-- Lua provided by RyzenAPI
-- Game: addappid(2994990)

-- MAIN APPLICATION
addappid(2994990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994991, 1, "894093ebeae42d54363fa7d7ff5b202a98ce4f00591bf15f5e70548c5c91a4bc")
