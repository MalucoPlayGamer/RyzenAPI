-- Lua provided by RyzenAPI
-- Game: 1747160

-- MAIN APPLICATION
addappid(1747160)
-- Game: addappid(1747160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747161, 1, "25c04de0d5c9ae6a317940825b15ce25d786e9510a9ab2fd83d760cc81014f1f")
