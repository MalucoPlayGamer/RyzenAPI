-- Lua provided by RyzenAPI 
-- Game: Pornocrates: Osiris's Seed
addappid(1747160)
addappid(1747161, 1, "25c04de0d5c9ae6a317940825b15ce25d786e9510a9ab2fd83d760cc81014f1f")
