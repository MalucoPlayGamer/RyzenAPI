-- Lua provided by RyzenAPI
-- Game: Game: Grave Gunner

-- MAIN APPLICATION
addappid(2701900)
-- Game: addappid(2701900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701901, 1, "53a3eaf4c9469bf7f7afaa511e41e11beb7fd9be8af5d3be41a097c2d5d3d90f")
