-- Lua provided by RyzenAPI
-- Game: Atelier Firis: The Alchemist and the Mysterious Journey / フィリスのアトリエ ～不思議な旅の錬金術士～

-- MAIN APPLICATION
addappid(527290)
addappid(573540)
addappid(573541)
addappid(573542)
addappid(573543)
addappid(573544)
addappid(573545)
addappid(573548)
addappid(620320)
addappid(620321)
addappid(620322)
addappid(620323)
addappid(620324)
addappid(620325)
addappid(620326)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(527291, 1, "419a7165a6a96cae8f47218488340de79e5207ed71d8fd1a9c664dd3fcb9c342")
addappid(573546, 0, "3e54b2cbb64c71db5944d8fb5838abd50d97da4cf77fd4bd21be526512e16378")
addappid(573547, 0, "c8bcad613ab7027d64a047fb06c1c62391f8709a22b15b70f004e8d91fc5aa57")

