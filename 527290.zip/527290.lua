-- Lua provided by RyzenAPI
-- Game: 527290

-- MAIN APPLICATION
addappid(527290)
-- Game: addappid(527290)

-- MAIN APP DEPOTS / PACKAGES
addappid(527291, 1, "419a7165a6a96cae8f47218488340de79e5207ed71d8fd1a9c664dd3fcb9c342")
addappid(573546, 0, "3e54b2cbb64c71db5944d8fb5838abd50d97da4cf77fd4bd21be526512e16378")
addappid(573547, 0, "c8bcad613ab7027d64a047fb06c1c62391f8709a22b15b70f004e8d91fc5aa57")
