-- Lua provided by RyzenAPI
-- Game: Lustful Butler And Charming Sisters

-- MAIN APPLICATION
addappid(2997120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997121, 1, "1eb6aac18921f46af207d80bb4294c731d859a54aa38117ce429ed843a77bfc8")

