-- Lua provided by RyzenAPI
-- Game: Tower of Hidden Waifus

-- MAIN APPLICATION
addappid(2619450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619451, 1, "d43a5f853cf7e4e7b3a6baa0c6a350fbaab52f7dbc782ae9993c8ddb55ecd18d")

