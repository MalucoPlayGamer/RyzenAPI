-- Lua provided by SkyAPI 
-- Game: AppID 321270
addappid(321270)
addappid(321271, 1, "962c38e7000d67cdb7908301a1d384bc073a2644a2c53120bbe13b1f14312dd3")
