-- Lua provided by RyzenAPI
-- Game: UNLOVED

-- MAIN APPLICATION
addappid(321270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(321271, 1, "962c38e7000d67cdb7908301a1d384bc073a2644a2c53120bbe13b1f14312dd3")
