-- Lua provided by RyzenAPI
-- Game: addappid(321270)

-- MAIN APPLICATION
addappid(321270)

-- MAIN APP DEPOTS / PACKAGES
addappid(321271, 1, "962c38e7000d67cdb7908301a1d384bc073a2644a2c53120bbe13b1f14312dd3")
