-- Lua provided by RyzenAPI
-- Game: Earthworm Jim 3D

-- MAIN APPLICATION
addappid(41600)

-- MAIN APP DEPOTS / PACKAGES
addappid(38481,0,"6778a7f58d926166ed32d1f84241ff1b10a0b7145ca2ca0077ad0f7c70801607")

