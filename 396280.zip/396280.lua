-- Lua provided by RyzenAPI
-- Game: Anarchy Online

-- MAIN APPLICATION
addappid(396280)
-- Game: addappid(396280)

-- MAIN APP DEPOTS / PACKAGES
addappid(396281, 1, "de8318381a609e3e67fb67774146c0eaee0de63fa9fe0c27b9297db943b98261")
addappid(663420, 0, "bb445c230a0b6f26e6e7cc64f9691e4dfff74b2fc217e473b822d124997fcd0b")
