-- 1135910's Lua and Manifest Created by Hubcap Manifest
-- Hunting Simulator 2
-- Created: September 29, 2025 at 18:31:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1135910) -- Hunting Simulator 2
-- MAIN APP DEPOTS
addappid(1135911, 1, "5a1f82285f633a2c47128104a6d5cd75edf0bd5b7c58da68f360d4f2d98ce61e") -- Hunting Simulator 2 All Languages
setManifestid(1135911, "5931820397542770102", 15515676479)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1255250) -- Hunting Simulator 2 Beretta Model 486 by Marc Newson
addappid(1255260) -- Hunting Simulator 2 Bear Hunter Pack
addappid(1255270) -- Hunting Simulator 2 Beretta Weapon Pack
addappid(1491100) -- Hunting Simulator 2 A Rangers Life