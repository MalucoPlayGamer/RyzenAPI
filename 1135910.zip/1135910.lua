-- Lua provided by SkyAPI 
-- Game: AppID 1135910
addappid(1135910)
addappid(1135911, 1, "5a1f82285f633a2c47128104a6d5cd75edf0bd5b7c58da68f360d4f2d98ce61e")
