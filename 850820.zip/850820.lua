-- Lua provided by RyzenAPI
-- Game: 祛魅·教化（祛魅1）

-- MAIN APPLICATION
addappid(850820)

-- MAIN APP DEPOTS / PACKAGES
addappid(850821, 1, "6face55df5055daba8a323260051725bf3e517019c32a8b2bf5ac2198df90e39")
addappid(1120730, 0, "9dd2454509b504b333ea2fab181a6bd7aa59499b7e7356f08251465550bfc1ed")
addappid(1471970, 0, "cfdeb7f53d513169c65e9c441537f487ec18d1694743a97246646efd0b320073")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
