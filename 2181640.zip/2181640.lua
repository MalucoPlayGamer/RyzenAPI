-- Lua provided by RyzenAPI
-- Game: 2181640

-- MAIN APPLICATION
addappid(2181640)
-- Game: addappid(2181640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181641, 1, "1df10df57088fa0953b77bd36dbb6e837214c6cbf2290166c4bb154b90c305f7")
