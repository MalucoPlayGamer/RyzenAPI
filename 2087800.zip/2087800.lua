-- Lua provided by RyzenAPI
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 14 - Mega Man: The Power Battle - Player Select

-- MAIN APPLICATION
addappid(2087800)
-- Game: addappid(2087800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087801, 1, "ee7225fee83d6c158bafecfa7436c7d791e6f50655fae4ac3f5d41581f1d47a0")
addappid(2087802, 1, "4c6d630b6477111e2ba654ec299617b041985af821774b5b6533d65a08447211")
addappid(2087803, 1, "7d16f7ce22144316bba00d3d50084547ff6c8e32cdb151678b8bfa6509474789")
addappid(2087804, 1, "b84c34e20143d9cda5a338235585b2cc664b29457ec09411297865baf1ae9c4a")
addappid(2087805, 1, "2aac9bc1a7e87c3397dadc92fcf16d6a7c1644499c842dc2a9863415b23bbf52")
addappid(2087806, 1, "0735709a6cdad0c0e982b06189ce372276443883aee580264f36323793e5d5be")
