-- Lua provided by RyzenAPI
-- Game: Game: 69 LOVE

-- MAIN APPLICATION
addappid(3136230)
-- Game: addappid(3136230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136231, 1, "07e219f47cca9c6d1d6714066271edf9e915682da04cb45c37527674d27e05e7")
