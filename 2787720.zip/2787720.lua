-- 2787720's Lua and Manifest Created by Hubcap Manifest
-- Super Rolling Heroes Deluxe
-- Created: August 06, 2026 at 23:51:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2787720) -- Super Rolling Heroes Deluxe
-- MAIN APP DEPOTS
addappid(2787721, 1, "7c1dced3aec33e5e67b657cae0926abec1aff04e8ac9bfa07c801fee491ad9bf") -- Depot 2787721
setManifestid(2787721, "5395902604309308699", 2372116370)