-- Lua provided by RyzenAPI
-- Game: Super Rolling Heroes Deluxe

-- MAIN APPLICATION
addappid(2787720) -- Super Rolling Heroes Deluxe

-- MAIN APP DEPOTS / PACKAGES
addappid(2787721, 1, "7c1dced3aec33e5e67b657cae0926abec1aff04e8ac9bfa07c801fee491ad9bf") -- Depot 2787721

