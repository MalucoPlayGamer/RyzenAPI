-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2394530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394533,0,"4c45d6cb6e628682ab28495b988cd0f18702ff8b1a52c9dcc195a01aa1de50b4")
