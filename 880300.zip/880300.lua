-- Lua provided by RyzenAPI
-- Game: addappid(880300)

-- MAIN APPLICATION
addappid(880300)

-- MAIN APP DEPOTS / PACKAGES
addappid(880301, 1, "eb74fac082c99c5af98d80e42301b5cda1c18a162744a570eac92f929ef15c3b")
addappid(1212880, 0, "41a502fcf7e13d21d5e847f0f94588b35c2b8bb2a5754a7ec97e08ccbb8fc42b")
