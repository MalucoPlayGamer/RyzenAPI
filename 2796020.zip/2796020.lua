-- Lua provided by RyzenAPI
-- Game: Refuted Wind

-- MAIN APPLICATION
addappid(2796020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796021, 1, "8f6e62f99eeef44ea2a35b8075a08cc007d6506f5a5c1c3034846e866588289c")
