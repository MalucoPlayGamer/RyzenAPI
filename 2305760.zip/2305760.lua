-- Lua provided by RyzenAPI
-- Game: Game: 人間牧場 Residence

-- MAIN APPLICATION
addappid(2305760)
-- Game: addappid(2305760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305761, 1, "15f87b7ab55928417f84b159f2467055fcd45da0e91f98bd5559c7f602cf1367")
