-- Lua provided by SkyAPI 
-- Game: AppID 349240
addappid(349240)
addappid(349241, 1, "5ad8affe560ec2496526370cbfdd55c274736d885b6139521784fbc26b34d279")
addappid(353060, 0, "7e7807a6aac2edc724174559d0475b8619aa4fe66220ea54ff021fd58cecb753")
