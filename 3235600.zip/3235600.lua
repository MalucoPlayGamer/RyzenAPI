-- Lua provided by RyzenAPI
-- Game: addappid(3235600)

-- MAIN APPLICATION
addappid(3235600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3235601, 1, "290533670b7718a274837ae558fee57c892dc92d930aabd836653186b9fc7cfe")
