-- Lua provided by RyzenAPI
-- Game: Game: Math High Speed

-- MAIN APPLICATION
addappid(2589400)
-- Game: addappid(2589400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589401, 1, "0d870e52b3d508a6b5d25f31c178dd90b28a2abc06445197c5a17c9f850f81a4")
