-- Lua provided by RyzenAPI
-- Game: The Shadow Government Simulator

-- MAIN APPLICATION
addappid(1281190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281191, 1, "8e51426f41784c14ff9d66b56772235479ecc62da8eaaf469e1caacad4b235b8")
