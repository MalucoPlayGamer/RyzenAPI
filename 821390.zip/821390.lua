-- Lua provided by RyzenAPI
-- Game: 821390

-- MAIN APPLICATION
addappid(821390)
-- Game: addappid(821390)

-- MAIN APP DEPOTS / PACKAGES
addappid(821391, 1, "68e368ab5f6f8c04a9eb45735daf77178c47d1cbb3f2aab6456a4c1e63b4b7e8")
