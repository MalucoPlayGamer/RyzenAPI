-- Lua provided by RyzenAPI
-- Game: Game: Patron Soundtrack

-- MAIN APPLICATION
addappid(1639550)
-- Game: addappid(1639550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639551, 1, "12414d7a4b3359a94720223a2d35ddd89934a9b54635515f190e1cca89f7e08e")
addappid(1639552, 1, "c6240480ef13489d216d69651532ce388622db45d2c0d24a03aed6315bcf82e1")
