-- Lua provided by RyzenAPI
-- Game: Terraforming Mars

-- MAIN APPLICATION
addappid(800270)
addappid(1245590)
addappid(1785010)
addappid(2625120)
addappid(2948100)
addappid(2948110)
addappid(4143120)

-- MAIN APP DEPOTS / PACKAGES
addappid(800271,0,"ce2ca0ea9d981da32cc3cb7e8804e230219f22a6abd38bc0ee73572d3cab96ac")
addappid(800272,0,"178c54b3d0eae73ad216e565b6901f02813a08934a759db19a4a17e2214bc7c7")

