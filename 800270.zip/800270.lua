-- Lua provided by RyzenAPI
-- Game: Game: AppID 800270

-- MAIN APPLICATION
addappid(800270)
-- Game: addappid(800270)

-- MAIN APP DEPOTS / PACKAGES
addappid(800271, 1, "ce2ca0ea9d981da32cc3cb7e8804e230219f22a6abd38bc0ee73572d3cab96ac")
