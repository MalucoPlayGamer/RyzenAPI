-- Lua provided by RyzenAPI
-- Game: Core Keeper Dedicated Server

-- MAIN APPLICATION
addappid(1963720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963721, 1, "7f6ad0c6574df3d507c724104075628cdb6aa8e193d3c3b4883d1a21be28c0ac")
addappid(1963722, 1, "1c94c34bbd421f024df34315ddf63f5360957fe6d48b699199e6a27325c41f63")

