-- Lua provided by RyzenAPI
-- Game: Game: Alien Spidy

-- MAIN APPLICATION
addappid(207000)
addappid(207951)
-- Game: addappid(207000)

-- MAIN APP DEPOTS / PACKAGES
addappid(207001, 1, "712a4181cd75a88f43c3f84bb8e9e0895c3d33506b207d3f4ea9e8703a8570c6")
addappid(207002, 1, "cedbd53fec1a2991282fa65c44311cd6be6f7b0e02e973c43c2d5967fb3b3164")
