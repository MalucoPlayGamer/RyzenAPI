-- Lua provided by RyzenAPI
-- Game: AppID 237630

-- MAIN APPLICATION
addappid(237630)

-- MAIN APP DEPOTS / PACKAGES
addappid(237631, 1, "8109a2506a5c0b1d757517edf3b1fb809c43ea094e293acf57dd46c2c6314127")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
