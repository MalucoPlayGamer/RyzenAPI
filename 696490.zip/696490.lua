-- Lua provided by SkyAPI 
-- Game: TOTOBALL
addappid(696490)
addappid(696491, 1, "766e6dfbc04d530c658ea2e781785970f668f3e5fdc0abd9242c2aaf7586da73")
