-- Lua provided by RyzenAPI
-- Game: Dungeon Travelers: To Heart 2 in Another World

-- MAIN APPLICATION
addappid(1901620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901621, 1, "cff445f7e4d109d7a1a3762c96ea9705e95f4fd22930b95b342cae585303ff1a")
addappid(1901622, 1, "1360b457942f4da3d6623a79ab9fad1cb85a90bf2141ccec5031871d90a6e738")
addappid(1901623, 1, "d9415c709c038ac95056003944d7a4b29732e2c6aeee14c968cfe44860ac09b6")
addappid(1901624, 1, "0e9abcd40cef2b26f286c59e7de4a50d803e66043ec6db05f7af1ed20bb0ee54")
