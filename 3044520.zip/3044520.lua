-- Lua provided by RyzenAPI
-- Game: addappid(3044520)

-- MAIN APPLICATION
addappid(3044520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044521, 1, "941364f880d94742096177f2aadde439ffa84c8e62f479b3690d397d2d3ac8aa")
