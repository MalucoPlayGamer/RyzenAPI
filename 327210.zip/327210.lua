-- Lua provided by SkyAPI 
-- Game: AppID 327210
addappid(327210)
addappid(327211, 1, "567593bac04deb9765fe39e2e74ecf5de8ed2e23ec4598e71a82129254215011")
