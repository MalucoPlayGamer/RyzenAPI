-- Lua provided by RyzenAPI
-- Game: SCP: 5K (Alpha Testing)

-- MAIN APPLICATION
addappid(872670)
addappid(884101)
addappid(884102)
addappid(1989390)
addappid(3508400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(872671,0,"87514c506dda0ed736b270bc5563c239ebe571e9c215a2c9085414ba6c22d26a")

