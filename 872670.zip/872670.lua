-- Lua provided by RyzenAPI
-- Game: SCP: 5K (Alpha Testing)

-- MAIN APPLICATION
addappid(872670)
addappid(884101)
addappid(884102)
addappid(1989390)
addappid(3508400)

-- MAIN APP DEPOTS / PACKAGES
addappid(872671,0,"87514c506dda0ed736b270bc5563c239ebe571e9c215a2c9085414ba6c22d26a")

