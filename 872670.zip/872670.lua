-- Lua provided by RyzenAPI
-- Game: 872670

-- MAIN APPLICATION
addappid(872670)
-- Game: addappid(872670)

-- MAIN APP DEPOTS / PACKAGES
addappid(872671, 1, "87514c506dda0ed736b270bc5563c239ebe571e9c215a2c9085414ba6c22d26a")
