-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Honmaru Backdrop "Autumn Leaves"

-- MAIN APPLICATION
addappid(1912042)
-- Game: addappid(1912042)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912042,0,"c00a85089e22c980b458b9fc17bedce136ad3c2c26b91360bf3972448a24f9fc")
