-- Lua provided by RyzenAPI
-- Game: Magnificent Ships: Volume 2

-- MAIN APPLICATION
addappid(628450)

-- MAIN APP DEPOTS / PACKAGES
addappid(628451,0,"cbedfe99ef8c25ce8d63e025ed2db70dea38f154e2be3f97164b8ebf504bc7f9")

