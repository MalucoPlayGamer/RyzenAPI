-- Lua provided by RyzenAPI
-- Game: addappid(2465160)

-- MAIN APPLICATION
addappid(2465160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465161, 1, "ef1759d043873b3cf9e9bb31354712a4f5625c6cbb3307f3954b9c86f0d84a6e")
