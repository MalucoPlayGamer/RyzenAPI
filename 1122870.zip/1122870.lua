-- Lua provided by RyzenAPI
-- Game: AppID 1122870

-- MAIN APPLICATION
addappid(1122870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122871, 1, "d802ad3783aede25cd309e0a4586bf07aae917b250f07b0c33d6dedefbccfe05")

