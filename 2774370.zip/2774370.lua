-- Lua provided by RyzenAPI
-- Game: 星烬 烛耀山海

-- MAIN APPLICATION
addappid(2774370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774371,0,"a197cd2b840a86a0de43b1a170b700547baa4cd300532881577bdd1c549cd47e")
addappid(3841650,0,"5eb8cc1ee93f79e8ef2dba2ee667e9159f6e25679d9a3104a0ef6583115b1ec2")

