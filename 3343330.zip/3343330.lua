-- Lua provided by RyzenAPI
-- Game: addappid(3343330)

-- MAIN APPLICATION
addappid(3343330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343331, 1, "ec9b6a5f6dcf99594f2d218f51cf254b9aa8ce50517b230381687c56b7cd4a43")
