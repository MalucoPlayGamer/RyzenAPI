-- Lua provided by RyzenAPI
-- Game: Game: AppID 597150

-- MAIN APPLICATION
addappid(597150)
-- Game: addappid(597150)

-- MAIN APP DEPOTS / PACKAGES
addappid(597151, 1, "cf0d6c456b6d6d42eb0d576381c53c864676928b4ef48420f29ba5dde109472d")
addappid(597152, 1, "a24e0e8a2c2384101a70dbd3726d408465a41465c1edb0efe73a6eee40ab296c")
addappid(597153, 1, "243a58dfa09678cad6be83d3e30531f2a2523b06bed623db9161b7ca4ba33e97")
