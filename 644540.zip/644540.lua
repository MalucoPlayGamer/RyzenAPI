-- Lua provided by RyzenAPI
-- Game: AppID 644540

-- MAIN APPLICATION
addappid(644540)

-- MAIN APP DEPOTS / PACKAGES
addappid(644541, 1, "022fadf8d636ccecded076441ab43f94474f9cb2d7b165ddeffe8d847a49f786")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(645770)
addappid(645771)
addappid(1038510)
addappid(1038530)
