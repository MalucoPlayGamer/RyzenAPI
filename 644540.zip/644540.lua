-- Lua provided by RyzenAPI
-- Game: Dies irae ~Amantes amentes~

-- MAIN APPLICATION
addappid(644540)
addappid(645770)
addappid(645771)
addappid(1038510)
addappid(1038530)

-- MAIN APP DEPOTS / PACKAGES
addappid(644541, 1, "022fadf8d636ccecded076441ab43f94474f9cb2d7b165ddeffe8d847a49f786")
