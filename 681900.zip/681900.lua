-- Lua provided by RyzenAPI
-- Game: ionAXXIA

-- MAIN APPLICATION
addappid(681900)

-- MAIN APP DEPOTS / PACKAGES
addappid(681901,0,"7a08569e9b1feb6b31d2b2155747be81dee14ab23368d3017a98ac168b28a3fd")

