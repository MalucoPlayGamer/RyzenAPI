-- Lua provided by RyzenAPI
-- Game: addappid(533950)

-- MAIN APPLICATION
addappid(533950)
addappid(556100)
addappid(803950)

-- MAIN APP DEPOTS / PACKAGES
addappid(533951, 1, "9ea5dea7502557ef71acadeaebaf7a2754e2188b9ca1ca331c72fab899b1a1a8")
addappid(533952, 1, "2188cf5516276574e0ab41b3d50dd125c6e34acb5cc0de4b2f1ff0fc1ea3e39c")
addappid(598290, 0, "52cf9a437a7887a4c640c3ba30592eb0140a46140981c34a92912dda99d4aec8")
