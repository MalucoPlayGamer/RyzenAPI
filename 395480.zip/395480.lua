-- Lua provided by RyzenAPI
-- Game: AppID 395480

-- MAIN APPLICATION
addappid(395480)

-- MAIN APP DEPOTS / PACKAGES
addappid(395481, 1, "cb61da84d6ab9ec03dc4af8c9dd971f2de27c9113bf0b0f7e578fa717bca5614")
