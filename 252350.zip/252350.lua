-- Lua provided by RyzenAPI
-- Game: Double Dragon: Neon

-- MAIN APPLICATION
addappid(252350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(252351, 1, "457d341e2133958d25f754d338c3c683d767cea9ac028c4f3a148afdb49a5a5a")

