-- Lua provided by RyzenAPI
-- Game: Double Dragon: Neon

-- MAIN APPLICATION
addappid(252350)

-- MAIN APP DEPOTS / PACKAGES
addappid(252351, 1, "457d341e2133958d25f754d338c3c683d767cea9ac028c4f3a148afdb49a5a5a")

