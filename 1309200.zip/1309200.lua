-- Lua provided by RyzenAPI
-- Game: Game: 3D Math - Ultra

-- MAIN APPLICATION
addappid(1309200)
-- Game: addappid(1309200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309201, 1, "25d7d31cc170b0fe8922113286b53c3338113ff3077744d61f73e5e48e4b7a92")
