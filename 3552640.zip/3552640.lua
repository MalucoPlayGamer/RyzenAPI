-- Lua provided by SkyAPI 
-- Game: Turnout Playtest
addappid(3552640)
addappid(3552641, 1, "0678c7365597d6570a8154d50e4658b46323545b7ae47d5624bee5955d264adb")
