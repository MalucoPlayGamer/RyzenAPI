-- Lua provided by RyzenAPI
-- Game: Game: ATNRPG

-- MAIN APPLICATION
addappid(2420690)
-- Game: addappid(2420690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420691, 1, "90faa1cedebbb68c75608ad680a4722917b1563eef111874ccae2bef6c20fee4")
addappid(2420692, 1, "de328487349df81d5dbd992ad914acb84cff824b6a5fa1d466c6927bbc602987")
