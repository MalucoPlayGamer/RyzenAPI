-- Lua provided by SkyAPI 
-- Game: AppID 2790360
addappid(2790360)
addappid(2790361, 1, "7c2cf1d6fbfe894cffa87225ab4d9af2d51661eb5df301110943c17e0ec6c86d")
