-- Lua provided by RyzenAPI
-- Game: Game: AppID 2790360

-- MAIN APPLICATION
addappid(2790360)
-- Game: addappid(2790360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790361, 1, "7c2cf1d6fbfe894cffa87225ab4d9af2d51661eb5df301110943c17e0ec6c86d")
