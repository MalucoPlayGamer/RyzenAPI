-- Lua provided by RyzenAPI
-- Game: addappid(768240)

-- MAIN APPLICATION
addappid(768240)

-- MAIN APP DEPOTS / PACKAGES
addappid(768241, 1, "76cc2272e341502683b849c9657dc6fa0a8d4e8b730c7d939199c5f7013bfe6d")
