-- Lua provided by RyzenAPI
-- Game: Beware Planet Earth

-- MAIN APPLICATION
addappid(267340)

-- MAIN APP DEPOTS / PACKAGES
addappid(267341, 1, "80d150616e12f8c204a12c74c55438e91175f5e0362e73e5d0888dd3129696fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
