-- Lua provided by RyzenAPI 
-- Game: Beware Planet Earth
addappid(267340)
addappid(267341, 1, "80d150616e12f8c204a12c74c55438e91175f5e0362e73e5d0888dd3129696fc")
