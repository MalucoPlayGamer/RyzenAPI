-- Lua provided by RyzenAPI
-- Game: addappid(1019981)

-- MAIN APPLICATION
addappid(1019981)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019981,0,"01a76e18abf5c2d1a5db9ceffeed1b7b3f85017c675f4a5960adf8fb9820e1ac")
