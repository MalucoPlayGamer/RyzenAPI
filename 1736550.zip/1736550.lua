-- Lua provided by SkyAPI 
-- Game: AppID 1736550
addappid(1736550)
addappid(1736551, 1, "80e87e7a4694b14c6ebb79a7842493a8c6ce0d2ba0cd8cb3263f9cf1b641946e")
