-- Lua provided by RyzenAPI
-- Game: 1736550

-- MAIN APPLICATION
addappid(1736550)
-- Game: addappid(1736550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736551, 1, "80e87e7a4694b14c6ebb79a7842493a8c6ce0d2ba0cd8cb3263f9cf1b641946e")
