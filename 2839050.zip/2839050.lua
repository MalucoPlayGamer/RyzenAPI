-- Lua provided by RyzenAPI
-- Game: AppID 2839050

-- MAIN APPLICATION
addappid(2839050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839051, 1, "74b41e5ce521da7cd5075e891981c53df8c606dc9d1411df56a2e97cba2d6c4b")
