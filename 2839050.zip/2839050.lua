-- Lua provided by RyzenAPI
-- Game: Real Life

-- MAIN APPLICATION
addappid(2839050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2839051, 1, "74b41e5ce521da7cd5075e891981c53df8c606dc9d1411df56a2e97cba2d6c4b")

