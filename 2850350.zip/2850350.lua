-- Lua provided by RyzenAPI
-- Game: 三国之怒

-- MAIN APPLICATION
addappid(2850350)
-- Game: addappid(2850350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850351, 1, "a042290a21b09b7066dcfcb178402fda008e12bb623c9ae1c79b3513c070922e")
