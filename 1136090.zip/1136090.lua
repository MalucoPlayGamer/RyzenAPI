-- Lua provided by SkyAPI 
-- Game: AppID 1136090
addappid(1136090)
addappid(1136091, 1, "a1d8af67cf1d2c13abffb3a197006d010d713837dd476b9206b8d37faf224eab")
