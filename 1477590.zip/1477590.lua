-- Lua provided by RyzenAPI
-- Game: EZ2ON REBOOT : R

-- MAIN APPLICATION
addappid(1477590)
addappid(1758560)
addappid(1926200)
addappid(1926210)
addappid(1926230)
addappid(2052630)
addappid(2130530)
addappid(2325460)
addappid(2427370)
addappid(2459810)
addappid(2688850)
addappid(2688860)
addappid(2688870)
addappid(3279470)
addappid(4039770)
addappid(4118900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1477591,0,"be6fde91b3fd41595188145d3f615546f92ef745010e1296bdec41f9cccb22d8")
addappid(1477592,0,"2fd251cc6b1807b6f5660299063a872076c0169a063f52608c358dedfc1ff485")

