-- Lua provided by RyzenAPI
-- Game: EZ2ON REBOOT : R

-- MAIN APPLICATION
addappid(1477590)
addappid(1758560)
addappid(1926200)
addappid(1926210)
addappid(1926230)
addappid(2052630)
addappid(2130530)
addappid(2325460)
addappid(2427370)
addappid(2459810)
addappid(2688850)
addappid(2688860)
addappid(2688870)
addappid(3279470)
addappid(4039770)
addappid(4118900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477591,0,"be6fde91b3fd41595188145d3f615546f92ef745010e1296bdec41f9cccb22d8")
addappid(1477592,0,"2fd251cc6b1807b6f5660299063a872076c0169a063f52608c358dedfc1ff485")

