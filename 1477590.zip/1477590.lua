-- Lua provided by RyzenAPI
-- Game: Game: EZ2ON REBOOT : R

-- MAIN APPLICATION
addappid(1477590)
-- Game: addappid(1477590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477591, 1, "be6fde91b3fd41595188145d3f615546f92ef745010e1296bdec41f9cccb22d8")
