-- Lua provided by RyzenAPI
-- Game: TEXT: Russia

-- MAIN APPLICATION
addappid(1436390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436391, 1, "a98b28d651e02f974092b7219ab4778d28dcb74728484d96d83cefed9118f76e")

