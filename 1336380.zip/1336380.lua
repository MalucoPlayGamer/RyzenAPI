-- Lua provided by RyzenAPI 
-- Game: AppID 1336380
addappid(1336380)
addappid(1336381, 1, "386590840719f57d561410a15c29be921e1bc9151b125f4292271e1602f89e94")
