-- Lua provided by RyzenAPI
-- Game: AppID 720660

-- MAIN APPLICATION
addappid(720660)
-- Game: addappid(720660)

-- MAIN APP DEPOTS / PACKAGES
addappid(720661, 1, "382e50ae208006866dcd3e9a0208e935806a00d32687e08be3f8c6cc5645e1ba")
