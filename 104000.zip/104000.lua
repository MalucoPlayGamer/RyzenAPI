-- Lua provided by RyzenAPI
-- Game: addappid(104000)

-- MAIN APPLICATION
addappid(104000)
addappid(228983)
addappid(228985)
addappid(229020)

-- MAIN APP DEPOTS / PACKAGES
addappid(104001, 1, "68cde29538bb1e10c91b9bba2bfbcc276c702a4f45734e4637d048d271880733")
addappid(104002, 1, "3fe357120e127f257ec3600ebe26376d5a80e730c41d43a24bead0fd00a45e19")
