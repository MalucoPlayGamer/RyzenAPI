-- Lua provided by RyzenAPI
-- Game: 0010100

-- MAIN APPLICATION
addappid(2753820)
-- Game: addappid(2753820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753821, 1, "ab3ca5c4c26ab14774ef4554018f27913b578c92218b4b8a420bac5b650533c3")
