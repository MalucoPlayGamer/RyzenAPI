-- Lua provided by SkyAPI 
-- Game: 0010100
addappid(2753820)
addappid(2753821, 1, "ab3ca5c4c26ab14774ef4554018f27913b578c92218b4b8a420bac5b650533c3")
