-- Lua provided by RyzenAPI
-- Game: Turqu-chan in the Hentai Laboratory

-- MAIN APPLICATION
addappid(2520890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520891, 1, "5ca71c57e45588826954bd23ef9e030034b34383133c5d9791b9f6c411949b6a")

