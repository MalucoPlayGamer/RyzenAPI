-- Lua provided by RyzenAPI
-- Game: Guan Suo - Officer Ticket / 関索使用券

-- MAIN APPLICATION
addappid(956893)
-- Game: addappid(956893)

-- MAIN APP DEPOTS / PACKAGES
addappid(956893,0,"a40ec02bebfe87562ca1867e5443958a6aef27f76f7ae494df08e745225c9bce")
