-- Lua provided by RyzenAPI
-- Game: addappid(2188650)

-- MAIN APPLICATION
addappid(2188650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188651, 1, "ea68e47f78a0528a0db3d132c2611b4ad89f2deeb336a1ddd6c6799ab2694dc4")
