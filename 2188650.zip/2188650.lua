-- Lua provided by RyzenAPI 
-- Game: Cursor Space
addappid(2188650)
addappid(2188651, 1, "ea68e47f78a0528a0db3d132c2611b4ad89f2deeb336a1ddd6c6799ab2694dc4")
