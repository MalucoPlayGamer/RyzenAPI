-- Lua provided by RyzenAPI
-- Game: Lumione

-- MAIN APPLICATION
addappid(1339860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1339861, 1, "478f4b81d24ff2c1a55e0687a5e7e02161df76cd75ac2d165729d44ae52422e5")

