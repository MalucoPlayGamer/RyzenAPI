-- Lua provided by RyzenAPI
-- Game: Rain on Your Parade

-- MAIN APPLICATION
addappid(1213230)
addappid(1764320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1213231, 1, "ae03ffc4420f8b8e0cb45d3fecbb80398836052ba52baa188ecb4157f1bb9382")
addappid(1213232, 1, "a34e913f106817caa6a0f48cfaf348653ccb0872ea294566572701118fcdb403")
addappid(1213233, 1, "02d178e928af12664b1605154ac0556fec5e0a0a5cbf1790bcd59cb6b818c5dc")
