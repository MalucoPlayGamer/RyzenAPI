-- Lua provided by RyzenAPI
-- Game: Baseball Mogul 2015

-- MAIN APPLICATION
addappid(388270)
-- Game: addappid(388270)

-- MAIN APP DEPOTS / PACKAGES
addappid(388271, 1, "f70d733dba35c77c92e28ebfdb8d04407429b1b8697a524ccd6ef0a92a6652a9")
