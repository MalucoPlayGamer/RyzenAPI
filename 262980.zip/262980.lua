-- Lua provided by RyzenAPI
-- Game: setManifestid(262982,"2364338004047653811")

-- MAIN APPLICATION
addappid(262980)

-- MAIN APP DEPOTS / PACKAGES
addappid(262982,0,"72b68be37ce2b5befa8a2c786eb7ea35d776fbf26f849d5d683bc731a0816d79")

