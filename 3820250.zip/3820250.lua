-- Lua provided by RyzenAPI
-- Game: Jrago II Eden The Journey Home

-- MAIN APPLICATION
addappid(3820250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3820252,0,"ccecd5589bf50fa6a08567c6b6568a74ebab7b7f6e2fde6fcf961c3c18d17c51")
