-- Lua provided by RyzenAPI
-- Game: 611850

-- MAIN APPLICATION
addappid(611850)
-- Game: addappid(611850)

-- MAIN APP DEPOTS / PACKAGES
addappid(611851, 1, "4b7c7cd4d98da1a1d8d69c4a6e3545b40c43acdefb62751000d11ddc8ab8fbe5")
