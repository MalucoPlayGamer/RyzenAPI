-- Lua provided by RyzenAPI
-- Game: Tragedy of Prince Rupert

-- MAIN APPLICATION
addappid(611850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(611851, 1, "4b7c7cd4d98da1a1d8d69c4a6e3545b40c43acdefb62751000d11ddc8ab8fbe5")
