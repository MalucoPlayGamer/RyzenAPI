-- Lua provided by RyzenAPI 
-- Game: Procyon
addappid(266250)
addappid(266251, 1, "81261106e5b9d3b9972daa717e416dcd24a43abd4111fb620dceb81c60637f75")
