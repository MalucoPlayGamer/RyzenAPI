-- Lua provided by RyzenAPI
-- Game: Procyon

-- MAIN APPLICATION
addappid(266250)

-- MAIN APP DEPOTS / PACKAGES
addappid(266251, 1, "81261106e5b9d3b9972daa717e416dcd24a43abd4111fb620dceb81c60637f75")
