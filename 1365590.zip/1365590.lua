-- Lua provided by RyzenAPI
-- Game: Timewalk Tower Defense

-- MAIN APPLICATION
addappid(1365590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365591, 1, "a63ccb551de6b57ddb79296155984a37d0ae777302cca0aced339a0a6778f2bd")

