-- Lua provided by RyzenAPI
-- Game: Game: Desktopia: A Desktop Village Simulator

-- MAIN APPLICATION
addappid(2018130)
-- Game: addappid(2018130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018131, 1, "71b57c306f6ac764b4f72ca9ea52061853d1ab860d63757d6cab1362c4c650d7")
addappid(2018132, 1, "4226da1f96803307259d688d8c2903a6118152c401be4cc0b59f36d490072e19")
addappid(2280100, 0, "1148d0cd2642bfd05675c95a98344864313241b93b971789bd8c635d3b6fee34")
