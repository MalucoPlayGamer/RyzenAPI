-- Lua provided by RyzenAPI
-- Game: One Room Dungeon Demo

-- MAIN APPLICATION
addappid(3065840)
-- Game: addappid(3065840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3065841, 1, "aadc63f169b59d87b21295c282710777ee580688b1867765658464f69c86affb")
