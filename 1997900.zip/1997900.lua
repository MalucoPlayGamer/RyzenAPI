-- Lua provided by RyzenAPI 
-- Game: Fxxkable Kim
addappid(1997900)
addappid(1997901, 1, "d15ec949492130f73bd41768463b7aa7e780003f7bb64413991218c83e43e52a")
