-- Lua provided by RyzenAPI
-- Game: Game: Fxxkable Kim

-- MAIN APPLICATION
addappid(1997900)
-- Game: addappid(1997900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997901, 1, "d15ec949492130f73bd41768463b7aa7e780003f7bb64413991218c83e43e52a")
