-- Lua provided by RyzenAPI
-- Game: Metaphor: ReFantazio - Shujin Academy School Uniform (7), Battle BGM & Battle Jingle Set

-- MAIN APPLICATION
addappid(2924400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924400,0,"9e10f74a58642944210d4ac83c2afe05a39a9260522357676d71f7a173b06377")

