-- Lua provided by RyzenAPI 
-- Game: AppID 1067020
addappid(1067020)
addappid(1067021, 1, "12620184110e2deedeaa26cc7a89a794aa6a9140639acd4356f9217c134a097e")
addappid(1150840, 0, "70fdaeebb18723daf801fb5f477da697007ae7a2bb7e11b7b406b8708898966f")
