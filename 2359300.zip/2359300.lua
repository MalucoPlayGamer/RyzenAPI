-- Lua provided by RyzenAPI 
-- Game: Combo Bombo
addappid(2359300)
addappid(2359301, 1, "c916d837daadb232ea8979a03848def9176c1b01e377de88c5885582d6c2a7a1")
