-- Lua provided by RyzenAPI
-- Game: Combo Bombo

-- MAIN APPLICATION
addappid(2359300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359301, 1, "c916d837daadb232ea8979a03848def9176c1b01e377de88c5885582d6c2a7a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
