-- Lua provided by RyzenAPI
-- Game: 2361370

-- MAIN APPLICATION
addappid(2361370)
-- Game: addappid(2361370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361371, 1, "3f70cde6a15b5a6c85735f91527f80e2f7ec50f1b701ea9426299cd68b1079a9")
