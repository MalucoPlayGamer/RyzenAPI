-- Lua provided by RyzenAPI
-- Game: addappid(2506480)

-- MAIN APPLICATION
addappid(2506480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506481, 1, "7121a4ab19d5ec332a0f39b06ce5a28df4aef2d556b8913b9b5dbf83305bee8e")
