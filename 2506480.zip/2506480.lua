-- Lua provided by RyzenAPI
-- Game: AppID 2506480

-- MAIN APPLICATION
addappid(2506480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506481, 1, "7121a4ab19d5ec332a0f39b06ce5a28df4aef2d556b8913b9b5dbf83305bee8e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2556790)
addappid(2556800)
addappid(2666740)
addappid(2880150)
addappid(3102720)
addappid(3252340)
addappid(3465720)
addappid(3659490)
addappid(4194490)
addappid(4341730)
addappid(4772090)
