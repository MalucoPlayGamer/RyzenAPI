-- Lua provided by RyzenAPI
-- Game: Game: Lucky Hunter Demo

-- MAIN APPLICATION
addappid(2862520)
-- Game: addappid(2862520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862521, 1, "462bf4f3aba4575122509be38db529c25d0baee82c79efde89357260615f7af4")
