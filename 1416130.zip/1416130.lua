-- Lua provided by RyzenAPI
-- Game: Perfect Vermin

-- MAIN APPLICATION
addappid(1416130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416131, 1, "cf01ecf5dfd663efd91518f27812c40b6dafa70ab804662f3b81b28869b50e57")
addappid(1416132, 1, "06d7abe1ac2a22736f976feae86b93657c744ff9b625bb9bb015c1484e66b6f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
