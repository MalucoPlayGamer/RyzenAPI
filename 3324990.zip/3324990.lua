-- Lua provided by SkyAPI 
-- Game: Tao Path (Alpha Demo)
addappid(3324990)
addappid(3324991, 1, "600591f6b30e0fca64d7662c686564c1117cc775daffaf81c72fc9d2dec615fb")
