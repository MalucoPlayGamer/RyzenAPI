-- Lua provided by RyzenAPI
-- Game: 3324990

-- MAIN APPLICATION
addappid(3324990)
-- Game: addappid(3324990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3324991, 1, "600591f6b30e0fca64d7662c686564c1117cc775daffaf81c72fc9d2dec615fb")
