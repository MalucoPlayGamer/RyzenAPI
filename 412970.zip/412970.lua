-- Lua provided by RyzenAPI
-- Game: AppID 412970

-- MAIN APPLICATION
addappid(412970)
addappid(412980)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(412971, 1, "94dc637e827ca2546f213c428892c9233ab6eb850438fb768e0c13667e8832eb")
addappid(412972, 1, "b56564f771263eeaa747d6a9c513ac9274cc612be9e2f7073e5d7ab375edadc5")

