-- Lua provided by RyzenAPI
-- Game: The Colorful Creature

-- MAIN APPLICATION
addappid(1651680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651681, 1, "2c75aecf9dc9aa6b9c298770f5f5c22912face1a45df36392ee0ee394d06f5f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2411810)
addappid(2411811)
addappid(2411812)
