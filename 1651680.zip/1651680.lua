-- Lua provided by RyzenAPI
-- Game: 1651680

-- MAIN APPLICATION
addappid(1651680)
-- Game: addappid(1651680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651681, 1, "2c75aecf9dc9aa6b9c298770f5f5c22912face1a45df36392ee0ee394d06f5f8")
