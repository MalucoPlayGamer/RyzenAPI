-- Lua provided by RyzenAPI
-- Game: Game: Warlander

-- MAIN APPLICATION
addappid(1675900)
-- Game: addappid(1675900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675901, 1, "fe75a2e006426eb8247eec627743412480cd31a19944415300eb79a9047aec39")
