-- Lua provided by RyzenAPI
-- Game: Warlander

-- MAIN APPLICATION
addappid(1675900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1675901, 1, "fe75a2e006426eb8247eec627743412480cd31a19944415300eb79a9047aec39")

