-- Lua provided by RyzenAPI
-- Game: addappid(1021730)

-- MAIN APPLICATION
addappid(1021730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021731, 1, "1c6bd8ab8ec9f5254e277475770840f7ea94874ba50c1e1bf39be7e88640f7b2")
