-- Lua provided by RyzenAPI
-- Game: Cultivation Realm: Card Survival

-- MAIN APPLICATION
addappid(2921670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921671, 1, "920df379b5be334e3596ca4c7eef466e5db09832bc19456fea651c7643573b6f")
