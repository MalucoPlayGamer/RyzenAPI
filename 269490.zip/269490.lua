-- Lua provided by RyzenAPI
-- Game: Game: Bardbarian

-- MAIN APPLICATION
addappid(269490)
-- Game: addappid(269490)

-- MAIN APP DEPOTS / PACKAGES
addappid(269491, 1, "f3073a5bd045c45404a138e6cc430b043c10eea845657c3103f26976c52087f1")
addappid(269492, 1, "b82a51c7405544e34f7a198133431c1b3896c04f331fdbad5a3e7dbe20be0105")
