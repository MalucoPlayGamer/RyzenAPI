-- Lua provided by RyzenAPI
-- Game: addappid(1965630)

-- MAIN APPLICATION
addappid(1965630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965631, 1, "8dffdce3da25f2cf851360aa5ebb47480a188f979b28697f9e802f89e2fbaec5")
