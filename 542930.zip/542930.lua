-- Lua provided by RyzenAPI
-- Game: AppID 542930

-- MAIN APPLICATION
addappid(542930)

-- MAIN APP DEPOTS / PACKAGES
addappid(542931, 1, "7d9adab4d4f8a99fb93a064615fd93c53b92eedf76cfa7a803f1570f3de7022f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
