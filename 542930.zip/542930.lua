-- Lua provided by RyzenAPI
-- Game: AppID 542930

-- MAIN APPLICATION
addappid(542930)

-- MAIN APP DEPOTS / PACKAGES
addappid(542931, 1, "7d9adab4d4f8a99fb93a064615fd93c53b92eedf76cfa7a803f1570f3de7022f")

