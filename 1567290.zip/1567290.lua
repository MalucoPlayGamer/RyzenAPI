-- Lua provided by RyzenAPI
-- Game: STORY OF SEASONS: Pioneers of Olive Town - Expansion Pass

-- MAIN APPLICATION
addappid(1567290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567290,0,"6fcc8cf39f5b1e1d7ad584df0bdeb8130e4619bc79964cde3ff93311d208ee76")
