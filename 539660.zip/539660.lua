-- Lua provided by RyzenAPI
-- Game: ChronoClock

-- MAIN APPLICATION
addappid(539660)

-- MAIN APP DEPOTS / PACKAGES
addappid(539661, 1, "066c2a1ca4eedd2dcb4162ae91967118a9fce2c85819b96820b455c9fe9d44d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
