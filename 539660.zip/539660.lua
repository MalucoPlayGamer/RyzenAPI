-- Lua provided by RyzenAPI
-- Game: 539660

-- MAIN APPLICATION
addappid(539660)
-- Game: addappid(539660)

-- MAIN APP DEPOTS / PACKAGES
addappid(539661, 1, "066c2a1ca4eedd2dcb4162ae91967118a9fce2c85819b96820b455c9fe9d44d0")
