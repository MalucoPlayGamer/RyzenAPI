-- Lua provided by RyzenAPI
-- Game: addappid(1996210)

-- MAIN APPLICATION
addappid(1996210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996211, 1, "37c2596fd0cbd838f3aa1486c5e09512640fb2b95050105cbbe27efd0c16f5e1")
addappid(2106850, 0, "9f1fefea1dc204dcba9f7afe31052eded26ff1f8c1637115e5e10c89ea84c5ad")
