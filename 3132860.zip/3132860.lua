-- Lua provided by RyzenAPI
-- Game: 天月麻雀 (Amatsuki Mahjong)

-- MAIN APPLICATION
addappid(3132860)
