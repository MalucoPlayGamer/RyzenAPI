-- Lua provided by SkyAPI 
-- Game: Hide vs. Seek
addappid(616220)
addappid(616221, 1, "c23ce9846264d1b139f09bd608c0ce668f10d9aaf46a5a9acd89e2942ff68349")
