-- Lua provided by RyzenAPI
-- Game: addappid(616220)

-- MAIN APPLICATION
addappid(616220)

-- MAIN APP DEPOTS / PACKAGES
addappid(616221, 1, "c23ce9846264d1b139f09bd608c0ce668f10d9aaf46a5a9acd89e2942ff68349")
