-- Lua provided by RyzenAPI
-- Game: Decarnation Demo

-- MAIN APPLICATION
addappid(2154220)
-- Game: addappid(2154220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154221, 1, "504ff0e640c9aa5bf80183e1fc592ff0a9d804478e2165697d115300e60696fe")
