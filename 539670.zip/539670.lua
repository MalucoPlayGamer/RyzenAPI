-- Lua provided by RyzenAPI 
-- Game: AppID 539670
addappid(539670)
addappid(539671, 1, "86feea0b28fd4ba5e0f78eaaac8359c26466cc7ed273d052d0376d1d96484075")
