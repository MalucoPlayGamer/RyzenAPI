-- Lua provided by RyzenAPI
-- Game: AppID 539670

-- MAIN APPLICATION
addappid(539670)
-- Game: addappid(539670)

-- MAIN APP DEPOTS / PACKAGES
addappid(539671, 1, "86feea0b28fd4ba5e0f78eaaac8359c26466cc7ed273d052d0376d1d96484075")
