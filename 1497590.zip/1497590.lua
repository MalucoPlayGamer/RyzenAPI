-- Lua provided by RyzenAPI 
-- Game: AppID 1497590
addappid(1497590)
addappid(1497591, 1, "6975973aec7215c42383b8d122d407b8e86119361d4777623fda717540674e83")
