-- Lua provided by RyzenAPI
-- Game: AppID 34850

-- MAIN APPLICATION
addappid(34850)

-- MAIN APP DEPOTS / PACKAGES
addappid(34851, 1, "9fccd5e5e15346c7f4a24d06bf9c0c4cb4ef3e2dd48c6b7f473fcca0e1631b05")

