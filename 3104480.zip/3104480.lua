-- Lua provided by RyzenAPI
-- Game: addappid(3104480)

-- MAIN APPLICATION
addappid(3104480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104481, 1, "b3a92e27ebe615045ca1db4b3b722b988d81406d72fbb2a1f0760bff8a639613")
