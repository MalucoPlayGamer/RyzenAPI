-- Lua provided by RyzenAPI
-- Game: MOVERS IN THE WAREHOUSE

-- MAIN APPLICATION
addappid(1751190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751191, 1, "f7f8d896cb51eb9a6716d9df0e23d37bdbc59a0eacaec109f866bc066d00dad3")
