-- Lua provided by RyzenAPI
-- Game: Game: AppID 2894790

-- MAIN APPLICATION
addappid(2894790)
-- Game: addappid(2894790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894791, 1, "7c527d7539859fccc4e7a54db438b7c17b7a0af1aac0056b5ba2d4305ad75845")
