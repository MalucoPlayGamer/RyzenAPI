-- Lua provided by RyzenAPI
-- Game: AppID 2894790

-- MAIN APPLICATION
addappid(2894790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2894791, 1, "7c527d7539859fccc4e7a54db438b7c17b7a0af1aac0056b5ba2d4305ad75845")

