-- Lua provided by RyzenAPI
-- Game: AppID 1866180

-- MAIN APPLICATION
addappid(1866180)
-- Game: addappid(1866180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866181, 1, "eade5f165a6945843f35c96c829e90b9a977e97ae7f81ef4e284ab9517700599")
