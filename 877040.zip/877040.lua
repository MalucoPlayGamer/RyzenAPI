-- Lua provided by RyzenAPI
-- Game: Samurai Wish

-- MAIN APPLICATION
addappid(877040)

-- MAIN APP DEPOTS / PACKAGES
addappid(877041, 1, "800f963fadf16c255d45ae440b8b239b6e3b2676700bd5b32056c718d9de8e34")
addappid(949160, 0, "c8537f3515b19226e558f5c4bcb856c472fd1ea693457c92ad3aa85142d155c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
