-- Lua provided by SkyAPI 
-- Game: Samurai Wish
addappid(877040)
addappid(877041, 1, "800f963fadf16c255d45ae440b8b239b6e3b2676700bd5b32056c718d9de8e34")
addappid(949160, 0, "c8537f3515b19226e558f5c4bcb856c472fd1ea693457c92ad3aa85142d155c3")
