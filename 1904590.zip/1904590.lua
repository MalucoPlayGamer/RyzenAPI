-- Lua provided by RyzenAPI
-- Game: Project Medved

-- MAIN APPLICATION
addappid(1904590)
-- Game: addappid(1904590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904591, 1, "ff80509b8d54ebd3546d7c71492ed5ca0c89d954ba58ad1161c134b080c5bbe3")
