-- Lua provided by RyzenAPI
-- Game: Project Medved

-- MAIN APPLICATION
addappid(1904590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1904591, 1, "ff80509b8d54ebd3546d7c71492ed5ca0c89d954ba58ad1161c134b080c5bbe3")

