-- Lua provided by SkyAPI 
-- Game: LaserShotz
addappid(1590020)
addappid(1590021, 1, "e92d20a6b70558d6070579e930d739785a3df5433d6e769dde7ed1ee1592918b")
