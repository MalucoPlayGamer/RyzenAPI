-- Lua provided by RyzenAPI
-- Game: addappid(3729690)

-- MAIN APPLICATION
addappid(3729690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3729691, 1, "12afc34f1e02884c8e0e26aadc73aacb84179c32e6ccd6b0b62323c88592f2cb")
addappid(3729692, 1, "a3e7c86f95c3de0c0ec88521d128a83ecb34279b4e9e664e9ab1350826abeed0")
