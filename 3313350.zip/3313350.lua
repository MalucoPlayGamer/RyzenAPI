-- Lua provided by RyzenAPI 
-- Game: Popo & Rob
addappid(3313350)
addappid(3313351, 1, "1a1b4ab9179825d3aa2264ff3bece04c3f6b3fa76b094cb58677268067f02f90")
