-- Lua provided by RyzenAPI
-- Game: addappid(3586070)

-- MAIN APPLICATION
addappid(3586070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586071, 1, "c06e0993cf5e60ec98fbce732ab849114804f6dc689044ec9096d34aead53b3e")
