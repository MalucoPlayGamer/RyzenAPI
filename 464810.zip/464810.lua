-- Lua provided by RyzenAPI
-- Game: addappid(464810)

-- MAIN APPLICATION
addappid(464810)

-- MAIN APP DEPOTS / PACKAGES
addappid(464810,0,"10200cb23e8be9fae5cc87d97844d62fcfb16a0fdc0147edc4c3e6f099e35622")
