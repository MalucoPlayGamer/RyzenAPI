-- Lua provided by SkyAPI 
-- Game: AppID 958340
addappid(958340)
addappid(958341, 1, "8c42ec3f39bdec1800bc94e7c4f444052638f8fc3e7ecaba9ac070f82358f946")
