-- Lua provided by RyzenAPI
-- Game: Game: Tuin

-- MAIN APPLICATION
addappid(2124770)
-- Game: addappid(2124770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124771, 1, "4ef18872ab3efee290c02b503c5a7ef2cd631abc8420131659c025d960789c4d")
addappid(2124772, 1, "572989c1dc9101b2592db1cd5f6e8205c88309bb306a456877d3a5a8e228596a")
