-- Lua provided by RyzenAPI
-- Game: Junkyard Simulator: First Car (Prologue 2)

-- MAIN APPLICATION
addappid(1515180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1515181, 1, "91b0543ba6a3cac531bd433c837a5c6ae530118f1a49cc2e5056387b8d7dcf6a")

