-- Lua provided by RyzenAPI
-- Game: Junkyard Simulator: First Car (Prologue 2)

-- MAIN APPLICATION
addappid(1515180)
-- Game: addappid(1515180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515181, 1, "91b0543ba6a3cac531bd433c837a5c6ae530118f1a49cc2e5056387b8d7dcf6a")
