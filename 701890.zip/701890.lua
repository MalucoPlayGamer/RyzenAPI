-- Lua provided by RyzenAPI
-- Game: Game: Starzine

-- MAIN APPLICATION
addappid(701890)
-- Game: addappid(701890)

-- MAIN APP DEPOTS / PACKAGES
addappid(701891, 1, "6428fcba60dd2d6ee22c7442e1ddaaa9704cef11a6dc7206e0a11cc5ccb474c5")
