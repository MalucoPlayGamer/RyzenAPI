-- Lua provided by RyzenAPI
-- Game: Starzine

-- MAIN APPLICATION
addappid(701890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(701891, 1, "6428fcba60dd2d6ee22c7442e1ddaaa9704cef11a6dc7206e0a11cc5ccb474c5")

