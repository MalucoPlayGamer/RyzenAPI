-- Lua provided by RyzenAPI
-- Game: 1555580

-- MAIN APPLICATION
addappid(1555580)
-- Game: addappid(1555580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555581, 1, "3ef528c8e81782a9d8e3896c8e7745a3c1d1fb17a01ac9a55f81206c9d193f63")
