-- Lua provided by SkyAPI 
-- Game: AppID 1555580
addappid(1555580)
addappid(1555581, 1, "3ef528c8e81782a9d8e3896c8e7745a3c1d1fb17a01ac9a55f81206c9d193f63")
