-- Lua provided by RyzenAPI
-- Game: Dandy & Randy DX

-- MAIN APPLICATION
addappid(1651030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651031, 1, "654f361ebe1d1c2068e5d847f1e7dcd9d479bcfe4327b4a1cbbb913cc2971817")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
