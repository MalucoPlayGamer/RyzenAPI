-- Lua provided by RyzenAPI
-- Game: 1651030

-- MAIN APPLICATION
addappid(1651030)
-- Game: addappid(1651030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651031, 1, "654f361ebe1d1c2068e5d847f1e7dcd9d479bcfe4327b4a1cbbb913cc2971817")
