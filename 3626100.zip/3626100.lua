-- Lua provided by SkyAPI 
-- Game: EXIT
addappid(3626100)
addappid(3626101, 1, "8c0eddedde8d00a9976c8d822346b4a9e00e878cc3372a4e017c82545e3d9b5a")
