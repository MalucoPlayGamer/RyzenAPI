-- Lua provided by RyzenAPI
-- Game: Kabounce

-- MAIN APPLICATION
addappid(431930)
addappid(870470)
addappid(1040110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(431931, 1, "2d2249ea5f9361411f66a933a519637942f5529e2a3b56a67767b0ef658c2b00")
addappid(431932, 1, "ba1b073de87859ec00ac819508332215feb5274efa7fc0ea59f8536d62343c64")
addappid(866320, 0, "4962a8dbf94b973cf5720e28441d425b11132e236d8da68217ed2b4e9ba2e3ee")
