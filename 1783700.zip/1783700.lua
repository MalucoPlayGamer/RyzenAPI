-- Lua provided by RyzenAPI
-- Game: 1783700

-- MAIN APPLICATION
addappid(1783700)
-- Game: addappid(1783700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783702,0,"c3f36d4dac3a9bfbc1673bd1e42e2674389ac2b0ed2e1cfbe9ed40023ba4a58e")
addappid(1783703,0,"e3a1f59248842adc5fca68e1562e37dca49c1efc15cae532513f2cc7c4096165")
