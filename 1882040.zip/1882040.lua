-- Lua provided by RyzenAPI
-- Game: Craft Hero

-- MAIN APPLICATION
addappid(1882040)
-- Game: addappid(1882040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882041, 1, "0cb8c33740a2b7fcc8033347c1d56c4a368ae5cf4170d4d55de4a94a98af4448")
addappid(2237730, 0, "d40a6444d1f478c7a856a27d5895ef0bc16741947bf72fbdf416f76e07660496")
