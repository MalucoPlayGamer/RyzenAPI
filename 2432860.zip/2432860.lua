-- Lua provided by SkyAPI 
-- Game: MENACE
addappid(2432860)
addappid(2432861, 1, "dd46113d103c531a01255582fb9c8eccc8b1a0efca01b2852de83796b58d0002")
