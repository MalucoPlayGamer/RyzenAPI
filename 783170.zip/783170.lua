-- Lua provided by RyzenAPI
-- Game: AppID 783170

-- MAIN APPLICATION
addappid(783170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(783171, 1, "ba1ab6633e2b86104da96f113a58f7ed61581e0ec70f43976ef9dad4661f33e3")

