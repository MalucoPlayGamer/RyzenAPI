-- Lua provided by RyzenAPI
-- Game: Space Station Alpha

-- MAIN APPLICATION
addappid(341930)
-- Game: addappid(341930)

-- MAIN APP DEPOTS / PACKAGES
addappid(341931, 1, "b2bf6b0bfaee36e1dc55e7a2271ca63e1d9303fd0477179a6aca67a5da502c93")
addappid(341932, 1, "f57ca21c453f43325804d083d221e6e25aa13a4a6857db5d477d3b6563fef6b1")
addappid(341933, 1, "24a3620e39ba45656045d43e160b4bcb9a76be82aad197b85f56422bc1be36d0")
