-- Lua provided by RyzenAPI
-- Game: Game: Mecha Legends Demo

-- MAIN APPLICATION
addappid(3491320)
-- Game: addappid(3491320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491321, 1, "f8f4dfaf3ee0235cd8087e98cd232269fca8efbbe18e34edb420cb7fb87a76eb")
