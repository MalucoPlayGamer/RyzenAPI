-- Lua provided by SkyAPI 
-- Game: AppID 486160
addappid(486160)
addappid(486161, 1, "112ef867caffeb549215738de9e8f792778b70455efc189b1932f2bf273a9413")
