-- Lua provided by RyzenAPI
-- Game: Berserk: The Cataclysm

-- MAIN APPLICATION
addappid(486160)

-- MAIN APP DEPOTS / PACKAGES
addappid(486161, 1, "112ef867caffeb549215738de9e8f792778b70455efc189b1932f2bf273a9413")
