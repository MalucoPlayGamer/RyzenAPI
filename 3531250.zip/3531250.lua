-- Lua provided by RyzenAPI
-- Game: Kid Mystic: Enchanted Edition

-- MAIN APPLICATION
addappid(3531250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3531251, 1, "9508c86e1b88d235e47eaea91c77170e5ef027e074d98416c4672262c4a0e018")
addappid(3531252, 1, "8b4de675987abd4068561c0be32ec7ed77a4031471086eb8938a18e6257677bb")
addappid(3531253, 1, "37d0816439bc4e795c057bb51a43cecaba356c296ce2ad345f434d9ea8400122")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
