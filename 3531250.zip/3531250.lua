-- Lua provided by RyzenAPI 
-- Game: Kid Mystic: Enchanted Edition
addappid(3531250)
addappid(3531251, 1, "9508c86e1b88d235e47eaea91c77170e5ef027e074d98416c4672262c4a0e018")
addappid(3531252, 1, "8b4de675987abd4068561c0be32ec7ed77a4031471086eb8938a18e6257677bb")
addappid(3531253, 1, "37d0816439bc4e795c057bb51a43cecaba356c296ce2ad345f434d9ea8400122")
