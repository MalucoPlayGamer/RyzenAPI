-- Lua provided by RyzenAPI
-- Game: TERA - Action MMORPG

-- MAIN APPLICATION
addappid(212740)
addappid(228985)
addappid(228988)

-- MAIN APP DEPOTS / PACKAGES
addappid(212741, 1, "6875c6e6c292857e321428f368872ddd6e6f3ac693d412eecd60c74c5e4e55a7")
