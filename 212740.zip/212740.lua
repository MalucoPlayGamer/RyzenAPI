-- Lua provided by RyzenAPI
-- Game: TERA - Action MMORPG

-- MAIN APPLICATION
addappid(212740)
addappid(228985)
addappid(228988)

-- MAIN APP DEPOTS / PACKAGES
addappid(212741, 1, "6875c6e6c292857e321428f368872ddd6e6f3ac693d412eecd60c74c5e4e55a7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(212751)
addappid(212752)
addappid(212753)
addappid(583680)
addappid(583681)
addappid(583690)
addappid(583691)
addappid(614680)
addappid(640190)
addappid(720440)
addappid(751850)
addappid(1400540)
