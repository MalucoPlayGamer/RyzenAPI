-- Lua provided by SkyAPI 
-- Game: Alex's Tunnel
addappid(2356300)
addappid(2356301, 1, "8415c459b12a5ffd925b13f4f4e83219cf58f486e0c4f51f5f664989a1ff6c3a")
