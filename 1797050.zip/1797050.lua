-- Lua provided by RyzenAPI
-- Game: Game: Age of Empires IV Official Soundtrack

-- MAIN APPLICATION
addappid(1797050)
-- Game: addappid(1797050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797051, 1, "0f7adb348c6d6db2832152597bb06068834bb94a6ce9d643683e2cb5e0bb5411")
addappid(1797052, 1, "a29caf90b23daa3fa37c4c91f71c2d11df111d1febb9b535914f4b395788ea23")
