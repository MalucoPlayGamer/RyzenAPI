-- Lua provided by RyzenAPI
-- Game: Lust Academy Season 2 Demo

-- MAIN APPLICATION
addappid(2166940)
-- Game: addappid(2166940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166941, 1, "9cd963f81cb6207ff45bf0de72d3f493385111b0f1f5eb72ba1290e16d28b080")
