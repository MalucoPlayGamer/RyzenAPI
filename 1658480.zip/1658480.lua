-- Lua provided by RyzenAPI
-- Game: EQDRIVE.IO

-- MAIN APPLICATION
addappid(1658480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658481, 1, "1e6c82793ec3c9d11b2491e81ae8ce338ecaf6e610bbd7f5c7fd274a86bbd216")

