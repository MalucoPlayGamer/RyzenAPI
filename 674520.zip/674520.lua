-- Lua provided by RyzenAPI
-- Game: AppID 674520

-- MAIN APPLICATION
addappid(674520)

-- MAIN APP DEPOTS / PACKAGES
addappid(674521, 1, "c30739dde3d3165392ce9bf6be998ca1950010506a270e975ba1ee214186baf8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
