-- Lua provided by RyzenAPI
-- Game: addappid(674520)

-- MAIN APPLICATION
addappid(674520)

-- MAIN APP DEPOTS / PACKAGES
addappid(674521, 1, "c30739dde3d3165392ce9bf6be998ca1950010506a270e975ba1ee214186baf8")
