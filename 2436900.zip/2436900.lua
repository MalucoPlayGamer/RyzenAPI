-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Friedrichshafen

-- MAIN APPLICATION
addappid(2436900)
-- Game: addappid(2436900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436900,0,"1305d4e6681200261e31e788740f266f224e577c1041f1f1e364e5d6c0c2990d")
