-- Lua provided by RyzenAPI
-- Game: Game: Hypnosis Prison

-- MAIN APPLICATION
addappid(1995580)
-- Game: addappid(1995580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995581, 1, "df01623b9d0088b31517dde31dd2bc2223372b06c348b7c0d52045e8a3728864")
