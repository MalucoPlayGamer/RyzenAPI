-- Lua provided by RyzenAPI
-- Game: Dream #46

-- MAIN APPLICATION
addappid(2563300)
-- Game: addappid(2563300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563302,0,"5447a4938f52476fccf5237ffc899951c0b18896c108e6d5a52806a7a99ce7c9")
