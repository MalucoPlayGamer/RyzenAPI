-- Lua provided by RyzenAPI
-- Game: Game: AppID 2956300

-- MAIN APPLICATION
addappid(2956300)
-- Game: addappid(2956300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956301, 1, "45e87269cc2f27eda49d1c31ef426014e40e6aee0a3eb7edcaf5078cd84cfb81")
