-- Lua provided by RyzenAPI
-- Game: Coin-Op Vice Demo

-- MAIN APPLICATION
addappid(2956300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956301, 1, "45e87269cc2f27eda49d1c31ef426014e40e6aee0a3eb7edcaf5078cd84cfb81")
