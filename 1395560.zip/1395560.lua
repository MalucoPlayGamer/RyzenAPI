-- Lua provided by RyzenAPI 
-- Game: Kandidatos
addappid(1395560)
addappid(1395561, 1, "47ef339c061085346f4b434c22b1372fd31750b00495f74ed5aad1e685e720b5")
