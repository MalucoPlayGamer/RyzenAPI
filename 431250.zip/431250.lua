-- Lua provided by RyzenAPI
-- Game: Mushroom Wars

-- MAIN APPLICATION
addappid(431250)

-- MAIN APP DEPOTS / PACKAGES
addappid(431251, 1, "6c09cd5e73bb3d553f0c94bb91541d874f6917378b06a948f49160fd577f3ebe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
