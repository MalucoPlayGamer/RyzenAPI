-- Lua provided by RyzenAPI 
-- Game: Mushroom Wars
addappid(431250)
addappid(431251, 1, "6c09cd5e73bb3d553f0c94bb91541d874f6917378b06a948f49160fd577f3ebe")
