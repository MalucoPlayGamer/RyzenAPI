-- Lua provided by SkyAPI 
-- Game: Poly Memory: Primates
addappid(2098210)
addappid(2098211, 1, "b80c2ea773d22415e4c909bf987b01dd2d640ac8ed16e18c6960a09ea9ca7233")
