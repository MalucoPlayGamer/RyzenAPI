-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Additional Music "Memories of Aonohara - Touken Ranbu Warriors"

-- MAIN APPLICATION
addappid(1912051)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912051,0,"17cbe63bf1ab2f84c2d5de65541846cf7e569dfe68ea34ca7bebbc4542ed4ed1")

