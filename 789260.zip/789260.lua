-- Lua provided by RyzenAPI
-- Game: Unmoor

-- MAIN APPLICATION
addappid(789260)

-- MAIN APP DEPOTS / PACKAGES
addappid(789261, 1, "b4c106f886d19ba9263f3368b02b78ff1da0e955c042e3d49719cdf2d1b42c21")
