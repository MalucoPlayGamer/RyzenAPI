-- Lua provided by RyzenAPI
-- Game: Painkiller: Redemption

-- MAIN APPLICATION
addappid(65560)

-- MAIN APP DEPOTS / PACKAGES
addappid(65561, 1, "5ad9c45da08b0a2613cdba61aaa71075c65b48990b80cf1be5858c54ea798f87")
addappid(65562, 1, "9d1232ef78c300267a543fc2eaaf4f429d2c7220afad690eb7a049d62d9b71cb")
