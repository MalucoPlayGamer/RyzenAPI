-- Lua provided by RyzenAPI
-- Game: Stick and Balls

-- MAIN APPLICATION
addappid(2531410)
-- Game: addappid(2531410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531412,0,"7828248e301944b636cfbf3032edb93a3b5c765136cd8e421f8d96fc78de7a5c")
addappid(2531413,0,"ab9581f2cffefc4ef771905a8a07860942796570d1eecaa611b936bde785c8d1")
addappid(2531414,0,"c07dcfebe8cfe3d256262ec197022708a162a52d6fc416cbdf396eb03df3259c")
