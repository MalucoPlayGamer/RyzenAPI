-- Lua provided by RyzenAPI
-- Game: Garbage Truck Simulator

-- MAIN APPLICATION
addappid(2241020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241021, 1, "1175de43239cfd4f01be6548b258973ff7512a3224787913270d152a7a70ea1e")
