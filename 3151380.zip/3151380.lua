-- Lua provided by RyzenAPI
-- Game: Small Spaces

-- MAIN APPLICATION
addappid(3151380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3151381, 1, "aa66b037526fe38a79372399ea40d453401359c23e4000592e23d8427985ce3b")

