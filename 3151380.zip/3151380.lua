-- Lua provided by RyzenAPI 
-- Game: Small Spaces
addappid(3151380)
addappid(3151381, 1, "aa66b037526fe38a79372399ea40d453401359c23e4000592e23d8427985ce3b")
