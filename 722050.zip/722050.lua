-- Lua provided by RyzenAPI
-- Game: Game: Dean Daimon

-- MAIN APPLICATION
addappid(722050)
-- Game: addappid(722050)

-- MAIN APP DEPOTS / PACKAGES
addappid(722051, 1, "2934505250f576d75d5e4d7bb2b589ebe74061c6862fdee9e4d7b8e1c5873ecc")
