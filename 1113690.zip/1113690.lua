-- Lua provided by SkyAPI 
-- Game: Senna and the Forest
addappid(1113690)
addappid(1113691, 1, "034fcf88637f070a68d0cabdecd45fbf2a12b997a66e2c4edc508b2c7a80c9b1")
addappid(1113692, 1, "f9ec64897bb5771f92c747aee50c9e6826c14ba129a22275ce56cace8135dfb8")
