-- Lua provided by RyzenAPI
-- Game: Towns Battleground

-- MAIN APPLICATION
addappid(1859260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859261, 1, "9a9f2909d26a5f4c9e17055718be898d5c5be0a832bc7330fd312c92e57b3d4f")

