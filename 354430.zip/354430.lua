-- Lua provided by RyzenAPI
-- Game: STAR WARS™: X-Wing Special Edition

-- MAIN APPLICATION
addappid(354430)

-- MAIN APP DEPOTS / PACKAGES
addappid(354431, 1, "8165629cd66d8bb06540b1b4c6b9415bcc7946c2aab39d2f26bcff593057b143")
addappid(354434, 1, "d95fde62fef5121f3ee2d4269641e8a526f850cb28339921ba996fc0a514d990")

