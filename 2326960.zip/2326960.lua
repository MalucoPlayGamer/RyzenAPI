-- Lua provided by RyzenAPI
-- Game: Battle of Hořice 1423

-- MAIN APPLICATION
addappid(2326960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326961, 1, "7088ad993360a1e549fc7890c4ff252734e5791bd9485e900cb61a30171e33e4")

