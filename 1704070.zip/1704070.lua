-- Lua provided by RyzenAPI
-- Game: Get Stuffed!

-- MAIN APPLICATION
addappid(1704070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704071, 1, "d286a0f10803f698747e1932cb792af65e7b2308db8ecb92cb809ba71754b6ec")

