-- Lua provided by RyzenAPI
-- Game: Game: AppID 504240

-- MAIN APPLICATION
addappid(504240)
-- Game: addappid(504240)

-- MAIN APP DEPOTS / PACKAGES
addappid(504241, 1, "74e84355f2c98a9202c9d261c9287daa5cb7ae1bdbfc69e6b0796cac4ad5c633")
