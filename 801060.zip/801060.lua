-- Lua provided by RyzenAPI
-- Game: 801060

-- MAIN APPLICATION
addappid(801060)
-- Game: addappid(801060)

-- MAIN APP DEPOTS / PACKAGES
addappid(801061, 1, "689ce0d5f4e85184001810c10b604ef2a01cab9953e63932d99267ae815eb405")
