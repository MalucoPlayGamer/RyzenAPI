-- Lua provided by RyzenAPI 
-- Game: AppID 801060
addappid(801060)
addappid(801061, 1, "689ce0d5f4e85184001810c10b604ef2a01cab9953e63932d99267ae815eb405")
