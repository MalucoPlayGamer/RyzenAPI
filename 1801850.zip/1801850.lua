-- Lua provided by RyzenAPI
-- Game: Cats War

-- MAIN APPLICATION
addappid(1801850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1801851, 1, "7bdfd9d00fd799bc2fa60c6e203f6fd929bfb8acd59b401c024e2f0c739a77a5")

