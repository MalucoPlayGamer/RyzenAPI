-- Lua provided by SkyAPI 
-- Game: Cats War
addappid(1801850)
addappid(1801851, 1, "7bdfd9d00fd799bc2fa60c6e203f6fd929bfb8acd59b401c024e2f0c739a77a5")
