-- Lua provided by RyzenAPI
-- Game: Dragon Bobby - The Story of a Life

-- MAIN APPLICATION
addappid(2656930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656931, 1, "99e5cc12cf6117e06bcddd6caacbc0d68f808445dd79cce6a1c1497f01545ed3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
