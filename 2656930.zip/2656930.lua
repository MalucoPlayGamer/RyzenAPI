-- Lua provided by RyzenAPI
-- Game: Dragon Bobby - The Story of a Life

-- MAIN APPLICATION
addappid(2656930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656931, 1, "99e5cc12cf6117e06bcddd6caacbc0d68f808445dd79cce6a1c1497f01545ed3")
