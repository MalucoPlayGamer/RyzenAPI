-- Lua provided by SkyAPI 
-- Game: AppID 217060
addappid(217060)
addappid(217061, 1, "4376ec32edc919cb7e2208ae5c48b7b2764666fe32585f5ca65f65dc1a38ad4f")
addappid(217063, 1, "5509070a40a6b1601fde1d842c967d93be76cf39584098a2a33edcf564391aaa")
