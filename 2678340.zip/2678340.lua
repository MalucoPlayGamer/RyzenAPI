-- Lua provided by RyzenAPI
-- Game: 2678340

-- MAIN APPLICATION
addappid(2678340)
-- Game: addappid(2678340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678341, 1, "d9552fa59105b679e985c76d416ae9e0f45a0e232ffb20b483689bc23504e55a")
