-- Lua provided by RyzenAPI
-- Game: EverRail

-- MAIN APPLICATION
addappid(4134600)
addappid(4917410)

-- MAIN APP DEPOTS / PACKAGES
addappid(4134601,0,"43c310a944fbe2450e2fb4c994ce79154098c611d4d4bbe8c3bf15e75e69a814")

