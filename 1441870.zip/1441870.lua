-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1441870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441870,0,"98a91cfeb84ba4c6a1d3e7b0839aa0916e7bbe867f94a1abead46f304c94a517")
