-- 1490020's Lua and Manifest Created by Hubcap Manifest
-- TIC-TAC: Twelve o'clock
-- Created: August 19, 2026 at 12:03:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1490020, 1, "97f75a78ba8a58b570cff739f5bd3fa6a1be76fd489cf5810564d83fecb96a94") -- TIC-TAC: Twelve o'clock
-- MAIN APP DEPOTS
addappid(1490021, 1, "b8bb2099f50072393e5090a8894de6146dc5ded6ba2c7567675d61aa548de1cf") -- Depot 1490021
setManifestid(1490021, "9117858223665874013", 12443930470)
-- DLCS WITH DEDICATED DEPOTS
-- TIC-TAC Twelve oclock - Supporter Pack (AppID: 4922870)
addappid(4922870)
addappid(4922870, 1, "38358c856200f842d4d071d4bb5d4cbe97af348150b2537f6a0099d7f9562c94") -- TIC-TAC Twelve oclock - Supporter Pack - Depot 4922870
setManifestid(4922870, "7319822103960257669", 45966968)