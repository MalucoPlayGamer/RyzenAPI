-- Lua provided by RyzenAPI
-- Game: TIC-TAC: Twelve o'clock

-- MAIN APPLICATION
addappid(4922870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490020, 1, "97f75a78ba8a58b570cff739f5bd3fa6a1be76fd489cf5810564d83fecb96a94") -- TIC-TAC: Twelve o'clock
addappid(1490021, 1, "b8bb2099f50072393e5090a8894de6146dc5ded6ba2c7567675d61aa548de1cf") -- Depot 1490021
addappid(4922870, 1, "38358c856200f842d4d071d4bb5d4cbe97af348150b2537f6a0099d7f9562c94") -- TIC-TAC Twelve oclock - Supporter Pack - Depot 4922870

