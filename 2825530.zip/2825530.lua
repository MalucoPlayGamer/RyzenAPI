-- Lua provided by RyzenAPI 
-- Game: Beholder: Conductor
addappid(2825530)
addappid(2825531, 1, "9c431873f776d9053638ad83bb819f7f4b0333e29467bca05809f8ca19e1aec9")
