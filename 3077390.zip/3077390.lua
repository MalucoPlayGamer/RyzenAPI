-- Lua provided by RyzenAPI 
-- Game: MotoGP™25
addappid(3077390)
addappid(3077391, 1, "ee460f4a0c4fdcfbdd31a8e7d084bd72dab87c59bde5939c020cc9c2da9ba48b")
