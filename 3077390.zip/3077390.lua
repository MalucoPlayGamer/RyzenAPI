-- Lua provided by RyzenAPI
-- Game: MotoGP™25

-- MAIN APPLICATION
addappid(3077390)
addappid(3374650) -- MotoGP™25 - Off Road Helmets Pack
addappid(3374660) -- MotoGP™25 - Iconic Liveries Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3077391, 1, "ee460f4a0c4fdcfbdd31a8e7d084bd72dab87c59bde5939c020cc9c2da9ba48b")

