-- Lua provided by RyzenAPI
-- Game: addappid(2498680)

-- MAIN APPLICATION
addappid(2498680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498681, 1, "f48394e30518b15564ed7d0169406b7232a7ef25a50a5d7bece5f5e1bdec8c5a")
