-- Lua provided by SkyAPI 
-- Game: Rooms: The Main Building
addappid(304500)
addappid(304501, 1, "31dc1af17c36fa98b187532e5bfa1f15fb8a20b8b47e57a95d2e3d0f03505f14")
addappid(304502, 1, "5d593af9502487e1796629be3acee592b6cb939c88fb0ca548fdd9baa21bd1cf")
