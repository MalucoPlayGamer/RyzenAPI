-- Lua provided by RyzenAPI 
-- Game: JR EAST Train Simulator: Yokosuka Line (Kurihama to Tokyo) Series E217
addappid(3280130)
addappid(3280131, 1, "4d87325309a7a72f58a7b31964266411da7e49de0ecda62bbe34e8d5b1ff32b3")
addappid(3280132, 1, "6a44ce73c83a16c9ecfee5ba3910e2e485415f970df9fce2c12df6d7bcb953a9")
addappid(3280133, 1, "f9a6ec763d4a171ef0894a441321a5aab59c8fa6e8941a29f9a1c7236ae184a2")
addappid(3280134, 1, "17fe0244944bf45a1695c4031e0f8f9e700c776c865c4ef0287c3e8d873fdc63")
