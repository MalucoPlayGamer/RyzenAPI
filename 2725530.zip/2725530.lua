-- Lua provided by RyzenAPI
-- Game: Eclipsium Demo

-- MAIN APPLICATION
addappid(2725530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725531, 1, "c78e4feb77be960c86401185b4eb9d6558e650d574f44f8001f535717aa1a124")
