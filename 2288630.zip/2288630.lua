-- Lua provided by RyzenAPI
-- Game: Taiko no Tatsujin: Rhythm Festival

-- MAIN APPLICATION
addappid(2288630)
-- Game: addappid(2288630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288631, 1, "6247e146b14ff88aa5a155f90b42e263de32e1c0b1f6d0a681454ef040c60530")
