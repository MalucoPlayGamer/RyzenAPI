-- Lua provided by RyzenAPI
-- Game: addappid(1210030)

-- MAIN APPLICATION
addappid(1210030)
addappid(1210031)
addappid(1210032)
addappid(1320771)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320770,0,"3f6aab0d36f98e333c3cb2d7c537ed014f469c7169357f62aa2e874deb325941")
