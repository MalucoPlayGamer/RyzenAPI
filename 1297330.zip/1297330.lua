-- Lua provided by SkyAPI 
-- Game: AppID 1297330
addappid(1297330)
addappid(1297331, 1, "b28ca358dce4898e8d3a999039cb32c8867f1923c47796600ad809c054508b0f")
