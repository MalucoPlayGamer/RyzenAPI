-- Lua provided by RyzenAPI
-- Game: Game: AppID 1297330

-- MAIN APPLICATION
addappid(1297330)
-- Game: addappid(1297330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297331, 1, "b28ca358dce4898e8d3a999039cb32c8867f1923c47796600ad809c054508b0f")
