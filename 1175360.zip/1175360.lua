-- Lua provided by RyzenAPI
-- Game: 1175360

-- MAIN APPLICATION
addappid(1175360)
addappid(2685580)
-- Game: addappid(1175360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175361, 1, "474762a0b0e44e77480374cdb172c736b3b987742cdf39a80149dc65ad9b6696")
