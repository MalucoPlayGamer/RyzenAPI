-- Lua provided by RyzenAPI
-- Game: 2650940

-- MAIN APPLICATION
addappid(2650940)
-- Game: addappid(2650940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650940,0,"2ee563f305ff6a7bcd602f5d27832ac35220ac56b23970a111cb73680772cce9")
