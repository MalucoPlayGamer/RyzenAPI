-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Rolling Stones - "Live by the Sword"

-- MAIN APPLICATION
addappid(2650940)
-- Game: addappid(2650940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650940,0,"2ee563f305ff6a7bcd602f5d27832ac35220ac56b23970a111cb73680772cce9")
