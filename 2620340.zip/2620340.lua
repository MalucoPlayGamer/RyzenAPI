-- Lua provided by RyzenAPI
-- Game: Bounty City: 3-Way Battle

-- MAIN APPLICATION
addappid(2620340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620341, 1, "ba007482f18e524fa99a67643c92435a6b078182139ac6aa2a74b8c141c87253")
