-- Lua provided by RyzenAPI
-- Game: Bikour!

-- MAIN APPLICATION
addappid(780080)

-- MAIN APP DEPOTS / PACKAGES
addappid(780081, 1, "0ddb630a57f77db9f6ca7768d6c4b17bb1567bc9405e60a4ddfadb539d68c1d0")

