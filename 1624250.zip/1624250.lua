-- Lua provided by RyzenAPI
-- Game: Drift King Demo

-- MAIN APPLICATION
addappid(1624250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624252,0,"030f484b3c1d869c05033ac6c19cc3faa112ca0a3f3e13a64197309f9edf5c2f")

