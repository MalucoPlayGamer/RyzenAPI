-- Lua provided by RyzenAPI
-- Game: Pro 11 - Football Manager Game

-- MAIN APPLICATION
addappid(844960)

