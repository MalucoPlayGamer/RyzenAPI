-- Lua provided by SkyAPI 
-- Game: Fittest Fire
addappid(2537510)
addappid(2537511, 1, "59dc05a7d997c6f6f967e95792f00d283814a962cf1959cbee206121b0b0c831")
