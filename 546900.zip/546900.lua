-- Lua provided by RyzenAPI
-- Game: Fear Effect Sedna

-- MAIN APPLICATION
addappid(546900)
addappid(817100)
-- Game: addappid(546900)

-- MAIN APP DEPOTS / PACKAGES
addappid(546901, 1, "fe9f88e5c3828de19ad242a3e4e447fb07945d32bf8923002683de2bff19d610")
