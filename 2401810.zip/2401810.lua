-- Lua provided by RyzenAPI
-- Game: 2401810

-- MAIN APPLICATION
addappid(2401810)
-- Game: addappid(2401810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401811, 1, "fd5dc73eb0a1cc550311b2176977a99e0cb9fd33d07328540dd727bfd28c3175")
