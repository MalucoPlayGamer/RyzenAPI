-- Lua provided by RyzenAPI
-- Game: AppID 355170

-- MAIN APPLICATION
addappid(355170)
-- Game: addappid(355170)

-- MAIN APP DEPOTS / PACKAGES
addappid(355171, 1, "9b66de6c2b93e1f07dae439c845c9d8c3bdb42c7b2e92382b8af15850357d9f2")
addappid(355172, 1, "2caef1aa0fc06ffc7ec19b690e4e2fcebcc0f81c2097c99a97c6d99d551cb1b7")
addappid(355174, 1, "cd7f22b1983fd4d98d65a61284df95491a583f3b83f104583f9c596c2685a607")
addappid(355176, 1, "abd912415e04fa3a1be87ddcab4a03e8c7ec84fba041b2cdff861a9d7bf4a26a")
