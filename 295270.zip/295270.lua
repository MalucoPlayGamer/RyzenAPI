-- Lua provided by RyzenAPI
-- Game: Football Manager 2015

-- MAIN APPLICATION
addappid(295270)
addappid(334340)
addappid(355200)
addappid(355201)
addappid(355202)
addappid(355203)
addappid(355204)
addappid(355205)
addappid(355206)
addappid(355207)
addappid(355208)
addappid(355209)
addappid(355210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(295271, 1, "543a593eddf623f0c94ba165e194328d000139643cc725caafa5077f597e7b90")
addappid(295272, 1, "9e08fedc6a05178007f151015fce79832d28f6764f115f92ac7288f7d654368b")
addappid(295273, 1, "acb847d3b85b28a6692ab3d90d40c9aace981fe8c8835c75c37c144ef907afd7")
addappid(295274, 1, "a64193e246039afd3750aa8ee5ec7f7d179bcf3562eacf63063bcdeb0d86ba01")
addappid(295275, 1, "b4fd690761e2307ded2e276f279c17fb73e2f4b410817ebf161fe3381860324f")
addappid(295276, 1, "7061a2b14d27ac48808aa46c00fae42ad75b3f9c80629214e833be3e6d24fe74")
addappid(295277, 1, "2400ada38962b1c0905d0f211dbba53a72ba13ef1989094d57343eca1b942ba0")
addappid(295278, 1, "1460a8925e07c8a4d7130e774c08ec7b5713ed2e07032c3f615232094f6cd7ae")
