-- Lua provided by RyzenAPI
-- Game: 2704580

-- MAIN APPLICATION
addappid(2704580)
-- Game: addappid(2704580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704583,0,"950e0c91a2a7c5f9a62ec57472497eaf1624bdec5b473435b4ad936c02965a0f")
