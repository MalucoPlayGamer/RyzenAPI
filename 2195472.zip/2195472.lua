-- Lua provided by RyzenAPI
-- Game: 2195472

-- MAIN APPLICATION
addappid(2195472)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195472,0,"805dcad91a8ef9c8e30ad210503ef1ef13f2e6be6ecce678e2d12aae74de82ca")
