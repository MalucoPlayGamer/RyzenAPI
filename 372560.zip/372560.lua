-- Lua provided by RyzenAPI
-- Game: Tanita: A Plasticine Dream

-- MAIN APPLICATION
addappid(372560)

-- MAIN APP DEPOTS / PACKAGES
addappid(372561, 1, "2c5e88510f9f683cc93e6626d7f4964b917ebe1a2c72087129677eaccc714f58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
