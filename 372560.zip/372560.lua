-- Lua provided by RyzenAPI
-- Game: Tanita: A Plasticine Dream

-- MAIN APPLICATION
addappid(372560)

-- MAIN APP DEPOTS / PACKAGES
addappid(372561, 1, "2c5e88510f9f683cc93e6626d7f4964b917ebe1a2c72087129677eaccc714f58")

