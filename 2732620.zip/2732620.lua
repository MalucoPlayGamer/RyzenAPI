-- Lua provided by RyzenAPI
-- Game: Game: Eternal gem

-- MAIN APPLICATION
addappid(2732620)
-- Game: addappid(2732620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732621, 1, "b8bdef6bd8ca12edad834440322396edb300ad54bcc6c440000fcba14da43bde")
