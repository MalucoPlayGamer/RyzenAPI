-- Lua provided by RyzenAPI
-- Game: AppID 2151750

-- MAIN APPLICATION
addappid(2151750)
-- Game: addappid(2151750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151751, 1, "cff424aaad5b1846969d2cb58f858f74c68b69425edc076acaa576fb5f6d3b73")
