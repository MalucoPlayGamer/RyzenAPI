-- Lua provided by RyzenAPI
-- Game: Selfish Heroes Playtest

-- MAIN APPLICATION
addappid(3317160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317161, 1, "1e30ed07a56bc66525dde1fd40cd974c8ed353aba6942f1deda968df37a845e0")
