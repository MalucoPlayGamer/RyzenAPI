-- Lua provided by RyzenAPI
-- Game: Game: 幻恋逢星之时

-- MAIN APPLICATION
addappid(2081240)
-- Game: addappid(2081240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081241, 1, "e149a04cf78c79a27bd719191183c5cbf3ecfc28b8ab07d82826ff0600452d81")
