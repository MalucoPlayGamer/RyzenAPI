-- Lua provided by SkyAPI 
-- Game: 幻恋逢星之时
addappid(2081240)
addappid(2081241, 1, "e149a04cf78c79a27bd719191183c5cbf3ecfc28b8ab07d82826ff0600452d81")
