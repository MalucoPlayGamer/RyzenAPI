-- Lua provided by SkyAPI 
-- Game: AppID 518040
addappid(518040)
addappid(518041, 1, "50fdab2fc60117beb3b8f0535ac72338a4c96717bcd6dd531cc89309e2fb2777")
