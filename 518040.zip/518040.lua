-- Lua provided by RyzenAPI
-- Game: Volleyball Unbound

-- MAIN APPLICATION
addappid(518040)

-- MAIN APP DEPOTS / PACKAGES
addappid(518041, 1, "50fdab2fc60117beb3b8f0535ac72338a4c96717bcd6dd531cc89309e2fb2777")
