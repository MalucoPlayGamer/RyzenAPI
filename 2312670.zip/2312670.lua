-- Lua provided by RyzenAPI
-- Game: The Cosmic Wheel Sisterhood Demo

-- MAIN APPLICATION
addappid(2312670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312671, 1, "535a98df5e267c3236fd2765798765d155697a7c42c6a0e207f092dcb4917de7")

