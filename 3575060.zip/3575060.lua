-- Lua provided by RyzenAPI
-- Game: Game: Wanderstop Soundtrack

-- MAIN APPLICATION
addappid(3575060)
-- Game: addappid(3575060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575061, 1, "ed683158329cd3c6867d4e4c4afbc5a69ac734ac219f4f55122da7af94ad3726")
