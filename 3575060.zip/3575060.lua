-- Lua provided by SkyAPI 
-- Game: Wanderstop Soundtrack
addappid(3575060)
addappid(3575061, 1, "ed683158329cd3c6867d4e4c4afbc5a69ac734ac219f4f55122da7af94ad3726")
