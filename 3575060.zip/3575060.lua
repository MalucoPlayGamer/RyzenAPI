-- Lua provided by RyzenAPI
-- Game: addappid(3575060)

-- MAIN APPLICATION
addappid(3575060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575061, 1, "ed683158329cd3c6867d4e4c4afbc5a69ac734ac219f4f55122da7af94ad3726")
