-- Lua provided by RyzenAPI
-- Game: DRIFT ISLAND Playtest

-- MAIN APPLICATION
addappid(3116850)
-- Game: addappid(3116850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116851, 1, "40b04f3e5fa7a13766061718bd55f1489d2143ab96b0f0ec29d2fd7ebd7063f1")
