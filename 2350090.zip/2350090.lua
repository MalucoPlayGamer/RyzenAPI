-- Lua provided by RyzenAPI
-- Game: Game: Fantasy Fighters

-- MAIN APPLICATION
addappid(2350090)
-- Game: addappid(2350090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350091, 1, "207b9ce62b8b1e373fd76d99cc9cd367cad83afa799f16d169e76b3d6ceaa36c")
