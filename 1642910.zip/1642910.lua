-- Lua provided by RyzenAPI
-- Game: 1642910

-- MAIN APPLICATION
addappid(1642910)
-- Game: addappid(1642910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642910,0,"c3a74a94f7aa8e7a905fccd0d1386432951c983091ddc0e51487a61afb87b238")
