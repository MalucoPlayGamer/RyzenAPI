-- Lua provided by RyzenAPI
-- Game: Unearthing Colossal

-- MAIN APPLICATION
addappid(428590)

-- MAIN APP DEPOTS / PACKAGES
addappid(428591, 1, "6535cccc674acdc3bd92d045ac03a6989625479adc0148cfa8c7b26e01617597")
addappid(428592, 1, "c1fe82533e2f692fb59fc07f225cfc9860304c4eba963e4213987e82abfe2570")
addappid(428593, 1, "9b8ca3cae9aad23ebcd3e64a9a2228a43696512f9f16a87f7c919c1e331befca")
addappid(545120, 0, "110d4d05e141f12e1681f52603116382bf2d26f73a3751a4fe89ce3c02ca351a")
