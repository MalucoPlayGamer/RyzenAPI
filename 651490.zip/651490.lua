-- Lua provided by RyzenAPI
-- Game: Game: No Longer Home

-- MAIN APPLICATION
addappid(651490)
-- Game: addappid(651490)

-- MAIN APP DEPOTS / PACKAGES
addappid(651491, 1, "69d7abf812ee10e6bcdcd66e24999877fd1c8066948c8625a2e6d863a4e79bb5")
