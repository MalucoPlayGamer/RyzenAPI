-- Lua provided by RyzenAPI
-- Game: RIDE 4

-- MAIN APPLICATION
addappid(1259980) -- RIDE 4
addappid(1365020) -- RIDE 4 - Credits Multiplier
addappid(1365050) -- RIDE 4 - European Bikes Pack
addappid(1365060) -- RIDE 4 - Japanese Bikes Pack
addappid(1365070) -- RIDE 4 - Valencia Pack
addappid(1365080) -- RIDE 4 - Bonus Pack 01
addappid(1365090) -- RIDE 4 - Sportbikes 101
addappid(1365100) -- RIDE 4 - Bonus Pack 02
addappid(1365110) -- RIDE 4 - Ultimate 2020
addappid(1365120) -- RIDE 4 - Kyalami Pack
addappid(1365130) -- RIDE 4 - Bonus Pack 03
addappid(1365150) -- RIDE 4 - Superbikes 2000
addappid(1365160) -- RIDE 4 - Bonus Pack 04
addappid(1365170) -- RIDE 4 - Italian Style Pack 1
addappid(1365180) -- RIDE 4 - Bonus Pack 05
addappid(1365190) -- RIDE 4 - 600cc Passion
addappid(1365200) -- RIDE 4 - Bonus Pack 06
addappid(1365210) -- RIDE 4 - Best Vintage 80s - 90s
addappid(1365220) -- RIDE 4 - Bonus Pack 07
addappid(1365230) -- RIDE 4 - Extreme Performance
addappid(1365240) -- RIDE 4 - Bonus Pack 08
addappid(1365250) -- RIDE 4 - The Collectors Pack
addappid(1365260) -- RIDE 4 - Bonus Pack 09
addappid(1365270) -- RIDE 4 - USA Tribute Pack
addappid(1365280) -- RIDE 4 - Bonus Pack 10
addappid(1365290) -- RIDE 4 - Power Naked Pack
addappid(1365300) -- RIDE 4 - Bonus Pack 11
addappid(1365310) -- RIDE 4 - Street Kings
addappid(1365320) -- RIDE 4 - Bonus Pack 12
addappid(1365330) -- RIDE 4 - Italian Style Pack 2
addappid(1365340) -- RIDE 4 - Bonus Pack 13
addappid(1365350) -- RIDE 4 - Naked Japan Style
addappid(1365360) -- RIDE 4 - Bonus Pack 14

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1259981, 1, "e3ec3d829bf2d18c10b6462b751a7609b97c1bb534f83975cedb6514d80d2dcd") -- RIDE 4 Content

