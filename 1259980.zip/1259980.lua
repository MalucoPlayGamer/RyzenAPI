-- Lua provided by RyzenAPI
-- Game: 1259980

-- MAIN APPLICATION
addappid(1259980)
-- Game: addappid(1259980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259981, 1, "e3ec3d829bf2d18c10b6462b751a7609b97c1bb534f83975cedb6514d80d2dcd")
