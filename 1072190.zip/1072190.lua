-- Lua provided by RyzenAPI
-- Game: Crossfire: Legion

-- MAIN APPLICATION
addappid(1072190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072191, 1, "31a05be963eb3ff21ef0e1ac6df9a46e33ebcfffbaf3c8b32d81f34ebcba3ebc")
