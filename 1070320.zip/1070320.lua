-- Lua provided by RyzenAPI
-- Game: Ring the City

-- MAIN APPLICATION
addappid(1070320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070321, 1, "274c8c8259ede4bf08860b791db29e682980067ee0fd047a4977ffb432db9dfe")

