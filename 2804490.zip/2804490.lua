-- Lua provided by RyzenAPI
-- Game: Game: Pawn Simulator

-- MAIN APPLICATION
addappid(2804490)
-- Game: addappid(2804490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804491, 1, "02f73ed5b6c236edd8a7c72df40be01eaf9d17d9dccb3cf7dc5c6aad1cad3c92")
