-- Lua provided by RyzenAPI
-- Game: AppID 1065750

-- MAIN APPLICATION
addappid(1065750)
-- Game: addappid(1065750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065751, 1, "7c989c42cddb8c4251286d1e7feefcaffda34159d2870be4cbef1a2bda6a0b86")
addappid(1065752, 1, "fa2377c365c55fa9cea629fe8d4179a7077e36d0ca1f7ac72a985f7a7ecb2d7c")
addappid(1065753, 1, "d73b9f8302bdc5153b9103cb41bc3b26bdf33ff9588e51a3b8fa6cab9768b7b2")
