-- Lua provided by RyzenAPI
-- Game: addappid(2455550)

-- MAIN APPLICATION
addappid(2455550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455550,0,"1e8f88974b1d0449e9f628a72a744eb50bddcbe053c27abd017677ba4a02252b")
