-- Lua provided by SkyAPI 
-- Game: Happy Piggy
addappid(3592350)
addappid(3592351, 1, "6899236647271e328735e3fa3835bf7fdf53a61c1ad2c145477ab726554d6a47")
