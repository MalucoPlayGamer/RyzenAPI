-- Lua provided by RyzenAPI
-- Game: Happy Piggy

-- MAIN APPLICATION
addappid(3592350)
-- Game: addappid(3592350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3592351, 1, "6899236647271e328735e3fa3835bf7fdf53a61c1ad2c145477ab726554d6a47")
