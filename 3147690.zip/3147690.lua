-- Lua provided by RyzenAPI 
-- Game: AppID 3147690
addappid(3147690)
addappid(3147691, 1, "cd513f0e9f59e0cc9cf6e7fac9cd79997e5612f17c0169f63a407730eeaf7473")
