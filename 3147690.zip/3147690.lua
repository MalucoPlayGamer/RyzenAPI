-- Lua provided by RyzenAPI
-- Game: Neverland永无乡

-- MAIN APPLICATION
addappid(3147690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147691, 1, "cd513f0e9f59e0cc9cf6e7fac9cd79997e5612f17c0169f63a407730eeaf7473")
