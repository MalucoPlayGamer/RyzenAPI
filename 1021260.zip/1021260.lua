-- Lua provided by RyzenAPI
-- Game: 1021260

-- MAIN APPLICATION
addappid(1021260)
-- Game: addappid(1021260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021261, 1, "f8ad1d6b5fa33cf83e498869e41f351ae339d630506a88ab26bb66e46f62883f")
