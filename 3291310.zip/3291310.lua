-- Lua provided by RyzenAPI
-- Game: Mutant College

-- MAIN APPLICATION
addappid(3291310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291311, 1, "f137b720fd39f59fc8411b65d19046ce77fb6431e06a514d548d25e20fd3775c")
