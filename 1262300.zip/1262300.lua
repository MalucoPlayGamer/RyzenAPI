-- Lua provided by RyzenAPI
-- Game: AUDICA - Sleeping Lion & Cass Miller ft. Bugle Bot - "How We Know (Bugle Bot Remix)"

-- MAIN APPLICATION
addappid(1262300)
-- Game: addappid(1262300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262300,0,"9595047f09775de350288469385a90bc7dcf69c1f1c5e13999ca5eaf2c410a53")
