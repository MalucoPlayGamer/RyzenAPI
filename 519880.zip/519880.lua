-- Lua provided by RyzenAPI 
-- Game: Redout Demo
addappid(519880)
addappid(519881, 1, "3f6e08ad63ab471ff60fe29e10a38547397b52d25302077dbeb2adb11fbbf344")
