-- Lua provided by RyzenAPI
-- Game: Game: Redout Demo

-- MAIN APPLICATION
addappid(519880)
-- Game: addappid(519880)

-- MAIN APP DEPOTS / PACKAGES
addappid(519881, 1, "3f6e08ad63ab471ff60fe29e10a38547397b52d25302077dbeb2adb11fbbf344")
