-- Lua provided by RyzenAPI
-- Game: ToS Gamepad Tester - Testing Upgrade Pack

-- MAIN APPLICATION
addappid(2104330)
-- Game: addappid(2104330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104330,0,"8671e3434fc8d37d01caa8168758ebaa0c806a36b256fe7677f100a13e078343")
