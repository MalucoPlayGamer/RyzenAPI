-- Lua provided by RyzenAPI
-- Game: Game: OceanCraft

-- MAIN APPLICATION
addappid(1497000)
-- Game: addappid(1497000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497001, 1, "f4d81a5492f695eedd2614b1a16ec933687becccb141d558074427bebca15191")
