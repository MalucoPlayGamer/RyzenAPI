-- Lua provided by RyzenAPI
-- Game: 3207670

-- MAIN APPLICATION
addappid(3207670)
-- Game: addappid(3207670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207671, 1, "2d0e5a8969b201ba636cc318891c091f3590e610318b5df540c2be4d5e4a66ff")
