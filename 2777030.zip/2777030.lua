-- Lua provided by RyzenAPI
-- Game: In The Shadows

-- MAIN APPLICATION
addappid(2777030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777031, 1, "310831f0be6dab2be79c0a02aeb45ab53787e948fb6addcd79308384db7ac024")
