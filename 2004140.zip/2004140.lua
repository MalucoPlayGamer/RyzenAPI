-- Lua provided by RyzenAPI
-- Game: 2004140

-- MAIN APPLICATION
addappid(2004140)
-- Game: addappid(2004140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004141, 1, "e0fc5ee85c20a0e3505016fe00e104d8bc35733bbfcdf4246af4af32a6de86e1")
