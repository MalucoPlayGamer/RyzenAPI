-- Lua provided by RyzenAPI
-- Game: AppID 963050

-- MAIN APPLICATION
addappid(963050)
-- Game: addappid(963050)

-- MAIN APP DEPOTS / PACKAGES
addappid(963051, 1, "ee18e7d5bb9264091f5d451d452c128f0a6a9812a5307d84915c89f267cf8319")
