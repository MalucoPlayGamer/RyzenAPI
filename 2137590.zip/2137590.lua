-- Lua provided by SkyAPI 
-- Game: AppID 2137590
addappid(2137590)
addappid(2137591, 1, "c2927120e2c97fb3b3d7be5bb5340f2d2a66f339872891f8368a880dc00e2fac")
