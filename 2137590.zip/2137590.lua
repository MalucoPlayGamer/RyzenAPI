-- Lua provided by RyzenAPI
-- Game: Game: AppID 2137590

-- MAIN APPLICATION
addappid(2137590)
-- Game: addappid(2137590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137591, 1, "c2927120e2c97fb3b3d7be5bb5340f2d2a66f339872891f8368a880dc00e2fac")
