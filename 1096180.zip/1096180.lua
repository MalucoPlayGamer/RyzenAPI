-- Lua provided by RyzenAPI
-- Game: Ato

-- MAIN APPLICATION
addappid(1096180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1096181, 1, "9670f6d77938fdcf6039ed9da61a13aa2d23512f5cb215094aa7a52876899695")

