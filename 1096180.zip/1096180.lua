-- Lua provided by RyzenAPI
-- Game: Ato

-- MAIN APPLICATION
addappid(1096180)
-- Game: addappid(1096180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096181, 1, "9670f6d77938fdcf6039ed9da61a13aa2d23512f5cb215094aa7a52876899695")
