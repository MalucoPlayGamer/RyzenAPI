-- Lua provided by RyzenAPI
-- Game: addappid(535400)

-- MAIN APPLICATION
addappid(535400)

-- MAIN APP DEPOTS / PACKAGES
addappid(535401, 1, "cbbcc9d89109af43004d65bcb97a6bb383d12f7877db591777f25bdf6393b1da")
