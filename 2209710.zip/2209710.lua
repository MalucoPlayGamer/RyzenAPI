-- Lua provided by SkyAPI 
-- Game: Skybox
addappid(2209710)
addappid(2209711, 1, "85cee8a4d55b9e68039461e1880cf68cdd2f277cb14d8de5a6d3230e2e3aa32b")
