-- Lua provided by RyzenAPI
-- Game: addappid(1028850)

-- MAIN APPLICATION
addappid(1028850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028851, 1, "53e54ecf27be4d7814abeb8f2e57c1890f4e7bf96d92c0dbac155755dada9581")
