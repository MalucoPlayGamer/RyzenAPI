-- Lua provided by RyzenAPI
-- Game: addappid(2016420)

-- MAIN APPLICATION
addappid(2016420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016421, 1, "70cfd3ffc2b8a4870e164b0166870983973e8eda35d2b84a49d718fadb4bf982")
