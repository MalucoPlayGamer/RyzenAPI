-- Lua provided by RyzenAPI
-- Game: Dark Journey

-- MAIN APPLICATION
addappid(1898640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1898641, 1, "e7ca1c6ebfb821959e7bb8098f09a2db4c765f27d007cf09106a79388720e72e")

