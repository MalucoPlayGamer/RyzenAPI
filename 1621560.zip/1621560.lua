-- Lua provided by RyzenAPI
-- Game: addappid(1621560)

-- MAIN APPLICATION
addappid(1621560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621561, 1, "28de5a653d01514649d6e16ec7b28d6ee5ac2897abc4609b507964835bfab62d")
