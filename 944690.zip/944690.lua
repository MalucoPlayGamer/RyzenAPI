-- Lua provided by RyzenAPI
-- Game: Star Goddess

-- MAIN APPLICATION
addappid(944690)

-- MAIN APP DEPOTS / PACKAGES
addappid(944691, 1, "faef91ad6ff532b2fbc2dcf787039cbc6249d6cd77789f121637167a2e92f20f")
