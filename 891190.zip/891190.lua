-- Lua provided by RyzenAPI 
-- Game: CROSS X CARROT
addappid(891190)
addappid(891191, 1, "f0b9d606a0d457d35b7f95f81bb6fb97dc7e7ba3a962cd064802314d942a67fa")
