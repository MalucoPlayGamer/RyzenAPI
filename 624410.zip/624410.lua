-- Lua provided by RyzenAPI
-- Game: 624410

-- MAIN APPLICATION
addappid(624410)
addappid(981840)
-- Game: addappid(624410)

-- MAIN APP DEPOTS / PACKAGES
addappid(624411, 1, "89ba8481b18ef22f18518dfcddd27cbabca8a180bd06ea11e350fa498320e784")
