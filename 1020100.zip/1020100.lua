-- Lua provided by RyzenAPI
-- Game: Liftoff® - Night Fever

-- MAIN APPLICATION
addappid(1020100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020101, 1, "a77a77978cfb70d2d1f78af4a8f4cbcc43fa089e3ebd63bc2b2c97b08897e3fc")
addappid(1020102, 1, "79b53caba7e254d7d730b63697de2d39e4fb9a2f749c45e9ceb9fc9d5f97b466")
addappid(1020103, 1, "c2e02b451e8ebd4955a225df3f2796a2b6ea5276083334ac10ee1de5c10d06b9")
addappid(1020104, 1, "fe135aa7f9b6b35edb302b754d2cbea0aa317fce4c9a98fc2e82b4ff51f6f45e")

