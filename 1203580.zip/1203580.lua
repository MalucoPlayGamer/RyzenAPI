-- Lua provided by SkyAPI 
-- Game: Photo Quiz - Animals
addappid(1203580)
addappid(1203581, 1, "7ec749cf096948465419f9e72122628bb6d3cf40266491b115075bbc208d167f")
