-- Lua provided by RyzenAPI
-- Game: Game: Photo Quiz - Animals

-- MAIN APPLICATION
addappid(1203580)
-- Game: addappid(1203580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203581, 1, "7ec749cf096948465419f9e72122628bb6d3cf40266491b115075bbc208d167f")
