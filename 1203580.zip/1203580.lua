-- Lua provided by RyzenAPI
-- Game: Photo Quiz - Animals

-- MAIN APPLICATION
addappid(1203580) -- Photo Quiz - Animals
addappid(1206160)
addappid(1212220)
addappid(1212490)
addappid(1212670)
addappid(1214610)
addappid(1216290)
addappid(1216750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203581, 1, "7ec749cf096948465419f9e72122628bb6d3cf40266491b115075bbc208d167f") -- Photo Quiz - Animals Content
addappid(1206160, 1, "97e9003a0c8183eae6004b9b729224e2668d5fb2d201b6e375eeffec4489fece") -- Photo Quiz - 3 Letter Words - Photo Quiz - 3 Letter Words (1206160) Depot
addappid(1212220, 1, "e25a0b41e7aa99370952c7c6b22900a1d8e6b6d4cc56bf4ab04a56ac354818a9") -- Photo Quiz - US States - Photo Quiz - US States (1212220) Depot
addappid(1212490, 1, "83f86e1de6db08085829b548909dfd31035946cb2cc1159ff642b6d694f47c84") -- Photo Quiz - What Job - Photo Quiz - What Job (1212490) Depot
addappid(1212670, 1, "824d8ef7bcfb3caa3fae7730df81e54d78327e3e05a5c4718e75a70192ecaef4") -- Photo Quiz - Capital Cities - Photo Quiz - Capital Cities (1212670) Depot
addappid(1214610, 1, "096c6f9d12bd20c694e2d6f33cf697aef704c39714979d1246af2cba60df33b8") -- Photo Quiz - Landmarks - Photo Quiz - Landmarks (1214610) Depot
addappid(1216290, 1, "ee1f1818004e1448038c147b9d481d01dc350296f31b3df9aada2de63e3e418b") -- Photo Quiz - Instruments - Photo Quiz - Instruments (1216290) Depot
addappid(1216750, 1, "5ea5265fdebf6ddcc4fcc9bd82c96ff32df1517f1edcf476d7cf1aadb60e122e") -- Photo Quiz - Flags - Photo Quiz - Flags (1216750) Depot

