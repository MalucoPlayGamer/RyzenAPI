-- Lua provided by RyzenAPI
-- Game: Game: GUARDS!

-- MAIN APPLICATION
addappid(2514460)
-- Game: addappid(2514460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514461, 1, "d7ad238adaaa7cea38e98b320fb49c8b87ee3c12fa7c6211f25fef753208aa5e")
addappid(2665430, 0, "cde5e17841e4cac008e8bc08d32c115ec186259ca363702442612d92edbd1f23")
