-- Lua provided by RyzenAPI
-- Game: GUARDS!

-- MAIN APPLICATION
addappid(2514460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514461, 1, "d7ad238adaaa7cea38e98b320fb49c8b87ee3c12fa7c6211f25fef753208aa5e")
addappid(2665430, 0, "cde5e17841e4cac008e8bc08d32c115ec186259ca363702442612d92edbd1f23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
