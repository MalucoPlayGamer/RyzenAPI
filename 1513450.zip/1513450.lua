-- Lua provided by RyzenAPI
-- Game: Game: TWO MONTHS

-- MAIN APPLICATION
addappid(1513450)
-- Game: addappid(1513450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513451, 1, "f6654366e6b67f101df527d24a5be4ef0951a1409cb571226e31430bf45772dc")
