-- Lua provided by RyzenAPI
-- Game: RUKIMIN's Disappointing Adventure!

-- MAIN APPLICATION
addappid(1843350)
addappid(1994290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843351, 1, "5d16498d00553d0ee1d0ac9bc6fab093110cae2f096a57b7fb80a0ebc1873e6e")

