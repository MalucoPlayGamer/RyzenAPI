-- Lua provided by RyzenAPI
-- Game: AppID 406800

-- MAIN APPLICATION
addappid(406800)

-- MAIN APP DEPOTS / PACKAGES
addappid(406801, 1, "6f47dee223a275d01e0d1af9b20a9fcbf4131f3f49a33fdcf211fae9b23c159b")
addappid(406802, 1, "dcf1c3e4e7119e26bcef0d8c8a4bdfba554b14b6ab00653806b216cebb1ff463")
