-- Lua provided by RyzenAPI
-- Game: Robin Morningwood Adventure - A gay RPG

-- MAIN APPLICATION
addappid(1457220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457221, 1, "6730819419c6bf211da64a417e7f82280a4f0320def923709f13220f3026e682")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2249900)
addappid(2355260)
