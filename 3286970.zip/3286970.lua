-- Lua provided by RyzenAPI
-- Game: Spear Song Artbook

-- MAIN APPLICATION
addappid(3286970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286971, 1, "e182612821559ff03401b3f37a56a7b61addef08351de0acd2e0c4a3ffbbaf3c")
