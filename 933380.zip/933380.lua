-- Lua provided by RyzenAPI
-- Game: Tennis Story

-- MAIN APPLICATION
addappid(933380)

-- MAIN APP DEPOTS / PACKAGES
addappid(933381, 1, "11d6eb38651411f7e12190336e602b467a3e9c3259446f39ec1ef7574fb24150")

