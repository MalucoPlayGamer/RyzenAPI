-- Lua provided by SkyAPI 
-- Game: Tanuki Justice
addappid(1406250)
addappid(1406251, 1, "d70f4bd6399f2f7e2602afb0d7c6a4dbee716f6ae8235e4b1228d7c747c62652")
