-- Lua provided by RyzenAPI
-- Game: 720280

-- MAIN APPLICATION
addappid(720280)
-- Game: addappid(720280)

-- MAIN APP DEPOTS / PACKAGES
addappid(720281, 1, "1c5936138789e03fd0b8c12a1de63a23af402dffd7e432244ac52bec71d795d0")
addappid(720282, 1, "ccfb791c47cfb58b25c3b9438af57df942364e285525dfe4bca3a738bc5b6dd3")
addappid(778160, 0, "ff58ff6e8b5ce79459be19207cba35cf9fefed3006c72124383d9c20446ed30b")
