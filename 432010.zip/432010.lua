-- Lua provided by RyzenAPI
-- Game: Game: AppID 432010

-- MAIN APPLICATION
addappid(432010)
-- Game: addappid(432010)

-- MAIN APP DEPOTS / PACKAGES
addappid(432011, 1, "14c1de5f34a36c7d3767944b5275ac36333933d24a55596ea4c21c205ef3744f")
