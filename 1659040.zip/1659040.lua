-- Lua provided by RyzenAPI
-- Game: HITMAN World of Assassination

-- MAIN APPLICATION
addappid(1829580) -- HITMAN 3 - Seven Deadly Sins Act 1: Greed
addappid(1829581) -- HITMAN 3 - Seven Deadly Sins Act 2: Pride
addappid(1829582) -- HITMAN 3 - Seven Deadly Sins Act 3: Sloth
addappid(1829583) -- HITMAN 3 - Seven Deadly Sins Act 4: Lust
addappid(1829584) -- HITMAN 3 - Seven Deadly Sins Act 5: Gluttony
addappid(1829585) -- HITMAN 3 - Seven Deadly Sins Act 6: Envy
addappid(1829586) -- HITMAN 3 - Seven Deadly Sins Act 7: Wrath
addappid(1829587) -- HITMAN 3 - Seven Deadly Sins Collection
addappid(1829590) -- HITMAN 3 Access Pass: HITMAN 2 Expansion
addappid(1829591) -- HITMAN 3 - Deluxe Pack
addappid(1829592) -- HITMAN 3 Access Pass: HITMAN 2 Standard
addappid(1829593) -- HITMAN 3 Access Pass: HITMAN 1 Complete First Season
addappid(1829594) -- HITMAN WOA - VR Access
addappid(1829595) -- HITMAN 3 Access Pass: HITMAN 1 GOTY Upgrade
addappid(1829596) -- HITMAN WOA - Trinity Pack
addappid(1829600) -- HITMAN 3 - Carpathian Mountains
addappid(1829601) -- HITMAN 3 - Mendoza
addappid(1829602) -- HITMAN 3 - Chongqing
addappid(1829603) -- HITMAN 3 - Berlin
addappid(1829604) -- HITMAN 3 - Dartmoor
addappid(1829605) -- HITMAN 3 - Dubai
addappid(1843460) -- HITMAN 3 Access Pass: HITMAN 1 GOTY Edition
addappid(2184790) -- HITMAN WOA - Street Art Pack
addappid(2184791) -- HITMAN WOA - Makeshift Pack
addappid(2475260) -- HITMAN WOA - Sarajevo Six Campaign Pack
addappid(2828470) -- HITMAN WOA - The Undying Pack
addappid(2973650) -- HITMAN 3 - The Disruptor Pack
addappid(3110360) -- HITMAN WOA - The Drop Pack
addappid(3254350) -- HITMAN WOA - The Splitter Pack
addappid(3711140) -- HITMAN WOA - The Banker Pack
addappid(3957470) -- HITMAN WOA - The Bruce Lee Pack
addappid(4097630) -- HITMAN WOA - The Eminem vs. Slim Shady Pack
addappid(4328240) -- HITMAN WOA - Patient Zero Requiem Pack
addappid(4542910) -- HITMAN WOA - World Champions Pack
addappid(4621250) -- HITMAN WOA - The Wizard Pack
addappid(4911210)
addappid(4944070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659040, 1, "5390a1942e4032c44876f6896fa8169bff61161a13f379433575053c4fe38c02")
addappid(1659041, 1, "891bd9670c03fa74065659fe448680b55b5279707dfe40493d5f00372e02b42f") -- (windows)
addappid(1659042, 1, "a4a03eaeb99e5848f2074a8902ce896268489ec313300285a521885c807e263c") -- (macos)

