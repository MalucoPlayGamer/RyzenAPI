-- Lua provided by RyzenAPI
-- Game: Bunny Guys!

-- MAIN APPLICATION
addappid(2218460)
addappid(4877830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218461, 1, "e258c354702f80c65e8b811048d48e5104459cba863529b797b143531f1694d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
