-- Lua provided by RyzenAPI
-- Game: Bunny Guys!

-- MAIN APPLICATION
addappid(2218460)
addappid(4877830)
-- Game: addappid(2218460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218461, 1, "e258c354702f80c65e8b811048d48e5104459cba863529b797b143531f1694d8")
