-- Lua provided by RyzenAPI
-- Game: AppID 547390

-- MAIN APPLICATION
addappid(547390)
addappid(558310)

-- MAIN APP DEPOTS / PACKAGES
addappid(547391, 1, "fa498bfd98980f166baa5afb742fe54485a26dfd90b2a0422ae747348a027f30")

