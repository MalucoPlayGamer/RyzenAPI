-- Lua provided by RyzenAPI
-- Game: addappid(2496920)

-- MAIN APPLICATION
addappid(2496920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496921, 1, "7987aba77a32baa32ba890bcef0bb200783f71c4985ac918f4eb4afba2518e39")
