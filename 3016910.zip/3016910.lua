-- Lua provided by RyzenAPI
-- Game: Summon Legion Demo

-- MAIN APPLICATION
addappid(3016910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016911, 1, "44a1d2f9bb00d9cbbfbbab96200f381aa29b06e4c05dcecedf2e7dc5901ac217")
