-- Lua provided by RyzenAPI
-- Game: Game: AppID 3172180

-- MAIN APPLICATION
addappid(3172180)
-- Game: addappid(3172180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172181, 1, "3b0910532b942a88680dd71443b4402c55b1baaa7ead95d4af1fb15217537ac9")
