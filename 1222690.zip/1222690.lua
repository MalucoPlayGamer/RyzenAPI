-- Lua provided by RyzenAPI
-- Game: AppID 1222690

-- MAIN APPLICATION
addappid(1222690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222691, 1, "542701533d6c8db0061f50ecbd1590287c2dfef83d7999818dda3ba8d49c113b")
addappid(1222692, 1, "69f743c2364a5096480dee7c15cdf6ac1c8bf03c7e43f0c839eeaef83acd66ab")
addappid(1222693, 1, "6010c7f30ae23cd27519e564c780f4376295379ccbc9c8cac48eb86df1808fab")
addappid(1222694, 1, "80e38ca64c882fb113d00e552ec4aaed9cfe242cbc6d86352835cd1f13f6c81f")
addappid(1222695, 1, "21af62561edab8c5e1b0241759ed5fd4b9638979306e35fdb7f47158ec3c783a")
addappid(1222696, 1, "2586e4ff645fbc003677e5d784d151e65f20f3282777762778e4ccfdf29fcc90")
addappid(1222697, 1, "325a200cc63eb34501ead298fd72b6356056323c57f5c9696f3da4c7ecd05a5b")
addappid(1222698, 1, "b89fb629cfe864d87c182ae86c8510163a4d419543795f458ecae9f06557a9b1")
addappid(1222699, 1, "66fbe2cea0a5c2ae0b0a02e7c525373596cfe5e51bea8535221782fb9f656103")
addappid(1257169, 0, "55ef26436f62c1abd06bd35e3dac4826f8b7ebcedd9e7242eb671600e99773bb")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1255340)
addappid(1255341)
addappid(1255342)
addappid(1255343)
addappid(1255344)
addappid(1255345)
addappid(1255346)
addappid(1255347)
addappid(1255348)
addappid(1255349)
addappid(1255350)
addappid(1255351)
addappid(1255352)
addappid(1255360)
addappid(1255361)
