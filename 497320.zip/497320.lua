-- Lua provided by RyzenAPI
-- Game: The Spirit of Twelve

-- MAIN APPLICATION
addappid(497320) -- The Spirit of Twelve

-- MAIN APP DEPOTS / PACKAGES
addappid(497322, 1, "31cf3622da8f1c4f559600b20f61930a6e75a5c9b662482a0de6b9fa5f920082") -- Depot 497322
addappid(497323, 1, "ba74fba4ef47c1b168cce50bac31832535fa66060b5bd7dc74c9014db710d8f0") -- Depot 497323
addappid(497324, 1, "534d8d1195d540e9f77cd4b7f34508b20bd77ecc6227793c73665ba38685fb02") -- Depot 497324

