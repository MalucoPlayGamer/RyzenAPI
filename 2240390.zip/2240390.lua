-- Lua provided by RyzenAPI
-- Game: Celebrity Kombat

-- MAIN APPLICATION
addappid(2240390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240391, 1, "95d3cea677f708e1139f2013d0922436400db2500e90988bd8236937a5d2b134")

