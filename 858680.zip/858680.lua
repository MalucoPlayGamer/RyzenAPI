-- Lua provided by RyzenAPI
-- Game: Game: Black Paradox

-- MAIN APPLICATION
addappid(858680)
addappid(909730)
-- Game: addappid(858680)

-- MAIN APP DEPOTS / PACKAGES
addappid(858681, 1, "4617d73f8d6048e269bfb8f9cc686c35f85e4942a0df546c1164ded299481350")
