-- Lua provided by RyzenAPI
-- Game: Terralysia Demo

-- MAIN APPLICATION
addappid(2929560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929561, 1, "ed13e581c9f65685c607d640c9f36f805f8b968097ae6801b0745e26f3db91b7")
