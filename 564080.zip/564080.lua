-- Lua provided by RyzenAPI
-- Game: Metagalactic Blitz

-- MAIN APPLICATION
addappid(564080)
addappid(1059630)
-- Game: addappid(564080)

-- MAIN APP DEPOTS / PACKAGES
addappid(564081, 1, "bb6cc01a49eecdfb7fcc519096c9209c450841518fdfce7a9caf7340bf00c23b")
