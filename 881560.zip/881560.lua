-- Lua provided by RyzenAPI
-- Game: 881560

-- MAIN APPLICATION
addappid(881560)
-- Game: addappid(881560)

-- MAIN APP DEPOTS / PACKAGES
addappid(881561, 1, "32e25bacd726415f6de8ab00c9a50bd2f9b5c121befda0cc7d82789a0276c96a")
addappid(881562, 1, "297ff71629d3b5c5eb832ef63715d6d7f35996766ce4a727a4a563217f8f9f22")
