-- Lua provided by RyzenAPI
-- Game: Crystal Clash

-- MAIN APPLICATION
addappid(1839660)
-- Game: addappid(1839660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839661, 1, "e63570f6937777c0e2d55853bb89a1e3e53159140df659a1e4c711b251ea3012")
