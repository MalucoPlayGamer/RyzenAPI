-- Lua provided by SkyAPI 
-- Game: Crystal Clash
addappid(1839660)
addappid(1839661, 1, "e63570f6937777c0e2d55853bb89a1e3e53159140df659a1e4c711b251ea3012")
