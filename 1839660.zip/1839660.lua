-- Lua provided by RyzenAPI
-- Game: Crystal Clash

-- MAIN APPLICATION
addappid(1839660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839661, 1, "e63570f6937777c0e2d55853bb89a1e3e53159140df659a1e4c711b251ea3012")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
