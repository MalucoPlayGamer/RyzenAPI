-- Lua provided by RyzenAPI
-- Game: Phantasmagoria 2: A Puzzle of Flesh

-- MAIN APPLICATION
addappid(501970)

-- MAIN APP DEPOTS / PACKAGES
addappid(501971, 1, "dd18345e85db5221f4f7e0ded96b611a941d597bd38d97fed2ca9a3d99fcfe33")
