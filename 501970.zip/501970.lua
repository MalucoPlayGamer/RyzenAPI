-- Lua provided by SkyAPI 
-- Game: Phantasmagoria 2: A Puzzle of Flesh
addappid(501970)
addappid(501971, 1, "dd18345e85db5221f4f7e0ded96b611a941d597bd38d97fed2ca9a3d99fcfe33")
