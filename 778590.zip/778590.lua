-- Lua provided by RyzenAPI
-- Game: Mountain Troll

-- MAIN APPLICATION
addappid(778590)

-- MAIN APP DEPOTS / PACKAGES
addappid(778591, 1, "d7607ebb0eb28cc873ceb4c9409534963f9d3b9a9324720c754799ce5ef9d4f5")

