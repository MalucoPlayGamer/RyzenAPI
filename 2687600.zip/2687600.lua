-- Lua provided by RyzenAPI
-- Game: Doppelgänger

-- MAIN APPLICATION
addappid(2687600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687601, 1, "ed412bd5c0ffc61b7219101b551d7e9f668c6cfa3a8d4467cb6fbba6518b4e77")
