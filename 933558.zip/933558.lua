-- Lua provided by RyzenAPI
-- Game: addappid(933558)

-- MAIN APPLICATION
addappid(933558)

-- MAIN APP DEPOTS / PACKAGES
addappid(933558,0,"cb07374f0e9365d451c4836e31e9cc092c53f6b74832c86cf034f3bc48a7578e")
