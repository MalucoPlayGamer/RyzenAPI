-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Weapons Orochi Pack 3

-- MAIN APPLICATION
addappid(933558)
-- Game: addappid(933558)

-- MAIN APP DEPOTS / PACKAGES
addappid(933558,0,"cb07374f0e9365d451c4836e31e9cc092c53f6b74832c86cf034f3bc48a7578e")
