-- Lua provided by RyzenAPI
-- Game: addappid(1927020)

-- MAIN APPLICATION
addappid(1927020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927021, 1, "5825b472cb501c61e265c5e420f1cd9a3819ae903531c0adba3d15572244e6cd")
