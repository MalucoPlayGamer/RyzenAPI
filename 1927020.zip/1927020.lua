-- Lua provided by SkyAPI 
-- Game: The Breadmaker
addappid(1927020)
addappid(1927021, 1, "5825b472cb501c61e265c5e420f1cd9a3819ae903531c0adba3d15572244e6cd")
