-- Lua provided by RyzenAPI
-- Game: AppID 42740

-- MAIN APPLICATION
addappid(42740)
-- Game: addappid(42740)

-- MAIN APP DEPOTS / PACKAGES
addappid(42741, 1, "8f17d1849d419858fd16d3574d61f42263ebc4d480a4c9e0c026738182da33ed")
