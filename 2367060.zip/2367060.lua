-- Lua provided by RyzenAPI
-- Game: Orc Covenant Demo

-- MAIN APPLICATION
addappid(2367060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367061, 1, "9b795258d8921dfbbc461b1173e462d36c65d29a850c1ce3883bfae7987519fd")
