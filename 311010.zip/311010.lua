-- Lua provided by RyzenAPI
-- Game: The Way

-- MAIN APPLICATION
addappid(311010)

-- MAIN APP DEPOTS / PACKAGES
addappid(311011, 1, "5ec3c7d89698de94e7da2ecc86c1eb663586ef7ac77a1a107e7b7ba70d239b85")
addappid(311012, 1, "7fddfe50204737e423b58e0dcbd36d83db16b0d9c7806fe6a6a3218ecf2605b2")
addappid(311013, 1, "23a7f1a34ae59e13734845b3ea671e54f4b0af26ca041f97a1e9bfbbf3913d58")
addappid(363640, 0, "6024a3adf5e56a84f6b0eb3fb80d7edf65aeb0e52ad1560ff02d2d2eb9f41bfe")

