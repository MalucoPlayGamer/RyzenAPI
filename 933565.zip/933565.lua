-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 - Special Mounts Pack 2

-- MAIN APPLICATION
addappid(933565)
-- Game: addappid(933565)

-- MAIN APP DEPOTS / PACKAGES
addappid(933565,0,"e5ae35bbe2abfcec96e7016e4283b3e89b090c4da12a604348a3966362c93fdb")
addtoken(933565,14761303738508550599)
