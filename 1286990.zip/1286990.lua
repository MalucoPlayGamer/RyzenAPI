-- Lua provided by RyzenAPI
-- Game: AppID 1286990

-- MAIN APPLICATION
addappid(1286990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286991, 1, "8c1377b907d090b7a9a8e8ea92efdb8cd9a27c88c08f2b7d596ec27878deb993")

