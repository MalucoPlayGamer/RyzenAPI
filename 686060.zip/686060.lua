-- Lua provided by RyzenAPI
-- Game: Mewgenics

-- MAIN APPLICATION
addappid(686060)

-- MAIN APP DEPOTS / PACKAGES
addappid(686061, 1, "632bb9334c4d72a84090a9998ec0bf0c8eac465df723928f022b40b6ff04119a")
