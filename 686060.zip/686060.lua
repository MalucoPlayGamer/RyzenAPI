-- Lua provided by RyzenAPI 
-- Game: Mewgenics
addappid(686060)
addappid(686061, 1, "632bb9334c4d72a84090a9998ec0bf0c8eac465df723928f022b40b6ff04119a")
