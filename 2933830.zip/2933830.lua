-- Lua provided by RyzenAPI
-- Game: addappid(2933830)

-- MAIN APPLICATION
addappid(2933830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933831, 1, "f7d5545342d172511ae46ca84228cc757b016972a30bc6b4aa1a2c354feab7cc")
