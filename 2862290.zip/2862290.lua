-- Lua provided by RyzenAPI
-- Game: 2862290

-- MAIN APPLICATION
addappid(2862290)
-- Game: addappid(2862290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862291, 1, "623fc81224a53a39e7af842b852c2594673ae45e8d8d4c4c947cbd9f035ff193")
