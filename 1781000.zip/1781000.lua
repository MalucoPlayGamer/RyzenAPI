-- Lua provided by RyzenAPI
-- Game: Bright Memory: Infinite Youthful Days DLC

-- MAIN APPLICATION
addappid(1781000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781000,0,"08a1542d2b727f6763c23f90748b2bc0cb2ec6081f150c23fdf65692a3777a2b")

