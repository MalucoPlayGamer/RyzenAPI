-- Lua provided by RyzenAPI
-- Game: addappid(2457780)

-- MAIN APPLICATION
addappid(2457780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457781, 1, "d3bbb287fd1d7c0eb17af42297280b9ffcc729d3f7cc0509214505b3f130d8c5")
