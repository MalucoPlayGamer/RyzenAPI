-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Naughty Sisters - Episode 9

-- MAIN APPLICATION
addappid(3663960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3663961, 1, "4f6264337870a55ae77663cfddeab295fc57630e7b4f5ed248ff2686f923c3fa")
