-- Lua provided by RyzenAPI
-- Game: AppID 595430

-- MAIN APPLICATION
addappid(595430)
-- Game: addappid(595430)

-- MAIN APP DEPOTS / PACKAGES
addappid(595431, 1, "ac7cbb717d1a86b4147246a9f6d0ab88f26d1a5e6225c67061349af20beac805")
