-- Lua provided by RyzenAPI
-- Game: 玄中记

-- MAIN APPLICATION
addappid(4571290)

