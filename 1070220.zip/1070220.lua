-- Lua provided by RyzenAPI
-- Game: 1070220

-- MAIN APPLICATION
addappid(1070220)
-- Game: addappid(1070220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070221, 1, "af1cd23c6e9312888118c48be1852b8fe84be0bd08ba91e584a677c803aef94d")
