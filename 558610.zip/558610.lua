-- Lua provided by RyzenAPI
-- Game: addappid(558610)

-- MAIN APPLICATION
addappid(558610)

-- MAIN APP DEPOTS / PACKAGES
addappid(558611, 1, "1e86f5ac7ccb199f86f379981af7df3065a80d8bc57e50d75a759ab777de07f8")
