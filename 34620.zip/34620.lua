-- Lua provided by RyzenAPI
-- Game: Game: Order of War Demo

-- MAIN APPLICATION
addappid(34620)
-- Game: addappid(34620)

-- MAIN APP DEPOTS / PACKAGES
addappid(34621, 1, "513b5c4cdadb59c882f200d6fe945d10aaa24318d0752cdad400211f95af6955")
