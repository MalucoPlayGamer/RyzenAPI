-- Lua provided by RyzenAPI 
-- Game: Order of War Demo
addappid(34620)
addappid(34621, 1, "513b5c4cdadb59c882f200d6fe945d10aaa24318d0752cdad400211f95af6955")
