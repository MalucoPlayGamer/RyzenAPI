-- Lua provided by RyzenAPI
-- Game: addappid(3197520)

-- MAIN APPLICATION
addappid(3197520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197521, 1, "66056a852f67cada4c33cab907e25d35ce77d8bba7ea53ba58d77f61d4f70386")
addappid(3197522, 1, "da29c80aa2aba4348ddab91f90fc9c93c5b931b1b84f2ed317aa61b8c62bc0f7")
