-- Lua provided by RyzenAPI
-- Game: Neo Cab Original Soundtrack

-- MAIN APPLICATION
addappid(1160390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160391, 1, "60ff02328e3d042f730a95e18b0fef5daa084f958be8a955e8641c7f7719c937")

