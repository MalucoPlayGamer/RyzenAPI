-- Lua provided by RyzenAPI
-- Game: Re: LieF ~ Shin'ainaru Anata e~

-- MAIN APPLICATION
addappid(1518770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518771, 1, "bc3e8950ab5e8bbb14dd389ceff5d5a2493fe07cfc586c64eb8b8721e54d9b64")
addappid(1518772, 1, "e42259754d952bcd211dc027daf9cfab78a5ed56dba7c0ff8f4a61d98038201e")
addappid(1518773, 1, "f9c2872cc01286c6d2f8260f8a32f7744c39d2672419560b4545449182db0cce")
addappid(1518774, 1, "2cfb94961107cb52ff21f101c1579603c46cb25c1007f977854c026ce3c1e28d")

