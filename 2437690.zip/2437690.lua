-- Lua provided by RyzenAPI
-- Game: 2437690

-- MAIN APPLICATION
addappid(2437690)
-- Game: addappid(2437690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437691, 1, "45c03bef6f120e1435771b010372942b14aaa78a9ab929c326b63293dfad5bb9")
