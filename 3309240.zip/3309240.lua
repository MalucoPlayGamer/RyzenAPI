-- Lua provided by SkyAPI 
-- Game: Creeping Clark
addappid(3309240)
addappid(3309241, 1, "72e301acf87cadf7b756347e073297a354d6369f1bf1ccc56393cc7ec7ce78dd")
