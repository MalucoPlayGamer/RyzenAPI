-- Lua provided by RyzenAPI
-- Game: Creeping Clark

-- MAIN APPLICATION
addappid(3309240)
-- Game: addappid(3309240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3309241, 1, "72e301acf87cadf7b756347e073297a354d6369f1bf1ccc56393cc7ec7ce78dd")
