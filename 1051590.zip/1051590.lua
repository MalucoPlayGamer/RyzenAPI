-- Lua provided by RyzenAPI
-- Game: Game: AppID 1051590

-- MAIN APPLICATION
addappid(1051590)
-- Game: addappid(1051590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051591, 1, "f808041c2ebda7f6d802932d9e6b2e4b73367c7c8ecbf1354372c206aa06ad08")
addappid(1206500, 0, "a10d3b12a668dc9ec4adcb6e2e537cc9d6677e09e55889c3c76b08a8b34994a9")
