-- Lua provided by RyzenAPI
-- Game: Agent-00

-- MAIN APPLICATION
addappid(1299580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299581, 1, "4a5d0e7aabdfe4b5179d44265ddc352193e15628b36bd155c0e70a53b8e1c94d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
