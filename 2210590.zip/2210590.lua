-- Lua provided by RyzenAPI
-- Game: 自由人生模拟 Free Life Simulation

-- MAIN APPLICATION
addappid(2210590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210591, 1, "48b9835de9f0ab13270e020cab5046ea390a6e765214f68d918e07520309af94")
