-- Lua provided by RyzenAPI
-- Game: 308000

-- MAIN APPLICATION
addappid(308000)
-- Game: addappid(308000)

-- MAIN APP DEPOTS / PACKAGES
addappid(308001, 1, "716842bf3ee3735eb396fdb63932bcb919170fb2d2c9341142c97fb942cda36b")
