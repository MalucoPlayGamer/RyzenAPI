-- Lua provided by RyzenAPI
-- Game: NBA 2K17

-- MAIN APPLICATION
addappid(385760)
addappid(515640)
addappid(515641)
addappid(515642)
-- Game: addappid(385760)

-- MAIN APP DEPOTS / PACKAGES
addappid(385762,0,"477799d3456bb786f58fff1c9a98606cbc55f268ba95c938ba34e7ada2845f43")
