-- Lua provided by RyzenAPI
-- Game: NBA 2K17

-- MAIN APPLICATION
addappid(385760)
addappid(515640)
addappid(515641)
addappid(515642)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(385762,0,"477799d3456bb786f58fff1c9a98606cbc55f268ba95c938ba34e7ada2845f43")

