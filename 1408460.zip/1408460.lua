-- Lua provided by RyzenAPI
-- Game: Strategic Mind: Spectre of Communism Demo

-- MAIN APPLICATION
addappid(1408460)
-- Game: addappid(1408460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408461, 1, "28833cb7790e2ed89188b8acfaa62f90843246bc9d6f2c50d01514c5f0999b7c")
