-- Lua provided by SkyAPI 
-- Game: AppID 1018770
addappid(1018770)
addappid(1018771, 1, "59318ab553242d264adca7fecb3bcbd674647bd2e1a5507063a95d246f2f866c")
