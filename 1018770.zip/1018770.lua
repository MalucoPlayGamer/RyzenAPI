-- Lua provided by RyzenAPI
-- Game: Lizardquest-Alien waters

-- MAIN APPLICATION
addappid(1018770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018771, 1, "59318ab553242d264adca7fecb3bcbd674647bd2e1a5507063a95d246f2f866c")
