-- Lua provided by RyzenAPI
-- Game: AppID 470480

-- MAIN APPLICATION
addappid(470480)
-- Game: addappid(470480)

-- MAIN APP DEPOTS / PACKAGES
addappid(470481, 1, "204c0b4ed65b364d72aced8f6e67db99ca9f04bf64585a3b1b4cac5b6e57dbe3")
addappid(571440, 0, "ffe60afdfa69aa60710b4e320fbdbecba125575abae683da977a466292fd7cf7")
