-- Lua provided by RyzenAPI
-- Game: AppID 621830

-- MAIN APPLICATION
addappid(621830)

-- MAIN APP DEPOTS / PACKAGES
addappid(621831, 1, "20e3152c0296460f28ce3f5a211affca305a09e6d9b9f6bbcce13bc819d0f462")

