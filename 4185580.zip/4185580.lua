-- Lua provided by RyzenAPI
-- Game: Signal Zone

-- MAIN APPLICATION
addappid(4185580)

-- MAIN APP DEPOTS / PACKAGES
addappid(4185581,0,"24204b7179d9b62d24db9656349e13e323ca5fb6dccfa7cb7900f166b6259574")

