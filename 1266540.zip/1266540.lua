-- Lua provided by RyzenAPI
-- Game: Ships At Sea

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1266540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1266542,0,"fbcc1f73994ed18e530465bb11c2a7f9a7a2d4cbdab681c215bf1ddfe135a8ca")

