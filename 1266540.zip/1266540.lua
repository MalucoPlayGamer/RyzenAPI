-- Lua provided by RyzenAPI
-- Game: Ships At Sea

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1266540)
-- Game: addappid(1266540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266542,0,"fbcc1f73994ed18e530465bb11c2a7f9a7a2d4cbdab681c215bf1ddfe135a8ca")
