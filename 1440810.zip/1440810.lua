-- Lua provided by SkyAPI 
-- Game: Enthrean Radiance : Prologue
addappid(1440810)
addappid(1440811, 1, "88a6a4843cb527c2f5badffe0720bbcca79f9c8a9468dcabb563e6da4e30dd68")
