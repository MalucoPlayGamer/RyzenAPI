-- Lua provided by RyzenAPI
-- Game: Enthrean Radiance : Prologue

-- MAIN APPLICATION
addappid(1440810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(1440811, 1, "88a6a4843cb527c2f5badffe0720bbcca79f9c8a9468dcabb563e6da4e30dd68")

