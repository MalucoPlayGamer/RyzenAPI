-- Lua provided by RyzenAPI
-- Game: NEKO-NIN exHeart

-- MAIN APPLICATION
addappid(407310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(407311, 1, "512f595c114e99f18864b73769b9d6bcbf6a5e0eeed07aff8b9569c411213c38")
addappid(943690, 0, "2ef2f675a091ef12802a78b0499f0271f7106d22e9f0f88352727a3de806e15f")

