-- Lua provided by RyzenAPI
-- Game: Numeral Lord

-- MAIN APPLICATION
addappid(2095180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095181, 1, "9f9be62d2d81f794b51e243712aaf423b6be1b98198f4ad352c6a519d9e65cd9")
