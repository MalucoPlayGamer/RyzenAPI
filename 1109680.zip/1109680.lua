-- Lua provided by RyzenAPI
-- Game: 1109680

-- MAIN APPLICATION
addappid(1109680)
addappid(2542770)
-- Game: addappid(1109680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109681, 1, "edddbcd9ad0d20c27f9dfe5dbc63b54266d67a028f2f5e6ea81960a0925e0bc3")
