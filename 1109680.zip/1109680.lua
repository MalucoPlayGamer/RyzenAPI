-- Lua provided by RyzenAPI 
-- Game: Regiments
addappid(1109680)
addappid(1109681, 1, "edddbcd9ad0d20c27f9dfe5dbc63b54266d67a028f2f5e6ea81960a0925e0bc3")
addappid(2542770)
