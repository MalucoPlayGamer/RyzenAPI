-- Lua provided by RyzenAPI
-- Game: addappid(2242320)

-- MAIN APPLICATION
addappid(2242320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242321, 1, "cac94a267d7787ec87cbc1e2409483122e6d9873d341e0c09dce35e10fd0bf19")
