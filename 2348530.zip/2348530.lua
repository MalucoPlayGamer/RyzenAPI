-- Lua provided by RyzenAPI
-- Game: addappid(2348530)

-- MAIN APPLICATION
addappid(2348530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348531, 1, "4c35228e78e3003a4b0fd1b0d98d6211e6cee97ec55d4eebee0d05bddb9fc6db")
