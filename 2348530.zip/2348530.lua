-- Lua provided by SkyAPI 
-- Game: Wizard's watch
addappid(2348530)
addappid(2348531, 1, "4c35228e78e3003a4b0fd1b0d98d6211e6cee97ec55d4eebee0d05bddb9fc6db")
