-- Lua provided by SkyAPI 
-- Game: Owinka Shooter 2
addappid(2397840)
addappid(2397841, 1, "14188e18d7cf349283e8c27834bbe7ebe4c827d26b623c74f7253f99bc050aec")
