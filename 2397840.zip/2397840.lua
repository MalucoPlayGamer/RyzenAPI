-- Lua provided by RyzenAPI
-- Game: 2397840

-- MAIN APPLICATION
addappid(2397840)
-- Game: addappid(2397840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397841, 1, "14188e18d7cf349283e8c27834bbe7ebe4c827d26b623c74f7253f99bc050aec")
