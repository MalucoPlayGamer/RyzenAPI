-- Lua provided by RyzenAPI
-- Game: Trusty Brothers

-- MAIN APPLICATION
addappid(1221400)
-- Game: addappid(1221400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221401, 1, "2cc6f5401b8c0a7d27ccaba9520311d1e4b2248b6144ff9fd7fb628b25cd14c1")
