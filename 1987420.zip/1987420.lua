-- Lua provided by RyzenAPI
-- Game: Call Sign is Magic Liner

-- MAIN APPLICATION
addappid(1987420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1987421, 1, "38efba9d95ae33052a4f43f700a5859a11853bde0a706f35d943bfe5c08c9f8d")

