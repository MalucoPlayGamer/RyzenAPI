-- Lua provided by RyzenAPI
-- Game: addappid(1987420)

-- MAIN APPLICATION
addappid(1987420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987421, 1, "38efba9d95ae33052a4f43f700a5859a11853bde0a706f35d943bfe5c08c9f8d")
