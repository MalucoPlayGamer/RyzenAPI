-- Lua provided by RyzenAPI
-- Game: AppID 1916660

-- MAIN APPLICATION
addappid(1916660)
-- Game: addappid(1916660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916661, 1, "a5e6ab78811895f4f8dc24938a42e7fad67badd5288e4d4367ab677bd7ecd23c")
