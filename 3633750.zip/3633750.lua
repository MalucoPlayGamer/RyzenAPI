-- Lua provided by RyzenAPI
-- Game: Love Confessions on the Adventure

-- MAIN APPLICATION
addappid(3633750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3633751,0,"6d6c11d057cb45fd5bc69440a581edd3a0327d8461c3da16e154d34a45ee945e")

