-- Lua provided by RyzenAPI
-- Game: Loop Hero Demo

-- MAIN APPLICATION
addappid(1519390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519391, 1, "fad131d7c524376f61e797a9771a29268ef1771bfff267084a30bc15891c6361")

