-- Lua provided by RyzenAPI
-- Game: 1482880

-- MAIN APPLICATION
addappid(1482880)
addappid(1747710)
-- Game: addappid(1482880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482881, 1, "c5d99245589881b3448ecff017077c628c5e139c550f6b50d276b2ec511bd565")
