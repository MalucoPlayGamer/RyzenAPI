-- Lua provided by RyzenAPI 
-- Game: Hentai Gothic Girl
addappid(1482880)
addappid(1482881, 1, "c5d99245589881b3448ecff017077c628c5e139c550f6b50d276b2ec511bd565")
addappid(1747710)
