-- Lua provided by RyzenAPI
-- Game: 1359760

-- MAIN APPLICATION
addappid(1359760)
-- Game: addappid(1359760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359761, 1, "9027d8d58e7b56ec26546326074443bacc2a80df10ec16f479895c1716ee1d7b")
