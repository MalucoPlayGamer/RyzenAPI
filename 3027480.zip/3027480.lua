-- Lua provided by RyzenAPI 
-- Game: Outpost 3
addappid(3027480)
addappid(3027481, 1, "2f707ad63555908d2e1f9bd467ea37889fa15eaaf35fdb25d0bffb6ddbd8aa2b")
