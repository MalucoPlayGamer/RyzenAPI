-- Lua provided by RyzenAPI 
-- Game: Galactic Junk League
addappid(562590)
addappid(562591, 1, "dbe9ea86f79fe4ed9b3a2fe27c7b25b087fa817469fbb8dfa2ebc6c8ec67c170")
addappid(562592, 1, "8be111dd4287a51d7202817e1deab85b0441bbb640163c8bcd7732712a287190")
