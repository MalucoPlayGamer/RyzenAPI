-- Lua provided by RyzenAPI
-- Game: R.E.P.O.

-- MAIN APPLICATION
addappid(3241660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241661, 1, "0a0fcffb2de6fb0fa6caff076a5a8cb960903d17320968d5c042fd5a4f9ad2ad")

