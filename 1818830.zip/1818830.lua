-- Lua provided by RyzenAPI
-- Game: Game: Maze Art: Red

-- MAIN APPLICATION
addappid(1818830)
-- Game: addappid(1818830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818831, 1, "19af856b95853fe969d223b6187eb673afe69e5bc28d23a09ec6c1510bb5a940")
