-- Lua provided by RyzenAPI
-- Game: KMP

-- MAIN APPLICATION
addappid(1152900)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1152901, 1, "3b58646ba96aa3e58982b861af61dc066900f83bc2beb07531fa7c95f51d4f24")
