-- Lua provided by RyzenAPI 
-- Game: AppID 1152900
addappid(1152900)
addappid(1152901, 1, "3b58646ba96aa3e58982b861af61dc066900f83bc2beb07531fa7c95f51d4f24")
