-- Lua provided by RyzenAPI
-- Game: 2196640

-- MAIN APPLICATION
addappid(2196640)
-- Game: addappid(2196640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196641, 1, "a64a205697c06f933de1cf5e70be685c87caf19c41315aac1f15e45ea29df8a2")
