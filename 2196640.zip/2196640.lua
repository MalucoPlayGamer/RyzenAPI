-- Lua provided by SkyAPI 
-- Game: Engine Evolution 2023
addappid(2196640)
addappid(2196641, 1, "a64a205697c06f933de1cf5e70be685c87caf19c41315aac1f15e45ea29df8a2")
