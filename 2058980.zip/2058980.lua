-- Lua provided by RyzenAPI
-- Game: Prototypers

-- MAIN APPLICATION
addappid(2058980)
-- Game: addappid(2058980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058981, 1, "dabcf765eec6483b548dcb32b009cae8ad67e6fb44279f7dd2f36d0a109a50e5")
