-- Lua provided by RyzenAPI
-- Game: Bad Bots Rise

-- MAIN APPLICATION
addappid(852920)

-- MAIN APP DEPOTS / PACKAGES
addappid(852921,0,"ca1fe048d5a917b36f814bb42c7344812ff38eb9947fd5e922d7b205a94efffc")

