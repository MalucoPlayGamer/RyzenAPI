-- Lua provided by RyzenAPI 
-- Game: Super Retro Fighter
addappid(1574750)
addappid(1574751, 1, "f75b60721f6029c9f547416a679787ee88f1b2cccdae1d663885c79c3227d177")
