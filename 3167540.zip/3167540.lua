-- Lua provided by RyzenAPI
-- Game: Not Monday Cafe

-- MAIN APPLICATION
addappid(3167540)
addappid(3787780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167541, 1, "d4aaad748f8899ae323b910dd54e0f6ccf51ec6706dbd4fdb8e4bf827e0f2aea")
