-- Lua provided by RyzenAPI
-- Game: Away From Earth: Mars

-- MAIN APPLICATION
addappid(852740)

-- MAIN APP DEPOTS / PACKAGES
addappid(852741, 1, "0cfb2535ad0f2898a52258060a0757748b7d3ed21e8447dd1aeb5d601c13e365")
