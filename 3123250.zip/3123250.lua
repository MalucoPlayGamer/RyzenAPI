-- Lua provided by SkyAPI 
-- Game: Nightwatch: Closer
addappid(3123250)
addappid(3123251, 1, "f9a4f098680635002768b18c91411657318915692ce9f0ee520c3edb601ea1b2")
