-- Lua provided by RyzenAPI
-- Game: Nightwatch: Closer

-- MAIN APPLICATION
addappid(3123250)
-- Game: addappid(3123250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123251, 1, "f9a4f098680635002768b18c91411657318915692ce9f0ee520c3edb601ea1b2")
