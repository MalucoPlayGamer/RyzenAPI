-- Lua provided by RyzenAPI
-- Game: Cheese Rolling

-- MAIN APPLICATION
addappid(3809440)

