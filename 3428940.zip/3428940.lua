-- Lua provided by RyzenAPI
-- Game: Game: Pest Control Simulator

-- MAIN APPLICATION
addappid(3428940)
-- Game: addappid(3428940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428941, 1, "5cb98ec5fd991dc17e2f6ad3c68226c7f11cc7d44db5b14f64da33632032faf6")
