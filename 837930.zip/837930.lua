-- Lua provided by RyzenAPI
-- Game: Alone

-- MAIN APPLICATION
addappid(837930)

-- MAIN APP DEPOTS / PACKAGES
addappid(837931,0,"a120c389fff9861f57d2e35fcff093f0bc9735b50540df04e759e0826165424e")

