-- Lua provided by RyzenAPI
-- Game: The Warlock of Firetop Mountain

-- MAIN APPLICATION
addappid(324740)
addappid(484960)
addappid(484970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(324741, 1, "625da507e8ad1e3c5d7ef68b2ca734642969c9921beef1e90e4e766b84157bb1")
addappid(324742, 1, "9729fb0dbc1c4e264f2f0847fe95b70260e085266fea2497e614e38b1c16d993")
addappid(324743, 1, "5c48a400574d1643e5cbed6acaa626c8c024adbd870ada793a9959f737c931df")
