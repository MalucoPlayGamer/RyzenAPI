-- Lua provided by RyzenAPI
-- Game: Dangerous Lands 2 - Evil Ascension

-- MAIN APPLICATION
addappid(1283740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283741, 1, "ba48bbebb3b03b357fc409773571d08737bc029821a9fdd73b6f9b8eb220d907")

