-- Lua provided by RyzenAPI
-- Game: Game: AppID 937740

-- MAIN APPLICATION
addappid(937740)
addappid(958970)
-- Game: addappid(937740)

-- MAIN APP DEPOTS / PACKAGES
addappid(937741, 1, "8a495b91ae64daabcca271a83417274d8c0d7a5e59ee626be5d8d2f656450318")
