-- Lua provided by SkyAPI 
-- Game: AppID 1703920
addappid(1703920)
addappid(1703921, 1, "66f6ff3415dcea18330b79ff8471868d5fb1124d38d4ee8f199e157ae3087909")
