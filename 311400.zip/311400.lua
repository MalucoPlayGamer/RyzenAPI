-- Lua provided by RyzenAPI
-- Game: addappid(311400)

-- MAIN APPLICATION
addappid(228983)
addappid(228990)
addappid(229002)
addappid(311400)

-- MAIN APP DEPOTS / PACKAGES
addappid(311406,0,"2914a494d7f400c225289409a0f9d721e4e9cd233f687f365e6ca43844ee35fd")
