-- Lua provided by RyzenAPI
-- Game: A.V.A Global

-- MAIN APPLICATION
addappid(1473480)
-- Game: addappid(1473480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473481, 1, "489412c62cb5a465d06b78ebaaae2698e037823fa6f37abac88621bc5633a568")
