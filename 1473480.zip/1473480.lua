-- 1473480's Lua and Manifest Created by Hubcap Manifest
-- A.V.A Global
-- Created: July 28, 2026 at 04:52:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 4
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(1473480, 1, "1c0d5ebc4aa7f6483ce20a4f1e81c7560a7ca223befa974aa197a3a58f8527e2") -- A.V.A Global
-- MAIN APP DEPOTS
addappid(1473481, 1, "489412c62cb5a465d06b78ebaaae2698e037823fa6f37abac88621bc5633a568") -- Depot 1473481
setManifestid(1473481, "1564977201741177838", 33634347465)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- PhysX System Software 9.12.1031 (Shared from App 228980)
setManifestid(229031, "7746630274301172884", 26729083)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2884850) -- A.V.A Global - Starters Pack
addappid(2884860) -- A.V.A Global - Masters Pack
addappid(2961160) -- A.V.A Global - Busters Content
addappid(2996300) -- A.V.A Global - Busters Content Lili Edition
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2884850) -- Depot 2884850 (empty depot)