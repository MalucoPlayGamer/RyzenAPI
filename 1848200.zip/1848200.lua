-- Lua provided by RyzenAPI 
-- Game: NEON STRUCT: Desperation Column
addappid(1848200)
addappid(1848201, 1, "0dfcf2f79c9c2c006d2d6cd01c32b66ea4363fba10f4fab4751a9e3748a2d192")
addappid(1848202, 1, "0b6df0859f1544cb537b88570f9b03d0ee9b5749688eac17a0b6f9b2eb325c09")
addappid(1848203, 1, "cae3f42f59a7f25d7c4de698b2f0242c35a41258efb43d71201cc4933eb75fc2")
