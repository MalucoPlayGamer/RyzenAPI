-- Lua provided by RyzenAPI 
-- Game: The True Love Rings
addappid(2010370)
addappid(2010371, 1, "aa68d767f8281bca02ce37e4315ab5c95636567d826d311430a41e7903ea133c")
addappid(2022630, 0, "64b77e6d55b38281c86b49d9d57a79340bef2fb9af428199ee706e20c6a58b56")
