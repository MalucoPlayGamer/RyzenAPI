-- Lua provided by RyzenAPI
-- Game: Humanity Asset

-- MAIN APPLICATION
addappid(271640)

-- MAIN APP DEPOTS / PACKAGES
addappid(271641, 1, "59592b12cae5e26fad64d7940622b539ce48f75cd764aa2d870aadcf092baca1")
