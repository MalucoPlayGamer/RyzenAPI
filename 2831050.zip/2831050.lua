-- Lua provided by RyzenAPI
-- Game: AppID 2831050

-- MAIN APPLICATION
addappid(2831050)
-- Game: addappid(2831050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831051, 1, "f696945073c5b740df737b041b365e9f3a3300b480e8257ea4bfa2d92fdd3f37")
