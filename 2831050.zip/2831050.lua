-- Lua provided by SkyAPI 
-- Game: AppID 2831050
addappid(2831050)
addappid(2831051, 1, "f696945073c5b740df737b041b365e9f3a3300b480e8257ea4bfa2d92fdd3f37")
