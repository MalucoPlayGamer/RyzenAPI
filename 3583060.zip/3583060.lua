-- Lua provided by RyzenAPI
-- Game: 3583060

-- MAIN APPLICATION
addappid(3583060)
-- Game: addappid(3583060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3583061, 1, "e10d5e76d2288bd2635bbc4b4f14f29ff309f1b989a20048776e5d066c123a87")
