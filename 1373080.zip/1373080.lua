-- Lua provided by RyzenAPI
-- Game: Twin Breaker: A Sacred Symbols Adventure

-- MAIN APPLICATION
addappid(1373080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373081, 1, "f59b988498c3bfd8ac0b2ca37ab078904f6038912802c55983f0593e4d7a37d9")

