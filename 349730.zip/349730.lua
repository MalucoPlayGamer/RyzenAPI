-- Lua provided by RyzenAPI
-- Game: addappid(349730)

-- MAIN APPLICATION
addappid(349730)

-- MAIN APP DEPOTS / PACKAGES
addappid(349731, 1, "8c67103f09df3a202d53cf14c1127e883f06a34f8223fc24c83d04efca7aa1d2")
