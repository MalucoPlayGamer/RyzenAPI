-- Lua provided by RyzenAPI
-- Game: Alice in Stardom - A Free Idol Visual Novel

-- MAIN APPLICATION
addappid(1054560)
-- Game: addappid(1054560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054561, 1, "558c26997e752103cad87e2149d68bc7351ca1cae85692edf75b2298295bfcc5")
