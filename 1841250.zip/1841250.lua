-- Lua provided by RyzenAPI 
-- Game: Hard Times at Sequoia State Park
addappid(1841250)
addappid(1841251, 1, "9669107e4c5eb07059b9863a38d2cc73786d596021b24712840b893fd6e76b63")
