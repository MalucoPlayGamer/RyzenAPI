-- Lua provided by RyzenAPI
-- Game: 风起洛阳 Demo

-- MAIN APPLICATION
addappid(2799540)
-- Game: addappid(2799540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799541, 1, "33fff399e1aa29b814d0a51912519624e3e20f0e561cb281043ff15c7b3cf01c")
