-- Lua provided by RyzenAPI
-- Game: Brain off

-- MAIN APPLICATION
addappid(1439030)
-- Game: addappid(1439030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439031, 1, "07ae60cd52c019da87a5732b61d4e455fc9653608a4a7365ba6a4c692fb296da")
