-- Lua provided by RyzenAPI
-- Game: Brain off

-- MAIN APPLICATION
addappid(1439030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439031, 1, "07ae60cd52c019da87a5732b61d4e455fc9653608a4a7365ba6a4c692fb296da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
