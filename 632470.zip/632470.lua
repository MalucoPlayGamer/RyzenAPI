-- Lua provided by RyzenAPI
-- Game: Disco Elysium

-- MAIN APPLICATION
addappid(632470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(632471, 1, "c1f12eca51041182cc2c6d43bf367dad67ca662865691b1beaac315b739fbf8e")
addappid(632473, 1, "d8f0c338ee47ed810ea03c7b20bea833cdf9eb8862d96cbb39d3f48da62920bf")
addappid(1173140, 0, "012eaa221b0a375c66d62ef1f37f67519f22863c8931e98cfc1517defaae5334")
