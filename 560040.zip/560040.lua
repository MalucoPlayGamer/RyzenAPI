-- Lua provided by SkyAPI 
-- Game: Minecraft: Story Mode - A Telltale Games Series Demo
addappid(560040)
addappid(560041, 1, "403a10411a7b5faf09d4c50e9443caea2d115b53bc8b048939aa386499759a4e")
