-- Lua provided by RyzenAPI
-- Game: AppID 763770

-- MAIN APPLICATION
addappid(763770)

-- MAIN APP DEPOTS / PACKAGES
addappid(763771, 1, "514f044cdbe324ed7cd0eb57665018d3d00602ca81b1bec76dba2980f419fe9c")
