-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Strong Point

-- MAIN APPLICATION
addappid(1246031)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246031,0,"0890b690096e02b173ea7e1388eafc57eaff993c78f852f48460784b863795cd")

