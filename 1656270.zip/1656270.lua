-- Lua provided by RyzenAPI
-- Game: Game: Crypto Shooter Demo

-- MAIN APPLICATION
addappid(1656270)
-- Game: addappid(1656270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656271, 1, "a2f285cc2c9b3fff49fb149ec8ec191eda569dfe11617a81b2a2a997dde64ee1")
