-- Lua provided by SkyAPI 
-- Game: Crypto Shooter Demo
addappid(1656270)
addappid(1656271, 1, "a2f285cc2c9b3fff49fb149ec8ec191eda569dfe11617a81b2a2a997dde64ee1")
