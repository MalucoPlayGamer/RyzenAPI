-- Lua provided by RyzenAPI
-- Game: setManifestid(296012,"4646662589533399405")

-- MAIN APPLICATION
addappid(296010)

-- MAIN APP DEPOTS / PACKAGES
addappid(296012,0,"7dd572c3fee9d6c5f9158acbd6257d4c3800a826dcbb607c63cdacb35a0ea776")
