-- Lua provided by RyzenAPI
-- Game: Game: Small Town Detective

-- MAIN APPLICATION
addappid(2243050)
-- Game: addappid(2243050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243051, 1, "03dcb3685dbe41aa7436fb57edcf3131bc5dfe8c5ead885d0a60b8f9cd859d9e")
