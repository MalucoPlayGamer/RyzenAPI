-- Lua provided by RyzenAPI
-- Game: addappid(988980)

-- MAIN APPLICATION
addappid(988980)

-- MAIN APP DEPOTS / PACKAGES
addappid(988981, 1, "5c8af7c6164a94d5db2f244e1b4a4a028725f0cb6fef845d77b7e335c8ff3ecc")
