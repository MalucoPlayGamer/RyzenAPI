-- Lua provided by RyzenAPI
-- Game: Street Fighter™ 6: World Tour

-- MAIN APPLICATION
addappid(1792751)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792751,0,"b47545f3d9f54a63bd3cfe4028c8510ad05aead03842627326793508414ba122")

