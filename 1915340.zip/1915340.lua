-- Lua provided by RyzenAPI
-- Game: addappid(1915340)

-- MAIN APPLICATION
addappid(1915340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915341, 1, "2f62dfb59db59ecb3ce6c0643ca2a808b6dabd8abb0b57838d47db65ca508cdc")
