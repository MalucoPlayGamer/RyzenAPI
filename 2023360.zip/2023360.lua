-- Lua provided by RyzenAPI
-- Game: addappid(2023360)

-- MAIN APPLICATION
addappid(2023360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023361, 1, "0bc43f344df399849d866b3269e45024e647d4cfbe07af3e41176888d40c088a")
addappid(2402850, 0, "e29c6c01e3cdc5d5157a6106c1b0ecf8e654e2b007d4efea075a4f52f1ea1daf")
