-- Lua provided by RyzenAPI
-- Game: Quest of Wizard

-- MAIN APPLICATION
addappid(1723570)
-- Game: addappid(1723570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723571, 1, "2c6325683a7f7e59eb9f32f88dfd7546d965c4e2eef61e70a30c686b78cbc32c")
