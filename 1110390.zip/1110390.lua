-- Lua provided by RyzenAPI
-- Game: Unturned - Dedicated Server

-- MAIN APPLICATION
addappid(1110390)
-- Game: addappid(1110390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110391, 1, "0b0144375a9b906d593c5bcb567383856495ba5d4c230ce3a8de771955f1cddf")
addappid(1110392, 1, "e10209445f9cde26ac7c213edf1a3549ac70618627ab07648243f4fbe90a0ca4")
addappid(1110393, 1, "931d267a0c5596dc6f4d7a806a83c3635f3f06fded4d9c08e2bf14b1864f53b5")
addappid(1110394, 1, "391a45bdb71c33afbf925403879823d44a617f923e63dfe193039ccb6473ebc9")
