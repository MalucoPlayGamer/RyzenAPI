-- Lua provided by RyzenAPI
-- Game: 2295450

-- MAIN APPLICATION
addappid(2295450)
-- Game: addappid(2295450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295451, 1, "fc5f4bbc7bd856d57d50f7178ebc683c58dcc66db7593ab2bbba50190c0d0389")
