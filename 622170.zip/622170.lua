-- Lua provided by RyzenAPI
-- Game: Offensive Combat: Redux!

-- MAIN APPLICATION
addappid(622170)

-- MAIN APP DEPOTS / PACKAGES
addappid(622171, 1, "a6a8df923cd042666c8b79dc2ea8e42ca68c4acb06738adfb1dc4eb1f7cfb3d3")
