-- Lua provided by RyzenAPI
-- Game: Game: The Sumerian Game

-- MAIN APPLICATION
addappid(2699250)
addappid(3036790)
-- Game: addappid(2699250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699251, 1, "496adef9db87c8dd63e474b0950515ca6ee4ab71abe0b62e367f3e115903fcbe")
addappid(2699252, 1, "92ff40b52c0db773b04abdcd31a2ffb1e994941a37313ec128bae8a362c73cbf")
addappid(2699253, 1, "5c07563e937f8cc6f19bac8eaf34285832fc69ba85cc7a4a1df3505c74be2ca8")
