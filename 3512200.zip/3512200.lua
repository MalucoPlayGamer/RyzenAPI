-- Lua provided by RyzenAPI
-- Game: Forest Asylum

-- MAIN APPLICATION
addappid(3512200)
-- Game: addappid(3512200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3512201, 1, "e603952808c1b0f68eb2676f975c4551f2b16567892ac5329252a7560f9a71d5")
