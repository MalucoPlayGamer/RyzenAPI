-- Lua provided by RyzenAPI
-- Game: Forest Asylum

-- MAIN APPLICATION
addappid(3512200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3512201, 1, "e603952808c1b0f68eb2676f975c4551f2b16567892ac5329252a7560f9a71d5")

