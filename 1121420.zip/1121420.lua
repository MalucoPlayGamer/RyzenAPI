-- Lua provided by RyzenAPI
-- Game: addappid(1121420)

-- MAIN APPLICATION
addappid(1121420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121421, 1, "726e12848fd329a4db013eb0b519b3d79f0e072c21b517934f11cd0ae6c5c085")
