-- Lua provided by RyzenAPI
-- Game: Game: Eastwind Adventures: Chapter 1

-- MAIN APPLICATION
addappid(1656870)
-- Game: addappid(1656870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656871, 1, "50c61d2e2278fa0548db03fedcba6fa542b30719e6671c217ac27cfed742d655")
