-- Lua provided by RyzenAPI
-- Game: AppID 1758110

-- MAIN APPLICATION
addappid(1758110)
-- Game: addappid(1758110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758111, 1, "dea47f5b6d1e89b3c4f7a6a1ddf8cb06d039bd50ef00f207265254bc1b60d387")
