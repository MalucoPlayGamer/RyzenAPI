-- Lua provided by RyzenAPI
-- Game: AppID 599460

-- MAIN APPLICATION
addappid(599460)

-- MAIN APP DEPOTS / PACKAGES
addappid(599461, 1, "61c232f11f72565e9a55439a648b64acea77751842c57ea761b91bd5237679fb")
addappid(599462, 1, "7d9a8babbe3e27fd4ae7cff982a0f9ca0b79b845a58bee89da19c6235c161f17")
addappid(599463, 1, "0b4297d580264babb62026d77b16a1b481613101bdd37077f140de616263586e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
