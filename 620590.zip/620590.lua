-- Lua provided by RyzenAPI
-- Game: Ancestors Legacy

-- MAIN APPLICATION
addappid(620590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(620591, 1, "c05d71a54366c4e3cc54510ce7b86e22f8e7e9969c6630ff2e3629aca04b8957")
addappid(799330, 0, "adf2c438e9d49e7fc0fa3bf282c0c30a4be23996eab6195a5caf675adf6b5206")
addappid(1100220, 0, "63e7c8b413bc5af6fce1c711438aa9e3b52427a8bc920fe584774f04124c70af")

