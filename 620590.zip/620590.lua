-- Lua provided by RyzenAPI
-- Game: addappid(620590)

-- MAIN APPLICATION
addappid(620590)

-- MAIN APP DEPOTS / PACKAGES
addappid(620591, 1, "c05d71a54366c4e3cc54510ce7b86e22f8e7e9969c6630ff2e3629aca04b8957")
addappid(799330, 0, "adf2c438e9d49e7fc0fa3bf282c0c30a4be23996eab6195a5caf675adf6b5206")
addappid(1100220, 0, "63e7c8b413bc5af6fce1c711438aa9e3b52427a8bc920fe584774f04124c70af")
