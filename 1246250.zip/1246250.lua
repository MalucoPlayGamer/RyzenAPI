-- Lua provided by RyzenAPI
-- Game: AppID 1246250

-- MAIN APPLICATION
addappid(1246250)
-- Game: addappid(1246250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246251, 1, "02737ceb4019f16036cfe2fcfdf8497e955dad7edd0321af61ac9bfa910787d8")
