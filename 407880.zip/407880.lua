-- Lua provided by RyzenAPI
-- Game: Game: Mad Nords: Probably an Epic Quest

-- MAIN APPLICATION
addappid(407880)
-- Game: addappid(407880)

-- MAIN APP DEPOTS / PACKAGES
addappid(407881, 1, "66ba3f21c601874e51d9aeafe6bb6275068a2caa2e806fab07014afa1323618c")
addappid(407882, 1, "b0a5e6d27cce70c25961e019c0fcb3979a9f05d03caecedd873f984de49e9c7b")
addappid(407883, 1, "16645c31c8118996e96fbaf77b0d00dbc1c18f5f453b92d352eaf513c9d5f916")
addappid(407884, 1, "8811f93441987e406c78fb827d5d2eaab303466932bfcd086574f7fa39855b47")
addappid(407885, 1, "6550e7b3ee4d3f7f3011e8afad24abe20079f5ff2ad7faf6f5fbc2a37cba5d5f")
