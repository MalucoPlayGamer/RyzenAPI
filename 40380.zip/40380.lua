-- Lua provided by RyzenAPI
-- Game: nail'd

-- MAIN APPLICATION
addappid(40380)
-- Game: addappid(40380)

-- MAIN APP DEPOTS / PACKAGES
addappid(40381, 1, "a084b4610db8cb692e0596db24b8dfa92d3909171dfd707e36fda533579d29e3")
addappid(40382, 1, "0d33b7a70cea78964fb38d797a0369f1513aedd345af986395a6230f1269bbeb")
addappid(40383, 1, "5cfa25f82e07281de6c1cb90c34a87dd42ef010f3b0b6e3d46b601c40e5251d6")
addappid(40384, 1, "cfc63df2978564971be0cc6aa8f8793ced5efe1cbbc795b1caa88b2cc0664839")
addappid(40385, 1, "c3f7fa88644b33e7684cefd03473307fc73ba4f12a91e9e9fbc422f43c1299b0")
