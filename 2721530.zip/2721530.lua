-- Lua provided by RyzenAPI
-- Game: Game: Afterplace

-- MAIN APPLICATION
addappid(2721530)
-- Game: addappid(2721530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721531, 1, "f8999413b26acdf61b4709358213fea4765769bec1b851e78c36091e905fc553")
