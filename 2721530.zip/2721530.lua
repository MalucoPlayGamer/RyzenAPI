-- Lua provided by SkyAPI 
-- Game: Afterplace
addappid(2721530)
addappid(2721531, 1, "f8999413b26acdf61b4709358213fea4765769bec1b851e78c36091e905fc553")
