-- Lua provided by RyzenAPI
-- Game: AppID 356640

-- MAIN APPLICATION
addappid(356640)
-- Game: addappid(356640)

-- MAIN APP DEPOTS / PACKAGES
addappid(356641, 1, "8251c8d7b574c4f3091ee863317db323f58d2d7444d03a9959bc713c0d7da5b0")
