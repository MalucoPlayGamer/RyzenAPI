-- Lua provided by RyzenAPI
-- Game: Metro Conflict

-- MAIN APPLICATION
addappid(356640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(356641, 1, "8251c8d7b574c4f3091ee863317db323f58d2d7444d03a9959bc713c0d7da5b0")

