-- Lua provided by RyzenAPI
-- Game: FUSER™ - 24kGoldn ft. iann dior - "Mood"

-- MAIN APPLICATION
addappid(1494602)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494602,0,"641a20609870a81d6ec6679e630967265fbbbb08a935ca160ef8e347e30fd28e")

