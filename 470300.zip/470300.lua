-- Lua provided by RyzenAPI
-- Game: Game: Winged Sakura: Demon Civil War

-- MAIN APPLICATION
addappid(470300)
addappid(563670)
-- Game: addappid(470300)

-- MAIN APP DEPOTS / PACKAGES
addappid(470301, 1, "fc99dc32cc4d3456604922310c338f63f59880294bac6f042237932ad45ec2ac")
addappid(470302, 1, "04ff51e3ebcd9e741197acba88878d2f6e7a31a43c6e7a5a3416641829b81a90")
addappid(470303, 1, "f62138403485f412b2d23e0a00e1253c0a07d6acbc30d0378ab11e869baed874")
addappid(470304, 1, "053444ed95914bd3a5b52aa282bc68ced3e65613582092965b63779c9629c238")
