-- Lua provided by SkyAPI 
-- Game: AppID 1051410
addappid(1051410)
addappid(1051411, 1, "ad28f1794a6a43e050cbb829e4db88f53a439c3037a264b381a8f43d9e14f4bc")
