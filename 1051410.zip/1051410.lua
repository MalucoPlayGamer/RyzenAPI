-- Lua provided by RyzenAPI
-- Game: Wanderlust: Travel Stories

-- MAIN APPLICATION
addappid(1051410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051411, 1, "ad28f1794a6a43e050cbb829e4db88f53a439c3037a264b381a8f43d9e14f4bc")

