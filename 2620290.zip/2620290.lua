-- Lua provided by RyzenAPI
-- Game: Divine Pig

-- MAIN APPLICATION
addappid(2620290) -- Divine Pig

-- MAIN APP DEPOTS / PACKAGES
addappid(2620291, 1, "8fdcd9bfebbdbddccd161d1aff9db570042f08e4c2fbf12e1347ed424b5a4975") -- Depot 2620291

