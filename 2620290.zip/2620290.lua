-- 2620290's Lua and Manifest Created by Hubcap Manifest
-- Divine Pig
-- Created: August 16, 2026 at 07:14:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2620290) -- Divine Pig
-- MAIN APP DEPOTS
addappid(2620291, 1, "8fdcd9bfebbdbddccd161d1aff9db570042f08e4c2fbf12e1347ed424b5a4975") -- Depot 2620291
setManifestid(2620291, "6241937024402764429", 5816458113)