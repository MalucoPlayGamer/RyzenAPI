-- Lua provided by RyzenAPI
-- Game: Jrago Destruction Breeds Creation

-- MAIN APPLICATION
addappid(2526350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526352,0,"ea9608c4495de6d0ce3b3c3b0aba61e36a46df08b7fc62d335f255bba5da2ba7")
