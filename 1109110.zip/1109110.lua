-- Lua provided by RyzenAPI
-- Game: addappid(1109110)

-- MAIN APPLICATION
addappid(1109110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109111, 1, "18d13d0951a732c1fa05c354eb378046fcd3b6baabd3b3335a9d022ddc9ab357")
