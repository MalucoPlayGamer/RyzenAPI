-- Lua provided by RyzenAPI
-- Game: Sledgehammer / Gear Grinder

-- MAIN APPLICATION
addappid(285520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(285521, 1, "eb150b388e47857fdfaf1c487d600964b31099741f85cad200a13f9a9ffe5ddc")
addappid(285522, 1, "c016909b329b7cd50ae44b0fe23159d968b52921f0c57558fe80cca4101cdaf7")
addappid(285523, 1, "0ee21c6398a79425b921a491d462871b552b29b5cb1fa7a519168fa0c8b4eff5")
addappid(285524, 1, "39aff01c73272d2d68a12e29ba5f205b30efe29c099e22d8383db97cbb8aa34a")
addappid(285525, 1, "157b8290826a51799b2620c69281269db7d8581ced7420633d15c4f97ae4a8be")
addappid(285526, 1, "d39a793b2caae97ecefc276a474f9123e07d354249b7fcafad8c3e3d83216a6b")

