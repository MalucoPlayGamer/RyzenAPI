-- Lua provided by SkyAPI 
-- Game: The Path of Ren
addappid(1619920)
addappid(1619921, 1, "2b1292ec5c3f780b432fba2d12b895645eccf3a8a758e049ff934c6e2730095b")
