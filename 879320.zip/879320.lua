-- Lua provided by RyzenAPI
-- Game: Game: Street Karate

-- MAIN APPLICATION
addappid(879320)
-- Game: addappid(879320)

-- MAIN APP DEPOTS / PACKAGES
addappid(879321, 1, "8606750485f60b6d0a9fb31163cb7a614e69fafab31dab751ef5c3aa85002696")
addappid(879330, 0, "c43d52f022ca02bc7bba0c94cf34441f91cd64602225d6ab476487c5a0227c86")
