-- Lua provided by RyzenAPI
-- Game: addappid(2598750)

-- MAIN APPLICATION
addappid(2598750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598751, 1, "1d04b666fd969bae62cbd192770d393e84abd18cc282fa339d029759283ce193")
