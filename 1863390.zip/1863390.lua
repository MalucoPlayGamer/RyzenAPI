-- Lua provided by RyzenAPI 
-- Game: N-Age: Awakening
addappid(1863390)
addappid(1863391, 1, "e71fc456d9e32a5f5cd733b71e9c073db0aa99700e0d31c8b65b7700eb26ec52")
