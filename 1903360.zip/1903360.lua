-- Lua provided by RyzenAPI
-- Game: Game: AppID 1903360

-- MAIN APPLICATION
addappid(1903360)
-- Game: addappid(1903360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903361, 1, "35b303196adf312d3a3371c7efdf25e58a9646d38850773e3e91273a91a29f71")
