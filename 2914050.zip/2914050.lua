-- Lua provided by RyzenAPI
-- Game: Jugs Bay

-- MAIN APPLICATION
addappid(2914050)
-- Game: addappid(2914050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914052,0,"07dc89651676149b0a0328077bed98f1333c5528b0ce452173ab8067ac3d1790")
