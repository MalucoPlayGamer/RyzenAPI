-- Lua provided by RyzenAPI
-- Game: Jugs Bay

-- MAIN APPLICATION
addappid(2914050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914052,0,"07dc89651676149b0a0328077bed98f1333c5528b0ce452173ab8067ac3d1790")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
