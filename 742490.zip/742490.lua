-- Lua provided by SkyAPI 
-- Game: AppID 742490
addappid(742490)
addappid(742491, 1, "095208101e4914cd4fc36d9f1c5c9afb2e70dabee44deadca5cc23370d1699d7")
