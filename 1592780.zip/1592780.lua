-- Lua provided by RyzenAPI
-- Game: addappid(1592780)

-- MAIN APPLICATION
addappid(1592780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592783,0,"3caba34c4d798a43dd7c2cf24c890656915a3927d2517eb6b115ff0ccbd27f94")
