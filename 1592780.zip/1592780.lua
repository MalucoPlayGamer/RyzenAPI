-- Lua provided by RyzenAPI
-- Game: ELIF

-- MAIN APPLICATION
addappid(1592780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1592783,0,"3caba34c4d798a43dd7c2cf24c890656915a3927d2517eb6b115ff0ccbd27f94")

