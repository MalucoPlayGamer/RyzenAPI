-- Lua provided by RyzenAPI
-- Game: 基础人体学习软件

-- MAIN APPLICATION
addappid(2885800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885801, 1, "8bb3c1f5b7c12e7714a930168213cceecb3539a956425fa4e550e936d4333c34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
