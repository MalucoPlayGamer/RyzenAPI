-- Lua provided by RyzenAPI
-- Game: 基础人体学习软件

-- MAIN APPLICATION
addappid(2885800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885801, 1, "8bb3c1f5b7c12e7714a930168213cceecb3539a956425fa4e550e936d4333c34")

