-- Lua provided by RyzenAPI
-- Game: Who wants to strip this babe? Streamer Girl

-- MAIN APPLICATION
addappid(1076210)
-- Game: addappid(1076210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076211, 1, "f247174817332354621f09e48506e150d7634b98c9a2e5ea005c666c9c64f33c")
