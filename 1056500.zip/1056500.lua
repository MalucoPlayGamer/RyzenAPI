-- Lua provided by RyzenAPI
-- Game: Game: VRLife

-- MAIN APPLICATION
addappid(1056500)
-- Game: addappid(1056500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056501, 1, "e643317350446876cfd373b68a36ccb8c76549784de7e73686ae0e6f93d0f2c1")
