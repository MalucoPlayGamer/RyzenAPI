-- Lua provided by RyzenAPI
-- Game: Game: Tin Can Soundtrack

-- MAIN APPLICATION
addappid(1678370)
-- Game: addappid(1678370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678371, 1, "85ddec39b27df3b51f18f81149be0bc0a69e38cd5b9ef7b5df2c9d1f606ef7b7")
addappid(1678372, 1, "ed22bf7f75ab87f856e4f0f45da5be0280fe1e1532766ba0147abf0d34e637be")
