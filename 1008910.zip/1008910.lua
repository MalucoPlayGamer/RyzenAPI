-- Lua provided by RyzenAPI
-- Game: 心塞男孩 Sadboy

-- MAIN APPLICATION
addappid(1008910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008911, 1, "a6b48de96945b8b8890a874f402c941e8822f0596bf075d0cbf4e026abef4293")
