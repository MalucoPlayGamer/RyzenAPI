-- Lua provided by RyzenAPI
-- Game: Guildford Castle VR

-- MAIN APPLICATION
addappid(1862880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862881, 1, "553ffe1964d7e22adec09fa1f13b17b06c28659e21cc35149598dd6ba7e22d2b")

