-- Lua provided by RyzenAPI
-- Game: AppID 1424930

-- MAIN APPLICATION
addappid(1424930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424931, 1, "9de49eccc484f0d4ff4d015ea90e2345aeaa7c17dcdb4bb628798b922882bb62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
