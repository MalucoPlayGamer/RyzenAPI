-- Lua provided by RyzenAPI
-- Game: AppID 1424930

-- MAIN APPLICATION
addappid(1424930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424931, 1, "9de49eccc484f0d4ff4d015ea90e2345aeaa7c17dcdb4bb628798b922882bb62")
