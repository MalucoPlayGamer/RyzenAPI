-- Lua provided by SkyAPI 
-- Game: Hexagonal Tower
addappid(1931090)
addappid(1931091, 1, "f24b3b83892011b8867dceb44c72446e453d3292ce823c0069dc6b2294e6e3c2")
