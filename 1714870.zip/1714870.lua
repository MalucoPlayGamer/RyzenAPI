-- Lua provided by RyzenAPI
-- Game: 1714870

-- MAIN APPLICATION
addappid(1714870)
-- Game: addappid(1714870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714871, 1, "6ab86016937fb9fb5f00042d554ade08fd0518ead729d8bed9e6486caa3999db")
