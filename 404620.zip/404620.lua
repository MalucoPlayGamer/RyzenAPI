-- Lua provided by RyzenAPI
-- Game: 404620

-- MAIN APPLICATION
addappid(404620)
-- Game: addappid(404620)

-- MAIN APP DEPOTS / PACKAGES
addappid(404621, 1, "9733fc69d6ff7c0058c085ad447b7003261f505f185506bd2194d32fc8e6110e")
