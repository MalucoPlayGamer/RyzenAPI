-- Lua provided by RyzenAPI
-- Game: The Political Machine 2016

-- MAIN APPLICATION
addappid(404620)
addappid(495380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(404621, 1, "9733fc69d6ff7c0058c085ad447b7003261f505f185506bd2194d32fc8e6110e")
