-- Lua provided by RyzenAPI 
-- Game: Mighty Switch Force! Academy
addappid(350210)
addappid(350211, 1, "82d05470108b210e1154e45216146db632abd2b3b2668a536f713f89d1b363a6")
