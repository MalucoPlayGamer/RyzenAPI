-- Lua provided by RyzenAPI
-- Game: Archimedes

-- MAIN APPLICATION
addappid(530920)

-- MAIN APP DEPOTS / PACKAGES
addappid(530921, 1, "fa0be9800b538a4d6bbf28c5ad3d69a6ce139e148351498603ca996f7b350b2e")
addappid(530922, 1, "f5193cae554203b84666faa5afd1967b5b9da20d5fe0dc0a803cf46a9712b5d5")
addappid(530923, 1, "0b0af2ea6b6652bb919477ef151bf048c090b1cf6e7af142159273fa9dbefac9")
addappid(530924, 1, "0c1897dbb35dee5543c3dac9c3220b294aca75330bf57fbf93572e234364bc8a")
addappid(530925, 1, "2dfc76df3e5702cbee877c77d0b7d439cbd814182ba669f482f920f5f4603139")

