-- Lua provided by RyzenAPI
-- Game: Temporal Purge: Z

-- MAIN APPLICATION
addappid(1503400)
addappid(3163270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503401, 1, "ace38255bdf2c6f3c56934d241259b23a8b354bb86cf22446b89c92d2db0f2f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
