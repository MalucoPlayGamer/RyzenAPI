-- Lua provided by RyzenAPI
-- Game: Game: Temporal Purge: Z

-- MAIN APPLICATION
addappid(1503400)
addappid(3163270)
-- Game: addappid(1503400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503401, 1, "ace38255bdf2c6f3c56934d241259b23a8b354bb86cf22446b89c92d2db0f2f0")
