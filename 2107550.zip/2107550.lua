-- Lua provided by RyzenAPI
-- Game: Valley Peaks

-- MAIN APPLICATION
addappid(2107550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107551, 1, "25cb1171113f29b6ca251704d4f8018eaa3966695e6a53f1c1e5f4418c7320cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
