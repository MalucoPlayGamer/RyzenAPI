-- Lua provided by RyzenAPI
-- Game: Game: Valley Peaks

-- MAIN APPLICATION
addappid(2107550)
-- Game: addappid(2107550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107551, 1, "25cb1171113f29b6ca251704d4f8018eaa3966695e6a53f1c1e5f4418c7320cf")
