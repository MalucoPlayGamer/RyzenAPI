-- Lua provided by RyzenAPI
-- Game: VIRA

-- MAIN APPLICATION
addappid(2338860)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(2338861, 1, "ea25f4412181d99b84de1746dee7bd9bcd9390303a2c0ec4a8f4584824558369")
addappid(2338862, 1, "098c2fd88431ea73646491dfc163e4ebe52b2df855ee7c61e50b9470cf7c710b")
addappid(2338863, 1, "7a3183df7a43d2aeee5a37eccbc52e0414b680e13a01363523a1cd3f2f634f15")

