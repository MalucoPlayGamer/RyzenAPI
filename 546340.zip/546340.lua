-- Lua provided by RyzenAPI
-- Game: Dynamic

-- MAIN APPLICATION
addappid(546340)
addappid(594610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(546341, 1, "d0f7e00ce18b7dd9f38de95bbd1d386a1c7ba105f86020d7dcb711ba89f171d4")
