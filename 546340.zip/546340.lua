-- Lua provided by RyzenAPI
-- Game: AppID 546340

-- MAIN APPLICATION
addappid(546340)
addappid(594610)

-- MAIN APP DEPOTS / PACKAGES
addappid(546341, 1, "d0f7e00ce18b7dd9f38de95bbd1d386a1c7ba105f86020d7dcb711ba89f171d4")

