-- Lua provided by RyzenAPI
-- Game: addappid(706560)

-- MAIN APPLICATION
addappid(706560)

-- MAIN APP DEPOTS / PACKAGES
addappid(706561, 1, "caf3b2ae70548e0f86eed2fdbbc30e969db0c62b963ec751f6f4976c4a144137")
