-- Lua provided by RyzenAPI
-- Game: AppID 706560

-- MAIN APPLICATION
addappid(706560)

-- MAIN APP DEPOTS / PACKAGES
addappid(706561, 1, "caf3b2ae70548e0f86eed2fdbbc30e969db0c62b963ec751f6f4976c4a144137")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(912270)
