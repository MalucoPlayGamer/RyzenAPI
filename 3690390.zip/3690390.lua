-- Lua provided by RyzenAPI
-- Game: Pictective

-- MAIN APPLICATION
addappid(3690390) -- Pictective

-- MAIN APP DEPOTS / PACKAGES
addappid(3690391, 1, "97bc7a933163bb679b1c8b53da50cf7ac2de0e478e8da08bf7b646f0cf045a54") -- Depot 3690391

