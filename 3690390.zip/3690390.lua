-- 3690390's Lua and Manifest Created by Hubcap Manifest
-- Pictective
-- Created: August 23, 2026 at 12:25:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3690390) -- Pictective
-- MAIN APP DEPOTS
addappid(3690391, 1, "97bc7a933163bb679b1c8b53da50cf7ac2de0e478e8da08bf7b646f0cf045a54") -- Depot 3690391
setManifestid(3690391, "8154885781123057580", 447582951)