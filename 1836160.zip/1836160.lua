-- Lua provided by RyzenAPI
-- Game: PANELKI

-- MAIN APPLICATION
addappid(1836160)
addappid(2258920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1836161, 1, "88d16d6da589bf58001edd0d7ab5434950ac40e7e3411f0f8666eda42a049096")
addappid(2018100, 0, "79d0b98e8d0db4b420b5721021dff5b627fa95e888a05d880869b145e93f9b0f")

