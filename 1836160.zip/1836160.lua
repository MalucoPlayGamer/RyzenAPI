-- Lua provided by RyzenAPI 
-- Game: PANELKI
addappid(1836160)
addappid(1836161, 1, "88d16d6da589bf58001edd0d7ab5434950ac40e7e3411f0f8666eda42a049096")
addappid(2018100, 0, "79d0b98e8d0db4b420b5721021dff5b627fa95e888a05d880869b145e93f9b0f")
