-- Lua provided by RyzenAPI
-- Game: AppID 223540

-- MAIN APPLICATION
addappid(223540)
-- Game: addappid(223540)

-- MAIN APP DEPOTS / PACKAGES
addappid(223541, 1, "508d7718267a64f2a6801749ed3a5d7460dd064a21e42bdce7827e7956666bcf")
