-- Lua provided by RyzenAPI
-- Game: I HAVE A DREAM

-- MAIN APPLICATION
addappid(2446320)
-- Game: addappid(2446320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446321, 1, "2804a6ba2a42362b7cd1559d57a8d9f9d56a0d182c4c85e9c7892b0717879feb")
