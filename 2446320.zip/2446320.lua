-- Lua provided by SkyAPI 
-- Game: I HAVE A DREAM
addappid(2446320)
addappid(2446321, 1, "2804a6ba2a42362b7cd1559d57a8d9f9d56a0d182c4c85e9c7892b0717879feb")
