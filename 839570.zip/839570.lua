-- Lua provided by RyzenAPI
-- Game: What Are You Stupid

-- MAIN APPLICATION
addappid(839570)

-- MAIN APP DEPOTS / PACKAGES
addappid(839571,0,"18223aaa7cd7fd6c1f03435af26eb6483924682dbeb295504f8b10eddbf506f6")

