-- Lua provided by RyzenAPI
-- Game: Bouncemasters

-- MAIN APPLICATION
addappid(3697340)

