-- Lua provided by RyzenAPI
-- Game: Bouncemasters

-- MAIN APPLICATION
addappid(3697340)
addappid(4126460)
addappid(4208670)
addappid(4266370)
addappid(4393550)
addappid(4393590)
addappid(4575590)

