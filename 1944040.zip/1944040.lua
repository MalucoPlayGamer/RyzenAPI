-- Lua provided by RyzenAPI
-- Game: goblinAmerica

-- MAIN APPLICATION
addappid(1944040) -- goblinAmerica

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1944042, 1, "6aa265c57de06efa030af2efd18a629b43e54be0239bbaa52a49ff5fb08068f2")

