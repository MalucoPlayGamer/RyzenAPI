-- Lua provided by RyzenAPI
-- Game: goblinAmerica

-- MAIN APPLICATION
addappid(1944040) -- goblinAmerica

-- MAIN APP DEPOTS / PACKAGES
addappid(1944042, 1, "6aa265c57de06efa030af2efd18a629b43e54be0239bbaa52a49ff5fb08068f2")

