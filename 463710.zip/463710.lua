-- Lua provided by RyzenAPI
-- Game: 463710

-- MAIN APPLICATION
addappid(463710)
-- Game: addappid(463710)

-- MAIN APP DEPOTS / PACKAGES
addappid(463711, 1, "d4c5fdd5cfa72771e37bf994bd5d66e957849ffc629822dd7d9f1b79639b9fe5")
addappid(463712, 1, "055384e8c143200cc75276ade14a4f8e013bfda3c2e8f38be71119da722ea912")
