-- Lua provided by RyzenAPI
-- Game: Fate/Samurai Remnant Digital Artbook & Soundtrack

-- MAIN APPLICATION
addappid(2426930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426930,0,"806974bd1ef3c87685e036622b684475f53f159bca5c91e1130c48b84321ef42")

