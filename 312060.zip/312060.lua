-- Lua provided by RyzenAPI
-- Game: addappid(312060)

-- MAIN APPLICATION
addappid(39211)
addappid(312060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
