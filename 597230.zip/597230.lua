-- Lua provided by RyzenAPI
-- Game: AppID 597230

-- MAIN APPLICATION
addappid(597230)

-- MAIN APP DEPOTS / PACKAGES
addappid(597231, 1, "adbb5da9aa6d2ef877ff7e13d8b4ef676c3a76a918a7d582cfae328fb6342414")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
