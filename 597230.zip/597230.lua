-- Lua provided by RyzenAPI 
-- Game: AppID 597230
addappid(597230)
addappid(597231, 1, "adbb5da9aa6d2ef877ff7e13d8b4ef676c3a76a918a7d582cfae328fb6342414")
