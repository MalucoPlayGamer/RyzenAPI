-- Lua provided by RyzenAPI
-- Game: addappid(2015350)

-- MAIN APPLICATION
addappid(2015350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015351, 1, "2fb3386193e5fabf58b022f58aa212b5dfe3f9cd5825f900eb98705661b24cd4")
