-- Lua provided by RyzenAPI
-- Game: They Breathe

-- MAIN APPLICATION
addappid(294140)

-- MAIN APP DEPOTS / PACKAGES
addappid(294141, 1, "c1561415744c0f241fe37dd34c3ed3c996e4c0e7f363231f81d599702408afe1")
addappid(294142, 1, "7ff71fdc5a66d22eecdbab917e7d824aa7ecaced64961b0900d9f957cd64dd64")

