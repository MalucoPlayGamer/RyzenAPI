-- Lua provided by RyzenAPI
-- Game: They Breathe

-- MAIN APPLICATION
addappid(294140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(294141, 1, "c1561415744c0f241fe37dd34c3ed3c996e4c0e7f363231f81d599702408afe1")
addappid(294142, 1, "7ff71fdc5a66d22eecdbab917e7d824aa7ecaced64961b0900d9f957cd64dd64")

