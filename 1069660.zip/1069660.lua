-- Lua provided by RyzenAPI
-- Game: AppID 1069660

-- MAIN APPLICATION
addappid(1069660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069661, 1, "2ac313c2c0171e5f729d2433e47d343eba402d3d3440484e74b2731db0368126")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2672570)
