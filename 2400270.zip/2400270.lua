-- Lua provided by RyzenAPI 
-- Game: Blades of Jianghu: Ballad of Wind and Dust -Soundtrack-
addappid(2400270)
addappid(2400271, 1, "65d58263fbe11e91305a9239ddc3900d04cb1d61c940b283ff0807319c90a922")
addappid(2400272, 1, "8a8ca3a9769cfd93d8eb23a278bb984429483e24cb73a18f98a382383c846418")
