-- Lua provided by RyzenAPI 
-- Game: Lost Castle 2
addappid(2445690)
addappid(2445691, 1, "58aa213ce335109a11490383c49a406f0bb7a5c68f2844e33e7883c4e70dc1b3")
addappid(2445695, 1, "91b6b4a727098238ce348dc1f01e054f447397b059c1523e79f9ebf765484d74")
