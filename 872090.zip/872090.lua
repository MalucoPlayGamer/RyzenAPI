-- Lua provided by RyzenAPI
-- Game: Freezeer

-- MAIN APPLICATION
addappid(872090)
-- Game: addappid(872090)

-- MAIN APP DEPOTS / PACKAGES
addappid(872091, 1, "5fb7ac3b0fb4e6ee72aae623061b098ca8d0b23385434b9df36945c86dd5f6e5")
