-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1290423)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290423,0,"f7dc67b809a8f7a176d9419f8a721153c9533c722fb696fb2823a54e6728818e")
addappid(1290440,0,"47c7c58881aa7a2b9ba0477a27ab6c2d4b9d839023590a17d826afb93c0baa1d")
addappid(1290441,0,"d97926fb2c8c85d0acbd96564aaacd1e4b6667699606bb2dd7db107a35e04e21")
addappid(1290442,0,"accebe3745890347762a6b0b37c1ab2c6c6694e1a53dbd3cc949b67b618f98d7")
addappid(1290443,0,"978d67c43cb4b58a6bcc9aa8ce304dd9a1238db6a3458c2b99f55b1d28f35f1a")
addappid(1290444,0,"fd89d3770029802053a2487610f2251ba0cce4f12f913882e2a6334ed306fbc8")
addappid(1290445,0,"5ccb57ae1bc2d09d9f470ce2ea8531c65c522c203f9985d5e68a5cf27cd5376d")
addappid(1290446,0,"eb5e01663af8d151fbea775f975a77e785105db8171b2df947d14d8e61e27afa")
addappid(1290447,0,"19198e8131d9d435a6e9260b7a8ff359391293bf40da97df3f3c6d69c225344e")
