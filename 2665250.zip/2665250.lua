-- 2665250's Lua and Manifest Created by Hubcap Manifest
-- Rancher: A new life
-- Created: August 06, 2026 at 11:36:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2665250) -- Rancher: A new life
-- MAIN APP DEPOTS
addappid(2665251, 1, "0c6b69f8c5c30ae8c21d2a971385e06d0c67e95d25f226de1e45157ca7b54c9b") -- Depot 2665251
setManifestid(2665251, "2078467139668616744", 9151172904)