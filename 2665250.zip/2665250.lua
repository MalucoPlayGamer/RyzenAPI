-- Lua provided by RyzenAPI
-- Game: Rancher: A new life

-- MAIN APPLICATION
addappid(2665250) -- Rancher: A new life

-- MAIN APP DEPOTS / PACKAGES
addappid(2665251, 1, "0c6b69f8c5c30ae8c21d2a971385e06d0c67e95d25f226de1e45157ca7b54c9b") -- Depot 2665251

