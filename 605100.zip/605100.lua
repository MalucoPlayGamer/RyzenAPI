-- Lua provided by RyzenAPI
-- Game: addappid(605100)

-- MAIN APPLICATION
addappid(605100)

-- MAIN APP DEPOTS / PACKAGES
addappid(605101, 1, "65d7eb94548043aaa37e8fb154df706d0b1a3e1ec9dc58ed81290f4af0e00bf8")
