-- Lua provided by RyzenAPI 
-- Game: Beltmatic
addappid(2674590)
addappid(2674591, 1, "06765dffd5ae577cf1f29ace43bdf9cc72092dc1d4d7bc52cc80307900d30f8c")
