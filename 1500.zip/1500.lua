-- Lua provided by RyzenAPI
-- Game: Darwinia

-- MAIN APPLICATION
addappid(1500)
addappid(1507)
addappid(1515)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501, 1, "67f0bb2ebad2b6f07434bcb41a2e9e6be3c68f510fc890d53d6667532e73e966")
addappid(1503, 1, "324f5b7b6105a1a716ba4624c3713d44597d36bf912f01b62e1b762957a6d36a")
addappid(1505, 1, "c41060ed9c303d9834b8a880531a3742f955633991a6bab971ad6ad7111513a9")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

