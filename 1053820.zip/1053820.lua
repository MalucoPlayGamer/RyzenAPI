-- Lua provided by RyzenAPI
-- Game: Game: Eternal Concord

-- MAIN APPLICATION
addappid(1053820)
-- Game: addappid(1053820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053821, 1, "b444a57a5c445892180f9ea50282be896822ff75a1cebf27de6325a186895c42")
