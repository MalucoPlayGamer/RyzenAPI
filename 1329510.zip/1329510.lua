-- Lua provided by RyzenAPI
-- Game: Game: Big Farm Story

-- MAIN APPLICATION
addappid(1329510)
-- Game: addappid(1329510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329511, 1, "d35a825fc46314fbe52af4456f342812bc03d9648fbd36f10fe632498c009c3a")
addappid(1329512, 1, "47143dac9744c758c8361bedf4333049c8415d4550b05435bc80024450e1d2f2")
