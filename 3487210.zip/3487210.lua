-- Lua provided by RyzenAPI
-- Game: Blood Bar Tycoon Soundtrack

-- MAIN APPLICATION
addappid(3487210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487211, 1, "f2cc7ca03d2983013ad3398a9f7ae00fedcdc63ecd18e7ea1cf6e76545962f30")
