-- Lua provided by SkyAPI 
-- Game: The Last Islands of Man
addappid(1477640)
addappid(1477641, 1, "52d253972cf0e7d7da6bfd9eb07b9e29d39f89826c1f9b6a4ebaee1dc2f76299")
