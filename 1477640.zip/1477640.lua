-- Lua provided by RyzenAPI
-- Game: addappid(1477640)

-- MAIN APPLICATION
addappid(1477640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477641, 1, "52d253972cf0e7d7da6bfd9eb07b9e29d39f89826c1f9b6a4ebaee1dc2f76299")
