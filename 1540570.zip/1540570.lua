-- Lua provided by RyzenAPI
-- Game: Game: Fractal Block World

-- MAIN APPLICATION
addappid(1540570)
-- Game: addappid(1540570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540571, 1, "cbea28ba0ec65bde697d2cb86d18bc5c1d7d8f7dcdd6faae9143044da078a771")
