-- Lua provided by RyzenAPI
-- Game: Ray Gigant

-- MAIN APPLICATION
addappid(421600)
-- Game: addappid(421600)

-- MAIN APP DEPOTS / PACKAGES
addappid(421601, 1, "b6a305ac3cd406c4048363cf6370ab2e007183584cff34e8d6f725026217388e")
addappid(421602, 1, "cea2d223546ba96eb71d0fb112ecb225487bceb9e71778dc42b3a572f37ee522")
addappid(421603, 1, "2a2aa53b9c3e84a5a9e4569bb7d3a5a1ca06c2631077cc38fc1452573de98748")
