-- Lua provided by RyzenAPI
-- Game: addappid(2464680)

-- MAIN APPLICATION
addappid(2464680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464681, 1, "12673d3bde14238e11b7ccd5c70e0a6384a495b28df2cfec71e0e8e1ebcce280")
