-- Lua provided by SkyAPI 
-- Game: Keplerian Space Discovery Demo
addappid(3313550)
addappid(3313551, 1, "4e85e6754346600d7e9b9e5fed88e3d5766006e77ba2d52f62e439c93b07731f")
