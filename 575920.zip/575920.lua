-- Lua provided by RyzenAPI
-- Game: Felix Jumpman

-- MAIN APPLICATION
addappid(575920)
-- Game: addappid(575920)

-- MAIN APP DEPOTS / PACKAGES
addappid(575921, 1, "2d7b5746c8933e6955b4473a8e022683f03e9797cf22f6eac09f580592a819a4")
