-- Lua provided by RyzenAPI
-- Game: AppID 2900970

-- MAIN APPLICATION
addappid(2900970)
-- Game: addappid(2900970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2900971, 1, "2b4092678d195ffd22357ac02dbe4cffb05071a0eaadb508b504ae4fdd40794e")
