-- Lua provided by RyzenAPI
-- Game: Haunted Train: Spirits of Charon Collector's Edition

-- MAIN APPLICATION
addappid(631240)

-- MAIN APP DEPOTS / PACKAGES
addappid(631241,0,"fc7816a0c4f7cec09551fd2a1a8e892b86c7f9138ae354d0f727c83de84a1652")

