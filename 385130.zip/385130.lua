-- Lua provided by RyzenAPI
-- Game: DvDrum, Ultimate Drum Simulator!

-- MAIN APPLICATION
addappid(385130)
addappid(676250)
addappid(676251)
addappid(676252)
addappid(676253)
addappid(676254)
addappid(676255)
addappid(676256)
addappid(676257)
addappid(676258)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(385131, 1, "ab96518f47952d574a3a62e4013b23981d03bb9f10c761b41d6d81207ef9da74")

