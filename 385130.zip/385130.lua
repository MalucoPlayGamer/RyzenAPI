-- Lua provided by RyzenAPI
-- Game: AppID 385130

-- MAIN APPLICATION
addappid(385130)
-- Game: addappid(385130)

-- MAIN APP DEPOTS / PACKAGES
addappid(385131, 1, "ab96518f47952d574a3a62e4013b23981d03bb9f10c761b41d6d81207ef9da74")
