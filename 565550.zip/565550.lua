-- Lua provided by RyzenAPI
-- Game: 565550

-- MAIN APPLICATION
addappid(565550)
-- Game: addappid(565550)

-- MAIN APP DEPOTS / PACKAGES
addappid(565551, 1, "0edcd738acae3fb071eb8abece7c318f52125f08b54f7be044b87b06dc0e9d5e")
