-- Lua provided by RyzenAPI
-- Game: Urja

-- MAIN APPLICATION
addappid(338710)

-- MAIN APP DEPOTS / PACKAGES
addappid(338711, 1, "b38497d827dd3d6a0495557d53fe70fddb1b2960e59fb82a575ff1662e72f74e")
addappid(338712, 1, "e05eb7e06b764a7e10dbab4bd4d244f9f460f990df0f3b2e9f92746a59a90789")
addappid(338713, 1, "0e99a0ec4d13b66ce95f6afde1ecad7d68fff2208fea473b901cbb15b6d4062d")

