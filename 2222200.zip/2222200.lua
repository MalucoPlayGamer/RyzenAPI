-- Lua provided by RyzenAPI
-- Game: Springblades

-- MAIN APPLICATION
addappid(2222200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222201, 1, "2a5841cc30414db415ccb6e12635e037d9c393c069ba5cb72c523110c6dc31e0")
addappid(2222202, 1, "ddfa5d754826fb1bc1489f4425ed2f3f478a0d639f6cd8eeb14f462bdeaca6d4")

