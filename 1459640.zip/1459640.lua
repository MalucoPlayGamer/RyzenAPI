-- Lua provided by RyzenAPI
-- Game: addappid(1459640)

-- MAIN APPLICATION
addappid(1459640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459641, 1, "6b3dc59cc99022bed0342ac84a67668a51e9518d97b76961c2c99aca193bf3fa")
