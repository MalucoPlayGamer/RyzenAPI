-- Lua provided by RyzenAPI
-- Game: Death Live

-- MAIN APPLICATION
addappid(1140610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140611, 1, "da5b75f4f9b867296e7429b2d6e34455e75bca38d72bff3c653085d8cccb71bc")

