-- Lua provided by RyzenAPI
-- Game: Game: AppID 1149430

-- MAIN APPLICATION
addappid(1149430)
-- Game: addappid(1149430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149431, 1, "c96ca7b14d851697db0dc603fbaa3679fc6ec9c710ebd7d7f575c212b62d73b1")
