-- Lua provided by RyzenAPI
-- Game: Game: Tears - 9, 10

-- MAIN APPLICATION
addappid(776830)
-- Game: addappid(776830)

-- MAIN APP DEPOTS / PACKAGES
addappid(776831, 1, "e9d93068a375746b0901576458169df00f5e86868a8a1c5240ada3598660ffbf")
addappid(776834, 1, "3a676a0afe666f8ad4325322726ea4e3129fcf4dff810b75a905fd19929f427e")
