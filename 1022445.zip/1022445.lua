-- Lua provided by RyzenAPI
-- Game: DFF NT: Exdeath Starter Pack

-- MAIN APPLICATION
addappid(1022445)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022445,0,"02395496f464caf9015ca2e72a7bff42546fefae25376b48dd5c2a7379e4cd8b")
