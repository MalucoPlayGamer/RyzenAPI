-- Lua provided by RyzenAPI
-- Game: 614030

-- MAIN APPLICATION
addappid(614030)
-- Game: addappid(614030)

-- MAIN APP DEPOTS / PACKAGES
addappid(614031, 1, "1fe67fedc48d478c9bec83b8ec01fdca66f8f384216d90cefb91629cf3055fa5")
