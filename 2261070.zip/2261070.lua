-- Lua provided by RyzenAPI
-- Game: 2261070

-- MAIN APPLICATION
addappid(2261070)
-- Game: addappid(2261070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261071, 1, "252b7690a5692444b101c7866ad36b94aa18a59844cea3cb2bb1c956b8110ffa")
