-- 2427640's Lua and Manifest Created by Hubcap Manifest
-- Buildy Stacky 2
-- Created: August 16, 2026 at 12:58:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2427640) -- Buildy Stacky 2
-- MAIN APP DEPOTS
addappid(2427641, 1, "a61950527aa93b2f807a1aacf4f54672c0de4c9ba4529761104828c81784a8c8") -- Depot 2427641
setManifestid(2427641, "2328502876612427857", 277681880)