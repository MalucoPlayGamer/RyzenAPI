-- Lua provided by RyzenAPI
-- Game: Buildy Stacky 2

-- MAIN APPLICATION
addappid(2427640) -- Buildy Stacky 2

-- MAIN APP DEPOTS / PACKAGES
addappid(2427641, 1, "a61950527aa93b2f807a1aacf4f54672c0de4c9ba4529761104828c81784a8c8") -- Depot 2427641

