-- Lua provided by RyzenAPI
-- Game: addappid(1408530)

-- MAIN APPLICATION
addappid(1408530)
addappid(1421920)
addappid(1429720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408531, 1, "74615e9df80fa0ae55c659c7dbea216f03fa88ac2e789d0569ac6747e18b9a69")
