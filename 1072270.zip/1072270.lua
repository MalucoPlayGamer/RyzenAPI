-- Lua provided by RyzenAPI
-- Game: K-9 Dog Job

-- MAIN APPLICATION
addappid(1072270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072271, 1, "9707972309eda2b33d1d75d25e53ad04c2a2705ddc13a98058905f28f4cd40c7")
