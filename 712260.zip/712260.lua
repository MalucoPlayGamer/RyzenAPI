-- Lua provided by RyzenAPI
-- Game: Feast Your Eyes: Little Marshmallow

-- MAIN APPLICATION
addappid(712260)
addappid(712270)

-- MAIN APP DEPOTS / PACKAGES
addappid(712261,0,"56abfa08ac101b4e60a172bae56928e495b60ea6d356e9efd420acac6b454067")

