-- Lua provided by RyzenAPI
-- Game: Heltons Haunted Hotel

-- MAIN APPLICATION
addappid(1605310)
-- Game: addappid(1605310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605311, 1, "a97fde18b192fbf54f7a7c4442a75d1a96b5bdaba37dcd79232793c9c0926604")
