-- Lua provided by RyzenAPI 
-- Game: AppID 3414060
addappid(3414060)
addappid(3414061, 1, "cf7d87233bd25efa3dff4cf78d03e72064fb86f1b13c5df6925a866386f941c1")
