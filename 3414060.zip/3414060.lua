-- Lua provided by RyzenAPI
-- Game: addappid(3414060)

-- MAIN APPLICATION
addappid(3414060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3414061, 1, "cf7d87233bd25efa3dff4cf78d03e72064fb86f1b13c5df6925a866386f941c1")
