-- Lua provided by RyzenAPI
-- Game: Detention - Original Soundtracks

-- MAIN APPLICATION
addappid(568290)

-- MAIN APP DEPOTS / PACKAGES
addappid(568299,0,"772147e2006570941c8192f7ca63ebf84e8e0bf0199b2cd9d595036c9a3eaaa6")
