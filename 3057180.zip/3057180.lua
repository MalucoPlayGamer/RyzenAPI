-- Lua provided by RyzenAPI
-- Game: Abnormal1999:Sector 49

-- MAIN APPLICATION
addappid(3057180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057181, 1, "aebd033ed3f619815b370137d7253d9f9f3696412aae2e48914464df58a51431")

