-- Lua provided by RyzenAPI 
-- Game: FlatOut 4: Total Insanity Workshop Tool
addappid(625080)
addappid(625081, 1, "8de0ee978dbb27d843651ac376a6f9c7b323aeb0d831dac2d94952a3e99462e1")
