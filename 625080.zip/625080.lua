-- Lua provided by RyzenAPI
-- Game: addappid(625080)

-- MAIN APPLICATION
addappid(625080)

-- MAIN APP DEPOTS / PACKAGES
addappid(625081, 1, "8de0ee978dbb27d843651ac376a6f9c7b323aeb0d831dac2d94952a3e99462e1")
