-- Lua provided by RyzenAPI
-- Game: addappid(3013880)

-- MAIN APPLICATION
addappid(3013880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013881, 1, "7af8d201c525097ea7f11285e93f384a2ff5fedbcd1c200c99fb2ee86529c699")
