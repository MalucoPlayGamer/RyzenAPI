-- Lua provided by RyzenAPI
-- Game: ASCII Game Series: Snake

-- MAIN APPLICATION
addappid(805240)

-- MAIN APP DEPOTS / PACKAGES
addappid(805241, 1, "69f3677669c7e637deb1a98edc0d452551f8b34b393e5e0dbdeb016c669865c4")

