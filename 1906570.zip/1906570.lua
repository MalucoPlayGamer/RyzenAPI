-- Lua provided by RyzenAPI
-- Game: The Art of War: Card Game

-- MAIN APPLICATION
addappid(1906570)
-- Game: addappid(1906570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906572,0,"9f909b0c71702947b40d08829933d216ef9bbdbe5465eee19ec96f4961ce955a")
addappid(1906573,0,"26fd0ea7da998d6697d8d9de78f68248984fc8ae346c0b8f0e4f770f08c0d8c2")
addappid(1906574,0,"0ec94abb45cbe223f92311f4ca2c0d8ee58380ee2caf55100f1263809d81fc93")
