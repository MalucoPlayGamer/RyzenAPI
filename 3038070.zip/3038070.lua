-- Lua provided by RyzenAPI
-- Game: Game: AppID 3038070

-- MAIN APPLICATION
addappid(3038070)
-- Game: addappid(3038070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038071, 1, "770ac032bd507d6faf98503bb62adad310dbfb30b9420d95489c5c0f958479d7")
