-- Lua provided by RyzenAPI
-- Game: ImmortalSurvivors Demo

-- MAIN APPLICATION
addappid(2641100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641101, 1, "e6de86a24bbae7591806b8f794be321bd471a7f568d52aeb747e1972ce28b772")
