-- Lua provided by RyzenAPI
-- Game: 1860370

-- MAIN APPLICATION
addappid(1860370)
-- Game: addappid(1860370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860374,0,"d8a3accab04a50dceeea3789d4d23c7562d0ee7a91515710bd39d69ce71949e4")
