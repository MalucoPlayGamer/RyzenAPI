-- Lua provided by RyzenAPI
-- Game: Weapons Simulator

-- MAIN APPLICATION
addappid(1860370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1860374,0,"d8a3accab04a50dceeea3789d4d23c7562d0ee7a91515710bd39d69ce71949e4")

