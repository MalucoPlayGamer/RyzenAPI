-- Lua provided by RyzenAPI
-- Game: Slender Reborn

-- MAIN APPLICATION
addappid(3209910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3209911, 1, "5dad293b039482fa23aa075f9e3e61be3a227bd2093badd6ec5c9132fd0b448d")

