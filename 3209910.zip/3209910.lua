-- Lua provided by RyzenAPI
-- Game: AppID 3209910

-- MAIN APPLICATION
addappid(3209910)
-- Game: addappid(3209910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209911, 1, "5dad293b039482fa23aa075f9e3e61be3a227bd2093badd6ec5c9132fd0b448d")
