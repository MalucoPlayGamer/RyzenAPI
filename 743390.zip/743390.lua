-- Lua provided by RyzenAPI
-- Game: Game: AppID 743390

-- MAIN APPLICATION
addappid(743390)
-- Game: addappid(743390)

-- MAIN APP DEPOTS / PACKAGES
addappid(743391, 1, "8f6433c5ab2508876ba66b91ce44e45550747cb55533c87a6f95c89d018ca207")
