-- Lua provided by RyzenAPI
-- Game: Gachimuchi Reloaded

-- MAIN APPLICATION
addappid(766730)

-- MAIN APP DEPOTS / PACKAGES
addappid(766731, 1, "8c6d2051b8f31d606f9eb45c340d5884186b7b3450cad7dbd57899c4ed724563")
