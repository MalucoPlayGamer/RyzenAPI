-- Lua provided by RyzenAPI
-- Game: Push Battle

-- MAIN APPLICATION
addappid(1825700)
addappid(2062620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825701, 1, "42244a6a218c9151638ec4b4a7b5142d25c9939fc47ffe1ac86984b146f6cd9f")
