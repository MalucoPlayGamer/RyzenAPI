-- Lua provided by RyzenAPI
-- Game: SOF: Enemy from the future - Prologue

-- MAIN APPLICATION
addappid(2952080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2952081, 1, "1d5c95e5f02fe8f503570e04529efb08fe2b85379c32640a326aae9ff4ac8633")
