-- Lua provided by RyzenAPI
-- Game: Redout 2

-- MAIN APPLICATION
addappid(1799930)
-- Game: addappid(1799930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799931, 1, "f3cadeab1aede0dcfe25f75d2fdea7be1afcd116f476929316284db09374164b")
