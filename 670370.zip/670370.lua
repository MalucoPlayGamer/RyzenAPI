-- Lua provided by RyzenAPI
-- Game: Fallen Cube

-- MAIN APPLICATION
addappid(670370)

-- MAIN APP DEPOTS / PACKAGES
addappid(670371, 1, "4024f9dfb0dc43d89587eb94e99ce3aaeb331228f6e89624f1b48c1c340123d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
