-- Lua provided by RyzenAPI
-- Game: Fallen Cube

-- MAIN APPLICATION
addappid(670370)
-- Game: addappid(670370)

-- MAIN APP DEPOTS / PACKAGES
addappid(670371, 1, "4024f9dfb0dc43d89587eb94e99ce3aaeb331228f6e89624f1b48c1c340123d0")
