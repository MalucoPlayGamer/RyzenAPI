-- Lua provided by RyzenAPI
-- Game: Accel

-- MAIN APPLICATION
addappid(994260)

-- MAIN APP DEPOTS / PACKAGES
addappid(994261, 1, "303ee8e081a22eefce010c40e7878ece743c86506e8c6bf5af2fe356bc447772")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
