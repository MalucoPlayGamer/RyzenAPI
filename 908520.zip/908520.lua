-- Lua provided by RyzenAPI
-- Game: Game: AppID 908520

-- MAIN APPLICATION
addappid(908520)
-- Game: addappid(908520)

-- MAIN APP DEPOTS / PACKAGES
addappid(908521, 1, "f31cd8224b7d2b7b0fb910eacc838d36e379847e5a43a05737c0bde364d302a2")
