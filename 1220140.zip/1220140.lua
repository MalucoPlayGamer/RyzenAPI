-- Lua provided by RyzenAPI
-- Game: Cartel Tycoon

-- MAIN APPLICATION
addappid(1220140) -- Cartel Tycoon
addappid(2081450) -- Cartel Tycoon - Lieutenants Pack - Guerillas
addappid(2081480)
addappid(2316200) -- Cartel Tycoon - Lieutenants Pack - La Familia
addappid(2348770) -- Cartel Tycoon San Rafaela
addappid(2827980) -- Cartel Tycoon Content Pack - Divas Hotel

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1220141, 1, "8c5dc498da79909bd350403d6063a625fca9a48f93e0f87d6fe1b2f0f5b23df2") -- Cartel Tycoon Content
addappid(2081480, 1, "dde87e84b645ae58d3c159b3dfa18bdd7a6c72d4da4c969a29ded7bf364a0e6e") -- Cartel Tycoon Artbook - Depot 2081480

