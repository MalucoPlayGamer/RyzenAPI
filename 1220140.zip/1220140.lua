-- Lua provided by RyzenAPI
-- Game: Game: Cartel Tycoon

-- MAIN APPLICATION
addappid(1220140)
-- Game: addappid(1220140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220141, 1, "8c5dc498da79909bd350403d6063a625fca9a48f93e0f87d6fe1b2f0f5b23df2")
addappid(2081480, 0, "dde87e84b645ae58d3c159b3dfa18bdd7a6c72d4da4c969a29ded7bf364a0e6e")
