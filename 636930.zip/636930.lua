-- Lua provided by RyzenAPI
-- Game: AppID 636930

-- MAIN APPLICATION
addappid(636930)
-- Game: addappid(636930)

-- MAIN APP DEPOTS / PACKAGES
addappid(636931, 1, "f62285e71907e89f18a173a3c0d70aec645073a58b0eaf07eda115455feddfdd")
