-- Lua provided by RyzenAPI
-- Game: Game: Pangeon

-- MAIN APPLICATION
addappid(983670)
-- Game: addappid(983670)

-- MAIN APP DEPOTS / PACKAGES
addappid(983671, 1, "144d7c162c1d2dfa5cda8a71fb482c7cbbc21d7640227298b5494f255b671a8c")
