-- Lua provided by RyzenAPI
-- Game: Gensei Suikoden Plus

-- MAIN APPLICATION
addappid(3078590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078591, 1, "91cf14573c94c7f1d998fa6eb48f8f1820e46a075b713a04db5a7d57e8b2e140")
