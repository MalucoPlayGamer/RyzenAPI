-- Lua provided by RyzenAPI
-- Game: addappid(1636980)

-- MAIN APPLICATION
addappid(1636980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636981, 1, "fa2db7e4fab2e5839279c03396a52cf68f8ffb062e4b57c1f4ebe5b46097418f")
