-- Lua provided by RyzenAPI
-- Game: 69 Mizuki Love

-- MAIN APPLICATION
addappid(1770140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770141, 1, "27352ce46b646eb36a77ae6191424133a28f4603b692cfec0096b6deb5e55a86")

