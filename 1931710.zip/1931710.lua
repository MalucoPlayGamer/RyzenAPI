-- Lua provided by RyzenAPI
-- Game: 1931710

-- MAIN APPLICATION
addappid(1931710)
addappid(2305090)
-- Game: addappid(1931710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931711, 1, "0827db67755d0e513ccb6d60f4cb4220847c1e7eb61ac1c5ad42f63b873cd9c7")
