-- Lua provided by RyzenAPI
-- Game: The Restless Sheep & The Lone Wolf -A Tale of Cutthroat Lovers-

-- MAIN APPLICATION
addappid(2947970)
-- Game: addappid(2947970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947971, 1, "a9d6563439db5ea33b44e76e7df22cf64b44fc3ae7c11610ed05020660224796")
addappid(2947972, 1, "2743e46e4759f246450037d6c126c38e1b9c79148008a4087c44b09589aea990")
addappid(2947973, 1, "5965311159078bdb6b7ddd9956678c9423f838d8c3a2e068cdc926310d4e8427")
