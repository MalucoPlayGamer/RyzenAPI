-- Lua provided by RyzenAPI
-- Game: Animal Rivals

-- MAIN APPLICATION
addappid(617420)
-- Game: addappid(617420)

-- MAIN APP DEPOTS / PACKAGES
addappid(617421, 1, "0dfdc2a9baa11d13b9b91316433182e7c4d8b83b2981b9dc701d52035c881176")
