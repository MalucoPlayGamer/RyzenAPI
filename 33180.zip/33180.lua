-- Lua provided by RyzenAPI
-- Game: addappid(33180)

-- MAIN APPLICATION
addappid(33180)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(33181, 1, "2febc1974da6b57a7038c555cccf2fadedd2ccfe55db08971a14c486383aa331")
addappid(33182, 1, "d121af565ca19bd5b447fe9557f0294a0def0b5652706ffa247b3d1ca0bdc54d")
