-- Lua provided by RyzenAPI 
-- Game: Marble Age
addappid(346810)
addappid(346811, 1, "15a7f5639e43efcb0d146dbc227177ba45ec170f3e59671259c886061d6e30d5")
addappid(346812, 1, "37964946f3c0490aec035c3271c0df6863560affa308282c5b1041018c625ac6")
