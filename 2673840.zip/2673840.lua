-- Lua provided by RyzenAPI
-- Game: 2673840

-- MAIN APPLICATION
addappid(2673840)
-- Game: addappid(2673840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673841, 1, "85a6e9d6dde8ff5edec70094e22b46fb9880029c469f00b6463f50d7b977303f")
