-- Lua provided by RyzenAPI 
-- Game: AppID 589220
addappid(589220)
addappid(589221, 1, "588bbcf224146f1b2c1e798d9bd48283a03aaca3e072a3893c71763ba5dc7abd")
