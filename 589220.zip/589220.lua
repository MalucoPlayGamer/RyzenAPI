-- Lua provided by RyzenAPI
-- Game: AppID 589220

-- MAIN APPLICATION
addappid(589220)

-- MAIN APP DEPOTS / PACKAGES
addappid(589221, 1, "588bbcf224146f1b2c1e798d9bd48283a03aaca3e072a3893c71763ba5dc7abd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
