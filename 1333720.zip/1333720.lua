-- Lua provided by RyzenAPI
-- Game: 1333720

-- MAIN APPLICATION
addappid(1333720)
-- Game: addappid(1333720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333721, 1, "fe02af86792cc02fb1f6608ad0f3ea1b595ddec6db8677c4e5121c174463985e")
