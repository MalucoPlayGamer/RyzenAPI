-- Lua provided by RyzenAPI
-- Game: addappid(1964060)

-- MAIN APPLICATION
addappid(1964060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964060,0,"d1e61c21dfa1c835bebbbb3299c1a3686bb20a370c818d784e16c84974412730")
