-- Lua provided by RyzenAPI
-- Game: NejicomiSimulator Vol.2 Demo

-- MAIN APPLICATION
addappid(1661220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661221, 1, "7d56bab892b6d59435055683b819278de0a6cfe383fb160773f49a0cc50fd595")

