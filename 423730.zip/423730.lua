-- Lua provided by RyzenAPI
-- Game: Hyper Gods

-- MAIN APPLICATION
addappid(423730)

-- MAIN APP DEPOTS / PACKAGES
addappid(423732,0,"82a1def7dd3f6ee93fd8541cf1aadd18fb3f4d5e12d485c98c3ff217636e45a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
