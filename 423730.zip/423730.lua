-- Lua provided by RyzenAPI
-- Game: 423730

-- MAIN APPLICATION
addappid(423730)
-- Game: addappid(423730)

-- MAIN APP DEPOTS / PACKAGES
addappid(423732,0,"82a1def7dd3f6ee93fd8541cf1aadd18fb3f4d5e12d485c98c3ff217636e45a3")
