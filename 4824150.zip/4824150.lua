-- Lua provided by RyzenAPI
-- Game: Yield to the Abyss

-- MAIN APPLICATION
addappid(4824150) -- Yield to the Abyss

-- MAIN APP DEPOTS / PACKAGES
addappid(4824151, 1, "ab55eb90cf2561eb94af83cdc34201e1fb3559b6ed8316737e78d7869f9564e2") -- Depot 4824151
addappid(4824152, 1, "4da08e74b0df8a1e71e87833efdc99c80db4f25f4f937609c92a61fa3cebd401") -- Depot 4824152

