-- 4824150's Lua and Manifest Created by Hubcap Manifest
-- Yield to the Abyss
-- Created: August 12, 2026 at 00:06:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4824150) -- Yield to the Abyss
-- MAIN APP DEPOTS
addappid(4824151, 1, "ab55eb90cf2561eb94af83cdc34201e1fb3559b6ed8316737e78d7869f9564e2") -- Depot 4824151
setManifestid(4824151, "2940621799627537995", 1184822394)
addappid(4824152, 1, "4da08e74b0df8a1e71e87833efdc99c80db4f25f4f937609c92a61fa3cebd401") -- Depot 4824152
setManifestid(4824152, "7454236868288414315", 1034236357)