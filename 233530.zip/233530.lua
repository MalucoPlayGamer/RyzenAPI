-- Lua provided by RyzenAPI
-- Game: Wake

-- MAIN APPLICATION
addappid(233530)

-- MAIN APP DEPOTS / PACKAGES
addappid(233531, 1, "6192f1530fb576356cb454c6ef67124be0fe0540ba8e4b6693b19f2713af6dc5")

