-- Lua provided by RyzenAPI
-- Game: Light Fairytale Episode 2

-- MAIN APPLICATION
addappid(1199760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199761, 1, "09da70e29c74085fb52ccd05486098c28906aa68866710d1dd584644eb540905")
