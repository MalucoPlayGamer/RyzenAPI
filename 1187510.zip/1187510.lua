-- Lua provided by RyzenAPI
-- Game: Game: AppID 1187510

-- MAIN APPLICATION
addappid(1187510)
-- Game: addappid(1187510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187511, 1, "62f6c5c77cf2557373ba6d80a9600876c5e42a9ec5ab5b708749e4fba856b89d")
