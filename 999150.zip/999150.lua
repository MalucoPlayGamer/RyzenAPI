-- Lua provided by RyzenAPI
-- Game: 999150

-- MAIN APPLICATION
addappid(999150)
-- Game: addappid(999150)

-- MAIN APP DEPOTS / PACKAGES
addappid(999151, 1, "19b3f207bcca00d07123bae39cf2ebba015b977579bc9e19387903e3cbc370ec")
