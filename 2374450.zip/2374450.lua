-- Lua provided by RyzenAPI
-- Game: 2374450

-- MAIN APPLICATION
addappid(2374450)
-- Game: addappid(2374450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374451, 1, "6e4e9eadc45db3b85ab4f439ce823c1b4ba271f478874264a57236ba0e78f66a")
addappid(2374452, 1, "4dd18c3cd130f33753410d97b2f51f39702cbf67ccbdebb4a6c96018944b1254")
