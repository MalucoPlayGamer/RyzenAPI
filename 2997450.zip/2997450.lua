-- Lua provided by RyzenAPI
-- Game: Only Up: SKIBIDI

-- MAIN APPLICATION
addappid(2997450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2997451, 1, "0c891ceace39a9fbb1a709cd3b2d6d75d2154736c9cd2f1c3b558e625586a1af")

