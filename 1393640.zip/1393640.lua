-- Lua provided by RyzenAPI
-- Game: Home Designer - Living Room

-- MAIN APPLICATION
addappid(1393640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393641, 1, "6a15a8584eb74da5feb83cd4cb6b0f42fd8159d0994d111660d52734642164db")
