-- Lua provided by RyzenAPI
-- Game: Just Ride: Apparent Horizon

-- MAIN APPLICATION
addappid(693960)
addappid(1205980)

-- MAIN APP DEPOTS / PACKAGES
addappid(693961, 1, "9d85a5183ab1ceba80d6de090a00d2fad5bf83680393349f14711ffd7e880bf6")

