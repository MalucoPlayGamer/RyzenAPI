-- Lua provided by RyzenAPI
-- Game: Parkan 2

-- MAIN APPLICATION
addappid(289400)

-- MAIN APP DEPOTS / PACKAGES
addappid(289401, 1, "2642ca21d91512bd6daeec1808eb54c2e1155a20c92bd908e1e2ea32efdc94e7")
addappid(289402, 1, "056047ad5d501416a822a8d98a03725a5a394e08f924d3c6a4d40b0d7c686e8c")
addappid(289403, 1, "366dd43786a7808efc7acb265a4fc174663877372061d754698215c86a53d4c4")
addappid(289404, 1, "4ec3d127f4d11ee518788e441e5034906f80caac23c1e67bded53fac2b958801")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
