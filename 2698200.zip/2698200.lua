-- Lua provided by RyzenAPI
-- Game: Keep Keepers Demo

-- MAIN APPLICATION
addappid(2698200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698201, 1, "87d8c3de2559b0d9a3254143afcd8ba0328aa10743e1f8ff223e4f06d561faca")
