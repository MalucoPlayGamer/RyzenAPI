-- Lua provided by RyzenAPI
-- Game: AirBuccaneers

-- MAIN APPLICATION
addappid(223630)

-- MAIN APP DEPOTS / PACKAGES
addappid(223631, 1, "ecde48551bc8f855e30542ec7033f3a29cc760a34d60b58a5a7a20413e91c1b8")
addappid(223632, 1, "8d47ab0aa1e9714d269f3db22385646fd2c11d539bfd2843c861012b152ccf6f")

