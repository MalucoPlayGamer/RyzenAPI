-- Lua provided by RyzenAPI
-- Game: Knight Swap 2

-- MAIN APPLICATION
addappid(1201800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201801, 1, "aaf6ffff20ba3173fa3fd7ab4aa3798c4dfaeb6883d499c27b0ad6c894c378dd")
