-- Lua provided by RyzenAPI
-- Game: Hatred : Black Label - comic book

-- MAIN APPLICATION
addappid(1580880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580880,0,"480533da6d6b9e61972ad4b0c2a1e6e011e7d2d9bece0468274cfdaeeb9d8be0")
