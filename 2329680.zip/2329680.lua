-- Lua provided by RyzenAPI
-- Game: NoOneSurvivedDedicatedServer

-- MAIN APPLICATION
addappid(2329680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2329681, 1, "3bdb3637c660a9b69792521ea5340430283405f16e5e37ed93e97a2ef7438941")

