-- Lua provided by RyzenAPI
-- Game: 2845720

-- MAIN APPLICATION
addappid(2845720)
-- Game: addappid(2845720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845721, 1, "e5aa684ec45255ea431bda57554c56cb37371b83f9897b329e226e32fe622dfd")
