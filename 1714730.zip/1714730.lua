-- Lua provided by RyzenAPI
-- Game: Game: Every day is more incredible than the previous

-- MAIN APPLICATION
addappid(1714730)
-- Game: addappid(1714730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714731, 1, "7c9ab54dc4f32475b0762dfec3d38fd3203dc4bb76def1b133c500a107044af0")
