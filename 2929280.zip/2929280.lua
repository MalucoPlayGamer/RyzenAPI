-- Lua provided by RyzenAPI
-- Game: Game: Antiyoy Demo

-- MAIN APPLICATION
addappid(2929280)
-- Game: addappid(2929280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929281, 1, "503fc4d2e38a6504b9b1485855077a0ee6396216f4629fc24252f63c388b4302")
