-- Lua provided by RyzenAPI
-- Game: 2530950

-- MAIN APPLICATION
addappid(2530950)
-- Game: addappid(2530950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530952,0,"27f8faaa02a38b7c885145bf8db7e9d4ac156b9a7870096c3a462d095c3480ed")
