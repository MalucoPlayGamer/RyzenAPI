-- Lua provided by RyzenAPI
-- Game: Xiaoqiao - Officer Ticket / 小喬使用券

-- MAIN APPLICATION
addappid(956765)

-- MAIN APP DEPOTS / PACKAGES
addappid(956765,0,"56f549b3c6c8b21195dad08d3ff9c865edca582b93cedb944793b37c182f7f32")
