-- Lua provided by RyzenAPI
-- Game: Game: Police Car Simulator

-- MAIN APPLICATION
addappid(2251240)
-- Game: addappid(2251240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251241, 1, "8f103d5797d84f6c12df00ac519c7f379d14b700ddd22c88886c10c927fae910")
