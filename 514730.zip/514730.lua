-- Lua provided by RyzenAPI
-- Game: Hidden Expedition: Dawn of Prosperity Collector's Edition

-- MAIN APPLICATION
addappid(514730)

-- MAIN APP DEPOTS / PACKAGES
addappid(514731,0,"78e98cb98c13db87ab0b67dd04e4e91a92603edeae173de5cf6da336e0e6f7ce")

