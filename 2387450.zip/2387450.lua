-- Lua provided by RyzenAPI
-- Game: AppID 2387450

-- MAIN APPLICATION
addappid(2387450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2387451, 1, "880a7b8957a34f9e6c8565e880226c3a0264d70b72b57d4afda23f4ec9503fc0")

