-- Lua provided by RyzenAPI
-- Game: 378030

-- MAIN APPLICATION
addappid(378030)
-- Game: addappid(378030)

-- MAIN APP DEPOTS / PACKAGES
addappid(378031, 1, "4be36d45c5ba322176efe311e99f783b68b5bbc37aacce64ae3209da406eefa0")
addappid(430000, 0, "5ac01e0e906ce0f85546c7ea207ecb2a7b026f5a39482c0c38606477aaf7e089")
