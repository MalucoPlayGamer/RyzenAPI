-- Lua provided by RyzenAPI
-- Game: Toree's Panic Pack

-- MAIN APPLICATION
addappid(3089290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089291, 1, "67219d83037a12d2776b4330df9908ba1c398f4335ce5abad5a1511be36dc720")
