-- Lua provided by RyzenAPI
-- Game: 432790

-- MAIN APPLICATION
addappid(432790)
-- Game: addappid(432790)

-- MAIN APP DEPOTS / PACKAGES
addappid(432792,0,"cd10bc9feace57ca45b1e4a72da834f9f620d885e7eedebf9238f7f0b481b82f")
