-- Lua provided by RyzenAPI
-- Game: Extra Terrestrial Perception

-- MAIN APPLICATION
addappid(629210)
-- Game: addappid(629210)

-- MAIN APP DEPOTS / PACKAGES
addappid(629211, 1, "c57eb9af9721005142844efffe2ddcc07df51754f32f96e65afdcc9dcb753ba9")
