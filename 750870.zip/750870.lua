-- Lua provided by RyzenAPI
-- Game: addappid(750870)

-- MAIN APPLICATION
addappid(750870)

-- MAIN APP DEPOTS / PACKAGES
addappid(750871, 1, "6e70c2d42657bec97729c570e7c9d5c0cd68621445a82d8133e00fcad6930851")
