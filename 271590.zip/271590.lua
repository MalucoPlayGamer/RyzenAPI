-- Lua provided by RyzenAPI
-- Game: Game: Grand Theft Auto V Legacy

-- MAIN APPLICATION
addappid(271590)
addappid(362000)
addappid(362001)
addappid(362002)
addappid(362003)
addappid(413180)
addappid(771300)
-- Game: addappid(271590)

-- MAIN APP DEPOTS / PACKAGES
addappid(271591, 1, "baebeedec48b33c68a322fea0cbaa8d023d1dab4d2870aa909b82c33caa53941")
addappid(271592, 1, "e34313f0ec133a608e636cf04fd879d3ac1e8e10af38542436940be1b6834bee")
addappid(271593, 1, "71b57be5c50e5fbc819068a5bf31db42b653f1c75d88307da682ff0d5cae9457")
addappid(271594, 1, "ae7ed6931a136d41d3aae146563368eb3b3e4e60963344f3f426c0abc74bbdab")
addappid(271595, 1, "6dc0d2ce6b9dc96469ff792f6a607f759f0abd851d496cac73d71cd145c70b4d")
addappid(1899671, 0, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
