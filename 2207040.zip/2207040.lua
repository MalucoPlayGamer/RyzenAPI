-- Lua provided by RyzenAPI
-- Game: Myasoid

-- MAIN APPLICATION
addappid(2207040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207041, 1, "07deccce114cb4e272160b39e5e21cd1f052539d058e5b66c2f61ecd9c2840f8")

