-- Lua provided by RyzenAPI
-- Game: addappid(1426210)

-- MAIN APPLICATION
addappid(1426210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426211, 1, "c450c44e032e27d0308cf864259fb2af91bcfc58401a0caf33bb8efba85bb323")
