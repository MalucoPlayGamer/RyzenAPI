-- Lua provided by RyzenAPI
-- Game: Dark Fantasy 2: Artwork and OST

-- MAIN APPLICATION
addappid(1079710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079710,0,"f7f2a17053233b508c6abec169686cc0623ab3f3f354be2a9afa0babd6127ba0")

