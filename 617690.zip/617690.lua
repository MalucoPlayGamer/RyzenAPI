-- Lua provided by RyzenAPI
-- Game: Endless Winter

-- MAIN APPLICATION
addappid(617690)
addappid(628260)

-- MAIN APP DEPOTS / PACKAGES
addappid(617691, 1, "6d7ea01ee95f1748b1b73a997fdac20555ac5c17174bd3a93308774f777f83f8")

