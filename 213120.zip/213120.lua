-- Lua provided by RyzenAPI
-- Game: AppID 213120

-- MAIN APPLICATION
addappid(213120)

-- MAIN APP DEPOTS / PACKAGES
addappid(213121, 1, "b2941325e085d4db8f2de56bffc5fef4678bb6a5c32939df82d47ccc60d21a56")
addappid(213122, 1, "0ef258e0ddd406cc29e9388a1806eb16cc4056bb59e5815581f11af1bfa1e66d")
addappid(213123, 1, "84c27a40b62f14191e1516898ae487c81ec9e08ace255fb571a5d0468314c7d2")
addappid(213124, 1, "6decf47a039757749de0e7ec9bfee772d207cfa144712f1a22aab9c35c9c4313")
addappid(213125, 1, "e2f453108d8f3575438093099be83a7df4618a10b76174fc2a76c52e2faee676")
addappid(213126, 1, "2b1aa5083e00104cac6ef54025a1b7ed4b9b2484ef7aff304f9a0a6f7fe8ce24")
addappid(213127, 1, "8445c544ae619310dba7f7681c6b189a1f06a2fd7e2f27d57535a12f3ecc891c")
addappid(213128, 1, "83826d0ae246d184b91b693f59abd874a7624c945430504b87479e3abaa97bfb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(213151)
addappid(213152)
addappid(213153)
addappid(213154)
addappid(213155)
