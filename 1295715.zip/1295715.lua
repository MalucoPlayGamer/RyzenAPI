-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1295715)
-- Game: addappid(1295715)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295715,0,"ca0826173487b0494ac42a80dcfa84898d04b4bd743919515ca9af01baa26335")
addappid(1296050,0,"ec51e4bedca2821c90e6eefc9903628522b3c46296c04c34f848c2b30558893a")
addappid(1296051,0,"9420955798ddee692f28fda5f5853356cf161e13a36b1c69970c7aaeb2e3becf")
addappid(1296052,0,"d3e1c96b0028258897ddb17826ef765fbc598773942c50fe10045f230f6dee25")
addappid(1296053,0,"fa982bbba6ad7a08bbb2667b5291e0a3764caa6e84b83bb06bbf7c382baae1f7")
addappid(1296054,0,"95e28acbc6a0677cf9c28c6aa7026f99b472aed67afff943e7b0fa9bd83277d2")
addappid(1296055,0,"a4503d22f696aa10ada9218e1098c1839d1f2670acdb0e8f10eb5a3ece6e9c5b")
addappid(1296056,0,"581711375e498497869d09c63848637b91c7bd35fea046f12119bbe05d159732")
