-- Lua provided by RyzenAPI 
-- Game: AppID 843440
addappid(843440)
addappid(843441, 1, "2fc3bbb6473d31bf10151146ec4331f48a1f416f226e9539e20c88120123350c")
