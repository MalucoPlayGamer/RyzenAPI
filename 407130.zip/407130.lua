-- Lua provided by RyzenAPI
-- Game: Tank Mechanic Simulator

-- MAIN APPLICATION
addappid(407130)
addappid(1065400)

-- MAIN APP DEPOTS / PACKAGES
addappid(407131, 1, "989efb78a9368874e2d18ac087df37d06459b0dc786fa054628e00bd27a9867c")
addappid(407132, 1, "0bd11b4aebe64e0fd0d926b63f8fe3f9eb86ce78b954d2a208ebbde79eb0ab09")
addappid(1065403, 0, "ddd06be3ac29a3ced9b5bcda682295cd0d7a64b075eebd0ec406c31a20b9c653")
addappid(1485420, 0, "eeed40b3a7fc89c6cc44631639551f329dd573372eb17a2d9155b8545c7643de")
addappid(1485421, 0, "41c1b9f4d7fd37022c0e843fed4271e4bbe0cc0c4f562e480f9323b269777a8b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4185020)
