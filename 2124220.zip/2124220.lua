-- Lua provided by RyzenAPI
-- Game: Fallen Legion: Rise to Glory Soundtrack

-- MAIN APPLICATION
addappid(2124220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124222,0,"3b18f0c2772073d1849b653fb5131144f0ccbf15f9398f8752bab47174f5d94c")
addappid(2124223,0,"56bc234eb946209192bff765e5925d43e78857a42dcfa67520bef7f143266d69")

