-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Sacred Treasure `Garm`

-- MAIN APPLICATION
addappid(1176616)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176616,0,"3c33c935b0bad2032062d9346303d65e38d515dc06c58eb989023070b6f01c01")

