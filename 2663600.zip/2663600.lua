-- Lua provided by RyzenAPI
-- Game: setManifestid(2663603,"2453584445532813238")

-- MAIN APPLICATION
addappid(2663600)
-- Game: addappid(2663600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663603,0,"eab16048a2cad46ebc24e5c25af32edf40d256c00ced57a39ea6161f91397c1a")
