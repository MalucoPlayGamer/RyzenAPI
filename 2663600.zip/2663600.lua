-- Lua provided by RyzenAPI
-- Game: 溢爱~fragile love

-- MAIN APPLICATION
addappid(2663600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2663603,0,"eab16048a2cad46ebc24e5c25af32edf40d256c00ced57a39ea6161f91397c1a")

