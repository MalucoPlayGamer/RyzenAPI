-- Lua provided by RyzenAPI
-- Game: Game: Pure Logic

-- MAIN APPLICATION
addappid(1861500)
-- Game: addappid(1861500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861501, 1, "056a4a8d6364e01582289b50709f9ebec3385b242618cb6417423d655f33325d")
