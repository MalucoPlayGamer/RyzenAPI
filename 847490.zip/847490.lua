-- Lua provided by RyzenAPI
-- Game: Star Speeder

-- MAIN APPLICATION
addappid(847490)

-- MAIN APP DEPOTS / PACKAGES
addappid(847491, 1, "579cfdddd17f626f05e6307109b06d72ee4a0d107064fc75fde196676babeeff")
