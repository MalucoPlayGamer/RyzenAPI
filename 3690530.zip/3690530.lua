-- Lua provided by RyzenAPI
-- Game: 末日之火(DoomsdayFire)

-- MAIN APPLICATION
addappid(3690530)
addappid(3731420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690531, 1, "838d8f2c357f9ac3cdb8a22fedcda342dbf2a15b676ae374fd78696e50b24ec3")
