-- Lua provided by RyzenAPI
-- Game: 1677040

-- MAIN APPLICATION
addappid(1677040)
-- Game: addappid(1677040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677041, 1, "d6a47630f2976e56daf7e1e494e518f25131e4d833f9947a74bdabb3cc1f28bd")
