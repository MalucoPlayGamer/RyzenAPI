-- Lua provided by RyzenAPI
-- Game: Greed Knights

-- MAIN APPLICATION
addappid(1444670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444671, 1, "637fe17e108254a7450fb6d879a285d283d846099dac94b33cccf38f3c6908e3")
