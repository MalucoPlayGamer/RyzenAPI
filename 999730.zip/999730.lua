-- Lua provided by RyzenAPI
-- Game: Secret Neighbor Beta

-- MAIN APPLICATION
addappid(999730)

-- MAIN APP DEPOTS / PACKAGES
addappid(999731, 1, "1d447c532c72185a264378edf335d6bf1a9e3c54311992e05ead3c64212183a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
