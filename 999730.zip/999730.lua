-- Lua provided by RyzenAPI 
-- Game: Secret Neighbor Beta
addappid(999730)
addappid(999731, 1, "1d447c532c72185a264378edf335d6bf1a9e3c54311992e05ead3c64212183a9")
