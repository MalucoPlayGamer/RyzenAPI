-- Lua provided by RyzenAPI
-- Game: 1583800

-- MAIN APPLICATION
addappid(1583800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583800,0,"c0e70e50a7e1eac4b0d0b13ba4d5ad141582cafbcd4a4d86ae0ea46adffab31b")
