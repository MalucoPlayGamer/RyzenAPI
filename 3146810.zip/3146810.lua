-- Lua provided by RyzenAPI
-- Game: Game: Look Closer! Demo

-- MAIN APPLICATION
addappid(3146810)
-- Game: addappid(3146810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146811, 1, "44e27e67bdfa19bf37d0b564efdcf8b8769e9f78f40592c9a468eac564f701cd")
