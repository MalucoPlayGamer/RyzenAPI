-- Lua provided by RyzenAPI
-- Game: Lyndaria: Lust Adventure - Spicy Wallpapers

-- MAIN APPLICATION
addappid(3170190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170190,0,"393ad3c1b0055dbdb6e5a1f626b188486bcc4cb42e1b9f59c5e64ee1928e5b6b")

