-- Lua provided by RyzenAPI
-- Game: AppID 963080

-- MAIN APPLICATION
addappid(963080)

-- MAIN APP DEPOTS / PACKAGES
addappid(963081, 1, "a209c1b14a508346dc8a82e5fccdb191fcd45f1dcfba99ae65048c1815aba60e")

