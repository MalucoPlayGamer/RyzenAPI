-- Lua provided by RyzenAPI
-- Game: Game: Ghost Bus Simulator

-- MAIN APPLICATION
addappid(2161600)
-- Game: addappid(2161600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161601, 1, "588b1d4e6ff09d8b6930e5b76a64b13291e5ebca0188063629696c74c25a1392")
