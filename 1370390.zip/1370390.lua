-- Lua provided by RyzenAPI
-- Game: AppID 1370390

-- MAIN APPLICATION
addappid(1370390)
-- Game: addappid(1370390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370391, 1, "a01c6657af039776bdd0d7d8b367d1b200e7d2b79b77ea8fa42e21b504f43573")
