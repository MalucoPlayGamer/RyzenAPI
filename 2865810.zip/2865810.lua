-- Lua provided by RyzenAPI
-- Game: Game: dark color

-- MAIN APPLICATION
addappid(2865810)
-- Game: addappid(2865810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865811, 1, "7b6a2bb962c87ec4ac11af9006af585e191e0d68082791a4c6e1ee9e1a10da89")
