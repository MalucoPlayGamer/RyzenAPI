-- Lua provided by RyzenAPI
-- Game: 2059730

-- MAIN APPLICATION
addappid(2059730)
-- Game: addappid(2059730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059731, 1, "2136d9c9e9fea963c1a5756383a57ab3cf52b0f206bd385fad0a9ec4a4d9a028")
