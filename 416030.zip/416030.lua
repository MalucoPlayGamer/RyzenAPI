-- Lua provided by RyzenAPI
-- Game: Your Quest

-- MAIN APPLICATION
addappid(228990)
addappid(229003)
addappid(229012)
addappid(416030)

-- MAIN APP DEPOTS / PACKAGES
addappid(416032,0,"18122c7863bc32420efe37d5af91f78c34c0e7bd80a25fb596aef645df8dfdab")

