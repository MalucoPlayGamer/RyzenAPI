-- Lua provided by RyzenAPI
-- Game: Cogito

-- MAIN APPLICATION
addappid(543710)

-- MAIN APP DEPOTS / PACKAGES
addappid(543711,0,"d5dd5f37c375c6d818c8fe98abae0fce1216e1fe751751775d25a28bc5fff331")

