-- Lua provided by RyzenAPI
-- Game: Labyronia RPG 2

-- MAIN APPLICATION
addappid(397500)

-- MAIN APP DEPOTS / PACKAGES
addappid(397501, 1, "338e068a29768db81c65fd21f8e70fa7717fd0df44007b7e39425f5ab1c00634")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
