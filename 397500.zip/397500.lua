-- Lua provided by RyzenAPI
-- Game: Game: Labyronia RPG 2

-- MAIN APPLICATION
addappid(397500)
-- Game: addappid(397500)

-- MAIN APP DEPOTS / PACKAGES
addappid(397501, 1, "338e068a29768db81c65fd21f8e70fa7717fd0df44007b7e39425f5ab1c00634")
