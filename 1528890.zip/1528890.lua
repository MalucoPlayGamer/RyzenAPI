-- Lua provided by RyzenAPI
-- Game: 1528890

-- MAIN APPLICATION
addappid(1528890)
-- Game: addappid(1528890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528891, 1, "c83d01276cf7e3853f37c8c9350d139626bea26addff6781a2dc526f31472a24")
