-- Lua provided by RyzenAPI
-- Game: Evil Wizard

-- MAIN APPLICATION
addappid(1592100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592101, 1, "801dbffa0b79b8945dcf7b01b473d655223d0148497999e9c02941971bb26da6")

