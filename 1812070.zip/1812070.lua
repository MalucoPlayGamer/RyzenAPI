-- Lua provided by RyzenAPI
-- Game: Among Waifus 18+

-- MAIN APPLICATION
addappid(1812070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812071, 1, "594a91c510d00fbd1a454195ccdf3ea644c6a326124b3d4b30b40c5362752f74")

