-- Lua provided by RyzenAPI
-- Game: addappid(4710)

-- MAIN APPLICATION
addappid(4710)

-- MAIN APP DEPOTS / PACKAGES
addappid(4711, 1, "2b37cfd9e2d3c4193d7992c54a9fb5bb3b4e67f69c02d5bc129634943f911eec")
