-- Lua provided by RyzenAPI
-- Game: ArcheBlade™

-- MAIN APPLICATION
addappid(207230)
addappid(228983)
addappid(228990)
addappid(229003)

-- MAIN APP DEPOTS / PACKAGES
addappid(207231, 1, "ca8d9c24441a574bd3871cc750d6b1d0728696c21cf89d6908861629f749dab0")

