-- Lua provided by RyzenAPI
-- Game: Lillian Night: Exclusive Contract of Succubus (Demo)

-- MAIN APPLICATION
addappid(1794040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794041, 1, "a9fc67585ec8ec56e03e03d1887c0e461704132b34411038ca14af5d57b32283")

