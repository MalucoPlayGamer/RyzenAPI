-- Generated with Luie @ https://lua.tools/
-- 3594540 - Orbital Checkpoint
-- Generated 2026-08-27 22:07:59 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(3594540)

-- Main Depots
addappid(3594542, 1, "4c697dc9c29ce39e3ba3f4ec91156f5d59725f0070c97734123396d5e37785fa") -- (windows)
setManifestid(3594542, "7437510630172625251", 480866039)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- Token-locked DLCs (couldn't read depots): 4912410
