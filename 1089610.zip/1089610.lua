-- Lua provided by RyzenAPI
-- Game: Aurora: The Lost Medallion - The Cave (Demo)

-- MAIN APPLICATION
addappid(1089610)
-- Game: addappid(1089610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089611, 1, "86b336b349609b9270b8fe5078a1dcc2f9b50fa0303d603fae1de2c570d56157")
