-- Lua provided by RyzenAPI
-- Game: Worlds of Aria

-- MAIN APPLICATION
addappid(1866980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866981, 1, "d0a56afaad1bad91e9f936e956c66c7a3a100a94cbcd509efc35a35e13856411")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2961620)
addappid(3325450)
