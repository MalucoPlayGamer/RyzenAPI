-- Lua provided by RyzenAPI
-- Game: Worlds of Aria

-- MAIN APPLICATION
addappid(1866980)
-- Game: addappid(1866980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866981, 1, "d0a56afaad1bad91e9f936e956c66c7a3a100a94cbcd509efc35a35e13856411")
