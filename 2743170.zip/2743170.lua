-- Lua provided by RyzenAPI
-- Game: addappid(2743170)

-- MAIN APPLICATION
addappid(2743170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743170,0,"597f5a6f7344d1fae24976718b574a35a20975555e73cb265abfa0e1ee18fbd4")
