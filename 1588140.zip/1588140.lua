-- Lua provided by RyzenAPI 
-- Game: Monkey vs Dino
addappid(1588140)
addappid(1588141, 1, "3deec2d4630ae49879ec2b637186db76ad83912d5ddb29774122435509763a68")
