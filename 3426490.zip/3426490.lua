-- Lua provided by SkyAPI 
-- Game: End Transmission?
addappid(3426490)
addappid(3426491, 1, "bf6c34565d6c17a99d80c87ed14391d1d557a414a6279e573157078ae8fe8911")
