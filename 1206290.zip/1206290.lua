-- Lua provided by RyzenAPI
-- Game: Goblin Summer Camp

-- MAIN APPLICATION
addappid(1206290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206291, 1, "f55654681ca1d38bf8083c1d063db48f60d2431293a2aeead72087e63bfaae15")

