-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1451024)
-- Game: addappid(1451024)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451024,0,"7e3a35d57ea6d8c2aad8a064f47e432cc2985badb9587c6ce838d24c37448ff4")
