-- Lua provided by RyzenAPI
-- Game: World of the dead Demo

-- MAIN APPLICATION
addappid(3152210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152211, 1, "2e59df33217cc241d6087f689b368ae86c4ca68f68e0273b8e87ee3bd3afe15d")

