-- Lua provided by RyzenAPI
-- Game: C-TAS: A Virtual Chinese Learning Game

-- MAIN APPLICATION
addappid(1277290)
-- Game: addappid(1277290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277291, 1, "5e804404225c5fa12a420932b86a1069f68a895ffaedd1fd9ae2080b9db1f3ae")
