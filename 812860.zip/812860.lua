-- Lua provided by RyzenAPI
-- Game: Genius Calculator

-- MAIN APPLICATION
addappid(812860)

-- MAIN APP DEPOTS / PACKAGES
addappid(812861, 1, "c4f5e9a30f49ef9086b90d84c5f689558120538d69aadb0228e6869412987ae9")
