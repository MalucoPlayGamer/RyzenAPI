-- Lua provided by RyzenAPI
-- Game: Trinity of Chaos

-- MAIN APPLICATION
addappid(1033120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033121, 1, "b2e33da01c71fd9c1c24fe7ad3b84543850e5e299efedee8ea88d3181aa0d8fc")
