-- Lua provided by RyzenAPI
-- Game: Game: Kitchen Chaos - Learn Game Development

-- MAIN APPLICATION
addappid(2275820)
-- Game: addappid(2275820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275821, 1, "9a0ad888ddbd4262b7003e6249df117513b9ab237680965120aed427ee1dd9cc")
addappid(2275822, 1, "1eb4898d47f9a308532b0c64e307bec431247bc40a82d737fe909c9c103b2215")
addappid(2275823, 1, "f7b28d99b6537929ee8116acbc2f1e89b79977532e8154ab5cb97fccd79ec743")
