-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Flooded Grounds

-- MAIN APPLICATION
addappid(3079420)
-- Game: addappid(3079420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079421, 1, "b9c4a1cbbf813531ce6add0c3a425226e35d190cde5ede94ed046c08e3e3b350")
