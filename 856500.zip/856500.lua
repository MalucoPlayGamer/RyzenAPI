-- Lua provided by RyzenAPI
-- Game: Game: AppID 856500

-- MAIN APPLICATION
addappid(856500)
-- Game: addappid(856500)

-- MAIN APP DEPOTS / PACKAGES
addappid(856501, 1, "239a3ca6c429fea64b4e11d7deee98bb40650fd7ab9412097129cb9126658692")
