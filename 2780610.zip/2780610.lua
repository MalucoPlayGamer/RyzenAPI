-- Lua provided by RyzenAPI
-- Game: Unholy Village

-- MAIN APPLICATION
addappid(2780610)
-- Game: addappid(2780610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780611, 1, "de827a431f07b4255241a19b7a3539480a7b6d94c72d82b766c111dcb0bc52ee")
