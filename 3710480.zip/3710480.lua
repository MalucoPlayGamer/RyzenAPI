-- Lua provided by RyzenAPI
-- Game: ROOM FOOTBALL - Sand Storm

-- MAIN APPLICATION
addappid(3710480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3710481, 1, "9c5ca4fd50bc26a10ce425818e69e7acd8cbdadfec3f816377396c87b9879b01")
