-- Lua provided by RyzenAPI
-- Game: Game: Occlude

-- MAIN APPLICATION
addappid(3547010)
addappid(3855680)
-- Game: addappid(3547010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3547011, 1, "efef77174609f56a13e19715a20b9579284687c09152120d92a7ef4d9f33bdf4")
