-- Lua provided by RyzenAPI
-- Game: Mist of the Undead

-- MAIN APPLICATION
addappid(1373500)
-- Game: addappid(1373500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373501, 1, "d19968c7b3993cf5dab1d472006bbffe231c6d4451ef14a20ef931912e08aea6")
