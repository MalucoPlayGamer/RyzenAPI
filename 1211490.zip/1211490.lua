-- Lua provided by RyzenAPI
-- Game: AppID 1211490

-- MAIN APPLICATION
addappid(1211490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211491, 1, "dd1e85311b3ffb8fe4dd4a37a0d194d677bca9dfa6d203553f83b2c9e99ec33a")
