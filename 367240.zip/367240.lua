-- Lua provided by RyzenAPI
-- Game: addappid(367240)

-- MAIN APPLICATION
addappid(367240)

-- MAIN APP DEPOTS / PACKAGES
addappid(367241, 1, "eec25c17a09d80d088bab19598f574f0152c83cd503817ea4ae747c5be3e92b4")
