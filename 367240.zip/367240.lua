-- Lua provided by SkyAPI 
-- Game: Avenging Angel
addappid(367240)
addappid(367241, 1, "eec25c17a09d80d088bab19598f574f0152c83cd503817ea4ae747c5be3e92b4")
