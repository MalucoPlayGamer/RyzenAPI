-- Lua provided by RyzenAPI
-- Game: AppID 811890

-- MAIN APPLICATION
addappid(811890)
-- Game: addappid(811890)

-- MAIN APP DEPOTS / PACKAGES
addappid(811891, 1, "b32799c3bc1861da431df49a5c9da8ffb36eb3a8a4bf5cafd375744a4826da85")
addappid(1224371, 0, "158bfb1946e34dc0fa99b2e7512f0fd4a47e3c657b084dcec7f2a7bfe0897ade")
