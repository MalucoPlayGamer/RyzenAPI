-- Lua provided by RyzenAPI 
-- Game: Pru the Pigeon
addappid(2701410)
addappid(2701411, 1, "903f919e781e45b81d474207e68f0aac3e071f746e7b8b2bf0ef607a7879ca22")
