-- Lua provided by RyzenAPI
-- Game: 657040

-- MAIN APPLICATION
addappid(657040)
-- Game: addappid(657040)

-- MAIN APP DEPOTS / PACKAGES
addappid(657041, 1, "67cce92deb8ca070259c735df74b7e6a03e9fe74fec11d444b77cc2b9106281d")
