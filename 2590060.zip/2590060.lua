-- Lua provided by RyzenAPI
-- Game: Wandering Sword Soundtrack

-- MAIN APPLICATION
addappid(2590060)
-- Game: addappid(2590060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590061, 1, "9401107c4e5d44722b3d4f98a1d2f5f9b9fc09b968a843c771c1e597959cceca")
addappid(2590062, 1, "7782f10af3334de62eef51894a0292714422317f7ae093f044941b739960284a")
