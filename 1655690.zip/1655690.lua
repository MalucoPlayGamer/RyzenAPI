-- Lua provided by RyzenAPI
-- Game: Live by the Sword: Tactics Demo

-- MAIN APPLICATION
addappid(1655690)
-- Game: addappid(1655690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655691, 1, "96c0a372756cf7d070775b69914e78095ec11da6f321e8001de8aacd5f76e26a")
