-- Lua provided by RyzenAPI
-- Game: DarkBlood -ReVerse-

-- MAIN APPLICATION
addappid(3052820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052821, 1, "cb242ae3c360076359d42fd86740ebd8032aca1343aadc526e7c208727b1e7cd")
