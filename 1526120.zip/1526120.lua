-- Lua provided by RyzenAPI 
-- Game: HARD TAPES
addappid(1526120)
addappid(1526121, 1, "7f240ac5343d40ed82a73181a1a76d9fc731e07754c70b05b4dcd90486b18ea6")
