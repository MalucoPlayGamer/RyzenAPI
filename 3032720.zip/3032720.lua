-- Lua provided by RyzenAPI
-- Game: addappid(3032720)

-- MAIN APPLICATION
addappid(3032720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032720,0,"3adef2c02f55fc6bbbb84ca2600c7d06e795921eca77f7124065959b9bfb342e")
