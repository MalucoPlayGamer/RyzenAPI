-- Lua provided by RyzenAPI
-- Game: Game: AppID 1218280

-- MAIN APPLICATION
addappid(1218280)
-- Game: addappid(1218280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218281, 1, "a4dc33c78b2492e16075ce060543244cd8d94322af6e5df832a72076d2cf8128")
