-- Lua provided by RyzenAPI
-- Game: 1830430

-- MAIN APPLICATION
addappid(1830430)
-- Game: addappid(1830430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830431, 1, "323e9cdda818b3cdd55e784fd31bd0adaf092f0aabcbaa7b2a0f6e4d46cce635")
