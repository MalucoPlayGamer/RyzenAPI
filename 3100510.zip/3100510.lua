-- Lua provided by SkyAPI 
-- Game: Minds Beneath Us Soundtrack
addappid(3100510)
addappid(3100511, 1, "9658ba1a7d83402c16a1f0b863cbd2bfe0066b0e9352667e887ecf950437c855")
addappid(3100513, 1, "e178d6b637a1cf0443c426c0c380cece24345696d74b66dc4c7ab9f056d23f6c")
