-- Lua provided by RyzenAPI
-- Game: addappid(538340)

-- MAIN APPLICATION
addappid(538340)

-- MAIN APP DEPOTS / PACKAGES
addappid(538342,0,"4d04783d0cadbd8a1d096e68b2d4f6a3632c6255ff8e7e0a86849e67c8e9dbae")
