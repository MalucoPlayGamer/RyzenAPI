-- Lua provided by RyzenAPI
-- Game: addappid(71230)

-- MAIN APPLICATION
addappid(71230)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(71231, 1, "a65a024070f07f2dd441bd1cb16c944b8c8358cd49eaf7e523ed266ee68d782d")
