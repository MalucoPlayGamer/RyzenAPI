-- Lua provided by RyzenAPI
-- Game: addappid(3747990)

-- MAIN APPLICATION
addappid(3747990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3747991, 1, "e71f9870a9bb4a81f8c379dcdc253941fe0265de4c5d8875c8b2dd83e043bd21")
