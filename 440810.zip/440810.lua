-- Lua provided by RyzenAPI
-- Game: addappid(440810)

-- MAIN APPLICATION
addappid(440810)
addappid(446880)
addappid(446882)
addappid(451241)

-- MAIN APP DEPOTS / PACKAGES
addappid(440811, 1, "3c08d8c611ddaa74529c014afbdba780f050991fe3eab8fa1dae8f52f5e42931")
