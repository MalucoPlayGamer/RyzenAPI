-- Lua provided by RyzenAPI
-- Game: Nekokami Demo

-- MAIN APPLICATION
addappid(3005060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3005061, 1, "40c2c9969d6d35d98af3d01be22365c46c6ff92548a1f3ade3e306846ae80a82")

