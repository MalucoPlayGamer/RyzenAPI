-- Lua provided by RyzenAPI
-- Game: Cozy Space

-- MAIN APPLICATION
addappid(2524480)
-- Game: addappid(2524480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524482,0,"9467b2ad0422cdb1cbe3253df9008c92fff875e37f5139ea65e2a1dec5e80f8d")
