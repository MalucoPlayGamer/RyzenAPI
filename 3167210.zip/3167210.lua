-- Lua provided by RyzenAPI
-- Game: 3167210

-- MAIN APPLICATION
addappid(3167210)
-- Game: addappid(3167210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167211, 1, "59dd266fd5f69f1b6bdcc04b108c2938c482364eb44e4ceb3cdde7b62d085cda")
