-- Lua provided by RyzenAPI
-- Game: Shell Runner Demo

-- MAIN APPLICATION
addappid(2958490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958491, 1, "4e9cd7c2ad5cd8b7a60e667a8b9c3c79945ca1c204eb0cebe573a8b3cc917d56")

