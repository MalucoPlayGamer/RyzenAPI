-- Lua provided by RyzenAPI
-- Game: Game: 缠罗深梦 Demo

-- MAIN APPLICATION
addappid(2557980)
-- Game: addappid(2557980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2557981, 1, "eb472ff3dff4a0e95188cfc36510067263a636791e2439b1cdaab4000df234a8")
