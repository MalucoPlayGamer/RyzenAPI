-- Lua provided by RyzenAPI
-- Game: Game: AppID 1012460

-- MAIN APPLICATION
addappid(1012460)
-- Game: addappid(1012460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012461, 1, "08c622a3e35a1f1805bbc1af0a46e464425c0c8e8f1386c69231dd5a6a7a9d53")
