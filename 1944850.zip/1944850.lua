-- Lua provided by RyzenAPI
-- Game: Game: DC's Justice League: Cosmic Chaos

-- MAIN APPLICATION
addappid(1944850)
-- Game: addappid(1944850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944851, 1, "bbaabe01866429792404663b9e954346d028dc448097849710eca7138469be07")
