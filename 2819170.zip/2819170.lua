-- Lua provided by RyzenAPI
-- Game: Desktop BaseBall 2

-- MAIN APPLICATION
addappid(2819170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819171, 1, "2e0e388781ea7a0d1a8d26464ef2dfc657b763a123611161183c300883244df6")
