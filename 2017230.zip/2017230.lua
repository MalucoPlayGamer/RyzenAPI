-- Lua provided by RyzenAPI
-- Game: addappid(2017230)

-- MAIN APPLICATION
addappid(2017230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017231, 1, "67bf27aca2e02a6e4d7f1a777bac7fb1862f2323725fafab2d08ce2160ed1124")
