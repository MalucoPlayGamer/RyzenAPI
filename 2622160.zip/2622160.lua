-- Lua provided by RyzenAPI
-- Game: Exsys Demo

-- MAIN APPLICATION
addappid(2622160)
-- Game: addappid(2622160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622161, 1, "e72fbbe43fe98768e610b7ceb4571c71a6899041a010e29973aeef6abc44356a")
