-- Lua provided by RyzenAPI
-- Game: Game: Progress Game

-- MAIN APPLICATION
addappid(1370410)
-- Game: addappid(1370410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370411, 1, "7dc136d795d5dbc7c3e6602c10e1f9a052e8e82c9e8f2f459bee52a655c78184")
addappid(1370412, 1, "ceb7826658f3e82a520e458cfa66a6036be8b85ea0389aa3b03dd2e62d47294f")
addappid(1370413, 1, "0d28d531f0d14ba99940f8fed4ced9223b607fc52ca7573cae260585657dc645")
addappid(1370414, 1, "58b485846252871af5e915c59f7767aaae2a5c553d493ae2ccd208f98da1542e")
