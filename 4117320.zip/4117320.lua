-- Lua provided by RyzenAPI
-- Game: Drive Together

-- MAIN APPLICATION
addappid(4117320)

-- MAIN APP DEPOTS / PACKAGES
addappid(4117321,0,"299c16e81e0916c129227f8559d5b1f71f24c9ea20f0989c1fd5cf447696cb19")

