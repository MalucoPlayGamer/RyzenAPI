-- Lua provided by RyzenAPI
-- Game: 1170610

-- MAIN APPLICATION
addappid(1170610)
-- Game: addappid(1170610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170611, 1, "2ec20d8a2f96cc2d489f735f247d1390f783f81517bfb92a86b47cacb6b37af3")
addappid(1268050, 0, "e7dffebc7b57b4abba477025cad0ee0acbc7135b2443d824f38beb4ade65c072")
