-- Lua provided by SkyAPI 
-- Game: AppID 1302100
addappid(1302100)
addappid(1302101, 1, "98c53a25227f54fb913fcb643dbcd064ab5b334ad7f7f805d12e369140dbd3a3")
