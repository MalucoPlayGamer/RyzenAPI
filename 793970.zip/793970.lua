-- Lua provided by RyzenAPI
-- Game: Super Kids Racing

-- MAIN APPLICATION
addappid(793970)

-- MAIN APP DEPOTS / PACKAGES
addappid(793971,0,"a4cb35751cce8e5d4eed4606a8f3f0b52d50aecdda9a5746ef015908cad8fda3")

