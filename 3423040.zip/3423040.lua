-- Lua provided by RyzenAPI
-- Game: 3423040

-- MAIN APPLICATION
addappid(3423040)
-- Game: addappid(3423040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3423041, 1, "4d7ea07402b46267c417f5981e62b8571377bd7e11ca10cba533ed6bf3db5daa")
