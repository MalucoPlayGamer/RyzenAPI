-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3204700)
-- Game: addappid(3204700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204700,0,"bf9d511ed9713348a582b240ad21e568291ba49ef4842c1571032667a97b656c")
