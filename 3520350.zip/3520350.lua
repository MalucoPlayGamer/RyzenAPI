-- Lua provided by RyzenAPI
-- Game: 3520350

-- MAIN APPLICATION
addappid(3520350)
-- Game: addappid(3520350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3520351, 1, "2f3ad29c25b0ac9cf7692558077dfaca909a1ccc47eae331cfbb4ae9c32a3a1f")
