-- Lua provided by SkyAPI 
-- Game: 少女的求生之路：研究所
addappid(3520350)
addappid(3520351, 1, "2f3ad29c25b0ac9cf7692558077dfaca909a1ccc47eae331cfbb4ae9c32a3a1f")
