-- Lua provided by RyzenAPI
-- Game: addappid(208460)

-- MAIN APPLICATION
addappid(208460)

-- MAIN APP DEPOTS / PACKAGES
addappid(208461, 1, "edbfa0d4d733bb10718394e19576bc2a880b74ba099a4534023e6a3a042d61f7")
addappid(208470, 0, "bcea41f9d1fb9ca71f8f9adec59c4b7138e53a2ecac6d3575109445d77c33efa")
