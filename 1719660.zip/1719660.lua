-- Lua provided by RyzenAPI
-- Game: My Cute Succubus

-- MAIN APPLICATION
addappid(1719660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719661, 1, "eb1b1c7659359b22638c6c2be314f1129d485164490700d7dd0a98e532410846")
addappid(1779580, 0, "ea6c2bcb7300a79fc7c384375d955b30d1de6b359cd82fb14760062dc684bfe7")
addappid(1795050, 0, "14c9b9a6cc61ed32c26c8dc7388f5f1a00ec8454b55059915552e6d7a5d627ef")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3794060)
