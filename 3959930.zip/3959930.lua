-- Lua provided by RyzenAPI
-- Game: Star Witch

-- MAIN APPLICATION
addappid(3959930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3959932,0,"4a0cf782b97f6d92f3fc4de003bcdf645d5c32d2b418ee82e38c6ffba989f5b4")

