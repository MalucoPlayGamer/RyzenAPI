-- Lua provided by RyzenAPI
-- Game: Andromeda One

-- MAIN APPLICATION
addappid(1180520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180521, 1, "9f1d27a033a93174829bfded0f81d9bfab1ed7f4936cf8e8c2897516bfc62dbb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
