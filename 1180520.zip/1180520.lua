-- Lua provided by RyzenAPI
-- Game: Andromeda One

-- MAIN APPLICATION
addappid(1180520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180521, 1, "9f1d27a033a93174829bfded0f81d9bfab1ed7f4936cf8e8c2897516bfc62dbb")
