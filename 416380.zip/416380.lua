-- Lua provided by RyzenAPI
-- Game: addappid(416380)

-- MAIN APPLICATION
addappid(416380)

-- MAIN APP DEPOTS / PACKAGES
addappid(416381, 1, "c55c4debb5d1647c2849b402ef65dc8cf4296be3c4fe2a4448e54b8cee583299")
addappid(609120, 0, "09a199c1f68136ebb8175dec150305be92c92b1fde6dfa22e9a113800c9bee48")
