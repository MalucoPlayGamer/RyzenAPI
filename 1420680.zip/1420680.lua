-- Lua provided by RyzenAPI
-- Game: Shards of Feyra

-- MAIN APPLICATION
addappid(1420680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420682,0,"172beab7c5234cfec46dd8da50eed0ecb6a3d8d0ca2757451ebf847cd4e755b0")

