-- Lua provided by RyzenAPI
-- Game: Shards of Feyra

-- MAIN APPLICATION
addappid(1420680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420682,0,"172beab7c5234cfec46dd8da50eed0ecb6a3d8d0ca2757451ebf847cd4e755b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
