-- Lua provided by RyzenAPI
-- Game: The Villa: Allison's Diary

-- MAIN APPLICATION
addappid(808210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(808211, 1, "140d3b7a0bc3194844cf36fa2dbdfe5256184b4bededba1edfa015f6c0a92942")

