-- Lua provided by RyzenAPI
-- Game: AppID 808210

-- MAIN APPLICATION
addappid(808210)

-- MAIN APP DEPOTS / PACKAGES
addappid(808211, 1, "140d3b7a0bc3194844cf36fa2dbdfe5256184b4bededba1edfa015f6c0a92942")

