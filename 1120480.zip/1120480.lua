-- Lua provided by RyzenAPI
-- Game: Game: The Anacrusis

-- MAIN APPLICATION
addappid(1120480)
-- Game: addappid(1120480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120481, 1, "b9b6c79ca0f72ad5830e8c79752e935bcd138e17f68f60b0a455588e1a603ba9")
