-- Lua provided by RyzenAPI
-- Game: The Anacrusis

-- MAIN APPLICATION
addappid(1120480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1120481, 1, "b9b6c79ca0f72ad5830e8c79752e935bcd138e17f68f60b0a455588e1a603ba9")

