-- Lua provided by RyzenAPI
-- Game: Game: Nirvana Noir Demo

-- MAIN APPLICATION
addappid(2742440)
-- Game: addappid(2742440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742441, 1, "6239f33beae6757de1707a59bc272c69ef2ae20c889e7a727200fd874d52f88a")
