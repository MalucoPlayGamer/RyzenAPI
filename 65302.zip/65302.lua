-- Lua provided by RyzenAPI
-- Game: Fastfall - Dustforce Original Soundtrack

-- MAIN APPLICATION
addappid(65302)
addappid(1238230)
-- Game: addappid(65302)

-- MAIN APP DEPOTS / PACKAGES
addappid(65302,0,"7ced72d1c1a79822f58b2b0fdd5f57e04fb73e89fe5b274150870b2e1e1d24ce")
