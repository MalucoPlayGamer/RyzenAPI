-- Lua provided by RyzenAPI
-- Game: CAR TUNE: Project

-- MAIN APPLICATION
addappid(1020800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1020801, 1, "25a3008631e435631e3dbfc5639befe1f91f7a5452280550d5a161d5e6e887a2")
