-- Lua provided by RyzenAPI 
-- Game: AppID 1020800
addappid(1020800)
addappid(1020801, 1, "25a3008631e435631e3dbfc5639befe1f91f7a5452280550d5a161d5e6e887a2")
