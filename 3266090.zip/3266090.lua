-- Lua provided by RyzenAPI
-- Game: IT Specialist Simulator

-- MAIN APPLICATION
addappid(3266090)
addappid(4322720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266091,0,"92216a708ff2b3686451435986561ea2bc207c5efd748eaa28908263dad1b748")

