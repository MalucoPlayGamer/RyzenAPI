-- 3266090's Lua and Manifest Created by Hubcap Manifest
-- IT Specialist Simulator
-- Created: August 02, 2026 at 16:35:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3266090) -- IT Specialist Simulator
-- MAIN APP DEPOTS
addappid(3266091, 1, "92216a708ff2b3686451435986561ea2bc207c5efd748eaa28908263dad1b748") -- Depot 3266091
setManifestid(3266091, "7285000280304461797", 2695079373)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4322720) -- Support Pack