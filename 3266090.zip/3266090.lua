-- Lua provided by RyzenAPI
-- Game: IT Specialist Simulator

-- MAIN APPLICATION
addappid(3266090) -- IT Specialist Simulator
addappid(4322720) -- Support Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(3266091, 1, "92216a708ff2b3686451435986561ea2bc207c5efd748eaa28908263dad1b748") -- Depot 3266091

