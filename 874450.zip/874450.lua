-- Lua provided by RyzenAPI
-- Game: Game: Lunacy: Saint Rhodes

-- MAIN APPLICATION
addappid(874450)
-- Game: addappid(874450)

-- MAIN APP DEPOTS / PACKAGES
addappid(874451, 1, "a889c3a2e5b9f2532cb4ddb1d3132b5b2e18311a5eaeebe22ba3ea3638d63209")
