-- Lua provided by SkyAPI 
-- Game: The Supper: New Blood Demo
addappid(3265040)
addappid(3265041, 1, "da189d0c001d9725b8f218ae8382e9ef8e9615a1d0056eecd2fdd36634bbf608")
