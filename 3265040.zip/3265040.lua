-- Lua provided by RyzenAPI
-- Game: The Supper: New Blood Demo

-- MAIN APPLICATION
addappid(3265040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265041, 1, "da189d0c001d9725b8f218ae8382e9ef8e9615a1d0056eecd2fdd36634bbf608")
