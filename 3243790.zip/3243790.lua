-- Lua provided by RyzenAPI
-- Game: 中华英雄Online-一代宗师

-- MAIN APPLICATION
addappid(3243790)
-- Game: addappid(3243790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243791, 1, "5b08873185c1ccf1c8e6d577b4e40f205c7209ef215d40622594d8ad11dc4c61")
