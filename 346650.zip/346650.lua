-- Lua provided by RyzenAPI
-- Game: Break the Cube

-- MAIN APPLICATION
addappid(346650)

-- MAIN APP DEPOTS / PACKAGES
addappid(346651, 1, "56a79457e55d1f36b340f211eb2ee92928a2e5182d6b4c4a9b8918583821e534")

