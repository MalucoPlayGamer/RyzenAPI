-- Lua provided by RyzenAPI
-- Game: Game: Izeriya

-- MAIN APPLICATION
addappid(463830)
-- Game: addappid(463830)

-- MAIN APP DEPOTS / PACKAGES
addappid(463831, 1, "69ad0877b2c0133867223a8e9f71fd6946ea29d98c4804949d4b04e7cbcf8341")
