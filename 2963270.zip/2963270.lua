-- Lua provided by RyzenAPI
-- Game: addappid(2963270)

-- MAIN APPLICATION
addappid(2963270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963271, 1, "d80f7e1df5d544e2d3298efb82d06ab249d74c4dcb975195c19abdb35a7d7d49")
