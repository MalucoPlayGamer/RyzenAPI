-- Lua provided by RyzenAPI
-- Game: FUSER™ - Amerie - "1 Thing"

-- MAIN APPLICATION
addappid(1432143)
-- Game: addappid(1432143)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432143,0,"3ea42c918345b743e4bab10a78450613910e76d47ea85741026393732279bcf1")
