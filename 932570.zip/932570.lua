-- Lua provided by RyzenAPI
-- Game: 阿比斯的宝藏 - Treasure of abyss

-- MAIN APPLICATION
addappid(932570)
addappid(1008540)
-- Game: addappid(932570)

-- MAIN APP DEPOTS / PACKAGES
addappid(932571, 1, "0293f8e1c6d72b534903b2765a722c971b2077b5414d0a585ba500847f63de49")
