-- Lua provided by RyzenAPI
-- Game: addappid(1594110)

-- MAIN APPLICATION
addappid(1594110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594111, 1, "02426ca97f44273c567537a06bd397ce9c9ebb453d9b9cf924a7defece4d0300")
