-- Lua provided by RyzenAPI
-- Game: Subluminal

-- MAIN APPLICATION
addappid(1594110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594111, 1, "02426ca97f44273c567537a06bd397ce9c9ebb453d9b9cf924a7defece4d0300")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
