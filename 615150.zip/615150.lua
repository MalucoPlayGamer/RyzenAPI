-- Lua provided by RyzenAPI
-- Game: Twist of Destiny

-- MAIN APPLICATION
addappid(615150)

-- MAIN APP DEPOTS / PACKAGES
addappid(615151, 1, "dcc8d9ee7932a9fd31ff42e7b518183f32ff7b84befa80967634c800113d1bfd")
