-- Lua provided by RyzenAPI
-- Game: Game: Solitarius

-- MAIN APPLICATION
addappid(1858860)
-- Game: addappid(1858860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858861, 1, "8be494cedf6f0a1038d4dd0393b0380ee49607f877ac96e7abf14febc77cab9a")
