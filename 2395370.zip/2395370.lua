-- Lua provided by RyzenAPI
-- Game: Game: AppID 2395370

-- MAIN APPLICATION
addappid(2395370)
-- Game: addappid(2395370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395371, 1, "5b1e287b484a2b2016f2098aab7f4c6726d244c463c3669085d1f6a3b790ab36")
