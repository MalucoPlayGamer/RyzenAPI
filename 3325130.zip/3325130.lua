-- Lua provided by RyzenAPI
-- Game: Year of the Ladybug: Season 1

-- MAIN APPLICATION
addappid(3325130)
addappid(3366610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3325131, 1, "478e761f8465e0041b4d9b67268325471c70652740fa08f7f1796bd18e259c39")
