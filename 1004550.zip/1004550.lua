-- Lua provided by RyzenAPI
-- Game: Stickman Racer Road Draw 2

-- MAIN APPLICATION
addappid(1004550)
-- Game: addappid(1004550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004551, 1, "833116d6255d83ec546def7cc5998c214ad482d4cdb1ec2b3863794a24b4276a")
