-- Lua provided by RyzenAPI 
-- Game: DANGO!
addappid(1900930)
addappid(1900931, 1, "cc754297ab59c7feb623a42c591730417a4aa0f225c6327c70ef73ca14caf46c")
addappid(2022500, 0, "f2b073079f1b8b27551380f3e07408612b5a951b2d0aea17261c587cc27a055f")
