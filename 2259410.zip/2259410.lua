-- Lua provided by RyzenAPI
-- Game: Game: AppID 2259410

-- MAIN APPLICATION
addappid(2259410)
-- Game: addappid(2259410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259411, 1, "8c22b007d79b8392c255775d519f0d6ae467422c3da8e87da484738ff25263d3")
