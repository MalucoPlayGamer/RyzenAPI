-- Lua provided by RyzenAPI
-- Game: FUCK PARTY CLUB

-- MAIN APPLICATION
addappid(3540360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(3540361, 1, "a4a2678ea010cdc7da23b6867337f0ea3176f8f1fe006e51e27bec47395d94af")

