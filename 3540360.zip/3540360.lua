-- Lua provided by RyzenAPI 
-- Game: FUCK PARTY CLUB
addappid(3540360)
addappid(3540361, 1, "a4a2678ea010cdc7da23b6867337f0ea3176f8f1fe006e51e27bec47395d94af")
