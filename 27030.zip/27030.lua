-- Lua provided by RyzenAPI
-- Game: The Graveyard Trial

-- MAIN APPLICATION
addappid(27030)

-- MAIN APP DEPOTS / PACKAGES
addappid(27031, 1, "48125f42735138a476e81f01b55d4bbd56dd6edca31e6a0ece2f09ed0be3cdc3")
