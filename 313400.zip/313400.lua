-- Lua provided by RyzenAPI
-- Game: addappid(313400)

-- MAIN APPLICATION
addappid(313400)

-- MAIN APP DEPOTS / PACKAGES
addappid(313401, 1, "23e1c7f322ced5fe6ab88e353208c021ae829741126a0a5fff150e720746167a")
