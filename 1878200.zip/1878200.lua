-- Lua provided by RyzenAPI
-- Game: Village RPG

-- MAIN APPLICATION
addappid(1878200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878201, 1, "e0bcc0489d1cdd46bc034ebdfb673ad262dbf0ee620ea3fb8a27e1aa0c2b8544")
