-- Lua provided by RyzenAPI
-- Game: Z

-- MAIN APPLICATION
addappid(275530)
-- Game: addappid(275530)

-- MAIN APP DEPOTS / PACKAGES
addappid(275531, 1, "420a3e4bc7cd9aaee2447e0e771b5016dbfcb565afb72042a953d55ae5202b4b")
