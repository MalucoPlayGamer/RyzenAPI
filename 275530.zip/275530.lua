-- Lua provided by RyzenAPI
-- Game: AppID 275530

-- MAIN APPLICATION
addappid(275530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(275531, 1, "420a3e4bc7cd9aaee2447e0e771b5016dbfcb565afb72042a953d55ae5202b4b")

