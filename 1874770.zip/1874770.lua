-- Lua provided by RyzenAPI
-- Game: Secret Series : BJ

-- MAIN APPLICATION
addappid(1874770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874772,0,"851ffd9921a17b41729b9a8423c388de2949268c0d328a22ad6f2d52e5609867")

