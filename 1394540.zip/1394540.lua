-- Lua provided by RyzenAPI
-- Game: 1394540

-- MAIN APPLICATION
addappid(1394540)
-- Game: addappid(1394540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394541, 1, "4c0bcce8d43463ba7e91f9abc84fbe1046337c9965889537f35fee0910ca182f")
