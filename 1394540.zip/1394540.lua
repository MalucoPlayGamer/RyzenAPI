-- Lua provided by RyzenAPI 
-- Game: AppID 1394540
addappid(1394540)
addappid(1394541, 1, "4c0bcce8d43463ba7e91f9abc84fbe1046337c9965889537f35fee0910ca182f")
