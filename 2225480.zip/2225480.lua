-- Lua provided by RyzenAPI
-- Game: MEMOLITH: Forsaken by Light

-- MAIN APPLICATION
addappid(2225480)
-- Game: addappid(2225480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225481, 1, "39a1b1a0f70b37d090f9a7ff794524a69a26b30eb5442d4cd50abf3105e68ef3")
