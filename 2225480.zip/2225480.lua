-- Lua provided by RyzenAPI
-- Game: MEMOLITH: Forsaken by Light

-- MAIN APPLICATION
addappid(2225480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2225481, 1, "39a1b1a0f70b37d090f9a7ff794524a69a26b30eb5442d4cd50abf3105e68ef3")

