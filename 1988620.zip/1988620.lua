-- Lua provided by RyzenAPI
-- Game: 1988620

-- MAIN APPLICATION
addappid(1988620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988620,0,"a4a3506eac30c41fbef9141a5388e6583b33b0a8d3ee799f6dfea8fe620eb5d2")
