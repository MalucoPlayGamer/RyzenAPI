-- Lua provided by RyzenAPI
-- Game: BISQUE DOLL

-- MAIN APPLICATION
addappid(1428460)
-- Game: addappid(1428460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428461, 1, "0e24654409934b80c4cc49c6b3de13f5276a8dc4eef9833f985b981fc6920b9a")
