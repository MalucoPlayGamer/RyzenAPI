-- Lua provided by RyzenAPI 
-- Game: BISQUE DOLL
addappid(1428460)
addappid(1428461, 1, "0e24654409934b80c4cc49c6b3de13f5276a8dc4eef9833f985b981fc6920b9a")
