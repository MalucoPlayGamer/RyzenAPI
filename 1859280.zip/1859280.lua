-- Lua provided by RyzenAPI
-- Game: Game: 7 Days to End with You

-- MAIN APPLICATION
addappid(1859280)
-- Game: addappid(1859280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859281, 1, "61c6b0b4486a044499b6aae9a4e8e212360700d7b34feec5f435cb4d691dc5a2")
