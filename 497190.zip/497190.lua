-- Lua provided by RyzenAPI
-- Game: Game: Pichon

-- MAIN APPLICATION
addappid(497190)
-- Game: addappid(497190)

-- MAIN APP DEPOTS / PACKAGES
addappid(497191, 1, "6f2bb4748eaf15240cb135900bf0b231cecd897a1aa2334628ade5353e282204")
addappid(497192, 1, "0c4eb95b2be01d75c66218cad52888ba9ae237cf278d693db703301d5118aa60")
