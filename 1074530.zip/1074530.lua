-- Lua provided by RyzenAPI
-- Game: Game: AppID 1074530

-- MAIN APPLICATION
addappid(1074530)
-- Game: addappid(1074530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074531, 1, "d3d8c3f0bd429c828e30c087a08e9067db4f08d14a80d82f2105e859897a4209")
