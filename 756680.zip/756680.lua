-- Lua provided by RyzenAPI
-- Game: Game: Angelo Skate Away

-- MAIN APPLICATION
addappid(756680)
-- Game: addappid(756680)

-- MAIN APP DEPOTS / PACKAGES
addappid(756681, 1, "2f9eb1daa55a190dcc8fbaf53decba7da5bd3df4f88ef2cad5e82cc49fef1581")
