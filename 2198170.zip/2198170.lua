-- Lua provided by RyzenAPI
-- Game: 2198170

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2198170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198173,0,"daf2d85ddf542c50f8f42589acd794bb744e206a191f82f6ae35a086aa23a867")

