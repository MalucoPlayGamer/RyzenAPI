-- Lua provided by RyzenAPI
-- Game: addappid(2100000)

-- MAIN APPLICATION
addappid(2100000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100000,0,"f8fbe9fedd89e2d82ca858503a4fee0261dee6815248b70f6d2957c88839cdb2")
