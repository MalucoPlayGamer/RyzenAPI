-- Lua provided by RyzenAPI
-- Game: Nienix: Cosmic Warfare

-- MAIN APPLICATION
addappid(1332760)
-- Game: addappid(1332760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332761, 1, "198199653ebe7899a33da1d08fa86370203e77d07f4c89a38d8e4e35c2b1431b")
