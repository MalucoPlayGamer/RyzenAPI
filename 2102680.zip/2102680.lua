-- Lua provided by RyzenAPI
-- Game: Blinded by Fear

-- MAIN APPLICATION
addappid(2102680)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(2102681, 1, "e91a1d1287fb3f3f74b31461123e08015373b88f0d2f7d041e556a1df3d6c1a6")

