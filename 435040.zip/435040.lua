-- Lua provided by RyzenAPI
-- Game: Incredible Dracula: Chasing Love Collector's Edition

-- MAIN APPLICATION
addappid(435040)

-- MAIN APP DEPOTS / PACKAGES
addappid(435041, 1, "fc01e1d49b0a3a62935e621ba894fb0f0fa3050a39c1a903da1af1f2c7b363b5")
addappid(435042, 1, "aaafd31eb5311b19a9bf64f4453e359949039f5d500d44dce9a5ecd20b20e53a")
addappid(435043, 1, "1f2520b7197419d53f88da7c3076d6616e7a06450395a04dd129a767dfd6e413")
addappid(435044, 1, "f8ae703e2754c1fb9e691325d5229d3de1f1ae2e2478bb59a74ac2eefe5b1b02")

