-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Intermediate String Skipping Exercise 2

-- MAIN APPLICATION
addappid(1122561)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122561,0,"87eb36a960d529f3bf6052e359ef856774ed416d2d5cf1ca722c5700c8b061ec")

