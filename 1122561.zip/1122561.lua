-- Lua provided by RyzenAPI
-- Game: 1122561

-- MAIN APPLICATION
addappid(1122561)
-- Game: addappid(1122561)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122561,0,"87eb36a960d529f3bf6052e359ef856774ed416d2d5cf1ca722c5700c8b061ec")
