-- Lua provided by RyzenAPI
-- Game: Game: Assembly Line 2

-- MAIN APPLICATION
addappid(2791880)
-- Game: addappid(2791880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791881, 1, "8afc3face5d0a8e22b5c6d5572efb8f9e70d52fd543f00561f0d40027b19e3ba")
