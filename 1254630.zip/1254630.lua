-- Lua provided by RyzenAPI
-- Game: Game: AppID 1254630

-- MAIN APPLICATION
addappid(1254630)
-- Game: addappid(1254630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254631, 1, "8671996d8cb2161dfcc92756812bf1febc1ff2046c7b74033a666d8931c0f07f")
