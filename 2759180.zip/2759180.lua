-- Lua provided by RyzenAPI
-- Game: addappid(2759180)

-- MAIN APPLICATION
addappid(2759180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759181, 1, "273ec71751922c5a03eb9e737cb029d87c50942ed5464b9ebe3d36be5d34f18a")
