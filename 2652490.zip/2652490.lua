-- Lua provided by RyzenAPI
-- Game: Agent Mirai and the Submission Machines

-- MAIN APPLICATION
addappid(2652490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2652491, 1, "6e24f3764bd3075c81f7d16c37a20481526acc72c2c6765bf80ce05e179b0d50")
addappid(2652492, 1, "0f8ef832f5c52747644804bd29339c52e49a4da970f673fa3eab27bd0a573e46")
