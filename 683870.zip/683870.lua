-- Lua provided by RyzenAPI
-- Game: Game: Quest of Vidhuraa

-- MAIN APPLICATION
addappid(683870)
-- Game: addappid(683870)

-- MAIN APP DEPOTS / PACKAGES
addappid(683871, 1, "fb86e75892caba941e4f8a803437f27150606d3a75a218a7af13e88d06ef9fc1")
