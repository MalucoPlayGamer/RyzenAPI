-- Lua provided by RyzenAPI
-- Game: addappid(2827780)

-- MAIN APPLICATION
addappid(2827780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827781, 1, "7a37ac237bd89b04f7bfc18b2d74eb2b5e8e94323c2db675e94de5ef6c5c7895")
