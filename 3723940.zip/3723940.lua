-- Lua provided by RyzenAPI
-- Game: Game: Stellar: Chroma Codex

-- MAIN APPLICATION
addappid(3723940)
-- Game: addappid(3723940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723941, 1, "5ed15aaa4945e8220544699b73e29e4adbb9a2451c8a10c174094f143d2f70f0")
