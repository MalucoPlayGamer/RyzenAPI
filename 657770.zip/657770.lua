-- Lua provided by SkyAPI 
-- Game: AppID 657770
addappid(657770)
addappid(657771, 1, "f08cfa6a1027e290f4c1f1a5ff5a395f943d5ff2a0d2cc7fb377fd6e94b3e448")
