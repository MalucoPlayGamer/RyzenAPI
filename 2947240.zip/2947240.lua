-- Lua provided by RyzenAPI
-- Game: Game: Kimi no Hitomi ni Hit Me

-- MAIN APPLICATION
addappid(2947240)
-- Game: addappid(2947240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947241, 1, "44386febfdbf66da789f698a5ffe214dadfcbe59dd863fe10ad556f7c53104ce")
