-- Lua provided by RyzenAPI
-- Game: Taimanin Asagi 1: Trial

-- MAIN APPLICATION
addappid(1152100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152101, 1, "62d2107639758e08a201d120d25fb8b7250539613f51b1e98c466cb37a2d1861")
