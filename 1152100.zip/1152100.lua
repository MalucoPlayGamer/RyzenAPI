-- Lua provided by RyzenAPI
-- Game: Taimanin Asagi 1: Trial

-- MAIN APPLICATION
addappid(1152100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152101, 1, "62d2107639758e08a201d120d25fb8b7250539613f51b1e98c466cb37a2d1861")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
