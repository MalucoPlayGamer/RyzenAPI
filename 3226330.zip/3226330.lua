-- Lua provided by RyzenAPI
-- Game: Game: FOOT LOVERS

-- MAIN APPLICATION
addappid(3226330)
-- Game: addappid(3226330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226331, 1, "f36abd5a345b1b14420be0d53daefa80d16d663d783eb1ef868ee0066984779f")
