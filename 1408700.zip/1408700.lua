-- Lua provided by RyzenAPI
-- Game: Osman Gazi

-- MAIN APPLICATION
addappid(1408700)
-- Game: addappid(1408700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408701, 1, "21d4025d74bf53f1ad32e88d081f27989541ccfd401620152490b8706ff36fd6")
