-- Lua provided by RyzenAPI 
-- Game: Snow Daze: The Music of Winter Special Edition
addappid(852480)
addappid(852481, 1, "79d3e953de33b4b7fbbc1708f0ad499f88237fb12cbf51605c4c762300910054")
addappid(852482, 1, "39e562014785125fa1aaf5772a50f440f9f0b7ac73ad3ddfa06b72875af89d48")
addappid(852483, 1, "8c14d883fce75154753682162de778a7d9bf97c150aa20277391000fa503896f")
