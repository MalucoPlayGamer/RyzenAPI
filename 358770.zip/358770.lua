-- Lua provided by RyzenAPI
-- Game: Game: The Reject Demon: Toko Chapter 0 — Prelude

-- MAIN APPLICATION
addappid(358770)
-- Game: addappid(358770)

-- MAIN APP DEPOTS / PACKAGES
addappid(358771, 1, "4adaeb04f3418e2bf219e1dba49a60460e0d4c6300f7ef9108f4dd7982b9fc17")
