-- Lua provided by RyzenAPI
-- Game: Nice Pro?

-- MAIN APPLICATION
addappid(3350780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350781, 1, "a8a4bf38dedb8b8995f45ca405bceb9102ec5cd242b64a635c9bbd202d0d6954")

