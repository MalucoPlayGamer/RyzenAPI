-- Lua provided by RyzenAPI
-- Game: 2685490

-- MAIN APPLICATION
addappid(2685490)
-- Game: addappid(2685490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685491, 1, "7a03d15eeae91c1e2bd8b55cb3dc95919e73f07e4bb7bdfe3791ab4c6285fec9")
