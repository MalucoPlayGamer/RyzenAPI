-- Lua provided by SkyAPI 
-- Game: Look or Die
addappid(3145520)
addappid(3145521, 1, "a5904b4821ed99aabff42c504bcc57a2229d9a70c95c87f183c30c12f61abe5e")
