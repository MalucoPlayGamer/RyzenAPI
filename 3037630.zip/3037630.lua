-- Lua provided by RyzenAPI
-- Game: AppID 3037630

-- MAIN APPLICATION
addappid(3037630)
-- Game: addappid(3037630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037631, 1, "83213ad200f5fe80caafe46c47fd2344b05c242587f1049d929da9df8ec8745e")
