-- Lua provided by RyzenAPI
-- Game: Survivor Challenge TD

-- MAIN APPLICATION
addappid(2443170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2443171, 1, "379e629757d60e6dc27f1d0624d7caf060dde4a43169780c3ebec6f9e6faaccb")

