-- Lua provided by RyzenAPI
-- Game: Fengdu Chronicles of battle

-- MAIN APPLICATION
addappid(3221000)
-- Game: addappid(3221000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3221001, 1, "1019c26e2dd03e1afb5b0b2bf5790f34a409e22e69216cb8a32521e851e0af4e")
