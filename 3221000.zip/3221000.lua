-- Lua provided by SkyAPI 
-- Game: Fengdu Chronicles of battle
addappid(3221000)
addappid(3221001, 1, "1019c26e2dd03e1afb5b0b2bf5790f34a409e22e69216cb8a32521e851e0af4e")
