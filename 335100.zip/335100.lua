-- Lua provided by RyzenAPI
-- Game: Dwarf Tower

-- MAIN APPLICATION
addappid(335100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(335101, 1, "5f2a4011fda2fc61e0102fc25f7c73756f2d060643a0e2b535f364181830a3fd")
addappid(335102, 1, "321276fd3c1bdc2b053aea58e5479becc4d54a84b71fc680b4f0a0d222640890")

