-- Lua provided by RyzenAPI
-- Game: Dwarf Tower

-- MAIN APPLICATION
addappid(335100)

-- MAIN APP DEPOTS / PACKAGES
addappid(335101, 1, "5f2a4011fda2fc61e0102fc25f7c73756f2d060643a0e2b535f364181830a3fd")
addappid(335102, 1, "321276fd3c1bdc2b053aea58e5479becc4d54a84b71fc680b4f0a0d222640890")
