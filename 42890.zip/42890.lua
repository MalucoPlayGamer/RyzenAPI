-- Lua provided by RyzenAPI
-- Game: Sword of the Stars: Complete Collection

-- MAIN APPLICATION
addappid(42890)

-- MAIN APP DEPOTS / PACKAGES
addappid(42891, 1, "13ce0404e65bee1b52a6b3e762b8cdd6a14553cfde3efe08160c1dfb9d7b111a")

