-- Lua provided by RyzenAPI
-- Game: addappid(3204120)

-- MAIN APPLICATION
addappid(3204120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204121, 1, "8e5979fb805b0194cd6f902c893ae3ca24d9cc297407aa0d57b26e7f6fe04f62")
