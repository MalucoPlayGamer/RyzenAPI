-- Lua provided by RyzenAPI
-- Game: Grinny’s Playhouse

-- MAIN APPLICATION
addappid(4712460)

-- MAIN APP DEPOTS / PACKAGES
addappid(4712461,0,"158631f3e2c495e8270b551ed63c4365839825585119dd9f45e1ed0fe64f2670")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
