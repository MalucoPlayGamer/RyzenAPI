-- Lua provided by RyzenAPI
-- Game: Grinny’s Playhouse

-- MAIN APPLICATION
addappid(4712460)

-- MAIN APP DEPOTS / PACKAGES
addappid(4712461,0,"158631f3e2c495e8270b551ed63c4365839825585119dd9f45e1ed0fe64f2670")

