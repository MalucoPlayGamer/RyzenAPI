-- Lua provided by RyzenAPI
-- Game: 2437710

-- MAIN APPLICATION
addappid(2437710)
-- Game: addappid(2437710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437711, 1, "469a745bfbf4de66e3c163075b850488f4c21a61149ed524f241136ad1faac10")
