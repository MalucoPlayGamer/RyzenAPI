-- Lua provided by RyzenAPI
-- Game: Electric Fairyland

-- MAIN APPLICATION
addappid(3101620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101621, 1, "5dead3376ad70fbb830a3bf9b974daf6ef60a4eb507fc141edc35148d41eb74d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
