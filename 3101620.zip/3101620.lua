-- Lua provided by RyzenAPI
-- Game: Electric Fairyland

-- MAIN APPLICATION
addappid(3101620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101621, 1, "5dead3376ad70fbb830a3bf9b974daf6ef60a4eb507fc141edc35148d41eb74d")
