-- Lua provided by SkyAPI 
-- Game: Electric Fairyland
addappid(3101620)
addappid(3101621, 1, "5dead3376ad70fbb830a3bf9b974daf6ef60a4eb507fc141edc35148d41eb74d")
