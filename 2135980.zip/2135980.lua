-- Lua provided by RyzenAPI
-- Game: addappid(2135980)

-- MAIN APPLICATION
addappid(2135980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135981, 1, "1a3b753dea973bd7269265f93816daa0ab4787fd9b4b4899be13da68a2470167")
