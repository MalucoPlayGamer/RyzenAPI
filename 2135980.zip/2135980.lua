-- Lua provided by RyzenAPI
-- Game: The Icon Battles

-- MAIN APPLICATION
addappid(2135980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135981, 1, "1a3b753dea973bd7269265f93816daa0ab4787fd9b4b4899be13da68a2470167")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
