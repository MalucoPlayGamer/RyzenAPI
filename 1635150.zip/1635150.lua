-- Lua provided by RyzenAPI
-- Game: Protect the Earth

-- MAIN APPLICATION
addappid(1635150)
-- Game: addappid(1635150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635151, 1, "c8758861aeba7bbfb6416c75535212aa216f97027b8f12fb9331e6d473740940")
