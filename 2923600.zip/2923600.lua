-- Lua provided by RyzenAPI
-- Game: addappid(2923600)

-- MAIN APPLICATION
addappid(2923600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923601, 1, "a842e209150f81f3050a29177befb6947d4d80fdc2ec39d631f8ad679ff05f04")
