-- Lua provided by RyzenAPI 
-- Game: AppID 795420
addappid(795420)
addappid(795421, 1, "506d9172e8c59e6c01a475b97da217e8cc8813bf019f637ef74afbebdbd004a5")
addappid(795422, 1, "5fbc321a0b618344d6c8fffa0d425a0ed2e10331de68e3ead6df4c65097ffe3a")
addappid(795423, 1, "124e3088f647cfed03618254da14a59a31135435d2c39e81d87a1a4848e47b73")
