-- Lua provided by RyzenAPI
-- Game: Election Year Knockout

-- MAIN APPLICATION
addappid(1313310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1313311, 1, "267b71bafc7410a5c9ce7a42cf3c465df82ce268e5040a335c2bb4bf4414c1ec")

