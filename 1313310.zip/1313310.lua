-- Lua provided by RyzenAPI
-- Game: 1313310

-- MAIN APPLICATION
addappid(1313310)
-- Game: addappid(1313310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313311, 1, "267b71bafc7410a5c9ce7a42cf3c465df82ce268e5040a335c2bb4bf4414c1ec")
