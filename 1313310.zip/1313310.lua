-- Lua provided by RyzenAPI 
-- Game: AppID 1313310
addappid(1313310)
addappid(1313311, 1, "267b71bafc7410a5c9ce7a42cf3c465df82ce268e5040a335c2bb4bf4414c1ec")
