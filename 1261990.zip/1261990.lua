-- Lua provided by RyzenAPI
-- Game: Horse Racing Rally

-- MAIN APPLICATION
addappid(1261990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261991, 1, "aa29194bb1d4c84f5b760493033f9b81649db43615881812e9e5cd022e806af9")

