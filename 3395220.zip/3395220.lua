-- Lua provided by RyzenAPI 
-- Game: Skuf vs beer bottle party
addappid(3395220)
addappid(3395221, 1, "b8b1b9d11a5eb9e2c0965b77716d635f29b93d0e158c5d54cd7855eec6bced43")
