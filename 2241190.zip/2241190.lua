-- Lua provided by RyzenAPI
-- Game: Game: Christmas Luge

-- MAIN APPLICATION
addappid(2241190)
-- Game: addappid(2241190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241191, 1, "af2fb86740593bdc001776041c3d7bf871b26a22066233b186fc1ede36cc2676")
