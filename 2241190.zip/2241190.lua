-- Lua provided by RyzenAPI
-- Game: Christmas Luge

-- MAIN APPLICATION
addappid(2241190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2241191, 1, "af2fb86740593bdc001776041c3d7bf871b26a22066233b186fc1ede36cc2676")

