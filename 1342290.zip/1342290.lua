-- Lua provided by RyzenAPI
-- Game: Himeko Maid

-- MAIN APPLICATION
addappid(1342290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342291, 1, "8f074d0bd3e0f47776a82ea9cfd64bdffc08ed65d16ce9ec0da63b01586e9d17")
