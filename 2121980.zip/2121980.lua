-- Lua provided by RyzenAPI
-- Game: Void Stranger

-- MAIN APPLICATION
addappid(2121980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121981, 1, "0b512dd421c449a8b727810e948ae4d41c3e15cc0184b0dcd1a00b86df251c7f")
