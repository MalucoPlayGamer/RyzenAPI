-- Lua provided by SkyAPI 
-- Game: AppID 2121980
addappid(2121980)
addappid(2121981, 1, "0b512dd421c449a8b727810e948ae4d41c3e15cc0184b0dcd1a00b86df251c7f")
