-- Lua provided by RyzenAPI
-- Game: KickHim

-- MAIN APPLICATION
addappid(526460)

-- MAIN APP DEPOTS / PACKAGES
addappid(526461, 1, "fb9e13cd9e8c07a5cb92bef074151c030e14f35333f52eaade6121b16adef3bf")

