-- Lua provided by RyzenAPI
-- Game: Game: Princess&Blade

-- MAIN APPLICATION
addappid(1639430)
addappid(1690970)
-- Game: addappid(1639430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639431, 1, "957bbb3429c03d99c686b26098f65bda3d42f715d772ef47356409e3ea0b07bd")
