-- Lua provided by RyzenAPI
-- Game: addappid(597970)

-- MAIN APPLICATION
addappid(597970)

-- MAIN APP DEPOTS / PACKAGES
addappid(597971, 1, "b3dcece0c1f1fc50d0bb44c04715eba112dcd8dc892052a401b453061620a37d")
