-- Lua provided by SkyAPI 
-- Game: Unfinished Battle
addappid(799180)
addappid(799181, 1, "936de12357c6dd1c543e7a2981ef3fc7c6bf24c70f2c18c12cd51fef54150414")
