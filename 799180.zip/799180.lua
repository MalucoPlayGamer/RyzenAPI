-- Lua provided by RyzenAPI
-- Game: 799180

-- MAIN APPLICATION
addappid(799180)
-- Game: addappid(799180)

-- MAIN APP DEPOTS / PACKAGES
addappid(799181, 1, "936de12357c6dd1c543e7a2981ef3fc7c6bf24c70f2c18c12cd51fef54150414")
