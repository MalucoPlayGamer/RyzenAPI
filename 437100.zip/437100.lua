-- Lua provided by RyzenAPI
-- Game: My Night Job

-- MAIN APPLICATION
addappid(437100)
-- Game: addappid(437100)

-- MAIN APP DEPOTS / PACKAGES
addappid(437101, 1, "3f6ec807031c38fae0c3eb1976a4985fb6f368d3795cea4f9ffdcf584a54b8f1")
