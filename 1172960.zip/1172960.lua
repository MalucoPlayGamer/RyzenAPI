-- Lua provided by RyzenAPI
-- Game: The Painscreek Killings - The Making of The Painscreek Killings

-- MAIN APPLICATION
addappid(1172960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172960,0,"21831e9bbbee50131b5d917c964b2d9675f4726b12acd33df9ec7c8c628bac41")
