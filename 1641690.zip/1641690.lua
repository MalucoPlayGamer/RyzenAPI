-- Lua provided by RyzenAPI
-- Game: Game: Crawlyard Demo

-- MAIN APPLICATION
addappid(1641690)
-- Game: addappid(1641690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641691, 1, "075bc0ae78c57dd7938f05b69803412757d8436b95e628cdff1b6bee77614676")
