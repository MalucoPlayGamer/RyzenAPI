-- Lua provided by RyzenAPI
-- Game: Rollick N' Roll

-- MAIN APPLICATION
addappid(3274880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274881,0,"913bf1bea4e8e7e27c2bcb4950e996e260447b3e835726ad408560bae4a4c72a")

