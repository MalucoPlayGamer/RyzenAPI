-- Lua provided by RyzenAPI
-- Game: BACK OF SPACE

-- MAIN APPLICATION
addappid(714590)

-- MAIN APP DEPOTS / PACKAGES
addappid(714592,0,"814c1a5767becb8b0dd612c93ab720e2752b8ebe6f82a54971d4d2bcf60deb5b")
