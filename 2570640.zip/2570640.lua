-- Lua provided by RyzenAPI
-- Game: Idle Space Navy

-- MAIN APPLICATION
addappid(2570640)
-- Game: addappid(2570640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570642,0,"1fd0b8989d9c006a70dfb904019b314f1418ab477bbc7b1fc2746df662da54d7")
addappid(2570643,0,"360f0700123ffb72c01c7a16a8c96efc8fa31bfd4ce02a4c81f0344b971aff7e")
