-- Lua provided by RyzenAPI
-- Game: Game: Embers of Magic

-- MAIN APPLICATION
addappid(526400)
-- Game: addappid(526400)

-- MAIN APP DEPOTS / PACKAGES
addappid(526401, 1, "f3beb4d923d3ebc6ce1885f39845148af564def27fb51cacbc8828e75dafddc8")
