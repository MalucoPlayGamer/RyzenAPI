-- Lua provided by RyzenAPI
-- Game: 612110

-- MAIN APPLICATION
addappid(612110)
-- Game: addappid(612110)

-- MAIN APP DEPOTS / PACKAGES
addappid(612111, 1, "de08d6e9b19cdebb09e583403184b333118470ad7a3a8577a51c22b1249db1a6")
