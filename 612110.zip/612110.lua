-- Lua provided by SkyAPI 
-- Game: AppID 612110
addappid(612110)
addappid(612111, 1, "de08d6e9b19cdebb09e583403184b333118470ad7a3a8577a51c22b1249db1a6")
