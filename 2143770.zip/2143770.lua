-- Lua provided by RyzenAPI
-- Game: 2143770

-- MAIN APPLICATION
addappid(2143770)
-- Game: addappid(2143770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143771, 1, "7384349150996efc5d4c96dbb7cb1919620091afd1b4acb3329eb2fe41e9bd02")
