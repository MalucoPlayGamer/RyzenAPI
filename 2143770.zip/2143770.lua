-- Lua provided by SkyAPI 
-- Game: Drift racing car
addappid(2143770)
addappid(2143771, 1, "7384349150996efc5d4c96dbb7cb1919620091afd1b4acb3329eb2fe41e9bd02")
