-- Lua provided by RyzenAPI
-- Game: 1621990

-- MAIN APPLICATION
addappid(1621990)
-- Game: addappid(1621990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621991, 1, "bc000d9af5e354cc1ae5114408f5c1d2d516110c3f0c9f913686b41340b6c73b")
