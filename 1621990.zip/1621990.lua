-- Lua provided by RyzenAPI
-- Game: Stray Blade

-- MAIN APPLICATION
addappid(1621990)
addappid(2430460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1621991, 1, "bc000d9af5e354cc1ae5114408f5c1d2d516110c3f0c9f913686b41340b6c73b")

