-- Lua provided by RyzenAPI
-- Game: Game: AppID 2814950

-- MAIN APPLICATION
addappid(2814950)
-- Game: addappid(2814950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814951, 1, "7f0d3e883fab68900fb205c94befff009590f26762a107207e166f7e59d7a068")
