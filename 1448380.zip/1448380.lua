-- Lua provided by RyzenAPI
-- Game: AppID 1448380

-- MAIN APPLICATION
addappid(1448380)
-- Game: addappid(1448380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448381, 1, "571723f2dded3f98b568ece7e4039bd34161efb5358aed504ce529bc7ac7b843")
