-- Lua provided by RyzenAPI
-- Game: 2452900

-- MAIN APPLICATION
addappid(2452900)
-- Game: addappid(2452900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452902,0,"0fa2387622cfdeb939436e84cfd1261699bd6419450caa365c762602e4fddbb4")
