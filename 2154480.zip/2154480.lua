-- Lua provided by RyzenAPI
-- Game: Cyclo Chambers Demo

-- MAIN APPLICATION
addappid(2154480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154481, 1, "07a12bded50cc1e424955ae886855e1302fa79e95db985bad9d5eb875d7ff9bc")

