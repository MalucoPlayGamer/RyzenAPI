-- Lua provided by SkyAPI 
-- Game: AppID 3296620
addappid(3296620)
addappid(3296621, 1, "ff6664c7965fc03d87cee87ca46cb0016360426b9fe694e02b2a9a2b48a89f16")
