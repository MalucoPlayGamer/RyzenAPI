-- Lua provided by RyzenAPI
-- Game: Game: From Soil to Bottle

-- MAIN APPLICATION
addappid(2873190)
-- Game: addappid(2873190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873191, 1, "1e24fdad66c070630605cd63116c274c58387a9134fd88b97818c29625631921")
