-- Lua provided by RyzenAPI
-- Game: AppID 509770

-- MAIN APPLICATION
addappid(509770)

-- MAIN APP DEPOTS / PACKAGES
addappid(509771, 1, "9aa6c8b5462c5b793c689df14ca92447d58fc6eaedbd6503e6c3407b783aac34")
addappid(509772, 1, "a8adee7e9acfa170d6de459da138baa3ec8e82bf059b0a49efd7dbcba68fa483")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
