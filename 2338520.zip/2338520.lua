-- Lua provided by RyzenAPI
-- Game: Underground Blossom Demo

-- MAIN APPLICATION
addappid(2338520)
-- Game: addappid(2338520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338521, 1, "1e708e757c21c363593f5ee603edf1bb14f61da66410ef8734b14c806ae86cfc")
