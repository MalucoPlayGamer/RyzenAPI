-- Lua provided by RyzenAPI 
-- Game: Underground Blossom Demo
addappid(2338520)
addappid(2338521, 1, "1e708e757c21c363593f5ee603edf1bb14f61da66410ef8734b14c806ae86cfc")
