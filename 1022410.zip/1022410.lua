-- Lua provided by RyzenAPI
-- Game: DFF NT: Rod of Censure, the Emperor's 4th Weapon

-- MAIN APPLICATION
addappid(1022410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022410,0,"b777b816105c728909c6a707714f3ae75156f7dd914c11c5541120120fa4ff99")

