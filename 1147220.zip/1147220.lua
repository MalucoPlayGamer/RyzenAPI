-- Lua provided by RyzenAPI
-- Game: addappid(1147220)

-- MAIN APPLICATION
addappid(1147220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147221, 1, "3070c7d0bf4f628ff8d70dc9fddc10b56c7fd27dc996e1a9149e4ff639ebf914")
