-- Lua provided by RyzenAPI
-- Game: fault - milestone two side:above

-- MAIN APPLICATION
addappid(344770)

-- MAIN APP DEPOTS / PACKAGES
addappid(344771, 1, "f08da15542178b2ce08192eed62b0ccc77b48c3f763369f8dfedb54ded82b909")
