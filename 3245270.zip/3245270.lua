-- Lua provided by RyzenAPI
-- Game: In Essence: Nil - (MaidxMan) / chapel

-- MAIN APPLICATION
addappid(3245270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245271, 1, "be22e50d9f1a73b25252d293635bcb44e8dae8cf2084ee111969ae794c420614")
