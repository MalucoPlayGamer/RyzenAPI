-- Lua provided by RyzenAPI
-- Game: addappid(413350)

-- MAIN APPLICATION
addappid(413350)

-- MAIN APP DEPOTS / PACKAGES
addappid(413351, 1, "63859fb4b00f10ffab41bbab49b27f76b12aaa54e9d0b7e367834c1564c5fb2c")
