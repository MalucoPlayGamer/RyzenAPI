-- Lua provided by RyzenAPI
-- Game: Game: Sleepy sister's friend

-- MAIN APPLICATION
addappid(3706440)
-- Game: addappid(3706440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3706441, 1, "281c7c0f4cf3d430cdb637389ecd35f00bc5ca7bc24978ade4ed5690372cc4ba")
