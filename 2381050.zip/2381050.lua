-- Lua provided by RyzenAPI
-- Game: Hyper Hentai Elf Attendant

-- MAIN APPLICATION
addappid(2381050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381051, 1, "9680753d18cab11e369c94c08dae1795a7ce8bb044eed01c37783bb907bbd7be")
