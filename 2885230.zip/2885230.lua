-- Lua provided by RyzenAPI
-- Game: AppID 2885230

-- MAIN APPLICATION
addappid(2885230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885231, 1, "055c5e8fc60d3a666195f36fca0cd1c54133ef5575a379c900edddaaa7d39df4")
addappid(2885260, 0, "22a903deaeb205b391447076cb3331fec2d71e251352017fe17bf6e8f43c0853")
addappid(2885270, 0, "1bd77237e7b75614c8d2643ba444c1788892650205953cb798a4eb1bceac544e")
addappid(2885280, 0, "f49d020fcd7a14507931f735c8e6930768ef6dc6e55b6f168c1ed183cdc9e73b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
