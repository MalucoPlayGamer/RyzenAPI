-- Lua provided by RyzenAPI
-- Game: addappid(239220)

-- MAIN APPLICATION
addappid(239220)
addappid(326200)

-- MAIN APP DEPOTS / PACKAGES
addappid(239221, 1, "6ea53a5a3b3a1379c4c2b0fa0572e8676d414fd922cecff0b93ef19f54fe7473")
addappid(239222, 1, "a553592bb395dfc6b51dca162fb010bdfb6a3d069388502fa64dfbc6fc717554")
