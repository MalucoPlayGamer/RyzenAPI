-- 239220's Lua and Manifest Created by Hubcap Manifest
-- The Mighty Quest For Epic Loot
-- Created: October 01, 2025 at 00:21:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 35
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(239220) -- The Mighty Quest For Epic Loot
-- MAIN APP DEPOTS
addappid(239221, 1, "6ea53a5a3b3a1379c4c2b0fa0572e8676d414fd922cecff0b93ef19f54fe7473") -- Mighty Quest : Game
setManifestid(239221, "3173768960693227637", 1433910165)
addappid(239222, 1, "a553592bb395dfc6b51dca162fb010bdfb6a3d069388502fa64dfbc6fc717554") -- Mighty Quest : Tools
setManifestid(239222, "3379475607435878227", 6404)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(260400) -- Chunk of Change Knight
addappid(260401) -- Chunk of Change Archer
addappid(260402) -- Mage Legit Fan
addappid(260403) -- High Roller
addappid(275550) -- The Mighty Quest For Epic Loot - Supply Pack
addappid(275551) -- Attacker Pack
addappid(275552) -- The Mighty Quest For Epic Loot - Defender Pack
addappid(275553) -- The Mighty Quest For Epic Loot - Combo Pack
addappid(275554) -- The Mighty Quest For Epic Loot - Ultimate Pack
addappid(293120) -- The Mighty Quest for Epic Loot - Best Frenemies
addappid(293130) -- The Mighty Quest for Epic Loot - Ranged Rovers
addappid(293131) -- The Mighty Quest for Epic Loot - Sword and Sorcery
addappid(293132) -- The Mighty Quest for Epic Loot - Archer  Pal
addappid(293133) -- The Mighty Quest for Epic Loot - Knight  Pal
addappid(293134) -- The Mighty Quest for Epic Loot - Mage  Pal
addappid(305530) -- Underpants for The Mighty Quest for Epic Loot
addappid(305531) -- Amulet - Gabes Pendant for The Mighty Quest for Epic Loot
addappid(305532) -- Pet - Nigel for The Mighty Quest for Epic Loot
addappid(309970) -- Attacker Pack
addappid(309971) -- The Mighty Quest For Epic Loot  Defender Pack
addappid(309972) -- The Mighty Quest For Epic Loot  Trio Combo Pack
addappid(309973) -- The Mighty Quest For Epic Loot  Ultimate Pack
addappid(328810) -- The Mighty Quest For Epic Loot - Knight Pack
addappid(328811) -- The Mighty Quest For Epic Loot - Archer Pack
addappid(328812) -- The Mighty Quest For Epic Loot - Mage Pack
addappid(328813) -- The Mighty Quest For Epic Loot - Runaway Pack
addappid(328814) -- The Mighty Quest For Epic Loot - All Heroes Pack
addappid(328815) -- The Mighty Quest For Epic Loot - Bronze Defender Pack
addappid(328816) -- The Mighty Quest For Epic Loot - Silver Defender Pack
addappid(328817) -- The Mighty Quest For Epic Loot - Gold Defender Pack
addappid(328818) -- The Mighty Quest For Epic Loot - The BIG Package
addappid(330030) -- The Mighty Quest For Epic Loot - Halloween Pack
addappid(336620) -- The Mighty Quest For Epic Loot - The Material-O-Matic Pack
addappid(336650) -- The Mighty Quest For Epic Loot - The Blings Pack
addappid(342680) -- The Mighty Quest For Epic Loot - Infinite Pack