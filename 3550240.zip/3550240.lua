-- Lua provided by RyzenAPI 
-- Game: Finding Pots & Pets
addappid(3550240)
addappid(3550241, 1, "440681df67f2673e122edb42ed76da58ff476b64c56a71c76087ee8efa6bdd12")
