-- Lua provided by RyzenAPI
-- Game: Game: Finding Pots & Pets

-- MAIN APPLICATION
addappid(3550240)
-- Game: addappid(3550240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3550241, 1, "440681df67f2673e122edb42ed76da58ff476b64c56a71c76087ee8efa6bdd12")
