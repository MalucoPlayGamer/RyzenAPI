-- Lua provided by RyzenAPI
-- Game: Finding Pots & Pets

-- MAIN APPLICATION
addappid(3550240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3550241, 1, "440681df67f2673e122edb42ed76da58ff476b64c56a71c76087ee8efa6bdd12")

