-- Lua provided by RyzenAPI 
-- Game: AppID 1642860
addappid(1642860)
addappid(1642861, 1, "e4b8c939d2a19737c9ae08b62c80d4fe937dd2fa00fe03bea0a90baad5386792")
addappid(1642862, 1, "d02b7eb15491bd09e555f570b823ce9da5744de10d95ca708440f5803ca8a391")
