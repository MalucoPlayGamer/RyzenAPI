-- Lua provided by RyzenAPI
-- Game: addappid(1768310)

-- MAIN APPLICATION
addappid(1768310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768311, 1, "ec8560fce2fd804fc829aa61355110ffbba9d41f48d0f1c6df77e3599340f041")
