-- Lua provided by SkyAPI 
-- Game: Don Flatus: Poop Hunter
addappid(1314480)
addappid(1314481, 1, "50ae6a6dfadfd556acb376f2c9c7906486edf182e736e93c941bdfa120933579")
addappid(1314482, 1, "09b98df86b742b6f99bf578e03fd1ac5dbd85fd59b60ffd2167c17a5218cc698")
