-- Lua provided by SkyAPI 
-- Game: AppID 3009960
addappid(3009960)
addappid(3009961, 1, "5e615cf4a3df7678c0eed3c1b1358690c9152f179191aa1fb40e8c2e98560ba6")
