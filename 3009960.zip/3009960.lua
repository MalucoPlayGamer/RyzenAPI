-- Lua provided by RyzenAPI
-- Game: 幻想乡：有罪推定~夜明前的三色堇 Demo

-- MAIN APPLICATION
addappid(3009960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009961, 1, "5e615cf4a3df7678c0eed3c1b1358690c9152f179191aa1fb40e8c2e98560ba6")

