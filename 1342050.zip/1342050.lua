-- Lua provided by RyzenAPI
-- Game: Lisa and the Grimoire

-- MAIN APPLICATION
addappid(1342050)
-- Game: addappid(1342050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342051, 1, "2c34c8005f0c85d6b85b3332b3638e188adbbe7544481440efc785d69ca1788b")
addappid(1342052, 1, "0a22b4ff1c148d3a19ec0d144007839b21a29c67f21852b732b513743c927de8")
