-- Lua provided by RyzenAPI
-- Game: 3765650

-- MAIN APPLICATION
addappid(3765650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3765650,0,"fab2a90caceaf8c7a03d18aa4594574f12ac5c78b03c6f0124e500bf928edb94")
