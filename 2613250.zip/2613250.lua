-- Lua provided by RyzenAPI
-- Game: Game: Multiplayer Drone Simulator

-- MAIN APPLICATION
addappid(2613250)
-- Game: addappid(2613250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613251, 1, "9e85e657de85b6277418e07b36e50a0a2e445ec174bc2fbf4269404bf0a309cb")
