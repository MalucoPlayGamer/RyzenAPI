-- Lua provided by RyzenAPI
-- Game: Game: Yomi

-- MAIN APPLICATION
addappid(287960)
addappid(383050)
-- Game: addappid(287960)

-- MAIN APP DEPOTS / PACKAGES
addappid(287961, 1, "5c6e473cd07138a445a16b7f477215286c9dcef4fc7ca0bd0c7054a0d099bc46")
