-- Lua provided by RyzenAPI
-- Game: Carto Demo

-- MAIN APPLICATION
addappid(1431200)
-- Game: addappid(1431200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431201, 1, "d62de450fdc46d1f7937bcda550411de8d78ee40318a53b34958c763cca18411")
addappid(1431203, 1, "f102909f52ce81b21a02bd0c5d00b791da3a4e90b099c44530c0b87ff95d53b3")
