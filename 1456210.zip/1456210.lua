-- Lua provided by RyzenAPI
-- Game: MechWarrior 5: Mercenaries - Digital Extras Content

-- MAIN APPLICATION
addappid(1456210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456212,0,"598bc56440d949389c13e439f65033a3cf2b40355f83b9158b60d8fd0bb14e85")

