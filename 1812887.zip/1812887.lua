-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1812887)
-- Game: addappid(1812887)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812887,0,"e5ec952b042417731b9e34ec1fe1ae73e3603b2f751875757f596af6d85a3b2a")
