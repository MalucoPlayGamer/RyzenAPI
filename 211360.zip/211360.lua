-- Lua provided by RyzenAPI
-- Game: Offspring Fling!

-- MAIN APPLICATION
addappid(211360)

-- MAIN APP DEPOTS / PACKAGES
addappid(211361, 1, "f746b4a5a1c6cc0e8713a911319ecee1cb12826f62c2fd360b432be5430718d7")
addappid(211364, 1, "afc1a1dab9d47dd9d220ab5462676950a5f4d74f6044d216a8006dfb2db58646")
