-- Lua provided by RyzenAPI
-- Game: Under Iron Water

-- MAIN APPLICATION
addappid(1857040)
-- Game: addappid(1857040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857041, 1, "efd0196549f422860ab9eafbc6842bdf7bb0a67f8d07fb18c6336442d441521f")
