-- Lua provided by RyzenAPI 
-- Game: Under Iron Water
addappid(1857040)
addappid(1857041, 1, "efd0196549f422860ab9eafbc6842bdf7bb0a67f8d07fb18c6336442d441521f")
