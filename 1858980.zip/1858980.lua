-- Lua provided by RyzenAPI
-- Game: Gravity Game

-- MAIN APPLICATION
addappid(1858980)
-- Game: addappid(1858980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858981, 1, "acaf834d3d59a9d964bb9436e7cedcae52bf56f2f425f6fc8eca164744b5ea52")
