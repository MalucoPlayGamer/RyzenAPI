-- Lua provided by RyzenAPI
-- Game: Gravity Game

-- MAIN APPLICATION
addappid(1858980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858981, 1, "acaf834d3d59a9d964bb9436e7cedcae52bf56f2f425f6fc8eca164744b5ea52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
