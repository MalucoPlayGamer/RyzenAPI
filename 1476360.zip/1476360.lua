-- Lua provided by RyzenAPI 
-- Game: Hang up Street
addappid(1476360)
addappid(1476361, 1, "fd00f5c63622d0db5c0abaa26568650b701b81bfe759af9dd3c4eddd779e99f3")
