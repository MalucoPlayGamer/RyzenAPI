-- Lua provided by RyzenAPI 
-- Game: Redemption of Liuyin
addappid(3306400)
addappid(3306401, 1, "e16ab6f68f421d0e9a1d6d99dd126873879b1be5c09ed9f7b9152fedcee2a768")
