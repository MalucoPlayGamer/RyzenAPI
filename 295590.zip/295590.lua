-- Lua provided by RyzenAPI
-- Game: Hero Generations

-- MAIN APPLICATION
addappid(295590)
addappid(362100)

-- MAIN APP DEPOTS / PACKAGES
addappid(295591, 1, "1a3b49a574da6d9a76b691ec66f49bc76b5627997e01d2be34807b00791ef31a")
addappid(295592, 1, "9d2d3d0476beb10662350fe4691b4af862582f97a4b2503b5bf24948b93183b6")

