-- Lua provided by RyzenAPI
-- Game: SCP Fatal Flee

-- MAIN APPLICATION
addappid(3122300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122301, 1, "c5fd8e7ec2edf1a0d1460253e893132dbb5c3e2e0011d519b690f794a74cae3b")

