-- Lua provided by RyzenAPI
-- Game: XFlight: FPV Drone Simulator

-- MAIN APPLICATION
addappid(3628070)
-- Game: addappid(3628070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3628071, 1, "041b13fa538062eb12585b97aa2d91f4844d74600421f236792d5dd8f0d340cf")
