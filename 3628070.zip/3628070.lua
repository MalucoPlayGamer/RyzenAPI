-- Lua provided by RyzenAPI
-- Game: XFlight: FPV Drone Simulator

-- MAIN APPLICATION
addappid(3628070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3628071, 1, "041b13fa538062eb12585b97aa2d91f4844d74600421f236792d5dd8f0d340cf")

