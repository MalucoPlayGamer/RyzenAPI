-- Lua provided by RyzenAPI
-- Game: Antadin DX

-- MAIN APPLICATION
addappid(1390000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390001, 1, "68226bb6ba471e55a5d42691122dafedc8783c80c372cf2eaa50fdb828ac67b5")

