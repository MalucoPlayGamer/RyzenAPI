-- Lua provided by RyzenAPI
-- Game: Game: AppID 80310

-- MAIN APPLICATION
addappid(80310)
-- Game: addappid(80310)

-- MAIN APP DEPOTS / PACKAGES
addappid(80311, 1, "4a81d67d9a92e78d13638d071c5e73e2389bcf9257b7d8a0ed3a19b0fc77c16d")
addappid(80312, 1, "aac7cebd9311b622ad3d3012e01a0573a1e1a4351eb33df2f476909823885832")
addappid(80313, 1, "496a2af8e9be0f1a754bb9c6b9fcf6907190c5d7663028735b28883a4c0587aa")
addappid(80314, 1, "2c6f74e58aef34bf69ee522053de2b9d0e11c06cff84b93fbe5e3e56c3f5c042")
