-- Lua provided by RyzenAPI
-- Game: 1209060

-- MAIN APPLICATION
addappid(1209060)
-- Game: addappid(1209060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209061, 1, "b8015f920519111fc76721d748fdb44c697ad16ac54d3057d9d412a983feae09")
