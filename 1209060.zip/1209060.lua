-- Lua provided by SkyAPI 
-- Game: AppID 1209060
addappid(1209060)
addappid(1209061, 1, "b8015f920519111fc76721d748fdb44c697ad16ac54d3057d9d412a983feae09")
