-- Lua provided by RyzenAPI
-- Game: addappid(1771380)

-- MAIN APPLICATION
addappid(1771380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771381, 1, "1075560619cad6bdb58f334637438af7b0f99ea0654f063e51bc6fe80eaf4d4f")
