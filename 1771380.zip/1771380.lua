-- Lua provided by RyzenAPI
-- Game: The Hidden Room

-- MAIN APPLICATION
addappid(1771380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771381, 1, "1075560619cad6bdb58f334637438af7b0f99ea0654f063e51bc6fe80eaf4d4f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1794570)
addappid(1912780)
