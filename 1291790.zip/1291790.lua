-- Lua provided by RyzenAPI 
-- Game: Lakeview Cabin 2
addappid(1291790)
addappid(1291791, 1, "4d35429fc9ab744ae7610fd837a2da0a38db47227300166f4662b395b8235145")
addappid(1291792, 1, "774c577559d5a511fcb4c93720456f00071f8df87ede02dd8a5d4d9755087545")
