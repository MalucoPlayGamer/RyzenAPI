-- Lua provided by RyzenAPI
-- Game: 1725502

-- MAIN APPLICATION
addappid(1725502)
-- Game: addappid(1725502)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725502,0,"e9bd8b71b6d53c9cc26559d6c15d980c15db26112798bd097eabd1a4fcd7b21e")
