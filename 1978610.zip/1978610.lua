-- Lua provided by RyzenAPI
-- Game: Game: AppID 1978610

-- MAIN APPLICATION
addappid(1978610)
-- Game: addappid(1978610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978611, 1, "542261f684c15db40d5ad2786053b17297fa5f827bfb67a5a8cdc8063cebeb26")
