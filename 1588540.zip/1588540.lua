-- Lua provided by RyzenAPI
-- Game: 1588540

-- MAIN APPLICATION
addappid(1588540)
-- Game: addappid(1588540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588541, 1, "e86ec832dd18cdeef69b912a57d46b204a18d06b011f52b0480a10e235764fc0")
