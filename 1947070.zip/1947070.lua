-- Lua provided by RyzenAPI
-- Game: Broken Edge

-- MAIN APPLICATION
addappid(1947070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947071, 1, "13f2d30285532ba2d6915154b9985dba46aee333ab227e30845ea035f19b737f")

