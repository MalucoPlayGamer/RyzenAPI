-- Lua provided by RyzenAPI
-- Game: CS Manager

-- MAIN APP DEPOTS / PACKAGES
addappid(3418500, 1, "069f14875b926ebf3d9ee09a74bcad534762c6789ab54705af609c991490a5b9") -- CS Manager
addappid(3418501, 1, "df2fe40942f40cba6dc3b4903b569a308c15be35318f6bfb482fc19f86ddfca3") -- Depot 3418501

