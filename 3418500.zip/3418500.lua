-- 3418500's Lua and Manifest Created by Hubcap Manifest
-- CS Manager
-- Created: August 06, 2026 at 18:13:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3418500, 1, "069f14875b926ebf3d9ee09a74bcad534762c6789ab54705af609c991490a5b9") -- CS Manager
-- MAIN APP DEPOTS
addappid(3418501, 1, "df2fe40942f40cba6dc3b4903b569a308c15be35318f6bfb482fc19f86ddfca3") -- Depot 3418501
setManifestid(3418501, "161970017421038391", 541814632)