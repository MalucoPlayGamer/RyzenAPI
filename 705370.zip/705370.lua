-- Lua provided by RyzenAPI
-- Game: Game: The Cursed Tower

-- MAIN APPLICATION
addappid(705370)
-- Game: addappid(705370)

-- MAIN APP DEPOTS / PACKAGES
addappid(705371, 1, "c22495e8db26fdae419238977228cb6bc6a77f29f4f81c2592818f88a4b60706")
addappid(705372, 1, "5c1ceccb723aad84229b51fc382427189a4e80933eeaa5958aa089f8fa76fd13")
addappid(705373, 1, "6daf669d1a133c51f1546d7839697850394beb26dc262740c3232f7d5238ebd1")
