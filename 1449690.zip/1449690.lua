-- Lua provided by RyzenAPI
-- Game: The Walking Dead: The Telltale Definitive Series

-- MAIN APPLICATION
addappid(1449690)
-- Game: addappid(1449690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449691, 1, "ebfb9f62016b22f81e1323ccfc885d47a554513a3aec0310ea08e4043e4a84a7")
