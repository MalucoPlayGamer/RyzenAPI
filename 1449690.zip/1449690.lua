-- Lua provided by RyzenAPI
-- Game: The Walking Dead: The Telltale Definitive Series

-- MAIN APPLICATION
addappid(1449690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449691, 1, "ebfb9f62016b22f81e1323ccfc885d47a554513a3aec0310ea08e4043e4a84a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
