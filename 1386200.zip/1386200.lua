-- Lua provided by RyzenAPI
-- Game: 1386200

-- MAIN APPLICATION
addappid(1386200)
-- Game: addappid(1386200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386201, 1, "7a12b7bd57d0887f826269ac0ae5fec429c3607da86e017f3736cf361e4b31f0")
