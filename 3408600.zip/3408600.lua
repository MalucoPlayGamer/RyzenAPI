-- Lua provided by RyzenAPI
-- Game: A Song in Elyel Nalore

-- MAIN APPLICATION
addappid(3408600)
-- Game: addappid(3408600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408601, 1, "63803c8e8b89f2347ef6b0aed6123b98e7b7f8bbb4519f08541ea12026ba6414")
addappid(3408605, 1, "b89a035ece8cf733264a09e243e1e132b4d9947565c52d43838ff630901d44bf")
