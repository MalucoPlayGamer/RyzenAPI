-- Lua provided by RyzenAPI
-- Game: addappid(3290290)

-- MAIN APPLICATION
addappid(3290290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290291, 1, "97798503a1daf17c2050a744d9d1ccbe9b520c9fc24ea37dffde0652924b4538")
