-- Lua provided by RyzenAPI
-- Game: 3170180

-- MAIN APPLICATION
addappid(3170180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170180,0,"7dffeacfc74b0c497258f32ab79a23d26e824b2f645ffbdc3baed3cbfaea08eb")

