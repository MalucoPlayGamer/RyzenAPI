-- Lua provided by RyzenAPI
-- Game: addappid(438010)

-- MAIN APPLICATION
addappid(438010)

-- MAIN APP DEPOTS / PACKAGES
addappid(438011, 1, "2f04c935796f841c3a905be0670ff217a046bde66690d78ed6ad065d88bd5f1e")
