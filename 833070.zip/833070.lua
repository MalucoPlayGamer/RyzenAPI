-- Lua provided by RyzenAPI
-- Game: Arrowborn

-- MAIN APPLICATION
addappid(833070)

-- MAIN APP DEPOTS / PACKAGES
addappid(833071,0,"4312a830c035b2cfcd5fc57ac74287dfc787d445eb97cb4d499cfa190f33f234")

