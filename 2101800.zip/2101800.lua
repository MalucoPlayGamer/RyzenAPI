-- Lua provided by RyzenAPI
-- Game: 2101800

-- MAIN APPLICATION
addappid(2101800)
-- Game: addappid(2101800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101801, 1, "a09eaf64c929c380a45f89e74f9be61fc6eb05f2b37b0858c614712be71a3c61")
