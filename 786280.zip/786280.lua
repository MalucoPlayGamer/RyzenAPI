-- Lua provided by RyzenAPI
-- Game: Game: AppID 786280

-- MAIN APPLICATION
addappid(786280)
-- Game: addappid(786280)

-- MAIN APP DEPOTS / PACKAGES
addappid(786281, 1, "df21f7ba250fcfe7960e40992492a47d179496744b6c105416281fac3221484d")
