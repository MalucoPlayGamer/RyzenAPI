-- Lua provided by RyzenAPI
-- Game: Armored Squad

-- MAIN APPLICATION
addappid(786280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(786281, 1, "df21f7ba250fcfe7960e40992492a47d179496744b6c105416281fac3221484d")

