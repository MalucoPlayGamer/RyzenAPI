-- Lua provided by RyzenAPI
-- Game: AppID 368150

-- MAIN APPLICATION
addappid(368150)

-- MAIN APP DEPOTS / PACKAGES
addappid(368151, 1, "e53418d1b4291ab8d0dce5507cd1ee1b37437e94fdc796c885d33a490fc2cc97")
