-- Lua provided by RyzenAPI
-- Game: Game: Out of Sight

-- MAIN APPLICATION
addappid(1622570)
-- Game: addappid(1622570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622571, 1, "b8a4be94484ae63b108ea84470eb4af1d79be7a179064256310c148b27f2172e")
