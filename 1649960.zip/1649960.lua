-- Lua provided by RyzenAPI
-- Game: Game: Erotic Jigsaw Puzzle 2

-- MAIN APPLICATION
addappid(1649960)
-- Game: addappid(1649960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649961, 1, "582921f7c23c70c28656c135f62b7bdc298a7274e4ffbbaf4c007d86a9bd6763")
addappid(1650630, 0, "61b3e283071dcb16bf5b1597bce42c82061afde10ae972dacaa5a8dc3f61356c")
