-- Lua provided by RyzenAPI
-- Game: My Secretary Bird

-- MAIN APPLICATION
addappid(3742910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742911, 1, "bad05fc29b771bc1bb3454e597a176ae4a45ef573053c9276d41c966a2c100bc")
