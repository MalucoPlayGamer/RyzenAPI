-- Lua provided by SkyAPI 
-- Game: Automaton Kingdom
addappid(1969280)
addappid(1969281, 1, "cb61cb814deab1aba03f87b95d7a7b0e3df5e219ae998b2e84073a48c023f6ee")
