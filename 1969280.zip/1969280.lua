-- Lua provided by RyzenAPI
-- Game: 1969280

-- MAIN APPLICATION
addappid(1969280)
-- Game: addappid(1969280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969281, 1, "cb61cb814deab1aba03f87b95d7a7b0e3df5e219ae998b2e84073a48c023f6ee")
