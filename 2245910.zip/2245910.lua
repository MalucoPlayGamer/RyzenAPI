-- Lua provided by RyzenAPI
-- Game: Game: AppID 2245910

-- MAIN APPLICATION
addappid(2245910)
-- Game: addappid(2245910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245911, 1, "74053994460cfc73e0fe72a31678247422e06d91081eaf020c11feb01d41c2c2")
