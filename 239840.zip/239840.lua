-- Lua provided by RyzenAPI
-- Game: Dead State: Reanimated

-- MAIN APPLICATION
addappid(239840)
addappid(336810)

-- MAIN APP DEPOTS / PACKAGES
addappid(239841, 1, "8f35e7be7afebeed624f883e84c6b405e6844688f3c30e9a9b5f92d3e2c52bd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
