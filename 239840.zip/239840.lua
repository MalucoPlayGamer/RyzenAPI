-- Lua provided by RyzenAPI
-- Game: Dead State: Reanimated

-- MAIN APPLICATION
addappid(239840)
addappid(336810)
-- Game: addappid(239840)

-- MAIN APP DEPOTS / PACKAGES
addappid(239841, 1, "8f35e7be7afebeed624f883e84c6b405e6844688f3c30e9a9b5f92d3e2c52bd7")
