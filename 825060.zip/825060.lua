-- Lua provided by RyzenAPI
-- Game: Watch Over Christmas

-- MAIN APPLICATION
addappid(825060)

-- MAIN APP DEPOTS / PACKAGES
addappid(825061,0,"316b670f50cdd6db29fae4e036a1c8961ab6b6344e3222a1b892e59efd52c2df")
addappid(825062,0,"d3d7eb189a97a9ccec7d6fc0cff1e077bd3ea5d9313b95b454c437b2217f145c")
addappid(825063,0,"9e8f4551cc44e4682e19d3f249fa6f794ec054b917048eb0c04ca2700e409e18")

