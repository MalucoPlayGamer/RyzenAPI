-- Lua provided by RyzenAPI
-- Game: Hot And Lovely 5

-- MAIN APPLICATION
addappid(2078120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078121, 1, "1b4c58f4afaaac4b026c3e52ac79e09bf00945170a235490a817345b80b88d3a")
addappid(2078180, 0, "6eb99fc21f7d82510c1e984da1e9f85f9632cfe0c2e293de033b0391c11b2bbb")

