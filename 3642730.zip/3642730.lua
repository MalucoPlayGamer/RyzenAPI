-- Lua provided by RyzenAPI
-- Game: 3642730

-- MAIN APPLICATION
addappid(3642730)
-- Game: addappid(3642730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3642731, 1, "d80c8777f6b5d5da7abc3e6040b9ebddd3e98ee57d0c4caaa4fdfdd98e9cb565")
