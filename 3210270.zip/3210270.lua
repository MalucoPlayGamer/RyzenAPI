-- Lua provided by RyzenAPI
-- Game: Game: Streets of Rageness: Beat 'Em Up Fighter

-- MAIN APPLICATION
addappid(3210270)
-- Game: addappid(3210270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210271, 1, "40530d3533ce93ec2821629bec14e1858242bce905acf08b58b10483fba997bf")
