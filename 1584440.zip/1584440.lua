-- Lua provided by RyzenAPI
-- Game: Where is my mom

-- MAIN APPLICATION
addappid(1584440)
-- Game: addappid(1584440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584441, 1, "f35a02a11d08ad27c0ef3d224492c9bf29545fba458aa7e95ba88e13d1709c43")
