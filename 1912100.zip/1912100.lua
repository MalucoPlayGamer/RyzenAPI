-- Lua provided by RyzenAPI
-- Game: 1912100

-- MAIN APPLICATION
addappid(1912100)
-- Game: addappid(1912100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912100,0,"7a22c3917612ff0e89f379915e5a01dde57dd43adf9c37c98a69fc1cba4de145")
