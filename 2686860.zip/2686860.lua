-- Lua provided by RyzenAPI 
-- Game: AppID 2686860
addappid(2686860)
addappid(2686861, 1, "44bc0a7a0b99060cccb20de62b0dc06be2a3e179bcfec88c20c840e440ad63d9")
