-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1670522)
-- Game: addappid(1670522)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670522,0,"8efb5876b76efe3098530589da535b47cb75edbaefb68987792dbe46b23419a1")
