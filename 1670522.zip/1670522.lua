-- Lua provided by RyzenAPI
-- Game: addappid(1670522)

-- MAIN APPLICATION
addappid(1670522)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670522,0,"8efb5876b76efe3098530589da535b47cb75edbaefb68987792dbe46b23419a1")
