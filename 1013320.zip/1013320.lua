-- 1013320's Lua and Manifest Created by Hubcap Manifest
-- Firestone – Idle Clicker Online RPG
-- Created: August 15, 2026 at 21:33:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 27

-- MAIN APPLICATION
addappid(1013320, 1, "71bc9d7fe8577624b7229c7151473a50a1ec962580d49070110947443fb006f5") -- Firestone – Idle Clicker Online RPG
-- MAIN APP DEPOTS
addappid(1013321, 1, "0a621dbd84fd5b306d4204fc37792279458334be9d285516ed9b56ecd410e27f") -- Firestone Content
setManifestid(1013321, "3114142359948631861", 794868485)
addappid(1013323, 1, "02daa57bb9ec6e6b36b16bbb3466274305e680039d82726cce72d91d365d5dba") -- Firestone Idle RPG Mac Depot
setManifestid(1013323, "2023525297534129969", 879009141)
addappid(1013324, 1, "6d3f00ac94ac3dc1a3bd307fa10ff159c791cbd1eb22e7f9e61d2ac19901e0fa") -- Firestone Idle RPG Linux Depot
setManifestid(1013324, "4414260719469046150", 847616520)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1265710) -- Firestone Idle RPG - Goblin The Little Monster
addappid(1266710) -- Firestone Idle RPG - Orc Thief, The gold Hunter  - Avatar
addappid(1266711) -- Firestone Idle RPG - Assassin, The silent danger  - Avatar
addappid(1266712) -- Firestone Idle RPG - Troll Archer, The Legionnaire of Mayhem  - Avatar
addappid(1266713) -- Firestone Idle RPG - Bandit, The Ex Crusader  - Avatar
addappid(1266714) -- Firestone Idle RPG - Troll Warrior, The Blade of Terror  - Avatar
addappid(1266715) -- Firestone Idle RPG - Mercenary, The Soldier of Destiny  - Avatar
addappid(1266716) -- Firestone Idle RPG - Orc Warrior, The Champion of Thal Badur  - Avatar
addappid(1266717) -- Firestone Idle RPG - Skeleton Warrior, The exile of the world  - Avatar
addappid(1266718) -- Firestone Idle RPG - Undead Warrior, The Hero of the Underworld  - Avatar
addappid(1266719) -- Firestone Idle RPG - Skeleton Archer, The Terror of Paladins  - Avatar
addappid(1291880) -- Firestone Idle RPG - Grace, The Fairy - Avatar
addappid(1291881) -- Firestone Idle RPG - Grace, The Nymph - Avatar
addappid(1291882) -- Firestone Idle RPG - Grace, The Valkyrie - Avatar
addappid(1291883) -- Firestone Idle RPG - Grace, The Angel - Avatar
addappid(1291884) -- Firestone Idle RPG - Grace, The Archangel - Avatar
addappid(1291885) -- Firestone Idle RPG - Vermilion, The Young Dragon - Avatar
addappid(1291886) -- Firestone Idle RPG - Vermilion, The Topaz Dragon - Avatar
addappid(1291887) -- Firestone Idle RPG - Vermilion, The Fire Dragon - Avatar
addappid(1291888) -- Firestone Idle RPG - Vermilion, The Ruby Dragon - Avatar
addappid(1291889) -- Firestone Idle RPG - Vermilion, The Ancient Battle Dragon - Avatar
addappid(1376970) -- Firestone Idle RPG - Golem, The Elemental of the Deep
addappid(1376971) -- Firestone Idle RPG - Treant, The Wrath of Nature
addappid(1376972) -- Firestone Idle RPG - Minotaur, The Undefeated Brawler
addappid(1376973) -- Firestone Idle RPG - Wrym, The Horror of the Sea
addappid(1376974) -- Firestone Idle RPG - Skeleton Warlock, The Evil Spellcaster
addappid(3063880) -- Banana