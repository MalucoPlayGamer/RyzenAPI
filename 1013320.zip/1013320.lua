-- Lua provided by RyzenAPI
-- Game: 1013320

-- MAIN APPLICATION
addappid(1013320)
addappid(3063880)
-- Game: addappid(1013320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013321, 1, "0a621dbd84fd5b306d4204fc37792279458334be9d285516ed9b56ecd410e27f")
addappid(1013323, 1, "02daa57bb9ec6e6b36b16bbb3466274305e680039d82726cce72d91d365d5dba")
addappid(1013324, 1, "6d3f00ac94ac3dc1a3bd307fa10ff159c791cbd1eb22e7f9e61d2ac19901e0fa")
