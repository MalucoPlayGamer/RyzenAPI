-- Lua provided by RyzenAPI
-- Game: QUIT TODAY

-- MAIN APPLICATION
addappid(1858450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1858451, 1, "b9d87c9d018876ed8924b7162ca32e67bcb43dbeb080637311f3e79c27fa3e0f")

