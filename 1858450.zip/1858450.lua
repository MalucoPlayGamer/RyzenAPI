-- Lua provided by RyzenAPI
-- Game: 1858450

-- MAIN APPLICATION
addappid(1858450)
-- Game: addappid(1858450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858451, 1, "b9d87c9d018876ed8924b7162ca32e67bcb43dbeb080637311f3e79c27fa3e0f")
