-- Lua provided by RyzenAPI 
-- Game: QUIT TODAY
addappid(1858450)
addappid(1858451, 1, "b9d87c9d018876ed8924b7162ca32e67bcb43dbeb080637311f3e79c27fa3e0f")
