-- Lua provided by RyzenAPI
-- Game: addappid(2102520)

-- MAIN APPLICATION
addappid(2102520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102521, 1, "01608c961b88d8bf7b87e76c74e85a2bb9a9b9a33b5373b4f92049da6de55c78")
