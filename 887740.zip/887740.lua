-- Lua provided by RyzenAPI
-- Game: 老虎游戏-casino

-- MAIN APPLICATION
addappid(887740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(887741, 1, "69fe54a9d6a3cfb2a922dec336579a47b3c7f065bb73ea1b39cbd2807f7a048d")

