-- Lua provided by RyzenAPI
-- Game: 887740

-- MAIN APPLICATION
addappid(887740)
-- Game: addappid(887740)

-- MAIN APP DEPOTS / PACKAGES
addappid(887741, 1, "69fe54a9d6a3cfb2a922dec336579a47b3c7f065bb73ea1b39cbd2807f7a048d")
