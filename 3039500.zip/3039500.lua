-- Lua provided by RyzenAPI
-- Game: 万象群侠传

-- MAIN APPLICATION
addappid(3039500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039501, 1, "52933c4abfccfaa0be28a1ff000ed5e5d54d002ce5c79bfa852b1195e226d4bd")

