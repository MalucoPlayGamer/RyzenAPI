-- Lua provided by RyzenAPI
-- Game: Game: Café Stella and the Reaper's Butterflies

-- MAIN APPLICATION
addappid(1829980)
-- Game: addappid(1829980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829981, 1, "bb26c855c621e80e9adfa9262b4e8c01d781f9710a03756159fd699a0e64c264")
