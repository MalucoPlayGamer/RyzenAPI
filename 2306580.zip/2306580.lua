-- Lua provided by RyzenAPI
-- Game: The Moonflower (Alpha)

-- MAIN APPLICATION
addappid(2306580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306581, 1, "11e1fbd5ba9fd3952e7d22987c679ef01e4ecd1db93b10dc76e4ff3ac983287b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
