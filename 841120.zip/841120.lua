-- Lua provided by RyzenAPI
-- Game: Game: Wheelchair Simulator VR

-- MAIN APPLICATION
addappid(841120)
-- Game: addappid(841120)

-- MAIN APP DEPOTS / PACKAGES
addappid(841121, 1, "1290b80ef83c7be21324c0dee6c8626cfcd0be43e03578ba7eff6648979ed391")
