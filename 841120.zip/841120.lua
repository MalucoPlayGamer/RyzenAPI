-- Lua provided by RyzenAPI
-- Game: Wheelchair Simulator VR

-- MAIN APPLICATION
addappid(841120)

-- MAIN APP DEPOTS / PACKAGES
addappid(841121, 1, "1290b80ef83c7be21324c0dee6c8626cfcd0be43e03578ba7eff6648979ed391")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
