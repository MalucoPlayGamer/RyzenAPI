-- Lua provided by RyzenAPI
-- Game: 828240

-- MAIN APPLICATION
addappid(828240)
-- Game: addappid(828240)

-- MAIN APP DEPOTS / PACKAGES
addappid(828241, 1, "468ae4bdc72644a3753c7204392d4ec72860eb07e7a56fedd1ae739b90d613d2")
