-- Lua provided by RyzenAPI
-- Game: Game: AppID 783470

-- MAIN APPLICATION
addappid(783470)
-- Game: addappid(783470)

-- MAIN APP DEPOTS / PACKAGES
addappid(783471, 1, "d32bfc370ee794cdda87c94056f8750a32b066a662d94ed6f0972188b1c5a3a8")
