-- Lua provided by RyzenAPI
-- Game: addappid(992610)

-- MAIN APPLICATION
addappid(992610)

-- MAIN APP DEPOTS / PACKAGES
addappid(992611, 1, "7a7e03eec3d59f992cf898fa4610710e8248fde6f11f45386c31aaf532138672")
