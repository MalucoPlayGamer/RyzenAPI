-- Lua provided by RyzenAPI
-- Game: Altiros Playtest

-- MAIN APPLICATION
addappid(1419270)
-- Game: addappid(1419270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419271, 1, "9cd28e764fb20c4e6dd4ec676841618a6a33730739f03142b025f10c39ea38a5")
