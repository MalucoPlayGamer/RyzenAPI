-- Lua provided by RyzenAPI
-- Game: Abyss School

-- MAIN APPLICATION
addappid(2473710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2473711, 1, "6fd98a3d18e40a628a3f7fa0419499d35cb31f86e6d45d1e881b91659184024d")

