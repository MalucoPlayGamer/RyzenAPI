-- Lua provided by SkyAPI 
-- Game: Abyss School
addappid(2473710)
addappid(2473711, 1, "6fd98a3d18e40a628a3f7fa0419499d35cb31f86e6d45d1e881b91659184024d")
