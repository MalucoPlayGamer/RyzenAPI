-- Lua provided by SkyAPI 
-- Game: AimGoGoGo
addappid(1705020)
addappid(1705021, 1, "2be434458d9b328b7cf317083f8dd8ac2520f29493f63b00f81e2577374f11c0")
