-- Lua provided by RyzenAPI
-- Game: AimGoGoGo

-- MAIN APPLICATION
addappid(1705020)
-- Game: addappid(1705020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705021, 1, "2be434458d9b328b7cf317083f8dd8ac2520f29493f63b00f81e2577374f11c0")
