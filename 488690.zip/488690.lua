-- Lua provided by RyzenAPI
-- Game: MX Nitro: Unleashed

-- MAIN APPLICATION
addappid(488690)

-- MAIN APP DEPOTS / PACKAGES
addappid(488691, 1, "edc4a94fe712d4abf661da5e467402048f31c44163c167a738ef761d38b5baf2")
addappid(557450, 0, "f82301ab5892b4115149a0a5466478e2a2c704b88e2683dc3b8200f4c3f40636")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
