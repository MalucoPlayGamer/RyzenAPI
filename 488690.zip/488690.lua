-- Lua provided by SkyAPI 
-- Game: MX Nitro: Unleashed
addappid(488690)
addappid(488691, 1, "edc4a94fe712d4abf661da5e467402048f31c44163c167a738ef761d38b5baf2")
addappid(557450, 0, "f82301ab5892b4115149a0a5466478e2a2c704b88e2683dc3b8200f4c3f40636")
