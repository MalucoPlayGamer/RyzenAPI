-- Lua provided by RyzenAPI
-- Game: Invincible Fins

-- MAIN APPLICATION
addappid(1481880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481881, 1, "ca26e12467c2e11f4fc818e8b5f4bba4771de2e58f563cf190c33044bf327699")
