-- Lua provided by RyzenAPI 
-- Game: Astronimo
addappid(1808640)
addappid(1808641, 1, "5c31b36f3f5130f872b6167ccb21cce9fa5aed12c3687c88ba786899fe80a35a")
