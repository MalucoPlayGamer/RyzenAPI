-- Lua provided by RyzenAPI
-- Game: Game: Old School RPG

-- MAIN APPLICATION
addappid(2416790)
-- Game: addappid(2416790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416791, 1, "1df1a581e06765b3b23f05d185f0e22a8bfcb150bd5e4f53f0726ba35b7866b9")
