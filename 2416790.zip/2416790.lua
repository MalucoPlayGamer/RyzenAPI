-- Lua provided by RyzenAPI
-- Game: Old School RPG

-- MAIN APPLICATION
addappid(2416790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2416791, 1, "1df1a581e06765b3b23f05d185f0e22a8bfcb150bd5e4f53f0726ba35b7866b9")

