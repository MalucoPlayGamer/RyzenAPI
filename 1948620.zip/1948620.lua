-- Lua provided by RyzenAPI
-- Game: Albert Innovation

-- MAIN APPLICATION
addappid(1948620)
-- Game: addappid(1948620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948621, 1, "6883d7e9e0065d0922525ddfc55211ca13d0e4ea6da6192038ef4c38a9f237a5")
