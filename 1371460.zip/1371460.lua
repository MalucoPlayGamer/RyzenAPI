-- Lua provided by RyzenAPI
-- Game: Game: Alien Cat 7

-- MAIN APPLICATION
addappid(1371460)
-- Game: addappid(1371460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371461, 1, "4a64777a7a0694938566759009d8c134da159d258382f6ee1fd41371e3f50377")
