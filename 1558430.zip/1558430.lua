-- Lua provided by RyzenAPI
-- Game: SgyuinBaldo

-- MAIN APPLICATION
addappid(1558430)
-- Game: addappid(1558430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558431, 1, "134ac83237de09ea5a40dc39f930a93f0d53874bc85a83565a2a2ec001e5697f")
