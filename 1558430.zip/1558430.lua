-- Lua provided by RyzenAPI
-- Game: SgyuinBaldo

-- MAIN APPLICATION
addappid(1558430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558431, 1, "134ac83237de09ea5a40dc39f930a93f0d53874bc85a83565a2a2ec001e5697f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
