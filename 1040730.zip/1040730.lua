-- Lua provided by RyzenAPI
-- Game: ZUSI 3 - Aerosoft Edition

-- MAIN APPLICATION
addappid(1040730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1040731, 1, "c5b3b28e4505b43631d0f7d2f350534de914ecf27c9b27517622c56b767dc1d1")

