-- Lua provided by RyzenAPI
-- Game: Game: ZUSI 3 - Aerosoft Edition

-- MAIN APPLICATION
addappid(1040730)
-- Game: addappid(1040730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040731, 1, "c5b3b28e4505b43631d0f7d2f350534de914ecf27c9b27517622c56b767dc1d1")
