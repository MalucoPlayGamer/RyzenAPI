-- Lua provided by RyzenAPI
-- Game: Game: AppID 1114220

-- MAIN APPLICATION
addappid(1114220)
-- Game: addappid(1114220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114221, 1, "23b3bfba02672961ab0943997b88291097953e6006eed793d3452dbe3c212db9")
