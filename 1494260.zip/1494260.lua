-- Lua provided by RyzenAPI
-- Game: 1494260

-- MAIN APPLICATION
addappid(1494260)
-- Game: addappid(1494260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494261, 1, "3aa06dda7c6fb418616bf9f3af59227ebd1d485e96cf08e3812d25f05ec9a700")
