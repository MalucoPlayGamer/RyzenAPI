-- Lua provided by RyzenAPI
-- Game: 370910

-- MAIN APPLICATION
addappid(370910)
-- Game: addappid(370910)

-- MAIN APP DEPOTS / PACKAGES
addappid(370911, 1, "ca8eb31a5f6085f2f8fe45aeae74ff212a127902b0c2937a1426a4724da20a31")
addappid(370912, 1, "e89b4d3f740be08474cc54a0754cd6b8cb92d094b2bb0d2664cd2cc9b6df552a")
