-- Lua provided by RyzenAPI
-- Game: AppID 370910

-- MAIN APPLICATION
addappid(370910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(370911, 1, "ca8eb31a5f6085f2f8fe45aeae74ff212a127902b0c2937a1426a4724da20a31")
addappid(370912, 1, "e89b4d3f740be08474cc54a0754cd6b8cb92d094b2bb0d2664cd2cc9b6df552a")

