-- Lua provided by RyzenAPI
-- Game: Game: AppID 2123140

-- MAIN APPLICATION
addappid(2123140)
-- Game: addappid(2123140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123141, 1, "a2717f3840964d320040d36926026fe50b03961a77779fdc24dcec76eb0c60ed")
addappid(2123142, 1, "c12dc05faf5ee529834d157d92ec0cbb9ffe55f6eed8c5cfca4309eb55e0215f")
addappid(2123143, 1, "747dadd8a6d6df0ab801a6299acf26f25b596423b75b0626a85ee066fd2e4277")
