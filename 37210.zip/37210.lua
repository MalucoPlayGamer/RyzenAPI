-- Lua provided by RyzenAPI
-- Game: Chocolatier: Decadence by Design

-- MAIN APPLICATION
addappid(37210)

-- MAIN APP DEPOTS / PACKAGES
addappid(37211, 1, "8695d38187281c2ec5f25a67d65ba0e0aba58c9b78e29ecaf82958e9430dc3a0")
