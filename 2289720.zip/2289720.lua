-- Lua provided by RyzenAPI
-- Game: Kaiju Princess 2

-- MAIN APPLICATION
addappid(2289720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289721, 1, "9fc3429c350b7acd178867e645e958b1fafa2cf615acb4bdae830eaac032bdd0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3350770)
