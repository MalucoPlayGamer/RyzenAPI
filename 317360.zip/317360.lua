-- Lua provided by RyzenAPI
-- Game: Double Action: Boogaloo

-- MAIN APPLICATION
addappid(317360)

-- MAIN APP DEPOTS / PACKAGES
addappid(317361, 1, "824a0e57ff1baa07bc84d373a6dd2dbad18913f9b5a64efebd6e3a749e9d012c")
addappid(317362, 1, "5642483593c3893f7724be1129200441384b04302c1dcc914bdfcce3e925f4cf")
addappid(317363, 1, "ef96078f2f428e517747eae8eefb4b0c0f18bd11de0530f53dda1a8bd2cbe956")
addappid(317364, 1, "5c1c407547e5c62179ebe0a9b35a94c586b4b5c6e4bc65b8e88a99de358be2a5")
