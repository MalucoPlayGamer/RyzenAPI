-- Lua provided by RyzenAPI
-- Game: Game: Angelica Weaver: Catch Me When You Can

-- MAIN APPLICATION
addappid(218700)
-- Game: addappid(218700)

-- MAIN APP DEPOTS / PACKAGES
addappid(218701, 1, "e51d026ac2810a7ae8c7c855c7111365691262e05f2d2ac86d56a5decd00893d")
