-- Lua provided by RyzenAPI
-- Game: Game: 铭日记 重书 / Mikoto Remake

-- MAIN APPLICATION
addappid(2191620)
-- Game: addappid(2191620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191621, 1, "6b422e1f8b4c0bf8f65e0f08d56140707823da1f68a48b0e28f19eeb9c380d6c")
