-- Lua provided by RyzenAPI
-- Game: addappid(2698980)

-- MAIN APPLICATION
addappid(2698980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698981, 1, "be62c9bcc33b305b995406999ac7360dca9cf2a9f602a4cdb2440da54841bc35")
