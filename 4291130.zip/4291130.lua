-- Lua provided by RyzenAPI
-- Game: Professional Chef

-- MAIN APPLICATION
addappid(4291130)

