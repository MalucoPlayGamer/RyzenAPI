-- Lua provided by RyzenAPI
-- Game: Professional Chef

-- MAIN APPLICATION
addappid(4291130)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4639850)
