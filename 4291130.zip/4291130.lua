-- Lua provided by RyzenAPI
-- Game: Professional Chef

-- MAIN APPLICATION
addappid(4291130)
addappid(4639850)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5181870)
