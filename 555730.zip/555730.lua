-- Lua provided by RyzenAPI
-- Game: Robot City Stadium

-- MAIN APPLICATION
addappid(555730)

-- MAIN APP DEPOTS / PACKAGES
addappid(555731,0,"1c49993fb16e52337a6460e2f930c9bfc00e00ae85c9d46a8b64ce41ccb5212e")

