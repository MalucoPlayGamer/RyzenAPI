-- Lua provided by RyzenAPI 
-- Game: Forward Brave
addappid(2702230)
addappid(2702231, 1, "b213f3a8f99361489d1c115d25bd0e6bbbe7485af24efd138a5b09b306a1c5c8")
