-- Lua provided by RyzenAPI
-- Game: My Sexy Neighbor 🔞 Prologue

-- MAIN APPLICATION
addappid(3121490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3121491, 1, "e02ed86af5f47b794fa83035258c027fbd2a5b895b20ba65a451f3dbe9cd6420")

