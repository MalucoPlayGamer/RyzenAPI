-- Lua provided by SkyAPI 
-- Game: My Sexy Neighbor 🔞 Prologue
addappid(3121490)
addappid(3121491, 1, "e02ed86af5f47b794fa83035258c027fbd2a5b895b20ba65a451f3dbe9cd6420")
