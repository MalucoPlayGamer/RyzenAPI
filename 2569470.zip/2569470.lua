-- Lua provided by RyzenAPI
-- Game: Dead Humanity

-- MAIN APPLICATION
addappid(2569470)
-- Game: addappid(2569470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569471, 1, "bd11f08953aff57f389b6f5a68456f8d37fca60ef787e57bd929fcfd062b3af6")
