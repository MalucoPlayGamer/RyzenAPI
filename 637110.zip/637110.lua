-- Lua provided by RyzenAPI
-- Game: Runes of Avalon - Path of Magic

-- MAIN APPLICATION
addappid(637110)

-- MAIN APP DEPOTS / PACKAGES
addappid(637111,0,"76a7b41064ba9ffa740d030e7a6237f9dda55fffb6848ea2b84a2788f2efb60d")

