-- 4768400's Lua and Manifest Created by Hubcap Manifest
-- Idle Crown
-- Created: June 26, 2026 at 10:39:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4768400) -- Idle Crown
-- MAIN APP DEPOTS
addappid(4768401, 1, "cd89b7e1b84a0903b1f4b2829e9629e43ba8a6381d8a47d5dfe3a3a37473e2a7") -- Depot 4768401
setManifestid(4768401, "1277554849511102351", 374825094)