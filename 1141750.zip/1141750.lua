-- Lua provided by RyzenAPI
-- Game: addappid(1141750)

-- MAIN APPLICATION
addappid(1141750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141751, 1, "935e3d43363cc98bb6b0a4f2ee5b504da273b1291ca48d5666ad6b97521399fa")
