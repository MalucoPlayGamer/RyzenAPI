-- Lua provided by RyzenAPI
-- Game: Game: AppID 1405220

-- MAIN APPLICATION
addappid(1405220)
-- Game: addappid(1405220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405221, 1, "bf1ceb8d9c1e8b73899c1833c0107d2afde0dc3deebc11e612cb5092dde12549")
