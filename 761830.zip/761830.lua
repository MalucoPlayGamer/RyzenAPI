-- Lua provided by RyzenAPI
-- Game: Mr. Prepper

-- MAIN APPLICATION
addappid(1882510)
addappid(3864310)
-- addappid(761833) -- Depot 761833 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(761830, 1, "3d256bed981b359890016d5e8b84fbdfb171b7033761b2f6e0af10cffaaff578") -- Mr. Prepper
addappid(761831, 1, "46eeb5fdced56fe223ab7a3ee5efbf1cfc9f81ab82d1285f0fe38b1ccb2daf6c") -- Mr. Prepper Content
addappid(761832, 1, "77abf0e1403cf75ac402c4a621736b0a475028a83ac1b8b94dcac5b2d97d8232") -- Depot 761832
addappid(1882510, 1, "b061415c5e0c184548bc9c781ce110b44e2a63924b9c131db606edfc76d11541") -- Mr. Prepper - Animal Farm DLC - Depot 1882510
addappid(1882511, 1, "53a898d906c250911c7461f7b0679556d8a84bf26342fdd6be1db3e7a2f9555b") -- Mr. Prepper - Animal Farm DLC - Depot 1882511
addappid(3864310, 1, "6914cb8af27033362615e9e5cdf85bcfa66bda7cb4af4310e0e73b4b8435a1e3") -- Mr. Prepper - Uranium Project DLC - Depot 3864310
-- addappid(3864311, 1, "MISSING_KEY") -- Mr. Prepper - Uranium Project DLC - Depot 3864311 (no key available)

