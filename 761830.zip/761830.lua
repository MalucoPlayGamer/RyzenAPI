-- Lua provided by RyzenAPI 
-- Game: Mr. Prepper
addappid(761830)
addappid(761831, 1, "46eeb5fdced56fe223ab7a3ee5efbf1cfc9f81ab82d1285f0fe38b1ccb2daf6c")
addappid(761832, 1, "77abf0e1403cf75ac402c4a621736b0a475028a83ac1b8b94dcac5b2d97d8232")
