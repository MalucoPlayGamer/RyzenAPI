-- Lua provided by RyzenAPI
-- Game: EmbodyMe Beta

-- MAIN APPLICATION
addappid(604530)

-- MAIN APP DEPOTS / PACKAGES
addappid(604531, 1, "181e14a9a3149b0024a51616068f3f643eb725b8676d509f8608a2fd7810bbd6")
