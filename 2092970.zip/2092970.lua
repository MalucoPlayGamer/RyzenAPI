-- Lua provided by RyzenAPI
-- Game: The Book of Aaru

-- MAIN APPLICATION
addappid(2092970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092971, 1, "0a16683a86c02c4a29766d7fa3d66831622b989bf29f76722ef12ed2c41b8b12")
