-- Lua provided by RyzenAPI
-- Game: addappid(1546920)

-- MAIN APPLICATION
addappid(1546920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546921, 1, "b0aa3165b0cfd5a204a5be884fb0d360f1ba021a085c767305faeaba49acb2bd")
