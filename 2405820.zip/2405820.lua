-- Lua provided by RyzenAPI
-- Game: Paranormal Records Demo

-- MAIN APPLICATION
addappid(2405820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405821, 1, "c31e3f891c6ac999793159ae09b4defe448111a5f19ca1835c662f6c961441e0")

