-- Lua provided by RyzenAPI
-- Game: Game: AppID 225220

-- MAIN APPLICATION
addappid(225220)
addappid(228983)
addappid(228990)
-- Game: addappid(225220)

-- MAIN APP DEPOTS / PACKAGES
addappid(225221, 1, "b034b930041a2ff9897e9b23bbf1add795fa963179222cf5aba57d9f1dc95139")
