-- Lua provided by RyzenAPI
-- Game: NASCAR The Game: 2013

-- MAIN APPLICATION
addappid(225220)
addappid(228983)
addappid(228990)
addappid(254580)
addappid(254581)
addappid(254582)
addappid(254583)
addappid(254584)
addappid(254585)

-- MAIN APP DEPOTS / PACKAGES
addappid(225221, 1, "b034b930041a2ff9897e9b23bbf1add795fa963179222cf5aba57d9f1dc95139")
