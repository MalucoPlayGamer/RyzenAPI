-- Lua provided by RyzenAPI
-- Game: Lone Hero Path

-- MAIN APPLICATION
addappid(2890970)
-- Game: addappid(2890970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890971, 1, "c01bdc939ac8d3ccd29d491b2f79735a615f879fec84563f65744eb15c9d0ba8")
