-- Lua provided by RyzenAPI
-- Game: Game: Hippocampus

-- MAIN APPLICATION
addappid(1079940)
-- Game: addappid(1079940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079941, 1, "54b68c22e472263759d4f039a8b0020b22c54afc1cb0ecf3c0ff277fb519c9ed")
