-- Lua provided by RyzenAPI
-- Game: Squids Odyssey

-- MAIN APPLICATION
addappid(822640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(822641, 1, "f2b59c99956acabe0e7beeb2ba377ed9dbfa8d6c96e0d1c465a4b15496ac7d0b")

