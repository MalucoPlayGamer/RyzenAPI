-- Lua provided by RyzenAPI
-- Game: addappid(822640)

-- MAIN APPLICATION
addappid(822640)

-- MAIN APP DEPOTS / PACKAGES
addappid(822641, 1, "f2b59c99956acabe0e7beeb2ba377ed9dbfa8d6c96e0d1c465a4b15496ac7d0b")
