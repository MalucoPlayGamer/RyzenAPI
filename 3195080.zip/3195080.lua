-- Lua provided by SkyAPI 
-- Game: Spellsided Demo
addappid(3195080)
addappid(3195081, 1, "9aff351b8a6e5ac2d5ae81cf6c143ad10fada2ff3e28743151cd07d41b90a150")
