-- Lua provided by RyzenAPI
-- Game: Spellsided Demo

-- MAIN APPLICATION
addappid(3195080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195081, 1, "9aff351b8a6e5ac2d5ae81cf6c143ad10fada2ff3e28743151cd07d41b90a150")

