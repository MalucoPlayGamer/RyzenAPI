-- Lua provided by RyzenAPI
-- Game: 384210

-- MAIN APPLICATION
addappid(384210)
-- Game: addappid(384210)

-- MAIN APP DEPOTS / PACKAGES
addappid(384211, 1, "6f8dc60b05275bbe9ce4efbd1a5aad3bb8054af491f2880a4b63a309ca6253aa")
