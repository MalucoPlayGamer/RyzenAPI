-- Lua provided by RyzenAPI
-- Game: All That Remains

-- MAIN APPLICATION
addappid(749580)

-- MAIN APP DEPOTS / PACKAGES
addappid(749581, 1, "d4fb2c0a641bac310e39f11d6aa6ff8160e825db8a1f3d7bd299668bb6a02d9e")
