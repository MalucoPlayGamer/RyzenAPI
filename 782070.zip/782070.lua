-- Lua provided by RyzenAPI
-- Game: Late Night 1320

-- MAIN APPLICATION
addappid(782070)
addappid(782560)

-- MAIN APP DEPOTS / PACKAGES
addappid(782071,0,"51e19b74d3e943e821422d61ba97f3cc6f83b8d86f9d6ac0394cb91c2916892f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
