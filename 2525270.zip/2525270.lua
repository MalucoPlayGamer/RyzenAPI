-- Lua provided by RyzenAPI
-- Game: The House [zebaxx]

-- MAIN APPLICATION
addappid(2525270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525271, 1, "5e5ccad3e7f86cfaf3072a67fa8421d69d4d2be39627499198a07ba43cf11087")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
