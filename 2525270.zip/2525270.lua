-- Lua provided by RyzenAPI
-- Game: addappid(2525270)

-- MAIN APPLICATION
addappid(2525270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525271, 1, "5e5ccad3e7f86cfaf3072a67fa8421d69d4d2be39627499198a07ba43cf11087")
