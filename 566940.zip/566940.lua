-- Lua provided by RyzenAPI
-- Game: Claws & Feathers 2

-- MAIN APPLICATION
addappid(566940)

-- MAIN APP DEPOTS / PACKAGES
addappid(566947,0,"dc27525f19a7a27fe9a6231111f71eb2a3b43f9830dbffb7f591bdaa5dcef59a")
addappid(566948,0,"34db363b17e63fa102fc4640c1ae28284d8c9292ea9bd9e1f287079c0d9361ab")
addappid(566949,0,"4a1965915d96849add90e60ab8a9c83023f57302bae069c91d2af8e4ee150a7c")

