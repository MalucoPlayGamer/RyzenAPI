-- Lua provided by RyzenAPI
-- Game: SWORD ART ONLINE Last Recollection DEMO

-- MAIN APPLICATION
addappid(2296830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296831, 1, "a43ff9383f00a4fa21d67445fac5503b7fb84ccacba23a13245a5f39d12c8735")
