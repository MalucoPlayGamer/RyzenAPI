-- Lua provided by SkyAPI 
-- Game: SWORD ART ONLINE Last Recollection DEMO
addappid(2296830)
addappid(2296831, 1, "a43ff9383f00a4fa21d67445fac5503b7fb84ccacba23a13245a5f39d12c8735")
