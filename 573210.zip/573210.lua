-- Lua provided by RyzenAPI 
-- Game: Mistwood Heroes
addappid(573210)
addappid(573211, 1, "2aaa8179e9e9bce97b5e9a8504c7a626ae0fdcf68c8065e5794db0294f54bfef")
