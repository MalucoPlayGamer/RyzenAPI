-- Lua provided by RyzenAPI
-- Game: Game: Mistwood Heroes

-- MAIN APPLICATION
addappid(573210)
-- Game: addappid(573210)

-- MAIN APP DEPOTS / PACKAGES
addappid(573211, 1, "2aaa8179e9e9bce97b5e9a8504c7a626ae0fdcf68c8065e5794db0294f54bfef")
