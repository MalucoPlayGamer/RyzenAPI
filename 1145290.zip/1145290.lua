-- Lua provided by RyzenAPI 
-- Game: Out There: Oceans of Time
addappid(1145290)
addappid(1145291, 1, "22263e94a8e7a25021a091c6f3f3cddbb6a0eb03e15abd4b21c07a58947d1c8e")
