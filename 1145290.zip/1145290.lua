-- Lua provided by RyzenAPI
-- Game: 1145290

-- MAIN APPLICATION
addappid(1145290)
-- Game: addappid(1145290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145291, 1, "22263e94a8e7a25021a091c6f3f3cddbb6a0eb03e15abd4b21c07a58947d1c8e")
