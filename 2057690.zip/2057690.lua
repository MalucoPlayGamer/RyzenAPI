-- Lua provided by RyzenAPI
-- Game: Schmaragon

-- MAIN APPLICATION
addappid(2057690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057691, 1, "e584956fa3b83afd536295dfed6e876a90df4a13569efc8c64e2e81cc09e2172")
addappid(2057692, 1, "31d913f55bd5fad086f69ad4ed9306d40e0e90f409dd1274a02351334a72bb7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
