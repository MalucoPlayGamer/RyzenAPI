-- Lua provided by RyzenAPI 
-- Game: Schmaragon
addappid(2057690)
addappid(2057691, 1, "e584956fa3b83afd536295dfed6e876a90df4a13569efc8c64e2e81cc09e2172")
addappid(2057692, 1, "31d913f55bd5fad086f69ad4ed9306d40e0e90f409dd1274a02351334a72bb7d")
