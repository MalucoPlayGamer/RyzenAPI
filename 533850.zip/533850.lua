-- Lua provided by RyzenAPI
-- Game: EggK47

-- MAIN APPLICATION
addappid(533850)
-- Game: addappid(533850)

-- MAIN APP DEPOTS / PACKAGES
addappid(533851, 1, "c8340fc96e6b6e83d814f28da1df9fd3755ea12dd08d27987db4e4fc0e83d826")
