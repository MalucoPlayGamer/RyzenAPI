-- Lua provided by RyzenAPI
-- Game: AirportSim

-- MAIN APPLICATION
addappid(1715280)
-- Game: addappid(1715280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715281, 1, "bae7ffcb078e65e62cc598e17e77d8490179058f9e3cb23a6d4950ce392d1476")
