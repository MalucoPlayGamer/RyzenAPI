-- Lua provided by SkyAPI 
-- Game: AirportSim
addappid(1715280)
addappid(1715281, 1, "bae7ffcb078e65e62cc598e17e77d8490179058f9e3cb23a6d4950ce392d1476")
