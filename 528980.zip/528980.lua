-- Lua provided by RyzenAPI
-- Game: Game: Arakion: Book One

-- MAIN APPLICATION
addappid(528980)
-- Game: addappid(528980)

-- MAIN APP DEPOTS / PACKAGES
addappid(528981, 1, "4021118e3141ad570da6569b70057b2bbd77424b78443cede2f6f62d6c224b01")
addappid(528982, 1, "dfcf7ecaffa1c68d90cdcb297e3fde6fd5d305327392cc575212ed79dee9e9c3")
addappid(528983, 1, "7c7a3f15e207d2a503bacc1d9f9574d052982114df93ce3e121add8ea1784415")
addappid(528984, 1, "92558337ef8979803e659b7abb3e8b12634d178930b6e135609959c4ef2135d1")
