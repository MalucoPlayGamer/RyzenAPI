-- Lua provided by RyzenAPI
-- Game: Fall Guys

-- MAIN APPLICATION
addappid(1097150)
addappid(1261620)
addappid(1343612)
addappid(1362660)
addappid(1426910)
addappid(1481570)
addappid(1532290)
addappid(1569400)
addappid(1570380)
addappid(1570390)
addappid(1622930)
addappid(1677990)
addappid(1677991)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097151, 1, "243e7ffcd6bbd15f3976f648f7d851f975219f7a995ffb32e404e7a94e84dae9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
