-- Lua provided by RyzenAPI
-- Game: AppID 623990

-- MAIN APPLICATION
addappid(623990)
-- Game: addappid(623990)

-- MAIN APP DEPOTS / PACKAGES
addappid(623991, 1, "c9290ef0e824c6840c23c93f292ae77dff8ddb55d768609a9a5bddb38f99ab22")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
