-- Lua provided by RyzenAPI
-- Game: addappid(695960)

-- MAIN APPLICATION
addappid(695960)

-- MAIN APP DEPOTS / PACKAGES
addappid(695961, 1, "b9c41b8d71023e7ab7a0b836cf01de2dcd3217274752fd468d4558f94c4eaf13")
