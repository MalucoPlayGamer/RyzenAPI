-- Lua provided by RyzenAPI
-- Game: addappid(1500740)

-- MAIN APPLICATION
addappid(1500740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500742,0,"2719f2d16cebf065f834bb361d149a9fde8fc58e043d2b028903abbe0015db4e")
