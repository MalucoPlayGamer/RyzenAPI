-- Lua provided by RyzenAPI
-- Game: 282400

-- MAIN APPLICATION
addappid(282400)
-- Game: addappid(282400)

-- MAIN APP DEPOTS / PACKAGES
addappid(282401, 1, "039456f8fc0840c22bfacf2730eb32fcddec5896cb1c0b12236de03038dccb81")
