-- Lua provided by RyzenAPI
-- Game: SuperPower 2 Steam Edition

-- MAIN APPLICATION
addappid(282400)

-- MAIN APP DEPOTS / PACKAGES
addappid(282401, 1, "039456f8fc0840c22bfacf2730eb32fcddec5896cb1c0b12236de03038dccb81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
