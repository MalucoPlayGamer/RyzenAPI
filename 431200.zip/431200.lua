-- Lua provided by RyzenAPI
-- Game: Disastr_Blastr

-- MAIN APPLICATION
addappid(431200)
addappid(572340)

-- MAIN APP DEPOTS / PACKAGES
addappid(431201, 1, "12226e3d735ad2b064e1217cf74f07f6fe02391bdeb1ff555705736072d8341d")

