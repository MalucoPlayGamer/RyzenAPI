-- Lua provided by RyzenAPI
-- Game: Game: Vertigo Remastered Soundtrack

-- MAIN APPLICATION
addappid(1336610)
-- Game: addappid(1336610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336611, 1, "caf78430a5f2776a807533d3c2eb1c1b060437a10a89bfa770a3592da031e9f8")
addappid(1336612, 1, "6ee8c83a96a2f1b9f33046f70066e2ab2587450b47d9a90f6a7d86f9e76af31e")
