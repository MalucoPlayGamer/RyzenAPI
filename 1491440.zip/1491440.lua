-- Lua provided by RyzenAPI
-- Game: 1491440

-- MAIN APPLICATION
addappid(229006)
addappid(1491440)
addappid(1491443)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491442,0,"fe7ec399b6008ee81e0332c40976dbcd7bb5abe25df02f08582394b0ff8677a0")
