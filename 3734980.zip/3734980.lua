-- Lua provided by RyzenAPI
-- Game: A Simple job

-- MAIN APPLICATION
addappid(3734980)
addappid(3829860)

