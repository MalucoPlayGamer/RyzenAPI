-- Lua provided by RyzenAPI
-- Game: A Simple job

-- MAIN APPLICATION
addappid(3734980)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3829860)
