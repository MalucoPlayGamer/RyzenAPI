-- Lua provided by RyzenAPI 
-- Game: GRAB
addappid(1701130)
addappid(1701131, 1, "8b7d9638098e0a56ecbea9527ef58665465936134987bdef0b46f140d3fa77bf")
