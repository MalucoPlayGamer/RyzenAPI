-- Lua provided by RyzenAPI
-- Game: GRAB

-- MAIN APPLICATION
addappid(1701130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1701131, 1, "8b7d9638098e0a56ecbea9527ef58665465936134987bdef0b46f140d3fa77bf")

