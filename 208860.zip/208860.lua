-- Lua provided by RyzenAPI
-- Game: Game: AppID 208860

-- MAIN APPLICATION
addappid(208860)
addappid(208881)
-- Game: addappid(208860)

-- MAIN APP DEPOTS / PACKAGES
addappid(208861, 1, "914aa0512d08b4ccf1bc881e42c16a179a13d9825fba493716fd1fe50af121f8")
addappid(208862, 1, "7c2d2db382a7deb08898ffea74c2fc2bec52f7623e9eada4238979307711b5aa")
addappid(208863, 1, "90ca61f8dbfa2423b22ac50a5f1b3a616042514c155bce90cd09f1ffa95b15c7")
addappid(208864, 1, "eb72228373fe42c9dc3fd6f64c84c4aedfcd35985837ee4a4b59d9d45813c4a3")
addappid(208865, 1, "53676dba1b86375afb64b7b2970f8a86c779018248fd30eb2106a072f0266b6c")
