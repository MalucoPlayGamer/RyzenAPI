-- Lua provided by RyzenAPI
-- Game: NTR is Common in Adventures

-- MAIN APPLICATION
addappid(4116020)

-- MAIN APP DEPOTS / PACKAGES
addappid(4116021,0,"41814ceca7e2844f62a105b08a6de08135b986620acb89c4af6290adf2e5e18e")

