-- Lua provided by RyzenAPI
-- Game: Divinity II - The Dragon Knight Saga

-- MAIN APPLICATION
addappid(58540)

-- MAIN APP DEPOTS / PACKAGES
addappid(58541, 1, "bf55fba7b985b5ea531d320674ab61e1b5cd30dabea33146514ef3d61e0a62d9")
addappid(58542, 1, "8b16be9a62aea90267c08a37b34daecfa84880ea255d322320dd071ab903ab1f")
addappid(58543, 1, "8c94852a10dcd3a01a069039e80182200f30a1f1301db2286eba84984b78debf")
addappid(58544, 1, "ef36a0b8c175460c81a5fdd867614913d13610c84242662e1cf636fbceca7076")
addappid(58545, 1, "dab564cc7f43898fb312e06d21bfe0a98bb5b3ae0ebd6c11597ea46b9d633901")
addappid(58546, 1, "92f9e5ddc64498920fa23787cd6e52991996fd1e4a3acc9a283ebb294c6f455b")
