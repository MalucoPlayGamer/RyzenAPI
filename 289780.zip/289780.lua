-- Lua provided by RyzenAPI
-- Game: Requiem: Desiderium Mortis

-- MAIN APPLICATION
addappid(289780)
