-- Lua provided by RyzenAPI
-- Game: The Last Duskreaper

-- MAIN APPLICATION
addappid(2266400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266401, 1, "4cc16c8537e9763b51a38199c3d9230054ccadaee46ab69c8e82eccef5458d53")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
