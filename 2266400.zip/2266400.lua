-- Lua provided by RyzenAPI 
-- Game: The Last Duskreaper
addappid(2266400)
addappid(2266401, 1, "4cc16c8537e9763b51a38199c3d9230054ccadaee46ab69c8e82eccef5458d53")
