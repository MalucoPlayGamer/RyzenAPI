-- Lua provided by RyzenAPI 
-- Game: Kingdom Of Peace
addappid(2904920)
addappid(2904921, 1, "9652164329e258838cc8bf16c4debe22a262112bc7341aefce4b263c7560c2ab")
