-- Lua provided by RyzenAPI
-- Game: Kingdom Of Peace

-- MAIN APPLICATION
addappid(2904920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904921, 1, "9652164329e258838cc8bf16c4debe22a262112bc7341aefce4b263c7560c2ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
