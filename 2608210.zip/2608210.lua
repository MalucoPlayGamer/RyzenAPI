-- Lua provided by RyzenAPI
-- Game: BLOODKILL

-- MAIN APPLICATION
addappid(2608210)
-- Game: addappid(2608210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2608211, 1, "03191d4178fb0483dfc03cb473e0f6910fe8ca6d3e5d1ebd4f9b76a913b48082")
