-- Lua provided by RyzenAPI
-- Game: Apoapsis

-- MAIN APPLICATION
addappid(1020610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020611, 1, "dea318f46dda3a39115efcd47f06ea42a09633976b1fb92fef272801036749f5")

