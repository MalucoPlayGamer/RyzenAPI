-- Lua provided by RyzenAPI
-- Game: 853860

-- MAIN APPLICATION
addappid(853860)
-- Game: addappid(853860)

-- MAIN APP DEPOTS / PACKAGES
addappid(853861, 1, "b92e1d9825ac56f4a2d5f2d7547991eafd4b5c74d0b3c59a6ece20a18ac6d1d0")
