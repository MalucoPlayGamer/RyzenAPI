-- Lua provided by RyzenAPI
-- Game: Space Smash

-- MAIN APPLICATION
addappid(1036490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036491, 1, "d43d30c09672908a6d22757771ffe40c767ff17b9ecbec62184f07a872743c79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
