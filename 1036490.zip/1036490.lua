-- Lua provided by SkyAPI 
-- Game: Space Smash
addappid(1036490)
addappid(1036491, 1, "d43d30c09672908a6d22757771ffe40c767ff17b9ecbec62184f07a872743c79")
