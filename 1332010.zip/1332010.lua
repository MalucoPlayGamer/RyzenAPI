-- Lua provided by RyzenAPI
-- Game: Game: Stray

-- MAIN APPLICATION
addappid(1332010)
-- Game: addappid(1332010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332011, 1, "e61bdb7aeaccc075f69345348178ac158f107c1433c9a28743797407dc335e4c")
addappid(1332012, 1, "b0288825cade4cf4aceb6bf5a2e523e0c94028b45fe8095fea1f7e04e26f5728")
