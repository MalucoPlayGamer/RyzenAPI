-- Lua provided by RyzenAPI
-- Game: Explore Fushimi Inari

-- MAIN APPLICATION
addappid(1098490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1098491, 1, "c24f8d019278fd9897427e4f95d6c70c42a9de8a38a1c4fb0b9bd8e70b3a27bd")
addappid(1098520, 0, "4120b3a5e39ae70865a258d4ac002b18fe1e4e010fc92924d1257d515c4c5a22")
