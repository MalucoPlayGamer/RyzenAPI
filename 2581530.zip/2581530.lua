-- Lua provided by RyzenAPI
-- Game: ハッピーパパサポート！～Sugar Daddy Support～

-- MAIN APPLICATION
addappid(2581530)
-- Game: addappid(2581530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581531, 1, "8c5a0192ba8e66aeb7f2d6b58fa814f81b77891b7be67d74dad1de51a0134056")
