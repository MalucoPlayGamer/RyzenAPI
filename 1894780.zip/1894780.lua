-- Lua provided by RyzenAPI
-- Game: Nova Lands Demo

-- MAIN APPLICATION
addappid(1894780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894781, 1, "d863925bdb4b1d3069019dbd6ba8284d1ef75a9e374cc96b60751a2b7386f547")
