-- Lua provided by RyzenAPI
-- Game: addappid(871720)

-- MAIN APPLICATION
addappid(871720)

-- MAIN APP DEPOTS / PACKAGES
addappid(871721, 1, "90e68dec72ab79583aa69fd0a65f03e510d7f0be9931995c2025f8eb8267156f")
