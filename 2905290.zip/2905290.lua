-- Lua provided by RyzenAPI
-- Game: Easy Breezy Drive

-- MAIN APPLICATION
addappid(2905290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2905291, 1, "4e24708d4384161d73f84b67b42f3d4f44c7c5fabd76faf771fde5ed78beff01")

