-- Lua provided by RyzenAPI
-- Game: Game: AppID 3421330

-- MAIN APPLICATION
addappid(3421330)
-- Game: addappid(3421330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421331, 1, "8edbdf3aed32ca767cda976eb29494df6160e007b1aabf6bb6918371f412858c")
