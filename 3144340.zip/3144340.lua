-- Lua provided by RyzenAPI
-- Game: Cult of PiN

-- MAIN APPLICATION
addappid(3144340) -- Cult of PiN

-- MAIN APP DEPOTS / PACKAGES
addappid(3144341, 1, "aa6b4eaa736b5485f52bb878fb3cc3e91d8976fa26aabf0941c97f196132cef1") -- Depot 3144341
addappid(3144342, 1, "832d54b3981b381fae0705dc665857724a1974f7df4be6db0a94c83a66bf71c6") -- Depot 3144342
addappid(3144343, 1, "8dd1dd2825cc942c4fe302ad0dc978c85a9269a58ec7f36b553ea8dfd33aa6c9") -- Depot 3144343

