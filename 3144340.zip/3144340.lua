-- 3144340's Lua and Manifest Created by Hubcap Manifest
-- Cult of PiN
-- Created: August 11, 2026 at 09:53:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3144340) -- Cult of PiN
-- MAIN APP DEPOTS
addappid(3144341, 1, "aa6b4eaa736b5485f52bb878fb3cc3e91d8976fa26aabf0941c97f196132cef1") -- Depot 3144341
setManifestid(3144341, "5066922582235838328", 200140261)
addappid(3144342, 1, "832d54b3981b381fae0705dc665857724a1974f7df4be6db0a94c83a66bf71c6") -- Depot 3144342
setManifestid(3144342, "109914324454428193", 197598595)
addappid(3144343, 1, "8dd1dd2825cc942c4fe302ad0dc978c85a9269a58ec7f36b553ea8dfd33aa6c9") -- Depot 3144343
setManifestid(3144343, "3080637425263184140", 216859902)