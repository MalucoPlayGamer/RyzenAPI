-- Lua provided by RyzenAPI
-- Game: Bō: Path of the Teal Lotus

-- MAIN APPLICATION
addappid(1614440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614441, 1, "da3db8e85ebe004aaddb6379888ddc7ebe35cb843b8bd1aed25c008839c26c62")

