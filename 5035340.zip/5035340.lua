-- Lua provided by RyzenAPI
-- Game: Tidewrack

-- MAIN APPLICATION
addappid(5035340) -- Tidewrack

-- MAIN APP DEPOTS / PACKAGES
addappid(5035341, 1, "a75fd7f6e5481ed6d301c617da7ee2b4f1cd0b2b78f0981d42bc0f76af9c3390") -- Depot 5035341
