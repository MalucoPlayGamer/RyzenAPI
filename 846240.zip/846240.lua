-- Lua provided by RyzenAPI
-- Game: 846240

-- MAIN APPLICATION
addappid(846240)
-- Game: addappid(846240)

-- MAIN APP DEPOTS / PACKAGES
addappid(846241, 1, "a20dc271a40ab942382b05894e0938fb1560a631a1d4e9cf6bc8d88b9777e02f")
