-- Lua provided by RyzenAPI
-- Game: addappid(383460)

-- MAIN APPLICATION
addappid(383460)

-- MAIN APP DEPOTS / PACKAGES
addappid(383461, 1, "5730cf3186bc697f621be00bbc3043a43a47cbef5dea56b8aa666dd3a47c8a3e")
addappid(383465, 1, "d08e368ff64b25c020e84a211957065c08f57c676240d9019987f6ccc8b9f9ad")
