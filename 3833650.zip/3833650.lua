-- Lua provided by RyzenAPI
-- Game: THE SCREEN Playtest

-- MAIN APPLICATION
addappid(3833650)
-- Game: addappid(3833650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3833651, 1, "9df060ca0392c55951263d0e9927db7f8a0e229ad609476f02f7e99bddde8954")
