-- Lua provided by RyzenAPI 
-- Game: Happy’s Humble Burger Farm: Ambush (OST)
addappid(1832410)
addappid(1832411, 1, "c33dc1f1f6ba1e2fa57fbe0bcc95ade4eaea4f4e3191dfe41fc1e8f11b6a90b9")
