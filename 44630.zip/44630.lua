-- Lua provided by RyzenAPI
-- Game: 44630

-- MAIN APPLICATION
addappid(44630)
-- Game: addappid(44630)

-- MAIN APP DEPOTS / PACKAGES
addappid(44631, 1, "bcd12700a701f1ad9908854c5eb1241270ee83c9fea08f667a151d1e03d36f85")
