-- Lua provided by RyzenAPI 
-- Game: AppID 44630
addappid(44630)
addappid(44631, 1, "bcd12700a701f1ad9908854c5eb1241270ee83c9fea08f667a151d1e03d36f85")
