-- Lua provided by RyzenAPI
-- Game: 2122162

-- MAIN APPLICATION
addappid(2122162)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122162,0,"abb15b12ee8e6487126c2f03e9fed5a317a9f992d122f546aba49ec0af3a3a06")

