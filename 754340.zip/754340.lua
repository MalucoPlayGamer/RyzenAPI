-- Lua provided by RyzenAPI
-- Game: Game: AppID 754340

-- MAIN APPLICATION
addappid(754340)
-- Game: addappid(754340)

-- MAIN APP DEPOTS / PACKAGES
addappid(754341, 1, "3122d144db52750a95d3d9990fc9e5c50c7dde7270998d78293acfeda6faec2f")
addappid(754342, 1, "3552ffadf5b1f0b814388abf95524fb21e0f72234e3fa56957a87afc33bfd2ce")
