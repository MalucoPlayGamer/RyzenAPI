-- Lua provided by RyzenAPI
-- Game: Spiritfall

-- MAIN APPLICATION
addappid(1835240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835241, 1, "a18508e6c20397d41437ea034f6cc75a22f2d6489ba7c23bf048f5cae405a8ee")
addappid(1835242, 1, "b9ba45bbc2bbbd83dcb47489b866aabeb1bbeb0858143ecc58a601d7b73de57b")
