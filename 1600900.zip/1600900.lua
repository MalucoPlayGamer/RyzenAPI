-- Lua provided by RyzenAPI
-- Game: addappid(1600900)

-- MAIN APPLICATION
addappid(1600900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600901, 1, "418e695b174e9fa66dcb521171c37b7596ee414c4ae58cb4b74de136eae6980a")
