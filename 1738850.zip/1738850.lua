-- Lua provided by RyzenAPI 
-- Game: Plumber 3
addappid(1738850)
addappid(1738851, 1, "328d7ace5479981ade20a18d96a104487beb009054cc61b2a9db622483e2b59a")
