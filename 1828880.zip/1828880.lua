-- Lua provided by RyzenAPI
-- Game: 1828880

-- MAIN APPLICATION
addappid(1828880)
-- Game: addappid(1828880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828881, 1, "0cc66708a5ebe7abdf0122d196d6f056126ac1abaab41b7a9c651ad4b584345f")
