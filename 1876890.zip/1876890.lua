-- Lua provided by RyzenAPI
-- Game: Wandering Sword

-- MAIN APPLICATION
addappid(1876890)
addappid(3027840) -- Wandering Sword - Mount Pack Majestic Steeds
addappid(3600640) -- Wandering Sword - Secrets of the Eastern Sea
addappid(3600650) -- Wandering Sword - Heros Adventure Collaboration DLC

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(1876890, 1, "17330e11dd131d13006d8e8df286ee717fd284f940bb652d3ce3d2390e258964")
addappid(1876891, 1, "40985dfc0fbcd23c2b692a036c22fad2ad18d03794b58ea33fd079acbfb53c5d")

