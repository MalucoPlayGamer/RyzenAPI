-- Lua provided by RyzenAPI 
-- Game: AppID 1876890
addappid(1876890)
addappid(1876891, 1, "40985dfc0fbcd23c2b692a036c22fad2ad18d03794b58ea33fd079acbfb53c5d")
