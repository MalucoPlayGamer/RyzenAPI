-- Lua provided by RyzenAPI
-- Game: addappid(672290)

-- MAIN APPLICATION
addappid(672290)

-- MAIN APP DEPOTS / PACKAGES
addappid(672291, 1, "692e97c9e4076b836807d18426047cd8f642dfb5093ba9fe2a68674cc1afe94e")
