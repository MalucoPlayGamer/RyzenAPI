-- Lua provided by RyzenAPI
-- Game: addappid(2803360)

-- MAIN APPLICATION
addappid(2803360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803361, 1, "6baf81f704f545a4cdd39adc0400334745f08d31ed765e00b6ac7a213ddcdcf6")
