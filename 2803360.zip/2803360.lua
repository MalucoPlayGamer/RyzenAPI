-- Lua provided by RyzenAPI
-- Game: Project L33T: Founders Edition

-- MAIN APPLICATION
addappid(2803360)
addappid(2808160)
addappid(3127200)
addappid(3127210)
addappid(3127220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2803361,0,"6baf81f704f545a4cdd39adc0400334745f08d31ed765e00b6ac7a213ddcdcf6")

