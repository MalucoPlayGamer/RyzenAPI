-- Lua provided by RyzenAPI
-- Game: addappid(899900)

-- MAIN APPLICATION
addappid(899900)

-- MAIN APP DEPOTS / PACKAGES
addappid(899900,0,"ddd40f67af4f6b4155526ee7abdb23041811b54bde86decee12965d5fdc05a8f")
