-- Lua provided by RyzenAPI
-- Game: Bright Memory: Infinite Soundtrack

-- MAIN APPLICATION
addappid(1781130)
-- Game: addappid(1781130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781131, 1, "93494e81b318050e6676c8d2402b163a0bf2001670ff1758132e712fbf57dc64")
addappid(1781132, 1, "d18e9832e6404391f229f37168aa7354c1ea034f6606f3420f265946d04ee87c")
