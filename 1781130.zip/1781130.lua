-- Lua provided by SkyAPI 
-- Game: Bright Memory: Infinite Soundtrack
addappid(1781130)
addappid(1781131, 1, "93494e81b318050e6676c8d2402b163a0bf2001670ff1758132e712fbf57dc64")
addappid(1781132, 1, "d18e9832e6404391f229f37168aa7354c1ea034f6606f3420f265946d04ee87c")
