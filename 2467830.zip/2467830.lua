-- Lua provided by RyzenAPI
-- Game: Dreamscape Abyss

-- MAIN APPLICATION
addappid(2467830)
-- Game: addappid(2467830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467831, 1, "384e59a5eb869f439b29abc894947cdf61619fa53ed65d36580ddfe7ad8782c5")
