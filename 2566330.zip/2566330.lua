-- Lua provided by RyzenAPI
-- Game: Game: American Arcadia Demo

-- MAIN APPLICATION
addappid(2566330)
-- Game: addappid(2566330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566331, 1, "8d64e526f8ab378e18b4dc01ecf6731e63c4900d677c099378c35170b012908c")
