-- Lua provided by RyzenAPI
-- Game: Lingo 2

-- MAIN APPLICATION
addappid(2523310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523311, 1, "e958c757f4aa0b4e4cfbc488cf45a75cd1aab386272c41b5570f0be2a1601c5d")
