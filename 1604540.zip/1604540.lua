-- Lua provided by RyzenAPI
-- Game: TURK: The Demon Slayer

-- MAIN APPLICATION
addappid(1604540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604541, 1, "29e6e43d3cf92cfdc4380d8952a77f827eb08f146e07cd17d15a0761416cf377")
