-- Lua provided by RyzenAPI
-- Game: Game: AppID 798420

-- MAIN APPLICATION
addappid(798420)
-- Game: addappid(798420)

-- MAIN APP DEPOTS / PACKAGES
addappid(798421, 1, "e91ec1d1b02d69881047e5b8d12fa2e93224d2654c2cb6c020e53c4cd8217125")
