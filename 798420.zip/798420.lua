-- Lua provided by RyzenAPI
-- Game: Professional Fishing

-- MAIN APPLICATION
addappid(798420)
addappid(937790)
addappid(937791)
addappid(937792)
addappid(988750)

-- MAIN APP DEPOTS / PACKAGES
addappid(798421,0,"e91ec1d1b02d69881047e5b8d12fa2e93224d2654c2cb6c020e53c4cd8217125")

