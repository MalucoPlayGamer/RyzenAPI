-- Lua provided by RyzenAPI
-- Game: addappid(2955220)

-- MAIN APPLICATION
addappid(2955220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955221, 1, "63cc6e9f8a8495eb736d6c4553de0767af9893c46a806b6cb0e667f86abc01e1")
