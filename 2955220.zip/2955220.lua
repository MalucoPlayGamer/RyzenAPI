-- Lua provided by RyzenAPI
-- Game: CARD QUEST

-- MAIN APPLICATION
addappid(2955220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955221, 1, "63cc6e9f8a8495eb736d6c4553de0767af9893c46a806b6cb0e667f86abc01e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
