-- Lua provided by RyzenAPI 
-- Game: CARD QUEST
addappid(2955220)
addappid(2955221, 1, "63cc6e9f8a8495eb736d6c4553de0767af9893c46a806b6cb0e667f86abc01e1")
