-- Lua provided by RyzenAPI 
-- Game: AppID 712840
addappid(712840)
addappid(712841, 1, "913ca9f5894eab832835ee20916df2db429e0027e30cbba2fc8fccab2972724f")
addappid(929360, 0, "b7dd2420173e11e5b3a201c00fe54d47ade373e7319dedea069b0cf8699660a3")
