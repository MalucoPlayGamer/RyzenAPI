-- Lua provided by RyzenAPI
-- Game: Forest Adventure

-- MAIN APPLICATION
addappid(1147700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147701, 1, "ddff0f7764ff730e2c207646b049aec933379b08fe0db042d348e51bb389a1a5")
