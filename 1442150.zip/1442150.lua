-- Lua provided by RyzenAPI
-- Game: Game: Raidfield 2

-- MAIN APPLICATION
addappid(1442150)
-- Game: addappid(1442150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442151, 1, "9220dc3080ac3f44e199b393e9bfe5ca15a4fcf86f3f1c16ddd6aa2309a41487")
addappid(1442152, 1, "49492196485d8aabc2855aa3faa7e83a39f0536fe09a2ff528a91a5337dd16b7")
addappid(1442153, 1, "1fed2ea69e728ae0fbb3e358cf432dd030ad77be141566e73f9815b16322f4c3")
