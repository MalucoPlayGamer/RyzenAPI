-- Lua provided by RyzenAPI
-- Game: AppID 3008930

-- MAIN APPLICATION
addappid(3008930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008931, 1, "1defee0743bda7b5ecafde1b70822ba52e62daadbed936afaf65e8e191cf9206")

