-- Lua provided by RyzenAPI
-- Game: Starbucket

-- MAIN APPLICATION
addappid(810050)

-- MAIN APP DEPOTS / PACKAGES
addappid(810051,0,"517a579fab49675933a9e71ba33688dbf2af2e2fe908f69f88033b8ecd766d4c")

