-- Lua provided by RyzenAPI
-- Game: Game: BoboInvasion

-- MAIN APPLICATION
addappid(2723220)
-- Game: addappid(2723220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723221, 1, "dad95a85ff86dceda3fa06507d1bf2859c4cf7ff5eacdce5fd629071ac5d5720")
