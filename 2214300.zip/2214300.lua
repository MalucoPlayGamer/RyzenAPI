-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Fantasy RPG BGM Pack - The Forest land Edition

-- MAIN APPLICATION
addappid(2214300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214300,0,"38682c8c919fef553b786d6a36bc0c4ab416a1381905d77414d9038f5efdf479")
