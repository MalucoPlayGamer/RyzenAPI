-- Lua provided by RyzenAPI
-- Game: 3464170

-- MAIN APPLICATION
addappid(3464170)
-- Game: addappid(3464170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464172,0,"cfe8422e038a99927f3b4f2681765a3570ff80aa3afada905a2c960e40cdb548")
