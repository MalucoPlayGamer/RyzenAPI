-- Generated with Luie @ https://lua.tools/
-- 1104280 - The Slormancer
-- Generated 2026-08-08 18:29:08 UTC
-- # Depots (Total/DLC/Shared): 3/1/1

-- Main AppID
addappid(1104280)

-- Main Depots
addappid(1104281, 1, "b118bf751695ef5b6f48a3daa0537e23dee2158285fd025252aa697b993f249c")
setManifestid(1104281, "8464868553383165664", 496725766)

-- DLC's (no depot keys required)
addappid(3625910) -- The Slormancer - Supporter Pack

-- DLC's (with depot keys)
-- The Slormancer- Original Soundtrack (AppID: 1110800)
addappid(1110800)
addappid(1110801, 1, "3896cdf9f8acc14e8e1590efe147374d5859997e3610bb80b4fc1adb92e4977f")
setManifestid(1110801, "1858826248462123647", 260997411)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
