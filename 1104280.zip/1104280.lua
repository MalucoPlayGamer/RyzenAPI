-- Lua provided by RyzenAPI
-- Game: addappid(1104280)

-- MAIN APPLICATION
addappid(1104280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104281, 1, "b118bf751695ef5b6f48a3daa0537e23dee2158285fd025252aa697b993f249c")
