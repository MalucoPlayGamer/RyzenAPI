-- Lua provided by RyzenAPI
-- Game: The Slormancer

-- MAIN APPLICATION
addappid(1104280)
addappid(1110800)
addappid(3625910) -- The Slormancer - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1104281, 1, "b118bf751695ef5b6f48a3daa0537e23dee2158285fd025252aa697b993f249c")
addappid(1110801, 1, "3896cdf9f8acc14e8e1590efe147374d5859997e3610bb80b4fc1adb92e4977f")

