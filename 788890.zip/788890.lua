-- Lua provided by RyzenAPI
-- Game: AppID 788890

-- MAIN APPLICATION
addappid(788890)

-- MAIN APP DEPOTS / PACKAGES
addappid(788891, 1, "4ad026129dd8515b3a9d0a499aadf253f672358f158f43d383f4383b63487673")
addappid(788892, 1, "3d1f9668b928270e80cdb18c748a3a7d067da9b734e0cfa54ad3328a7a363d62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
