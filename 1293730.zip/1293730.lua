-- Lua provided by RyzenAPI
-- Game: 1293730

-- MAIN APPLICATION
addappid(1293730)
-- Game: addappid(1293730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293731, 1, "1a68c325d93b327900892c4788093bf818275fc5fedfc0e5033c4f0bbaad4d41")
