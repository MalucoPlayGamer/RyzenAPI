-- Lua provided by RyzenAPI
-- Game: AppID 1293730

-- MAIN APPLICATION
addappid(1293730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293731, 1, "1a68c325d93b327900892c4788093bf818275fc5fedfc0e5033c4f0bbaad4d41")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
