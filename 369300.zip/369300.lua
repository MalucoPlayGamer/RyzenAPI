-- Lua provided by RyzenAPI
-- Game: 369300

-- MAIN APPLICATION
addappid(369300)

-- MAIN APP DEPOTS / PACKAGES
addappid(413790,0,"f3417bc996313c1cae4f49ddaa1ae27ef916f2452273f4b3fdc9acde10f25cc6")
