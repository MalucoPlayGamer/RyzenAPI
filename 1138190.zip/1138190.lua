-- Lua provided by RyzenAPI
-- Game: Poker Championship

-- MAIN APPLICATION
addappid(1138190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138191, 1, "2b3327d336ecd07f7285926b8ba13b771dc3065cae37be8dc49ae015622cf48b")
addappid(1138192, 1, "5968363a380c196160bc9785fba6e7983e6e5ba1b82005bcbeb40a4f77ced580")
addappid(1138193, 1, "4771b1a3fa549c25d6e4ed332b5e887e5e8f856d3c73a82f4e6d37e45c995acc")
