-- Lua provided by RyzenAPI
-- Game: Game: Civilization IV: Beyond the Sword

-- MAIN APPLICATION
addappid(8800)
-- Game: addappid(8800)

-- MAIN APP DEPOTS / PACKAGES
addappid(8801, 1, "9b2475fb8301069beebd316c853bba51da16eee0a4019fadfcd705719319ace0")
addappid(8802, 1, "53cade68c26fdea2d08a5bc54e9fd69cb9a347e1bcf521de4c7394f22dd87bd2")
addappid(8803, 1, "5ec48f5fd7fd2c94f9941f9af908e93d61d4d6f0537a2f9c1e07b6eca3614dfe")
