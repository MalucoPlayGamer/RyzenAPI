-- Lua provided by RyzenAPI 
-- Game: Hidden Ghost Town 2
addappid(1885010)
addappid(1885011, 1, "f6c6b7e138a90ca40507811dfefb7ca62e380cfa1e14121a3f9afdf3e80127bf")
