-- Lua provided by RyzenAPI
-- Game: Chefs Together

-- MAIN APPLICATION
addappid(2764690)
-- Game: addappid(2764690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764691, 1, "ee878e64cabd1cc20d8babc469f741ef743e1662beb88f951e080491da6757a9")
