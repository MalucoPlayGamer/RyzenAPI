-- 3323490's Lua and Manifest Created by Hubcap Manifest
-- Truxton Extreme
-- Created: July 30, 2026 at 14:15:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(3323490) -- Truxton Extreme
-- MAIN APP DEPOTS
addappid(3323491, 1, "5f19ca5931a9fc50e69027b18638dc0751283f0ee74c06249b69241bfcb40ac9") -- Depot 3323491
setManifestid(3323491, "5998309314940607796", 12248069874)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4317760) -- TXE - Batsugun MusicSkin set
addappid(4317780) -- TXE - Truxton 2 MusicSkin set
addappid(4317800) -- TXE - Truxton MusicSkin set