-- Lua provided by RyzenAPI
-- Game: This is Love

-- MAIN APPLICATION
addappid(3520300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3520302,0,"9d3c69d85c0718dacd12c6c3b97e0e423fce68b3104793291779041da7901e4b")
