-- Lua provided by RyzenAPI
-- Game: Fluffy Cubed

-- MAIN APPLICATION
addappid(1656600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656601, 1, "8856531b892e7153b6451e4e1e7c7b7bfe739c88609f9f08a15073375f4c28ad")
