-- Lua provided by RyzenAPI
-- Game: Game: Succubus: Hunt For Meal

-- MAIN APPLICATION
addappid(1642820)
-- Game: addappid(1642820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642821, 1, "148784e27e85d5d5d6f29408febe2cd4138fba35e90b10e3ad8cbbb40a34804e")
