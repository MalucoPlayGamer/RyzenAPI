-- Lua provided by RyzenAPI
-- Game: addappid(604780)

-- MAIN APPLICATION
addappid(604780)

-- MAIN APP DEPOTS / PACKAGES
addappid(604781, 1, "a744d8be6fa5f4b65f2595a63a3f69a5a40471051a20becc4ec46b699e38e4e9")
