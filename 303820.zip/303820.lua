-- Lua provided by RyzenAPI
-- Game: AppID 303820

-- MAIN APPLICATION
addappid(303820)

-- MAIN APP DEPOTS / PACKAGES
addappid(303821, 1, "1b089497a9be8e5d49f93ef9b3128ac76307fffbe455d03acd754eb22002bc82")

