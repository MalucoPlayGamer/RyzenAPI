-- Lua provided by RyzenAPI
-- Game: addappid(1566680)

-- MAIN APPLICATION
addappid(1566680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566681, 1, "ad6de723141d613a0f59dc02cc13f9df47778be3fdd9fef577dff347f2150e6c")
