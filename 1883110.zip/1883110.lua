-- Lua provided by RyzenAPI
-- Game: 1883110

-- MAIN APPLICATION
addappid(1883110)
-- Game: addappid(1883110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883111, 1, "ac3540634fea51bb1eca48b0d4961858eb00b4154d43e9d058e1e01ba6629b96")
