-- Lua provided by RyzenAPI
-- Game: Akihabara - Feel the Rhythm Remixed - Electric Symphony Soundtrack

-- MAIN APPLICATION
addappid(976540)

-- MAIN APP DEPOTS / PACKAGES
addappid(976540,0,"806ba36f77d07a2e9ae25b7114d4a0344bf3cfd5d3a9eec21ca646e9974a126a")
