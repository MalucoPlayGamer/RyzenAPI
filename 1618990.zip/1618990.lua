-- Lua provided by RyzenAPI
-- Game: 1618990

-- MAIN APPLICATION
addappid(1618990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618990,0,"b72c1c8ac6a8e6f542c3501825a6c8ca821f969c1af52bad5fa4ef6d40fee9a5")

