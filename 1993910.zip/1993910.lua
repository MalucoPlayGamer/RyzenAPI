-- Lua provided by RyzenAPI
-- Game: Holy Shit

-- MAIN APPLICATION
addappid(1993910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993912,0,"4ff0b90f66af7dbce5fa5a3789d442c8664fc555625b7ec9279409931cc1480c")

