-- Lua provided by RyzenAPI
-- Game: Mokoko X - Artwork

-- MAIN APPLICATION
addappid(1791240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791240,0,"470e78ab5c6a3df24ab374b995d40a568e6ca71204663c81aec0f6e9ea968740")
