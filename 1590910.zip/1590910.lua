-- Lua provided by RyzenAPI
-- Game: Forgive Me Father

-- MAIN APPLICATION
addappid(1590910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590911, 1, "8e2ba27316a162742cd823bb6a93eca7ed9a19826e1adcb9e5efc4c882505347")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
