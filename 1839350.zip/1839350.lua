-- Lua provided by RyzenAPI
-- Game: Dawn of Kagura: Natsu's Story

-- MAIN APPLICATION
addappid(1839350)
addappid(1839351)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839352,0,"42bd86f112cf85d9f5d5f13ebecf4c393086d15e7a9713f2d8ae947edc079699")
addappid(1839353,0,"7bb5323c80fe48d6a364aee9f8342cff4d08aa36142db1a4df34a345f8acc4e5")

