-- Lua provided by RyzenAPI
-- Game: addappid(340490)

-- MAIN APPLICATION
addappid(340490)
addappid(470670)

-- MAIN APP DEPOTS / PACKAGES
addappid(340491, 1, "0d0ef85fb4ef1841bacb24ada1782cb0adde2ecdbc2874204a3a2a4338e13986")
