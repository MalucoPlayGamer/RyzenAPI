-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2022 DataEditor

-- MAIN APPLICATION
addappid(1612970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612971, 1, "abf69f1570d97a68852b3e512b46f1543c6e7944fd8d296fc070920be5e06566")
