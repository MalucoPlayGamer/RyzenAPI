-- Lua provided by RyzenAPI
-- Game: Game: Don't Remember

-- MAIN APPLICATION
addappid(2194760)
-- Game: addappid(2194760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194761, 1, "5ef6299c5b919925e335f021e1e8ed88d0c43320233c6ad8b0b3dc894d3d8ae6")
