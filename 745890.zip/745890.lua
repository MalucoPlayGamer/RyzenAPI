-- Lua provided by RyzenAPI
-- Game: This Is Not A Jumping Game

-- MAIN APPLICATION
addappid(745890)
-- Game: addappid(745890)

-- MAIN APP DEPOTS / PACKAGES
addappid(745891, 1, "629e55133df3fb6657d347bebeb3be73f546f73af1f45c8ee5eeca5ad3a1f7cc")
