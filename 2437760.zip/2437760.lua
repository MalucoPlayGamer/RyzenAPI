-- Lua provided by RyzenAPI
-- Game: addappid(2437760)

-- MAIN APPLICATION
addappid(2437760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437761, 1, "8997184280d022cf3ffd53eefb05fdfc5d2b331828a5f3cf7757decad8563709")
