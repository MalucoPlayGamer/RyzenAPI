-- Lua provided by RyzenAPI
-- Game: Karate Survivor Demo

-- MAIN APPLICATION
addappid(3027940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027941, 1, "c1abcac80173103bcfb4d6866141e78065f7e8a866efa9a1a1572396eb709aea")

