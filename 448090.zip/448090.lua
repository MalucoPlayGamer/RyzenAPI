-- Lua provided by RyzenAPI
-- Game: 448090

-- MAIN APPLICATION
addappid(448090)
-- Game: addappid(448090)

-- MAIN APP DEPOTS / PACKAGES
addappid(448091, 1, "1668f8e3efbc6a51d0585b591a51aa2a6bc0e67d73ff5235739e23a6c9a6850a")
