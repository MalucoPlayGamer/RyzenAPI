-- Lua provided by RyzenAPI
-- Game: Russian Reality

-- MAIN APPLICATION
addappid(1470730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470731, 1, "74105369820519690efb51676683bbb2b98998ec1b1a0d3e5c0b1e0305725fca")
