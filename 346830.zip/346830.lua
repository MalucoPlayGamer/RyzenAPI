-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY IV: THE AFTER YEARS

-- MAIN APPLICATION
addappid(346830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(346831, 1, "29256d3ca90ed186cad42ddd055105c037e64985b8392c3026e9b5023ee3c90b")

