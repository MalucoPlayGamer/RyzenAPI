-- Lua provided by RyzenAPI
-- Game: addappid(346830)

-- MAIN APPLICATION
addappid(346830)

-- MAIN APP DEPOTS / PACKAGES
addappid(346831, 1, "29256d3ca90ed186cad42ddd055105c037e64985b8392c3026e9b5023ee3c90b")
