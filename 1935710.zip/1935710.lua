-- Lua provided by RyzenAPI
-- Game: Game: Sex Diary - Futanari Jail

-- MAIN APPLICATION
addappid(1935710)
-- Game: addappid(1935710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935711, 1, "d3680b6be8a9d3d3a6a765bc3cccc087b1a7e26b13bbe970192fd0c160006add")
