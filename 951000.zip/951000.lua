-- Lua provided by RyzenAPI
-- Game: Trap Shrine

-- MAIN APPLICATION
addappid(951000)

-- MAIN APP DEPOTS / PACKAGES
addappid(951001, 1, "766c753ef96ccf3d373159335fefdeef08b1cc9c7e92610a1e4ca62d7c30b47c")
addappid(951002, 1, "f3bdad808ac13d4f53c20b62b8682a1e5a1f04d6d5af34aad64f91c1331fc356")
addappid(951003, 1, "814397fca752ad34e785d28a9a395a57f880053b53cd1e2a02f8747e87c6d43c")
addappid(951004, 1, "abe0e5007f2f4d07d72961a8a2c199eceea2864abc83e942987d7b2336d820f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
