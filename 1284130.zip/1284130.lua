-- Lua provided by RyzenAPI
-- Game: Sclash

-- MAIN APPLICATION
addappid(1284130)
addappid(2361880)
addappid(2541920)
addappid(2635600)
addappid(2956230)
addappid(2956610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284131, 1, "a604d50f75a0675f747be39102eb134964d12c5bb741294aeae199e4cd07acdf")

