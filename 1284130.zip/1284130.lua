-- Lua provided by RyzenAPI
-- Game: addappid(1284130)

-- MAIN APPLICATION
addappid(1284130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284131, 1, "a604d50f75a0675f747be39102eb134964d12c5bb741294aeae199e4cd07acdf")
