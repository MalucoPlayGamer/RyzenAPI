-- Lua provided by RyzenAPI
-- Game: Magical Delicacy Demo

-- MAIN APPLICATION
addappid(2655370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655371, 1, "aa989fd9525def055821e08c27029998807f75ea71434f42b3034e461ec7e065")
