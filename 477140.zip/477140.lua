-- Lua provided by RyzenAPI
-- Game: 477140

-- MAIN APPLICATION
addappid(477140)
-- Game: addappid(477140)

-- MAIN APP DEPOTS / PACKAGES
addappid(477141, 1, "005416ef7c9a3b5ad7fd90bbf0b09df0fe294166d7891763741a0742b710e987")
