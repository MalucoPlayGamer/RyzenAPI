-- Lua provided by RyzenAPI
-- Game: Game: Pacific Drive

-- MAIN APPLICATION
addappid(1458140)
addappid(2646730)
addappid(2790060)
addappid(2935180)
addappid(3073780)
addappid(3242220)
addappid(3594760)
-- Game: addappid(1458140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458141, 1, "006e2d6e9d40e35f8533859d38ce7f71cb41794bcd91cc1c67617d86a13a6395")
