-- Lua provided by RyzenAPI
-- Game: Pacific Drive

-- MAIN APPLICATION
addappid(1458140)
addappid(2646730)
addappid(2790060)
addappid(2935180)
addappid(3073780)
addappid(3242220)
addappid(3594760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1458141, 1, "006e2d6e9d40e35f8533859d38ce7f71cb41794bcd91cc1c67617d86a13a6395")

