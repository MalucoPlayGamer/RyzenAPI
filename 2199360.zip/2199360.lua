-- Lua provided by RyzenAPI
-- Game: 2199360

-- MAIN APPLICATION
addappid(2199360)
addappid(2230870)
-- Game: addappid(2199360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199361, 1, "31fded73d20ea7e156d2b87bcffbdfa369be12a512d6c85d89220ce6e6d953e9")
