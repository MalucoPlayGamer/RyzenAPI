-- Lua provided by RyzenAPI
-- Game: Penarium

-- MAIN APPLICATION
addappid(307590)

-- MAIN APP DEPOTS / PACKAGES
addappid(307591, 1, "7e16ebed6477d67a710cc9137510f349b043c1ac7b11c258b8ebe228d1d8f9c6")
addappid(307592, 1, "5bb322f4e87b691b3a777c7a118316bcc5acb900272a304d3b98c906679e0189")
addappid(307593, 1, "dc2ad0b689f81c0bf791bff53767fabfea9668abe57c882b5ce81de6bbcfa825")

