-- Lua provided by RyzenAPI
-- Game: The Room

-- MAIN APPLICATION
addappid(288160)
-- Game: addappid(288160)

-- MAIN APP DEPOTS / PACKAGES
addappid(288161, 1, "1a8a6fcadef603cc5065b42f2673fcba8d47f561c1b594a37a1953f93a77b687")
