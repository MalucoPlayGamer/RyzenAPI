-- Lua provided by RyzenAPI
-- Game: addappid(2968980)

-- MAIN APPLICATION
addappid(2968980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968981, 1, "ac0f5fc7085176a3fe2e1443431e697a02481836b9d7200d0d371f52d4f4ed7a")
