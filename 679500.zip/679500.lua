-- Lua provided by RyzenAPI
-- Game: Campfire Cooking

-- MAIN APPLICATION
addappid(679500)

-- MAIN APP DEPOTS / PACKAGES
addappid(679501,0,"e5a06cb7e4685a202548436b91c91d0b5b061c50074d3394b0aabb73912351d3")

