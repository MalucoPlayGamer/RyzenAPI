-- Lua provided by RyzenAPI
-- Game: Symphonic Rain

-- MAIN APPLICATION
addappid(629650)

-- MAIN APP DEPOTS / PACKAGES
addappid(629651, 1, "dc42c51287c6abddd062bff13c1f33c5d391bc8c6e0fcbd5fceeacae896d794c")
addappid(629652, 1, "890b7bbf22e8cbd242826a7bbcb6d785e67881ff597a70efe1995db6a3fe795b")
addappid(629653, 1, "0425085ab8851b0b592d10c574b41781c6c6004c964fe3ad6534607e3ce49bdc")
addappid(629654, 1, "8e8b5b2e83212a1e5321db1e97a6b05320a9dfbfe20cf4d8392d308c1f043493")
addappid(629655, 1, "352038302a3f8b01aa8620cc6e58f69c7428139fb3a9ca956f8412e858386ffd")
addappid(629656, 1, "7adbc4d5b689e51c8f4f0feffec9101c68b7b3563578764e55f286024ae0ffa0")
addappid(629657, 1, "5501712fa32069f1569c74363c9b57485996379ea71a9618889960e9ec55f236")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
