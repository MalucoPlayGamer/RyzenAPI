-- Lua provided by RyzenAPI
-- Game: Iragon: Prologue

-- MAIN APPLICATION
addappid(2229490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229491, 1, "046763678f2869d779f01a7a8d04fcd1f31bcd294ea6660d676844a0c9ce9dd3")
addappid(2229492, 1, "628dd05e7bffafe7e9584893d4728e46eea1917686b1b126272e150fbee53440")

