-- Lua provided by RyzenAPI
-- Game: EvoLife

-- MAIN APPLICATION
addappid(2102770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102771,0,"823ca092ac5c166c76ee7f366b12f3b0b1122876c9cc9f0ddc97315d792f6640")
