-- Lua provided by RyzenAPI
-- Game: Minit

-- MAIN APPLICATION
addappid(609490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(609491, 1, "88b4fe3a47df16bc4ca7839b6ac74cdfa65e49e32bab352cf36cd3a46f091b20")
addappid(609492, 1, "8d2decdc11897741951836db361a91399d3570f4d0d8b6f2d26936204a0cb929")
addappid(609493, 1, "83d72756ebf378fc77f1028a8fbb9a83f1630a0d5544f88f01a6c866cd2cc413")

