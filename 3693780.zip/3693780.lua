-- Lua provided by RyzenAPI
-- Game: Broken Arrow Soundtrack

-- MAIN APPLICATION
addappid(3693780)
-- Game: addappid(3693780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3693781, 1, "e0e98c1b997f2cd43ff79d143606267c7a23dce3abceb239f088a33c3923cd63")
