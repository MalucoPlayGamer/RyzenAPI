-- Lua provided by RyzenAPI
-- Game: 717060

-- MAIN APPLICATION
addappid(717060)
-- Game: addappid(717060)

-- MAIN APP DEPOTS / PACKAGES
addappid(717061, 1, "76e39a6b46e347cc5f3cc891f2bb8dc2aefc9c554e81ba65aea7b1ac44514531")
