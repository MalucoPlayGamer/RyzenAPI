-- Lua provided by RyzenAPI
-- Game: Oil Rush

-- MAIN APPLICATION
addappid(200390)
addappid(228983)
addappid(229020)

-- MAIN APP DEPOTS / PACKAGES
addappid(200392,0,"76879e16821e404a63f0e2c4f97e7bedc4105657ae580ab1945f6335edf7a7eb")
addappid(200393,0,"afa288fc640ad40287a030fbdb8a30ccdd511e388e4dd1b509f9eab27b4a3d5a")
addappid(200394,0,"e8157adba5ea023861aa99b6a255805d0c9b1dcc1ae315ee599631315ea990cf")
addappid(200395,0,"5152f922c16aa9ce0a046a213df919340cfdf5dac3e3244a454b9880ff9be43b")
addappid(200396,0,"919f8c357c8f8d8db3bae2430c88bd51c66b59d4b9d011aeb5727cad414844d1")
addappid(200397,0,"897f10fbf46bebb8d23adffe0e90bdc3684e284594227f093c9f63806bdd4812")
addappid(200398,0,"f89e20aadb56072a1c6f0e536bbcebeee02ebb1ec48f1ec3b146fa721e494ad4")

