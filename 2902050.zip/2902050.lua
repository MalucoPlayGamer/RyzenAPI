-- Lua provided by RyzenAPI
-- Game: Game: The Planet Crafter Original Soundtrack

-- MAIN APPLICATION
addappid(2902050)
-- Game: addappid(2902050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902051, 1, "7b4e9eae4b3cbb994e3efaff9668dacfacf4dd0442655edb3f0b1113e4dacf8e")
