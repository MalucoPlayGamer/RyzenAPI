-- Lua provided by RyzenAPI
-- Game: 1681060

-- MAIN APPLICATION
addappid(1681060)
addappid(3402960)
-- Game: addappid(1681060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681061, 1, "cfa4f55a60171be45467df23bdd100ca1a02b90735280e06e3e7d61645116284")
