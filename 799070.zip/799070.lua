-- Lua provided by RyzenAPI
-- Game: 799070

-- MAIN APPLICATION
addappid(799070)
-- Game: addappid(799070)

-- MAIN APP DEPOTS / PACKAGES
addappid(799071, 1, "80277edc6cd9398594f05b5e2a931af10cb032000cf074d71634ee37b10b792f")
