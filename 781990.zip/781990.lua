-- Lua provided by RyzenAPI
-- Game: Wequer

-- MAIN APPLICATION
addappid(781990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(781991, 1, "4d7fb9d5e0e29ed705b9b0866dec51ad430161abe32f47beff81d9b3c43e9eef")

