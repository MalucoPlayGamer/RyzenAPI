-- Lua provided by RyzenAPI
-- Game: Game: 掼个蛋蛋

-- MAIN APPLICATION
addappid(2916760)
-- Game: addappid(2916760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916761, 1, "2b1458e8687ce4077c3cecbcf0938941f367da1512e734ba2665819e7e234272")
