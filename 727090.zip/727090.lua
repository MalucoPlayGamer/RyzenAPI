-- Lua provided by RyzenAPI
-- Game: 727090

-- MAIN APPLICATION
addappid(727090)
-- Game: addappid(727090)

-- MAIN APP DEPOTS / PACKAGES
addappid(727091, 1, "f89b7e37101434aa0f6e2eb574e412315cff43aff8fae0273e3d657984d64cd3")
