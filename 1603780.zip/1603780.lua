-- Lua provided by RyzenAPI
-- Game: addappid(1603780)

-- MAIN APPLICATION
addappid(1603780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603781, 1, "6e3c6d2a6416065d094d2cbb70b769ee91bc2f55db10f81b463273f5f23ebca5")
