-- Lua provided by RyzenAPI
-- Game: Hentai Sea Battle

-- MAIN APPLICATION
addappid(1882050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882051, 1, "199db275ac1298f030fb6d4c6892f63239e3e98b708795b37d753178cbcf5a8a")

