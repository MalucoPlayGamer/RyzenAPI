-- Lua provided by RyzenAPI
-- Game: Cubicus 2

-- MAIN APPLICATION
addappid(1754350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754351,0,"a83e32836771a70964ecc0b09dc756b45ae29a0477af20cb71a635ea409c9086")

