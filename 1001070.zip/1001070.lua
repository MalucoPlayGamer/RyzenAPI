-- Lua provided by RyzenAPI
-- Game: Koi

-- MAIN APPLICATION
addappid(1001070)
-- Game: addappid(1001070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001071, 1, "6778f30fb7f466dfb0a03aa9e5c3a4ec4a9f1053ae903986317dbd5e8e0ef814")
