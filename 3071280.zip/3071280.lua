-- Lua provided by RyzenAPI
-- Game: BubbleBeast DigiDungeon

-- MAIN APPLICATION
addappid(3071280)
