-- Lua provided by RyzenAPI
-- Game: Cute Bite

-- MAIN APPLICATION
addappid(1586960)
-- Game: addappid(1586960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586962,0,"4d88c9575db5aebb50687e615e4b0d458175accd2d497f715c317c393c340b48")
addappid(1586965,0,"abb371a86c0f81b54cb4a25c35dc8a052b665586338d3bdac953364d2175c787")
