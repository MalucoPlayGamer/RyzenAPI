-- Lua provided by RyzenAPI
-- Game: addappid(3341100)

-- MAIN APPLICATION
addappid(3341100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341101, 1, "b9f1a89759d83c362b2a32c021eca9a9dbcb5c91ecebde59acfba17c94d89c6a")
