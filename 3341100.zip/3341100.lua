-- Lua provided by RyzenAPI
-- Game: SWIFT STRIDERS PARKOUR

-- MAIN APPLICATION
addappid(3341100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3341101, 1, "b9f1a89759d83c362b2a32c021eca9a9dbcb5c91ecebde59acfba17c94d89c6a")

