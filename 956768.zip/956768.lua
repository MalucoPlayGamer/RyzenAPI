-- Lua provided by RyzenAPI
-- Game: Cai Wenji - Officer Ticket / 蔡文姫使用券

-- MAIN APPLICATION
addappid(956768)

-- MAIN APP DEPOTS / PACKAGES
addappid(956768,0,"b5ee986e890e2db56294be6c938148bcffb618c6db09492630405ed96817c1da")
