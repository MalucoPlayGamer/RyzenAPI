-- Lua provided by RyzenAPI
-- Game: Game: Zombie Frenzy

-- MAIN APPLICATION
addappid(1360250)
-- Game: addappid(1360250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360251, 1, "668fd9b38d397673b07df209f59f7ee1b1614b319f460648d3e684dcf3cfe94d")
