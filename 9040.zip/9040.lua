-- Lua provided by RyzenAPI
-- Game: addappid(9040)

-- MAIN APPLICATION
addappid(9040)

-- MAIN APP DEPOTS / PACKAGES
addappid(9041, 1, "a6a446da6a42feddcac660cd0416e5128f91caa601bf5bfb747e45980063cbf1")
