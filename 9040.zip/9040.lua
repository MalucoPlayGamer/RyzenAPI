-- Lua provided by RyzenAPI
-- Game: Game: QUAKE Mission Pack 1: Scourge of Armagon

-- MAIN APPLICATION
addappid(9040)
-- Game: addappid(9040)

-- MAIN APP DEPOTS / PACKAGES
addappid(9041, 1, "a6a446da6a42feddcac660cd0416e5128f91caa601bf5bfb747e45980063cbf1")
