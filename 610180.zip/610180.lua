-- Lua provided by RyzenAPI
-- Game: AppID 610180

-- MAIN APPLICATION
addappid(610180)

-- MAIN APP DEPOTS / PACKAGES
addappid(610181, 1, "3a9ae992cf0ea6a3f7bb900dd188c2f26f0b53295c2e889275c742abba2ee0e5")
addappid(610182, 1, "236ff641f0450087a87939fa294de5fce404169749feba8fa025067e59381182")
addappid(610183, 1, "e2d07be6c078930cc1377a9a588b6c24be05199d6a1304b8388f3ab909bc7695")
addappid(610184, 1, "64494feb8aa15c1b9b01966021d0cfec2500c71f7fa4f2ce4b5da7cc6ef0fe59")
addappid(610185, 1, "c592a7e4de0f2d0abb3f7867a524ece065401398671abd19302d3b13cca9ed07")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
