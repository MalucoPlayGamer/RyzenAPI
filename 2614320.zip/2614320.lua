-- Lua provided by RyzenAPI
-- Game: 2614320

-- MAIN APPLICATION
addappid(2614320)
-- Game: addappid(2614320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614321, 1, "7e69ebb275be9a1a6c71c30173febd5fedca0dfc8c5dd53992dc98546af09b25")
