-- Lua provided by RyzenAPI
-- Game: 1779530

-- MAIN APPLICATION
addappid(1779530)
-- Game: addappid(1779530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779532,0,"551b8c505df1bcba70ed08a958b008948eb6235019d8536d80ef555fbcd6d9f6")
