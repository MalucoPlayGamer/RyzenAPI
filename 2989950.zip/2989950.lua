-- Lua provided by RyzenAPI
-- Game: addappid(2989950)

-- MAIN APPLICATION
addappid(2989950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989951, 1, "46ba9c35893709885a253dc16ae624a59f7ba30e7d5673c8d70bab12dd2dfa75")
