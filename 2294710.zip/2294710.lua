-- Lua provided by RyzenAPI
-- Game: addappid(2294710)

-- MAIN APPLICATION
addappid(2294710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294711, 1, "72c31f114680a73f0b98d3834301de114fd8fb3cf4de55d9e27cc5834823912d")
