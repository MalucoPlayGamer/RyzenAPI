-- Lua provided by RyzenAPI
-- Game: Game: Resist the succubus—The end of the female Knight

-- MAIN APPLICATION
addappid(1868000)
-- Game: addappid(1868000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868001, 1, "b1725a2cd27a3dd357d6b5696c2762a208c9cb18dcd72cd26fbc158b86f0011a")
addappid(1947360, 0, "125b5c7abd963b3df38978e5459b0d1e8241d4fc21f2e588ed2329ef8d1b073b")
