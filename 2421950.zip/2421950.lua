-- Lua provided by RyzenAPI
-- Game: addappid(2421950)

-- MAIN APPLICATION
addappid(2421950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421952,0,"a2cab1c9036221ca91c6de141c95a5957f6b4c4582266fc29f1c2dfcf2217b27")
