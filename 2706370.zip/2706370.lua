-- Lua provided by RyzenAPI
-- Game: AC Sailing

-- MAIN APPLICATION
addappid(2706370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2706371, 1, "1207864b13de7b29529eb7e9e17a43727d6e574f7895775fb0e086672e6d7a10")

