-- Lua provided by RyzenAPI
-- Game: AC Sailing

-- MAIN APPLICATION
addappid(2706370)
-- Game: addappid(2706370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706371, 1, "1207864b13de7b29529eb7e9e17a43727d6e574f7895775fb0e086672e6d7a10")
