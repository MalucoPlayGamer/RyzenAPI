-- Lua provided by RyzenAPI
-- Game: Game: 暴打萌鼠

-- MAIN APPLICATION
addappid(1606520)
-- Game: addappid(1606520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606521, 1, "71c33672af786783fa015bc9562c34f86be92de4d93b251ca6464777ae2af7b6")
