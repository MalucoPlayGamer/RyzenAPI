-- Lua provided by SkyAPI 
-- Game: AppID 586190
addappid(586190)
addappid(586191, 1, "eb32166076f678337b4a333d8ff3c90eac1c9db0d69315585dad55465760e88b")
