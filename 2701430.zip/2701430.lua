-- Lua provided by RyzenAPI
-- Game: 2701430

-- MAIN APPLICATION
addappid(2701430)
-- Game: addappid(2701430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701431, 1, "636f4b22ef1dfcdbd13f3c79b3501aecf9b57adbce1c6f7fd3e8dd75c89f7ba7")
