-- Lua provided by SkyAPI 
-- Game: AppID 585890
addappid(585890)
addappid(585891, 1, "0e30c24e4f9cc0eeeba00a38fecd661da256d2ccd9aa97d68ef91f042862e5a4")
