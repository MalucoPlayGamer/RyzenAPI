-- Lua provided by RyzenAPI
-- Game: addappid(1525060)

-- MAIN APPLICATION
addappid(1525060)
addappid(1749680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525061, 1, "8c1da9336aefe159ceaf74733e48d72a9db10f11d533b3ab4319e3ca6300e189")
