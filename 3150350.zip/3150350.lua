-- Lua provided by RyzenAPI
-- Game: addappid(3150350)

-- MAIN APPLICATION
addappid(3150350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150350,0,"6a230fc11c9925fed6da42d675b012a9ab88b69b1c174b90e6b592a8b9d85055")
