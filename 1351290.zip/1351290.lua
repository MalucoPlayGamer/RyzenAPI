-- Lua provided by RyzenAPI 
-- Game: AccidentHouse
addappid(1351290)
addappid(1351291, 1, "26b9b941b1aefd06af7eb4ca359e462a1f4618ac54b7db70f414e3bdf017eb12")
