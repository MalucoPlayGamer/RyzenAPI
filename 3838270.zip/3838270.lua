-- Lua provided by RyzenAPI
-- Game: Awurda First Wave

-- MAIN APPLICATION
addappid(3838270) -- Awurda First Wave

-- MAIN APP DEPOTS / PACKAGES
addappid(3838271, 1, "3037ce5f3d8ef578fae0b661975c2abb0e1c60af7b7fd0bafb46e1002e25f48f") -- Depot 3838271
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
