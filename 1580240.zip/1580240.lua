-- Lua provided by RyzenAPI
-- Game: Rune Factory 4 Special

-- MAIN APPLICATION
addappid(1580240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580241, 1, "0c3a546dad6b55213bee7095e92d19ab3b74c6d49d803344cbcbf53402df81f6")
