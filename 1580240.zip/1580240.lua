-- Lua provided by RyzenAPI
-- Game: Rune Factory 4 Special

-- MAIN APPLICATION
addappid(1580240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580241, 1, "0c3a546dad6b55213bee7095e92d19ab3b74c6d49d803344cbcbf53402df81f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
