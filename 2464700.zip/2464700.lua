-- Lua provided by RyzenAPI
-- Game: Game: AppID 2464700

-- MAIN APPLICATION
addappid(2464700)
-- Game: addappid(2464700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464701, 1, "7d5162212663457aa82a2ee3bc9e2d74b7ca8ad39733833dc7c6d918a9a74082")
