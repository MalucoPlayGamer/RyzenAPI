-- Lua provided by RyzenAPI
-- Game: Digital Girlfriend

-- MAIN APPLICATION
addappid(2464700)
addappid(2616180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464701, 1, "7d5162212663457aa82a2ee3bc9e2d74b7ca8ad39733833dc7c6d918a9a74082")

