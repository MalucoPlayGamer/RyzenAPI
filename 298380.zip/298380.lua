-- Lua provided by RyzenAPI
-- Game: 298380

-- MAIN APPLICATION
addappid(298380)
-- Game: addappid(298380)

-- MAIN APP DEPOTS / PACKAGES
addappid(298381, 1, "3d88baac7b6020dc3eee482340140709f93e6f8e976f8c9ebe33e1a282767ee1")
