-- Lua provided by RyzenAPI
-- Game: Reef Shot

-- MAIN APPLICATION
addappid(298380)

-- MAIN APP DEPOTS / PACKAGES
addappid(298381, 1, "3d88baac7b6020dc3eee482340140709f93e6f8e976f8c9ebe33e1a282767ee1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
