-- Lua provided by RyzenAPI
-- Game: Tactic Boxing

-- MAIN APPLICATION
addappid(2740280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2740281, 1, "ef29f751a9739d8085a82f083d762667ec556ed33dcdd3f5beda492efe955c55")

