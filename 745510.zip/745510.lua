-- Lua provided by RyzenAPI
-- Game: Game: Fidget Spinner In Space

-- MAIN APPLICATION
addappid(745510)
-- Game: addappid(745510)

-- MAIN APP DEPOTS / PACKAGES
addappid(745511, 1, "0c1387da4ff6c4cb0c83843c693e1c93037ef018f08f365505e4860458b79536")
