-- Lua provided by RyzenAPI
-- Game: 义体伞兵：第一次下降 Playtest

-- MAIN APPLICATION
addappid(3285600)
-- Game: addappid(3285600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3285601, 1, "a75224ea13cb0b819318259c010dac726328bcaed7d3069694a831487d6cc1d7")
