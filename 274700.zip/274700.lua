-- Lua provided by RyzenAPI
-- Game: AppID 274700

-- MAIN APPLICATION
addappid(274700)

-- MAIN APP DEPOTS / PACKAGES
addappid(274701, 1, "63078ad2446b6931090615748a01b8da53d321d7e9fc31dd36d0c4628e02c2cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(646930)
