-- Lua provided by RyzenAPI
-- Game: AppID 274700

-- MAIN APPLICATION
addappid(274700)
-- Game: addappid(274700)

-- MAIN APP DEPOTS / PACKAGES
addappid(274701, 1, "63078ad2446b6931090615748a01b8da53d321d7e9fc31dd36d0c4628e02c2cf")
