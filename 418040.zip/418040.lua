-- Lua provided by RyzenAPI
-- Game: 418040

-- MAIN APPLICATION
addappid(418040)
-- Game: addappid(418040)

-- MAIN APP DEPOTS / PACKAGES
addappid(418041, 1, "58471c5080bcb713367c685ede83c8c9b2a2fb1e68b0153f34778a86f1404df7")
addappid(418042, 1, "1c30457ca21a8ee4103cf3d131ac4c7a7e687a3cfe65b4f0d83c5a0baabb0cf3")
