-- Lua provided by RyzenAPI
-- Game: Wars Across The World: Russian Battles

-- MAIN APPLICATION
addappid(341043)
addappid(551910)
addappid(564890)
addappid(574962)
addappid(587380)
addappid(753293)
addappid(853150)
addappid(853151)
addappid(853152)
addappid(853153)
-- Game: addappid(853150)

-- MAIN APP DEPOTS / PACKAGES
addappid(551911,0,"42ad294869387b715961c1296c6507eff3f9b5138fdf9d4bd0c08e250704eb7b")
