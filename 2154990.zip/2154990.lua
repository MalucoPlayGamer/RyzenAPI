-- Lua provided by RyzenAPI
-- Game: AppID 2154990

-- MAIN APPLICATION
addappid(2154990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154991, 1, "804b29791bd95dc8c838b6f57928c5dd2fd285332b466f6de23800352b371b45")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
