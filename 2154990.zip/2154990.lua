-- Lua provided by RyzenAPI
-- Game: Game: AppID 2154990

-- MAIN APPLICATION
addappid(2154990)
-- Game: addappid(2154990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154991, 1, "804b29791bd95dc8c838b6f57928c5dd2fd285332b466f6de23800352b371b45")
