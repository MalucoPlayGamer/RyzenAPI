-- Lua provided by RyzenAPI
-- Game: Force of Warships: Battleship Games

-- MAIN APPLICATION
addappid(1991860)
-- Game: addappid(1991860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991862,0,"b45d6118d1797cdef4cc8072876bf4ef9b527aa21e06dd533f77c298fdd23141")
addappid(1991863,0,"ae09d4e416a3865dae0b4556a23ef732ef2a4dee8274ffe52020b1a92bc0b037")
addappid(1991864,0,"4c235c8899a009c867a094123554f091cd39288670d8226329168e89c3e49ccd")
