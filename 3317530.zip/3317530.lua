-- Lua provided by RyzenAPI
-- Game: Game: Knight's Night!

-- MAIN APPLICATION
addappid(3317530)
-- Game: addappid(3317530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317531, 1, "5271b7f346c8962a4e53c9732c16a3219a271b531f973e3816e80123f8ab59f0")
