-- Lua provided by RyzenAPI
-- Game: Game: AppID 2683600

-- MAIN APPLICATION
addappid(2683600)
-- Game: addappid(2683600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683601, 1, "ba9ac209bdd70229ce8d867c63b062b1b0ddbbd80c58b6cf0ec71aef7872a5cc")
