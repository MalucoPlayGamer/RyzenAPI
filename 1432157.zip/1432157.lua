-- Lua provided by RyzenAPI
-- Game: addappid(1432157)

-- MAIN APPLICATION
addappid(1432157)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432157,0,"903e9ab626764e142b2889e7cb61f1f131ff9157ec0ab2b73fbda2a23503e68f")
