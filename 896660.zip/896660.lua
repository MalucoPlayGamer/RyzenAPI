-- Lua provided by RyzenAPI
-- Game: Valheim Dedicated Server

-- MAIN APPLICATION
addappid(896660)

-- MAIN APP DEPOTS / PACKAGES
addappid(896661, 1, "3fceadfc3b43eeb8b99b6252e097ae76be634b44da5de93e24e728744ab2d32f")
addappid(896662, 1, "bfd072165d1948338279d6dbbb59f3eba8db112e9249311822ba40ba69593754")
addappid(896663, 1, "24fd9b099dacad85d14865546090b20856fc59b0ac21124311571d0b4172e704")

