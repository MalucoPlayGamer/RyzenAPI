-- Lua provided by RyzenAPI
-- Game: One Manga Day

-- MAIN APPLICATION
addappid(365070)
-- Game: addappid(365070)

-- MAIN APP DEPOTS / PACKAGES
addappid(365071, 1, "d6c8e084b7644bfbb142d80d64bbdadd622d38818c43bba62036609fce97fcec")
addappid(431980, 0, "8d12ca21253b452bce4865292ab47fe56c6b7795ab360ee3265d1180e11b2c05")
