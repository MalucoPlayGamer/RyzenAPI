-- Lua provided by RyzenAPI
-- Game: L'affaire est dans le sac

-- MAIN APPLICATION
addappid(2294590)
-- Game: addappid(2294590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294591, 1, "6f50d216db8fc6655b5055171b16224a334a3fa00344a53a5b1b0cbcb783e3ad")
