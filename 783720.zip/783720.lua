-- Lua provided by RyzenAPI
-- Game: Ninja Striker!

-- MAIN APPLICATION
addappid(783720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(783721,0,"eb1845970dbd23ab9f239378fa242afb975556ae96ef9c1febfdf7d365d744db")

