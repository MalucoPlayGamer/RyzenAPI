-- Lua provided by RyzenAPI
-- Game: Ninja Striker!

-- MAIN APPLICATION
addappid(783720)

-- MAIN APP DEPOTS / PACKAGES
addappid(783721,0,"eb1845970dbd23ab9f239378fa242afb975556ae96ef9c1febfdf7d365d744db")

