-- Lua provided by RyzenAPI
-- Game: Voxel Turf

-- MAIN APPLICATION
addappid(404530)

-- MAIN APP DEPOTS / PACKAGES
addappid(404532,0,"835ef2c68da792c6c415f91a2f6f4c84652c4adb4163c4b1abebca1003a8ba62")
addappid(404533,0,"6930e76e6bab462cb315b310f1ce855807260aed024018e9b6dd3e64696a6872")

