-- Lua provided by RyzenAPI
-- Game: Wolf Balls: The Game

-- MAIN APPLICATION
addappid(849630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(849631,0,"36f90187dec15ada15e5344aaedeef55e809da5329ba0a0dabecd7c27966e732")

