-- Lua provided by RyzenAPI
-- Game: Wolf Balls: The Game

-- MAIN APPLICATION
addappid(849630)

-- MAIN APP DEPOTS / PACKAGES
addappid(849631,0,"36f90187dec15ada15e5344aaedeef55e809da5329ba0a0dabecd7c27966e732")

