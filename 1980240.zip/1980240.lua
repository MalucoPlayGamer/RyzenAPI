-- Lua provided by RyzenAPI
-- Game: Ares Virus2

-- MAIN APPLICATION
addappid(1980240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980241, 1, "3047972e2a3f14d21cee0145e23a2fb6d07ce98e920c814f52a7a727ae5795ea")

