-- Lua provided by RyzenAPI
-- Game: AppID 1256040

-- MAIN APPLICATION
addappid(1256040)
-- Game: addappid(1256040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256041, 1, "3282edcab37be9a372f4f6e8d67c91dbe026134c03f547fa0472ac198dc79f30")
