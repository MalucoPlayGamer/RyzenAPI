-- Lua provided by RyzenAPI
-- Game: Alien Cat 6

-- MAIN APPLICATION
addappid(1370180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370181, 1, "3d73623718ee76478227f4152bdbb5b0b6f202cd416a5a27399fbb063f90b179")

