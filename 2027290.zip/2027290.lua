-- Lua provided by RyzenAPI
-- Game: 2027290

-- MAIN APPLICATION
addappid(2027290)
-- Game: addappid(2027290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027291, 1, "f2b8e2a23976eab0807990babfaa43697ffa2228a5b983e5f5033228d2aca750")
