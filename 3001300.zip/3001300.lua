-- Lua provided by RyzenAPI
-- Game: Whirlight - No Time To Trip - Demo

-- MAIN APPLICATION
addappid(3001300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001301, 1, "61fc53c45c86734e36a378af145be5a75e1e364a1128d87b27dc07f86f8da302")

