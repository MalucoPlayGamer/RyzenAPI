-- Lua provided by RyzenAPI 
-- Game: AppID 2279500
addappid(2279500)
addappid(2279501, 1, "1db95a931801586862518cda5431441a5eb70057c85f0af1ee74b61b87561657")
