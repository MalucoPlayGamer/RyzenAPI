-- Lua provided by RyzenAPI
-- Game: addappid(1564590)

-- MAIN APPLICATION
addappid(1564590)
addappid(1810120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564591, 1, "584ed914a010705df3399dc6603e1913bc1da0c56cf5d9a46b754a9751c92ff1")
