-- Lua provided by RyzenAPI 
-- Game: AppID 1102650
addappid(1102650)
addappid(1102651, 1, "5f3c820785d9e6173ba2df1776b6a860d98cfd1d2eba49f05fb908a78d8c5b6f")
