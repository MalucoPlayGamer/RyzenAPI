-- Lua provided by RyzenAPI
-- Game: Neon City Riders

-- MAIN APPLICATION
addappid(1102650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102651, 1, "5f3c820785d9e6173ba2df1776b6a860d98cfd1d2eba49f05fb908a78d8c5b6f")

