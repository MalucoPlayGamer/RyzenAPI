-- Lua provided by RyzenAPI
-- Game: addappid(429430)

-- MAIN APPLICATION
addappid(429430)

-- MAIN APP DEPOTS / PACKAGES
addappid(429431, 1, "8273a8ca20ad07831ae4ac102e4903b4d0e0e876b00221d261a9ece0322470ea")
