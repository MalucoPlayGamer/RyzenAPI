-- Lua provided by RyzenAPI
-- Game: Game: AppID 801510

-- MAIN APPLICATION
addappid(801510)
-- Game: addappid(801510)

-- MAIN APP DEPOTS / PACKAGES
addappid(801511, 1, "b5554de26e0b538337f86b575303f9f3a15addc1bdf132a712912fde85d31cfa")
