-- Lua provided by RyzenAPI
-- Game: Game: Thor's Ascension: Nine Realms

-- MAIN APPLICATION
addappid(2462570)
-- Game: addappid(2462570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462571, 1, "bd1d8eb4031a49e7ecd5fedda7fdeb4ec434e2be0e24fb28e5d6572a703a613b")
