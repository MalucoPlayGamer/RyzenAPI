-- Lua provided by RyzenAPI
-- Game: Thor's Ascension: Nine Realms

-- MAIN APPLICATION
addappid(2462570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462571, 1, "bd1d8eb4031a49e7ecd5fedda7fdeb4ec434e2be0e24fb28e5d6572a703a613b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
