-- Lua provided by RyzenAPI
-- Game: Thunderman - Adventures in another realm

-- MAIN APPLICATION
addappid(3224330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224331, 1, "e216b72e2627c742311f4fc1b936f174bad43e14054a840cb0fae761526c27e1")
