-- Lua provided by RyzenAPI
-- Game: addappid(3099640)

-- MAIN APPLICATION
addappid(3099640)
addappid(3841440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099641, 1, "b2ed6e538d382e74368f191954ef92eb4d9474d31615eb3471422e6bbceab1e3")
