-- Lua provided by RyzenAPI
-- Game: Game: Colony Ship: A Post-Earth Role Playing Game Demo

-- MAIN APPLICATION
addappid(1190730)
-- Game: addappid(1190730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190731, 1, "df9031a20ddbfa4f9452287f9aefcf77ea99eb454c447b9357080e5171c12307")
