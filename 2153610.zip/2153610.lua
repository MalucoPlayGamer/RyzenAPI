-- Lua provided by RyzenAPI
-- Game: Game: Virtual Sailor NG

-- MAIN APPLICATION
addappid(2153610)
-- Game: addappid(2153610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153611, 1, "63ddac76d2c030b430a8215c8487b45622bb38d2912b4b03f9cf243aea554531")
addappid(2159190, 0, "6ae7b7ad83be6aa8ad77b1b20af4919876ff7933f62d567196d45439865301a9")
