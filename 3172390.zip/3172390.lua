-- Lua provided by RyzenAPI
-- Game: 3172390

-- MAIN APPLICATION
addappid(3172390)
-- Game: addappid(3172390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172392,0,"a208990ca816c45c1643bd227c520f6f0f7bfb34f74e17803e59a8e3de84e5c3")
