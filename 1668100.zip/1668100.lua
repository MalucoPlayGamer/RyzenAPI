-- Lua provided by RyzenAPI
-- Game: BoneTown: The Second Coming Edition - Cheats

-- MAIN APPLICATION
addappid(1668100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668100,0,"7021f952988199e87beb2aaabd87466ea1b8ae13ca27644839c3653b4042f0f1")

