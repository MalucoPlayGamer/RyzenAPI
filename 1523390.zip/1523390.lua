-- Lua provided by RyzenAPI
-- Game: Fantasy Tavern Sextet -Vol.3 Postlude Days-

-- MAIN APPLICATION
addappid(1523390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523391, 1, "a77f9c84a32b0dc3d0aac69ca74d2357cad2607531d47a33a1586413bcab1048")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
