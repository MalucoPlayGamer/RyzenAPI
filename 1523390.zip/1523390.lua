-- Lua provided by RyzenAPI
-- Game: Fantasy Tavern Sextet -Vol.3 Postlude Days-

-- MAIN APPLICATION
addappid(1523390)
-- Game: addappid(1523390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523391, 1, "a77f9c84a32b0dc3d0aac69ca74d2357cad2607531d47a33a1586413bcab1048")
