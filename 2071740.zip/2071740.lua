-- Lua provided by RyzenAPI 
-- Game: Frogun Soundtrack
addappid(2071740)
addappid(2071741, 1, "e0f256b40de5066e5d226e31bc14c638c64272c9057fc00ef5267964387636ef")
addappid(2071742, 1, "4374ce9b537038209ba7160446174c96296f6cf721eec1bd167197b53474003a")
