-- Lua provided by RyzenAPI
-- Game: This Book Is A Dungeon

-- MAIN APPLICATION
addappid(404690)

-- MAIN APP DEPOTS / PACKAGES
addappid(404691, 1, "460fd36797c97a5dad858ea323f59c041265921a86f455089d915136bb853c4f")

