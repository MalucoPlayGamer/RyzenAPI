-- Lua provided by RyzenAPI
-- Game: Game: AppID 404690

-- MAIN APPLICATION
addappid(404690)
-- Game: addappid(404690)

-- MAIN APP DEPOTS / PACKAGES
addappid(404691, 1, "460fd36797c97a5dad858ea323f59c041265921a86f455089d915136bb853c4f")
