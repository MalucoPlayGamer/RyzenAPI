-- Lua provided by RyzenAPI
-- Game: Eiyuden Chronicle: Hundred Heroes

-- MAIN APPLICATION
addappid(1658280)
-- Game: addappid(1658280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658281, 1, "61d12d4ec2b9e888bfe67fae7c70f6d76bfe64bbef403294b7375cc326523bb4")
addappid(2694060, 0, "c0aa52099fb10cf9bb72bb177c12fb2e52918d0bf6d39dc3dfc85eaf07e5d07a")
addappid(2694070, 0, "1bf7c8888c8f8eff07d289aaebb430c7ea9bbd4ef1a3f0a1eb1ff1f158f557a6")
addappid(2694080, 0, "93f4886b80544255a37428bee906326f84974c434b3439009fdfb1f90d9bb7e4")
