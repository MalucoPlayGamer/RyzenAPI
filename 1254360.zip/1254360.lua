-- Lua provided by RyzenAPI
-- Game: addappid(1254360)

-- MAIN APPLICATION
addappid(1254360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254361, 1, "9306dd37f3efd64ca5208cac99e2965b92cb4f55f43014169546ddf241025eac")
