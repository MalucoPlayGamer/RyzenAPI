-- Lua provided by RyzenAPI
-- Game: Peekaboo Collection - 3 Tales of Horror

-- MAIN APPLICATION
addappid(1273780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273781, 1, "c1b5df0d748289b6af85731706dad5d403c1a894f01d3f0e232b791bb857dd7e")

