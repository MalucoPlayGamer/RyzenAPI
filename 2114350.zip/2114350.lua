-- Lua provided by RyzenAPI
-- Game: Is It Wrong to Repay the Debt in a Dungeon?

-- MAIN APPLICATION
addappid(2114350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114351, 1, "b21308a571b40a558790e6c17c249e397eb7c99a619e6b32a943aa50670a1868")
addappid(2114352, 1, "e52e79848eda9d7bc5ccedb45f55fefa16f0ce461e74f7831449eeb775240bbc")

