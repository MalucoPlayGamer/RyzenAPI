-- Lua provided by RyzenAPI
-- Game: Game: Bulls and Cows

-- MAIN APPLICATION
addappid(2078210)
-- Game: addappid(2078210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078211, 1, "bdbb0802bb88a04b47c0d360babe12f2225e632bd582dfc68ade17964fe8cafb")
