-- Lua provided by RyzenAPI
-- Game: 池畔追思 Poolcore Reflection

-- MAIN APPLICATION
addappid(2398260)
-- Game: addappid(2398260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398261, 1, "668f7afd53edd2a3ffc8737058ca53e16f879351d481ebd7b906bdda29b2ad8e")
