-- Lua provided by RyzenAPI
-- Game: 三国杀

-- MAIN APPLICATION
addappid(1180320)
addappid(3075030)
addappid(3713280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1180321, 1, "8e73ef21e6b319497fab5405ffc08844bb6fd19ab2b480893522dfccd411570d")
addappid(1180322, 1, "baf4b0301608f0b1529ff2a6905b008ae13eb72ac6480223b309c7d3be5d176f")

