-- Lua provided by RyzenAPI 
-- Game: AppID 295610
addappid(295610)
addappid(295611, 1, "1892ac569e7d6a9f6d9f7554c593eab2c31b1b00e325fba5fbb8db85bcf63fec")
addappid(295612, 1, "5baf8eaf7c9d8db86325ef8dcf4a559ca86e391da173f7a95277d992f649bfe6")
addappid(295613, 1, "48490c20e6e725954225c63b07235dbb5b08f569eb2f72204eeff37eb3f71e9c")
addappid(295614, 1, "b2fced65bd41d9a70597b6206a50bf1cf31c592bd557d009b8cd1c7820c9a800")
