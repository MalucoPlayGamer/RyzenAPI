-- Lua provided by RyzenAPI
-- Game: Game: 异世界生存指南

-- MAIN APPLICATION
addappid(3074020)
-- Game: addappid(3074020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074021, 1, "c349fd0b61413ccd60be941cc56222d310ef992cc81982bd590b83f4d845b03b")
