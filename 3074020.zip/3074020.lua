-- Lua provided by RyzenAPI
-- Game: 异世界生存指南

-- MAIN APPLICATION
addappid(3074020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3074021, 1, "c349fd0b61413ccd60be941cc56222d310ef992cc81982bd590b83f4d845b03b")

