-- Lua provided by RyzenAPI
-- Game: Voipas

-- MAIN APPLICATION
addappid(1029750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029751, 1, "6933d3b20275b1839b689f33453d944e5d572a582da10a88abcec99bf5fd1e75")
addappid(1029752, 1, "57d47cbe7807a1edb5be672e421fad4013ac140acad21443c596d6d734cb4163")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
