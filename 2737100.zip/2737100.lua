-- Lua provided by RyzenAPI
-- Game: Room231

-- MAIN APPLICATION
addappid(2737100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737101, 1, "8cee881040cfb6d367eb95bd9c639967ad47c667c7ebfb10cb3b321c2a206dd2")

