-- Lua provided by RyzenAPI
-- Game: Bulby - Diamond Course

-- MAIN APPLICATION
addappid(461390)

-- MAIN APP DEPOTS / PACKAGES
addappid(461391, 1, "ed6a5a99cce0da90f895d0a708e286791400121a4b1362d3bc2b56600a04efd3")
addappid(461392, 1, "c68a4472f75480bda8ea880070d2e4a06fffdb81e68f39124933bfca008bb0a0")
addappid(461393, 1, "37f34d376e0f7e97820cfc37f87dd3543e8fe157a3a9ee11310274cff960f6e2")
