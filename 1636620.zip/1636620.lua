-- Lua provided by RyzenAPI
-- Game: Cognition Method

-- MAIN APP DEPOTS / PACKAGES
addappid(1636620, 1, "28b698ec2795b6bae5077572053b0bd6ef7596a93fc5764558894b6ef86765e7") -- Cognition Method
addappid(1636621, 1, "5e83b630f4600c54f4fe85bf51e37a10e6d7be95a997317d1807484690d7b788") -- Depot 1636621

