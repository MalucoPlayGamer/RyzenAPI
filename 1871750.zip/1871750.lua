-- Lua provided by RyzenAPI
-- Game: Camp Focus

-- MAIN APPLICATION
addappid(1871750)
-- Game: addappid(1871750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871751, 1, "b5594b668a7188280451ce8a01b005fa495e3ed617c620a335a25d3e560df321")
