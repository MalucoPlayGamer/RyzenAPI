-- Lua provided by RyzenAPI
-- Game: Acid Nimbus

-- MAIN APPLICATION
addappid(909110)
addappid(1002060)
-- Game: addappid(909110)

-- MAIN APP DEPOTS / PACKAGES
addappid(909111, 1, "f85ad93d88ee5b256f43fc9e48f2ee58222af74fcd00298ad34cafe69f0534b6")
