-- Lua provided by RyzenAPI
-- Game: Palallel

-- MAIN APPLICATION
addappid(1155300)
-- Game: addappid(1155300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155301, 1, "e5529470b9ed21142b25d53e005316164cb2e66500e3091ad1b36c51fc0954ad")
