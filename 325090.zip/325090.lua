-- Lua provided by RyzenAPI
-- Game: Deep Dungeons of Doom

-- MAIN APPLICATION
addappid(325090)

-- MAIN APP DEPOTS / PACKAGES
addappid(325091, 1, "cfb49574a9498f2059e222ee00701a6b1855c0886bbf201be05260158c43c1c7")
addappid(325092, 1, "c07b2b14d4f9c76f5572e593f15aca0e8af8e2bd78d91d8252cb4f8f27b46b9b")
