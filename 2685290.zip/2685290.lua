-- Lua provided by RyzenAPI
-- Game: 2685290

-- MAIN APPLICATION
addappid(2685290)
-- Game: addappid(2685290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685291, 1, "96a892c9144cada9dbc4dd4fd8bda7e57efa07553e47c6eb85eace8e3eb1e642")
