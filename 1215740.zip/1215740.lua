-- Lua provided by RyzenAPI
-- Game: Game: Casina: The Forgotten Comedy

-- MAIN APPLICATION
addappid(1215740)
addappid(1643250)
-- Game: addappid(1215740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215741, 1, "768798fd9fd162823aca34c5edfa9da95378b06e9046028e412cd4e3ca508a0f")
