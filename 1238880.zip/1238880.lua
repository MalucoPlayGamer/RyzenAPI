-- Lua provided by RyzenAPI
-- Game: Battlefield™ Hardline

-- MAIN APPLICATION
addappid(1238880)
addappid(1238891)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238881, 1, "ca3213c27f45fd919fb3bbcc717d1fc836d56c9cadf6d7c5484aef22a2e9d886")
addappid(1238882, 1, "2ebe691fe34ea5ca9107fd88b53a6f821a6aa045026efc3b7ef232c72ece882a")
addappid(1238883, 1, "e1198986c9ffaab4271866ef20e776ba574e9b8b8040ecadbb3b76b1e424b205")
addappid(1238884, 1, "2d306ab061b8201a93d108fbd2f291f24efd36512d565ba88464ec6c4b121dae")
addappid(1238885, 1, "c5340ac0a0ed7f342cd4f828385b2cb49efb905acec556d75567da2df9e0e3c6")
addappid(1238886, 1, "950e5af714c7dbb4e5bfe0d4ff452d1f928d21837693850f9309ab786768a295")
addappid(1238887, 1, "30a987c78b276c7f506a4ee56651e3a334bde3ff35f7d79d5761c0d5d857b065")
addappid(1238888, 1, "2268764d6bc1f2f32a7458b3571487ede7466bca0fdc990f9afc8a3a96394ddc")
addappid(1238889, 1, "2346893aec717451d709a962d67a2e32f10fc08642c7596c358fe9fb9b994773")
addappid(1238892, 1, "82eb2ed4c66d175c26dd9fb2aab0dfae52ad55d50ebfd4c997983be50a4b1867")
addappid(1238893, 1, "7bc37388f1986e9db3f5edf96121383cfc438df8d9f39875786f4ef7392e7494")
addappid(1238894, 1, "382618919bb7d5b0a5b3f73014eccdff8ae21c7cb89f626b5215e7a74af6d103")
addappid(1238895, 1, "888d9571a3d76aaa8c83b15934a902da713d19a9ca98c4f5127304d432b979f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1238890)
addappid(1279010)
addappid(1279011)
addappid(1279012)
addappid(1279013)
addappid(1279340)
addappid(1279341)
addappid(1279350)
addappid(1279351)
addappid(1279352)
addappid(1279353)
addappid(1279354)
addappid(1279355)
addappid(1279356)
addappid(1279357)
