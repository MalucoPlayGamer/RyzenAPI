-- Lua provided by RyzenAPI
-- Game: 1877120

-- MAIN APPLICATION
addappid(1877120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877120,0,"ea3cb8b14df82204ce0c4b7f2ae4a54de59f9f031eed2cbd4c3413b24d633d83")
