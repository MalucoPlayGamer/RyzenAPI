-- Lua provided by RyzenAPI
-- Game: Police hot Tale

-- MAIN APPLICATION
addappid(1333330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333331, 1, "421ca045453e8b5db56fadca71e05d6132302d25fd3eca4be1aaef6e8743f29d")

