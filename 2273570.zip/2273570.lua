-- Lua provided by RyzenAPI
-- Game: Speed Dates

-- MAIN APPLICATION
addappid(2273570)
-- Game: addappid(2273570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273571, 1, "73304a42e06843929a96c6f16724d49956a799e760404575c201fd410bf58bf9")
