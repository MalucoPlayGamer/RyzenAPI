-- Lua provided by RyzenAPI
-- Game: addappid(3298670)

-- MAIN APPLICATION
addappid(3298670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298671, 1, "b1cbe4ec3b99408399fcc522315865e6a91a14757d6b2337010afc2b8b9c55ca")
