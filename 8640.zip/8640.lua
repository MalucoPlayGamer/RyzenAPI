-- Lua provided by RyzenAPI
-- Game: RACE On

-- MAIN APPLICATION
addappid(8640)
-- Game: addappid(8640)

-- MAIN APP DEPOTS / PACKAGES
addappid(8641, 1, "45b5c4155276d107622c5bb2781327a7b015010613a3fd977e950efad0f51817")
