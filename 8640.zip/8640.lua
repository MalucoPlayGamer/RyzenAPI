-- Lua provided by RyzenAPI 
-- Game: RACE On
addappid(8640)
addappid(8641, 1, "45b5c4155276d107622c5bb2781327a7b015010613a3fd977e950efad0f51817")
