-- Lua provided by SkyAPI 
-- Game: Flint: Treasure of Oblivion
addappid(2366130)
addappid(2366131, 1, "f6d46f01f1affdb38613d74aa1e1bf79f10dcd127b5ba3157ce8346367315266")
addappid(3126610, 0, "3387884958ec10954eeabf784bb84032a0b9008f5cf0bf64f2672003b43ec7d9")
