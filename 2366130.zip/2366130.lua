-- Lua provided by RyzenAPI
-- Game: Flint: Treasure of Oblivion

-- MAIN APPLICATION
addappid(2366130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2366131, 1, "f6d46f01f1affdb38613d74aa1e1bf79f10dcd127b5ba3157ce8346367315266")
addappid(3126610, 0, "3387884958ec10954eeabf784bb84032a0b9008f5cf0bf64f2672003b43ec7d9")

