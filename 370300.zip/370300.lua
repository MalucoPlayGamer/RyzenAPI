-- Lua provided by RyzenAPI
-- Game: 8-Bit Adventures 1: The Forgotten Journey Remastered Edition

-- MAIN APPLICATION
addappid(370300)

-- MAIN APP DEPOTS / PACKAGES
addappid(370301, 1, "a95f38d822f5722ef61a44fb702463effd3c2ef13fcd710dc6bd9fdefc6fab91")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
