-- Lua provided by RyzenAPI
-- Game: 370300

-- MAIN APPLICATION
addappid(370300)
-- Game: addappid(370300)

-- MAIN APP DEPOTS / PACKAGES
addappid(370301, 1, "a95f38d822f5722ef61a44fb702463effd3c2ef13fcd710dc6bd9fdefc6fab91")
