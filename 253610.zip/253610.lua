-- Lua provided by RyzenAPI
-- Game: 253610

-- MAIN APPLICATION
addappid(253610)
-- Game: addappid(253610)

-- MAIN APP DEPOTS / PACKAGES
addappid(253611, 1, "cede88a499c26a47f405bdfbcc24ac68985bc817a00d868b56a7d36855ad0833")
addappid(339080, 0, "07cbcf49e38e578555afef011814f0b98ac34ef750a8a24ba1cf1f3bb3a0f13c")
