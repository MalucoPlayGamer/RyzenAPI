-- Lua provided by RyzenAPI
-- Game: Wrack

-- MAIN APPLICATION
addappid(253610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(253611, 1, "cede88a499c26a47f405bdfbcc24ac68985bc817a00d868b56a7d36855ad0833")
addappid(339080, 0, "07cbcf49e38e578555afef011814f0b98ac34ef750a8a24ba1cf1f3bb3a0f13c")

