-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2184540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184540,0,"2d2c0622ba6156a3e87eb4099bbbbc78c6efb765fef48f435db2fc180af76979")

