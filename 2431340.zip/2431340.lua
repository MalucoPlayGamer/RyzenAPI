-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2431340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431340,0,"bff6faa6e7cb13954ff24a48f90322dbf66a17328f48ba2a580d2ea3ca1ce88a")

