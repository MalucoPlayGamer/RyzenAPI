-- Lua provided by RyzenAPI
-- Game: Game: Marie's Room

-- MAIN APPLICATION
addappid(648390)
-- Game: addappid(648390)

-- MAIN APP DEPOTS / PACKAGES
addappid(648391, 1, "3b9267f4ba84e272bd511f2fe7ca298a2b636e40c4b0fdb7fd05afc51c0e556a")
