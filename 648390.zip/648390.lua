-- Lua provided by RyzenAPI
-- Game: Marie's Room

-- MAIN APPLICATION
addappid(648390)

-- MAIN APP DEPOTS / PACKAGES
addappid(648391, 1, "3b9267f4ba84e272bd511f2fe7ca298a2b636e40c4b0fdb7fd05afc51c0e556a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1962190)
