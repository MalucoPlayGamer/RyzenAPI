-- Lua provided by RyzenAPI 
-- Game: Marie's Room
addappid(648390)
addappid(648391, 1, "3b9267f4ba84e272bd511f2fe7ca298a2b636e40c4b0fdb7fd05afc51c0e556a")
