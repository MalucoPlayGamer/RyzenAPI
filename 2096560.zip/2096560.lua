-- Lua provided by RyzenAPI
-- Game: Game: The Top

-- MAIN APPLICATION
addappid(2096560)
-- Game: addappid(2096560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096561, 1, "0a4491e2c4d54527d615fcceb01a383a2f348955fa9912ce366378408a480bf5")
