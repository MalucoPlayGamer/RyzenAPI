-- Lua provided by SkyAPI 
-- Game: The Top
addappid(2096560)
addappid(2096561, 1, "0a4491e2c4d54527d615fcceb01a383a2f348955fa9912ce366378408a480bf5")
