-- Lua provided by RyzenAPI
-- Game: The Top

-- MAIN APPLICATION
addappid(2096560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(2096561, 1, "0a4491e2c4d54527d615fcceb01a383a2f348955fa9912ce366378408a480bf5")

