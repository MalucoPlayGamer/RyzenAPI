-- Lua provided by SkyAPI 
-- Game: PaintBall War 2
addappid(1561980)
addappid(1561981, 1, "6172c726de9dc6d11d805ccd6766471996561d3931270163243e01d7f3b9d544")
