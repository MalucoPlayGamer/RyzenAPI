-- Lua provided by RyzenAPI
-- Game: PaintBall War 2

-- MAIN APPLICATION
addappid(1561980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561981, 1, "6172c726de9dc6d11d805ccd6766471996561d3931270163243e01d7f3b9d544")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
