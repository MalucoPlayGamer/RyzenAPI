-- Lua provided by RyzenAPI
-- Game: Game: PaintBall War 2

-- MAIN APPLICATION
addappid(1561980)
-- Game: addappid(1561980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561981, 1, "6172c726de9dc6d11d805ccd6766471996561d3931270163243e01d7f3b9d544")
