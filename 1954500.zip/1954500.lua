-- Lua provided by RyzenAPI
-- Game: 百战斗斗堂

-- MAIN APPLICATION
addappid(1954500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954501, 1, "cec85b7692c3fc3e48db561a568a38bd66007a0b41d5f56a2f2606a7908e2dc1")

