-- Lua provided by RyzenAPI
-- Game: 100 in 1 Game Collection

-- MAIN APPLICATION
addappid(2597660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597661, 1, "3b74025bbc30a704869587165e088402800f474812896041ca3deba9eefd180c")
