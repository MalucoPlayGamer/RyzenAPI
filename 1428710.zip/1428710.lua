-- Lua provided by RyzenAPI
-- Game: The Tarnishing of Juxtia

-- MAIN APPLICATION
addappid(1428710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428711, 1, "12e26071df458c8c2ce5b62e229603f1df09c4e60659f73cd38ebe077beb51d7")
