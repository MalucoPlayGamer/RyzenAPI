-- Lua provided by RyzenAPI
-- Game: Riding Shotgun

-- MAIN APPLICATION
addappid(1598410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598411, 1, "bf636f3093911fda6a3e19e629347460bf0b0680528a1184370a91b44aecbb88")

