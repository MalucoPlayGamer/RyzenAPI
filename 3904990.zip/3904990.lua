-- Lua provided by RyzenAPI
-- Game: Love Love Mystery Club

-- MAIN APPLICATION
addappid(3904990)
addappid(4367610)
addappid(4367620)
-- Game: addappid(3904990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3904991, 1, "14ad8caa761cccb2b5fd4e645d49b37d343b3f6b9c08396e3b0fd37a3547088b")
