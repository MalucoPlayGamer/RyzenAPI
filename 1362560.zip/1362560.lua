-- Lua provided by RyzenAPI
-- Game: Game: Fire Commander

-- MAIN APPLICATION
addappid(1362560)
-- Game: addappid(1362560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362561, 1, "9d796bdc2d962118910add1f9091fee20b9d013e35430c805b0ccb99d89113da")
