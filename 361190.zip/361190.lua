-- Lua provided by RyzenAPI
-- Game: Sparkle 3 Genesis

-- MAIN APPLICATION
addappid(361190)

-- MAIN APP DEPOTS / PACKAGES
addappid(361191, 1, "a58967811a33f96692892af00ffb2a821d26ab5325592f520b46930b82b7c7fa")
addappid(361192, 1, "3b26ab03af24c7839d5e58e28b1fb85334e74a44af88c7993dfba685f90b8666")
addappid(361193, 1, "7ed91fe33cd43e91927f9afc67d6a1866b4ee81e994bea0b1967505068637e51")
addappid(361194, 1, "441351cc6683fdc9765e7d250eebc047eeb0e0bd564e4724c38e6cfabc2ae126")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
