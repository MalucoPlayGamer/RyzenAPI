-- Lua provided by RyzenAPI
-- Game: 彷徨之街 The Street of Adrift Soundtrack

-- MAIN APPLICATION
addappid(2909920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909921, 1, "58b013f539126b744ccae4991fb9735f03ff06886b0e8e060ee9eeb181a439c7")
addappid(2909922, 1, "d4be78663d6873e46cc82e8bf4a40f3c24e19b68c310ee676c1eb84c0462c97d")
