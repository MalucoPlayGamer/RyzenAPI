-- Lua provided by RyzenAPI
-- Game: AppID 1196160

-- MAIN APPLICATION
addappid(1196160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196161, 1, "de189ec1a01ccd6dd4091707d269ffe28443d5fcfcfaace264f7f44574f0f796")
