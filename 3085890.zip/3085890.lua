-- Lua provided by RyzenAPI
-- Game: 3085890

-- MAIN APPLICATION
addappid(3085890)
-- Game: addappid(3085890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085891, 1, "5cf3c9208314cbde9de4b11acf051ea93779fddaece9022375cbf8f54ba14d84")
