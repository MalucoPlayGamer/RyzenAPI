-- Lua provided by RyzenAPI
-- Game: Higurashi When They Cry Hou - Ch.4 Himatsubushi

-- MAIN APPLICATION
addappid(526490)

-- MAIN APP DEPOTS / PACKAGES
addappid(526491, 1, "7249db1e3a8b4478d84af24306f3851f836effda30ffae37ce2b01ded0b8790d")
