-- Lua provided by RyzenAPI
-- Game: AppID 1145560

-- MAIN APPLICATION
addappid(1145560)
-- Game: addappid(1145560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145561, 1, "2b7e31f470445ab9c9bd78b7a49396ebc9fd8a010b86e767dc3ac786e8edb0ee")
