-- Lua provided by RyzenAPI
-- Game: Game: Wowo Island

-- MAIN APPLICATION
addappid(3136260)
-- Game: addappid(3136260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136261, 1, "bc05e70825c797452ba85706cf54aba0eaae6538500d1b336e565f4cf515c2fa")
