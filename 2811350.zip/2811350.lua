-- Lua provided by RyzenAPI
-- Game: Xiuzhen Idle DLC - Talismans

-- MAIN APPLICATION
addappid(2811350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811350,0,"e7abe2d652d8d75fd25640d4876d76efff92cf7d4605884d7306b1ffae636936")
