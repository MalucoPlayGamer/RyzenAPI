-- Lua provided by RyzenAPI
-- Game: Life Is Strange™ Demo

-- MAIN APPLICATION
addappid(329030)

-- MAIN APP DEPOTS / PACKAGES
addappid(329031, 1, "f26c333165d0f9e45eb63316ec86ad9ba7f6e9253786025b422f8d248da63de8")

