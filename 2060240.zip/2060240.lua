-- Lua provided by RyzenAPI
-- Game: addappid(2060240)

-- MAIN APPLICATION
addappid(2060240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060241, 1, "6225668ba7538cb3bcddeaaddcd65be5ae2dfd1aea28b4af83ea59ce042d2caf")
