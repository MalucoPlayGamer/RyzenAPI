-- Lua provided by SkyAPI 
-- Game: Quriocity
addappid(2060240)
addappid(2060241, 1, "6225668ba7538cb3bcddeaaddcd65be5ae2dfd1aea28b4af83ea59ce042d2caf")
