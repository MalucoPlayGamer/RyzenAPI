-- Lua provided by RyzenAPI
-- Game: Now you can't see me

-- MAIN APPLICATION
addappid(1644200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644201, 1, "99846c5c28feb8ac67e765dc6d711c05102cd83796844f62229ec75bd91e1cc7")

