-- Lua provided by RyzenAPI
-- Game: UBERMOSH Vol.5

-- MAIN APPLICATION
addappid(640380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(640381, 1, "4558f357046d22d3f0a4cabd37d855e190ea736a5b3cf29e99d7ae926d8c473e")
addappid(640382, 1, "9fc1719599097dfc728f83c00596fcd9f3f6276220eb1f5fa7f403071935eed2")

