-- Lua provided by RyzenAPI
-- Game: Pool Cleaning Simulator Demo

-- MAIN APPLICATION
addappid(2326390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326391, 1, "da70b36f9c9ae2a02411da14642ac1fe044bf2a7dbe93e8b270d72dd25f69355")

