-- Lua provided by RyzenAPI
-- Game: 8i - Make VR Human

-- MAIN APPLICATION
addappid(462530)
-- Game: addappid(462530)

-- MAIN APP DEPOTS / PACKAGES
addappid(462531, 1, "78c577bc8ef67e218be4c0e7a1461baf430554af21f6f684619ddf9d7d6d2b91")
