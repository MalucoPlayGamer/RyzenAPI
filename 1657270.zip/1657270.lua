-- Lua provided by SkyAPI 
-- Game: AppID 1657270
addappid(1657270)
addappid(1657271, 1, "0f108a8a5b02fb1481d67f5d7b36ed7c6738d5ebec02f7ec0ef28c8d80bc6712")
