-- Lua provided by RyzenAPI
-- Game: Mini Royale Demo

-- MAIN APPLICATION
addappid(1657270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657271, 1, "0f108a8a5b02fb1481d67f5d7b36ed7c6738d5ebec02f7ec0ef28c8d80bc6712")

