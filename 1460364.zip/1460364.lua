-- Lua provided by RyzenAPI
-- Game: FUSER™ - Kat DeLuna ft. Elephant Man - "Whine Up"

-- MAIN APPLICATION
addappid(1460364)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460364,0,"91eda71a078dcaaf348d0c68d46a3083e6f3976a1674cc34a4053ef08c930a46")

