-- Lua provided by RyzenAPI
-- Game: addappid(629030)

-- MAIN APPLICATION
addappid(629030)

-- MAIN APP DEPOTS / PACKAGES
addappid(629031, 1, "79c2d9f1853ba2fc45148f02627dc4641408648224d98fff7ee9fd0fe02ddcb1")
addappid(629032, 1, "1df4e9e179323c3732c8177ef081b8189ab45ad1eee0526fe5963e0e06087fc7")
addappid(629033, 1, "a545c862a83f0e334f34a7dcd3e1cf8df8be2b7222308891f4cd86eb4a6cedf9")
