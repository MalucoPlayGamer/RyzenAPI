-- Lua provided by RyzenAPI
-- Game: AppID 1766430

-- MAIN APPLICATION
addappid(1766430)
-- Game: addappid(1766430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766431, 1, "c055e05fa87c965a140b13b0abad91e6b6c91ffc56f2b89d4d3cb5fdf0d791ae")
