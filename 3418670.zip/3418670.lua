-- Lua provided by RyzenAPI
-- Game: 3418670

-- MAIN APPLICATION
addappid(3418670)
-- Game: addappid(3418670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418671, 1, "755488ea28b0d201cf721a3c0d09ea425616cbf2b7d0621de708141b45daf538")
