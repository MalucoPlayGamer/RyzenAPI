-- Lua provided by RyzenAPI
-- Game: 1844270

-- MAIN APPLICATION
addappid(1844270)
-- Game: addappid(1844270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844271, 1, "e9af58ec323df06435926c226c1fa6b7fc441175bbabea02e6047212b92b6be8")
