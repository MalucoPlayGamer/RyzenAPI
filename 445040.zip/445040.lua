-- Lua provided by RyzenAPI
-- Game: AppID 445040

-- MAIN APPLICATION
addappid(445040)

-- MAIN APP DEPOTS / PACKAGES
addappid(445041, 1, "a760548a371aa907700a7c9f8857ab01c45651aabf16a9d67a08d4efd48ed89f")
addappid(445042, 1, "e73e65a9c3fb94daa72616f4586730072a56f8ee3e4b7a3566441deaad3c42eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
