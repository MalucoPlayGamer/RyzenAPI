-- Lua provided by RyzenAPI
-- Game: addappid(3528910)

-- MAIN APPLICATION
addappid(3528910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3528911, 1, "55b3a1a1e39bdd2cc5f4bf2e2d76950708701e673499fef94cd76bbbb8b6ea95")
