-- Lua provided by RyzenAPI
-- Game: Love Battle Spirit

-- MAIN APPLICATION
addappid(3630910)
-- Game: addappid(3630910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3630911, 1, "70d0bc1d4dfc25ab6128d72e18be8bc1056795bc59044fd9303b4f53752fe760")
