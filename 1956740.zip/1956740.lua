-- Lua provided by RyzenAPI
-- Game: Game: Argentum Online

-- MAIN APPLICATION
addappid(1956740)
-- Game: addappid(1956740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956741, 1, "3c35220723f93f124d644ef432bf32f526ff0d9a93d0fee435ec78b16f183c0a")
