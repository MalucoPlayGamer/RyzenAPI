-- Lua provided by RyzenAPI 
-- Game: Don't Die, Mr. Robot! DX
addappid(2051450)
addappid(2051451, 1, "6fc74e090f608078ae9def246dd95d6b367070b2d84cf7fd37c280c7342d5dd9")
