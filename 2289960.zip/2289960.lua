-- Lua provided by RyzenAPI
-- Game: My Neighbor's Lonely Wife

-- MAIN APPLICATION
addappid(2289960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289962,0,"e2ddb108c0a33c8823e839eafc833e2b3487cb6d7bcd20326eaa33ddaa34f44d")
addappid(2289963,0,"fc99af3364f584383e98581fd8d2a9b123a5f42159490fc4e0181e5a5c4928b9")
addappid(2289964,0,"c70f051cc075be70f741e65caef8e30eab32e7f60fca6238e8335301c27aa37c")
