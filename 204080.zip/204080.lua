-- Lua provided by RyzenAPI
-- Game: 204080

-- MAIN APPLICATION
addappid(204080)
-- Game: addappid(204080)

-- MAIN APP DEPOTS / PACKAGES
addappid(204081, 1, "826caae9acaf9528f2a9ce8cab4c2fdd608958b75aaf7932747453c3d7cb4803")
addappid(204082, 1, "2581901c5be862161dee557f38ced6d6597ac565d48983bc533b34633e361d03")
addappid(204083, 1, "193e21e18bcc4098f78b813e2bf88fd5b4f2a96c9ef34aef64237756b00c7c2a")
addappid(204084, 1, "66cf17bb05ddfac9bac4861fbb3cfbea65923027b43de3fba07fa5cebf50ef83")
