-- Lua provided by RyzenAPI
-- Game: Game: Insect Swarm

-- MAIN APPLICATION
addappid(1999170)
-- Game: addappid(1999170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999171, 1, "8d5d54d3808c114890cf28842250d34bc14ba31635fdb2a71f983149e3d9daed")
