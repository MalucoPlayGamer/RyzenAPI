-- Lua provided by RyzenAPI
-- Game: 1377350

-- MAIN APPLICATION
addappid(1377350)
-- Game: addappid(1377350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377351, 1, "dcc9d7220706adf4131113681e3436e74fa8f6b0b6b8e1572ba82b488cd25b58")
