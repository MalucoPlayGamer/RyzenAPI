-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 24: Deserted Island

-- MAIN APPLICATION
addappid(797340)

-- MAIN APP DEPOTS / PACKAGES
addappid(797341,0,"deac55d58b1d79d485a89932072b2bba29663c8c6e8dd17ad8432e1a40edb38a")

