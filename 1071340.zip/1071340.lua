-- Lua provided by RyzenAPI
-- Game: 1071340

-- MAIN APPLICATION
addappid(1071340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071340,0,"85b44a902c31717d72802aaa868fbbdac5fae62a10c086d7afb2da1c1bb9536c")
addappid(2523040,0,"54ce0bade07bea55f407c3cc957ecb86cd59eeaf214487e194274fc952b383aa")

