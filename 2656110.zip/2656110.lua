-- Lua provided by RyzenAPI
-- Game: Sweet Dreams Demo

-- MAIN APPLICATION
addappid(2656110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656111, 1, "20d6ba6fc4a7c3ad03297d21be4e30e2ed480b30126db0010f8e78b3102bd27b")
