-- Lua provided by RyzenAPI
-- Game: 1820040

-- MAIN APPLICATION
addappid(1820040)
-- Game: addappid(1820040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820041, 1, "91ac9e8688f7cae6d95738810c99351ad9bd4bf9b17bd76db9ad534c6e84f1f6")
