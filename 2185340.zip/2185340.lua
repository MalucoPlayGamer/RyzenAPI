-- Lua provided by RyzenAPI 
-- Game: Raiden IV x MIKADO remix Soundtrack
addappid(2185340)
addappid(2185341, 1, "e09431d789178215a3917304933ea2cb411008bd4ca7b6eab4b61a245c54e56d")
addappid(2185342, 1, "efba33cc096e30d58c13f30b10c476b7f54591721489c41b021fb2ed24a5ab7d")
