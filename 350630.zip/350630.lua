-- Lua provided by RyzenAPI
-- Game: Dodge

-- MAIN APPLICATION
addappid(350630)
-- Game: addappid(350630)

-- MAIN APP DEPOTS / PACKAGES
addappid(350631, 1, "6c556a13717859476359071e8600747d0e132f451a04fc38dd56cb36355bf2cc")
