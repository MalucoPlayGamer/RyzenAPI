-- Lua provided by RyzenAPI
-- Game: Bomb Vehicle Idle Clicker

-- MAIN APPLICATION
addappid(3376850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376851, 1, "f57959fbb03f93d0003e5886f276d1219007b5c309804b7513cf6bcf1fe9a928")
