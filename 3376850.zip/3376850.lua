-- Lua provided by SkyAPI 
-- Game: Bomb Vehicle Idle Clicker
addappid(3376850)
addappid(3376851, 1, "f57959fbb03f93d0003e5886f276d1219007b5c309804b7513cf6bcf1fe9a928")
