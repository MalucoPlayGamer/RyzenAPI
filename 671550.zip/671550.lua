-- Lua provided by RyzenAPI
-- Game: Brickochet

-- MAIN APPLICATION
addappid(671550)
-- Game: addappid(671550)

-- MAIN APP DEPOTS / PACKAGES
addappid(671551, 1, "5c5c775bba6e454d7e74100eec7fbabe8c0b23ab5023ceb97cde6e14e04ae9f2")
