-- Lua provided by RyzenAPI
-- Game: Rose and Locket Demo

-- MAIN APPLICATION
addappid(2867750)
-- Game: addappid(2867750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867751, 1, "51e485b1728ea7569ae54837be27245624f51e8a97f0db33e7fcec3f466a0b83")
