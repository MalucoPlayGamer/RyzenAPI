-- 2859080's Lua and Manifest Created by Hubcap Manifest
-- John Fox
-- Created: August 12, 2026 at 00:02:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2859080) -- John Fox
-- MAIN APP DEPOTS
addappid(2859081, 1, "37f2c2c4b5a9009f72d531bfdbcd2df0efa6916c545187c0b7ff7e77a471fe65") -- Depot 2859081
setManifestid(2859081, "998095676215523295", 287673631)