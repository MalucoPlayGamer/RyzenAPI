-- Lua provided by RyzenAPI
-- Game: John Fox

-- MAIN APPLICATION
addappid(2859080) -- John Fox

-- MAIN APP DEPOTS / PACKAGES
addappid(2859081, 1, "37f2c2c4b5a9009f72d531bfdbcd2df0efa6916c545187c0b7ff7e77a471fe65") -- Depot 2859081

