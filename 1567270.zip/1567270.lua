-- Lua provided by RyzenAPI
-- Game: Castle survival

-- MAIN APPLICATION
addappid(1567270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567271, 1, "04b73df15cda2ce603003ee4bcfedee16adff901734f489c7d76f820db5ff439")
