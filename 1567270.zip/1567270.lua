-- Lua provided by SkyAPI 
-- Game: Castle survival
addappid(1567270)
addappid(1567271, 1, "04b73df15cda2ce603003ee4bcfedee16adff901734f489c7d76f820db5ff439")
