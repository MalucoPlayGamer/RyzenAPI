-- Lua provided by RyzenAPI
-- Game: Tesla Effect: A Tex Murphy Adventure

-- MAIN APPLICATION
addappid(261510)
addappid(282580)

-- MAIN APP DEPOTS / PACKAGES
addappid(261511, 1, "abb4579715c9005e38e932be1dcee1d89cd2b01f201acd33d5c9c5ddd418265e")
addappid(261512, 1, "a4dff91953a696473d211e6cf4afdb34eb42ac69fd59defc4f40a1ab288a2f2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
