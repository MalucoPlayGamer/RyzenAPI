-- 3478560's Lua and Manifest Created by Hubcap Manifest
-- Void Future: Hacking Protocol
-- Created: July 24, 2026 at 05:34:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3478560) -- Void Future: Hacking Protocol
-- MAIN APP DEPOTS
addappid(3478561, 1, "c8c5bac978b02a2a7cd53026e61ce05235386e97edba8fe7b9509b2f30de6847") -- Depot 3478561
setManifestid(3478561, "8157280687038637033", 17450910603)