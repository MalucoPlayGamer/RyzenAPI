-- Lua provided by SkyAPI 
-- Game: 弹幕那个恶人
addappid(1043470)
addappid(1043471, 1, "95a0e6bec423fd9983fcdf6e93af074deb0a0b381b03b398d29e63539043fd1c")
