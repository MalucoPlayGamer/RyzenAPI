-- Lua provided by RyzenAPI
-- Game: Hotel: A Resort Simulator

-- MAIN APPLICATION
addappid(1389840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389841, 1, "051626a94b7064d28641e7412ff77276775859f51ef58dd28e5a658974303f56")
addappid(1898280, 0, "fe5fff7726674cad821d6d6b3e82071f49cf50f4c8d724f4bec17994fa5f2b38")
addappid(1898281, 0, "59f4173633a8404e8721fadc5deeba32732fd32c178899b7ad912b077f9df9de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
