-- Lua provided by SkyAPI 
-- Game: Hotel: A Resort Simulator
addappid(1389840)
addappid(1389841, 1, "051626a94b7064d28641e7412ff77276775859f51ef58dd28e5a658974303f56")
addappid(1898280, 0, "fe5fff7726674cad821d6d6b3e82071f49cf50f4c8d724f4bec17994fa5f2b38")
addappid(1898281, 0, "59f4173633a8404e8721fadc5deeba32732fd32c178899b7ad912b077f9df9de")
