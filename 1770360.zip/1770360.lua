-- Lua provided by RyzenAPI
-- Game: Desert Magic Adventures

-- MAIN APPLICATION
addappid(1770360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770361, 1, "a34508976268f5cb51e1643cb417cb900753e904228c98b609246ed10228a9bd")

