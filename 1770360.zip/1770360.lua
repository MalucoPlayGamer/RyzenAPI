-- Lua provided by SkyAPI 
-- Game: Desert Magic Adventures
addappid(1770360)
addappid(1770361, 1, "a34508976268f5cb51e1643cb417cb900753e904228c98b609246ed10228a9bd")
