-- Lua provided by RyzenAPI
-- Game: addappid(38750)

-- MAIN APPLICATION
addappid(38750)

-- MAIN APP DEPOTS / PACKAGES
addappid(38751, 1, "afcc86f02928f14ee2a65e9cfd2e4f5eec3806ee05d4df282c35b1f929c10c2c")
