-- Lua provided by RyzenAPI
-- Game: Soulash 2 Demo

-- MAIN APPLICATION
addappid(2590260)
-- Game: addappid(2590260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590261, 1, "200813b35c1c7b169d2a936249156e33965b4f25580ce1602eccdd15950581e6")
