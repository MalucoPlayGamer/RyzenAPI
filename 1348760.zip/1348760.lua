-- Lua provided by RyzenAPI
-- Game: KARM

-- MAIN APPLICATION
addappid(1348760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348761, 1, "02705aa34e15260e64bd52fb3f11cbe8b4b95b00bed58ef1aacc76434be37f56")

