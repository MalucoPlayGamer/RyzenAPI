-- Lua provided by RyzenAPI
-- Game: KARM

-- MAIN APPLICATION
addappid(1348760)
addappid(3018540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1348761, 1, "02705aa34e15260e64bd52fb3f11cbe8b4b95b00bed58ef1aacc76434be37f56")

