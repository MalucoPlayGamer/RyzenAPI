-- Lua provided by RyzenAPI
-- Game: Football Agent

-- MAIN APPLICATION
addappid(4860970) -- Football Agent

-- MAIN APP DEPOTS / PACKAGES
addappid(4860971, 1, "2f17ce11cc0d6a4c944167848de020bce13aaea5fbb7ee7ed3bab80cb62f17fe") -- Depot 4860971

