-- 4860970's Lua and Manifest Created by Hubcap Manifest
-- Football Agent
-- Created: August 25, 2026 at 13:26:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4860970) -- Football Agent
-- MAIN APP DEPOTS
addappid(4860971, 1, "2f17ce11cc0d6a4c944167848de020bce13aaea5fbb7ee7ed3bab80cb62f17fe") -- Depot 4860971
setManifestid(4860971, "3634495011233310889", 407061405)