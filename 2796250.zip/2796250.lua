-- 2796250's Lua and Manifest Created by Hubcap Manifest
-- Beware the Depths
-- Created: August 27, 2026 at 10:28:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2796250) -- Beware the Depths
-- MAIN APP DEPOTS
addappid(2796251, 1, "bd53e554dc01426705a841b545adcb1fbd1e0480bad9ced4b87dc597bfe8a41f") -- Depot 2796251
setManifestid(2796251, "8113142530439730019", 2812830776)