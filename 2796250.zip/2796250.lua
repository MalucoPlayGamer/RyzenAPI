-- Lua provided by RyzenAPI
-- Game: Beware the Depths

-- MAIN APPLICATION
addappid(2796250) -- Beware the Depths

-- MAIN APP DEPOTS / PACKAGES
addappid(2796251, 1, "bd53e554dc01426705a841b545adcb1fbd1e0480bad9ced4b87dc597bfe8a41f") -- Depot 2796251

