-- 4292860's Lua and Manifest Created by Hubcap Manifest
-- RigidGems Museum
-- Created: July 23, 2026 at 02:19:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4292860) -- RigidGems Museum
-- MAIN APP DEPOTS
addappid(4292861, 1, "b7d9ba849bae7ba616bff99ca639be28ccfd1e7e81e92512b2b2226167abb157") -- Depot 4292861
setManifestid(4292861, "8829164851930238423", 387059250)