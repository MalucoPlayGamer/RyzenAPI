-- Lua provided by RyzenAPI
-- Game: 缚戎人：唐建中十三年 Demo

-- MAIN APPLICATION
addappid(3475280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3475281, 1, "7ca569fd6d5fd502c9643e5bbba6d5a252635d062a1a9e7ba91e932628d1bb00")

