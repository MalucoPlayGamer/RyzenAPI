-- Lua provided by SkyAPI 
-- Game: AppID 3475280
addappid(3475280)
addappid(3475281, 1, "7ca569fd6d5fd502c9643e5bbba6d5a252635d062a1a9e7ba91e932628d1bb00")
