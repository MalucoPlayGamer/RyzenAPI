-- Lua provided by RyzenAPI
-- Game: Game: AppID 588030

-- MAIN APPLICATION
addappid(588030)
-- Game: addappid(588030)

-- MAIN APP DEPOTS / PACKAGES
addappid(588031, 1, "8f86e8547e0ff976ae25b0485d10a772f80b80edd6a0223e81425d8b69917c21")
addappid(588032, 1, "7d1ed980030644def80ae52ff407d02bfeaa9c7c413476ed331ee05730fbb10f")
