-- Lua provided by RyzenAPI
-- Game: Lets Beats

-- MAIN APPLICATION
addappid(880610)

-- MAIN APP DEPOTS / PACKAGES
addappid(880611,0,"083ecaeb3eadc08c04293d9b95518452c1a3e068843f1544fc302870fab79a4d")

