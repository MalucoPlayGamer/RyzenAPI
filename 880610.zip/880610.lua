-- Lua provided by RyzenAPI
-- Game: Lets Beats

-- MAIN APPLICATION
addappid(880610)

-- MAIN APP DEPOTS / PACKAGES
addappid(880611,0,"083ecaeb3eadc08c04293d9b95518452c1a3e068843f1544fc302870fab79a4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
