-- Lua provided by RyzenAPI
-- Game: Sudoku Killer

-- MAIN APPLICATION
addappid(861270)

-- MAIN APP DEPOTS / PACKAGES
addappid(861271, 1, "d498b0555c02e3ba0c9747c61210e8cb63a9de50ff2c9ab783edadd012cb879f")
