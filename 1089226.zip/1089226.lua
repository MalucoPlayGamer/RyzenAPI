-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Easy Pull-off Exercise 2

-- MAIN APPLICATION
addappid(1089226)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089226,0,"fa7746a1a35ef017b67fb69be46f13b31c57fe408f436386726bc6c7774e2146")

