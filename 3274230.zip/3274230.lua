-- Lua provided by RyzenAPI
-- Game: Beat Saber - Monstercat Mixtape 2 - F.O.O.L & Power Glove - "Mercenary"

-- MAIN APPLICATION
addappid(3274230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274230,0,"0f02f0e8f0c801ab9b889fed079561c1e8822f0bb32deb602283d97a82a905d9")

