-- Lua provided by RyzenAPI
-- Game: 327010

-- MAIN APPLICATION
addappid(327010)
-- Game: addappid(327010)

-- MAIN APP DEPOTS / PACKAGES
addappid(327011, 1, "6146ca66d0c5c35fcd9ef67313e5db1be0181889fc05589b1f363340849ba46f")
