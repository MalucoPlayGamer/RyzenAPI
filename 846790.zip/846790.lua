-- Lua provided by RyzenAPI
-- Game: Game: AppID 846790

-- MAIN APPLICATION
addappid(846790)
-- Game: addappid(846790)

-- MAIN APP DEPOTS / PACKAGES
addappid(846791, 1, "661e36418b9a5cdb06b0f00ac20c1b5acb6611b8b4e9618236669b8930ce6c4f")
