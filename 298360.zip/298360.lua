-- Lua provided by RyzenAPI
-- Game: Game: Immortal Defense

-- MAIN APPLICATION
addappid(298360)
-- Game: addappid(298360)

-- MAIN APP DEPOTS / PACKAGES
addappid(298361, 1, "a84d3e9b124919c84643320e2468ad0835ea1b13ace25ac67fcace9b1a481ec4")
