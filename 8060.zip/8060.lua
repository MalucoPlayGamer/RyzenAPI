-- Lua provided by RyzenAPI
-- Game: AppID 8060

-- MAIN APPLICATION
addappid(8060)

-- MAIN APP DEPOTS / PACKAGES
addappid(8061, 1, "b8daadb928048fecf04f5012cb093a50e20ecfd2f1d1507281f8318b3169347a")
addappid(8062, 1, "a6a8d72a68d1fcbd3c6de97e4ade417d3de1beecdb8d0aa826708297a92cdcdd")
