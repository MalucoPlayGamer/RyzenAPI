-- Lua provided by RyzenAPI
-- Game: Game: A Sketchbook About Her Sun

-- MAIN APPLICATION
addappid(1611760)
-- Game: addappid(1611760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611761, 1, "f9dabd68c55bded3ea4f84645c65fcd9d75d4f2926984935c21e84202150a67f")
