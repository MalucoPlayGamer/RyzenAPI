-- Lua provided by RyzenAPI
-- Game: AppID 987800

-- MAIN APPLICATION
addappid(987800)
-- Game: addappid(987800)

-- MAIN APP DEPOTS / PACKAGES
addappid(987801, 1, "0814360d6cb83d42c183a8e511998ab3cd8d868ace5e43e1a296c91dfc5c7885")
