-- Lua provided by RyzenAPI
-- Game: SANCTION

-- MAIN APPLICATION
addappid(1191080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191081, 1, "8a8d04b9e18ea83016acebd8dd8cdd0b60d75c8f6e2ff1616f8ea41c13f2107b")
