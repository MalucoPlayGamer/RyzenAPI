-- Lua provided by RyzenAPI
-- Game: SANCTION

-- MAIN APPLICATION
addappid(1191080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191081, 1, "8a8d04b9e18ea83016acebd8dd8cdd0b60d75c8f6e2ff1616f8ea41c13f2107b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
