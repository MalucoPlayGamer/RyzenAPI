-- Lua provided by RyzenAPI
-- Game: Game: AstraX

-- MAIN APPLICATION
addappid(1990790)
-- Game: addappid(1990790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990791, 1, "b15b6f7c9a1cc3ded9088ae4859165fb22d2b487f8fa67774833db899109047b")
