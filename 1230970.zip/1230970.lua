-- Lua provided by RyzenAPI
-- Game: addappid(1230970)

-- MAIN APPLICATION
addappid(1230970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230970,0,"9df9d2fa60d70f8a55e93d1a223c944cd386089c7b05f9dcff0d7142233a9423")
