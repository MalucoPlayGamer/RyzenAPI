-- Lua provided by RyzenAPI
-- Game: addappid(16060)

-- MAIN APPLICATION
addappid(16060)

-- MAIN APP DEPOTS / PACKAGES
addappid(16061, 1, "3cbf3eff98f6cdb07a379f0b93183df6311cdbdc351d56b4fb9e7aa2b3a9cdd5")
