-- Lua provided by RyzenAPI 
-- Game: Samantha Swift and the Golden Touch
addappid(16060)
addappid(16061, 1, "3cbf3eff98f6cdb07a379f0b93183df6311cdbdc351d56b4fb9e7aa2b3a9cdd5")
