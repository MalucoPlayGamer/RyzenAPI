-- Lua provided by RyzenAPI 
-- Game: Mahjong House: Challenge All Achievements
addappid(3762280)
addappid(3762281, 1, "57d684ba87b425cf20b38b09ebd0315a1266db36825fa122a4077775f5c758d5")
