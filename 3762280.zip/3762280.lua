-- Lua provided by RyzenAPI
-- Game: Game: Mahjong House: Challenge All Achievements

-- MAIN APPLICATION
addappid(3762280)
-- Game: addappid(3762280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3762281, 1, "57d684ba87b425cf20b38b09ebd0315a1266db36825fa122a4077775f5c758d5")
