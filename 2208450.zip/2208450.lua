-- Lua provided by RyzenAPI
-- Game: Atelier Marie Remake: The Alchemist of Salburg Digital Deluxe Upgrade Pack

-- MAIN APPLICATION
addappid(2208450)
-- Game: addappid(2208450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208450,0,"5fc1ba0661996fc11482796740067dab5888c518f2f042604b2f188cbad04cbb")
