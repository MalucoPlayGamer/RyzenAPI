-- Lua provided by RyzenAPI
-- Game: Game: Drift Showcase

-- MAIN APPLICATION
addappid(1636400)
-- Game: addappid(1636400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636401, 1, "67a8334551aae15f06f40529b8dda03b700867382f114521677dfa09d32843d3")
