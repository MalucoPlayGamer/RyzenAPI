-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 - BGM Pack 2

-- MAIN APPLICATION
addappid(933573)
-- Game: addappid(933573)

-- MAIN APP DEPOTS / PACKAGES
addappid(933573,0,"900d5fcd3b00e9697e1736f699d7321af19449c147babeb77deb4abc496e3d52")
