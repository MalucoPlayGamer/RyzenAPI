-- Lua provided by RyzenAPI
-- Game: PAGUI

-- MAIN APPLICATION
addappid(986680)
addappid(3547950)
addappid(3678680)
addappid(3969840)
addappid(3970000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(986681,0,"5c358ba3611cd58fa952e06591c5397863d0d564b8c9b7a9a148a03828a4c4c4")
addappid(986683,0,"9bfbcefc41402f974a02be75250e82aa0cf42a024433ef5ceffb182a9077b0a7")

