-- Lua provided by RyzenAPI 
-- Game: PAGUI打鬼
addappid(986680)
addappid(986681, 1, "5c358ba3611cd58fa952e06591c5397863d0d564b8c9b7a9a148a03828a4c4c4")
addappid(986683, 1, "9bfbcefc41402f974a02be75250e82aa0cf42a024433ef5ceffb182a9077b0a7")
