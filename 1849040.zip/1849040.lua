-- Lua provided by RyzenAPI
-- Game: addappid(1849040)

-- MAIN APPLICATION
addappid(1849040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849041, 1, "ec93e72c7542f9680c6fcad34e4be71ab59e1c3bbfa4915ac9447219f8418566")
addappid(1849042, 1, "497dfef786ea7840e4bf8136672945dba4d3296c4e740c1beebd1ea612bff0d1")
