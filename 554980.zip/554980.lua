-- Lua provided by RyzenAPI
-- Game: LolliPop: The Best Indie Game

-- MAIN APPLICATION
addappid(554980)

-- MAIN APP DEPOTS / PACKAGES
addappid(554982,0,"cb0e4cb0ec514d2bb6af780c24f48e946aedd3d5cfdf0470a448ce6c094f9b90")

