-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Piano Battle and Fantasy Music Pack

-- MAIN APPLICATION
addappid(3119100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119100,0,"aaa0f951da405025d6ea84cfb62c773b8fefe0956a32f43b4572886b20b355cc")

