-- Lua provided by RyzenAPI
-- Game: Royal Revolt II

-- MAIN APPLICATION
addappid(1571190)
