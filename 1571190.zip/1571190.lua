-- Lua provided by RyzenAPI
-- Game: Royal Revolt II

-- MAIN APPLICATION
addappid(1571190)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
