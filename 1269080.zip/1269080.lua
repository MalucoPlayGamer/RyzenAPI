-- Lua provided by RyzenAPI 
-- Game: ALIVE
addappid(1269080)
addappid(1269081, 1, "17d03d0b80dab583dfe9a49c4fc0e79ec3454cd346ba6c6d6f9980ee543dd6df")
