-- Lua provided by RyzenAPI
-- Game: ALIVE

-- MAIN APPLICATION
addappid(1269080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1269081, 1, "17d03d0b80dab583dfe9a49c4fc0e79ec3454cd346ba6c6d6f9980ee543dd6df")

