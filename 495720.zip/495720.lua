-- Lua provided by RyzenAPI 
-- Game: Intrude
addappid(495720)
addappid(495721, 1, "9eac9de6a93c1cb1e585967431e554fb641ff09d61fb39b880b3505e1c19f153")
addappid(510310, 0, "ff36814c069ccabe3064e5a2cf9b06119bbf5f02f7094554ef04efd8a1954cfc")
