-- Lua provided by SkyAPI 
-- Game: OPUS: Echo of Starsong Complete Soundtrack -Vol.1-
addappid(1838320)
addappid(1838321, 1, "82d7d0c63909050f3052436bf839a91b3c677c9ad7fe28c48941cff352c76b2e")
addappid(1838322, 1, "b79b0d685eb1f441f3bfb6b6b5521acb7c565b320a93878e6913e2d97cff24d2")
