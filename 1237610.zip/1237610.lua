-- Lua provided by RyzenAPI 
-- Game: The Catch: Carp & Coarse Fishing
addappid(1237610)
addappid(1237611, 1, "8370fb42f03fbdf42876ca7fc785e7fb335451dfc9b8523d99c7aebec51c17f1")
addappid(1351270, 0, "56b4b370f435a1a1d29cd2e154ab7019e44c056a710d5ea39c14217ae09b92dc")
addappid(1351271, 0, "fd34d2633b7f037d44262c1b084a34d15637951367ef8acbbb4b72ae4d51db94")
