-- Lua provided by RyzenAPI
-- Game: addappid(1511620)

-- MAIN APPLICATION
addappid(1511620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511621, 1, "5ccfe13cdced86fba45be2643b2a658531e722fde1ec19e72334d237201958ef")
