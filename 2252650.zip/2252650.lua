-- Lua provided by RyzenAPI
-- Game: Stick figure fight

-- MAIN APPLICATION
addappid(2252650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252651, 1, "53467ebd09cb57d6004db7cb3d087941d946f60e0a1e8abbd18083fdb90e3c20")

