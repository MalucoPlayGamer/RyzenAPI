-- Lua provided by RyzenAPI
-- Game: AppID 723270

-- MAIN APPLICATION
addappid(723270)
-- Game: addappid(723270)

-- MAIN APP DEPOTS / PACKAGES
addappid(723271, 1, "6c34c4e27b79d4232fb3791be14f28c532e42915807e966e892b9224b5c8e54b")
