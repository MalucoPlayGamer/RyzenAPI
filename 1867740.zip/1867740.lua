-- Lua provided by RyzenAPI 
-- Game: Like Dreamer
addappid(1867740)
addappid(1867741, 1, "a4f4f3d8267f72581b0c891b9787cbf8899863a1a38e923fca62697f05fa63f3")
