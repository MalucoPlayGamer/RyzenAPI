-- Lua provided by RyzenAPI
-- Game: 31160

-- MAIN APPLICATION
addappid(31160)
-- Game: addappid(31160)

-- MAIN APP DEPOTS / PACKAGES
addappid(31161, 1, "e892763fa34dd78927f6fd1f8cb43bdcf7e8ed9c9641a865b900602c59ec2a3b")
