-- Lua provided by RyzenAPI
-- Game: Zombie Playground™

-- MAIN APPLICATION
addappid(215550)
addappid(228986)
addappid(228990)
addappid(574750)

-- MAIN APP DEPOTS / PACKAGES
addappid(215552,0,"eee671491477388046e15de9eae025da9129055af442f2e76c9f4cf0e3ac9f04")
addappid(215554,0,"f7bfdbf15d515c1b8e79956582981e2fab3d77a6a507a910aeb2e5ff875a322c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(413570)
addappid(529120)
addappid(542440)
addappid(570610)
addappid(570611)
addappid(570612)
addappid(570613)
addappid(570614)
addappid(570615)
addappid(570616)
addappid(570617)
addappid(570619)
addappid(570651)
addappid(570652)
addappid(570653)
addappid(570654)
addappid(570655)
addappid(573140)
addappid(680840)
addappid(730900)
addappid(730901)
addappid(730902)
addappid(730903)
addappid(730904)
addappid(730905)
addappid(730960)
addappid(734460)
addappid(734461)
addappid(734462)
