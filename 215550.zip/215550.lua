-- Lua provided by RyzenAPI
-- Game: Zombie Playground™

-- MAIN APPLICATION
addappid(215550)
addappid(228986)
addappid(228990)
addappid(574750)

-- MAIN APP DEPOTS / PACKAGES
addappid(215552,0,"eee671491477388046e15de9eae025da9129055af442f2e76c9f4cf0e3ac9f04")
addappid(215554,0,"f7bfdbf15d515c1b8e79956582981e2fab3d77a6a507a910aeb2e5ff875a322c")

