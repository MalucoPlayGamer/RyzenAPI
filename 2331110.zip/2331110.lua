-- Lua provided by RyzenAPI
-- Game: addappid(2331110)

-- MAIN APPLICATION
addappid(2331110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331111, 1, "c6ac7165d43ce2aab20dd01d60831a282393e885f2f30ce374508ca9fd24c32c")
addappid(2331112, 1, "618af0e6e96eb5f50f4eaee9711b10ebfe089dfc7c57480421d4dd1565635f30")
