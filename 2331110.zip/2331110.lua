-- Lua provided by RyzenAPI
-- Game: No Crime

-- MAIN APPLICATION
addappid(2331110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331111, 1, "c6ac7165d43ce2aab20dd01d60831a282393e885f2f30ce374508ca9fd24c32c")
addappid(2331112, 1, "618af0e6e96eb5f50f4eaee9711b10ebfe089dfc7c57480421d4dd1565635f30")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
