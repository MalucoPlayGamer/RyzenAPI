-- Lua provided by RyzenAPI
-- Game: hololive Dreams

-- MAIN APPLICATION
addappid(4282500)

-- MAIN APP DEPOTS / PACKAGES
addappid(4282502, 1, "92d4f32ebd56e0c9482c3d6e94280f98462a73ff1fc1735316f91da88fcb335e")

