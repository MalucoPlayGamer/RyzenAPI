-- Lua provided by RyzenAPI
-- Game: Ouroboros: Prelude

-- MAIN APPLICATION
addappid(593730)

-- MAIN APP DEPOTS / PACKAGES
addappid(593731,0,"5e5d59cb3fab253cd7e72a58cc5a7d3fb84db73d77fdba774db671ddcc2c93b8")

