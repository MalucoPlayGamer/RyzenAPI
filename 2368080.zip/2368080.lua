-- Lua provided by RyzenAPI
-- Game: 2368080

-- MAIN APPLICATION
addappid(2368080)
-- Game: addappid(2368080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368081, 1, "e111e0c5c3c5f840e48693fbf5d67dc433ccf0fce478bee4fe200a39b58ced6c")
