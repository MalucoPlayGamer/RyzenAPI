-- Lua provided by RyzenAPI
-- Game: Reagan Gorbachev

-- MAIN APPLICATION
addappid(364720)

-- MAIN APP DEPOTS / PACKAGES
addappid(364721, 1, "33bf5b5313f3eefc2765be0273fa63e1b6a5a1d771963fae9724305815ad8210")
