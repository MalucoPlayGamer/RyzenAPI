-- Lua provided by RyzenAPI
-- Game: AppID 2913950

-- MAIN APPLICATION
addappid(2913950)
-- Game: addappid(2913950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913951, 1, "1eb62801d8dd3cb00c576a38d2041543424fede1108994ca9494a7e3448adf02")
