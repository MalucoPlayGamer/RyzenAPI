-- Lua provided by RyzenAPI 
-- Game: Cauldrons of War - Barbarossa
addappid(1265220)
addappid(1265221, 1, "41ad69b94233b9254121a76de21909d0a3e792edfef4449871585f45a3f345e0")
