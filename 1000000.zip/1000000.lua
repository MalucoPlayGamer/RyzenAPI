-- Lua provided by RyzenAPI
-- Game: Game: ASCENXION

-- MAIN APPLICATION
addappid(1000000)
-- Game: addappid(1000000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000001, 1, "984d422430d16407c464971a4ebd6d8c443c0f120a5565c79bbf43a0a8e74b89")
