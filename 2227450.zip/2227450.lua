-- Lua provided by RyzenAPI
-- Game: Game: Oyabu Clinic Deathcare Corporation

-- MAIN APPLICATION
addappid(2227450)
-- Game: addappid(2227450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227451, 1, "b79db1bab4e12427dc0128eb95cbeb44229d4e5606dcd6a9a718f08db46b88e9")
addappid(2227452, 1, "22da27b7a7088df27c8d344b7312974d8408401acb6aafa167db5fad0a0d7590")
addappid(2227453, 1, "d1a1906508b93b1f71707fc5e536505b063b7281296ee6677ea7f76c74bcb61a")
addappid(2227454, 1, "60d60c36e6080d6c1e1cb6e9112c9681c7c8b0dfe967f742104dc2f18a0d787a")
