-- Lua provided by RyzenAPI
-- Game: Winning Post 9 2022 体験版

-- MAIN APPLICATION
addappid(1832610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832611, 1, "cf02b83bf579d89b7ee97ad6fbc2ca9092a35cfd8bf85faff025544ee2217257")

