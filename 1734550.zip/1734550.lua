-- Lua provided by RyzenAPI
-- Game: 1734550

-- MAIN APPLICATION
addappid(1734550)
addappid(1734551)
addappid(1734552)
addappid(1734554)
-- Game: addappid(1734550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734553,0,"733404fbc4c16773081ed4a7167fe96b9d4817acd217a74ff71a7fbeb148cc2b")
addtoken(1734550,10802368606799062100)
