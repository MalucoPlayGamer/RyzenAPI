-- Lua provided by RyzenAPI 
-- Game: Domino Sky
addappid(457480)
addappid(457481, 1, "6b23fd390527877d95591a0ec2eccabc2bd3cdd0ff1fc87e646ad701d5846412")
addappid(457482, 1, "6887cb32d52e2c8808be845c6ee246de01108b33a31aedd46d3b4f38ef295555")
