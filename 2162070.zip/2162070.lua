-- Lua provided by RyzenAPI
-- Game: Game: Ooglians

-- MAIN APPLICATION
addappid(2162070)
-- Game: addappid(2162070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162071, 1, "9741a6f5e0272af38e705adddcd622593b7489a7a51c0f9b137fb38cbb111625")
