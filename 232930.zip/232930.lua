-- Lua provided by RyzenAPI
-- Game: AppID 232930

-- MAIN APPLICATION
addappid(232930)

-- MAIN APP DEPOTS / PACKAGES
addappid(232931, 1, "b316235f79d4a35d3b3337e99bf537e7da71a5ba2dac2edbfcbe1ebbc5146199")
