-- 4287100's Lua and Manifest Created by Hubcap Manifest
-- Rollin' Ravioli
-- Created: August 21, 2026 at 22:34:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4287100) -- Rollin' Ravioli
-- MAIN APP DEPOTS
addappid(4287101, 1, "2fada53544d9a074bd89e96578ec8d93ad0f05154c48b5ee576f3df15e2fcdf7") -- Depot 4287101
setManifestid(4287101, "1539753513349219087", 1273834924)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)