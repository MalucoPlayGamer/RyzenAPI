-- Lua provided by RyzenAPI
-- Game: 864810

-- MAIN APPLICATION
addappid(864810)
-- Game: addappid(864810)

-- MAIN APP DEPOTS / PACKAGES
addappid(864811, 1, "080ff15ab00d031a61845d3dd738a481ab3fbcd4a6154daa9c34d14dc99cbaab")
