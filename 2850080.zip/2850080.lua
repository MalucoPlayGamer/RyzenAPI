-- Lua provided by RyzenAPI
-- Game: Heads Will Roll: Reforged - Not a Hero

-- MAIN APPLICATION
addappid(2850080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850080,0,"e79ad69cab8dde1b709cffe60fffc9031966e1939847a039a16359ca70109903")

