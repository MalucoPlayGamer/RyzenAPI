-- Lua provided by RyzenAPI
-- Game: 2919800

-- MAIN APPLICATION
addappid(2919800)
-- Game: addappid(2919800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919800,0,"fa3143dba69440aff04ac707fcb37d47670ef05a082438b282063f6de7871b0c")
