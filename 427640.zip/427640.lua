-- Lua provided by RyzenAPI
-- Game: The Ables: Freepoint High

-- MAIN APPLICATION
addappid(427640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(427641, 1, "129b3ebb60a6042a87ae690b7f0d3baec4731c664a02f286de158ce33a933554")

