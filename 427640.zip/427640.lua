-- Lua provided by RyzenAPI
-- Game: 427640

-- MAIN APPLICATION
addappid(427640)
-- Game: addappid(427640)

-- MAIN APP DEPOTS / PACKAGES
addappid(427641, 1, "129b3ebb60a6042a87ae690b7f0d3baec4731c664a02f286de158ce33a933554")
