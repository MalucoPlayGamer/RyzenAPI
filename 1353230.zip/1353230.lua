-- Lua provided by RyzenAPI
-- Game: Bomb Rush Cyberfunk

-- MAIN APPLICATION
addappid(1353230)
addappid(2518220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353231, 1, "39e891398178eb462896935f7400ec32fb665213162d174d4b34d9b843519e66")

