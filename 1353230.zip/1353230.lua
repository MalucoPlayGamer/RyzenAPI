-- Lua provided by RyzenAPI 
-- Game: AppID 1353230
addappid(1353230)
addappid(1353231, 1, "39e891398178eb462896935f7400ec32fb665213162d174d4b34d9b843519e66")
