-- Lua provided by RyzenAPI
-- Game: Idle Sailor

-- MAIN APPLICATION
addappid(4090840) -- Idle Sailor
addappid(4107730) -- Idle Sailor Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4090841, 1, "046ded11969548e63a1e01b26ae7e3b0d2a7625a643d67ab8555070995175477") -- Depot 4090841
addappid(4090842, 1, "7d4c5ffde31193b4183534ee5b18d1065c5d469b37df46a58782c95c43ca0088") -- Depot 4090842

