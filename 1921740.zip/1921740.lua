-- Lua provided by RyzenAPI
-- Game: Game: CRAYON SHINCHAN The Storm Called! FLAMING KASUKABE RUNNER!!

-- MAIN APPLICATION
addappid(1921740)
-- Game: addappid(1921740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921741, 1, "d43c5fcd184de2fdb0d22451dd36e4506427bd61b16c65955daacdcff62150c0")
