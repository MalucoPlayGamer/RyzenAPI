-- Lua provided by RyzenAPI
-- Game: LandPort

-- MAIN APPLICATION
addappid(1956110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956111, 1, "1ed1e5c5a23cf1c43f04c1be9bfdd6644446c6c764112f71b41478f1ee56cc80")
addappid(1956112, 1, "17e404017a6424dbeeae7fa8d41ac710f6350082b3dfb00adf01c02a13e41aca")
addappid(1956113, 1, "ab7c9d14772c0cefc8052f25293a8295d68a261693ac7608a325083fdf8e62a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
