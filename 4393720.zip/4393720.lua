-- 4393720's Lua and Manifest Created by Hubcap Manifest
-- 放置恶魔
-- Created: August 05, 2026 at 13:23:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4393720) -- 放置恶魔
-- MAIN APP DEPOTS
addappid(4393721, 1, "f8d1855bcca626a07302e2a18754f3d9d8f50337c539868450b40842c6855e7e") -- Depot 4393721
setManifestid(4393721, "3454692452480006617", 258658444)