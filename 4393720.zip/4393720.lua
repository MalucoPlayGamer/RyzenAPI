-- Lua provided by RyzenAPI
-- Game: Created: August 05, 2026 at 13:23:52 EDT

-- MAIN APPLICATION
addappid(4393720) -- 放置恶魔

-- MAIN APP DEPOTS / PACKAGES
addappid(4393721, 1, "f8d1855bcca626a07302e2a18754f3d9d8f50337c539868450b40842c6855e7e") -- Depot 4393721

