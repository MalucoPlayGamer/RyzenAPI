-- Lua provided by RyzenAPI
-- Game: Game: AppID 49320

-- MAIN APPLICATION
addappid(49320)
-- Game: addappid(49320)

-- MAIN APP DEPOTS / PACKAGES
addappid(49321, 1, "c358cb0e5bcc16d50f77001dd344e9a4a3be31b2991f0285ddf81d663396b6a5")
addappid(49322, 1, "705c715dbcec789d570f6f65a4be8ee1b822471aa45169f4b08599387c89d366")
addappid(49323, 1, "baee2b10746617d0fa4c71ff503efafbcd52e5c078cf85b50531cf7e26a2a338")
addappid(49324, 1, "bca768bea218a82013758ced76650a80444aadbf96bd4f4a24199ce2dded543d")
addappid(49325, 1, "7735389943c3a9a1afdf7bcad8f35c673543483e744f13eaf336fb13a5d4bd7e")
