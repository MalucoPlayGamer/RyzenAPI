-- Lua provided by RyzenAPI
-- Game: Cataclysm: Dark Days Ahead

-- MAIN APPLICATION
addappid(2330750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330751, 1, "f941c429cb88c73862f83e0d50cc52f3cf2f9908760f3309801e95dec9d88944")
