-- Lua provided by RyzenAPI
-- Game: addappid(2622500)

-- MAIN APPLICATION
addappid(2622500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622501, 1, "6eb07d28ced61b0dace042d278762cbfe6bb65dff38815d6bac2813c57a4e252")
