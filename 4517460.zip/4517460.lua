-- Lua provided by RyzenAPI
-- Game: Total Football Online

-- MAIN APPLICATION
addappid(4517460)

