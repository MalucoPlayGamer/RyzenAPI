-- Lua provided by RyzenAPI
-- Game: BowmanVSZombies

-- MAIN APPLICATION
addappid(870740)

-- MAIN APP DEPOTS / PACKAGES
addappid(870741,0,"5af0149d9b0b334e3bcf3c3feff6e16b552c7d07636d77bed4850a9580e34072")

