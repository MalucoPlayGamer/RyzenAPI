-- Lua provided by RyzenAPI
-- Game: 2235820

-- MAIN APPLICATION
addappid(2235820)
-- Game: addappid(2235820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235821, 1, "b4a73f4c738b3a0a32d78d9516f456c00b0e940a3cf9d059aefd94e1589d0728")
