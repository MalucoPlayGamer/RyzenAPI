-- Lua provided by RyzenAPI
-- Game: Jack Holmes : Master of Puppets

-- MAIN APPLICATION
addappid(2235820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235821, 1, "b4a73f4c738b3a0a32d78d9516f456c00b0e940a3cf9d059aefd94e1589d0728")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
