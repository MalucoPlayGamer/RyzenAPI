-- Lua provided by SkyAPI 
-- Game: Jack Holmes : Master of Puppets
addappid(2235820)
addappid(2235821, 1, "b4a73f4c738b3a0a32d78d9516f456c00b0e940a3cf9d059aefd94e1589d0728")
