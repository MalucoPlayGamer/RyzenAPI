-- Lua provided by RyzenAPI
-- Game: Game: Dread X Collection 5

-- MAIN APPLICATION
addappid(1899810)
-- Game: addappid(1899810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899811, 1, "81a778e39285cd69b5bbf88b158a2cb36731b73a6ebfc4591fd77632bdff2843")
