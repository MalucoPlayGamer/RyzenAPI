-- Lua provided by RyzenAPI
-- Game: 告死天使之言 Death angel

-- MAIN APPLICATION
addappid(1124090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124091, 1, "7e575a5597c79b88f0bb77d910fe9e51710a42e2681a2c6367b74a8ddc3df4a1")
addappid(1124100, 1, "ea7b97828c787f3aaf1669d6b017adeabf6eed353522b990585327cfe98452dd")
