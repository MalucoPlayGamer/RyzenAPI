-- Lua provided by RyzenAPI
-- Game: AppID 262900

-- MAIN APPLICATION
addappid(262900)

-- MAIN APP DEPOTS / PACKAGES
addappid(262901, 1, "39ef2ead23e67e5ddf5ef747b0ad78bda1c41b93d8b3796905adcd40506f240d")
