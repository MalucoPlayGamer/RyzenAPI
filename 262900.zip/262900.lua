-- Lua provided by SkyAPI 
-- Game: AppID 262900
addappid(262900)
addappid(262901, 1, "39ef2ead23e67e5ddf5ef747b0ad78bda1c41b93d8b3796905adcd40506f240d")
