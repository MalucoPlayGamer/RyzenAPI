-- Lua provided by RyzenAPI
-- Game: RaiOhGar: Asuka and the King of Steel

-- MAIN APPLICATION
addappid(1163070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163071, 1, "c6b8ea914941f9a92bb8c05bfd39af683ee412188686db584235cde4b063e093")
addappid(1163072, 1, "11c8a9a90846c40df6f7137847ada3ab7e494486b944aec5c67934ee3943e026")
addappid(1163073, 1, "111dc8222b44952015be724ae47affc3b02434a95601440838e3f5576af7effe")
