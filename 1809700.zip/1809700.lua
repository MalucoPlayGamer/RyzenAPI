-- Lua provided by RyzenAPI
-- Game: Game: Persona 3 Portable

-- MAIN APPLICATION
addappid(1809700)
-- Game: addappid(1809700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809701, 1, "e677f23186a5ae4ebe6796b07212f513e806c73871d8ca39e79420bc7c5c7e3c")
