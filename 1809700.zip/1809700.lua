-- Lua provided by RyzenAPI
-- Game: Persona 3 Portable

-- MAIN APPLICATION
addappid(1809700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1809701, 1, "e677f23186a5ae4ebe6796b07212f513e806c73871d8ca39e79420bc7c5c7e3c")

