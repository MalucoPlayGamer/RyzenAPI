-- Lua provided by RyzenAPI
-- Game: 453730

-- MAIN APPLICATION
addappid(453730)
-- Game: addappid(453730)

-- MAIN APP DEPOTS / PACKAGES
addappid(453731, 1, "d7a6cc2779305df94b3e2fb9fd83fecef70bbedea0561589275c8732a439070e")
