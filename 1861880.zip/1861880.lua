-- Lua provided by RyzenAPI
-- Game: Air Traffic: Greenlight

-- MAIN APPLICATION
addappid(1861880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861881, 1, "dcd1681a7b335a37d70b6776e85874328a6f793ddd3f30c8c9850082922231c0")
