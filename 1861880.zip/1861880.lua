-- Lua provided by SkyAPI 
-- Game: Air Traffic: Greenlight
addappid(1861880)
addappid(1861881, 1, "dcd1681a7b335a37d70b6776e85874328a6f793ddd3f30c8c9850082922231c0")
