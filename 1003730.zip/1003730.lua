-- Lua provided by RyzenAPI
-- Game: Soko Loco Deluxe

-- MAIN APPLICATION
addappid(1003730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1003731, 1, "b305c2c281f88128b80e9bed426f14afb965120ccea1f5075ae1edf7a8b0acae")
addappid(1003732, 1, "154827f1a0449b00082e54d3205924d15de3f63280a82bd4075ab8dc0e85a68f")
