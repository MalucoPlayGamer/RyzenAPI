-- Lua provided by SkyAPI 
-- Game: AppID 1003730
addappid(1003730)
addappid(1003731, 1, "b305c2c281f88128b80e9bed426f14afb965120ccea1f5075ae1edf7a8b0acae")
addappid(1003732, 1, "154827f1a0449b00082e54d3205924d15de3f63280a82bd4075ab8dc0e85a68f")
