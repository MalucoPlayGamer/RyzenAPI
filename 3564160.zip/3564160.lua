-- Lua provided by RyzenAPI
-- Game: 3564160

-- MAIN APPLICATION
addappid(3564160)
-- Game: addappid(3564160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564160,0,"041034bd8eac8ca81ee32e8cc03adeb8f95e0c795587be2609f9f67608317f57")
