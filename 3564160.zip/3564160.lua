-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - MEGA FANTASY Walking Actors and Faces

-- MAIN APPLICATION
addappid(3564160)
-- Game: addappid(3564160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564160,0,"041034bd8eac8ca81ee32e8cc03adeb8f95e0c795587be2609f9f67608317f57")
