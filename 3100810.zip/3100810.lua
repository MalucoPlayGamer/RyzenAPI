-- Lua provided by RyzenAPI
-- Game: Unreal Wukong

-- MAIN APPLICATION
addappid(3100810)
addappid(3264560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100811, 1, "9e941cebe27bd2b42e06cdef7f3e1bcfb94e237ac8101f95027578962edf6928")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
