-- Lua provided by RyzenAPI
-- Game: addappid(3100810)

-- MAIN APPLICATION
addappid(3100810)
addappid(3264560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100811, 1, "9e941cebe27bd2b42e06cdef7f3e1bcfb94e237ac8101f95027578962edf6928")
