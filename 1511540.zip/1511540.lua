-- Lua provided by RyzenAPI
-- Game: addappid(1511540)

-- MAIN APPLICATION
addappid(1511540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511541, 1, "34b880c701601c225298f08d1de55aaca13eb376bf69fb68872dc2c4d7b9390d")
