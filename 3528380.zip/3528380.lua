-- Lua provided by RyzenAPI 
-- Game: AppID 3528380
addappid(3528380)
addappid(3528381, 1, "080a00429a1b58aeff194216cfd938266286614dba1bd1f11ad3af00400e341f")
