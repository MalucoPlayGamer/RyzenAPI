-- Lua provided by RyzenAPI
-- Game: Black Ice

-- MAIN APPLICATION
addappid(311800)
-- Game: addappid(311800)

-- MAIN APP DEPOTS / PACKAGES
addappid(311801, 1, "ce232b05ea74c1132008aec8f5965738909e168736172a4ee5abbf4b320ac1e7")
