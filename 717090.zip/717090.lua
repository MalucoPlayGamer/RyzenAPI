-- Lua provided by RyzenAPI
-- Game: Game-Ready Assets

-- MAIN APPLICATION
addappid(717090)
addappid(717130)
addappid(718150)
addappid(719920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(717091, 1, "faa7fec07af4a0ef9fbf78fa7659e725991d4c548858418973aa32a6218d5d89")
addappid(718290, 0, "4cb97966f367fa7c3eebd2ebfafcc5b7c4c83fa32d31e757725706be9d615d19")
