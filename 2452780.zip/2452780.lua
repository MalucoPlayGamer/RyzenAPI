-- Lua provided by RyzenAPI
-- Game: NSFW Content - Cow Girls 3 Stories

-- MAIN APPLICATION
addappid(2452780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452780,0,"ba2d0916b8735667309514fcf56114bcad9a3e814e3d56d25de4ded2661d0fc5")

