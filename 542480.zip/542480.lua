-- Lua provided by RyzenAPI
-- Game: Therian Saga

-- MAIN APPLICATION
addappid(542480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(542481, 1, "e8b295d23a64bcc66351859c3e836a53b51872b6f0d7afa48e70bdc866a3656c")

