-- Lua provided by RyzenAPI
-- Game: 542480

-- MAIN APPLICATION
addappid(542480)
-- Game: addappid(542480)

-- MAIN APP DEPOTS / PACKAGES
addappid(542481, 1, "e8b295d23a64bcc66351859c3e836a53b51872b6f0d7afa48e70bdc866a3656c")
