-- Lua provided by RyzenAPI
-- Game: Game: AppID 815360

-- MAIN APPLICATION
addappid(815360)
-- Game: addappid(815360)

-- MAIN APP DEPOTS / PACKAGES
addappid(815361, 1, "2686abe40c8688e4622701d2bf5cf581e59f61bb2c39112460b05e87909f0fd4")
