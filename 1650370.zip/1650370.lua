-- Lua provided by RyzenAPI 
-- Game: Galaxy Highways
addappid(1650370)
addappid(1650371, 1, "4190b5c64eb7ce53a039148d2b323725ae8a362029045a80a05bbb8142d09371")
addappid(3721090, 0, "1db3f78e129a2fa7d8c81bb1e0901eac0861a77f13350f887184c4ae01a7dd07")
