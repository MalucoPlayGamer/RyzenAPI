-- Lua provided by RyzenAPI
-- Game: AppID 1067320

-- MAIN APPLICATION
addappid(1067320)
-- Game: addappid(1067320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067321, 1, "3719e7d896a05b7f46a8ee8f2d4ce207bf265cd672531dc02d8183cb0c3281a5")
