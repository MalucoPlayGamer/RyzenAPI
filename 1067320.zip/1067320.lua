-- Lua provided by RyzenAPI
-- Game: Pathogenesis: Overcome

-- MAIN APPLICATION
addappid(1067320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1067321, 1, "3719e7d896a05b7f46a8ee8f2d4ce207bf265cd672531dc02d8183cb0c3281a5")

