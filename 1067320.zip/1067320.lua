-- Lua provided by RyzenAPI 
-- Game: AppID 1067320
addappid(1067320)
addappid(1067321, 1, "3719e7d896a05b7f46a8ee8f2d4ce207bf265cd672531dc02d8183cb0c3281a5")
