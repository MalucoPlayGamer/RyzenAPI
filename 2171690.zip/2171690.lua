-- Lua provided by RyzenAPI
-- Game: Handshakes

-- MAIN APPLICATION
addappid(2171690)

