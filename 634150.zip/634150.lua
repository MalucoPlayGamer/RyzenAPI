-- Lua provided by RyzenAPI
-- Game: Game: ReSizE

-- MAIN APPLICATION
addappid(634150)
-- Game: addappid(634150)

-- MAIN APP DEPOTS / PACKAGES
addappid(634151, 1, "4ac8bb5f40324b06703a05ee96973b3cec473c41b69c74f79e113552b090a1e0")
