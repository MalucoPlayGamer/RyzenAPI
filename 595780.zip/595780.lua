-- Lua provided by RyzenAPI 
-- Game: AppID 595780
addappid(595780)
addappid(595781, 1, "6d4b88aff2287686c33639a4ef05b5f3e3d3a26b69527b25db28f3e97b7b3340")
