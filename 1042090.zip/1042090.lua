-- Lua provided by RyzenAPI
-- Game: 1042090

-- MAIN APPLICATION
addappid(1042090)
-- Game: addappid(1042090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042091, 1, "d96d8bbede7e8c96d6d1276e8fa5450b80a0fd3bb3fbd269872fc2eace0b5fe5")
