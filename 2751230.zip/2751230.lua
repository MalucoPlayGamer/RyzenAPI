-- Lua provided by RyzenAPI
-- Game: Hole io

-- MAIN APPLICATION
addappid(2751230)
addappid(2751620)
addappid(2751630)
addappid(2751640)
addappid(4132900)
addappid(4132910)
addappid(4132920)
addappid(4132930)
addappid(4132940)
addappid(4132950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751231,0,"ba09baf0249a5e225bb99620de00750c6e3211e1ffc9378f3f060071a83a6388")
addappid(2751620,0,"51bc17084c120e26a588fd0b8766eba66183cfae2c561f1d378aa877cbe49e34")
addappid(2751630,0,"c26287ffce520546a04700dee90bf7ebe3edab047254cf425012de569877eac0")
addappid(2751640,0,"956baf889d8fc10530e8c87a7b73987796bb0f62ba8533436a92e18651d1ced4")

