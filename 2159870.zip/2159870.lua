-- Lua provided by RyzenAPI
-- Game: City Metro Simulator

-- MAIN APPLICATION
addappid(2159870)
-- Game: addappid(2159870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159871, 1, "4b2b5eb619909a54cf409a1146198e35464c677e88fa5a136061d8b76bcd25bc")
