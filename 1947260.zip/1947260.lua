-- Lua provided by RyzenAPI
-- Game: Game: Hidden Harbor Top-Down 3D

-- MAIN APPLICATION
addappid(1947260)
-- Game: addappid(1947260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947261, 1, "5ded2213b782aea78f80e39040be3a103eec8a405efbbb4c78d8339891c5e84e")
