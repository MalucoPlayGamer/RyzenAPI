-- Lua provided by RyzenAPI
-- Game: Where the Heart is:  Season 1

-- MAIN APPLICATION
addappid(2287710)
-- Game: addappid(2287710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287711, 1, "45e81b1be0d1746ec6b9ea874073aa1ef9f1ba7a23c758db0902a6a7eab8a30d")
