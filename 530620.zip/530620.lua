-- Lua provided by RyzenAPI
-- Game: Resident Evil 7 Teaser: Beginning Hour

-- MAIN APPLICATION
addappid(530620)

-- MAIN APP DEPOTS / PACKAGES
addappid(530621, 1, "8e2d6a5493ed3eb9c7eed7431ea06e0743b2543e2e6d2448b7b6e8e2ec297c1f")

