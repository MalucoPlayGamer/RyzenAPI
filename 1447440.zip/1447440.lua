-- Lua provided by RyzenAPI
-- Game: Happy Quest : True Happy

-- MAIN APPLICATION
addappid(1447440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447440,0,"04e7755f9c488a04caba081b9b1e262bc65c9e4dc5682e4e27b934d14d669484")

