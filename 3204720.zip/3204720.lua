-- Lua provided by RyzenAPI
-- Game: Veilwalkers

-- MAIN APPLICATION
addappid(3204720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204722,0,"316b93c746e5394de6c9b1d599b66918a4122f9956b794b2bd36aff30c74d848")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
