-- Lua provided by RyzenAPI
-- Game: Veilwalkers

-- MAIN APPLICATION
addappid(3204720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204722,0,"316b93c746e5394de6c9b1d599b66918a4122f9956b794b2bd36aff30c74d848")
