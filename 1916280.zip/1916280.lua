-- Lua provided by RyzenAPI
-- Game: Swords Fantasy: Battlefield

-- MAIN APPLICATION
addappid(1916280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916281, 1, "e54ba697da0b2d83a9edf1096beb4482363cd430687bcb47d4bd9b0a3fdb4bfb")
