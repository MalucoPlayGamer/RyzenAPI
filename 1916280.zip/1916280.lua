-- Lua provided by RyzenAPI
-- Game: Swords Fantasy: Battlefield

-- MAIN APPLICATION
addappid(1916280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916281, 1, "e54ba697da0b2d83a9edf1096beb4482363cd430687bcb47d4bd9b0a3fdb4bfb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
