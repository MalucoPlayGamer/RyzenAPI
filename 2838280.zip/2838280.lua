-- Lua provided by RyzenAPI
-- Game: Beat Saber - Daft Punk - "Lose Yourself to Dance (feat. Pharrell Williams)"

-- MAIN APPLICATION
addappid(2838280)
-- Game: addappid(2838280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838280,0,"309ef301fbd9856b7519d7a404b1cc82329409e400e066859d7ab77bdaa1ca6e")
