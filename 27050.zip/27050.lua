-- Lua provided by RyzenAPI
-- Game: Fatale

-- MAIN APPLICATION
addappid(27050)

-- MAIN APP DEPOTS / PACKAGES
addappid(27051, 1, "afc98e8f49aa8bd24c255d68b2ad34b48098c321c37e3b4c5244b03158af43a5")

