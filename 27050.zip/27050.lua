-- Lua provided by RyzenAPI 
-- Game: Fatale
addappid(27050)
addappid(27051, 1, "afc98e8f49aa8bd24c255d68b2ad34b48098c321c37e3b4c5244b03158af43a5")
