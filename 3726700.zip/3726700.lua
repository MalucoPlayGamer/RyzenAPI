-- Lua provided by RyzenAPI
-- Game: addappid(3726700)

-- MAIN APPLICATION
addappid(3726700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3726701, 1, "000205602fd5288fb659d9b3cc81ca2814cdb5e83c7ccb691907a8071ba66d7a")
