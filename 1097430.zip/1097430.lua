-- Lua provided by RyzenAPI 
-- Game: AppID 1097430
addappid(1097430)
addappid(1097431, 1, "54261c3e89fb233b498eb6600dccae1f874a9996407f4cf30ad3a9754e8ade90")
addappid(1097436, 1, "25e623c862ebb86f27aeb58b3f9de77f426e4754d3b49746aaa2385d7aaa7500")
