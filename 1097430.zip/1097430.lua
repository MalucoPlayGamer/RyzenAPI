-- 1097430's Lua and Manifest Created by Hubcap Manifest
-- 依盖之书 book of yog
-- Created: August 15, 2026 at 22:04:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1097430, 1, "f4c6ce3a4873b249940384c403cc6c219f05cbb55766ddf2985abd7d98a144e3") -- 依盖之书 book of yog
-- MAIN APP DEPOTS
addappid(1097432, 1, "2e4a3efb0a138c1b4f9b3027bd8f14651a1e451710784d013073c2533244430e") -- Depot 1097432
setManifestid(1097432, "903370832220483260", 2071289875)
addappid(1097431, 1, "54261c3e89fb233b498eb6600dccae1f874a9996407f4cf30ad3a9754e8ade90") -- Depot 1097431
setManifestid(1097431, "3733391343079240505", 2071289875)
addappid(1097436, 1, "25e623c862ebb86f27aeb58b3f9de77f426e4754d3b49746aaa2385d7aaa7500") -- Depot 1097436
setManifestid(1097436, "7818038583621433143", 24204977072)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2644290) -- -
addappid(2694630) -- -
addappid(2872960) -- -
addappid(3440690) -- -
addappid(3642190) -- -