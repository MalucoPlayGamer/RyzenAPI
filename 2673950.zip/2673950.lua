-- Lua provided by RyzenAPI
-- Game: The Unvisited Grandma

-- MAIN APPLICATION
addappid(2673950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673951, 1, "7f89e01b36a0883dd958abf588a29c176602f0198c3a31995542718e3d334c53")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
