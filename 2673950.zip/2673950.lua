-- Lua provided by RyzenAPI 
-- Game: The Unvisited Grandma
addappid(2673950)
addappid(2673951, 1, "7f89e01b36a0883dd958abf588a29c176602f0198c3a31995542718e3d334c53")
