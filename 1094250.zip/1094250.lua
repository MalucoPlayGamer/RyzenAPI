-- Lua provided by RyzenAPI
-- Game: It Stares Back

-- MAIN APPLICATION
addappid(1094250)
-- Game: addappid(1094250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094251, 1, "3d2581e86a85f1e572a7d3def071dfa101331829f4097fe3b18772794e25127b")
