-- Lua provided by RyzenAPI
-- Game: addappid(2054660)

-- MAIN APPLICATION
addappid(2054660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054661, 1, "ab4e2da3364ed5edd189355519a244cf4f7630469abeb2ede70a411d2eeb5382")
