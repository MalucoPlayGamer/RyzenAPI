-- Lua provided by RyzenAPI 
-- Game: Disney Illusion Island Starring Mickey and Friends
addappid(2054660)
addappid(2054661, 1, "ab4e2da3364ed5edd189355519a244cf4f7630469abeb2ede70a411d2eeb5382")
