-- Lua provided by RyzenAPI
-- Game: Blood Island

-- MAIN APPLICATION
addappid(1009810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009811, 1, "c6f1578ec6a6c2022c389d4cce0da8c949a1be71e370ce8589a3fe7bc6677222")

