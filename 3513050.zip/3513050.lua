-- Lua provided by RyzenAPI
-- Game: Last Town

-- MAIN APPLICATION
addappid(3513050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3513051, 1, "c18017f5494e3624c7da11995cbcde25a144a78e054e5f23ba906f562b0a4544")

