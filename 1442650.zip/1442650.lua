-- Lua provided by RyzenAPI
-- Game: White Day VR: The Courage Test

-- MAIN APPLICATION
addappid(1442650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442651, 1, "d36e1fe8363fe1bbadb034770b8002ca6c7c008cbb956b9b7b43c2de2ccf58c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
