-- Lua provided by RyzenAPI
-- Game: Game: White Day VR: The Courage Test

-- MAIN APPLICATION
addappid(1442650)
-- Game: addappid(1442650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442651, 1, "d36e1fe8363fe1bbadb034770b8002ca6c7c008cbb956b9b7b43c2de2ccf58c8")
