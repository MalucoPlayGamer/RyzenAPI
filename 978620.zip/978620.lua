-- Lua provided by RyzenAPI
-- Game: Game: AppID 978620

-- MAIN APPLICATION
addappid(978620)
-- Game: addappid(978620)

-- MAIN APP DEPOTS / PACKAGES
addappid(978621, 1, "78d3a7982d8983d97fd39587a0f4a6faa2b24761fff6b121da821baed6c66821")
