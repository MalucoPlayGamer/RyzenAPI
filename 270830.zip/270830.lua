-- Lua provided by RyzenAPI 
-- Game: Global ATC Simulator
addappid(270830)
addappid(270831, 1, "af8ef68b762a19c4b26b29184560052111af86c6552bb22b42c31c94242a66a5")
