-- Lua provided by RyzenAPI
-- Game: Global ATC Simulator

-- MAIN APPLICATION
addappid(270830)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(270831, 1, "af8ef68b762a19c4b26b29184560052111af86c6552bb22b42c31c94242a66a5")

