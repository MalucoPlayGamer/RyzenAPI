-- Lua provided by RyzenAPI
-- Game: I'm Pregnant at 16

-- MAIN APPLICATION
addappid(3464570)
addappid(3909910)
addappid(4033390)
addappid(4050150)
addappid(4879090)

