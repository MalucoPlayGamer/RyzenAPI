-- Lua provided by RyzenAPI
-- Game: I'm Pregnant at 16

-- MAIN APPLICATION
addappid(3464570)
