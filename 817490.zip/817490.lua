-- Lua provided by RyzenAPI
-- Game: Viki Spotter: Around The World

-- MAIN APPLICATION
addappid(817490)

-- MAIN APP DEPOTS / PACKAGES
addappid(817491, 1, "859d401a0f86c84eeb5a6c4316f379bf6c537d82ce76f68d826986aa421cd3aa")
