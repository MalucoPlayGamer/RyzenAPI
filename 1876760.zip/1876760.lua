-- Lua provided by RyzenAPI
-- Game: 万界之门 Demo

-- MAIN APPLICATION
addappid(1876760)
-- Game: addappid(1876760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876761, 1, "f761fda4f4b6a598ad98a9713a018473175473c9d52e7ca8e648f885fc30b4d3")
