-- 3701190's Lua and Manifest Created by Hubcap Manifest
-- Mycofall
-- Created: July 22, 2026 at 13:59:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3701190, 1, "ec6f062ad37a14213770a6bf69921fd6f4625844f1cc2bb1ea644424f9d21d9c") -- Mycofall
-- MAIN APP DEPOTS
addappid(3701191, 1, "6c22f661e479464eb2ecda7e92d3fd71f36a19eaa78ef31d1f6eea9df29edb89") -- Depot 3701191
setManifestid(3701191, "6296042475296543165", 2163315754)