-- Lua provided by RyzenAPI
-- Game: The Matriarch

-- MAIN APPLICATION
addappid(1773180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773181, 1, "0e59311760fa44ae8b2e7063a64694d7baf6677165bd88667b297d090add4b90")

