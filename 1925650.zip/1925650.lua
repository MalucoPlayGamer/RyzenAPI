-- Lua provided by RyzenAPI
-- Game: Stars Reach

-- MAIN APPLICATION
addappid(1925650) -- Stars Reach
addappid(4896600) -- Stars Reach - Firstlight Founders Pack
addappid(4896620) -- Stars Reach - Voyager Founders Pack
addappid(4896630) -- Stars Reach - Cosmonaut Founders Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1925651, 1, "30e28dde007731af5d57f67baac0ceaf0244d8e86d5443ea87177bc6a666d738") -- Depot 1925651

