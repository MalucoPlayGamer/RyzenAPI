-- 1925650's Lua and Manifest Created by Hubcap Manifest
-- Stars Reach
-- Created: August 19, 2026 at 15:54:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(1925650) -- Stars Reach
-- MAIN APP DEPOTS
addappid(1925651, 1, "30e28dde007731af5d57f67baac0ceaf0244d8e86d5443ea87177bc6a666d738") -- Depot 1925651
setManifestid(1925651, "3171273910427321076", 5861893401)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4896600) -- Stars Reach - Firstlight Founders Pack
addappid(4896620) -- Stars Reach - Voyager Founders Pack
addappid(4896630) -- Stars Reach - Cosmonaut Founders Pack