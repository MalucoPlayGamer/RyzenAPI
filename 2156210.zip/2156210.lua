-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Darktide Playtest

-- MAIN APPLICATION
addappid(2156210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156211, 1, "163f1273eab0fc43b7c803c283116b4685a5592ff656a5de8dc18ebc9c37f92a")
addappid(2156212, 1, "305881bf97852d992c8370266caa7fdf774f9f60e914515596cbae31fa9c37e4")
addappid(2156213, 1, "f80c6bc3304f963f59f29aa88ae39ecde7de3987cb203b3046737e9375985bdb")

