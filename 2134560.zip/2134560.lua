-- Lua provided by RyzenAPI
-- Game: addappid(2134560)

-- MAIN APPLICATION
addappid(2134560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134561, 1, "7be11788085b726da4fcf5842d1f89a9336d5864b96614d0c53f1c750a3efd6e")
