-- Lua provided by RyzenAPI
-- Game: 9th Sentinel Sisters

-- MAIN APPLICATION
addappid(2134560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134561, 1, "7be11788085b726da4fcf5842d1f89a9336d5864b96614d0c53f1c750a3efd6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
