-- Lua provided by RyzenAPI
-- Game: 817050

-- MAIN APPLICATION
addappid(817050)
-- Game: addappid(817050)

-- MAIN APP DEPOTS / PACKAGES
addappid(817051, 1, "b9202ecdd9fe706256ef206921608dcab104b6028ddf0c630c85f1419fe58408")
