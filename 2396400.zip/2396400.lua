-- Lua provided by RyzenAPI
-- Game: Canvas Menagerie

-- MAIN APPLICATION
addappid(2396400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396401,0,"bd1d97d59c8299310b3ed88e709cd746c8a393c0baa8c3d6ed2fdf6db61a4808")
addappid(3409480,0,"be7fc372c76e96974885a43d790d56dcf4479f3f5a8d48c435a5df755581c532")

