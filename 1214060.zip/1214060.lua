-- Lua provided by RyzenAPI
-- Game: 1214060

-- MAIN APPLICATION
addappid(1214060)
-- Game: addappid(1214060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214061, 1, "912c7e8552904e6d65fee2ed9a2a45db8a2aac997da6441b6d1f8732f6602f62")
