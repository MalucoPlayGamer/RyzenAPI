-- Lua provided by SkyAPI 
-- Game: AppID 1214060
addappid(1214060)
addappid(1214061, 1, "912c7e8552904e6d65fee2ed9a2a45db8a2aac997da6441b6d1f8732f6602f62")
