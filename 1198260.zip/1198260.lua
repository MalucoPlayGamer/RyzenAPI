-- Lua provided by RyzenAPI
-- Game: addappid(1198260)

-- MAIN APPLICATION
addappid(1198260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198261, 1, "bab8322f7b02520a357e26c30ce3a01a0cdcb8340704fba2282373c502a07cc7")
