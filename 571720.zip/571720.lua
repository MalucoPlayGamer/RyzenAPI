-- Lua provided by RyzenAPI
-- Game: One Piece: Unlimited World Red - Deluxe Edition

-- MAIN APPLICATION
addappid(571720)
-- Game: addappid(571720)

-- MAIN APP DEPOTS / PACKAGES
addappid(571721, 1, "f530c9ff8a14d54141651e1418331d17e5053e41738e00f113371eaefe1309ac")
