-- Lua provided by RyzenAPI
-- Game: One Piece: Unlimited World Red - Deluxe Edition

-- MAIN APPLICATION
addappid(571720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(571721, 1, "f530c9ff8a14d54141651e1418331d17e5053e41738e00f113371eaefe1309ac")

