-- Lua provided by RyzenAPI
-- Game: Space Merchants: Arena

-- MAIN APPLICATION
addappid(548080)

-- MAIN APP DEPOTS / PACKAGES
addappid(548081, 1, "9bafbdd9fdb43dc660e21f2a250230e87cfcf93f0223957bd1e5b84175f6b947")
addappid(548082, 1, "41d286ee66b6a8329f7c496b1daba868a23d1df1468cf4ead08707b998ded099")
addappid(548083, 1, "734a953af2ee55b39fe32349eeccb251551fb845f1bbd3940bd9755cd03c4ea0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
