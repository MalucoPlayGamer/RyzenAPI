-- Lua provided by RyzenAPI
-- Game: WAR_WAR_WAR: Smiles vs Ghosts

-- MAIN APPLICATION
addappid(916820)
-- Game: addappid(916820)

-- MAIN APP DEPOTS / PACKAGES
addappid(916821, 1, "092ba9acef116374877b373641248d3f97b1c8ad0acd0e87b0b1faeeeecddbf7")
