-- Lua provided by SkyAPI 
-- Game: Agonize
addappid(1609570)
addappid(1609571, 1, "b3ed294b69723b89accb1cbff58279355de485f788fc3c451064e8594813bed5")
