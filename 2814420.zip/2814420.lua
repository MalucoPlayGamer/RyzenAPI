-- Lua provided by RyzenAPI
-- Game: addappid(2814420)

-- MAIN APPLICATION
addappid(2814420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814421, 1, "57b7e00ae5a4917e6dd051e1e0573ab4b9bda8fa6f9a469e8e9fe49be2ef77fc")
