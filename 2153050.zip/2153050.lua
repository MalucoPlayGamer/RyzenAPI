-- Lua provided by RyzenAPI
-- Game: Game: AppID 2153050

-- MAIN APPLICATION
addappid(2153050)
-- Game: addappid(2153050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153051, 1, "f6e4083e41cabe3aaafabd51efd804e2e8b788b4bec3018f3dac1c82f5e2744e")
