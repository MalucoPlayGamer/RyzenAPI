-- Lua provided by RyzenAPI
-- Game: AppID 288020

-- MAIN APPLICATION
addappid(288020)

-- MAIN APP DEPOTS / PACKAGES
addappid(288021, 1, "7454acf121476dd1c4ffe16b977bfd981c54212d4963be322033720e882ebec9")
addappid(288022, 1, "ecf471b6e2b59119baf3b96c760177260c9c17b37f450905ed8f252c72ab2658")
addappid(288023, 1, "23c8721075f0818572626ce82c49eb9439b25ba1cc4f6e692bbe0a914fd53849")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
