-- Lua provided by RyzenAPI
-- Game: Infection Free Zone

-- MAIN APPLICATION
addappid(1465460)
addappid(3905440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465461, 1, "e2a62ed18d9479e7bca56d425a8c527bacdfc7435666810eafeea55fe3e7746f")

