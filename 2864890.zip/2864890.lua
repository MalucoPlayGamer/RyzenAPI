-- Lua provided by RyzenAPI
-- Game: Magic Research 2

-- MAIN APPLICATION
addappid(2864890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2864891, 1, "00df4cd16a04dc241db056aa7a3bc56671e98068358353649abeea1bc2a16796")
addappid(2864892, 1, "8ce0c28ea01408d1139b408db01ed6564f74237eb79380d85d0116d34495bbf0")

