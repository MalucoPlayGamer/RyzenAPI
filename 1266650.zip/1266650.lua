-- Lua provided by RyzenAPI
-- Game: 1266650

-- MAIN APPLICATION
addappid(1266650)
-- Game: addappid(1266650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266651, 1, "f190567e4c8cf639f26aa382877143011fdc37e9978bf317e4b5561feeae406a")
