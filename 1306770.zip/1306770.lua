-- Lua provided by RyzenAPI 
-- Game: Revival: Recolonization
addappid(1306770)
addappid(1306771, 1, "f2502a1a377932d59c61198585dbdfcd53450654b8205fa3a325743e4b0f4fab")
