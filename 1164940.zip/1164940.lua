-- Lua provided by RyzenAPI
-- Game: Trepang2

-- MAIN APPLICATION
addappid(1164940)
addappid(2615910)
addappid(2615920)
addappid(2656880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164944,0,"e7cf384fd9cc9adec7e85fe5751ed3bb5fe89e2cf1c3c1135df0dbd421580c3c")

