-- Lua provided by RyzenAPI
-- Game: Game: AppID 2617470

-- MAIN APPLICATION
addappid(2617470)
-- Game: addappid(2617470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617471, 1, "fdc064333ed4c287e86a5ab2744d14841dd094007c40b333ae38471e98b67597")
