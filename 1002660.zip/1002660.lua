-- Lua provided by RyzenAPI
-- Game: addappid(1002660)

-- MAIN APPLICATION
addappid(1002660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002661, 1, "01e34c77a0dfea0a0e5b7a5e3c5f49ea275b354b140c4431533e2d6ff2d17324")
