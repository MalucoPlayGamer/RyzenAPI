-- Lua provided by RyzenAPI
-- Game: 只有向下 Only Down

-- MAIN APPLICATION
addappid(2571120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2571121, 1, "bd58ce98548d1182075c6b1c7abb8ce0ff69dff30b70ef99f89359ed5374fac8")

