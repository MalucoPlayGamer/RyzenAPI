-- Lua provided by SkyAPI 
-- Game: Princess Chessboard
addappid(2509130)
addappid(2509131, 1, "b1df4c7b158a2a016894d291232c9b9f7e271304b89f8e2b95679db604880378")
