-- Lua provided by RyzenAPI
-- Game: Princess Chessboard

-- MAIN APPLICATION
addappid(2509130)
-- Game: addappid(2509130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509131, 1, "b1df4c7b158a2a016894d291232c9b9f7e271304b89f8e2b95679db604880378")
