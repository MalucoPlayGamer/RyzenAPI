-- Lua provided by RyzenAPI
-- Game: Cult of Personality

-- MAIN APPLICATION
addappid(1699290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699291, 1, "ec107a7ed73a0c26ec8bf5672189879b7aafb03b035d11b99664bc566858eef0")
addappid(1699292, 1, "aaf6132e492e4c4b6cc068d89a02306be289010d7db207fb3190caab7d3d7802")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
