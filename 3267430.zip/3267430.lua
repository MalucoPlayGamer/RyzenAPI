-- Lua provided by SkyAPI 
-- Game: Last Remains
addappid(3267430)
addappid(3267431, 1, "7f4f1fa469c4bc63de14ff6f56c50c25a958287221d8029fd049c8b653da24d4")
