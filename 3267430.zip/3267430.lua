-- Lua provided by RyzenAPI
-- Game: Last Remains

-- MAIN APPLICATION
addappid(3267430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267431, 1, "7f4f1fa469c4bc63de14ff6f56c50c25a958287221d8029fd049c8b653da24d4")
