-- Lua provided by RyzenAPI
-- Game: Tail Trail Demo

-- MAIN APPLICATION
addappid(1615440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507601,0,"d4c06dbc05c3f6efc8a2cfe2d8fc99c3680f9202ec165170bdf3432829ef6fed")

