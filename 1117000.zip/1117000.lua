-- Lua provided by RyzenAPI
-- Game: 1117000

-- MAIN APPLICATION
addappid(1117000)
-- Game: addappid(1117000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117001, 1, "0802f4f01e53f6b42fae639eade7b3337d1c5abb939f60cb1a7319825e17e306")
