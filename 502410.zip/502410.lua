-- Lua provided by RyzenAPI
-- Game: addappid(502410)

-- MAIN APPLICATION
addappid(502410)

-- MAIN APP DEPOTS / PACKAGES
addappid(502411, 1, "745168d7d434a52bea90c24a1a3c69db01f70e43f01e97b5122f6e91cfc4b896")
