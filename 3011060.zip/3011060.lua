-- Lua provided by RyzenAPI
-- Game: Game: Iron Village

-- MAIN APPLICATION
addappid(3011060)
-- Game: addappid(3011060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011061, 1, "523129831c321963a324de6fc94640504c5c07b53c7093c65b6786717eaae23d")
addappid(3011062, 1, "64a0c3355d088f75bd86ff073ef5d5ce0f4c1d965fd52ea9fe7158e24cb99174")
