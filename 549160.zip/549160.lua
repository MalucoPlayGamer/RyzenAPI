-- Lua provided by RyzenAPI
-- Game: Army Men

-- MAIN APPLICATION
addappid(549160)
-- Game: addappid(549160)

-- MAIN APP DEPOTS / PACKAGES
addappid(549161, 1, "2156bd03b39c8cbc342c64a4b112a7c50f22592e19eaca37343890703bf31151")
addappid(549162, 1, "489d962c941095880886b78641a7dda44eb4fee0e2a4db3e8d94f53fc75fd213")
