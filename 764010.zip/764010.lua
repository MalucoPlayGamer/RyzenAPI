-- Lua provided by RyzenAPI
-- Game: Insane Cold: Back to the Ice Age

-- MAIN APPLICATION
addappid(764010)
-- Game: addappid(764010)

-- MAIN APP DEPOTS / PACKAGES
addappid(764011, 1, "477fa655c7627748e00997da989baec17777bee7c61b9602ade1510c5277e8ea")
addappid(764012, 1, "92640132d87d64795b7ed47df409ed107ad2fc4af934131dae95f615e151ee04")
addappid(764013, 1, "961f724751a2e0c7ab803ff457fd0f616efdc936f39060e3ff17479363e171cb")
addappid(764014, 1, "5f56fb4481d7b052c4d16f3aaf9f29e87a28b921667db28c0d351277fcffb505")
addappid(764015, 1, "6376ac1371fe9409bf18f46757f898f9baf6270fce70502cca1ffe657c3676d4")
addappid(764016, 1, "762e2adb71d4ccedc69f14e364ff322df340babab1794c4a721d824861cc5aa4")
