-- Lua provided by RyzenAPI
-- Game: Fighting Fantasy Classics

-- MAIN APPLICATION
addappid(856880)
addappid(856900)
addappid(856910)
addappid(856920)
addappid(856930)
addappid(856940)
addappid(856950)
addappid(856960)
addappid(897180)
addappid(897190)
addappid(1588350)
addappid(1647470)
addappid(1960520)
addappid(2081030)
addappid(2081031)
addappid(2081032)
addappid(2081033)
addappid(3510410)
addappid(3588900)
addappid(3855210)
addappid(4138770)
addappid(4692040)

-- MAIN APP DEPOTS / PACKAGES
addappid(856882,0,"0aadee7d2f4ab339947ccc351ca91c978e9e7a12a64e848dc328fc8e4f53c2a0")
addappid(856883,0,"88f0cf6fcb3cccf02133d65bd18886bdf5613dd61ac8e59bafcd4d8d89225ed9")

