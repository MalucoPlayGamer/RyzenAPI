-- Lua provided by RyzenAPI
-- Game: 856880

-- MAIN APPLICATION
addappid(856880)

-- MAIN APP DEPOTS / PACKAGES
addappid(856882,0,"0aadee7d2f4ab339947ccc351ca91c978e9e7a12a64e848dc328fc8e4f53c2a0")
addappid(856883,0,"88f0cf6fcb3cccf02133d65bd18886bdf5613dd61ac8e59bafcd4d8d89225ed9")

