-- Lua provided by RyzenAPI
-- Game: Game: TAL: Arctic 4

-- MAIN APPLICATION
addappid(1548830)
-- Game: addappid(1548830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548831, 1, "353691839e347245d297566d68526b223116174e815e402bd8ead08a98c2d23f")
