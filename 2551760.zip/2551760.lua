-- Lua provided by RyzenAPI
-- Game: Game: AppID 2551760

-- MAIN APPLICATION
addappid(2551760)
-- Game: addappid(2551760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551761, 1, "817ca3b3d2a4bd0eb86407241422a8955c13e058cff62a36bb356ec30292c19e")
