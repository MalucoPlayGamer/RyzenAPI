-- Lua provided by RyzenAPI
-- Game: Viking Frontiers Demo

-- MAIN APPLICATION
addappid(2786420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786421, 1, "f3cb2bd482a2f1e96744b25a73dadf701209dbe089eb17a8d493e13f98175cdd")

