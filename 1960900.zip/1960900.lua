-- Lua provided by RyzenAPI
-- Game: Judero

-- MAIN APPLICATION
addappid(1960900)
-- Game: addappid(1960900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960901, 1, "fe32c2c1b0ad75541bee58152907d7c41af5ac6814881de86a09e72c7f5a3c06")
addappid(1960902, 1, "0b55c07503bd55fff3921a7e57176cc63e526aca19a1ec9e541d596d6eda8765")
