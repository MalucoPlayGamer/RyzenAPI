-- Lua provided by RyzenAPI
-- Game: addappid(1863540)

-- MAIN APPLICATION
addappid(1863540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863541, 1, "bec6e0ed44d1fb50cf956c7c79940ed6705b0f76013e1bca793318324ab6edee")
