-- Lua provided by RyzenAPI
-- Game: Nymphomaniac - Sex Addict

-- MAIN APPLICATION
addappid(3002570)
addappid(3411040)
-- Game: addappid(3002570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002571, 1, "e6978a8a04524482ba060c58ba0f45e185f278af036c31730452acee6a40ccb9")
