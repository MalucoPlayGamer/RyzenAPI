-- Lua provided by RyzenAPI
-- Game: Nymphomaniac - Sex Addict

-- MAIN APPLICATION
addappid(3002570)
addappid(3411040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(3002571, 1, "e6978a8a04524482ba060c58ba0f45e185f278af036c31730452acee6a40ccb9")

