-- Lua provided by RyzenAPI
-- Game: Hooligan Vasja

-- MAIN APPLICATION
addappid(515910)
-- Game: addappid(515910)

-- MAIN APP DEPOTS / PACKAGES
addappid(515911, 1, "51ec649d7200b53b9b9fc98d54808e635c7c27cd494f47113800982f47aabd6c")
