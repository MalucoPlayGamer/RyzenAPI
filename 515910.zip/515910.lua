-- Lua provided by RyzenAPI
-- Game: Hooligan Vasja

-- MAIN APPLICATION
addappid(515910)
addappid(542800)
addappid(560910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(515911, 1, "51ec649d7200b53b9b9fc98d54808e635c7c27cd494f47113800982f47aabd6c")

