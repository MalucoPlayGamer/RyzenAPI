-- Lua provided by RyzenAPI
-- Game: Ye Guild Clerk!

-- MAIN APPLICATION
addappid(3715020)

