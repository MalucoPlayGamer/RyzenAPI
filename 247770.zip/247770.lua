-- Lua provided by RyzenAPI
-- Game: AppID 247770

-- MAIN APPLICATION
addappid(247770)

-- MAIN APP DEPOTS / PACKAGES
addappid(247771, 1, "1db360a99679e85c85830d330be250f9545bc10e2d04adf8bcbe7717ebf618b2")
addappid(247772, 1, "80d000e8de670f48341e9d94fa7f11ff1f893de14a9ab0ce6924d5ced4a9eb59")

