-- Lua provided by RyzenAPI
-- Game: Game: Master of Magic

-- MAIN APPLICATION
addappid(1623070)
addappid(2239310)
addappid(2482370)
addappid(2689110)
-- Game: addappid(1623070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623071, 1, "34361efe132489475af6263696a90db1b1a2a5d8a4e30e2345f59c528f86feab")
addappid(1623072, 1, "08f76d2f8dff9433de73971c313dde27379952ed82d210d1ebcd25eeb3c45c8a")
