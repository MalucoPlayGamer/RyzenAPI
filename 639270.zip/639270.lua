-- Lua provided by RyzenAPI
-- Game: Game: AppID 639270

-- MAIN APPLICATION
addappid(639270)
-- Game: addappid(639270)

-- MAIN APP DEPOTS / PACKAGES
addappid(639271, 1, "73456670c1421a4bd37af005a488b6e0e1e5d0a39e3d48c614acbb4d39409760")
