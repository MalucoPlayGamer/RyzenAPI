-- Lua provided by RyzenAPI
-- Game: addappid(3344960)

-- MAIN APPLICATION
addappid(3344960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3344961, 1, "fccb92db8cc74db09e0dfe98204e43ac517d2b8a53f13a10520ce3f99f39d8ec")
