-- Lua provided by RyzenAPI
-- Game: 2216610

-- MAIN APPLICATION
addappid(2216610)
-- Game: addappid(2216610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216611, 1, "069404e5290cf2c35b540ad2fc6ad8e29604d5f6d795ccec15006d5cb5d2ee7d")
