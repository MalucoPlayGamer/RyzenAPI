-- Lua provided by RyzenAPI
-- Game: 苗歌 Demo

-- MAIN APPLICATION
addappid(2776420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776421, 1, "0c5d83d9170f6134147fdbb2ca6f9977cd4fb64c7a08492270ba275fb8ae35a2")

