-- Lua provided by RyzenAPI
-- Game: Lock & Key: A Magical Girl Mystery

-- MAIN APPLICATION
addappid(1803850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803851,0,"456b29ec17db1b0cd74b7985d277825e4d429de13a01b4f80999435dc65fc929")

