-- Lua provided by RyzenAPI
-- Game: AppID 2024870

-- MAIN APPLICATION
addappid(2024870)
-- Game: addappid(2024870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024871, 1, "9ff16abdfc09d352aa56fc23bbcbd03f4cd2f42b0509c20d9c89c2d1cf5ad082")
