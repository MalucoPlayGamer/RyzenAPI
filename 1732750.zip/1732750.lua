-- Lua provided by RyzenAPI
-- Game: Havsala: Into the Soul Palace

-- MAIN APPLICATION
addappid(1732750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1732751, 1, "117d89aa81b048421b598fb9c650a29824df485fa4122f8aedae52626da1f9fb")

