-- Lua provided by RyzenAPI
-- Game: AppID 3014550

-- MAIN APPLICATION
addappid(3014550)
-- Game: addappid(3014550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014551, 1, "b1f185bb56847d7cbff819eb539d34d36282e2cedd4c7a509487430b14b415ec")
