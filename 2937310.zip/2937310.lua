-- Lua provided by RyzenAPI
-- Game: Tidal Nexus Online

-- MAIN APPLICATION
addappid(2937310)

