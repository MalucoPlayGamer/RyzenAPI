-- Lua provided by RyzenAPI
-- Game: Game: AppID 1263160

-- MAIN APPLICATION
addappid(1263160)
-- Game: addappid(1263160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263161, 1, "da50cf2621da4459b54ede1d8bf1f915455822404ddcd41938cb78008f06aa81")
