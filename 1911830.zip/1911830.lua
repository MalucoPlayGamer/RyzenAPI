-- Lua provided by RyzenAPI
-- Game: Game: AppID 1911830

-- MAIN APPLICATION
addappid(1911830)
-- Game: addappid(1911830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911831, 1, "be1d169093a214b5c1906f4934960a0def0119bfcc4706d4b78a509a736bc62c")
