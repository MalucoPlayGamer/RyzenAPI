-- Lua provided by RyzenAPI
-- Game: Game: Europa Universalis III Complete Demo

-- MAIN APPLICATION
addappid(22150)
-- Game: addappid(22150)

-- MAIN APP DEPOTS / PACKAGES
addappid(22151, 1, "19026b738d86966f6de4b67f20e8cb9586afb24a012bd5641d6bc1281fed738e")
