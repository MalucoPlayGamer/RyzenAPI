-- Lua provided by RyzenAPI
-- Game: 我的江湖（JiangHu Sect）- 山门与幻境

-- MAIN APPLICATION
addappid(2917210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917210,0,"bdeb1eccedd69002ef23f347d2ef3b65a79887c96a4996cbe1fe7c53a79c2c2f")

