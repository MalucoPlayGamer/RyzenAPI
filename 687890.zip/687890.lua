-- Lua provided by RyzenAPI
-- Game: Game: Runaway VR

-- MAIN APPLICATION
addappid(687890)
-- Game: addappid(687890)

-- MAIN APP DEPOTS / PACKAGES
addappid(687891, 1, "a4488f73c1cac125e03089a183ccc935e77840323eb03dc83cb00cf5826b0e60")
