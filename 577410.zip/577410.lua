-- Lua provided by RyzenAPI
-- Game: The Pit: Infinity

-- MAIN APPLICATION
addappid(577410)
addappid(1216510)
addappid(1348780)

-- MAIN APP DEPOTS / PACKAGES
addappid(577411, 1, "172815065bdc0aaf988fcd3a14491e11db9fcba6666031ca7dab2983909a79ee")
