-- Lua provided by RyzenAPI
-- Game: Souldiers - OST

-- MAIN APPLICATION
addappid(1988760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988761, 1, "70986fa0671aa1835294188ee1cf8876d46b38f046967bc006db31f47f0fe553")
