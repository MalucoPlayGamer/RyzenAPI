-- Lua provided by RyzenAPI
-- Game: Virtual City Playground®: Build Your Metropolis

-- MAIN APPLICATION
addappid(3760180)
