-- Lua provided by RyzenAPI
-- Game: Delta Manager

-- MAIN APPLICATION
addappid(4247780)

-- MAIN APP DEPOTS / PACKAGES
addappid(4247780,0,"60962a1188363acaf8fff69b1e5ec59680161a9cae6d9c0b9ab16bb95ae9e84d")
addappid(4247781,0,"0e5e20171a0f56153b9bbae39ce29be71cfeccd586d9bd80576e39f3a45b4116")

