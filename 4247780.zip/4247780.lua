-- Lua provided by RyzenAPI
-- Game: Delta Manager

-- MAIN APPLICATION
addappid(4247780)

-- MAIN APP DEPOTS / PACKAGES
addappid(4247780,0,"60962a1188363acaf8fff69b1e5ec59680161a9cae6d9c0b9ab16bb95ae9e84d")
addappid(4247781,0,"0e5e20171a0f56153b9bbae39ce29be71cfeccd586d9bd80576e39f3a45b4116")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
