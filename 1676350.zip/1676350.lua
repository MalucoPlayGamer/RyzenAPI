-- Lua provided by RyzenAPI 
-- Game: 摆地摊
addappid(1676350)
addappid(1676351, 1, "d09b1138244d2612228bbd4de37e6fcbe5338bdc27e8ce83159386800292ba8c")
