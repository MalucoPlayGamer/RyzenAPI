-- Lua provided by SkyAPI 
-- Game: I Walk Among Zombies Vol. 1 (Adult Version)
addappid(942850)
addappid(942851, 1, "6d85d01525a1bfb26b11376dd63497bceeac34e4785344b31cfdc8fb5d60f8b4")
addappid(942852, 1, "4528f83b87a8beb0c803ffd5a151b74b43e4bc20a2624d5c171f8aec16ec6515")
