-- Lua provided by RyzenAPI
-- Game: Game: AppID 2998790

-- MAIN APPLICATION
addappid(2998790)
-- Game: addappid(2998790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998791, 1, "606bfca7c78434d6f411481f7eb5394817db142150834c6e6789d3673bef0ce6")
