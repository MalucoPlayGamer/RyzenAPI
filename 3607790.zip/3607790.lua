-- Lua provided by RyzenAPI
-- Game: 3607790

-- MAIN APPLICATION
addappid(3607790)
-- Game: addappid(3607790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3607791, 1, "3f0d0e9b08699dcd56120d50803c46faf268ab3d004bbb0ca60db0b4a6d3f24a")
