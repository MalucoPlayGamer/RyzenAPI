-- Lua provided by RyzenAPI
-- Game: Last Command

-- MAIN APPLICATION
addappid(1487270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487271, 1, "e2cb13ecf63037185abff0e505121254599aba1d2ab89ad25e4c2b7df1786f40")

