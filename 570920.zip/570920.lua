-- Lua provided by RyzenAPI
-- Game: Game: AppID 570920

-- MAIN APPLICATION
addappid(570920)
-- Game: addappid(570920)

-- MAIN APP DEPOTS / PACKAGES
addappid(570921, 1, "6892a2fef4d64d1438538cebcc825683d3ea9ad8342bc7e2f2b51161efd8c09e")
