-- Lua provided by RyzenAPI
-- Game: vBuilder

-- MAIN APPLICATION
addappid(735470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(735471, 1, "9ab55945a71caf043ae5076826888675e3f4818085dbfccbae98720c33788b6c")
