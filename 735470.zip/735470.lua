-- Lua provided by RyzenAPI
-- Game: Game: AppID 735470

-- MAIN APPLICATION
addappid(735470)
-- Game: addappid(735470)

-- MAIN APP DEPOTS / PACKAGES
addappid(735471, 1, "9ab55945a71caf043ae5076826888675e3f4818085dbfccbae98720c33788b6c")
