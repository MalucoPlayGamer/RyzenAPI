-- Lua provided by RyzenAPI 
-- Game: Zavod
addappid(3487340)
addappid(3487341, 1, "8b44893262dfd494bd59b0f216ffd51589951a3055c66c4a346b7399b0cbd39d")
addappid(3487342, 1, "42b67432f0388e55089f8099d1d532a384c935a63384caa2ac62aebdd58b93fc")
