-- Lua provided by RyzenAPI
-- Game: Faylinn's Quest

-- MAIN APPLICATION
addappid(1528010) -- Faylinn's Quest
addappid(1727630)
addappid(1728820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528011, 1, "39d28cf28a1d0c758e0326a8e7cae7dc66b373bfa4b883d780f0dbfe35da8e19") -- Faylinn's Quest Content
addappid(1727630, 1, "08bcb90003de3c1d07f3456e85a7f2c61bf16a308c72b379c0aa00be1a0dc35e") -- Faylinns Quest Magical Side Story - Depot: Faylinn's Quest: Magical Side Story (1727630)
addappid(1728820, 1, "e80228dd828fd8bb53093cfe1938fc5ccfcaca94f627e5752f5c61a4f562931b") -- NSFW Patch - Depot: NSFW Patch (1728820)

