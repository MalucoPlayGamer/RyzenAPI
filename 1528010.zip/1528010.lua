-- 1528010's Lua and Manifest Created by Hubcap Manifest
-- Faylinn's Quest
-- Created: August 17, 2026 at 13:38:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1528010) -- Faylinn's Quest
-- MAIN APP DEPOTS
addappid(1528011, 1, "39d28cf28a1d0c758e0326a8e7cae7dc66b373bfa4b883d780f0dbfe35da8e19") -- Faylinn's Quest Content
setManifestid(1528011, "1682150380869790430", 1025481023)
-- DLCS WITH DEDICATED DEPOTS
-- Faylinns Quest Magical Side Story (AppID: 1727630)
addappid(1727630)
addappid(1727630, 1, "08bcb90003de3c1d07f3456e85a7f2c61bf16a308c72b379c0aa00be1a0dc35e") -- Faylinns Quest Magical Side Story - Depot: Faylinn's Quest: Magical Side Story (1727630)
setManifestid(1727630, "3700732149312522014", 11171)
-- NSFW Patch (AppID: 1728820)
addappid(1728820)
addappid(1728820, 1, "e80228dd828fd8bb53093cfe1938fc5ccfcaca94f627e5752f5c61a4f562931b") -- NSFW Patch - Depot: NSFW Patch (1728820)
setManifestid(1728820, "4756895289648577663", 77604)