-- Lua provided by RyzenAPI
-- Game: addappid(2983380)

-- MAIN APPLICATION
addappid(2983380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983381, 1, "70904f0a67109a5b0d1255ad6101ffebf9439249adad89b24571bcac62a98a9e")
