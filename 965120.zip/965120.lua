-- Lua provided by RyzenAPI 
-- Game: 能量冲击 Energy Shock
addappid(965120)
addappid(965121, 1, "ff11c5c3f67cd19f0947a76edcc6d6da2870a85d7d148d9ffbf3e0c66b48bb40")
