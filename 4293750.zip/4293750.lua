-- Lua provided by RyzenAPI
-- Game: More fish - Idle Clicker

-- MAIN APPLICATION
addappid(4293750) -- More fish - Idle Clicker

-- MAIN APP DEPOTS / PACKAGES
addappid(4293752, 1, "047de7035e89efbe8c40846d20a0934db289983a6856c4823e69f460173275e1") -- Depot 4293752
addappid(4293753, 1, "c3bdcd12428b36967a6d5c8905ed3621a376093d095c431dbb95fc67f5291f2a") -- Depot 4293753
addappid(4293754, 1, "9a9f85e778d86438ace9a82fdbf12d43941d0088c2349b0f7abacf120887497e") -- Depot 4293754

