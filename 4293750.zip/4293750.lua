-- 4293750's Lua and Manifest Created by Hubcap Manifest
-- More fish - Idle Clicker
-- Created: August 17, 2026 at 16:14:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4293750) -- More fish - Idle Clicker
-- MAIN APP DEPOTS
addappid(4293752, 1, "047de7035e89efbe8c40846d20a0934db289983a6856c4823e69f460173275e1") -- Depot 4293752
setManifestid(4293752, "5231262533634186105", 300005047)
addappid(4293753, 1, "c3bdcd12428b36967a6d5c8905ed3621a376093d095c431dbb95fc67f5291f2a") -- Depot 4293753
setManifestid(4293753, "5278893935364642298", 429415156)
addappid(4293754, 1, "9a9f85e778d86438ace9a82fdbf12d43941d0088c2349b0f7abacf120887497e") -- Depot 4293754
setManifestid(4293754, "4402049721551970392", 364314488)