-- Lua provided by RyzenAPI
-- Game: 1184230

-- MAIN APPLICATION
addappid(1184230)
-- Game: addappid(1184230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184231, 1, "7ef211b8af04046d39b14119619db45ed3b07a294af60d2eff62530b323082a2")
