-- Lua provided by RyzenAPI
-- Game: AppID 651080

-- MAIN APPLICATION
addappid(651080)

-- MAIN APP DEPOTS / PACKAGES
addappid(651081, 1, "dc2023667ffd9d2fab109d425bcdfffd462b0c17ea273dbea45d8aa0493e54d2")
