-- Lua provided by RyzenAPI
-- Game: 2718780

-- MAIN APPLICATION
addappid(2718780)
-- Game: addappid(2718780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718780,0,"6e48e73ca069c5f6e6aa968730f441f30d4afd8aa3b8c4372305eb6a051c589e")
