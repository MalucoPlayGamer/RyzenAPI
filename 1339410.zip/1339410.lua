-- Lua provided by RyzenAPI
-- Game: AppID 1339410

-- MAIN APPLICATION
addappid(1339410)
addappid(2078000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339411, 1, "d70381c730fb6c5609bce75daa7893ef232d3f213f40f1e5f7fad70f4fbef802")
