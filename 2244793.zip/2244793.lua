-- Lua provided by RyzenAPI
-- Game: 2244793

-- MAIN APPLICATION
addappid(2244793)
-- Game: addappid(2244793)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244793,0,"19de5ac123210d5be995762ef2010a48c62e6160f6294f5c1e59eb501e5ee0de")
