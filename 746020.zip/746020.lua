-- Lua provided by RyzenAPI
-- Game: Pit of Evil

-- MAIN APPLICATION
addappid(746020)

-- MAIN APP DEPOTS / PACKAGES
addappid(746021, 1, "1e9857e0cbd3022bf9645c61aa956d16cabc397a7123965ff178d09edbd5a31e")
addappid(746022, 1, "adf0ff3c056defae7859dd7f3b935c9a0e97145d91f01912d5a2298ebf656067")
