-- Lua provided by SkyAPI 
-- Game: AppID 315540
addappid(315540)
addappid(315541, 1, "29b49c30cd2fcc15bf2e08186c9ba57d513dd9122e1fcbb88e5a5b0f199f097a")
