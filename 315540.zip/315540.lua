-- Lua provided by RyzenAPI
-- Game: AppID 315540

-- MAIN APPLICATION
addappid(315540)

-- MAIN APP DEPOTS / PACKAGES
addappid(315541, 1, "29b49c30cd2fcc15bf2e08186c9ba57d513dd9122e1fcbb88e5a5b0f199f097a")

