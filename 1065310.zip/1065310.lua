-- Lua provided by RyzenAPI
-- Game: AppID 1065310

-- MAIN APPLICATION
addappid(1065310)
addappid(1997840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1065311, 1, "fad466752e88e3caf8ad1aa7d471043f04aa0ae7c0074b107fb4c53af267f8f6")

