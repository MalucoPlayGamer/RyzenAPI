-- Lua provided by SkyAPI 
-- Game: AppID 1065310
addappid(1065310)
addappid(1065311, 1, "fad466752e88e3caf8ad1aa7d471043f04aa0ae7c0074b107fb4c53af267f8f6")
