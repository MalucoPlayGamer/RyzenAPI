-- Lua provided by RyzenAPI
-- Game: 1065310

-- MAIN APPLICATION
addappid(1065310)
-- Game: addappid(1065310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065311, 1, "fad466752e88e3caf8ad1aa7d471043f04aa0ae7c0074b107fb4c53af267f8f6")
