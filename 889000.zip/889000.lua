-- Lua provided by RyzenAPI
-- Game: Paralines The Last paladin Original Sound Track

-- MAIN APPLICATION
addappid(889000)
-- Game: addappid(889000)

-- MAIN APP DEPOTS / PACKAGES
addappid(889000,0,"7a0d4c2370c01661d80f164520cc463169388d894cbd179a4e62c66c7af07677")
