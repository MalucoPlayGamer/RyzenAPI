-- Lua provided by RyzenAPI
-- Game: Banebush Soundtrack

-- MAIN APPLICATION
addappid(3452200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452201, 1, "a96bcd1f1e028bf0d898fead4d75805ee9981acb61573c8ce4edb58c6863c72d")
