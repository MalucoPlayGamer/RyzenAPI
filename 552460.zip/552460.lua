-- Lua provided by RyzenAPI
-- Game: Serious Sam VR: The Second Encounter

-- MAIN APPLICATION
addappid(552460)
-- Game: addappid(552460)

-- MAIN APP DEPOTS / PACKAGES
addappid(552461, 1, "1f0e53b4e2039f47b4024de82de6f18d842625439c59cb1d08989e6f74d17bb9")
addappid(552462, 1, "08c1023779279e1c2a32e300e2dbf9ad1dc8071032c72b8f1d224d24d32b276a")
addappid(552463, 1, "2499a330e96d114d72fe91c2a1dddb652315c4b804b682be2e98894731768aef")
addappid(552464, 1, "d3dd79a29d4398c6667e02bce815eff455da4b101b87a05ec52e43abaed011e5")
addappid(552465, 1, "bfceeda6498faa8e2af5deb38ecf78ada4fbf68b5ce8ccf9c1eb5edc7a970c72")
addappid(552466, 1, "8b875d93c8ba57f1f565f41247f0e88a765cb9fbe570627caeee854e5cbefa15")
addappid(552468, 1, "2cb501dde448b40318ab84b3ac66edb1504a345556468be8733045ee5f5e5649")
addappid(552469, 1, "771a4364bb69f8c8cd2d14af0f3e664f12886582f692b8d5e70b334c172af6c2")
addappid(574300, 0, "6f46089f904f487dfeefa4b13c1457a5d670c586e4b5e807ea8731d012ff7f24")
