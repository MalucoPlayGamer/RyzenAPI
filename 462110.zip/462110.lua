-- Lua provided by RyzenAPI
-- Game: 3 Coins At School

-- MAIN APPLICATION
addappid(462110)
-- Game: addappid(462110)

-- MAIN APP DEPOTS / PACKAGES
addappid(462111, 1, "640e08c7c17145202ebe76d935ce5e8f207305b2ad2277bfa419be3ad42ba6c9")
