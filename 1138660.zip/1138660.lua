-- Lua provided by RyzenAPI
-- Game: AppID 1138660

-- MAIN APPLICATION
addappid(1138660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138661, 1, "69d40dd62002773f5068d9bf5011c0ba1cab563afd9be3fabf35e577c83958af")
addappid(1138662, 1, "38a7a74f8d586614df317d4aade0718a6081f02cf4b4fd818421937a90aad147")
addappid(1138663, 1, "2bbc9af27b86c3163b5505ef62c88b3ec85b50bae89ff287974dd4cd51acc78c")
addappid(1535180, 0, "fe40a548965a20a3752a8b668c5cd2cc56ae3f7671bc546f360617fe644e803a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1879710)
