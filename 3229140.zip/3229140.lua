-- Lua provided by RyzenAPI
-- Game: Echoes Of The House

-- MAIN APPLICATION
addappid(3229140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229141, 1, "0daca8e1cc3ec8afd8448a4c935ee9a269908d265283eb262110ffc05e851300")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
