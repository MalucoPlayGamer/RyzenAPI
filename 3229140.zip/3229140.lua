-- Lua provided by RyzenAPI
-- Game: addappid(3229140)

-- MAIN APPLICATION
addappid(3229140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229141, 1, "0daca8e1cc3ec8afd8448a4c935ee9a269908d265283eb262110ffc05e851300")
