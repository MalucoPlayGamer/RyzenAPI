-- Lua provided by RyzenAPI
-- Game: Space Hulk: Deathwing

-- MAIN APPLICATION
addappid(298900)
addappid(523990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(298901, 1, "e4664380d87531974e5245e864dede7953cefc675e31e1852742a4479477ab95")
addappid(298902, 1, "393bf82e73e0fbb213f9c3283866b3899594c12fba204f52b8bb07bf4812748a")
addappid(298903, 1, "8bd1ca8c6f49a0b2bdc1f7a3aa320fc5f14fea39ccff6adca7580e9fc20accfb")

