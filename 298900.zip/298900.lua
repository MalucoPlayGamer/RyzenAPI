-- Lua provided by RyzenAPI 
-- Game: Space Hulk: Deathwing
addappid(298900)
addappid(298901, 1, "e4664380d87531974e5245e864dede7953cefc675e31e1852742a4479477ab95")
addappid(298902, 1, "393bf82e73e0fbb213f9c3283866b3899594c12fba204f52b8bb07bf4812748a")
addappid(298903, 1, "8bd1ca8c6f49a0b2bdc1f7a3aa320fc5f14fea39ccff6adca7580e9fc20accfb")
addappid(523990)
