-- Lua provided by RyzenAPI
-- Game: Alien Rage - Unlimited

-- MAIN APPLICATION
addappid(217920)
addappid(228981)
addappid(228982)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(217921, 1, "a9fe85d4407e5f811e6c86a3b4a5c0968f9a0a4fd73f7ef4ba7ab946926dccac")
addappid(217922, 1, "05700ddc99d745c557b852d3e904ced2c1d8fb4ef8ec95b0497c4ab209928f73")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(256100)
