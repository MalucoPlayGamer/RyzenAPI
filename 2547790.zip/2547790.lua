-- Lua provided by RyzenAPI
-- Game: Closing Shift

-- MAIN APPLICATION
addappid(2547790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547791, 1, "054aa956663977808a3aee4c7bf51bbabb550e0a55504125883bc162e34b90cf")

