-- Lua provided by RyzenAPI
-- Game: Insanity's Grip

-- MAIN APPLICATION
addappid(2510170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510171, 1, "4cdd8759fa66b9af303618504ffde7201cec7684d57ee5720b2177d535e09b6f")
