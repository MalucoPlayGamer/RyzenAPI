-- 3039180's Lua and Manifest Created by Hubcap Manifest
-- DeepDig: Together
-- Created: August 03, 2026 at 19:22:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3039180) -- DeepDig: Together
-- MAIN APP DEPOTS
addappid(3039182, 1, "0fdb334925e223f078d0bed2a46976fb951ae8189d12c3b221a2acbc05450011") -- Depot 3039182
setManifestid(3039182, "7872354301400848987", 306150744)
addappid(3039183, 1, "ebbd7fc3531c0c63508451294cd412e1de50c83669d95f21619ada32d69188b0") -- Depot 3039183
setManifestid(3039183, "7976012416405786832", 271221616)