-- Lua provided by RyzenAPI
-- Game: DeepDig: Together

-- MAIN APPLICATION
addappid(3039180) -- DeepDig: Together

-- MAIN APP DEPOTS / PACKAGES
addappid(3039182, 1, "0fdb334925e223f078d0bed2a46976fb951ae8189d12c3b221a2acbc05450011") -- Depot 3039182
addappid(3039183, 1, "ebbd7fc3531c0c63508451294cd412e1de50c83669d95f21619ada32d69188b0") -- Depot 3039183

