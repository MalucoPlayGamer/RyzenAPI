-- Lua provided by RyzenAPI
-- Game: It Runs Red

-- MAIN APPLICATION
addappid(1068980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068981, 1, "30d2df06020aa20fd084733a1e60b162bfff9792080d2f9ff6d89ab0c78be39d")

