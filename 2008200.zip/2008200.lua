-- Lua provided by RyzenAPI
-- Game: Ashen Knights: Foreshadow

-- MAIN APPLICATION
addappid(2008200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008201, 1, "6F0524FAE018C54A781942C3EC6F3BEBC1A637A740915FE9D8A3ACFA61F55879")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
