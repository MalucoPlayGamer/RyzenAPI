-- Lua provided by RyzenAPI
-- Game: 幻想乡之玉 Demo

-- MAIN APPLICATION
addappid(2783590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783591, 1, "d338d4df751f18b578a394f309c3cfa2ac434d228558d12c55d2e42b6306a97d")

