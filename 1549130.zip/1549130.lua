-- Lua provided by RyzenAPI
-- Game: 1549130

-- MAIN APPLICATION
addappid(1549130)
-- Game: addappid(1549130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549131, 1, "d708f1addee2ae6d51722c07395f1d4fb307c8c3e1447966ab6bdfd67309114f")
