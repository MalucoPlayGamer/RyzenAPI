-- Lua provided by RyzenAPI
-- Game: Silly's Gameshow

-- MAIN APPLICATION
addappid(3674050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3674051, 1, "c1342b4678b38ee2541fd5416105ab55e7a9a9bc1393070b4154d2278d0cf3f4")
