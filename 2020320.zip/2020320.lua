-- Lua provided by RyzenAPI
-- Game: Gunner, HEAT, PC! Demo

-- MAIN APPLICATION
addappid(2020320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020321, 1, "4cdb92eee54b8fa5d1dec020e6f99f9b0b1bc88fd5a07fa50bd7ae1d79052a98")
