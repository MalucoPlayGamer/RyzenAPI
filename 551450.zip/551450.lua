-- Lua provided by RyzenAPI
-- Game: Furious Angels

-- MAIN APPLICATION
addappid(551450)

-- MAIN APP DEPOTS / PACKAGES
addappid(551451,0,"77cc6402278567ea05b2d76048b56207a319eeab4068ee26ff090419d0883d1e")
addappid(551452,0,"3ecf5dcabd1271386c29ad71e684b7ea119bcc49ff62c7a4c8346046b7d594ec")

