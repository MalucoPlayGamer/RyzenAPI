-- Lua provided by RyzenAPI
-- Game: 2477200

-- MAIN APPLICATION
addappid(2477200)
-- Game: addappid(2477200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477201, 1, "01737fe742b2a902fd6007581b83007d4abd6c2fab2dc28d919ed9418c08b1b4")
