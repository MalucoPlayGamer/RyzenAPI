-- Lua provided by RyzenAPI
-- Game: Game: AppID 2668340

-- MAIN APPLICATION
addappid(2668340)
-- Game: addappid(2668340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668341, 1, "ab54e2b22212dcab07f1cede413db8151bbe4c01fdb8f21b29f7f01cc56fca02")
