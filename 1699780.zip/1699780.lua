-- Lua provided by RyzenAPI
-- Game: 1699780

-- MAIN APPLICATION
addappid(1699780)
-- Game: addappid(1699780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699781, 1, "68def674549e52adfd6bfdab60a5d1b14bd53f13339f99a4e6eb83b5f2d2fcf8")
