-- Lua provided by RyzenAPI
-- Game: 東方苦粗緑 Touhou KSG RPG (Project ONe add-on levels)

-- MAIN APPLICATION
addappid(1098880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098880,0,"60064bc02a5d73a2a43bdfd2233496e92e7878a2d527f75c5418123076e4a1c2")

