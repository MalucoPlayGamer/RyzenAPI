-- Lua provided by RyzenAPI
-- Game: You Will Die Here Tonight

-- MAIN APPLICATION
addappid(1446350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446352,0,"44b8e72e2f4a08a2b1beea145f260fa395f691b54fba8f44c5d7a7edc8e03434")

