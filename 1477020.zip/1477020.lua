-- Lua provided by RyzenAPI 
-- Game: Wordle 4
addappid(1477020)
addappid(1477021, 1, "9278a7f77d49a3f73899aa2b3e15ea00c60a2c8845da5a67d5392870ad480c77")
