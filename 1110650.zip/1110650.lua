-- Lua provided by RyzenAPI
-- Game: addappid(1110650)

-- MAIN APPLICATION
addappid(1110650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110652,0,"19aa1b5b7f80bb2826c3b1fc0fa8a16a8baffd3683df57bb264ac3b502b50619")
