-- Lua provided by RyzenAPI
-- Game: Dungeons 4 - Original Soundtrack

-- MAIN APPLICATION
addappid(2605810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605811, 1, "b60dcc7c2f61067fe182ef7ec6ca62fe89b90cd7511d8470446ff5978dcb6c42")
addappid(2605812, 1, "475f821dfc6ee893a5cb1dd0b4aa7f21e93af53903d47abb1ba0917443dff621")
