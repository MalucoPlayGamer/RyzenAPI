-- Lua provided by RyzenAPI
-- Game: Monmusu Island

-- MAIN APPLICATION
addappid(4326550)

-- MAIN APP DEPOTS / PACKAGES
addappid(4326551,0,"36afc3cd36502a115c1117a786ee4dbef7567f25f30f3f4032aa591d9b698e7f")

