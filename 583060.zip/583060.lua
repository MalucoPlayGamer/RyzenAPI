-- Lua provided by RyzenAPI
-- Game: 583060

-- MAIN APPLICATION
addappid(583060)
-- Game: addappid(583060)

-- MAIN APP DEPOTS / PACKAGES
addappid(583061, 1, "9122637cb40d4195354a2d1e2c06a383497ebe2745833baa6e40c061903ab14b")
