-- Lua provided by RyzenAPI
-- Game: LUST & MAGIC ✨

-- MAIN APPLICATION
addappid(3424900)
-- Game: addappid(3424900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424901, 1, "651198a2cf35cc02dc77f0386b9629de76b82c54fc05c864f4cab88a4448c067")
