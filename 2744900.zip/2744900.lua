-- Lua provided by RyzenAPI
-- Game: addappid(2744900)

-- MAIN APPLICATION
addappid(2744900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744901, 1, "7b05737afe82ea46a9f48e51d57cac34d88aab0078dc5d629410120777915d55")
