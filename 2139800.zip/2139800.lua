-- Lua provided by RyzenAPI
-- Game: 2139800

-- MAIN APPLICATION
addappid(2139800)
-- Game: addappid(2139800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139801, 1, "bd1dd3073ada31087add83a145f70f0fbe84d63187c4a91cffdb48d59627b33a")
