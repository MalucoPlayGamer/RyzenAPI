-- Lua provided by RyzenAPI
-- Game: Orcen Axe

-- MAIN APPLICATION
addappid(2139800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139801, 1, "bd1dd3073ada31087add83a145f70f0fbe84d63187c4a91cffdb48d59627b33a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
