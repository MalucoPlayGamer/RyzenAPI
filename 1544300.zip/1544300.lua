-- Lua provided by RyzenAPI
-- Game: Super Can Cannon

-- MAIN APPLICATION
addappid(1544300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544301, 1, "2611a8d39e3f98d5ebf977ba66433fc07f33d09b8171669ce7f43cdcf205afdd")

