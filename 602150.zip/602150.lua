-- Lua provided by RyzenAPI
-- Game: Desert Battle

-- MAIN APPLICATION
addappid(602150)

-- MAIN APP DEPOTS / PACKAGES
addappid(602151,0,"1ac033b0e3591d83df57a58d37aefe596c5e5b231c9d9abaa6b49b3d625c5e59")

