-- Lua provided by RyzenAPI
-- Game: 101 Cats in Bangkok

-- MAIN APPLICATION
addappid(3440240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440241, 1, "915d99efbb007556fa35acaeb7aeb726b72252465f1bd9abe268acc7028da57c")

