-- Lua provided by RyzenAPI
-- Game: Diesel Legacy: The Brazen Age Demo

-- MAIN APPLICATION
addappid(2296440)
-- Game: addappid(2296440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296441, 1, "4af82f21c57701e7d918cf3f2bd76eb90b007ce2dae2f4c5383bc6b08b02a2fb")
