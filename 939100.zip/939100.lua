-- Lua provided by RyzenAPI
-- Game: Darksburg

-- MAIN APPLICATION
addappid(939100)

-- MAIN APP DEPOTS / PACKAGES
addappid(939101, 1, "2d0a76d30b1a84715b229e681ba75d25cb6dd107a9099a5bd323bd3c28c3fe6e")

