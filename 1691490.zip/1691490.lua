-- Lua provided by RyzenAPI
-- Game: Game: Elemental colossus

-- MAIN APPLICATION
addappid(1691490)
-- Game: addappid(1691490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691491, 1, "71a12b8a4a250f82964b71e7c12de0104fc6a281168b49eb837d577227df817b")
