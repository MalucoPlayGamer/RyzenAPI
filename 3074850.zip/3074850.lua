-- Lua provided by RyzenAPI
-- Game: Utawarerumono: ZAN 2

-- MAIN APPLICATION
addappid(3074850)
addappid(4147440)
addappid(4147450)
addappid(4147460)
addappid(4147470)
addappid(4147480)
addappid(4147490)
addappid(4147500)
addappid(4147510)
addappid(4147520)
addappid(4147530)
addappid(4147540)
addappid(4147550)
addappid(4147560)
addappid(4147570)
addappid(4147580)
addappid(4147590)
addappid(4147600)
addappid(4147610)
addappid(4147620)
addappid(4147630)
addappid(4147750)
addappid(4147760)
addappid(4270400)
addappid(4270410)
-- Game: addappid(3074850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074851, 1, "31c70f9c048a144e17fd913a134c05824d14ac07da176e32a6b8d3311fd2855d")
