-- Lua provided by RyzenAPI
-- Game: I Shall Remain

-- MAIN APPLICATION
addappid(293460)

-- MAIN APP DEPOTS / PACKAGES
addappid(293461, 1, "a57cc0f75804802a44c839194f8958818e4e20d1afed68fb8a5c89e5fbb94127")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
