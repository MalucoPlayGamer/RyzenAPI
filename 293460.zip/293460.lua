-- Lua provided by RyzenAPI
-- Game: I Shall Remain

-- MAIN APPLICATION
addappid(293460)

-- MAIN APP DEPOTS / PACKAGES
addappid(293461, 1, "a57cc0f75804802a44c839194f8958818e4e20d1afed68fb8a5c89e5fbb94127")
