-- Lua provided by RyzenAPI
-- Game: addappid(1375280)

-- MAIN APPLICATION
addappid(1375280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375282,0,"abf4122b6ee3970f388a2693cd5a17677db85a3ed73ca5cd17fc4d90e86c4d10")
