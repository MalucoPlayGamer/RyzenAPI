-- Lua provided by RyzenAPI
-- Game: Game: Champy the Useless Vampire

-- MAIN APPLICATION
addappid(2426350)
-- Game: addappid(2426350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426351, 1, "b7e0bc9d1e199e36a168f2ca64c741bae9747c45bb7cb4ed8b75d279ce9b5533")
