-- Lua provided by SkyAPI 
-- Game: Ascent
addappid(1682620)
addappid(1682621, 1, "6c18e71743f566766093c5f6d0c60097d2a60b88bb520cad0e87a5287894bd3d")
