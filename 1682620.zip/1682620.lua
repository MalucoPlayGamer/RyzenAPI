-- Lua provided by RyzenAPI
-- Game: Game: Ascent

-- MAIN APPLICATION
addappid(1682620)
-- Game: addappid(1682620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682621, 1, "6c18e71743f566766093c5f6d0c60097d2a60b88bb520cad0e87a5287894bd3d")
