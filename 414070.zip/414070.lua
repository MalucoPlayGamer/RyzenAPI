-- Lua provided by RyzenAPI
-- Game: Shut Up And Dig

-- MAIN APPLICATION
addappid(414070)

-- MAIN APP DEPOTS / PACKAGES
addappid(414071, 1, "52d126dcc19456a25c774b1380918042b84eb623e9d931dded4653c841ef125d")

