-- Lua provided by SkyAPI 
-- Game: AppID 414070
addappid(414070)
addappid(414071, 1, "52d126dcc19456a25c774b1380918042b84eb623e9d931dded4653c841ef125d")
