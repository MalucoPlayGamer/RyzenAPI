-- Lua provided by RyzenAPI 
-- Game: Concept Destruction
addappid(1153540)
addappid(1153541, 1, "230e2fe08a90bef8ba2c63e4b4ccbdc560ad3300202e0f010a4f8f7560dfacee")
