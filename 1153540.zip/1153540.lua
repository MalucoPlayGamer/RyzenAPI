-- Lua provided by RyzenAPI
-- Game: Concept Destruction

-- MAIN APPLICATION
addappid(1153540)
-- Game: addappid(1153540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153541, 1, "230e2fe08a90bef8ba2c63e4b4ccbdc560ad3300202e0f010a4f8f7560dfacee")
