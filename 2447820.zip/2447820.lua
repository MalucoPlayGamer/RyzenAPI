-- Lua provided by SkyAPI 
-- Game: Survivor's guilt
addappid(2447820)
addappid(2447821, 1, "a46eb115612c5e0ca37a947d6cbe7db4cc9eaf2190271b1de8306e3d37d0b68b")
