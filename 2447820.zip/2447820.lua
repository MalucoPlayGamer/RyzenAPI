-- Lua provided by RyzenAPI
-- Game: Survivor's guilt

-- MAIN APPLICATION
addappid(2447820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447821, 1, "a46eb115612c5e0ca37a947d6cbe7db4cc9eaf2190271b1de8306e3d37d0b68b")
