-- Lua provided by RyzenAPI 
-- Game: AppID 1715380
addappid(1715380)
addappid(1715381, 1, "115747be5827dc0e1d60b9469539dd5c45989bb994accd55cc473eb22b1e5c8b")
