-- Lua provided by RyzenAPI
-- Game: Megania Online

-- MAIN APPLICATION
addappid(1715380)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1715381, 1, "115747be5827dc0e1d60b9469539dd5c45989bb994accd55cc473eb22b1e5c8b")
