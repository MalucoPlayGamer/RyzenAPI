-- Lua provided by RyzenAPI
-- Game: addappid(629730)

-- MAIN APPLICATION
addappid(629730)

-- MAIN APP DEPOTS / PACKAGES
addappid(629731, 1, "d545f9c050f40882240b3a912f0ff28459b1cef3f95099c86c74a67d0a0e1541")
