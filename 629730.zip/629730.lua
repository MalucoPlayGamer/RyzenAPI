-- Lua provided by SkyAPI 
-- Game: Blade and Sorcery
addappid(629730)
addappid(629731, 1, "d545f9c050f40882240b3a912f0ff28459b1cef3f95099c86c74a67d0a0e1541")
