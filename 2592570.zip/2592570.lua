-- Lua provided by RyzenAPI
-- Game: Pixel Colony Demo

-- MAIN APPLICATION
addappid(2592570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2592571, 1, "8102f8d9ba4396bb2177a109160db5e28968f861bd91d419b8867ab124d4e9ca")
