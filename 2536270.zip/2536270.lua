-- Lua provided by RyzenAPI 
-- Game: Everholm Demo
addappid(2536270)
addappid(2536271, 1, "f44032d23c71a6a3ab421d68a9a9d4e7753cf3285e097255a967ece4687a6424")
