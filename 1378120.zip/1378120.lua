-- Lua provided by RyzenAPI
-- Game: Fairy Godmother Stories: Dark Deal Collector's Edition

-- MAIN APPLICATION
addappid(1378120)
-- Game: addappid(1378120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378121, 1, "74d8081e623c4070d836a45cd679d161bb70393a038b5d446ecb67607e67e3d3")
