-- Lua provided by RyzenAPI
-- Game: Descent Vector: Space Runner

-- MAIN APPLICATION
addappid(1580380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580381, 1, "897a83ea8941f7a5aa5773f55fc93bb974522d5aa544ed758ec1908ecffecaff")
addappid(1580382, 1, "dc64ba785dc1a6b8e8a8aaf24c518bd28c0ef5e82cd4597ce1e917bb1216aeb1")
