-- Lua provided by RyzenAPI
-- Game: addappid(2761200)

-- MAIN APPLICATION
addappid(2761200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761201, 1, "6a8e10a73516690e9e59cd10dd52664a1ab1b96abad67bf90de25cc4306b67e7")
