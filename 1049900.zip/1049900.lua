-- Lua provided by RyzenAPI
-- Game: 1049900

-- MAIN APPLICATION
addappid(1049900)
-- Game: addappid(1049900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049900,0,"2255d0870f9e67b9ed1617ab4be45a8cd6d4a4a142a81d6e587b31706cf7c4c5")
