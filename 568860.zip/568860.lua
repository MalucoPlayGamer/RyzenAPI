-- Lua provided by RyzenAPI 
-- Game: Psycho on the loose
addappid(568860)
addappid(568861, 1, "250d4f791eafdb31644fbefce4fb9a487ff54925792a15c0a4756a4c63d2f6bd")
