-- Lua provided by RyzenAPI
-- Game: addappid(956899)

-- MAIN APPLICATION
addappid(956899)

-- MAIN APP DEPOTS / PACKAGES
addappid(956899,0,"d214d2d9b4d3f1f4ffd95c6528dd745fce72a9985f2d1411547effb1ab3b38b8")
