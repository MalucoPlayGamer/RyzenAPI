-- Lua provided by RyzenAPI
-- Game: Hentai Direct-Her

-- MAIN APPLICATION
addappid(2541370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541371, 1, "1e46529eeae0590383e37f9048fd46fc31fb4b49147c5c094b9565341aa1face")
