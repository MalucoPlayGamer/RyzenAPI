-- Lua provided by RyzenAPI
-- Game: Get Tanked!

-- MAIN APPLICATION
addappid(1679800)
-- Game: addappid(1679800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679801, 1, "2807fd433a05e161b30774b451dde49babd6c9942ce0c745094938104b80c4a7")
