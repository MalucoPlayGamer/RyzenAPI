-- Lua provided by SkyAPI 
-- Game: Westerado: Double Barreled
addappid(275200)
addappid(275201, 1, "e0ec077b84d4a5ac49261ed0d91456de4beff66f335f06fc38dda89b2fb74e17")
addappid(275202, 1, "3e3bf7a9fafd7f630ebb650da46b8889ec5db75a35f0df93ea0d73537c4df0e1")
