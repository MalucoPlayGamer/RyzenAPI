-- Lua provided by RyzenAPI
-- Game: Sumatra: Fate of Yandi

-- MAIN APPLICATION
addappid(610900)

-- MAIN APP DEPOTS / PACKAGES
addappid(610901, 1, "e8583531660764cb7fe101ed94e30992b5050f8f692eff286cff8a1f02dbff46")
addappid(1078890, 0, "ca612a63829515206a5801d33fd5591ea6e4d8107807c16c4230ac1f02bb5640")
