-- Lua provided by RyzenAPI
-- Game: Sumatra: Fate of Yandi

-- MAIN APPLICATION
addappid(610900)

-- MAIN APP DEPOTS / PACKAGES
addappid(610901, 1, "e8583531660764cb7fe101ed94e30992b5050f8f692eff286cff8a1f02dbff46")
addappid(1078890, 0, "ca612a63829515206a5801d33fd5591ea6e4d8107807c16c4230ac1f02bb5640")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
