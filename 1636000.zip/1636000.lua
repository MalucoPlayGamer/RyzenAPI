-- Lua provided by RyzenAPI
-- Game: Tybot Invasion: The Typing Runner

-- MAIN APPLICATION
addappid(1636000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636001, 1, "9ae8ad0a1a67db52f1ba2d4bde34665a9d093955cb84dc5e4e6db55cc06f9909")
