-- Lua provided by SkyAPI 
-- Game: Wren's Resurgence
addappid(2728260)
addappid(2728261, 1, "584a890467ed6058f0af3058ceb0ef9187fc2f14ca89de36815db055e1a5d659")
