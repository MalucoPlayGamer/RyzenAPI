-- Lua provided by RyzenAPI 
-- Game: Faraway: Puzzle Escape
addappid(883880)
addappid(883881, 1, "827397b34bbfe6af9f5926d67d82c0ae9c4fa9172fe9f651a35aed363ac2f45a")
