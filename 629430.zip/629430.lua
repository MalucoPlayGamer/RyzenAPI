-- Lua provided by RyzenAPI
-- Game: addappid(629430)

-- MAIN APPLICATION
addappid(629430)
addappid(633330)
addappid(633331)

-- MAIN APP DEPOTS / PACKAGES
addappid(629431, 1, "671364cbc8fce8bdd0a185713cef8df962f967c922bf6b2d48a87dea03beb2f4")
