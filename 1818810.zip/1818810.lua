-- Lua provided by RyzenAPI
-- Game: addappid(1818810)

-- MAIN APPLICATION
addappid(1818810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818811, 1, "d3a762e822b40be9f50f740c5236240e44f55b370a805e98ed7a10f3c3cd5698")
