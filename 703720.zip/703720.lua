-- Lua provided by RyzenAPI
-- Game: AppID 703720

-- MAIN APPLICATION
addappid(703720)

-- MAIN APP DEPOTS / PACKAGES
addappid(703721, 1, "df4eaeac96dd050ff7cd409bb5a9dfc151ec0054c0a29d5759c4dfcd55cb85e9")
addappid(704600, 0, "fa322381cf4086066aea0f3aded98925fe444d36f6e02e969ea133fbac164621")
