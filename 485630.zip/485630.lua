-- Lua provided by SkyAPI 
-- Game: Brazed
addappid(485630)
addappid(485631, 1, "4b98f322915076f096c5603920ecb42a5e8b95bdbdcf1477d0e93ee74f142cad")
