-- Lua provided by RyzenAPI
-- Game: Speed Crew Demo

-- MAIN APPLICATION
addappid(2405520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405521, 1, "09ddff9074b1cea1cf00105519203de7f54c4a03a2235bb52b8f8d24fad71b5b")

