-- Lua provided by RyzenAPI
-- Game: Alchemist's Castle

-- MAIN APPLICATION
addappid(726340)

-- MAIN APP DEPOTS / PACKAGES
addappid(726341, 1, "9c1722f14b785699720cf8528653e047ee0677b7202c1318eb2adcecb8f3bb12")
addappid(726342, 1, "b2631c928eb5d01db64843ea7e9206eaf85664634718bbcae7a0acd1ddfb4c1c")
addappid(726343, 1, "c8f1c131b11c764109aad58c42d6e85240515f591143470e81e9da84bab6cf9d")
