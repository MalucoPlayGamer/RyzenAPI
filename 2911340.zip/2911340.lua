-- Lua provided by RyzenAPI
-- Game: Game: Mound of Music

-- MAIN APPLICATION
addappid(2911340)
-- Game: addappid(2911340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911341, 1, "1daf42a40c41a229c7da71aa5ce40f1ab507d4bedca6a1c75cad3229018f33cf")
