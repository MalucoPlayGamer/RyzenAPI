-- Lua provided by RyzenAPI
-- Game: addappid(2966850)

-- MAIN APPLICATION
addappid(2966850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966851, 1, "0c7cc7204dc7a30359eab52bf0a87d45c2f269e869c4807174017100c63df61c")
