-- Lua provided by RyzenAPI
-- Game: 50910

-- MAIN APPLICATION
addappid(50910)
-- Game: addappid(50910)

-- MAIN APP DEPOTS / PACKAGES
addappid(50911, 1, "5f372a87bbd246fe76d9bbe78d3a4a301e20e5f4b737bc02d0177df4d0069d45")
