-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost in Turkey Find & Color

-- MAIN APPLICATION
addappid(3809570)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4021810)
