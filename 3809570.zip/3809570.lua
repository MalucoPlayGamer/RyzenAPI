-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost in Turkey Find & Color

-- MAIN APPLICATION
addappid(3809570)

