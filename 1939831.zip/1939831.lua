-- Lua provided by RyzenAPI
-- Game: addappid(1939831)

-- MAIN APPLICATION
addappid(1939831)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939831,0,"775b8361f1e89ec881ac37b32d04aada9db4b03d98a9f5df1c0a4789dc90d79e")
