-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Daqiao (High school girls Costume) / 大喬 「女子高生風コスチューム」

-- MAIN APPLICATION
addappid(964932)

-- MAIN APP DEPOTS / PACKAGES
addappid(964932,0,"798d36c9c506c1d9d08db439a038c7cd59ddb7bab9f12ca30c408a104828d251")
