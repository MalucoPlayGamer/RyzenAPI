-- Lua provided by RyzenAPI
-- Game: addappid(964932)

-- MAIN APPLICATION
addappid(964932)

-- MAIN APP DEPOTS / PACKAGES
addappid(964932,0,"798d36c9c506c1d9d08db439a038c7cd59ddb7bab9f12ca30c408a104828d251")
