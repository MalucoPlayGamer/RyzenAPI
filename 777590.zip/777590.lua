-- Lua provided by RyzenAPI
-- Game: AppID 777590

-- MAIN APPLICATION
addappid(777590)
-- Game: addappid(777590)

-- MAIN APP DEPOTS / PACKAGES
addappid(777591, 1, "efa77f32184200d4831d5a083a9bb554a8fc3f7a7900c6a6b97eab57dd8d7341")
