-- Lua provided by RyzenAPI
-- Game: 词力牌：LexiLoong

-- MAIN APPLICATION
addappid(3758650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3758651, 1, "468598f2fbae6d83915ebeb292e77a29f24e976c670e0011ea7608084c5be712")

