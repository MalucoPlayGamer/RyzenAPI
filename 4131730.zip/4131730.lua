-- Generated with Luie @ https://lua.tools/
-- 4131730 - VHOLUME
-- Generated 2026-08-22 04:38:27 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(4131730)

-- Main Depots
addappid(4131731, 1, "434664fa58d5cf2b3058734a738903a03b70148afe8f2fac9e04043808fe8ede") -- (windows)
setManifestid(4131731, "4328666819561454240", 5968721954)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- Token-locked DLCs (couldn't read depots): 5133400
