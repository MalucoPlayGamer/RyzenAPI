-- Lua provided by RyzenAPI
-- Game: Milo and the Christmas Gift

-- MAIN APPLICATION
addappid(2716140)
-- Game: addappid(2716140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716141, 1, "d3b87712169c9aa7d73d65617f02ca26f7361b4dc51f24584cd1c9c9576c71f6")
addappid(2716142, 1, "151437fd9530c705a9511989f0d3a94aa089bcc26fe7b71144b36ebff3c31a30")
