-- Lua provided by RyzenAPI
-- Game: Game: Self-Isolation

-- MAIN APPLICATION
addappid(1298530)
-- Game: addappid(1298530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298531, 1, "9fa9d22093f66bc16036d5cf5409b75a348c8139bc03336231777a639f8afe2b")
