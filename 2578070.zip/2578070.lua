-- Lua provided by RyzenAPI
-- Game: Ending Tau Demo

-- MAIN APPLICATION
addappid(2578070)
-- Game: addappid(2578070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578071, 1, "962b2346af149d8d40212ae2b78e32a1015a4b0b40e88777a36e6564490fc8e0")
