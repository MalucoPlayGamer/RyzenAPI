-- Lua provided by RyzenAPI
-- Game: 2783300

-- MAIN APPLICATION
addappid(2783300)
-- Game: addappid(2783300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783302,0,"8e74ec3bdcb07bee1e9f1d9f0d45716a08db64e6b2b46181921978bbd761a5e4")
addappid(2783303,0,"bdba326eb5ed80fd20cde6154c41d30df27ebb8d002f1e64a85d813dfa097779")
