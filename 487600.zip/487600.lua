-- Lua provided by RyzenAPI
-- Game: Puzzles Under The Hill

-- MAIN APPLICATION
addappid(487600)

-- MAIN APP DEPOTS / PACKAGES
addappid(487601, 1, "cdd4aaa6ee923b21d71a683fb832b27867d2b140b4ff695992d1aa7a4f11b774")
