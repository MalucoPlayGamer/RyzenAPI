-- Lua provided by RyzenAPI
-- Game: addappid(2623820)

-- MAIN APPLICATION
addappid(2623820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623820,0,"809b45f193dfe6a30e3b0a39af499d81c9334dc94ef4327f8ce49ee7c8af4860")
