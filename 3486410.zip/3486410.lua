-- Lua provided by RyzenAPI 
-- Game: Threefold Recital Soundtrack
addappid(3486410)
addappid(3486411, 1, "2e76a4c2e623c95f411d7444c0f873f53a21835b24d9733b94de649414e6315b")
