-- Lua provided by RyzenAPI
-- Game: Game: Threefold Recital Soundtrack

-- MAIN APPLICATION
addappid(3486410)
-- Game: addappid(3486410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3486411, 1, "2e76a4c2e623c95f411d7444c0f873f53a21835b24d9733b94de649414e6315b")
