-- Lua provided by RyzenAPI
-- Game: Beat Saber - Fall Out Boy - 'My Songs Know What You Did In The Dark (Light Em Up)'

-- MAIN APPLICATION
addappid(1939835)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939835,0,"18a987fcfdd13f65b9c5e10a5dd69c28306d1fe0c6dfe40b0ca7b6142f58e23f")
