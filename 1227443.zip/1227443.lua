-- Lua provided by RyzenAPI
-- Game: RetroArch - Stella

-- MAIN APPLICATION
addappid(1227443)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227443,0,"2bdc314a3aeedb5f66601213a666466f34d9e6670d580364d1dead207177b92a")
addappid(1656160,0,"40c250f5c501d3d5f8277ee996685c216240bb668b5bcabfbf43a5238600ac63")
addappid(1656161,0,"1eed6a499b6bfb81c5794c2d8f5d9296dbb7f73b437dd97b1cfe5bd5de0cc6b6")

