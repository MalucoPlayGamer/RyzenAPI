-- Lua provided by RyzenAPI
-- Game: 899903

-- MAIN APPLICATION
addappid(899903)
-- Game: addappid(899903)

-- MAIN APP DEPOTS / PACKAGES
addappid(899903,0,"22d018e4d9d83b94aabd368871d73724e82b14c03c87aeada1a2777a605714e1")
