-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Mini Mixed Trivia 3

-- MAIN APPLICATION
addappid(710110)

-- MAIN APP DEPOTS / PACKAGES
addappid(710111, 1, "e5052325e2eed883be67a1a30405a68349b8ee56f5d04fe6fb94336c9ce15403")

