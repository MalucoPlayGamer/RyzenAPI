-- Lua provided by RyzenAPI
-- Game: 1378460

-- MAIN APPLICATION
addappid(1378460)
-- Game: addappid(1378460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378460,0,"7ac83c8d50ddab84e6d3c82c965b9c3940980ba844f978bd54cccb309256a0ef")
