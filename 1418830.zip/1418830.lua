-- Lua provided by RyzenAPI
-- Game: addappid(1418830)

-- MAIN APPLICATION
addappid(1418830)
addappid(1418900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418831, 1, "0046411f71e896a9da6b0ea3c29eeec338da16c61c35f2dce80c2374e8765826")
