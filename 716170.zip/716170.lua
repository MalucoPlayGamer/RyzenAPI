-- Lua provided by RyzenAPI
-- Game: addappid(716170)

-- MAIN APPLICATION
addappid(716170)

-- MAIN APP DEPOTS / PACKAGES
addappid(716171, 1, "2b188b48b2f4f4fae49dba3a5e9b779080a54b8a9a39315e17cea8a1eb7b6327")
