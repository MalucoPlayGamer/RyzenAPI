-- Lua provided by RyzenAPI
-- Game: Crabs Dive In Crossway Demo

-- MAIN APPLICATION
addappid(3328570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328571, 1, "4186c29f510f84ec928b96fbf86962b552a3d0a19584b659411f04225c272d71")

