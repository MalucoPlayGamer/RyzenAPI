-- Lua provided by RyzenAPI
-- Game: Chess Ultra

-- MAIN APPLICATION
addappid(518060)
addappid(638010)
addappid(638011)
addappid(638980)
addappid(638981)
addappid(639001)
addappid(813380)
addappid(816980)
addappid(816981)
addappid(816982)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(518061, 1, "c6167664a8aef8b3f883170f6286025585a0a4aca24a3605a74b25ee0defa80b")
addappid(639000, 0, "f7a6750047752c98ae059424edd8ae95d126d3acf724573e7c48ee2078407c13")

