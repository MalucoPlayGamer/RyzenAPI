-- Lua provided by SkyAPI 
-- Game: AppID 518060
addappid(518060)
addappid(518061, 1, "c6167664a8aef8b3f883170f6286025585a0a4aca24a3605a74b25ee0defa80b")
addappid(638010)
addappid(638011)
addappid(638980)
addappid(638981)
addappid(639000, 0, "f7a6750047752c98ae059424edd8ae95d126d3acf724573e7c48ee2078407c13")
addappid(639001)
addappid(813380)
addappid(816980)
addappid(816981)
addappid(816982)
