-- Lua provided by RyzenAPI
-- Game: 逝去之物 Passenger:Gone

-- MAIN APPLICATION
addappid(3600960)
-- Game: addappid(3600960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600961, 1, "d5fcba26b3e334a0d0617d24190ed6f356e174b723397c793a745faf18aa7e7e")
