-- Lua provided by RyzenAPI
-- Game: 逝去之物 Passenger:Gone

-- MAIN APPLICATION
addappid(3600960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600961, 1, "d5fcba26b3e334a0d0617d24190ed6f356e174b723397c793a745faf18aa7e7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
