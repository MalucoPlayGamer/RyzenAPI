-- Lua provided by RyzenAPI
-- Game: Game: AppID 368160

-- MAIN APPLICATION
addappid(368160)
-- Game: addappid(368160)

-- MAIN APP DEPOTS / PACKAGES
addappid(368161, 1, "a077ad82243ad982195e8f8f72152dd938125a1b1f65d7d3befd8d17658742b6")
addappid(368163, 1, "43b5e5b78d11b0be9e0f1959c89889cd8de562d4fe670c6de5e3d1a986195544")
