-- Lua provided by RyzenAPI
-- Game: Cursed Words: The Word Game That Isn't

-- MAIN APPLICATION
addappid(3856460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3856461,0,"23db969267704646917ace252094fce4d1e37e7e039bccae85a33a958038fc4b")

