-- Lua provided by RyzenAPI
-- Game: Game: AppID 292410

-- MAIN APPLICATION
addappid(292410)
-- Game: addappid(292410)

-- MAIN APP DEPOTS / PACKAGES
addappid(292411, 1, "dd106d1f3407ca9e6dd548f69854edbe2bcc7228af0f78c1f1d94181be97abd7")
