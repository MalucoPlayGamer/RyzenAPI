-- Lua provided by RyzenAPI
-- Game: Game: Space Slaughter

-- MAIN APPLICATION
addappid(2349480)
-- Game: addappid(2349480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349481, 1, "877ca73c6fc095eea1069bd9551963caaa33d2290a93ff244695a3b38e272c60")
