-- Lua provided by RyzenAPI
-- Game: 2369400

-- MAIN APPLICATION
addappid(2369400)
-- Game: addappid(2369400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369401, 1, "3baa15b345024030902762a4649fb4b1b15dea79e8a63a2eaebdff0c971251a0")
