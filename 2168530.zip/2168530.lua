-- Lua provided by RyzenAPI
-- Game: 2168530

-- MAIN APPLICATION
addappid(2168530)
-- Game: addappid(2168530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168531, 1, "55b9647c39f2d86fb3fdb44167bf08257add4b18e2f1037cc75fd9a92d1b285e")
