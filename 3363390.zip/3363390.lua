-- Lua provided by SkyAPI 
-- Game: PASSIONERS
addappid(3363390)
addappid(3363391, 1, "3a19f039ae4cd58b555794f312c8c88b5064a47c3ea11332012e1b801a46678f")
