-- Lua provided by RyzenAPI
-- Game: Princess Farmer

-- MAIN APPLICATION
addappid(1320490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320491, 1, "710bee858b8759deb077a5098857d749cf7111b156f53f03d8a33f0f43b4f24d")
