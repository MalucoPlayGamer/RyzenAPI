-- Lua provided by RyzenAPI 
-- Game: Cannonball Crew
addappid(1605030)
addappid(1605031, 1, "ba931cca75bd8e44b3789cd61bbedfe35cc672455ae3ac01d55e59c15068111c")
