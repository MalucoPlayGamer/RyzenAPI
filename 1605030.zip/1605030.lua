-- Lua provided by RyzenAPI
-- Game: Cannonball Crew

-- MAIN APPLICATION
addappid(1605030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1605031, 1, "ba931cca75bd8e44b3789cd61bbedfe35cc672455ae3ac01d55e59c15068111c")

