-- Lua provided by RyzenAPI
-- Game: 2823360

-- MAIN APPLICATION
addappid(2823360)
-- Game: addappid(2823360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2823361, 1, "8d976f0e2ebf8c6b7ec575dc73155267ddea9fc279cac7be8060f4e269f5e376")
