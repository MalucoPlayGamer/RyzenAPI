-- Lua provided by RyzenAPI 
-- Game: Werewolf Party
addappid(2920510)
addappid(2920511, 1, "10b10048b43c4a5423f90e35675f2c8c1e19c9b5cca26837a00c73fbb4acb9bf")
