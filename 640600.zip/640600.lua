-- Lua provided by RyzenAPI
-- Game: Bleeding Kansas

-- MAIN APPLICATION
addappid(640600)

-- MAIN APP DEPOTS / PACKAGES
addappid(640601,0,"98665d2a43d05058c2a51f53decb2143b5327543ca9fd438e621a7bd2588b031")

