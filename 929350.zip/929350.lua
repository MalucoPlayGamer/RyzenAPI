-- Lua provided by SkyAPI 
-- Game: Touhou Makuka Sai ~ Fantastic Danmaku Festival Soundtrack
addappid(929350)
addappid(929351, 1, "88c247ae7a6d2b7bf02dd1b094ccd3db679695eca0975a4a1d544e0aab4e9d27")
addappid(929352, 1, "f6f479a3c28b205896c4a8d866008d63d21663719cc28fba288ba63416bef19a")
addappid(929353, 1, "3cc5dcedc146ab5f3f62902b252c9155763022086cb4643504351ea0646daca8")
