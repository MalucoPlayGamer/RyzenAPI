-- Lua provided by RyzenAPI
-- Game: Cars Mater-National

-- MAIN APPLICATION
addappid(332260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(332261, 1, "367b72a8d68c2cc7769f138f23196a381ac73dafddd326b33d641c711482cc85")
addappid(332262, 1, "b0ef363d9d520dc6ae6300acd4040b11e3b4df2e000400fdca168d8e352e1208")
addappid(332263, 1, "232239c5a7ca88c4deda9ffd7dbb17c5b90f243bf807ba74c2766c57d07eac12")
addappid(332264, 1, "edf06225df3e06281f2120f2094ddaffb93f65ab1340ef0c9f68863faa2f926e")
addappid(332265, 1, "4f14fa0d150d49c2d16e1bdb8b28f5083135d470e8a7fec83776ee0e21b767d4")
addappid(332266, 1, "eefe38426d8231ddc8e93d1e8f55e47ddaabf6b5f165b85e50d458921b8fcf95")
addappid(332267, 1, "9674aa80dc78fbc73ff16cb12f0f18798c96bbd6d2b2be65817d812fbb4993fd")
addappid(332268, 1, "b3df42e8754154e0d2a63b79abbb7ed53c97c066bef152c892dd4f1e2ab842a7")
addappid(332269, 1, "0137ea5763ea02c01e83620f11badc8f4cbb9d17c9e3ea67c9797ae35d134422")
