-- Lua provided by SkyAPI 
-- Game: AppID 838400
addappid(838400)
addappid(838401, 1, "733e42c3858b8483d66bc9f1e7c09bfdd6b43596a0cc0d5b22aec25764b6ec17")
