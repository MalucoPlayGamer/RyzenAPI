-- Lua provided by RyzenAPI
-- Game: 838400

-- MAIN APPLICATION
addappid(838400)
-- Game: addappid(838400)

-- MAIN APP DEPOTS / PACKAGES
addappid(838401, 1, "733e42c3858b8483d66bc9f1e7c09bfdd6b43596a0cc0d5b22aec25764b6ec17")
