-- Lua provided by RyzenAPI
-- Game: addappid(1262450)

-- MAIN APPLICATION
addappid(1262450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262451, 1, "7b3015ee8f257aa67d2d44257e8bcc1b5e7e34f8fc3af614edbdae63dd457757")
