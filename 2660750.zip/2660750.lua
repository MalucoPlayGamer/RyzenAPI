-- Lua provided by RyzenAPI
-- Game: Teku

-- MAIN APPLICATION
addappid(2660750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660751, 1, "12916283fd1eb75e3cd6f0851c24e90543786653a848986f1691a7ff6c6dc99d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
