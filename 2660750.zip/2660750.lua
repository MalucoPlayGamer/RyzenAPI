-- Lua provided by RyzenAPI
-- Game: Teku

-- MAIN APPLICATION
addappid(2660750)
-- Game: addappid(2660750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660751, 1, "12916283fd1eb75e3cd6f0851c24e90543786653a848986f1691a7ff6c6dc99d")
