-- Lua provided by RyzenAPI
-- Game: Merge Castle: Mansion Puzzles

-- MAIN APPLICATION
addappid(4126660)
