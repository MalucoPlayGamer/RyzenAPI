-- Lua provided by RyzenAPI
-- Game: 末日竟在我身边 - Zombies Everywhere

-- MAIN APPLICATION
addappid(1511870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511871, 1, "f9473cd6b4ef598db80dd5a61aa4a54296f25afe404edae01d330e34c70cce2a")
addappid(1538250, 0, "677510b375350f3b90a8b83b35a0fdc24dc07643c8e8fb1e014eefd0253629ff")
