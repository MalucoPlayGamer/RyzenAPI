-- Lua provided by SkyAPI 
-- Game: Adventure Slime
addappid(1146500)
addappid(1146501, 1, "c84c8b9bd367bc835dce4e898406eb47a1877b669f1ccccee66c2065a97d9d29")
