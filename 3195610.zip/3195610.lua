-- Lua provided by RyzenAPI
-- Game: Not Easy Demo

-- MAIN APPLICATION
addappid(3195610)
-- Game: addappid(3195610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195611, 1, "cde266aaff11086d2924d8467f855246c93d26eb28d372c92a171ff0d1a4af3b")
