-- Lua provided by SkyAPI 
-- Game: AppID 944810
addappid(944810)
addappid(944811, 1, "d35d0b49f1c7b35fa230fc4a8eea5a1e968df02153819b7e2fb9d533b95d691e")
