-- Lua provided by RyzenAPI
-- Game: SCALPERS: Turtle & the Moonshine Gang

-- MAIN APPLICATION
addappid(577280)

-- MAIN APP DEPOTS / PACKAGES
addappid(577281,0,"0b7439869e500a75e6e5929d69e69098ccef519f8bc1d81196c8ce6040e7e2ca")

