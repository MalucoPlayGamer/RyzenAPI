-- Lua provided by RyzenAPI
-- Game: Game: Orderly Havoc

-- MAIN APPLICATION
addappid(2363310)
-- Game: addappid(2363310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363311, 1, "ff8ce52f095566779fb6ce5f095fc567b2015db4165b02cbac49eb2ff371d20a")
