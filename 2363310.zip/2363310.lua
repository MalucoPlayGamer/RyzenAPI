-- Lua provided by RyzenAPI
-- Game: Orderly Havoc

-- MAIN APPLICATION
addappid(2363310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2363311, 1, "ff8ce52f095566779fb6ce5f095fc567b2015db4165b02cbac49eb2ff371d20a")

