-- Lua provided by RyzenAPI
-- Game: Infinitely up 4

-- MAIN APPLICATION
addappid(1080670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080671, 1, "fc9e97a8f1360f04f1693a334469bc2cad95a9a31d98a9db2c2a9660c777cd92")
