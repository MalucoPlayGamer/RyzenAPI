-- Lua provided by RyzenAPI
-- Game: 2232770

-- MAIN APPLICATION
addappid(2232770)
-- Game: addappid(2232770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232771, 1, "71d29fc65a40c07e1f10d819b13401e44aee16a6bc10b4ef9b97c896fa083191")
