-- Lua provided by RyzenAPI
-- Game: The Sin

-- MAIN APPLICATION
addappid(1543460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543461, 1, "21082495481c45abf93497bc0d704327a17ea6dc6e2cf6bb47bcf7951bd9ea69")
