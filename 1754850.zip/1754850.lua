-- Lua provided by RyzenAPI
-- Game: AppID 1754850

-- MAIN APPLICATION
addappid(1754850)
-- Game: addappid(1754850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754851, 1, "1019d3a5aa7dc3068377a64b53021dd01d4a7651ae082e83e4e73635fdf1c9d9")
