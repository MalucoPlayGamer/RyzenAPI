-- Lua provided by RyzenAPI
-- Game: addappid(2319870)

-- MAIN APPLICATION
addappid(2319870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319871, 1, "89fdc39c7e673bafac5787cb68c67dee599f2faaa6ee50c2252b972f2e5047f1")
