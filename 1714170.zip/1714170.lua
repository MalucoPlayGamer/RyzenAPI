-- Lua provided by RyzenAPI 
-- Game: Lust from Beyond: M Edition Demo
addappid(1714170)
addappid(1714171, 1, "c94e963bb9c2afe6c9ec7322939bc069e4cfbbbfe8430d4995f62e013bd40ad8")
