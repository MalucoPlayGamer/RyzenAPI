-- Lua provided by SkyAPI 
-- Game: Trivia Vault: Mixed Trivia
addappid(686550)
addappid(686551, 1, "9b13ba9721486f68999e71bf31f0df2b8115b10888805143565a35bb07561252")
