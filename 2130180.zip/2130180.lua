-- Lua provided by RyzenAPI
-- Game: Neko Girls - Artbook 18+

-- MAIN APPLICATION
addappid(2130180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130180,0,"6a493712f9f25c4f634e15b2fdd44ad9a327530383ab2071fa2309281c155afa")
