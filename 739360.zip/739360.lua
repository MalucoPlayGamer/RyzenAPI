-- Lua provided by RyzenAPI
-- Game: Poly Island

-- MAIN APPLICATION
addappid(739360)

-- MAIN APP DEPOTS / PACKAGES
addappid(739361, 1, "5187ee33516a9f77d332ec9acb305e6b5dda2e841a5c0ee0836b04a2a42fe7b4")
addappid(739362, 1, "1d55cac69724fb80eb9a56eeb413e7d12eaeae63f606fde2558734cabd29ace8")
addappid(739363, 1, "319cb93eb9e0471745607a1ad12c7530cea366dfd4c4dd3b5e08df34f3c699de")
