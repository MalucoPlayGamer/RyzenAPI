-- Lua provided by RyzenAPI
-- Game: Game: AppID 525240

-- MAIN APPLICATION
addappid(525240)
-- Game: addappid(525240)

-- MAIN APP DEPOTS / PACKAGES
addappid(525241, 1, "69908ee8b13ed776a5448984217c9cc16b33effd908b184889bcc0389996df45")
addappid(780460, 0, "cac594b83612003bfd8bb8102e0e622cd1363ecf2fac84aea3935464f03fb731")
