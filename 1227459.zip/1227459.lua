-- Lua provided by RyzenAPI
-- Game: addappid(1227459)

-- MAIN APPLICATION
addappid(1227459)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227459,0,"39d343f24923f2534b84a257c5f664a098f302ed5d2b3694119fffdbd4a7f17b")
addappid(1789950,0,"49f5e316ac65dac37c73ab33d9c7b0301ebcbd1e80c8b6c7d09140fd844deb48")
addappid(1789951,0,"3b9f2d9ece31a30031aabb2382a70012a67e2bdc85cc14bff0a5e7ea5e2c1b33")
