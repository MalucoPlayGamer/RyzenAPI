-- Lua provided by RyzenAPI
-- Game: Trash Horror Collection 5

-- MAIN APPLICATION
addappid(3569980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3569981, 1, "02ad7595c306b0af5fdc6d4e48c1b5693e2c9d2ed4ab8342433739d6424ebb08")
