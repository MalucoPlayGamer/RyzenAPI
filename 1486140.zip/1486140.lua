-- Lua provided by RyzenAPI
-- Game: Game: Microcosmum 2

-- MAIN APPLICATION
addappid(1486140)
-- Game: addappid(1486140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486141, 1, "08eb1abc386a84cd1a8698afb8993b6c2584a5615f06d16a083d8d387731af29")
