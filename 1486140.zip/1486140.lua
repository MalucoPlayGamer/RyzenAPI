-- Lua provided by RyzenAPI
-- Game: Microcosmum 2

-- MAIN APPLICATION
addappid(1486140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486141, 1, "08eb1abc386a84cd1a8698afb8993b6c2584a5615f06d16a083d8d387731af29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2860750)
