-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1718600)
addappid(1718601)
addappid(1718602)
addappid(1718604)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718603,0,"808399813513de1f21982fec1a8bb697059d95dbc7d4e82a0f6b18bdd9d59bb1")
addtoken(1718600,7560668202712648797)
