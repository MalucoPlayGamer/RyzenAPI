-- Lua provided by RyzenAPI
-- Game: PERISH

-- MAIN APPLICATION
addappid(1016360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016361, 1, "12a15d878cad1ec3bc984b2f26fea92b0baa1e134a934260f73591c4c20bd191")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
