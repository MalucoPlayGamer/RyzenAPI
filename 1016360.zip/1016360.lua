-- Lua provided by RyzenAPI
-- Game: addappid(1016360)

-- MAIN APPLICATION
addappid(1016360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016361, 1, "12a15d878cad1ec3bc984b2f26fea92b0baa1e134a934260f73591c4c20bd191")
