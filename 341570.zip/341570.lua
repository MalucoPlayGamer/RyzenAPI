-- Lua provided by RyzenAPI
-- Game: Throbax TD

-- MAIN APPLICATION
addappid(341570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(341571, 1, "d6804dabeb749d4f4288372856290fd92dbc462089fc4f3897deb5d8d0ea9a39")
addappid(341573, 1, "acedb7fee0ebfeb5ffd0237dd05c60c85f1cd8b46cb6ad98adae6590b7cedbcd")
