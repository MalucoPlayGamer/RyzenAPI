-- Lua provided by RyzenAPI
-- Game: Albacete Warrior

-- MAIN APPLICATION
addappid(1605480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605481, 1, "a9cb654f38ee30f9d5e773aec0ed582f6df846a9610770d4ec9ee7bbc46a9e9b")

