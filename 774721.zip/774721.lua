-- Lua provided by RyzenAPI
-- Game: Game: AppID 774721

-- MAIN APPLICATION
addappid(774721)
-- Game: addappid(774721)

-- MAIN APP DEPOTS / PACKAGES
addappid(774722, 1, "dc09038197949b56f192f59c4ce320c92d5870fcf364df9017961127b1783f22")
