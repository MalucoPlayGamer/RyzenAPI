-- Lua provided by RyzenAPI
-- Game: AppID 774721

-- MAIN APPLICATION
addappid(774721)

-- MAIN APP DEPOTS / PACKAGES
addappid(774722, 1, "dc09038197949b56f192f59c4ce320c92d5870fcf364df9017961127b1783f22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
