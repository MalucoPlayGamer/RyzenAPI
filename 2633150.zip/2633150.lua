-- Lua provided by RyzenAPI
-- Game: Sophia's Spa

-- MAIN APPLICATION
addappid(2633150)
addappid(2778720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633151, 1, "df4ec19abd627d4e3e497ab38fe46e8224090a3f5c076ed9c5f2c616e7ed8b09")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3062960)
