-- Lua provided by RyzenAPI
-- Game: addappid(1691560)

-- MAIN APPLICATION
addappid(1691560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691561, 1, "f69e3dc4406d4a7302585ced7d805c33bae353396bbfa04776fe9b7354248c67")
