-- Lua provided by RyzenAPI
-- Game: Mido and Di

-- MAIN APPLICATION
addappid(1691560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1691561, 1, "f69e3dc4406d4a7302585ced7d805c33bae353396bbfa04776fe9b7354248c67")

