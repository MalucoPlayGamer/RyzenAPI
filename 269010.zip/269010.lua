-- Lua provided by RyzenAPI
-- Game: 269010

-- MAIN APPLICATION
addappid(269010)
addappid(269011)
addappid(269013)
addappid(269014)
addappid(269016)

-- MAIN APP DEPOTS / PACKAGES
addappid(269012,0,"2c50dcdba07c8e727443edd935715e52707924903ea8302f5469bdb3cca627e2")
addappid(269015,0,"9fb5aceef284c58ff09c352faa2cba6f17453897b40dd9c8cd71b93314750094")
