-- Lua provided by RyzenAPI
-- Game: 3165410

-- MAIN APPLICATION
addappid(3165410)
-- Game: addappid(3165410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165411, 1, "5bb8d75eb4dcee9afa1ac69661f886f6c5344970e227ebbfb4c4b7c9991c9972")
