-- Lua provided by SkyAPI 
-- Game: AppID 313220
addappid(313220)
addappid(313221, 1, "82a7b217144dacb6fa6d49058be41c46898bfd0c85791bdcf0f2f27a1a5d3dac")
