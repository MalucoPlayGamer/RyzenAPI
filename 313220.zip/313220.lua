-- Lua provided by RyzenAPI
-- Game: 313220

-- MAIN APPLICATION
addappid(313220)
-- Game: addappid(313220)

-- MAIN APP DEPOTS / PACKAGES
addappid(313221, 1, "82a7b217144dacb6fa6d49058be41c46898bfd0c85791bdcf0f2f27a1a5d3dac")
