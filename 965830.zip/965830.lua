-- Lua provided by RyzenAPI
-- Game: Deported: Drain the Swamp

-- MAIN APPLICATION
addappid(965830)

-- MAIN APP DEPOTS / PACKAGES
addappid(965831, 1, "e9a2d2075f9e25dfb749fc462eb6dde43f1f078ff3ea30bb945e7220bd9c4b74")
