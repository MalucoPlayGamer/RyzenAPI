-- Lua provided by RyzenAPI
-- Game: AppID 451100

-- MAIN APPLICATION
addappid(451100)

-- MAIN APP DEPOTS / PACKAGES
addappid(451101, 1, "b0a19231589521041562c84eb55803ffce8adbb6a38b1dd4bc732406b128b496")
addappid(451102, 1, "09465f5b8eb9751174a60d5785ba1ae0f6e95871fba9c277412e376001097907")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
