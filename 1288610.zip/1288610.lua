-- Lua provided by RyzenAPI
-- Game: Wildcat Gun Machine

-- MAIN APPLICATION
addappid(1288610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1288611, 1, "42b08b0f1055f4aaa2f0de9be5d063c5ed1e7682113b5c9f42dcdaa45015089f")

