-- Lua provided by RyzenAPI
-- Game: AppID 1288610

-- MAIN APPLICATION
addappid(1288610)
-- Game: addappid(1288610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288611, 1, "42b08b0f1055f4aaa2f0de9be5d063c5ed1e7682113b5c9f42dcdaa45015089f")
