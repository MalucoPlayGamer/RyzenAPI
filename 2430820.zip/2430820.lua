-- Lua provided by RyzenAPI 
-- Game: Squab
addappid(2430820)
addappid(2430821, 1, "d49c2ec9ea44e720572005f43892484c59fb38b8833a5a4e3d4e0ef484dfb34a")
