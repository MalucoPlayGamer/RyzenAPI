-- Lua provided by RyzenAPI
-- Game: addappid(1346740)

-- MAIN APPLICATION
addappid(1346740)
addappid(1346741)
addappid(1346743)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346744,0,"d6a6d5408f7514635edfd9f3da123367ef9edaca86bf61df0b53ca3de2190130")
