-- Lua provided by RyzenAPI
-- Game: Race in Desert

-- MAIN APPLICATION
addappid(2253950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253951, 1, "1864ec2bdb0d42f296c27313e8bfb14404768d49766c5d94d311b4cb676db06b")

