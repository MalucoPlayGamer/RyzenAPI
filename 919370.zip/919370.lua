-- Lua provided by RyzenAPI
-- Game: Overdungeon

-- MAIN APPLICATION
addappid(919370)
addappid(987110)
addappid(1194470)

-- MAIN APP DEPOTS / PACKAGES
addappid(919371,0,"6d3f4c2df57c4f9c4d275afd49347da2c06b4439af51fa06455916839fb5c133")
addappid(919372,0,"5b1ea148c337f17a297acbe881497fdf4a45b6a61c5b80a443ab6536cad119ad")
addappid(919373,0,"1461e662cba1d5abfbe726cbac867c84e6326312e1d7ce5086cc698e929bc78c")
addappid(987110,0,"e6218b5f3aa1289e5c7ee3a4335c8b3498d9aa10b0565c9809c5793cbb090d85")

