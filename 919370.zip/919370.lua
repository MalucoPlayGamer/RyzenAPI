-- Lua provided by RyzenAPI
-- Game: Game: Overdungeon

-- MAIN APPLICATION
addappid(919370)
-- Game: addappid(919370)

-- MAIN APP DEPOTS / PACKAGES
addappid(919371, 1, "6d3f4c2df57c4f9c4d275afd49347da2c06b4439af51fa06455916839fb5c133")
addappid(919372, 1, "5b1ea148c337f17a297acbe881497fdf4a45b6a61c5b80a443ab6536cad119ad")
addappid(919373, 1, "1461e662cba1d5abfbe726cbac867c84e6326312e1d7ce5086cc698e929bc78c")
