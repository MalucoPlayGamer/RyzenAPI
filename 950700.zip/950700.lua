-- Lua provided by RyzenAPI
-- Game: Game: AppID 950700

-- MAIN APPLICATION
addappid(950700)
-- Game: addappid(950700)

-- MAIN APP DEPOTS / PACKAGES
addappid(950701, 1, "7931ad236b40471ac073f4d805add880507e7808cac4fd496e8a4902e243aea8")
