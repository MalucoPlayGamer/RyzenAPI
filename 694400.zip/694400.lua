-- Lua provided by RyzenAPI
-- Game: Diminutive

-- MAIN APPLICATION
addappid(694400)
addappid(988410)

-- MAIN APP DEPOTS / PACKAGES
addappid(694401,0,"404487972f31ceba9ef8c70075343896d6aa2a259ccaa51203934d815fedbde7")

