-- Lua provided by RyzenAPI 
-- Game: Car Service Together
addappid(3501070)
addappid(3501071, 1, "7bb00da72e348f52d382147b41332f518de67a4ff8f3ab8cd203888982e72de4")
