-- Lua provided by RyzenAPI
-- Game: Game: Car Service Together

-- MAIN APPLICATION
addappid(3501070)
-- Game: addappid(3501070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3501071, 1, "7bb00da72e348f52d382147b41332f518de67a4ff8f3ab8cd203888982e72de4")
