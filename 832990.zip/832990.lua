-- Lua provided by RyzenAPI
-- Game: AppID 832990

-- MAIN APPLICATION
addappid(832990)
-- Game: addappid(832990)

-- MAIN APP DEPOTS / PACKAGES
addappid(832991, 1, "d44c4070bb8944e665a99d64768eed4fdd4e3d6b21869367f26b4f2377c3f300")
