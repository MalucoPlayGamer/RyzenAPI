-- Lua provided by RyzenAPI
-- Game: Alien Breed 3: Descent

-- MAIN APPLICATION
addappid(22642)
addappid(22670)
addappid(22678)

-- MAIN APP DEPOTS / PACKAGES
addappid(22671, 1, "471164186d29041ab03ec6478df2ff69dea80b033969bce52e8f31e313efe3d9")
addappid(22672, 1, "adce81fd9087f4521642d21ee0340bcc5d1996bf0ca841b9967eb57af734e8cc")
addappid(22673, 1, "207fd2518f50bbd247f5566824a4f2343a8942490404ec03d1819e7442b22591")
addappid(22674, 1, "8e2dabbe449976b227affec0730ebb1e10df2c7e8cbefa263dca869c295689af")
addappid(22675, 1, "82e499e217afd9ddaa98563464a929f3a52483daebc1d30005a99b26578b9ed0")
addappid(22676, 1, "08c03b220bfa08a093fe38a520e0e7fe18308ec9cf63f5367b783c6486f94bbe")
addappid(22677, 1, "4fc4ae9a07a16798ded1b12f8749e8b9e011936dc905fcc113146d0d2da7eefb")

