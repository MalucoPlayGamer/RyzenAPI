-- Lua provided by RyzenAPI
-- Game: Game: Talented

-- MAIN APPLICATION
addappid(2435090)
-- Game: addappid(2435090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435091, 1, "3bb02dd8b5026578c993a658d5539930ff82e9da5d955961d1043af6a76e43b4")
