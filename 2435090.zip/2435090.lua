-- Lua provided by RyzenAPI
-- Game: Talented

-- MAIN APPLICATION
addappid(2435090)
addappid(3423250)
addappid(3529280)
addappid(3997780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435091, 1, "3bb02dd8b5026578c993a658d5539930ff82e9da5d955961d1043af6a76e43b4")

