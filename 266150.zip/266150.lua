-- Lua provided by RyzenAPI
-- Game: Lost Saga North America

-- MAIN APPLICATION
addappid(266150)
addappid(322510)
addappid(330230)
addappid(330240)
addappid(343760)

-- MAIN APP DEPOTS / PACKAGES
addappid(266151,0,"27c4cad7971aab1dc9d93ed486134353a60f5ec0acf6cc08175b5ccae5d51626")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
