-- Lua provided by RyzenAPI
-- Game: Lost Saga North America

-- MAIN APPLICATION
addappid(266150)
addappid(322510)
addappid(330230)
addappid(330240)
addappid(343760)

-- MAIN APP DEPOTS / PACKAGES
addappid(266151,0,"27c4cad7971aab1dc9d93ed486134353a60f5ec0acf6cc08175b5ccae5d51626")

