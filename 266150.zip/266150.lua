-- Lua provided by RyzenAPI
-- Game: AppID 266150

-- MAIN APPLICATION
addappid(266150)
-- Game: addappid(266150)

-- MAIN APP DEPOTS / PACKAGES
addappid(266151, 1, "27c4cad7971aab1dc9d93ed486134353a60f5ec0acf6cc08175b5ccae5d51626")
