-- Lua provided by RyzenAPI
-- Game: addappid(2233850)

-- MAIN APPLICATION
addappid(2233850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233851, 1, "f3affc9b7608a03a5e41bd2e16e4518bd56d1aab9d8df2ec5191adb2410c1736")
