-- Lua provided by RyzenAPI
-- Game: 343320

-- MAIN APPLICATION
addappid(343320)
-- Game: addappid(343320)

-- MAIN APP DEPOTS / PACKAGES
addappid(343321, 1, "9a7ea4f85e6b2a7c23116d38328a61e1e7caad982f428fa3c159b75a2ff66940")
