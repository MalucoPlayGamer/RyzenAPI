-- Lua provided by RyzenAPI
-- Game: StaudSoft's Synthetic World Beta

-- MAIN APPLICATION
addappid(343320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(343321, 1, "9a7ea4f85e6b2a7c23116d38328a61e1e7caad982f428fa3c159b75a2ff66940")

