-- Lua provided by RyzenAPI
-- Game: Chinatown Detective Agency: Day One

-- MAIN APPLICATION
addappid(1401920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401921, 1, "98e88d09bcb6bd817f3ee16fa7559e872e5a550ec8b4230b4623205e6ea3ac2b")

