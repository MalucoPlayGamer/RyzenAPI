-- Lua provided by RyzenAPI
-- Game: The song of Star night

-- MAIN APPLICATION
addappid(1509340)
-- Game: addappid(1509340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509341, 1, "24ab2c3ce26b4036adf1f1ce26ea83600239e111ed3a9f7dc054e10a51c15b72")
