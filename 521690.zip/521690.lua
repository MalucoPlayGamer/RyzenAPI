-- Lua provided by RyzenAPI
-- Game: 521690

-- MAIN APPLICATION
addappid(521690)
-- Game: addappid(521690)

-- MAIN APP DEPOTS / PACKAGES
addappid(521691, 1, "6f0756f717008df4ae638db414e7ffb06f0b2dca06c67d0fbacaaa954c840624")
