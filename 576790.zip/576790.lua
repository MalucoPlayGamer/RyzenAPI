-- Lua provided by RyzenAPI
-- Game: Game: AppID 576790

-- MAIN APPLICATION
addappid(576790)
-- Game: addappid(576790)

-- MAIN APP DEPOTS / PACKAGES
addappid(576791, 1, "24e8c707133d4dca072344a4a668068427930a3b7b24cff92ba4248eb6c3b31b")
