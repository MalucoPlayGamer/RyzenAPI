-- Lua provided by RyzenAPI
-- Game: AppID 269030

-- MAIN APPLICATION
addappid(269030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(269031, 1, "c088f5824959155555c8e0bcadd37d5199648f980cde6804ced679b6e69f2ff8")

