-- Lua provided by RyzenAPI
-- Game: Game: AppID 269030

-- MAIN APPLICATION
addappid(269030)
-- Game: addappid(269030)

-- MAIN APP DEPOTS / PACKAGES
addappid(269031, 1, "c088f5824959155555c8e0bcadd37d5199648f980cde6804ced679b6e69f2ff8")
