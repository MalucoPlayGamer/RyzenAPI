-- Lua provided by RyzenAPI
-- Game: OBJ VR

-- MAIN APPLICATION
addappid(3086680)
-- Game: addappid(3086680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086681, 1, "660ad14446dab91bcee42fd31e3993993fc6827991265a7572680d5d23b61dd1")
