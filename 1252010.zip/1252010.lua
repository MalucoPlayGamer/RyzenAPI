-- Lua provided by RyzenAPI
-- Game: VEGAS Movie Studio 17 Platinum Steam Edition

-- MAIN APPLICATION
addappid(1252010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252011, 1, "71723ef89f445e42ac58b7efaea8dae6356e76212dd79ae6da5455c0b8b4b619")

