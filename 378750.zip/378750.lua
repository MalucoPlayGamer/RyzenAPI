-- Lua provided by RyzenAPI
-- Game: Sayonara Umihara Kawase

-- MAIN APPLICATION
addappid(378750)

-- MAIN APP DEPOTS / PACKAGES
addappid(378751, 1, "cf078aa3934fcf4171d870238ffce504f36c6603d15b7bf8d9ba0fdb9ea4f0a2")
