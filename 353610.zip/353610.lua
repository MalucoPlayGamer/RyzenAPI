-- Lua provided by RyzenAPI
-- Game: AppID 353610

-- MAIN APPLICATION
addappid(353610)

-- MAIN APP DEPOTS / PACKAGES
addappid(353611, 1, "a1f3f343c498497088fe7e14c8246b3c1eef5fcd88944c8dc8bd21c1f0d1187f")
addappid(353612, 1, "a08b258bc9162b61f34f4a01534843d4cfb6d3a24f591a40ce93e51794ff02cb")
addappid(353613, 1, "f58b84da69d42c3322c604a4f8914d7de50e22ba4078df2a7131e13e84fdb210")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(524450)
