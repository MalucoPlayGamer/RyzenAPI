-- Lua provided by RyzenAPI
-- Game: Game: 与我签订契约，成为救世勇者吧！

-- MAIN APPLICATION
addappid(1831290)
-- Game: addappid(1831290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831291, 1, "e3d1cb84d60e59cf6aaf7f8055ed7375b4b34e9fc2370a523540f63ec20283dc")
