-- Lua provided by RyzenAPI 
-- Game: Redswood VR
addappid(499760)
addappid(499761, 1, "b0805d30b794c72544fbbc687c822c3ac5cf9aa069b54d723822110b02d0ac73")
