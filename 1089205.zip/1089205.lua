-- Lua provided by RyzenAPI
-- Game: 1089205

-- MAIN APPLICATION
addappid(1089205)
-- Game: addappid(1089205)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089205,0,"8cfffd741c39285c26b7b37ba3743915400ecafeabefe3f974ac84db9690c86e")
addtoken(1089205,"13809631797973804949")
