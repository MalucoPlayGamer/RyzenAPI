-- Lua provided by RyzenAPI
-- Game: Hired Ops

-- MAIN APPLICATION
addappid(374280)

