-- Lua provided by RyzenAPI
-- Game: Game: AppID 726600

-- MAIN APPLICATION
addappid(726600)
-- Game: addappid(726600)

-- MAIN APP DEPOTS / PACKAGES
addappid(726601, 1, "e035962270313ec164ac2fde24810c2b9d115c522e99985687da74e18349ead4")
