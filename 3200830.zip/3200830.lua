-- Lua provided by RyzenAPI
-- Game: addappid(3200830)

-- MAIN APPLICATION
addappid(3200830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200831, 1, "a1aa4dfbf57dec26f745be5ccf9e5e08005fae66dc2c672ddc8907f56ae2c0fb")
