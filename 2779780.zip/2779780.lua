-- Lua provided by RyzenAPI
-- Game: addappid(2779780)

-- MAIN APPLICATION
addappid(2779780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779781, 1, "d510356aa26d8fe77a9634e9baee9c061f87f5bee1a3a0308b9f2e476d721bc6")
