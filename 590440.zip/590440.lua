-- Lua provided by RyzenAPI
-- Game: Carlos III y la difusión de la antigüedad

-- MAIN APPLICATION
addappid(590440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(590441, 1, "bc87e043a19db7251e4f9b7f39e32b5472bcd6a082d8a49a820fdc2585e28dda")

