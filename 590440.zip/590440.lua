-- Lua provided by RyzenAPI
-- Game: AppID 590440

-- MAIN APPLICATION
addappid(590440)

-- MAIN APP DEPOTS / PACKAGES
addappid(590441, 1, "bc87e043a19db7251e4f9b7f39e32b5472bcd6a082d8a49a820fdc2585e28dda")

