-- Lua provided by RyzenAPI
-- Game: 2579850

-- MAIN APPLICATION
addappid(2579850)
-- Game: addappid(2579850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579851, 1, "d1c14d0c4778b2b09e6c90660128662d2dd6c30e52ce0dfa137688d87a551f95")
