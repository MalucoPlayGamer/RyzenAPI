-- Lua provided by RyzenAPI
-- Game: Game: The Top of The Dream

-- MAIN APPLICATION
addappid(1676670)
-- Game: addappid(1676670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676671, 1, "9d1c5d6fca086b21ccb7784f0b153f45b55cb89ff55eeb2eae9d3ba1b1ed0b3d")
