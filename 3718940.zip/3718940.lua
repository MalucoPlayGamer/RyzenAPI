-- Lua provided by RyzenAPI
-- Game: Phoenix's Faye Playtest

-- MAIN APPLICATION
addappid(3718940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3718941, 1, "60a4bb701aff85143c4f885a7a8a2d86b5ea27ffc68687dc27a10f56cbce5c91")

