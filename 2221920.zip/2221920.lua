-- Lua provided by RyzenAPI
-- Game: Immortals Fenyx Rising

-- MAIN APPLICATION
addappid(2221920)
addappid(2222840)
addappid(2222841)
addappid(2222842)
addappid(2222843)
addappid(2222844)
addappid(2222845)
addappid(2222880)
addappid(2224320)
addappid(2224321)
addappid(2236200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2221921, 1, "8275786a67804e966e135b16f69f1645268119c16cfd77f21c6067bcb56a83e8")
addappid(2221924, 1, "591f2020ca54e1092d56368756b4f1451320964f23ed1be6097c2a7024cd7280")
addappid(2221925, 1, "9a0bb2ad4553ba8307ba1d495e1e90c970ae1168c1dd796537fe4f4b19f7519f")
addappid(2221926, 1, "4ae02ea71b8eeec15234a8ac672df21243ce0439b0f08a7f434e339d300e6795")

