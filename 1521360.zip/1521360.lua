-- Lua provided by SkyAPI 
-- Game: MainFrames
addappid(1521360)
addappid(1521361, 1, "4ff7ac3f84acf3833361a8b8534d4bd874f4f721337fc886bc9fc49e013d25cd")
