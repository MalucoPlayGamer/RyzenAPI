-- Lua provided by RyzenAPI
-- Game: Game: MainFrames

-- MAIN APPLICATION
addappid(1521360)
-- Game: addappid(1521360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521361, 1, "4ff7ac3f84acf3833361a8b8534d4bd874f4f721337fc886bc9fc49e013d25cd")
