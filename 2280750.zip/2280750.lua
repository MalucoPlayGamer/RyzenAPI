-- Lua provided by RyzenAPI 
-- Game: EXS2 Support package-CG
addappid(2280750)
addappid(2280751, 1, "8b4b035a35cb082aec8d136e74e913a238ef651fe7506612018a19ea40e53c86")
