-- Lua provided by RyzenAPI
-- Game: 2280750

-- MAIN APPLICATION
addappid(2280750)
-- Game: addappid(2280750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280751, 1, "8b4b035a35cb082aec8d136e74e913a238ef651fe7506612018a19ea40e53c86")
