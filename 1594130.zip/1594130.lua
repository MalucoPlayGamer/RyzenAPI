-- Lua provided by RyzenAPI
-- Game: Game: Excidio The Kaiju Simulator

-- MAIN APPLICATION
addappid(1594130)
-- Game: addappid(1594130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594131, 1, "0a0d5250bcb4b6d42cf9418cce12612a9b2e29876899d2c742d132422aee9868")
