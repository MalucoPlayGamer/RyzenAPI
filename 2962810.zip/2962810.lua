-- Lua provided by RyzenAPI
-- Game: 2962810

-- MAIN APPLICATION
addappid(2962810)
-- Game: addappid(2962810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962811, 1, "46d3774904d4c61843adc05c677b658f98bdb6a318956b13afa44920936eb0ab")
