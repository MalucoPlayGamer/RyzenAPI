-- Lua provided by RyzenAPI
-- Game: 3358680

-- MAIN APPLICATION
addappid(3358680)
-- Game: addappid(3358680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358681, 1, "9c229ac4bc93b05094936c6ac214f0aee5a9d009aca5b5fdffe72ec38257e11a")
