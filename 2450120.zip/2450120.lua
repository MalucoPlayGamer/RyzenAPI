-- Lua provided by RyzenAPI
-- Game: Naughty College 18+

-- MAIN APPLICATION
addappid(2450120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450121, 1, "53d9377a264bdbf78968dd06666e4e96520ff93476fdf989d28a0f5517f82326")

