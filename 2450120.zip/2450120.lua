-- Lua provided by SkyAPI 
-- Game: Naughty College 18+
addappid(2450120)
addappid(2450121, 1, "53d9377a264bdbf78968dd06666e4e96520ff93476fdf989d28a0f5517f82326")
