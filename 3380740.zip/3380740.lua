-- Lua provided by RyzenAPI
-- Game: Boo! Are you scared? The Chests Game

-- MAIN APPLICATION
addappid(3380740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380741, 1, "4145f583e71fb91c44588fd1f589f4a976a3a5001f7fba9dc287fc32d758a8ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
