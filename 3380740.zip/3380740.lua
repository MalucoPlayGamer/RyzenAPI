-- Lua provided by RyzenAPI
-- Game: 3380740

-- MAIN APPLICATION
addappid(3380740)
-- Game: addappid(3380740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380741, 1, "4145f583e71fb91c44588fd1f589f4a976a3a5001f7fba9dc287fc32d758a8ed")
