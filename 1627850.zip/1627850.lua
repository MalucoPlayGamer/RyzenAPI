-- Lua provided by RyzenAPI
-- Game: 1627850

-- MAIN APPLICATION
addappid(1627850)
addappid(1627854)
addappid(1627856)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627855,0,"1dc7cf241bdbe9740476e912acf3b307fb079e54e6d0b797d4312e39201a39c3")

