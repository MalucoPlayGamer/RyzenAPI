-- Lua provided by RyzenAPI 
-- Game: The Random Game
addappid(3446740)
addappid(3446741, 1, "e657e899d9bceb265b3cd53335e8c6a9ecf37b3a694a8b3f11bfc5d7ed6408a4")
