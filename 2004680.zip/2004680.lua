-- Lua provided by RyzenAPI
-- Game: Voidling Bound


addappid(2004680, 1, "1a83ead6b5e0b5dd4b2a52fcf034194a1e34cd0ff56afa5a1deb494afa16c940") -- Voidling Bound
addappid(2004681, 1, "1860d9124ae9fc2ac8d1d6187a27c3724a88dc31e97ee3176b7f6a817c11257a") -- Depot 2004681
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4788030)
addappid(4788030, 1, "cb3125fbee554d53523adcbbedfdee69133a1982ccf56209087a4946e00d8367") -- Voidling Bound - Digital Artbook - Depot 4788030
