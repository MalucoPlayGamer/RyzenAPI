-- 2004680's Lua and Manifest Created by Hubcap Manifest
-- Voidling Bound
-- Created: June 12, 2026 at 14:45:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2004680, 1, "1a83ead6b5e0b5dd4b2a52fcf034194a1e34cd0ff56afa5a1deb494afa16c940") -- Voidling Bound
-- MAIN APP DEPOTS
addappid(2004681, 1, "1860d9124ae9fc2ac8d1d6187a27c3724a88dc31e97ee3176b7f6a817c11257a") -- Depot 2004681
-- setManifestid(2004681, "1399645663783409544", 16023578200)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Voidling Bound - Digital Artbook (AppID: 4788030)
addappid(4788030)
addappid(4788030, 1, "cb3125fbee554d53523adcbbedfdee69133a1982ccf56209087a4946e00d8367") -- Voidling Bound - Digital Artbook - Depot 4788030
-- setManifestid(4788030, "8268446157988366266", 326439307)