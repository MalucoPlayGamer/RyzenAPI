-- Lua provided by RyzenAPI
-- Game: 233570

-- MAIN APPLICATION
addappid(233570)
-- Game: addappid(233570)

-- MAIN APP DEPOTS / PACKAGES
addappid(233571, 1, "a682e7ef43a2942f4a90cbdba30c7071716bdc31c946ccb695a122fda58e2e2b")
