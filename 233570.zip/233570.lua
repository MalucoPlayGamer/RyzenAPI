-- Lua provided by RyzenAPI
-- Game: AppID 233570

-- MAIN APPLICATION
addappid(233570)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(233571, 1, "a682e7ef43a2942f4a90cbdba30c7071716bdc31c946ccb695a122fda58e2e2b")

