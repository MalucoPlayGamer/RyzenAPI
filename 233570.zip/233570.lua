-- Lua provided by RyzenAPI 
-- Game: AppID 233570
addappid(233570)
addappid(233571, 1, "a682e7ef43a2942f4a90cbdba30c7071716bdc31c946ccb695a122fda58e2e2b")
