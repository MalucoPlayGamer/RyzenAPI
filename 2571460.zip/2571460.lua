-- Lua provided by RyzenAPI
-- Game: Untamed Tactics Soundtrack

-- MAIN APPLICATION
addappid(2571460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571461, 1, "07fa8f6baae6519d3f21c25478a5b28a1814252232c6b51dbc83d31e2b4d8d90")
