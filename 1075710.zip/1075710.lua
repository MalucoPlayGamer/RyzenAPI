-- Lua provided by RyzenAPI
-- Game: Katana ZERO Soundtrack

-- MAIN APPLICATION
addappid(1075710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075711, 1, "b6f4fe40f6e957091d029ec75df5f69dc3eb451f9546fd25fc600b3fecddb514")
addappid(1075712, 1, "c4a9f4b5b6320b5b5eaa4afdadae99249df23bff0fea23321f3fd3560ac745a3")
