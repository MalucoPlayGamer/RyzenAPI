-- Lua provided by RyzenAPI
-- Game: DwarfHeim

-- MAIN APPLICATION
addappid(977650)
addappid(1405910)

-- MAIN APP DEPOTS / PACKAGES
addappid(977651,0,"1a32159d9020b5e8786a0b51f1595246831ce00c17d7d527c39f07f0d121a1da")

