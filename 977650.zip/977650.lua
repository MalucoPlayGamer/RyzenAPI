-- Lua provided by RyzenAPI
-- Game: AppID 977650

-- MAIN APPLICATION
addappid(977650)
-- Game: addappid(977650)

-- MAIN APP DEPOTS / PACKAGES
addappid(977651, 1, "1a32159d9020b5e8786a0b51f1595246831ce00c17d7d527c39f07f0d121a1da")
