-- Lua provided by RyzenAPI
-- Game: addappid(2437035)

-- MAIN APPLICATION
addappid(2437035)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437035,0,"63e9dc7b45ad882e2769ebb3e60b64c121b38c6f65f9631b32f7c1f125de61d3")
