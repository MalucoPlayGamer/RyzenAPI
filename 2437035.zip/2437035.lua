-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Zurich V2.0

-- MAIN APPLICATION
addappid(2437035)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437035,0,"63e9dc7b45ad882e2769ebb3e60b64c121b38c6f65f9631b32f7c1f125de61d3")

