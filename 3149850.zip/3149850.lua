-- Lua provided by RyzenAPI
-- Game: 3149850

-- MAIN APPLICATION
addappid(3149850)
-- Game: addappid(3149850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3149851, 1, "5f9605a8d1d40ecad4304eabb2072b1af311c6ffa5f8352b7beaf2d3c7676e12")
