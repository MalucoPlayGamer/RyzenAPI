-- Lua provided by RyzenAPI
-- Game: AppID 639130

-- MAIN APPLICATION
addappid(639130)
-- Game: addappid(639130)

-- MAIN APP DEPOTS / PACKAGES
addappid(639131, 1, "79f7e637b2eb1e249438bbb8ef703b00d87cb9c43d7909646a46300a745c834a")
