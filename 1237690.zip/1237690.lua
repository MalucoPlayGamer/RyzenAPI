-- Lua provided by SkyAPI 
-- Game: HVOR
addappid(1237690)
addappid(1237691, 1, "04a3fa0f229a2217db3d3283f904b6245b3a70346c34ef0db9b1e7af4b3be2ee")
