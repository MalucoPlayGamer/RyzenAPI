-- Lua provided by RyzenAPI
-- Game: Prince of Vibe Code

-- MAIN APPLICATION
addappid(4820270) -- Prince of Vibe Code

-- MAIN APP DEPOTS / PACKAGES
addappid(4820271, 1, "de0da35227c8c948c73f42fed501ebb6f78f3324ba069127779d68637a820b4f") -- Depot 4820271

