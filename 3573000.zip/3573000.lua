-- Lua provided by RyzenAPI
-- Game: Milo's Tiny Fish Pond

-- MAIN APPLICATION
addappid(3573000)
-- Game: addappid(3573000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573001, 1, "681ba7a64ac3ce943f86c49cb451a9437da356759fd91bd5c4c0ef81e7cabed9")
