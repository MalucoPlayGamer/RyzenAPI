-- Lua provided by RyzenAPI
-- Game: addappid(217270)

-- MAIN APPLICATION
addappid(217270)

-- MAIN APP DEPOTS / PACKAGES
addappid(217271, 1, "d81fd6c957a70f5a33eaed14f4e99e7a4ee234926dad9d6a170d0def94e8c15e")
