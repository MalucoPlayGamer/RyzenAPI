-- Lua provided by RyzenAPI
-- Game: JOI Lab VR 🔞 Demo

-- MAIN APPLICATION
addappid(3108540)
-- Game: addappid(3108540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108541, 1, "578de9a5685506c84c1e7f128a339d10a8e23f034119050d10fe7463cb8228be")
