-- Lua provided by RyzenAPI
-- Game: Game: MIRAGE

-- MAIN APPLICATION
addappid(793880)
-- Game: addappid(793880)

-- MAIN APP DEPOTS / PACKAGES
addappid(793881, 1, "50e299d7e4eb9a518ad36c46ee0e68d62e1368bf059b6e4f530df39041c7408d")
