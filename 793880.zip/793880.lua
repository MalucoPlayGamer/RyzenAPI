-- Lua provided by SkyAPI 
-- Game: MIRAGE
addappid(793880)
addappid(793881, 1, "50e299d7e4eb9a518ad36c46ee0e68d62e1368bf059b6e4f530df39041c7408d")
