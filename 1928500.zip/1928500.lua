-- Lua provided by RyzenAPI 
-- Game: Secret Camera
addappid(1928500)
addappid(1928501, 1, "2b4afb5de6b383c8c84de0b01005ac29cf2bb0d09b2daab7ec05c2c2410cb076")
