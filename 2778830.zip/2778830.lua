-- Lua provided by RyzenAPI
-- Game: 2778830

-- MAIN APPLICATION
addappid(2778830)
-- Game: addappid(2778830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778831, 1, "26fa7609853f967e445cdb5e6c963ec855bc38228e18ff5e3f0168802484fab4")
