-- Lua provided by RyzenAPI
-- Game: addappid(1961760)

-- MAIN APPLICATION
addappid(1961760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961761, 1, "a5e3a8349ed97f57e66cd5b439fc33732a9e76b9888d89edb0f5a8e387251896")
