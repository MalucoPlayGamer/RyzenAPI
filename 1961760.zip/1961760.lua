-- Lua provided by RyzenAPI 
-- Game: My Girlfriend’s Special Place
addappid(1961760)
addappid(1961761, 1, "a5e3a8349ed97f57e66cd5b439fc33732a9e76b9888d89edb0f5a8e387251896")
