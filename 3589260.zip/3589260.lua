-- Lua provided by RyzenAPI
-- Game: addappid(3589260)

-- MAIN APPLICATION
addappid(3589260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3589264,0,"0d8cf459df2fc44a8b4a9a88bba0e193d72c3921a368a2fad1113611bc62b572")
