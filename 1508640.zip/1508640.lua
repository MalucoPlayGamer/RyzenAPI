-- Lua provided by RyzenAPI
-- Game: AppID 1508640

-- MAIN APPLICATION
addappid(1508640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508641, 1, "b589fca622f8249c568e295843aaee0509431d7ee6a509e8e594179b5d5f32cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
