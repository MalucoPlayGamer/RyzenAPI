-- Lua provided by RyzenAPI 
-- Game: AppID 1508640
addappid(1508640)
addappid(1508641, 1, "b589fca622f8249c568e295843aaee0509431d7ee6a509e8e594179b5d5f32cf")
