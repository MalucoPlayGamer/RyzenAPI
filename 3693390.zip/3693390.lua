-- Lua provided by RyzenAPI
-- Game: Bullet Noir Soundtrack

-- MAIN APPLICATION
addappid(3693390)
-- Game: addappid(3693390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3693391, 1, "a4ac97ac0504d754be35839aa0a9a8b99e0f8ea8c8f401f626bb5b716b7a9031")
