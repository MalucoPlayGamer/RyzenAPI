-- Lua provided by SkyAPI 
-- Game: Detective Dotson
addappid(2450840)
addappid(2450841, 1, "4458b5c21ee0e65bbd9f3b9237025990e28f3de28fc011b222b20270303157e6")
