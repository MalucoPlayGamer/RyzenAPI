-- Lua provided by RyzenAPI
-- Game: Bavity

-- MAIN APPLICATION
addappid(1811710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(1811711, 1, "34df8e7368db38896ae2f8f9239362db25262dfd931dab471fbe4511a73f7a02")

