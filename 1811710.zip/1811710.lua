-- Lua provided by RyzenAPI
-- Game: addappid(1811710)

-- MAIN APPLICATION
addappid(1811710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811711, 1, "34df8e7368db38896ae2f8f9239362db25262dfd931dab471fbe4511a73f7a02")
