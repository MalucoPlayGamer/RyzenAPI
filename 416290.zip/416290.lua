-- Lua provided by RyzenAPI
-- Game: 416290

-- MAIN APPLICATION
addappid(416290)
-- Game: addappid(416290)

-- MAIN APP DEPOTS / PACKAGES
addappid(416291, 1, "7819849d6c4fa09018f2912f4cd354dded7da2ff993964b041d15e65bd27b6e4")
