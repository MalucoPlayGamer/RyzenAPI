-- Lua provided by RyzenAPI
-- Game: Raven Estate Demo

-- MAIN APPLICATION
addappid(2595870)
-- Game: addappid(2595870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595871, 1, "2c9d2479cc79d35b955fced7b2fe41f8c396175cd331b340d227d1caf731fa61")
