-- Lua provided by RyzenAPI
-- Game: Game: AppID 1106830

-- MAIN APPLICATION
addappid(1106830)
-- Game: addappid(1106830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106831, 1, "897f6c9e28e88f631d39573c7534896ffe585ec98ed809055bc0514bbb878632")
