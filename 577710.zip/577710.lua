-- Lua provided by RyzenAPI
-- Game: Pirates of Everseas

-- MAIN APPLICATION
addappid(577710)

-- MAIN APP DEPOTS / PACKAGES
addappid(577711, 1, "d61edf47a3408dff960334bc5c494e1f7b7f5f9e746944e46116fbb43f513d9e")
addappid(577712, 1, "3f857a331a2211bdbdd9b52444b8e6c13356f37447458460f21e5a8eaeaee0fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
