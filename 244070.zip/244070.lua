-- Lua provided by RyzenAPI
-- Game: Sid Meier’s Ace Patrol

-- MAIN APPLICATION
addappid(244070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(244071, 1, "786218b886b08cff66fd1999192358b843448f6807e4dc66951d5eacad2b0780")
addappid(244072, 1, "e9d0ab89fa017873a95bac2e8a28bb7b68f92c90a4c22ca87617b3a61a8c7154")

