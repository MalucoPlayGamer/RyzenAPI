-- Lua provided by RyzenAPI
-- Game: Abiotic Factor Demo

-- MAIN APPLICATION
addappid(2454840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454841, 1, "46d68737be099b9892a1af3ad05430538bda020165a777fe295543e0b6b88a79")
