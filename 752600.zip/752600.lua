-- Lua provided by RyzenAPI
-- Game: Game: Dual Snake

-- MAIN APPLICATION
addappid(752600)
-- Game: addappid(752600)

-- MAIN APP DEPOTS / PACKAGES
addappid(752601, 1, "a60d23cbab50ef590504be0b745b22bf8d6f4c2418698f561e90e4aaec7144e3")
