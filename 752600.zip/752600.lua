-- Lua provided by SkyAPI 
-- Game: Dual Snake
addappid(752600)
addappid(752601, 1, "a60d23cbab50ef590504be0b745b22bf8d6f4c2418698f561e90e4aaec7144e3")
