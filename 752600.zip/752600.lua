-- Lua provided by RyzenAPI
-- Game: Dual Snake

-- MAIN APPLICATION
addappid(752600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(752601, 1, "a60d23cbab50ef590504be0b745b22bf8d6f4c2418698f561e90e4aaec7144e3")

