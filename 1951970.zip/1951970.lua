-- Lua provided by RyzenAPI
-- Game: Abedot Family Estate: Search For Hidden Objects

-- MAIN APPLICATION
addappid(1951970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951971, 1, "c939357003824e79b22a719a0c8aef26da984efc2acad71cf327005cff788475")
