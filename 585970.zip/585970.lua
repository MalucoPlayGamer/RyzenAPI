-- Lua provided by RyzenAPI
-- Game: Game: Tank Assault X

-- MAIN APPLICATION
addappid(585970)
-- Game: addappid(585970)

-- MAIN APP DEPOTS / PACKAGES
addappid(585971, 1, "27557e03b3fbc7ec2cbcc31d2399df64acbdf6d45966058d037a1f3fb8235638")
addappid(585972, 1, "a5ba2b92ee9259826a1ae12f581e1422c6d5e2126b2dd5021b06d45e50d74d74")
addappid(585973, 1, "cf3186b2a5a66041e14b47543a858fa9fc318cd126f59a85672b4c3a78861aa5")
