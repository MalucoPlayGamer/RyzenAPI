-- Lua provided by RyzenAPI
-- Game: Game: AppID 1275790

-- MAIN APPLICATION
addappid(1275790)
-- Game: addappid(1275790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275791, 1, "9ba148c8bb1f4512857d6ef983993363e99f18fb98845021e2cc642f3950a81d")
