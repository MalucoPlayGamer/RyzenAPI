-- Lua provided by RyzenAPI
-- Game: Warfare

-- MAIN APPLICATION
addappid(35300)
-- Game: addappid(35300)

-- MAIN APP DEPOTS / PACKAGES
addappid(35301, 1, "eaf9e10a496d13623393248909f185dda004c17f3d5b20d5dd4f680735544943")
