-- Lua provided by SkyAPI 
-- Game: Warfare
addappid(35300)
addappid(35301, 1, "eaf9e10a496d13623393248909f185dda004c17f3d5b20d5dd4f680735544943")
