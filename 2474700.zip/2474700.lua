-- Lua provided by RyzenAPI
-- Game: Of the Red, the Light, and the Ayakashi Tsuzuri

-- MAIN APPLICATION
addappid(2474700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474701, 1, "df5530a71e5071f43d38282225556c4b6f86de708abe0181b9de0f466c25554a")

