-- Lua provided by RyzenAPI 
-- Game: AppID 3204990
addappid(3204990)
addappid(3204991, 1, "1fc1665037a634b7a7ecb37c579053b14120acfab8e2d275557ddd324dd5c094")
