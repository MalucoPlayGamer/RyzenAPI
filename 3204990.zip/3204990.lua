-- Lua provided by RyzenAPI
-- Game: addappid(3204990)

-- MAIN APPLICATION
addappid(3204990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204991, 1, "1fc1665037a634b7a7ecb37c579053b14120acfab8e2d275557ddd324dd5c094")
