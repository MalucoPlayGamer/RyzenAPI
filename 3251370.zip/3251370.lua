-- Lua provided by RyzenAPI
-- Game: Lawnmower Game: 2024

-- MAIN APPLICATION
addappid(3251370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(3251371, 1, "d4b9bca067b5c8d0ad16b6be7a1c09a51101128056d98b645d7de0d51350f6ba")

