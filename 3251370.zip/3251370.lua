-- Lua provided by RyzenAPI
-- Game: Game: Lawnmower Game: 2024

-- MAIN APPLICATION
addappid(3251370)
-- Game: addappid(3251370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251371, 1, "d4b9bca067b5c8d0ad16b6be7a1c09a51101128056d98b645d7de0d51350f6ba")
