-- Lua provided by RyzenAPI
-- Game: 1157090

-- MAIN APPLICATION
addappid(1157090)
-- Game: addappid(1157090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157091, 1, "4ebbcf6316ae25269a59bb0fa5773221b25c54cfd2d51df2032785f41e013967")
