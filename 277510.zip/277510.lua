-- Lua provided by SkyAPI 
-- Game: Shiny The Firefly
addappid(277510)
addappid(277511, 1, "569af198e2d9f0b170b52e598e3283481cfe2545d89f0b3f7e5c77a7b9318eee")
addappid(277512, 1, "c9c79f243222d0648bfe2739861c9c05cb68f82fe72cec5eb6db0d8c4bcd0bc8")
addappid(277513, 1, "aa9f6221442e4c1180d10d2a24ed5d6f13d9a18ee9303a1ba65c48c776a693f8")
