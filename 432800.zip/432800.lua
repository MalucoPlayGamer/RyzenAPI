-- Lua provided by RyzenAPI
-- Game: Crashlands Soundtrack

-- MAIN APPLICATION
addappid(432800)
addappid(432801)

-- MAIN APP DEPOTS / PACKAGES
addappid(432800,0,"72c5107cba98bc95bde59790750922e05c9d00957342c518c5948f7f0ebaafbc")

