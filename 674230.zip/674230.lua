-- Lua provided by RyzenAPI
-- Game: addappid(674230)

-- MAIN APPLICATION
addappid(674230)

-- MAIN APP DEPOTS / PACKAGES
addappid(674231, 1, "68507738d7f9157ac589c2ed747e87f413fdde37f9792b9e4f76c875dbc22fab")
