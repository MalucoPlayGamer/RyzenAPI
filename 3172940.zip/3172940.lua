-- Lua provided by RyzenAPI
-- Game: Heads Will Roll: Reforged - Threads of Destiny

-- MAIN APPLICATION
addappid(3172940)
-- Game: addappid(3172940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172940,0,"dee694c2924c53087d62b2c82f564125ebafbd954d8221abc74ab6fce72fb85f")
