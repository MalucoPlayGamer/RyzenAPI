-- Lua provided by SkyAPI 
-- Game: Metempsychosis
addappid(1667110)
addappid(1667111, 1, "2abb5ebd2b911961509c66073dccfd1ee5c32a9a57970ad4cbbde42ae9ec6142")
addappid(2295020)
