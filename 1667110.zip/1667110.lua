-- Lua provided by RyzenAPI
-- Game: Metempsychosis

-- MAIN APPLICATION
addappid(1667110)
addappid(2295020)
-- Game: addappid(1667110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667111, 1, "2abb5ebd2b911961509c66073dccfd1ee5c32a9a57970ad4cbbde42ae9ec6142")
