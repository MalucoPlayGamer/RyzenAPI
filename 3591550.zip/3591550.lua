-- Lua provided by RyzenAPI
-- Game: Hunter Roulette

-- MAIN APPLICATION
addappid(3591550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3591552,0,"1cb4c37523815e21e4634b0f1bb8582ddb4659f4ec4579f72d0065690f900644")

