-- Lua provided by RyzenAPI
-- Game: Double

-- MAIN APPLICATION
addappid(887820)

-- MAIN APP DEPOTS / PACKAGES
addappid(887822,0,"f4c1a1008388fdf5dc4d4d24b566b5bc298055c6affbeece11f2f6722841e606")
