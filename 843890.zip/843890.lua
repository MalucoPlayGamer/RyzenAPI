-- Lua provided by RyzenAPI
-- Game: 843890

-- MAIN APPLICATION
addappid(843890)
-- Game: addappid(843890)

-- MAIN APP DEPOTS / PACKAGES
addappid(843891, 1, "82e0ccda59aefb1b981bd644acb11fd33e0e8d16d059c7a82e293fc0a667fd6c")
