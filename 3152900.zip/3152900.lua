-- Lua provided by RyzenAPI
-- Game: 3152900

-- MAIN APPLICATION
addappid(3152900)
-- Game: addappid(3152900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152901, 1, "5ca64815c6dc96e881c689bd6ea40694ccbadb3069cf24425464ca4ac46d796c")
