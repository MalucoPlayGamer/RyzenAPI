-- Lua provided by RyzenAPI 
-- Game: Touhou Fantasy
addappid(3152900)
addappid(3152901, 1, "5ca64815c6dc96e881c689bd6ea40694ccbadb3069cf24425464ca4ac46d796c")
