-- Lua provided by RyzenAPI
-- Game: 946780

-- MAIN APPLICATION
addappid(946780)
addappid(952480)
-- Game: addappid(946780)

-- MAIN APP DEPOTS / PACKAGES
addappid(946781, 1, "526d79d5bb7437699b8dfb4eb1583d40c7f3ce7cd8da33820a26c4539aec4cd0")
