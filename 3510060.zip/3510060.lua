-- Lua provided by RyzenAPI
-- Game: Hellbrella

-- MAIN APPLICATION
addappid(3510060)
addappid(3925560)
addappid(4461360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3510061, 1, "d8fa1495447ab2a895474774c3ac54b9f8846248ab99c1da25201207bef9260c")

