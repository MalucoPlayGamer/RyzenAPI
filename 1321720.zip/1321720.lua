-- Lua provided by RyzenAPI
-- Game: 1321720

-- MAIN APPLICATION
addappid(1321720)
-- Game: addappid(1321720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321721, 1, "8d414c8dceba63162955044dd0931d5ae7090ed339712e3aceacadad00edf22e")
