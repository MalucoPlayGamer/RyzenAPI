-- Lua provided by RyzenAPI
-- Game: 2423270

-- MAIN APPLICATION
addappid(2423270)
-- Game: addappid(2423270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423272,0,"ccffea3d3a1c70e39303460b4afded0480b97015e8956aef1a3297d88d614324")
