-- Lua provided by RyzenAPI
-- Game: AppID 1165860

-- MAIN APPLICATION
addappid(1165860)
-- Game: addappid(1165860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165861, 1, "6fa9d6eb08a76d81b119708b1314f407107171e82613f99f411cbef4c3ebbaef")
