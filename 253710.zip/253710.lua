-- Lua provided by RyzenAPI
-- Game: theHunter Classic

-- MAIN APPLICATION
addappid(253710)
addappid(584970)

-- MAIN APP DEPOTS / PACKAGES
addappid(253711, 1, "5f3b0023cb87e2e4c58472f2bf8c6036a2bd4c07a2b36083c69a2fea91e7e906")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(304000)
addappid(322360)
addappid(322361)
addappid(582170)
addappid(582171)
addappid(582172)
addappid(586410)
addappid(637990)
