-- Lua provided by RyzenAPI
-- Game: Game: theHunter Classic

-- MAIN APPLICATION
addappid(253710)
addappid(584970)
-- Game: addappid(253710)

-- MAIN APP DEPOTS / PACKAGES
addappid(253711, 1, "5f3b0023cb87e2e4c58472f2bf8c6036a2bd4c07a2b36083c69a2fea91e7e906")
