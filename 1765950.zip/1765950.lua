-- Lua provided by SkyAPI 
-- Game: SpookyMilkLife Demo
addappid(1765950)
addappid(1765951, 1, "5c2609d17c8356edacacdaf903ab3d77ccf2809a408bb30cf29ed35495d60cb7")
