-- Lua provided by RyzenAPI
-- Game: SpookyMilkLife Demo

-- MAIN APPLICATION
addappid(1765950)
-- Game: addappid(1765950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765951, 1, "5c2609d17c8356edacacdaf903ab3d77ccf2809a408bb30cf29ed35495d60cb7")
