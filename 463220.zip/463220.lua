-- Lua provided by SkyAPI 
-- Game: Dungeon of Zolthan
addappid(463220)
addappid(463221, 1, "e5c8cc4d1cebb09e55b08a36e5d040f5b076879c8c91ccf7b05817a6aa56e5ba")
addappid(463222, 1, "7a9e642cc63387ea34233c9f2991032a6701dcfa50067aa487d01cfe843e929d")
