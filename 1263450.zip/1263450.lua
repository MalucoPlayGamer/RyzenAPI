-- Lua provided by RyzenAPI
-- Game: Game: 蔚蓝月下

-- MAIN APPLICATION
addappid(1263450)
-- Game: addappid(1263450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263451, 1, "e73b02b5c6257c460f0d7bcc39bb65db45d992a2cff544e951184249793159a9")
