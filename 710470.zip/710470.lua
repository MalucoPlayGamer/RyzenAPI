-- Lua provided by RyzenAPI
-- Game: AppID 710470

-- MAIN APPLICATION
addappid(710470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(710471, 1, "672f8405751b9038891269cca357b4cd1087d5824c0f45283751afdaae0c2162")

