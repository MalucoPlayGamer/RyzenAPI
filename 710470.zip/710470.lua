-- Lua provided by RyzenAPI
-- Game: Game: AppID 710470

-- MAIN APPLICATION
addappid(710470)
-- Game: addappid(710470)

-- MAIN APP DEPOTS / PACKAGES
addappid(710471, 1, "672f8405751b9038891269cca357b4cd1087d5824c0f45283751afdaae0c2162")
