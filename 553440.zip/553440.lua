-- Lua provided by RyzenAPI
-- Game: AppID 553440

-- MAIN APPLICATION
addappid(553440)

-- MAIN APP DEPOTS / PACKAGES
addappid(553441, 1, "6698adbea139edbbc8a95c07f1a48934cd2e9349ea0f92a1095b7fc68cf4f505")

