-- Lua provided by RyzenAPI
-- Game: AppID 993090

-- MAIN APPLICATION
addappid(993090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(993091, 1, "3a02317ffe8c475c236c603a9fcd31c7cd8e4a109240f4c3d9fa28081bdc02bd")
addappid(993092, 1, "7f42c4f024fecc789a821093226e8655818e4f981c698ff5f5bba81abe4edda3")

