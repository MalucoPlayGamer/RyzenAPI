-- Lua provided by RyzenAPI
-- Game: AppID 640300

-- MAIN APPLICATION
addappid(640300)

-- MAIN APP DEPOTS / PACKAGES
addappid(640301, 1, "ec21d53265af87142be43e675afddd60e5ee1121127bcbda49d76cba53b78d89")
