-- Lua provided by RyzenAPI
-- Game: 1700550

-- MAIN APPLICATION
addappid(1700550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700552,0,"47c8270be87194eba069258f1bce433cc8d3f5f1f3bbb881d9fbabecb6d41bce")
