-- Lua provided by RyzenAPI
-- Game: Isekai Succubus ~My Genderbent Saga in Another World~

-- MAIN APPLICATION
addappid(1383680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383681, 1, "97f1165194fac61576685c69230952b6c0e7954775a0e80190f8a67e6004a94a")

