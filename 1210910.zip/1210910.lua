-- Lua provided by RyzenAPI
-- Game: 1210910

-- MAIN APPLICATION
addappid(1210910)
-- Game: addappid(1210910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210911, 1, "5f59ddb6e38a7033041b4eaf1fb46163b256e6a95e4af208d6de3f758fd1e3c5")
