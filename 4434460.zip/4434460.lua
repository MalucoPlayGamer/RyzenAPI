-- Lua provided by RyzenAPI
-- Game: Dungeon Infinite

-- MAIN APPLICATION
addappid(4434460) -- Dungeon Infinite

-- MAIN APP DEPOTS / PACKAGES
addappid(4434461, 1, "ca3c3fd4040c924cd5e66ac67f177a8bdcc7461a7a42cd4308aa8e7374e6f9ff") -- Depot 4434461

