-- 4434460's Lua and Manifest Created by Hubcap Manifest
-- Dungeon Infinite
-- Created: August 01, 2026 at 09:12:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4434460) -- Dungeon Infinite
-- MAIN APP DEPOTS
addappid(4434461, 1, "ca3c3fd4040c924cd5e66ac67f177a8bdcc7461a7a42cd4308aa8e7374e6f9ff") -- Depot 4434461
setManifestid(4434461, "269963406009354800", 147303638)