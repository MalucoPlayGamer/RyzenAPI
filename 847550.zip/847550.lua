-- Lua provided by RyzenAPI
-- Game: Game: Strike!OvulationDivine Fist!  Rebellion to Extinction!

-- MAIN APPLICATION
addappid(847550)
-- Game: addappid(847550)

-- MAIN APP DEPOTS / PACKAGES
addappid(847551, 1, "53b942e48bf988c352d8591af8ced3a3fbb75dafc2b663284cc6faa6147e3356")
addappid(847552, 1, "c008b09a6305ec374ab78b717d63e128dc2b96f73b8f4fb53216c7a24ab85499")
