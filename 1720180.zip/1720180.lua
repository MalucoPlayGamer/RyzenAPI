-- Lua provided by RyzenAPI 
-- Game: Mini Island: Autumn
addappid(1720180)
addappid(1720181, 1, "c7b6a01d2e62cd58d7ad016d512461759ffc19141e862bff8d2d330a14b0ad5e")
