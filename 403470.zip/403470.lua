-- Lua provided by RyzenAPI
-- Game: MAGIX PC Check & Tuning 2016

-- MAIN APPLICATION
addappid(403470)

-- MAIN APP DEPOTS / PACKAGES
addappid(403471, 1, "4950f5885249ec3ca5a55ba0a460310d0e9a33e6211cc3ac536cc77c89676cfa")
addappid(403476, 1, "d62c64c8e29fb42231120a099a3cba5270b6fe540270ad9dd898b3648fd3ce19")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
