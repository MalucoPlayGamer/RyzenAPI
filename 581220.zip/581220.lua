-- Lua provided by RyzenAPI
-- Game: News Tycoon

-- MAIN APPLICATION
addappid(581220)

-- MAIN APP DEPOTS / PACKAGES
addappid(581221,0,"97e5e3aab7de3d550f092b96649d05a52b09ac5ec9cf644a1c9a5277068a5e86")

