-- Lua provided by SkyAPI 
-- Game: AppID 259470
addappid(259470)
addappid(259471, 1, "81b3bfa18e0bb9ce456c56309db1cad44b9246ddb29e36c8b674d05242dcb66e")
addappid(259472, 1, "f18da87afb812819d7c1ba1a90f39994c4ad2006927e7a14a8b1ddeae72e0767")
addappid(259473, 1, "e56f0f393daeab4de8dcf4dc0bcaf21e56240de9307cdf89cff37656f2db9429")
addappid(266810)
addappid(267870)
