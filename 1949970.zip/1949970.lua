-- Lua provided by RyzenAPI
-- Game: J-Jump Arena

-- MAIN APPLICATION
addappid(1949970)
addappid(2401760)
-- Game: addappid(1949970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949971, 1, "cc0d36f870e4d2843dba34e2128bc6debebd0801fd2b43a401dea60bdc1a8aa4")
