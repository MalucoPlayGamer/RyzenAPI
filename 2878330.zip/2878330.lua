-- Lua provided by SkyAPI 
-- Game: AppID 2878330
addappid(2878330)
addappid(2878331, 1, "82aa424b05646b0b70b151023551e8961d01e0266a5f36ae508077d3ee3fedc2")
