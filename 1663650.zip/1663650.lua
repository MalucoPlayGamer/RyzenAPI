-- Lua provided by RyzenAPI
-- Game: Knife To Meet You

-- MAIN APPLICATION
addappid(1663650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663651,0,"8f80b872864cbb00e6978e660c11e0bbdacf2049566163ae0299eb79b6aaeb30")

