-- Lua provided by SkyAPI 
-- Game: Shopping Center Tycoon
addappid(2200620)
addappid(2200621, 1, "a234f67f8deba579f1b90d3d8eb9415348b020ee116ce35986dd2c230ebf208b")
