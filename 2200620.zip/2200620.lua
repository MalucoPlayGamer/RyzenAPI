-- Lua provided by RyzenAPI
-- Game: 2200620

-- MAIN APPLICATION
addappid(2200620)
-- Game: addappid(2200620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200621, 1, "a234f67f8deba579f1b90d3d8eb9415348b020ee116ce35986dd2c230ebf208b")
