-- Lua provided by RyzenAPI
-- Game: Godius Eternal War

-- MAIN APPLICATION
addappid(4559140)
