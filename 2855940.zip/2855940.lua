-- Lua provided by RyzenAPI
-- Game: Game: Betrayed

-- MAIN APPLICATION
addappid(2855940)
-- Game: addappid(2855940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2855941, 1, "9463823d436cb2365132dc1a40a8873e4efa6d718a1829f18f4c81efa7e12a0d")
