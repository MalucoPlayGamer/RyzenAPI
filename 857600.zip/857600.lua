-- Lua provided by RyzenAPI
-- Game: Fight the Horror

-- MAIN APPLICATION
addappid(857600)

-- MAIN APP DEPOTS / PACKAGES
addappid(857601,0,"e867a9d5255681b8fb8faeff60a16ad5aa492e783629516c8a329d007b73f6c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
