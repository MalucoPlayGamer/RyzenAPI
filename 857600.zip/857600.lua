-- Lua provided by RyzenAPI
-- Game: Fight the Horror

-- MAIN APPLICATION
addappid(857600)

-- MAIN APP DEPOTS / PACKAGES
addappid(857601,0,"e867a9d5255681b8fb8faeff60a16ad5aa492e783629516c8a329d007b73f6c3")

