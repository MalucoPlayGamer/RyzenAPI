-- Lua provided by RyzenAPI
-- Game: DSS 2: War Industry

-- MAIN APPLICATION
addappid(3582440)
addappid(4820280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582441,0,"508fc824e652730a54c8eb6c55e9cde1af78bed54cff74c4348f4010bd2f6b8c")
