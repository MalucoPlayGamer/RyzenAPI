-- Lua provided by SkyAPI 
-- Game: AppID 1008920
addappid(1008920)
addappid(1008921, 1, "d044e9530b6f575a4d43f97dc2095f9e0cc058191f03363e2b0b52e21a7a4d98")
