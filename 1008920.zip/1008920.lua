-- Lua provided by RyzenAPI
-- Game: Photographs

-- MAIN APPLICATION
addappid(1008920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008921, 1, "d044e9530b6f575a4d43f97dc2095f9e0cc058191f03363e2b0b52e21a7a4d98")
