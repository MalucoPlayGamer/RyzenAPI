-- 3565980's Lua and Manifest Created by Hubcap Manifest
-- The Stalked 3
-- Created: August 21, 2026 at 01:46:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3565980, 1, "9efe5023a007e20ce50d0b41c570ee06d28fb7dd9461e66ab8721d9c4fca76f2") -- The Stalked 3
-- MAIN APP DEPOTS
addappid(3565981, 1, "e64b06506f1186972139f04d29cabdd759aab6e6f2d1c8ae4af9c7b79365136e") -- Depot 3565981
setManifestid(3565981, "727938905936732042", 7242701454)