-- Lua provided by RyzenAPI
-- Game: Game: Caravan Sandwitch Demo

-- MAIN APPLICATION
addappid(3036980)
-- Game: addappid(3036980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036981, 1, "e84fce688a89003c03880ffb72a27fb1a832802fa73916bcd0ae7311181d594b")
