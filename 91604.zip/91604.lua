-- Lua provided by RyzenAPI
-- Game: Sanctum: Official Soundtrack

-- MAIN APPLICATION
addappid(91604)

-- MAIN APP DEPOTS / PACKAGES
addappid(91604,0,"4e9ee46e784a7730f9f90e6c9e60618f2f3733c83a95c05652710d7a9581021d")

