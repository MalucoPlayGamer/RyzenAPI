-- Lua provided by RyzenAPI
-- Game: Decimate Drive

-- MAIN APPLICATION
addappid(2427950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427951, 1, "41442322936fda4ea9ec07bfb4a24a03ad26e795576d81cc34c17883d64f1a07")

