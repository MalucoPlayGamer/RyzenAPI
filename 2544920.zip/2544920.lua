-- Lua provided by RyzenAPI
-- Game: Jujutsu Kaisen Cursed Clash - Jujusta 2024

-- MAIN APPLICATION
addappid(2544920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544920,0,"410c45819542016f665d18953ecc4e08cc691f93f9952ceb7085309cfff121a5")

