-- Lua provided by RyzenAPI
-- Game: AppID 1147030

-- MAIN APPLICATION
addappid(1147030)
-- Game: addappid(1147030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147031, 1, "85edeb02f22d17891a837a8ec2abf8017dcad568d1d42aec33f41111956c1113")
