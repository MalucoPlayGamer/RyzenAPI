-- Lua provided by RyzenAPI
-- Game: The Terrible Old Man

-- MAIN APPLICATION
addappid(1147030)
addappid(1147040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1147031, 1, "85edeb02f22d17891a837a8ec2abf8017dcad568d1d42aec33f41111956c1113")
