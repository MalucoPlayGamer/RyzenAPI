-- Lua provided by RyzenAPI
-- Game: 2865900

-- MAIN APPLICATION
addappid(2865900)
-- Game: addappid(2865900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865901, 1, "4dff282ef4bed80a67fb9c1b28ac4b5ca9cc4cf78f7fa271e00815e0ee5d06f0")
