-- Lua provided by RyzenAPI
-- Game: Where is Mr Cloud

-- MAIN APPLICATION
addappid(2419870)
-- Game: addappid(2419870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419871, 1, "85245b26ac39bba4403701f855fc038c77e70a13b80d60e41013bd8a398c125f")
