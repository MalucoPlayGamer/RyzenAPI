-- Lua provided by RyzenAPI
-- Game: 2295530

-- MAIN APPLICATION
addappid(2295530)
addappid(2295640)
-- Game: addappid(2295530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295531, 1, "99043be51fa07657f972170af3b521b41caf2f0da81b70ad0797cf43b9357746")
