-- Lua provided by RyzenAPI
-- Game: addappid(523790)

-- MAIN APPLICATION
addappid(523790)

-- MAIN APP DEPOTS / PACKAGES
addappid(523791, 1, "c44a4fee837072c1118b08071bfad35e269a2065f5906a9b59f958a1ce11b339")
