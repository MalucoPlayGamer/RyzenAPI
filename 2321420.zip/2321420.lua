-- Lua provided by RyzenAPI
-- Game: 房间的秘密2：起点

-- MAIN APPLICATION
addappid(2321420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2321421, 1, "8554c4635ca986d84f13e2f73d1f5d5c1fe8e22e832957e15e3fbdacd992b647")

