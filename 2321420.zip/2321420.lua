-- Lua provided by RyzenAPI
-- Game: 房间的秘密2：起点

-- MAIN APPLICATION
addappid(2321420)
-- Game: addappid(2321420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321421, 1, "8554c4635ca986d84f13e2f73d1f5d5c1fe8e22e832957e15e3fbdacd992b647")
