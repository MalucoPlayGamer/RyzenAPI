-- Lua provided by RyzenAPI 
-- Game: Trivia Vault: TV Trivia
addappid(851520)
addappid(851521, 1, "50a4c114f50cdb3372c66a7452e9a07cbff850e88ba2bbdd67d0c4c04d0ba090")
