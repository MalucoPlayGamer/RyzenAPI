-- Lua provided by RyzenAPI
-- Game: Asterika: Phantom Rose Refrain

-- MAIN APP DEPOTS / PACKAGES
addappid(3690850, 1, "105c4e1610cf73afda7058d39848d80c51aa85fa47b6b77d04bc58619d6fd8a5") -- Asterika: Phantom Rose Refrain
addappid(3690852, 1, "e41cec4045e884a3fd8424428df8f3d83c17bf19a18472a2541270f39d546b7c") -- Depot 3690852
addappid(3690853, 1, "a9dd6dff3efc0264f4b95af372603985cc63be8799d685dfc22c4f7ace65dab5") -- Depot 3690853

