-- Lua provided by RyzenAPI
-- Game: Hostage: Rescue Mission

-- MAIN APPLICATION
addappid(781290)

-- MAIN APP DEPOTS / PACKAGES
addappid(781291, 1, "8bc1506218bd64791d2a67c1b4e9afdbc46b8344755e4eebb6349edf14ed652c")
