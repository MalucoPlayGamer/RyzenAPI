-- Lua provided by RyzenAPI
-- Game: Game: Deep Cuts OST - Bastard Town

-- MAIN APPLICATION
addappid(3575540)
-- Game: addappid(3575540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575541, 1, "d7f84dbbd7007505006de77aa44499af0636c3ef9f6655185e8882420863fbae")
addappid(3575542, 1, "add623dcffd59d0512884f380c4e7e951487479c657c1ea62b812c03f3116866")
