-- Lua provided by RyzenAPI
-- Game: The Lady with the Dog

-- MAIN APPLICATION
addappid(4895940) -- The Lady with the Dog

-- MAIN APP DEPOTS / PACKAGES
addappid(4895941, 1, "db68492b269185c555486ff91e912a9bf4498c43e157425b33e28aa8d08745bd") -- Depot 4895941
addappid(4895942, 1, "6becbf8a717c75c00abdf28233ae48a17e199b6e05663ba8ad0c2769eb60bf23") -- Depot 4895942
addappid(4895943, 1, "4b9fdc3c38e6da4be1dc926ebb44e3ab2e844a0d5fe51a93e4d2fe509ffe6419") -- Depot 4895943

