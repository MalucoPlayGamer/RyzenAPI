-- Lua provided by SkyAPI 
-- Game: AppID 457770
addappid(457770)
addappid(457771, 1, "4eb011125b5dd289524b70efa842a8d61379c79de8582f5cdd4ebe535281a287")
