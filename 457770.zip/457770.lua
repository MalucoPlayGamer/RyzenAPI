-- Lua provided by RyzenAPI
-- Game: 457770

-- MAIN APPLICATION
addappid(457770)
-- Game: addappid(457770)

-- MAIN APP DEPOTS / PACKAGES
addappid(457771, 1, "4eb011125b5dd289524b70efa842a8d61379c79de8582f5cdd4ebe535281a287")
