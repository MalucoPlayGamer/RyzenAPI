-- Lua provided by RyzenAPI
-- Game: Dangerous Diver

-- MAIN APPLICATION
addappid(4901970) -- Dangerous Diver

-- MAIN APP DEPOTS / PACKAGES
addappid(4901971, 1, "c7dc3861bf4ca9fc5b583d86be99b65df034e95328a46c459ede9e9b6816754d") -- Depot 4901971

