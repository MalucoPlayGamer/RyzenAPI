-- 4901970's Lua and Manifest Created by Hubcap Manifest
-- Dangerous Diver
-- Created: August 04, 2026 at 09:31:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4901970) -- Dangerous Diver
-- MAIN APP DEPOTS
addappid(4901971, 1, "c7dc3861bf4ca9fc5b583d86be99b65df034e95328a46c459ede9e9b6816754d") -- Depot 4901971
setManifestid(4901971, "3913326528484891855", 396218947)