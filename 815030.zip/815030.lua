-- Lua provided by RyzenAPI
-- Game: AppID 815030

-- MAIN APPLICATION
addappid(815030)

-- MAIN APP DEPOTS / PACKAGES
addappid(815031, 1, "40793214cc8fdd4287efe6931d6e4a4255a2c39f7ecf2b9f2ba20759308ee26e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
