-- Lua provided by RyzenAPI
-- Game: Game: AppID 815030

-- MAIN APPLICATION
addappid(815030)
-- Game: addappid(815030)

-- MAIN APP DEPOTS / PACKAGES
addappid(815031, 1, "40793214cc8fdd4287efe6931d6e4a4255a2c39f7ecf2b9f2ba20759308ee26e")
