-- Lua provided by RyzenAPI 
-- Game: Infestation: Origins
addappid(2635640)
addappid(2635641, 1, "983410bbdbcf9ad4bfe8ffcf8f24cbceb53f9fbc51a5081cee6d44d6ed83cb2e")
