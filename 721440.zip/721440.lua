-- Lua provided by RyzenAPI
-- Game: AppID 721440

-- MAIN APPLICATION
addappid(721440)
-- Game: addappid(721440)

-- MAIN APP DEPOTS / PACKAGES
addappid(721441, 1, "b65d57cc60ffdaa1f4008a260c0733647ffcea4e1a26a965f04d395c98b81a23")
