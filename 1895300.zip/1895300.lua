-- Lua provided by SkyAPI 
-- Game: Shinobi Warfare
addappid(1895300)
addappid(1895301, 1, "2c5d73fd62512163fc5dbd39b1396e0986b8ef97f14e98fc0f7e3b15a7bfb7cd")
