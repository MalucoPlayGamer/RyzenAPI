-- Lua provided by RyzenAPI
-- Game: addappid(934540)

-- MAIN APPLICATION
addappid(934540)

-- MAIN APP DEPOTS / PACKAGES
addappid(934541, 1, "8d2eaee1f4df0f9a02fddfe865c89d06faf3363328eb34511f8866528779e6f8")
addappid(955240, 0, "7fe481f86d7e09fab02b971ab9f7c59293e39e60986abfd65e40c87d9ae455b9")
