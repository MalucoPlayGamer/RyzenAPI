-- Lua provided by RyzenAPI 
-- Game: Milkyway Funland
addappid(1481580)
addappid(1481581, 1, "a248e65d84686684bec8eca0c8b3feb7052a1ece88d2fee67ef70b3a2c4218b3")
