-- Lua provided by RyzenAPI
-- Game: addappid(1460550)

-- MAIN APPLICATION
addappid(1460550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460551, 1, "f138dddeaae4451ea438a7fc3ee4c3d1182a7c49ef97666cb04d074f7d5c415a")
