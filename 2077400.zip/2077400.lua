-- Lua provided by RyzenAPI
-- Game: AppID 2077400

-- MAIN APPLICATION
addappid(2077400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077401, 1, "a593295da48e6d06aac126d48bf982274a417bb068cb3fbd3948bcc833690fa9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2086240)
