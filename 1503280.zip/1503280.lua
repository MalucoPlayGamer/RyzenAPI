-- Lua provided by RyzenAPI
-- Game: 1503280

-- MAIN APPLICATION
addappid(1503280)
-- Game: addappid(1503280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503281, 1, "c16f7eff3eed96f8c73cde161b09b62e603b2123bf4076f6baf7eec88a44a28e")
