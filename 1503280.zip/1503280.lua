-- Lua provided by RyzenAPI
-- Game: Octarina

-- MAIN APPLICATION
addappid(1503280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1503281, 1, "c16f7eff3eed96f8c73cde161b09b62e603b2123bf4076f6baf7eec88a44a28e")

