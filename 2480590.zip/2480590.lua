-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Heroes

-- MAIN APPLICATION
addappid(2480590)
-- Game: addappid(2480590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480591, 1, "65f6cddaef611b693b51a6040f164447ff0ebc300c9127220d46cb22592a756c")
