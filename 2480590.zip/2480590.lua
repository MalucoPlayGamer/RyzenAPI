-- Lua provided by RyzenAPI
-- Game: Dungeon Heroes

-- MAIN APPLICATION
addappid(2480590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480591, 1, "65f6cddaef611b693b51a6040f164447ff0ebc300c9127220d46cb22592a756c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
