-- Lua provided by SkyAPI 
-- Game: AppID 3317580
addappid(3317580)
addappid(3317581, 1, "630fbffc5d37dbbe1004a2ae421d10679f0c3db16248d1b97dd3c058688814ce")
addappid(3327540)
