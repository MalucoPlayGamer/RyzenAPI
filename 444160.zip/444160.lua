-- Lua provided by RyzenAPI
-- Game: Bonsai

-- MAIN APPLICATION
addappid(444160)

-- MAIN APP DEPOTS / PACKAGES
addappid(444161, 1, "4b6026d3978e791ee9665c325babb36c72ca570126764d0acc974f52587dcc84")
addappid(444162, 1, "d780c85197d4584dabe17eec22a07f710b9055d3ea02432e659d0193ecabd797")
addappid(444163, 1, "5f37abceeb58747b5deabf444aefac81ced87dcf6b5e11e57a54d2380f8e811b")

