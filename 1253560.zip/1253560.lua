-- Lua provided by RyzenAPI
-- Game: addappid(1253560)

-- MAIN APPLICATION
addappid(1253560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253561, 1, "e2bd467eaea6c2faf0aeccf8d4804bf1a8ab5f007f012a09710eb07ba2ed3499")
