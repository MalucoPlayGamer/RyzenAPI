-- Lua provided by RyzenAPI 
-- Game: Frontier Pilot Simulator Soundtracks
addappid(1253560)
addappid(1253561, 1, "e2bd467eaea6c2faf0aeccf8d4804bf1a8ab5f007f012a09710eb07ba2ed3499")
