-- Lua provided by RyzenAPI
-- Game: Defenders of the Omniverse

-- MAIN APPLICATION
addappid(2461840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461841,0,"ebbaeddcb578c2922071a98e1927adaf12a5e2c7775bef5e22da84dc2fb77c4a")

