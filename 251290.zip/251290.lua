-- Lua provided by RyzenAPI
-- Game: addappid(251290)

-- MAIN APPLICATION
addappid(251290)

-- MAIN APP DEPOTS / PACKAGES
addappid(251291, 1, "1cde59018cca24d71167e88e27921647ddb4b55673b17855b4b1b2560ddbbde6")
