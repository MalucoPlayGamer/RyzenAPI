-- Lua provided by RyzenAPI
-- Game: King of Vikings

-- MAIN APPLICATION
addappid(1249850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249851, 1, "d685647842f0f8eec087386974dbc4790971bcf614c04eeb270ef305f81afed7")
addappid(1249852, 1, "660cdd48518871e8c3d79de761fa2b255533dce833a274294ebb4645504fdde7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1314350)
