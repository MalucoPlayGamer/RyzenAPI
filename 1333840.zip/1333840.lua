-- Lua provided by RyzenAPI
-- Game: Overshadow

-- MAIN APPLICATION
addappid(1333840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1333841, 1, "c928bf3340320d3f46da386ec15d0c1ae036dc7ac35fb711f4e7b5eede31ae2b")

