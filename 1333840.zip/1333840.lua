-- Lua provided by RyzenAPI
-- Game: Game: Overshadow

-- MAIN APPLICATION
addappid(1333840)
-- Game: addappid(1333840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333841, 1, "c928bf3340320d3f46da386ec15d0c1ae036dc7ac35fb711f4e7b5eede31ae2b")
