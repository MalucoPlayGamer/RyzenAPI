-- Lua provided by RyzenAPI
-- Game: Pinkman

-- MAIN APPLICATION
addappid(516480)

-- MAIN APP DEPOTS / PACKAGES
addappid(516481, 1, "179e456aaa97946fb3e5794a0916145ae99c6a7852fc557d8cec5dcdcd46ea74")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
