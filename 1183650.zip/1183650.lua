-- Lua provided by SkyAPI 
-- Game: PM-1 Inverse Universe
addappid(1183650)
addappid(1183651, 1, "54b06f5dcd41bfbf52b69cf7f5e064b862294291ea765cbe6595412f9870c42d")
