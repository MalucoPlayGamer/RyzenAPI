-- Lua provided by RyzenAPI
-- Game: PM-1 Inverse Universe

-- MAIN APPLICATION
addappid(1183650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183651, 1, "54b06f5dcd41bfbf52b69cf7f5e064b862294291ea765cbe6595412f9870c42d")

