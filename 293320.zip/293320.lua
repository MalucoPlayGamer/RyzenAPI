-- Lua provided by RyzenAPI
-- Game: Game: Coma: Mortuary

-- MAIN APPLICATION
addappid(293320)
-- Game: addappid(293320)

-- MAIN APP DEPOTS / PACKAGES
addappid(293321, 1, "8f8727d1ef7390d038f8487a2304023ee84be5765bbd22b13406081a1322f8c9")
addappid(293322, 1, "2d79a85008df4a381b91b94ab234663cc098d38f0bde90338422971260a9fa40")
