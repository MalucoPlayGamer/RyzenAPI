-- Lua provided by RyzenAPI
-- Game: Coma: Mortuary

-- MAIN APPLICATION
addappid(293320)

-- MAIN APP DEPOTS / PACKAGES
addappid(293321, 1, "8f8727d1ef7390d038f8487a2304023ee84be5765bbd22b13406081a1322f8c9")
addappid(293322, 1, "2d79a85008df4a381b91b94ab234663cc098d38f0bde90338422971260a9fa40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
