-- Lua provided by RyzenAPI
-- Game: AppID 1590670

-- MAIN APPLICATION
addappid(1590670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590671, 1, "2ef3be8f9f41a7bcafc40d5dd9ea9cda69529a911987644f152ffc71c17ebac4")
addappid(1610970, 0, "212e2f6558c0fe91ed9b7fd1c39254fa6992e75f419167778d0c640c2bdd36ad")

