-- Lua provided by RyzenAPI
-- Game: Guardians of Eden Artbook

-- MAIN APPLICATION
addappid(2770450)
-- Game: addappid(2770450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2770454,0,"b3f9436d2a8efbd8866167c867cdc6a3cd2b83d6e187e9fd43587ff52fac2549")
