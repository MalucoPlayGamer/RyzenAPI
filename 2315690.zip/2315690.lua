-- Lua provided by RyzenAPI
-- Game: WWE 2K24

-- MAIN APPLICATION
addappid(2315690)
addappid(2528460)
addappid(2544390)
addappid(2584660)
addappid(2768160)
addappid(2768170)
addappid(2768180)
addappid(2768190)
addappid(2855610)
addappid(2855620)
addappid(2855630)
addappid(2855640)
addappid(3180050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2315691, 1, "23e097a5dcfd505419d23c66434881e466ae025183332849a90469800dd3d074")

