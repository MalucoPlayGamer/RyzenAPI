-- Lua provided by RyzenAPI
-- Game: Game: AppID 1017580

-- MAIN APPLICATION
addappid(1017580)
-- Game: addappid(1017580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017581, 1, "0a2ab17b37aeb37494069164c2f1d40ce060e9ac24154d714603a6908b4a6cf1")
