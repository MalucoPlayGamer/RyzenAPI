-- Lua provided by RyzenAPI
-- Game: The explorer of night

-- MAIN APPLICATION
addappid(1017580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1017581, 1, "0a2ab17b37aeb37494069164c2f1d40ce060e9ac24154d714603a6908b4a6cf1")
