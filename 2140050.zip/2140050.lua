-- Lua provided by RyzenAPI 
-- Game: SGS Battle For: Stalingrad
addappid(2140050)
addappid(2140051, 1, "6aff87b437d1f0a5b06aa0bc5d014a3a61045000e13e6eb7608b30e5e423377c")
addappid(2140053, 1, "951a97ff550a0823bb20b6ddbc5560e806dd5581b9bd1afc53816f2d1a24d429")
