-- Lua provided by RyzenAPI
-- Game: AppID 1111070

-- MAIN APPLICATION
addappid(1111070)
-- Game: addappid(1111070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111071, 1, "bf987aaabf78bf2aa0fa4eb09c10afc798c4da30426cc2263e204a0d56687bff")
