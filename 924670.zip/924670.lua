-- Lua provided by RyzenAPI
-- Game: Need for Spirit: Drink & Drive Simulator

-- MAIN APPLICATION
addappid(924670)

-- MAIN APP DEPOTS / PACKAGES
addappid(924671, 1, "ad26eead67b24ebd5ef5c82e24e7a9231cccde3aad2a98cc1f91ea41c1c8d168")

