-- Lua provided by RyzenAPI
-- Game: 3244880

-- MAIN APPLICATION
addappid(3244880)
-- Game: addappid(3244880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244881, 1, "f67ca71f7b3f300b641c884be264efb37c4cbeded724d7ac0cc0494c0bc66d84")
