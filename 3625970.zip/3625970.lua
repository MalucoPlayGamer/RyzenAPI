-- Lua provided by RyzenAPI
-- Game: addappid(3625970)

-- MAIN APPLICATION
addappid(3625970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3625971, 1, "612d6f2a9a9925e3029cfb1cb09a4686749f60b22656d30fdd1aa55a2e96a982")
