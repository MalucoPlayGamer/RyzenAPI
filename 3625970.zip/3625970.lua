-- Lua provided by RyzenAPI 
-- Game: SEX VIKING ISLAND
addappid(3625970)
addappid(3625971, 1, "612d6f2a9a9925e3029cfb1cb09a4686749f60b22656d30fdd1aa55a2e96a982")
