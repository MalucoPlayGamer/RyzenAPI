-- Lua provided by RyzenAPI
-- Game: Book of Spells 2

-- MAIN APPLICATION
addappid(3022680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022681, 1, "a1a3c620e89f6b726070c5292d6a9b84963d18d0d35109f7a20a55a9b93c426f")
