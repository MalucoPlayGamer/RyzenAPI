-- Lua provided by RyzenAPI
-- Game: 1146230

-- MAIN APPLICATION
addappid(1146230)
-- Game: addappid(1146230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146231, 1, "7ca3ae3a094b40c0aef87a16b8e884edbad23b6df4bd600e7ebc435ad95aea31")
