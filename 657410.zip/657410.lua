-- Lua provided by RyzenAPI
-- Game: Electronics Circuits Simulator

-- MAIN APPLICATION
addappid(657410)

-- MAIN APP DEPOTS / PACKAGES
addappid(657411, 1, "e5521100872988b3ec62837fe92d620ff152ca8c131077474c130e771138f208")

