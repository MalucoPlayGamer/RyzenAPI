-- Lua provided by RyzenAPI
-- Game: Anti Gravity Warriors VR

-- MAIN APPLICATION
addappid(711390)

-- MAIN APP DEPOTS / PACKAGES
addappid(711391, 1, "674be210b2b566b67624981596afc6694e3df79403fb24c5da1b1445c357db56")

