-- Lua provided by RyzenAPI
-- Game: Slimekeep

-- MAIN APPLICATION
addappid(1552500)
-- Game: addappid(1552500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552501, 1, "9d1c88ef91353694a828586c10eed62a45d53eeac01a5b25b67fde49e32c72e6")
