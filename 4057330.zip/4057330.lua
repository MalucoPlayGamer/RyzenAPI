-- Lua provided by RyzenAPI
-- Game: My Horny Anime Girls

-- MAIN APPLICATION
addappid(4057330)

-- MAIN APP DEPOTS / PACKAGES
addappid(4057331,0,"276d83cc6660448dc1dce6dafc08e296375c1a362f89f24b8d38a91201c06b7b")
