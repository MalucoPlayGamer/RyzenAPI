-- Lua provided by RyzenAPI 
-- Game: AppID 1493880
addappid(1493880)
addappid(1493881, 1, "ce23d627b772f8ffcd8e49e206a7549cb0421310695c4b4c56156ca4158b7af4")
