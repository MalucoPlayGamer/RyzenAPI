-- Lua provided by RyzenAPI
-- Game: Soul Gambler

-- MAIN APPLICATION
addappid(313020)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(313021, 1, "5c0696b457082f7ecae0e89ee04bb16b8b8c1262fcbc3a202646f9c25482c17f")
addappid(313760, 0, "8e136921c8ce5bc4b3a3af5b768394899e653aac55508d99e2a5ce4d7b3502eb")

