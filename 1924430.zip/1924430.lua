-- Lua provided by RyzenAPI
-- Game: 1924430

-- MAIN APPLICATION
addappid(1924430)
-- Game: addappid(1924430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924431, 1, "55f1ee3bf31c7ca59e30e91329e6763fe783ec32c55c6f2358b11fa9e52313cf")
