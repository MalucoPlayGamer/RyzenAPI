-- 4148390's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Eva is streaming
-- Created: July 09, 2026 at 02:53:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4148390) -- Hentai Clicker: Eva is streaming
-- MAIN APP DEPOTS
addappid(4148391, 1, "a660c14153af5af3f7850e0d46d78f5747531f483a5584ac6b60786ae39e5f4c") -- Depot 4148391
setManifestid(4148391, "5610296318863699525", 169612542)