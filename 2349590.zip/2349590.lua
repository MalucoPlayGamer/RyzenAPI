-- Lua provided by RyzenAPI
-- Game: Brasil Simuleitor

-- MAIN APPLICATION
addappid(2349590)
-- Game: addappid(2349590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349591, 1, "196923f6d7ecc691e2a41727fb95711a04fc183d56d0b9937f69747459ee703b")
