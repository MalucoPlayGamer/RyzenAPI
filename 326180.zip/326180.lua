-- Lua provided by RyzenAPI
-- Game: Sinister City

-- MAIN APPLICATION
addappid(326180)
addappid(370580)

-- MAIN APP DEPOTS / PACKAGES
addappid(326181, 1, "6ced3675400852ab5a05db3d4ee76d2154fd8531440d509971b058e1408cb9d8")
addappid(326185, 1, "52ff06d2b2b911a296d39fe2f677df58717b5f5704b14ab2cfac9a38a09126d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
