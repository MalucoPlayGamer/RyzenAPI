-- Lua provided by RyzenAPI
-- Game: Game: AppID 605800

-- MAIN APPLICATION
addappid(605800)
-- Game: addappid(605800)

-- MAIN APP DEPOTS / PACKAGES
addappid(605801, 1, "77c80f4dfb880811a9ad9121e46e6895d2a5d71f2a9a5495429ec2ee2d40822f")
