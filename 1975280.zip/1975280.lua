-- Lua provided by RyzenAPI
-- Game: Between Two Worlds

-- MAIN APPLICATION
addappid(1975280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975285,0,"3a4340a192d8c879005cd0b399856c3c64379b5a3ffd17ed06cb50d39ececf27")
addappid(3754820,0,"3865a9935afdbfd956e447f74a6679c68c1a3b44e0cd89d025e58fbab947dd54")

