-- Lua provided by RyzenAPI
-- Game: addappid(1584680)

-- MAIN APPLICATION
addappid(1584680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584681, 1, "aaef1c76532fce04fb12b415429f68e09f52cf0f53e5c36e3069df179c8d19f8")
