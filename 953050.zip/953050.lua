-- Lua provided by RyzenAPI
-- Game: Dread of Laughter

-- MAIN APPLICATION
addappid(953050)

-- MAIN APP DEPOTS / PACKAGES
addappid(953051, 1, "298d5d29643a85af0a23df9f5e3b27471a4e5e631c0ec9a93c824cd7b4cd8f05")
