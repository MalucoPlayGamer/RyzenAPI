-- Lua provided by RyzenAPI
-- Game: Endure Island

-- MAIN APPLICATION
addappid(1993560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1993561, 1, "5a7e4e1465bf4944a2b802bec7a320a95089e096ed3d2dce25f96148fbf011fc")

