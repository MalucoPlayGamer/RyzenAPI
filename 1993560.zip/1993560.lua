-- Lua provided by RyzenAPI 
-- Game: Endure Island
addappid(1993560)
addappid(1993561, 1, "5a7e4e1465bf4944a2b802bec7a320a95089e096ed3d2dce25f96148fbf011fc")
