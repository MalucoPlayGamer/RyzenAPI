-- Lua provided by RyzenAPI
-- Game: Careening Demo

-- MAIN APPLICATION
addappid(3393250)
-- Game: addappid(3393250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393251, 1, "2c3198112e8fce61253d1dc33e0ac4f7fd4dcb3ceb0d7ac3f382d294ed9f8dd5")
