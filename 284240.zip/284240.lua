-- Lua provided by RyzenAPI
-- Game: Maize

-- MAIN APPLICATION
addappid(284240)
addappid(559950)

-- MAIN APP DEPOTS / PACKAGES
addappid(284241, 1, "0822971be91189f317fc07b107eb3bc6de5f0232c240a381b6065127376a145c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
