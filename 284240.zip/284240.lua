-- Lua provided by RyzenAPI
-- Game: addappid(284240)

-- MAIN APPLICATION
addappid(284240)
addappid(559950)

-- MAIN APP DEPOTS / PACKAGES
addappid(284241, 1, "0822971be91189f317fc07b107eb3bc6de5f0232c240a381b6065127376a145c")
