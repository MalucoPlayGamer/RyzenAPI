-- Lua provided by RyzenAPI
-- Game: Idle Craft Demo

-- MAIN APPLICATION
addappid(3463310)
-- Game: addappid(3463310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3463311, 1, "1b20ca5d7ddb0da3da178596758dfe752a42e8c734e8e2a2e2479f3ecb9f05e4")
