-- Lua provided by RyzenAPI
-- Game: Game: AppID 2183260

-- MAIN APPLICATION
addappid(2183260)
-- Game: addappid(2183260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183261, 1, "94f86570484267d673fc02f8a3b6678b3e6ae5058e9ccabd2ef03c980e5febbe")
