-- Lua provided by RyzenAPI
-- Game: Incremental Epic Hero 2

-- MAIN APPLICATION
addappid(1690710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690711, 1, "277efcc6152d0423158775ef364a9aa923e7c660331fd18669d05bdf624cc133")
addappid(1690712, 1, "382599b084c924853837816e3bb58f8d4f8ba0ba8fd8cb69a5ac9ee30b193117")

