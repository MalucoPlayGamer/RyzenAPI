-- Lua provided by RyzenAPI
-- Game: Phoenix Hope

-- MAIN APPLICATION
addappid(1465950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465951, 1, "4fb11450ddc2d7bd6f6cfac9d9ce0fd88f2ed690836400baa53e09676d07c17d")
