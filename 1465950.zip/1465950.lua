-- Lua provided by SkyAPI 
-- Game: Phoenix Hope
addappid(1465950)
addappid(1465951, 1, "4fb11450ddc2d7bd6f6cfac9d9ce0fd88f2ed690836400baa53e09676d07c17d")
