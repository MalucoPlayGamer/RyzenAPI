-- Lua provided by RyzenAPI
-- Game: Bounce

-- MAIN APPLICATION
addappid(827920)
-- Game: addappid(827920)

-- MAIN APP DEPOTS / PACKAGES
addappid(827921, 1, "a11a5fd6314543b64632e62326c4cd9dbe2178b4a256530f66480e81536f39a9")
addappid(827922, 1, "a0d0a1f95e2b73ca354b1ffc07bde3fb4f4d602c5a5c77151906fbee57ab8046")
addappid(827923, 1, "3ce66b63cf8bf249977e5426b7f4a891c505bf092de26d4f8539b630ab0da123")
