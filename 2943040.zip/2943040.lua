-- Lua provided by RyzenAPI
-- Game: setManifestid(2943044,"2115806875406055739")

-- MAIN APPLICATION
addappid(2943040)
-- Game: addappid(2943040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943044,0,"60bb879e67546f5900c53df284fcbc617ad911adabfaa3545590daf41fa8b14d")
