-- Lua provided by RyzenAPI
-- Game: addappid(978857)

-- MAIN APPLICATION
addappid(978857)

-- MAIN APP DEPOTS / PACKAGES
addappid(978857,0,"9a9042a6ae6f49481afbcd1b630c55f57f2875484934251d3d79bcdef217c2c7")
