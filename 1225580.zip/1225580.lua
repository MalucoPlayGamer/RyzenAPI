-- Lua provided by RyzenAPI
-- Game: Fe

-- MAIN APPLICATION
addappid(1225580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225581, 1, "d1be39e5675119d596e8dca09cd2e98486a3041a07ec4539f45487212fe3d47c")
addappid(1225582, 1, "43b0c4a1d51f1da3c042f6552542e91f839a2d6dffcab7762173f46c7fc81a4d")
addappid(1225583, 1, "43cbe830ae87ad71ecd9530faa02602c3b20b84db5155e0858d06708d4e7b6c3")
addappid(1225584, 1, "951f2c85d637ead6e2ebb182658400faf7060325b2859111c3cd8f46f63c90c3")
addappid(1225585, 1, "1e3ba205301eec08079daee0754146995d9629abdc78d13a64889e287f562d9d")
addappid(1225586, 1, "75d2d3d50d41fd62ab3b75e23caad1da60bf92fa4d63bcf412469525286199f1")
addappid(1225587, 1, "08686416c62a5cf1609851646757532dcd2579cd980236cd6a1dbc6c7c189a0a")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1283300)
