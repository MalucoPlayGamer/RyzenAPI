-- Lua provided by RyzenAPI
-- Game: 791200

-- MAIN APPLICATION
addappid(791200)
-- Game: addappid(791200)

-- MAIN APP DEPOTS / PACKAGES
addappid(791202,0,"ae9d0c0664bbfee86e7d726e638b630f339648fab926a9737c80eae5b4cfbfc7")
