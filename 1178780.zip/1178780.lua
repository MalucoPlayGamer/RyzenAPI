-- Lua provided by SkyAPI 
-- Game: AppID 1178780
addappid(1178780)
addappid(1178781, 1, "a996621f541507d8fc1e87977b202267221cf3a774b547c3a186b008fec32ef6")
