-- Lua provided by RyzenAPI
-- Game: AppID 1347550

-- MAIN APPLICATION
addappid(1347550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347551, 1, "1e3ccdbe24790bab10b3168dc06989e1c4cda5ef70c031f1def7d7762f2eb74a")
