-- Lua provided by RyzenAPI
-- Game: AppID 1347550

-- MAIN APPLICATION
addappid(1347550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347551, 1, "1e3ccdbe24790bab10b3168dc06989e1c4cda5ef70c031f1def7d7762f2eb74a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
