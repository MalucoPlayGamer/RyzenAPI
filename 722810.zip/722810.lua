-- Lua provided by RyzenAPI
-- Game: Casual Spider Solitaire

-- MAIN APPLICATION
addappid(722810)

-- MAIN APP DEPOTS / PACKAGES
addappid(722811, 1, "126545d92a9c8120e369f59e8b6aac24d0b33faf94c2f24fcbbd455e6bbe929f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
