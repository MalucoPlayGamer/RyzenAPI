-- Lua provided by RyzenAPI
-- Game: Casual Spider Solitaire

-- MAIN APPLICATION
addappid(722810)

-- MAIN APP DEPOTS / PACKAGES
addappid(722811, 1, "126545d92a9c8120e369f59e8b6aac24d0b33faf94c2f24fcbbd455e6bbe929f")
