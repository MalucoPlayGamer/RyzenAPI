-- Lua provided by RyzenAPI
-- Game: SEX, LOVE & GIRLS❤️💦

-- MAIN APPLICATION
addappid(2294540)
-- Game: addappid(2294540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294541, 1, "db64cb077981292926e7daaaa2450c99e11c72a20234d633884f19e9f9ac7657")
