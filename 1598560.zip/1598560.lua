-- Lua provided by RyzenAPI
-- Game: Life On A Pizza

-- MAIN APPLICATION
addappid(1598560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598561, 1, "580a3ddbb9e32570a91dd367028dfb6f691d97ac95b28778008ca3eca7f39cfa")
addappid(1598562, 1, "c0e8f557ab725015b516c868493cff04821e4ab03c9b7583db54c07b59bfddad")
addappid(1598563, 1, "167249f73e08f83b055375bef2cce58d0a300cf345ad183b300f2d41a7649bbe")

