-- Lua provided by RyzenAPI
-- Game: Game: Margo

-- MAIN APPLICATION
addappid(2245890)
-- Game: addappid(2245890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245891, 1, "04556b415fd71b9dc6d630060eb752684ac6085f1cb910a0f72e2774b07eff20")
addappid(2245892, 1, "2eacf1cd8e836f9a3029225027eaf7f0b8bb92efc6dc2a65a549e70970083b5a")
