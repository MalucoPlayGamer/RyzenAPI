-- Lua provided by SkyAPI 
-- Game: Dungeon Alchemist
addappid(1588530)
addappid(1588531, 1, "a9d28558cd0686aa83b4c6a439b5fed7f391983302c52bc7b8229c935c2e1aa0")
addappid(1588532, 1, "d659a3dd79f804b13ee6190db2243f4365f0f43ecfda8f8a8c1973c1b5121a46")
addappid(1588533, 1, "2c03f5f7da5a7150eb0ecf6c192adac1a8dfaf46be043f8bc862a00540d51aa4")
