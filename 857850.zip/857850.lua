-- Lua provided by RyzenAPI
-- Game: Dwarf Defense

-- MAIN APPLICATION
addappid(857850)
-- Game: addappid(857850)

-- MAIN APP DEPOTS / PACKAGES
addappid(857851, 1, "c78d23b65f7eead7f154762e043402c2ed5e4aa930639a85a7a93f2aa83149bd")
