-- Lua provided by RyzenAPI
-- Game: AppID 857850

-- MAIN APPLICATION
addappid(857850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(857851, 1, "c78d23b65f7eead7f154762e043402c2ed5e4aa930639a85a7a93f2aa83149bd")

