-- Lua provided by RyzenAPI
-- Game: SaberStyle

-- MAIN APPLICATION
addappid(1680270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680271, 1, "2ed7a86d2c7c4ce0089644b6f418f9df44aa7680e5341c29899e54438495f026")

