-- Lua provided by RyzenAPI
-- Game: SaberStyle

-- MAIN APPLICATION
addappid(1680270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680271, 1, "2ed7a86d2c7c4ce0089644b6f418f9df44aa7680e5341c29899e54438495f026")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
