-- Lua provided by RyzenAPI
-- Game: Father Forgets

-- MAIN APPLICATION
addappid(4503250) -- Father Forgets

-- MAIN APP DEPOTS / PACKAGES
addappid(4503251, 1, "29ec113cba48462f8abe6b0d9ed612310b5d0fa6b0cafa602531f77a93c0dc71") -- Depot 4503251

