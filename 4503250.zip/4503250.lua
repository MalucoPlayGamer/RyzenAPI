-- 4503250's Lua and Manifest Created by Hubcap Manifest
-- Father Forgets
-- Created: August 11, 2026 at 00:20:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4503250) -- Father Forgets
-- MAIN APP DEPOTS
addappid(4503251, 1, "29ec113cba48462f8abe6b0d9ed612310b5d0fa6b0cafa602531f77a93c0dc71") -- Depot 4503251
setManifestid(4503251, "7226293346123943923", 412573309)