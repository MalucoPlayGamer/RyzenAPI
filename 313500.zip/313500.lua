-- Lua provided by RyzenAPI
-- Game: Game: Blitzkrieg 2 Anthology

-- MAIN APPLICATION
addappid(313500)
-- Game: addappid(313500)

-- MAIN APP DEPOTS / PACKAGES
addappid(313501, 1, "bcab13e6a8d5e53533662395ce68555e123ab8d695aec13f587117240f8b11b0")
