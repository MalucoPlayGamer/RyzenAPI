-- Lua provided by RyzenAPI 
-- Game: 江山如画
addappid(2121840)
addappid(2121841, 1, "b833ae50f17e84d65f1c403030026e8f6fb172a0dfc575484e1a2e6cb0a9b7e7")
