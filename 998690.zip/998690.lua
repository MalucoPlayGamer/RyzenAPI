-- Lua provided by RyzenAPI
-- Game: Run Away

-- MAIN APPLICATION
addappid(998690)

-- MAIN APP DEPOTS / PACKAGES
addappid(998691, 1, "628f06c706d2bcc00caab70adb0496a071808b6c83d5398f8dd58f71f8c4602b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
