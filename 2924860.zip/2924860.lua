-- Lua provided by SkyAPI 
-- Game: Astrumis - Survive Together
addappid(2924860)
addappid(2924861, 1, "99d1e15906a454d6cb672e1052589bfaf01ca97086a41b9cdfd803fe0cd6e602")
