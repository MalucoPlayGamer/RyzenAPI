-- Lua provided by RyzenAPI
-- Game: addappid(2924860)

-- MAIN APPLICATION
addappid(2924860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924861, 1, "99d1e15906a454d6cb672e1052589bfaf01ca97086a41b9cdfd803fe0cd6e602")
