-- Lua provided by RyzenAPI
-- Game: Game: AppID 708800

-- MAIN APPLICATION
addappid(708800)
-- Game: addappid(708800)

-- MAIN APP DEPOTS / PACKAGES
addappid(708801, 1, "2a3f397192b53bbbee83667c7305ccaf39294df2f0418d5b5761edf0321b2873")
