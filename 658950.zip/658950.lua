-- Lua provided by RyzenAPI
-- Game: 658950

-- MAIN APPLICATION
addappid(658950)
-- Game: addappid(658950)

-- MAIN APP DEPOTS / PACKAGES
addappid(658951, 1, "88cf8ea23ea9e1b9924b1ffc1aa6975ea332a95ec21ade7ed20d69c870320735")
