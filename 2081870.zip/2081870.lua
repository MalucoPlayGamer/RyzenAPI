-- Lua provided by RyzenAPI
-- Game: 2081870

-- MAIN APPLICATION
addappid(2081870)
-- Game: addappid(2081870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081870,0,"ab4d15049fd9b0e3fe31c5e5ecb5b65d90f5178082728bc83aaa202fdb6079e3")
