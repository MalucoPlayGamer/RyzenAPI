-- Lua provided by RyzenAPI
-- Game: Sand Tanble War: The Crusandes

-- MAIN APPLICATION
addappid(2463830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463831, 1, "dbf8376e0c0384f507cb433ce2742b0a6a336d8b01164c8d9c5957e67fd1d470")
