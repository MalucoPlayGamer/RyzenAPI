-- Lua provided by RyzenAPI
-- Game: Sand Tanble War: The Crusandes

-- MAIN APPLICATION
addappid(2463830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463831, 1, "dbf8376e0c0384f507cb433ce2742b0a6a336d8b01164c8d9c5957e67fd1d470")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
