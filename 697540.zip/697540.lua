-- Lua provided by RyzenAPI
-- Game: Cursor Slayer

-- MAIN APPLICATION
addappid(697540) -- Cursor Slayer

-- MAIN APP DEPOTS / PACKAGES
addappid(697542, 1, "ed3495d7427e1a55237a9c56716ea4ab4644003941f0a2d249766edaf6494a70") -- Depot 697542

