-- 697540's Lua and Manifest Created by Hubcap Manifest
-- Cursor Slayer
-- Created: August 17, 2026 at 15:54:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(697540) -- Cursor Slayer
-- MAIN APP DEPOTS
addappid(697542, 1, "ed3495d7427e1a55237a9c56716ea4ab4644003941f0a2d249766edaf6494a70") -- Depot 697542
setManifestid(697542, "2534039215390193506", 422657044)