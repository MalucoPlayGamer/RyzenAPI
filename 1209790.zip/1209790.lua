-- Lua provided by RyzenAPI
-- Game: 郡主别怕

-- MAIN APPLICATION
addappid(1209790)
-- Game: addappid(1209790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209796,0,"f307e5a79035e58470da25617a732111ac4644d5147f57786f61e0f610930ae3")
