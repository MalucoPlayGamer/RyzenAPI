-- Lua provided by RyzenAPI
-- Game: AppID 1254670

-- MAIN APPLICATION
addappid(1254670)
-- Game: addappid(1254670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254671, 1, "755da19fc01a3a96dd322998e8896c0c0a6afa51b654f35d950586d0ccaa0572")
