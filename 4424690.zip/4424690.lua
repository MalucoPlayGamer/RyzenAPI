-- Lua provided by RyzenAPI
-- Game: Just Open The Door

-- MAIN APPLICATION
addappid(4424690) -- Just Open The Door

-- MAIN APP DEPOTS / PACKAGES
addappid(4424691, 1, "37557bba6a63869b7efacc4da4643ed78eed2e1355f0fd400053c75d210e8c21") -- Depot 4424691

