-- Lua provided by RyzenAPI 
-- Game: LEGO® Bricktales Demo
addappid(1970100)
addappid(1970101, 1, "7545778a9a87cbfd83311cf3ce195b5a99ba33e1679b6cbafc59084f618e436c")
