-- Lua provided by RyzenAPI
-- Game: AppID 233630

-- MAIN APPLICATION
addappid(233630)

-- MAIN APP DEPOTS / PACKAGES
addappid(233631, 1, "3cb2256f107ef93b2a7e0e7ce407af82549fed1b43ffe056f352dae79bbdf336")

