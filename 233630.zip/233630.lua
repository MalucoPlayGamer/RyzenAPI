-- Lua provided by RyzenAPI
-- Game: AppID 233630

-- MAIN APPLICATION
addappid(233630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(233631, 1, "3cb2256f107ef93b2a7e0e7ce407af82549fed1b43ffe056f352dae79bbdf336")

