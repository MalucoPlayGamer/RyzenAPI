-- Lua provided by RyzenAPI
-- Game: Vivez Versailles

-- MAIN APPLICATION
addappid(788540)
-- Game: addappid(788540)

-- MAIN APP DEPOTS / PACKAGES
addappid(788541, 1, "4df8b2fdbc5ccca04e70f93da1d8a18279c65ef71352802e6f1ac8ca7bb00c7a")
