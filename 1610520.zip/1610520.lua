-- Lua provided by RyzenAPI
-- Game: Serum: Toxic Survival

-- MAIN APPLICATION
addappid(1610520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610521, 1, "2ba28b50db35dedf342f577bd9284a0b1be5c076aeaf3510c145e9a677af9b26")
addappid(2996490, 0, "0f79d6b2d358d0f674dba0e0c8a03c50fb01641415593dc0fbf73c3cbd2626d4")
addappid(2996500, 0, "904ca1afb6000f1ba13c2462ac18d14c06180033924067a260e507a7b8414c4a")
addappid(2996510, 0, "f4b7f63ea21d6903b0db4d2c9eb0cc899a70ff7ada3802c7cff08abe677cb8c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
