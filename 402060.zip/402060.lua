-- Lua provided by RyzenAPI 
-- Game: AppID 402060
addappid(402060)
addappid(402061, 1, "8bb6521c50a9e60d38c6e85f70abe02d8b868e649afc738c97979a0c92895fc9")
addappid(402062, 1, "fcd91cebae4a783efbd2f6bd3079389666096f0c5cf50ce43d717a61ad0a6475")
addappid(402063, 1, "95a0d0e50a98f54aaeb0dde7a8b60681462dd5383976b5d3e7e50bc05c913c78")
addappid(402064, 1, "72959ba1996a9c0e8a5c9f865f05b6afafafb12106eaee10eb01ca4fc94bbcc4")
