-- Lua provided by RyzenAPI
-- Game: With My Past

-- MAIN APPLICATION
addappid(2524360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524361, 1, "331fc19735995ae73c7c4ddd2af5c7440567d4d362f760b76e1d07aa41763827")
