-- Lua provided by RyzenAPI
-- Game: Chronos Builder

-- MAIN APPLICATION
addappid(2006470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006472,0,"e3bf9f56195b2742ae0ce5ac7dbf89ea7209764a5053a7c63e2ba76b935025f0")
addappid(2600860,0,"1b09c2b37061d61cbe38674ac73ccaf8d90cb62d1d8807e407e69b95652d4ba9")
