-- Lua provided by RyzenAPI
-- Game: Game: Pixel Royale 3D

-- MAIN APPLICATION
addappid(2511180)
-- Game: addappid(2511180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511181, 1, "2710da0d64099ec1adb7041eeddf744874221018de28bd6bf514859f58e389bc")
addappid(2511182, 1, "44b34cd5f2a2a7e6a8a0ad2b47db5e5b37311a00d749daab920de0602355381e")
addappid(2511183, 1, "43e7f1ed49137ec342cfaf3b60e8176ba6bf5c4c82932c66975aa4b56701b7da")
