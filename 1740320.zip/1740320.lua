-- Lua provided by RyzenAPI
-- Game: addappid(1740320)

-- MAIN APPLICATION
addappid(1740320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740321, 1, "284b0decd064f99b2ce82dee37ad4289310eccdef16527dd7e1d9931c31869d4")
