-- Lua provided by RyzenAPI
-- Game: Hentai World Forest

-- MAIN APPLICATION
addappid(4812510) -- Hentai World Forest

-- MAIN APP DEPOTS / PACKAGES
addappid(4812511, 1, "b25c560b05323af0012b150ce9b547af4ea2ae59834889d2191ddc0f10a6696d") -- Depot 4812511

