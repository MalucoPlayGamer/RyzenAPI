-- 4812510's Lua and Manifest Created by Hubcap Manifest
-- Hentai World Forest
-- Created: August 17, 2026 at 14:47:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4812510) -- Hentai World Forest
-- MAIN APP DEPOTS
addappid(4812511, 1, "b25c560b05323af0012b150ce9b547af4ea2ae59834889d2191ddc0f10a6696d") -- Depot 4812511
setManifestid(4812511, "1237725141848284981", 362491810)