-- Lua provided by RyzenAPI
-- Game: Sense - 不祥的预感: A Cyberpunk Ghost Story

-- MAIN APPLICATION
addappid(1120560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120561, 1, "3f2d21a1974e80d2fb0860a684ad101e3fd33ba38b5c977f77f6476285bd47b1")
