-- Lua provided by RyzenAPI 
-- Game: SUSHI SOUL UNIVERSE
addappid(2562460)
addappid(2562461, 1, "c57f289ec12f2758d90669b7bba5eae18ca01b4301b9ebf3b4932f9f8f49c673")
