-- Lua provided by RyzenAPI
-- Game: SUSHI SOUL UNIVERSE

-- MAIN APPLICATION
addappid(2562460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2562461, 1, "c57f289ec12f2758d90669b7bba5eae18ca01b4301b9ebf3b4932f9f8f49c673")

