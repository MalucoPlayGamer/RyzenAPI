-- Lua provided by RyzenAPI
-- Game: Agarest: Generations of War Zero

-- MAIN APPLICATION
addappid(260130)
addappid(281600)
addappid(281601)
addappid(281602)
addappid(281603)
addappid(281604)
addappid(281605)
addappid(281606)
addappid(281607)
-- Game: addappid(260130)

-- MAIN APP DEPOTS / PACKAGES
addappid(260131, 1, "5c7dec1977937bba6b321919215c4a3a1846b830df7d44a8463281a0ee99cbae")
