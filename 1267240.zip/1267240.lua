-- Lua provided by RyzenAPI
-- Game: Chaos Combat Chess

-- MAIN APPLICATION
addappid(228988)
addappid(1267240)
addappid(1267241)
addappid(1267242)
-- Game: addappid(1267240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267243,0,"39c115b009d571efcce68b62324466a4dd16bf978da1555f92621cb6aa2b274d")
