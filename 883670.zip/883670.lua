-- Lua provided by RyzenAPI
-- Game: AppID 883670

-- MAIN APPLICATION
addappid(883670)
-- Game: addappid(883670)

-- MAIN APP DEPOTS / PACKAGES
addappid(883671, 1, "65af551e661b8dbbeb6ea43b007c56b2b9000c02c4546c9b6263c0d9051412e3")
