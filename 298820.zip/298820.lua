-- Lua provided by RyzenAPI
-- Game: Game: Millennium 2 - Take Me Higher

-- MAIN APPLICATION
addappid(298820)
-- Game: addappid(298820)

-- MAIN APP DEPOTS / PACKAGES
addappid(298821, 1, "e52a0507881c57254ab2e3a4bac32b5620f850d51bbc10d3b76b721ed0c176a4")
addappid(357110, 0, "fd406a5ed7d2862667d429d40f3d0f9c7bb8ab4f9ea717ef61b5669c26708eda")
