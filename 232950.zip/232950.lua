-- Lua provided by RyzenAPI
-- Game: addappid(232950)

-- MAIN APPLICATION
addappid(232950)

-- MAIN APP DEPOTS / PACKAGES
addappid(232951, 1, "99de0bebf124a1cd0d8c12472bcc0b9154d5f40df268ce7d3eae02c2910eb9c0")
addappid(232952, 1, "6298e61dce58bb00c1300d1a52b378a8b3904b59574fffded3b18e9cb07e37c1")
addappid(232953, 1, "2fc156ad9471a98cb137d9d6fe327949c3881fb11d362286b681226bfcef1606")
