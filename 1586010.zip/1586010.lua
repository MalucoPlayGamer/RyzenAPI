-- Lua provided by RyzenAPI
-- Game: Dream Catchers

-- MAIN APPLICATION
addappid(1586010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586012,0,"258dc9cc90381f576f0196706e8b8cd3ccf7bca6ea832b258276a0e8bb1e5c01")

