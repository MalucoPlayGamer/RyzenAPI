-- Lua provided by RyzenAPI
-- Game: Starbound

-- MAIN APPLICATION
addappid(211820)

-- MAIN APP DEPOTS / PACKAGES
addappid(211821, 1, "d38d22b9989c3c2c74a3ff2b9164637cd6816f06bbac1cbd57a79098f56e7a49")
addappid(211822, 1, "f34154fb8d8c1bad83ea48eca72eb672004cd9c334cf1042c380b1439b0ec9f2")
addappid(211823, 1, "f557c69f92ae74f4d8658c8633837fd6605f355606ee5381330b63ed15553dc0")
addappid(211824, 1, "18da06f95aae21ebd6d63bf0ac30854b0b908bef896d1d8ff19aeb21e989a186")
addappid(211825, 1, "6e7664f162e86314482286f2d561b5158d708f2412a6b7bd2be03320e433b7c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
