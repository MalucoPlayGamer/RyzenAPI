-- Lua provided by RyzenAPI
-- Game: 1893820

-- MAIN APPLICATION
addappid(1893820)
-- Game: addappid(1893820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893821, 1, "b5f91cf8bdbb6b7c5bad76171053665d5e1067fabd33ce9cd146591e250a297f")
