-- Lua provided by RyzenAPI
-- Game: Quilts and Cats of Calico

-- MAIN APPLICATION
addappid(1993180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1993181, 1, "48ad17bb37e37e71de758e5b9ee0d7d47226b35fdf3683d749b1318901577ed4")
addappid(1993182, 1, "e8611329122cc87a03b0fe2d9f26f302e46a9df22115ece8c01c41467c0f218e")

