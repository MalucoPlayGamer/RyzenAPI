-- Lua provided by SkyAPI 
-- Game: Quilts and Cats of Calico
addappid(1993180)
addappid(1993181, 1, "48ad17bb37e37e71de758e5b9ee0d7d47226b35fdf3683d749b1318901577ed4")
addappid(1993182, 1, "e8611329122cc87a03b0fe2d9f26f302e46a9df22115ece8c01c41467c0f218e")
