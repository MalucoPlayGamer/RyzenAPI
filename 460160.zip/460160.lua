-- Lua provided by RyzenAPI
-- Game: The Leisure of Grisaia

-- MAIN APPLICATION
addappid(460160)

-- MAIN APP DEPOTS / PACKAGES
addappid(460161, 1, "e6c30e7c38b0521375678ac335a4e6e75fee9ab641c4444a4a2eec29da776a7d")
addappid(460162, 1, "dd5447642d0e5e6dff97542fcdf8542c82b13fa312d455b95d2df348f04bdd43")

