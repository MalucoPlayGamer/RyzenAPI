-- Lua provided by RyzenAPI
-- Game: Dungeon Painter Studio

-- MAIN APPLICATION
addappid(592260)

-- MAIN APP DEPOTS / PACKAGES
addappid(592261, 1, "46d2b75f570c822e8e237e65540225499f68a07309fe067698ec89be1105d292")

