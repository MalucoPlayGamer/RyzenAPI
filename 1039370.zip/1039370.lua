-- Lua provided by RyzenAPI
-- Game: 1039370

-- MAIN APPLICATION
addappid(1039370)
-- Game: addappid(1039370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039371, 1, "0aca276c4c623541f657bb2918cd4cefb3843d423078f9f59383bd2bd41bd523")
