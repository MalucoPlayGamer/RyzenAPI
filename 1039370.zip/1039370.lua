-- Lua provided by SkyAPI 
-- Game: AppID 1039370
addappid(1039370)
addappid(1039371, 1, "0aca276c4c623541f657bb2918cd4cefb3843d423078f9f59383bd2bd41bd523")
