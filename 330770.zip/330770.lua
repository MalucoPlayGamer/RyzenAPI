-- Lua provided by RyzenAPI
-- Game: Radial-G : Racing Revolved

-- MAIN APPLICATION
addappid(330770)

-- MAIN APP DEPOTS / PACKAGES
addappid(330771, 1, "56d5d468c2cc832178128b0ee0cbc6993bce1ffa799c317390f6bf75b0737d5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
