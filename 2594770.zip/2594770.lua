-- Lua provided by RyzenAPI
-- Game: AppID 2594770

-- MAIN APPLICATION
addappid(2594770)
-- Game: addappid(2594770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594771, 1, "902499fed81985d84a7fbd13b900dae8e4b913fc7ebedb3e51ba5d670300ecbe")
