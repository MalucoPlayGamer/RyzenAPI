-- Lua provided by RyzenAPI 
-- Game: Titan Attacks!
addappid(203210)
addappid(203211, 1, "cfec34645e9b05494f1c87fc0ab911deab98f4cf8b9cf64bc4cc256e06698f5b")
addappid(203212, 1, "417d381a9dd9efd7063c1d2aa8fa3db3f11c59f76a380aa37c22efa315791289")
addappid(203213, 1, "eed55fa082f160fe96499b459dbf3f8d61be785f73038a59c3a1ee09ae8e9e33")
