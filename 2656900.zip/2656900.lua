-- Lua provided by SkyAPI 
-- Game: AppID 2656900
addappid(2656900)
addappid(2656901, 1, "921738a70b83afc5221d128ae75e6dea8c9d8f1fe8d54b2ec249cd4336037766")
addappid(2677270, 0, "bce111fa7b87444e2626b3e663ee1516f2d3a5a88ee00e71c1b467a32b96378a")
