-- Lua provided by RyzenAPI
-- Game: Killjoy Hunter Yuuko

-- MAIN APPLICATION
addappid(1148470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148471, 1, "ea6316a04d7c61dee023c24e892086a41ee6842b6b27bec5f42b830ba2e7fe41")

