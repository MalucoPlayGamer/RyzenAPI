-- Lua provided by RyzenAPI
-- Game: addappid(933550)

-- MAIN APPLICATION
addappid(933550)

-- MAIN APP DEPOTS / PACKAGES
addappid(933550,0,"47775a786fa8ceb5329b14d9d9cef013664aa0f36282a7b661fff74a7c07b4f5")
