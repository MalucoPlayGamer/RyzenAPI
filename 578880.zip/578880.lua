-- Lua provided by RyzenAPI
-- Game: Embrace The Fear

-- MAIN APPLICATION
addappid(578880)

-- MAIN APP DEPOTS / PACKAGES
addappid(578881,0,"b33c8ddf9a2b45f7fee9608a084106a8b5f39ac1cf5dd1155068c68362a3f64f")

