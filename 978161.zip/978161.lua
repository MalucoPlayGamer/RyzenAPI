-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３- Bonus Costumes for Mitsunari Ishida

-- MAIN APPLICATION
addappid(978161)

-- MAIN APP DEPOTS / PACKAGES
addappid(978161,0,"b9561856baccf8886fc5067e70696114ff105acf74ffe3d465fec98ae12b23aa")

