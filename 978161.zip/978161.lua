-- Lua provided by RyzenAPI
-- Game: 978161

-- MAIN APPLICATION
addappid(978161)

-- MAIN APP DEPOTS / PACKAGES
addappid(978161,0,"b9561856baccf8886fc5067e70696114ff105acf74ffe3d465fec98ae12b23aa")
