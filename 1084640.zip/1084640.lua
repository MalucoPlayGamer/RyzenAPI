-- Lua provided by RyzenAPI
-- Game: Chicken Police - Paint it RED!

-- MAIN APPLICATION
addappid(1084640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084642,0,"4ac63b63a0ea86e96d581fd68f620fb00c5dff6aef13a511a8ae56c39eb4ac65")
addappid(1084643,0,"b23d4665d363e6f408e09023d01bb40bd8346646971fb666afb4b2b1e0e00875")
addappid(1084644,0,"1f5a8cf4febc1ab0895502a9115fff348ce79ea00c99258b3b27e1b0288c35f7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1591810)
