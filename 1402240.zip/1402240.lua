-- Lua provided by RyzenAPI
-- Game: addappid(1402240)

-- MAIN APPLICATION
addappid(1402240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402241, 1, "c8cb9c02483053f7a5bf275d60eba7c78accc3b5427f4c376b4e2aa5f5936644")
