-- Lua provided by SkyAPI 
-- Game: AppID 1511500
addappid(1511500)
addappid(1511501, 1, "247ca9e23afaa59142c112dd7ecd104bae87268d3ffcec207ccac56b68842db1")
