-- Lua provided by RyzenAPI
-- Game: Elven Truth

-- MAIN APPLICATION
addappid(1511500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511501, 1, "247ca9e23afaa59142c112dd7ecd104bae87268d3ffcec207ccac56b68842db1")
