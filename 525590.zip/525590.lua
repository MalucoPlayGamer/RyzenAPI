-- Lua provided by RyzenAPI
-- Game: Brawlderdash

-- MAIN APPLICATION
addappid(525590)

-- MAIN APP DEPOTS / PACKAGES
addappid(525591,0,"aca84354c946df90ad5277d3de72cfad71ef6d204fa38ed5e2b3181e179710dd")

