-- Lua provided by RyzenAPI
-- Game: addappid(1284430)

-- MAIN APPLICATION
addappid(1284430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284431, 1, "1a80b7be326eda7b5b4ef92a020d89ec250d40cc168560c88342d022dba9cb2e")
