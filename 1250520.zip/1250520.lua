-- Lua provided by RyzenAPI 
-- Game: Love Spell: Written In The Stars - a magical romantic-comedy otome
addappid(1250520)
addappid(1250521, 1, "45af76a3a893790e6b2024eb9cae58935d8392d560a3e93224e58d4a4637b50b")
addappid(2469700, 0, "892b56593fbb539f66976d2142903f5ace83c78a938a1065617982770cf14805")
