-- Lua provided by RyzenAPI
-- Game: AppID 225960

-- MAIN APPLICATION
addappid(225960)
-- Game: addappid(225960)

-- MAIN APP DEPOTS / PACKAGES
addappid(225961, 1, "306d2fa6a22153bcda8911bdd59aaff5bb43a7643dbd64a3960506da09675036")
