-- Lua provided by RyzenAPI
-- Game: 2747830

-- MAIN APPLICATION
addappid(2747830)
-- Game: addappid(2747830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747831, 1, "6ed08bcc59036b6e85ed41abec15697dc46b4fc15afed39b3309f31faa2614a2")
