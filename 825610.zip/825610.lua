-- Lua provided by SkyAPI 
-- Game: Viking's drakkars
addappid(825610)
addappid(825611, 1, "0729d0781c5ddfcb629c2884208acaf03ab8fd9a9217d16ec152426b1c4ad51a")
