-- Lua provided by SkyAPI 
-- Game: Freedom Force vs. the Third Reich
addappid(8890)
addappid(8891, 1, "379849b7f0163dcb12e31b686522a3f66fa91a0c47d193debeb24a8b7a9b6f0e")
