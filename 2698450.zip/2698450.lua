-- Lua provided by RyzenAPI
-- Game: Taskmaster VR

-- MAIN APPLICATION
addappid(2698450)
-- Game: addappid(2698450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698451, 1, "34c7c5be27f5fb083aea3a4554d29b3d2fb9e322e83f0b45f848bd7216aa7341")
