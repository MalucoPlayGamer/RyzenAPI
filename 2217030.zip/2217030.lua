-- Lua provided by RyzenAPI
-- Game: 2217030

-- MAIN APPLICATION
addappid(2217030)
-- Game: addappid(2217030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217031, 1, "581d01863d98f8aad946d3e29f235f6141f0566d82e21e4f787e5998e5c21aae")
