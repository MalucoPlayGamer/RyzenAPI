-- Lua provided by RyzenAPI
-- Game: ROM: Extraction

-- MAIN APPLICATION
addappid(530960)

-- MAIN APP DEPOTS / PACKAGES
addappid(530961, 1, "c06a4dba97608c42cd2ed462a730295f56810a8ef6a4ee57559ce32b2e3b58d7")
