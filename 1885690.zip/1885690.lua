-- Lua provided by SkyAPI 
-- Game: Virtual Circuit Board
addappid(1885690)
addappid(1885691, 1, "269ddf769a77f41edc041817b94e884247def7d6ad7343380ccd1ae1317b9229")
