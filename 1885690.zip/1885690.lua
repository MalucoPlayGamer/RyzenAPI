-- Lua provided by RyzenAPI
-- Game: addappid(1885690)

-- MAIN APPLICATION
addappid(1885690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885691, 1, "269ddf769a77f41edc041817b94e884247def7d6ad7343380ccd1ae1317b9229")
