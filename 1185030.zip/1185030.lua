-- Lua provided by RyzenAPI
-- Game: 1185030

-- MAIN APPLICATION
addappid(1185030)
-- Game: addappid(1185030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185031, 1, "9828d46081472fffe9c6d11d87b887225da68d9e6954735e2d73c0a8db4a2e51")
