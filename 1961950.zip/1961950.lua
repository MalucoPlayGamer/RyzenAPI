-- Lua provided by RyzenAPI
-- Game: CHAOS;HEAD NOAH

-- MAIN APPLICATION
addappid(1961950)
addappid(2103330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961951, 1, "2cb66a9c6a4f0ff6361ae0aec2c4fd913dc59f17e4be59cbb37572918e162ca1")
