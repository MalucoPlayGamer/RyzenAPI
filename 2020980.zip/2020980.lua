-- Lua provided by RyzenAPI
-- Game: Cartel Tycoon - Soundtrack Vol. II

-- MAIN APPLICATION
addappid(2020980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020981, 1, "15785f59715c5f3dda78e735c7f7802314aafdd61da5e4f6e3fb75518cc4f54c")
addappid(2020982, 1, "1c87613a6ce5ba1c22bcdf731d1e36862167478fb51b84c49fa19800c13dad12")

