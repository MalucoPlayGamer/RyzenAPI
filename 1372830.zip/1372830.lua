-- Lua provided by RyzenAPI
-- Game: Fantasy Tavern Sextet -Vol.1 New World Days-

-- MAIN APPLICATION
addappid(1372830)
-- Game: addappid(1372830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372831, 1, "8fdc320d93c9eed491972c55a39c192ba9d7f2fa08b1b3b0cb56da7c84ee207d")
