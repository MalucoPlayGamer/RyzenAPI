-- Lua provided by RyzenAPI
-- Game: CastleMiner Z

-- MAIN APPLICATION
addappid(253430)

-- MAIN APP DEPOTS / PACKAGES
addappid(253431, 1, "05b21341555aa79fb007f9b0df955981a059ceff1bc0f79b695c7b5e4764345e")

