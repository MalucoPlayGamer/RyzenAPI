-- Lua provided by RyzenAPI
-- Game: CastleMiner Z

-- MAIN APPLICATION
addappid(253430)

-- MAIN APP DEPOTS / PACKAGES
addappid(253431, 1, "05b21341555aa79fb007f9b0df955981a059ceff1bc0f79b695c7b5e4764345e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
