-- Lua provided by RyzenAPI
-- Game: Lilly's Potion Shop

-- MAIN APPLICATION
addappid(2450930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450931, 1, "2fb3c61a97fa9d7351d9e395b9ddb5487cbd4069da8d178662f519606cea5de6")
