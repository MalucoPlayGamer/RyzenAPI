-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Skyline Simulations - Long Beach Airport

-- MAIN APPLICATION
addappid(2970650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2970650,0,"c75d4323bd230f059bc0f4aaf47518acc5dfaaf1b93b553eb6e7c831e3183ac9")
