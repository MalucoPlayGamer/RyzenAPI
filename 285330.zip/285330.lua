-- Lua provided by RyzenAPI
-- Game: 285330

-- MAIN APPLICATION
addappid(285330)
-- Game: addappid(285330)

-- MAIN APP DEPOTS / PACKAGES
addappid(285331, 1, "4c3b841f34370f833e049cf297783e7b6e489ffd430bbb7490c54a59e93ba4ab")
addappid(285332, 1, "0c7b51a49f56aafa6b55b829969b8fec17260f3f65e17ddafc7d36f45fbc9f01")
addappid(285333, 1, "dfbc8ccd27d2b49ebae8cd9efff6ccc0cb803613d04f0ee4654a627278ced470")
addappid(285334, 1, "f8e0f8863f40e1e475dfbbd24cb61b31b3eef2dc633c1c6e8c02249a53995db8")
addappid(285335, 1, "b5665714b992f891b0fd8e4b9a6cbd92cb862dc78ca1213f2001696667a93cc3")
