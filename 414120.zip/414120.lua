-- Lua provided by RyzenAPI 
-- Game: Modbox
addappid(414120)
addappid(414121, 1, "0cb4fd85484f70a706f73614511deab059265796aca845ec9aaa4073f4088fd7")
