-- Lua provided by RyzenAPI
-- Game: addappid(1564700)

-- MAIN APPLICATION
addappid(1564700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564701, 1, "b15f0f73a909ebee1f46afe95c13acb9c72f5d11bad71681dbb9e7c54721254f")
