-- Lua provided by RyzenAPI
-- Game: House Cleaning Survival

-- MAIN APPLICATION
addappid(1564700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564701, 1, "b15f0f73a909ebee1f46afe95c13acb9c72f5d11bad71681dbb9e7c54721254f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
