-- Lua provided by RyzenAPI 
-- Game: AppID 1268840
addappid(1268840)
addappid(1268841, 1, "8b853b6e084b60b7e5ac33c541fbac1109aad0e70327ffde8ca44eae5fc2c562")
