-- Lua provided by RyzenAPI
-- Game: Game: Clicker Guardians

-- MAIN APPLICATION
addappid(2252330)
-- Game: addappid(2252330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252331, 1, "6b9a312b7ee879023d33f0f66f9df79d9ab7fd5e6fc2df3978a444be3a4c1fdd")
