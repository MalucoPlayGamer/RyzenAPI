-- Lua provided by RyzenAPI 
-- Game: AppID 1121710
addappid(1121710)
addappid(1121711, 1, "19b2c9644e597d99e64a983dcbe50b003fddb90f6dd3b2ab68540ca5cf1c0f74")
