-- Lua provided by RyzenAPI
-- Game: Total Lockdown

-- MAIN APPLICATION
addappid(1121710)
addappid(1249140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1121711, 1, "19b2c9644e597d99e64a983dcbe50b003fddb90f6dd3b2ab68540ca5cf1c0f74")
