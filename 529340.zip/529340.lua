-- Lua provided by RyzenAPI
-- Game: Victoria 3

-- MAIN APPLICATION
addappid(2071470)
addappid(2071471)
addappid(2071472) -- Victoria 3 - Expansion Pass
addappid(2282100)
addappid(2348450)
addappid(2366580)
addappid(2411230)
addappid(2411231)
addappid(2591240)
addappid(2800730)
addappid(3174360)
addappid(3450170)
addappid(3562730)
addappid(3562810)
addappid(3562890)
addappid(3562940)
addappid(3563050) -- Victoria 3: Expansion Pass 2
addappid(3596990) -- Victoria 3: Ultimate Bundle
addappid(4314630) -- Victoria 3: Volume 3
addappid(4314640)
addappid(4314650)

-- MAIN APP DEPOTS / PACKAGES
addappid(529340, 1, "6bcadea95bc4140711cac04610c20ad2857088090ead96424d38bae4505042ce")
addappid(529341, 1, "751bcf7f0ff0ba30922a60e32fe2c3e57e717bf3eb81cd5abe517d89a91f666a")
addappid(529342, 1, "fbbc0f3f114625d167ca6637a358e37e90ae0e56002ad08d6cd826141487b143") -- (windows)
addappid(529343, 1, "f8b6d5cad4b56cdcb290338d680e0b7f5ec029a3a9c0e7801eab102c7057ed45") -- (macos)
addappid(529344, 1, "91e2a80038ee5c6b9c10ffde8db28f2da0e1b358d499654416aea646689673a1") -- (linux)
addappid(529345, 1, "35b3747b37fea27a9fd293bd654b46bb98d4bf2517f9a13d4c131d01ac0b09a3") -- (windows)
addappid(529346, 1, "a2b158572cb0700badd3577c2d65aab9d8401347c178d0a429b7fd4aabf0d608") -- (macos)
addappid(529347, 1, "657da71ab5a239544ffed593e0ab6f4d90ecc376989bdd7d3ddea676bed7321b") -- (linux)
addappid(2071470, 1, "e46b0335eaf1a6aa7ed5b00b9051735d16d1f034c9ed1dbcc1b5743175f8d1fc")
addappid(2071471, 1, "fd34c3e32f4e327d81e2929351b9ab82f5848549f7ea3173a3266335cbf6b1f5")
addappid(2282100, 1, "ca755c1431847a9c44d481bb188467c2f96ee0c26720c944acdcd1700cf69771")
addappid(2348450, 1, "8321a5fc485da48cfb6fc6ac66b941c35a979cd982b719fc8facf51d2edba047")
addappid(2366580, 1, "8cc68dc93b4685bc2986a3fc4556a2de7f8cf1909bb2f06cd2ed94f48e2350d3")
addappid(2411230, 1, "80fa984d828254137925cac71bd9ebeb795fa5b4bc390ad9983fe8fadbd211a3")
addappid(2411231, 1, "5ba842826fdb9e68071c9771b01adc0e4be9159e92e26de331e7ac5c1d2684f9")
addappid(2591240, 1, "773a1ca21d2e9197ce4b1ff852ae3230ac5fbab8a954a68b61ad71a13e4875b2")
addappid(2800730, 1, "4e6ca866a42b0bda030de8c041ff8694d51a8ec73375dbc5e68c4d93749ae07f")
addappid(3174360, 1, "fd9adc2a5fc66fba32852fcc4584ab6ee87ca061d6a03ba3a9c262baed00dd8a")
addappid(3450170, 1, "10d073b22eb3123a70c012b6b9ebea935c6fff13e7fb6652e7e7636566ba062d")
addappid(3562730, 1, "ed6a84a44c1e43437202fc093e173ce8cb2ead8463df1a694bf43bd2e99a9988")
addappid(3562810, 1, "e3554bdbd47ebd858dfd124dfbda63f44ee18ce89de8574e8e7dbdb0d7441a07")
addappid(3562890, 1, "a94dbe1edbe6d6570aa59dc67513830a4c712703306c40afcc9238c47b741d26")
addappid(3562940, 1, "6fc91d1743fbec84b8887e3092e4c473292d0dbc973bb31ea812805e28f7ea50")
addappid(4314640, 1, "de6a7f79a9b77028620bdb00a4d9029076f2e378750404aa12420eab405c7288")
addappid(4314650, 1, "08f910d38b72a83f8f28d324c6d95fe6514ed4c39ee8b5c8b5e7bb1541218d7e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4314660)
addappid(4314670)
