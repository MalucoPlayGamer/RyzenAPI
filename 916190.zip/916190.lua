-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(916190)
-- Game: addappid(916190)

-- MAIN APP DEPOTS / PACKAGES
addappid(916190,0,"a6b297bd0c53fce42612ef9a3d06d11a25802b3e24319123f5c4ab1511181839")
