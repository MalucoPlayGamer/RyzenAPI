-- Lua provided by RyzenAPI
-- Game: addappid(1418970)

-- MAIN APPLICATION
addappid(1418970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418971, 1, "e060dc5c709b3cf63786d6ffbe7d513e263eb65f63fdfd289b340aa8b8488621")
