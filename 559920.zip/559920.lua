-- Lua provided by SkyAPI 
-- Game: Broken Blue
addappid(559920)
addappid(559921, 1, "9e8fe4a63f6c190babe5683a0f291128d053b77f671db228965368a1cfe6b483")
