-- Lua provided by RyzenAPI
-- Game: Extreme Formula Championship

-- MAIN APPLICATION
addappid(833810)

-- MAIN APP DEPOTS / PACKAGES
addappid(833811,0,"8bde0fad7bca64bc6b84cd0eee8ffc0f9c0378ec148dd818a153c32f044c3c76")

