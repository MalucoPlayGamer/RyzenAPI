-- Lua provided by RyzenAPI
-- Game: Cosmopoly

-- MAIN APPLICATION
addappid(1983670)
addappid(2094940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983671, 1, "ec63a82c781935600a552c6b589f0a339a621210d6076f14605f04fad99765af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
