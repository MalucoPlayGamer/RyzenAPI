-- Lua provided by RyzenAPI
-- Game: Cosmopoly

-- MAIN APPLICATION
addappid(1983670)
addappid(2094940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983671, 1, "ec63a82c781935600a552c6b589f0a339a621210d6076f14605f04fad99765af")
