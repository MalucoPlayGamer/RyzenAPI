-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Battlefront (Classic, 2004)

-- MAIN APPLICATION
addappid(1058020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058021, 1, "0c182a0a22f1d3692f57c59df496d7de252b441c63179b2627de132b9f53c516")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
