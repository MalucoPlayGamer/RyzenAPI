-- Lua provided by RyzenAPI 
-- Game: STAR WARS™ Battlefront (Classic, 2004)
addappid(1058020)
addappid(1058021, 1, "0c182a0a22f1d3692f57c59df496d7de252b441c63179b2627de132b9f53c516")
