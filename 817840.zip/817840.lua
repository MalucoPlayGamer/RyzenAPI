-- Lua provided by RyzenAPI
-- Game: Max Gentlemen Sexy Business!

-- MAIN APPLICATION
addappid(817840)
-- Game: addappid(817840)

-- MAIN APP DEPOTS / PACKAGES
addappid(817841, 1, "d8f81d713042f89f1ebf6117c5d7273aba442d0f766c458bebc3f3873f95034f")
