-- Lua provided by RyzenAPI
-- Game: 2071600

-- MAIN APPLICATION
addappid(2071600)
-- Game: addappid(2071600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071601, 1, "f79fe599a982ca1fe14e006405f64bfc0e074be1a9853ad7f4f629fd488ac19f")
