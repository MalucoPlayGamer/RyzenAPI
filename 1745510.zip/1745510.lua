-- Lua provided by RyzenAPI
-- Game: Lunacid

-- MAIN APPLICATION
addappid(1745510)
-- Game: addappid(1745510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745511, 1, "d07aafcd878b15a1b9e8c79d8197df4971a4392d31c00e32580055c4f5a9b012")
