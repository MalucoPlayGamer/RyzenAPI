-- Lua provided by RyzenAPI
-- Game: Escapeworld Dilemma

-- MAIN APPLICATION
addappid(1325270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325271, 1, "8e7e5bd4b8baa4551617627afe940b1480b1c4eb901d2fd5c8ea04650321066f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
