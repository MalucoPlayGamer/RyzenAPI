-- Lua provided by SkyAPI 
-- Game: Escapeworld Dilemma
addappid(1325270)
addappid(1325271, 1, "8e7e5bd4b8baa4551617627afe940b1480b1c4eb901d2fd5c8ea04650321066f")
