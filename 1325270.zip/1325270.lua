-- Lua provided by RyzenAPI
-- Game: Game: Escapeworld Dilemma

-- MAIN APPLICATION
addappid(1325270)
-- Game: addappid(1325270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325271, 1, "8e7e5bd4b8baa4551617627afe940b1480b1c4eb901d2fd5c8ea04650321066f")
