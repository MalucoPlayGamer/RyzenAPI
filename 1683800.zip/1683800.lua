-- Lua provided by RyzenAPI 
-- Game: AppID 1683800
addappid(1683800)
addappid(1683801, 1, "d2e905f028215df4714c29cc187fa65436a3fb25100e1f206df67dc67a937bbe")
