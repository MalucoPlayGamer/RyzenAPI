-- Lua provided by SkyAPI 
-- Game: Tales of Yore
addappid(1902880)
addappid(1902881, 1, "0c3fc7536e3808b2c78f201ad8888bcbedbf9a648f66680445eba245d8508331")
addappid(1902882, 1, "f0a214b429bd8afbac326630bad67843449c0c68a90b44a3752798b70d7d717e")
addappid(1902883, 1, "97575b9a7ff3416b9e9fd30c0ff59bd838ca132c904a0cfe42f3c77a3ade2f31")
