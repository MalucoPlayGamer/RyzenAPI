-- Lua provided by RyzenAPI
-- Game: Congo

-- MAIN APPLICATION
addappid(317530)

-- MAIN APP DEPOTS / PACKAGES
addappid(317531, 1, "8f4b965cbdc8d513ed999d20ef150ce32ac59000d6a3c6e1ceebfaa37240a60c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
