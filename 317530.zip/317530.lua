-- Lua provided by RyzenAPI
-- Game: Congo

-- MAIN APPLICATION
addappid(317530)
-- Game: addappid(317530)

-- MAIN APP DEPOTS / PACKAGES
addappid(317531, 1, "8f4b965cbdc8d513ed999d20ef150ce32ac59000d6a3c6e1ceebfaa37240a60c")
