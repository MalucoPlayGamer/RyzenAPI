-- 2138410's Lua and Manifest Created by Hubcap Manifest
-- Turnip Mountain
-- Created: July 30, 2026 at 14:14:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2138410) -- Turnip Mountain
-- MAIN APP DEPOTS
addappid(2138411, 1, "9c7c908a16306607582b6bb15f26e060cb7ccd6d3c34552e79eb01850cd24bab") -- Depot 2138411
setManifestid(2138411, "8155037866560794533", 98491026)