-- Lua provided by RyzenAPI
-- Game: 2781210

-- MAIN APPLICATION
addappid(2781210)
-- Game: addappid(2781210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781211, 1, "5bd92e731fccd46155196d3907b2afb3488046934c73dc8035a92db827bd6cb7")
