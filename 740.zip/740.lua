-- Lua provided by RyzenAPI
-- Game: Counter-Strike Global Offensive - Dedicated Server

-- MAIN APPLICATION
addappid(740)

-- MAIN APP DEPOTS / PACKAGES
addappid(731,0,"bca9a9cde94bb4dff61849c6a87230ee45867a590fdd28826366e35e7d62c08e")
addappid(740,0,"a25453ccd4815e8a3d3ebc7ac912744bacd544a42e46247730b5178acb2086e5")

