-- Lua provided by RyzenAPI
-- Game: Katamari Damacy REROLL

-- MAIN APPLICATION
addappid(848350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(848351, 1, "282b2c0becb141144c1a0d54acb30f28f1640f663bb55a02944d930d80cbec74")

