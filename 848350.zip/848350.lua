-- Lua provided by RyzenAPI
-- Game: 848350

-- MAIN APPLICATION
addappid(848350)
-- Game: addappid(848350)

-- MAIN APP DEPOTS / PACKAGES
addappid(848351, 1, "282b2c0becb141144c1a0d54acb30f28f1640f663bb55a02944d930d80cbec74")
