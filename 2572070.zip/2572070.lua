-- Lua provided by RyzenAPI
-- Game: Seablip Demo

-- MAIN APPLICATION
addappid(2572070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572072,0,"d3bde0f8ef334f43f2b5d426c518b8b82bd5932bd533befa29678b4e6cc138aa")
