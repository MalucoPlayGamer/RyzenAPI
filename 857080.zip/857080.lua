-- Lua provided by RyzenAPI
-- Game: Escape from the Princess

-- MAIN APPLICATION
addappid(857080)
-- Game: addappid(857080)

-- MAIN APP DEPOTS / PACKAGES
addappid(857081, 1, "7fc670410e5981c330fb7e4b80661704b7fd8c0a7d1897f7c818f497692085c1")
