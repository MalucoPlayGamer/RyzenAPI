-- Lua provided by RyzenAPI
-- Game: Prison Alone

-- MAIN APPLICATION
addappid(3087680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087681, 1, "c417b4f4b904ce8b72dfd04f5c824c6a1dfb24be391eb6087c4918a0d8dc8bcc")

