-- Lua provided by RyzenAPI 
-- Game: Every Letter
addappid(2379720)
addappid(2379721, 1, "a522b6ed5c9f8275f0e45e2091777d5990dfa605d3d9c0bb39bb5581ca86c5c8")
addappid(2379722, 1, "91833ef512d81c14087244ecb4013b47f5a4a3af7cbc538a3756e6d3f24d293d")
addappid(2379723, 1, "ffc3ba9b51098449a8ef9849a54df173099c3e2a25acb987520ff9b151e1d589")
