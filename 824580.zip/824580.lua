-- Lua provided by RyzenAPI
-- Game: addappid(824580)

-- MAIN APPLICATION
addappid(824580)

-- MAIN APP DEPOTS / PACKAGES
addappid(824581, 1, "d7bdbf3382fc774226c3ad15dc8f8da0285c296175452beb1b19bc39bafe15be")
