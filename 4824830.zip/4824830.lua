-- 4824830's Lua and Manifest Created by Hubcap Manifest
-- The Last Factory
-- Created: July 28, 2026 at 11:33:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4824830) -- The Last Factory
-- MAIN APP DEPOTS
addappid(4824831, 1, "c7ae8f3c520aa3b85688800f32b5a60f7ce186924736ab494c0016e7a73c0b7c") -- Depot 4824831
setManifestid(4824831, "605367198885949169", 1089635592)
addappid(4824832, 1, "7d782cbfb3db06a90cd4a0f484910cd8d1fa69c16b19626be47a3d7f7a2481d9") -- Depot 4824832
setManifestid(4824832, "2937696807140143656", 824345532)