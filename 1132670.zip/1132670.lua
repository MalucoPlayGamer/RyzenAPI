-- Lua provided by RyzenAPI
-- Game: 1132670

-- MAIN APPLICATION
addappid(1132670)
-- Game: addappid(1132670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132671, 1, "a0aa9e37a7784bae2d3a3876a7cb1436bc3abac26d566c9101f29d7daf6900f9")
