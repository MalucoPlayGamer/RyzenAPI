-- Lua provided by SkyAPI 
-- Game: Undungeon
addappid(928990)
addappid(928991, 1, "2b8384b3a17008b0730574ed878c9da936ada91cd19136f0bbd277ae961c29df")
