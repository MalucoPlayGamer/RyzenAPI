-- Lua provided by RyzenAPI
-- Game: 928990

-- MAIN APPLICATION
addappid(928990)
-- Game: addappid(928990)

-- MAIN APP DEPOTS / PACKAGES
addappid(928991, 1, "2b8384b3a17008b0730574ed878c9da936ada91cd19136f0bbd277ae961c29df")
