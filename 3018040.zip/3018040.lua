-- Lua provided by RyzenAPI
-- Game: Game: Starground Demo

-- MAIN APPLICATION
addappid(3018040)
-- Game: addappid(3018040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018041, 1, "5bad0ed0838073a0ba0641c9c906f9a3f28c17b35c7a287952a48858fbbf799c")
