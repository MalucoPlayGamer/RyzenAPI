-- Lua provided by RyzenAPI
-- Game: Game: Succubus Girl

-- MAIN APPLICATION
addappid(1778330)
-- Game: addappid(1778330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778331, 1, "8b5c65b6ac37a5e33f7c45a284222564188b50d246782675615033ae8b431a39")
