-- Lua provided by RyzenAPI
-- Game: WarPlan

-- MAIN APPLICATION
addappid(1084790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084791, 1, "2ea789e67663420ca8e54d160d32293328772ef22d49b653b77ed7bfab000a98")
addappid(1084792, 1, "5cf93099552397e0dd26a54069671f841f7453902371facaf3fc3a9082fa1987")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
