-- Lua provided by RyzenAPI
-- Game: Zombie Quarantine

-- MAIN APPLICATION
addappid(360400)
addappid(642500)

-- MAIN APP DEPOTS / PACKAGES
addappid(360401, 1, "069884331449ad0191771e28c7554a6725d9489bca08fe1c9c830318200dc2b1")

