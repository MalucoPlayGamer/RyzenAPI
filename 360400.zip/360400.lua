-- Lua provided by RyzenAPI
-- Game: AppID 360400

-- MAIN APPLICATION
addappid(360400)

-- MAIN APP DEPOTS / PACKAGES
addappid(360401, 1, "069884331449ad0191771e28c7554a6725d9489bca08fe1c9c830318200dc2b1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(642500)
