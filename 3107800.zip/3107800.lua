-- Lua provided by RyzenAPI
-- Game: LIZARDS MUST DIE 2

-- MAIN APPLICATION
addappid(3107800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107801, 1, "890f21e1179fb55405d9a3e26c308dd7671d612e5d67f6ae07ff9e9f4ac92c14")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3563320)
addappid(3563330)
addappid(3969230)
