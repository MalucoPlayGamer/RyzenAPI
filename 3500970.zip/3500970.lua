-- Lua provided by RyzenAPI
-- Game: 3500970

-- MAIN APPLICATION
addappid(3500970)
-- Game: addappid(3500970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500971, 1, "bb95c48bbad3a6c01ba86d4f35b691500816c4938de5fef70828b0043194f247")
addappid(3500972, 1, "72654922f8ffd8fd749ee9bd3bc6ef132a88006bcf7d91a8e6b747daf15d2f74")
