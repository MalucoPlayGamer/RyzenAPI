-- Lua provided by RyzenAPI
-- Game: Block Sky Rise

-- MAIN APPLICATION
addappid(3644070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3644071,0,"ee0a5341fc2ba6769dfa6f93d621e91302f9680d9a1e93eea1dd24bb0c96bb19")

