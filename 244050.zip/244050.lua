-- Lua provided by RyzenAPI
-- Game: Rise of Flight United

-- MAIN APPLICATION
addappid(244050)
addappid(244060)
addappid(244061)
addappid(244062)
addappid(244063)
addappid(244064)
addappid(244065)
addappid(244066)
addappid(315560)
addappid(356950)
addappid(360020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(244051, 1, "a4aed5eb13916d7135b54a84c3dc6fdab7592a4d708db12fa25a5cd4ce9b5881")

