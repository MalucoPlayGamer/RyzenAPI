-- Lua provided by RyzenAPI
-- Game: addappid(436110)

-- MAIN APPLICATION
addappid(436110)
addappid(443400)

-- MAIN APP DEPOTS / PACKAGES
addappid(436111, 1, "ef98010defc935cf39aa927f69978ba9f473409f144898331606909bd2a0ff79")
