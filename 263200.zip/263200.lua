-- Lua provided by RyzenAPI
-- Game: Signs of Life

-- MAIN APPLICATION
addappid(263200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(263201, 1, "5178cb5ad8f827fb14fdc23cb32f117d66dc0175da637c51724e95ba981dc2e9")
addappid(263203, 1, "80013f2137524d4fd83ab392670132343cf4b3a63560ba168b2161939fd02e69")

