-- Lua provided by RyzenAPI
-- Game: FUSER™ - Dua Lipa - "Levitating"

-- MAIN APPLICATION
addappid(1771596)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771596,0,"b61aa8ca31c267801268344de6a93b83a4a2cacbc31cb3134b56072eaf1c58a7")
