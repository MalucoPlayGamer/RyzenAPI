-- Lua provided by RyzenAPI
-- Game: Game: Jiangshi x Daoshi

-- MAIN APPLICATION
addappid(1338460)
addappid(1360370)
-- Game: addappid(1338460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338461, 1, "8698b796efbb909a52f9cc9ec8dbed4c804da16bf2ee88a01c0840548738d95a")
