-- Lua provided by RyzenAPI
-- Game: Impresja

-- MAIN APPLICATION
addappid(657530)

-- MAIN APP DEPOTS / PACKAGES
addappid(657531, 1, "d395b8c8d2da5307c3d3d64dd6d7cdaaa8002fe93e7fa83cbadfbebcea54a173")

