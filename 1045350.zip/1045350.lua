-- Lua provided by RyzenAPI
-- Game: Hentai Pussy

-- MAIN APPLICATION
addappid(1045350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045351, 1, "106d53f2ac0cab8de1661e4b032f050c8a87ca9e1e5ce63dac1aaf731b8773f3")
addappid(1051910, 0, "b70af5dc4f36f4afb48641512ed7a6ace0ef6eed1f0a361858af3fc0ab6ab815")

