-- Lua provided by RyzenAPI
-- Game: Drunk: Relapsed

-- MAIN APPLICATION
addappid(2101480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101481, 1, "5834d473eefbced061d2f4e7cceb7f88008c4052f56210ffc2f2dbc5d11716a5")

