-- Lua provided by RyzenAPI
-- Game: Premier Buggy Racing Tour

-- MAIN APPLICATION
addappid(716600)

-- MAIN APP DEPOTS / PACKAGES
addappid(716601, 1, "cb648c19dff4d283358019faef1a8b508019975e4bbb8ed2bef4099da9c8e3d1")
