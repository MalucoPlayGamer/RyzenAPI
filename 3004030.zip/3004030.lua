-- Lua provided by RyzenAPI
-- Game: JOI Lab VR 🔞 / 自慰ラボ

-- MAIN APPLICATION
addappid(3004030)
-- Game: addappid(3004030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004032,0,"294726d5256520a7539030ea4d26e6140515aed05cb28791b1c4d1162a87333c")
