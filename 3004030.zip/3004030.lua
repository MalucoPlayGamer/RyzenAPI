-- Lua provided by RyzenAPI
-- Game: JOI Lab VR 🔞 / 自慰ラボ

-- MAIN APPLICATION
addappid(3004030)
addappid(3343740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3004032,0,"294726d5256520a7539030ea4d26e6140515aed05cb28791b1c4d1162a87333c")

