-- Lua provided by RyzenAPI
-- Game: Game: AppID 1502370

-- MAIN APPLICATION
addappid(1502370)
-- Game: addappid(1502370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502371, 1, "44ce8418902cc188ef5905580a27985611195c606f0fe4dcd5f64fcbffaea558")
