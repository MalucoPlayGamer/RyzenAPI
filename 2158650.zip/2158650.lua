-- Lua provided by RyzenAPI
-- Game: Game: I Did Not Buy This Ticket

-- MAIN APPLICATION
addappid(2158650)
-- Game: addappid(2158650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158651, 1, "99af3d75ca2ab7e12bf66d9b4bcdc6ad2699afd96e7817a213179cebec573215")
