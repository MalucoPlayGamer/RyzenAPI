-- Lua provided by RyzenAPI
-- Game: addappid(1209133)

-- MAIN APPLICATION
addappid(1209133)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209133,0,"9525f32f3513219eb987b8dee36dfd7ef93282b4ea2e2c180ecfc1424123ee85")
