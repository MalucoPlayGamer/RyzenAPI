-- Lua provided by RyzenAPI
-- Game: The Hundred Youkai Master

-- MAIN APPLICATION
addappid(3654060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3654061, 1, "99390007196acca447978332513ae46ec93f97ff15501de98b556f5a3e319387")
