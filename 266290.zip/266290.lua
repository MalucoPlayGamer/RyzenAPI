-- Lua provided by RyzenAPI
-- Game: addappid(266290)

-- MAIN APPLICATION
addappid(266290)

-- MAIN APP DEPOTS / PACKAGES
addappid(266291, 1, "48060c04223b64e860ef1a000ffb9c338e6b7997d637a11b8d430c42ca4ff24a")
