-- Lua provided by RyzenAPI
-- Game: Songs of the HMong

-- MAIN APPLICATION
addappid(2715930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715931, 1, "f8be04357e80f2f1fae982bbfd8239ae49ea6b95239525c1a5875a917c880718")

