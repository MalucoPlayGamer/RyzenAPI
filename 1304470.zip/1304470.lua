-- Lua provided by SkyAPI 
-- Game: 降妖神兵
addappid(1304470)
addappid(1304471, 1, "0ed64ad571e5fe283b9916cf37db08ab2f37a8221a53651dd1544e812832c239")
