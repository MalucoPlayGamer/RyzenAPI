-- Lua provided by RyzenAPI 
-- Game: AppID 3163150
addappid(3163150)
addappid(3163151, 1, "c45760085d900b76d65b0101040ac97821171c84d4bf3383127d41a0b06f9d3a")
