-- Lua provided by RyzenAPI
-- Game: Teacher Lady

-- MAIN APPLICATION
addappid(1245090)
addappid(1245340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245091, 1, "d045e2b306a1921fc2eb1e294d85a814bff742a5802affc4511db8367190a077")
