-- Lua provided by RyzenAPI
-- Game: addappid(1055170)

-- MAIN APPLICATION
addappid(1055170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055171, 1, "f13eed82d710ef02a5276808db4ff6e125922ed5c3c194bd3f7be235beaf2834")
