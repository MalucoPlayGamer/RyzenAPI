-- Lua provided by RyzenAPI
-- Game: Once Upon A Mind - A Little Too Friendly

-- MAIN APPLICATION
addappid(3690750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690751, 1, "d817bb38eb83fe4fad4e329034711808535ca1363381069195e80b13f7f11fd1")

