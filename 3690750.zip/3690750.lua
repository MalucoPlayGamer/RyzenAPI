-- Lua provided by SkyAPI 
-- Game: AppID 3690750
addappid(3690750)
addappid(3690751, 1, "d817bb38eb83fe4fad4e329034711808535ca1363381069195e80b13f7f11fd1")
