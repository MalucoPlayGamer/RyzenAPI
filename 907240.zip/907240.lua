-- Lua provided by RyzenAPI
-- Game: 像素修真 - Pixel Xiuzhen

-- MAIN APPLICATION
addappid(907240)

-- MAIN APP DEPOTS / PACKAGES
addappid(907241, 1, "26cf627e1cb22e4a524fb85b585a8051bedb9685751fc67ba48645df7546512e")

