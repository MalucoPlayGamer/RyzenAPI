-- Lua provided by RyzenAPI
-- Game: Know Your Limits

-- MAIN APPLICATION
addappid(2625030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625031, 1, "925f01c57f6784acde90c171875789568076c35978ed8954b5a2cd7dcf7468d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
