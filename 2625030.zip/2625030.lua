-- Lua provided by RyzenAPI
-- Game: Know Your Limits

-- MAIN APPLICATION
addappid(2625030)
-- Game: addappid(2625030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625031, 1, "925f01c57f6784acde90c171875789568076c35978ed8954b5a2cd7dcf7468d5")
