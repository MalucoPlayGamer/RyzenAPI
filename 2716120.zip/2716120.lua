-- Lua provided by RyzenAPI 
-- Game: Kaetram
addappid(2716120)
addappid(2716121, 1, "d35d750e58e9673f56cdb10d264d0bb117ba2e5823f638b4449cf4c32db454ee")
addappid(2716122, 1, "6d63fc31f62cd5c0393203b1759976ed7fac2fac29b033ab2f9e5c83fe455f6f")
addappid(2716123, 1, "c2a625ceeaaaa3801fc1d4b2a5a5677916b08e238a5c5c3c0a7592ffae1811e5")
