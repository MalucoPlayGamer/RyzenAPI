-- Lua provided by RyzenAPI
-- Game: Witch College

-- MAIN APPLICATION
addappid(1116020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116021, 1, "5e8e72abb4c5c96b9fc201581b6deedce5c7ab70e0c8cfa3ca34b9c2221a9fd5")
