-- Lua provided by RyzenAPI 
-- Game: The Gold River Project
addappid(1253220)
addappid(1253221, 1, "25b9c9a08aeefc0ca628bfa486538d10955829ce6a2933242ea428f5e861cca3")
