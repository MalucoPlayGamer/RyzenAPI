-- Lua provided by RyzenAPI
-- Game: 1025960

-- MAIN APPLICATION
addappid(1025960)
-- Game: addappid(1025960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025961, 1, "188cc0a09f75cb01aa9e9ccb70fb2efbea42f6940e9a86599270537222004106")
