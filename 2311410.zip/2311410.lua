-- Lua provided by RyzenAPI
-- Game: Reincarnation : Hero of the Gun

-- MAIN APPLICATION
addappid(2311410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311411, 1, "c653f1a69ce24b087432cbd9112a5945633f82d33f0862d609272da4a13442bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
