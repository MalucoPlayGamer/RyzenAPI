-- Lua provided by RyzenAPI
-- Game: Game: Tentacles of Submission

-- MAIN APPLICATION
addappid(1717610)
-- Game: addappid(1717610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717611, 1, "6f934e03ac0ab843880fd4477a2f7e91611b32780ab7b567da42ebbc9ac64e82")
