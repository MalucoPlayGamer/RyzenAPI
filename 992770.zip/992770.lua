-- Lua provided by RyzenAPI
-- Game: Odyssey Soundtrack

-- MAIN APPLICATION
addappid(992770)

-- MAIN APP DEPOTS / PACKAGES
addappid(992770,0,"e772ee5b12d573bf361428eeb3ee4f9a84fa614b86afdd1bce95810102ee17ec")

