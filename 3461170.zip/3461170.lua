-- Lua provided by RyzenAPI
-- Game: Mutant Slime : Survivor Team Demo

-- MAIN APPLICATION
addappid(3461170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461171, 1, "17d2f95a6051087e7e401f3acc34e7c37711ba0dcb20fd37cb5ddcaa19ada890")

