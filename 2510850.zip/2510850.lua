-- Lua provided by RyzenAPI
-- Game: Slay the Minotaur

-- MAIN APPLICATION
addappid(2510850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2510851, 1, "9ef0d2eb19823c6b84de7d0dec0876caf84d5f6aaf827042e3c8d98f1ddca491")

