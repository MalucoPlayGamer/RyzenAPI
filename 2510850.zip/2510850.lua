-- Lua provided by RyzenAPI
-- Game: Slay the Minotaur

-- MAIN APPLICATION
addappid(2510850)
-- Game: addappid(2510850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510851, 1, "9ef0d2eb19823c6b84de7d0dec0876caf84d5f6aaf827042e3c8d98f1ddca491")
