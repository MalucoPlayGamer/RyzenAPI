-- Lua provided by SkyAPI 
-- Game: Slay the Minotaur
addappid(2510850)
addappid(2510851, 1, "9ef0d2eb19823c6b84de7d0dec0876caf84d5f6aaf827042e3c8d98f1ddca491")
