-- Lua provided by RyzenAPI
-- Game: Fancy Fishing VR

-- MAIN APPLICATION
addappid(601940)

-- MAIN APP DEPOTS / PACKAGES
addappid(601941, 1, "b70a41668b71c58395cd0fba71965c027c5a42865f64483dceb15936e5bbd467")

