-- Lua provided by RyzenAPI
-- Game: Game: Halls of Torment Soundtrack

-- MAIN APPLICATION
addappid(3464980)
-- Game: addappid(3464980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464981, 1, "066b6c2959e18d351286f1bbaa6f502288fd7d437597e8ca7b4e3bc47e937f33")
addappid(3464982, 1, "1c897247841820d0622680ef0485d378c6e1bbf3dc09b534b36496c876ca9a4e")
