-- Lua provided by SkyAPI 
-- Game: Triad Ball
addappid(2394240)
addappid(2394241, 1, "ce6231ddcaa2f6a08961a709d3524316d17af4937683c203ee4642ab94cb17cf")
