-- Lua provided by RyzenAPI
-- Game: Triad Ball

-- MAIN APPLICATION
addappid(2394240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394241, 1, "ce6231ddcaa2f6a08961a709d3524316d17af4937683c203ee4642ab94cb17cf")

