-- Lua provided by RyzenAPI
-- Game: Gravitators

-- MAIN APPLICATION
addappid(1321890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321891, 1, "d67cfa473cb267fb33bb721f05bfb9ae43d5255befb29412a38af07a08a37f5c")
addappid(1321893, 1, "24928915fd6c6d514e08a99f623116a1fdc0577d260d8928edb27d87d24fd54e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1639960)
