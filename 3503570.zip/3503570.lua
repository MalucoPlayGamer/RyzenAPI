-- Lua provided by SkyAPI 
-- Game: Whispers of Lust
addappid(3503570)
addappid(3503571, 1, "e9f4158176b2ee3ef4b2e6094047c9fe1678e1d2111d3b8807b9063eedca4596")
