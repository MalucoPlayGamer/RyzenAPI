-- Lua provided by RyzenAPI
-- Game: 3503570

-- MAIN APPLICATION
addappid(3503570)
-- Game: addappid(3503570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3503571, 1, "e9f4158176b2ee3ef4b2e6094047c9fe1678e1d2111d3b8807b9063eedca4596")
