-- Lua provided by RyzenAPI
-- Game: Curse of Black Bone

-- MAIN APPLICATION
addappid(2086150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086151, 1, "198f778293a9613427c09c5da40f4d9d7aa0cb3388e8bb0ffe4df2d3fdd95987")

