-- Lua provided by RyzenAPI
-- Game: Horizon To Crinoa: Have Faith in Radiance -Prototype-

-- MAIN APPLICATION
addappid(2538840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538841, 1, "1f34d86eae6ab0ead973fb58547a665e5ba8fd944c28c40e519fc2ca86ca91ff")
