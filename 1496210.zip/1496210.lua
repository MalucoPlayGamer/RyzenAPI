-- Lua provided by RyzenAPI
-- Game: Centrifugal

-- MAIN APPLICATION
addappid(1496210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496211, 1, "ba9c67d1d19a554f082d6572c2ab2601bedfa519da867dd4fe1055382daae553")
