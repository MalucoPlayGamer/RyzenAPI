-- Lua provided by RyzenAPI 
-- Game: AppID 1451650
addappid(1451650)
addappid(1451651, 1, "36ea10e4a98c632c12bc223077230d8cf478d012d3ed9ef70d50323d1465973d")
addappid(1451652, 1, "5a4b1d4e0373008bf290fc0b793b5ac8922f168f2f85c804910cce7d7d37eec5")
