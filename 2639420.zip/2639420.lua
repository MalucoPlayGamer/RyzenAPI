-- Lua provided by SkyAPI 
-- Game: Fairytale Fables
addappid(2639420)
addappid(2639421, 1, "a9607f84ed3488d3d6d50c3bb81d51e530a65d6b5e02841fadf8fc2767997404")
addappid(2639422, 1, "f2562b43f67c996c90a175732a7ee00c25ccbdca7a8d22b68c69e9b52c971f54")
addappid(2639423, 1, "8024dee1e3fa55c9d6c1497a9c99e73312a7bf44373052424a353dff08a1d7ca")
