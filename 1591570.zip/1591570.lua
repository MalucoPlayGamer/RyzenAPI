-- Lua provided by RyzenAPI
-- Game: Mondealy: Day One

-- MAIN APPLICATION
addappid(1591570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1591571, 1, "f34df2494c1d2733ff55922a7431d3d80fb746e34e3a8e4a14d02e79b0e6d3ea")
addappid(1591572, 1, "5860f6e3896a112adde47a12a68132c891b190616f78dd2df85a38a60a251de9")

