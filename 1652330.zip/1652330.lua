-- Lua provided by RyzenAPI
-- Game: Jixxaw: Party Time

-- MAIN APPLICATION
addappid(1652330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652331, 1, "485e24b764b4f9c29c4bbe364dccc39623448551277a8022fd1d2ace65820827")
