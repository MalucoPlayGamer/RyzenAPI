-- Lua provided by RyzenAPI
-- Game: Jixxaw: Party Time

-- MAIN APPLICATION
addappid(1652330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1652331, 1, "485e24b764b4f9c29c4bbe364dccc39623448551277a8022fd1d2ace65820827")

