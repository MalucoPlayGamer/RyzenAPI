-- Lua provided by RyzenAPI
-- Game: Bomb Club Deluxe - Soundtrack

-- MAIN APPLICATION
addappid(1906710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906711, 1, "a52dd1a9881a02aa17e209405d4cd9c1dad30ca91d4c5762df825814a39d2dfa")
