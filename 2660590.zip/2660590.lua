-- Lua provided by RyzenAPI
-- Game: Game: Lucky Mayor Demo

-- MAIN APPLICATION
addappid(2660590)
-- Game: addappid(2660590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660591, 1, "de1b49e2c2c4472c6427b20d42d9f01c762c162fe6277e00aad4fb9bbd2e31b4")
