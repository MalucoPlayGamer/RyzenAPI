-- Lua provided by RyzenAPI
-- Game: 2319030

-- MAIN APPLICATION
addappid(2319030)
-- Game: addappid(2319030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319031, 1, "b1f7187090f08c793f4bd4e8c5a0a9676940f6c1facd511d5bc0e56f1fbe56ab")
