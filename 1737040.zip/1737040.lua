-- Lua provided by RyzenAPI
-- Game: Motor Town : Behind The Wheel Demo

-- MAIN APPLICATION
addappid(1737040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737041, 1, "cb05e8f01c6561028c45e74fd280f1e9c96caefd2c0b54d7d326268443826667")
