-- Lua provided by RyzenAPI
-- Game: Dollhouse

-- MAIN APPLICATION
addappid(280850)
-- Game: addappid(280850)

-- MAIN APP DEPOTS / PACKAGES
addappid(280851, 1, "e6081b4df407313f1e0e49050f6874c51857e4aa39d8c0804390efec030ad36c")
