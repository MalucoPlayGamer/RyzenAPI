-- Lua provided by RyzenAPI
-- Game: Dollhouse

-- MAIN APPLICATION
addappid(280850)

-- MAIN APP DEPOTS / PACKAGES
addappid(280851, 1, "e6081b4df407313f1e0e49050f6874c51857e4aa39d8c0804390efec030ad36c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
