-- Lua provided by SkyAPI 
-- Game: Dollhouse
addappid(280850)
addappid(280851, 1, "e6081b4df407313f1e0e49050f6874c51857e4aa39d8c0804390efec030ad36c")
