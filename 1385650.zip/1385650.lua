-- Lua provided by RyzenAPI
-- Game: addappid(1385650)

-- MAIN APPLICATION
addappid(1385650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385651, 1, "fc7c6291512eba51751882d4782d8aafac974dc9c1d32092a55b0a9f1af720d4")
