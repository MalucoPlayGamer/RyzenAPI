-- Lua provided by RyzenAPI 
-- Game: Hot Pot For One (Endless Mode Now Available)
addappid(1385650)
addappid(1385651, 1, "fc7c6291512eba51751882d4782d8aafac974dc9c1d32092a55b0a9f1af720d4")
