-- Lua provided by RyzenAPI
-- Game: Just One Line

-- MAIN APPLICATION
addappid(228990)
addappid(640210)
addappid(640211)
addappid(640213)

-- MAIN APP DEPOTS / PACKAGES
addappid(640212,0,"f77fa2315eb75dfd10184a993c1573d8f1ea05e219505e48e137274b2c5ee3ca")
addappid(640214,0,"3dd4f6089fea677d1eabe21fd201b61563864609539442c002097146bd420627")

