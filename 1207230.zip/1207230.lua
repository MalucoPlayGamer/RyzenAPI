-- Lua provided by RyzenAPI 
-- Game: AppID 1207230
addappid(1207230)
addappid(1207231, 1, "2aa013d4af3b7200204460a1cbeaaa625f8f29a6b8f3d004dc2b5b0d209d74e9")
