-- Lua provided by RyzenAPI 
-- Game: ARRIVAL: ZERO EARTH
addappid(1613580)
addappid(1613581, 1, "d025a3e699b394a265b638c496dba635c0597eaed58506479041166132e3c25f")
