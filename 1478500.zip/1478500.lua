-- Lua provided by RyzenAPI
-- Game: Big Walk

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1478500, 1, "1174edcf23ff4903776c928407704c67bf13b9f75a546c3587fe5413055b2ca8") -- Big Walk
addappid(1478501, 1, "f1f21164a742a9a2ce6614fc29dbe3fda4a2365c1b73e88a2738bec5cca99d53") -- Depot 1478501
addappid(1478502, 1, "595e8e546355fab56cf985a75b0c428014f60327b70dc584cba7a3bfbebe3c71") -- Depot 1478502

