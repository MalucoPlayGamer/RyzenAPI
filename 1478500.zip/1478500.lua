-- 1478500's Lua and Manifest Created by Hubcap Manifest
-- Big Walk
-- Created: August 04, 2026 at 09:31:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1478500, 1, "1174edcf23ff4903776c928407704c67bf13b9f75a546c3587fe5413055b2ca8") -- Big Walk
-- MAIN APP DEPOTS
addappid(1478501, 1, "f1f21164a742a9a2ce6614fc29dbe3fda4a2365c1b73e88a2738bec5cca99d53") -- Depot 1478501
setManifestid(1478501, "6520011635981099030", 3740602488)
addappid(1478502, 1, "595e8e546355fab56cf985a75b0c428014f60327b70dc584cba7a3bfbebe3c71") -- Depot 1478502
setManifestid(1478502, "6217079635181162160", 7272213876)