-- Lua provided by RyzenAPI
-- Game: The Mice of Riddle Place: The Incident of Izzy Ramirez

-- MAIN APPLICATION
addappid(686660)

-- MAIN APP DEPOTS / PACKAGES
addappid(686662,0,"61b29cfd1184b7e74ba84ca0c48830f8f6ee2d2bee68448233870168d15ea263")

