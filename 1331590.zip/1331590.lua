-- Lua provided by RyzenAPI
-- Game: 7 дней лета: Youth Sky

-- MAIN APPLICATION
addappid(1331590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331591, 1, "02025ed949e1a56438ba960cb35bc990f9b63d7091939033194766f5ef0632b9")

