-- Lua provided by SkyAPI 
-- Game: Beat Slayer
addappid(2089830)
addappid(2089831, 1, "e2a01648813baf9f9dadd6c80e4d63f749186ec619089e315aa84bf9ab3f6e76")
