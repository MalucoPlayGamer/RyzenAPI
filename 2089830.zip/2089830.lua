-- Lua provided by RyzenAPI
-- Game: Beat Slayer

-- MAIN APPLICATION
addappid(2089830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089831, 1, "e2a01648813baf9f9dadd6c80e4d63f749186ec619089e315aa84bf9ab3f6e76")
