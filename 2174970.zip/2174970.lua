-- Lua provided by RyzenAPI
-- Game: 2174970

-- MAIN APPLICATION
addappid(2174970)
-- Game: addappid(2174970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174971, 1, "48dde30d62ed8a34562af0598d14050176f4f57c90349a7a3f73def64a2f1661")
