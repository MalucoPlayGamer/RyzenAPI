-- Lua provided by RyzenAPI
-- Game: AppID 289480

-- MAIN APPLICATION
addappid(289480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(289481, 1, "7a14cacb1ca08291b7ecc879849500794d6e7065fb883f910ded5e28bbe926c9")
addappid(289482, 1, "dee07c9c7055d6942c4ee45462b3f13f7e11edc6d3b09ee73349466e4fcf64bb")

