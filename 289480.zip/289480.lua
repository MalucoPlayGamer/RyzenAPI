-- Lua provided by RyzenAPI
-- Game: 289480

-- MAIN APPLICATION
addappid(289480)
-- Game: addappid(289480)

-- MAIN APP DEPOTS / PACKAGES
addappid(289481, 1, "7a14cacb1ca08291b7ecc879849500794d6e7065fb883f910ded5e28bbe926c9")
addappid(289482, 1, "dee07c9c7055d6942c4ee45462b3f13f7e11edc6d3b09ee73349466e4fcf64bb")
