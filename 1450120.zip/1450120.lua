-- Lua provided by RyzenAPI 
-- Game: AppID 1450120
addappid(1450120)
addappid(1450121, 1, "78f2d760e5895a228884c01a01bbd3ba0777608dfe7f3eaff375c4d36b12a68c")
