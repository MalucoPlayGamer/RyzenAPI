-- Lua provided by RyzenAPI
-- Game: Man in gravity

-- MAIN APPLICATION
addappid(1386810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386811, 1, "b0ea9f64536a66495c0139ef482363fe2f1e4cad62740b0a806fb6799f3c65bd")

