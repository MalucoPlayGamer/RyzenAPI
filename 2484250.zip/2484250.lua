-- Lua provided by SkyAPI 
-- Game: ASTRA: Knights of Veda
addappid(2484250)
addappid(2484251, 1, "eec381bccb8c22c8214fe3e93326d08168ed21890ed5868458922052e82ff5c7")
