-- Lua provided by RyzenAPI
-- Game: ASTRA: Knights of Veda

-- MAIN APPLICATION
addappid(2484250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484251, 1, "eec381bccb8c22c8214fe3e93326d08168ed21890ed5868458922052e82ff5c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
