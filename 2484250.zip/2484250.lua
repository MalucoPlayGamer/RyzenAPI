-- Lua provided by RyzenAPI
-- Game: addappid(2484250)

-- MAIN APPLICATION
addappid(2484250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484251, 1, "eec381bccb8c22c8214fe3e93326d08168ed21890ed5868458922052e82ff5c7")
