-- Lua provided by RyzenAPI
-- Game: 1042800

-- MAIN APPLICATION
addappid(1042800)
-- Game: addappid(1042800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042801, 1, "1e5d9df64c85c7259e5764bc91970185aae825bae7e8bc0ad41b029e2a140782")
