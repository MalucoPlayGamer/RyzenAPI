-- Lua provided by RyzenAPI
-- Game: addappid(3109000)

-- MAIN APPLICATION
addappid(3109000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109001, 1, "c2107271672d8a49237c8ff469b1f4f64ef691dbb32e371caaa1b141017c8198")
