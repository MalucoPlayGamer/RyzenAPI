-- Lua provided by RyzenAPI 
-- Game: I'm Not Crazy
addappid(3109000)
addappid(3109001, 1, "c2107271672d8a49237c8ff469b1f4f64ef691dbb32e371caaa1b141017c8198")
