-- Lua provided by SkyAPI 
-- Game: Animal Kostume
addappid(2421110)
addappid(2421111, 1, "6eb6bdf7ef449997381dee05eb390b6edf4ab3c63a01a405e3d3bed6f3758ce1")
addappid(2421112, 1, "affef32b711b876c4fdeca7a27bc4c7f7b54a44c89b50fad6611a31857753abd")
addappid(2421113, 1, "5d24a16a5db1de41d1634b4367affe1f2baed241fce0eb9b1cc8c0899b51d36b")
