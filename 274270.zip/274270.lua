-- Lua provided by RyzenAPI
-- Game: NOT A HERO

-- MAIN APPLICATION
addappid(274270)
addappid(380030)

-- MAIN APP DEPOTS / PACKAGES
addappid(274271, 1, "c4997ffc9aabeb46353f96dfea25ea7b1ec5677d271d5713da0bf30fbef54023")
addappid(368520, 0, "3f76a719e56fdd2a1566226c469d3c76559c68ecf0c95bb216f5d0e6effac197")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(469810)
