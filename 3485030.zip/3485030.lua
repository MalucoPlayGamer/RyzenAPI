-- Lua provided by RyzenAPI
-- Game: Game: The Curse of Beatriz

-- MAIN APPLICATION
addappid(3485030)
-- Game: addappid(3485030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3485031, 1, "2b2ad9e3dedcb93cc85097e30c720ee5d2d873bf07cb022c36a9ff0d6f036c29")
