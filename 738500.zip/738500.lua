-- Lua provided by RyzenAPI
-- Game: The Parallax Effect

-- MAIN APPLICATION
addappid(738500)
addappid(1015840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(738501, 1, "9f4d56e0ecab1996eefa391f35507cde42b910fcc6c7825d455a6a7c79c20035")

