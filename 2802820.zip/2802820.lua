-- Lua provided by RyzenAPI
-- Game: 2802820

-- MAIN APPLICATION
addappid(2802820)
-- Game: addappid(2802820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802821, 1, "b9b87b3927b1b8e5a42ff1c971d8e7da18f4471694f024fd2f9d55402345a76f")
