-- Lua provided by SkyAPI 
-- Game: Aeon Must Die!
addappid(1089930)
addappid(1089931, 1, "91ea03ed64cea406ae721a0eeb0e18d8949de39f4030ef78eb080f50e1505cdb")
