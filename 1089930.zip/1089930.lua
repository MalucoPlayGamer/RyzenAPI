-- Lua provided by RyzenAPI
-- Game: Aeon Must Die!

-- MAIN APPLICATION
addappid(1089930)
addappid(1655870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1089931, 1, "91ea03ed64cea406ae721a0eeb0e18d8949de39f4030ef78eb080f50e1505cdb")

