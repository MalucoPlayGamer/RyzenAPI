-- Lua provided by RyzenAPI
-- Game: Aeon Must Die!

-- MAIN APPLICATION
addappid(1089930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089931, 1, "91ea03ed64cea406ae721a0eeb0e18d8949de39f4030ef78eb080f50e1505cdb")

