-- Lua provided by RyzenAPI
-- Game: Game: AppID 966350

-- MAIN APPLICATION
addappid(966350)
-- Game: addappid(966350)

-- MAIN APP DEPOTS / PACKAGES
addappid(966351, 1, "100042f323cb6158666162208c256df5aca43588c893d16060312c0c35fafdc1")
