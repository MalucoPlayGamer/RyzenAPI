-- Lua provided by RyzenAPI
-- Game: addappid(3327420)

-- MAIN APPLICATION
addappid(3327420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3327421, 1, "0586d60a6981b11aee956dba80eacd39d7f868bfca3a5a61cb53d0b4be938ffd")
