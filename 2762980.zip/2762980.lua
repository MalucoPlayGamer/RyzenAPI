-- Lua provided by RyzenAPI
-- Game: Game: Face Your Fear

-- MAIN APPLICATION
addappid(2762980)
-- Game: addappid(2762980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762981, 1, "39de716de4168d6123e11b0c7e36df97c83dcfa5b2defc2a003fb88b4e711bda")
