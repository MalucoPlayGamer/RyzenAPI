-- Lua provided by RyzenAPI
-- Game: Face Your Fear

-- MAIN APPLICATION
addappid(2762980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762981, 1, "39de716de4168d6123e11b0c7e36df97c83dcfa5b2defc2a003fb88b4e711bda")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
