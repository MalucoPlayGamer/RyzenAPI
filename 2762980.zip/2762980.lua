-- Lua provided by SkyAPI 
-- Game: Face Your Fear
addappid(2762980)
addappid(2762981, 1, "39de716de4168d6123e11b0c7e36df97c83dcfa5b2defc2a003fb88b4e711bda")
