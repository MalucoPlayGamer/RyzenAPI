-- Lua provided by SkyAPI 
-- Game: Hidden Series Prologue
addappid(2500610)
addappid(2500611, 1, "0a4d0f0b7faf4274f90df55e94b2675f9ddce60a53dfe34b838362a8644492cc")
