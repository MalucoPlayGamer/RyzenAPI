-- Lua provided by RyzenAPI
-- Game: MotoGP™21

-- MAIN APPLICATION
addappid(1447000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447001, 1, "63336d8971691a9f1c8a290b63703291352c9e9af3925a16dcf16b6e5c19acd3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1525820)
addappid(1525840)
