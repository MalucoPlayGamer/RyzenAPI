-- Lua provided by RyzenAPI
-- Game: MotoGP™21

-- MAIN APPLICATION
addappid(1447000)
-- Game: addappid(1447000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447001, 1, "63336d8971691a9f1c8a290b63703291352c9e9af3925a16dcf16b6e5c19acd3")
