-- Lua provided by RyzenAPI
-- Game: Other Side Of Mist And Mountain

-- MAIN APPLICATION
addappid(2672060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672061, 1, "b7fff35812906e73ec5d6970c860527da6a27902c9ddf6dd87405ff585cc219e")
