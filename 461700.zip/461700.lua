-- Lua provided by RyzenAPI
-- Game: Seduce Me 2: The Demon War

-- MAIN APPLICATION
addappid(461700)
addappid(575610)

-- MAIN APP DEPOTS / PACKAGES
addappid(461701, 1, "b658d2d274a0acd2941c4edf92b645e5584d0bbc3745717fabded25cbed1d08b")

