-- Lua provided by RyzenAPI
-- Game: Dust & Neon Demo

-- MAIN APPLICATION
addappid(2253020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253021, 1, "e1c9db72843bfc7d9f352d2e869a1d97135497c2469f3adfd6e71a1fb2ceea93")

