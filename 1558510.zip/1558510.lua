-- Lua provided by SkyAPI 
-- Game: MECHANICA: A Ballad of the Rabbit and Mercury
addappid(1558510)
addappid(1558511, 1, "02303acad4dfe666d380bc20e83c66948681daaf571b64a90b044665b9273e4b")
addappid(1558512, 1, "bff1b4370fb9ec9ae0eb83a433f68fd288f029beff93edae851d1be2a98391e2")
addappid(1558513, 1, "880fb41cdedda976812c12719aa74d555b4c86d18e763c78786ae017adb5a6d2")
