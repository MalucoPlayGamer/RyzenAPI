-- Lua provided by SkyAPI 
-- Game: AppID 1875080
addappid(1875080)
addappid(1875081, 1, "5bf6c402a9a1a026a2da5d19ed30f7e8003815158343d62cd8befd36789b178b")
