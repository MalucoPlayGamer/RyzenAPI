-- Lua provided by RyzenAPI 
-- Game: Rabbit: Jigsaw Puzzles
addappid(833470)
addappid(833471, 1, "46048248aee7e0c93b5d544336cab49f3702719a641b14f9ffef64a493aed890")
