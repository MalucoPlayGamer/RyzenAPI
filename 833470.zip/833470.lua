-- Lua provided by RyzenAPI
-- Game: 833470

-- MAIN APPLICATION
addappid(833470)
-- Game: addappid(833470)

-- MAIN APP DEPOTS / PACKAGES
addappid(833471, 1, "46048248aee7e0c93b5d544336cab49f3702719a641b14f9ffef64a493aed890")
