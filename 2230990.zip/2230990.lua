-- Lua provided by RyzenAPI
-- Game: addappid(2230990)

-- MAIN APPLICATION
addappid(2230990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230991, 1, "5c8042a510b54d770366ba3dc679b91f8d0315a84ca7a6ef9147bf03a07e053a")
