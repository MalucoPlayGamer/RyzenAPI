-- Lua provided by RyzenAPI
-- Game: Graveyard Keeper OST

-- MAIN APPLICATION
addappid(919050)
-- Game: addappid(919050)

-- MAIN APP DEPOTS / PACKAGES
addappid(919052,0,"7e7e6c419ae023cf6616a608f94bf66f55c1c1378c8b366f5ccf57ff045a329c")
