-- Lua provided by RyzenAPI
-- Game: Zankinzoken

-- MAIN APPLICATION
addappid(2060740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060741, 1, "60ee2db59a0be5a898cbe9bb565d3ad83b04472d4df08f7c939ff5cc1d069cce")
