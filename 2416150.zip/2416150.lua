-- Lua provided by SkyAPI 
-- Game: Zombie Ants VR
addappid(2416150)
addappid(2416151, 1, "d45cc4fde905f23a89b10e29bdf89e0dca2f8a7d1c3ae7d9a26c4df9da0eada1")
