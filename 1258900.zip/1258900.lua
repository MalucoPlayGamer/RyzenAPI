-- Lua provided by RyzenAPI
-- Game: Arcade Redemption

-- MAIN APPLICATION
addappid(1258900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1258901, 1, "f814ae4898731ac1345210b60dba81ae5288575cd75e740a2435e89ae645212c")

