-- Lua provided by RyzenAPI
-- Game: Arcade Redemption

-- MAIN APPLICATION
addappid(1258900)
-- Game: addappid(1258900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258901, 1, "f814ae4898731ac1345210b60dba81ae5288575cd75e740a2435e89ae645212c")
