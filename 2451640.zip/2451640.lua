-- Lua provided by RyzenAPI
-- Game: Game: Furry Myth 🦁

-- MAIN APPLICATION
addappid(2451640)
-- Game: addappid(2451640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451641, 1, "032203c5ac58e693cb22424290bf3fd4641f142b47d3bc0f9b1a8e373fbed15f")
addappid(2805290, 0, "91b4f4bdc95dfce4a8be06bd68852dd600476e9e0604fdf0d66c4a2e62792c9b")
addappid(2805300, 0, "fc7fd96a853aa3e47ef97f1e87c5adcc20b0ebbdd7ed0c918f3b20af76596579")
