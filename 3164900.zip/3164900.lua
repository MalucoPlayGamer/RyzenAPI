-- Lua provided by RyzenAPI
-- Game: 3164900

-- MAIN APPLICATION
addappid(3164900)
-- Game: addappid(3164900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164901, 1, "2bff69f830f0621d256a1cc33b3846886c1ea90c529729f30bd1bf4a8ac22ffe")
