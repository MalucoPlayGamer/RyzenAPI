-- Lua provided by RyzenAPI 
-- Game: Look Outside
addappid(3373660)
addappid(3373661, 1, "88c6e87f7634aef8353a85a294ee8c152ecf785deb98dfec994bfa3181e747d1")
