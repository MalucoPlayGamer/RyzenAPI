-- Lua provided by RyzenAPI
-- Game: Game: Look Outside

-- MAIN APPLICATION
addappid(3373660)
-- Game: addappid(3373660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3373661, 1, "88c6e87f7634aef8353a85a294ee8c152ecf785deb98dfec994bfa3181e747d1")
