-- Lua provided by RyzenAPI
-- Game: Cooking Simulator VR

-- MAIN APPLICATION
addappid(1358140)
-- Game: addappid(1358140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358141, 1, "b9caad1928cb457a060452917395400de1e6b669ecb7fe0d3215dfe64deca51f")
