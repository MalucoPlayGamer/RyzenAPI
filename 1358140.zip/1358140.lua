-- Lua provided by RyzenAPI
-- Game: Cooking Simulator VR

-- MAIN APPLICATION
addappid(1358140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358141, 1, "b9caad1928cb457a060452917395400de1e6b669ecb7fe0d3215dfe64deca51f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
