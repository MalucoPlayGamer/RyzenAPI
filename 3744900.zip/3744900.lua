-- Lua provided by RyzenAPI
-- Game: 3744900

-- MAIN APPLICATION
addappid(3744900)
-- Game: addappid(3744900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3744902,0,"23687e2cfd1e28c8beadf151b05d83a04480c0c5e927b33d263c2adbd345394d")
