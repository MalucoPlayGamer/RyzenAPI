-- Lua provided by RyzenAPI
-- Game: 1829200

-- MAIN APPLICATION
addappid(1829200)
-- Game: addappid(1829200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829202,0,"351b1ce1f096c5a8b510729f7e2f694a9f94ac22c87647b703d2bc9e7ddda3f1")
