-- Lua provided by RyzenAPI
-- Game: Kandra The Moonwalker

-- MAIN APPLICATION
addappid(1829200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1829202,0,"351b1ce1f096c5a8b510729f7e2f694a9f94ac22c87647b703d2bc9e7ddda3f1")

