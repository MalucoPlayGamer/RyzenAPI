-- Lua provided by RyzenAPI
-- Game: Aurora Hills: Chapter 1

-- MAIN APPLICATION
addappid(2762230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762232,0,"a68b84574e8645869dc5ff61f1ccede46e20f5d449009fd97e52c2bed09b1c4f")
addappid(2762233,0,"11c0530e9d501530ac6ab3d1620c53d41de1c7538d7a075d971dc87bfa387cdd")
