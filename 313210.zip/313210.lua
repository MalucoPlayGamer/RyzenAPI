-- Lua provided by RyzenAPI
-- Game: 313210

-- MAIN APPLICATION
addappid(313210)
-- Game: addappid(313210)

-- MAIN APP DEPOTS / PACKAGES
addappid(313211, 1, "5c352ec10976d733a6f05d69b427775e0fbc84ec498df23eebd77241b5fafd28")
