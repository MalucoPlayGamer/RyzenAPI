-- Lua provided by RyzenAPI 
-- Game: Alpha Zylon
addappid(313210)
addappid(313211, 1, "5c352ec10976d733a6f05d69b427775e0fbc84ec498df23eebd77241b5fafd28")
