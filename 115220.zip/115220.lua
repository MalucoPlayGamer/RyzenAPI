-- Lua provided by RyzenAPI
-- Game: addappid(115220)

-- MAIN APPLICATION
addappid(115220)

-- MAIN APP DEPOTS / PACKAGES
addappid(115222,0,"5394ebe632522e1b910fde7330c9968127902f064cbcbcdcd14d0f4da9ad75ca")
