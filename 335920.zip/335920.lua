-- Lua provided by RyzenAPI
-- Game: addappid(335920)

-- MAIN APPLICATION
addappid(335920)

-- MAIN APP DEPOTS / PACKAGES
addappid(335921, 1, "9b0512fe5402f82d9dcf8efc06fe98e3a46a4ec6a0ee0722396e46f34099f7d7")
addappid(347110, 0, "265a764d9e564b9b16739d289b6ebcbf500dce0330cdb2f041a80e4304e5fc59")
