-- Lua provided by RyzenAPI 
-- Game: Heroines of Swords & Spells
addappid(1212400)
addappid(1212401, 1, "e1392f77dc81f5bce0ab3fb670b16b1c0341bc4584d3246b41665374fda41af0")
addappid(1511510, 0, "105105c35ff61a61e071de9af09959e38f359143f92f11a76c35f2a41ba4a7dd")
