-- Lua provided by RyzenAPI 
-- Game: Oh Trap!
addappid(994520)
addappid(994521, 1, "5d4661e07e35e44d85129161abae59527cdb535e1e909ef82a03106fad5eba59")
addappid(994522, 1, "6ce4f0917821a3d34c941befb4d497aedd528fe70ab2c335875037436079c5d1")
