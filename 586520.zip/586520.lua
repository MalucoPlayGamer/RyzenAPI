-- Lua provided by RyzenAPI
-- Game: 586520

-- MAIN APPLICATION
addappid(586520)
-- Game: addappid(586520)

-- MAIN APP DEPOTS / PACKAGES
addappid(586521, 1, "8b47d754ecea6977dd445cea03ee997bebad53fd30c639df3d2768dc99f07a30")
