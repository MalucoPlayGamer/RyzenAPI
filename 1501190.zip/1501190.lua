-- Lua provided by RyzenAPI
-- Game: addappid(1501190)

-- MAIN APPLICATION
addappid(1501190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501191, 1, "c3a124d9fd19db35c886ef49a7fa3b2c745abc11b67bb76f84d74bf98b40d485")
