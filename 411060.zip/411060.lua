-- Lua provided by RyzenAPI
-- Game: Roads of Rome 2

-- MAIN APPLICATION
addappid(411060)

-- MAIN APP DEPOTS / PACKAGES
addappid(411061, 1, "efce478dddd7acf0339deee1089b8004888d10826b748575a5a66ca2ed4d4096")
addappid(411066, 1, "e536f20060672973c44b73dab391fcac8659f945e04e0d273690dadf562f7521")
