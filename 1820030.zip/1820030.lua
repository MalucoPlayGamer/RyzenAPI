-- Lua provided by RyzenAPI
-- Game: Destructor Tanks

-- MAIN APPLICATION
addappid(1820030)
-- Game: addappid(1820030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820031, 1, "c3f6e37cb789b386d765038dd8b5271296b3bbc94c98798cd29937707919ccf3")
