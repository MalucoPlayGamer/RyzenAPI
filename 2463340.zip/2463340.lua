-- Lua provided by SkyAPI 
-- Game: Night Escape
addappid(2463340)
addappid(2463341, 1, "3047bde25825e1616c86a5f4c258a929b3564a44857708a1f3b767ab6900678e")
