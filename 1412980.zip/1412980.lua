-- Lua provided by RyzenAPI 
-- Game: Ironseed 25th Anniversary Edition
addappid(1412980)
addappid(1412981, 1, "d554d2a4ef9670aefa8edb3d45016bff8a47782be386b7cc04462fb3e51e5393")
addappid(1412983, 1, "102a55b92e22b725c1eeeb5ecbad07e9961c003539260603ea94adb36d773539")
