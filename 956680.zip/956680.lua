-- Lua provided by RyzenAPI
-- Game: 956680

-- MAIN APPLICATION
addappid(956680)
-- Game: addappid(956680)

-- MAIN APP DEPOTS / PACKAGES
addappid(956681, 1, "d5edcec382dadb9d728666ccaac26bfda1574f86050ec439152159df6eaca02e")
