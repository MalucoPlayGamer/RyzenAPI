-- Lua provided by RyzenAPI
-- Game: 263320

-- MAIN APPLICATION
addappid(263320)
addappid(325640)
-- Game: addappid(263320)

-- MAIN APP DEPOTS / PACKAGES
addappid(263321, 1, "77ee9a0acc680af01e68ee0dc0d85d28dd0591ada52da8ebdcb9d1e515adb40a")
addappid(263322, 1, "307d9a70c45700e15b0cb0c2a1306dfc1c11cbbb4e92d6c73423e8a1aca7ba3e")
addappid(263323, 1, "f62fe46e45201e3b0f234cbe19276fdbe1da05b564ae8beb53e5133755c045da")
