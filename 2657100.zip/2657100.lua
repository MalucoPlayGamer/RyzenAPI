-- Lua provided by RyzenAPI
-- Game: Teardown: The Greenwash Gambit

-- MAIN APPLICATION
addappid(2657100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657100,0,"5df4828df3d5422b27c221a29b70af3f0a032c14f71c632237047fb4b2ab2644")
