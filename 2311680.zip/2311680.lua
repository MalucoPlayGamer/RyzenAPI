-- Lua provided by RyzenAPI
-- Game: Magic Research

-- MAIN APPLICATION
addappid(2311680)
-- Game: addappid(2311680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311681, 1, "980e5164662fe2b2bae779db7205cd34a260af2510dc5a50c0f4c5ee8d638ee0")
