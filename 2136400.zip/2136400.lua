-- Lua provided by RyzenAPI
-- Game: Cycle of The Moon

-- MAIN APPLICATION
addappid(2136400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136401, 1, "f3adae70c5f939dd72bdef459e2b526ce9357e55d5690bc81d829664ed36ba4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
