-- Lua provided by SkyAPI 
-- Game: Cycle of The Moon
addappid(2136400)
addappid(2136401, 1, "f3adae70c5f939dd72bdef459e2b526ce9357e55d5690bc81d829664ed36ba4c")
