-- Lua provided by RyzenAPI
-- Game: Bhop up!

-- MAIN APPLICATION
addappid(2836830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2836831, 1, "10514ae7850301159cb074b57db3721c4c754bbad51a0dae93adcf8776bbeb15")

