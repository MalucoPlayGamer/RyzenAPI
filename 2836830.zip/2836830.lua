-- Lua provided by RyzenAPI
-- Game: Bhop up!

-- MAIN APPLICATION
addappid(2836830)
-- Game: addappid(2836830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836831, 1, "10514ae7850301159cb074b57db3721c4c754bbad51a0dae93adcf8776bbeb15")
