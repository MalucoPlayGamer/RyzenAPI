-- Lua provided by RyzenAPI
-- Game: The Way We All Go (2015)

-- MAIN APPLICATION
addappid(352610)

-- MAIN APP DEPOTS / PACKAGES
addappid(352611, 1, "58e74be7ee9fc19a7a1f667a2b82b12821e935a2ad5475f0236c8779b281b481")

