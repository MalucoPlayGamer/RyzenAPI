-- Lua provided by RyzenAPI
-- Game: AppID 862300

-- MAIN APPLICATION
addappid(862300)
-- Game: addappid(862300)

-- MAIN APP DEPOTS / PACKAGES
addappid(862301, 1, "7455b5994741dc3001028687db747cb20facffa90cdaee21d9ee9cb5b68b8ac6")
