-- Lua provided by RyzenAPI
-- Game: Recession

-- MAIN APPLICATION
addappid(510360)

-- MAIN APP DEPOTS / PACKAGES
addappid(510361,0,"37dfa5bed4d759550fdab4fc108291b0258f50b5841668d903b8bf6ec8f900ff")

