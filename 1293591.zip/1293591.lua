-- Lua provided by RyzenAPI
-- Game: addappid(1293591)

-- MAIN APPLICATION
addappid(1293591)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293591,0,"e445a7ba63a93d4efc537da21c50309365368145effcdec519e0ed49e757d5dc")
