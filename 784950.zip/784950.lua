-- Lua provided by RyzenAPI 
-- Game: SUPREMACY: WORLD WAR 3
addappid(784950)
addappid(784951, 1, "27ce2b7063f198a2017ebe8ef701422894571415688a9436388a8b591b1adf2f")
addappid(784953, 1, "d0417f6066c0fb2efa2038da230bb9dc9084c8c5c15440a5f8c5c5d41c417cf3")
