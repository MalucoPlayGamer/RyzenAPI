-- Lua provided by RyzenAPI
-- Game: Bao Bao's™ Cozy Laundromat

-- MAIN APPLICATION
addappid(3194550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194551, 1, "16661d9ff0a8a84f150a924cf803d245e08eb070fa8b43f29a17ed2088aa45c9")

