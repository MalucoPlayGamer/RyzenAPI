-- Lua provided by SkyAPI 
-- Game: Wyvern
addappid(1541710)
addappid(1541711, 1, "ba4ba8c4a15a52f3fae569834dc20a81f0fc6df0a053bb5be99a6777dd7561e1")
