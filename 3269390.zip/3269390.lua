-- Lua provided by RyzenAPI
-- Game: Game: CyberpunkXXX Demo

-- MAIN APPLICATION
addappid(3269390)
-- Game: addappid(3269390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269391, 1, "ce956a16aec75c835a1f5d6ac7afc376121c06092cf1ad707d8fd4e462626648")
