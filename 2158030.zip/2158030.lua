-- Lua provided by RyzenAPI
-- Game: RetroRealms Arcade

-- MAIN APPLICATION
addappid(2158030)
-- Game: addappid(2158030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158031, 1, "1b7f83b634d3a18d6065fe8e08b7ab1ef1ab0a7b4c9f50559d1c76bc8e366aa7")
addappid(2833010, 0, "98cab5b73f6763ecf4ad530ae81fe53aaa080556bb9172f6d58178d4f0cca57b")
addappid(2833020, 0, "4d132ba5032ccc35ae05629a48589103210fc2717c28f526bee0f9ba2473ea51")
addappid(2833030, 0, "71c26d2956eb00f6ade8718d41ebe482145460171cbc7f4d8f748d7916d011b7")
addappid(2833040, 0, "83ec1509ca078bbbae6c80d8bb9d306101a0f5278ae7bc717d7acf3cf05343ab")
