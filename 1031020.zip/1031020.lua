-- Lua provided by RyzenAPI
-- Game: Game: Hadaka Shitsuji - Naked Butlers

-- MAIN APPLICATION
addappid(1031020)
-- Game: addappid(1031020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031021, 1, "64a70d587e840338e91efc05c5cca4ba76200b4741d2a0680ce26dec907f4e27")
