-- Lua provided by RyzenAPI
-- Game: Insanity's Blade

-- MAIN APPLICATION
addappid(334190)
addappid(337260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(334191, 1, "17f4404f1c7a6f84b43b10d753bf4fa384ef2bb7a24f4c4918b5bd16f8d3cfc0")

