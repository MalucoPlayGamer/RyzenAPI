-- Lua provided by RyzenAPI
-- Game: addappid(334190)

-- MAIN APPLICATION
addappid(334190)
addappid(337260)

-- MAIN APP DEPOTS / PACKAGES
addappid(334191, 1, "17f4404f1c7a6f84b43b10d753bf4fa384ef2bb7a24f4c4918b5bd16f8d3cfc0")
