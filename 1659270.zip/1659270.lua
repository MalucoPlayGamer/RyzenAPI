-- Lua provided by RyzenAPI
-- Game: Sprite Sequence Chapter 2

-- MAIN APPLICATION
addappid(1659270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659271, 1, "b36fe7d4fa4c1da2f6545e401b2759dac5202b52b195bccaea6076752bc4353d")

