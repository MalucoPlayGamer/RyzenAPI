-- Lua provided by RyzenAPI
-- Game: Game: AppID 559940

-- MAIN APPLICATION
addappid(559940)
-- Game: addappid(559940)

-- MAIN APP DEPOTS / PACKAGES
addappid(559941, 1, "18ecc63daa5e0fbdf0b4920e557d72ad89707a6bca11c90af73efae73b134e6d")
