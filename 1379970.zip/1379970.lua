-- Lua provided by RyzenAPI 
-- Game: AppID 1379970
addappid(1379970)
addappid(1379971, 1, "f4f6abc0185086f92e868ff632af0697a8c3adeedf01e116b9de82bcb8a154a3")
