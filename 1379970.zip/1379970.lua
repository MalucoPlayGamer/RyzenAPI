-- Lua provided by RyzenAPI
-- Game: Solar System VR

-- MAIN APPLICATION
addappid(1379970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1379971, 1, "f4f6abc0185086f92e868ff632af0697a8c3adeedf01e116b9de82bcb8a154a3")
