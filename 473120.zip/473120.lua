-- Lua provided by RyzenAPI
-- Game: TRIZEAL Original Soundtrack

-- MAIN APPLICATION
addappid(473120)

-- MAIN APP DEPOTS / PACKAGES
addappid(473121, 1, "5b78df6c591a832c35f175545fc0f9da2e7d1b7e8da4e60471816a04e3b287fe")

