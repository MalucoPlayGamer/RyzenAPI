-- Lua provided by RyzenAPI
-- Game: Pyro VR

-- MAIN APPLICATION
addappid(586360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(586361, 1, "e770246e007b2e1bb6ea44b0520adec59fcad3baee95ca0c42db506e97b47a5f")

