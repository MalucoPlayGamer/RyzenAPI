-- Lua provided by RyzenAPI
-- Game: Pyro VR

-- MAIN APPLICATION
addappid(586360)

-- MAIN APP DEPOTS / PACKAGES
addappid(586361, 1, "e770246e007b2e1bb6ea44b0520adec59fcad3baee95ca0c42db506e97b47a5f")

