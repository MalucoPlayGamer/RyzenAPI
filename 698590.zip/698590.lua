-- Lua provided by RyzenAPI
-- Game: DemonsTier

-- MAIN APPLICATION
addappid(698590)

-- MAIN APP DEPOTS / PACKAGES
addappid(698592,0,"b50b555933250dfee6bdcf27543f2398e407f7bbc73c6bb56185abaef95ba023")

