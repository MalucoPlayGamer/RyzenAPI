-- Lua provided by RyzenAPI
-- Game: DemonsTier

-- MAIN APPLICATION
addappid(698590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(698592,0,"b50b555933250dfee6bdcf27543f2398e407f7bbc73c6bb56185abaef95ba023")

