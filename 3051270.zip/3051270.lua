-- Lua provided by RyzenAPI
-- Game: 3051270

-- MAIN APPLICATION
addappid(3051270)
-- Game: addappid(3051270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051271, 1, "481897b4c01f4707dcce465e947ba971c59d60af5b7ca30d048cbe888df00107")
