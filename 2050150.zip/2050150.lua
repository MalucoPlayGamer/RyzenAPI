-- Lua provided by RyzenAPI
-- Game: 2050150

-- MAIN APPLICATION
addappid(2050150)
-- Game: addappid(2050150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050151, 1, "d6adf8d43f280d7fd6e87bd9e49052dbbc67c082f0c5d319211d08ea2f008c46")
addappid(2050152, 1, "2ca9acc023a22c03eb430d3eacdd6c18e4540e3452ee1c2f9ec070ccfa5ce5a9")
