-- Lua provided by RyzenAPI
-- Game: Monument Soundtrack

-- MAIN APPLICATION
addappid(1237650)
-- Game: addappid(1237650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237651, 1, "99e9e44d8f92e6274b97c9adbbc2612142dedfdb88db55c64ce22afc49615d30")
