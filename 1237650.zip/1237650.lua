-- Lua provided by RyzenAPI 
-- Game: Monument Soundtrack
addappid(1237650)
addappid(1237651, 1, "99e9e44d8f92e6274b97c9adbbc2612142dedfdb88db55c64ce22afc49615d30")
