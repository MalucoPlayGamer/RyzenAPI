-- Lua provided by RyzenAPI
-- Game: Perfect Poses Demo

-- MAIN APPLICATION
addappid(2891470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891471, 1, "a70787f4c96d26a3be24ee4a4e7e775017ad49663a54dd5e4a7754305947ad25")

