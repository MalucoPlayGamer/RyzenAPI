-- Lua provided by RyzenAPI
-- Game: Game: BEAVER RAMPAGE

-- MAIN APPLICATION
addappid(3655380)
-- Game: addappid(3655380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655381, 1, "5bd63cd04f7503b6175e7b640fd49819083fe030b39dede5ec5535de6e0a56df")
