-- Lua provided by RyzenAPI
-- Game: Game: Hanna Must Run

-- MAIN APPLICATION
addappid(1926470)
-- Game: addappid(1926470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926471, 1, "4a241edff17979bab2f26939ff3c36cb834a06d06c802f67fcc4a1dbde204a96")
