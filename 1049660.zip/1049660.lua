-- Lua provided by RyzenAPI
-- Game: Game: stein.world

-- MAIN APPLICATION
addappid(1049660)
-- Game: addappid(1049660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049661, 1, "55cc9aa0ae0a982659fb766ddc1dd5d6f0669deb5b12e14d9ae68d13f80c70b3")
