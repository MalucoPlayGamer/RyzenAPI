-- Lua provided by RyzenAPI
-- Game: Hero of Fate - Darkness Land DLC

-- MAIN APPLICATION
addappid(2699720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699720,0,"00c7fcbf53a5f8985c3b3687530ec18157efba8a543cb0fc601549c0f4eabef9")

