-- Lua provided by RyzenAPI
-- Game: Evertree Inn

-- MAIN APPLICATION
addappid(565980)

-- MAIN APP DEPOTS / PACKAGES
addappid(565981, 1, "d7bab4164158dbefb0df5b707153188ea3a0064ac4c89cb47b0a89a9a371917e")
