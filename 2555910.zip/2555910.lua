-- Lua provided by RyzenAPI
-- Game: 2555910

-- MAIN APPLICATION
addappid(2555910)
-- Game: addappid(2555910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555911, 1, "5033ea08ad86e8b454a8fae1b3a089f29481de4f8ee8fd3c5971fefead403876")
