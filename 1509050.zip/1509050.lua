-- Lua provided by RyzenAPI
-- Game: Space of Retaliation

-- MAIN APPLICATION
addappid(1509050)
-- Game: addappid(1509050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509051, 1, "c201109e42e5a905fad4fb2e6709538667a093512f986669f9761ea4761f0dfd")
