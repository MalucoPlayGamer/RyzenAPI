-- Lua provided by RyzenAPI
-- Game: Woodlands

-- MAIN APPLICATION
addappid(646100)

-- MAIN APP DEPOTS / PACKAGES
addappid(646101, 1, "722a43cb26682b3b96d7c3e146c51fd599e147cf66b1ba89499dcb9c2b2736c4")
