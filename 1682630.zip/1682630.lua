-- Lua provided by RyzenAPI
-- Game: Big Boy Boxing Demo

-- MAIN APPLICATION
addappid(1682630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682631, 1, "4ae0d988eac490eeed3a63220b8182676bd1e1d8a0db38aa46c4ca6f249214fe")
