-- Lua provided by RyzenAPI
-- Game: The Last Ski Trip

-- MAIN APPLICATION
addappid(3852340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3852341, 1, "2be03621e222414cf61594fc9575d127ed9850c4f66bc1046fbb29f0ecce829f")

