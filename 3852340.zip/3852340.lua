-- Lua provided by RyzenAPI
-- Game: The Last Ski Trip

-- MAIN APPLICATION
addappid(3852340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3852341, 1, "2be03621e222414cf61594fc9575d127ed9850c4f66bc1046fbb29f0ecce829f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
