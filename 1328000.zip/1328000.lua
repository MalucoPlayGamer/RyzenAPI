-- Lua provided by RyzenAPI
-- Game: Zombie Shooting Star

-- MAIN APPLICATION
addappid(1328000)
-- Game: addappid(1328000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328001, 1, "5a085a918af4b12b7f5fe3c4810571f4fee6573715a63f3d328a6b8e4d872a7e")
