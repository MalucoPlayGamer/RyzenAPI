-- Lua provided by RyzenAPI
-- Game: Game: 万界之门

-- MAIN APPLICATION
addappid(1787920)
-- Game: addappid(1787920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787921, 1, "7a18211f4111d79b5a225b24cf54e3edda75076ecd887abbfc80dbcc67a6fea3")
