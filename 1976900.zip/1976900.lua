-- Lua provided by RyzenAPI
-- Game: MORSE Demo

-- MAIN APPLICATION
addappid(1976900)
-- Game: addappid(1976900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976901, 1, "8b78d69800ef69e1c2f82250d413acf798c3bceb69560966702078c9d6e50620")
