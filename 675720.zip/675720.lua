-- Lua provided by RyzenAPI 
-- Game: AppID 675720
addappid(675720)
addappid(675721, 1, "9c34ec8ab723b2367c28635a76d2afe13ecf66f4ca314b32303861d46a265032")
