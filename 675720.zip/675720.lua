-- Lua provided by RyzenAPI
-- Game: Game: AppID 675720

-- MAIN APPLICATION
addappid(675720)
-- Game: addappid(675720)

-- MAIN APP DEPOTS / PACKAGES
addappid(675721, 1, "9c34ec8ab723b2367c28635a76d2afe13ecf66f4ca314b32303861d46a265032")
