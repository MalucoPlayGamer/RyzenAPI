-- Lua provided by RyzenAPI
-- Game: 539290

-- MAIN APPLICATION
addappid(539290)
-- Game: addappid(539290)

-- MAIN APP DEPOTS / PACKAGES
addappid(539291, 1, "2abea6fdff66cf163c08b9c1e248fad457023f1611aa0be9a5603eaf6009fdda")
