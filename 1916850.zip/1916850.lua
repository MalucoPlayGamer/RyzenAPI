-- Lua provided by RyzenAPI
-- Game: Game: Doomed to Hell

-- MAIN APPLICATION
addappid(1916850)
-- Game: addappid(1916850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916851, 1, "8770056e0219938535a169280af1d4a47cdcae72721a2761879715b74ca36a7b")
