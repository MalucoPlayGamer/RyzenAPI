-- Lua provided by RyzenAPI 
-- Game: AppID 1132020
addappid(1132020)
addappid(1132021, 1, "d61ebdba53ff144665896a05815ec5d1c85d984fa6d818beb087b01b5d179ab4")
