-- Lua provided by RyzenAPI
-- Game: Game: AppID 3214890

-- MAIN APPLICATION
addappid(3214890)
-- Game: addappid(3214890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214891, 1, "27cfd4d58d01cd0acd26295df65dcac165b87a3c77030292fe3b2b5b36023182")
