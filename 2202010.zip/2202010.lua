-- Lua provided by RyzenAPI
-- Game: Neon Ascending

-- MAIN APPLICATION
addappid(2202010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202011, 1, "f4f4b2b7a7bdabc73e9cee7d04ba520204385638c86d2a89753f6eea6640eb08")
