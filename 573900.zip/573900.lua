-- Lua provided by RyzenAPI
-- Game: addappid(573900)

-- MAIN APPLICATION
addappid(573900)

-- MAIN APP DEPOTS / PACKAGES
addappid(573900,0,"4355d154c80000fe9dd53f3d7cee8e668d2f8b838bdaa4fd327f784a740cab10")
