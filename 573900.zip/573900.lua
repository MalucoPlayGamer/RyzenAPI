-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(573900)
addappid(573900,0,"4355d154c80000fe9dd53f3d7cee8e668d2f8b838bdaa4fd327f784a740cab10")
-- setManifestid(573900,"2038154678640562523")