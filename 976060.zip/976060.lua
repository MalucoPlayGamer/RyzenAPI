-- Lua provided by RyzenAPI
-- Game: Game: In The Ember 余烬之中

-- MAIN APPLICATION
addappid(976060)
-- Game: addappid(976060)

-- MAIN APP DEPOTS / PACKAGES
addappid(976061, 1, "5ff10e310861134127b5806551d7c0a3fdd8adb5129759e6fbf0f0f50b37dfb9")
