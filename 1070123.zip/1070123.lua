-- Lua provided by RyzenAPI
-- Game: 1070123

-- MAIN APPLICATION
addappid(1070123)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070123,0,"a23bcf592b4cbcd307eab3ae80dccf139983ec254dea06708fb4dd85ee549221")
