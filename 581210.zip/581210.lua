-- Lua provided by RyzenAPI 
-- Game: AppID 581210
addappid(581210)
addappid(581211, 1, "0b02672e20a1b873a97bdbc7419218cc01940e351e6598c50cd328edc93495b3")
