-- Lua provided by RyzenAPI 
-- Game: Skybreakers
addappid(2439710)
addappid(2439711, 1, "37bd38d52e90051646f6174b02816a28b0cacf32ccff245fe5b9edada3dd3c0c")
addappid(3021030, 0, "dfc50658b3a64bb88de1c227206d8001f0429a2e5a3e42fb204260d0b3963867")
