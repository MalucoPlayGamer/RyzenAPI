-- Lua provided by RyzenAPI
-- Game: Shrouded Tales: Revenge of Shadows Collector's Edition

-- MAIN APPLICATION
addappid(647940)

-- MAIN APP DEPOTS / PACKAGES
addappid(647941,0,"34efe765ab9fd1f57813dcab2a6429bd4205886b963806069fe020961e6aceed")

