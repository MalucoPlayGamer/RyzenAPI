-- Lua provided by RyzenAPI
-- Game: The First Odyssey

-- MAIN APPLICATION
addappid(1846510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846511, 1, "cfb1899aa5e1036f4cbfc0ee70ff437361cabb4fe6010640ed1039f82b614c4b")
