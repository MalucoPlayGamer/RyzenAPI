-- Lua provided by RyzenAPI
-- Game: Game: AppID 3365580

-- MAIN APPLICATION
addappid(3365580)
-- Game: addappid(3365580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365581, 1, "e018f152ffae75195d8c0ea4d29593b50e961fb2043258a9410c3872a94ff740")
