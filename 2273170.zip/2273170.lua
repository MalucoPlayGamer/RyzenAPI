-- Lua provided by SkyAPI 
-- Game: AppID 2273170
addappid(2273170)
addappid(2273171, 1, "06f1ddaaea147e89f83ed34175d6e5e69ea6464fa98d4a631737c6fc8a1bc973")
