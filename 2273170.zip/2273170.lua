-- Lua provided by RyzenAPI
-- Game: Gaia Trek

-- MAIN APPLICATION
addappid(2273170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273171, 1, "06f1ddaaea147e89f83ed34175d6e5e69ea6464fa98d4a631737c6fc8a1bc973")

