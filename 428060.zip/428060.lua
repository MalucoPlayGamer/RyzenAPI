-- Lua provided by RyzenAPI
-- Game: Millia -The ending-

-- MAIN APPLICATION
addappid(428060)

-- MAIN APP DEPOTS / PACKAGES
addappid(428061, 1, "fe62f09ace89bde32b82fa01f8b4e87391a7f0c3d7a4741c6cb84e3c8c4e7568")
