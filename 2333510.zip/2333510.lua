-- Lua provided by RyzenAPI
-- Game: Blade Prince Academy

-- MAIN APPLICATION
addappid(2333510)
-- Game: addappid(2333510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333511, 1, "61fa4a9a958561c6f5d9908e14b8d48b51f9b5b647a4f679ffd76912bfd8da9f")
