-- Lua provided by RyzenAPI
-- Game: Sentience: The Android's Tale

-- MAIN APPLICATION
addappid(635850)

-- MAIN APP DEPOTS / PACKAGES
addappid(635851, 1, "9bb7917529d7840360b1a963701512254612422e7df80650ddb7df5aba804ac5")
addappid(635852, 1, "ba0e759fd0a56548d1baf1e16c0ea5fc97902159fc72f0eb7f896262fab76f22")

