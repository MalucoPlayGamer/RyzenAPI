-- Lua provided by RyzenAPI
-- Game: addappid(1447470)

-- MAIN APPLICATION
addappid(1447470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447471, 1, "ac6232e56c955a94f41a2fedc3f46c48cb7fefef6693941e72d641dff7129682")
