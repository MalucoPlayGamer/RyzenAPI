-- Lua provided by RyzenAPI
-- Game: Appointment with FEAR (Standalone)

-- MAIN APPLICATION
addappid(316140)

-- MAIN APP DEPOTS / PACKAGES
addappid(316143,0,"648236d57b99441d012f60ad1f25254dd08351db4fca563f81e4bd21e9019a46")

