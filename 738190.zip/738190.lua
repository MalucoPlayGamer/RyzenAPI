-- Lua provided by RyzenAPI
-- Game: Morth

-- MAIN APPLICATION
addappid(738190)
-- Game: addappid(738190)

-- MAIN APP DEPOTS / PACKAGES
addappid(738192,0,"7a50f2f67d2560d428d396acdd6a4976b4e7cb4634a7a792b200027ab1c73b03")
