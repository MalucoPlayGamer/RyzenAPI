-- Lua provided by RyzenAPI
-- Game: 3328700

-- MAIN APPLICATION
addappid(3328700)
-- Game: addappid(3328700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328701, 1, "4fe2509b425cdb965dee5cd0f6a1fa67b3acfeef7f4c2398946046857dc491ff")
