-- Lua provided by RyzenAPI
-- Game: 1421790

-- MAIN APPLICATION
addappid(1421790)
addappid(1421792)
addappid(1421793)
-- Game: addappid(1421790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421794,0,"61beafbf14a6e63899408d18da0b16c7b0134c16fd0d7b2f33cf8a917c2d3c8a")
