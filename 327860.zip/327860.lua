-- Lua provided by SkyAPI 
-- Game: Salt
addappid(327860)
addappid(327861, 1, "a049082839d1dce664d4b5a546672635d60906de0305b8d3d1ea8285d19c8ea6")
addappid(327862, 1, "8e3c257f6cbbbc401c4fe79ae36a130de4d3e1b55ed5aa0c94d58914da4e6a84")
addappid(327863, 1, "5cf37e16c28419f2d1e1e26c9aabc6420a0a315d76d9c72a4a95da42184498fe")
