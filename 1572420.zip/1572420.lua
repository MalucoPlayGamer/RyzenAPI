-- Lua provided by RyzenAPI
-- Game: Leenie Boog

-- MAIN APPLICATION
addappid(1572420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1572421, 1, "2696ac20d407565b12833112007030ee2b710a89301a916b205b5262a9883f72")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
