-- Lua provided by RyzenAPI 
-- Game: Leenie Boog
addappid(1572420)
addappid(1572421, 1, "2696ac20d407565b12833112007030ee2b710a89301a916b205b5262a9883f72")
