-- Lua provided by RyzenAPI
-- Game: Game: Leenie Boog

-- MAIN APPLICATION
addappid(1572420)
-- Game: addappid(1572420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1572421, 1, "2696ac20d407565b12833112007030ee2b710a89301a916b205b5262a9883f72")
