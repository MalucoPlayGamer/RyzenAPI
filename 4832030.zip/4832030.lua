-- 4832030's Lua and Manifest Created by Hubcap Manifest
-- Big Golden Rock
-- Created: August 05, 2026 at 13:40:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4832030) -- Big Golden Rock
-- MAIN APP DEPOTS
addappid(4832031, 1, "e14ecd795fdfc154d4d8f6448f0576cf249c37bec0a3987dd5bbc1ef8ba3bff8") -- Depot 4832031
setManifestid(4832031, "1169154835636170648", 144536958)