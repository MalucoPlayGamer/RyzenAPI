-- Lua provided by RyzenAPI
-- Game: Big Golden Rock

-- MAIN APPLICATION
addappid(4832030) -- Big Golden Rock

-- MAIN APP DEPOTS / PACKAGES
addappid(4832031, 1, "e14ecd795fdfc154d4d8f6448f0576cf249c37bec0a3987dd5bbc1ef8ba3bff8") -- Depot 4832031

