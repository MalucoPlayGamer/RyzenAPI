-- Lua provided by RyzenAPI
-- Game: King Bullseye: Headshot Training

-- MAIN APPLICATION
addappid(1600870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600871, 1, "346af9dea17d9ee0b61f1a1319311543f5cb24cd74b7e342cc8b78455c58cfbc")

