-- Lua provided by RyzenAPI
-- Game: Merry Snowballs

-- MAIN APPLICATION
addappid(567730)

-- MAIN APP DEPOTS / PACKAGES
addappid(567731, 1, "224a6d608244328ffe96ee75b920f0273513182cd7f2c811f08c790366aac67e")
