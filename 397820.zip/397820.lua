-- Lua provided by RyzenAPI
-- Game: Let's Sing 2016

-- MAIN APPLICATION
addappid(397820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(397821, 1, "573ed63006763512b0b889cde36cf9a53ba52fd74168e913d9829edc3e2f8fc2")

