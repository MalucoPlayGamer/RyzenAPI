-- Lua provided by RyzenAPI
-- Game: hack_me 2

-- MAIN APPLICATION
addappid(602890)

-- MAIN APP DEPOTS / PACKAGES
addappid(602891, 1, "60ddee87b70681a25cbd47dedea08faf24e994f3a2c9ed7d38df6dcdc0cfb3c8")
addappid(608590, 0, "9a05715b098da00919dd673a88e375353db27b07ebd7991957dcd5c0364c512e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
