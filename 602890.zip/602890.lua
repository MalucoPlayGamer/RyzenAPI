-- Lua provided by RyzenAPI
-- Game: hack_me 2

-- MAIN APPLICATION
addappid(602890)

-- MAIN APP DEPOTS / PACKAGES
addappid(602891, 1, "60ddee87b70681a25cbd47dedea08faf24e994f3a2c9ed7d38df6dcdc0cfb3c8")
addappid(608590, 0, "9a05715b098da00919dd673a88e375353db27b07ebd7991957dcd5c0364c512e")

