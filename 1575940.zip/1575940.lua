-- Lua provided by RyzenAPI
-- Game: Sins of a Solar Empire II

-- MAIN APPLICATION
addappid(1575940)
addappid(3195270)
addappid(3195280)
addappid(3195290)
addappid(3195300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1575941, 1, "4e2e571147e77d0cadda071bc6cb8aea54d2c0e2c076b1dbf4d5fea94482ff09")
addappid(1575942, 1, "cc619e6e9c7f306decb6005a71df177bcb1d9980484676461f25cbf4bcc52e76")
addappid(1575943, 1, "8fa4ce7002d306e317d40c1629f5a14edfc0d578ce1a253a52a6cca27e4b35a4")

