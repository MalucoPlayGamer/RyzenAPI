-- Lua provided by RyzenAPI
-- Game: Game: AppID 1575940

-- MAIN APPLICATION
addappid(1575940)
-- Game: addappid(1575940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575941, 1, "4e2e571147e77d0cadda071bc6cb8aea54d2c0e2c076b1dbf4d5fea94482ff09")
addappid(1575942, 1, "cc619e6e9c7f306decb6005a71df177bcb1d9980484676461f25cbf4bcc52e76")
addappid(1575943, 1, "8fa4ce7002d306e317d40c1629f5a14edfc0d578ce1a253a52a6cca27e4b35a4")
