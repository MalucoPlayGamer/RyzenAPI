-- Lua provided by RyzenAPI
-- Game: Altarium

-- MAIN APPLICATION
addappid(2524700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524701, 1, "c88e2327ad35279cdfb64c7bc12777dd70bce87b30d350140da67097c0302bfd")

