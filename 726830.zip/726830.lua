-- Lua provided by SkyAPI 
-- Game: AppID 726830
addappid(726830)
addappid(726831, 1, "f63db3e6120368269cb33ee5999825d06387dc59362702181c88d06daa8a617d")
