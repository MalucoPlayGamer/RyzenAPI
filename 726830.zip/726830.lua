-- Lua provided by RyzenAPI
-- Game: Game: AppID 726830

-- MAIN APPLICATION
addappid(726830)
-- Game: addappid(726830)

-- MAIN APP DEPOTS / PACKAGES
addappid(726831, 1, "f63db3e6120368269cb33ee5999825d06387dc59362702181c88d06daa8a617d")
