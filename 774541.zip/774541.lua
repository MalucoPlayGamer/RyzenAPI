-- Lua provided by RyzenAPI
-- Game: Species: Artificial Life, Real Evolution

-- MAIN APPLICATION
addappid(774541)

-- MAIN APP DEPOTS / PACKAGES
addappid(774542, 1, "503f8fea47bd724c7450f9b4afb8e52c060a7cbfcffc7c776887258f71502999")
addappid(774543, 1, "918169d8bd0e7f2317b573bfe3920d1ac379d111dc5778b891638604159c8e21")
addappid(774544, 1, "2c7379a1aebe781d7ef960a2a5f8574c8c383d63212e8f8087a29134a9c6014d")

