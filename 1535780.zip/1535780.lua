-- Lua provided by RyzenAPI
-- Game: Imp of the Sun

-- MAIN APPLICATION
addappid(1535780)
-- Game: addappid(1535780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535781, 1, "6a1c3a7ae9e7ab0d4a13509c245534774857c9473615e7458ab6ebffd25ed527")
