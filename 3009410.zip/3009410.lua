-- Lua provided by RyzenAPI
-- Game: 3009410

-- MAIN APPLICATION
addappid(3009410)
-- Game: addappid(3009410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009411, 1, "2e1cab5956f9f43d416a8df5ce4b29a5d47ec3c7d3663c4f50d05f0a4472bfa4")
