-- Lua provided by RyzenAPI
-- Game: addappid(437030)

-- MAIN APPLICATION
addappid(437030)

-- MAIN APP DEPOTS / PACKAGES
addappid(437031, 1, "c5ba212350c667e9e824b8ce07df48b41dd5d5fcc609b3f51575c058a96e5448")
addappid(437032, 1, "ff8d595b6303d11093be33dc08411e2a9a75dffb9eb1063d5ad2e9f879fb5901")
