-- Lua provided by RyzenAPI
-- Game: phoToq

-- MAIN APPLICATION
addappid(1798970)
-- Game: addappid(1798970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798971, 1, "afc75aec94d68c4c2c419188f1df853b2cc5ab74b24454d40996c0717fb35148")
