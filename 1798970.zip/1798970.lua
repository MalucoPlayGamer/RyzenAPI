-- Lua provided by SkyAPI 
-- Game: phoToq
addappid(1798970)
addappid(1798971, 1, "afc75aec94d68c4c2c419188f1df853b2cc5ab74b24454d40996c0717fb35148")
