-- Lua provided by RyzenAPI
-- Game: Game: Hollow Floor

-- MAIN APPLICATION
addappid(2815150)
-- Game: addappid(2815150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815151, 1, "acaed58da21c80f3ee0beae1c073fe4bc330872872dabcba9e69dfb80c1b90ae")
