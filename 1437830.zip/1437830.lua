-- Lua provided by SkyAPI 
-- Game: AppID 1437830
addappid(1437830)
addappid(1437831, 1, "6e79befc0ff46a5b527c162ee27f225e0018b5f61b769856f80e3be9f2d1cbaf")
addappid(1437832, 1, "1cc5f702306a6fc8842e9bf37f225f70cc3e1ef059f0c077b34541fd83f41013")
