-- Lua provided by RyzenAPI
-- Game: 1947360

-- MAIN APPLICATION
addappid(1947360)
-- Game: addappid(1947360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947361, 1, "7457d9a866dfee94eb5210ed8ee9502513ff31a752f5be5a86ed4cbf7edc5a90")
