-- Lua provided by RyzenAPI
-- Game: Game: Delta Force — Black Hawk Down: Team Sabre

-- MAIN APPLICATION
addappid(32680)
-- Game: addappid(32680)

-- MAIN APP DEPOTS / PACKAGES
addappid(32681, 1, "d1a9454fed8c4add3a2d9302d095813436850a9d9ccd1f8c4cf1c7260de49920")
