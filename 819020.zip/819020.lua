-- Lua provided by RyzenAPI
-- Game: AppID 819020

-- MAIN APPLICATION
addappid(819020)

-- MAIN APP DEPOTS / PACKAGES
addappid(819021, 1, "ec9e19564d0aec8730421340231c83ae821404a166da55fb92991871d4421db4")
addappid(1060910, 0, "4a45a3b50bcad5e21dea5382aa42db77de849c879706411920c656c4c2b8c415")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
