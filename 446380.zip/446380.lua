-- Lua provided by RyzenAPI 
-- Game: Sophie's Curse
addappid(446380)
addappid(446381, 1, "0ebc7f9285d348e7211fa832b59b64f55d7e5bbb04d19d540886aca3595ffdb1")
addappid(446382, 1, "414b5a074b39bc822575d3074088468bd24c7f467466bbaae280d1654669fb2b")
