-- Lua provided by RyzenAPI
-- Game: AppID 348820

-- MAIN APPLICATION
addappid(348820)

-- MAIN APP DEPOTS / PACKAGES
addappid(348821, 1, "b88f1d77c5d7cb7a2bcf5ec641adf4fd912cb3f3aa56fc1654d6830f7477a6e1")
addappid(348822, 1, "172f374b35eb42c687d3cf00272f078238e65c8e5946f417696449059cf1c80e")
addappid(348823, 1, "8e6a2951c0d5059049b20d16301d722b22fd74e00b133c3ed9304783dcac3bb9")
addappid(348824, 1, "3a8e09d7ac718c8c8f9e4da43310748368025e9b9bb06293ab94c65b8330c4dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
