-- Lua provided by SkyAPI 
-- Game: Tournament of Beans
addappid(1951050)
addappid(1951051, 1, "3d9e1247e8b438469aff87bb0ac2601ffca5695611da332a3e46a547b99f38be")
