-- Lua provided by RyzenAPI
-- Game: Tournament of Beans

-- MAIN APPLICATION
addappid(1951050)
-- Game: addappid(1951050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951051, 1, "3d9e1247e8b438469aff87bb0ac2601ffca5695611da332a3e46a547b99f38be")
