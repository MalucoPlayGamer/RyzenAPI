-- Lua provided by RyzenAPI
-- Game: Skull Ball Heroes

-- MAIN APPLICATION
addappid(228985)
addappid(228986)
addappid(228990)
addappid(521330)

-- MAIN APP DEPOTS / PACKAGES
addappid(521332,0,"3c2c0f86805077121587b69dba1476d4ad0fda495d3a080e29a41f6dfc1bcac2")
addappid(521333,0,"aeb1499378535267970eaa204ea9c7dcc383e11a003088a34e6448f67ce2e278")
addappid(521334,0,"039e3c7d3636a4c2e1f4aca215af0c95c6dc143437b6100291242dd8f5525ed9")
