-- Lua provided by RyzenAPI
-- Game: Game: AppID 2236580

-- MAIN APPLICATION
addappid(2236580)
-- Game: addappid(2236580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236581, 1, "270f7177c5beb0f03c1de03583d3f3320756e3a4b9e70d05e677a10209073a94")
