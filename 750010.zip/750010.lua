-- Lua provided by RyzenAPI
-- Game: Combat Tested

-- MAIN APPLICATION
addappid(750010) -- Combat Tested

-- MAIN APP DEPOTS / PACKAGES
addappid(750012, 1, "e2ca2cd464ad152ca9e519669acc5b7e926ab4fa0b14403b4016cfc9a398ef51") -- Combat Tested RELEASE Depot

