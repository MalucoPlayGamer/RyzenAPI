-- Lua provided by RyzenAPI
-- Game: WTC : Love's Labour's Lost

-- MAIN APPLICATION
addappid(1981690)
addappid(2769840)
-- Game: addappid(1981690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981691, 1, "c8aa9ae6eee7fa1f517e3ccbb7cce8f2584701c99fa8d7b2f7f80ade8363ca23")
