-- Lua provided by RyzenAPI
-- Game: 815450

-- MAIN APPLICATION
addappid(815450)
-- Game: addappid(815450)

-- MAIN APP DEPOTS / PACKAGES
addappid(815451, 1, "045669b30602c8b24c0de75ce45d5e2848533ccef8976e04338a688dd143741e")
