-- Lua provided by SkyAPI 
-- Game: Gerda: A Flame in Winter
addappid(1771360)
addappid(1771361, 1, "3dd639075cab70d752083e27eea4552c3086948b7f1b8fbc6a5ef2844a4520f4")
addappid(2139530, 0, "518e2fb4b13c6b82b2f0334b063e3dd2ad10e7a3f6243728488434dcfa918a03")
