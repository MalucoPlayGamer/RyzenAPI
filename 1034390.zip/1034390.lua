-- Lua provided by RyzenAPI
-- Game: addappid(1034390)

-- MAIN APPLICATION
addappid(1034390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034391, 1, "69f66f7b4fd05ed9671b29a7e06e58291f2e07e4ebeb4980ba8feb6028bdd8c0")
addappid(1034394, 1, "9295831253e126f0824e652e01e030cb9beede453e0ec7b7782a4f2dbe5cfc12")
