-- Lua provided by RyzenAPI 
-- Game: Heartbreak Hotel
addappid(2155060)
addappid(2155061, 1, "3d7ac3b4d86b2d4c98abb60237ce65b01940cf47881e32f05cf8bce4f93a592a")
