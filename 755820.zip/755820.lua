-- Lua provided by RyzenAPI
-- Game: One Against The Galaxy

-- MAIN APPLICATION
addappid(755820)

-- MAIN APP DEPOTS / PACKAGES
addappid(755821, 1, "54e220b6dba76eb49e70404dd3cdf97ebb0775cc331ce681a6138493bd3751b5")
