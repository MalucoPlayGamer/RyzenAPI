-- Lua provided by RyzenAPI
-- Game: Game: Gomoku Let's Go

-- MAIN APPLICATION
addappid(1555400)
-- Game: addappid(1555400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555401, 1, "dc6a292304c4f56cffcee8678002ba2b23646843eaa8388a9216a2e6d9ff8c14")
