-- Lua provided by SkyAPI 
-- Game: PinballAdventure
addappid(1803380)
addappid(1803381, 1, "1dcc36c6c1503e493dee30a7819c5d22cf7e8f48193031904486b961a2c4582f")
