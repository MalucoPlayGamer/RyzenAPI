-- Lua provided by RyzenAPI
-- Game: Game: PinballAdventure

-- MAIN APPLICATION
addappid(1803380)
-- Game: addappid(1803380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803381, 1, "1dcc36c6c1503e493dee30a7819c5d22cf7e8f48193031904486b961a2c4582f")
