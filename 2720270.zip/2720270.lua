-- Lua provided by RyzenAPI
-- Game: addappid(2720270)

-- MAIN APPLICATION
addappid(2720270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720271, 1, "4764ea6ac75438e2559847b38bcf52db2b9b8ee2dc5fa3f4e7b2ffb669e7aa9a")
