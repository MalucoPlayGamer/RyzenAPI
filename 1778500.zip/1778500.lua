-- Lua provided by SkyAPI 
-- Game: Dee's Nuts
addappid(1778500)
addappid(1778501, 1, "c3781db8fed20d70494bc9bc3547ad3e834cc4f0725b68c0bcb2ddaa8ea425d8")
