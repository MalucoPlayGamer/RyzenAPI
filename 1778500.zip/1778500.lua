-- Lua provided by RyzenAPI
-- Game: Dee's Nuts

-- MAIN APPLICATION
addappid(1778500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778501, 1, "c3781db8fed20d70494bc9bc3547ad3e834cc4f0725b68c0bcb2ddaa8ea425d8")
