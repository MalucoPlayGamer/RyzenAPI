-- Lua provided by RyzenAPI
-- Game: Duty in the Forest

-- MAIN APPLICATION
addappid(1561480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561481, 1, "f0edddcdfbb41306483ff3f73d6d7c26d5b4495477b393f636dad1bae4cc5b91")

