-- Lua provided by RyzenAPI
-- Game: Duty in the Forest

-- MAIN APPLICATION
addappid(1561480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1561481, 1, "f0edddcdfbb41306483ff3f73d6d7c26d5b4495477b393f636dad1bae4cc5b91")

