-- Lua provided by RyzenAPI
-- Game: Game: Color Party

-- MAIN APPLICATION
addappid(898380)
-- Game: addappid(898380)

-- MAIN APP DEPOTS / PACKAGES
addappid(898381, 1, "0ef33b53c21c3c3553e3bc2ea61a3fd10d498f656595475aea591ea3ca696e0e")
