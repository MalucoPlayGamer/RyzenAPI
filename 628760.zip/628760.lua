-- Lua provided by RyzenAPI
-- Game: The Adventurer - Episode 1: Beginning of the End

-- MAIN APPLICATION
addappid(628760)

-- MAIN APP DEPOTS / PACKAGES
addappid(628761, 1, "8b832fe9898e41d845a945d7ba2dd747db6e6b557ca407b3bc75a3a80b2e9b78")

