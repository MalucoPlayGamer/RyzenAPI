-- Lua provided by SkyAPI 
-- Game: AppID 628760
addappid(628760)
addappid(628761, 1, "8b832fe9898e41d845a945d7ba2dd747db6e6b557ca407b3bc75a3a80b2e9b78")
