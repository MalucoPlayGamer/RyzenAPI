-- Lua provided by RyzenAPI
-- Game: Fun Hospital

-- MAIN APPLICATION
addappid(829420)

-- MAIN APP DEPOTS / PACKAGES
addappid(829421, 1, "b48977f7983b3d69c250073b4c1cb7b258cd33fcb91419f7461a96e976588fcb")
addappid(829422, 1, "9aad6caf3b710a4178579a1734cc8c8267418169c2935f3f4b8d98d25d4de929")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
