-- Lua provided by RyzenAPI
-- Game: Hide and Seek

-- MAIN APPLICATION
addappid(1010860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010861, 1, "9d15830d6a4ae4a76d0eada832d1a4eec687b3367b2186c9044031f45cbdc095")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
