-- Lua provided by RyzenAPI
-- Game: Thrust & Shoot : Flight School

-- MAIN APPLICATION
addappid(663100)

-- MAIN APP DEPOTS / PACKAGES
addappid(663101,0,"88dded1d9d8f6da7ce3317c331895e7b921acd9d0c02db97e24e21726b92d22e")

