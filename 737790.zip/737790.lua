-- Lua provided by RyzenAPI
-- Game: 737790

-- MAIN APPLICATION
addappid(737790)
addappid(737791)

-- MAIN APP DEPOTS / PACKAGES
addappid(737790,0,"fed826cb44a175c388883cc36fda12b446e25276c70faee361d440d687fd0298")

