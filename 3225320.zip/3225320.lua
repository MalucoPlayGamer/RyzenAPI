-- Lua provided by RyzenAPI
-- Game: Ocean Survivors

-- MAIN APP DEPOTS / PACKAGES
addappid(3225320, 1, "d4d571ac48f425d920d2d9a2f8d842a0375ad7925ad68bb73220ccdbbe024199") -- Ocean Survivors
addappid(3225321, 1, "30af26836caaa93a0debc841de6086ccdef5cebcf05f2ee66ff60fd942bcb78d") -- Depot 3225321

