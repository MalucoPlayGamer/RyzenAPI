-- 3225320's Lua and Manifest Created by Hubcap Manifest
-- Ocean Survivors
-- Created: August 03, 2026 at 22:43:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3225320, 1, "d4d571ac48f425d920d2d9a2f8d842a0375ad7925ad68bb73220ccdbbe024199") -- Ocean Survivors
-- MAIN APP DEPOTS
addappid(3225321, 1, "30af26836caaa93a0debc841de6086ccdef5cebcf05f2ee66ff60fd942bcb78d") -- Depot 3225321
setManifestid(3225321, "6499069691648552452", 672570880)