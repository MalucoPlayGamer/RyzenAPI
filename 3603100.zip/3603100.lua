-- Lua provided by RyzenAPI
-- Game: Lost Luminosity

-- MAIN APPLICATION
addappid(3603100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3603101, 1, "8be282bbbc91e8869dee515d0188aa064b700585de41c71a4c56d899dbf40a35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
