-- Lua provided by RyzenAPI
-- Game: addappid(3603100)

-- MAIN APPLICATION
addappid(3603100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3603101, 1, "8be282bbbc91e8869dee515d0188aa064b700585de41c71a4c56d899dbf40a35")
