-- Lua provided by RyzenAPI
-- Game: Crawling Angels

-- MAIN APPLICATION
addappid(3958640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3958641,0,"968bfd8891190f7b8589b30d193f091d74b54faa729dd20fbc0ea386b0b6b205")

