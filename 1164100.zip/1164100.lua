-- Lua provided by RyzenAPI
-- Game: 1164100

-- MAIN APPLICATION
addappid(1164100)
-- Game: addappid(1164100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164101, 1, "be6c06724be5f7ffb40b9ac24bfba8417ce183aa6e6f442df2e42e15950ff99b")
