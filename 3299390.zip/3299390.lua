-- Lua provided by SkyAPI 
-- Game: 寻仙问道 Demo
addappid(3299390)
addappid(3299391, 1, "efe83d4e6b1278eb4fdf7a04a8f477215b70077616813c1623bff498b9cc85d8")
