-- Lua provided by RyzenAPI
-- Game: 548280

-- MAIN APPLICATION
addappid(548280)
-- Game: addappid(548280)

-- MAIN APP DEPOTS / PACKAGES
addappid(548282,0,"e3458c5adf13400783482b19e9bfdf65d2eaa655ccb15995187ced58d66ddbe5")
addappid(548283,0,"02f1c2635c2a95e4c68baca3b496cb23085c75f2fcb458a28a14665affb79295")
