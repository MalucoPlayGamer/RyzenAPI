-- Lua provided by RyzenAPI
-- Game: Really Big Sky

-- MAIN APPLICATION
addappid(201570)
addappid(228982)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228990)
addappid(229001)
addappid(229002)
addappid(229003)
addappid(229004)
addappid(229010)
addappid(229011)
addappid(229012)
-- Game: addappid(201570)

-- MAIN APP DEPOTS / PACKAGES
addappid(201571, 1, "49b68ef461e25d17f203538b0c8763d080cf60a8135df17097e78ca0e617ad16")
