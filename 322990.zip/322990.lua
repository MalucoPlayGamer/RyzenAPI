-- Lua provided by RyzenAPI
-- Game: Game: Black Viper: Sophia's Fate

-- MAIN APPLICATION
addappid(322990)
-- Game: addappid(322990)

-- MAIN APP DEPOTS / PACKAGES
addappid(322991, 1, "293f211ce06e63711214b7bb79bca976b87ea931d6475d35237ab24882d0e610")
addappid(322992, 1, "9522ff0e92160e66dd334a8c940b702b463940c100e1f48cd70709a63a8e111c")
