-- Lua provided by RyzenAPI
-- Game: 597040

-- MAIN APPLICATION
addappid(597040)
-- Game: addappid(597040)

-- MAIN APP DEPOTS / PACKAGES
addappid(597041, 1, "1cadb00adca7609594a6d38959e0a9cedfda130a3b8ced6d206666807f28931b")
