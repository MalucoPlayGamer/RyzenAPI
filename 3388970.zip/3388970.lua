-- Lua provided by RyzenAPI
-- Game: 无用之人：登神长阶 Playtest

-- MAIN APPLICATION
addappid(3388970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388971, 1, "eae6ec86ed23e515cfae197332f0ceaea6283fe337479c1e17b0cac23a76408b")

