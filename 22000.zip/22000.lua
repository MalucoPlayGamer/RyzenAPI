-- Lua provided by RyzenAPI
-- Game: 22000

-- MAIN APPLICATION
addappid(22000)
-- Game: addappid(22000)

-- MAIN APP DEPOTS / PACKAGES
addappid(22001, 1, "259e5302914bd25c22a8214fbe7f3d3db7671fe7bfe2427a10ad5077a2e993e0")
addappid(22002, 1, "2c5293d636ad6f4b4aad97c624f1b77ac9f9ddb91ab1d837f70f57ebd58263aa")
addappid(22003, 1, "93c8bbb89845b3eb08ee8528267fddbb1b0d60757135ee53834277d9975dee89")
