-- Lua provided by RyzenAPI
-- Game: Crypt of the NecroDancer: AMPLIFIED OST - FamilyJules and A_Rival

-- MAIN APPLICATION
addappid(584381)

-- MAIN APP DEPOTS / PACKAGES
addappid(584381,0,"e8918bdbb58b08d54837325d9061e2102df9f6f281d79835a943d42810019224")
addappid(1237740,0,"f2c8ac25fd54930d3a505f75d181a721e69a52c1b91865d1a98c2dd59d021fba")
