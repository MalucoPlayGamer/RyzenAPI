-- Lua provided by RyzenAPI
-- Game: Game: John Mambo

-- MAIN APPLICATION
addappid(849280)
-- Game: addappid(849280)

-- MAIN APP DEPOTS / PACKAGES
addappid(849281, 1, "cc2eb5e04aad3626f754ab3b0422379eff3a52f1efd875cc96b0f786bdefff57")
