-- Lua provided by SkyAPI 
-- Game: John Mambo
addappid(849280)
addappid(849281, 1, "cc2eb5e04aad3626f754ab3b0422379eff3a52f1efd875cc96b0f786bdefff57")
