-- Lua provided by RyzenAPI
-- Game: 热血街头

-- MAIN APPLICATION
addappid(2899660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899661, 1, "529d9b8642d046ffebbbf619183e8cff0e5ad079c175276e73b6b27743cc1d03")
addappid(2900290, 0, "a67650caba8908e933a352e9b0fd5053abc1f6cfafa36848af1aa0d8128abe38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
