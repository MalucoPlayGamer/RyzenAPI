-- Lua provided by RyzenAPI
-- Game: 2899660

-- MAIN APPLICATION
addappid(2899660)
-- Game: addappid(2899660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899661, 1, "529d9b8642d046ffebbbf619183e8cff0e5ad079c175276e73b6b27743cc1d03")
addappid(2900290, 0, "a67650caba8908e933a352e9b0fd5053abc1f6cfafa36848af1aa0d8128abe38")
