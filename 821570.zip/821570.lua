-- Lua provided by RyzenAPI
-- Game: Game: AppID 821570

-- MAIN APPLICATION
addappid(821570)
-- Game: addappid(821570)

-- MAIN APP DEPOTS / PACKAGES
addappid(821571, 1, "2592339c730394108a4cc9848f10a0e4e598452223113dd87de19a845ad219cf")
