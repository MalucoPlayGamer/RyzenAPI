-- Lua provided by RyzenAPI
-- Game: Game: Eternal Strands Soundtrack

-- MAIN APPLICATION
addappid(3404420)
-- Game: addappid(3404420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3404421, 1, "b169de2f3ed304df51a3d79e79ddc6582d8fc9ef30ca92ef759815d2feefb3cc")
