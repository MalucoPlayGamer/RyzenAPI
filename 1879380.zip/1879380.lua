-- Lua provided by RyzenAPI
-- Game: Paper Bride 2 Zangling Village

-- MAIN APPLICATION
addappid(1879380)
-- Game: addappid(1879380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879381, 1, "104d66cc65b66cbe36a60211a8e8146e3e973c08c58beb7af0e2cf784b3db684")
addappid(1879382, 1, "50db8d2def46c7dd90e6e3712b53d5793c604b51d8b0fa7d8211b2b33d51e023")
addappid(1879383, 1, "234113e0fdc3c8874b34b810c6b0638ef9a805c9e52c11a2ef6631cbb3172520")
addappid(1945200, 0, "72642aa0eff2aa579c133571cc5bfde4e1de69af66a2a9a3292ea0a710990d87")
addappid(1963460, 0, "07c3085fe2f2c55fb089928c57554103fff9b79c65df2ce2dafd226427911e6a")
