-- Lua provided by RyzenAPI 
-- Game: Kaitou Tenshi TwinAngel -Labyrinth of the Time and the World- Re:light+ DLC
addappid(3524190)
addappid(3524191, 1, "3a83dbc488541fe4b53fe33135940a70b6660735f2d80251603ae9e0bdf6426d")
addappid(3524192, 1, "cdefe32840ea38337a347e2794d6e26714269aac0b102c68597207f3e27b1009")
