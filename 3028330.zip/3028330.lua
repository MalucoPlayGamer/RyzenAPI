-- Lua provided by RyzenAPI
-- Game: Battlefield™ REDSEC

-- MAIN APPLICATION
addappid(3028330)
