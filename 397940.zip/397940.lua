-- Lua provided by RyzenAPI
-- Game: No Time To Live

-- MAIN APPLICATION
addappid(397940)
-- Game: addappid(397940)

-- MAIN APP DEPOTS / PACKAGES
addappid(397941, 1, "aa484188511121d2823736256ab1214bbda86606058b28bba21c1e3a82714338")
