-- Lua provided by RyzenAPI
-- Game: Game: The Clinic of Depravity - A Wife Reveals Her True Nature in Front of Her Husband -

-- MAIN APPLICATION
addappid(1521020)
-- Game: addappid(1521020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521021, 1, "3d01f2548529f9abf48926e856555775a0101f1b69437eb106b9c098b6828eac")
addappid(1521022, 1, "a1e2d50b7941683191e1e7cb1a03a490280b4330f6db15898e6ca0e6de9a358c")
addappid(1521024, 1, "139a286140dc22c07398083e12ce3dd7c55e6b64b94b08c62c00ebd42fe38895")
