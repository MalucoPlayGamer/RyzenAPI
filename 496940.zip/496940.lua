-- Lua provided by RyzenAPI
-- Game: 496940

-- MAIN APPLICATION
addappid(496940)
-- Game: addappid(496940)

-- MAIN APP DEPOTS / PACKAGES
addappid(496941, 1, "317035e5e31ed1db9695968ca13c4feebf9dbf3916092464a608d915c082c1a1")
