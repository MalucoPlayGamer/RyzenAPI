-- Lua provided by RyzenAPI
-- Game: PogoStickMiooooooon

-- MAIN APPLICATION
addappid(1942860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942861, 1, "275934b651dd91e58e59e7abf7b6b098041f6986879e4ddc5805f2e3887d1914")

