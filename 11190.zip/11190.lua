-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes versus Jack the Ripper

-- MAIN APPLICATION
addappid(11190)

-- MAIN APP DEPOTS / PACKAGES
addappid(11191, 1, "b31503bd117921fac8f5a5724e43c010253b89f34ca9d900d0f9f1460c8a725a")
addappid(11192, 1, "c6009b17db581ec5016eb9b3c2b1d7a54dcff04ba8d4706094e7e6ac66f26d27")
addappid(11193, 1, "62b0a6c5c1aa32e2597fa079581dee52da49d79390c68b49343597770d862778")
addappid(11194, 1, "6cb9d9f4f2e9b61d3d4a4c9646b3d5d5f5461085580ac40e5776c42525b9b029")
addappid(11195, 1, "5f7c52d8a7cc1e5de9e0e2692d0c1dc10023fe0d14e2717e8255bb5e9aa27e0b")
addappid(11196, 1, "a0c0328e458df4f4a9c0ffcc072f1d4a4a4e1cde77050fdfb796a4f60f8c0014")
addappid(11197, 1, "d0e37e380ba23599cdcce5872c34555dbbfea2c3c05431e67dc64102fd9001df")
addappid(11198, 1, "a7ca88ca9ad8457203f619e597ffd35d4d2aeb4da08221819f59fc39eb1b6429")
addappid(11199, 1, "15368b0849e819a9fcacbf2fda1f336197e14c9e693c17ce2a78e84e6fa41d75")
addappid(212331, 0, "5b470445487deb606012aea378cd061b9930382d172ae06b2e631e8512f8e222")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
