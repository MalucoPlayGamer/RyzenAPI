-- Lua provided by RyzenAPI
-- Game: Game: OF MICE AND SAND -REVISED-

-- MAIN APPLICATION
addappid(785780)
-- Game: addappid(785780)

-- MAIN APP DEPOTS / PACKAGES
addappid(785781, 1, "47036ec61505ccdef191edeb6a6a9536685698d60a00037aa73e59830148fff3")
addappid(826520, 0, "b0402e585ecaf1dbbe453037f745cf5b1048ab720e1b1f92eba2e10f8dab7b00")
