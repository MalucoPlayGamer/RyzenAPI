-- Lua provided by SkyAPI 
-- Game: AppID 3056180
addappid(3056180)
addappid(3056181, 1, "597fac69e815ec000efc72f38953808602e5e092de16ab2869ec8d4dd2a2864d")
