-- Lua provided by RyzenAPI 
-- Game: Beyond Sol
addappid(348490)
addappid(348491, 1, "02e042f98f929ed3c694fbcfbbab15e13e02941e6e3e2108ae8c35fa64e290c1")
