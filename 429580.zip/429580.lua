-- Lua provided by RyzenAPI
-- Game: Game: A Wild Catgirl Appears!

-- MAIN APPLICATION
addappid(429580)
-- Game: addappid(429580)

-- MAIN APP DEPOTS / PACKAGES
addappid(429581, 1, "39a902f5b0d9915599cee2239e551da437eb7bbe65e5abbdadf909480df29393")
