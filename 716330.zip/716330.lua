-- Lua provided by RyzenAPI
-- Game: 716330

-- MAIN APPLICATION
addappid(716330)
-- Game: addappid(716330)

-- MAIN APP DEPOTS / PACKAGES
addappid(716331, 1, "f33f0dfbfa1daa44ee7d35ecb46e63cefec2a31a2b4cc6078545d4ec449ffde5")
