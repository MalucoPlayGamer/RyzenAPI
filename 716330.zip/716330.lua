-- Lua provided by SkyAPI 
-- Game: AppID 716330
addappid(716330)
addappid(716331, 1, "f33f0dfbfa1daa44ee7d35ecb46e63cefec2a31a2b4cc6078545d4ec449ffde5")
