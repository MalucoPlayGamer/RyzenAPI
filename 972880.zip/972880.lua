-- Lua provided by RyzenAPI
-- Game: A Piece of Wish upon the Stars - 高清CG包

-- MAIN APPLICATION
addappid(972880)
-- Game: addappid(972880)

-- MAIN APP DEPOTS / PACKAGES
addappid(972880,0,"19897a6922d39dc7abf961d3cfdf7665698b55c9bcb05df957ad34c1648b26cb")
