-- Lua provided by RyzenAPI
-- Game: Grave Mania: Pandemic Pandemonium

-- MAIN APPLICATION
addappid(514770)

-- MAIN APP DEPOTS / PACKAGES
addappid(514771,0,"5642646eebca4241de7f84daa125ced4fb956d20152bd8b04ee8cabce992bc1c")

