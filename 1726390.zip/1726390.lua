-- Lua provided by RyzenAPI
-- Game: addappid(1726390)

-- MAIN APPLICATION
addappid(1726390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726391, 1, "2d1612c500b6205ba89a0558cf26298d164e69fba2dc76952194210ffe1ea4dc")
