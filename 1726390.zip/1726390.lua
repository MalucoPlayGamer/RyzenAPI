-- Lua provided by SkyAPI 
-- Game: Adventure of Rikka - The Cursed Kingdom
addappid(1726390)
addappid(1726391, 1, "2d1612c500b6205ba89a0558cf26298d164e69fba2dc76952194210ffe1ea4dc")
