-- Lua provided by RyzenAPI
-- Game: Harvest Village

-- MAIN APPLICATION
addappid(3210720)
-- Game: addappid(3210720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210721, 1, "a89d3a510bdc819516f9fb0f2d1bb57c69bdee455c5c8180e855dd6020267871")
