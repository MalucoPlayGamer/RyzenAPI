-- Lua provided by RyzenAPI
-- Game: Hector: Episode 1

-- MAIN APPLICATION
addappid(94600)

-- MAIN APP DEPOTS / PACKAGES
addappid(94601, 1, "cb4fe6f712eb1673e3d8c322b07d62e7b1c6bb967e776352daea2397ab35c750")
addappid(94602, 1, "761880d52d45035dd62d1f47f8a57c9fca54517051005e911b7198f0f0558f46")

