-- Lua provided by RyzenAPI
-- Game: Amnesia: A Machine for Pigs

-- MAIN APPLICATION
addappid(239200)

-- MAIN APP DEPOTS / PACKAGES
addappid(239201, 1, "56e3256bf209f382a31c67bc688a43d3d203c7b1b1289fad2e5518f58974891f")
addappid(239202, 1, "5870b1b7eb3f9dcd3568eceab68885ffd08a8d3deec0aaa31212bcb3cb5a93f6")
addappid(239203, 1, "dcaea671d793d501ce7770f1e05d6d31a08ea85ff75bbd8282ade4b682570e47")
addappid(239204, 1, "eb19a2500fc55eb42480e6561c0c9032a457ad99100053ac7f85d78f557e3e69")

