-- Lua provided by RyzenAPI
-- Game: Phantom Project

-- MAIN APPLICATION
addappid(1745480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745481, 1, "07aa8daf40d40985075a2f35394c23422600215c709851fdf20b675b465c0f0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
