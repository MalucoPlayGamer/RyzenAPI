-- Lua provided by RyzenAPI
-- Game: Phantom Project

-- MAIN APPLICATION
addappid(1745480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745481, 1, "07aa8daf40d40985075a2f35394c23422600215c709851fdf20b675b465c0f0c")
