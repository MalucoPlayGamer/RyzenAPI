-- Lua provided by RyzenAPI
-- Game: 1182540

-- MAIN APPLICATION
addappid(1182540)
-- Game: addappid(1182540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182540,0,"8a3384ff21ca4ea36e007df026af6d7acae8f77fbe4cdbe4f315434d67fc57d1")
