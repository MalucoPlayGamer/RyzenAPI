-- Lua provided by RyzenAPI
-- Game: Game: 悲哀朋克：劳动、生存与火箭 Demo

-- MAIN APPLICATION
addappid(2945160)
-- Game: addappid(2945160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945161, 1, "98760aa8d2a523ee1295102efa5a86c2aec7b611dd9c2c90902230e478bfd234")
