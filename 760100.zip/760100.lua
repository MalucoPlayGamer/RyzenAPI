-- Lua provided by RyzenAPI
-- Game: addappid(760100)

-- MAIN APPLICATION
addappid(760100)

-- MAIN APP DEPOTS / PACKAGES
addappid(760101, 1, "c5576be93e5c3b2801f845663e3126d21fab1d05217afc8cbed85bdd2cf16a17")
