-- Lua provided by RyzenAPI
-- Game: Game: Stray Gods - Pantheon Edition (Original Game Soundtrack)

-- MAIN APPLICATION
addappid(2517710)
-- Game: addappid(2517710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517711, 1, "95d21bacbaeab6cf762615632930d9181d37b73c700c6376e1430ea9336e965a")
