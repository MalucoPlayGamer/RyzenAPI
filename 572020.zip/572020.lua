-- Lua provided by RyzenAPI
-- Game: Game: Darwin's Demons

-- MAIN APPLICATION
addappid(572020)
-- Game: addappid(572020)

-- MAIN APP DEPOTS / PACKAGES
addappid(572021, 1, "1dbb260fd64c2045f8428374cdeadc5220aac154b60d3cd0cf584f29d95c491b")
addappid(572022, 1, "72b612395a277f07328fb8c167096dfb8f39b93a185ce181e6c2021f705db089")
addappid(572023, 1, "b28085d37644b6bbb921d66ced6f571a49c7d5b5b4947f58ded58f0875aadfe0")
addappid(572024, 1, "bbdee93d093b4a13fd43a5333ba6651f221f9aa17100362e4b384c8f4546face")
addappid(572025, 1, "3f921c04a28ab86b95a9bc52db7eb73d824d9be027482a420daf853cbdb8e571")
addappid(572026, 1, "5320febcd74549fb2e06eb39a2bb2b816e3b20e2e87e80349581287ebf7ad48e")
