-- Lua provided by RyzenAPI
-- Game: addappid(2096980)

-- MAIN APPLICATION
addappid(228989)
addappid(2096980)
addappid(2096981)
addappid(2096982)
addappid(2096983)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942051,0,"fe1ff730b91012f303847522af7b0ec3cd8b46944de3cd3a5967c18e483403ec")
addappid(1942052,0,"e17bc02e0eaeec284ac41fc3fad55b920dfe2cd9418911100e0b745dec995547")
addappid(1942053,0,"84db2633f90e0c317bb92b12524bc2b4bc7ad1d757b50122d2b209a6b11b4c5f")
