-- Lua provided by RyzenAPI
-- Game: The Devil Within: Satgat

-- MAIN APPLICATION
addappid(1802880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1802881, 1, "d8359c859a78b301e8e04517324fc883cc792b527ce3be778f8c76430e730ed8")

