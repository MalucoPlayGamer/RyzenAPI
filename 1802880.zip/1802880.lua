-- Lua provided by SkyAPI 
-- Game: The Devil Within: Satgat
addappid(1802880)
addappid(1802881, 1, "d8359c859a78b301e8e04517324fc883cc792b527ce3be778f8c76430e730ed8")
