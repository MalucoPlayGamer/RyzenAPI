-- Lua provided by RyzenAPI
-- Game: Game: The Devil Within: Satgat

-- MAIN APPLICATION
addappid(1802880)
-- Game: addappid(1802880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802881, 1, "d8359c859a78b301e8e04517324fc883cc792b527ce3be778f8c76430e730ed8")
