-- 4498210's Lua and Manifest Created by Hubcap Manifest
-- Desktop Pinforge
-- Created: August 12, 2026 at 00:05:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4498210) -- Desktop Pinforge
-- MAIN APP DEPOTS
addappid(4498211, 1, "28af29c69f845302440dbec8e1ed327b7f323fc1d2b3b6aa6a56af191f97b5c8") -- Depot 4498211
setManifestid(4498211, "6879120243892878198", 222158377)