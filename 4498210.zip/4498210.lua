-- Lua provided by RyzenAPI
-- Game: Desktop Pinforge

-- MAIN APPLICATION
addappid(4498210) -- Desktop Pinforge

-- MAIN APP DEPOTS / PACKAGES
addappid(4498211, 1, "28af29c69f845302440dbec8e1ed327b7f323fc1d2b3b6aa6a56af191f97b5c8") -- Depot 4498211

