-- Lua provided by RyzenAPI
-- Game: Jrago II Eden This Inner Life

-- MAIN APPLICATION
addappid(3820220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3820222,0,"b79dafd8b202c848bf39e948b9f4e85f4f518652c5f6a28f78e6bb9bb30028da")

