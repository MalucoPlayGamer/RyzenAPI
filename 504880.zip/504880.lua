-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles 2: RADical ROACH

-- MAIN APPLICATION
addappid(504880)
-- Game: addappid(504880)

-- MAIN APP DEPOTS / PACKAGES
addappid(504881, 1, "8fab824c86610c02b3bf901dd80efea3b3effe0abddc7323ebe48cb99ae3f2b7")
