-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles 2: RADical ROACH

-- MAIN APPLICATION
addappid(504880)

-- MAIN APP DEPOTS / PACKAGES
addappid(504881, 1, "8fab824c86610c02b3bf901dd80efea3b3effe0abddc7323ebe48cb99ae3f2b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
