-- Lua provided by RyzenAPI
-- Game: Game: Horse Racing 2016

-- MAIN APPLICATION
addappid(655610)
-- Game: addappid(655610)

-- MAIN APP DEPOTS / PACKAGES
addappid(655611, 1, "eac626e08e395de06da589158d536d23f0ad03d424f70eb842b2d6ea187b2cbb")
