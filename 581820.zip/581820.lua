-- Lua provided by RyzenAPI
-- Game: Game: AppID 581820

-- MAIN APPLICATION
addappid(581820)
-- Game: addappid(581820)

-- MAIN APP DEPOTS / PACKAGES
addappid(581821, 1, "f23c16aa615285ca0ca059558ca38b821c19a0704ae922de1dcdd6d9093499a5")
