-- Lua provided by RyzenAPI
-- Game: Game: Estranged: Act I

-- MAIN APPLICATION
addappid(261820)
-- Game: addappid(261820)

-- MAIN APP DEPOTS / PACKAGES
addappid(261821, 1, "88aac0db9a994f30e77ac1e4581156b3f8237ccb72f10bcb017e73b7a5c6e512")
addappid(261822, 1, "22f52860d0dd61998494faf7dd0c0c1c2a168529f66c7b06ecf07cb595878caa")
addappid(261823, 1, "778dce4979b3603dc364b3413e18e6fe709562e8d28fc6e6ba12c6ad532fe0ba")
addappid(261824, 1, "f10353c171601e45d652cb45a5e45172f33bba5911a70cbe1b31a644165dfa6b")
addappid(261825, 1, "e86725456c194ea7169c29ff08b9c012a49a51ba0909a714a542fd77d37e0e0a")
