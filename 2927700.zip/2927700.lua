-- Lua provided by RyzenAPI
-- Game: Fight Life: Vanguard

-- MAIN APPLICATION
addappid(2927700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927701,0,"197b73936a631cfa67c320def9c65ad11aa5c0c848015ece4fe14359b4fa2fbb")

