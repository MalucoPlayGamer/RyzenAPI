-- Lua provided by RyzenAPI
-- Game: addappid(2367400)

-- MAIN APPLICATION
addappid(2367400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367401, 1, "ba9cd799756525c4f1ada45468216d2ff5e8da72a92cf4aa3ccd898e5a247591")
