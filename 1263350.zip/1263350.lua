-- Lua provided by SkyAPI 
-- Game: AppID 1263350
addappid(1263350)
addappid(1263351, 1, "cc3cee2f267501bc59bd01f204b330cba818bc0715a7285263f789cf6f16201f")
