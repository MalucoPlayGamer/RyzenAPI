-- Lua provided by RyzenAPI
-- Game: Break Free

-- MAIN APPLICATION
addappid(1821520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821521, 1, "c529d7f73a686dca7ebc3f5ee412a27b2ed7a683bb8f5ac877c58a030fb1ade4")
