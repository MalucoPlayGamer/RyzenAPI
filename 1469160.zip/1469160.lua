-- Lua provided by RyzenAPI
-- Game: 1469160

-- MAIN APPLICATION
addappid(1469160)
-- Game: addappid(1469160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469161, 1, "b2d79be18883bd7c3f1eb222fab3634ff5eeea46ebfd2289dc235546920274c8")
