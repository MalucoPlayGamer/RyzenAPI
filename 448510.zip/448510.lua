-- Lua provided by RyzenAPI
-- Game: AppID 448510

-- MAIN APPLICATION
addappid(448510)
-- Game: addappid(448510)

-- MAIN APP DEPOTS / PACKAGES
addappid(448511, 1, "d54ea6782642b416a2c5587f03ed3c9b7cbf6098565dca9cd91325ac1c79e750")
addappid(530060, 0, "ddca5a86b69fd74aec04867274a9171d22a319ca1efe116d60ad195e840710c2")
