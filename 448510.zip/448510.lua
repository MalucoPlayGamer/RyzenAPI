-- Lua provided by RyzenAPI
-- Game: AppID 448510

-- MAIN APPLICATION
addappid(448510)

-- MAIN APP DEPOTS / PACKAGES
addappid(448511, 1, "d54ea6782642b416a2c5587f03ed3c9b7cbf6098565dca9cd91325ac1c79e750")
addappid(530060, 0, "ddca5a86b69fd74aec04867274a9171d22a319ca1efe116d60ad195e840710c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
