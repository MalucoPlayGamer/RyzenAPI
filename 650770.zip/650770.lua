-- Lua provided by RyzenAPI
-- Game: Time Gun

-- MAIN APPLICATION
addappid(650770)

-- MAIN APP DEPOTS / PACKAGES
addappid(650771,0,"e68f48c43c97b3170bf70563b8232601408664aaaffa1fa76f1e62111727bab0")

