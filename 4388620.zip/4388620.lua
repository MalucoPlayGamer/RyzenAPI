-- Lua provided by RyzenAPI
-- Game: Cosmic Wayfinder

-- MAIN APPLICATION
addappid(4388620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4388622,0,"1a793a0784f1a746fb1d9c0c11bed15ed499d0777a84b5e4302ab2511f5528c0")

