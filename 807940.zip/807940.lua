-- Lua provided by RyzenAPI 
-- Game: War of Criminals
addappid(807940)
addappid(807941, 1, "7e86c2f52a40765c7e864fd01eee1c6667d2ad1aabe76cfd725bec42455b76e7")
