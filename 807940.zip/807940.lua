-- Lua provided by RyzenAPI
-- Game: addappid(807940)

-- MAIN APPLICATION
addappid(807940)

-- MAIN APP DEPOTS / PACKAGES
addappid(807941, 1, "7e86c2f52a40765c7e864fd01eee1c6667d2ad1aabe76cfd725bec42455b76e7")
