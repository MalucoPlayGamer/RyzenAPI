-- Lua provided by RyzenAPI
-- Game: Eclipse Protocol 2130

-- MAIN APPLICATION
addappid(4216540) -- Eclipse Protocol 2130
--addappid(4230830) -- Eclipse Protocol 2130 Artbook

-- MAIN APP DEPOTS / PACKAGES
addappid(4216541, 1, "861589412a89600be1adb63f6cedcc6b61b777e49f13c758d9ff72b4d3188c9c") -- Depot 4216541

