-- Lua provided by RyzenAPI
-- Game: ProBee

-- MAIN APPLICATION
addappid(1881250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881251, 1, "1dca5de6123155bb89868f7011d9a52c5be36342d0338838844ed7031f7a2cf2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
