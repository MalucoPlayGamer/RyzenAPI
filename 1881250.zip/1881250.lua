-- Lua provided by RyzenAPI 
-- Game: ProBee
addappid(1881250)
addappid(1881251, 1, "1dca5de6123155bb89868f7011d9a52c5be36342d0338838844ed7031f7a2cf2")
