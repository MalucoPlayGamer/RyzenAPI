-- Lua provided by RyzenAPI
-- Game: AppID 1222370

-- MAIN APPLICATION
addappid(1222370)
addappid(1522550)
addappid(1613060)
addappid(1786040)
addappid(1786041)
addappid(1786042)
addappid(1792910)
addappid(1792911)
-- Game: addappid(1222370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222371, 1, "5291db50e26017232fc71eaf2c27b4e796a09e8e61872ebbdff4f3a24e78ffb4")
addappid(1222372, 1, "0af0c3ba7ef2187afb4b670fc4f843a035580c7ad4bdd435e9d7cebadc8d4067")
