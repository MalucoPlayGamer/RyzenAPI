-- Lua provided by RyzenAPI
-- Game: Game: JDM: Japanese Drift Master - Supporter Pack

-- MAIN APPLICATION
addappid(3749550)
-- Game: addappid(3749550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3749551, 1, "ebe86f26c512a72840dfc92fcfd523c57ede0185d0150f30ea1f0e04a11a219d")
