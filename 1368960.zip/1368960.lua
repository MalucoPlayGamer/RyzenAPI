-- Lua provided by RyzenAPI
-- Game: Fishing Sim World: Bass Pro Shops Edition

-- MAIN APPLICATION
addappid(1368960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368961, 1, "19ce558d9663fc5e495f636c8f5f2668bd46ae38c5dd304b508ad3d5338ffe8d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
