-- Lua provided by SkyAPI 
-- Game: 咸鱼修仙指南
addappid(2378120)
addappid(2378121, 1, "08c80df5054357e436adadb3b8a3d3fc18a0c55188ebdd3a0abe688bef2fcc43")
