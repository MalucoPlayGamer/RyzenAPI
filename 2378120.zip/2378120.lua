-- Lua provided by RyzenAPI
-- Game: 咸鱼修仙指南

-- MAIN APPLICATION
addappid(2378120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378121, 1, "08c80df5054357e436adadb3b8a3d3fc18a0c55188ebdd3a0abe688bef2fcc43")

