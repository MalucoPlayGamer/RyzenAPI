-- Lua provided by RyzenAPI
-- Game: AppID 1247460

-- MAIN APPLICATION
addappid(1247460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247461, 1, "1a2a0b5226ae98186af290255d7319e6413e4643a1563fc6080774644b37f67d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1282680)
addappid(1282681)
