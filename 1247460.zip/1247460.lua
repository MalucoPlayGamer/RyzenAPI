-- Lua provided by RyzenAPI
-- Game: To the Edge of the Sky

-- MAIN APPLICATION
addappid(1247460)
addappid(1282680)
addappid(1282681)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247461, 1, "1a2a0b5226ae98186af290255d7319e6413e4643a1563fc6080774644b37f67d")

