-- Lua provided by RyzenAPI
-- Game: Marimoth

-- MAIN APPLICATION
addappid(1786660)
-- Game: addappid(1786660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786661, 1, "b544f24e1ab9720bcaa374b076ff44cb4cd15a50db1158c0a175b57ea546cf9c")
