-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Hibiki Katakura MV Monsters Vol.3

-- MAIN APPLICATION
addappid(1618120)
-- Game: addappid(1618120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618120,0,"9ff3c0b2ea71e5172fd2ea90ba8b50adee2384443dd7636ec62bfa5a36b4d1c8")
