-- Lua provided by RyzenAPI
-- Game: Push Me Pull You

-- MAIN APPLICATION
addappid(362380)
addappid(362383)
addappid(362384)
-- Game: addappid(362380)

-- MAIN APP DEPOTS / PACKAGES
addappid(362382,0,"99c8a9d76c1d7d49a00854707069d13050446af12827153ce58e08d18cb0a8eb")
addappid(488630,0,"898378b96efac7c1815de6e73314d279504c7837f6ca956f8619c5407d3cef5b")
