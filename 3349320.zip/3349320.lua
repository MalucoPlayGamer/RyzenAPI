-- Lua provided by RyzenAPI
-- Game: ARK: Extinction Ascended

-- MAIN APPLICATION
addappid(3349320)
-- Game: addappid(3349320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349320,0,"e0cbc7f932b6b5ffa7e36b9fe8ccf5b2317d5073f520b8a357a7bb8e32d7a181")
