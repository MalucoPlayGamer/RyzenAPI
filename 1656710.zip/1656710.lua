-- Lua provided by RyzenAPI
-- Game: addappid(1656710)

-- MAIN APPLICATION
addappid(1656710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656713,0,"27e3fb8af4e8021f53371c87e1c58ae064b40fe7387fe5b75fa6d4c488397720")
