-- Lua provided by RyzenAPI
-- Game: Game: The Dust of the Violet Crystals

-- MAIN APPLICATION
addappid(2843830)
-- Game: addappid(2843830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843831, 1, "945b550252b36db48380b1700af5b56f3ca9332432369264ae3771c428caa33c")
