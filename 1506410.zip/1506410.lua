-- Lua provided by RyzenAPI
-- Game: 1506410

-- MAIN APPLICATION
addappid(1506410)
-- Game: addappid(1506410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506411, 1, "ab829014b551e3f7b944a048c602f0a8359e0ccc3baf3d3aa4aa0094f7234e70")
