-- Lua provided by RyzenAPI
-- Game: Kebab House

-- MAIN APPLICATION
addappid(1379150)
-- Game: addappid(1379150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379151, 1, "6ff99623ac9450ea65d550f83a27f54a6d710a1c1ab3064d6118d8d7e55b8644")
