-- Lua provided by SkyAPI 
-- Game: Kebab House
addappid(1379150)
addappid(1379151, 1, "6ff99623ac9450ea65d550f83a27f54a6d710a1c1ab3064d6118d8d7e55b8644")
