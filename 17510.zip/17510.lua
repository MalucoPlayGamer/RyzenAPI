-- Lua provided by RyzenAPI
-- Game: Game: AppID 17510

-- MAIN APPLICATION
addappid(17510)
-- Game: addappid(17510)

-- MAIN APP DEPOTS / PACKAGES
addappid(17511, 1, "9af61873c3c82e5736719de687098fc1674fa7632412ea633716f2389d928a69")
