-- Lua provided by RyzenAPI
-- Game: Fairground 2 - The Ride Simulation

-- MAIN APPLICATION
addappid(977790)

-- MAIN APP DEPOTS / PACKAGES
addappid(977791, 1, "7171b934bfb8b8cb909f52a883bb8ff3e459ab12d051c1e89d1f6f0568395769")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
