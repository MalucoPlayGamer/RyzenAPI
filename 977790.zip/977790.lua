-- Lua provided by RyzenAPI
-- Game: addappid(977790)

-- MAIN APPLICATION
addappid(977790)

-- MAIN APP DEPOTS / PACKAGES
addappid(977791, 1, "7171b934bfb8b8cb909f52a883bb8ff3e459ab12d051c1e89d1f6f0568395769")
