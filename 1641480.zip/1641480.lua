-- Lua provided by RyzenAPI
-- Game: 1641480

-- MAIN APPLICATION
addappid(1641480)
-- Game: addappid(1641480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641481, 1, "21d87dcc260e1f40047cb76888f1edfcb2b50a1f119421fc42b891e6f38725f0")
