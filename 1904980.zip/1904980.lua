-- Lua provided by RyzenAPI
-- Game: Game: Espresso Tycoon Prologue: Underwater

-- MAIN APPLICATION
addappid(1904980)
-- Game: addappid(1904980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904981, 1, "292a9be11e0df65e4b0a5877d5e22b417d9c10fcda15f53d561151dfd47afb2c")
