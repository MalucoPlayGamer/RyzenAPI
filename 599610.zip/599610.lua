-- Lua provided by RyzenAPI
-- Game: AppID 599610

-- MAIN APPLICATION
addappid(599610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(599611, 1, "2cbd911acc5b52cc9ead11b00bcf2c4ee7fde8969829635bc9eb9d39948ec30f")

