-- Lua provided by RyzenAPI 
-- Game: AppID 599610
addappid(599610)
addappid(599611, 1, "2cbd911acc5b52cc9ead11b00bcf2c4ee7fde8969829635bc9eb9d39948ec30f")
