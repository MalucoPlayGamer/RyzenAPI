-- Lua provided by RyzenAPI
-- Game: DJ Streamer

-- MAIN APPLICATION
addappid(497150)

-- MAIN APP DEPOTS / PACKAGES
addappid(497151, 1, "5ded310c09b11d11499c04861d752c94b914d3cab9fed564eb5a981184c72ba8")
