-- Lua provided by RyzenAPI
-- Game: DJ Streamer

-- MAIN APPLICATION
addappid(497150)

-- MAIN APP DEPOTS / PACKAGES
addappid(497151, 1, "5ded310c09b11d11499c04861d752c94b914d3cab9fed564eb5a981184c72ba8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
