-- Lua provided by RyzenAPI
-- Game: Game: Twilight Manor: Roguelite FPS

-- MAIN APPLICATION
addappid(2863690)
-- Game: addappid(2863690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863691, 1, "730c186a0a4c36a6333a26488e19a8b8b62db71d225f90444f45c44bbc80e817")
