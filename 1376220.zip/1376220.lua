-- Lua provided by SkyAPI 
-- Game: AppID 1376220
addappid(1376220)
addappid(1376221, 1, "0c2e69be4ccb01d1aa47a7c7de5267de41226aa2c2cac21120879330ce1761e7")
