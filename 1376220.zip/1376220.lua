-- Lua provided by RyzenAPI
-- Game: 1376220

-- MAIN APPLICATION
addappid(1376220)
-- Game: addappid(1376220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376221, 1, "0c2e69be4ccb01d1aa47a7c7de5267de41226aa2c2cac21120879330ce1761e7")
