-- 4695000's Lua and Manifest Created by Hubcap Manifest
-- The Lumberjack's Routine
-- Created: June 26, 2026 at 02:10:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4695000) -- The Lumberjack's Routine
-- MAIN APP DEPOTS
addappid(4695001, 1, "c02bbe6923e73efacee4a12c891626c48650089cdbbe423580eb853ec9e6c318") -- Depot 4695001
setManifestid(4695001, "2201076804260672050", 128942384)
addappid(4695002, 1, "60e501ba6259be989ada000dcdee8ffdf0bc0260c99b265707d72fe5d5eac4c7") -- Depot 4695002
setManifestid(4695002, "942793590262892815", 214020474)
addappid(4695003, 1, "0ce23a842d8cdd2747bb2f776219591ee3b304a7d1cac7275ff7a44abaea3e20") -- Depot 4695003
setManifestid(4695003, "7523103534145537078", 95353270)