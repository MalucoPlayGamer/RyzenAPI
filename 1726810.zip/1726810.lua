-- Lua provided by SkyAPI 
-- Game: Psychonauts 2 (Original Soundtrack), Vol. 1
addappid(1726810)
addappid(1726811, 1, "78d100ecee5498292852da366cc12abe962e788f7dd7d7055aee226fe9db8b8f")
addappid(1726813, 1, "9ee7f99df4f81b7162fa957c1ead906c98c62bac9c6e32b630e251e212d4ed76")
