-- Lua provided by RyzenAPI
-- Game: Game: HellFurnace

-- MAIN APPLICATION
addappid(2298330)
-- Game: addappid(2298330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298331, 1, "aeb1441dfc1a01cf2bbe9821ab5e12a9e84955a8affc61046163eb0879ee9e7d")
