-- Lua provided by SkyAPI 
-- Game: Ladies I'm Ready
addappid(3262440)
addappid(3262441, 1, "3488f90a40c45164d8067ed61f144065b19a4c2c681259af3810e893c55e3fd5")
