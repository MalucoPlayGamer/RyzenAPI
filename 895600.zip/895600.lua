-- Lua provided by RyzenAPI
-- Game: Mojo

-- MAIN APPLICATION
addappid(895600)
-- Game: addappid(895600)

-- MAIN APP DEPOTS / PACKAGES
addappid(895602,0,"67de221ace751d756592e4c848899ff3c499e92693c58d0db3b8e7f7d3bfc468")
