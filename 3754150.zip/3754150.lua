-- Lua provided by SkyAPI 
-- Game: CENTO Original Soundtrack 2
addappid(3754150)
addappid(3754151, 1, "650eb33458d6c05e8fd0498e21bf86ff4a31005fe818ae02bafbd3ebda6b2987")
addappid(3754152, 1, "28ed17984e1dc28ff691b39fe5770f9f92f0490b159baeb61559649dba720049")
