-- Lua provided by RyzenAPI
-- Game: A Fisherman's Tale 2

-- MAIN APPLICATION
addappid(2096570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096571, 1, "07674e037c87b9063511efaf2d02a67980b5198951a6b8a1c48c3ea85e177c62")

