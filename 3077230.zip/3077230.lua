-- Lua provided by RyzenAPI
-- Game: Game: Open Blocks

-- MAIN APPLICATION
addappid(3077230)
-- Game: addappid(3077230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077231, 1, "d7d23d28089fd14a03d576338c08b82362958f1b43f1b15cc0c560b366869287")
