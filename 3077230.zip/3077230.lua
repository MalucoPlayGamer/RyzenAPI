-- Lua provided by RyzenAPI
-- Game: Open Blocks

-- MAIN APPLICATION
addappid(3077230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3077231, 1, "d7d23d28089fd14a03d576338c08b82362958f1b43f1b15cc0c560b366869287")

