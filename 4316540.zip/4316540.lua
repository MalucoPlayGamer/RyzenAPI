-- 4316540's Lua and Manifest Created by Hubcap Manifest
-- The Anomaly Department
-- Created: August 10, 2026 at 08:57:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4316540) -- The Anomaly Department
-- MAIN APP DEPOTS
addappid(4316541, 1, "9eba46b86f9c18c491e16872b61022bd0e85213a5b1aa79e1466c3b2dc57dcc1") -- Depot 4316541
setManifestid(4316541, "5977034145195468805", 5596348368)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)