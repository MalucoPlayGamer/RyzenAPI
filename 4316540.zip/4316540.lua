-- Lua provided by RyzenAPI
-- Game: The Anomaly Department

-- MAIN APPLICATION
addappid(4316540) -- The Anomaly Department

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4316541, 1, "9eba46b86f9c18c491e16872b61022bd0e85213a5b1aa79e1466c3b2dc57dcc1") -- Depot 4316541

