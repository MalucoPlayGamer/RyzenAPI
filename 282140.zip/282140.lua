-- Lua provided by RyzenAPI
-- Game: AppID 282140

-- MAIN APPLICATION
addappid(282140)
-- Game: addappid(282140)

-- MAIN APP DEPOTS / PACKAGES
addappid(282141, 1, "575eef2b1e8796520eb8b7dbebc2734a4ac7bd65b1aaff15c469cf4a2b23a087")
addappid(282142, 1, "abbca057dd0ca3dd23e5cb2403d22aac8a1d679555c052fc50904dd7ea3e201b")
addappid(282143, 1, "f6d26735998113de1a173d2ba557e039d43e166a9427add04d3e7d7fe789431b")
addappid(282144, 1, "b1924089e06c7b37db8b242e2691cdab4033b7c65879ca3f95e3eb3c94eb763b")
addappid(282145, 1, "81f10d8ca12374ca0efe4da30c51c1b7815bb302028dce886e4e9c03bd86cb46")
