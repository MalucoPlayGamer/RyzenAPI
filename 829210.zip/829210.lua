-- Lua provided by RyzenAPI
-- Game: AIdol

-- MAIN APPLICATION
addappid(829210)

-- MAIN APP DEPOTS / PACKAGES
addappid(829211,0,"80e988efb035cc492c56c8d82d43fc249ff18a422d66a16a25e24e5c77e5fccb")

