-- Lua provided by RyzenAPI
-- Game: Game: A Heart of Butterblue

-- MAIN APPLICATION
addappid(2406550)
-- Game: addappid(2406550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406551, 1, "a796ea47abd033b9ff42c1554c95d296145daabe3d0f1cbcc817dee2cbd563b6")
addappid(2406552, 1, "10c3293ebc7a27366b6d35d125453bd49e7098661c59f020ac1cc044161462b7")
addappid(2406553, 1, "f74b4eff7f23de44c19908e2662a32bc08a1c3bb90d9b17db6ab91a1421ecf11")
