-- Lua provided by RyzenAPI
-- Game: Duet Night Abyss

-- MAIN APPLICATION
addappid(3950020)
