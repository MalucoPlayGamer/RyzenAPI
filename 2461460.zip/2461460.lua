-- Lua provided by RyzenAPI
-- Game: Womanizer

-- MAIN APPLICATION
addappid(2461460)
-- Game: addappid(2461460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461461, 1, "62dc73ebf2f505a1ec7edc0d23331a4c64c687cfb0534f6023a2f0f8d3d97d4a")
