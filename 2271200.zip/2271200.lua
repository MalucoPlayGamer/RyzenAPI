-- Lua provided by RyzenAPI 
-- Game: Assault On Proxima
addappid(2271200)
addappid(2271201, 1, "b9aaf28f2eacf4cfbf3fc0ced0da19415576908077548999946ad72757a61416")
