-- Lua provided by RyzenAPI
-- Game: 2271200

-- MAIN APPLICATION
addappid(2271200)
-- Game: addappid(2271200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271201, 1, "b9aaf28f2eacf4cfbf3fc0ced0da19415576908077548999946ad72757a61416")
