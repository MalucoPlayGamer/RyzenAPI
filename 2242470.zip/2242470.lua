-- Lua provided by RyzenAPI
-- Game: DrivingSchool-驾驶学校

-- MAIN APPLICATION
addappid(2242470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242471, 1, "3f4aaf4c164e4fca3296072e465195a3449d64d8b5afb2dd1cd2123d3dfcb5dc")
