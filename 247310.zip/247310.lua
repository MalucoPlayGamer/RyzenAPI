-- Lua provided by RyzenAPI
-- Game: Game: Gravi

-- MAIN APPLICATION
addappid(247310)
-- Game: addappid(247310)

-- MAIN APP DEPOTS / PACKAGES
addappid(247311, 1, "8db43953342c31ca48005e439a9c42d6d5517c0ee1a83fea5939f65672451b5d")
