-- Lua provided by RyzenAPI
-- Game: 3835010

-- MAIN APPLICATION
addappid(3835010)
-- Game: addappid(3835010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3835011, 1, "5dee768c75903c4fb32a2021ed212b8593047aba22014e8ff2eee4dab11b5448")
