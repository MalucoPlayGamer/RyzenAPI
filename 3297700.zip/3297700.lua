-- Lua provided by RyzenAPI
-- Game: Hacky Demo

-- MAIN APPLICATION
addappid(3297700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3297701, 1, "73a7bb602e56e97e99aa172bd80aed862a49d7990d417477b6424a36a1d0e69f")

