-- Lua provided by RyzenAPI
-- Game: Game: Sands of Salzaar Soundtrack

-- MAIN APPLICATION
addappid(1416310)
-- Game: addappid(1416310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416311, 1, "8016d36f780bcf48cb9af9af3a4405c5f782a093fe86a4d1efaae4fdbd83bcc1")
addappid(1416312, 1, "b5689e2776b66912335ca9076d1983c34ae6f9743134128cbddb3b9d3b664406")
