-- Lua provided by RyzenAPI
-- Game: addappid(2836780)

-- MAIN APPLICATION
addappid(2836780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836780,0,"fa17091515f90b2c5474d0f407a470c1e3acdd4fa5ad79533d82b3163b3aca27")
