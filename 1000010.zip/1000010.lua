-- Lua provided by RyzenAPI
-- Game: Crown Trick

-- MAIN APPLICATION
addappid(1000010)
-- Game: addappid(1000010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000011, 1, "fea52c12af4b75e0439f1218cfa66c24ffd1e145909101a7080339c26063a21a")
addappid(1000012, 1, "0eed2cf8f51838c0f34692e5c6f4b03b56c949f6f0437979222bb4a7930cf83c")
