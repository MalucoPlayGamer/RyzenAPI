-- Lua provided by RyzenAPI
-- Game: AppID 1000010

-- MAIN APPLICATION
addappid(1000010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000011, 1, "fea52c12af4b75e0439f1218cfa66c24ffd1e145909101a7080339c26063a21a")
addappid(1000012, 1, "0eed2cf8f51838c0f34692e5c6f4b03b56c949f6f0437979222bb4a7930cf83c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1367290)
