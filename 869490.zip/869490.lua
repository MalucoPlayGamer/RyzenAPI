-- Lua provided by RyzenAPI
-- Game: Limerick: Cadence Mansion

-- MAIN APPLICATION
addappid(869490)

-- MAIN APP DEPOTS / PACKAGES
addappid(869491,0,"7a281b41b3b32c7a355d79500f8e01c3ede03eb90eaa1f7bcb849b7e7605545d")

