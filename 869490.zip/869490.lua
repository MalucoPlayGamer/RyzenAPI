-- Lua provided by RyzenAPI
-- Game: Limerick: Cadence Mansion

-- MAIN APPLICATION
addappid(869490)

-- MAIN APP DEPOTS / PACKAGES
addappid(869491,0,"7a281b41b3b32c7a355d79500f8e01c3ede03eb90eaa1f7bcb849b7e7605545d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
