-- Lua provided by RyzenAPI
-- Game: Rochard

-- MAIN APPLICATION
addappid(107800)

-- MAIN APP DEPOTS / PACKAGES
addappid(107801, 1, "0a1207b768e16e03d0b51875ac7ae54ef7df102b43529ed72d8f43aada2e978c")
addappid(107808, 1, "0e97f2eba30dbbdd4bc7d8c25ae0757192827d0a55277a873f11b8e559b5c5ab")
addappid(107815, 1, "0deb74654913216cfbc65e8752f412898194b24d19fe94856097d010a605917c")
addappid(107820, 1, "91f56ca74fe264d63ddde2e5cc80b1002a8ed52773c80dcff05c87a84628f2bb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(107821)
