-- Lua provided by RyzenAPI
-- Game: Trials Of Randoom

-- MAIN APPLICATION
addappid(2435410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435411, 1, "f029e46c0798591387ab0bf2228c8b2c0a63fadd0a52bb2f437b48903da210a7")

