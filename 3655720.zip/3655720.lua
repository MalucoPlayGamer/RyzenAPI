-- Lua provided by RyzenAPI
-- Game: addappid(3655720)

-- MAIN APPLICATION
addappid(3655720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655721, 1, "c4790bf29ddef6645fc67bde81502984c7c46c4c1b1d34ca60e163e0fb02f044")
