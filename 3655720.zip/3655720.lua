-- Lua provided by SkyAPI 
-- Game: STELLAR INC - Internship
addappid(3655720)
addappid(3655721, 1, "c4790bf29ddef6645fc67bde81502984c7c46c4c1b1d34ca60e163e0fb02f044")
