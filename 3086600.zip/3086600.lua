-- Lua provided by RyzenAPI
-- Game: Sex Clinic 18+

-- MAIN APPLICATION
addappid(3086600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086601, 1, "fa072ba5da4de8aa6c3d00221ae30af052f8f82ca7f39e31add49d9a086520e7")
