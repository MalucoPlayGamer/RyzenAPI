-- Lua provided by RyzenAPI
-- Game: Medal of Honor™

-- MAIN APPLICATION
addappid(47790)
addappid(47844)

-- MAIN APP DEPOTS / PACKAGES
addappid(47791, 1, "6cfa2ae2ab1ca45d932583d4bb09d81a32c9dab59bc81ff78093b7f86b2c5f22")
addappid(47792, 1, "1aed186dafde484880853967cc9874f7425d3f393a50e62ff1ce07eb915c74cb")
addappid(47793, 1, "a388975b420de37f5a325f11a0e0a99849af69cd09a02f4c334942f031fd1dce")
addappid(47794, 1, "3ccf090b82a45af81dc25d44b74a5d6ad120875a3b3c3b6aa21bfcd38b2d24ad")
addappid(47795, 1, "6186ccb802d9cce2ac254f712dc8a5ede302565775356493e829ac607525054e")
addappid(47796, 1, "8c769e57b4d08d2c9b5407f027d59a2acdaca21a7e8791a47ffb45201c7eaa02")
addappid(47797, 1, "b7f8041cc9fd835c22d739802217bb2dc2fa54e64520fbfb8b7f33f3d120b65e")
addappid(47799, 1, "8142793c31d69d6640fd8ccbbba480801eeaafe945634eb1946055c8aca0ef27")
addappid(47820, 0, "f12001624d2e8a0fad874d33319a7eb0a2e51d46c22945c639cf97e91a0dae16")
addappid(47821, 0, "154cdd68bc04e8f157c1988fd384d055bc5ad9c097f7e66193bdc471b9a6e9ad")
addappid(47822, 0, "31446e9f0f16284a65881537af62c26a2a264f7c1c72a1939055340e162b2cf5")
addappid(47843, 0, "c08bc5097b66053a150c8bb80e515404645372a0c8aaa09f43adce34c980219d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(47842)
