-- Lua provided by RyzenAPI
-- Game: EndlessCar

-- MAIN APPLICATION
addappid(2371510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371511, 1, "9b1d7b0a8d1428c842f0f02f11d101bbb03baf18aeb0d6730aef49e2308e64a7")
