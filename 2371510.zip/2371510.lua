-- Lua provided by RyzenAPI
-- Game: EndlessCar

-- MAIN APPLICATION
addappid(2371510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371511, 1, "9b1d7b0a8d1428c842f0f02f11d101bbb03baf18aeb0d6730aef49e2308e64a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
