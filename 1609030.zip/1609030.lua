-- Lua provided by RyzenAPI
-- Game: Game: Immortus Temporus

-- MAIN APPLICATION
addappid(1609030)
-- Game: addappid(1609030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609031, 1, "ebf70ac9985c45724415eb7597556c72cbcd43ec486c472abe5ecd782a761150")
