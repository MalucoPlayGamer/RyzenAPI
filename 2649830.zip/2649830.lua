-- Lua provided by RyzenAPI
-- Game: Paradise Road

-- MAIN APPLICATION
addappid(2649830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649831, 1, "8660da9140398b2cdce751ac2423bc73402819970db6c7a43e6c8fad49c6a00c")
