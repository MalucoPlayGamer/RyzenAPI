-- Lua provided by RyzenAPI
-- Game: SUPER FLAIL

-- MAIN APPLICATION
addappid(891130)
addappid(898110)

-- MAIN APP DEPOTS / PACKAGES
addappid(891131,0,"e2699691665e8fef53930f86a383ee9f87a5ec75d08adc549d602edffb0b1527")

