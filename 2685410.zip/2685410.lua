-- Lua provided by SkyAPI 
-- Game: SPEEDUS -SHEDDING SPEED CARD-
addappid(2685410)
addappid(2685411, 1, "a0160c58bee75bdee77287ebfeb49e8f250ba6e9c13aac52994641529f19667c")
