-- Lua provided by RyzenAPI
-- Game: 2685410

-- MAIN APPLICATION
addappid(2685410)
-- Game: addappid(2685410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685411, 1, "a0160c58bee75bdee77287ebfeb49e8f250ba6e9c13aac52994641529f19667c")
