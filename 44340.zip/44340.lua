-- Lua provided by RyzenAPI
-- Game: Operation Flashpoint: Red River

-- MAIN APPLICATION
addappid(44340)

-- MAIN APP DEPOTS / PACKAGES
addappid(44341, 1, "f48417fce714ae6529de1fec6a0449360b43ec88618964133b2d53c6c6903bde")

