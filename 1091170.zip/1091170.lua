-- Lua provided by RyzenAPI
-- Game: Face Your Demons

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(1091170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091172,0,"2c595bf1ddea20fbf01fd29a12196991109ba5f22ca6c6337475c94e2a4f274d")

