-- Lua provided by SkyAPI 
-- Game: 有请祖师爷
addappid(2903680)
addappid(2903681, 1, "4789a6379ceb489c7189947cea5a8ee939b83cd6855125e2efed5d7c8a1eebaa")
