-- Lua provided by RyzenAPI
-- Game: 有请祖师爷

-- MAIN APPLICATION
addappid(2903680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903681, 1, "4789a6379ceb489c7189947cea5a8ee939b83cd6855125e2efed5d7c8a1eebaa")

