-- Lua provided by RyzenAPI
-- Game: Game: Gloom: Digital Edition

-- MAIN APPLICATION
addappid(766040)
addappid(771270)
-- Game: addappid(766040)

-- MAIN APP DEPOTS / PACKAGES
addappid(766041, 1, "53dbccb204c23cc06ec0cd6e2e15fe0ed4b1aa83487ee1c676e6883581369ae0")
