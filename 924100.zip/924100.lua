-- Lua provided by RyzenAPI
-- Game: addappid(924100)

-- MAIN APPLICATION
addappid(924100)

-- MAIN APP DEPOTS / PACKAGES
addappid(924101, 1, "5b251caa263e8f56d8691e75b8cd74cb97158e293dd2971d4a688002850db416")
