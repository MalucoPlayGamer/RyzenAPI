-- Lua provided by RyzenAPI
-- Game: K-Bot

-- MAIN APPLICATION
addappid(2949350) -- K-Bot

-- MAIN APP DEPOTS / PACKAGES
addappid(2949351, 1, "206886499d994a1a5a28fdb23de050fb56d477a14be53687ccda730462b75ead") -- Depot 2949351

