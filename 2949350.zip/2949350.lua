-- 2949350's Lua and Manifest Created by Hubcap Manifest
-- K-Bot
-- Created: August 07, 2026 at 07:23:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2949350) -- K-Bot
-- MAIN APP DEPOTS
addappid(2949351, 1, "206886499d994a1a5a28fdb23de050fb56d477a14be53687ccda730462b75ead") -- Depot 2949351
setManifestid(2949351, "7880238121626499262", 529380478)