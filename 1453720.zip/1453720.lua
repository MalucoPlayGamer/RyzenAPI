-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1453720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453720,0,"fc129e773a5d0bbe78635edf07ef59b4dfc0a328d57b2f87cf1174831747701e")
