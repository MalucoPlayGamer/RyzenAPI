-- Lua provided by SkyAPI 
-- Game: AppID 1870080
addappid(1870080)
addappid(1870081, 1, "4b90fa6100a2a27ae237d83f6c9c78b3f3ba9e218efb1d1d6383f76ce4f71e5a")
