-- Lua provided by RyzenAPI
-- Game: Night of the Blood Moon

-- MAIN APPLICATION
addappid(894000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(894001, 1, "6210c157cfa40b28ca5a4199e3823265046c66de5cc673de85366cf30775aea6")

