-- Lua provided by RyzenAPI
-- Game: addappid(894000)

-- MAIN APPLICATION
addappid(894000)

-- MAIN APP DEPOTS / PACKAGES
addappid(894001, 1, "6210c157cfa40b28ca5a4199e3823265046c66de5cc673de85366cf30775aea6")
