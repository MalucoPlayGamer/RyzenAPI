-- Lua provided by RyzenAPI 
-- Game: Visual Novel Sisters
addappid(1734890)
addappid(1734891, 1, "cd5a7b16498fd11e237b1beedc895133a8cd0cf4a462e1351bdad2836e1359de")
