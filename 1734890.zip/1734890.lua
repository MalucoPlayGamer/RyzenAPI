-- Lua provided by RyzenAPI
-- Game: addappid(1734890)

-- MAIN APPLICATION
addappid(1734890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734891, 1, "cd5a7b16498fd11e237b1beedc895133a8cd0cf4a462e1351bdad2836e1359de")
