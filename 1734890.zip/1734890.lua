-- Lua provided by RyzenAPI
-- Game: Visual Novel Sisters

-- MAIN APPLICATION
addappid(1734890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734891, 1, "cd5a7b16498fd11e237b1beedc895133a8cd0cf4a462e1351bdad2836e1359de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
