-- Lua provided by RyzenAPI
-- Game: Clicker Kids

-- MAIN APPLICATION
addappid(4355950)

