-- Lua provided by SkyAPI 
-- Game: Liquidator 2: Welcome to Hell
addappid(3302510)
addappid(3302511, 1, "d194cf03ef1a5ace603e2e24a3522ac6037faa691924d9149b9355751283b898")
addappid(3302512, 1, "8fb04c2c5a69941be74b45c59417d4b20200097afda72e1caae393df17df57be")
