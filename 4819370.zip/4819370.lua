-- Lua provided by RyzenAPI
-- Game: Spanking Exorcist

-- MAIN APPLICATION
addappid(4819370)

-- MAIN APP DEPOTS / PACKAGES
addappid(4819371,0,"61ce6fb2cbeba5e269c0564c77d19e3a005fac69cc490d2275cfacac83ddfdf2")

