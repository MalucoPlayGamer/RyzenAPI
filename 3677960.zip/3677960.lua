-- Lua provided by RyzenAPI
-- Game: University Days - Bonus Pack 2

-- MAIN APPLICATION
addappid(3677960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3677960,0,"9d6ae0282049c6887d8aea748c41f686b0fa68aa29d8dfd2ad56beb0350189b8")

