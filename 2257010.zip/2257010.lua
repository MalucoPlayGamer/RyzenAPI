-- Lua provided by RyzenAPI
-- Game: Game: Creeper World IXE

-- MAIN APPLICATION
addappid(2257010)
-- Game: addappid(2257010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257011, 1, "ce36e6c98c6147f97538dec5ded6171d705e6d04ff37e82515f2563ee16e719c")
