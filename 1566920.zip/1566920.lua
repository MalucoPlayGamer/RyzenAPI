-- Lua provided by RyzenAPI
-- Game: Booble H

-- MAIN APPLICATION
addappid(1566920)
-- Game: addappid(1566920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566921, 1, "364bcca4c2042b72db122e5b298bddff0892882b613eee237ac7efc2d68ab3f0")
