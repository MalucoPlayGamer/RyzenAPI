-- Lua provided by SkyAPI 
-- Game: Booble H
addappid(1566920)
addappid(1566921, 1, "364bcca4c2042b72db122e5b298bddff0892882b613eee237ac7efc2d68ab3f0")
