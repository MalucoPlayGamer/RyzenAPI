-- Lua provided by SkyAPI 
-- Game: Timberman: The Big Adventure
addappid(2589910)
addappid(2589911, 1, "d67a22baf35c1cc51912afb9ad69c4cb4d2b93245fdd0fc09f3bcc612f7ef734")
