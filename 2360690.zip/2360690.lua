-- Lua provided by RyzenAPI
-- Game: Pixel Ripped 1978: An Atari Adventure

-- MAIN APPLICATION
addappid(2360690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360691, 1, "9667a041890a3b6f29f2295daf3bfa352b4e90480ee4a5c85967fd90e7a81bc0")
