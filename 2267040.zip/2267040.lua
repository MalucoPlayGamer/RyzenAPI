-- Lua provided by SkyAPI 
-- Game: Light the Backrooms
addappid(2267040)
addappid(2267041, 1, "dfc69123828f1b1a08aacc2504a95b6d7c8cb87e2f3e4ca619e26b5bc9a20bc9")
