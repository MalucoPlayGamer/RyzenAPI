-- Lua provided by RyzenAPI
-- Game: Light the Backrooms

-- MAIN APPLICATION
addappid(2267040)
-- Game: addappid(2267040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267041, 1, "dfc69123828f1b1a08aacc2504a95b6d7c8cb87e2f3e4ca619e26b5bc9a20bc9")
