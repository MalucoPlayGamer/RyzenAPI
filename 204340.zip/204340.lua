-- Lua provided by SkyAPI 
-- Game: Serious Sam II
addappid(204340)
addappid(204341, 1, "378c61c3fdef5d82815ce8b6ba81abb1083453372412c1101fb7a97753bf09c2")
