-- Lua provided by SkyAPI 
-- Game: Necrosmith 2 Demo
addappid(2337020)
addappid(2337021, 1, "b9ce0b534252c8217edc623aa221150910d8c691524e9ae06f55fba1a0931526")
