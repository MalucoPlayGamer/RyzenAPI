-- Lua provided by RyzenAPI
-- Game: Game: AppID 911480

-- MAIN APPLICATION
addappid(911480)
-- Game: addappid(911480)

-- MAIN APP DEPOTS / PACKAGES
addappid(911481, 1, "000b520b72d6ecc1b9047d8ce58e8e8bcdfa5a0a4ee44376a919f1cf14260043")
