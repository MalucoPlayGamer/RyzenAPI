-- Lua provided by RyzenAPI
-- Game: Game: 100 Doors: Escape from Work

-- MAIN APPLICATION
addappid(1684530)
-- Game: addappid(1684530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684531, 1, "86f4676ff58fab95fbdc1625cf55944ffa0216043d93b33d264df5ce230f63a5")
