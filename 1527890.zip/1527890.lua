-- Lua provided by RyzenAPI
-- Game: Dysterra

-- MAIN APPLICATION
addappid(1527890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527891, 1, "bf20d56bd33a233719ff20a96208010e3d37d0007ad132188fd4450b8c50e729")

