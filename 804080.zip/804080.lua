-- Lua provided by RyzenAPI
-- Game: AppID 804080

-- MAIN APPLICATION
addappid(804080)
-- Game: addappid(804080)

-- MAIN APP DEPOTS / PACKAGES
addappid(804081, 1, "38a1a9535accae11ef5ab963a944171c483d976a5203a811c306451a2de800a1")
