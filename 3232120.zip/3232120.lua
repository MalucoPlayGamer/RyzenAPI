-- Lua provided by RyzenAPI
-- Game: Otherskin Demo

-- MAIN APPLICATION
addappid(3232120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232121, 1, "02da996e886eb84957d8d0c1b7dfd99162e6d013e41b91dae61a4ec294a9839b")

