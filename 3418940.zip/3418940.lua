-- Lua provided by RyzenAPI
-- Game: Game: Dolls Nest Demo

-- MAIN APPLICATION
addappid(3418940)
-- Game: addappid(3418940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418941, 1, "fb590f14b08b706eddbf7561ed6a68871ac4bea251c873c49134c707b5edb116")
