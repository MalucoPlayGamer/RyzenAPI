-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1171460)
-- Game: addappid(1171460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171460,0,"c5c76c17e5514f574a7df2a486961bce45f0b4f018c47b29f56259450620c756")
