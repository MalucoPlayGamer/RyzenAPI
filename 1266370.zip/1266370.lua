-- Lua provided by RyzenAPI
-- Game: addappid(1266370)

-- MAIN APPLICATION
addappid(1266370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266371, 1, "c480a0074a813ddc2e4d88352e68cd9cdf202ff01fba97e5c05998b5f2d66cc2")
