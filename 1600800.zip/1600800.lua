-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Typhoon Rising

-- MAIN APPLICATION
addappid(1600800)
-- Game: addappid(1600800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600800,0,"5869e7885aad4fb3342b4bee2056c86aa82a2e29959f74072dc4bca9b3372b1d")
