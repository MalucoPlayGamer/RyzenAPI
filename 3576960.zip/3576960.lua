-- Lua provided by RyzenAPI
-- Game: I wanna fuck my daughter’s besties

-- MAIN APPLICATION
addappid(3576960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3576961, 1, "d676b17b027578ca2a921ffe46a5d9052700e5467fff9d7ea2898aebb97b0b53")
