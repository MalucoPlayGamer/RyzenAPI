-- Lua provided by RyzenAPI
-- Game: LostWinds 2: Winter of the Melodias

-- MAIN APPLICATION
addappid(447800)

-- MAIN APP DEPOTS / PACKAGES
addappid(447801, 1, "a11daee00340e01e51476bad7b863f44240e382f66e93e26a1aac09080a32e48")
