-- Lua provided by RyzenAPI
-- Game: addappid(2369210)

-- MAIN APPLICATION
addappid(2369210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369211, 1, "928193b42db42c750f710c026b4b6ad97baf908e9a612fcb36ee9bd0885c76f7")
