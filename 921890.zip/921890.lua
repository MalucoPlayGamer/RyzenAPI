-- Lua provided by RyzenAPI
-- Game: Retro Rockets

-- MAIN APPLICATION
addappid(921890)

-- MAIN APP DEPOTS / PACKAGES
addappid(921893,0,"98a7c72fa07bfeb3c3ec645c088489af38c0759e86ebe583f3cdc0c31b731e07")
addappid(921894,0,"9c0f52dcc38fa1d7edbf68158a26f6760d225fce1c2b8f67aa26d57cf762d479")

