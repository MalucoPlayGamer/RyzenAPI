-- Lua provided by RyzenAPI 
-- Game: AppID 981310
addappid(981310)
addappid(981311, 1, "d728fa62bb676561308ba21ec43f1fb03380243228d2b7084f0c7aa1939582d8")
