-- Lua provided by RyzenAPI
-- Game: Game: Odd||Even

-- MAIN APPLICATION
addappid(455940)
-- Game: addappid(455940)

-- MAIN APP DEPOTS / PACKAGES
addappid(455941, 1, "94ab8bbf4ee057fee051793ac50b52657edb04357c441fa6015f8ee6b8fc0103")
