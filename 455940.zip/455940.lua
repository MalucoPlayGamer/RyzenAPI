-- Lua provided by RyzenAPI
-- Game: Odd||Even

-- MAIN APPLICATION
addappid(455940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(455941, 1, "94ab8bbf4ee057fee051793ac50b52657edb04357c441fa6015f8ee6b8fc0103")

