-- Lua provided by RyzenAPI
-- Game: Game: Nomad Fleet

-- MAIN APPLICATION
addappid(371010)
-- Game: addappid(371010)

-- MAIN APP DEPOTS / PACKAGES
addappid(371011, 1, "9160563155d93b972ef89bb4f6b91e0a2929be924ee473941d98cd297bae8525")
addappid(371012, 1, "6d76f85e2242f372d001058432b2a75a07cfb1de8b890d8b6596ff1ded5d9e56")
