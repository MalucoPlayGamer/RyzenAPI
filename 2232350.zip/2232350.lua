-- Lua provided by RyzenAPI
-- Game: AppID 2232350

-- MAIN APPLICATION
addappid(2232350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232351, 1, "c70ef8685857ddae9aa8feaf78433b45fe831c057cfb6349e9cf5f5e65f89ba8")

