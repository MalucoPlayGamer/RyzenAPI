-- Lua provided by RyzenAPI
-- Game: Game: satori

-- MAIN APPLICATION
addappid(3519830)
-- Game: addappid(3519830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519831, 1, "31475758b4695d435f7a2b57be1d52c351d2d3b63ab719bbe4f1885e24fbb4a5")
