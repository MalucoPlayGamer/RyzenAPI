-- Lua provided by RyzenAPI
-- Game: Up in the Air

-- MAIN APPLICATION
addappid(969220)
-- Game: addappid(969220)

-- MAIN APP DEPOTS / PACKAGES
addappid(969221, 1, "484b54e85a5a93a753baa714588a7a6d53636b163f48c58fdfd96d03f347d174")
