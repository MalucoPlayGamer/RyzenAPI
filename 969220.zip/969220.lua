-- Lua provided by RyzenAPI
-- Game: Up in the Air

-- MAIN APPLICATION
addappid(969220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(969221, 1, "484b54e85a5a93a753baa714588a7a6d53636b163f48c58fdfd96d03f347d174")

