-- Lua provided by RyzenAPI
-- Game: addappid(1341530)

-- MAIN APPLICATION
addappid(1341530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341530,0,"7592fd3dbea283372e34a364ac37fefdca161c07425c0347085a8d0c782324cb")
