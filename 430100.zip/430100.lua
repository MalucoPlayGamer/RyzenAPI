-- Lua provided by RyzenAPI
-- Game: darkcase : the basement

-- MAIN APPLICATION
addappid(430100)

-- MAIN APP DEPOTS / PACKAGES
addappid(430101, 1, "254412b933dd771f1b78b9bbd401f6b8de2c8670f1c38347bf1699b3efac5ee1")

