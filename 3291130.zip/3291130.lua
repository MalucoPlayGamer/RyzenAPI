-- Lua provided by RyzenAPI
-- Game: 3291130

-- MAIN APPLICATION
addappid(3291130)
-- Game: addappid(3291130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291131, 1, "c7db65b13ad8671a51ba999a8238edf09d6f834a7498084d43da815a1cffe23f")
