-- Lua provided by RyzenAPI
-- Game: QR DEAD

-- MAIN APPLICATION
addappid(3291130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291131, 1, "c7db65b13ad8671a51ba999a8238edf09d6f834a7498084d43da815a1cffe23f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
