-- Lua provided by RyzenAPI 
-- Game: WitchHand
addappid(2420880)
addappid(2420881, 1, "3b660069e03fcff6e9ab7a299c86f5b5f8841ec332c0c9cc6eb6d323fec69078")
