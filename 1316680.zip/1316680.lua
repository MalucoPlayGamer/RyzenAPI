-- Lua provided by RyzenAPI
-- Game: Game: VLADiK BRUTAL

-- MAIN APPLICATION
addappid(1316680)
-- Game: addappid(1316680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316681, 1, "5ffddaa8a208d452dbf7149e9c82bfd278682c10b1262d32c0159db65bdf4644")
