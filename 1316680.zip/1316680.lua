-- Lua provided by SkyAPI 
-- Game: VLADiK BRUTAL
addappid(1316680)
addappid(1316681, 1, "5ffddaa8a208d452dbf7149e9c82bfd278682c10b1262d32c0159db65bdf4644")
