-- Lua provided by RyzenAPI
-- Game: BLUE REFLECTION: Second Light

-- MAIN APPLICATION
addappid(1423600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423601, 1, "f3c8f849e1c922ecda08f1e76f461a6662d182257e39f122e32fdb1ed0d6e320")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1744810)
addappid(1744811)
addappid(1744812)
addappid(1744813)
addappid(1744814)
addappid(1744815)
addappid(1744816)
addappid(1744817)
addappid(1744818)
addappid(1744819)
addappid(1744830)
addappid(1744831)
addappid(1744832)
addappid(1744833)
addappid(1744834)
addappid(1744835)
addappid(1744836)
addappid(1744837)
addappid(1744838)
addappid(1744839)
addappid(1744840)
addappid(1744841)
addappid(1744842)
addappid(1744843)
