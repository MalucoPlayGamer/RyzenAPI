-- Lua provided by RyzenAPI
-- Game: addappid(1423600)

-- MAIN APPLICATION
addappid(1423600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423601, 1, "f3c8f849e1c922ecda08f1e76f461a6662d182257e39f122e32fdb1ed0d6e320")
