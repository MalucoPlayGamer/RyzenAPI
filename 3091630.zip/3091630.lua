-- Lua provided by SkyAPI 
-- Game: AppID 3091630
addappid(3091630)
addappid(3091631, 1, "107f8f74e5ed3aced2938fa3d54e634315df282fb0b11b6b6f9a366fc5c2266c")
