-- Lua provided by RyzenAPI
-- Game: Free Stars: The Ur-Quan Masters

-- MAIN APPLICATION
addappid(2645580)
-- Game: addappid(2645580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645581, 1, "2c5641beaf32b93a57fe5c979ecaf640f4f2b06c78cf7132afad7147df70a331")
addappid(2645583, 1, "afab866a01034f1a92ef89a782136b99b054b924d2f2643313ffa59f3779e589")
