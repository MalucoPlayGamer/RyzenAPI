-- Lua provided by RyzenAPI
-- Game: addappid(3055120)

-- MAIN APPLICATION
addappid(3055120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3055121, 1, "d82ca8ce719e11feeee2f5bc7a5b3e59088a9dc9dbcae22044614d7a0d9f6574")
