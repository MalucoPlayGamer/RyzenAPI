-- Lua provided by RyzenAPI
-- Game: addappid(3532570)

-- MAIN APPLICATION
addappid(3532570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3532571, 1, "6bedb273560f17c608c117800aad7e6b12e9d2cc249022362e9b5759aa7effb5")
