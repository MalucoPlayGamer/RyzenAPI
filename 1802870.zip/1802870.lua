-- Lua provided by RyzenAPI
-- Game: Secret Pie (Adult Version)

-- MAIN APPLICATION
addappid(1802870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802871, 1, "ccad7ba97d05ac6585875c572974cf0ac57176ddc9f087e67cd77b2adb9d2af8")
