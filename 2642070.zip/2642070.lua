-- Lua provided by RyzenAPI
-- Game: Game: Block Strategy

-- MAIN APPLICATION
addappid(2642070)
-- Game: addappid(2642070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642071, 1, "5b873e802c3a809d56e697aac7d82b99dde97d5a1680df89b39c58c1e5b7eb75")
