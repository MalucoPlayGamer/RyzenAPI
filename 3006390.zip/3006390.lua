-- Lua provided by RyzenAPI
-- Game: Micron Defense Force Demo

-- MAIN APPLICATION
addappid(3006390)
-- Game: addappid(3006390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006391, 1, "18f54a4d98e58f18ad926d66cae8aaeec2c8dda75a9c5be8947424aaf293754a")
