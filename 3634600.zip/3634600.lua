-- Lua provided by RyzenAPI
-- Game: Game: Post Trauma Soundtrack

-- MAIN APPLICATION
addappid(3634600)
-- Game: addappid(3634600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3634601, 1, "369ae4824204e137636f5db7149c7128db6f79179b7b8e5f014e370826eee51b")
