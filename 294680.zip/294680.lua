-- Lua provided by RyzenAPI
-- Game: addappid(294680)

-- MAIN APPLICATION
addappid(294680)
addappid(303150)
addappid(303151)
addappid(303152)
addappid(303153)
addappid(303154)
addappid(303155)
addappid(303156)
addappid(303157)
addappid(303158)
addappid(303159)

-- MAIN APP DEPOTS / PACKAGES
addappid(294681, 1, "ecc91c0818274f9d8011f6e2041a0dd803a3a47600a4f36f6bc37db170f348e3")
addappid(294684, 1, "f3df77947c5c67a5cbdb9df92af34a4c9e7d519faa6d7bc4bbbac67361925a1a")
addappid(294685, 1, "fe44f59a3f247af3dddf71c46562ff4967f9bfb770981f6caf47aa7b44463548")
