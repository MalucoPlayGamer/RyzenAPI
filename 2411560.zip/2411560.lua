-- Lua provided by RyzenAPI
-- Game: 2411560

-- MAIN APPLICATION
addappid(2411560)
-- Game: addappid(2411560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411561, 1, "7155e26af60f637865c73cb3cdb6ac65fe4c0bf48766ecd705a8c5b4029f7c81")
