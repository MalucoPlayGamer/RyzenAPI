-- Lua provided by RyzenAPI
-- Game: Game: MXGP 24: The Official Game

-- MAIN APPLICATION
addappid(2603040)
-- Game: addappid(2603040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603041, 1, "454821620b726cdecaf413e240648c5b98644e910fa00e33d8c371c1f89c4ea1")
