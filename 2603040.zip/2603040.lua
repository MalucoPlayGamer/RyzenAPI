-- Lua provided by RyzenAPI
-- Game: MXGP 24: The Official Game

-- MAIN APPLICATION
addappid(2603040)
addappid(3283530)
addappid(3283540)
addappid(3283550)
addappid(3283560)
addappid(3283570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2603041, 1, "454821620b726cdecaf413e240648c5b98644e910fa00e33d8c371c1f89c4ea1")

