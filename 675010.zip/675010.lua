-- Lua provided by RyzenAPI
-- Game: 675010

-- MAIN APPLICATION
addappid(675010)
addappid(782230)
addappid(816790)
addappid(891810)
addappid(1024110)
-- Game: addappid(675010)

-- MAIN APP DEPOTS / PACKAGES
addappid(675011, 1, "749a4be682fa56571865b3249aacc549792f6f6ddfab61e79d83c5f8a0f7e5ae")
addappid(740380, 0, "a1ab275cc57ae73840105deab47a62f789ab19722e89bc6c6c8663c453b6f09c")
