-- Lua provided by RyzenAPI
-- Game: Kingdom of Cards

-- MAIN APPLICATION
addappid(3160500)
-- Game: addappid(3160500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160501, 1, "d38985ce515aca8fc52fac0ace682a9ff7fe646d423661b251c2578bb1e3a461")
