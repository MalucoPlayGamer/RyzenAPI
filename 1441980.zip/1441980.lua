-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy

-- MAIN APPLICATION
addappid(1441980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441980,0,"0f4289de6a49a7b1f0ffe8f4db81a8be9741340c4410dc2df91fa8a05460d10f")
