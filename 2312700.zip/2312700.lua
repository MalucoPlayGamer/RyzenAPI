-- Lua provided by SkyAPI 
-- Game: Children of the Sun Demo
addappid(2312700)
addappid(2312701, 1, "1bdf757c91d8c5629bcb19059ae7af8089dc6411ffc79c9cae9619b61be1ef66")
