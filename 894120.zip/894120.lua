-- Lua provided by RyzenAPI
-- Game: Game: Ghostman: The Council Calamity

-- MAIN APPLICATION
addappid(894120)
-- Game: addappid(894120)

-- MAIN APP DEPOTS / PACKAGES
addappid(894121, 1, "e5c146ee5dae6c981a8177c59ec18f1190ee1cb8e670fe2028d2e13e28ab8e26")
