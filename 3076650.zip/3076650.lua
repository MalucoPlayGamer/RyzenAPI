-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3076650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864591,0,"c58f51fb6911539a3f2db893727e44a1df112db9632a17c4ff846811228eacce")

