-- Lua provided by RyzenAPI
-- Game: SeaColony

-- MAIN APPLICATION
addappid(4661260) -- SeaColony

-- MAIN APP DEPOTS / PACKAGES
addappid(4661261, 1, "addb23bfcfcd2670b6b22d74055cafa3de345831e1133284789046786473606b") -- Depot 4661261

