-- 4661260's Lua and Manifest Created by Hubcap Manifest
-- SeaColony
-- Created: August 26, 2026 at 02:36:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4661260) -- SeaColony
-- MAIN APP DEPOTS
addappid(4661261, 1, "addb23bfcfcd2670b6b22d74055cafa3de345831e1133284789046786473606b") -- Depot 4661261
setManifestid(4661261, "214642601048263115", 293577840)