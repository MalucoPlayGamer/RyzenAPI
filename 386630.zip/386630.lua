-- Lua provided by RyzenAPI
-- Game: Game: Nirvana: The First Travel

-- MAIN APPLICATION
addappid(386630)
-- Game: addappid(386630)

-- MAIN APP DEPOTS / PACKAGES
addappid(386631, 1, "819e5000548e96aaf6d3237f78a0c1479ce80faff9b0f8868173000af5f49291")
