-- Lua provided by RyzenAPI
-- Game: King's Bounty: Warriors of the North

-- MAIN APPLICATION
addappid(203350)

-- MAIN APP DEPOTS / PACKAGES
addappid(203351, 1, "74a41415599a165d97dc582988c98068a53273affdb9d3a72a65ab4237ce1701")
addappid(203352, 1, "33da78bd1183ab99f4731479bbf7c23c95264a8d6819d70afdae4acb9778c720")
addappid(203353, 1, "b846f2b168a086e483a26df768f7e9d2ca0af7637e0062aab2dc7491fd8b19e7")
addappid(203354, 1, "99aec16a7df575c84b1d7057210c8e1658de622687ccb733c2557c255045a89a")
addappid(203355, 1, "36b6605e1b5cf63dc53e1b3d16cfab5dcfea8c1a1648c214bc4dfb16c5b9aa4f")
addappid(203356, 1, "6a7b489ec960ef5334c79aa1421e9c3c2a610b5429bc9403a22ff5d93abe7503")
addappid(203357, 1, "495837763bef23c2551fdf4404e987989b3e9c178b0155d211689afd6fbd0b14")
addappid(203358, 0, "7e666dff98b77f98e16680d8ad97ad6cd406e144e4cce8702c8eaaf394875a30")
addappid(203359, 1, "79c8eb9f4c833df6aa5dc4d6a76032fb4feedf80d8c0b1b199e077674252248f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
