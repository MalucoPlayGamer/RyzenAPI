-- Lua provided by RyzenAPI
-- Game: HAINYA WORLD

-- MAIN APPLICATION
addappid(1299030)
addappid(3092650)
addappid(3093940)
addappid(3628140)
addappid(3628150)
addappid(3628160)
addappid(3628170)
addappid(3628180)
addappid(3628190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1299031, 1, "2f0518064c1db2b4844e6d6e3c886398f4bbdd02c0614f3a5c66bb01a775421e")

