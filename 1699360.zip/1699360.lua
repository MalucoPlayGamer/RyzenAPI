-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Tyler Warren RPG Battlers - 5th 50

-- MAIN APPLICATION
addappid(1699360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699360,0,"d17c6b08941384d875ff7678174578f365c4246486c889d96ae0fa6a188447fd")

