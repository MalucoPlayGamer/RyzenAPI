-- Lua provided by SkyAPI 
-- Game: Blocks Challenge
addappid(3225120)
addappid(3225121, 1, "9c1c3d09d9bd2cd0509d5ac8a7fceb940b12cf73e903a926a28e6d27f347d701")
