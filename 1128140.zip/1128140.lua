-- Lua provided by RyzenAPI
-- Game: Game: AppID 1128140

-- MAIN APPLICATION
addappid(1128140)
-- Game: addappid(1128140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128141, 1, "922d8ea6d2ab798c0680add500e7d2cdc5e4b3b37cabb08db66f58b301bf8c21")
