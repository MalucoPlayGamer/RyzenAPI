-- Lua provided by RyzenAPI 
-- Game: AppID 789770
addappid(789770)
addappid(789771, 1, "6ad939151222d80401841c82845a0da644d975f601040e97b4fa421fbbbf240b")
