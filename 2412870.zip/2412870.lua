-- Lua provided by RyzenAPI
-- Game: Game: BIKEOUT Demo

-- MAIN APPLICATION
addappid(2412870)
-- Game: addappid(2412870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412871, 1, "e30571ba0792faec95c30b45e21c4caa2bf2007085b3e7593548013f60293680")
