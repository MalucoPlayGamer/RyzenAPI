-- Lua provided by SkyAPI 
-- Game: BIKEOUT Demo
addappid(2412870)
addappid(2412871, 1, "e30571ba0792faec95c30b45e21c4caa2bf2007085b3e7593548013f60293680")
