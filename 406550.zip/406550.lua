-- Lua provided by RyzenAPI
-- Game: 406550

-- MAIN APPLICATION
addappid(406550)
-- Game: addappid(406550)

-- MAIN APP DEPOTS / PACKAGES
addappid(406551, 1, "e75ace7261010d5f7159124e7b433f0aa26dfbe0367c396cafe3152a3fc988a6")
