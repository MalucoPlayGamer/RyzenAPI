-- Lua provided by RyzenAPI
-- Game: Prose & Codes

-- MAIN APPLICATION
addappid(1718910)
-- Game: addappid(1718910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718915,0,"11400fb46d4ada5b8d15f66f78c98132895914473d7a9e69a0a6e02426f16206")
