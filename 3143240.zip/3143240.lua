-- Lua provided by RyzenAPI
-- Game: To The Grave: The Wildlands of Faenora Demo

-- MAIN APPLICATION
addappid(3143240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143241, 1, "7f604d6c6bd3f6dcdcb7259f5e8e5f41aa6747b5d3cda85b643763cb65e392bd")
