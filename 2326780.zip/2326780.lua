-- Lua provided by RyzenAPI
-- Game: Embarrassed Shina-chan~ the Naked Wandering College Girl

-- MAIN APPLICATION
addappid(2326780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326781, 1, "e9e24a44e634d4a0aa306cbfa8583fe2d9bdb1badcd95218e3f6b4e8d2c1d48a")
addappid(2326782, 1, "8408076fe482e7e1a2523ba6eeefaa556e2fec6fe45f91134012c5dff88897f1")
addappid(2326783, 1, "b584269001d5c9f4ed6b489c50d9f9a34e153bff71bf6b8e832428e0e6df8178")
addappid(2326784, 1, "6ac7a3acd15000d5200ed1c08736895c8ea551b0abba471d8a0f1c8724fa957f")

