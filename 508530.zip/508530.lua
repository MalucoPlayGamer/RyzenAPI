-- Lua provided by RyzenAPI
-- Game: 508530

-- MAIN APPLICATION
addappid(508530)
addappid(615200)
-- Game: addappid(508530)

-- MAIN APP DEPOTS / PACKAGES
addappid(508531, 1, "4f64522b689c96f47578faf8ea4e291c56aeefa2e9767f08cdfe2e9b5716d2d6")
addappid(508532, 1, "3793d2fbfc75fa833a7c4a62e85ef0109e101e5c1fc2353edfbab69bc894ac1c")
