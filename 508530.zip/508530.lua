-- Lua provided by RyzenAPI
-- Game: HackyZack

-- MAIN APPLICATION
addappid(508530)
addappid(615200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(508531, 1, "4f64522b689c96f47578faf8ea4e291c56aeefa2e9767f08cdfe2e9b5716d2d6")
addappid(508532, 1, "3793d2fbfc75fa833a7c4a62e85ef0109e101e5c1fc2353edfbab69bc894ac1c")

