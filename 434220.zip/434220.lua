-- Lua provided by RyzenAPI 
-- Game: Bear Haven Nights
addappid(434220)
addappid(434221, 1, "2b6e728b8bab62928e11c88a69ff362ace76dcb9dcb5038f35009e0ed1c4f6da")
addappid(434222, 1, "21f0d2c499d9e0bf381a4e1ff3d26d91ce3c9cdba58497bf6b4876b30210e938")
addappid(434224, 1, "e1746828d33889dcf6e83ba1845408ab221511febe1341b67441af8c53f8a2b8")
addappid(434225, 1, "f4bac5f0321e51aa4f8e084a7b94d7cdd7621bae6598ea61b82f08125a942c03")
