-- Lua provided by SkyAPI 
-- Game: AppID 1776410
addappid(1776410)
addappid(1776411, 1, "757c577afd0a17c1f4642b481bfb52f6f0ed43112b6fefbc4fa0214e5f8a16b2")
