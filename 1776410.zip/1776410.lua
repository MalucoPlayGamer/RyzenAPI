-- Lua provided by RyzenAPI
-- Game: 1776410

-- MAIN APPLICATION
addappid(1776410)
-- Game: addappid(1776410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776411, 1, "757c577afd0a17c1f4642b481bfb52f6f0ed43112b6fefbc4fa0214e5f8a16b2")
