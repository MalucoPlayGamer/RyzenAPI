-- Lua provided by RyzenAPI
-- Game: 1433700

-- MAIN APPLICATION
addappid(1433700)
-- Game: addappid(1433700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433701, 1, "f3b816883d24e5625481fedfcf93dadd48f373faef3afd5aef7403e9ef11c791")
