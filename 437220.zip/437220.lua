-- Lua provided by RyzenAPI
-- Game: The Culling

-- MAIN APPLICATION
addappid(437220)
addappid(936670)
addappid(942380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(437221, 1, "37a09f126830fbe2d491594d7d538361e6144661dd3618ad53d5e32cb53591e6")
addappid(437222, 1, "975f70c778d9266c5289df68b4dec07b236236a2000a5c32d37f1b23481bcb3c")

