-- Lua provided by RyzenAPI
-- Game: 2323980

-- MAIN APPLICATION
addappid(2323980)
-- Game: addappid(2323980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323981, 1, "ab76c2ce384bc02d59c676ca68a7d77cbc7cae089463bb314b335167d42684bd")
