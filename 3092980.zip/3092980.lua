-- Lua provided by RyzenAPI 
-- Game: MALL MANAGER SIMULATOR
addappid(3092980)
addappid(3092981, 1, "96699788ef76dec5bbcf1402a2668343313df50ee3eafe85bd3d9f267f53dbef")
