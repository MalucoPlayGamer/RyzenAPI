-- Lua provided by RyzenAPI
-- Game: addappid(3092980)

-- MAIN APPLICATION
addappid(3092980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092981, 1, "96699788ef76dec5bbcf1402a2668343313df50ee3eafe85bd3d9f267f53dbef")
