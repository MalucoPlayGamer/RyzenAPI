-- Lua provided by RyzenAPI
-- Game: MALL MANAGER SIMULATOR

-- MAIN APPLICATION
addappid(3092980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092981, 1, "96699788ef76dec5bbcf1402a2668343313df50ee3eafe85bd3d9f267f53dbef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
