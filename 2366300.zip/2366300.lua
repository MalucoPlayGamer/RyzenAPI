-- Lua provided by RyzenAPI
-- Game: Hentai Casual Swap 2

-- MAIN APPLICATION
addappid(2366300)
-- Game: addappid(2366300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366301, 1, "e5bb12786df646f89bfe2262b51b177e3212e3e435708bfbd5fded8f49e7d387")
