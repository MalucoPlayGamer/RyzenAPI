-- Lua provided by RyzenAPI
-- Game: 2308850

-- MAIN APPLICATION
addappid(2308850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308852,0,"acd0f38c7dac43055dcf8ff85b7ebdf8d00d93be3a29f5a8fc5694b9fb87fa1f")
