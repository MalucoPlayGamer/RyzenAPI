-- Lua provided by RyzenAPI
-- Game: 3373730

-- MAIN APPLICATION
addappid(3373730)
-- Game: addappid(3373730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3373731, 1, "129e444e509f697a70ebcdda6fc785b870b68b04aa9c6dfde5b02ef2629b8d57")
