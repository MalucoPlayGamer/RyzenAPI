-- Lua provided by RyzenAPI
-- Game: Steam Prison

-- MAIN APPLICATION
addappid(977460)

-- MAIN APP DEPOTS / PACKAGES
addappid(977461, 1, "8b58b3befad1bde8b678b08f918b99db7e0927f8f19ee31891b92dd4dc987df9")
addappid(1394890, 0, "dfcc747db3f061bf66b9ef78b44f4301ee4e8a3c4edb0c1b35d953b9c2ce1e01")
