-- Lua provided by RyzenAPI
-- Game: Game: My Cat Girl Lover

-- MAIN APPLICATION
addappid(2018640)
-- Game: addappid(2018640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018641, 1, "39213370703abf76ee2e5aff6e504f88aeb0ace009377ddff082b784bb582da3")
addappid(2018642, 1, "04e4cf068f619564d7f15b8d22be493c73c29b265f5ca892225ba777c1ac12aa")
addappid(2018643, 1, "d550f45e3eaa495983d419c199b23c0821c335dae31bfa7d878196bd68db2bce")
addappid(2018644, 1, "c64213ec57073a859f118493d33f9be264ecc62ae77afe119917444747105b7d")
