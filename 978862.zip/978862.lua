-- Lua provided by RyzenAPI
-- Game: 978862

-- MAIN APPLICATION
addappid(978862)
-- Game: addappid(978862)

-- MAIN APP DEPOTS / PACKAGES
addappid(978862,0,"0288eeaad9131f322165721f1f6d230c96a2fd998ee28db8b889978d9ee1b1f0")
