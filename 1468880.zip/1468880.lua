-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - MV Monsters HIBIKI KATAKURA ver Vol.1

-- MAIN APPLICATION
addappid(1468880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468880,0,"ff34309e6239772170c2d94fae650ad2fb09a3ea43c2515141ed8efa5e05f952")

