-- Lua provided by RyzenAPI
-- Game: 1468880

-- MAIN APPLICATION
addappid(1468880)
-- Game: addappid(1468880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468880,0,"ff34309e6239772170c2d94fae650ad2fb09a3ea43c2515141ed8efa5e05f952")
