-- Lua provided by RyzenAPI
-- Game: addappid(2197870)

-- MAIN APPLICATION
addappid(2197870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197871, 1, "abc7ce5351ab654859260686772459bcf95b9fb4d21928ad2e3c9bdc8f002a00")
