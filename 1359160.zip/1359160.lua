-- Lua provided by RyzenAPI
-- Game: Rocket Bots

-- MAIN APPLICATION
addappid(1359160)
addappid(1366190)
-- Game: addappid(1359160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359161, 1, "7d264d74b91ae97b793998f5b32311a6acb7d8a40acd10e7ab2b8eb8462e1a05")
addappid(1359162, 1, "1bfd4030faeb2e9af8bdc6d7c5f27c1047cd8780056f13a38ff8d5bd8c29053c")
