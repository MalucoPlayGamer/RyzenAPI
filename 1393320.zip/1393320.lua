-- Lua provided by RyzenAPI
-- Game: AppID 1393320

-- MAIN APPLICATION
addappid(1393320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393321, 1, "32ec5d912cb54e817f65112a01ae0ace16e4dc37ab110837e61ce978dd8da89e")
