-- Lua provided by RyzenAPI
-- Game: 908830

-- MAIN APPLICATION
addappid(908830)
addappid(908831)
addappid(908832)
addappid(908833)
addappid(908860)
addappid(1003540)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005,0,"aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a")

