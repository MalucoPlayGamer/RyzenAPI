-- Lua provided by RyzenAPI
-- Game: V-Fighter 2000

-- MAIN APPLICATION
addappid(1838800)
-- Game: addappid(1838800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838801, 1, "e63c19279d4b61a90bc113149b6ea35310207ff197a27bcc1a2fb5019082b2d1")
