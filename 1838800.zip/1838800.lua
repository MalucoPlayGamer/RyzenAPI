-- Lua provided by SkyAPI 
-- Game: V-Fighter 2000
addappid(1838800)
addappid(1838801, 1, "e63c19279d4b61a90bc113149b6ea35310207ff197a27bcc1a2fb5019082b2d1")
