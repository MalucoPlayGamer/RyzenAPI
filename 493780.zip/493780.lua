-- Lua provided by RyzenAPI
-- Game: Nightork Adventures - Beyond the Moons of Shadalee

-- MAIN APPLICATION
addappid(493780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(493781, 1, "b96c360840996541939be08408c9d537229a2688f06b3f5e77b93f9b00906b6e")

