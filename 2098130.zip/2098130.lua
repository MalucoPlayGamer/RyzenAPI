-- Lua provided by RyzenAPI
-- Game: International Basketball Manager 23

-- MAIN APPLICATION
addappid(2098130)
-- Game: addappid(2098130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098131, 1, "e671b504085395fc12233ccdbab6ed0bbf7682591ca5778cbcd46c2245cf0ddf")
