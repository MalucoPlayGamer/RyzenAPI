-- Lua provided by RyzenAPI
-- Game: addappid(620040)

-- MAIN APPLICATION
addappid(620040)

-- MAIN APP DEPOTS / PACKAGES
addappid(620041, 1, "e94d7ec869a192a0a6e253057fa74fa60885af3428f5a544cc67831ae5f8bd71")
