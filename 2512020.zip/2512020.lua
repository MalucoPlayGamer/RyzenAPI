-- Lua provided by RyzenAPI
-- Game: Game: Europa Demo

-- MAIN APPLICATION
addappid(2512020)
-- Game: addappid(2512020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512021, 1, "011202a206973a7dde2deb567c5a3f66a8b0512cc57b3a9f32a0ac9f7fe45163")
