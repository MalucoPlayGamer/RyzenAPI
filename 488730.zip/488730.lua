-- Lua provided by RyzenAPI
-- Game: AppID 488730

-- MAIN APPLICATION
addappid(488730)

-- MAIN APP DEPOTS / PACKAGES
addappid(488731, 1, "1766cbc8b15799108d3e13a1e28dbccb70c28be0c46bd53c60ba19ac1f433856")
addappid(1042870, 0, "c66240353eeba793248bedea3e1e7c87d7494888006d134ea726f83da5db9324")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
