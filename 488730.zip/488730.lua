-- Lua provided by SkyAPI 
-- Game: AppID 488730
addappid(488730)
addappid(488731, 1, "1766cbc8b15799108d3e13a1e28dbccb70c28be0c46bd53c60ba19ac1f433856")
addappid(1042870, 0, "c66240353eeba793248bedea3e1e7c87d7494888006d134ea726f83da5db9324")
