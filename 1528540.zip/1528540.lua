-- Lua provided by RyzenAPI
-- Game: Holy Whore Emily

-- MAIN APPLICATION
addappid(1528540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528541, 1, "3c781ca2954742cd8047dfb3a10dc4163b026ad888df044e40a12e7fdcb9c156")

