-- Lua provided by RyzenAPI
-- Game: Planet RIX-13

-- MAIN APPLICATION
addappid(599840)

-- MAIN APP DEPOTS / PACKAGES
addappid(599841,0,"41447e405374919af702e8ee7d85ce1b5bb9fa7a0b146cebfa5297908394d4f1")

