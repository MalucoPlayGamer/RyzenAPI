-- Lua provided by RyzenAPI
-- Game: 逆光 Sunwards

-- MAIN APPLICATION
addappid(1206570)
-- Game: addappid(1206570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206571, 1, "c87eb3125e1c90c09b9e1c8a59e957c97edce944620584cebd5c3c26b2a84dac")
