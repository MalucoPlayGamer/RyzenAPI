-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Battle Grounds Ultimate Demo

-- MAIN APPLICATION
addappid(3272720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272721, 1, "a3b0a669348d02e135363ede8bf8210212341dabd9aedfc28069460da5943641")

