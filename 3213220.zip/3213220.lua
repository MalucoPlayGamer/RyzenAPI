-- Lua provided by SkyAPI 
-- Game: Junkcity Factory Simulator
addappid(3213220)
addappid(3213221, 1, "da6bc69365b753fa7d00ddaaec9d764e1e663bc5c49211825f2767a3972759ab")
