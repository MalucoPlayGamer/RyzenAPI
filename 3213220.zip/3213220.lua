-- Lua provided by RyzenAPI
-- Game: Junkcity Factory Simulator

-- MAIN APPLICATION
addappid(3213220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213221, 1, "da6bc69365b753fa7d00ddaaec9d764e1e663bc5c49211825f2767a3972759ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
