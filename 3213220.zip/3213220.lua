-- Lua provided by RyzenAPI
-- Game: 3213220

-- MAIN APPLICATION
addappid(3213220)
-- Game: addappid(3213220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213221, 1, "da6bc69365b753fa7d00ddaaec9d764e1e663bc5c49211825f2767a3972759ab")
