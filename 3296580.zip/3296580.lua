-- Lua provided by RyzenAPI
-- Game: Phoenix Nirvana Rebirth 2

-- MAIN APPLICATION
addappid(3296580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296581, 1, "ba8232b7e39f30cd7d2ec9caff0d0ac56ec2e96b6a48919fac308a25384f3eff")

