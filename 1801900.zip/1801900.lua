-- Lua provided by RyzenAPI 
-- Game: DEEEER Simulator Soundtrack
addappid(1801900)
addappid(1801901, 1, "d3399a8354f3e59404ec58438cf4b7ba0c093c3629d2519d3ba79727a78a1b0f")
