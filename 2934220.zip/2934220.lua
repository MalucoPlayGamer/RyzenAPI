-- Lua provided by RyzenAPI
-- Game: Monsters are Coming!

-- MAIN APPLICATION
addappid(2934220)
addappid(4407410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934221,0,"655fd0514b7ac5f0ea01bc1fce34a46d3b70436dc4e6f1527dc230ecc6548eab")

