-- Lua provided by RyzenAPI
-- Game: 7th Domain:Tree of Chaos Demo

-- MAIN APPLICATION
addappid(3137200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137201, 1, "ce5fd93a770da75126734b6c37e59addae7c44b3420d74377129def56c1cea1e")
