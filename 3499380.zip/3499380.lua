-- Lua provided by RyzenAPI
-- Game: 3499380

-- MAIN APPLICATION
addappid(3499380)
-- Game: addappid(3499380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499380,0,"562ad0c0a2753f1aaf4cae8e67c3d2326d4709031c2a1f3d7d37fa3a1f24ea7c")
