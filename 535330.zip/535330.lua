-- Lua provided by RyzenAPI
-- Game: Block King

-- MAIN APPLICATION
addappid(535330)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(535331,0,"e00b60daa6c0131a20f8a16c642254f6106c7f727e8ae8a3653ee81d20ab32f3")

