-- Lua provided by RyzenAPI
-- Game: Tavern Table Tactics

-- MAIN APPLICATION
addappid(782290)

-- MAIN APP DEPOTS / PACKAGES
addappid(782291,0,"51dc5ae6d69aeeee4e7e949b55a30c44de7d1e6e2e08d58f532a4c3286fd723b")

