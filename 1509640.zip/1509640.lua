-- Lua provided by RyzenAPI
-- Game: Viking Warrior

-- MAIN APPLICATION
addappid(1509640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509641, 1, "2a1ce241f3319baae33affa11a8d663b2b27934c858a879aba03185b66ffb507")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
