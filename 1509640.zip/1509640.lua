-- Lua provided by RyzenAPI
-- Game: addappid(1509640)

-- MAIN APPLICATION
addappid(1509640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509641, 1, "2a1ce241f3319baae33affa11a8d663b2b27934c858a879aba03185b66ffb507")
