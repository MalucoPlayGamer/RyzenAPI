-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Katakura Hibiki's Lords of Darkness

-- MAIN APPLICATION
addappid(1499370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499370,0,"d32c500e0766cbdb3e0cc557e1f87fa5b0151ea26eaa1e21a8651222d67dcd63")

