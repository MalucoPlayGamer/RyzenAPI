-- Lua provided by RyzenAPI
-- Game: Marrow

-- MAIN APPLICATION
addappid(556710)

-- MAIN APP DEPOTS / PACKAGES
addappid(556711, 1, "4ea7c590f4d81d23b9b839e55c5d6b2de8ff9684234fee2ef6eae9fed4e4fa1d")
addappid(556712, 1, "ee54f204c61a4c1e850c8ce66133806b08b9c15ea0eb4400bb5388ee9bc4dc8e")
