-- Lua provided by RyzenAPI
-- Game: Dice 1000 online

-- MAIN APPLICATION
addappid(708930)

-- MAIN APP DEPOTS / PACKAGES
addappid(708931, 1, "680253f3ff85cbdae0d63e881488bfba641916a2fab886715866976cd6d7d58c")

