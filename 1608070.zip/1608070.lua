-- Lua provided by RyzenAPI
-- Game: CRISIS CORE –FINAL FANTASY VII– REUNION

-- MAIN APPLICATION
addappid(1608070)
addappid(2066830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1608071, 1, "366e38158dbceef1cef1db9cd66d7490cf00f1053523c71d10c4bfb3e65e1c51")
addappid(2131710, 0, "d081c2190195947def0c58e5d54c20546d8a23190f1d0334546aa575e2032ad8")

