-- Lua provided by SkyAPI 
-- Game: Haruka Ao no Hanayome ni
addappid(2947230)
addappid(2947231, 1, "8b95863307cecd8b8c526d3d5421c460d5a8f1e51f799d52141fc7240f691e3b")
