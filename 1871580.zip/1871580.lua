-- Lua provided by SkyAPI 
-- Game: Our Life: Now & Forever Demo
addappid(1871580)
addappid(1871581, 1, "8737ea4b392ea96bbfcdb7d9d5aa45108be8280c62603472db1a10dafca60348")
