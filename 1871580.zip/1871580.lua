-- Lua provided by RyzenAPI
-- Game: Game: Our Life: Now & Forever Demo

-- MAIN APPLICATION
addappid(1871580)
-- Game: addappid(1871580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871581, 1, "8737ea4b392ea96bbfcdb7d9d5aa45108be8280c62603472db1a10dafca60348")
