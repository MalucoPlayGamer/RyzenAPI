-- Lua provided by RyzenAPI
-- Game: 2137090

-- MAIN APPLICATION
addappid(2137090)
-- Game: addappid(2137090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137091, 1, "62e986962d45f808a811ae7124bac81939c6c1519ea08adbc5b07ca92569ac38")
