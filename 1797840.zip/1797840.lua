-- Lua provided by RyzenAPI
-- Game: addappid(1797840)

-- MAIN APPLICATION
addappid(1797840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797841, 1, "511e9b0c9f299e069b51a494c06b06bc14efdb00a68489eaf50dce5a7ed6ebe6")
