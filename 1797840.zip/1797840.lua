-- Lua provided by SkyAPI 
-- Game: Cyberpunk Fighting
addappid(1797840)
addappid(1797841, 1, "511e9b0c9f299e069b51a494c06b06bc14efdb00a68489eaf50dce5a7ed6ebe6")
