-- Lua provided by RyzenAPI
-- Game: El Pasante Elementalista

-- MAIN APPLICATION
addappid(3479650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3479651, 1, "543e91564e85372262e27e4b54e173951cb848ad19b6bcdc8c1d9a1ed9a030e8")
