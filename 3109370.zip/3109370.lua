-- Lua provided by RyzenAPI 
-- Game: Slot Waste
addappid(3109370)
addappid(3109371, 1, "ed831c6551039984ee434ae61590c9cf737c455bf5730143f1bc38c24f96139a")
