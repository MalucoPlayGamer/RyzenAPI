-- Lua provided by SkyAPI 
-- Game: Realms of Arkania: Star Trail
addappid(288860)
addappid(288861, 1, "7a32cd5a848e31de521be14ddcb734fcae9b81e17c319aed76deac4b2c8088fe")
addappid(654140, 0, "36818ba154dfb6b576e0ced08f1daf403831df7aa33f76e4210ef597a9bb22c4")
