-- Lua provided by RyzenAPI 
-- Game: Point of Mew
addappid(2331170)
addappid(2331171, 1, "5ceaa274a3667fd34eecf045ccaf32ff213a4a129d518e5e1673be501ac9d65a")
