-- Lua provided by RyzenAPI
-- Game: Game: Point of Mew

-- MAIN APPLICATION
addappid(2331170)
-- Game: addappid(2331170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331171, 1, "5ceaa274a3667fd34eecf045ccaf32ff213a4a129d518e5e1673be501ac9d65a")
