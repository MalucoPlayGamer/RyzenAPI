-- Lua provided by RyzenAPI
-- Game: Fateful Destiny

-- MAIN APPLICATION
addappid(3359560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359561, 1, "97bdebd28150dbdbae16d0856dc46717de14763893699788c18bb9922f82e1c9")

