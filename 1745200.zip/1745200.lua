-- Lua provided by RyzenAPI
-- Game: Sexy Airlines EVO

-- MAIN APPLICATION
addappid(1745200)
addappid(3728840)
addappid(4612450)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1745201, 1, "5e60ced700d81b335ee31ae7691836e9efc80bdd9236be3fd0211950504fbcc5")

