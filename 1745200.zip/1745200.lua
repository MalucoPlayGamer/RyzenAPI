-- Lua provided by RyzenAPI
-- Game: Sexy Airlines EVO

-- MAIN APPLICATION
addappid(1745200)
-- Game: addappid(1745200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745201, 1, "5e60ced700d81b335ee31ae7691836e9efc80bdd9236be3fd0211950504fbcc5")
