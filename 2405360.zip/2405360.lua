-- Lua provided by SkyAPI 
-- Game: 再上一层
addappid(2405360)
addappid(2405361, 1, "e33110f0fbf5baf7961293ed551e2e0291d10e9698249ba36b1217e6a6ac8571")
