-- Lua provided by RyzenAPI 
-- Game: The Darkness II Demo
addappid(204410)
addappid(204411, 1, "895956c4ca8ed25e89cce896f49d4a44e3d9ad930593897dd5c6099d0c67a23a")
addappid(204412, 1, "3dcedf9099fd02ac9259fcb29f397f011e2d407c96e993dd1d8f4fcf3a61a23c")
