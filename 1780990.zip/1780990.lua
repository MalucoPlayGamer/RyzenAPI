-- Lua provided by RyzenAPI
-- Game: Fallen Flowers

-- MAIN APPLICATION
addappid(1780990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780991, 1, "71aa9613b4c94514d9fc857538f8147e9d1b6a721e41d0f26157d5e46f8ebf1c")
