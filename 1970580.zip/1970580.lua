-- Lua provided by SkyAPI 
-- Game: Backpack Hero
addappid(1970580)
addappid(1970581, 1, "7bae37e1619e3eaf89e2689a47977fe767293487db2dc87eeea151deb59b4e2a")
addappid(1970582, 1, "47cefda381bf839c765b093c9d27e09a805d90509379e96950ab2b9baf93bfb4")
addappid(1970583, 1, "6218e47340a54721ed75b10918487fc70956b4005f56d5464f48dacf4ad4ef1d")
