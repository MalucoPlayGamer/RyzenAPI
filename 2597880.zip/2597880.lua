-- Lua provided by RyzenAPI
-- Game: Game: STRIDE: Fates

-- MAIN APPLICATION
addappid(2597880)
-- Game: addappid(2597880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597881, 1, "c6ef5819757efe256522c5c3d9981687a645b3344739949ad09d05070ba1282c")
