-- Lua provided by RyzenAPI
-- Game: STRIDE: Fates

-- MAIN APPLICATION
addappid(2597880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597881, 1, "c6ef5819757efe256522c5c3d9981687a645b3344739949ad09d05070ba1282c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
