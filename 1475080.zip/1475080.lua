-- Lua provided by RyzenAPI
-- Game: addappid(1475080)

-- MAIN APPLICATION
addappid(1475080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475081, 1, "5d0c681f3056a111547b353b9e43da414a785a21745ce08aa32f928ba459dac6")
