-- Lua provided by RyzenAPI
-- Game: Flora & Fang: Guardians of the vampire garden

-- MAIN APPLICATION
addappid(2751060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751061, 1, "dba0d000531a51aa5e5bb3f060af82404825dee35cc87e76403b92b46f2c4eef")
