-- Lua provided by RyzenAPI
-- Game: Game: 100 Ninja Cats

-- MAIN APPLICATION
addappid(2776810)
-- Game: addappid(2776810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776811, 1, "2f4c89182ba98aa8ed9591971799957c29dbe5ad9d840030b86b4adc34cab24c")
