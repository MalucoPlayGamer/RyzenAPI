-- Lua provided by RyzenAPI
-- Game: Game: Shan Gui (山桂)

-- MAIN APPLICATION
addappid(307050)
-- Game: addappid(307050)

-- MAIN APP DEPOTS / PACKAGES
addappid(307051, 1, "86b84503ca0db3b702a4680988a27c003c41f06a3e62818ec947626dfe516d2d")
addappid(307052, 1, "51044dab1471cddbacbfc125b6a557aa58a0b5b7d0b05cca632039271fd73f12")
addappid(326760, 0, "d998f25157b9d87733d700668b985eb48738fc4a126d56887b1cfbf9f68bb807")
