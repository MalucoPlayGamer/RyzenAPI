-- Lua provided by RyzenAPI
-- Game: AppID 661810

-- MAIN APPLICATION
addappid(661810)

-- MAIN APP DEPOTS / PACKAGES
addappid(661811, 1, "06230d5ffd00db098b944ce92d54538cd7c6620c7d3bc0f2b122df918aa7c302")

