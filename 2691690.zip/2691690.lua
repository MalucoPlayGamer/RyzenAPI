-- Lua provided by RyzenAPI
-- Game: River Tails: Stronger Together - The Art of River Tails: Stronger Together

-- MAIN APPLICATION
addappid(2691690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691690,0,"be7f80a49422e4e05e6f8e299812759a908823727f088e9772ce77180659c752")

