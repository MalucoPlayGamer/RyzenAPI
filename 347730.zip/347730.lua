-- Lua provided by RyzenAPI
-- Game: AppID 347730

-- MAIN APPLICATION
addappid(347730)

-- MAIN APP DEPOTS / PACKAGES
addappid(347731, 1, "e1f7c0b3ca48775c6780a67a3620c554ed2460aea2f8e3b2a349f95153096296")
addappid(347732, 1, "a1ff9ce02258f7593aed0bbeaa6a8ea1ef4378cb96ba977dc592d3b49947b941")
addappid(347733, 1, "282c3a7a042d2406718c4399e702ae69bc5273684dd4adfd74ad9d3f429358e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
