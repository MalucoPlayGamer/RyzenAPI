-- Lua provided by RyzenAPI
-- Game: 幻兽骑士

-- MAIN APPLICATION
addappid(2799740)
-- Game: addappid(2799740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799741, 1, "55ce0c57ffee49118d64a6e2144710992b74ae04f4215b891518c7a846505768")
