-- Lua provided by RyzenAPI
-- Game: Poly Memory: Dinosaurs

-- MAIN APPLICATION
addappid(2190280)
-- Game: addappid(2190280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190281, 1, "73b889a61d7ad5361351c7ebc0334f4cc4e78e748a31b38b689cdb773eb7a25c")
