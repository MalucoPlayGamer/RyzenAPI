-- Lua provided by RyzenAPI
-- Game: Ghost Trap

-- MAIN APPLICATION
addappid(2006090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006091, 1, "2b7fe4bab6f1dbce933ad14648c990b650ef40dcb71308835273de1ec1c2ad65")

