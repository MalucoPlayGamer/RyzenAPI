-- Lua provided by RyzenAPI 
-- Game: AppID 1312540
addappid(1312540)
addappid(1312541, 1, "0a6487b85e9b1ca00834e84bc74531a6759693a55b373ca6afc26c258c660845")
