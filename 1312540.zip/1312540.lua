-- Lua provided by RyzenAPI
-- Game: OMG: One Million Guns

-- MAIN APPLICATION
addappid(1312540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1312541, 1, "0a6487b85e9b1ca00834e84bc74531a6759693a55b373ca6afc26c258c660845")

