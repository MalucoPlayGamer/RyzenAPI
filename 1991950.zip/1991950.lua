-- Lua provided by RyzenAPI
-- Game: Blood Job

-- MAIN APPLICATION
addappid(1991950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991951, 1, "640fa12a733a48af728035ed66dd9b29f71ff18020117e8d2a4bd85bacbf18fe")
