-- Lua provided by RyzenAPI
-- Game: MDK 2

-- MAIN APPLICATION
addappid(38460)
-- Game: addappid(38460)

-- MAIN APP DEPOTS / PACKAGES
addappid(38461, 1, "926fa08a5e76071999596f9e742ecb9368862338722473c32a96f666bd605ae5")
