-- Lua provided by RyzenAPI 
-- Game: Camper Jumper Simulator
addappid(520380)
addappid(520381, 1, "f7a342a3e01c4a530efa29abed2add6c4bceb70399102115d1e71f940bd99efb")
