-- Lua provided by RyzenAPI
-- Game: 520380

-- MAIN APPLICATION
addappid(520380)
-- Game: addappid(520380)

-- MAIN APP DEPOTS / PACKAGES
addappid(520381, 1, "f7a342a3e01c4a530efa29abed2add6c4bceb70399102115d1e71f940bd99efb")
