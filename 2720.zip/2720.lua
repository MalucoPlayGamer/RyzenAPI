-- Lua provided by RyzenAPI
-- Game: ThreadSpace: Hyperbol

-- MAIN APPLICATION
addappid(2720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721, 1, "1ab66fe3b86b88cb979405c2ed926667d0f7d4a5a049a2b2b66791a795a4f4d8")
addappid(2722, 1, "7fbd9497a98176bca021543adba8dbbe6a7a796e6015626a1991f2d9a4fbec8a")
addappid(2723, 1, "1611d3893c5eeef840ef0a464bbd9c2120d2d05a09117882a6d5ac058e3f2e57")
addappid(2726, 1, "aee41147e03414fc3abab7e1e9804a7203270cdfcaab7f573503cb95ef90d6d1")
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

