-- Lua provided by RyzenAPI
-- Game: Peasant Royale

-- MAIN APPLICATION
addappid(2677640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2677641, 1, "f6ca2eabbea2c731a9d7d3f79b2d4cbc212d03b67a3db62c49b7431dc834b608")

