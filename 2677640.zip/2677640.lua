-- Lua provided by RyzenAPI
-- Game: Peasant Royale

-- MAIN APPLICATION
addappid(2677640)
-- Game: addappid(2677640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677641, 1, "f6ca2eabbea2c731a9d7d3f79b2d4cbc212d03b67a3db62c49b7431dc834b608")
