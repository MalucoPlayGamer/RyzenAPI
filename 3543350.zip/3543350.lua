-- Lua provided by RyzenAPI
-- Game: 3543350

-- MAIN APPLICATION
addappid(3543350)
addappid(4123680)
-- Game: addappid(3543350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3543351, 1, "301fd366c497e2f376ef8973ec4fdca277ef19fe635f673af31eef6d1db21345")
