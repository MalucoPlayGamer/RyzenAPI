-- Lua provided by RyzenAPI
-- Game: This is Timmy Playtest

-- MAIN APPLICATION
addappid(1733640)
-- Game: addappid(1733640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733641, 1, "78818fba4383c3a8ff3e1e8f7213d843a419213bf03090a754754155136348ac")
