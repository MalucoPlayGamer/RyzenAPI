-- Lua provided by RyzenAPI
-- Game: Excremental Game

-- MAIN APPLICATION
addappid(4268200) -- Excremental Game
addappid(5006310) -- Excremental Game - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4268201, 1, "a98da7af1af8951cadd2047be105a4332a4ea3ae346d57cd57f8a84bd91dae1b") -- Depot 4268201

