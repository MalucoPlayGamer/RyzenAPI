-- 4268200's Lua and Manifest Created by Hubcap Manifest
-- Excremental Game
-- Created: August 17, 2026 at 16:14:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4268200) -- Excremental Game
-- MAIN APP DEPOTS
addappid(4268201, 1, "a98da7af1af8951cadd2047be105a4332a4ea3ae346d57cd57f8a84bd91dae1b") -- Depot 4268201
setManifestid(4268201, "2326328979258690200", 442710491)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5006310) -- Excremental Game - Supporter Pack