-- Lua provided by SkyAPI 
-- Game: City Patrol: Police
addappid(789890)
addappid(789891, 1, "9488685fc3b935210214a31b5f813f6f82cc221eebc8c72e999fa6b94b4e49e1")
