-- Lua provided by RyzenAPI
-- Game: Astrologaster

-- MAIN APPLICATION
addappid(742520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(742521, 1, "de8ec6ebea97be58fb6ab0f1ff916cdfb9af6cae478a0ad28480e9ff27295a49")

