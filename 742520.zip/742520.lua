-- Lua provided by RyzenAPI
-- Game: Astrologaster

-- MAIN APPLICATION
addappid(742520)

-- MAIN APP DEPOTS / PACKAGES
addappid(742521, 1, "de8ec6ebea97be58fb6ab0f1ff916cdfb9af6cae478a0ad28480e9ff27295a49")
