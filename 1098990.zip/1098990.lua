-- Lua provided by RyzenAPI
-- Game: Cream Me

-- MAIN APPLICATION
addappid(1098990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098991, 1, "91240f69f44f9907bd6ba2911a11ffc17671140ba5e4f824d733c9df7fee5186")
