-- Lua provided by RyzenAPI
-- Game: addappid(2478800)

-- MAIN APPLICATION
addappid(2478800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478801, 1, "3d9cf7791576356f3e9bb56d51be3d6dc63e0a1b9e6aa78d7bade6d2563cddeb")
