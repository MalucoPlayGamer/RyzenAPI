-- Lua provided by RyzenAPI 
-- Game: Noun Town Language Learning Demo
addappid(2478800)
addappid(2478801, 1, "3d9cf7791576356f3e9bb56d51be3d6dc63e0a1b9e6aa78d7bade6d2563cddeb")
