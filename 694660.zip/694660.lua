-- Lua provided by RyzenAPI
-- Game: End of Days

-- MAIN APPLICATION
addappid(694660)

-- MAIN APP DEPOTS / PACKAGES
addappid(694661,0,"41d8f70a5d76b52cc2ba9d0e931bc38aeda043b8c05edcebb88c959246589128")
addappid(694662,0,"78aa11164f2188afc290c7c74fd473072fe125f577dcc2f21d64338490964604")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
