-- Lua provided by RyzenAPI
-- Game: Ninja Remix

-- MAIN APPLICATION
addappid(2846510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846511, 1, "7709f4e1dfee7b7a1b7192416bebd495c374f25df75369e8f5cf80fa8a3263e5")
