-- Lua provided by RyzenAPI
-- Game: Striving for Light

-- MAIN APPLICATION
addappid(1646790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646791, 1, "387a839d535759a41e628d9eae51b5df05ad03e45ce39e9d92c6a9bd110d9bd5")

