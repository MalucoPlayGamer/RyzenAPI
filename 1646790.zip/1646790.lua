-- Lua provided by RyzenAPI
-- Game: Striving for Light

-- MAIN APPLICATION
addappid(1646790)
addappid(4606350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646791,0,"387a839d535759a41e628d9eae51b5df05ad03e45ce39e9d92c6a9bd110d9bd5")
addappid(1646792,0,"a1f92459297356f46472216096fedf43c5fb833243de65ccb8aeb91078381dc6")

