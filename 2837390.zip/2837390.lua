-- Lua provided by RyzenAPI
-- Game: Shoulders of Giants Demo

-- MAIN APPLICATION
addappid(2837390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837391, 1, "73b3810b3bb6e891cccddf14193c17445984715c423b94f9775d31da7d59d614")
