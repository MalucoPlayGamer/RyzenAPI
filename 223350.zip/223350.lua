-- Lua provided by RyzenAPI
-- Game: AppID 223350

-- MAIN APPLICATION
addappid(223350)
addappid(228985)
addappid(229004)
-- Game: addappid(223350)

-- MAIN APP DEPOTS / PACKAGES
addappid(223351, 1, "313fce1b92870aeae709cf0dc905b4017f2d838199ee73085ace74dcf812dfb6")
addappid(223352, 1, "0e8d4d681fedd8b8693222327d7b5f58ff56cf714bfdd59a3d654f0ac39a525c")
addappid(223353, 1, "a54f79b99eb82d48dbc223eab2c92454fb191a97853713b56c6e8b77d69a9065")
addappid(223354, 1, "0004afb451c4e4c2917c895c240f57e8b422d71b3ada06d0c780b97e8e3de7e7")
