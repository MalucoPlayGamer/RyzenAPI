-- Lua provided by RyzenAPI
-- Game: addappid(776370)

-- MAIN APPLICATION
addappid(776370)

-- MAIN APP DEPOTS / PACKAGES
addappid(776371, 1, "238dd474ed10153510fe270f1b4028606cf17c28aaaa9e6a9f293acd0ab47ca9")
