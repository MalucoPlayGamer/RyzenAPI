-- Lua provided by RyzenAPI
-- Game: Riven Demo

-- MAIN APPLICATION
addappid(3007180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007181, 1, "d857cff0a48e803e55baaf71b06dc61b1289c2911a1136852b7960c6a6106897")
