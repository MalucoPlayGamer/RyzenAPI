-- Lua provided by RyzenAPI
-- Game: 3115510

-- MAIN APPLICATION
addappid(3115510)
-- Game: addappid(3115510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115511, 1, "4eb4be2c5a5e441ef3407cb663b9ad7ff24ecd64eff4ed53b1f0e2dd73caf68c")
