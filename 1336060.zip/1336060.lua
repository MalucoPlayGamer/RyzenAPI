-- Lua provided by RyzenAPI
-- Game: TAISHO x ALICE episode 2

-- MAIN APPLICATION
addappid(1336060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336061, 1, "b693cfd255cb77f7c64501710c87cfab6fb1dac5245f5ff0b7208a764e7e1fbb")
