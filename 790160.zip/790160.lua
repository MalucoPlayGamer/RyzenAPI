-- Lua provided by RyzenAPI
-- Game: Five Keys to Exit

-- MAIN APPLICATION
addappid(790160)
-- Game: addappid(790160)

-- MAIN APP DEPOTS / PACKAGES
addappid(790161, 1, "0607b261340376a5a30e63e92d1826a4cec177603cc7558c776a36ab7af63661")
