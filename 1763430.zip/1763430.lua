-- Lua provided by RyzenAPI
-- Game: Karryn's Prison Demo

-- MAIN APPLICATION
addappid(1763430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763431, 1, "ff18be6e7600b3d0605f3e4de3a11fc667d6d05aef71178449fa83453c2d43cb")
