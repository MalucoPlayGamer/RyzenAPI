-- Lua provided by RyzenAPI
-- Game: Game: BugLab Simulator

-- MAIN APPLICATION
addappid(3729330)
-- Game: addappid(3729330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3729331, 1, "04d191d63fb0dc0f6a5e6c180659e1f264e5d99a9b2dad71577d8355facd624e")
