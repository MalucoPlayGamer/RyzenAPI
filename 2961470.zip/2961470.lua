-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic the Change of Seasons ALL in ONE Pack

-- MAIN APPLICATION
addappid(2961470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2961471, 1, "d4476da39e4825498f94119efa9d4352453bdf6df5bdea9b62cecc205acb42c3")
