-- Lua provided by RyzenAPI
-- Game: AppID 302670

-- MAIN APPLICATION
addappid(302670)

-- MAIN APP DEPOTS / PACKAGES
addappid(302671, 1, "3e65babcddf3e355150640051939bd668679ca9d6a28dbd7f4202d63f7e6855b")
addappid(302672, 1, "432ed372fbe5cf4a1d8a170402021d29d199bbbabed929fd1069cf895bc855ac")
addappid(302673, 1, "8bf7411ec6ce26a0017cf39bf6896dcc9af1a7ba7f6d63e3d856ea2757416c86")
addappid(302674, 1, "531c102af53824a44023438a8e9c3b33bea8b74a2143c9ae2a607c329529e9d5")
addappid(302675, 1, "83cba74766ae1a90e1c63e1b33d14039bb4355026d0141e98539404bebdccc50")
addappid(302676, 1, "084e98289252950f851b92de3dea17763ecfa23b09e92ca851a36e436d671cb3")
addappid(302677, 1, "e3f4473df15ada8b23932e8e0c60835de254abd33b5fe06f2153b40703073738")
addappid(475170, 0, "83373b30c2525b93bb866726e94bf8272b47b258424bb720dbcd20d7d67b654f")
addappid(487170, 0, "f9ba895f81f7169a8a8cc8798a184f192c18884f17fb63a578d66df3585f2532")
addappid(561140, 0, "64e9170f08642db2b67673315d4486d0cb4e78c261fd3e95c1df03b17af30291")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(374390)
addappid(487310)
addappid(548180)
