-- Lua provided by RyzenAPI 
-- Game: Fort Meow
addappid(352070)
addappid(352071, 1, "048917d2086b88b477a011a6c58dfed6f12ee65c00def1c095313bf4a0c485c8")
