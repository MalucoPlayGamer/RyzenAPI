-- Lua provided by RyzenAPI
-- Game: Hue Defense

-- MAIN APPLICATION
addappid(512070)
-- Game: addappid(512070)

-- MAIN APP DEPOTS / PACKAGES
addappid(512071, 1, "c4260f91a76b249f8c5b872edcf0bdbee71ac04e58c613325a219121f628aa30")
