-- Lua provided by RyzenAPI
-- Game: 1480650

-- MAIN APPLICATION
addappid(1480650)
-- Game: addappid(1480650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480651, 1, "0d398ae2428afadcc55cae0623fb14f8ce50115bf5596bae778ccb3345fab3dd")
