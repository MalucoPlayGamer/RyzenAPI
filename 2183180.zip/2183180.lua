-- Lua provided by RyzenAPI 
-- Game: BACCHANALIA
addappid(2183180)
addappid(2183181, 1, "73061a91fa91e8a4077d2b149eb54ffb6059236fc9e117a4491db98a3914b395")
