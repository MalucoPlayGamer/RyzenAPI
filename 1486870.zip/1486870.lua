-- Lua provided by RyzenAPI
-- Game: Hiddenverse: Ominous Opus

-- MAIN APPLICATION
addappid(1486870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486871, 1, "e7828c6405dbfe5a40f138be6bde6a23ff4bf0ad788bf3858f77ba9ef9eec1f1")

