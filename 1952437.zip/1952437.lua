-- Lua provided by RyzenAPI
-- Game: 1952437

-- MAIN APPLICATION
addappid(1952437)
-- Game: addappid(1952437)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952437,0,"8a6af6194584ad446ad2a40683ce384a6f8aaf54fcbd60be1906b8971bf1fc07")
