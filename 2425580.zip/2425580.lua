-- Lua provided by RyzenAPI
-- Game: 2425580

-- MAIN APPLICATION
addappid(2425580)
addappid(2733010)
-- Game: addappid(2425580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425581, 1, "243c49b938f787b04f8b2ca0d4e15f117f2eca9d7f374c6a212c1f38366cbba6")
