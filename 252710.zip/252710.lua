-- Lua provided by RyzenAPI
-- Game: The Last Express Gold Edition

-- MAIN APPLICATION
addappid(252710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(252711, 1, "ea52a8802559e0045e34fe68c3fbe0452b8429d81fdf654808a696ed0afe4729")
addappid(252712, 1, "ffc209361c5dc22ab1359befc4392b79a643e8fdf2c4955b6fe70170474d2d95")
