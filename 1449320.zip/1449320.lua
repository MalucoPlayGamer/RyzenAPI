-- Lua provided by RyzenAPI
-- Game: Alfred Hitchcock - Vertigo

-- MAIN APPLICATION
addappid(1449320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449321, 1, "65b1fd16d76e00fab134eb6ca9c240d3bb0237bb15c4dcdeebd230b21c42d960")

