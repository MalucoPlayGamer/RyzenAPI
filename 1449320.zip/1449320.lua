-- Lua provided by RyzenAPI
-- Game: Alfred Hitchcock - Vertigo

-- MAIN APPLICATION
addappid(1449320)
addappid(1722460)
addappid(1731180)
addappid(1731220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1449321, 1, "65b1fd16d76e00fab134eb6ca9c240d3bb0237bb15c4dcdeebd230b21c42d960")

