-- Lua provided by RyzenAPI
-- Game: Selene ~Apoptosis~

-- MAIN APPLICATION
addappid(1398210)
-- Game: addappid(1398210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398211, 1, "467d9de19340e2155226a512fc3565d942b580503506940ad971525dfc825651")
