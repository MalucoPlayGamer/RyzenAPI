-- Lua provided by RyzenAPI
-- Game: Selene ~Apoptosis~

-- MAIN APPLICATION
addappid(1398210)
addappid(1398260)
addappid(2151000)
addappid(2315500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398211, 1, "467d9de19340e2155226a512fc3565d942b580503506940ad971525dfc825651")

