-- Lua provided by RyzenAPI
-- Game: Paper Shakespeare: To Date Or Not To Date?

-- MAIN APPLICATION
addappid(702940)
addappid(711960)
addappid(731980)
addappid(836380)
addappid(842670)
addappid(843600)
addappid(878830)
addappid(890490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(702941, 1, "931a64f8377dc16187dde6995f68dc0fefaa6596deaa334e04cc1c745b465032")
addappid(702942, 1, "48831a6a7441e74b3b612798d9b24870c0fac45b6b57eb5500b28ca2e761817c")
addappid(702943, 1, "40847af45d2ea5f4a788c0592a7388e9a40de8c62f268a80168199b25a1df21b")

