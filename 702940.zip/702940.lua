-- Lua provided by RyzenAPI
-- Game: Paper Shakespeare: To Date Or Not To Date?

-- MAIN APPLICATION
addappid(702940)

-- MAIN APP DEPOTS / PACKAGES
addappid(702941, 1, "931a64f8377dc16187dde6995f68dc0fefaa6596deaa334e04cc1c745b465032")
addappid(702942, 1, "48831a6a7441e74b3b612798d9b24870c0fac45b6b57eb5500b28ca2e761817c")
addappid(702943, 1, "40847af45d2ea5f4a788c0592a7388e9a40de8c62f268a80168199b25a1df21b")
