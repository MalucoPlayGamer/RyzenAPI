-- Lua provided by SkyAPI 
-- Game: Deathless: Survivors
addappid(2443090)
addappid(2443091, 1, "1c1eb54027b84eceefe1b6d827518f7fbc62a22ee2b9c6e5938d45baa6c569b1")
