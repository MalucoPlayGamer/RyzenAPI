-- Lua provided by RyzenAPI
-- Game: 2443090

-- MAIN APPLICATION
addappid(2443090)
-- Game: addappid(2443090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443091, 1, "1c1eb54027b84eceefe1b6d827518f7fbc62a22ee2b9c6e5938d45baa6c569b1")
