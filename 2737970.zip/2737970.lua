-- Lua provided by RyzenAPI
-- Game: Game: Mashiroiro Symphony HD -Love is Pure White-

-- MAIN APPLICATION
addappid(2737970)
-- Game: addappid(2737970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737971, 1, "840f5dc54723f683a779d965c5f5b59100f204edf78060453dad1aa036877165")
