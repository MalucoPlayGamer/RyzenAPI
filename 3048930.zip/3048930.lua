-- Lua provided by RyzenAPI
-- Game: Duriano

-- MAIN APPLICATION
addappid(3048930)
addappid(3678720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048931,0,"d3a86128848a33a4ac7a83312dedec0a9aa1df7292469662afafbb748564ee7f")

