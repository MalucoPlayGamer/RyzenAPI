-- Lua provided by RyzenAPI
-- Game: SysAdmin Odyssey. Back to the office Demo

-- MAIN APPLICATION
addappid(2835510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835513,0,"7e57387aed03ff44945d75ef33d3c6e272fdbe0976d7d317ffd23fe5cab47389")

