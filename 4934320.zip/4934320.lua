-- Lua provided by RyzenAPI
-- Game: SlimeHold

-- MAIN APPLICATION
addappid(4934320) -- SlimeHold

-- MAIN APP DEPOTS / PACKAGES
addappid(4934321, 1, "f3b7ea54b5ee7dad2b99915564166f50eadcb293de86bcd7ca6483bcfc1028ea") -- Depot 4934321

