-- 4934320's Lua and Manifest Created by Hubcap Manifest
-- SlimeHold
-- Created: August 07, 2026 at 07:22:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4934320) -- SlimeHold
-- MAIN APP DEPOTS
addappid(4934321, 1, "f3b7ea54b5ee7dad2b99915564166f50eadcb293de86bcd7ca6483bcfc1028ea") -- Depot 4934321
setManifestid(4934321, "5560372471652577427", 145197807)