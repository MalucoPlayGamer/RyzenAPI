-- Lua provided by RyzenAPI
-- Game: addappid(730390)

-- MAIN APPLICATION
addappid(730390)

-- MAIN APP DEPOTS / PACKAGES
addappid(730391, 1, "dfb15439c88610227b175ae5af4e60e58324b6c7d5b3cf9d551130e7d932ddb6")
