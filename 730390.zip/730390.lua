-- Lua provided by RyzenAPI 
-- Game: Raji: An Ancient Epic
addappid(730390)
addappid(730391, 1, "dfb15439c88610227b175ae5af4e60e58324b6c7d5b3cf9d551130e7d932ddb6")
