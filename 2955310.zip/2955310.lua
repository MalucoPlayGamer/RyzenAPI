-- Lua provided by RyzenAPI
-- Game: Unity-Chan: Desktop Companion

-- MAIN APPLICATION
addappid(2955310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955311,0,"5fd19248c1eead93fbcae44800e73151d8e6adbb48c87fada2f4f5cfc2b616dd")

