-- Lua provided by RyzenAPI
-- Game: Saiku's Endless Labyrinth

-- MAIN APPLICATION
addappid(1302470)
-- Game: addappid(1302470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302471, 1, "014a09b8bb282d0e6bd3b1b0e85d22453e1d3019ae14d1ae1c2226efdf9156cc")
