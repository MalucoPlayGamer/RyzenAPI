-- Lua provided by RyzenAPI
-- Game: Re:DESTINY

-- MAIN APPLICATION
addappid(1426120)
addappid(1442320)
-- Game: addappid(1426120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426121, 1, "48239e69982b8e819cafea6116230e56fdd2060d7f601c59f8eaad9d3ae5d1e1")
