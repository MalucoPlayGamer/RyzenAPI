-- Lua provided by SkyAPI 
-- Game: Re:DESTINY
addappid(1426120)
addappid(1426121, 1, "48239e69982b8e819cafea6116230e56fdd2060d7f601c59f8eaad9d3ae5d1e1")
addappid(1442320)
