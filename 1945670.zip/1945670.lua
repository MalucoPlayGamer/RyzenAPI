-- Lua provided by RyzenAPI
-- Game: Bear Adventure

-- MAIN APPLICATION
addappid(1945670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1945671, 1, "73bc7ffe4ad8b5a5dbaa8067e9b752612eaeb1674deb81e364abc87c7adeba08")

