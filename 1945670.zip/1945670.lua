-- Lua provided by RyzenAPI
-- Game: 1945670

-- MAIN APPLICATION
addappid(1945670)
-- Game: addappid(1945670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945671, 1, "73bc7ffe4ad8b5a5dbaa8067e9b752612eaeb1674deb81e364abc87c7adeba08")
