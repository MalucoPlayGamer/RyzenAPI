-- Lua provided by RyzenAPI
-- Game: Shining Blade

-- MAIN APPLICATION
addappid(1636970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636971, 1, "e28ac3af43f22a4e0a2c0e40c3c8556543a14e20878f41d345a5c09d6feda924")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
