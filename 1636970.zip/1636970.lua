-- Lua provided by RyzenAPI
-- Game: addappid(1636970)

-- MAIN APPLICATION
addappid(1636970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636971, 1, "e28ac3af43f22a4e0a2c0e40c3c8556543a14e20878f41d345a5c09d6feda924")
