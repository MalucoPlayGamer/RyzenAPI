-- Lua provided by RyzenAPI
-- Game: Spirit Whisperer Conversation With Kamiko

-- MAIN APPLICATION
addappid(3828350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3828351, 1, "fb12225f069cd1b0aeb0152a4d8a94ad51ed0e6c8d09159cb14ee1bab3777d2c")
