-- Lua provided by RyzenAPI
-- Game: Game: Naughty Or Nice

-- MAIN APPLICATION
addappid(574780)
-- Game: addappid(574780)

-- MAIN APP DEPOTS / PACKAGES
addappid(574781, 1, "c95da63919c04c9848af935fa480e2cdf1c7970b4be49934ce408bbe5b319dac")
