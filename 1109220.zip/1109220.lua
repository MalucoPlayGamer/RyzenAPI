-- Lua provided by RyzenAPI
-- Game: Pencil Fantastic

-- MAIN APPLICATION
addappid(1109220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109221, 1, "8335ea43559166d47f7f407f57248e044b34ecb58935e20869b237a96034c9e6")

