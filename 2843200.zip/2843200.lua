-- Lua provided by RyzenAPI
-- Game: addappid(2843200)

-- MAIN APPLICATION
addappid(2843200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843201, 1, "bb71707c57a8c0461ae49d9097b92b26f0560011ff587a6fa3b1619fb66b2b83")
