-- Lua provided by RyzenAPI
-- Game: Game: Space Menace Demo

-- MAIN APPLICATION
addappid(2020700)
-- Game: addappid(2020700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020701, 1, "b99a80634dad76f4b151ee08304831bc6a0e848482427022d372191102f0abad")
