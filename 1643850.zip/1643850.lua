-- Lua provided by RyzenAPI
-- Game: Slaycation Paradise

-- MAIN APPLICATION
addappid(1643850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643851, 1, "1f3862cfd13dc0ef310f9089775c52adbed77b87a1dc8cfa4e2d903fb5e734f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
