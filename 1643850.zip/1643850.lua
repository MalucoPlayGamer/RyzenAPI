-- Lua provided by RyzenAPI
-- Game: 1643850

-- MAIN APPLICATION
addappid(1643850)
-- Game: addappid(1643850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643851, 1, "1f3862cfd13dc0ef310f9089775c52adbed77b87a1dc8cfa4e2d903fb5e734f7")
