-- Lua provided by RyzenAPI
-- Game: Game: AppID 1151130

-- MAIN APPLICATION
addappid(1151130)
-- Game: addappid(1151130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151131, 1, "b7cf5a86054e555ef658b03512174a4218bc2504f41613fabae3813898303cad")
