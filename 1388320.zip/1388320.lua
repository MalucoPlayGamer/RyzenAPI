-- Lua provided by RyzenAPI
-- Game: 老板，游戏凉了！- Game Company Simulator: back to 2000

-- MAIN APPLICATION
addappid(1388320)
-- Game: addappid(1388320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388321, 1, "c522fcd83e120ba8f47e5c0a373af9fc816cd1da3c3e446715535119bc589b84")
