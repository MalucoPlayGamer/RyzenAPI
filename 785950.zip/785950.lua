-- Lua provided by RyzenAPI
-- Game: Game: Sacrifice Dungeon

-- MAIN APPLICATION
addappid(785950)
-- Game: addappid(785950)

-- MAIN APP DEPOTS / PACKAGES
addappid(785951, 1, "0b8f5fe98ad5a94d1a945142c14e256e6db3d65e07064ac1ae731d6225579f69")
