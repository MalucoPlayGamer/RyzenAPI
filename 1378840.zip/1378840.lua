-- Lua provided by RyzenAPI
-- Game: addappid(1378840)

-- MAIN APPLICATION
addappid(1378840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378841, 1, "b8bfe363337be7f23bfb74e1133d3efb7cbf65b6ccd5726a2aaf9fcd3f46fd7c")
