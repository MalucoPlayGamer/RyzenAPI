-- Lua provided by RyzenAPI
-- Game: Lingua VR

-- MAIN APPLICATION
addappid(1378840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378841, 1, "b8bfe363337be7f23bfb74e1133d3efb7cbf65b6ccd5726a2aaf9fcd3f46fd7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
