-- Lua provided by RyzenAPI
-- Game: Trader Ascent

-- MAIN APPLICATION
addappid(4643260)

-- MAIN APP DEPOTS / PACKAGES
addappid(4643261,0,"b774bf34728cd4642def985c8b86f089954210db92d52b2a96806e1da5717e8d")

