-- Lua provided by RyzenAPI
-- Game: 2915460

-- MAIN APPLICATION
addappid(2915460)
-- Game: addappid(2915460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915461, 1, "022099f7246ff72908c4a31e8fec337cfc87537266af23bd5ff99d327fc1ecb4")
