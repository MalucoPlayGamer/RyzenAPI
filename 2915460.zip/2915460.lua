-- Lua provided by RyzenAPI
-- Game: OneShot: World Machine Edition

-- MAIN APPLICATION
addappid(2915460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915461, 1, "022099f7246ff72908c4a31e8fec337cfc87537266af23bd5ff99d327fc1ecb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
