-- Lua provided by RyzenAPI
-- Game: Inside My Radio

-- MAIN APPLICATION
addappid(357720)
addappid(435500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(357721, 1, "c0edc822646e1570f52015f6ca7a355e93835cf47d08d0bf5a1e2c4752d8e228")
addappid(357722, 1, "d6e1a0b0dcd14aa1a4dab48b3504dbdb3c6f237733dab3aebeca32b2956c22bc")
