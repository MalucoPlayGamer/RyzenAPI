-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VII

-- MAIN APPLICATION
addappid(39140)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(39142,0,"6c12a4e6828b3bd8eeb3294935f557c79117d257785c190879a535ad7164f7f7")
addappid(39143,0,"4b1ecafba0774002e5b0c67cdf69acb6ed7353144d590a621ab2dcfcf0777059")
addappid(39144,0,"97cb41a02102e64a1c1b6a9c0e2ae4d1fae52751d0f71dd7d44a16c431474055")
addappid(39145,0,"4f2dfd13b0eb9dbb995032ccce71f77fc84e9fd051a39d0cd24ce8271ad57c63")
addappid(39146,0,"c6bdbe14b1e561e938fd570d35d1d9825ca2816c43c5f93525c04b1d1c935ab0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
