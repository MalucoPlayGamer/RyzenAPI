-- Lua provided by RyzenAPI
-- Game: Grand Theft Auto III

-- MAIN APPLICATION
addappid(12230)

-- MAIN APP DEPOTS / PACKAGES
addappid(12231, 1, "f5adeaf90aaf36837c16ecde679da7c8e64a06d408b90d59ad4a2bd2203b95ee")
