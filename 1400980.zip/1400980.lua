-- Lua provided by RyzenAPI
-- Game: My Neighborhood Arcade

-- MAIN APPLICATION
addappid(1400980)
addappid(1423240)
addappid(1423241)
addappid(1423242)
addappid(1423243)
addappid(1423244)
addappid(1423245)
addappid(1423246)
addappid(1423247)
addappid(1423248)
addappid(1423249)
addappid(1423250)
addappid(1423251)
addappid(1427850)
addappid(1504680)
addappid(1512220)
addappid(1512222)
addappid(1514870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400981, 1, "8efb192266f611e1e0f16577b4fb80fd7df7f56cff5636afaa3e9a74e1acbedf")

