-- Lua provided by RyzenAPI
-- Game: addappid(1400980)

-- MAIN APPLICATION
addappid(1400980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400981, 1, "8efb192266f611e1e0f16577b4fb80fd7df7f56cff5636afaa3e9a74e1acbedf")
