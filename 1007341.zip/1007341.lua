-- Lua provided by RyzenAPI
-- Game: Fantasia of the Wind 2 Art Book

-- MAIN APPLICATION
addappid(1007341)
-- Game: addappid(1007341)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007341,0,"4bc078e43096193d52089955bccdfe0ad9be90df4555c027fa94e16eebae5440")
