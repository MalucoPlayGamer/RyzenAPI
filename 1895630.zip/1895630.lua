-- Lua provided by RyzenAPI
-- Game: VRM Posing Desktop

-- MAIN APPLICATION
addappid(1895630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895633,0,"83728c2f395ea8886c260f975373366a333569fd43b5ecf6dcfbf8718754ada5")

