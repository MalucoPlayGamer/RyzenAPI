-- Lua provided by RyzenAPI
-- Game: Super Mega Baseball: Extra Innings

-- MAIN APPLICATION
addappid(314070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(314071, 1, "4a29a7e13eb55a36f4abdb2ce9d5d71fffd351344caaa45bc905be394cdb4065")
