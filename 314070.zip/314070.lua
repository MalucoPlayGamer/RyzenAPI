-- Lua provided by RyzenAPI
-- Game: Super Mega Baseball: Extra Innings

-- MAIN APPLICATION
addappid(314070)
-- Game: addappid(314070)

-- MAIN APP DEPOTS / PACKAGES
addappid(314071, 1, "4a29a7e13eb55a36f4abdb2ce9d5d71fffd351344caaa45bc905be394cdb4065")
