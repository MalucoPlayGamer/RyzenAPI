-- Lua provided by RyzenAPI
-- Game: 756760

-- MAIN APPLICATION
addappid(756760)
-- Game: addappid(756760)

-- MAIN APP DEPOTS / PACKAGES
addappid(756761, 1, "6706e6e9ead7a283167cb7fd9bd0babaa4d12ab3eb405f818d25e3797a133b65")
