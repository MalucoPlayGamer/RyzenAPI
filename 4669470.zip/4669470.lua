-- 4669470's Lua and Manifest Created by Hubcap Manifest
-- Idle Keep
-- Created: June 25, 2026 at 12:05:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4669470) -- Idle Keep
-- MAIN APP DEPOTS
addappid(4669471, 1, "2a2bbd396bfa32c71d1bae110dccc2cb9c9283ea8289955449b1fcdc473500c0") -- Depot 4669471
-- setManifestid(4669471, "6845654211906537877", 376281234)