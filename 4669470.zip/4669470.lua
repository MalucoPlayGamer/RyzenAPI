-- Lua provided by RyzenAPI
-- Game: Idle Keep

-- MAIN APPLICATION
addappid(4669470) -- Idle Keep

-- MAIN APP DEPOTS / PACKAGES
addappid(4669471, 1, "2a2bbd396bfa32c71d1bae110dccc2cb9c9283ea8289955449b1fcdc473500c0") -- Depot 4669471

