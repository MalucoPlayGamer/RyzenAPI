-- Lua provided by RyzenAPI 
-- Game: AppID 1144020
addappid(1144020)
addappid(1144021, 1, "84a4c91f48a5eeee053f2267963f9bf143439b266b49901d54ce663b14814160")
