-- Lua provided by RyzenAPI
-- Game: Apartment 666

-- MAIN APPLICATION
addappid(375680)
-- Game: addappid(375680)

-- MAIN APP DEPOTS / PACKAGES
addappid(375681, 1, "8d7263d0771a9d8f37b029322da3311d97e39a6ef18e2ee17814228dc8b475c0")
addappid(375682, 1, "d3f0be4331042e254a0ace6cdb3ac72f4a1692a94c09ace612c62ad1c6ca391c")
