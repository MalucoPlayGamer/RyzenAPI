-- Lua provided by RyzenAPI
-- Game: 1663680

-- MAIN APPLICATION
addappid(1663680)
-- Game: addappid(1663680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663681, 1, "0ea5c1607075ba7a3ccc9f44d3b1fd64067e6a3a6c9337402b7a311ba4e13d1d")
addappid(1663682, 1, "aceee204bb814767bb868244f330ac10fe144553c7359cfcf2a8fafc3fd1a8be")
