-- Lua provided by RyzenAPI
-- Game: John Carpenter's Toxic Commando

-- MAIN APPLICATION
addappid(2157830)
addappid(3933860)
addappid(3933870)
addappid(3933880)
addappid(4148650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2157831, 1, "3198b1f3831fde3e4f41577b2f01b20595ff7961ac9a679f856809d3219d0ef3")

