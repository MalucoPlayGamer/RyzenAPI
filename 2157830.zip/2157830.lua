-- Lua provided by RyzenAPI
-- Game: John Carpenter's Toxic Commando

-- MAIN APPLICATION
addappid(2157830)
addappid(3933860)
addappid(3933870)
addappid(3933880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157831, 1, "3198b1f3831fde3e4f41577b2f01b20595ff7961ac9a679f856809d3219d0ef3")

