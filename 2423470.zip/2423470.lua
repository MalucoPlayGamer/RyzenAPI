-- Lua provided by RyzenAPI
-- Game: AppID 2423470

-- MAIN APPLICATION
addappid(2423470)
-- Game: addappid(2423470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423471, 1, "328f92d83306eccb5f9f6eae23cfb7850204d21cff21785e77e8f51aef0ad20a")
