-- Lua provided by RyzenAPI
-- Game: Cellveillance-Digital upgraded version

-- MAIN APPLICATION
addappid(3586820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586821, 1, "8d81c8b27cfe053509650d6c320d207193ec50c2bcd773a3756e4c549e0ac2f0")

