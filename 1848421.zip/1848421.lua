-- Lua provided by RyzenAPI
-- Game: addappid(1848421)

-- MAIN APPLICATION
addappid(1848421)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848421,0,"ea8392143cf3fe4567df9aa415cb555b827e6dc4947ec4a7a00d999c631c5250")
