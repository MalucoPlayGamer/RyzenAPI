-- Lua provided by SkyAPI 
-- Game: Spectator 2
addappid(2358620)
addappid(2358621, 1, "23f9beb50b820800d08cd2f146218a2b40584a77b837478ebb38df599b2e426d")
