-- Lua provided by RyzenAPI
-- Game: Flowers -Le volume sur automne-

-- MAIN APPLICATION
addappid(1238730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238731, 1, "0d6a6ad961428475f304a92aa5ed6a66ed6fd17cb716bf505ba8c8b50c3fa092")
addappid(1238732, 1, "2ed24b4a7e270cd7716147353ef9896f404eb2deddeeab7ba28fcb4eaa983b76")
