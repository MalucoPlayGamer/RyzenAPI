-- Lua provided by RyzenAPI
-- Game: Starship EVO

-- MAIN APPLICATION
addappid(711980)

-- MAIN APP DEPOTS / PACKAGES
addappid(711981, 1, "7ec0a6f521b3284e171f338e02dee5ce3da8d1c4db13fe4b00e381ff90deb9ba")

