-- Lua provided by RyzenAPI 
-- Game: 思恋与你的终焉
addappid(3712960)
addappid(3712961, 1, "3a48ae57469dfb6d4a5804ab90c6d08cee329580465f18f142396a1970007d80")
