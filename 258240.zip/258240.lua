-- Lua provided by RyzenAPI
-- Game: Game: Tank Operations: European Campaign

-- MAIN APPLICATION
addappid(258240)
-- Game: addappid(258240)

-- MAIN APP DEPOTS / PACKAGES
addappid(258241, 1, "74bc71daa0eaaaef66e3f8e13a89a17fe193d5cc4dc9260846b2ceaaecb85d68")
