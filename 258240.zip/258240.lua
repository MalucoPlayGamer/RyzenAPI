-- Lua provided by RyzenAPI
-- Game: Tank Operations: European Campaign

-- MAIN APPLICATION
addappid(258240)

-- MAIN APP DEPOTS / PACKAGES
addappid(258241, 1, "74bc71daa0eaaaef66e3f8e13a89a17fe193d5cc4dc9260846b2ceaaecb85d68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
