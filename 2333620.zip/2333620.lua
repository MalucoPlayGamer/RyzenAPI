-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2333620)
-- Game: addappid(2333620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333620,0,"96f76cef76d32c7fb83d1ed67beafd6c6bae4c47a0cc2001794c99c4b4d4ef4f")
