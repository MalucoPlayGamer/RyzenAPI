-- Lua provided by RyzenAPI
-- Game: Game: ColorBlend FX: Desaturation

-- MAIN APPLICATION
addappid(670510)
-- Game: addappid(670510)

-- MAIN APP DEPOTS / PACKAGES
addappid(670511, 1, "fe230dfd3af85265dc16a248656e310abbce1c20e557fdbd16d5a0abc4d77eae")
