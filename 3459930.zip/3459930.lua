-- Lua provided by RyzenAPI 
-- Game: ‌Lexis
addappid(3459930)
addappid(3459931, 1, "f5e2baf801d6a81e9e4b2309d35884cffadc240c909f82a285407913bc73c6e0")
