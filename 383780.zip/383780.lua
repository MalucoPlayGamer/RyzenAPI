-- Lua provided by RyzenAPI
-- Game: Game: Judgement

-- MAIN APPLICATION
addappid(383780)
-- Game: addappid(383780)

-- MAIN APP DEPOTS / PACKAGES
addappid(383781, 1, "bd3a5898cda43f5fe6b3bdc0c782c8854f91d61561d389ca8fb924bf5d6c227b")
