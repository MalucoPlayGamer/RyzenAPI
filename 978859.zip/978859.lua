-- Lua provided by RyzenAPI
-- Game: 978859

-- MAIN APPLICATION
addappid(978859)
-- Game: addappid(978859)

-- MAIN APP DEPOTS / PACKAGES
addappid(978859,0,"6282336e7d1f2db555d652d0c80bb00632ed2c8dd007802a84d5ab92779988b3")
