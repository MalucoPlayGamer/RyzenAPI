-- Lua provided by RyzenAPI
-- Game: Game: Crimson Echoes

-- MAIN APPLICATION
addappid(2895060)
-- Game: addappid(2895060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895061, 1, "c8ac6024558d00969c65225a73d3705e8b861e5421f51506a97af09cf51d6ea9")
