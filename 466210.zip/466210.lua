-- Lua provided by RyzenAPI
-- Game: Race & Destroy

-- MAIN APPLICATION
addappid(466210)

-- MAIN APP DEPOTS / PACKAGES
addappid(466211, 1, "85f99dbdd1072ecdc91eec7f8cc2dceacd2b4a059699db0b33ad5a4b9178402b")

