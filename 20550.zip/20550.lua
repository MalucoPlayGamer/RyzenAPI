-- Lua provided by RyzenAPI
-- Game: Game: Red Faction II

-- MAIN APPLICATION
addappid(20550)
-- Game: addappid(20550)

-- MAIN APP DEPOTS / PACKAGES
addappid(20551, 1, "9109b487642a911729ef6be39d30019823d52f6d8898b8d3863b630455a5046f")
