-- Lua provided by RyzenAPI
-- Game: Thief Office Simulator

-- MAIN APPLICATION
addappid(3586380)
-- Game: addappid(3586380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586381, 1, "1027d37fe762d3cda8cf29d132a634c71005478ad8b6d30ce9c7c1e3c24adb5e")
