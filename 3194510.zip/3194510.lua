-- Lua provided by RyzenAPI 
-- Game: AppID 3194510
addappid(3194510)
addappid(3194511, 1, "23e50a1b5b43a60b67153b9fd68e4d802ebaa4dcc91731ac4ba84fd06684c1ec")
