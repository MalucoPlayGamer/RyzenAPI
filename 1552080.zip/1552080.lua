-- Lua provided by RyzenAPI
-- Game: Deepest Chamber: Resurrection

-- MAIN APPLICATION
addappid(1552080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552081, 1, "f09a27a36d2d419a1c972ecd02c36e9e3d13dd9ae80d9b4281293f2e5a669d43")
addappid(1552082, 1, "41234fd92df867f91356433b6903c2de4e4991a4e3a50e7f9e397ede235f132d")
