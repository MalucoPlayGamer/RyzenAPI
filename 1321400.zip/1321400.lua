-- Lua provided by RyzenAPI
-- Game: Diesel Punch

-- MAIN APPLICATION
addappid(1321400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1321401, 1, "b514bed4db2534e6e90735d9b4723677a1d041c552e968766d8d09ae4144d3fe")

