-- Lua provided by RyzenAPI
-- Game: Yokai Art 2: Tales of the Nine-Tails

-- MAIN APPLICATION
addappid(3405160)
addappid(4795890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405161,0,"ed48f9ed03da805eb57da01c0feb75d51fc40199852aac4b262805843d49cfea")
addappid(3813400,0,"cff9399cc9cee7006513bd244df20633d6dc996354809f0c6d1178483de228c5")

