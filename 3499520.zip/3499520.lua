-- Lua provided by RyzenAPI
-- Game: Piano Glow

-- MAIN APPLICATION
addappid(3499520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499521, 1, "6446540b05ba8770b71879f6c2643d3ef753f44af502a943cd4ac3da3a925dcc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
