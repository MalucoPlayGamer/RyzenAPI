-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport Manchester

-- MAIN APPLICATION
addappid(991064)
-- Game: addappid(991064)

-- MAIN APP DEPOTS / PACKAGES
addappid(991064,0,"43f37533adc7782edd958894247707dedae138595450212385d49febb1d6574d")
