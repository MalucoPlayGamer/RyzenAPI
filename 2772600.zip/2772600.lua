-- Lua provided by RyzenAPI
-- Game: I got CUCKED by a FUTANARI

-- MAIN APPLICATION
addappid(2772600)
-- Game: addappid(2772600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772601, 1, "e93a6ddb151331b8688549464bf555686ac727ade8f4c611afbc9bf395fab24d")
