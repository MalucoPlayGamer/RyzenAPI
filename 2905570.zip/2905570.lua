-- Lua provided by RyzenAPI
-- Game: Rune Coliseum Demo

-- MAIN APPLICATION
addappid(2905570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905571, 1, "73e026476d5869c20e8445b8322cce20a0b0242e77aa1c965384e48bdc6ef01b")
