-- Lua provided by RyzenAPI
-- Game: The Signal State Demo

-- MAIN APPLICATION
addappid(1662120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662121, 1, "a67d7838d5edcdb047aad19521d2cfa0fd463e174b3015e3e1bee0622e4b0b5c")

