-- Lua provided by RyzenAPI
-- Game: Mango's Wonderland

-- MAIN APPLICATION
addappid(2450540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450542,0,"e12911422db164ac746292c17ee296a28554f23f0b1f487d6ce083f050534c5f")

