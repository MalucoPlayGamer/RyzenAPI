-- Lua provided by RyzenAPI
-- Game: Mango's Wonderland

-- MAIN APPLICATION
addappid(2450540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2450542,0,"e12911422db164ac746292c17ee296a28554f23f0b1f487d6ce083f050534c5f")

