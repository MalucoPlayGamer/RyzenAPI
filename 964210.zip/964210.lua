-- Lua provided by RyzenAPI
-- Game: 964210

-- MAIN APPLICATION
addappid(964210)
-- Game: addappid(964210)

-- MAIN APP DEPOTS / PACKAGES
addappid(964211, 1, "8977cf97964b51b9f45a64187f09a8a5f8925ca242c722b3f271e5ab9437cfaa")
