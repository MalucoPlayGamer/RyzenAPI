-- Lua provided by RyzenAPI
-- Game: AppID 729060

-- MAIN APPLICATION
addappid(729060)

-- MAIN APP DEPOTS / PACKAGES
addappid(729061, 1, "6c040a540645ccea06db73af76dad7691dba16dcde198637268dc53b33a91c81")

