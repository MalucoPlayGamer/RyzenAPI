-- Lua provided by RyzenAPI
-- Game: 1269770

-- MAIN APPLICATION
addappid(1269770)
-- Game: addappid(1269770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269771, 1, "80e1ebc9a15de4c06706eb353ddf84d16134ce8c4cd095a0b588a226a8389f61")
