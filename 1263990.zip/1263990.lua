-- Lua provided by RyzenAPI
-- Game: addappid(1263990)

-- MAIN APPLICATION
addappid(1263990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263991, 1, "c07af9a8925d8799952ba91759ac79c4f3bbf26cd743ab6237044b1bc0edfcf7")
