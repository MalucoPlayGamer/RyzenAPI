-- Lua provided by RyzenAPI
-- Game: Game: Uncharted Waters II

-- MAIN APPLICATION
addappid(628170)
-- Game: addappid(628170)

-- MAIN APP DEPOTS / PACKAGES
addappid(628171, 1, "d2f360beb7e774b4939ae238dcb30f49bea8a33cb51bb1eb0bd72b0a1a75ef13")
