-- Lua provided by RyzenAPI
-- Game: addappid(2742730)

-- MAIN APPLICATION
addappid(2742730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742731, 1, "8db533458a2ff850a75fa45db4e2d645d128dd74460ecd6c108dc87bfad32ede")
