-- Lua provided by RyzenAPI
-- Game: addappid(2620310)

-- MAIN APPLICATION
addappid(2620310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620311, 1, "6d9062a26aa55d6ee488bc3ff39f682640e350837e6db6450d01bee2ea5a7d47")
