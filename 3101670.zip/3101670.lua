-- Lua provided by RyzenAPI 
-- Game: The Midnight Bus
addappid(3101670)
addappid(3101671, 1, "1cc2ca81f211a3fed710263552861d83a3725137eb382c0c9621b96ab1bf8ecb")
