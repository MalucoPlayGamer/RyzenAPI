-- Lua provided by RyzenAPI
-- Game: 3101670

-- MAIN APPLICATION
addappid(3101670)
-- Game: addappid(3101670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101671, 1, "1cc2ca81f211a3fed710263552861d83a3725137eb382c0c9621b96ab1bf8ecb")
