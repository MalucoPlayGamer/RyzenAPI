-- Lua provided by RyzenAPI
-- Game: Versus Vampire

-- MAIN APPLICATION
addappid(2476580)
-- Game: addappid(2476580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476581, 1, "fc7c1be5f7837d285bd074c79939f46d3ec24cf5ee018f5d5a025ccf836c9c1b")
