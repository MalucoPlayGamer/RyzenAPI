-- Lua provided by SkyAPI 
-- Game: Versus Vampire
addappid(2476580)
addappid(2476581, 1, "fc7c1be5f7837d285bd074c79939f46d3ec24cf5ee018f5d5a025ccf836c9c1b")
