-- Lua provided by RyzenAPI
-- Game: This Land Is My Land

-- MAIN APPLICATION
addappid(1069640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069641, 1, "e7f0959ebfd147f6293c889d88be9877c513d1923673402fa63c2cbf4a182675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1181530)
addappid(2080110)
