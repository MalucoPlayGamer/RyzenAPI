-- Lua provided by RyzenAPI
-- Game: This Land Is My Land

-- MAIN APPLICATION
addappid(1069640)
-- Game: addappid(1069640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069641, 1, "e7f0959ebfd147f6293c889d88be9877c513d1923673402fa63c2cbf4a182675")
