-- Lua provided by RyzenAPI
-- Game: Vegetaball

-- MAIN APPLICATION
addappid(850880)

-- MAIN APP DEPOTS / PACKAGES
addappid(850881,0,"a41901d23fccfb34c09846710a775f3089978d899bf462bbda74bac098f5e773")

