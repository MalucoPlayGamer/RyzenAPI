-- Lua provided by RyzenAPI
-- Game: Botology

-- MAIN APPLICATION
addappid(363610)
addappid(385160)
addappid(388670)
addappid(389620)
addappid(389630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(363611, 1, "b230825012ddc9b5bdcd10c4606ad769987f7527d4dfa61c2f5b4308b8e9872e")

