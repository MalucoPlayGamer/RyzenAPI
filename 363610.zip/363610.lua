-- Lua provided by RyzenAPI
-- Game: addappid(363610)

-- MAIN APPLICATION
addappid(363610)
addappid(385160)
addappid(388670)
addappid(389620)
addappid(389630)

-- MAIN APP DEPOTS / PACKAGES
addappid(363611, 1, "b230825012ddc9b5bdcd10c4606ad769987f7527d4dfa61c2f5b4308b8e9872e")
