-- Lua provided by RyzenAPI
-- Game: Game: Hentai Femdom Sim: Femdom University

-- MAIN APPLICATION
addappid(1485100)
-- Game: addappid(1485100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485101, 1, "3855aabacf0ac086f83ae57937067984de4a949bca905d6619e137a5d77d4cd2")
