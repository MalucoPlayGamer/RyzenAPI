-- Lua provided by RyzenAPI
-- Game: Game: AppID 2786780

-- MAIN APPLICATION
addappid(2786780)
-- Game: addappid(2786780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786781, 1, "522c736e247c2160909187c8f86db19da81c04cba1b7c7162d8388ffde48fc81")
