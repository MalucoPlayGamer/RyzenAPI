-- Lua provided by RyzenAPI
-- Game: Neon Nights 2 Demo

-- MAIN APPLICATION
addappid(1998430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998431, 1, "bd36e0b21df37aa63a337d72f3b6bea4e147be7f8005a5b5e2e17df1d52e0dc4")

