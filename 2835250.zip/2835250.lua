-- Lua provided by RyzenAPI
-- Game: UFO BLAST

-- MAIN APPLICATION
addappid(2835250)
-- Game: addappid(2835250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835251, 1, "590dd52112748962bd4f6eb7ab9542cf7ebb225a935278fa9825e5a42aa89f23")
