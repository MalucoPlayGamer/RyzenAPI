-- Lua provided by RyzenAPI
-- Game: Space Fetus Attack Idle Clicker

-- MAIN APPLICATION
addappid(4684040) -- Space Fetus Attack Idle Clicker

-- MAIN APP DEPOTS / PACKAGES
addappid(4684041, 1, "a5036154bb41581c552eb4692c8c1e399e4dd94b5697294789ff33023a466486") -- Depot 4684041

