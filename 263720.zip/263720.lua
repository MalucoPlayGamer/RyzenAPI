-- Lua provided by SkyAPI 
-- Game: AppID 263720
addappid(263720)
addappid(263721, 1, "cd6c18d816198aa5b63768ffea9306f9b1c2f2b0a391a40b3dab5225cb7e67ed")
