-- Lua provided by RyzenAPI
-- Game: AppID 263720

-- MAIN APPLICATION
addappid(263720)

-- MAIN APP DEPOTS / PACKAGES
addappid(263721, 1, "cd6c18d816198aa5b63768ffea9306f9b1c2f2b0a391a40b3dab5225cb7e67ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
