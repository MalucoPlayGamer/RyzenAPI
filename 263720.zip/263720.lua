-- Lua provided by RyzenAPI
-- Game: AppID 263720

-- MAIN APPLICATION
addappid(263720)
-- Game: addappid(263720)

-- MAIN APP DEPOTS / PACKAGES
addappid(263721, 1, "cd6c18d816198aa5b63768ffea9306f9b1c2f2b0a391a40b3dab5225cb7e67ed")
