-- Lua provided by RyzenAPI
-- Game: Game: Lucent Heart

-- MAIN APPLICATION
addappid(283060)
-- Game: addappid(283060)

-- MAIN APP DEPOTS / PACKAGES
addappid(283061, 1, "148544f392048a2f880e3f9dc5080cfd9e5e7da14db5ecae43e1cced5969abb5")
