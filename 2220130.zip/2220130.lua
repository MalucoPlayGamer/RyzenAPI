-- Lua provided by RyzenAPI
-- Game: Chaos Saw

-- MAIN APPLICATION
addappid(2220130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220131, 1, "a466bebab94b49ab3f9945cf94cdb7fdaa32d68c1c18e4210a032419961356c0")
