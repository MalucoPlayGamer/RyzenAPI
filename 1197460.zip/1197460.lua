-- Lua provided by RyzenAPI
-- Game: Game: AppID 1197460

-- MAIN APPLICATION
addappid(1197460)
-- Game: addappid(1197460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197461, 1, "90fb8e71af1d58b15d2f4e62feb79d179383116b5c3e5a052abd71884b3cab15")
