-- Lua provided by RyzenAPI
-- Game: Sex and the Furry Titty 3: Come Inside, Sweety Soundtrack

-- MAIN APPLICATION
addappid(2900380)
-- Game: addappid(2900380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2900381, 1, "a598816aaac0d32f7166c24a9078f9a7f34acce4b411f2c962b8477444bfae1f")
addappid(2900382, 1, "d984a8e1512b2c3870cb012aa9ba34c18fa0f0e6330c6d4e7c106b4e37518f33")
