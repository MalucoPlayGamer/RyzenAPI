-- Lua provided by RyzenAPI
-- Game: Purgatory -NARAKU-

-- MAIN APPLICATION
addappid(2851770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851772,0,"c2bb6b962c64b770e80a14acd4342976ccda6e87afd608ec415e28eb081e70d5")

