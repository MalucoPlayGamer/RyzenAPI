-- Lua provided by RyzenAPI
-- Game: addappid(1535870)

-- MAIN APPLICATION
addappid(228988)
addappid(228989)
addappid(228990)
addappid(1535870)
addappid(1535871)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535872,0,"442edf369105b847aa7bbdca8650f84bed505b5e2cfab9c9af614c7ab07aea5c")
