-- Lua provided by RyzenAPI
-- Game: One More Night

-- MAIN APPLICATION
addappid(2720620)
addappid(4528750)
-- Game: addappid(2720620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720621, 1, "3cdb35e089661a1ff0a427ca4f6e72b88a8461de151ccc96ce8079b5adaf4c3b")
