-- Lua provided by RyzenAPI
-- Game: addappid(2097570)

-- MAIN APPLICATION
addappid(2097570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097571, 1, "162f5956918437b675aeb87b3b4b3392bb4b253d3d41aeb4701ffa463b0d1f1e")
