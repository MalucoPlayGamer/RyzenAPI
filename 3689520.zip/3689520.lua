-- Lua provided by RyzenAPI
-- Game: Game: Bioprototype

-- MAIN APPLICATION
addappid(3689520)
-- Game: addappid(3689520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689521, 1, "0e304ad2c6f9936aa814db0b52212a611a28b116bf9c0d9052cfcdd4f059d8ae")
addappid(3689522, 1, "8481aedf4534003cc27cce2faccd8ad69167b37db9c528c614c98191ffdc89f8")
addappid(3689523, 1, "21c8e6606fd499d5e935c249bc6704f1d692820ec02050357364b91048691b60")
