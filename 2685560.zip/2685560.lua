-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2685560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685560,0,"9bbfc46ef324d6a9a93e44a0502ca9335243e40326681528921710e4c02c6594")
