-- Lua provided by RyzenAPI
-- Game: addappid(2860450)

-- MAIN APPLICATION
addappid(2860450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2860452,0,"d7b37153c1da580c67e82fb5a747ffb41b004cda7606e9489ca40442b64bbfa3")
