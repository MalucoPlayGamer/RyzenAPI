-- Lua provided by RyzenAPI
-- Game: SaGa Frontier Remastered

-- MAIN APPLICATION
addappid(1295270)
addappid(1550610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295271, 1, "c0b81b40affc02eb3db6b3a40a61b3acc73b1e46e2c1bb8add8b791cf5e7e6fa")
