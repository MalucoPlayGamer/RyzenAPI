-- Lua provided by RyzenAPI
-- Game: KEEP GAMBLING

-- MAIN APPLICATION
addappid(3720460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720461,0,"b98c998a95006e204427e460d7500e011221c58141853c98d0d78d71fb25d30a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
