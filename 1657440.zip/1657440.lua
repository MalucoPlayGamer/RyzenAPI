-- Lua provided by RyzenAPI
-- Game: 贝丽尔养成计划 Demo

-- MAIN APPLICATION
addappid(1657440)
-- Game: addappid(1657440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657441, 1, "794213964d6c3975cc7fb68101a0922fce047a4a6065ea42205558b0151f84d9")
