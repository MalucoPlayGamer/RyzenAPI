-- Lua provided by RyzenAPI
-- Game: HARDCORE MECHA - Digital Art Book

-- MAIN APPLICATION
addappid(1125640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125640,0,"0e5880dcb3b9bdc149864470e31f96e8afec03d3219d31fef7758fc428f29672")

