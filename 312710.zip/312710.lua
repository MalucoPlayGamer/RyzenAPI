-- Lua provided by RyzenAPI
-- Game: Game: AppID 312710

-- MAIN APPLICATION
addappid(312710)
-- Game: addappid(312710)

-- MAIN APP DEPOTS / PACKAGES
addappid(312711, 1, "4f7beb08dacbfb25742ff0143d36e7de055383ed070b025f9625bd0ae945f3ab")
