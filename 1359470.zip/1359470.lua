-- Lua provided by RyzenAPI
-- Game: 1359470

-- MAIN APPLICATION
addappid(1359470)
addappid(1366600)
-- Game: addappid(1359470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359471, 1, "f9d1c13db622941f717cb144768f6d18494e5ae2cbbce46299a20c53f78d7e0f")
