-- Lua provided by RyzenAPI
-- Game: A Bad Day For A Hangover

-- MAIN APPLICATION
addappid(2442880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2442881, 1, "c418b177c7df5b713c4d59c5011e6bdbe0af282b2994fa4adf43f0169207a22e")

