-- Lua provided by RyzenAPI
-- Game: Game: AppID 894110

-- MAIN APPLICATION
addappid(894110)
-- Game: addappid(894110)

-- MAIN APP DEPOTS / PACKAGES
addappid(894111, 1, "626ebc7064fdb8a6f435599aa3fe8c1950c0df989ed114ff5c509631b5e38acb")
addappid(894112, 1, "44162bf23ab1606a24c4e6a8f723306c2247e109618cdc3acf6e52986fc6bb6d")
addappid(894113, 1, "24375d1435d05b04738ba8742a47ba8de290c414b93d5be3acc0f814bb51d54d")
