-- Lua provided by RyzenAPI
-- Game: Game: Trivia Vault: Super Heroes Trivia 2

-- MAIN APPLICATION
addappid(705090)
-- Game: addappid(705090)

-- MAIN APP DEPOTS / PACKAGES
addappid(705091, 1, "ea3e386080c8e00e8681560a755badc5f31a1caf581876c9991ff5901ed0ecb3")
