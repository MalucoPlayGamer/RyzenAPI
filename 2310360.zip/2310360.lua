-- Lua provided by RyzenAPI
-- Game: Up All Night: Daybreak

-- MAIN APPLICATION
addappid(2310360)
-- Game: addappid(2310360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310362,0,"6ff654d38e02658cf0cf8af02b5ff73935a2b9cedff8089236d344cd98fe48d5")
addappid(2310363,0,"8d06333763fdf2b2b011689342bedcb513a2a8a953a3994a64142929f487149b")
addappid(2310364,0,"96c607b3117c3feef8d2a87dfc1851c737edac5857b62e84ea93cf69fd1e719e")
