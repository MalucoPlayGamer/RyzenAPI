-- Lua provided by RyzenAPI
-- Game: Killer Tank

-- MAIN APPLICATION
addappid(1483160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483161, 1, "58e4b006377a30fb52c8a7ca04d68b52e7db63cb63e9ec9c5e2b35ceda1030c4")
