-- Lua provided by RyzenAPI
-- Game: addappid(3252300)

-- MAIN APPLICATION
addappid(3252300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3252301, 1, "476fe4266e0c97b278b879efa609e130e74bdbec2f568ba6451c2bf906b6bd06")
