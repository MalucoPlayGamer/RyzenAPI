-- Lua provided by RyzenAPI
-- Game: Escape 2042 - The Truth Defenders

-- MAIN APPLICATION
addappid(598590)

-- MAIN APP DEPOTS / PACKAGES
addappid(598591,0,"f8a051408f91301370dd543af04d1ec64af22822603855147f893426dd21e62e")

