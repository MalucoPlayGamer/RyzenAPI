-- Lua provided by RyzenAPI
-- Game: NOSTALGIC TRAIN

-- MAIN APPLICATION
addappid(801260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(801261, 1, "3b7222f3b05d91fe340e98b26b157d385e5cdfd1da543d90344f5988aff0b05e")

