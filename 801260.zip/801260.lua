-- Lua provided by SkyAPI 
-- Game: AppID 801260
addappid(801260)
addappid(801261, 1, "3b7222f3b05d91fe340e98b26b157d385e5cdfd1da543d90344f5988aff0b05e")
