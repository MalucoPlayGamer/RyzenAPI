-- Lua provided by RyzenAPI
-- Game: addappid(3297310)

-- MAIN APPLICATION
addappid(3297310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3297311, 1, "251e706b04b6d6e1a2a21ad63151c40e781d9edfb4ed2b8705166aea4767eac2")
