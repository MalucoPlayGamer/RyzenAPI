-- Lua provided by RyzenAPI
-- Game: The Cursed Hour

-- MAIN APPLICATION
addappid(3297310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3297311, 1, "251e706b04b6d6e1a2a21ad63151c40e781d9edfb4ed2b8705166aea4767eac2")

