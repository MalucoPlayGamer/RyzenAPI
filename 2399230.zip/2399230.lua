-- Lua provided by RyzenAPI
-- Game: AppID 2399230

-- MAIN APPLICATION
addappid(2399230)
-- Game: addappid(2399230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399231, 1, "a94ba63c535f3f377bdf77f61923f538ffea399e34c11f990f6b22dc1f01c7bd")
