-- Lua provided by RyzenAPI
-- Game: AppID 596690

-- MAIN APPLICATION
addappid(596690)

-- MAIN APP DEPOTS / PACKAGES
addappid(596691, 1, "6bb40904333b7e7d6e1a1276d824dd0201a8daf0f8871c77f4e11bb3bc585fe8")

