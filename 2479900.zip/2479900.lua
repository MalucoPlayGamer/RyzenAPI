-- Lua provided by RyzenAPI
-- Game: AppID 2479900

-- MAIN APPLICATION
addappid(2479900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479901, 1, "d36f6d716587dbb82c34f2b9c3ef5db4ee68788c8de1b1d21a0ffeea1b5b4643")

