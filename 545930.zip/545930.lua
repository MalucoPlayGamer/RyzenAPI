-- Lua provided by RyzenAPI
-- Game: Game: Hunting Unlimited 2011

-- MAIN APPLICATION
addappid(545930)
-- Game: addappid(545930)

-- MAIN APP DEPOTS / PACKAGES
addappid(545931, 1, "c397c74de164a218694db517478fd831ef91375933373b1693c958a97b1e4b9a")
