-- Lua provided by RyzenAPI
-- Game: Emerald City Confidential™

-- MAIN APPLICATION
addappid(37260)
-- Game: addappid(37260)

-- MAIN APP DEPOTS / PACKAGES
addappid(37261, 1, "d32febf905a7f8bf61da2ef3c936da0245c47b129b3f09d44ba067205e7e64e8")
