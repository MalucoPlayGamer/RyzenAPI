-- Lua provided by RyzenAPI
-- Game: 魔物娘捕获大陆-日版

-- MAIN APPLICATION
addappid(1800150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800150,0,"5ad0e438283788afc1f0de72307a813a16ad3ed4da54c24ffb094e9da25921b9")
