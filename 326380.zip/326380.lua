-- Lua provided by RyzenAPI
-- Game: Mystery of Neuschwanstein

-- MAIN APPLICATION
addappid(326380)
-- Game: addappid(326380)

-- MAIN APP DEPOTS / PACKAGES
addappid(326381, 1, "273841347ebb26848d8c74e45a40d3e260bd8e74d1fb67b2385874437736cf4b")
addappid(326383, 1, "8b84300bc50a887500a1cd106fcf74892b18a3f4340fe2e675527e6e22a55401")
