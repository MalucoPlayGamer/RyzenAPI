-- Lua provided by RyzenAPI
-- Game: Game: Last Standing

-- MAIN APPLICATION
addappid(1554770)
addappid(1606230)
-- Game: addappid(1554770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554771, 1, "002244ad392b9906569f50fd19c09eb876da71cea590aa8a8bcd3d22537023d9")
