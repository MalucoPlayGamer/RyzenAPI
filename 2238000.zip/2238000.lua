-- Lua provided by RyzenAPI
-- Game: AppID 2238000

-- MAIN APPLICATION
addappid(2238000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238001, 1, "b041dcc49866b2da10cc2dc59764b9af203f8d7be6948c2f4b7a4fc3ae1bb8ba")

