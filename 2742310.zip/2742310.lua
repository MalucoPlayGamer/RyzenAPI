-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2742310)
addappid(2742310,0,"ff0aaa74bf19c7cc977a21e80d354be7f4ae58a1f7c4814b720d4791a97ae190")
-- setManifestid(2742310,"2977321481525931099")