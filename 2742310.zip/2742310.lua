-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2742310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742310,0,"ff0aaa74bf19c7cc977a21e80d354be7f4ae58a1f7c4814b720d4791a97ae190")
