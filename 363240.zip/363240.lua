-- Lua provided by RyzenAPI
-- Game: Caveman Craig

-- MAIN APPLICATION
addappid(363240)

-- MAIN APP DEPOTS / PACKAGES
addappid(363241, 1, "ba82bab471f08dbfb84aac35e86b0832da9c5f515e7267715daeacc743b05624")
addappid(363242, 1, "06ac8505339ce3c455ff85c4dd32f09ec70b137af1c3e40e0b3e4b0e1f89d2f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
