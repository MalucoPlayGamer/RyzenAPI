-- Lua provided by RyzenAPI
-- Game: 1662210

-- MAIN APPLICATION
addappid(1662210)
-- Game: addappid(1662210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662211, 1, "2f4260f71eb14c440ae0308f39bc10b34f9e54d522307a318c23ae5d2e03419f")
