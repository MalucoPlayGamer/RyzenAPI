-- Lua provided by RyzenAPI
-- Game: START AGAIN: a prologue (an artbook)

-- MAIN APPLICATION
addappid(1697580)
-- Game: addappid(1697580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697580,0,"0f8c931158d89d8ed3453a9f8ccd78b1b18aef14a8419ab4a1a0676826228c89")
