-- Lua provided by SkyAPI 
-- Game: Moonshot
addappid(426930)
addappid(426931, 1, "f576a2dd3033c25581a53ae362f542dd2d33cb5186969970ca836590ada535ee")
