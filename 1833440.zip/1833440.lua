-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 5

-- MAIN APPLICATION
addappid(1833440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833440,0,"3172f30fd477cf0bb44fee8ef4643f8240458b3e86267f94fa1c6046299f2143")

