-- Lua provided by RyzenAPI
-- Game: Steelrising

-- MAIN APPLICATION
addappid(1283400)
-- Game: addappid(1283400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283401, 1, "294af8455925dc234d9ff5463684a75c642770b005008c48f2683042aa08ec05")
