-- Lua provided by RyzenAPI
-- Game: Steelrising

-- MAIN APPLICATION
addappid(1283400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283401, 1, "294af8455925dc234d9ff5463684a75c642770b005008c48f2683042aa08ec05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2004260)
addappid(2004261)
addappid(2021370)
