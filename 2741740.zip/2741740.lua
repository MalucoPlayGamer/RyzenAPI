-- Lua provided by RyzenAPI
-- Game: Project Tape

-- MAIN APPLICATION
addappid(2741740)
addappid(3542210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2741741, 1, "8c82d203dd018936b2ebb1e3021370e1da71fea248351417bf9d2f847bc5e71d")

