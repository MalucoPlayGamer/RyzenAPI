-- Lua provided by RyzenAPI
-- Game: Project Tape

-- MAIN APPLICATION
addappid(2741740)
addappid(3542210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741741, 1, "8c82d203dd018936b2ebb1e3021370e1da71fea248351417bf9d2f847bc5e71d")
