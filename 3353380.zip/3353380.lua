-- Lua provided by RyzenAPI
-- Game: Game: Dead by Skill Check

-- MAIN APPLICATION
addappid(3353380)
-- Game: addappid(3353380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3353381, 1, "45073543b9ed7c2b056953380f6f18993b344745275a72f51b7fb43a8b6b5d84")
