-- Lua provided by RyzenAPI
-- Game: Dead by Skill Check

-- MAIN APPLICATION
addappid(3353380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3353381, 1, "45073543b9ed7c2b056953380f6f18993b344745275a72f51b7fb43a8b6b5d84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
