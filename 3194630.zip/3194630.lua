-- Lua provided by RyzenAPI
-- Game: 3194630

-- MAIN APPLICATION
addappid(3194630)
-- Game: addappid(3194630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194631, 1, "bf4628dab610158f5afffa2e046a9bef10cb484138da1914d4984d1e1cf5215b")
