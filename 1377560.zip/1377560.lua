-- Lua provided by RyzenAPI
-- Game: Game: К.О.Р.О.В.А.Н.Ы | Симулятор Грабежа Корованов

-- MAIN APPLICATION
addappid(1377560)
-- Game: addappid(1377560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377561, 1, "9772931e3ade1941307d990fba2823957b52bebd4d27a36763ff5f2eb06bb532")
