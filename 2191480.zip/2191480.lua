-- Lua provided by SkyAPI 
-- Game: Jumbo Airport Story
addappid(2191480)
addappid(2191481, 1, "7da77f558540a4a9f77e8386ee5407aa6223f6a3b4aa20cebe4a7a2972c79c15")
