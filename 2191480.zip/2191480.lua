-- Lua provided by RyzenAPI
-- Game: Jumbo Airport Story

-- MAIN APPLICATION
addappid(2191480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191481, 1, "7da77f558540a4a9f77e8386ee5407aa6223f6a3b4aa20cebe4a7a2972c79c15")

