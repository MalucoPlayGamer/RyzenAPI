-- Lua provided by RyzenAPI
-- Game: Let's Explore the Jungle (Junior Field Trips)

-- MAIN APPLICATION
addappid(363070)
-- Game: addappid(363070)

-- MAIN APP DEPOTS / PACKAGES
addappid(363071, 1, "01ccdb36a1d90316d8d88be62a5c4ccf436a4854c3c6a9465cac2daf58583685")
addappid(363072, 1, "f351702ce741fd4ca55c932b5965855f25ac01cdb7e17e5ab69e523288027db4")
addappid(363073, 1, "fda46d9d14104654719d38cc0e8d271d3f1ababc233d347f3b9a6195c15e6b50")
addappid(363074, 1, "cfa2ce1fd537d44afd543700b8524c5a0d6a39eea2ea1f5b0580d85a6f024f6d")
addappid(363075, 1, "21f5af4805b058b9561ecfee7b25276026162265d5566bc35e6e5309f40bd951")
addappid(363076, 1, "81cc1eacf0d8fc5b70809ccb193be76e6f0d9c2909d1b36ecd1aba363a4f3ddf")
addappid(363077, 1, "b57648dc6bc480d1b139f550adae01bf2049768da3c0bb134a2816e8f942f9a5")
