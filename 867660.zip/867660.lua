-- Lua provided by SkyAPI 
-- Game: NYKRA: Before
addappid(867660)
addappid(867661, 1, "972016225b476b46152e4823aa8bf45919732ef420477d5fa227dc58123de435")
