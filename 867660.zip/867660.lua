-- Lua provided by RyzenAPI
-- Game: Game: NYKRA: Before

-- MAIN APPLICATION
addappid(867660)
-- Game: addappid(867660)

-- MAIN APP DEPOTS / PACKAGES
addappid(867661, 1, "972016225b476b46152e4823aa8bf45919732ef420477d5fa227dc58123de435")
