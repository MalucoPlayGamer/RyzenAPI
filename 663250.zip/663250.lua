-- Lua provided by RyzenAPI
-- Game: Professional Farmer: American Dream

-- MAIN APPLICATION
addappid(663250)

-- MAIN APP DEPOTS / PACKAGES
addappid(663251,0,"9c8484c27d97e6807bdcc4cf21395eae1c5b1edf305df0283e7ab98b7baf08a1")

