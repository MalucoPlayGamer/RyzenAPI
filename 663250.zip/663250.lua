-- Lua provided by RyzenAPI
-- Game: Professional Farmer: American Dream

-- MAIN APPLICATION
addappid(663250)

-- MAIN APP DEPOTS / PACKAGES
addappid(663251,0,"9c8484c27d97e6807bdcc4cf21395eae1c5b1edf305df0283e7ab98b7baf08a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
