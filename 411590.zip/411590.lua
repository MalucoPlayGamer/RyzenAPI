-- Lua provided by RyzenAPI
-- Game: The Rivers of Alice - Extended Version

-- MAIN APPLICATION
addappid(411590)

-- MAIN APP DEPOTS / PACKAGES
addappid(411591, 1, "950c8f4b75c48c11b85de77663664116d31bb67c353b501bf9505ab7bb0baced")
