-- Lua provided by RyzenAPI
-- Game: Tropicalia: a Brazilian Game

-- MAIN APPLICATION
addappid(1375760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375762,0,"871c26bdee3d99056d4e286735fc5d323e7ae4dd04896be006b4c534e84237a9")

