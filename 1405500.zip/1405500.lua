-- Lua provided by RyzenAPI
-- Game: Angel at Dusk

-- MAIN APPLICATION
addappid(1405500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1405501, 1, "bbb8a1a4d9242c0811f26813add00cd9e9611731d3916b1f150dac1b59613055")
addappid(1405503, 1, "b5383257b43121abc372b7a3b3a0e17341c5589b7edb9e599a14a635c35402ec")
addappid(1405504, 1, "5327ca0c285c962c5ac02e02880f70ce6a02439dad898c653d97d72c1946b130")

