-- Lua provided by RyzenAPI
-- Game: Game: Mahjong Strip Solitaire: Harem Guild

-- MAIN APPLICATION
addappid(1008520)
-- Game: addappid(1008520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008521, 1, "c407c24477f420e373e04af117c10989619ef56a4119a9bdeee67214f3131585")
