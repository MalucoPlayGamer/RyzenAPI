-- Lua provided by RyzenAPI
-- Game: Panzer Killer

-- MAIN APPLICATION
addappid(655440)

-- MAIN APP DEPOTS / PACKAGES
addappid(655441,0,"3f1f07c9a4c430d09ecad6ef0283dd89dd2ce03debdc3b02fcc7057244c0d063")

