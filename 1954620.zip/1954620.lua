-- Lua provided by RyzenAPI
-- Game: 迷失幻途 Playtest

-- MAIN APPLICATION
addappid(1954620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954621, 1, "a77e93aa5fb43833ac433037c0159593ec8196d3686f315e93cce0d92eb39757")

