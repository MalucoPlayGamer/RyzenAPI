-- Lua provided by RyzenAPI
-- Game: ABEL

-- MAIN APPLICATION
addappid(2439100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439101, 1, "14df8ecb391c52b0b51a7a542e6b96454076d1546e8cf21db1bdd734d2e2ad8d")
