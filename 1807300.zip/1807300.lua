-- Lua provided by RyzenAPI 
-- Game: NewHrdGame
addappid(1807300)
addappid(1807301, 1, "9ddc28fdd26ef61d6b0457fe89a21b277d3d8367d9624f8316475c9a9cb19dee")
