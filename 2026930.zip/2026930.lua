-- Lua provided by RyzenAPI
-- Game: Game: AppID 2026930

-- MAIN APPLICATION
addappid(2026930)
-- Game: addappid(2026930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026931, 1, "b2d374db295fd01e1d827885378c319cab93ee4a85d877a7421c1445d5339c40")
