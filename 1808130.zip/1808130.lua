-- Lua provided by RyzenAPI 
-- Game: Mysteries Under Lake Ophelia
addappid(1808130)
addappid(1808131, 1, "9aa437db3c6e04bb0d4727d49fefdc26cae7630a8d456e0cb61701e7ac79df6f")
