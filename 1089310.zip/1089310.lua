-- Lua provided by RyzenAPI 
-- Game: Nordlicht
addappid(1089310)
addappid(1089311, 1, "a2c8eee1a3ad375ff0dd3ab9a698284719e9558dfbbc86e622a46c580a15d273")
