-- Lua provided by RyzenAPI
-- Game: Dark Grim Mariupolis

-- MAIN APPLICATION
addappid(597730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(597731, 1, "eafcfcc0f7229768cf9003d34545f7296f16ff1239f2c7b68066027a4dcb8569")
addappid(828920, 0, "b1229bb47d35d118498a0d4bb75d9facb956bb1b2df31b355523bb2a61e60c7d")
