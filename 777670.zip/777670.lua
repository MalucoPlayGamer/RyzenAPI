-- Lua provided by RyzenAPI
-- Game: Okinawa Rush

-- MAIN APPLICATION
addappid(777670)
-- Game: addappid(777670)

-- MAIN APP DEPOTS / PACKAGES
addappid(777671, 1, "02a99851a7c851730ff982a5100addc1ebcebcb016bdff457ea9b373578a656a")
