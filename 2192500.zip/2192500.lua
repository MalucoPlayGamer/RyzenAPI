-- Lua provided by RyzenAPI
-- Game: Train Operator 377

-- MAIN APPLICATION
addappid(2192500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192501, 1, "edd4d4b0fb573703b124cb2239e36203c8055e35dfe0978a424cffbae3713955")

