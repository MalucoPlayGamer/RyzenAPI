-- Lua provided by RyzenAPI
-- Game: Monster Train 2

-- MAIN APPLICATION
addappid(2742830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742831, 1, "C2A5386E1F6FEABAD976FFD5E88028153D29A7D432483EE3763229BFF9075FCB")
addappid(3580220, 0, "6a48b119fa0f4779ec8618000d21337750db9a1e0eac4f89cdf1afb16ea4a7ec")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3993450)
