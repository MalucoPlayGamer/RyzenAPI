-- Lua provided by RyzenAPI
-- Game: Game: Slavic Winter Simulator

-- MAIN APPLICATION
addappid(1519150)
-- Game: addappid(1519150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519151, 1, "372564582ea2053371c5d4e0b6646475f24b2466f600ff0e184e0c55f384cf41")
