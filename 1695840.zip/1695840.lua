-- Lua provided by RyzenAPI
-- Game: addappid(1695840)

-- MAIN APPLICATION
addappid(1695840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695841, 1, "a5c05e649b5344a6d64feff8c3fec9734736bf52ec87c6d56cb446ecb2f52f04")
