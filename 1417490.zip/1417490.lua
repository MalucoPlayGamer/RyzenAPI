-- Lua provided by RyzenAPI
-- Game: addappid(1417490)

-- MAIN APPLICATION
addappid(1417490)
addappid(1422991)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417491, 1, "a0eb1e9de85884cac2dc327c8111d923431eeb4748aabc771f2bf1fef88a2640")
