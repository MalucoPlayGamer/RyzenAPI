-- Lua provided by RyzenAPI
-- Game: Fractal Fury

-- MAIN APPLICATION
addappid(1417490)
addappid(1422991)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417491, 1, "a0eb1e9de85884cac2dc327c8111d923431eeb4748aabc771f2bf1fef88a2640")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
