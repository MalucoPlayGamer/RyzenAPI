-- Lua provided by RyzenAPI
-- Game: We Were Here Together

-- MAIN APPLICATION
addappid(865360)
addappid(1170850)
addappid(1170860)
-- Game: addappid(865360)

-- MAIN APP DEPOTS / PACKAGES
addappid(865361, 1, "f6f1cfca0ee6f4e76f671929c6576420ed7369c4fcb3ec01f64033d53ed022c0")
addappid(865362, 1, "8608a92f9bded30a00ec7a47f42a9dc8963204bfbf180cf55c71d40edcf1a98d")
addappid(1163640, 0, "9232e6f62743ca075a5d1e83210394f226e3b2c31e942c7b6385ffa5f317f6af")
