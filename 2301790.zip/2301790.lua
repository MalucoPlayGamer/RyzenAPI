-- Lua provided by RyzenAPI
-- Game: 三国：寻将传

-- MAIN APPLICATION
addappid(2301790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301791, 1, "c88b2e90c03e76a2932877a4075b6e96f2ccb7a4d5fc4b03794d7cd3292c98c9")

