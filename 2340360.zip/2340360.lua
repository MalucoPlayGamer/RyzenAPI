-- Lua provided by RyzenAPI
-- Game: T.D.Z. 3 Dark Way of Stalker

-- MAIN APPLICATION
addappid(2340360)
-- Game: addappid(2340360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340361, 1, "d3c6237972db8a4e6e62885463906019bcc183ef5225cc8f48b7409c7643673b")
