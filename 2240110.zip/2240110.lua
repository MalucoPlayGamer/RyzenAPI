-- Lua provided by RyzenAPI
-- Game: 2240110

-- MAIN APPLICATION
addappid(2240110)
-- Game: addappid(2240110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240111, 1, "172d8d7fb867c14dfe3251829c334dd13bd3fa452eca4f34a3c583ed9928efea")
