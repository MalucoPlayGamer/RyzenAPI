-- Lua provided by RyzenAPI
-- Game: 1882190

-- MAIN APPLICATION
addappid(1882190)
-- Game: addappid(1882190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882192,0,"2b6a889035b9f2f29574443c2c4a322e724ae8d253993addd3bacb97601ef2c4")
