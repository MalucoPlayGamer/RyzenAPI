-- Lua provided by RyzenAPI
-- Game: Idol Hands 2 Artbook

-- MAIN APPLICATION
addappid(2302900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302901, 1, "a5229c66c5e43e9525bc1039d88bd7f824484de54a8bc66498965192e3e55ea6")
