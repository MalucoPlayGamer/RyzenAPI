-- Lua provided by RyzenAPI
-- Game: Game: Warhammer 40,000: Battlesector - Soundtrack

-- MAIN APPLICATION
addappid(1726490)
-- Game: addappid(1726490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726491, 1, "7da5ea98b924079c80c817b4ea9e05d8b329a7ec5f8e5a3a65b4c02ef1315ac3")
addappid(1726492, 1, "83ae1b7db2fed04c59d73c764d7e554c8d98b6dd3adc66ba2c0391ab7d35bcaf")
