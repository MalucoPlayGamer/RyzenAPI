-- Lua provided by RyzenAPI
-- Game: Seed Hunter 猎源

-- MAIN APPLICATION
addappid(1078490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078491, 1, "5d14a90387cf7e9011474e45239f81fe092d0e9df061a9f8a0f3d94ff7446bb6")
