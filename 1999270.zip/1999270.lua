-- Lua provided by SkyAPI 
-- Game: V Rising Soundtrack
addappid(1999270)
addappid(1999271, 1, "018b653b9b20cb999529b75c5893c842325de70b50a9d294e1425f2461089604")
addappid(1999272, 1, "bc8a0725a46c16535d2b0ea0ca3671bc100e16c5feb496ba92fa7bbfacc89061")
