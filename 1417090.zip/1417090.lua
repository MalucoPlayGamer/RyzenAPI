-- Lua provided by RyzenAPI
-- Game: NEON STRUCT: Carrion Carrier

-- MAIN APPLICATION
addappid(1417090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417091, 1, "c36846fb3250fa9d818a36f403a0937feb40f5c8bcc5adf4da8982e62bbf676c")
addappid(1417092, 1, "83d77169d6575efef9ea89eaded93a1eb9aefdf18835c5a5b8e1cba2bc738529")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
