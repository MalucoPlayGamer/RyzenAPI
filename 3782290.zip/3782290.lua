-- Lua provided by RyzenAPI 
-- Game: SoundCat
addappid(3782290)
addappid(3782291, 1, "e6ecd37d0ef54bbb1982595cf064f8a08aa8df539292462632b61622ac032a70")
