-- Lua provided by RyzenAPI
-- Game: Hold Your Own

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(717790)

-- MAIN APP DEPOTS / PACKAGES
addappid(717792,0,"92a73e63ddc5387ac3df713f7ec034b8c4a8005d7e520a71e47d079eb719f231")
