-- Lua provided by RyzenAPI
-- Game: Farm Frenzy: Heave Ho

-- MAIN APPLICATION
addappid(395930)

-- MAIN APP DEPOTS / PACKAGES
addappid(395931, 1, "9682d812c1537a61251fc7c38b42cfbdba28a50e579a32f49d7526ee89d6e8c1")
addappid(395932, 1, "9ea547eeeda5b7d0e94cd6fb169da2467e7268095d859b333b2d94c1e849d043")
addappid(395933, 1, "421e10105b29e3b57e6d30efc471d42432c4699a72aa65540acaa750eb153f0d")
addappid(395934, 1, "c0dea9ccece795a456e1c3be12a50d10a3d92f294cb8209f5c982225ae35e86c")
