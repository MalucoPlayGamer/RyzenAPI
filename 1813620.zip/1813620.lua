-- Lua provided by RyzenAPI
-- Game: Game: 大富翁少女 Soundtrack

-- MAIN APPLICATION
addappid(1813620)
-- Game: addappid(1813620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813621, 1, "3e2654b46ce3f023ff90d2919551d51ea30f3681a6f481ec459a5b7ff282e7f0")
addappid(1813622, 1, "12b14a2704c7f9627814be9a96e90f1d984ed22193c291ba2aa9ead3d7203720")
