-- Lua provided by RyzenAPI
-- Game: Claris the Princess Knight

-- MAIN APPLICATION
addappid(1948920)
-- Game: addappid(1948920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948921, 1, "c4f7cf48714b0b25f682fd38d3fea417064ce649d57ed32f72726ac2570494d5")
addappid(1948923, 1, "3f5e805cd76e9eacef8d848c26b4ccc9c4f699e0b2995100afe0526539e33249")
