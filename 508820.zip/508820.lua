-- Lua provided by RyzenAPI
-- Game: Won't You Be My Laser?

-- MAIN APPLICATION
addappid(508820)

-- MAIN APP DEPOTS / PACKAGES
addappid(508821, 1, "c4296d6c6bf3ff1ef4ba89c32b57525bd77b39d3811e91d62a6562fec2666d39")

