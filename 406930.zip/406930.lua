-- Lua provided by RyzenAPI
-- Game: Epic Showdown

-- MAIN APPLICATION
addappid(406930)
addappid(406931)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985,0,"21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229030,0,"92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e")
