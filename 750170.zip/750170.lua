-- Lua provided by RyzenAPI
-- Game: Diesel Railcar Simulator

-- MAIN APPLICATION
addappid(750170)
-- Game: addappid(750170)

-- MAIN APP DEPOTS / PACKAGES
addappid(750171, 1, "6176352d1907a4b6c0b9a66407895122057e96c0cfb57414c8e16146ea07445e")
