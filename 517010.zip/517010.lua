-- Lua provided by RyzenAPI
-- Game: Game: Aztecalypse

-- MAIN APPLICATION
addappid(517010)
-- Game: addappid(517010)

-- MAIN APP DEPOTS / PACKAGES
addappid(517011, 1, "77fdc6f11d0e3d8681b258e915882bc6e83c1793020b6a4739f63a0b97b26e14")
