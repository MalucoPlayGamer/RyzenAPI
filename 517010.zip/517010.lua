-- Lua provided by RyzenAPI
-- Game: Aztecalypse

-- MAIN APPLICATION
addappid(517010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(517011, 1, "77fdc6f11d0e3d8681b258e915882bc6e83c1793020b6a4739f63a0b97b26e14")

