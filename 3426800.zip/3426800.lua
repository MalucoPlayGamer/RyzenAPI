-- Lua provided by RyzenAPI 
-- Game: Delverium Demo
addappid(3426800)
addappid(3426801, 1, "acb83b1a82cc71fd53b7e76fd2696d64e06a4b28eb7573ef008e6692deda58ba")
