-- Lua provided by RyzenAPI
-- Game: AppID 3340480

-- MAIN APPLICATION
addappid(3340480)
-- Game: addappid(3340480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340481, 1, "4248ad4d4357506ffc7c6d4cb707c2334ad26ddfb0e5702bf01cd7b003363231")
