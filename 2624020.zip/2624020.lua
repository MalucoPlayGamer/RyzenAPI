-- Lua provided by RyzenAPI 
-- Game: Parasomnum
addappid(2624020)
addappid(2624021, 1, "c1738af3572d6ea3896dfc522f4ea19e44e51757010039d4f626613fcc22763a")
