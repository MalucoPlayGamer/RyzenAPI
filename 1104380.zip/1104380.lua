-- Lua provided by RyzenAPI 
-- Game: AppID 1104380
addappid(1104380)
addappid(1104381, 1, "ec0b23905a483c5df91db3b99417a513dd2ae939a1c7a90af184007141c829ed")
