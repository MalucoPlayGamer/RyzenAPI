-- Lua provided by RyzenAPI 
-- Game: Mutant Meltdown
addappid(2085790)
addappid(2085791, 1, "d1383fe688022c1150042746d280a9f30d8d4ae3183ce36526dd4fa632f71e24")
