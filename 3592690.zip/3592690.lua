-- Lua provided by RyzenAPI
-- Game: Michelangelo: Stonemason Simulator - Original Soundtrack

-- MAIN APPLICATION
addappid(3592690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3592691, 1, "683522430fb2d0e2ec771ec9a034deed4a2dc856ed5aec7b1ff10056b71c68f4")

