-- Lua provided by RyzenAPI
-- Game: Girls in Glasses

-- MAIN APPLICATION
addappid(942990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(942991, 1, "d44720bb7f109a6a28918967873eeb1a75986c231e2e4c2bb690ca40663062ab")

