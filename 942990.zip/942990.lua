-- Lua provided by SkyAPI 
-- Game: Girls in Glasses
addappid(942990)
addappid(942991, 1, "d44720bb7f109a6a28918967873eeb1a75986c231e2e4c2bb690ca40663062ab")
