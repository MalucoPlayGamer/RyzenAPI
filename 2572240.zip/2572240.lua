-- Lua provided by RyzenAPI 
-- Game: AppID 2572240
addappid(2572240)
addappid(2572241, 1, "410e777058f1373bfeab54a781470461309d83fee5bc48395688940fdd21e588")
