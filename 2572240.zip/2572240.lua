-- Lua provided by RyzenAPI
-- Game: Time Handlers Demo

-- MAIN APPLICATION
addappid(2572240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572241, 1, "410e777058f1373bfeab54a781470461309d83fee5bc48395688940fdd21e588")
