-- Lua provided by RyzenAPI
-- Game: Megacraft Hentai And Zombies

-- MAIN APPLICATION
addappid(1773830)
-- Game: addappid(1773830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773831, 1, "1268e64f2e1d93f03b0bcfcea177cfd622bbae8c1efe24498dc9aa260448c6eb")
