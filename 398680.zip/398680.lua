-- Lua provided by RyzenAPI
-- Game: Ace Of Words

-- MAIN APPLICATION
addappid(398680)
-- Game: addappid(398680)

-- MAIN APP DEPOTS / PACKAGES
addappid(398681, 1, "b0586add8578fc24484b982b9c08fd0c30396caec0a6fa19967ec3b6f47b95b8")
