-- Lua provided by RyzenAPI
-- Game: Shooting Range Simulator

-- MAIN APPLICATION
addappid(2967850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967851,0,"bcd016eb613993225fb990529a187d558be463312580de47e56a7095a48e3c91")

