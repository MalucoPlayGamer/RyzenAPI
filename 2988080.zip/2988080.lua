-- Lua provided by RyzenAPI
-- Game: Game: siMarket Supermarket Simulator

-- MAIN APPLICATION
addappid(2988080)
addappid(3223110)
-- Game: addappid(2988080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988081, 1, "c1a5fea74939f67d338ed017ab56213949c6b9a5b3f3788a96e25bef126fa4fb")
