-- Lua provided by RyzenAPI
-- Game: Game: Shogun Showdown Soundtrack

-- MAIN APPLICATION
addappid(3132940)
-- Game: addappid(3132940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132941, 1, "63cfcce2f995561b72d2819b1fbb63f823360e0404b350cc6730c9b7e6806bbf")
