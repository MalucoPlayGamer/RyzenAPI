-- Lua provided by RyzenAPI
-- Game: Maneuver Warfare

-- MAIN APPLICATION
addappid(1285180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285181, 1, "35f59e403d5f9997934b1f2d260e1ac2fbf8e79ef1c57a6512405f5fb7b57346")

