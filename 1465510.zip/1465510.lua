-- Lua provided by RyzenAPI
-- Game: addappid(1465510)

-- MAIN APPLICATION
addappid(1465510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465511, 1, "d631588b8356561f97733f853ac2b58f54d0c9cc151c80e691e16b2b6f7b17be")
