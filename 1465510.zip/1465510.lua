-- Lua provided by RyzenAPI 
-- Game: DUSK '82: ULTIMATE EDITION
addappid(1465510)
addappid(1465511, 1, "d631588b8356561f97733f853ac2b58f54d0c9cc151c80e691e16b2b6f7b17be")
