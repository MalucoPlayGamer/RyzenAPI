-- Lua provided by RyzenAPI
-- Game: Game: AppID 817570

-- MAIN APPLICATION
addappid(817570)
-- Game: addappid(817570)

-- MAIN APP DEPOTS / PACKAGES
addappid(817571, 1, "b12e9a2f1f0617b52fcdecdf4b276d037463fd3151e960ba2b1fc6a1a91df340")
