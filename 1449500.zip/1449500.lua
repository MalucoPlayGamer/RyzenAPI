-- Lua provided by RyzenAPI
-- Game: Bassmaster® Fishing

-- MAIN APPLICATION
addappid(1449500)
addappid(1796153)
addappid(1796156)
addappid(1796157)
addappid(2017291)
addappid(2017292)
addappid(2017293)
addappid(2017294)
addappid(2017295)
addappid(2017296)
addappid(2017297)
addappid(2017298)
addappid(2017299)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449501, 1, "fdfe8b7a37191f33a55bbfa20f83198eb16c771be74c39f8241e65b40e7b7d6f")
addappid(1671650, 0, "1c1961fe9784d42dc295afbc519ef285e81119fc6cad18a0cfb982d5a50346c9")
addappid(1762990, 0, "a5708e83284f1b812070c4b9f44df1d00542dc81ed50e4bd3bb6bb649c6f2c4d")
addappid(1796150, 0, "4afdb88f64a32d75ebacad4b7f4aa7b85038a2a88e896336184b989ee0b76106")
addappid(1796151, 0, "e2765d0266e4f6f2b98650268cb3fd8e187ef5ba8d9ea27820c73f389f821421")
addappid(1796152, 0, "55ca9cfa24da1685b23baf009e1853396b290297d16de8ffe73c08f3ea8e3304")
addappid(1796154, 0, "1f2d09c50dc0b04ddde176a82d47d962c1413f53a723b7987a28eabbce49cf13")
addappid(1796155, 0, "9de66c6f00062330ce64c81069462cf13ee3100a2344efe4cb88bc032997f7b6")
addappid(1796158, 0, "8d6ec87efe07a26fa366230caedf42c2d9124ebc2673b15069a128a794d075ad")
addappid(1796159, 0, "99ae666f28277754385a9190d602ef6b31a806ed8581b7acd7e358d32d6e943f")
addappid(2017290, 0, "53222112eb331ca18e508abcc6721c029a0b5af9e960fcbaba734ff8a2c07278")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
