-- Lua provided by RyzenAPI
-- Game: AppID 1720950

-- MAIN APPLICATION
addappid(1720950)
-- Game: addappid(1720950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720951, 1, "87ba3df47c38cca0b3b9348285c576fda934954631aee86926ac236a16803cf1")
