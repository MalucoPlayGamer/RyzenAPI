-- Lua provided by RyzenAPI
-- Game: Bloodecay

-- MAIN APPLICATION
addappid(2503890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503891, 1, "10425294ea2ff95648e361782f6edf9ad99f80fb1edea2fdff2b8985934feb6f")
