-- Lua provided by RyzenAPI
-- Game: Top Hat

-- MAIN APPLICATION
addappid(315940)

-- MAIN APP DEPOTS / PACKAGES
addappid(315941, 1, "f2752981e6a185a24a25f00308a28bf2a139fec08e6b9d5e53f9dabb3afa66e7")
