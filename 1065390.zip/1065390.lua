-- Lua provided by RyzenAPI
-- Game: Virtual Hero VR

-- MAIN APPLICATION
addappid(1065390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065391, 1, "c09a09f245fdc4993b93b20c1a395fcba185887551d55df78b13afa1de1bf38a")
addappid(1065392, 1, "67d85d35f4f452e68436c839b3858910ce8b7d70ddaba9f15dbb3412babf3e7e")
addappid(1065393, 1, "5b465104139ca45b616fa3706562be5a90e4013ba1aaeaf088ded3c09c6c4f62")
