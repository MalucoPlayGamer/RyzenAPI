-- Lua provided by RyzenAPI 
-- Game: AppID 526250
addappid(526250)
addappid(526251, 1, "ba8e2afb520062d651b16b18234e6eaa0ae52785dc0d57df4d5d2e8fc07aee4e")
