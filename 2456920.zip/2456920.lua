-- Lua provided by SkyAPI 
-- Game: AppID 2456920
addappid(2456920)
addappid(2456921, 1, "c8b4aea8c93f4268c4cdfd898d9ed486a7096b24debedf8b3d86b6d2999bf558")
