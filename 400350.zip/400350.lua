-- Lua provided by SkyAPI 
-- Game: Battle Fleet: Ground Assault
addappid(400350)
addappid(400351, 1, "8e4cec33d2e1d749c234c6bc8a1424a0fc7493f6d0bcc12a2189dc2f1b12dcd0")
addappid(400352, 1, "6992d22badc1f36d1df21d5b8ad3fe7aa3dde978e924943011e5877df129d0d5")
