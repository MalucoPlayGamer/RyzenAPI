-- Lua provided by RyzenAPI
-- Game: Game: Songbird Symphony Demo

-- MAIN APPLICATION
addappid(1102300)
-- Game: addappid(1102300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102301, 1, "516276634721e944e65204555b394927e317e315fded6a791908db4628bab185")
