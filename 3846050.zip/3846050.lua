-- Lua provided by RyzenAPI
-- Game: 3846050

-- MAIN APPLICATION
addappid(3846050)
-- Game: addappid(3846050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3846051, 1, "ccb82ee83251c1a1c5d72e7551d3f9e54080ff191d9c5a9e6f82b373ddcb10f0")
