-- Lua provided by RyzenAPI
-- Game: addappid(2142250)

-- MAIN APPLICATION
addappid(2142250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142251, 1, "57d356003801c9287900eb3e1498258c959a1c8aaa56be1d44acc1ce5c46f719")
