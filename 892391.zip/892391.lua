-- Lua provided by RyzenAPI
-- Game: Sun Shangxiang (Dudou Costume)/孫尚香「肚兜風コスチューム」

-- MAIN APPLICATION
addappid(892391)

-- MAIN APP DEPOTS / PACKAGES
addappid(892391,0,"915b8fbf5be6565291b202ce4c1a979acd3d647210687ca5799b1d65297366bd")

