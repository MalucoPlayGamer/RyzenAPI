-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(219152)
-- Game: addappid(219152)

-- MAIN APP DEPOTS / PACKAGES
addappid(219152,0,"d1116e26a0aeb3d3a498382d419102e5a8386dcfa923e8844a6e1e2aa0d671f4")
