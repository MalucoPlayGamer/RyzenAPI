-- Lua provided by RyzenAPI
-- Game: Game: AppID 92100

-- MAIN APPLICATION
addappid(92100)
addappid(228982)
addappid(229000)
addappid(229011)
-- Game: addappid(92100)

-- MAIN APP DEPOTS / PACKAGES
addappid(92101, 1, "f9fae6ccc70d991127b49bed5180850a37a005936b2c7ea7ec800a9c6cad1740")
