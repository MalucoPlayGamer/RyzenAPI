-- Lua provided by RyzenAPI
-- Game: MADiSON

-- MAIN APPLICATION
addappid(1670870)
addappid(1949860)
-- Game: addappid(1670870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670871, 1, "fec5adab12265656f336fd9e3ca6b0545515f01cc1697d95b6d315f5771adf35")
