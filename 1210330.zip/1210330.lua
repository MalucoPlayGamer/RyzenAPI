-- Lua provided by RyzenAPI
-- Game: Game: AppID 1210330

-- MAIN APPLICATION
addappid(1210330)
-- Game: addappid(1210330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210331, 1, "54326835332c7e2b1a37f09485728ae0a7352710b6f48fd16adf32c86177bca7")
