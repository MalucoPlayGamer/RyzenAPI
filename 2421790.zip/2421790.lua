-- Lua provided by RyzenAPI
-- Game: Game: AppID 2421790

-- MAIN APPLICATION
addappid(2421790)
-- Game: addappid(2421790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421791, 1, "4c6bff8719ce0bb891565644802e897e5f2b6cc77bfaa885d080ad63c869c536")
