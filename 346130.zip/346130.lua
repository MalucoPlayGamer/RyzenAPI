-- Lua provided by RyzenAPI
-- Game: addappid(346130)

-- MAIN APPLICATION
addappid(346130)

-- MAIN APP DEPOTS / PACKAGES
addappid(346131, 1, "63f3cd43bae76c9117db9bd206e44b2d158ab48d3708323d50063fda25bc50b6")
