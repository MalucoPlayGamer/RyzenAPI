-- Lua provided by RyzenAPI
-- Game: Dead Matter

-- MAIN APPLICATION
addappid(2184150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184151, 1, "7fcf86a407ed2bf3dc7d0191e036bd4d5da63afbdf4eb27eef04177d249b932c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
