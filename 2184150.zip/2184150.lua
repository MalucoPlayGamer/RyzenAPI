-- Lua provided by RyzenAPI
-- Game: Dead Matter

-- MAIN APPLICATION
addappid(2184150)
-- Game: addappid(2184150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184151, 1, "7fcf86a407ed2bf3dc7d0191e036bd4d5da63afbdf4eb27eef04177d249b932c")
