-- Lua provided by RyzenAPI 
-- Game: Lab Inspect
addappid(2206720)
addappid(2206721, 1, "1bf0624c70975b71be4c0f6b4e82e9ada7e15e615732f97f15be5e0ace91fabb")
