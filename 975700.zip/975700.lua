-- Lua provided by RyzenAPI
-- Game: KóterGame

-- MAIN APPLICATION
addappid(975700)
-- Game: addappid(975700)

-- MAIN APP DEPOTS / PACKAGES
addappid(975701, 1, "b8e6a07d20f682cb1a1128d5bbab2bb03b52e2da1d978f940194603e1767b1c0")
