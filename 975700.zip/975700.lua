-- Lua provided by RyzenAPI
-- Game: KóterGame

-- MAIN APPLICATION
addappid(975700)

-- MAIN APP DEPOTS / PACKAGES
addappid(975701, 1, "b8e6a07d20f682cb1a1128d5bbab2bb03b52e2da1d978f940194603e1767b1c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1000940)
addappid(1000970)
