-- Lua provided by RyzenAPI
-- Game: Sears: The Sky Frontier

-- MAIN APPLICATION
addappid(2098840)
-- Game: addappid(2098840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098841, 1, "a489a299230e96e864a2e93eea0ac75e78bc3a0ecf6260f5a31dd8dbfdfcdf01")
