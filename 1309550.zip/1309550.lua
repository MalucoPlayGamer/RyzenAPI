-- Lua provided by RyzenAPI
-- Game: Far Eastern Federal University Virtual Expo

-- MAIN APPLICATION
addappid(1309550)
-- Game: addappid(1309550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309551, 1, "f72ba2ede37dfef48fe61eb42bb6f86a9d43ac46b5bec6544cffef62b19a2c94")
