-- Lua provided by RyzenAPI
-- Game: Game: The Stanley Parable

-- MAIN APPLICATION
addappid(221910)
-- Game: addappid(221910)

-- MAIN APP DEPOTS / PACKAGES
addappid(221911, 1, "63a52ac3857a0c6a6a85bfe4af6d84395e79ddf0cc5e38eb1bf45b6932e30999")
addappid(221912, 1, "239566732a9a1d0e47deba270c2d39cdf30f5e1916164c046f4069f9751353e8")
addappid(221913, 1, "e1551dfc6816c3dab69e361f7d3d8a3a5a7364c11c17932e91e41b129d012f9f")
addappid(221914, 1, "c5c453c2733e1fd0ba816e8772d28d2078d6ec93f2315063d2f1926eb9b1a903")
