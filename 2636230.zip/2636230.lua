-- Lua provided by RyzenAPI
-- Game: AppID 2636230

-- MAIN APPLICATION
addappid(2636230)
-- Game: addappid(2636230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636231, 1, "a46bd998a77962635109e8d6a7dd193292c76ca14afb7ba17857c152e6d9df30")
