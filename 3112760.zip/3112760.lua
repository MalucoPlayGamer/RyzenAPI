-- Lua provided by RyzenAPI
-- Game: It's Only Money Demo

-- MAIN APPLICATION
addappid(3112760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112761, 1, "fd74b1206d92d0fd8ffe1212b1e6e4df4c778026960143686f2f6788c000c421")

