-- Lua provided by RyzenAPI
-- Game: AppID 1141530

-- MAIN APPLICATION
addappid(1141530)
addappid(1328420)
addappid(1328421)
addappid(1379300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1141531, 1, "6070b38d0a901b8d0beed5c96d52e2e56bae2860e70c0009845aadae4f821a02")

