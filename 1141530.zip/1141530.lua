-- Lua provided by RyzenAPI 
-- Game: AppID 1141530
addappid(1141530)
addappid(1141531, 1, "6070b38d0a901b8d0beed5c96d52e2e56bae2860e70c0009845aadae4f821a02")
