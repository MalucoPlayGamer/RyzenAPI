-- Lua provided by RyzenAPI
-- Game: Mini Crafty

-- MAIN APPLICATION
addappid(1585680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585681, 1, "675776b23e41bbc832a6f6c3317c9af12aa0450a5da782c5ab2f2777eb6f6fad")
