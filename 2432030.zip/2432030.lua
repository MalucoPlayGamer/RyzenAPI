-- Lua provided by RyzenAPI
-- Game: Game: City Legends: The Ghost of Misty Hill Collector's Edition

-- MAIN APPLICATION
addappid(2432030)
addappid(2433660)
-- Game: addappid(2432030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432031, 1, "44a0fbf5b51f0290159b18fdacba994b2860e01fde83fd94c0e629b26ce0eae3")
