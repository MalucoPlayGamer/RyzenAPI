-- Lua provided by SkyAPI 
-- Game: ChainMan
addappid(646300)
addappid(646301, 1, "65d4a9cc2019f4b8e9c0a1e75aad1ba2fbdfb0534f2b43ee1c906dbf557189cb")
