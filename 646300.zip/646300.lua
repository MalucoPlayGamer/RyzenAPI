-- Lua provided by RyzenAPI
-- Game: ChainMan

-- MAIN APPLICATION
addappid(646300)
-- Game: addappid(646300)

-- MAIN APP DEPOTS / PACKAGES
addappid(646301, 1, "65d4a9cc2019f4b8e9c0a1e75aad1ba2fbdfb0534f2b43ee1c906dbf557189cb")
