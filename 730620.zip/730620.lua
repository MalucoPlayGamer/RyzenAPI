-- Lua provided by RyzenAPI
-- Game: addappid(730620)

-- MAIN APPLICATION
addappid(730620)

-- MAIN APP DEPOTS / PACKAGES
addappid(730621, 1, "f8eea09b10bc83c5691a4ad8078dddc10a3c5f8bbf09cc0ecb2e20b4e0fcd242")
