-- Lua provided by RyzenAPI
-- Game: AppID 762220

-- MAIN APPLICATION
addappid(762220)

-- MAIN APP DEPOTS / PACKAGES
addappid(762221, 1, "4f0dd9170c39263691de7d0c3343781ec7694e134614a953bc77fe7f7795b712")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
