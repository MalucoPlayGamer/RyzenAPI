-- Lua provided by RyzenAPI
-- Game: AppID 3341040

-- MAIN APPLICATION
addappid(3341040)
-- Game: addappid(3341040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341041, 1, "f23a99e7b5967d4b693b2032a43bde96b498b5d0010e6bf47c1d1d7d90d92f76")
