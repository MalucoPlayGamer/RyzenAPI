-- Lua provided by RyzenAPI
-- Game: Wantless Demo

-- MAIN APPLICATION
addappid(2262090)
-- Game: addappid(2262090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262091, 1, "d22f53087845240b63214ae2e9a8f6e87fd63fdf4567569e66d45761e16bc0c5")
