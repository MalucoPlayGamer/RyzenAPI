-- Lua provided by RyzenAPI 
-- Game: Wantless Demo
addappid(2262090)
addappid(2262091, 1, "d22f53087845240b63214ae2e9a8f6e87fd63fdf4567569e66d45761e16bc0c5")
