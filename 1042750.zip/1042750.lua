-- Lua provided by RyzenAPI
-- Game: Night shot

-- MAIN APPLICATION
addappid(1042750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042751, 1, "c0d171fc6064e66d544ecd14c31065ff93d6cf3227a2b215da16612b6affc52e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
