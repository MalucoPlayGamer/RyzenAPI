-- Lua provided by RyzenAPI
-- Game: REC: Beyond The Lens

-- MAIN APPLICATION
addappid(2466400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466401, 1, "ab0c10055a7291407b8baa2bc3a98a9a7972bec613a2b35b6cd5587c204cf707")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
