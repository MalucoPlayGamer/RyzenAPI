-- Lua provided by RyzenAPI
-- Game: addappid(2466400)

-- MAIN APPLICATION
addappid(2466400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466401, 1, "ab0c10055a7291407b8baa2bc3a98a9a7972bec613a2b35b6cd5587c204cf707")
