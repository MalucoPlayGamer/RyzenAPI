-- Lua provided by RyzenAPI
-- Game: Dream Detective

-- MAIN APPLICATION
addappid(1158910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158916,0,"a22d59f1e8918031ca6fa558a007fa10306834e2d17f660ddec82b7c55278c04")
