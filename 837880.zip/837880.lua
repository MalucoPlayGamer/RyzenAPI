-- Lua provided by RyzenAPI
-- Game: addappid(837880)

-- MAIN APPLICATION
addappid(837880)

-- MAIN APP DEPOTS / PACKAGES
addappid(837881, 1, "8dd2c726ea77563c689a85c6be1d03c5932dbffd7645ed006083785a49d93992")
