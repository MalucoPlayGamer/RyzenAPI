-- Lua provided by RyzenAPI
-- Game: You Suck at Parking® - Complete Edition

-- MAIN APPLICATION
addappid(837880)
addappid(1983920)
addappid(2220780)

-- MAIN APP DEPOTS / PACKAGES
addappid(837881,0,"8dd2c726ea77563c689a85c6be1d03c5932dbffd7645ed006083785a49d93992")

