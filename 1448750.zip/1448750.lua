-- Lua provided by RyzenAPI
-- Game: Hentai Beach

-- MAIN APPLICATION
addappid(1448750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448751, 1, "2c402d9b73612210d764100b43ee6e2d1c69070f123b80f3e7c46634fddd537c")

