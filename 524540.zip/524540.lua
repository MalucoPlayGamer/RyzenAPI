-- Lua provided by RyzenAPI
-- Game: Game: AppID 524540

-- MAIN APPLICATION
addappid(524540)
-- Game: addappid(524540)

-- MAIN APP DEPOTS / PACKAGES
addappid(524541, 1, "1a7803bccb6438376724ebe27b71b82db285c989d45dcf07d5d3e507ca0e5fcf")
