-- Lua provided by RyzenAPI
-- Game: addappid(622040)

-- MAIN APPLICATION
addappid(622040)

-- MAIN APP DEPOTS / PACKAGES
addappid(622041, 1, "a3fa293e429fe1f903b90a1141d5b3883a53fc3e1adb78d791550314c4570ef7")
