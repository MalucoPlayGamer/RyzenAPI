-- Lua provided by RyzenAPI
-- Game: 1689640

-- MAIN APPLICATION
addappid(1689640)
-- Game: addappid(1689640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689641, 1, "8a79dc2b8691feaf41ee3bc05550f2e5f2cccc5a30fc1eb18569e9fe3a37795b")
