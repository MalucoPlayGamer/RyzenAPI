-- Lua provided by RyzenAPI
-- Game: Warden's Will

-- MAIN APPLICATION
addappid(1689640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689641, 1, "8a79dc2b8691feaf41ee3bc05550f2e5f2cccc5a30fc1eb18569e9fe3a37795b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
