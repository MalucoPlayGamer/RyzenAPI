-- Lua provided by RyzenAPI 
-- Game: AppID 857840
addappid(857840)
addappid(857841, 1, "d5af2f4cc1719f8d445f3c879b0a51ef81ea46cb94ebc3eeb3228d6271e75d11")
