-- Lua provided by SkyAPI 
-- Game: Pro Strategy Football 2024
addappid(2459100)
addappid(2459101, 1, "05046e83c6e11aa4513c1d9f31ea3523cc1c67d119b52b3842de8535d28f3667")
addappid(2459102, 1, "832ed1ae277cafc8af532f2747806a729899cb02431080d4d767719e60c816cb")
