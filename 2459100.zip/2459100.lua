-- Lua provided by RyzenAPI
-- Game: Pro Strategy Football 2024

-- MAIN APPLICATION
addappid(2459100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459101, 1, "05046e83c6e11aa4513c1d9f31ea3523cc1c67d119b52b3842de8535d28f3667")
addappid(2459102, 1, "832ed1ae277cafc8af532f2747806a729899cb02431080d4d767719e60c816cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
