-- Lua provided by RyzenAPI
-- Game: Game: Bendy and the Dark Revival

-- MAIN APPLICATION
addappid(1063660)
-- Game: addappid(1063660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063661, 1, "8a02dd866fcac446855a005dfc59832198ac2fb120e81c22295e9cbdd47443f5")
