-- Lua provided by RyzenAPI
-- Game: Below Nowhere

-- MAIN APPLICATION
addappid(2569280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569281, 1, "3b8093a94de728a770bdd72d86e994b91bbd18a9abeb9a3e0f45b49fa574ff27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
