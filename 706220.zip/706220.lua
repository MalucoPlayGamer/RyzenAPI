-- Lua provided by RyzenAPI
-- Game: Black Desert SA

-- MAIN APPLICATION
addappid(706220)
addappid(2052350)
addappid(2052351)
addappid(2052352)

-- MAIN APP DEPOTS / PACKAGES
addappid(706221, 1, "57030c73f80090c0ed14d924a4b027479b6ffbf46f85caaf9fa58801cf6419c3")

