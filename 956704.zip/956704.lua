-- Lua provided by RyzenAPI
-- Game: 956704

-- MAIN APPLICATION
addappid(956704)
-- Game: addappid(956704)

-- MAIN APP DEPOTS / PACKAGES
addappid(956704,0,"1b1b5abe9f0e00edb2a6803eb22c6880c2017f8a37a94240c9cbaa03525e61ac")
