-- Lua provided by RyzenAPI
-- Game: Draft Day Sports: College Football 2018

-- MAIN APPLICATION
addappid(878710)

-- MAIN APP DEPOTS / PACKAGES
addappid(878711,0,"b6757b2e18496a61568014ff7d20f20fc42762906a3f3b8d5e1e7eb7e71cda5f")

