-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2624220)
-- Game: addappid(2624220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624220,0,"ec0a43231c1171f9a9d3f71dbfe1fa1feccbd92d031124b28a73ded87a9f62fe")
