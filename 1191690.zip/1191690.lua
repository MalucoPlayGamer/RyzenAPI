-- Lua provided by RyzenAPI
-- Game: Skull Head World

-- MAIN APPLICATION
addappid(1191690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191691, 1, "e09896cd7d5235648b1a503c0a062282b88e403bd28f5be6a004d30c720947f2")
