-- Lua provided by RyzenAPI 
-- Game: Once Upon a Jester
addappid(1668190)
addappid(1668191, 1, "24f1729c7e9013206efae8b4b71f5c6e16159ed7b8231d06c8371ccd568c6f95")
addappid(1668192, 1, "41235a9dac1e7d58c094f31643cfaecf60422bf657ffac9561783666c6398c29")
