-- Lua provided by RyzenAPI
-- Game: 卖萌恶霸喵霸霸 Cute Bully Nyanbaba

-- MAIN APPLICATION
addappid(1145130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145131, 1, "06575ff39f4241946971152143df66a65f3839c75e883a4970e15a30381c1ceb")

