-- Lua provided by SkyAPI 
-- Game: AppID 1145130
addappid(1145130)
addappid(1145131, 1, "06575ff39f4241946971152143df66a65f3839c75e883a4970e15a30381c1ceb")
