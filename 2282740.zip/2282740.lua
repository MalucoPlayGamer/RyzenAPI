-- Lua provided by RyzenAPI
-- Game: addappid(2282740)

-- MAIN APPLICATION
addappid(2282740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282741, 1, "7e5a702bf71e8e6ff5fab939622246400eaaea9118001ba43ff0a55a26804c06")
