-- Lua provided by RyzenAPI
-- Game: BATSUGUN Saturn Tribute Boosted

-- MAIN APPLICATION
addappid(2282740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2282741, 1, "7e5a702bf71e8e6ff5fab939622246400eaaea9118001ba43ff0a55a26804c06")

