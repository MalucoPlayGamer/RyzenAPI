-- Lua provided by RyzenAPI
-- Game: 1234520

-- MAIN APPLICATION
addappid(1234520)
-- Game: addappid(1234520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234521, 1, "6be8db30bc4781f004abf45b763bdeb7950d7d055e66e70b9edb315de85981ec")
