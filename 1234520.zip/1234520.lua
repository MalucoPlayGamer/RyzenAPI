-- Lua provided by SkyAPI 
-- Game: The Escaper
addappid(1234520)
addappid(1234521, 1, "6be8db30bc4781f004abf45b763bdeb7950d7d055e66e70b9edb315de85981ec")
