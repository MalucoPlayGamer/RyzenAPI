-- Lua provided by RyzenAPI
-- Game: 1362980

-- MAIN APPLICATION
addappid(1362980)
addappid(1363910)
-- Game: addappid(1362980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362981, 1, "bd52af0d15e7a1bc388520891639c6e0f8f8a03350776f8bc95d83912c48e264")
