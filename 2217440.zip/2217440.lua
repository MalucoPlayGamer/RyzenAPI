-- Lua provided by RyzenAPI
-- Game: AppID 2217440

-- MAIN APPLICATION
addappid(2217440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217441, 1, "80256ba5fab0f3b528934597a5c6f2ca1c7afa1ac1b5d2ac3ae1005a8bbd2191")

