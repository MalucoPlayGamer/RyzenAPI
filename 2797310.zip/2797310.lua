-- Lua provided by SkyAPI 
-- Game: Hypnotic Idol
addappid(2797310)
addappid(2797311, 1, "2fee0d3ceb47f07db76153736bebdd92eb1e44b9fe6d731c8f237d37a05ce7db")
addappid(3463980, 0, "6c4a4f062de4faf9001664abcc320ef5f26c0a00912ac6e667c96ed53d20ca8e")
