-- Lua provided by SkyAPI 
-- Game: Gravity Cab Demo
addappid(2783200)
addappid(2783201, 1, "610e2f374d6564f171761fa3925f86de6ff795f71e5a0914818bd993d7b56333")
