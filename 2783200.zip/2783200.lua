-- Lua provided by RyzenAPI
-- Game: Gravity Cab Demo

-- MAIN APPLICATION
addappid(2783200)
-- Game: addappid(2783200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783201, 1, "610e2f374d6564f171761fa3925f86de6ff795f71e5a0914818bd993d7b56333")
