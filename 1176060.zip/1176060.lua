-- Lua provided by SkyAPI 
-- Game: AppID 1176060
addappid(1176060)
addappid(1176061, 1, "0c9e5d4ca73d09b4b1ac4ab6436e8b27fa61f914ed30571da5f55b05d46d63bb")
