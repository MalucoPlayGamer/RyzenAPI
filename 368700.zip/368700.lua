-- Lua provided by RyzenAPI
-- Game: addappid(368700)

-- MAIN APPLICATION
addappid(368700)

-- MAIN APP DEPOTS / PACKAGES
addappid(368701, 1, "382d094297c75c496642014e9b936affd99409ed2a72dcd88120d2e6d614ec4f")
