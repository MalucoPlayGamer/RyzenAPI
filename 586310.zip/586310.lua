-- Lua provided by SkyAPI 
-- Game: Gunman Taco Truck
addappid(586310)
addappid(586311, 1, "926cb83a8a65017e3c2d7604d098dc9b044dc19902a4c78efbce31e85b89c656")
addappid(586312, 1, "2438ef29d53536d45174a4a3773996b748dff014ef9a9077dab17465aec0070b")
