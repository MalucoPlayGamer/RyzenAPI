-- Lua provided by RyzenAPI
-- Game: Gravity Ace

-- MAIN APPLICATION
addappid(1003860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003862,0,"98fcbeba8c8bb9894833239fa04179341a7e0b40bc8521ea5fb066b2a4fe22b4")

