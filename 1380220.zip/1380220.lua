-- Lua provided by RyzenAPI 
-- Game: Starsand
addappid(1380220)
addappid(1380221, 1, "8ccba39dc3c368c8c7e3cd7253c9b43d55b57b6c58f57d177ae780fe09206d6e")
addappid(1797310, 0, "685425eeebbf0c00a4683c4a85d0586fc98f7bbe0c6c331c751ac49497d14f8e")
