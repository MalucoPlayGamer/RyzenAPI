-- Lua provided by RyzenAPI
-- Game: addappid(1991740)

-- MAIN APPLICATION
addappid(1991740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991741, 1, "2df484fc3da41018ccc824fac1b53502818dfc83b4fd273809d0a4f95d9d789b")
