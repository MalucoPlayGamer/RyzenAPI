-- Lua provided by RyzenAPI
-- Game: 360 No Scope Arena

-- MAIN APPLICATION
addappid(883100)

-- MAIN APP DEPOTS / PACKAGES
addappid(883101, 1, "78cf247e217d1941fc0fed82c6279766d4bad331d31f9e5052b74ed467ce442e")
