-- Lua provided by RyzenAPI
-- Game: Under The Ground

-- MAIN APPLICATION
addappid(1110670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110671, 1, "5c1759a2fb6b240f83ebbac6923961c885b71759d4dccd2713b37d0d622b3e00")

