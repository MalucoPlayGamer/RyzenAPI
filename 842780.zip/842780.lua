-- Lua provided by RyzenAPI 
-- Game: AppID 842780
addappid(842780)
addappid(842781, 1, "f2f0faa6e2a25f845d967c412be052d442475706907cfa876648c6c4995bfc9a")
