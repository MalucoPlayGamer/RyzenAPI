-- Lua provided by RyzenAPI
-- Game: addappid(842780)

-- MAIN APPLICATION
addappid(842780)

-- MAIN APP DEPOTS / PACKAGES
addappid(842781, 1, "f2f0faa6e2a25f845d967c412be052d442475706907cfa876648c6c4995bfc9a")
