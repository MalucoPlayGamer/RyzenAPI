-- Lua provided by RyzenAPI
-- Game: Game: Torn

-- MAIN APPLICATION
addappid(557520)
addappid(922160)
-- Game: addappid(557520)

-- MAIN APP DEPOTS / PACKAGES
addappid(557521, 1, "f937047e91837655a2f92cde7b352641b06c57679f39d3213f9e619b8693e417")
