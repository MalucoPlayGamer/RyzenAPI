-- Lua provided by RyzenAPI
-- Game: Torn

-- MAIN APPLICATION
addappid(557520)
addappid(922160)

-- MAIN APP DEPOTS / PACKAGES
addappid(557521, 1, "f937047e91837655a2f92cde7b352641b06c57679f39d3213f9e619b8693e417")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
