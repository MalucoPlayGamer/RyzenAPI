-- Lua provided by RyzenAPI
-- Game: Game: AppID 3558430

-- MAIN APPLICATION
addappid(3558430)
-- Game: addappid(3558430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558431, 1, "f1890ef9597b8a2a3fd9c8cc24513e44a0e8009c0b9402612002f968a9621a16")
