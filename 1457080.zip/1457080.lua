-- Lua provided by RyzenAPI
-- Game: The Mageseeker: A League of Legends Story™

-- MAIN APPLICATION
addappid(1457080)
addappid(2252140)
addappid(2252141)
addappid(2252142)
addappid(2252143)
addappid(2252144)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1457081, 1, "b06bbdb3bdffaa20812685d4de796f06e28d3e52c17e886c09cb3108480a30b1")

