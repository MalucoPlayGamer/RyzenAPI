-- Lua provided by RyzenAPI
-- Game: The Mageseeker: A League of Legends Story™

-- MAIN APPLICATION
addappid(1457080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457081, 1, "b06bbdb3bdffaa20812685d4de796f06e28d3e52c17e886c09cb3108480a30b1")
