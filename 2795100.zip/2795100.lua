-- Lua provided by RyzenAPI
-- Game: Into The Depths Demo

-- MAIN APPLICATION
addappid(2795100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795101, 1, "a91fb749faa424427dc882d4f7bb8904fe6f7faf03e598ef8af81855ef59763b")
