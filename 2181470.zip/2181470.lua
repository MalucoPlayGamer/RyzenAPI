-- Lua provided by RyzenAPI
-- Game: Game: 幻想曹操传2 Demo

-- MAIN APPLICATION
addappid(2181470)
-- Game: addappid(2181470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181471, 1, "417f48faee5e9339eccf8db0a365a85d4732384832c21486744f45ade65d90e5")
