-- Lua provided by RyzenAPI
-- Game: addappid(3155560)

-- MAIN APPLICATION
addappid(3155560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155561, 1, "d219c05375237beada93b230be8980b34f97319bf031ff4d982a03ca65850ea6")
