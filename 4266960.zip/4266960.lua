-- 4266960's Lua and Manifest Created by Hubcap Manifest
-- AI Faith: Compute [>_AIFC]
-- Created: August 06, 2026 at 12:01:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4266960) -- AI Faith: Compute [>_AIFC]
-- MAIN APP DEPOTS
addappid(4266961, 1, "320228aecd8ac6917cbc252e6e286a981953944bfccc2b7475a875e3ad5f5f19") -- Depot 4266961
setManifestid(4266961, "6759309225886096722", 347195496)