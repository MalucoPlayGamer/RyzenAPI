-- Lua provided by RyzenAPI
-- Game: AI Faith: Compute [>_AIFC]

-- MAIN APPLICATION
addappid(4266960) -- AI Faith: Compute [>_AIFC]

-- MAIN APP DEPOTS / PACKAGES
addappid(4266961, 1, "320228aecd8ac6917cbc252e6e286a981953944bfccc2b7475a875e3ad5f5f19") -- Depot 4266961

