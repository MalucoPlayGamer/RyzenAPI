-- Lua provided by RyzenAPI
-- Game: 3568440

-- MAIN APPLICATION
addappid(3568440)
-- Game: addappid(3568440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568441, 1, "a37c1298c57d3f3fc0025a4d379e60953d4b2dfeec4dc86fcbc354aac69e25be")
