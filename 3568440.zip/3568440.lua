-- Lua provided by SkyAPI 
-- Game: AppID 3568440
addappid(3568440)
addappid(3568441, 1, "a37c1298c57d3f3fc0025a4d379e60953d4b2dfeec4dc86fcbc354aac69e25be")
