-- Lua provided by RyzenAPI
-- Game: AppID 485490

-- MAIN APPLICATION
addappid(485490)
-- Game: addappid(485490)

-- MAIN APP DEPOTS / PACKAGES
addappid(485491, 1, "d6d5339f9a4d6b4aa0615f51e79e6c5d45df16f7a2c1826e629078dd379b234c")
