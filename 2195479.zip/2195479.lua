-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Weeknd - "The Hills"

-- MAIN APPLICATION
addappid(2195479)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195479,0,"99faff849d8eb2b93f356f916d00ccfaae2142a2e2c285a029433c4ecf9e33f4")
