-- Lua provided by SkyAPI 
-- Game: Extra Lives
addappid(2310690)
addappid(2310691, 1, "71c9ffa699de7614285c781a00e0d9f2a51fd1789fb235b150875dbe542fd7f8")
