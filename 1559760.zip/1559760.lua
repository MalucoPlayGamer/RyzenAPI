-- Lua provided by RyzenAPI 
-- Game: AppID 1559760
addappid(1559760)
addappid(1559761, 1, "4b89cbe93c57aaac3fc5dc95cd52748c1e33086bd020196a16ab2fa5685c3b1a")
