-- Lua provided by RyzenAPI
-- Game: NGHTMN Soundtrecks

-- MAIN APPLICATION
addappid(701230)

-- MAIN APP DEPOTS / PACKAGES
addappid(701230,0,"69643d1d8b43de28591d59ea094fc5147d4b753b8fb21d5c223fc9a32fad256e")
addtoken(701230,14977409443268021482)

