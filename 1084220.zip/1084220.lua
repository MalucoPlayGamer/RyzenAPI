-- Lua provided by RyzenAPI
-- Game: Cavity Busters

-- MAIN APPLICATION
addappid(1084220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084221, 1, "7340f96ac043fcae777cf34e24caadcfafee665113c35449b877adef8b2264fe")

