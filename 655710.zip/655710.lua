-- Lua provided by RyzenAPI
-- Game: tick-hunter

-- MAIN APPLICATION
addappid(655710)

-- MAIN APP DEPOTS / PACKAGES
addappid(655711,0,"95e5b9836ae6356ced9ccc94787b94d363f25589ddffd098edd6a56f4e296545")

