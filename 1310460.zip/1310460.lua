-- Lua provided by RyzenAPI
-- Game: AppID 1310460

-- MAIN APPLICATION
addappid(1310460)
-- Game: addappid(1310460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310461, 1, "e35552fc5df9a2934bf6f3885c5c3b0c7b9169fcef9b289d939829515ad2c300")
addappid(1310462, 1, "d70ffc0230bc7b6ab8da1a2e9e16607a0043aefd33ce3df91de0e7b62747b162")
