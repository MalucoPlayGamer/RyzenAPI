-- Lua provided by RyzenAPI
-- Game: Game: Sexcraft - Sofiya and the Lewd Clan

-- MAIN APPLICATION
addappid(1468420)
-- Game: addappid(1468420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468421, 1, "bdec2e35940816de1bd97c8619a27a15349891a71719064348c1c28e9d4e1546")
addappid(1743292, 0, "74158bd2ee7e63a5273e4543fa22fc85d70738835536d74ea9184a80380cf6fb")
addappid(1743293, 0, "9ad516bd9893ea2367d9460f7324a21b506d2d95a0dd46c84478ab14794d1cc1")
