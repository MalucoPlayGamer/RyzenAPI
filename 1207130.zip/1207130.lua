-- Lua provided by RyzenAPI
-- Game: Many Faces

-- MAIN APPLICATION
addappid(1207130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207131, 1, "33a0a9c5aefbc6deb418ef9bfce49ca646508f07c70100948e65720611d1f331")
