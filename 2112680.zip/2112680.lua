-- Lua provided by SkyAPI 
-- Game: Darkness Revenge
addappid(2112680)
addappid(2112681, 1, "bcf472476a0d6d31e633762c440c8173498e6ccdc1d19960fc36f923b8bdb004")
