-- Lua provided by RyzenAPI
-- Game: Game: AppID 1274360

-- MAIN APPLICATION
addappid(1274360)
-- Game: addappid(1274360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274361, 1, "c032b95c9244b930b7db2b104a4a634454d96cb0794cf8921bb0995da9bdcfea")
