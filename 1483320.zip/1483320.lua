-- Lua provided by RyzenAPI
-- Game: Railroad Engineer

-- MAIN APPLICATION
addappid(1483320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483321, 1, "d2046f14eb05e5107a8c41c9a1b45ed06842b9bc5cc940191de62274f4924cc5")

