-- Lua provided by SkyAPI 
-- Game: Railroad Engineer
addappid(1483320)
addappid(1483321, 1, "d2046f14eb05e5107a8c41c9a1b45ed06842b9bc5cc940191de62274f4924cc5")
