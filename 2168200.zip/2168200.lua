-- Lua provided by RyzenAPI
-- Game: NervBox

-- MAIN APPLICATION
addappid(2168200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168202,0,"ae3ee43260181bf64fc642f55288dc960d332e872eea283b4b89e621b6fc6d84")
