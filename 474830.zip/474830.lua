-- Lua provided by SkyAPI 
-- Game: Time in Time
addappid(474830)
addappid(474831, 1, "febeac0f99d9a12523d46a79e6b12b4951cadd52c835578edfba9236f2a8c488")
