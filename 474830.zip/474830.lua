-- Lua provided by RyzenAPI
-- Game: addappid(474830)

-- MAIN APPLICATION
addappid(474830)

-- MAIN APP DEPOTS / PACKAGES
addappid(474831, 1, "febeac0f99d9a12523d46a79e6b12b4951cadd52c835578edfba9236f2a8c488")
