-- Lua provided by RyzenAPI
-- Game: Snack Stall

-- MAIN APPLICATION
addappid(1989950)
addappid(2107940)
addappid(2107941)
addappid(2107942)
addappid(2107943)
addappid(2107944)
addappid(2107960)
addappid(2107961)
addappid(2107962)
addappid(2107963)
addappid(2107964)
addappid(2107980)
addappid(2107981)
addappid(2107982)
addappid(2107983)
addappid(2107984)
addappid(2108000)
addappid(2108001)
addappid(2108002)
addappid(2108003)
addappid(2108004)
addappid(2108020)
addappid(2108021)
addappid(2108022)
addappid(2108023)
addappid(2108024)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989951, 1, "351f3760fb08b927d6f445ef760b00f6dde158a5eaaff3806e53e45dccd84e64")

