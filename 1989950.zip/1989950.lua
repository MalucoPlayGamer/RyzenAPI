-- Lua provided by RyzenAPI
-- Game: 1989950

-- MAIN APPLICATION
addappid(1989950)
-- Game: addappid(1989950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989951, 1, "351f3760fb08b927d6f445ef760b00f6dde158a5eaaff3806e53e45dccd84e64")
