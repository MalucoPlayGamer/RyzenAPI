-- Lua provided by RyzenAPI 
-- Game: Snack Stall
addappid(1989950)
addappid(1989951, 1, "351f3760fb08b927d6f445ef760b00f6dde158a5eaaff3806e53e45dccd84e64")
