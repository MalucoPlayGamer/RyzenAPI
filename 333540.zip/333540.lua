-- Lua provided by RyzenAPI
-- Game: addappid(333540)

-- MAIN APPLICATION
addappid(333540)

-- MAIN APP DEPOTS / PACKAGES
addappid(333541, 1, "0867aa27923876bbadaf08ef53d604dcb65a6d630d069d42613904499e52d6fe")
addappid(333542, 1, "26c4fe7e73e79cde1e75d93df1579cfd6ad25cc6a873ba94d03bab02c37abd0a")
addappid(333543, 1, "ef8b260a6af11e46dee7072f1a95e8f6e3ecdbac0484b14680299a94ba89fe37")
