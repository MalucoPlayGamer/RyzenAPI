-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３- Bonus Costume for Wang Yi

-- MAIN APPLICATION
addappid(933491)
-- Game: addappid(933491)

-- MAIN APP DEPOTS / PACKAGES
addappid(933491,0,"24f02afbbf743240decf12bc2e673788bc520c02cb8a16e1000c4454826994c7")
addtoken(933491,2510814798471980565)
