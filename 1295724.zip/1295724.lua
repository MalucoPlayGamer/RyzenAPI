-- Lua provided by RyzenAPI
-- Game: Dragon Age™ II - Promotional Pack

-- MAIN APPLICATION
addappid(1295724)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295724,0,"456c7427660864d013111c2382047c103c6eb354fa20cab5f88ef4c3fd74bb17")
addappid(1296140,0,"837adc437c3ba265c899adb558bb43f08a4c698a4c683829dd32c272537ebf17")
addappid(1296141,0,"90c6bfd89d037792b897d2b980f5be0ae8861f7aa6aebe7c6ce2edcc0c141e5d")
addappid(1296142,0,"7c6480bbdc492aadaf49a8d53fb614a6f9c6e5c011e63b18b14bd7660c6a70f9")
addappid(1296143,0,"eec0dda8147a24e8521b0ace282e1279eaa094436c0883543efaf27bd43b0cc9")
addappid(1296144,0,"e457d01f1e157f120c4152a986f0733942daeba408db039bbb1e65c89beb1c51")
addappid(1296145,0,"73d51a13cfe718f7ec72b2fccc20f03e6bc018aa59fbca1af7ca2041a013dab1")
addappid(1296146,0,"d2c2b5bcd6ddd7c94e29a07bf70d70e25ec7346bce7eb663f3c63a58756e507e")

