-- Lua provided by RyzenAPI
-- Game: Wise Escape From Prison (현명한 감옥 탈출기)

-- MAIN APPLICATION
addappid(1237060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237061, 1, "e01b8d9911dc79b280dc28dc581324eeba795d51ff4499d1c4da07c5660a9650")
