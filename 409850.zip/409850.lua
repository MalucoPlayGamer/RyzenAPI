-- Lua provided by RyzenAPI
-- Game: 409850

-- MAIN APPLICATION
addappid(409850)
-- Game: addappid(409850)

-- MAIN APP DEPOTS / PACKAGES
addappid(409851, 1, "6d3e9256604951472f033eb5ed56d4255b1db75e1c35438755699db3ac0981bd")
addappid(516330, 0, "36bfebe00a0d60b2f5ce2ec9e4528dc7f3ee88013394bdef9af25521c55618ab")
addappid(516331, 0, "85835ccf4ffe5b8f2cc55bf42c560fd12a5aba4bde2a5ff8546c77c04ff5e431")
