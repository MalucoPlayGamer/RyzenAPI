-- Lua provided by RyzenAPI
-- Game: Criminal Girls: Invite Only

-- MAIN APPLICATION
addappid(409850)

-- MAIN APP DEPOTS / PACKAGES
addappid(409851, 1, "6d3e9256604951472f033eb5ed56d4255b1db75e1c35438755699db3ac0981bd")
addappid(516330, 0, "36bfebe00a0d60b2f5ce2ec9e4528dc7f3ee88013394bdef9af25521c55618ab")
addappid(516331, 0, "85835ccf4ffe5b8f2cc55bf42c560fd12a5aba4bde2a5ff8546c77c04ff5e431")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
