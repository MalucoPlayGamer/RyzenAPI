-- Lua provided by RyzenAPI
-- Game: Hentai Cheerleader

-- MAIN APPLICATION
addappid(2322280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322281, 1, "f0641431804b6a07cd6fde3d5c99bbe47966f7aa2489457d6e5a53529cae8b53")

