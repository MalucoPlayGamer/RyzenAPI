-- Lua provided by RyzenAPI
-- Game: Rescue HQ - The Tycoon

-- MAIN APPLICATION
addappid(809720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(809721, 1, "c405fd2a4f4a4a62cdcca1fbb929b8bf5e8774a1b5b51f551f56aa139bb8b4b9")
addappid(1239250, 0, "fa957a4d03978f91dbc1875e6f85670b48c65c481b955c55758b6b0b8f385114")

