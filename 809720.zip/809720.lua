-- Lua provided by RyzenAPI 
-- Game: Rescue HQ - The Tycoon
addappid(809720)
addappid(809721, 1, "c405fd2a4f4a4a62cdcca1fbb929b8bf5e8774a1b5b51f551f56aa139bb8b4b9")
addappid(1239250, 0, "fa957a4d03978f91dbc1875e6f85670b48c65c481b955c55758b6b0b8f385114")
