-- Lua provided by RyzenAPI
-- Game: Arbiter

-- MAIN APPLICATION
addappid(772220)

-- MAIN APP DEPOTS / PACKAGES
addappid(772221,0,"ba80c431a32402c9b5264efc4cca330fce05134510e518a9c04a1c00829b6f53")

