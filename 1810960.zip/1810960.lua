-- Lua provided by RyzenAPI
-- Game: Andy's Apple Farm

-- MAIN APPLICATION
addappid(1810960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810961, 1, "b4c2368a751bd30faef6e3dc2219ab9d6aad6dc015d29729c66d5403f43f0f3f")

