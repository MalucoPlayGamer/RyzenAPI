-- Lua provided by RyzenAPI
-- Game: 1452050

-- MAIN APPLICATION
addappid(1452050)
-- Game: addappid(1452050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452050,0,"128806d129f739d98af97667f1fad77c1da1d865df2daff873c0089a7037a659")
