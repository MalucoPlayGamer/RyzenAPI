-- Lua provided by RyzenAPI
-- Game: BURST WITCH

-- MAIN APPLICATION
addappid(2001670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001671, 1, "b38ed7601fca89e5fbe1ab4d13c948eb64d6e4681733cc0ec95ccae50d575af6")
