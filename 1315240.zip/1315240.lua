-- Lua provided by RyzenAPI
-- Game: Blackstorm

-- MAIN APPLICATION
addappid(1315240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1315241, 1, "046923fa8c2e0c00b59dc7d399e77eb8e53613ded09483f50f2a6f94c3ff853b")
addappid(1315991, 0, "43d85224e8400476d5e4197fac568f4b200342bee1d96a38e48ab92f249339d1")

