-- Lua provided by RyzenAPI
-- Game: Blackstorm

-- MAIN APPLICATION
addappid(1315240)
-- Game: addappid(1315240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315241, 1, "046923fa8c2e0c00b59dc7d399e77eb8e53613ded09483f50f2a6f94c3ff853b")
addappid(1315991, 0, "43d85224e8400476d5e4197fac568f4b200342bee1d96a38e48ab92f249339d1")
