-- Lua provided by RyzenAPI
-- Game: Wonderputt Forever

-- MAIN APPLICATION
addappid(1766540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766542,0,"a4e2810d7084e3feab4ddd0617390ca9cd770db7cdcf85494c741e802c75d074")
