-- Lua provided by RyzenAPI
-- Game: 41005

-- MAIN APPLICATION
addappid(41001)
addappid(41003)
addappid(41005)

-- MAIN APP DEPOTS / PACKAGES
addappid(41005,0,"2ca6933ef1dd48a71413adc449ee2d03292a3d121857b7b9b6589422db84dd85")
