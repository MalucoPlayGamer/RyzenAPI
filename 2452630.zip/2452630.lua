-- Lua provided by SkyAPI 
-- Game: Jock Studio Demo
addappid(2452630)
addappid(2452631, 1, "40299c23c6192e2e57251eb4a08795d8185730319b6fa799235d8c3f50da4dfc")
addappid(2452632, 1, "8ac667dce0cce0645f7408dd389d9235d7c8c71e1c1fe15c009e1664512e7da6")
