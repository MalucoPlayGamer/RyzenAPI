-- Lua provided by RyzenAPI
-- Game: Supreme League of Patriots Issue 3: Ice Cold in Ellis

-- MAIN APPLICATION
addappid(336730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(336731, 1, "a6b8c9adb0faa67026e2825a26660fd6a9108b3adfdc85972a2b9cfd1a41e166")
addappid(336732, 1, "bf1962ce3d367f9c098e95fccb56539a1e7a3592d55e43b5f37c2d0027c5042c")
addappid(336733, 1, "a74da69c738088b574ea83b8179754e2a1b32d60790abfd8e0e25d12ed2a3c9d")
addappid(336734, 1, "78b40c7689c95d01b4a8ce350fe006199a0903b83dbbdff59ec91ade9107493c")

