-- Lua provided by RyzenAPI
-- Game: Trainatic

-- MAIN APPLICATION
addappid(3208560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208561, 1, "a489068d42cdc161802726031ef1d30cbb50ae56e4c677768cd6c13a7cf6cea0")

