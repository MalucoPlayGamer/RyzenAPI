-- Lua provided by RyzenAPI
-- Game: Robots n Lasers

-- MAIN APPLICATION
addappid(1692520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1692521, 1, "5f4ccdc5d7f3ae72e314e6966a4cc4f698d8c150c113e9abaed703660b968d73")

