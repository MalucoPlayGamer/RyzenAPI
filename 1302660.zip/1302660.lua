-- Lua provided by RyzenAPI
-- Game: Wish - Beyond Fate

-- MAIN APPLICATION
addappid(1302660)
addappid(1302661)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302660,0,"a65f961ca996a01a5f4a76bcbefe0e21c11259998b6a12b7bc4d8d839421bbb9")
