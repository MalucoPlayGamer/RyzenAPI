-- Lua provided by SkyAPI 
-- Game: AppID 1165530
addappid(1165530)
addappid(1165531, 1, "608c772d3d197525fc90a4b8b411618f56c6b827e3b278b104747333d6829dc7")
