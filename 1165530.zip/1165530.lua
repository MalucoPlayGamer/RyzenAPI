-- Lua provided by RyzenAPI
-- Game: AppID 1165530

-- MAIN APPLICATION
addappid(1165530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165531, 1, "608c772d3d197525fc90a4b8b411618f56c6b827e3b278b104747333d6829dc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
