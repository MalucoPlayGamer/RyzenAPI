-- Lua provided by RyzenAPI
-- Game: Offroad Truck Simulator – Heavy Duty Challenge

-- MAIN APPLICATION
addappid(1165530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1165531, 1, "608c772d3d197525fc90a4b8b411618f56c6b827e3b278b104747333d6829dc7")
