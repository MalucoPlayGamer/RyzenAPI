-- Lua provided by RyzenAPI
-- Game: Game: Maybe Immortal

-- MAIN APPLICATION
addappid(1640810)
-- Game: addappid(1640810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640811, 1, "6a8fde9c79f3b3d2d5b24f3a3d90f77783247dc4e4cf42fa42827ac81ae91ab4")
