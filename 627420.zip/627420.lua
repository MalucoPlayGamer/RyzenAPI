-- Lua provided by RyzenAPI
-- Game: Sorgina: A Tale of Witches

-- MAIN APPLICATION
addappid(627420)

-- MAIN APP DEPOTS / PACKAGES
addappid(627421,0,"ac59ad11c7ead8a51605ac00fcf8b6b0014c4e08c57942a7a8429e07b3cad2ab")

