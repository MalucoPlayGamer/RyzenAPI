-- Lua provided by RyzenAPI
-- Game: 怪物塔 Monster Tower

-- MAIN APPLICATION
addappid(3609580)
-- Game: addappid(3609580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609581, 1, "b6dd201b6e9841ad6ee0b5a7f2d0b64b2065e1dba1681cc2dd75405606fca678")
