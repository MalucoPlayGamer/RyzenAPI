-- Lua provided by RyzenAPI 
-- Game: Tropical Monster Girls
addappid(3060250)
addappid(3060251, 1, "10faf374ab755aee0b0b7ee8cca6ecda9f081c2ea84dda8884ea9ff1333ebcc8")
