-- Lua provided by RyzenAPI
-- Game: Nakawak: Expanded Color Edition

-- MAIN APPLICATION
addappid(716150)

-- MAIN APP DEPOTS / PACKAGES
addappid(716151, 1, "10551ed9a48691cdd8c887b267d52be13ca105f00993c35a8e5af04be71f5d84")
