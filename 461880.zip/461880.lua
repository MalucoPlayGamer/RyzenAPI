-- Lua provided by RyzenAPI
-- Game: 461880

-- MAIN APPLICATION
addappid(461880)
-- Game: addappid(461880)

-- MAIN APP DEPOTS / PACKAGES
addappid(461881, 1, "c2ae1f509ce524807b993d425146d68e9dc7fe36bab78ba3bbd00956b0c94a9f")
addappid(461882, 1, "baffa786cd4dd7209e6b6a5bc72045b7df521595c75b0d8b25650b9955fe6a15")
addappid(461883, 1, "58a0a751db5e0edb88550650c77ab9eb9ddbbd0fe344bc11a1b50bc64384781d")
