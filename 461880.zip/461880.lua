-- Lua provided by RyzenAPI
-- Game: Hyposphere

-- MAIN APPLICATION
addappid(461880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(461881, 1, "c2ae1f509ce524807b993d425146d68e9dc7fe36bab78ba3bbd00956b0c94a9f")
addappid(461882, 1, "baffa786cd4dd7209e6b6a5bc72045b7df521595c75b0d8b25650b9955fe6a15")
addappid(461883, 1, "58a0a751db5e0edb88550650c77ab9eb9ddbbd0fe344bc11a1b50bc64384781d")

