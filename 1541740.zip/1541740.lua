-- Lua provided by RyzenAPI
-- Game: TrackMaster: Free For All Motorsport Demo

-- MAIN APPLICATION
addappid(1541740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541741, 1, "b9993ff12e94c6ce13028d3ae44e93787a69d68645963f5118cb980827daea20")

