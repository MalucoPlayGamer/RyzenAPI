-- Lua provided by RyzenAPI
-- Game: Game: QIMEN Tower Defense

-- MAIN APPLICATION
addappid(3428690)
-- Game: addappid(3428690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428691, 1, "a24f98edfeda71b666213b10653c39a6312223fce72e41311742accb58a6e7ba")
