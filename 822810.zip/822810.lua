-- Lua provided by RyzenAPI
-- Game: Velvet Guard

-- MAIN APPLICATION
addappid(822810)
addappid(3845490)

-- MAIN APP DEPOTS / PACKAGES
addappid(822811, 1, "6773286c54e8a6f9303a41fb8050d241a3951b9a322bf8a97094d54379c49d01")

