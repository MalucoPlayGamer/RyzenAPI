-- Lua provided by RyzenAPI
-- Game: Velvet Guard

-- MAIN APPLICATION
addappid(822810)
addappid(3845490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(822811, 1, "6773286c54e8a6f9303a41fb8050d241a3951b9a322bf8a97094d54379c49d01")

