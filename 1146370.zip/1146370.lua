-- Lua provided by RyzenAPI
-- Game: Master of Magic Classic

-- MAIN APPLICATION
addappid(1146370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146371, 1, "3aca91470d6018b9a4ac245c82c014a4a2ff5d830b7f25915a9439a98ae925a5")
addappid(1146372, 1, "495f9ae1deb2424e21466f56382dc2dcfd38a3b7984ef4cc23f98f2c6a96a81e")
addappid(1146373, 1, "20383ef0cae7c002dc00197b61731f7280ca6a8bbc3f7a67ba9012447c6048b6")
addappid(1146374, 1, "630f928d0334021649bdb602c6ef7027f6fdd749c7d715a151b3d0670dc4081a")
addappid(1146375, 1, "f15735e5169171d404f41ee34bf0be88cca267c3f56e7688f1e84f2c83257579")
addappid(1146376, 1, "87bd4e02620cb77eaf1c21ec77e7ea67fed3414735f20c777472ef2770a5aebf")
addappid(1146377, 1, "efa1f72f56035f27e8835a58d9a5fb5b9f52ec5219506414d318c943633e3ba7")
addappid(1557960, 0, "6c6f4e59d58ef5c4ca5675c572fc9650bf0dda30286b1014d53147b26a8eb5a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1250690)
