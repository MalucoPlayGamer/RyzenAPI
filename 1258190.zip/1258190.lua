-- Lua provided by RyzenAPI
-- Game: Cyber Lady

-- MAIN APPLICATION
addappid(1258190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258191, 1, "e52ab88fcd3ba1cd3a4051b73f5a43b84e87d74e0de558edd95f05579330a0ca")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1263500)
