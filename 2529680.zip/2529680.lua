-- Lua provided by RyzenAPI
-- Game: 2529680

-- MAIN APPLICATION
addappid(2529680)
-- Game: addappid(2529680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529681, 1, "20e453025c2b95e904c90ab192ad96f87cc96a5115afe8fcd0f4339f8e3d766d")
