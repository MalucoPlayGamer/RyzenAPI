-- Lua provided by SkyAPI 
-- Game: Countdown Timer
addappid(2182640)
addappid(2182641, 1, "c58202f9f804bea792cc20fe20f6f9410a514841b04681797244be9a6e8a1a9b")
