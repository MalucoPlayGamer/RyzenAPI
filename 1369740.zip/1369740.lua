-- 1369740's Lua and Manifest Created by Hubcap Manifest
-- Dragon Lapis
-- Created: October 02, 2025 at 09:16:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1369740) -- Dragon Lapis
-- MAIN APP DEPOTS
addappid(1369741, 1, "2a18ae884d30e9308ca54febde0c36dc8189164064aa4b481ebefa3df0a7f5c5") -- Dragon Lapis Content
setManifestid(1369741, "1351063396181757416", 583691202)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1382600) -- Experience x3 - Dragon Lapis
addappid(1382610) -- No Encounters - Dragon Lapis
addappid(1382611) -- Damage x2 - Dragon Lapis
addappid(1382612) -- Full Restore - Dragon Lapis
addappid(1382613) -- No Skill Cost - Dragon Lapis