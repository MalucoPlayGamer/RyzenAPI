-- Lua provided by RyzenAPI
-- Game: Dragon Lapis

-- MAIN APPLICATION
addappid(1369740) -- Dragon Lapis
addappid(1382600) -- Experience x3 - Dragon Lapis
addappid(1382610) -- No Encounters - Dragon Lapis
addappid(1382611) -- Damage x2 - Dragon Lapis
addappid(1382612) -- Full Restore - Dragon Lapis
addappid(1382613) -- No Skill Cost - Dragon Lapis

-- MAIN APP DEPOTS / PACKAGES
addappid(1369741, 1, "2a18ae884d30e9308ca54febde0c36dc8189164064aa4b481ebefa3df0a7f5c5") -- Dragon Lapis Content

