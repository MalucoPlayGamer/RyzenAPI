-- Lua provided by RyzenAPI
-- Game: Game: AppID 1369740

-- MAIN APPLICATION
addappid(1369740)
-- Game: addappid(1369740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369741, 1, "2a18ae884d30e9308ca54febde0c36dc8189164064aa4b481ebefa3df0a7f5c5")
