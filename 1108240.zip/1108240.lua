-- Lua provided by RyzenAPI
-- Game: Code/The Werewolf Party

-- MAIN APPLICATION
addappid(1108240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108241, 1, "257f11a6ed3aeac48f2bc949e8a86b36ac5081f81f969884e461c820975e470a")
