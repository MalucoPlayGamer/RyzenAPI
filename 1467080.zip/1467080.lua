-- Lua provided by RyzenAPI
-- Game: addappid(1467080)

-- MAIN APPLICATION
addappid(1467080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467081, 1, "c3ff67a93e7243226762f719bc9a9b1b581ac391a01f131239c110076ceaec58")
