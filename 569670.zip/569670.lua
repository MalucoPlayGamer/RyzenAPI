-- Lua provided by RyzenAPI
-- Game: LoveKami -Divinity Stage- Demo

-- MAIN APPLICATION
addappid(569670)
-- Game: addappid(569670)

-- MAIN APP DEPOTS / PACKAGES
addappid(569671, 1, "e47b74a6f55cb108dc42b374231f1431788348a0e148abd45f5194e08d30ecc4")
