-- Lua provided by RyzenAPI
-- Game: 2076030

-- MAIN APPLICATION
addappid(2076030)
-- Game: addappid(2076030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076031, 1, "3b452adefce9d31d73d703c6a79b1b6553c4d03f3577e774a5762edd92d39c66")
