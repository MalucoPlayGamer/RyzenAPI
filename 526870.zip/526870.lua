-- Lua provided by RyzenAPI
-- Game: AppID 526870

-- MAIN APPLICATION
addappid(526870)
addappid(3170070)

-- MAIN APP DEPOTS / PACKAGES
addappid(526871, 1, "ae0ab673da3c9d0f444b1cd61fe8f2235d43e6c0401684a78f4fbdfc8f0d9bc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
