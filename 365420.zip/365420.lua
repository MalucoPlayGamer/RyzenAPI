-- Lua provided by RyzenAPI
-- Game: Game: AppID 365420

-- MAIN APPLICATION
addappid(365420)
-- Game: addappid(365420)

-- MAIN APP DEPOTS / PACKAGES
addappid(365421, 1, "ed9c2d3f8f2d30a23d7e7c6144651840cae7bf8b809495bf7f3872d7e901da42")
