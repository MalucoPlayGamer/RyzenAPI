-- Lua provided by RyzenAPI
-- Game: AppID 365420

-- MAIN APPLICATION
addappid(365420)

-- MAIN APP DEPOTS / PACKAGES
addappid(365421, 1, "ed9c2d3f8f2d30a23d7e7c6144651840cae7bf8b809495bf7f3872d7e901da42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
