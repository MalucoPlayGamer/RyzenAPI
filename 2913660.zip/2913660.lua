-- Lua provided by RyzenAPI 
-- Game: AppID 2913660
addappid(2913660)
addappid(2913661, 1, "90232d5ea72d2c1dd7fef230857c8c691cbb2b10e37c2be49e7e19b4499f910e")
