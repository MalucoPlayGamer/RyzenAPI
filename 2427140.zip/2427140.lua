-- Lua provided by RyzenAPI
-- Game: MUSA

-- MAIN APPLICATION
addappid(2427140)
-- Game: addappid(2427140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427141, 1, "4da1f76b2823bc229a0f564494ffe833585b291165c5c7285d540ba4962fe379")
