-- Lua provided by RyzenAPI
-- Game: addappid(3440000)

-- MAIN APPLICATION
addappid(3440000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440001, 1, "56cac7755d3c1b57c83be4413bf0a0f495d42881501f68af095d100c892c9e0f")
