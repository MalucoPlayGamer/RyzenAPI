-- Lua provided by RyzenAPI
-- Game: Good fruit

-- MAIN APPLICATION
addappid(2569840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569841, 1, "3604fbbf5f1c69a54d90e48a06452e7ff5c0bb4f291184408e9eeb50170c178f")

