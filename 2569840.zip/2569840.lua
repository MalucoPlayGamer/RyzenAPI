-- Lua provided by SkyAPI 
-- Game: Good fruit
addappid(2569840)
addappid(2569841, 1, "3604fbbf5f1c69a54d90e48a06452e7ff5c0bb4f291184408e9eeb50170c178f")
