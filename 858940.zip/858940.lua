-- Lua provided by RyzenAPI
-- Game: Flowers -Le volume sur ete-

-- MAIN APPLICATION
addappid(858940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(858941, 1, "f6c567c7a36ad50814708d77925e071087813320107030b544659cc726e8769b")
addappid(858942, 1, "a15cccb082e4558e092593d2a65e19a354841076b2c4030327c39c8d2fc94667")
