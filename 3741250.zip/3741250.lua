-- Lua provided by SkyAPI 
-- Game: One Step Further
addappid(3741250)
addappid(3741251, 1, "eadcc0714a5970fc456f7c910d6588b3375ae3f0e4620ba11dda8de8e7d2a79c")
