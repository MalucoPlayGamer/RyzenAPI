-- Lua provided by RyzenAPI
-- Game: One Step Further

-- MAIN APPLICATION
addappid(3741250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3741251, 1, "eadcc0714a5970fc456f7c910d6588b3375ae3f0e4620ba11dda8de8e7d2a79c")
