-- Lua provided by RyzenAPI
-- Game: addappid(3122260)

-- MAIN APPLICATION
addappid(3122260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122261, 1, "3ceade3c79aac3eba53284408fcd58993581890df08793d8d9c08098f5acae85")
