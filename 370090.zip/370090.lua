-- Lua provided by RyzenAPI
-- Game: addappid(370090)

-- MAIN APPLICATION
addappid(370090)

-- MAIN APP DEPOTS / PACKAGES
addappid(370091, 1, "3c700c0ca49ef20bcd517584d8eef6d10832114363d3193c08fa1ec97291ea5f")
