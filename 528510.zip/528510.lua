-- Lua provided by RyzenAPI
-- Game: Game: AppID 528510

-- MAIN APPLICATION
addappid(528510)
-- Game: addappid(528510)

-- MAIN APP DEPOTS / PACKAGES
addappid(528511, 1, "8d664fec685c7219d72dae9ef43919c856c297292766247560846bc080eb7e5d")
addappid(528512, 1, "224af5fa382f535ef51712f0fb4f0285d345843aebfcfa7e217e1950ce2c58b8")
