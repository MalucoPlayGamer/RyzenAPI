-- Lua provided by RyzenAPI
-- Game: AppID 528510

-- MAIN APPLICATION
addappid(528510)

-- MAIN APP DEPOTS / PACKAGES
addappid(528511, 1, "8d664fec685c7219d72dae9ef43919c856c297292766247560846bc080eb7e5d")
addappid(528512, 1, "224af5fa382f535ef51712f0fb4f0285d345843aebfcfa7e217e1950ce2c58b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
