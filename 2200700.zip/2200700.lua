-- Lua provided by RyzenAPI
-- Game: addappid(2200700)

-- MAIN APPLICATION
addappid(2200700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200701, 1, "4575e6e1da795b537f560a33a40e6ed6b782c0feb3e99c838031adde3f4a5582")
