-- Lua provided by RyzenAPI
-- Game: TuHou Remilia - Begin Of Scarlet Family

-- MAIN APPLICATION
addappid(2200700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2200701, 1, "4575e6e1da795b537f560a33a40e6ed6b782c0feb3e99c838031adde3f4a5582")

