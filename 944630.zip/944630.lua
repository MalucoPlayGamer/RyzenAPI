-- Lua provided by RyzenAPI
-- Game: MOLOCH (Zero)

-- MAIN APPLICATION
addappid(944630)
-- Game: addappid(944630)

-- MAIN APP DEPOTS / PACKAGES
addappid(944631, 1, "2ede0ef97ac59779c1713bc7deebdb9da885f080360390dd795bcfc1221d3ba7")
