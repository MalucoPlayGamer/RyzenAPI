-- Lua provided by RyzenAPI
-- Game: DELTAZEAL

-- MAIN APPLICATION
addappid(379520)

-- MAIN APP DEPOTS / PACKAGES
addappid(379521, 1, "1f8c5f42f7f5675ad407eb4da27b2c457eae7cdf223e28d458414a8bba9a3b70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
