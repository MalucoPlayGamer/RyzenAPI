-- Lua provided by RyzenAPI
-- Game: Game: DELTAZEAL

-- MAIN APPLICATION
addappid(379520)
-- Game: addappid(379520)

-- MAIN APP DEPOTS / PACKAGES
addappid(379521, 1, "1f8c5f42f7f5675ad407eb4da27b2c457eae7cdf223e28d458414a8bba9a3b70")
