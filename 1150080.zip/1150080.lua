-- Lua provided by RyzenAPI
-- Game: AppID 1150080

-- MAIN APPLICATION
addappid(1150080)
addappid(1162340)
addappid(1162341)
addappid(1162342)
addappid(1336480)
addappid(1336481)
addappid(1336482)
addappid(1336483)
addappid(1336484)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150081, 1, "6b0bf9f1a6ad67843a4a2c16775ebbb274e11f6781a387b849f48678b4d6c75a")
addappid(1150082, 1, "423ba2b3e3c3862f3fa42cb9e4ab50f482717e1722cbc7b0b0f588423b0250f0")
addappid(1150083, 1, "5a9a96744b0ba1b07a95a77aa9aca41ce9b49eb080e4232609a2a799171c0bd8")
addappid(1150084, 1, "1446aa9797745ef6a5906406823c362d46bb4581770ca975a3e6c41de01f8c92")
addappid(1215110, 0, "cbb75832d1e82f2a486d0ee2a32a5ac724696b8a12790266c4fa4a25d59882d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
