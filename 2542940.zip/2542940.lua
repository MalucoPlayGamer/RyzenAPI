-- Lua provided by RyzenAPI
-- Game: addappid(2542940)

-- MAIN APPLICATION
addappid(2542940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542941, 1, "480e78dcfafec346e01927aea2cdef7e015dba84049e9515e5e5e19051d15d63")
