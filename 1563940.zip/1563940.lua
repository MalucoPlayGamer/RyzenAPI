-- Lua provided by RyzenAPI
-- Game: Atlantica Europe

-- MAIN APPLICATION
addappid(1563940)
