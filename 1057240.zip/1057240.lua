-- Lua provided by RyzenAPI
-- Game: Crucible Beta

-- MAIN APPLICATION
addappid(1057240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057241, 1, "2cb4799551a98aca0c71b97a690a3e9ee049a5aec2220bc9cbfcca95e13622d9")
