-- Lua provided by RyzenAPI
-- Game: AppID 1250790

-- MAIN APPLICATION
addappid(1250790)
-- Game: addappid(1250790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250791, 1, "d2314775471efea67e018a202908acdf878d20466a5e93bc3f320206c4848ace")
