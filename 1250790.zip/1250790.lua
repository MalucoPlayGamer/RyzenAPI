-- Lua provided by RyzenAPI 
-- Game: AppID 1250790
addappid(1250790)
addappid(1250791, 1, "d2314775471efea67e018a202908acdf878d20466a5e93bc3f320206c4848ace")
