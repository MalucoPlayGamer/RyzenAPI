-- Lua provided by RyzenAPI
-- Game: The Unseen Fears: Outlive Collector's Edition

-- MAIN APPLICATION
addappid(3884820)
-- Game: addappid(3884820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3884821, 1, "73158ddd7856d79c938c881e42bde1de6d9618d714d5abbaad0a58012d5fe2b1")
