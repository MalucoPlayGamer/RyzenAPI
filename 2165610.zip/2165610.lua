-- Lua provided by RyzenAPI
-- Game: Mosaique Neko Waifus 5

-- MAIN APPLICATION
addappid(2165610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165611, 1, "66888caadb3098c286f4e7aeefad2db238dacb4b0fdb8c2dc519673aed0d89c4")
addappid(2165612, 1, "3a50159b8ffeeb401a71a148c171a5f5857d2629533b652a29664be3b3781cc9")
addappid(2165613, 1, "073dbd7fb7d9b5416123d53e5b4d477278de765a83da1d826f8fe38b6b93781b")
addappid(2190360, 0, "fcc2ce31656bcf56dc73fe95b75d36ddb9fef392132f46485655adfbcdbc5234")
