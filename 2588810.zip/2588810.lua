-- Lua provided by RyzenAPI
-- Game: Stellar Serenity Demo

-- MAIN APPLICATION
addappid(2588810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588811, 1, "4d2a7fdcbd7a734d8688c9a8e31e014e0b7cf9b055884942296172fd1e26a0e9")
