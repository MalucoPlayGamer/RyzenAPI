-- Lua provided by RyzenAPI
-- Game: 2930210

-- MAIN APPLICATION
addappid(2930210)
-- Game: addappid(2930210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930211, 1, "28c81c20318638da7eb9f7f447ec1b8685b342c9db9fb008eaf04f9a0977e721")
