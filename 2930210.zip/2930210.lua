-- Lua provided by RyzenAPI
-- Game: MY DOG!

-- MAIN APPLICATION
addappid(2930210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930211, 1, "28c81c20318638da7eb9f7f447ec1b8685b342c9db9fb008eaf04f9a0977e721")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
