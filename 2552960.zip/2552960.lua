-- Lua provided by RyzenAPI 
-- Game: AppID 2552960
addappid(2552960)
addappid(2552961, 1, "e6dee2a766937aba9229013bba487da36e9e1e9c50d9e8b521292aa92154e412")
