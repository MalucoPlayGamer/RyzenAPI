-- Lua provided by RyzenAPI
-- Game: AppID 467460

-- MAIN APPLICATION
addappid(467460)

-- MAIN APP DEPOTS / PACKAGES
addappid(467461, 1, "6deb980f4deed925833602b0cc8fbdf105551de5afa71e470d797787f06caa28")
