-- Lua provided by RyzenAPI
-- Game: Game: Chaotic Loop

-- MAIN APPLICATION
addappid(1995230)
addappid(2099130)
-- Game: addappid(1995230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995231, 1, "359cc4eff47c597245ee6b69c5c40364c721e78dae16c0388922f5323f386572")
