-- Lua provided by RyzenAPI
-- Game: Heroes City Superman Edition

-- MAIN APPLICATION
addappid(2181490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2181491, 1, "96dd3243568d6b5e931b09c66dcdd91e9ae96cbc6a339d768271dc4e2a61d1e8")
