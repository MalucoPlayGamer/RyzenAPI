-- Lua provided by RyzenAPI
-- Game: Game: AppID 2181490

-- MAIN APPLICATION
addappid(2181490)
-- Game: addappid(2181490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181491, 1, "96dd3243568d6b5e931b09c66dcdd91e9ae96cbc6a339d768271dc4e2a61d1e8")
