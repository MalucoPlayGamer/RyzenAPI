-- Lua provided by RyzenAPI
-- Game: Wildlife Park Gold Reloaded

-- MAIN APPLICATION
addappid(664120)

-- MAIN APP DEPOTS / PACKAGES
addappid(664122,0,"eb8b80bfe07fd9443252f5657cf14bd5e96d8e9e3b9ea02493e48e8dc0dc1a96")

