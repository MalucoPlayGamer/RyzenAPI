-- Lua provided by RyzenAPI 
-- Game: 呆呆大冒险
addappid(2166910)
addappid(2166911, 1, "8493e0c28262fd3ce3603a9ede7a370e6bf6ad92ee0dcd0a1711de5e2352f646")
