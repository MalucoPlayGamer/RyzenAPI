-- Lua provided by RyzenAPI
-- Game: EverQuest II

-- MAIN APPLICATION
addappid(201230)

