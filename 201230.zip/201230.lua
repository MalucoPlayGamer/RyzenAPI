-- Lua provided by RyzenAPI
-- Game: EverQuest II

-- MAIN APPLICATION
addappid(24100)
addappid(24110)
addappid(24190)
addappid(24230)
addappid(201230)
addappid(224560)
addappid(249770)
addappid(332430)
addappid(333890)
addappid(333891)
addappid(333892)
addappid(334430)
addappid(420410)

