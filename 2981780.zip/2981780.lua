-- Lua provided by RyzenAPI
-- Game: Game: 病娇X契约 Demo

-- MAIN APPLICATION
addappid(2981780)
-- Game: addappid(2981780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981781, 1, "c781e6fdc848527d39cb39df36b671f50f3660bf89164e0d3ec50d2dc64c21e0")
