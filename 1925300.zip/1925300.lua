-- Lua provided by RyzenAPI
-- Game: 1925300

-- MAIN APPLICATION
addappid(1925300)
-- Game: addappid(1925300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925301, 1, "90c7a8d2dc42c3237e8c62179ec0109a332b1f6c230f51a33a5e3cc98a3fd35d")
