-- Lua provided by RyzenAPI 
-- Game: AppID 1946700
addappid(1946700)
addappid(1946701, 1, "1855172b9981957be819a2b9bf0465f73a8891dd8b3df1c8f5c058d2e67dd600")
addappid(1946702, 1, "138424a39d78ff3f8bbffbbab899c050b2d5872b1220105e8a40a17784606cfc")
