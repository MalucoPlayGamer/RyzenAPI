-- Lua provided by RyzenAPI
-- Game: AppID 1946700

-- MAIN APPLICATION
addappid(1946700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946701, 1, "1855172b9981957be819a2b9bf0465f73a8891dd8b3df1c8f5c058d2e67dd600")
addappid(1946702, 1, "138424a39d78ff3f8bbffbbab899c050b2d5872b1220105e8a40a17784606cfc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2402250)
