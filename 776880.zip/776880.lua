-- Lua provided by RyzenAPI
-- Game: addappid(776880)

-- MAIN APPLICATION
addappid(776880)

-- MAIN APP DEPOTS / PACKAGES
addappid(776881, 1, "943e51a23a2c006f597bfd9a91b6851d9d785eb4c4211a88c527bbc9b188b5d9")
