-- Lua provided by RyzenAPI
-- Game: Assault Suit Leynos 2 Saturn Tribute

-- MAIN APPLICATION
addappid(2488300)
-- Game: addappid(2488300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488301, 1, "736d86bbf9e4e2503caf286826302d3f1c67fd90266af0bd19f3966cac553531")
