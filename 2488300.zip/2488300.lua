-- Lua provided by RyzenAPI
-- Game: Assault Suit Leynos 2 Saturn Tribute

-- MAIN APPLICATION
addappid(2488300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2488301, 1, "736d86bbf9e4e2503caf286826302d3f1c67fd90266af0bd19f3966cac553531")

