-- Lua provided by SkyAPI 
-- Game: AppID 1195460
addappid(1195460)
addappid(1195461, 1, "d490602afdf4203eddb34754d7ad01c9ce80bc12c9aeee5f1013dbd4c82721ec")
