-- Lua provided by RyzenAPI
-- Game: AppID 1195460

-- MAIN APPLICATION
addappid(1195460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195461, 1, "d490602afdf4203eddb34754d7ad01c9ce80bc12c9aeee5f1013dbd4c82721ec")
