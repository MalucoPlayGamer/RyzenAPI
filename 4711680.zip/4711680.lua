-- Lua provided by RyzenAPI
-- Game: Gathera

-- MAIN APPLICATION
addappid(4711680) -- Gathera

-- MAIN APP DEPOTS / PACKAGES
addappid(4711681, 1, "76992ae6df3a8480fa3d12ce219b2089ea1a89f8c18e958569d85e0732e1deac") -- Depot 4711681
