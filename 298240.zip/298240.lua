-- Lua provided by RyzenAPI
-- Game: addappid(298240)

-- MAIN APPLICATION
addappid(298240)

-- MAIN APP DEPOTS / PACKAGES
addappid(298241, 1, "a359db96cf45d8c4a271da7a47905976777bc173ee00df803c4b9e046159c47a")
addappid(298245, 1, "6cc31509d6dc43f7a15fb3bc91bb2165f734ed0339d3e7eba6edbdaa38b69996")
