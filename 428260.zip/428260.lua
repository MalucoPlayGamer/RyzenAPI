-- Lua provided by RyzenAPI
-- Game: Game: The Book of Desires

-- MAIN APPLICATION
addappid(428260)
-- Game: addappid(428260)

-- MAIN APP DEPOTS / PACKAGES
addappid(428261, 1, "9ce51ebe78c43fdf2012a3df049941644bad44989f2c51c3e27c27d5235ec646")
addappid(428262, 1, "931cb73be627e270094ed0186eca7c7aa12c81d5f4e3928fca7f2a4fadffc51e")
addappid(428263, 1, "50b8330c4df279d36219ecc9a38513e2ca6340ab7351aa8aee49ff2972e33801")
addappid(428264, 1, "455b3ee3d6faa6295ec3eec5035cd2db5a2d3c76f1b8dbb1cbd6eb951390dac4")
addappid(428265, 1, "e57183a8b1600fde85159c33d1aee4e6a4ef0ab2cc7f5d45365a6ce3f3a4c824")
addappid(428266, 1, "9afc7fbd4adadb160b0830d96e31ea2847b22033adb4195522243907c546595e")
addappid(428267, 1, "9e3087594e24bbbf19155ae4a02de1c5555ca25c72eeb5cd92669d61a94cae71")
addappid(428268, 1, "1479777757c4d137d37555cce3cba5447e8f8220bedaeb4c364e56fc6b53e799")
