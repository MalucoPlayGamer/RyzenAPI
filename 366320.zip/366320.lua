-- Lua provided by RyzenAPI
-- Game: 366320

-- MAIN APPLICATION
addappid(366320)
-- Game: addappid(366320)

-- MAIN APP DEPOTS / PACKAGES
addappid(366321, 1, "c3b1855df00a5dd17f5b180f486e86198f2cc0626d9d6cdf5f05e87e7863a968")
