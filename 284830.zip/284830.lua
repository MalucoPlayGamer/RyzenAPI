-- Lua provided by RyzenAPI 
-- Game: AppID 284830
addappid(284830)
addappid(284831, 1, "e2010ca387faef0694f88f7a80c01c26191041161d41abb38777e55c4ae5ae85")
addappid(284832, 1, "430c9b3a5bd49680dfca5596d5dbda436024e2f0f744d011de76acc62d0da200")
addappid(284833, 1, "bbbd23d45adb724975c3174a9f95a6731a8c0e5451d51a6e0d0a6ef7a32ea1b5")
