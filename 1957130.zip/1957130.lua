-- Lua provided by RyzenAPI
-- Game: 1957130

-- MAIN APPLICATION
addappid(1957130)
addappid(1962480)
-- Game: addappid(1957130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957131, 1, "a082933d051d8fa25e343a4d1ee196c9fabaa56d8f0ceeec8f2d05732eaa7d75")
