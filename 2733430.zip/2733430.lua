-- Lua provided by RyzenAPI
-- Game: Game: Slot Fever

-- MAIN APPLICATION
addappid(2733430)
-- Game: addappid(2733430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733431, 1, "b6789a5e4863ba9955ad08149202747a53b131fc102c17b0c9ca456eef4a84b4")
