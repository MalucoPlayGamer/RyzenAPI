-- Lua provided by RyzenAPI 
-- Game: AppID 537060
addappid(537060)
addappid(537061, 1, "a48fcb4eac27772c0bac317f274d6900fcdb8a7867488cabfdae615136f00dc0")
