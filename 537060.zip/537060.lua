-- Lua provided by RyzenAPI
-- Game: AppID 537060

-- MAIN APPLICATION
addappid(537060)

-- MAIN APP DEPOTS / PACKAGES
addappid(537061, 1, "a48fcb4eac27772c0bac317f274d6900fcdb8a7867488cabfdae615136f00dc0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
