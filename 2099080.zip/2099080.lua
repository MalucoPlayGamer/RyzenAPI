-- Lua provided by RyzenAPI
-- Game: addappid(2099080)

-- MAIN APPLICATION
addappid(2099080)
addappid(2261880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099081, 1, "7b57425b0d967e7026d8ae7034f1318c7a5e5be3f10f15e3784b44c24aac221e")
addappid(2099082, 1, "1d4f0e534dc3b73a41629ac053e28f311b5a0c0ee503cdf226c67aeeb7d37728")
