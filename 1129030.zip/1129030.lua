-- Lua provided by RyzenAPI
-- Game: Endless Fables 4: Shadow Within

-- MAIN APPLICATION
addappid(1129030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129031, 1, "127ed737381b161e51381a005c7593224b569b972b936b36c8871d59ef79bb8a")

