-- Lua provided by RyzenAPI
-- Game: addappid(2178570)

-- MAIN APPLICATION
addappid(2178570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178572,0,"a5b5c499d9ba563e3b97a5e07d5aee0c9cfc5e2b7b3416a0578b888328dcf590")
