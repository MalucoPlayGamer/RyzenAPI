-- Lua provided by SkyAPI 
-- Game: LOGistICAL 3: Earth
addappid(672150)
addappid(672151, 1, "195b726c7665e98a714f22a87fa8577d47a19e289673f9612b6f45331d777dc4")
