-- Lua provided by RyzenAPI
-- Game: LOGistICAL 3: Earth

-- MAIN APPLICATION
addappid(672150)

-- MAIN APP DEPOTS / PACKAGES
addappid(672151, 1, "195b726c7665e98a714f22a87fa8577d47a19e289673f9612b6f45331d777dc4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
