-- Lua provided by RyzenAPI
-- Game: Quarta Amethyst

-- MAIN APPLICATION
addappid(2429870)
-- Game: addappid(2429870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429871, 1, "cf828864cfa61a8f8b0f6ec7067eada7c180d74e33627b282b336243c0270292")
addappid(2429872, 1, "3fef517d82308924710e53570c6ff94f4420efb3995f89ca3dabac6771abbc49")
addappid(2429873, 1, "f8f1f03737e1d310eee3ce38c1d400488b99859a69ee9b5f580252baf39d0c42")
