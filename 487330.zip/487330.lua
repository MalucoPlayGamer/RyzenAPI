-- Lua provided by RyzenAPI
-- Game: Totally Unbalanced

-- MAIN APPLICATION
addappid(487330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(487332,0,"9d26e50f4ad7bc57119e420afaffe108a65bfa2da96dfb6ba22a1251684d19f2")
addappid(487334,0,"2b9771b7399e8c1500e0fa2592e280f5916a089825a2d21ac7a8eca4242719ae")

