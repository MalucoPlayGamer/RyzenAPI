-- Lua provided by RyzenAPI
-- Game: Totally Unbalanced

-- MAIN APPLICATION
addappid(487330)

-- MAIN APP DEPOTS / PACKAGES
addappid(487332,0,"9d26e50f4ad7bc57119e420afaffe108a65bfa2da96dfb6ba22a1251684d19f2")
addappid(487334,0,"2b9771b7399e8c1500e0fa2592e280f5916a089825a2d21ac7a8eca4242719ae")

