-- Lua provided by RyzenAPI
-- Game: Heretical

-- MAIN APPLICATION
addappid(2877540)
-- Game: addappid(2877540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877541, 1, "a9ce0bfd6d731be4c23bc3d53755bddc74be59237e5ba9b0365f02f9d4daaa57")
