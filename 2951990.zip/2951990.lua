-- Lua provided by SkyAPI 
-- Game: AppID 2951990
addappid(2951990)
addappid(2951991, 1, "47fb2a7f5c69f478464b2dc16e22cb386f8937b69065b47c49e8e9140ea3c3f7")
addappid(2951992, 1, "11d8b1c92b160025d10ae272d231b075bb4520b3a4f7b85be57be2cd0c2d2d7a")
