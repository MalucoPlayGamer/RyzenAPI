-- Lua provided by RyzenAPI
-- Game: Dungeon & Derision

-- MAIN APPLICATION
addappid(1277100)
-- Game: addappid(1277100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277102,0,"2c2aa0dc58af1be9c3b7f2149d7e84954c2a7547f096840e2b03a68d58e7a0f9")
addappid(1277103,0,"76958dc10b64eea9dd298c75c6a9be640d9954bc018f5a1d323a094f7f2d8f66")
addappid(1277104,0,"24602d59f17e35aaad87a0bf4231f2ae4a640b131d76a62efe29c94319a73a11")
