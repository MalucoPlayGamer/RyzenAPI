-- Lua provided by RyzenAPI
-- Game: addappid(413740)

-- MAIN APPLICATION
addappid(413740)

-- MAIN APP DEPOTS / PACKAGES
addappid(413743,0,"8b8930368137ed5bb3c75b46f566bb2b16f16ed2099d123da4e8ecf56ab584f9")
