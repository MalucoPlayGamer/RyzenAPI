-- Lua provided by RyzenAPI
-- Game: Archaeology - Post-Apocalypse

-- MAIN APPLICATION
addappid(3244710)
-- Game: addappid(3244710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244711, 1, "c4f2e190af836dd0fdbb493af88a758b86c4e62559f23891eff580167b4c36f7")
