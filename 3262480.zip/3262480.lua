-- Lua provided by RyzenAPI
-- Game: 3262480

-- MAIN APPLICATION
addappid(3262480)
-- Game: addappid(3262480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262481, 1, "84b9ac366fa5c4660c75d1a97033a3e09ee84c044e1a2f94b9b1b0231eef0ad1")
