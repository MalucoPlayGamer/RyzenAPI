-- Lua provided by RyzenAPI
-- Game: JUMP! The Floor Is...

-- MAIN APPLICATION
addappid(3262480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262481, 1, "84b9ac366fa5c4660c75d1a97033a3e09ee84c044e1a2f94b9b1b0231eef0ad1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
