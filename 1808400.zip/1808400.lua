-- Lua provided by RyzenAPI
-- Game: Tag: The Power of Paint

-- MAIN APPLICATION
addappid(1808400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808401, 1, "8516e0d8540e130c0c0e90f93032dda7a3d78655c5bca78ea6e1a1bca2fe4b49")

