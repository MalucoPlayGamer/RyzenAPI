-- Lua provided by RyzenAPI
-- Game: Tag: The Power of Paint

-- MAIN APPLICATION
addappid(1808400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808401, 1, "8516e0d8540e130c0c0e90f93032dda7a3d78655c5bca78ea6e1a1bca2fe4b49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
