-- Lua provided by RyzenAPI
-- Game: Multishop Tycoon Deluxe

-- MAIN APPLICATION
addappid(568780)

-- MAIN APP DEPOTS / PACKAGES
addappid(568781,0,"a74117a3e095ce9e4a565d8d4a84830f46eaaf9af089ce74f0bbebf0c97f606c")

