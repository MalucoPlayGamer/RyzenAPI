-- Lua provided by RyzenAPI
-- Game: Destoria: The Withering

-- MAIN APPLICATION
addappid(1953960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953961, 1, "2ac8e6d43457df551289973a1c014c52f1a3c4ac73a8ad83aa92c0380e4df8b2")
addappid(1953962, 1, "be15372dc9e7bdbdbd79108ae913148381f8feeda104afbf1bf5078aeac1554e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
