-- Lua provided by RyzenAPI
-- Game: The Federal Rescue

-- MAIN APPLICATION
addappid(869340)
addappid(879720)

-- MAIN APP DEPOTS / PACKAGES
addappid(869341, 1, "ac5e8b3da997a7d66f4133b21941a856b8812f94eb098252d7ef6a9ceb1505e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
