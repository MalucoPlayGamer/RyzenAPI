-- Lua provided by RyzenAPI
-- Game: The Federal Rescue

-- MAIN APPLICATION
addappid(869340)
addappid(879720)

-- MAIN APP DEPOTS / PACKAGES
addappid(869341, 1, "ac5e8b3da997a7d66f4133b21941a856b8812f94eb098252d7ef6a9ceb1505e9")

