-- Lua provided by RyzenAPI
-- Game: Witch 4 Hotel

-- MAIN APPLICATION
addappid(2731300)
addappid(4165220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2731301, 1, "1eaf845d34cf7eb0dee18a8ae53e0abdcf53b38f2511ef8a97cc07e1ecc14784")
addappid(2731302, 1, "28e5205211f10446fa1cfd338fba4cb8d9418f639f4154115b6f9c622917bb6f")
addappid(2731303, 1, "876337e0f676959d7a345a19a44a1270149b2bb8b9b9728c19c68bbab98dae42")
addappid(3205510, 0, "5396ab773e862d880084dcdfed8a3d1d57b17160c7cac393ab730f8c59420ba3")
addappid(3407440, 0, "fa8394823c723eae10e3f9315d0001421b65fb0bca62ba935aa8adcc69cc6659")
addappid(3534180, 0, "30e096c86c5a2b83a4c07ad62355d0bceb289cec7bb8b3598bdeb941acc49dbf")

