-- Lua provided by RyzenAPI
-- Game: Game: Witch 4 Hotel

-- MAIN APPLICATION
addappid(2731300)
-- Game: addappid(2731300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731301, 1, "1eaf845d34cf7eb0dee18a8ae53e0abdcf53b38f2511ef8a97cc07e1ecc14784")
addappid(2731302, 1, "28e5205211f10446fa1cfd338fba4cb8d9418f639f4154115b6f9c622917bb6f")
addappid(2731303, 1, "876337e0f676959d7a345a19a44a1270149b2bb8b9b9728c19c68bbab98dae42")
addappid(3205510, 0, "5396ab773e862d880084dcdfed8a3d1d57b17160c7cac393ab730f8c59420ba3")
addappid(3407440, 0, "fa8394823c723eae10e3f9315d0001421b65fb0bca62ba935aa8adcc69cc6659")
addappid(3534180, 0, "30e096c86c5a2b83a4c07ad62355d0bceb289cec7bb8b3598bdeb941acc49dbf")
