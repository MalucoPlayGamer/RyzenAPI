-- Lua provided by SkyAPI 
-- Game: Planetoid
addappid(590870)
addappid(590871, 1, "c27e9d1c53286c4bf79ec4145833a3bb921dbebce8cc1b01b022475a3082d4df")
