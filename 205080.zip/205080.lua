-- Lua provided by RyzenAPI 
-- Game: BIT.TRIP FATE
addappid(205080)
addappid(205081, 1, "92b4635af08a38fad674ae4e20ea00c2dd6c37a270dd77762164ed9c6e257f55")
addappid(205083, 0, "2b69ad853d3a9177757052a6d30106e30c1095dc0082ae2e1bd44a10075c439f")
