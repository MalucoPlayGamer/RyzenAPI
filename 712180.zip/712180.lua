-- Lua provided by RyzenAPI
-- Game: Game: Mugsters

-- MAIN APPLICATION
addappid(712180)
-- Game: addappid(712180)

-- MAIN APP DEPOTS / PACKAGES
addappid(712181, 1, "ac03b41610be185253deb4af63500a718b56a1e4a7e2ce10932250289d3d52ef")
addappid(712182, 1, "645945b3220c9161db5f792c529c87e3476db872d0ef1263649af4d674ca584e")
