-- Lua provided by RyzenAPI
-- Game: The VII Enigma

-- MAIN APPLICATION
addappid(1720470)
-- Game: addappid(1720470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720472,0,"793f53a33fbdcf656958057ab9b234d352ad69c0e01951642fe139178f7b52a5")
