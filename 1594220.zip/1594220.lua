-- Lua provided by RyzenAPI 
-- Game: Big Dick at the Beach
addappid(1594220)
addappid(1594221, 1, "4fd62c8331e96257f5a9445a362b860ee603cb4b8ded5ce91216c49f975cfa3c")
addappid(1594222, 1, "d706c1191a7f5226652eb9a3d561e0d302f7dad4e1178c2703a83920a6c69447")
