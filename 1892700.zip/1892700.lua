-- Lua provided by RyzenAPI
-- Game: 1892700

-- MAIN APPLICATION
addappid(1892700)
addappid(2296670)
-- Game: addappid(1892700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892701, 1, "33bb4beca813f83671ebc79b55abfeac8c8f24e428b77325f303cb4c1e64bf5d")
