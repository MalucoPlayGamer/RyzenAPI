-- Lua provided by SkyAPI 
-- Game: Ghost Maze
addappid(2419380)
addappid(2419381, 1, "858e83553d10c88cae4b3c8f7a35a5e6fd0db899a9ac94509d651f6c30889256")
