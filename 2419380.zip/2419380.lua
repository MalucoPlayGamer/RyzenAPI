-- Lua provided by RyzenAPI
-- Game: Game: Ghost Maze

-- MAIN APPLICATION
addappid(2419380)
-- Game: addappid(2419380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419381, 1, "858e83553d10c88cae4b3c8f7a35a5e6fd0db899a9ac94509d651f6c30889256")
