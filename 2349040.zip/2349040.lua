-- Lua provided by SkyAPI 
-- Game: Dinky Guardians
addappid(2349040)
addappid(2349041, 1, "d1a16751d2bab01f018d5e1bb272ddb75c738c71fc95476e7e0cb34aece690e6")
addappid(2349042, 1, "d5ca7ea8235a6cb76b8b9e328390da9bf24a8d46fb0c182dafaa89930231958b")
addappid(2349043, 1, "b602becddcfc9f851778b12b80201cfce7276c00d177c750ac90ab36ad2a6f5f")
