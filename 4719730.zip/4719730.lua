-- Lua provided by RyzenAPI
-- Game: 4719730

-- MAIN APPLICATION
addappid(4719730)
-- Game: addappid(4719730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4719731, 1, "d5fc8d13704085760b7e30bba2fe8a0095dc26dcc64a88cd2381cd4ab8d5f85d")
