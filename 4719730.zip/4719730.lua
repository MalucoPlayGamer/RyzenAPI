-- Lua provided by RyzenAPI
-- Game: Giant Waifu Wash Simulator 💦

-- MAIN APPLICATION
addappid(4719730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4719731, 1, "d5fc8d13704085760b7e30bba2fe8a0095dc26dcc64a88cd2381cd4ab8d5f85d")

