-- Lua provided by RyzenAPI
-- Game: PUSSY 4

-- MAIN APPLICATION
addappid(1750060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750061, 1, "f966d2813b03498cf5383f0cef1f7a1497dd025e5ad2fa241edab5ca23df80f6")
