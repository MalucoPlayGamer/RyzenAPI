-- Lua provided by RyzenAPI
-- Game: Grisaia Phantom Trigger Vol.6

-- MAIN APPLICATION
addappid(1039970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1039971, 1, "9a7cd8e8c907cd4b92b5df06bc602b3deacb64b2ff60452f10501bfaab5b0801")
addappid(1039972, 1, "9f7b1c168f19435f94a564bb0d982b3324881c008d8b050bdf4aafd1202127d7")

