-- Lua provided by RyzenAPI
-- Game: Game: AppID 108100

-- MAIN APPLICATION
addappid(108100)
-- Game: addappid(108100)

-- MAIN APP DEPOTS / PACKAGES
addappid(108101, 1, "64484e364d6f70f3cd8c24429efd4da0f7e18ade94fdc15198e37065aaf62e1e")
