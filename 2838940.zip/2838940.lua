-- Lua provided by RyzenAPI
-- Game: Game: 神魔决之江湖行

-- MAIN APPLICATION
addappid(2838940)
addappid(3413690)
-- Game: addappid(2838940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838941, 1, "3bac7548c85b7fadfa6746b536af989a485506fe800f4ea0aac28a0858ca5036")
