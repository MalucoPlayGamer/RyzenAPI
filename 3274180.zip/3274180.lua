-- Lua provided by RyzenAPI
-- Game: Beat Saber - Monstercat Mixtape 2 - Grant & Ellis - "Dead Man Walking"

-- MAIN APPLICATION
addappid(3274180)
-- Game: addappid(3274180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274180,0,"1d0b450722c6adb4092aa07613f775b74ae684219bc72d82d3cdd355c75efc1b")
