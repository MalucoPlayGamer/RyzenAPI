-- Lua provided by RyzenAPI
-- Game: addappid(2641480)

-- MAIN APPLICATION
addappid(2641480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641481, 1, "e22399c7795c87872aee67061e7ec41ae3e3b70ab9ab8b210859a54f99bcd17d")
