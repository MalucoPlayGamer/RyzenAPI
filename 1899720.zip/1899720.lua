-- Lua provided by RyzenAPI
-- Game: AppID 1899720

-- MAIN APPLICATION
addappid(1899720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899721, 1, "380abebcdabd5051e455b9b549a1a824df02d7df5f95482f36449de9d548bc94")
