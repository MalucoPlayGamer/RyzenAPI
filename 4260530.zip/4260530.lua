-- Lua provided by RyzenAPI
-- Game: addappid(4260530)

-- MAIN APPLICATION
addappid(4260530)

-- MAIN APP DEPOTS / PACKAGES
addappid(4260531, 1, "1d52269a782113dfe959673c692f453d605d1bd70aeaf5fc099ab3cd6f409323")
