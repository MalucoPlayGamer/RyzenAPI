-- Lua provided by RyzenAPI
-- Game: Game: WARRIORS OROCHI 4

-- MAIN APPLICATION
addappid(831560)
-- Game: addappid(831560)

-- MAIN APP DEPOTS / PACKAGES
addappid(831561, 1, "e8477176be994e781ee73ddbf0ee375c2adf14cd62e4ac2932de159a841db198")
