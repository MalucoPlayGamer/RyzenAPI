-- 831560's Lua and Manifest Created by Hubcap Manifest
-- WARRIORS OROCHI 4
-- Created: April 25, 2026 at 02:33:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 74
-- Total DLCs: 78
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(831560, 1, "e133e1d49f4c0bd1323d54eac30e5b71a391bdea4563066903f03fb9fd9b146e") -- WARRIORS OROCHI 4
-- MAIN APP DEPOTS
addappid(831561, 1, "e8477176be994e781ee73ddbf0ee375c2adf14cd62e4ac2932de159a841db198") -- NAGA Content
setManifestid(831561, "1575399759387378980", 17387788511)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Bonus Mount Pegasus (AppID: 933460)
addappid(933460)
addtoken(933460, "9279609088275084154")
addappid(933460, 1, "0735b7dea9b8a7ff6197e94c90d822d6cfd7a9ea2fc6700517747264b2b0daf1") -- Bonus Mount Pegasus - Depot 933460
setManifestid(933460, "3695408869805386196", 15455960)
-- Bonus Mount Unicorn (AppID: 933470)
addappid(933470)
addtoken(933470, "6442844779032101448")
addappid(933470, 1, "fad4246ba5ef1b11fbf068d6d9fc2f8b95e98c2daf78979ec841ee1db99f1228") -- Bonus Mount Unicorn - Depot 933470
setManifestid(933470, "6447003142648122141", 15419736)
-- Bonus Costumes for Xu Shu and Mitsunari Ishida and Da Ji (AppID: 933471)
addappid(933471)
addtoken(933471, "16837142266219510621")
addappid(933471, 1, "3f81a963655b415c0d1293437157d1b9203bfe6621af74599b0aa2bce3b74300") -- Bonus Costumes for Xu Shu and Mitsunari Ishida and Da Ji - Depot 933471
setManifestid(933471, "595446478022387026", 58697528)
-- WARRIORS OROCHI 4 - Bonus Costume for Wang Yuanji (AppID: 933490)
addappid(933490)
addappid(933490, 1, "1412f8846c6281e321fa601919eb5ab9f4a41dc100ff1a5e276d9b9e1bce357a") -- WARRIORS OROCHI 4 - Bonus Costume for Wang Yuanji - Bonus Costume for Wang Yuanji Content
setManifestid(933490, "7085614660748490817", 21724292)
-- WARRIORS OROCHI 4 - Bonus Costume for Wang Yi (AppID: 933491)
addappid(933491)
addtoken(933491, "2510814798471980565")
addappid(933491, 1, "24f02afbbf743240decf12bc2e673788bc520c02cb8a16e1000c4454826994c7") -- WARRIORS OROCHI 4 - Bonus Costume for Wang Yi - Depot 933491
setManifestid(933491, "727657253427806861", 21467408)
-- WARRIORS OROCHI 4 - Bonus Costume for Lady Hayakawa (AppID: 933492)
addappid(933492)
addtoken(933492, "13669332657106836264")
addappid(933492, 1, "1f390a7cb5a538761834f8ebcff02184359cafd4a1da0a5c5fc2250c7808ed53") -- WARRIORS OROCHI 4 - Bonus Costume for Lady Hayakawa - Depot 933492
setManifestid(933492, "3579074775605536113", 22071756)
-- WARRIORS OROCHI 4 - Bonus Costume for Xingcai (AppID: 933493)
addappid(933493)
addtoken(933493, "13896167761093581552")
addappid(933493, 1, "a4eb8ebdeb7fd3f33fbd229f9da8230a6be4cd7561a65e271106c9ef71deea95") -- WARRIORS OROCHI 4 - Bonus Costume for Xingcai - Depot 933493
setManifestid(933493, "8996713594365027854", 22004444)
-- WARRIORS OROCHI 4 - Bonus Costume for Guo Jia (AppID: 933500)
addappid(933500)
addtoken(933500, "225271796409487172")
addappid(933500, 1, "bbce039e87fef7c37aba7a4435dad5f5bf7f05971edcd50eea310bc0259a42ce") -- WARRIORS OROCHI 4 - Bonus Costume for Guo Jia - Depot 933500
setManifestid(933500, "9154636202427136212", 25044920)
-- WARRIORS OROCHI 4 - Bonus Costume for Yoshitsugu Otani (AppID: 933501)
addappid(933501)
addtoken(933501, "16165073147105620311")
addappid(933501, 1, "d9adf98e03cc6f70f9080eb28dfbd0f636c9f30e1470f8ee240551239e114974") -- WARRIORS OROCHI 4 - Bonus Costume for Yoshitsugu Otani - Depot 933501
setManifestid(933501, "7094625463209975537", 21535636)
-- WARRIORS OROCHI 4 - Bonus Costume for Takatora Todo (AppID: 933502)
addappid(933502)
addtoken(933502, "14300075965904469837")
addappid(933502, 1, "dc40f4f6ad1edad6b1090d234157c8054fba631fa8aef34dbc5b7e721b8fd5fb") -- WARRIORS OROCHI 4 - Bonus Costume for Takatora Todo - Depot 933502
setManifestid(933502, "6226699749628175990", 21913188)
-- Bonus 3 Weapons (AppID: 933503)
addappid(933503)
addtoken(933503, "185799311073323653")
addappid(933503, 1, "f59c42a32f57f6362eb9d8c41d19d48b5e46f5057608bf838c8bed0a2df7476e") -- Bonus 3 Weapons - Depot 933503
setManifestid(933503, "7425898434867567453", 8093436)
-- Special Costumes Pack 1 (AppID: 933507)
addappid(933507)
addtoken(933507, "14501482262133531908")
addappid(933507, 1, "a03edf0943ea688517d598ddaeed7cabafa0b10c1bb381ee76037cbba27b66d6") -- Special Costumes Pack 1 - Depot 933507
setManifestid(933507, "1022311464769533368", 111682772)
-- Special Mounts Pack 1 (AppID: 933508)
addappid(933508)
addtoken(933508, "1433903658582379655")
addappid(933508, 1, "59a0da3079c1d99dc9e78b4259645843e938d45f9499307eedddd632817aac87") -- Special Mounts Pack 1 - Depot 933508
setManifestid(933508, "7681463095468132453", 28753136)
-- Legendary Costumes Wei Pack 1 (AppID: 933509)
addappid(933509)
addappid(933509, 1, "66142b8871e5ad978b24623ab5ae96306c6a23e10e20b963708075a140459c7d") -- Legendary Costumes Wei Pack 1 - Legendary Costumes Wei Pack 1 Content
setManifestid(933509, "5221971436192068895", 179476312)
-- WARRIORS OROCHI 4 - Legendary Costumes Wei Pack 2 (AppID: 933510)
addappid(933510)
addappid(933510, 1, "77bb1805984d0e37b6ce83c7084a48f1dceb1a00fff5f07d4419f44cae5b2101") -- WARRIORS OROCHI 4 - Legendary Costumes Wei Pack 2 - WARRIORS OROCHI 4 - Legendary Costumes Wei Set 2 Content
setManifestid(933510, "752536519009973009", 179653516)
-- WARRIORS OROCHI 4 - Legendary Costumes Shu Pack 1 (AppID: 933511)
addappid(933511)
addappid(933511, 1, "4728573505a17b7b646e02b89cac0af435f8feaa544c18484221e077aa88cbb8") -- WARRIORS OROCHI 4 - Legendary Costumes Shu Pack 1 - WARRIORS OROCHI 4 - Legendary Costumes Shu Pack 1 Content
setManifestid(933511, "5861627322900305010", 197194976)
-- WARRIORS OROCHI 4 - Legendary Costumes Shu Pack 2 (AppID: 933512)
addappid(933512)
addappid(933512, 1, "94cdda7fa1f15d44eac879b470fd109748178bb291647e8e4fb13cc7a8e851a2") -- WARRIORS OROCHI 4 - Legendary Costumes Shu Pack 2 - WARRIORS OROCHI 4 - Legendary Costumes Shu Pack 2 Content
setManifestid(933512, "5501681902357953663", 196721120)
-- WARRIORS OROCHI 4 - Legendary Costumes Wu Pack 1 (AppID: 933520)
addappid(933520)
addappid(933520, 1, "b139279cbaf261841f15fad53e564315f4d91d550483e16c1585c326f976bf30") -- WARRIORS OROCHI 4 - Legendary Costumes Wu Pack 1 - WARRIORS OROCHI 4 - Legendary Costumes Wu Set 1 Content
setManifestid(933520, "4381741010691993329", 161991036)
-- WARRIORS OROCHI 4 - Legendary Costumes Wu Pack 2 (AppID: 933521)
addappid(933521)
addappid(933521, 1, "f7e803ca7875d15be8618e732bdb82e16770f22b6442e1f3cb1e09ec683b86c7") -- WARRIORS OROCHI 4 - Legendary Costumes Wu Pack 2 - WARRIORS OROCHI 4 - Legendary Costumes Wu Pack 2 Content
setManifestid(933521, "6554182369921654031", 179635320)
-- WARRIORS OROCHI 4 - Legendary Costumes Jin Pack (AppID: 933522)
addappid(933522)
addappid(933522, 1, "cb78261ed2eeb2eba74e96764a4b68c2c1553d34a2fa64f11363491b2965098d") -- WARRIORS OROCHI 4 - Legendary Costumes Jin Pack - WARRIORS OROCHI 4 - Legendary Costumes Jin Pack Content
setManifestid(933522, "3694166646438163845", 212870232)
-- WARRIORS OROCHI 4 - Legendary Costumes Others Pack (AppID: 933523)
addappid(933523)
addappid(933523, 1, "6d953620066db0ebc611baf2f6ce7757c1c78561f0a3f183093967961269563e") -- WARRIORS OROCHI 4 - Legendary Costumes Others Pack - WARRIORS OROCHI 4 - Legendary Costumes Others Pack Content
setManifestid(933523, "4560243864074023863", 179637052)
-- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 1 (AppID: 933525)
addappid(933525)
addappid(933525, 1, "032476a2a65b779452fdd94896a2b417c03eba39e2a7745103d78d0486296c15") -- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 1 - WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 1 Content
setManifestid(933525, "6614388352385331663", 198117224)
-- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 2 (AppID: 933526)
addappid(933526)
addappid(933526, 1, "471242730a02af1ac613743a9be91950f71299fd53f5ff3bc8e423f351029fdc") -- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 2 - WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 2 Content
setManifestid(933526, "411170748926144253", 198127264)
-- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 3 (AppID: 933527)
addappid(933527)
addappid(933527, 1, "7e4e9a01036b1d11035771d270945dbae1f6a0d2066d89522ba761f0514cdf8b") -- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 3 - WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 3 Content
setManifestid(933527, "4807954965749631739", 198120384)
-- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 4 (AppID: 933528)
addappid(933528)
addappid(933528, 1, "5eeffbed951d3fd1ba6a61ce8ddc091bb2284d482d140bad42cebcaa5995a9d7") -- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 4 - WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 4 Content
setManifestid(933528, "6291776222734471069", 215709172)
-- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 5 (AppID: 933529)
addappid(933529)
addappid(933529, 1, "44b6f8bc39e68131c903078448d05dd4d27893fd94378e0ff3d369b55f621820") -- WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 5 - WARRIORS OROCHI 4 - Legendary Costumes Samurai Warriors Pack 5 Content
setManifestid(933529, "1059842915583896323", 198208504)
-- WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 1 (AppID: 933530)
addappid(933530)
addappid(933530, 1, "672c8bd00026bb6c630644c0274f0264753d2114614b91479d2777801dec9f60") -- WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 1 - WARRIORS OROCHI 4 - Legendary Costumes Orochi Set 1 Content
setManifestid(933530, "8700779756030344970", 155959384)
-- WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 2 (AppID: 933531)
addappid(933531)
addappid(933531, 1, "a6d33c84b6a97c821f1c96b78a6e6becef1d002e8cbb4f43e9b04714db2a92c0") -- WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 2 - WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 2 Content
setManifestid(933531, "8448895222853987045", 155939860)
-- WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 3 (AppID: 933532)
addappid(933532)
addappid(933532, 1, "0648f430d7418ae18e09cde0dea4f781afa300d71b07c7633818ef7dd9961444") -- WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 3 - WARRIORS OROCHI 4 - Legendary Costumes Orochi Pack 3 Content
setManifestid(933532, "5424533003415356909", 194074392)
-- WARRIORS OROCHI 4 - Legendary Weapons Wei Pack 1 (AppID: 933533)
addappid(933533)
addappid(933533, 1, "1142a199c20c6f738a9d574dfab29202507fdcad78a7e1cb5b46d61255394346") -- WARRIORS OROCHI 4 - Legendary Weapons Wei Pack 1 - WARRIORS OROCHI 4 - Legendary Weapons Wei Set 1 Content
setManifestid(933533, "5090004872417118531", 19318912)
-- WARRIORS OROCHI 4 - Legendary Weapons Wei Pack 2 (AppID: 933534)
addappid(933534)
addappid(933534, 1, "493855e7d7642ae6b59ab55f6cce3845a7af225b044f044b408ab23144ad527c") -- WARRIORS OROCHI 4 - Legendary Weapons Wei Pack 2 - WARRIORS OROCHI 4 - Legendary Weapons Wei Set 2 Content
setManifestid(933534, "2172525684541679693", 20151192)
-- WARRIORS OROCHI 4 - Legendary Weapons Shu Pack 1 (AppID: 933535)
addappid(933535)
addappid(933535, 1, "c0ce527e0ca8ee04a68295bef579e9f02c7af70118399a4f3f4f4a16559a864b") -- WARRIORS OROCHI 4 - Legendary Weapons Shu Pack 1 - WARRIORS OROCHI 4 - Legendary Weapons Shu Set 1 Content
setManifestid(933535, "8503581893356711709", 20261604)
-- WARRIORS OROCHI 4 - Legendary Weapons Shu Pack 2 (AppID: 933536)
addappid(933536)
addappid(933536, 1, "13d2ff1c48957306f40353e0035b5d1fc44b0baba4565e77068a3f42fc9b3a7e") -- WARRIORS OROCHI 4 - Legendary Weapons Shu Pack 2 - WARRIORS OROCHI 4 - Legendary Weapons Shu Set 2 Content
setManifestid(933536, "1725006059811635742", 17578660)
-- WARRIORS OROCHI 4 - Legendary Weapons Wu Pack 1 (AppID: 933537)
addappid(933537)
addappid(933537, 1, "1ad878552bde51a09d4c3aa9ce05616be78908455a8a9132a3dad6dea2c9bb65") -- WARRIORS OROCHI 4 - Legendary Weapons Wu Pack 1 - WARRIORS OROCHI 4 - Legendary Weapons Wu Set 1 Content
setManifestid(933537, "6147878196204015202", 13410912)
-- WARRIORS OROCHI 4 - Legendary Weapons Wu Pack 2 (AppID: 933538)
addappid(933538)
addappid(933538, 1, "3d1f464f19dbb5b77d6afcdf5c3528f825fb2e4d52e9f1ddcfc96ec6c87ad096") -- WARRIORS OROCHI 4 - Legendary Weapons Wu Pack 2 - WARRIORS OROCHI 4 - Legendary Weapons Wu Set 2 Content
setManifestid(933538, "705608579724593092", 21377660)
-- WARRIORS OROCHI 4 - Legendary Weapons Jin Pack (AppID: 933539)
addappid(933539)
addappid(933539, 1, "464af5704ff766505d9ce5e4950c26a1175b696c846281379dddb59cefa7197e") -- WARRIORS OROCHI 4 - Legendary Weapons Jin Pack - WARRIORS OROCHI 4 - Legendary Weapons Jin Set Content
setManifestid(933539, "7551287735653302682", 18970744)
-- WARRIORS OROCHI 4 - Legendary Weapons Others Pack (AppID: 933550)
addappid(933550)
addappid(933550, 1, "47775a786fa8ceb5329b14d9d9cef013664aa0f36282a7b661fff74a7c07b4f5") -- WARRIORS OROCHI 4 - Legendary Weapons Others Pack - WARRIORS OROCHI 4 - Legendary Weapons Others Set Content
setManifestid(933550, "8710753784933905617", 15681440)
-- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 1 (AppID: 933551)
addappid(933551)
addappid(933551, 1, "86b611b0bf9b81da97045fd10729a84964450bff489b5dbe44ab2686220582a8") -- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 1 - WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Set 1 Content
setManifestid(933551, "8533740086796536254", 25875768)
-- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 2 (AppID: 933552)
addappid(933552)
addappid(933552, 1, "b74c0eb934efde91a7319bd8fa6e037da521b09b61853da1e2fc7b12220a3c91") -- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 2 - WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Set 2 Content
setManifestid(933552, "4410226657108711112", 26546732)
-- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 3 (AppID: 933553)
addappid(933553)
addappid(933553, 1, "5b18218da49f2c504047d4aef0904c9bf3770e3fd901acb82dd145e542035187") -- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 3 - WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Set 3 Content
setManifestid(933553, "1179004644767355363", 21823568)
-- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 4 (AppID: 933554)
addappid(933554)
addappid(933554, 1, "cccff9f75c71235e1dc9938dd377dc003190ceaa9bf5ad0ed778caf56d2c3f6e") -- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 4 - WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Set 4 Content
setManifestid(933554, "7916144518619786431", 21942292)
-- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 5 (AppID: 933555)
addappid(933555)
addappid(933555, 1, "e997e23174982354576af8e250750d0220b470506929d9b548bc42ad7e0c7389") -- WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Pack 5 - WARRIORS OROCHI 4 - Legendary Weapons Samurai Warriors Set 5 Content
setManifestid(933555, "3639082364840437411", 29102272)
-- WARRIORS OROCHI 4 - Legendary Weapons Orochi Pack 1 (AppID: 933556)
addappid(933556)
addappid(933556, 1, "dca8c862bcf9fcfa1f4540e16f8ede638681cb2eaa9ae66810727762605d7797") -- WARRIORS OROCHI 4 - Legendary Weapons Orochi Pack 1 - WARRIORS OROCHI 4 - Legendary Weapons Orochi Set 1 Content
setManifestid(933556, "9177063915911447957", 20064484)
-- WARRIORS OROCHI 4 - Legendary Weapons Orochi Pack 2 (AppID: 933557)
addappid(933557)
addappid(933557, 1, "f6efbcabc090c269f2dc0aa6bf46320b363bea3e31d9c9e496cbdeb6210b0557") -- WARRIORS OROCHI 4 - Legendary Weapons Orochi Pack 2 - WARRIORS OROCHI 4 - Legendary Weapons Orochi Set 2 Content
setManifestid(933557, "9118731930997467458", 23249304)
-- WARRIORS OROCHI 4 - Legendary Weapons Orochi Pack 3 (AppID: 933558)
addappid(933558)
addappid(933558, 1, "cb07374f0e9365d451c4836e31e9cc092c53f6b74832c86cf034f3bc48a7578e") -- WARRIORS OROCHI 4 - Legendary Weapons Orochi Pack 3 - WARRIORS OROCHI 4 - Legendary Weapons Orochi Set 3 Content
setManifestid(933558, "3755621697103117865", 34819516)
-- WARRIORS OROCHI 4 - Legendary Mounts Pack (AppID: 933560)
addappid(933560)
addappid(933560, 1, "29de99fa46395455d463f5b078e3fa64ae58b39530b9387493a28d6848eaad2c") -- WARRIORS OROCHI 4 - Legendary Mounts Pack - WARRIORS OROCHI 4 - Legendary Mounts Set Content
setManifestid(933560, "6691205908242774994", 124391436)
-- WARRIORS OROCHI 4 - Special Costumes Pack 2 (AppID: 933564)
addappid(933564)
addtoken(933564, "4925623087674307623")
addappid(933564, 1, "62a21196bb78f96ae45dfec7efc927d780c5cfbd46dd22f85a1d8ec50de249ce") -- WARRIORS OROCHI 4 - Special Costumes Pack 2 - Depot 933564
setManifestid(933564, "4332637011724171853", 85365180)
-- WARRIORS OROCHI 4 - Special Mounts Pack 2 (AppID: 933565)
addappid(933565)
addtoken(933565, "14761303738508550599")
addappid(933565, 1, "e5ae35bbe2abfcec96e7016e4283b3e89b090c4da12a604348a3966362c93fdb") -- WARRIORS OROCHI 4 - Special Mounts Pack 2 - Depot 933565
setManifestid(933565, "8241703592587049394", 17520948)
-- WARRIORS OROCHI 4 - Challenge Modes Rampage and Bridge Melee (AppID: 933566)
addappid(933566)
addappid(933566, 1, "4cdc3a5347ae49435e299e2bcd1cd349cfea31d15a5497f82b76ec845d7639cf") -- WARRIORS OROCHI 4 - Challenge Modes Rampage and Bridge Melee - WARRIORS OROCHI 4 - Challenge Modes &quot;Rampage&quot; and &quot;Bridge Melee&quot; Content
setManifestid(933566, "3595373978156182546", 3575464)
-- WARRIORS OROCHI 4 - Sacred Treasures Pack 1 (AppID: 933567)
addappid(933567)
addtoken(933567, "10600892394346179935")
addappid(933567, 1, "813f53d0564b4047262f14af73b6b3338d38659d158e37075455d542979fe18e") -- WARRIORS OROCHI 4 - Sacred Treasures Pack 1 - Depot 933567
setManifestid(933567, "1607203995446560588", 3575996)
-- WARRIORS OROCHI 4 - Scenario Pack 1 (AppID: 933568)
addappid(933568)
addtoken(933568, "4456574890628891766")
addappid(933568, 1, "b3c55223f3281f0211143a73b23e47af9e4f11d3606c0076186d5bc74a68a25e") -- WARRIORS OROCHI 4 - Scenario Pack 1 - Depot 933568
setManifestid(933568, "5364317348362249013", 3962624)
-- WARRIORS OROCHI 4 - BGM Pack 1 (AppID: 933569)
addappid(933569)
addtoken(933569, "6359814379061023043")
addappid(933569, 1, "d686c3a74eec74e474f3b661ef51f7a251409e21dad0426e1730b41982953375") -- WARRIORS OROCHI 4 - BGM Pack 1 - Depot 933569
setManifestid(933569, "3976142155635338119", 26233728)
-- WARRIORS OROCHI 4 - -Force 20th Anniversary Concert BGM Pack (AppID: 933570)
addappid(933570)
addappid(933570, 1, "73501b386f9ea9eccd6ce966f58651c8df4fd49e846eff95e461d689706e6560") -- WARRIORS OROCHI 4 - -Force 20th Anniversary Concert BGM Pack - WARRIORS OROCHI 4 - ω-Force 20th Anniversary Concert BGM Set Content
setManifestid(933570, "7894145577431210477", 159672092)
-- WARRIORS OROCHI 4 - Sacred Treasures Pack 2 (AppID: 933571)
addappid(933571)
addappid(933571, 1, "cc621ed62d15f2656c32c1c570a4317c91a55ea13f01a51b8df70b4f1fa44e10") -- WARRIORS OROCHI 4 - Sacred Treasures Pack 2 - WARRIORS OROCHI 4 - Sacred Treasures Pack 2 Content
setManifestid(933571, "3851912247490409553", 3581496)
-- WARRIORS OROCHI 4 - Scenario Pack 2 (AppID: 933572)
addappid(933572)
addappid(933572, 1, "5f97aa5a53a963d247864ccf5050d670efe3c5b48f6f4f6a4dc499c8310d3102") -- WARRIORS OROCHI 4 - Scenario Pack 2 - WARRIORS OROCHI 4 - Scenario Pack 2 Content
setManifestid(933572, "6640450811106529897", 3985532)
-- WARRIORS OROCHI 4 - BGM Pack 2 (AppID: 933573)
addappid(933573)
addappid(933573, 1, "900d5fcd3b00e9697e1736f699d7321af19449c147babeb77deb4abc496e3d52") -- WARRIORS OROCHI 4 - BGM Pack 2 - WARRIORS OROCHI 4 - BGM Pack 2 Content
setManifestid(933573, "624444892078865711", 25649244)
-- WARRIORS OROCHI 4 - Bonus Costumes for Xu Shu (AppID: 978160)
addappid(978160)
addappid(978160, 1, "d5fede863e40e924b566fe85dbf421a7be1d1f0e1977b4f7281596df5643e792") -- WARRIORS OROCHI 4 - Bonus Costumes for Xu Shu - WARRIORS OROCHI 4 - Bonus Costumes for Xu Shu
setManifestid(978160, "5010593326994833905", 22086912)
-- WARRIORS OROCHI 4 - Bonus Costumes for Mitsunari Ishida (AppID: 978161)
addappid(978161)
addappid(978161, 1, "b9561856baccf8886fc5067e70696114ff105acf74ffe3d465fec98ae12b23aa") -- WARRIORS OROCHI 4 - Bonus Costumes for Mitsunari Ishida - WARRIORS OROCHI 4 - Bonus Costumes for Mitsunari Ishida
setManifestid(978161, "7031014893310562477", 21380276)
-- WARRIORS OROCHI 4 - Bonus Costumes for Da Ji (AppID: 978162)
addappid(978162)
addappid(978162, 1, "de8fb2a174ff3d5d178465d1a2a8c4d04ccf4232bfa783b6eb361617f0013fc0") -- WARRIORS OROCHI 4 - Bonus Costumes for Da Ji - WARRIORS OROCHI 4 - Bonus Costumes for Da Ji
setManifestid(978162, "120315629281981006", 22400544)
-- WARRIORS OROCHI 4 The Ultimate Upgrade Pack (AppID: 1147480)
addappid(1147480)
addappid(1147480, 1, "c110a707ba474e78fec39dd54574f413101a8cd53ec7929d1c4caedbaae58342") -- WARRIORS OROCHI 4 The Ultimate Upgrade Pack - WARRIORS OROCHI 4 - Gaia デポ
setManifestid(1147480, "6173872705472517861", 4334064187)
-- WARRIORS OROCHI 4 Ultimate - Bonus Costume for Ryu Hayabusa (AppID: 1176612)
addappid(1176612)
addappid(1176612, 1, "3278431ee40b97fef4a39c4d557693a6a6353905834ae773cceb5a5b2db3bad0") -- WARRIORS OROCHI 4 Ultimate - Bonus Costume for Ryu Hayabusa - WARRIORS OROCHI 4 Ultimate - Bonus Costume for Ryu Hayabusa デポ
setManifestid(1176612, "1617246669501531832", 13734440)
-- WARRIORS OROCHI 4 Ultimate - Legendary Costumes OROCHI Pack 4 (AppID: 1176613)
addappid(1176613)
addappid(1176613, 1, "1ffe89b244821b95875a52e49cc2fa8b1587b3c925ed72b90c6285deb14b086e") -- WARRIORS OROCHI 4 Ultimate - Legendary Costumes OROCHI Pack 4 - WARRIORS OROCHI 4 Ultimate - Legendary Costumes OROCHI Pack 4 デポ
setManifestid(1176613, "3344347265224619689", 100077100)
-- WARRIORS OROCHI 4 Ultimate - Special Costume for Hades (AppID: 1176614)
addappid(1176614)
addappid(1176614, 1, "7e91477853a75217aceb7945f0e2de64915c36e6a6057a933ed9955fd4f19593") -- WARRIORS OROCHI 4 Ultimate - Special Costume for Hades - WARRIORS OROCHI 4 Ultimate - Special Costume for Hades デポ
setManifestid(1176614, "4704474081902795721", 26362908)
-- WARRIORS OROCHI 4 Ultimate - Special Costume for Yang Jian (AppID: 1176615)
addappid(1176615)
addappid(1176615, 1, "6670f13620afd2c3f315ff41c56cb95556837977a81727b755f0351762145ad4") -- WARRIORS OROCHI 4 Ultimate - Special Costume for Yang Jian - WARRIORS OROCHI 4 Ultimate - Special Costume for Yang Jian デポ
setManifestid(1176615, "4031759667091839954", 25973088)
-- WARRIORS OROCHI 4 Ultimate - Sacred Treasure Garm (AppID: 1176616)
addappid(1176616)
addappid(1176616, 1, "3c33c935b0bad2032062d9346303d65e38d515dc06c58eb989023070b6f01c01") -- WARRIORS OROCHI 4 Ultimate - Sacred Treasure Garm - WARRIORS OROCHI 4 Ultimate - Sacred Treasure `Garm` デポ
setManifestid(1176616, "8003947422501915318", 7184704)
-- WARRIORS OROCHI 4 Ultimate - Sacred Treasure World Tree Bident (AppID: 1176617)
addappid(1176617)
addappid(1176617, 1, "e12c740ed9c636ee5c754f5bb909d528c2ab77f355a06ba725894c66d7e4673b") -- WARRIORS OROCHI 4 Ultimate - Sacred Treasure World Tree Bident - WARRIORS OROCHI 4 Ultimate - Sacred Treasure `World Tree Bident` デポ
setManifestid(1176617, "4495768951958377921", 7184704)
-- WARRIORS OROCHI 4 Ultimate - Legendary Weapons OROCHI Pack 4 (AppID: 1176618)
addappid(1176618)
addappid(1176618, 1, "13d8fa0b027824eee3e751c901b16827a041bcc9f5516e0c488af3f45eebde80") -- WARRIORS OROCHI 4 Ultimate - Legendary Weapons OROCHI Pack 4 - WARRIORS OROCHI 4 Ultimate - Legendary Weapons OROCHI Pack 4 デポ
setManifestid(1176618, "21201295156945789", 25061152)
-- WARRIORS OROCHI 4 Ultimate - Series BGM Pack (AppID: 1176619)
addappid(1176619)
addappid(1176619, 1, "7b8bf8429706b360adc87bfd7fd8672485096445787d2b742af90e5c08d87dd1") -- WARRIORS OROCHI 4 Ultimate - Series BGM Pack - WARRIORS OROCHI 4 Ultimate - Series BGM Pack デポ
setManifestid(1176619, "8681517802757346914", 60306012)
-- WARRIORS OROCHI 4 Ultimate - Weapon Feline Paws (AppID: 1176621)
addappid(1176621)
addappid(1176621, 1, "0cf8faa9b21ced0f3976f0ed150a3c7994fef7ce0337fed5709168f0e0495b9c") -- WARRIORS OROCHI 4 Ultimate - Weapon Feline Paws - WARRIORS OROCHI 4 Ultimate - Weapon `Feline Paws デポ
setManifestid(1176621, "6256689599794473173", 11607876)
-- WARRIORS OROCHI 4 Ultimate - Weapon Traffic Signal (AppID: 1176622)
addappid(1176622)
addappid(1176622, 1, "6cbd3570bba472c3ef219edafc8832ac637563b0e4d600e5b625eb988ffdf2c6") -- WARRIORS OROCHI 4 Ultimate - Weapon Traffic Signal - WARRIORS OROCHI 4 Ultimate - Weapon `Traffic Signal` デポ
setManifestid(1176622, "7243289746711570021", 10884832)
-- WARRIORS OROCHI 4 Ultimate - Weapon Fork (AppID: 1176623)
addappid(1176623)
addappid(1176623, 1, "17e5a774d054a88796d6555b8153b64705422150ff6162c3f9c01c50f327421c") -- WARRIORS OROCHI 4 Ultimate - Weapon Fork - WARRIORS OROCHI 4 Ultimate - Weapon `Fork` デポ
setManifestid(1176623, "1704228327576068055", 8750388)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(933504) -- Season Pass
addappid(933505) -- Special Costumes Pack
addappid(933506) -- Special Mounts Pack
addappid(933524) -- WARRIORS OROCHI 4 - Legendary Costumes Pack
addappid(933561) -- WARRIORS OROCHI 4 - Sacred Treasures Pack
addappid(933562) -- WARRIORS OROCHI 4 - Scenario Pack
addappid(933563) -- WARRIORS OROCHI 4 - BGM Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(831563) -- Depot 831563 (empty depot)