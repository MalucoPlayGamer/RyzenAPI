-- Lua provided by RyzenAPI
-- Game: AppID 723880

-- MAIN APPLICATION
addappid(723880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(723881, 1, "a85f48a0a945a4de7c2894bbeb83dd6752aab9dd043b4eeb747f9fe2d76f0f7e")

