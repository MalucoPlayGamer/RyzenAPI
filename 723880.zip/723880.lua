-- Lua provided by RyzenAPI
-- Game: 723880

-- MAIN APPLICATION
addappid(723880)
-- Game: addappid(723880)

-- MAIN APP DEPOTS / PACKAGES
addappid(723881, 1, "a85f48a0a945a4de7c2894bbeb83dd6752aab9dd043b4eeb747f9fe2d76f0f7e")
