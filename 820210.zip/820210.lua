-- Lua provided by RyzenAPI
-- Game: 820210

-- MAIN APPLICATION
addappid(820210)
-- Game: addappid(820210)

-- MAIN APP DEPOTS / PACKAGES
addappid(820211, 1, "f4ce5e3bc35d4ee61d771aafe2296740f49332650c5c13b22fd210106957f0ac")
