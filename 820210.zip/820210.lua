-- Lua provided by RyzenAPI
-- Game: ASHI WASH

-- MAIN APPLICATION
addappid(820210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(820211, 1, "f4ce5e3bc35d4ee61d771aafe2296740f49332650c5c13b22fd210106957f0ac")

