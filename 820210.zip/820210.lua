-- Lua provided by SkyAPI 
-- Game: AppID 820210
addappid(820210)
addappid(820211, 1, "f4ce5e3bc35d4ee61d771aafe2296740f49332650c5c13b22fd210106957f0ac")
