-- Lua provided by RyzenAPI
-- Game: addappid(2259480)

-- MAIN APPLICATION
addappid(2259480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259480,0,"d0767ba3dc73b196293d1f9b16a10a37f03b1a269b2b550305accb07b5f2689f")
