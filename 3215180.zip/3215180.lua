-- Lua provided by SkyAPI 
-- Game: AppID 3215180
addappid(3215180)
addappid(3215181, 1, "1123c7035174cf5ef0c451ec99f31da6ce70da7aeb7d3bde5a2049540444991c")
