-- Lua provided by RyzenAPI
-- Game: 3215180

-- MAIN APPLICATION
addappid(3215180)
-- Game: addappid(3215180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215181, 1, "1123c7035174cf5ef0c451ec99f31da6ce70da7aeb7d3bde5a2049540444991c")
