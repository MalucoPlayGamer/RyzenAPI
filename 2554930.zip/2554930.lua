-- Lua provided by RyzenAPI
-- Game: Shadows Are Alive

-- MAIN APPLICATION
addappid(2554930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554931, 1, "a5a29dc025075ef9a0e509f9b5e454e3c0c1f867a9f68e0eaaca6949ff2d6e19")

