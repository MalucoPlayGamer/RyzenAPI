-- Lua provided by RyzenAPI
-- Game: 361990

-- MAIN APPLICATION
addappid(361990)
-- Game: addappid(361990)

-- MAIN APP DEPOTS / PACKAGES
addappid(361991, 1, "73801ba5a46dc0095d6b2f5e8dbda30b7834de4b0dc3b72ab57653bf9a93a5f2")
addappid(361993, 1, "79b6cc38925c02806302d71c4fe8e02ea50595bc4da277d983d67078dfaffd36")
