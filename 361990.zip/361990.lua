-- Lua provided by RyzenAPI
-- Game: Lakeview Cabin Collection

-- MAIN APPLICATION
addappid(361990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(361991, 1, "73801ba5a46dc0095d6b2f5e8dbda30b7834de4b0dc3b72ab57653bf9a93a5f2")
addappid(361993, 1, "79b6cc38925c02806302d71c4fe8e02ea50595bc4da277d983d67078dfaffd36")
