-- Lua provided by RyzenAPI
-- Game: 2429760

-- MAIN APPLICATION
addappid(2429760)
-- Game: addappid(2429760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429761, 1, "30bcdbb85fdaa3258c34da0637f251b3a38cc6952949aa91ed5fc4e824696965")
