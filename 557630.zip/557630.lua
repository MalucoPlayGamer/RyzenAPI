-- Lua provided by RyzenAPI
-- Game: Hello Charlotte

-- MAIN APPLICATION
addappid(557630)

-- MAIN APP DEPOTS / PACKAGES
addappid(557631, 1, "919a0d89c1bb1df408f8ddb3968b040bb3fab69befab3110849844ae7b21d77e")
addappid(557633, 1, "05efd4599802159c8201f4db8f1d11bf36f4bca2897267b061e2da2ab1a7dbc6")
addappid(557634, 1, "f046030f974b96710d3d3145ed1c98a39638a4fbb4ea4089422fba7a28c858ff")
addappid(557638, 1, "18655930febeef74285bcf13da914b889eec86d10a1b23a00e6ae7cedad7e5e8")
addappid(557639, 1, "7239ddb4ade97443c3d5a1f72e95187e397f8eabf79bf088d9a4c6cd3d099d0d")
addappid(769871, 0, "8fcdc95eecd99445c0d3e79cb13aae75bf7c527f63b5a98553266c5d1a0d1c32")
addappid(769872, 0, "400a77a66be3ecd05bfa48f30702606de8ac54a074f6e328af41673e7da6443a")
addappid(769879, 0, "e53bfdee778fd6e11dd05fc42fc9419137b1589b7d30e966c8389fab85e799c7")

