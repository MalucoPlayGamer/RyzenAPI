-- Lua provided by RyzenAPI
-- Game: Game: News Tower

-- MAIN APPLICATION
addappid(1649950)
-- Game: addappid(1649950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649951, 1, "f17424f2bf015a6cbdb81715f365b15ab924e6c5bbbf8384f9ee60ba963a8253")
addappid(1649952, 1, "49c2380d0c7954477872885734ff457ce8d952573a960930a87f60ded2a95f09")
