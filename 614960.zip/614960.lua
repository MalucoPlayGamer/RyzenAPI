-- Lua provided by RyzenAPI
-- Game: AppID 614960

-- MAIN APPLICATION
addappid(614960)
-- Game: addappid(614960)

-- MAIN APP DEPOTS / PACKAGES
addappid(614961, 1, "09f15cfdbb655f3ee6d6429ccb997ee6e7fa16e715af17e043824e42afdef069")
