-- Lua provided by RyzenAPI
-- Game: Game: The Wreck

-- MAIN APPLICATION
addappid(1687960)
addappid(2342790)
-- Game: addappid(1687960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687961, 1, "7a626ccc50acc56dae200f5706d9b949b462fa95ef48f1657faf2763de7fd674")
