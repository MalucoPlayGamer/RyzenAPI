-- Lua provided by RyzenAPI
-- Game: Power Punch - Healthy Workout Edition

-- MAIN APPLICATION
addappid(2591030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591031, 1, "8c44eb404a7be69e8ac9c49c6090a43596a99cfc0c64b9e9f03166e4a835299b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
