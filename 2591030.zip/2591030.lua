-- Lua provided by RyzenAPI
-- Game: Power Punch - Healthy Workout Edition

-- MAIN APPLICATION
addappid(2591030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591031, 1, "8c44eb404a7be69e8ac9c49c6090a43596a99cfc0c64b9e9f03166e4a835299b")

