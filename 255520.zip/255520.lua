-- Lua provided by RyzenAPI
-- Game: Viscera Cleanup Detail: Shadow Warrior

-- MAIN APPLICATION
addappid(255520)

-- MAIN APP DEPOTS / PACKAGES
addappid(255521, 1, "fb82303d8279ab1c2d248b4f47f600f09ee1e9b1a0878ab4874e807bc2202e6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
