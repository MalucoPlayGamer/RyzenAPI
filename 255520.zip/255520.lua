-- Lua provided by RyzenAPI
-- Game: Viscera Cleanup Detail: Shadow Warrior

-- MAIN APPLICATION
addappid(255520)

-- MAIN APP DEPOTS / PACKAGES
addappid(255521, 1, "fb82303d8279ab1c2d248b4f47f600f09ee1e9b1a0878ab4874e807bc2202e6d")
