-- Lua provided by RyzenAPI
-- Game: 1249040

-- MAIN APPLICATION
addappid(1249040)
-- Game: addappid(1249040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249041, 1, "3d4a833fb9a5edb7baff041f8bd76f263c66e28572bd46f3e9db0603496613b9")
