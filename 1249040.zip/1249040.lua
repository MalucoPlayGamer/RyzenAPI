-- Lua provided by RyzenAPI
-- Game: American Arcadia

-- MAIN APPLICATION
addappid(1249040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249041, 1, "3d4a833fb9a5edb7baff041f8bd76f263c66e28572bd46f3e9db0603496613b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2680540)
