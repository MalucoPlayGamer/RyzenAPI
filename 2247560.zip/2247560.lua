-- Lua provided by RyzenAPI
-- Game: DDR: The Beginning

-- MAIN APPLICATION
addappid(2247560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247561, 1, "6d5aac9e9d3e5134551451d1658701617d53f00e53e80a3c1d1af48f5d9c2109")
