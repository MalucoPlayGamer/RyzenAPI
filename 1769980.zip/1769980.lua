-- Lua provided by RyzenAPI
-- Game: Game: Mask of the Rose

-- MAIN APPLICATION
addappid(1769980)
-- Game: addappid(1769980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769981, 1, "c26d56322f669e0c311e9d14d950b6e3556784405956c5538d20178791419b84")
