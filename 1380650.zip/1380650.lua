-- Lua provided by RyzenAPI
-- Game: Draft of Darkness

-- MAIN APPLICATION
addappid(1380650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380651, 1, "7a1bb7dc1cda46678d37799efd1f1090035d1552a073b72722d679f212ee1615")
addappid(1380652, 1, "4b0bd47483d77129f1aa303d5a7d16d9abeda215ca327909f5731e6b82981cd1")

