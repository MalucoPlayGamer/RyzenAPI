-- Lua provided by RyzenAPI
-- Game: AppID 2570070

-- MAIN APPLICATION
addappid(2570070)
-- Game: addappid(2570070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570071, 1, "eb374688773ff78000004a31b79a03dad20de548e860d4caade1b99cf30264b4")
