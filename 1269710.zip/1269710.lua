-- Lua provided by RyzenAPI 
-- Game: Kainga: Seeds of Civilization
addappid(1269710)
addappid(1269711, 1, "e96a1f734ee1b8f27f1d6fbb714442ec169ef1f6ed87d6e229b23f69a45ef880")
addappid(1269712, 1, "01cb7c1b8913f26d23ea8929acdd03696725764336820f0cf54317fa497ab069")
addappid(2731110, 0, "f4e893b1f6f70385fb8e4d0c9f07bcab33cf02ce0c0fd4a2353b2250fbf03602")
