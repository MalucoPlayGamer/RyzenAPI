-- Lua provided by RyzenAPI
-- Game: Bikini Island Challenge

-- MAIN APPLICATION
addappid(1074680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074681, 1, "6b41a7c798c5b87eb1de74a3dd46ea0a966862e0c8248092d8b4d6c0648c528a")

