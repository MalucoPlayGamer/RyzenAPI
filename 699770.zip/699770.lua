-- Lua provided by RyzenAPI 
-- Game: RideOp - Thrill Ride Simulator
addappid(699770)
addappid(699771, 1, "62164b6bb176948cc75a8143a4dd7abbf8888bb21ab52b68d72f090fc12506e4")
addappid(762600, 0, "0a48e58a261431fd7ed821c8931e108445aece1317310043434debb65f9d78f6")
addappid(959060, 0, "e0c6fd17aa4931d0caf99ca901324623718e3e80ef91492758bc26d9f399f10c")
