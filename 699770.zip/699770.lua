-- Lua provided by RyzenAPI
-- Game: RideOp - Thrill Ride Simulator

-- MAIN APPLICATION
addappid(699770)

-- MAIN APP DEPOTS / PACKAGES
addappid(699771, 1, "62164b6bb176948cc75a8143a4dd7abbf8888bb21ab52b68d72f090fc12506e4")
addappid(762600, 0, "0a48e58a261431fd7ed821c8931e108445aece1317310043434debb65f9d78f6")
addappid(959060, 0, "e0c6fd17aa4931d0caf99ca901324623718e3e80ef91492758bc26d9f399f10c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
