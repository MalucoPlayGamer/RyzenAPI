-- Lua provided by RyzenAPI
-- Game: Dot's Home

-- MAIN APPLICATION
addappid(1763520)
-- Game: addappid(1763520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763521, 1, "f0708ffb461a8f64f7dae828a2a5169d167c584a1393cc7373575d28638ac764")
addappid(1763522, 1, "cae0d906b83eb4428ec19735e0cf1dff563a523bef50bd4df9430200c98c8f0c")
