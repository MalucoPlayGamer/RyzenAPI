-- Lua provided by RyzenAPI
-- Game: 2296990

-- MAIN APPLICATION
addappid(2296990)
-- Game: addappid(2296990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296991, 1, "27bc64e8bc9748cccd892ab3401ed3c2e01b42aa7b496e9c0dd6ff0e06406f4c")
