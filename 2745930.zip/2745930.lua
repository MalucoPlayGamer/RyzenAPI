-- Lua provided by RyzenAPI
-- Game: MindKatt:First Strike

-- MAIN APPLICATION
addappid(2745930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2745931, 1, "c981946192598ad0652ead9f0e64b8ffdd87fbc61bd55d6d96f18d5e02bfa9e7")

