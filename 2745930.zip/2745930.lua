-- Lua provided by RyzenAPI
-- Game: addappid(2745930)

-- MAIN APPLICATION
addappid(2745930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2745931, 1, "c981946192598ad0652ead9f0e64b8ffdd87fbc61bd55d6d96f18d5e02bfa9e7")
