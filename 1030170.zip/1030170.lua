-- Lua provided by RyzenAPI 
-- Game: AppID 1030170
addappid(1030170)
addappid(1030171, 1, "3634222d15667393c9a7a0853da276a5ae230ea7b392b200ff22c2f877a725e0")
