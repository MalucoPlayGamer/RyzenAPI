-- Lua provided by RyzenAPI
-- Game: Beam Car Crash Derby

-- MAIN APPLICATION
addappid(1555880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555881, 1, "45c9cb5700983e6e90553e0246062cb71a0acb2389b206f0175c13fb7160e4db")
