-- Lua provided by RyzenAPI
-- Game: Half Minute Hero: The Second Coming

-- MAIN APPLICATION
addappid(240970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(240971, 1, "78b8e8897679952e2ed1314a9ff465f02ecf60cd33bdb5e3ca9ffe465eceb3d8")
addappid(240980, 1, "74c9201776b7694f64f166c87947270e659d1e23485fc2ac350f6be82add9ffc")
addappid(283750, 0, "80433f58c824080423826ae81a4899e4c120286927fc9097727f838185fcb9eb")
