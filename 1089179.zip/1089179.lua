-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1089179)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089179,0,"51e5e183d0fcaf94acc31e5e8125554de8179be697d1c31167278b8397042382")
addtoken(1089179,8107642662352155983)

