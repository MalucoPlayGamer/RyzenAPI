-- Lua provided by RyzenAPI
-- Game: 3014300

-- MAIN APPLICATION
addappid(3014300)
-- Game: addappid(3014300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014301, 1, "ccd6de2a7c3dd941677d788f07eed14c68ff2af3675cac8ae04967c4a909f733")
