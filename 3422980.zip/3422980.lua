-- 3422980's Lua and Manifest Created by Hubcap Manifest
-- Patra and the Erotic Dungeon
-- Created: August 13, 2026 at 11:11:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3422980, 1, "f7beb34a50c3d0c82766940aa03ab553330311a9d273e85b64bb97bd0c503dd9") -- Patra and the Erotic Dungeon
-- MAIN APP DEPOTS
addappid(3422981, 1, "4ea26a6abf115287ffef2e3b76b95ac21ee0ffc77b9f2508585e23f14f1b174c") -- Depot 3422981
setManifestid(3422981, "2807752851050089834", 610017163)
addappid(3422982, 1, "4c0293b61802a46aceeb7ac991354e9947753a226f35f26821672949c74a7891") -- Depot 3422982
setManifestid(3422982, "3849912152654587242", 609936802)
addappid(3422983, 1, "d5926837372fcb85244b0c8997af0d8a3e012f26b0bb6bca4d391b02ae87c8ee") -- Depot 3422983
setManifestid(3422983, "1074528236277752837", 637163032)