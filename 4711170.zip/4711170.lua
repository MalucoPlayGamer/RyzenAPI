-- 4711170's Lua and Manifest Created by Hubcap Manifest
-- Miriam's Potion Journal
-- Created: July 29, 2026 at 12:48:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4711170) -- Miriam's Potion Journal
-- MAIN APP DEPOTS
addappid(4711171, 1, "3f3f8acb6ee4d0016493e0c015fb21f95d00e70139fb24ba78a85b746c925c3e") -- Depot 4711171
setManifestid(4711171, "4895732067345051646", 1304525014)