-- Lua provided by RyzenAPI
-- Game: Game: Driftwood

-- MAIN APPLICATION
addappid(2223700)
-- Game: addappid(2223700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223701, 1, "7a0a5886a86f1ff0123bc4ac0a8da1c52df0b7b0c9af2d41050d751aed8b383b")
