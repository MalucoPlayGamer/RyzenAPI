-- Lua provided by RyzenAPI
-- Game: 2674810

-- MAIN APPLICATION
addappid(2674810)
-- Game: addappid(2674810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674811, 1, "e1717e0bfea5acb27240ccc45a2643ceaec2e5eeaaf96c903d601a8c46d09535")
addappid(2674812, 1, "b24d2b2a6731ba5f2373cdb34715eea0409bbec7c9e8b26436b8675a9886e7bf")
