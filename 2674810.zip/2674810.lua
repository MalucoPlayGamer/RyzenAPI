-- Lua provided by RyzenAPI 
-- Game: Dragon's Dogma 2 Character Creator & Storage
addappid(2674810)
addappid(2674811, 1, "e1717e0bfea5acb27240ccc45a2643ceaec2e5eeaaf96c903d601a8c46d09535")
addappid(2674812, 1, "b24d2b2a6731ba5f2373cdb34715eea0409bbec7c9e8b26436b8675a9886e7bf")
