-- Lua provided by RyzenAPI
-- Game: Chernobyl Again Demo

-- MAIN APPLICATION
addappid(2771150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771151, 1, "b427a7326d21f0b2b233c91b86604c0dc60a1ceb610585c6bd32f95cd038d298")

