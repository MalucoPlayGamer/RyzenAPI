-- Lua provided by RyzenAPI 
-- Game: Nasty Zombies
addappid(2851700)
addappid(2851701, 1, "053b3e90f41a63024b2603a78ecb597d6bc4633e43e218ef1117692b159e0d55")
