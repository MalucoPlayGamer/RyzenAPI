-- Lua provided by RyzenAPI
-- Game: Game: Nasty Zombies

-- MAIN APPLICATION
addappid(2851700)
-- Game: addappid(2851700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851701, 1, "053b3e90f41a63024b2603a78ecb597d6bc4633e43e218ef1117692b159e0d55")
