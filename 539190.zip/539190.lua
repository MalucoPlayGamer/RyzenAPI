-- Lua provided by RyzenAPI 
-- Game: AppID 539190
addappid(539190)
addappid(539191, 1, "d0629461e251b304f85705db1ccf341530d4661f91ade53af0642c7a0cbc76ae")
