-- Lua provided by RyzenAPI
-- Game: addappid(3103880)

-- MAIN APPLICATION
addappid(3103880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103880,0,"1c8d9bb507f945877934bbbc1313c8027cedf7e6f8ca0beecf00c0526aeaa277")
