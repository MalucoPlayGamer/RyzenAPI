-- Lua provided by RyzenAPI
-- Game: AppID 712660

-- MAIN APPLICATION
addappid(712660)

-- MAIN APP DEPOTS / PACKAGES
addappid(712661, 1, "251ff2561ded9b52d2993f667d316a609908f21673455a7a59b8ad4a2ddc7f15")
addappid(712662, 1, "c9d772d0105392c3f4d5c0bb98c434482f23f003f147ffd740e51c850d7f5c93")
addappid(712663, 1, "ef176752c40932de5380e8893673b52b66b0fcbd018d237399d147661cc1c5d5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(787380)
