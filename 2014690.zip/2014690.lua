-- Lua provided by RyzenAPI
-- Game: Shame Legacy

-- MAIN APPLICATION
addappid(2014690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014691, 1, "cb8a8e492df8d37466b0b04bb4da84a54ec601ed8fa2edc99459aea3498b5aa8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
