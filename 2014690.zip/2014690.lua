-- Lua provided by RyzenAPI
-- Game: Shame Legacy

-- MAIN APPLICATION
addappid(2014690)
-- Game: addappid(2014690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014691, 1, "cb8a8e492df8d37466b0b04bb4da84a54ec601ed8fa2edc99459aea3498b5aa8")
