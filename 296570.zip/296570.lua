-- Lua provided by RyzenAPI
-- Game: Lords of Xulima

-- MAIN APPLICATION
addappid(296570)
addappid(298880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(296571, 1, "db260e1aa0944537fac5518c83b6a963af71fa8e1d45532d9ff334717a5cb2f3")
addappid(296572, 1, "cea818c0f72f64fb43331515d49bcd71393c14cec44544f25c9705280326dc21")
addappid(296573, 1, "14d712a1d1805fdb696c99d18a5b155fdf12c1ab255af39a757b277624bbe992")
addappid(319290, 0, "1b5c0b48de2ad825406c931dfcd2051b1ec8737d1084869becfef9a8231f9364")
