-- Lua provided by RyzenAPI
-- Game: addappid(1820300)

-- MAIN APPLICATION
addappid(1820300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820301, 1, "9a33f8adc034549e2f800155c4c2b3bcd2e8ad313644352c39d02d1fe54b7c97")
