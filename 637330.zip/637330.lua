-- Lua provided by RyzenAPI
-- Game: Stack

-- MAIN APPLICATION
addappid(637330)
-- Game: addappid(637330)

-- MAIN APP DEPOTS / PACKAGES
addappid(637331, 1, "bd692ba7ae732d42a09c79a0a39873f2b0f699405127ccbb657e25d62b3afd6f")
