-- Lua provided by RyzenAPI
-- Game: Stack

-- MAIN APPLICATION
addappid(637330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(637331, 1, "bd692ba7ae732d42a09c79a0a39873f2b0f699405127ccbb657e25d62b3afd6f")

