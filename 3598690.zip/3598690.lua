-- Lua provided by RyzenAPI
-- Game: Pachinko Farm

-- MAIN APPLICATION
addappid(3598690) -- Pachinko Farm

-- MAIN APP DEPOTS / PACKAGES
addappid(3598691, 1, "bf4681a554200f6ac45ab7b881a73a69ce6f1a01ba058521682fc6a50c1353f1") -- Depot 3598691

