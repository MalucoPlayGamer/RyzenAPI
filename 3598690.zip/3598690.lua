-- 3598690's Lua and Manifest Created by Hubcap Manifest
-- Pachinko Farm
-- Created: August 17, 2026 at 09:31:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3598690) -- Pachinko Farm
-- MAIN APP DEPOTS
addappid(3598691, 1, "bf4681a554200f6ac45ab7b881a73a69ce6f1a01ba058521682fc6a50c1353f1") -- Depot 3598691
setManifestid(3598691, "6955942013649479160", 75748603)