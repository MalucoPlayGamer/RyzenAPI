-- Lua provided by RyzenAPI
-- Game: Spirit of the North

-- MAIN APPLICATION
addappid(1213700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213701, 1, "4dfe3c7a1d433a9b7102f47919dde1f0b94b175cad010ab9041d54ec05c6ab4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
