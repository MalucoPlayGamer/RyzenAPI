-- Lua provided by RyzenAPI
-- Game: Spirit of the North

-- MAIN APPLICATION
addappid(1213700)
-- Game: addappid(1213700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213701, 1, "4dfe3c7a1d433a9b7102f47919dde1f0b94b175cad010ab9041d54ec05c6ab4d")
