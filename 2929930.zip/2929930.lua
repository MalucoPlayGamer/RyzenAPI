-- Lua provided by RyzenAPI
-- Game: Xenowars Demo

-- MAIN APPLICATION
addappid(2929930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929931, 1, "de977f2ceceee9f3d50a740565f3f1a5999b45667bb374de3e53da3961e95ff4")
