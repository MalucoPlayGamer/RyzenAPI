-- Lua provided by RyzenAPI 
-- Game: Xenowars Demo
addappid(2929930)
addappid(2929931, 1, "de977f2ceceee9f3d50a740565f3f1a5999b45667bb374de3e53da3961e95ff4")
