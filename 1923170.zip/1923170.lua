-- Lua provided by RyzenAPI
-- Game: Pizza Synthwave

-- MAIN APPLICATION
addappid(1923170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923171, 1, "65d46cc982f9b1ed59f36475fb11218377db1dbd4a85411fbe87c3d3846822f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
