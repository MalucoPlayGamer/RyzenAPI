-- Lua provided by RyzenAPI
-- Game: Pizza Synthwave

-- MAIN APPLICATION
addappid(1923170)
-- Game: addappid(1923170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923171, 1, "65d46cc982f9b1ed59f36475fb11218377db1dbd4a85411fbe87c3d3846822f0")
