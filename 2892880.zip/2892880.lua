-- Lua provided by RyzenAPI
-- Game: 修仙小屋

-- MAIN APPLICATION
addappid(2892880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892881, 1, "97371ce20a95049fb3b6aa47ada1b9a21429e2dbc8ca5c1488a31f46fb364900")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
