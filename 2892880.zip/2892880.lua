-- Lua provided by RyzenAPI
-- Game: addappid(2892880)

-- MAIN APPLICATION
addappid(2892880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892881, 1, "97371ce20a95049fb3b6aa47ada1b9a21429e2dbc8ca5c1488a31f46fb364900")
