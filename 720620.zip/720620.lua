-- Lua provided by RyzenAPI
-- Game: AppID 720620

-- MAIN APPLICATION
addappid(720620)

-- MAIN APP DEPOTS / PACKAGES
addappid(720621, 1, "d08d757f36b034d29142c59699b700bcd098998d1bb9aff7b251b9ca67b96d46")
addappid(720622, 1, "7430390fbdae2ce456327f8273bd4987f1cedeef6bcb8c75890a0a15519acc1d")
addappid(720623, 1, "fffc0300271cb14d251db3991723c0466bbc687791f7aaf30f77c1dd97b38e8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
