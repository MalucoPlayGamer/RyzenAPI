-- Lua provided by RyzenAPI
-- Game: 2827310

-- MAIN APPLICATION
addappid(2827310)
-- Game: addappid(2827310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827311, 1, "bfd9991c0deda79dc97fea32a610f0bcc2a06f72a590ef4284d6f4cfa22589fe")
