-- Lua provided by RyzenAPI
-- Game: 漂流瓶盖 Drifting Bottle Cap

-- MAIN APPLICATION
addappid(2827310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2827311, 1, "bfd9991c0deda79dc97fea32a610f0bcc2a06f72a590ef4284d6f4cfa22589fe")

