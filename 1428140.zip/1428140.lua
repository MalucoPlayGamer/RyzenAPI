-- Lua provided by RyzenAPI
-- Game: Riding Seas

-- MAIN APPLICATION
addappid(1428140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428141, 1, "78d29f1a2e34472e5cfe9ca36a737d7bf374e9ef94f0abac23cd0809f1256446")

