-- Lua provided by RyzenAPI
-- Game: 2963530

-- MAIN APPLICATION
addappid(2963530)
-- Game: addappid(2963530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963531, 1, "bb3a620c559cd6c0eb5f2c303daefe349375da03fe0a0a7cd8c23fbfe84510ec")
addappid(2963532, 1, "a84c468393b1a0a68cd6dfdb78025c64d26851aeff7ad4a121f6f44791832b58")
addappid(2963533, 1, "d750f951cb643afd8f4500e346d81cb6c948f98d8aea4df9bce45cff44ec3d07")
addappid(2963534, 1, "7ad3a4b2c255a5d9eebfeedf96e4ee5e0fa314c45a55f3abacb931185c033a88")
