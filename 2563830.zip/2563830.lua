-- Lua provided by RyzenAPI
-- Game: Death of a Wish Demo

-- MAIN APPLICATION
addappid(2563830)
-- Game: addappid(2563830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563831, 1, "c58d68749d53cebbf28ecd5f827a634129859f0bccbaa162c07f5bd5fd0745d8")
