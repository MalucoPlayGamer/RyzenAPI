-- Lua provided by RyzenAPI
-- Game: The Evil Within - Soundtrack

-- MAIN APPLICATION
addappid(446950)

-- MAIN APP DEPOTS / PACKAGES
addappid(446950,0,"bf30aa6a29252e5fedf5bb424228fa5549eb907f08ffebe3769e98c9d32e36cd")
