-- Lua provided by RyzenAPI
-- Game: 1762320

-- MAIN APPLICATION
addappid(1762320)
-- Game: addappid(1762320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762321, 1, "e190ef485f4b1dc7e85a032312c4afafdd485e703e33b853c31749d723c9d3c8")
