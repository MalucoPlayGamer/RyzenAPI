-- Lua provided by RyzenAPI
-- Game: addappid(42670)

-- MAIN APPLICATION
addappid(42670)
addappid(229033)

-- MAIN APP DEPOTS / PACKAGES
addappid(42671, 1, "57ee2d1dfbccfc21c9c7cd5d33b173b8f747280202f99fbac5534836ca4696db")
addappid(42672, 1, "2db0a5e36a26e540cee83f2ae48d007b43cd758c36af0db9f2dc980e1d8621b9")
addappid(42673, 1, "ec9b68e15ca309c706eac7209e8871ee5c23916a3bb0fa51d3e2b94369bec1e8")
addappid(42676, 1, "ea887a84dc2b9622af39b5f12ae39e0c87d0923839016f496784370513ad7bbc")
