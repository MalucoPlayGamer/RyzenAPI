-- Lua provided by RyzenAPI
-- Game: Pandemic Love

-- MAIN APPLICATION
addappid(1558900)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1565270)
