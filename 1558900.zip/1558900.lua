-- Lua provided by RyzenAPI
-- Game: Pandemic Love

-- MAIN APPLICATION
addappid(1558900)
