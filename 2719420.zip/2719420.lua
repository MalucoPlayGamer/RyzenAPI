-- Lua provided by RyzenAPI
-- Game: Dude Simulator Six

-- MAIN APPLICATION
addappid(2719420)
-- Game: addappid(2719420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719421, 1, "889c359e2f2c7a36f8ef9102ed234697621ec3de3a55413528b28c83ff093f81")
