-- Lua provided by RyzenAPI
-- Game: Lillian Night: Exclusive Contract of Succubus

-- MAIN APPLICATION
addappid(1793800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793801, 1, "c23473d19ed0d107bf5866965baf129e4f3e64fbe6bcd2f2ca4e89a044cdb05b")

