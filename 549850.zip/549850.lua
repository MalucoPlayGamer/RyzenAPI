-- Lua provided by RyzenAPI
-- Game: The Shadows of Pygmalion

-- MAIN APPLICATION
addappid(549850)
-- Game: addappid(549850)

-- MAIN APP DEPOTS / PACKAGES
addappid(549851, 1, "f995a84cc21e9ae3617a05f3bb06709ebe5fb4bce202067c39946405c2757cf5")
