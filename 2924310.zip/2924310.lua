-- Lua provided by RyzenAPI 
-- Game: Anoxia Station
addappid(2924310)
addappid(2924311, 1, "ab58e5ab3a9492526a07c16dd55056e3740d0be139a73f8b780e1664258c0b5a")
