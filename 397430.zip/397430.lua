-- Lua provided by RyzenAPI
-- Game: Game: Zoombinis

-- MAIN APPLICATION
addappid(397430)
-- Game: addappid(397430)

-- MAIN APP DEPOTS / PACKAGES
addappid(397431, 1, "baec2365c204e1a5156be390d905abacf178b5a6089c7eb2538dc71033177fc6")
addappid(397435, 1, "e66812e3efab5256188a3f4fdc189be7e0ee252cb026b360b2637fb6c911a5fe")
addappid(411700, 0, "818a7894174e9d7172b715566d33dd8e5776a9c724577033aaae9cc1a9e967b6")
addappid(411701, 0, "f8bb34872e47a6d168f0619ed5221ef46f61e6c170a1eac32631b66293c2c536")
addappid(411702, 0, "ff91e221c30b90daa7fb0b879fece286f8dfbc6a0e3a35b7465491c0a749278d")
addappid(411703, 0, "13fdae6061b3daf8f4b84c84f5827a50f41ef7ed3a459a82db1897dfc5b14f8a")
