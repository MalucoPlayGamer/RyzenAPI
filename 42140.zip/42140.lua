-- Lua provided by RyzenAPI
-- Game: Hamilton's Great Adventure

-- MAIN APPLICATION
addappid(42140)
addappid(42180)
-- Game: addappid(42140)

-- MAIN APP DEPOTS / PACKAGES
addappid(42141, 1, "1fd7aab3ea8fd864b2adc9fa2589cb321af94a82e11ec802bd4cd8997c4dd287")
