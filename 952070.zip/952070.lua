-- Lua provided by RyzenAPI
-- Game: RESIDENT EVIL RESISTANCE

-- MAIN APPLICATION
addappid(952070)
addappid(1108280)
addappid(1295350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(952071,0,"be4c331b420fccf7ed6e4ed528a8f004574c409dfc941ad3e7004fb936679301")
addappid(1108280,0,"2c80f9e638cea673510ec5562456040bb00c6ef138fb7be77c691ecab6118199")
addappid(1295350,0,"dbe021a1825f0f53da71272f5fd0f4e37669b27d0e00393fcc472b70f515dce7")

