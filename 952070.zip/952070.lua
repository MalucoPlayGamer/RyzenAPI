-- Lua provided by RyzenAPI
-- Game: Game: RESIDENT EVIL RESISTANCE

-- MAIN APPLICATION
addappid(952070)
-- Game: addappid(952070)

-- MAIN APP DEPOTS / PACKAGES
addappid(952071, 1, "be4c331b420fccf7ed6e4ed528a8f004574c409dfc941ad3e7004fb936679301")
