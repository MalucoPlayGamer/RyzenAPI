-- Lua provided by RyzenAPI
-- Game: Wallpaper Pack – Sex Arena 🖥️

-- MAIN APPLICATION
addappid(3668770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668770,0,"64bbdd6bab2889d8d3416d719d1b81825e742002225cff10e069820d7fb73132")
