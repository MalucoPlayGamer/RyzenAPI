-- Lua provided by RyzenAPI
-- Game: AppID 1019100

-- MAIN APPLICATION
addappid(1019100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019101, 1, "e1792d53fa6eb393033cbc5a70373eb42006e6ab7f77dbc9e7aaf886f4a511e0")
