-- Lua provided by RyzenAPI
-- Game: Metaphor: ReFantazio - Etrian Odyssey Class Costumes (7) & Battle BGM Set

-- MAIN APPLICATION
addappid(2924470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924470,0,"16a09d4bd6677c201ad2b9b6164fd3e363aa0e76ce4e703134893da89548fb97")
