-- Lua provided by RyzenAPI
-- Game: Game: Exp10sion

-- MAIN APPLICATION
addappid(2618850)
-- Game: addappid(2618850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618851, 1, "426b9dbc2229ce871268f68da121ad26a0232a4d07bd11b63e2f22d83e8ebc18")
addappid(2618852, 1, "34c8391bfbcacf46077db6dc401ee4f1eea1e8f6e3c60bc07b761ddaf6354028")
