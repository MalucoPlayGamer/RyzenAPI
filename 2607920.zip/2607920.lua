-- Lua provided by RyzenAPI
-- Game: House of Jigsaw: Happy puzzling, Happy home

-- MAIN APPLICATION
addappid(2607920)
addappid(2610930)
addappid(2610940)
addappid(2610950)
addappid(2649590)
addappid(2649600)
addappid(2649610)
addappid(2649620)
addappid(2649630)
addappid(2649640)
addappid(2649650)
addappid(2649660)
addappid(2649670)
addappid(2649680)
addappid(2649710)
addappid(2649720)
addappid(2666010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607921, 1, "bc31085fc34af38fa4686d23b06d18f6a850fbb392c054ef517b42a528b5ecae")

