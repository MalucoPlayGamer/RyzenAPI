-- Lua provided by RyzenAPI
-- Game: addappid(204580)

-- MAIN APPLICATION
addappid(204580)

-- MAIN APP DEPOTS / PACKAGES
addappid(204581, 1, "8cf82b6c79074b4e9a58e7e490affa4ad3a7c29a2a029d98660908016b269605")
