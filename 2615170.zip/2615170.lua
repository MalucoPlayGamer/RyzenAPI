-- Lua provided by SkyAPI 
-- Game: AppID 2615170
addappid(2615170)
addappid(2615171, 1, "04b635d9bd7ce93cbf90db5e571d9637aa957587c0d1d1283b34098d2ae78113")
