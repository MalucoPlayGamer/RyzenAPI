-- Lua provided by RyzenAPI
-- Game: Shui's Odyssey Demo

-- MAIN APPLICATION
addappid(2897780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897781, 1, "facfbecda215f93d2854b3861f16b6e8b80f18b4f536d21f008004685e9e6709")
