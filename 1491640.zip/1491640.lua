-- Lua provided by RyzenAPI
-- Game: Understanding, The Game

-- MAIN APPLICATION
addappid(1491640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491641, 1, "bdd5d796d26d64b90fccbd52a7f92ae76978f0e556dc1707c07b0bf1fecfcb5b")
