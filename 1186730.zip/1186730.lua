-- Lua provided by RyzenAPI
-- Game: Game: Terro Lunkka Adventures

-- MAIN APPLICATION
addappid(1186730)
-- Game: addappid(1186730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186731, 1, "026af74792200c43656ddb2edd7b33d47b6a3dea61b7f47884cb74ec228e02cf")
