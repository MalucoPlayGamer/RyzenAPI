-- Lua provided by RyzenAPI
-- Game: addappid(1780820)

-- MAIN APPLICATION
addappid(1780820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780820,0,"8f8dea9504bd65be128a00ec17e21231eb0c1a4c7db6575aacbf5d812ae01e1b")
