-- Lua provided by RyzenAPI
-- Game: Patrick's Parabox Original Soundtrack

-- MAIN APPLICATION
addappid(1928340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928341, 1, "896a82e9d269028758a48d12df22d979044185a6ba1a34fbb1c275506baaee57")
addappid(1928342, 1, "8e1471d12e5296bc44707fde2bb708edbd8fa500d202f5b16368a41723cb6f0a")

