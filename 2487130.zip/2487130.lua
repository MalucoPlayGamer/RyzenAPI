-- Lua provided by RyzenAPI
-- Game: addappid(2487130)

-- MAIN APPLICATION
addappid(2487130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487131, 1, "e5fa7238d0663218e800e619069e9d36b29c16bfe2c2ad6829df7ad61f2f6e7a")
