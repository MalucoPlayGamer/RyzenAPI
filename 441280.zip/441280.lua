-- Lua provided by RyzenAPI
-- Game: AppID 441280

-- MAIN APPLICATION
addappid(441280)
-- Game: addappid(441280)

-- MAIN APP DEPOTS / PACKAGES
addappid(441281, 1, "12cca336e41cb0be64b46104ffb7e9585d2e5a069019dd82a0df559f01752ac7")
