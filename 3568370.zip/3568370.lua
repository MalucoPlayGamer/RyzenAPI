-- Lua provided by RyzenAPI
-- Game: 3568370

-- MAIN APPLICATION
addappid(3568370)
-- Game: addappid(3568370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568371, 1, "3d8f14cb3908733e409848aed7f979ecb6bd468fce5119c429c60c7bd4414ee2")
