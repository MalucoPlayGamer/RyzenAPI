-- Lua provided by RyzenAPI
-- Game: 2554760

-- MAIN APPLICATION
addappid(2554760)
-- Game: addappid(2554760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554761, 1, "7e8114acab7ab8ef1fd078cb3bcd8bd7ccc2983788789b08435915a8b4954cf7")
