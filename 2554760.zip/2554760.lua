-- Lua provided by RyzenAPI
-- Game: Lightcube Pixel Art Editor

-- MAIN APPLICATION
addappid(2554760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2554761, 1, "7e8114acab7ab8ef1fd078cb3bcd8bd7ccc2983788789b08435915a8b4954cf7")

