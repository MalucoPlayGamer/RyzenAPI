-- Lua provided by RyzenAPI
-- Game: addappid(511280)

-- MAIN APPLICATION
addappid(511280)

-- MAIN APP DEPOTS / PACKAGES
addappid(511281, 1, "097bd35a09bf52bf7e71a111c93782e622d690b0b3b16cfded9879480caa861f")
