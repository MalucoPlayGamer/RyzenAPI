-- Lua provided by RyzenAPI
-- Game: Silent Depth 3D Submarine Simulation

-- MAIN APPLICATION
addappid(846050)

-- MAIN APP DEPOTS / PACKAGES
addappid(846051, 1, "c9ebfb8a0e90df5c8d7396a285eedd6d83c330a97f7056816a5efe8690963503")

