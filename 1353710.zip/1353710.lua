-- Lua provided by RyzenAPI
-- Game: 1353710

-- MAIN APPLICATION
addappid(1353710)
-- Game: addappid(1353710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353711, 1, "09b6a13d18bf99a94446accf95958375b4ee346c8fafa6f7dae328936a033ad1")
