-- Lua provided by RyzenAPI
-- Game: setManifestid(2415482,"2005748565587265048")

-- MAIN APPLICATION
addappid(2415480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415482,0,"e635caeb8cb6d82ba960ac51c93ed8d924bae394d3c1bacd6770280aa07fa275")

