-- Lua provided by RyzenAPI
-- Game: RECYCLE

-- MAIN APPLICATION
addappid(294830)
-- Game: addappid(294830)

-- MAIN APP DEPOTS / PACKAGES
addappid(294831, 1, "cadc497e5a2f4010d593b4d37d27ae360e35db5955555886d75303771ebf7cf6")
