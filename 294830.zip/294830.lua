-- Lua provided by RyzenAPI
-- Game: RECYCLE

-- MAIN APPLICATION
addappid(294830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(294831, 1, "cadc497e5a2f4010d593b4d37d27ae360e35db5955555886d75303771ebf7cf6")

