-- Lua provided by RyzenAPI
-- Game: The Test: Secrets of the Soul

-- MAIN APPLICATION
addappid(2231890)
addappid(2280920)
-- Game: addappid(2231890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231891, 1, "aca89642f7d2619660c6fd3da08d2b4ff609f2aaf4195522e9f6d1958611bec7")
