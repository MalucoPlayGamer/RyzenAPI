-- Lua provided by RyzenAPI
-- Game: The Test: Secrets of the Soul

-- MAIN APPLICATION
addappid(2231890)
addappid(2280920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2231891, 1, "aca89642f7d2619660c6fd3da08d2b4ff609f2aaf4195522e9f6d1958611bec7")

