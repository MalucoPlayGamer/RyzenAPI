-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - German Islands 1: East Frisia

-- MAIN APPLICATION
addappid(1379950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379950,0,"5d0d49d70951e4c5ac33c315aea1d6e9cdae98c2e2be4feffe48055d06760a15")

