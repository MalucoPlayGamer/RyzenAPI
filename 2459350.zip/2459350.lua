-- Lua provided by RyzenAPI
-- Game: Game: AppID 2459350

-- MAIN APPLICATION
addappid(2459350)
-- Game: addappid(2459350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459351, 1, "d2a72495e9c6120eb5267ece25116f7435c00082dcf1c242b5d1dbe8ffab1fbe")
addappid(3202740, 0, "ae5430b21357961642a3562c24e1f533d1753b4c608fa3ee8a507b07750bda25")
