-- Lua provided by RyzenAPI
-- Game: addappid(336770)

-- MAIN APPLICATION
addappid(336770)

-- MAIN APP DEPOTS / PACKAGES
addappid(336771, 1, "42f8aeed2a56aabea55ad9de29afdf602aeb10cef6c3109104662074e0286ac1")
