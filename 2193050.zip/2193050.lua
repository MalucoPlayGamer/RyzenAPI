-- Lua provided by RyzenAPI
-- Game: Bleak Sword DX

-- MAIN APPLICATION
addappid(2193050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193051, 1, "9670643b180eba9f1d400e0ce5e7db79ec6c5cabc84aad753ce34af0608ef587")
