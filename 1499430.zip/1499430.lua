-- Lua provided by RyzenAPI
-- Game: What We Pretend To Be

-- MAIN APPLICATION
addappid(1499430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499431, 1, "7323ff53ef661feae01440a336f05e839f5c0d710900c29723b9beccc6de3f8c")

