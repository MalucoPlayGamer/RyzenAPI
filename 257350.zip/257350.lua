-- Lua provided by SkyAPI 
-- Game: Baldur's Gate II: Enhanced Edition
addappid(257350)
addappid(257351, 1, "88e74b749a3e454dcff08e818290a58bcb741800f002aa0e40cfdca9d364f5c8")
addappid(257352, 1, "e3455666047d6559b851052b68f9f73041bbffb76ee74ba8cb93b1f0ccc0e5fe")
addappid(257353, 1, "ef916ff1549de04b067c8cc39c4ce5ae4ebc1a8fb410c27b35ca856ba34b883d")
addappid(257354, 1, "b3c8a168d08424cbdab3eb502d4a177b32515e334c705d3257dfa8630073a818")
addappid(2489050, 0, "6662f37ac2ed6ef91731f764678342a103ea91028bc8b077fe0cf4aca7028f05")
