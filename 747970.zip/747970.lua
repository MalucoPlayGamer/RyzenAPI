-- Lua provided by RyzenAPI
-- Game: Scions of Fate

-- MAIN APPLICATION
addappid(747970)

