-- Lua provided by SkyAPI 
-- Game: 八尾 Demo
addappid(1722200)
addappid(1722201, 1, "0224ce8b2b279e8a9166b4c652549fb2f62e5b8ab08735b638e872fc62e28323")
