-- Lua provided by RyzenAPI
-- Game: Trap of MUSK:Europe Night

-- MAIN APPLICATION
addappid(2129280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129281, 1, "aa5cdc32410fc36ac304d2aa7f2019b4ce79704be24727fcf57ff368b6295850")

