-- Lua provided by RyzenAPI
-- Game: 1301250

-- MAIN APPLICATION
addappid(1301250)
addappid(1301251)
addappid(1301253)
addappid(1301254)
-- Game: addappid(1301250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301252,0,"5de0a5c8f62b3942113e3b8786bf25d0216051f9257063eec53940249e89b1c2")
