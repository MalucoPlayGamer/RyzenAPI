-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Diaochan "Knight Costume" / 貂蝉「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019969)
-- Game: addappid(1019969)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019969,0,"626262e30ecd3a506376a27793e3fe45a55d02600e21dd30e31dc6b93831f2f9")
