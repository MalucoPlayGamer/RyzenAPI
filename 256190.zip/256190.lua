-- Lua provided by RyzenAPI
-- Game: Enemy Front

-- MAIN APPLICATION
addappid(256190)

-- MAIN APP DEPOTS / PACKAGES
addappid(256191, 1, "c783ced772d893edf55da72fce0bc97d47a2217ee0c6f5a467ad012629c7972f")
addappid(256192, 1, "51eef06a51e24f6874ee5cdd5b36709bbc3abe39595fe711fa13cc3f04371295")
addappid(256193, 1, "0bc45b949b7b3ecacf5a2b3347ce4a00546ce491cfbcd4adc62d83914619278a")
addappid(256194, 1, "836ea5b6c97f997e358ac72db290282d171b364de1821e00fc1c4889c3bf0c89")
addappid(256195, 1, "d58a80c63de7894f5621928b771c71810005c327251dfc7300d0b8a9e0b0331d")
addappid(256196, 1, "1782b80b1412a2ad88840e98621cce3d3fab722c545b4b19c2d013a76958fc98")
addappid(256197, 1, "0c46143b0c6754f8b43e36b3e48e0853766b30afd6f9d034ed193849f613ecdb")
addappid(256198, 1, "af0a657120ac1b9e8c7660426217a98b2c776fdf958557c66c446f21cc33fe3c")
addappid(256203, 1, "c96f62cd8f5b348b53a8d2493225d883fdb0bbcf0487015bb87182848be8e1df")
addappid(256205, 1, "dffe17c11b17212650ceff6e139c84c9d0bffa7ab6f367d417c78e7ca20010ea")
addappid(298990, 0, "38bec4fdd68c6799dc27d7dfe8a4a817c0b0d2f5331e965fd1fbf5b921e1a80c")
addappid(298991, 1, "8eb162750dacd9d32f8e7cb86b5cbce7712859d22542bb902cbafc0eabab17ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(299000)
addappid(299001)
addappid(299002)
addappid(299003)
addappid(299004)
