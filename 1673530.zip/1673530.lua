-- Lua provided by RyzenAPI
-- Game: Game: AppID 1673530

-- MAIN APPLICATION
addappid(1673530)
-- Game: addappid(1673530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673531, 1, "811f23168efb4e311af538d96b6bbb0b896988921092fe5bf48db839d0de72f3")
