-- Lua provided by RyzenAPI
-- Game: Game: AppID 492370

-- MAIN APPLICATION
addappid(492370)
-- Game: addappid(492370)

-- MAIN APP DEPOTS / PACKAGES
addappid(492371, 1, "cd74171a320075b75c98de6d2b489f2a0f1846419540cfed146fcf2f68fc22e4")
