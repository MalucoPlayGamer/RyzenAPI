-- Lua provided by RyzenAPI
-- Game: Owlboy

-- MAIN APPLICATION
addappid(115800)

-- MAIN APP DEPOTS / PACKAGES
addappid(115801, 1, "a7e3b849c66873b3c4c2f8cfe71bb7ec573874589edfa9b45411050240383ac6")
addappid(115802, 1, "738602fd9417b936957c34e56b4918fa0e1405029359337b9c3738877ad3e6d6")
addappid(115804, 1, "2adf3f41396af518bfb490339fe3fd5fa2c9704e449cafa61c157aa82bf5eb71")
addappid(115805, 1, "d310bc39106ecece4c138a2d0defa4e3566ca891feaac95fa81d2874fb5a4509")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

