-- Lua provided by RyzenAPI
-- Game: Tales of Agaris

-- MAIN APPLICATION
addappid(1990400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990401, 1, "09cd24514a30ec4ee1bf5f8caeb02d7f8c02997bcf6850581e5fa94982a4e32d")
addappid(1990402, 1, "8624a004977cd1f337885dca9df4bfe93eb9a34b91da6672735a00b4e66ee5a4")
addappid(1990403, 1, "748e2e2ad86eda8f4d67eb3f7b7e93e23d70b558bf1e457dfa8e00ed5bd9ccfd")
addappid(1990404, 1, "d97a77ea48841994952f8efb55fa3cabcaab6b95bc759219fb381b2074d0d3b7")
addappid(1990405, 1, "79f948f20cca12feda8034e68cc0248c3edb3a61399a82d4043fa9934cbbdf3d")
addappid(1990409, 1, "eea9062f7b96ab3ef0af18273c312bc26e6343510dfe8e7dc99702e2f49c145f")
