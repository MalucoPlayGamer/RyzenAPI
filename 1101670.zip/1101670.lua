-- Lua provided by RyzenAPI
-- Game: ARISEN - Chronicles of Var'Nagal

-- MAIN APPLICATION
addappid(1101670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101671, 1, "37be8e7a2b99aff31b0ad5f5b43323720ba585c6138a07232058f798301b209b")

