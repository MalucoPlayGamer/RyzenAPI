-- Lua provided by RyzenAPI 
-- Game: The Cinema Rosa
addappid(1049140)
addappid(1049141, 1, "636f2a9f1cf370d4f0458ebda5631e2a0546d2c4fcf5130b23c0e66cde57b67e")
