-- Lua provided by RyzenAPI
-- Game: The Cinema Rosa

-- MAIN APPLICATION
addappid(1049140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1049141, 1, "636f2a9f1cf370d4f0458ebda5631e2a0546d2c4fcf5130b23c0e66cde57b67e")

