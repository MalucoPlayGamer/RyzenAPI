-- Lua provided by RyzenAPI
-- Game: addappid(258880)

-- MAIN APPLICATION
addappid(258880)

-- MAIN APP DEPOTS / PACKAGES
addappid(258881, 1, "3dc88de5dae71ccf9cb8dd720178a8962a9d5afb4db5edafbbcbd3d6108d67b0")
addappid(264830, 0, "da09955ec485265efb131c9b7e0b5a06d3d9f490c0501c9e2e6fe2f74ea0960e")
addappid(288850, 0, "7077714ae2f0e41bdf1d5919cfecd881d237bda4bfec8f7f5f35a015e6ff9b36")
