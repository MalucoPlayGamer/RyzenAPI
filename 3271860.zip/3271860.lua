-- Lua provided by RyzenAPI
-- Game: addappid(3271860)

-- MAIN APPLICATION
addappid(3271860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271862,0,"3692deff355cbbb3da7c3357d0293d13fea5c032084d705aa504282cc72fb8c4")
