-- Lua provided by RyzenAPI
-- Game: addappid(3424040)

-- MAIN APPLICATION
addappid(3424040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424041, 1, "d5c5a97b61afdf8bc986ec57edc405407f1117f1c19d635d0716ed331ea3ba49")
