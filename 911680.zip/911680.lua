-- Lua provided by RyzenAPI
-- Game: REZ PLZ

-- MAIN APPLICATION
addappid(911680)
addappid(1188300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(911681, 1, "5190073706f423df9d1a3e098cc6a0a67802d7b8742177076dff5d3c0e1b28b1")

