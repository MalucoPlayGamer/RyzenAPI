-- Lua provided by RyzenAPI
-- Game: REZ PLZ

-- MAIN APPLICATION
addappid(911680)
addappid(1188300)
-- Game: addappid(911680)

-- MAIN APP DEPOTS / PACKAGES
addappid(911681, 1, "5190073706f423df9d1a3e098cc6a0a67802d7b8742177076dff5d3c0e1b28b1")
