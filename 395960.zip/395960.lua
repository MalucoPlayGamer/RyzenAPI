-- Lua provided by RyzenAPI
-- Game: عالم أريب

-- MAIN APPLICATION
addappid(395960)
addappid(395961)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983,0,"77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b")

