-- Lua provided by RyzenAPI
-- Game: Game: AppID 1054170

-- MAIN APPLICATION
addappid(1054170)
addappid(1118900)
addappid(1132400)
-- Game: addappid(1054170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054171, 1, "37c78dcdba51e1a79a5280142c7dc0938c498f8914a3f1d80943f96eda1f0a7c")
