-- Lua provided by RyzenAPI
-- Game: Byte Driver

-- MAIN APPLICATION
addappid(944300)
-- Game: addappid(944300)

-- MAIN APP DEPOTS / PACKAGES
addappid(944301, 1, "e2a5609736af1a18fe441918a4ed7d2722cac1e99130c4cead68f96a57c4776b")
addappid(1071820, 0, "3d25e4597222083850b7f9c04511c9d15fe4123e9194f0ebb1e8d0b973e9e004")
