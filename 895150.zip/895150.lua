-- Lua provided by RyzenAPI
-- Game: addappid(895150)

-- MAIN APPLICATION
addappid(895150)

-- MAIN APP DEPOTS / PACKAGES
addappid(895151, 1, "7c0ed2d105dfbd0ec35baf491f6e176a2c7987bdb3fa3fb419bf5194cc8c8fd5")
