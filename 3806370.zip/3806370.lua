-- Lua provided by RyzenAPI
-- Game: Nasubi Room

-- MAIN APPLICATION
addappid(3806370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3806371, 1, "65986f2b316efbf4bb320f0dd5ffadeffe3c097632ac04fdc46204a773dc7ad7")
