-- Lua provided by RyzenAPI
-- Game: A Boy and His Blob

-- MAIN APPLICATION
addappid(281200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(281201, 1, "09350faba45549dfcae10c5670d5c41640647c643cfe2d2f24e5f34a13d3e518")
addappid(281202, 1, "df0dcf61b49861f307a074a610396d8c65f45f4a4ceba02db7e202057310b718")
addappid(281203, 1, "654ee227f1ffeb0a445b6bae95110b7b85ce88fc3e7e2cf0380256233f4c03b4")

