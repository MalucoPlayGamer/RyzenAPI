-- Lua provided by RyzenAPI
-- Game: Game: AppID 585550

-- MAIN APPLICATION
addappid(585550)
-- Game: addappid(585550)

-- MAIN APP DEPOTS / PACKAGES
addappid(585551, 1, "11c6f23ceec906d102bb40dba604e4ad16a8445d362cc2cfa474413dac084dea")
addappid(596960, 0, "0a09c80be7055fcbdac2f76359603ba46a2557826218808879cb76b51285c0e6")
