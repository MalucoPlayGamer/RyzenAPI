-- Lua provided by RyzenAPI
-- Game: FEMINAZI: The Triggering

-- MAIN APPLICATION
addappid(585550)
addappid(625660)
addappid(674970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(585551, 1, "11c6f23ceec906d102bb40dba604e4ad16a8445d362cc2cfa474413dac084dea")
addappid(596960, 0, "0a09c80be7055fcbdac2f76359603ba46a2557826218808879cb76b51285c0e6")

