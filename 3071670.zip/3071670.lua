-- Lua provided by RyzenAPI
-- Game: Pixel Cross Stitch Color by Number

-- MAIN APPLICATION
addappid(3071670)
