-- Lua provided by RyzenAPI
-- Game: Lily's Well

-- MAIN APPLICATION
addappid(1834870)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1857420)
