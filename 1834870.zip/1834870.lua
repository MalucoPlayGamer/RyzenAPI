-- Lua provided by RyzenAPI
-- Game: Lily's Well

-- MAIN APPLICATION
addappid(1834870)

