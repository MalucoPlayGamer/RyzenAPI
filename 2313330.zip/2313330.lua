-- Lua provided by RyzenAPI
-- Game: TerraTech Worlds

-- MAIN APPLICATION
addappid(2313330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313331, 1, "8ee1a4fafbd70d88f090b0ea5334848b76fc0833f64012b442b92183465bddc1")

