-- Lua provided by RyzenAPI
-- Game: TerraTech Worlds

-- MAIN APPLICATION
addappid(2313330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313331, 1, "8ee1a4fafbd70d88f090b0ea5334848b76fc0833f64012b442b92183465bddc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
