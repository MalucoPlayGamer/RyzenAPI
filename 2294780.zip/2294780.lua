-- Lua provided by RyzenAPI
-- Game: Backpack Survivors

-- MAIN APPLICATION
addappid(2294780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294784,0,"8b1c3d458cb2c148c385a4bbe090128cf1c05e5dbe76f8236e83b0bfd774ca3e")

