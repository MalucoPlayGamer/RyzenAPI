-- Lua provided by RyzenAPI
-- Game: Twisty's Asylum Escapades

-- MAIN APPLICATION
addappid(506760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(506761, 1, "1cc930853c500e2159860f384be9100e0ce6027fde095bda71c0457ec67d4b08")
