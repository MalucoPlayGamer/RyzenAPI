-- Lua provided by RyzenAPI
-- Game: addappid(1264220)

-- MAIN APPLICATION
addappid(1264220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264221, 1, "e3bcbcb4ec52665c5158c86644a5d28fb53fcc7b7a2d22139c05e21ee25280d3")
