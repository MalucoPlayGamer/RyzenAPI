-- Lua provided by RyzenAPI 
-- Game: Card Blitz: WWII
addappid(1264220)
addappid(1264221, 1, "e3bcbcb4ec52665c5158c86644a5d28fb53fcc7b7a2d22139c05e21ee25280d3")
