-- Lua provided by RyzenAPI
-- Game: Game: When In Rome

-- MAIN APPLICATION
addappid(415330)
-- Game: addappid(415330)

-- MAIN APP DEPOTS / PACKAGES
addappid(415331, 1, "cc918e5ffc39801a8537d3ef5e3a275ab44f631976efd3c182520ddacb25ab85")
addappid(415336, 1, "8f2a19b2d1ed48ee0971631c52d4b31ea8def3c9315df67c0defba4eabd20b2f")
