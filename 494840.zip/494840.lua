-- Lua provided by RyzenAPI
-- Game: AppID 494840

-- MAIN APPLICATION
addappid(494840)

-- MAIN APP DEPOTS / PACKAGES
addappid(494841, 1, "61609f23c66b061a624e3ff3aaba6340acfbcc2bae0fa7587beb8388d5c4bfe0")
addappid(3129990, 0, "b827b0e341707f1155a4752e17591ebd2d4a06ca510b56264d8f059e68cf4abc")
