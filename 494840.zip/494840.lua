-- Lua provided by RyzenAPI
-- Game: AppID 494840

-- MAIN APPLICATION
addappid(494840)

-- MAIN APP DEPOTS / PACKAGES
addappid(494841, 1, "61609f23c66b061a624e3ff3aaba6340acfbcc2bae0fa7587beb8388d5c4bfe0")
addappid(3129990, 0, "b827b0e341707f1155a4752e17591ebd2d4a06ca510b56264d8f059e68cf4abc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3985670)
