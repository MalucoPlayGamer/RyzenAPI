-- Lua provided by RyzenAPI
-- Game: 哈希绿洲 Hash Oasis

-- MAIN APPLICATION
addappid(2556450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556451, 1, "6db6a7b666608570f1521b7ba2fe4ff8c55650d84ae21005bcc6511c044ab994")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
