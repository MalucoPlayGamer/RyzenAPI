-- Lua provided by RyzenAPI
-- Game: 哈希绿洲 Hash Oasis

-- MAIN APPLICATION
addappid(2556450)
-- Game: addappid(2556450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556451, 1, "6db6a7b666608570f1521b7ba2fe4ff8c55650d84ae21005bcc6511c044ab994")
