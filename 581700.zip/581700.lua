-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(581700)
addappid(581701)
-- Game: addappid(581700)

-- MAIN APP DEPOTS / PACKAGES
addappid(581702,0,"d4a0c001c0b2ff5900f4d62931383c5800df6c0773fd817dcebe5208e887dc95")
addappid(581703,0,"999ed89cf209e6a70f43f96df16825dc354c6e16700995495e0dc34a865b870b")
addtoken(581700,14074891797495668583)
