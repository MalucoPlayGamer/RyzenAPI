-- Lua provided by RyzenAPI
-- Game: AppID 599090

-- MAIN APPLICATION
addappid(599090)

-- MAIN APP DEPOTS / PACKAGES
addappid(599091, 1, "5b7e37ef03c8a8cb01fccbc3df7714cd6dbef049b0d07cb7c3903c3de4ff78fa")

