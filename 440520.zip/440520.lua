-- Lua provided by RyzenAPI
-- Game: VirtualHere For Steam Link

-- MAIN APPLICATION
addappid(440520)

-- MAIN APP DEPOTS / PACKAGES
addappid(440522,0,"c41b72483b5113a748411157825acb01641f254680d546a88a34c9e7217bd158")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(523560)
