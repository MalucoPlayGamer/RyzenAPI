-- Lua provided by RyzenAPI
-- Game: Hero Rush: Mad King

-- MAIN APPLICATION
addappid(702190)

-- MAIN APP DEPOTS / PACKAGES
addappid(702191, 1, "0eb54f0c330828b4120020c947abadf26d429e3d8cc48c0871be071c00e65831")

