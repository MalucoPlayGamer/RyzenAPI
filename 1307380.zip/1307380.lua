-- Lua provided by RyzenAPI 
-- Game: AppID 1307380
addappid(1307380)
addappid(1307381, 1, "3b313e40eaee46ac8a5683606e9923eec74b083efbc6bacdb0dae0e8df6d7be2")
addappid(1307382, 1, "da6a7548d95ae455ff60f62a93c8db360921fe46bc11ce2f98e0f38d5cf6fc93")
