-- Lua provided by RyzenAPI
-- Game: Extreme Formula Championship Demo

-- MAIN APPLICATION
addappid(833840)
-- Game: addappid(833840)

-- MAIN APP DEPOTS / PACKAGES
addappid(833841, 1, "67eb1138117d0405fac08bce83e49480a7a6d2646594b9211bfe49335590ee78")
