-- Lua provided by RyzenAPI
-- Game: Bean There, Won That

-- MAIN APPLICATION
addappid(3130340)
-- Game: addappid(3130340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130341, 1, "190b87105d9faa50fac50e3247d057fa8b9a6710be90788892ec4655851f3b70")
