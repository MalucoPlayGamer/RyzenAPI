-- Lua provided by RyzenAPI
-- Game: Nekokami - The Human Restoration Project

-- MAIN APPLICATION
addappid(2840890)
-- Game: addappid(2840890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840891, 1, "77475e6033012e2492f7fa7201bb0e6952361009838b1e31cd610e8230f343e6")
