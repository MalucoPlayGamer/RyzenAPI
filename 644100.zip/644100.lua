-- Lua provided by RyzenAPI
-- Game: Game: AppID 644100

-- MAIN APPLICATION
addappid(644100)
-- Game: addappid(644100)

-- MAIN APP DEPOTS / PACKAGES
addappid(644101, 1, "afcf6eb723f3f92158802b7ab7819a9f827119a850605604d97d284595280eb2")
