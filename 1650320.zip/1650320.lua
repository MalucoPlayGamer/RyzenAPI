-- Lua provided by RyzenAPI
-- Game: Game: Minotaur Maze

-- MAIN APPLICATION
addappid(1650320)
-- Game: addappid(1650320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650321, 1, "ddc320f2c7870748c41ba4e4373545df136f602870e2eb06cd275ce602bd5773")
