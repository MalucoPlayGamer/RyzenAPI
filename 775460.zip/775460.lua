-- Lua provided by RyzenAPI
-- Game: The Cryptkeepers of Hallowford

-- MAIN APPLICATION
addappid(775460)

-- MAIN APP DEPOTS / PACKAGES
addappid(775461,0,"dee207c7a9417d506030040bbd9616c2ffdc20e9feba5ec0296fbcf18c71b3bf")

