-- Lua provided by RyzenAPI
-- Game: Game: Magical Girl D Demo

-- MAIN APPLICATION
addappid(1743400)
-- Game: addappid(1743400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743401, 1, "1982f7b2a264594fd1f890e3e10402cde1423991fd1d47298229ce5b7c6a0b9e")
