-- Lua provided by RyzenAPI
-- Game: 1054790

-- MAIN APPLICATION
addappid(1054790)
-- Game: addappid(1054790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054791, 1, "f5a28c176517c0c6318fec1e2a5ea8c882930139928380ba87eb6e2f1b8756e5")
