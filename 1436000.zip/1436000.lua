-- Lua provided by SkyAPI 
-- Game: AppID 1436000
addappid(1436000)
addappid(1436001, 1, "92564ca64141dcc7e65a2ef1ec0fa8452719b8eb7f90b133096526e497a71896")
