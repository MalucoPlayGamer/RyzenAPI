-- Lua provided by RyzenAPI
-- Game: 2376690

-- MAIN APPLICATION
addappid(2376690)
-- Game: addappid(2376690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376691, 1, "b7c4ca6d401662feb77102f43e40178167e9a1f83faf7e9c8ee84df77bca1fc2")
