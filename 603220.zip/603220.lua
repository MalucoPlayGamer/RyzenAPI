-- Lua provided by RyzenAPI
-- Game: ROTii

-- MAIN APPLICATION
addappid(603220)
addappid(604480)
-- Game: addappid(603220)

-- MAIN APP DEPOTS / PACKAGES
addappid(603221, 1, "6dd7c6c08cc7316a5d5af31c42604133a0351216bf3482e31ecf8ab7bcfe52b7")
addappid(603223, 1, "321a78811971798467f8a28c8e871e62f17ce52cecac2337de0d5a5cc083ae4c")
