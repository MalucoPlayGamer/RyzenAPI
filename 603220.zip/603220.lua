-- Lua provided by RyzenAPI
-- Game: ROTii

-- MAIN APPLICATION
addappid(603220)
addappid(604480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(603221, 1, "6dd7c6c08cc7316a5d5af31c42604133a0351216bf3482e31ecf8ab7bcfe52b7")
addappid(603223, 1, "321a78811971798467f8a28c8e871e62f17ce52cecac2337de0d5a5cc083ae4c")

