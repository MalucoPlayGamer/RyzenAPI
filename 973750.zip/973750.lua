-- Lua provided by RyzenAPI
-- Game: Hentai Neighbors - Sweet Summer (18+ Uncensored)

-- MAIN APPLICATION
addappid(973750)
-- Game: addappid(973750)

-- MAIN APP DEPOTS / PACKAGES
addappid(973750,0,"94960baaaaab63e6a5337f5ae48afcb86b817158d3aaba4a7f79d619bd5cfc20")
