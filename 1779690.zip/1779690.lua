-- Lua provided by RyzenAPI
-- Game: So long as there is Mercy

-- MAIN APPLICATION
addappid(1779690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779691, 1, "1c37f58f0d22e91066033830dec02d222004ab055353abb8dcb1403954f18f9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
