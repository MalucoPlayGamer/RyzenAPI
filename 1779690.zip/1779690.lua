-- Lua provided by RyzenAPI
-- Game: So long as there is Mercy

-- MAIN APPLICATION
addappid(1779690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779691, 1, "1c37f58f0d22e91066033830dec02d222004ab055353abb8dcb1403954f18f9d")
