-- Lua provided by RyzenAPI
-- Game: addappid(3124850)

-- MAIN APPLICATION
addappid(3124850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124851, 1, "7f4b1b832e0f42173a329bb0273f6d9ebb9f5bccae71fc8924f936abd229dea8")
