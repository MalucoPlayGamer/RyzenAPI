-- Lua provided by SkyAPI 
-- Game: D.O.T. Defence
addappid(3124850)
addappid(3124851, 1, "7f4b1b832e0f42173a329bb0273f6d9ebb9f5bccae71fc8924f936abd229dea8")
