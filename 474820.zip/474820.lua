-- Lua provided by RyzenAPI
-- Game: Game: AppID 474820

-- MAIN APPLICATION
addappid(474820)
-- Game: addappid(474820)

-- MAIN APP DEPOTS / PACKAGES
addappid(474821, 1, "f5bcda6a899d4cab0f66a6d326ac69dda382d4b04c7717ab34fff85b526c057d")
