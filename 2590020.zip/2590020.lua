-- Lua provided by RyzenAPI
-- Game: 2590020

-- MAIN APPLICATION
addappid(2590020)
-- Game: addappid(2590020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590021, 1, "1d2e0ac130d36cf9c31a33f86d79c6413c7fe61f4cc2141affdb48d8ab9d3d87")
