-- Lua provided by RyzenAPI
-- Game: addappid(1577080)

-- MAIN APPLICATION
addappid(1577080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1577081, 1, "42cea17220690d5ca1b183b01b24b55d110165aa00ed1dfa32dbde3bccb7acbe")
