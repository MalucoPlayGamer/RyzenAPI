-- Lua provided by RyzenAPI
-- Game: Heart Fragment

-- MAIN APPLICATION
addappid(1253880)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1775680)
addappid(1775681)
