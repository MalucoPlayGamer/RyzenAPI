-- Lua provided by RyzenAPI
-- Game: Heart Fragment

-- MAIN APPLICATION
addappid(1253880)

