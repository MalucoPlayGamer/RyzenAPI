-- Lua provided by RyzenAPI
-- Game: Meridian 59

-- MAIN APPLICATION
addappid(893390)

-- MAIN APP DEPOTS / PACKAGES
addappid(893391, 1, "06e688c20b74d87027c2926d56c0a0dccda0d2df2829e53a04a6e7f97dce81e1")

