-- Lua provided by RyzenAPI
-- Game: Aleph Null

-- MAIN APPLICATION
addappid(511420)

-- MAIN APP DEPOTS / PACKAGES
addappid(511421, 1, "11fe738ee0a54e3eacbb2e9d58490ec7db0222aeb3df82b8fc5b8a43327dc714")

