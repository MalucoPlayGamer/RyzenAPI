-- Lua provided by RyzenAPI 
-- Game: Adolescent Santa Claus
addappid(628730)
addappid(628731, 1, "36422c927c025c8348f12a4a3898693a601a057cdd5c7d5321e4953454548075")
addappid(960890, 0, "8a6d47b579f91d7735af20fada073de6bdb4d8efd56afc7f8210605adad8d049")
