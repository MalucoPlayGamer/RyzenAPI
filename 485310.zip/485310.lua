-- Lua provided by RyzenAPI
-- Game: Head Shot

-- MAIN APPLICATION
addappid(485310)

-- MAIN APP DEPOTS / PACKAGES
addappid(485311, 1, "aafec3bea3d8eb30bdf4213d4b56043b2ced4666816e05b7a0bd7895341014b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
