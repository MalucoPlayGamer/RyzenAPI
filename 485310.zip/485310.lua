-- Lua provided by RyzenAPI
-- Game: Game: Head Shot

-- MAIN APPLICATION
addappid(485310)
-- Game: addappid(485310)

-- MAIN APP DEPOTS / PACKAGES
addappid(485311, 1, "aafec3bea3d8eb30bdf4213d4b56043b2ced4666816e05b7a0bd7895341014b9")
