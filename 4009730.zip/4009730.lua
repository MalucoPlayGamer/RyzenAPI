-- Lua provided by RyzenAPI
-- Game: 4009730

-- MAIN APPLICATION
addappid(4009730)
-- Game: addappid(4009730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4009731, 1, "4af4cec8278b39079b593bb729963d97b553b1e7d29ac3eca5e5ac56b442e9f1")
