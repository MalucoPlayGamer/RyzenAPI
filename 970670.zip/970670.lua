-- Lua provided by RyzenAPI
-- Game: AppID 970670

-- MAIN APPLICATION
addappid(970670)
-- Game: addappid(970670)

-- MAIN APP DEPOTS / PACKAGES
addappid(970671, 1, "9520ef1568f231a0ba9e5c4b1aa0589d12e5e214789cce7e320c5d77d35bb7f3")
