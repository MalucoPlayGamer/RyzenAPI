-- Lua provided by RyzenAPI
-- Game: Game: Curse That Magic Cat!

-- MAIN APPLICATION
addappid(1410830)
-- Game: addappid(1410830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410831, 1, "9de510e1c2c11ba650c5f5bc3f819b19c0291fd4206aecbe3aed87a3b7e20373")
