-- Lua provided by RyzenAPI
-- Game: Curse That Magic Cat!

-- MAIN APPLICATION
addappid(1410830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1410831, 1, "9de510e1c2c11ba650c5f5bc3f819b19c0291fd4206aecbe3aed87a3b7e20373")

