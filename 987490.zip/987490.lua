-- Lua provided by RyzenAPI
-- Game: addappid(987490)

-- MAIN APPLICATION
addappid(987490)

-- MAIN APP DEPOTS / PACKAGES
addappid(987491, 1, "3a181b90d13c1017a9b779d76221d7a18a61a0d66fdc07c68ef726e47682f697")
