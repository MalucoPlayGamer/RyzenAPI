-- Lua provided by RyzenAPI
-- Game: Tunnel Escape Demo

-- MAIN APPLICATION
addappid(2963430)
-- Game: addappid(2963430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963431, 1, "44a633d7e0780d7429461b0c64ed10ebc5079021656ab6622472cd561fdee4b8")
addappid(2963433, 1, "875e41bba062068920bc795ae2842b1da1fa96dd3798d32c27377566c21894d8")
