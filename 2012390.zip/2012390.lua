-- Lua provided by RyzenAPI
-- Game: Galactic Getaway: Build a Home for Pets

-- MAIN APPLICATION
addappid(2012390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012391, 1, "40d7b1e51194f9f2f672d0ceb4c32e8eeb75cc17eef0cd813a651afcd04eccdf")

