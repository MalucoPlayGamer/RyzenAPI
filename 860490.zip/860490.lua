-- Lua provided by RyzenAPI
-- Game: Revenant Dogma

-- MAIN APPLICATION
addappid(860490)

-- MAIN APP DEPOTS / PACKAGES
addappid(860491,0,"5b99b06669fb099f009684a4b81cba11e14c6f9434216c33049faf3ceda7481b")

