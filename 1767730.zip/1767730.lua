-- Lua provided by RyzenAPI
-- Game: Crusade of Deitra

-- MAIN APPLICATION
addappid(1767730)
-- Game: addappid(1767730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767731, 1, "1ce4f0da6762fc3f4d372b002e792c2b8b24aaeb0b4d2a563d5bd167da39f33a")
