-- Lua provided by RyzenAPI
-- Game: Ultimate Ball

-- MAIN APPLICATION
addappid(2300910)
addappid(2739810)
addappid(2739820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2300911, 1, "628720d0359c9957d11eeb0b8dc3a1ce3691ebc0d55a79cab9f8a7118b82774f")

