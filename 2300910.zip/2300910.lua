-- Lua provided by RyzenAPI
-- Game: Ultimate Ball

-- MAIN APPLICATION
addappid(2300910)
addappid(2739810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300911, 1, "628720d0359c9957d11eeb0b8dc3a1ce3691ebc0d55a79cab9f8a7118b82774f")
