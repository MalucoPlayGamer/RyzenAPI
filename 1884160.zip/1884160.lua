-- Lua provided by RyzenAPI
-- Game: Tick

-- MAIN APPLICATION
addappid(1884160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884161, 1, "408f13b81bbe4a5ae8acb1cd9888f7f06774439588fc20b0b448e802c41fb11e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
