-- Lua provided by RyzenAPI
-- Game: Tick

-- MAIN APPLICATION
addappid(1884160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884161, 1, "408f13b81bbe4a5ae8acb1cd9888f7f06774439588fc20b0b448e802c41fb11e")

