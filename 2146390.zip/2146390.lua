-- Lua provided by SkyAPI 
-- Game: Ctrl Alt Deal
addappid(2146390)
addappid(2146391, 1, "dd9e0ee01dcb9df91984ff055fddc39f7611a5a86cbcf28fcbad3ff16bcdaa36")
