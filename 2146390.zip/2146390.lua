-- Lua provided by RyzenAPI
-- Game: Ctrl Alt Deal

-- MAIN APPLICATION
addappid(2146390)
-- Game: addappid(2146390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146391, 1, "dd9e0ee01dcb9df91984ff055fddc39f7611a5a86cbcf28fcbad3ff16bcdaa36")
