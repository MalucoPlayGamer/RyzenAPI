-- Lua provided by RyzenAPI
-- Game: 1328460

-- MAIN APPLICATION
addappid(1328460)
-- Game: addappid(1328460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328461, 1, "816e8c237d15023bd89a656455e2cffbe917cdf337955a6ed3a8314ecc988426")
