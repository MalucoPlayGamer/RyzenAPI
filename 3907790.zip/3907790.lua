-- Lua provided by RyzenAPI
-- Game: addappid(3907790)

-- MAIN APPLICATION
addappid(3907790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3907791, 1, "22db0cd15dfca4f2c4a944655338c6007b15260252ee974fb5f0bfdf87db60f2")
