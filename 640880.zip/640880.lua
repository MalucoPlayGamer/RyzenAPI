-- Lua provided by RyzenAPI
-- Game: Game: Hyper Sentinel

-- MAIN APPLICATION
addappid(640880)
-- Game: addappid(640880)

-- MAIN APP DEPOTS / PACKAGES
addappid(640881, 1, "02175074470ce1cf32e6c335a8119654be25500037655d3859814a907ae6ad41")
