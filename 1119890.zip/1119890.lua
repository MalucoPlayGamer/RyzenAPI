-- Lua provided by RyzenAPI 
-- Game: AppID 1119890
addappid(1119890)
addappid(1119891, 1, "357c96a9bc56413e2f685e410874f4ed7cec8ec2833d9d3f7c04d19c2b62eef0")
