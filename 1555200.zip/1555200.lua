-- Lua provided by RyzenAPI
-- Game: Flowers Blooming at the End of Summer (Free)

-- MAIN APPLICATION
addappid(1555200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555201, 1, "34667403a4f82b120ed98bfb1be2a9b768c14c7498f97d9bcc859076715c26d6")

