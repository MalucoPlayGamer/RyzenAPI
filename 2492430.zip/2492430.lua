-- Lua provided by SkyAPI 
-- Game: 火焰征程
addappid(2492430)
addappid(2492431, 1, "061f786b6b33be80b6c223185e391a38c83e3a2baab438e64d90901a495f84b7")
addappid(2492432, 1, "ad11c925bf3848a41d44ec1b6e5ad0a21fdec5a5c862e2b6809cd7d7bf2af9f5")
