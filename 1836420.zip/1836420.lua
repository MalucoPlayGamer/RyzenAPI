-- Lua provided by RyzenAPI
-- Game: 1836420

-- MAIN APPLICATION
addappid(1836420)
-- Game: addappid(1836420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836421, 1, "bbd8629289de9028bbbd4ad3c3a4509268c4471765ea63b78fcb58ba830e8835")
