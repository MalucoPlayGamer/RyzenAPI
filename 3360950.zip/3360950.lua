-- Lua provided by SkyAPI 
-- Game: Run the Rings
addappid(3360950)
addappid(3360951, 1, "16849016a045e061c1f2d6ff68c0b19cb446594e2568de558e16c5eaaa5392ae")
