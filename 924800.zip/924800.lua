-- Lua provided by RyzenAPI
-- Game: addappid(924800)

-- MAIN APPLICATION
addappid(924800)

-- MAIN APP DEPOTS / PACKAGES
addappid(924801, 1, "0ef929f4946006b1311a9774cdd8133e53e599baf914a724b4ace607e9d16e96")
