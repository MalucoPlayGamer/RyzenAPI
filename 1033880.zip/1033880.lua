-- Lua provided by RyzenAPI 
-- Game: Press F to pay respects
addappid(1033880)
addappid(1033881, 1, "d4ca4f9827be387049fd2c8692a6ed19c6fd561b62ae695271004a553d7a1b49")
