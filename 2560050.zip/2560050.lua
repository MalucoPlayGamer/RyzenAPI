-- Lua provided by RyzenAPI
-- Game: The Local

-- MAIN APPLICATION
addappid(2560050)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2560140)
