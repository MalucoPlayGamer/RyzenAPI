-- Lua provided by RyzenAPI
-- Game: The Local

-- MAIN APPLICATION
addappid(2560050)
