-- Lua provided by RyzenAPI
-- Game: No Captain Allowed!

-- MAIN APPLICATION
addappid(794350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(794351,0,"636474f18abf6d8f68c726e77e9e9bcb3e8bda4050bc46bbd3ef67bc4ad8aefa")

