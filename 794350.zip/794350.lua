-- Lua provided by RyzenAPI
-- Game: No Captain Allowed!

-- MAIN APPLICATION
addappid(794350)

-- MAIN APP DEPOTS / PACKAGES
addappid(794351,0,"636474f18abf6d8f68c726e77e9e9bcb3e8bda4050bc46bbd3ef67bc4ad8aefa")

