-- Lua provided by RyzenAPI
-- Game: Raiders of Valhalla

-- MAIN APPLICATION
addappid(2298620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298621, 1, "a0a9660399e335fd7c52b021c5687490a247379abd9572907904ef4b51bc7da2")
