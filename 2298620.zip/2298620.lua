-- Lua provided by RyzenAPI 
-- Game: Raiders of Valhalla
addappid(2298620)
addappid(2298621, 1, "a0a9660399e335fd7c52b021c5687490a247379abd9572907904ef4b51bc7da2")
