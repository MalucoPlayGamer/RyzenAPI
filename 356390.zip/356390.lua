-- Lua provided by RyzenAPI
-- Game: AppID 356390

-- MAIN APPLICATION
addappid(356390)
addappid(430400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(356391, 1, "dac420e9c88c5b3491f23313040bdac068e0c32102449527497c556b48886d1a")

