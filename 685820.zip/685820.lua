-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(685820)

-- MAIN APP DEPOTS / PACKAGES
addappid(685820,0,"9abe17864a3b8aa5c947561cf7ae2c53c23f1e3c5f4ce36c68979a4a9c8b9f2e")
