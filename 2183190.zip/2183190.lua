-- Lua provided by SkyAPI 
-- Game: OSAWARI HOCKEY えんこちゃん
addappid(2183190)
addappid(2183191, 1, "5b2458ba08ea1dc068c5dee04c4a22cc9934d5edd89ec20d752e3b11783b21ff")
