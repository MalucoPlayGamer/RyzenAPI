-- Lua provided by RyzenAPI
-- Game: Game: AppID 302200

-- MAIN APPLICATION
addappid(302200)
-- Game: addappid(302200)

-- MAIN APP DEPOTS / PACKAGES
addappid(302201, 1, "883d43b6f3ac54bfb258086c7e754053a9203cb6e0fd18b1da1c2d73830df039")
