-- Lua provided by RyzenAPI
-- Game: Quarantine

-- MAIN APPLICATION
addappid(489370)

-- MAIN APP DEPOTS / PACKAGES
addappid(489371, 1, "67773aeff73d17ee9fe185592f9855254aaa4d5351580277166d444a46636a4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
