-- Lua provided by RyzenAPI
-- Game: Quarantine

-- MAIN APPLICATION
addappid(489370)

-- MAIN APP DEPOTS / PACKAGES
addappid(489371, 1, "67773aeff73d17ee9fe185592f9855254aaa4d5351580277166d444a46636a4b")
