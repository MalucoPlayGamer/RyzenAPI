-- Lua provided by RyzenAPI
-- Game: Game: Kurukshetra: Ascension

-- MAIN APPLICATION
addappid(1857540)
-- Game: addappid(1857540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857541, 1, "2903d96e5897db86886a2e223105800d47f8eb5df5f5c3d79dd319450a4dbae4")
