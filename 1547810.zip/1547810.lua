-- Lua provided by RyzenAPI
-- Game: 1547810

-- MAIN APPLICATION
addappid(1547810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547810,0,"ef045c71c8fe1c004eb32973e1cad0e08c08d71dc342dcc55928cb6eecd3a401")

