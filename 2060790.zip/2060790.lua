-- Lua provided by SkyAPI 
-- Game: Hauntii
addappid(2060790)
addappid(2060791, 1, "6a2d2c54786c45e38c28c3cd9dd6e00bdff5071ae9b77ff215e23e49759b4b37")
addappid(2994470, 0, "29d05d91834e237b1dbdac873964a37b98f5f54a9547119d69d3f01b78175970")
