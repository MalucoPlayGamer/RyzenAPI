-- Lua provided by RyzenAPI
-- Game: Knights and Castles

-- MAIN APPLICATION
addappid(1734500)
addappid(1785290)
-- Game: addappid(1734500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734501, 1, "ae8f0e60b2ecc5f0e601c482532e5c979881788854cbe3a904e466489a1a2c11")
