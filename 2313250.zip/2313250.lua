-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Paris

-- MAIN APPLICATION
addappid(2313250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313251, 1, "c02effde40ac4d06e05f51f0778f4b028c03d8e21aa3baacb59bfb42cde46c21")
