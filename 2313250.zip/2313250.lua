-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Paris

-- MAIN APPLICATION
addappid(2313250)
addappid(2426940)
addappid(3380510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313251, 1, "c02effde40ac4d06e05f51f0778f4b028c03d8e21aa3baacb59bfb42cde46c21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
