-- Lua provided by RyzenAPI
-- Game: Game: ROMEO IS A DEAD MAN

-- MAIN APPLICATION
addappid(3050900)
-- Game: addappid(3050900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050901, 1, "f081ae2e3c7e7c843c67e6acb49e29d18dcb838d225a6942bc79ce2db85b9ac6")
