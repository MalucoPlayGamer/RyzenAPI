-- Lua provided by RyzenAPI 
-- Game: ROMEO IS A DEAD MAN
addappid(3050900)
addappid(3050901, 1, "f081ae2e3c7e7c843c67e6acb49e29d18dcb838d225a6942bc79ce2db85b9ac6")
