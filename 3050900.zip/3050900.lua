-- 3050900's Lua and Manifest Created by Hubcap Manifest
-- ROMEO IS A DEAD MAN
-- Created: August 16, 2026 at 07:13:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3050900, 1, "0a41aed2a61f5144b685f5b9b7b58bfb353ce681ef346fb5d29c432e33205ccb") -- ROMEO IS A DEAD MAN
-- MAIN APP DEPOTS
addappid(3050901, 1, "f081ae2e3c7e7c843c67e6acb49e29d18dcb838d225a6942bc79ce2db85b9ac6") -- Depot 3050901
setManifestid(3050901, "5250555546493445615", 35398168232)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- THE ART OF ROMEO IS A DEAD MAN (AppID: 3846510)
addappid(3846510)
addappid(3846510, 1, "1d9c86753215c06e6b59ce0d862cdf489f1cbc0a8e327ea2bc4fdf6b8684b03c") -- THE ART OF ROMEO IS A DEAD MAN - Depot 3846510
setManifestid(3846510, "75536163585914456", 290500479)