-- Lua provided by RyzenAPI
-- Game: AppID 650000

-- MAIN APPLICATION
addappid(650000)

-- MAIN APP DEPOTS / PACKAGES
addappid(650001, 1, "f700af8216f3f710d2fc214e454cb3604c0fd258a219ef6495d77e475fa96308")
addappid(650002, 1, "f21dc31ac152512c2888261dadc8e96cbaba051a9579d0f3fba04cabaafa9717")
addappid(650003, 1, "8ff90b5d4f32778cb81158052f370cd1450115e0c70c23aa0a4b9191dd80b3d4")
addappid(650004, 1, "1d6a6aaed671d22c907c3dc3e78ccd6c720221ca6c85db46dc696f230db05564")
addappid(650005, 1, "1eefd54c5523cc28ae6c3ea10d5ce2a2ea4c34b5a24d116d8d2ba37710c61c0e")
addappid(650006, 1, "2be994158ca0a20f74c1ec2b3503b1db982509ead9367e83c34462f60aa3587c")
addappid(650007, 1, "ec1cd625e6505b1596623f471b77d30ba5b263705357225460e1165eed4b23d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
