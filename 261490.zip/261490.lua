-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(261490)
-- Game: addappid(261490)

-- MAIN APP DEPOTS / PACKAGES
addappid(261493,0,"6e7dcbf878a9bbf4cd5a2f6a6cb783533b3b1554ab66812102f71729ac77a296")
addappid(261494,0,"98d1e703976e63bb16bf52c72eaafc316ebe9184272856e33d8ab3cc7cd89ee4")
