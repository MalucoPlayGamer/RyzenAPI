-- 4323800's Lua and Manifest Created by Hubcap Manifest
-- 关守神
-- Created: August 13, 2026 at 11:17:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4323800, 1, "ffb750a7cd7583a2fe0723d3bd242361d02cb3928a911987326f0c0a4e2c1567") -- 关守神
-- MAIN APP DEPOTS
addappid(4323801, 1, "f9300ccbb86ffe6a85435485f63ae5a4a9ceeadd4b839d3e58635a0adb91b994") -- Depot 4323801
setManifestid(4323801, "5528665336402000174", 1754210145)