-- Lua provided by RyzenAPI
-- Game: Created: August 13, 2026 at 11:17:49 EDT

-- MAIN APP DEPOTS / PACKAGES
addappid(4323800, 1, "ffb750a7cd7583a2fe0723d3bd242361d02cb3928a911987326f0c0a4e2c1567") -- 关守神
addappid(4323801, 1, "f9300ccbb86ffe6a85435485f63ae5a4a9ceeadd4b839d3e58635a0adb91b994") -- Depot 4323801

