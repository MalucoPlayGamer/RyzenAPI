-- Lua provided by RyzenAPI
-- Game: 789090

-- MAIN APPLICATION
addappid(789090)
-- Game: addappid(789090)

-- MAIN APP DEPOTS / PACKAGES
addappid(789091, 1, "965b9f31bfac81d92968edddaf2f6311f23d50f077f17e12dba2d3af221e6043")
