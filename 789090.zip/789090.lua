-- Lua provided by RyzenAPI 
-- Game: AppID 789090
addappid(789090)
addappid(789091, 1, "965b9f31bfac81d92968edddaf2f6311f23d50f077f17e12dba2d3af221e6043")
