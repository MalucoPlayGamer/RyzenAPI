-- Lua provided by SkyAPI 
-- Game: WWE 2K25
addappid(2878960)
addappid(2878961, 1, "06400ef21bacfd625a917c8964e13740059333d2173dc2496357ef23db97f483")
