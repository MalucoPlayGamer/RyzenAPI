-- Lua provided by RyzenAPI
-- Game: WWE 2K25

-- MAIN APPLICATION
addappid(2878960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878961, 1, "06400ef21bacfd625a917c8964e13740059333d2173dc2496357ef23db97f483")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3331100)
addappid(3401590)
addappid(3401600)
addappid(3401610)
addappid(3401620)
addappid(3401630)
addappid(3401640)
addappid(3401650)
addappid(3401660)
addappid(3401670)
addappid(3401680)
addappid(3401690)
addappid(3482630)
addappid(3482640)
addappid(3482860)
addappid(3785260)
addappid(3785270)
addappid(3934190)
addappid(4023140)
addappid(4023150)
