-- Lua provided by SkyAPI 
-- Game: AppID 898490
addappid(898490)
addappid(898491, 1, "a1cad13a07b5ac642b3c174e0641c1a58a9cf8e6f5dcd11a80025a5a9c1ee7f6")
