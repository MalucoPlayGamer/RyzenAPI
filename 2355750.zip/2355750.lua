-- Lua provided by RyzenAPI
-- Game: Aker Fern 2 : Demo

-- MAIN APPLICATION
addappid(2355750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355751, 1, "cb80c7813cec0762547301df4803b9e8dd233cbdc404aa0c9d7de599d89acb25")
