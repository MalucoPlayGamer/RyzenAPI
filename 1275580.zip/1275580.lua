-- Lua provided by RyzenAPI
-- Game: addappid(1275580)

-- MAIN APPLICATION
addappid(1275580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275581, 1, "f8846d42c68e58c3d854f4153e805aab755fa64123d7ca7cea618d1ba226838f")
addappid(1275582, 1, "4fa14e108c5ad78b60296b10df1274677e42b0326b4c0e1ff8fedeee2b29bb43")
