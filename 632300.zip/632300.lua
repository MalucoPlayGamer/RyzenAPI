-- Lua provided by RyzenAPI
-- Game: Hobo: Tough Life

-- MAIN APPLICATION
addappid(632300)

-- MAIN APP DEPOTS / PACKAGES
addappid(632301, 1, "f1e3666450afb59a43038cb7afb583a66b9fe73e79e1d99db59e02c91abda29e")
addappid(632302, 1, "a527ac8279aef11cc243871b0fc7ccd2a75f4824c0a1fbb1dbc2cf42e6e365b4")
addappid(1255390, 0, "cdf7211589ca4e6b4f300e61100324b6d46d63f067d323047ddeb5a34249f879")
