-- Lua provided by RyzenAPI
-- Game: addappid(2120870)

-- MAIN APPLICATION
addappid(2120870)
addappid(2394370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120871, 1, "4ae7d96e2075676e4e0b314a95c42a27aa56bf70bf30dff6b0fc6f7365a3d916")
