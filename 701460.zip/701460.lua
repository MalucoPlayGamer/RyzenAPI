-- Lua provided by RyzenAPI
-- Game: Game: AppID 701460

-- MAIN APPLICATION
addappid(701460)
-- Game: addappid(701460)

-- MAIN APP DEPOTS / PACKAGES
addappid(701461, 1, "9472f091f43801b41b761d511bdd64e8423486763debc83bbd33107d605d0745")
