-- Lua provided by RyzenAPI
-- Game: Billiards

-- MAIN APPLICATION
addappid(701460)

-- MAIN APP DEPOTS / PACKAGES
addappid(701461, 1, "9472f091f43801b41b761d511bdd64e8423486763debc83bbd33107d605d0745")
