-- Lua provided by RyzenAPI
-- Game: 2811750

-- MAIN APPLICATION
addappid(2811750)
-- Game: addappid(2811750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811751, 1, "0e5b6d44d2e7c4c03c6d11839aa348e063dbebd587e8a322ea11c77be7bdc0a2")
