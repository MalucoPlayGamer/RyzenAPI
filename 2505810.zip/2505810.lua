-- Lua provided by SkyAPI 
-- Game: 深入龙巢 Demo
addappid(2505810)
addappid(2505811, 1, "59f8c604ded88394db805b9dd4cbb630d78dc40f3e64cca069d20519ca279e37")
