-- Lua provided by RyzenAPI
-- Game: 2505810

-- MAIN APPLICATION
addappid(2505810)
-- Game: addappid(2505810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505811, 1, "59f8c604ded88394db805b9dd4cbb630d78dc40f3e64cca069d20519ca279e37")
