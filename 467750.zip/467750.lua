-- Lua provided by RyzenAPI
-- Game: Chromo XY

-- MAIN APPLICATION
addappid(467750)

-- MAIN APP DEPOTS / PACKAGES
addappid(467751, 1, "74fb76023aadd7a02c4f5b28a64238376b6a1414c919d6e9bd71cd2e05cf725e")

