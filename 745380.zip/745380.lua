-- Lua provided by RyzenAPI
-- Game: Game: Znkl - 177

-- MAIN APPLICATION
addappid(745380)
-- Game: addappid(745380)

-- MAIN APP DEPOTS / PACKAGES
addappid(745381, 1, "5aae470e86bcd49fb952d586427cd6d6ff05c55a6d25fc1b061f27c14b7b4c47")
