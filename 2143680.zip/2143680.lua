-- Lua provided by RyzenAPI
-- Game: 梦灯花

-- MAIN APPLICATION
addappid(2143680)
addappid(2875660)
addappid(3879310)
addappid(3915560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143681, 1, "f5d8ce3a9f4f95d8e0a4367c3add3fc756cc8e301455dac56682f2ebe15bd74f")
