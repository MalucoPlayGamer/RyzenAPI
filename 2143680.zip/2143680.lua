-- Lua provided by RyzenAPI 
-- Game: AppID 2143680
addappid(2143680)
addappid(2143681, 1, "f5d8ce3a9f4f95d8e0a4367c3add3fc756cc8e301455dac56682f2ebe15bd74f")
