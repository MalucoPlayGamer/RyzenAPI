-- Lua provided by RyzenAPI
-- Game: 830580

-- MAIN APPLICATION
addappid(830580)
-- Game: addappid(830580)

-- MAIN APP DEPOTS / PACKAGES
addappid(830581, 1, "9b4deefebfaa6d1f54cec5e7c1687f09d01f7a9ee1e73317f32eb829f1bd68df")
