-- Lua provided by RyzenAPI
-- Game: BattleBeasts

-- MAIN APPLICATION
addappid(830580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(830581, 1, "9b4deefebfaa6d1f54cec5e7c1687f09d01f7a9ee1e73317f32eb829f1bd68df")

