-- Lua provided by RyzenAPI
-- Game: Supraland

-- MAIN APPLICATION
addappid(813630)
addappid(1093730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(813631, 1, "58f782b2875327edd8542dd2c34a3e1004cbf5c26e4cdf81310ffa3186ebc505")
