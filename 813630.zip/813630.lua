-- Lua provided by RyzenAPI
-- Game: addappid(813630)

-- MAIN APPLICATION
addappid(813630)

-- MAIN APP DEPOTS / PACKAGES
addappid(813631, 1, "58f782b2875327edd8542dd2c34a3e1004cbf5c26e4cdf81310ffa3186ebc505")
