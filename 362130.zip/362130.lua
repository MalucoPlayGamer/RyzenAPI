-- Lua provided by RyzenAPI
-- Game: Ashes of Immortality

-- MAIN APPLICATION
addappid(362130)

-- MAIN APP DEPOTS / PACKAGES
addappid(362131, 1, "6682901b1dbe82f8c3ceb9042eb7f76d060272c07aa76f331654a8cbe370927b")

