-- Lua provided by RyzenAPI
-- Game: WGT Golf

-- MAIN APPLICATION
addappid(1182020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182021, 1, "e9d9f0fb9746b747bb2eb19fa74297a0c53a887dbcf7fe5048c43b5813c15db7")
addappid(1182022, 1, "73cda5e05e4ee4abbdf3ebf67ff0fa13b088c5f72e404f8679bf049a4c51211c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1353480)
addappid(1353490)
addappid(1354410)
addappid(1355150)
addappid(1355151)
addappid(1770520)
addappid(1770521)
addappid(2402570)
