-- Lua provided by RyzenAPI
-- Game: Siren Head Horror Bunker VR

-- MAIN APPLICATION
addappid(1699880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699881, 1, "39a0ea57abd47a1762efe70de995b631bfed8f17e7d7e0157e1419528bf4daec")
