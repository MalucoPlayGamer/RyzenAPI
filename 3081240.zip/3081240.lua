-- Lua provided by RyzenAPI
-- Game: Game: AppID 3081240

-- MAIN APPLICATION
addappid(3081240)
-- Game: addappid(3081240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081241, 1, "8998ba702ef77702f501bdd727d9b458224739e9e0362f47bc809d0bb066a7d9")
