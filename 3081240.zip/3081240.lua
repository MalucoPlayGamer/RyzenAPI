-- Lua provided by RyzenAPI
-- Game: 少女怪奇事件簿:永生 Salvation:Immortale

-- MAIN APPLICATION
addappid(3081240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081241, 1, "8998ba702ef77702f501bdd727d9b458224739e9e0362f47bc809d0bb066a7d9")

