-- Lua provided by RyzenAPI
-- Game: 1676750

-- MAIN APPLICATION
addappid(1676750)
-- Game: addappid(1676750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676751, 1, "8d092550fa928d974ad55291bf15b440f48f6b6e473c5c7668c5718b901ecdf8")
