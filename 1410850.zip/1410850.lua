-- Lua provided by RyzenAPI
-- Game: addappid(1410850)

-- MAIN APPLICATION
addappid(1410850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410851, 1, "e975530674a5a2524289e20b781f82690bac88ba6c04fa65535f7ce7a2e56fe2")
