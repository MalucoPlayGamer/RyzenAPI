-- Lua provided by RyzenAPI 
-- Game: Space Smack!
addappid(1410850)
addappid(1410851, 1, "e975530674a5a2524289e20b781f82690bac88ba6c04fa65535f7ce7a2e56fe2")
