-- Lua provided by RyzenAPI
-- Game: Space Smack!

-- MAIN APPLICATION
addappid(1410850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1410851, 1, "e975530674a5a2524289e20b781f82690bac88ba6c04fa65535f7ce7a2e56fe2")

