-- Lua provided by RyzenAPI 
-- Game: Beam Eye Tracker Demo
addappid(2582050)
addappid(2582051, 1, "e018272b4ac2b0fd2d7c15d339950c174aea40d31b0f93f9f9a5dc89312f4c7b")
