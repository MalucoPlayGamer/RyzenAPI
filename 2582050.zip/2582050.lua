-- Lua provided by RyzenAPI
-- Game: addappid(2582050)

-- MAIN APPLICATION
addappid(2582050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582051, 1, "e018272b4ac2b0fd2d7c15d339950c174aea40d31b0f93f9f9a5dc89312f4c7b")
