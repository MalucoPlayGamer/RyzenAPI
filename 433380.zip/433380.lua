-- Lua provided by RyzenAPI 
-- Game: AppID 433380
addappid(433380)
addappid(433381, 1, "37103129e28b3abf08f4fda349c29b08bf23598100d3179113e029a3f4932911")
