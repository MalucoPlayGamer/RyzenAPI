-- Lua provided by RyzenAPI 
-- Game: Party Golf
addappid(538550)
addappid(538551, 1, "6297e8e1a24cf43cf55d0ff594b70111e4a7e3a8ce5db265bfdc5dc767a7abba")
