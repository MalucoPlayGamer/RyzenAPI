-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2932950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932952,0,"3d817928d78f5f07145a32a68d1bb00c4ab0c162ec6d53c627b1cfac55757fe0")

