-- Lua provided by RyzenAPI
-- Game: Gachi-Natsu Soundtrack

-- MAIN APPLICATION
addappid(2182210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182212,0,"ab0c72691832b8c648b35a0b32457fc4425c3d8e0bbfbbacfe8a32b5218aab51")
addappid(2182213,0,"2954da533d67b5a38ba2d0ecd8a0050caaf3ef78ff200ddf6710e638d51aa2a2")
