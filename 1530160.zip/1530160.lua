-- Lua provided by RyzenAPI
-- Game: Digimon World: Next Order

-- MAIN APPLICATION
addappid(1530160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530161, 1, "79f6668266ed6a85515dbd54406ca18c6268feafc1e8f239ee78bad23087dd8d")
