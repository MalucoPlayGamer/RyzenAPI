-- Lua provided by RyzenAPI
-- Game: Thymesia Original Soundtrack

-- MAIN APPLICATION
addappid(2117330)
-- Game: addappid(2117330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117331, 1, "ad99d0552579af595eaf8e780b12c0a0f33ac2eaa64472069f4991b1e00b7007")
addappid(2117332, 1, "809ad83004e4e93e7d965ff03fa49dab62f11103178984ce66b64f94dcb8712f")
