-- Lua provided by RyzenAPI
-- Game: AppID 725120

-- MAIN APPLICATION
addappid(725120)
-- Game: addappid(725120)

-- MAIN APP DEPOTS / PACKAGES
addappid(725121, 1, "1f624de33aaa414176c42ef71d1aa2f0645133ad13e3bf3e557856211e8313ae")
