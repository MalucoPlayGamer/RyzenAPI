-- Lua provided by RyzenAPI
-- Game: addappid(3081060)

-- MAIN APPLICATION
addappid(3081060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081061, 1, "d29870a582449d4ab8941cab23df859f2c9dc3949f7264b8eb4ad87372d2d436")
