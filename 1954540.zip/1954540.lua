-- Lua provided by RyzenAPI
-- Game: AppID 1954540

-- MAIN APPLICATION
addappid(1954540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954541, 1, "7632c790acd09c7eaaea2d140d9a38904bc579720c198ac28c2e78a1b49b4cba")
