-- Lua provided by RyzenAPI
-- Game: Southfield Demo

-- MAIN APPLICATION
addappid(2601090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601091, 1, "8f079015dbb6f7257e113d6585253cf49ba456a605a3acd446c034fd14f07320")

