-- Lua provided by RyzenAPI 
-- Game: Arena of the Titans
addappid(3206090)
addappid(3206091, 1, "876fe451438c2070aab23b2e1cf39b78f55383724c4894b7a4a2e22855245a48")
