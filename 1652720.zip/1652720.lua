-- Lua provided by RyzenAPI
-- Game: Hextones: Spacetime

-- MAIN APPLICATION
addappid(1652720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652721, 1, "4663e21886943b4203600e32fd4b10d7b7e1ce9ea0b1fc0f4c42793fec479433")
addappid(1652722, 1, "f6804710b565ed325f9dbc1e1ee8641b7b0c6a00ffd3a7b3d8cd516b9648ec4f")
