-- Lua provided by RyzenAPI
-- Game: 978867

-- MAIN APPLICATION
addappid(978867)
-- Game: addappid(978867)

-- MAIN APP DEPOTS / PACKAGES
addappid(978867,0,"833dcb7dee5638e60be6bc2883fa275f888f5de3c6ed67200ebacbf576ec91a9")
