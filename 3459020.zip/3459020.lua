-- Lua provided by RyzenAPI
-- Game: addappid(3459020)

-- MAIN APPLICATION
addappid(3459020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3459021, 1, "0aef4f3b92f3a087a572f437a18b70ee5803269f1a7ccd2e24da3aede5bbf55d")
