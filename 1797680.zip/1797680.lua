-- Lua provided by RyzenAPI
-- Game: Wee Tanks!

-- MAIN APPLICATION
addappid(1797680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797681, 1, "eb68487f9e715ad50a2c0b91cb97592defe97a3b56818e8f990e8693b624d6a3")

