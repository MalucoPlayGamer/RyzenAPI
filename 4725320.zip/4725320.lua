-- Lua provided by RyzenAPI
-- Game: Blood in the Ice

-- MAIN APPLICATION
addappid(4725320)

-- MAIN APP DEPOTS / PACKAGES
addappid(4725321, 1, "cb1351ea55f4b86759f70d583c64f4473ab5287b0ce9c61d2a3060836137854b")

