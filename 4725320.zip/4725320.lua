-- Generated with Luie @ https://lua.tools/
-- 4725320 - Blood in the Ice
-- Generated 2026-08-27 22:26:49 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4725320)

-- Main Depots
addappid(4725321, 1, "cb1351ea55f4b86759f70d583c64f4473ab5287b0ce9c61d2a3060836137854b")
setManifestid(4725321, "7513393872815979499", 116262654)
