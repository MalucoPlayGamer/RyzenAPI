-- Lua provided by RyzenAPI
-- Game: Game: The Lord of Time

-- MAIN APPLICATION
addappid(2837420)
-- Game: addappid(2837420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837421, 1, "e4465e14ca92cd860b9c4e2fb795a4523f4943a9fb7307171cb5e319f70d4fd1")
