-- Lua provided by RyzenAPI
-- Game: AppID 3533100

-- MAIN APPLICATION
addappid(3533100)
-- Game: addappid(3533100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3533101, 1, "165e0dadd51768e263a833318ade634f7f7a76a7fcf9d32356eb4a03e64f0f90")
