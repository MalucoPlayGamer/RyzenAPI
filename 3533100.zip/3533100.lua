-- Lua provided by RyzenAPI
-- Game: Wrap House Simulator🌯

-- MAIN APPLICATION
addappid(3533100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3533101, 1, "165e0dadd51768e263a833318ade634f7f7a76a7fcf9d32356eb4a03e64f0f90")

