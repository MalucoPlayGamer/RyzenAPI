-- Lua provided by RyzenAPI
-- Game: Team Sonic Racing™

-- MAIN APPLICATION
addappid(785260)

-- MAIN APP DEPOTS / PACKAGES
addappid(785261, 1, "9d51fe375965802388bc5c627589d5a41f3fad4ba0270d6f7dcf5fe5fe9a886c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
