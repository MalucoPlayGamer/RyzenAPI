-- Lua provided by RyzenAPI
-- Game: Touhou Hero of Ice Fairy DLC1 - Rose Idol

-- MAIN APPLICATION
addappid(3213970)
-- Game: addappid(3213970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213970,0,"8aa8c519999b733e62801b312663af06939b9ca56e89c3fde921f995fc6f56a8")
