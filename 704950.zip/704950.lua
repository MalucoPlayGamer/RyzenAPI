-- Lua provided by RyzenAPI
-- Game: Scarlett's Dungeon

-- MAIN APPLICATION
addappid(704950)

-- MAIN APP DEPOTS / PACKAGES
addappid(704951,0,"6fce6f7b1f0657687eca31ecab3ecfdfee339172efcc523fed341922b034f3cf")

