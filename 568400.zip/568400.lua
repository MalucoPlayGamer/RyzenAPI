-- Lua provided by RyzenAPI
-- Game: Depths of Limbo

-- MAIN APPLICATION
addappid(568400)
addappid(579860)

-- MAIN APP DEPOTS / PACKAGES
addappid(568401, 1, "0a85697947dfa8a42c77959efa359dd5f5a66c587bc9851ba6145ec99e1a6dcc")
addappid(568402, 1, "b03bef3ddbd2e708ec484965ba969a975e32e65510ddaa32f7ce92ad7d87e06e")
addappid(568403, 1, "a56ca478d64f1d0fb7259791f30c9862b3bb188ec6faf1442c097b8e3d5a5233")
addappid(568404, 1, "5dfd8c1ad662cfa9c4836d7379ce418f7b440177f28191fde043e2e315924f98")

