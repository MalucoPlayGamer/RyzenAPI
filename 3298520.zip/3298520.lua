-- Lua provided by RyzenAPI
-- Game: Idle Iktah

-- MAIN APPLICATION
addappid(3298520)

