-- Lua provided by RyzenAPI
-- Game: Blood West

-- MAIN APPLICATION
addappid(1587130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587131, 1, "d3b09a2ce3e50bcdc756c824fc4c55fb27e7ce2af1e9f9d43b89f4781acf8383")
addappid(3158590, 0, "ce8e093dd1f41a4afbd46af1e713952ba4c7aacc718a1980b319ddf880e57b71")

