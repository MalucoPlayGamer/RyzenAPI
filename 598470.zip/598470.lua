-- Lua provided by RyzenAPI
-- Game: AppID 598470

-- MAIN APPLICATION
addappid(598470)

-- MAIN APP DEPOTS / PACKAGES
addappid(598471, 1, "77d6cacb9a02ad73a0c9a54e87abadb025a5faa128421b5ba051deeb803837c0")
