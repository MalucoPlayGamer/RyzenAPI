-- Lua provided by RyzenAPI
-- Game: Game: Christmas Journey to Santa

-- MAIN APPLICATION
addappid(2815100)
-- Game: addappid(2815100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815101, 1, "b11443a9bd5b7057e4ab581c2f19863b8886422e1a775ce7e0a05e319f9cea44")
