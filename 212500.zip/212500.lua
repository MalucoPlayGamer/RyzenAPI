-- Lua provided by RyzenAPI
-- Game: The Lord of the Rings Online™

-- MAIN APPLICATION
addappid(212500)
