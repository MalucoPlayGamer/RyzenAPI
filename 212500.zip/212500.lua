-- Lua provided by RyzenAPI
-- Game: The Lord of the Rings Online™

-- MAIN APPLICATION
addappid(212500)
addappid(213170)
addappid(213171)
addappid(213172)
addappid(213173)
addappid(213174)
addappid(213175)
addappid(213176)
addappid(213177)
addappid(213178)
addappid(213179)
addappid(258800)
addappid(258803)
addappid(258804)

