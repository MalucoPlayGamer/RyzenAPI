-- Lua provided by RyzenAPI
-- Game: The Hand of Glory - The Blowtorch Files

-- MAIN APPLICATION
addappid(1950020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950022,0,"08e92b8e04973105e2360ab303129238f8cc45ccbaf8b873e94bfcfebe0c5858")

