-- Lua provided by SkyAPI 
-- Game: AppID 868830
addappid(868830)
addappid(868831, 1, "a04676c67540c0d2c8e5c712a502dcb59156c877f35e69ae7ab28e9877272331")
