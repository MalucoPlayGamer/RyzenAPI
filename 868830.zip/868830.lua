-- Lua provided by RyzenAPI
-- Game: Rio Rex

-- MAIN APPLICATION
addappid(868830)
-- Game: addappid(868830)

-- MAIN APP DEPOTS / PACKAGES
addappid(868831, 1, "a04676c67540c0d2c8e5c712a502dcb59156c877f35e69ae7ab28e9877272331")
