-- Lua provided by RyzenAPI
-- Game: addappid(3274540)

-- MAIN APPLICATION
addappid(3274540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274541, 1, "986bc4ec27957c4c7b3054114ab68aad6ab9be38e057b70791efa03692fc9161")
