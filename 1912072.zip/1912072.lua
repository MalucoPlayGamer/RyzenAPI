-- Lua provided by RyzenAPI
-- Game: addappid(1912072)

-- MAIN APPLICATION
addappid(1912072)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912072,0,"48a4fc26cf1e899e5817f72cb9df0b3199c93d6f9ce010aeb7f6c356934d8974")
