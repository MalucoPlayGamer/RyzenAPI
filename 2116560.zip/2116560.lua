-- Lua provided by RyzenAPI
-- Game: Cepheus Protocol Playtest

-- MAIN APPLICATION
addappid(2116560)
-- Game: addappid(2116560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116561, 1, "350758c4a424513376ce9af0e97878bd811f740be6590aea2e2297bc85813618")
