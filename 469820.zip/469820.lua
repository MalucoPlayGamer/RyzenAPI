-- Lua provided by RyzenAPI
-- Game: Genital Jousting

-- MAIN APPLICATION
addappid(469820)

-- MAIN APP DEPOTS / PACKAGES
addappid(469821, 1, "6317b276f5f1d6bed97a40ab77bb91875303a4414e00ef3a3633f8878541af7b")
addappid(469822, 1, "fb50a96f9fa7ec86814f05924b523e0f42fd16a9e25ae88ddc1185dea2a59006")

