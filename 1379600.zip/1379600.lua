-- Lua provided by RyzenAPI
-- Game: Pandemic Train

-- MAIN APPLICATION
addappid(1379600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379601, 1, "fa33ce8e097b7dfdfaa499a886e6a51d0cd22380e55c3afc242a255d1fcfb0c9")

