-- Lua provided by RyzenAPI 
-- Game: Minicology
addappid(1471700)
addappid(1471701, 1, "ba1a27acb8fb1e3fe63395cf3a72f9441707b7e409cfd878039bf5e747a7f05e")
