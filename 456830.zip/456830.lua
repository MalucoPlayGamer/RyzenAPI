-- Lua provided by RyzenAPI
-- Game: Game: AppID 456830

-- MAIN APPLICATION
addappid(456830)
-- Game: addappid(456830)

-- MAIN APP DEPOTS / PACKAGES
addappid(456831, 1, "f32381adcce86e124881c7e05c0261cc8f8eb68a94e38b8310ddba83acb20171")
