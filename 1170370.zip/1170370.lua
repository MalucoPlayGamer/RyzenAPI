-- Lua provided by RyzenAPI
-- Game: Game: Whimsy

-- MAIN APPLICATION
addappid(1170370)
-- Game: addappid(1170370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170371, 1, "64feb51b8bca43a3a7c281ab247ad0dd500cfdb96acb1778061e65d717576774")
