-- Lua provided by RyzenAPI
-- Game: 1315160

-- MAIN APPLICATION
addappid(1315160)
-- Game: addappid(1315160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315161, 1, "dc49ff9946c705f1ce7be6cabe80ac0e06866918ade00f18198db0a55fd479da")
