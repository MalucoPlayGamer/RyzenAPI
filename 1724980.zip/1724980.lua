-- Lua provided by RyzenAPI
-- Game: setManifestid(1724982,"3902615790522263367")

-- MAIN APPLICATION
addappid(1724980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724982,0,"2ef8f742f248b82ae878fbcdc446529d2f2cfa5ce12cf97e7f53f3a14947ecc8")

