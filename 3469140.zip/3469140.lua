-- Lua provided by RyzenAPI
-- Game: Backrooms: The Yellow Dream

-- MAIN APPLICATION
addappid(3469140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3469144,0,"7e4204d0233020a51137107effb1490b2abad2675f727230e67c3facf82f3708")

