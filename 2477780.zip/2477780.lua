-- Lua provided by RyzenAPI
-- Game: Roguenarok

-- MAIN APPLICATION
addappid(2477780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477781, 1, "dd7dc9407d46b56cc8b8cfc4df19fdd089102fac5cb302ef691d3b5338e198bf")

