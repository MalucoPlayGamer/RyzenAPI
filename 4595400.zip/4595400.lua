-- Lua provided by RyzenAPI
-- Game: Erotic Clicker

-- MAIN APPLICATION
addappid(4595400) -- Erotic Clicker

-- MAIN APP DEPOTS / PACKAGES
addappid(4595401, 1, "e6049fa1b8bb7fde3384d861b771a48c50003f08bc6fda9995316e435fb61503") -- Depot 4595401

