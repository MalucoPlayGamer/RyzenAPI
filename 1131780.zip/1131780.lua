-- Lua provided by RyzenAPI
-- Game: Mustache or Revenge

-- MAIN APPLICATION
addappid(1131780)
-- Game: addappid(1131780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131781, 1, "b250883b15ea0ee9b2689a393aba69f1d0eb88c47ff980f0a11b7b4c6b160234")
