-- Lua provided by RyzenAPI 
-- Game: AppID 2074650
addappid(2074650)
addappid(2074651, 1, "5034cfa5922cb468f2f0d9976f474faf666e38b1f590203a2f66075ec32ba8ad")
