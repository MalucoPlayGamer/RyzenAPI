-- Lua provided by RyzenAPI
-- Game: addappid(2734820)

-- MAIN APPLICATION
addappid(2734820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2734821, 1, "e346d2aabefeca9843374ad52a3fbe7d909513fcb3050b9b304581524e10d3c8")
