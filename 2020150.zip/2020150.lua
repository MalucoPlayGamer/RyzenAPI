-- Lua provided by RyzenAPI
-- Game: Game: Forbidden Ninja Scroll: Kunoichi Training Demo

-- MAIN APPLICATION
addappid(2020150)
-- Game: addappid(2020150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020151, 1, "21069da94bfae998579e72c4f149ac0542d50e50d6ec84c95ff200675b69e641")
