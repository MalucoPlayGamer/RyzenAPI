-- Lua provided by RyzenAPI
-- Game: addappid(907310)

-- MAIN APPLICATION
addappid(907310)

-- MAIN APP DEPOTS / PACKAGES
addappid(907311, 1, "17a93a3e4b9315d31eb0ac8cfa9cdfc20cc946d6522e4501e39d59976e86056e")
