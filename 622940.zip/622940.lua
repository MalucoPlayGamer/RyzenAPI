-- Lua provided by RyzenAPI
-- Game: 622940

-- MAIN APPLICATION
addappid(622940)
-- Game: addappid(622940)

-- MAIN APP DEPOTS / PACKAGES
addappid(622941, 1, "f6724eb1c9d98c81fccdb07cb14068e0430ef15926525fc6b1551cb39a15d811")
