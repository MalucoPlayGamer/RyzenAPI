-- Lua provided by RyzenAPI
-- Game: Electronics Puzzle Lab

-- MAIN APPLICATION
addappid(2567620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567621, 1, "df4dc8818b06f7b3802020a9c845234d97391ccdf389f2598b3d76668d5d267b")
