-- Lua provided by RyzenAPI
-- Game: ModLab

-- MAIN APPLICATION
addappid(768970)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(768971, 1, "d4e76d27dff5522beb8d09a74d52b87289afaf51c46c5e0a4272e3dab69c0c71")

