-- Lua provided by RyzenAPI
-- Game: AppID 768970

-- MAIN APPLICATION
addappid(768970)

-- MAIN APP DEPOTS / PACKAGES
addappid(768971, 1, "d4e76d27dff5522beb8d09a74d52b87289afaf51c46c5e0a4272e3dab69c0c71")

