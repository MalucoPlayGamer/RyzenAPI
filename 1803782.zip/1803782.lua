-- Lua provided by RyzenAPI
-- Game: Surviving the Aftermath - Rebirth

-- MAIN APPLICATION
addappid(1803782)
-- Game: addappid(1803782)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803782,0,"9e9b910c801d8a2c5662f93f80407a600982b100311bb36c81ce609d48bb73c4")
