-- Lua provided by RyzenAPI
-- Game: Game: Dragonpath

-- MAIN APPLICATION
addappid(425820)
-- Game: addappid(425820)

-- MAIN APP DEPOTS / PACKAGES
addappid(425821, 1, "9bb899ceeebbaea40537293d3a5274715f665361c85843025198f8e727059535")
