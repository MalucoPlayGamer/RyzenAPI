-- Lua provided by SkyAPI 
-- Game: Dragonpath
addappid(425820)
addappid(425821, 1, "9bb899ceeebbaea40537293d3a5274715f665361c85843025198f8e727059535")
