-- Lua provided by RyzenAPI
-- Game: AppID 1398620

-- MAIN APPLICATION
addappid(1398620)
-- Game: addappid(1398620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398621, 1, "ed93ffa66add46217140e798e8c01a2f093ba026cca65e22785a88574880cea5")
