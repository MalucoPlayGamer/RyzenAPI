-- Lua provided by RyzenAPI
-- Game: Budget Cuts

-- MAIN APPLICATION
addappid(400940)

-- MAIN APP DEPOTS / PACKAGES
addappid(400941, 1, "fc6cdd47c1c056649e954e201860baf4f11f8b6644ccecf30876dddc25fafc82")
