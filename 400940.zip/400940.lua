-- Lua provided by SkyAPI 
-- Game: Budget Cuts
addappid(400940)
addappid(400941, 1, "fc6cdd47c1c056649e954e201860baf4f11f8b6644ccecf30876dddc25fafc82")
