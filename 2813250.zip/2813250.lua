-- Lua provided by RyzenAPI
-- Game: addappid(2813250)

-- MAIN APPLICATION
addappid(2813250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2813251, 1, "ffe8a853b907acb8f20df8b1ff56395c3b798194b98ec5b0ec84276313a8ac18")
