-- Lua provided by RyzenAPI 
-- Game: Lost In Failures
addappid(2813250)
addappid(2813251, 1, "ffe8a853b907acb8f20df8b1ff56395c3b798194b98ec5b0ec84276313a8ac18")
