-- Lua provided by RyzenAPI 
-- Game: Nephise
addappid(606860)
addappid(606861, 1, "10e1167d3719c70f2988bbcf7fc36d6f377e44b2b7fcbe869fab40e6d4efa27f")
