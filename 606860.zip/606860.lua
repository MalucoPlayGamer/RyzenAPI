-- Lua provided by RyzenAPI
-- Game: 606860

-- MAIN APPLICATION
addappid(606860)
-- Game: addappid(606860)

-- MAIN APP DEPOTS / PACKAGES
addappid(606861, 1, "10e1167d3719c70f2988bbcf7fc36d6f377e44b2b7fcbe869fab40e6d4efa27f")
