-- Lua provided by RyzenAPI
-- Game: Game: AppID 2989460

-- MAIN APPLICATION
addappid(2989460)
-- Game: addappid(2989460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989461, 1, "13d35aea2041f481d847a5a0ad57c56503ca6c540e36100c30968d13664ed0d5")
