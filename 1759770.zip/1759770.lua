-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1759770)
-- Game: addappid(1759770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759770,0,"a2b6ed720118943b7d8b3546e1b2e8c502f8879509f7687a8c7086bf94a48ff7")
