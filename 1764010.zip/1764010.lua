-- Lua provided by SkyAPI 
-- Game: Gold Miner
addappid(1764010)
addappid(1764011, 1, "fba0cb4c299baf1de68a282a52ae2e6acc48636e0a1fdb8d27b81b9c2f5bee23")
