-- Lua provided by RyzenAPI
-- Game: METAL SUITS: Counter-attack

-- MAIN APPLICATION
addappid(2093800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093801, 1, "4da581b9f61c51a79d3a81defa888299c496d7ea9da4aebac59891d9ff431dd0")

