-- Lua provided by RyzenAPI
-- Game: Fantasy Sliding Puzzle 2

-- MAIN APPLICATION
addappid(1760590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760591, 1, "46439a9b3e9436c5b03305a1ac52cfbd771dfb89438b11761fd80bd5149ba82d")
addappid(1760630, 0, "949cc2c32a25443a958fd6f7a1726b62356a05525873056d78ebc0fc9832e40e")
