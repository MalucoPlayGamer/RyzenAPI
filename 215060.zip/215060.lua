-- Lua provided by RyzenAPI
-- Game: 215060

-- MAIN APPLICATION
addappid(215060)
-- Game: addappid(215060)

-- MAIN APP DEPOTS / PACKAGES
addappid(215061, 1, "8908415b23ab39a67938f2c2f22bdd55755a82f5532f55fd89426c43ebd73081")
