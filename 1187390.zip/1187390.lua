-- Lua provided by RyzenAPI
-- Game: Occupy Mars: Supporter Pack: Official Soundtrack, ArtBook, Comic Book & more

-- MAIN APPLICATION
addappid(1187390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187390,0,"8ab19d74f72f0ed958470610fd2fc94130e3955ce67ace55176b54016c83e1be")

