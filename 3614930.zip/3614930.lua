-- Lua provided by RyzenAPI
-- Game: ZDSimulator - Kyiv-Shepetivka Route

-- MAIN APPLICATION
addappid(3614930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614930,0,"db06701b466916ff797fa3990e6f810fac323e2cb7815e5443a343ec5ac675e1")
