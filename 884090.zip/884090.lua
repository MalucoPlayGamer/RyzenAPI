-- Lua provided by SkyAPI 
-- Game: Idle Dungeons
addappid(884090)
addappid(884091, 1, "1d30c53ce5dc4c755729ce5a740b03e30272ff6ff082a41162b331da57940713")
