-- Lua provided by RyzenAPI
-- Game: Tubular Rift

-- MAIN APPLICATION
addappid(717680)

-- MAIN APP DEPOTS / PACKAGES
addappid(717683,0,"d7300d99c52d1904183f1d3e76618642689b0fdba9ed8680245cc55126b4a3ec")

