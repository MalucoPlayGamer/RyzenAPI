-- Lua provided by RyzenAPI
-- Game: 448540

-- MAIN APPLICATION
addappid(448540)
-- Game: addappid(448540)

-- MAIN APP DEPOTS / PACKAGES
addappid(448541, 1, "8a502b1dca4c3f0026693746b178171907dee638348ef1acfa2608833c6ed853")
addappid(448542, 1, "fd0527e6f2d83d6dde4f5d9984a1e2249f800f2372fad233b4c4b7b3bb7c14c5")
addappid(448543, 1, "97874822b226c944d1fcddfe2c468ccd6d9aef439e7efb5a2481d4f8d5764c2a")
