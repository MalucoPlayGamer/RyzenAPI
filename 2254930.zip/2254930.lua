-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 It’s a Night Magic Lucky Bag Ver.Dark

-- MAIN APPLICATION
addappid(2254930)
-- Game: addappid(2254930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254931, 1, "da84c799913b61329c6537f37622e4005ba6bffaa1c6a5af8c05cc05def2f7d8")
addappid(2254932, 1, "662a3ac5984a5f9d63533a2339622b8f51cbb3f17c6b72a9f62833129d0ef3e9")
addappid(2254933, 1, "8b9efb58290001a32ad51fcc8a562321f6b225cbc3c0938ece9823d282803c80")
