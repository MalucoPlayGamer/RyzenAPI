-- Lua provided by RyzenAPI 
-- Game: Crayon Physics Deluxe
addappid(26900)
addappid(26901, 1, "5c5e65a15c732d1320726b13a5ad7125ab9ea042a5480accfb7d514f370dc2f1")
addappid(26902, 1, "e65b22497039e6e724ce201e08ba78539135bc67626f944ce879859e2f914bb8")
