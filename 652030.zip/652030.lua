-- Lua provided by RyzenAPI
-- Game: AppID 652030

-- MAIN APPLICATION
addappid(652030)
-- Game: addappid(652030)

-- MAIN APP DEPOTS / PACKAGES
addappid(652031, 1, "0f26cce1c0b32743c4f974d53480f0aec4167d4dd543b81f430061c976ff24d2")
