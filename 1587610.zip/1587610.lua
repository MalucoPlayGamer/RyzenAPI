-- Lua provided by RyzenAPI
-- Game: Game: Little drift

-- MAIN APPLICATION
addappid(1587610)
-- Game: addappid(1587610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587611, 1, "7a4c49c8c423e5a91a571a3f5382239dab9704579579ab0eda767fa9b5405170")
