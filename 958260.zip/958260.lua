-- Lua provided by RyzenAPI
-- Game: AppID 958260

-- MAIN APPLICATION
addappid(958260)
-- Game: addappid(958260)

-- MAIN APP DEPOTS / PACKAGES
addappid(958261, 1, "47a7073965d982c132fbec7844f17a3acf0ec4133cd86f8f39ab239ae4942718")
