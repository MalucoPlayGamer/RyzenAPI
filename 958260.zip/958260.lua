-- Lua provided by RyzenAPI
-- Game: AppID 958260

-- MAIN APPLICATION
addappid(958260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(958261, 1, "47a7073965d982c132fbec7844f17a3acf0ec4133cd86f8f39ab239ae4942718")

