-- Lua provided by RyzenAPI
-- Game: Beat Saber - Queen - Killer Queen

-- MAIN APPLICATION
addappid(2407765)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407765,0,"5ffcc637d6c26fe0db60a5d7c5594031aa3985f7e38bb060542697d359d5c4f7")

