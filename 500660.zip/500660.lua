-- Lua provided by RyzenAPI
-- Game: 500660

-- MAIN APPLICATION
addappid(500660)
-- Game: addappid(500660)

-- MAIN APP DEPOTS / PACKAGES
addappid(500661, 1, "771c1cccf073f5f64d8e40948a09d94f3d05da06f6e96f1793dd86452b3ba6ca")
