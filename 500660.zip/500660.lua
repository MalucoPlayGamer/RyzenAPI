-- Lua provided by SkyAPI 
-- Game: AppID 500660
addappid(500660)
addappid(500661, 1, "771c1cccf073f5f64d8e40948a09d94f3d05da06f6e96f1793dd86452b3ba6ca")
