-- Lua provided by RyzenAPI
-- Game: addappid(1964170)

-- MAIN APPLICATION
addappid(1964170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964171, 1, "a4a5bcc69013fb9cb0b58d1a6059b7e132b3da74b699ef1bbd57aa4963ff798b")
