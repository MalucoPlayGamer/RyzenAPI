-- Lua provided by RyzenAPI
-- Game: Game: Chicken Holmes - The Mystery of Bartolomeu

-- MAIN APPLICATION
addappid(1577280)
-- Game: addappid(1577280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1577281, 1, "39fa4cc7614817cc55002904d770fd4cb6143fe8d514de6ac53492404518df6a")
