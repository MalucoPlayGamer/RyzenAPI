-- Lua provided by SkyAPI 
-- Game: AppID 1299510
addappid(1299510)
addappid(1299511, 1, "10e6d9c752130de53e4644e5493a6001a70aba427bd5878a59b396b95940ed61")
