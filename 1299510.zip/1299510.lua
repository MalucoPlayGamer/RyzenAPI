-- Lua provided by RyzenAPI
-- Game: Game: AppID 1299510

-- MAIN APPLICATION
addappid(1299510)
-- Game: addappid(1299510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299511, 1, "10e6d9c752130de53e4644e5493a6001a70aba427bd5878a59b396b95940ed61")
