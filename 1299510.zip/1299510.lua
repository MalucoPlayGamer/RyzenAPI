-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade - Swansong

-- MAIN APPLICATION
addappid(1299510)
addappid(1801880)
addappid(1801881)
addappid(1801882)
addappid(2407740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1299511, 1, "10e6d9c752130de53e4644e5493a6001a70aba427bd5878a59b396b95940ed61")

