-- Lua provided by RyzenAPI
-- Game: 2712540

-- MAIN APPLICATION
addappid(2712540)
-- Game: addappid(2712540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712541, 1, "ad87625f8f7f5df47fa6ddc091f8b6462066fca8d588b49cf8afc5d5f87ca1fa")
addappid(2712543, 1, "46dccda997a12a9b35cd890c7181c6c38b2ad3c224354808bbb35b085151ac22")
