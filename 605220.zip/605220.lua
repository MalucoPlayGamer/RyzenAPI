-- Lua provided by RyzenAPI
-- Game: Game: AppID 605220

-- MAIN APPLICATION
addappid(605220)
-- Game: addappid(605220)

-- MAIN APP DEPOTS / PACKAGES
addappid(605221, 1, "161f8f13371d23ef983190b9d1c826572b98397d1e7e72489ed5f0c1509103c9")
