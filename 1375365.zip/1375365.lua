-- Lua provided by RyzenAPI
-- Game: addappid(1375365)

-- MAIN APPLICATION
addappid(1375365)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375365,0,"9184ff95ff4d49053636338a5b4002e3344144fd4fddc510d4db9cb1d65cc21f")
