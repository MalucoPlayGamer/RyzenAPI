-- Lua provided by RyzenAPI
-- Game: addappid(856630)

-- MAIN APPLICATION
addappid(856630)

-- MAIN APP DEPOTS / PACKAGES
addappid(856630,0,"0965c1c18cd64566b71ad0c7be8b9957bc2cc97c0d5e1a26b3c6ff772462ed08")
