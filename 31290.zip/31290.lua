-- Lua provided by RyzenAPI
-- Game: Back to the Future: The Game

-- MAIN APPLICATION
addappid(31290)
-- Game: addappid(31290)

-- MAIN APP DEPOTS / PACKAGES
addappid(31291, 1, "814d9366f129232087f2c79517841bc95a5d29e59d329df6cd11257b8767dd27")
addappid(31292, 1, "14d176b1f5e4344d509eb23a8b5031e897c459a8bf4cb5db56310b546ffcc470")
addappid(31293, 1, "a38a31b74b3271541b763d35de710333638b733dad4eb108e1d0e9e6939250fd")
addappid(31294, 1, "a48cb23c16a8c1fa275ee2a46e917baed51c1ebf092192190cc241abc0f0891a")
addappid(31295, 1, "f7c106d2be7170fb04e2b8780bbebbdedeeffbe2b7c8ebe37aac9d1e56f4a996")
addappid(31296, 1, "c9a5316f2ee0e3a81157fc4d0322bf4a939c46ca97af7ca1618245ec80c499fd")
