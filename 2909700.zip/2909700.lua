-- Lua provided by RyzenAPI
-- Game: DayZ Experimental Tools

-- MAIN APPLICATION
addappid(2909700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909701, 1, "88a0e30fada436450021104b41d2bc9d78a9d081725d24844c31995a3da93e15")
