-- Lua provided by RyzenAPI
-- Game: Sex-Pop Demon Hunters

-- MAIN APPLICATION
addappid(4355490) -- Sex-Pop Demon Hunters
addappid(4895660)
addappid(4895670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4355491, 1, "d1d255f2f54ba269a16eb39d8a72dddbb8e055dba5cbfa452efe8dc41cbcf75f") -- Depot 4355491
addappid(4895660, 1, "a1bb116b1f37c8f4d47417f86d1d1bc9ed90b2dfe8ce480a1458d9d962046cf1") -- Sex-Pop Demon Hunters - Wallpapers Pack - Depot 4895660
addappid(4895670, 1, "148c292f59f6cf7abe3ff9791a5668cfa12e3029e7d15c6e6e83cb3f47ff0815") -- Sex-Pop Demon Hunters - Digital Artbook - Depot 4895670

