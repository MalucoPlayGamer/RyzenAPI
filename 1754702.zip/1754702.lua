-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Diebold's Swimsuit "Knight Commander"

-- MAIN APPLICATION
addappid(1754702)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754702,0,"ba9d4356ba2c21c741558b8a9686a6a919a0933d888aa8b28f0bbd91aa783dd1")
