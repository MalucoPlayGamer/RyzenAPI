-- Lua provided by RyzenAPI
-- Game: 373870

-- MAIN APPLICATION
addappid(373870)

-- MAIN APP DEPOTS / PACKAGES
addappid(373872,0,"ee93e0264121d5c9bb152b15fbc9034db257c58127b0c10ed93dc35fcde10d06")

