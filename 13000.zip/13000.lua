-- Lua provided by RyzenAPI
-- Game: Ninja Reflex: Steamworks Edition

-- MAIN APPLICATION
addappid(13000)

-- MAIN APP DEPOTS / PACKAGES
addappid(13001, 1, "edcffe19a0e4daab187bf219ee5f308f10f91f681c7ab948197950d64e540544")
addappid(13002, 1, "cd8490accd79273d22ade6aa309800b2a82899ab06f544f25332ad6c6dbd41dc")
addappid(13003, 1, "53308d9a0ade5bc562861fb61772ec2e15fbe70168c51757d0bf2ce7902bd5b8")
addappid(13004, 1, "0c25775fb68988230cf1045be8fb86e6a9498103ec69066caff27ff3968de05e")
addappid(13005, 1, "ff9ebc591ebc85385cf460b8debd394ab930d39148c584be356530ed58ea9d11")
addappid(13006, 1, "f25a32458963cbaa1ad9e3774eb7694b0c5cffd9779ed6ae8a82bc2946d4537a")

