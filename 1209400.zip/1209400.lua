-- Lua provided by RyzenAPI
-- Game: 1209400

-- MAIN APPLICATION
addappid(1209400)
-- Game: addappid(1209400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209401, 1, "77e55edcb61a5d3dcc080ec8a1fa340f9257cd2faef9137d3bb63af9a57f33e2")
