-- Lua provided by RyzenAPI
-- Game: AppID 458760

-- MAIN APPLICATION
addappid(458760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(458761, 1, "e2ef80f1699d8267fb75d7b3abc4d36d568eb76c036ad8c42467e5e2ebf34124")

