-- Lua provided by RyzenAPI
-- Game: 458760

-- MAIN APPLICATION
addappid(458760)
-- Game: addappid(458760)

-- MAIN APP DEPOTS / PACKAGES
addappid(458761, 1, "e2ef80f1699d8267fb75d7b3abc4d36d568eb76c036ad8c42467e5e2ebf34124")
