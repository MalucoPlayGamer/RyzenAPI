-- Lua provided by RyzenAPI
-- Game: 2132850

-- MAIN APPLICATION
addappid(2132850)
-- Game: addappid(2132850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132851, 1, "c0cf251a04e11e7860d8bf6a88a97db33bacf450670116ca72fa7a86758b5192")
