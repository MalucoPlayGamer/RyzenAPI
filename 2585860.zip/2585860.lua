-- Lua provided by RyzenAPI
-- Game: Ruins To Fortress

-- MAIN APPLICATION
addappid(2585860)
addappid(3103100)
-- Game: addappid(2585860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585861, 1, "2bac440b2d5869df096a534303d08f804e45654928c34dbfecf31e994f3763f8")
addappid(2585862, 1, "1bc8f8aba0e29c83482aa4a3a856c416298375c0ddfcbb00556f68c2cef6274a")
