-- Lua provided by RyzenAPI
-- Game: Costume Party

-- MAIN APPLICATION
addappid(1648300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648301, 1, "716d72a4cb829e7ee7735bda6c2b3bee1812492ac5d89c0d31ee01e53991d363")
addappid(1648302, 1, "2fb68d1ab5db2a310580f68bd2462a9cd3ea311f748720551b0bde5ce0a51624")
