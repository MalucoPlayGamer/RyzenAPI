-- Lua provided by SkyAPI 
-- Game: AGAINST
addappid(1584840)
addappid(1584841, 1, "78f9521346d0acd359460ace3c0c0800cf511b149fd97d3d30d8f31db0efb52e")
