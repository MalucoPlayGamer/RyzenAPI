-- Lua provided by RyzenAPI
-- Game: AGAINST

-- MAIN APPLICATION
addappid(1584840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584841, 1, "78f9521346d0acd359460ace3c0c0800cf511b149fd97d3d30d8f31db0efb52e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1827160)
