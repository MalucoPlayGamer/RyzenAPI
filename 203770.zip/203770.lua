-- 203770's Lua and Manifest Created by Hubcap Manifest
-- Crusader Kings II
-- Created: January 15, 2026 at 11:25:56 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 76
-- Total DLCs: 32
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(203770) -- Crusader Kings II
-- MAIN APP DEPOTS
addappid(203771, 1, "f82582e394fdcc64edfc9bde7690a24bdbb2b32c957b1b336a1f2fbdc599d217") -- CKIIMain
setManifestid(203771, "7320328967989843853", 2367427154)
addappid(210890, 1, "bb68a942af30e14fdaf119d703f615990e1f01bb39de88dc9187267736d2d0e5") -- CKII PC
setManifestid(210890, "7073754417396204765", 183673175)
addappid(210891, 1, "92cf7e4f12112599f315b447753553bfa48930f3336cac094a2658a292eb99f6") -- CKII Mac=
setManifestid(210891, "2534104746831011572", 238444026)
addappid(210909, 1, "94736942d20eaabd9ff6a4f2ab148b2f92d0de3ebe0ed75b4ae3d82d522e5e8b") -- CKII Linux
setManifestid(210909, "5398874466109349620", 725987329)
addappid(203772, 1, "4b0286766571d986232fc3a194099fbc372a7afc587931fca0361e4289194db9") -- Dynasty CoA Pack 1
setManifestid(203772, "7736519193388302235", 491948)
addappid(203773, 1, "678a2c3f1879a370291fd6e5978566419df2800445c351246cfe374c3dfe11c1") -- Mongol Graphics Pack
setManifestid(203773, "2893702148401338896", 2165996)
addappid(203774, 1, "0180eb1148b1410cd976589745bcb769fb93f51d1da3c673970df4ae8a0ce280") -- Songs of Albion
setManifestid(203774, "6693934556503586496", 35162548)
addappid(203775, 1, "494fb6a77dbcd04f0e6ab6887540c4a2c0874e5c2731d7adc4c71fc1eae05f30") -- Songs of Faith
setManifestid(203775, "125708884775864596", 55093360)
addappid(203777, 1, "2de3374417aa671655b97f365207627609c9726047df3c116598c78d52e8831e") -- Songs of the Holy Land
setManifestid(203777, "2640723284232348651", 37370116)
addappid(210892, 1, "c35f79a2f591298e8276776ac94e3790e1bc851acdd7d4fa608bb2f013cacebb") -- African Unit Pack
setManifestid(210892, "4784486203031872745", 5520674)
addappid(210893, 1, "6333ca656a4f591b1a67faedc3bd5de9070f7c2aa420ccbece04d93ee2b2cb2f") -- Songs of the Caliph
setManifestid(210893, "7788825952780570926", 40285328)
addappid(210894, 1, "893dd9b356deb3c1002360345bd61d32870728abda94d040e0241d6051f1409a") -- Dynasty Coat of Arms Pack 2
setManifestid(210894, "7571586680611011697", 362511)
addappid(210896, 1, "92f50d9e9b4351df2b3ab0de50b7e9b6acc273d832283522abcd7224fc15f40a") -- Byzantine Unit Pack
setManifestid(210896, "2605454879484757382", 4392771)
addappid(210897, 1, "27280031a406a071ea47206f543775e58c7d0120661aabb034276f43ce143cc8") -- African Portraits
setManifestid(210897, "6708664032720834637", 1985633)
addappid(210898, 1, "f1908f74b84299fdd9619c7e4c4220d4003f7f3dfa86fb69d722ee74f2d8a93a") -- Mediterranean Portraits
setManifestid(210898, "2618010994137912816", 2065366)
addappid(210899, 1, "7136196119ccc4ace75c98d5848f7b94cfc94e7bedee0637147d6bec73671e4c") -- Russian Unit Pack
setManifestid(210899, "6953397558175007812", 4362362)
addappid(210900, 1, "ad12a851c7929887957ab767ec3c7ed98878957aabcb7326856d2f79bf4a4f7b") -- Russian Portraits
setManifestid(210900, "7744271099548626373", 3190854)
addappid(210901, 1, "3dc709385803c42b140b6dac621818dba6330cf1c8bba98cc24b59741a3eebae") -- Songs of Byzantium
setManifestid(210901, "6602625933893890630", 38619818)
addappid(210903, 1, "40e62ad18d217acf3ee2dc986733d1c511c7704e340aa1c5d2f6b2fac339fe61") -- Songs of the Rus
setManifestid(210903, "592733058011282760", 37992295)
addappid(210907, 1, "1ad8483fcbe97f03671ecdcf1325e4c0b20f68f0c43da60d8383bb0610a19a9f") -- Songs of Prosperity
setManifestid(210907, "4510440994356443738", 34480423)
addappid(210904, 1, "4d4f3fed92134c9183761dd0abd937cccd3b68e04b90954ab4ffdabe1840190a") -- Norse Portraits
setManifestid(210904, "4806828341628083750", 3389924)
addappid(210905, 1, "0244125bbc3bba9d2304f9fc94ea6945aba8c31d026374ca536ec470952347ea") -- Norse Unit Pack
setManifestid(210905, "5847395675986559790", 4028789)
addappid(226660, 1, "2871c9d14da4df9ce6e647b325fc6ed75adb6b9840790c81a8dde15d96021316") -- Hymns to the Old Gods
setManifestid(226660, "474456692832266743", 40252491)
addappid(226664, 1, "1e78255abdb97821da7aa6b089851cbc92794f468c9a8ce3f7741a0d9cc4285f") -- Dynasty Coat of Arms Pack 3
setManifestid(226664, "2789404881128860709", 228535)
addappid(226662, 1, "61cf456478420ce6a8c2cf9f87b970ab963570f1b74216d44c7c96cc1ea17f0f") -- Celtic Unit Pack
setManifestid(226662, "7071390988259870195", 3738014)
addappid(226663, 1, "9145bd50b345e4c2a93e87bf4f4974f0c1ab78cd0419e93cf6a8ade9b669e66a") -- Celtic Portraits
setManifestid(226663, "8469882600645611630", 2846530)
addappid(226668, 1, "0821328e58208ddf1013ca53c471ac9114d11e18817434624a931c8ca9df87f6") -- Crusader Kings II: Military Orders Unit Pack
setManifestid(226668, "8599655656761659417", 4200599)
addappid(226669, 1, "1a0a19a5b9608b3d0f81c8f5e0100d0695e4ef3efeb846183f9565493cce4890") -- Crusader Kings II: Warriors of Faith Unit Pack
setManifestid(226669, "8181225463756226252", 4204600)
addappid(226670, 1, "3dbffd3117317317b716e8e38688d902f642e28549f818f42993b64f7388b0d2") -- Crusader Kings II: Hymns of Abraham
setManifestid(226670, "8810867342377008414", 50376248)
addappid(226672, 1, "7034e22e5e8c207776d53524a7aaeb2b8e2a117ecff7eaae94849d0bc0ee6ce0") -- Crusader Kings II: Saxon Unit Pack
setManifestid(226672, "8577053228063611967", 4269597)
addappid(226673, 1, "3b4f13a6b63a73944f02dfc8481c539d82a44868690c063b1b660425f9cc71f8") -- Crusader Kings II: Finno-Ugric Unit Pack
setManifestid(226673, "5484707795349860714", 4181254)
addappid(279601, 1, "1c0e0f6ee08932fa569b75c2a89bad06ce1e282ba26606e195b4cb75cb0f1283") -- Crusader Kings II: Turkish Unit Pack
setManifestid(279601, "3250875259890030420", 3953838)
addappid(279602, 1, "8e942b4c85686887fbcab8e944bea824c0bd886807fab8b3ab0a2548283a7228") -- Crusader Kings II: Turkish Portraits
setManifestid(279602, "5756101493917035257", 2075398)
addappid(279603, 1, "359a1a23175a2fc3e4f388dff397e6932c57d6b31e287116980cb8f28830ee23") -- Crusader Kings II: Songs of India
setManifestid(279603, "594686765142321562", 38506261)
addappid(292980, 1, "72c05e9cc562a5a49298a8425c9fb64812cd58267e4866628a79fcce42db6bdc") -- Crusader Kings II: Persian Unit Pack
setManifestid(292980, "5580512706256788042", 4517727)
addappid(292981, 1, "f8c11a468792f285508df4cf0e40d99190e244907c735c2c936676b07260f61c") -- Crusader Kings II: Persian Portraits
setManifestid(292981, "5705513130696838411", 2080457)
addappid(292983, 1, "3c90819db78ea16b796eb03ada2dcafbe2b2d31f3303a7c52839007af61f0319") -- Crusader Kings II: Early Western Clothing Pack (292983) Depot
setManifestid(292983, "7349669357774677025", 875628)
addappid(292984, 1, "f096ccbe05d19a3750a7e52a811e4e8a06633ca6af903c6d8a8aab996a263091") -- Crusader Kings II: Early Eastern Clothing Pack (292984) Depot
setManifestid(292984, "5094353863021498177", 2438489)
addappid(292985, 1, "9228eb93230c46d2c99fc3de0e9f0f876864cfa25a6b1ebf47f50da84be67d63") -- Crusader Kings II: Dynasty Shields Charlemagne (292985) Depot
setManifestid(292985, "1550427492894667390", 311837)
addappid(329011, 1, "dec07e497bc671e14b9267d8445d7de6478dc01d7b306eb79aaac4a1ee2fe7be") -- Crusader Kings II: Iberian Unit Pack (329011) Depot
setManifestid(329011, "7202469712817515744", 3172674)
addappid(329012, 1, "a50379a6b5647a43f998016337d649123dabb7c0c463474138ca8c8a09efa610") -- Crusader Kings II: Iberian Portraits (329012) Depot
setManifestid(329012, "3548700544758413528", 2325903)
addappid(373940, 1, "1bae9c7ebb69c1fec6558194047eb9704d337626441633b224c277b78f5670ad") -- Crusader Kings II: Orchestral House Lords (373940) Depot
setManifestid(373940, "2946940948886523507", 90746304)
addappid(401660, 1, "97c64fa4dbb7f4a67423a75288a4c34cd356eefd3b44898f264d5775e74493e6") -- Crusader Kings II: Viking Metal (401660) Depot
setManifestid(401660, "416068762721259204", 142585931)
addappid(428720, 1, "9034d85ad9ff9a3ad6c8578de0dd2653b96576f55013b7758310a34c3ec8f5bb") -- Crusader Kings II: South Indian Portraits(428720) Depot
setManifestid(428720, "7037806026456005248", 1700635)
addappid(472070, 1, "64df3caa004f2d74634a6a6c5d25ebde17959c7f52b99448950a72477088bc77") -- Crusader Kings II: No Savage Bears (472070) Depot
setManifestid(472070, "6009316026206842380", 124610604)
addappid(601270, 1, "991e4cc3bfe50de46caf00c3343c766a19046e13910a1fe724db35d1c782e0bd") -- Crusader Kings II: Hymns of Revelation (601270) Depot
setManifestid(601270, "4014004482374877561", 106201242)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Crusader Kings II Ruler Designer (AppID: 203776)
addappid(203776)
addappid(203776, 1, "08e9ae88d66d5931492617af622c0895e5a5599704faa82d37acdb8a7bcf58ef") -- Crusader Kings II Ruler Designer - Ruler Designer
setManifestid(203776, "8009288298515652483", 189)
-- Crusader Kings II Sword of Islam (AppID: 203778)
addappid(203778)
addappid(203778, 1, "d3d5bcb7bd008626e81e4d7097049c1f6c05095e4d3aacbca27d72a168d58c8a") -- Crusader Kings II Sword of Islam - The Sword of Islam
setManifestid(203778, "7322925981693052732", 7781493)
-- Crusader Kings II Legacy of Rome  (AppID: 210895)
addappid(210895)
addappid(210895, 1, "94ff2fdd072bda2b751c294c6eeed2cb78b9ce55ef59d9896d6b3472f31404ea") -- Crusader Kings II Legacy of Rome  - Legacy of Rome
setManifestid(210895, "466924056394183911", 1325698)
-- Crusader Kings II Sunset Invasion (AppID: 210902)
addappid(210902)
addappid(210902, 1, "0f5f39c364ed0eb6b61e697c0c247ee547aa2b2fdbf46c82ca2275127aa8174b") -- Crusader Kings II Sunset Invasion - Sunset Invasion
setManifestid(210902, "3541039448428417832", 8266704)
-- Crusader Kings II The Republic  (AppID: 210906)
addappid(210906)
addappid(210906, 1, "9db6d1e63c42283991a873c77fb45c66c81363a51bfd669df2c707bfa734eb06") -- Crusader Kings II The Republic  - The Republic
setManifestid(210906, "6289427501751466862", 2047158)
-- Crusader Kings II The Old Gods  (AppID: 210908)
addappid(210908)
addappid(210908, 1, "3010d909f707ea7117ec27071ecb83748487efa106e2d4093dc98f331b9f6370") -- Crusader Kings II The Old Gods  - The Old Gods
setManifestid(210908, "2901040346439526003", 2166228)
-- Crusader Kings II Europa Universalis IV Converter (AppID: 226665)
addappid(226665)
addappid(226665, 1, "ab44fee7b9dc4a871e30ed7043de8c2310bf1808d11d0e57d1c9d91cdc32a673") -- Crusader Kings II Europa Universalis IV Converter - Europa Universalis IV Converter
setManifestid(226665, "1726576533293814123", 3295536)
-- Crusader Kings II Customization Pack DLC  (AppID: 226666)
addappid(226666)
addappid(226666, 1, "e67c5abd009a411bb7ac83a22aed6cfdfd39f73ab1eca8fa2ab14ac0c1de24c2") -- Crusader Kings II Customization Pack DLC  - Customization Pack
setManifestid(226666, "2122311707818888169", 193)
-- Crusader Kings II Sons of Abraham (AppID: 226667)
addappid(226667)
addappid(226667, 1, "e57c61c78762bd25e7540775d04ad205d3c3ff62ef22740afe19c080ae3d725b") -- Crusader Kings II Sons of Abraham - Sons of Abraham
setManifestid(226667, "3095526964476043255", 190)
-- Crusader Kings II Songs of Yuletide (AppID: 226671)
addappid(226671)
addappid(226671, 1, "14913e002297e760bcd9d996b69f01652f39f7b826ac0540cf7e9c266aac42f0") -- Crusader Kings II Songs of Yuletide - Songs of Yuletide
setManifestid(226671, "5140079562930070115", 10236258)
-- Crusader Kings II Rajas of India (AppID: 279600)
addappid(279600)
addappid(279600, 1, "c34c2e6fe7fcaa8eeb7edbc5f13103e8db7992e2c4a1b4c851ae32a495b261e3") -- Crusader Kings II Rajas of India - Crusader Kings II: Rajas of India
setManifestid(279600, "4127148476012417828", 7972965)
-- Crusader Kings II Charlemagne (AppID: 292982)
addappid(292982)
addappid(292982, 1, "f6cc8e7510a02123515aeb6e5d56b61d9d8dade20e6904efa47e795317a7b28f") -- Crusader Kings II Charlemagne - Crusader Kings II: Charlemagne (292982) Depot
setManifestid(292982, "5745429231328889421", 6258726)
-- Crusader Kings II The Song of Roland Ebook (AppID: 326530)
addappid(326530)
addappid(326530, 1, "84479e4beb5aa7c623ba275b3c5e30259a746da3ea0b6a161634831527aef05b") -- Crusader Kings II The Song of Roland Ebook - Crusader Kings II: The Song of Roland Ebook (326530) Depot
setManifestid(326530, "4037781146347397711", 2134920)
-- Crusader Kings II Way of Life (AppID: 329010)
addappid(329010)
addappid(329010, 1, "9b895a1b3387aa8ea99e474202c7525de441d76cef7ca1a6dc31c12bc0d70cb4") -- Crusader Kings II Way of Life - Crusader Kings II: Way of Life (329010) Depot
setManifestid(329010, "5917372905387762715", 3036267)
-- Crusader Kings II Tales of Treachery EBook (AppID: 329013)
addappid(329013)
addappid(329013, 1, "d74023b3da5236a5c8037bb9661d640b5678f81d8522b1fcca43216cd08107aa") -- Crusader Kings II Tales of Treachery EBook - Crusader Kings II: Tales of Treachery EBook (329013) Depot
setManifestid(329013, "124481147254090918", 3690318)
-- Crusader Kings II Horse Lords  (AppID: 354330)
addappid(354330)
addappid(354330, 1, "fde76df0c96c85758e0877706b9bbe9dbb12b2749198c298283d75e964514241") -- Crusader Kings II Horse Lords  - Crusader Kings II: Inmortuos ad Ortum (354330) Depot
setManifestid(354330, "608816597166698661", 1556082)
-- Crusader Kings II Horse Lords Content Pack (AppID: 354331)
addappid(354331)
addappid(354331, 1, "8218d5ddfdfa421da5ba8efee37780fa5e4e08c1b8c2bf3a64653af70ec22710") -- Crusader Kings II Horse Lords Content Pack - Crusader Kings II: Inmortuos ad Ortum Content Pack (354331) Depot
setManifestid(354331, "1770786164403113448", 62491585)
-- Crusader Kings II Conclave (AppID: 394320)
addappid(394320)
addappid(394320, 1, "f8bc802dc442c2cc8a662a84577e0d4bb428e211a4e4c0083d302818cc5ff969") -- Crusader Kings II Conclave - Crusader Kings II: Conclave (394320) Depot
setManifestid(394320, "48788755829047153", 1860072)
-- Crusader Kings II Conclave Content Pack (AppID: 394321)
addappid(394321)
addappid(394321, 1, "91b931f45ae6fa6deef6dcf5826ead5c4c70d102be06d038ae3ac4f5bcb2be77") -- Crusader Kings II Conclave Content Pack - Crusader Kings II: Conclave Content Pack (394321) Depot
setManifestid(394321, "1221565303991973142", 8569309)
-- Crusader Kings II The Reapers Due (AppID: 449980)
addappid(449980)
addappid(449980, 1, "9018c64c7c3827c2eb7415047ee1c0c866f1aece0e3bb1d6e7015eee97b1163f") -- Crusader Kings II The Reapers Due - Crusader Kings II: Not Bears (449980) Depot
setManifestid(449980, "256992923282045130", 8998758)
-- Crusader Kings II The Reapers Due Content Pack (AppID: 449981)
addappid(449981)
addappid(449981, 1, "1c18ac54794806c28114df4bbcdf691f5cfe8b4211072cfd7692c8b588a59b3d") -- Crusader Kings II The Reapers Due Content Pack - Crusader Kings II: Not Bears At All CP (449981) Depot
setManifestid(449981, "8336312139236356299", 7690111)
-- Crusader Kings II Monks and Mystics (AppID: 530780)
addappid(530780)
addappid(530780, 1, "b6f85b9be450687e9f7a329130f67443d003c176e2ab334727e3a91999026d59") -- Crusader Kings II Monks and Mystics - Crusader Kings II: Monks and Mystics (530780) Depot
setManifestid(530780, "2568207183713811986", 20685508)
-- Crusader Kings II South Indian Portraits 5 Year Anniversary Gift (AppID: 592800)
addappid(592800)
addappid(592800, 1, "69f96e7b270f54f9470530508839658baa55ffa6b7024a5d09317f7dc6395f79") -- Crusader Kings II South Indian Portraits 5 Year Anniversary Gift - Crusader Kings II: South Indian Portraits 5 Year Anniversary Gift (592800) Depot
setManifestid(592800, "7911971495937246008", 1700659)
-- Crusader Kings II Jade Dragon (AppID: 640140)
addappid(640140)
addappid(640140, 1, "18fc0a71c68d67a4e88b63c81f15872e21194b5dafdded0f5599c528c2e18ce2") -- Crusader Kings II Jade Dragon - Crusader Kings II: Board Game Night (640140) Depot
setManifestid(640140, "1270188710112029482", 57953599)
-- Crusader Kings II Holy Fury (AppID: 756660)
addappid(756660)
addappid(756660, 1, "eb2c63203fd83aa1e8c98ad5bd944cbb8b0bb12866f073e177a78fc9f5fbe6b6") -- Crusader Kings II Holy Fury - Crusader Kings II: Holy Fury (756660) Depot
setManifestid(756660, "8676815965759567318", 101875171)
-- Crusader Kings II Pagan Fury (AppID: 949870)
addappid(949870)
addappid(949870, 1, "d401d2455f232739b14f5ba26a974c96f177f749ace813e0ed07a142fce8a315") -- Crusader Kings II Pagan Fury - Crusader Kings II: Pagan Fury (949870) Depot
setManifestid(949870, "773564310530905389", 57334169)
-- Crusader Kings II Pagan Fury - Warrior Queen (AppID: 1167860)
addappid(1167860)
addappid(1167860, 1, "9d6bed00c34e16012fa83673c3b523febe3a1cc336b511202d663d8d0b42f11c") -- Crusader Kings II Pagan Fury - Warrior Queen - Mega Cat (1167860) depå
setManifestid(1167860, "5551136992468584111", 197396156)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(616160) -- Crusader Kings II Ultimate Music Pack Collection
addappid(616170) -- Crusader Kings II Ultimate Portrait Pack Collection
addappid(616180) -- Crusader Kings II Ultimate Unit Pack Collection
addappid(616210) -- Crusader Kings II Dynasty Shield Pack
addappid(1538960) -- Crusader Kings II - Expansion Subscription