-- Lua provided by RyzenAPI
-- Game: 베일드 엣지(Veiled Edge)

-- MAIN APPLICATION
addappid(2447120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447121, 1, "e08a419241f28c016e9bb88a00e1f10ab7c6903f6c4b3f5d309442efc76d7ba3")

