-- Lua provided by RyzenAPI
-- Game: Crypt of the Necrodancer Original Danny Baranowsky Soundtrack

-- MAIN APPLICATION
addappid(314680)
-- Game: addappid(314680)

-- MAIN APP DEPOTS / PACKAGES
addappid(314680,0,"e1a657d960e8bc3c5b993e459ad99dfb6b564cb9be03361ea68877413ce7526d")
addappid(314682,0,"19358e986b0a2b6fd791a29d1d324fa5f26c02be2218ed9300e3315f9be37d16")
