-- Lua provided by RyzenAPI
-- Game: addappid(1523190)

-- MAIN APPLICATION
addappid(1523190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523191, 1, "57a5815bb70904f7546cee4a49f75879e25ad21d6a5173bcb59b7a8fc99afce9")
