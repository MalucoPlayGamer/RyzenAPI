-- Lua provided by RyzenAPI
-- Game: Emoji Merge - Puzzle Matching

-- MAIN APPLICATION
addappid(1921120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921121, 1, "a44fb502a5f33e0f782ed818bfcd7bc8261afcf626474ccf69659a8b110317ea")

