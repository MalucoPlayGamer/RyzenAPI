-- Lua provided by RyzenAPI
-- Game: LawnMower City

-- MAIN APPLICATION
addappid(1831930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831931, 1, "0931f303dd5e56f094a4c7e4f625a99016d99f6063940a785276bdd8c4ce4d84")

