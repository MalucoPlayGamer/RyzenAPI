-- Lua provided by RyzenAPI 
-- Game: 12 Labours of Hercules
addappid(342580)
addappid(342581, 1, "f7b42f7d7007adf300d31984b1fb2eb1f3cb8eb57446783e7c9a605ef2b4da57")
addappid(342582, 1, "b87d8dcfde7ef0ce1e62c3cc9cb219f4e31eece11c2af80ef7352b5cd06ef7af")
addappid(342583, 1, "5c514f00baa8e865f32c5eb3daac12a4f50c7013f52b2a590c3a83657d2264ae")
