-- Lua provided by SkyAPI 
-- Game: AppID 2565290
addappid(2565290)
addappid(2565291, 1, "349855e7ceded8481ab02b1066e88ab4127f0ee732d44ea7b20520f2c57f68aa")
