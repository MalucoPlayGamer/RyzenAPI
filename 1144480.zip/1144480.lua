-- Lua provided by RyzenAPI
-- Game: 1144480

-- MAIN APPLICATION
addappid(1144480)
addappid(1144481)
-- Game: addappid(1144480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144480,0,"b50ad4725c8b74adafbd0b346f8ea4d428f20ce0b14218f564c5add4a824e18c")
