-- Lua provided by RyzenAPI
-- Game: addappid(1746630)

-- MAIN APPLICATION
addappid(1746630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746631, 1, "33328722b4b724b522d5a52f7c1ef42efa2660992c63533522bb5e274adbed57")
