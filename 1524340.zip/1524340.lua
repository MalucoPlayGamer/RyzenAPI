-- Lua provided by RyzenAPI 
-- Game: Street karate 3
addappid(1524340)
addappid(1524341, 1, "d1f507a30a8ec68158e31f50af5143928e7db5bba95db0f0465c5884024f53c0")
