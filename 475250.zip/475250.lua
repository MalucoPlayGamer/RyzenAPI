-- Lua provided by RyzenAPI 
-- Game: AppID 475250
addappid(475250)
addappid(475251, 1, "9d9ff8ab5ff7e67a82e2d6cc9d91c7a2b3190ac071be68edd307f5984e59c2e4")
