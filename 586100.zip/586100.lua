-- Lua provided by RyzenAPI
-- Game: Heroes in the Sky-Origin

-- MAIN APPLICATION
addappid(586100)

-- MAIN APP DEPOTS / PACKAGES
addappid(586101, 1, "2eaf2393529327218b36f69d1828e455046491e6ee444d487e3deae355325fe7")

