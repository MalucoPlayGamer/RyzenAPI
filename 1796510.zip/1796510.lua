-- Lua provided by RyzenAPI
-- Game: addappid(1796510)

-- MAIN APPLICATION
addappid(1796510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796511, 1, "b881321c9598a19bbfe7947e053067197e5e11fe7f56cc5af9c43742dc1ca090")
