-- Lua provided by SkyAPI 
-- Game: AppID 994730
addappid(994730)
addappid(994731, 1, "b6e6fa5e6571d90fe48e2db5d36f49b83f18ad9345b768307a71446c2eab909e")
addappid(996820, 0, "3708f8ddf00678dce8ae442d178847475fcf63a3b6c5291a5eac91dfa2e005df")
addappid(1139930, 0, "cce10041302b8f7d05b0792ae77cedd6df4e451cd327ee879928224f61d2c4ae")
