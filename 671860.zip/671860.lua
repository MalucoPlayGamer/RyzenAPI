-- Lua provided by RyzenAPI
-- Game: BattleBit Remastered

-- MAIN APPLICATION
addappid(671860)
addappid(2390150)

-- MAIN APP DEPOTS / PACKAGES
addappid(671861, 1, "56bbe2a8bdcb1799753f6640f3cb92353e9d4c555d58070576c3697ffe9cc430")

