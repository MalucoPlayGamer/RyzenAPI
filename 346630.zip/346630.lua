-- Lua provided by RyzenAPI 
-- Game: Plazma Being
addappid(346630)
addappid(346631, 1, "1f369ad455642733412b257a7c0878fcdbd359e0de0ea2522e371da57ecf730b")
