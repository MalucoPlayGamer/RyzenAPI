-- Lua provided by SkyAPI 
-- Game: AppID 354130
addappid(354130)
addappid(354131, 1, "5445eddbc901302096aaeca97342da32b90e662297668afd7d70233f37bce0e2")
