-- Lua provided by RyzenAPI
-- Game: AppID 419810

-- MAIN APPLICATION
addappid(419810)

-- MAIN APP DEPOTS / PACKAGES
addappid(419811, 1, "017eb0eab85107c75b508e7505cb073151837b1965ee8ce6859806eed82ada75")
addappid(419812, 1, "3635b37f02a0786d23cc1a1c06783538aa9f462915a6089fdaa95fecd22289ad")
addappid(419813, 1, "1242b67a772734446f8706d2b68f8b613aa823a23abdd8afd2513bee5e91472d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
