-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It’s a Night Magic Personality Pack Quiet and love to be pampered, Bookworm

-- MAIN APPLICATION
addappid(2053930)
-- Game: addappid(2053930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053931, 1, "7cedf44b169a5288dfcb868aed0f62e74193b637898ce07c06f8b810afd1d6e0")
addappid(2053932, 1, "1ac590e8d08faa9a600573d6ea850564de5b54129ccc993d184630fef260f3af")
