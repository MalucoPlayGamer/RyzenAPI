-- Lua provided by RyzenAPI
-- Game: Wayhaven Chronicles: Book Three

-- MAIN APPLICATION
addappid(2120320)
-- Game: addappid(2120320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120321, 1, "d3161576d92759f49c90f1b225bb38079100424012c0967aca081085721ecf47")
