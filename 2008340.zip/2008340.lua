-- Lua provided by RyzenAPI 
-- Game: Anger Foot Demo
addappid(2008340)
addappid(2008341, 1, "c6fada2e0378c646c6f1ae62fa91b5c058a8726a6b590e4933739b86bde40951")
