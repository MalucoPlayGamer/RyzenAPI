-- Lua provided by RyzenAPI
-- Game: addappid(1245910)

-- MAIN APPLICATION
addappid(1245910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245911, 1, "2305621ffd4e37b0abbe6ac616c85314ab02b145206f895b93712233fd885fc7")
