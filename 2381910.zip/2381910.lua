-- Lua provided by RyzenAPI
-- Game: 2381910

-- MAIN APPLICATION
addappid(2381910)
-- Game: addappid(2381910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381911, 1, "95c2b084e8fdb8455771ed260105a3d9dde61ed05adda7fcb86400f499d608f3")
