-- Lua provided by RyzenAPI
-- Game: Is This Seat Taken?

-- MAIN APPLICATION
addappid(3035120)
-- Game: addappid(3035120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035122,0,"03f91732d30d6b4b09435368553ac35895d83d88a114160940bf374f65f509f1")
