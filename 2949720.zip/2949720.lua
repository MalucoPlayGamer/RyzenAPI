-- Lua provided by RyzenAPI
-- Game: addappid(2949720)

-- MAIN APPLICATION
addappid(2949720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949721, 1, "9f15a50eb6a0b570ae0d7d0a9a69af24a9f9f230febabdec088fd5a3a7dd64dd")
