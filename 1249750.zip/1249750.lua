-- Lua provided by RyzenAPI
-- Game: Touch Typing Home Row Speed Grinder

-- MAIN APPLICATION
addappid(1249750)
-- Game: addappid(1249750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249751, 1, "2d95aba505923492217d4190a2251b109ee7298114838994d6ed7bb562835d14")
