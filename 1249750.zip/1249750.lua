-- Lua provided by RyzenAPI
-- Game: Touch Typing Home Row Speed Grinder

-- MAIN APPLICATION
addappid(1249750)
addappid(1365650)
addappid(1384230)
addappid(1444100)
addappid(1447620)
addappid(1450820)
addappid(1452580)
addappid(1456480)
addappid(1458520)
addappid(3808960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249751, 1, "2d95aba505923492217d4190a2251b109ee7298114838994d6ed7bb562835d14")

