-- Lua provided by RyzenAPI
-- Game: 2385020

-- MAIN APPLICATION
addappid(2385020)
-- Game: addappid(2385020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385021, 1, "dfa0a1342d22f2d67a5158b3425d749dd8eb5bec918b7090a51d48b13a1a9e15")
