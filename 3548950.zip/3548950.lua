-- Lua provided by RyzenAPI
-- Game: Scary Tales: Horror School

-- MAIN APPLICATION
addappid(3548950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3548951, 1, "0c143dd03e50c2127c20efc4a5ce4273a62a50d61bc86aa3030065a9a335e074")

