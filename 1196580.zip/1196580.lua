-- Lua provided by RyzenAPI
-- Game: AppID 1196580

-- MAIN APPLICATION
addappid(1196580)
-- Game: addappid(1196580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196581, 1, "a4ab0917e04727730a09efe544f1855d3722b441ecf5757dc7d60de5575f3f36")
