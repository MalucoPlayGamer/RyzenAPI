-- Lua provided by RyzenAPI
-- Game: AppID 3662130

-- MAIN APPLICATION
addappid(3662130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3662131, 1, "7399e26be81ced74b9b989772c263f56e7800d0a8afbdbd4f473f521cd3bf913")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
