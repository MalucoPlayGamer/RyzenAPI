-- Lua provided by RyzenAPI
-- Game: 3662130

-- MAIN APPLICATION
addappid(3662130)
-- Game: addappid(3662130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3662131, 1, "7399e26be81ced74b9b989772c263f56e7800d0a8afbdbd4f473f521cd3bf913")
