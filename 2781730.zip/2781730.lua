-- Lua provided by SkyAPI 
-- Game: AppID 2781730
addappid(2781730)
addappid(2781731, 1, "81bc95feeff485fb0c2d65114d4cfe9569e5335d2f7e558be403a9b7e8112903")
