-- Lua provided by RyzenAPI
-- Game: addappid(2078510)

-- MAIN APPLICATION
addappid(2078510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078511, 1, "6b40f2cf36c34cbf1e3b359b60696ecd31ad0f7e42fc86a1dfce661d6b9d116a")
