-- Lua provided by RyzenAPI
-- Game: Game: AppID 1184330

-- MAIN APPLICATION
addappid(1184330)
-- Game: addappid(1184330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184331, 1, "934d210fd8fbc701275da7b5190632eba5791204c57a537114b8f278c18370de")
