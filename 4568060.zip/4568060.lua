-- 4568060's Lua and Manifest Created by Hubcap Manifest
-- Click Build Repeat
-- Created: July 30, 2026 at 14:11:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4568060) -- Click Build Repeat
-- MAIN APP DEPOTS
addappid(4568061, 1, "837603d10464baa4fd4bd9fb56447ec2a85125aaf22725d8249d40d66b79a4f8") -- Depot 4568061
setManifestid(4568061, "7722451576351520405", 1528804021)