-- Lua provided by RyzenAPI
-- Game: Dark Hill Museum of Death

-- MAIN APPLICATION
addappid(1007050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007051, 1, "95943177146dda0cee43c98a5a35b8de6f5dc6c32f6b12ee12faa5f674d550c6")
