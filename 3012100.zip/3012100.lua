-- Lua provided by RyzenAPI
-- Game: 3012100

-- MAIN APPLICATION
addappid(3012100)
-- Game: addappid(3012100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012100,0,"896512a302c0b1e0669d1a44d3378dd17c44b3a341db9b35cc4d0c76aa8f8290")
