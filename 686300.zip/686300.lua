-- Lua provided by RyzenAPI
-- Game: 686300

-- MAIN APPLICATION
addappid(686300)
-- Game: addappid(686300)

-- MAIN APP DEPOTS / PACKAGES
addappid(686301, 1, "21b0e95110ae4c9eba22a787f1d61c046339c6441c2964002d7cce97e05852b3")
