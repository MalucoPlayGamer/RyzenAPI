-- Lua provided by RyzenAPI
-- Game: Convicted Demo

-- MAIN APPLICATION
addappid(2676430)
-- Game: addappid(2676430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676431, 1, "1730e5e5b8e99f7e0828d72a4919980da57f32f8f79a5e013610936e68611eb4")
