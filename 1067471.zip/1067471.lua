-- Lua provided by RyzenAPI
-- Game: addappid(1067471)

-- MAIN APPLICATION
addappid(1067471)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067471,0,"8784bf79021af20e3876ffb64f8638320c45e805facb41c9db05db37114deedf")
