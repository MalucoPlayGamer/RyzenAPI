-- Lua provided by RyzenAPI
-- Game: addappid(3268250)

-- MAIN APPLICATION
addappid(3268250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268251, 1, "eae07c74cdd2ec56e9e942ea3f619c0a718a17f3311acd1c249e79aa102302f4")
