-- Lua provided by RyzenAPI
-- Game: 2114330

-- MAIN APPLICATION
addappid(2114330)
-- Game: addappid(2114330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114331, 1, "b833f9a5625d30292ebf765456611473ad5d7cb8d23c67206c79103e06efa1df")
addappid(2114332, 1, "9e07537f296d86e49bac91195e35e832d6f3555a75a25fd0abafcfd170b233e2")
addappid(2114333, 1, "7bbc40b01511613c2f7dd3f3abe76bfc5865dbccb9a08cac82fdb993ed48d7b2")
