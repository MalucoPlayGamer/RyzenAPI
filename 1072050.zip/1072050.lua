-- Lua provided by RyzenAPI
-- Game: Core Of Darkness

-- MAIN APPLICATION
addappid(1072050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1072051, 1, "c4605276b75946a0808d96dee8c06cea783d3221034e330ca3fff3ee06cb9ce6")

