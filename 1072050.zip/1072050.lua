-- Lua provided by RyzenAPI
-- Game: Core Of Darkness

-- MAIN APPLICATION
addappid(1072050)
-- Game: addappid(1072050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072051, 1, "c4605276b75946a0808d96dee8c06cea783d3221034e330ca3fff3ee06cb9ce6")
