-- Lua provided by RyzenAPI
-- Game: AppID 443970

-- MAIN APPLICATION
addappid(443970)
-- Game: addappid(443970)

-- MAIN APP DEPOTS / PACKAGES
addappid(443971, 1, "f2835ca65117621a95f1ecf8b2726b2d06272fe1da8ba64925fb4e83787a1ebb")
addappid(500890, 0, "22a873bdda302302a2599a736ca389c2e579ce4167390fc49e6df782b361dae0")
addappid(573960, 0, "7e57db82a5f41abfbd133a109b6641e7f70a0f274a45cbc3c74cfda1a39d8f4b")
addappid(747520, 0, "0e5129b4df2efe8e97e2c4da2ce50732efcc57045b941779b966f88c609bc0a3")
