-- Lua provided by RyzenAPI
-- Game: S2ENGINE HD

-- MAIN APPLICATION
addappid(443970)
addappid(979780)
addappid(995560)
addappid(1189110)
addappid(1581710)
addappid(2987820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(443971, 1, "f2835ca65117621a95f1ecf8b2726b2d06272fe1da8ba64925fb4e83787a1ebb")
addappid(500890, 0, "22a873bdda302302a2599a736ca389c2e579ce4167390fc49e6df782b361dae0")
addappid(573960, 0, "7e57db82a5f41abfbd133a109b6641e7f70a0f274a45cbc3c74cfda1a39d8f4b")
addappid(747520, 0, "0e5129b4df2efe8e97e2c4da2ce50732efcc57045b941779b966f88c609bc0a3")
