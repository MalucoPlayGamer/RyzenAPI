-- Lua provided by RyzenAPI
-- Game: Game: Pistol Whip

-- MAIN APPLICATION
addappid(1079800)
-- Game: addappid(1079800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079801, 1, "42658144daff10982bfa06dcdc13b2fea75268b2c08496130a993f270e3d9bad")
