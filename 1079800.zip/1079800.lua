-- Lua provided by SkyAPI 
-- Game: Pistol Whip
addappid(1079800)
addappid(1079801, 1, "42658144daff10982bfa06dcdc13b2fea75268b2c08496130a993f270e3d9bad")
