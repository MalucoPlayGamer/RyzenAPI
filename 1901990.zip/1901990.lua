-- Lua provided by RyzenAPI
-- Game: Machine Gun Fury

-- MAIN APPLICATION
addappid(1901990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1901991, 1, "d898b552d7c13b4cb11dfd44f0ff92f48a13cb28a11d63998af7822f5b3ced37")

