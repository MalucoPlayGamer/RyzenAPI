-- Lua provided by RyzenAPI
-- Game: 1901990

-- MAIN APPLICATION
addappid(1901990)
-- Game: addappid(1901990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901991, 1, "d898b552d7c13b4cb11dfd44f0ff92f48a13cb28a11d63998af7822f5b3ced37")
