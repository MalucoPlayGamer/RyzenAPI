-- Lua provided by RyzenAPI 
-- Game: War Of Gold 2 Mission 99
addappid(2180980)
addappid(2180981, 1, "316e7d118a2e42af8d30a38a8be320249bedc73057e5e4783b6aa441124fc25a")
