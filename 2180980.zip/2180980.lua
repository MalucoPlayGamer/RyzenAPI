-- Lua provided by RyzenAPI
-- Game: 2180980

-- MAIN APPLICATION
addappid(2180980)
-- Game: addappid(2180980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180981, 1, "316e7d118a2e42af8d30a38a8be320249bedc73057e5e4783b6aa441124fc25a")
