-- Lua provided by RyzenAPI
-- Game: SUPER 56

-- MAIN APPLICATION
addappid(1659150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659151, 1, "44bc7a0c5d1d30bd9c91d28ae3f787deacbd16ad76e7678ecda6ada0bef38c9f")
