-- Lua provided by SkyAPI 
-- Game: Extreme Bike Racing Demo
addappid(2614880)
addappid(2614881, 1, "4286b4403acac55fedbb9d2ed5b712d431bbda162c3b4d496f7bc8a69e45ea44")
