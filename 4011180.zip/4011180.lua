-- Lua provided by RyzenAPI
-- Game: NTR Idol: Déjà Vu

-- MAIN APPLICATION
addappid(4011180)
addappid(4340680)

-- MAIN APP DEPOTS / PACKAGES
addappid(4011181,0,"984dbfea7fafeba01c1c2a44fd4b89f20d38c54bf67395ecc67bcb6bced1f7c4")
addappid(4340681,0,"3a30173dd61441e7b251f08fc0cecce9e086dfc78205c50ea22376003af38bcc")

