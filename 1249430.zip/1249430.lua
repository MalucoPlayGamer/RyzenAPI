-- Lua provided by RyzenAPI
-- Game: 1249430

-- MAIN APPLICATION
addappid(1249430)
-- Game: addappid(1249430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249431, 1, "b37629547c7b1a8d57102a97f0dc44dae8a31d668dcfced4d92d993cead85587")
