-- Lua provided by RyzenAPI
-- Game: Sarawak

-- MAIN APPLICATION
addappid(1249430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249431, 1, "b37629547c7b1a8d57102a97f0dc44dae8a31d668dcfced4d92d993cead85587")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
