-- Lua provided by RyzenAPI
-- Game: addappid(1748370)

-- MAIN APPLICATION
addappid(1748370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748371, 1, "dbb051ee79d544613d7df7a2f3c3d9cbb7ad89e1cfd224757e3ce6fce6708b7b")
