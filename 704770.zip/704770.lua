-- Lua provided by RyzenAPI
-- Game: Game: AppID 704770

-- MAIN APPLICATION
addappid(704770)
-- Game: addappid(704770)

-- MAIN APP DEPOTS / PACKAGES
addappid(704771, 1, "09370d921a4c688bc83989d508dc3bd992baa486cb09e4fcc7623e80a90f5046")
