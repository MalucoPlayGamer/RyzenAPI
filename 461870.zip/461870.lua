-- Lua provided by RyzenAPI
-- Game: Police Simulator: Patrol Duty

-- MAIN APPLICATION
addappid(461870)
-- Game: addappid(461870)

-- MAIN APP DEPOTS / PACKAGES
addappid(461871, 1, "33cf536ac085a67f87e59eea8e15c68ce14c3db7c25a07ac85bccf97e2fe3c8e")
