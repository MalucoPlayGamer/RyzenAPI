-- Lua provided by RyzenAPI
-- Game: Police Simulator: Patrol Duty

-- MAIN APPLICATION
addappid(461870)

-- MAIN APP DEPOTS / PACKAGES
addappid(461871, 1, "33cf536ac085a67f87e59eea8e15c68ce14c3db7c25a07ac85bccf97e2fe3c8e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
