-- Lua provided by RyzenAPI
-- Game: 2276510

-- MAIN APPLICATION
addappid(2276510)
-- Game: addappid(2276510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276511, 1, "511786e98cd7d1c3ed982d70a702abe08695cdab29f8a7d563a55ffd43f3d396")
