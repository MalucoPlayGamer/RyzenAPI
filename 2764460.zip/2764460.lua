-- 2764460's Lua and Manifest Created by Hubcap Manifest
-- Sandustry
-- Created: August 13, 2026 at 11:26:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2764460, 1, "15d9eb03e6f3b5c1ec35e305e214ce1662b7103c7e74bcf06027417d695e942b") -- Sandustry
-- MAIN APP DEPOTS
addappid(2764461, 1, "7313b7e2315a3af93d98fd727e28b50647db89db3fa5fa10c3fc9e44e9a426b0") -- Depot 2764461
setManifestid(2764461, "5626794830932830034", 422672901)
addappid(2764462, 1, "03ca8509541506be95f7dba76c8288685dab30b4a1f1c229cbfed038821d4e5b") -- Depot 2764462
setManifestid(2764462, "3737510975080646579", 415465873)
addappid(2764463, 1, "ceaf644dcde4818ac2c611e76a35be4aa217488a642882195aa4918f98063612") -- Depot 2764463
setManifestid(2764463, "1549511250075029424", 577548302)