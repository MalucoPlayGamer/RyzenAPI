-- Lua provided by RyzenAPI 
-- Game: AppID 1383740
addappid(1383740)
addappid(1383741, 1, "1b23258b2f73afd20bb079fe44ddc4fd42a3e248ed95a1fc7d85051db09bc42b")
addappid(1410590, 0, "bd351356b814d96785e01e27f1ca1705f9f31c4a27a121110cf8cd2725e07aa5")
