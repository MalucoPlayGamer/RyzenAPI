-- Lua provided by RyzenAPI
-- Game: Game: AppID 545040

-- MAIN APPLICATION
addappid(545040)
-- Game: addappid(545040)

-- MAIN APP DEPOTS / PACKAGES
addappid(545041, 1, "4dde7a91c0187c1676c399c1747b601ebf96006d5fff94482045e41819688a92")
addappid(545042, 1, "1ce2661b91cbb8ec32833056ed6f146cd713c7cb851040db8f6f749aa01add9d")
