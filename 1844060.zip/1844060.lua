-- Lua provided by RyzenAPI
-- Game: Holy Purge : Exorcist

-- MAIN APPLICATION
addappid(1844060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844061, 1, "8022e032e4ac641a07618df8a97425201e98202ded5221fb7a3fe859617b2522")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
