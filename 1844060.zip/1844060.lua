-- Lua provided by RyzenAPI
-- Game: Game: Holy Purge : Exorcist

-- MAIN APPLICATION
addappid(1844060)
-- Game: addappid(1844060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844061, 1, "8022e032e4ac641a07618df8a97425201e98202ded5221fb7a3fe859617b2522")
