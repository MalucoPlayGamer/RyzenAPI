-- Lua provided by RyzenAPI
-- Game: The Symbiant - PG-13 Artbook & CG Pack

-- MAIN APPLICATION
addappid(2326980)
-- Game: addappid(2326980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326981, 1, "e30a6035d825b0549221198e64f1fedb21f6738da4888ed9948abd2d110d3490")
