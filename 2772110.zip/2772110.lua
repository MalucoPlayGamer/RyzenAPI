-- Lua provided by RyzenAPI
-- Game: Game: Imaginary Friend Asylum Demo

-- MAIN APPLICATION
addappid(2772110)
-- Game: addappid(2772110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772111, 1, "c5d90c71f9f94003e5afcab8444a31e1f1ba3d0c9d692ae2bec2affe4d14a938")
