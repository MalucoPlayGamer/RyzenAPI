-- Lua provided by RyzenAPI
-- Game: Housebreaker Demo

-- MAIN APPLICATION
addappid(2052620)
-- Game: addappid(2052620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052621, 1, "191fd452b9614809dcea34bd76ae2c7aa2dd01e60838826dd34128c5a23395c3")
