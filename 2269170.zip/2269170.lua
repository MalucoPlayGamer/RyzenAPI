-- Lua provided by RyzenAPI
-- Game: Keyboard Warrior: Dreamstate Prologue

-- MAIN APPLICATION
addappid(2269170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269172,0,"e97189b50d05cfdc008bfd85d1570553abc37517adff62e5f6692b5755221a99")
addappid(2269173,0,"5cd5751430fb9e7e84c08e5a0734d98d20cc2cefb50076ad29a9e32e0d495252")
