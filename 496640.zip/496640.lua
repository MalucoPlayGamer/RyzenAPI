-- Lua provided by RyzenAPI
-- Game: AppID 496640

-- MAIN APPLICATION
addappid(496640)

-- MAIN APP DEPOTS / PACKAGES
addappid(496641, 1, "4f200af63dc198136d08630e7aeffd4938a1109536d2e63cd3f31d1ee3be7aea")
