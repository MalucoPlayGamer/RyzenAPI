-- Lua provided by RyzenAPI
-- Game: Sophie's Guardian

-- MAIN APPLICATION
addappid(530830)
-- Game: addappid(530830)

-- MAIN APP DEPOTS / PACKAGES
addappid(530831, 1, "35d7ae86284e533fb497a8d74cc38a7612248a06d58c4d9445ad03e8e2e63b27")
