-- Lua provided by SkyAPI 
-- Game: Sophie's Guardian
addappid(530830)
addappid(530831, 1, "35d7ae86284e533fb497a8d74cc38a7612248a06d58c4d9445ad03e8e2e63b27")
