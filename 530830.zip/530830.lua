-- Lua provided by RyzenAPI
-- Game: Sophie's Guardian

-- MAIN APPLICATION
addappid(530830)

-- MAIN APP DEPOTS / PACKAGES
addappid(530831, 1, "35d7ae86284e533fb497a8d74cc38a7612248a06d58c4d9445ad03e8e2e63b27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
