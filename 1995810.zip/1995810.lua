-- Lua provided by RyzenAPI
-- Game: Life is not auto

-- MAIN APPLICATION
addappid(1995810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995811, 1, "0993b1914d88ca44075f837bb0ba269e70a798773e9828cce3b496e5f4e42088")

