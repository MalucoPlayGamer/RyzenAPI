-- Lua provided by RyzenAPI
-- Game: AppID 952540

-- MAIN APPLICATION
addappid(952540)
-- Game: addappid(952540)

-- MAIN APP DEPOTS / PACKAGES
addappid(952541, 1, "8596e1367edada0a70c520fa0f09230970d0353030dfc74ad9e932e5a5f23a75")
