-- Lua provided by SkyAPI 
-- Game: AppID 952540
addappid(952540)
addappid(952541, 1, "8596e1367edada0a70c520fa0f09230970d0353030dfc74ad9e932e5a5f23a75")
