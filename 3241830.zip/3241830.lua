-- Lua provided by RyzenAPI
-- Game: Velev Demo

-- MAIN APPLICATION
addappid(3241830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241831, 1, "bb20916ecb280e78b594265ffa701476280ef8d983018c33e74d0ba2d706b5f9")

