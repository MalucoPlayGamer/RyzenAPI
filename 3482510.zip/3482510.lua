-- Lua provided by RyzenAPI
-- Game: Packing Life

-- MAIN APPLICATION
addappid(3482510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3482512,0,"c4cf457ebdd9293f6cc3537a49b6e9c189d15d425fed62968132a1e7a600d071")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
