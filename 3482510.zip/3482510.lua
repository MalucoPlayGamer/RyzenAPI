-- Lua provided by RyzenAPI
-- Game: Packing Life

-- MAIN APPLICATION
addappid(3482510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3482512,0,"c4cf457ebdd9293f6cc3537a49b6e9c189d15d425fed62968132a1e7a600d071")

