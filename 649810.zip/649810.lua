-- Lua provided by RyzenAPI
-- Game: Windstorm: Start of a Great Friendship

-- MAIN APPLICATION
addappid(649810)

-- MAIN APP DEPOTS / PACKAGES
addappid(649811, 1, "8df2e146b2e8d317ac3040e46a7481816850093cf8f81693dc0731e1320957ae")

