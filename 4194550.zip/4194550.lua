-- Lua provided by RyzenAPI
-- Game: ElectroFix Simulator

-- MAIN APPLICATION
addappid(4194550)
