-- Lua provided by RyzenAPI
-- Game: Kiss Effect

-- MAIN APPLICATION
addappid(2288480)
addappid(2295620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288481, 1, "7dc6ce02ace230185492be138e8c98d53446f2f9bfb781c5737bdfc89ee7925c")
