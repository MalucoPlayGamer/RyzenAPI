-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1674680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674680,0,"18c463743e245fecb9b4be208e8b1ed7226f972565f9586d099a1d15a472ff68")

