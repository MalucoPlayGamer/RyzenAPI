-- Lua provided by RyzenAPI
-- Game: ESCHATOS

-- MAIN APPLICATION
addappid(378770)

-- MAIN APP DEPOTS / PACKAGES
addappid(378771, 1, "90956b3a9cb1baaf0e31fc75e4d9cd70001ffca073802c7a98839b24d3159803")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
