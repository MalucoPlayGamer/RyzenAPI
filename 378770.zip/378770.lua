-- Lua provided by RyzenAPI
-- Game: ESCHATOS

-- MAIN APPLICATION
addappid(378770)
-- Game: addappid(378770)

-- MAIN APP DEPOTS / PACKAGES
addappid(378771, 1, "90956b3a9cb1baaf0e31fc75e4d9cd70001ffca073802c7a98839b24d3159803")
