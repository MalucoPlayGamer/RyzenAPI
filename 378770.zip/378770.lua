-- Lua provided by SkyAPI 
-- Game: ESCHATOS
addappid(378770)
addappid(378771, 1, "90956b3a9cb1baaf0e31fc75e4d9cd70001ffca073802c7a98839b24d3159803")
