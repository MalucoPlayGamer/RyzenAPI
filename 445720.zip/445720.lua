-- Lua provided by RyzenAPI
-- Game: 445720

-- MAIN APPLICATION
addappid(445720)
addappid(639050)
-- Game: addappid(445720)

-- MAIN APP DEPOTS / PACKAGES
addappid(445721, 1, "683c4cf32059812953c8ad6c312ca46a5b964c213b28c61a605a3b4d6c82f66b")
