-- Lua provided by RyzenAPI
-- Game: Battle Islands: Commanders

-- MAIN APPLICATION
addappid(445720)
addappid(639050)

-- MAIN APP DEPOTS / PACKAGES
addappid(445721, 1, "683c4cf32059812953c8ad6c312ca46a5b964c213b28c61a605a3b4d6c82f66b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
