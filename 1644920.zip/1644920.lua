-- Lua provided by RyzenAPI
-- Game: Love in Belarus

-- MAIN APPLICATION
addappid(1644920)
-- Game: addappid(1644920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644921, 1, "b0178e08a7e7bb11a7e225b65386df380b6764ec52f6a9cba631926e560a4c1f")
