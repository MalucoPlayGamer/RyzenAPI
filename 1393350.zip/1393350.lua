-- Lua provided by RyzenAPI
-- Game: Swaying Girl

-- MAIN APPLICATION
addappid(1393350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393351, 1, "127ba573c89e588d1ebf1143d5ac398396761ac9872c33a8a0cdf94ba45b9bec")
addappid(1411520, 0, "e586ed20f11f3af27faedba91bbe31da12db4e28ced73c5eb6266186ad8abdba")
