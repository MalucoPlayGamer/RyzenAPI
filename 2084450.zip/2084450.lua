-- Lua provided by SkyAPI 
-- Game: DIRECT CONTACT
addappid(2084450)
addappid(2084451, 1, "a420d009e7a869269fa9bf952847a827b7a077539bf84522e0b6472ba53fc580")
