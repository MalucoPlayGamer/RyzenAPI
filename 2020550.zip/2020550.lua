-- Lua provided by RyzenAPI
-- Game: 風色幻想XX:交錯的軌跡

-- MAIN APPLICATION
addappid(2020550)
-- Game: addappid(2020550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020551, 1, "0c094fba007baecaa1c2bb0f35f8819a2abcae6cd2e75bc9407011453345e4fa")
