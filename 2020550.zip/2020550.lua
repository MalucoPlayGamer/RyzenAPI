-- Lua provided by RyzenAPI
-- Game: 風色幻想XX:交錯的軌跡

-- MAIN APPLICATION
addappid(2020550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020551, 1, "0c094fba007baecaa1c2bb0f35f8819a2abcae6cd2e75bc9407011453345e4fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
