-- Lua provided by RyzenAPI
-- Game: The Riftbreaker - Tools

-- MAIN APPLICATION
addappid(1849580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849581, 1, "a512d599d961dd55d454c1174c35b6822c6bcaa913ab9f89ec40ac1869301d76")
