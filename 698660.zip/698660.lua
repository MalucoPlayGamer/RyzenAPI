-- Lua provided by RyzenAPI
-- Game: UKNON Jones & Guynelk - Awesome!

-- MAIN APPLICATION
addappid(698660)

-- MAIN APP DEPOTS / PACKAGES
addappid(698661, 1, "4880cbf05e0c663fab96148171e6d94dd5dfe6900f9b19b27f869aa45f3f1185")

