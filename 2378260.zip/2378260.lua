-- Lua provided by RyzenAPI
-- Game: Kronian Titans Demo

-- MAIN APPLICATION
addappid(2378260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378261, 1, "f57247a8b3e957605c6068b12a40fe940f9c7e7ee9b437ac63c4292c23502236")

