-- Lua provided by RyzenAPI
-- Game: Game: Tales of Sorrow: Strawsbrough Town

-- MAIN APPLICATION
addappid(1009780)
-- Game: addappid(1009780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009781, 1, "fe806385940a22b72d4a58bc3dd30ab6364e044e29078a10d803d70aea61fc58")
addappid(1009782, 1, "1d6782a0ec50bf1a73a9720ed6200cdf95162752340229b690383c6fb27b2987")
addappid(1009783, 1, "359e967070d84358e88efeb652fe719f5eaf50c5a73041215183778317d55d75")
