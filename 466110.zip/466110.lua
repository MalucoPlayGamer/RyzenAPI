-- Lua provided by RyzenAPI
-- Game: Shaolin vs Wutang

-- MAIN APPLICATION
addappid(466110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(466111, 1, "2c8bbcb46587d27649fb1ab0e30c84a0e56b96a4ff9f2935861ad265dec74e1d")

