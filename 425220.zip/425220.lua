-- Lua provided by SkyAPI 
-- Game: One Piece Burning Blood
addappid(425220)
addappid(425221, 1, "67498d5ca47e8d438e47b160b8c99fff1ffe41ee1ff73fbfe13f157be02d16f3")
