-- Lua provided by RyzenAPI
-- Game: One Piece Burning Blood

-- MAIN APPLICATION
addappid(425220)
addappid(458440)
addappid(458441)
addappid(458442)
addappid(458443)
addappid(458444)
addappid(458445)
addappid(458460)
addappid(501570)
addappid(501580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(425221, 1, "67498d5ca47e8d438e47b160b8c99fff1ffe41ee1ff73fbfe13f157be02d16f3")

