-- Lua provided by SkyAPI 
-- Game: Unnatural Investigations
addappid(1596360)
addappid(1596361, 1, "30d2669ddbc63d9e52cda465f38d8c6bf93c280d503adfc70e7b35b6b30db6d8")
