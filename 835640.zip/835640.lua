-- Lua provided by RyzenAPI
-- Game: Dust and Salt: The Battle for Murk

-- MAIN APPLICATION
addappid(835640)

-- MAIN APP DEPOTS / PACKAGES
addappid(835641,0,"2760845a46b0177b1999abee0f56a274afc66161458546bdc5cd51926a067734")

