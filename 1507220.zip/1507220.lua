-- Lua provided by RyzenAPI
-- Game: addappid(1507220)

-- MAIN APPLICATION
addappid(1507220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507221, 1, "155ad670c6e552a0d1c33d58c84e7ea198a22d0faa31a54c6e7e232a9ab16447")
