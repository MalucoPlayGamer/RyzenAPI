-- Lua provided by RyzenAPI
-- Game: Exteria

-- MAIN APPLICATION
addappid(532660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(532662,0,"bd915104a9589b605fc36ff4359f8437abf7dcde1c1bab1dca47cf1b06e0eb99")

