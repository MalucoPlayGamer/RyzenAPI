-- Lua provided by RyzenAPI
-- Game: setManifestid(532662,"48515847503678389")

-- MAIN APPLICATION
addappid(532660)
-- Game: addappid(532660)

-- MAIN APP DEPOTS / PACKAGES
addappid(532662,0,"bd915104a9589b605fc36ff4359f8437abf7dcde1c1bab1dca47cf1b06e0eb99")
