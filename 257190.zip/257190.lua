-- Lua provided by RyzenAPI
-- Game: Alien Rage - Demo

-- MAIN APPLICATION
addappid(257190)
-- Game: addappid(257190)

-- MAIN APP DEPOTS / PACKAGES
addappid(257191, 1, "7708b8bcd7ce15b3f518d30bb4f5f2bee8666f515b6dcab11161351c7cc6f40b")
