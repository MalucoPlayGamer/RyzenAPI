-- Lua provided by RyzenAPI
-- Game: Police Quest - SWAT 2

-- MAIN APPLICATION
addappid(607120)

-- MAIN APP DEPOTS / PACKAGES
addappid(607121,0,"d5e8b3ffba866a5e26adb3ce07b533abef601983e434bbcac9fcbd37a3b18126")

