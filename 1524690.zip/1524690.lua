-- Lua provided by RyzenAPI
-- Game: addappid(1524690)

-- MAIN APPLICATION
addappid(1524690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524691, 1, "141f204859d1f0e47db89335e9a5297b5c2872984f94bf5b24b08a6cd498a0fb")
