-- Lua provided by RyzenAPI 
-- Game: Sabbat of the Witch
addappid(888790)
addappid(888791, 1, "8a02be19d12cc990782e2f5479cd6ae6e849a1edcb9d6bc72c37e7d46aadf922")
addappid(967420, 0, "49e02a28fec81f02632ce7667d4a654719b55fde5c9d99063e3c3c980e56fabe")
