-- Lua provided by RyzenAPI 
-- Game: AppID 1548090
addappid(1548090)
addappid(1548091, 1, "69b5fdac7dd45fe63539c4c71a6835d098592255d2bf5e8f7cda2e2d6c51aabc")
