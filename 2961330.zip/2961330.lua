-- Lua provided by RyzenAPI
-- Game: Secret Toy

-- MAIN APPLICATION
addappid(2961330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2961331, 1, "6ea6ca7a64c9b2d02e71650f0aae3cd9fee35619df9d64d34bf5d450208331cc")
addappid(2961332, 1, "d9f78ca5edb87a81d133ad392c1af943bdac141975ddaf1cdbaa2c9e36affde1")
