-- Lua provided by RyzenAPI
-- Game: HRDINA

-- MAIN APPLICATION
addappid(1077730)
addappid(1118230)
-- Game: addappid(1077730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077731, 1, "ac847f9d1e7cd0eddaddd5aef079278dd5700b16eab912bd3fc71acbf9e38dae")
