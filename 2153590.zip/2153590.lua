-- Lua provided by RyzenAPI
-- Game: addappid(2153590)

-- MAIN APPLICATION
addappid(2153590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153591, 1, "9f1aab5ea2396700534cb90ff72f64a9db59a150bc44e873f9badd06a7a706cd")
