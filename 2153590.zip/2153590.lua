-- Lua provided by RyzenAPI
-- Game: Detective Super Star

-- MAIN APPLICATION
addappid(2153590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153591, 1, "9f1aab5ea2396700534cb90ff72f64a9db59a150bc44e873f9badd06a7a706cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
