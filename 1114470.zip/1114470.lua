-- Lua provided by RyzenAPI
-- Game: Evan's Remains Demo

-- MAIN APPLICATION
addappid(1114470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114471, 1, "1435df2d838e705984f71e54f969a07bfd2c4153682cbd0f3e496d98902a8266")

