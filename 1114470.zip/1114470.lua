-- Lua provided by SkyAPI 
-- Game: Evan's Remains Demo
addappid(1114470)
addappid(1114471, 1, "1435df2d838e705984f71e54f969a07bfd2c4153682cbd0f3e496d98902a8266")
