-- Lua provided by RyzenAPI
-- Game: addappid(1835020)

-- MAIN APPLICATION
addappid(1835020)
addappid(1995270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835021, 1, "b5d18f5076506a00ef0afdf8d3361661cd7bf57954061efd9e839813f2dabed7")
addappid(1835022, 1, "51bf7a93dee70b38ebf6320a7e2a16d57657e2a95735d80ff0024a5bd2c4b797")
