-- Lua provided by RyzenAPI
-- Game: Game: Old Coin Pusher Friends 3

-- MAIN APPLICATION
addappid(3040390)
-- Game: addappid(3040390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040391, 1, "ed93093fda173889775fd24d60acb0871a4c602a75f4cab18904a2afa800860a")
