-- Lua provided by RyzenAPI
-- Game: addappid(1587020)

-- MAIN APPLICATION
addappid(1587020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587023,0,"591529ec66001a891cf8415fec3e9eede17bf782d4a301ef6acb188f20cdd249")
