-- Lua provided by RyzenAPI
-- Game: 3243750

-- MAIN APPLICATION
addappid(3243750)
-- Game: addappid(3243750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243750,0,"af0711303d4e1f70ab40d65d30fbff2e15b01ee4d3a5dea64cf1407f42260a54")
