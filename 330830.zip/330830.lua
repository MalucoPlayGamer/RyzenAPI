-- Lua provided by RyzenAPI
-- Game: Tales from the Borderlands

-- MAIN APPLICATION
addappid(330830)

-- MAIN APP DEPOTS / PACKAGES
addappid(330831, 1, "7a494bb8ee30c3c02b597f9743a9ea1a94b48dfcbe0df1c142553a839f8a7513")
addappid(330832, 1, "c582a51de44a058242f8b19f4ee57e3f50250f21d195f30084e26b94d53d847a")
addappid(330833, 1, "b7fd83b5e7b12cf270ad8581d444bea1ec01f316279dd115cc748fffc7836fd4")
addappid(330834, 1, "f363e36ee7829d4e2e9e949053d4ce29d9edbc73f9e74c091d14c1c8503af379")
addappid(330835, 1, "a03bfcda0f60c5cc28919208f4113d48c739a041a4be32dfb4f0130e407e24e1")
addappid(330836, 1, "1267c8f620a70ae6f0d430e47b1aa2cf2980e6cacb6736d3e0d5973c19f325b9")
addappid(330837, 1, "12d0a3627a84440c700716fbaff12cd038f8bfe6a5e8e3424d65c4b39721956c")
addappid(330838, 1, "4c60619e5577aa330b0eb0c2494d85b084d52316c3af4f62de982ac6fedbee51")
addappid(330839, 1, "89207c585e7b98c7691bab8276946bc9066029b4d89a6a46c19ccf665ab6da40")
addappid(371770, 0, "953af850b6fb3ae73a1da47fcbe8ad9835336acc17749fb7ef45320c4ccf32cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
