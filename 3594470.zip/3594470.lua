-- Lua provided by RyzenAPI 
-- Game: AppID 3594470
addappid(3594470)
addappid(3594471, 1, "b328a3ff6849639469e9c6c4a9698650b395d3d460bf736710071629dd92ed0d")
