-- Lua provided by RyzenAPI 
-- Game: AppID 716260
addappid(716260)
addappid(716261, 1, "9b51934a41d3883f348de32b2659b8b935ec08f09d1c6779547831398c2984ee")
