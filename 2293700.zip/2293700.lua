-- Lua provided by SkyAPI 
-- Game: Crimson Veil
addappid(2293700)
addappid(2293701, 1, "9a145eabdc0b46e5af67d59889fa8650ee434558aa5e080e20ea02f3074d5097")
