-- Lua provided by RyzenAPI
-- Game: addappid(2293700)

-- MAIN APPLICATION
addappid(2293700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293701, 1, "9a145eabdc0b46e5af67d59889fa8650ee434558aa5e080e20ea02f3074d5097")
