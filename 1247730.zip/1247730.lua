-- Lua provided by RyzenAPI
-- Game: Game: Carrots and Cream

-- MAIN APPLICATION
addappid(1247730)
-- Game: addappid(1247730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247731, 1, "49420497a9529a9296dc3320b61d540993b9684a48151314adf9eb6eb51daf2a")
