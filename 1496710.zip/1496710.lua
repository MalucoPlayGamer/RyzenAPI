-- Lua provided by RyzenAPI
-- Game: Game: Zombie Alert

-- MAIN APPLICATION
addappid(1496710)
addappid(1542520)
-- Game: addappid(1496710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496711, 1, "f9c5f8ea1a0465d206df27db1931a301238c476ed800f59bdc44f592317f04ae")
