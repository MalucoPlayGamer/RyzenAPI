-- Lua provided by RyzenAPI
-- Game: UncleOffice:uncle Dating Simulator

-- MAIN APPLICATION
addappid(1728490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728491, 1, "de758912698ef014e1fbc08dc8ef53dc2940cdae36be33dacbd9fef155665915")

