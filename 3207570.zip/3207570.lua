-- Lua provided by RyzenAPI
-- Game: addappid(3207570)

-- MAIN APPLICATION
addappid(3207570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207571, 1, "fd3b9687e740a4df00347dd61b2836eeb7418da36c9d2fec5aaa4c31a1374bfb")
