-- 4526440's Lua and Manifest Created by Hubcap Manifest
-- Futa Succubus Slay!
-- Created: August 26, 2026 at 12:17:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4526440) -- Futa Succubus Slay!
-- MAIN APP DEPOTS
addappid(4526441, 1, "c90d8b54dcc16bbb1860f8ffd0d24e06a1a6c137f9e9eab5467468a0eef2f73f") -- Depot 4526441
setManifestid(4526441, "7668543553401707907", 1629143010)