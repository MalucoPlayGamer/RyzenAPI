-- Lua provided by RyzenAPI
-- Game: Futa Succubus Slay!

-- MAIN APPLICATION
addappid(4526440) -- Futa Succubus Slay!

-- MAIN APP DEPOTS / PACKAGES
addappid(4526441, 1, "c90d8b54dcc16bbb1860f8ffd0d24e06a1a6c137f9e9eab5467468a0eef2f73f") -- Depot 4526441

