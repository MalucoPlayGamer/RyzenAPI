-- Lua provided by RyzenAPI
-- Game: Peglin Demo

-- MAIN APPLICATION
addappid(1326880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326881, 1, "cb985940675c97dda27891c76bb16dcf5961a4dc4a02fbab0a9e18a4d45a02a2")

