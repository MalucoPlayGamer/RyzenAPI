-- Lua provided by RyzenAPI
-- Game: Bloody Hills Demo

-- MAIN APPLICATION
addappid(2734060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2734061, 1, "f5394a698e981bc559725bb0feb9cbb93af6828d6fdde7bd4b37f341c0454b6b")
