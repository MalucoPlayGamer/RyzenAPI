-- Lua provided by RyzenAPI
-- Game: PalmRide

-- MAIN APPLICATION
addappid(1415320)
-- Game: addappid(1415320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415321, 1, "2a291d2f72c045c527849bf5974ab31a98b250a521e1cb03442060ab5ddb1849")
