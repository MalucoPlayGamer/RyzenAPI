-- Lua provided by RyzenAPI
-- Game: Pachi Pachi On A Roll

-- MAIN APPLICATION
addappid(1599940)
-- Game: addappid(1599940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599941, 1, "83879e89740c9ed8f7027375cbfb05b27232db18078184a0120db14fa7e52fe5")
