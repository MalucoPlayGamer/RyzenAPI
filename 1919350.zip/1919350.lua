-- Lua provided by RyzenAPI
-- Game: Coral Cove

-- MAIN APPLICATION
addappid(1919350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919351, 1, "3914f411520b0218bb8b87383f27f92e19c1fbb3b8530279932fbf692f799e9e")

