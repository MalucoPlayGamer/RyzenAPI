-- Lua provided by RyzenAPI
-- Game: 1828740

-- MAIN APPLICATION
addappid(1828740)
addappid(2481050)
addappid(2481051)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828742,0,"bad473cd425fca956d1a0bd4fcb30230a8542793d6b99d5974fe40c5d0b3c472")

