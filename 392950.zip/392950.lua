-- Lua provided by RyzenAPI
-- Game: Lost Lands: A Hidden Object Adventure

-- MAIN APPLICATION
addappid(392950)

