-- Lua provided by RyzenAPI
-- Game: addappid(549680)

-- MAIN APPLICATION
addappid(549680)

-- MAIN APP DEPOTS / PACKAGES
addappid(549681, 1, "32d86de176be0d2f84e1eab2f2ba306361e5e60e4362de465d27b4ea1b65370d")
