-- Lua provided by RyzenAPI 
-- Game: SaiIn Rhythm
addappid(1794320)
addappid(1794321, 1, "c2f35bf310e502b406757c9d8c85744f9f36f3e771e68f92833187219de55f16")
addappid(1794323, 1, "ae65ef1c9dad506823fcda8c065ee9683f9b6c85a25698c3310c49461a7fd138")
addappid(1794324, 1, "1e4e6aab5fbe5e8f9b7f6a714b13dece299b6fbf1e49ba307b58120d13bf858f")
