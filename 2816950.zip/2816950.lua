-- Lua provided by RyzenAPI
-- Game: Yaoling: Mythical Journey

-- MAIN APPLICATION
addappid(2816950)
-- Game: addappid(2816950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2816951, 1, "1821d0a58d878d0c38d0df188d51e486f885a0e63cb8c70d3a1ac4c7a9740bc1")
addappid(3758970, 0, "ea38e9c3e11218bc90403f138721d51857c5dd96deb84496608aa1ebf7ef8ab7")
