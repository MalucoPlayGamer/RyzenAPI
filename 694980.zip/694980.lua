-- Lua provided by RyzenAPI
-- Game: Fjong

-- MAIN APPLICATION
addappid(694980)

-- MAIN APP DEPOTS / PACKAGES
addappid(694981, 1, "053d11ce4733d4400fc6f7dba799f184771890c4c2f2528ec5f5f3e8ab62ea1a")

