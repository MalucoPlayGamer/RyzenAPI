-- Lua provided by RyzenAPI
-- Game: 2405880

-- MAIN APPLICATION
addappid(2405880)
-- Game: addappid(2405880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405881, 1, "fe48613925bbf82ecfd34d3f7b03644f44f5100513f2b806ff15adaee69b7d5c")
