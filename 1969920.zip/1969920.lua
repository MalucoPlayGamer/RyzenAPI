-- Lua provided by RyzenAPI
-- Game: Tomb Explorer VR

-- MAIN APPLICATION
addappid(1969920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1969921, 1, "fab6ed41c008bd0014a16e04b9622d5f4804e37b9c2a3b8039896748665276fe")

