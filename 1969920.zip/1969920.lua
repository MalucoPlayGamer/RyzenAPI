-- Lua provided by RyzenAPI
-- Game: Tomb Explorer VR

-- MAIN APPLICATION
addappid(1969920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969921, 1, "fab6ed41c008bd0014a16e04b9622d5f4804e37b9c2a3b8039896748665276fe")

