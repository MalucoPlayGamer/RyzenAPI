-- Lua provided by RyzenAPI
-- Game: 4006040

-- MAIN APPLICATION
addappid(4006040)
-- Game: addappid(4006040)

-- MAIN APP DEPOTS / PACKAGES
addappid(4006041, 1, "7e1e29a2c518925c472bae0cfbd6cd1cb07716174dff3871257741094a2ef0b8")
