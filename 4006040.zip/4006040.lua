-- Lua provided by SkyAPI 
-- Game: VEGAS Pro 23 Steam Edition
addappid(4006040)
addappid(4006041, 1, "7e1e29a2c518925c472bae0cfbd6cd1cb07716174dff3871257741094a2ef0b8")
