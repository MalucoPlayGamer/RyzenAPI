-- Lua provided by SkyAPI 
-- Game: The Maid
addappid(3456720)
addappid(3456721, 1, "7b272889804c644280e04e912894edcfc1c930c445d84e81936e5be39ebd9aff")
