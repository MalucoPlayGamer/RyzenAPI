-- Lua provided by RyzenAPI
-- Game: addappid(3456720)

-- MAIN APPLICATION
addappid(3456720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456721, 1, "7b272889804c644280e04e912894edcfc1c930c445d84e81936e5be39ebd9aff")
