-- Lua provided by RyzenAPI
-- Game: Sentinel Agency

-- MAIN APPLICATION
addappid(2951380)
addappid(3470410)
-- Game: addappid(2951380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951381, 1, "f502570d7e9bdc5854c428991c6512d0bbd55d8eae64fac6b41911a085aa7289")
