-- Lua provided by RyzenAPI
-- Game: Mash Box

-- MAIN APPLICATION
addappid(3062380)
-- Game: addappid(3062380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062381, 1, "93d781f60088263fb335848ca03b104dcadf78b356dc2f2096a1462449047e8a")
