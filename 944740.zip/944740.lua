-- Lua provided by RyzenAPI
-- Game: 944740

-- MAIN APPLICATION
addappid(944740)
-- Game: addappid(944740)

-- MAIN APP DEPOTS / PACKAGES
addappid(944741, 1, "f073bd6b2f8526b548f6e81e7a465f173158316472b3fc46dc1e2199d4b02914")
