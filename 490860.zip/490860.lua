-- Lua provided by RyzenAPI
-- Game: addappid(490860)

-- MAIN APPLICATION
addappid(490860)

-- MAIN APP DEPOTS / PACKAGES
addappid(490861, 1, "0e52ef4487de4fec7699c6c1cd670393d39da89f10ac7e9f96c6d65bc803cb5d")
