-- Lua provided by RyzenAPI 
-- Game: DashBored
addappid(490860)
addappid(490861, 1, "0e52ef4487de4fec7699c6c1cd670393d39da89f10ac7e9f96c6d65bc803cb5d")
