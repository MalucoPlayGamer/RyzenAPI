-- Lua provided by RyzenAPI
-- Game: 3036880

-- MAIN APPLICATION
addappid(3036880)
-- Game: addappid(3036880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036881, 1, "12450ce23a0d1719983cb268be40542cadbca0ccf12309de87fd372d79536e7f")
