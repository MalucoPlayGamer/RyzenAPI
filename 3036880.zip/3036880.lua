-- Lua provided by RyzenAPI
-- Game: Panic In The Woods

-- MAIN APPLICATION
addappid(3036880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036881, 1, "12450ce23a0d1719983cb268be40542cadbca0ccf12309de87fd372d79536e7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
