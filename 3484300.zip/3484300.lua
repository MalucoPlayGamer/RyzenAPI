-- Lua provided by RyzenAPI
-- Game: DREADZONE

-- MAIN APPLICATION
addappid(3484300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484301, 1, "e26f07fd4b7fdee8af7f179b8f498c0527b56121cc06ecfa93a2b3c2c683e226")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
