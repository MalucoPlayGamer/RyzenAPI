-- Lua provided by RyzenAPI
-- Game: DREADZONE

-- MAIN APPLICATION
addappid(3484300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484301, 1, "e26f07fd4b7fdee8af7f179b8f498c0527b56121cc06ecfa93a2b3c2c683e226")

