-- Lua provided by SkyAPI 
-- Game: BLOODSONG
addappid(2484860)
addappid(2484861, 1, "1a693d7f085f715d8e2f4971499c7d2661d2c78c6d91515d58f475380a631ac5")
