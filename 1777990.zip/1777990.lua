-- Lua provided by RyzenAPI
-- Game: Ortharion : The Last Battle

-- MAIN APPLICATION
addappid(1777990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777991, 1, "84fe2811c0b367fb79acda1b7efc728fffb80c6a8e171ecde29a9deea0e1e278")
