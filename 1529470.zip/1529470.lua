-- Lua provided by RyzenAPI 
-- Game: Ethereal Estate
addappid(1529470)
addappid(1529471, 1, "b320ad2d01696bda5e6f3080a9cf25a1ca819d9cbfedc66fe1af0ac191e10968")
