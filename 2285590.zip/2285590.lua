-- Lua provided by RyzenAPI
-- Game: Field Guide

-- MAIN APPLICATION
addappid(2285590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285590,0,"3a691865239e553dea5eb6f96ec162d91ea200caf69f4a56943b7ef9ab4f9eea")

