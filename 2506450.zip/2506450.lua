-- Lua provided by RyzenAPI
-- Game: Guayota

-- MAIN APPLICATION
addappid(2506450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2506451, 1, "25b14467aceb9d8e80f98fd10b7878ab6f1b6fd664f8edb3f1764ca9de4f2301")

