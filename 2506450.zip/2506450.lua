-- Lua provided by RyzenAPI
-- Game: Guayota

-- MAIN APPLICATION
addappid(2506450)
-- Game: addappid(2506450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506451, 1, "25b14467aceb9d8e80f98fd10b7878ab6f1b6fd664f8edb3f1764ca9de4f2301")
