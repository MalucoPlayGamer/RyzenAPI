-- Lua provided by RyzenAPI
-- Game: Fall of Civilization

-- MAIN APPLICATION
addappid(467010)

-- MAIN APP DEPOTS / PACKAGES
addappid(467011, 1, "fe15018e7c64bed3282fb4254ae65a58b12716cea264b14c64924e541a600971")

