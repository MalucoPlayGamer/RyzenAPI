-- Lua provided by RyzenAPI
-- Game: Ultimate Racing 2D

-- MAIN APPLICATION
addappid(808080)

-- MAIN APP DEPOTS / PACKAGES
addappid(808081, 1, "78507256a08af869b7e680ecf58b7b04b7edd50257e3bdf26d34d53fe53362e1")

