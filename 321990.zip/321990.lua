-- Lua provided by RyzenAPI
-- Game: Dreaming Sarah OST

-- MAIN APPLICATION
addappid(321990)

-- MAIN APP DEPOTS / PACKAGES
addappid(321990,0,"2c1ae486a6b70f4101b2c1f34fcc151478683c9363c092734811a7db5eb622f5")
