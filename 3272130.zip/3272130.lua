-- Lua provided by RyzenAPI
-- Game: Guild Master Demo

-- MAIN APPLICATION
addappid(3272130)
-- Game: addappid(3272130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272131, 1, "24db6466557d48f9b8edc25a61c2c96bf1da1f3e78fcc2e9796f0b521ca00001")
