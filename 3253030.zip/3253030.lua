-- Lua provided by RyzenAPI
-- Game: Game: Is It Wrong to Try to Pick Up Girls in a Dungeon? ~Fullland of Water and Light~

-- MAIN APPLICATION
addappid(3253030)
-- Game: addappid(3253030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253031, 1, "5f592c020816020c22f6a8045b20314ba58a002969a686e3ffd30897b6e9d055")
