-- Lua provided by RyzenAPI
-- Game: addappid(2012440)

-- MAIN APPLICATION
addappid(2012440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012441, 1, "0c0e5e1356e637f69e7437aafcd7e745c6f79f05c0e624a4358e62238774f3b0")
