-- Lua provided by RyzenAPI
-- Game: 3686200

-- MAIN APPLICATION
addappid(3686200)
-- Game: addappid(3686200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3686201, 1, "f41f561278e598e4486170095ebddcf04175cd7bca05b12bf1af5442050d646a")
