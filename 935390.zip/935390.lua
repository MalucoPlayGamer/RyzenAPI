-- Lua provided by RyzenAPI
-- Game: addappid(935390)

-- MAIN APPLICATION
addappid(935390)

-- MAIN APP DEPOTS / PACKAGES
addappid(935390,0,"66ff217ac29dd2a8b5d3b6a44e14dba3a37dc9417c47086df0094a8b8f511544")
