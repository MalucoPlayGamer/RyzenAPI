-- Lua provided by RyzenAPI
-- Game: addappid(872730)

-- MAIN APPLICATION
addappid(872730)

-- MAIN APP DEPOTS / PACKAGES
addappid(872731, 1, "eae5456e200fee174385e10f4c34edb0cec76db9af8be37fd1aa283e6f522dca")
