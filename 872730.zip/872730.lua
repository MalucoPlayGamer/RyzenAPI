-- Lua provided by RyzenAPI 
-- Game: Test your knowledge: Cities
addappid(872730)
addappid(872731, 1, "eae5456e200fee174385e10f4c34edb0cec76db9af8be37fd1aa283e6f522dca")
