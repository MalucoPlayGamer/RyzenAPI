-- Lua provided by RyzenAPI
-- Game: Shanghai Summer - Digital Art

-- MAIN APPLICATION
addappid(2867940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867941, 1, "0f403113218dfca7c13ab60f869388b28bdadf260f5db6c50a4a85a391c3c47e")

