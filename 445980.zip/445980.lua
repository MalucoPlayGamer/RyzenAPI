-- Lua provided by RyzenAPI
-- Game: Wizard of Legend

-- MAIN APPLICATION
addappid(445980)

-- MAIN APP DEPOTS / PACKAGES
addappid(445982,0,"cdf637c83cb12982e2cb9ca6b78c5f00d69dc5f00e4aa428dbe8ff7132f9a2e1")
addappid(445983,0,"8a3dca72182906dc87b1e1a83ca8bc13479be34c98ada2b43403eb4069209f40")
addappid(445984,0,"037874df1150cc2bcc61efb177a924e78f795f6d1b3bb5d1b09b73f592f4c2ee")
addappid(445985,0,"092b925b18aaa7123e8fba48be04b5662332aafa8fb69bb23560457ac16e8d72")
addappid(813840,0,"2e914f073a9a56ca520a68fd74e6fcc97f53d3d0dd2449dba4aa3d6b174cad0c")

