-- Lua provided by RyzenAPI
-- Game: Phoenix Dynasty 2

-- MAIN APPLICATION
addappid(621880)

-- MAIN APP DEPOTS / PACKAGES
addappid(621882,0,"5aac3d9222cf2440f675d237adb1981c3ca6ef025bcfce73a272233f032545af")

