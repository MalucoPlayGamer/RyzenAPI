-- Lua provided by RyzenAPI
-- Game: A Tiny Sticker Tale

-- MAIN APPLICATION
addappid(2322180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322181, 1, "45ae272150a8590672f4d496733bca5a689658ef51013e95fc1b1dcfc0ee2311")

