-- Lua provided by RyzenAPI
-- Game: AppID 923570

-- MAIN APPLICATION
addappid(923570)
-- Game: addappid(923570)

-- MAIN APP DEPOTS / PACKAGES
addappid(923571, 1, "b58a0156345cf32aa464d66ad6b06cde89fad20164f333fa8c034b7d5bb30233")
