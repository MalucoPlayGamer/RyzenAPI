-- Lua provided by RyzenAPI
-- Game: 迷离诡夜 blurred weird night Demo

-- MAIN APPLICATION
addappid(1452780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452781, 1, "e8feba047e19dca8f50f32c0be581524a7d7f5566148fc666fba1357b338f579")
