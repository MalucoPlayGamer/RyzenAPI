-- Lua provided by RyzenAPI
-- Game: Game: Anomaly Collapse Original Soundtrack

-- MAIN APPLICATION
addappid(3017060)
-- Game: addappid(3017060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017061, 1, "4688b220643cfffca45e495c2c16dede0488b0508c0ba96b9ba7614232544642")
addappid(3017062, 1, "1d6e7594c3d27704149659df9f72fa6fcc7e460bb3d6b029854ad4dfd794bf17")
