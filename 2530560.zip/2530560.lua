-- Lua provided by SkyAPI 
-- Game: Rusty Rabbit
addappid(2530560)
addappid(2530561, 1, "8c0fa80b5a03553119bc455a56201365fb3e38750e25a1478dbfb53b9f2b7ac6")
