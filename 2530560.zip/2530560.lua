-- Lua provided by RyzenAPI
-- Game: 2530560

-- MAIN APPLICATION
addappid(2530560)
-- Game: addappid(2530560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530561, 1, "8c0fa80b5a03553119bc455a56201365fb3e38750e25a1478dbfb53b9f2b7ac6")
