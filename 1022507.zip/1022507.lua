-- Lua provided by RyzenAPI
-- Game: DFF NT: Scion Healer's Robe Appearance Set for Y'shtola

-- MAIN APPLICATION
addappid(1022507)
-- Game: addappid(1022507)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022507,0,"97414cab8c67387cfbd67c8220827159feb1c18c2ea3e43288491e4a94f37b1f")
