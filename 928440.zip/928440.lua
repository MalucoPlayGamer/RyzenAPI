-- Lua provided by RyzenAPI
-- Game: Game: AppID 928440

-- MAIN APPLICATION
addappid(928440)
-- Game: addappid(928440)

-- MAIN APP DEPOTS / PACKAGES
addappid(928441, 1, "c98d4dea8619bcb77a3428b4d223dd87c6dc236a2314584d31f0612a96a58717")
