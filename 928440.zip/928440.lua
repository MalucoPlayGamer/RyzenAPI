-- Lua provided by RyzenAPI
-- Game: Azure Reflections

-- MAIN APPLICATION
addappid(928440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(928441, 1, "c98d4dea8619bcb77a3428b4d223dd87c6dc236a2314584d31f0612a96a58717")

