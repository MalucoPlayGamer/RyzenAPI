-- Lua provided by RyzenAPI
-- Game: Fetish Room 18+

-- MAIN APPLICATION
addappid(2487120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487121, 1, "24d4253247ac5fe6e93e27e47030e4f4242d64eb1281c4c3686f617ccfeefeee")

