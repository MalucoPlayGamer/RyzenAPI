-- Lua provided by RyzenAPI
-- Game: Fetish Room 18+

-- MAIN APPLICATION
addappid(2487120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2487121, 1, "24d4253247ac5fe6e93e27e47030e4f4242d64eb1281c4c3686f617ccfeefeee")

