-- Lua provided by RyzenAPI
-- Game: Game: AppID 1017900

-- MAIN APPLICATION
addappid(1017900)
-- Game: addappid(1017900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017901, 1, "d28682965acebec2e120b391343fe1f369835501696e82b33a6312037eb0b0d5")
