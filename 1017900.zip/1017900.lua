-- Lua provided by SkyAPI 
-- Game: AppID 1017900
addappid(1017900)
addappid(1017901, 1, "d28682965acebec2e120b391343fe1f369835501696e82b33a6312037eb0b0d5")
