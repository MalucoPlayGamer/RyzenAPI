-- Lua provided by RyzenAPI 
-- Game: Greed and Fear and the Rest
addappid(2514650)
addappid(2514651, 1, "ef163f80f881ee1bac20558dd6d7a5f91a55464f5b7a6b0d6b3d1183c39ce29f")
