-- Lua provided by RyzenAPI
-- Game: addappid(2780830)

-- MAIN APPLICATION
addappid(2780830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780830,0,"3e647fcc837c11a11f603de9ba432b0188cd530ba21777a952ab49cef8b63986")
