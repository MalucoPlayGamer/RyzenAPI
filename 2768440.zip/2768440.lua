-- Lua provided by RyzenAPI
-- Game: 2768440

-- MAIN APPLICATION
addappid(2768440)
-- Game: addappid(2768440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768441, 1, "a9438153a7cafa7aa421922f7218fbdfc0deee48a834f2143ed89dc52211992c")
