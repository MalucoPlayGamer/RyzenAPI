-- Lua provided by RyzenAPI
-- Game: 394550

-- MAIN APPLICATION
addappid(394550)
-- Game: addappid(394550)

-- MAIN APP DEPOTS / PACKAGES
addappid(394551, 1, "69779add303dfdcc16cfd30976ca0c9d4f48a9aeafa6af53913ddf4a32aaf38a")
