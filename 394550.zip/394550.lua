-- Lua provided by RyzenAPI
-- Game: Gunman Clive 2

-- MAIN APPLICATION
addappid(394550)

-- MAIN APP DEPOTS / PACKAGES
addappid(394551, 1, "69779add303dfdcc16cfd30976ca0c9d4f48a9aeafa6af53913ddf4a32aaf38a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
