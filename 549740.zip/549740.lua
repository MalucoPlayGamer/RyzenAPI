-- Lua provided by RyzenAPI
-- Game: addappid(549740)

-- MAIN APPLICATION
addappid(549740)

-- MAIN APP DEPOTS / PACKAGES
addappid(549741, 1, "6424eda7fb1937db9bc2314ba460f9c95a47da0593f3880c61cc009c2d407be7")
