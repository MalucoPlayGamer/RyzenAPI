-- Lua provided by RyzenAPI
-- Game: 1541240

-- MAIN APPLICATION
addappid(1541240)
-- Game: addappid(1541240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541241, 1, "fe15aafeabc282adbe92adf5fdc1097e010ccf33161e224f94981f28b2a34f04")
