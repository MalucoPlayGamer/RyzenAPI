-- Lua provided by RyzenAPI
-- Game: addappid(768180)

-- MAIN APPLICATION
addappid(768180)

-- MAIN APP DEPOTS / PACKAGES
addappid(768181, 1, "387e4ff009cd4c11799c21ad68361c11d1ef0a6217aa7cf1c9f651e392ae9913")
addappid(768182, 1, "d6cda88aeb93052d1a50d06f46dfddfb6a8072ceba8edff06f19c2f21d08fd80")
addappid(768183, 1, "08eaab94f10fd2543b3f88b9ab693c0c07e26dce887b250f2711ee310104146f")
