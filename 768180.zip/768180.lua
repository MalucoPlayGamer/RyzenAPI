-- Lua provided by RyzenAPI
-- Game: Truck Driver

-- MAIN APPLICATION
addappid(768180)
addappid(1279710)
addappid(1279711)
addappid(1279712)
addappid(1279713)
addappid(1279714)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(768181, 1, "387e4ff009cd4c11799c21ad68361c11d1ef0a6217aa7cf1c9f651e392ae9913")
addappid(768182, 1, "d6cda88aeb93052d1a50d06f46dfddfb6a8072ceba8edff06f19c2f21d08fd80")
addappid(768183, 1, "08eaab94f10fd2543b3f88b9ab693c0c07e26dce887b250f2711ee310104146f")
