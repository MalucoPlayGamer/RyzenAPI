-- Lua provided by RyzenAPI 
-- Game: 完蛋！我被美女包围了！-房间里的心跳VR花絮
addappid(2802560)
addappid(2802561, 1, "ab048c10716f3151b945a8b4232dbf6f3e2d05971c6d07e0575895e448e2f3f9")
