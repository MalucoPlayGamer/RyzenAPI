-- Lua provided by RyzenAPI 
-- Game: Crime Cities
addappid(1112570)
addappid(1112571, 1, "a834859eed146e195151e2868b17843fb4b69ad8c40d7c728aefd5329701d8f1")
addappid(1112572, 1, "b47bbe77d0b112e3ab3880c9a206bba35f4b2ed167b4bf47efe8eab212ed8f3b")
