-- Lua provided by RyzenAPI
-- Game: Crime Cities

-- MAIN APPLICATION
addappid(1112570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112571, 1, "a834859eed146e195151e2868b17843fb4b69ad8c40d7c728aefd5329701d8f1")
addappid(1112572, 1, "b47bbe77d0b112e3ab3880c9a206bba35f4b2ed167b4bf47efe8eab212ed8f3b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
