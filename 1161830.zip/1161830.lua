-- Lua provided by RyzenAPI
-- Game: addappid(1161830)

-- MAIN APPLICATION
addappid(1161830)
addappid(3988050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161831, 1, "e1a623d865fa1f73a35221e8f9e08f42bedac87bb2b26a0110c87fa8324467d0")
