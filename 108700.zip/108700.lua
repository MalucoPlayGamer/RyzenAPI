-- Lua provided by RyzenAPI
-- Game: Death Rally

-- MAIN APPLICATION
addappid(108700)
-- Game: addappid(108700)

-- MAIN APP DEPOTS / PACKAGES
addappid(108701, 1, "317c7bae5e38b7f8cfa0719c4432b0d0ed13589473cbb7dc8d73e96f45647a8e")
