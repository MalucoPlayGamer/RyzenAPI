-- Lua provided by RyzenAPI
-- Game: Sidewards Demo

-- MAIN APPLICATION
addappid(3274590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274591, 1, "d6125787f0500d6ff41e71244a57ea0d21f57864f2848668c2c9fca49fb31926")
