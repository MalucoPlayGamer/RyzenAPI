-- Lua provided by RyzenAPI
-- Game: Game: House of Sin

-- MAIN APPLICATION
addappid(1697400)
-- Game: addappid(1697400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697401, 1, "717c26e602c30e659e48c8aeffe073431810ced790b0cf9c23ebe2105d789779")
