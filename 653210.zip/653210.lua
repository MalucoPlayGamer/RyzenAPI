-- Lua provided by RyzenAPI
-- Game: Prisoner

-- MAIN APPLICATION
addappid(653210)

-- MAIN APP DEPOTS / PACKAGES
addappid(653212,0,"dc70c4ce43e59cd97b878673ed66a6455fc90dc437f0def959a3c94d6b3a1f75")
addappid(653213,0,"5c562a68cd39fa71eacbcf3e0761f8dd069ddcb970f40988bec7156be539f814")
addappid(741380,0,"039d7451dd5bacad985d5be44dfa51979ec07819e247c47a46e01ca1988a16a1")

