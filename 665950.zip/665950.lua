-- Lua provided by RyzenAPI
-- Game: Creepy Races

-- MAIN APPLICATION
addappid(665950)

-- MAIN APP DEPOTS / PACKAGES
addappid(665951,0,"0b425b575062a3299701e441a8e286ffec92a3d20ca307bd7d35c8ac048891bc")

