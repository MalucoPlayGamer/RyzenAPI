-- Lua provided by RyzenAPI
-- Game: 1158770

-- MAIN APPLICATION
addappid(1158770)
-- Game: addappid(1158770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158771, 1, "7bdfcf7cc1f70bc24d738d2ff1710bb63b0701a93ca8f3956e6eae281909bc39")
