-- Lua provided by RyzenAPI
-- Game: AppID 1158770

-- MAIN APPLICATION
addappid(1158770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158771, 1, "7bdfcf7cc1f70bc24d738d2ff1710bb63b0701a93ca8f3956e6eae281909bc39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1158780)
