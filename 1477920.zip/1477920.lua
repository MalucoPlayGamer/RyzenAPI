-- Lua provided by RyzenAPI
-- Game: Night Book

-- MAIN APPLICATION
addappid(1477920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477921, 1, "57add1602176872ee07c28ed010a651b4642a7b52aec42fd1c521bfcd6e3fafc")
addappid(1477923, 1, "f9dd87b6ec08e57872d28529c7580677d38d8edb0d464ce78700db9be136d981")

