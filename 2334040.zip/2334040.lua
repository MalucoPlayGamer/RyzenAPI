-- Lua provided by RyzenAPI
-- Game: YinYang Street Ultimate Edition

-- MAIN APPLICATION
addappid(2334040)
addappid(2546330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334041, 1, "926003c384b0d33a850300d3a38c5cae214d7e386cc496dd9eb58bc96c73f9bf")
