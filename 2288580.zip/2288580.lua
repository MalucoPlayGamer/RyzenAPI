-- Lua provided by RyzenAPI
-- Game: Game: Berry Madness

-- MAIN APPLICATION
addappid(2288580)
-- Game: addappid(2288580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288581, 1, "ac02d975453c7079a050374c8436fe595151ce5fb42d147c98196e102dc502d3")
