-- Lua provided by RyzenAPI
-- Game: 如果还有明天 If I Still Had Tomorrow

-- MAIN APPLICATION
addappid(1849230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849231, 1, "d44252ce2b55b454fad7c650902d12a2a8373e2930914ada31ff12a69fdbf198")

