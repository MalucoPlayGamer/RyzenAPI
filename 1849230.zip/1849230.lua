-- Lua provided by RyzenAPI
-- Game: 1849230

-- MAIN APPLICATION
addappid(1849230)
-- Game: addappid(1849230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849231, 1, "d44252ce2b55b454fad7c650902d12a2a8373e2930914ada31ff12a69fdbf198")
