-- Lua provided by RyzenAPI
-- Game: AppID 260230

-- MAIN APPLICATION
addappid(260230)

-- MAIN APP DEPOTS / PACKAGES
addappid(260231, 1, "6c41bd4691a0b3d82697e2b41689bb5b94b99f6d250f162227b1cd98bd902c4a")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
