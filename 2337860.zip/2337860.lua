-- Lua provided by RyzenAPI
-- Game: Nubs! Arena

-- MAIN APPLICATION
addappid(2337860)
addappid(3645020)
addappid(3694150)
addappid(3694160)
addappid(3700930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337861, 1, "103bf2e090d599ec9d72d09a1e5573ba7ec826200f52ea778e0e639af16982e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
