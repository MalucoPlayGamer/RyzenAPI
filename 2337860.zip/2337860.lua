-- Lua provided by RyzenAPI
-- Game: addappid(2337860)

-- MAIN APPLICATION
addappid(2337860)
addappid(3645020)
addappid(3694150)
addappid(3694160)
addappid(3700930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337861, 1, "103bf2e090d599ec9d72d09a1e5573ba7ec826200f52ea778e0e639af16982e7")
