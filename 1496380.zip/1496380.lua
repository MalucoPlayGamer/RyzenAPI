-- Lua provided by RyzenAPI 
-- Game: 艾斯菲尔的谎言
addappid(1496380)
addappid(1496381, 1, "ff15ae06a0519873595f4015592200f6043e28b3566acf15f01469e9f18238f7")
