-- Lua provided by RyzenAPI
-- Game: 2093020

-- MAIN APPLICATION
addappid(2093020)
-- Game: addappid(2093020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093021, 1, "69a897acd661c306cfb06e3ce1ac2ec1b456bfabcf43ef649647266e259f4a46")
