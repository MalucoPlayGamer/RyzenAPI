-- Lua provided by RyzenAPI
-- Game: 3121480

-- MAIN APPLICATION
addappid(3121480)
-- Game: addappid(3121480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3121481, 1, "2b2d721d89d10805a1d17d602a13958cd20ca3cc1371b5774fb81f3f349aa7fc")
