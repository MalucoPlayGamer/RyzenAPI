-- Lua provided by RyzenAPI
-- Game: AppID 71410

-- MAIN APPLICATION
addappid(71410)
-- Game: addappid(71410)

-- MAIN APP DEPOTS / PACKAGES
addappid(71411, 1, "f799d8efafc72b49cc51fe9763614c97364c7ac76afad86543bf7b2a0c58ce87")
