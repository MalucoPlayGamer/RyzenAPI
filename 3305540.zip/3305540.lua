-- Lua provided by RyzenAPI
-- Game: A Night Duty

-- MAIN APPLICATION
addappid(3305540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3305543,0,"bd72ab1208fa3ac7e91229c4a5ac0798445ee9ff3adc7a59136dbd985699e004")

