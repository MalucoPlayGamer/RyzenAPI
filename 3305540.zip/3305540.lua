-- Lua provided by RyzenAPI
-- Game: 3305540

-- MAIN APPLICATION
addappid(3305540)
-- Game: addappid(3305540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3305543,0,"bd72ab1208fa3ac7e91229c4a5ac0798445ee9ff3adc7a59136dbd985699e004")
