-- Lua provided by RyzenAPI
-- Game: School Booster

-- MAIN APPLICATION
addappid(2318590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318591, 1, "7f96c91f470456f6ab8583dd0818363d5c6b7f87bc353e66f7f9f6c041009d36")

