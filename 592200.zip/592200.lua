-- Lua provided by RyzenAPI
-- Game: addappid(592200)

-- MAIN APPLICATION
addappid(592200)

-- MAIN APP DEPOTS / PACKAGES
addappid(592201, 1, "5d6a8c2b1a8e8bd22140ffdc45f3a6b1e06a3005b7ff3fa17eaa479dea97bc2f")
addappid(592202, 1, "82cfbbb15e3850a7d3ba9fddda6658faf503e88b76dbe0d34dabca1e88c038b6")
addappid(592203, 1, "2992bff7d3cb37c7703b4b7b4ebdf2c8ff8b8da8948de479db893e4ebe5dda4b")
