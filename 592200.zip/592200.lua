-- Lua provided by RyzenAPI
-- Game: Super Army of Tentacles 3: The Search for Army of Tentacles 2

-- MAIN APPLICATION
addappid(592200)

-- MAIN APP DEPOTS / PACKAGES
addappid(592201, 1, "5d6a8c2b1a8e8bd22140ffdc45f3a6b1e06a3005b7ff3fa17eaa479dea97bc2f")
addappid(592202, 1, "82cfbbb15e3850a7d3ba9fddda6658faf503e88b76dbe0d34dabca1e88c038b6")
addappid(592203, 1, "2992bff7d3cb37c7703b4b7b4ebdf2c8ff8b8da8948de479db893e4ebe5dda4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(592810)
addappid(592811)
addappid(592812)
addappid(592813)
addappid(592814)
addappid(592815)
addappid(592816)
addappid(594540)
addappid(694780)
addappid(694800)
addappid(698130)
addappid(717260)
addappid(780960)
addappid(785820)
addappid(788160)
