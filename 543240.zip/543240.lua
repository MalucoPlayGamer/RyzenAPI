-- Lua provided by RyzenAPI
-- Game: AppID 543240

-- MAIN APPLICATION
addappid(543240)
addappid(579650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(543241, 1, "11bf58b0bde984d369cdfddec965c39669ae691df41a16be2f52e7b415eaef4f")
addappid(543242, 1, "35248bfb8db65a348a4d48e0804aded32407eeec463edc4fe7c192e01b5054d0")
addappid(543243, 1, "4a6d82edde1825dffc5c61d5e00e773b72497684d990f30f6d7639a09d06b12b")
addappid(543244, 1, "75a5ea2bfdae10d94bd872ea69c87fb8cab0a061bb374c3fd40ec240923e2c28")
addappid(543245, 1, "27e3d8bd72350522f3a2e3a072798ecfb1720caf025f82c5930616cda882892e")
addappid(543246, 1, "501ea32c741a4276303024d8ae6f9c186130a5c9269ca59678706270688528f6")

