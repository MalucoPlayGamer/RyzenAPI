-- Lua provided by RyzenAPI
-- Game: The Last Show of Mr. Chardish

-- MAIN APPLICATION
addappid(1164060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164061, 1, "8b843bb410283548db00e449c0cc3736a8f759715da2b6dccfc4e3f52f1ba3b1")

