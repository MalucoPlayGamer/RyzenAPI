-- Lua provided by RyzenAPI
-- Game: Game: AppID 575910

-- MAIN APPLICATION
addappid(575910)
-- Game: addappid(575910)

-- MAIN APP DEPOTS / PACKAGES
addappid(575911, 1, "48239877d0c4ae1b1fa1f6ef42f0c7387886066d99890d14142462c50d848f47")
