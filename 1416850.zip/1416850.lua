-- Lua provided by RyzenAPI
-- Game: Game: Astrotour VR

-- MAIN APPLICATION
addappid(1416850)
-- Game: addappid(1416850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416851, 1, "f6494cc131ba420615483975fe9ac956a1764a512e39833305e2d9fc0ce88181")
