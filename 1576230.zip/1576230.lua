-- Lua provided by RyzenAPI
-- Game: An Un-epic story: The adventure of Enki and Tiny Freddie

-- MAIN APPLICATION
addappid(1576230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576231, 1, "af4bcd67801aac9b9b9403fc573bfc7b83393b9776d4ce9bbc21601c49149c15")
addappid(1576232, 1, "fc525fdfc510e5179a6545fbf511a0644ffe3fb486a90cf36986e035f6a1dda3")
