-- Lua provided by RyzenAPI
-- Game: addappid(2868110)

-- MAIN APPLICATION
addappid(2868110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868111, 1, "629fb4b60e53bd006ffaae0f7f7a94f58eda4f3f2c6674d36afad5184c9deb91")
