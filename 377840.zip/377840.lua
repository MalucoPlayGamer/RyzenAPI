-- Lua provided by RyzenAPI 
-- Game: FINAL FANTASY IX
addappid(377840)
addappid(377841, 1, "1e0f8e41510025cbe5cd9944c20057428b7724f2dafa667cbf6b30a87048e845")
addappid(377842, 1, "cc04129aee7111238ca757f73754fccdde5f1626c83cda362eeab94e9cd21f65")
