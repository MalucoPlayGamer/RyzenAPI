-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY IX

-- MAIN APPLICATION
addappid(377840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(377841, 1, "1e0f8e41510025cbe5cd9944c20057428b7724f2dafa667cbf6b30a87048e845")
addappid(377842, 1, "cc04129aee7111238ca757f73754fccdde5f1626c83cda362eeab94e9cd21f65")

