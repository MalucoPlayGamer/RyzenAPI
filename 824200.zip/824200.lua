-- Lua provided by RyzenAPI
-- Game: The Bell Chimes for Gold

-- MAIN APPLICATION
addappid(824200)
-- Game: addappid(824200)

-- MAIN APP DEPOTS / PACKAGES
addappid(824201, 1, "495c10594b4d1ac6d9d36464e7f41eae0f6d95d051cefd52f7aa982664caac71")
