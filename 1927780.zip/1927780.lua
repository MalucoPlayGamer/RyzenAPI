-- Lua provided by RyzenAPI 
-- Game: Galaxy Life
addappid(1927780)
addappid(1927781, 1, "539cc9b882ac9f3a1f9ff2be8ff0d582d279d3314f47af2e6ab8813d303b1a39")
addappid(1927783, 1, "f8379a373d50347d251b2093dd0dae9a3417e18942957b9ddd35b303f8e73248")
