-- Lua provided by RyzenAPI
-- Game: addappid(431230)

-- MAIN APPLICATION
addappid(431230)
addappid(448270)

-- MAIN APP DEPOTS / PACKAGES
addappid(431231, 1, "9a2c5be0890894ba55a8231a67765935cd7f09321bf848796ff9a27405cb8396")
