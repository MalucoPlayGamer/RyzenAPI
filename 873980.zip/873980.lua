-- Lua provided by RyzenAPI
-- Game: Isle of Skye

-- MAIN APPLICATION
addappid(873980)
-- Game: addappid(873980)

-- MAIN APP DEPOTS / PACKAGES
addappid(873981, 1, "de5d916cf73ac8340e1ccbcefd5c2e118bcfa9f4e479c085f102fdf8e61648af")
