-- Lua provided by RyzenAPI
-- Game: ReLinked

-- MAIN APPLICATION
addappid(2363760)
-- Game: addappid(2363760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363761, 1, "8b7c3ccb0c2325f882eab47c84662ccc8d959bf8d75a27004391ce2602a4842f")
