-- Lua provided by RyzenAPI 
-- Game: ReLinked
addappid(2363760)
addappid(2363761, 1, "8b7c3ccb0c2325f882eab47c84662ccc8d959bf8d75a27004391ce2602a4842f")
