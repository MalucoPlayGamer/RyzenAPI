-- Lua provided by RyzenAPI
-- Game: Robot's Mystery

-- MAIN APPLICATION
addappid(724750)

-- MAIN APP DEPOTS / PACKAGES
addappid(724751,0,"4d02dfa6befbe0ec1a17009ae171ec4753bf501b81a644d79f262f2fd5979528")

