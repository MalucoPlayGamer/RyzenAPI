-- Lua provided by RyzenAPI
-- Game: AppID 3615840

-- MAIN APPLICATION
addappid(3615840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3615841, 1, "b2b02ab08cb81554ad0ed7bac558a97ca237b6c21480b874f6fa70a4b646ec85")

