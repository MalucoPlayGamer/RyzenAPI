-- Lua provided by RyzenAPI
-- Game: Beyond Gravity

-- MAIN APPLICATION
addappid(317510)

-- MAIN APP DEPOTS / PACKAGES
addappid(317511, 1, "0485524739007ba69ddc4aaa54f7136ed991427587446b7abb5f8be5e0d6222f")
addappid(317512, 1, "8c161814b0d07c1f3b5c62839fa2c49f5d9b7d8c0f6036a9b85b654d363cc239")
addappid(317513, 1, "b12510f7f33beb948aafce783c209b95641ebaaff837ee78e6f7fd0d2cf6974f")

