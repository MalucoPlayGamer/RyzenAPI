-- Lua provided by RyzenAPI
-- Game: AppID 1308880

-- MAIN APPLICATION
addappid(1308880)
-- Game: addappid(1308880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308881, 1, "8effdb3ffaada54559733fc71de565117a85bd0dab68720cd1bf853820660cf3")
