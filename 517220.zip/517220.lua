-- Lua provided by RyzenAPI
-- Game: Balls! Virtual Reality Cricket

-- MAIN APPLICATION
addappid(517220)

-- MAIN APP DEPOTS / PACKAGES
addappid(517221,0,"bae05f308380739814ef86115cbe552a03bf527d3d38146469ac69974d9726a2")

