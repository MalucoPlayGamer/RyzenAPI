-- Lua provided by RyzenAPI
-- Game: Game: AppID 1541390

-- MAIN APPLICATION
addappid(1541390)
-- Game: addappid(1541390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541391, 1, "8b3a2b73790e88a728b10532eece76927c735a58821bb1c7102330ca31a1655e")
