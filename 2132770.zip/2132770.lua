-- Lua provided by SkyAPI 
-- Game: Labyrinthatory
addappid(2132770)
addappid(2132771, 1, "bdad4d8b6f98f78c7e80c09a33101bc1a7cb126bb7599cc93bd0e6c0ae69e8be")
