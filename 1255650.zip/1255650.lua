-- Lua provided by RyzenAPI
-- Game: addappid(1255650)

-- MAIN APPLICATION
addappid(1255650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255651, 1, "553da8ea2ddce11479d1b9aad7378f9e04e432ed1c33f1cbce9bb0b9189de300")
addappid(1255652, 1, "7d3ff996e9312e455f968b01dc27760e64767204eca3538c90cf8ee35f7ea39e")
