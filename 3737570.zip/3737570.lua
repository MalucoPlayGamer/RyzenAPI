-- Lua provided by RyzenAPI
-- Game: addappid(3737570)

-- MAIN APPLICATION
addappid(3737570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3737570,0,"ec84c88085c003ee23349e2a8ad7ffa03b78bb0d2038853abcb29f97d0f37dac")
