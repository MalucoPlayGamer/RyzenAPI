-- Lua provided by RyzenAPI
-- Game: Manus Dei

-- MAIN APPLICATION
addappid(2591970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2591971, 1, "81a7eb81333433db5a5c640c739fb3814663f413524980740c5c992ce9171321")

