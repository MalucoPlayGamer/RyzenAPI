-- Lua provided by RyzenAPI
-- Game: Manus Dei

-- MAIN APPLICATION
addappid(2591970)
-- Game: addappid(2591970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591971, 1, "81a7eb81333433db5a5c640c739fb3814663f413524980740c5c992ce9171321")
