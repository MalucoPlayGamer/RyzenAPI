-- Lua provided by RyzenAPI
-- Game: addappid(3603030)

-- MAIN APPLICATION
addappid(3603030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3603031, 1, "f05b88f3b42645b7b2e7cd0f64a7d265330c457dd2361f7bb37e2d79900305b5")
addappid(3603032, 1, "8a7266c9ad02ca947cfedafb33458ca585b2d7ffae43ade861bfd5b43cfb39e0")
