-- Lua provided by RyzenAPI
-- Game: FutureGrind

-- MAIN APPLICATION
addappid(355820)

-- MAIN APP DEPOTS / PACKAGES
addappid(355821, 1, "d30e1a31f2656660fc0de8faf8d8066ba432b10a13bf7d4a043ba8c380684284")

