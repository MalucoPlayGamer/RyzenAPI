-- Lua provided by RyzenAPI
-- Game: Game: Shing! OST

-- MAIN APPLICATION
addappid(1450510)
-- Game: addappid(1450510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450511, 1, "39606f85f138d379d394d3be8a1b84ed7acaa8f0dbfb55e10cf2353c4656398e")
addappid(1450512, 1, "213b18c750bdbe6e49d568ec3395a0eb8952cb1cf9457f06e8c71eef148f0640")
