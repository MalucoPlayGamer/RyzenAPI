-- Lua provided by RyzenAPI
-- Game: addappid(2955810)

-- MAIN APPLICATION
addappid(2955810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955811, 1, "a1e1d0ed1b74e266efd7e291fe86f767acfa06f8e48bba5532ecc587c25c47db")
