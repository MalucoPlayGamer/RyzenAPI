-- Lua provided by SkyAPI 
-- Game: AppID 2624050
addappid(2624050)
addappid(2624051, 1, "0c0db2f57ced57fca8022d01f6499238caa6002bbf5365d22bbc1e3b7cb7c242")
