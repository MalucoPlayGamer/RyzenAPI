-- Lua provided by RyzenAPI
-- Game: AppID 2624050

-- MAIN APPLICATION
addappid(2624050)
-- Game: addappid(2624050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624051, 1, "0c0db2f57ced57fca8022d01f6499238caa6002bbf5365d22bbc1e3b7cb7c242")
