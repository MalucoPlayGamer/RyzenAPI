-- Lua provided by RyzenAPI
-- Game: addappid(1275860)

-- MAIN APPLICATION
addappid(1275860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275861, 1, "17bd7b64c6b48606e88d61e3beb8ccfc18f4447febaec5c59b3e77101b70d5a0")
