-- Lua provided by SkyAPI 
-- Game: AppID 869260
addappid(869260)
addappid(869261, 1, "244de883d0256420af99efeffcfbf3823f2cce865a0d1bc807c7f9a7a68e8022")
