-- Lua provided by RyzenAPI
-- Game: Welcome to Ukraine

-- MAIN APPLICATION
addappid(2806830)
-- Game: addappid(2806830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806831, 1, "138b3aa361fafb4d0e6731b122cb4618e78b39afa8e3cb587a5554c6d13764bd")
