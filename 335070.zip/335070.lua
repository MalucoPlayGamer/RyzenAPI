-- Lua provided by RyzenAPI
-- Game: VRC PRO

-- MAIN APPLICATION
addappid(335070)
addappid(344060)
addappid(344070)
addappid(344080)
addappid(344090)
addappid(381790)
addappid(381791)
addappid(381792)
addappid(419980)
addappid(453060)
addappid(574670)
addappid(574671)
addappid(574672)
addappid(574673)
addappid(574674)
addappid(574675)
addappid(574676)
addappid(574677)
addappid(678730)
addappid(678731)
addappid(678732)
addappid(678733)
addappid(678734)
addappid(678736)
addappid(678737)
addappid(678738)
addappid(678739)
addappid(2237580)
addappid(2237581)
addappid(2237582)
addappid(2237583)
addappid(2237584)
addappid(2237586)
addappid(2237588)

-- MAIN APP DEPOTS / PACKAGES
addappid(335071,0,"07c1d45c6344481fe6f31c7651ef210af67e3e0a52ad490c4451e83cd264ff1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
