-- Lua provided by RyzenAPI
-- Game: VRC PRO

-- MAIN APPLICATION
addappid(335070)
-- Game: addappid(335070)

-- MAIN APP DEPOTS / PACKAGES
addappid(335071, 1, "07c1d45c6344481fe6f31c7651ef210af67e3e0a52ad490c4451e83cd264ff1c")
