-- Lua provided by RyzenAPI
-- Game: The Contact

-- MAIN APPLICATION
addappid(394010)

-- MAIN APP DEPOTS / PACKAGES
addappid(394011, 1, "7bcf1ec9ae9ff40e77e616bfb5d51609a0ee48f621fcc242d1ce603b18c790a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
