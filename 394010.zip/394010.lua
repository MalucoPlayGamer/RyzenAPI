-- Lua provided by RyzenAPI
-- Game: 394010

-- MAIN APPLICATION
addappid(394010)
-- Game: addappid(394010)

-- MAIN APP DEPOTS / PACKAGES
addappid(394011, 1, "7bcf1ec9ae9ff40e77e616bfb5d51609a0ee48f621fcc242d1ce603b18c790a9")
