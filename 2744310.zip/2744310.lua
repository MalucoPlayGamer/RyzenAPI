-- Lua provided by RyzenAPI 
-- Game: Potato Arena Demo
addappid(2744310)
addappid(2744311, 1, "96d353c1affd5f91d450fac4e6228d70c1a040ef91d3253d98b621c2b4d87983")
