-- Lua provided by RyzenAPI
-- Game: New Yankee in King Arthur's Court

-- MAIN APPLICATION
addappid(462570)

-- MAIN APP DEPOTS / PACKAGES
addappid(462571, 1, "707b00047d11601e98d6f1c78f3b558846f43c7f7a494c7d49dd431bbf1a4bbc")

