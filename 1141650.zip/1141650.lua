-- Lua provided by RyzenAPI
-- Game: Crowd Simulator

-- MAIN APPLICATION
addappid(1141650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141652,0,"2f5befe143cef5cb1868c382de0078375218863fb0016244627416b8009ca24e")
addappid(1141653,0,"d93bd0a5307b748d28ee7f456552cb610215df047b801784967a75f4f64d9cfe")
addappid(1141654,0,"bffb1befc68afab4db124d656ada61ff1c44d9a4a851814759c00f727cb9d173")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1710470)
addappid(1916750)
