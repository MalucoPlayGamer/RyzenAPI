-- Lua provided by RyzenAPI
-- Game: Choice of Life: Middle Ages 2

-- MAIN APPLICATION
addappid(1573630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573631, 1, "e47b77bbf1b8440ac53dadbc9640dafe74243aed7d250296ae926ab01356d890")

