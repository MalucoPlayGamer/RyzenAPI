-- Lua provided by RyzenAPI
-- Game: addappid(3106310)

-- MAIN APPLICATION
addappid(3106310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106311, 1, "c7985904bff6329d13f590a67ef1b406496cf0e55a0debdef96102191889c049")
