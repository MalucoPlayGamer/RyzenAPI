-- Lua provided by RyzenAPI
-- Game: 3XO: XXX Online Demo

-- MAIN APPLICATION
addappid(2344810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344811, 1, "41afb2d59c736053331682fbc5f61209f7d31ed6d525ff2524ed74e020a44d65")

