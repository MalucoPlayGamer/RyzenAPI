-- Lua provided by RyzenAPI
-- Game: Reversion - The Escape (1st Chapter)

-- MAIN APPLICATION
addappid(270570)

-- MAIN APP DEPOTS / PACKAGES
addappid(270571, 1, "3416f015cf0e34444ac5d5dddc706a1a5045f4d4d4be189ef5905609e014f0a0")
addappid(270572, 1, "ec4abefe663f9decc5fd2413244a8de9dc38815f9c97e4f91e032bb9de87fb14")
addappid(270573, 1, "8f5423c4785f61ad2e2228779eba6ca5b2d32570e83ed1593946f232026aa1a0")
