-- Lua provided by RyzenAPI
-- Game: addappid(1064150)

-- MAIN APPLICATION
addappid(1064150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064151, 1, "ddb3c0fc753a5e9eb432e905e49e9b9db35f54cc9aae23c117f15b102c076c05")
