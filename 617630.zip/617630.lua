-- Lua provided by RyzenAPI
-- Game: AppID 617630

-- MAIN APPLICATION
addappid(617630)

-- MAIN APP DEPOTS / PACKAGES
addappid(617631, 1, "ff11c192cb337fb77ac29f6f38b6f44ff22b652041622626d48eaf645ab992aa")

