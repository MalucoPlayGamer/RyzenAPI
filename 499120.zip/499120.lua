-- Lua provided by RyzenAPI
-- Game: addappid(499120)

-- MAIN APPLICATION
addappid(499120)

-- MAIN APP DEPOTS / PACKAGES
addappid(499121, 1, "e7b629cadead47fd7406ff100ea80d3d7d8276c9d792849cfa4229093091c3ea")
