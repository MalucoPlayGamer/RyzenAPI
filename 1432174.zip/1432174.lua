-- Lua provided by RyzenAPI
-- Game: FUSER™ - Weezer - "Buddy Holly"

-- MAIN APPLICATION
addappid(1432174)
-- Game: addappid(1432174)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432174,0,"8e7c8c73bae8c786c251667847c4fb7065d7c521ccac4e9e24d1d5da0e8509b2")
