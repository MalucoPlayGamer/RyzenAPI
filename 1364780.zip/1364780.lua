-- Lua provided by RyzenAPI
-- Game: Game: Street Fighter™ 6

-- MAIN APPLICATION
addappid(1364780)
-- Game: addappid(1364780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364781, 1, "cfec39716b5a5cae49b52b5c0e01e6db93356ee3df5a0d87590fd811ab6d06e1")
