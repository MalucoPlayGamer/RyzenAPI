-- Lua provided by RyzenAPI
-- Game: Sand Playtest

-- MAIN APPLICATION
addappid(2981610)
-- Game: addappid(2981610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981611, 1, "281693ff76cfae4dc13350a42baa22e576e43a3e849516cab38e216a585f2512")
