-- Lua provided by RyzenAPI
-- Game: Adventures On The Polluted Islands

-- MAIN APPLICATION
addappid(496690)
-- Game: addappid(496690)

-- MAIN APP DEPOTS / PACKAGES
addappid(496691, 1, "7b4be6b17b9e699866e02c84ef387615d1973ac52b74b78c60f75df0b205de36")
