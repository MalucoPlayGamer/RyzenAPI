-- Lua provided by RyzenAPI
-- Game: Two Against the Legion

-- MAIN APPLICATION
addappid(1612900)
-- Game: addappid(1612900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612901, 1, "1efa841531cad154df9787e26b33cbc73d8d28bc6a2b7ab10f41077edec28829")
