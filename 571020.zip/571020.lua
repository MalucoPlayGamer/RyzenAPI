-- Lua provided by RyzenAPI
-- Game: Santa's Big Adventures

-- MAIN APPLICATION
addappid(571020)

-- MAIN APP DEPOTS / PACKAGES
addappid(571021, 1, "2818159b85895de1b7caf72504b3487e1a786ed6ed91289d221918e20eca4791")
addappid(571022, 1, "628bff35ce5a73d57db04d8d08153efb030b9bdbc6673a97a9730e94c40f48a6")
addappid(571023, 1, "e7fd402f2a637195cbc79e7986174b4e280288ce973ba7f8179ea762a1d62ece")

