-- Lua provided by RyzenAPI
-- Game: The House

-- MAIN APPLICATION
addappid(302910)

-- MAIN APP DEPOTS / PACKAGES
addappid(302911, 1, "046677bcc9e83752aa4aa707ce856f1d78edfbaa32bf10f55efc57775d0dce90")

