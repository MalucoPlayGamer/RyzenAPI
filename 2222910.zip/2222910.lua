-- Lua provided by RyzenAPI
-- Game: addappid(2222910)

-- MAIN APPLICATION
addappid(2222910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222911, 1, "f7ec4227af258c431cedc3250cf74a0b408ff671edded29b1e7e148e22f95fb2")
