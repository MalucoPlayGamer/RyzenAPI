-- Lua provided by RyzenAPI 
-- Game: Hentai DevilGirl
addappid(2222910)
addappid(2222911, 1, "f7ec4227af258c431cedc3250cf74a0b408ff671edded29b1e7e148e22f95fb2")
