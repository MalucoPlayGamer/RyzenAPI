-- Lua provided by RyzenAPI
-- Game: Inevitable VR

-- MAIN APPLICATION
addappid(905180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(905181, 1, "04a3393122e952fa992aab0e3ef32a967c46ea7d9fee3a8f7718d409b8a08e9d")
