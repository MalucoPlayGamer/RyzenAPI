-- Lua provided by RyzenAPI
-- Game: 905180

-- MAIN APPLICATION
addappid(905180)
-- Game: addappid(905180)

-- MAIN APP DEPOTS / PACKAGES
addappid(905181, 1, "04a3393122e952fa992aab0e3ef32a967c46ea7d9fee3a8f7718d409b8a08e9d")
