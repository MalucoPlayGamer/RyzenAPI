-- Lua provided by RyzenAPI
-- Game: addappid(2876250)

-- MAIN APPLICATION
addappid(2876250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2876251, 1, "6fb707a0829554dda88bac18b9798e6a6674558a6349e8300b8cb53b6fcd4176")
