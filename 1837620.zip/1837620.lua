-- Lua provided by RyzenAPI
-- Game: Sans Logique

-- MAIN APPLICATION
addappid(1837620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1837621, 1, "9e8ef1238a114cce7f5338b521cac729ee762ae53129785597c403c0079f7b8a")

