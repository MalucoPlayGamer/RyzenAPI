-- Lua provided by RyzenAPI
-- Game: addappid(1582810)

-- MAIN APPLICATION
addappid(1582810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582811, 1, "10d06fe623d3cbca72a316d16d8579621e2e13921906c9b7cd9ee7abb7376055")
