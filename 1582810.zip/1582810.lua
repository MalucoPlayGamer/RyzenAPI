-- Lua provided by RyzenAPI
-- Game: Alien Wall

-- MAIN APPLICATION
addappid(1582810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582811, 1, "10d06fe623d3cbca72a316d16d8579621e2e13921906c9b7cd9ee7abb7376055")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
