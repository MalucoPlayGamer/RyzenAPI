-- Lua provided by RyzenAPI
-- Game: Radium 2

-- MAIN APPLICATION
addappid(562460)

-- MAIN APP DEPOTS / PACKAGES
addappid(562461, 1, "de5717b05e84201615b55ce6e88a0b875dbb6269fd82fcd6f2b080ae46aff100")
addappid(562462, 1, "022edc4274c346f1022dce466c45a60cb15092e67ef3485a10c7b164ad58fd41")
addappid(562463, 1, "e6b5df26a8c0ef5979502503e1c86658d0bbe60e85f36b91941b5e256cf3ac20")
addappid(632910, 0, "aa60a0acd78c3a82da6fbd83157fff90cd9178769ef8ec8a795ae78d0a9f8c34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
