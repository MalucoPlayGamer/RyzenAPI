-- Lua provided by RyzenAPI
-- Game: Urge

-- MAIN APPLICATION
addappid(1304350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304351, 1, "d0c4453f1e03ca29896de018385f95b7d38da667befb06611bcc306e6a289a6f")

