-- Lua provided by RyzenAPI
-- Game: Downtown Mafia: Gang Wars

-- MAIN APPLICATION
addappid(889730)

-- MAIN APP DEPOTS / PACKAGES
addappid(889731, 1, "c5abcdaa866ba5c3811013b56b6912cf3995ca527558c7b7150db4b0f0b894af")
addappid(889732, 1, "cdd694e505e5d88349e1892654497cb3f64340bfb15883747c3545de0c95a89e")
addappid(889733, 1, "4ab53b6d9dc1e5e14548dc3e5bf72c97a6798bfaf4e99b88276a104a7b626c35")
addappid(889735, 1, "22b991772d6f0dd01d8feab1c12b8277def2c12663df9a994c4386c123c7ae9f")

