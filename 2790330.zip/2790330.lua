-- Lua provided by RyzenAPI
-- Game: Blood Typers

-- MAIN APPLICATION
addappid(2790330)
-- Game: addappid(2790330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790331, 1, "e2849c9c34b6ae97847e916f63847c74a22404ba3f6e64adeb9ad7379d8511bc")
