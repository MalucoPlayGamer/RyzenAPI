-- Lua provided by SkyAPI 
-- Game: Blood Typers
addappid(2790330)
addappid(2790331, 1, "e2849c9c34b6ae97847e916f63847c74a22404ba3f6e64adeb9ad7379d8511bc")
