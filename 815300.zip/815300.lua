-- Lua provided by RyzenAPI
-- Game: 幻想英雄传 / Fantasy Hero Biography

-- MAIN APPLICATION
addappid(815300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(815301,0,"57cee91f4550f1c7e536605ef2ccaf1ec00c022eec5ab04737248e0c355a99e2")

