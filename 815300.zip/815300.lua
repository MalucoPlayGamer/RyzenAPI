-- Lua provided by RyzenAPI
-- Game: 幻想英雄传 / Fantasy Hero Biography

-- MAIN APPLICATION
addappid(815300)

-- MAIN APP DEPOTS / PACKAGES
addappid(815301,0,"57cee91f4550f1c7e536605ef2ccaf1ec00c022eec5ab04737248e0c355a99e2")

