-- Lua provided by RyzenAPI
-- Game: Miracle Brave

-- MAIN APPLICATION
addappid(4284660)

-- MAIN APP DEPOTS / PACKAGES
addappid(4284661,0,"cdd7a99854a9ea1de8fd791450290214f37b3384f21f873401f86b2ffaaf2586")

