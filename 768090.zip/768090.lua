-- Lua provided by RyzenAPI 
-- Game: AppID 768090
addappid(768090)
addappid(768091, 1, "e4022f3861ef6f1e70917566c12e9ff7b45ca1505881d55cca218b46454d65cd")
