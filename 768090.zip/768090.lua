-- Lua provided by RyzenAPI
-- Game: AppID 768090

-- MAIN APPLICATION
addappid(768090)
-- Game: addappid(768090)

-- MAIN APP DEPOTS / PACKAGES
addappid(768091, 1, "e4022f3861ef6f1e70917566c12e9ff7b45ca1505881d55cca218b46454d65cd")
