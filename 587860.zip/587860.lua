-- Lua provided by RyzenAPI
-- Game: Tales of Escape

-- MAIN APPLICATION
addappid(587860)

-- MAIN APP DEPOTS / PACKAGES
addappid(587861, 1, "296d8aae5b3d0694ee5dca6b5e86bff259d51e7e0fba4c9edd4df5435309b571")
