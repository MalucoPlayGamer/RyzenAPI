-- Lua provided by RyzenAPI
-- Game: Tales of Escape

-- MAIN APPLICATION
addappid(587860)
addappid(686790)
addappid(686800)
addappid(741760)
addappid(747030)
addappid(747040)
addappid(1283710)
addappid(1283711)

-- MAIN APP DEPOTS / PACKAGES
addappid(587861, 1, "296d8aae5b3d0694ee5dca6b5e86bff259d51e7e0fba4c9edd4df5435309b571")

