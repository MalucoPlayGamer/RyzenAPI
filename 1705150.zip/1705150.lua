-- Lua provided by RyzenAPI
-- Game: SKULL CHAINZ

-- MAIN APPLICATION
addappid(1705150)
-- Game: addappid(1705150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705151, 1, "63fa0d76d4fe8f5b83e8b3f281efb5f7cee605c8ede47ecba061af5acb6c0b17")
