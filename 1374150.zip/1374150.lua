-- Lua provided by RyzenAPI
-- Game: VR Hentai room 2

-- MAIN APPLICATION
addappid(1374150)
addappid(1374151)
-- Game: addappid(1374150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374150,0,"e89ceebf940032c4767476d7fc04e47c5d677202c823a3a8bf27acbd41c9f292")
