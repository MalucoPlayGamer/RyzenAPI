-- Lua provided by RyzenAPI
-- Game: Gothic Playable Teaser

-- MAIN APPLICATION
addappid(950670)

-- MAIN APP DEPOTS / PACKAGES
addappid(950671, 1, "2c85c5aa933e4ccd5c5dc4b389c3913b73da8fa5ae60824e16abb437e6c9c93b")
