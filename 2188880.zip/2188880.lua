-- Lua provided by RyzenAPI
-- Game: Evergreen - Mountain Life Simulator: PROLOGUE

-- MAIN APPLICATION
addappid(2188880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188881, 1, "f97d4380ecdccd972ffb27281af5a0a949786daff99b809095298c72e6fe7b44")
