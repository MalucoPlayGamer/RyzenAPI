-- 1133570's Lua and Manifest Created by Hubcap Manifest
-- Shining Starter
-- Created: August 16, 2026 at 17:30:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1133570) -- Shining Starter
-- MAIN APP DEPOTS
addappid(1133571, 1, "a0a5c30ea4c8e4e81eebbfeed2ff6a0ae395bed401b6659671a62f170af64a6d") -- ShiningCity Mac
setManifestid(1133571, "7476512359786427902", 1333183176)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1184970) -- ShiningCity - ShiningMenu
addappid(1184971) -- ShiningCity - Reward 1
addappid(1184972) -- ShiningCity - Reward 2
addappid(1707020) -- ShiningCity - Reward 3
addappid(1707021) -- ShiningCity - Reward 4
addappid(1707022) -- ShiningCity - Reward 5