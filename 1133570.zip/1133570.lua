-- Lua provided by RyzenAPI
-- Game: Game: Shining Starter

-- MAIN APPLICATION
addappid(1133570)
-- Game: addappid(1133570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133571, 1, "a0a5c30ea4c8e4e81eebbfeed2ff6a0ae395bed401b6659671a62f170af64a6d")
