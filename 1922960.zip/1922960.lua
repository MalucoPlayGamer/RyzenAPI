-- Lua provided by RyzenAPI
-- Game: AppID 1922960

-- MAIN APPLICATION
addappid(1922960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1922961, 1, "42429a7ee35a33e1c17321c6f61901b3c5373d8e746d460b43bc15054dafbf25")

