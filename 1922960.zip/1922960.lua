-- Lua provided by RyzenAPI
-- Game: Labyrinth of Zangetsu

-- MAIN APPLICATION
addappid(1922960)
-- Game: addappid(1922960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922961, 1, "42429a7ee35a33e1c17321c6f61901b3c5373d8e746d460b43bc15054dafbf25")
