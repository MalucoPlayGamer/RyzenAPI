-- Lua provided by RyzenAPI
-- Game: 豆腐脑模拟器 Tofu Pudding Simulator

-- MAIN APPLICATION
addappid(1020840)
-- Game: addappid(1020840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020842,0,"58a474628d008905b72f4d9501f5967678466f781b49870d273488037c6567e9")
