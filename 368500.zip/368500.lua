-- Lua provided by RyzenAPI
-- Game: Assassin's Creed® Syndicate

-- MAIN APPLICATION
addappid(368500)
addappid(371020)
addappid(407474)
addappid(417960)
addappid(417961)
addappid(417962)
addappid(417963)
addappid(417964)
addappid(417965)
addappid(417966)
addappid(417967)
addappid(417968)
addappid(417970)
addappid(417971)
addappid(417972)
addappid(417973)
addappid(417974)
addappid(417975)
addappid(417976)
addappid(452960)
addappid(456770)

-- MAIN APP DEPOTS / PACKAGES
addappid(368501, 1, "d1bdef91b5eaec4f3e423ca91fcfdf9431091873ffb54f6f72c040cc953b97e4")
addappid(368502, 1, "104abcec788393b8fdd109808cdd448282321f2ca2a2841bd144bf714a6c49c0")
addappid(368503, 1, "a141f6692cc60dbbf88df0cb80c64887a85c1ab11b4f8c6b5f32c58443d5be37")
addappid(368504, 1, "fe94c08ddf5cca80f132536cc1fc78f52bb83920c7d7c25a065b1e2af798fdfc")
addappid(368505, 1, "8bb3f40ef7ed048b09cb108388bf7a67b3c488bfb865e592a87bf9cc3a4e7854")
addappid(405080, 0, "0b90af327ed0210d31b63ebaf92971acbc3dd0d28ce213b5c7da0915a041b48a")
addappid(407470, 0, "1c2aa26252e28e027a4ef7e686d7557f66d9d1a558c3daeb6a6c4eab6552acfd")
addappid(407471, 0, "4fb128097f83ca038a9ca86bf80ca2d030e47c314f274568906d2586ca2b8dd6")
addappid(407472, 0, "4ada1b0ac4eaf0c9ddf28bdde57963e0e1bae66413d4c5262aadd3e8764e07c6")
addappid(407473, 0, "faec6593cb6d2e6b32626b52677f86bb5201875eee76b2e27cf5b2d00bf5caaa")
addappid(407475, 0, "c1506ebebe02f663559ca77f6031bac61c86ea9dede7a44d22e391553d54afda")
addappid(407476, 0, "c09880ee8e9d7f43f503b453d621475d21260f808c2a8ea3dcad8c84321e6e0a")
addappid(407477, 0, "2ed345356b1c7f23d41c73dde724b24b97210e4071f17a0014895b3b31c5435f")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
