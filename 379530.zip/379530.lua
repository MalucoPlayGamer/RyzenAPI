-- Lua provided by RyzenAPI
-- Game: AppID 379530

-- MAIN APPLICATION
addappid(379530)
addappid(401580)

-- MAIN APP DEPOTS / PACKAGES
addappid(379531, 1, "a88aeec643c90eca34fb05c0f0d9bb0a71792b86147294f180ba7c70abe8b1a4")
addappid(379532, 1, "220499716bce9b71c3d8a17894db9481a68f0b5f62b90bc4fc1d1f2baf71a090")
