-- Lua provided by RyzenAPI
-- Game: Tiny House

-- MAIN APPLICATION
addappid(2826220) -- Tiny House

-- MAIN APP DEPOTS / PACKAGES
addappid(2826221, 1, "ca8ceb3881940675693d6103a2d1193d8ffbe81231ebed74bc81c37350bae6f9") -- Depot 2826221
addappid(2826222, 1, "39472b29e4444cc9bfcff73b04e5e4ef167f19f06082257a26d1cb65dfe0156d") -- Depot 2826222
