-- Lua provided by RyzenAPI
-- Game: Ultros

-- MAIN APPLICATION
addappid(2386310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386311, 1, "af749a581922a0c97f5cd9d034f04d877796b39acf48e7a430aae7f3dd52a852")
addappid(2386312, 1, "d9c4cf37af7bd810f59dd4ab10b58036676003464de7951a02f4362a9ba6031f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2649730)
