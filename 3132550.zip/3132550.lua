-- Lua provided by RyzenAPI
-- Game: Game: Fuga: Melodies of Steel (Manga) Vol. 2

-- MAIN APPLICATION
addappid(3132550)
-- Game: addappid(3132550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132551, 1, "573806fe65665803727a1872efeeeb66f4966b7a77b46cba60dd5a4437b19c4f")
