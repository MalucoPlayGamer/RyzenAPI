-- Lua provided by RyzenAPI
-- Game: addappid(2843130)

-- MAIN APPLICATION
addappid(2843130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843131, 1, "2fcf2d27f92aa8748b2b2c55cf5a7cbf05946f3d91d0dd309a740703d1c908aa")
