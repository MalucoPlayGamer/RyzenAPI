-- Lua provided by SkyAPI 
-- Game: The Heroes Around Me
addappid(1768470)
addappid(1768471, 1, "04995ea00a2c227e3903021f6747fc454900b89766e14076aa355a367a196104")
