-- Lua provided by RyzenAPI
-- Game: Game: The Heroes Around Me

-- MAIN APPLICATION
addappid(1768470)
-- Game: addappid(1768470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768471, 1, "04995ea00a2c227e3903021f6747fc454900b89766e14076aa355a367a196104")
