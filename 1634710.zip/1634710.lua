-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Scenario & BGM Set 3

-- MAIN APPLICATION
addappid(1634710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634710,0,"f4c999d43364d49b5a28f4b4b854a848346c730609406d7a9653a2bd9cca1e7d")
