-- Lua provided by SkyAPI 
-- Game: PhantomRider
addappid(3413090)
addappid(3413091, 1, "0c508438dcb1232ddcbe17982d84574677324dcbd2cd6f4306aa7dee765337fc")
