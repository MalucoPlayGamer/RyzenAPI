-- Lua provided by RyzenAPI
-- Game: addappid(3413090)

-- MAIN APPLICATION
addappid(3413090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413091, 1, "0c508438dcb1232ddcbe17982d84574677324dcbd2cd6f4306aa7dee765337fc")
