-- Lua provided by RyzenAPI
-- Game: Game: Yoshima: Hentai Simulator

-- MAIN APPLICATION
addappid(3298250)
-- Game: addappid(3298250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298251, 1, "656439b90e74c833bd5ea954098b00a4302212400ba7c93147741dff3981f4bc")
