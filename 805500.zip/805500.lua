-- Lua provided by RyzenAPI
-- Game: 805500

-- MAIN APPLICATION
addappid(805500)
-- Game: addappid(805500)

-- MAIN APP DEPOTS / PACKAGES
addappid(805501, 1, "1eef745e6b51e0aabb4d62f5bfcc4f9ace749350a69d628805aae740b4183cae")
addappid(807040, 0, "c334f80aff4705d7f16406edc07c1751ab1a1785929aca4c13efcdf6a1711682")
