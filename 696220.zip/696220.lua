-- Lua provided by RyzenAPI
-- Game: AppID 696220

-- MAIN APPLICATION
addappid(696220)
addappid(4340140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(696221, 1, "2f0e6c87d9d9bf77d17ac93f4ca0cb58db5d83950662593d9a0897d6d86354c5")

