-- Lua provided by RyzenAPI 
-- Game: AppID 696220
addappid(696220)
addappid(696221, 1, "2f0e6c87d9d9bf77d17ac93f4ca0cb58db5d83950662593d9a0897d6d86354c5")
