-- Lua provided by RyzenAPI
-- Game: 2176430

-- MAIN APPLICATION
addappid(2176430)
-- Game: addappid(2176430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176431, 1, "8d6970135846100a73ee4a7cc89de19ad9c28d236debb552cb39c6855e965dd7")
