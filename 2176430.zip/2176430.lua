-- Lua provided by RyzenAPI
-- Game: Testament: The Order of High Human

-- MAIN APPLICATION
addappid(2176430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2176431, 1, "8d6970135846100a73ee4a7cc89de19ad9c28d236debb552cb39c6855e965dd7")

