-- Lua provided by RyzenAPI
-- Game: 672630

-- MAIN APPLICATION
addappid(672630)
-- Game: addappid(672630)

-- MAIN APP DEPOTS / PACKAGES
addappid(672631, 1, "6e01aa98e2114851cfff31bdc0b110b3f4b73105ed18bd1e0f0211f0367498d8")
addappid(672632, 1, "32d3b242a37e09b90f6d383061d6be529919d4e45d904cdb35f8df673d586795")
addappid(672633, 1, "6b7aeb860ec95e3d510dfb74ed7650b4e246d5a700fc04b7cab63fb32ad7f2be")
