-- Lua provided by RyzenAPI
-- Game: 880370

-- MAIN APPLICATION
addappid(880370)
addappid(880480)
-- Game: addappid(880370)

-- MAIN APP DEPOTS / PACKAGES
addappid(880371, 1, "1a969fab6999ee4edb5d4611b35bffe85ff871097a9974c201b997903c38b641")
