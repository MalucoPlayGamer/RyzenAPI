-- Lua provided by RyzenAPI
-- Game: FUSER™ - Panic! At The Disco - "Dancing's Not A Crime"

-- MAIN APPLICATION
addappid(1551391)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551391,0,"3705183970e2a5ab9fc29ccfd1b9f23939758ab66aedd122d08797838d558884")
