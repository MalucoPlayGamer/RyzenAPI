-- Lua provided by RyzenAPI
-- Game: addappid(365760)

-- MAIN APPLICATION
addappid(365760)

-- MAIN APP DEPOTS / PACKAGES
addappid(365761, 1, "d516f58a4d3c8f8d9d5e151d91eeab479b1b3721d08f5cb5401d7bbd185cd06e")
addappid(365762, 1, "22d8dfa2864316841a0eeab57c60db3a6f1192a86198682cf69d4e82955061d9")
addappid(365763, 1, "9a5ab1b24ad7346ddf6125cbf34df5f406c90b3bc9e04b100cc6cd141b80d58a")
