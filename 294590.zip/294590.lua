-- Lua provided by RyzenAPI
-- Game: Wars and Warriors: Joan of Arc

-- MAIN APPLICATION
addappid(294590)

-- MAIN APP DEPOTS / PACKAGES
addappid(294591, 1, "45e0912a618cd4e79668f53a201cd489eda09203ba6e5d425a658ba0953d49c2")
