-- Lua provided by RyzenAPI
-- Game: DinoTrek

-- MAIN APPLICATION
addappid(925170)
-- Game: addappid(925170)

-- MAIN APP DEPOTS / PACKAGES
addappid(925171, 1, "c9fa2c558a75ae6397a8bbfc2e4384c2d2a5b351d9544215db7517d047aeafeb")
