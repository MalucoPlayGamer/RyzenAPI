-- Lua provided by RyzenAPI
-- Game: Job Battle Simulator

-- MAIN APPLICATION
addappid(3671980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3671981,0,"4ab31edda5d0ca04b78fd7dba715282175b84489f12055f65e2940519467f774")

