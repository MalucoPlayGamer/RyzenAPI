-- Lua provided by RyzenAPI
-- Game: addappid(2358220)

-- MAIN APPLICATION
addappid(2358220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358221, 1, "80cd37dd53cac375e6f3d5a45bbbfeeca5f0df0f32b43dc595f78be56239f460")
