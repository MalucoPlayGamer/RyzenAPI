-- Lua provided by SkyAPI 
-- Game: BYTE FYTE (MULTIPLAYER)
addappid(2211190)
addappid(2211191, 1, "d691dc44e0603657e615ca398c168995a0444a74c4fff31d480dba72bba6ebf8")
