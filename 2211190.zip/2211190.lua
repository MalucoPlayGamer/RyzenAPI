-- Lua provided by RyzenAPI
-- Game: Game: BYTE FYTE (MULTIPLAYER)

-- MAIN APPLICATION
addappid(2211190)
-- Game: addappid(2211190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211191, 1, "d691dc44e0603657e615ca398c168995a0444a74c4fff31d480dba72bba6ebf8")
