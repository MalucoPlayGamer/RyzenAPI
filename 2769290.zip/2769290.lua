-- Lua provided by SkyAPI 
-- Game: Ringo's Roundup
addappid(2769290)
addappid(2769291, 1, "7eb10e829140a63c5e58a49bd2e84c5b60fc81ffbd0c76fd9f9a4a10e803c1d9")
