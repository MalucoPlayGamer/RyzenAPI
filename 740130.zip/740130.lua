-- Lua provided by SkyAPI 
-- Game: AppID 740130
addappid(740130)
addappid(740131, 1, "53bd94c3766f7bed57c085db01225225321c8f56f7f7455beeb783b19d4c5f35")
addappid(740133, 1, "d567daa6083fc8d7def267e5a2234477b78c924d3858154bbd538d8e8e930072")
