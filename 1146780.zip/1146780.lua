-- Lua provided by SkyAPI 
-- Game: Monster planet
addappid(1146780)
addappid(1146781, 1, "8796e2d861a9ff4e019fc3bbc610e9f969ed682cc5227a083168b392bb1d66ff")
