-- Lua provided by RyzenAPI
-- Game: Geocore

-- MAIN APPLICATION
addappid(355190)

-- MAIN APP DEPOTS / PACKAGES
addappid(355191, 1, "82a479e5a0f2ecdc33b4ad6eb60ee34dd2a44bea0943af41bd3c2eb816bbb843")

