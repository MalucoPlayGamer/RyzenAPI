-- Lua provided by RyzenAPI
-- Game: Game: AppID 3286720

-- MAIN APPLICATION
addappid(3286720)
-- Game: addappid(3286720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286721, 1, "1af3de0d01a0c2b7b0348c44159f4cc742640a989969f3ef0141a9faf533cc9f")
