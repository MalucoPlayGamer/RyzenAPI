-- Lua provided by RyzenAPI
-- Game: Mortanis Prisoners

-- MAIN APPLICATION
addappid(2354120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354121, 1, "e6d96ec67033a7f3de30fd38fc453281b78808cc6d73c5199cf14b6b2c2b8697")

