-- Lua provided by RyzenAPI
-- Game: Put in

-- MAIN APPLICATION
addappid(1132120)
addappid(1237860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132121, 1, "9b78f37b7bf57a02133fd32d912c1ae1f107ad0fded44fa25c299fcc81335873")

