-- Lua provided by RyzenAPI
-- Game: AppID 714640

-- MAIN APPLICATION
addappid(714640)
-- Game: addappid(714640)

-- MAIN APP DEPOTS / PACKAGES
addappid(714641, 1, "ce2969d93be83b47b404a67ec26ab21634bcc9dbda35da69c864ad435ed844c6")
