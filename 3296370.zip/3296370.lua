-- Lua provided by RyzenAPI 
-- Game: Cursed New Year
addappid(3296370)
addappid(3296371, 1, "fbc115df60af81ba03bb4f7fb7826ea1fab6db4a53ae1274ca1d7967c02368aa")
