-- Lua provided by RyzenAPI
-- Game: addappid(1954640)

-- MAIN APPLICATION
addappid(1954640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954641, 1, "e0c7ad606042904e2a9a195579febc7324888a14f18c2a608b33654fca29c63c")
