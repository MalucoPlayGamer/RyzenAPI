-- Lua provided by RyzenAPI
-- Game: Mass Effect™ 3 Digital Books

-- MAIN APPLICATION
addappid(1317471)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317471,0,"b18bfca279876e1d2a578b2532de84c933799ae4d075d25f5453822b17141a97")
addappid(1317790,0,"95e49642ca4c964188fc0983d69b621d3cadbeac746adc910dd6d27e54abe03b")
addappid(1317791,0,"fa5e25d99462f2a9d94e41ae35805349521ff8f043eabadb2d4ad1c8fa46cd06")
addappid(1317792,0,"5befdb43ac2cfd1cc04acc956471c9ca543dafec8f6306f56046d0cdf2c5ebe4")
addappid(1317793,0,"582b5a77f0dfb8d09f2ecabd9f3c42cbd669263fb5be1f8b92e3d5531a502a48")
addappid(1317794,0,"809728da69c295e8c5abaf50550f5f40512d8dbcda2a21fb99a249ff263bd2cf")
addappid(1317795,0,"0ca71cc5fe88249b9e2edd06adea1ccd098d66ec93421cf5645bc865373e3d56")
addappid(1317796,0,"c9acea08b07af566c4347ff5879e59b5f22745afd868579c6dc0e47a51d50826")

