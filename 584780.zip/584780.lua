-- Lua provided by RyzenAPI
-- Game: AppID 584780

-- MAIN APPLICATION
addappid(584780)

-- MAIN APP DEPOTS / PACKAGES
addappid(584781, 1, "a710c993cd9847bba414272e47b46c00b3d74db74e06e8af1450ce5c5eaacae1")
