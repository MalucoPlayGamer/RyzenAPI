-- Lua provided by RyzenAPI
-- Game: addappid(1234730)

-- MAIN APPLICATION
addappid(1234730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234731, 1, "481d5f4917fb1f79748c8bcd9e1808949bdc561789a10a72f62ca896a4c7ac64")
