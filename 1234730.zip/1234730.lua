-- Lua provided by RyzenAPI
-- Game: HereSphere VR Video Player

-- MAIN APPLICATION
addappid(1234730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1234731, 1, "481d5f4917fb1f79748c8bcd9e1808949bdc561789a10a72f62ca896a4c7ac64")

