-- Lua provided by SkyAPI 
-- Game: HereSphere VR Video Player
addappid(1234730)
addappid(1234731, 1, "481d5f4917fb1f79748c8bcd9e1808949bdc561789a10a72f62ca896a4c7ac64")
