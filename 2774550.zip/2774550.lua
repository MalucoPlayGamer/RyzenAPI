-- Lua provided by RyzenAPI
-- Game: 2774550

-- MAIN APPLICATION
addappid(2774550)
-- Game: addappid(2774550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774551, 1, "538ddb604125615c8527c8ce9ed990f21c5bea4b274679fbc4087b8c572efba8")
