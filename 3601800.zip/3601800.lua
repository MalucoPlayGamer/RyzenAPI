-- Lua provided by RyzenAPI
-- Game: setManifestid(3601801,"4803133971782193171")

-- MAIN APPLICATION
addappid(3601800)
addappid(4707900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3601801,0,"048175d4bbc12230b351c03d114c954dd37ccfcabab8e501a6a7ec6aec707cc3")

