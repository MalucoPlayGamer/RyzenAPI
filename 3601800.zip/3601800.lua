-- Lua provided by RyzenAPI
-- Game: Meltopia

-- MAIN APPLICATION
addappid(3601800)
addappid(4707900)
addappid(4707900) -- Meltopia - Frozen Expedition

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3601800, 1, "1afaf44f72baf77045a1e0e7a2c34744d11111720b1760837c886ab8198e86a2")
addappid(3601801,0,"048175d4bbc12230b351c03d114c954dd37ccfcabab8e501a6a7ec6aec707cc3")
addappid(3601801, 1, "048175d4bbc12230b351c03d114c954dd37ccfcabab8e501a6a7ec6aec707cc3") -- Depot 3601801

