-- Lua provided by RyzenAPI
-- Game: Guns N Stuff

-- MAIN APPLICATION
addappid(1406350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1406351, 1, "e9708f5dc757deaf34c4b6c15c0b0234f1c5fe5a8e01a307505c57722a0f18a7")

