-- Lua provided by RyzenAPI 
-- Game: Guns N Stuff
addappid(1406350)
addappid(1406351, 1, "e9708f5dc757deaf34c4b6c15c0b0234f1c5fe5a8e01a307505c57722a0f18a7")
