-- Lua provided by RyzenAPI
-- Game: addappid(71400)

-- MAIN APPLICATION
addappid(71400)

-- MAIN APP DEPOTS / PACKAGES
addappid(71401, 1, "ce330e6296d810e2319c0e5049af3ed050bd5f9853a9e0d9190aa25fcf2d0954")
