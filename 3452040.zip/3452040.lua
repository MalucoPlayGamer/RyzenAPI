-- Lua provided by RyzenAPI
-- Game: AFFRAID

-- MAIN APPLICATION
addappid(3452040)
-- Game: addappid(3452040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452041, 1, "58311791b3fe938df460bbdd1edc21b0ed9fe4b1f7c5c36b7129216a7e8cc870")
