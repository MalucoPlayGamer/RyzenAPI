-- Lua provided by RyzenAPI
-- Game: 1396260

-- MAIN APPLICATION
addappid(1396260)
-- Game: addappid(1396260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396261, 1, "859083e296bedecd08d818cf7f800960cb0970cbeb88d8acd83dbebad1a3ae91")
