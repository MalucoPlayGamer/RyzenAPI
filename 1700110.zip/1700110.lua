-- Lua provided by RyzenAPI
-- Game: The Edge Of

-- MAIN APPLICATION
addappid(1700110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700111, 1, "add4ed4f7c2069c3e86de16929dec8cbe35e82ca4f9297b63e3725fc3efece70")
