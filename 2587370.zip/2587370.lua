-- Lua provided by RyzenAPI
-- Game: Chick-Chick

-- MAIN APPLICATION
addappid(2587370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587371, 1, "893f9d71526ecf3f6ea95ee998a2391cddf5be1d95a6f294de3ea20dcf8f27cb")
