-- Lua provided by RyzenAPI
-- Game: Game: Training Grounds

-- MAIN APPLICATION
addappid(1443250)
-- Game: addappid(1443250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443251, 1, "c5ec25fce11bd3626a5108d39fae36a042606eb5f3fc9368aa783056575041c7")
