-- Lua provided by RyzenAPI 
-- Game: The Forgotten Apartment
addappid(3727810)
addappid(3727811, 1, "a9315212bbf2f0dc85946fcfb92c57f4aadc78de03e81a4d745f50b9eda2432d")
