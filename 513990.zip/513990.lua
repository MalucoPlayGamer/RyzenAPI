-- Lua provided by RyzenAPI
-- Game: Happy Empire

-- MAIN APPLICATION
addappid(513990)
-- Game: addappid(513990)

-- MAIN APP DEPOTS / PACKAGES
addappid(513991, 1, "058a90995ac2c84bc7a546a61139f14d2e1e1effe7503b7a435bcb9d5b1b7383")
