-- Lua provided by RyzenAPI
-- Game: 2990430

-- MAIN APPLICATION
addappid(2990430)
-- Game: addappid(2990430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990430,0,"cc1e64d590434473930b6edd90d09027aa939a0d8b1fcc7d3ccd30f86ea21e1f")
