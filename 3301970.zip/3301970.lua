-- Lua provided by RyzenAPI
-- Game: addappid(3301970)

-- MAIN APPLICATION
addappid(3301970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301972,0,"cecd7a6496e9567eee6bc9da5f8ff3542b414286126292f23ec274d699e49156")
