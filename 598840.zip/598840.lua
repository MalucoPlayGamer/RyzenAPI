-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(598840)
addappid(598841)
addappid(598842)
addappid(598843)
-- Game: addappid(598840)

-- MAIN APP DEPOTS / PACKAGES
addappid(598844,0,"ca105900ab565efe7237fcf8252698ce66d1c1a23b6fa5cdecc22fca9fedb0ac")
