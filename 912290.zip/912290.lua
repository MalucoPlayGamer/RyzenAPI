-- Lua provided by RyzenAPI
-- Game: 912290

-- MAIN APPLICATION
addappid(912290)
-- Game: addappid(912290)

-- MAIN APP DEPOTS / PACKAGES
addappid(912291, 1, "c9900d632fcf123492b083e20b0f8df5ba905152b5c2efdf06d882ad70c0c2e3")
