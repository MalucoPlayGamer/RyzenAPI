-- Lua provided by SkyAPI 
-- Game: Twilight Memoria
addappid(1402900)
addappid(1402901, 1, "961e486210ddde4c00e1daf0f874b3710a5709d47e8f5ad6076f420c6a04dd61")
