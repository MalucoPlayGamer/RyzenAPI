-- Lua provided by RyzenAPI 
-- Game: Quescaper
addappid(3033880)
addappid(3033881, 1, "67a36ca96d19242ad4bc4942a7c51794e84b41d4831b580c7d438248845338d1")
