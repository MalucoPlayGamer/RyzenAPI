-- Lua provided by RyzenAPI
-- Game: Game: Quescaper

-- MAIN APPLICATION
addappid(3033880)
-- Game: addappid(3033880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033881, 1, "67a36ca96d19242ad4bc4942a7c51794e84b41d4831b580c7d438248845338d1")
