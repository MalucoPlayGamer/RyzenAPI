-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - EVFX Slash

-- MAIN APPLICATION
addappid(2623780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623780,0,"6e3db3d8382ac9bd409c1f1f847d1f77a67faf7c00e7a5e2786ceb79c7d5f727")
