-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes Chapter One Original Game Soundtrack

-- MAIN APPLICATION
addappid(1581931)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797150,0,"aaec31934332d1c9fe76a2e40fcf46c652ccfd0b1447e02454d86ffa547a27ec")
addappid(1797151,0,"1d33dd771f598c5f1670ce51cca7c58ea5e6e64d3c01eb67540cffe597c2e65c")

