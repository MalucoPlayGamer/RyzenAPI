-- Lua provided by RyzenAPI 
-- Game: Horror Adventure VR Demo
addappid(1321000)
addappid(1321001, 1, "93f850c285dc705616d8f4e6d8379a99bd523efeec4ef22db9bc2c8be34c5815")
