-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 3 - Additional Area "Rosca Island"

-- MAIN APPLICATION
addappid(2156250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156250,0,"f4f3013ed0f1723bc95f6e82b0c6e79bc562c5a850e13ef6b5e0651ac1112288")

