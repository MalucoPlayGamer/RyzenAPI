-- Lua provided by RyzenAPI
-- Game: BIKEOUT

-- MAIN APPLICATION
addappid(2322050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2322051, 1, "076642665e12422dad858f6013d33f596e7f77e300a8661146144a2caa9d9b83")

