-- Lua provided by RyzenAPI
-- Game: Syndeo-Complex

-- MAIN APPLICATION
addappid(1988930)
-- Game: addappid(1988930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988931, 1, "00b33e90a7b389ed618af94a452fdd698de61177c1d767ad40b546ce9588937e")
