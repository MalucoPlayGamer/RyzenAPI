-- Lua provided by RyzenAPI
-- Game: Syndeo-Complex

-- MAIN APPLICATION
addappid(1988930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1988931, 1, "00b33e90a7b389ed618af94a452fdd698de61177c1d767ad40b546ce9588937e")

