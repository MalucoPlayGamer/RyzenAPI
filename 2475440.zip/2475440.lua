-- Lua provided by RyzenAPI
-- Game: Last Hope Bunker: Zombie Survival

-- MAIN APPLICATION
addappid(2475440)
-- Game: addappid(2475440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475441, 1, "cf6a133cf88be01b087d07347946d0882868a6c9d2999ec4a6e1bec1e667fc4b")
