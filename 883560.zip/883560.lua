-- Lua provided by SkyAPI 
-- Game: AppID 883560
addappid(883560)
addappid(883561, 1, "21a0b368c3510133680abcdc25e97e4bda6b4bbde17063406c4ee0eff3f15a7c")
addappid(883563, 1, "6cfe8a84e9cba0ff8d5ef44fdceb5d2bed3359eaddb66344c096e578de061373")
