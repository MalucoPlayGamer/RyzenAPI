-- Lua provided by RyzenAPI
-- Game: addappid(2008980)

-- MAIN APPLICATION
addappid(2008980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008981, 1, "ff99de909281660c9ce16da5d8073f45871bdd69f42cdef2f45e62eabb696c09")
