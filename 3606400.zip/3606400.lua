-- 3606400's Lua and Manifest Created by Hubcap Manifest
-- Dungeon Repeater
-- Created: August 13, 2026 at 11:13:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3606400, 1, "84a75577e030340380325bd2111ccfba23d6896ab168d0270e3b9031718ed070") -- Dungeon Repeater
-- MAIN APP DEPOTS
addappid(3606401, 1, "db5ed7680e956e5ca5194604fe67e45d9850f999fe02fa69e77d26992afe0ec9") -- Depot 3606401
setManifestid(3606401, "8253957394792047260", 78171626)
addappid(3606402, 1, "f6071b26f295541066f2b6f05368d32c16d81a76e9969476f5dd52404ad8f6ff") -- Depot 3606402
setManifestid(3606402, "8817846636401299244", 66671787)
addappid(3606403, 1, "f9fafb89d107a0d9b6a865739a5340483364d25561b6490009295c837fbbfefe") -- Depot 3606403
setManifestid(3606403, "3685702187923495322", 65815129)