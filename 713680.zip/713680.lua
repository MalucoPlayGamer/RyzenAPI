-- Lua provided by RyzenAPI
-- Game: Ablepsia

-- MAIN APPLICATION
addappid(713680)

-- MAIN APP DEPOTS / PACKAGES
addappid(713681, 1, "0d72abb2e84550c7ace65d4894a93427a52265258447d38cf4115e0a390fe526")

