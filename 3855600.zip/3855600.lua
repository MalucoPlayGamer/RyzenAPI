-- Lua provided by RyzenAPI
-- Game: Runerock Arena

-- MAIN APPLICATION
addappid(3855600) -- Runerock Arena

-- MAIN APP DEPOTS / PACKAGES
addappid(3855601, 1, "47144b72194b29b4963fa3838c247285f3692838ac2a1d1036eaafe7716a57b5") -- Depot 3855601

