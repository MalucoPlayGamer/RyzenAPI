-- 3855600's Lua and Manifest Created by Hubcap Manifest
-- Runerock Arena
-- Created: August 11, 2026 at 23:23:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3855600) -- Runerock Arena
-- MAIN APP DEPOTS
addappid(3855601, 1, "47144b72194b29b4963fa3838c247285f3692838ac2a1d1036eaafe7716a57b5") -- Depot 3855601
setManifestid(3855601, "2939262754160683710", 279537135)