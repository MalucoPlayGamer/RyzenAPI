-- Lua provided by RyzenAPI
-- Game: White Mirror

-- MAIN APPLICATION
addappid(428630)

-- MAIN APP DEPOTS / PACKAGES
addappid(428631, 1, "f791ca63fc7c6a4068663ddd574b05f4c2a86cf7c9d54d6b1972f7f57623e57e")
