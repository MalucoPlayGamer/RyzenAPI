-- Lua provided by RyzenAPI
-- Game: District Steel

-- MAIN APPLICATION
addappid(616820)

-- MAIN APP DEPOTS / PACKAGES
addappid(616821, 1, "33235b4268a57d698b4fbf3fea5c2b0d54cdea3aac4579b7f06805d09f294feb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
