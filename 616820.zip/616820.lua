-- Lua provided by RyzenAPI
-- Game: addappid(616820)

-- MAIN APPLICATION
addappid(616820)

-- MAIN APP DEPOTS / PACKAGES
addappid(616821, 1, "33235b4268a57d698b4fbf3fea5c2b0d54cdea3aac4579b7f06805d09f294feb")
