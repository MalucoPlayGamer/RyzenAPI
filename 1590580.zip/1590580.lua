-- Lua provided by RyzenAPI
-- Game: Game: MELTY BLOOD ARCHIVES

-- MAIN APPLICATION
addappid(1590580)
-- Game: addappid(1590580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590581, 1, "436fa82f9d7f9bffc15db902c75faa6562cbf24ba1bbc9b1125841e2e7f00826")
