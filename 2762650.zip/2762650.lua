-- Lua provided by RyzenAPI 
-- Game: Magibrick
addappid(2762650)
addappid(2762651, 1, "9fcd175de69737f53ab941a13356d0826521b647cd558a7dee1d3c6b9589238e")
