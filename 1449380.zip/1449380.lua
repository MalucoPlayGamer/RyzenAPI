-- Lua provided by RyzenAPI
-- Game: Colored Shapes

-- MAIN APPLICATION
addappid(1449380)
-- Game: addappid(1449380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449381, 1, "ac56f8309951ae18bd6405cba91c8b4022062dad95a8a45738b4ae9e10e3e3da")
