-- Lua provided by RyzenAPI
-- Game: Game: Shyma and the Lesbian Demon Lord

-- MAIN APPLICATION
addappid(3631170)
-- Game: addappid(3631170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631171, 1, "e4e77b986160f19a9d0f8d6b221c7e69ea14a5f569db37414b292d1199c814c3")
