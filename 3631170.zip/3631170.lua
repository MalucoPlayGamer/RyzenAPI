-- Lua provided by RyzenAPI
-- Game: Shyma and the Lesbian Demon Lord

-- MAIN APPLICATION
addappid(3631170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631171, 1, "e4e77b986160f19a9d0f8d6b221c7e69ea14a5f569db37414b292d1199c814c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
