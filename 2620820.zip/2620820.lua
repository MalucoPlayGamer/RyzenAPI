-- Lua provided by RyzenAPI
-- Game: addappid(2620820)

-- MAIN APPLICATION
addappid(2620820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620820,0,"1e6063e0e1c85a7af258af8c40c1500cdeccd0fdb943f88c7fb56d8abbf8277d")
