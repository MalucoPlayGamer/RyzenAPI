-- Lua provided by RyzenAPI 
-- Game: Irony Curtain: From Matryoshka with Love
addappid(866190)
addappid(866191, 1, "961862d3212ebfa9dd2f03e902112927b436cd835087c478d146a8e786039d8b")
addappid(866192, 1, "4572885eed5114f8cc25adb6f942f7749128b7119095cf55c94ac85481d5d10d")
addappid(866193, 1, "c231161555545395c2bb042101d3aed5d41e4e1a0560440e51b75e4694eba4bf")
addappid(1078741, 0, "63bdb60b9313c0bd4d6ce4f83d24ddab16ae252635fb361a8bf966b9431bcc6a")
