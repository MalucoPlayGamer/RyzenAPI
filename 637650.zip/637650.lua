-- Lua provided by RyzenAPI
-- Game: addappid(637650)

-- MAIN APPLICATION
addappid(637650)

-- MAIN APP DEPOTS / PACKAGES
addappid(637651, 1, "067cfbc8b2cdd98dec9619de67a9c50b91477b19e8220fe19adf16631383d1e6")
