-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY XV WINDOWS EDITION

-- MAIN APPLICATION
addappid(637650)

-- MAIN APP DEPOTS / PACKAGES
addappid(637651, 1, "067cfbc8b2cdd98dec9619de67a9c50b91477b19e8220fe19adf16631383d1e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(771560)
addappid(787600)
addappid(787610)
addappid(922570)
addappid(977610)
