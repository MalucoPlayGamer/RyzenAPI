-- Lua provided by RyzenAPI
-- Game: addappid(486540)

-- MAIN APPLICATION
addappid(486540)

-- MAIN APP DEPOTS / PACKAGES
addappid(486541, 1, "9f3d186065bdade62b89699d99ed1358236a5f871bbc1562a45610ba32522ea9")
