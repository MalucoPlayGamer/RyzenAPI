-- Lua provided by RyzenAPI
-- Game: Your Ball Exploded

-- MAIN APPLICATION
addappid(872980)

-- MAIN APP DEPOTS / PACKAGES
addappid(872981, 1, "522203115365e7c2898f3f4c9e8d3d72e7d05a2f21f2d9d65458ac68938ecd73")

