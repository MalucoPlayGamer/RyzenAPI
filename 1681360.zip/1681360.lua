-- Lua provided by RyzenAPI
-- Game: Gore. Prologue.

-- MAIN APPLICATION
addappid(1681360)
-- Game: addappid(1681360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681365,0,"284e31520ccb157eb4a89608bda598c341cc60987a7f47505468861faa0212ec")
