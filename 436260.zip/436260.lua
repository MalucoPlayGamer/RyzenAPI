-- Lua provided by RyzenAPI
-- Game: setManifestid(436262,"3933526682866356762")

-- MAIN APPLICATION
addappid(436260)

-- MAIN APP DEPOTS / PACKAGES
addappid(436262,0,"f9cc8a2e3206610b673cb65dd7f435be4598d09a37d925a8b3c5ea02aaeca92e")
