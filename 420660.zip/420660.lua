-- Lua provided by RyzenAPI
-- Game: Burnin' Rubber 5 HD

-- MAIN APPLICATION
addappid(420660)

-- MAIN APP DEPOTS / PACKAGES
addappid(420661, 1, "34532fb1c84245d00fab7ee1659e7d5538ed0f81e654436c6a3e2101b37c4435")

