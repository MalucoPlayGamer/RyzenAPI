-- Lua provided by RyzenAPI
-- Game: Super Hyperactive Ninja

-- MAIN APPLICATION
addappid(743330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(743331, 1, "0698a3c640d55ac9ec34acb4d5d66b3f715052c2686a5d096431cb282b6a4a5a")
