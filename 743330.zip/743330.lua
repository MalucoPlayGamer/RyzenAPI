-- Lua provided by RyzenAPI
-- Game: AppID 743330

-- MAIN APPLICATION
addappid(743330)
-- Game: addappid(743330)

-- MAIN APP DEPOTS / PACKAGES
addappid(743331, 1, "0698a3c640d55ac9ec34acb4d5d66b3f715052c2686a5d096431cb282b6a4a5a")
