-- Lua provided by RyzenAPI
-- Game: LEGO® Bricktales

-- MAIN APPLICATION
addappid(1898290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898291, 1, "0d2fbdae03623a225c394a15ce2505d6b3d72cc604563f131bcf2370d5195991")
addappid(1898292, 1, "0976b5441d1b2e1a9d3344f141f53d1a0b79c825c77cfb0585a1a0c5840c9f9c")
addappid(1898293, 1, "8348c331194d94325f92e8abcca8e8b21fe27e2c236d0bbcfbbd7f5999c59bd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
