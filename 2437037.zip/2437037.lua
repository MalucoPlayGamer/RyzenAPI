-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Helgoland

-- MAIN APPLICATION
addappid(2437037)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437037,0,"65e8322f92746fcf136375a99917770a4dda731f4d6ad80af88e49f3251a20a6")

