-- Lua provided by RyzenAPI
-- Game: addappid(2831200)

-- MAIN APPLICATION
addappid(2831200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831201, 1, "7dd932510a2c4b1ef4ad057909fbe93390a74f1bf235b637eecf16b930befb1e")
