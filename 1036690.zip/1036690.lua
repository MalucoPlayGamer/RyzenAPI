-- Lua provided by RyzenAPI
-- Game: addappid(1036690)

-- MAIN APPLICATION
addappid(1036690)
addappid(1076460)
addappid(1076470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036691, 1, "8ff224080cadce62390c496a3291f13e83e1ef91ab030353db7daa94e48930de")
