-- 4932350's Lua and Manifest Created by Hubcap Manifest
-- Watch The Edge Honey!
-- Created: August 06, 2026 at 23:44:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4932350) -- Watch The Edge Honey!
-- MAIN APP DEPOTS
addappid(4932351, 1, "af3ef6e6e612ee2e88f5354773d3245ae39d5444dae415eea701aa8b7d633184") -- Depot 4932351
setManifestid(4932351, "7165479531114674314", 3382355079)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)