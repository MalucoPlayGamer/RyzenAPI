-- Lua provided by RyzenAPI
-- Game: Watch The Edge Honey!

-- MAIN APPLICATION
addappid(4932350) -- Watch The Edge Honey!

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4932351, 1, "af3ef6e6e612ee2e88f5354773d3245ae39d5444dae415eea701aa8b7d633184") -- Depot 4932351

