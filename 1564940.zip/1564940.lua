-- Lua provided by RyzenAPI
-- Game: Game: A Strange City

-- MAIN APPLICATION
addappid(1564940)
-- Game: addappid(1564940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564941, 1, "95f617bd36ba4ed42279345c0003968f8f5205bd73e6b1f9d7439a65dc6381a5")
