-- Lua provided by RyzenAPI
-- Game: ARCADE GAME SERIES: DIG DUG

-- MAIN APPLICATION
addappid(403400)

-- MAIN APP DEPOTS / PACKAGES
addappid(403401, 1, "5369b34e713bec5790d692e548b786a1e42f1258466b8c7dd12ad92a20e71449")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
