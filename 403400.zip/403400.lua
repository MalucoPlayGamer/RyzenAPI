-- Lua provided by RyzenAPI
-- Game: 403400

-- MAIN APPLICATION
addappid(403400)
-- Game: addappid(403400)

-- MAIN APP DEPOTS / PACKAGES
addappid(403401, 1, "5369b34e713bec5790d692e548b786a1e42f1258466b8c7dd12ad92a20e71449")
