-- Lua provided by RyzenAPI
-- Game: Mostly Intense Monster Defense

-- MAIN APPLICATION
addappid(1116430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116431, 1, "972199920973f74314a0d838cd406234e97a17191448687d2436412faf4a493c")

