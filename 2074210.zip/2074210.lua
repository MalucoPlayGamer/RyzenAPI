-- Lua provided by RyzenAPI
-- Game: Seven Deadly Dates Artbook + Wallpapers

-- MAIN APPLICATION
addappid(2074210)
-- Game: addappid(2074210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074210,0,"edc73115d59328ee2ca5a37e552ca3b6197879fcb9977223235b5a8324095196")
