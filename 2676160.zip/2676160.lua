-- Lua provided by RyzenAPI
-- Game: Arcade Paradise VR

-- MAIN APPLICATION
addappid(2676160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676161, 1, "51f0c7eac9ef8ff548b6470862724f7ed167d7cf27bff57009b80d4d65f1cff5")

