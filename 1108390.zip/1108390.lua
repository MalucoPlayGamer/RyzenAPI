-- Lua provided by RyzenAPI
-- Game: Cartonfall: Fortress - Defend Cardboard Castle

-- MAIN APPLICATION
addappid(1108390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108391, 1, "4ba049ce6d66fad0baea03414ddbf670b37a565335abbca33838d71d34df6729")

