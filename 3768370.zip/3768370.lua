-- Lua provided by RyzenAPI
-- Game: ARROW-ButtonHeart

-- MAIN APPLICATION
addappid(3768370)
-- Game: addappid(3768370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3768371, 1, "3b179d53fa4d3ecaafbfdcfe4db22db2824fed21abea3a3b55ad0232810184c8")
