-- Lua provided by RyzenAPI
-- Game: 2343920

-- MAIN APPLICATION
addappid(2343920)
-- Game: addappid(2343920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343921, 1, "31f334e1a8f8c1db91c9b140260928df5ec397e7aa39b1c8e59c16ea65745f6d")
