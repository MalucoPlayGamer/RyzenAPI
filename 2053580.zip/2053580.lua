-- Lua provided by RyzenAPI
-- Game: Nonozle

-- MAIN APPLICATION
addappid(2053580)
addappid(3077890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053581, 1, "3a2fbb18cecc7cfaa9866b17fba3a36e722b5a5b55cbee90788d84fd918397c1")
