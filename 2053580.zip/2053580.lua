-- Lua provided by RyzenAPI
-- Game: Nonozle

-- MAIN APPLICATION
addappid(2053580)
addappid(3077890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053581, 1, "3a2fbb18cecc7cfaa9866b17fba3a36e722b5a5b55cbee90788d84fd918397c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
