-- Lua provided by RyzenAPI
-- Game: 692590

-- MAIN APPLICATION
addappid(692590)
-- Game: addappid(692590)

-- MAIN APP DEPOTS / PACKAGES
addappid(692591, 1, "78fee208867edf9c7262dca04dafaf661e353b192427f5f215287a9c28d5ab19")
