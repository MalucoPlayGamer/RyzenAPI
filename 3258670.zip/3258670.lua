-- Lua provided by RyzenAPI
-- Game: Tomorrow's Land

-- MAIN APPLICATION
addappid(3258670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3258671, 1, "26f53ccee75c03512ee89aa058fe2a1630bedffcc397a2d9fbcc13812fd40121")
addappid(3258672, 1, "6b23f8521fb88dd0928235238b2811fdd3ce83ca68df30be3b13d8ef35a4a415")

