-- Lua provided by RyzenAPI
-- Game: BEATris

-- MAIN APPLICATION
addappid(708890)

-- MAIN APP DEPOTS / PACKAGES
addappid(708891, 1, "036a0f7b4fb1e36fc8e6951f78a4bf918772f0a16b2f59c8dfd284ffd7e6d72f")
