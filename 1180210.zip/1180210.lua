-- Lua provided by RyzenAPI
-- Game: Super Rhythm Duel

-- MAIN APPLICATION
addappid(1180210)
-- Game: addappid(1180210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180211, 1, "68b4fb113ed676356b91c75551da2732de9215696d968c999598d6a05f9eeaf2")
