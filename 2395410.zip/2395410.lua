-- Lua provided by RyzenAPI
-- Game: Sol: Last Light

-- MAIN APPLICATION
addappid(2395410)
-- Game: addappid(2395410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395411, 1, "6a17b9b861effe002a99d9815f3a8e5300246bc15191b452c91885dc20f09f59")
