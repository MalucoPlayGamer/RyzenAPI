-- Lua provided by RyzenAPI
-- Game: 2088370

-- MAIN APPLICATION
addappid(2088370)
-- Game: addappid(2088370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088371, 1, "1081dac47230b6a471b91465886fa32243beca0d7a39c4cc878a38ae37b953b2")
