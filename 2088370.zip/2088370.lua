-- Lua provided by SkyAPI 
-- Game: PIGFACE MASSACRE Playtest
addappid(2088370)
addappid(2088371, 1, "1081dac47230b6a471b91465886fa32243beca0d7a39c4cc878a38ae37b953b2")
