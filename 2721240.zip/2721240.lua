-- Lua provided by RyzenAPI
-- Game: 2721240

-- MAIN APPLICATION
addappid(2721240)
-- Game: addappid(2721240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721241, 1, "c10a81267d98a6a76323ac707aaa92e8c8d4d4bdf52dcf94c9a0b5b6f840fa7f")
