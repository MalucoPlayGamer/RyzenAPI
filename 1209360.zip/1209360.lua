-- Lua provided by RyzenAPI
-- Game: Monster Truck Championship

-- MAIN APPLICATION
addappid(1209360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209361, 1, "3bc42f0024e1907176a46327632384f81e86170bf2f2291cb780dcaeb40a0f36")

