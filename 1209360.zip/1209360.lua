-- Lua provided by RyzenAPI
-- Game: Monster Truck Championship

-- MAIN APPLICATION
addappid(1209360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209361, 1, "3bc42f0024e1907176a46327632384f81e86170bf2f2291cb780dcaeb40a0f36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1357170)
addappid(1357171)
