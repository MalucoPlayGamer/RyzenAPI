-- Lua provided by RyzenAPI
-- Game: Game: AppID 584370

-- MAIN APPLICATION
addappid(584370)
-- Game: addappid(584370)

-- MAIN APP DEPOTS / PACKAGES
addappid(584371, 1, "d7e2e81a1b4a12d57fcb729c1583c30e9e3120f300caf2ebc408cd1e14fc060f")
addappid(584372, 1, "de0acbce737886b769d265c0c085756e36d21c664eec28aeef0f265657ac5041")
