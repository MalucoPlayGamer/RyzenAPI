-- Lua provided by RyzenAPI
-- Game: addappid(739700)

-- MAIN APPLICATION
addappid(739700)

-- MAIN APP DEPOTS / PACKAGES
addappid(739701, 1, "b1e3c9225aa0c3028fdcb96744c13060f476bd9051f43058c733594270e4eae0")
