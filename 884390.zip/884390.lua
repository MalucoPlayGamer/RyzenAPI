-- Lua provided by RyzenAPI
-- Game: Professor Watts Word Search: Pirates Life

-- MAIN APPLICATION
addappid(884390)

-- MAIN APP DEPOTS / PACKAGES
addappid(884391, 1, "70db22a41dd9490cc87bc09fbe09c4794f75ea8f7baf22231cfec2b06f2ab612")

