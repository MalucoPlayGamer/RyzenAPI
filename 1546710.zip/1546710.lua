-- Lua provided by RyzenAPI
-- Game: Game: Vernal Edge

-- MAIN APPLICATION
addappid(1546710)
-- Game: addappid(1546710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546711, 1, "578fc7607faca3cc714281494a29381c314b482a69da97fb74be258d443cc608")
