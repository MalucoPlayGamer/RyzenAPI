-- Lua provided by SkyAPI 
-- Game: EcoGnomix
addappid(2473640)
addappid(2473641, 1, "3de94928ef3e10f42717c781db624af3c067367a54b349474408b50148fecdc1")
