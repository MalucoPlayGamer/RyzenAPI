-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2082500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082502,0,"e0f5e932b35c3d2080b8063a2b675a4f6e3a98c6ef4829c45fc25b3d7d7056ae")
