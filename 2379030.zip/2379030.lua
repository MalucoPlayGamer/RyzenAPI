-- Lua provided by RyzenAPI
-- Game: Game: Barro T23

-- MAIN APPLICATION
addappid(2379030)
-- Game: addappid(2379030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379031, 1, "affef6e4b68eb0dc05b4e8d44164886bd636ecb23cf8bfa950a6467ab38e4be0")
addappid(2379032, 1, "d01b261496d4a6bb21d979e10a141cbf5fb73bb1f5d347d85492f80ba5b88faf")
