-- Lua provided by RyzenAPI
-- Game: Dark Fairy Fantasy - Soundtrack

-- MAIN APPLICATION
addappid(1169330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169330,0,"fb46109a66ac5a81bd38b2720482755c6b3807bc2c034eb66e7aa3b05ef23321")

