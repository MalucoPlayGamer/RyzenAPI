-- Lua provided by RyzenAPI
-- Game: Bright Memory: Infinite Bikini DLC

-- MAIN APPLICATION
addappid(1781100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781100,0,"d071ca80abb766ecb037f9cf11e33c6b04295ae0d651050c2147d7cf090ad1a4")
