-- Lua provided by RyzenAPI
-- Game: 2750960

-- MAIN APPLICATION
addappid(2750960)
-- Game: addappid(2750960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2750961, 1, "f38e8c2e181c97cdb4391e1a85fe2126086c6f3f919d79e76b25dcb88d3c3c8c")
