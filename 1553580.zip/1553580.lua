-- Lua provided by SkyAPI 
-- Game: Bondage Girl
addappid(1553580)
addappid(1553581, 1, "c42a8b104e221b173436718f763c3a9b41de2dffed98ecf9ec54e4bafbfff87e")
