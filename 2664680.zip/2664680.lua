-- Lua provided by RyzenAPI
-- Game: Mysterious legend

-- MAIN APPLICATION
addappid(2664680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664681, 1, "0b94854cca6afa83bac8ac72cd9415c66705580f254d9bac1be086f94e031686")

