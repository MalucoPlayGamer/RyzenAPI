-- Lua provided by RyzenAPI 
-- Game: Zombie Builder Defense 2
addappid(1638950)
addappid(1638951, 1, "54cf9bf6ba257da6d6b09f9bdcdb21a4f90523ff944e016484d088b5af0bd8b4")
