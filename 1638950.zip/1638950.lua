-- Lua provided by RyzenAPI
-- Game: Zombie Builder Defense 2

-- MAIN APPLICATION
addappid(1638950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638951, 1, "54cf9bf6ba257da6d6b09f9bdcdb21a4f90523ff944e016484d088b5af0bd8b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
