-- Lua provided by RyzenAPI
-- Game: Brew-Ha

-- MAIN APPLICATION
addappid(786490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(786491, 1, "4fdb37c1ed041386d5c4e73b8f44679e64608c9157d6da4a5d6510f47fa2b0d6")
