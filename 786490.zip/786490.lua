-- Lua provided by SkyAPI 
-- Game: AppID 786490
addappid(786490)
addappid(786491, 1, "4fdb37c1ed041386d5c4e73b8f44679e64608c9157d6da4a5d6510f47fa2b0d6")
