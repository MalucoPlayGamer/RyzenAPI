-- Lua provided by RyzenAPI
-- Game: Game: God of Rock

-- MAIN APPLICATION
addappid(1851030)
-- Game: addappid(1851030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851031, 1, "047e954287813769e50adaa5c3c311168fa0de7915af694414725cb490b8940f")
