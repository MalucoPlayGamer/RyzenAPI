-- Lua provided by RyzenAPI
-- Game: God of Rock

-- MAIN APPLICATION
addappid(1851030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1851031, 1, "047e954287813769e50adaa5c3c311168fa0de7915af694414725cb490b8940f")

