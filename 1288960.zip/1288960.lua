-- Lua provided by RyzenAPI
-- Game: SwordBoy

-- MAIN APPLICATION
addappid(1288960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288961, 1, "28621e7d436e3c1a300d8d272aca3f8b1f6c60ff58c611531d270118a915e146")

