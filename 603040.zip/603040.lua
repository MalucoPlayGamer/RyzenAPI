-- Lua provided by RyzenAPI
-- Game: AppID 603040

-- MAIN APPLICATION
addappid(603040)

-- MAIN APP DEPOTS / PACKAGES
addappid(603041, 1, "1d947537a33d9cacf83885acc46dca1a317f264d6e84bfda4f120f28d90a6568")

