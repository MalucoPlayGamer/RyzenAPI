-- Lua provided by SkyAPI 
-- Game: TrinityS
addappid(1584690)
addappid(1584691, 1, "49fbbcd3b537dc2a555f9d9d8074e39271a69d2255d6ef0912b55361a8925332")
