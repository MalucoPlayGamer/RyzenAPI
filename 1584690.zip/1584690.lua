-- Lua provided by RyzenAPI
-- Game: TrinityS

-- MAIN APPLICATION
addappid(1584690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584691, 1, "49fbbcd3b537dc2a555f9d9d8074e39271a69d2255d6ef0912b55361a8925332")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
