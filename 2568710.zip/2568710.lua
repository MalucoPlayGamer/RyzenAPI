-- Lua provided by RyzenAPI
-- Game: Game: Boing Bang Adventure

-- MAIN APPLICATION
addappid(2568710)
-- Game: addappid(2568710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568711, 1, "8e614f3134f09df82fe2235cfeb5f516aa5b96595e105947bd6002a9c690c889")
