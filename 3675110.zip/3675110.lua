-- Lua provided by RyzenAPI
-- Game: 地禍駐車場 -The Cursed Underground Parking Lot-

-- MAIN APPLICATION
addappid(3675110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3675111, 1, "0b013528c0a6e8efaf55b543bd275706dd6fb5b05026db5ded240a08e6b2baa6")
