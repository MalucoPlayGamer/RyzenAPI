-- Lua provided by RyzenAPI
-- Game: 地禍駐車場 -The Cursed Underground Parking Lot-

-- MAIN APPLICATION
addappid(3675110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3675111, 1, "0b013528c0a6e8efaf55b543bd275706dd6fb5b05026db5ded240a08e6b2baa6")

