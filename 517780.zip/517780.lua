-- Lua provided by RyzenAPI
-- Game: Ogre

-- MAIN APPLICATION
addappid(517780)
addappid(677090)

-- MAIN APP DEPOTS / PACKAGES
addappid(517781, 1, "4c35a4576b1bbda7b34d85f3a1aa91bdc2688dd6eb3e17419eb35f1b2b32fb64")
addappid(517782, 1, "3bc571c9ec318f8a960608dcb7d778f01c1cf704c6fe772cbb5e0314aca23776")
