-- Lua provided by RyzenAPI
-- Game: addappid(1912071)

-- MAIN APPLICATION
addappid(1912071)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912071,0,"52eeb94c8f62892f2f32ad2b5684ad928dd3527e04682317a95fc0db11c8510b")
