-- 2926610's Lua and Manifest Created by Hubcap Manifest
-- Travel Cuisine 2: Sweet Life
-- Created: July 31, 2026 at 03:44:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2926610) -- Travel Cuisine 2: Sweet Life
-- MAIN APP DEPOTS
addappid(2926611, 1, "27f6aaa5a2a52f8cd7eacc287d8799f4c49f87d17d4f21f9638f655b5a3cad9f") -- Depot 2926611
setManifestid(2926611, "1357263950544363767", 593459100)