-- Lua provided by RyzenAPI
-- Game: Animal Up!

-- MAIN APPLICATION
addappid(1127730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127731, 1, "8ba585bb274210fe9622b9e30fb82199402ebbc231fcd27dd4804002cdf68a68")

