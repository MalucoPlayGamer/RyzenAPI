-- Lua provided by RyzenAPI
-- Game: AppID 2215820

-- MAIN APPLICATION
addappid(2215820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215821, 1, "df4650f427c6a3d2ecea06b94f00bc8bcb27df7551c256e6ca675fa2c90d4b4b")

