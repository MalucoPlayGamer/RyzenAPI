-- Lua provided by RyzenAPI
-- Game: Space Pilgrim Episode I: Alpha Centauri

-- MAIN APPLICATION
addappid(429470)
-- Game: addappid(429470)

-- MAIN APP DEPOTS / PACKAGES
addappid(429471, 1, "79d64a415b5ac61c0e3a49d4fd3d76db57b9f7bbd99ba4c0601d1ea190676608")
