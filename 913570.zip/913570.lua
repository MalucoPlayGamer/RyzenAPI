-- Lua provided by RyzenAPI
-- Game: 913570

-- MAIN APPLICATION
addappid(913570)
-- Game: addappid(913570)

-- MAIN APP DEPOTS / PACKAGES
addappid(913571, 1, "e976cd45f705da7c36a8063837ade331a9f89523ca2204e2a4b0aae2ec787739")
