-- Lua provided by RyzenAPI
-- Game: Game: Achievement Lurker: Easiest Cosmetic Numbers

-- MAIN APPLICATION
addappid(798850)
-- Game: addappid(798850)

-- MAIN APP DEPOTS / PACKAGES
addappid(798851, 1, "496da522651536c8ecd6a5e069085fd2c097dc6203e580939987ee13bda944a2")
