-- Lua provided by RyzenAPI 
-- Game: AppID 514220
addappid(514220)
addappid(514221, 1, "932e44f86675e34ca536a4bf98b27d10589b0ef4459f067da018f435cf6b0894")
