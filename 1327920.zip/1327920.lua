-- Lua provided by RyzenAPI
-- Game: Maestro VR

-- MAIN APPLICATION
addappid(1327920)
addappid(3293890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327921, 1, "086b334bba243a70ef3f0b65861ec255c693f3e6be33df47496a90d02c09c843")

