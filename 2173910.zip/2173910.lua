-- Lua provided by RyzenAPI
-- Game: Project: WATERFALL

-- MAIN APPLICATION
addappid(2173910)
-- Game: addappid(2173910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173911, 1, "759b7dc47c41289c7202bd74a770434c24fd4ff271f43b528928f8d071d50e21")
