-- Lua provided by SkyAPI 
-- Game: Achievement Idler: Red
addappid(850050)
addappid(850051, 1, "7489ab6796af69f1982a19e9db6325fe791e2c1fc98427aaef345335550cd36c")
