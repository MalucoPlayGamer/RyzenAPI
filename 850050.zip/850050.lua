-- Lua provided by RyzenAPI
-- Game: Game: Achievement Idler: Red

-- MAIN APPLICATION
addappid(850050)
-- Game: addappid(850050)

-- MAIN APP DEPOTS / PACKAGES
addappid(850051, 1, "7489ab6796af69f1982a19e9db6325fe791e2c1fc98427aaef345335550cd36c")
