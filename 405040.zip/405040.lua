-- Lua provided by RyzenAPI
-- Game: Game: AppID 405040

-- MAIN APPLICATION
addappid(405040)
-- Game: addappid(405040)

-- MAIN APP DEPOTS / PACKAGES
addappid(405041, 1, "56b45d0032b2d6aaf5a02473b33ce0b7b148b10e752f3ec17c065442951c3565")
