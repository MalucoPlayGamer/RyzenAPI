-- Lua provided by RyzenAPI
-- Game: The Dark Side

-- MAIN APPLICATION
addappid(1017880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017881, 1, "4ea908f349005aa45e1dbdf97b4ccb3c62c3cc24a1b8cdf14ff8ac5963c23fd1")

