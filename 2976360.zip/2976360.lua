-- Lua provided by RyzenAPI
-- Game: 2976360

-- MAIN APPLICATION
addappid(2976360)
-- Game: addappid(2976360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976361, 1, "001c0232380eab1fddf287c6eb9754ce9a1bac0d1e4948f160ee698101fa2d42")
