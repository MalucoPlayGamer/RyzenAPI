-- Lua provided by RyzenAPI 
-- Game: Goobies
addappid(2294130)
addappid(2294131, 1, "c658de3969a26fe6db9c1298e8b19da59aeeddd3112c53ad144cd4b685e1c6e0")
