-- Lua provided by RyzenAPI 
-- Game: FIGHTING GIRL SAKURA-R
addappid(2013060)
addappid(2013061, 1, "9a46acb239c565e04080575e871594f9723c72811d74c00816320dabecd772d6")
