-- Lua provided by RyzenAPI
-- Game: Choice of the Vampire: The Fall of Memphis

-- MAIN APPLICATION
addappid(776020)

-- MAIN APP DEPOTS / PACKAGES
addappid(776021, 1, "5eeeec1b46848935cc90a15a855d31dd137fa9fcb1c0ea47c53cece52fa1cf59")

