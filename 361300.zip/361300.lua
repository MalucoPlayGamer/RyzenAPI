-- Lua provided by RyzenAPI
-- Game: Game: Mother Russia Bleeds

-- MAIN APPLICATION
addappid(361300)
-- Game: addappid(361300)

-- MAIN APP DEPOTS / PACKAGES
addappid(361301, 1, "24e1c2017dffdb7bea03edf672074ab2a2772e9667beb0e847e0684ee71d2c6c")
addappid(361302, 1, "f4f93ac409ed28d69807e16c229b56f71db3e2fe772ca98a7b401d93853e407a")
addappid(361303, 1, "52f85adbb7ebfc551b9083066160256e04cd5e0ef43a6d2e582b3fd5f4dc9214")
addappid(361304, 1, "e7b5ae96de6f3e4ba223f374a92018b9ef295cf67b26417516ec536fc52c271e")
addappid(361305, 1, "fe56a2da7bcba672e29d4c20503f23c3000a8633310628d198b4194c204146ed")
addappid(361306, 1, "d4f304db32ff0dfd5919d53f0fa8900ff7ce5c0540be813fae9b16436dde5b56")
