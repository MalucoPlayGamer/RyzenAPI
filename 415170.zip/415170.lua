-- Lua provided by RyzenAPI
-- Game: Engare

-- MAIN APPLICATION
addappid(415170)

-- MAIN APP DEPOTS / PACKAGES
addappid(415171, 1, "c2efe33f49d2788af78961a99d50a2899710e23e4fca0ded9a7d155be65f0959")
addappid(415172, 1, "b6bab9c8741b4fde189e602adae1074db8d52bb9ce13dcda392c3737279fb4d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
