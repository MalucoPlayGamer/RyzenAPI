-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Faroe Islands XP

-- MAIN APPLICATION
addappid(2436890)
-- Game: addappid(2436890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436890,0,"03aded20b3dec79881a1a5b0e3e6d449c97012823a09f28b0d29649ccf8f9061")
