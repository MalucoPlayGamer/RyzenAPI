-- Lua provided by RyzenAPI
-- Game: Tetra Dungeon

-- MAIN APPLICATION
addappid(2933930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933931, 1, "a03b3b221d554420bf5d3951e276537ea1aea037c70d01e6466cb8b5913300dd")
