-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Kassel

-- MAIN APPLICATION
addappid(2969860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969860,0,"b4bdda6665a5de020b87e6da718719e64d9420c29e55dbea0822756080cddd25")

