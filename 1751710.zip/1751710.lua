-- Lua provided by RyzenAPI
-- Game: Horror Stories: PLEASE COMPLY

-- MAIN APPLICATION
addappid(1751710)
-- Game: addappid(1751710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751711, 1, "af36e3bd4452d2e9356683f97a841f2d3613d4741ea9ad069d55ea069e93356d")
