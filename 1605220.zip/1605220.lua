-- Lua provided by RyzenAPI
-- Game: Dune: Spice Wars

-- MAIN APPLICATION
addappid(1605220)
addappid(2807090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1605221, 1, "d9b810744ceded0de8e527039bd842c9931c76da38fb1683230642fd71842411")

