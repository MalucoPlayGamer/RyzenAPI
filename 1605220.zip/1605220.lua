-- Lua provided by RyzenAPI 
-- Game: Dune: Spice Wars
addappid(1605220)
addappid(1605221, 1, "d9b810744ceded0de8e527039bd842c9931c76da38fb1683230642fd71842411")
addappid(2807090)
