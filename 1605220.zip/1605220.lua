-- Lua provided by RyzenAPI
-- Game: Game: Dune: Spice Wars

-- MAIN APPLICATION
addappid(1605220)
addappid(2807090)
-- Game: addappid(1605220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605221, 1, "d9b810744ceded0de8e527039bd842c9931c76da38fb1683230642fd71842411")
