-- Lua provided by RyzenAPI
-- Game: shapez 2 Demo

-- MAIN APPLICATION
addappid(2642190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642191, 1, "f05ad4d82f2f3af218bdfbb477347ac2f0b34bc70e873ae87cdea956d7e610a5")
