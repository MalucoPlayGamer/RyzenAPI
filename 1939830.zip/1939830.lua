-- Lua provided by RyzenAPI
-- Game: addappid(1939830)

-- MAIN APPLICATION
addappid(1939830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939830,0,"dd0ee5d8c3621dff66d866a4fb8d3460263bcd852867bafea755c6e23cb325eb")
