-- Lua provided by RyzenAPI
-- Game: addappid(2188690)

-- MAIN APPLICATION
addappid(2188690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188691, 1, "2681287afa0e69efd77d437827d6ea7b79fa1e7b4789f5802f127008fd5f350f")
