-- Lua provided by RyzenAPI 
-- Game: AppID 865090
addappid(865090)
addappid(865091, 1, "f833c861d84ceb06e0c3d759c13db51100632a6e818137ca1f8722ed8ab7f9e1")
addappid(865092, 1, "e5327eee27f04004ee6186ef708db858c603380887e77b229f015da8293ef10c")
