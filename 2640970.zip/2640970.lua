-- Lua provided by RyzenAPI
-- Game: Game: AppID 2640970

-- MAIN APPLICATION
addappid(2640970)
-- Game: addappid(2640970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2640971, 1, "18538e8352c0e10649eb718bf0a5887e42db2ae2726c637c0af9c9528fd017c1")
