-- Lua provided by RyzenAPI
-- Game: Super Crush KO

-- MAIN APPLICATION
addappid(907670)

-- MAIN APP DEPOTS / PACKAGES
addappid(907671, 1, "68be1b606d771d94f28a6f1c523ebd69b71ad6f94db725a9250643aeedebb465")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
