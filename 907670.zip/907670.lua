-- Lua provided by RyzenAPI
-- Game: Super Crush KO

-- MAIN APPLICATION
addappid(907670)
-- Game: addappid(907670)

-- MAIN APP DEPOTS / PACKAGES
addappid(907671, 1, "68be1b606d771d94f28a6f1c523ebd69b71ad6f94db725a9250643aeedebb465")
