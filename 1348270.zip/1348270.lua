-- Lua provided by RyzenAPI
-- Game: Game: Fingers: Mini Games

-- MAIN APPLICATION
addappid(1348270)
-- Game: addappid(1348270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348271, 1, "e118cf34ddf20e1540bb7a3048c27a9260f39ecc3c9b52b96c651fa5da71db1e")
