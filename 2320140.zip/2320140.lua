-- Lua provided by RyzenAPI
-- Game: AppID 2320140

-- MAIN APPLICATION
addappid(2320140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320141, 1, "798e0b6c2d3a3ee1dba7bc7a8cad9a4834209b1fd5d1def8c54183b8cda5a3cc")

