-- Lua provided by RyzenAPI
-- Game: Dark Mystery

-- MAIN APPLICATION
addappid(660900)

-- MAIN APP DEPOTS / PACKAGES
addappid(660901,0,"d70e1f768369dbe610b2aa97a4a58b9e017e5dfa2e1ab80d43e98ba8e10031ad")

