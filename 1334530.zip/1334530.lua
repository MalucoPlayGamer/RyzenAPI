-- Lua provided by RyzenAPI
-- Game: Game: I AM FLY

-- MAIN APPLICATION
addappid(1334530)
-- Game: addappid(1334530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334531, 1, "2190dcf227db74d32289ae66ad36da497563c173ad42c8e11da37da67495821d")
