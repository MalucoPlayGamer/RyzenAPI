-- Lua provided by RyzenAPI
-- Game: I AM FLY

-- MAIN APPLICATION
addappid(1334530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1334531, 1, "2190dcf227db74d32289ae66ad36da497563c173ad42c8e11da37da67495821d")

