-- Lua provided by RyzenAPI
-- Game: 1818240

-- MAIN APPLICATION
addappid(1818240)
-- Game: addappid(1818240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818241, 1, "cc2bcd8e6cfefc094625b857f889740123c9979346fc7ebaaa5453a462e71a5d")
addappid(1819270, 0, "b1115f23795467fe2ae0dbf4274431151b8bf78e1e9c50a9cc5e7b7d34bbf3bb")
