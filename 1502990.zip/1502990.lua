-- Lua provided by RyzenAPI
-- Game: Atelier Lydie & Suelle: The Alchemists and the Mysterious Paintings DX

-- MAIN APPLICATION
addappid(1502990)
-- Game: addappid(1502990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502991, 1, "095618c3403fac4b9907ce99a1380673ea6c5ccb969a3c44a23c4328ec5b1b7d")
