-- Lua provided by RyzenAPI
-- Game: Atelier Lydie & Suelle: The Alchemists and the Mysterious Paintings DX

-- MAIN APPLICATION
addappid(1502990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1502991, 1, "095618c3403fac4b9907ce99a1380673ea6c5ccb969a3c44a23c4328ec5b1b7d")

