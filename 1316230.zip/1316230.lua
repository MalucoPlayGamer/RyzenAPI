-- Lua provided by RyzenAPI
-- Game: Force of Nature 2: Ghost Keeper

-- MAIN APPLICATION
addappid(1316230)
-- Game: addappid(1316230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316231, 1, "ce3246d908215d22d0f2e8257a640bda867b07ebe9f233b9fc9827fc777af452")
addappid(2247910, 0, "22c5586e35a24cc20af0959e410fbe3e1e72e422d2cf2456d585a6738c6b7f96")
