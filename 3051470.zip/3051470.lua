-- Lua provided by RyzenAPI
-- Game: 3051470

-- MAIN APPLICATION
addappid(3051470)
-- Game: addappid(3051470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051471, 1, "fd82a12824aaa017fd9f9df79a69c912499fcb6030c97006df6481e8eecd7432")
