-- Lua provided by RyzenAPI
-- Game: Game: Fowl Magic

-- MAIN APPLICATION
addappid(1137860)
-- Game: addappid(1137860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137861, 1, "45e0f71ab7fdcc86cd1627085f7667b849a698f571d7e2968069ea8b79124dc1")
