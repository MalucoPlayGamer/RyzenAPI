-- Lua provided by RyzenAPI
-- Game: Fowl Magic

-- MAIN APPLICATION
addappid(1137860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1137861, 1, "45e0f71ab7fdcc86cd1627085f7667b849a698f571d7e2968069ea8b79124dc1")

