-- Lua provided by RyzenAPI
-- Game: Not Another Dungeon?!

-- MAIN APPLICATION
addappid(1739100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739101, 1, "2a54449bd8346ed489159286a73e240569bcf23ec9db4ed72956911e9be42997")

