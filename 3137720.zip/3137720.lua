-- Lua provided by RyzenAPI
-- Game: addappid(3137720)

-- MAIN APPLICATION
addappid(3137720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137721, 1, "99ca77a79de0e2ee5fc084025fde9d6fec734bfdd6db12ea67c42bc18a1b8c40")
