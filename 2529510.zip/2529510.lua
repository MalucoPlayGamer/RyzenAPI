-- Lua provided by RyzenAPI
-- Game: Fish on the desktop

-- MAIN APPLICATION
addappid(2529510)
addappid(2529511)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529512,0,"021a751b01e6b8509c6c4e535fe77b140790056c5439cb7cccdfb60b08a05927")

