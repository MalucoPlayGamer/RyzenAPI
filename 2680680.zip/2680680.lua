-- Lua provided by RyzenAPI 
-- Game: outside the door
addappid(2680680)
addappid(2680681, 1, "69c46b6a5f275a69467eed9b919ddecb6e4705e46ae3bc52df18fb4ab9b4e58f")
