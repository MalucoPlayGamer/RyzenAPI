-- Lua provided by RyzenAPI
-- Game: addappid(2478020)

-- MAIN APPLICATION
addappid(2478020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478021, 1, "e5891d726e0a361ae37f4e15e16b500173a36f8409f9dc768ee9c57e469fe734")
