-- Lua provided by RyzenAPI
-- Game: Fallen King Demo

-- MAIN APPLICATION
addappid(2937880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937882,0,"3caf40add45ef6256cac33cc7ca746b0e624c1bc44a80f24c55b35696b665c20")

