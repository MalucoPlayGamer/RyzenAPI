-- Lua provided by RyzenAPI
-- Game: addappid(467350)

-- MAIN APPLICATION
addappid(467350)

-- MAIN APP DEPOTS / PACKAGES
addappid(467351, 1, "b3742c4119cb5e6466f55d83ba45dc71e403df089d746ac97c3960e70698d7f7")
