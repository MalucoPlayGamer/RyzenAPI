-- Lua provided by RyzenAPI
-- Game: Forklift Racer

-- MAIN APPLICATION
addappid(2443760)
-- Game: addappid(2443760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443763,0,"fe7a12f9f12af17542358aabe6e7a9ab37c338d650d3b01203522d646bb33dc5")
addappid(2443764,0,"7a9b487e86caeb0cf6bafb6a49aca08ecb3cca14d3c3a1ac4c4f8c318bd7e109")
