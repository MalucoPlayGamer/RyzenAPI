-- Lua provided by RyzenAPI
-- Game: P.A.I.N.T.

-- MAIN APPLICATION
addappid(1175890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1175891, 1, "b5a5a27bb769b549c00fec8005d82273eba7e86536da0f0024d0107f8ae2e3e8")

