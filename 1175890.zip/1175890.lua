-- Lua provided by RyzenAPI
-- Game: 1175890

-- MAIN APPLICATION
addappid(1175890)
-- Game: addappid(1175890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175891, 1, "b5a5a27bb769b549c00fec8005d82273eba7e86536da0f0024d0107f8ae2e3e8")
