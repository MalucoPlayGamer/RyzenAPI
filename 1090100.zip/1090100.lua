-- Lua provided by RyzenAPI
-- Game: Game: AppID 1090100

-- MAIN APPLICATION
addappid(1090100)
-- Game: addappid(1090100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090101, 1, "11fcdad988033d5e31a0f621f7449ac0b351dd7674e31714f84941279adc3298")
addappid(1090102, 1, "2c3d687ed6a7f107a8265b02cbb4fa6092ed50dd94fae1e4617eb37c02f6a870")
