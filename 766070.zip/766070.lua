-- Lua provided by RyzenAPI
-- Game: Apperception

-- MAIN APPLICATION
addappid(766070)

-- MAIN APP DEPOTS / PACKAGES
addappid(766071,0,"cd9bc3801f486e80a50b02e6acb46187bf372a56750059ad1a94441386be2072")

