-- Lua provided by SkyAPI 
-- Game: Dark Hours Demo
addappid(2297070)
addappid(2297071, 1, "95a44fb9d3f6097b6d86dc0adc31d7aa01006c6fab7fd4c175eb03fc4eab6f0c")
