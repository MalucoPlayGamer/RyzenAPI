-- Lua provided by SkyAPI 
-- Game: AppID 2366880
addappid(2366880)
addappid(2366881, 1, "2593d379b855494ca9e04b68552524159491a2bc47c40ff357f3d3556b5bae38")
