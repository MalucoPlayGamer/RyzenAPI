-- Lua provided by RyzenAPI
-- Game: Last Train Outta' Wormtown Friend's Pass

-- MAIN APPLICATION
addappid(2366880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366881, 1, "2593d379b855494ca9e04b68552524159491a2bc47c40ff357f3d3556b5bae38")

