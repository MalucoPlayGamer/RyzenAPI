-- Lua provided by SkyAPI 
-- Game: AppID 291210
addappid(291210)
addappid(291211, 1, "98a80965be5790d00f37872f233ca9c56eff81af441ca3d206d3b0e3f06f61d3")
addappid(291212, 1, "617d45fc5204add058f8be07824b2fa663c4e9696243031f93382d5a5cd0bc4a")
