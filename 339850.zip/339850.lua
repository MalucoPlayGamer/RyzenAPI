-- Lua provided by RyzenAPI
-- Game: Overclocked: A History of Violence

-- MAIN APPLICATION
addappid(339850)

-- MAIN APP DEPOTS / PACKAGES
addappid(339851, 1, "94daea9ada0592dd38c2a5137c5bfbac331b18015e19119b31d89dab9e0296f5")
addappid(339852, 1, "2a012cc75c8bc8f5da4588b37b4a0caa88bf06c603733c53fd7759757ec6782e")
addappid(339853, 1, "57c8c2f645230be9a08903b1baef4eae587a97299ec171544aa7f290bb22ca37")
addappid(339854, 1, "5d8e3bc9ede070938e4a7b511f99a6babfe05da862c9b53fc4fb79f15c0a079a")
addappid(339855, 1, "56f75f7bfd5ab1036a716cccd321392898b4def83b01fe7b63d5e2dfc49064ec")
addappid(339856, 1, "ef674c46f1a1af5b60c97672f0df61037519d13ee6986d2dff0fb567199ffa1a")
addappid(339857, 1, "0a977d1594775b93a111685b9ddd11950bfa48468aa6098e0971274dc7c39ab6")
addappid(339858, 1, "be4d2e3752f6ce85d871fda28cfb9da92d31c0d754a384c64989f33542f01a23")
