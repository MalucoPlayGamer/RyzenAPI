-- Lua provided by RyzenAPI
-- Game: Grim Clicker

-- MAIN APPLICATION
addappid(1160750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160751, 1, "110d746a854a24d9f5bf6d2b05056a5b5439e02b1c4667341271540ffcc125c7")
