-- Lua provided by SkyAPI 
-- Game: AppID 1160750
addappid(1160750)
addappid(1160751, 1, "110d746a854a24d9f5bf6d2b05056a5b5439e02b1c4667341271540ffcc125c7")
