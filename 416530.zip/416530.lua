-- Lua provided by RyzenAPI
-- Game: Tacopocalypse

-- MAIN APPLICATION
addappid(416530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(416531, 1, "04d3b49382833c2e5401eb7c2805ed8e0c0e67109add88c64b99e2d55d0221d2")

