-- Lua provided by RyzenAPI
-- Game: 416530

-- MAIN APPLICATION
addappid(416530)
-- Game: addappid(416530)

-- MAIN APP DEPOTS / PACKAGES
addappid(416531, 1, "04d3b49382833c2e5401eb7c2805ed8e0c0e67109add88c64b99e2d55d0221d2")
