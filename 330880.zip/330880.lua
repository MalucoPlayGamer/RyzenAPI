-- Lua provided by RyzenAPI
-- Game: Redemption

-- MAIN APPLICATION
addappid(330880)

-- MAIN APP DEPOTS / PACKAGES
addappid(330881, 1, "fa0ef71b80889b554d7e614a0e6b2bbf536e0a0a7a1c9f5dd4f57a2975baaa33")
