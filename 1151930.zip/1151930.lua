-- Lua provided by RyzenAPI
-- Game: addappid(1151930)

-- MAIN APPLICATION
addappid(1151930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151931, 1, "812f1a485bd24855baa9de169916b561dafd22c6a65f24d13ad6df2eb0bd8805")
