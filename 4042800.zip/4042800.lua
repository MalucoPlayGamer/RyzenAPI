-- Lua provided by RyzenAPI
-- Game: Poker Fate - Anime Girls Texas Hold'em

-- MAIN APPLICATION
addappid(4042800)
