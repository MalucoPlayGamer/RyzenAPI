-- Lua provided by RyzenAPI
-- Game: AppID 1127070

-- MAIN APPLICATION
addappid(1127070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127071, 1, "940ead0ceceeee03c903381151e9df9e3039c840596a51ccd6f27bf033455cc8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1142250)
