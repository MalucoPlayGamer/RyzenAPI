-- Lua provided by RyzenAPI
-- Game: 1127070

-- MAIN APPLICATION
addappid(1127070)
-- Game: addappid(1127070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127071, 1, "940ead0ceceeee03c903381151e9df9e3039c840596a51ccd6f27bf033455cc8")
