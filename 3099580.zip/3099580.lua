-- Lua provided by RyzenAPI
-- Game: You see me?

-- MAIN APPLICATION
addappid(3099580)
-- Game: addappid(3099580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099581, 1, "0e2e9ccff0ed9284c624f9e589c1611fcc0d4d9d8edbc46abe7843013afdb4f5")
