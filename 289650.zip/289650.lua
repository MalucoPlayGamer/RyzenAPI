-- Lua provided by RyzenAPI
-- Game: Assassin's Creed® Unity

-- MAIN APPLICATION
addappid(289650)
addappid(324330)
addappid(324331)
addappid(324332)
addappid(330960)
addappid(330961)
addappid(330970)
addappid(330980)
addappid(330981)
addappid(330982)
addappid(330983)
addappid(330984)
addappid(330985)
addappid(330986)
addappid(330987)
addappid(330988)
addappid(331950)
addappid(344600)
-- Game: addappid(289650)

-- MAIN APP DEPOTS / PACKAGES
addappid(289651, 1, "8f869005c44f493f984aa111e49e96c4f64e69a4b4078cbfff77f01ce5bb7b8e")
addappid(289652, 1, "dd7b22e30a71132cc09a5e75b0d8b326d5a0716911cb3b63f6f656fafe0ddad1")
addappid(289653, 1, "8aa4b40cbc6dc05229d0cdd4f7fc19f1e5b0cebe991d6db3fec2f3ffb906d700")
addappid(324333, 0, "9b07cb83c48f76dd01431636c4dcfed721bbf6d70141900658c6ff573ac15d3c")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
