-- Lua provided by RyzenAPI
-- Game: 1310470

-- MAIN APPLICATION
addappid(1310470)
-- Game: addappid(1310470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310471, 1, "d1e62e22f86f1df8bb1f9061a61b4e4df0920a4bb67b1df7fdd5e768039faec4")
