-- Lua provided by RyzenAPI
-- Game: addappid(2124230)

-- MAIN APPLICATION
addappid(2124230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124230,0,"4b80be5096b6088d0a3195af55d07afa32ea1a6d6bba1eca2ad10d2d5e27a061")
