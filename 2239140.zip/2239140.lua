-- Lua provided by RyzenAPI
-- Game: 2239140

-- MAIN APPLICATION
addappid(2239140)
-- Game: addappid(2239140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239141, 1, "ce7a2abe51105acda36d9f11d13c06a7cbfc2cbf96367d9d552bfcf179c49732")
