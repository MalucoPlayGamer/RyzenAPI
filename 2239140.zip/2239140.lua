-- Lua provided by RyzenAPI
-- Game: Grapples Galore

-- MAIN APPLICATION
addappid(2239140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239141, 1, "ce7a2abe51105acda36d9f11d13c06a7cbfc2cbf96367d9d552bfcf179c49732")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2618870)
addappid(2889720)
addappid(2889730)
addappid(3394960)
addappid(3394970)
