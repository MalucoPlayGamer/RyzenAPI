-- 4240180's Lua and Manifest Created by Hubcap Manifest
-- Blackhole Survivors
-- Created: June 12, 2026 at 06:12:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4240180) -- Blackhole Survivors
-- MAIN APP DEPOTS
addappid(4240181, 1, "6b944c558a3500cd45161b45752800587d87a06413ae1cae7d3bd657d6011ba0") -- Depot 4240181
-- setManifestid(4240181, "3498533284943517506", 273070295)