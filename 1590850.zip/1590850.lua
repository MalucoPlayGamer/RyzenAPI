-- Lua provided by RyzenAPI 
-- Game: AppID 1590850
addappid(1590850)
addappid(1590851, 1, "90abaa1ddd415b0c7533e726b4291b86620372245dac0154049e3d666af646bf")
