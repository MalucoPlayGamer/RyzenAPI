-- Lua provided by RyzenAPI
-- Game: AppID 899220

-- MAIN APPLICATION
addappid(899220)

-- MAIN APP DEPOTS / PACKAGES
addappid(899221, 1, "0ce69e9649f5ca81e8a4b0287403a7664510589d5d755de17bb887afd57df5eb")
addappid(899222, 1, "9c15239d4c1b466e4b7e892255c6ddcb7c533d37aa0ec5d473a3bad48ab75100")
addappid(899223, 1, "35db8c555147da43af998e0c842f7ad1b00144d5e5a5bc841f0a67538f9404bd")
addappid(899224, 1, "0769a56029ecb7d8df482bc5a13450f5469303eae43807cc6333663bba245663")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
