-- Lua provided by RyzenAPI
-- Game: addappid(3412930)

-- MAIN APPLICATION
addappid(3412930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3412930,0,"d21626c6d9455d907d3d410d20277730fec3caa841263736e1b573fac48b6dea")
