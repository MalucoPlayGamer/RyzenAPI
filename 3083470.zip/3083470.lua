-- Lua provided by RyzenAPI
-- Game: addappid(3083470)

-- MAIN APPLICATION
addappid(3083470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3083471, 1, "bddba07cd7d4c587cd6d12780688943425ef36692efa4d30ca515341b2a69a6a")
