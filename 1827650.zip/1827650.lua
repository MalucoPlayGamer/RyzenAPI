-- Lua provided by RyzenAPI 
-- Game: Star Knightess Aura
addappid(1827650)
addappid(1827651, 1, "752f7c0d9215a9159ed02438960e5cee3180c2fe14dbfc58d8e8091de8913da2")
