-- Lua provided by RyzenAPI
-- Game: addappid(1827650)

-- MAIN APPLICATION
addappid(1827650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827651, 1, "752f7c0d9215a9159ed02438960e5cee3180c2fe14dbfc58d8e8091de8913da2")
