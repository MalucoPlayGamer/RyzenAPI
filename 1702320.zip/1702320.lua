-- Lua provided by SkyAPI 
-- Game: AppID 1702320
addappid(1702320)
addappid(1702321, 1, "4d32c6ad44eb68b14212413edae66f457e1b955a216da7d2820e0a9e3714c580")
