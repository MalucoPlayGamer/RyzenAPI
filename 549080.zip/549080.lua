-- Lua provided by RyzenAPI
-- Game: AppID 549080

-- MAIN APPLICATION
addappid(549080)

-- MAIN APP DEPOTS / PACKAGES
addappid(549081, 1, "d586b3bab22c76962b68e26c52319f621efd3d58a8dbd030fb62b04fa38820d9")
addappid(549082, 1, "be595c28e515d9139a4cf61329df14e86e37f22cd86798cf051f748e911747cb")
addappid(603760, 0, "9ed3b6475823dad0d65f83030af6de2b997f56b8e16a2bda5967b48458c4d317")
addappid(616370, 0, "8e4f524072abff6fd694c0c58a1040569d23a4deb216e27b78789d8ca7562928")
addappid(742790, 0, "44e88e5a60ab44589968eb143ad7c9ed36f8ae13f252a4fe322de8c956005c83")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(956070)
