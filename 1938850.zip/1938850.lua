-- Lua provided by RyzenAPI
-- Game: 1938850

-- MAIN APPLICATION
addappid(1938850)
-- Game: addappid(1938850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938851, 1, "3a0f19d61954c54cce7b59b4ea20e17fa429f5dae41be1c9fd63d90c93a00f69")
