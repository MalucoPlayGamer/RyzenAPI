-- Lua provided by RyzenAPI
-- Game: OPUS: Echo of Starsong Official Game Script -Vol.2-

-- MAIN APPLICATION
addappid(1874890)
-- Game: addappid(1874890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874891, 1, "b70f7cba52c9c62904bdfe5304df801eed09f1472d0265086d4864d5e940a0d5")
