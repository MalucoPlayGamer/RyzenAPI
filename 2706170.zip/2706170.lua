-- Lua provided by RyzenAPI
-- Game: Get To Work

-- MAIN APPLICATION
addappid(2706170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706171, 1, "8bac962c79191db607320de0e50e8a4e2ecbe0ae551d23c1c869c3dd541ad093")

