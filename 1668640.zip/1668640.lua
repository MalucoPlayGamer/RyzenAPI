-- Lua provided by RyzenAPI
-- Game: Rings of Hell

-- MAIN APPLICATION
addappid(1668640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668641, 1, "7b89420e2bbfb5e969f391d517bf93f0809c26fdc62a675757e33c87925823e3")
