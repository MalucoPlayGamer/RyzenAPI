-- Lua provided by RyzenAPI
-- Game: Rings of Hell

-- MAIN APPLICATION
addappid(1668640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1668641, 1, "7b89420e2bbfb5e969f391d517bf93f0809c26fdc62a675757e33c87925823e3")

