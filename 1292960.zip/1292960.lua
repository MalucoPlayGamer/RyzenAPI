-- Lua provided by RyzenAPI
-- Game: addappid(1292960)

-- MAIN APPLICATION
addappid(1292960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292961, 1, "e6a52ba753ed34db6cab8a3785a9bfd0ced3c961ade3e703f5295c29af52eca8")
