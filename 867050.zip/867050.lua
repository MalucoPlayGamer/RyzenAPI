-- Lua provided by RyzenAPI
-- Game: Endless Fables 3: Dark Moor

-- MAIN APPLICATION
addappid(867050)

-- MAIN APP DEPOTS / PACKAGES
addappid(867051,0,"0d42e19d41edaa480eb41a258fa420ef4879c426988cab6c87a2818d4452f3ae")
addappid(867052,0,"b8b200cdaff93ae642d32b247caff946d5e880f2c88d18a8a54e23a13dce4f8b")
addappid(867053,0,"819dd78932ae45e1f2c5f3190042f4a08e04dcb54ba8938876166cce66810cb9")

