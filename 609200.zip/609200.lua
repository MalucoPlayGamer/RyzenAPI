-- Lua provided by RyzenAPI
-- Game: addappid(609200)

-- MAIN APPLICATION
addappid(609200)

-- MAIN APP DEPOTS / PACKAGES
addappid(609200,0,"342e3cecbf3b02363fee1d82c02e0de5111fa14896b6ff31326ad4f3f8a3c220")
