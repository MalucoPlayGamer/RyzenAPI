-- Lua provided by RyzenAPI
-- Game: Slap The Fly

-- MAIN APPLICATION
addappid(543030)
-- Game: addappid(543030)

-- MAIN APP DEPOTS / PACKAGES
addappid(543031, 1, "8b4a2f68f0df6b1ff1337011640697cc9dcd754166f16df55c771fa40f99a283")
