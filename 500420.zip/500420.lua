-- Lua provided by RyzenAPI
-- Game: setManifestid(500422,"3124400624474136704")

-- MAIN APPLICATION
addappid(500420)
-- Game: addappid(500420)

-- MAIN APP DEPOTS / PACKAGES
addappid(500422,0,"8afcbacd98ebbf6dc046a9aa58a23db33893d2b3b234a57d6527be53c9d2b1a3")
