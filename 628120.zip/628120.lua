-- Lua provided by RyzenAPI
-- Game: 628120

-- MAIN APPLICATION
addappid(628120)
-- Game: addappid(628120)

-- MAIN APP DEPOTS / PACKAGES
addappid(628121, 1, "dfa1d64337919b2a86255f5fe61305f88f600e0cfa16ada5cf19414010f9019c")
