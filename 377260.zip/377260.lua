-- Lua provided by RyzenAPI
-- Game: Unearned Bounty

-- MAIN APPLICATION
addappid(377260)
-- Game: addappid(377260)

-- MAIN APP DEPOTS / PACKAGES
addappid(377261, 1, "b5fcc54d27e9fda1b8e7220bde7437103518dd0f373675daf1caf31245a44128")
addappid(377262, 1, "b8dfbe34a43c18ec1eb3163a62f23df2c81bc44841d5ae16c45a7c983c02bba8")
addappid(377263, 1, "f9c991f9f2fd9546302adad3d893a6297059decedb3a8c13a9b575eee127e7c8")
addappid(377264, 1, "0f2f66ab9ba1348171f7e58cd6eb5245a9a610120afd0e5a6c86fa76e499ba2e")
addappid(377265, 1, "fb139e6e62c7f40c8d018df776006ce27920dd0cb1782df0956a0623668fee15")
addappid(377266, 1, "b3b9d188cf5fbc795619d4e416502d7da16695ad1702355dd88090d36cb1023e")
