-- Lua provided by RyzenAPI
-- Game: Night Stones Soundtrack

-- MAIN APPLICATION
addappid(3339580)
-- Game: addappid(3339580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339581, 1, "9963f6529c6738374a7bba8459090f6a16b0347fdb8ab2fe90d8ac5c7f03c3d6")
addappid(3339582, 1, "0cce80285c3c7244b782c3b89b0297d545e49c203065dbd64f995354cbedbf6a")
