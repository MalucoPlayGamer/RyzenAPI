-- Lua provided by RyzenAPI
-- Game: Roots of Pacha

-- MAIN APPLICATION
addappid(1245560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245561, 1, "c59e4ebf3c234a8d58ca8569203cad83878d158791cc5d9c608d9f09edbd5630")
addappid(1245562, 1, "4b2a3974fbef0a05951bdfa793a75ca8569648a6f235c4ea6419885106c05bb4")
addappid(1245563, 1, "9fad175a5cb3291efb893857c0f91c280075e6941f2e0cb44e9bcbff701c5a5d")

