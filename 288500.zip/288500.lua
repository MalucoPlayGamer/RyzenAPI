-- Lua provided by RyzenAPI
-- Game: Game: AppID 288500

-- MAIN APPLICATION
addappid(288500)
-- Game: addappid(288500)

-- MAIN APP DEPOTS / PACKAGES
addappid(288501, 1, "e76ac465ca3804da8685e9fa51b2864901916bc5361071bd7e26debe4dab9509")
addappid(288502, 1, "daa338219c1d0f4f07b516b33a4f2ab8fc66cb6e3019a5003c134c3bc45dc068")
addappid(288503, 1, "c96a83afb96f9bd07d55736ade0fba244afbe26028b5b55619547426b61260ce")
