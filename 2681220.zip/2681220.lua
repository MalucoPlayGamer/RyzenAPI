-- Lua provided by RyzenAPI
-- Game: 2681220

-- MAIN APPLICATION
addappid(2681220)
-- Game: addappid(2681220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681221, 1, "d6156bd1b802fd0086e20b71aef1a597d262cdb3432b0c2b9f80899ea56b7328")
