-- Lua provided by RyzenAPI
-- Game: Game: AppID 867270

-- MAIN APPLICATION
addappid(867270)
-- Game: addappid(867270)

-- MAIN APP DEPOTS / PACKAGES
addappid(867271, 1, "bbd8f68d8419983ad36f96e3364760749290a8ae46a75ca83440588286bb872a")
