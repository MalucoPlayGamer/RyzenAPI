-- Lua provided by RyzenAPI
-- Game: 恶魔的房间 The Demon's Room

-- MAIN APPLICATION
addappid(3434330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3434331, 1, "33e44d9333504275fafef888a4d960e2172a94a490e0f587a91b6fb7dbdb6e1f")

