-- Lua provided by RyzenAPI
-- Game: addappid(1726400)

-- MAIN APPLICATION
addappid(1726400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726401, 1, "3fdb4b14b3fd232cb7e5b7484cc086e3177950022cdf2f156044e7b62fc817f5")
addappid(1726402, 1, "0167a0b3ac9dbf3d4012dde9ca8c3a8fa63b6cd43aad720d520c9af4c3b345ab")
