-- Lua provided by RyzenAPI
-- Game: The Death | Thần Trùng

-- MAIN APPLICATION
addappid(1726400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726401, 1, "3fdb4b14b3fd232cb7e5b7484cc086e3177950022cdf2f156044e7b62fc817f5")
addappid(1726402, 1, "0167a0b3ac9dbf3d4012dde9ca8c3a8fa63b6cd43aad720d520c9af4c3b345ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
