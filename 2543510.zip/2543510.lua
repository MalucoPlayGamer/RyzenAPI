-- Lua provided by RyzenAPI
-- Game: GUNTOUCHABLES

-- MAIN APPLICATION
addappid(2543510)
addappid(3768260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2543511, 1, "8b67a8f11996c561c14877de7602aa8a0e99f85db0205f10f24a973da70ae82e")

