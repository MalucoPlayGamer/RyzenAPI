-- Lua provided by RyzenAPI
-- Game: addappid(2543510)

-- MAIN APPLICATION
addappid(2543510)
addappid(3768260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543511, 1, "8b67a8f11996c561c14877de7602aa8a0e99f85db0205f10f24a973da70ae82e")
