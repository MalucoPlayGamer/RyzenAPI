-- Lua provided by RyzenAPI
-- Game: Farm Frenzy 3

-- MAIN APPLICATION
addappid(38150)

-- MAIN APP DEPOTS / PACKAGES
addappid(38151, 1, "93a40b4dd43dd38d80f106b019ad04e7aa385b846d9cfd12233cedb459e37a9f")
