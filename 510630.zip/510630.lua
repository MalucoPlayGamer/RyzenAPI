-- Lua provided by RyzenAPI
-- Game: Game: AppID 510630

-- MAIN APPLICATION
addappid(510630)
-- Game: addappid(510630)

-- MAIN APP DEPOTS / PACKAGES
addappid(510631, 1, "c959d41fb6c495529b472fdc76d0196eac8e70087c9d92e88f0ac5b7c51f329b")
addappid(510632, 1, "4ddc76e463299a598d22fff1393238950e3d7083fb2dd491b47d16a80d2944e2")
