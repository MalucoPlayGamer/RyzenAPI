-- Lua provided by RyzenAPI
-- Game: Game: World Ship Simulator

-- MAIN APPLICATION
addappid(403980)
-- Game: addappid(403980)

-- MAIN APP DEPOTS / PACKAGES
addappid(403981, 1, "958612c1b3e13655f43f3b3e93004bdb1f7a876716961111a0eb6a44a9ebf6c1")
addappid(403982, 1, "3d98a8d6303efbd6a148fe12bb6bead57b2de859c4da5a265c83f1ca30d51358")
