-- Lua provided by RyzenAPI
-- Game: World Ship Simulator

-- MAIN APPLICATION
addappid(403980)

-- MAIN APP DEPOTS / PACKAGES
addappid(403981, 1, "958612c1b3e13655f43f3b3e93004bdb1f7a876716961111a0eb6a44a9ebf6c1")
addappid(403982, 1, "3d98a8d6303efbd6a148fe12bb6bead57b2de859c4da5a265c83f1ca30d51358")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
