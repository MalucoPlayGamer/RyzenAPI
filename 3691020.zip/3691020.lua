-- Lua provided by RyzenAPI
-- Game: addappid(3691020)

-- MAIN APPLICATION
addappid(3691020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3691021, 1, "7d52b05fec5f1b0c7f58e5ffb5588ecf3f3f01853e8560d5eb3fe9a2d413be58")
