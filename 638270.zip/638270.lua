-- Lua provided by RyzenAPI
-- Game: Rite of Passage: Child of the Forest Collector's Edition

-- MAIN APPLICATION
addappid(638270)

-- MAIN APP DEPOTS / PACKAGES
addappid(638271,0,"fe87a41bd687fd3e2a1c35b35c851aab3c4ef674f9ef9732793c129cecbd04c3")

