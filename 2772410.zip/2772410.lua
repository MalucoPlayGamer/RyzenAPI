-- Lua provided by RyzenAPI
-- Game: addappid(2772410)

-- MAIN APPLICATION
addappid(2772410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772411, 1, "7b3bfd469e7e6cf07fc31eeb6c78d1f6c203a9a86627366b194eb2b6a4e0b78f")
