-- Lua provided by RyzenAPI
-- Game: GunSoul Girl

-- MAIN APPLICATION
addappid(1476520)
addappid(1547940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476521, 1, "54426e7807e9615968129aeab85214e54261d41761bc78ff3d348e23e25a28d2")

