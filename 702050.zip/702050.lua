-- Lua provided by RyzenAPI
-- Game: The Song of Saya

-- MAIN APPLICATION
addappid(702050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(702051, 1, "50e945a3ff5eb1c7d9767adb0480a08691bcd99c89d4f0c1a6a242eaba7830b3")
addappid(702052, 1, "0889c34892f364e5da0379ea0cfa35d218ebb00eea0b675c282eb66490459886")

