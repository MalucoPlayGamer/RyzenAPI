-- Lua provided by RyzenAPI
-- Game: addappid(1841640)

-- MAIN APPLICATION
addappid(1841640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841641, 1, "91b73585a4a038e7bc448c40dcdc6cc4f40bf05e8658cb25ad1ffab7fba646ae")
