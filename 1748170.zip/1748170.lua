-- Lua provided by RyzenAPI
-- Game: addappid(1748170)

-- MAIN APPLICATION
addappid(1748170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748171, 1, "8aec64c2b4332b1a7a91919477fd7f10ea4ed588caa591f25bc64791d7ddbf2b")
