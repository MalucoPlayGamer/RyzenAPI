-- Lua provided by RyzenAPI
-- Game: 1907590

-- MAIN APPLICATION
addappid(1907590)
-- Game: addappid(1907590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907591, 1, "7ce54200a077c566af9563fa8790bb79e947c9702bd3b210f5501b69fb9f9a29")
