-- Lua provided by RyzenAPI
-- Game: Battle Runner

-- MAIN APPLICATION
addappid(749040)

-- MAIN APP DEPOTS / PACKAGES
addappid(749041, 1, "d3d05cb9fd34e729eb494f8ec665fe635bfbe2405737f3226274c1df07aa387d")

