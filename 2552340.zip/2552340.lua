-- Lua provided by RyzenAPI
-- Game: TEMPEST : Tower of Probatio

-- MAIN APPLICATION
addappid(2552340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552341, 1, "6c9aae9a0990c20e21970a476f2abd90a392595616989e0686defa65249ebe9c")

