-- Lua provided by RyzenAPI
-- Game: 3401490

-- MAIN APPLICATION
addappid(3401490)
-- Game: addappid(3401490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3401491, 1, "b3318ae1c3e047f333c2fec2cfd1a7a185ffeb91baddf51527a2e025c0a1a744")
