-- Lua provided by RyzenAPI
-- Game: Shiina Taki's Decameron

-- MAIN APPLICATION
addappid(3269960)
