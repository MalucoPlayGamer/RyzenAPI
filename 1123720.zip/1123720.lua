-- Lua provided by RyzenAPI
-- Game: Heave Ho Party Demo

-- MAIN APPLICATION
addappid(1123720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123721, 1, "193f9993b7381ba5e463bec8e22e7e2c55815ee73dcf993afb9aa36fcc4add81")
