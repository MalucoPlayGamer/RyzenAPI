-- Lua provided by RyzenAPI 
-- Game: Legendary Eleven: Epic Football
addappid(839300)
addappid(839301, 1, "b7a42b847eac9dc504311854e5241de69d7eab52dd3e2804915eb277d332cd0c")
