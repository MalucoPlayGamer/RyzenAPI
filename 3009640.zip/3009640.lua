-- Lua provided by RyzenAPI 
-- Game: Sakura, The Jirai-kei Magical Girl
addappid(3009640)
addappid(3009641, 1, "42502aed5c953cec15df3cb201e428ce1aa7990916e1aa0b0b42396fb8c2a9a9")
