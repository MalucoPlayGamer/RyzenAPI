-- Lua provided by RyzenAPI
-- Game: Faaast Penguin

-- MAIN APPLICATION
addappid(2590150)
