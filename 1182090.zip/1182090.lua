-- Lua provided by RyzenAPI
-- Game: Mr. Pumpkin 2: Kowloon walled city

-- MAIN APPLICATION
addappid(1182090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182091, 1, "6b9066f66d78548ed27291d4940eb181ceba07e4f989a7bf5be80c1070b940e5")
addappid(1182092, 1, "ee63157b28c472803d4a7e9e715099f10190d5846c9295c148f0b1e6b955906e")

