-- Lua provided by RyzenAPI
-- Game: 1900260

-- MAIN APPLICATION
addappid(1900260)
-- Game: addappid(1900260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900261, 1, "54720e6a6130507aa79dcec7bd3d8dad7aa606cc33666313db065c5d1b7e12de")
