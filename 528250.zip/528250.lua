-- Lua provided by RyzenAPI
-- Game: Patchwork

-- MAIN APPLICATION
addappid(528250)
-- Game: addappid(528250)

-- MAIN APP DEPOTS / PACKAGES
addappid(528251, 1, "d154aa9116dd60aee0dc232476cc68939f9209ecb66996208ac33f6a264915a9")
addappid(528252, 1, "64864a75e4032892d4046c6a7714b84b6be70483cd6bfa6b4b5b96fdb135375d")
addappid(528253, 1, "3903f06ada078ecb502ce94ab1780addd7eb5d2113958b8a20bd5bae0934fc00")
addappid(528254, 1, "e0c2c7774ee16f63e677219b44f9f8f7f9bdadf7d033f1e69486e38e4629eab3")
