-- Lua provided by RyzenAPI
-- Game: 606180

-- MAIN APPLICATION
addappid(606180)
-- Game: addappid(606180)

-- MAIN APP DEPOTS / PACKAGES
addappid(606181, 1, "638cf2d4503e57c82d4f782410cfde6cc57be24b463c43851ec2f12433fcab32")
