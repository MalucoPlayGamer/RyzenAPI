-- Lua provided by RyzenAPI
-- Game: A Foreign World 🔞

-- MAIN APPLICATION
addappid(2174320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174321, 1, "8c1d78a91ea3c2c6ab6fe835a21e09610339b28fdc54d4de11ef1dc9df4c7032")
