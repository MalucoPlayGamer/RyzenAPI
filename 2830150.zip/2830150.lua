-- Lua provided by RyzenAPI
-- Game: Super Mining Mechs

-- MAIN APPLICATION
addappid(2830150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830151, 1, "076593271881557f1f284cc21257d7b52e9d4bf878c09a5dbcf21c015342c7ce")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3244780)
addappid(3379430)
