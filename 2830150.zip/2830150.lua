-- Lua provided by RyzenAPI
-- Game: Super Mining Mechs

-- MAIN APPLICATION
addappid(2830150)
-- Game: addappid(2830150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830151, 1, "076593271881557f1f284cc21257d7b52e9d4bf878c09a5dbcf21c015342c7ce")
