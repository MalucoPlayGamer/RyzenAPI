-- Lua provided by RyzenAPI
-- Game: Spaceship Looter

-- MAIN APPLICATION
addappid(600630)
addappid(675400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(600631, 1, "479003e5b43102a8e82fd4743f9ae34569b67a707febbe40657fb4427e0f35b6")
