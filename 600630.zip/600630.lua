-- Lua provided by RyzenAPI
-- Game: Game: AppID 600630

-- MAIN APPLICATION
addappid(600630)
-- Game: addappid(600630)

-- MAIN APP DEPOTS / PACKAGES
addappid(600631, 1, "479003e5b43102a8e82fd4743f9ae34569b67a707febbe40657fb4427e0f35b6")
