-- Lua provided by RyzenAPI
-- Game: NUC: After The Blast

-- MAIN APPLICATION
addappid(1595410)
-- Game: addappid(1595410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595411, 1, "752fbb6a91757a561ab034aadb72b576250a8814a5e2b3d1e1dd70fd7c6e11f6")
