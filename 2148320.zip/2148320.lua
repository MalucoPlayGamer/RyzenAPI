-- Lua provided by RyzenAPI
-- Game: Super Galaxy Ball

-- MAIN APPLICATION
addappid(2148320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148321, 1, "7f8da3fccb48e528f07a1682bf395aa773ba9841fa7ee76912a9b00d0f894286")
