-- Lua provided by RyzenAPI
-- Game: Cheaphaven Demo

-- MAIN APPLICATION
addappid(1969090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969091, 1, "ca5b2b43d9fd3693bd5af5a2e3c8488302f9c36e141d381aa6a50e17968aeaf1")

