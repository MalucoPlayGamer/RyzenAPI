-- Lua provided by RyzenAPI
-- Game: Florist Business Simulator

-- MAIN APPLICATION
addappid(2967450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967451, 1, "afbabfc25ac516d317194d63969666cd7dbca6a92e74a6a89889feba5084cefa")
