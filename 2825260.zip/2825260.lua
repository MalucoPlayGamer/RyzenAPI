-- Lua provided by RyzenAPI
-- Game: 2825260

-- MAIN APPLICATION
addappid(2825260)
-- Game: addappid(2825260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825261, 1, "df65745c6f625c2a46da30f83b91a544fcb80e85d2481fe731c7e876ad11224a")
