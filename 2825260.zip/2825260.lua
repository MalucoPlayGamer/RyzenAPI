-- Lua provided by RyzenAPI 
-- Game: My Lovely Empress Demo
addappid(2825260)
addappid(2825261, 1, "df65745c6f625c2a46da30f83b91a544fcb80e85d2481fe731c7e876ad11224a")
