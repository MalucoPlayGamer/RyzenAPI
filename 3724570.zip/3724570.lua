-- Lua provided by RyzenAPI
-- Game: Winslow

-- MAIN APPLICATION
addappid(3724570)
-- Game: addappid(3724570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3724571, 1, "49d1c97b46013c627545f6ef2b4c2d78acc855db68130b982915f01639fbdce3")
