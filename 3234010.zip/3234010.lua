-- Lua provided by RyzenAPI
-- Game: 3234010

-- MAIN APPLICATION
addappid(3234010)
-- Game: addappid(3234010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3234011, 1, "faf637b9e551eec41aaf445adc0745e56d9c0ac6d5ca9867b787fc1d6dae9b4c")
