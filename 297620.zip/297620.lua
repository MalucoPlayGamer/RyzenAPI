-- Lua provided by RyzenAPI
-- Game: 297620

-- MAIN APPLICATION
addappid(297620)
-- Game: addappid(297620)

-- MAIN APP DEPOTS / PACKAGES
addappid(297621, 1, "ce6b13f27a08c8257cf5223ed5a0049c1172bb860e984bb7c553a92dac0913a9")
