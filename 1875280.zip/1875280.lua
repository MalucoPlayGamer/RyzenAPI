-- Lua provided by RyzenAPI
-- Game: Miner Ultra Adventures 2

-- MAIN APPLICATION
addappid(1875280)
addappid(2059580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875281, 1, "848237ff74171d7e96421bc9259ee57e894b49a4ab7af193eae239f235ac9874")
