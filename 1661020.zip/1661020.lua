-- Lua provided by RyzenAPI
-- Game: BATTLE STEED : GUNMA (배틀 스티드 : 군마)

-- MAIN APPLICATION
addappid(1661020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661021, 1, "9954e57d257be5dcb66076682dec841cd30744b580b71294c2d018b335d52d06")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
