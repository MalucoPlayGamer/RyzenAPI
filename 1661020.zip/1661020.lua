-- Lua provided by RyzenAPI
-- Game: Game: BATTLE STEED : GUNMA (배틀 스티드 : 군마)

-- MAIN APPLICATION
addappid(1661020)
-- Game: addappid(1661020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661021, 1, "9954e57d257be5dcb66076682dec841cd30744b580b71294c2d018b335d52d06")
