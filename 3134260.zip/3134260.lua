-- Lua provided by RyzenAPI
-- Game: addappid(3134260)

-- MAIN APPLICATION
addappid(3134260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134261, 1, "53201cbe1c0663f7f0d67b28d6cf6d336e224fa2c23f06307d79db1ae74b5675")
