-- Lua provided by RyzenAPI
-- Game: 大落大起 Hard jump

-- MAIN APPLICATION
addappid(3600940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600941, 1, "86293f97de578fdb2903caa7703bb6653510f2f1d98252601a351a419d0af35c")

