-- Lua provided by SkyAPI 
-- Game: AppID 3600940
addappid(3600940)
addappid(3600941, 1, "86293f97de578fdb2903caa7703bb6653510f2f1d98252601a351a419d0af35c")
