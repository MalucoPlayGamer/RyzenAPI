-- Lua provided by RyzenAPI
-- Game: Fantasy Jigsaw Puzzle 5

-- MAIN APPLICATION
addappid(1771600)
addappid(1771680)
-- Game: addappid(1771600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771601, 1, "bfa88f519ed845d6625d1a2b4e71d391149966b3a073c052668e4074f0440684")
