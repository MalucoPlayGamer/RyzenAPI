-- Lua provided by RyzenAPI
-- Game: AppID 437160

-- MAIN APPLICATION
addappid(437160)
-- Game: addappid(437160)

-- MAIN APP DEPOTS / PACKAGES
addappid(437161, 1, "87b0121ee2578c7a76ee5a3cca55ce9763e43419bb9b7b1aae268f0e6e8eb057")
addappid(437162, 1, "0054f38d1f90bc0f0fb38421e41acdf12aca58e36708baaf8e65c80fd03b7769")
addappid(437163, 1, "db5b108dc7cdefc547ec589d55b43080472e022bb78edd01c8a343005bc28f48")
