-- Lua provided by RyzenAPI
-- Game: AppID 437160

-- MAIN APPLICATION
addappid(437160)
addappid(459140)
addappid(477020)
addappid(477030)
addappid(477040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(437161, 1, "87b0121ee2578c7a76ee5a3cca55ce9763e43419bb9b7b1aae268f0e6e8eb057")
addappid(437162, 1, "0054f38d1f90bc0f0fb38421e41acdf12aca58e36708baaf8e65c80fd03b7769")
addappid(437163, 1, "db5b108dc7cdefc547ec589d55b43080472e022bb78edd01c8a343005bc28f48")

