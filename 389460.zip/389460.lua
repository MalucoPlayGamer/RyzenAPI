-- Lua provided by RyzenAPI 
-- Game: AppID 389460
addappid(389460)
addappid(389461, 1, "6047b92e207aee24885fcee3f36a69a75554d56644827b3b79eaa9f6760c7c29")
