-- Lua provided by RyzenAPI
-- Game: Game: Murder In Tehran's Alleys 2016

-- MAIN APPLICATION
addappid(639730)
-- Game: addappid(639730)

-- MAIN APP DEPOTS / PACKAGES
addappid(639731, 1, "afd0ebcd6005589cb251ea3c0cbfc37124b925b30ee63058a5d4cc1eebaac92a")
