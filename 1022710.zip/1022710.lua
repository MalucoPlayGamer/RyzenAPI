-- Lua provided by RyzenAPI
-- Game: Conglomerate 451

-- MAIN APPLICATION
addappid(1022710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022711, 1, "3b7fd31e22d7b1984aaa71ad52164ea41a9e2acbd0110aa457ccb73ab29a268e")

