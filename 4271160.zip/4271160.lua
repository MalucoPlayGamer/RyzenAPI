-- 4271160's Lua and Manifest Created by Hubcap Manifest
-- Zero Stress King: Idle Defense
-- Created: June 13, 2026 at 11:59:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4271160, 1, "2afa8c6af8fa4abc117565ffa162ac76827bbe445991ebd931958a58766b5788") -- Zero Stress King: Idle Defense
-- MAIN APP DEPOTS
addappid(4271161, 1, "e38c6fa16240305be2aa7416c00ffc3b3d9a1786b94d53291b87119fcd05fa55") -- Depot 4271161
-- setManifestid(4271161, "7374138995390870732", 58012961)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4456860) -- Zero Stress King Beach Episode (Supporter Pack)