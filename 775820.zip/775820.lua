-- Lua provided by RyzenAPI
-- Game: Controllers Battery Indicator

-- MAIN APPLICATION
addappid(775820)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(775821, 1, "6ff0ca16f7a3135634ccc81c00c706b8a3153d834e20e3267ef03affc9a3b292")

