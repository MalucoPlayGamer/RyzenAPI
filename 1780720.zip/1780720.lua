-- Lua provided by RyzenAPI
-- Game: addappid(1780720)

-- MAIN APPLICATION
addappid(1780720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780721, 1, "fbd0439e7f92c7a5d2ba69796da9a6ec83b610f05cb917e2e35b7f0971bc4d97")
