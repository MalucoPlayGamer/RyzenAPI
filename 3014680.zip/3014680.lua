-- Lua provided by RyzenAPI
-- Game: Herbals tycoon

-- MAIN APPLICATION
addappid(3014680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014681, 1, "19c48bfe2cae77e41a9b5919d5660c15a85b50afc64787190ba83cc866779888")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4629360)
