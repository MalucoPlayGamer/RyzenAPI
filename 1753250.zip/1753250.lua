-- Lua provided by RyzenAPI
-- Game: Rogue Planet 1

-- MAIN APPLICATION
addappid(1753250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753251, 1, "8d670400890d5b1dd4b85f405b0d95220422c0ce8e13226d60ece772993ffc97")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1762210)
