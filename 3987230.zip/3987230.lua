-- 3987230's Lua and Manifest Created by Hubcap Manifest
-- Mining and Dwarves
-- Created: August 27, 2026 at 13:04:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3987230, 1, "93cf39713d36fad2505d7fc5fa189365f4780dfd3c28ed1497065256e7ab8a84") -- Mining and Dwarves
-- MAIN APP DEPOTS
addappid(3987231, 1, "fc7961f62179b18801f7eb8cc77fbef807bbe2b732ab2bf3336ba708ca15392c") -- Depot 3987231
setManifestid(3987231, "9197533527193754160", 317512011)
addappid(3987232, 1, "1df7ed999e68a7b82e5778c09cb213f88321b09db602bf16b15874e29180e8ac") -- Depot 3987232
setManifestid(3987232, "472837126313663435", 282434699)
addappid(3987233, 1, "2090811a692f17dcaa620f68657d8cc2cfc3727b3328709eb89fa7907e1bc8fd") -- Depot 3987233
setManifestid(3987233, "6202168373843246574", 378194059)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4963210) -- Mining and Dwarves - Supporter Pack