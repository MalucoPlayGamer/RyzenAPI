-- Lua provided by RyzenAPI
-- Game: addappid(1967808)

-- MAIN APPLICATION
addappid(1967808)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967808,0,"6e09fd488b81e3afae9a0560b96ddb72a41e48c9c4167b45c56eed264230c715")
