-- Lua provided by RyzenAPI
-- Game: 1351080

-- MAIN APPLICATION
addappid(1351080)
-- Game: addappid(1351080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351081, 1, "9e978faab4a203b5dfd99ccc412311a9063201eb6b6b61a4c6fdb2da0b4d5609")
