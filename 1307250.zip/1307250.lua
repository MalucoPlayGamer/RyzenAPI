-- Lua provided by RyzenAPI
-- Game: Game: AppID 1307250

-- MAIN APPLICATION
addappid(1307250)
-- Game: addappid(1307250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307251, 1, "7fcd1edbc86e24d0ed3146afa83818ae7c9047f26ec5fb6a30625670a4f31a3a")
