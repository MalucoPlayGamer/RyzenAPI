-- Lua provided by RyzenAPI
-- Game: AppID 595480

-- MAIN APPLICATION
addappid(595480)

-- MAIN APP DEPOTS / PACKAGES
addappid(595481, 1, "04c5add73ef2781111a7fb0b8ee2d39b5b41f1aa308b1b2e1bd4f2801cad6c4d")

