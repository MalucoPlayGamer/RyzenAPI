-- Lua provided by RyzenAPI
-- Game: Game: Idol cultivation process ：unspoken rules ★ミ

-- MAIN APPLICATION
addappid(2499670)
-- Game: addappid(2499670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499671, 1, "88e95fd202933326b0ef5f905adc96543822d71e40ca66d39def2b11409c8a0a")
addappid(2499672, 1, "9e88b8a73cb7b157de3a5dec69eaa30b05834d3d7f365555ccd93976ee7c50b4")
addappid(2499673, 1, "3b1fa587f6e7b3afa409c78beff3a37dda2ff6d01ae2b707737be6c54c8fbd0b")
addappid(2499674, 1, "b17d2b37ddf66d32f4ead90c693894f16c91b2b7624fbac7f528634cade2eccd")
