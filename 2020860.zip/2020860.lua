-- Lua provided by RyzenAPI
-- Game: Rush Rally 3

-- MAIN APPLICATION
addappid(2020860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2020861, 1, "6950ef3efb7cdef380ead26ac963a3bce000e61c1d0f3311dba5aa5a774d2615")

