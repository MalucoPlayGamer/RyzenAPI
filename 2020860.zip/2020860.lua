-- Lua provided by RyzenAPI
-- Game: Rush Rally 3

-- MAIN APPLICATION
addappid(2020860)
-- Game: addappid(2020860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020861, 1, "6950ef3efb7cdef380ead26ac963a3bce000e61c1d0f3311dba5aa5a774d2615")
