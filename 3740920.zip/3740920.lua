-- Lua provided by RyzenAPI
-- Game: Orbit Maze

-- MAIN APPLICATION
addappid(3740920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3740921, 1, "bd5a6bf816e3c5bd841eccafb589673b5bb5051ec251e83df7f1a110121ee530")
