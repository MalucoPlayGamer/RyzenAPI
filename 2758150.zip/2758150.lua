-- Lua provided by RyzenAPI
-- Game: Blast Processed

-- MAIN APPLICATION
addappid(2758150)
addappid(4185930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758151,0,"7260d6c067b5ac09c56eb34cd87bc9c1f6773e9d0889a9bd2bda158d8adfb681")

