-- Lua provided by RyzenAPI
-- Game: Lonely Yuri

-- MAIN APPLICATION
addappid(800120)

-- MAIN APP DEPOTS / PACKAGES
addappid(800121, 1, "5a14b9a8b4d01770d49b4f8dd42e8b6efe01451f19f1e677c10f332f34d15421")
addappid(800123, 1, "a8249f9caac652ed77abb1c8c97f80bfb014670010debb0d5156272299bc676c")
