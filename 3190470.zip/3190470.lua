-- Lua provided by RyzenAPI
-- Game: Commando Collection Soundtrack

-- MAIN APPLICATION
addappid(3190470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3190471, 1, "1e99918419d4bb9fe95bdeaed7233f0c7804aa47710a271ba30c9f7ce09a80bf")
