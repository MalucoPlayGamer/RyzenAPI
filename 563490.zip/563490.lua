-- Lua provided by RyzenAPI
-- Game: Earth Liberation

-- MAIN APPLICATION
addappid(563490)
addappid(569820)

-- MAIN APP DEPOTS / PACKAGES
addappid(563492,0,"2395a9ff8fdfdaeeaae4d1800fc1b1c453fecfe8617be30571e0aead1fb60df4")

