-- Lua provided by RyzenAPI
-- Game: Dress-up Traveller

-- MAIN APPLICATION
addappid(1129010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129011, 1, "c69185653c5ef511ad7e50a8c0ce77c32d8300ef1485227f4b85649f8ac4d43c")
addappid(1141110, 0, "95425575632ecb7b3b3825af6b3b821d671330c6bb9d044e4bd763dff3df3ff3")

