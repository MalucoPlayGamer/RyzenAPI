-- 4560660's Lua and Manifest Created by Hubcap Manifest
-- Eslabong
-- Created: August 24, 2026 at 19:38:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4560660) -- Eslabong
-- MAIN APP DEPOTS
addappid(4560661, 1, "a95950b18d5bf247a04b2a7199b3a9a93756fdc9bb97cb514d8ae9cb48ce015c") -- Depot 4560661
setManifestid(4560661, "6314013724540377704", 1058009507)