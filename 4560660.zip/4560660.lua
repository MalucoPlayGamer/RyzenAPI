-- Lua provided by RyzenAPI
-- Game: Eslabong

-- MAIN APPLICATION
addappid(4560660) -- Eslabong

-- MAIN APP DEPOTS / PACKAGES
addappid(4560661, 1, "a95950b18d5bf247a04b2a7199b3a9a93756fdc9bb97cb514d8ae9cb48ce015c") -- Depot 4560661

