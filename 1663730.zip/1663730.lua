-- Lua provided by RyzenAPI
-- Game: SGS Afrika Korps: Tunisia

-- MAIN APPLICATION
addappid(1663730)
-- Game: addappid(1663730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663731, 1, "7bfabde854c981635fa94c7ea68883542be103b6663637dfbd753688903eb6a8")
addappid(1663732, 1, "b8861c713949112b20175639e771b921a641ed8bedf80ac8345db7b8290db32c")
