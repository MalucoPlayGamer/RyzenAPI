-- Lua provided by RyzenAPI
-- Game: 2582920

-- MAIN APPLICATION
addappid(2582920)
-- Game: addappid(2582920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582920,0,"e7e6ce8d66497d9eb6c66c048b5fdd384e8a941899f8cfeca32ab7bf110bf6a5")
