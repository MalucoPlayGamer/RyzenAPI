-- Lua provided by RyzenAPI
-- Game: Forest and Girls

-- MAIN APPLICATION
addappid(1437650)
addappid(1455480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437651, 1, "bbfd09f5a2886964ddbddf740d68713b808172bc33e3fcfc9900693de15e1ffb")

