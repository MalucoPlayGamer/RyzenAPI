-- Lua provided by RyzenAPI
-- Game: 1437650

-- MAIN APPLICATION
addappid(1437650)
-- Game: addappid(1437650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437651, 1, "bbfd09f5a2886964ddbddf740d68713b808172bc33e3fcfc9900693de15e1ffb")
