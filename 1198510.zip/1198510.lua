-- Lua provided by RyzenAPI
-- Game: Paperball

-- MAIN APPLICATION
addappid(1198510)
-- Game: addappid(1198510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198511, 1, "a1ec653ebd41aeefdb6f97f31acf2f0c3594d090a4ebc390130065ce5d47cf25")
addappid(1209620, 0, "caef75b7e3531f638630bc62cfa2a12627fe22be70b808828354e4e106933e49")
addappid(1209621, 0, "51dbc33231365b9d7953eb79586e1f0c53ea5e128bb468afe5bc1574e7ce0535")
addappid(1285150, 0, "fdc0d4ce56c0dd841f2e4db3074d60277910252aee59369e88931e8a1b23ab4e")
