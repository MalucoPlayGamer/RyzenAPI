-- Lua provided by RyzenAPI
-- Game: Bloody Chronicles Original Soundtrack

-- MAIN APPLICATION
addappid(1001260)
-- Game: addappid(1001260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001261, 1, "b78bd82951467ce4378d507e76a1cc1ccdc9008865e6bf887b8af5bd93b4a329")
