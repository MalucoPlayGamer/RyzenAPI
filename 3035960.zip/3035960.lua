-- Lua provided by RyzenAPI
-- Game: Augment Anthem

-- MAIN APPLICATION
addappid(3035960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035969,0,"fa7f135eb24d884dbad747d4715cba056b2dab308805b8523b6d5d985e5b8939")

