-- Lua provided by RyzenAPI
-- Game: Game: Yargis - Space Melee

-- MAIN APPLICATION
addappid(369040)
-- Game: addappid(369040)

-- MAIN APP DEPOTS / PACKAGES
addappid(369041, 1, "9d63bb93862c59e25aad00f14aa7406894f46f417e7386092cfab368337ceef0")
addappid(383611, 0, "5a35b53d7077c9d8b090d06fde89309cf215633327b042aba39627939b287f0a")
