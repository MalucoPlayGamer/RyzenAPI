-- Lua provided by RyzenAPI
-- Game: Yargis - Space Melee

-- MAIN APPLICATION
addappid(369040)

-- MAIN APP DEPOTS / PACKAGES
addappid(369041, 1, "9d63bb93862c59e25aad00f14aa7406894f46f417e7386092cfab368337ceef0")
addappid(383611, 0, "5a35b53d7077c9d8b090d06fde89309cf215633327b042aba39627939b287f0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(383610)
addappid(402950)
