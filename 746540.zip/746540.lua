-- Lua provided by RyzenAPI
-- Game: Game: Space Panic Defense

-- MAIN APPLICATION
addappid(746540)
-- Game: addappid(746540)

-- MAIN APP DEPOTS / PACKAGES
addappid(746541, 1, "038d250d5d5656c8d14a6187e1ea2e5cdbb93fe9e8250d750a6bb3e09432c487")
addappid(746542, 1, "14c7c3c6e021b945f81cc4db72dc8126b552230519c0bc751addd46649395a99")
