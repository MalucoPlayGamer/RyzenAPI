-- Lua provided by RyzenAPI
-- Game: Tetragon

-- MAIN APPLICATION
addappid(1545850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545851, 1, "12fa68a837d2f1b91bc00a6a053612358f65758ba31a3b58e4a37f0b8af05a96")
