-- Lua provided by RyzenAPI
-- Game: Luckcatchers2

-- MAIN APPLICATION
addappid(2700970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2700971, 1, "c9c9dbaf0d94da8392cfda3b805349c1a5c3e9be73d4a367223e7cf98280aaef")
