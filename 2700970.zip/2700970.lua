-- Lua provided by RyzenAPI
-- Game: AppID 2700970

-- MAIN APPLICATION
addappid(2700970)
-- Game: addappid(2700970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700971, 1, "c9c9dbaf0d94da8392cfda3b805349c1a5c3e9be73d4a367223e7cf98280aaef")
