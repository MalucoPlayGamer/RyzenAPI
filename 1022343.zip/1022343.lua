-- Lua provided by RyzenAPI
-- Game: 1022343

-- MAIN APPLICATION
addappid(1022343)
-- Game: addappid(1022343)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022343,0,"88bbe0cffb0bc6afc8887f5ff65ca32d08149e6881d088f3fc0c7194c1a035da")
