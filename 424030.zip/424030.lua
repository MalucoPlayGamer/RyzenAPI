-- Lua provided by RyzenAPI
-- Game: 424030

-- MAIN APPLICATION
addappid(424030)
-- Game: addappid(424030)

-- MAIN APP DEPOTS / PACKAGES
addappid(424031, 1, "0d2d1793d5c1a8dcff87207ad8c37ad35d08c488e97c4ab82e111f2805bc0c11")
