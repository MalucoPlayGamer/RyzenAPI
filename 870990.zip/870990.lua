-- Lua provided by RyzenAPI
-- Game: addappid(870990)

-- MAIN APPLICATION
addappid(870990)

-- MAIN APP DEPOTS / PACKAGES
addappid(870991, 1, "d12124a070498ff6b998b24c921c084cab37fbd40281adf6abb105edd905ea3c")
