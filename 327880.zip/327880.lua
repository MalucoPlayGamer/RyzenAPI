-- Lua provided by RyzenAPI
-- Game: Sublevel Zero Redux

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228990)
addappid(327880)
addappid(405460)

-- MAIN APP DEPOTS / PACKAGES
addappid(327882,0,"0cd2c5c0197d0199050e8f0c408ff19b0a6ac0206aa9080cf813f07d5c43a33f")
addappid(327883,0,"f99838d88640f747f32af7ae8928527617a2a5f3e9498e1c25d1be892388b6d9")
addappid(327884,0,"6ba315ba114fd84e1e5f68df615b76e1932713e0225be7d07e0705c50190a1ed")
addappid(327885,0,"816382a308ba1bbf211b1539b7e80a25fd1bd98b7d51d3f99bf7b30cfacf31bf")
