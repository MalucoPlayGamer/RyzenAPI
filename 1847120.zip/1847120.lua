-- Lua provided by RyzenAPI
-- Game: 11F

-- MAIN APPLICATION
addappid(1847120)
-- Game: addappid(1847120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847122,0,"7c7d897acd8856017a9706c5bc7b9f0b594fabd83613c57d7372e79c2fa12e36")
