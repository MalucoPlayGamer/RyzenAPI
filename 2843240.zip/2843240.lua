-- Lua provided by RyzenAPI
-- Game: Fancyland

-- MAIN APPLICATION
addappid(2843240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843241,0,"2dc05dff9ab7b414d47951774946f248b73471f0204a98eec165fbfb3b396dae")

