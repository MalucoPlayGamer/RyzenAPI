-- Lua provided by RyzenAPI
-- Game: Ultimate Zombie Defense 2

-- MAIN APPLICATION
addappid(1765300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1765301, 1, "91d5ee6c2df3c69ec5ee6adb1ccd74bf45f8a311ffccfad5bdaa35aa0907bf5d")
