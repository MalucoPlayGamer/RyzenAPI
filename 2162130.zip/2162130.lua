-- Lua provided by RyzenAPI
-- Game: Deck 'Em!

-- MAIN APPLICATION
addappid(2162130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162131, 1, "efc00816fb0dc0be6e75452e86255abefbc9f0ad4e78edbc6654975fd92fdde7")

