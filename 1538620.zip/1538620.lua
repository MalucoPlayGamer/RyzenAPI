-- Lua provided by RyzenAPI
-- Game: Zoo Cleaner

-- MAIN APPLICATION
addappid(1538620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538621, 1, "5fb4b14bcf32b4319cdef36369f791d748c918f46ea66a475e6261315493dca5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
