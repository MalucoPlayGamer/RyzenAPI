-- Lua provided by RyzenAPI
-- Game: Zoo Cleaner

-- MAIN APPLICATION
addappid(1538620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538621, 1, "5fb4b14bcf32b4319cdef36369f791d748c918f46ea66a475e6261315493dca5")

