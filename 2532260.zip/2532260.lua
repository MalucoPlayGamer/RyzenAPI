-- Lua provided by RyzenAPI
-- Game: 2532260

-- MAIN APPLICATION
addappid(2532260)
-- Game: addappid(2532260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532261, 1, "d4b8240db6a436c6f1e9bdce24903b24511a5f1068c5758dfa352f6c40491ec7")
