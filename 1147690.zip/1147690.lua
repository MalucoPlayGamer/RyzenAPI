-- Lua provided by RyzenAPI
-- Game: NGU IDLE

-- MAIN APPLICATION
addappid(1147690)

