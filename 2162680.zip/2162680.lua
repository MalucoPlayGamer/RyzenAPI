-- Lua provided by RyzenAPI
-- Game: Doom Sweeper

-- MAIN APPLICATION
addappid(2162680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162682,0,"faec5be9b8536254519e9f27e889d0695d2c43a847a20261eb241a615140a275")

