-- Lua provided by RyzenAPI
-- Game: 947890

-- MAIN APPLICATION
addappid(947890)
-- Game: addappid(947890)

-- MAIN APP DEPOTS / PACKAGES
addappid(947893,0,"8483c249bcafb64c02f868673d0a7eede0bf7993e5c8f573011046870df1760c")
