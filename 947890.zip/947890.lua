-- Lua provided by RyzenAPI
-- Game: VirtualCast

-- MAIN APPLICATION
addappid(947890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(947893,0,"8483c249bcafb64c02f868673d0a7eede0bf7993e5c8f573011046870df1760c")

