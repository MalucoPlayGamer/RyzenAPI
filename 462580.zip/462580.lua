-- Lua provided by RyzenAPI
-- Game: addappid(462580)

-- MAIN APPLICATION
addappid(462580)

-- MAIN APP DEPOTS / PACKAGES
addappid(462585,0,"021e719a07ff7b4c4979ec63332cc772686f44817f1eed9d4743bf895952adc6")
