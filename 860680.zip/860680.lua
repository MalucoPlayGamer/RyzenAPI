-- Lua provided by RyzenAPI
-- Game: Smile'N'Slide

-- MAIN APPLICATION
addappid(860680)

-- MAIN APP DEPOTS / PACKAGES
addappid(860681,0,"d4f858859cccc418f647034d5b742bdf6163ad8b5c5c85fd894545737071b728")

