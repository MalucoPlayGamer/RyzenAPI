-- Lua provided by RyzenAPI
-- Game: Smile'N'Slide

-- MAIN APPLICATION
addappid(860680)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(860681,0,"d4f858859cccc418f647034d5b742bdf6163ad8b5c5c85fd894545737071b728")

