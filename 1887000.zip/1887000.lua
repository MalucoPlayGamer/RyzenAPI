-- Lua provided by RyzenAPI
-- Game: Gorilla Soccer

-- MAIN APPLICATION
addappid(1887000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887001, 1, "a98db549798c2a3561b079a87c8ba8f55a777525a4e93f2fdcccd9c70104c1cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2107790)
