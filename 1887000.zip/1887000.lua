-- Lua provided by RyzenAPI 
-- Game: Gorilla Soccer
addappid(1887000)
addappid(1887001, 1, "a98db549798c2a3561b079a87c8ba8f55a777525a4e93f2fdcccd9c70104c1cb")
