-- Lua provided by RyzenAPI
-- Game: addappid(966330)

-- MAIN APPLICATION
addappid(966330)

-- MAIN APP DEPOTS / PACKAGES
addappid(966331, 1, "6f7cd3d723ffffcdfc0f5df7312526bae9b942712511609fafea5eb4d4e02e71")
