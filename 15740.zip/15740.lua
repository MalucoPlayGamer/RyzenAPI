-- Lua provided by RyzenAPI 
-- Game: Oddworld: Munch's Oddysee
addappid(15740)
addappid(15741, 1, "c1586f7d418c66c186c519b49768218e100698a496d6f5a0ff6b3ab826bfd097")
