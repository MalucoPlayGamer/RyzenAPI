-- Lua provided by RyzenAPI
-- Game: Oddworld: Munch's Oddysee

-- MAIN APPLICATION
addappid(15740)

-- MAIN APP DEPOTS / PACKAGES
addappid(15741, 1, "c1586f7d418c66c186c519b49768218e100698a496d6f5a0ff6b3ab826bfd097")

