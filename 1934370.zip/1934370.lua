-- Lua provided by RyzenAPI
-- Game: addappid(1934370)

-- MAIN APPLICATION
addappid(1934370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934371, 1, "c98dd0f5d8c53cf0eca726bd3a57bb475eace554eb2064195026cf2a5a0aef8d")
