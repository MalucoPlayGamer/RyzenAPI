-- Lua provided by RyzenAPI
-- Game: addappid(2082810)

-- MAIN APPLICATION
addappid(2082810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082811, 1, "97f5ad2125781f3f56dd47db0ee2ff8e490163dd16523feeb706c75128989383")
