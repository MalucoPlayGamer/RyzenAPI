-- Lua provided by RyzenAPI
-- Game: bluem

-- MAIN APPLICATION
addappid(1949670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949671, 1, "27663f2b987dadb0127ff269dadf644bdec6cc07eeef5aed4ab632e12ee7f4c4")
