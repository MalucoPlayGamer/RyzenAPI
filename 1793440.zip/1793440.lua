-- Lua provided by RyzenAPI
-- Game: Shale Hill Secrets

-- MAIN APPLICATION
addappid(1793440)
addappid(3302100)
addappid(3302170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793441, 1, "6b074b78ca04366d020ffa23b460f9317fdc5cbd7243ccdf2bbc8e950c3b627f")
