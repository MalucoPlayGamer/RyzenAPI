-- Lua provided by RyzenAPI
-- Game: Stock:Retail investors

-- MAIN APPLICATION
addappid(2792080)
-- Game: addappid(2792080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2792081, 1, "4161f7e0f56d115d4113983473b5ae658d205138aeb55cc1c5fbd9e82683cc44")
