-- Lua provided by RyzenAPI 
-- Game: AppID 2422070
addappid(2422070)
addappid(2422071, 1, "b46bf5cd374ed81a0d53c1f5e82f0da18e5539ad5c68fb5cccf56ab3f7c0c846")
