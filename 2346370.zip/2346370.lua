-- Lua provided by RyzenAPI
-- Game: addappid(2346370)

-- MAIN APPLICATION
addappid(2346370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346371, 1, "5b4151523fad8f2d7e41bb9eeec8259f7c51ef9112e5fc089c9538594f388dc1")
