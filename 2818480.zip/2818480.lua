-- Lua provided by RyzenAPI
-- Game: addappid(2818480)

-- MAIN APPLICATION
addappid(2818480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818481, 1, "84526ae4986ee5db4c4e4c98ddfff9d3568e795bf1c06026e6146195d83fae42")
