-- Lua provided by RyzenAPI
-- Game: Slime Jump

-- MAIN APPLICATION
addappid(4920820) -- Slime Jump

-- MAIN APP DEPOTS / PACKAGES
addappid(4920821, 1, "a1853ba57191ef5ba02d190332583c2481ba4233a848863bd5bdf3d7a6607e7d") -- Depot 4920821
