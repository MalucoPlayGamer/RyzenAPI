-- Lua provided by RyzenAPI
-- Game: 2673110

-- MAIN APPLICATION
addappid(2673110)
-- Game: addappid(2673110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673111, 1, "b473410dd0ee74bcacb4dc8cbec2f4cd3064474188edba54f5464c3e744ada20")
addappid(2673112, 1, "1c350545348eb4e2ff7cf35efff8a75fcdaa13dd15808e337f6dd908aa363db2")
