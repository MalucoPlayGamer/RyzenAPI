-- Lua provided by RyzenAPI
-- Game: AppID 223810

-- MAIN APPLICATION
addappid(223810)
-- Game: addappid(223810)

-- MAIN APP DEPOTS / PACKAGES
addappid(223811, 1, "8cae9dc48566afcdfc0650c0eb761d060215cbf6af2d1c69e9a530d4b9e2fdab")
