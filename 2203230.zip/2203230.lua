-- Lua provided by RyzenAPI
-- Game: OCTOPATH TRAVELER II Prologue Demo

-- MAIN APPLICATION
addappid(2203230)
-- Game: addappid(2203230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203231, 1, "9d20b1acddbdfe97ff9a4ea0bc01e67e9f50490926c6bcad54189fdf3ab9f3f7")
