-- Lua provided by SkyAPI 
-- Game: VELASTER
addappid(1897060)
addappid(1897061, 1, "e9e32002d2fc0d1a4630573da158aa437fae2396d947210df22b7298ad020e41")
