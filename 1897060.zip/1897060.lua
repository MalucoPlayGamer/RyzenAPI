-- Lua provided by RyzenAPI
-- Game: 1897060

-- MAIN APPLICATION
addappid(1897060)
-- Game: addappid(1897060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897061, 1, "e9e32002d2fc0d1a4630573da158aa437fae2396d947210df22b7298ad020e41")
