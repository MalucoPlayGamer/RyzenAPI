-- Lua provided by RyzenAPI
-- Game: AppID 2720680

-- MAIN APPLICATION
addappid(2720680)
-- Game: addappid(2720680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720681, 1, "cedb8fef4d052ba22ef210e490ee25fa110cc02eaf97cd6a59aa96b805c4445a")
