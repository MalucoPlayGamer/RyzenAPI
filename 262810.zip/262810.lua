-- Lua provided by RyzenAPI
-- Game: 262810

-- MAIN APPLICATION
addappid(262810)
-- Game: addappid(262810)

-- MAIN APP DEPOTS / PACKAGES
addappid(262815,0,"59cd0bc5684cf9a426e9cc73ab2f41d54e3c8b16b5c725621287f3c4f937b81c")
