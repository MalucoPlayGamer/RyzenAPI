-- Lua provided by RyzenAPI
-- Game: Game: Stunt Hill

-- MAIN APPLICATION
addappid(818790)
-- Game: addappid(818790)

-- MAIN APP DEPOTS / PACKAGES
addappid(818791, 1, "fefd3a0250b6db123c8979559bd6e1379568ee59a3207d75261239374421303c")
