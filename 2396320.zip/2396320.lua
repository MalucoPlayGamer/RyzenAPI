-- Lua provided by RyzenAPI
-- Game: addappid(2396320)

-- MAIN APPLICATION
addappid(2396320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396321, 1, "10c9b03725c89f6cd7cdf24299174fd08907565cde7fbe8e5d715ff9690fb4f0")
