-- Lua provided by SkyAPI 
-- Game: 2023: Alien Bugs Invade Earth
addappid(2396320)
addappid(2396321, 1, "10c9b03725c89f6cd7cdf24299174fd08907565cde7fbe8e5d715ff9690fb4f0")
