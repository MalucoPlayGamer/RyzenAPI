-- Lua provided by RyzenAPI
-- Game: Blastercell

-- MAIN APPLICATION
addappid(608540)

-- MAIN APP DEPOTS / PACKAGES
addappid(608541, 1, "355087eb775d27a42378230e8d8d31b5952c37bc2d77941cfc1ba61038cc8d5c")
