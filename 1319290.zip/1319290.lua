-- Lua provided by RyzenAPI
-- Game: AppID 1319290

-- MAIN APPLICATION
addappid(1319290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1319291, 1, "61250bf3268b0517f6384633eb98b467284b0d0a86576faa074ca4b35a7725e3")

