-- Lua provided by RyzenAPI 
-- Game: AppID 1319290
addappid(1319290)
addappid(1319291, 1, "61250bf3268b0517f6384633eb98b467284b0d0a86576faa074ca4b35a7725e3")
