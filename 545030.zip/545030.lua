-- Lua provided by RyzenAPI
-- Game: Game: NSFW ~ Not a Simulator For Working

-- MAIN APPLICATION
addappid(545030)
-- Game: addappid(545030)

-- MAIN APP DEPOTS / PACKAGES
addappid(545031, 1, "0e197b45407b0819953c7c1b283421c1d5e840a6b15fc55a59a8a0a329fb701e")
addappid(545032, 1, "ceb590b2c83b61c0975b3b256767b994d8fa8db49b26d108179e647552678c2d")
addappid(545033, 1, "320b48e1fbecb618b87e059129d0b8ea29bc4d0c438eb4b0983ca8976f829cc5")
