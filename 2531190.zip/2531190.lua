-- Lua provided by RyzenAPI
-- Game: 2531190

-- MAIN APPLICATION
addappid(2531190)
-- Game: addappid(2531190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531191, 1, "0bf9c40ac1d1d064300b3562f4d2cb444487e3b60ed2c57a397383acb8cee2dc")
