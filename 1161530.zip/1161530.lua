-- Lua provided by RyzenAPI
-- Game: addappid(1161530)

-- MAIN APPLICATION
addappid(1161530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161531, 1, "a94f91f476602b5f7e757b4c7785e072b7ad849e20bfa5b8c4f5a96025ed65e0")
