-- Lua provided by RyzenAPI
-- Game: Idle Guy: Life Simulator games

-- MAIN APPLICATION
addappid(3659020)
