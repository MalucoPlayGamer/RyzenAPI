-- Lua provided by RyzenAPI
-- Game: Draw Rider 2

-- MAIN APPLICATION
addappid(588630)

-- MAIN APP DEPOTS / PACKAGES
addappid(588631, 1, "ec4e56e908e3b107212c78e4e3113194905dfc6bbce4468f97b0ecabd4a95a69")
addappid(588632, 1, "7c4944ba647959010b0fdb3d154e62aa3f0a804e1f9dd47c2c2aa1ddfe8dc944")
