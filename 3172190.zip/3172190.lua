-- Lua provided by RyzenAPI
-- Game: Game: AppID 3172190

-- MAIN APPLICATION
addappid(3172190)
-- Game: addappid(3172190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172191, 1, "a9dfb8d7b50461e7c42960f5d500bee69024f88c9af6af83cadcc477b270e6b2")
