-- Lua provided by RyzenAPI
-- Game: Judofuri

-- MAIN APPLICATION
addappid(3013460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013462,0,"eb886bf0a6a963b7a4a2a8cfa23cb47d248d2ca13284420a7051122d99d0145a")

