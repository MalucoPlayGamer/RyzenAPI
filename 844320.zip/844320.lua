-- Lua provided by RyzenAPI
-- Game: The House in Fata Morgana: A Requiem for Innocence Original Soundtrack

-- MAIN APPLICATION
addappid(844320)
-- Game: addappid(844320)

-- MAIN APP DEPOTS / PACKAGES
addappid(844320,0,"bf69f21d29b22d98a0d13912ca7ae129c44a44e0c9fe26c833bfe0879def8d7d")
