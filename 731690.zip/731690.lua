-- Lua provided by SkyAPI 
-- Game: AppID 731690
addappid(731690)
addappid(731691, 1, "6a710102f658b749128e2a3308e020f82e627168ee07b3d6e3934d174b417790")
