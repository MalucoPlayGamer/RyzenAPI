-- Lua provided by RyzenAPI
-- Game: 3075740

-- MAIN APPLICATION
addappid(3075740)
-- Game: addappid(3075740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075741, 1, "f76a15a4e18404a37b35ca04c6a698b24264fc6ae12926d55ec19b39ba031707")
