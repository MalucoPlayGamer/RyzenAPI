-- Lua provided by RyzenAPI
-- Game: Game: Voyeur Villa - Harem Manager

-- MAIN APPLICATION
addappid(2753260)
-- Game: addappid(2753260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753261, 1, "0d36166c538c77da617a7706fa2a7e95e7ab2a74559ec5574df17f750f98cf6a")
