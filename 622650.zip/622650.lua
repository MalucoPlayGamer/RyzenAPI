-- Lua provided by RyzenAPI
-- Game: Bendy and the Ink Machine

-- MAIN APPLICATION
addappid(622650)
addappid(622660)
addappid(622661)
addappid(730000)

-- MAIN APP DEPOTS / PACKAGES
addappid(622651, 1, "525bb062dc2acf46744d4fbd02044d28bad4f3266fe3c8e42bd6fdd1d2030e97")
addappid(622652, 1, "ff3dc383c775b96130d7be30d5b3a0b9d28a8a761f48663a342206e48f58ff0c")
addappid(622653, 1, "32f8523448cd804dbdb79f690000a9a39ec66e90f2b4b8db6dee433092a4abf4")
addappid(622654, 1, "b05fea5e1e495e4c071fee38d3d800ab0c2bc123fbfc9609da2bf49f614ac42e")
