-- Lua provided by RyzenAPI
-- Game: 2659940

-- MAIN APPLICATION
addappid(2659940)
-- Game: addappid(2659940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659940,0,"874a829901eee553e055be01f4b16f0e4ef568efd4f1fdc9faa1d4222e2d4b3b")
