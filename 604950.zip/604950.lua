-- Lua provided by RyzenAPI
-- Game: Game: AppID 604950

-- MAIN APPLICATION
addappid(604950)
-- Game: addappid(604950)

-- MAIN APP DEPOTS / PACKAGES
addappid(604951, 1, "6ea135414803faa0c46bef28c0e2e562961ef8fc0220603a9602aeaf49f34ba1")
