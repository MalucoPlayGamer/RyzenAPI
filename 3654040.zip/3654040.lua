-- Lua provided by RyzenAPI
-- Game: Tomboy: Trapped by Orcs

-- MAIN APPLICATION
addappid(3654040)
-- Game: addappid(3654040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3654041, 1, "b2528f790637928571362267676b8b00fa1899221442e72501a49be306bfedb8")
