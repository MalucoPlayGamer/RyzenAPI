-- Lua provided by RyzenAPI
-- Game: 什么鸟都 Playtest

-- MAIN APPLICATION
addappid(2821060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821061, 1, "465e485132015b42ba12d841dd7117c6b4ad679a12d4b4213dc0d177f228a3b3")

