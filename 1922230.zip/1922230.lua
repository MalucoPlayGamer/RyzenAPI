-- Lua provided by RyzenAPI
-- Game: addappid(1922230)

-- MAIN APPLICATION
addappid(1922230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922231, 1, "4e78993ff66cb8362956b890383a2ef4c3aa921b9acde68f1785f4e456aeeb68")
