-- Lua provided by RyzenAPI
-- Game: Command & Conquer Renegade™

-- MAIN APPLICATION
addappid(2229890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229891, 1, "bdd894d6c914afd1e1280f00b55cb6101ba134431e219773f87540c30c56fab3")
addappid(2229892, 1, "3dc15997e4d9d1d3952f000888711324c829c79dcbc6af2c80eea5d6870661c2")
addappid(2229893, 1, "578e675b291aa9dc07cce9ccf432c3d9f24d91a58310cd2a38f91dad95f62ea9")
addappid(2229894, 1, "2541b5fd9e50ce40591ca909c52930cd5097ce0240c2c7364ebd5279cf134cfa")
addappid(2229895, 1, "b9df820aca84b96cd98f4db45e37340e7794950cfb0c00b4cac2e157137144da")
addappid(2229896, 1, "eb66030a8511edabf0d6573820544eeec12b460119bb13136fbbd31e96514bf2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
