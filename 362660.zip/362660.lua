-- Lua provided by RyzenAPI
-- Game: AppID 362660

-- MAIN APPLICATION
addappid(362660)

-- MAIN APP DEPOTS / PACKAGES
addappid(362661, 1, "39ba62e9d5a3f2542dc9dd773bcfc3a7d2f314a1beb288736841133631d0e7c9")

