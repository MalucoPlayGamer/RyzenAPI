-- Lua provided by RyzenAPI
-- Game: Charlie II

-- MAIN APPLICATION
addappid(777760)

-- MAIN APP DEPOTS / PACKAGES
addappid(777761,0,"7f41dc46539bfe9b52247aa267b9945ea7a7ba3c542bc0c7cce5015a38330237")
addappid(851360,0,"d4da3592d61500144bb6dedc212a8776dc7350c90afe0fc4bc0ed3eb32678686")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
