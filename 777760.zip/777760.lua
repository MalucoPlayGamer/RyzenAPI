-- Lua provided by RyzenAPI
-- Game: Charlie II

-- MAIN APPLICATION
addappid(777760)

-- MAIN APP DEPOTS / PACKAGES
addappid(777761,0,"7f41dc46539bfe9b52247aa267b9945ea7a7ba3c542bc0c7cce5015a38330237")
addappid(851360,0,"d4da3592d61500144bb6dedc212a8776dc7350c90afe0fc4bc0ed3eb32678686")

