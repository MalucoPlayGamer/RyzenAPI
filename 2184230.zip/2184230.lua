-- Lua provided by RyzenAPI
-- Game: Red Tape

-- MAIN APPLICATION
addappid(2184230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184231, 1, "581c8197335fb0dc283646ae87a2369953453e05128cde90bac9248adca63ace")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
