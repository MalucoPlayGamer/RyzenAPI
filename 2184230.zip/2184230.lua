-- Lua provided by RyzenAPI
-- Game: Red Tape

-- MAIN APPLICATION
addappid(2184230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184231, 1, "581c8197335fb0dc283646ae87a2369953453e05128cde90bac9248adca63ace")
