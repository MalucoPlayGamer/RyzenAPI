-- Lua provided by RyzenAPI
-- Game: addappid(2916770)

-- MAIN APPLICATION
addappid(2916770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916771, 1, "6f64e82f4d8259dbe28b1f771a51f205836508c2e096819e00cf3390bb8b56cc")
