-- Lua provided by RyzenAPI
-- Game: 3588580

-- MAIN APPLICATION
addappid(3588580)
-- Game: addappid(3588580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3588581, 1, "f91093199035709f75d09d42b128ce1c3a6edc3a02f411721ecfa2b049f4e025")
