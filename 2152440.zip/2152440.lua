-- Lua provided by RyzenAPI
-- Game: Dome Keeper: Engineer Gear Pack

-- MAIN APPLICATION
addappid(2152440)
-- Game: addappid(2152440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152440,0,"7b68441ca2a5016bbe0979544c38bb426f0640d4ccf12edc99a8eed812e44e2b")
