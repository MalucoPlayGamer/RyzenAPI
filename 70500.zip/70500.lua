-- Lua provided by RyzenAPI
-- Game: AppID 70500

-- MAIN APPLICATION
addappid(70500)

-- MAIN APP DEPOTS / PACKAGES
addappid(70501, 1, "68ccff90b8bc8fa455b714e611aae88d0befbda8841d9b8fccd0c8a3e3fcfa46")
addappid(70502, 1, "1fb420533ca540935f51b8fa83830a30405bff48a1ea60522351e438da45fe1f")
