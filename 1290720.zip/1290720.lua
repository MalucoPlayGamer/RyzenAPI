-- Lua provided by RyzenAPI
-- Game: Calm Girls

-- MAIN APPLICATION
addappid(1290720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290721, 1, "f205bf1caab10754cb1fca3376f961edac8941f800da306c398bce7ed5eb1ede")
addappid(1315760, 0, "033b48d59f9a7a5996f7bff8c2a0b9e933978857bce133a833170af020ff3b50")
