-- Lua provided by RyzenAPI
-- Game: Flesh Eaters

-- MAIN APPLICATION
addappid(383580)
addappid(743290)

-- MAIN APP DEPOTS / PACKAGES
addappid(383581, 1, "452e07ff920d01b7a803e9f96f5b2bbd6330567cb2dc91fa02b56278cb718205")
