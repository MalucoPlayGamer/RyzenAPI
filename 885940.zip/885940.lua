-- Lua provided by RyzenAPI
-- Game: 885940

-- MAIN APPLICATION
addappid(885940)
-- Game: addappid(885940)

-- MAIN APP DEPOTS / PACKAGES
addappid(885941, 1, "8297c5dc050302f85d9ab6ae4936dabe453bc986ade531e01411885be45ba253")
