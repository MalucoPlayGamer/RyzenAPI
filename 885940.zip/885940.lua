-- Lua provided by RyzenAPI 
-- Game: Meritocracy of the Oni & Blade
addappid(885940)
addappid(885941, 1, "8297c5dc050302f85d9ab6ae4936dabe453bc986ade531e01411885be45ba253")
