-- Lua provided by RyzenAPI
-- Game: 2089430

-- MAIN APPLICATION
addappid(2089430)
-- Game: addappid(2089430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089431, 1, "5950ef0357c514d088b2c3c1eb0bdf25aaf84d4201cad57a4566d8c7022dbbd3")
