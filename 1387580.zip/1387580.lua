-- Lua provided by RyzenAPI
-- Game: AbsentedAge:アブセンテッドエイジ ～亡霊少女のローグライクアクションSRPG -幽玄の章-

-- MAIN APPLICATION
addappid(1387580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387581, 1, "492517975f2c091157702d1e117764e3dd52cab29a7f678123595de45af6f4b3")

