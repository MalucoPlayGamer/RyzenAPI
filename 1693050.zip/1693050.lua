-- Lua provided by RyzenAPI 
-- Game: Dirty and lascivious awakening RPG by lecher knight Reika
addappid(1693050)
addappid(1693051, 1, "830ceee9c284867485b8448c8159d690396f361f62a12691e823ad24dc187291")
addappid(1693052, 1, "c9c39f2b9c98e86cb0b171a593811e1d953ab5f522702cc6da5eca7cd32a6add")
