-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel (Manga) Vol. 1

-- MAIN APPLICATION
addappid(3132540)
-- Game: addappid(3132540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132541, 1, "cd3e495999f321353088138a8cf9e06764182c642ce8ad1bc3036e2c9e99cc40")
