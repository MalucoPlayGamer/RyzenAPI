-- Lua provided by RyzenAPI
-- Game: cat notebook

-- MAIN APPLICATION
addappid(1003490)
-- Game: addappid(1003490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003491, 1, "ca8db6c0085ccd86506239a187bdce1e782b2f83b03f55a1a06d5d299188e58f")
