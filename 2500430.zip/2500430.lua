-- Lua provided by RyzenAPI
-- Game: War Thunder: Air Forces, Vol.2 (Original Game Soundtrack)

-- MAIN APPLICATION
addappid(2500430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500432,0,"295a945282470ba96f46c433fd85532e887955b6631e0ce022f56a1ae86df0ae")
addappid(2500433,0,"62c65cf9cdc6fcf3dc96faa8c58fc817deb9964b2e3456bbef841384bb4da81e")
