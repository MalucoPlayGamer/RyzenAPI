-- Lua provided by RyzenAPI
-- Game: Game: AppID 202270

-- MAIN APPLICATION
addappid(202270)
addappid(228982)
addappid(228990)
addappid(236310)
-- Game: addappid(202270)

-- MAIN APP DEPOTS / PACKAGES
addappid(202271, 1, "90772e2664092cd495b590dea7c089de95cade98062d724d35a522d30d0b065c")
addappid(202272, 1, "bcba93f08ee5cddfae6748336d9bfd2f1740143eda85dc861622e8df55a38225")
