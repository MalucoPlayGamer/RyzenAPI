-- Lua provided by RyzenAPI
-- Game: addappid(373440)

-- MAIN APPLICATION
addappid(373440)

-- MAIN APP DEPOTS / PACKAGES
addappid(373441, 1, "e1a16afe8ccfdb97bbf910c3ec3e66096f90dc688f19131c7ed6c3fb1825a978")
