-- Lua provided by RyzenAPI
-- Game: 1426500

-- MAIN APPLICATION
addappid(1426500)
-- Game: addappid(1426500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426501, 1, "a398f19b6a042b9de0a1df77364efeae16699634ea4febafda8a705c22a7dc32")
