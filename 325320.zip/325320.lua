-- Lua provided by RyzenAPI
-- Game: Mythos: The Beginning

-- MAIN APPLICATION
addappid(325320)

-- MAIN APP DEPOTS / PACKAGES
addappid(325321, 1, "4c368eddaa62e978575c6b422e41215b8b4b62d7c032346984c818a2b7702153")

