-- Lua provided by RyzenAPI
-- Game: AppID 49810

-- MAIN APPLICATION
addappid(49810)
-- Game: addappid(49810)

-- MAIN APP DEPOTS / PACKAGES
addappid(49811, 1, "82120d6352685997a14355b575ccad303d3f307fd5eea434e9a7d180bea887da")
addappid(49812, 1, "8de9f84eeef2a617da6de1543deda7b6c560570bfe6f1dd49fefe8df5ffce635")
addappid(49813, 1, "233aa7e3af0e4e6cf7089519f43f13192c042831e962675d8a68aca7b352fcc0")
