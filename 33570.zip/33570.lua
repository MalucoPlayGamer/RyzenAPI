-- Lua provided by RyzenAPI
-- Game: Patrician III

-- MAIN APPLICATION
addappid(33570)
-- Game: addappid(33570)

-- MAIN APP DEPOTS / PACKAGES
addappid(33571, 1, "79a4ad86c24189c100232bf2037dea3a9d0a4b24ddb3f2fbabfa14a9cae44ada")
