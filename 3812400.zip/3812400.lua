-- Lua provided by RyzenAPI 
-- Game: AppID 3812400
addappid(3812400)
addappid(3812401, 1, "bcc320757da1ac73fc8f1d67315a2847cb86a61b0a761bdc840d05562a2be08d")
addappid(3812402, 1, "95b320ec833c488c26a602fc3e66a1f482f4849eadbfc7948a79364ec923f52a")
