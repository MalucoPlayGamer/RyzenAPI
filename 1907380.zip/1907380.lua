-- Lua provided by RyzenAPI
-- Game: Game: Arcane Vale

-- MAIN APPLICATION
addappid(1907380)
-- Game: addappid(1907380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907381, 1, "6e449b002e7a20c8902d27bc58200dea451cc6387703e0c46258e7115b248119")
