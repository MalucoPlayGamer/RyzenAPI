-- Lua provided by RyzenAPI
-- Game: TOXICANT

-- MAIN APPLICATION
addappid(688120)

-- MAIN APP DEPOTS / PACKAGES
addappid(688121,0,"e4d2cef82d14595b6c9da80d3599032b7be1c4aeda2bb43d65d4ba14733b69b0")

