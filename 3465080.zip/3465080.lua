-- 3465080's Lua and Manifest Created by Hubcap Manifest
-- Dungeons Bomb
-- Created: August 11, 2026 at 14:37:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3465080) -- Dungeons Bomb
-- MAIN APP DEPOTS
addappid(3465081, 1, "222cec09908f3207406d6efa20763bdb30041e0281d2a1b15dda076d2bb5ddec") -- Depot 3465081
setManifestid(3465081, "7699179081880952043", 891236581)