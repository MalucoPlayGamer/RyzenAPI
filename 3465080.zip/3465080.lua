-- Lua provided by RyzenAPI
-- Game: Dungeons Bomb

-- MAIN APPLICATION
addappid(3465080) -- Dungeons Bomb

-- MAIN APP DEPOTS / PACKAGES
addappid(3465081, 1, "222cec09908f3207406d6efa20763bdb30041e0281d2a1b15dda076d2bb5ddec") -- Depot 3465081

