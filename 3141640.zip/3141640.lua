-- Lua provided by RyzenAPI
-- Game: Valis Collection Artbook

-- MAIN APPLICATION
addappid(3141640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141641, 1, "18f164cff5b50d448cdcc49ba45dbd3d67c5a011fe013a6e9e3459f739927a7e")

