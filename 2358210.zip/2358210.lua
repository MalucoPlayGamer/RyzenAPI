-- Lua provided by RyzenAPI
-- Game: addappid(2358210)

-- MAIN APPLICATION
addappid(2358210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358211, 1, "e603da89d0b208bb644135cc818c060004dba7661cf649e3006f0edf17b8b58a")
