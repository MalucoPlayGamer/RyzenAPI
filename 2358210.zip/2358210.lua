-- Lua provided by RyzenAPI
-- Game: 全城警戒-世界大战一触即发，跪求指挥官！

-- MAIN APPLICATION
addappid(2358210)
-- Game: addappid(2358210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358211, 1, "e603da89d0b208bb644135cc818c060004dba7661cf649e3006f0edf17b8b58a")
