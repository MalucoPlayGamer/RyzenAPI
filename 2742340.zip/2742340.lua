-- Lua provided by RyzenAPI
-- Game: Apex Heroines - Mystic Month 神无月

-- MAIN APPLICATION
addappid(2742340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742340,0,"49c165b0947943f642904c9959253a71af09190902c99ea9cd465032e437366f")
