-- Lua provided by RyzenAPI
-- Game: Game: Necromunda: Hired Gun - Original Soundtrack

-- MAIN APPLICATION
addappid(1613040)
-- Game: addappid(1613040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1613041, 1, "add39ffb22c0478feade51977edf4793f8473ad0ce99de782efd564c790de1b9")
addappid(1613042, 1, "ea9b21a3c9566a11da7f3bd8073223842affa8cb128d7d5ff4cc1856789383a7")
