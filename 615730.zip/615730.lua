-- Lua provided by RyzenAPI
-- Game: Nancy Drew: The Final Scene

-- MAIN APPLICATION
addappid(615730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(615731,0,"a669eab687f7f4fba8b6c75cb4ad1aedf748474bc3a36f0b7e2ff64e29b5874a")

