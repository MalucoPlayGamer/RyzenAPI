-- Lua provided by RyzenAPI
-- Game: Nancy Drew: The Final Scene

-- MAIN APPLICATION
addappid(615730)

-- MAIN APP DEPOTS / PACKAGES
addappid(615731,0,"a669eab687f7f4fba8b6c75cb4ad1aedf748474bc3a36f0b7e2ff64e29b5874a")

