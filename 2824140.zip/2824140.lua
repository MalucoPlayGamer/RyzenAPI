-- 2824140's Lua and Manifest Created by Hubcap Manifest
-- DROOM
-- Created: August 04, 2026 at 22:45:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2824140, 1, "b016328801c54185432fa5ebc4fa8e2a19653df71ccbcfaf22729cf3d2602bde") -- DROOM
-- MAIN APP DEPOTS
addappid(2824141, 1, "91ea244a08de1a990101cc66ec24677fbf947001f6af9ceeb7a425ad570d5984") -- Depot 2824141
setManifestid(2824141, "4844474041961891721", 478778756)