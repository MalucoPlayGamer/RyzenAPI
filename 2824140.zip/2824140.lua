-- Lua provided by RyzenAPI
-- Game: DROOM

-- MAIN APP DEPOTS / PACKAGES
addappid(2824140, 1, "b016328801c54185432fa5ebc4fa8e2a19653df71ccbcfaf22729cf3d2602bde") -- DROOM
addappid(2824141, 1, "91ea244a08de1a990101cc66ec24677fbf947001f6af9ceeb7a425ad570d5984") -- Depot 2824141

