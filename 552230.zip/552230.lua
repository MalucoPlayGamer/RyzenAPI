-- Lua provided by RyzenAPI
-- Game: Doomsday Survival:Training

-- MAIN APPLICATION
addappid(552230)

-- MAIN APP DEPOTS / PACKAGES
addappid(552231,0,"b40be7ab7b32b711f8581c208b01dc1dcaeaf1689a6a637d7293d9ec204e752a")

