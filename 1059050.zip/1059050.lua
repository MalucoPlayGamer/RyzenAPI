-- Lua provided by RyzenAPI
-- Game: Limouzik Demo

-- MAIN APPLICATION
addappid(1059050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059051, 1, "47b23b79d1861e2c12e434a332abdacf4491884281b4560afd394559eabeb857")

