-- Lua provided by RyzenAPI
-- Game: The Cyber Masquerade

-- MAIN APPLICATION
addappid(2780640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780647,0,"90961752cf35d31c2af47388c782336ae19ca81183ae7b750ef21bb227b0b2f5")
addappid(2780648,0,"05ae34422d5316ec63a35e89af053d9c6f73125a3c9d81fce1424124d371b833")
addappid(2780649,0,"9aea9f891234a368ed96e8ddbf98c6f0116e2d99b600b95e097d77a11ab5fffb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2838860)
