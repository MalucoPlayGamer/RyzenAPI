-- Lua provided by RyzenAPI
-- Game: 560050

-- MAIN APPLICATION
addappid(560050)
-- Game: addappid(560050)

-- MAIN APP DEPOTS / PACKAGES
addappid(560051, 1, "0a80cc2fcb34b9dd9778f3dba5847716697d8a5a8fb35356f311e5881b216ea2")
