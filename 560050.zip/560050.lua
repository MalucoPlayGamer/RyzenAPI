-- Lua provided by RyzenAPI
-- Game: Xmas Shooting - Scramble!!

-- MAIN APPLICATION
addappid(560050)

-- MAIN APP DEPOTS / PACKAGES
addappid(560051, 1, "0a80cc2fcb34b9dd9778f3dba5847716697d8a5a8fb35356f311e5881b216ea2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
