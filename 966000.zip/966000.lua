-- Lua provided by RyzenAPI
-- Game: addappid(966000)

-- MAIN APPLICATION
addappid(966000)

-- MAIN APP DEPOTS / PACKAGES
addappid(966001, 1, "add80dd0a944994f7bdcdc37a64f4376236295c5cdd307a96c86fc57f6a8b067")
