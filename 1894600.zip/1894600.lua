-- Lua provided by RyzenAPI
-- Game: 1894600

-- MAIN APPLICATION
addappid(1894600)
-- Game: addappid(1894600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894601, 1, "ddb89ea73cf7c129ea1b93f4029b8169d2ed30a615d0f92422b96403c7bb807c")
