-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1626880)
addappid(1626881)
addappid(1626882)

-- MAIN APP DEPOTS / PACKAGES
addappid(845241,0,"9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")
