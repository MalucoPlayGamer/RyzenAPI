-- Lua provided by RyzenAPI 
-- Game: Wartales - Music: The Official Soundtrack
addappid(3533110)
addappid(3533111, 1, "3354e8e7365b10273c0c78b9cd7518719e8363fd3a2b09af934059b80307d624")
addappid(3533112, 1, "ac370f744d81811d0f2349a8f98ddbaa19edad8c1d9771965373b165c78db5aa")
