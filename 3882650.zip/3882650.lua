-- Lua provided by RyzenAPI
-- Game: Kingdom's Return: Time-Eating Fruit and the Ancient Monster

-- MAIN APPLICATION
addappid(3882650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3882651,0,"cc96156152e58dc04e860943fb6ca9976a3097ce8eec01236396e4218edbff4a")
addappid(4382420,0,"60571a22dfa9bb608cf91181d856b162701d3112ec9182413a82461ac86c252e")

