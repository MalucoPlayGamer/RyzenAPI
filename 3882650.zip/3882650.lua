-- Lua provided by RyzenAPI
-- Game: Kingdom's Return: Time-Eating Fruit and the Ancient Monster

-- MAIN APPLICATION
addappid(4382420)
addappid(4382430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3882650, 1, "561d33b55dd9037da3733620e3fb8c2d98ea32ddde31e57e1f27214b4279d7a3") -- Kingdom's Return: Time-Eating Fruit and the Ancient Monster
addappid(3882651, 1, "cc96156152e58dc04e860943fb6ca9976a3097ce8eec01236396e4218edbff4a") -- Depot 3882651
addappid(4382420, 1, "60571a22dfa9bb608cf91181d856b162701d3112ec9182413a82461ac86c252e") -- Kingdoms Return - Azure Striker Gunvolt Crossover Character Skin - Depot 4382420
addappid(4382430, 1, "64980f756e41952b0dceb0a2362bea2ec03f12df0a0e1840d053184f0460637f") -- Kingdoms Return - GalGun Double Peace Crossover Character Skin - Depot 4382430

