-- 3882650's Lua and Manifest Created by Hubcap Manifest
-- Kingdom's Return: Time-Eating Fruit and the Ancient Monster
-- Created: August 25, 2026 at 05:50:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3882650, 1, "561d33b55dd9037da3733620e3fb8c2d98ea32ddde31e57e1f27214b4279d7a3") -- Kingdom's Return: Time-Eating Fruit and the Ancient Monster
-- MAIN APP DEPOTS
addappid(3882651, 1, "cc96156152e58dc04e860943fb6ca9976a3097ce8eec01236396e4218edbff4a") -- Depot 3882651
setManifestid(3882651, "8689577657228270851", 767357711)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Kingdoms Return - Azure Striker Gunvolt Crossover Character Skin (AppID: 4382420)
addappid(4382420)
addappid(4382420, 1, "60571a22dfa9bb608cf91181d856b162701d3112ec9182413a82461ac86c252e") -- Kingdoms Return - Azure Striker Gunvolt Crossover Character Skin - Depot 4382420
setManifestid(4382420, "5488538593822591812", 3213616)
-- Kingdoms Return - GalGun Double Peace Crossover Character Skin (AppID: 4382430)
addappid(4382430)
addappid(4382430, 1, "64980f756e41952b0dceb0a2362bea2ec03f12df0a0e1840d053184f0460637f") -- Kingdoms Return - GalGun Double Peace Crossover Character Skin - Depot 4382430
setManifestid(4382430, "8080540160882660577", 2439874)