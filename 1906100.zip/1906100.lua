-- Lua provided by RyzenAPI
-- Game: 1906100

-- MAIN APPLICATION
addappid(1906100)
-- Game: addappid(1906100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906101, 1, "d3ec4ca9bf1874642155e50e38a6c6855ceb37f78d45256fcfad71a0eed99c32")
