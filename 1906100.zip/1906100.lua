-- Lua provided by RyzenAPI
-- Game: Mirror Shoot

-- MAIN APPLICATION
addappid(1906100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1906101, 1, "d3ec4ca9bf1874642155e50e38a6c6855ceb37f78d45256fcfad71a0eed99c32")

