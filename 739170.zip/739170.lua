-- Lua provided by SkyAPI 
-- Game: Parker & Lane: Twisted Minds
addappid(739170)
addappid(739171, 1, "6442e3cd470b1ac1c5a419bc2fa42e256ec1a767a124650f33e77edf45ff2516")
