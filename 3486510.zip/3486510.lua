-- Lua provided by RyzenAPI
-- Game: 3486510

-- MAIN APPLICATION
addappid(3486510)
-- Game: addappid(3486510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3486511, 1, "ea685e97fb7c882b8c961e0aae1fa5afc2723998f9f44c2e34bb4658a93ea598")
