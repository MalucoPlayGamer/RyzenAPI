-- Lua provided by RyzenAPI
-- Game: Conradito Cafézito

-- MAIN APPLICATION
addappid(3235270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3235271, 1, "71e1ee172e0a5a15a333c1146e375a46671e14171d1ae10cf45d0c5723a7885d")

