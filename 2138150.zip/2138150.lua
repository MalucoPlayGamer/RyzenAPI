-- Lua provided by RyzenAPI
-- Game: My Stepsis is a Furry Futa Fox

-- MAIN APPLICATION
addappid(2138150)
-- Game: addappid(2138150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138151, 1, "1392e3b02f8213afeab12791c1235eed66040f8f9b2c436501e46f6fa70e4ea1")
