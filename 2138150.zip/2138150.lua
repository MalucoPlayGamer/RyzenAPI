-- Lua provided by SkyAPI 
-- Game: My Stepsis is a Furry Futa Fox
addappid(2138150)
addappid(2138151, 1, "1392e3b02f8213afeab12791c1235eed66040f8f9b2c436501e46f6fa70e4ea1")
