-- Lua provided by RyzenAPI
-- Game: addappid(1043510)

-- MAIN APPLICATION
addappid(1043510)
addappid(1115120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043511, 1, "1c4d012d9df6e1817ac35f1864db5108e89ac36ccaf11ad3c0d6026bd50a9b6c")
