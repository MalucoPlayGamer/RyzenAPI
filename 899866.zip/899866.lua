-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(899866)
-- Game: addappid(899866)

-- MAIN APP DEPOTS / PACKAGES
addappid(899866,0,"9aae7e846db8628253865acf75c13cd8da864699d2d097ff1066f16bd462786e")
