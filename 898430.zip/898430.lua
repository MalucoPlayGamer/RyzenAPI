-- Lua provided by RyzenAPI
-- Game: CubeCreatorX

-- MAIN APPLICATION
addappid(898430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(898431, 1, "b9deb9453d38cc467568054a455e024b98ab2ad2182cd95d0599a64763cbed5c")
