-- Lua provided by RyzenAPI
-- Game: AppID 487250

-- MAIN APPLICATION
addappid(487250)

-- MAIN APP DEPOTS / PACKAGES
addappid(487251, 1, "0bf62c90cc4c1eee9334767a2d831b0f13434afbd7b3ea2847cde4580aef034f")

