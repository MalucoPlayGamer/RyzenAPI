-- Lua provided by RyzenAPI 
-- Game: AppID 1087080
addappid(1087080)
addappid(1087081, 1, "cab369f305d4ae4c20e07c279706131c9f939433b15824ae3ff3e52fb13549c2")
