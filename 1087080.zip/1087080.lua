-- Lua provided by RyzenAPI
-- Game: AppID 1087080

-- MAIN APPLICATION
addappid(1087080)
addappid(1107090)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1087081, 1, "cab369f305d4ae4c20e07c279706131c9f939433b15824ae3ff3e52fb13549c2")

