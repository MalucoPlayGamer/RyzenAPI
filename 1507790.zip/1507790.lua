-- Lua provided by RyzenAPI
-- Game: Game: Witch Strandings

-- MAIN APPLICATION
addappid(1507790)
-- Game: addappid(1507790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507791, 1, "60bf9e930dde7e6e08d68098915a638ce69bd9f569cf7b8965de58a465055493")
