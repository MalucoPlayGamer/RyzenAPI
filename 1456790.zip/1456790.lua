-- Lua provided by RyzenAPI
-- Game: Rolls and Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1456790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456790,0,"3be80101e0f6e78c25e7e51aad554583f33b45dfb4a0c77388c501bd24810635")

