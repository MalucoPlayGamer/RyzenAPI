-- Lua provided by RyzenAPI
-- Game: Streng Check

-- MAIN APPLICATION
addappid(295650)

-- MAIN APP DEPOTS / PACKAGES
addappid(295651, 1, "0764158fa8c6180394b819302d495dfbb4cd954d8ffc357a33bb58ddc934d387")

