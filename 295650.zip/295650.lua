-- Lua provided by RyzenAPI
-- Game: Streng Check

-- MAIN APPLICATION
addappid(295650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(295651, 1, "0764158fa8c6180394b819302d495dfbb4cd954d8ffc357a33bb58ddc934d387")

