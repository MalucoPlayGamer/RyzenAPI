-- Lua provided by RyzenAPI
-- Game: NejicomiSimulator Vol.5

-- MAIN APPLICATION
addappid(2370740)
addappid(2370750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370741, 1, "427211ca5b459623e9cbcd6f589aa08a0ce118ee1b64daddb6c67e835d8d5ccd")
