-- Lua provided by RyzenAPI
-- Game: Role of Hex

-- MAIN APPLICATION
addappid(1479880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479881, 1, "e2077f2b16104650f15461d4cda2dc38cbf041dc4bbfdd48e7eb37a597fc50cc")
