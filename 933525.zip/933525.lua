-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Samurai Warriors Pack 1

-- MAIN APPLICATION
addappid(933525)
-- Game: addappid(933525)

-- MAIN APP DEPOTS / PACKAGES
addappid(933525,0,"032476a2a65b779452fdd94896a2b417c03eba39e2a7745103d78d0486296c15")
