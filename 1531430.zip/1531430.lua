-- Lua provided by RyzenAPI
-- Game: 1531430

-- MAIN APPLICATION
addappid(1531430)
-- Game: addappid(1531430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531431, 1, "1c549cd790d156d8ee3e77068c5b703473ca56182ded2a3323b1ecc214e25ea5")
