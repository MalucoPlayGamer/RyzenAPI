-- Lua provided by RyzenAPI
-- Game: Night Fright

-- MAIN APPLICATION
addappid(3162740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162741, 1, "c421b9ffdb4129c50c6711e30e38710ace030797881d53bf13c1c83ff9b87b7a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
