-- Lua provided by RyzenAPI
-- Game: Game: Night Fright

-- MAIN APPLICATION
addappid(3162740)
-- Game: addappid(3162740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162741, 1, "c421b9ffdb4129c50c6711e30e38710ace030797881d53bf13c1c83ff9b87b7a")
