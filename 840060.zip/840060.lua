-- Lua provided by RyzenAPI
-- Game: Good Doggo

-- MAIN APPLICATION
addappid(840060)
addappid(840670)

-- MAIN APP DEPOTS / PACKAGES
addappid(840061, 1, "3c913c36f9717855e5210abaaf8b164a60ca95bb780db3180b5f696aa7411998")
addappid(840062, 1, "0bb2e6c58cad86495cc88eed509fab61c77023cb8ad5dc37623678c35419b9e1")
addappid(840063, 1, "1380d01ae1c1214e13cbdcb91a3c0f7d61032a213bf26494563e4dca59b0bea3")
