-- Lua provided by RyzenAPI
-- Game: SCP-087 VR Survivor

-- MAIN APPLICATION
addappid(808220)

-- MAIN APP DEPOTS / PACKAGES
addappid(808221,0,"871568e9bd862c54e8cd18ee754fa269e66831560a541ca45f71a6deb7d69dd5")

