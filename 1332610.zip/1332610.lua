-- Lua provided by RyzenAPI
-- Game: 1332610

-- MAIN APPLICATION
addappid(1332610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332612,0,"9be7c8ebef072d29ab76d9031b84204d19e097a1406ca5de6912dab4b9a2e4ca")
