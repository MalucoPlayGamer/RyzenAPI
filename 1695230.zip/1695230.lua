-- Lua provided by RyzenAPI
-- Game: 1695230

-- MAIN APPLICATION
addappid(1695230)
-- Game: addappid(1695230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695233,0,"254e3d4d596235f8cdfdd64dc1da40b99a41656391f870ebb988ea0a6efc96c6")
