-- Lua provided by RyzenAPI
-- Game: Sector's Edge

-- MAIN APPLICATION
addappid(1024890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024891, 1, "86dfdbc1fc0c0fc73440e27d77f7c9ba158faa6731316f70c41415347940f6e8")

