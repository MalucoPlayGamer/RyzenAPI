-- Lua provided by RyzenAPI
-- Game: 1918030

-- MAIN APPLICATION
addappid(1918030)
-- Game: addappid(1918030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918032,0,"4dc63156b71146c187a9491f2ed12831948adf6be874b9411c20be1840dbbcdf")
