-- Lua provided by RyzenAPI
-- Game: AppID 1714020

-- MAIN APPLICATION
addappid(1714020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714021, 1, "8aa7b746c20093219bf727fc3b2c97f900cfb5b039bdaae9b71bc68c9fcbcc2c")

