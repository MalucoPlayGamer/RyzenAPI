-- Lua provided by RyzenAPI
-- Game: Mushroom Age

-- MAIN APPLICATION
addappid(2683110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683111,0,"eea6b5f30d0642e1b73f403ec8f5ea14205ec65ee8dbd067884cb198bef1c0ae")

