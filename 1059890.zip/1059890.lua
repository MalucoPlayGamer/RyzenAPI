-- Lua provided by RyzenAPI
-- Game: Devious Dungeon 2

-- MAIN APPLICATION
addappid(1059890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059891, 1, "e89f8c86d4a7f5747074de123590fe3443587635215db5ad45cce29342ce081c")
