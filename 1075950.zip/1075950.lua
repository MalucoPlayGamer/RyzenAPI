-- Lua provided by RyzenAPI
-- Game: Disintegration Technical Beta

-- MAIN APPLICATION
addappid(1075950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075951, 1, "a05eb6aaac7be4b98137ab860b444393874dd58ff9a114a265b20e1a22ac96bf")

