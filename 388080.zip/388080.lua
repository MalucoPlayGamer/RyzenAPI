-- Lua provided by RyzenAPI
-- Game: 388080

-- MAIN APPLICATION
addappid(388080)
addappid(393560)
-- Game: addappid(388080)

-- MAIN APP DEPOTS / PACKAGES
addappid(388081, 1, "2bcaa2abc99c660fd9303b47fde74e15c71b7a24da78c401869bb3c0850bc99b")
