-- Lua provided by RyzenAPI
-- Game: Borderless Gaming

-- MAIN APPLICATION
addappid(388080)
addappid(393560)

-- MAIN APP DEPOTS / PACKAGES
addappid(388081, 1, "2bcaa2abc99c660fd9303b47fde74e15c71b7a24da78c401869bb3c0850bc99b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2901910)
