-- Lua provided by RyzenAPI
-- Game: Monkey Land 3D: Reaper Rush

-- MAIN APPLICATION
addappid(569500)

-- MAIN APP DEPOTS / PACKAGES
addappid(569501, 1, "33753aa36f55b748e86587d133549d8cc830e74874f341e0a874765858336b75")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
