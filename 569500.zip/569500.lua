-- Lua provided by RyzenAPI
-- Game: Game: Monkey Land 3D: Reaper Rush

-- MAIN APPLICATION
addappid(569500)
-- Game: addappid(569500)

-- MAIN APP DEPOTS / PACKAGES
addappid(569501, 1, "33753aa36f55b748e86587d133549d8cc830e74874f341e0a874765858336b75")
