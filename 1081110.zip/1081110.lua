-- Lua provided by RyzenAPI
-- Game: Game: Milly the dog

-- MAIN APPLICATION
addappid(1081110)
-- Game: addappid(1081110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081111, 1, "e18f6eb23bf9dca3387871c3c8cc8a8d058df1d7a0071f6f1263f4505e5f4486")
