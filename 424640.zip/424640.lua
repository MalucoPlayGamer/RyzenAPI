-- Lua provided by RyzenAPI
-- Game: Karaski: What Goes Up...

-- MAIN APPLICATION
addappid(424640)

-- MAIN APP DEPOTS / PACKAGES
addappid(424641, 1, "493d7f262be0358c32e00e3fb08b92057d2c5e0f6d97aab1241aea3480cd7965")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
