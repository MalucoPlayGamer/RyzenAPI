-- Lua provided by RyzenAPI 
-- Game: Karaski: What Goes Up...
addappid(424640)
addappid(424641, 1, "493d7f262be0358c32e00e3fb08b92057d2c5e0f6d97aab1241aea3480cd7965")
