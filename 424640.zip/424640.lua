-- Lua provided by RyzenAPI
-- Game: Game: Karaski: What Goes Up...

-- MAIN APPLICATION
addappid(424640)
-- Game: addappid(424640)

-- MAIN APP DEPOTS / PACKAGES
addappid(424641, 1, "493d7f262be0358c32e00e3fb08b92057d2c5e0f6d97aab1241aea3480cd7965")
