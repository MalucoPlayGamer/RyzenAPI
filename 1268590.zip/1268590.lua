-- Lua provided by RyzenAPI 
-- Game: Millennia
addappid(1268590)
addappid(1268591, 1, "81443b429135f50985f3d1d2b7b82855ebe63b1472213827ca6cba86b460c55e")
addappid(2647810, 0, "039a5b79e1e5d200d26bf20e35f47fcd977d5e4dca873c10bd85dca5238754a7")
