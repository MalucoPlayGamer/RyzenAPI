-- Lua provided by RyzenAPI
-- Game: Game: ROAD HOMEWARD 2: river trip

-- MAIN APPLICATION
addappid(1059080)
-- Game: addappid(1059080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059081, 1, "648734466bc80a0f1cea3532cffb499fe5bfec92935a2edd9c4e8b40af49667f")
