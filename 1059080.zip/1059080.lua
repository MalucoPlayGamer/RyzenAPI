-- Lua provided by RyzenAPI
-- Game: ROAD HOMEWARD 2: river trip

-- MAIN APPLICATION
addappid(1059080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059081, 1, "648734466bc80a0f1cea3532cffb499fe5bfec92935a2edd9c4e8b40af49667f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
