-- Lua provided by RyzenAPI
-- Game: addappid(1483310)

-- MAIN APPLICATION
addappid(1483310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483311, 1, "8a77bb2f076a0535fa3ae2968f3a5edd2c6b4a335f70712892cc109b3321a823")
