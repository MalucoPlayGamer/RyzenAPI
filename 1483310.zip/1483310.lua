-- Lua provided by SkyAPI 
-- Game: 大禹治水 Flood Fighting Hero
addappid(1483310)
addappid(1483311, 1, "8a77bb2f076a0535fa3ae2968f3a5edd2c6b4a335f70712892cc109b3321a823")
