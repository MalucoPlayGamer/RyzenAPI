-- Lua provided by RyzenAPI
-- Game: Devilated Soundtrack

-- MAIN APPLICATION
addappid(1789290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789291, 1, "f05bc8a68084ffd5620ecf24435cba9c0d9bb4b26b0884736d7a2c1eb34d6c08")
addappid(1789292, 1, "caf0a3613809866e1bca69e287328f7cce943772f2967d9641234d670b9287bf")
addappid(1789293, 1, "8903390b366c6ac5753f076ffbf1745b35aaeecbf1eda3a611e32689ca79651e")

