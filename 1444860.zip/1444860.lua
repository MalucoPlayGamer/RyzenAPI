-- Lua provided by RyzenAPI
-- Game: Waifu Love

-- MAIN APPLICATION
addappid(1444860)
addappid(3561650)
addappid(3561660)
addappid(3561670)
addappid(3561680)
addappid(3561690)
addappid(3561700)
addappid(3561710)
addappid(3561720)
addappid(4850600)
addappid(4850610)
addappid(4850620)
addappid(4850630)
addappid(4850640)
addappid(4850650)
addappid(4850660)
addappid(4850670)
addappid(4850680)
addappid(4850690)
addappid(4850700)
addappid(4850710)
addappid(4850720)
addappid(4850730)
addappid(4850740)
addappid(4850750)
addappid(4850760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444861, 1, "b488b785a663f7fb9036cf131eeee96193621fa85f4f45fb84b4de2258f76f7a")

