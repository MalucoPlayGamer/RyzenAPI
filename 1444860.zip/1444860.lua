-- Lua provided by RyzenAPI
-- Game: Game: Waifu Love

-- MAIN APPLICATION
addappid(1444860)
-- Game: addappid(1444860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444861, 1, "b488b785a663f7fb9036cf131eeee96193621fa85f4f45fb84b4de2258f76f7a")
