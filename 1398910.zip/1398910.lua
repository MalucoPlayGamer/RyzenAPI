-- Lua provided by RyzenAPI
-- Game: Jorel’s Brother and The Most Important Game of the Galaxy - Complete Edition

-- MAIN APPLICATION
addappid(1398910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398912,0,"c3c46eac3dfb69688091cce1c7b8d394ec6bf826628f46c4ba1cb49f26ce3e3c")
addappid(1398913,0,"3a4107315e7813d923e72349847b1b1bf56eca26d97f8195400838c8f3e230c3")
addappid(2238380,0,"e8d714c3e42c54b56bcc280a09112ed9b07b8a4fb94c44591326b57b37979286")
addappid(2238390,0,"fb2655e7cbea9a94af23030a6f52ada61d0b7b95d8cd953ab55ac2890ae7286b")

