-- Lua provided by RyzenAPI
-- Game: Happy Island Life

-- MAIN APPLICATION
addappid(1855610)
-- Game: addappid(1855610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855611, 1, "b89a99c2d58443b25e487be00ecdc62d4115732c395a14465e0805e50a951e17")
