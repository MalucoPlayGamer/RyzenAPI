-- Lua provided by RyzenAPI
-- Game: addappid(1041690)

-- MAIN APPLICATION
addappid(1041690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041691, 1, "b14f7e49b17cb69d575197d391c66485348cf5ef634f2e98a2b628ba29b82d3b")
