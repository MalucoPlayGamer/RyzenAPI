-- Lua provided by RyzenAPI
-- Game: Suzerain Original Soundtrack

-- MAIN APPLICATION
addappid(1252140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252141, 1, "f06a5be907cd04be8e13a18c3bf99ffee05e8dc7c4caed8fb70467f4a9417097")
addappid(1252142, 1, "2a4738905f8a1927a46867f51b871655b75049b3a068729766ea4848598ab5d9")
