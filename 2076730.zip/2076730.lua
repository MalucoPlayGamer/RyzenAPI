-- 2076730's Lua and Manifest Created by Hubcap Manifest
-- Mud Way
-- Created: July 28, 2026 at 14:08:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2076730) -- Mud Way
-- MAIN APP DEPOTS
addappid(2076731, 1, "ea3af2bf0293f2ee3b0f1e9c585106aee9a5d518e83ecb4e92ebbcb78c128f50") -- Depot 2076731
setManifestid(2076731, "7628088184497374918", 152740671)