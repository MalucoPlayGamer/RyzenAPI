-- Lua provided by RyzenAPI 
-- Game: AppID 1778290
addappid(1778290)
addappid(1778291, 1, "e949180ad74f9abb61c3d5ee5dca8bc7afd767ecd45f80d9382c1a8d4ceca5ef")
