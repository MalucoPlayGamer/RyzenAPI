-- Lua provided by RyzenAPI
-- Game: Summer Nightmare

-- MAIN APPLICATION
addappid(576860)

-- MAIN APP DEPOTS / PACKAGES
addappid(576861, 1, "495399b50aab305c2503b56e66ad5a5ab9259d6db10dd3a3ec3a667a04ed531d")
