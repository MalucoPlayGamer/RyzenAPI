-- Lua provided by RyzenAPI
-- Game: Derby's Tycoon Online

-- MAIN APPLICATION
addappid(4118140)
