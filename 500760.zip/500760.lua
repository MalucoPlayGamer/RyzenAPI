-- Lua provided by SkyAPI 
-- Game: Kuraburo Kai
addappid(500760)
addappid(500761, 1, "907d15ae2f681c31aa124b3d5b9b096f889a47b49b26d8d0ab5ffb1dfe1aea2e")
