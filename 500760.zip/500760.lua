-- Lua provided by RyzenAPI
-- Game: Kuraburo Kai

-- MAIN APPLICATION
addappid(500760)

-- MAIN APP DEPOTS / PACKAGES
addappid(500761, 1, "907d15ae2f681c31aa124b3d5b9b096f889a47b49b26d8d0ab5ffb1dfe1aea2e")

