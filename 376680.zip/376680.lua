-- Lua provided by RyzenAPI
-- Game: Game: Splendor

-- MAIN APPLICATION
addappid(376680)
-- Game: addappid(376680)

-- MAIN APP DEPOTS / PACKAGES
addappid(376681, 1, "fb3bcc11a5773fd71d8a9fe927f602fad50d0316f58c99973955ce12c9494256")
