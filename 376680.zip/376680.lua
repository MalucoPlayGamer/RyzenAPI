-- Lua provided by RyzenAPI
-- Game: Splendor

-- MAIN APPLICATION
addappid(376680)
addappid(798250)
addappid(798252)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(376681, 1, "fb3bcc11a5773fd71d8a9fe927f602fad50d0316f58c99973955ce12c9494256")

