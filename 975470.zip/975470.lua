-- Lua provided by RyzenAPI
-- Game: Game: Silver Chains

-- MAIN APPLICATION
addappid(975470)
-- Game: addappid(975470)

-- MAIN APP DEPOTS / PACKAGES
addappid(975471, 1, "56096191ae443273709d65438a873a7abbd06d2cccc15e1d55b93a1006fbe190")
