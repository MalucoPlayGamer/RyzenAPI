-- Lua provided by RyzenAPI
-- Game: Hex of Steel - DEMO

-- MAIN APPLICATION
addappid(1401140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401142,0,"dd70de4afd2e7a3d705edd1f3a23676ea4188c587f7f7ed4ec1af613351aba1c")

