-- Lua provided by RyzenAPI
-- Game: Game: I and Me

-- MAIN APPLICATION
addappid(399600)
-- Game: addappid(399600)

-- MAIN APP DEPOTS / PACKAGES
addappid(399601, 1, "fed3d85add16fc1620a0cbe64f8b8741d72f37659d106be7d0e38bb1472242dd")
addappid(471450, 0, "5950d5500d90f8aa0170e928242639ca0efc8d647078dc6761a36d16e1c50591")
