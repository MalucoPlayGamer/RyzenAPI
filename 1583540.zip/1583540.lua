-- Lua provided by RyzenAPI
-- Game: Meco Rocket Simulator

-- MAIN APPLICATION
addappid(1583540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583542,0,"6644a230736dc78b33f27665f2767018e1e929fd6f0feb7433b63e58445cd5cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3924680)
