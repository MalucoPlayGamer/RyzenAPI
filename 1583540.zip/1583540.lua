-- Lua provided by RyzenAPI
-- Game: Meco Rocket Simulator

-- MAIN APPLICATION
addappid(1583540)
-- Game: addappid(1583540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583542,0,"6644a230736dc78b33f27665f2767018e1e929fd6f0feb7433b63e58445cd5cc")
