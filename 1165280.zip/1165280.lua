-- Lua provided by SkyAPI 
-- Game: AppID 1165280
addappid(1165280)
addappid(1165281, 1, "1f5b42bee190f0d7877ab0e0c35325d03ff9b1b100ab89b9a64f7620f9933f69")
