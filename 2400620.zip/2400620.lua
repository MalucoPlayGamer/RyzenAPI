-- Lua provided by RyzenAPI
-- Game: 2400620

-- MAIN APPLICATION
addappid(2400620)
-- Game: addappid(2400620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400621, 1, "e76b1dec82363966032c3ed76a6dd3e5d333a5effc6562176ab338fc7902b6e2")
