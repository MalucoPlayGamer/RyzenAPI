-- Lua provided by SkyAPI 
-- Game: Fossilfuel 2 Demo
addappid(2605180)
addappid(2605181, 1, "b00898a34d9540c468d44b1adcbd842961699c391d468e90222646939d4f62fb")
