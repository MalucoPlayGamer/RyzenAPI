-- Lua provided by RyzenAPI
-- Game: YU-NO: A girl who chants love at the bound of this world

-- MAIN APPLICATION
addappid(912450)

-- MAIN APP DEPOTS / PACKAGES
addappid(912451, 1, "fc262d484e76d298f4bcb60355cb70fabe497d0a9b24e41668a086de1167c1a9")
addappid(912452, 1, "7879e5ccddd243fe825dc98d80d103f504283198c3e254892542079ed74a7ed6")
addappid(912453, 1, "7b96fa41aa24176635a6e33a35fb9d793e6d2f9e9bd931423cfa7400aa2657a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1160520)
