-- Lua provided by RyzenAPI
-- Game: Beat Saber - Snoop Dogg - "Gin and Juice"

-- MAIN APPLICATION
addappid(2893450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893450,0,"a30098965dcecb811a39da73aa79db8250bf757bf2cc25b900a49611744737da")

