-- Lua provided by RyzenAPI
-- Game: Math-Havoc

-- MAIN APPLICATION
addappid(4607690) -- Math-Havoc

-- MAIN APP DEPOTS / PACKAGES
addappid(4607691, 1, "25cdb22ee222b83b83dd5476fac957891bf6460ba9e6f8e9b9c63db8942a8863") -- Depot 4607691
