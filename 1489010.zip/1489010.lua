-- Lua provided by RyzenAPI
-- Game: The Picture in The House

-- MAIN APPLICATION
addappid(1489010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489011, 1, "922fd3b138a6f3be50798e56303d050651eba66735090ccbcd17ab022df3f613")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
