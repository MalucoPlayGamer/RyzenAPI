-- Lua provided by RyzenAPI 
-- Game: Wylde Flowers Demo
addappid(1980210)
addappid(1980211, 1, "bed9c6eeed4ba4f296fb3b4a1f600ff363276de0b84565d3706c618d7c73e063")
