-- Lua provided by SkyAPI 
-- Game: FUR Squadron Phoenix Demo
addappid(3186310)
addappid(3186311, 1, "7859efbfc5f306db94281b325722b3435ecead60a10ebf39f690c786354bc085")
