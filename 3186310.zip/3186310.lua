-- Lua provided by RyzenAPI
-- Game: Game: FUR Squadron Phoenix Demo

-- MAIN APPLICATION
addappid(3186310)
-- Game: addappid(3186310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3186311, 1, "7859efbfc5f306db94281b325722b3435ecead60a10ebf39f690c786354bc085")
