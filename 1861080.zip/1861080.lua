-- Lua provided by RyzenAPI
-- Game: 1861080

-- MAIN APPLICATION
addappid(1861080)
-- Game: addappid(1861080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861081, 1, "199ca003617ca4d9d0cb3b6ce5b961c89012c0c927e532d2ad6cd616b02e0802")
