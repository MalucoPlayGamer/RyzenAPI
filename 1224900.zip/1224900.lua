-- Lua provided by RyzenAPI
-- Game: AppID 1224900

-- MAIN APPLICATION
addappid(1224900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224901, 1, "0235e4fad9e867dd506814049a19de4d62083c6f4ec02c5bbdcdd70f0eccf590")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
