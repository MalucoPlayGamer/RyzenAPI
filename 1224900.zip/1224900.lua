-- Lua provided by RyzenAPI 
-- Game: AppID 1224900
addappid(1224900)
addappid(1224901, 1, "0235e4fad9e867dd506814049a19de4d62083c6f4ec02c5bbdcdd70f0eccf590")
