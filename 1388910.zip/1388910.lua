-- Lua provided by RyzenAPI
-- Game: Deadly Forest

-- MAIN APPLICATION
addappid(1388910)
-- Game: addappid(1388910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388911, 1, "6bf2213b878b434b003c3c3e4c6c68fc2f2f8a326524558573623af43fb3367e")
