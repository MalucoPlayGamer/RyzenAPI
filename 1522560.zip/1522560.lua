-- Lua provided by RyzenAPI
-- Game: 100 hidden mice

-- MAIN APPLICATION
addappid(1522560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522561, 1, "b378d34c4f11950fd70bfff4d944d0e6fd5c8d9d960104265beb69710f17b5b1")
