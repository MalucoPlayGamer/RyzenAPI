-- Lua provided by RyzenAPI
-- Game: Game: Sunlight

-- MAIN APPLICATION
addappid(1451120)
-- Game: addappid(1451120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451121, 1, "0050bd4eaf311db16953f1ee2408431ec4e6b2e05149f018cefa1ca8debe0d9b")
