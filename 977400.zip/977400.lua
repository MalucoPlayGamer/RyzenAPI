-- Lua provided by RyzenAPI
-- Game: AppID 977400

-- MAIN APPLICATION
addappid(977400)
-- Game: addappid(977400)

-- MAIN APP DEPOTS / PACKAGES
addappid(977401, 1, "246d42fd812942fc613bd78c8c0996dc352b83c8f461b3ab695ec033ad51c770")
addappid(977402, 1, "da6635ba68ebc2e39dd2145aa2d6c4c410a955d7afca730d30b9c557faaa9015")
