-- Lua provided by RyzenAPI
-- Game: CopperCube 6 Game Engine

-- MAIN APPLICATION
addappid(857350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(857351,0,"f51f21308a009d32aeb754c6139bd8df8742b893e3d4f0ecaeb6a5a7d70da531")
addappid(857380,0,"65b89825409f10a8e0f26ffaa9a5a748501cd4857dd362913bc8961ecd8de5a4")
addappid(857381,0,"73aa7a5bc3410e764b878454a2fd3939c1b167a7e802551702151c16cf59fc10")

