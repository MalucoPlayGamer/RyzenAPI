-- Lua provided by RyzenAPI
-- Game: CopperCube 6 Game Engine

-- MAIN APPLICATION
addappid(857350)

-- MAIN APP DEPOTS / PACKAGES
addappid(857351, 1, "f51f21308a009d32aeb754c6139bd8df8742b893e3d4f0ecaeb6a5a7d70da531")
