-- Lua provided by RyzenAPI
-- Game: 956760

-- MAIN APPLICATION
addappid(956760)
-- Game: addappid(956760)

-- MAIN APP DEPOTS / PACKAGES
addappid(956760,0,"f67695cdc5ee74559ae16e8a3a3e7159f45bc14db2e251a008c0e10a989f391e")
