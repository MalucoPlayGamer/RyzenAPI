-- Lua provided by RyzenAPI
-- Game: Sex Hotel Simulator 🏩

-- MAIN APPLICATION
addappid(2450130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450131, 1, "f792df5c83448f8cf471e6142a2dac64462114abc1231c0e825120a1c7c4382e")

