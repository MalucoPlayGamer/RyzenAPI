-- Lua provided by RyzenAPI
-- Game: FUSER™ - Alesso & Armin van Buuren - "Leave A Little Love"

-- MAIN APPLICATION
addappid(1620951)
-- Game: addappid(1620951)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620951,0,"af49cfd8a8bdacadafd967d4532756cc4cb68b8fd4859761d265753d841c5fb2")
