-- Lua provided by RyzenAPI
-- Game: Hazy Monochrome Wand

-- MAIN APPLICATION
addappid(2460210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460212,0,"7b5e74cf384c90cd5c6a2ee6f11e6ecbd7bcbc39c65eb5eb7abb47f81e2ec1f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
