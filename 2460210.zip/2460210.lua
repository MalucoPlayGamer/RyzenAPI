-- Lua provided by RyzenAPI
-- Game: 2460210

-- MAIN APPLICATION
addappid(2460210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460212,0,"7b5e74cf384c90cd5c6a2ee6f11e6ecbd7bcbc39c65eb5eb7abb47f81e2ec1f5")

