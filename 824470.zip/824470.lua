-- Lua provided by RyzenAPI
-- Game: My Maid Girlfriend

-- MAIN APPLICATION
addappid(824470)

-- MAIN APP DEPOTS / PACKAGES
addappid(824473,0,"461ed3622f52bc0bb903e0b7af9c9700d8ba6e7001879d7549cf79ac628539b0")

