-- Lua provided by RyzenAPI
-- Game: Dead Age

-- MAIN APPLICATION
addappid(363930)

-- MAIN APP DEPOTS / PACKAGES
addappid(363931, 1, "9c7f6e3c67e3cea7e7154a18ab18667dad632de03006366d9e879e0b7b2140ce")
addappid(363932, 1, "276cd2c9d41b2b06c2a22fd0418b9f712a7d5c366fbeebf96b46c089130214f9")
addappid(363933, 1, "896d1131bcd0a4b62661630386dccb24c9c2f2a4bf02c703defbe00f551ba4e7")
addappid(1330410, 0, "8f7246bdac676faa81ed17e595c32d9488608a00a379e35123ab2b0cb20162a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
