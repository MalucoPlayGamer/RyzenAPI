-- Lua provided by RyzenAPI
-- Game: Game: Dead Age

-- MAIN APPLICATION
addappid(363930)
-- Game: addappid(363930)

-- MAIN APP DEPOTS / PACKAGES
addappid(363931, 1, "9c7f6e3c67e3cea7e7154a18ab18667dad632de03006366d9e879e0b7b2140ce")
addappid(363932, 1, "276cd2c9d41b2b06c2a22fd0418b9f712a7d5c366fbeebf96b46c089130214f9")
addappid(363933, 1, "896d1131bcd0a4b62661630386dccb24c9c2f2a4bf02c703defbe00f551ba4e7")
addappid(1330410, 0, "8f7246bdac676faa81ed17e595c32d9488608a00a379e35123ab2b0cb20162a1")
