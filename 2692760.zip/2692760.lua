-- Lua provided by RyzenAPI
-- Game: ReHarmony

-- MAIN APPLICATION
addappid(2692760)
-- Game: addappid(2692760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692761, 1, "531297183889a648ddfdc7d45c49c8974cc0a2e6511232c6bb897a2a07c358c0")
