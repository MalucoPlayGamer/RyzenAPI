-- Lua provided by RyzenAPI
-- Game: Gunpowder

-- MAIN APPLICATION
addappid(375170)
-- Game: addappid(375170)

-- MAIN APP DEPOTS / PACKAGES
addappid(375172,0,"fe15d70a266a377cfddb0639b8e5946bbc0243f79d78f0393236f64932853b83")
addappid(375173,0,"ca3737b04f58ddb71cfef98f4289148792f59fc308eb1faf4467f46ddc0faf04")
addappid(375174,0,"8f7c6a2f95a137dc695abfbc3440b032049d0988396515a855cbce3d3a018f83")
