-- Lua provided by RyzenAPI
-- Game: Dungeons and Dragons: Daggerdale

-- MAIN APPLICATION
addappid(99100)

-- MAIN APP DEPOTS / PACKAGES
addappid(99101, 1, "07d5d3bf745db18ba2e499aa4302faaf18f6c851205640ab18f60fa65cac341d")
addappid(99103, 1, "dcc849aea61dc354948aa6322559d48eafba721a10070dcdd24c10011082048b")

