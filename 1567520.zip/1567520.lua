-- Lua provided by SkyAPI 
-- Game: Blackwind
addappid(1567520)
addappid(1567521, 1, "a53024fa033befea2802d8715ea8cf377095edd0adacb5f068761d0f639eb4d6")
