-- Lua provided by RyzenAPI
-- Game: Cosmic Cursor

-- MAIN APPLICATION
addappid(2611750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2611751, 1, "248ecf18b917f44898975c7072a69cd6e0e3f7b833bc0fe5b8fb2a8401ce672b")
