-- Lua provided by RyzenAPI
-- Game: Cybercube battle

-- MAIN APPLICATION
addappid(1431620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431621, 1, "0d6f0aeac9bc362001050bf98b34a9da0b51a2c14882744b0b5e6ce72edf7392")

