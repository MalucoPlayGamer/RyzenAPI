-- Lua provided by RyzenAPI
-- Game: Some Distant Memory

-- MAIN APPLICATION
addappid(824850)
addappid(1159140)

-- MAIN APP DEPOTS / PACKAGES
addappid(824851, 1, "b76f20033ee81c5bf229c59cad56f91d5d586955578586877f6e9dc2af228ebd")

