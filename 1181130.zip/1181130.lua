-- Lua provided by RyzenAPI
-- Game: Play with NEKO

-- MAIN APPLICATION
addappid(1181130)
-- Game: addappid(1181130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181131, 1, "edb4409ae5796455aca0af584134fd45658b10ed088265b4699760777be28664")
