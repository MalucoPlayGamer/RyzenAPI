-- Lua provided by RyzenAPI
-- Game: Yanpai Simulator

-- MAIN APPLICATION
addappid(990850)

-- MAIN APP DEPOTS / PACKAGES
addappid(990851, 1, "18615aaf9ddab92264029d0914c5ab1da8dbaa5ae1e3162243b4ee3219a64cfe")

