-- Lua provided by RyzenAPI
-- Game: Barry the Bunny

-- MAIN APPLICATION
addappid(1373700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373701, 1, "4699997be8fc5c0c369f1da6272fee00113f9c95fe47bf4a331f376329344cee")
