-- Lua provided by RyzenAPI
-- Game: Cattails: Wildwood Story

-- MAIN APPLICATION
addappid(1882500)
-- Game: addappid(1882500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882501, 1, "abb69fd4cd37c84153990a5f70ac601107cd56733b9f80fbf7ac73a869bc2e42")
addappid(1882502, 1, "c6a4eaed25d79841f426e54391dfa287e279cd6c047f4a00772455f87a01060d")
