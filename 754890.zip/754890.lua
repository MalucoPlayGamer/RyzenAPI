-- Lua provided by RyzenAPI
-- Game: Firmament

-- MAIN APPLICATION
addappid(754890)
-- Game: addappid(754890)

-- MAIN APP DEPOTS / PACKAGES
addappid(754891, 1, "e0f7bde13933f549c87ed878514e16dad8af0eb2755a92856e00d5eb22d64966")
addappid(754893, 1, "be56c2254bb63870cf54218a9ec6550991a4247d79288a55ad706172fabbaea3")
