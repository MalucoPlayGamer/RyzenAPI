-- Lua provided by RyzenAPI
-- Game: Firmament

-- MAIN APPLICATION
addappid(754890)
addappid(2419480)
addappid(2419481)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(754891, 1, "e0f7bde13933f549c87ed878514e16dad8af0eb2755a92856e00d5eb22d64966")
addappid(754893, 1, "be56c2254bb63870cf54218a9ec6550991a4247d79288a55ad706172fabbaea3")
