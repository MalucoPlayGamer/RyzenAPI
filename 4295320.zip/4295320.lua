-- 4295320's Lua and Manifest Created by Hubcap Manifest
-- Crown Of Silence
-- Created: August 06, 2026 at 11:58:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4295320) -- Crown Of Silence
-- MAIN APP DEPOTS
addappid(4295321, 1, "4a4a6ccc05f22a8196314aa90f6bdeb97609fb095d31015ae3daa1294da6ad3a") -- Depot 4295321
setManifestid(4295321, "2317137553793411373", 974830932)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4295322) -- Depot 4295322 (empty depot)