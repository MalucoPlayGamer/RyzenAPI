-- Lua provided by RyzenAPI
-- Game: Crown Of Silence

-- MAIN APPLICATION
addappid(4295320) -- Crown Of Silence
-- addappid(4295322) -- Depot 4295322 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4295321, 1, "4a4a6ccc05f22a8196314aa90f6bdeb97609fb095d31015ae3daa1294da6ad3a") -- Depot 4295321

