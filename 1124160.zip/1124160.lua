-- Lua provided by RyzenAPI
-- Game: VR Giants

-- MAIN APPLICATION
addappid(1124160)
-- Game: addappid(1124160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124161, 1, "8f9421d917da2b2a01183c3a3d9b8b45668dea49ec41c5ee56be1e46e52e4ae3")
