-- Lua provided by RyzenAPI
-- Game: 2081670

-- MAIN APPLICATION
addappid(2081670)
-- Game: addappid(2081670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081671, 1, "3860a537618586ed769620b8f183dd1e9a38edf085e59eacaa346de6e769bccf")
