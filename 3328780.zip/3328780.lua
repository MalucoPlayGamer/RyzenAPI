-- Lua provided by RyzenAPI
-- Game: SEDAP! A Culinary Adventure Demo

-- MAIN APPLICATION
addappid(3328780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328781, 1, "de68bc5d083e1389d555baf43f7b25519bbd8b8735ec574aaebe014c4c0d449f")
