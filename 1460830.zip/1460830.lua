-- Lua provided by RyzenAPI
-- Game: 6 Seasons And A Game

-- MAIN APPLICATION
addappid(1460830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1460831, 1, "a10998deee07c1d093d138d5a8b1319325c09d3b6c26e2e38669093698fa1363")