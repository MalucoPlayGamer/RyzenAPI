-- Lua provided by RyzenAPI
-- Game: Cross of Auria

-- MAIN APPLICATION
addappid(764180)

-- MAIN APP DEPOTS / PACKAGES
addappid(764181, 1, "2d2205bae6c1ae4a46d0a1358ceae3db36885b162e309ee7ad377f4a7661ec6e")
addappid(764182, 1, "ecc6e4eba3f9edd1c864758a0acc6c90ebebb6948802afef2597a42160a68e5a")
addappid(1297700, 0, "6da17050918cecab7266991653a89c9a40537144af34cebb7a5132e8adecdfc4")
addappid(1383790, 0, "63be367166f44b72bb553f1f0f7b81316f268143724701e81ae24debd4316ece")
addappid(1383791, 0, "9e85022b6717cfb97b98799e6a52d3c205806391aaa9e44c54676daeb7db4d98")
addappid(1383792, 0, "e03fe7d16d40ee33bbf9338cb8552bedd3b261eeb8f6440bea814f2c0c019817")
addappid(1386390, 0, "1f07d2b976d3249500c49fddea7f2327ca529ae8013d356f6c5d4999aa9badbf")
addappid(1749290, 0, "7297219736f194b395be2049eff14b20a9e12bc5bd44d720ad70c11a3276d79e")
addappid(1840980, 0, "4370af94b45f398b2bb99450a80fa558c4ffcd47dc9acbff9d8823ae08c44640")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1459600)
addappid(1730481)
addappid(1730482)
addappid(2110310)
