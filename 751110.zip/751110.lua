-- Lua provided by RyzenAPI
-- Game: OVERVIEW (A Walk Through The Universe)

-- MAIN APPLICATION
addappid(751110)

-- MAIN APP DEPOTS / PACKAGES
addappid(751111, 1, "327910bfab145618e0d61fed263a25c2d16140c67cf84765c0668415ab97a627")

