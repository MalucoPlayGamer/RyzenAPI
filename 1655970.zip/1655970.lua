-- Lua provided by SkyAPI 
-- Game: Erotic Jigsaw Puzzle 3
addappid(1655970)
addappid(1655971, 1, "014998d354229891755c2016b0548b3e812e825657be1ae59cb4c1aef91a2ba9")
addappid(1657850, 0, "52af4d1e7f38dad4199040971ada5e1be97f0bb4ea22b987c657975e8d7378e0")
