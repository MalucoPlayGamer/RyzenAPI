-- Lua provided by RyzenAPI
-- Game: addappid(1057130)

-- MAIN APPLICATION
addappid(1057130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057131, 1, "89312ca656f226f436afe9e1c266d88d53047eacdd1e9ce5e4c1983f4a75237d")
