-- Lua provided by RyzenAPI
-- Game: Sex Story - Ruby and Hunter - Episode 1

-- MAIN APPLICATION
addappid(2460570)
-- Game: addappid(2460570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460571, 1, "a66b967509bd666d8171c4535eaeea5de2f66ba1e73064675ee95089a5c8bd85")
