-- Lua provided by RyzenAPI
-- Game: Game: AppID 414110

-- MAIN APPLICATION
addappid(414110)
-- Game: addappid(414110)

-- MAIN APP DEPOTS / PACKAGES
addappid(414111, 1, "ec1b843e378147610cc549500a351de09321e98d89929b4eeb0ecb7a44303df6")
