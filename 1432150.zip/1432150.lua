-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432150,0,"bf0b8cd2d3e424b166d45d393903390651d787a41dd3e77bfe596f4e95b71500")

