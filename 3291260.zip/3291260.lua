-- Lua provided by RyzenAPI
-- Game: Craft & Conquer

-- MAIN APPLICATION
addappid(3291260)
-- Game: addappid(3291260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291261, 1, "5d928425239c9c43f0a2d65aeb48116cc2e3cfa280c698e537dc2eea68524c85")
