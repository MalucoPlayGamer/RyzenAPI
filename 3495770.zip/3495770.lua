-- Lua provided by RyzenAPI
-- Game: Sex Apartment 💫 - Wallpapers Pack

-- MAIN APPLICATION
addappid(3495770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495770,0,"738016fd9bf298bf67c21a717944bdd2d6e568e13c1c6b9189bc67f6e333a03e")

