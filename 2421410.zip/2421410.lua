-- Lua provided by RyzenAPI
-- Game: Cyber Manhunt 2: New World - The Hacking Simulator

-- MAIN APPLICATION
addappid(2421410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421411, 1, "4129c0dfb7314a4a7464996cf15ad5ce4d98037edd8d2dbdce1370681f078042")
addappid(2421412, 1, "de9d565e3be8af53510237991c16dab96fb14373b032f085124ec01a67847e28")
