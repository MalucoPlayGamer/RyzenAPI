-- Lua provided by RyzenAPI
-- Game: addappid(1436800)

-- MAIN APPLICATION
addappid(1436800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436801, 1, "afa6f650b4b082e9c3a5e53ae48a563a23b8a07eb05acee177afcafe37e580bd")
