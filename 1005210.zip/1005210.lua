-- Lua provided by RyzenAPI
-- Game: Game: AppID 1005210

-- MAIN APPLICATION
addappid(1005210)
-- Game: addappid(1005210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005211, 1, "fe4b284c060f927cf46d046114fa1720080476aa346bd10fa1a02ac139902a80")
