-- Lua provided by SkyAPI 
-- Game: AppID 1005210
addappid(1005210)
addappid(1005211, 1, "fe4b284c060f927cf46d046114fa1720080476aa346bd10fa1a02ac139902a80")
