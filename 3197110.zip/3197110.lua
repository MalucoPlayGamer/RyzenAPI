-- Lua provided by RyzenAPI
-- Game: addappid(3197110)

-- MAIN APPLICATION
addappid(3197110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197111, 1, "78dd60c3ebcf9318165f39b6af42f7a1d7caf2a2586aba0bca5ac3fcf26060df")
