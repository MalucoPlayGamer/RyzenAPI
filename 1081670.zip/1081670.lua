-- Lua provided by RyzenAPI 
-- Game: Fitforce
addappid(1081670)
addappid(1081671, 1, "2b1a753b90b79ad9ef1f57de99566976359f03cc4e1b71a16d2259a4cd8f8089")
addappid(1081672, 1, "28c81881012c840773d1e16d83aa5c237c7ee95010502b9927146fad64c284f9")
