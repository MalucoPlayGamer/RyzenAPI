-- Lua provided by RyzenAPI
-- Game: Kare wa Kanojo

-- MAIN APPLICATION
addappid(1024790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1024791, 1, "9b1ea8c28fde4875b9fb5ef13685f0d932a203883d9c7275b12a931bdb4cecd3")

