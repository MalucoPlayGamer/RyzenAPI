-- Lua provided by RyzenAPI
-- Game: addappid(1024790)

-- MAIN APPLICATION
addappid(1024790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024791, 1, "9b1ea8c28fde4875b9fb5ef13685f0d932a203883d9c7275b12a931bdb4cecd3")
