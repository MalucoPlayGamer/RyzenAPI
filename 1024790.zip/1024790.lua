-- Lua provided by SkyAPI 
-- Game: Kare wa Kanojo
addappid(1024790)
addappid(1024791, 1, "9b1ea8c28fde4875b9fb5ef13685f0d932a203883d9c7275b12a931bdb4cecd3")
