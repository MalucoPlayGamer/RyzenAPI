-- Lua provided by RyzenAPI
-- Game: Game: HerrAnwalt: Lawyers Legacy

-- MAIN APPLICATION
addappid(2179290)
-- Game: addappid(2179290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179291, 1, "e27b2a99992f3991e10dae9ca31102dcb1c29aba1609739cfcb81c752f57b306")
