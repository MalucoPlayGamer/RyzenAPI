-- Lua provided by RyzenAPI
-- Game: AppID 469890

-- MAIN APPLICATION
addappid(469890)

-- MAIN APP DEPOTS / PACKAGES
addappid(469891, 1, "41d3d28aff06bb125f1f2443bbc8c6888864cff8ff7c38ae6e17441239b2efd2")
