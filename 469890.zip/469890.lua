-- Lua provided by SkyAPI 
-- Game: AppID 469890
addappid(469890)
addappid(469891, 1, "41d3d28aff06bb125f1f2443bbc8c6888864cff8ff7c38ae6e17441239b2efd2")
