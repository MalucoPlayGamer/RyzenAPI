-- Lua provided by RyzenAPI
-- Game: Romance of the Three Kingdoms IX with Power Up Kit

-- MAIN APPLICATION
addappid(628050)

-- MAIN APP DEPOTS / PACKAGES
addappid(628051, 1, "3459b68f1423d3f4030613d46b7df9db4c82fbb41d610f40ed6966d0e4b1ad8f")
addappid(628052, 1, "0aba924f9bf1313503897b6087357f70e4e0ba43d198994aa6c572f261a436e1")

