-- Lua provided by RyzenAPI
-- Game: The Vanishing of Ethan Carter

-- MAIN APPLICATION
addappid(258520)
addappid(319930)

-- MAIN APP DEPOTS / PACKAGES
addappid(258521, 1, "f62f6b10d1eb69c1edc93703ccd5fc419096c248f7b2c17f9da53580fc1c8431")
addappid(258523, 1, "6dbfbb3d7c9c8050dbfba80049c5c6ad72a304fee07ba5c9371006023f345682")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
