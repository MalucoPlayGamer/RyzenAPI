-- Lua provided by RyzenAPI
-- Game: Chronicles from the Abyss

-- MAIN APPLICATION
addappid(3698640)
-- Game: addappid(3698640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3698641, 1, "798b09b155dbc7944c2b0ef09d0ca2bf4ab4db1b7811d8254518362902be82c7")
