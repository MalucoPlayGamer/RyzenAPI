-- Lua provided by RyzenAPI
-- Game: 582990

-- MAIN APPLICATION
addappid(582990)
-- Game: addappid(582990)

-- MAIN APP DEPOTS / PACKAGES
addappid(582991, 1, "a7bcf762de7cd7bac52114195831b16e2664ce7fa1f497b29ed9b08b74c14c78")
