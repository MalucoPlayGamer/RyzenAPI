-- Lua provided by RyzenAPI
-- Game: Game: AppID 923370

-- MAIN APPLICATION
addappid(923370)
-- Game: addappid(923370)

-- MAIN APP DEPOTS / PACKAGES
addappid(923371, 1, "272cbdb3fcdb86165b15266edb194b6089da298697ca0f6ad8420160c1dcb219")
addappid(923372, 1, "fc5da3be2e0f3ebdf0139b674d2a3773f9b9fdbadd59aa4e9f9b325d258bda32")
addappid(923373, 1, "09468bd1812f1a500ffd1e79bf0f5d634867742e5fa35896eb5ec9f2a21b2a34")
