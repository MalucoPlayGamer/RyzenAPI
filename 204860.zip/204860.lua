-- Lua provided by RyzenAPI
-- Game: Men of War: Condemned Heroes

-- MAIN APPLICATION
addappid(204860)

-- MAIN APP DEPOTS / PACKAGES
addappid(204861, 1, "a806400692df6c9ab89338e27f0f6f82e61d14622a55545999910ba293ebd762")
addappid(204862, 1, "6464bd8347e9dcda2eb8fed7d04fcd87e1cae1684c551a3a93d31771a20cb92b")
addappid(204863, 1, "caf2bae0942ac59a20958fce29ec8e56764a7393ec4b80f27b2718db6c73761b")
addappid(204864, 1, "28d1bd42f06cea991bc3321bc1c5c98dfbfb0340a7bad19884783ef78c74f324")
addappid(204865, 1, "4277a57a0128ecb9b9881adb8bc4268745532bb97cecf3fda8f6a411baed296a")
addappid(204866, 1, "e6ad39cc0a87dc3e5ffbd4e30700afa75342c1150fb8662281643c95f608c088")
addappid(204867, 1, "4fa20655b4cdd23e4aa4151819b91ddb4e15ba73458746fabb2c9eab562f3fd3")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

