-- Lua provided by RyzenAPI
-- Game: Ninja Stealth

-- MAIN APPLICATION
addappid(485450)
addappid(552950)

-- MAIN APP DEPOTS / PACKAGES
addappid(485451, 1, "79ef5f961b6b2f27afe7eeaeea35370d07c6d4961f711d36454f0d25f907e41c")
addappid(485452, 1, "63c28429a9b8bae8901b66b368b1079bc7ff67c623aa00918fb1b4e8ae12da3a")

