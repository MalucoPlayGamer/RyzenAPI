-- Lua provided by RyzenAPI
-- Game: Game: Spectro

-- MAIN APPLICATION
addappid(719520)
-- Game: addappid(719520)

-- MAIN APP DEPOTS / PACKAGES
addappid(719521, 1, "99c9202ba6e706f804fb7ce7a5d5ed22b9591236b67f138457cb3bd6e504c6db")
