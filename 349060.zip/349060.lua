-- Lua provided by RyzenAPI
-- Game: 349060

-- MAIN APPLICATION
addappid(349060)
-- Game: addappid(349060)

-- MAIN APP DEPOTS / PACKAGES
addappid(349061, 1, "9867e53d6843aa522b18f33e603db3a9b2d8673619563f00cf1bdbc9b929fa54")
