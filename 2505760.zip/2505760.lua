-- Lua provided by RyzenAPI
-- Game: addappid(2505760)

-- MAIN APPLICATION
addappid(2505760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505761, 1, "69d1aaea605bf89aae0485bf43a0899c4ad74a9d3acc1c9bc78e817082b87c8e")
