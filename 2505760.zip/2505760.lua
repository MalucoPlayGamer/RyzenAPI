-- Lua provided by RyzenAPI
-- Game: プロ野球スピリッツ myBALLPARK

-- MAIN APPLICATION
addappid(2505760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2505761, 1, "69d1aaea605bf89aae0485bf43a0899c4ad74a9d3acc1c9bc78e817082b87c8e")

