-- Lua provided by RyzenAPI
-- Game: Juice FX

-- MAIN APPLICATION
addappid(1046770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046771, 1, "aa8f6846aa9be141bf7bd96c1156f83dafb8169002859fcc0dcf22f01ac27020")

