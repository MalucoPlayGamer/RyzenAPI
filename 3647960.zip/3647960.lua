-- Lua provided by RyzenAPI
-- Game: 森林王国的试炼

-- MAIN APPLICATION
addappid(3647960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3647961, 1, "591f084f0c54ddb790f0d588cfebcd0479a39322360bf3f8b83062f4ece6f3e9")

