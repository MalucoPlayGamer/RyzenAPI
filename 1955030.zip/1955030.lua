-- Lua provided by RyzenAPI 
-- Game: SCP: EVENT CLASSIFIED
addappid(1955030)
addappid(1955031, 1, "b69bfad6726d5251f0cf12650b4772039a75d5d4054ba802b572b6888c12e7b6")
