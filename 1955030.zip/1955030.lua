-- Lua provided by RyzenAPI
-- Game: SCP: EVENT CLASSIFIED

-- MAIN APPLICATION
addappid(1955030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955031, 1, "b69bfad6726d5251f0cf12650b4772039a75d5d4054ba802b572b6888c12e7b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
