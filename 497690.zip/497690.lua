-- Lua provided by RyzenAPI
-- Game: 497690

-- MAIN APPLICATION
addappid(497690)
-- Game: addappid(497690)

-- MAIN APP DEPOTS / PACKAGES
addappid(497691, 1, "ab65d8342dc3514da0cf475ea9f868d1292c1e8a98382313026c5236a81720e6")
