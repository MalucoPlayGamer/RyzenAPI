-- Lua provided by RyzenAPI
-- Game: Before Nightfall: Summertime

-- MAIN APPLICATION
addappid(1362860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362861, 1, "86d347094809a1d1639c23e357d3d3484d689f2d65ad8a2395277d640e86c7f2")

