-- Lua provided by RyzenAPI
-- Game: Before Nightfall: Summertime

-- MAIN APPLICATION
addappid(1362860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1362861, 1, "86d347094809a1d1639c23e357d3d3484d689f2d65ad8a2395277d640e86c7f2")

