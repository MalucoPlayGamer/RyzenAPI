-- Lua provided by RyzenAPI
-- Game: Supposedly Wonderful Future

-- MAIN APPLICATION
addappid(719210)

-- MAIN APP DEPOTS / PACKAGES
addappid(719211,0,"d0e3cc9a67bab579a481478affbd12f3bfb040c88c14118daf8194bb5dedec18")

