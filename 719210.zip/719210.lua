-- Lua provided by RyzenAPI
-- Game: Supposedly Wonderful Future

-- MAIN APPLICATION
addappid(719210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(719211,0,"d0e3cc9a67bab579a481478affbd12f3bfb040c88c14118daf8194bb5dedec18")

