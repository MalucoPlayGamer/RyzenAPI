-- Lua provided by RyzenAPI 
-- Game: Just Keep Digging
addappid(2974660)
addappid(2974661, 1, "8c0d1f74ee3fc6ed76ce7348fc518c70a30772054c17ba40b5581886af72e3cc")
