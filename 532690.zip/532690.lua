-- Lua provided by RyzenAPI
-- Game: Game: Neo ATLAS 1469

-- MAIN APPLICATION
addappid(532690)
-- Game: addappid(532690)

-- MAIN APP DEPOTS / PACKAGES
addappid(532691, 1, "f481d52b93f0d6a22bd755fd77f71dad5ac3af5bb9e132cf7584246c20b165f1")
