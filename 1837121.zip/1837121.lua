-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - DorapixelMapChips - Modern JP Interiors

-- MAIN APPLICATION
addappid(1837121)
-- Game: addappid(1837121)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837121,0,"4eeed47ae5694a678af87570148abd888355f3d72c8a7b4619e41f6b1cc1940b")
