-- Lua provided by RyzenAPI
-- Game: Typing Bullets

-- MAIN APPLICATION
addappid(2429620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429621, 1, "ef9b1919042b7246ca57743ad0e836ccecf0507bfb05bcb3a3266cdf48bc769d")

