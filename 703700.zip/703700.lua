-- Lua provided by RyzenAPI
-- Game: Our End of the World

-- MAIN APPLICATION
addappid(703700)
-- Game: addappid(703700)

-- MAIN APP DEPOTS / PACKAGES
addappid(703701, 1, "a715357a3e82bac60a246a8ccbabe7507e1ce96db09cec24aeaae028a9733411")
addappid(703702, 1, "016a5439648df35ff3d2a19a582ddc0d2cd3eafc4053216d0c8449adb6b05dd8")
