-- Lua provided by SkyAPI 
-- Game: Jaded
addappid(1932570)
addappid(1932571, 1, "d4a7c4e08fc111d9981aa1f767ad9ab90508e704065a302f6a77c7a1be0a5b66")
addappid(1932572, 1, "08f36137f3211cc580716c65c99bc5705986d7dd5f8334fe2b409ea243fb2946")
