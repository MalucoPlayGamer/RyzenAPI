-- Lua provided by RyzenAPI
-- Game: UFO: Afterlight - Old Version

-- MAIN APPLICATION
addappid(7500)

-- MAIN APP DEPOTS / PACKAGES
addappid(7501, 1, "b04b3d4b9cb86c8e096598e18bdab1693752eaf070d82a3cc4fb9b3dea4b9414")
addappid(7502, 1, "24ebf64c760bce60dc80b65f5073e7eb0abd349ee2dfdab7a63cb8692dd1c050")
addappid(7503, 1, "9cb80c84503ec8680dd248010784dff2ad73f019b60fc57ac2253af58672b940")
addappid(7504, 1, "06592a79de183ad1bf68935f2a383ca203566079d04cc51beb8adacf2255f11c")
addappid(7505, 1, "710b9a0d62013817b55d0c9ad78e796260a48007b7cffb36ac6f6d6ee350ed19")
addappid(7506, 1, "e80eeb11ed692f09ab47a8165ab7e996717d188f73f123c0a60d9c062dc0d818")
