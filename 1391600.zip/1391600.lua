-- Lua provided by RyzenAPI 
-- Game: AppID 1391600
addappid(1391600)
addappid(1391601, 1, "f375f487bf95803aea0e01770f0d9d73f5b393bb101347fcabc83ae4d9a94d65")
