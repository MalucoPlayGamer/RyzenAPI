-- Lua provided by RyzenAPI
-- Game: FPV Freerider Recharged - Custom Levels Pack

-- MAIN APPLICATION
addappid(849540)

-- MAIN APP DEPOTS / PACKAGES
addappid(849541, 1, "f62c870a9ecfb42e4a327502aad27d66fc77d1053aeacaf7a2add2332ef881d1")

