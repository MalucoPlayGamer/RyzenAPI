-- Lua provided by RyzenAPI
-- Game: SULFUR Demo

-- MAIN APPLICATION
addappid(2845200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845201, 1, "3d47a63d0ff16cc964ca49da96b4da032ba8ddbb9af6f7cc55d57267be323d18")
