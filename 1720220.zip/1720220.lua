-- Lua provided by RyzenAPI
-- Game: 1720220

-- MAIN APPLICATION
addappid(1720220)
addappid(1720221)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720222,0,"afd806ae8db7e5bb455beb047627f1d4e713675620bc185fd037c36f4b683cc1")

