-- Lua provided by RyzenAPI
-- Game: Foot washing and massage for DIY girls in VR

-- MAIN APPLICATION
addappid(1719910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719910,0,"048bd6c6e4f7f3364f74623d3f2639fb1729c7803bd2b960994e6a360e67552b")

