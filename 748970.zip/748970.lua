-- Lua provided by RyzenAPI
-- Game: Zen Chess: Mate in One

-- MAIN APPLICATION
addappid(748970)
-- Game: addappid(748970)

-- MAIN APP DEPOTS / PACKAGES
addappid(748971, 1, "a835bfab1b3fdcb246fd30d4be9b8d05038324d4f9e573301a23af0587cc0dec")
