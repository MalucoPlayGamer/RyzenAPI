-- Lua provided by RyzenAPI
-- Game: addappid(616090)

-- MAIN APPLICATION
addappid(616090)

-- MAIN APP DEPOTS / PACKAGES
addappid(616091, 1, "62809bfe3410f1c8b0572e721a4d758efc5c078f463775d19496f904a97ff09d")
