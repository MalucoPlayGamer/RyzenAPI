-- Lua provided by RyzenAPI
-- Game: Game: Hellgate VR

-- MAIN APPLICATION
addappid(1576910)
-- Game: addappid(1576910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576911, 1, "b72208b153986d1c8baf5c9867a20ad01441653535f37d92a543bab041bbf032")
