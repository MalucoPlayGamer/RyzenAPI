-- Lua provided by RyzenAPI
-- Game: Hellgate VR

-- MAIN APPLICATION
addappid(1576910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1576911, 1, "b72208b153986d1c8baf5c9867a20ad01441653535f37d92a543bab041bbf032")

