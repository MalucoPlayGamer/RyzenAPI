-- Lua provided by SkyAPI 
-- Game: Ghost Marriage Matchmaking - Original Soundtrack
addappid(1894900)
addappid(1894901, 1, "3492797f5835edc30af0451744efa97d14507fd60bed784442cf2527a27f2823")
addappid(1894902, 1, "8d2a671f25f42063cb06d7ad69a1ab8de47b34121b952d09d44114747f8e729d")
