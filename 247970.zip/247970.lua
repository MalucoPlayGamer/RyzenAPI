-- 247970's Lua and Manifest Created by Hubcap Manifest
-- Korea. IL-2 Series
-- Created: August 04, 2026 at 14:28:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(247970) -- Korea. IL-2 Series
-- MAIN APP DEPOTS
addappid(247971, 1, "38512b456adc44f3e9fa5db22ae548f2712e75ba1edab033d8d65c88f3a43909") -- Depot 247971
setManifestid(247971, "6433861539579977396", 40225459251)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5026020) -- Korea. IL-2 Series F-84E Thunderjet Collector Plane
addappid(5026030) -- Korea. IL-2 Series Lavochkin La-11 Collector Plane
addappid(5026460) -- Korea. IL-2 Series Unique Aerobatic Team Liveries