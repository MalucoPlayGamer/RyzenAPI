-- Lua provided by RyzenAPI
-- Game: Korea. IL-2 Series

-- MAIN APPLICATION
addappid(247970) -- Korea. IL-2 Series
addappid(5026020) -- Korea. IL-2 Series F-84E Thunderjet Collector Plane
addappid(5026030) -- Korea. IL-2 Series Lavochkin La-11 Collector Plane
addappid(5026460) -- Korea. IL-2 Series Unique Aerobatic Team Liveries

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(247971, 1, "38512b456adc44f3e9fa5db22ae548f2712e75ba1edab033d8d65c88f3a43909") -- Depot 247971

