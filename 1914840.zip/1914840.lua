-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 × NEKO WORKS: NEKOPARA - Azuki casual clothes & maid clothes set

-- MAIN APPLICATION
addappid(1914840)
-- Game: addappid(1914840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914841, 1, "e424b2a86edc9c013e746f53b7e621c1b0c109a09831b8b3d9a76519c42e7afb")
addappid(1914842, 1, "206b1cdc31300279ffce380bbdc75b19672da5a0f71ec97ed6689a041d7684a6")
