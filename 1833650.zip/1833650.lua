-- Lua provided by RyzenAPI
-- Game: addappid(1833650)

-- MAIN APPLICATION
addappid(1833650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833651, 1, "2e811b03efbadbe123ddb4cc3bb8d9fcab44ed1f0ffc695f1b5e12ba522b1afb")
