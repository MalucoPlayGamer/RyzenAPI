-- Lua provided by RyzenAPI
-- Game: 756280

-- MAIN APPLICATION
addappid(756280)

-- MAIN APP DEPOTS / PACKAGES
addappid(756280,0,"d1aae91176e7ef12cece2e5511a23cbcf7a0d08ced26e30d52c40ba3a75defba")
