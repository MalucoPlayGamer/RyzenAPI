-- Lua provided by RyzenAPI
-- Game: Probability Race Demo

-- MAIN APPLICATION
addappid(1605660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605661, 1, "36c09328ac1a2a8d3a89ab16a8379a7b9bdadc9a55d0d4ff5062bac3eaf4e5c0")
