-- Lua provided by RyzenAPI
-- Game: addappid(232050)

-- MAIN APPLICATION
addappid(232050)
addappid(237170)
addappid(237171)
addappid(297770)
addappid(303730)

-- MAIN APP DEPOTS / PACKAGES
addappid(232051, 1, "286102318abfd88fbfe1e7dd5b86a27a9822323b674ea7f57eb02de03e196005")
