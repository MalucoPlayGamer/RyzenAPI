-- Lua provided by RyzenAPI
-- Game: AppID 232050

-- MAIN APPLICATION
addappid(232050)
addappid(237170)
addappid(237171)
addappid(297770)
addappid(303730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(232051, 1, "286102318abfd88fbfe1e7dd5b86a27a9822323b674ea7f57eb02de03e196005")

