-- Lua provided by RyzenAPI
-- Game: Game: Gladio Mori Demo

-- MAIN APPLICATION
addappid(2908480)
-- Game: addappid(2908480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908481, 1, "f2100986311386c312f59f5f6007bbc64f95a294a726100f46fe5976c1a817a1")
