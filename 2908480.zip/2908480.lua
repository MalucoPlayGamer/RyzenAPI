-- Lua provided by SkyAPI 
-- Game: Gladio Mori Demo
addappid(2908480)
addappid(2908481, 1, "f2100986311386c312f59f5f6007bbc64f95a294a726100f46fe5976c1a817a1")
