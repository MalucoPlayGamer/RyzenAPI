-- Lua provided by RyzenAPI
-- Game: MXGP2 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(400800)
addappid(445200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(400801, 1, "bc05a09506c20a5a16fbd22be89e2f58c709c5a183aba5f6dbdbefcdab454c7f")
addappid(438850, 0, "9582332b3fd7c2875a22ebf63a48aca94032eaf672ec2e6f8c0444c2f6f9c94d")
addappid(438860, 0, "acfa1823c25aee80209b5c288f9aa714c0ef7882ffd33516e2bd0def9412a75c")
addappid(438870, 0, "b61a9cd0c336b2dba5f85013dbd98f365ce7b021a6953e9565984f7c81534a20")
