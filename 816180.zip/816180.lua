-- Lua provided by RyzenAPI
-- Game: Zhmyshenko Valery Albertovich

-- MAIN APPLICATION
addappid(816180)
-- Game: addappid(816180)

-- MAIN APP DEPOTS / PACKAGES
addappid(816181, 1, "d9ea1bd05260293966243884d9c72226e0eeb656f2e878f3762b4d1ae990c524")
addappid(830740, 0, "ca60791bf4b701be6f54d5cb93da9c71ef92c9454cb3d24c3960d47039f667d9")
