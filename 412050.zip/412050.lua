-- Lua provided by RyzenAPI
-- Game: Game: AppID 412050

-- MAIN APPLICATION
addappid(412050)
-- Game: addappid(412050)

-- MAIN APP DEPOTS / PACKAGES
addappid(412051, 1, "165acb24cd35c280204a2bf18e4233ebaa7dee38f0ddb9e6e13d3e493beef37f")
