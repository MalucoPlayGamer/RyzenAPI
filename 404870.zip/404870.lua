-- Lua provided by RyzenAPI
-- Game: Realms Edge

-- MAIN APPLICATION
addappid(404870)

-- MAIN APP DEPOTS / PACKAGES
addappid(404871, 1, "5274c5b9428cf032f04e587bdd8bc4934e6355be7c203dda327c83d214ecdf98") -- (windows)
addappid(404872, 1, "89255f6f8abed4303b4f580523603e4adfd06aa8b543f454eb89e8fe39ce0997") -- (macos, 64-bit)

