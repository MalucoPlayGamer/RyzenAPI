-- Lua provided by RyzenAPI
-- Game: Overgrown: Genesis

-- MAIN APPLICATION
addappid(1280260)
addappid(1352980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280261, 1, "5c227d42bbde01dd986971de102adcbdbaa21efe80d7fbde266d8ddb34daa2e0")

