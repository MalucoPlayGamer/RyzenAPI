-- Lua provided by RyzenAPI
-- Game: Game: FIND ALL 2: Middle Ages

-- MAIN APPLICATION
addappid(1722520)
-- Game: addappid(1722520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722521, 1, "e0825819a9a5b4d6014e93eb53801993ab3a37380947291606513cf1ad1ac810")
