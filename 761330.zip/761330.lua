-- Lua provided by RyzenAPI
-- Game: 761330

-- MAIN APPLICATION
addappid(761330)
addappid(860250)
-- Game: addappid(761330)

-- MAIN APP DEPOTS / PACKAGES
addappid(761331, 1, "f55a9969c43235144bb570b67c81a1030d1f37ed3485be02be171a2bcf1873e1")
