-- Lua provided by RyzenAPI
-- Game: Game: AppID 1414800

-- MAIN APPLICATION
addappid(1414800)
-- Game: addappid(1414800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414801, 1, "128edc2425dc0a524d9cad21af3c9f0819f4fa96d0a6b97ebe0dc217caae64bf")
