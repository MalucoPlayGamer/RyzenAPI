-- 1465640's Lua and Manifest Created by Hubcap Manifest
-- Dead Man's Rest
-- Created: August 06, 2026 at 11:23:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1465640, 1, "a2944087ddaebcc3a263c43f7f13e07c2eb921b0745b01a81caa33112197c752") -- Dead Man's Rest
-- MAIN APP DEPOTS
addappid(1465641, 1, "809db9d498b53cf42607c92ca91175c805fa56cf91f8f45cd13833c627c7f6b5") -- DMR PC and Linux
setManifestid(1465641, "6658096403793427703", 425268685)
addappid(1465642, 1, "df328da59fdded3313e14b659c67db2c43b271cb0c017a289c25e63e4aa56976") -- DMR Mac
setManifestid(1465642, "9164217557974636834", 526816180)
addappid(1465643, 1, "fbc96690d666fad47a17149af35f312ab7759d7a8792ec388299c68a404070f3") -- DMR Linux
setManifestid(1465643, "6697980807920537102", 425268685)