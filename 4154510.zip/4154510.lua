-- 4154510's Lua and Manifest Created by Hubcap Manifest
-- How Asian Parents went to School
-- Created: August 25, 2026 at 11:39:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4154510) -- How Asian Parents went to School
-- MAIN APP DEPOTS
addappid(4154511, 1, "7426063383ae363ec0a12a8f5dbacfc3cbd52c7cd2c620bdb7fec27ad4af9ea0") -- Depot 4154511
setManifestid(4154511, "7694030506829066864", 3557746405)