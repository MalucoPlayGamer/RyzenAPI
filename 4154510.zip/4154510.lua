-- Lua provided by RyzenAPI
-- Game: How Asian Parents went to School

-- MAIN APPLICATION
addappid(4154510) -- How Asian Parents went to School

-- MAIN APP DEPOTS / PACKAGES
addappid(4154511, 1, "7426063383ae363ec0a12a8f5dbacfc3cbd52c7cd2c620bdb7fec27ad4af9ea0") -- Depot 4154511

