-- Lua provided by RyzenAPI
-- Game: addappid(2720920)

-- MAIN APPLICATION
addappid(2720920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720921, 1, "f9fc8122946a0a1c6329648121d3483fe457c67d21d4e5cda661b596fa55ff2e")
