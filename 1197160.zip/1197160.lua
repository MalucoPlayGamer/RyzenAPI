-- Lua provided by SkyAPI 
-- Game: Code 3: Police Response
addappid(1197160)
addappid(1197161, 1, "a01e6f50a0d07013aed575ee1f6829414a778bbd9b1c8bb3dd40b0e9efd1f824")
