-- Lua provided by RyzenAPI
-- Game: Code 3: Police Response

-- MAIN APPLICATION
addappid(1197160)
-- Game: addappid(1197160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197161, 1, "a01e6f50a0d07013aed575ee1f6829414a778bbd9b1c8bb3dd40b0e9efd1f824")
