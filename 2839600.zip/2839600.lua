-- Lua provided by RyzenAPI
-- Game: Dungeon Full Dive: Player Edition

-- MAIN APPLICATION
addappid(2839600)
addappid(2951980)
-- Game: addappid(2839600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839601, 1, "b4dfb748ff552fe5ffc9767569f85d6b0872d12b67f7a1971b6c2578fc0a3d06")
