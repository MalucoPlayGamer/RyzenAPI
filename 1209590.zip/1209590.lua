-- Lua provided by RyzenAPI
-- Game: addappid(1209590)

-- MAIN APPLICATION
addappid(1209590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209590,0,"8f6743bda4235f851a19b2d18bf83fbf5cbfa6d0e65d2607911fd6a893a2cb81")
