-- Lua provided by RyzenAPI
-- Game: 2485170

-- MAIN APPLICATION
addappid(2485170)
-- Game: addappid(2485170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485171, 1, "9dece275644c4d74b2ccf1256fa08160f7faaad36bf56f2999ae5affecf08cb5")
