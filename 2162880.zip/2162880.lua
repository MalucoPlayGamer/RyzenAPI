-- Lua provided by RyzenAPI
-- Game: Game: AppID 2162880

-- MAIN APPLICATION
addappid(2162880)
-- Game: addappid(2162880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162881, 1, "02bec457928bf883774d6fd42ee4053f1a7064e1e857bd4523bf5c58633e5219")
