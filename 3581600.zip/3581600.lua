-- Lua provided by RyzenAPI
-- Game: Fate War

-- MAIN APPLICATION
addappid(3581600)

