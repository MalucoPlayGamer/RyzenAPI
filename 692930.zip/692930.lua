-- Lua provided by RyzenAPI
-- Game: 692930

-- MAIN APPLICATION
addappid(692930)
-- Game: addappid(692930)

-- MAIN APP DEPOTS / PACKAGES
addappid(692931, 1, "78aad96bfbb17d5c6cdac9723ce15be2a54b0ff6e80f8b047c37699ca5dbd0f7")
