-- Lua provided by RyzenAPI
-- Game: Crab Game 2

-- MAIN APPLICATION
addappid(3349150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3349151, 1, "deb3857f2ce656c271ac99ce400be90d4608701551e960b7ee1c07310ae13ac6")

