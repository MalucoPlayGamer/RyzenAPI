-- Lua provided by RyzenAPI
-- Game: addappid(3349150)

-- MAIN APPLICATION
addappid(3349150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349151, 1, "deb3857f2ce656c271ac99ce400be90d4608701551e960b7ee1c07310ae13ac6")
