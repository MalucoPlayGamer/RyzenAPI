-- Lua provided by RyzenAPI 
-- Game: Crab Game 2
addappid(3349150)
addappid(3349151, 1, "deb3857f2ce656c271ac99ce400be90d4608701551e960b7ee1c07310ae13ac6")
