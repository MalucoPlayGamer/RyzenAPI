-- Lua provided by RyzenAPI
-- Game: 龙傲天的多元宇宙

-- MAIN APPLICATION
addappid(2387780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387781, 1, "8a59b4e05260845da74e37332d063111b2c2c799a62ec38e9619e5cfee6f3dd4")
