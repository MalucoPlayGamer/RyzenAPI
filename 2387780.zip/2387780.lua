-- Lua provided by SkyAPI 
-- Game: 龙傲天的多元宇宙
addappid(2387780)
addappid(2387781, 1, "8a59b4e05260845da74e37332d063111b2c2c799a62ec38e9619e5cfee6f3dd4")
