-- Lua provided by RyzenAPI
-- Game: 2219450

-- MAIN APPLICATION
addappid(2219450)
addappid(3654160)
-- Game: addappid(2219450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219451, 1, "981b8780fc1f05ca0e740a0930cf3492d294bd6a0b985911928c02544d1dbe2b")
