-- Lua provided by RyzenAPI 
-- Game: I'm Lost
addappid(737530)
addappid(737531, 1, "b44fa2f69fed0409daae0bfe15e567a80fc4c709eaebf55e781209651011de9b")
