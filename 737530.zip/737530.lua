-- Lua provided by RyzenAPI
-- Game: I'm Lost

-- MAIN APPLICATION
addappid(737530)

-- MAIN APP DEPOTS / PACKAGES
addappid(737531, 1, "b44fa2f69fed0409daae0bfe15e567a80fc4c709eaebf55e781209651011de9b")
