-- Lua provided by RyzenAPI
-- Game: addappid(1840940)

-- MAIN APPLICATION
addappid(1840940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840941, 1, "611c7166b34702aa92fb7300d4f2f1d877f876447e9a8f30ebbe681ded774100")
