-- Lua provided by RyzenAPI
-- Game: 16190

-- MAIN APPLICATION
addappid(16190)
-- Game: addappid(16190)

-- MAIN APP DEPOTS / PACKAGES
addappid(16191, 1, "e9cb9b410efefe59d94e007df9f2ce8a6dce02ec4b7792856192dfae0e3a25ee")
