-- Lua provided by RyzenAPI
-- Game: Rad Rodgers - Radical Edition

-- MAIN APPLICATION
addappid(805660)
-- Game: addappid(805660)

-- MAIN APP DEPOTS / PACKAGES
addappid(805661, 1, "c1435e899d1aa755449c14b20c61b216738bc0135c05f8c8a2ceedb8929f9276")
