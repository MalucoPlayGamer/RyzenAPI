-- Lua provided by RyzenAPI
-- Game: HypeSquad Final Test

-- MAIN APPLICATION
addappid(1940810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940811, 1, "d9aa25e55439b9a6516582350a656d0b077b233abfe9b036c34c1cc36e7d6ea9")

