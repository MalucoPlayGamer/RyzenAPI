-- Lua provided by RyzenAPI
-- Game: Game: AppID 3244640

-- MAIN APPLICATION
addappid(3244640)
-- Game: addappid(3244640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244641, 1, "d229984b69bf4a73a78c74f75ba306135c8e2a795a425e2db3d277752f51121d")
