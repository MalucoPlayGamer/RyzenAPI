-- Lua provided by RyzenAPI
-- Game: SEXDIVERS 🔞

-- MAIN APPLICATION
addappid(3244640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3244641, 1, "d229984b69bf4a73a78c74f75ba306135c8e2a795a425e2db3d277752f51121d")

