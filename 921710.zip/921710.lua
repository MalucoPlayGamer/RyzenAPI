-- Lua provided by RyzenAPI
-- Game: Galaxy Squad

-- MAIN APPLICATION
addappid(921710)

-- MAIN APP DEPOTS / PACKAGES
addappid(921711, 1, "d4d692003cb32bfbfafcb9b27c760b87b0dc62190f6dcb29c07754e29c49fb6c")
addappid(921712, 1, "13daf0a18ae37a6d8336c59eca8f7f0305139bda34ff50f0b483b17f8b703d6a")

