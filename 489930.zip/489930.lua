-- Lua provided by RyzenAPI
-- Game: Adventures of Bertram Fiddle 2: A Bleaker Predicklement

-- MAIN APPLICATION
addappid(489930)

-- MAIN APP DEPOTS / PACKAGES
addappid(489932,0,"8ee61a3ab6a82ebd7280ccc6ec3233f5bc9ddc36f84f41e828e9b76a9f27b94e")
