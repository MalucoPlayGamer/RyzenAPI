-- Lua provided by SkyAPI 
-- Game: ProtectHeart
addappid(2791010)
addappid(2791011, 1, "b3f2101ef821654552cab3b87142df9618204692f9dc240230ae06c6065d0af0")
