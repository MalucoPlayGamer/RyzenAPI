-- Lua provided by RyzenAPI
-- Game: Game: ProtectHeart

-- MAIN APPLICATION
addappid(2791010)
-- Game: addappid(2791010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791011, 1, "b3f2101ef821654552cab3b87142df9618204692f9dc240230ae06c6065d0af0")
