-- Generated with Luie @ https://lua.tools/
-- 4259990 - Corner King: Boxing Tycoon
-- Generated 2026-08-21 21:34:40 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(4259990)

-- Main Depots
addappid(4259991, 1, "281ffd9356469658709a696ad1cc5609bc60550bfa687c0962d76c76fc7c9a80")
setManifestid(4259991, "2795535809447920805", 1202169804)

-- DLC's (with depot keys)
-- Corner King: Boxing Tycoon Demo (AppID: 4771840)
addappid(4771840)
addappid(4771841, 1, "117e65c3b1ae82810b26061085a4815be88aa5b4fe835040433e1f056f34c160")
setManifestid(4771841, "5172409992216643632", 1202161784)
