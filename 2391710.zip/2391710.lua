-- Lua provided by RyzenAPI
-- Game: Gatekeeper: Infinity

-- MAIN APPLICATION
addappid(2391710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391711, 1, "511dcc31334cf36e5ead8cf0fa997ed065b6242b57bb035dc53881685ea8824a")
