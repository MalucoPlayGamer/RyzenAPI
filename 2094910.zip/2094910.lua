-- Lua provided by RyzenAPI
-- Game: Pile Up!

-- MAIN APPLICATION
addappid(2094910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094911, 1, "db4c431edb8fa95a158d32effe156aa64371d4ccfca562cca284100fd157f6eb")
