-- Lua provided by RyzenAPI
-- Game: Wet Dreams

-- MAIN APPLICATION
addappid(1965360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965361, 1, "f1a35bcc0b4758f51fc728a5ac4b3cf85023445d2c67eb0af8987df3c9342d04")

