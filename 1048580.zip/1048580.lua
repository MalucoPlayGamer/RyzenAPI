-- Lua provided by RyzenAPI
-- Game: 1048580

-- MAIN APPLICATION
addappid(1048580)
-- Game: addappid(1048580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048581, 1, "72dff211273e55fdf9383aeb1797f5bb0d0cffa22a28a0f31af1362709e6adcb")
