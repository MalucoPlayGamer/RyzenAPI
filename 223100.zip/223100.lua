-- Lua provided by RyzenAPI
-- Game: Homefront®: The Revolution

-- MAIN APPLICATION
addappid(223100)

-- MAIN APP DEPOTS / PACKAGES
addappid(223101, 1, "6a3156d07345e25983d5010c595cb9242758bd93ddffd3f6565ef593301eedc3")
addappid(223102, 1, "5c952178ff2bfc780ea2158b621e0105a164ab90826acf055d6968fa9972f838")
addappid(223103, 1, "23f25d77c193e79c329e4a5cc6ca2b4656c7ef9750a17eebe59d3b4495a80a13")
addappid(223106, 1, "a2ff3e5bbbd70cd98624a607f9c8b963371baf76966e04757e88d9fed480b17b")
addappid(500270, 0, "848686a5db9c49199dbe949ce70faa9536aa689fa6bb586465c9a6635c6f9043")
addappid(500271, 0, "3e3a8c8ad4bed71be9d325b00892d5c0c8e8d79b5732239031eef5523646ba39")
addappid(500272, 0, "bc3ac2037563fb4e4f7fe538aee1d4c9d3604b0f238ee0922375edb5347b518f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(378520)
addappid(378521)
addappid(445990)
addappid(445991)
addappid(445992)
addappid(455350)
addappid(456270)
addappid(456271)
