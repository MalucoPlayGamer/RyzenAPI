-- Lua provided by RyzenAPI
-- Game: Rising Star 2

-- MAIN APPLICATION
addappid(1235110)
-- Game: addappid(1235110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235111, 1, "77efe9c6fc784f5803d59de8f5cf7985378b0b7e8ad4688274fe956cd484b0e0")
addappid(1235112, 1, "2a278d5648dd627b526beb59c651c06e14b1b1dfee98ac3d3aff5d5a7948302c")
