-- Lua provided by RyzenAPI
-- Game: AppID 925940

-- MAIN APPLICATION
addappid(925940)

-- MAIN APP DEPOTS / PACKAGES
addappid(925941, 1, "963780b175bfcf863b98e849cb329b3446259736718957a950adacb50ea68bb7")
addappid(925942, 1, "0e07060ee85b093230618da9fe8a728208c5745b224013f9d8ba3ed2c34daf90")
addappid(925943, 1, "50cf5cd612e6018b8e5113aad84aea0a91b1ec2b943c5d723573a059e57396a4")
addappid(925944, 1, "50e842f54115fb91a9d63de6ff05181d48e9660bf7e7d7077c010393e533d0cb")
addappid(925945, 1, "91e0c585e8d27e9d1e29749872785ae0d038bd57cad284ac2cebfb89fa05cba8")
addappid(925946, 1, "683df55fea80f58af443d6f009e4d0d531fffc779909b21a1afeeaf6864659d2")
addappid(925947, 1, "d3b0ea553b52e17329a9bcfaab2496f44d7b8469e109db9f1b39a198cee8d149")
addappid(925948, 1, "fd0a3ace2bbc13f04458a972ba5c372f3da72c6b74928ea4f6ca9db19ff6e5c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
