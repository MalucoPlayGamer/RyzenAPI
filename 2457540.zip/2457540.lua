-- Lua provided by RyzenAPI
-- Game: Game: Cardfight!! Vanguard Dear Days 2

-- MAIN APPLICATION
addappid(2457540)
-- Game: addappid(2457540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457541, 1, "5195261e7ca5f37ebc06fd9599b9b8cbc1b172ea54cec4096d3e60b8f176643e")
