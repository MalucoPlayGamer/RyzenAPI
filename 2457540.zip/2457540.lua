-- Lua provided by RyzenAPI
-- Game: Cardfight!! Vanguard Dear Days 2

-- MAIN APPLICATION
addappid(2457540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457541, 1, "5195261e7ca5f37ebc06fd9599b9b8cbc1b172ea54cec4096d3e60b8f176643e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3332190)
addappid(3332200)
addappid(3332210)
addappid(3332220)
addappid(3332230)
addappid(3332240)
addappid(3332250)
addappid(3332260)
addappid(3332270)
addappid(3332280)
addappid(3332310)
addappid(3332330)
addappid(3332340)
addappid(3332350)
addappid(3332360)
addappid(3493490)
addappid(3493500)
addappid(3493510)
addappid(3493520)
addappid(3493530)
addappid(3619670)
addappid(3619680)
addappid(3619690)
addappid(3619700)
addappid(3619710)
addappid(3619720)
addappid(3785990)
addappid(3786000)
addappid(3902290)
addappid(3902300)
addappid(3987600)
addappid(3996280)
addappid(3996300)
addappid(3996310)
addappid(3996320)
addappid(4133570)
addappid(4133580)
addappid(4133590)
addappid(4133600)
addappid(4306500)
addappid(4306510)
