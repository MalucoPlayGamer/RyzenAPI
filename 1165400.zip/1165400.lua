-- Lua provided by RyzenAPI
-- Game: addappid(1165400)

-- MAIN APPLICATION
addappid(1165400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165401, 1, "af03b281089b6afd597880cc0d638da572ef8d329b81adac8923b573cfe6dcbb")
addappid(1207351, 0, "7a4dba8045aeeed8d8abed21b45227586157b13aabf829753fa1abcf135d8859")
