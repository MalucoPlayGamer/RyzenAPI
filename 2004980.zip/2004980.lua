-- Lua provided by RyzenAPI
-- Game: Revenge of the Orcs: Flag of Conquest

-- MAIN APPLICATION
addappid(2004980)
-- Game: addappid(2004980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004981, 1, "d1138d32d95ba841c50130bc0477e60e9063ef80aab37c90996e0afe9dd1fa3d")
addappid(2004982, 1, "c5fa56a9b4e5950207b2a81d072184815dc2ca9fc3dce8bd89f40784cf03c3c4")
addappid(2004983, 1, "9ad36789a58c8fe0c83b09c191e66a8886f940bb010a0048b18690a0386d8bb3")
