-- Lua provided by RyzenAPI
-- Game: Guilty Gear X2 #Reload

-- MAIN APPLICATION
addappid(314030)

-- MAIN APP DEPOTS / PACKAGES
addappid(314031, 1, "e630af5f2ac5ab45104a2b982cae66da45a8cbb4f57da510990f047d77de616e")

