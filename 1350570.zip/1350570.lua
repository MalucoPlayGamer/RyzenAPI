-- Lua provided by RyzenAPI
-- Game: addappid(1350570)

-- MAIN APPLICATION
addappid(1350570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350571, 1, "bfcc2260418e7ec47d83f447a65dee145589650bba4ec52773df419f3771cf09")
