-- Lua provided by RyzenAPI
-- Game: Holy Heroes

-- MAIN APPLICATION
addappid(3107270)
-- Game: addappid(3107270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107271, 1, "4fe72180ac2a1d6cf422c68b50ecfb805270c79356c4f16dc8ebceab918fdc79")
