-- Lua provided by RyzenAPI
-- Game: 2470270

-- MAIN APPLICATION
addappid(2470270)
-- Game: addappid(2470270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470271, 1, "51f6d1dd5d03bd63cc390e283c8461dbda816a619ed53edcb382192ad515d824")
