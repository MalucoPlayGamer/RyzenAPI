-- Lua provided by RyzenAPI
-- Game: Turbo Era Boss

-- MAIN APPLICATION
addappid(4911580) -- Turbo Era Boss
addappid(5038680) -- Turbo Era Boss Editor

-- MAIN APP DEPOTS / PACKAGES
addappid(4911581, 1, "9a2821a26c42c72b8cd42f898d460493280aedb1f8bd8d3773a645cac02dc84d") -- Depot 4911581

