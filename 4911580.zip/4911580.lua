-- 4911580's Lua and Manifest Created by Hubcap Manifest
-- Turbo Era Boss
-- Created: August 27, 2026 at 12:10:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4911580) -- Turbo Era Boss
-- MAIN APP DEPOTS
addappid(4911581, 1, "9a2821a26c42c72b8cd42f898d460493280aedb1f8bd8d3773a645cac02dc84d") -- Depot 4911581
setManifestid(4911581, "5853008256356741183", 168173720)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5038680) -- Turbo Era Boss Editor