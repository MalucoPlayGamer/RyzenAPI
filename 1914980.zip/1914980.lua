-- Lua provided by RyzenAPI
-- Game: Golfing in Aether

-- MAIN APPLICATION
addappid(1914980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914981, 1, "a427d20072dec3d34c32b05bc458cd8a6443073d0d3650aa1c6d1d26fcb1ebcc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2138970)
addappid(2168440)
addappid(2168441)
addappid(2293060)
addappid(2577930)
addappid(2999530)
addappid(4006460)
