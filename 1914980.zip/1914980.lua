-- Lua provided by RyzenAPI
-- Game: Golfing in Aether

-- MAIN APPLICATION
addappid(1914980)
-- Game: addappid(1914980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914981, 1, "a427d20072dec3d34c32b05bc458cd8a6443073d0d3650aa1c6d1d26fcb1ebcc")
