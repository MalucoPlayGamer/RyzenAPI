-- Lua provided by RyzenAPI
-- Game: addappid(1040200)

-- MAIN APPLICATION
addappid(1040200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040201, 1, "c674332af23f9b6fcc58092e93db43d62fe38a9b004985697e490bde97b45548")
