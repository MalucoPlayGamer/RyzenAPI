-- Lua provided by RyzenAPI
-- Game: Pole of Cold

-- MAIN APPLICATION
addappid(1446100)
-- Game: addappid(1446100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446101, 1, "eea5d9a64648626b4cf8eb8993a4d4a824c7da29151e0167acd0c981b8c26a7e")
