-- Lua provided by RyzenAPI
-- Game: AppID 1646690

-- MAIN APPLICATION
addappid(1646690)
-- Game: addappid(1646690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646691, 1, "dac03d90da978caf1158deb0919251d40ad613cb6a05bc5c349921428f4d62b1")
