-- Lua provided by RyzenAPI
-- Game: Nightmare Grotto

-- MAIN APPLICATION
addappid(614700)

-- MAIN APP DEPOTS / PACKAGES
addappid(614701,0,"176362086aba96da3a21807b544425eee3469ab803d169f7841fc846e8be77b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
