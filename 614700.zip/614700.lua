-- Lua provided by RyzenAPI
-- Game: Nightmare Grotto

-- MAIN APPLICATION
addappid(614700)

-- MAIN APP DEPOTS / PACKAGES
addappid(614701,0,"176362086aba96da3a21807b544425eee3469ab803d169f7841fc846e8be77b9")

