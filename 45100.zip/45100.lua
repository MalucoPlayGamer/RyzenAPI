-- Lua provided by RyzenAPI
-- Game: Secret of the Magic Crystals

-- MAIN APPLICATION
addappid(45100)
addappid(228983)

-- MAIN APP DEPOTS / PACKAGES
addappid(45101, 1, "ab9d39d5e3494902836da23fb486b15bbd2fa7a56177d7509b323f27d2062441")
addappid(45102, 1, "b55a037810b5afcc0680ec08bebb5552c5e575a7127d6eea0278cc55941b17ed")
addappid(45103, 1, "912e77307101adc64b5cb13d7302e814cb1fa18193e1f6395e345c468796c3cd")
addappid(321420, 0, "eeff91fa236f70bfdc5a3d23420250637731b1981a0b6bb40e91a2d40259d691")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(305570)
addappid(321421)
