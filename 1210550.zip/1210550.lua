-- Lua provided by RyzenAPI
-- Game: 1210550

-- MAIN APPLICATION
addappid(1210550)
-- Game: addappid(1210550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210551, 1, "e494916b8fcba96d63f4812af4f32dec86be2ad028f59c74da909f0f0ccab1a7")
