-- Lua provided by RyzenAPI 
-- Game: Hohokum
addappid(1210550)
addappid(1210551, 1, "e494916b8fcba96d63f4812af4f32dec86be2ad028f59c74da909f0f0ccab1a7")
