-- Lua provided by RyzenAPI
-- Game: Lost Vessel

-- MAIN APPLICATION
addappid(4652730)
