-- Lua provided by RyzenAPI
-- Game: They Bleed Pixels Soundtrack

-- MAIN APPLICATION
addappid(211262)

-- MAIN APP DEPOTS / PACKAGES
addappid(211262,0,"2bc5284bf5074b5ee090dba29a6598f2145664f09349dbe28167d1428b062539")
