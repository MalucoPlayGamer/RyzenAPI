-- Lua provided by RyzenAPI
-- Game: Regeria Hope Episode 1

-- MAIN APPLICATION
addappid(447570)

-- MAIN APP DEPOTS / PACKAGES
addappid(447571, 1, "0681ccc4eccda7cd5a5877dec7857cf39151df65cbc164caf3c499b745eb8970")
