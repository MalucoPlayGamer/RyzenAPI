-- Lua provided by RyzenAPI
-- Game: Stone Age: Digital Edition

-- MAIN APPLICATION
addappid(2177570)
-- Game: addappid(2177570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177571, 1, "97614165a469a8e14491745fa546413e92960c18da5a0b67f987037c359ac0f7")
