-- Lua provided by RyzenAPI
-- Game: Strike Force Heroes

-- MAIN APPLICATION
addappid(1981820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981821, 1, "503f766da9b250522ec18da5429e65770ce4f9cd9179c1b89c4c034e07f0d3aa")
addappid(2670380, 0, "12fb1fd8f21f7b69ea82d123f2b3dc731e0b963822c23dc2832b058b98dfe946")
