-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes The Awakened Soundtrack

-- MAIN APPLICATION
addappid(2330080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330081, 1, "6a488df0b1fecc0d99123d5e4843a6c22cabb2fbf2e4c8d6209318f90dab2785")
addappid(2330082, 1, "076d7bdc12cdbcee771feb20ce20f72799a3f0b2a006f9fba62c306dd07f0156")

