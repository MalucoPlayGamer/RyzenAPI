-- Lua provided by RyzenAPI
-- Game: Monster 3

-- MAIN APPLICATION
addappid(2999070)
-- Game: addappid(2999070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999071, 1, "d3677bd45c9c56e90e802f7a8cdd8d3bb45976d5043ef9e1855ba2ae1410e1b8")
