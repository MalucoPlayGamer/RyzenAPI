-- Lua provided by RyzenAPI
-- Game: Chilli Con Valley

-- MAIN APPLICATION
addappid(1775110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775111, 1, "cb571134759b98811253364382936b5b5b35dcdddbf4e63d62d0564f57a63c9f")

