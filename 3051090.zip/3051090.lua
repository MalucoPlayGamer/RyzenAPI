-- Lua provided by RyzenAPI
-- Game: Game: Underwater abyss

-- MAIN APPLICATION
addappid(3051090)
-- Game: addappid(3051090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051091, 1, "4d4bc405e44638f17b3407d140134146a3d47f017f92c14453b260c0470512ec")
