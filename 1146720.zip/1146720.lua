-- Lua provided by RyzenAPI
-- Game: 1146720

-- MAIN APPLICATION
addappid(228986)
addappid(228987)
addappid(229000)
addappid(229001)
addappid(1146720)
addappid(1146721)
addappid(1146722)
-- Game: addappid(1146720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146723,0,"5f0cbe273fedc05d6a2fa8cc361204acf0a6964be9ba3140969639932afe3050")
