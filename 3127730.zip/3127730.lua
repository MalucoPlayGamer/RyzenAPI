-- Lua provided by RyzenAPI
-- Game: Game: Selene's Unbearable Night Demo

-- MAIN APPLICATION
addappid(3127730)
-- Game: addappid(3127730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127731, 1, "71c05a2861fcbb254d5470233eff1bcf491a6ad6f353ed74b6f6312457c22eca")
