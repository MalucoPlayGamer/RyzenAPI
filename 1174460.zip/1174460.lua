-- Lua provided by RyzenAPI
-- Game: Poker Club

-- MAIN APPLICATION
addappid(1174460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174461, 1, "ed8b75ad32145573a7ecb76a9daf57d2a2032907ec25909c72464bdf012c6e79")
