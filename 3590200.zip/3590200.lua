-- Lua provided by RyzenAPI
-- Game: Bionic Bay: Digital Artbook

-- MAIN APPLICATION
addappid(3590200)
-- Game: addappid(3590200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3590200,0,"cf42d58c1f95af4bd257049c9373a3649174f65b1c5388a9536dd9280559c66c")
