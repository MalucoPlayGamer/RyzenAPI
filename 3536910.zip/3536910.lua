-- Lua provided by RyzenAPI
-- Game: addappid(3536910)

-- MAIN APPLICATION
addappid(3536910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3536911, 1, "7b5b816fbfe91dbadd8dfce374db70e6b55d65035347bf3b3d4f61169d1d83b5")
