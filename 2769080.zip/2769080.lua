-- Lua provided by RyzenAPI
-- Game: 2769080

-- MAIN APPLICATION
addappid(2769080)
-- Game: addappid(2769080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769081, 1, "6843b35550304f6170532750c039efeddc8b13c3e0a610a0c4e7a102813b1edf")
