-- Lua provided by RyzenAPI
-- Game: Dashbounce Sage 2023 Demo

-- MAIN APPLICATION
addappid(2591350)
-- Game: addappid(2591350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591351, 1, "560b7fa54e8607a021cee68685000cbf2c216f67f0725aea750e6b34d4332676")
