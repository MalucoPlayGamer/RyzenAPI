-- Lua provided by RyzenAPI
-- Game: Magnesium_173

-- MAIN APPLICATION
addappid(1157200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157201, 1, "50c118be0e60505660d78290f93d3f1a9165d5242ce6bec1a23762b68da22c56")
