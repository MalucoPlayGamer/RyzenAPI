-- Lua provided by RyzenAPI
-- Game: addappid(1798290)

-- MAIN APPLICATION
addappid(1798290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798291, 1, "0deed4091e5c41e48351d6de7a6b57f0e4ff14c11d295b5cf3322c5c87c59163")
