-- Lua provided by RyzenAPI
-- Game: Champions of Odin

-- MAIN APPLICATION
addappid(479200)

-- MAIN APP DEPOTS / PACKAGES
addappid(479201, 1, "dcb2e9ea723d31f12a9e2671c099e21e04454eaebec14de5dabf6756b75ad76d")

