-- Lua provided by RyzenAPI
-- Game: Toy Trains Demo

-- MAIN APPLICATION
addappid(2622270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622271, 1, "412f8f17f9b0760ad449a6c0e34d0a5aabe76084b0cad34a4c9742df12c29b10")

