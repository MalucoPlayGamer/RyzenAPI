-- Lua provided by RyzenAPI
-- Game: Game: S.T.A.L.K.E.R.: Clear Sky

-- MAIN APPLICATION
addappid(20510)
-- Game: addappid(20510)

-- MAIN APP DEPOTS / PACKAGES
addappid(20511, 1, "0dfb827e04da9a59772f16c610e8546aeb489257a139a057b665e31369c3b3fa")
addappid(20512, 1, "f11eb795d5b8bad2e6a70198a0b33cd10252abb9e4c663d84daed2d76246cfd3")
addappid(20513, 1, "08caf0febe3eb9d4af599b067c779260df8b21fd03c4eb261d90e4cd3f497bc3")
addappid(20514, 1, "7ba20774366d6d685a257aaa3a713955ca0ff747abf7dfebe5e66a029aea3ad3")
addappid(20515, 1, "740e8f1a3f2e916143461473d5a344ac47efb3a216dd1d82b1928bdba57d0f3b")
addappid(20516, 1, "5df5bfb8b7bfd77c2f5d684ee410c9a90e24cf6795c6b00cce53e0780234c4a8")
addappid(20517, 1, "5ec54a3d4f78c4696ad223f22cce984292f50543ce899a7973a356077cb0fe39")
addappid(20518, 1, "090ed51e67d3ff0e41aece219650a763e5c5784fdf7aba3d25cc0263b8d0baeb")
addappid(20519, 1, "a92b90a12e1fe6603c8f0731f6f7aac76d0158a5e1ac1ff1c3f8eb593d7a1c70")
addappid(1243460, 0, "18a113e10b7c76555acf66f6ca11e389fb6436dc2bba5083bdbd3294a1ecc198")
