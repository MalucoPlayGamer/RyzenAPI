-- Lua provided by RyzenAPI
-- Game: Game: AppID 1592330

-- MAIN APPLICATION
addappid(1592330)
-- Game: addappid(1592330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592331, 1, "c313f0a477f364279812d70ea50f0a7480dbe390f79c541b3e0f6e32165e1903")
