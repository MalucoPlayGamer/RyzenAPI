-- Lua provided by RyzenAPI
-- Game: Final War: Frozen Defense

-- MAIN APPLICATION
addappid(3689850)
