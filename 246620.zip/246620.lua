-- Lua provided by RyzenAPI
-- Game: Plague Inc: Evolved

-- MAIN APPLICATION
addappid(246620)
addappid(317520)
addappid(1472780)
-- Game: addappid(246620)

-- MAIN APP DEPOTS / PACKAGES
addappid(246621, 1, "19ad23e511f566d12808b52a4cfabb6457d8acc91815acbaddc6fdfe76dacfbe")
addappid(246622, 1, "dd2e9f4b104c4ce27c22dadf3dd13210e54a51c0fa09f14addd72d8c05121f89")
addappid(246623, 1, "516e04bc485cebe525f9d28a727a2fbc29aad932656bcb36238448797d52a337")
addappid(246624, 1, "b7170469891310d1335cb12516164cff304a536657ad2c35fad0950719133123")
addappid(246625, 1, "3c1666a26d525bf81d9b9c90bbd47b0fd637db2d2056950f5a9c8c72f76109bb")
addappid(246626, 1, "8d0fb3394cd06ae93b744373a1024f9a4c4b5c4a1e30ed95fadbb05718d02ff2")
