-- Lua provided by SkyAPI 
-- Game: Necrophosis Demo
addappid(2959950)
addappid(2959951, 1, "cdbb7c0c3b9b73d43de624361688a6749398706c8654ea0bbcc5f583540726c3")
