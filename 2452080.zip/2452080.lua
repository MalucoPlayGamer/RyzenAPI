-- Lua provided by RyzenAPI
-- Game: SaGa Frontier 2 Remastered

-- MAIN APPLICATION
addappid(2452080)
-- Game: addappid(2452080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452081, 1, "c2d565341531f2032ec2e3340fd71477d019939f2b79db27d6f23898e49e9580")
