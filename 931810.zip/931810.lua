-- Lua provided by RyzenAPI
-- Game: addappid(931810)

-- MAIN APPLICATION
addappid(931810)

-- MAIN APP DEPOTS / PACKAGES
addappid(931811, 1, "78b1b1390dbcb022fe019cbfc03cee141d33d310a3be5538febca8b71b041500")
