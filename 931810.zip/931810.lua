-- Lua provided by RyzenAPI 
-- Game: Attack on I-Ching  进击的易经
addappid(931810)
addappid(931811, 1, "78b1b1390dbcb022fe019cbfc03cee141d33d310a3be5538febca8b71b041500")
