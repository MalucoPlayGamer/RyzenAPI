-- Lua provided by RyzenAPI
-- Game: Game: Dice People

-- MAIN APPLICATION
addappid(3373670)
-- Game: addappid(3373670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3373671, 1, "e504276f1a5d47bd14e00a3824630c304f6827c342a49337dc9cc2e96796169f")
