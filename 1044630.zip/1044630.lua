-- Lua provided by RyzenAPI
-- Game: addappid(1044630)

-- MAIN APPLICATION
addappid(1044630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044631, 1, "0965c64ad48522dbb71fc8cf87b10654cabfdbaed2497a4a6b581f94843c7aff")
