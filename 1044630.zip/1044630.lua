-- Lua provided by RyzenAPI 
-- Game: Choice of the Dragon
addappid(1044630)
addappid(1044631, 1, "0965c64ad48522dbb71fc8cf87b10654cabfdbaed2497a4a6b581f94843c7aff")
