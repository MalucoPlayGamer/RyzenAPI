-- Lua provided by RyzenAPI
-- Game: The Star Named EOS - Artbook

-- MAIN APPLICATION
addappid(2959500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959500,0,"e87e2a8697c538cbe15889d146018e7d8b7475e411d4354fc63e0789b78cb0f2")

