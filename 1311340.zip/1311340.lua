-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2021 DataEditor

-- MAIN APPLICATION
addappid(1311340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311341, 1, "77be7c2b2ed9543f736bc6cfff7fd98695a014623e19d600d8b4ef4784e71cf7")
addappid(1311342, 1, "6a9276e4b66dda3fd56985bb3f3f4f7e9bc7cda9617c02336e8e4b0b2864241c")
addappid(1311343, 1, "04393d14da5690d6e09f6ed1aaa79629fd93852450e81267914de38a49053cd8")
