-- Lua provided by RyzenAPI
-- Game: Let's School Homeroom

-- MAIN APPLICATION
addappid(2431660)
-- Game: addappid(2431660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431661, 1, "2ad279717dc3601e9a3945ad3e0ac2a1a77ff7cbc7bf8e0397ceb2c0f6cf5d36")
