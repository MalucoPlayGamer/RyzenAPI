-- Lua provided by RyzenAPI
-- Game: Game: AppID 1211320

-- MAIN APPLICATION
addappid(1211320)
-- Game: addappid(1211320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211321, 1, "70c94a4bbc301a722688c78aff691de7023aa531baab0a9790c85c362f3d65d6")
