-- Lua provided by RyzenAPI
-- Game: Concrete Jungle

-- MAIN APPLICATION
addappid(400160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(400161, 1, "0ef1811dfd9564ac27cd0f1371c54a1f28e3d5ba5fbdefb0dd845c663fdbf516")
addappid(400162, 1, "8d2b687644758e2bd35c4e457b4c376d9fe1fd1de25cd2e399220c50fca5957c")
