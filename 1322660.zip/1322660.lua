-- Lua provided by RyzenAPI
-- Game: Spitlings Demo

-- MAIN APPLICATION
addappid(1322660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322661, 1, "d77777d37b6addd6038a14c5ec03b14a7700e08c9bc2965d694ce756b41f621d")
