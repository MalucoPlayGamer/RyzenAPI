-- Lua provided by RyzenAPI
-- Game: DOCTOR VISCERA

-- MAIN APPLICATION
addappid(3708660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3708661,0,"d3fb0e7f240b88fe2b26907b3a4d421da267c6e6f88b2cae1fcd1fc7f5243e6b")

