-- Lua provided by RyzenAPI
-- Game: Stickman in the portal

-- MAIN APPLICATION
addappid(853620)

-- MAIN APP DEPOTS / PACKAGES
addappid(853621, 1, "d4538bb2304a94f0315789201424183350601598dc63ba688417e7e212b15fd4")
