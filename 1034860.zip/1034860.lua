-- Lua provided by RyzenAPI
-- Game: Game: GRANDIA HD Remaster

-- MAIN APPLICATION
addappid(1034860)
-- Game: addappid(1034860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034861, 1, "32afe4718ef900f3f3cbf8b8162b4551a1a94fcda021505120c47d20517fa660")
