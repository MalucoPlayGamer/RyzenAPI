-- Lua provided by RyzenAPI
-- Game: GRANDIA HD Remaster

-- MAIN APPLICATION
addappid(1034860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1034861, 1, "32afe4718ef900f3f3cbf8b8162b4551a1a94fcda021505120c47d20517fa660")

