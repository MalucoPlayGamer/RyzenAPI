-- Lua provided by RyzenAPI 
-- Game: GRANDIA HD Remaster
addappid(1034860)
addappid(1034861, 1, "32afe4718ef900f3f3cbf8b8162b4551a1a94fcda021505120c47d20517fa660")
