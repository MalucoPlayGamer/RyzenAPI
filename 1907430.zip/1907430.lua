-- Lua provided by RyzenAPI
-- Game: addappid(1907430)

-- MAIN APPLICATION
addappid(1907430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907431, 1, "71d88b02e77b53391b7d0495c420b8746f1d2a58e08c74a9f96abfcd7d7f925b")
