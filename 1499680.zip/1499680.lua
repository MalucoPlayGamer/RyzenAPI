-- Lua provided by RyzenAPI
-- Game: Game: Ertugrul Gazi

-- MAIN APPLICATION
addappid(1499680)
-- Game: addappid(1499680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499681, 1, "ada2366dc22ba585f9d011be5c3ee3f49dd854b4f6cbd2dade0f8f59c1f87378")
