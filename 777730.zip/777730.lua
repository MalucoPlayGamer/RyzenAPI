-- Lua provided by RyzenAPI
-- Game: addappid(777730)

-- MAIN APPLICATION
addappid(777730)

-- MAIN APP DEPOTS / PACKAGES
addappid(777731, 1, "e0e2d316e7df894a52dec6db94b4437e494f332338a3efceaa8481aa0be071a5")
