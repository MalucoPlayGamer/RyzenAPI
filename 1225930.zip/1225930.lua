-- Lua provided by RyzenAPI
-- Game: 1225930

-- MAIN APPLICATION
addappid(1225930)
-- Game: addappid(1225930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225931, 1, "733d63669c9f93f0729fddcec7316a9d56e47aa83a7568c83de095e28f700274")
