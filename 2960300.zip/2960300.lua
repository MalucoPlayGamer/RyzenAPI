-- Lua provided by RyzenAPI
-- Game: Mars Mirage

-- MAIN APPLICATION
addappid(2960300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2960301,0,"520a3cdc6a3c5423013e895446a5cd0b79b0ee55ce98d04a2a43ef39e75c3d41")

