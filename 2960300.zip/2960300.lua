-- Lua provided by RyzenAPI
-- Game: Mars Mirage

-- MAIN APPLICATION
addappid(2960300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960301,0,"520a3cdc6a3c5423013e895446a5cd0b79b0ee55ce98d04a2a43ef39e75c3d41")

