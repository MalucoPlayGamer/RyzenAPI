-- Lua provided by RyzenAPI
-- Game: OutBreak Zombie

-- MAIN APPLICATION
addappid(792900)

-- MAIN APP DEPOTS / PACKAGES
addappid(792901,0,"488b3ec57c99c361404cdaf8fdcdd43e913f8ff1d0c04a1043fe11d31e9b202d")

