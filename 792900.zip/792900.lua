-- Lua provided by RyzenAPI
-- Game: OutBreak Zombie

-- MAIN APPLICATION
addappid(792900)

-- MAIN APP DEPOTS / PACKAGES
addappid(792901,0,"488b3ec57c99c361404cdaf8fdcdd43e913f8ff1d0c04a1043fe11d31e9b202d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
