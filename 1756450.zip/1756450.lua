-- Lua provided by RyzenAPI
-- Game: 1756450

-- MAIN APPLICATION
addappid(1756450)
-- Game: addappid(1756450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756451, 1, "17dab6e22176fc4d0ec7c7a7173137c640fbf12527d1c7c7edc55be6523fce81")
