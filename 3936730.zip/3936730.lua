-- 3936730's Lua and Manifest Created by Hubcap Manifest
-- STARDUST: Wish of Witch
-- Created: August 06, 2026 at 23:52:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3936730, 1, "12c8bf36353c519f6716b1e5d57fb0a3c6c9e316170b73cde79a0beb0668dd33") -- STARDUST: Wish of Witch
-- MAIN APP DEPOTS
addappid(3936731, 1, "a468120d529ebfd2edf1f5998b7e0368269b5508393e37aff6e2b8117a77f8eb") -- Depot 3936731
setManifestid(3936731, "5595036927604039755", 1076086954)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4990190) -- STARDUST Wish of Witch - Sword of Judgment