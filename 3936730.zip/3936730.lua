-- Lua provided by RyzenAPI
-- Game: STARDUST: Wish of Witch

-- MAIN APPLICATION
addappid(4990190) -- STARDUST Wish of Witch - Sword of Judgment

-- MAIN APP DEPOTS / PACKAGES
addappid(3936730, 1, "12c8bf36353c519f6716b1e5d57fb0a3c6c9e316170b73cde79a0beb0668dd33") -- STARDUST: Wish of Witch
addappid(3936731, 1, "a468120d529ebfd2edf1f5998b7e0368269b5508393e37aff6e2b8117a77f8eb") -- Depot 3936731

