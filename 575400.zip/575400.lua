-- Lua provided by RyzenAPI 
-- Game: Try Hard Parking
addappid(575400)
addappid(575401, 1, "2a4ded922ddc59cff2a6dd86eaa66c073ec62d1e0052b2231b5694aa31057721")
addappid(575402, 1, "1c538cf07220f80a7feb587042fabe44b08e8c589c344c69ff0b2210b65d38eb")
addappid(575403, 1, "6653fdcfc21b76bbc35996dac2072b3efc3de588c94cb91761e869d9605cc62e")
addappid(575404, 1, "8d77e130d372ad2b28fbdecdfb5622b893ef219c9a599e278bc689f17ffd20fb")
