-- Lua provided by RyzenAPI
-- Game: Ultra Mega Cats

-- MAIN APPLICATION
addappid(1882130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1882131, 1, "704a97c2f01903957c323783c717bcb74ff4ec73fa206ff40672f5c627545014")
addappid(3774380, 0, "10ed62c34faa4656bf2be21151b873d3d98ab03d5cfd2e9ffe646336be755e27")

