-- Lua provided by RyzenAPI
-- Game: Game: Ultra Mega Cats

-- MAIN APPLICATION
addappid(1882130)
-- Game: addappid(1882130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882131, 1, "704a97c2f01903957c323783c717bcb74ff4ec73fa206ff40672f5c627545014")
addappid(3774380, 0, "10ed62c34faa4656bf2be21151b873d3d98ab03d5cfd2e9ffe646336be755e27")
