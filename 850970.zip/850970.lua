-- Lua provided by RyzenAPI
-- Game: Game: Plunker

-- MAIN APPLICATION
addappid(850970)
-- Game: addappid(850970)

-- MAIN APP DEPOTS / PACKAGES
addappid(850971, 1, "99417889a79a89f6414b4fa18590b642df0562ae93ab9504092363e7275732c6")
