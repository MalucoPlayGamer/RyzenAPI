-- Lua provided by RyzenAPI
-- Game: AppID 1011390

-- MAIN APPLICATION
addappid(1011390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011391, 1, "e5ee5acda5bcdabff025f47c3e666c19a9fb0701b2d8e9d964aea3ed589cd731")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1257440)
