-- Lua provided by RyzenAPI 
-- Game: AppID 1011390
addappid(1011390)
addappid(1011391, 1, "e5ee5acda5bcdabff025f47c3e666c19a9fb0701b2d8e9d964aea3ed589cd731")
