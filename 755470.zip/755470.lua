-- Lua provided by RyzenAPI
-- Game: The World Next Door

-- MAIN APPLICATION
addappid(755470)

-- MAIN APP DEPOTS / PACKAGES
addappid(755471, 1, "a52fbcec8fb061636f248e886446b9bd58874287ecb1269c1bcfeab8f4faddb9")
addappid(1053860, 0, "4ee1c339b0a080af6e0f801e147b50878af9458dc215ec46dc91b1bb02ece321")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
