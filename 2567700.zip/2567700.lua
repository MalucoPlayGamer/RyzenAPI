-- Lua provided by SkyAPI 
-- Game: JUICY ASS
addappid(2567700)
addappid(2567701, 1, "8676768383f12ae5641fb5a8a0a885c3307892db6986fbc5d5b256e6b2855f52")
