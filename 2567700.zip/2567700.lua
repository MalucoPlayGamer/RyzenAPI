-- Lua provided by RyzenAPI
-- Game: Game: JUICY ASS

-- MAIN APPLICATION
addappid(2567700)
-- Game: addappid(2567700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567701, 1, "8676768383f12ae5641fb5a8a0a885c3307892db6986fbc5d5b256e6b2855f52")
