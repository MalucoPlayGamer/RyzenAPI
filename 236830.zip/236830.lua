-- Lua provided by RyzenAPI
-- Game: AppID 236830

-- MAIN APPLICATION
addappid(236830)
-- Game: addappid(236830)

-- MAIN APP DEPOTS / PACKAGES
addappid(236831, 1, "849a7289dc7ea62ba5d9a0658d0dc1b4d01bb089cc33430dc27734c0792bf143")
addappid(236832, 1, "4862a5b29b8c97c47b2b9f9d41a6632790cc5ce32ecb9f3991a05f75f7e00dce")
addappid(236833, 1, "db71c8d47ba8efdd112d2afa24189bd00fe88766d8edff806b7627db1675ae7b")
addappid(236834, 1, "3318aee3b474bdf6f51525659dad832857f9d0dbb106b5aec5ab84368f9249ad")
addappid(236835, 1, "852fee6aef8f696cbda9d33c0d310d69aca90fc93dff7b17b62d553a6025ffe8")
