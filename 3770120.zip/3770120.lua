-- Lua provided by RyzenAPI
-- Game: Farm Racing

-- MAIN APPLICATION
addappid(3770120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3770121, 1, "00301242ae83652b183f5c159d46bb5db80078f6e8c7b832e15bb9fd47dac1a1")

