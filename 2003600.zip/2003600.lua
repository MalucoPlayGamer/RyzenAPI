-- Lua provided by RyzenAPI
-- Game: 2003600

-- MAIN APPLICATION
addappid(2003600)
-- Game: addappid(2003600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003601, 1, "4fc28cea0bf63c286fa58ebbe3394ffcf86016d958d8b9a08b25a62e2987127f")
