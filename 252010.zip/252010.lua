-- Lua provided by RyzenAPI
-- Game: Oniken: Unstoppable Edition

-- MAIN APPLICATION
addappid(252010)

-- MAIN APP DEPOTS / PACKAGES
addappid(252011, 1, "cfe480fbfe1597b466c23bb4e47738f806ea83e340b7f0001aa9a7b09abfb958")
addappid(252012, 1, "15e8c6dd053ee993b5385e7409bc84b518364c234b5198d9c49d2637424afc0f")
addappid(252013, 1, "dcf7421fb880ddd6f3e5badf0492d148cfd89af1bfe2d0256bae3ce0759bb8c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
