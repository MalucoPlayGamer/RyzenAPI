-- Lua provided by RyzenAPI 
-- Game: AppID 2782980
addappid(2782980)
addappid(2782981, 1, "54d357d5f32be496aaa4a3dbc79568db5d1d5c3ab742f984ae9a96a3fe39c51d")
