-- Lua provided by RyzenAPI
-- Game: 逆光迷途 Lost in Darklight

-- MAIN APPLICATION
addappid(2251020)
-- Game: addappid(2251020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251021, 1, "4e5321ad99b0f44c44aeed8097c890e85ac1599ad0c296bbf263a0657b5a97f6")
