-- Lua provided by RyzenAPI
-- Game: Keyscaper

-- MAIN APPLICATION
addappid(732980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(732981, 1, "f98c5bb670c734c6ead1aed8309c32368781f4ce2d8548c98cb0ad0ed219300d")

