-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2540390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540390,0,"947c9a0c1495f5193b0824b8edf86d6b32eadd10ce1db60f72d450d4a071aa4f")
