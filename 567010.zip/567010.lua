-- Lua provided by RyzenAPI
-- Game: Game Royale 2 - The Secret of Jannis Island

-- MAIN APPLICATION
addappid(567010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(567011, 1, "dfa3b1005cdeffac904fdd879b6efd4abf46f7c26f16af8472787a23486937d8")

