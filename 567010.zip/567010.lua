-- Lua provided by RyzenAPI
-- Game: 567010

-- MAIN APPLICATION
addappid(567010)
-- Game: addappid(567010)

-- MAIN APP DEPOTS / PACKAGES
addappid(567011, 1, "dfa3b1005cdeffac904fdd879b6efd4abf46f7c26f16af8472787a23486937d8")
