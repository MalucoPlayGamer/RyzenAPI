-- Lua provided by RyzenAPI
-- Game: AppID 1538810

-- MAIN APPLICATION
addappid(1538810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538811, 1, "7c8d2bbe72c4aa908cc75a5cbf6aec7e38e04fcbcd3a08997c0bb57c4808cbbf")
