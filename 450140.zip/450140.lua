-- Lua provided by RyzenAPI
-- Game: Seven Kingdoms: Ancient Adversaries

-- MAIN APPLICATION
addappid(450140)

-- MAIN APP DEPOTS / PACKAGES
addappid(450141, 1, "74943eb140e3a8b1602fb926ef6ba556f7113744eb78edeedcb9fb7536c53fe4")
