-- Lua provided by SkyAPI 
-- Game: sususususuusu
addappid(1088590)
addappid(1088591, 1, "9140a3d3675e87c4242d4e03a88a9366fb09471b895e59714bb7549ae67f1933")
