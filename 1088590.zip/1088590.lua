-- Lua provided by RyzenAPI
-- Game: Game: sususususuusu

-- MAIN APPLICATION
addappid(1088590)
-- Game: addappid(1088590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088591, 1, "9140a3d3675e87c4242d4e03a88a9366fb09471b895e59714bb7549ae67f1933")
