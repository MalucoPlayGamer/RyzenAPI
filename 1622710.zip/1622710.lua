-- Lua provided by RyzenAPI
-- Game: Oceanhorn 2: Knights of the Lost Realm

-- MAIN APPLICATION
addappid(1622710)
-- Game: addappid(1622710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622711, 1, "1a209fc8033f23d611fd4b263309c3d0a5c3ab21b453d46063b0f1041f0c6ba3")
