-- Lua provided by RyzenAPI
-- Game: Oceanhorn 2: Knights of the Lost Realm

-- MAIN APPLICATION
addappid(1622710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622711, 1, "1a209fc8033f23d611fd4b263309c3d0a5c3ab21b453d46063b0f1041f0c6ba3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
