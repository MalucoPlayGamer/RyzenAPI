-- Lua provided by RyzenAPI 
-- Game: Furry Meow
addappid(2173700)
addappid(2173701, 1, "4bf7df2fca9517e26257c562a77512c1b9488c1a85b71e52590cf3ba2579bc61")
