-- Lua provided by RyzenAPI
-- Game: Game: 职场上升记

-- MAIN APPLICATION
addappid(2472240)
-- Game: addappid(2472240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472241, 1, "5c0c2ad97fe5c7a41cfdad72e5f1278135896e46f634bfb1fe9f94c42ab47570")
