-- Lua provided by RyzenAPI
-- Game: How Can a Joker Like Me Play Cards with a Beautiful Girl Demo

-- MAIN APPLICATION
addappid(3265170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265171, 1, "f93a4abe5333b7821e645009699330d91f4238eea40df695a4df13827ace3c08")
