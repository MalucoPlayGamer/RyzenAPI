-- Lua provided by RyzenAPI
-- Game: AppID 491580

-- MAIN APPLICATION
addappid(491580)
-- Game: addappid(491580)

-- MAIN APP DEPOTS / PACKAGES
addappid(491581, 1, "b7456283a763658ed4b72ea22474cabacf018268687cff3a23c03b25e1710d40")
