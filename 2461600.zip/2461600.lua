-- Lua provided by SkyAPI 
-- Game: Evil Officer
addappid(2461600)
addappid(2461601, 1, "a532d73bd2104df3c2bac9aa836a1301dfb8766a21e411c1ccc5f91f8a4b35f3")
