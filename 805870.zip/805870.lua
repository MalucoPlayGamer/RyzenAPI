-- Lua provided by RyzenAPI
-- Game: Do you know de way

-- MAIN APPLICATION
addappid(805870)
-- Game: addappid(805870)

-- MAIN APP DEPOTS / PACKAGES
addappid(805871, 1, "f19bd180ea261e7a4f96537f512645585cbd1126cde9295f7cbb6b1f2142811d")
