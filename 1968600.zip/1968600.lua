-- Lua provided by RyzenAPI
-- Game: Lander Odyssey

-- MAIN APPLICATION
addappid(1968600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968601, 1, "d7076cd83b8358b319816a3b6a301a778adec36ed633af574e6641255b8ed5e3")
