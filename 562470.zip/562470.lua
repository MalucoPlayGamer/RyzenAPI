-- Lua provided by RyzenAPI
-- Game: Game: Empire of Angels IV

-- MAIN APPLICATION
addappid(562470)
-- Game: addappid(562470)

-- MAIN APP DEPOTS / PACKAGES
addappid(562471, 1, "72e1a254a72a8d6a73e0aec219dec5207d71235f67046887b8c773b9615b0438")
