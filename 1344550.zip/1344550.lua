-- Lua provided by RyzenAPI 
-- Game: Warspace 2
addappid(1344550)
addappid(1344551, 1, "6079748e55b5555ecf97086eed0ebbc473c8f4dd606564c03d53575c74c2e8ed")
addappid(3094410)
