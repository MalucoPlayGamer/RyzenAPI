-- Lua provided by RyzenAPI
-- Game: 1344550

-- MAIN APPLICATION
addappid(1344550)
addappid(3094410)
-- Game: addappid(1344550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344551, 1, "6079748e55b5555ecf97086eed0ebbc473c8f4dd606564c03d53575c74c2e8ed")
