-- Lua provided by RyzenAPI
-- Game: 2253460

-- MAIN APPLICATION
addappid(2253460)
-- Game: addappid(2253460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253461, 1, "59c3908609493190ecf6b09eff614a7cc56d9f70d8b2ab1490f96967ea8f064f")
