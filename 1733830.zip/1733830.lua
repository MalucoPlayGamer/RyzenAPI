-- Lua provided by RyzenAPI
-- Game: Selfmade Devil

-- MAIN APPLICATION
addappid(1733830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733831, 1, "98aab136758fc8c336b0673a84f53525b74976a72057aa8cad456d486838d400")

