-- Lua provided by RyzenAPI
-- Game: Aquilon Lust: Sex Arcana

-- MAIN APPLICATION
addappid(3427140)
addappid(3525900)
addappid(3525910)
addappid(3525920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427141, 1, "08ac3f01aecb09eb5d0d50ca76895bcdc13381e17bc12cceddf487f67f0f41c2")

