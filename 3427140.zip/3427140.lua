-- Lua provided by RyzenAPI
-- Game: Game: Aquilon Lust: Sex Arcana

-- MAIN APPLICATION
addappid(3427140)
-- Game: addappid(3427140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427141, 1, "08ac3f01aecb09eb5d0d50ca76895bcdc13381e17bc12cceddf487f67f0f41c2")
