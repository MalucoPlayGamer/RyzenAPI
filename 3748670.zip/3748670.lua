-- Lua provided by RyzenAPI
-- Game: Near-Mage - Digital Artbook

-- MAIN APPLICATION
addappid(3748670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3748670,0,"705cb0f857d2e3bffaf498937c51bcdf8dec49a4c469fa19d6317c527b117b72")

