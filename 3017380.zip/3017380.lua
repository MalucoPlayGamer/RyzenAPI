-- Lua provided by RyzenAPI
-- Game: 100 Egypt Cats

-- MAIN APPLICATION
addappid(3017380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017381, 1, "3cad9946e345e1f5ce53446fb2d631c8b45c433e426b6cbca3dcd2715784293d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3496380)
