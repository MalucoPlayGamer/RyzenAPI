-- Lua provided by RyzenAPI
-- Game: Hero's Land

-- MAIN APPLICATION
addappid(2349820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349821, 1, "9744cf91e311141d253c46ca7a89a75fa6ba2d86f5d29ff3b5a4141413a62f81")

