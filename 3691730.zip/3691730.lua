-- Lua provided by RyzenAPI
-- Game: Sweet Delivery

-- MAIN APPLICATION
addappid(3691730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3691731, 1, "2c01aea237e957078484bd887ceef741243500943ebe560e85659f4c1bb0a303")
