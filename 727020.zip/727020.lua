-- Lua provided by RyzenAPI
-- Game: AppID 727020

-- MAIN APPLICATION
addappid(727020)
-- Game: addappid(727020)

-- MAIN APP DEPOTS / PACKAGES
addappid(727021, 1, "d83258dff8d67e0685186c717042d33d53044c7db6bb738d15de47a6531a9784")
