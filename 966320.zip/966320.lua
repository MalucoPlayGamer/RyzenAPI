-- Lua provided by RyzenAPI 
-- Game: Later Alligator
addappid(966320)
addappid(966321, 1, "01747cde3b23a0fd9ea6982c2870ee115c7ac5b0b6acbcab135df838d19ca446")
addappid(966322, 1, "9e4e283484a46addbd5d5251949681bc11e3ca32133a5976b6d88bce143d5d92")
