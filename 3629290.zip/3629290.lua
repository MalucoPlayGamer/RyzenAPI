-- Lua provided by RyzenAPI
-- Game: Paragnosia: Museum

-- MAIN APPLICATION
addappid(3629290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629291,0,"15e78439b82e81fa3e0cc1fe038e44ebc0c9b8fa6bbf60f44d79a660f4460c5f")

