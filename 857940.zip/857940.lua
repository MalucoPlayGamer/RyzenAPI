-- Lua provided by RyzenAPI
-- Game: Nature Calls

-- MAIN APPLICATION
addappid(857940)

-- MAIN APP DEPOTS / PACKAGES
addappid(857941, 1, "f4c6b9ecc44e1542a8ca82b896aafa4792591c2c7473456efaabdfb32fb0c31f")
