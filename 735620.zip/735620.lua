-- Lua provided by RyzenAPI
-- Game: 735620

-- MAIN APPLICATION
addappid(735620)
-- Game: addappid(735620)

-- MAIN APP DEPOTS / PACKAGES
addappid(735621, 1, "f3138f955e08c94eba5d8f3f40815b0f5a8e3afb483b37fd804c7a204447b8b0")
