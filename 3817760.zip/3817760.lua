-- Lua provided by RyzenAPI
-- Game: Game: Trash Collector Simulator: Survive Edition

-- MAIN APPLICATION
addappid(3817760)
-- Game: addappid(3817760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3817761, 1, "71f7b19dd428eda44867584231ee15e22431375ea56b78164738ff623e2d9477")
