-- Lua provided by RyzenAPI
-- Game: 2569820

-- MAIN APPLICATION
addappid(2569820)
-- Game: addappid(2569820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569821, 1, "7f489173a1ff5ba6bff0d58cb0c1d13af05e9573d22c08bc1fe9c253494a2c8a")
