-- Lua provided by RyzenAPI
-- Game: Manic Mechanics

-- MAIN APPLICATION
addappid(2569820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569821, 1, "7f489173a1ff5ba6bff0d58cb0c1d13af05e9573d22c08bc1fe9c253494a2c8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
