-- Lua provided by RyzenAPI
-- Game: Гордость Улыпа. VR-легенды Чувашии

-- MAIN APPLICATION
addappid(2736390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736391, 1, "2f29847f8c32b11b93b29fcacecce8acaf2b6bc441a67acc3a76bec61f28a5f4")
