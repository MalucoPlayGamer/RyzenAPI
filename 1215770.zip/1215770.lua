-- Lua provided by RyzenAPI
-- Game: Naked Story (Sports Festival Ver)

-- MAIN APPLICATION
addappid(1215770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215771, 1, "c6d36c498505777b9ce018a85ff9f7378917cb40ce0b670163b44951c1becce4")
addappid(1215772, 1, "1ec76a982e7c9a3134f6a30f4127e4f45e291bc089dccef15e993db7ee41068b")
addappid(1215773, 1, "fa6f3d57a413b8f59aa126ad61eb2ccc7cacc3f04b5a6dd56914581c87d1f4a2")
