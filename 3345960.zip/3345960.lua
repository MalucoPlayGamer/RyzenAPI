-- Lua provided by RyzenAPI
-- Game: 贝如塔医院 Beta Hospital

-- MAIN APPLICATION
addappid(3345960)
addappid(4305870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345964,0,"1632fc41c035812d8d5213175bd577d8ecea6a3bf3e228d05ac49c19dab48980")

