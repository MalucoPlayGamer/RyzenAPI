-- Lua provided by RyzenAPI
-- Game: Rise of Incarnates

-- MAIN APPLICATION
addappid(228983)
addappid(228990)
addappid(229031)
addappid(258160)
addappid(258161)

-- MAIN APP DEPOTS / PACKAGES
addappid(258162,0,"21d030eeb276fac64442965f6ee12d0448cdadf9c25f2f9460cfce371155e011")
addappid(258163,0,"1389b9778e9e09be4790bab86693fba4bc4d41193b7e2f11ec71facce4550f8d")

