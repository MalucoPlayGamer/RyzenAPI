-- Lua provided by RyzenAPI
-- Game: Loophole

-- MAIN APPLICATION
addappid(3629400)
-- Game: addappid(3629400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629401, 1, "fd7dcb050f744ad27f17e6a26cdf6d6b5273146d0684e5584eaaa4c637cb1972")
