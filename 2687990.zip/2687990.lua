-- Lua provided by SkyAPI 
-- Game: The Black Guards of Odom - Desert Town Prison
addappid(2687990)
addappid(2687991, 1, "907298cb2c7e7ca06059f0fc53a525ae8b946138f93cbe717edf4ab6d5bbba46")
addappid(2687992, 1, "62db3c0910cedfbcad3707dd35e31c6c415d941f61cb4824bccabeebc64a3fca")
addappid(2687993, 1, "6e750c7d5331fa3050006e73ac12fdbae01b51387e5f381b67a1188bfd1c2bb0")
