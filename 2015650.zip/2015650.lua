-- Lua provided by RyzenAPI
-- Game: Game: Disembowel

-- MAIN APPLICATION
addappid(2015650)
-- Game: addappid(2015650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015651, 1, "68ebe7c7c52554f3c41641ef0e91102ef96189df697a969a9e586935f1cc078e")
