-- Lua provided by RyzenAPI
-- Game: Kingdom Under Fire: A War of Heroes (GOLD Edition)

-- MAIN APPLICATION
addappid(2183600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2183601, 1, "36774107f9645db3b3eb64c518d174e4d8d672c54286c44e11e19312dc864b03")

