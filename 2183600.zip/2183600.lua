-- Lua provided by RyzenAPI
-- Game: Kingdom Under Fire: A War of Heroes (GOLD Edition)

-- MAIN APPLICATION
addappid(2183600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183601, 1, "36774107f9645db3b3eb64c518d174e4d8d672c54286c44e11e19312dc864b03")

