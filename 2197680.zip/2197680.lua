-- Lua provided by RyzenAPI
-- Game: That Time I Got Reincarnated as a Slime ISEKAI Chronicles

-- MAIN APPLICATION
addappid(2197680)
addappid(2788640)
addappid(2788650)
addappid(2788670)
addappid(2788680)
addappid(2788690)
addappid(2788700)
addappid(2788730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197681,0,"753312d661b8597395743cfeeaa70ac6b7bbf87779edbcc6863c0d88dd046749")

