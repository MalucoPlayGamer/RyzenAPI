-- Lua provided by RyzenAPI
-- Game: That Time I Got Reincarnated as a Slime ISEKAI Chronicles

-- MAIN APPLICATION
addappid(2197680)
-- Game: addappid(2197680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197681, 1, "753312d661b8597395743cfeeaa70ac6b7bbf87779edbcc6863c0d88dd046749")
