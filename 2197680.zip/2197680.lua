-- Lua provided by RyzenAPI
-- Game: That Time I Got Reincarnated as a Slime ISEKAI Chronicles

-- MAIN APPLICATION
addappid(2197680)
addappid(2788640)
addappid(2788650)
addappid(2788670)
addappid(2788680)
addappid(2788690)
addappid(2788700)
addappid(2788730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2197681,0,"753312d661b8597395743cfeeaa70ac6b7bbf87779edbcc6863c0d88dd046749")

