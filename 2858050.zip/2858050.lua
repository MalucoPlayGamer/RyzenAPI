-- Lua provided by RyzenAPI
-- Game: Muchi Muchi SEXTRA

-- MAIN APPLICATION
addappid(2858050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858051, 1, "e6c8a649eebb1667652e02cddcd824d409cbff3cf6b9c72bee5be02e63573f33")
