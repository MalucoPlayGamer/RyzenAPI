-- Lua provided by RyzenAPI
-- Game: addappid(2552630)

-- MAIN APPLICATION
addappid(2552630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552631, 1, "49e5995f5a2636b36cdde0a1ca1987a3aab52348d4a09fa7db4cee7308cf0812")
