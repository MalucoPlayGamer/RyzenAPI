-- Lua provided by RyzenAPI
-- Game: Cities: Skylines

-- MAIN APPLICATION
addappid(346791) -- Cities Skylines - Deluxe Edition Upgrade Pack
addappid(369150) -- Cities Skylines - After Dark
addappid(420610) -- Cities Skylines - Snowfall
addappid(456200) -- Cities Skylines - Match Day
addappid(515190) -- Cities Skylines - Content Creator Pack Art Deco
addappid(515191) -- Cities Skylines - Natural Disasters
addappid(547500) -- Cities Skylines - Content Creator Pack High-Tech Buildings
addappid(547501)
addappid(547502) -- Cities Skylines - Mass Transit
addappid(563850) -- Cities Skylines - Pearls From the East
addappid(614580) -- Cities Skylines - Green Cities
addappid(614581)
addappid(614582)
addappid(715190) -- Cities Skylines - Content Creator Pack European Suburbia
addappid(715191) -- Cities Skylines - Parklife
addappid(715192)
addappid(715193)
addappid(715194) -- Cities Skylines - Industries
addappid(815380)
addappid(944070)
addappid(944071) -- Cities Skylines - Campus
addappid(1059820) -- Cities Skylines - Content Creator Pack University City
addappid(1065490)
addappid(1065491)
addappid(1146930) -- Cities Skylines - Sunset Harbor
addappid(1148020) -- Cities Skylines - Content Creator Pack Modern City Center
addappid(1148021)
addappid(1148022) -- Cities Skylines - Content Creator Pack Modern Japan
addappid(1196100)
addappid(1531470) -- Cities Skylines - Content Creator Pack Train Stations
addappid(1531471) -- Cities Skylines - Content Creator Pack Bridges  Piers
addappid(1531472)
addappid(1531473)
addappid(1726380) -- Cities Skylines - Airports
addappid(1726381) -- Cities Skylines - Content Creator Pack Vehicles of the World
addappid(1726382) -- Cities Skylines - Content Creator Pack Map Pack
addappid(1726383)
addappid(1726384)
addappid(1992290) -- Cities Skylines - Content Creator Pack Mid-Century Modern
addappid(1992291) -- Cities Skylines - Content Creator Pack Seaside Resorts
addappid(1992292)
addappid(1992293)
addappid(2008400) -- Cities Skylines - Plazas  Promenades
addappid(2144480) -- Cities Skylines - Content Creator Pack Heart of Korea
addappid(2144481) -- Cities Skylines - Content Creator Pack Skyscrapers
addappid(2144482)
addappid(2144483)
addappid(2148900) -- Cities Skylines - Content Creator Pack Africa in Miniature
addappid(2148901) -- Cities Skylines - Financial Districts
addappid(2148902)
addappid(2148903) -- Cities Skylines - Content Creator Pack Map Pack 2
addappid(2148904)
addappid(2224690) -- Cities Skylines - Content Creator Pack Sports Venues
addappid(2224691) -- Cities Skylines - Content Creator Pack Shopping Malls
addappid(2225940)
addappid(2225941)
addappid(2313320) -- Cities Skylines - Content Creator Pack Brooklyn  Queens
addappid(2313321) -- Cities Skylines - Content Creator Pack Railroads of Japan
addappid(2313322) -- Cities Skylines - Content Creator Pack Industrial Evolution
addappid(2313323)
addappid(2313324)
addappid(2342310) -- Cities Skylines - Hotels  Retreats
addappid(2934300) -- Cities Skylines - Expansion Subscription
addappid(2955870) -- Cities Skylines - Content Creator Pack Mountain Village
addappid(2955880) -- Cities Skylines - Content Creator Pack Map Pack 3
addappid(2955890)
addappid(2955900) -- Cities Skylines - Content Creator Pack Countryside
addappid(2955910) -- Cities Skylines - Content Creator Pack Emerging Downtown
addappid(2955920)
addappid(3731500) -- Cities Skylines - Content Creator Pack Shops of Shibuya
addappid(3731510) -- Cities Skylines - Content Creator Pack Map Pack 4
addappid(3731530)
addappid(4031130) -- Cities Skylines - Race Day
addappid(4031140) -- Cities Skylines - Content Creator Pack Renewed History
addappid(4031150) -- Cities Skylines - Content Creator Pack Iconic Brutalism
addappid(4031160)
-- addappid(340160) -- Depot 340160 (empty depot)
-- addappid(346790) -- Depot 346790 (empty depot)
-- addappid(346791) -- Depot 346791 (empty depot)
-- addappid(365040) -- Depot 365040 (empty depot)
-- addappid(369150) -- Depot 369150 (empty depot)
-- addappid(420610) -- Depot 420610 (empty depot)
-- addappid(456200) -- Depot 456200 (empty depot)
-- addappid(515190) -- Depot 515190 (empty depot)
-- addappid(515191) -- Depot 515191 (empty depot)
-- addappid(525940) -- Depot 525940 (empty depot)
-- addappid(526610) -- Depot 526610 (empty depot)
-- addappid(526611) -- Depot 526611 (empty depot)
-- addappid(526612) -- Depot 526612 (empty depot)
-- addappid(536610) -- Depot 536610 (empty depot)
-- addappid(547500) -- Depot 547500 (empty depot)
-- addappid(547501) -- Depot 547501 (empty depot)
-- addappid(547502) -- Depot 547502 (empty depot)
-- addappid(563850) -- Depot 563850 (empty depot)
-- addappid(614580) -- Depot 614580 (empty depot)
-- addappid(614581) -- Depot 614581 (empty depot)
-- addappid(614582) -- Depot 614582 (empty depot)
-- addappid(715190) -- Depot 715190 (empty depot)
-- addappid(715191) -- Depot 715191 (empty depot)
-- addappid(715192) -- Depot 715192 (empty depot)
-- addappid(715193) -- Depot 715193 (empty depot)
-- addappid(715194) -- Depot 715194 (empty depot)
-- addappid(815380) -- Depot 815380 (empty depot)
-- addappid(944070) -- Depot 944070 (empty depot)
-- addappid(944071) -- Depot 944071 (empty depot)
-- addappid(1059820) -- Depot 1059820 (empty depot)
-- addappid(1065490) -- Depot 1065490 (empty depot)
-- addappid(1065491) -- Depot 1065491 (empty depot)
-- addappid(1146930) -- Depot 1146930 (empty depot)
-- addappid(1148020) -- Depot 1148020 (empty depot)
-- addappid(1148021) -- Depot 1148021 (empty depot)
-- addappid(1148022) -- Depot 1148022 (empty depot)
-- addappid(1196100) -- Depot 1196100 (empty depot)
-- addappid(1531472) -- Depot 1531472 (empty depot)
-- addappid(1531473) -- Depot 1531473 (empty depot)
-- addappid(1726383) -- Depot 1726383 (empty depot)
-- addappid(1726384) -- Depot 1726384 (empty depot)
-- addappid(1992292) -- Depot 1992292 (empty depot)
-- addappid(1992293) -- Depot 1992293 (empty depot)
-- addappid(2144482) -- Depot 2144482 (empty depot)
-- addappid(2144483) -- Depot 2144483 (empty depot)
-- addappid(2148902) -- Depot 2148902 (empty depot)
-- addappid(2148904) -- Depot 2148904 (empty depot)
-- addappid(2225940) -- Depot 2225940 (empty depot)
-- addappid(2225941) -- Depot 2225941 (empty depot)
-- addappid(2313323) -- Depot 2313323 (empty depot)
-- addappid(2313324) -- Depot 2313324 (empty depot)
-- addappid(2955890) -- Depot 2955890 (empty depot)
-- addappid(2955920) -- Depot 2955920 (empty depot)
-- addappid(3731530) -- Depot 3731530 (empty depot)
-- addappid(4031160) -- Depot 4031160 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(255710, 1, "624bcd6cc6783aaaf17722fb0bfb8a17b1d687e7b76c32b6f038307e1deab622") -- Cities: Skylines
addappid(255711, 1, "125653faaac1bad58ea92c82059dcbe10705c04cd5c97e847c4f68b535fe24a6") -- Cities: Skylines Windows
addappid(255712, 1, "8b92cc0e5effe6aae01b10e49408f561ebd6a8b4f72c8d9534758e123eba3464") -- Cities: Skylines OSX
addappid(255713, 1, "7a309e01d09daf057aee177d1645ffb3233b7199a24da2fe28fbf4cb87ac5c91") -- Cities: Skylines Linux
addappid(255714, 1, "7fcfe06a667ea8db815ac5d6f6a085b9356ceb39d648f16ceebc9b2e63d560c4") -- Cities Skylines - Relaxation Station - Cities: Skylines - Station1 Win
addappid(255715, 1, "efb97ce4b64d8acd9db5f3a1b557c202d7dfec9bf50999cef10d3a55d87cc69f") -- Cities Skylines - Relaxation Station - Cities: Skylines - Station1 OSX
addappid(255716, 1, "f40ba8a2adca78fc5f9f7599c3eec84071d768d6526b766009b769bf0832ad92") -- Cities Skylines - Relaxation Station - Cities: Skylines - Station1 Linux
addappid(255717, 1, "3bf4014a381fcaa010ab5c49a3d379f07679456cc8347e79726afdfec8960e60") -- Cities Skylines - Rock City Radio - Cities: Skylines - Station2 Win
addappid(255718, 1, "739c9129f0d056259cf7aa4b2cb47c659e1be629725c26923ff1eaea80598de0") -- Cities Skylines - Rock City Radio - Cities: Skylines - Station2 OSX
addappid(255719, 1, "df8111ddb3496994aae7c48f8c40583ecfeb88ad4392b0d41f8f9bef0e384254") -- Cities Skylines - Rock City Radio - Cities: Skylines - Station2 Linux
addappid(255720, 1, "88efcde6dad72f42df80d041f337294a8eeaf033204d3895c67e1e4674baad96") -- Cities Skylines - Concerts - Cities: Skylines - Event Win
addappid(255721, 1, "7b56bead9fac9e4482cd126d78ab0aa8ac769a36e701256d662ab4783ad51c9a") -- Cities Skylines - Concerts - Cities: Skylines - Event OSX
addappid(255722, 1, "a08bb860b36673d01bda6747b5ce305f4158f0e19c5f5b62a6196c58a876ddf3") -- Cities Skylines - Concerts - Cities: Skylines - Event Linux
addappid(255723, 1, "9f5cad514a854a2e69156f6f15be1e71b1cc7d82e534579eb34140ea5cb0752a") -- Cities Skylines - Carols, Candles and Candy - Cities: Skylines - AppID1 Win
addappid(255724, 1, "bc598610a321a7ef1c910fc0e61c93be4318dc79c3d2a5408b0327b38fe9aafe") -- Cities Skylines - Carols, Candles and Candy - Cities: Skylines - AppID1 OSX
addappid(255725, 1, "402bca8a2c3cfe139fdc8f578ec9db295dbd9456854100ff78d5470338493ff8") -- Cities Skylines - Carols, Candles and Candy - Cities: Skylines - AppID1 Linux
addappid(255726, 1, "d21c408150c7aeee48f009d90f2c8379a482d4b350eac3456e2fd6412798f4f1") -- Cities Skylines - All That Jazz - Cities: Skylines - AppID2 Win
addappid(255727, 1, "971b1dcc1143566aaac2f595e39c5546b43375fe17912502a091f4c937b4c3a3") -- Cities Skylines - All That Jazz - Cities: Skylines - AppID2 OSX
addappid(255728, 1, "d689e0e229b0116834440542e7816f42c501088274d464aa97a2d2171ad58846") -- Cities Skylines - All That Jazz - Cities: Skylines - AppID2 Linux
addappid(340161, 1, "818cd8e997974337e8ee6f89673a057877eac9e2a6ed95f0d6143362ee7dd7bd") -- Cities Skylines - On Air Radio - Depot 340161
addappid(340162, 1, "460efa99f378cad419a9775fa14f95803e658ec3bc404e517dbb41598187b518") -- Cities Skylines - On Air Radio - Depot 340162
addappid(340163, 1, "b63f0566e265d2cbd7a332decc2f082c97d8ec21edbb647f3884e5ab2593514e") -- Cities Skylines - On Air Radio - Depot 340163
addappid(340164, 1, "086376a5b651fd3bc70b349385d8ae86a79af9b291ed2c49568d21fdb98840bc") -- Cities Skylines - Calm The Mind Radio - Depot 340164
addappid(340165, 1, "9850fbf3d046d21d99531801ccf703c7fef95586ed743d6cf8747cd81052b17f") -- Cities Skylines - Calm The Mind Radio - Depot 340165
addappid(340166, 1, "98012feffaac08868a749b69ce2ebf753a0816844976d0a092fb7e5f00a741c6") -- Cities Skylines - Calm The Mind Radio - Depot 340166
addappid(340167, 1, "b50536032fbcacdafa7ddb24e1abbf272a808e1881991c09518f3e2ddb487a93") -- Cities Skylines - Piano Tunes Radio - Depot 340167
addappid(340168, 1, "a09be0e2df8dc1e3facd033bca905caa327bda7463a9e3b5beeb14fe090b925a") -- Cities Skylines - Piano Tunes Radio - Depot 340168
addappid(340169, 1, "f1ab804104a529fe82505d66f5564de74765a68ee01d2cf6f794b6881c068096") -- Cities Skylines - Piano Tunes Radio - Depot 340169
addappid(346793, 1, "c37d34546779a8678346002969cceaa7090df2a327bdd65111153e1c1bd7a66e") -- Cities Skylines - 90s Pop Radio - Depot 346793
addappid(346794, 1, "b28af0a5027bbb4fe2b29122531c42bf77ff3f81710ee0afd77b36592980783c") -- Cities Skylines - 90s Pop Radio - Depot 346794
addappid(346795, 1, "5eb7b5a118eac661102dbe13f2060ab272285b94e3fb051843a493bacddc0e24") -- Cities Skylines - 90s Pop Radio - Depot 346795
addappid(346796, 1, "5b219e83029bfa53ed2586ba341bd8813ac71beb497b198d61d00ec6c91e9e47") -- Cities Skylines - Harvest Harmony - Depot 346796
addappid(346797, 1, "dbf8f5cb2b2f1c703af2f187c357b4c069261a71936c7d1a655b70aca0f11d32") -- Cities Skylines - Harvest Harmony - Depot 346797
addappid(346798, 1, "6dc83260866056a1a44a519862d65941625ada38d8bb9e81a3b8effc29b5f43b") -- Cities Skylines - Harvest Harmony - Depot 346798
addappid(352510, 1, "e65d744bca9d5cb2a7fe1e16d8d3c2f8d4fafc219d4cc7bdd9ef5c03f89157ed") -- Cities: Skylines - Soundtrack (352510) Depot
addappid(352511, 1, "3885ecb5bdd0348394a2b36d74b88c1278f63c4d74a6311ba7dddd93512fbf5f") -- Cities: Skylines - The Architecture Artbook (352511) Depot
addappid(352512, 1, "77fab0114fb10f2f3cd6204ed53b8d88cf04cfa6d37268b3ee99e74aabe4d650") -- Cities: Skylines - The Monuments Booklet (352512) Depot
addappid(355600, 1, "1784a931fcade32b697550d07880b21abfb6c358fce9de3994f1e4af73624357") -- Cities Skylines - Post Cards (355600) Depot
addappid(761947, 1, "40e30e7c0ecb3ac9763a0abb4e56e380bb0fee7d0521be8e5de8c7abdb44fe47") -- Cities Skylines - Alpine Tunes Radio - Depot 761947
addappid(761948, 1, "aecb31165cecf3d1c935739ad2765c565d179f2451ff53399ce210820de736dd") -- Cities Skylines - Alpine Tunes Radio - Depot 761948
addappid(761949, 1, "3ed87bc5fca2075331666dde80c712cb5a84d29f2e66728bec8f12f9fe316367") -- Cities Skylines - Alpine Tunes Radio - Depot 761949
addappid(815381, 1, "73495a33cbedc2742bb3df9b1d1e375a45327ed74dc07fe0c7759d8956895d31") -- Cities Skylines - Country Road Radio - Cities: Skylines - CRR Win
addappid(815382, 1, "a1b4c264baca561a983c412ec79a9f60ad9b8f774e1460388a668cc93bf7cc84") -- Cities Skylines - Country Road Radio - Cities: Skylines - CRR OSX
addappid(815383, 1, "a525a730ef7e286e60e9b8f79fda42a47a234a13b39d603857ff861977598581") -- Cities Skylines - Country Road Radio - Cities: Skylines - CRR Linux
addappid(944072, 1, "59a3e0bc98713eb0dd79ea422fe08faf9c84d6ab99355efb4e6ef3329cb19382") -- Cities Skylines - Synthetic Dawn Radio - Cities: Skylines - Synthetic Dawn Radio Win
addappid(944073, 1, "a33e252c8cde3a006e1911da3837ad0c4677789aee35e8ec7840d72f47c3f35d") -- Cities Skylines - Synthetic Dawn Radio - Cities: Skylines - Synthetic Dawn Radio OSX
addappid(944074, 1, "dd16bb91fb7cc5d9e2c6c6f153f78dfe328c7c7feb35ceef28d72d9d2bbc7bb4") -- Cities Skylines - Synthetic Dawn Radio - Cities: Skylines - Synthetic Dawn Radio Linux
addappid(1065492, 1, "848aa9ffcb484d3439f20b7f3782b81d558045627058dadb34f3b32b9953f216") -- Cities Skylines - Deep Focus Radio - Cities: Skylines - Radio Station 6 Win
addappid(1065493, 1, "983729d8ce46da5066be88351e48cc2bebc18faa5ca87556b84f1b1be5d5f0b0") -- Cities Skylines - Deep Focus Radio - Cities: Skylines - Radio Station 6 OSX
addappid(1065494, 1, "1c94923473db6498cffa25830e71363b5a47bf8e8d18578369981addddf9e75f") -- Cities Skylines - Deep Focus Radio - Cities: Skylines - Radio Station 6 Linux
addappid(1065495, 1, "f2403e96c73ffc6295258faee73faca29fdf99905832f050c6a7d95e51328605") -- Cities Skylines - Campus Radio - Cities: Skylines - Radio Station 7 Win
addappid(1065496, 1, "4442e0f044aefb9d39ca8f94b0ddc976c3bc663a8609dee4ceb63f8d80cef744") -- Cities Skylines - Campus Radio - Cities: Skylines - Radio Station 7 OSX
addappid(1065497, 1, "6c8597525f45f463539b5cd52aaef115aa38e550115e6786b7a847c06dabfedf") -- Cities Skylines - Campus Radio - Cities: Skylines - Radio Station 7 Linux
addappid(1148023, 1, "0fd70f29e1bad1179aeebede80845a5fdcb470c102148b7a152d582654eb9750") -- Cities Skylines - Downtown Radio - Cities: Skylines - Chocolate Win
addappid(1148024, 1, "103ce29a6e5a1fe243ce8f182afa3b717d8b4c06a3b01fc873c754fdcf191182") -- Cities Skylines - Downtown Radio - Cities: Skylines - Chocolate OSX
addappid(1148025, 1, "182a570f256046e6cffa7d434e853b994a55c0d2d52e9154ba706296540fe625") -- Cities Skylines - Downtown Radio - Cities: Skylines - Chocolate Linux
addappid(1196101, 1, "79efe2737c98dfdca6c6eb77cf6d40f1b5e6fe8180b8e7fd5dbbc2dce41192c8") -- Cities Skylines - Coast to Coast Radio - Cities: Skylines - Cookies Win
addappid(1196102, 1, "52c699b95fa97e1428b9b093d3dca281e69a15db9407a9db13af34e7f3c7da31") -- Cities Skylines - Coast to Coast Radio - Cities: Skylines - Cookies OSX
addappid(1196103, 1, "58e607150aa3b2b834d2a522b9b9f6b2c40003df48f71344bb682352a9257bc3") -- Cities Skylines - Coast to Coast Radio - Cities: Skylines - Cookies Linux
addappid(1531474, 1, "c8375e4f2a1e9c97bb94fc0e84f1580a9c8d52003d77871c90886d666316daca") -- Cities Skylines - Rail Hawk Radio - Cities: Skylines - Hawk Win
addappid(1531475, 1, "3219c75974d126c6f3b7bfebe83942dd6777f90dd26f06756c981d53752e722c") -- Cities Skylines - Rail Hawk Radio - Cities: Skylines - Hawk OSX
addappid(1531476, 1, "ba2a64170b5f0a69a4dc3103c8171112ba7c0e5934a679fac93953a4a02e890f") -- Cities Skylines - Rail Hawk Radio - Cities: Skylines - Hawk Linux
addappid(1531477, 1, "d32d610aca38424af4f8fee4bdbeccb073cd59cdf7cc612eeb11b8043117fb0e") -- Cities Skylines - Sunny Breeze Radio - Cities: Skylines - Breeze Win
addappid(1531478, 1, "fd5fba1478a69cbe0d79e6e4859294eda30216770ca70cce7adb91b41561b6e7") -- Cities Skylines - Sunny Breeze Radio - Cities: Skylines - Breeze OSX
addappid(1531479, 1, "9c24571449bab4e2dadafe53d5de073fbdbde57f7bb36139f5db51dcffa2f477") -- Cities Skylines - Sunny Breeze Radio - Cities: Skylines - Breeze Linux
addappid(1616458, 1, "3d85fcc861795b2bb0ca5283bc569895f8d753f7a8a4d55d131af549408d4e80") -- Cities Skylines - 8 Gear Radio - Depot 1616458
addappid(1616459, 1, "06cc873bcf0ba8acc2cad50aadf0909ff262770f9cfaaa299e19301f8b9e45d9") -- Cities Skylines - 8 Gear Radio - Depot 1616459
addappid(2008401, 1, "2f14bf7eef76208e86f9d40f795938d73d1dd3d855c47fe05e1a7148b4b97587") -- Cities Skylines - Shoreline Radio - Depot 2008401
addappid(2008402, 1, "48774954cf4636f06d80f85a0c500d58a92db4cbfa7b966b4a21b1a82107754f") -- Cities Skylines - Shoreline Radio - Depot 2008402
addappid(2008403, 1, "def7673b7ced9ef6d78c78e8cee04c30cb3824b440b737476202b099d83dd13d") -- Cities Skylines - Shoreline Radio - Depot 2008403
addappid(2008404, 1, "52e7b7837cbe203c28e79a0192ac7f62666dcbed476f1c70424905a15af7372a") -- Cities Skylines - Paradise Radio - Depot 2008404
addappid(2008405, 1, "4e583ce4a34f6556ff65046f9f7b0045e4ec7327cd439df768d1d76498ee4ac3") -- Cities Skylines - Paradise Radio - Depot 2008405
addappid(2008406, 1, "c8cf3bffecbb80fa0b5ecd2f86d61ca3cde14d2637deb85174427d1b6d0fcea9") -- Cities Skylines - Paradise Radio - Depot 2008406
addappid(2144485, 1, "12f2e3b3df395f1a960ca3aacfb7c2a599cdf38f5042c373814c125c970ab478") -- Cities Skylines - 80s Downtown Beat - Depot 2144485
addappid(2144486, 1, "b23df440e0343cf0de558102d4b698c75841debabbc2c08e4a4c9009f13bb639") -- Cities Skylines - 80s Downtown Beat - Depot 2144486
addappid(2144487, 1, "3c790f9199071fc6db17dd6ba44e7ee50857ae137f677541d37b8de516101783") -- Cities Skylines - 80s Downtown Beat - Depot 2144487
addappid(2148907, 1, "c286ac283dd5ec1be6fbeb739eae9e8cf5e455ee3b528a75a88ccf7fa8a541ef") -- Cities Skylines - K-pop Station - Depot 2148907
addappid(2148908, 1, "e2c3a2c280aa3abc3bb54e3e2a5cc44bdbaf7ebd6f9b2d33db4490bda09241f5") -- Cities Skylines - K-pop Station - Depot 2148908
addappid(2148909, 1, "232f281ce643d46bee52c4c26a34755c7ac3f07e5dec52bf6e67e98f066bfdae") -- Cities Skylines - K-pop Station - Depot 2148909
addappid(2202577, 1, "4421aa852b26f07c6a854a3383c2269f1bba7bbfee7be4246b50bd7488671d72") -- Cities Skylines - African Vibes - Depot 2202577
addappid(2202578, 1, "997411b2120352e3e2d3dc98f3c33b5ba181455e55863d7d82cb12c780b9d48e") -- Cities Skylines - African Vibes - Depot 2202578
addappid(2202579, 1, "a5f78347180321e5a187086ae040fe4825752d6c28a07f8bfa64c53c5320766f") -- Cities Skylines - African Vibes - Depot 2202579
addappid(2225947, 1, "5eabd2d610d49b2c0c719b1f2867691face1d4bceaba1ddb7b8d1bc06546048f") -- Cities Skylines - Pop-Punk Radio - Depot 2225947
addappid(2225948, 1, "fd6dc7ff944c062ec2f4d63523623e506bcfdfeff14a666537dc27b5634140de") -- Cities Skylines - Pop-Punk Radio - Depot 2225948
addappid(2225949, 1, "372fa05f8e057205822d14f6cb42668c4af1e6ad2a7554b9b1c40bea9a435820") -- Cities Skylines - Pop-Punk Radio - Depot 2225949
addappid(2246684, 1, "a918a0c5896046bc645c0b6f36026ed95e6a750f44400faa059e026f92db7e73") -- Cities Skylines - 80s Movies Tunes - Depot 2246684
addappid(2246685, 1, "cdd4b493ff540d37c1ebd05643690b3cfff66a23418a8dc9cdf14633a0fcd7a9") -- Cities Skylines - 80s Movies Tunes - Depot 2246685
addappid(2246686, 1, "88c65a20301ce5a07ff63e0bea24342a4b830742ba413f931fbea6f7cefceb8f") -- Cities Skylines - 80s Movies Tunes - Depot 2246686
addappid(2246687, 1, "2160b000d84a89444a9c5bab7f0fb473efe4b1878dd359ce03dbcf25b4309c59") -- Cities Skylines - JADIA Radio - Depot 2246687
addappid(2246688, 1, "9e41f603e07f3a0e86295d0b167f6db69d6c1173519ea69f62571458670d7df3") -- Cities Skylines - JADIA Radio - Depot 2246688
addappid(2246689, 1, "066889f4238f45a4caeafacdbeb2d9be06bbfa130377f38ed0f8eb60dc1c62fb") -- Cities Skylines - JADIA Radio - Depot 2246689
addappid(3843397, 1, "950239ba804650646547d0cf4e324e2110e870b4e3fb81f17bc327b297da9413") -- Cities Skylines - Harumi Nights FM - Depot 3843397
addappid(3843398, 1, "6e29b97dc9de4120b4956fc57cafa2d2aef3664bc7cbf901672372465803e5d3") -- Cities Skylines - Harumi Nights FM - Depot 3843398
addappid(3843399, 1, "71e34a128f6048fa14daf4e551573d8f222529f3716b7c605a0e1b53c5e83511") -- Cities Skylines - Harumi Nights FM - Depot 3843399
addtoken(346791, "2840039886544960915")

