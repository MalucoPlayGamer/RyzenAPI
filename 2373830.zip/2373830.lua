-- Lua provided by RyzenAPI
-- Game: Hyper Hentai Sister Nun

-- MAIN APPLICATION
addappid(2373830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373831, 1, "b4299c05dad3377ae0b03edefcc543fdf68c6f3f9c8e7b9ed0c18b4ae728bd11")
