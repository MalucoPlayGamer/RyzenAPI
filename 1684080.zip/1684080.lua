-- Lua provided by RyzenAPI 
-- Game: Toroom
addappid(1684080)
addappid(1684081, 1, "aacc1600d875d9833c24b2d972ab55ad3a9dc5c1daa06335782bcf4addce6066")
