-- Lua provided by RyzenAPI
-- Game: Toroom

-- MAIN APPLICATION
addappid(1684080)
-- Game: addappid(1684080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684081, 1, "aacc1600d875d9833c24b2d972ab55ad3a9dc5c1daa06335782bcf4addce6066")
