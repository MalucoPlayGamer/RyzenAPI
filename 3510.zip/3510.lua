-- Lua provided by RyzenAPI
-- Game: Amazing Adventures The Lost Tomb™

-- MAIN APPLICATION
addappid(3510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3511, 1, "a632da082174c092c5aed6f37f49d75a47fb89483aa0941aa22c566ae899abb0")

