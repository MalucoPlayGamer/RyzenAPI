-- Lua provided by RyzenAPI
-- Game: Horny Warp: Hentai Fantasy

-- MAIN APPLICATION
addappid(1539160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539162,0,"8f2501881aa515abd7108735b39e6a1d3e0b23fa13f0d5363fea77633897b2fb")

