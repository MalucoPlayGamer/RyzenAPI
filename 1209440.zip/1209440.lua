-- Lua provided by RyzenAPI
-- Game: capy hoky

-- MAIN APPLICATION
addappid(1209440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209441, 1, "538bedc5878a989b881e538be0c827b3debeab18273c7ce1ebd4aea9b1dfb524")
addappid(1209442, 1, "a75f13e8a8eb784629edd1764ae33cbf233337f11f74a05666ea10c970c66141")
