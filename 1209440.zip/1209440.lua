-- Lua provided by RyzenAPI
-- Game: capy hoky

-- MAIN APPLICATION
addappid(1209440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1209441, 1, "538bedc5878a989b881e538be0c827b3debeab18273c7ce1ebd4aea9b1dfb524")
addappid(1209442, 1, "a75f13e8a8eb784629edd1764ae33cbf233337f11f74a05666ea10c970c66141")

