-- Lua provided by RyzenAPI
-- Game: Cold War

-- MAIN APPLICATION
addappid(260650)

-- MAIN APP DEPOTS / PACKAGES
addappid(260651, 1, "e1c79601824053988322e346ab67d278dff3d985c4b5eed82d1bbf3dfba81c17")
addappid(260653, 1, "e79683c791f8200c6d2560a61c12d64197fa5b2aafcb98d37bab4551cfce0fd8")
addappid(260655, 1, "340959d72440aa4b19bf19da3b27e1de981b97c42b2913ff21fb51abdec1bf4d")
