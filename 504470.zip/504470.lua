-- Lua provided by RyzenAPI 
-- Game: AppID 504470
addappid(504470)
addappid(504471, 1, "be21b74ccefe63cf5c72f8715d52199dbc7820f7a57acba8a9c172132dfb97a1")
