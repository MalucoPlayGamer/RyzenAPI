-- Lua provided by RyzenAPI
-- Game: On Air Island : Survival Chat

-- MAIN APPLICATION
addappid(2562510)
-- Game: addappid(2562510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562511, 1, "8d71f3e13e1d65027248f6b29cba7ef46eb550aeea85ffe2ec31620f53b8d98b")
