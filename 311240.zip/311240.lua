-- Lua provided by RyzenAPI
-- Game: Zero Escape: Zero Time Dilemma

-- MAIN APPLICATION
addappid(311240)

-- MAIN APP DEPOTS / PACKAGES
addappid(311241, 1, "62f0bdac69ca5a4c6feec80a23a532dd08a4f7aa3a00da341e14101258bc79d5")
addappid(311242, 1, "409de951cc6cdebaac59c02c1d5a376fb808b808ba8a4d2d6f482ae5bfec31cc")
addappid(471420, 0, "b1ae990c05990df0a8041400d07eed4dceda0c609398c031e9be94da527014c2")
addappid(471520, 0, "0f4f1424cb18065cb652f040258d347308229ef1bbc601e0aabc41a626ac8f1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
