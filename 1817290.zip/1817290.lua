-- Lua provided by RyzenAPI
-- Game: 1817290

-- MAIN APPLICATION
addappid(1817290)
-- Game: addappid(1817290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817291, 1, "3286dc44755b592443a91777e8bbae3bef19279aeff5650a2f6e38b2ce01debb")
