-- Lua provided by RyzenAPI
-- Game: A-GIRL

-- MAIN APPLICATION
addappid(2651230)
addappid(2686800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651231, 1, "7da7d40dffa05224d18043360dd1c6fc6be5f0516bc8a48a1b6f7d3ca51a3474")

