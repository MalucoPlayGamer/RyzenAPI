-- Lua provided by RyzenAPI
-- Game: 436090

-- MAIN APPLICATION
addappid(436090)
-- Game: addappid(436090)

-- MAIN APP DEPOTS / PACKAGES
addappid(436091, 1, "72edbb2c0d316fd9b5f39aa3d480ecf62bddadd611a728a5ccd95b66a5200ba5")
