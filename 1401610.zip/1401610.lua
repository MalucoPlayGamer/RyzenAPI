-- Lua provided by RyzenAPI
-- Game: Leons Identität

-- MAIN APPLICATION
addappid(1401610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401611, 1, "1fe6112062f2567119c40f268816048567e08d8bf7bb8ef08676848adca3ad7f")
addappid(1401612, 1, "c07953cd1dd9a891c72f9adb73962bda5dd9e0b4e679518d18c30483ef900081")
addappid(1401613, 1, "5e7bd669d48bc0c6c3ed9326586092359c40582c9c971f897323d0bb0d7567c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
