-- Lua provided by RyzenAPI
-- Game: Game: The Creature Zone VR: Nightfall

-- MAIN APPLICATION
addappid(2530030)
-- Game: addappid(2530030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530031, 1, "805df6fd004d6e28d768d221c01e7e3fda09741b2c32a5e6ff57fa47770744ed")
