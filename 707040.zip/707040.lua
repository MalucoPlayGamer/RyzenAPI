-- Lua provided by RyzenAPI
-- Game: addappid(707040)

-- MAIN APPLICATION
addappid(707040)

-- MAIN APP DEPOTS / PACKAGES
addappid(707041, 1, "ada0cf4b41204a1f711bf6710c9c07e59825a8cd50de33553d2cc827ac83e921")
