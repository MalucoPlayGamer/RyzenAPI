-- Lua provided by RyzenAPI
-- Game: Aground Zero Demo

-- MAIN APPLICATION
addappid(1795573)
addappid(2255750)
-- Game: addappid(2255750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795571,0,"b55d329d52e6d553098a0ef98629e71da01a814186f3dcb22057fa3959f78ec3")
addappid(1795572,0,"24489338c26fa7480bd044fae3a1be2728d41939cbdcbaa907fd2f92fb1de963")
