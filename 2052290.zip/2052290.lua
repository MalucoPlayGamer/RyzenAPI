-- Lua provided by RyzenAPI
-- Game: 曦Lost girl

-- MAIN APPLICATION
addappid(2052290)
addappid(2234040)
-- Game: addappid(2052290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052291, 1, "d2ae5347303deb072ddb9b9a04e79b01eddac7736a4a1fba0b292d786878d034")
addappid(2052292, 1, "04b1a2434508845bc7389ce016c1489d3ed77cb7eb85a4fb16376fcd5d9950d3")
addappid(2052293, 1, "a0431aa2951cbd9d55bf6e5a3e635eef01e857b0ea058880eb7ca39b2106d254")
