-- Lua provided by RyzenAPI
-- Game: Game: AppID 503750

-- MAIN APPLICATION
addappid(503750)
-- Game: addappid(503750)

-- MAIN APP DEPOTS / PACKAGES
addappid(503751, 1, "a27ef10ccaf9479e00fc1fb7111a21b5738f1c76f5929535d080e7b1869877bd")
