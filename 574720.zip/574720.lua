-- Lua provided by RyzenAPI
-- Game: Little Big Workshop

-- MAIN APPLICATION
addappid(574720)
addappid(1426880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(574721, 1, "3639fec2e6886f768df5a18f61f57086cb4ac9eb28f086648d0db45ef6c81d56")
addappid(574722, 1, "7b383b5204c7a2aaaaf20f553b86a2b63981886349b250a12774f50d8c7579f3")

