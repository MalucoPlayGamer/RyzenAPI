-- Lua provided by RyzenAPI 
-- Game: Colors! Maze
addappid(1740420)
addappid(1740421, 1, "6be9393eada57bbe2247061142f5c0864363416f8d28c38980b449fb768da85b")
