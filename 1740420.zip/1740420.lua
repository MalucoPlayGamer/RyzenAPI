-- Lua provided by RyzenAPI
-- Game: Game: Colors! Maze

-- MAIN APPLICATION
addappid(1740420)
-- Game: addappid(1740420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740421, 1, "6be9393eada57bbe2247061142f5c0864363416f8d28c38980b449fb768da85b")
