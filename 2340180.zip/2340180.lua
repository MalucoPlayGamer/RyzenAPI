-- Lua provided by RyzenAPI
-- Game: Angels of Darkness Angels of Light

-- MAIN APPLICATION
addappid(2340180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340181, 1, "3b7dd9b9628fac27bcca10489595c05fea991e5b10f14ae6a4455c5fff4c7026")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
