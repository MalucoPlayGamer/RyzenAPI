-- Lua provided by RyzenAPI
-- Game: Angels of Darkness Angels of Light

-- MAIN APPLICATION
addappid(2340180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340181, 1, "3b7dd9b9628fac27bcca10489595c05fea991e5b10f14ae6a4455c5fff4c7026")
