-- Lua provided by RyzenAPI
-- Game: Game: AppID 1072170

-- MAIN APPLICATION
addappid(1072170)
-- Game: addappid(1072170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072171, 1, "276819de380c8acf3f4d505fdf112dd17a06fbc2448a26c81615cbb27f0f242b")
