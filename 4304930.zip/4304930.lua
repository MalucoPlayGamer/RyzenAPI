-- 4304930's Lua and Manifest Created by Hubcap Manifest
-- Chef Knight
-- Created: June 04, 2026 at 13:38:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4304930) -- Chef Knight
-- MAIN APP DEPOTS
addappid(4304931, 1, "a4a17a17eaec59396387e89f1a1dcf8852d3ad8ea046988b327fa0462292b715") -- Depot 4304931
-- setManifestid(4304931, "2068012407921332999", 339393131)