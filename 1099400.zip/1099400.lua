-- Lua provided by RyzenAPI
-- Game: AppID 1099400

-- MAIN APPLICATION
addappid(1099400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1099401, 1, "19facd55ad186b608ff222d61c9e0d051504dc17a085f49baa2cfdfeea52a838")

