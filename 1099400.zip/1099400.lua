-- Lua provided by SkyAPI 
-- Game: AppID 1099400
addappid(1099400)
addappid(1099401, 1, "19facd55ad186b608ff222d61c9e0d051504dc17a085f49baa2cfdfeea52a838")
