-- Lua provided by RyzenAPI
-- Game: Marauders

-- MAIN APPLICATION
addappid(1789480)
addappid(2140130)
addappid(2475000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1789481, 1, "7ad240d388bfc7d00551db80ea1d7a33e2a9e6b2db81ff01c7e0e8b802adece5")

