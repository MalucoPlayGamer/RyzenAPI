-- Lua provided by RyzenAPI
-- Game: addappid(1636344)

-- MAIN APPLICATION
addappid(1636344)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636344,0,"d123e67f72b93df983ec3cfc34d112c53b4ebf798504ce04cd49015579db621e")
