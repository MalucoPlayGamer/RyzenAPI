-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1636344)
-- Game: addappid(1636344)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636344,0,"d123e67f72b93df983ec3cfc34d112c53b4ebf798504ce04cd49015579db621e")
