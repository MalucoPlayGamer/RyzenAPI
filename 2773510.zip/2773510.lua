-- Lua provided by RyzenAPI
-- Game: FOR THE QUEEN : Adventures of a Village Girl

-- MAIN APPLICATION
addappid(2773510)
-- Game: addappid(2773510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773510,0,"af6408222e6c7c395483edd77597824742988daf98e1be178824514f9fcb5366")
