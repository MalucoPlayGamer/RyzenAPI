-- Lua provided by RyzenAPI
-- Game: Tales Beyond The Tomb - The Last Vigil

-- MAIN APPLICATION
addappid(3416690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416691, 1, "4d5f84f37528b842cfad7fd2888bd1f4c1a7082ad2ba9f2dfc1f5d5f971b9cfb")
