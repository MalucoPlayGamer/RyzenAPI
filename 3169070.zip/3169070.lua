-- Lua provided by RyzenAPI
-- Game: Laundromat Simulator

-- MAIN APPLICATION
addappid(3169070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169071, 1, "a477f05235d870350b5a6d027128e17ab9ef4ae18cb6dbcfa7b7685297d38d92")
