-- Lua provided by RyzenAPI
-- Game: AppID 1868070

-- MAIN APPLICATION
addappid(1868070)
-- Game: addappid(1868070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868071, 1, "9054eb348da6b1ea2e8eeaa4572f7e7b04f1aaa1411084f02aeae9c9328fe9c7")
addappid(1868072, 1, "604c894980015b5bbf2f6069b126e3de54f10df3048a10bee2043d403006ecc0")
