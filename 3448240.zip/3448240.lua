-- Lua provided by RyzenAPI
-- Game: addappid(3448240)

-- MAIN APPLICATION
addappid(3448240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3448241, 1, "5754dfae59212d0f5794db2cffe2b34bf9545bee9e5adc7731c16ff9eb4b6ff9")
