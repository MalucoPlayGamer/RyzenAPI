-- Lua provided by RyzenAPI
-- Game: Analogue: A Hate Story Soundtrack

-- MAIN APPLICATION
addappid(209373)
-- Game: addappid(209373)

-- MAIN APP DEPOTS / PACKAGES
addappid(209373,0,"be4d7ad531533f952d2b9e6f1f6bfdfa85c15361f9256660a8be8a64eccef010")
