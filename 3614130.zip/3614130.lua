-- 3614130's Lua and Manifest Created by Hubcap Manifest
-- Shelves and Sorcery: Tidy Up the Enchanted Shop
-- Created: August 12, 2026 at 09:12:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3614130) -- Shelves and Sorcery: Tidy Up the Enchanted Shop
-- MAIN APP DEPOTS
addappid(3614131, 1, "3288ddfa61bc73b5e1820f6819ef628548db8a8d9b27c5d7f330ddd7f33ed0df") -- Depot 3614131
setManifestid(3614131, "8577051120799684436", 1705739807)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)