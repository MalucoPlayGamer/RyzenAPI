-- Lua provided by RyzenAPI
-- Game: Game: Castle of Vania

-- MAIN APPLICATION
addappid(3064230)
-- Game: addappid(3064230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064231, 1, "b399bf0273bbc62a3a3505045e5d4a7e692e2c3382022da7a7cf89af29b63ca1")
