-- Lua provided by RyzenAPI
-- Game: Braveland

-- MAIN APPLICATION
addappid(285800)

-- MAIN APP DEPOTS / PACKAGES
addappid(285801, 1, "4c64b70ff66172ec34d6f515640d08593527d319108851503acbaa5f43c2ba06")
addappid(285802, 1, "5ed519979b6b745243d94abf93fccadb4d1266db8befa4db998e0a8f08984308")
addappid(285803, 1, "da00b89a55d50c8af7952a94507f0bd79aaa371d95a2c13390f93cd1f422d529")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
