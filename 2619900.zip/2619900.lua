-- Lua provided by RyzenAPI
-- Game: Tiny Breakers Camp

-- MAIN APPLICATION
addappid(2619900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619901, 1, "b5b2bd624da6b5a2bb7f28b3ac622c6be48b1b32ae408966009a0a3e487718b3")

