-- Lua provided by RyzenAPI
-- Game: Desert Skies

-- MAIN APPLICATION
addappid(1048950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048951, 1, "16ee388ac76810ffaab3460faf36efd886c7fea8893d35d0f69630f6831147b8")

