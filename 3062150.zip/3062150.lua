-- Lua provided by RyzenAPI
-- Game: Game: Car Service Simulator

-- MAIN APPLICATION
addappid(3062150)
-- Game: addappid(3062150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062151, 1, "91df684558cad450928541d0b0d91e0d07433a4f76f8cc2da1f5421e08c4013d")
