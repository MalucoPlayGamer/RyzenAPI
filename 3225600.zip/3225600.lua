-- Lua provided by RyzenAPI
-- Game: Tech Market Simulator

-- MAIN APPLICATION
addappid(3225600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3225601, 1, "2330917646878535818131204d5aa326d0f540723419b8a35dee822c2efd90d8")

