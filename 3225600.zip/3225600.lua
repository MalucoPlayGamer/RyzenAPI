-- Lua provided by RyzenAPI
-- Game: Tech Market Simulator

-- MAIN APPLICATION
addappid(3225600)
-- Game: addappid(3225600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3225601, 1, "2330917646878535818131204d5aa326d0f540723419b8a35dee822c2efd90d8")
