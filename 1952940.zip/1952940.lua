-- Lua provided by RyzenAPI
-- Game: Soul Wargame Demo

-- MAIN APPLICATION
addappid(1952940)
-- Game: addappid(1952940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952941, 1, "13c566e24c2e8f9206bbf4c765aad03dfc09739a5ffb79a31848993cdd961056")
