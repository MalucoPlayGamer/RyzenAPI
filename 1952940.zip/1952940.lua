-- Lua provided by SkyAPI 
-- Game: Soul Wargame Demo
addappid(1952940)
addappid(1952941, 1, "13c566e24c2e8f9206bbf4c765aad03dfc09739a5ffb79a31848993cdd961056")
