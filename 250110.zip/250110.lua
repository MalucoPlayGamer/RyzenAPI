-- Lua provided by RyzenAPI
-- Game: Assault Android Cactus+

-- MAIN APPLICATION
addappid(250110)
addappid(403990)

-- MAIN APP DEPOTS / PACKAGES
addappid(250111, 1, "9ba96c53cbc37b53927a49bf459e952fe343df3ee9e78cc0e022f0834bb82af8")
addappid(250112, 1, "9b581e062d08c1dbd08f0a55fac1820689958aac9492615944215387c3808a1b")
addappid(250113, 1, "54b63fff63332402f9381a76121e7ac5cedc228f9148c0ce9a58d6ad1eab7836")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
