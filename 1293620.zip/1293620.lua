-- Lua provided by RyzenAPI
-- Game: Assemble with Care Soundtrack

-- MAIN APPLICATION
addappid(1293620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293621, 1, "9700b00d4c521670cfbf4f2339549187b9f13c18c2f8a337eb99b843a2eef886")
addappid(1293622, 1, "1795bae938af94e5ec880cdfca23335850a0232e0bcb9f98750b1d3ebb07277c")
