-- Lua provided by RyzenAPI
-- Game: addappid(1087020)

-- MAIN APPLICATION
addappid(1087020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087021, 1, "c4d97f09261bf81ef5dcd3b69a11606945afae8510ce872b660d6ff41162ad11")
