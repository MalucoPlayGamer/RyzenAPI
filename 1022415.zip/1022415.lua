-- Lua provided by RyzenAPI
-- Game: DFF NT: Obsidian Scales, Golbez's 4th Weapon

-- MAIN APPLICATION
addappid(1022415)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022415,0,"50d4394512a920ac970e41632b79d53b95359449021caf92bbb9b69e86a8c0cf")

