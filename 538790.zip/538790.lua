-- Lua provided by RyzenAPI
-- Game: Primal Carnage: Onslaught

-- MAIN APPLICATION
addappid(538790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(538791, 1, "1be3eee67da74f383748c9bf263b1cdc1ec6b1c1b3dcbfbab78b38818c7dab12")

