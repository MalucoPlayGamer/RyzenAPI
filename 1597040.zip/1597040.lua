-- Lua provided by RyzenAPI
-- Game: 1597040

-- MAIN APPLICATION
addappid(1597040)
addappid(1752320)
-- Game: addappid(1597040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597041, 1, "136e900c71a8a36f65935ef05ac9b8ca149a298ee7634a38405ee72454c6498b")
