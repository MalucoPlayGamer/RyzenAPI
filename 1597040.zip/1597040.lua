-- Lua provided by RyzenAPI
-- Game: Fossilfuel

-- MAIN APPLICATION
addappid(1597040)
addappid(1752320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597041, 1, "136e900c71a8a36f65935ef05ac9b8ca149a298ee7634a38405ee72454c6498b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
