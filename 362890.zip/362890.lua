-- Lua provided by RyzenAPI
-- Game: AppID 362890

-- MAIN APPLICATION
addappid(362890)

-- MAIN APP DEPOTS / PACKAGES
addappid(362891, 1, "46ba8e1d09bb724bb5274d7fa497e4acd1186881d41a91857922c979d4f37344")
addappid(362892, 1, "1141f7df13dcc852bac94bbe7a7d684903dbb97ef068228782c62ac4f8adae23")
addappid(362894, 1, "d7ead84613b380590a839d924354b02e5943f64d6d291045d209b2ba4f72f1c4")
addappid(362895, 1, "89498042a0fa6ab71fe0ed1cb35240a02daffe7e8f622856eefa3e46dd87e68d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
