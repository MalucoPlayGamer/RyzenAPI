-- Lua provided by RyzenAPI
-- Game: 1206000

-- MAIN APPLICATION
addappid(1206000)
-- Game: addappid(1206000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206001, 1, "202e68acc10c16430cd909457a4ab8d9c412d851e426af5225b9d9767b15f69e")
