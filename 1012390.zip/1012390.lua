-- Lua provided by RyzenAPI
-- Game: addappid(1012390)

-- MAIN APPLICATION
addappid(1012390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012391, 1, "8db582b712eee67c9dbdd9f7be0887e6e21e55353af1d99d5d69a039eb93f09c")
