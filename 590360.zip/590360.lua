-- Lua provided by RyzenAPI
-- Game: The Wild Eight – Soundtrack

-- MAIN APPLICATION
addappid(590360)

-- MAIN APP DEPOTS / PACKAGES
addappid(590360,0,"d3bcb62bfc06d150709fa1a70bb4ca96a9bd4355a27e6506473af0ee37515c70")
