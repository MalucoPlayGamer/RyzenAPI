-- Lua provided by RyzenAPI
-- Game: addappid(1774130)

-- MAIN APPLICATION
addappid(1774130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774131, 1, "a7ca78901858c9cd3f811b07b1f17af63afa795c8ab80ef9713dc240ab3325bc")
