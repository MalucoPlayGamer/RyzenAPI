-- Lua provided by RyzenAPI
-- Game: addappid(1601950)

-- MAIN APPLICATION
addappid(1601950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601951, 1, "ff98afd27ac8e71f142481724c6c40622b294944b734aa3c941376ac72ac79a9")
