-- Lua provided by RyzenAPI
-- Game: Anno 1800

-- MAIN APPLICATION
addappid(916451) -- Anno 1800 - Uplay Activation Standard Preorder
addappid(916452) -- Anno 1800 - Uplay Activation Deluxe Preorder
addappid(1066850) -- Anno 1800 - Season Pass
addappid(1066851) -- Anno 1800 - Season Pass Uplay Activation
addappid(1066852)
addappid(1066853) -- Anno 1800 - Deluxe Pack Uplay Activation
addappid(1125790) -- Anno 1800 - Sunken Treasure
addappid(1125791) -- Anno 1800 - Sunken Treasure Uplay Activation
addappid(1125792) -- DLC 1125792
addappid(1125793) -- DLC 1125793
addappid(1125794) -- Anno 1800 - The Passage
addappid(1125795) -- DLC 1125795
addappid(1210040) -- DLC 1210040
addappid(1210041) -- Anno 1800 – Holyday pack Uplay activation
addappid(1247680) -- Anno 1800 - Seat of Power
addappid(1247681) -- DLC 1247681
addappid(1247710) -- Anno 1800 - Year 2 Pass
addappid(1247711) -- Anno 1800 - Year 2 Pass Uplay Activation
addappid(1314950) -- Anno 1800 - Bright Harvest
addappid(1314951) -- DLC 1314951
addappid(1383240) -- DLC 1383240
addappid(1383241) -- DLC 1383241
addappid(1442810) -- Anno 1800 - Land of Lions
addappid(1442811) -- Anno 1800 - Land of Lions Uplay Activation
addappid(1465650) -- Anno 1800 - City Lights Pack
addappid(1465651) -- DLC 1465651
addappid(1530880) -- Anno 1800 - Year 3 Pass
addappid(1530881) -- DLC 1530881
addappid(1530882) -- Anno 1800 - Docklands
addappid(1530883) -- DLC 1530883
addappid(1626970) -- Anno 1800 - Tourist Season
addappid(1626971) -- DLC 1626971
addappid(1626972) -- DLC 1626972
addappid(1626973) -- DLC 1626973
addappid(1704680) -- Anno 1800 - The High Life
addappid(1704681) -- DLC 1704681
addappid(1704690) -- DLC 1704690
addappid(1704691) -- DLC 1704691
addappid(1803740) -- DLC 1803740
addappid(1803741) -- DLC 1803741
addappid(1803742) -- Anno 1800 - Vibrant Cities Pack
addappid(1803743) -- DLC 1803743
addappid(1881100) -- Anno 1800 - Seasonal Decorations Pack
addappid(1881101) -- DLC 1881101
addappid(1933240) -- Anno 1800 - Year 4 Season Pass
addappid(1933241) -- Anno 1800 - Year 4 Season Pass Ubisoft Activation
addappid(1933242) -- Anno 1800 - Cosmetic Pack Bundle
addappid(1933243) -- Anno 1800 - Cosmetic Pack Bundle Ubisoft Activation
addappid(1933244) -- Anno 1800 - Seeds of Change
addappid(1933245) -- Anno 1800 - Seeds of Change Ubisoft Activation
addappid(2055760) -- Anno 1800 - Industrial Zone Pack
addappid(2055761) -- Anno 1800 - Industrial Zone Pack Ubisoft Activation
addappid(2074410) -- Anno 1800 - Empire of the Skies Pack
addappid(2074411) -- Anno 1800 - Empire of the Skies Pack Ubisoft Connect Activation
addappid(2222640) -- Anno 1800 – New World Rising Pack
addappid(2222641) -- Anno 1800 – New World Rising Ubisoft Activation
addappid(2222650) -- Anno 1800 - Old Town Pack
addappid(2222651) -- Anno 1800 - Old Town Pack Ubisoft Activation
addappid(2231361) -- Anno 1800 Ubisoft Activation
addappid(2235740) -- Anno 1800 - Year 4 Complete Edition Ubisoft Activation
addappid(2235741) -- Anno 1800 - Year 4 Gold Edition Ubisoft Activation
addappid(2277980) -- Anno 1800 – Dragon Garden Pack
addappid(2277981) -- Anno 1800 – Dragon Garden Pack Ubisoft Activation
addappid(2400950) -- Anno 1800 - Fiesta Pack
addappid(2504950) -- Anno 1800 - National Park Pack
addappid(2622020) -- Anno 1800 - Cosmetic Bundle #2
addappid(2622040) -- Anno 1800 - Eldritch Pack
addappid(2830580) -- Anno 1800 - Steampunk Pack
addappid(3113620) -- Anno 1800 - Pirate Cove Pack
addappid(3256930) -- Anno 1800 - End of an Era Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(916440, 1, "889f4cfd8180a1fdc3df4831d25fdf6cdef9ce57dfe9c60ed6fc145ab532c383")
addappid(916441, 1, "fdf2da2bad8516bd58704e87cdd2101173aa1330d9328186184ff6445a945e19")
addappid(916442, 1, "eb8f0f30eafebbbaf8c5870c365708e8a973fd5d817e79d08db91170da90284b")
addappid(916443, 1, "070c294380877e9c7d8f2daab4a07fe0b2194473c79502b71e66b11d5ec4bbf0")
addappid(916444, 1, "5f6372b7a1ed235b555d05aa54ec7bea9f3d4b08906633514b058b5bd14f4e6c")
addappid(916445, 1, "2bb378d0ec6043f34d63cbf2c37a06e9d61c9c197188638cdd24b6fccc0ccbbf")
addappid(916446, 1, "96ca058661170b58b95d8745bf9a352795ee003dfbf96c622825b88063eada12")
addtoken(1066850, "12111271149057402995")
addtoken(1066852, "13854832133522835162")
addtoken(1125792, "15363863492004126802")
addtoken(1125793, "15696604020445804298")
addtoken(1125794, "10348292758142420166")
addtoken(1125795, "285244861000477955")
addtoken(1210040, "16759723954527412761")
addtoken(1247680, "3197839846494379136")
addtoken(1247681, "10907565467632324824")
addtoken(1247710, "8973042785894684627")
addtoken(1314950, "14151021687858726039")
addtoken(1314951, "9050655666304366063")
addtoken(1383240, "6035183030212088646")
addtoken(1383241, "3247136012154016126")
addtoken(1465651, "8510601613906666037")
addtoken(1530880, "10032381193074420280")
addtoken(1530881, "10333676926568764571")
addtoken(1530883, "14469224751097083876")
addtoken(1626970, "14431331289985871920")
addtoken(1626971, "15660085937845016189")
addtoken(1626972, "7686359769432141679")
addtoken(1626973, "1001413596776433140")
addtoken(1704681, "8134497571007803230")
addtoken(1704690, "4766422470377779440")
addtoken(1704691, "4237534615968270310")
addtoken(1803741, "13092192723117200999")
addtoken(1803743, "10834241906534394363")
addtoken(1881101, "7186953762791114175")

