-- Lua provided by RyzenAPI
-- Game: Security Guy vs AI: The Dawn of AI

-- MAIN APPLICATION
addappid(1502620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502621, 1, "2b5f4081a6f5dc8c0da2022ccbfde7ed066c4cbaba8016ddfc00f4b63719039d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
