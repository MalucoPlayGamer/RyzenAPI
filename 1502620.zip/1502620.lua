-- Lua provided by RyzenAPI
-- Game: 1502620

-- MAIN APPLICATION
addappid(1502620)
-- Game: addappid(1502620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502621, 1, "2b5f4081a6f5dc8c0da2022ccbfde7ed066c4cbaba8016ddfc00f4b63719039d")
