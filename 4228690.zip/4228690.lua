-- 4228690's Lua and Manifest Created by Hubcap Manifest
-- Black Gold - Shining Town
-- Created: August 14, 2026 at 11:07:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(4228690, 1, "e2869a3be9814254c88a8d36e8068def7789c0b29050ccd12f0686eb451bf068") -- Black Gold - Shining Town
-- MAIN APP DEPOTS
addappid(4228691, 1, "7cd87fd9c8a5ef1a15f81f75bf5e8cc7c914b7a767d5da0d86d1706bf12eeb15") -- Depot 4228691
setManifestid(4228691, "466554627787853633", 1594903903)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)