-- Lua provided by RyzenAPI
-- Game: Game: Ghost Girl Lasling DLC - R18 ASMR

-- MAIN APPLICATION
addappid(2127420)
-- Game: addappid(2127420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2127421, 1, "52994f8faf7395fdb46cf6fd29593ad6bacd3853abdfe2ac1322440c2902aa8d")
addappid(2127422, 1, "dde0f4e58aa59a3a450c276e1ff12f3ed25f25e019907a3b8fc34e75dd3b49b2")
addappid(2127423, 1, "0796b35005529981fb44e8486ab37a13a30ad0730d2b1326428d55223f1be182")
