-- Lua provided by RyzenAPI
-- Game: Just Ignore Them: Brea's Story Tape 1

-- MAIN APPLICATION
addappid(1900280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900281, 1, "2fb70cb7332dae5bf78b562d6956138843b8fdc43f477474c2dd80a56b4a3c54")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
