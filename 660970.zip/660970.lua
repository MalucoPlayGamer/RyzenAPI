-- Lua provided by RyzenAPI
-- Game: addappid(660970)

-- MAIN APPLICATION
addappid(660970)

-- MAIN APP DEPOTS / PACKAGES
addappid(660971, 1, "c3862e136d7fef6c73025936761e4b00dfc2aef19b50eff4d5f2c6bb977d2385")
