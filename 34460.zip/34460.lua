-- Lua provided by RyzenAPI
-- Game: 34460

-- MAIN APPLICATION
addappid(34460)

-- MAIN APP DEPOTS / PACKAGES
addappid(8804,0,"e071eefdf549dfb671a80e6ec69e090b8e994b31e03aeb46e84c2ee378358858")
