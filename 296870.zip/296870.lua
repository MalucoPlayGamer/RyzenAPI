-- Lua provided by RyzenAPI
-- Game: AppID 296870

-- MAIN APPLICATION
addappid(296870)

-- MAIN APP DEPOTS / PACKAGES
addappid(296871, 1, "9f7f461458c11c8159a4a25fd7866e13aec6b5cc7299db60260796703a60557b")
addappid(296872, 1, "5f34dcd678c52afa39153961da1d6322938d71483d0dd9320f53dc7b3101ef5b")
addappid(296873, 1, "5f6e9ecdb9bcb511607f59b339f47918da10cd6d4c04073a1747b2b08e64b076")
addappid(296874, 1, "423e3fdbb523e21b5247c232cf03bd3916e183f47105e3563e20bcb4a50beaa2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1169600)
