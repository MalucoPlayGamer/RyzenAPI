-- Lua provided by RyzenAPI
-- Game: Deep Cuts OST - Forsaken Festival

-- MAIN APPLICATION
addappid(3602140)
-- Game: addappid(3602140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602141, 1, "2a421e6de87d55a2b17836075e1fd5e088ca38c25df5934e75f6c4da54c455dc")
addappid(3602142, 1, "dadcb84664a740ba0fc3503d617cf92b97f8b36a87880b0094a77586feb0f886")
