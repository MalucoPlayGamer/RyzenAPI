-- Lua provided by RyzenAPI 
-- Game: 三國立志傳3
addappid(2467190)
addappid(2467191, 1, "5e8d3bc7394e531aeb2c231aaf081322ddbd6590ea0dbcd316dbe7e4644c3d9a")
addappid(2467192, 1, "567559decfaa48fed030313ce6d80c8b95e3624e38ad505c52efa231348298e4")
addappid(2467193, 1, "00949ec9b67b5369925e4b80c0485dee373da404c74659f17c1f09d736f82a93")
addappid(2477880)
