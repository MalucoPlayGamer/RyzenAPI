-- Lua provided by RyzenAPI
-- Game: Crowd Simulator - Hats DLC

-- MAIN APPLICATION
addappid(1916750)
-- Game: addappid(1916750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916750,0,"6298f97e8e0b6290acef5ddade9c6fc11decd2827b4d2eaae3502f78d2becad7")
