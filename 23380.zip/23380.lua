-- Lua provided by RyzenAPI
-- Game: AppID 23380

-- MAIN APPLICATION
addappid(23380)

-- MAIN APP DEPOTS / PACKAGES
addappid(23381, 1, "b665e02dfeaf968445215f9519c6144457077dc4f06b14b45e3dac024e9444ef")
addappid(23382, 1, "52d114fa07efbeed92677d9d9cefc82b8c255ee0a6a65cff7b3a586d0eb1d09b")
addappid(23383, 1, "099b89d55d034d2168891efa82b9f2f1b9b6232f497e7bd0a3166264daff3667")
addappid(23384, 1, "3879efe386cb0fb116702e549c36431d106c155738f95f07f2f5ed159c827f2d")
addappid(23385, 1, "d97bfafdfa24a0f892d19366815d0466a30b5f0f00202a4fd8df5d20f3254725")
addappid(23386, 1, "da2971d224bba7501c75385057028a0adef6a7b8f165c8dd9981ffb5da5ae3d0")
addappid(23387, 1, "4d19ece70776d2c050d9d774198b8b7cfc62c6bcd6113d32a816d901ea6e43e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
