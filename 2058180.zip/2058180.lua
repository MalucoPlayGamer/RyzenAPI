-- Lua provided by RyzenAPI
-- Game: Judgment

-- MAIN APPLICATION
addappid(2058180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058181, 1, "2c5b08fe950ac2f5fcfc838f3ebcf0f1863bcb65ffc05bb859d1e3f8cd20fb99")
addappid(2058182, 1, "f6aa46579ab78cdede9b725040ae992a922876dc88c3d0b4d51f1de8dca091d7")
addappid(2058183, 1, "362b005a854a2281f863b2b29a2d4cdf14c0038bd1593d80eae2845a023c748a")
addappid(2058184, 1, "8e74fca7757729e2611867385eb27efcdac8eb374d28dd0d6a783c25a852f6d4")
addappid(2058185, 1, "a26ec42bcfcd2d33dfe90f40d4354dcc0e4a5345c55ae1bea3e70d5bd19164b4")
addappid(2058186, 1, "89fd458eaee9f9f95bbd9ebd4198b2ebbdd31e4757ee89dee2de1822755476a0")
addappid(2058187, 1, "6392203a125860c340a4115737d0a6f44929bf4def0f4e18db19c1e917078387")
addappid(2058188, 1, "94548f8725ca5a1ab85f479f30ab6c987c1f92b16d3a51a1601ea4705db12ba3")
addappid(2058189, 1, "fd84527ae76dc442a8ad74d9293d136400bfe79a532dc323d21790b2b9021bed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
