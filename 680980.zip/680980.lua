-- Lua provided by RyzenAPI 
-- Game: HEADLINER
addappid(680980)
addappid(680981, 1, "9e126e6b4f50b0f2f8f636e3d9b72ddae26c079888b5fbf0c69654460b2d5e21")
