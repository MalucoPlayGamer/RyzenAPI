-- Lua provided by RyzenAPI
-- Game: HEADLINER

-- MAIN APPLICATION
addappid(680980)

-- MAIN APP DEPOTS / PACKAGES
addappid(680981, 1, "9e126e6b4f50b0f2f8f636e3d9b72ddae26c079888b5fbf0c69654460b2d5e21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
