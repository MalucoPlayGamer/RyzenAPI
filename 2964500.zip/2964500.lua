-- Lua provided by RyzenAPI
-- Game: Read Only Memories: NEURODIVER Original Game Soundtrack

-- MAIN APPLICATION
addappid(2964500)
-- Game: addappid(2964500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964501, 1, "47184b19b0404026d5b7e8a350c87d5c74509d18ee96f8e5f4f2230846b21153")
