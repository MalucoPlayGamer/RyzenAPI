-- Lua provided by RyzenAPI
-- Game: Kings and Pigs Prequel

-- MAIN APPLICATION
addappid(1787640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1787641, 1, "928934328e6a69666c4848b906d764f1e00a3fc9e3c644a882a31a79739cc348")

