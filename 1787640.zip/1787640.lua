-- Lua provided by RyzenAPI
-- Game: Kings and Pigs Prequel

-- MAIN APPLICATION
addappid(1787640)
-- Game: addappid(1787640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787641, 1, "928934328e6a69666c4848b906d764f1e00a3fc9e3c644a882a31a79739cc348")
