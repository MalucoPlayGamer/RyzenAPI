-- Lua provided by RyzenAPI
-- Game: Sanatorium - A Mental Asylum Simulator Demo

-- MAIN APPLICATION
addappid(2753150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753151, 1, "164f6dc850c3e8c16f4b520f4eadeee5102841a2fe83e29cb37363b11d1e6f8a")

