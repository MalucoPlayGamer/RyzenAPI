-- Lua provided by RyzenAPI
-- Game: The Blunderbuss

-- MAIN APPLICATION
addappid(1875160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1875161, 1, "877f2680e0e7be283fe69d832917ecfebee9b78e25d3616d32250814251bbb69")

