-- Lua provided by RyzenAPI
-- Game: Game: The Blunderbuss

-- MAIN APPLICATION
addappid(1875160)
-- Game: addappid(1875160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875161, 1, "877f2680e0e7be283fe69d832917ecfebee9b78e25d3616d32250814251bbb69")
