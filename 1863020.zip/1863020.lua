-- Lua provided by RyzenAPI 
-- Game: Hentai Dream
addappid(1863020)
addappid(1863021, 1, "df344050e78a82385e77e1c3e6996fc085d0f2c2a23ec64a734affabf6dbc8c9")
