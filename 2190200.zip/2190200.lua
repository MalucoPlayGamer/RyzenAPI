-- Lua provided by RyzenAPI
-- Game: Cockville [18+]

-- MAIN APPLICATION
addappid(2190200)
-- Game: addappid(2190200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190201, 1, "ae9237599afcbfdcd3f8e8880dae0179e48d6c0851d71c6afcbcffffa0bfbc3f")
