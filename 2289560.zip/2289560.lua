-- Lua provided by RyzenAPI
-- Game: addappid(2289560)

-- MAIN APPLICATION
addappid(2289560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289562,0,"3266ef18d62efacd2ecd9156306bd8c72c2f16a5a475af61a93e943e939c3152")
