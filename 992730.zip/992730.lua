-- Lua provided by RyzenAPI
-- Game: Neckbreak

-- MAIN APPLICATION
addappid(992730)

-- MAIN APP DEPOTS / PACKAGES
addappid(992731, 1, "cea8bd89d8e9d8d93d2a07dd0e095b5c1eb2b3db3ab8f1f99287b9778e433355")

