-- Lua provided by SkyAPI 
-- Game: Bears Can't Drift!?
addappid(338040)
addappid(338041, 1, "f9cd959ec5062eaa868f7ef10e12e0cdf1e49ca5ad5f2e1532f2c97df1a37ed1")
