-- Lua provided by RyzenAPI
-- Game: Game: Bears Can't Drift!?

-- MAIN APPLICATION
addappid(338040)
-- Game: addappid(338040)

-- MAIN APP DEPOTS / PACKAGES
addappid(338041, 1, "f9cd959ec5062eaa868f7ef10e12e0cdf1e49ca5ad5f2e1532f2c97df1a37ed1")
