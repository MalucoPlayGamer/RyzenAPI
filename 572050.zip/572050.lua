-- Lua provided by RyzenAPI
-- Game: Call to Power II

-- MAIN APPLICATION
addappid(572050)
-- Game: addappid(572050)

-- MAIN APP DEPOTS / PACKAGES
addappid(572051, 1, "a2c93bfbc209f46eea96391e8cd02862ea4634c48daceab4670545d62fd815a5")
