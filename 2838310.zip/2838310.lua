-- Lua provided by RyzenAPI
-- Game: Beat Saber - Daft Punk - "The Prime Time of Your Life/The Brainwasher/Rollin'/Alive (Live 2007)"

-- MAIN APPLICATION
addappid(2838310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838310,0,"762f7b07d743ce413b348a2697ca478b25b01b14d1347df81afaf79cb7332233")
