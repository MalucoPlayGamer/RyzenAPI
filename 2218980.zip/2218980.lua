-- Lua provided by SkyAPI 
-- Game: Sperma
addappid(2218980)
addappid(2218981, 1, "3e25253e8ddb8f25e7a07d942822f4bff9411328d397eb09e89fd4a18fabb08e")
