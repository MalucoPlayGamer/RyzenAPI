-- Lua provided by RyzenAPI
-- Game: Sperma

-- MAIN APPLICATION
addappid(2218980)
-- Game: addappid(2218980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218981, 1, "3e25253e8ddb8f25e7a07d942822f4bff9411328d397eb09e89fd4a18fabb08e")
