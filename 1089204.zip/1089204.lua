-- Lua provided by RyzenAPI
-- Game: addappid(1089204)

-- MAIN APPLICATION
addappid(1089204)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089204,0,"7c1e51670ef6b129cd3ad6d2e3cff230ce60acd13fda1895520c23d4dee8a049")
addtoken(1089204,"9060366394470842325")
