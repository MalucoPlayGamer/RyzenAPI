-- Lua provided by RyzenAPI
-- Game: Game: AppID 1295500

-- MAIN APPLICATION
addappid(1295500)
-- Game: addappid(1295500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295501, 1, "d12f0bcfa736438c73d5829cd28d41cd9bbc7be4f401af778ec81c0cf9d16ae9")
addappid(1295502, 1, "e4bca82705ce54ce78394160a3222f708214c7dbd198a07b320f63f6d9dce0aa")
