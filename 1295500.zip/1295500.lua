-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Battlesector

-- MAIN APPLICATION
addappid(1295500)
addappid(1718640)
addappid(1793050)
addappid(1793051)
addappid(2011980)
addappid(2199370)
addappid(2305830)
addappid(2583910)
addappid(3202720)
addappid(3577600)
addappid(3577620)
addappid(3577690)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1295501, 1, "d12f0bcfa736438c73d5829cd28d41cd9bbc7be4f401af778ec81c0cf9d16ae9")
addappid(1295502, 1, "e4bca82705ce54ce78394160a3222f708214c7dbd198a07b320f63f6d9dce0aa")
