-- Lua provided by RyzenAPI
-- Game: METAL DOGS

-- MAIN APPLICATION
addappid(1036740)
addappid(2903260)
addappid(2903270)
addappid(3025210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036741,0,"2c4c5d895dbeca8c799aef93013be2815c2adbbcf9d49d01987e87b37c93f2a9")

