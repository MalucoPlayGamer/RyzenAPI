-- Lua provided by RyzenAPI
-- Game: ESKO

-- MAIN APPLICATION
addappid(1045140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045141, 1, "6ae7595c5ec35886fc8a35424a7dabcc334ffbb343bb65d332a820938ddd19f8")
