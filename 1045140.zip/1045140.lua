-- Lua provided by RyzenAPI
-- Game: ESKO

-- MAIN APPLICATION
addappid(1045140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045141, 1, "6ae7595c5ec35886fc8a35424a7dabcc334ffbb343bb65d332a820938ddd19f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
