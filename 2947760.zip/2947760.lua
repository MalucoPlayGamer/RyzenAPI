-- Lua provided by RyzenAPI
-- Game: Hidden Vintage House Top-Down 3D

-- MAIN APPLICATION
addappid(2947760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947761, 1, "a7ac741d4656609c90f9cae692068c657740f0662dee0189bdc9d5950731870f")
