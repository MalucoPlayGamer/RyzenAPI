-- Lua provided by RyzenAPI
-- Game: AppID 355350

-- MAIN APPLICATION
addappid(355350)

-- MAIN APP DEPOTS / PACKAGES
addappid(355351, 1, "3543cfd7b323da400391062ec3e8655b2c7cd22769dd51917ac9fd3b3e1f11a8")
addappid(355353, 1, "27a2c0bcdcb8620c7e722da2104cc805857f443323a8eb4380447311fa271868")
addappid(355354, 1, "1311f2f940c6a7ac1b062c548c98e18cd9b128beb73ffd656192395532a084d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
