-- Lua provided by RyzenAPI
-- Game: Cipher Monk

-- MAIN APPLICATION
addappid(2772900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772901, 1, "bbcefbb856081d437a739c01b8bcad1f18c00b3eebcc31e937109775f81b46d0")

