-- Lua provided by RyzenAPI
-- Game: 仙侠世界2

-- MAIN APPLICATION
addappid(1674340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1674341, 1, "d9685ae72013ab52c65a29b7f72c5be61cba3256ad06145dcb966431bd9f3eca")

