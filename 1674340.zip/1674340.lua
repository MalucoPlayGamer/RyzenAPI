-- Lua provided by RyzenAPI
-- Game: Game: AppID 1674340

-- MAIN APPLICATION
addappid(1674340)
-- Game: addappid(1674340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674341, 1, "d9685ae72013ab52c65a29b7f72c5be61cba3256ad06145dcb966431bd9f3eca")
