-- Lua provided by RyzenAPI
-- Game: 仙侠世界2

-- MAIN APPLICATION
addappid(1674340) -- 仙侠世界2
addappid(1873680) -- 2-
addappid(1873690) -- 2-
addappid(1873700) -- 2-
addappid(1873710) -- 2-
addappid(3384790) -- 2-
addappid(3384800) -- 2-
addappid(3384810) -- 2-
addappid(3384830) -- 2-

-- MAIN APP DEPOTS / PACKAGES
addappid(1674341, 1, "d9685ae72013ab52c65a29b7f72c5be61cba3256ad06145dcb966431bd9f3eca") -- 仙侠世界2 Content
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
