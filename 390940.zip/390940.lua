-- Lua provided by RyzenAPI
-- Game: The Musketeers: Victoria's Quest

-- MAIN APPLICATION
addappid(390940)

-- MAIN APP DEPOTS / PACKAGES
addappid(390941, 1, "424fce15d16583998adedab83d6f4bc6e43b695261725bfe3e2de3a5d2cb3ab0")

