-- Lua provided by RyzenAPI
-- Game: 1553910

-- MAIN APPLICATION
addappid(1553910)
-- Game: addappid(1553910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553911, 1, "3efe59e5b875e3174e994c1ca02cd93a0f39d372b96479f203cbfa9a3ce7252e")
