-- 4464670's Lua and Manifest Created by Hubcap Manifest
-- Slime Jamboree
-- Created: August 16, 2026 at 12:59:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4464670) -- Slime Jamboree
-- MAIN APP DEPOTS
addappid(4464671, 1, "8c47214c401e47530ed938059349f35ef8935ff22f46f4e9944ce145f8aa436b") -- Depot 4464671
setManifestid(4464671, "6110557249661894820", 247908159)