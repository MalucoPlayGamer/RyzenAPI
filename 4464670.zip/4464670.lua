-- Lua provided by RyzenAPI
-- Game: Slime Jamboree

-- MAIN APPLICATION
addappid(4464670) -- Slime Jamboree

-- MAIN APP DEPOTS / PACKAGES
addappid(4464671, 1, "8c47214c401e47530ed938059349f35ef8935ff22f46f4e9944ce145f8aa436b") -- Depot 4464671

