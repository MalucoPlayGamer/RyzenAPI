-- Lua provided by RyzenAPI
-- Game: addappid(3092290)

-- MAIN APPLICATION
addappid(3092290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092291, 1, "48598b3e5d4f571f099f1acdf7c94ac98acee865700c45fb1135e185543ffa3a")
