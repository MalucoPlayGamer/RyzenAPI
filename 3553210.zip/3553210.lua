-- Lua provided by RyzenAPI
-- Game: addappid(3553210)

-- MAIN APPLICATION
addappid(3553210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3553211, 1, "fa1462b15979f2739eafc2a1371af2f6f3e4ace223e2e477a842c1fcddce8a7f")
