-- Lua provided by RyzenAPI
-- Game: The Legend of Dark Witch Episode 4

-- MAIN APPLICATION
addappid(2644240)
addappid(3864720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644241, 1, "91999ae2c1ae89c4233a5d729c91b1b27bab5a78666126dcc38bff12d5a659b9")
addappid(3773340, 0, "158480c17cc03958516302415563269cee62e763a57251a4811720e7ea575a87")

