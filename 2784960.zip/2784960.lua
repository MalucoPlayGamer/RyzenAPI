-- Lua provided by RyzenAPI
-- Game: Avian Enigma

-- MAIN APPLICATION
addappid(2784960)
-- Game: addappid(2784960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784962,0,"8d11d333333a0643bdb3b4180ec3140dcb7b5c70ec503d7480d6c86edf61a3e9")
