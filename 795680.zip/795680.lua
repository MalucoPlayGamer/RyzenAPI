-- Lua provided by RyzenAPI
-- Game: 795680

-- MAIN APPLICATION
addappid(795680)
addappid(795681)
addappid(795683)
addappid(795685)
addappid(795686)
addappid(795687)
addappid(795688)
addappid(795689)
addappid(812750)

-- MAIN APP DEPOTS / PACKAGES
addappid(795682,0,"cc724d12f970311a7339a92efca38ec6d965764c951dd88f195e1d10e90fb6b6")
addappid(795684,0,"26b9b5ce4a940cff17925273f543432e3e0723060d3abf64482cb678f39616e5")
