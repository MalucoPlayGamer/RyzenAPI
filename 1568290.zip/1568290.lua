-- Lua provided by RyzenAPI
-- Game: Game: AppID 1568290

-- MAIN APPLICATION
addappid(1568290)
-- Game: addappid(1568290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568291, 1, "4a00629c8da15ff3363f1d444d33c70b7a06773dd7f7a64041c185e6c97a7fb1")
