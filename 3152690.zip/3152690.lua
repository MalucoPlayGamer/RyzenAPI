-- Lua provided by RyzenAPI
-- Game: addappid(3152690)

-- MAIN APPLICATION
addappid(3152690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152691, 1, "e2092e1534d295194f597f2a7674e366c61645c8ac25227b48ee1f0cbd0f1cda")
