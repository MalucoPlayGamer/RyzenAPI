-- Lua provided by RyzenAPI
-- Game: 3626090

-- MAIN APPLICATION
addappid(3626090)
-- Game: addappid(3626090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3626091, 1, "aead28beb1774163df841c7c8fe8484fe8378b2b68a0844d1c4b820b305fc090")
