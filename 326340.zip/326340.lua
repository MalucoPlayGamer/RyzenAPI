-- Lua provided by SkyAPI 
-- Game: River City Super Sports Challenge ~All Stars Special~
addappid(326340)
addappid(326341, 1, "75d5489473106c211c7e252078f38c1eb3795cb2f410af3a3d1e4abc67c78227")
