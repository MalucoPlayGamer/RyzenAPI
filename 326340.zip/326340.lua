-- Lua provided by RyzenAPI
-- Game: River City Super Sports Challenge ~All Stars Special~

-- MAIN APPLICATION
addappid(326340)

-- MAIN APP DEPOTS / PACKAGES
addappid(326341, 1, "75d5489473106c211c7e252078f38c1eb3795cb2f410af3a3d1e4abc67c78227")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
