-- Lua provided by RyzenAPI
-- Game: Cao Ren - Officer Ticket / 曹仁使用券

-- MAIN APPLICATION
addappid(956731)

-- MAIN APP DEPOTS / PACKAGES
addappid(956731,0,"6319423811b2b1899d428f570a7c73946a88df111fcd9812c970cee624ce5d88")
