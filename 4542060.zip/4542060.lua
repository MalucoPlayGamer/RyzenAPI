-- 4542060's Lua and Manifest Created by Hubcap Manifest
-- Evergarden
-- Created: July 10, 2026 at 10:34:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4542060) -- Evergarden
-- MAIN APP DEPOTS
addappid(4542061, 1, "5664732d1e50d95e321b79085c8a2659bda959b2a48da481cd454037a801c928") -- Depot 4542061
setManifestid(4542061, "4011412150352499964", 1735760790)