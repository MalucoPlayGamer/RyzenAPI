-- Lua provided by RyzenAPI
-- Game: VR Hentai Girl 3

-- MAIN APPLICATION
addappid(1419121)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419121,0,"a99d65f08266404d1ad9e044df85f2c4829647d7bbe07ccf159925e8ecf92f7e")
