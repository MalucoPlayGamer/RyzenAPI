-- Lua provided by RyzenAPI
-- Game: OlliOlli2: Welcome to Olliwood

-- MAIN APPLICATION
addappid(365660)
addappid(365661)
addappid(398520)

-- MAIN APP DEPOTS / PACKAGES
addappid(365662,0,"7e5d5765a10264abb6e58d928003168953e5aa90b66021e44dc1b89bef01e7d0")
addappid(365663,0,"3764bbe4b2dfa8bfba556fdd2dda57c476a1a7531a69cdea9eff16263287fcd9")
addappid(365664,0,"ecdc5f451684201658915cbff9fc41569f2071480b70c060a1cda61adffc9b60")
