-- Lua provided by RyzenAPI
-- Game: Game: AppID 495780

-- MAIN APPLICATION
addappid(495780)
addappid(511300)
addappid(511301)
-- Game: addappid(495780)

-- MAIN APP DEPOTS / PACKAGES
addappid(495781, 1, "0f2f22f3f45392bd4514b4f88dc7927ce56fe8d0c0ca1aa26395ffe536e27ae3")
addappid(495782, 1, "c181454e5d257f4c818ddd2a394ee5ef37a54ef6637503721f1afddd205e6103")
