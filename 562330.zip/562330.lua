-- Lua provided by RyzenAPI
-- Game: Dwarflings

-- MAIN APPLICATION
addappid(562330)

-- MAIN APP DEPOTS / PACKAGES
addappid(562331, 1, "b8f6eb5f083b3b4c7bbae1b747b6b870a5c761927390e27da490f53fe57deebd")

