-- Lua provided by RyzenAPI
-- Game: 1472400

-- MAIN APPLICATION
addappid(1472400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472400,0,"00cfa6f7a0239b44c8ef70dfd628a31e1bbd4246752cdffb00f8d146b507eb62")
