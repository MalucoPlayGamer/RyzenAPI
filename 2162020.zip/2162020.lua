-- Lua provided by RyzenAPI
-- Game: Strayed Lights

-- MAIN APPLICATION
addappid(2162020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162021, 1, "c921eac6de027e25c420e2c68ede47fa16bf9d518bc5374551d7fc5b8ad9317d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2347510)
