-- Lua provided by RyzenAPI
-- Game: Game: My Special Summer Vacation 2

-- MAIN APPLICATION
addappid(2923560)
-- Game: addappid(2923560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923561, 1, "9c5890289649d8633185f70414f40b817b3cc13c4d3ad81106cc8c6acdf68866")
addappid(2923562, 1, "410ff6282034ee5062a716ff0e74f28b08c0b7f7f64e6a00e76a56a4f3d9c503")
addappid(2923563, 1, "46c773d0e29fc5c45ce90da51946b10f347a4287b25224b2531663fc5a15fdf3")
