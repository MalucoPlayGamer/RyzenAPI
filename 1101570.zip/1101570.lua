-- Lua provided by RyzenAPI
-- Game: addappid(1101570)

-- MAIN APPLICATION
addappid(1101570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101571, 1, "d3256e703f4a87560df0d719dcbd753cd6e7be6b861f10d44f048e1f19c4b2cc")
