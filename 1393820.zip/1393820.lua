-- Lua provided by SkyAPI 
-- Game: AppID 1393820
addappid(1393820)
addappid(1393821, 1, "088ce3a81a352a7ba4dac80756cc2381c7a1076644c5f985fa6195e79b3f8cbf")
