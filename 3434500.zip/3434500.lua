-- Lua provided by SkyAPI 
-- Game: Dead Don't Die Demo
addappid(3434500)
addappid(3434501, 1, "5aadf35a927f716106ef73871e8a125125faf66e913c8a08b3fe8475166c81e9")
