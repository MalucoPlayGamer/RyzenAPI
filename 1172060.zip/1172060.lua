-- Lua provided by RyzenAPI
-- Game: Rest In Pieces

-- MAIN APPLICATION
addappid(1172060)
-- Game: addappid(1172060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172061, 1, "e82fff907723b4c1b04ea03bd357688f96c73278e37a6636e5771735cd785af3")
