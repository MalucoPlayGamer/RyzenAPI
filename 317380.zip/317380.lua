-- Lua provided by RyzenAPI 
-- Game: AppID 317380
addappid(317380)
addappid(317381, 1, "14768dc4749b1ba8897b72291a5447d821bd7686d3c1ccd1d1f7e72b57160e7f")
addappid(317382, 1, "da4145db9a002dcd42808c57c8d320efe32367d43d32a42353c1a14074a9483a")
