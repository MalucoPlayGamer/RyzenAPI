-- Lua provided by RyzenAPI
-- Game: Self-Checkout Unlimited

-- MAIN APPLICATION
addappid(1221320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221321, 1, "d883df76e4ab73afd79b5b81495eb76710bd9fbe9c361de7fbd42e064ba3a547")
addappid(1221322, 1, "19318be58d6b8dc0b623f5200fd35deb11903a0eb2c86addb63ad7ed87e3dfbd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
