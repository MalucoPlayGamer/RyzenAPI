-- Lua provided by RyzenAPI
-- Game: addappid(858030)

-- MAIN APPLICATION
addappid(858030)

-- MAIN APP DEPOTS / PACKAGES
addappid(858031, 1, "a814db2b2973042f846f4c75f1f034ae758d4752a2ec44cb317ad5b2ff4c26b9")
