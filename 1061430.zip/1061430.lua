-- Lua provided by RyzenAPI
-- Game: Adagio

-- MAIN APPLICATION
addappid(1061430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061431, 1, "9931ecdd5b6558ac0affc664175c549777d5abdef2dc6d923e00eeda7eccfe31")
