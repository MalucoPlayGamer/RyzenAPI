-- Lua provided by RyzenAPI
-- Game: 2840420

-- MAIN APPLICATION
addappid(2840420)
-- Game: addappid(2840420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840421, 1, "289e4ff765fbbbd17a4daf6a1ea0a1467f4068b9886799b939076d6a62da0a99")
