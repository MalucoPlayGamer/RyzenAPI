-- Lua provided by RyzenAPI
-- Game: HEDE Game Engine

-- MAIN APPLICATION
addappid(1313330)
-- Game: addappid(1313330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313331, 1, "93322c0ac44fe86131c213869697e3e145d64caa633d4593bb0d6a19ceb28504")
