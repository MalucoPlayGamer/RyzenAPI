-- Lua provided by RyzenAPI
-- Game: Game: Toadomination

-- MAIN APPLICATION
addappid(1687040)
-- Game: addappid(1687040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687041, 1, "8a56154101889d3785e35454cd181f91ed1905ad3a8af7b8061714c5f622de24")
