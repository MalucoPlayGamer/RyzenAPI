-- Lua provided by SkyAPI 
-- Game: Toadomination
addappid(1687040)
addappid(1687041, 1, "8a56154101889d3785e35454cd181f91ed1905ad3a8af7b8061714c5f622de24")
