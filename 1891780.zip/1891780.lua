-- Lua provided by RyzenAPI
-- Game: addappid(1891780)

-- MAIN APPLICATION
addappid(1891780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891781, 1, "5cc09b86101e35be38bf44688d9f8177b46c4e6442cabf108b0d90c8d91af08e")
