-- Lua provided by RyzenAPI
-- Game: 2945630

-- MAIN APPLICATION
addappid(2945630)
-- Game: addappid(2945630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945630,0,"948d67b9b3f9a86527dbc70fb2c69ddb3163cbba5f848c838a600ba5c1ab760f")
