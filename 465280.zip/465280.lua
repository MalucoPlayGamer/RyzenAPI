-- Lua provided by RyzenAPI
-- Game: AppID 465280

-- MAIN APPLICATION
addappid(465280)

-- MAIN APP DEPOTS / PACKAGES
addappid(465281, 1, "ecbe6e14974be564079b8f942587dcaea0a171a6f9854a11a5593563a96a5d41")
addappid(465282, 1, "a2fa63c5d1cba792fc2a478a5844a58998978792e2bf1814bd6a9a3637af2734")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
