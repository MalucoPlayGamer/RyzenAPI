-- Lua provided by RyzenAPI
-- Game: AppID 225940

-- MAIN APPLICATION
addappid(225940)

-- MAIN APP DEPOTS / PACKAGES
addappid(225941, 1, "9dcbb9c9339eba81e24a387890b0123dc6a4ddcd96ba367ea81d17d8ee6fe8d3")

