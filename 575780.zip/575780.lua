-- Lua provided by RyzenAPI
-- Game: Inner silence

-- MAIN APPLICATION
addappid(575780)
-- Game: addappid(575780)

-- MAIN APP DEPOTS / PACKAGES
addappid(575781, 1, "b5506e336b1e233baa02444cb74a0c304ee21b0184a3539b9bc3af9bca36cf57")
