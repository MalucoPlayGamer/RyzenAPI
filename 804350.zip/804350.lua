-- Lua provided by RyzenAPI
-- Game: Starman

-- MAIN APPLICATION
addappid(804350)

-- MAIN APP DEPOTS / PACKAGES
addappid(804352,0,"5352e8013a3548ff6c6d75d12fddcd617f5cea5bacf69cc5577a71c7f0396631")

