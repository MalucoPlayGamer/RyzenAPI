-- Lua provided by RyzenAPI
-- Game: Meadowland

-- MAIN APPLICATION
addappid(320120)

-- MAIN APP DEPOTS / PACKAGES
addappid(320121, 1, "d08adf5ef984bb466dc9c38c1ade5e7a161c9f0a486f93006433a60d09fd26f5")
