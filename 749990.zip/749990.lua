-- Lua provided by RyzenAPI
-- Game: Game: Trigonometry

-- MAIN APPLICATION
addappid(749990)
-- Game: addappid(749990)

-- MAIN APP DEPOTS / PACKAGES
addappid(749991, 1, "8530a2ebe598c47badc6a189bff70300fea3785e8d1b243d5bcd27a62c440489")
addappid(749992, 1, "c3f76d718474e58055a556d57ad5b994a26938e7535cb13b1537ebde39332110")
addappid(749993, 1, "63c8282606ec57bd7b5ae10abb0f92dc27143a1dc6a9d42a579d3956d8932995")
