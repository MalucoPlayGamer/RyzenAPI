-- Lua provided by RyzenAPI
-- Game: Game: Splintered

-- MAIN APPLICATION
addappid(3127000)
-- Game: addappid(3127000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127001, 1, "271288167b4c985c94592aaa096637300995c2106930ce751c4b8d95f500fca3")
