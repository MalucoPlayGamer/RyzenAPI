-- Lua provided by RyzenAPI
-- Game: Game: AppID 1086070

-- MAIN APPLICATION
addappid(1086070)
-- Game: addappid(1086070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086071, 1, "9a5a309d771932a4be53ffdf0e3173a58acd2914397fd5f609f49eba96420633")
