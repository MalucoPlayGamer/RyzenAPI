-- Lua provided by RyzenAPI
-- Game: Kittens' Maze

-- MAIN APPLICATION
addappid(1460300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1460301, 1, "461af5e76fb494282d57f76dd7b876842692efe4e00f25ed9edf150fdbece334")

