-- Lua provided by RyzenAPI
-- Game: 1460300

-- MAIN APPLICATION
addappid(1460300)
-- Game: addappid(1460300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460301, 1, "461af5e76fb494282d57f76dd7b876842692efe4e00f25ed9edf150fdbece334")
