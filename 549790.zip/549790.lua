-- Lua provided by RyzenAPI
-- Game: Glorch's Great Escape: Walking is for Chumps

-- MAIN APPLICATION
addappid(549790)

-- MAIN APP DEPOTS / PACKAGES
addappid(549791, 1, "fa9c1649ad676d19d0940094fcc9f115ae46c11296975f2d852a5314e6b6a9ef")
