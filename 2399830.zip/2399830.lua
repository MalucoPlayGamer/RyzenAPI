-- 2399830's Lua and Manifest Created by Hubcap Manifest
-- ARK: Survival Ascended
-- Created: August 10, 2026 at 16:58:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 19
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2399830, 1, "b1ea599fef75fb79ad1302210f84313f0e014f3dc079f2af31ae524390ddf59d") -- ARK: Survival Ascended
-- MAIN APP DEPOTS
addappid(2399831, 1, "320e0bcc46f1e7d88e18488c73990878eedbc06c3284015e1d0af97abe143e23") -- Depot 2399831
setManifestid(2399831, "3043226382517458870", 227598069522)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- ARK The Center Ascended (AppID: 2827030)
addappid(2827030)
addappid(2827030, 1, "ca47571a30440cd0d827bee6a57a945cf56d25fd4dbc19435d608994b021302a") -- ARK The Center Ascended - Depot 2827030
setManifestid(2827030, "985219264259992854", 9670009235)
-- ARK Scorched Earth Ascended (AppID: 2849450)
addappid(2849450)
addappid(2849450, 1, "06a4aa068a1a3940e0c7eff34508ad6474806f4b46520ef9ea12b4b7f77a3d0e") -- ARK Scorched Earth Ascended - Depot 2849450
setManifestid(2849450, "6069721793311760594", 6920183114)
-- ARK Aberration Ascended (AppID: 3059650)
addappid(3059650)
addappid(3059650, 1, "84b1a413568c28ea0226bbd983fbf08741ead907cc7cd9cdd447056405850bd2") -- ARK Aberration Ascended - Depot 3059650
setManifestid(3059650, "3880667613636701611", 7054046846)
-- ARK Extinction Ascended (AppID: 3349320)
addappid(3349320)
addappid(3349320, 1, "e0cbc7f932b6b5ffa7e36b9fe8ccf5b2317d5073f520b8a357a7bb8e32d7a181") -- ARK Extinction Ascended - Depot 3349320
setManifestid(3349320, "7342484876145087424", 5580128437)
-- ARK Astraeos (AppID: 3483400)
addappid(3483400)
addappid(3483400, 1, "8f2706fe64f86426091cbb9a23dedbc3ec0c53a78877abb9b549edded5f436ea") -- ARK Astraeos - Depot 3483400
setManifestid(3483400, "5017337524397185913", 21988972081)
-- ARK Lost Colony (AppID: 3583650)
addappid(3583650)
addappid(3583650, 1, "e7d5b3c53aabefd8ec1f24038e55c6e614c31d7e5c6237c443e83c4eb1fc5a83") -- ARK Lost Colony - Depot 3583650
setManifestid(3583650, "2774553589679785350", 43420691312)
-- ARK Ragnarok Ascended (AppID: 3675020)
addappid(3675020)
addappid(3675020, 1, "5028ee914f2c74aba43cc91d7f2f49fd5ad0ec96dcb76372ed26deec22b0e88c") -- ARK Ragnarok Ascended - Depot 3675020
setManifestid(3675020, "722295771521371919", 12700862064)
-- ARK Valguero Ascended (AppID: 3982310)
addappid(3982310)
addappid(3982310, 1, "184547e9bf5059e77f7971af6c7a064a5a7eb7a76a3b210fbeed6ebb00df991c") -- ARK Valguero Ascended - Depot 3982310
setManifestid(3982310, "5064609552693366804", 20725547736)
-- ARK Genesis Ascended Part 1 (AppID: 4558470)
addappid(4558470)
addappid(4558470, 1, "4b8207f4622bf4e9eb35a0da27d875f87b29ea9081d4cf4188ebf38cbbf1fde3") -- ARK Genesis Ascended Part 1 - Depot 4558470
setManifestid(4558470, "2113233885702716604", 19024608943)
-- ARK Dragontopia (AppID: 4558490)
addappid(4558490)
addappid(4558490, 1, "d20fe0649f9a014dbb0feb29ecd21514ec3b7743f4d49d3cb8885afb1b22e020") -- ARK Dragontopia - Depot 4558490
setManifestid(4558490, "5157510924718883041", 3)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2881150) -- ARK Bobs Tall Tales
addappid(2972680) -- ARK Fantastic Tames - Pyromane
addappid(3282470) -- ARK Fantastic Tames - Dreadmare
addappid(3571730) -- ARK Animated Series 109-Costumes Pack
addappid(3720100) -- ARK Lost Colony Expansion Pass
addappid(3720200) -- ARK Fantastic Tames - Drakelings
addappid(3982300) -- ARK Fantastic Tames - Elderclaw
addappid(4558480) -- ARK Tides of Fortune
addappid(4558510) -- ARK Fantastic Tames Season 1