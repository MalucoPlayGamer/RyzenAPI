-- Lua provided by RyzenAPI
-- Game: 1558560

-- MAIN APPLICATION
addappid(1558560)
-- Game: addappid(1558560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558561, 1, "a9b3276e5cdf37941a55f5eaccd6250fdcda88f46e6b7e40759ed20a082a5112")
