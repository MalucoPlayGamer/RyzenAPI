-- Lua provided by RyzenAPI
-- Game: Harvest Island: Beginnings

-- MAIN APPLICATION
addappid(1446320)
-- Game: addappid(1446320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446321, 1, "ce48ebc59928f33849bb3a55db80b6e33e12bbfebdedf0b285b96c8498bc95b5")
