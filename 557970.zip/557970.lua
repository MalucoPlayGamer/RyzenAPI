-- Lua provided by RyzenAPI
-- Game: addappid(557970)

-- MAIN APPLICATION
addappid(557970)

-- MAIN APP DEPOTS / PACKAGES
addappid(557971, 1, "0d49f0620575f7c9a50c56d96a7e6ee5bb7c216b19ab2f7abd9a873d7dd5a69b")
addappid(557972, 1, "5c99c9445de102bb9aff135f9396dfe9fae03f234324457a85b40ce9fe77d513")
