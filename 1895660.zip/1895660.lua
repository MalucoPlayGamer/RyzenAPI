-- Lua provided by RyzenAPI
-- Game: Koncolos: Prologue

-- MAIN APPLICATION
addappid(1895660)
-- Game: addappid(1895660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895661, 1, "16c2c7a9254ab7a17ddb3cf87121b58623bc2f8274abe6b90c4516e920fd6be5")
