-- Lua provided by RyzenAPI
-- Game: 12 Labours of Hercules VIII: How I Met Megara

-- MAIN APPLICATION
addappid(938310)
-- Game: addappid(938310)

-- MAIN APP DEPOTS / PACKAGES
addappid(938311, 1, "a4e41342bd76f90ccb2ca2c640a904e55543a16ccb2f282cd0c6c113fd814b58")
