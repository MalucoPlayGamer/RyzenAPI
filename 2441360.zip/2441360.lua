-- Lua provided by RyzenAPI
-- Game: 2441360

-- MAIN APPLICATION
addappid(2441360)
addappid(2746930)
-- Game: addappid(2441360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441361, 1, "93802718adec1fc87bff8aa465376f1d80fb030b1422b3d78969070f58c15faf")
