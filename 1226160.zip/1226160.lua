-- Lua provided by RyzenAPI
-- Game: addappid(1226160)

-- MAIN APPLICATION
addappid(1226160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226162,0,"0c650aca2d9c53e705aa263ef7f19bd286d8fd65da166cabb0d755f773f7ba40")
