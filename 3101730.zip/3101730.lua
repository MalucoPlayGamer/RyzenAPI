-- Lua provided by RyzenAPI
-- Game: Game Of Fate Demo

-- MAIN APPLICATION
addappid(3101730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101731, 1, "424fc9f6f027e632b2c2a3ca76bfb40a9999ad490c7f0f96989a476d1524b407")
