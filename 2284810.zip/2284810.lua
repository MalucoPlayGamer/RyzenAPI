-- Lua provided by RyzenAPI 
-- Game: AppID 2284810
addappid(2284810)
addappid(2284811, 1, "ce88180bd798322375a5dd9d7e54535f641eba939641602adee2d096c2e27ccd")
