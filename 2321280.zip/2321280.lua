-- Lua provided by RyzenAPI
-- Game: Heretic's Fork Demo

-- MAIN APPLICATION
addappid(2321280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321281, 1, "a60becad4288b2c41ed20213308fd7bd69f7539200b6c0c6cd6b4fc904cf7f12")
