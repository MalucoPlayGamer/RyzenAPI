-- Lua provided by RyzenAPI
-- Game: タネヅケ不動産～赤ちゃんの為の子宮（ぶっけん）探し～

-- MAIN APPLICATION
addappid(4273060)

-- MAIN APP DEPOTS / PACKAGES
addappid(4273062,0,"11a0f3a313c73e43c728a6f4c6f62f850508444e6b59920356a62a0d4952011e")

