-- Lua provided by RyzenAPI
-- Game: 2668680

-- MAIN APPLICATION
addappid(2668680)
-- Game: addappid(2668680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668681, 1, "948aa11c26cf7c11b715b4e56224641e85cae89e6fab35279284761df11c140e")
