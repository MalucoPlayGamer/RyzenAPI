-- Lua provided by RyzenAPI
-- Game: Click To Eleven

-- MAIN APPLICATION
addappid(1586220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586221, 1, "30f3ab65d8cd4a97d0c2ab8126a0ae19de54de2c7bde943b10e72dbe6ee8fa96")
