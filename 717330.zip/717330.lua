-- Lua provided by RyzenAPI
-- Game: Halloween Pumpkin Story

-- MAIN APPLICATION
addappid(717330)

-- MAIN APP DEPOTS / PACKAGES
addappid(717331,0,"834573a2af82e01706c5149f05c0f66b9df4eacecda3206c494f704671a6b0d0")

