-- Lua provided by RyzenAPI
-- Game: Jericho Dungeon

-- MAIN APPLICATION
addappid(1808690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808691, 1, "7ac8012aec4254c6eaedb6e12becd92ec5bbcf06c6aa1a1895c1e8e3a840f608")

