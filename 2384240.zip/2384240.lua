-- Lua provided by RyzenAPI
-- Game: Never Meet Your Heroes

-- MAIN APPLICATION
addappid(2384240)
-- Game: addappid(2384240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384241, 1, "ff7af034867cb22f36e110c6f84744d4664a6ea6b07903e8a984c422bd73e523")
