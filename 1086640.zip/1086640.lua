-- Lua provided by SkyAPI 
-- Game: Dude Simulator 3
addappid(1086640)
addappid(1086641, 1, "364bde962e4e62274087a77975131cd7f4793c3a3e711166fe2b9759d0d4f22d")
