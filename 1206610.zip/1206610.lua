-- Lua provided by RyzenAPI
-- Game: Rubber Bandits

-- MAIN APPLICATION
addappid(1206610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206611, 1, "8e0e90d3dfd12c16c29945a1219a0273045d54571c434f3adc559d55b89e5ade")
