-- Lua provided by RyzenAPI
-- Game: 1428420

-- MAIN APPLICATION
addappid(1428420)
-- Game: addappid(1428420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428421, 1, "ac43af7109101c47a87ace9779caefb38f41bc5c97d6e7c9eb8e76652939e6c9")
addappid(3000380, 0, "bb3ddd9cc724263241d5b868d6bb32ffba6ecf59a4f9527aee50d5c2779bbd5f")
