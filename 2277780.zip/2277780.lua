-- Lua provided by RyzenAPI
-- Game: Ara and the Empty Universe

-- MAIN APPLICATION
addappid(2277780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277781, 1, "edc683cf34f2fc4d520e6316cec82884cd5b5934073f3acfaef21f5fefa1062c")

