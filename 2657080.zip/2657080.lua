-- Lua provided by RyzenAPI
-- Game: Teardown: Quilez R0113R Robot

-- MAIN APPLICATION
addappid(2657080)
-- Game: addappid(2657080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657080,0,"204a8120beb5167f417969cac2724a24b5a1b35019dc45f94cca8fc986512185")
