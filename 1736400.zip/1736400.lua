-- Lua provided by SkyAPI 
-- Game: TramSim Munich - The Tram Simulator
addappid(1736400)
addappid(1736401, 1, "87335a1372ef65359000b31539137a4a72e652de2051c49a2c9aab389e2bb2fd")
