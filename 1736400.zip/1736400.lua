-- Lua provided by RyzenAPI
-- Game: TramSim Munich - The Tram Simulator

-- MAIN APPLICATION
addappid(1736400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1736401, 1, "87335a1372ef65359000b31539137a4a72e652de2051c49a2c9aab389e2bb2fd")

