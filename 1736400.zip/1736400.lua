-- Lua provided by RyzenAPI
-- Game: Game: TramSim Munich - The Tram Simulator

-- MAIN APPLICATION
addappid(1736400)
-- Game: addappid(1736400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736401, 1, "87335a1372ef65359000b31539137a4a72e652de2051c49a2c9aab389e2bb2fd")
