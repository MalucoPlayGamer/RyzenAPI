-- Lua provided by RyzenAPI
-- Game: Game: AppID 1416190

-- MAIN APPLICATION
addappid(1416190)
-- Game: addappid(1416190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416191, 1, "2fa7e4f616d8cf6d64ce02541b5ff85c18e6258e0946ee2ebcb984f735ddd421")
