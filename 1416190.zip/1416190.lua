-- Lua provided by RyzenAPI
-- Game: 发条

-- MAIN APPLICATION
addappid(1416190)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1416191, 1, "2fa7e4f616d8cf6d64ce02541b5ff85c18e6258e0946ee2ebcb984f735ddd421")
