-- Lua provided by RyzenAPI
-- Game: Game: Escape to Moscow

-- MAIN APPLICATION
addappid(1484960)
-- Game: addappid(1484960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484961, 1, "eff8a7dbd0f8563b9d8a9420ca841cb104c1d853b648f18acd41d3485755ae41")
