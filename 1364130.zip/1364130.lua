-- Lua provided by RyzenAPI
-- Game: Game: Chaotic Airport Construction Manager

-- MAIN APPLICATION
addappid(1364130)
-- Game: addappid(1364130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364131, 1, "d3b40da86614c6053a6db65cabd7c6b7ff319721c11e221a5e60f8f46669393c")
