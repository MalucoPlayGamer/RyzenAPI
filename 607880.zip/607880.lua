-- Lua provided by RyzenAPI
-- Game: Accel World VS. Sword Art Online Deluxe Edition

-- MAIN APPLICATION
addappid(607880)

-- MAIN APP DEPOTS / PACKAGES
addappid(607881, 1, "344be9dc6e3c119e636417add6a38bb91e2cacadc663fcd74bcc2e4de5dc61aa")

