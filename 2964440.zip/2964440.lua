-- Lua provided by RyzenAPI
-- Game: addappid(2964440)

-- MAIN APPLICATION
addappid(2964440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964442,0,"315d131b6009fd9a1d530ca8942c0d8ceba080693f1a4a0be0a07711aacb5481")
