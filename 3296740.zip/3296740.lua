-- Lua provided by SkyAPI 
-- Game: AppID 3296740
addappid(3296740)
addappid(3296741, 1, "e6c20155bb4dbd2037ad842dab222776ab1f61c1c7cbd2c6856942140c4ff38a")
