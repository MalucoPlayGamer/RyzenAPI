-- Lua provided by RyzenAPI
-- Game: 卡丹历险记 Demo

-- MAIN APPLICATION
addappid(3296740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296741, 1, "e6c20155bb4dbd2037ad842dab222776ab1f61c1c7cbd2c6856942140c4ff38a")

