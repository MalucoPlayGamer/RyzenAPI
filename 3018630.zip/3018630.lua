-- Lua provided by RyzenAPI
-- Game: 3018630

-- MAIN APPLICATION
addappid(3018630)
-- Game: addappid(3018630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018631, 1, "df31ffc46f815d350fbf6560b8ad3ef2a321acdee85c22c2b6867fd1e5db5b65")
