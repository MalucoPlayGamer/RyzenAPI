-- Lua provided by RyzenAPI
-- Game: Nightmare Pursuit

-- MAIN APPLICATION
addappid(3018630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3018631, 1, "df31ffc46f815d350fbf6560b8ad3ef2a321acdee85c22c2b6867fd1e5db5b65")

