-- Lua provided by RyzenAPI
-- Game: Super Potato Bruh

-- MAIN APPLICATION
addappid(951360)

-- MAIN APP DEPOTS / PACKAGES
addappid(951361, 1, "346899292b1ba23c057c7126e61a5039e11298833c864e23e5ca2a864acc9fa6")

