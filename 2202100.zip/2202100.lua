-- Lua provided by RyzenAPI
-- Game: AppID 2202100

-- MAIN APPLICATION
addappid(2202100)
-- Game: addappid(2202100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202101, 1, "c8099466d33d8978a5407eeeddc5f8b983f2eb1671d9af3258c090e121454d9b")
