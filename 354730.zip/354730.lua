-- Lua provided by RyzenAPI
-- Game: Deadly Sin

-- MAIN APPLICATION
addappid(354730)

-- MAIN APP DEPOTS / PACKAGES
addappid(354731, 1, "3b32b25cd8c2756c0a8ff41bccbca15e3c7780a0606fc8ea14e6f3f1f70e6829")
