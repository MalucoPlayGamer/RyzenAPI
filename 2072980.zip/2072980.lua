-- Lua provided by SkyAPI 
-- Game: Final Knight
addappid(2072980)
addappid(2072981, 1, "ed2f903f534830206601542369719a93a978a1381a1cd76308784b5a560d0c3b")
