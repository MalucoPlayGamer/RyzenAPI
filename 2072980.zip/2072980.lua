-- Lua provided by RyzenAPI
-- Game: Game: Final Knight

-- MAIN APPLICATION
addappid(2072980)
-- Game: addappid(2072980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072981, 1, "ed2f903f534830206601542369719a93a978a1381a1cd76308784b5a560d0c3b")
