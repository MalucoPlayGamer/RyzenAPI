-- Lua provided by RyzenAPI 
-- Game: AppID 731230
addappid(731230)
addappid(731231, 1, "3c11c21f4414617522a9dc2fe4f799d909d2252f4d6b906ce8ea20cebd805e46")
