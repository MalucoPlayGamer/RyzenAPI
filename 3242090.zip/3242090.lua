-- Lua provided by RyzenAPI
-- Game: Artifact Seekers 1

-- MAIN APPLICATION
addappid(3242090)

