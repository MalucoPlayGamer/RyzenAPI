-- Lua provided by RyzenAPI
-- Game: Steel Hunters Beta Playtest

-- MAIN APPLICATION
addappid(1905910)
-- Game: addappid(1905910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905911, 1, "1f1485c7595da977c7358f0bc4188a3293f8980b25a9ba437a4f5c8d0325f5d6")
