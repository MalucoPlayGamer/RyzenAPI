-- Lua provided by RyzenAPI
-- Game: Game: AppID 922490

-- MAIN APPLICATION
addappid(922490)
-- Game: addappid(922490)

-- MAIN APP DEPOTS / PACKAGES
addappid(922491, 1, "6ed5ab755004936e71cd716ed0005388bc9bd0005a1ff67bab717dfc94df09aa")
