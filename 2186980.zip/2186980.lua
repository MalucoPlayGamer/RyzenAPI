-- Lua provided by RyzenAPI
-- Game: Deluge: Sermon for the Dead

-- MAIN APPLICATION
addappid(2186980)
addappid(3933160)
-- Game: addappid(2186980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186981, 1, "5adead8d48a1c65a9c5564e00f89200fa009f3c3f63bf346fd91ba66500bfced")
addappid(2186982, 1, "7431f5ecaac23a754b7ee4c1ae27f27f02b08bff763269afbf6a6dfc0274aef3")
addappid(2186983, 1, "e6310fa133c77a8d1f01822c4d159ace4a11aceb7cdbc57bb2c265a2d35bb319")
