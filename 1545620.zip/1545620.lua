-- Lua provided by RyzenAPI
-- Game: Arcane Arts Academy

-- MAIN APPLICATION
addappid(1545620)
-- Game: addappid(1545620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545621, 1, "2be8f3d6ec86cc8435f0ed04ddb5c3b86f8998552731e825e6552adf16ddd514")
