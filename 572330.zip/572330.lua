-- Lua provided by SkyAPI 
-- Game: The Fan
addappid(572330)
addappid(572331, 1, "b04b0db194f1cfa5b18df37c3ca7cf28f893e1b7f79bfced37a636c05234ddda")
