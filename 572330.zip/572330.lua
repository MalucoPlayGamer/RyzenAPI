-- Lua provided by RyzenAPI
-- Game: The Fan

-- MAIN APPLICATION
addappid(572330)

-- MAIN APP DEPOTS / PACKAGES
addappid(572331, 1, "b04b0db194f1cfa5b18df37c3ca7cf28f893e1b7f79bfced37a636c05234ddda")

