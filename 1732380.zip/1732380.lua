-- Lua provided by RyzenAPI
-- Game: Kingdom Two Crowns: Norse Lands Demo

-- MAIN APPLICATION
addappid(1732380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732381, 1, "9b35b1179765656be84ac265b2231d3956fb18cf25203413f37390104073ab5c")
