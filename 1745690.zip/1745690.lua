-- Lua provided by RyzenAPI
-- Game: Deluge: Threnody of Crashing Waves

-- MAIN APPLICATION
addappid(1745690)
addappid(3319770)
-- Game: addappid(1745690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745691, 1, "7227317272fa920e0e501532aaea07d847f94a656d36b3f6dc7875d0863f25be")
addappid(1745692, 1, "061dfecc47d93d048d8aa11c7fbcc66edefb71cec67f817e571dd3913557ccf0")
addappid(1745693, 1, "9cff49c0507b8670674b8b1f88391d9fad58772703a4fc10ce440624f6ec17b4")
