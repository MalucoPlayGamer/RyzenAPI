-- Lua provided by RyzenAPI
-- Game: Neon Drive

-- MAIN APPLICATION
addappid(433910)

-- MAIN APP DEPOTS / PACKAGES
addappid(433911, 1, "7fdfbc298ae85607fd51a2bed5bfd5e2e6fe8b99c8cf04af92c9e763095a551c")
addappid(433912, 1, "0fd3717a2dc3afa9fb0d7fedb19504bad6bd84b607d0d0c28dc5fea926c3d79b")
addappid(433913, 1, "f3cbc1aa93f6bc8a30c267f483e70d56ad7d3b0d32f6dcfc8f245d8710de9dba")

