-- Lua provided by RyzenAPI
-- Game: addappid(1000770)

-- MAIN APPLICATION
addappid(1000770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000771, 1, "0ca274bf825de97f40b733c65906d171dc56cb539976d76db1a89f8a786daa49")
