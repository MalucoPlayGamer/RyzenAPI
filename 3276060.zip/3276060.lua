-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor 2025

-- MAIN APPLICATION
addappid(3276060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276061, 1, "939e715ce6ccbaa1ef3912c3a492b1ae7bab55a809a3f96c91655c403678b2f6")

