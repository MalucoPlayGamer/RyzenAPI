-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor 2025

-- MAIN APPLICATION
addappid(3276060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276061, 1, "939e715ce6ccbaa1ef3912c3a492b1ae7bab55a809a3f96c91655c403678b2f6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3311000)
addappid(3311010)
addappid(3311020)
addappid(3311030)
addappid(3311040)
addappid(3311050)
addappid(3311060)
addappid(3311070)
addappid(3311080)
addappid(3311120)
addappid(3311130)
addappid(3311140)
addappid(3311150)
addappid(3311170)
addappid(3311190)
addappid(3311200)
addappid(3311210)
addappid(3313680)
