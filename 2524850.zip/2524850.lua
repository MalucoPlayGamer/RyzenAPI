-- Lua provided by RyzenAPI
-- Game: Denshattack!

-- MAIN APPLICATION
addappid(2524850)
addappid(4609680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524851,0,"854834358f04229eb0eb1b0b522eb217236a1ada2f6864505bd1f1eeb349619c")

