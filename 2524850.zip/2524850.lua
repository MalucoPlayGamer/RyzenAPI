-- Lua provided by RyzenAPI
-- Game: Denshattack!

-- MAIN APPLICATION
addappid(2524850)
addappid(4609680)
addappid(4609680) -- Denshattack Seasonal Skin Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2524850, 1, "71cfa8f402b01290d4d504a9a6076693bbe06ddc565e7ed4409a625aa6fa9dcb") 
addappid(2524851,0,"854834358f04229eb0eb1b0b522eb217236a1ada2f6864505bd1f1eeb349619c")
addappid(2524851, 1, "854834358f04229eb0eb1b0b522eb217236a1ada2f6864505bd1f1eeb349619c") 

