-- Lua provided by RyzenAPI
-- Game: UEBERNATURAL: The Video Game - Prologue

-- MAIN APPLICATION
addappid(1386940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386941, 1, "904bbbcd4a5d3c07bbe7ccdcf268b7ddf6a36cbf4062805347707eace9d8cff8")
addappid(1386942, 1, "ba4e6a7ec82fca31741d293be11c9d7dde3cc1095d5eff265bf632f89b51a85b")
