-- Lua provided by RyzenAPI
-- Game: Nitroplus Blasterz: Heroines Infinite Duel

-- MAIN APPLICATION
addappid(482450)

-- MAIN APP DEPOTS / PACKAGES
addappid(482451, 1, "e3f759633391c83574db6b2ce4ca7cd7cf52add3327ac77870504a000e82c478")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
