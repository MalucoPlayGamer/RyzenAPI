-- Lua provided by RyzenAPI
-- Game: 482450

-- MAIN APPLICATION
addappid(482450)
-- Game: addappid(482450)

-- MAIN APP DEPOTS / PACKAGES
addappid(482451, 1, "e3f759633391c83574db6b2ce4ca7cd7cf52add3327ac77870504a000e82c478")
