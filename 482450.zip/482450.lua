-- Lua provided by RyzenAPI 
-- Game: Nitroplus Blasterz: Heroines Infinite Duel
addappid(482450)
addappid(482451, 1, "e3f759633391c83574db6b2ce4ca7cd7cf52add3327ac77870504a000e82c478")
