-- Lua provided by SkyAPI 
-- Game: Pleasure Party 2
addappid(2529930)
addappid(2529931, 1, "4059c537904c0743b3c6bb128e107aef1781d45004812ad50cdf810d6865efd8")
