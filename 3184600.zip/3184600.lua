-- Lua provided by RyzenAPI 
-- Game: AppID 3184600
addappid(3184600)
addappid(3184601, 1, "d6b8d87777b8a77421f0dce0f74bb27f3dcce17bf029d1ba58a5a0b6cdfdb93f")
