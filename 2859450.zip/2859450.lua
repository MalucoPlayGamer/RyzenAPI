-- Lua provided by RyzenAPI
-- Game: Find Cats With Friends

-- MAIN APPLICATION
addappid(2859450)
-- Game: addappid(2859450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859451, 1, "4e4553b3eee5a7b7feb25279ccf50c3210922597cfbacfb21dea69910e7cc088")
