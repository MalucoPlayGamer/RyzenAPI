-- Lua provided by RyzenAPI
-- Game: Find Cats With Friends

-- MAIN APPLICATION
addappid(2859450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859451, 1, "4e4553b3eee5a7b7feb25279ccf50c3210922597cfbacfb21dea69910e7cc088")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
