-- Lua provided by RyzenAPI
-- Game: Game: The Travelyan Home

-- MAIN APPLICATION
addappid(1258070)
-- Game: addappid(1258070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258071, 1, "0ea693b40297fd61db162781e7c64209e3d0248f247a0a551a70dd4c1512a9d2")
