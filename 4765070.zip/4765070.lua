-- 4765070's Lua and Manifest Created by Hubcap Manifest
-- Nova Swarm
-- Created: June 13, 2026 at 06:40:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4765070) -- Nova Swarm
-- MAIN APP DEPOTS
addappid(4765071, 1, "d6e4fbc7815fb86919ab75e82f4fb858da9fdaf4550958e9c0f194afeb1779f4") -- Depot 4765071
-- setManifestid(4765071, "359487553528548586", 776787451)