-- Lua provided by RyzenAPI
-- Game: Nubla 2 Soundtrack

-- MAIN APPLICATION
addappid(1969770)
-- Game: addappid(1969770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969771, 1, "484c3a66b8ab309898da06eff63303b055d8e75936df1ed6c05c6cb20b00573f")
