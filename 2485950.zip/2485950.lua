-- Lua provided by RyzenAPI
-- Game: Horror Engine: Tech Demo

-- MAIN APPLICATION
addappid(2485950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485951, 1, "4adf38019aeffc1644e050bf17543365f3ed8ed1f72fb19cea4eeb34cea269d7")
addappid(2485952, 1, "c41d138c535ee09505c940e768a69594e48d2c8a9bdcc9bf8a5717b2978fba16")
