-- Lua provided by RyzenAPI
-- Game: Game: Hentai Tales: The World Only Maid

-- MAIN APPLICATION
addappid(2803950)
-- Game: addappid(2803950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803951, 1, "dd150fa9604ae33a58e1a21909e699af5d825791811f306082a2d7d64931a2cd")
