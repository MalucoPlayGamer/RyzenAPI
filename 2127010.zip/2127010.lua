-- Lua provided by SkyAPI 
-- Game: Handyman Legend
addappid(2127010)
addappid(2127011, 1, "ba74b9378234ce633438b260700a436620223cfa82eae6430bf1c27e9682eeb2")
addappid(2346740, 0, "bd695e7ca426eb597393d681bc252d5f761626dd9272ec44994406b90845a1f6")
