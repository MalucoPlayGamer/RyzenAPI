-- Lua provided by RyzenAPI
-- Game: Be My Horde

-- MAIN APPLICATION
addappid(2499520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499521, 1, "bacd69c0a3b7139b1021cdbb881f516adbd0de86041bc85c742c56a5a79d585b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
