-- Lua provided by RyzenAPI
-- Game: 2499520

-- MAIN APPLICATION
addappid(2499520)
-- Game: addappid(2499520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499521, 1, "bacd69c0a3b7139b1021cdbb881f516adbd0de86041bc85c742c56a5a79d585b")
