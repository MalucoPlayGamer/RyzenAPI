-- Lua provided by RyzenAPI
-- Game: AppID 518100

-- MAIN APPLICATION
addappid(518100)
-- Game: addappid(518100)

-- MAIN APP DEPOTS / PACKAGES
addappid(518101, 1, "809d46b8fc9d272b51ab74ec6e6d612e388ea9abb87dd3ce21ca339d0efcf2be")
