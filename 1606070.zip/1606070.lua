-- Lua provided by RyzenAPI
-- Game: AppID 1606070

-- MAIN APPLICATION
addappid(1606070)
-- Game: addappid(1606070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606071, 1, "f000620ec627518c30511a1432dee8fac7b351ab567d6a05cacd80a7f900a46c")
