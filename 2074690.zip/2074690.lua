-- Lua provided by RyzenAPI
-- Game: addappid(2074690)

-- MAIN APPLICATION
addappid(2074690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074691, 1, "6fdfb5e68d876010ac534f1e61efec5515711ab47fdc86e16a14915da14192b7")
