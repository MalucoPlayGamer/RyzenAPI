-- Lua provided by RyzenAPI
-- Game: 1288430

-- MAIN APPLICATION
addappid(1288430)
-- Game: addappid(1288430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288431, 1, "787cde0ea9bbc7392c644f8a1a193f8c10e50f5556cdafa8d5430dcf9a13c900")
