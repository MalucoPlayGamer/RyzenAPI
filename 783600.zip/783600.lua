-- Lua provided by RyzenAPI
-- Game: Game: AppID 783600

-- MAIN APPLICATION
addappid(783600)
-- Game: addappid(783600)

-- MAIN APP DEPOTS / PACKAGES
addappid(783601, 1, "feadb62ad7ba36d860fa4ce5c9f7f0eabc26f0fbaf80e50adbf389b90046642b")
