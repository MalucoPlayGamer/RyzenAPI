-- Lua provided by RyzenAPI 
-- Game: AppID 2435210
addappid(2435210)
addappid(2435211, 1, "7b8516ec2264d532660b16bba1bb4685e151557f00d6b423b1ccab39c093f230")
