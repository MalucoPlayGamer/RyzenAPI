-- Lua provided by RyzenAPI
-- Game: addappid(2435210)

-- MAIN APPLICATION
addappid(2435210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435211, 1, "7b8516ec2264d532660b16bba1bb4685e151557f00d6b423b1ccab39c093f230")
