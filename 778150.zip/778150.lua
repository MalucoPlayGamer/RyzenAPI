-- Lua provided by RyzenAPI
-- Game: Crossroad

-- MAIN APPLICATION
addappid(778150)

-- MAIN APP DEPOTS / PACKAGES
addappid(778151, 1, "82ae3c8d8ce8f626a42ce826009b09425616793fbb006adf7fbe5d35de60f942")

