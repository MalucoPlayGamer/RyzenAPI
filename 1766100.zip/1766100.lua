-- Lua provided by RyzenAPI
-- Game: The Last Hero of Nostalgaia

-- MAIN APPLICATION
addappid(1766100)
addappid(2132750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766101, 1, "c240c1b2745b02faf40b44b09a7e9521cad742da85c3fa8153648375cfd01b35")
