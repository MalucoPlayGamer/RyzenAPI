-- Lua provided by RyzenAPI 
-- Game: Mirror's Edge™
addappid(17410)
addappid(17411, 1, "c33850de7b7ffdf3471a48d9ed25096128125048fc3cf3ad70917e07b868cb8d")
