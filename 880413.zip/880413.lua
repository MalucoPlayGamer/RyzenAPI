-- Lua provided by RyzenAPI
-- Game: 880413

-- MAIN APPLICATION
addappid(880413)
-- Game: addappid(880413)

-- MAIN APP DEPOTS / PACKAGES
addappid(880413,0,"90d2e91c8d3b0f5c8496ba9b45061134fbb7b190ecbdbee13022e09b187333ec")
addtoken(880413,"2334659296201558543")
