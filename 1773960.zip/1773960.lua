-- Lua provided by RyzenAPI
-- Game: Ark Mobius: Censored Edition - adult patch

-- MAIN APPLICATION
addappid(1773960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773960,0,"955479afe31def0baa71e23895bd5353dfc59f3483e9cbceab006bce19a578d9")
