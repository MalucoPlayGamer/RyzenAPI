-- Lua provided by RyzenAPI
-- Game: On Track

-- MAIN APPLICATION
addappid(2836290)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3082800)
