-- Lua provided by RyzenAPI
-- Game: On Track

-- MAIN APPLICATION
addappid(2836290)
