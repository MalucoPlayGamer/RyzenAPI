-- Lua provided by SkyAPI 
-- Game: AppID 2136740
addappid(2136740)
addappid(2136741, 1, "10758997e0c19eca0d1101fcdd45e4c9eddd5cf7a4c72c067a4ae1f7da2440f4")
