-- Lua provided by RyzenAPI
-- Game: Return of the Phantom

-- MAIN APPLICATION
addappid(1299710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1299711, 1, "28dd745d7064cb63f3c59a9310c92756a9830bf2781b099f55e8569bbf8458bb")

