-- Lua provided by RyzenAPI 
-- Game: AppID 1299710
addappid(1299710)
addappid(1299711, 1, "28dd745d7064cb63f3c59a9310c92756a9830bf2781b099f55e8569bbf8458bb")
