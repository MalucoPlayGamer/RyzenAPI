-- Lua provided by RyzenAPI
-- Game: addappid(1442500)

-- MAIN APPLICATION
addappid(1442500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442500,0,"6b64c11f0467b6bedb8ff13221594eb4f61e01cb19470ee43175f8c1f74fc57b")
