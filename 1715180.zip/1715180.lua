-- Lua provided by SkyAPI 
-- Game: AppID 1715180
addappid(1715180)
addappid(1715181, 1, "16753c602658b633f2e2ecf5e9d9def15fee49b9110b50d34e1364ad0e16f81c")
addappid(1715182, 1, "57a1d6b0c45e5737cb17702a280487fbd7db1be2f8e3c5d1d9d7531dc32f1b11")
