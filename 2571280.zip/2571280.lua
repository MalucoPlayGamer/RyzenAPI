-- Lua provided by RyzenAPI
-- Game: addappid(2571280)

-- MAIN APPLICATION
addappid(2571280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571281, 1, "663afc823576210b47be6e3c808323966e9118fc0e51be49f61bb4ab8f2e3d53")
