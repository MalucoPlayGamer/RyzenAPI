-- Lua provided by RyzenAPI
-- Game: Hide & Crab

-- MAIN APPLICATION
addappid(2007120)
addappid(2197070)
-- Game: addappid(2007120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2007121, 1, "c3db184bb63d1d7e0630835b3f920fe0543eb75cd98b49a875f1fe18c5cf0234")
