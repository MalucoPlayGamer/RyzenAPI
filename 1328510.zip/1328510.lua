-- Lua provided by RyzenAPI
-- Game: AppID 1328510

-- MAIN APPLICATION
addappid(1328510)
addappid(2361990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1328511, 1, "b7e28decf3079d09663b29527e4cdb9e90108e20ac15126f7975a26e5bcd0c72")

