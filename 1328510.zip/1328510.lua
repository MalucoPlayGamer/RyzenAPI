-- Lua provided by RyzenAPI
-- Game: AppID 1328510

-- MAIN APPLICATION
addappid(1328510)
-- Game: addappid(1328510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328511, 1, "b7e28decf3079d09663b29527e4cdb9e90108e20ac15126f7975a26e5bcd0c72")
