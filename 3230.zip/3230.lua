-- Lua provided by RyzenAPI
-- Game: Genesis Rising

-- MAIN APPLICATION
addappid(3230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231, 1, "1c7bac94cb21f5350764cc0fea38c35e7f9ae09fec374edbd2386fb132337707")
addappid(3232, 1, "490b7ca55fee79d10407b5b720b54da8f8c73b2a6579b1a3761d5332be3c0294")

