-- Lua provided by RyzenAPI
-- Game: Tony Hawk's™ Pro Skater™ 3 + 4

-- MAIN APPLICATION
addappid(2545710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545711, 1, "cc91db4546139b89ff7216df6c489b4c157da8515a88f2491921ae845b9dab5a")
addappid(2545712, 1, "8027343d1efbd17177d104a56462394d6507a9d68f348e96e365b9d9db954804")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3315210)
addappid(3529150)
addappid(3529160)
