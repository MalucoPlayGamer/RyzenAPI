-- Lua provided by RyzenAPI
-- Game: Farming Simulator 17

-- MAIN APPLICATION
addappid(447020)
addappid(570220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(447021, 1, "4bbd0156cf66a7b9dcb3559be8770b2fd08d5fb2ed552a8564d89540def11e23")
addappid(447022, 1, "c59cf326a6fe193d8c66935b13e002db3453579001dde0109e5e7e6f6da7d2b8")
addappid(535770, 0, "4211181a7794d83c5e84689a1b4291372babac7e630e24be957ba062478a9ea2")
addappid(535771, 0, "2d8bae2b6235d2ed65e0f0fb99bec5a8e8c94fb5f4a6139cf063b73ae5d5fb54")
addappid(605550, 0, "8b5ee2bc071e4b0ba0da0f2583efe4b654d23f28fa6fabdd5bff2afd598644e0")
addappid(635290, 0, "00ff372d3da175bfd669051453c3e0ce7bd21394df63420a590b87f429554fa3")
addappid(635330, 0, "96b74f342657057b257593ea33c16e784a36c8f7a8c1f876e90c982de0d80cc2")
