-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Verticalsim - KPVD - T. F. Green Airport XP

-- MAIN APPLICATION
addappid(1816664)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816664,0,"c288159f0e199b353ddead5f3606c92dd0c847fc6002e8502da5fb1b948354ad")
