-- Lua provided by RyzenAPI
-- Game: 227800

-- MAIN APPLICATION
addappid(227800)
-- Game: addappid(227800)

-- MAIN APP DEPOTS / PACKAGES
addappid(227801, 1, "337961325c79b03506fc76a02d0a8d782f3257f1a702b056cc171577f4c4acb6")
