-- Lua provided by RyzenAPI
-- Game: Crazy Caveman

-- MAIN APPLICATION
addappid(4522150)

-- MAIN APP DEPOTS / PACKAGES
addappid(4522151,0,"5c0c9f6ba9b86886039994e44cc16c03923579183b1a7dd7270b5bcfe6e8816b")

