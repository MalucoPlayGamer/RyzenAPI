-- Lua provided by RyzenAPI
-- Game: Crazy Caveman

-- MAIN APPLICATION
addappid(4522150)

-- MAIN APP DEPOTS / PACKAGES
addappid(4522151,0,"5c0c9f6ba9b86886039994e44cc16c03923579183b1a7dd7270b5bcfe6e8816b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
