-- Lua provided by RyzenAPI
-- Game: BETA: iVRy Driver for SteamVR DEMO (PSVR2 Lite Edition)

-- MAIN APPLICATION
addappid(2772740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772741, 1, "d87c8bb05aa5c73b6457e6a72310995906ba75f98f21fdc692ecfe4f82f159d9")
