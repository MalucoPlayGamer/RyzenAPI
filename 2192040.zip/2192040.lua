-- Lua provided by RyzenAPI
-- Game: 2192040

-- MAIN APPLICATION
addappid(2192040)
-- Game: addappid(2192040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192041, 1, "7b0bc220147afa2a6385fef86484d856dbbc511f2eddcafdad73ddd95e7d7ce1")
