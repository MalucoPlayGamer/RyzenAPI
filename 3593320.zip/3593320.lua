-- Lua provided by RyzenAPI
-- Game: Game: Crashlands 2 Soundtrack

-- MAIN APPLICATION
addappid(3593320)
-- Game: addappid(3593320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593321, 1, "f269062a16381157e8ae373ae1403169c9bcf17eeacd95af10c65d3a6660be97")
addappid(3593322, 1, "c87866f70266b56d29c3ce956843372caa5f1620cc544eb699cff6c9dea03ebd")
