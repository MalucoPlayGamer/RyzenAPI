-- Lua provided by RyzenAPI
-- Game: Shadowkin: Dominion of Darkness

-- MAIN APPLICATION
addappid(2731200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731201, 1, "9d49bf15c689716b39a32efcd8cdde600a834de91bb445f09b3dff4d3935ab1b")
