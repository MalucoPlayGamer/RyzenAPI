-- Lua provided by RyzenAPI
-- Game: addappid(937940)

-- MAIN APPLICATION
addappid(937940)

-- MAIN APP DEPOTS / PACKAGES
addappid(937941, 1, "03ecd98126fc8911dced33a8a6964bd770bf74824ac07077a79e07afd987f4de")
