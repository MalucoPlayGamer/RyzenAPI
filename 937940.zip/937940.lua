-- Lua provided by RyzenAPI
-- Game: Sea Dogs: City of Abandoned Ships

-- MAIN APPLICATION
addappid(937940)

-- MAIN APP DEPOTS / PACKAGES
addappid(937941, 1, "03ecd98126fc8911dced33a8a6964bd770bf74824ac07077a79e07afd987f4de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
