-- Lua provided by RyzenAPI
-- Game: Myth of Empires: Throne

-- MAIN APPLICATION
addappid(4510830)
