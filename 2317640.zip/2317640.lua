-- Lua provided by RyzenAPI
-- Game: JUMP KING QUEST

-- MAIN APPLICATION
addappid(2317640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317641, 1, "5d59bfdb823edffd726a9d9c35778a6f146d51963f262ded040f372f12cf8330")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4563920)
