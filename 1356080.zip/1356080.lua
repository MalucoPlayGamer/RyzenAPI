-- Lua provided by RyzenAPI
-- Game: addappid(1356080)

-- MAIN APPLICATION
addappid(1356080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356081, 1, "a57f5bd76a359e69d1c5fabc527a1888358216c3f4412ad7dee52d27fabb5d11")
