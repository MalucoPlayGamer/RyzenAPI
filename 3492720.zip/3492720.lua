-- Lua provided by RyzenAPI
-- Game: Stranded Souls

-- MAIN APPLICATION
addappid(3492720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3492721, 1, "38c92fe324bdfedb63ccdc8dcefb843287aa1b39b0ac3f4ee833537dd015c41d")

