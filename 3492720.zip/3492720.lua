-- Lua provided by RyzenAPI
-- Game: Game: Stranded Souls

-- MAIN APPLICATION
addappid(3492720)
-- Game: addappid(3492720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3492721, 1, "38c92fe324bdfedb63ccdc8dcefb843287aa1b39b0ac3f4ee833537dd015c41d")
