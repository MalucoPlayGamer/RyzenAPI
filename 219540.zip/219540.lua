-- Lua provided by RyzenAPI
-- Game: Arma 2: Operation Arrowhead Beta (Obsolete)

-- MAIN APPLICATION
addappid(219540)

-- MAIN APP DEPOTS / PACKAGES
addappid(219541, 1, "4da34b17349cc385c90bc420194e78e514d39b93f9d5b182ef03ef0b9c356901")
