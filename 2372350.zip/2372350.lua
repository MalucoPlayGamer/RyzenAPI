-- Lua provided by RyzenAPI
-- Game: Bahamut2-Come on,Fight

-- MAIN APPLICATION
addappid(2372350)
addappid(2650420)
-- Game: addappid(2372350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372351, 1, "de337a8343356025d39d48862c82ef03164344c8168ee60359f9211c6bec0c1d")
addappid(2372352, 1, "98cca52b818d1b51fa88cb3d6e64eee70c03b835f4d31018993790f5c60e603a")
addappid(2372353, 1, "78642fcc7c606bf6ed5c47a0fe8f36344c476ac872dcae1c3bf6a2457eaba3a0")
