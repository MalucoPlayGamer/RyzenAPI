-- Lua provided by RyzenAPI
-- Game: Battlewake

-- MAIN APPLICATION
addappid(814400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(814401, 1, "8dccfb8ee65335ccb4e45e4edcc4930652b04408dde029d2fc033af0d9d67073")

