-- Lua provided by RyzenAPI
-- Game: AppID 814400

-- MAIN APPLICATION
addappid(814400)
-- Game: addappid(814400)

-- MAIN APP DEPOTS / PACKAGES
addappid(814401, 1, "8dccfb8ee65335ccb4e45e4edcc4930652b04408dde029d2fc033af0d9d67073")
