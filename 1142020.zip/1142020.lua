-- Lua provided by RyzenAPI
-- Game: Parcel Mania

-- MAIN APPLICATION
addappid(1142020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142021, 1, "2164264aa164c8c6fbecdb0b248fe852bfc8a2163fea57762e7ad173722f49a5")
addappid(1142023, 1, "b02275d060e28d8e0efafc1ec9ff0702dfca14be7d28aa7209d9b21605bc3693")
addappid(1142024, 1, "1bfab79c6d6710b17aaa057209b1e6a676ad02491d30ce04b7fcdf878eb451f6")
