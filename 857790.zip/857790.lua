-- Lua provided by RyzenAPI
-- Game: Gravitycers

-- MAIN APPLICATION
addappid(857790)

-- MAIN APP DEPOTS / PACKAGES
addappid(857791, 1, "064e27a647a8c9ea44c07bc467e74fce455a2f1522fd1d49d28d79cbcc47ab04")
