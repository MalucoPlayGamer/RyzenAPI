-- Lua provided by RyzenAPI 
-- Game: AppID 857790
addappid(857790)
addappid(857791, 1, "064e27a647a8c9ea44c07bc467e74fce455a2f1522fd1d49d28d79cbcc47ab04")
