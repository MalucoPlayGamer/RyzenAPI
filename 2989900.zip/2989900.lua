-- Lua provided by RyzenAPI
-- Game: 2989900

-- MAIN APPLICATION
addappid(2989900)
-- Game: addappid(2989900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989901, 1, "4bf9164eb9754b9a9622330e53eb2a5b346c812fc632c69eaaca5d816e6c1805")
