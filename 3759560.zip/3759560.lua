-- Lua provided by RyzenAPI
-- Game: 3759560

-- MAIN APPLICATION
addappid(3759560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3763990,0,"f0c9d78a04c8579be7dc8ded1c200c2fd8f165a65402a2ecda8f6ee418987c4e")
addappid(3763991,0,"ac6b45d0ace36bd5fa06585952cb5c9ad7593d187dc41cec532e452132d2abf4")

