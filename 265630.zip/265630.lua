-- Lua provided by RyzenAPI
-- Game: Fistful of Frags

-- MAIN APPLICATION
addappid(265630)
addappid(1965120)

-- MAIN APP DEPOTS / PACKAGES
addappid(265631, 1, "d5929b331956ac73c8670705f40aa2938e7f787a38c045d7de53cb07e27132cf")
addappid(265632, 1, "588c298f865b9327928c6171fbc24213d4dd9c5270e29fe87c40029d69cf7a9c")
addappid(265633, 1, "1e1a56c4ec2835530fcfb334de733ccebefb092e47c80951ec34844dfd491e9f")
addappid(265634, 1, "82d76800f06c223448e48d218fc340a356d08e18d38eb8852f5a15b1700943b4")
addappid(265635, 1, "3b1ec85b0c8551667c1f459b43e53e32b1b5cc0c55365b8e57e742074912eb23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
