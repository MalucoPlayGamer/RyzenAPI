-- Lua provided by RyzenAPI
-- Game: Game: Voidtrain

-- MAIN APPLICATION
addappid(1159690)
-- Game: addappid(1159690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159691, 1, "399feb028d40b4631439972a222c8dfcfc7f5fc3672f5671782a08a75614af78")
