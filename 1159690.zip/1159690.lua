-- Lua provided by RyzenAPI
-- Game: Voidtrain

-- MAIN APPLICATION
addappid(1159690)
addappid(2348780)
addappid(4108450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1159691, 1, "399feb028d40b4631439972a222c8dfcfc7f5fc3672f5671782a08a75614af78")

