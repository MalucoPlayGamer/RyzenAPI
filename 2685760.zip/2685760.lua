-- Lua provided by RyzenAPI
-- Game: Game: Team Disorder Special Edition

-- MAIN APPLICATION
addappid(2685760)
-- Game: addappid(2685760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685761, 1, "7e80ea39fd720e7cc3b99b387dbaad5d3e90b426759c63fd0009b0d5d5395e50")
