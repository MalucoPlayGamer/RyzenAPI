-- Lua provided by RyzenAPI
-- Game: Extreme Escape

-- MAIN APPLICATION
addappid(1316740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316741, 1, "217fd2fad6c55e8d8e799a73e3d2d988bffb070d8f117226bd26a5502234b82a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
