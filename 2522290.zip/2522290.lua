-- Lua provided by RyzenAPI
-- Game: 2522290

-- MAIN APPLICATION
addappid(2522290)
-- Game: addappid(2522290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522291, 1, "a496249059dba8191d316bbd3d280bbc345b67bbe9486122c39c243c66b41d05")
