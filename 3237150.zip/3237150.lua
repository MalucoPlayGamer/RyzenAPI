-- Lua provided by RyzenAPI
-- Game: One Iced Latte With Your Breast Milk, Please! ~ Demo

-- MAIN APPLICATION
addappid(3237150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3237151, 1, "f8deed0310d1a7ed3639298907e21715d4edd3687eead0efbab77532a425c37e")

