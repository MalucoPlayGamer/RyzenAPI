-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(973370)
addappid(973371)

-- MAIN APP DEPOTS / PACKAGES
addappid(973370,0,"2a03b82f3ab1fd81e49dfb16380f4bf7768350831a30a7ea422e1ce54bdd6f10")
