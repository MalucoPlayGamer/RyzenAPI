-- Lua provided by RyzenAPI
-- Game: SPACE BLASTER 8 BIT

-- MAIN APPLICATION
addappid(857110)

-- MAIN APP DEPOTS / PACKAGES
addappid(857111,0,"ba3abc28ccb4dee8238cde127db4cecf084ea7c02e8567e31f57a70822760db9")

