-- Lua provided by RyzenAPI
-- Game: AppID 2059790

-- MAIN APPLICATION
addappid(2059790)
addappid(2103260)
-- Game: addappid(2059790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059791, 1, "682b0b49de2eb176cfc77be50e0cd9f60aa3f1ad39fbef2cfb16ad9f6b034490")
