-- Lua provided by RyzenAPI 
-- Game: 俺が私に変わった日…～Becoming a She～
addappid(2154960)
addappid(2154961, 1, "bc060331d3cb0da542d80c372bbc3e53c2bea78519b6ec21c1f0964735379bec")
