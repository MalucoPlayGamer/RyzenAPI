-- Lua provided by RyzenAPI
-- Game: addappid(735433)

-- MAIN APPLICATION
addappid(735433)

-- MAIN APP DEPOTS / PACKAGES
addappid(735433,0,"d7e825f22e43dc161f08121f2b8f73398e0ac7f99768d58f5d94e9f85a2befd7")
