-- Lua provided by RyzenAPI
-- Game: AppID 2348590

-- MAIN APPLICATION
addappid(2348590)
-- Game: addappid(2348590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348591, 1, "28def539c28b93a29e90e41d1e83993840db8d70da037c2ee35fb515270615f3")
