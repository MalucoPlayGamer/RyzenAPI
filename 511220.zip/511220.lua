-- Lua provided by RyzenAPI
-- Game: Long Gone Days Soundtrack

-- MAIN APPLICATION
addappid(511220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659620,0,"18aa4cef5764e6fcb11bfa24d803f892f4f84737241bc3c17dca79ef871a6de0")
addappid(2659621,0,"779299fcba57a064e50b41db9564922d09e8a3dd86331460b96d9ac5b2cabda8")

