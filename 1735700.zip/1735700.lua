-- Lua provided by RyzenAPI
-- Game: Back to the Dawn

-- MAIN APPLICATION
addappid(1735700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735701, 1, "f2bbd7e59cb9050efe964f132c6edcb6059ffefaa0995f9b658989c95a85d7df")
