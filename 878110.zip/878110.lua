-- Lua provided by RyzenAPI
-- Game: Fuel Renegades

-- MAIN APPLICATION
addappid(878110)

-- MAIN APP DEPOTS / PACKAGES
addappid(878111, 1, "c8a04491bf9d246bb77adf490ad92f3d774609ef53e96ce4f932c01f28d0c2d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
