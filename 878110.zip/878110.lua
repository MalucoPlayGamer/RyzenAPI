-- Lua provided by RyzenAPI
-- Game: 878110

-- MAIN APPLICATION
addappid(878110)
-- Game: addappid(878110)

-- MAIN APP DEPOTS / PACKAGES
addappid(878111, 1, "c8a04491bf9d246bb77adf490ad92f3d774609ef53e96ce4f932c01f28d0c2d2")
