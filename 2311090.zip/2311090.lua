-- Lua provided by RyzenAPI
-- Game: addappid(2311090)

-- MAIN APPLICATION
addappid(2311090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311091, 1, "54b61c1b7694f94bdf6e07e859a1ba8cb68a21ed7d126d6e3cd2f09eeec1aeca")
