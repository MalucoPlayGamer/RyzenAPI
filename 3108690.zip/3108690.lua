-- Lua provided by RyzenAPI 
-- Game: Descendant Demo
addappid(3108690)
addappid(3108691, 1, "7e1dac7f3fb07602f3ab087b715d148c47c6668aebc51373db78fe720b3a488a")
