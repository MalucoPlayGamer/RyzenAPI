-- Lua provided by RyzenAPI 
-- Game: The Lust City 2
addappid(2832400)
addappid(2832401, 1, "d64ed9a43acb8d5e1b18517218ec3d61fce2f13ee7da00d4b2a546bd4298e3d5")
