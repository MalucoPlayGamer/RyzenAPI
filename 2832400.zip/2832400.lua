-- Lua provided by RyzenAPI
-- Game: 2832400

-- MAIN APPLICATION
addappid(2832400)
-- Game: addappid(2832400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832401, 1, "d64ed9a43acb8d5e1b18517218ec3d61fce2f13ee7da00d4b2a546bd4298e3d5")
