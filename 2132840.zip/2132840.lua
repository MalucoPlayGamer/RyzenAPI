-- Lua provided by RyzenAPI
-- Game: addappid(2132840)

-- MAIN APPLICATION
addappid(2132840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132841, 1, "46f17dc0c8e9ad1bf990969eb7ebbb8497bab869abf5bc1fd4921718edf6e4c4")
