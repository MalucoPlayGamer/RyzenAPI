-- Lua provided by RyzenAPI
-- Game: Desires of the Amazons

-- MAIN APPLICATION
addappid(2359030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359031, 1, "5cee1208172ae7afd80af34d6c17b42cf1d83315f93271c31af6d61cc3fbaaa4")

