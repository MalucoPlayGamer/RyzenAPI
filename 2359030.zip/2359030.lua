-- Lua provided by RyzenAPI
-- Game: Desires of the Amazons

-- MAIN APPLICATION
addappid(2359030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359031, 1, "5cee1208172ae7afd80af34d6c17b42cf1d83315f93271c31af6d61cc3fbaaa4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
