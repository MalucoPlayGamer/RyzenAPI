-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition - Remastered

-- MAIN APPLICATION
addappid(258370)
addappid(294990)
addappid(369770)
addappid(369771) -- Rocksmith 2014 - Classic Country Song Pack
addappid(369823) -- Rocksmith 2014 - The Doors Song Pack II
addappid(390369) -- Rocksmith 2014 - Kiss Song Pack II
addappid(390389)
addappid(390399) -- Rocksmith 2014 - Skillet Song Pack
addappid(390435) -- Rocksmith 2014 - Megadeth Song Pack II
addappid(390445) -- Rocksmith 2014 - The Offspring Song Pack II
addappid(436571) -- Rocksmith 2014 - My Chemical Romance Song Pack II
addappid(436578) -- Rocksmith 2014 - Women Who Rock Song Pack
addappid(436607) -- Rocksmith 2014 - 80s Mix Song Pack
addappid(436647)
addappid(436665)
addappid(436666)
addappid(436667)
addappid(436668) -- Rocksmith 2014 - 60s Mix Song Pack
addappid(436669)
addappid(492940)
addappid(492941)
addappid(492942)
addappid(492943)
addappid(492944) -- Rocksmith 2014 - Pixies Song Pack
addappid(492945)
addappid(492946)
addappid(492947)
addappid(492948)
addappid(492949) -- Rocksmith 2014 - Variety Song Pack III
addappid(492950)
addappid(492951)
addappid(492952)
addappid(492953)
addappid(492954) -- Rocksmith 2014 - Bad Religion Song Pack
addappid(492955)
addappid(492956)
addappid(492957) -- Rocksmith 2014 - 2010s Mix Song Pack
addappid(492958)
addappid(492959)
addappid(492960)
addappid(492961)
addappid(492962)
addappid(492963) -- Rocksmith 2014 - Rush Song Pack II
addappid(492964)
addappid(492965)
addappid(492966)
addappid(492967) -- Rocksmith 2014 - 70s Mix Song Pack
addappid(492968)
addappid(492969)
addappid(492970)
addappid(492971) -- Rocksmith 2014 - Staind Song Pack
addappid(492972)
addappid(492973)
addappid(492974)
addappid(492975)
addappid(492976) -- Rocksmith 2014 - Variety Song Pack IV
addappid(492977)
addappid(492978)
addappid(492979)
addappid(492980)
addappid(492981) -- Rocksmith 2014 - Misfits Song Pack
addappid(492982)
addappid(492983)
addappid(492984)
addappid(492985) -- Rocksmith 2014 - Dream Theater Song Pack
addappid(492986)
addappid(492987)
addappid(492988)
addappid(492989)
addappid(509630)
addappid(509631)
addappid(509632) -- Rocksmith 2014 - Anniversary Song Pack
addappid(509633)
addappid(509634)
addappid(509635)
addappid(509636) -- Rocksmith 2014 Edition - Remastered - 2000s Mix Song Pack II
addappid(509637)
addappid(509638)
addappid(509639)
addappid(509640)
addappid(509641)
addappid(509642) -- Rocksmith 2014 Edition - Remastered - Yes Song Pack
addappid(509643)
addappid(509644)
addappid(509645)
addappid(509646)
addappid(509647) -- Rocksmith 2014 Edition - Remastered - Zombie Song Pack
addappid(509648)
addappid(509649)
addappid(509650)
addappid(509651)
addappid(509652) -- Rocksmith 2014 Edition - Remastered - Variety Song Pack V
addappid(509653)
addappid(509654)
addappid(509655)
addappid(509656)
addappid(509657)
addappid(509658) -- Rocksmith 2014 Edition - Remastered - UBI30 1986 Song Pack
addappid(509659)
addappid(509660)
addappid(509661)
addappid(509662)
addappid(509663)
addappid(509664) -- Rocksmith 2014 Edition - Remastered - Stevie Ray Vaughan  Double Trouble Song Pack
addappid(509665)
addappid(509666)
addappid(509667)
addappid(509668) -- Rocksmith 2014 Edition - Remastered - 2010s Mix Song Pack II
addappid(509669)
addappid(509670)
addappid(509671)
addappid(509672)
addappid(509673) -- Rocksmith 2014 Edition - Remastered - Third Eye Blind Song Pack
addappid(509674)
addappid(509675)
addappid(509676)
addappid(509677)
addappid(509678) -- Rocksmith 2014 Edition - Remastered - Variety Song Pack VI
addappid(509679)
addappid(509680)
addappid(509681)
addappid(509682) -- Rocksmith 2014 Edition - Remastered - Creedence Clearwater Revival Song Pack
addappid(509683)
addappid(509684)
addappid(509685)
addappid(509686)
addappid(509687)
addappid(509688) -- Rocksmith 2014 Edition - Remastered - Green Day Song Pack II
addappid(509689)
addappid(509690)
addappid(509691)
addappid(509692)
addappid(509693)
addappid(509694) -- Rocksmith 2014 Edition - Remastered - U2 Song Pack
addappid(509695)
addappid(509696)
addappid(509697)
addappid(509698) -- Rocksmith 2014 Edition  Remastered  60s Mix Song Pack II
addappid(509699)
addappid(509700)
addappid(509701)
addappid(509702)
addappid(509703)
addappid(509704) -- Rocksmith 2014 Edition  Remastered  blink-182 Song Pack II
addappid(509705)
addappid(509706)
addappid(509707)
addappid(509708)
addappid(509709) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack VII
addappid(509710)
addappid(509711)
addappid(509712)
addappid(509713) -- Rocksmith 2014 Edition  Remastered  Evanescence Song Pack
addappid(509714)
addappid(509715)
addappid(509716)
addappid(509717) -- Rocksmith 2014 Edition  Remastered  80s Mix Song Pack II
addappid(509718)
addappid(509719)
addappid(509720)
addappid(509721)
addappid(509722)
addappid(509723)
addappid(509724) -- Rocksmith 2014 Edition  Remastered  Coldplay Song Pack
addappid(509725)
addappid(509726)
addappid(509727)
addappid(509728) -- Rocksmith 2014 Edition  Remastered  Beastie Boys Song Pack
addappid(509729)
addappid(509730)
addappid(509731)
addappid(509732)
addappid(509733) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack VIII
addappid(509734)
addappid(509735)
addappid(509736)
addappid(509737)
addappid(509738)
addappid(509739) -- Rocksmith 2014 Edition  Remastered  Avril Lavigne Song Pack
addappid(509740)
addappid(509741)
addappid(509742)
addappid(509743) -- Rocksmith 2014 Edition  Remastered  90s Mix Song Pack II
addappid(509744)
addappid(509745)
addappid(509746)
addappid(509747)
addappid(509748)
addappid(509749) -- Rocksmith 2014 Edition  Remastered  Skid Row Song Pack
addappid(590170)
addappid(590171)
addappid(590172)
addappid(590173)
addappid(590174)
addappid(590175) -- Rocksmith 2014 Edition  Remastered  Skater Rock Song Pack
addappid(590184)
addappid(590185)
addappid(590186)
addappid(590187)
addappid(590188)
addappid(590189) -- Rocksmith 2014 Edition  Remastered  Pearl Jam Song Pack II
addappid(590190)
addappid(590191)
addappid(590192)
addappid(590193)
addappid(590194) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack IX
addappid(590195)
addappid(590196)
addappid(590197)
addappid(590198)
addappid(590199)
addappid(590200) -- Rocksmith 2014 Edition  Remastered  Bob Marley  The Wailers Song Pack
addappid(590201) -- Rocksmith 2014 Edition  Remastered  Royal Blood Song Pack
addappid(590202)
addappid(590203)
addappid(590204)
addappid(590205) -- Rocksmith 2014 Edition  Remastered  Mix Tape Song Pack
addappid(590206)
addappid(590207)
addappid(590208)
addappid(590209)
addappid(590210)
addappid(590211) -- Rocksmith 2014 Edition  Remastered  Sheryl Crow Song Pack
addappid(590212)
addappid(590213)
addappid(590214)
addappid(590215) -- Rocksmith 2014 Edition  Remastered  Grateful Dead Song Pack
addappid(590216)
addappid(590217)
addappid(590218)
addappid(590219)
addappid(590220)
addappid(590221) -- Rocksmith 2014 Edition  Remastered  80s Mix Song Pack III
addappid(590222)
addappid(590223)
addappid(590224)
addappid(590225) -- Rocksmith 2014 Edition  Remastered  New Found Glory Song Pack
addappid(590226)
addappid(590227)
addappid(590228)
addappid(590229) -- Rocksmith 2014 Edition  Remastered  Surf Rock Song Pack II
addappid(590230)
addappid(590231)
addappid(590232)
addappid(590233)
addappid(590234) -- Rocksmith 2014 Edition  Remastered  Live Song Pack
addappid(590235)
addappid(590236)
addappid(590237)
addappid(590238)
addappid(590239)
addappid(590240) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack X
addappid(590241)
addappid(590242)
addappid(590243)
addappid(590244)
addappid(590245) -- Rocksmith 2014 Edition  Remastered  Alabama Shakes Song Pack
addappid(590246)
addappid(590247)
addappid(590248)
addappid(590249)
addappid(637690) -- Rocksmith 2014 Edition  Remastered  70s Mix Song Pack II
addappid(637691)
addappid(637692)
addappid(637693)
addappid(637694) -- Rocksmith 2014 Edition  Remastered  The Strokes Song Pack II
addappid(637695)
addappid(637696)
addappid(637697)
addappid(637698)
addappid(637699) -- Rocksmith 2014 Edition  Remastered  90s Mix Song Pack III
addappid(637700)
addappid(637701)
addappid(637702)
addappid(637703) -- Rocksmith 2014 Edition  Remastered  Marilyn Manson Song Pack
addappid(637704)
addappid(637705)
addappid(637706)
addappid(637707) -- Rocksmith 2014 Edition  Remastered  The Monkees Song Pack
addappid(637708)
addappid(637709)
addappid(637710)
addappid(637711) -- Rocksmith 2014 Edition  Remastered  2010s Mix Song Pack III
addappid(637712)
addappid(637713)
addappid(637714)
addappid(637715) -- Rocksmith 2014 Edition  Remastered  Muddy Waters Song Pack
addappid(637716)
addappid(637717)
addappid(637718)
addappid(637719)
addappid(637720) -- Rocksmith 2014 Edition  Remastered  Airbourne Song Pack
addappid(637721)
addappid(637722)
addappid(637723)
addappid(637724) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XI
addappid(637725)
addappid(637726)
addappid(637727)
addappid(637728)
addappid(637729) -- Rocksmith 2014 Edition  Remastered  3 Doors Down Song Pack II
addappid(637730)
addappid(637731)
addappid(637732)
addappid(637733)
addappid(637734)
addappid(637735) -- Rocksmith 2014 Edition  Remastered  80s Mix Song Pack IV
addappid(637736)
addappid(637737)
addappid(637738)
addappid(637739) -- Rocksmith 2014 Edition  Remastered  Thrice Song Pack
addappid(637740)
addappid(637741)
addappid(637742)
addappid(637743) -- Rocksmith 2014 Edition  Remastered  Rockin Covers Song Pack
addappid(637744)
addappid(637745)
addappid(637746)
addappid(637747)
addappid(637748) -- Rocksmith 2014 Edition  Remastered  Four Tops Song Pack
addappid(637749)
addappid(637750)
addappid(637751)
addappid(637752)
addappid(637753) -- Rocksmith 2014 Edition  Remastered  2000s Mix Song Pack III
addappid(637754)
addappid(637755)
addappid(637756)
addappid(637757) -- Rocksmith 2014 Edition  Remastered  Bachman-Turner Overdrive Song Pack
addappid(637758)
addappid(637759)
addappid(637760)
addappid(637761) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XII
addappid(637762)
addappid(637763)
addappid(637764)
addappid(637765)
addappid(637766) -- Rocksmith 2014 Edition  Remastered  Amon Amarth Song Pack
addappid(637767)
addappid(637768)
addappid(637769)
addappid(637770)
addappid(637771)
addappid(637772) -- Rocksmith 2014 Edition  Remastered  NOFX Song Pack
addappid(637773)
addappid(637774)
addappid(637775)
addappid(637776)
addappid(637777) -- Rocksmith 2014 Edition  Remastered  The Pretenders Song Pack
addappid(637778)
addappid(637779)
addappid(637780)
addappid(637781)
addappid(637782)
addappid(637783)
addappid(637784)
addappid(637785)
addappid(637786)
addappid(637787) -- Rocksmith 2014 Edition  Remastered  Trans-Siberian Orchestra Song Pack
addappid(637788)
addappid(637789)
addappid(637790)
addappid(637791)
addappid(637792)
addappid(637793) -- Rocksmith 2014 Edition  Remastered  Steve Miller Band Song Pack
addappid(637794)
addappid(637795)
addappid(637796)
addappid(637797)
addappid(637798)
addappid(637799) -- Rocksmith 2014 Edition  Remastered  Alice in Chains Song Pack II
addappid(637800)
addappid(637801)
addappid(637802)
addappid(637803)
addappid(637804)
addappid(637805) -- Rocksmith 2014 Edition  Remastered  Johnny Cash Song Pack (I-II)
addappid(637806) -- Rocksmith 2014 Edition  Remastered  Johnny Cash Song Pack I
addappid(637807)
addappid(637808)
addappid(637809)
addappid(637810)
addappid(637811)
addappid(637812) -- Rocksmith 2014 Edition  Remastered  Johnny Cash Song Pack II
addappid(637813)
addappid(637814)
addappid(637815)
addappid(637816)
addappid(637817)
addappid(637818) -- Rocksmith 2014 Edition  Remastered  Paramore Song Pack
addappid(637819)
addappid(637820)
addappid(637821)
addappid(637822)
addappid(637823)
addappid(637824)
addappid(637825) -- Rocksmith 2014 Edition  Remastered  Green Day Song Pack III
addappid(637826)
addappid(637827)
addappid(637828)
addappid(637829)
addappid(637830)
addappid(637831) -- Rocksmith 2014 Edition  Remastered  Mumford  Sons Song Pack
addappid(637832)
addappid(637833)
addappid(637834)
addappid(637835) -- Rocksmith 2014 Edition  Remastered  70s Mix Song Pack III
addappid(637836)
addappid(637837)
addappid(637838)
addappid(637839) -- Rocksmith 2014 Edition  Remastered  Lady Gaga Song Pack
addappid(637840)
addappid(637841)
addappid(637842)
addappid(637843)
addappid(637844) -- Rocksmith 2014 Edition  Remastered  Trivium Song Pack
addappid(637845)
addappid(637846)
addappid(637847)
addappid(637848) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XIII
addappid(637849)
addappid(753740)
addappid(753741)
addappid(753742)
addappid(753743)
addappid(753744) -- Rocksmith 2014 Edition  Remastered  60s Mix Song Pack III
addappid(753745)
addappid(753746)
addappid(753747)
addappid(753748) -- Rocksmith 2014 Edition  Remastered  Shania Twain Song Pack
addappid(753749)
addappid(753750)
addappid(753751)
addappid(753752) -- Rocksmith 2014 Edition  Remastered  Kaiser Chiefs Song Pack
addappid(753753)
addappid(753754)
addappid(753755)
addappid(753756)
addappid(753757)
addappid(753758)
addappid(753759)
addappid(753760) -- Rocksmith 2014 Edition  Remastered  The Cardigans Song Pack
addappid(753761)
addappid(753762)
addappid(753763)
addappid(753764) -- Rocksmith 2014 Edition  Remastered  Dethklok Song Pack II
addappid(753765)
addappid(753766)
addappid(753767)
addappid(753768)
addappid(753769)
addappid(753770)
addappid(753771)
addappid(753772)
addappid(753773) -- Rocksmith 2014 Edition  Remastered  Stereophonics Song Pack
addappid(753774)
addappid(753775)
addappid(753776)
addappid(753777) -- Rocksmith 2014 Edition  Remastered  90s Mix Song Pack IV
addappid(753778)
addappid(753779)
addappid(753780)
addappid(753781) -- Rocksmith 2014 Edition  Remastered  KT Tunstall Song Pack
addappid(753782)
addappid(753783)
addappid(753784)
addappid(753785) -- Rocksmith 2014 Edition  Remastered  80s Mix Song Pack V
addappid(753786)
addappid(753787)
addappid(753788)
addappid(753789) -- Rocksmith 2014 Edition  Remastered  Interpol Song Pack
addappid(753790)
addappid(753791)
addappid(753792)
addappid(753793)
addappid(753794) -- Rocksmith 2014 Edition  Remastered  Metal Mix Song Pack
addappid(753795)
addappid(753796)
addappid(753797)
addappid(753798) -- Rocksmith 2014 Edition  Remastered  Norah Jones Song Pack
addappid(753799)
addappid(753800)
addappid(753801)
addappid(753802) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XV
addappid(753803)
addappid(753804)
addappid(753805)
addappid(753806)
addappid(753807) -- Rocksmith 2014 Edition  Remastered  2000s Mix Song Pack IV
addappid(753808)
addappid(753809)
addappid(753810)
addappid(753811) -- Rocksmith 2014 Edition  Remastered  Radiohead Song Pack II
addappid(753812)
addappid(753813)
addappid(753814)
addappid(753815) -- Rocksmith 2014 Edition  Remastered  Joan Jett Song Pack
addappid(753816)
addappid(753817)
addappid(753818)
addappid(753819) -- Rocksmith 2014 Edition  Remastered  70s Mix Song Pack IV
addappid(753820)
addappid(753821)
addappid(753822)
addappid(753823) -- Rocksmith 2014 Edition  Remastered  Run-D.M.C. Song Pack
addappid(753824)
addappid(753825)
addappid(753826)
addappid(753827) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XVI
addappid(753828)
addappid(753829)
addappid(753830)
addappid(753831)
addappid(753832) -- Rocksmith 2014 Edition  Remastered  Joni Mitchell Song Pack
addappid(753833)
addappid(753834)
addappid(753835)
addappid(753836)
addappid(753842) -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet Song Pack
addappid(753843)
addappid(753844)
addappid(753845)
addappid(753846) -- Rocksmith 2014 Edition  Remastered  Blues Song Pack II
addappid(753847)
addappid(753848)
addappid(753849)
addappid(753850) -- Rocksmith 2014 Edition  Remastered  Silverstein Song Pack
addappid(753851)
addappid(753852)
addappid(753853)
addappid(753854)
addappid(753855) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XVII
addappid(753856)
addappid(753857)
addappid(753858)
addappid(753859)
addappid(753860) -- Rocksmith 2014 Edition  Remastered  Kelly Clarkson Song Pack
addappid(753861)
addappid(753862)
addappid(753863)
addappid(753864) -- Rocksmith 2014 Edition  Remastered  90s Mix Song Pack V
addappid(753865)
addappid(753866)
addappid(753867)
addappid(753868) -- Rocksmith 2014 Edition  Remastered  Stone Sour Song Pack
addappid(753869)
addappid(753870)
addappid(753871)
addappid(753872) -- Rocksmith 2014 Edition  Remastered  2010s Mix Song Pack V
addappid(753873)
addappid(753874)
addappid(753875)
addappid(753876) -- Rocksmith 2014 Edition  Remastered  Joy Division Song Pack
addappid(753877)
addappid(753878)
addappid(753879)
addappid(753880) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XVIII
addappid(753881)
addappid(753882)
addappid(753883)
addappid(753884) -- Rocksmith 2014 Edition  Remastered  Brad Paisley Song Pack
addappid(753885)
addappid(753886)
addappid(753887)
addappid(753888) -- Rocksmith 2014 Edition  Remastered  80s Mix Song Pack VI
addappid(753889)
addappid(753890)
addappid(753891)
addappid(753892) -- Rocksmith 2014 Edition  Remastered  Ghost Song Pack
addappid(753893)
addappid(753894)
addappid(753895)
addappid(753896)
addappid(899781) -- Rocksmith 2014 Edition  Remastered  Queen Song Pack II
addappid(899782)
addappid(899783)
addappid(899784)
addappid(899785)
addappid(899786) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XIX
addappid(899787)
addappid(899790)
addappid(899791) -- Rocksmith 2014 Edition  Remastered  Christmas Classics Song Pack
addappid(899792)
addappid(899793)
addappid(899794)
addappid(899795)
addappid(899796) -- Rocksmith 2014 Edition  Remastered  Jimmy Eat World Song Pack
addappid(899797)
addappid(899798)
addappid(899799)
addappid(899800) -- Rocksmith 2014 Edition  Remastered  Alice Cooper Song Pack
addappid(899801)
addappid(899802)
addappid(899803)
addappid(899804) -- Rocksmith 2014 Edition  Remastered  Five Finger Death Punch Song Pack
addappid(899805)
addappid(899806)
addappid(899807)
addappid(899808) -- Rocksmith 2014 Edition  Remastered  The Rolling Stones Song Pack
addappid(899809)
addappid(899810)
addappid(899811)
addappid(899812)
addappid(899813) -- Rocksmith 2014 Edition  Remastered  Chuck Berry Song Pack
addappid(899814)
addappid(899815)
addappid(899816)
addappid(899817) -- Rocksmith 2014 Edition  Remastered  Paramore Song Pack II
addappid(899818)
addappid(899819)
addappid(899820)
addappid(899821) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XX
addappid(899822)
addappid(899823)
addappid(899824)
addappid(899825)
addappid(899826) -- Rocksmith 2014 Edition  Remastered  Queen Song Pack III
addappid(899827)
addappid(899828)
addappid(899829)
addappid(899830) -- Rocksmith 2014 Edition  Remastered  90s Mix Song Pack VI
addappid(899831)
addappid(899832)
addappid(899833)
addappid(899834) -- Rocksmith 2014 Edition  Remastered  Sabaton Song Pack
addappid(899835)
addappid(899836)
addappid(899837)
addappid(899838) -- Rocksmith 2014 Edition  Remastered  2000s Mix Song Pack V
addappid(899839)
addappid(899840)
addappid(899841)
addappid(899842) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XXI
addappid(899843)
addappid(899844)
addappid(899845)
addappid(899846)
addappid(899847) -- Rocksmith 2014 Edition  Remastered  Heart Song Pack
addappid(899848)
addappid(899849)
addappid(899850)
addappid(899851) -- Rocksmith 2014 Edition  Remastered  Night Ranger Song Pack
addappid(899852)
addappid(899853)
addappid(899854)
addappid(899855) -- Rocksmith 2014 Edition  Remastered  70s Mix Song Pack V
addappid(899856)
addappid(899857)
addappid(899858)
addappid(899859)
addappid(899860)
addappid(899861)
addappid(899862)
addappid(899863) -- Rocksmith 2014 Edition  Remastered  Roxette Song Pack
addappid(899864)
addappid(899865)
addappid(899866)
addappid(899867) -- Rocksmith 2014 Edition  Remastered  Cat Stevens Song Pack
addappid(899868)
addappid(899869)
addappid(899870)
addappid(899871) -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XXII
addappid(899872)
addappid(899873)
addappid(899874)
addappid(899875)
addappid(899876) -- Rocksmith 2014 Edition  Remastered  2000s Mix Song Pack VI
addappid(899877)
addappid(899878)
addappid(899879)
addappid(899880) -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet Song Pack II
addappid(899881)
addappid(899882)
addappid(899883)
addappid(899884) -- Rocksmith 2014 Edition  Remastered  Cyndi Lauper Song Pack
addappid(899885)
addappid(899886)
addappid(899887)
addappid(899888) -- Rocksmith 2014 Edition  Remastered  P.O.D. Song Pack
addappid(899889)
addappid(899890)
addappid(899891)
addappid(899892)
addappid(899896) -- Rocksmith 2014 Edition  Remastered  5 Seconds of Summer Song Pack
addappid(899897)
addappid(899898)
addappid(899899)
addappid(899900)
addappid(1089160) -- Rocksmith 2014 Edition  Remastered  Trivium Song Pack II
addappid(1089161)
addappid(1089162)
addappid(1089163)
addappid(1089164) -- Rocksmith 2014 Edition  Remastered  Rockin Covers Song Pack II
addappid(1089165)
addappid(1089166)
addappid(1089167)
addappid(1089168) -- Rocksmith 2014 Edition  Remastered  Tegan and Sara Song Pack
addappid(1089169)
addappid(1089170)
addappid(1089171)
addappid(1089172)
addappid(1089184)
addappid(1089185)
addappid(1089186)
addappid(1089187) -- Rocksmith 2014 Edition  Remastered  Indie Rock Song Pack
addappid(1089188)
addappid(1089189)
addappid(1089190)
addappid(1089191) -- Rocksmith 2014 Edition  Remastered  Manic Street Preachers Song Pack
addappid(1089192)
addappid(1089193)
addappid(1089194)
addappid(1089195) -- Rocksmith 2014 Edition  Remastered  Gary Moore Song Pack
addappid(1089196)
addappid(1089197)
addappid(1089198)
addappid(1089210) -- Rocksmith 2014 Edition  Remastered  Wrestling Theme Song Pack
addappid(1089211)
addappid(1089212)
addappid(1089213)
addappid(1089214) -- Rocksmith 2014 Edition  Remastered  Bloodhound Gang Song Pack
addappid(1089215)
addappid(1089216)
addappid(1089217) -- Rocksmith 2014 Edition  Remastered  Bloodhound Gang - The Ballad of Chasey Lain
addappid(1089218) -- Rocksmith 2014 Edition  Remastered  Women Who Rock Song Pack II
addappid(1089219)
addappid(1089220)
addappid(1089221)
addappid(1089222)
addappid(1089233)
addappid(1089234)
addappid(1089235)
addappid(1089236)
addappid(1089237) -- Rocksmith 2014 Edition  Remastered  Social Stars Song Pack
addappid(1089238)
addappid(1089239)
addappid(1089240)
addappid(1089241)
addappid(1089242) -- Rocksmith 2014 Edition  Remastered  Amaranthe Song Pack
addappid(1089243)
addappid(1089244)
addappid(1089245)
addappid(1122562) -- Rocksmith 2014 Edition  Remastered  Metal Mix Song Pack II
addappid(1122563)
addappid(1122564)
addappid(1122565)
addappid(1122566) -- Rocksmith 2014 Edition  Remastered  Indigo Girls Song Pack
addappid(1122570) -- Rocksmith 2014 Edition  Remastered  The Zombies Song Pack
addappid(1122571)
addappid(1122572)
addappid(1122573)
addappid(1122574)
addappid(1122585)
addappid(1122586)
addappid(1122587)
addappid(1122588)
addappid(1122593) -- Rocksmith 2014 Edition  Remastered  Blues Song Pack III
addappid(1122594)
addappid(1122595)
addappid(1122596)
addappid(1122597) -- Rocksmith 2014 Edition  Remastered  Pat Benatar Song Pack
addappid(1122598)
addappid(1122599)
addappid(1122600)
addappid(1122601) -- Rocksmith 2014 Edition  Remastered  Weezer Song Pack II
addappid(1122602)
addappid(1122603)
addappid(1122604)
addappid(1122605) -- Rocksmith 2014 Edition  Remastered  ABBA Song Pack
addappid(1122606)
addappid(1122607)
addappid(1122608)
addappid(1122609) -- Rocksmith 2014 Edition  Remastered  Aerosmith Song Pack II
addappid(1122610)
addappid(1122611)
addappid(1122612)
addappid(1122613) -- Rocksmith 2014 Edition  Remastered  Chris Stapleton Song Pack
addappid(1122614)
addappid(1122615)
addappid(1122616)
addappid(1122617) -- Rocksmith 2014 Edition  Remastered  John Mellencamp Song Pack
addappid(1122618)
addappid(1122619)
addappid(1122620)
addappid(1122621) -- Rocksmith 2014 Edition  Remastered  HAIM Song Pack
addappid(1122622)
addappid(1122623)
addappid(1122624)
addappid(1122625) -- Rocksmith 2014 Edition  Remastered  Great White Song Pack
addappid(1122626)
addappid(1122627)
addappid(1122628)
addappid(1122629) -- Rocksmith 2014 Edition  Remastered  Stevie Wonder Song Pack
addappid(1122630)
addappid(1122631)
addappid(1122632)
addappid(1122633) -- Rocksmith 2014 Edition  Remastered  Green Day Song Pack IV
addappid(1122634)
addappid(1122635)
addappid(1122636)
addappid(1122637) -- Rocksmith 2014 Edition  Remastered  Riot Grrrl Song Pack
addappid(1122638)
addappid(1122639)
addappid(1122640)
addappid(1122641) -- Rocksmith 2014 Edition  Remastered  Sevendust Song Pack
addappid(1122642)
addappid(1122643)
addappid(1122644)
addappid(1122645) -- Rocksmith 2014 Edition  Remastered  Melissa Etheridge Song Pack
addappid(1122646)
addappid(1122647)
addappid(1122648)
addappid(1122649) -- Rocksmith 2014 Edition  Remastered  SixxA.M. Song Pack
addappid(1122650)
addappid(1122651)
addappid(1122652)
addappid(1122653) -- Rocksmith 2014 Edition  Remastered  70s Mix Song Pack VI
addappid(1122654)
addappid(1122655)
addappid(1122656)
addappid(1122657) -- Rocksmith 2014 Edition  Remastered  Janis Joplin Song Pack
addappid(1122658)
addappid(1122659)
addappid(1122660)
addappid(1122661) -- Rocksmith 2014 Edition  Remastered  Opeth Song Pack
addappid(1122662)
addappid(1122663)
addappid(1122664)
-- addappid(221684) -- Depot 221684 (empty depot)
-- addappid(243421) -- Depot 243421 (empty depot)
-- addappid(258340) -- Depot 258340 (empty depot)
-- addappid(258347) -- Depot 258347 (empty depot)
-- addappid(258353) -- Depot 258353 (empty depot)
-- addappid(258357) -- Depot 258357 (empty depot)
-- addappid(258363) -- Depot 258363 (empty depot)
-- addappid(258367) -- Depot 258367 (empty depot)
-- addappid(258371) -- Depot 258371 (empty depot)
-- addappid(258377) -- Depot 258377 (empty depot)
-- addappid(258383) -- Depot 258383 (empty depot)
-- addappid(258387) -- Depot 258387 (empty depot)
-- addappid(258391) -- Depot 258391 (empty depot)
-- addappid(258397) -- Depot 258397 (empty depot)
-- addappid(258401) -- Depot 258401 (empty depot)
-- addappid(258407) -- Depot 258407 (empty depot)
-- addappid(258413) -- Depot 258413 (empty depot)
-- addappid(258419) -- Depot 258419 (empty depot)
-- addappid(271415) -- Depot 271415 (empty depot)
-- addappid(271419) -- Depot 271419 (empty depot)
-- addappid(271425) -- Depot 271425 (empty depot)
-- addappid(271431) -- Depot 271431 (empty depot)
-- addappid(271434) -- Depot 271434 (empty depot)
-- addappid(271435) -- Depot 271435 (empty depot)
-- addappid(271436) -- Depot 271436 (empty depot)
-- addappid(271437) -- Depot 271437 (empty depot)
-- addappid(271444) -- Depot 271444 (empty depot)
-- addappid(271448) -- Depot 271448 (empty depot)
-- addappid(271454) -- Depot 271454 (empty depot)
-- addappid(271463) -- Depot 271463 (empty depot)
-- addappid(271469) -- Depot 271469 (empty depot)
-- addappid(271474) -- Depot 271474 (empty depot)
-- addappid(271478) -- Depot 271478 (empty depot)
-- addappid(271482) -- Depot 271482 (empty depot)
-- addappid(271483) -- Depot 271483 (empty depot)
-- addappid(271484) -- Depot 271484 (empty depot)
-- addappid(271485) -- Depot 271485 (empty depot)
-- addappid(271486) -- Depot 271486 (empty depot)
-- addappid(271487) -- Depot 271487 (empty depot)
-- addappid(271488) -- Depot 271488 (empty depot)
-- addappid(271492) -- Depot 271492 (empty depot)
-- addappid(271493) -- Depot 271493 (empty depot)
-- addappid(271494) -- Depot 271494 (empty depot)
-- addappid(271495) -- Depot 271495 (empty depot)
-- addappid(271496) -- Depot 271496 (empty depot)
-- addappid(294904) -- Depot 294904 (empty depot)
-- addappid(294908) -- Depot 294908 (empty depot)
-- addappid(294912) -- Depot 294912 (empty depot)
-- addappid(294918) -- Depot 294918 (empty depot)
-- addappid(294922) -- Depot 294922 (empty depot)
-- addappid(294928) -- Depot 294928 (empty depot)
-- addappid(294939) -- Depot 294939 (empty depot)
-- addappid(294948) -- Depot 294948 (empty depot)
-- addappid(294957) -- Depot 294957 (empty depot)
-- addappid(294958) -- Depot 294958 (empty depot)
-- addappid(294962) -- Depot 294962 (empty depot)
-- addappid(294971) -- Depot 294971 (empty depot)
-- addappid(294977) -- Depot 294977 (empty depot)
-- addappid(294981) -- Depot 294981 (empty depot)
-- addappid(294985) -- Depot 294985 (empty depot)
-- addappid(294997) -- Depot 294997 (empty depot)
-- addappid(295005) -- Depot 295005 (empty depot)
-- addappid(295011) -- Depot 295011 (empty depot)
-- addappid(295017) -- Depot 295017 (empty depot)
-- addappid(295023) -- Depot 295023 (empty depot)
-- addappid(295029) -- Depot 295029 (empty depot)
-- addappid(295040) -- Depot 295040 (empty depot)
-- addappid(295044) -- Depot 295044 (empty depot)
-- addappid(295050) -- Depot 295050 (empty depot)
-- addappid(295056) -- Depot 295056 (empty depot)
-- addappid(295062) -- Depot 295062 (empty depot)
-- addappid(295064) -- Depot 295064 (empty depot)
-- addappid(295068) -- Depot 295068 (empty depot)
-- addappid(295069) -- Depot 295069 (empty depot)
-- addappid(295073) -- Depot 295073 (empty depot)
-- addappid(295077) -- Depot 295077 (empty depot)
-- addappid(295081) -- Depot 295081 (empty depot)
-- addappid(295085) -- Depot 295085 (empty depot)
-- addappid(295086) -- Depot 295086 (empty depot)
-- addappid(295093) -- Depot 295093 (empty depot)
-- addappid(295099) -- Depot 295099 (empty depot)
-- addappid(342760) -- Depot 342760 (empty depot)
-- addappid(342769) -- Depot 342769 (empty depot)
-- addappid(342775) -- Depot 342775 (empty depot)
-- addappid(342779) -- Depot 342779 (empty depot)
-- addappid(342785) -- Depot 342785 (empty depot)
-- addappid(342789) -- Depot 342789 (empty depot)
-- addappid(342795) -- Depot 342795 (empty depot)
-- addappid(342800) -- Depot 342800 (empty depot)
-- addappid(342806) -- Depot 342806 (empty depot)
-- addappid(342811) -- Depot 342811 (empty depot)
-- addappid(342815) -- Depot 342815 (empty depot)
-- addappid(342821) -- Depot 342821 (empty depot)
-- addappid(342825) -- Depot 342825 (empty depot)
-- addappid(342831) -- Depot 342831 (empty depot)
-- addappid(342835) -- Depot 342835 (empty depot)
-- addappid(342841) -- Depot 342841 (empty depot)
-- addappid(342845) -- Depot 342845 (empty depot)
-- addappid(342851) -- Depot 342851 (empty depot)
-- addappid(342857) -- Depot 342857 (empty depot)
-- addappid(369762) -- Depot 369762 (empty depot)
-- addappid(369767) -- Depot 369767 (empty depot)
-- addappid(369768)
-- addappid(369769)
-- addappid(369771) -- Depot 369771 (empty depot)
-- addappid(369777) -- Depot 369777 (empty depot)
-- addappid(369781) -- Depot 369781 (empty depot)
-- addappid(369787) -- Depot 369787 (empty depot)
-- addappid(369793) -- Depot 369793 (empty depot)
-- addappid(369797) -- Depot 369797 (empty depot)
-- addappid(369802) -- Depot 369802 (empty depot)
-- addappid(369807) -- Depot 369807 (empty depot)
-- addappid(369811) -- Depot 369811 (empty depot)
-- addappid(369815) -- Depot 369815 (empty depot)
-- addappid(369819) -- Depot 369819 (empty depot)
-- addappid(369823) -- Depot 369823 (empty depot)
-- addappid(369827) -- Depot 369827 (empty depot)
-- addappid(390361) -- Depot 390361 (empty depot)
-- addappid(390365) -- Depot 390365 (empty depot)
-- addappid(390369) -- Depot 390369 (empty depot)
-- addappid(390373) -- Depot 390373 (empty depot)
-- addappid(390378) -- Depot 390378 (empty depot)
-- addappid(390383) -- Depot 390383 (empty depot)
-- addappid(390388) -- Depot 390388 (empty depot)
-- addappid(390395) -- Depot 390395 (empty depot)
-- addappid(390399) -- Depot 390399 (empty depot)
-- addappid(390405) -- Depot 390405 (empty depot)
-- addappid(390411) -- Depot 390411 (empty depot)
-- addappid(390418) -- Depot 390418 (empty depot)
-- addappid(390423) -- Depot 390423 (empty depot)
-- addappid(390429) -- Depot 390429 (empty depot)
-- addappid(390435) -- Depot 390435 (empty depot)
-- addappid(390439) -- Depot 390439 (empty depot)
-- addappid(390445) -- Depot 390445 (empty depot)
-- addappid(390450) -- Depot 390450 (empty depot)
-- addappid(390455) -- Depot 390455 (empty depot)
-- addappid(436571) -- Depot 436571 (empty depot)
-- addappid(436578) -- Depot 436578 (empty depot)
-- addappid(436584) -- Depot 436584 (empty depot)
-- addappid(436588) -- Depot 436588 (empty depot)
-- addappid(436593) -- Depot 436593 (empty depot)
-- addappid(436597) -- Depot 436597 (empty depot)
-- addappid(436603) -- Depot 436603 (empty depot)
-- addappid(436607) -- Depot 436607 (empty depot)
-- addappid(436611) -- Depot 436611 (empty depot)
-- addappid(436617) -- Depot 436617 (empty depot)
-- addappid(436622) -- Depot 436622 (empty depot)
-- addappid(436626) -- Depot 436626 (empty depot)
-- addappid(436630) -- Depot 436630 (empty depot)
-- addappid(436634) -- Depot 436634 (empty depot)
-- addappid(436640) -- Depot 436640 (empty depot)
-- addappid(436645) -- Depot 436645 (empty depot)
-- addappid(436650) -- Depot 436650 (empty depot)
-- addappid(436655) -- Depot 436655 (empty depot)
-- addappid(436659) -- Depot 436659 (empty depot)
-- addappid(436664) -- Depot 436664 (empty depot)
-- addappid(436668) -- Depot 436668 (empty depot)
-- addappid(492944) -- Depot 492944 (empty depot)
-- addappid(492949) -- Depot 492949 (empty depot)
-- addappid(492954) -- Depot 492954 (empty depot)
-- addappid(492957) -- Depot 492957 (empty depot)
-- addappid(492963) -- Depot 492963 (empty depot)
-- addappid(492967) -- Depot 492967 (empty depot)
-- addappid(492971) -- Depot 492971 (empty depot)
-- addappid(492976) -- Depot 492976 (empty depot)
-- addappid(492981) -- Depot 492981 (empty depot)
-- addappid(492985) -- Depot 492985 (empty depot)
-- addappid(509632) -- Depot 509632 (empty depot)
-- addappid(509636) -- Depot 509636 (empty depot)
-- addappid(509642) -- Depot 509642 (empty depot)
-- addappid(509647) -- Depot 509647 (empty depot)
-- addappid(509652) -- Depot 509652 (empty depot)
-- addappid(509658) -- Depot 509658 (empty depot)
-- addappid(509664) -- Depot 509664 (empty depot)
-- addappid(509668) -- Depot 509668 (empty depot)
-- addappid(509673) -- Depot 509673 (empty depot)
-- addappid(509678) -- Depot 509678 (empty depot)
-- addappid(509682) -- Depot 509682 (empty depot)
-- addappid(509688) -- Depot 509688 (empty depot)
-- addappid(509694) -- Depot 509694 (empty depot)
-- addappid(509698) -- Depot 509698 (empty depot)
-- addappid(509704) -- Depot 509704 (empty depot)
-- addappid(509709) -- Depot 509709 (empty depot)
-- addappid(509713) -- Depot 509713 (empty depot)
-- addappid(509717) -- Depot 509717 (empty depot)
-- addappid(509724) -- Depot 509724 (empty depot)
-- addappid(509728) -- Depot 509728 (empty depot)
-- addappid(509733) -- Depot 509733 (empty depot)
-- addappid(509739) -- Depot 509739 (empty depot)
-- addappid(509743) -- Depot 509743 (empty depot)
-- addappid(509749) -- Depot 509749 (empty depot)
-- addappid(590175) -- Depot 590175 (empty depot)
-- addappid(590176) -- Depot 590176 (empty depot)
-- addappid(590177) -- Depot 590177 (empty depot)
-- addappid(590178) -- Depot 590178 (empty depot)
-- addappid(590179) -- Depot 590179 (empty depot)
-- addappid(590180) -- Depot 590180 (empty depot)
-- addappid(590181) -- Depot 590181 (empty depot)
-- addappid(590182) -- Depot 590182 (empty depot)
-- addappid(590183) -- Depot 590183 (empty depot)
-- addappid(590189) -- Depot 590189 (empty depot)
-- addappid(590194) -- Depot 590194 (empty depot)
-- addappid(590200) -- Depot 590200 (empty depot)
-- addappid(590201) -- Depot 590201 (empty depot)
-- addappid(590205) -- Depot 590205 (empty depot)
-- addappid(590211) -- Depot 590211 (empty depot)
-- addappid(590215) -- Depot 590215 (empty depot)
-- addappid(590221) -- Depot 590221 (empty depot)
-- addappid(590225) -- Depot 590225 (empty depot)
-- addappid(590229) -- Depot 590229 (empty depot)
-- addappid(590234) -- Depot 590234 (empty depot)
-- addappid(590240) -- Depot 590240 (empty depot)
-- addappid(590245) -- Depot 590245 (empty depot)
-- addappid(637690) -- Depot 637690 (empty depot)
-- addappid(637694) -- Depot 637694 (empty depot)
-- addappid(637699) -- Depot 637699 (empty depot)
-- addappid(637703) -- Depot 637703 (empty depot)
-- addappid(637707) -- Depot 637707 (empty depot)
-- addappid(637711) -- Depot 637711 (empty depot)
-- addappid(637715) -- Depot 637715 (empty depot)
-- addappid(637720) -- Depot 637720 (empty depot)
-- addappid(637724) -- Depot 637724 (empty depot)
-- addappid(637729) -- Depot 637729 (empty depot)
-- addappid(637735) -- Depot 637735 (empty depot)
-- addappid(637739) -- Depot 637739 (empty depot)
-- addappid(637743) -- Depot 637743 (empty depot)
-- addappid(637748) -- Depot 637748 (empty depot)
-- addappid(637753) -- Depot 637753 (empty depot)
-- addappid(637757) -- Depot 637757 (empty depot)
-- addappid(637761) -- Depot 637761 (empty depot)
-- addappid(637766) -- Depot 637766 (empty depot)
-- addappid(637772) -- Depot 637772 (empty depot)
-- addappid(637777) -- Depot 637777 (empty depot)
-- addappid(637787) -- Depot 637787 (empty depot)
-- addappid(637793) -- Depot 637793 (empty depot)
-- addappid(637799) -- Depot 637799 (empty depot)
-- addappid(637805) -- Depot 637805 (empty depot)
-- addappid(637806) -- Depot 637806 (empty depot)
-- addappid(637812) -- Depot 637812 (empty depot)
-- addappid(637818) -- Depot 637818 (empty depot)
-- addappid(637825) -- Depot 637825 (empty depot)
-- addappid(637831) -- Depot 637831 (empty depot)
-- addappid(637835) -- Depot 637835 (empty depot)
-- addappid(637839) -- Depot 637839 (empty depot)
-- addappid(637844) -- Depot 637844 (empty depot)
-- addappid(637848) -- Depot 637848 (empty depot)
-- addappid(753744) -- Depot 753744 (empty depot)
-- addappid(753748) -- Depot 753748 (empty depot)
-- addappid(753752) -- Depot 753752 (empty depot)
-- addappid(753760) -- Depot 753760 (empty depot)
-- addappid(753764) -- Depot 753764 (empty depot)
-- addappid(753773) -- Depot 753773 (empty depot)
-- addappid(753777) -- Depot 753777 (empty depot)
-- addappid(753781) -- Depot 753781 (empty depot)
-- addappid(753785) -- Depot 753785 (empty depot)
-- addappid(753789) -- Depot 753789 (empty depot)
-- addappid(753794) -- Depot 753794 (empty depot)
-- addappid(753798) -- Depot 753798 (empty depot)
-- addappid(753802) -- Depot 753802 (empty depot)
-- addappid(753807) -- Depot 753807 (empty depot)
-- addappid(753811) -- Depot 753811 (empty depot)
-- addappid(753815) -- Depot 753815 (empty depot)
-- addappid(753819) -- Depot 753819 (empty depot)
-- addappid(753823) -- Depot 753823 (empty depot)
-- addappid(753827) -- Depot 753827 (empty depot)
-- addappid(753832) -- Depot 753832 (empty depot)
-- addappid(753842) -- Depot 753842 (empty depot)
-- addappid(753846) -- Depot 753846 (empty depot)
-- addappid(753850) -- Depot 753850 (empty depot)
-- addappid(753855) -- Depot 753855 (empty depot)
-- addappid(753860) -- Depot 753860 (empty depot)
-- addappid(753864) -- Depot 753864 (empty depot)
-- addappid(753868) -- Depot 753868 (empty depot)
-- addappid(753872) -- Depot 753872 (empty depot)
-- addappid(753876) -- Depot 753876 (empty depot)
-- addappid(753880) -- Depot 753880 (empty depot)
-- addappid(753884) -- Depot 753884 (empty depot)
-- addappid(753888) -- Depot 753888 (empty depot)
-- addappid(753892) -- Depot 753892 (empty depot)
-- addappid(753897) -- Depot 753897 (empty depot)
-- addappid(753898) -- Depot 753898 (empty depot)
-- addappid(753899) -- Depot 753899 (empty depot)
-- addappid(899780) -- Depot 899780 (empty depot)
-- addappid(899781) -- Depot 899781 (empty depot)
-- addappid(899786) -- Depot 899786 (empty depot)
-- addappid(899788)
-- addappid(899789)
-- addappid(899791) -- Depot 899791 (empty depot)
-- addappid(899796) -- Depot 899796 (empty depot)
-- addappid(899800) -- Depot 899800 (empty depot)
-- addappid(899804) -- Depot 899804 (empty depot)
-- addappid(899808) -- Depot 899808 (empty depot)
-- addappid(899813) -- Depot 899813 (empty depot)
-- addappid(899817) -- Depot 899817 (empty depot)
-- addappid(899821) -- Depot 899821 (empty depot)
-- addappid(899826) -- Depot 899826 (empty depot)
-- addappid(899830) -- Depot 899830 (empty depot)
-- addappid(899834) -- Depot 899834 (empty depot)
-- addappid(899838) -- Depot 899838 (empty depot)
-- addappid(899842) -- Depot 899842 (empty depot)
-- addappid(899847) -- Depot 899847 (empty depot)
-- addappid(899892) -- Depot 899892 (empty depot)
-- addappid(1122567)
-- addappid(1122568)
-- addappid(1122569)

-- MAIN APP DEPOTS / PACKAGES
addappid(221680, 1, "7e75d2e984ca048b8b617a65d69bd3adc02408098b96cb5caf760e21902f7518") -- Rocksmith® 2014 Edition - Remastered
addappid(221681, 1, "2774295430175ffb239a4064516349a5bde16e081b50bef3b5c8a3f0995acb34") -- Rocksmith 2014 PC
addappid(221682, 1, "0508788ca23f64cbd2fbb192c1cacd466001db445c23ec95b1d5425546bf8a64") -- Rocksmith 2014 MacOS
addappid(221683, 1, "9fee3bfa5a929e871fe8af03bedf03985f021c8517b5187b45b655bc13103f86") -- Depot 221683
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(248750, 1, "4196de9ae280ad4c299e3ccac6258c18de1a14058e59a7f8b88e941645496203") -- Rocksmith® 2014 - The Smashing Pumpkins  - “Cherub Rock” (248750) Depot
addappid(248751, 1, "6e734be57a579c545e6b66d9b465ce9ef2eddc688d103ab8ad93c5e6f0a4d62c") -- Rocksmith® 2014 - Albert King  - “The Sky Is Crying” (248751) Depot
addappid(248752, 1, "bac9f5c9a68f0c21029430b0a075d672995ea23a993968665242121805e3c00f") -- Rocksmith® 2014 - Chicago  - “25 Or 6 To 4” (248752) Depot
addappid(248753, 1, "26aed40bc84a758837a9eb16cbbb0e13f9dbdc23f68abd898491adbc578b9477") -- Rocksmith® 2014 - Tame Impala  - “Elephant” (248753) Depot
addappid(248754, 1, "5fc9f15acf3b79276ced5082fef944635aa64fe39edeedcb9daccc26cf29f78f") -- Rocksmith® 2014 - The Lumineers  - “Ho Hey” (248754) Depot
addappid(248755, 1, "a9bbee322b702c89d041ab711412be7b794532a8a669dcf3bc6f10f1b1612c60") -- Rocksmith® 2014 - The Hives  - “Hate To Say I Told You So” (248755) Depot
addappid(248756, 1, "870cf26c51d4ac617250192fc06b3769b0910ed8a85616205ca9682285f2b5e8") -- Rocksmith® 2014 - Them Crooked Vultures  - “Mind Eraser, No Chaser” (248756) Depot
addappid(248757, 1, "b1673cba58d31f874cbb09c381ad8eb625d2322b84e3d82be4cc9ba1059c956d") -- Rocksmith® 2014 - Queens Of The Stone Age  - “My God Is The Sun” (248757) Depot
addappid(258341, 1, "2eae1cc5a340fdc7d547680c6b6f3b1bfa0180293ad40efa05921ec8c998bf4f") -- savecancel
addappid(258342, 1, "4b3d5856e1acb774f854064a794df941b72396415f9c380e8ced24628a59213d") -- DLC 258342
addappid(258343, 1, "ec201d0d393bc4395aefde008be61137e73fbb0e011198e69d11a2bfa55f6972") -- DLC 258343
addappid(258344, 1, "1bb8acaeba593da977a28b634d896fe3f71ff3ac8b621ff8ff28b55425d27e53") -- DLC 258344
addappid(258345, 1, "a9b4f8927cac6a74698c8fcfc94bee255500933eb6affad42a332b8f382316d6") -- DLC 258345
addappid(258346, 1, "462094d40878c6ad6eea5a1129d5fcaf8a8ec93c37cd3246a42f6f49fc1eb2e5") -- DLC 258346
addappid(258348, 1, "360e9dec345d72533b11e189a206499fae1d27406ae9851734f5ebe2aafdfc15") -- Rocksmith 2014 DLC (258348) Depot
addappid(258349, 1, "22b150b27b23616567ac10403ee2ce14df312ad06c6197d60bdf24eab98aa722") -- Rocksmith 2014 DLC (258349) Depot
addappid(258350, 1, "a78e0fd925cc0bbc5fb31c4b8ca3c6ebf7b5bb9a24a1a2cd3ab725190806f788") -- Rocksmith 2014 DLC (258350) Depot
addappid(258351, 1, "6410cec052ef203fc97bdad9c11882138a4a81d6c39c4798a33f3c9ef26a0b43") -- Rocksmith 2014 DLC (258351) Depot
addappid(258352, 1, "c642e8ca60beb904bed2505931daf190a73f2736362cf996fd0b4b861ffda745") -- Rocksmith 2014 DLC (258352) Depot
addappid(258354, 1, "4284b14d3131f86fd4c62306d41bcc6246ee7f943c297e8778fb860e6a625bbe") -- Rocksmith 2014 DLC (258354) Depot
addappid(258355, 1, "c62ce67b88ab887d7e8113589220f51c20b7445c8b0dd83acde304bbb875e1ce") -- Rocksmith 2014 DLC (258355) Depot
addappid(258356, 1, "df048ab50fc26d8689b5e3802d862a46d751b917a3d1b5533d4dab9574a0f621") -- Rocksmith 2014 DLC (258356) Depot
addappid(258358, 1, "7a037e1e9ad3451353450c14b87457b688fe0423c02ca244239d08f1739bbcb2") -- Rocksmith 2014 DLC (258358) Depot
addappid(258359, 1, "3aafe157a1cb75710434a6927b34b4677134974072a1d8df451509687d42964f") -- Rocksmith 2014 DLC (258359) Depot
addappid(258360, 1, "52dfe0e819dc7481895365c9d6d2cc70f420c55dabc76ddaacfe6e7c85c074af") -- Rocksmith 2014 DLC (258360) Depot
addappid(258361, 1, "c2dd0ad5921ea20c9ec8ea04c1f6cb17db5958787d5c1e3d752a86163cae104a") -- Rocksmith 2014 DLC (258361) Depot
addappid(258362, 1, "f68d7154bddbc65962846407baf223f14225c5f9f91945319f8dc5111d791ebc") -- Rocksmith 2014 DLC (258362) Depot
addappid(258364, 1, "2879d378862b1ab14524b4fbec21a91002ff671644f89dcaa5274269c07e972a") -- Rocksmith 2014 DLC (258364) Depot
addappid(258365, 1, "a5d2e2a4fe87999aadb427218ed96d26dd0550636e9c005f93def39e4953dbae") -- Rocksmith 2014 DLC (258365) Depot
addappid(258366, 1, "9f17652afc96269e2e4baf3409cb40b35ba6aafc2acdebc342bc4e8816365ee1") -- Rocksmith 2014 DLC (258366) Depot
addappid(258368, 1, "da08c727b590c661715256049537f39f613925159bfa4682786e5e4f31a70705") -- Rocksmith 2014 DLC (258368) Depot
addappid(258369, 1, "df49dad170167fff624b278e702a053a31e86b46c119203222d7052bdbbcd5fb") -- Rocksmith 2014 DLC (258369) Depot
addappid(258372, 1, "fcc8ebef346dd4ecffd42b3e19a81e030a62e4bbce7ca7ab125e327ea47b7a3c") -- Rocksmith 2014 DLC (258372) Depot
addappid(258373, 1, "9b01a0fcad8b897f2fb6d1e2033cf92632f5a4557cec98778c104d9e3cb82173") -- Rocksmith 2014 DLC (258373) Depot
addappid(258374, 1, "c40eff397ba984fc516a8c7ff51d817d83332bddc328b8693d05a5fddfa4d939") -- Rocksmith 2014 DLC (258374) Depot
addappid(258375, 1, "b9858f8c6b5a0f5e3cb540f2e33134f9f941c8c371023f2f5d3509a1108b49aa") -- Rocksmith 2014 DLC (258375) Depot
addappid(258376, 1, "f76c6a61bfd64d0329c3ece280e4f6a871d7a80dae8020a5326380eaef53943d") -- Rocksmith 2014 DLC (258376) Depot
addappid(258378, 1, "5c66d346137932df53c42c64c31690850566848b6a02842db9a0c1fa2b83f339") -- Rocksmith 2014 DLC (258378) Depot
addappid(258379, 1, "b3267a67ef079037da3ca13578b0464429b2db59da8fe411f87c684373fe5209") -- Rocksmith 2014 DLC (258379) Depot
addappid(258380, 1, "e68995fba4e16c9ecf715a7d0760ac81994e6d382bcad1450b114a3d87008fc7") -- Rocksmith 2014 DLC (258380) Depot
addappid(258381, 1, "810e3dc0add044e3f8d149f80ffdbb849d52bcaaf06ac6b773d5d234b1a940e6") -- Rocksmith 2014 DLC (258381) Depot
addappid(258382, 1, "c0db58d475e326e9fd13b0978e38cc3ca71be839a77a3e1b21a3a4efb17205c1") -- Rocksmith 2014 DLC (258382) Depot
addappid(258384, 1, "621674c527b5e30407f817fb30d915b1c1f25ecbe080f291ac65b80affee07e1") -- Rocksmith 2014 DLC (258384) Depot
addappid(258385, 1, "06492e8bea3c0b036ed72b74634d89ddc72929a575752ff1004d0cc98f26beda") -- Rocksmith 2014 DLC (258385) Depot
addappid(258386, 1, "4f2e7a9dcd40426be2e16dae684a6074b1abd709bfd9f59cc353125c449ee6d6") -- Rocksmith 2014 DLC (258386) Depot
addappid(258388, 1, "271a28cbaeaad37d583b6bc84596a3d4d0a9b6a76c5e7c8134a6296fc63b2658") -- Rocksmith 2014 DLC (258388) Depot
addappid(258389, 1, "ed12a6c38e1de9eb1d0e3320546010c20dcfe67297e57780f374bae8f1dbdde6") -- Rocksmith 2014 DLC (258389) Depot
addappid(258390, 1, "e60fa024d0a5ad96ce56e5bd14edeab0508bc7b3d0408a34c3a9abed4d6addc4") -- Rocksmith 2014 DLC (258390) Depot
addappid(258392, 1, "7e7e3edc07560572acad41b00345c2435c7f6dc251a2cedd315cfa9bc8ed9aaa") -- Rocksmith 2014 DLC (258392) Depot
addappid(258393, 1, "ae1a38ea569c010a2e19ae4922fdfde85186cdd5977168a1fbf1999988d32eb5") -- Rocksmith 2014 DLC (258393) Depot
addappid(258394, 1, "6e427cf28fc4514c44b85a9dbecefb3c536fdad3e75e813b55892ff585c5a7dd") -- Rocksmith 2014 DLC (258394) Depot
addappid(258395, 1, "0dcb9d597ac68645f9bb01a7d782d3ea7de4f9a61b0ecd9510a4a49e36f8a7cb") -- Rocksmith 2014 DLC (258395) Depot
addappid(258396, 1, "86f7a69b4304aef91057db911bf0e7f48e71b421aafe091dc5a0e6109cd07174") -- Rocksmith 2014 DLC (258396) Depot
addappid(258398, 1, "47bdaeb1a57838bcad55ba061d880d10518fde1e0897a42136b960403048748c") -- Rocksmith 2014 DLC (258398) Depot
addappid(258399, 1, "16b0b75d9d50cbbcbafa6d8f5dad45e34fc90b24b932db8b25bca833d64c1a1a") -- Rocksmith 2014 DLC (258399) Depot
addappid(258402, 1, "6d940fb0216a57e577d1a399845c98be6833461b764bd672c15f994d1ebbf834") -- Rocksmith 2014 DLC (258402) Depot
addappid(258403, 1, "749b13127fba2acc6c1c43b145ac526d9ccdcdb8cdf69a60a95cd2234064f6a0") -- Rocksmith 2014 DLC (258403) Depot
addappid(258404, 1, "1741cd8336a7c2b863ee53112b57967f322ce583e7f53431723bafddc4f647b0") -- Rocksmith 2014 DLC (258404) Depot
addappid(258405, 1, "38171e576461ff62013ceb6d0ac06336b58916f83f5f6c49ff59f7a2e83c5055") -- Rocksmith 2014 DLC (258405) Depot
addappid(258406, 1, "2c0f874df1d00bc731dcebd0206ca1ca7d8f7a4e5098815f3829f20aafe6bd59") -- Rocksmith 2014 DLC (258406) Depot
addappid(258408, 1, "c8e98ae8c45969b92f8844fcd912b67fe91ea046e62636c8220b298c7f214dd7") -- Rocksmith 2014 DLC (258408) Depot
addappid(258409, 1, "6abe21fac1f1d800899ac07a44029fcd6f315038a8f807c3791035a6fb65240e") -- Rocksmith 2014 DLC (258409) Depot
addappid(258410, 1, "a365873708fdd62d7eaca77da539805bfdfad2fef265b85fc1ffdf1e6e6fb399") -- Rocksmith 2014 DLC (258410) Depot
addappid(258411, 1, "11b8f46709120957fbc1028ba557a9b51300a918f999fcb1d7d087323f67021a") -- Rocksmith 2014 DLC (258411) Depot
addappid(258412, 1, "c170ef02b01a92897a26d74846b32084d57cddf62d48ecb806c9bab5373d7f91") -- Rocksmith 2014 DLC (258412) Depot
addappid(258414, 1, "5086d31bc841706a2c407a5bf951fe5dfe50735c61aa1753e81f33ba3d59e61a") -- Rocksmith 2014 DLC (258414) Depot
addappid(258415, 1, "dd391a5f21ab03237651d2ba782b1a7e08dcc1c2e9e03603b796b288a5e7abe7") -- Rocksmith 2014 DLC (258415) Depot
addappid(258416, 1, "9ccb9801d94d68bdaaaf675c3478e476a720f82baecef2a225d9637ffa9cdc4f") -- Rocksmith 2014 DLC (258416) Depot
addappid(258417, 1, "e24af69c264aa28770b9cba3ee6517730aca054df2f786b27fd90406ccdb982e") -- Rocksmith 2014 DLC (258417) Depot
addappid(258418, 1, "057430beb71697e4eb6e109d0106bb6146ec8cd9509c386e4677874658c2e028") -- Rocksmith 2014 DLC (258418) Depot
addappid(271410, 1, "125bedeabcb06eccae8824a8089cf0663e4547a939b1f45bc8db0e4e420e719d") -- Rocksmith 2014 (271410) Depot
addappid(271411, 1, "bed15059efe8dfceae8f5c448f57a272313146014a9eb6020980c1698398e394") -- Rocksmith 2014 (271411) Depot
addappid(271412, 1, "ee02884832b46e14d06e592b4da90b11f99bc8efbd7c5abb08bc0e7505420505") -- Rocksmith 2014 (271412) Depot
addappid(271413, 1, "7031caf60f94bab3d138f4c72ef4e7f50ca42d91c88a6e97179a1f733311f388") -- Rocksmith 2014 (271413) Depot
addappid(271414, 1, "5e75cd71f523f0246bc3953870bccb5ba7ce008acbc016adb0dbd48873d7066d") -- Rocksmith 2014 (271414) Depot
addappid(271416, 1, "b27b44adb4b4c7c9ed1b3c3dd37a262a397ead1892b5b52429d69e76ef7e332b") -- Rocksmith 2014 (271416) Depot
addappid(271417, 1, "b0154fbd03b64d326bd8f057abfdf84253a99cb8bc452a7cb4270229ec27f954") -- Rocksmith 2014 (271417) Depot
addappid(271418, 1, "3e17d18ea010f586764123dea23cd56bab67328d250e7cb3cd2429e3be01794b") -- Rocksmith 2014 (271418) Depot
addappid(271421, 1, "80a2d02a64cacabc34c4f16e9fd65c2d9a904bd095fe2342af29d820159474f4") -- Rocksmith 2014 (271421) Depot
addappid(271422, 1, "d2dfb6b830c996d619c825b9176272d1d6a1f5641565e56f1c0922963789bc4f") -- Rocksmith 2014 (271422) Depot
addappid(271423, 1, "20316cd3a94aa8e7e87c4d72b5211cdde0bef55636498e30dee4c2de69e591df") -- Rocksmith 2014 (271423) Depot
addappid(271424, 1, "3c6fe3b740f1bcb510a6e8942165f1e0fcec7b4851835eba39e07a40b5c69f4f") -- Rocksmith 2014 (271424) Depot
addappid(271426, 1, "587c141cc4ef317705f9e4f974743e1f5bf95b1edda9957d602e66e521544a75") -- Rocksmith 2014 (271426) Depot
addappid(271427, 1, "6144aedbb00d7b1c837ec839a4195b592ffec92c80a26b66d98fd00f937fffc8") -- Rocksmith 2014 (271427) Depot
addappid(271428, 1, "0eb4eb5702f1a453758a630e2863416e1b6b09e9b8d2e480212d8718f1611b00") -- Rocksmith 2014 (271428) Depot
addappid(271429, 1, "b33df7eae4a2b60069b6d90ec3800b5c089d4757cd2f797116926eb0c67b8bf7") -- Rocksmith 2014 (271429) Depot
addappid(271430, 1, "a243d7099311257b448327acbe93cc7889c237f8ab700a0ac739e9e441358f97") -- Rocksmith 2014 (271430) Depot
addappid(271432, 1, "711524f16c4334b16ce4002c0b71f648002efa6e510a8f8c1f2aed6e63c9a322") -- Rocksmith 2014 (271432) Depot
addappid(271433, 1, "497bb4bad30c2b43234ddc163b56fa07f4de3ece1a337cece8646eb02cbe696c") -- Rocksmith 2014 (271433) Depot
addappid(271438, 1, "17388bc1c6567031da745ccd16b359ae4df6557443f724ca612ae99940240c76") -- Rocksmith 2014 (271438) Depot
addappid(271439, 1, "5fcaa040e8773347589d6c1249924ec0bec0ad6b5c08eac8c848896e6b34b808") -- Rocksmith 2014 (271439) Depot
addappid(271441, 1, "28c473d8089de9a59a698f09b082124c35ef9016acf7751f58a95d4d216e771c") -- Rocksmith 2014 (271441) Depot
addappid(271442, 1, "911b999d19da6603e8147f722b44c26d1ffdffa4421484a4ad791fa94e43b7b7") -- Rocksmith 2014 (271442) Depot
addappid(271443, 1, "7c6d2ea967799a566af33f65004c5dc8824579f29c18634c9728bb0aa587423d") -- Rocksmith 2014 (271443) Depot
addappid(271445, 1, "2058a34b4acaf48d2bd571d900b58d3a40dda8e5a381e8dd36ba3d3d8b680af3") -- Rocksmith 2014 (271445) Depot
addappid(271446, 1, "c8bc006070d8c0121c34cb8761165391976111ea9c06842d738322c883107b7b") -- Rocksmith 2014 (271446) Depot
addappid(271447, 1, "984c7ed56f35f26ab7322c5ab83f442b414e14b7cfab12c2f4749b2d161c344d") -- Rocksmith 2014 (271447) Depot
addappid(271449, 1, "fdf92c05aff66aba1efac55096fe9a4d47aab3058e9a2d6c45b2ecc44b8d92cb") -- Rocksmith 2014 (271449) Depot
addappid(271450, 1, "d5d09b0f1963e8d76c6288cc883ccbf1f09a1fc43d152c58b215d6fb00b91d3c") -- Rocksmith 2014 (271450) Depot
addappid(271451, 1, "f1192718f66067be154abcfef0ce1d2fa57688e195334833710042ca31737974") -- Rocksmith 2014 (271451) Depot
addappid(271452, 1, "cf43a9117be49e132f74b5942ca1da7590601d20219fe8241f4f34e78f876e2b") -- Rocksmith 2014 (271452) Depot
addappid(271453, 1, "2922962ad0e72dd2017342be91bcc1e54b51dfe9ad90adfb12c69917b559cb1d") -- Rocksmith 2014 (271453) Depot
addappid(271455, 1, "d6c56337d3c3e450e4ae3d005fc4936e1e2075a7dea6eca6c3659eee0f8d652d") -- Rocksmith 2014 (271455) Depot
addappid(271456, 1, "cdc89a5b0d1a1755632c1ef103fdd0ca82a6b54f09a843c6bf1d507886acbc01") -- Rocksmith 2014 (271456) Depot
addappid(271457, 1, "25bf72ae6ffce6d7d4f185c50940d2e55438bf898834a04b08a5d7d74469b484") -- Rocksmith 2014 (271457) Depot
addappid(271458, 1, "6ffb37f8d86311fcfe5e44909256a019265f0c810c70441856237438225eb67d") -- Rocksmith 2014 (271458) Depot
addappid(271459, 1, "e7d385c49945abf030af7e8ff6be10617b891472bf992a092536c6ef497ae29d") -- Rocksmith 2014 (271459) Depot
addappid(271461, 1, "28e8cef390a2f167d572bd4eee812b94159ef4590b1e503d2c914f37c8caa5b8") -- Rocksmith 2014 (271461) Depot
addappid(271462, 1, "429abffc00e8800ca9ade5905432b966ebff61be74ba39df588dfe4e715a5f27") -- Rocksmith 2014 (271462) Depot
addappid(271464, 1, "31d68aa45bb5cf2070611d0e173aa2351b915fc12db53177d99334eb71b7d471") -- Rocksmith 2014 (271464) Depot
addappid(271465, 1, "38bb86051bf79404e1ae1b56ece7714eef2b1a8889c8eba9420f67d70bc0815c") -- Rocksmith 2014 (271465) Depot
addappid(271466, 1, "571f08faecaeb640b127c7a9b9b77ce2b3972af208ff781c0701be62b6620854") -- Rocksmith 2014 (271466) Depot
addappid(271467, 1, "8aca2811d3ef72eb372c49c9b86a1f07bbecf6a531db034657bc9c0b32a172f6") -- Rocksmith 2014 (271467) Depot
addappid(271468, 1, "39e06da5d84bcdd56c1a3b3da58ef6f0cc47dc8e1dde23cd4c3f491951c6da87") -- Rocksmith 2014 (271468) Depot
addappid(271471, 1, "42df7c625d9e857a887cdb8c4cf0273f051b7a590e2c8e74bdc1ace2a1ea880e") -- Rocksmith 2014 (271471) Depot
addappid(271472, 1, "e7cae2818ecb38f07f90d1c3be2bb527b027e8eca3d4a9fb5fa53aa8bdab41b0") -- Rocksmith 2014 (271472) Depot
addappid(271473, 1, "b9e5fde7a60a16b4b0bb036b24bf917a3457902f9e56d24f37a9c6451c997cf5") -- Rocksmith 2014 (271473) Depot
addappid(271475, 1, "2be5dbaf2e9366cbbe315edff0c1bc054674cec91e9aada9e67424982af8f683") -- Rocksmith 2014 (271475) Depot
addappid(271476, 1, "3bc7dbdcf15ba15c77e8053e4f62d8284451d34bab6412912783ff958e1ff0ca") -- Rocksmith 2014 (271476) Depot
addappid(271477, 1, "53f68ed4b071943c3018d9c9b7c529b669a2bd76c182ee0acd0cdfb12e3179f4") -- Rocksmith 2014 (271477) Depot
addappid(271479, 1, "c9bf948119db42786f2f2568579de06e03d97d50e18ee9e83eea80e192886512") -- Rocksmith 2014 (271479) Depot
addappid(271480, 1, "862a670721e05254738826d3d040766af64a595043f0970c8515cbb7b9c6f79d") -- Rocksmith 2014 (271480) Depot
addappid(271481, 1, "b8658b7da092537f2e268a0723a5d62ddce885ee1efd18efad2f2d130cfc7cd1") -- Rocksmith 2014 (271481) Depot
addappid(271489, 1, "07db210164bffbe1e6aa286dedf95dc74caf904e81c4b05256a3bcd2895866ba") -- Rocksmith 2014 (271489) Depot
addappid(271491, 1, "a91a7a9e24d0ae7c3eeb3aba4c268c82a03752fb19e0132ff17b193471785851") -- Rocksmith 2014 (271491) Depot
addappid(271497, 1, "4bc75508d6496f13cdba7a049eb880719e60bbc74fa601954b3cac45f0916340") -- Rocksmith 2014 (271497) Depot
addappid(271498, 1, "734c28759486a579734a4803690c2ce56c837b23bd824359411398831082d962") -- Rocksmith 2014 (271498) Depot
addappid(271499, 1, "280fd1469a542522c98a23fd356a025e09b8a4b7a88eb4a6ccc077bdc6af1e5d") -- Rocksmith 2014 (271499) Depot
addappid(294913, 1, "a2e7eaffaa172046b8d8388ec8c696603cd3c9b983ba1b88b0ebfe4ddfab4ce2") -- Rocksmith 2014 - Additional DLC 14 (294913) Depot
addappid(294914, 1, "57e6f98c60b78f7150ff1b558ba3f74c004c53aabd9c85906520aee4d2d9cec3") -- Rocksmith 2014 - Additional DLC 15 (294914) Depot
addappid(294915, 1, "bcb6f07b05d8909d7d968358794d8b792b87ad2488c9c659716b2d7e63248ba6") -- Rocksmith 2014 - Additional DLC 16 (294915) Depot
addappid(294916, 1, "7e0429fdee862befa2355ddecbacba6c4848810a20ae7b0544b8c1c644f36d4b") -- Rocksmith 2014 - Additional DLC 17 (294916) Depot
addappid(294917, 1, "4fa5321f5edd3a3a083292bf949c4dd60f055fdf4038fa9e42f5776c74cb45fd") -- Rocksmith 2014 - Additional DLC 18 (294917) Depot
addappid(294919, 1, "f05ab40a8fce797cc9d3ac7a42ffeb2c63c34614bf6dfe43ff6088cd906b5435") -- Rocksmith 2014 - Additional DLC 20 (294919) Depot
addappid(294920, 1, "57254087dffd6a9eca6e3a18b323d29c9f0695a6df7ae5c347c6ef88c2f9e73e") -- Rocksmith 2014 - Additional DLC 21 (294920) Depot
addappid(294921, 1, "8a8909d96cc458f21aa1b48360ff3fae21d9f4104334c010f201d543dd343f57") -- Rocksmith 2014 - Additional DLC 22 (294921) Depot
addappid(294923, 1, "c8267caf7cc8f7de6956344431179d769c18ea2d684ac04ec1052935ab23a5f0") -- Rocksmith 2014 - Additional DLC 24 (294923) Depot
addappid(294924, 1, "11544bf473015ff79b0c6154380e1a0e5b830b598eaa4357b4c1108597a7203b") -- Rocksmith 2014 - Additional DLC 25 (294924) Depot
addappid(294925, 1, "3c2b435361d816df37a4f19a9066bbc6b78b197c939a1165d1de9d5bfef20b13") -- Rocksmith 2014 - Additional DLC 26 (294925) Depot
addappid(294926, 1, "8bc2e3cb51353813940fb9f3305c07d374027988c519132dd50eeefd1dce9675") -- Rocksmith 2014 - Additional DLC 27 (294926) Depot
addappid(294927, 1, "f7bafd9c6000565fd27389ef7aae6c0933a97684bdcb865a611c8ade24f1170f") -- Rocksmith 2014 - Additional DLC 28 (294927) Depot
addappid(294931, 1, "dc63f39a227ea9558724fd921c55d20d6b576c86950f5daf5e5ca49a903f927a") -- Rocksmith 2014 - Additional DLC 32 (294931) Depot
addappid(294932, 1, "91d1a73a96f4a2586028ab049042294445c8b1d555f2817e618401c89ce2e3c4") -- Rocksmith 2014 - Additional DLC 33 (294932) Depot
addappid(294934, 1, "1a746933cfe72f7051316d8db955aa486214b9732e2ab9394ab8333ea22c3146") -- Rocksmith 2014 - Additional DLC 35 (294934) Depot
addappid(294935, 1, "2eb785118d1294ecff4e7e0dc05956426eaf8d169baa428eb7e2373f3ab1cabc") -- Rocksmith 2014 - Additional DLC 36 (294935) Depot
addappid(294936, 1, "2ec4216d28a7f2c208b4b420322efbe7368814f36f8271cbce67fd80593235ae") -- Rocksmith 2014 - Additional DLC 37 (294936) Depot
addappid(294937, 1, "74a7f11758a6d8a166a41069496f38f8f4f2a98ba6769395918af7a895922d4d") -- Rocksmith 2014 - Additional DLC 38 (294937) Depot
addappid(294938, 1, "aabff148f9b8a23408b65fd499ba1bc7a717df6262a18b44c8cd86ea2372d130") -- Rocksmith 2014 - Additional DLC 39 (294938) Depot
addappid(294942, 1, "7b1a16a6ee17ce40e600a70368b29a18db8841819d96ec87b5a77869bf293d2d") -- Rocksmith 2014 - Additional DLC 43 (294942) Depot
addappid(294943, 1, "615d68276ddbb123839127a283f277950bbf7d6cac4789e23fc2a9153d0d194b") -- Rocksmith 2014 - Additional DLC 44 (294943) Depot
addappid(294944, 1, "51226fd4131abf9ae0fc8fae863940783d5eb302dfd66e4ce89f9864bd37e5ea") -- Rocksmith 2014 - Additional DLC 45 (294944) Depot
addappid(294945, 1, "8ca2ea180e5e5c22ab9fee692cff55fe80cd7ad78b7b8d73581d0d85dd8ecd6b") -- Rocksmith 2014 - Additional DLC 46 (294945) Depot
addappid(294959, 1, "6c3df189c8844d53439754799f6993c52e9fe9bbced9c05de72312f001223525") -- Rocksmith 2014 - Additional DLC 60 (294959) Depot
addappid(294963, 1, "a8504b028a2126a9fed6a160ac3e9de4b5fe4179dd9f249eaf079ce97e70867a") -- Rocksmith 2014 - Additional DLC 64 (294963) Depot
addappid(294968, 1, "2472b6b3b92ed1ae1f5b48eb750553989b2e4725a5e79316b519d666dbe46515") -- Rocksmith 2014 - Additional DLC 69 (294968) Depot
addappid(294969, 1, "023e6b66c941690e35eb8e124a871f520470a00cc87b9cdf5bb3e34ec58b4e38") -- Rocksmith 2014 - Additional DLC 70 (294969) Depot
addappid(294970, 1, "388edc67811bffae4258ab981c410b476791037a65bc0e46c2f188825c9a0904") -- Rocksmith 2014 - Additional DLC 71 (294970) Depot
addappid(294978, 1, "707495fb232ce6980393268ce5597827f8294d42f61b5dabe1df85a27ef6190a") -- Rocksmith 2014 - Additional DLC 79 (294978) Depot
addappid(294979, 1, "d852b851168d853fc1c3ac9ee5aff8d68f6051679a1f380870dccdcc48fd4805") -- Rocksmith 2014 - Additional DLC 80 (294979) Depot
addappid(294980, 1, "6f26c17ef3fc334ef624dba212b7bfa1aac7ed7223f905f78cb0297ceaf868f9") -- Rocksmith 2014 - Additional DLC 81 (294980) Depot
addappid(294990, 1, "c7996fa945508019307df69e2add339aeb40181a9b0e0cc55b41a34b1db10ee0") -- Rocksmith 2014 - Bachsmith - Rocksmith 2014 - Additional DLC 91 (294990) Depot
addappid(294992, 1, "1d70c4ca67dc34ac3a4ba3be9efa01cd2e9f5a6a2b601458d43f35248bfa7be5") -- Rocksmith 2014 - Additional DLC 93 (294992) Depot
addappid(294993, 1, "f3e533f3cfa061f473c4d7527634f10ea3a6b4274762bed13916510a06df8507") -- Rocksmith 2014 - Additional DLC 94 (294993) Depot
addappid(294994, 1, "941f05e7a89d77c43753d546372fa16015abc870202b54ab3ad4da1b637fbc30") -- Rocksmith 2014 - Additional DLC 95 (294994) Depot
addappid(294995, 1, "3c1fd397c356eb8d1a4f04f996432672eae4970f9f763db90ee3a12eba078801") -- Rocksmith 2014 - Additional DLC 96 (294995) Depot
addappid(294996, 1, "7b16250d578b701e6ae17d4c4cef5022c2f02b2204615da376bf8d074f5886cb") -- Rocksmith 2014 - Additional DLC 97 (294996) Depot
addappid(294998, 1, "13efc308e4433efc49fbd8ddf2f0eecbffbf0020c550872113b2a0e1646109c2") -- Rocksmith 2014 - Additional DLC 99 (294998) Depot
addappid(294999, 1, "2bbde993ff8f7d2f688c3c532d662d4cfac42c40453f1ad0be83b60b19d4f190") -- Rocksmith 2014 - Additional DLC 100 (294999) Depot
addappid(295000, 1, "c3ee43b2e0b37331716be6bf65f30f15040e7d227a63d113c343f695fd72df1b") -- Rocksmith 2014 - Additional DLC 101 (295000) Depot
addappid(295001, 1, "a820bb10b62bda785c6123110b85709f3201f43f8dcb44737910e93201d2834c") -- Rocksmith 2014 - Additional DLC 102 (295001) Depot
addappid(295002, 1, "dbe7d87483d22c22db3286359b1adba4c4cc106d38dc7ae6c2d1ea402e0787a3") -- Rocksmith 2014 - Additional DLC 103 (295002) Depot
addappid(295003, 1, "23e424ca68a8fccb1874965b8bd61d5ccd93c3680324317a34d2b017bb1840b6") -- Rocksmith 2014 - Additional DLC 104 (295003) Depot
addappid(295004, 1, "aac7b21bb525712790515afabe30985f9406b6ccc1d2496acc3d9375cef1b86c") -- Rocksmith 2014 - Additional DLC 105 (295004) Depot
addappid(295012, 1, "87c44c0d54f671aaba71a7f725cc25dc2b95db579b73c1b0b1c6db5c772c7cc3") -- Rocksmith 2014 - Additional DLC 113 (295012) Depot
addappid(295018, 1, "7e1eb0aa987fdbac09db6c2a0c2358e8a49a747df9b7ae3f3839a912be8892a9") -- Rocksmith 2014 - Additional DLC 119 (295018) Depot
addappid(295019, 1, "f963dd5d1e48b5e271613ea9fdd433d4b390c20d4fb8ccad7e5b3323ae22eb90") -- Rocksmith 2014 - Additional DLC 120 (295019) Depot
addappid(295020, 1, "2e6d6f43ca5d38447dee984162d75f695abc225228f33f93a8596735bc1efef6") -- Rocksmith 2014 - Additional DLC 121 (295020) Depot
addappid(295021, 1, "e880f37989e1750c84dc6a64fd14d20d498d600281c40f0fa29dcec01c925e05") -- Rocksmith 2014 - Additional DLC 122 (295021) Depot
addappid(295022, 1, "c21695eba4c97793d3d9c379d9b6deee985def4ad8e9117e6d86023ff7fbe11b") -- Rocksmith 2014 - Additional DLC 123 (295022) Depot
addappid(295024, 1, "5ea33d9b57e426c8e1d0e999d54044925758956dc5413128c91d41beecd520b6") -- Rocksmith 2014 - Additional DLC 125 (295024) Depot
addappid(295026, 1, "bdc6217c82e697bdc2a10024b553fd6e6b58d2d3d1112e57fc3c7a27f32f0110") -- Rocksmith 2014 - Additional DLC 127 (295026) Depot
addappid(295028, 1, "87a06499fecf1c522ad9e682e3e9a324f254e193589061e49d770db09a824d43") -- Rocksmith 2014 - Additional DLC 129 (295028) Depot
addappid(295030, 1, "f12e323962907b53bb6708ac8ebb4c0b1828ffbdd09dcd46c6b38ca919d5b598") -- Rocksmith 2014 - Additional DLC 131 (295030) Depot
addappid(295034, 1, "14e5ba48973657e8b2195b923393afe11733450e3904265ce9cfd69569649b42") -- Rocksmith 2014 - Additional DLC 135 (295034) Depot
addappid(295035, 1, "6e3b778feb004405fa8e6c31cbb8d2e7972b416731103443f4756c9026f8c4da") -- Rocksmith 2014 - Additional DLC 136 (295035) Depot
addappid(295036, 1, "fe5661363a35c648429e1e0096f82946164816dbd6d11e6ad2b1015f585a586a") -- Rocksmith 2014 - Additional DLC 137 (295036) Depot
addappid(295037, 1, "d55d5f05dd7c3d15ba1ee27ac0cbc5030816ae1cbf964eb5d2733e4de138e2cd") -- Rocksmith 2014 - Additional DLC 138 (295037) Depot
addappid(295038, 1, "e19d31005958d05de893be70c23ca88e1492e0ec2e1c5ccb8c03a7a04339065a") -- Rocksmith 2014 - Additional DLC 139 (295038) Depot
addappid(295039, 1, "da1b7f4fb6a868a4cadffa22d1e84e9f29618c59387ecfda250b44b941999de3") -- Rocksmith 2014 - Additional DLC 140 (295039) Depot
addappid(295041, 1, "9a029a7b90e616034dead8ce245c831264340fc7a1b627a471d6b106e3ad1ca8") -- Rocksmith 2014 - Additional DLC 142 (295041) Depot
addappid(295042, 1, "2f2755db212a0a59a44f2d69a12816599490a147b0b55bf93fcc60ea0d68abdd") -- Rocksmith 2014 - Additional DLC 143 (295042) Depot
addappid(295043, 1, "c6b97c7d3a357dfec43a06df44bc1af84910ec89b3a67c3d4371025ef07f89cd") -- Rocksmith 2014 - Additional DLC 144 (295043) Depot
addappid(295045, 1, "df47def81693f7ec13193a2d4084bcdd739b6fe9b78c45b44565b058849790ab") -- Rocksmith 2014 - Additional DLC 146 (295045) Depot
addappid(295046, 1, "65b309533e6b9c352a383f48afd1504e149484716ff4b7cca9aeb86b32349c7e") -- Rocksmith 2014 - Additional DLC 147 (295046) Depot
addappid(295047, 1, "3e7c87911f56efcf67556211f765a939c637e1002305b7dcf39ad1a5af3f264f") -- Rocksmith 2014 - Additional DLC 148 (295047) Depot
addappid(295048, 1, "6c842ac214d855426041c0fb0aa86916f38b981b6cdf61d3a3a5b8785c384502") -- Rocksmith 2014 - Additional DLC 149 (295048) Depot
addappid(295049, 1, "edddb511d324e06e12ae20ca8e0b7e099df0ef68c2315a6fc743780db7ac535b") -- Rocksmith 2014 - Additional DLC 150 (295049) Depot
addappid(295051, 1, "c53220bd7a99335fe148f563214235c703d54a713d8fbd8e2051483d530e53a2") -- Rocksmith 2014 - Additional DLC 152 (295051) Depot
addappid(295052, 1, "189817faf27dcde9b5408d40dce0ecb8aa5a5f760178c21d791b04247c5ef663") -- Rocksmith 2014 - Additional DLC 153 (295052) Depot
addappid(295053, 1, "4f549f3a4f269327407cf91aff9cfb87cc0ce41ea443c43edf353fea8a605c18") -- Rocksmith 2014 - Additional DLC 154 (295053) Depot
addappid(295054, 1, "9154d9580cab0aa883ba8b2162f7a226d5b2b8be86c4d6b8692ead23f509991a") -- Rocksmith 2014 - Additional DLC 155 (295054) Depot
addappid(295055, 1, "33f9664fb3ebc6fef51b60c8cae208d5d6808264703116e7b99115fb49253ca9") -- Rocksmith 2014 - Additional DLC 156 (295055) Depot
addappid(295057, 1, "29cf407ed912474bdba6f8ac7ddb0ea78f78337b0b1ae71e46269fe33aa48462") -- Rocksmith 2014 - Additional DLC 158 (295057) Depot
addappid(295058, 1, "76141712882cfbc447d200cfa24dcb884dbc973f1726286de8edcf1243888450") -- Rocksmith 2014 - Additional DLC 159 (295058) Depot
addappid(295059, 1, "e8b1385416bb1306b39d1d985bd97176ea15ee5e1467814c659c4daa6173065a") -- Rocksmith 2014 - Additional DLC 160 (295059) Depot
addappid(295060, 1, "7207ea52be8c46ad3fd0d9180ef01cd883381047d9fbd48cf5c3c0f2e4057c61") -- Rocksmith 2014 - Additional DLC 161 (295060) Depot
addappid(295061, 1, "df387a80fcef5666063de99818922db2024aff7a4509032e4a52cc946ec951ba") -- Rocksmith 2014 - Additional DLC 162 (295061) Depot
addappid(295063, 1, "7709007cd56539d4a6d0817e12db9efa0b7e78895dbeac227e24e4ac5e736d24") -- Rocksmith 2014 - Additional DLC 164 (295063) Depot
addappid(295065, 1, "be127cccef5eb2696a029d41473f269d94314befb06f8169cf112f75ed860e25") -- Rocksmith 2014 - Additional DLC 166 (295065) Depot
addappid(295066, 1, "74c631091a5fc2e8994d221262c26a7aa70566071b849bb2fdd5710e08b16949") -- Rocksmith 2014 - Additional DLC 167 (295066) Depot
addappid(295067, 1, "75f7d4f52102eb8a422a4e58f305fc472858edd928417f6c09ab970540ebf717") -- Rocksmith 2014 - Additional DLC 168 (295067) Depot
addappid(295070, 1, "5c52436735158639962bd803ac10b80816e9bffd97221515404b697714ca3c89") -- Rocksmith 2014 - Additional DLC 171 (295070) Depot
addappid(295071, 1, "caec455e4d5d7dbeac4bb2b80622e8af53f741388072b6db65dcf6e6398671c7") -- Rocksmith 2014 - Additional DLC 172 (295071) Depot
addappid(295072, 1, "bcc4d149110aa3977cb0e2e6f4fa986122f84ec6300a04fce2335e3d0bdbd35d") -- Rocksmith 2014 - Additional DLC 173 (295072) Depot
addappid(295074, 1, "4e89b6321c9b2af37a8d11c8961a4afa6c07fdef3fa83cdd7396a79ff6b7a451") -- Rocksmith 2014 - Additional DLC 175 (295074) Depot
addappid(295075, 1, "31f482e26dfb8fea87af4c1dd8e48c4a5b47904fefb81dbe8833031e7478384f") -- Rocksmith 2014 - Additional DLC 176 (295075) Depot
addappid(295076, 1, "600179418653fc0b99ac18861d77483f8c98d05a6832442e4bc5b139497a6416") -- Rocksmith 2014 - Additional DLC 177 (295076) Depot
addappid(295078, 1, "912a3a39cf90b511349fc3c9a52774d979f5b284c1fc732b1643c59ccefaac9e") -- Rocksmith 2014 - Additional DLC 179 (295078) Depot
addappid(295079, 1, "cab566d6879788252e5fbccd9954b0ebac9426c5ecdbae720bd79f128571fe17") -- Rocksmith 2014 - Additional DLC 180 (295079) Depot
addappid(295080, 1, "2764cd87d4bee4826dc88bbfd6d2c5a08ca8aa473004c5d838cd83b6e2c07624") -- Rocksmith 2014 - Additional DLC 181 (295080) Depot
addappid(295082, 1, "adc0c5dd9268eb53af8a6d983537c37c936925362df067233c9d6909776f1ad9") -- Rocksmith 2014 - Additional DLC 183 (295082) Depot
addappid(295083, 1, "d5241a3bc6a9ea30914d2896bcf23e69e70fe6fa3f8aee4ebbe3b3bb7530eb06") -- Rocksmith 2014 - Additional DLC 184 (295083) Depot
addappid(295084, 1, "14831b54531601f5a0423c6e1a0e295516a982b1811735a2ed8707201f292ddc") -- Rocksmith 2014 - Additional DLC 185 (295084) Depot
addappid(295087, 1, "164b3d235947b7c30fe3334c01d2c140c88a55d604fd88f4947396937533c65e") -- Rocksmith 2014 - Additional DLC 188 (295087) Depot
addappid(295088, 1, "f84a5690456348b54a125915e06b1b81403f27f1c761a5c2b47e32c7dc257fae") -- Rocksmith 2014 - Additional DLC 189 (295088) Depot
addappid(295089, 1, "096424b3d6653c739a4bc446a87e93d26f2f1e33fc8597720915b673bf714d27") -- Rocksmith 2014 - Additional DLC 190 (295089) Depot
addappid(295090, 1, "9d9c14615ae6017d22f5cf16903332801571d907d64a6e73be20b71a5a25bdf3") -- Rocksmith 2014 - Additional DLC 191 (295090) Depot
addappid(295091, 1, "895546500eddee56403a29b138cb378e3436c66cc11b7720acddbe8cb073b8d8") -- Rocksmith 2014 - Additional DLC 192 (295091) Depot
addappid(295092, 1, "b3cd90b0c2ca697bf8cdebe3cfb87469e18d79273e3b399511da3873e49ec63b") -- Rocksmith 2014 - Additional DLC 193 (295092) Depot
addappid(295094, 1, "388f4c05ec74db202d5589c05aa777547192aa60050d92a0821725de23e2628a") -- Rocksmith 2014 - Additional DLC 195 (295094) Depot
addappid(295095, 1, "4853aecf243a8563ecb72f42a5ec9fa7fa87e669beb3741bc86c7870d2b8f2b7") -- Rocksmith 2014 - Additional DLC 196 (295095) Depot
addappid(295096, 1, "0492600c2b486dd7a11503aa393a58e483831c790d3a43d8259257d2d0ad8b1c") -- Rocksmith 2014 - Additional DLC 197 (295096) Depot
addappid(295097, 1, "6f2b98fa4f10c390f4874ad803494a825b6465b53c4ebd8534d21eaa23273dfb") -- Rocksmith 2014 - Additional DLC 198 (295097) Depot
addappid(295098, 1, "522d102d99abb60e0672edb00914b054d1e173b1101f371b2a43ca71cb4c873e") -- Rocksmith 2014 - Additional DLC 199 (295098) Depot
addappid(342751, 1, "bec0a3954cac62efde7f27b265ec37cd312febcc50906782538128b9d209ea9d") -- Rocksmith 2014 - Additional DLC (342751) Depot
addappid(342753, 1, "f78027731df81db0c01e7d0eed714e089a267bfbc1d75dc76d900c5e8fd63291") -- Rocksmith 2014 - Additional DLC (342753) Depot
addappid(342754, 1, "0c18189c528bc53270be23d5005a98cfc63493119c63a6efa219acfe71593ebe") -- Rocksmith 2014 - Additional DLC (342754) Depot
addappid(342755, 1, "423b048f8f562ad75ba63d5aad5c5221f66aed859e5d75c8c4e2ba0575932d6b") -- Rocksmith 2014 - Additional DLC (342755) Depot
addappid(342756, 1, "9b337d9f531a78a2d87bb6bb9da49d0bc1b19f90e0454271e90e0d0f5799234e") -- Rocksmith 2014 - Additional DLC (342756) Depot
addappid(342757, 1, "d970a3fbdd0eb2e54e159c6c66d08f6ada7a9601fbde11e9deb3198cb79a0de8") -- Rocksmith 2014 - Additional DLC (342757) Depot
addappid(342758, 1, "3184114996e58f622456b2bd533c706d345802d9b360ec0f5546049f4e6d9f0d") -- Rocksmith 2014 - Additional DLC (342758) Depot
addappid(342759, 1, "0a7a13045fac946dcbb4f6cacba95a6266d6cfb3d8a7500974d82f1133ad04bb") -- Rocksmith 2014 - Additional DLC (342759) Depot
addappid(342761, 1, "26b38b24b5a9c21dd49e5451e05c929815287928603c47f0fcb58bca3a60d937") -- Rocksmith 2014 - Additional DLC (342761) Depot
addappid(342762, 1, "97a4d98d247da8944ac2fe1fd5eadca1cb85fcf038302999bc4a9a826d880b14") -- Rocksmith 2014 - Additional DLC (342762) Depot
addappid(342763, 1, "2b75417d9b3397ebcc28d5024d7ec12fbfb1fe5ef26e4cd6e63ca9787033d55e") -- Rocksmith 2014 - Additional DLC (342763) Depot
addappid(342765, 1, "fcbdc2c793917e4630dbfa9a37d70d2a5ece9c3f64fe941aaf9b008da1df6ecf") -- Rocksmith 2014 - Additional DLC (342765) Depot
addappid(342767, 1, "e3a92ea5129b620fb55a6fc6750409115f634e444e1b972ae54d4010bd684f92") -- Rocksmith 2014 - Additional DLC (342767) Depot
addappid(342768, 1, "7637305153880281d513f3015517b9de11b3c31c4cc6f1723215e1e4ad47f1a1") -- Rocksmith 2014 - Additional DLC (342768) Depot
addappid(342776, 1, "646a023838ce32f73a9084c280639ba69f80910839eaabf1f2d4105d33c78eba") -- Rocksmith 2014 - Additional DLC (342776) Depot
addappid(342777, 1, "d5441c0e646aeeab6fb0dbd28eaa9e28e7fc63ff6871c5af86d4fe1340c567a5") -- Rocksmith 2014 - Additional DLC (342777) Depot
addappid(342778, 1, "30a7418a53f846187889908bea83acdde6373a44f8376d60adfb96cca63831a2") -- Rocksmith 2014 - Additional DLC (342778) Depot
addappid(342786, 1, "23b6c71680d8ad14ae8d056f7782ca5301c8e88e16116d1cf0a759f54d8e59bc") -- Rocksmith 2014 - Additional DLC (342786) Depot
addappid(342790, 1, "cc28c797ac2f41d65a1fa9d47bce78d178ffaff789107fba66805849585d899c") -- Rocksmith 2014 - Additional DLC (342790) Depot
addappid(342792, 1, "08d79c4491851bbb30558b36b5118d95f67f3ffc44a7d168a61897d1f846bbd3") -- Rocksmith 2014 - Additional DLC (342792) Depot
addappid(342796, 1, "2539ac0e31601895b16f70fb4582f025b68520d160f4fa6840f6c300acdaede1") -- Rocksmith 2014 - Additional DLC (342796) Depot
addappid(342797, 1, "7da27deb30879e9abe1eb142edc8909b081a3970665db9995b6bfcf2722132c8") -- Rocksmith 2014 - Additional DLC (342797) Depot
addappid(342798, 1, "955d5e43477da2ee2dcd78648f83ef2c84f87775af25535f1fe5d4642b971940") -- Rocksmith 2014 - Additional DLC (342798) Depot
addappid(342799, 1, "b94d4723887c733e2f4788c863bc3847a334be16dc59432e31ae6a33193dd220") -- Rocksmith 2014 - Additional DLC (342799) Depot
addappid(342807, 1, "9675659b42b58ecdd4c539bffb9d6fee8ad920d52696ebe62be5f29a8eb44bbd") -- Rocksmith 2014 - Additional DLC (342807) Depot
addappid(342810, 1, "342decb1525f56577e1b891bcfe3f4b5210a7b0e835c39a0056c973530a1dbeb") -- Rocksmith 2014 - Additional DLC (342810) Depot
addappid(342816, 1, "f47b429445b2d8e0c9300fe9b7d6389b6cd9009ee22d9c045aed4affe8f9f85b") -- Rocksmith 2014 - Additional DLC (342816) Depot
addappid(342817, 1, "9b36966d725ed6b998845ccf9ebb8520fe4a1674a055910b09cf6272129bcbcb") -- Rocksmith 2014 - Additional DLC (342817) Depot
addappid(342819, 1, "3dff5a7256bdc8d0ff1e86a4fb65096599f8a5fd02b38de6f64283a5857e6f5d") -- Rocksmith 2014 - Additional DLC (342819) Depot
addappid(342820, 1, "3ae425f9be1be98c79645039cd854e56ef9a431a17b234430122f1a596971376") -- Rocksmith 2014 - Additional DLC (342820) Depot
addappid(342822, 1, "3710814a1cf88e0773bd6e0af0fcc73a04211ff08cc8c7f4bb027c3788f0bcd6") -- Rocksmith 2014 - Additional DLC (342822) Depot
addappid(342823, 1, "9204fb02408daedbe7acbfdab6b20bec81f356cc0076eedfaabd21a577bd6538") -- Rocksmith 2014 - Additional DLC (342823) Depot
addappid(342824, 1, "d2238cb610400680a9cfb8a9bd0cc4b94bdba76b3c2f61273f1b5ecab0d86acf") -- Rocksmith 2014 - Additional DLC (342824) Depot
addappid(342826, 1, "86af9c977324317c4d1cbd5566977f3945c20fe057022c6c830bc7d16f47ebf6") -- Rocksmith 2014 - Additional DLC (342826) Depot
addappid(342827, 1, "d09c9e2f478f6f3f38da6a562f52d52695366c581762b3295997f760e2aabbfa") -- Rocksmith 2014 - Additional DLC (342827) Depot
addappid(342828, 1, "45044060bd129d9e2cbf3fb3b7904cd1a1a1753f1e21f95cbac31b36c25e9732") -- Rocksmith 2014 - Additional DLC (342828) Depot
addappid(342829, 1, "80907ba37d021a1075aa4533f708558b8b100f926b99c7207d341f5d6a4b2f07") -- Rocksmith 2014 - Additional DLC (342829) Depot
addappid(342830, 1, "cae83ba546616edfcdf194518b4997f1d51cbf8a6380c6e90509acf38cf20e3b") -- Rocksmith 2014 - Additional DLC (342830) Depot
addappid(342832, 1, "b005df63aba6ef95389877b4fdee8cd12cfab708d378519c86c3e80d89dcff18") -- Rocksmith 2014 - Additional DLC (342832) Depot
addappid(342833, 1, "6ef0d2e9471d75f65508af30102076eb8a8117b3ff76e4f82f0b699a0af9037f") -- Rocksmith 2014 - Additional DLC (342833) Depot
addappid(342834, 1, "8817f3c79c470bfadfbe213a27daa47f5bf4599b0544f973438793431363f6ae") -- Rocksmith 2014 - Additional DLC (342834) Depot
addappid(342836, 1, "36be77c3e4308e7331721e04f7beb05cb341cf0043e7befe6d7b05b02eb0708d") -- Rocksmith 2014 - Additional DLC (342836) Depot
addappid(342837, 1, "d1a04d804618e2f1ceeec9bc0fa1bd1ed8dd403d5b2479afaf67470757c7522c") -- Rocksmith 2014 - Additional DLC (342837) Depot
addappid(342838, 1, "8bd9c23217b85021fb92b5e76370038a1e8251cd153a6a95b33df2021d213cb5") -- Rocksmith 2014 - Additional DLC (342838) Depot
addappid(342839, 1, "ba38dd3f05e67bcfdca73d4f7ca7a85da0240e073c14176ed54b2c2da37a6ca0") -- Rocksmith 2014 - Additional DLC (342839) Depot
addappid(342840, 1, "a96694f4d319f30d80a43ecba3be8940eda583d574bd487263211b7d9c47c31d") -- Rocksmith 2014 - Additional DLC (342840) Depot
addappid(342842, 1, "6d29be87c4a7bd80663b42db9d8aa2dad74b92b29291baafdd622aeb0fa54eb3") -- Rocksmith 2014 - Additional DLC (342842) Depot
addappid(342843, 1, "caa30facdd213a38d25ccfd3c40e06ed65074b67e580f872452bf8800fe0eb87") -- Rocksmith 2014 - Additional DLC (342843) Depot
addappid(342846, 1, "7aa9c51fae1b4033321e598d96a1c3b427d2b23a9721f06699bf2b00045ba904") -- Rocksmith 2014 - Additional DLC (342846) Depot
addappid(342847, 1, "a035c4dc39f4c50bb0abbfcfd659b35e991eeb324d17c46fba907e42bdd08831") -- Rocksmith 2014 - Additional DLC (342847) Depot
addappid(342848, 1, "e8527a14a767f8d392c6edb6e21d2450cb1241964e32661937f6c436b02bf615") -- Rocksmith 2014 - Additional DLC (342848) Depot
addappid(342849, 1, "0022a3733c977c526385007508029bac0e9c21e5ad98424e86dad335a42b3234") -- Rocksmith 2014 - Additional DLC (342849) Depot
addappid(342850, 1, "3ed883631d9da92ef186a835e9541eb7a8a945a88071689cd5ba2612ae7c53e2") -- Rocksmith 2014 - Additional DLC (342850) Depot
addappid(342853, 1, "fc4d2be2e239546cc247432edd237c2a74acf0101f24c12c6750e53b76edde84") -- Rocksmith 2014 - Additional DLC (342853) Depot
addappid(342856, 1, "c1e739ba9934f4cc61f450288cac19c3093bc9829dcd922e121f9f98c85bf4e8") -- Rocksmith 2014 - Additional DLC (342856) Depot
addappid(369763, 1, "9fbc764393b01582cd2e9d98516ce55fdbd39d8555afc5317dcb9fc03c9fb36c") -- Rocksmith 2014 - Upcoming DLC4 (369763) Depot
addappid(369764, 1, "125fd248de004eb2020a82e2fb232ddd5e2cabf828be71065a1607b81079bdf5") -- Rocksmith 2014 - Upcoming DLC5 (369764) Depot
addappid(369765, 1, "a5c4e755d68ad267c4c7e3875d559de671db59ff1e8fb99fc83494fde0f45643") -- Rocksmith 2014 - Upcoming DLC6 (369765) Depot
addappid(369766, 1, "c7368370bb7be6d374e7cb2fae125fa2024dd988238adace7790c26d3bb56c1e") -- Rocksmith 2014 - Upcoming DLC7 (369766) Depot
addappid(369770, 1, "271c559ecdd3f20ed4264fc0c0c07735f9520ea9a675047d2ac95a7e64ccee97") -- Rocksmith 2014 - Hank Williams - Im So Lonesome I Could Cry - Rocksmith 2014 - Upcoming DLC11 (369770) Depot
addappid(369772, 1, "6f1924bcf1e9dc57f48470b9872d7f7207c5fc77098731b650df910bbe0d3a08") -- Rocksmith 2014 - Upcoming DLC13 (369772) Depot
addappid(369773, 1, "401ab20ca0fcd75280933d6f70517e73609f6a3d3fd9d19bdf7ff32d566fd095") -- Rocksmith 2014 - Upcoming DLC14 (369773) Depot
addappid(369774, 1, "3a3dc84063e8b53b643508fe7a2c326ba96729506165027ab055c3bd38e4c784") -- Rocksmith 2014 - Upcoming DLC15 (369774) Depot
addappid(369775, 1, "8695bb36e6d6f4acb3b9c923de688bfce0031e3ae4358f067062ee2c95c81e67") -- Rocksmith 2014 - Upcoming DLC16 (369775) Depot
addappid(369776, 1, "516d12fd79cfaba211f3de7b0a2d94a6f8fe3e6f40ba6c411af438ea1ff352ca") -- Rocksmith 2014 - Upcoming DLC17 (369776) Depot
addappid(369778, 1, "7684ea61fb29aa1df63d06458c2bd034a0c86fec6730579ed04dfe6daf5d14a9") -- Rocksmith 2014 - Upcoming DLC19 (369778) Depot
addappid(369779, 1, "2ebf112af653dd9ff4eb8def51083535e72c706b3820e9af5f595a330924c7b3") -- Rocksmith 2014 - Upcoming DLC20 (369779) Depot
addappid(369780, 1, "e0f8c89980fcaf491a49af6cb30d9ba300953b1a008a2abcc02eaf7db9ff3cfe") -- Rocksmith 2014 - Upcoming DLC21 (369780) Depot
addappid(369783, 1, "efbed200b4178e0cdc339726e2fa9d84bd01c6b7c9e7499a9c62a880054a903d") -- Rocksmith 2014 - Upcoming DLC24 (369783) Depot
addappid(369784, 1, "4f525269ecc102181ad3ef204d2595b8346cf481bc375bfc3b2a3fa966b7cafb") -- Rocksmith 2014 - Upcoming DLC25 (369784) Depot
addappid(369786, 1, "2b3e431eedd153214614735bd967da1a05fc5c723eb9a00ba9c472376624ccde") -- Rocksmith 2014 - Upcoming DLC27 (369786) Depot
addappid(369788, 1, "db30a1df5db10261471d794b7b6332193056610f69455b39ad96fa509301b4f6") -- Rocksmith 2014 - Upcoming DLC29 (369788) Depot
addappid(369795, 1, "6a7dba751d184d177dc8b15a6d7765725fb72afb7c0498224369786b8afc0608") -- Rocksmith 2014 - Upcoming DLC36 (369795) Depot
addappid(369796, 1, "ff402a2727e6dce3635f23921d0a2915058f3c9494ed8881120fb7810cfdf583") -- Rocksmith 2014 - Upcoming DLC37 (369796) Depot
addappid(369803, 1, "acf55ad101b4f664bbf3b344cb432c4bdd451ecd7a000ba520c97d39c11836e2") -- Rocksmith 2014 - Upcoming DLC44 (369803) Depot
addappid(369804, 1, "90c891fca0b2b18c5303f8c66893332db4fd4738775bda1ada31183a395ac68e") -- Rocksmith 2014 - Upcoming DLC45 (369804) Depot
addappid(369805, 1, "81280ed11d6573bedd78470f6868b4ac5af0425b049e8069fc690b981d056755") -- Rocksmith 2014 - Upcoming DLC46 (369805) Depot
addappid(369806, 1, "9a330b0a594bb7a4cc37f81010be7334aa316fe9e54df3d4412b0f4a92fd95f2") -- Rocksmith 2014 - Upcoming DLC47 (369806) Depot
addappid(369812, 1, "cb6594b23c66c57490d7510f32bba0ce15c1c215cbcc2f514ba9f3782f25fecf") -- Rocksmith 2014 - Upcoming DLC53 (369812) Depot
addappid(369820, 1, "7c899c72c7cb20fdf336bbaba20009f7db7bb8cd3a12825c9e0b8cc4199562a0") -- Rocksmith 2014 - Upcoming DLC61 (369820) Depot
addappid(369821, 1, "6d5180b969358bcc321f08a7ca947116e033cd817d0a7799ab04454139cc3395") -- Rocksmith 2014 - Upcoming DLC62 (369821) Depot
addappid(369822, 1, "d058b57f4db1718fb72379bd6c2bf66df576f3bcd37c8f3ba902f3522df9f475") -- Rocksmith 2014 - Upcoming DLC63 (369822) Depot
addappid(369824, 1, "f631a867f53aaded67e6c3b95ccae7b135124be8ae4d2aac7ee19fb42df26804") -- Rocksmith 2014 - Upcoming DLC65 (369824) Depot
addappid(369825, 1, "776cee8c171111cf4b06f7c02d838b9e4c7013a98f81eb4995a94f1de73a9a32") -- Rocksmith 2014 - Upcoming DLC66 (369825) Depot
addappid(369826, 1, "667efd8897a2de1d6ba9c840a0fc145dfbd3e6bdad188ef4b1b574a5c94aead3") -- Rocksmith 2014 - Upcoming DLC67 (369826) Depot
addappid(369828, 1, "ffd3b9eb71434bfd99628e386ea87c1cbc4f84e91aa80b5d4dd1d457e8fd1f32") -- Rocksmith 2014 - Upcoming DLC69 (369828) Depot
addappid(369829, 1, "f88b82f81a68c3cebf39f5bbcd10680f4d69f5c3d47e4164fa73279d288e2653") -- Rocksmith 2014 - Upcoming DLC70 (369829) Depot
addappid(390360, 1, "34b6a6687f76f9370d5d81c811e4c02fa881c8c9f41967e3b133ad8de404ce2c") -- Rocksmith 2014 - DLC1 (390360) Depot
addappid(390362, 1, "574196ba09f36ee57ed82e2e30fa50efbf74511efcfca9db14a9ba1edf4bc1fb") -- Rocksmith 2014 - DLC3 (390362) Depot
addappid(390363, 1, "f836b3d8ad3c4e05fe329bdb459a80b6453c9602477b41cd2607514599a34fb1") -- Rocksmith 2014 - DLC4 (390363) Depot
addappid(390364, 1, "83dd5d18256461fed0f25f7304eb330dc8f767eba336c8af4cd93eeab34fc877") -- Rocksmith 2014 - DLC5 (390364) Depot
addappid(390366, 1, "468a661a395a597db1ccedf8c9df4051d288195d6ee864159c619b04bd51b81b") -- Rocksmith 2014 - DLC7 (390366) Depot
addappid(390367, 1, "e99fef276b92c08e1174574c089ae3df6bf41b889b47e73ae0bd6627b9232b14") -- Rocksmith 2014 - DLC8 (390367) Depot
addappid(390368, 1, "0493473c77b5debbcdd11fa5468e5434d973ede3669af324389c2d2bd30b92a6") -- Rocksmith 2014 - DLC9 (390368) Depot
addappid(390370, 1, "54ca77a0bc406b907ced8f58b282b7eb7de71ba06c378adaac4a53159630774d") -- Rocksmith 2014 - DLC11 (390370) Depot
addappid(390371, 1, "07d6a3e2db4b9207e750597f5cdfbbe07ddebcc96772b44ecf93705b64eb91d1") -- Rocksmith 2014 - DLC12 (390371) Depot
addappid(390372, 1, "adb3f7894a22e089e3139eda8a10b096633d491a1fc81d36a22a829df21d578b") -- Rocksmith 2014 - DLC13 (390372) Depot
addappid(390374, 1, "114e639f0f0f0c55d5ff053d570fd6376050404964ffeb159982abce90c4a728") -- Rocksmith 2014 - DLC15 (390374) Depot
addappid(390375, 1, "e3bff193580701d2a08935c84c0c810a1cb1baca44dfd433029d0ba875b772f8") -- Rocksmith 2014 - DLC16 (390375) Depot
addappid(390376, 1, "27964e38b8867ce137c98b373f0ab90abef480fe2c72e1a5b0b22e133a278718") -- Rocksmith 2014 - DLC17 (390376) Depot
addappid(390377, 1, "65a19c7f41a8bf99c85de9d4f20fee725648268101c0faa2598cb4a17fa707f0") -- Rocksmith 2014 - DLC18 (390377) Depot
addappid(390379, 1, "f718a9788b311a94c9d016fa3263e5abc57bf0d4b03199996049de5cd892b414") -- Rocksmith 2014 - DLC20 (390379) Depot
addappid(390380, 1, "52a6ef325169d20ca21e929b26193794c36a70beb6a5e19a604a1ae052701113") -- Rocksmith 2014 - DLC21 (390380) Depot
addappid(390381, 1, "6155302c7daa7d2df1187b2a4a948e70ee7d27f3137ad397963da9b75aa1b188") -- Rocksmith 2014 - DLC22 (390381) Depot
addappid(390382, 1, "4723b38cde55fd3a2bdf6a76f2ddf3da59490b55dc5029b4ec98e55e92d8729e") -- Rocksmith 2014 - DLC23 (390382) Depot
addappid(390384, 1, "4b850c9d8355dbd974419f7746e3b6d0e878b2231d884a91cd171c468468a143") -- Rocksmith 2014 - DLC25 (390384) Depot
addappid(390385, 1, "678bfe68b1f140b1cc66e1005af82401cf7a415ad385d34a916be2fae03181b5") -- Rocksmith 2014 - DLC26 (390385) Depot
addappid(390386, 1, "e74151d57a93521e826f0dd3dbc15bf24045ab7992c4fb18b3f39df161520ee1") -- Rocksmith 2014 - DLC27 (390386) Depot
addappid(390387, 1, "14201fa819efd1edc5512ed9a172a337f40d5f13568cd781b7fd12b97b882ff1") -- Rocksmith 2014 - DLC28 (390387) Depot
addappid(390389, 1, "ed9b603017ed2ea4fb7080364c91cd5c3ea75ce27bd4bf2c0dbfab21a6fe1de5") -- Rocksmith 2014 - Bachsmith II - Rocksmith 2014 - DLC30 (390389) Depot
addappid(390390, 1, "c78f2ed1d884626af69a0da043ffcc0963a31ea5b2244caea9b7ed992488745e") -- Rocksmith 2014 - DLC31 (390390) Depot
addappid(390391, 1, "e146c9bbd216d65a2516e727835aa7fe122d376e73acadfb5f54dec059cdd0f7") -- Rocksmith 2014 - DLC32 (390391) Depot
addappid(390392, 1, "2f478b586cfbdf41257eaacafb2db9084b523c375ee85da5cb6346f7ce7a5d31") -- Rocksmith 2014 - DLC33 (390392) Depot
addappid(390393, 1, "4d13ed040626f5011f183e9a313f4775a05060fd7137a1a28ff9177e2159e769") -- Rocksmith 2014 - DLC34 (390393) Depot
addappid(390394, 1, "a6c9813883ff88c18708cf3a40fcc1c0d174cefec7edc0c118c3ae083141394d") -- Rocksmith 2014 - DLC35 (390394) Depot
addappid(390396, 1, "93e5df196d05c68fc1bf573c7760b60f4a3183874fd2dcbec6bcb48d0d34ea6c") -- Rocksmith 2014 - DLC37 (390396) Depot
addappid(390397, 1, "779e337da056e14cc7d8d26bc1e241d148096aa813ed26f72c8542fcdeca99e2") -- Rocksmith 2014 - DLC38 (390397) Depot
addappid(390398, 1, "ff73fd99a8092a3bfe8285fc960fd847c4b3381d53b451a897aaa87977f4e023") -- Rocksmith 2014 - DLC39 (390398) Depot
addappid(390402, 1, "4a7a11df3f3a08e418572ca123df38f203160c4ef1259751b17f141a1ea816cb") -- Rocksmith 2014 - DLC43 (390402) Depot
addappid(390403, 1, "4056408d376a3717164fd98e28e178acea17a0edc976b80db98b7b3bbbac7d30") -- Rocksmith 2014 - DLC44 (390403) Depot
addappid(390404, 1, "4bcc00050d97d5e46c532a351e9a00fc6d3dbdf49751232824f8dc1233963ad5") -- Rocksmith 2014 - DLC45 (390404) Depot
addappid(390406, 1, "c6570a80c490ae78b65763686f279eca86120fc8ddb3a661f7f8316aac8034f1") -- Rocksmith 2014 - DLC47 (390406) Depot
addappid(390407, 1, "c10238ee63d354911d569c4e06095d66b61b9ad96f8a91320906841b2f6935e9") -- Rocksmith 2014 - DLC48 (390407) Depot
addappid(390408, 1, "0e0923767d0bf641f985341bfc9d87705f3a13ad8bf61f6b9cc7a2935416ac8c") -- Rocksmith 2014 - DLC49 (390408) Depot
addappid(390409, 1, "7908954f7330c83952506f9a1882e83b893b01fbb68a057dc22713e4a8e1f17e") -- Rocksmith 2014 - DLC50 (390409) Depot
addappid(390410, 1, "e198669ab62851077e08a44145fe38ac058d148ec06ac45081caba26b5a892a5") -- Rocksmith 2014 - DLC51 (390410) Depot
addappid(390412, 1, "cf745a9b65694be25a9a1908dc6e68f88362e84ad272c1553e6da82b6559ff2a") -- Rocksmith 2014 - DLC53 (390412) Depot
addappid(390413, 1, "93ea34461dfc29cdb6449f9f0aad3d647a249cf8b4c48ca1b6cd03f96224674f") -- Rocksmith 2014 - DLC54 (390413) Depot
addappid(390414, 1, "2cdebfecb7c274bfc1806f315b2bd8dbc2bacacbd98c5cf3c37138fc0c63f852") -- Rocksmith 2014 - DLC55 (390414) Depot
addappid(390415, 1, "7d898ac8455faf32e784b6bc56c0fabddb62393ae7ce05113e3f553e7d4bddcc") -- Rocksmith 2014 - DLC56 (390415) Depot
addappid(390416, 1, "9a5aa21a9208ae647e5abb66a64856f511ae128745e0a079128a856962db80f0") -- Rocksmith 2014 - DLC57 (390416) Depot
addappid(390417, 1, "d7eaa38f2e76e1fdc9227cbce6df338c5f09dc740752b6082a1914ee8cc4dc33") -- Rocksmith 2014 - DLC58 (390417) Depot
addappid(390419, 1, "af0a70ce6c721661b3d4beb2dd58969999ccd7dbc6ebd04e8aa494755843f71e") -- Rocksmith 2014 - DLC60 (390419) Depot
addappid(390420, 1, "ef080f70fc8767e2fb6db7cb44b26c9371e729f488871187edba3b089e79f913") -- Rocksmith 2014 - DLC61 (390420) Depot
addappid(390421, 1, "254de888a6d8367be842778623aecdbbcf77a29ce875a952253b8f76e834a9ba") -- Rocksmith 2014 - DLC62 (390421) Depot
addappid(390422, 1, "14226fa93eda278de800168a52954755f5a987f354d87a689f1d36482824c215") -- Rocksmith 2014 - DLC63 (390422) Depot
addappid(390424, 1, "cf8a5806c057857d28606e8a793635cfc65b5eb07d50c13368cb8b071fc44a94") -- Rocksmith 2014 - DLC65 (390424) Depot
addappid(390425, 1, "89b31aa12bee66a5f87c5b4b413326bec450fc5c63e16488e790f0f98386a37c") -- Rocksmith 2014 - DLC66 (390425) Depot
addappid(390426, 1, "44d03e316ff5a89185508dd14b0229c1e3a2f375b5eff5319439fee2118b289d") -- Rocksmith 2014 - DLC67 (390426) Depot
addappid(390427, 1, "f7d0feee07ab5264c8097ea80719ea0dbbc66e5e507892730ca865bfc7a5b393") -- Rocksmith 2014 - DLC68 (390427) Depot
addappid(390428, 1, "c1f0012e014589a511eb1e35809a1b021e1a6bfea91cb49f5b2d030efb2ad957") -- Rocksmith 2014 - DLC69 (390428) Depot
addappid(390430, 1, "6cdb9ec0b8ee91c546af49a40d105c06ce70631b3db927ac88adfcef47fc3d3b") -- Rocksmith 2014 - DLC71 (390430) Depot
addappid(390431, 1, "cc1c20bd990464fb884df2e301131d8ee0082b38939a324f64d4a58b47245d5d") -- Rocksmith 2014 - DLC72 (390431) Depot
addappid(390432, 1, "5cf54b63ad3e6017051452e98b97d91cd66793862f2df66fce878416a06342ae") -- Rocksmith 2014 - DLC73 (390432) Depot
addappid(390433, 1, "94e06a2028d2320e2f98f777ba7ed338d0a443ecdfa4b0da93eb3b8cde40e88e") -- Rocksmith 2014 - DLC74 (390433) Depot
addappid(390434, 1, "f7da284e6a29a056257547fdd418a15151cab9ac3cd6b561bfa73e36316b81d3") -- Rocksmith 2014 - DLC75 (390434) Depot
addappid(390436, 1, "69d3527cabff6d740648b675b4300062399ef7b7cf5e8f61ce7a626e0bbe4fa5") -- Rocksmith 2014 - DLC77 (390436) Depot
addappid(390437, 1, "c90337a949dba635b405cb174ea39020a5c6f0aa0fb9d783daf826a2a91e5d73") -- Rocksmith 2014 - DLC78 (390437) Depot
addappid(390438, 1, "7cf80fba9cebd300a782adcb0da589d1df1fcd1af39baedf3b26044bdc131a53") -- Rocksmith 2014 - DLC79 (390438) Depot
addappid(390440, 1, "319a3134a029a0f79de043a88d4303ed276b42218a8ed804c38de2f5cdace13a") -- Rocksmith 2014 - DLC81 (390440) Depot
addappid(390441, 1, "1f9b23e6fccee6de4f10c71a33e6074122dca1553160e9b06b3176552e1608be") -- Rocksmith 2014 - DLC82 (390441) Depot
addappid(390442, 1, "e2dc18de4750fee107d7d60e8dfdc2c749415fefdf4225e0f819a5d9808c87f5") -- Rocksmith 2014 - DLC83 (390442) Depot
addappid(390443, 1, "6c130e712c9d530c1f875c2caaa43ece92468978b0bc83ecfa468ed4216b668f") -- Rocksmith 2014 - DLC84 (390443) Depot
addappid(390444, 1, "08f9ef8d1f47abb50e42e687444bb50bf1b979ae8fa26646bdb940cbead47909") -- Rocksmith 2014 - DLC85 (390444) Depot
addappid(390446, 1, "4fc99b0a0a47da83f1d2c2edcf3fcb15cccba39918287fa9067a135dda9257d2") -- Rocksmith 2014 - DLC87 (390446) Depot
addappid(390447, 1, "ca3e01ff9cb552f36cf73086ffd01f8bc024cefe386ff30c0686fb82eea060f2") -- Rocksmith 2014 - DLC88 (390447) Depot
addappid(390448, 1, "325b834d6da088af92dfc2c010f34e7b66bc6d7d8884e5cd84f30b1033305b07") -- Rocksmith 2014 - DLC89 (390448) Depot
addappid(390449, 1, "cc3673f1eb547bc432280f6320eba7ca5d49523d43b00553122782a5f0a39345") -- Rocksmith 2014 - DLC90 (390449) Depot
addappid(390451, 1, "eb58a86918504075f8cef1d072de54ecc7c72b9cae930437501cf77bbb419b98") -- Rocksmith 2014 - DLC92 (390451) Depot
addappid(390452, 1, "819722ec95bbbada6803f922d4b28466559e1b1e69766ef38b6763b3b8521e12") -- Rocksmith 2014 - DLC93 (390452) Depot
addappid(390453, 1, "79cdcfcf22632a64f70a71f9d3655e8348b7b85784ae731deee49935e0dfeef3") -- Rocksmith 2014 - DLC94 (390453) Depot
addappid(390454, 1, "f1217f7da351620d91ebaf8c1fba2bfc94c9556739dab929aadccf3480906607") -- Rocksmith 2014 - DLC95 (390454) Depot
addappid(390456, 1, "1752a880c238db6f3bfbd010936c86d3bded464c7f1364b6134aa4cc306c402a") -- Rocksmith 2014 - DLC97 (390456) Depot
addappid(390457, 1, "ff8491db622ebaf4ecd554ab1900490822a7ec0b6355afc01ec6dbb246d7d87e") -- Rocksmith 2014 - DLC98 (390457) Depot
addappid(390458, 1, "5f44522997c7d5595840c649c947cbbe5db0e3d6658420bc209896c77347ab73") -- Rocksmith 2014 - DLC99 (390458) Depot
addappid(390459, 1, "84defed4fb5896fff8a62fa82c8818d07eaae380e12845132f873f42193ee7c5") -- Rocksmith 2014 - DLC100 (390459) Depot
addappid(436570, 1, "754032b7f44381f63f7e5ab5007dd6af93b8e3d0864a46b4d5c9929b8cf20e0b") -- Rocksmith 2014 - 1 (436570) Depot
addappid(436572, 1, "781f0c7cea6487083f7480f1a07e2c78a6660117c1512f273209e513f119ecae") -- Rocksmith 2014 - 3 (436572) Depot
addappid(436573, 1, "b4f9fe39dcb5607494a8e48360dc0523f48220884a5ea5b36d13ed4d8fa969c9") -- Rocksmith 2014 - 4 (436573) Depot
addappid(436574, 1, "94e67269619e5b1e6892e704dcca8f9ed0a40727f30592e07b852bd4270f40f9") -- Rocksmith 2014 - 5 (436574) Depot
addappid(436575, 1, "f08d80609d66d435300b9b6a8ad1f452bd0fb0df280ba8226ee274ad7ced442c") -- Rocksmith 2014 - 6 (436575) Depot
addappid(436576, 1, "fb58c269b552601765222a269d166853a2c3e317c2c9b98f4218383c22db35d3") -- Rocksmith 2014 - 7 (436576) Depot
addappid(436577, 1, "5b38700831cc66534c83df8167c3101ec113558f4b251d048c5e9e8c2fb6143e") -- Rocksmith 2014 - 8 (436577) Depot
addappid(436579, 1, "318c43a195ae8d2302b5500401965e69066e7fc1eafb3b38c6fe1e7b5aa42785") -- Rocksmith 2014 - 10 (436579) Depot
addappid(436580, 1, "a060683729b243c4269392724ca38fb3153e50539e3fcce6912607fb558f5cc6") -- Rocksmith 2014 - 11 (436580) Depot
addappid(436581, 1, "130e1f1d6ac5113900f9ea8502f86e689b5e4f1d22a591bba27f96f7a259d6f0") -- Rocksmith 2014 - 12 (436581) Depot
addappid(436582, 1, "f6675ed4a6e2413e664d59aec62d28e95bceab4d46a8c663df981c5db34e3daf") -- Rocksmith 2014 - 13 (436582) Depot
addappid(436583, 1, "63bc323758c4591035f7765b0b6dba4d4f5861a4b4f8b03c495b2c015e591bf1") -- Rocksmith 2014 - 14 (436583) Depot
addappid(436585, 1, "10f6e0f3dd2691657ff1da788d9e016d994e0c03f90078369b9be667022c8ba5") -- Rocksmith 2014 - 16 (436585) Depot
addappid(436586, 1, "e065a6dcdc9bace37dceb8be0023dc1f1f12a911866844a16c60b8bd680d1c1d") -- Rocksmith 2014 - 17 (436586) Depot
addappid(436587, 1, "e3503227b419bdebc20a1883a6431f4203300c7808508ac60106a180ccffc235") -- Rocksmith 2014 - 18 (436587) Depot
addappid(436589, 1, "fbd72282b04f5806d829acb9906757b56ca7cbc68f73498be7122687661f2042") -- Rocksmith 2014 - 20 (436589) Depot
addappid(436590, 1, "b60fa083c398ba5b77a2b1432b4866747342f28e99406419e806ebf443758d4c") -- Rocksmith 2014 - 21 (436590) Depot
addappid(436591, 1, "558a424111f9c404a1c7b88a41ee003dfaf4919d2d1706d8a27e34329a0a31ba") -- Rocksmith 2014 - 22 (436591) Depot
addappid(436592, 1, "a0e704890bdc1c94e1fb18250259caa69a0a8a1f1dfbaa7d5dfa7fc288cc4116") -- Rocksmith 2014 - 23 (436592) Depot
addappid(436594, 1, "cf79d79f60ffa92df8911e71fb4ae967f812d6c2af7d8af89eb6896a885d19b2") -- Rocksmith 2014 - 24 (436594) Depot
addappid(436595, 1, "4df5815b05e82fd1a8c6f055a7b55dc0bee41856c42cfd12661f92c876e18883") -- Rocksmith 2014 - 25 (436595) Depot
addappid(436596, 1, "9caeae2abadba039bcf6419080308f3e0b9901e941592d94db466330324f769c") -- Rocksmith 2014 - 26 (436596) Depot
addappid(436598, 1, "612802a7f8a8a8f318043f188816f79f387ec1aed8f3554929efc4e49658972d") -- Rocksmith 2014 - 28 (436598) Depot
addappid(436599, 1, "ae4b48838c9fcc6dd6d2045905668ba1b1bed4adc8b77c157c9d5f7af4365759") -- Rocksmith 2014 - 29 (436599) Depot
addappid(436600, 1, "d1bd7235714fd80fcf66215b6c53ff2367ebebd3bd66b20afda2330af071964b") -- Rocksmith 2014 - 30 (436600) Depot
addappid(436601, 1, "23261f781c72b43740905e18af284bc978e9883210a52ef24156693fa2b7e96e") -- Rocksmith 2014 - 31 (436601) Depot
addappid(436602, 1, "372c7b72d16806a53987031c2bcca9e9bd3d809d614ff1de15bf33c075445ee3") -- Rocksmith 2014 - 32 (436602) Depot
addappid(436604, 1, "bbd273ecef95ec2ca99fa277e1a3b198ebb36e103f355b6199f4cec948e9efe5") -- Rocksmith 2014 - 34 (436604) Depot
addappid(436605, 1, "6b13d4fb870cdbe8131fff40ae41508172615d8394aba319180e022cab7a4df7") -- Rocksmith 2014 - 35 (436605) Depot
addappid(436606, 1, "778503cc530d56f08dc486dc3323a59fcabb0d9fe604a80a6c013b22e889ac3d") -- Rocksmith 2014 - 36 (436606) Depot
addappid(436608, 1, "c5942d18f2f48c102440145f63910041ff39810fc2d63eb0ad3b199494a83ff6") -- Rocksmith 2014 - 38 (436608) Depot
addappid(436609, 1, "ecd0afae9ae77938f0b6cbe11273c9f4402ef95d4a28710b2cbfdb86a485cc94") -- Rocksmith 2014 - 39 (436609) Depot
addappid(436610, 1, "7678532f7e377e20f25235bd60b4737fd90f04cc2639dd305a1263c2d43b25fd") -- Rocksmith 2014 - 40 (436610) Depot
addappid(436612, 1, "de700b7d06428e1ef2a2d5493fa308a09c86d849de3dfe218b33eeef547c515a") -- Rocksmith 2014 - 42 (436612) Depot
addappid(436613, 1, "178cf4245ebd246c74c75ee018b1fc6131beb21c3e82471ea75d2e0a8eb35fe9") -- Rocksmith 2014 - 43 (436613) Depot
addappid(436614, 1, "a10cf3f394cbaeba50aa80e719c4c31a5abdb7b23a5003d72147e1e472a5a920") -- Rocksmith 2014 - 44 (436614) Depot
addappid(436615, 1, "69af12cb6fb8d5f62fe1eb4c06f742f2eddf44e070b73cc350477b25efc6b726") -- Rocksmith 2014 - 45 (436615) Depot
addappid(436616, 1, "4aabcd2bbe29c68407b0074e7de47ea745c999e75b7c5b56fe09d38be3af01dd") -- Rocksmith 2014 - 46 (436616) Depot
addappid(436618, 1, "884e9ef572036e9e687ea1728a21ddbee0baa4598b4ba5dc84be991af028edd0") -- Rocksmith 2014 - 48 (436618) Depot
addappid(436619, 1, "3e4021cd7e9cbdedbc4a986c24f2d7b42348f236b1e824c34d129cca63d5df99") -- Rocksmith 2014 - 49 (436619) Depot
addappid(436620, 1, "44919796e737864045d95b990a3cf836fe894c3dddae85e202a0ca75a2dd6383") -- Rocksmith 2014 - 50 (436620) Depot
addappid(436621, 1, "9527a0b7621d7215387b9d095ba05360fad6183e637bf52a61c6d43f7bccc166") -- Rocksmith 2014 - 51 (436621) Depot
addappid(436623, 1, "2e75646edaf00fc7d78dc557619a32efc552088f22897b87c750946a1bad9687") -- Rocksmith 2014 - 53 (436623) Depot
addappid(436624, 1, "77c5abb0a78fb0e80bd74fc486575330298b8e7e9fe3f1439e3ed9fb716b7e84") -- Rocksmith 2014 - 54 (436624) Depot
addappid(436625, 1, "73ba9eed5a4c56effdd568f797a556fc4cf182b2bad5845f13b39d1e7a65a327") -- Rocksmith 2014 - 55 (436625) Depot
addappid(436627, 1, "9f73949535f5c2a879aa11e08c9dd0d26d62a9dc5db2bb9b769936b868dd204b") -- Rocksmith 2014 - 57 (436627) Depot
addappid(436628, 1, "bcefcce89ca62f9feb39535873a277b4c471487bba41cf970ff0c20ea3c13a10") -- Rocksmith 2014 - 58 (436628) Depot
addappid(436629, 1, "bb3bd2ba59963b19ece50751c71f0875b00b1ff1fb7a9a8fe2fbe95623b17e95") -- Rocksmith 2014 - 59 (436629) Depot
addappid(436631, 1, "d29fd6a27993d9ef4f6588cc3e4fd3c89cfe0a522d1130df323a9812d8e8170e") -- Rocksmith 2014 - 61 (436631) Depot
addappid(436632, 1, "3d7358ee756bb05bb9643515070ab0755f50541abbfa6f56a32b8f2fb5ccd9c3") -- Rocksmith 2014 - 62 (436632) Depot
addappid(436633, 1, "e75142f8f03b778d913ac0828c2e977c65ef99bfadfdd00d7afb7fbd6e2c54ef") -- Rocksmith 2014 - 63 (436633) Depot
addappid(436635, 1, "205c7dde2f44b46a89dce136aea461fe43f697a78e3e0cc1a5a1e219f6315f07") -- Rocksmith 2014 - 65 (436635) Depot
addappid(436636, 1, "5ccc1e508ed9619c1c66628c9933516b3277e39764f58bf963526b1e34cb87c0") -- Rocksmith 2014 - 66 (436636) Depot
addappid(436637, 1, "5b4702b0c7e9a2e7fc173be11c1aa4ac5ae5fedc655d9bebcbf5db5ade74ac96") -- Rocksmith 2014 - 67 (436637) Depot
addappid(436638, 1, "0ca3c5f615d14c0c6c6d498e9d1176d5969c0fa8cf4a5be9ad8ab066cefb8f83") -- Rocksmith 2014 - 68 (436638) Depot
addappid(436639, 1, "8dc61aa4b478cfe630a735193bb8dcc68541dd1140451db024cf99a756d7515a") -- Rocksmith 2014 - 69 (436639) Depot
addappid(436641, 1, "6afa177b7d01264dd6e897483214bb9d43275acc421d93043ff4bc589815b89a") -- Rocksmith 2014 - 71 (436641) Depot
addappid(436642, 1, "7ee527296ae725ea653e4c84e35057a31a3d5aab4173674a75cf9de4a92f038f") -- Rocksmith 2014 - 72 (436642) Depot
addappid(436643, 1, "5f3662a6a3a07baf85f42c2068f39363bc09f45ce11934ab0e3e1ab46de5e7f0") -- Rocksmith 2014 - 73 (436643) Depot
addappid(436644, 1, "71f70e4bfaf062385172a7e1e6eac4e1e765ae406f6efeb1fcf7522169729742") -- Rocksmith 2014 - 74 (436644) Depot
addappid(436646, 1, "e4b707d1dde56b4b616e63c9fd8a2c2bf875c7e4afc97ed9183537050aaceaa3") -- Rocksmith 2014 - 76 (436646) Depot
addappid(436647, 1, "19c4034bc34884497530b4b48e46a5e8c2d21de5d039e6c7d9aeb37eeaa47227") -- Rocksmith 2014 - Incubus - Stellar - Rocksmith 2014 - 77 (436647) Depot
addappid(436648, 1, "d0f027cef15e9e1c2605239647a8b522805c15ea111be21367515804841dadb8") -- Rocksmith 2014 - 78 (436648) Depot
addappid(436649, 1, "a2e13a96add9422e8e16d7eb9d3a31aec9b054261cbe30a451e22ccff21ff387") -- Rocksmith 2014 - 79 (436649) Depot
addappid(436651, 1, "1a9a5278e52e329283dcdf764e972c1cd3fe7717018b212bc0a496b6388a5fbb") -- Rocksmith 2014 - 81 (436651) Depot
addappid(436652, 1, "707e79eb442549fb6992bc1dea00c8b42e305308689c2888afb77d8a13f49061") -- Rocksmith 2014 - 82 (436652) Depot
addappid(436653, 1, "2397519baa2fba4e50b4a1c41978d6432cfe28dd1faf50058de0ec0bd7d95739") -- Rocksmith 2014 - 83 (436653) Depot
addappid(436654, 1, "a8a7c84caf9e618f509a55fba99f4f5e914e75d996389f2cb3a74e4e3aa7c765") -- Rocksmith 2014 - 84 (436654) Depot
addappid(436656, 1, "5957b6198d457f06aef993f8c275524f1073567cc372555e8783dc5b46680913") -- Rocksmith 2014 - 86 (436656) Depot
addappid(436657, 1, "c7d91d3bec5066fbc5dd50c0b2b94f8c20fef96e45624fb11cbac956402b1b8a") -- Rocksmith 2014 - 87 (436657) Depot
addappid(436658, 1, "f12540ec6e9fd34f0503fc2be4d955aa70de2afc8701c0fdf5c55c716afd7006") -- Rocksmith 2014 - 88 (436658) Depot
addappid(436660, 1, "6d497bd129224fbef128b2c3424f4365bf4f7c80bb1bffd7822e9662b3fa75f3") -- Rocksmith 2014 - 90 (436660) Depot
addappid(436661, 1, "16360bab2b062f5e4f0acba07d7de9fe5e99dcc74c861d0c3c23b8223e236c5b") -- Rocksmith 2014 - 91 (436661) Depot
addappid(436662, 1, "c8f44e1b2ca2606fe5b3f0dda71560becc53a8f4413fc7e662eabe5697a51b71") -- Rocksmith 2014 - 92 (436662) Depot
addappid(436663, 1, "5d4684aaae90dc09f0388b11dabead7606ab2711cdb213038e6ba36e3eb47f5d") -- Rocksmith 2014 - 93 (436663) Depot
addappid(436665, 1, "08de78ff050e553c59fb5f8c6f31268f1506131507dbde58d74a3bcc99383215") -- Rocksmith 2014 - Jefferson Airplane - White Rabbit - Rocksmith 2014 - 95 (436665) Depot
addappid(436666, 1, "4dde4ad6566d25ea3d6368053d2612181d146fcb0e2a6c54f7c001b3cf4fe940") -- Rocksmith 2014 - The Doors - Love Me Two Times - Rocksmith 2014 - 96 (436666) Depot
addappid(436667, 1, "ebc4d6fa85ed8715a521cccba76c07bd232a741eacabc15b53b9554dfed8f9a1") -- Rocksmith 2014 - Shocking Blue - Venus - Rocksmith 2014 - 97 (436667) Depot
addappid(436669, 1, "9744439db659d1e5369097238f0fe7cf82c739d53da00546d0450a77bab056b0") -- Rocksmith 2014 - Hail The Sun - Burn Nice and Slow (The Formative Years) - Rocksmith 2014 - 99 (436669) Depot
addappid(492940, 1, "7dfedaa5904df056b7e17f7ed1b05e5567d20aee781c1a48cdfb376599541daf") -- Rocksmith 2014 - Pixies - Debaser - Rocksmith 2014 (492940) Depot
addappid(492941, 1, "1230b7b33ad0d25c345d95904a2faed9c47b18409981ad0cba4440eec71f1618") -- Rocksmith 2014 - Pixies - Hey - Rocksmith 2014 (492941) Depot
addappid(492942, 1, "129fd91cdf5ce75eeef6ae31667ea4f75902678effb5f13b4beef0aca5decb0a") -- Rocksmith 2014 - Pixies - Wave of Mutilation - Rocksmith 2014 (492942) Depot
addappid(492943, 1, "bc6f6ff8ce6236d76c45c53c9e951e5a60c1e2cbd52be28b2c6acb11c2f0f76b") -- Rocksmith 2014 - Pixies - Monkey Gone To Heaven - Rocksmith 2014 (492943) Depot
addappid(492945, 1, "9ddd1baba3a292944ec864761886da65080a716abaf412d7eb87d26302441d7c") -- Rocksmith 2014 - Joe Satriani - Always with Me, Always with You - Rocksmith 2014 (492945) Depot
addappid(492946, 1, "f78d1ee1a27ac59035841ba0537dfdc7581d6008fb34c23bf0a75e65f8851233") -- Rocksmith 2014 - Pantera - 5 Minutes Alone - Rocksmith 2014 (492946) Depot
addappid(492947, 1, "5e982d773279dec2b1f399f97e4788390d6f36e205b7e865811e7d9ab152b60c") -- Rocksmith 2014 - The Fratellis - Chelsea Dagger - Rocksmith 2014 (492947) Depot
addappid(492948, 1, "ec2d6751c5d18b1e2af42d959fb044ec34454f4555f41278b6ae8b1e5cea838e") -- Rocksmith 2014 - Styx - Blue Collar Man (Long Nights) - Rocksmith 2014 (492948) Depot
addappid(492950, 1, "ec8b1ea7f433fc832e7c7a243a228983ac7baa82c9a03b96aa864284c3877988") -- Rocksmith 2014 - Bad Religion - American Jesus - Rocksmith 2014 (492950) Depot
addappid(492951, 1, "8611f0a21205a7f9cd3e6f7d980a4012b874aa296cb2799dd02424dcc11f9cc0") -- Rocksmith 2014 - Bad Religion - 21st Century (Digital Boy) - Rocksmith 2014 (492951) Depot
addappid(492952, 1, "e94dd1af762ab37417f004cf2b527f0737e119bfa782533a705be33af3831632") -- Rocksmith 2014 - Bad Religion - Infected - Rocksmith 2014 (492952) Depot
addappid(492953, 1, "fa42b7b497511a6bd5a2e44b96952aa8700b4cdeb3676e6485fb2c8f4c96b1bd") -- Rocksmith 2014 - Bad Religion - Sorrow - Rocksmith 2014 (492953) Depot
addappid(492955, 1, "d49f3599f567648b32126f127369495db63f2c1274384ac15bcdef617a469559") -- Rocksmith 2014 - Fall Out Boy - My Songs Know What You Did In The Dark (Light Em Up) - Rocksmith 2014 (492955) Depot
addappid(492956, 1, "69feabef01f36787bc692f64f84fc94a13ade3238d1d99c98469633393bfd979") -- Rocksmith 2014 - The Neighbourhood - Sweater Weather - Rocksmith 2014 (492956) Depot
addappid(492958, 1, "871216fd9cf60161a09f89779ac05a2fba04bb945114e401a9bd9a37518118c6") -- Rocksmith 2014 - Rush - Working Man - Rocksmith 2014 (492958) Depot
addappid(492959, 1, "7f8d37ac52246d22904bfc21f509947815d56cf0903a16b56a1f1f8bb5445020") -- Rocksmith 2014 - Rush - La Villa Strangiato - Rocksmith 2014 (492959) Depot
addappid(492960, 1, "99d2d51bf396f964fda3249cd7b28298db7092500cbdd85dbea59e0c498469ec") -- Rocksmith 2014 - Rush - Freewill - Rocksmith 2014 (492960) Depot
addappid(492961, 1, "e06fae3fc60e5215450b29448b4c7c60976dda2ad505daf724e2f5413d43dac1") -- Rocksmith 2014 - Rush - Fly By Night - Rocksmith 2014 (492961) Depot
addappid(492962, 1, "438eec895a9950565a09c23bbf384b3da761957e9e05f446a7c29159efc47ae8") -- Rocksmith 2014 - Rush - Closer to the Heart - Rocksmith 2014 (492962) Depot
addappid(492964, 1, "94301a8cadd8ef8ae399a5444e38c93257de616cb4424b0f02702a91a56f44bc") -- Rocksmith 2014 - The Clash - I Fought the Law - Rocksmith 2014 (492964) Depot
addappid(492965, 1, "6eaf2886e5ee66b5e60e080b0a7f37feec1af46e646fc5cece2e3c9a1b1a2574") -- Rocksmith 2014 - Thin Lizzy - Emerald - Rocksmith 2014 (492965) Depot
addappid(492966, 1, "a33f56036e14e471371dee30de4b40bf1a6d644a7f93d92a2c58114bf0f05576") -- Rocksmith 2014 - George Baker Selection - Little Green Bag - Rocksmith 2014 (492966) Depot
addappid(492968, 1, "d506fd6eb5e64a788d5615763c792b5ef3bde537ad3a2d36cde44af622c0d114") -- Rocksmith 2014 - Staind - Its Been Awhile - Rocksmith 2014 (492968) Depot
addappid(492969, 1, "fa075dda04bb2ab93d88c0c1755726b77b52cfe413283199780bbfcf84a318dc") -- Rocksmith 2014 - Staind - Outside - Rocksmith 2014 (492969) Depot
addappid(492970, 1, "8dd8d18cb04fb2dc3457f0562496e9d7fcf8698367f935a29859e76aa9fa274e") -- Rocksmith 2014 - Staind - So Far Away - Rocksmith 2014 (492970) Depot
addappid(492972, 1, "341d540ac5331a93aec46d8e690a8a8b31a2e8571f66c9bdbf6c83eef937a706") -- Rocksmith 2014 - Fleetwood Mac - Never Going Back Again - Rocksmith 2014 (492972) Depot
addappid(492973, 1, "329c6613da93f3a58a2d1388f3e46c1d64320e0296dd18ba1d49d432d933c3ee") -- Rocksmith 2014 - A Flock of Seagulls - I Ran (So Far Away) - Rocksmith 2014 (492973) Depot
addappid(492974, 1, "2ace84e16161f91298a7ffc9d225e0f72fe09a5bec53e06d14c6bfb28d1c8737") -- Rocksmith 2014 - Sepultura - RefuseResist - Rocksmith 2014 (492974) Depot
addappid(492975, 1, "caa2d4c2597ff9dbeb41e06f6b98eb8cbea851d1c43ec286a596525930330941") -- Rocksmith 2014 - A Day To Remember - Im Made of Wax, Larry, What Are You Made Of - Rocksmith 2014 (492975) Depot
addappid(492977, 1, "2a103cc3ad21fda515f8b41554de0a711165b1f677a9d181ae5ed967c193fc98") -- Rocksmith 2014 - Misfits - Last Caress - Rocksmith 2014 (492977) Depot
addappid(492978, 1, "2a255964e0d2a41c035325521ee2c24f1f5b4fe9107cee908264757f57941017") -- Rocksmith 2014 - Misfits - Die, Die My Darling - Rocksmith 2014 (492978) Depot
addappid(492979, 1, "307da383d28fe2f4eb7b739f3db42f808b33dffb69db50188a7c1adf57f3f092") -- Rocksmith 2014 - Misfits - Where Eagles Dare - Rocksmith 2014 (492979) Depot
addappid(492980, 1, "60a67899e75f14bf2f18e3b36aa75ab922083cddc801ec24cf781a50bf84443d") -- Rocksmith 2014 - Misfits - Halloween - Rocksmith 2014 (492980) Depot
addappid(492982, 1, "1f99087a6ccf1d9ed1739de09e1d60e4e0cb53d75184e5c470e59aa58da35bdf") -- Rocksmith 2014 - Dream Theater - Pull Me Under - Rocksmith 2014 (492982) Depot
addappid(492983, 1, "ee46a852c983f3eb3bda99ac39629904642db675c93d7702468e2c192bb88ab9") -- Rocksmith 2014 - Dream Theater - Metropolis Part I The Miracle and the Sleeper - Rocksmith 2014 (492983) Depot
addappid(492984, 1, "d3c5ca64b39548ccada58018e188e28bfabdc9c4773a2bc12e895e9fa3f9de64") -- Rocksmith 2014 - Dream Theater - On the Backs of Angels - Rocksmith 2014 (492984) Depot
addappid(492986, 1, "483de36b8c74bc45782da7131294e75b3bd28604690a507de7dc0bcb516ca7ea") -- Rocksmith 2014 - Elvis Presley - Suspicious Minds - Rocksmith 2014 (492986) Depot
addappid(492987, 1, "ed4c95d85d3a8360d28d5ff9471a43aa323d37cb3724383cb92914694925566b") -- Rocksmith 2014 - Jackson 5 - I Want You Back - Rocksmith 2014 (492987) Depot
addappid(492988, 1, "439a1f72fe01b529c341f7b605e1c9f486bc07c8de58f66687665b6b5ab4d4df") -- Rocksmith 2014 - Bob Marley  The Wailers - Three Little Birds - Rocksmith 2014 (492988) Depot
addappid(492989, 1, "2574229290af359fb1b5adaefc3a517471c7be96b304b93e2ee47947b5702e69") -- Rocksmith 2014 - Train - Drops of Jupiter - Rocksmith 2014 (492989) Depot
addappid(509630, 1, "803fd99a1a98922f50b1464c8eb0e730ffe4d69aaeb851404c697d3d1bf869fe") -- Rocksmith 2014 - OutKast - Hey Ya - Rocksmith 2014 - More DLC (509630) Depot
addappid(509631, 1, "c2e9b9f86517a6f6d08f87cc5818d04e34111ca7f0a4164df88da709f15353fa") -- Rocksmith 2014 - FUN. - Some Nights - Rocksmith 2014 - More DLC (509631) Depot
addappid(509633, 1, "192ef955bece6bab18654bd6e3fd3840bda56187f59f555701e4cdb37dc1b8c6") -- Rocksmith 2014 Edition - Remastered - The Fray - How to Save a Life - Rocksmith 2014 - More DLC (509633) Depot
addappid(509634, 1, "a6c3be6b86661de56fbd9b7c72468e7af544c480d6ec6b32baf8dd1a7978c8be") -- Rocksmith 2014 Edition - Remastered - Shinedown - Simple Man - Rocksmith 2014 - More DLC (509634) Depot
addappid(509635, 1, "eadc43a9b890a0d3241c997cb81a705b711804c9bcba7e5d645d44e9f201548c") -- Rocksmith 2014 Edition - Remastered - Crossfade - Cold - Rocksmith 2014 - More DLC (509635) Depot
addappid(509637, 1, "30257d3e387729c57e952a75c49e3c2b92dc6bfb1f6ae44b63fa5abefa455d85") -- Rocksmith 2014 Edition - Remastered - Yes - Roundabout - Rocksmith 2014 - More DLC (509637) Depot
addappid(509638, 1, "df3f48b4361d7892f30701a0dad568894fcd390c37e3f6cd49f95d7f3345cca9") -- Rocksmith 2014 Edition - Remastered - Yes - Owner of a Lonely Heart - Rocksmith 2014 - More DLC (509638) Depot
addappid(509639, 1, "e8e5eccd84647a4eadc8884654cec1c4620c51926bfe443bf44a40f6c46a95ef") -- Rocksmith 2014 Edition - Remastered - Yes - Heart of the Sunrise - Rocksmith 2014 - More DLC (509639) Depot
addappid(509640, 1, "891c530e178128364af75edffc9d54a3f3ee3457b1d813cbd403ca9e0920f81f") -- Rocksmith 2014 Edition - Remastered - Yes - Starship Trooper - Rocksmith 2014 - More DLC (509640) Depot
addappid(509641, 1, "a27438e210a5916b1b6484563fc4d57c5b66807111cd8b46af49bc3e4ea4fe6c") -- Rocksmith 2014 Edition - Remastered - Yes - Ive Seen All Good People - Rocksmith 2014 - More DLC (509641) Depot
addappid(509643, 1, "d7cb4380e9db28e1bf0e5ccc8e889976b8938786cb57e0ddf3b213493aa0c006") -- Rocksmith 2014 Edition - Remastered - White Zombie - Black Sunshine - Rocksmith 2014 - More DLC (509643) Depot
addappid(509644, 1, "22c7383189fdf85258d6e06a9cbcbd440e262ef4dbd455d47cbd3ec968de96d5") -- Rocksmith 2014 Edition - Remastered - Rob Zombie - Dragula - Rocksmith 2014 - More DLC (509644) Depot
addappid(509645, 1, "210548028075870015d5ef2cd81fc51881e3ccbee79bb70df8799dd85765c5b4") -- Rocksmith 2014 Edition - Remastered - Rob Zombie - Living Dead Girl - Rocksmith 2014 - More DLC (509645) Depot
addappid(509646, 1, "068501264fef51b75ba47dbb9cc66056fec3eeb70ceb0a7cd71db2029f92b2b8") -- Rocksmith 2014 Edition - Remastered - Rob Zombie - Superbeast - Rocksmith 2014 - More DLC (509646) Depot
addappid(509648, 1, "3ef8625474d963a00a2ddfbe3a1899c976f13894eea2fdaf4128b2274ae5d84d") -- Rocksmith 2014 - More DLC - Rocksmith 2014 - More DLC (509648) Depot
addappid(509649, 1, "024044f27679d9bfcf6369270ac7815f70a0cc5d061598004ecd1236c8cc8d13") -- Rocksmith 2014 Edition - Remastered - Steel Panther - Eyes of a Panther - Rocksmith 2014 - More DLC (509649) Depot
addappid(509650, 1, "3cc20af64483fb82978e3caecc00b54f7bc6ab0dacdffb46ecae488036d2ac15") -- Rocksmith 2014 Edition - Remastered - Iggy and The Stooges - Search and Destroy - Rocksmith 2014 - More DLC (509650) Depot
addappid(509651, 1, "f41304a9a80198c6dc70cbc7f7f9f6e5486e22fa6fecce22f7873b288e04ce76") -- Rocksmith 2014 - More DLC - Rocksmith 2014 - More DLC (509651) Depot
addappid(509653, 1, "165ba906d61b23dfc9caaf7bc4b203aded34f1429a96ce456712f148dd7325c3") -- Rocksmith 2014 Edition - Remastered - Poison - Talk Dirty To Me - Rocksmith 2014 - More DLC (509653) Depot
addappid(509654, 1, "331d1b68ead19cd705b63baeb61139667c659619df8fd94ab5b5b0773764c597") -- Rocksmith 2014 Edition - Remastered - Kenny Loggins - Danger Zone - Rocksmith 2014 - More DLC (509654) Depot
addappid(509655, 1, "8613e15606e53e5cd30c92fde761ca9764fe86912b035276db670d2bd7461c0f") -- Rocksmith 2014 Edition - Remastered - Cinderella - Nobodys Fool - Rocksmith 2014 - More DLC (509655) Depot
addappid(509656, 1, "132b11ee71f550c2a40aaf1af9bcb7b29f3f12d1a4fd3223019c5b3f4e37d9bf") -- Rocksmith 2014 Edition - Remastered - Robert Palmer - Addicted To Love - Rocksmith 2014 - More DLC (509656) Depot
addappid(509657, 1, "993dbecda766c8f8fb00e583222779578732834c28fec18c5b2d7029bee0f004") -- Rocksmith 2014 Edition - Remastered - Survivor - Burning Heart - Rocksmith 2014 - More DLC (509657) Depot
addappid(509659, 1, "45eaf30a8d6597650488505ce8b6e13236fdf43f031d63b2f4b2cdfc10fb13c5") -- Rocksmith 2014 Edition - Remastered - Stevie Ray Vaughan  Double Trouble - Pride and Joy - Rocksmith 2014 - More DLC (509659) Depot
addappid(509660, 1, "0d5ab05cb171ef74e2ee7d78988f455b9718424fd6cca2ef83bb43d76df21d3f") -- Rocksmith 2014 Edition - Remastered - Stevie Ray Vaughan  Double Trouble - Texas Flood - Rocksmith 2014 - More DLC (509660) Depot
addappid(509661, 1, "31a8246bf30274321194b3ed3e575e9ca56f556330b88e8773196702f86eb61f") -- Rocksmith 2014 Edition - Remastered - Stevie Ray Vaughan  Double Trouble - Cold Shot - Rocksmith 2014 - More DLC (509661) Depot
addappid(509662, 1, "5bcec13ac87d934a3645f2fa62aaefc327bf3aa44879a6d527e9cfc71a35122f") -- Rocksmith 2014 Edition - Remastered - Stevie Ray Vaughan  Double Trouble - Scuttle Buttin - Rocksmith 2014 - More DLC (509662) Depot
addappid(509663, 1, "9f545d92121eacaa9e4dc9def0be691b5c28f12b9047889f54deeb454ce29572") -- Rocksmith 2014 Edition - Remastered - Stevie Ray Vaughan  Double Trouble - Couldnt Stand the Weather - Rocksmith 2014 - More DLC (509663) Depot
addappid(509665, 1, "89a3f15b0f8951b5554cf2c23ca4801bac8bb81d88b4a23d9294d1a0f6647b61") -- Rocksmith 2014 Edition - Remastered - AWOLNATION - Sail - Rocksmith 2014 - More DLC (509665) Depot
addappid(509666, 1, "6359d5aa861fe17fbcdfb476bb988f5795c361170c2de8d2cbd48613f0dd3794") -- Rocksmith 2014 Edition - Remastered - WALK THE MOON - Shut Up And Dance - Rocksmith 2014 - More DLC (509666) Depot
addappid(509667, 1, "f7914621a98401648e6583725e38c2e18b8c964f502d94feddc71d3f40fa5ef7") -- Rocksmith 2014 Edition - Remastered - Black Veil Brides - In The End - Rocksmith 2014 - More DLC (509667) Depot
addappid(509669, 1, "dd0dd70942cdc159bec365e8735fdd1143aac3a5863d1d26e9df5286ffaa0df7") -- Rocksmith 2014 Edition - Remastered - Third Eye Blind - Jumper - Rocksmith 2014 - More DLC (509669) Depot
addappid(509670, 1, "3c1a9bff0a2ebf17d6399adcce5bcf2a986ad0f773ebca4b10dbf67fccb7a725") -- Rocksmith 2014 Edition - Remastered - Third Eye Blind - Semi-Charmed Life - Rocksmith 2014 - More DLC (509670) Depot
addappid(509671, 1, "c5b91b9f218fcd53266c5306d2b214baf095b3512a8d1d30db1020b43901daab") -- Rocksmith 2014 Edition - Remastered - Third Eye Blind - Hows It Going To Be - Rocksmith 2014 - More DLC (509671) Depot
addappid(509672, 1, "eaa23e1fec9f9724d6e335a2f6d3b57b3d956777fc3f136f8303c1c6dba6fe02") -- Rocksmith 2014 Edition - Remastered - Third Eye Blind - Never Let You Go - Rocksmith 2014 - More DLC (509672) Depot
addappid(509674, 1, "2b983681365e9e905a339c3296e0aa63c2f3fddb320f86c9a89c65c7b6fcc33f") -- Rocksmith 2014 Edition - Remastered - Brian Setzer - Stray Cat Strut - Rocksmith 2014 - More DLC (509674) Depot
addappid(509675, 1, "247ca5eaada7ccac92aec577ff684ea587b30fe5f44f4cb9a223c9590a1029b2") -- Rocksmith 2014 Edition - Remastered - The Fall of Troy - F.C.P.R.E.M.I.X - Rocksmith 2014 - More DLC (509675) Depot
addappid(509676, 1, "cd5a6b3ca56cc4644f264aac8fe4a0b9b315db469da96bd154dba0e29c39c7ca") -- Rocksmith 2014 Edition - Remastered - Gin Blossoms - Hey Jealousy - Rocksmith 2014 - More DLC (509676) Depot
addappid(509677, 1, "0dd3f48ec6f299c1affc3c390475e40ecf34a20ba7a412c4a90c1544383241a0") -- Rocksmith 2014 Edition - Remastered - David Bowie - Suffragette City - Rocksmith 2014 - More DLC (509677) Depot
addappid(509679, 1, "d6ea3a281678d688fa38b971714672f2436974e88d90caa8777f923716b26503") -- Rocksmith 2014 Edition - Remastered - Creedence Clearwater Revival - Bad Moon Rising  - Rocksmith 2014 - More DLC (509679) Depot
addappid(509680, 1, "5d9e9c2fcc2db6e4eacce001db60c95ee869e7de06b7468c7055e2457dc5ccc2") -- Rocksmith 2014 Edition - Remastered - Creedence Clearwater Revival - Fortunate Son - Rocksmith 2014 - More DLC (509680) Depot
addappid(509681, 1, "0223fccd713619a83baab4ecf808e7c7d865e3f66b1a70b03be300c0e0558f2d") -- Rocksmith 2014 Edition - Remastered - Creedence Clearwater Revival - Proud Mary - Rocksmith 2014 - More DLC (509681) Depot
addappid(509683, 1, "e1c490744d938ae245f04364558d19e372243abfc81d9b5ac251214f5e3f372d") -- Rocksmith 2014 Edition - Remastered - Green Day - Good Riddance (Time of Your Life) - Rocksmith 2014 - More DLC (509683) Depot
addappid(509684, 1, "c8f11a1f8a8e339153a6f47592a0d24e291bce8bf89526645d26d12bcfe50217") -- Rocksmith 2014 Edition - Remastered - Green Day - 21 Guns - Rocksmith 2014 - More DLC (509684) Depot
addappid(509685, 1, "c162d3c90aba73b18bd8db505f880848c13fa13fe3b1b5f6f0aa1c305453f95e") -- Rocksmith 2014 Edition - Remastered - Green Day - Wake Me Up When September Ends - Rocksmith 2014 - More DLC (509685) Depot
addappid(509686, 1, "63c48b701fb0114835d5fbc7a2f3481b33dc940f26e6e1b0997c319a54b51806") -- Rocksmith 2014 Edition - Remastered - Green Day - Longview - Rocksmith 2014 - More DLC (509686) Depot
addappid(509687, 1, "bc8217fe5976e022445ba7f7d9e40de336da211a132f23b32218e4a27c1fe5af") -- Rocksmith 2014 Edition - Remastered - Green Day - Bang Bang - Rocksmith 2014 - More DLC (509687) Depot
addappid(509689, 1, "d984f8f1b946d094e503213c6279eb00c3d7a370d7ba718d1a3df010a8432385") -- Rocksmith 2014 Edition - Remastered - U2 - With or Without You - Rocksmith 2014 - More DLC (509689) Depot
addappid(509690, 1, "aa7ade4773630b6a2773c6707aa1214c5cd30c62e91936b0dc855750ad98ed89") -- Rocksmith 2014 Edition - Remastered - U2 - Sunday Bloody Sunday - Rocksmith 2014 - More DLC (509690) Depot
addappid(509691, 1, "f23ded680c29aec76e18ce6e3464d1803e455612364d121d8c018cbff24b3164") -- Rocksmith 2014 Edition - Remastered - U2 - Where the Streets Have No Name - Rocksmith 2014 - More DLC (509691) Depot
addappid(509692, 1, "a98eeaef58aa12d96bc8c6c64548627d0209fc59005d34d8010bdac1e7effbbb") -- Rocksmith 2014 Edition - Remastered - U2 - Beautiful Day - Rocksmith 2014 - More DLC (509692) Depot
addappid(509693, 1, "b162b92063ffb5280c0ac739a07a7f56d811e2669cd4d04d96ffefbf46000d0d") -- Rocksmith 2014 Edition - Remastered - U2 - Vertigo - Rocksmith 2014 - More DLC (509693) Depot
addappid(509695, 1, "2e57bae63bf7e47df304c8eab16210661a25e7484961e8640e62a301b12fdacc") -- Rocksmith 2014 Edition  Remastered  Jefferson Airplane - Somebody To Love - Rocksmith 2014 - More DLC (509695) Depot
addappid(509696, 1, "465b4ebf4094c5a88b3da524081ab8436d2a5b2d7d215adb8012a034836bd13a") -- Rocksmith 2014 Edition  Remastered  Booker T.  the M.G.s - Green Onions - Rocksmith 2014 - More DLC (509696) Depot
addappid(509697, 1, "ff4b2f76b42732b06ba4b0e2e4098bb972fe3a1f82510ac2104dbfcb7c2505b4") -- Rocksmith 2014 Edition  Remastered  The Mamas  The Papas - California Dreamin - Rocksmith 2014 - More DLC (509697) Depot
addappid(509699, 1, "76125b3382673d54ae54d29460778ce81d5d6d4d0fb3dca75070576d686d61b3") -- Rocksmith 2014 Edition  Remastered  blink-182 - I Miss You - Rocksmith 2014 - More DLC (509699) Depot
addappid(509700, 1, "c88241d177e7db29e23e0efab919abd369e446f412d7b0c06bdcc861d380fb1f") -- Rocksmith 2014 Edition  Remastered  blink-182 - Adams Song - Rocksmith 2014 - More DLC (509700) Depot
addappid(509701, 1, "b24df50c17e2b58abcad2c27d07f5d559a0e6a75e7a67bd8f9a249ad85e4e656") -- Rocksmith 2014 Edition  Remastered  blink-182 - The Rock Show - Rocksmith 2014 - More DLC (509701) Depot
addappid(509702, 1, "19f2e10d8b2f0018b79fecf2f97d184d704a5f2792cb0e651a50fdf7c2db7766") -- Rocksmith 2014 Edition  Remastered  blink-182 - First Date - Rocksmith 2014 - More DLC (509702) Depot
addappid(509703, 1, "5e379de983a49d961708171a24669241dd39e9f2f3ee80745881d9856d967a0e") --  Rocksmith 2014 Edition  Remastered  blink-182 - Feeling This - Rocksmith 2014 - More DLC (509703) Depot
addappid(509705, 1, "9ab2cb71b0071b06871fab032aa5b0d6afba277438d4e43dbf0b8aa772a95fda") -- Rocksmith 2014 Edition  Remastered OneRepublic - Counting Stars - Rocksmith 2014 - More DLC (509705) Depot
addappid(509706, 1, "ed77fda50178a60527da919b56bd4e49b13fa189be95ec8b16358160ca727533") -- Rocksmith 2014 Edition  Remastered  The Calling - Wherever You Will Go - Rocksmith 2014 - More DLC (509706) Depot
addappid(509707, 1, "92e4a4dcf7f4ed8c09f3e2be2e967432e32bc6ae6763affb7f7afe88aec7b739") -- Rocksmith 2014 Edition  Remastered  Modern English - I Melt With You - Rocksmith 2014 - More DLC (509707) Depot
addappid(509708, 1, "e5240ba48411f5f10ada4727e5f2f33211fe6a6a4f62f5f3b7c63b6323cdfded") -- Rocksmith 2014 Edition  Remastered  Rage Against the Machine - Take the Power Back - Rocksmith 2014 - More DLC (509708) Depot
addappid(509710, 1, "41c5c60777fc3149ac4c749f3461d7318ca6659e40922cccf984655fd9a5c5a1") -- Rocksmith 2014 - Remastered  Evanescence - My Immortal - Rocksmith 2014 - More DLC (509710) Depot
addappid(509711, 1, "dae20d408dc2cf9897777301b30d94ab19cc066d0ed7e492b4d465620627b216") -- Rocksmith 2014 - Remastered  Evanescence - Going Under - Rocksmith 2014 - More DLC (509711) Depot
addappid(509712, 1, "0be172809173c023ab7c8e8b172867c0742c2179a7416bdb5652e36e2aa181bc") -- Rocksmith 2014 - Remastered  Evanescence - Everybodys Fool - Rocksmith 2014 - More DLC (509712) Depot
addappid(509714, 1, "b86f366499acfb10cc8abb9b792b8ccb233a10b1738def751f27527060c86001") -- Rocksmith 2014 Edition  Remastered  Simple Minds - Dont You (Forget About Me) - Rocksmith 2014 - More DLC (509714) Depot
addappid(509715, 1, "11b95610548e7997eb9c04e7a727a5b6f11af2f6e23134d12534d8639504d72a") -- Rocksmith 2014 Edition  Remastered  Kenny Loggins - Footloose - Rocksmith 2014 - More DLC (509715) Depot
addappid(509716, 1, "453a45042fe4b15255ac223124fb6de60dd0e3cb69fc8174a22aaab79557bd05") -- Rocksmith 2014 Edition  Remastered  Twisted Sister - I Wanna Rock - Rocksmith 2014 - More DLC (509716) Depot
addappid(509718, 1, "b7c97cba1794a3d6c0e27699d2bd094b0318f1697f85a14a5d126e64be09cfcc") -- Rocksmith 2014 Edition  Remastered  Coldplay - The Scientist - Rocksmith 2014 - More DLC (509718) Depot
addappid(509719, 1, "19c574e7baab5d94cb8da3fcccfac1d531d77fbfbbf6e76b96486009bf023fe9") -- Rocksmith 2014 Edition  Remastered  Coldplay - Yellow - Rocksmith 2014 - More DLC (509719) Depot
addappid(509720, 1, "47e890d3cda63d48377c00779823eed63d9eed1fa82e576db4f8a8dc1e469f84") -- Rocksmith 2014 Edition  Remastered  Coldplay - Fix You - Rocksmith 2014 - More DLC (509720) Depot
addappid(509721, 1, "960657553cef28e9e12222501dcc8a66b9f4989a17042e67f93244d8dc82a434") -- Rocksmith 2014 Edition  Remastered  Coldplay - Viva La Vida - Rocksmith 2014 - More DLC (509721) Depot
addappid(509722, 1, "863f45848f3e6dbc9b81f303aabc9a9d8901ce5ec3c2b4e08e498a6f3987fba1") -- Rocksmith 2014 Edition  Remastered  Coldplay - Clocks - Rocksmith 2014 - More DLC (509722) Depot
addappid(509723, 1, "5885cd40e9f2371b7dd1f73a76a32ffc409cf0de08163b0d2b281947b576ddbb") -- Rocksmith 2014 Edition  Remastered  Coldplay - In My Place - Rocksmith 2014 - More DLC (509723) Depot
addappid(509725, 1, "ee0975003c3a7021a57cc4a883bd6bcfb482a9facb3ebccb66abd338e865ec95") -- Rocksmith 2014 Edition  Remastered - Beastie Boys - No Sleep Till Brooklyn - Rocksmith 2014 - More DLC (509725) Depot
addappid(509726, 1, "7a5704404958dda75d4b767a07d403f65171b39d17299b5ace52d9fcef75430b") -- Rocksmith 2014 Edition  Remastered - Beastie Boys - Fight For Your Right - Rocksmith 2014 - More DLC (509726) Depot
addappid(509727, 1, "ebfe012b7df3d74558c45255c5904c398a90f7ea5551bb7f9131eef142178c6f") -- Rocksmith 2014 Edition  Remastered - Beastie Boys - Sabotage - Rocksmith 2014 - More DLC (509727) Depot
addappid(509729, 1, "b2f9a4f33b1369eea138a05a0e2c3a28e0b34f78a08f4bad9b83cf95dbaa6148") -- Rocksmith 2014 Edition  Remastered  Candlebox - Far Behind - Rocksmith 2014 - More DLC (509729) Depot
addappid(509730, 1, "6baebcbfc9fe2da4dfe7025fbd255dc4ece59eed05aa621b7fd7ee86def2cfdf") -- Rocksmith 2014 Edition  Remastered  Tears for Fears - Everybody Wants to Rule the World - Rocksmith 2014 - More DLC (509730) Depot
addappid(509731, 1, "f243b22bf00bdd0ca9a22a90c641e4c0deefef32246cc43b619fa969297f450d") -- Rocksmith 2014 Edition  Remastered  Kasabian - Underdog - Rocksmith 2014 - More DLC (509731) Depot
addappid(509732, 1, "01dc110903405e2bf6adc7712b29e91b9c302400a4543e6b76f3fc5ce5209016") -- Rocksmith 2014 Edition  Remastered  Steppenwolf - Magic Carpet Ride - Rocksmith 2014 - More DLC (509732) Depot
addappid(509734, 1, "0a82535d65468a658a9af045b5a2058bcfd5447de79c80798c7c4ea96df42586") -- Rocksmith 2014 Edition  Remastered  Avril Lavigne - Complicated - Rocksmith 2014 - More DLC (509734) Depot
addappid(509735, 1, "5bd24d9ef183a16de3486c93e6b4d3784cd9efc0d9fc2a1a4c3d31b906856bb4") -- Rocksmith 2014 Edition  Remastered  Avril Lavigne - Im with You - Rocksmith 2014 - More DLC (509735) Depot
addappid(509736, 1, "169322281cccd4b8ae77b4661cf524fe891cb9303e82ceca0d5dd9031b457b0c") -- Rocksmith 2014 Edition  Remastered  Avril Lavigne - Sk8er Boi - Rocksmith 2014 - More DLC (509736) Depot
addappid(509737, 1, "4a0ebaba12f8f4eb3c72e338f39d7bb852e492bdd2ae1c1d0a763f8d8f1b612c") -- Rocksmith 2014 Edition  Remastered  Avril Lavigne - My Happy Ending - Rocksmith 2014 - More DLC (509737) Depot
addappid(509738, 1, "6477705fe3957c3e8b20b0c93d82c5754da3a6e737af9116c23008e0c27f1606") -- Rocksmith 2014 Edition  Remastered  Avril Lavigne - When Youre Gone - Rocksmith 2014 - More DLC (509738) Depot
addappid(509740, 1, "9b930e4924cd1af5d333481d4e29a961e25e8f8f0404fad23021ae4b326ae449") -- Rocksmith 2014 Edition  Remastered  Eve 6 - Inside Out - Rocksmith 2014 - More DLC (509740) Depot
addappid(509741, 1, "f589d302e7834b508c663c454f1b8a87454bc8d322a57a28fd69f70d0c3edf43") -- Rocksmith 2014 Edition  Remastered  Tonic - If You Could Only See - Rocksmith 2014 - More DLC (509741) Depot
addappid(509742, 1, "13e03844d8ed8fe1fbb48d593e958c235c36523020d1397ea5ab4c81157a8e28") -- Rocksmith 2014 Edition  Remastered  Hole - Violet - Rocksmith 2014 - More DLC (509742) Depot
addappid(509744, 1, "8dfc5db89fed7d5bff153010e0dcb75597bfdf6770f037985a8b72331085fc1a") -- Rocksmith 2014 Edition  Remastered  Skid Row - 18 And Life - Rocksmith 2014 - More DLC (509744) Depot
addappid(509745, 1, "0322b6b827dd6b5658cc8ef0825a55725cc88de303e5bbeba008be3cc1c32577") -- Rocksmith 2014 Edition  Remastered  Skid Row - I Remember You - Rocksmith 2014 - More DLC (509745) Depot
addappid(509746, 1, "82c92fbba3126e1978e69ec2f796090f032fa491a0e3d903a1b8cd04786f4d9e") -- Rocksmith 2014 Edition  Remastered  Skid Row - Youth Gone Wild - Rocksmith 2014 - More DLC (509746) Depot
addappid(509747, 1, "553b0e2073d05337001027826fb6673a284384ccdfc9a2f2d6ce4ea682969c92") -- Rocksmith 2014 Edition  Remastered  Skid Row - Monkey Business - Rocksmith 2014 - More DLC (509747) Depot
addappid(509748, 1, "fcefed696868a77be2d895a521fe1e80809404016e64668e8deb3c5bb66d65db") -- Rocksmith 2014 Edition  Remastered  Skid Row - Slave to the Grind - Rocksmith 2014 - More DLC (509748) Depot
addappid(590170, 1, "ec6aa2df376dc13aeecebcccd7a8802e9bd4feceb3b608c6834cfd7bdd32aacf") -- Rocksmith 2014 Edition  Remastered  Goldfinger - Superman - Rocksmith 2014 - DLC 2017 (590170) Depot
addappid(590171, 1, "9f7edab8f872e7c4965412cfdb42ed3e739c312db1fd053e199a83ac427590b5") -- Rocksmith 2014 Edition  Remastered  Bad Religion - You - Rocksmith 2014 - DLC 2017 (590171) Depot
addappid(590172, 1, "fd1ffcada9354723cfc07d0afb752d4cdcb4da822af2180d25de94bc91211f02") -- Rocksmith 2014 Edition  Remastered  Lagwagon - May 16 - Rocksmith 2014 - DLC 2017 (590172) Depot
addappid(590173, 1, "92a2ca6a4c8fe8097417b78d0d7fc50408fb6aa1627626680abaee5e1df1b26d") -- Rocksmith 2014 Edition  Remastered  Powerman 5000 - When Worlds Collide - Rocksmith 2014 - DLC 2017 (590173) Depot
addappid(590174, 1, "a1f686972f781ef1fd11f43c62141b81ccbf679fa395db740ed8005bb0632c20") -- Rocksmith 2014 Edition  Remastered  Millencolin - No Cigar - Rocksmith 2014 - DLC 2017 (590174) Depot
addappid(590184, 1, "975ca38c8b8a90cb989d8d545ce15f650905c6b282ae0d53750835955621736f") -- Rocksmith 2014 Edition  Remastered  Pearl Jam - Yellow Ledbetter - Rocksmith 2014 - DLC 2017 (590184) Depot
addappid(590185, 1, "5fcec12e76485d36b2d00b071943ce93dac959b316511741e4cb5d2e557c0fd3") -- Rocksmith 2014 Edition  Remastered  Pearl Jam - Even Flow - Rocksmith 2014 - DLC 2017 (590185) Depot
addappid(590186, 1, "f263feef4736a47e53f8d39fc57ac4fdf41a552fa0fb2a11c5364bcb9d8ca23a") -- Rocksmith 2014 Edition  Remastered  Pearl Jam - Do the Evolution - Rocksmith 2014 - DLC 2017 (590186) Depot
addappid(590187, 1, "3fd3699f3a828158b0b25e6af0efe114d4faf0e349df9a8203f2a1aa075f94b2") -- Rocksmith 2014 Edition  Remastered  Pearl Jam - Rearviewmirror - Rocksmith 2014 - DLC 2017 (590187) Depot
addappid(590188, 1, "6f794ef8304e20c84bee30ec2b9e4ac6eb1c18bceaea0a8a7bfee424a898045c") -- Rocksmith 2014 Edition  Remastered  Pearl Jam - Last Exit - Rocksmith 2014 - DLC 2017 (590188) Depot
addappid(590190, 1, "c7a92f9eed5b2da2b390e35942d2a02562017f774c36607fd72fc83699c844ae") -- Rocksmith 2014 Edition  Remastered  James Bay - Let It Go - Rocksmith 2014 - DLC 2017 (590190) Depot
addappid(590191, 1, "8a032d3df0940f1bc24d32ef5a68e1e8a768d72edcf36fafb936bffb360ecd25") -- Rocksmith 2014 Edition  Remastered  Jack Johnson - Banana Pancakes - Rocksmith 2014 - DLC 2017 (590191) Depot
addappid(590192, 1, "451dcdfe2f9e1165c4eac7e8109f32293454e99c88fbde191554e0bc73ceff30") -- Rocksmith 2014 Edition  Remastered  Joe Satriani - Surfing with the Alien - Rocksmith 2014 - DLC 2017 (590192) Depot
addappid(590193, 1, "8680ad399110121aa04823a9db6bb625748743c9052f69bae7eb443af9365b35") -- Rocksmith 2014 Edition  Remastered  311 - All Mixed Up - Rocksmith 2014 - DLC 2017 (590193) Depot
addappid(590195, 1, "c5abf422bf52bf426f29b35e2e91b1d55849f119de911a4076fa933487896672") -- Rocksmith 2014 Edition  Remastered  Bob Marley  The Wailers - Redemption Song - Rocksmith 2014 - DLC 2017 (590195) Depot
addappid(590196, 1, "419ae1a6e668245d29e9b4885d26a16504d5c3201e82bc88cee932427d34e010") -- Rocksmith 2014 Edition  Remastered  Bob Marley  The Wailers - No Woman, No Cry - Rocksmith 2014 - DLC 2017 (590196) Depot
addappid(590197, 1, "09b74f0a27a73cc6392bc4e973470b0910fd93c99b9fc6f469739f8c0f164847") -- Rocksmith 2014 Edition  Remastered  Bob Marley  The Wailers - Is This Love - Rocksmith 2014 - DLC 2017 (590197) Depot
addappid(590198, 1, "390e88b76378c1d827792f3840a2aea8f8b456a09cbdbf1c0da05f191f3438a5") -- Rocksmith 2014 Edition  Remastered  Bob Marley  The Wailers - Could You Be Loved - Rocksmith 2014 - DLC 2017 (590198) Depot
addappid(590199, 1, "d7402fbacc5e3b2d00d1fe64940604090573ab54b8cc1b2aeabd36f02f1e9f96") -- Rocksmith 2014 Edition  Remastered  Bob Marley  The Wailers - Buffalo Soldier - Rocksmith 2014 - DLC 2017 (590199) Depot
addappid(590202, 1, "f39b4fa5507070ef4600b1ddb07af2bcb5d4800fd57b7ec885e16707eb592059") -- Rocksmith 2014 Edition  Remastered  Royal Blood - Figure It Out - Rocksmith 2014 - DLC 2017 (590202) Depot
addappid(590203, 1, "6ced5db38710b9442bcfb3e90a92fc1d64839a8b83909478bb89baf66cdc5e9a") -- Rocksmith 2014 Edition  Remastered  Royal Blood - Little Monster - Rocksmith 2014 - DLC 2017 (590203) Depot
addappid(590204, 1, "143a8d7288617d0e46cebc31a62ca40044f63af3d33fea40fff65d2980b71333") -- Rocksmith 2014 Edition  Remastered  Royal Blood - Out of the Black - Rocksmith 2014 - DLC 2017 (590204) Depot
addappid(590206, 1, "b28a1b8c8ed9c8a3e0b4544099bf7b745324c6f21449dbf8d999d35a7becdb9f") -- Rocksmith 2014 Edition  Remastered  David Bowie - Moonage Daydream - Rocksmith 2014 - DLC 2017 (590206) Depot
addappid(590207, 1, "81b87c41bab5200265170682990a04c9623078195786c9d66ba5e2b31dbdad9f") -- Rocksmith 2014 Edition  Remastered  Marvin Gaye  Tammi Terrell - Aint No Mountain High Enough - Rocksmith 2014 - DLC 2017 (590207) Depot
addappid(590208, 1, "3c8fa4f0a096511e57d8dfb206e2a1bc38e8f98b1855f1159b7e4889a1811442") -- Rocksmith 2014 Edition  Remastered  Redbone - Come and Get Your Love - Rocksmith 2014 - DLC 2017 (590208) Depot
addappid(590209, 1, "b831a34fabcf7b7d93f4c7216d5999a6f4cf2010d3182c34f59425b030a1f984") -- Rocksmith 2014 Edition  Remastered  Blue Swede - Hooked on a Feeling - Rocksmith 2014 - DLC 2017 (590209) Depot
addappid(590210, 1, "34235be2deacf0783fe0989c93e2579f8f5eaefe2ec1ec70d2d23edefacde069") -- Rocksmith 2014 Edition  Remastered  Raspberries - Go All the Way - Rocksmith 2014 - DLC 2017 (590210) Depot
addappid(590212, 1, "9bfe104c3e8d263acb66317c86445395a9902ba48c589751e8cb580f90aa9555") -- Rocksmith 2014 Edition  Remastered  Sheryl Crow - If It Makes You Happy - Rocksmith 2014 - DLC 2017 (590212) Depot
addappid(590213, 1, "f993b3b136f271c2bd557aefedb6ef754b54976b6c25af3adef5d7b9a8b7de77") -- Rocksmith 2014 Edition  Remastered  Sheryl Crow - Soak Up the Sun - Rocksmith 2014 - DLC 2017 (590213) Depot
addappid(590214, 1, "2550427848354ef6c4fac41b92f10dc1d426e24332c3ae210aa1c4b6cd68820b") -- Rocksmith 2014 Edition  Remastered  Sheryl Crow - My Favorite Mistake - Rocksmith 2014 - DLC 2017 (590214) Depot
addappid(590216, 1, "03526660fdd20c1e76a08acd54b77618fb4192bbb31dc6cf4534964c92928d77") -- Rocksmith 2014 Edition  Remastered  Grateful Dead - Truckin - Rocksmith 2014 - DLC 2017 (590216) Depot
addappid(590217, 1, "b49615d5eb59fde8adfe81a69f443b579845f338c2e9be9622214039f7ae6bf2") -- Rocksmith 2014 Edition  Remastered  Grateful Dead - Uncle Johns Band - Rocksmith 2014 - DLC 2017 (590217) Depot
addappid(590218, 1, "0fd7eb7aba3e3ed3ad296b6d137173cb1da56709ef2a0e9749d552ebd01aa288") -- Rocksmith 2014 Edition  Remastered  Grateful Dead - Casey Jones - Rocksmith 2014 - DLC 2017 (590218) Depot
addappid(590219, 1, "cfdbbab9d0fb9aaf5f6832db605b3c5c4442c573653f86a40fc255bbfddb3c61") -- Rocksmith 2014 Edition  Remastered  Grateful Dead - Friend of the Devil - Rocksmith 2014 - DLC 2017 (590219) Depot
addappid(590220, 1, "6003e33d1d7300adbf9994f72050795d70bbe5210f8d247aa607ffb881c769a9") -- Rocksmith 2014 Edition  Remastered  Grateful Dead - Sugar Magnolia - Rocksmith 2014 - DLC 2017 (590220) Depot
addappid(590222, 1, "9e7e664e39b32202946f3658feb1bb1283eadb86896b09c870767bc502473e3c") -- Rocksmith 2014 Edition  Remastered  Black Flag - Rise Above - Rocksmith 2014 - DLC 2017 (590222) Depot
addappid(590223, 1, "d7b4dcf97ffac5ada94036f089b10656a258c1b39f12fbd2ea65c574077fb3cd") -- Rocksmith 2014 Edition  Remastered  REO Speedwagon - Take It on the Run - Rocksmith 2014 - DLC 2017 (590223) Depot
addappid(590224, 1, "49662778346fc3e747f4cc9c0839e0bb82c438405353dc0891eeffb40d283fc0") -- Rocksmith 2014 Edition  Remastered  Queen - I Want It All - Rocksmith 2014 - DLC 2017 (590224) Depot
addappid(590226, 1, "1a1dc1f77d13c0c2753cc8a3a3a013fde5536b7000baa28ef2531ff9b406652b") -- Rocksmith 2014 Edition  Remastered  New Found Glory - My Friends Over You - Rocksmith 2014 - DLC 2017 (590226) Depot
addappid(590227, 1, "44d36c65f787f499fb204b3c8993dec60e6654ce26dd2fa27008025a67164551") -- Rocksmith 2014 Edition  Remastered  New Found Glory - All Downhill from Here - Rocksmith 2014 - DLC 2017 (590227) Depot
addappid(590228, 1, "948f249fb22244c81cff0986649d9ddb053e908a2cb57367a8c3e16149f2ca6a") -- Rocksmith 2014 Edition  Remastered  New Found Glory - Hit or Miss - Rocksmith 2014 - DLC 2017 (590228) Depot
addappid(590230, 1, "e32b9f2d1af320a7630e4c7039271c4a02f82f0607b4bf7709a39233e4b507ea") -- Rocksmith 2014 Edition  Remastered  The Lively Ones - Surf Rider - Rocksmith 2014 - DLC 2017 (590230) Depot
addappid(590231, 1, "73f84ed26571bc4e7b3c1f836f28ce71e492e65e30cf8339ae788053977122d8") -- Rocksmith 2014 Edition  Remastered  The Chantays - Pipeline - Rocksmith 2014 - DLC 2017 (590231) Depot
addappid(590232, 1, "1b5b079255ed8a2690051a62218b926cb3a8cdc0ff48efdd5c9671a5623ba9d9") -- Rocksmith 2014 Edition  Remastered  The Pyramids - Penetration - Rocksmith 2014 - DLC 2017 (590232) Depot
addappid(590233, 1, "908cd93879a5cea6582eb94a438d55accb203c8754e44c0a11abbb3870bb5a56") -- Rocksmith 2014 Edition  Remastered  The Beach Boys - Surfin U.S.A. - Rocksmith 2014 - DLC 2017 (590233) Depot
addappid(590235, 1, "85a85bc297e337697d05db36b661676fd407e7ce7e9e95ea45e5abfb181e86ea") -- Rocksmith 2014 Edition  Remastered  Live - All Over You - Rocksmith 2014 - DLC 2017 (590235) Depot
addappid(590236, 1, "6caa263f2c4bcfb0644285e605a3c538c64e1c1371cf6661448b804b5c027973") -- Rocksmith 2014 Edition  Remastered  Live - I Alone - Rocksmith 2014 - DLC 2017 (590236) Depot
addappid(590237, 1, "e440646ad08f858249a8b3590d451df6a9af989ed8079beb67e4a91b89dc9d84") -- Rocksmith 2014 Edition  Remastered  Live - Lightning Crashes - Rocksmith 2014 - DLC 2017 (590237) Depot
addappid(590238, 1, "fab5b97d38939cd3a7777d351110df81b243856f7608ba29d76cf1c57fbb8390") -- Rocksmith 2014 Edition  Remastered  Live - Selling the Drama - Rocksmith 2014 - DLC 2017 (590238) Depot
addappid(590239, 1, "7cb384a440f09fe8ec264d11b1e63c64500205d7f868b4ee2c5b3d4b87075d05") -- Rocksmith 2014 Edition  Remastered  Live - The Dolphins Cry - Rocksmith 2014 - DLC 2017 (590239) Depot
addappid(590241, 1, "b88f1681f50f8060f8e22db64cef8fa8e889f60e6131ed70f7fec34f7c8f6e89") -- Rocksmith 2014 Edition  Remastered  Jace Everett - Bad Things - Rocksmith 2014 - DLC 2017 (590241) Depot
addappid(590242, 1, "06d2c2beb8c7f907a1ba4c7a258e9f96158a12cd1c0469506ef4b205f128b7d0") -- Rocksmith 2014 Edition  Remastered  Kiss - Lick It Up - Rocksmith 2014 - DLC 2017 (590242) Depot
addappid(590243, 1, "885c45fedab7088fc71931026a90ab885a9672ff0a417472d25fbbb907e9780b") -- Rocksmith 2014 Edition  Remastered  Pantera - Mouth for War - Rocksmith 2014 - DLC 2017 (590243) Depot
addappid(590244, 1, "8640a21b92ffbd1dfac5dead2306800074697a70103907e79a70b56e67db99b6") -- Rocksmith 2014 Edition  Remastered  X - Los Angeles - Rocksmith 2014 - DLC 2017 (590244) Depot
addappid(590246, 1, "9ec1f6a2a725f16ba6b49b1ac436704b8bb644c9bc00246730dc69345e573b00") -- Rocksmith 2014 Edition  Remastered  Alabama Shakes - Hold On - Rocksmith 2014 - DLC 2017 (590246) Depot
addappid(590247, 1, "8699022cd93c7080a07bbe422e4de47c399245a2d5440841a9f41971759d23bd") -- Rocksmith 2014 Edition  Remastered  Alabama Shakes - Dont Wanna Fight - Rocksmith 2014 - DLC 2017 (590247) Depot
addappid(590248, 1, "5dbef5dd3390dcd3a9341541f510388246772fa671637d02af44763c96081298") -- Rocksmith 2014 Edition  Remastered  Alabama Shakes - Gimme All Your Love - Rocksmith 2014 - DLC 2017 (590248) Depot
addappid(590249, 1, "314ab5e12bd967faf257903946b00c2d8f37dfa8a9057c1d6e8740a95f1f37d9") -- Rocksmith 2014 Edition  Remastered  Alabama Shakes - Always Alright - Rocksmith 2014 - DLC 2017 (590249) Depot
addappid(637691, 1, "3de59c98030667c9c2ad02fae3be6f932c42b70f9c13583556978b8316d8e4e6") -- Rocksmith 2014 Edition  Remastered  Jim Croce - Time in a Bottle - Rocksmith 2014 Edition - Remastered DLC (637691) Depot
addappid(637692, 1, "4ddf053663e4dbc5d0def52ee214b858d9ec18cb45794e7f9b5d8fff9aecbbae") -- Rocksmith 2014 Edition  Remastered  Peter Frampton - Do You Feel Like We Do - Rocksmith 2014 Edition - Remastered DLC (637692) Depot
addappid(637693, 1, "98e118c808dbad8420eb535ecd95ea2c42e0ff8bfc22da1b89173a1197f6d041") -- Rocksmith 2014 Edition  Remastered  Thin Lizzy - Cowboy Song - Rocksmith 2014 Edition - Remastered DLC (637693) Depot
addappid(637695, 1, "22391c6b4f8da38df30c7cb5de2ec0a02d0eba1f3ddd7e59cc8cda4f44423c22") -- Rocksmith 2014 Edition  Remastered  The Strokes - 1251 - Rocksmith 2014 Edition - Remastered DLC (637695) Depot
addappid(637696, 1, "94d3799c15a877245137d3e4f32b5043e1dc747f6111d2e40abd98ce6923a715") -- Rocksmith 2014 Edition  Remastered  The Strokes - You Only Live Once - Rocksmith 2014 Edition - Remastered DLC (637696) Depot
addappid(637697, 1, "efa41d7bd2da606c691202d5b96b106db3bdce3004d9e4a660b8e8846ced30da") -- Rocksmith 2014 Edition  Remastered  The Strokes - Someday - Rocksmith 2014 Edition - Remastered DLC (637697) Depot
addappid(637698, 1, "4cec701a38b1ca9f2e063a873d24163152b1e9b1988365f9392ebe778feaefb0") -- Rocksmith 2014 Edition  Remastered  The Strokes - Taken for a Fool - Rocksmith 2014 Edition - Remastered DLC (637698) Depot
addappid(637700, 1, "a37cb7fb4e3a7fe5f28bfb2937539432057206b716e40a0f8b60ab9366c3c854") -- Rocksmith 2014 Edition  Remastered  Spin Doctors - Little Miss Cant Be Wrong - Rocksmith 2014 Edition - Remastered DLC (637700) Depot
addappid(637701, 1, "264fddb642c879d5ac1b63020cac9410b66a85c5344a89375c396fe1d95bc881") -- Rocksmith 2014 Edition  Remastered  Supergrass - Alright - Rocksmith 2014 Edition - Remastered DLC (637701) Depot
addappid(637702, 1, "47cb6759b515027b40c4f846d6f453d93954dc0f75d58a4c9f0ccb5903a3010e") -- Rocksmith 2014 Edition  Remastered  Tom Cochrane - Life is a Highway - Rocksmith 2014 Edition - Remastered DLC (637702) Depot
addappid(637704, 1, "a733240ecebaa5cf0b58b1f36a05d55d49fcd805c8dd66a54932340f4a3dc7c5") -- Rocksmith 2014 Edition  Remastered  Marilyn Manson - Coma White - Rocksmith 2014 Edition - Remastered DLC (637704) Depot
addappid(637705, 1, "f7f16e49713e98a346cba6cf08e2ac9ae26ef873625973ebd47aa5bc06f364f8") -- Rocksmith 2014 Edition  Remastered  Marilyn Manson - The Beautiful People - Rocksmith 2014 Edition - Remastered DLC (637705) Depot
addappid(637706, 1, "5bf15a7b47f36727388676e50aa6b685f672c21b124f2033f16a8edee45e7123") -- Rocksmith 2014 Edition  Remastered  Marilyn Manson - Tourniquet - Rocksmith 2014 Edition - Remastered DLC (637706) Depot
addappid(637708, 1, "8fd304dd9039ef1ad1a761b78661e7018142043681dac6dbf3a51c6a12c9a421") -- Rocksmith 2014 Edition  Remastered  The Monkees - Last Train to Clarksville - Rocksmith 2014 Edition - Remastered DLC (637708) Depot
addappid(637709, 1, "3504aa514647322e16bd74fe10a6cee832b36e9702fbb69ef3a889150c5e6849") -- Rocksmith 2014 Edition  Remastered  The Monkees - Pleasant Valley Sunday - Rocksmith 2014 Edition - Remastered DLC (637709) Depot
addappid(637710, 1, "502b321a874f4fee5544ca9d62252d1eb0d89371cb801e740e11200f362c91fe") -- Rocksmith 2014 Edition  Remastered  The Monkees - Valleri - Rocksmith 2014 Edition - Remastered DLC (637710) Depot
addappid(637712, 1, "70c15988fc1eb2e2e6b33e2307a5e82d84d7c769cb7dbcf892f45c892d46ce30") -- Rocksmith 2014 Edition  Remastered  Bring Me the Horizon - Can You Feel My Heart - Rocksmith 2014 Edition - Remastered DLC (637712) Depot
addappid(637713, 1, "da3b2e01495af459e4d455495c32294747a068742cf3a4c31ede8cc89352e477") -- Rocksmith 2014 Edition  Remastered  The Gaslight Anthem - 45 - Rocksmith 2014 Edition - Remastered DLC (637713) Depot
addappid(637714, 1, "353740f7c7429fbc64d3563c3ec146fd34bdfde6ee6fb9cb4563803e236d86bd") -- Rocksmith 2014 Edition  Remastered  Passenger - Let Her Go - Rocksmith 2014 Edition - Remastered DLC (637714) Depot
addappid(637716, 1, "49332b501cf8a672b538fdf2618538fd23678aab2a5bb2acee74808ade5ea258") -- Rocksmith 2014 Edition  Remastered  Muddy Waters - Mannish Boy - Rocksmith 2014 Edition - Remastered DLC (637716) Depot
addappid(637717, 1, "35574eafb4255a9d6c979e7efa90e5394c542e8955033d903c9555f9fa090324") -- Rocksmith 2014 Edition  Remastered  Muddy Waters - Honey Bee - Rocksmith 2014 Edition - Remastered DLC (637717) Depot
addappid(637718, 1, "cd6baa8613e86e17eb5e34c864c6c87fc0b61aa365ea9dda999b0f2067ca3056") -- Rocksmith 2014 Edition  Remastered  Muddy Waters - I Cant Be Satisfied - Rocksmith 2014 Edition - Remastered DLC (637718) Depot
addappid(637719, 1, "6e459816f3c33f3b6c4e96bb80fa7988646a980302a604b93260a4d3014f5f1b") -- Rocksmith 2014 Edition  Remastered  Muddy Waters - Still A Fool - Rocksmith 2014 Edition - Remastered DLC (637719) Depot
addappid(637721, 1, "65d5a58645588a831a5ce4a62e34f3bf1c8273b82d9ec11ec070ad28ab151faf") -- Rocksmith 2014 Edition  Remastered  Airbourne - Blonde, Bad and Beautiful - Rocksmith 2014 Edition - Remastered DLC (637721) Depot
addappid(637722, 1, "50fd1028af253871e6b1074ce278d1db19d8bbe373bb3e4b7d15da4f69fc835d") -- Rocksmith 2014 Edition  Remastered  Airbourne - Runnin Wild - Rocksmith 2014 Edition - Remastered DLC (637722) Depot
addappid(637723, 1, "a767b13eb9782ee4a16ae6c5f651f9045fe56333fb56f98412ce8514a436df27") -- Rocksmith 2014 Edition  Remastered  Airbourne - Too Much, Too Young, Too Fast - Rocksmith 2014 Edition - Remastered DLC (637723) Depot
addappid(637725, 1, "a17349ce394d2b095c37a0b59e83ad688459fd9474c3ad1b148d37285814fb82") -- Rocksmith 2014 Edition  Remastered  Bombay Bicycle Club - Your Eyes - Rocksmith 2014 Edition - Remastered DLC (637725) Depot
addappid(637726, 1, "1f3d12a9dc8f634b2ff0409df1a9cef3d0939a1823c7a41bb64a87e81d975fe4") -- Rocksmith 2014 Edition  Remastered  Escape The Fate - This War Is Ours (The Guillotine II) - Rocksmith 2014 Edition - Remastered DLC (637726) Depot
addappid(637727, 1, "efdba0d4eaea25ad8eaad29996fae2aa12a154f01ae3bf55e9a479f5b6f2de3a") -- Rocksmith 2014 Edition  Remastered  The Flaming Lips - She Dont Use Jelly - Rocksmith 2014 Edition - Remastered DLC (637727) Depot
addappid(637728, 1, "98e3769618d49918f8c344ac84e4dc3d2bdba279d2b708478a357c86163b2f9b") -- Rocksmith 2014 Edition  Remastered  George Strait - All My Exs Live in Texas - Rocksmith 2014 Edition - Remastered DLC (637728) Depot
addappid(637730, 1, "bd6d5e00212fc9e96128ad7566879bb6720be31a6830b288520da84386e0ea70") -- Rocksmith 2014 Edition  Remastered  3 Doors Down - Its Not My Time - Rocksmith 2014 Edition - Remastered DLC (637730) Depot
addappid(637731, 1, "1a4f6abd5ee38aa59d1bfec127c459a84f14850f52115f6692e5e59330b617c3") -- Rocksmith 2014 Edition  Remastered  3 Doors Down - Let Me Go - Rocksmith 2014 Edition - Remastered DLC (637731) Depot
addappid(637732, 1, "e67eb399f100d36797cbf58b905807b2ec412556aafd5b761e67eb413b7994f5") -- Rocksmith 2014 Edition  Remastered  3 Doors Down - Be Like That - Rocksmith 2014 Edition - Remastered DLC (637732) Depot
addappid(637733, 1, "975b7fcd57147962b63f175f62b939c628e6b4a5ba29c13588819b1f81ad7eb0") -- Rocksmith 2014 Edition  Remastered  3 Doors Down - Here Without You - Rocksmith 2014 Edition - Remastered DLC (637733) Depot
addappid(637734, 1, "859d05a30a4f1731c6e82aa4c054b28eb63261a849ab6a4b5b6d2e4503ff86fb") -- Rocksmith 2014 Edition  Remastered  3 Doors Down - Away from the Sun - Rocksmith 2014 Edition - Remastered DLC (637734) Depot
addappid(637736, 1, "ae68d4e3c0c41021f11d28e3a8080013a5fa6bbc069008da716c5a8431299566") -- Rocksmith 2014 Edition  Remastered  Ratt - Lay It Down - Rocksmith 2014 Edition - Remastered DLC (637736) Depot
addappid(637737, 1, "0705398f2baf3f2a6911c3d4d37e3c5c8af896b161b6d7909076ccfc8d9b8753") -- Rocksmith 2014 Edition  Remastered  Steve Winwood - Higher Love - Rocksmith 2014 Edition - Remastered DLC (637737) Depot
addappid(637738, 1, "412ed1c7248d943d5248cf816a581033cd4946462b179a8a197948dc26c76bc8") -- Rocksmith 2014 Edition  Remastered  Huey Lewis  The News - Hip To Be Square - Rocksmith 2014 Edition - Remastered DLC (637738) Depot
addappid(637740, 1, "31b84c429900e00489e5c873d0e04792150636fbd3ec395cd2cbb3ebaccabc80") -- Rocksmith 2014 Edition  Remastered  Thrice - The Artist in the Ambulance - Rocksmith 2014 Edition - Remastered DLC (637740) Depot
addappid(637741, 1, "d634b85c9ece8070ea3081e3080c73b9cefbf94a50d99e7052b8804c219cc022") -- Rocksmith 2014 Edition  Remastered  Thrice - Deadbolt - Rocksmith 2014 Edition - Remastered DLC (637741) Depot
addappid(637742, 1, "28e370768335c5d4deba736d9a07e370daf44e049d7207781674b80b8cf466b0") -- Rocksmith 2014 Edition  Remastered  Thrice - Stare at the Sun - Rocksmith 2014 Edition - Remastered DLC (637742) Depot
addappid(637744, 1, "81b6fc016a95bd48d98354a08b71121ca0998ea00131abde9fa3f9b7f831f3e9") -- Rocksmith 2014 Edition  Remastered  Goldfinger - 99 Red Balloons - Rocksmith 2014 Edition - Remastered DLC (637744) Depot
addappid(637745, 1, "d7e4308c6e099843af59ad2b9cb4816652b97a4f23c56d2a43a31548ae021892") -- Rocksmith 2014 Edition  Remastered  Marilyn Manson - Tainted Love - Rocksmith 2014 Edition - Remastered DLC (637745) Depot
addappid(637746, 1, "578942515f284d99824c836706745ec7126889fde0cf0c69a6563f5aee0a125e") -- Rocksmith 2014 Edition  Remastered  Seether - Careless Whisper - Rocksmith 2014 Edition - Remastered DLC (637746) Depot
addappid(637747, 1, "3bf7dc2a2aaf35669571db52d4143b74d511bbb7bcfe3943166e6a8b00cd749a") -- Rocksmith 2014 Edition  Remastered  Halestorm - Bad Romance - Rocksmith 2014 Edition - Remastered DLC (637747) Depot
addappid(637749, 1, "334c677bb11e774d258f677d70d40ea1d39f5ec4b9aff7a4edcb153f55749f84") -- Rocksmith 2014 Edition  Remastered  Four Tops - I Cant Help Myself (Sugar Pie Honey Bunch) - Rocksmith 2014 Edition - Remastered DLC (637749) Depot
addappid(637750, 1, "e576c906845e99ea4d07f2e2f187794a3f572489643f7231f056ec47b93e871b") -- Rocksmith 2014 Edition  Remastered  Four Tops - Bernadette - Rocksmith 2014 Edition - Remastered DLC (637750) Depot
addappid(637751, 1, "ec8d13b1d486bdb5fbc0f6eb8bb634bfe07f0867863e67bb1c5fbce4a2088adb") -- Rocksmith 2014 Edition  Remastered  Four Tops - Reach Out Ill Be There - Rocksmith 2014 Edition - Remastered DLC (637751) Depot
addappid(637752, 1, "c50c4ee40bd055c4a983aa07db910e12f244d275d0ea9bcd35664a52698858eb") -- Rocksmith 2014 Edition  Remastered  Four Tops - Its the Same Old Song - Rocksmith 2014 Edition - Remastered DLC (637752) Depot
addappid(637754, 1, "5c3c58078baa0fede22117443f2c6052d084db48fa529011a9435466115ae00e") -- Rocksmith 2014 Edition  Remastered  Hinder - Lips of an Angel - Rocksmith 2014 Edition - Remastered DLC (637754) Depot
addappid(637755, 1, "935ed29bd8428a852047bde9f9b818abbe590fe4a106a3d13d87f1381d581058") -- Rocksmith 2014 Edition  Remastered  Band of Horses - The Funeral - Rocksmith 2014 Edition - Remastered DLC (637755) Depot
addappid(637756, 1, "26955662a7b7a17089a7ba2104beabecec3a4b1868caaf8e711af84c3450ffb8") -- Rocksmith 2014 Edition  Remastered  Kelly Clarkson - Breakaway - Rocksmith 2014 Edition - Remastered DLC (637756) Depot
addappid(637758, 1, "0f9810a8768b62b87f61f42b02932ab963c728802a39acb1caa35c1d67569d57") -- Rocksmith 2014 Edition  Remastered  Bachman-Turner Overdrive - Takin Care of Business - Rocksmith 2014 Edition - Remastered DLC (637758) Depot
addappid(637759, 1, "868843829242866960254248bfe9cc561dea01803757ad79481dcd3f74c09045") -- Rocksmith 2014 Edition  Remastered  Bachman-Turner Overdrive - You Aint Seen Nothing Yet - Rocksmith 2014 Edition - Remastered DLC (637759) Depot
addappid(637760, 1, "caae5302f9eee477357c1a8ce811ab224eb5121b48844b3bd03d495959de58e9") -- Rocksmith 2014 Edition  Remastered  Bachman-Turner Overdrive - Let It Ride - Rocksmith 2014 Edition - Remastered DLC (637760) Depot
addappid(637762, 1, "edcd43cc2274c5f4d4f65c35de764c02fb0d8d8ff0e0ab79a9025d954a7a38ea") -- Rocksmith 2014 Edition  Remastered  DragonForce - Through the Fire and Flames - Rocksmith 2014 Edition - Remastered DLC (637762) Depot
addappid(637763, 1, "60d46bef9ab896af44b4e02cf38fb7509ae9f7ccef2c86de116d3cc5334158d4") -- Rocksmith 2014 Edition  Remastered  Elton John - Saturday Nights Alright (For Fighting) - Rocksmith 2014 Edition - Remastered DLC (637763) Depot
addappid(637764, 1, "f3e2172536a9e541bffe11800ef47c6e46c2afa517849750eae1a9cc9ba31e07") -- Rocksmith 2014 Edition  Remastered  Colin Hay of Men at Work - Down Under 2012 - Rocksmith 2014 Edition - Remastered DLC (637764) Depot
addappid(637765, 1, "79c98bebc876932257f9acb42ce7ad649733a66b998a0d09023f87e780bf9d40") -- Rocksmith 2014 Edition  Remastered  Rusted Root - Send Me On My Way - Rocksmith 2014 Edition - Remastered DLC (637765) Depot
addappid(637767, 1, "fa5158395834dffccf2736955350f200be6bab6f54cd2bd76eab7a12027490fa") -- Rocksmith 2014 Edition  Remastered  Amon Amarth - Guardians of Asgaard - Rocksmith 2014 Edition - Remastered DLC (637767) Depot
addappid(637768, 1, "ff9fc30e134cd19a7edcbbebbb8e1933cbf784925cef425d9deadde68706d488") -- Rocksmith 2014 Edition  Remastered  Amon Amarth - Death in Fire - Rocksmith 2014 Edition - Remastered DLC (637768) Depot
addappid(637769, 1, "397c30e7aa4ab6820a1018e03eb90f66fb44274942d666bcc8a1f29ee75c206d") -- Rocksmith 2014 Edition  Remastered  Amon Amarth - The Pursuit of Vikings - Rocksmith 2014 Edition - Remastered DLC (637769) Depot
addappid(637770, 1, "6ead696df8045a7f495eb2484a00622e3f20f93168c8334255fd25099be9b9e3") -- Rocksmith 2014 Edition  Remastered  Amon Amarth - Twilight of the Thunder God - Rocksmith 2014 Edition - Remastered DLC (637770) Depot
addappid(637771, 1, "455718b27f19741ed1d396f2da6ca2f571e2e8c704bd2806b0406a784218ca35") -- Rocksmith 2014 Edition  Remastered  Amon Amarth - War of the Gods - Rocksmith 2014 Edition - Remastered DLC (637771) Depot
addappid(637773, 1, "ece944eb21bcfe85d2e553388f4edfcab0246e001998cdc1f2254e3a23ef3ea4") -- Rocksmith 2014 Edition  Remastered  NOFX - Linoleum - Rocksmith 2014 Edition - Remastered DLC (637773) Depot
addappid(637774, 1, "c455349df7290294c90784bd4cfc13e9d7789f09138a35d67dd051183a999883") -- Rocksmith 2014 Edition  Remastered  NOFX - Stickin in My Eye - Rocksmith 2014 Edition - Remastered DLC (637774) Depot
addappid(637775, 1, "41b717e03bd264cf7edd16d95584e5307c29474c873ad8812b98b936756b0f4a") -- Rocksmith 2014 Edition  Remastered  NOFX - Seeing Double at the Triple Rock - Rocksmith 2014 Edition - Remastered DLC (637775) Depot
addappid(637776, 1, "4a3f1b6f5c41de04a7056d99022bb908445993124d56779c9f9124a869f8dc17") -- Rocksmith 2014 Edition  Remastered  NOFX - Bob - Rocksmith 2014 Edition - Remastered DLC (637776) Depot
addappid(637778, 1, "a3208baff2b0d1f9396168769449a0a67677a2ff6b63c7aa5a225b441cdced47") -- Rocksmith 2014 Edition  Remastered  The Pretenders - Dont Get Me Wrong - Rocksmith 2014 Edition - Remastered DLC (637778) Depot
addappid(637779, 1, "20f2345426ad3403286708d6c5e9873d6f6bd48b727319a04c6533bb192d9959") -- Rocksmith 2014 Edition  Remastered  The Pretenders - Back on the Chain Gang - Rocksmith 2014 Edition - Remastered DLC (637779) Depot
addappid(637780, 1, "b17b4d3e35aa4544de796e0dd9fd4e7a7ac11b126b2c200ac5a828be4601d5ae") -- Rocksmith 2014 Edition  Remastered  The Pretenders - Brass in Pocket - Rocksmith 2014 Edition - Remastered DLC (637780) Depot
addappid(637781, 1, "44090f45e26f251c5524308cb5b7bcb46ef848e34b3570635b9e5cf190342fbc") -- Rocksmith 2014 Edition  Remastered  The Pretenders - Middle of the Road - Rocksmith 2014 Edition - Remastered DLC (637781) Depot
addappid(637782, 1, "e5d6e202b7d3025a651cec1aebd9cb6804cf7104884869840636f8bb52482881") -- Rocksmith 2014 Edition  Remastered  The Pretenders - Ill Stand by You - Rocksmith 2014 Edition - Remastered DLC (637782) Depot
addappid(637783, 1, "f3b6657340d4a14c2cd8aad10f5beff49edca3720811e045a1192909fdfabc7f") -- Rocksmith 2014 Edition  Remastered  Halestorm Song Pack - Rocksmith 2014 Edition - Remastered DLC (637783) Depot
addappid(637784, 1, "d7538a69d3d575866455293913d015fd52f7e310d5e4e50c306e78b3941492d6") -- Rocksmith 2014 Edition  Remastered  Halestorm - I Miss the Misery - Rocksmith 2014 Edition - Remastered DLC (637784) Depot
addappid(637785, 1, "e1ae869069f96937a0ccb26e1cc966c61270f765bf8baf546676d236eac0fa4b") -- Rocksmith 2014 Edition  Remastered  Halestorm - I Get Off - Rocksmith 2014 Edition - Remastered DLC (637785) Depot
addappid(637786, 1, "9e7e9eba6e5ee61b16ae3f14532a0daf1fcd2e0d478c2feed60ab439f1fa2096") -- Rocksmith 2014 Edition  Remastered  Halestorm - Mz. Hyde - Rocksmith 2014 Edition - Remastered DLC (637786) Depot
addappid(637788, 1, "929aeb293ad70a59f368882773985a86001dba568b798d17c8bb059831cc938e") -- Rocksmith 2014 Edition  Remastered  Trans-Siberian Orchestra - Christmas Eve  Sarajevo 1224 - Rocksmith 2014 Edition - Remastered DLC (637788) Depot
addappid(637789, 1, "cbb4c9737a389c8554c6e726b815081e593144d06b725e47b9232f311cb81b44") -- Rocksmith 2014 Edition  Remastered  Trans-Siberian Orchestra - Wizards in Winter - Rocksmith 2014 Edition - Remastered DLC (637789) Depot
addappid(637790, 1, "d6cbd400b0aa925db5c64eff5918ff9d167a35ed99ca90d5879cc2f86c091172") -- Rocksmith 2014 Edition  Remastered  Trans-Siberian Orchestra - O Come All Ye Faithful  O Holy Night - Rocksmith 2014 Edition - Remastered DLC (637790) Depot
addappid(637791, 1, "89d4e2caf8030ba7148e6751054a4b154ebf786061e2f4193129a591048ef482") -- Rocksmith 2014 Edition  Remastered  Trans-Siberian Orchestra - A Mad Russians Christmas - Rocksmith 2014 Edition - Remastered DLC (637791) Depot
addappid(637792, 1, "41e04c62d5207cd34e466c60cd87c3f443ed8d7fea7208fd20cc416d202bcc65") -- Rocksmith 2014 Edition  Remastered  Trans-Siberian Orchestra - Christmas Canon Rock - Rocksmith 2014 Edition - Remastered DLC (637792) Depot
addappid(637794, 1, "bb1c0d6ed453d0a4cd100667237cfe59c47d6cbf0724511bb001986cc57b514b") -- Rocksmith 2014 Edition  Remastered  Steve Miller Band - Jet Airliner - Rocksmith 2014 Edition - Remastered DLC (637794) Depot
addappid(637795, 1, "243f614958de02ef0849b431c76170829020bd9a8a00fc1e29453d0894719d2e") -- Rocksmith 2014 Edition  Remastered  Steve Miller Band - Rockn Me - Rocksmith 2014 Edition - Remastered DLC (637795) Depot
addappid(637796, 1, "c9434e391b67269d724f3cbfa8ebda7d68a759cc8b97219f399b92d683a615f5") -- Rocksmith 2014 Edition  Remastered  Steve Miller Band - Take the Money and Run - Rocksmith 2014 Edition - Remastered DLC (637796) Depot
addappid(637797, 1, "4bd422f5fd85c357c792a178cf730a22c1174be02e7600fac5281edd24713d79") -- Rocksmith 2014 Edition  Remastered  Steve Miller Band - The Joker - Rocksmith 2014 Edition - Remastered DLC (637797) Depot
addappid(637798, 1, "962de7ccc798fad3640cfd17c21dfcd1dcea717954c1ac503005e5d975c7c805") -- Rocksmith 2014 Edition  Remastered  Steve Miller Band - Fly Like an Eagle - Rocksmith 2014 Edition - Remastered DLC (637798) Depot
addappid(637800, 1, "34d6daff0c29e98afe35b7448f9a61f9a4e7558c4f47b10e9b72b031a174a44e") -- Rocksmith 2014 Edition  Remastered  Alice in Chains - Down in a Hole - Rocksmith 2014 Edition - Remastered DLC (637800) Depot
addappid(637801, 1, "13d90b76ff1b082fb7a6e7bf4c2f6d930b95585f60889a8c3fc86ee12b01db3d") -- Rocksmith 2014 Edition  Remastered  Alice in Chains - Heaven Beside You - Rocksmith 2014 Edition - Remastered DLC (637801) Depot
addappid(637802, 1, "74a671693b4f551757d4c97281bec79825d946679a76be9c35b423dbdab22b7b") -- Rocksmith 2014 Edition  Remastered  Alice in Chains - No Excuses - Rocksmith 2014 Edition - Remastered DLC (637802) Depot
addappid(637803, 1, "f7b25626ef1c9a5ab0cdb8d9289fed3f1219c91ed7e7efe3f025fdc22dff7573") -- Rocksmith 2014 Edition  Remastered  Alice in Chains - Nutshell - Rocksmith 2014 Edition - Remastered DLC (637803) Depot
addappid(637804, 1, "054532b92670a7bdae3c5f412caac5020144155fbcd5b479f86e4689f694e556") -- Rocksmith 2014 Edition  Remastered  Alice in Chains - Rooster - Rocksmith 2014 Edition - Remastered DLC (637804) Depot
addappid(637807, 1, "ed24d4f520fe43c90e0b4ce24c56cb7fed85dc067deda0ff1ce9c7464b21e445") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Folsom Prison Blues - Rocksmith 2014 Edition - Remastered DLC (637807) Depot
addappid(637808, 1, "95c5f995a41b9228d9af04fe5ca33649dfef471a09215da9ba701240d76ae1e4") -- Rocksmith 2014 Edition  Remastered  Johnny Cash  June Carter - Jackson - Rocksmith 2014 Edition - Remastered DLC (637808) Depot
addappid(637809, 1, "be4e9b6cdd5332d3ee39b0ebab01ec7b954cd3bdb31a94d1b08f8f9a3dd343cc") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Big River - Rocksmith 2014 Edition - Remastered DLC (637809) Depot
addappid(637810, 1, "fef256b1cd302c450c9d7fa08ef78b25a4ad67daa555ef700ea87d8676790b1e") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Hey Porter - Rocksmith 2014 Edition - Remastered DLC (637810) Depot
addappid(637811, 1, "e25dc3df5e4755d9e79a005320705ca727a5819b0325a78de52793dd4eb5ddf3") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Give My Love to Rose - Rocksmith 2014 Edition - Remastered DLC (637811) Depot
addappid(637813, 1, "7ae8c41386ef7c72c26c45b10f92784661908bb48ad9a518ad1ecbb1a487eae4") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - I Walk the Line - Rocksmith 2014 Edition - Remastered DLC (637813) Depot
addappid(637814, 1, "85662b75513a881caeb090f05f1ba987e4eef5e6db1b02b9e2fa50e1a94333e0") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Ring of Fire - Rocksmith 2014 Edition - Remastered DLC (637814) Depot
addappid(637815, 1, "66632aed8568e8b703339484bf595f853df909f05e9dd0ee99414ecc127d859c") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Sunday Mornin Comin Down - Rocksmith 2014 Edition - Remastered DLC (637815) Depot
addappid(637816, 1, "fce9632b2473562ae141bbd5789b837ad78ad7060a7b3895745111a3f8b666a0") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Get Rhythm - Rocksmith 2014 Edition - Remastered DLC (637816) Depot
addappid(637817, 1, "ea7f124734405163d0f4c08a1a4e3eb63311b3f82308d487d8673a7c72ce771c") -- Rocksmith 2014 Edition  Remastered  Johnny Cash - Cry Cry Cry - Rocksmith 2014 Edition - Remastered DLC (637817) Depot
addappid(637819, 1, "917d7c92446d32bb20cb342dc905cbf88e0ed0473a61941b088d9cf9d5808fc3") -- Rocksmith 2014 Edition  Remastered  Paramore - crushcrushcrush - Rocksmith 2014 Edition - Remastered DLC (637819) Depot
addappid(637820, 1, "abc106b9c3868ece8e9f4551c3663b54e5e488867bf6506ec5d436be15738539") -- Rocksmith 2014 Edition  Remastered  Paramore - Still Into You - Rocksmith 2014 Edition - Remastered DLC (637820) Depot
addappid(637821, 1, "697affe9eca03489422b4375b68f38b96ae7843ec0f249f6695374d9a78f6373") -- Rocksmith 2014 Edition  Remastered  Paramore - Brick by Boring Brick - Rocksmith 2014 Edition - Remastered DLC (637821) Depot
addappid(637822, 1, "b10288bea5624e7e5cb90938fa6aa179b7e959eec51a8ca32c0213bf376f094e") -- Rocksmith 2014 Edition  Remastered  Paramore - The Only Exception - Rocksmith 2014 Edition - Remastered DLC (637822) Depot
addappid(637823, 1, "b979dfd222221f1da54e1515d1809c58481cd2060e20280e85c67784c7fafcd7") -- Rocksmith 2014 Edition  Remastered  Paramore - Aint It Fun - Rocksmith 2014 Edition - Remastered DLC (637823) Depot
addappid(637824, 1, "61aeeb39cd15c67b1bd76e8f06a8184231e3166eb355e98f891afdb4ab4b1ebf") -- Rocksmith 2014 Edition  Remastered  Paramore - Pressure - Rocksmith 2014 Edition - Remastered DLC (637824) Depot
addappid(637826, 1, "701aa3139c24391bf7bbcf6011663f87d4c11e80e76fb6da6a7052e676bfc5ef") -- Rocksmith 2014 Edition  Remastered  Green Day - Boulevard of Broken Dreams - Rocksmith 2014 Edition - Remastered DLC (637826) Depot
addappid(637827, 1, "38c062c4751d33b0c454f8434235c87346dcf3bc845361b27510f8880101814d") -- Rocksmith 2014 Edition  Remastered  Green Day - Holiday - Rocksmith 2014 Edition - Remastered DLC (637827) Depot
addappid(637828, 1, "3e931c72841ca2bf1c63cdbed07d1e634424e5d0262a5701b7e9ae7e920bc904") -- Rocksmith 2014 Edition  Remastered  Green Day - Jesus of Suburbia - Rocksmith 2014 Edition - Remastered DLC (637828) Depot
addappid(637829, 1, "d2518d1ad3c3c5b1b8593e47b92f2c1c39fc827d4bcd4e8e4f91384fd63b3a74") -- Rocksmith 2014 Edition  Remastered  Green Day - Know Your Enemy - Rocksmith 2014 Edition - Remastered DLC (637829) Depot
addappid(637830, 1, "337a6933874b26b599926dd54c3f353977a98841414569be4b5ebdde96d98a2b") -- Rocksmith 2014 Edition  Remastered  Green Day - Welcome to Paradise - Rocksmith 2014 Edition - Remastered DLC (637830) Depot
addappid(637832, 1, "1075f7f93a572c42bc45b847c5c797de11140cf02e48a9367cd6c36f66759cc3") -- Rocksmith 2014 Edition  Remastered  Mumford  Sons - Little Lion Man - Rocksmith 2014 Edition - Remastered DLC (637832) Depot
addappid(637833, 1, "88669952ee4205346025c339de27df41ca68bb1ae616ca21bc6b4adeb5c02013") -- Rocksmith 2014 Edition  Remastered  Mumford  Sons - I Will Wait - Rocksmith 2014 Edition - Remastered DLC (637833) Depot
addappid(637834, 1, "6237fda2b42d1e60388cd87dc2a002c1a31494439976d8a4bd3dc478de3fe4c1") -- Rocksmith 2014 Edition  Remastered  Mumford  Sons - The Cave - Rocksmith 2014 Edition - Remastered DLC (637834) Depot
addappid(637836, 1, "c22cbd715b5432523a6ce6cc5154385ab53282a27209ad5b566eef7ed6edfa63") -- Rocksmith 2014 Edition  Remastered  Golden Earring - Radar Love - Rocksmith 2014 Edition - Remastered DLC (637836) Depot
addappid(637837, 1, "777bb221d58c9ccee34b57e356c0a66ed44c91cfdb94f8c951cdc10be92db772") -- Rocksmith 2014 Edition  Remastered  Jethro Tull - Aqualung - Rocksmith 2014 Edition - Remastered DLC (637837) Depot
addappid(637838, 1, "ccf2ffd6acf7df46b2ab5d75d2fba4b015a9d9fa929c76277dcda2c1bfa792fc") -- Rocksmith 2014 Edition  Remastered  Grand Funk Railroad - Were An American Band - Rocksmith 2014 Edition - Remastered DLC (637838) Depot
addappid(637840, 1, "ccfda549a0634f1eca4cc67548c147a633e128b78abf83771c3328021ae414a9") -- Rocksmith 2014 Edition  Remastered  Lady Gaga - Bad Romance - Rocksmith 2014 Edition - Remastered DLC (637840) Depot
addappid(637841, 1, "3a1e57a066909541ecfcad816c77bf05bf4c9c734bae28b245b0e13058d8fb48") -- Rocksmith 2014 Edition  Remastered  Lady Gaga - Yo and I - Rocksmith 2014 Edition - Remastered DLC (637841) Depot
addappid(637842, 1, "ec31c4309fb39304da94934990d003627040dea1f269a9ea77807869aec2e88f") -- Rocksmith 2014 Edition  Remastered  Lady Gaga - Poker Face - Rocksmith 2014 Edition - Remastered DLC (637842) Depot
addappid(637843, 1, "1872216f341d3f28a71a419eef5b3c872138fe94db64bbad156f42a155eba762") -- Rocksmith 2014 Edition  Remastered  Lady Gaga - Paparazzi - Rocksmith 2014 Edition - Remastered DLC (637843) Depot
addappid(637845, 1, "0831acfe641495634a5757cc2989b345fc30034583908901e1c0aacc49005b2b") -- Rocksmith 2014 Edition  Remastered  Trivium - Built to Fall - Rocksmith 2014 Edition - Remastered DLC (637845) Depot
addappid(637846, 1, "719344551c26960b1321180c498b1df0c5266d71c6cca57010ad703306ad213f") -- Rocksmith 2014 Edition  Remastered  Trivium - In Waves - Rocksmith 2014 Edition - Remastered DLC (637846) Depot
addappid(637847, 1, "5e69445542149a1cb9514f068f11185d89aacb89605464b31d6c99e552acd46b") -- Rocksmith 2014 Edition  Remastered  Trivium - Strife - Rocksmith 2014 Edition - Remastered DLC (637847) Depot
addappid(637849, 1, "a3405b33b1d845aba3ca3240cf010fc37629136db87dca8664cccc0af8165e3f") -- Rocksmith 2014 Edition  Remastered  Billy Joel - Only the Good Die Young - Rocksmith 2014 Edition - Remastered DLC (637849) Depot
addappid(753740, 1, "5545b4e2c1822e33ce2c8aadca04e976042b268dc75f1515ff9378949ee0fa72") -- Rocksmith 2014 Edition  Remastered  The Outlaws - Green Grass  High Tides - Rocksmith® 2014 Edition - Remastered - DLC (753740) Depot
addappid(753741, 1, "bf3eec78c458ca2103e5d0a53f850422be205d9c1da84b34cd9d5138ea4e61b1") -- Rocksmith 2014 Edition  Remastered  George Thorogood - Bad to the Bone - Rocksmith® 2014 Edition - Remastered - DLC (753741) Depot
addappid(753742, 1, "4d7573c159b823087229fb0bfd2dac6d1dbca3bfa43d29bd0d2723a8d608deac") -- Rocksmith 2014 Edition  Remastered  The Red Jumpsuit Apparatus - Face Down - Rocksmith® 2014 Edition - Remastered - DLC (753742) Depot
addappid(753743, 1, "1a261a7288d7027b289c30fd94d28f01e9fd6c2739e206a409f8b744e7cb22b2") -- Rocksmith 2014 Edition  Remastered  Soul Asylum - Runaway Train - Rocksmith® 2014 Edition - Remastered - DLC (753743) Depot
addappid(753745, 1, "037c17e1c697d59a088a38c075b0c52098603a4e63a688f36d4131e031855fbd") -- Rocksmith 2014 Edition  Remastered  Deep Purple - Hush - Rocksmith® 2014 Edition - Remastered - DLC (753745) Depot
addappid(753746, 1, "04e72383a412f01779f8614b9ff95a45d5e28a5ce54dfed6c2eaaed3ca834f88") -- Rocksmith 2014 Edition  Remastered  The Youngbloods - Get Together - Rocksmith® 2014 Edition - Remastered - DLC (753746) Depot
addappid(753747, 1, "310b3e6afc7da08bcc3b232d59c9aa3cd38b0213e6b9a299d9a14b3dbaa112b8") -- Rocksmith 2014 Edition  Remastered  Joe South - Games People Play - Rocksmith® 2014 Edition - Remastered - DLC (753747) Depot
addappid(753749, 1, "ee66b978a2e7351edef47a489c01c3a7b27d96dcbe50eab2811aad1c3e105a6c") -- Rocksmith 2014 Edition  Remastered  Shania Twain - Man I Feel Like a Woman - Rocksmith® 2014 Edition - Remastered - DLC (753749) Depot
addappid(753750, 1, "70f398d5211dbf77ed2e615d21ed2c5a9ecedd0be48e07b2501736b4cd48afc6") -- Rocksmith 2014 Edition  Remastered  Shania Twain - Youre Still the One - Rocksmith® 2014 Edition - Remastered - DLC (753750) Depot
addappid(753751, 1, "d8fda169a1edc4ae10073620759aa9c3bdc148ed199bae809ed48386d4c70add") -- Rocksmith 2014 Edition  Remastered  Shania Twain - That Dont Impress Me Much - Rocksmith® 2014 Edition - Remastered - DLC (753751) Depot
addappid(753753, 1, "fc146b9d3dc6b370f50ece3561b480edac9b806962fc3b768d69db2e4ab626a3") -- Rocksmith 2014 Edition  Remastered  Kaiser Chiefs - Ruby - Rocksmith® 2014 Edition - Remastered - DLC (753753) Depot
addappid(753754, 1, "4a1ddb8baed587a6e08c07b0326e536914a2bdc83786170457cc2e622e998652") -- Rocksmith 2014 Edition  Remastered  Kaiser Chiefs - I Predict a Riot - Rocksmith® 2014 Edition - Remastered - DLC (753754) Depot
addappid(753755, 1, "12b485eb47f9ec64d75321402af8ebf8afd23025e7120a3b1fba400980b7dee3") -- Rocksmith 2014 Edition  Remastered  Kaiser Chiefs - Never Miss a Beat - Rocksmith® 2014 Edition - Remastered - DLC (753755) Depot
addappid(753756, 1, "feec9eab851037b2449653647429396eb0fbc55f4bc290fff274d05ab96840b5") -- Rocksmith 2014 Edition  Remastered  2010s Mix Song Pack IV - Rocksmith® 2014 Edition - Remastered - DLC (753756) Depot
addappid(753757, 1, "877469874fb3c027ea8f22aa4b6e02ffd950fb25df4393a52fd657b0216e1da4") -- Rocksmith 2014 Edition  Remastered  Two Door Cinema Club - What You Know - Rocksmith® 2014 Edition - Remastered - DLC (753757) Depot
addappid(753758, 1, "9fd9f875e4fde09f1d54e970dbea74022df98bb5eec29051d74044a4a5118678") -- Rocksmith 2014 Edition  Remastered  Bastille - Pompeii - Rocksmith® 2014 Edition - Remastered - DLC (753758) Depot
addappid(753759, 1, "f011fb75c12fd045f3871d0bdf71c00ce918c0dc3188ee8fc1b0ba963c93d40d") -- Rocksmith 2014 Edition  Remastered  James Bay - Hold Back the River - Rocksmith® 2014 Edition - Remastered - DLC (753759) Depot
addappid(753761, 1, "f33f729691df4185677f80a8e48b992ecfa0b3cd013147528a88f1bd1eb217c4") -- Rocksmith 2014 Edition  Remastered  The Cardigans - Lovefool - Rocksmith® 2014 Edition - Remastered - DLC (753761) Depot
addappid(753762, 1, "f1023d172c0a27f95e33407a8d888422cd583c0b0f2615920f5b27d792ceb361") -- Rocksmith 2014 Edition  Remastered  The Cardigans - My Favourite Game - Rocksmith® 2014 Edition - Remastered - DLC (753762) Depot
addappid(753763, 1, "b621200081b7a52cc0b6cca4880f8fe1b3dd85415bf2064ff70656f26241fc4a") -- Rocksmith 2014 Edition  Remastered  The Cardigans - EraseRewind - Rocksmith® 2014 Edition - Remastered - DLC (753763) Depot
addappid(753765, 1, "4b56944776146bd195d7b24b94532ea8ca4a07c9d60adc19575247386b1a5ce0") -- Rocksmith 2014 Edition  Remastered  Dethklok - Murmaider - Rocksmith® 2014 Edition - Remastered - DLC (753765) Depot
addappid(753766, 1, "f91abbe330841e6d3ab142c7bc9f1d359770d5b31ca890315e9f0c9c875aa13f") -- Rocksmith 2014 Edition  Remastered  Dethklok - Black Fire Upon Us - Rocksmith® 2014 Edition - Remastered - DLC (753766) Depot
addappid(753767, 1, "553c783270e23636d9fc061ed97134c285215a9d0e778f20ef0d018c0a74749a") -- Rocksmith 2014 Edition  Remastered  Dethklok - Bloodlines - Rocksmith® 2014 Edition - Remastered - DLC (753767) Depot
addappid(753768, 1, "7c03f447aefb9755381381ab964ad8f8c52b46cd8762f6ed57ca55f4527f5582") -- Rocksmith 2014 Edition  Remastered  Variety Song Pack XIV - Rocksmith® 2014 Edition - Remastered - DLC (753768) Depot
addappid(753769, 1, "fe0018cf26c3a52e23a6286bb9dd236866b838b135f05966833c121ada654e89") -- Rocksmith 2014 Edition  Remastered  The Outfield - Your Love - Rocksmith® 2014 Edition - Remastered - DLC (753769) Depot
addappid(753770, 1, "59972ccbab2f5ac7eeb4e059ee543af2b6b3af2f343e753f1e407b12263262b8") -- Rocksmith 2014 Edition  Remastered  Temple of the Dog - Hunger Strike - Rocksmith® 2014 Edition - Remastered - DLC (753770) Depot
addappid(753771, 1, "69093938af57b17f06021915d25cbcffccf4aa8b2ef514755883a4383c3f136b") -- Rocksmith 2014 Edition  Remastered  Panic at the Disco - I Write Sins Not Tragedies - Rocksmith® 2014 Edition - Remastered - DLC (753771) Depot
addappid(753772, 1, "fbfb6c03fd50ac31b249eea1d8c49066d4b32521dccf875de95ef100937db522") -- Rocksmith 2014 Edition  Remastered  Pure Prairie League - Amie - Rocksmith® 2014 Edition - Remastered - DLC (753772) Depot
addappid(753774, 1, "75ae1ba35db2275998f526843a77e11aec69d5134703a30d2c719dd23d0d4485") -- Rocksmith 2014 Edition  Remastered  Stereophonics - Dakota - Rocksmith® 2014 Edition - Remastered - DLC (753774) Depot
addappid(753775, 1, "15d35276c88e0e04b4ec997889c930e05845657faf6def293356f1d4580bae24") -- Rocksmith 2014 Edition  Remastered  Stereophonics - Maybe Tomorrow - Rocksmith® 2014 Edition - Remastered - DLC (753775) Depot
addappid(753776, 1, "04414baed1d9f03644b37a390654490dbce5d77745fd3bc112a7a15aaf92af95") -- Rocksmith 2014 Edition  Remastered  Stereophonics - The Bartender and the Thief - Rocksmith® 2014 Edition - Remastered - DLC (753776) Depot
addappid(753778, 1, "d469675f4c07874e00567fc504feea127de0eea89c7be4f7408ec6a58de75640") -- Rocksmith 2014 Edition  Remastered  Godsmack - Keep Away - Rocksmith® 2014 Edition - Remastered - DLC (753778) Depot
addappid(753779, 1, "dd13dffb1fcd2ab2ea84cc19295a2a1ed2f5972d1b25e765ea1e76b74174efc8") -- Rocksmith 2014 Edition  Remastered  New Radicals - You Get What You Give - Rocksmith® 2014 Edition - Remastered - DLC (753779) Depot
addappid(753780, 1, "0d0b09321f3c2e4d0b5c9c27d412b0f8c058e8250d7c3a2e38552f875d91cf5f") -- Rocksmith 2014 Edition  Remastered  Veruca Salt - Volcano Girls - Rocksmith® 2014 Edition - Remastered - DLC (753780) Depot
addappid(753782, 1, "34c517bdd65aa1320ed884547f6cbd9d2af688d196456232070fd8a61b929458") -- Rocksmith 2014 Edition  Remastered  KT Tunstall - Black Horse and the Cherry Tree - Rocksmith® 2014 Edition - Remastered - DLC (753782) Depot
addappid(753783, 1, "7af5d5bf82e61cc27fbea9403de9236b96c1a92b4e0acf0e5fd8e674b5d7926f") -- Rocksmith 2014 Edition  Remastered  KT Tunstall - Suddenly I See - Rocksmith® 2014 Edition - Remastered - DLC (753783) Depot
addappid(753784, 1, "ee9e5b52fcfd4b437a380c477e8e5103dc9742668ebb1646daccd44d59d123e8") -- Rocksmith 2014 Edition  Remastered  KT Tunstall - Other Side of the World - Rocksmith® 2014 Edition - Remastered - DLC (753784) Depot
addappid(753786, 1, "9bdee8be635924689b05586a2a2513f41b54026ab479f1eaa8a4252d0bcce48f") -- Rocksmith 2014 Edition  Remastered  Billy Squier - Lonely is the Night - Rocksmith® 2014 Edition - Remastered - DLC (753786) Depot
addappid(753787, 1, "6072e97f2ba2866c78db1fdd4dd7f2366e45390d314699690c20cddb208c94a0") -- Rocksmith 2014 Edition  Remastered  Earth, Wind  Fire - Lets Groove - Rocksmith® 2014 Edition - Remastered - DLC (753787) Depot
addappid(753788, 1, "27975e77fd208919bebb0f7947ee3068c0083cdd9b0aa4f2c341d3abfbf9d25f") -- Rocksmith 2014 Edition  Remastered  Styx - Too Much Time on My Hands - Rocksmith® 2014 Edition - Remastered - DLC (753788) Depot
addappid(753790, 1, "d22c5eb01559598b4ea0b1467a468ca8a70a8550de04d16c27cee529cb4f1eb5") -- Rocksmith 2014 Edition  Remastered  Interpol - All The Rage Back Home - Rocksmith® 2014 Edition - Remastered - DLC (753790) Depot
addappid(753791, 1, "917ac8b39a35052aead63f113b2d8502b04fb189392a43248f8cb997024b4b17") -- Rocksmith 2014 Edition  Remastered  Interpol - Evil - Rocksmith® 2014 Edition - Remastered - DLC (753791) Depot
addappid(753792, 1, "80354f27c955096d5db614973adabcf22ad023436730432aa68ef28099f0f408") -- Rocksmith 2014 Edition  Remastered  Interpol - Obstacle 1 - Rocksmith® 2014 Edition - Remastered - DLC (753792) Depot
addappid(753793, 1, "e3596068eaf92a918efefad293459ca39e0b9f92d01c9fb74872cd072f0affec") -- Rocksmith 2014 Edition  Remastered  Interpol - PDA - Rocksmith® 2014 Edition - Remastered - DLC (753793) Depot
addappid(753795, 1, "a2a8e576cf989043bcec183c941efd651ebca4bb41799e57cca6e445cda33a5b") -- Rocksmith 2014 Edition  Remastered  Testament - Souls of Black - Rocksmith® 2014 Edition - Remastered - DLC (753795) Depot
addappid(753796, 1, "71100b4a17099f08f272fc03de23a6f5c008a18a0cac076458bbcfe64ade2513") -- Rocksmith 2014 Edition  Remastered  Morbid Angel - Immortal Rites - Rocksmith® 2014 Edition - Remastered - DLC (753796) Depot
addappid(753797, 1, "3adb2c51e2f03b1c87af28d92a71c438da2220d642f1a61875c62e940d8ef66c") -- Rocksmith 2014 Edition  Remastered  Darkthrone - Transilvanian Hunger - Rocksmith® 2014 Edition - Remastered - DLC (753797) Depot
addappid(753799, 1, "6f111935c45a8f39142e7021543f1d863ddb83d0787c7057f7d2a296fa422fd1") -- Rocksmith 2014 Edition  Remastered  Norah Jones - Dont Know Why - Rocksmith® 2014 Edition - Remastered - DLC (753799) Depot
addappid(753800, 1, "612618715349fd4f4177812829f9f0a31f37ee9f9fbc05d923021607282a6567") -- Rocksmith 2014 Edition  Remastered  Norah Jones - Sunrise - Rocksmith® 2014 Edition - Remastered - DLC (753800) Depot
addappid(753801, 1, "2fc02b22edfb525d159e8e51b493dd4ac127fd6c7f65affac1105815f74688fa") -- Rocksmith 2014 Edition  Remastered  Norah Jones - Come Away with Me - Rocksmith® 2014 Edition - Remastered - DLC (753801) Depot
addappid(753803, 1, "d5ddf845368d74e9a0aecd2769bc61ff799e92d90120f90895f55e7a2961e3e0") -- Rocksmith 2014 Edition  Remastered  Badfinger - Baby Blue - Rocksmith® 2014 Edition - Remastered - DLC (753803) Depot
addappid(753804, 1, "6edb22903075c8bdb98c6a4791bc760082e81c2d3727d5a58e06a6e0ed1c6b97") -- Rocksmith 2014 Edition  Remastered  Spacehog - In The Meantime - Rocksmith® 2014 Edition - Remastered - DLC (753804) Depot
addappid(753805, 1, "75b0baa24c6668150c486e36a0dd1fc153dcdb79484f04cd077b4558aa1ee3eb") -- Rocksmith 2014 Edition  Remastered  The Shadows - Apache - Rocksmith® 2014 Edition - Remastered - DLC (753805) Depot
addappid(753806, 1, "297fa980ff80ce72d2382e73e5d908920a351e5ba7ad59b64cc9ea7f43883182") -- Rocksmith 2014 Edition  Remastered  U2 - Bad - Rocksmith® 2014 Edition - Remastered - DLC (753806) Depot
addappid(753808, 1, "eb7347ef7e9da1c24ef46ed816edea45d721dda970cb8588c7e32b3de6bafd86") -- Rocksmith 2014 Edition  Remastered  Modest Mouse - Dashboard - Rocksmith® 2014 Edition - Remastered - DLC (753808) Depot
addappid(753809, 1, "cf4073e88fd8af36c99d714bf558921173f67bdefa44c7fb16791a02ed52a0a8") -- Rocksmith 2014 Edition  Remastered  Theory of a Deadman - Bad Girlfriend - Rocksmith® 2014 Edition - Remastered - DLC (753809) Depot
addappid(753810, 1, "863b6e752150f21bfdc31e4dad2c8db44fe586bd8c079f5494b26bbe5f8f54c2") -- Rocksmith 2014 Edition  Remastered  Dropkick Murphys - Johnny, I Hardly Knew Ya - Rocksmith® 2014 Edition - Remastered - DLC (753810) Depot
addappid(753812, 1, "eb944da9d35cb4d83d3c9c49c9c0ee48e967b20d6ef5c2d1e271e3590c98deed") -- Rocksmith 2014 Edition  Remastered  Radiohead - There There - Rocksmith® 2014 Edition - Remastered - DLC (753812) Depot
addappid(753813, 1, "c92a303b5bdd4b2a3293cd8851f0da4de939b4235ffd0c5edee7f0cbfa94730f") -- Rocksmith 2014 Edition  Remastered  Radiohead - Street Spirit (Fade Out) - Rocksmith® 2014 Edition - Remastered - DLC (753813) Depot
addappid(753814, 1, "e3adc6e7625a4a7362ce10b67cdd3783a576e715e721c49ddfecf56a816c557d") -- Rocksmith 2014 Edition  Remastered  Radiohead - No Surprises - Rocksmith® 2014 Edition - Remastered - DLC (753814) Depot
addappid(753816, 1, "2dc0168f1a37c5e732de7bab4e3c980d5ec8d707948ceecf3d22ccbc252edce3") -- Rocksmith 2014 Edition  Remastered  Joan Jett - Bad Reputation - Rocksmith® 2014 Edition - Remastered - DLC (753816) Depot
addappid(753817, 1, "2480d645df1ddb74be2685d67afe148adef5584630769fc68c8a43d4215adad1") -- Rocksmith 2014 Edition  Remastered  Joan Jett  the Blackhearts - Crimson  Clover - Rocksmith® 2014 Edition - Remastered - DLC (753817) Depot
addappid(753818, 1, "55684f09cae327de0514e9d8c2af13ce69709eb60ff3203f42fda21977a04b75") -- Rocksmith 2014 Edition  Remastered  Joan Jett  the Blackhearts -  I Hate Myself For Loving You - Rocksmith® 2014 Edition - Remastered - DLC (753818) Depot
addappid(753820, 1, "caab9103942dc5d53c9582d284de055581dee511c1a09275bd0ad8e86ba10693") -- Rocksmith 2014 Edition  Remastered  George Thorogood - Who Do You Love - Rocksmith® 2014 Edition - Remastered - DLC (753820) Depot
addappid(753821, 1, "369118ea66652672105a174b8a7978e1a79c008e81c0defe58754209c95dc6a3") -- Rocksmith 2014 Edition  Remastered  Steve Miller Band - Jungle Love - Rocksmith® 2014 Edition - Remastered - DLC (753821) Depot
addappid(753822, 1, "2e201398111f55daf4ee934205ca66b436f2255004beb18048feef025be79465") -- Rocksmith 2014 Edition  Remastered  Buzzcocks - Ever Fallen in Love (With Someone You Shouldntve) - Rocksmith® 2014 Edition - Remastered - DLC (753822) Depot
addappid(753824, 1, "c12bbbf29cc020f7f64c35916f25c6c6474e7b34accb749f3f3631b2ddd248d3") -- Rocksmith 2014 Edition  Remastered  Run-D.M.C. - King of Rock - Rocksmith® 2014 Edition - Remastered - DLC (753824) Depot
addappid(753825, 1, "163c1e991ea9a939974aa467f741685326644dea70aeee24b97a2b14db996915") -- Rocksmith 2014 Edition  Remastered  Run-D.M.C. - Its Tricky - Rocksmith® 2014 Edition - Remastered - DLC (753825) Depot
addappid(753826, 1, "fe52243f8ea31ae350c65c6682242760bacf21a277a689b25274a5029abb7acb") -- Rocksmith 2014 Edition  Remastered  Run-D.M.C. - Rock Box - Rocksmith® 2014 Edition - Remastered - DLC (753826) Depot
addappid(753828, 1, "a6f56a14a00062880c10186cea397bf7c67d554002278913cab26d03d4325711") -- Rocksmith 2014 Edition  Remastered  Duane Eddy - Rebel Rouser - Rocksmith® 2014 Edition - Remastered - DLC (753828) Depot
addappid(753829, 1, "c7e4cf5e45d779d1622567561554f0ca162b21a375edfb1c0dab17dded7e8f3b") -- Rocksmith 2014 Edition  Remastered  Pantera - This Love - Rocksmith® 2014 Edition - Remastered - DLC (753829) Depot
addappid(753830, 1, "19d0ad590332df1942f0a010128e66a01c97148f0fc670e4487478b4a7a297a9") -- Rocksmith 2014 Edition  Remastered  The Proclaimers - Im Gonna Be (500 Miles) - Rocksmith® 2014 Edition - Remastered - DLC (753830) Depot
addappid(753831, 1, "58e94b3fa6d4e0c563f0f47985de967ad109978fd21e0ac114785cf3b61d4ad2") -- Rocksmith 2014 Edition  Remastered  Nina Simone - Feeling Good - Rocksmith® 2014 Edition - Remastered - DLC (753831) Depot
addappid(753833, 1, "e90e798f023a41e36dd298a4139939804c1d4579f6ecc2a182d5ef653b71f4b2") -- Rocksmith 2014 Edition  Remastered  Joni Mitchell - Big Yellow Taxi - Rocksmith® 2014 Edition - Remastered - DLC (753833) Depot
addappid(753834, 1, "74485565fa991d97cbc5a6ab391c732cd40642179ac1e596a0cd30d3d60690f1") -- Rocksmith 2014 Edition  Remastered  Joni Mitchell - Both Sides, Now - Rocksmith® 2014 Edition - Remastered - DLC (753834) Depot
addappid(753835, 1, "99ed002eb8e8b6eb52bd805f9741480fea5919a48e6c76ff178fe6855c1994c1") -- Rocksmith 2014 Edition  Remastered  Joni Mitchell - A Case of You - Rocksmith® 2014 Edition - Remastered - DLC (753835) Depot
addappid(753836, 1, "3c53bfdf55987dbf93ba9899cee41a5b2d5e5d7e4fab035f67fd7f374c83a005") -- Rocksmith 2014 Edition  Remastered  Ubisoft Music Song Pack - Rocksmith® 2014 Edition - Remastered - DLC (753836) Depot
addappid(753843, 1, "4c3715ca3cbee8ae5f4fb7f5624b3e0cce592a9db8a0c364682efdf9d6f8458f") -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet - Highway Tune - Rocksmith® 2014 Edition - Remastered - DLC (753843) Depot
addappid(753844, 1, "f8fc66be74d6c4c3d5d4428f0ee42fe1fd6d70389e975ac63eff5675e1fb3322") -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet - Black Smoke Rising - Rocksmith® 2014 Edition - Remastered - DLC (753844) Depot
addappid(753845, 1, "aa3b7a90384fb661389bb887ae5e4226cc686cf1a0d0584f5db0b35be31627ec") -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet - Safari Song - Rocksmith® 2014 Edition - Remastered - DLC (753845) Depot
addappid(753847, 1, "8e991423ce733cb113902b357116fd38ca89537c1b2e7f9aeb4429efe1fcb0c5") -- Rocksmith 2014 Edition  Remastered  Willie Dixon - Back Door Man - Rocksmith® 2014 Edition - Remastered - DLC (753847) Depot
addappid(753848, 1, "4f059b773e042c6505540d439591f52c22e61396bb0608a1c1b08cfd89f36f56") -- Rocksmith 2014 Edition  Remastered  John Lee Hooker - One Bourbon, One Scotch, One Beer - Rocksmith® 2014 Edition - Remastered - DLC (753848) Depot
addappid(753849, 1, "07c0f0db55017aba0fc92e89b4474221370851ac92c0ac34ae5500693c741f72") -- Rocksmith 2014 Edition  Remastered  Wes Montgomery - West Coast Blues - Rocksmith® 2014 Edition - Remastered - DLC (753849) Depot
addappid(753851, 1, "c4ff72b67abdc65e9fd04cabb77eb375caca8d222dc392992f732ea1adc7da76") -- Rocksmith 2014 Edition  Remastered  Silverstein - My Heroine - Rocksmith® 2014 Edition - Remastered - DLC (753851) Depot
addappid(753852, 1, "34dca82ace01e3e0ff8f1d6d00f2cb245b477200e3830caba1602bbb3380b592") -- Rocksmith 2014 Edition  Remastered  Silverstein - Smile in Your Sleep - Rocksmith® 2014 Edition - Remastered - DLC (753852) Depot
addappid(753853, 1, "d514706cc7404528f58f1b1213e1a73d30fc7f16c8d62cbc2ed6052f113c8aa2") -- Rocksmith 2014 Edition  Remastered  Silverstein - Bleeds No More - Rocksmith® 2014 Edition - Remastered - DLC (753853) Depot
addappid(753854, 1, "43f79bf1911e0a72c369959a7c3eb54abbd414045b9a943817157418073b05a5") -- Rocksmith 2014 Edition  Remastered  Silverstein - Smashed into Pieces - Rocksmith® 2014 Edition - Remastered - DLC (753854) Depot
addappid(753856, 1, "82f0d2b9252aaacc657775c917688b687e184cd90efbbbde1017e10ce14972f6") -- Rocksmith 2014 Edition  Remastered  Alien Ant Farm - Movies - Rocksmith® 2014 Edition - Remastered - DLC (753856) Depot
addappid(753857, 1, "d561a1c988a2e88387b77f2e41418ecfea298006787a312841a8e0c4379c035b") -- Rocksmith 2014 Edition  Remastered  David Bowie - Changes - Rocksmith® 2014 Edition - Remastered - DLC (753857) Depot
addappid(753858, 1, "a53660b442675c9e93fb7f4196eaaf224af3c9613234d7d61652052e949680ca") -- Rocksmith 2014 Edition  Remastered  Grateful Dead - Touch of Grey - Rocksmith® 2014 Edition - Remastered - DLC (753858) Depot
addappid(753859, 1, "a6cf4a381e96ef0f656fece47180f6f60c2174460eecec6e1f15a7e2920b6524") -- Rocksmith 2014 Edition  Remastered  Lisa Loeb - Stay (I Missed You) - Rocksmith® 2014 Edition - Remastered - DLC (753859) Depot
addappid(753861, 1, "00f5eeb0945b215b1f96e47552bba20f0c1eaf7437247874725e4099afea0f83") -- Rocksmith 2014 Edition  Remastered  Kelly Clarkson - Since U Been Gone - Rocksmith® 2014 Edition - Remastered - DLC (753861) Depot
addappid(753862, 1, "904f45a9331f216f5853286e8cd6dea0e61ad3aa1ef31a34e9ef1665054c3992") -- Rocksmith 2014 Edition  Remastered  Kelly Clarkson - Behind These Hazel Eyes - Rocksmith® 2014 Edition - Remastered - DLC (753862) Depot
addappid(753863, 1, "2deb507e724ef86800041b29da4d34189caf40f513039b9728766b2f93686170") -- Rocksmith 2014 Edition  Remastered  Kelly Clarkson - My Life Would Suck Without You - Rocksmith® 2014 Edition - Remastered - DLC (753863) Depot
addappid(753865, 1, "d09b285d404cfbf2f4c1916db9f6006a3405c435aac2c98df66f1411dcab39a4") -- Rocksmith 2014 Edition  Remastered  Type O Negative - Christian Woman - Rocksmith® 2014 Edition - Remastered - DLC (753865) Depot
addappid(753866, 1, "1a1b0b4ed49aadcaf4e38741dd273f3892a1e576b40df9296ba712c9850ea27a") -- Rocksmith 2014 Edition  Remastered  Joe Satriani - Summer Song - Rocksmith® 2014 Edition - Remastered - DLC (753866) Depot
addappid(753867, 1, "12230ee07462df1857c96239fb1035ca361678ae53edad30c2ce700813200a37") -- Rocksmith 2014 Edition  Remastered  Helmet - Unsung - Rocksmith® 2014 Edition - Remastered - DLC (753867) Depot
addappid(753869, 1, "ef4eae8eaea62dd99bdb13d9438e3d578f05bd25439664d0ae758621fc2d98f2") -- Rocksmith 2014 Edition  Remastered  Stone Sour - Absolute Zero - Rocksmith® 2014 Edition - Remastered - DLC (753869) Depot
addappid(753870, 1, "0ad8876f6fee32cfdf796e37b8777486daf19fb1475ad9d145689cfe5caf1bd0") -- Rocksmith 2014 Edition  Remastered  Stone Sour - Bother - Rocksmith® 2014 Edition - Remastered - DLC (753870) Depot
addappid(753871, 1, "800953dae35dc5290accfd48a831b775b7d2afe6c0c86eb0fac6fedecaeeeaf7") -- Rocksmith 2014 Edition  Remastered  Stone Sour - Say Youll Haunt Me - Rocksmith® 2014 Edition - Remastered - DLC (753871) Depot
addappid(753873, 1, "c3fdfefcc10d888adf3b238e3448b567ceede2f377b533c21949f7c84f672adb") -- Rocksmith 2014 Edition  Remastered  Coldplay - Paradise - Rocksmith® 2014 Edition - Remastered - DLC (753873) Depot
addappid(753874, 1, "a8936036ae68fc5e2ab544b05dd5cbe7ad2b921079836af9886290f969408f96") -- Rocksmith 2014 Edition  Remastered  Elle King - Exs  Ohs - Rocksmith® 2014 Edition - Remastered - DLC (753874) Depot
addappid(753875, 1, "f0bfeac1550676f1b8013b5d3edb5a747517345573c9a5de7805b2d8e6665120") -- Rocksmith 2014 Edition  Remastered  The War on Drugs - Red Eyes - Rocksmith® 2014 Edition - Remastered - DLC (753875) Depot
addappid(753877, 1, "f65ac775a548383b19e67729985555c2e9c1980c4085846735c5d2ed510ad998") -- Rocksmith 2014 Edition  Remastered  Joy Division - Disorder - Rocksmith® 2014 Edition - Remastered - DLC (753877) Depot
addappid(753878, 1, "da7d2b270d6715379771641fb239ceac339990387e61fe6f12946e4b483a4484") -- Rocksmith 2014 Edition  Remastered  Joy Division - Love Will Tear Us Apart - Rocksmith® 2014 Edition - Remastered - DLC (753878) Depot
addappid(753879, 1, "0a669048c98250f08fbae0f70181a0e35f3468f583480ce1cd8bd0a563da0270") -- Rocksmith 2014 Edition  Remastered  Joy Division - Transmission - Rocksmith® 2014 Edition - Remastered - DLC (753879) Depot
addappid(753881, 1, "a33d10203c8967dae509a5e7df62d1ea25cf54b890c85bf8722a15e801003a0c") -- Rocksmith 2014 Edition  Remastered  Beastie Boys - Gratitude - Rocksmith® 2014 Edition - Remastered - DLC (753881) Depot
addappid(753882, 1, "9b5107856148f0768f2f31cac2358ab87e7178bca3fb5e40901a849dbe6865e9") -- Rocksmith 2014 Edition  Remastered  blink-182 - Stay Together for the Kids - Rocksmith® 2014 Edition - Remastered - DLC (753882) Depot
addappid(753883, 1, "ab9dfb1c20e0408ef19186537ed61022a203937a54339140282da9bc5e8295fa") -- Rocksmith 2014 Edition  Remastered  The Beach Boys - Surfin Safari - Rocksmith® 2014 Edition - Remastered - DLC (753883) Depot
addappid(753885, 1, "a30539da49d7405699790d4b56bfcfeb505678f276a296c9f1d4ff51ea62d3d9") -- Rocksmith 2014 Edition  Remastered  Brad Paisley - Mud on the Tires - Rocksmith® 2014 Edition - Remastered - DLC (753885) Depot
addappid(753886, 1, "93281788d0dedb3f7feccdd3f7187867cabc110274a08d450e2e61501dd5199a") -- Rocksmith 2014 Edition  Remastered  Brad Paisley - Ticks - Rocksmith® 2014 Edition - Remastered - DLC (753886) Depot
addappid(753887, 1, "68c701038a15dcf65cb7032434f3698aa0353063f26313d65bb219071c9647b2") -- Rocksmith 2014 Edition  Remastered  Brad Paisley  ft. Alison Krauss- Whiskey Lullaby - Rocksmith® 2014 Edition - Remastered - DLC (753887) Depot
addappid(753889, 1, "32d5b1c553acb5365e0115b3c5b19c4e419c091f9564cf25513ed27e1429f8a9") -- Rocksmith 2014 Edition  Remastered  Poison - Fallen Angel - Rocksmith® 2014 Edition - Remastered - DLC (753889) Depot
addappid(753890, 1, "3ab1eb89e344f7da3ff84bcc33687325e6c14dac9b38673cd85afb11348c4ba4") -- Rocksmith 2014 Edition  Remastered  a-ha - Take On Me - Rocksmith® 2014 Edition - Remastered - DLC (753890) Depot
addappid(753891, 1, "dfbb169b2236b9d53e3be8bad47b666d6247c941505792091a3f1ae192567052") -- Rocksmith 2014 Edition  Remastered  Georgia Satellites - Keep Your Hands to Yourself - Rocksmith® 2014 Edition - Remastered - DLC (753891) Depot
addappid(753893, 1, "00d098614f1cd8e85b4ba8c623aec25f4e165ba0a9b0fd04c80836e07e427578") -- Rocksmith 2014 Edition  Remastered  Ghost B.C. - Year Zero - Rocksmith® 2014 Edition - Remastered - DLC (753893) Depot
addappid(753894, 1, "d5e40c7f2b78ca5190d301922273de2c8040c2dd1e36ca3ef69ae124b1cf53f8") -- Rocksmith 2014 Edition  Remastered  Ghost - Cirice - Rocksmith® 2014 Edition - Remastered - DLC (753894) Depot
addappid(753895, 1, "fc5797574f4e729be23461a133c7865d6e8a40d59a6e6e8ac3d5a3757756401f") -- Rocksmith 2014 Edition  Remastered  Ghost - Ritual - Rocksmith® 2014 Edition - Remastered - DLC (753895) Depot
addappid(753896, 1, "9f68c46a7e12005b4257f1e0b1d8e64502a566c4f3145e0a6b811f1339427739") -- Rocksmith 2014 Edition  Remastered  Ghost - He Is - Rocksmith® 2014 Edition - Remastered - DLC (753896) Depot
addappid(899782, 1, "74975394a7ba835cff76fbf57745f07e3439451dc3f9e386bcf527378a6b3667") -- Rocksmith 2014 Edition  Remastered  Queen - Tie Your Mother Down - Rocksmith® 2014 Edition - Remastered (899782) Depot
addappid(899783, 1, "6fa9a63f1341d97f4025ca1be648bb7be21f9f81bde87ff6ff02971d6b46241c") -- Rocksmith 2014 Edition  Remastered  Queen - We Will Rock You - Rocksmith® 2014 Edition - Remastered (899783) Depot
addappid(899784, 1, "2b5364128fe7a7bba7f30fb2dc8ac1aa92b76f13534da6ffa037ab6883667255") -- Rocksmith 2014 Edition  Remastered  Queen - Dont Stop Me Now - Rocksmith® 2014 Edition - Remastered (899784) Depot
addappid(899785, 1, "baba0a023a6f4b40a1e96d86ed0e503059b71f030673432abe15f90b206fbffe") -- Rocksmith 2014 Edition  Remastered  Queen - Love of My Life - Rocksmith® 2014 Edition - Remastered (899785) Depot
addappid(899787, 1, "f49803f06dcd3a97064d927b187ba2cd161eed21ffc31ee8c40d29159ec71d1f") -- Rocksmith 2014 Edition  Remastered  Big Country - In A Big Country - Rocksmith® 2014 Edition - Remastered (899787) Depot
addappid(899790, 1, "9ad38a7ba4b7aca28075bad0fa3048b3c123cfc6dc823484442c9b2d7059e461") -- Rocksmith 2014 Edition  Remastered  The Meters - Cissy Strut - Rocksmith® 2014 Edition - Remastered (899790) Depot
addappid(899792, 1, "be0354414853d47ed077382cbd0f6659ce40ddd3a02f9d341ea4ad7bb36a22d5") -- Rocksmith 2014 Edition  Remastered  Elvis Presley - Blue Christmas - Rocksmith® 2014 Edition - Remastered (899792) Depot
addappid(899793, 1, "24857469513e6eb69b7a6b88dd5c3cc43cca7c88859ee11d931912f726fdccd1") -- Rocksmith 2014 Edition  Remastered  Chuck Berry - Run, Rudolph, Run - Rocksmith® 2014 Edition - Remastered (899793) Depot
addappid(899794, 1, "feaaa426a04d1cb905be623ef6fb101ffcf54a59f9ad86777bb9d1c0c4e03f07") -- Rocksmith 2014 Edition  Remastered  Brenda Lee - Rockin Around the Christmas Tree - Rocksmith® 2014 Edition - Remastered (899794) Depot
addappid(899795, 1, "6b7779eeca60fbc533aef760cb9c5ac2c0e7d55befdf173f73930b24eebc56de") -- Rocksmith 2014 Edition  Remastered  Gene Autry - Rudolph the Red-Nosed Reindeer - Rocksmith® 2014 Edition - Remastered (899795) Depot
addappid(899797, 1, "b76380056093f70d5d5bbc68f968ab0c7827a88422193c1d2173f3ed501f0b30") -- Rocksmith 2014 Edition  Remastered  Jimmy Eat World - Bleed American - Rocksmith® 2014 Edition - Remastered (899797) Depot
addappid(899798, 1, "9c9dfe5bd5d08e1179f163fe76f93ed6ebc0d982ff44886701ed3373de592d6c") -- Rocksmith 2014 Edition  Remastered  Jimmy Eat World - The Middle - Rocksmith® 2014 Edition - Remastered (899798) Depot
addappid(899799, 1, "a35bd9e5d415b74389695a35302aa5566ee7a27c87e5f5a79c5619268332b1fb") -- Rocksmith 2014 Edition  Remastered  Jimmy Eat World - Sweetness - Rocksmith® 2014 Edition - Remastered (899799) Depot
addappid(899801, 1, "2c75d66bc4b045d73b59d340e6325cfa83d337b5b18eeb98fbc8bac9f20e7f43") -- Rocksmith 2014 Edition  Remastered  Alice Cooper - Billion Dollar Babies - Rocksmith® 2014 Edition - Remastered (899801) Depot
addappid(899802, 1, "5b4ae6fdbcb296e1303462673f4ecc3aa16d3c50e045b2100c360b76e8e3b65a") -- Rocksmith 2014 Edition  Remastered  Alice Cooper - Poison - Rocksmith® 2014 Edition - Remastered (899802) Depot
addappid(899803, 1, "b3a527bf0bf801aa716c9a030cf90302b58cc2807e73f4ca1ab85ac27f673a2e") -- Rocksmith 2014 Edition  Remastered  Alice Cooper - Schools Out - Rocksmith® 2014 Edition - Remastered (899803) Depot
addappid(899805, 1, "ea0ae423b6cab0f07684c871a9611ac4d8350f322440d20ba03050948a92c01c") -- Rocksmith 2014 Edition  Remastered  Five Finger Death Punch - The Bleeding - Rocksmith® 2014 Edition - Remastered (899805) Depot
addappid(899806, 1, "7f1192850625e23a6538b01d576a73e9b457d61cb29877c28f72d506062d95c5") -- Rocksmith 2014 Edition  Remastered  Five Finger Death Punch - Bad Company - Rocksmith® 2014 Edition - Remastered (899806) Depot
addappid(899807, 1, "83a535a763874096ece5fc38e3bd5b2bf5e9f147c58da735f8ee94fb6f6dc679") -- Rocksmith 2014 Edition  Remastered  Five Finger Death Punch - Wrong Side of Heaven - Rocksmith® 2014 Edition - Remastered (899807) Depot
addappid(899809, 1, "7cd441742d96185717abd3a3cbd9d8a296a39ca84251572758d47703e1a6e5ff") -- Rocksmith 2014 Edition  Remastered  The Rolling Stones - Brown Sugar - Rocksmith® 2014 Edition - Remastered (899809) Depot
addappid(899810, 1, "398c758793640b656952229b817dfb65a0d5c49f1e0736992d8647d9b39764b1") -- Rocksmith 2014 Edition  Remastered  The Rolling Stones - Gimme Shelter - Rocksmith® 2014 Edition - Remastered (899810) Depot
addappid(899811, 1, "0834d582d36cc47447edb8b34dbfd173ff844219bbd6f4ed19edbc17bfb34c3c") -- Rocksmith 2014 Edition  Remastered  The Rolling Stones - Jumpin Jack Flash - Rocksmith® 2014 Edition - Remastered (899811) Depot
addappid(899812, 1, "a631deb0ff31c6255cc8f8560b0780f27a2b225ad68b1b7385a5cc88a157dd88") -- Rocksmith 2014 Edition  Remastered  The Rolling Stones - Sympathy for the Devil - Rocksmith® 2014 Edition - Remastered (899812) Depot
addappid(899814, 1, "059c64aafc8ae79d8d65b7c953f43871c7829ffef9e9bafb1403fc61cf9b98cf") -- Rocksmith 2014 Edition  Remastered  Chuck Berry - Johnny B. Goode - Rocksmith® 2014 Edition - Remastered (899814) Depot
addappid(899815, 1, "2ac5e74dd5f4cf3c0bdbe73823ed58d3ecbe00ee42826d00055ce92f2b293f55") -- Rocksmith 2014 Edition  Remastered  Chuck Berry - School Day (Ring Ring Goes The Bell) - Rocksmith® 2014 Edition - Remastered (899815) Depot
addappid(899816, 1, "3d467b355265fb8fb221602d12bd8ca1095f38b406029287aba3a8aa3b7ed3c2") -- Rocksmith 2014 Edition  Remastered  Chuck Berry - You Never Can Tell - Rocksmith® 2014 Edition - Remastered (899816) Depot
addappid(899818, 1, "0754960f01896af38f1116541d047ffe9e4a61e4bf6f1b2d8f2baa9390ea7293") -- Rocksmith 2014 Edition  Remastered  Paramore - Ignorance - Rocksmith® 2014 Edition - Remastered (899818) Depot
addappid(899819, 1, "3a88aaf3ec3854144ed4874b67dbb2102989044fd3eaa27a37bd92541e0de824") -- Rocksmith 2014 Edition  Remastered  Paramore - Misery Business - Rocksmith® 2014 Edition - Remastered (899819) Depot
addappid(899820, 1, "8750a30347b295ef6e91400c54853a0bb03385d1fdde4bfd57dd77417216121f") -- Rocksmith 2014 Edition  Remastered  Paramore - Rose-Colored Boy - Rocksmith® 2014 Edition - Remastered (899820) Depot
addappid(899822, 1, "38dedd1bd6719db40b81cae619178946cd02c1d9cab1ed649d04728d386c58f0") -- Rocksmith 2014 Edition  Remastered  Thin Lizzy - Whiskey in the Jar - Rocksmith® 2014 Edition - Remastered (899822) Depot
addappid(899823, 1, "7d557a8cff93be6dc711e45094979be95a3866f7fa74bf92a16c947208b32c9a") -- Rocksmith 2014 Edition  Remastered  Wheatus - Teenage Dirtbag - Rocksmith® 2014 Edition - Remastered (899823) Depot
addappid(899824, 1, "95ca5ff7c149b82a979cfd544e26db93559bf246757487f04fe8b340990928f3") -- Rocksmith 2014 Edition  Remastered  Les Paul  Mary Ford - On the Sunny Side of the Street - Rocksmith® 2014 Edition - Remastered (899824) Depot
addappid(899825, 1, "e20d4f0939c4603a61a09cdd541ce6bc490ac25309766416d89bb871ac721768") -- Rocksmith 2014 Edition  Remastered  Deep Blue Something - Breakfast at Tiffanys - Rocksmith® 2014 Edition - Remastered (899825) Depot
addappid(899827, 1, "439c495ca7f068466cbd7da7f39fe0df33c047c22fb26c6861efad82c22b87c6") -- Rocksmith 2014 Edition  Remastered  Queen - Hammer to Fall - Rocksmith® 2014 Edition - Remastered (899827) Depot
addappid(899828, 1, "b950c66b10144d0469f8280d5e278c22115259c5e278a7983f051405adf5906b") -- Rocksmith 2014 Edition  Remastered  Queen - Somebody to Love - Rocksmith® 2014 Edition - Remastered (899828) Depot
addappid(899829, 1, "eaa9ae80efe989ca1f9b046ef2280b008b6c2f0a8bcee327a351246ff31da204") -- Rocksmith 2014 Edition  Remastered  Queen - I Want to Break Free - Rocksmith® 2014 Edition - Remastered (899829) Depot
addappid(899831, 1, "6cf6b40794bd0325e70bb69fab38ef96944810baf939eca4eb66c5baf88d888e") -- Rocksmith 2014 Edition  Remastered  Green Day - When I Come Around - Rocksmith® 2014 Edition - Remastered (899831) Depot
addappid(899832, 1, "dde5a21195870cb13efbba0baf4c040e390b33984a53ba211850dd1670d9f3a9") -- Rocksmith 2014 Edition  Remastered  Stone Temple Pilots - Trippin on a Hole in a Paper Heart - Rocksmith® 2014 Edition - Remastered (899832) Depot
addappid(899833, 1, "dce6ed9ebc16516b7d63a3634b7513680bb80ce29c076f7d35fa7fe019346676") -- Rocksmith 2014 Edition  Remastered  Joan Osborne - One Of Us - Rocksmith® 2014 Edition - Remastered (899833) Depot
addappid(899835, 1, "420c949eea6fcb9a553ffa6ec26eb6174daa92896283eeabe5a69304989d1d17") -- Rocksmith 2014 Edition  Remastered  Sabaton - Primo Victoria - Rocksmith® 2014 Edition - Remastered (899835) Depot
addappid(899836, 1, "de66b0aa4f8591cd455eea287971bc46f93775b4d4cd3f669e8ec27ec058f8b1") -- Rocksmith 2014 Edition  Remastered  Sabaton - Ghost Division - Rocksmith® 2014 Edition - Remastered (899836) Depot
addappid(899837, 1, "1496d3008c322a8f4ab34c1a754bc8bb69734c3897744e7983597874acd1f108") -- Rocksmith 2014 Edition  Remastered  Sabaton - 401 - Rocksmith® 2014 Edition - Remastered (899837) Depot
addappid(899839, 1, "594321b475d10733eb58fee038daeec6bf5b628d020ae2e0663e447e7e7881ce") -- Rocksmith 2014 Edition  Remastered  Drowning Pool - Bodies - Rocksmith® 2014 Edition - Remastered (899839) Depot
addappid(899840, 1, "b6c3a9109efb84bbf86ed45b7810e165fd9304bb5dd4d3c9da6a15f8bdecc2b5") -- Rocksmith 2014 Edition  Remastered  Fountains of Wayne - Stacys Mom - Rocksmith® 2014 Edition - Remastered (899840) Depot
addappid(899841, 1, "ec68c05fc5eca803797162db435c33a58cdb38ef13e507310c2f908911d538d7") -- Rocksmith 2014 Edition  Remastered  blink-182 - Always - Rocksmith® 2014 Edition - Remastered (899841) Depot
addappid(899843, 1, "06ad88861d3407fa63fb4e7d675262f4d0aeec3071693a11000ee2f129eeecf6") -- Rocksmith 2014 Edition  Remastered  Gin Blossoms - Found Out About You - Rocksmith® 2014 Edition - Remastered (899843) Depot
addappid(899844, 1, "acf8b9733f28421485478552ab2f7f6df39204afd30ba1b5f5bf2b2e25dc3580") -- Rocksmith 2014 Edition  Remastered  Warren Zevon - Werewolves of London - Rocksmith® 2014 Edition - Remastered (899844) Depot
addappid(899845, 1, "18108fafbf2ac9168bfa7f857671b03006144a335682aca451cb7026afba7310") -- Rocksmith 2014 Edition  Remastered  Fuel - Shimmer - Rocksmith® 2014 Edition - Remastered (899845) Depot
addappid(899846, 1, "df13415a3dff5b47a738edc864c0a646c499fbaf5762968bcfa57876f00dfe7c") -- Rocksmith 2014 Edition  Remastered  Clutch - The Regulator - Rocksmith® 2014 Edition - Remastered (899846) Depot
addappid(899848, 1, "f11710962936983f25dc7972a972fed0747320f84e43d72c3c2ef0c0bdf3a2cb") -- Rocksmith 2014 Edition  Remastered  Heart - What About Love - Rocksmith® 2014 Edition - Remastered (899848) Depot
addappid(899849, 1, "443d57de5a47a750978128783098ea49286ac7124803b09f8a0fb4c7d6a9dd4e") -- Rocksmith 2014 Edition  Remastered  Heart - Alone - Rocksmith® 2014 Edition - Remastered (899849) Depot
addappid(899850, 1, "d6347508a8a2db2b7028a2769082ab98e2c0c909fe539d5065069cd23fb83121") -- Rocksmith 2014 Edition  Remastered  Heart - Straight On - Rocksmith® 2014 Edition - Remastered (899850) Depot
addappid(899852, 1, "76a3d0ff7ee57ec01ce91b8cd54c226c8575d7135239bc09b7d1cf19a9a83a0e") -- Rocksmith 2014 Edition  Remastered  Night Ranger - Sister Christian - Rocksmith® 2014 Edition - Remastered Depot
addappid(899853, 1, "39a62a06efd6952b7653a42d4d8bb6145c61a7427206db5ba704c19b34c902b6") -- Rocksmith 2014 Edition  Remastered  Night Ranger - Dont Tell Me You Love Me - Rocksmith® 2014 Edition - Remastered Depot
addappid(899854, 1, "2a36804cf8d0a6f77465c51ef96f712514f7362d13a55490c2ea1c07349ba91c") -- Rocksmith 2014 Edition  Remastered  Night Ranger - (You Can Still) Rock in America - Rocksmith® 2014 Edition - Remastered Depot
addappid(899856, 1, "61e816ca08ea7eafc4f127946eec1a6fbd1f1ba1a6dd443b98f180313924dd96") -- Rocksmith 2014 Edition  Remastered  Commodores - Brick House - Rocksmith® 2014 Edition – Remastered – Commodores - “Brick House” Depot
addappid(899857, 1, "1f72a2f7a5c69e8f645fc435f29677aaa02a5b77da6ebbe31b95fc31a0806b06") -- Rocksmith 2014 Edition  Remastered  The Hollies - Long Cool Woman (In a Black Dress) - Rocksmith® 2014 Edition – Remastered – The Hollies - “Long Cool Woman (In a Black Dress)” Depot
addappid(899858, 1, "17b166db9c7a268599ed64a960508ba48f6eb8cd8a9b211ff3fed73abca968fe") -- Rocksmith 2014 Edition  Remastered  Funkadelic - Maggot Brain - Rocksmith® 2014 Edition – Remastered – Funkadelic - “Maggot Brain Depot
addappid(899859, 1, "7440c8b90e51369b89d60355ba4b2536fa59bcf35c031e215e1ea140b80a8f75") -- Rocksmith 2014 Edition  Remastered  Radiohead Song Pack III - Rocksmith® 2014 Edition – Remastered – Radiohead Song Pack III Depot
addappid(899860, 1, "dc4414e4d93e2861dfb277c1f516dc53109a6f00441c9239b7a0da85f282803b") -- Rocksmith 2014 Edition  Remastered  Radiohead - Fake Plastic Trees - Rocksmith® 2014 Edition – Remastered – Radiohead - “Fake Plastic Trees” Depot
addappid(899861, 1, "cd561f0d06832817a487c16ccce5a0332be36418df4f5b727e8e7c271564a2de") -- Rocksmith 2014 Edition  Remastered  Radiohead - Jigsaw Falling Into Place - Rocksmith® 2014 Edition – Remastered – Radiohead - “Jigsaw Falling Into Place” Depot
addappid(899862, 1, "f0c99899c608f0ff727379ec18c630c251c13c800ef15cc534f628edfa219089") -- Rocksmith 2014 Edition  Remastered  Radiohead - Airbag - Rocksmith® 2014 Edition – Remastered – Radiohead - “Airbag” Depot
addappid(899864, 1, "7e82b9221e4c8141c8968a443c4b524b9e6925602acb80c40d51c4df539b78f2") -- Rocksmith 2014 Edition  Remastered  Roxette - The Look - Rocksmith® 2014 Edition – Remastered – Roxette - “The Look” Depot
addappid(899865, 1, "073607cdad9c09fd747b6c7fdefa7eb351e0595b8b13e7c00662a91575eed251") -- Rocksmith 2014 Edition  Remastered  Roxette - Listen to Your Heart - Rocksmith® 2014 Edition – Remastered – Roxette - “The Look” Depot
addappid(899866, 1, "9aae7e846db8628253865acf75c13cd8da864699d2d097ff1066f16bd462786e") -- Rocksmith 2014 Edition  Remastered  Roxette - It Must Have Been Love - Rocksmith® 2014 Edition – Remastered – Roxette - “Listen to Your Heart” Depot
addappid(899868, 1, "e968794b803c487349fe8796f06afe323ca86d05960ecb40d8ae48108cebd2e0") -- Rocksmith 2014 Edition  Remastered  Cat Stevens - Wild World - Rocksmith® 2014 Edition – Remastered – Cat Stevens - “Wild World” Depot
addappid(899869, 1, "9de462e0ba422bcd85778a9230f153412f4062c7043224ea51993e3b9dca31de") -- Rocksmith 2014 Edition  Remastered  Cat Stevens - Father and Son - Rocksmith® 2014 Edition – Remastered – Cat Stevens - “Father and Son” Depot
addappid(899870, 1, "c2c4dfc5bb69f6e02a51438c66d5b1e91ac50b9c595ad5447299c0a115069239") -- Rocksmith 2014 Edition  Remastered  Cat Stevens - Morning Has Broken - Rocksmith® 2014 Edition – Remastered – Cat Stevens - “Morning Has Broken” Depot
addappid(899872, 1, "43dc553e609a44f22f9a223c9e55a03cd24e74b570fd4c60d7a119c0ebacb29f") -- Rocksmith 2014 Edition  Remastered  Dishwalla - Counting Blue Cars - Rocksmith® 2014 Edition – Remastered – Dishwalla - “Counting Blue Cars” Depot
addappid(899873, 1, "0d1677f6a404ea55af64a4d508ed983c0302d76e0442db0d58a7f436b7346627") -- Rocksmith 2014 Edition  Remastered  Annihilator - Alison Hell - Rocksmith® 2014 Edition – Remastered – Annihilator - “Alison Hell” Depot
addappid(899874, 1, "9aea9070ce87820dac833e61dc05a46e26cbfb49ec59182f9b3082f0b14e77b0") -- Rocksmith 2014 Edition  Remastered  Wanda Jackson - Long Tall Sally - Rocksmith® 2014 Edition – Remastered – Wanda Jackson - “Long Tall Sally” Depot
addappid(899875, 1, "679542ec55ccc610b36243108c5ad08d5325e32c06c6fb0a7ef104bcd73e0444") -- Rocksmith 2014 Edition  Remastered  Ghost - From the Pinnacle to the Pit - Rocksmith® 2014 Edition – Remastered – Ghost - “From the Pinnacle to the Pit” Depot
addappid(899877, 1, "f1f24b31805fe622440187e059b236f527895142706123360cffea83a3225c07") -- Rocksmith 2014 Edition  Remastered  Coldplay- Shiver - Rocksmith® 2014 Edition – Remastered – Coldplay- “Shiver” Depot
addappid(899878, 1, "52853b309d2a1101f29e24ead772bb8ceb6537efcadefd11afa3f99bb851af3e") -- Rocksmith 2014 Edition  Remastered  Angels  Airwaves- The Adventure - Rocksmith® 2014 Edition – Remastered – Angels & Airwaves- “The Adventure” Depot
addappid(899879, 1, "b2f357b74d22f2f5272719ff87e45fb2ad44dda58a68e566e63e4f00c9865f50") -- Rocksmith 2014 Edition  Remastered  Andrew W.K.- Party Hard - Rocksmith® 2014 Edition – Remastered – Andrew W.K.- “Party Hard” Depot
addappid(899881, 1, "0a25544afd1c76e6d40a71dac27d3cc1640816e4dc8041cdf22d5db6eb25ffe0") -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet - Edge of Darkness - Rocksmith® 2014 Edition – Remastered – Greta Van Fleet - “Edge of Darkness” Depot
addappid(899882, 1, "31a49d88417a758eef565357c13c21d75e4561086bf0acb4041c6dcbfead92ce") -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet - Youre the One - Rocksmith® 2014 Edition – Remastered – Greta Van Fleet - “You’re the One” Depot
addappid(899883, 1, "6c0634e3050ebe00cbbfb2447437e1ce84217b3bec80b100be943fc11eb7fdcc") -- Rocksmith 2014 Edition  Remastered  Greta Van Fleet - When the Curtain Falls - Rocksmith® 2014 Edition – Remastered – Greta Van Fleet - “When the Curtain Falls” Depot
addappid(899885, 1, "6011dec0beab9e119d958b3cd50c67fb21604d64723fb87159d43598a8467d6b") -- Rocksmith 2014 Edition  Remastered  Cyndi Lauper - Girls Just Want to Have Fun - Rocksmith® 2014 Edition – Remastered – Cyndi Lauper - “Girls Just Want to Have Fun” Depot
addappid(899886, 1, "fbcf20017342fd68af339907a51ce68fe0d274a2d887226e01247215b9984f34") -- Rocksmith 2014 Edition  Remastered  Cyndi Lauper - Time After Time - Official game title: Rocksmith® 2014 Edition – Remastered – Cyndi Lauper - “Time After Time” Depot
addappid(899887, 1, "e38d8f6fe413b42d27c90d0185daa4fa8fc9cb04d2c8d509fe1bca3d37c72bf5") -- Rocksmith 2014 Edition  Remastered  Cyndi Lauper - True Colors - Rocksmith® 2014 Edition – Remastered – Cyndi Lauper - “True Colors” Depot
addappid(899889, 1, "4fcd2a1780fb12c982991b151a7ba12b1dd6632c5f52ed4ce63d77823fb2548e") -- Rocksmith 2014 Edition  Remastered  P.O.D. - Alive - Rocksmith® 2014 Edition – Remastered – P.O.D. - “Alive” Depot
addappid(899890, 1, "f04e20e22574fdd4058ce0c8271869540cefefa3d61da5d82416dc45feee451b") -- Rocksmith 2014 Edition  Remastered  P.O.D. - Youth of the Nation - Rocksmith® 2014 Edition – Remastered – P.O.D. - “Youth of the Nation” Depot
addappid(899891, 1, "d2198541d2df3ed1d912c02c265d08844956b8c9470e8f79f319bad26fd75682") -- Rocksmith 2014 Edition  Remastered  P.O.D. - Boom - Rocksmith® 2014 Edition – Remastered – P.O.D. - “Boom” Depot
addappid(899892, 1, "92e5a1c8f42895fde3f0d9afdc9982f86ce38156d2930fa32b47f94a20aedd99") -- Rocksmith 2014 Edition  Remastered  Classic Melody Song Pack - Rocksmith® 2014 Edition – Remastered – Classic Melody Song Pack Depot
addappid(899897, 1, "d8579b135130cc29c67d523c80ed66cf31267347a415c24ef76c9ff7a0145691") -- Rocksmith 2014 Edition  Remastered  5 Seconds of Summer - Amnesia - Rocksmith® 2014 Edition – Remastered – 5 Seconds of Summer - “Amnesia Depot
addappid(899898, 1, "a2d2a57c8e4ac0f91d24328916b5fed53f8cd0854a918020540a285abf9cac41") -- Rocksmith 2014 Edition  Remastered  5 Seconds of Summer - She Looks So Perfect - Rocksmith® 2014 Edition – Remastered – 5 Seconds of Summer - “She Looks So Perfect” Depot
addappid(899899, 1, "fc238d1724e1da6fc24c12b62413df07cf65b6d6184804d5b0f40d49542c829f") -- Rocksmith 2014 Edition  Remastered  5 Seconds of Summer - Shes Kinda Hot - Rocksmith® 2014 Edition – Remastered – 5 Seconds of Summer - “She’s Kinda Hot” Depot
addappid(899900, 1, "ddd40f67af4f6b4155526ee7abdb23041811b54bde86decee12965d5fdc05a8f") -- Rocksmith 2014 Edition  Remastered  Rocksmith Easy Exercises, Vol. 1 - Rocksmith® 2014 Edition – Remastered – Rocksmith Easy Exercises, Vol. 1 Depot
addappid(1089161, 1, "844635054739447eb3525c5e489a7e880c4ddaf5422cdee7f2cea6e0aaefacf4") -- Rocksmith 2014 Edition  Remastered  Trivium - Pull Harder on the Strings of Your Martyr - Rocksmith® 2014 Edition – Remastered – Trivium - “Pull Harder on the Strings of Your Martyr” Depot
addappid(1089162, 1, "a51dacc4fb5bf27e92c83f5310cb9ef6640d165894c3345a8dc67aae56752f55") -- Rocksmith 2014 Edition  Remastered  Trivium - Dying in Your Arms - Rocksmith® 2014 Edition – Remastered – Trivium - “Dying in Your Arms” Depot
addappid(1089163, 1, "86bdafdacd7bc87f2185a2af6c891b03e235f70dc805f88e6adf259e3e8589b8") -- Rocksmith 2014 Edition  Remastered  Trivium - A Gunshot to the Head of Trepidation - Rocksmith® 2014 Edition – Remastered – Trivium - “A Gunshot to the Head of Trepidation” Depot
addappid(1089165, 1, "12472d4fdffccbfc0e072f222c0b488bd903081c84ad5f7d345210582ff1a168") -- Rocksmith 2014 Edition  Remastered  Reel Big Fish - Take On Me - Rocksmith® 2014 Edition – Remastered – Reel Big Fish - “Take On Me” Depot
addappid(1089166, 1, "c45c44041151e3ba12c57ca27f837f6b0415077cdb1c65e81ecb2ec7c728c106") -- Rocksmith 2014 Edition  Remastered  Nightwish - Over the Hills and Far Away - Rocksmith® 2014 Edition – Remastered – Nightwish - “Over the Hills and Far Away” Depot
addappid(1089167, 1, "f16299bf3d1efe930a7f37f632b793f50761013e30d6bbd2c37a92ef2adafa0f") -- Rocksmith 2014 Edition  Remastered  Joan Jett  the Blackhearts - Louie Louie - Rocksmith® 2014 Edition – Remastered – Joan Jett &amp; the Blackhearts - “Louie Louie” Depot
addappid(1089169, 1, "a7256062a384ca65ffcf04367c66a7fa578261091c4d411a5769c118104b3385") -- Rocksmith 2014 Edition  Remastered  Tegan and Sara - The Con - Rocksmith® 2014 Edition – Remastered – Tegan and Sara - “The Con” Depot
addappid(1089170, 1, "23571c03e951492aad9c46a3aa7ac70d3684f867079f92f44829634cba9f450c") -- Rocksmith 2014 Edition  Remastered  Tegan and Sara - Walking with a Ghost - Rocksmith® 2014 Edition – Remastered – Tegan and Sara - “Walking with a Ghost” Depot
addappid(1089171, 1, "987221b4742aaaf15c697d08cc6587bcf6e5b32912f47ca52a0b8e22bbec10b4") -- Rocksmith 2014 Edition  Remastered  Tegan and Sara - Call It Off - Rocksmith® 2014 Edition – Remastered – Tegan and Sara - “Call It Off” Depot
addappid(1089172, 1, "4eab017c2dddc5fc88212be96a197eb0cf6b931a1de316250cf953083e02969d") -- Rocksmith 2014 Edition  Remastered  Rocksmith Intermediate Exercises, Vol. 1 - Rocksmith® 2014 Edition – Remastered – Rocksmith Intermediate Exercises, Vol. 1 Depot
addappid(1089184, 1, "89c7fea735706a45b5e747cd65c010be6e3f06b0f60284fc1e12f2d71c96cf41") -- Rocksmith 2014 Edition  Remastered  The Pretty Reckless - Going to Hell - Rocksmith® 2014 Edition – Remastered – The Pretty Reckless - “Going to Hell” Depot
addappid(1089185, 1, "25d5178cb156857fa1bf449858fd7836545f8a4643c20bdb1cec79656c64551c") -- Rocksmith 2014 Edition  Remastered  The Pretty Reckless - Make Me Wanna Die - Rocksmith® 2014 Edition – Remastered – The Pretty Reckless - “Make Me Wanna Die” Depot
addappid(1089186, 1, "1cdeb22c258426a489170bfc03eaeffe2a9d63ef1d202cdd308595547324939b") -- Rocksmith 2014 Edition  Remastered  The Pretty Reckless - My Medicine - Rocksmith® 2014 Edition – Remastered – The Pretty Reckless - “My Medicine” Depot
addappid(1089188, 1, "5c42d2727c1f276d7aa860c234ed7dfa1e9a67d4742ee77e31441878bba17d70") -- Rocksmith 2014 Edition  Remastered  X Ambassadors - Renegades - Rocksmith® 2014 Edition – Remastered – X Ambassadors - “Renegades” Depot
addappid(1089189, 1, "4dfbdfb202c5ad36492fa6e5b85b9ce7747f1150f275e97e81a9fffa04670611") -- Rocksmith 2014 Edition  Remastered  Snow Patrol - Chasing Cars - Rocksmith® 2014 Edition – Remastered – Snow Patrol - “Chasing Cars” Depot
addappid(1089190, 1, "68013f1e3405fa930e34998b1d600baa92ebe712f839b8271f718aba60c4f197") -- Rocksmith 2014 Edition  Remastered  Aranbee Pop Symphony Orchestra - Bittersweet Symphony - Rocksmith® 2014 Edition – Remastered – Aranbee Pop Symphony Orchestra - “Bittersweet Symphony” Depot
addappid(1089192, 1, "9e29325fcd45c717a8bfe86d548b21eb02cd47bc5733e0f994fbf6e2a36b6c42") -- Rocksmith 2014 Edition  Remastered  Manic Street Preachers - Motorcycle Emptiness - Rocksmith® 2014 Edition – Remastered – Manic Street Preachers - “Motorcycle Emptiness” Depot
addappid(1089193, 1, "66e52144a4914fb8204312e95de40b2f1d45b3f4fd968536c339b9a5f2a78815") -- Rocksmith 2014 Edition  Remastered  Manic Street Preachers - A Design for Life - Rocksmith® 2014 Edition – Remastered – Manic Street Preachers - “A Design for Life” Depot
addappid(1089194, 1, "b79c027cc7b8138cad7a2e604a10ce0941b8c8aa4b76629450b72ac6f0bdabda") -- Rocksmith 2014 Edition  Remastered  Manic Street Preachers - If You Tolerate This Your Children Will Be Next - Rocksmith® 2014 Edition – Remastered – Manic Street Preachers - “If You Tolerate This Your Children Will Be Next” Depot
addappid(1089196, 1, "67f50ee809e273c6e48128763c64a376081d068f39e50e836c638f2066ec97b9") -- Rocksmith 2014 Edition  Remastered  Gary Moore - The Loner - Rocksmith® 2014 Edition – Remastered – Gary Moore - “The Loner” Depot
addappid(1089197, 1, "f66e195741fb3dfe608d0a411c89d8a40e94030a5aef4fa99f4904461d62b673") -- Rocksmith 2014 Edition  Remastered  Gary Moore - Over the Hills and Far Away - Rocksmith® 2014 Edition – Remastered – Gary Moore - “Over the Hills and Far Away” Depot
addappid(1089198, 1, "53ffdc97a17ac6191da1b4f96f202a8f7bb6c215675e41d5da8451160134d279") -- Rocksmith 2014 Edition  Remastered  Gary Moore - Still Got the Blues - Rocksmith® 2014 Edition – Remastered – Gary Moore - “Still Got the Blues” Depot
addappid(1089199) -- Rocksmith 2014 Edition  Remastered  Rocksmith Advanced Exercises, Vol. 1
addappid(1089211, 1, "50a2d5faf3b3a20959054d53133c84af96a7eead36254c01e1ed2ea4bf85ce28") -- Rocksmith 2014 Edition  Remastered  Jim Johnston - I Wont Do What You Tell Me (Stone Cold Steve Austin) - Rocksmith® 2014 Edition – Remastered – Jim Johnston - “I Won’t Do What You Tell Me (Stone Cold Steve Austin)” Depot
addappid(1089212, 1, "5b621d71ce8e11befb5cd363e6e090b1972f864b7d1ae49f624124c4eaffbe5a") -- Rocksmith 2014 Edition  Remastered  Jim Johnston - Electrifying (The Rock) - Rocksmith® 2014 Edition – Remastered – Jim Johnston - “Electrifying (The Rock)” Depot
addappid(1089213, 1, "703bf977e49db3dd74bee88a26c2e8e5c783ea549371b2c553d1ae148cfe9b1c") -- Rocksmith 2014 Edition  Remastered  Jim Johnston - Break the Walls Down (Chris Jericho) - Rocksmith® 2014 Edition – Remastered – Jim Johnston - “Break the Walls Down (Chris Jericho) Depot
addappid(1089215, 1, "5fc1f2b1df0251626767fe361fce5fea78191510f9c79c1b96fc2fd87c37122a") -- Rocksmith 2014 Edition  Remastered  Bloodhound Gang - The Bad Touch - Rocksmith® 2014 Edition – Remastered – Bloodhound Gang - “The Bad Touch” Depot
addappid(1089216, 1, "a7a921846290dad10512f186ea9f068b83f59acd8799938a322f6acc78894000") -- Rocksmith 2014 Edition  Remastered  Bloodhound Gang - Foxtrot Uniform Charlie Kilo - Rocksmith® 2014 Edition – Remastered – Bloodhound Gang - “Foxtrot Uniform Charlie Kilo” Depot
addappid(1089219, 1, "24703beb2daaab385045ab1b87b06e9221bb51d9f62e2163a492e891bc8233de") -- Rocksmith 2014 Edition  Remastered  The Go-Gos - We Got the Beat - Rocksmith® 2014 Edition – Remastered – The Go-Go’s - “We Got the Beat” Depot
addappid(1089220, 1, "2a20162257891d45113378e5e4c7f79aa14f1c883d78c4611059d107e40b6742") -- Rocksmith 2014 Edition  Remastered  Veruca Salt - Seether - Rocksmith® 2014 Edition – Remastered – Veruca Salt - “Seether” Depot
addappid(1089221, 1, "90f1a8d6e233db9d7b118b2cf098d048d69c0137a5ac05955937ff38d06edcd9") -- Rocksmith 2014 Edition  Remastered  Orianthi - According to You - Rocksmith® 2014 Edition – Remastered – Orianthi - “According to You” Depot
addappid(1089222, 1, "8148c074bec19a5266a673b4b0b8eb06190b8aa230db7b3c950da197236159bf") -- Rocksmith 2014 Edition  Remastered  Rocksmith Easy Exercises, Vol. 2 - Rocksmith® 2014 Edition – Remastered – Rocksmith Easy Exercises, Vol. 2 Depot
addappid(1089233, 1, "fea47ee44285c896b49f6191ca23c1b65f3b696f9a105a199381b9a18908d499") -- Rocksmith 2014 Edition  Remastered  Kaleo Song Pack - Rocksmith® 2014 Edition – Remastered – Kaleo Song Pack Depot
addappid(1089234, 1, "ed13440758677716b9161ab92391813b6ba2d3fde2a61e14c240e9d5bb3b10c4") -- Rocksmith 2014 Edition  Remastered  Kaleo - No Good - Rocksmith® 2014 Edition – Remastered – Kaleo - “No Good” Depot
addappid(1089235, 1, "5363c91a1c0919e795f9eff7f6cd1b1b51cf69a06a719b3cc987b211eec4df85") -- Rocksmith 2014 Edition  Remastered  Kaleo - Way Down We Go - Rocksmith® 2014 Edition – Remastered – Kaleo - “Way Down We Go” Depot
addappid(1089236, 1, "e46e35903ffe87e462f304c281ab32d6185a8389b1f77759fcb79438d1b12dc2") -- Rocksmith 2014 Edition  Remastered  Kaleo - All the Pretty Girls - Rocksmith® 2014 Edition – Remastered – Kaleo - “All the Pretty Girls” Depot
addappid(1089238, 1, "f5c3d833ec5898f082ca2434d9c56f4c02fbbba078bef8eeb9e1279518888cc4") -- Rocksmith 2014 Edition  Remastered  The Dooo - Guitar Solos with Dooo 2 - Ascend - Rocksmith® 2014 Edition – Remastered – The Dooo - “Guitar Solos with Dooo #2 - Ascend” Depot
addappid(1089239, 1, "a39431e70ace64e73557fa2d14f28a6e3e17bd5bde0058604d65ef9114aef704") -- Rocksmith 2014 Edition  Remastered  Set The Charge - Everything But Me - Rocksmith® 2014 Edition – Remastered – Set The Charge - “Everything But Me” Depot
addappid(1089240, 1, "66fbd4b96c8e34de4750482b71c08ad7d75758aa180d6715b53f30768002e558") -- Rocksmith 2014 Edition  Remastered  Audrey and Kate - No Reason - Rocksmith® 2014 Edition – Remastered – Audrey and Kate - “No Reason” Depot
addappid(1089241, 1, "ab41117ba24fa81601afb63cea925338c0b1d016a5d19b722bf9f75b6d22ec8b") -- Rocksmith 2014 Edition  Remastered  DragonForce - Highway to Oblivion - Rocksmith® 2014 Edition – Remastered – DragonForce - “Highway to Oblivion” Depot
addappid(1089243, 1, "ca07d94ba624a154a434b51dbc8f5392441f28a959bf11d75a3d5ed1d2fdde61") -- Rocksmith 2014 Edition  Remastered  Amaranthe - The Nexus - Rocksmith® 2014 Edition – Remastered – Amaranthe - “The Nexus” Depot
addappid(1089244, 1, "20a235e06141c6ef2db0a8441dbed64256c833fdca558cca93364230dd55316b") -- Rocksmith 2014 Edition  Remastered  Amaranthe - Amaranthine - Rocksmith® 2014 Edition – Remastered – Amaranthe - “Amaranthine” Depot
addappid(1089245, 1, "3a609d349d50692d3b6d1e24981e9d15d52e31caea10b1419946583eb90e3dce") -- Rocksmith 2014 Edition  Remastered  Amaranthe - Drop Dead Cynical - Rocksmith® 2014 Edition – Remastered – Amaranthe - “Drop Dead Cynical” Depot
addappid(1122551) -- Rocksmith 2014 Edition  Remastered  Rocksmith Intermediate Exercises, Vol. 2
addappid(1122563, 1, "89bc76d799d37405ba6dd835d124a9a9f4f6b2578bf7c89b57fa3ed524b98fd5") -- Rocksmith 2014 Edition  Remastered  Children of Bodom - Are You Dead Yet - Rocksmith® 2014 Edition – Remastered – Children of Bodom - “Are You Dead Yet?” Depot
addappid(1122564, 1, "64c03db2a5ba8f1cfcd37158d75ec2e344f67d784e08eec9a2903a9f7a7e80c3") -- Rocksmith 2014 Edition  Remastered  Machine Head - Davidian - Rocksmith® 2014 Edition – Remastered – Machine Head - “Davidian” Depot
addappid(1122565, 1, "15ec1501dcb2c715abe26443ec3c1f34208562687762657bb2358448768b111b") -- Rocksmith 2014 Edition  Remastered  Death - Crystal Mountain - Rocksmith® 2014 Edition – Remastered – Death - “Crystal Mountain” Depot
addappid(1122571, 1, "6c18e85f7efb530321a3d9a9087ac478c451b9530de4a3776be01881071c91e7") -- Rocksmith 2014 Edition  Remastered  The Zombies - Time of the Season - Rocksmith® 2014 Edition – Remastered – The Zombies - “Time of the Season” Depot
addappid(1122572, 1, "935991e708a1011eb63a74a604594ab1399aadc281949d64fedcf0bd9a06b9f3") -- Rocksmith 2014 Edition  Remastered  The Zombies - Shes Not There - Rocksmith® 2014 Edition – Remastered – The Zombies - “She’s Not There” Depot
addappid(1122573, 1, "cff09db858cecab917bc0d36368a25c018d10c8b95ce6bf63343b60603890780") -- Rocksmith 2014 Edition  Remastered  The Zombies - Tell Her No - Rocksmith® 2014 Edition – Remastered – The Zombies - “Tell Her No” Depot
addappid(1122574, 1, "6b330934a9d23655c91babaa30efb128003ed7a5b3488624692e58817fa12a25") -- Rocksmith 2014 Edition  Remastered  Rocksmith Advanced Exercises, Vol. 2 - Rocksmith® 2014 Edition – Remastered – Rocksmith Advanced Exercises, Vol. 2 Depot
addappid(1122585, 1, "684fe49b1bc1ab0f92046bd9ac1bf40c1092d8af83aa1519ea748cc1d5866a08") -- Rocksmith 2014 Edition  Remastered  Daughtry Song Pack - Rocksmith® 2014 Edition – Remastered – Daughty Song Pack Depot
addappid(1122586, 1, "f44e7c0e5e1f6fb52df14b6445c6ec546797866fad65f347582df8a0567a46c7") -- Rocksmith 2014 Edition  Remastered  Daughtry - Feels Like Tonight - Rocksmith® 2014 Edition – Remastered – Daughtry - “Feels Like Tonight” Depot
addappid(1122587, 1, "a9173636393a824c612d0ce52b7855befb1cfafc7a916687f078ced6d86296fa") -- Rocksmith 2014 Edition  Remastered  Daughtry - Over You - Rocksmith® 2014 Edition – Remastered – Daughtry - “Over You” Depot
addappid(1122588, 1, "85996ee460b938781f93cef47e47cb54ab643f24c15f33f36dbdcd65d33dee40") -- Rocksmith 2014 Edition  Remastered  Daughtry - Home - Rocksmith® 2014 Edition – Remastered – Daughtry - “Home” Depot
addappid(1122594, 1, "fc09933e0b71b2de32ee0a179057c2e3354124c1017ef4be25ddb5b08d013e5d") -- Rocksmith 2014 Edition  Remastered  Shuggie Otis - Bootie Cooler - Rocksmith® 2014 Edition – Remastered – Shuggie Otis - “Bootie Cooler” Depot
addappid(1122595, 1, "766ce6a0d47067ab52dea10bffa125bea5d3ba25b251b2eb7ed46751e3935f0d") -- Rocksmith 2014 Edition  Remastered  John Lee Hooker - San Francisco - Rocksmith® 2014 Edition – Remastered – John Lee Hooker - “San Francisco” Depot
addappid(1122596, 1, "29bc8cab072890c8dcad38fa4f413a5fcccf1271d2802f2ed5a994f43f39154a") -- Rocksmith 2014 Edition  Remastered  Freddie King - Going Down - Rocksmith® 2014 Edition – Remastered – Freddie King - “Going Down” Depot
addappid(1122598, 1, "e1ea9d6187666bd8b7cd46fe6b4381b47db1e1c6f652aa307736dfb43057c598") -- Rocksmith 2014 Edition  Remastered  Pat Benatar - We Belong - Rocksmith® 2014 Edition – Remastered – Pat Benatar - “We Belong” Depot
addappid(1122599, 1, "a3dbcbc77f0e65ac1cf6d742dacece24f9f74a663f814020311dbff78c14e85f") -- Rocksmith 2014 Edition  Remastered  Pat Benatar - Heartbreaker - Rocksmith® 2014 Edition – Remastered – Pat Benatar - “Heartbreaker” Depot
addappid(1122600, 1, "ce78ed5dfeaebca08bf945ac0e2851ac84f2eec4e95f082fc540be5465eae5ec") -- Rocksmith 2014 Edition  Remastered  Pat Benatar - Hell is for Children - Rocksmith® 2014 Edition – Remastered – Pat Benatar - “Hell is for Children” Depot
addappid(1122602, 1, "ed4b5005c1151afb965a2cab9415ffe8959771e93eb8ce16aee331678547bbb1") -- Rocksmith 2014 Edition  Remastered  Weezer - Beverly Hills - Rocksmith® 2014 Edition – Remastered – Weezer - “Beverly Hills” Depot
addappid(1122603, 1, "ba04b55a28b4cd5dd3bb019161e812889b71fabb30d593b8d15034c7ce687d22") -- Rocksmith 2014 Edition  Remastered  Weezer - Perfect Situation - Rocksmith® 2014 Edition – Remastered – Weezer - “Perfect Situation” Depot
addappid(1122604, 1, "494fb32b8e1e1e4c13e52f1cda5b149fb1dd391da818429f38c2b3ee9e18cbc1") -- Rocksmith 2014 Edition  Remastered  Weezer - Pork and Beans - Rocksmith® 2014 Edition – Remastered – Weezer - “Pork and Beans” Depot
addappid(1122606, 1, "8049d0196664f81e8982bb61a08d2d3a0871fe90eb700106c36e736d4da472e1") -- Rocksmith 2014 Edition  Remastered  ABBA - Dancing Queen - Rocksmith® 2014 Edition – Remastered – ABBA - “Dancing Queen” Depot
addappid(1122607, 1, "86db368d5295beb193f4fd0b6c4c1e55138206d09309ea6f297e3fb9dfef1d4d") -- Rocksmith 2014 Edition  Remastered  ABBA - Fernando - Rocksmith® 2014 Edition – Remastered – ABBA - “Fernando” Depot
addappid(1122608, 1, "59e950217cb8e9f95f4776d6f2accdfb054be06eaf187bf037243799e38d9bcf") -- Rocksmith 2014 Edition  Remastered  ABBA - Mamma Mia - Rocksmith® 2014 Edition – Remastered – ABBA - “Mamma Mia” Depot
addappid(1122610, 1, "bd64a49104617719e4a9262bc6d9c8bbdd68788db5a527a4fa819fb693169364") -- Rocksmith 2014 Edition  Remastered  Aerosmith - Crazy - Rocksmith® 2014 Edition – Remastered – Aerosmith - “Crazy” Depot
addappid(1122611, 1, "50f320363d96bd06b76caa89f4ebf409c66f35c0d9449651741afdfe9c1c36b4") -- Rocksmith 2014 Edition  Remastered  Aerosmith - Love in an Elevator - Rocksmith® 2014 Edition – Remastered – Aerosmith - “Love in an Elevator” Depot
addappid(1122612, 1, "ea807164a543cfb4bf8cb35c8e7ad40b9d7f0465ee0ffbd1beac38cb7bccbe6b") -- Rocksmith 2014 Edition  Remastered  Aerosmith - Train Kept A-Rollin - Rocksmith® 2014 Edition – Remastered – Aerosmith - “Train Kept A-Rollin’” Depot
addappid(1122614, 1, "25c4e5bfeb063b516da0cb22f3b5a4a56b93a1d8c5025c9b610d55b290d5e023") -- Rocksmith 2014 Edition  Remastered  Chris Stapleton - Tennessee Whiskey - Rocksmith® 2014 Edition – Remastered – Chris Stapleton - “Tennessee Whiskey” Depot
addappid(1122615, 1, "1f73f7f3665ca0ea96e7b451b8bbf50fa01e1bbb3e8bafaab25c2b0e4c245924") -- Rocksmith 2014 Edition  Remastered  Chris Stapleton - Parachute - Rocksmith® 2014 Edition – Remastered – Chris Stapleton - “Parachute” Depot
addappid(1122616, 1, "9cfd0d244697e6058680ce928d2a49a1318e29eb1dc53bd1c447e2bafbfeaf44") -- Rocksmith 2014 Edition  Remastered  Chris Stapleton - Nobody to Blame - Rocksmith® 2014 Edition – Remastered – Chris Stapleton - “Nobody to Blame” Depot
addappid(1122618, 1, "a2f6155be46c0def06e3a8eb072a2c081489c37cdc273e42484f2b406d6ba367") -- Rocksmith 2014 Edition  Remastered  John Mellencamp - Small Town - Rocksmith® 2014 Edition – Remastered – John Mellencamp - “Small Town” Depot
addappid(1122619, 1, "c042395db49db60f1616cb651f9fbfd398f259cb90321ac25f24b255e5688b2c") -- Rocksmith 2014 Edition  Remastered  John Mellencamp - Jack  Diane - Rocksmith® 2014 Edition – Remastered – John Mellencamp - “Jack &amp; Diane” Depot
addappid(1122620, 1, "56c64ec052debd67d46956abd0a47e522959cd375c5ee4745f6ca1477c9b1f48") -- Rocksmith 2014 Edition  Remastered  John Mellencamp - Pink Houses - Rocksmith® 2014 Edition – Remastered – John Mellencamp - “Pink Houses” Depot
addappid(1122622, 1, "a7bba4a42ab08491fed0ffa4d578e2d0d3c860856db70f9c7f65682862ffb80f") -- Rocksmith 2014 Edition  Remastered  HAIM - The Wire - Rocksmith® 2014 Edition – Remastered – HAIM - “The Wire” Depot
addappid(1122623, 1, "ae3594a95b324709559278f28259513dd17c551ea083e8a6b8aab6a8a1497c1a") -- Rocksmith 2014 Edition  Remastered  HAIM - Forever - Rocksmith® 2014 Edition – Remastered – HAIM - “Forever” Depot
addappid(1122624, 1, "f216f0b88cf932e1fe18d1ca5d893a66713f369d98d2dca8f3a779f83670d0dd") -- Rocksmith 2014 Edition  Remastered  HAIM - Dont Save Me - Rocksmith® 2014 Edition – Remastered – HAIM - “Don’t Save Me” Depot
addappid(1122626, 1, "2b6172baba6dbcab316475d9cbf2e1a2a38cda8918699f4b2e4b1232ab421936") -- Rocksmith 2014 Edition  Remastered  Great White - House of Broken Love - Rocksmith® 2014 Edition – Remastered – Great White - “House of Broken Love” Depot
addappid(1122627, 1, "8865b33e029f026354c603645faa1563fa861ef571856485a4e17bb97b478f4d") -- Rocksmith 2014 Edition  Remastered  Great White - Rock Me - Rocksmith® 2014 Edition – Remastered – Great White - “Rock Me” Depot
addappid(1122628, 1, "ff1c6bca5e204eeecc561348c3d5e7925c82c6cf7de8d87fc4da1501274fe757") -- Rocksmith 2014 Edition  Remastered  Great White - Once Bitten, Twice Shy - Rocksmith® 2014 Edition – Remastered – Great White - “Once Bitten, Twice Shy” Depot
addappid(1122630, 1, "2fa21c11b23e163f5029d6625aaa64b91fbf2371c8a559138389a2c3342a152e") -- Rocksmith 2014 Edition  Remastered  Stevie Wonder - Superstition - Rocksmith® 2014 Edition – Remastered – Stevie Wonder - “Superstition” Depot
addappid(1122631, 1, "8d1cd596df9774a6add1d314f0c96dce378920990b9ab857080bc575a2208822") -- Rocksmith 2014 Edition  Remastered  Stevie Wonder - Signed, Sealed, Delivered Im Yours - Rocksmith® 2014 Edition – Remastered – Stevie Wonder - “Signed, Sealed, Delivered I’m Yours” Depot
addappid(1122632, 1, "f448f542d261cfc98aeb5cde454b8ac59a32aa617b401fd5224de23fe52d71a6") -- Rocksmith 2014 Edition  Remastered  Stevie Wonder - I Wish - Rocksmith® 2014 Edition – Remastered – Stevie Wonder - “I Wish” Depot
addappid(1122634, 1, "b1b7678d4b2dcc9713784fff99061daf1d2f508473e3268c72f559bbd469c20d") -- Rocksmith 2014 Edition  Remastered  Green Day - Brain Stew - Rocksmith® 2014 Edition – Remastered – Green Day - “Brain Stew” Depot
addappid(1122635, 1, "853073ecbf46e750f5e293709cdd53b6518e5b5565e4dc1a8214c5384043ff0d") -- Rocksmith 2014 Edition  Remastered  Green Day - Father of All... - Rocksmith® 2014 Edition – Remastered – Green Day - “Father of All...” Depot
addappid(1122636, 1, "21c235e152f137937f4200d66f807cbf831402835b021ceebe01f8664fdea7d8") -- Rocksmith 2014 Edition  Remastered  Green Day - Fire, Ready, Aim - Rocksmith® 2014 Edition – Remastered – Green Day - “Fire, Ready, Aim” Depot
addappid(1122638, 1, "3e63e3fe36f3069c5f7a64b468e582b2aa8e6719d2d88decc750eae593e6f943") -- Rocksmith 2014 Edition  Remastered  L7 - Pretend Were Dead - Rocksmith® 2014 Edition – Remastered – L7 - “Pretend We’re Dead” Depot
addappid(1122639, 1, "d339b995d470d1d800b7397c2d02982bb3c114a774138cf53dd4e0e1bd0b7e53") -- Rocksmith 2014 Edition  Remastered  Sleater-Kinney - Dig Me Out - Rocksmith® 2014 Edition – Remastered – Sleater-Kinney - “Dig Me Out” Depot
addappid(1122640, 1, "a10ee8021279b72ec72aeeb5b784a3d2a20a1d8d4f97c90e15b53372fa30f6cc") -- Rocksmith 2014 Edition  Remastered  Babes in Toyland - Bruise Violet - Rocksmith® 2014 Edition – Remastered – Babes in Toyland - “Bruise Violet” Depot
addappid(1122642, 1, "cbaec8dfdc5e52ebcf12e0c6779ecd521ebf2f440531d22ae4fd076df3fc9555") -- Rocksmith 2014 Edition  Remastered  Sevendust - Black - Rocksmith® 2014 Edition – Remastered – Sevendust - “Black” Depot
addappid(1122643, 1, "376bd00a2ee20af2863310f177f443f3fe6d8891f810b36259554d76a1243acd") -- Rocksmith 2014 Edition  Remastered  Sevendust - Angels Son - Rocksmith® 2014 Edition – Remastered – Sevendust - “Angel’s Son” Depot
addappid(1122644, 1, "01dbacc55cd2c3de608c685aad07be6101a0b8166370dc8a98190d7d7ab1ea42") -- Rocksmith 2014 Edition  Remastered  Sevendust - Praise - Rocksmith® 2014 Edition – Remastered – Sevendust - “Praise” Depot
addappid(1122646, 1, "8301cbea347a1ce31c94fa59e74de7a337bc687c5d55d9021c489c23ec67f800") -- Rocksmith 2014 Edition  Remastered  Melissa Etheridge - Im the Only One - Rocksmith® 2014 Edition – Remastered – Melissa Etheridge - “I’m the Only One” Depot
addappid(1122647, 1, "fb15e3b4413df645443e6c527f0ca83a8a152c83e88aa1f5f6c47c4ae58abe74") -- Rocksmith 2014 Edition  Remastered  Melissa Etheridge - Come to My Window - Rocksmith® 2014 Edition – Remastered – Melissa Etheridge - “Come to My Window” Depot
addappid(1122648, 1, "d96ea1670e83f9afeab47dedd6c2e84f64aa21c1b734fb6cb94a68eafdacf0c8") -- Rocksmith 2014 Edition  Remastered  Melissa Etheridge - I Want to Come Over - Rocksmith® 2014 Edition – Remastered – Melissa Etheridge - “I Want to Come Over” Depot
addappid(1122650, 1, "ece34154e6e04569b0597f49cbf9d87f089725c54c6054c0e794ae35b56af366") -- Rocksmith 2014 Edition  Remastered  SixxA.M. - Life Is Beautiful - Rocksmith® 2014 Edition – Remastered – Sixx:A.M. - “Life Is Beautiful” Depot
addappid(1122651, 1, "25632d6fd73080360b1661738cd8176c21a78666cb28d6bded0b21364528d937") -- Rocksmith 2014 Edition  Remastered  SixxA.M. - This Is Gonna Hurt - Rocksmith® 2014 Edition – Remastered – Sixx:A.M. - “This Is Gonna Hurt” Depot
addappid(1122652, 1, "ffe9ff9769a8eb546152909664a353bd5686cfed3daa3c2fe8c0b60ab01fab46") -- Rocksmith 2014 Edition  Remastered  SixxA.M. - Stars - Rocksmith® 2014 Edition – Remastered – Sixx:A.M. - “Stars” Depot
addappid(1122654, 1, "25aa2ed3c0fddd554745b6389445053c12255cfeefc168ab4db75be68ccf8caa") -- Rocksmith 2014 Edition  Remastered  George Benson - Breezin - Rocksmith® 2014 Edition – Remastered – George Benson - “Breezin’” Depot
addappid(1122655, 1, "484b1f1f6cf61ff8fc30843742d106aa65ac49559f12c4427b453fd664edac44") -- Rocksmith 2014 Edition  Remastered  Chicago - Saturday in the Park - Rocksmith® 2014 Edition – Remastered – Chicago - “Saturday in the Park” Depot
addappid(1122656, 1, "de6e8f86a008170e9586c9fb80ffcbb3a36a3e69b23a1e1d648c7f051109e5c5") -- Rocksmith 2014 Edition  Remastered  Carly Simon - Youre So Vain - Rocksmith® 2014 Edition – Remastered – Carly Simon - “You’re So Vain” Depot
addappid(1122658, 1, "c448cd6ebc9049ae5ec3bfc4998f4a5e8dea93aa0c0ad3af69b67d8db930a8a7") -- Rocksmith 2014 Edition  Remastered  Janis JoplinBig Brother  The Holding Co. - Piece of My Heart - Rocksmith® 2014 Edition – Remastered – Janis Joplin/Big Brother &amp; The Holding Co. - “Piece of My Heart” Depot
addappid(1122659, 1, "6bc31c4800ca2c42302a202b1024ed7d6d8093c74cd0f4322a7181612f15cd45") -- Rocksmith 2014 Edition  Remastered  Janis Joplin - Me and Bobby McGee - Rocksmith® 2014 Edition – Remastered – Janis Joplin - “Me and Bobby McGee” Depot
addappid(1122660, 1, "3943a44b3553ccf9b58ccf5a19e689c7589f0678128c8242594ad99962c0acb3") -- Rocksmith 2014 Edition  Remastered  Janis JoplinBig Brother  The Holding Co. - Summertime - Rocksmith® 2014 Edition – Remastered – Janis Joplin/Big Brother &amp; The Holding Co. - “Summertime” Depot
addappid(1122662, 1, "f1d312d7c526463c5e520b16bdac43dc83f202bc5e1faf049e3de93f69df41c5") -- Rocksmith 2014 Edition  Remastered  Opeth - Blackwater Park - Rocksmith® 2014 Edition – Remastered – Opeth - “Blackwater Park” Depot
addappid(1122663, 1, "c3a7bebc596bf51a59ceea02f97cb1f4a1b23897d824801463ca459ab71e3f86") -- Rocksmith 2014 Edition  Remastered  Opeth - Bleak - Rocksmith® 2014 Edition – Remastered – Opeth - “Bleak” Depot
addappid(1122664, 1, "5d4c488f4e201ef94b3ff33d2a4cfa54b50595df64aa82154192d22c7b0c019b") -- Rocksmith 2014 Edition  Remastered  Opeth - Ghost of Perdition - Rocksmith® 2014 Edition – Remastered – Opeth - “Ghost of Perdition” Depot

