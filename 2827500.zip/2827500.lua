-- Generated with Luie @ https://lua.tools/
-- 2827500 - Hentai Milf
-- Generated 2026-08-17 06:41:34 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(2827500)

-- Main Depots
addappid(2827501, 1, "20a53c33547ec66eb054ee7a73fa367f73ff5036db37200b3deb325b42bab72b")
setManifestid(2827501, "3172343828538686218", 413696523)

-- DLC's (no depot keys required)
addappid(3429790) -- Hentai Milf - Arts
