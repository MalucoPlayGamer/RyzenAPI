-- Lua provided by RyzenAPI
-- Game: Hentai Milf

-- MAIN APPLICATION
addappid(2827500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827501, 1, "20a53c33547ec66eb054ee7a73fa367f73ff5036db37200b3deb325b42bab72b")

