-- Lua provided by RyzenAPI
-- Game: Selatria: Advent of the Dakk'rian Empire

-- MAIN APPLICATION
addappid(578890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(578891, 1, "95d7becbcb325e1480e540d48f930f1e7914ac9baeec81367ad025642a3ba1bb")
addappid(578893, 1, "c49553152f0087216dd15d6597257284a671973562fcdff728c4154759dbb689")
