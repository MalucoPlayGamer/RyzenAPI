-- Lua provided by RyzenAPI 
-- Game: AppID 578890
addappid(578890)
addappid(578891, 1, "95d7becbcb325e1480e540d48f930f1e7914ac9baeec81367ad025642a3ba1bb")
addappid(578893, 1, "c49553152f0087216dd15d6597257284a671973562fcdff728c4154759dbb689")
