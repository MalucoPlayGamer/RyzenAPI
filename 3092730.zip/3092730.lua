-- Lua provided by RyzenAPI
-- Game: Bloomtown: A Different Story Supporter pack - OST & Arts

-- MAIN APPLICATION
addappid(3092730)
-- Game: addappid(3092730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092732,0,"7ec1c22600ccd3d829a8171d6846a46af584df67168afbb2f91b2e7b0319faae")
addappid(3092733,0,"c83eeb7839e4fae0a52bc3e489c7b918979ea0e6d68d087699a5982dd5395a84")
