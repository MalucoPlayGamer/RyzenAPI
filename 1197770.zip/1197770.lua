-- Lua provided by RyzenAPI
-- Game: AppID 1197770

-- MAIN APPLICATION
addappid(1197770)
-- Game: addappid(1197770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197771, 1, "d395c2bf786c7e845028197542c7d0af5913874e36d7f5ec6813de78ecd7c503")
