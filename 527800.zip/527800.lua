-- Lua provided by RyzenAPI
-- Game: addappid(527800)

-- MAIN APPLICATION
addappid(527800)

-- MAIN APP DEPOTS / PACKAGES
addappid(527801, 1, "8a1040a0cef27167626717adab9cf292e99cd1b4c3f58da1d829a9a1c86328a8")
