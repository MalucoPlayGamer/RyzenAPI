-- Lua provided by RyzenAPI
-- Game: Bank Robber

-- MAIN APPLICATION
addappid(1990270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990271, 1, "c81a7231ff5f01518e9618229833d37674a5f0ba2b4e5f97b165e13fe3b4791b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
