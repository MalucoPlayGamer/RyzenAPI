-- Lua provided by RyzenAPI
-- Game: Bank Robber

-- MAIN APPLICATION
addappid(1990270)
-- Game: addappid(1990270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990271, 1, "c81a7231ff5f01518e9618229833d37674a5f0ba2b4e5f97b165e13fe3b4791b")
