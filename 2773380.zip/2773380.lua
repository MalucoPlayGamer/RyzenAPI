-- Lua provided by RyzenAPI 
-- Game: AppID 2773380
addappid(2773380)
addappid(2773381, 1, "8a01e99931792044ef4b87d3830a2c02c67fabf3c3d1f8d5c3f685bc5abca678")
