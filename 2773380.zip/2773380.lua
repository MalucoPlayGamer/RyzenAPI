-- Lua provided by RyzenAPI
-- Game: 2773380

-- MAIN APPLICATION
addappid(2773380)
-- Game: addappid(2773380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773381, 1, "8a01e99931792044ef4b87d3830a2c02c67fabf3c3d1f8d5c3f685bc5abca678")
