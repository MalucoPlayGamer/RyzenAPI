-- Lua provided by RyzenAPI
-- Game: The Tenants - Free Trial

-- MAIN APPLICATION
addappid(1546540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546541, 1, "f04d5953ce7e4e7dd2cec713bde27cd31a49c281b52d518b844b13490a74b4de")
