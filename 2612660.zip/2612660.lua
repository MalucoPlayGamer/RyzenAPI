-- Lua provided by RyzenAPI
-- Game: Kamaitachi no Yoru x3

-- MAIN APPLICATION
addappid(2612660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612661, 1, "f78b00b3d1227cb6467095f86c4aa6977b08581f814bfb137bb0f1f2836d93a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
