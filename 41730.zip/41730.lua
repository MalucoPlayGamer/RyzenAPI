-- Lua provided by RyzenAPI
-- Game: Ion Assault

-- MAIN APPLICATION
addappid(41730)

-- MAIN APP DEPOTS / PACKAGES
addappid(41731, 1, "895fcf12fa93ea0bc2dce5ba443f6018f5263975518af58159e3065eb8fd9e7c")
