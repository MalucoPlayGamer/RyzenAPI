-- Lua provided by RyzenAPI
-- Game: Last Stanza

-- MAIN APPLICATION
addappid(835130)

-- MAIN APP DEPOTS / PACKAGES
addappid(835131, 1, "a706e2e729b6c74afca6ba075399d20fd28b4de18604fa69040d18b754dceae9")
