-- Lua provided by SkyAPI 
-- Game: Last Stanza
addappid(835130)
addappid(835131, 1, "a706e2e729b6c74afca6ba075399d20fd28b4de18604fa69040d18b754dceae9")
