-- Lua provided by RyzenAPI
-- Game: AppID 240460

-- MAIN APPLICATION
addappid(240460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(240461, 1, "fa8c39c3f2f4501263bc558ab8e643f60b29f570bfc26dde695d8255ecb64b98")

