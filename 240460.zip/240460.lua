-- Lua provided by RyzenAPI
-- Game: AppID 240460

-- MAIN APPLICATION
addappid(240460)

-- MAIN APP DEPOTS / PACKAGES
addappid(240461, 1, "fa8c39c3f2f4501263bc558ab8e643f60b29f570bfc26dde695d8255ecb64b98")
