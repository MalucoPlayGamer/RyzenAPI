-- Lua provided by RyzenAPI 
-- Game: World Cruise Story
addappid(2019360)
addappid(2019361, 1, "936a788c625c9fec28e56ebb54133191422f4997bc02281db99519032c77073a")
