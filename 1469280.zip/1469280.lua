-- Lua provided by RyzenAPI 
-- Game: SuchArt: Creative Space
addappid(1469280)
addappid(1469281, 1, "19c7916a149f4c8ef28d06ffede21559c8c79db94c0b689d6cb031972ecaa0e5")
