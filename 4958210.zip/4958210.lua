-- 4958210's Lua and Manifest Created by Hubcap Manifest
-- Pet Diary
-- Created: August 16, 2026 at 12:07:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4958210) -- Pet Diary
addtoken(4958210, "18115736811539269362")
-- MAIN APP DEPOTS
addappid(4958211, 1, "861ab279b34f2e3155ab25017a7080a29ed850497bca3398fb7722e2ad13a2ad") -- Depot 4958211
setManifestid(4958211, "1217299693366455236", 298283357)