-- Lua provided by RyzenAPI
-- Game: Pet Diary

-- MAIN APPLICATION
addappid(4958210) -- Pet Diary

-- MAIN APP DEPOTS / PACKAGES
addappid(4958211, 1, "861ab279b34f2e3155ab25017a7080a29ed850497bca3398fb7722e2ad13a2ad") -- Depot 4958211
addtoken(4958210, "18115736811539269362")

