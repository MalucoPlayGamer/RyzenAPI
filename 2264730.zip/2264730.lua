-- Lua provided by RyzenAPI
-- Game: addappid(2264730)

-- MAIN APPLICATION
addappid(2264730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264731, 1, "1692dbd1b3fc531a148b2278f61912b77b7e08b15b00ebb475a952f700da27ac")
