-- Lua provided by RyzenAPI 
-- Game: AppID 16600
addappid(16600)
addappid(16601, 1, "48724aadc3e8198d1d0cc0adc0ae21ca55bff7e9d752a5e09886273ed919b333")
