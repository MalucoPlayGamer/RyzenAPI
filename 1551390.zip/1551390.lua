-- Lua provided by RyzenAPI
-- Game: FUSER™ - Darude - "Sandstorm"

-- MAIN APPLICATION
addappid(1551390)
-- Game: addappid(1551390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551390,0,"36b6d61e534143638b7a7d86d98aea96494f5355e5a31a7ea2067746df7bd37b")
