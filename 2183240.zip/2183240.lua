-- Lua provided by RyzenAPI
-- Game: SUKUR

-- MAIN APPLICATION
addappid(2183240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183241, 1, "c2794a9eebaceb370bbd8d35d4a30c9c1e7876a19f610c8c0842a9b0652a8db6")

