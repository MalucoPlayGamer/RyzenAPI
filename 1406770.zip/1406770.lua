-- Lua provided by RyzenAPI
-- Game: Evil Icebox

-- MAIN APPLICATION
addappid(1406770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1406771, 1, "1408fac5b56b8069e68f4ce2f0bb3081132f754eea39f6357dc32bba133bbd6b")

