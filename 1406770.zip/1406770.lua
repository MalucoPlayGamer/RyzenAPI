-- Lua provided by RyzenAPI
-- Game: addappid(1406770)

-- MAIN APPLICATION
addappid(1406770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406771, 1, "1408fac5b56b8069e68f4ce2f0bb3081132f754eea39f6357dc32bba133bbd6b")
