-- Lua provided by RyzenAPI
-- Game: World of Warships

-- MAIN APPLICATION
addappid(552990)
-- Game: addappid(552990)

-- MAIN APP DEPOTS / PACKAGES
addappid(552991, 1, "6ea374043631e71d0558d60e0a0a1b581c6a53b048b56d68057fd0b1a1c3fc41")
addappid(552992, 1, "6d995cdbd2ab17ee64c0859f971fc48af9901a0a75fb3ba70b96562ab5165e6c")
addappid(552993, 1, "a4ac589393a2c8679c1f99b2e6fcee10554c030a0a6bf69bd4e22a13da7aab55")
addappid(552994, 1, "25d3f6b29f4cc6dda30b84f0e558ed4e35d36d3f673e423ab9ab2a63fa8094dc")
addappid(552996, 1, "2aef04a277208797997c7cf562c65036561a96c838a8f3ef68d7f23c95a860f4")
