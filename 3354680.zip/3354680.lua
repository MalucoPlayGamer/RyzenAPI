-- Lua provided by RyzenAPI
-- Game: Beat Saber - Metallica - "One"

-- MAIN APPLICATION
addappid(3354680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354680,0,"db60d605031c25897883d11ce16cd83a4e7f1870accc42c3032b4f2e28c62827")
