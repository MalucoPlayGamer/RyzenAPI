-- Lua provided by RyzenAPI
-- Game: Axe Girl

-- MAIN APPLICATION
addappid(1267130)
-- Game: addappid(1267130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267131, 1, "ab8c6baba6a3e25d1853436c2d0231012099b489638cbae4971e8007d99cca90")
