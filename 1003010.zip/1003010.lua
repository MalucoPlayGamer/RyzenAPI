-- Lua provided by RyzenAPI
-- Game: AppID 1003010

-- MAIN APPLICATION
addappid(1003010)
-- Game: addappid(1003010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003011, 1, "080dca0370622fff9fe16122c231e71ce64d9107324ee45da58fbe6dc6b9157e")
