-- Lua provided by RyzenAPI
-- Game: Game: 前進吧！高捷少女Initiating Station PLUS

-- MAIN APPLICATION
addappid(1250770)
-- Game: addappid(1250770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250771, 1, "a40bf4535ab033ececc173fadd860cd9c8e49f1c2b70ea10091214315eb9b2c0")
