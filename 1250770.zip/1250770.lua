-- Lua provided by SkyAPI 
-- Game: 前進吧！高捷少女Initiating Station PLUS
addappid(1250770)
addappid(1250771, 1, "a40bf4535ab033ececc173fadd860cd9c8e49f1c2b70ea10091214315eb9b2c0")
