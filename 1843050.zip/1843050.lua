-- Lua provided by RyzenAPI
-- Game: Game: Rambell

-- MAIN APPLICATION
addappid(1843050)
-- Game: addappid(1843050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843051, 1, "8f39063a3c9738452496bd0774030a53fd45d4e6f23414175df2705a7800e371")
