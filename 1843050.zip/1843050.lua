-- Lua provided by RyzenAPI
-- Game: Rambell

-- MAIN APPLICATION
addappid(1843050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843051, 1, "8f39063a3c9738452496bd0774030a53fd45d4e6f23414175df2705a7800e371")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
