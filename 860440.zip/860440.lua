-- Lua provided by RyzenAPI
-- Game: Goat Life

-- MAIN APPLICATION
addappid(860440)

-- MAIN APP DEPOTS / PACKAGES
addappid(860441, 1, "968a2deae28bb3ab130791da526c9434eab8136c45161294bf39849a2676fdc1")
