-- Lua provided by SkyAPI 
-- Game: Whisperwind
addappid(1501650)
addappid(1501651, 1, "2c9df0e36960070a72c2d30cdd3f78392f687aa631135e9dfb894d193cdd8600")
