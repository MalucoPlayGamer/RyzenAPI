-- Lua provided by RyzenAPI
-- Game: addappid(1501650)

-- MAIN APPLICATION
addappid(1501650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501651, 1, "2c9df0e36960070a72c2d30cdd3f78392f687aa631135e9dfb894d193cdd8600")
