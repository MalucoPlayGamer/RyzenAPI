-- Lua provided by RyzenAPI
-- Game: 1159360

-- MAIN APPLICATION
addappid(1159360)
-- Game: addappid(1159360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159361, 1, "68fd8ce619f4d8641c58897cd7a22c44534fa818e7d4ee428de19704ada4fbc6")
