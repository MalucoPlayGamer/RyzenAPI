-- Lua provided by RyzenAPI
-- Game: Shatris: Infinite Puzzles

-- MAIN APPLICATION
addappid(1301830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301831, 1, "0562557a04fa147a9d4000613a2927101823d92405018c53fc8d73927c5ab725")
