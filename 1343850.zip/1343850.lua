-- Lua provided by RyzenAPI
-- Game: 1343850

-- MAIN APPLICATION
addappid(1343850)
-- Game: addappid(1343850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343851, 1, "d29c899d82dd45ab23130efca8518bc26981103169a0868782d8c26e6eff6be7")
