-- Lua provided by SkyAPI 
-- Game: AppID 1995870
addappid(1995870)
addappid(1995871, 1, "13d607bf92e2630f7ae4a2a2da8dd771c2d1780d157697ce36199842600e94ec")
