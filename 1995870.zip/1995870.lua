-- Lua provided by RyzenAPI
-- Game: 1995870

-- MAIN APPLICATION
addappid(1995870)
-- Game: addappid(1995870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995871, 1, "13d607bf92e2630f7ae4a2a2da8dd771c2d1780d157697ce36199842600e94ec")
