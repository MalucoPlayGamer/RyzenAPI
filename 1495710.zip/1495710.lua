-- Lua provided by RyzenAPI
-- Game: Cyberpunk 2077 Bonus Content

-- MAIN APPLICATION
addappid(1495710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495710,0,"d1eee983c6b6dc175c3ec89ae337fe4e4435d19bf689ed1607e19f0887ca1e3c")
addtoken(1495710,"13440227389371067611")

