-- Lua provided by RyzenAPI
-- Game: Snakest

-- MAIN APPLICATION
addappid(940350)
addappid(940370)

-- MAIN APP DEPOTS / PACKAGES
addappid(940351, 1, "ae89e70fae8f7ad0f6b0196658a321318c5387ea125955e62c87c2ffadb82a13")

