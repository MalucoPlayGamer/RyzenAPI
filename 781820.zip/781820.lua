-- Lua provided by RyzenAPI
-- Game: AppID 781820

-- MAIN APPLICATION
addappid(781820)
addappid(883640)

-- MAIN APP DEPOTS / PACKAGES
addappid(781821, 1, "713de9debcc444b5bc807a16fc45be598ca885917a08681787a57c5c2fe9c00b")

