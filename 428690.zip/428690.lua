-- Lua provided by RyzenAPI
-- Game: Youtubers Life

-- MAIN APPLICATION
addappid(428690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(428691, 1, "c2886d221f990c67c34644bff6ca0f1d10fecc5c6de3b179594ae071bcdb6504")
addappid(428692, 1, "203f5d73e5428d2b13075ecc3056ed38d11baf0d03d2edc4b46ca48a756882a1")
addappid(428693, 1, "4675d3db6afb9c4cd216e57abea57b77f0c3fffff283ba86de7c7b750c651e15")
