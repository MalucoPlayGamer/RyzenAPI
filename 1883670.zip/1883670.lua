-- Lua provided by RyzenAPI
-- Game: Race On Ice 2022 Pro

-- MAIN APPLICATION
addappid(1883670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883671, 1, "85ae4cd994faab057bd80010c319b8768d47a4243f866348ca4146c05a4d406d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
