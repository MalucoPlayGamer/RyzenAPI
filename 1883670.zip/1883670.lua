-- Lua provided by RyzenAPI
-- Game: Game: Race On Ice 2022 Pro

-- MAIN APPLICATION
addappid(1883670)
-- Game: addappid(1883670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883671, 1, "85ae4cd994faab057bd80010c319b8768d47a4243f866348ca4146c05a4d406d")
