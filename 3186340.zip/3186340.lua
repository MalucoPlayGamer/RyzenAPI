-- Lua provided by RyzenAPI
-- Game: STAaRS

-- MAIN APPLICATION
addappid(3186340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3186341, 1, "6223be8bd744a8b1bc5b67796dbe7fe2017600cf25545c33742563354b8dae77")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
