-- Lua provided by RyzenAPI
-- Game: Game: STAaRS

-- MAIN APPLICATION
addappid(3186340)
-- Game: addappid(3186340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3186341, 1, "6223be8bd744a8b1bc5b67796dbe7fe2017600cf25545c33742563354b8dae77")
