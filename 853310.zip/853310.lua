-- Lua provided by RyzenAPI
-- Game: Game: AppID 853310

-- MAIN APPLICATION
addappid(853310)
-- Game: addappid(853310)

-- MAIN APP DEPOTS / PACKAGES
addappid(853311, 1, "098ca944b38d023024886d9e36d106723f7b345416c5c14a8a5991de2fba1060")
