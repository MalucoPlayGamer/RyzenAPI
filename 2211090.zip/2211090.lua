-- Lua provided by SkyAPI 
-- Game: Villain's Legacy
addappid(2211090)
addappid(2211091, 1, "297bfc69d5df2291218da1d0208c439513b909293fea64d9eecc1f4e3becc717")
