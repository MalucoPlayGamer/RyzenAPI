-- Lua provided by RyzenAPI
-- Game: Villain's Legacy

-- MAIN APPLICATION
addappid(2211090)
-- Game: addappid(2211090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211091, 1, "297bfc69d5df2291218da1d0208c439513b909293fea64d9eecc1f4e3becc717")
