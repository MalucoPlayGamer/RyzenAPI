-- Lua provided by RyzenAPI
-- Game: Swan Song

-- MAIN APP DEPOTS / PACKAGES
addappid(3265290, 1, "19812713fb59da294623e7f81d2936c56c41f886f71dd92d817375db6052b91b") -- Swan Song
addappid(3265291, 1, "9fcc34a891e862174a1f976675f0ed6d433ba89ff5b95a01d611b6fd9f286a1d") -- Depot 3265291
addappid(3265292, 1, "fa3ff258d4572df83f86e921e322c13333dfdf254cdc8e12bd09effb4da1fecf") -- Depot 3265292

