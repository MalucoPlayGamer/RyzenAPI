-- Lua provided by RyzenAPI
-- Game: setManifestid(773712,"8674119402813179945")

-- MAIN APPLICATION
addappid(773710)

-- MAIN APP DEPOTS / PACKAGES
addappid(773712,0,"dfa7edc9f98c554f9ab8aa7aee8af4d6c6f3162cf9852e6fd62a6d25faf9b082")

