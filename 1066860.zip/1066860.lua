-- Lua provided by RyzenAPI
-- Game: RPG Paper Maker

-- MAIN APPLICATION
addappid(1066860)
-- Game: addappid(1066860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066861, 1, "17c0d258b2c85ec663fbfb30dd2b0f961520edac528131c63b7f646799774a86")
addappid(1066862, 1, "e465acb9dc188ff900dcb7b516d70718a73847e7afe08d49a5137c472210cf84")
addappid(1066863, 1, "911fdaf4118bb32d851e016e5d45b607393bcbba959c8a9cfc411b25ddb2233a")
