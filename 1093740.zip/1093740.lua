-- Lua provided by RyzenAPI
-- Game: 1093740

-- MAIN APPLICATION
addappid(1093740)
-- Game: addappid(1093740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093741, 1, "b5412e46bbc207cafc3c146d7af81ea39c2b2a7a36cd23d40009a1a57f90277a")
