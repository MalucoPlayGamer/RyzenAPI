-- Lua provided by RyzenAPI
-- Game: Game: AppID 2893970

-- MAIN APPLICATION
addappid(2893970)
-- Game: addappid(2893970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893971, 1, "c968d9a870c2524570b7bf0114bbd6c4c9ccb3f6aab67fdb46a6eb1bc389cc2e")
addappid(2893972, 1, "ea8b900051231ef2765e2bc6347fee4e631ef86074cf2ad798c2ab65ffff1f9d")
addappid(2893973, 1, "c33aeb412f4d4a66577a300fcad293ca13559bed5049cebeee0cae7c00b0acc8")
addappid(2893974, 1, "ed9abdba6fca1fe9094eb9ad5bc69f1aada2b29bf858e8983b09ca7046409725")
addappid(2893975, 1, "1ff3f3789214439f06267d81c18aec695c2203239fbf4531bef2c6c8188035cb")
addappid(2893976, 1, "4a6a3a47ceca2f40c0786cada1269e724484b4592100f25c7fe18d17def1b72e")
