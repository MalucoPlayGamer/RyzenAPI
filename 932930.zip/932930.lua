-- Lua provided by RyzenAPI
-- Game: Sexy Girls Puzzle

-- MAIN APPLICATION
addappid(932930)

-- MAIN APP DEPOTS / PACKAGES
addappid(932931, 1, "434c88a74b272534670036e425bf97593fbdc73b534c95ec573e80d73391d3f0")
