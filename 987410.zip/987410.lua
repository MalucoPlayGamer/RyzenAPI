-- Lua provided by RyzenAPI
-- Game: AppID 987410

-- MAIN APPLICATION
addappid(987410)

-- MAIN APP DEPOTS / PACKAGES
addappid(987411, 1, "e0ee1ddfeb4027f702910072b747bd58b7b7fe5bb47be82691d3fddce52ebe7c")

