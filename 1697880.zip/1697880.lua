-- Lua provided by RyzenAPI
-- Game: Game: Junkyard Truck

-- MAIN APPLICATION
addappid(1697880)
-- Game: addappid(1697880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697881, 1, "145e46e146327ae397ce387e8b18739c46642a40de020b99c14e7a434211d2dc")
