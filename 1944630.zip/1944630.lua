-- Lua provided by RyzenAPI
-- Game: Game: Katana Rama

-- MAIN APPLICATION
addappid(1944630)
-- Game: addappid(1944630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944631, 1, "b3e4ad75646a7dbbcad4ba48ba553196b31ce732db6f5f6144794e57dd2987ed")
