-- Lua provided by RyzenAPI 
-- Game: The Catacombs of Solaris Revisited
addappid(1532250)
addappid(1532251, 1, "7138c05bffae10cf67c4af795e5c112026d7cb5768fd1f482e4362f3c83a0a51")
