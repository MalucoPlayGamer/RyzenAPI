-- Lua provided by RyzenAPI
-- Game: The Catacombs of Solaris Revisited

-- MAIN APPLICATION
addappid(1532250)
-- Game: addappid(1532250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532251, 1, "7138c05bffae10cf67c4af795e5c112026d7cb5768fd1f482e4362f3c83a0a51")
