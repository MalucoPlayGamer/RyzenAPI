-- Lua provided by RyzenAPI
-- Game: Prank Call

-- MAIN APPLICATION
addappid(1442480)
-- Game: addappid(1442480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442481, 1, "0b170b30c43bb22ff2a7503782854a1d8695615188e3b8e52249718584c7e9cd")
addappid(1442482, 1, "fb6f07af4871c53f1ae1bb5c2f19f6718808f72b6defcfc1e32439a9593488a1")
