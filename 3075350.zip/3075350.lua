-- Lua provided by RyzenAPI
-- Game: Game: Pickle

-- MAIN APPLICATION
addappid(3075350)
-- Game: addappid(3075350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075351, 1, "3dc555484ce6c3c90e21292082afc0504b9ff93b56766a59b724c287351c07a4")
