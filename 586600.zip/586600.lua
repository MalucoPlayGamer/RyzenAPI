-- Lua provided by RyzenAPI
-- Game: Game: The Adventures of Fluffy

-- MAIN APPLICATION
addappid(586600)
-- Game: addappid(586600)

-- MAIN APP DEPOTS / PACKAGES
addappid(586601, 1, "6abdc785d7402986812c35c7ccd0aaaf9143469a013f383ff5ebbe1a855836e3")
