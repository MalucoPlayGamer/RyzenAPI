-- Lua provided by RyzenAPI
-- Game: 20.000 Leagues Under The Sea - Captain Nemo

-- MAIN APPLICATION
addappid(821720)

-- MAIN APP DEPOTS / PACKAGES
addappid(821721, 1, "27185bd8220f0f80023f6506ed0dad1600edb5d614a9fecf9bd2d9373bcd3855")