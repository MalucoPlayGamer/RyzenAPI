-- Lua provided by RyzenAPI
-- Game: Vector

-- MAIN APPLICATION
addappid(248970)

-- MAIN APP DEPOTS / PACKAGES
addappid(248971, 1, "927b0e6e5f7e084b4756d55b26efbcf4fd533068d9418e33353e3b5fe9749e14")
