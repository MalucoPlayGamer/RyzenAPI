-- Lua provided by RyzenAPI
-- Game: 2277660

-- MAIN APPLICATION
addappid(2277660)
-- Game: addappid(2277660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277661, 1, "04e3eb9c6411a79a10da4055f538d9a7a33d37ee8867ea8ea3521dba3881c280")
