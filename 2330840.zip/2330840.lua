-- Lua provided by RyzenAPI
-- Game: addappid(2330840)

-- MAIN APPLICATION
addappid(2330840)
addappid(2330841)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330840,0,"7c5b2b7ba9c07643ce094d65b14d946c1135498f531502c32bf49e007ecc7555")
