-- Lua provided by RyzenAPI
-- Game: One More Delve

-- MAIN APPLICATION
addappid(3847110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3847111,0,"d20b77013c032fa25e4709053b1b05232f57b6627a399dbe57684e71e47067bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
