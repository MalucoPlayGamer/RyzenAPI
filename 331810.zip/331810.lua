-- Lua provided by RyzenAPI
-- Game: AppID 331810

-- MAIN APPLICATION
addappid(331810)

-- MAIN APP DEPOTS / PACKAGES
addappid(331811, 1, "9a2dabb15be3b857f2e66a1ebe8ed08f8977f938d5b391f0e81092b64f1070b9")
