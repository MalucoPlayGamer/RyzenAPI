-- Lua provided by SkyAPI 
-- Game: AppID 331810
addappid(331810)
addappid(331811, 1, "9a2dabb15be3b857f2e66a1ebe8ed08f8977f938d5b391f0e81092b64f1070b9")
