-- Lua provided by RyzenAPI
-- Game: 東方文花帖 ～ Shoot the Bullet.

-- MAIN APPLICATION
addappid(1420650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1420651, 1, "832b587061efac0c20695b7f193985c39fe5b66e8df28cc27852b62db91587f1")
