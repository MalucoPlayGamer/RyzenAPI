-- Lua provided by RyzenAPI
-- Game: 1420650

-- MAIN APPLICATION
addappid(1420650)
-- Game: addappid(1420650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420651, 1, "832b587061efac0c20695b7f193985c39fe5b66e8df28cc27852b62db91587f1")
