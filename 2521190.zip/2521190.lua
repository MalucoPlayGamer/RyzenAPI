-- Lua provided by RyzenAPI
-- Game: Werelderfgoed: Romeins Aquaduct van Nijmegen en Berg en Dal

-- MAIN APPLICATION
addappid(2521190)
-- Game: addappid(2521190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521191, 1, "4a50bef67ef212fc1d413c755141e6073683c99745550ee118a6165eb2f7a6b4")
