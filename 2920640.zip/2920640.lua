-- Lua provided by RyzenAPI
-- Game: AppID 2920640

-- MAIN APPLICATION
addappid(2920640)
-- Game: addappid(2920640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920641, 1, "ec5d4562d6b80c9ae2300b55003825e58ed8b3c28e30eec6bc4fdb9260db699a")
