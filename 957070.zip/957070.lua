-- Lua provided by RyzenAPI
-- Game: iB Cricket

-- MAIN APPLICATION
addappid(957070)

-- MAIN APP DEPOTS / PACKAGES
addappid(957071, 1, "59d482c8d1adc83bee7527d518714675814f97e341d361f62cab8be33a0da726")

