-- Lua provided by RyzenAPI 
-- Game: Re: Gals Panic
addappid(1154720)
addappid(1154721, 1, "4da3dc73cb65f63b675dc39b9081325a4f37f39c521c5913f4dc8566e521e143")
