-- Lua provided by RyzenAPI
-- Game: Liar Moon Shangri-La

-- MAIN APPLICATION
addappid(1932690)
-- Game: addappid(1932690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932691, 1, "fd139c82ae57c8913eef0a6f44a0cc9fe7a9ac64f6eaed5ae6d2f75070b72fb9")
