-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956705)

-- MAIN APP DEPOTS / PACKAGES
addappid(956705,0,"4084331d93aeef171cd673001ea1e38d6f64f0590e11690cf1246de65310c92c")
