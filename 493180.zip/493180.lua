-- Lua provided by RyzenAPI
-- Game: Dynasty Feud

-- MAIN APPLICATION
addappid(493180)
addappid(723460)

-- MAIN APP DEPOTS / PACKAGES
addappid(493181, 1, "7166f09cca7843ace89283113b1e2260cca1c3ec310fbc59e6894d36bf4d2e47")
addappid(493182, 1, "99da1f22102357aaceca241b8950bd93a948286ccddd34abc007028172e14b7a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
