-- Lua provided by SkyAPI 
-- Game: AppID 1061720
addappid(1061720)
addappid(1061721, 1, "3301bf9764db74523af0bc4b04244346045b8d37388898ee9d6a3e29740473de")
