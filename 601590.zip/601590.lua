-- Lua provided by SkyAPI 
-- Game: BattleTrucks
addappid(601590)
addappid(601591, 1, "1cf6131c4bd8c640c26584383677136adf5afe4efb1975297ff0a6f4f88aa2e1")
addappid(601592, 1, "4feef5399c94f5791c7015f1c79f31d8b99025180dbcbf3faeec695807fb8509")
