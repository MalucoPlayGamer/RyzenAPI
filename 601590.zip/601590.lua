-- Lua provided by RyzenAPI
-- Game: BattleTrucks

-- MAIN APPLICATION
addappid(601590)

-- MAIN APP DEPOTS / PACKAGES
addappid(601591, 1, "1cf6131c4bd8c640c26584383677136adf5afe4efb1975297ff0a6f4f88aa2e1")
addappid(601592, 1, "4feef5399c94f5791c7015f1c79f31d8b99025180dbcbf3faeec695807fb8509")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
