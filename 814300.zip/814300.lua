-- Lua provided by RyzenAPI
-- Game: 814300

-- MAIN APPLICATION
addappid(814300)
-- Game: addappid(814300)

-- MAIN APP DEPOTS / PACKAGES
addappid(814301, 1, "679a2d52ca0d1dff8bf6d8a291abb05b76b1e520bdcf5a3eda86e3ca9e86ebee")
