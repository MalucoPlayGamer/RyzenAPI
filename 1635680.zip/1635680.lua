-- Lua provided by RyzenAPI
-- Game: Palladium: Adventure in Greece Soundtrack

-- MAIN APPLICATION
addappid(1635680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635681, 1, "c451518bc041062f1b019d0209a1433570bad81d27a074931941c8a02280677b")
