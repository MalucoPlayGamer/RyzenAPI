-- Lua provided by RyzenAPI
-- Game: addappid(1833430)

-- MAIN APPLICATION
addappid(1833430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833430,0,"7d6815c38977f2803ce5a2679bfc1818d9a34e26f16afe4eb233ccda46f5c98b")
