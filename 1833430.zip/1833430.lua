-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy Add on Animals 2

-- MAIN APPLICATION
addappid(1833430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833430,0,"7d6815c38977f2803ce5a2679bfc1818d9a34e26f16afe4eb233ccda46f5c98b")

