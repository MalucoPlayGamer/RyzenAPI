-- Lua provided by RyzenAPI
-- Game: Milfylicious - Chapter I

-- MAIN APPLICATION
addappid(3135930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135934,0,"6432b62d9a6c62dcfb83dfac064f9e9731381259b6cc98fac6b3d4d38d748ff7")

