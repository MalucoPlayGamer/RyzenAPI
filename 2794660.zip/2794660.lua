-- Lua provided by RyzenAPI
-- Game: Intergalactic Ecstasy Demo

-- MAIN APPLICATION
addappid(2794660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794661, 1, "22c6e2571c23fb0d8b6117e71f6002631c6cdbf1ed3d41f2bd266ee299a70ab6")

