-- Lua provided by SkyAPI 
-- Game: Rhino's Rage
addappid(433210)
addappid(433211, 1, "8edde3d3b2956c420b96988af16ac72bd12de5c4784dfcddc94bc7e6b5e8b564")
