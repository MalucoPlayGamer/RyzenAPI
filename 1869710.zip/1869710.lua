-- Lua provided by SkyAPI 
-- Game: Invention 3
addappid(1869710)
addappid(1869711, 1, "3f748c6a0adbb804e55fd41b9f3990c9f9a93083d6b77de3c7a78c3f2ab94aeb")
