-- Lua provided by RyzenAPI
-- Game: addappid(1214210)

-- MAIN APPLICATION
addappid(1214210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214211, 1, "fc2c80e6ba09c70e2998592274b3ae2bcb7baa932d84c8d48337af997a7dafda")
