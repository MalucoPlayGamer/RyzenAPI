-- Lua provided by RyzenAPI
-- Game: AppID 1637320

-- MAIN APPLICATION
addappid(1637320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637321, 1, "c0d4d6c5d92ae7a0c63de34717961fde6f236bb14016e43c90d87efc92b5f5c8")
addappid(1637322, 1, "38589513fd71352d7bc7c6fd27896971ac96fc8eab25321af5ba7e0fba053b52")
addappid(1637323, 1, "b8d37f4ec539a4af41019ba11f330f53e08ad9c1ab63517f3972463e86ecf38a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2152440)
addappid(2380060)
addappid(4331610)
