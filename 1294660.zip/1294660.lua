-- Lua provided by RyzenAPI
-- Game: Divine Knockout (DKO)

-- MAIN APPLICATION
addappid(1294660)
addappid(2104030)
addappid(2104040)
addappid(2245970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1294661, 1, "83d760dd993d2c2dbcd973dc03c2e30b5395c9a3451946d61b9e68069142d109")

