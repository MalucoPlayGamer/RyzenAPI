-- Lua provided by RyzenAPI
-- Game: 1253690

-- MAIN APPLICATION
addappid(1253690)
-- Game: addappid(1253690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253691, 1, "749d95f6bb06981f740138285e0c4fef787fc22d3c9645008ccc4c90cd2f9c9b")
