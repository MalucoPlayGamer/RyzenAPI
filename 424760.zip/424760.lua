-- Lua provided by RyzenAPI
-- Game: Game: AppID 424760

-- MAIN APPLICATION
addappid(424760)
-- Game: addappid(424760)

-- MAIN APP DEPOTS / PACKAGES
addappid(424761, 1, "61449f93621e86b1989dc5403bccc5d5573d09469f54207d29e6f82699cc7400")
