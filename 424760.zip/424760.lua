-- Lua provided by SkyAPI 
-- Game: AppID 424760
addappid(424760)
addappid(424761, 1, "61449f93621e86b1989dc5403bccc5d5573d09469f54207d29e6f82699cc7400")
