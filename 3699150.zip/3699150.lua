-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Puppy Park

-- MAIN APPLICATION
addappid(3699150)
-- Game: addappid(3699150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699150,0,"633c5f6e048ab27f6c4d0e40eae3a2d6956f41b613420a5273cba4120529b2ab")
