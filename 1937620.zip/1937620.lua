-- Lua provided by RyzenAPI
-- Game: Tennis Manager 2022

-- MAIN APPLICATION
addappid(1937620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937621, 1, "0542f95132634466a9bc963a57c86beaa7b8c8e9ccfb025d51cfab0a6c879fd0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
