-- Lua provided by RyzenAPI
-- Game: The Disaster

-- MAIN APPLICATION
addappid(1395080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395081, 1, "8131dc08a03c49943b7b3decb29d898682c399b0bd61bdfcd73d9c9e5aa9e604")

