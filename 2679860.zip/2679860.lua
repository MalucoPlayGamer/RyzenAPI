-- Lua provided by RyzenAPI
-- Game: Space Miner - Idle Adventures

-- MAIN APPLICATION
addappid(2679860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679861, 1, "74832f43cc8f43c80b59d56d54ec79d9cbb42a609a14e8a3f53c1e406e19b5bc")
addappid(2679862, 1, "c3112cad93815305530921ca63a70b02e631befd35d6a37757103e1bb876469b")
