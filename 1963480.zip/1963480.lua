-- Lua provided by RyzenAPI
-- Game: Race to Kyiv

-- MAIN APPLICATION
addappid(1963480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1963481, 1, "01b1e292b66bdd3cc199f3e1125ffae8d2e3a50953d7e71f7fabf816d5d85991")

