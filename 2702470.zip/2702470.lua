-- Lua provided by RyzenAPI
-- Game: Poly Roam

-- MAIN APPLICATION
addappid(2702470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702471, 1, "3abc68de70b961e7dda694a566c7a520512e07b8735333cef335ce552a4771e0")

