-- Lua provided by RyzenAPI
-- Game: Poly Roam

-- MAIN APPLICATION
addappid(2702470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702471, 1, "3abc68de70b961e7dda694a566c7a520512e07b8735333cef335ce552a4771e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
