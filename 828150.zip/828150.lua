-- Lua provided by RyzenAPI
-- Game: WIN THE GAME!

-- MAIN APPLICATION
addappid(828150)
-- Game: addappid(828150)

-- MAIN APP DEPOTS / PACKAGES
addappid(828151, 1, "12154d67fe4d9f870ed9a8e3537d164140bc1f979139f38a2c7a923f39404c93")
