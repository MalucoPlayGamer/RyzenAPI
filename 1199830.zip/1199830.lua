-- Lua provided by RyzenAPI
-- Game: How To Hack In?

-- MAIN APPLICATION
addappid(1199830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199831, 1, "2efb4a433566b2a1b91bfe21ba42526fb5afa40be38dcc24ed4de6a0be7ddf59")
