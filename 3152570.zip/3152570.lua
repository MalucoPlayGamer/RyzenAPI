-- Lua provided by RyzenAPI
-- Game: addappid(3152570)

-- MAIN APPLICATION
addappid(3152570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152571, 1, "557a8bc13c517bbadea57ef40fa08f3487a034c7b33418d5be38ec22136882ad")
