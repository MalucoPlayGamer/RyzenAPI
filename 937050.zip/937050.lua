-- Lua provided by RyzenAPI
-- Game: addappid(937050)

-- MAIN APPLICATION
addappid(937050)

-- MAIN APP DEPOTS / PACKAGES
addappid(937051, 1, "c59f1ca3db6f97881458bf844b4f96ec8f8f7c058034c03b74d4c0533ec3db92")
