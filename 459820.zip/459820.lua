-- Lua provided by RyzenAPI
-- Game: Game: AppID 459820

-- MAIN APPLICATION
addappid(459820)
addappid(3630990)
-- Game: addappid(459820)

-- MAIN APP DEPOTS / PACKAGES
addappid(459821, 1, "aa604fcda9432e9771859c3e86da68938ee4ea9fe1ecef2756ecfa4b6a29e965")
addappid(459822, 1, "d6c6b792d89f44bf67940e24fd6fe4a380d469b022308bb03732ca3868f9cd36")
addappid(459823, 1, "f937c6c3585fef083d295ad35234e588cc1fc94cfecf1f5b5db510af7cd24516")
addappid(948681, 0, "570d7b2578c10dd5bda006abb6d082ca36edb235c3199dd817d6d66bd3f71d3c")
addappid(948682, 0, "dd9ccf33ad4b95653fa4c14d267ac9c3b39791ba20088dae50d7804f213298c5")
addappid(948683, 0, "4aa195ea1741c34b8959f5623de844a063b5dfad2fdaa615438c5c44ccaa900f")
