-- Lua provided by RyzenAPI
-- Game: Game: AlpenCROSS

-- MAIN APPLICATION
addappid(801700)
-- Game: addappid(801700)

-- MAIN APP DEPOTS / PACKAGES
addappid(801701, 1, "1a14410316d643c8b9ab99d70b02db6cf04315cf7ce57a91ebf7c34818b80071")
