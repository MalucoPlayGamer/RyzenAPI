-- Lua provided by SkyAPI 
-- Game: AppID 1162350
addappid(1162350)
addappid(1162351, 1, "160fbaac4d3fa887c20ef332b2f28c901992c3884330aad029754855ef307212")
