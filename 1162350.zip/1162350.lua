-- Lua provided by RyzenAPI
-- Game: Drill Down

-- MAIN APPLICATION
addappid(1162350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162351, 1, "160fbaac4d3fa887c20ef332b2f28c901992c3884330aad029754855ef307212")

