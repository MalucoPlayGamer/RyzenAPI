-- Lua provided by RyzenAPI
-- Game: Black Smith3

-- MAIN APPLICATION
addappid(1614940)
-- Game: addappid(1614940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614941, 1, "014878adf09e3e110078127d3e0c000bcb1eb7a4f076bddefa79799aa4abd260")
