-- Lua provided by RyzenAPI 
-- Game: Pray Game
addappid(1551530)
addappid(1551531, 1, "8bf4bb9de5995d70de93ed82c12e20ab74698b9448371dda333a4e7f31e4ad35")
addappid(1551532, 1, "81d1809a02aacdb3d10af04d9637fcea028a71ef0eaf2827af9c07fe12f00998")
addappid(1551533, 1, "2b7505fb0b733627298e72ac45e1b03e2ccf63bb8f17130bc693465aa573b29b")
