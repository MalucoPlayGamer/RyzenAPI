-- Lua provided by RyzenAPI
-- Game: Cave Crawlers

-- MAIN APPLICATION
addappid(2143030)
addappid(2444550)
addappid(2444553)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143031, 1, "db69eb8b304e751e12e70fd67b4905834176b3678ef6d2c66c29411c01153b7b")

