-- Lua provided by RyzenAPI
-- Game: AppID 2475860

-- MAIN APPLICATION
addappid(2475860)
-- Game: addappid(2475860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475861, 1, "a04fc70cba9b9f8bbac661f36b1a03ae516d1fcddcba43410d5f0f9585a507a2")
