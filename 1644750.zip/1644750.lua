-- Lua provided by RyzenAPI
-- Game: Sheep

-- MAIN APPLICATION
addappid(1644750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644753,0,"de84c3295a04988ef631e567dad5895da7b07676f9b5c2f434d7ec49b537515c")

