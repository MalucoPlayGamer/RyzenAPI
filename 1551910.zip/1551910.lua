-- Lua provided by SkyAPI 
-- Game: Race On Ice 2021 Pro
addappid(1551910)
addappid(1551911, 1, "198ac5d96e0a4fed4d7d08f0310c47e3ca5f5086e0ed22b1aafb90a8f7e9b8db")
