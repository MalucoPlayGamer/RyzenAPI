-- Lua provided by RyzenAPI
-- Game: Race On Ice 2021 Pro

-- MAIN APPLICATION
addappid(1551910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1551911, 1, "198ac5d96e0a4fed4d7d08f0310c47e3ca5f5086e0ed22b1aafb90a8f7e9b8db")

