-- Lua provided by RyzenAPI
-- Game: 3439600

-- MAIN APPLICATION
addappid(3439600)
-- Game: addappid(3439600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439601, 1, "72df0dc4cafeddf57de58a2ab6ca7d2ca189b1fae1e3b7b88a8f661045832533")
