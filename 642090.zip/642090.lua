-- Lua provided by RyzenAPI
-- Game: Coming Out on Top

-- MAIN APPLICATION
addappid(642090)

-- MAIN APP DEPOTS / PACKAGES
addappid(642094,0,"33f88825db7d0e55ab7c9c0450b87835396e7c871f89d531755b17e65803ebc7")

