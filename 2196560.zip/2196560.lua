-- Lua provided by RyzenAPI
-- Game: 2196560

-- MAIN APPLICATION
addappid(2196560)
-- Game: addappid(2196560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196561, 1, "0a9aa46dee4fe77aeb7b2d41df6315137a5899d9b32e24c2ac449908910b8786")
