-- Lua provided by RyzenAPI
-- Game: addappid(1371330)

-- MAIN APPLICATION
addappid(1371330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371331, 1, "710b80ea82b21d20ca9b1b8953a64a40f2fd9d64d3d1148daa30b463e09a6f4b")
