-- Lua provided by RyzenAPI
-- Game: Vessels

-- MAIN APPLICATION
addappid(1371330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371331, 1, "710b80ea82b21d20ca9b1b8953a64a40f2fd9d64d3d1148daa30b463e09a6f4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
