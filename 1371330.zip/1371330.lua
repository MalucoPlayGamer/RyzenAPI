-- Lua provided by SkyAPI 
-- Game: Vessels
addappid(1371330)
addappid(1371331, 1, "710b80ea82b21d20ca9b1b8953a64a40f2fd9d64d3d1148daa30b463e09a6f4b")
