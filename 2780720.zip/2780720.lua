-- Lua provided by RyzenAPI
-- Game: 魍魉村 Demo

-- MAIN APPLICATION
addappid(2780720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780721, 1, "e1bab00d068bda45b917d22a1e47815723c1fc96f5781e00796163d56c1c718a")

