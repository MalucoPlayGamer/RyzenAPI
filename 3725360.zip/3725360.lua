-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Barcelona

-- MAIN APPLICATION
addappid(3725360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3725361, 1, "81b9fd89f33eb124e53cb55d3642d32ebad5ccfade4486d3dcd459b6428e518e")

