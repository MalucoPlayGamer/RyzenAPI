-- Lua provided by RyzenAPI
-- Game: Face of Mankind

-- MAIN APPLICATION
addappid(299700)
addappid(306570)
addappid(315030)
addappid(315100)
addappid(315101)
addappid(317140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982,0,"fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5")
addappid(229003,0,"8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63")
addappid(229020,0,"efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9")
addappid(299719,0,"332840536a908bdfef381a600ae723989d271938e4b900fcaa49e29871bdde6f")

