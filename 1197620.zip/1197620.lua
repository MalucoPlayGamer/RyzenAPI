-- Lua provided by RyzenAPI
-- Game: Game: AppID 1197620

-- MAIN APPLICATION
addappid(1197620)
addappid(1595430)
-- Game: addappid(1197620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197621, 1, "f3e321ade73f7974f0f303d41cfb56f1c9634f63f478441fcc38199894091e23")
