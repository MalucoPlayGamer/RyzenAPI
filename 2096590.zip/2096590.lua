-- Lua provided by RyzenAPI
-- Game: Game: Land of the Vikings Demo

-- MAIN APPLICATION
addappid(2096590)
-- Game: addappid(2096590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096591, 1, "443c463072214ca44be70e083ac6fd53763c9706644e34775e5f596cbf5a6a3d")
