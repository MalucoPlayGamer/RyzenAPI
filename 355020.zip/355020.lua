-- Lua provided by SkyAPI 
-- Game: Bomb The Monsters!
addappid(355020)
addappid(355021, 1, "c2fa47e0f3caaa215149c7d3641ac045b8c6efe787ffc045c6dc353b7af95076")
