-- Lua provided by RyzenAPI
-- Game: AppID 416930

-- MAIN APPLICATION
addappid(416930)

-- MAIN APP DEPOTS / PACKAGES
addappid(416931, 1, "b52ffd2740172b65bb5bd6cfd8a17b5ea75f4f20444bbba5ad4f02345d96ce69")

