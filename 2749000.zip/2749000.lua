-- Lua provided by RyzenAPI
-- Game: Inn Tycoon

-- MAIN APPLICATION
addappid(2749000)
-- Game: addappid(2749000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2749001, 1, "867b444c2eb8519774232a1a354854de141eede681d32d518f61f766c501df4a")
