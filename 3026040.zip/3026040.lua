-- Lua provided by RyzenAPI
-- Game: 3026040

-- MAIN APPLICATION
addappid(3026040)
-- Game: addappid(3026040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026041, 1, "f5a6945bdfa1785ab07bff3a84e6cf31e1d32eec3e6ccab2a2b8cf2dbd208e92")
