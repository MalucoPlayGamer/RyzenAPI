-- Lua provided by RyzenAPI 
-- Game: shion
addappid(3026040)
addappid(3026041, 1, "f5a6945bdfa1785ab07bff3a84e6cf31e1d32eec3e6ccab2a2b8cf2dbd208e92")
