-- Lua provided by RyzenAPI
-- Game: FPS Training

-- MAIN APPLICATION
addappid(971460)

-- MAIN APP DEPOTS / PACKAGES
addappid(971461, 1, "bde10002c7ad10bfd07c81293c2874bceb1b16b92489644b4b2241ab751cee2d")

