-- Lua provided by RyzenAPI
-- Game: FPS Training

-- MAIN APPLICATION
addappid(971460)

-- MAIN APP DEPOTS / PACKAGES
addappid(971461, 1, "bde10002c7ad10bfd07c81293c2874bceb1b16b92489644b4b2241ab751cee2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
