-- Lua provided by RyzenAPI
-- Game: Many Mini Typing Games

-- MAIN APPLICATION
addappid(2918930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918932,0,"d0d52cf1d427a2d459b1271b76fda0ddf6704ad0e102eb7cf4084ed8ce3e5d2e")

