-- Lua provided by RyzenAPI
-- Game: addappid(510220)

-- MAIN APPLICATION
addappid(510220)

-- MAIN APP DEPOTS / PACKAGES
addappid(510221, 1, "ec0bc8833cc3e9b1b5665c8115f2a880f468058e938fb9ea8848b92bcdca59cd")
