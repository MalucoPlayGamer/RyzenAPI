-- Lua provided by RyzenAPI 
-- Game: AppID 2870540
addappid(2870540)
addappid(2870541, 1, "84904ff3a2d305828e083ed8bdec4ad478ed5a7529ef9f35d357ea0457e45b3a")
