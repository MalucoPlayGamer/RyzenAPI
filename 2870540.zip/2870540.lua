-- Lua provided by RyzenAPI
-- Game: 2870540

-- MAIN APPLICATION
addappid(2870540)
-- Game: addappid(2870540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870541, 1, "84904ff3a2d305828e083ed8bdec4ad478ed5a7529ef9f35d357ea0457e45b3a")
