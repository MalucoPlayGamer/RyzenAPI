-- Lua provided by RyzenAPI
-- Game: Game: Hentai　HOTLADY

-- MAIN APPLICATION
addappid(2317310)
-- Game: addappid(2317310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317311, 1, "2e5fca482ddc42a465d19a83846901c507864022ac09831ae18890989dc343d6")
