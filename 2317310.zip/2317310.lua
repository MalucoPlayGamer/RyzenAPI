-- Lua provided by RyzenAPI 
-- Game: Hentai　HOTLADY
addappid(2317310)
addappid(2317311, 1, "2e5fca482ddc42a465d19a83846901c507864022ac09831ae18890989dc343d6")
