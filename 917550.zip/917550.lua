-- Lua provided by RyzenAPI
-- Game: addappid(917550)

-- MAIN APPLICATION
addappid(917550)

-- MAIN APP DEPOTS / PACKAGES
addappid(917551, 1, "76f7bebb665c4712d49a9f29bcade577793e062bca63fce85aac7f2e2e6649d5")
