-- Lua provided by RyzenAPI
-- Game: Checkmate!

-- MAIN APPLICATION
addappid(917550)
addappid(917590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(917551, 1, "76f7bebb665c4712d49a9f29bcade577793e062bca63fce85aac7f2e2e6649d5")
