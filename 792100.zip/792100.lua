-- Lua provided by RyzenAPI
-- Game: 7 Billion Humans

-- MAIN APPLICATION
addappid(792100)

-- MAIN APP DEPOTS / PACKAGES
addappid(792101, 1, "9e557cdbc47245322ef1a7de113b45767f4704ebe9c02fc9060daf5ae40e56f1")
addappid(792102, 1, "031f4c9d22d4ed5f0abfcfed22bb63d1d4f1c0aafb68534ce196b37596760946")
addappid(792103, 1, "8222783a0e2c9d5a5429e6dcdf6f2973d00f3d5f91ac554b12482fd30c21cdba")
addappid(792104, 1, "1b84162027a57ce888ad25ca123b046487766ca4b6246a96779bd8af9b49ebbe")
addappid(792105, 1, "ecc2e2acae8a0fcc07f3bd6c2c25251898c66f04494fda0a7085d234a5db6c2b")