-- Lua provided by RyzenAPI
-- Game: 1448780

-- MAIN APPLICATION
addappid(1448780)
-- Game: addappid(1448780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448781, 1, "ce0af5c4d5ecd7b30b90784745cf4f7f281a6eb30cb5891340bd11f1f7065385")
