-- Lua provided by RyzenAPI
-- Game: AppID 411980

-- MAIN APPLICATION
addappid(411980)
addappid(992180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(411981, 1, "183c51b97c10536e956dab42cb87b5e72e5dd3eb42f14d8edd82189d064d00c7")
addappid(411982, 1, "63c25a4b892e060a367738b75a0739178b1ba61fec012cf7fda3debd12de8b95")

