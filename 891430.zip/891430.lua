-- Lua provided by RyzenAPI
-- Game: Rogue Heist

-- MAIN APPLICATION
addappid(891430)

-- MAIN APP DEPOTS / PACKAGES
addappid(891431, 1, "0606445dfe245a916ca1294473ab961a906dfd1a6f2e1141d3681589365cdc91")

