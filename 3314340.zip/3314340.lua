-- Lua provided by RyzenAPI
-- Game: addappid(3314340)

-- MAIN APPLICATION
addappid(3314340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3314342,0,"4a553b925ea338f09b056513e1f0feeb7aea85a2ae975aa82cbc38b5019bf985")
