-- Lua provided by RyzenAPI
-- Game: addappid(1382770)

-- MAIN APPLICATION
addappid(1382770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382772,0,"a142d925eb829ded2a908c8184913b52255d8fd59ca234386f35fbf2a6e96cee")
