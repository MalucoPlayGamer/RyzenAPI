-- Lua provided by RyzenAPI
-- Game: Game: Secret Agent Wizard Boy and the International Crime Syndicate Demo

-- MAIN APPLICATION
addappid(3281870)
-- Game: addappid(3281870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3281871, 1, "010583d2f8806a211a4273aace2fa9f8c19cfcc7cd643f1a57535ee49ca7c256")
