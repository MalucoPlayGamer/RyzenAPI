-- Lua provided by RyzenAPI 
-- Game: Autobahn Police Simulator 3
addappid(1065520)
addappid(1065521, 1, "ebdf69796c66194e13e3eba42c193675f787c3d7e93d878ccbbbd71adfa98da7")
addappid(1065522, 1, "2b897b355434d8d396d3cae8a4c488b3d6c9188df5daf894a3c01d316f5e5c3a")
addappid(2068070, 0, "e5163f6d8fc49ac016e4318e092a2b6601b1f1f10244e0368abe68722f89914f")
