-- Lua provided by RyzenAPI
-- Game: addappid(1022394)

-- MAIN APPLICATION
addappid(1022394)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022394,0,"6b8362476679c8ba8d2ae88810fefe800dcbf08d0c62adcfac1b2ccdce3b5f87")
