-- Lua provided by RyzenAPI
-- Game: 3451710

-- MAIN APPLICATION
addappid(3451710)
-- Game: addappid(3451710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451711, 1, "637a6c3a1cfe3faf4bc1b50e5dabec5606a661c19d6cc827a820613bc5b6b911")
