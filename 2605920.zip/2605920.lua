-- Lua provided by RyzenAPI
-- Game: AppID 2605920

-- MAIN APPLICATION
addappid(2605920)
-- Game: addappid(2605920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605921, 1, "dd7adfa1aba7520b3f04b07b21904e8d0d5ca4f66cafcc8abce84a4691b6ae51")
