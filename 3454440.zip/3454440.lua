-- Lua provided by SkyAPI 
-- Game: AppID 3454440
addappid(3454440)
addappid(3454441, 1, "c7264e02e3880a5942996a2ab429301c4162e99908bf856c09a1a143170e60b0")
