-- Lua provided by RyzenAPI
-- Game: Provoron

-- MAIN APPLICATION
addappid(2495730) -- Provoron

-- MAIN APP DEPOTS / PACKAGES
addappid(2495731, 1, "275ce8706b91fa1ae6b401f5972286b1f2061c357f39252c5805aa393bdc3489") -- Depot 2495731

