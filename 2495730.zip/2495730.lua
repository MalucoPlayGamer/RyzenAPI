-- 2495730's Lua and Manifest Created by Hubcap Manifest
-- Provoron
-- Created: August 21, 2026 at 22:55:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2495730) -- Provoron
-- MAIN APP DEPOTS
addappid(2495731, 1, "275ce8706b91fa1ae6b401f5972286b1f2061c357f39252c5805aa393bdc3489") -- Depot 2495731
setManifestid(2495731, "7227250113962718813", 9552989334)