-- Lua provided by RyzenAPI
-- Game: Home Sweet Home

-- MAIN APPLICATION
addappid(617160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(617161, 1, "83ffafe3da1cb09d9a2865d2e53b4ee8f7306fddc7420b9aeb18bec559426e84")

