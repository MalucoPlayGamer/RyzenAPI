-- Lua provided by RyzenAPI
-- Game: Game: AppID 617160

-- MAIN APPLICATION
addappid(617160)
-- Game: addappid(617160)

-- MAIN APP DEPOTS / PACKAGES
addappid(617161, 1, "83ffafe3da1cb09d9a2865d2e53b4ee8f7306fddc7420b9aeb18bec559426e84")
