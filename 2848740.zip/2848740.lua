-- Lua provided by RyzenAPI
-- Game: OverRider

-- MAIN APPLICATION
addappid(2848740)
-- Game: addappid(2848740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848741, 1, "2ff4371554ec98d39afab5cde3c48e9c5246789ad7663dc02f7938dc2ecf4978")
