-- Lua provided by RyzenAPI 
-- Game: OverRider
addappid(2848740)
addappid(2848741, 1, "2ff4371554ec98d39afab5cde3c48e9c5246789ad7663dc02f7938dc2ecf4978")
