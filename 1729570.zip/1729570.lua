-- Lua provided by RyzenAPI
-- Game: Cast

-- MAIN APPLICATION
addappid(1729570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729571, 1, "88de042c5bf8d98d9e2fb446940d86a8d81325e82fcefffa807a060c98339540")
