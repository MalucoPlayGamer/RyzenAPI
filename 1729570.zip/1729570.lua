-- Lua provided by SkyAPI 
-- Game: Cast
addappid(1729570)
addappid(1729571, 1, "88de042c5bf8d98d9e2fb446940d86a8d81325e82fcefffa807a060c98339540")
