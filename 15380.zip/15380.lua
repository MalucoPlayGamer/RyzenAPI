-- Lua provided by RyzenAPI
-- Game: Heroes of Might & Magic V: Hammers of Fate

-- MAIN APPLICATION
addappid(15380)

-- MAIN APP DEPOTS / PACKAGES
addappid(15381, 1, "fe22944991f61f8bfb0efc133ca8255b910b0962614f232c714fd06473e7e539")
addappid(15382, 1, "bf81a81fcea5c922fa3e5117c1d85d47b38285553c7c0776c036cae385e0b4c2")
addappid(15383, 1, "8d0822683376bc17ee5ef8297db2a37dee4306d63c716dc68dbc2cd3241ed745")
addappid(15384, 1, "121d7d8f8515e57c051c7dfaf70b757db1a6fbe1780659382592701d9ff2521a")
addappid(15385, 1, "55dd8b72100b999e57c40314317c935f2236e7418c1377e484a28c8cf48ca98c")
addappid(15386, 1, "171cb089413988ad98b86f362a3b30b695d73205ab34c54ee07dfbf75514c59f")
addappid(15388, 1, "661a73de1b2d0a57b89ed220ef033bde334eebff4a033265a52b0f0e50061f67")
addappid(3838341, 0, "fd199e61d273f952185f75411b554e1c180226a895504f902a307a47dbf93917")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
