-- Lua provided by RyzenAPI
-- Game: SpaceRoads

-- MAIN APPLICATION
addappid(488480)

-- MAIN APP DEPOTS / PACKAGES
addappid(488481, 1, "1b320c859b05ab6e582400e592d7b11136482f204f4c07820976ca15697efe66")
addappid(488482, 1, "b527ef4e8086334287ca7bf45ccca226d74aa6fba4cd67cfa525acc71f045f7a")
