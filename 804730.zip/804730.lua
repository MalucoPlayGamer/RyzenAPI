-- Lua provided by RyzenAPI
-- Game: 804730

-- MAIN APPLICATION
addappid(804730)
-- Game: addappid(804730)

-- MAIN APP DEPOTS / PACKAGES
addappid(804731, 1, "4054f121fba59ac9e30de6569693e92eb3937cd784fa8c583d140f2f284f8faf")
