-- Lua provided by RyzenAPI
-- Game: addappid(2387980)

-- MAIN APPLICATION
addappid(2387980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387981, 1, "0b8a6bedccec1c2c3b4e16596218ed24fcfd203b8864b85a7fccfc925b4bb86d")
