-- Lua provided by RyzenAPI 
-- Game: Snip It!
addappid(2849870)
addappid(2849871, 1, "54231baf3dabedd9bc6c09619c4702f2d9f3373f4ead138b7e55275948ca96a2")
