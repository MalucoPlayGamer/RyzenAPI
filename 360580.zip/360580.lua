-- Lua provided by RyzenAPI
-- Game: Abduction Action! Plus

-- MAIN APPLICATION
addappid(360580)

-- MAIN APP DEPOTS / PACKAGES
addappid(360581, 1, "e4af5bdf9e85e133fdba434d94b3c355e7b3745cd55a3f601a3b348062bfb0b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
