-- Lua provided by SkyAPI 
-- Game: Abduction Action! Plus
addappid(360580)
addappid(360581, 1, "e4af5bdf9e85e133fdba434d94b3c355e7b3745cd55a3f601a3b348062bfb0b9")
