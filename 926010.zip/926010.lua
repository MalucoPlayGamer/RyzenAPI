-- Lua provided by RyzenAPI
-- Game: Operation Lone Wolf

-- MAIN APPLICATION
addappid(926010)

-- MAIN APP DEPOTS / PACKAGES
addappid(926011, 1, "86e406720ef6699483634ee74f08a8813a24f51052a62b21689b2c1b93a437c6")
