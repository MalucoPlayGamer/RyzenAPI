-- Lua provided by RyzenAPI
-- Game: Nether: The Untold Chapter

-- MAIN APPLICATION
addappid(1010270)
-- Game: addappid(1010270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010271, 1, "2acf9ad767143a55cbac6ef5f6fb0e302e345f5e5774b2ea92eee93558d61fd0")
