-- Lua provided by RyzenAPI
-- Game: Grand Soul Story

-- MAIN APPLICATION
addappid(2830250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830251, 1, "3478be06bf6c4c94b0da8192c59d61e4f6bbb6bc025226ba01e0d22386445e23")
