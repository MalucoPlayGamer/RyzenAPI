-- Lua provided by SkyAPI 
-- Game: Shuttlecock-H
addappid(1055590)
addappid(1055591, 1, "c25598b6a54476c2fe68825741161a689c60a8dc15cc8b1fe8867d13659afef8")
