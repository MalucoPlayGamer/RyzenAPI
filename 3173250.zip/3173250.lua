-- Lua provided by SkyAPI 
-- Game: SKYGUARD
addappid(3173250)
addappid(3173251, 1, "67b389f4342d3d1643f874c7b4f2640cbd30f06410be927d23afcdf7c1784a7b")
