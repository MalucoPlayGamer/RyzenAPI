-- Lua provided by RyzenAPI
-- Game: SKYGUARD

-- MAIN APPLICATION
addappid(3173250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173251, 1, "67b389f4342d3d1643f874c7b4f2640cbd30f06410be927d23afcdf7c1784a7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
