-- Lua provided by RyzenAPI
-- Game: addappid(3173250)

-- MAIN APPLICATION
addappid(3173250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173251, 1, "67b389f4342d3d1643f874c7b4f2640cbd30f06410be927d23afcdf7c1784a7b")
