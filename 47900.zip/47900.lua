-- Lua provided by RyzenAPI
-- Game: AppID 47900

-- MAIN APPLICATION
addappid(47900)

-- MAIN APP DEPOTS / PACKAGES
addappid(47901, 1, "6a0366356e6d3559dd8a21a61b95124c171519ef9204ec100c84f5877d16730a")
addappid(47902, 1, "64e9358d6df6bd59f402ef2b1dffcca92606dd34be45ee8b3903fdaf9f2834d6")
addappid(47903, 1, "7d1a332d30eb868163de389672b652be082150c36a2470dc459b930c0b9a66fe")
addappid(47904, 1, "7335e53eb457807d24d070851c0795e2804da0a0bf5febaaf23f51e360c1cba0")
addappid(47905, 1, "b17b976aa3d7a33ee25478af883484305a7af47285239fcff8fc1df385848f0e")
addappid(47906, 1, "d3c9d95f8af0cc5969ba173e6b14951f8326cab7e3d8ccd0843328b87a78b95d")
addappid(47907, 1, "8c20b5b536b43ad71000ff9db8588d89c29ad63c104314c1cb2cb7c7fd39539a")
addappid(47908, 1, "74d632df4df90c125036728b1ef6ca43216308210e55da7c2122bf98c40eb248")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(47911)
addappid(47912)
