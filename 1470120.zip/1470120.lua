-- Lua provided by RyzenAPI
-- Game: Atopes

-- MAIN APPLICATION
addappid(1470120)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1538320)
