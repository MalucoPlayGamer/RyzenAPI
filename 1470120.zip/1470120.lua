-- Lua provided by RyzenAPI
-- Game: Atopes

-- MAIN APPLICATION
addappid(1470120)
addappid(1538320)

