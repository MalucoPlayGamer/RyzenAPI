-- Lua provided by RyzenAPI
-- Game: Decently Bad Tower Defense

-- MAIN APPLICATION
addappid(1309870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309871, 1, "a5b0b15c2464c96eb97bbf4be54155be4318fb09345a5e7cfd0657c381053290")
