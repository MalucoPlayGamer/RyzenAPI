-- Lua provided by SkyAPI 
-- Game: Monarchy
addappid(2391650)
addappid(2391651, 1, "0c95c37adfa65a81528547142b18a0c8f9171f80840c256b5a2d5226e7ad91ab")
