-- Lua provided by RyzenAPI
-- Game: addappid(2391650)

-- MAIN APPLICATION
addappid(2391650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391651, 1, "0c95c37adfa65a81528547142b18a0c8f9171f80840c256b5a2d5226e7ad91ab")
