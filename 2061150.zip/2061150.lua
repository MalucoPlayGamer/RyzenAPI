-- Lua provided by RyzenAPI
-- Game: addappid(2061150)

-- MAIN APPLICATION
addappid(2061150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061151, 1, "6aaa6e3712d222513afed01427dae51e155b92c182899a607f31abf3b6129dd3")
