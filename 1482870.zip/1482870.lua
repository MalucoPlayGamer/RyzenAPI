-- Lua provided by RyzenAPI
-- Game: Midnight Legends

-- MAIN APPLICATION
addappid(1482870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1482871, 1, "2628f8a2f9220a6bc466d565fe1f53d24593143fbf7aaf78538fd0fce47733aa")

