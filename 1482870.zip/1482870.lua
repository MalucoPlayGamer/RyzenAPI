-- Lua provided by RyzenAPI 
-- Game: Midnight Legends
addappid(1482870)
addappid(1482871, 1, "2628f8a2f9220a6bc466d565fe1f53d24593143fbf7aaf78538fd0fce47733aa")
