-- Lua provided by RyzenAPI
-- Game: addappid(1519010)

-- MAIN APPLICATION
addappid(1519010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519011, 1, "797e743ee882f794af262e1a58ab8af307f68acf80872016b11a8ec88fed8c12")
