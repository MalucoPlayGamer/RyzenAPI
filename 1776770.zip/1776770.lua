-- Lua provided by RyzenAPI
-- Game: Game: AppID 1776770

-- MAIN APPLICATION
addappid(1776770)
-- Game: addappid(1776770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776771, 1, "f9a72069bd415f84090721215101b07ba9388c312bc9640c7db888cb6c536cca")
