-- Lua provided by RyzenAPI
-- Game: Crown of the Empire Around the World

-- MAIN APPLICATION
addappid(1261390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261391, 1, "9471273921e4313aa97b04dfcd113042635681e0f950d706b4b70d43fbd93440")
addappid(1261392, 1, "c700dab05710d868f3fef8d28ff1bd2a6b574f56350be370f2cb2eafe8b97ce4")
addappid(1261393, 1, "33f5da688ed911005ce7e3df2d48290c407ee892b3101844d3acfb680edb7c44")
addappid(1261394, 1, "4e8199cead4c535e0623584bcade770d461b43b938827cc9fa16340a429eeb01")
