-- Lua provided by RyzenAPI
-- Game: Isles of Yore

-- MAIN APPLICATION
addappid(1360850)
-- Game: addappid(1360850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360851, 1, "7d0ecaf3366b2fa460a864370402925a391946d4c6594e756222236d0e4481d8")
