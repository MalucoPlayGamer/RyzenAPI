-- Lua provided by RyzenAPI
-- Game: addappid(1432180)

-- MAIN APPLICATION
addappid(1432180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432180,0,"e68ed72a0c2072d7612aafc416b1a6f5314b9a6e0e750116f8c391a7cf01a74c")
