-- Lua provided by RyzenAPI
-- Game: addappid(1653650)

-- MAIN APPLICATION
addappid(1653650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653651, 1, "9397efb18acab046837257d9d5aa3ad485df997482f59eb9e96adc974a4ec2af")
