-- Lua provided by RyzenAPI
-- Game: addappid(2413020)

-- MAIN APPLICATION
addappid(2413020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413021, 1, "9667f92a9f985549901517ceebbb7b6fe2734f7ceb2cdf757c65b620b532a601")
