-- Lua provided by RyzenAPI
-- Game: AppID 1558600

-- MAIN APPLICATION
addappid(1558600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1558601, 1, "f20fe5e89ded95929382d336803e000e6bdc28ab4b8eddb220bd3349618b0a9b")

