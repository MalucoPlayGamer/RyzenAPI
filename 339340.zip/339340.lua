-- Lua provided by RyzenAPI
-- Game: 339340

-- MAIN APPLICATION
addappid(339340)
-- Game: addappid(339340)

-- MAIN APP DEPOTS / PACKAGES
addappid(339341, 1, "e9299de2069122e5731bd097c02d35efe353b7dc40f59ca9ab568a382f3753c9")
addappid(339342, 1, "5152d943dbe7913f463d7f9deab9da7bc6fcd382c8cb835b83182e1b7ef6ba46")
addappid(381710, 0, "ad086aff51fa29ecb7fd9e505054a2eea1a4d7ec52ab5e375278abeb78a7e16e")
addappid(381711, 0, "8983531cfd5d11e8574db04b0e6b0b9fff62a72b1c96d3a49c0eec8d6cb3229b")
addappid(381712, 0, "75c7d7d7a3b9d267b81318fb7cfd61f1cd78d4b757e70f71efecde5fff153bcf")
addappid(381713, 0, "0af8b8434f59751b16e7c4980fc31ddde20b0741487216fe779580ee28d05215")
addappid(381716, 0, "6af532d95f2f01b2de58c0a23d03e6c3b8f875653e8ccbc33babf6befe8e47b4")
addappid(406140, 0, "c898f781e3b9add2cec64f7b3f0b7d4ca3f0860aa0693fca4284b8e172cd9d1d")
addappid(430390, 0, "2b2af9d49810ca216a15e3163cc022d8aa1c4ce0e5c1117226180fc04113ae1b")
