-- Lua provided by RyzenAPI 
-- Game: Centipede Gun
addappid(2308000)
addappid(2308001, 1, "2f85d5c398fc02bec7a680ccdd540221cb8c0ef0111359641e9fc8c1d1c20ce2")
