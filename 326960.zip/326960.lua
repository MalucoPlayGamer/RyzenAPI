-- Lua provided by RyzenAPI
-- Game: AppID 326960

-- MAIN APPLICATION
addappid(326960)

-- MAIN APP DEPOTS / PACKAGES
addappid(326961, 1, "52ae1758f8de07e7de347f92b873be8ee96e885bf9223189eeca309cf3f0b2e4")

