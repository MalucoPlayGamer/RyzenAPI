-- Lua provided by RyzenAPI
-- Game: Luxor Evolved

-- MAIN APPLICATION
addappid(205830)

-- MAIN APP DEPOTS / PACKAGES
addappid(205831, 1, "167608e03ff6f925d1605ca3e10cd186d8b246c6b489105527bbbbba6bc7bc8e")

