-- Lua provided by RyzenAPI
-- Game: Singularity

-- MAIN APPLICATION
addappid(1429890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1429891, 1, "5ade84320e1ca0a6313d3d5ad7e970cc6efd1ce948ac3e10202e5a2cd9417720")

