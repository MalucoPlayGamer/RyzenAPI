-- Lua provided by RyzenAPI 
-- Game: Singularity
addappid(1429890)
addappid(1429891, 1, "5ade84320e1ca0a6313d3d5ad7e970cc6efd1ce948ac3e10202e5a2cd9417720")
