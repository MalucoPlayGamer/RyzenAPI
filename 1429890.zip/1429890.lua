-- Lua provided by RyzenAPI
-- Game: 1429890

-- MAIN APPLICATION
addappid(1429890)
-- Game: addappid(1429890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429891, 1, "5ade84320e1ca0a6313d3d5ad7e970cc6efd1ce948ac3e10202e5a2cd9417720")
