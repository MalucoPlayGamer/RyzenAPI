-- Lua provided by RyzenAPI
-- Game: Go Mission: Space Travel

-- MAIN APPLICATION
addappid(487270)

-- MAIN APP DEPOTS / PACKAGES
addappid(487271, 1, "3c6481411133f544590d9dbc71548f5d22f669ce11d8a9775e59193cc0457c1b")
addappid(487272, 1, "909b374c32608f73dcc88a857ef98459e01e61468d5c4fbfd2d015bf40007e29")
addappid(487273, 1, "e51c6d933b34ad52fc4a4de6bb998e78d66ef3d9a66ab6ebeca667da7f28cd26")
