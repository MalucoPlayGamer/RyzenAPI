-- Lua provided by RyzenAPI
-- Game: Warplanes: Battles over Pacific

-- MAIN APPLICATION
addappid(1930920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930921, 1, "ed7c6e65ff50194bc04f7b55991d4739830d997fbdb2c8270db5ac4b29789ef1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
