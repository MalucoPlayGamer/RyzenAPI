-- Lua provided by RyzenAPI
-- Game: 1930920

-- MAIN APPLICATION
addappid(1930920)
-- Game: addappid(1930920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930921, 1, "ed7c6e65ff50194bc04f7b55991d4739830d997fbdb2c8270db5ac4b29789ef1")
