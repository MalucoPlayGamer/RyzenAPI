-- Lua provided by RyzenAPI
-- Game: 3263430

-- MAIN APPLICATION
addappid(3263430)
-- Game: addappid(3263430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263431, 1, "76cc1c3fc961514f2a1345fa38d49155e323542bcd446ab0cb1cfe66ca086384")
