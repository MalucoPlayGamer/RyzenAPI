-- Lua provided by SkyAPI 
-- Game: AppID 2795460
addappid(2795460)
addappid(2795461, 1, "668462a94d055bee856e07dd19637e3fa0334bd200d84d3035ebb15491fba1c7")
