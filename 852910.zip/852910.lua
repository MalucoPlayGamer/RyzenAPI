-- Lua provided by RyzenAPI
-- Game: sweet pool

-- MAIN APPLICATION
addappid(852910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(852911, 1, "96f6a59d77f5f62a438756790ef961b7d8202cd213c3f377e3df3f64b874fbbe")

