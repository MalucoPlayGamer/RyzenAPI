-- Lua provided by RyzenAPI
-- Game: Game: sweet pool

-- MAIN APPLICATION
addappid(852910)
-- Game: addappid(852910)

-- MAIN APP DEPOTS / PACKAGES
addappid(852911, 1, "96f6a59d77f5f62a438756790ef961b7d8202cd213c3f377e3df3f64b874fbbe")
