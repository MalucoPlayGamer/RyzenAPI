-- Lua provided by SkyAPI 
-- Game: AppID 2914800
addappid(2914800)
addappid(2914801, 1, "781006f48b41ae5408d54cfcbfcaeeb920a9c278ecde6ddabccd5e95e8852d31")
