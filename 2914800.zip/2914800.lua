-- Lua provided by RyzenAPI
-- Game: AppID 2914800

-- MAIN APPLICATION
addappid(2914800)
-- Game: addappid(2914800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914801, 1, "781006f48b41ae5408d54cfcbfcaeeb920a9c278ecde6ddabccd5e95e8852d31")
