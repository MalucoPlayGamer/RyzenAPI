-- Lua provided by RyzenAPI
-- Game: Blockbuster Inc. - Prologue

-- MAIN APPLICATION
addappid(2535620)
-- Game: addappid(2535620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535621, 1, "00a8cb52fdab906766a2ab957825087b9723409a8821caa84da6949f7192ce90")
