-- Lua provided by RyzenAPI
-- Game: 2690160

-- MAIN APPLICATION
addappid(2690160)
-- Game: addappid(2690160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690161, 1, "224abb10fe6a47c1f7024d4a55c3e76098419be0bd61a338a83714465c3a9bfd")
