-- Lua provided by SkyAPI 
-- Game: AppID 1366750
addappid(1366750)
addappid(1366751, 1, "98fa0d912cec6d8869ac0b028f1981cf809eb4274f57ce2f3b3cd462975aafe4")
