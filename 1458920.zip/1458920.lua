-- Lua provided by RyzenAPI 
-- Game: Meridian 157: Chapter 1
addappid(1458920)
addappid(1458921, 1, "b11690523374f4fdee2a40a4fa335106d1d14745d54901a48bab69bd1ae9f3e5")
addappid(1458922, 1, "bb3c29a293d2b4776df2ad8b8a80e4414c0bfb142abb5831c0549ae4cf53989f")
