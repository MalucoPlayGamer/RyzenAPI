-- Lua provided by RyzenAPI
-- Game: 1089225

-- MAIN APPLICATION
addappid(1089225)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089225,0,"919e7dc865ef25e1aaff42b9aabe96980377fc08cf52bb3cefca30565c6fcea5")
