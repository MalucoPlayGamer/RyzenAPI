-- Lua provided by RyzenAPI
-- Game: Circles EP: South of the Circle Edition

-- MAIN APPLICATION
addappid(2052810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052811, 1, "aff8c8d7304cf3f889756aec7368a46cf323b4f1911bb7ce07cabec7baad5f85")
addappid(2052812, 1, "3633f423213f6e0fab52e891e3dfdc9508a03c8730d2bcd9aa84dfb560b76c7c")
