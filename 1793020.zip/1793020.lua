-- Lua provided by RyzenAPI
-- Game: Game: Celerity

-- MAIN APPLICATION
addappid(1793020)
-- Game: addappid(1793020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793021, 1, "2f65b3bafce6b2e125fd5f45dca8a502af59271f391e18a66569ee3f6b279a23")
