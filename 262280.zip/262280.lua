-- Lua provided by RyzenAPI
-- Game: Dungeons 2

-- MAIN APPLICATION
addappid(262280)
addappid(363710)
addappid(382400)
addappid(382410)
addappid(390180)
addappid(408600)

-- MAIN APP DEPOTS / PACKAGES
addappid(262281, 1, "71e4814cc88d71db67ca805598711b334e6478e7908fb4ff9827115db33276bd")
addappid(262282, 1, "42b2fbfd641469ed5363b4742ebc62a3cc5a0f64d739a074ddcb19d7c0f08276")
addappid(262283, 1, "5cf7984b666d81d4f8e03b65c74728f0ad2dd6ef227fd817cae034be33459273")
addappid(262284, 1, "e1d19de89bef5caed9495e21336137f265ed1df438d416774d314da142cee9d4")
addappid(262285, 1, "1d3e40bf9d85065ddd18e4d36a94e59b03ccd0c2e4366a3fc02b3950f898474a")
addappid(262286, 1, "3e814ba80f6435b0dfb22381491083cc64c4db7345fb3d4f0e47ae41466a6668")
addappid(262287, 1, "07ea7406dc082502b51032518f0bd73e16305c84ea627879aea5d0dff5fd73d0")
addappid(262288, 1, "8b017daf8d6630d3f653ea214e90aa296b707ab0664a881a389f43bb0adbc13b")
addappid(262291, 1, "94af67d50bb593d59f2b019206431f1782d21dff2ec48158edcc24bfa9ca30b2")
addappid(262292, 1, "d1a1ce203cd2c2fde9be270040ad60716ebbe9879f502f7aab5d5a28014cebc3")
addappid(262293, 1, "dc5e2cec44c1ef68754294382e32a68f4afc193ca1ebfc9d84899adce0bb52ee")
addappid(262294, 1, "f0f6e5a747ddc2f85d9c52c16b17eec7186e5b11974e62e80a43f2348ddc1c2c")
addappid(262295, 1, "77c4d31e4b859fa4ab7436b10430002a2ccb1f0ce0f1840b7ea3e3d5b0aef04e")
addappid(262299, 1, "02b4f06a205de4c502df7ad4b542dabc4f57cf9f66af1546431b119575f565c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(363720)
