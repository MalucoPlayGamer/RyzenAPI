-- Lua provided by RyzenAPI
-- Game: Game: Pro Show Jumping

-- MAIN APPLICATION
addappid(2725650)
-- Game: addappid(2725650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725651, 1, "07ac1bfb47e29ccf542503bcbfeaa8a48ed3ebf5668b917ec0a5825a75ca3fdd")
