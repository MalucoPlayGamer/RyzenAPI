-- Lua provided by RyzenAPI
-- Game: Pro Show Jumping

-- MAIN APPLICATION
addappid(2725650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725651, 1, "07ac1bfb47e29ccf542503bcbfeaa8a48ed3ebf5668b917ec0a5825a75ca3fdd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
