-- Lua provided by RyzenAPI
-- Game: World of Sea Battle

-- MAIN APPLICATION
addappid(2948190)
