-- Lua provided by RyzenAPI
-- Game: 678890

-- MAIN APPLICATION
addappid(678890)
-- Game: addappid(678890)

-- MAIN APP DEPOTS / PACKAGES
addappid(678891, 1, "c89473d6af0d439287f7dfdb19e468b3835ddb3d8789224326641f7c6f052ed9")
