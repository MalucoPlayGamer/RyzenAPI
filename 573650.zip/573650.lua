-- Lua provided by RyzenAPI
-- Game: 3 days: Zoo Mystery

-- MAIN APPLICATION
addappid(573650)

-- MAIN APP DEPOTS / PACKAGES
addappid(573651, 1, "5d3d78a61b63a90ab544f5312fab603d1dc27487df4f864d0943ec2c03c80a25")
addappid(573652, 1, "74add7d379308319b3b3bfe4001b8d7d70a3b667a2abcad9204cf872352c2434")

