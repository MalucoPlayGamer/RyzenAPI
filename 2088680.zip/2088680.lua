-- Lua provided by RyzenAPI
-- Game: addappid(2088680)

-- MAIN APPLICATION
addappid(2088680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088681, 1, "44875adbdfd142647365d93407087dec6367b7fac2eb332f3eaaf2b3f95a7e0f")
