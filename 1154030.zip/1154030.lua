-- Lua provided by RyzenAPI
-- Game: Game: AppID 1154030

-- MAIN APPLICATION
addappid(1154030)
-- Game: addappid(1154030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154031, 1, "e4c24aa5ff3a15fba8dcb2762211078a3f284a840b9514a64e6694e2acbb33b3")
addappid(1154032, 1, "43500c93da407fa7209d086b870b5e21bf2fe23eb5b4222593992edd340ca26e")
addappid(1154033, 1, "fd8d7e7db90c144288acda1e77897ffd3ecc1acc26408079c1c8f54c095d3f49")
