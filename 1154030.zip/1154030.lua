-- Lua provided by RyzenAPI
-- Game: Titan Quest II

-- MAIN APPLICATION
addappid(1154030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1154031, 1, "e4c24aa5ff3a15fba8dcb2762211078a3f284a840b9514a64e6694e2acbb33b3")
addappid(1154032, 1, "43500c93da407fa7209d086b870b5e21bf2fe23eb5b4222593992edd340ca26e")
addappid(1154033, 1, "fd8d7e7db90c144288acda1e77897ffd3ecc1acc26408079c1c8f54c095d3f49")

