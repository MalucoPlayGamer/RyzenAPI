-- Lua provided by RyzenAPI
-- Game: Planting Trees

-- MAIN APPLICATION
addappid(2359220)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(2359221, 1, "4b33957ec485c54403c4ce1a5b72ecad0e3fc5dfc3af8ad85131aa0c9cac851f")
addappid(2359222, 1, "4a5758e4af6c84ffc50bfdc9b42c469cc4d116b7e61b5f0a030bd35ef2cba5d1")

