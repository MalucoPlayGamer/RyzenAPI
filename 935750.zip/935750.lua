-- Lua provided by RyzenAPI
-- Game: 935750

-- MAIN APPLICATION
addappid(935750)
-- Game: addappid(935750)

-- MAIN APP DEPOTS / PACKAGES
addappid(935751, 1, "d8aa8d2cca421107774eb6953c56384d2b77abeb4a5f1ae578834a080877e7d5")
