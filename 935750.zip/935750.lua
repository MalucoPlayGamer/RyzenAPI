-- Lua provided by RyzenAPI
-- Game: Antiquitas

-- MAIN APPLICATION
addappid(935750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(935751, 1, "d8aa8d2cca421107774eb6953c56384d2b77abeb4a5f1ae578834a080877e7d5")

