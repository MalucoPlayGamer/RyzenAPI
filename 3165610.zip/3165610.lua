-- Lua provided by RyzenAPI
-- Game: "Otherworldly: Beginning of the Rift" Pre-Alpha

-- MAIN APPLICATION
addappid(3165610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3165611, 1, "1a8c0c1147e0db7693b68d22f7372bd9d5f86c6362591305a87c55e7ec1aba41")

