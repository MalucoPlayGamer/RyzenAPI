-- Lua provided by RyzenAPI
-- Game: "Otherworldly: Beginning of the Rift" Pre-Alpha

-- MAIN APPLICATION
addappid(3165610)
-- Game: addappid(3165610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165611, 1, "1a8c0c1147e0db7693b68d22f7372bd9d5f86c6362591305a87c55e7ec1aba41")
