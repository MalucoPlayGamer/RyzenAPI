-- Lua provided by RyzenAPI
-- Game: Roomscale Coaster

-- MAIN APPLICATION
addappid(592330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(592331, 1, "b00f17fffe0dde36b0fa12f341464271d3f095c370d35b785afa7628c2a63914")
