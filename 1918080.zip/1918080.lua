-- Lua provided by RyzenAPI
-- Game: Path Of Destruction

-- MAIN APPLICATION
addappid(1918080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918081, 1, "5d9cadb6e3017f115cb9b935f9e194f1e931ccc987a2f57d9ef8111fe10234ac")
addappid(1918083, 1, "7f669e62ea200bc721f4a6657fc4e88c8fee0d248492771e1371f0c087d624b2")

