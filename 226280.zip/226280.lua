-- Lua provided by SkyAPI 
-- Game: Warp Frontier
addappid(226280)
addappid(226281, 1, "8e64f04f007b6f4c18cff9750ada50329cfac3bcd3c61c200f28a518803538b5")
