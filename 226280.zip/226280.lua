-- Lua provided by RyzenAPI
-- Game: Game: Warp Frontier

-- MAIN APPLICATION
addappid(226280)
-- Game: addappid(226280)

-- MAIN APP DEPOTS / PACKAGES
addappid(226281, 1, "8e64f04f007b6f4c18cff9750ada50329cfac3bcd3c61c200f28a518803538b5")
