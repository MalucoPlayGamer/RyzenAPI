-- Lua provided by RyzenAPI
-- Game: Game: Beautiful Vikings

-- MAIN APPLICATION
addappid(1668850)
-- Game: addappid(1668850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668851, 1, "0ec33dea3471d7ec5166d755ea19fcaa5411f4df4d5b6ad17596c2795c14d772")
