-- Lua provided by RyzenAPI
-- Game: Alien Hominid HD

-- MAIN APPLICATION
addappid(1285360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285361, 1, "b6058d1783532c314a08e4b93d80c02854abd2bb7ec95148c979cca0684f5ece")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
