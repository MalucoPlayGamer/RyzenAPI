-- Lua provided by RyzenAPI
-- Game: addappid(1285360)

-- MAIN APPLICATION
addappid(1285360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285361, 1, "b6058d1783532c314a08e4b93d80c02854abd2bb7ec95148c979cca0684f5ece")
