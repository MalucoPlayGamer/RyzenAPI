-- Lua provided by RyzenAPI 
-- Game: Alien Hominid HD
addappid(1285360)
addappid(1285361, 1, "b6058d1783532c314a08e4b93d80c02854abd2bb7ec95148c979cca0684f5ece")
