-- Lua provided by RyzenAPI
-- Game: Death Trick: Double Blind - Demo

-- MAIN APPLICATION
addappid(2322630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322631, 1, "2d89ef756eadffe0f4a6454459c091d6b83c49eea00ce4c3f2e913aae3257551")
