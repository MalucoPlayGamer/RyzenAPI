-- Lua provided by RyzenAPI
-- Game: addappid(3070380)

-- MAIN APPLICATION
addappid(3070380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070381, 1, "52b12cc58a6962918feb5c33c6f3136f42c8bf33727ad37953e70e83b413fab8")
