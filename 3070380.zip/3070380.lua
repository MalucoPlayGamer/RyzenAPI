-- Lua provided by SkyAPI 
-- Game: AppID 3070380
addappid(3070380)
addappid(3070381, 1, "52b12cc58a6962918feb5c33c6f3136f42c8bf33727ad37953e70e83b413fab8")
