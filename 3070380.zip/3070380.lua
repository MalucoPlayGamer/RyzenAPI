-- Lua provided by RyzenAPI
-- Game: Space Will

-- MAIN APPLICATION
addappid(3070380)
addappid(3226240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3070381, 1, "52b12cc58a6962918feb5c33c6f3136f42c8bf33727ad37953e70e83b413fab8")

