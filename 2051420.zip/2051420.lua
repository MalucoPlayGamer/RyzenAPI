-- Lua provided by RyzenAPI
-- Game: Beltex

-- MAIN APPLICATION
addappid(2051420)
-- Game: addappid(2051420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051421, 1, "8926e65611daef9d20adad37abcef052469c2d93e04b8ba6d264fcdfe57c5491")
