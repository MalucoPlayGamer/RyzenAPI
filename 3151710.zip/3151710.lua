-- Lua provided by RyzenAPI
-- Game: Ace Squared

-- MAIN APPLICATION
addappid(3151710)
addappid(4090140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151711, 1, "dcceb45da1e60d78c98030f222be8981bbd411e9f387812b66384d6ef791bb26")
