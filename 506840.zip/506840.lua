-- Lua provided by RyzenAPI
-- Game: 506840

-- MAIN APPLICATION
addappid(506840)
-- Game: addappid(506840)

-- MAIN APP DEPOTS / PACKAGES
addappid(506841, 1, "2b3e268f9c8ee95dc0cc709c8bf99de629911e554b691f8cb294949ccf3a4dd0")
