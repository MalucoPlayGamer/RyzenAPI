-- Lua provided by RyzenAPI
-- Game: 2020500

-- MAIN APPLICATION
addappid(2020500)
-- Game: addappid(2020500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020501, 1, "72d5b0ee788662a197e394b3deba6afc5de14f8135382d0d3eb27da51fa87253")
