-- Lua provided by RyzenAPI
-- Game: 風色幻想3:罪與罰的鎮魂歌

-- MAIN APPLICATION
addappid(2020500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2020501, 1, "72d5b0ee788662a197e394b3deba6afc5de14f8135382d0d3eb27da51fa87253")

