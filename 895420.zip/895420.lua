-- Lua provided by RyzenAPI
-- Game: AppID 895420

-- MAIN APPLICATION
addappid(895420)

-- MAIN APP DEPOTS / PACKAGES
addappid(895421, 1, "8f262aabeda33ff3221eb96ceb2f1c75c118fcbd599306d0c374b82af30e608b")

