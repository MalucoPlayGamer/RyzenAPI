-- Lua provided by RyzenAPI
-- Game: Couroland

-- MAIN APPLICATION
addappid(2172760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172761, 1, "367af53c86a49416ddd44aeeb48f2bf609c673f59625d13affc9217183d8a927")
