-- 3384360's Lua and Manifest Created by Hubcap Manifest
-- Ashbound Expanse
-- Created: July 24, 2026 at 06:00:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3384360) -- Ashbound Expanse
-- MAIN APP DEPOTS
addappid(3384361, 1, "883f2de29aeea3a1ee448a02629724f0bd28ab69b1e4295868e33b3f3716f65e") -- Depot 3384361
setManifestid(3384361, "1563919805240823973", 4325359711)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)