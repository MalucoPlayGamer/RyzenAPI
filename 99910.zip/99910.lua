-- Lua provided by RyzenAPI
-- Game: Puzzle Pirates

-- MAIN APPLICATION
addappid(99910)
-- Game: addappid(99910)

-- MAIN APP DEPOTS / PACKAGES
addappid(99911, 1, "5de10fe4c43b0402fd76ad49fd0e4242c7b0577e0690f015b5f61de43127b378")
addappid(99912, 1, "3c2e957be2e3774f2e8496e38166b936ee5d12547a280bc382bebb953615fbdf")
