-- Lua provided by RyzenAPI
-- Game: Game: AppID 411520

-- MAIN APPLICATION
addappid(411520)
-- Game: addappid(411520)

-- MAIN APP DEPOTS / PACKAGES
addappid(411521, 1, "d270dd2fce83d4995d36c2f85fd799520c0fa73f53f4cc0888b0f7abcb9c4ac6")
