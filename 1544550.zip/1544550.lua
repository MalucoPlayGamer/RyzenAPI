-- Lua provided by SkyAPI 
-- Game: ALONE (Free)
addappid(1544550)
addappid(1544551, 1, "1a1078bce68598f423ff41dab6277c707de90372c25c07dd266b7605e0ecc0ca")
