-- Lua provided by RyzenAPI
-- Game: ALONE (Free)

-- MAIN APPLICATION
addappid(1544550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544551, 1, "1a1078bce68598f423ff41dab6277c707de90372c25c07dd266b7605e0ecc0ca")
