-- Lua provided by RyzenAPI
-- Game: Pagui soundtrack album#3-The Light From the Temple

-- MAIN APPLICATION
addappid(2102050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102051, 1, "e8418bff4b31f5101f19b4b25f544205740df9ddcb1fc3f8298d50434735dbc5")
addappid(2102052, 1, "c9a6b3c43f7b82afd55c77ea355219428d4228dae7f6d7b79c715dcb1ed9fca9")
