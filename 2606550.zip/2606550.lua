-- Lua provided by RyzenAPI 
-- Game: Farmer Survivors
addappid(2606550)
addappid(2606551, 1, "1c8592e91037cec58594c84123a2822d9b66e1e3572b75683708e6c6791d52c9")
