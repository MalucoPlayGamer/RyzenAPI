-- Lua provided by RyzenAPI
-- Game: Game: AppID 1686480

-- MAIN APPLICATION
addappid(1686480)
-- Game: addappid(1686480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686481, 1, "541985639f0fbe744b83c3f209f9656582db619410b26e26135d1ae4ead0348c")
