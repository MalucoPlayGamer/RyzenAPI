-- Lua provided by RyzenAPI
-- Game: Soulstone Survivors Demo

-- MAIN APPLICATION
addappid(2083070)
-- Game: addappid(2083070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083071, 1, "986365ab41f85673b7dce860b124cc3f0c1fc87204a9524c62d8f43ed8de53ae")
