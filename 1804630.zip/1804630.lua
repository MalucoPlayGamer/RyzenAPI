-- Lua provided by RyzenAPI
-- Game: 1804630

-- MAIN APPLICATION
addappid(1804630)
-- Game: addappid(1804630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804631, 1, "3b7c9ab3bc61e2300b26277a917a7aaf1d4b79abaa141b0253bb8c6152815fc2")
