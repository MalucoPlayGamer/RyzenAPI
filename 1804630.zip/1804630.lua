-- Lua provided by RyzenAPI
-- Game: Outbreak Island: Pendulum

-- MAIN APPLICATION
addappid(1804630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804631, 1, "3b7c9ab3bc61e2300b26277a917a7aaf1d4b79abaa141b0253bb8c6152815fc2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
