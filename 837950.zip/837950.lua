-- Lua provided by RyzenAPI
-- Game: Mad Carnage

-- MAIN APPLICATION
addappid(837950)

-- MAIN APP DEPOTS / PACKAGES
addappid(837951,0,"ef6eaa646434976fe0c78448b25a823aa45657a75b181fc6e60782b56d82aae3")

