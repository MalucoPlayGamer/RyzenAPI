-- Lua provided by SkyAPI 
-- Game: JUNKPUNK
addappid(1585020)
addappid(1585021, 1, "96f2bd7af4758ff153ffbaafa69d9ca44af1485c4a374be8b113a877ab44188d")
