-- Lua provided by RyzenAPI
-- Game: Man of Honor

-- MAIN APPLICATION
addappid(756740)

-- MAIN APP DEPOTS / PACKAGES
addappid(756741,0,"64e1c94ef43334293bd21453ba61f138f731c485b44d23d105b9eae4b47d6323")

