-- Lua provided by RyzenAPI
-- Game: Gamedec - Definitive Edition

-- MAIN APPLICATION
addappid(917720)
addappid(1730040)
addappid(1912680)
addappid(1912690)
addappid(2157020)
addappid(2157021)
addappid(2157024)

-- MAIN APP DEPOTS / PACKAGES
addappid(917721,0,"5cc9c2341bbd1e63ea4e220af63ab917804a76be1bb20834b8fb9c058472d1d3")
addappid(917722,0,"81dea3efaf405bc683c686eb9e04c9b203fa3e8063c6c80b86190470ae583503")
addappid(917723,0,"aaf358fc0eb617f648087f7461fea193771c56115cb95b8b3128ed6acb7550e5")
addappid(917724,0,"6e4414f2ca7a3bb02967c50ed9e6d444b97e9abb7845468d502e3dfddeeff2d5")
addappid(917725,0,"c1ee75268ff25613d415921489f0fad92b85cad7377b560ce1091437f94ed08d")
addappid(1729970,0,"511dee1193f29da01192ddf12d11bbb2557c5b52aa6b37e3b7dc6982687f1099")
addappid(1748810,0,"de35bed7e8377b5a8e2688e0501008a066e04bf860e566c3ab802fdad0ab3a4e")

