-- Lua provided by RyzenAPI
-- Game: Freedom Planet

-- MAIN APPLICATION
addappid(248310)

-- MAIN APP DEPOTS / PACKAGES
addappid(248311, 1, "676450a8c66959e587ba4808925c90ec02e095b30320716bd11034aab94f146c")
addappid(248312, 1, "4299e8c226f343afb5d68178e524e890b4cf0181c1ed9933e4cab2666e1f8973")
addappid(248313, 1, "9c464603c538790b524e8d17ba46871b20fb5f300c922ccb7387e18e57d85a85")
addappid(316560, 0, "3d55381188ba9e4ce1fa1aa3ea958ef01f665e52939fee876914182f83db42c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
