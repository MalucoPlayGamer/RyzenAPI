-- Lua provided by RyzenAPI
-- Game: WAGAMAMA HIGH SPEC

-- MAIN APPLICATION
addappid(575480)
-- Game: addappid(575480)

-- MAIN APP DEPOTS / PACKAGES
addappid(575481, 1, "d30d62f9647b8d9a25dcb36ebc1f2c19a89fced3b1376d1fdcd22109cbdd862d")
