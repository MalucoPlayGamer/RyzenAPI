-- Lua provided by RyzenAPI
-- Game: WAGAMAMA HIGH SPEC

-- MAIN APPLICATION
addappid(575480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(575481, 1, "d30d62f9647b8d9a25dcb36ebc1f2c19a89fced3b1376d1fdcd22109cbdd862d")

