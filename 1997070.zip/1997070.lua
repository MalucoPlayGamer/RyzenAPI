-- Lua provided by RyzenAPI 
-- Game: HEN, CHICKS AND CATS
addappid(1997070)
addappid(1997071, 1, "a2c75730eb7a3d12b2c84e6108a511988c38478e3e4ab6d8346ff8cb510ba17e")
