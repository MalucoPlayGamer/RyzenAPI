-- Lua provided by RyzenAPI
-- Game: 313360

-- MAIN APPLICATION
addappid(313360)
-- Game: addappid(313360)

-- MAIN APP DEPOTS / PACKAGES
addappid(313361, 1, "b66e3c43a848f27c1c261d8635120559c263b1ab10022c1909eb69c352c70a7a")
addappid(313362, 1, "5cfd01f1d5173ee97ce057c934b60b2e640be75736989166c3a2f814c1e33fa2")
addappid(313363, 1, "53f5f9c0eaddfd18cf6dbf8fef0a50e305e7e6a5bac6c42d830abb18f5623a13")
addappid(316640, 0, "f95b5f56a0fa8cfe52e0c130aded6e37859c1ff7655a1a4ba3b8e77cdfd3db95")
