-- Lua provided by RyzenAPI
-- Game: addappid(384960)

-- MAIN APPLICATION
addappid(228990)
addappid(384960)
addappid(384963)

-- MAIN APP DEPOTS / PACKAGES
addappid(384962,0,"1b21488c5bfd2fba9456389df7775f1c2b3b92253261d64614dd62bb999ffb78")
