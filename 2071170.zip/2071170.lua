-- Lua provided by RyzenAPI 
-- Game: Wandering Sword Playtest
addappid(2071170)
addappid(2071171, 1, "22a99c486edb405dec9f0fa1c49c89dd33e224d93e9bc60a758bd8a9a6a79452")
