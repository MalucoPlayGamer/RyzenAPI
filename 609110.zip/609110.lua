-- Lua provided by RyzenAPI
-- Game: Game: AppID 609110

-- MAIN APPLICATION
addappid(609110)
-- Game: addappid(609110)

-- MAIN APP DEPOTS / PACKAGES
addappid(609111, 1, "a44222e81b30fa1a49201523cfd7dfc50c33ec5c94d02a7f48f75bce3e75e464")
