-- Lua provided by SkyAPI 
-- Game: AppID 609110
addappid(609110)
addappid(609111, 1, "a44222e81b30fa1a49201523cfd7dfc50c33ec5c94d02a7f48f75bce3e75e464")
