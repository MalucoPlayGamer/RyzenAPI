-- Lua provided by RyzenAPI
-- Game: addappid(1359900)

-- MAIN APPLICATION
addappid(1359900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359901, 1, "907655b9266825128c5a7e42930c9e5df1e203c8db2fce2aa5d3a6de5fdd7174")
