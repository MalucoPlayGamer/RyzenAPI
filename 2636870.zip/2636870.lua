-- Lua provided by RyzenAPI
-- Game: MEGA MAN X DiVE Offline Demo

-- MAIN APPLICATION
addappid(2636870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636871, 1, "e10c47b4d45265e1c50fc25b1aafe48ed0c725c7aff6e1cd16589ea16828712a")
