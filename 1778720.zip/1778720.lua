-- Lua provided by RyzenAPI 
-- Game: Blast Beat
addappid(1778720)
addappid(1778721, 1, "99dc2f4a3359b59ed7ce65cc9df3430851d67a91fe803b248720a5e101f5a190")
