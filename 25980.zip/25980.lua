-- Lua provided by RyzenAPI
-- Game: Majesty 2

-- MAIN APPLICATION
addappid(25980)

-- MAIN APP DEPOTS / PACKAGES
addappid(25981, 1, "baa3c2b3d3676b5dd00d2c16662a34a2fb79cd544316c6a8050cdadf1491b07a")
addappid(25982, 1, "0e1f85d3be54f04058383fbb227feca49cfd4e523300729a31b6fb5d276faac8")
addappid(25983, 1, "6395675030df94efe94e537b54612e52162ea7e12790c6f5f8cde734cc1c7eca")
addappid(42881, 0, "957a4b19768d3633ae373e4d97f418f7af835e3723eaba9643bad4c3f439befe")
addappid(42882, 0, "ca1a450915e4c0607145c3d8ca3d4b3d812f80722afbbb6a5e3e2ba77fa5b10c")
addappid(42883, 0, "b0e506b3d12cd1a09261dd0f7421c9879a1053383e9881eead06c6c823f13e2b")
addappid(73041, 0, "458285a6b6ecb8fcd05f6cf52fd701dec1ccc91e89e783bbe9a40f1fa3331815")
addappid(73042, 0, "50235df9ab08ace5f40c4fe5235a91396d05e0457eda948bb4fb731db6052544")
addappid(73043, 0, "30e0ac32a6538d14e28dd3df9996416a32dbff434897563b65068e6008fc1a71")
addappid(73071, 0, "bc67ed51b767ed3976327e6f9804b9c60a00121c41204a2395ef77fa75726838")
addappid(73072, 0, "c8d93b82645b6a6256a121e2ec8dd8d6e665ba0cb92f79972711958cd2ca46f9")
addappid(73073, 0, "108a7ebe92ba80f6860c27abefb1d3eeeb49419d188c08af29889e25ad16b0de")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(25985)
addappid(42840)
addappid(42841)
addappid(42842)
addappid(42843)
addappid(42844)
addappid(42845)
addappid(42846)
addappid(42847)
addappid(42848)
addappid(42849)
addappid(42860)
addappid(73040)
