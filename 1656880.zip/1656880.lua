-- Lua provided by SkyAPI 
-- Game: Dungless
addappid(1656880)
addappid(1656881, 1, "43604ff9802fa10f5f229ff672550bd0d9881509e54f79f7997e26f91286fe28")
