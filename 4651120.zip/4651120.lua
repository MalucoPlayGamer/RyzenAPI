-- 4651120's Lua and Manifest Created by Hubcap Manifest
-- Farming Incremental But With Guns
-- Created: August 12, 2026 at 00:06:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4651120) -- Farming Incremental But With Guns
-- MAIN APP DEPOTS
addappid(4651121, 1, "7cb3ae8df5398246d3e6e86931581cf6abd994f806ff90e174b4d9a38729c1fd") -- Depot 4651121
setManifestid(4651121, "5981035121396464349", 1364484361)