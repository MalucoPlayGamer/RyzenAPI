-- Lua provided by RyzenAPI
-- Game: Farming Incremental But With Guns

-- MAIN APPLICATION
addappid(4651120) -- Farming Incremental But With Guns

-- MAIN APP DEPOTS / PACKAGES
addappid(4651121, 1, "7cb3ae8df5398246d3e6e86931581cf6abd994f806ff90e174b4d9a38729c1fd") -- Depot 4651121

