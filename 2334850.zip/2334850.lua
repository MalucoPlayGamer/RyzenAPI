-- Lua provided by RyzenAPI
-- Game: Game: SHIRIME: The Curse of Butt-Eye

-- MAIN APPLICATION
addappid(2334850)
-- Game: addappid(2334850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334851, 1, "4ee548339f52bc82a1d84c9ba6d5026eb396aa4418e7453503f87dbf8b59567d")
