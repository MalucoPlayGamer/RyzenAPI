-- Lua provided by SkyAPI 
-- Game: SHIRIME: The Curse of Butt-Eye
addappid(2334850)
addappid(2334851, 1, "4ee548339f52bc82a1d84c9ba6d5026eb396aa4418e7453503f87dbf8b59567d")
