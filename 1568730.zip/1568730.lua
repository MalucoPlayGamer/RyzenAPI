-- Lua provided by SkyAPI 
-- Game: Heroes of Eldemor
addappid(1568730)
addappid(1568731, 1, "7490be631c523bd974e1a27dffe5169fe9ec77b3905087c8331a0fd6d437714a")
