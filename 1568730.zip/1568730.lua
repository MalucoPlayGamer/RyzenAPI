-- Lua provided by RyzenAPI
-- Game: Heroes of Eldemor

-- MAIN APPLICATION
addappid(1568730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568731, 1, "7490be631c523bd974e1a27dffe5169fe9ec77b3905087c8331a0fd6d437714a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
