-- Lua provided by RyzenAPI
-- Game: Heroes of Eldemor

-- MAIN APPLICATION
addappid(1568730)
-- Game: addappid(1568730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568731, 1, "7490be631c523bd974e1a27dffe5169fe9ec77b3905087c8331a0fd6d437714a")
