-- Lua provided by RyzenAPI
-- Game: Highrise: Avatar & Social World

-- MAIN APPLICATION
addappid(3474800)
