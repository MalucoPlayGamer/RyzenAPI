-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] The Radio Station | 深夜放送

-- MAIN APPLICATION
addappid(1744910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744911, 1, "eb0f4b8fba0f819736cc9ec1a6272888175aa9867d1c2d632a777c14bf7acaab")

