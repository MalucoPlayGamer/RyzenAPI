-- Lua provided by RyzenAPI
-- Game: 1744910

-- MAIN APPLICATION
addappid(1744910)
-- Game: addappid(1744910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744911, 1, "eb0f4b8fba0f819736cc9ec1a6272888175aa9867d1c2d632a777c14bf7acaab")
