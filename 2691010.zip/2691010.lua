-- Lua provided by RyzenAPI
-- Game: 2691010

-- MAIN APPLICATION
addappid(2691010)
-- Game: addappid(2691010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691011, 1, "b51f415fab07092fe7c4551b21c73286d0e921fd754add78a38b138ae7388314")
