-- Lua provided by RyzenAPI
-- Game: Let's Patiti! Demo

-- MAIN APPLICATION
addappid(2860650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2860651, 1, "c207c9dbe4327e06520d4bf981b20c1eb07eb0663a3d3567c63878a9e85490a4")
