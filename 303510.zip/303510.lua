-- Lua provided by RyzenAPI
-- Game: Dungeons: The Eye of Draconus

-- MAIN APPLICATION
addappid(303510)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(303511, 1, "65b6d846356a1ea9ebac5d4fc1cad060f2806523c2b6e9a9b0d36f46428c7da1")

