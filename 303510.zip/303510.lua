-- Lua provided by RyzenAPI
-- Game: addappid(303510)

-- MAIN APPLICATION
addappid(303510)

-- MAIN APP DEPOTS / PACKAGES
addappid(303511, 1, "65b6d846356a1ea9ebac5d4fc1cad060f2806523c2b6e9a9b0d36f46428c7da1")
