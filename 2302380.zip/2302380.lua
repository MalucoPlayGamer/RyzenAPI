-- Lua provided by RyzenAPI
-- Game: Bleeding Deities

-- MAIN APPLICATION
addappid(2302380)
-- Game: addappid(2302380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302381, 1, "a3cf37af85cd1463f2c64da442debb827b61d81de2be575f39985dd952b41945")
