-- Lua provided by RyzenAPI
-- Game: AppID 1443430

-- MAIN APPLICATION
addappid(1443430)
-- Game: addappid(1443430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443431, 1, "7821979b36a29c7369bfec19494b4d0f2d2a05717e6cc91f9c063f736fc4eb29")
