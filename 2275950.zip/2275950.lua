-- Lua provided by RyzenAPI
-- Game: Pretty Overseer Demo

-- MAIN APPLICATION
addappid(2275950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275951, 1, "f7b78bacaa47cb0bc1c03ce260a76e59c74ca613c6e71d8e07eacf18449606f8")

