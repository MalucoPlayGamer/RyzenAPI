-- Lua provided by RyzenAPI
-- Game: Strike Suit Zero

-- MAIN APPLICATION
addappid(209540)
addappid(228990)
addappid(229000)
-- Game: addappid(209540)

-- MAIN APP DEPOTS / PACKAGES
addappid(209541, 1, "f0ace0ec24f65c8068bb1bf9d38960874c3945f2273c3ee47de190e9347506df")
addappid(209545, 1, "93038ab7889402aa47233dcfb5a894f8a226bce67e02825c77dd3589759bb0c3")
addappid(209546, 1, "f9d8e5dfed9474ac170148180e9de38322e9a88f68da8270d671c08b2ae07e9d")
addappid(209548, 1, "040d26cc8308916bb5f1271a66ad5dfe389a88c21f15ff0d78a7bb5464be47a2")
addappid(234180, 0, "9afc350e44e99a85bc3f3a8f022391a308e3144e49888bf8bc9579d109f304fc")
addappid(234181, 0, "98aa6822ab4fa0af523acbd087eb6a34e6d7c473ead3fd97ec269ce32d34f51a")
addappid(234182, 0, "ebb8b0fd259458626f27e4c2df8d05c8ed020ba903af25105b42f8f9aa620486")
