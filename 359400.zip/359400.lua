-- Lua provided by RyzenAPI 
-- Game: AppID 359400
addappid(359400)
addappid(359401, 1, "40e288abfe0a5d8814ec0c8fd549c1c20ed864e3d1c9e07f8710e96c96311895")
addappid(359402, 1, "e64bf09bb229b351b1717597297ded20e01c6df935c4d7862f94979bf2dd2870")
