-- Lua provided by RyzenAPI
-- Game: FBC: Firebreak

-- MAIN APPLICATION
addappid(2272540)
addappid(3625720)
addappid(4438410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2272541, 1, "a07aa761da92da0deb6a785fac179e2fc66fd3cb9b177051ff9b397b2b966ceb")

