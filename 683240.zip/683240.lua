-- Lua provided by RyzenAPI
-- Game: addappid(683240)

-- MAIN APPLICATION
addappid(683240)

-- MAIN APP DEPOTS / PACKAGES
addappid(683241, 1, "a6933f5748e467e5558c47f8785dbbebacc980b27650c91e95f8e4ddbcdb01eb")
addappid(683242, 1, "15c344b60fac2aa2e4d1790e673d636374eecdcd43d44f3cce717a496ce3765f")
