-- Lua provided by RyzenAPI
-- Game: Game: Tiny Room Stories: Town Mystery

-- MAIN APPLICATION
addappid(1259640)
-- Game: addappid(1259640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259641, 1, "88d9d6113648c97315b6accb2779aaf3fd04448110a7c63e4915fc7171b72bb0")
