-- Lua provided by RyzenAPI
-- Game: 978866

-- MAIN APPLICATION
addappid(978866)

-- MAIN APP DEPOTS / PACKAGES
addappid(978866,0,"f619a8980d5968fb40661dcfdbea7c4473d16b4fe649056380cfde2e11ccbe9b")
