-- Lua provided by RyzenAPI
-- Game: addappid(3482310)

-- MAIN APPLICATION
addappid(3482310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3482311, 1, "ecf76b3f40656549d3b5e12e0ab1d6b9cfb6aabeb3836faf663b7d0008efaddb")
