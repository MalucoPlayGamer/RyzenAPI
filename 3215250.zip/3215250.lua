-- Lua provided by RyzenAPI
-- Game: ReTrime Demo

-- MAIN APPLICATION
addappid(3215250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215251, 1, "1b42dafa70d2e8198587b2136048b7e3be4f82457a61768dc3082cb794d293da")

