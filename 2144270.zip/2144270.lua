-- Lua provided by RyzenAPI
-- Game: addappid(2144270)

-- MAIN APPLICATION
addappid(2144270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144271, 1, "3d4d7cb498c05db2d80f331faa8e3cddb06cd523a9e90b29b66bc4df9a29c53d")
