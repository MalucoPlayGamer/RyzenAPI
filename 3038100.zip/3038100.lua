-- Lua provided by RyzenAPI
-- Game: Game: Survivor World Demo

-- MAIN APPLICATION
addappid(3038100)
-- Game: addappid(3038100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038101, 1, "72d69a92c8e859f081066e0c00a20eea00f58f693c2f07cdba27082d89f34a0b")
