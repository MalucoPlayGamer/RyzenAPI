-- Lua provided by RyzenAPI
-- Game: IN TRUCK DRIVING

-- MAIN APPLICATION
addappid(2660320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660321, 1, "e54ae8d57fbeec482e8e273f8658189e2e744a6e7b5c9853bab89dfdde5f0ef2")
