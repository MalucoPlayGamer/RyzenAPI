-- Lua provided by SkyAPI 
-- Game: IN TRUCK DRIVING
addappid(2660320)
addappid(2660321, 1, "e54ae8d57fbeec482e8e273f8658189e2e744a6e7b5c9853bab89dfdde5f0ef2")
