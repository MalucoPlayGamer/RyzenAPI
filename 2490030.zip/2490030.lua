-- Lua provided by RyzenAPI
-- Game: Escape From Castle Matsumoto

-- MAIN APPLICATION
addappid(2490030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490032,0,"bea249427cd447a9d45184361edad3bb1739762c7fa939056b535db23ff06d1d")
addappid(2490033,0,"8eea66e5e61c1fde7ec286a8ee5330561c450f3c0e3c669d1431480e6fc3444b")
addappid(2490034,0,"34ccdfcc59b179a7f89b9542f7de353e1f1a9d42a75f1aad0a39ee6faf9b272f")
