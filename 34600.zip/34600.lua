-- Lua provided by RyzenAPI
-- Game: Order of War™

-- MAIN APPLICATION
addappid(34600)
addappid(34610)
addappid(34611)
addappid(34612)
addappid(34613)
addappid(34614)
addappid(34615)

-- MAIN APP DEPOTS / PACKAGES
addappid(34601,0,"7223e833a4a299a70bec15fdaf71aac6eb5863bfbad0cf291a13ff287dea7bb1")
addappid(34602,0,"4be66d58b8e8b74b9f0b76530db114cac16fddc0aa518d11598782d038129c46")
addappid(34603,0,"f7cec7e9fcbb0be61f16f8fa1d38987fabac388b7ce56815ad5fbe65f076d5ee")
addappid(34604,0,"09522f9a988ca37881b21ced975ca1cc739b0357248aa506b2b3749d451625df")
addappid(34605,0,"a1f104251dd743c05f47d4aa5fc899448ceffa91773a5f1fc8da6816bb0eaf2e")
addappid(34606,0,"e681b1ac663ff198e45055cec74eaf7bf3bc62e1c1f33707b6fc665e03137053")
addappid(34607,0,"8d7e87d608b9b618d611cce59778fb5a71830ab4a58a05288ce838b80eaaa373")
addappid(34608,0,"0c5e6e73e5d307e5632b1fec1803a3f9f18cb7313eab18991715cd1ffa19e05e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(34616)
