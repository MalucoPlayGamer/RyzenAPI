-- Lua provided by RyzenAPI
-- Game: Game: AppID 34600

-- MAIN APPLICATION
addappid(34600)
-- Game: addappid(34600)

-- MAIN APP DEPOTS / PACKAGES
addappid(34601, 1, "7223e833a4a299a70bec15fdaf71aac6eb5863bfbad0cf291a13ff287dea7bb1")
addappid(34602, 1, "4be66d58b8e8b74b9f0b76530db114cac16fddc0aa518d11598782d038129c46")
addappid(34603, 1, "f7cec7e9fcbb0be61f16f8fa1d38987fabac388b7ce56815ad5fbe65f076d5ee")
addappid(34604, 1, "09522f9a988ca37881b21ced975ca1cc739b0357248aa506b2b3749d451625df")
addappid(34605, 1, "a1f104251dd743c05f47d4aa5fc899448ceffa91773a5f1fc8da6816bb0eaf2e")
addappid(34606, 1, "e681b1ac663ff198e45055cec74eaf7bf3bc62e1c1f33707b6fc665e03137053")
addappid(34607, 1, "8d7e87d608b9b618d611cce59778fb5a71830ab4a58a05288ce838b80eaaa373")
