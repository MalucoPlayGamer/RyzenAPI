-- Lua provided by RyzenAPI
-- Game: Strata

-- MAIN APPLICATION
addappid(286380)
-- Game: addappid(286380)

-- MAIN APP DEPOTS / PACKAGES
addappid(286381, 1, "d52dc999adc93d2e49031de39610e60b3bf92f8ce0f3274a3ec326e3392d0685")
addappid(286382, 1, "5e3d9f07d85d127b88ed92c9226bfe0e1c6da34fdb2e82463daa957a616a404a")
addappid(286383, 1, "1d8f6f4925484c3eb21468516119316fe10c9a0617fdf606f43d32702dbec14e")
