-- Lua provided by RyzenAPI
-- Game: The Secret Planet

-- MAIN APPLICATION
addappid(2397980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397981, 1, "07126c3f0184e49080b0b34a35ef3ca596e2b1e21bebca079a98f0e380809984")

