-- Lua provided by RyzenAPI
-- Game: Game: Jack Hayes: The Lazarus Sign

-- MAIN APPLICATION
addappid(1295750)
-- Game: addappid(1295750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295751, 1, "9f57130015e1edfa924169f67876ee4f78900dcc13b5d672b7dc098c9a2ac7b5")
