-- Lua provided by RyzenAPI
-- Game: Game: AppID 1156510

-- MAIN APPLICATION
addappid(1156510)
-- Game: addappid(1156510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156511, 1, "4d583dd3d1d401f599d9b4e71c9bb62a2adaa80f8db76e583fa65b12f9dfae2a")
