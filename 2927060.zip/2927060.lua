-- Lua provided by SkyAPI 
-- Game: AppID 2927060
addappid(2927060)
addappid(2927061, 1, "1632d824295ab56632c6dfeb508ae6355b6949d3ec6e5d6f5f6945997089dd65")
