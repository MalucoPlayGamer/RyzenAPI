-- Lua provided by RyzenAPI
-- Game: 机械轮回 Cyber Loop Demo

-- MAIN APPLICATION
addappid(2927060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927061, 1, "1632d824295ab56632c6dfeb508ae6355b6949d3ec6e5d6f5f6945997089dd65")

