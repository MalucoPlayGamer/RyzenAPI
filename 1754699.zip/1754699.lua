-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Ramizel's Swimsuit "Agapanthus Romance"

-- MAIN APPLICATION
addappid(1754699)
-- Game: addappid(1754699)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754699,0,"1f367420406fb8d4c7e30ecc28f2c72283bcef5df00e584e54645a2828932852")
