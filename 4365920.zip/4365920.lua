-- Lua provided by RyzenAPI
-- Game: Buccaneer's Booty

-- MAIN APPLICATION
addappid(4365920) -- Buccaneer's Booty

-- MAIN APP DEPOTS / PACKAGES
addappid(4365921, 1, "9c750bd257d7dc25e34445c769a8b7ad2bf5d1fb19aaff64c02afced0acb8aa1") -- Depot 4365921

