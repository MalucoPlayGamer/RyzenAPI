-- Lua provided by RyzenAPI
-- Game: addappid(1066230)

-- MAIN APPLICATION
addappid(1066230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066231, 1, "dab50be3b78184515a1356831d0def253515453eb909e909140fb6c596feae5c")
