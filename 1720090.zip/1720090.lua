-- Lua provided by RyzenAPI
-- Game: 1720090

-- MAIN APPLICATION
addappid(1720090)
-- Game: addappid(1720090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720091, 1, "760062f244b6c9e9b8fbaaf412e186244d12f04caedaf9c41ff15a960967ce2b")
addappid(1817430, 0, "fdaec3acf71418357c03a894af46464df1483df939b2f710fa881e2772708da3")
