-- Lua provided by RyzenAPI
-- Game: Jim is Moving Out!

-- MAIN APPLICATION
addappid(643940)

-- MAIN APP DEPOTS / PACKAGES
addappid(643941, 1, "193d7796763400801ca636fbfc27373a697db1b515120a604fc383767d67367b")

