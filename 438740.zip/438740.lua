-- Lua provided by RyzenAPI
-- Game: addappid(438740)

-- MAIN APPLICATION
addappid(438740)

-- MAIN APP DEPOTS / PACKAGES
addappid(438741, 1, "800d70f48dcfc7847f7f09c34a6a224451a86de5d52ab3b119dea8499b7196dc")
