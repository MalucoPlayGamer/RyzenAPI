-- Lua provided by RyzenAPI
-- Game: Friday the 13th: The Game

-- MAIN APPLICATION
addappid(438740)
addappid(607570)
addappid(607580)
addappid(646160)
addappid(646161)
addappid(702660)
addappid(719330)
addappid(735000)
addappid(737990)
addappid(739581)
addappid(857280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(438741, 1, "800d70f48dcfc7847f7f09c34a6a224451a86de5d52ab3b119dea8499b7196dc")

