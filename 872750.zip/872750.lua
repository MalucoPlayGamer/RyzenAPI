-- Lua provided by RyzenAPI
-- Game: Guard Duty

-- MAIN APPLICATION
addappid(872750)
addappid(1076890)

-- MAIN APP DEPOTS / PACKAGES
addappid(872751,0,"3e1f9b7a8f4e5732adcdb9d8bb5e31dc75e1d131a4eea08ba64616b140e8fdde")

