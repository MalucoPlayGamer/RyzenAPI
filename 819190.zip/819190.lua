-- Lua provided by RyzenAPI
-- Game: 819190

-- MAIN APPLICATION
addappid(819190)

-- MAIN APP DEPOTS / PACKAGES
addappid(819192,0,"9caddfe84d8b4810c7583fd02b788ee2ebb53f56da1b6d665cc6d2ddf6c747bd")
