-- Lua provided by RyzenAPI
-- Game: A Walk Along the Wall

-- MAIN APPLICATION
addappid(776360)

-- MAIN APP DEPOTS / PACKAGES
addappid(776361,0,"c22c886cb17ad5b935153bab034834084a959869ee5f117615380e595e92f63f")

