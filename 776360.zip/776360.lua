-- Lua provided by RyzenAPI
-- Game: A Walk Along the Wall

-- MAIN APPLICATION
addappid(776360)
addappid(779180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(776361,0,"c22c886cb17ad5b935153bab034834084a959869ee5f117615380e595e92f63f")

