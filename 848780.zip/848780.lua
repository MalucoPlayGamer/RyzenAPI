-- Lua provided by RyzenAPI
-- Game: setManifestid(848782,"2776455685460808013")

-- MAIN APPLICATION
addappid(848780)

-- MAIN APP DEPOTS / PACKAGES
addappid(848782,0,"36536b67c09ed84c3fcefd00e008fccd4689f69f58a2ae67dd49d39a62e226dd")
addappid(848783,0,"955b61dc92e2e84c91e7b21a656dcb6bb6c8a0c10eb9c340314e0fed957dba2e")
