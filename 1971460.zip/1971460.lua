-- Lua provided by RyzenAPI
-- Game: Game: Terminus: Zombie Survivors - Free 50 Turn Demo

-- MAIN APPLICATION
addappid(1971460)
-- Game: addappid(1971460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971461, 1, "2ac43572186a4b124f3db23130b972bfd3bdf900708b37701b6215f087995cd8")
