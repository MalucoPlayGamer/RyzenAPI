-- Lua provided by RyzenAPI
-- Game: Prison Life

-- MAIN APPLICATION
addappid(1904820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904821, 1, "4aa9bde17baf5fc9ed249051709e605dac40766831a328b4f4db7c1072d26e42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
