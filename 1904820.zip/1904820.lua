-- Lua provided by RyzenAPI
-- Game: Prison Life

-- MAIN APPLICATION
addappid(1904820)
-- Game: addappid(1904820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904821, 1, "4aa9bde17baf5fc9ed249051709e605dac40766831a328b4f4db7c1072d26e42")
