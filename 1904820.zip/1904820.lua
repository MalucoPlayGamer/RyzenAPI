-- Lua provided by SkyAPI 
-- Game: Prison Life
addappid(1904820)
addappid(1904821, 1, "4aa9bde17baf5fc9ed249051709e605dac40766831a328b4f4db7c1072d26e42")
