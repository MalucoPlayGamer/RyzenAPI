-- Lua provided by RyzenAPI
-- Game: Game: Solaright

-- MAIN APPLICATION
addappid(615590)
-- Game: addappid(615590)

-- MAIN APP DEPOTS / PACKAGES
addappid(615591, 1, "c02d660d06294be9c8c78e5b0899eced922520e1c39af029a955e9f6cb26bad9")
