-- Lua provided by RyzenAPI
-- Game: Game: AppID 1205550

-- MAIN APPLICATION
addappid(1205550)
addappid(1210580)
addappid(1210581)
addappid(1210582)
addappid(1210583)
addappid(1210584)
addappid(1210585)
addappid(1210586)
addappid(1210587)
addappid(1210588)
addappid(1258720)
-- Game: addappid(1205550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205551, 1, "7cffd687bff0b76c358be57efe841f5cce72082bfc2414f9a299f7192993312b")
