-- Lua provided by SkyAPI 
-- Game: JR EAST Train Simulator
addappid(2111630)
addappid(2111631, 1, "560843c4356cc57dba2fefb072f32f56e21217fb7fa03e3c21625e195bc9de7d")
addappid(2111632, 1, "f720bf041063477e203355bc887e84ac7f0fb76ebc26755bda6ffe21cfb76dda")
addappid(2111633, 1, "17a52417f2821a4843121052b9bcb954f9f32f0947a7b05b5fe08439575b272e")
