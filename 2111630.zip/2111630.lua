-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator

-- MAIN APPLICATION
addappid(2111630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111631, 1, "560843c4356cc57dba2fefb072f32f56e21217fb7fa03e3c21625e195bc9de7d")
addappid(2111632, 1, "f720bf041063477e203355bc887e84ac7f0fb76ebc26755bda6ffe21cfb76dda")
addappid(2111633, 1, "17a52417f2821a4843121052b9bcb954f9f32f0947a7b05b5fe08439575b272e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2210720)
addappid(2216300)
addappid(2219200)
addappid(2260870)
addappid(2433290)
addappid(2476590)
addappid(2514660)
addappid(2553940)
addappid(2602460)
addappid(2646190)
addappid(2696300)
addappid(2735590)
addappid(2788350)
addappid(2844540)
addappid(2889350)
addappid(2942990)
addappid(2998930)
addappid(3166710)
addappid(3280130)
addappid(3349810)
addappid(3390940)
addappid(3532910)
addappid(3586360)
addappid(3811380)
addappid(3907540)
addappid(3996090)
addappid(4110510)
addappid(4150600)
addappid(4240730)
addappid(4463440)
addappid(4583320)
addappid(4893760)
