-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Winlu Spaceship Tileset

-- MAIN APPLICATION
addappid(2902960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902960,0,"cab9505584859ce68f69b0303106bd0db107dfc2d065c473a1bbf7cf9752eaab")

