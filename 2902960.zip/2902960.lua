-- Lua provided by RyzenAPI
-- Game: 2902960

-- MAIN APPLICATION
addappid(2902960)
-- Game: addappid(2902960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902960,0,"cab9505584859ce68f69b0303106bd0db107dfc2d065c473a1bbf7cf9752eaab")
