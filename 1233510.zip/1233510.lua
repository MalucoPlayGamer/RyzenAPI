-- Lua provided by SkyAPI 
-- Game: Juice Mania
addappid(1233510)
addappid(1233511, 1, "b9b74701f0f2fd596846fbbb7dafb4b8672258ec1c12eae9eca7a8b700c2fe56")
