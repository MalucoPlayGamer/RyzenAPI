-- Lua provided by RyzenAPI
-- Game: A Plague Tale: Requiem

-- MAIN APPLICATION
addappid(1182900)
addappid(1906530)
-- Game: addappid(1182900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182901, 1, "89056a553dcf6ee12c8c1a92b728c89e8457fb95ec117f931d7115aa918cbd18")
