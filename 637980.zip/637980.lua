-- Lua provided by RyzenAPI
-- Game: Game: Mission B

-- MAIN APPLICATION
addappid(637980)
-- Game: addappid(637980)

-- MAIN APP DEPOTS / PACKAGES
addappid(637981, 1, "3f210335342a6a42e50847af93679839d024effc058647691f729782d5e494b1")
