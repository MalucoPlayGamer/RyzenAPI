-- Lua provided by RyzenAPI
-- Game: Simp: Leveling Up on a Dating App

-- MAIN APPLICATION
addappid(3262250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262251, 1, "61c9196125d65ea9231f307d7abd7d423811a767487ec22f30d349514ec277a9")
