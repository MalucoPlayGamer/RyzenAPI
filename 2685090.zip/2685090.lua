-- Lua provided by RyzenAPI
-- Game: Ufouria: The Saga 2

-- MAIN APPLICATION
addappid(2685090)
-- Game: addappid(2685090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685091, 1, "96e5667241210fe50b9e444d1c5f67989d3ac5855de84c7c1f47e2e092bc92a1")
