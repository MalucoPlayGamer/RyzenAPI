-- Lua provided by RyzenAPI 
-- Game: Fated Souls 2
addappid(523900)
addappid(523901, 1, "aa6cc5de2719be3567597eaf87e7aa8f56e88a2e5c3b74363fc4c9109495f60d")
