-- Lua provided by RyzenAPI
-- Game: Liminal

-- MAIN APPLICATION
addappid(885690)

-- MAIN APP DEPOTS / PACKAGES
addappid(885691, 1, "6c9a5c57a7bed7a525a933987345706f403c89bb34249f58f68ca489cf3d128d")

