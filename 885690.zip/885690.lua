-- Lua provided by RyzenAPI
-- Game: Liminal

-- MAIN APPLICATION
addappid(885690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(885691, 1, "6c9a5c57a7bed7a525a933987345706f403c89bb34249f58f68ca489cf3d128d")

