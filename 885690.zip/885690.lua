-- Lua provided by SkyAPI 
-- Game: Liminal
addappid(885690)
addappid(885691, 1, "6c9a5c57a7bed7a525a933987345706f403c89bb34249f58f68ca489cf3d128d")
