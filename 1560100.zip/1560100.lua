-- Lua provided by SkyAPI 
-- Game: Super Stupid Game
addappid(1560100)
addappid(1560101, 1, "59289fb82a2f742cbab2aec6181b82dfe8aa2fc1e98f7fc5a0aa824aa9e64748")
addappid(1560102, 1, "905afe8f019b4110a72a7a312dbf65e9586e70f63c91dcd9b2a1814a9b55f665")
addappid(1560103, 1, "967ce32ee1121fdef04cc5c33a409eb95cbcf7b501a5ab98e7c547a4cbb99786")
addappid(1560104, 1, "c2adc18724da02c0a4e232dc5f15bd6dc40b61a9210672be7eb6f1c87023438d")
