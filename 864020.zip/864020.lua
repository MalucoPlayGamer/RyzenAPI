-- Lua provided by RyzenAPI
-- Game: addappid(864020)

-- MAIN APPLICATION
addappid(864020)

-- MAIN APP DEPOTS / PACKAGES
addappid(864021, 1, "72463cb5969b49f7f20bad0fb676c570715c7e5d97e11f2aceb2c758705f61e8")
