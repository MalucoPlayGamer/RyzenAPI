-- Lua provided by RyzenAPI
-- Game: The Liminal Dimension

-- MAIN APPLICATION
addappid(3137560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137561, 1, "723383a22823d8e703efdad4230aa014e6a2d5e38de41ec4879ea9e2fd180116")
