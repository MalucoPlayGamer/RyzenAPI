-- Lua provided by RyzenAPI
-- Game: AppID 1444150

-- MAIN APPLICATION
addappid(1444150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444151, 1, "82b6dabec976dd60f19e87e5a2e7b60f4238d084580b109663253de47d3413b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
