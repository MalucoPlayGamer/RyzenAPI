-- Lua provided by SkyAPI 
-- Game: AppID 1444150
addappid(1444150)
addappid(1444151, 1, "82b6dabec976dd60f19e87e5a2e7b60f4238d084580b109663253de47d3413b7")
