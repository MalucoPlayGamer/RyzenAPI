-- Lua provided by RyzenAPI
-- Game: Game: さくら、もゆ。-as the Night's, Reincarnation-

-- MAIN APPLICATION
addappid(2899760)
-- Game: addappid(2899760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899761, 1, "6c15a53d577d149005b8fbfb425c575be9420ae0de646001340a08ba9bc28081")
