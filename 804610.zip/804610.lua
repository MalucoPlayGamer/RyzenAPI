-- Lua provided by RyzenAPI
-- Game: MONMUSU * FIGHT!

-- MAIN APPLICATION
addappid(804610)

-- MAIN APP DEPOTS / PACKAGES
addappid(804611,0,"780fc1d6e12024086b3cd974b0db184c6f52c62bb9a76ebdd2053e9ddb3a78f3")

