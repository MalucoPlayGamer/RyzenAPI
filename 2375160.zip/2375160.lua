-- Lua provided by RyzenAPI
-- Game: 2375160

-- MAIN APPLICATION
addappid(2375160)
-- Game: addappid(2375160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375161, 1, "02bec967efa084aeb0993a579c9ea59f2885eef7c521509993dfa5573d06b7cb")
