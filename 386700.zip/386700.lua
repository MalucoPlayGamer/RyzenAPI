-- Lua provided by RyzenAPI
-- Game: 386700

-- MAIN APPLICATION
addappid(386700)
-- Game: addappid(386700)

-- MAIN APP DEPOTS / PACKAGES
addappid(386701, 1, "119c069f6e49fc6bc43449f28cf136c1f5d7fd45c662810e3fdc9ee35247df71")
