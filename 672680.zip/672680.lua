-- Lua provided by RyzenAPI
-- Game: Supremacy: Call of War 1942

-- MAIN APPLICATION
addappid(672680)

