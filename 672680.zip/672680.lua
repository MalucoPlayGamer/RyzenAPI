-- Lua provided by RyzenAPI
-- Game: Supremacy: Call of War 1942

-- MAIN APPLICATION
addappid(672680)
addappid(815350)
addappid(815351)
addappid(815352)
addappid(815353)
addappid(815354)
addappid(815355)
addappid(815356)
addappid(815357)
addappid(815358)
addappid(815359)

