-- Lua provided by RyzenAPI
-- Game: ❂ Heroes of Hexaluga ❂

-- MAIN APPLICATION
addappid(728050)

-- MAIN APP DEPOTS / PACKAGES
addappid(728051,0,"8b00a6a9305892dead5265b34a190844042210b7d75dc32dc08bf22233ac41f3")

