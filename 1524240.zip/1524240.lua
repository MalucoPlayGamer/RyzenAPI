-- Lua provided by RyzenAPI
-- Game: ANVIL Demo

-- MAIN APPLICATION
addappid(1524240)
-- Game: addappid(1524240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524241, 1, "466324ec0582e5adfc5b165775dcf6514525534b9ef7719c58f5e7d94b94e178")
