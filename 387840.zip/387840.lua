-- Lua provided by RyzenAPI
-- Game: addappid(387840)

-- MAIN APPLICATION
addappid(387840)

-- MAIN APP DEPOTS / PACKAGES
addappid(387841, 1, "abe5bfb859bac463d0f4aa1ee185168fa28baceb70e64b19a8396c507836bd86")
