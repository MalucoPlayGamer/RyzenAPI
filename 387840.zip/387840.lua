-- Lua provided by RyzenAPI
-- Game: AppID 387840

-- MAIN APPLICATION
addappid(387840)

-- MAIN APP DEPOTS / PACKAGES
addappid(387841, 1, "abe5bfb859bac463d0f4aa1ee185168fa28baceb70e64b19a8396c507836bd86")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
