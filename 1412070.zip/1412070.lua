-- Lua provided by RyzenAPI
-- Game: 1412070

-- MAIN APPLICATION
addappid(1412070)
-- Game: addappid(1412070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412071, 1, "93bb41f2bb1150bcb48231a89be90f9b0cd47bb0d76fa69f4f41a90a39c99b7d")
