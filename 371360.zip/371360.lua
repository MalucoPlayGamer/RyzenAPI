-- Lua provided by RyzenAPI 
-- Game: Orc Assault
addappid(371360)
addappid(371361, 1, "98f7ecdf62f6e1dc31b3ce86b3c66ee43382cf3f1e148a15d70ea338adf5f166")
