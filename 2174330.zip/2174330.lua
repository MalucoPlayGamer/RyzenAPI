-- Lua provided by RyzenAPI
-- Game: addappid(2174330)

-- MAIN APPLICATION
addappid(2174330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174331, 1, "6b12ca0f04627f122ebfe85d064e840ad057a9aef8273b0f74795a908e0179cb")
