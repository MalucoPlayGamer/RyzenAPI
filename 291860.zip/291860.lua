-- Lua provided by RyzenAPI
-- Game: AppID 291860

-- MAIN APPLICATION
addappid(291860)

-- MAIN APP DEPOTS / PACKAGES
addappid(291861, 1, "9588b5573c002bf5b2e2f130a6d5389e34e0509a9f9aff43bc854b3bff775eaa")
