-- Lua provided by RyzenAPI
-- Game: Pit People

-- MAIN APPLICATION
addappid(291860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(291861, 1, "9588b5573c002bf5b2e2f130a6d5389e34e0509a9f9aff43bc854b3bff775eaa")

