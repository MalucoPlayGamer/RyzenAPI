-- Lua provided by RyzenAPI
-- Game: 910320

-- MAIN APPLICATION
addappid(910320)
-- Game: addappid(910320)

-- MAIN APP DEPOTS / PACKAGES
addappid(910321, 1, "2637dee2818aa6f9d5a5dcbf8b5e66e7b6d4cab34d29d7a81884ba852e497ae2")
