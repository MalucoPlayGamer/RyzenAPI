-- Lua provided by RyzenAPI
-- Game: Three Kingdoms 2019 阿达三国志2019 横版

-- MAIN APPLICATION
addappid(910320)

-- MAIN APP DEPOTS / PACKAGES
addappid(910321, 1, "2637dee2818aa6f9d5a5dcbf8b5e66e7b6d4cab34d29d7a81884ba852e497ae2")
