-- Lua provided by RyzenAPI
-- Game: V Rising

-- MAIN APPLICATION
addappid(1604030)
addappid(1983900)
addappid(1983901)
addappid(1997210)
addappid(2169180)
addappid(2358430)
addappid(2833600)
addappid(3604340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604031, 1, "e51d4f407e118a5477cab33cf9cd3340057f5aa111772951f47d76b05b594606")
addappid(1604032, 1, "05dc87d45e23f53bfdc06512480bf3a8d84941a929034772fba892bf252d9587")

