-- Lua provided by RyzenAPI
-- Game: 花园魔三国 - 拓展内容  额外剧情

-- MAIN APPLICATION
addappid(1997730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997730,0,"867c3f42999865b6220bb2c8cbf7282c9240da4bfa7b38586fc7fc8d73b26983")
