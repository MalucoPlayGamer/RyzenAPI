-- Lua provided by RyzenAPI
-- Game: addappid(2051080)

-- MAIN APPLICATION
addappid(2051080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051081, 1, "53768e7f3c0032a3ef67a1df64b764d6fee277e1f4a3ce2b4a8edb93d01620d5")
