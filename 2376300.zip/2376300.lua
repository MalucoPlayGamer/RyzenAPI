-- Lua provided by SkyAPI 
-- Game: Cash Dash
addappid(2376300)
addappid(2376301, 1, "2615a4a740edb3ad0d40ae042383df7e5b345d5190f611476dd3d883ef70d26f")
