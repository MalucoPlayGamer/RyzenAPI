-- Lua provided by RyzenAPI
-- Game: Cash Dash

-- MAIN APPLICATION
addappid(2376300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2376301, 1, "2615a4a740edb3ad0d40ae042383df7e5b345d5190f611476dd3d883ef70d26f")

