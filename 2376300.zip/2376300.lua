-- Lua provided by RyzenAPI
-- Game: Cash Dash

-- MAIN APPLICATION
addappid(2376300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376301, 1, "2615a4a740edb3ad0d40ae042383df7e5b345d5190f611476dd3d883ef70d26f")

