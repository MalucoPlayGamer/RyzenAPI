-- Lua provided by RyzenAPI
-- Game: 2744080

-- MAIN APPLICATION
addappid(2744080)
-- Game: addappid(2744080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744081, 1, "e36c26bacdf3f520d1ae5d24aa75e211577b80dbc72b706a7f28444f8d46e977")
