-- Lua provided by RyzenAPI
-- Game: Chasmal Fear Demo

-- MAIN APPLICATION
addappid(2656970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656971, 1, "962405abca0d25c57c495af94f304830f8428c820898ee4f24a7a43240a8a7e7")
