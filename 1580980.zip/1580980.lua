-- Lua provided by RyzenAPI
-- Game: The Floor is [Blank]

-- MAIN APPLICATION
addappid(1580980)
-- Game: addappid(1580980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580981, 1, "270cdbaddd82215225740536eca8ddc17f83832b9ce8d655e79ffd6912c5764f")
