-- Lua provided by RyzenAPI
-- Game: Ironsight

-- MAIN APPLICATION
addappid(715220)

-- MAIN APP DEPOTS / PACKAGES
addappid(715221, 1, "dffd5f7375beac0e43e57741b348891612454c3d82e692a1b22574365a96ae2f")

