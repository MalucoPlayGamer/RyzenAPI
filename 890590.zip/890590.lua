-- Lua provided by SkyAPI 
-- Game: AppID 890590
addappid(890590)
addappid(890591, 1, "9a957faab90707a77fdea0cfc2c83e81499d4e1913618da3c7324c1f90cae3a9")
