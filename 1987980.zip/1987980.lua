-- Lua provided by RyzenAPI
-- Game: Fatal Countdown - immoral List of Desires

-- MAIN APPLICATION
addappid(1987980)
-- Game: addappid(1987980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987981, 1, "6f3c5dffa06166c971a22b5f4e4efad7a8060b82a5dbe092ec46a780f4f699dd")
