-- Lua provided by RyzenAPI
-- Game: Gold Hunter

-- MAIN APPLICATION
addappid(1082450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082451, 1, "bafa50139414aab3e425d8774d6ab3087686570bf6082ab10816aa02eb26f258")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
