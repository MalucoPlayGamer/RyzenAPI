-- Lua provided by RyzenAPI
-- Game: Dungeon Fighter Online

-- MAIN APPLICATION
addappid(495910)
