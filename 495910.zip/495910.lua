-- Lua provided by RyzenAPI
-- Game: Dungeon Fighter Online

-- MAIN APPLICATION
addappid(495910)
addappid(495920)
addappid(495930)
addappid(502790)
addappid(904260)
addappid(1134360)
addappid(2492770)
addappid(2492771)

