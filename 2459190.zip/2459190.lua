-- Lua provided by RyzenAPI
-- Game: Last Signal

-- MAIN APPLICATION
addappid(2459190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459191, 1, "4a8f7efad651e71df92668590b3706a4996a3f48f519f133da1c0d435d0980e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
