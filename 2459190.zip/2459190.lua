-- Lua provided by RyzenAPI
-- Game: Last Signal

-- MAIN APPLICATION
addappid(2459190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459191, 1, "4a8f7efad651e71df92668590b3706a4996a3f48f519f133da1c0d435d0980e9")
