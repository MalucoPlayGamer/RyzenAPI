-- Lua provided by RyzenAPI
-- Game: Game: ARCANA Demo

-- MAIN APPLICATION
addappid(3007030)
-- Game: addappid(3007030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007031, 1, "39f961f9c9536d2e8e7af0a3cf726fda98a013202c199f524f094e0403f11127")
