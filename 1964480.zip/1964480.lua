-- Lua provided by RyzenAPI
-- Game: 1964480

-- MAIN APPLICATION
addappid(1964480)
-- Game: addappid(1964480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964481, 1, "0fbc3ce20c8baf6dfbb6c67c3e8301316876c2e2ef6b9149498b901c54b7fa7d")
