-- Lua provided by RyzenAPI
-- Game: Yami RPG Editor

-- MAIN APPLICATION
addappid(1964480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1964481, 1, "0fbc3ce20c8baf6dfbb6c67c3e8301316876c2e2ef6b9149498b901c54b7fa7d")

