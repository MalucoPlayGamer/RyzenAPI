-- Lua provided by RyzenAPI
-- Game: Serke Demo

-- MAIN APPLICATION
addappid(3116650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116651, 1, "64ea31cc686b44044e48a90fcabd44be38d9a3534a2bac3239d192c70ea73551")
