-- Lua provided by RyzenAPI 
-- Game: Astrodogs
addappid(1301230)
addappid(1301231, 1, "1591875e17d8fbb2ce16a16d3db783c1cb2830b37718f7a70a6f5a54fc218ef9")
