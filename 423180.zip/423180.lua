-- Lua provided by RyzenAPI
-- Game: addappid(423180)

-- MAIN APPLICATION
addappid(423180)

-- MAIN APP DEPOTS / PACKAGES
addappid(423181, 1, "bb16c9e16dcd04f2ebe3d1b45eb50f36d0c54ada5e4bda286d70514909a86291")
