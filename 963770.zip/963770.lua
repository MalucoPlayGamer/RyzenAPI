-- Generated with Luie @ https://lua.tools/
-- 963770 - Welcome To... Chichester Redux : The Spy Of America And The Long Vacation
-- Generated 2026-08-22 17:08:58 UTC
-- # Depots (Total/DLC/Shared): 10/7/0

-- Main AppID
addappid(963770)

-- Main Depots
addappid(963771, 1, "61ae74fd2f4231d2d092a3d54a5822010b35b578fba58d4de90e53a9c0446e45") -- (windows)
setManifestid(963771, "6757991708477721164", 414226958)
addappid(963772, 1, "9dffe42e1db222b3f888a378eeef8fa91781b6e63a93afedcc764c6b7fa2565a") -- (linux)
setManifestid(963772, "3170641056185308030", 464707684)
addappid(963773, 1, "018437f42b7dc479cb7088f8108754c4b581f24990987c04e6c59d1836ee7309") -- (macos, 64-bit)
setManifestid(963773, "4203080524933810863", 401249199)

-- DLC's (no depot keys required)
addappid(965100) -- DLC 965100
addappid(1031600) -- DLC 1031600

-- DLC's (with depot keys)
-- WTC Redux Original Chapter 1 (AppID: 965102)
addappid(965102)
addappid(965102, 1, "923169ba17bb500603ee4354980f7d259c8c83e9102c8feca7c557867a8d5ada") -- (windows)
setManifestid(965102, "8411325595504339241", 192426773)
-- Welcome To... Chichester 1 : Test Project (AppID: 1140430)
addappid(1140430)
addappid(1140430, 1, "c0924f1a76b9eb6146094c97a0a8078e129d30c2b7ffeea6b017b9bd5dab4d30") -- (windows)
setManifestid(1140430, "7426018027000409098", 420811763)
addappid(1140431, 1, "539fa98804dbbad58dbe23ccc7dfb3f2131a19fdaa4d8d2c67ec00930af8b46b") -- (linux)
setManifestid(1140431, "2479234891201434544", 391358439)
addappid(1140432, 1, "b44cb1267b92441d2e01e4ab8a3f8be02927247c98da3ac148d1eaa4216a969c") -- (macos, 64-bit)
setManifestid(1140432, "3492649457387871685", 356313709)
-- Welcome To... Chichester 1 : Test Project Files (AppID: 1140710)
addappid(1140710)
addappid(1140710, 1, "a6c35f4c0a9aeb295cfea8a4d02777588750f43fe91da644498447d7a58e38b3")
setManifestid(1140710, "446260698082835692", 187357081)

-- Missing Depots (We don't have the keys yet lol): 965101, 1023660
