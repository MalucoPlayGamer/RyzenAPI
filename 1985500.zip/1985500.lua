-- Lua provided by RyzenAPI
-- Game: 집착의 망자 - 집으로부터의 탈출

-- MAIN APPLICATION
addappid(1985500)
addappid(2005130)

