-- Lua provided by RyzenAPI
-- Game: Nightmare Slash

-- MAIN APPLICATION
addappid(2015110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015111, 1, "6dbf4a373274abedc888c23650311a75487b3c5a4bdc7ec5ce3a7d9c500c1c06")

