-- Lua provided by RyzenAPI
-- Game: Adventuring With Matilda!

-- MAIN APPLICATION
addappid(3329430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3329431, 1, "1fd2774b5c9b85764e11260ad6db78cde8fec6a27f33fd770d1df0ea6f2be5f0")
addappid(3329432, 1, "547a321e12a7706896c579e9dd79d12e97ee88f07138a386772e4a122036dc68")
addappid(3329433, 1, "a1bee8af67c44a59fecb7f5357c45d6cbb47834cd593b23333583be97ebb900b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
