-- Lua provided by RyzenAPI
-- Game: Game: Adventuring With Matilda!

-- MAIN APPLICATION
addappid(3329430)
-- Game: addappid(3329430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3329431, 1, "1fd2774b5c9b85764e11260ad6db78cde8fec6a27f33fd770d1df0ea6f2be5f0")
addappid(3329432, 1, "547a321e12a7706896c579e9dd79d12e97ee88f07138a386772e4a122036dc68")
addappid(3329433, 1, "a1bee8af67c44a59fecb7f5357c45d6cbb47834cd593b23333583be97ebb900b")
