-- Lua provided by RyzenAPI
-- Game: addappid(2179030)

-- MAIN APPLICATION
addappid(2179030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179031, 1, "fcde624f1a9ce4f7436758ceed7c56837a7cf6cc4e5e6c3314c29a768d9d36a2")
