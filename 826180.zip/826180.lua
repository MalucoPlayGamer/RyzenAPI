-- Lua provided by RyzenAPI
-- Game: 826180

-- MAIN APPLICATION
addappid(826180)
-- Game: addappid(826180)

-- MAIN APP DEPOTS / PACKAGES
addappid(826181, 1, "a0322fceb3a71a71e425a513828d0764a0a005ee04a06b46a5a49714f977f94f")
