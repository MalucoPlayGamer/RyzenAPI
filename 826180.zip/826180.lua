-- Lua provided by SkyAPI 
-- Game: EONIA
addappid(826180)
addappid(826181, 1, "a0322fceb3a71a71e425a513828d0764a0a005ee04a06b46a5a49714f977f94f")
