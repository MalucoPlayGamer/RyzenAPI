-- Lua provided by RyzenAPI
-- Game: EONIA

-- MAIN APPLICATION
addappid(826180)

-- MAIN APP DEPOTS / PACKAGES
addappid(826181, 1, "a0322fceb3a71a71e425a513828d0764a0a005ee04a06b46a5a49714f977f94f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
