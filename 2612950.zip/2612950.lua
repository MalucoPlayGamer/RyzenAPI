-- Lua provided by RyzenAPI
-- Game: Warm Snow - The End Of Karma

-- MAIN APPLICATION
addappid(2612950)
-- Game: addappid(2612950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612951, 1, "8836b7eab3392d6916577bff52e2b164064115d58d59696306e1933c342c8a4c")
addappid(2612952, 1, "a0e808e703d416af24ea88a613a8ff91a92e5508669aeba93c54581e55715569")
