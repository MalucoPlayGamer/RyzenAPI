-- Lua provided by RyzenAPI
-- Game: Super BAWK BAWK Chicken

-- MAIN APPLICATION
addappid(2054850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054851, 1, "9efd6a2f755d835df13e3241509aece2d9d6eb6360b1de8f1b7e5434fa2dd852")

