-- Lua provided by RyzenAPI
-- Game: Game: 21+

-- MAIN APPLICATION
addappid(904990)
-- Game: addappid(904990)

-- MAIN APP DEPOTS / PACKAGES
addappid(904991, 1, "a886ccc2b012bbf99468137e344f7d2a713ad2d759e2ad987540845152313a88")
addappid(904992, 1, "2ed9eabc930b950b55a62dbae81ea1f8de210dc43638aa41e6a86bbff973e66c")
addappid(904993, 1, "601541566a3fb39126c009c07e0be5f89e9cd5edd733e5afc9ffeac07ac4be37")
addappid(920730, 0, "be517b95a2bb0e5ed92a1a011ecc0e0e81601009436cc389186ccc34099079b8")
