-- Lua provided by RyzenAPI
-- Game: 1870120

-- MAIN APPLICATION
addappid(1870120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870120,0,"d77c489362c1dd7cbb33eb191fe54f5eda6b85d10b0c33d9c7cfb51203e80aeb")

