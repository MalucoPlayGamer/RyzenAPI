-- Lua provided by RyzenAPI
-- Game: Bright Memory: Infinite Cheongsam (New Year) DLC

-- MAIN APPLICATION
addappid(1870120)
-- Game: addappid(1870120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870120,0,"d77c489362c1dd7cbb33eb191fe54f5eda6b85d10b0c33d9c7cfb51203e80aeb")
