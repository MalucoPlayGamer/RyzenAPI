-- Lua provided by RyzenAPI
-- Game: Game: AppID 976840

-- MAIN APPLICATION
addappid(976840)
-- Game: addappid(976840)

-- MAIN APP DEPOTS / PACKAGES
addappid(976841, 1, "defc79b8c1adaa84771a30215ee548b48a7b6791f78f7049f8b1092d425fe1e0")
