-- Lua provided by RyzenAPI
-- Game: Game: RetroArch - Beetle Cygne

-- MAIN APPLICATION
addappid(1843660)
-- Game: addappid(1843660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843661, 1, "848c7a98494385123d841bb409146e646f8f9b2294a0df4c4d05131d3650b723")
addappid(1843662, 1, "930b56099cbd152477770d7d6b08751c1a065293cedc73f2bc9e590fb16787a8")
