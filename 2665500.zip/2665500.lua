-- Lua provided by RyzenAPI
-- Game: 2665500

-- MAIN APPLICATION
addappid(2665500)
-- Game: addappid(2665500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665502,0,"7bd1e2f84cefe349e919ad763f8544942bd788fa4d150a94c9c50c6bfde64cb9")
addappid(2665503,0,"c3ffd1baa13289c00e0835d7fe4b2fa80be967efdd2ae368b805c7e5a7b73248")
