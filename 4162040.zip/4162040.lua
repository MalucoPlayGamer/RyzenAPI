-- Lua provided by RyzenAPI
-- Game: Zenless Zone Zero

-- MAIN APPLICATION
addappid(4162040)

