-- Lua provided by RyzenAPI
-- Game: Anime Gas Station

-- MAIN APPLICATION
addappid(1866110)
addappid(1884690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866111, 1, "d3d928ee997ec32a7d704e3904759bcc84d76c770dd688d9faa5ff13fe269fee")
