-- Lua provided by RyzenAPI
-- Game: Strange Night ll

-- MAIN APPLICATION
addappid(767910)

-- MAIN APP DEPOTS / PACKAGES
addappid(767911, 1, "2809f765d3ac4dc0f82fe6f5a4b634b05a4199e0e6452749d05abbd04760a003")

