-- Lua provided by RyzenAPI
-- Game: The motel

-- MAIN APPLICATION
addappid(2829450)
-- Game: addappid(2829450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829452,0,"06bd8a0c2a90131bd299469666eb27a50e642cc58d39b51187bb8631290a16d9")
