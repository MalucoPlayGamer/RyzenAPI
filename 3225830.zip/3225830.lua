-- Lua provided by RyzenAPI
-- Game: 3225830

-- MAIN APPLICATION
addappid(3225830)
-- Game: addappid(3225830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3225831, 1, "23ebc9b3ba64db65d381ebdfe336abe49d124ae66c0c42dada28d694cfbfdc33")
