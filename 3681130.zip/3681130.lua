-- Lua provided by RyzenAPI
-- Game: 閃攻機人アスラ - ASURA THE STRIKER - Soundtrack

-- MAIN APPLICATION
addappid(3681130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3681131, 1, "6cb534ba4d5c1cb122972d4b975d12d953229b57a01c3fbd4383ed7a578b6b0d")
