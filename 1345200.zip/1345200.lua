-- Lua provided by RyzenAPI
-- Game: 1345200

-- MAIN APPLICATION
addappid(1345200)
-- Game: addappid(1345200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345201, 1, "c1b106d7ebeda95d5c7af7ace6fe64e17281e7b26bc06345ee86a066059c92d0")
