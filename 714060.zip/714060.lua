-- Lua provided by RyzenAPI
-- Game: addappid(714060)

-- MAIN APPLICATION
addappid(714060)

-- MAIN APP DEPOTS / PACKAGES
addappid(714061, 1, "7358429ed3eca17eb1d48f29cccd6073a5419e49db13739a7ff1d38927cfb315")
