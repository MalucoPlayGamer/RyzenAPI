-- Lua provided by RyzenAPI
-- Game: AppID 312790

-- MAIN APPLICATION
addappid(312790)
-- Game: addappid(312790)

-- MAIN APP DEPOTS / PACKAGES
addappid(312791, 1, "a5846408b0c6a34c8d0dc134deac6323845a8ac0726fe2818a7f833fa0bfa6e9")
