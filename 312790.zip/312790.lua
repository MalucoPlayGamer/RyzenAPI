-- Lua provided by RyzenAPI
-- Game: Agarest: Generations of War 2

-- MAIN APPLICATION
addappid(312790)
addappid(343420)
addappid(343421)
addappid(343422)
addappid(343423)
addappid(343424)
addappid(343425)
addappid(343426)
addappid(343940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(312791, 1, "a5846408b0c6a34c8d0dc134deac6323845a8ac0726fe2818a7f833fa0bfa6e9")
