-- Lua provided by RyzenAPI
-- Game: AppID 557940

-- MAIN APPLICATION
addappid(557940)

-- MAIN APP DEPOTS / PACKAGES
addappid(557941, 1, "0796cce0c1599a920dcaa7859125b080fb636362b1f5ce9facce97b889ac48c5")

