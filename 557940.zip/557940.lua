-- Lua provided by RyzenAPI
-- Game: AppID 557940

-- MAIN APPLICATION
addappid(557940)

-- MAIN APP DEPOTS / PACKAGES
addappid(557941, 1, "0796cce0c1599a920dcaa7859125b080fb636362b1f5ce9facce97b889ac48c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
