-- Lua provided by RyzenAPI
-- Game: 3013060

-- MAIN APPLICATION
addappid(3013060)
-- Game: addappid(3013060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013061, 1, "1a208e9a56e6947cd033c3af8f6d2ea2ec103ea2bba1899565f268913df2ea9d")
