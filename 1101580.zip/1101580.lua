-- Lua provided by RyzenAPI
-- Game: 1101580

-- MAIN APPLICATION
addappid(1101580)
-- Game: addappid(1101580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101581, 1, "d47ee61b60cfd720958360630fb8cfa259e336dc5ef4656bdb80426e8d7710d8")
