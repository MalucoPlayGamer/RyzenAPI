-- Lua provided by RyzenAPI
-- Game: addappid(498340)

-- MAIN APPLICATION
addappid(498340)

-- MAIN APP DEPOTS / PACKAGES
addappid(498341, 1, "7365644aaeb8a84d2a905930f699c0a132b68d759f2e4aab8388748e0715ffca")
