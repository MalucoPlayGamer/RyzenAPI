-- Lua provided by SkyAPI 
-- Game: StarBreak
addappid(420790)
addappid(420791, 1, "165048d4054ad1b05ac73be5d91759aad569d284c9f60d5315fa228823b6ed5a")
addappid(420792, 1, "bd9e9a136e0e91abe7212ab285e445ee6b5b89484450115f6af7f9f195ed2c4b")
addappid(420793, 1, "32f71d7ddab08b972b712d947aaeec4ac217dae867e0880c1e5a7ec39dee0d96")
addappid(420794, 1, "b44ad31e384e7b03340e1b2482d8a44be34dad096079c0f9dae81e9d0fbdcbe0")
