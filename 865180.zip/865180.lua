-- Lua provided by RyzenAPI
-- Game: Reformers Intl Ver(变革者国际版)

-- MAIN APPLICATION
addappid(865180)

-- MAIN APP DEPOTS / PACKAGES
addappid(865181, 1, "5a78232cbf32f5da447cc8ffdb75850da24227265aac75609ab58678b4337549")
