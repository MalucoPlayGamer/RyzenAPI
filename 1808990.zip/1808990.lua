-- Lua provided by RyzenAPI
-- Game: Boyfriend Dungeon Art Book

-- MAIN APPLICATION
addappid(1808990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808990,0,"1ea1e42fed9e54ece0707b2e7169dfb97bc458eaca1967cfa950a2a2ca077862")
