-- Lua provided by RyzenAPI
-- Game: Deep Fishing

-- MAIN APPLICATION
addappid(1648550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648551, 1, "f8d5ae20693d19090d734eca7f7366ce96f1381ddd5ec8e25f7e565eb81d6ec5")

