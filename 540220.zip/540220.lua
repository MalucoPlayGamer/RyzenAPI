-- Lua provided by RyzenAPI
-- Game: AIRHEART - The Original Soundtrack

-- MAIN APPLICATION
addappid(540220)

-- MAIN APP DEPOTS / PACKAGES
addappid(540220,0,"1e5a7ce4ccda033733b372540a2ab77530f7cd41d33793c243028a4e765f5023")

