-- Lua provided by RyzenAPI 
-- Game: AppID 969870
addappid(969870)
addappid(969871, 1, "a4099aa60fadb2b78bc8a4e5a332e466e1af32d588400915ddefe56d2741da29")
addappid(1002250, 0, "8af7de4f71d48e0e196df9e1f301a4d6a36aeda3180e2d36697666b8ecdb4637")
addappid(1127300, 0, "1ed8918fa10a72fc6f38f5642034ecee6c7741ee6946355e0c3d07542c3fc9a5")
