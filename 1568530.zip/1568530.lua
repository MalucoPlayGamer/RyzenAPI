-- Lua provided by RyzenAPI
-- Game: Realife Simulator

-- MAIN APPLICATION
addappid(1568530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1577488,0,"bd3061f2765da69f12a61c85cb4874e876c7f05b992c43861e5d363748bf996e")

