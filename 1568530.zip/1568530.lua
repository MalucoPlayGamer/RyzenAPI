-- Lua provided by RyzenAPI
-- Game: Realife Simulator

-- MAIN APPLICATION
addappid(1568530)
-- Game: addappid(1568530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1577488,0,"bd3061f2765da69f12a61c85cb4874e876c7f05b992c43861e5d363748bf996e")
