-- Lua provided by RyzenAPI
-- Game: Bargain Platformer

-- MAIN APPLICATION
addappid(2162970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162971, 1, "e7cf366a10a17a8bd0bd3026d65b12221ac8475e2f5bb80ac09161e779daeb67")
