-- Lua provided by RyzenAPI
-- Game: Moons of Ardan

-- MAIN APPLICATION
addappid(1694260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694261, 1, "8c928c11a04b77087e2ec8215c50891c71cd41661420f250e696c1fb0e44eaf9")
addappid(1694262, 1, "a6eb55b1f0ba61e85985909f09b8770e74eb3186f6aa724323d35efba950958f")
addappid(1694263, 1, "5ad9ecfae7cf9096821ee22c0cd73fbbb1f6c2dd40a285ed054cd2204966a07f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
