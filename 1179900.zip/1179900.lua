-- Lua provided by RyzenAPI
-- Game: Cat Quest II Demo

-- MAIN APPLICATION
addappid(1179900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179901, 1, "1a7986d0e581dc6397b6a44c4b2803d817a52124905bfd772f61eac5f40cd2dc")

