-- Lua provided by RyzenAPI
-- Game: 2364140

-- MAIN APPLICATION
addappid(2364140)
-- Game: addappid(2364140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364141, 1, "708505038706e5f98f26ed6d84aae0d25ae1896d54bd78d0447765be35ed09e5")
