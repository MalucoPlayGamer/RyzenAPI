-- Lua provided by RyzenAPI
-- Game: 786990

-- MAIN APPLICATION
addappid(786990)
-- Game: addappid(786990)

-- MAIN APP DEPOTS / PACKAGES
addappid(786991, 1, "acd65b160af517c82831d4d154fda549b7520fa1bea0a5548e277cf1068e5043")
