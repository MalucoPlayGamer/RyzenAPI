-- Lua provided by RyzenAPI
-- Game: addappid(1805240)

-- MAIN APPLICATION
addappid(1805240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805241, 1, "45993495d99ae93152a2e2dda3ab68cd33e5fbd5c90fa67797fa625304dfa075")
