-- Lua provided by RyzenAPI
-- Game: Layer Section™ & Galactic Attack™ S-Tribute

-- MAIN APPLICATION
addappid(1805240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1805241, 1, "45993495d99ae93152a2e2dda3ab68cd33e5fbd5c90fa67797fa625304dfa075")

