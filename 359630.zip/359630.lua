-- Lua provided by RyzenAPI
-- Game: Independence War® 2: Edge of Chaos

-- MAIN APPLICATION
addappid(359630)

-- MAIN APP DEPOTS / PACKAGES
addappid(359631, 1, "b4bbec6834e634bb6027caf7476a30c1119ec6af0c9eee15dc3f7a29caf39a9c")

