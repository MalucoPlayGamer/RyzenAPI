-- Lua provided by SkyAPI 
-- Game: Independence War® 2: Edge of Chaos
addappid(359630)
addappid(359631, 1, "b4bbec6834e634bb6027caf7476a30c1119ec6af0c9eee15dc3f7a29caf39a9c")
