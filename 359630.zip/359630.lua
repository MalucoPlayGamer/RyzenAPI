-- Lua provided by RyzenAPI
-- Game: 359630

-- MAIN APPLICATION
addappid(359630)
-- Game: addappid(359630)

-- MAIN APP DEPOTS / PACKAGES
addappid(359631, 1, "b4bbec6834e634bb6027caf7476a30c1119ec6af0c9eee15dc3f7a29caf39a9c")
