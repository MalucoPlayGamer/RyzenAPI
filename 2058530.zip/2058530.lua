-- Lua provided by RyzenAPI
-- Game: AppID 2058530

-- MAIN APPLICATION
addappid(2058530)
-- Game: addappid(2058530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058531, 1, "9fe5eae2f846b6b53829d8aa1c6dcae916566c15d364328c78c7bf3f1b3aae0e")
