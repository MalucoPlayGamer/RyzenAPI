-- Lua provided by RyzenAPI
-- Game: A Fishy RPG

-- MAIN APPLICATION
addappid(1787670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787671, 1, "a92f4fb1a5f8fe10821d2ff1d4751f761d3c9c9a8a8b79dd1cf87ccab3656c03")

