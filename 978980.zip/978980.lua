-- Lua provided by SkyAPI 
-- Game: Paradigm Blast
addappid(978980)
addappid(978981, 1, "7eac084bcc10e6c684621fedf268df42520b551e4a7695faeda635d25c3e05a5")
