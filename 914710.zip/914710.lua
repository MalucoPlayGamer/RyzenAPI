-- Lua provided by RyzenAPI
-- Game: Game: AppID 914710

-- MAIN APPLICATION
addappid(914710)
-- Game: addappid(914710)

-- MAIN APP DEPOTS / PACKAGES
addappid(914711, 1, "7a9034278cc1f859bc64f942f36c04f11d114e9073a512cf40c1e14b12682ea3")
