-- Lua provided by RyzenAPI
-- Game: Cat Quest II

-- MAIN APPLICATION
addappid(914710)

-- MAIN APP DEPOTS / PACKAGES
addappid(914711, 1, "7a9034278cc1f859bc64f942f36c04f11d114e9073a512cf40c1e14b12682ea3")
