-- Lua provided by RyzenAPI
-- Game: 1815300

-- MAIN APPLICATION
addappid(1815300)
-- Game: addappid(1815300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815302,0,"4dbb9c70ae4a7ac60788c8b275ec39fe563744a40a5d3df221540d8ce2226cd8")
