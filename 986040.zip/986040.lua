-- Lua provided by RyzenAPI
-- Game: The Unliving

-- MAIN APPLICATION
addappid(986040)
-- Game: addappid(986040)

-- MAIN APP DEPOTS / PACKAGES
addappid(986042,0,"c67de580a47c343ce52a782656ae33d0fc08cb7a2d014355459b9a446ad78d85")
addappid(2190670,0,"aa82c10efa598099db81847a9a786c481440953d3c68e428a0f82c3920e17c7c")
