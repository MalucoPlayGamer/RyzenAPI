-- Lua provided by RyzenAPI
-- Game: The Unliving

-- MAIN APPLICATION
addappid(986040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(986042,0,"c67de580a47c343ce52a782656ae33d0fc08cb7a2d014355459b9a446ad78d85")
addappid(2190670,0,"aa82c10efa598099db81847a9a786c481440953d3c68e428a0f82c3920e17c7c")

