-- Lua provided by RyzenAPI
-- Game: Math Combat Challenge

-- MAIN APPLICATION
addappid(673870)

-- MAIN APP DEPOTS / PACKAGES
addappid(673871,0,"7a255cbff7b5acd3b7e56e0d2a1397e518ad9a817c513c9a6bfa0f3047535a45")
addappid(673872,0,"223647b9c05470de3fda1e4247a728735e7383df3844f633c2f5b28446f1ad07")

