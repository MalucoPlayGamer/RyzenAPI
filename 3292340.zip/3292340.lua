-- Lua provided by RyzenAPI
-- Game: 3292340

-- MAIN APPLICATION
addappid(3292340)
addappid(3734050)
-- Game: addappid(3292340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3292341, 1, "5ca8a714c8700f36f3055986591c56b5c50f85c33d96c07f1e67c56c06c110e9")
