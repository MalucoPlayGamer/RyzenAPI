-- Lua provided by RyzenAPI
-- Game: addappid(2216130)

-- MAIN APPLICATION
addappid(2216130)
addappid(2688710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216131, 1, "29104683ab075f2eedff6b447664c06dabe3bef6769ce61068ca964cabf8ea49")
