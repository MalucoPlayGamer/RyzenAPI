-- Lua provided by RyzenAPI 
-- Game: 沉默的蟋蟀
addappid(2216130)
addappid(2216131, 1, "29104683ab075f2eedff6b447664c06dabe3bef6769ce61068ca964cabf8ea49")
addappid(2688710)
