-- Lua provided by RyzenAPI
-- Game: EXP: War Trauma Demo

-- MAIN APPLICATION
addappid(1812190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812191, 1, "6409f8d40c60b8b85dd06a99895d79702cda6e49f8b672465e0871bf2c991883")

