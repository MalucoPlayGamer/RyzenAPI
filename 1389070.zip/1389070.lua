-- Lua provided by RyzenAPI
-- Game: Game: AppID 1389070

-- MAIN APPLICATION
addappid(1389070)
-- Game: addappid(1389070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389071, 1, "99780b0d49992f2c29ad746f4cb4bc9341f09786338b0a136c00ef07d51a222f")
