-- Lua provided by RyzenAPI
-- Game: AppID 889280

-- MAIN APPLICATION
addappid(889280)

-- MAIN APP DEPOTS / PACKAGES
addappid(889281, 1, "7ebe66527df28cfcd6f544b45b970ac543dd6edea0721d86e4d006cee32fba34")

