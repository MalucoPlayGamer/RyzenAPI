-- Lua provided by RyzenAPI
-- Game: 拖拖拉拉小菲镇 Playtest

-- MAIN APPLICATION
addappid(3223440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3223441, 1, "88faeef3eaabdd03a4250a97b4a9163f9b2e4c234da8a1fb2150d088cd25e5c5")
