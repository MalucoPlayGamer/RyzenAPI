-- Lua provided by RyzenAPI
-- Game: AppID 696180

-- MAIN APPLICATION
addappid(696180)
-- Game: addappid(696180)

-- MAIN APP DEPOTS / PACKAGES
addappid(696181, 1, "a6cd7f44133532a6e87cbcadabe29914aea09748af6347db9fbd61b2955ba444")
