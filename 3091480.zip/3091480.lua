-- Lua provided by RyzenAPI
-- Game: 3091480

-- MAIN APPLICATION
addappid(3091480)
-- Game: addappid(3091480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091481, 1, "9bbadd21f2af3ee16d89c2266f7c762395e69e171b645d40b186021a3a117e39")
