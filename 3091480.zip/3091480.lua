-- Lua provided by RyzenAPI
-- Game: FLOORS

-- MAIN APPLICATION
addappid(3091480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091481, 1, "9bbadd21f2af3ee16d89c2266f7c762395e69e171b645d40b186021a3a117e39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
