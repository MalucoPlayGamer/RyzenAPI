-- Lua provided by SkyAPI 
-- Game: AppID 731310
addappid(731310)
addappid(731311, 1, "31f7475027b3ea7d1208d1ad279d82725f404619a2505b9a006bded2f1b37a54")
