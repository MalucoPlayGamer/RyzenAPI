-- Lua provided by RyzenAPI
-- Game: Game: AppID 731310

-- MAIN APPLICATION
addappid(731310)
-- Game: addappid(731310)

-- MAIN APP DEPOTS / PACKAGES
addappid(731311, 1, "31f7475027b3ea7d1208d1ad279d82725f404619a2505b9a006bded2f1b37a54")
