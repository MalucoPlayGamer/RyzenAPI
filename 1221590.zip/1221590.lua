-- Lua provided by RyzenAPI
-- Game: 1221590

-- MAIN APPLICATION
addappid(1221590)
-- Game: addappid(1221590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221591, 1, "099668b91ba4f573a2087f1f08e9360ec08024bab77d464f6f13c083066cfcf9")
