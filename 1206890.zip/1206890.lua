-- Lua provided by RyzenAPI
-- Game: SkateBIRD Original Soundtrack

-- MAIN APPLICATION
addappid(1206890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206891, 1, "4cd1f06d5124f73af6b4baba63843f609e8c034d1bcdc955b641e04d48563b21")

