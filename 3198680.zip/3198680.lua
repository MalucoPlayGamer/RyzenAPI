-- Lua provided by RyzenAPI
-- Game: Game: Puttler

-- MAIN APPLICATION
addappid(3198680)
-- Game: addappid(3198680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198681, 1, "6af6d224feb8cafd89eaf6c92fa28b5ce47561db59b1d8308893d792d31d4d21")
