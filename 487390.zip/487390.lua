-- Lua provided by RyzenAPI
-- Game: 487390

-- MAIN APPLICATION
addappid(487390)
-- Game: addappid(487390)

-- MAIN APP DEPOTS / PACKAGES
addappid(487391, 1, "1d5b8c5435829f5ba0eb858f2bf732e2fe60e4123aaea7b7c190609e9c889079")
