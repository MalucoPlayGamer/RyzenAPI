-- Lua provided by RyzenAPI
-- Game: setManifestid(530512,"6177173988545694440")

-- MAIN APPLICATION
addappid(530510)
-- Game: addappid(530510)

-- MAIN APP DEPOTS / PACKAGES
addappid(530512,0,"a6b7cb0f5a12e1c4ccf5903bed77095f76fc4024391d7859ff3c2e3daa51248b")
