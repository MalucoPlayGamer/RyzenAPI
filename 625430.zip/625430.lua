-- Lua provided by RyzenAPI
-- Game: Doodle God Blitz

-- MAIN APPLICATION
addappid(625430)
addappid(746180)
addappid(794890)
addappid(819300)
addappid(832100)
addappid(836040)
addappid(844680)
addappid(845130)
addappid(862930)
addappid(862931)
addappid(894860)
addappid(894870)
addappid(915690)
addappid(942360)
addappid(1042440)

-- MAIN APP DEPOTS / PACKAGES
addappid(625431,0,"5a797d69bf3ce5f4b9276826f7092ab63fb30a9ba6e57345abf97a34f2424d74")
addappid(625432,0,"0e863f7d4429d9a671f74d634b8a81a0e105c82bbb7f40332d1cc0772f876e26")
addappid(625433,0,"efd066f74b38c77b973bf4c026c518a619b58d4a66036ec87296e5683961b97a")
addappid(625434,0,"3297cee90235cd6b3dda2d22e6f565b385fe2d01cd93cc38bdd60a70ab391044")
addappid(625435,0,"d5990489274a6332d5034216e8280a404a12aa1a8f2736421e7efadc3679e439")
addappid(625436,0,"dd621858bf963a984d014ea66a035b818cd9d72b7cc3c531780e8d71574e88e7")
addappid(707740,0,"ff6e4c3d09d4212d65edae308879eb6e705d0a2bf75ab5653f99cbd7d33e3ce5")
addappid(726660,0,"dbf26827278c99995b7fe9ed80fdf1423c790072a52017849bd0d8a2b47a3109")
addappid(733880,0,"82d79bb58c4db6c2177869bf956b5619429aab5123942ff1266a3144fbcaa0b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
