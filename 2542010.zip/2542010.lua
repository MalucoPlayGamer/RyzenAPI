-- Lua provided by RyzenAPI 
-- Game: Only Wish
addappid(2542010)
addappid(2542011, 1, "1f96c319422bcb89551d86aeac7d8b84bef33e8a0d48d45d861eed4262089cec")
