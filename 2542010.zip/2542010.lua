-- Lua provided by RyzenAPI
-- Game: Only Wish

-- MAIN APPLICATION
addappid(2542010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542011, 1, "1f96c319422bcb89551d86aeac7d8b84bef33e8a0d48d45d861eed4262089cec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
