-- Lua provided by RyzenAPI
-- Game: addappid(2542010)

-- MAIN APPLICATION
addappid(2542010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542011, 1, "1f96c319422bcb89551d86aeac7d8b84bef33e8a0d48d45d861eed4262089cec")
