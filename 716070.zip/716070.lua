-- Lua provided by RyzenAPI
-- Game: 716070

-- MAIN APPLICATION
addappid(716070)
addappid(716071)
addappid(716073)
addappid(716074)
addappid(716076)

-- MAIN APP DEPOTS / PACKAGES
addappid(716072,0,"3829983719748ba238d6bc572746ca18f2b065e3b360cbfcd0f1116c7fd3cfd4")
addappid(716075,0,"0423e3088d9081299f2acb7d48dcaf0bc3e0ff75e1cd899a0042855d5e4dc678")

