-- Lua provided by RyzenAPI
-- Game: Sue's Story

-- MAIN APPLICATION
addappid(1307200)
-- Game: addappid(1307200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307201, 1, "c53cb5e34dc9c7f50c403ad7b351986fd9cb90b2fe9c7229a16ae9bb3c9e44f8")
