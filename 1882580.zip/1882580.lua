-- Lua provided by RyzenAPI
-- Game: addappid(1882580)

-- MAIN APPLICATION
addappid(1882580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882581, 1, "afe5ec998426740c3a61436c876f95897b8daadf04592b5fb7b5e51f486c69f7")
