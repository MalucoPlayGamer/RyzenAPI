-- Lua provided by SkyAPI 
-- Game: FALL GIRLS
addappid(1882580)
addappid(1882581, 1, "afe5ec998426740c3a61436c876f95897b8daadf04592b5fb7b5e51f486c69f7")
