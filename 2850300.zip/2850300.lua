-- Lua provided by RyzenAPI
-- Game: 坤坤之家

-- MAIN APPLICATION
addappid(2850300)
-- Game: addappid(2850300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850301, 1, "52f8719af4c8c82197fedd5731f58a4bc1ceb9e4042f6953047766a7e9407004")
