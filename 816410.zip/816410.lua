-- Lua provided by RyzenAPI
-- Game: Go Go Poncho!

-- MAIN APPLICATION
addappid(816410)

-- MAIN APP DEPOTS / PACKAGES
addappid(816411,0,"8552e6ef7f2dec92bca804f09cb8c94e1ef43a3eba294821322073726543acbf")

