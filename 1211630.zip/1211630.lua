-- Lua provided by RyzenAPI
-- Game: The Jackbox Party Pack 7

-- MAIN APPLICATION
addappid(1211630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211631, 1, "0232625b6b4d872447085f7024965b2305339e71f439fabf35a04c1bf48e9bbe")
addappid(1211632, 1, "d37ce38e03f4111e4044a9465d4c1a36651a35e4b1991d265dcbfe1eda3fa7e2")
addappid(1211633, 1, "f62c602e58e637d6194925711aca18bacc9b2d6896f51da11b5e83f7556ccb96")
addappid(1211634, 1, "7f3b5ff256fe5dff1c4373c42fbb71b798f31867dd1f24072ba57e399aeb33e8")
addappid(1211635, 1, "b32726b2dc9962a7aa53f963fc491c13f814092e6f0df6bec2ab1cfb34764bc7")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
