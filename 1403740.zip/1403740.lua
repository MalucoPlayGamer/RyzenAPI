-- Lua provided by RyzenAPI
-- Game: Space Architect

-- MAIN APPLICATION
addappid(1403740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1403741, 1, "3798786b29122f525be23456e50a1c5839269d27a4c12ba5a7232e84533f7c4f")

