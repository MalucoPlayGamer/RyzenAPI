-- Lua provided by SkyAPI 
-- Game: Voyage Senki VR 海洋传说 VR
addappid(747210)
addappid(747211, 1, "88c1b0bbdf301a7d91370047755ce2a42c25b666649356e5342188861904909b")
