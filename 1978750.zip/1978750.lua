-- Lua provided by RyzenAPI
-- Game: PHOBOS: PSYCHODEATH 狂死

-- MAIN APPLICATION
addappid(1978750)
addappid(2262670)
addappid(2272910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978752,0,"dcf3ad99fc5165ca0e011525aadbe67c6d105d7f6d0cf85044c17ffad39d7b4b")
addappid(1978753,0,"56ee65698c398fea37df19c9b6a0f79c4c9bd92d6938fe021eeca46992e0366e")

