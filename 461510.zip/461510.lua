-- Lua provided by RyzenAPI
-- Game: Game: Tears of Avia

-- MAIN APPLICATION
addappid(461510)
-- Game: addappid(461510)

-- MAIN APP DEPOTS / PACKAGES
addappid(461511, 1, "2e5799e46a645875469a08e33050c0742c9846f5ddcc90a01def585a5cdab165")
