-- Lua provided by RyzenAPI
-- Game: 念诗姬 Poetry Tuber Demo

-- MAIN APPLICATION
addappid(1673860)
-- Game: addappid(1673860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673861, 1, "9291ecdadf9d4def9bd42e0f2b386b4c208f56dd8dc93d620c7bed523cedac18")
