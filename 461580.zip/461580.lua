-- Lua provided by SkyAPI 
-- Game: Galaxy Cannon Rider
addappid(461580)
addappid(461581, 1, "81aec7c3b71118f299d430e41517bd7f50bc2bac2d2314c704a45bd61d527f1c")
