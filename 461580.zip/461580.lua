-- Lua provided by RyzenAPI
-- Game: addappid(461580)

-- MAIN APPLICATION
addappid(461580)

-- MAIN APP DEPOTS / PACKAGES
addappid(461581, 1, "81aec7c3b71118f299d430e41517bd7f50bc2bac2d2314c704a45bd61d527f1c")
