-- Lua provided by RyzenAPI
-- Game: Drawn™: Dark Flight

-- MAIN APPLICATION
addappid(433360)
-- Game: addappid(433360)

-- MAIN APP DEPOTS / PACKAGES
addappid(433361, 1, "7d51d761b3b9ad53b73d408f492cbc34020d639f611870766e67251fd3013a91")
