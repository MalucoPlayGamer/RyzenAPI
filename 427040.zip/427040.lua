-- Lua provided by RyzenAPI
-- Game: 427040

-- MAIN APPLICATION
addappid(427040)
-- Game: addappid(427040)

-- MAIN APP DEPOTS / PACKAGES
addappid(427041, 1, "cf160e4db974cb625905b1ebc9d1db8650ccfb47167fcdb2e0855405a5b71770")
