-- Lua provided by RyzenAPI
-- Game: AppID 454190

-- MAIN APPLICATION
addappid(454190)

-- MAIN APP DEPOTS / PACKAGES
addappid(454191, 1, "23868e96909a6a04c9224c4ebf3a5f7515b012f28eececd9285fa40e3dbeb447")
addappid(454192, 1, "5eec9a9536d384cc3a42332e8465ea3181910fcaed94c255caeb3094fd80bfd7")
addappid(454193, 1, "2b43b5305b9d5e498608fa68098970f212bd4b92d791a28dd9e680f55cec1dfb")
addappid(454194, 1, "13e0bf4250272d90847fb34ee266f2ec38745952b868067717be8eaab93f29a7")
addappid(454195, 1, "a97c0d7516d23ef46c70055155058df02d16c15ccd865556bf3b7c457ab8c0bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
