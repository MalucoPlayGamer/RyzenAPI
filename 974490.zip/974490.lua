-- Lua provided by RyzenAPI
-- Game: AppID 974490

-- MAIN APPLICATION
addappid(974490)

-- MAIN APP DEPOTS / PACKAGES
addappid(974491, 1, "7aafc8d42fec9231848cd63fa9f53c9c1b25d472c5d5a2760cdddc79bd11d312")

