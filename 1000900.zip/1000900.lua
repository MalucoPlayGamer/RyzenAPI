-- Lua provided by RyzenAPI
-- Game: Zero spring episode 3

-- MAIN APPLICATION
addappid(1000900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000901, 1, "e0e0ac2dd6a36720d2787f9e34c4e972d051b96f6a4c8e769af724f83013e233")
addappid(1000902, 1, "e48d7716dcfa2fe061334c0195d5213faf86ad50c10985c57da42203c9ff3914")
addappid(1000903, 1, "baf23384fb306d1bab2d710f60c1c56ca9d70013c0187d7fa8beeca1035b21e0")
addappid(1000904, 1, "d166bfe9c17240d7a0a07dba9e6db0168ce4e1b636615ba76363443751cfbd13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1060740)
