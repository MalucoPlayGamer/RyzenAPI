-- Lua provided by RyzenAPI
-- Game: ROUNDS

-- MAIN APPLICATION
addappid(1557740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557741, 1, "a6cedd0b2c308a406cddc4573cef3b7f00d14682403b44aa8e355d1c2e44ef44")
