-- Lua provided by RyzenAPI
-- Game: Uncanny Valley

-- MAIN APPLICATION
addappid(359580)
addappid(360140)
-- Game: addappid(359580)

-- MAIN APP DEPOTS / PACKAGES
addappid(359581, 1, "9c2a4f535db3ba7a69b5cb506987b6d1a1c43efe077ef82ae01e47e6c08a87fb")
