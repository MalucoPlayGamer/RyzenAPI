-- Lua provided by RyzenAPI
-- Game: AppID 2864710

-- MAIN APPLICATION
addappid(2864710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864711, 1, "7e5fec1cc87018e39448ff9e98f61d25abf8e8d3e1203b67facb8d17d5d7d385")

