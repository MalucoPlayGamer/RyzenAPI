-- Lua provided by SkyAPI 
-- Game: PokeyPoke Demo
addappid(1326250)
addappid(1326251, 1, "f2234895be843432dd2c206c12a191f4ab7ffb01e25e2720bbf3be05c710cece")
addappid(1326252, 1, "e9061230dae0991a448992e018660947a43d0de35b4657f98e17c21026999368")
