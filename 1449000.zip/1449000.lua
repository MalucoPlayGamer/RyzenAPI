-- Lua provided by RyzenAPI
-- Game: CALL OF LDPR

-- MAIN APPLICATION
addappid(1449000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449001, 1, "3918b92669e8c5fbd9418d7909d933bfe33efd6cbc066709d0c0b1e0ad25665c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
