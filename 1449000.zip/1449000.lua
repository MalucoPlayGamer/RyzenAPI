-- Lua provided by RyzenAPI
-- Game: 1449000

-- MAIN APPLICATION
addappid(1449000)
-- Game: addappid(1449000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449001, 1, "3918b92669e8c5fbd9418d7909d933bfe33efd6cbc066709d0c0b1e0ad25665c")
