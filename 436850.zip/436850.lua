-- Lua provided by RyzenAPI
-- Game: Game: AppID 436850

-- MAIN APPLICATION
addappid(436850)
addappid(549800)
-- Game: addappid(436850)

-- MAIN APP DEPOTS / PACKAGES
addappid(436851, 1, "9ab8485ef42b71edd7390ff53374126889f582faf8538f1f4171b21d3b94b932")
