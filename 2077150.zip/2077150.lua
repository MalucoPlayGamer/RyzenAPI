-- Lua provided by SkyAPI 
-- Game: AppID 2077150
addappid(2077150)
addappid(2077151, 1, "44f47df0eef156841457929ecc89c92385a584048ddbf2f5ca206a651a6254cb")
