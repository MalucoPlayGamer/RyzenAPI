-- Lua provided by RyzenAPI
-- Game: AppID 2077150

-- MAIN APPLICATION
addappid(2077150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077151, 1, "44f47df0eef156841457929ecc89c92385a584048ddbf2f5ca206a651a6254cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
