-- Lua provided by RyzenAPI
-- Game: AppID 1669110

-- MAIN APPLICATION
addappid(1669110)
-- Game: addappid(1669110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669111, 1, "d7739a13d13710e2977129d8c10a2e705898eb1b741cfdd8ac2915cf97e215c3")
