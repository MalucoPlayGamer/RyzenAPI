-- Lua provided by RyzenAPI 
-- Game: THE KING OF FIGHTERS '97 GLOBAL MATCH Soundtrack
addappid(1940670)
addappid(1940671, 1, "4af5d4fb4f6764e1b0e306e35ab3608a152d429c7448440c443b9a9af959454f")
addappid(1940672, 1, "fb12967f7b7ec5447c0cb961522e7b2e4e13fb5eb3f89459b8228c90d9274c5d")
