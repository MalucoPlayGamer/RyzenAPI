-- Lua provided by RyzenAPI
-- Game: addappid(816280)

-- MAIN APPLICATION
addappid(816280)

-- MAIN APP DEPOTS / PACKAGES
addappid(816281, 1, "3dc0faecfb2532abc744b1495f6e75264e37f633bda11fe75e08a6c158bc223f")
