-- Lua provided by RyzenAPI
-- Game: Amora

-- MAIN APPLICATION
addappid(816280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(816281, 1, "3dc0faecfb2532abc744b1495f6e75264e37f633bda11fe75e08a6c158bc223f")

