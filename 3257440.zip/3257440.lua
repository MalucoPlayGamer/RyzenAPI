-- Lua provided by RyzenAPI
-- Game: 咒语回声 试用版

-- MAIN APPLICATION
addappid(3257440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257441, 1, "9bee057af548be0de40fcb1880893d756283c306ebb9d2c546437e57f6063fdb")
