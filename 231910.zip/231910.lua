-- Lua provided by RyzenAPI
-- Game: Leisure Suit Larry in the Land of the Lounge Lizards: Reloaded

-- MAIN APPLICATION
addappid(231910)
-- Game: addappid(231910)

-- MAIN APP DEPOTS / PACKAGES
addappid(231912,0,"012da791a00f2dc25dc4bb1a2fdee8a684950d587f261f505fd812c7ecdd64aa")
addappid(231913,0,"3bc5f81b83f065e3bc39cb8d27942725ed957ac69be18ff72fd99b95a13b8646")
addappid(231914,0,"7d286b3629bc1e0dfdb3b599346a39526e29e2c8225f542693f7bda73846a69d")
addappid(231915,0,"a4c2a702989dc8249f6fdf3a58db4aade53dd8e438f9ad4d3b826ef94d623e6f")
