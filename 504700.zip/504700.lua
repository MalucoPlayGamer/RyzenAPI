-- Lua provided by RyzenAPI
-- Game: Game: Blockships

-- MAIN APPLICATION
addappid(504700)
-- Game: addappid(504700)

-- MAIN APP DEPOTS / PACKAGES
addappid(504701, 1, "834e36da4f99feff54ddc08ace47eeb42f47bf5fd454e3c33898bec0bbd6e644")
addappid(504702, 1, "f20430138fc448843023fcc902b069e3ecbf2ef7266682cecfe37cb1432555cf")
