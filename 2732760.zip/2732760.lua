-- Lua provided by SkyAPI 
-- Game: Follow the meaning Demo
addappid(2732760)
addappid(2732761, 1, "08242afa9f5cf247f59ce0748483c3a6eb9fca18a1d6521b687ba1cd1b8c0fc0")
