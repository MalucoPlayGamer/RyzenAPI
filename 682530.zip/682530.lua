-- Lua provided by RyzenAPI
-- Game: Game: MarZ: Tactical Base Defense

-- MAIN APPLICATION
addappid(682530)
-- Game: addappid(682530)

-- MAIN APP DEPOTS / PACKAGES
addappid(682531, 1, "4163b3fd8968075b0bf78bc01f101d82ec96281e74734c46e31d7d2651b93995")
