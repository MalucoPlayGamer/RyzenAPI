-- Lua provided by SkyAPI 
-- Game: Grimm: Dark Legacy
addappid(536640)
addappid(536641, 1, "1d8f1122c6769e724a3a5a91c5c902968b11450ce161cd5a8a274801d7498620")
addappid(536642, 1, "73d238d27c330263208c7fd1c72f6f61a988ac2de1009163af62399503c32e30")
