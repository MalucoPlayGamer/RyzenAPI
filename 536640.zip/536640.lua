-- Lua provided by RyzenAPI
-- Game: Grimm: Dark Legacy

-- MAIN APPLICATION
addappid(536640)

-- MAIN APP DEPOTS / PACKAGES
addappid(536641, 1, "1d8f1122c6769e724a3a5a91c5c902968b11450ce161cd5a8a274801d7498620")
addappid(536642, 1, "73d238d27c330263208c7fd1c72f6f61a988ac2de1009163af62399503c32e30")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
