-- Lua provided by RyzenAPI
-- Game: Game: Grimm: Dark Legacy

-- MAIN APPLICATION
addappid(536640)
-- Game: addappid(536640)

-- MAIN APP DEPOTS / PACKAGES
addappid(536641, 1, "1d8f1122c6769e724a3a5a91c5c902968b11450ce161cd5a8a274801d7498620")
addappid(536642, 1, "73d238d27c330263208c7fd1c72f6f61a988ac2de1009163af62399503c32e30")
