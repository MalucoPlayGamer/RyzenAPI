-- Lua provided by RyzenAPI
-- Game: DeadPoly Dedicated Server

-- MAIN APPLICATION
addappid(2208380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208381, 1, "d3d4ab72c2245b79a7c7fe2e7f708bac12f4a6a6838bb628bf72dd3decb55d9f")
