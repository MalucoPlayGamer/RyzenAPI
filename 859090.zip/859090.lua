-- Lua provided by RyzenAPI
-- Game: Game: AppID 859090

-- MAIN APPLICATION
addappid(859090)
-- Game: addappid(859090)

-- MAIN APP DEPOTS / PACKAGES
addappid(859091, 1, "ab61328d9178235f8b8dd5a465d79610143f7ffc97d6bb0b6c4917a216b3f443")
