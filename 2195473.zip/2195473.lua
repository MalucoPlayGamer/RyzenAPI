-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2195473)
-- Game: addappid(2195473)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195473,0,"346ef63effc4547e63af7960d7fc0865456702803f46b770bd65663d335ae9ba")
