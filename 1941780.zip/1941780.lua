-- Lua provided by SkyAPI 
-- Game: Zumbi Blocks 2 Open Alpha
addappid(1941780)
addappid(1941781, 1, "c0dd21eacfa642b61bd60e82a6ff6b5487472d65d62b7d606449a6f3b03f2b44")
addappid(1941782, 1, "d82cc1c76c12fbeeb4327e3ac67c7d26e6337aaad9f3de310f70e6ec2c5b92ee")
