-- Lua provided by RyzenAPI
-- Game: Game: Cakey's Twisted Bakery

-- MAIN APPLICATION
addappid(3028500)
-- Game: addappid(3028500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028501, 1, "c17d34cee9e3b321524c63849fcb6ce142a0bd19a0fd8f47279129be624637c8")
