-- Lua provided by RyzenAPI
-- Game: Mini Gardens - Logic Puzzle

-- MAIN APPLICATION
addappid(1905260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905261, 1, "f1929d3fb79a6c9666993f31ed470e5076a67b2085d31d069526aa5060a6aaf0")
