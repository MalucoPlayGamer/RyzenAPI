-- Lua provided by RyzenAPI
-- Game: Hi-Fi RUSH

-- MAIN APPLICATION
addappid(1817230)
addappid(2076280)
addappid(2314670)
addappid(2314700)
addappid(2365950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1817231, 1, "0b72efdcb9381949af6d0260210821349bfd5047d33c3ed7e6a62e5fbbc9c816")
addappid(1817232, 1, "1fd310294fa59e457d3df62891cb2a4b9285b3e6a7d97adad3bdbf70106d4e4f")

