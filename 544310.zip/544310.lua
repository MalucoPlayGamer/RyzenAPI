-- Lua provided by RyzenAPI
-- Game: 544310

-- MAIN APPLICATION
addappid(544310)
-- Game: addappid(544310)

-- MAIN APP DEPOTS / PACKAGES
addappid(544311, 1, "9b0052ee768b2843dce38f51d6d04111ed217fc681e419131501da39cac9ff4b")
