-- Lua provided by RyzenAPI
-- Game: Waifu vs Evil

-- MAIN APPLICATION
addappid(1639340)
-- Game: addappid(1639340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639341, 1, "8d634c9edc63a135743ccfc1ea510d2c0c20c1f487c32c79c7098477e2f269f3")
