-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Space Marine - Anniversary Edition

-- MAIN APPLICATION
addappid(55150)

-- MAIN APP DEPOTS / PACKAGES
addappid(55152,0,"74c1f39841f51827a14de70a58541709448f922375ce843a7bdf8d123b6e00e4")
addappid(55153,0,"850b25c4072739708bdca7603923024a80c5fe87af4984b142e4f39f22c6cf46")
addappid(55155,0,"ff98724747f01ec92ed6c8e62bd0bf8e11ce276e5f909d5ff7975fe0ebe7e3f2")
addappid(55156,0,"d20c26f8b66e6e171ff5541e4904d9cea8a8b45c848f8592c63fe1a600723701")
addappid(55157,0,"d6bdbd0f6bbd5ded437d1ab06542f7999309d1bb8807113d0cf23c70fe29459b")
addappid(55158,0,"0589ec93eaacdccf08c08bc486e0628b191a3f5b9816b1984bcebe65ee9d460f")
addappid(55159,0,"6ffd446547e3c0b5a88ae1f178e6056d4e4f6ead0490e1e441fbc0c23acb5f5a")
addappid(55350,0,"2689a6046c0e45173f9f81caae5665aff0d6bdbdac55a5860de1928953d254fd")
addappid(55351,0,"3ccf6393fc34579c34a59d552874d5df809d92739696265a93f0e13d3dc19a67")
addappid(55352,0,"28fd2935fe1fd88e6137f97473791e92be6fa9b48c89f57327cc313a1b64c976")
addappid(55353,0,"5e9b829e0440fb56a0f7275d56e4efc3a959210117839afbbaf56abf059e679f")
addappid(1769500,0,"e48a10e5dd12fd29d4bf0e838aac1bc7b79dbfbc61cebb0280e79e31015687d0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(55340)
addappid(55341)
addappid(55342)
addappid(55343)
addappid(55344)
addappid(55345)
addappid(55346)
addappid(55347)
addappid(55348)
addappid(55349)
addappid(55470)
addappid(55471)
addappid(55472)
addappid(55473)
addappid(55474)
addappid(55475)
addappid(55476)
