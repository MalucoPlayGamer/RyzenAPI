-- Lua provided by RyzenAPI
-- Game: Kane and Lynch: Dead Men™

-- MAIN APPLICATION
addappid(8080)

-- MAIN APP DEPOTS / PACKAGES
addappid(8081, 1, "283127201d72e69713552fd15c435b78168c1d375a758d937dabf74be882b022")
addappid(8082, 1, "8784945df74c25e35862ce015d4ba848365180f39c07cf2b0362799f24932c31")
addappid(8083, 1, "630b021c6d8571e6e1e24515915ec317dca405978ce7ac6cd7b55255875c1a6d")
addappid(8084, 1, "b2adf48ceb0d5618fad9b208266a2f4965d1439c5479ae5d04e61018d7d43d7a")
addappid(8085, 1, "867f1938a3246975dde85883b34f612ae1e673ba759aadbf87cbf2018028c317")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
