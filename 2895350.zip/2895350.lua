-- Lua provided by RyzenAPI
-- Game: Tactical Mission: Target Rush

-- MAIN APPLICATION
addappid(2895350)
-- Game: addappid(2895350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895351, 1, "843b4aab25219e7abc5ebd2efecff62ebf7d825aa24e97d23986498394329b21")
