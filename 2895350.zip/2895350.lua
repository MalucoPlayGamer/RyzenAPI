-- Lua provided by RyzenAPI
-- Game: Tactical Mission: Target Rush

-- MAIN APPLICATION
addappid(2895350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895351, 1, "843b4aab25219e7abc5ebd2efecff62ebf7d825aa24e97d23986498394329b21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
