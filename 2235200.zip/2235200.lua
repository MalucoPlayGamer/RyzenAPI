-- Lua provided by RyzenAPI
-- Game: 2235200

-- MAIN APPLICATION
addappid(2235200)
-- Game: addappid(2235200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235201, 1, "64b6a7741dff52341709bb548d844f5cbfb4d551a165eba90db90d49ca88586c")
