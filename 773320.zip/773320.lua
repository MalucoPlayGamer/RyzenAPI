-- Lua provided by RyzenAPI
-- Game: TcNo TimeKeeper

-- MAIN APPLICATION
addappid(773320)

-- MAIN APP DEPOTS / PACKAGES
addappid(773321, 1, "aa54faaa333e09684e0402615aeff3a01e1c31120f3d0ef16f21fc0845370713")

