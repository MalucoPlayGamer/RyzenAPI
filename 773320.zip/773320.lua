-- Lua provided by RyzenAPI
-- Game: TcNo TimeKeeper

-- MAIN APPLICATION
addappid(773320)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(773321, 1, "aa54faaa333e09684e0402615aeff3a01e1c31120f3d0ef16f21fc0845370713")

