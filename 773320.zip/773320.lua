-- Lua provided by SkyAPI 
-- Game: TcNo TimeKeeper
addappid(773320)
addappid(773321, 1, "aa54faaa333e09684e0402615aeff3a01e1c31120f3d0ef16f21fc0845370713")
