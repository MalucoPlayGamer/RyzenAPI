-- Lua provided by RyzenAPI
-- Game: Bitburner

-- MAIN APPLICATION
addappid(1812820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812821, 1, "9e5877bbbdf4e398d4fbbc598eac2e1641f8f1c27bb66a98e8a9e9a90e2c50b8")
addappid(1812822, 1, "51a246fc57ffbdcc952d6fa6021bf9c53050fc8619abd41a0c2859874216a8af")
addappid(1812823, 1, "c952b51f6250fa5c587d2658b694aa759a51085719be37431086a3fb4f3aed33")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
