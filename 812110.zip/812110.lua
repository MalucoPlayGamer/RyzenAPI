-- Lua provided by RyzenAPI
-- Game: Alice in Wonderland - Hidden Objects

-- MAIN APPLICATION
addappid(812110)

-- MAIN APP DEPOTS / PACKAGES
addappid(812111, 1, "c6c65a6b6d883b1fa9ecbb71fdb00aed272f2560f6d6c5c9001b42f3c70957ee")
