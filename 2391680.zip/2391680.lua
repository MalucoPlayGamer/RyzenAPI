-- Lua provided by RyzenAPI
-- Game: addappid(2391680)

-- MAIN APPLICATION
addappid(2391680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391681, 1, "6555f23d6b555ae5f090844ae8b9ffde79c95ce28b7f8122789a69845dd9a0c7")
