-- Lua provided by SkyAPI 
-- Game: OSES
addappid(704990)
addappid(704991, 1, "4e46fd5957a0d35e1bd65af9d0cc326a03a840d76aebfd5a3c81db759792edfd")
