-- Lua provided by RyzenAPI
-- Game: OSES

-- MAIN APPLICATION
addappid(704990)
-- Game: addappid(704990)

-- MAIN APP DEPOTS / PACKAGES
addappid(704991, 1, "4e46fd5957a0d35e1bd65af9d0cc326a03a840d76aebfd5a3c81db759792edfd")
