-- Lua provided by RyzenAPI
-- Game: Game: Immortal Legacy: The Jade Cipher

-- MAIN APPLICATION
addappid(1217220)
-- Game: addappid(1217220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217221, 1, "9db147cda40ac1fe55c1ef1ec67da2a8a088f5f352342be66300c5229b236b2d")
