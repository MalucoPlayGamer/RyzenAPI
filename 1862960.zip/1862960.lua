-- Lua provided by RyzenAPI
-- Game: Vestige

-- MAIN APPLICATION
addappid(1862960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862961, 1, "e1e1245aed152a8f55f125823857d4070f991b8a87e886bcedbdb7c8fb87c1f9")

