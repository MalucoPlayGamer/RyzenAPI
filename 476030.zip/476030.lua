-- Lua provided by SkyAPI 
-- Game: AppID 476030
addappid(476030)
addappid(476031, 1, "4d2bce6d54cea16e1435f23f06c6501998f87f3e265045c2fd80fb12b404cf2a")
