-- Lua provided by RyzenAPI
-- Game: addappid(476030)

-- MAIN APPLICATION
addappid(476030)

-- MAIN APP DEPOTS / PACKAGES
addappid(476031, 1, "4d2bce6d54cea16e1435f23f06c6501998f87f3e265045c2fd80fb12b404cf2a")
