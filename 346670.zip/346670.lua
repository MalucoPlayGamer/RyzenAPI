-- Lua provided by SkyAPI 
-- Game: AppID 346670
addappid(346670)
addappid(346671, 1, "87f9ac1d32d874298c7bf526ebe8bba64961a9c176a5ea5351aed316510bbd91")
addappid(346672, 1, "d386ed20a7025f4ef0f7d88cb6cc960034f26a4e070106aa7587140b63c82cf0")
addappid(346673, 1, "65ca7cc4f5eda65515dbdfa5c305be4cb00ea710c5eda779a3b64c9ebda810eb")
