-- Lua provided by RyzenAPI
-- Game: Game: Seek

-- MAIN APPLICATION
addappid(3193730)
-- Game: addappid(3193730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193731, 1, "eb9694b2cc21d4697b6b4f58a3d215705eb558ddc58099e10298688011457c69")
