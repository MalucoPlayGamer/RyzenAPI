-- Lua provided by RyzenAPI
-- Game: The Days Without Gods

-- MAIN APPLICATION
addappid(1983270)
-- Game: addappid(1983270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983271, 1, "829f7cb37624c2264adcf79c9eccee73e107d1719577b41feb4f3ac89d4e8cb6")
