-- Lua provided by RyzenAPI 
-- Game: The Days Without Gods
addappid(1983270)
addappid(1983271, 1, "829f7cb37624c2264adcf79c9eccee73e107d1719577b41feb4f3ac89d4e8cb6")
