-- Lua provided by RyzenAPI 
-- Game: 100-Level Dungeon
addappid(1363020)
addappid(1363021, 1, "2207ba65bb9293692b984d86d8a090be1ed139166a1841fc6090b8fe4d0b90c7")
