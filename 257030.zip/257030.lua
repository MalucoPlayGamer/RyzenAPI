-- Lua provided by RyzenAPI
-- Game: Project Nimbus: Complete Edition

-- MAIN APPLICATION
addappid(257030)
addappid(932470)
addappid(932471)
addappid(932472)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(257031, 1, "14b9ca4589b7020ddd93e6f663502817a97cecd2ded753717f113f80f810b890")
addappid(257032, 1, "c644d7abe1b6e4f2f1d49706145f9028396d38486bb1deaa235c4ff7b311233d")
addappid(257033, 1, "97ed62460add002ae02c22d4f57c3844f26b0422805126654246c7bb1e2b9124")

