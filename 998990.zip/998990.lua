-- Lua provided by RyzenAPI
-- Game: Psyvariar Delta

-- MAIN APPLICATION
addappid(998990)
addappid(1013110)

-- MAIN APP DEPOTS / PACKAGES
addappid(998991, 1, "2de5f7a44d626b02b73fb3d6e896895c0314c404f6abda7d7e43a5f7c112940f")
