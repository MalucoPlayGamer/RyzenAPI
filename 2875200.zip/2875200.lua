-- Lua provided by RyzenAPI
-- Game: Max Mustard Soundtrack

-- MAIN APPLICATION
addappid(2875200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875201, 1, "4899c61b27b351a8369ef90eaf94e4244ce6a6e172512f1dae7d7d6511ca927f")
