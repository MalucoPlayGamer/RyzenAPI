-- Lua provided by RyzenAPI
-- Game: Game: Desta: The Memories Between - Official Soundtrack

-- MAIN APPLICATION
addappid(2299010)
-- Game: addappid(2299010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299011, 1, "2c1c9fc92f0ff7d1d055ee55fc7257afc9c9275835715aa868712611d27bfc20")
addappid(2299012, 1, "7ffd40c94788e4fe4184aaaa074d36855e74171c9814b7393565973784ec7a06")
