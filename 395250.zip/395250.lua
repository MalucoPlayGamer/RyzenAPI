-- Lua provided by RyzenAPI
-- Game: The Adventures of Fatman

-- MAIN APPLICATION
addappid(395250)
-- Game: addappid(395250)

-- MAIN APP DEPOTS / PACKAGES
addappid(395251, 1, "2fa2cc29390b089b20188e7388f8c76dbda8ce8210ae681d8b9f80bf7251a7fc")
