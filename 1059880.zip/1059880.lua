-- Lua provided by RyzenAPI
-- Game: Game: Devious Dungeon

-- MAIN APPLICATION
addappid(1059880)
-- Game: addappid(1059880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059881, 1, "4db42e34df90e954d9db75205c640c96538d47c1d1a42a6eae78f1606263852e")
