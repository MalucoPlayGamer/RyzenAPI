-- Lua provided by RyzenAPI 
-- Game: AppID 439350
addappid(439350)
addappid(439351, 1, "47099bd081f83fc14f620ad434cc0082a479da872108884de4c79eac96093b10")
