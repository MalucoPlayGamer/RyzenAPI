-- Lua provided by RyzenAPI
-- Game: AppID 439350

-- MAIN APPLICATION
addappid(439350)
addappid(717030)
addappid(717031)
addappid(717032)
addappid(846310)
addappid(846400)
addappid(1189480)
addappid(1239110)
addappid(1351100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(439351, 1, "47099bd081f83fc14f620ad434cc0082a479da872108884de4c79eac96093b10")

