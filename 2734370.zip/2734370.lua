-- Lua provided by SkyAPI 
-- Game: 东方崛起
addappid(2734370)
addappid(2734371, 1, "d241587c5674f5603c4a021b1d7bb3b6dd3e3545b945def5051fa75fed694c23")
