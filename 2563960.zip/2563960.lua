-- Lua provided by RyzenAPI
-- Game: Necroslayer

-- MAIN APPLICATION
addappid(2563960)
-- Game: addappid(2563960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563961, 1, "7fd7671957cc497902a5d65dd1ab1bdbb8c525a6e4b5305cc5695a6245bfae2c")
