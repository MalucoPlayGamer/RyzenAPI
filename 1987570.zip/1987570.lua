-- Lua provided by RyzenAPI
-- Game: addappid(1987570)

-- MAIN APPLICATION
addappid(1987570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987571, 1, "8c90786c59bf5ac2811ac12c8285436d43e41aa33323fb5b3a5f9686b2de7106")
