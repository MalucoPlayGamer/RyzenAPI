-- Lua provided by RyzenAPI
-- Game: BootyBuns & 21

-- MAIN APPLICATION
addappid(683440)

-- MAIN APP DEPOTS / PACKAGES
addappid(683441, 1, "3aa00e287fdc832f95b06a6a1e92eef65d0f03523b9c7c3ec63eee744bf9a0e3")

