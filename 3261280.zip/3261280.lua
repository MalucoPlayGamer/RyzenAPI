-- Lua provided by RyzenAPI
-- Game: 3261280

-- MAIN APPLICATION
addappid(3261280)
-- Game: addappid(3261280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261281, 1, "1b9e8770cec5eae361134369f26ed876944ea981c9cf0f345d7f589dfc42e62b")
