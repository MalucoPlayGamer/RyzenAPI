-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: 29 Palms/Captain7 - Airport Nuremberg

-- MAIN APPLICATION
addappid(2969830)
-- Game: addappid(2969830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969830,0,"7521e0a90b3185fff6103173abb40c6c333899f5a59a2e4d303434ff753e3fb8")
