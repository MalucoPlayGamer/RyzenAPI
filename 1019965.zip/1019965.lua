-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Additional Weapon "Tripartite Nunchucks" / 追加武器「三結棍」

-- MAIN APPLICATION
addappid(1019965)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019965,0,"4f376206268a2ca83e65f4c6723248fd4f1cf398f5a0268eeebe061f46ca2ec7")

