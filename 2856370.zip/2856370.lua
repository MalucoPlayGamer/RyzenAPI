-- Lua provided by RyzenAPI
-- Game: Game: Into the Emberlands

-- MAIN APPLICATION
addappid(2856370)
-- Game: addappid(2856370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856371, 1, "7185725005b8328347ffa0667156000e7d9e8efdd3271c663fc7b54cd2c67aa0")
addappid(2904410, 0, "d0e3824cdb74a5fb07b1e53b6225b418b6a5b6675ed6326af136d2f7d3176b42")
