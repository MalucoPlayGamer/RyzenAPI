-- Lua provided by RyzenAPI
-- Game: addappid(1841240)

-- MAIN APPLICATION
addappid(1841240)
addappid(1841243)
addappid(1841244)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841242,0,"e150800a581d326ca7167683a140a2bf62e2b714ff1966830cc8707cc88d23d1")
