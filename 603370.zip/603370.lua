-- Lua provided by RyzenAPI
-- Game: AppID 603370

-- MAIN APPLICATION
addappid(603370)

-- MAIN APP DEPOTS / PACKAGES
addappid(603371, 1, "0f65d32423a7e0714f39de095e5a6648b110c929979f1febbeaa1c0fed1fb3be")
