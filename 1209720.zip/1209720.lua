-- Lua provided by RyzenAPI
-- Game: Machina of the Planet Tree -Unity Unions-

-- MAIN APPLICATION
addappid(1209720)
-- Game: addappid(1209720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209721, 1, "31891a66491ab0e5576fbebeb2a87aeee3d93e53abb7c1f8af8fb66e7616f352")
