-- Lua provided by RyzenAPI
-- Game: Morkull Ragast's Rage Demo

-- MAIN APPLICATION
addappid(2643440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643441, 1, "bf6818dff0cbf9d73cdc5cc460cdc687cba6e9944d00c522f087e38bc2be9202")

