-- Lua provided by RyzenAPI
-- Game: Afternoon Affairs & Helpless Housewives

-- MAIN APPLICATION
addappid(4237210)

-- MAIN APP DEPOTS / PACKAGES
addappid(4237211,0,"c17f155d11339a4cb02b6e4cd9f792a2ee22c4454a257a2eb019a701855865ad")
addappid(4237212,0,"7fa1690645bf9dcd09d7ba14787d6c22182ed9982ccdc3331bd6c893543dd339")
addappid(4237213,0,"04d7296505e37b7cf8191582349321eeac7220d38bf5f355ec1ec51add4fd553")

