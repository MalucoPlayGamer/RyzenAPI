-- Lua provided by RyzenAPI
-- Game: addappid(915230)

-- MAIN APPLICATION
addappid(915230)

-- MAIN APP DEPOTS / PACKAGES
addappid(915231, 1, "24f27ff472a9e3d79a910253bd0e727266c032fb5d0a5a7e30f88f67284be20e")
