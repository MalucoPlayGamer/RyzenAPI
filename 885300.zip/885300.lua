-- Lua provided by RyzenAPI
-- Game: AppID 885300

-- MAIN APPLICATION
addappid(885300)

-- MAIN APP DEPOTS / PACKAGES
addappid(885301, 1, "a977ac377f040fbb3c3b71ac4f1d942db60bd7b68acca142ff99a7bf2751d9f9")

