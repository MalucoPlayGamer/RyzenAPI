-- Lua provided by RyzenAPI
-- Game: addappid(715020)

-- MAIN APPLICATION
addappid(715020)

-- MAIN APP DEPOTS / PACKAGES
addappid(715021, 1, "09aa64b3a978270dffabc52b51e6abad93fa255d973e7605cb60449098283613")
