-- Lua provided by RyzenAPI
-- Game: Game: 幻恋夜宴Guide Book: 秘传·古明地无心流秘籍 None-Heart Secret Sword

-- MAIN APPLICATION
addappid(2653140)
-- Game: addappid(2653140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653141, 1, "149c234e65d978baf98b0f088119541e7d8ba7d1e7a256e1cbfa8ed1f37e776e")
