-- Lua provided by RyzenAPI
-- Game: Legends of the Universe - StarCore

-- MAIN APPLICATION
addappid(482330)

-- MAIN APP DEPOTS / PACKAGES
addappid(482331, 1, "21e5d841e9dad1f8897d327f9ce5a3bb958d8fbc01896a1abf776b960ed163ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
