-- Lua provided by RyzenAPI
-- Game: 482330

-- MAIN APPLICATION
addappid(482330)
-- Game: addappid(482330)

-- MAIN APP DEPOTS / PACKAGES
addappid(482331, 1, "21e5d841e9dad1f8897d327f9ce5a3bb958d8fbc01896a1abf776b960ed163ab")
