-- Lua provided by RyzenAPI
-- Game: Letters of Bernard Thorne

-- MAIN APPLICATION
addappid(2984860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984861, 1, "4e6a1a96100cd0341e0b9f26ef70b8faa535c0c46ec709920406a1f6dc08846f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
