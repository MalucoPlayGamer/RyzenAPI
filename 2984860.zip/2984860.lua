-- Lua provided by SkyAPI 
-- Game: Letters of Bernard Thorne
addappid(2984860)
addappid(2984861, 1, "4e6a1a96100cd0341e0b9f26ef70b8faa535c0c46ec709920406a1f6dc08846f")
