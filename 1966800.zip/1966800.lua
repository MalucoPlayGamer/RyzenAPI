-- Lua provided by RyzenAPI
-- Game: Game: The Den of Chaos2 - 混沌の魔窟殿２～アッサマラームの遺跡編～

-- MAIN APPLICATION
addappid(1966800)
-- Game: addappid(1966800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966801, 1, "48bc30d6edf172a77378b9997fe08822b26e4f6b21059bd8619dd1e9829ccb9d")
