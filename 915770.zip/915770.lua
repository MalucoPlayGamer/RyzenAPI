-- Lua provided by RyzenAPI
-- Game: addappid(915770)

-- MAIN APPLICATION
addappid(915770)

-- MAIN APP DEPOTS / PACKAGES
addappid(915771, 1, "b52d1f61f7e6eca7a5b4bef758fa14654d0d7b2cd713e22c8bec383d51fb291a")
