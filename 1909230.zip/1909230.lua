-- Lua provided by RyzenAPI
-- Game: 1909230

-- MAIN APPLICATION
addappid(1909230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909232,0,"bf5598d2e0438cc9a1e56fb8f7747f4d5f2ac4a5ebe965f92ec7eb3150b44c73")
