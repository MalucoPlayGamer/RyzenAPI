-- Lua provided by RyzenAPI
-- Game: Ambulance Life: A Paramedic Simulator

-- MAIN APPLICATION
addappid(1926520)
addappid(3039580)
addappid(3077470)
addappid(3140820)
addappid(3140830)
addappid(3140840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1926521, 1, "8d99afff8971c840af514a5901f2195b6fd5fabb00d1beaa89d547fe2b297787")

