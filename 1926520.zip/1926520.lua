-- Lua provided by RyzenAPI 
-- Game: Ambulance Life: A Paramedic Simulator
addappid(1926520)
addappid(1926521, 1, "8d99afff8971c840af514a5901f2195b6fd5fabb00d1beaa89d547fe2b297787")
