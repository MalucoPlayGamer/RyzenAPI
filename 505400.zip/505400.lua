-- Lua provided by RyzenAPI
-- Game: Game: Diamond Joyce and the Secret of Crystal Cave

-- MAIN APPLICATION
addappid(505400)
-- Game: addappid(505400)

-- MAIN APP DEPOTS / PACKAGES
addappid(505401, 1, "a28b1b9510f59e3fa115badaf6f3aaf7271fb98295c43bcb330baf17a827e779")
