-- Lua provided by RyzenAPI
-- Game: addappid(2933870)

-- MAIN APPLICATION
addappid(2933870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933871, 1, "e48d4ee502338545757bac0b65c4ff5eeaa1d64bc54e41743c7d58827d13bdd8")
