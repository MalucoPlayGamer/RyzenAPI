-- Lua provided by RyzenAPI
-- Game: Mbembe Radio

-- MAIN APPLICATION
addappid(2933870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933871, 1, "e48d4ee502338545757bac0b65c4ff5eeaa1d64bc54e41743c7d58827d13bdd8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
