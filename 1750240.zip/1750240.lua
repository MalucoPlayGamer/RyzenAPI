-- Lua provided by RyzenAPI
-- Game: my MusicOasis

-- MAIN APPLICATION
addappid(1750240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1750241, 1, "a340aa9a5155f5b9f43173772a63c4e3ed9d0e69790303d61558fa9424eb4b71")

