-- Lua provided by RyzenAPI
-- Game: my MusicOasis

-- MAIN APPLICATION
addappid(1750240)
-- Game: addappid(1750240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750241, 1, "a340aa9a5155f5b9f43173772a63c4e3ed9d0e69790303d61558fa9424eb4b71")
