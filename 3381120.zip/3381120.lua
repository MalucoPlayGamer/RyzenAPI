-- Lua provided by RyzenAPI 
-- Game: ZDSimulator
addappid(3381120)
addappid(3381121, 1, "728de21056163f61d9e9347d5812d2dbfd24a3b450348920c66a269e77b23b8f")
