-- Lua provided by RyzenAPI
-- Game: ZDSimulator

-- MAIN APPLICATION
addappid(3381120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381121, 1, "728de21056163f61d9e9347d5812d2dbfd24a3b450348920c66a269e77b23b8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3542730)
addappid(3542740)
addappid(3609190)
addappid(3609200)
addappid(3609210)
addappid(3609220)
addappid(3609230)
addappid(3609240)
addappid(3614750)
addappid(3614760)
addappid(3614770)
addappid(3614780)
addappid(3614790)
addappid(3614800)
addappid(3614810)
addappid(3614820)
addappid(3614830)
addappid(3614840)
addappid(3614850)
addappid(3614860)
addappid(3614870)
addappid(3614880)
addappid(3614890)
addappid(3614910)
addappid(3614920)
addappid(3614930)
addappid(3614940)
addappid(3615040)
addappid(3894010)
addappid(3894420)
addappid(3894430)
addappid(3980150)
addappid(4114940)
addappid(4139780)
addappid(4158050)
addappid(4366030)
addappid(4524730)
addappid(4735370)
