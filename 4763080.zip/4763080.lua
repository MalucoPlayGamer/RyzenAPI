-- 4763080's Lua and Manifest Created by Hubcap Manifest
-- Pick Ball
-- Created: August 06, 2026 at 14:59:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4763080) -- Pick Ball
-- MAIN APP DEPOTS
addappid(4763081, 1, "f2139da9e3be5d534dc11db18b075189c1208bcae085309c910995f3c9f68596") -- Depot 4763081
setManifestid(4763081, "2368139498819817967", 207475966)