-- Lua provided by RyzenAPI
-- Game: Pick Ball

-- MAIN APPLICATION
addappid(4763080) -- Pick Ball

-- MAIN APP DEPOTS / PACKAGES
addappid(4763081, 1, "f2139da9e3be5d534dc11db18b075189c1208bcae085309c910995f3c9f68596") -- Depot 4763081

