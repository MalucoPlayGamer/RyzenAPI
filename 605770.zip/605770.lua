-- Lua provided by RyzenAPI
-- Game: Luna

-- MAIN APPLICATION
addappid(605770)

-- MAIN APP DEPOTS / PACKAGES
addappid(605771, 1, "8ff2e0df674285678866dc93b5e44ae4547a4dae2419cae6720b46db68b4ec9f")
addappid(605772, 1, "49e1ae0f2515ac6d304e1555bdf6d999519823bf9ede66403e8ae7ac5d8e05e2")
addappid(605773, 1, "cbd4a505c327b861d8e0df70d689dfa19173bd8a2df18b609c707c7ebe2312bd")

