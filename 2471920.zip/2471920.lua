-- Lua provided by RyzenAPI
-- Game: addappid(2471920)

-- MAIN APPLICATION
addappid(2471920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471921, 1, "f0ac2f1256f04a661102fce6c21bc55dbe2349bfb8da8c0791f9bc84d7dc2dbb")
