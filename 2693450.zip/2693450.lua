-- Lua provided by SkyAPI 
-- Game: Not Burned Evil
addappid(2693450)
addappid(2693451, 1, "0fc6bb10626fd0649caff657c1351f50efa7f0752badc76a53c1304db74a1afa")
