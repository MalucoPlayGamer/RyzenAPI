-- Lua provided by RyzenAPI
-- Game: 1636360

-- MAIN APPLICATION
addappid(1636360)
-- Game: addappid(1636360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636361, 1, "72675426a5223dcee6d042fbfccb2ec4ea8190de4d7b34daafc3c1df43bd0ef7")
