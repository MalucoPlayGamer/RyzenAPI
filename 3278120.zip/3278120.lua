-- Lua provided by SkyAPI 
-- Game: Girls Kitchen Dinner
addappid(3278120)
addappid(3278121, 1, "083d0e0bc9ed83860a061c1e15809139db1026680c0bc278c367d1be1f891875")
