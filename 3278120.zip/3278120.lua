-- Lua provided by RyzenAPI
-- Game: Game: Girls Kitchen Dinner

-- MAIN APPLICATION
addappid(3278120)
-- Game: addappid(3278120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278121, 1, "083d0e0bc9ed83860a061c1e15809139db1026680c0bc278c367d1be1f891875")
