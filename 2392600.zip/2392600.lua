-- Lua provided by RyzenAPI 
-- Game: AppID 2392600
addappid(2392600)
addappid(2392601, 1, "773cab9279564584692944026a1799074ce228eb05be8152a960c585279c50e2")
