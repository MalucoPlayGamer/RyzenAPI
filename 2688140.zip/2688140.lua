-- Lua provided by RyzenAPI
-- Game: Amidst The Haze

-- MAIN APPLICATION
addappid(2688140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2688141, 1, "6e47a31b5fa2d68bada128f0b718467c138b6f0b9ae47d2c53d3dbea5a296d21")
