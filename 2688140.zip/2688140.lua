-- Lua provided by RyzenAPI
-- Game: AppID 2688140

-- MAIN APPLICATION
addappid(2688140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688141, 1, "6e47a31b5fa2d68bada128f0b718467c138b6f0b9ae47d2c53d3dbea5a296d21")

