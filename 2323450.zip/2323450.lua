-- Lua provided by RyzenAPI
-- Game: addappid(2323450)

-- MAIN APPLICATION
addappid(2323450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323452,0,"e47663d28994de686deaefca7c0a819ad4b98e355af42fc29a26b79282f86e05")
