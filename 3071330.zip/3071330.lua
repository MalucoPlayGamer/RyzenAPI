-- Lua provided by RyzenAPI 
-- Game: MetalMercs Demo
addappid(3071330)
addappid(3071331, 1, "4734057c93177164f2d3988d1780d9aa01196466f720f7c02b6d6588565ae59c")
addappid(3071333, 1, "64a42178a606332a285d7d971bcc1a24cd64c6df934ca1dac74d581750a71016")
