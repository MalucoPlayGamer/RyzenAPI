-- Lua provided by RyzenAPI
-- Game: Game: Pro Cycling Manager 2018

-- MAIN APPLICATION
addappid(704230)
-- Game: addappid(704230)

-- MAIN APP DEPOTS / PACKAGES
addappid(704231, 1, "509eccd46563ff624cbf0a5221910043b0c6cd9a29364528b2559e6a71578588")
addappid(704232, 1, "8c66dacdfee8caaf11237b03df5ef4f8ba7965b3684a75f8144c873ebdaad2d9")
addappid(704233, 1, "529ee28202371652a00844d7d74969e7c37d38db6181a470fa827f373f671109")
