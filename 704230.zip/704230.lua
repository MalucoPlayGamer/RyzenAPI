-- Lua provided by RyzenAPI
-- Game: Pro Cycling Manager 2018

-- MAIN APPLICATION
addappid(704230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(704231, 1, "509eccd46563ff624cbf0a5221910043b0c6cd9a29364528b2559e6a71578588")
addappid(704232, 1, "8c66dacdfee8caaf11237b03df5ef4f8ba7965b3684a75f8144c873ebdaad2d9")
addappid(704233, 1, "529ee28202371652a00844d7d74969e7c37d38db6181a470fa827f373f671109")

