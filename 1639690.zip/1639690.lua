-- Lua provided by RyzenAPI
-- Game: 1639690

-- MAIN APPLICATION
addappid(1639690)
-- Game: addappid(1639690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639691, 1, "9fd8b4eb2cd6f5fae54c8c532e83a9dc023c442f2925752f438684ab40aeed40")
