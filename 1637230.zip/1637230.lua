-- Lua provided by RyzenAPI
-- Game: METAL MAX Xeno Reborn

-- MAIN APPLICATION
addappid(1637230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637231, 1, "a6f6ef0e69768dc68cdeb78eb651f882f24b433f5732a0ee406c776bbe6efa56")

