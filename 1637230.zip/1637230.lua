-- Lua provided by SkyAPI 
-- Game: METAL MAX Xeno Reborn
addappid(1637230)
addappid(1637231, 1, "a6f6ef0e69768dc68cdeb78eb651f882f24b433f5732a0ee406c776bbe6efa56")
