-- Lua provided by SkyAPI 
-- Game: BIO SECRET
addappid(2659850)
addappid(2659851, 1, "ff2193dd3222133a876a78e0ec52512c6d71d5a3cf55c6c44d673aff5c661624")
addappid(2659852, 1, "1a9ed6c5eb42584c635d70a35b838c999e8bf5ca236c3acdb5a4a7b661d5bc94")
addappid(2659853, 1, "02898a82af37ce7ba7bc1ee574131aac059a51fb644a1c5f7a38ba01158af539")
