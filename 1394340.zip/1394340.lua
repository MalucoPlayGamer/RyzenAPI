-- Lua provided by RyzenAPI
-- Game: AppID 1394340

-- MAIN APPLICATION
addappid(1394340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394341, 1, "b1a6c9b60cfaacecc43fea1a33aa135e50c7341fe298f9dffd87afb21fda4e5b")
addappid(1394342, 1, "e934639fca4b149c25abe2e5417895fd8e3abc911826d1000eb27c25be512480")
