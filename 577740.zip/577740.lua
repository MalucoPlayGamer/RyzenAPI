-- Lua provided by RyzenAPI
-- Game: Game: AppID 577740

-- MAIN APPLICATION
addappid(577740)
-- Game: addappid(577740)

-- MAIN APP DEPOTS / PACKAGES
addappid(577741, 1, "1d19180044ad3d186acf1bd86bdac855223b904dca2235912fd84d0e441bb62b")
addappid(577742, 1, "365621ae472c7c95bd79c5fa334552a531e7de8e83474d01ba983f794ef12031")
