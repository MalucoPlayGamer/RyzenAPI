-- Lua provided by RyzenAPI
-- Game: AppID 577740

-- MAIN APPLICATION
addappid(577740)

-- MAIN APP DEPOTS / PACKAGES
addappid(577741, 1, "1d19180044ad3d186acf1bd86bdac855223b904dca2235912fd84d0e441bb62b")
addappid(577742, 1, "365621ae472c7c95bd79c5fa334552a531e7de8e83474d01ba983f794ef12031")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
