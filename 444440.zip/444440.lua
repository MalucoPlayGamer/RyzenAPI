-- Lua provided by RyzenAPI
-- Game: 444440

-- MAIN APPLICATION
addappid(444440)
-- Game: addappid(444440)

-- MAIN APP DEPOTS / PACKAGES
addappid(444441, 1, "3b91c5c6fdc91f40e770a8c0bd9625dbda4e0b77db00f964c5151ced4ec0daa3")
addappid(444442, 1, "ef99f72704514d265d1349b10b943f57e8a32461319d001211d4fc927dd14e66")
