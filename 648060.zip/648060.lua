-- Lua provided by RyzenAPI
-- Game: Nucvivor

-- MAIN APPLICATION
addappid(648060)

-- MAIN APP DEPOTS / PACKAGES
addappid(648061,0,"28d3931c872c63af8a178fa806e6384874e1454fcd3d053e3d374a7c1968135a")

