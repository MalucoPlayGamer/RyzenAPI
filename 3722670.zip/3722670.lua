-- Lua provided by RyzenAPI
-- Game: One Man´s Trash Demo

-- MAIN APPLICATION
addappid(3722670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722671, 1, "bde06a6cd847522d5fece3ec5f059bbaf23aa787399a2c6d3e2a5cb3bbf71aa3")

