-- Lua provided by RyzenAPI
-- Game: Game: Higurashi When They Cry Hou+

-- MAIN APPLICATION
addappid(2491040)
-- Game: addappid(2491040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491041, 1, "38e879859dcce788c844a5875898b6ebdcc56154cba1019cddca890c2c894d11")
