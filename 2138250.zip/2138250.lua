-- Lua provided by RyzenAPI
-- Game: MELIGO Creator

-- MAIN APPLICATION
addappid(2138250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138251, 1, "3110a1a93b130f3621b19e94bec65a575d5df5e55feb41fd55e131178c3b978a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
