-- Lua provided by RyzenAPI
-- Game: addappid(2138250)

-- MAIN APPLICATION
addappid(2138250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138251, 1, "3110a1a93b130f3621b19e94bec65a575d5df5e55feb41fd55e131178c3b978a")
