-- Lua provided by RyzenAPI
-- Game: Sex Dating Trip

-- MAIN APPLICATION
addappid(1836590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836591, 1, "e8c4a7f54b846e765081a272884ee8fcc05b9a083040b8970c3cef6a73773bdc")

