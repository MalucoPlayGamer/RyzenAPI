-- Lua provided by RyzenAPI
-- Game: GRUEL

-- MAIN APPLICATION
addappid(2882930)
addappid(3354890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882931, 1, "fab78c9499562ddf287a5f7e4d55d2abda90fbaff1236a8052f6f32b323701c6")
