-- Lua provided by RyzenAPI
-- Game: Kizuna AI - Touch the Beat! DLC Costume 2: A.I. Party! 2018

-- MAIN APPLICATION
addappid(2379840)
-- Game: addappid(2379840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379840,0,"101cee81588b7b80c56f0dd0240f6c8d693d8174740b91480cd99aae175517f0")
