-- Lua provided by RyzenAPI
-- Game: Red Ronin

-- MAIN APPLICATION
addappid(1222570)
-- Game: addappid(1222570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222571, 1, "1a4100751d5606dc38cd446da6328645d6ed02f1b6115bac536a2d0216e6ff02")
