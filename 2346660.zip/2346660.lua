-- Lua provided by RyzenAPI
-- Game: DFHack - Dwarf Fortress Modding Engine

-- MAIN APPLICATION
addappid(2346660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2346661, 1, "59bcaafaef9575fef1ff4b1f838b9c591b9506b5ab1224335987b82d220764a0")
addappid(2346662, 1, "48656abe26f495cecbc9af452d2896ddb2ccc1df330786090d2127dec834057b")
addappid(2346663, 1, "a725c976d1fc1e611d852263042bb6256e47ea531ae570ba6e647ad4e3fbd28b")

