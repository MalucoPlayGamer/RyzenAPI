-- Lua provided by RyzenAPI
-- Game: 2768240

-- MAIN APPLICATION
addappid(2768240)
-- Game: addappid(2768240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768241, 1, "691b092eab516df4f19c471cc3c5c66cac870cb3013f699266fef6f31b51c633")
addappid(2768242, 1, "b1c4d5df66cafa67cef3b6bc5694ad2ec39651a2ebac1014392bee407594bc4f")
