-- Lua provided by RyzenAPI
-- Game: Game: AppID 575870

-- MAIN APPLICATION
addappid(575870)
-- Game: addappid(575870)

-- MAIN APP DEPOTS / PACKAGES
addappid(575871, 1, "ea055c0403db6828378bfc5b03bf17d79a040851b5aa964e306f271aaae79143")
addappid(575872, 1, "880b393761bad9b8ef3dc5d1843d3226f018dbf400de0365a4e888eba7afc9f1")
addappid(575874, 1, "8b1f264c569bcc6fe71d9e6047acce3557ef2c318c9f27cc7aa65458799d4ec9")
