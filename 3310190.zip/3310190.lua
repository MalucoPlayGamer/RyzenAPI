-- Lua provided by SkyAPI 
-- Game: Arima Lodge
addappid(3310190)
addappid(3310191, 1, "99e31795ca85fe1b9e7b0833a494c59bf883af22e5b4359227cfd884bba3aa53")
addappid(3310192, 1, "a6e1c0d49afdd494a919119d5f2f4010be0caef8b911df7caf7210e98014475e")
