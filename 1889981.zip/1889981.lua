-- Lua provided by RyzenAPI
-- Game: Pathfinder: Wrath of the Righteous - Through the Ashes

-- MAIN APPLICATION
addappid(1889981)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976050,0,"de6905e768c9fb8f97c7cea5ad097ff50e00240f487ce917e885b069a4d02f0d")
addappid(1976051,0,"4ac6bbe1fa2e510b4cb8bb875d1c069618fa5127a53bc40e4b6d975678ca993e")

