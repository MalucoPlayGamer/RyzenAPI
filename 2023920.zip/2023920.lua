-- Lua provided by RyzenAPI
-- Game: Game: DYSCHRONIA: Chronos Alternate - Dual Edition

-- MAIN APPLICATION
addappid(2023920)
-- Game: addappid(2023920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023921, 1, "6541e10d6f6031064a1134744ff8b5a4f3548d3ffa447bfd18afc71a8846e9a7")
