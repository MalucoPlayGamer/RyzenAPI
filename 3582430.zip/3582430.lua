-- Lua provided by RyzenAPI
-- Game: Uh Oh Airlines

-- MAIN APPLICATION
addappid(3582430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582431,0,"9d66744c453fc63ad2c747d37eefff8eb7ee20d4ecd14e7899e0c79618d43e03")

