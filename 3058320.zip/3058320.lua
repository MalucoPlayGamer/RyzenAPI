-- Lua provided by RyzenAPI 
-- Game: AppID 3058320
addappid(3058320)
addappid(3058321, 1, "38558ce8f3ad4bf1f314db6b804bebb426ac9e41e9795c6f808ceea31c22cf5d")
