-- Lua provided by RyzenAPI 
-- Game: Balance 97.261/100
addappid(2219180)
addappid(2219181, 1, "281eb7e786ffe530387d2fe74a5e0a1a15bb3ccaf318781fed06eaa108de5d8e")
