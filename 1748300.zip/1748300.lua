-- Lua provided by RyzenAPI
-- Game: Dear Monster

-- MAIN APPLICATION
addappid(1748300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748301, 1, "eac0169e0ee908459e9ac0917e4f360f9312174324ad453a27356f3882d5ed79")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2253210)
addappid(2253211)
