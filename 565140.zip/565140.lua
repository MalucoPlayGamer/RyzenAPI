-- Lua provided by RyzenAPI
-- Game: Chimeras: Tune of Revenge Collector's Edition

-- MAIN APPLICATION
addappid(565140)

-- MAIN APP DEPOTS / PACKAGES
addappid(565141,0,"b85f894ee744584637c5b5302956345e204480c7fc481cefc14b38954a2bda78")

