-- Lua provided by RyzenAPI
-- Game: 3443730

-- MAIN APPLICATION
addappid(3443730)
-- Game: addappid(3443730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443731, 1, "eabc53217d4231a743416a3d265d3480f400d0ffcf3c4207f90a8f4937ec5125")
