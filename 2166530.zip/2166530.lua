-- Lua provided by RyzenAPI 
-- Game: Rich Teddy Adventure
addappid(2166530)
addappid(2166531, 1, "14c04a6711943d4284007d6574397dcc47b0d1a9bbf0f9b46cb60ca403d2076e")
