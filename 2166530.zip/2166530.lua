-- Lua provided by RyzenAPI
-- Game: Rich Teddy Adventure

-- MAIN APPLICATION
addappid(2166530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2166531, 1, "14c04a6711943d4284007d6574397dcc47b0d1a9bbf0f9b46cb60ca403d2076e")

