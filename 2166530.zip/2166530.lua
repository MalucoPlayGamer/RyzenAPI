-- Lua provided by RyzenAPI
-- Game: 2166530

-- MAIN APPLICATION
addappid(2166530)
-- Game: addappid(2166530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166531, 1, "14c04a6711943d4284007d6574397dcc47b0d1a9bbf0f9b46cb60ca403d2076e")
