-- Lua provided by RyzenAPI
-- Game: Heroes of Umbra

-- MAIN APPLICATION
addappid(645380)
-- Game: addappid(645380)

-- MAIN APP DEPOTS / PACKAGES
addappid(645381, 1, "6072f47d0a3f32dc54156e2b1db0197afb8ef99c67369e6802fb1c5460bf95f4")
