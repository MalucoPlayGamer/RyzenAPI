-- Lua provided by RyzenAPI
-- Game: Jury - Episode 2: The Trial of Brooke Lafferty

-- MAIN APPLICATION
addappid(2874140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2874140,0,"d465196147698fc878326f9dbee48bc599aa487aa3cd05cb5451e2de4422293d")

