-- Lua provided by RyzenAPI
-- Game: addappid(2874140)

-- MAIN APPLICATION
addappid(2874140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2874140,0,"d465196147698fc878326f9dbee48bc599aa487aa3cd05cb5451e2de4422293d")
