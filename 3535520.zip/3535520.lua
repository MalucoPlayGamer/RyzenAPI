-- Lua provided by RyzenAPI
-- Game: Beat Saber - Kendrick Lamar - "Not Like Us"

-- MAIN APPLICATION
addappid(3535520)
-- Game: addappid(3535520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3535520,0,"166319f4c2d71e2e216fda19e51ee5ff1118e343a5a516a5c0610bb2ff652878")
