-- Lua provided by RyzenAPI
-- Game: Game: Techtonica

-- MAIN APPLICATION
addappid(1457320)
-- Game: addappid(1457320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457321, 1, "062d04b254bb41efe5a03697783de61ac61922ef1db5143bbb6710dc40716ab5")
