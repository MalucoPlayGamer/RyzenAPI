-- Lua provided by RyzenAPI
-- Game: Game: The Guest

-- MAIN APPLICATION
addappid(2506110)
-- Game: addappid(2506110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506111, 1, "a009733b93f814685be6169306369594b9aa322cc448bab7425056bd5d5087da")
