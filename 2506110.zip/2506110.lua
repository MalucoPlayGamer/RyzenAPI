-- Lua provided by RyzenAPI
-- Game: The Guest

-- MAIN APPLICATION
addappid(2506110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506111, 1, "a009733b93f814685be6169306369594b9aa322cc448bab7425056bd5d5087da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
