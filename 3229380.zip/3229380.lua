-- Lua provided by RyzenAPI
-- Game: Game: AppID 3229380

-- MAIN APPLICATION
addappid(3229380)
-- Game: addappid(3229380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229381, 1, "01d6dbf5f25a94d40dc40602140d536c45c9342847107328fe8970a3e8f971ce")
