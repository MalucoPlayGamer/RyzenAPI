-- 4516900's Lua and Manifest Created by Hubcap Manifest
-- Smile Protocol
-- Created: August 08, 2026 at 07:58:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4516900) -- Smile Protocol
-- MAIN APP DEPOTS
addappid(4516901, 1, "c37c916e81215cbc0cfd4e7b2f90ed61c31237ed4125d588e14370451bf6c652") -- Depot 4516901
setManifestid(4516901, "7543704687973481304", 5604680827)