-- Lua provided by RyzenAPI
-- Game: Smile Protocol

-- MAIN APPLICATION
addappid(4516900) -- Smile Protocol

-- MAIN APP DEPOTS / PACKAGES
addappid(4516901, 1, "c37c916e81215cbc0cfd4e7b2f90ed61c31237ed4125d588e14370451bf6c652") -- Depot 4516901

