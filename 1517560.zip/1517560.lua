-- Lua provided by RyzenAPI
-- Game: 1517560

-- MAIN APPLICATION
addappid(1517560)
-- Game: addappid(1517560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517561, 1, "aa555c50353d4494a48bd445e23046538f8a07c9c98db138c5ccecd4f644a881")
