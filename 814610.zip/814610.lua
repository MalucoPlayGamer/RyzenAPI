-- Lua provided by SkyAPI 
-- Game: AppID 814610
addappid(814610)
addappid(814611, 1, "053cf2d7d66c85b1317ec327f5b4e350b81588f2adb470b2ed051d10deb13198")
