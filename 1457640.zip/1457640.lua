-- Lua provided by RyzenAPI
-- Game: Game: 幻想三国志3

-- MAIN APPLICATION
addappid(1457640)
-- Game: addappid(1457640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457641, 1, "3d82cb1d8db7dff32313a9d66e375a542d9f54524341666600ef22e80e4f58ef")
addappid(1457642, 1, "42cb88532bbf4eead479fd9d85b7f53dbd5bd4c1ee90d6e930d1a4bd65839183")
