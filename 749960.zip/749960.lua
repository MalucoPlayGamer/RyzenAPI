-- Lua provided by RyzenAPI
-- Game: AppID 749960

-- MAIN APPLICATION
addappid(749960)
-- Game: addappid(749960)

-- MAIN APP DEPOTS / PACKAGES
addappid(749961, 1, "e99ec159a1a44ccc15c58625d0862719d2e623f9597be4b44d6607b45508a793")
