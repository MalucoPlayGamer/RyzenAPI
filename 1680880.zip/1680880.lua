-- Lua provided by RyzenAPI
-- Game: Forspoken

-- MAIN APPLICATION
addappid(1680880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680881, 1, "3a714f498834b6b17b15fd1864da4a1158074207edbc8e94912f7412adac8f70")
addappid(1680882, 1, "36ab29f55972986cc4c4535ac7249791e305e217339ae47c65fb0816c1f53ab4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1818430)
addappid(1818431)
addappid(1819220)
addappid(1819221)
addappid(1819222)
addappid(1819223)
addappid(1819224)
addappid(2279791)
addappid(2279792)
addappid(2279793)
