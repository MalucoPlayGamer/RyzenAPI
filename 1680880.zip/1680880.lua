-- Lua provided by RyzenAPI
-- Game: Game: Forspoken

-- MAIN APPLICATION
addappid(1680880)
-- Game: addappid(1680880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680881, 1, "3a714f498834b6b17b15fd1864da4a1158074207edbc8e94912f7412adac8f70")
addappid(1680882, 1, "36ab29f55972986cc4c4535ac7249791e305e217339ae47c65fb0816c1f53ab4")
