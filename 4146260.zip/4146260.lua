-- 4146260's Lua and Manifest Created by Hubcap Manifest
-- Monslice
-- Created: August 01, 2026 at 08:38:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4146260) -- Monslice
-- MAIN APP DEPOTS
addappid(4146262, 1, "6f873fc113704b109613f990db17ecc350b27598d65c134edeaaafbceac77638") -- Depot 4146262
setManifestid(4146262, "2435839241062154736", 120253172)