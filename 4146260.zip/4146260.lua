-- Lua provided by RyzenAPI
-- Game: Monslice

-- MAIN APPLICATION
addappid(4146260) -- Monslice

-- MAIN APP DEPOTS / PACKAGES
addappid(4146262, 1, "6f873fc113704b109613f990db17ecc350b27598d65c134edeaaafbceac77638") -- Depot 4146262

