-- Lua provided by RyzenAPI
-- Game: addappid(1185730)

-- MAIN APPLICATION
addappid(1185730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185731, 1, "56a9da546a617f3a6b5079f840cfe231519feb9ea17e8b2eb2af428f2f8a1f77")
