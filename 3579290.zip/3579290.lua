-- Lua provided by RyzenAPI
-- Game: 3579290

-- MAIN APPLICATION
addappid(3579290)
-- Game: addappid(3579290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3579291, 1, "c2d64e8da8db5bc924647e8a325eb5ee870fe08f5b8920e6e2173dde448f7c3c")
