-- Lua provided by RyzenAPI
-- Game: Game: AppID 1977400

-- MAIN APPLICATION
addappid(1977400)
-- Game: addappid(1977400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977401, 1, "79d73000f4d68d4a60640f62de1af493feeabec5c4be2841a78eded9acf04476")
