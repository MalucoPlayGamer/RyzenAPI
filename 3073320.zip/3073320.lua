-- Lua provided by RyzenAPI
-- Game: Color Splash: Horses

-- MAIN APPLICATION
addappid(3073320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073321, 1, "b41e1685c8ff0c08f5665ce076a48ff573f334d514966e58b8f3dd0a4023d41c")

