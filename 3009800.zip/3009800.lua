-- Lua provided by RyzenAPI
-- Game: addappid(3009800)

-- MAIN APPLICATION
addappid(3009800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009801, 1, "76901f0ddafd53dcb190ab3ab9a2885a41a01c36958a554049613d6b8065ccea")
