-- Lua provided by RyzenAPI
-- Game: addappid(1327570)

-- MAIN APPLICATION
addappid(1327570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327571, 1, "99c3ceeb4a9abadb76ebf6bf38b5e5d849a5d039e529664e2b9d643b1e6663f4")
