-- Lua provided by RyzenAPI
-- Game: Game: Tick Tock Bang Bang

-- MAIN APPLICATION
addappid(460650)
-- Game: addappid(460650)

-- MAIN APP DEPOTS / PACKAGES
addappid(460651, 1, "ddb5f7d9ac481bbd022196ba994abcf6e15c1ef3cb72f0f441d94f2a88b4bbd8")
