-- Lua provided by RyzenAPI 
-- Game: MySims™
addappid(3328900)
addappid(3328901, 1, "cd9abf8d8967b437cfc5d367ea79581dcafcac4bb3d985771448a154d25add28")
