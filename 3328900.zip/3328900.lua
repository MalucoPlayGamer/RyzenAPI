-- Lua provided by RyzenAPI
-- Game: MySims™

-- MAIN APPLICATION
addappid(3328900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328901, 1, "cd9abf8d8967b437cfc5d367ea79581dcafcac4bb3d985771448a154d25add28")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
