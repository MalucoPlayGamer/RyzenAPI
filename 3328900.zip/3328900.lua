-- Lua provided by RyzenAPI
-- Game: MySims™

-- MAIN APPLICATION
addappid(3328900)
-- Game: addappid(3328900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328901, 1, "cd9abf8d8967b437cfc5d367ea79581dcafcac4bb3d985771448a154d25add28")
