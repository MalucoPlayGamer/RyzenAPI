-- Lua provided by RyzenAPI
-- Game: Game: 101 Cats in Venice

-- MAIN APPLICATION
addappid(3735890)
-- Game: addappid(3735890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3735891, 1, "a88e1d45ac98fa05a8b7dc2eda68156fdde1f9dd4d99377b9001306264fdb6f5")
