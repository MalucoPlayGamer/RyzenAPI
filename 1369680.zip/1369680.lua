-- Lua provided by RyzenAPI
-- Game: Attack of the Gigant Zombie vs Unity chan - LITE

-- MAIN APPLICATION
addappid(1369680)
-- Game: addappid(1369680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369680,0,"30c1b7226b1328f5db627818dd6f4c0d8e4c11302463af714ede0c760ad6650d")
