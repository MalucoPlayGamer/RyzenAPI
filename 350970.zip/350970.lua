-- Lua provided by RyzenAPI
-- Game: AppID 350970

-- MAIN APPLICATION
addappid(350970)
-- Game: addappid(350970)

-- MAIN APP DEPOTS / PACKAGES
addappid(350971, 1, "f2ceb78491d4dfe4435ebe038e19e10b1ee7c9b2321c68c0de40b0720eed9e55")
addappid(350972, 1, "f9db16af5cb42312b450a9f46c0cb7ef9b8fc696355c0efef10aa082ed3fb575")
