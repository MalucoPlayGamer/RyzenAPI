-- Lua provided by RyzenAPI
-- Game: Game: Plane Accident

-- MAIN APPLICATION
addappid(1682340)
-- Game: addappid(1682340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682341, 1, "9d8dc6e9b546b33e3a2cd0157851cd96060dab29f61fde00f68a36dbd45bb038")
