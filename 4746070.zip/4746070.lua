-- 4746070's Lua and Manifest Created by Hubcap Manifest
-- Eldara
-- Created: June 16, 2026 at 11:04:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4746070) -- Eldara
-- MAIN APP DEPOTS
addappid(4746071, 1, "0cb976c83d6c825b8b75b300f7b83c3574dba297014746d9175afaea3a9a0395") -- Depot 4746071
-- setManifestid(4746071, "395647840754786714", 1421804134)