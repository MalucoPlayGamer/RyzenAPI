-- Lua provided by RyzenAPI
-- Game: Game: AppID 2743490

-- MAIN APPLICATION
addappid(2743490)
-- Game: addappid(2743490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743491, 1, "5b6a4aa7e74c9dafd0d570f98b6f297dea4e5958b39702145f9cbc34c4106a8f")
