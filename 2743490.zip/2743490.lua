-- Lua provided by SkyAPI 
-- Game: AppID 2743490
addappid(2743490)
addappid(2743491, 1, "5b6a4aa7e74c9dafd0d570f98b6f297dea4e5958b39702145f9cbc34c4106a8f")
