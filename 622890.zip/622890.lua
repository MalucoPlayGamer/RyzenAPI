-- Lua provided by RyzenAPI
-- Game: NecroWorm

-- MAIN APPLICATION
addappid(622890)

-- MAIN APP DEPOTS / PACKAGES
addappid(622891, 1, "c11003920b486fb663fc08a0c9d39ee20aabcb97a96cfa51582952b87ecd71a6")

