-- Lua provided by RyzenAPI
-- Game: The Long Survival

-- MAIN APPLICATION
addappid(2366100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366101,0,"8c08d178924b450b49e93975e118b730eebd6a670e4f1f053d3fff85696e9c09")

