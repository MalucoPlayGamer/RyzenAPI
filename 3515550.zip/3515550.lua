-- Lua provided by RyzenAPI
-- Game: addappid(3515550)

-- MAIN APPLICATION
addappid(3515550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515551, 1, "fb9a6a473186e026749119f5ba44c5c40b9bcc1ddf524a756f775a9ba0fc596b")
