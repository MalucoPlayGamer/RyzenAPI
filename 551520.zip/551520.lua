-- Lua provided by SkyAPI 
-- Game: Last Days of Spring 2
addappid(551520)
addappid(551521, 1, "d14ff4fc79203bf96683bcbb9b5aa4b8d1b479e817fdb67009789b6af076abc4")
addappid(551522, 1, "a12d8d8a77fc3d032bbd9df2f922869f48359b55d20ac0c4b3d88f048416b8ee")
addappid(551523, 1, "2c95de3667ea6c7ab3df935c1ce93916fb492a30488bb5f832ef1a25d0811ecb")
addappid(556810)
