-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2661810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661810,0,"7bd373fc14678c76842210cd03ee6c488ca7bc4e7831d90484dd8369133fc5d0")
