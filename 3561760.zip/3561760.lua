-- Lua provided by RyzenAPI
-- Game: Game: 100 Cats Italy

-- MAIN APPLICATION
addappid(3561760)
-- Game: addappid(3561760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561761, 1, "17c24249f96ed3e73e2f897eeb5571a82cdbd16dbba48ad177a7fbdfa766c9df")
