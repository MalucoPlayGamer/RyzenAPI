-- Lua provided by RyzenAPI
-- Game: Game: Vilset

-- MAIN APPLICATION
addappid(1299930)
-- Game: addappid(1299930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299931, 1, "89dc8e0049d980ff729ac9664a4e24557fa683a5617837c51506c96052eabcf7")
