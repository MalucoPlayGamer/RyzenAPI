-- Lua provided by SkyAPI 
-- Game: Vilset
addappid(1299930)
addappid(1299931, 1, "89dc8e0049d980ff729ac9664a4e24557fa683a5617837c51506c96052eabcf7")
