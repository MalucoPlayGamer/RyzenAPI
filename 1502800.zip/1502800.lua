-- Lua provided by RyzenAPI
-- Game: Escape Machine City: Airborne

-- MAIN APPLICATION
addappid(1502800)
-- Game: addappid(1502800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502801, 1, "a65e0133635026cabd912b0d25d18fdf9f46d686ac1949f4a85f480390a5c4d9")
