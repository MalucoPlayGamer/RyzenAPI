-- Lua provided by RyzenAPI
-- Game: NBA THE RUN

-- MAIN APPLICATION
addappid(2866670)
addappid(4799710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866671, 1, "7154869f1d566e3254a00f81174eab7c092954420a07e253597f960fe08494ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
