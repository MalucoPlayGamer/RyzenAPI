-- Lua provided by RyzenAPI
-- Game: 1508960

-- MAIN APPLICATION
addappid(1508960)
addappid(1663420)
-- Game: addappid(1508960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508961, 1, "d988d731cb737ca6dba0daf9e6f28ee10c5fb70abe16e3977b1c894461c19bb5")
