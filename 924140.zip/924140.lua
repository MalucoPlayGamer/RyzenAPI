-- Lua provided by RyzenAPI
-- Game: 924140

-- MAIN APPLICATION
addappid(924140)
-- Game: addappid(924140)

-- MAIN APP DEPOTS / PACKAGES
addappid(924141, 1, "a0aeeafe518dfd9fe18266a852b86ae153f0d19d5f2f9ab1a9081583dca01907")
