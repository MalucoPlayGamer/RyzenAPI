-- Lua provided by RyzenAPI
-- Game: Game: Crime Scene Cleaner Playtest

-- MAIN APPLICATION
addappid(1818060)
-- Game: addappid(1818060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818061, 1, "021e2a318368ed7413e5b7771adde71eb7592d238e4a96a4b02dd54953de4b0e")
