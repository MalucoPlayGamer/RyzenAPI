-- Lua provided by RyzenAPI
-- Game: 8th Heaven

-- MAIN APPLICATION
addappid(2321860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321861, 1, "1279159e1ca3c0df2eed92973c5d0ce480525542ac596081e6f38429d2b9a1f3")
