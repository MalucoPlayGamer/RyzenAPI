-- Lua provided by RyzenAPI
-- Game: Cute Girls Love Books

-- MAIN APPLICATION
addappid(1607570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607571, 1, "cc58708e5466b560a5b231b206727558c0b3e98d305743af40c729f808285c40")
