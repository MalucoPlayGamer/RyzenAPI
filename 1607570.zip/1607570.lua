-- Lua provided by SkyAPI 
-- Game: AppID 1607570
addappid(1607570)
addappid(1607571, 1, "cc58708e5466b560a5b231b206727558c0b3e98d305743af40c729f808285c40")
