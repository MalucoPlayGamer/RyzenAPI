-- Lua provided by SkyAPI 
-- Game: Creed: Rise to Glory™
addappid(804490)
addappid(804491, 1, "b323d74d42cb514292b406453e6635d18c7e2f369d740deffb48478c27da3b9c")
