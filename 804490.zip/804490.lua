-- Lua provided by RyzenAPI
-- Game: Creed: Rise to Glory™

-- MAIN APPLICATION
addappid(804490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(804491, 1, "b323d74d42cb514292b406453e6635d18c7e2f369d740deffb48478c27da3b9c")

