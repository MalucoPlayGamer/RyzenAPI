-- Lua provided by RyzenAPI
-- Game: Creed: Rise to Glory™

-- MAIN APPLICATION
addappid(804490)
-- Game: addappid(804490)

-- MAIN APP DEPOTS / PACKAGES
addappid(804491, 1, "b323d74d42cb514292b406453e6635d18c7e2f369d740deffb48478c27da3b9c")
