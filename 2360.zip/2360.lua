-- Lua provided by RyzenAPI
-- Game: Hexen: Beyond Heretic

-- MAIN APPLICATION
addappid(2360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361, 1, "3a44650f40b43fb0d1bf42d48a4ba586a47d7efaa370130ce37b10a132ec85c3")

