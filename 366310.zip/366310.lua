-- Lua provided by RyzenAPI
-- Game: Game: AppID 366310

-- MAIN APPLICATION
addappid(366310)
-- Game: addappid(366310)

-- MAIN APP DEPOTS / PACKAGES
addappid(366311, 1, "7882971ca4483a337ccac0f38d90c3f437506d16674475f3debb768171733c40")
