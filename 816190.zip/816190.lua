-- Lua provided by RyzenAPI
-- Game: Draw It!

-- MAIN APPLICATION
addappid(816190)
-- Game: addappid(816190)

-- MAIN APP DEPOTS / PACKAGES
addappid(816191, 1, "4c7b9690b7d785295c825111db4718c1a3737726476da0f5f257ae7b0e1b884e")
