-- Lua provided by RyzenAPI
-- Game: Sexy Furry - Raccoon Furry DLC

-- MAIN APPLICATION
addappid(3402060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402060,0,"6278f87edd34e222785ec829fcdcccd98a3ea56362f28dd10dd88b60d4339471")
