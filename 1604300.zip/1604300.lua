-- Lua provided by RyzenAPI
-- Game: Game: LOVE 3

-- MAIN APPLICATION
addappid(1604300)
-- Game: addappid(1604300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604301, 1, "7c58a05c9c4859b3be30e9edbb214d5366577ee4f5c3b455ddc5ebc2b981dd8f")
