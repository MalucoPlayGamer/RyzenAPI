-- Lua provided by RyzenAPI
-- Game: Red Crow Mysteries: Legion

-- MAIN APPLICATION
addappid(372890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(372891, 1, "c534bae0f5c70787a9ab657704a54b3642f725f921d23c1e5a54b80b2d310ba8")
addappid(372892, 1, "f915024ade26dbbb39aa2f471712ceb2c4261bd2fad75b82fe3c6c3444bd0b45")
addappid(372898, 1, "bae8f0426a8a590c10f4a4765982a645cc00c0cf3fe9df1590b7df7eb84da040")

