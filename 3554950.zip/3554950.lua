-- Lua provided by RyzenAPI
-- Game: 3554950

-- MAIN APPLICATION
addappid(3554950)
-- Game: addappid(3554950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554951, 1, "91d445c19c2010baeb3047aefb28214c6b62748f0e9740f513b95ddbb55c12cf")
