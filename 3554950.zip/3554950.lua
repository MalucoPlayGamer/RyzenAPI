-- Lua provided by RyzenAPI
-- Game: 谜境·AI剧本杀互动剧场

-- MAIN APPLICATION
addappid(3554950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554951, 1, "91d445c19c2010baeb3047aefb28214c6b62748f0e9740f513b95ddbb55c12cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
