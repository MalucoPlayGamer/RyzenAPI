-- Lua provided by RyzenAPI
-- Game: Photo Studio

-- MAIN APPLICATION
addappid(1384390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384391, 1, "d2275dc4ccfbc63720523be983da3821f2e06ad5fd97ed7cf565512aa5684a52")

