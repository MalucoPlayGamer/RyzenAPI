-- Lua provided by RyzenAPI
-- Game: LumenTale: Memories of Trey

-- MAIN APPLICATION
addappid(2261430)
addappid(3976090)
addappid(3976100)
-- Game: addappid(2261430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261431, 1, "c37596c858c344da52f712140ec94665adcc3aee9d5b990901bbd3be121aaab8")
addappid(2261432, 1, "e945dac3ce70daffed46d0aa7cf192691d3b0867eef8c298add542e8d72b5888")
