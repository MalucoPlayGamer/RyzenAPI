-- Lua provided by RyzenAPI 
-- Game: Scripture
addappid(1846060)
addappid(1846061, 1, "78a450da242781b04f523dccdabbef8a3ea7f7740fb8ae8dc28aef29dc1b2c9a")
