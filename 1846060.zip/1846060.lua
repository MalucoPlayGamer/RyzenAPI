-- Lua provided by RyzenAPI
-- Game: 1846060

-- MAIN APPLICATION
addappid(1846060)
-- Game: addappid(1846060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846061, 1, "78a450da242781b04f523dccdabbef8a3ea7f7740fb8ae8dc28aef29dc1b2c9a")
