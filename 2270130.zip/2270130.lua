-- Lua provided by SkyAPI 
-- Game: Bloodhound: First day in hell
addappid(2270130)
addappid(2270131, 1, "68d58fb8739432030402ca315edca2acbf3a41ab310cb5d3a661ccac1e068989")
