-- Lua provided by RyzenAPI
-- Game: Bloodhound: First day in hell

-- MAIN APPLICATION
addappid(2270130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2270131, 1, "68d58fb8739432030402ca315edca2acbf3a41ab310cb5d3a661ccac1e068989")

