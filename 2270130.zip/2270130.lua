-- Lua provided by RyzenAPI
-- Game: Game: Bloodhound: First day in hell

-- MAIN APPLICATION
addappid(2270130)
-- Game: addappid(2270130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270131, 1, "68d58fb8739432030402ca315edca2acbf3a41ab310cb5d3a661ccac1e068989")
