-- Lua provided by RyzenAPI
-- Game: FUSER™ - Future - "Mask Off"

-- MAIN APPLICATION
addappid(1432172)
-- Game: addappid(1432172)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432172,0,"f79848dd71d50a27af4b26ca8262aa904f96222470c59e4afbb25314e925fbae")
