-- Lua provided by RyzenAPI
-- Game: Blackhole on the Road

-- MAIN APPLICATION
addappid(2616060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616061, 1, "b2d594d31af09dd8231275a1ed06471e9c0d8380936da1ed0c3b1d7bfebdf2ff")

