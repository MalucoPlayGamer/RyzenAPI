-- Lua provided by RyzenAPI
-- Game: DeathWatchers

-- MAIN APPLICATION
addappid(2599370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599371, 1, "feb1c54a0a57cbf15dd4b1c48a1f91835cc37c44598713decfc0cee5b3a3d52c")
