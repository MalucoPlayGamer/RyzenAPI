-- Lua provided by RyzenAPI
-- Game: Jeff Logar

-- MAIN APPLICATION
addappid(1694360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694361, 1, "023ebaf68c1dfa164411af817b2eebbb7dbb4b300294cf2ab79ac00dcf7d1cde")

