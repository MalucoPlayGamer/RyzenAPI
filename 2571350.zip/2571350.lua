-- Lua provided by RyzenAPI
-- Game: Game: Soul of War: Legions

-- MAIN APPLICATION
addappid(2571350)
-- Game: addappid(2571350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571351, 1, "cb21a094fbcebc8b4f310289a1dc75ded368bf28818d5e13cc556609ea32f655")
