-- Lua provided by RyzenAPI 
-- Game: Soul of War: Legions
addappid(2571350)
addappid(2571351, 1, "cb21a094fbcebc8b4f310289a1dc75ded368bf28818d5e13cc556609ea32f655")
