-- Lua provided by RyzenAPI
-- Game: Game: AppID 2015800

-- MAIN APPLICATION
addappid(2015800)
-- Game: addappid(2015800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015801, 1, "b65302c66b8f11e0b669caefcaa8b9de4e617a5a19637aea6a3798d58597c694")
