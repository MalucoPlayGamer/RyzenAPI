-- Lua provided by RyzenAPI
-- Game: 东方妖精武踏会 Demo

-- MAIN APPLICATION
addappid(2015800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015801, 1, "b65302c66b8f11e0b669caefcaa8b9de4e617a5a19637aea6a3798d58597c694")

