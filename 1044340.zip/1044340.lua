-- Lua provided by RyzenAPI
-- Game: Game: AppID 1044340

-- MAIN APPLICATION
addappid(1044340)
-- Game: addappid(1044340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044341, 1, "3535440f8c98829f983a67915c2cccdc555c58a5330fcdddce7abfb607598f68")
addappid(1044342, 1, "519d3eda68d56b28e7cf918e67c590fafebb5191b4e23a1a0bda7c4dec6d47ef")
addappid(1048430, 0, "3b99db1a91cb6632694ed85246e71f7c1bb8e531a963e5486eb5064c748b5a69")
