-- Lua provided by RyzenAPI
-- Game: AppID 1044340

-- MAIN APPLICATION
addappid(1044340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044341, 1, "3535440f8c98829f983a67915c2cccdc555c58a5330fcdddce7abfb607598f68")
addappid(1044342, 1, "519d3eda68d56b28e7cf918e67c590fafebb5191b4e23a1a0bda7c4dec6d47ef")
addappid(1048430, 0, "3b99db1a91cb6632694ed85246e71f7c1bb8e531a963e5486eb5064c748b5a69")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
