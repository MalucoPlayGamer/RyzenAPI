-- Lua provided by RyzenAPI
-- Game: War Inc. Battlezone

-- MAIN APPLICATION
addappid(107900)

-- MAIN APP DEPOTS / PACKAGES
addappid(107901, 1, "b55d97f4330a07d81e289e87e6161154bf870378f02184a92bb2681a84316d45")
