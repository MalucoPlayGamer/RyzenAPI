-- Lua provided by RyzenAPI
-- Game: AppID 636700

-- MAIN APPLICATION
addappid(636700)

-- MAIN APP DEPOTS / PACKAGES
addappid(636701, 1, "f622abd8085da8b6586ceb875b60ecbc839ef01dc8fb258be95f367acf37a650")
