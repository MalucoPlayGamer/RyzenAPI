-- Lua provided by RyzenAPI
-- Game: Game: AppID 740470

-- MAIN APPLICATION
addappid(740470)
-- Game: addappid(740470)

-- MAIN APP DEPOTS / PACKAGES
addappid(740471, 1, "0e4e8c435e933a69655f7efc79c0af50fc93db9ae75e9b59179112b95fbe3917")
