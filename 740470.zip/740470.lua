-- Lua provided by RyzenAPI
-- Game: AppID 740470

-- MAIN APPLICATION
addappid(740470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(740471, 1, "0e4e8c435e933a69655f7efc79c0af50fc93db9ae75e9b59179112b95fbe3917")

