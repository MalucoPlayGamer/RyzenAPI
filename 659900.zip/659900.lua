-- Lua provided by RyzenAPI
-- Game: Aetherspace

-- MAIN APPLICATION
addappid(659900)

-- MAIN APP DEPOTS / PACKAGES
addappid(659901, 1, "4679f0cfe61dc56b8b77468ae2aeb83c1d021bf1483f249d4eb2d6b006715291")
