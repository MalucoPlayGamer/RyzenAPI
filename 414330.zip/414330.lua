-- Lua provided by RyzenAPI
-- Game: We Are Chicago

-- MAIN APPLICATION
addappid(414330)

-- MAIN APP DEPOTS / PACKAGES
addappid(414332,0,"850719c60807925831cfa5ca3067a0db75324c78869acc4d9cbd8aebf8cfc023")

