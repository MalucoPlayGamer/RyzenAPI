-- Lua provided by RyzenAPI
-- Game: We Are Chicago

-- MAIN APPLICATION
addappid(414330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(414332,0,"850719c60807925831cfa5ca3067a0db75324c78869acc4d9cbd8aebf8cfc023")

