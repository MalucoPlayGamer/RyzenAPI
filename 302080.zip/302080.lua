-- Lua provided by RyzenAPI 
-- Game: AppID 302080
addappid(302080)
addappid(302081, 1, "ff83be21767048b4688776c96a609f4ebc6242f2a4fbb91a9c6e0ee38940256b")
addappid(302082, 1, "2075898e208ea43aac750c4c573c66c9516fe53daa4024e38646c8e57fa79361")
