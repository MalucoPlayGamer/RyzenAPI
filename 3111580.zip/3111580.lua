-- Lua provided by RyzenAPI
-- Game: Record Shop Simulator

-- MAIN APPLICATION
addappid(3111580)
-- Game: addappid(3111580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111581, 1, "387ff37c7044fc545f710a0e76d6a0b389562a15640fea0d8a16b577d8f59abd")
