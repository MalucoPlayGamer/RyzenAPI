-- Lua provided by RyzenAPI
-- Game: Design it, Drive it : Speedboats

-- MAIN APPLICATION
addappid(501090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(501091, 1, "5afa35546b72912206276315d9799b687c425bd149f3154c22bfc0340916c858")

