-- Lua provided by RyzenAPI
-- Game: addappid(2292930)

-- MAIN APPLICATION
addappid(2292930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292931, 1, "eadd7f79a872c1d3f947e8d3353c1c00b8d59df81ff1808cf29b5b9e197b7243")
