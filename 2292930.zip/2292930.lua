-- Lua provided by SkyAPI 
-- Game: The Remains of the Day Playtest
addappid(2292930)
addappid(2292931, 1, "eadd7f79a872c1d3f947e8d3353c1c00b8d59df81ff1808cf29b5b9e197b7243")
