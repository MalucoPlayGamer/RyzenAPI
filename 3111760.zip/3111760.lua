-- Lua provided by RyzenAPI
-- Game: AppID 3111760

-- MAIN APPLICATION
addappid(3111760)
-- Game: addappid(3111760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111761, 1, "013ff91b1c7e0af6848c6dc14285ef047ef7ca2ba5d10f2c75061736cba048b9")
