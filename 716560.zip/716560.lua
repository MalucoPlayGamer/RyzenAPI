-- Lua provided by RyzenAPI
-- Game: Trancelation

-- MAIN APPLICATION
addappid(716560)

-- MAIN APP DEPOTS / PACKAGES
addappid(716561,0,"6ddeeaa3dcd0adfcaf72fcec6d34b4f909e86cca057a14748531b959c1b9eb40")

