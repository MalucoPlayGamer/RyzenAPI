-- Lua provided by RyzenAPI
-- Game: Trancelation

-- MAIN APPLICATION
addappid(716560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(716561,0,"6ddeeaa3dcd0adfcaf72fcec6d34b4f909e86cca057a14748531b959c1b9eb40")

