-- Lua provided by RyzenAPI
-- Game: addappid(652760)

-- MAIN APPLICATION
addappid(652760)

-- MAIN APP DEPOTS / PACKAGES
addappid(652761, 1, "9b52a3ed6be51d7a0c61c9b0927839c9d4a3b3b9a36924d1f1fd94d0f0bc3a43")
