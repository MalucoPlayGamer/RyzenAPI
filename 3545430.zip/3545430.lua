-- Lua provided by RyzenAPI
-- Game: 妖精之地 Playtest

-- MAIN APPLICATION
addappid(3545430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3545431, 1, "476806cd603b59bba50be6f9bf7ef7c09093cf4fa228231d0d34038230816367")
