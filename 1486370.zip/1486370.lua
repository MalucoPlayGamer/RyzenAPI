-- Lua provided by RyzenAPI
-- Game: addappid(1486370)

-- MAIN APPLICATION
addappid(1486370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486372,0,"9e73a0ea6518d7396cbff550700bf0307c7d65c8264de2a9b87653f5b757f99b")
