-- Lua provided by RyzenAPI 
-- Game: Paradise Angel
addappid(2627340)
addappid(2627341, 1, "53c4f8bc74998c89b76cc7bbdeb574d67fb0d38f4d07e3f1c9131692cfa8f773")
addappid(2627342, 1, "903ea96c512dafc685809de75d1b37113cf1a8319ebb694727005ea770ef2653")
addappid(2627343, 1, "f5762bfc7a3371393bbbcb88fb2b1fcdb42cd9197ceba7d1445e2ea7eee31ad5")
