-- Lua provided by RyzenAPI
-- Game: addappid(2539820)

-- MAIN APPLICATION
addappid(2539820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539821, 1, "14bd8e3c8737f0ad8846c46c6394f4a1b212b0634dfc67bdae61eaeae481806c")
