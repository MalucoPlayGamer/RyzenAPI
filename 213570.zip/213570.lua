-- Lua provided by RyzenAPI
-- Game: Trash TV (demo)

-- MAIN APPLICATION
addappid(213570)
addappid(229012)

-- MAIN APP DEPOTS / PACKAGES
addappid(213571, 1, "7080447f097e2d4bac329a291039bc0b315703e63713d72a9fcdf94e3b7f4461")

