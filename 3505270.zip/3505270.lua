-- Lua provided by RyzenAPI
-- Game: 3505270

-- MAIN APPLICATION
addappid(3505270)
-- Game: addappid(3505270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3505271, 1, "cade0d83212f9e1821e33b744e6d0adc2f92cae94e0f52772c882c31e0650ace")
