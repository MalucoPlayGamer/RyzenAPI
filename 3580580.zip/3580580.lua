-- Lua provided by RyzenAPI
-- Game: Jacksmith: Weapons and Warriors

-- MAIN APPLICATION
addappid(3580580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3580581, 1, "66b3c25e35e2d734a6591131492f846958fed2a8c5b0a1a4e44a9195f6f78866")

