-- Lua provided by RyzenAPI
-- Game: addappid(316080)

-- MAIN APPLICATION
addappid(316080)

-- MAIN APP DEPOTS / PACKAGES
addappid(316081, 1, "b086fc9104246cdaa7ecbed6f595ebbc483f89c5d7ba1207fd9199e3573ded35")
addappid(362970, 0, "939a92f4aa6de07615718f1ff721a79eb239e8e5680c5fa42b9f40602f66512a")
