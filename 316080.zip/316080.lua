-- Lua provided by RyzenAPI
-- Game: Parcel

-- MAIN APPLICATION
addappid(316080)

-- MAIN APP DEPOTS / PACKAGES
addappid(316081, 1, "b086fc9104246cdaa7ecbed6f595ebbc483f89c5d7ba1207fd9199e3573ded35")
addappid(362970, 0, "939a92f4aa6de07615718f1ff721a79eb239e8e5680c5fa42b9f40602f66512a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
