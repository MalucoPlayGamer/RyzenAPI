-- Lua provided by RyzenAPI 
-- Game: Skyward Extraction
addappid(2787610)
addappid(2787611, 1, "9c384dbd819f050b3cc68ea13525aa784afd28b7e6b23ef287b9a51b3fbbb2e9")
