-- Lua provided by RyzenAPI
-- Game: Game: Skyward Extraction

-- MAIN APPLICATION
addappid(2787610)
-- Game: addappid(2787610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787611, 1, "9c384dbd819f050b3cc68ea13525aa784afd28b7e6b23ef287b9a51b3fbbb2e9")
