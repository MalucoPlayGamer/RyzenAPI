-- Lua provided by RyzenAPI
-- Game: Skyward Extraction

-- MAIN APPLICATION
addappid(2787610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787611, 1, "9c384dbd819f050b3cc68ea13525aa784afd28b7e6b23ef287b9a51b3fbbb2e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
