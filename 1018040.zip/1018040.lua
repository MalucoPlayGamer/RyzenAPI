-- Lua provided by RyzenAPI 
-- Game: AppID 1018040
addappid(1018040)
addappid(1018041, 1, "bf7099771b625e25ff424a06637bafd4f3ad626fae6bd6b27922e23647e14f76")
addappid(1018042, 1, "69d994a4e2e1f37ff70e0992e7789ae55d3e74066d2233a2e48cc82b525776ee")
