-- Lua provided by RyzenAPI
-- Game: 39260

-- MAIN APPLICATION
addappid(23391)
addappid(39260)
-- Game: addappid(39260)

-- MAIN APP DEPOTS / PACKAGES
addappid(23392,0,"66a5637eafc69ae41f04383b878950cd7828d76223d741fd1f025dc61e542c61")
