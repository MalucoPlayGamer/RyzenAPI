-- Lua provided by RyzenAPI
-- Game: 1237370

-- MAIN APPLICATION
addappid(1237370)
-- Game: addappid(1237370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237371, 1, "e3af7d9d008bf4bd1c8b5ee9e6245746c3b59f3be60661b5f70e4c1c87569781")
