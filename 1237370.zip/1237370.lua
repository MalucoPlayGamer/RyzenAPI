-- Lua provided by RyzenAPI 
-- Game: AppID 1237370
addappid(1237370)
addappid(1237371, 1, "e3af7d9d008bf4bd1c8b5ee9e6245746c3b59f3be60661b5f70e4c1c87569781")
