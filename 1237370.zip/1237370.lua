-- Lua provided by RyzenAPI
-- Game: 牛顿与苹果树

-- MAIN APPLICATION
addappid(1237370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1237371, 1, "e3af7d9d008bf4bd1c8b5ee9e6245746c3b59f3be60661b5f70e4c1c87569781")

