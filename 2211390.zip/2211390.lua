-- Lua provided by RyzenAPI
-- Game: addappid(2211390)

-- MAIN APPLICATION
addappid(2211390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211391, 1, "534648749f9fc0b9cab2bd2589d21f50e686281409de9d22a587254fc60db0de")
