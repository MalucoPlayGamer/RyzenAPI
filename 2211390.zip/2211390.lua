-- Lua provided by RyzenAPI
-- Game: Time Survivors

-- MAIN APPLICATION
addappid(2211390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2211391, 1, "534648749f9fc0b9cab2bd2589d21f50e686281409de9d22a587254fc60db0de")

