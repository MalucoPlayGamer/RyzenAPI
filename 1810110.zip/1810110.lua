-- Lua provided by RyzenAPI
-- Game: 1810110

-- MAIN APPLICATION
addappid(1810110)
-- Game: addappid(1810110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810111, 1, "d4ce18d7da0333511e1d367d0838056ccffc44fde4cc9beee474c0ad76830ac4")
