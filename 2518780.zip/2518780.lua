-- Lua provided by SkyAPI 
-- Game: AppID 2518780
addappid(2518780)
addappid(2518781, 1, "eedcadf8461206a0f3bdb132af2400c61977fc668aa4763f235d3d6e16a38a2e")
