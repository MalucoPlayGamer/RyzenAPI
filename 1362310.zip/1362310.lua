-- Lua provided by RyzenAPI
-- Game: Zombie Simulator

-- MAIN APPLICATION
addappid(1362310)
addappid(1650000)
-- Game: addappid(1362310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362311, 1, "a2c4e740de7de09c6b4b0bf6dee53d36ff94c6a9347f36c8879345044dc15e4c")
