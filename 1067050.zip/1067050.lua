-- Lua provided by RyzenAPI 
-- Game: Deep Dungeon: Gym
addappid(1067050)
addappid(1067051, 1, "2a97d814d7df043ea3d03bf9a48bdd0be590b7bfaa27770a32853242cb7f7610")
