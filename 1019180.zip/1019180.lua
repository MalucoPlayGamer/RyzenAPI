-- Lua provided by RyzenAPI
-- Game: 1019180

-- MAIN APPLICATION
addappid(1019180)
-- Game: addappid(1019180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019182,0,"982521baba69d64b8c1699e32380f9775e6ae3a804adda8ae66af149e149ac91")
