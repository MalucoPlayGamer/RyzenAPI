-- Lua provided by RyzenAPI
-- Game: AppID 952510

-- MAIN APPLICATION
addappid(952510)

-- MAIN APP DEPOTS / PACKAGES
addappid(952511, 1, "a1b0a8692bc5cde157f85909cca9fbd07b544913ba92c79fbeea0eea8bbc6e8c")
