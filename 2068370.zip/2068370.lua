-- Lua provided by RyzenAPI 
-- Game: My Agent is a Futanari
addappid(2068370)
addappid(2068371, 1, "0afc45456d607a6b2a3597a28627ffcbbd6eeba3a9279e070217e33118cbbc6e")
