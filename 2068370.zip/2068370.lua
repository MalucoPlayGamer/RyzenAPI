-- Lua provided by RyzenAPI
-- Game: Game: My Agent is a Futanari

-- MAIN APPLICATION
addappid(2068370)
-- Game: addappid(2068370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068371, 1, "0afc45456d607a6b2a3597a28627ffcbbd6eeba3a9279e070217e33118cbbc6e")
