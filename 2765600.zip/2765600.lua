-- Lua provided by RyzenAPI
-- Game: Schrodinger's Cat Experiment (SCE)

-- MAIN APPLICATION
addappid(2765600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765601, 1, "56ddd0a961f786e5c559839ac2c33bd0633ec9b91d2f5212615e0d79e77a58fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
