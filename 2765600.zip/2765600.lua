-- Lua provided by RyzenAPI
-- Game: 2765600

-- MAIN APPLICATION
addappid(2765600)
-- Game: addappid(2765600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765601, 1, "56ddd0a961f786e5c559839ac2c33bd0633ec9b91d2f5212615e0d79e77a58fa")
