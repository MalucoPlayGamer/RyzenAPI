-- Lua provided by SkyAPI 
-- Game: Whispers in the Moss
addappid(1944310)
addappid(1944311, 1, "c6e8db8b745bb19e8b1fcdb8c6facd4195de0885014c1ef89f7703a88ba6fc7e")
