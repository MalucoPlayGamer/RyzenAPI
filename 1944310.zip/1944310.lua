-- Lua provided by RyzenAPI
-- Game: Whispers in the Moss

-- MAIN APPLICATION
addappid(1944310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944311, 1, "c6e8db8b745bb19e8b1fcdb8c6facd4195de0885014c1ef89f7703a88ba6fc7e")

