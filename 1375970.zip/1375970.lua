-- Lua provided by RyzenAPI
-- Game: Korean Adventures in Russia

-- MAIN APPLICATION
addappid(1375970)
-- Game: addappid(1375970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375971, 1, "7aedb14a8b3345e50790443131921d7dce72e2011b57764f00276e550bc14f35")
