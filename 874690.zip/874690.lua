-- Lua provided by RyzenAPI
-- Game: Maze And Dagger

-- MAIN APPLICATION
addappid(874690)
-- Game: addappid(874690)

-- MAIN APP DEPOTS / PACKAGES
addappid(874691, 1, "039ed77f88202419c51a595cc23a7bcd42f33a959beb80375ee7d2de2f3a938b")
addappid(874694, 1, "67c7aa59dcf55b983f8e731786ae56c61cab61b0f7bb41a4935e371707c68021")
addappid(874695, 1, "ffd7ed278438856b7c41be08937077754d6692b00754a44356fa5bbe44d8b569")
addappid(874697, 1, "c504380e1003e83f4dfddab1cf99017a7f450d1dba15f6846eef9cfb2069c74f")
