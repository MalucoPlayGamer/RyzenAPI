-- Lua provided by RyzenAPI
-- Game: Game: Dark Matter

-- MAIN APPLICATION
addappid(251410)
-- Game: addappid(251410)

-- MAIN APP DEPOTS / PACKAGES
addappid(251411, 1, "f537189b945d51b932decffe50a0679421b79d5b9cbf01e7d11b205ad018eb3e")
addappid(251412, 1, "81a4262a6c6a680ee5f54b8ad577a808eae3acd37fcb87a41a3d2b8284923385")
addappid(251413, 1, "3558a0eaa99d3f02cba9af5fa20c46f036553b0c3491280fcd3f145922054674")
