-- Lua provided by RyzenAPI
-- Game: vROVpilot: TITANIC

-- MAIN APPLICATION
addappid(3397800)
-- Game: addappid(3397800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397801, 1, "1d458eda842f24025de40e7ac58195dd6a50d3b96d5ead560b42a7610703234d")
