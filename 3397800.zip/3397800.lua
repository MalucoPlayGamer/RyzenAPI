-- Lua provided by RyzenAPI
-- Game: vROVpilot: TITANIC

-- MAIN APPLICATION
addappid(3397800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397801, 1, "1d458eda842f24025de40e7ac58195dd6a50d3b96d5ead560b42a7610703234d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
