-- Lua provided by RyzenAPI 
-- Game: Milky Way Prince – The Vampire Star
addappid(1302050)
addappid(1302051, 1, "c05b77b423494085c71edd7945a6684ad5c0da5c17303ab11367fd2ef7341cde")
addappid(1302052, 1, "00c6dc5453151decf3bf73ffccb5de8b3841ae00f2521b46f51fd82db3b02fdd")
