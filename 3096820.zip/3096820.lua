-- Lua provided by RyzenAPI
-- Game: Game: AppID 3096820

-- MAIN APPLICATION
addappid(3096820)
-- Game: addappid(3096820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096821, 1, "ef4e71b8e457afa599110afd13028ea870bdb3bca31c612c669217b243f64476")
