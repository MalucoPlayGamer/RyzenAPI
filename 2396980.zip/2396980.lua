-- Lua provided by RyzenAPI
-- Game: Fate/stay night REMASTERED

-- MAIN APPLICATION
addappid(2396980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2396981, 1, "62bc96ae2b5b2f680456b0ec8a425ab43d8a57725810e3c3efe590cf7e31f6fc")

