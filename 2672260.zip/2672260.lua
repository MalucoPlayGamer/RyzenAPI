-- Lua provided by RyzenAPI
-- Game: AppID 2672260

-- MAIN APPLICATION
addappid(2672260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672261, 1, "370a680c041d0d4518f85eea3ea6c510e4d77ccd46c4f6dd0d87d43c89e03ffb")

