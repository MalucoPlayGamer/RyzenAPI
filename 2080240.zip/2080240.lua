-- Lua provided by RyzenAPI 
-- Game: AppID 2080240
addappid(2080240)
addappid(2080241, 1, "6b297c61c45f54a114f0ee6ea8f132e838412d21246184ad8c22e44358f931c8")
