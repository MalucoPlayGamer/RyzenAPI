-- Lua provided by RyzenAPI
-- Game: Just Dismantle

-- MAIN APPLICATION
addappid(4043010)

-- MAIN APP DEPOTS / PACKAGES
addappid(4043011,0,"da2cdf7d59bae553b02366cd5b8f1fdadc59b815301924e91b55cd62db496179")

