-- Lua provided by RyzenAPI
-- Game: Going Medieval Soundtrack

-- MAIN APPLICATION
addappid(1612760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612761, 1, "670cf95bd86a71ff2fb862403c4d9c4eeff5f394bcdfeaf5630481f303b32d24")
