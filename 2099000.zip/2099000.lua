-- Lua provided by RyzenAPI
-- Game: Game: Western Girls

-- MAIN APPLICATION
addappid(2099000)
-- Game: addappid(2099000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099001, 1, "2e919b0841eb46416c6aecbc19dd467f2a6c35eaba542f3896f3872d5d15212f")
