-- Lua provided by RyzenAPI
-- Game: ATC Infinite

-- MAIN APPLICATION
addappid(1516440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516441, 1, "fcf853a36b4f1866903a63c4fbdf220a387643d586115be6abd237acc89212cc")

