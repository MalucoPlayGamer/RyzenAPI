-- Lua provided by RyzenAPI
-- Game: Game: AppID 3359210

-- MAIN APPLICATION
addappid(3359210)
-- Game: addappid(3359210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359211, 1, "c85fb772ad17414514259d227f051c02070de03a243bdfb9142ab3a8862138b4")
