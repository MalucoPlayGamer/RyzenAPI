-- Lua provided by RyzenAPI
-- Game: The Dreamscape

-- MAIN APPLICATION
addappid(3359210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3359211, 1, "c85fb772ad17414514259d227f051c02070de03a243bdfb9142ab3a8862138b4")
