-- Lua provided by RyzenAPI
-- Game: addappid(1978310)

-- MAIN APPLICATION
addappid(1978310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978311, 1, "3914a4eb059f463afb314b5cb7bd3ca1c2626a28f66be6dc9c9f7eb0491729e7")
