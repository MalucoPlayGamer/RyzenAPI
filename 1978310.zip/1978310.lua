-- Lua provided by SkyAPI 
-- Game: AppID 1978310
addappid(1978310)
addappid(1978311, 1, "3914a4eb059f463afb314b5cb7bd3ca1c2626a28f66be6dc9c9f7eb0491729e7")
