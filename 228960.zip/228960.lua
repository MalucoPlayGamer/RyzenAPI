-- Lua provided by RyzenAPI
-- Game: Game: Skulls of the Shogun

-- MAIN APPLICATION
addappid(228960)
-- Game: addappid(228960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228961, 1, "400ee5291dfc34dc89ada07ef3683417798aa1b4b8a09c6623f46f8d30c14f93")
addappid(228962, 1, "de52b0f5e094f793c72f5e373232acd5b950f635cf467b1eed7d1301279f1a18")
addappid(228963, 1, "f865b7a637bec0c803168999633e7f41b9e6464e21ab5edf5e1af607315b8604")
