-- Lua provided by RyzenAPI
-- Game: Skulls of the Shogun

-- MAIN APPLICATION
addappid(228960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228961, 1, "400ee5291dfc34dc89ada07ef3683417798aa1b4b8a09c6623f46f8d30c14f93")
addappid(228962, 1, "de52b0f5e094f793c72f5e373232acd5b950f635cf467b1eed7d1301279f1a18")
addappid(228963, 1, "f865b7a637bec0c803168999633e7f41b9e6464e21ab5edf5e1af607315b8604")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
