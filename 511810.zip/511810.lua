-- Lua provided by RyzenAPI 
-- Game: AppID 511810
addappid(511810)
addappid(511811, 1, "078844231d10864afe2aa9c42871abeabe40308319994b16d226b5791ac5cb4e")
addappid(511812, 1, "7e62378e79806377c96f62a81d954bd49d6b52864bdcb658c63be770da86ef60")
