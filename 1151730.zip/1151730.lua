-- Lua provided by RyzenAPI
-- Game: addappid(1151730)

-- MAIN APPLICATION
addappid(1151730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151730,0,"1fa432cb9b2476b7b825842c3509dcba1f9e5d17146d1542fa2cf9629f375ba3")
