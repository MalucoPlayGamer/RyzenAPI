-- Lua provided by RyzenAPI
-- Game: SPACE / MECH / PILOT

-- MAIN APPLICATION
addappid(1398390)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1400160)
