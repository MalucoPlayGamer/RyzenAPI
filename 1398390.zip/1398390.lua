-- Lua provided by RyzenAPI
-- Game: SPACE / MECH / PILOT

-- MAIN APPLICATION
addappid(1398390)
