-- Lua provided by RyzenAPI
-- Game: Game: Jolly Rover

-- MAIN APPLICATION
addappid(58200)
-- Game: addappid(58200)

-- MAIN APP DEPOTS / PACKAGES
addappid(58201, 1, "a9263764779d7db6428063998936e0bfb1cfe119094804c3d81601c3b8c923e6")
addappid(58202, 1, "e2787b92a5027632e345460e8c26b502b33e87a81dff3c2026caa7718540af41")
