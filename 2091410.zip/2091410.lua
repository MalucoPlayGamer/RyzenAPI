-- Lua provided by RyzenAPI 
-- Game: March of Shrooms
addappid(2091410)
addappid(2091411, 1, "0e7f63374d8c59edcc8862e455bbdf5c8a02cbda291abc0ba4568448f99fe8d4")
