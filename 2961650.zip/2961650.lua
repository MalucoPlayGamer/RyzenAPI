-- Lua provided by RyzenAPI
-- Game: Gangbanged by Orcs and Goblins!

-- MAIN APPLICATION
addappid(2961650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2961651, 1, "442b0aa0c39bdb28b707f4ad2c3301a3b8256278609cebb5475e792d68abb388")

