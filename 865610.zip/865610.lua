-- Lua provided by RyzenAPI
-- Game: addappid(865610)

-- MAIN APPLICATION
addappid(865610)

-- MAIN APP DEPOTS / PACKAGES
addappid(865611, 1, "9a41ed2a17a08f02aabf6e5df2ae6989befaab04a0ff715fa4e773dc95acb0a0")
addappid(865612, 1, "375f824b34711b5def9f5a700ba4a7a3d534bbf93cf38c1ff402ddfdae5045bd")
addappid(1649990, 0, "c97a54c696681db0edd18fe600f3e3ef94911f061b82b8644a7d6030825651fb")
