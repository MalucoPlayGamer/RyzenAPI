-- Lua provided by RyzenAPI
-- Game: Dragon Boar and Lady Rabbit

-- MAIN APPLICATION
addappid(769370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(769371, 1, "59b240d2bbab5ee76ace8a267a5c0b80c1321758fd8045d6421db8a767330040")

