-- Lua provided by RyzenAPI
-- Game: 368800

-- MAIN APPLICATION
addappid(368800)
-- Game: addappid(368800)

-- MAIN APP DEPOTS / PACKAGES
addappid(368801, 1, "8678312ee2660e15267eeb2ebab49ed8c22df33e8fff31a2836e10892bf47f01")
