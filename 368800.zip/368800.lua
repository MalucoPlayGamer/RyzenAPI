-- Lua provided by RyzenAPI
-- Game: Apocalypse: Party's Over

-- MAIN APPLICATION
addappid(368800)

-- MAIN APP DEPOTS / PACKAGES
addappid(368801, 1, "8678312ee2660e15267eeb2ebab49ed8c22df33e8fff31a2836e10892bf47f01")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
