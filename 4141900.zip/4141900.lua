-- Lua provided by RyzenAPI
-- Game: The Corrupted

-- MAIN APPLICATION
addappid(4141900)

