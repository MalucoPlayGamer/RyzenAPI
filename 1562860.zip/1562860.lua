-- Lua provided by SkyAPI 
-- Game: Distancing
addappid(1562860)
addappid(1562861, 1, "82eef1ec16f34d9bdee0de327b4bae2505b0ea405ab453cd5a429f3fb93a6668")
