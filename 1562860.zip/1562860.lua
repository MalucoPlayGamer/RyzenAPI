-- Lua provided by RyzenAPI
-- Game: 1562860

-- MAIN APPLICATION
addappid(1562860)
-- Game: addappid(1562860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562861, 1, "82eef1ec16f34d9bdee0de327b4bae2505b0ea405ab453cd5a429f3fb93a6668")
