-- Lua provided by RyzenAPI
-- Game: addappid(1263720)

-- MAIN APPLICATION
addappid(1263720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263721, 1, "1d672011797f7b9caf743a9774cc9ca245c3666eb4e69ec3d89a1d80ad6f3066")
