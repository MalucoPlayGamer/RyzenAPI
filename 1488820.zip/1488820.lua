-- Lua provided by RyzenAPI
-- Game: 1488820

-- MAIN APPLICATION
addappid(1488820)
-- Game: addappid(1488820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488821, 1, "8c9c6e8479fc09316fe9b99561e3c1bbab95a643fd479ad1dafda4cd6e7607a3")
