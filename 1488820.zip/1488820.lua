-- Lua provided by RyzenAPI
-- Game: Dark Fantasy Warriors

-- MAIN APPLICATION
addappid(1488820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488821, 1, "8c9c6e8479fc09316fe9b99561e3c1bbab95a643fd479ad1dafda4cd6e7607a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
