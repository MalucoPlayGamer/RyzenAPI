-- Lua provided by RyzenAPI
-- Game: 426820

-- MAIN APPLICATION
addappid(426820)
-- Game: addappid(426820)

-- MAIN APP DEPOTS / PACKAGES
addappid(426820,0,"b84790788f504d95fae914aff7d0ff39ac4e2ec66bb92f31f8f11675599a2c47")
