-- Lua provided by RyzenAPI
-- Game: BONEBUILDER Playtest

-- MAIN APPLICATION
addappid(3721050)
-- Game: addappid(3721050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3721051, 1, "822f06855e4071d3526e1c92f91d56ae79419d41efc214172cfe7c40b2c8a224")
