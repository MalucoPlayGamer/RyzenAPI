-- Lua provided by RyzenAPI
-- Game: HOUND: AUTOMATON

-- MAIN APPLICATION
addappid(3081120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081121, 1, "173327df456862ab43bccde389847e903a67fec3edf2879346baac7ada7d1a49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
