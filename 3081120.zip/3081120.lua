-- Lua provided by RyzenAPI
-- Game: 3081120

-- MAIN APPLICATION
addappid(3081120)
-- Game: addappid(3081120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081121, 1, "173327df456862ab43bccde389847e903a67fec3edf2879346baac7ada7d1a49")
