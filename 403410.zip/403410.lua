-- Lua provided by RyzenAPI
-- Game: 403410

-- MAIN APPLICATION
addappid(403410)
-- Game: addappid(403410)

-- MAIN APP DEPOTS / PACKAGES
addappid(403411, 1, "657cd3a41f0ed833f0c0d9aafe44f0ab3884cfaf30405668088990c2b760eab5")
