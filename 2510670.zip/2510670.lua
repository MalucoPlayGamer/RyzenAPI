-- Lua provided by RyzenAPI 
-- Game: KEM Alpha 1
addappid(2510670)
addappid(2510671, 1, "21b26060d5bf78415f2069c183163f228736eb4cfb7d97261da31ba9e02ad18d")
