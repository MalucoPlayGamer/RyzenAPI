-- Lua provided by RyzenAPI
-- Game: KEM Alpha 1

-- MAIN APPLICATION
addappid(2510670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2510671, 1, "21b26060d5bf78415f2069c183163f228736eb4cfb7d97261da31ba9e02ad18d")

