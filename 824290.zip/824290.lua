-- Lua provided by RyzenAPI 
-- Game: AppID 824290
addappid(824290)
addappid(824291, 1, "5cf8ff6a17b1591d32165756701f41883572c420623f9780737342a21818f605")
