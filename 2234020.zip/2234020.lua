-- Lua provided by SkyAPI 
-- Game: Iso Racer
addappid(2234020)
addappid(2234021, 1, "a8d64df5e8175b97cfa6a12cfcbfd51ca7cefe82d9b4cf8d0b9c3b5fe938cf09")
