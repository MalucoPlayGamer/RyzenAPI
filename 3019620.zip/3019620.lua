-- Lua provided by RyzenAPI
-- Game: Abaddon Demo

-- MAIN APPLICATION
addappid(3019620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019621, 1, "371976ae4f22b04b4e130ac964802a848cb6f9ff283a9df2ac69b9b9803048cc")

