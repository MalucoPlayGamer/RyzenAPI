-- Lua provided by RyzenAPI
-- Game: addappid(833300)

-- MAIN APPLICATION
addappid(833300)

-- MAIN APP DEPOTS / PACKAGES
addappid(833301, 1, "acd29c613ba1217c9a7a7d7ceb637e494ab05dcda88a499187c9c2f1597e19fd")
