-- Lua provided by RyzenAPI
-- Game: Winter's Symphonies

-- MAIN APPLICATION
addappid(738900)

-- MAIN APP DEPOTS / PACKAGES
addappid(738901,0,"41a6f9ccecb5176096e5222d01b6eedcea819f28de865e749c7042be4aa35fe1")

