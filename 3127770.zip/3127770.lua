-- Lua provided by RyzenAPI
-- Game: ACE Strategy: Mecha Nova

-- MAIN APPLICATION
addappid(3127770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127771,0,"01364574fa7f9b65ab6b3559d33d71216efdf006245a51f430f1f56920a5f171")

