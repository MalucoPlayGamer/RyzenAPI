-- Lua provided by RyzenAPI
-- Game: Granny 3

-- MAIN APPLICATION
addappid(1707550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707551, 1, "f4410bc90ecd9cb0290cb8844063c55ea74deb00a789cd359633fd0790a6f742")
