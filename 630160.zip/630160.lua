-- Lua provided by RyzenAPI
-- Game: addappid(630160)

-- MAIN APPLICATION
addappid(630160)

-- MAIN APP DEPOTS / PACKAGES
addappid(630161, 1, "4ee4485d375be2748cfca5b49094b188a43c2dd8ea528aaf87eae4317e5a0133")
