-- Lua provided by RyzenAPI
-- Game: AppID 1363600

-- MAIN APPLICATION
addappid(1363600)
-- Game: addappid(1363600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363601, 1, "74ef7c38628685c6cd74dd0405fcc7fb63bb147e8294edcda2e083f4daa7b1a2")
