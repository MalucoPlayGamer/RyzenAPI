-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator: Shin-etsu Line (Naoetsu to Niigata) E129-0 series

-- MAIN APPLICATION
addappid(2602460)
-- Game: addappid(2602460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602461, 1, "969646605b8a49d9777eded8a12b31d593172cb1a7285b1c4a14d41c4f817356")
addappid(2602462, 1, "a13cc901cd3d7792c3ec7ec3b5699b5b24fc50e21f09a136a7974cbc1c89e686")
