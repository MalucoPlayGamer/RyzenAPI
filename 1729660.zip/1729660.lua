-- Lua provided by RyzenAPI
-- Game: Hyper Bullet

-- MAIN APPLICATION
addappid(1729660)
-- Game: addappid(1729660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729661, 1, "abc938bd38199ae4411c953e4129b149d0f6b9da079883913e79748d7225743f")
