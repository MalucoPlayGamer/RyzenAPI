-- Lua provided by RyzenAPI
-- Game: Hyper Bullet

-- MAIN APPLICATION
addappid(1729660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1729661, 1, "abc938bd38199ae4411c953e4129b149d0f6b9da079883913e79748d7225743f")

