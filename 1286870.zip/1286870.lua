-- Lua provided by RyzenAPI 
-- Game: Nevertales: Hearthbridge Cabinet Collector's Edition
addappid(1286870)
addappid(1286871, 1, "b75a67c131fd46ba0d996ad4acb5cd858bd2d0d84f19d6d56a917b21725dba15")
