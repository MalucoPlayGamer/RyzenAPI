-- Lua provided by RyzenAPI
-- Game: Game: MechWarrior Online™ Legends

-- MAIN APPLICATION
addappid(342200)
-- Game: addappid(342200)

-- MAIN APP DEPOTS / PACKAGES
addappid(342201, 1, "12285849aaf10836b6960bfd4e55f616991f2e64391b136463436acbec3f23db")
