-- Lua provided by RyzenAPI
-- Game: Rogue Assault

-- MAIN APPLICATION
addappid(4264680)
