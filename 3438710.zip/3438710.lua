-- Lua provided by RyzenAPI
-- Game: Game: Minimal Moba Playtest

-- MAIN APPLICATION
addappid(3438710)
-- Game: addappid(3438710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438711, 1, "ea8ce832f9cbf89e49760ada305a0f7d709361fdafb3bfe6a1f78ad646951b55")
