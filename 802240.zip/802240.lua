-- Lua provided by RyzenAPI
-- Game: 802240

-- MAIN APPLICATION
addappid(802240)
-- Game: addappid(802240)

-- MAIN APP DEPOTS / PACKAGES
addappid(802241, 1, "bdf1769312edc4768e7379b0b4d9105e56c7fd2110560d22e456c72d731fd71d")
