-- Lua provided by SkyAPI 
-- Game: AppID 802240
addappid(802240)
addappid(802241, 1, "bdf1769312edc4768e7379b0b4d9105e56c7fd2110560d22e456c72d731fd71d")
