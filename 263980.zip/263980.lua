-- Lua provided by RyzenAPI
-- Game: Out There Somewhere

-- MAIN APPLICATION
addappid(263980)
-- Game: addappid(263980)

-- MAIN APP DEPOTS / PACKAGES
addappid(263982,0,"2668e1026b30d8d1a743de08ea4b5ba4f3eba3f6e90b07e6c1fc39f739117159")
addappid(263983,0,"9e372686c18e8b7a975ed1ef01367c4335cb87200870b18aa113bea206723de6")
addappid(450960,0,"8c55dc61b29b905aa06fb0d82405a554de39a676eaa4408e3f2241e0f08ecc2f")
