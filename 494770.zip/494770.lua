-- Lua provided by RyzenAPI
-- Game: addappid(494770)

-- MAIN APPLICATION
addappid(494770)

-- MAIN APP DEPOTS / PACKAGES
addappid(494773,0,"8cf64c4bfc45223b024f0b5cdc22c2f6c5a67ae0843013a628093bac76ee42d8")
