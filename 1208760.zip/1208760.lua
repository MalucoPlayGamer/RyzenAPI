-- Lua provided by RyzenAPI
-- Game: View From Below

-- MAIN APPLICATION
addappid(1208760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1208761, 1, "1a7dde7dbcf035a31205c7bf767ce394c10aeb39469f5f3f7fd81f722f4de6b4")

