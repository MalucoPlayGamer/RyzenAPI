-- Lua provided by RyzenAPI
-- Game: View From Below

-- MAIN APPLICATION
addappid(1208760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208761, 1, "1a7dde7dbcf035a31205c7bf767ce394c10aeb39469f5f3f7fd81f722f4de6b4")

