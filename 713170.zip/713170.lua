-- Lua provided by RyzenAPI
-- Game: unBorn

-- MAIN APPLICATION
addappid(713170)

-- MAIN APP DEPOTS / PACKAGES
addappid(713171,0,"161069dec550ce12ac38c42bb168c496a3902f5d2dac4c0b428d7de92b218b0c")

