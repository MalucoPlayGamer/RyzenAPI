-- Lua provided by RyzenAPI
-- Game: Game: POG 4

-- MAIN APPLICATION
addappid(1666810)
-- Game: addappid(1666810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666811, 1, "cfac0156329e32580a6f52031b84583152cd499980d706c16f2819069c2e9fc3")
