-- Lua provided by SkyAPI 
-- Game: POG 4
addappid(1666810)
addappid(1666811, 1, "cfac0156329e32580a6f52031b84583152cd499980d706c16f2819069c2e9fc3")
