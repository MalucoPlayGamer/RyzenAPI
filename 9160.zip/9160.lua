-- Lua provided by RyzenAPI
-- Game: 9160

-- MAIN APPLICATION
addappid(9160)
-- Game: addappid(9160)

-- MAIN APP DEPOTS / PACKAGES
addappid(9161, 1, "b01e9bc5943b6445f2dd7dbb3a75eab7635fffc5b265c6b09bc9af8cfb92374d")
