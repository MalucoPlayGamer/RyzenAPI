-- Lua provided by RyzenAPI 
-- Game: AppID 2052970
addappid(2052970)
addappid(2052971, 1, "a35e88cb228abc5ec0d678a3422974b99a6c006e420f70f70a1ca1ce49e952ce")
