-- Lua provided by RyzenAPI
-- Game: addappid(2052970)

-- MAIN APPLICATION
addappid(2052970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052971, 1, "a35e88cb228abc5ec0d678a3422974b99a6c006e420f70f70a1ca1ce49e952ce")
