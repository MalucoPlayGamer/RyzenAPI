-- Lua provided by RyzenAPI
-- Game: Arcus

-- MAIN APPLICATION
addappid(1479960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1479961, 1, "d848eb512de2c7c6dbd0ddf0b33c91953d2435f0eb98563e6bb82fc40bc1db72")

