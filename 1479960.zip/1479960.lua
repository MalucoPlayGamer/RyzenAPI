-- Lua provided by RyzenAPI 
-- Game: Arcus
addappid(1479960)
addappid(1479961, 1, "d848eb512de2c7c6dbd0ddf0b33c91953d2435f0eb98563e6bb82fc40bc1db72")
