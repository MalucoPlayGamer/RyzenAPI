-- Lua provided by RyzenAPI
-- Game: 无上道

-- MAIN APPLICATION
addappid(1248220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248221, 1, "4dbe785f1bff96a2b8156ca114430afa60ee5b99cf862852064b075f0103c786")

