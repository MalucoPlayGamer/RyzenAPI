-- Lua provided by RyzenAPI
-- Game: Zefyr: A Thief's Melody

-- MAIN APPLICATION
addappid(1344990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344991, 1, "bd71f1bd90921b1664ae1799ba2abf6a1e46780127a4b932b1d6c66a4815bd33")

