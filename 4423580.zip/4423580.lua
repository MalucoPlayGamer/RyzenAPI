-- Lua provided by RyzenAPI
-- Game: Shadow Dungeon

-- MAIN APPLICATION
addappid(4423580)

-- MAIN APP DEPOTS / PACKAGES
addappid(4423581,0,"fa6d5e8b4f2ea3d8dacd02c20086cc8b10505fd45f5e0577517254dcbe97bd02")

