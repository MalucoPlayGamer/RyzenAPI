-- Lua provided by RyzenAPI
-- Game: RPG NPC Simulator VR

-- MAIN APPLICATION
addappid(1130560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130561, 1, "7eccf544e920d28bffb8a3df95f908b3f2a60becd8ce217ab881221629dce4db")

