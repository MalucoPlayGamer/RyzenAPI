-- Lua provided by RyzenAPI
-- Game: The Black Signal

-- MAIN APPLICATION
addappid(2597380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597381, 1, "13e08fe146d7fbfd76274900ade36f77d6c33b8639a553f0a5139b6a79397016")
