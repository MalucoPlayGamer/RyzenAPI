-- Lua provided by RyzenAPI
-- Game: be you 2

-- MAIN APPLICATION
addappid(1361810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361811, 1, "fd10cffa1aa2dc940104e6d6f168757adc1e82c55d3310acb7be3008912f6805")
