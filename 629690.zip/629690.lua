-- Lua provided by RyzenAPI 
-- Game: Vaporum
addappid(629690)
addappid(629691, 1, "c88a64cd73358e0a4a483d798af7942666412929f975948c40dbb3d7c1db8707")
addappid(629694, 1, "ad1ae18df64d60ae06ea8f7b948709eebcc5096cb6a8dcf1434081ae9a864c00")
addappid(629695, 1, "79740bbecff510a66cdc506adb9c2dacf112c5345e9e533647e2b52c782cf462")
