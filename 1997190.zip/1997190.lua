-- Lua provided by RyzenAPI
-- Game: Hentai Big Tits

-- MAIN APPLICATION
addappid(1997190)
-- Game: addappid(1997190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997191, 1, "2e0f5d13e9db158eb35c69118e640d165861fb98b1e18db0ddec2396a7ef0d5a")
