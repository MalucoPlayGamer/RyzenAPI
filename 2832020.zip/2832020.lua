-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Mysterious Clinic

-- MAIN APPLICATION
addappid(2832020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832021, 1, "e6b11b53d06b4aa472b4815f8917278a3d5edf92afc9a9b8ee1c2f8da9f2f251")
