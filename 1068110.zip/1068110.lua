-- Lua provided by RyzenAPI 
-- Game: AppID 1068110
addappid(1068110)
addappid(1068111, 1, "b44ddd25b628c024c5ba8a9c2cdc3f539df5ed4543dfa0dc129fc3b99311773d")
