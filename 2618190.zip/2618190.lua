-- Lua provided by RyzenAPI
-- Game: addappid(2618190)

-- MAIN APPLICATION
addappid(2618190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618191, 1, "9dce74025147fa47be4cd5f213b7d5095f5c0b5aa34886acbdb6002d2a9f7c07")
