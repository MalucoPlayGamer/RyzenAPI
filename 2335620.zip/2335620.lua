-- Lua provided by RyzenAPI 
-- Game: Delve Into Pawssion
addappid(2335620)
addappid(2335621, 1, "0039faa4f0d1fb0a98ab2d4afd4ced140091317702dd3d5708c53e27ff83c9ad")
