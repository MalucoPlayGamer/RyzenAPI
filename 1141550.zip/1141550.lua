-- 1141550's Lua and Manifest Created by Hubcap Manifest
-- CUCKOLD SIMULATOR: Life as a Beta Male Cuck
-- Created: May 29, 2026 at 20:18:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1141550, 1, "e1f616c909c1c29bfb3d1141dd829fb7b0eb1ac7bf4d5373e6954411142bc03c") -- CUCKOLD SIMULATOR: Life as a Beta Male Cuck
-- MAIN APP DEPOTS
addappid(1141551, 1, "51ea3cfe06ce1156a8ca562c78a638afe933250b3252eae6b33100da90016860") -- CUCKOLD SIMULATOR: Life as a Beta Male Content
setManifestid(1141551, "5128926407922970004", 10029008052)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- CUCKOLD SIMULATOR Covid-19 Mask (AppID: 1618840)
addappid(1618840)
addappid(1618841, 1, "72a7c3a287f93de0af9d649e863439c814c5a927366869975fcb02448051b9ee") -- CUCKOLD SIMULATOR Covid-19 Mask - CUCKOLD SIMULATOR: Covid-19 Mask 2
setManifestid(1618841, "762395762634575019", 13631485)
-- CUCKOLD SIMULATOR Coomers Delight (AppID: 1812160)
addappid(1812160)
addappid(1812161, 1, "30ff5117f71879b066586288a39519d2ef5c61c0ac9abbcfae147c38ebc64c43") -- CUCKOLD SIMULATOR Coomers Delight - CUCKOLD SIMULATOR: Coomer's Delight 2
setManifestid(1812161, "7458495184317434677", 8109108)
-- CUCKOLD SIMULATOR Ukraine Supporter Pack (AppID: 2265340)
addappid(2265340)
addappid(2265340, 1, "6c50e51b6e62620452f53772ee358721d8a383de99886dea8f0f1d81b5a7f8aa") -- CUCKOLD SIMULATOR Ukraine Supporter Pack - Depot 2265340
setManifestid(2265340, "8940253925747232941", 17612425)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1618840) -- Depot 1618840 (empty depot)
-- addappid(1812160) -- Depot 1812160 (empty depot)