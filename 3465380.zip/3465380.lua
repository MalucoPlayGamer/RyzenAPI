-- Lua provided by RyzenAPI
-- Game: Burger Shop 3 Soundtrack

-- MAIN APPLICATION
addappid(3465380)
-- Game: addappid(3465380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3465381, 1, "89b31b33a49b100c628878765372a733498c6f39c7d2628b63830c5e90a10552")
