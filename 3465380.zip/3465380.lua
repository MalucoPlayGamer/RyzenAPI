-- Lua provided by SkyAPI 
-- Game: Burger Shop 3 Soundtrack
addappid(3465380)
addappid(3465381, 1, "89b31b33a49b100c628878765372a733498c6f39c7d2628b63830c5e90a10552")
