-- Lua provided by RyzenAPI
-- Game: AppID 1380390

-- MAIN APPLICATION
addappid(1380390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1380391, 1, "f97fb8cf15d9a0dd9ac90469575a08a1ef417a9dff23bbd8bbd6df4a0698f75f")

