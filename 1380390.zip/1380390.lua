-- Lua provided by SkyAPI 
-- Game: AppID 1380390
addappid(1380390)
addappid(1380391, 1, "f97fb8cf15d9a0dd9ac90469575a08a1ef417a9dff23bbd8bbd6df4a0698f75f")
