-- Lua provided by RyzenAPI
-- Game: addappid(699290)

-- MAIN APPLICATION
addappid(699290)

-- MAIN APP DEPOTS / PACKAGES
addappid(699291, 1, "c69bd36118782f8151e6611b5c4b994e4c922093e34f2c01820e20f43a41cbdb")
