-- Lua provided by RyzenAPI
-- Game: 残神觉醒-BROKEN God Awakening Demo

-- MAIN APPLICATION
addappid(2443070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443071, 1, "c3170b0996117a0fb7423d6614182348e8c40265e86a160ac620f0f0840c600c")

