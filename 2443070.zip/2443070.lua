-- Lua provided by RyzenAPI 
-- Game: AppID 2443070
addappid(2443070)
addappid(2443071, 1, "c3170b0996117a0fb7423d6614182348e8c40265e86a160ac620f0f0840c600c")
