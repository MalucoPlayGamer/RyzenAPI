-- Lua provided by RyzenAPI
-- Game: 真・三国无双８ 帝国 - 男女用自建“狐狸仿装套装”

-- MAIN APPLICATION
addappid(1684158)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684158,0,"3ce719c0b41398a4473087bec92b0d34d8394ec596ef4eb420c5050183c36754")

