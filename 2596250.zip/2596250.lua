-- Lua provided by RyzenAPI
-- Game: Cactus Simulator 2

-- MAIN APPLICATION
addappid(2596250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596251, 1, "0aab8398c77deb647ac9e5e383dd249c2c5399a025189f3a236e205b6482d41c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
