-- Lua provided by RyzenAPI
-- Game: addappid(2596250)

-- MAIN APPLICATION
addappid(2596250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596251, 1, "0aab8398c77deb647ac9e5e383dd249c2c5399a025189f3a236e205b6482d41c")
