-- Lua provided by RyzenAPI
-- Game: Game: Agent Roy - Zombie Hunt

-- MAIN APPLICATION
addappid(2274800)
-- Game: addappid(2274800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274801, 1, "f8c1aa04dd03eb807717be8fa17f8c79cfef60223a117c501e9a6ebeabfeae49")
