-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Super Retro JRPG Music Pack

-- MAIN APPLICATION
addappid(1638830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638830,0,"9c097f17a78c8f217d41f9aacae8ff7aaaa30c8d876a41185b50a6b54e859eec")
