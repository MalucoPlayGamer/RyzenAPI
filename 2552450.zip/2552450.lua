-- Lua provided by RyzenAPI
-- Game: KINGDOM HEARTS III + Re Mind (DLC)

-- MAIN APPLICATION
addappid(2552450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552452,0,"0996809871cd2add5b4175ad4c447a5d00c6455fede02b10d99b47120c70c1a6")
addappid(2552453,0,"a74f30fcc9178ac8e59620ca6ba41f0954a596611c7b4c61d9cd652d22d1190f")
addappid(2552454,0,"f852f8b48069d5d7f51767b97648e38ce1551464cc872db21ce10081b5355c68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
