-- Lua provided by RyzenAPI
-- Game: Hoven the Sages Spinel

-- MAIN APPLICATION
addappid(398960)

-- MAIN APP DEPOTS / PACKAGES
addappid(398961, 1, "5b108135702a136843a887fe895e6add39efdc592a370a03b82db4db73baaf84")
