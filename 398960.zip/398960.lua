-- Lua provided by RyzenAPI 
-- Game: Hoven the Sages Spinel
addappid(398960)
addappid(398961, 1, "5b108135702a136843a887fe895e6add39efdc592a370a03b82db4db73baaf84")
