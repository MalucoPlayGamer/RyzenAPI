-- Lua provided by RyzenAPI
-- Game: Project Adder (Prologue)

-- MAIN APPLICATION
addappid(2598410)
-- Game: addappid(2598410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598411, 1, "174a05ce0e560d41106a91e7acd4a3f385fd2e3fa927f9e951169b84df0f232b")
