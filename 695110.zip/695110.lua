-- Lua provided by RyzenAPI
-- Game: 695110

-- MAIN APPLICATION
addappid(695110)
-- Game: addappid(695110)

-- MAIN APP DEPOTS / PACKAGES
addappid(695111, 1, "b836d18110aaca3874b4f36d911043a0da379424ed9bbedbb6cfc6ef6199f71a")
