-- Lua provided by RyzenAPI
-- Game: AppID 1558480

-- MAIN APPLICATION
addappid(1558480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558481, 1, "2cdfd9de9f3d161e88cb1afd6f22f905e63de7a32f38d4d4e5c351229a1c24b9")
