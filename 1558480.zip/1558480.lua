-- Lua provided by RyzenAPI
-- Game: My Territory Was Witches' Island!?

-- MAIN APPLICATION
addappid(1558480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1558481, 1, "2cdfd9de9f3d161e88cb1afd6f22f905e63de7a32f38d4d4e5c351229a1c24b9")
