-- Lua provided by RyzenAPI
-- Game: Cairn

-- MAIN APPLICATION
addappid(1588550)
addappid(4031100)
-- Game: addappid(1588550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588551, 1, "4ce5dce22497dfd82c8fc6fc3a6f0c4f9961a811d460ab7ab6a590b717cae583")
addappid(4031101, 0, "a7b1bec9765224ce4eb45fd57d5111b7625aa4f21fd5a64f8f5a13851c770abe")
