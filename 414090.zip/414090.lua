-- Lua provided by RyzenAPI
-- Game: The Warden

-- MAIN APPLICATION
addappid(414090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(414091, 1, "3c1509ed8f795e4e2a7ce3e551d5dba08dda90ee8b1713ced3c8aa593825d813")

