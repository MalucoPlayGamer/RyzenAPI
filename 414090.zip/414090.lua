-- Lua provided by RyzenAPI
-- Game: AppID 414090

-- MAIN APPLICATION
addappid(414090)

-- MAIN APP DEPOTS / PACKAGES
addappid(414091, 1, "3c1509ed8f795e4e2a7ce3e551d5dba08dda90ee8b1713ced3c8aa593825d813")

