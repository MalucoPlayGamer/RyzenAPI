-- Lua provided by RyzenAPI
-- Game: Heroes of the Three Kingdoms 7

-- MAIN APPLICATION
addappid(1437880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437881, 1, "4ac27d396a4ec44d450af4a6fd865392c2edaa35bfa01637a6f432fdf3f7dbdf")
addappid(1437882, 1, "e1721291b635e01cc173a1bd7bd20b070543cd0230bbb83149feb3ca456de19f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
