-- Lua provided by RyzenAPI
-- Game: Flight of the Athena

-- MAIN APPLICATION
addappid(751940)

-- MAIN APP DEPOTS / PACKAGES
addappid(751941,0,"47fdfa91b5fa90b2208679d62bed4e8b1d5768ea67cb4c37eeb8907da1006f00")

