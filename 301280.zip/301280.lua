-- Lua provided by RyzenAPI
-- Game: 301280

-- MAIN APPLICATION
addappid(301280)
-- Game: addappid(301280)

-- MAIN APP DEPOTS / PACKAGES
addappid(301281, 1, "7ffc4347e349c8503314f1cb1ee522e82f1f07642a76fdc9f11658adda0fde86")
