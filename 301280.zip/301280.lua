-- Lua provided by RyzenAPI
-- Game: AppID 301280

-- MAIN APPLICATION
addappid(301280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(301281, 1, "7ffc4347e349c8503314f1cb1ee522e82f1f07642a76fdc9f11658adda0fde86")

