-- Lua provided by RyzenAPI
-- Game: Game: AppID 1096240

-- MAIN APPLICATION
addappid(1096240)
-- Game: addappid(1096240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096241, 1, "2db9389f2281f15c79761dc24893fb039927d51c90e0c78f3e0f832f3af51032")
