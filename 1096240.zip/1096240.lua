-- Lua provided by SkyAPI 
-- Game: AppID 1096240
addappid(1096240)
addappid(1096241, 1, "2db9389f2281f15c79761dc24893fb039927d51c90e0c78f3e0f832f3af51032")
