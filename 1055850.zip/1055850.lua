-- Lua provided by RyzenAPI
-- Game: Inspector Waffles

-- MAIN APPLICATION
addappid(1055850)
-- Game: addappid(1055850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055851, 1, "a3cc8b8acccab917981606947965c90927e6ead92b030ef92948f925770c1b1d")
