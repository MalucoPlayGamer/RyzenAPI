-- Lua provided by RyzenAPI
-- Game: Game: Idol Hunter : Hentai

-- MAIN APPLICATION
addappid(1916380)
-- Game: addappid(1916380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916381, 1, "6aec734f842ad589a018ce07afdf7c63edec122fa17d9e7c9573375131896d09")
