-- Lua provided by RyzenAPI
-- Game: Idol Hunter : Hentai

-- MAIN APPLICATION
addappid(1916380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916381, 1, "6aec734f842ad589a018ce07afdf7c63edec122fa17d9e7c9573375131896d09")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
