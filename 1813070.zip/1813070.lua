-- Lua provided by RyzenAPI 
-- Game: Andy's Apple Farm Demo
addappid(1813070)
addappid(1813071, 1, "f9643002a77b36e6c6b0161408c87ddbab958e965efcb259b83c8a48ba4d51ca")
