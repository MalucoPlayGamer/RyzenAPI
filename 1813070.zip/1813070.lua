-- Lua provided by RyzenAPI
-- Game: addappid(1813070)

-- MAIN APPLICATION
addappid(1813070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813071, 1, "f9643002a77b36e6c6b0161408c87ddbab958e965efcb259b83c8a48ba4d51ca")
