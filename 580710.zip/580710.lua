-- Lua provided by SkyAPI 
-- Game: AppID 580710
addappid(580710)
addappid(580711, 1, "564c4c372a4e15e0931c7275cd1d9c4cdf01f0046836b8e00c42f24e77aecd60")
