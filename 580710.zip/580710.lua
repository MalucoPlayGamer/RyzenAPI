-- Lua provided by RyzenAPI
-- Game: Afghanistan '11

-- MAIN APPLICATION
addappid(580710)
addappid(812130)

-- MAIN APP DEPOTS / PACKAGES
addappid(580711, 1, "564c4c372a4e15e0931c7275cd1d9c4cdf01f0046836b8e00c42f24e77aecd60")
