-- Lua provided by SkyAPI 
-- Game: Sonata Theory
addappid(1663200)
addappid(1663201, 1, "22bd616f8e6d21039ee3a4b265ff06d8a6659d77f89c46766fdab8ca0d1d846b")
