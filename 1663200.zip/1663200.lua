-- Lua provided by RyzenAPI
-- Game: Sonata Theory

-- MAIN APPLICATION
addappid(1663200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663201, 1, "22bd616f8e6d21039ee3a4b265ff06d8a6659d77f89c46766fdab8ca0d1d846b")
