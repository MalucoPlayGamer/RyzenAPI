-- Lua provided by RyzenAPI
-- Game: Sonata Theory

-- MAIN APPLICATION
addappid(1663200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663201, 1, "22bd616f8e6d21039ee3a4b265ff06d8a6659d77f89c46766fdab8ca0d1d846b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
