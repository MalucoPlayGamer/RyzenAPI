-- Lua provided by RyzenAPI
-- Game: 梗过100关

-- MAIN APPLICATION
addappid(2808490)
-- Game: addappid(2808490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808491, 1, "ecc1cee96c2356d89548bca1b4cd790fb5632ffe2df617784bd63303b0601f46")
