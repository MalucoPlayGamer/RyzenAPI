-- Lua provided by RyzenAPI
-- Game: Game: Lagoon Lounge 2 : The Secret Roommate

-- MAIN APPLICATION
addappid(2754340)
-- Game: addappid(2754340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754341, 1, "68f9e3f877426f09ea2e33d8571c38c2c72436b5c468cb6fbd362b391839ecd4")
