-- Lua provided by RyzenAPI
-- Game: The Wrath of the Goose King

-- MAIN APPLICATION
addappid(2787630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787631, 1, "8a0f3f5d4f4c6263e02b49f80faa1b9ccf233f3630d892ec20e89f4fb03e23b7")
