-- Lua provided by RyzenAPI
-- Game: addappid(396060)

-- MAIN APPLICATION
addappid(396060)

-- MAIN APP DEPOTS / PACKAGES
addappid(396061, 1, "fc92c4e1dd9cfd579c74d2d4a09a0b5811eb845570f5ad45b978fe023b923d1b")
