-- Lua provided by RyzenAPI
-- Game: 2011600

-- MAIN APPLICATION
addappid(2011600)
-- Game: addappid(2011600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011601, 1, "2c261f079316f04a6ccc23db2b0fced43215cd6d08930f6de80462dd6f64b748")
