-- Lua provided by RyzenAPI
-- Game: Superfighters Deluxe

-- MAIN APPLICATION
addappid(855860)

-- MAIN APP DEPOTS / PACKAGES
addappid(855861, 1, "c2ffe8f910948e3d9b3855dae6f58b0ae013a0b2bdf622df4ea5ee1ac8983a0d")

