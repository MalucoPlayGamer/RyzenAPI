-- Lua provided by RyzenAPI 
-- Game: AppID 777390
addappid(777390)
addappid(777391, 1, "a6e5d498f86dfbf88f426e2e5288146bd29093d8f0bc1737f02d61ee7de996dc")
