-- Lua provided by RyzenAPI
-- Game: Gravity Island

-- MAIN APPLICATION
addappid(420370)

-- MAIN APP DEPOTS / PACKAGES
addappid(420371, 1, "85c2b10e7a2193849396d1c864a323a2b4a9472e5cee0e299285f704187c140f")
