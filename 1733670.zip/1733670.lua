-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1733670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733670,0,"8cec6ee314800bd149ad800400d1cb68cfd6c5d32125e7298eacbd854369a801")

