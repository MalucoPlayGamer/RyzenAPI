-- Lua provided by RyzenAPI
-- Game: Game: AppID 743320

-- MAIN APPLICATION
addappid(743320)
-- Game: addappid(743320)

-- MAIN APP DEPOTS / PACKAGES
addappid(743321, 1, "607696627d9fb71a7abb13c9f597b877c0b641bc359d85e3f3d3a13c9d1e903b")
