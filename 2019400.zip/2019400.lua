-- Lua provided by SkyAPI 
-- Game: DORAEMON STORY OF SEASONS Friends of the Great Kingdom Demo
addappid(2019400)
addappid(2019401, 1, "5e861e46e3cd4f08b75fd80a65449a615affa58cde186d159779a5935797c257")
