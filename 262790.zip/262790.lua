-- Lua provided by RyzenAPI
-- Game: Our Darker Purpose

-- MAIN APPLICATION
addappid(262790)

-- MAIN APP DEPOTS / PACKAGES
addappid(262791, 1, "44b1dddd9ae0682650feff0b41419635ce44dfb181f83b9dd9ac9f13cdcf4709")
addappid(334390, 0, "1d7ad90bfc7509fd4b196ae0fe4553b5b4a83c4f63583855b4faf6e80ee866c5")
