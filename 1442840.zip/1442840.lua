-- Lua provided by RyzenAPI
-- Game: DIG - Deep In Galaxies

-- MAIN APPLICATION
addappid(1442840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442844,0,"c185fcdc5b3332031930475b2b943b035986013a42d20ebd5496e06a1ef34155")

