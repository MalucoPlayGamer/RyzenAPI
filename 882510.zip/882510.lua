-- Lua provided by RyzenAPI
-- Game: Your Car Shooter

-- MAIN APPLICATION
addappid(882510)

-- MAIN APP DEPOTS / PACKAGES
addappid(882511, 1, "9883db8acb1abfbcdc1afef7076686d7419fcd2dc622b5bc219fd3918742555f")

