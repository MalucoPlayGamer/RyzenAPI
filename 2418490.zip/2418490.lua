-- Lua provided by RyzenAPI
-- Game: Trakonius

-- MAIN APPLICATION
addappid(2418490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418491,0,"3e9b1ee2025cf64e80481945bac851abbdef9672f86e2f4e96c9ca1d3de782b2")

