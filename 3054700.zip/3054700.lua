-- Lua provided by RyzenAPI
-- Game: 3054700

-- MAIN APPLICATION
addappid(3054700)
-- Game: addappid(3054700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054701, 1, "175ab63b016b5ac0a685d5e521551c430772aed9bfbc42345079a617dfde6392")
