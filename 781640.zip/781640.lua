-- Lua provided by RyzenAPI
-- Game: AppID 781640

-- MAIN APPLICATION
addappid(781640)

-- MAIN APP DEPOTS / PACKAGES
addappid(781641, 1, "bac6f3bcc1085c3ea52ce43b04003856dc9924fe3c637a6c6c4897f384a54af1")
