-- Lua provided by SkyAPI 
-- Game: AppID 781640
addappid(781640)
addappid(781641, 1, "bac6f3bcc1085c3ea52ce43b04003856dc9924fe3c637a6c6c4897f384a54af1")
