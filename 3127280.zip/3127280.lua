-- Lua provided by RyzenAPI
-- Game: Marvel Contest of Champions

-- MAIN APPLICATION
addappid(3127280)
