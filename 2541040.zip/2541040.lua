-- Lua provided by RyzenAPI 
-- Game: AppID 2541040
addappid(2541040)
addappid(2541041, 1, "d8eca114cd50dc3348730889f3876dd8976827bf3dc172ca228f661ebe0280c0")
