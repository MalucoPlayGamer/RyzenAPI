-- Lua provided by RyzenAPI
-- Game: Grapple Tournament

-- MAIN APPLICATION
addappid(1384320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384321, 1, "6d573c6ac204bc17430b6a2fbb05bd8a525621e9b03ada73788932cc8ad45b7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
