-- Lua provided by RyzenAPI
-- Game: Grapple Tournament

-- MAIN APPLICATION
addappid(1384320)
-- Game: addappid(1384320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384321, 1, "6d573c6ac204bc17430b6a2fbb05bd8a525621e9b03ada73788932cc8ad45b7b")
