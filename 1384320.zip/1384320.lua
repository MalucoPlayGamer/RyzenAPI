-- Lua provided by RyzenAPI 
-- Game: Grapple Tournament
addappid(1384320)
addappid(1384321, 1, "6d573c6ac204bc17430b6a2fbb05bd8a525621e9b03ada73788932cc8ad45b7b")
