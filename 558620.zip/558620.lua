-- Lua provided by SkyAPI 
-- Game: AppID 558620
addappid(558620)
addappid(558621, 1, "05e48a79e5df9ca213f138e1ef6381d4a925d3b689933dafa7e6dfde1bc5e974")
