-- Lua provided by RyzenAPI
-- Game: addappid(558620)

-- MAIN APPLICATION
addappid(558620)

-- MAIN APP DEPOTS / PACKAGES
addappid(558621, 1, "05e48a79e5df9ca213f138e1ef6381d4a925d3b689933dafa7e6dfde1bc5e974")
