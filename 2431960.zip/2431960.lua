-- Lua provided by RyzenAPI
-- Game: 擱淺地 - Dream Antique

-- MAIN APPLICATION
addappid(2431960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431961, 1, "88cd4581af90e9f9f35f77a7df4261e649b7747fa4deecd934071b49fba5ddc2")

