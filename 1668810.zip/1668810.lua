-- Lua provided by RyzenAPI
-- Game: 1668810

-- MAIN APPLICATION
addappid(1668810)
-- Game: addappid(1668810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668811, 1, "0fb66cabb9c190935489baad1750285213ff295003965ae180b08366a6c86ffb")
