-- Lua provided by RyzenAPI
-- Game: Forbidden Offering

-- MAIN APPLICATION
addappid(3067680)
-- Game: addappid(3067680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3067682,0,"906f87941ff02cf8e2ef57dd82c28e6009d0b05b3f481fd93537c91aed0890f5")
