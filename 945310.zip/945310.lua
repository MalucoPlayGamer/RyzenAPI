-- Lua provided by SkyAPI 
-- Game: Hyper Visualizer
addappid(945310)
addappid(945311, 1, "9ac8cf14a485de4dcfa5941cd7641d2585e7a2c7828592c81d1cc6e4f69d1295")
