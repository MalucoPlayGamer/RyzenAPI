-- Lua provided by RyzenAPI
-- Game: Hyper Visualizer

-- MAIN APPLICATION
addappid(945310)
-- Game: addappid(945310)

-- MAIN APP DEPOTS / PACKAGES
addappid(945311, 1, "9ac8cf14a485de4dcfa5941cd7641d2585e7a2c7828592c81d1cc6e4f69d1295")
