-- Lua provided by RyzenAPI
-- Game: AppID 209340

-- MAIN APPLICATION
addappid(209340)
addappid(228983)
addappid(228990)
addappid(229002)

-- MAIN APP DEPOTS / PACKAGES
addappid(209341, 1, "8b94003b2256c81c3cf8a18781cf3f9aa88513fde1982c326273f529810b878a")
addappid(209342, 1, "7fa5fb2a4780f7301080824c34058ffb5e2d75d19d4a63f18f26863bada52b5f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(209343)
