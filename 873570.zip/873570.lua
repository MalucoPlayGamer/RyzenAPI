-- Lua provided by RyzenAPI
-- Game: AppID 873570

-- MAIN APPLICATION
addappid(873570)

-- MAIN APP DEPOTS / PACKAGES
addappid(873571, 1, "f25356e017a9b1b76b81cfa2f64f567c5a0dfc1766fdc450d3a6b6d6537ecdbb")

