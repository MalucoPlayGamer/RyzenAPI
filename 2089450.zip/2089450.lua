-- Lua provided by RyzenAPI
-- Game: Game: Hot Springs Story 2

-- MAIN APPLICATION
addappid(2089450)
-- Game: addappid(2089450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089451, 1, "43f9c70bb33eb9d0b264ada46b9b27dda12bcc016eed6f4bf1f4ea6875c7c63d")
