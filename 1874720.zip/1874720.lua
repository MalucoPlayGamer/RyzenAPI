-- Lua provided by RyzenAPI
-- Game: Elf World Adventure: Part 1

-- MAIN APPLICATION
addappid(1874720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874721, 1, "4ad364148931cec642d6e421cc7ac537bb5dc88894fe614e8c73c869157f1e17")
