-- Lua provided by RyzenAPI
-- Game: Cyan's Snow House

-- MAIN APPLICATION
addappid(2856090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856092,0,"399827f4e8ce25f836b10f713fd310dcad3b22f96af00c368261560f0a1edf88")
addappid(2856093,0,"78cdb1fe5f1e490600b0f29af8fa788ee9d715ab4c8f4b7d40d52d16b2be073a")

