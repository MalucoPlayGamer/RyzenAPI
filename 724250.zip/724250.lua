-- Lua provided by RyzenAPI
-- Game: Princess Maker 5

-- MAIN APPLICATION
addappid(724250)

-- MAIN APP DEPOTS / PACKAGES
addappid(724251,0,"d8075eb1e51d67c6ad0d1da0d1d65e5e01d85e2f50b90068ec7a1deb617ead40")
addappid(724252,0,"0362ef675773fa22b16b1f2d991191172e437fd7b90ecda936543724c80eb33e")
addappid(724253,0,"680a0dd36e3617af4d2dfdbe5c0df18f7905e8ab14183e904f030b549a563025")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
