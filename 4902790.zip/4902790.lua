-- Lua provided by RyzenAPI
-- Game: Rule or Fall

-- MAIN APPLICATION
addappid(4902790) -- Rule or Fall

-- MAIN APP DEPOTS / PACKAGES
addappid(4902791, 1, "c0b66af1e5364c1ff285b32c849db9b93d9a756de7459068f9b852e5a71173bf") -- Depot 4902791
addappid(4902792, 1, "1216bace116078a62a2a217eaed2497fd4bd004deb0302a36af3f7a3224138e0") -- Depot 4902792

