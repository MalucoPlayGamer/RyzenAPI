-- 4902790's Lua and Manifest Created by Hubcap Manifest
-- Rule or Fall
-- Created: August 11, 2026 at 23:23:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4902790) -- Rule or Fall
-- MAIN APP DEPOTS
addappid(4902791, 1, "c0b66af1e5364c1ff285b32c849db9b93d9a756de7459068f9b852e5a71173bf") -- Depot 4902791
setManifestid(4902791, "6343582187383832932", 135950792)
addappid(4902792, 1, "1216bace116078a62a2a217eaed2497fd4bd004deb0302a36af3f7a3224138e0") -- Depot 4902792
setManifestid(4902792, "2879114854449583006", 139367768)