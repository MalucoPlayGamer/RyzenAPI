-- Lua provided by RyzenAPI
-- Game: Modules

-- MAIN APPLICATION
addappid(2266160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2266161, 1, "98ff098c0e628d54e67841219f0e24e70bcc05533ac4468f3b7b227810b7fb33")

