-- Lua provided by RyzenAPI
-- Game: Modules

-- MAIN APPLICATION
addappid(2266160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266161, 1, "98ff098c0e628d54e67841219f0e24e70bcc05533ac4468f3b7b227810b7fb33")
