-- Lua provided by SkyAPI 
-- Game: Shmup Love Boom
addappid(387110)
addappid(387111, 1, "71fe0ee4724d89f8551400177281f1d92831d7a2f03bfc0544527221a244b9b8")
addappid(387120, 0, "101f7664ed379787f1cf3b0224016fb6ba53d240b6fcebeab6132cae247072ee")
