-- Lua provided by RyzenAPI
-- Game: Raji: Prologue

-- MAIN APPLICATION
addappid(1429740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429741, 1, "eb97db0223880996b74f319bd9f004aae4a8c4e9460d0b2d633a788ec4c71a4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
