-- Lua provided by SkyAPI 
-- Game: Raji: Prologue
addappid(1429740)
addappid(1429741, 1, "eb97db0223880996b74f319bd9f004aae4a8c4e9460d0b2d633a788ec4c71a4c")
