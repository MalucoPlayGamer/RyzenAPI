-- Lua provided by RyzenAPI
-- Game: addappid(822150)

-- MAIN APPLICATION
addappid(822150)

-- MAIN APP DEPOTS / PACKAGES
addappid(822151, 1, "c111f57cf06049330c2dec74e7b27a8d5397f22feb0e638f23772324920792bb")
