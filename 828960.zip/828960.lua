-- Lua provided by RyzenAPI 
-- Game: Blonde Driver
addappid(828960)
addappid(828961, 1, "d961d606bc18bcee73b35288ea930ac6b53851d14ae3e3a4f12577c8743c597e")
