-- Lua provided by SkyAPI 
-- Game: Girls Memory Card
addappid(1355010)
addappid(1355011, 1, "2ff144f1e63d011bc6bfab7f86d6372d8b54a1aec8202b348e287d17438b15c2")
addappid(1355130, 0, "5f9ab99c019c204a187288ee5d21eb7d71e095112c6b810214af99eca4199375")
