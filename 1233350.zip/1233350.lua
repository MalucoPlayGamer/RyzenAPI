-- Lua provided by RyzenAPI
-- Game: Random Heroes: Gold Edition

-- MAIN APPLICATION
addappid(1233350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233351, 1, "24deb47f6214b63f7eb7b3e4392e645c5310be43a4fa3cd165b56fd1599bd9b3")
