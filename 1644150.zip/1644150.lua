-- Lua provided by RyzenAPI
-- Game: 1644150

-- MAIN APPLICATION
addappid(1644150)
-- Game: addappid(1644150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644151, 1, "0935afa6e2c11a0ffdc4a251e994d866480837b6136d6ff50144dabc028ba14b")
