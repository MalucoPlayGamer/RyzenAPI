-- Lua provided by RyzenAPI
-- Game: AppID 63640

-- MAIN APPLICATION
addappid(63640)
-- Game: addappid(63640)

-- MAIN APP DEPOTS / PACKAGES
addappid(63641, 1, "87237fd841c1914216b2bace23db90d426637317fdd076727ecfbf444cb8e204")
