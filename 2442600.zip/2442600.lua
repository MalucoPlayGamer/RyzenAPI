-- Lua provided by RyzenAPI
-- Game: Goobies Demo

-- MAIN APPLICATION
addappid(2442600)
-- Game: addappid(2442600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442601, 1, "69852b51ed9a4c52df5c5e05a455dbc09780648cc97f729d2cb4cbeafdf6a2a4")
