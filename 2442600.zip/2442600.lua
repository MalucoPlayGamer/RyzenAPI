-- Lua provided by SkyAPI 
-- Game: Goobies Demo
addappid(2442600)
addappid(2442601, 1, "69852b51ed9a4c52df5c5e05a455dbc09780648cc97f729d2cb4cbeafdf6a2a4")
