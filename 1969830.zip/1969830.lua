-- Lua provided by RyzenAPI
-- Game: Dadish 3

-- MAIN APPLICATION
addappid(1969830)
-- Game: addappid(1969830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969831, 1, "c26fc69500e28a64ebcbf4ad68ad6eef6dbfe3532a4e9df50ef2d8942d010870")
