-- Lua provided by SkyAPI 
-- Game: Xenoids
addappid(1890750)
addappid(1890751, 1, "bf41ff259ce3ba59b81303f9045ca5dc2b3d05689293db4735f04d359735f92b")
