-- Lua provided by RyzenAPI
-- Game: Healing Spree

-- MAIN APPLICATION
addappid(1271110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271111, 1, "5dba4de5dbef286224a4d110be4fcc86169f5572c2f3584e5ff3e3a7ac996733")
