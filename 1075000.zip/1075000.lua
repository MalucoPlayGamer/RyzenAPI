-- Lua provided by RyzenAPI
-- Game: Beyond the Stars VR

-- MAIN APPLICATION
addappid(1075000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1075001, 1, "75a152502dd40d920c7e0c5cf4b78c4a9c2a74019982bde1ee2b3732936d7494")

