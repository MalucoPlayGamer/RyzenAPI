-- Lua provided by SkyAPI 
-- Game: AppID 1075000
addappid(1075000)
addappid(1075001, 1, "75a152502dd40d920c7e0c5cf4b78c4a9c2a74019982bde1ee2b3732936d7494")
