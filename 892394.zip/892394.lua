-- Lua provided by RyzenAPI
-- Game: Wang Yi (Dudou Costume)/王異「肚兜風コスチューム」

-- MAIN APPLICATION
addappid(892394)
-- Game: addappid(892394)

-- MAIN APP DEPOTS / PACKAGES
addappid(892394,0,"3832dc80a47763d4e04df32f49ee2a7451bae345662a104671223e7f344a784a")
