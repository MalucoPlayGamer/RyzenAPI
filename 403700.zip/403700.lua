-- Lua provided by RyzenAPI
-- Game: Zero Punctuation: Hatfall - Hatters Gonna Hat Edition

-- MAIN APPLICATION
addappid(403700)
-- Game: addappid(403700)

-- MAIN APP DEPOTS / PACKAGES
addappid(403701, 1, "2ecac3b42830cb0153d586ce0c439cceedbe49e6a7ce3eb573f7fd1e4b38c05a")
