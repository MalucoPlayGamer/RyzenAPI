-- 1670700's Lua and Manifest Created by Hubcap Manifest
-- Influence, Inc.
-- Created: August 26, 2026 at 12:08:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1670700) -- Influence, Inc.
-- MAIN APP DEPOTS
addappid(1670701, 1, "98c78b517874725577d8e86df05130a322610836ac3572abd077df8dd899b1ce") -- Depot 1670701
setManifestid(1670701, "5576420812110053501", 252184295)