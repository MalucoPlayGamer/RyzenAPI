-- Lua provided by RyzenAPI
-- Game: Influence, Inc.

-- MAIN APP DEPOTS / PACKAGES
addappid(1670700) -- Influence, Inc.
addappid(1670701, 1, "98c78b517874725577d8e86df05130a322610836ac3572abd077df8dd899b1ce") -- Depot 1670701

