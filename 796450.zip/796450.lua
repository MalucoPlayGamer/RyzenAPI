-- Lua provided by RyzenAPI
-- Game: AppID 796450

-- MAIN APPLICATION
addappid(796450)

-- MAIN APP DEPOTS / PACKAGES
addappid(796451, 1, "c2748b6806a81cdad17ff06686bae5a7282d9545858ef17c3deb373c18783feb")

