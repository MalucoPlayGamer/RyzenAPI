-- Lua provided by RyzenAPI
-- Game: Monkey King vs Transformers

-- MAIN APPLICATION
addappid(1447570)
-- Game: addappid(1447570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447571, 1, "fc4ab2878bab4c143be6d1f03ffd9ed1912e014ce05374c4244a6cb3ec12853f")
