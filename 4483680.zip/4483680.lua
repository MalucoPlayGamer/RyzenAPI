-- 4483680's Lua and Manifest Created by Hubcap Manifest
-- The Lonely Miner
-- Created: July 26, 2026 at 03:47:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4483680) -- The Lonely Miner
-- MAIN APP DEPOTS
addappid(4483681, 1, "01dccda62d557242c3554696222b72b4a083a6219cafe62caf13846359f2c137") -- Depot 4483681
setManifestid(4483681, "5591178129207082036", 138541234)