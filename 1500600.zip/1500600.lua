-- Lua provided by RyzenAPI
-- Game: Game: Demonpact: Clarice

-- MAIN APPLICATION
addappid(1500600)
-- Game: addappid(1500600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500601, 1, "3e821f69710312b550ebac3b1777b82ba365e97f65b23f5bed00955179db6d7a")
