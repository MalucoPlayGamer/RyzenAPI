-- Lua provided by RyzenAPI
-- Game: Thomas Scott

-- MAIN APPLICATION
addappid(1279480)
-- Game: addappid(1279480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279481, 1, "0848ca8f7576fb3b3905eb7e8a7bbde3d463bbbb33c9123b74d0de0fe41278ed")
