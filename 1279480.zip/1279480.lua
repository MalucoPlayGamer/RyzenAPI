-- Lua provided by RyzenAPI
-- Game: Thomas Scott

-- MAIN APPLICATION
addappid(1279480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1279481, 1, "0848ca8f7576fb3b3905eb7e8a7bbde3d463bbbb33c9123b74d0de0fe41278ed")

