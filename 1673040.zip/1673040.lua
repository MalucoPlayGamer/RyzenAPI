-- Lua provided by RyzenAPI
-- Game: Genderbend Me! Sayonara Demon Dong

-- MAIN APPLICATION
addappid(1673040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673041, 1, "8d63966ac1cd75129f758b4d520d5ed4ae5ee77fc7dc264dc640b379a6f019c9")

