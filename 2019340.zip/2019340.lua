-- Lua provided by RyzenAPI
-- Game: addappid(2019340)

-- MAIN APPLICATION
addappid(2019340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019341, 1, "8b5f2a05225036542054d5984688bc5847be97fa49bb0fbbc4e9bb2171aad5de")
