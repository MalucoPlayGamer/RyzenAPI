-- Lua provided by RyzenAPI
-- Game: 洛神见月

-- MAIN APPLICATION
addappid(2066780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066781, 1, "55d8317c5aee6f3885dc91cfb30e15998e92b34dccb66ceaef626362719496d1")

