-- Lua provided by RyzenAPI
-- Game: Max Mustard Digital Art Book

-- MAIN APPLICATION
addappid(2875210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875210,0,"487a250df9d566524d7623f7350d9bd792d27429e2a149a5040b3d9bd4ee4620")

