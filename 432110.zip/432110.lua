-- Lua provided by RyzenAPI
-- Game: addappid(432110)

-- MAIN APPLICATION
addappid(432110)

-- MAIN APP DEPOTS / PACKAGES
addappid(432111, 1, "6e9ef6b3d1d41e38ebb93386ecccbba52c7696d932aebbe4ec0a2fd5010414c2")
