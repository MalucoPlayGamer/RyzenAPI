-- Lua provided by RyzenAPI
-- Game: ATC4: Airport NARITA [RJAA]

-- MAIN APPLICATION
addappid(2670310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670310,0,"fd9e680fa895022ae6e766c46d3a79bd498bb7d735c0d42a547d185dfb3b87b9")

