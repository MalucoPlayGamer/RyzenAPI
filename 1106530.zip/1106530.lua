-- Lua provided by RyzenAPI
-- Game: GemCraft - Frostborn Wrath

-- MAIN APPLICATION
addappid(1106530)
-- Game: addappid(1106530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106531, 1, "cf3c895989a3efb77d5132b99e63fcb94b26eb0c4888913640fc998e80394e04")
