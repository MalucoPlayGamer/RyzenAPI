-- Lua provided by RyzenAPI
-- Game: Shaped Touches

-- MAIN APPLICATION
addappid(1656900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656901, 1, "6e756d9fed11cabc7430db7c653196f223e1d9cec2bb9b79f0d33a0285a61922")
