-- Lua provided by RyzenAPI
-- Game: Shaped Touches

-- MAIN APPLICATION
addappid(1656900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656901, 1, "6e756d9fed11cabc7430db7c653196f223e1d9cec2bb9b79f0d33a0285a61922")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
