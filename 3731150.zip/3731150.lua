-- Lua provided by RyzenAPI
-- Game: (The Lingering) Graveyard Visit

-- MAIN APPLICATION
addappid(3731150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731151, 1, "4ec014a7cde0b185963764ad3e4f9708ef7c4238f994c72ffec86171a6c150f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
