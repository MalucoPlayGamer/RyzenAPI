-- Lua provided by RyzenAPI
-- Game: (The Lingering) Graveyard Visit

-- MAIN APPLICATION
addappid(3731150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731151, 1, "4ec014a7cde0b185963764ad3e4f9708ef7c4238f994c72ffec86171a6c150f7")
