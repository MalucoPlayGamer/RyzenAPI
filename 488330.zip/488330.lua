-- Lua provided by RyzenAPI 
-- Game: Highway to the Moon
addappid(488330)
addappid(488331, 1, "1e5a97803cc277cf29277d99cc775e14d371f7a8e1a355951c55ff6382a80e5f")
