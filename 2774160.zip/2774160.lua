-- Lua provided by RyzenAPI
-- Game: 2774160

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2774160)
addappid(2774161)
addappid(2774163)
addappid(2774164)
-- Game: addappid(2774160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774162,0,"eb11529af3e3ec94c6f0d77f44f459fb659b0dfdfc8ebf83cfd8f3a6798f0c12")
