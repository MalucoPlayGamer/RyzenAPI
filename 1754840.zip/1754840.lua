-- Lua provided by RyzenAPI
-- Game: Hacker Simulator

-- MAIN APPLICATION
addappid(1754840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754841, 1, "a712e4d1bec4f811a9996e477ce6a964372106b3970ce86a38153fef3d12619d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
