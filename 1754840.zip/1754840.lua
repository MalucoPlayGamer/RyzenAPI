-- Lua provided by RyzenAPI
-- Game: Hacker Simulator

-- MAIN APPLICATION
addappid(1754840)
-- Game: addappid(1754840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754841, 1, "a712e4d1bec4f811a9996e477ce6a964372106b3970ce86a38153fef3d12619d")
