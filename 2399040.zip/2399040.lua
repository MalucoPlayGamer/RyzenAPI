-- Lua provided by RyzenAPI
-- Game: Sentinels

-- MAIN APPLICATION
addappid(2399040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399041, 1, "cd44de5548df4634a53a10e161b57bb8912dc494e1ecbd0fdca6b5e5d29ae94d")
