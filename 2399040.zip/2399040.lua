-- Lua provided by RyzenAPI 
-- Game: Sentinels
addappid(2399040)
addappid(2399041, 1, "cd44de5548df4634a53a10e161b57bb8912dc494e1ecbd0fdca6b5e5d29ae94d")
