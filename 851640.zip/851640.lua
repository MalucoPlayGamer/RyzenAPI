-- Lua provided by SkyAPI 
-- Game: Marble Race
addappid(851640)
addappid(851641, 1, "793354dee20e9da79004a3535e678f9125b5f8d5e2437c62cc1806d717e34e1f")
