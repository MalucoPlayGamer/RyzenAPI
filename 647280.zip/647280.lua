-- Lua provided by RyzenAPI
-- Game: AppID 647280

-- MAIN APPLICATION
addappid(647280)

-- MAIN APP DEPOTS / PACKAGES
addappid(647281, 1, "ef5d134f1cdcdfe44e669bbc4fd4ec7e9ed36ddd843c08aed70b72c002943413")

