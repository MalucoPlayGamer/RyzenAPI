-- Lua provided by SkyAPI 
-- Game: Dusk Pub - OST
addappid(2880100)
addappid(2880101, 1, "12e4872d5bd99693a38d7eba6849f9b8e702f3ba5c28ddd04bf15890d154593a")
addappid(2880200, 0, "d1fc01d21b6da07d8b797a25fecbf0d07d435462e21dbcac7e12b15ff5276f21")
