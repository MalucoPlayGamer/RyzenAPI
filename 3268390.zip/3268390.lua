-- Lua provided by RyzenAPI
-- Game: Tavern Talk - Supporter Upgrade

-- MAIN APPLICATION
addappid(3268390)
-- Game: addappid(3268390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268390,0,"9e8081ed036846f8aa20f8e62a4035f8a7ee114684a97b4a1481ad96e943be16")
