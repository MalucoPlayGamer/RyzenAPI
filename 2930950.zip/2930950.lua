-- Lua provided by RyzenAPI
-- Game: Game: Dream of Things 物之梦

-- MAIN APPLICATION
addappid(2930950)
-- Game: addappid(2930950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930951, 1, "83200e93dcd7da7a0e73c87a5f19ecaf37a538f275df5ba4e11d42332418e50e")
