-- Lua provided by RyzenAPI
-- Game: Warehouse Simulator: Forklift Driver

-- MAIN APPLICATION
addappid(1885640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885641, 1, "90dbde502283ae78b9880e8411d37a1a9bd68699163188ca5adf5d4bad3adabd")
