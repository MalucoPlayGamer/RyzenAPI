-- Lua provided by RyzenAPI
-- Game: Warehouse Simulator: Forklift Driver

-- MAIN APPLICATION
addappid(1885640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1885641, 1, "90dbde502283ae78b9880e8411d37a1a9bd68699163188ca5adf5d4bad3adabd")

