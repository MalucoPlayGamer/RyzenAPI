-- Lua provided by RyzenAPI
-- Game: 1885640

-- MAIN APPLICATION
addappid(1885640)
-- Game: addappid(1885640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885641, 1, "90dbde502283ae78b9880e8411d37a1a9bd68699163188ca5adf5d4bad3adabd")
