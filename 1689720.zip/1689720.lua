-- Lua provided by RyzenAPI
-- Game: addappid(1689720)

-- MAIN APPLICATION
addappid(1689720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689721, 1, "d2f96aef769d733cb1811440871bd63b19db6ced148b3e574c2d9102f52044e1")
