-- Lua provided by RyzenAPI
-- Game: Maze of Infection

-- MAIN APPLICATION
addappid(811990)

-- MAIN APP DEPOTS / PACKAGES
addappid(811991, 1, "c6d5262cf649e9574fa463481ba639e40ef4a6ddb3e4bab5df2d63bc1e999bb7")
