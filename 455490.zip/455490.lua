-- Lua provided by RyzenAPI
-- Game: Don't Die Dateless, Dummy!

-- MAIN APPLICATION
addappid(455490)

-- MAIN APP DEPOTS / PACKAGES
addappid(455491, 1, "a2d93e3d227179aa97be5b06bc988d32927ba30776c4411eb6ce8f02f15779b3")
