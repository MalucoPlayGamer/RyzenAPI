-- Lua provided by RyzenAPI
-- Game: Subway Surfers - 地铁跑酷2018

-- MAIN APPLICATION
addappid(881080)

-- MAIN APP DEPOTS / PACKAGES
addappid(881081, 1, "ebfee492fc117da826eecac733a65bf99ed82fb4d5de5f680c31fe23297cd1ab")

