-- Lua provided by RyzenAPI
-- Game: Now You See

-- MAIN APPLICATION
addappid(1066140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066141, 1, "bc36151c17c0353231194904bbdc01fc549884ed5bcc9ef93ee64aee320f6b93")
