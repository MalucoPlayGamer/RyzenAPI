-- Lua provided by RyzenAPI
-- Game: Scarytales: All Hail King Mongo

-- MAIN APPLICATION
addappid(1081240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081241, 1, "4421c9b906f3440266575097315e786a24e97ed90ff15e5d3af37dd13d00d0b6")
addappid(1081242, 1, "55560a7ba57d1224e6bcf75d5a6f8be7e66e2ed003c258d0f4678422f565508e")
