-- Lua provided by RyzenAPI
-- Game: Ghost fire

-- MAIN APPLICATION
addappid(3071600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071601, 1, "69c5154db63b1910d3bedf62bfd86606191045bb443c07544d8dab27fda08d1d")

