-- Lua provided by RyzenAPI
-- Game: RAGING BILL

-- MAIN APPLICATION
addappid(3710470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3710471,0,"0af993561df49467ab7a0c554da8a9423b6d1561831339d41e64cbb6babf36e3")

