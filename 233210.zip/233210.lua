-- Lua provided by RyzenAPI
-- Game: Game: Air Conflicts: Vietnam

-- MAIN APPLICATION
addappid(233210)
-- Game: addappid(233210)

-- MAIN APP DEPOTS / PACKAGES
addappid(233211, 1, "7eb4c75e9a7929e3a3ccc892c3d11f3aed31ec17faebdf10a139c71f6fb5c261")
addappid(233212, 1, "9f4ad503ed2ca8abd17ee2657e9c7b5467f4d2aae2faf741ce2adf66e1e3db6e")
addappid(233213, 1, "aaeefca552345c693d000f2ed46bbbfa7187a9f752ca70eede4f0bf3c7133f73")
addappid(233214, 1, "ece1f5eea8ea559fe7506073897e11177fdf92a01d47778ba1a0371df3708540")
addappid(233215, 1, "b140609e5f457f87dc7b2012ed42ed70f287c9ee4bbab38a5187630aaaacc634")
addappid(233216, 1, "c5b0bd31dc8001989fdbbe94ef4d200776f494f51102226771d3933bf94d2ade")
addappid(233217, 1, "16e74a0d366f487b4015199d1065f398e95bc246fa80e3f81ebf00ab84106e28")
addappid(233218, 1, "be90ac6fafb185202cc61455d2942c94b5d9d7bbd2bad3f9936d6e9caab26ce4")
addappid(233220, 1, "c65541c83912df5d03a64349f0b8c1ed2fcc60c97d38921056e8adad9a5db9f7")
addappid(233221, 1, "35fee4c3794b2bcdea08a6081fe0dadede003189bb357a665e1545d9d43af716")
