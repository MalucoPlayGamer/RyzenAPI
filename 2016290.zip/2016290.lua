-- Lua provided by RyzenAPI
-- Game: 2016290

-- MAIN APPLICATION
addappid(2016290)
-- Game: addappid(2016290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016291, 1, "21e3bc070ad34df0aba4e8837f96b46b92dbfb96210e0f66e017adc58ac82825")
