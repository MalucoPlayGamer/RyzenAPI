-- Lua provided by RyzenAPI
-- Game: FAR: Lone Sails

-- MAIN APPLICATION
addappid(609320)

-- MAIN APP DEPOTS / PACKAGES
addappid(609322,0,"a1921eed4ffcb5935cfa6fb70f47888f89854645ead6e3b9f2b4b27d4b266357")
addappid(609323,0,"b2b5bfc0fe5dc6cbba03ee5164b09820b8a8a235343afe99e1f0df7471c61501")

