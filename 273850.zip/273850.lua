-- Lua provided by RyzenAPI
-- Game: Ski-World Simulator

-- MAIN APPLICATION
addappid(273850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(273851, 1, "77fb868c9a611a798ad6490432fa73bc34759032ac73b667ada75c6bd02104a0")
addappid(273852, 1, "dd6463bfd1e6dc56f2ba4b7f2821d178bca1f683055dbf395ff8eed67b2d1e82")
addappid(273853, 1, "a49b240179268436d7d9caeb72c1a95e7175adbad275cab9784880cb64fb1c27")
addappid(273854, 1, "aa4ce7e92940b5245ef10a950458941354a1617f04a679ad05b86530ee27e56a")
addappid(273855, 1, "7775dcb635d954b7fc3b553ec909af1b72220b0e35e4cd46357f011b65c9cd98")
addappid(273856, 1, "127db18c91a1e588a0113d962fad6307e0b631e72a5632e1c6193f21cc0eb5cd")

