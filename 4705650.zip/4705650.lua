-- 4705650's Lua and Manifest Created by Hubcap Manifest
-- Silent Shark
-- Created: August 12, 2026 at 15:22:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4705650) -- Silent Shark
-- MAIN APP DEPOTS
addappid(4705651, 1, "07d4c55229f310bbbd9b6ff73456b9eb80cf983da128290ad239b3c8e98a2dd4") -- Depot 4705651
setManifestid(4705651, "8914300902946083595", 342639876)
addappid(4705652, 1, "a22c56d3c15f1a80e9235e8c63650b07052c03a37f2272a7bb219e2256dcbdad") -- Depot 4705652
setManifestid(4705652, "4545855487975927324", 332338360)
addappid(4705653, 1, "72ee6b2d1978f1cc8afdec8152d9f16033d25d8205c81dfff3a1b237a5317518") -- Depot 4705653
setManifestid(4705653, "3254531651928382467", 303328633)