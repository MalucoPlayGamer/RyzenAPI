-- Lua provided by RyzenAPI
-- Game: Dark Playtest

-- MAIN APPLICATION
addappid(2414030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414031, 1, "984ac8dd591751842c3155c3d5889f6255e89dfd71339ca1ef0431a86145cc1d")
