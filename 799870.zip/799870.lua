-- Lua provided by RyzenAPI
-- Game: Game: Neko Dungeon | 喵酱迷城 | 喵醬迷城 | ねこダンジョン

-- MAIN APPLICATION
addappid(799870)
-- Game: addappid(799870)

-- MAIN APP DEPOTS / PACKAGES
addappid(799871, 1, "62466681e06c57eef6d001b724d6f33e5d39457a4e2f1ea437ef20841f8bd719")
addappid(799873, 1, "7d915e4feca2aad5d98e1d5c4758b0219037f23b185ecb5b4400de8cb99b2ea1")
addappid(904270, 0, "a3f765b01a249669ca377b9975e39acd2c386c46872f510481e4484fd9eae413")
addappid(996240, 0, "80639a0a08c90d0609e8ecac841940387bd2f424a620de27283dcea047af815f")
