-- Lua provided by RyzenAPI
-- Game: Date Z

-- MAIN APPLICATION
addappid(1567890)
addappid(2951390)
addappid(2951400)
addappid(2951410)
addappid(2951450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567891, 1, "8a4e20e2b6f94f1d9ae0e6e3179a5f61af63cc3b53e55a80770d10516af37571")

