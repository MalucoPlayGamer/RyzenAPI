-- Lua provided by RyzenAPI
-- Game: AppID 507520

-- MAIN APPLICATION
addappid(507520)

-- MAIN APP DEPOTS / PACKAGES
addappid(507521, 1, "048ef68a39016ffa5f47f3ea24b9a9dda695da57c520aa1265658194a4b5cca9")

