-- Lua provided by RyzenAPI
-- Game: AI Dungeon

-- MAIN APPLICATION
addappid(1519310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519312,0,"24a649273af0d1586a1d1f2bae26681e0cb105ed89075b0b94a85b6dfea03d46")

