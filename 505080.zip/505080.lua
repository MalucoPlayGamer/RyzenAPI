-- Lua provided by RyzenAPI
-- Game: Gakuen Club

-- MAIN APPLICATION
addappid(505080)

-- MAIN APP DEPOTS / PACKAGES
addappid(505081, 1, "1f615cac0cf39f1d061ebdc79274947df251d86aa6576ef6cb67bbead8ff5865")
