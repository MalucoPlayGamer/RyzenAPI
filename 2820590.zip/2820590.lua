-- Lua provided by RyzenAPI
-- Game: addappid(2820590)

-- MAIN APPLICATION
addappid(2820590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820591, 1, "690c3058e40bc5c19c3197650b68f46044cdb676216c1e0c861af29fb0eeafe3")
