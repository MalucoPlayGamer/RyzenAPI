-- Lua provided by RyzenAPI 
-- Game: Sex College 🔞
addappid(2820590)
addappid(2820591, 1, "690c3058e40bc5c19c3197650b68f46044cdb676216c1e0c861af29fb0eeafe3")
