-- Lua provided by RyzenAPI
-- Game: 411860

-- MAIN APPLICATION
addappid(411860)
-- Game: addappid(411860)

-- MAIN APP DEPOTS / PACKAGES
addappid(411861, 1, "a4e34221e857c5314f04faee45638f30c85fad0cc860f7339e4e24f82280e299")
