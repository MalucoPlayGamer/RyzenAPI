-- Lua provided by RyzenAPI
-- Game: The First Class VR

-- MAIN APPLICATION
addappid(630020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(630021, 1, "93b9064ddba1e2a702688038bc271a20b81cc5bf4b4e2ee48ce816124efebe66")

