-- Lua provided by RyzenAPI
-- Game: 630020

-- MAIN APPLICATION
addappid(630020)
-- Game: addappid(630020)

-- MAIN APP DEPOTS / PACKAGES
addappid(630021, 1, "93b9064ddba1e2a702688038bc271a20b81cc5bf4b4e2ee48ce816124efebe66")
