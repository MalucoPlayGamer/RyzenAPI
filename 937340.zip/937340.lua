-- Lua provided by RyzenAPI
-- Game: addappid(937340)

-- MAIN APPLICATION
addappid(937340)

-- MAIN APP DEPOTS / PACKAGES
addappid(937341, 1, "fe4319e0c79072dc9a50d7f893dea593cb66322f0ad48c91669dc797be0278a1")
