-- Lua provided by RyzenAPI
-- Game: Holy Light

-- MAIN APPLICATION
addappid(3042850)
-- Game: addappid(3042850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042851, 1, "b56ac69c5f99c421e5731377013412370c160c138fd8b6484b46db659d40b462")
