-- Lua provided by RyzenAPI
-- Game: Lake of Creatures

-- MAIN APPLICATION
addappid(1808320)
addappid(4575790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808321, 1, "1bd991004d66944b89907627f0ee6208f6fca2ebb1b6aa635e5085db4d9f4cd7")
