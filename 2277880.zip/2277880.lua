-- Lua provided by RyzenAPI
-- Game: 2277880

-- MAIN APPLICATION
addappid(2277880)
-- Game: addappid(2277880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277881, 1, "80fe11554b9c291410eb1faa0ba2b9ae29cfec36cb871d9354f6347c6fcfabd2")
