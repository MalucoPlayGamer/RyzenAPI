-- Lua provided by RyzenAPI
-- Game: Skynet Rising : Portal to the Past

-- MAIN APPLICATION
addappid(516250)

-- MAIN APP DEPOTS / PACKAGES
addappid(516251, 1, "0531814e8c309f39c82a3ea8d1838d00f2ce1fdcd81c8a97c0fd3be24633e812")

