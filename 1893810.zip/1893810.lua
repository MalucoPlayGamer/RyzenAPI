-- Lua provided by RyzenAPI
-- Game: addappid(1893810)

-- MAIN APPLICATION
addappid(1893810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893811, 1, "1e7029fe0f49b6198e77a38bd01242345eab2e81a7ded46b2f212defd18710c3")
