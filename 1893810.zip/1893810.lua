-- Lua provided by RyzenAPI
-- Game: Solium Infernum

-- MAIN APPLICATION
addappid(1893810)
addappid(2893270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893811,0,"1e7029fe0f49b6198e77a38bd01242345eab2e81a7ded46b2f212defd18710c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
