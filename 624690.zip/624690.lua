-- Lua provided by SkyAPI 
-- Game: NEXT JUMP: Shmup Tactics
addappid(624690)
addappid(624691, 1, "790e7b509fdab682e4018e8bea8523f2c5e04caf8a55c0fd0a0e89f2a4fbac3e")
addappid(624692, 1, "d4e2db404cfcff2d06ee175246cfa2b81370a8137eeb0934fbcf6e0ebf253d0a")
addappid(624693, 1, "3b330aa946f3b7365566fa0bd86073700b54d4c6bf5f32dd520ea59446486330")
