-- Lua provided by RyzenAPI
-- Game: The PenguinGame 2 -Lies of Penguin-

-- MAIN APPLICATION
addappid(2513890)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2520200)
