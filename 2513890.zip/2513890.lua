-- Lua provided by RyzenAPI
-- Game: The PenguinGame 2 -Lies of Penguin-

-- MAIN APPLICATION
addappid(2513890)
addappid(2520200)

