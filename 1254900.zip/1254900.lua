-- Lua provided by RyzenAPI
-- Game: 迷雾之夏-The Vigilant Villa

-- MAIN APPLICATION
addappid(1254900)
-- Game: addappid(1254900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254901, 1, "3bb19209380c51601f034bd726a554aa8472cab6fe6fd9a132444cdc87f58e71")
addappid(1388620, 0, "550df287dcf55d874cf597fd7b90a08e0ed2e3131174e5139f26eb2b1b24f95c")
addappid(1390590, 0, "f7b6ebb2ab83239c3db0e586682e5714bf0310d896f072657e9149d914fed6ef")
addappid(1410520, 0, "4a31f97111a37b140ae58a4ce7b8f68d5299c744f67bf51d01863f690a8e6b4d")
