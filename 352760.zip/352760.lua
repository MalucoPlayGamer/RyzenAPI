-- Lua provided by RyzenAPI
-- Game: Game: Kaiju Panic

-- MAIN APPLICATION
addappid(352760)
-- Game: addappid(352760)

-- MAIN APP DEPOTS / PACKAGES
addappid(352761, 1, "af4f8b9cff6cb04a4a3904b1fddb0610b75aeffaf8e1fab42bdbeeec7562410c")
