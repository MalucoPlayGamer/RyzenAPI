-- Lua provided by RyzenAPI
-- Game: addappid(2659560)

-- MAIN APPLICATION
addappid(2659560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659561, 1, "260988b9a7cb4c325edd3b71c2bc847a6821250607d40cf9d221d004ee4cc259")
