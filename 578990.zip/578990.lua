-- Lua provided by RyzenAPI
-- Game: Two Worlds II HD - Shattered Embrace

-- MAIN APPLICATION
addappid(578990)

-- MAIN APP DEPOTS / PACKAGES
addappid(578991, 1, "881886e663ac52c199cc6832bd123fb69c88e99b85855e6c1fa87158c51fadd2")
addappid(578992, 1, "83b5779817d98abe00063cd80c717c46de4052a484502df21adef365c1ea837e")
addappid(578993, 1, "35d3a80da4e42d4d258f72cd3bfae76e9b5ce8bf0129c4aaee02c08a0cea88b5")
addappid(578994, 1, "73541bf42f9ab9e0736f7739f36dbeded860a7af738eb9eade2da34fbbe50343")

