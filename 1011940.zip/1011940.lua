-- Lua provided by RyzenAPI
-- Game: Game: Ideology in Friction

-- MAIN APPLICATION
addappid(1011940)
addappid(1246400)
-- Game: addappid(1011940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011941, 1, "bfe3f65b777618e99c0b3825b73e0b4785c1e576c20829af31dabff68a1185a8")
addappid(1011942, 1, "2abeab98fe2d057bd36ba2ffdd391b2f751e6dd34188910ae29a936c67ba6f96")
