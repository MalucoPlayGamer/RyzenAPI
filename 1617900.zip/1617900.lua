-- Lua provided by RyzenAPI 
-- Game: Head 2 Head
addappid(1617900)
addappid(1617901, 1, "0fec80771239c6e20d1fc82af5638d173be704960cacab9448565a541a432fd6")
