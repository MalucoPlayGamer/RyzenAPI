-- Lua provided by RyzenAPI
-- Game: 1617900

-- MAIN APPLICATION
addappid(1617900)
-- Game: addappid(1617900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617901, 1, "0fec80771239c6e20d1fc82af5638d173be704960cacab9448565a541a432fd6")
