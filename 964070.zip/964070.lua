-- Lua provided by RyzenAPI
-- Game: AppID 964070

-- MAIN APPLICATION
addappid(964070)

-- MAIN APP DEPOTS / PACKAGES
addappid(964071, 1, "1ca35d9f87db8e7f51af1da5e98f76df9e7a12366224bb3c1f05b061caa04868")
