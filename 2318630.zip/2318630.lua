-- Lua provided by SkyAPI 
-- Game: The Territory of Egg
addappid(2318630)
addappid(2318631, 1, "ce3ff69d8816895874a43c13761c333d59455d99f814223535b3623745560f94")
