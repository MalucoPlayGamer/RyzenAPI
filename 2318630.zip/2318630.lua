-- Lua provided by RyzenAPI
-- Game: Game: The Territory of Egg

-- MAIN APPLICATION
addappid(2318630)
-- Game: addappid(2318630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318631, 1, "ce3ff69d8816895874a43c13761c333d59455d99f814223535b3623745560f94")
