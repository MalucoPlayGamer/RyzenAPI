-- Lua provided by RyzenAPI
-- Game: addappid(813280)

-- MAIN APPLICATION
addappid(813280)
addappid(813281)

-- MAIN APP DEPOTS / PACKAGES
addappid(813282,0,"dbba3c0e9a88a83c22528b0dcf44ad1751483f98e6dd0d96057764ccb18c6993")
