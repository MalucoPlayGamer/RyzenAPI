-- Lua provided by RyzenAPI
-- Game: Eiyu*Senki Gold – A New Conquest

-- MAIN APPLICATION
addappid(1518430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518431, 1, "1b20261374e32af60aa660559d8396760d4671f00451d229c70934eac87d03c0")
addappid(1518432, 1, "df47a49800577ab4aab6726d82582d9c23df2c59cc6e0da741339ea073b8689c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
