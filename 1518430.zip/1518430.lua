-- Lua provided by RyzenAPI
-- Game: Game: Eiyu*Senki Gold – A New Conquest

-- MAIN APPLICATION
addappid(1518430)
-- Game: addappid(1518430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518431, 1, "1b20261374e32af60aa660559d8396760d4671f00451d229c70934eac87d03c0")
addappid(1518432, 1, "df47a49800577ab4aab6726d82582d9c23df2c59cc6e0da741339ea073b8689c")
