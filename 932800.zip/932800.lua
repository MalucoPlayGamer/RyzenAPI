-- Lua provided by RyzenAPI
-- Game: Letzte Worte VR

-- MAIN APPLICATION
addappid(932800)

-- MAIN APP DEPOTS / PACKAGES
addappid(932801, 1, "b7d0ee7aecd3452fffb194f34f3a6109947c0324cc0191a923b845aa4f248147")
addappid(932802, 1, "4d830cf363bc24d3b9c02bd34006310bc7ff8a84af08cd241f09669fb14650d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
