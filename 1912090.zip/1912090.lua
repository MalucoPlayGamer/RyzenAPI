-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit "Heshikiri Hasebe"

-- MAIN APPLICATION
addappid(1912090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912090,0,"5d371db8d928687d1538c5d469ab1f177b8aa5a938732295d8f379f38d1455bc")
