-- Lua provided by SkyAPI 
-- Game: Anode Heart
addappid(1592750)
addappid(1592751, 1, "19394723d56e6c05bf076d51f1c3f4325ffbd0a0cccf5fc9fec54174bc937c1c")
addappid(1592752, 1, "70ed27c3b2310fdb4448fb2a2d980e3845fbaec4a7a5b2aad66c2e70934fdfee")
