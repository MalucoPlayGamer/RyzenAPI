-- Lua provided by RyzenAPI
-- Game: AppID 1309620

-- MAIN APPLICATION
addappid(1309620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1309621, 1, "5d61dec4e6d97c716529e5d329421d1b4722b365e810d2f5df55f7b000f083ab")

