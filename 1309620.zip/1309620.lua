-- Lua provided by RyzenAPI
-- Game: AppID 1309620

-- MAIN APPLICATION
addappid(1309620)
-- Game: addappid(1309620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309621, 1, "5d61dec4e6d97c716529e5d329421d1b4722b365e810d2f5df55f7b000f083ab")
