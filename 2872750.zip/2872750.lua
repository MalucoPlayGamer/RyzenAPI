-- Lua provided by SkyAPI 
-- Game: Dungeon Dev
addappid(2872750)
addappid(2872751, 1, "0066e676cfd284cf645219e3ca070731675ca6aa10e29b35e3ec37be391eadf7")
