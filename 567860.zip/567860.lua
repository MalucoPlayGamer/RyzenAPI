-- Lua provided by RyzenAPI
-- Game: addappid(567860)

-- MAIN APPLICATION
addappid(567860)

-- MAIN APP DEPOTS / PACKAGES
addappid(567861, 1, "925f8c222b7d60b0f455d591c3e1f8c8e2031a07b79b887f0e09e0d1c7f261d7")
