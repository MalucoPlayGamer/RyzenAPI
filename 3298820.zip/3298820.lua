-- Lua provided by RyzenAPI
-- Game: Game: My proud girlfriend-Lina Chapter

-- MAIN APPLICATION
addappid(3298820)
-- Game: addappid(3298820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298821, 1, "385748bd7f86aa9e28ef1feb815184b9a0f0234abe408cada3598e600c3eff26")
