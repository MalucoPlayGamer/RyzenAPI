-- Lua provided by RyzenAPI
-- Game: Naheulbeuk's Dungeon Master - Official Soundtrack

-- MAIN APPLICATION
addappid(2659000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659001, 1, "6d34f88ff313e95327b01ca99f5adbf49d013feb67e45d01810a660c43f434d2")

