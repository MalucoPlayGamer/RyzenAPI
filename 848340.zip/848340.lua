-- Lua provided by RyzenAPI
-- Game: seccia.dev

-- MAIN APPLICATION
addappid(848340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(848341, 1, "6656a365a4b8217dc627f3c7f0192ec5d79c4a6d993634986d92b2c07df247a2")

