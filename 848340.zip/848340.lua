-- Lua provided by RyzenAPI
-- Game: 848340

-- MAIN APPLICATION
addappid(848340)
-- Game: addappid(848340)

-- MAIN APP DEPOTS / PACKAGES
addappid(848341, 1, "6656a365a4b8217dc627f3c7f0192ec5d79c4a6d993634986d92b2c07df247a2")
