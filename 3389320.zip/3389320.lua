-- 3389320's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Kristina is streaming
-- Created: December 08, 2025 at 11:21:28 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3389320) -- Hentai Clicker: Kristina is streaming
-- MAIN APP DEPOTS
addappid(3389321, 1, "b771e51aed7f40cb56043ef5878d7383921fdfb4f6b1b26215384330caf39866") -- Depot 3389321
setManifestid(3389321, "7039942460742698162", 170980268)