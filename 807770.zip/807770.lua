-- Lua provided by RyzenAPI
-- Game: Game: AppID 807770

-- MAIN APPLICATION
addappid(807770)
-- Game: addappid(807770)

-- MAIN APP DEPOTS / PACKAGES
addappid(807771, 1, "ee6af641f5eef187162cd3320849505c2148e9ff0acdbe81a5be777025c57842")
