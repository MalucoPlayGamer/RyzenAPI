-- Lua provided by RyzenAPI
-- Game: Stellar Reflections

-- MAIN APPLICATION
addappid(2763820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763821, 1, "4e08d0472f5e1e84d0942d91aa10798831d422883603786f2b92348caa3c5e1f")
