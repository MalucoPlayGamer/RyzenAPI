-- Lua provided by RyzenAPI
-- Game: Expeditions: Conquistador Editor

-- MAIN APPLICATION
addappid(297700)

-- MAIN APP DEPOTS / PACKAGES
addappid(297701, 1, "2bd565ffaa1a77e35153b9315656822ded6abb8fa37ddae1010a2d0a04e0ce97")

