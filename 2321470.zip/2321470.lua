-- Lua provided by RyzenAPI
-- Game: addappid(2321470)

-- MAIN APPLICATION
addappid(2321470)
addappid(2782850)
addappid(3818560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321471, 1, "18154d412c1c3c3719d8f05c119354536a5228cdd169ca75488708a215c1cddf")
