-- Lua provided by RyzenAPI
-- Game: Dracula 4 and  5 - Special Steam Edition

-- MAIN APPLICATION
addappid(279560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(279561, 1, "a1d2ec63571e9e03b0bee185ddac26bded251aa0d4a604221a5d66e495ba4e66")
addappid(279562, 1, "ee3c74ee0b642a91402d7e22866f0ac436b02d61396b164c86c76d628e70f83d")
