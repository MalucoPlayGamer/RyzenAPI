-- Lua provided by RyzenAPI
-- Game: Game: AppID 279560

-- MAIN APPLICATION
addappid(279560)
-- Game: addappid(279560)

-- MAIN APP DEPOTS / PACKAGES
addappid(279561, 1, "a1d2ec63571e9e03b0bee185ddac26bded251aa0d4a604221a5d66e495ba4e66")
addappid(279562, 1, "ee3c74ee0b642a91402d7e22866f0ac436b02d61396b164c86c76d628e70f83d")
