-- Lua provided by RyzenAPI
-- Game: USA Truck Simulator

-- MAIN APPLICATION
addappid(1568180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568181, 1, "48a1a62c6c35c37c688fb6c31f88a4fc3598c332c97463db0359f71265e08adb")

