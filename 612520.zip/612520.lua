-- Lua provided by RyzenAPI 
-- Game: Sudden Strike 2 Gold
addappid(612520)
addappid(612521, 1, "a959fadd02d9e61e2bacaf19c6bbe11ff0b9d20cb46b1960db14b2d1ee287f38")
addappid(612522, 1, "4a84486433e8b53c062a9b0e658fad49a7c3675f5e5a95e7586c690ddb3c7e4e")
addappid(612523, 1, "187467908bd137364b2c3901e861021e033fcb70e133f4b10d44d491e4a6d5ce")
addappid(612524, 1, "6811dd32fbd2628d3f854fd612d7ede8a6fc7b46c0d1ba43e1a0a52e5a16817e")
