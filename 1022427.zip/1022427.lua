-- Lua provided by RyzenAPI
-- Game: DFF NT: Sin's Spur, Jecht's 4th Weapon

-- MAIN APPLICATION
addappid(1022427)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022427,0,"c10a927db8fdf52121ab21621de5eb5a0a8e969a0490f59b0db4c2f4cf09cb44")
