-- Lua provided by RyzenAPI
-- Game: Cat Go! Ultimate Challenge

-- MAIN APPLICATION
addappid(1505980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505981, 1, "e40be124695c7ae9980febe3ed2f7448783a949e272803af68780c8f6a39d089")

