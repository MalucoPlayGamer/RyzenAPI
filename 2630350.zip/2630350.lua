-- Lua provided by RyzenAPI
-- Game: Game: Yatagarasu Enter the Eastward

-- MAIN APPLICATION
addappid(2630350)
-- Game: addappid(2630350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2630351, 1, "237734e930c8c837417a3f523ae386911751bb52c00c178d8ac8a9a2602ede06")
