-- Lua provided by RyzenAPI
-- Game: Protocol: Children of War

-- MAIN APPLICATION
addappid(1878460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878461, 1, "d7dbf021fd2432233080568e51ef58c3145bd532812c1760e31dd5c340f6434c")

