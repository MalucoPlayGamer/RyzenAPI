-- Lua provided by RyzenAPI
-- Game: Eredia: The Diary of Heroes

-- MAIN APPLICATION
addappid(713180)

-- MAIN APP DEPOTS / PACKAGES
addappid(713181, 1, "ed654484374d4299e8d98e097ee480ba9d344de84719ce9bea38ed7b3bf519d1")
