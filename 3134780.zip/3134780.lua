-- Lua provided by RyzenAPI
-- Game: Born to Breed

-- MAIN APPLICATION
addappid(3134780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134781, 1, "3c98f70f793fbde3eca45a4fab3487b1c26e8575761895ce97c25894f9ce7e48")

