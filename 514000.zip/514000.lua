-- Lua provided by RyzenAPI
-- Game: Long Gone Days Art Book

-- MAIN APPLICATION
addappid(514000)

-- MAIN APP DEPOTS / PACKAGES
addappid(514000,0,"96b04e52e033d44f004c0abcf2bf9206c2b4b5206e70a54668a09da723bb921f")
