-- Lua provided by RyzenAPI
-- Game: 汉尘：腐草为萤 Demo

-- MAIN APPLICATION
addappid(2802360)
-- Game: addappid(2802360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802361, 1, "7cec10f13effdd6c1a7a872db6dfd0d98d7f1272912a8d9dc1553b49367a2262")
