-- Lua provided by RyzenAPI
-- Game: Game: CuberPunk 2089

-- MAIN APPLICATION
addappid(938300)
-- Game: addappid(938300)

-- MAIN APP DEPOTS / PACKAGES
addappid(938301, 1, "045320eb156d0f301e6c22bbc594371d808757863e1ea859ccd427ff4246f0e0")
