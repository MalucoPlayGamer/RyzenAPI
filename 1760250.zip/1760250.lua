-- Lua provided by RyzenAPI
-- Game: Madden NFL 23

-- MAIN APPLICATION
addappid(1760250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760251, 1, "06ae0f293f54b9f3685a3ef05883bac8072755d091dbe3339e1e2dea40af336e")
addappid(1760252, 1, "f7abdc362476d7e2bd8c1a90a29968ca87089e45f0ba197283dab28d007537d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1760260)
addappid(1827540)
addappid(1914410)
addappid(1914411)
addappid(1914412)
addappid(1934670)
