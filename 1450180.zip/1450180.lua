-- Lua provided by RyzenAPI
-- Game: Haunt Chaser

-- MAIN APPLICATION
addappid(1450180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1450181, 1, "084b183e28e7ef9ec6a42e0acea65a7b9f4bd666100f4e6490c320a9ec4f400d")

