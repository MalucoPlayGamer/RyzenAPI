-- Lua provided by RyzenAPI 
-- Game: Haunt Chaser
addappid(1450180)
addappid(1450181, 1, "084b183e28e7ef9ec6a42e0acea65a7b9f4bd666100f4e6490c320a9ec4f400d")
