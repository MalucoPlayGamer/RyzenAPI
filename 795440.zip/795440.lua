-- Lua provided by RyzenAPI
-- Game: 795440

-- MAIN APPLICATION
addappid(795440)
-- Game: addappid(795440)

-- MAIN APP DEPOTS / PACKAGES
addappid(795441, 1, "9768b0300373292cd80bb5ac8ac5094d74e54756c54c357e232ed97aff733e21")
