-- Lua provided by RyzenAPI
-- Game: Game: If only I could go home early

-- MAIN APPLICATION
addappid(2115610)
-- Game: addappid(2115610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115611, 1, "b03d80382c43fa77773f7b5219b3326d5801d4a07400192af43a67f8c06c55f0")
