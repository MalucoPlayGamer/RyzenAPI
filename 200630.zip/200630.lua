-- Lua provided by RyzenAPI
-- Game: Game: AppID 200630

-- MAIN APPLICATION
addappid(200630)
-- Game: addappid(200630)

-- MAIN APP DEPOTS / PACKAGES
addappid(200631, 1, "973bd8c6501a4af47d8435bdeb2ddf86e4916f4a5c157f1f83fe081b7d9f560f")
