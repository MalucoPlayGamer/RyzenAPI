-- Lua provided by SkyAPI 
-- Game: GIRLS' FRONTLINE 2: EXILIUM
addappid(3347400)
addappid(3347401, 1, "84863480d73a0fc3ebd6af74d03091baeebe152595c08294c2a2b23f62afc50e")
