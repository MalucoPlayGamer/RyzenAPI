-- Lua provided by RyzenAPI
-- Game: addappid(3347400)

-- MAIN APPLICATION
addappid(3347400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347401, 1, "84863480d73a0fc3ebd6af74d03091baeebe152595c08294c2a2b23f62afc50e")
