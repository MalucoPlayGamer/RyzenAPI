-- Lua provided by SkyAPI 
-- Game: Valley of Shadows
addappid(2850850)
addappid(2850851, 1, "d854490969c95c971fae6f929c024d66005a9600e7fe25309437743da9e7bb0f")
