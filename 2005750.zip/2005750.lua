-- Lua provided by RyzenAPI 
-- Game: Collapse Relapse
addappid(2005750)
addappid(2005751, 1, "57b3294798b833bd63503d1799b299e91b0d4e69526ebda289353e6164512751")
