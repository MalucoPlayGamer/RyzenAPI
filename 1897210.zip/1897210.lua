-- Lua provided by RyzenAPI
-- Game: Lost in Play Demo

-- MAIN APPLICATION
addappid(1897210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897211, 1, "6a984886cdd4a3b37a62be7b5af9149f23f5897204b96d6f09b435fdbbad161d")
