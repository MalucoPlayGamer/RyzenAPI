-- Lua provided by RyzenAPI 
-- Game: Survival RPG: The Lost Treasure
addappid(1480050)
addappid(1480051, 1, "05fb8b65c4617d8006a4db5950783a4be4908a7687ac8f988df4e2e55af25667")
