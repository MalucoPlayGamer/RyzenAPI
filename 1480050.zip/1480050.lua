-- Lua provided by RyzenAPI
-- Game: Survival RPG: The Lost Treasure

-- MAIN APPLICATION
addappid(1480050)
-- Game: addappid(1480050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480051, 1, "05fb8b65c4617d8006a4db5950783a4be4908a7687ac8f988df4e2e55af25667")
