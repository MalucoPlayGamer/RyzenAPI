-- Lua provided by RyzenAPI 
-- Game: WhaleGameOnline
addappid(2661210)
addappid(2661211, 1, "bbcac27ebad67177bb1069f8b5254c82919b04b77272dd86213f993de43181ee")
