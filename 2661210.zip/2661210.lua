-- Lua provided by RyzenAPI
-- Game: WhaleGameOnline

-- MAIN APPLICATION
addappid(2661210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661211, 1, "bbcac27ebad67177bb1069f8b5254c82919b04b77272dd86213f993de43181ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
