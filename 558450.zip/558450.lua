-- Lua provided by SkyAPI 
-- Game: Fibrillation HD
addappid(558450)
addappid(558451, 1, "d39181e7ba21b0b24ecf5ab03a38861e4fd03de5bfd76225c7d684f632617ffa")
addappid(558452, 1, "0a29d8bd3abb7ccad335f54e210be5eae89d5be2312df8f6770594388f37b7d2")
