-- Lua provided by RyzenAPI
-- Game: 3057430

-- MAIN APPLICATION
addappid(3057430)
-- Game: addappid(3057430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057431, 1, "97962ebb89413761c3ade47e6c93b7e57cad26c91dfb03620dc56af7ef220909")
