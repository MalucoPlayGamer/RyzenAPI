-- Lua provided by RyzenAPI
-- Game: addappid(2800980)

-- MAIN APPLICATION
addappid(2800980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800981, 1, "fc636b14c8c29d766dd30cbeab3966663bb0e9ec724759ccab4b66d2ea128c81")
