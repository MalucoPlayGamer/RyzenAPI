-- Lua provided by SkyAPI 
-- Game: Hentai Casino
addappid(2800980)
addappid(2800981, 1, "fc636b14c8c29d766dd30cbeab3966663bb0e9ec724759ccab4b66d2ea128c81")
