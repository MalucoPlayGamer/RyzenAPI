-- Lua provided by RyzenAPI
-- Game: 三国英雄坛

-- MAIN APPLICATION
addappid(2001050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001051, 1, "e95a7e5936621ccdb4880fe4ca4f34424d17c111709a81d2744d47d899723a4c")

