-- Lua provided by RyzenAPI
-- Game: addappid(435840)

-- MAIN APPLICATION
addappid(435840)

-- MAIN APP DEPOTS / PACKAGES
addappid(435841, 1, "4cca4cbd060adea0a159fcaf057919c70ef9658b806e1e7870d58d0a7dd77c1c")
