-- Lua provided by RyzenAPI
-- Game: The Preposterous Awesomeness of Everything

-- MAIN APPLICATION
addappid(435840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(435841, 1, "4cca4cbd060adea0a159fcaf057919c70ef9658b806e1e7870d58d0a7dd77c1c")

