-- Lua provided by RyzenAPI
-- Game: Punch A Bunch

-- MAIN APPLICATION
addappid(1512590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512591, 1, "7a368a3cc1912e1e8b4a946fad878d0beac6801c6878242d926595d845148c64")
