-- Lua provided by RyzenAPI
-- Game: 3402530

-- MAIN APPLICATION
addappid(3402530)
-- Game: addappid(3402530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402531, 1, "cd8a012bb6725a1443e905eb3686ed79accef272dddea835bdf0ca5fd9564d46")
