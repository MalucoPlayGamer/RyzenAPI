-- Lua provided by RyzenAPI
-- Game: Driftmoon

-- MAIN APPLICATION
addappid(263380)

-- MAIN APP DEPOTS / PACKAGES
addappid(263382,0,"0bbe0fd0c6452876195eeea715ea7b9582c057de1ac3f02c51ace7bf58382adf")
addappid(263383,0,"ba23f4a50ce025b35cae9b9622650ace583d1ae089fd02067a0b2eca5bec83de")
addappid(263384,0,"8432c12f3fb112ac32502da271c6400d04f591d211c3cb178d849106310e4f6d")

