-- Lua provided by RyzenAPI
-- Game: Orb Flight

-- MAIN APPLICATION
addappid(2406540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406541, 1, "3cd841d0dc1bb59a18b47e7a849584f3486307e3c4fdb22de8a738fe7959d1a2")

