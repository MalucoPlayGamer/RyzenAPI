-- Lua provided by SkyAPI 
-- Game: LONER
addappid(1566490)
addappid(1566491, 1, "803b824637398e3bb84e6d1d254cb95edddf6f16a9a73d9e310f36245fdc246a")
