-- Lua provided by RyzenAPI
-- Game: 1566490

-- MAIN APPLICATION
addappid(1566490)
-- Game: addappid(1566490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566491, 1, "803b824637398e3bb84e6d1d254cb95edddf6f16a9a73d9e310f36245fdc246a")
