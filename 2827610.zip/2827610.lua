-- Lua provided by SkyAPI 
-- Game: RUMBLE BLAZING
addappid(2827610)
addappid(2827611, 1, "596b7c0a41b82b296d42a1f094c05d63ab0e2ffa3006b7a411de885af20264fa")
