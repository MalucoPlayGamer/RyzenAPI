-- Lua provided by RyzenAPI
-- Game: Dungeon Mori

-- MAIN APPLICATION
addappid(3597590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3597591, 1, "19a6bf4e7b45f2b0d8742b282e7da4d65fc05f447643894f333d978816d55130")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
