-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Mori

-- MAIN APPLICATION
addappid(3597590)
-- Game: addappid(3597590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3597591, 1, "19a6bf4e7b45f2b0d8742b282e7da4d65fc05f447643894f333d978816d55130")
