-- Lua provided by RyzenAPI
-- Game: Yield! Demo

-- MAIN APPLICATION
addappid(1645760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645761, 1, "7aa5a12b85e5a38f1bf66467b0f572ccf940c8e1f402ef1b411e51500cec4d8f")

