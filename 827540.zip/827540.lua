-- Lua provided by RyzenAPI
-- Game: A Penny For Some Motivation

-- MAIN APPLICATION
addappid(827540)
-- Game: addappid(827540)

-- MAIN APP DEPOTS / PACKAGES
addappid(827541, 1, "f5f3fafdaf15b4957eef594e34200dd8c06eafdd1e12c58e84a93ecb90eaf907")
