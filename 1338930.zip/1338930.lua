-- Lua provided by RyzenAPI
-- Game: Game: Invaliens

-- MAIN APPLICATION
addappid(1338930)
-- Game: addappid(1338930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338931, 1, "0f31e13929eb195c44dd889149080de96b558c94f08d5ba71a011b3fcc13e3d4")
