-- Lua provided by RyzenAPI
-- Game: Die Young: Prologue

-- MAIN APPLICATION
addappid(973000)

-- MAIN APP DEPOTS / PACKAGES
addappid(973001, 1, "f5495b32b8499214fa455fe081b48d0e19cde21b44c1e0eece88969af2df675c")

