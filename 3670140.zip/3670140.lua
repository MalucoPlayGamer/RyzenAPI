-- Lua provided by RyzenAPI
-- Game: Godzilla x Kong: Titan Chasers

-- MAIN APPLICATION
addappid(3670140)
