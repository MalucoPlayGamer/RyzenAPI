-- Lua provided by RyzenAPI
-- Game: Godzilla x Kong: Titan Chasers

-- MAIN APPLICATION
addappid(3670140)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4046390)
