-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade - Coteries of New York Artbook

-- MAIN APPLICATION
addappid(1266750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266750,0,"7f90f41425c1a23fe582bc6a0e9b6830bc0cbb35a9534d1fae20b24d9af7fb98")
