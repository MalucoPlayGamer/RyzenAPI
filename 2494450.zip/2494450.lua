-- Lua provided by RyzenAPI
-- Game: The Last Soldier of the Ming Dynasty

-- MAIN APPLICATION
addappid(2494450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494451, 1, "962d06317910f44ab5bd3017cbe4aa004b0a8428cf5ed17160a2d31d216a3446")

