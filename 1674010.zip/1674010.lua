-- Lua provided by RyzenAPI
-- Game: Nin Online

-- MAIN APPLICATION
addappid(1674010)

