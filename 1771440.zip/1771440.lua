-- Lua provided by RyzenAPI
-- Game: Bomb Club Deluxe

-- MAIN APPLICATION
addappid(1771440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771441, 1, "8b9925e49641963e88c851e566a207739b2663107f8bda92b451345ffaa5ebf9")
