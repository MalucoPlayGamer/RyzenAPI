-- Lua provided by RyzenAPI
-- Game: Beat Saber: Skrillex & Wolfgang Gartner – 'The Devil’s Den '

-- MAIN APPLICATION
addappid(1725507)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725507,0,"bfa53d88e0b72622811285b7f3afb302b77b0a0a430f023cec1d60d625546289")

