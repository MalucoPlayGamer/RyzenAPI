-- Lua provided by RyzenAPI
-- Game: Everlife

-- MAIN APPLICATION
addappid(1754480)
addappid(1923100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1754481, 1, "9e9d9b7febc24419262db5781236de720bc587b6ed00f42591eaecda33814a88")

