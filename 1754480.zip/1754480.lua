-- Lua provided by RyzenAPI
-- Game: Everlife

-- MAIN APPLICATION
addappid(1754480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754481, 1, "9e9d9b7febc24419262db5781236de720bc587b6ed00f42591eaecda33814a88")

