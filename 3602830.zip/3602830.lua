-- Lua provided by RyzenAPI
-- Game: AppID 3602830

-- MAIN APPLICATION
addappid(3602830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602831, 1, "f81ab81d3bf8d9737796cc2c1dc0fe4eefcbe4431eec170a704eb8bf334e2078")
addappid(3602832, 1, "35bae1b2b71659ddc5e16281fd3dfc56ca08839a4ee5a71d8cda60891d5206c0")

