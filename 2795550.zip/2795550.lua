-- Lua provided by RyzenAPI
-- Game: AppID 2795550

-- MAIN APPLICATION
addappid(2795550)
-- Game: addappid(2795550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795551, 1, "b5ae0cb6b10e023f0f94176b595a4e82e8f1f92608904cdc9d2a6e27a391ced3")
addappid(2795552, 1, "3444e96bf3933a354e20a7a02b801bc507e17eedfabfca8a32a5e0c256cc89ff")
