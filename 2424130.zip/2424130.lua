-- Lua provided by RyzenAPI
-- Game: Death Must Die Demo

-- MAIN APPLICATION
addappid(2424130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424131, 1, "ad9b8a701cfcf0aeb0a5f81392eaf01a611dfd8fa0c8730c48e268f3f081a454")

