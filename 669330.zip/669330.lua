-- Lua provided by RyzenAPI
-- Game: Mechabellum

-- MAIN APPLICATION
addappid(669330)
-- Game: addappid(669330)

-- MAIN APP DEPOTS / PACKAGES
addappid(669331, 1, "cce2dbb82d8bf772c353fd8b749df375dd3679858007e05fecc5f398c9a266e1")
