-- Lua provided by RyzenAPI
-- Game: 745870

-- MAIN APPLICATION
addappid(745870)
-- Game: addappid(745870)

-- MAIN APP DEPOTS / PACKAGES
addappid(745871, 1, "094435b515521e391cc713e84cbb3c997bb7e52a5265cd02c5a72a8e9520373c")
