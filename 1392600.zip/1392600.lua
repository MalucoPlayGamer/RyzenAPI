-- Lua provided by RyzenAPI
-- Game: Kazakh Drive

-- MAIN APPLICATION
addappid(1392600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392601, 1, "be1bc62ed384af5d2ad1aa2996149a82dcfd569dfefaf22591d74081ec5129f2")

