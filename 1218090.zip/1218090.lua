-- Lua provided by RyzenAPI
-- Game: HellScape: Two Brothers

-- MAIN APPLICATION
addappid(1218090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218091, 1, "25712eef857a56f29011d75b33128e6c17799792aa5165d777c0cc22cab81b44")

