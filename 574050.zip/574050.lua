-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST HEROES™ II

-- MAIN APPLICATION
addappid(574050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(574051, 1, "4e2fd2b97ee63fcd96779522fd16d7fcb953697fc366b317a0dedf0fb04e1fdc")
addappid(594400, 0, "2f3b81ae4e1299c2120199789a7bebe8ad320f0e56052891c67c7efd04b1ec49")

