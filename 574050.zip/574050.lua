-- Lua provided by SkyAPI 
-- Game: DRAGON QUEST HEROES™ II
addappid(574050)
addappid(574051, 1, "4e2fd2b97ee63fcd96779522fd16d7fcb953697fc366b317a0dedf0fb04e1fdc")
addappid(594400, 0, "2f3b81ae4e1299c2120199789a7bebe8ad320f0e56052891c67c7efd04b1ec49")
