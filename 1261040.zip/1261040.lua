-- Lua provided by SkyAPI 
-- Game: Streamer Life Simulator
addappid(1261040)
addappid(1261041, 1, "ee645de6bceda809083a62c4c8679274bdaab74bdd0eccb3eb94dcb4fa8822ae")
