-- Lua provided by RyzenAPI
-- Game: Game: Streamer Life Simulator

-- MAIN APPLICATION
addappid(1261040)
-- Game: addappid(1261040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261041, 1, "ee645de6bceda809083a62c4c8679274bdaab74bdd0eccb3eb94dcb4fa8822ae")
