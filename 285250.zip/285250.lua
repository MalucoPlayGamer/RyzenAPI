-- Lua provided by RyzenAPI
-- Game: Dear Leader Prototype

-- MAIN APPLICATION
addappid(285250)

-- MAIN APP DEPOTS / PACKAGES
addappid(285251, 1, "ea3278ad4f8cb9acc14e090d9867cda0592bb1fd2bc835e6bc065ae3d2435147")
