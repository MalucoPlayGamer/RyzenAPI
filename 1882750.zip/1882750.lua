-- Lua provided by SkyAPI 
-- Game: Cluck
addappid(1882750)
addappid(1882751, 1, "663f02d2700ae549df660f924b5b986ca5da2bb3c00671d4a8f7f8804d069b39")
