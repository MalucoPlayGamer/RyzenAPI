-- Lua provided by RyzenAPI
-- Game: Cluck

-- MAIN APPLICATION
addappid(1882750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882751, 1, "663f02d2700ae549df660f924b5b986ca5da2bb3c00671d4a8f7f8804d069b39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
