-- Lua provided by RyzenAPI
-- Game: Game: Cluck

-- MAIN APPLICATION
addappid(1882750)
-- Game: addappid(1882750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882751, 1, "663f02d2700ae549df660f924b5b986ca5da2bb3c00671d4a8f7f8804d069b39")
