-- 4114860's Lua and Manifest Created by Hubcap Manifest
-- SCP The Beginning
-- Created: August 27, 2026 at 10:28:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4114860) -- SCP The Beginning
-- MAIN APP DEPOTS
addappid(4114861, 1, "d7276341820b19f3e11e6792625826eb84152d11f7f955e7f77d8cb359db36b0") -- Depot 4114861
setManifestid(4114861, "4026223059142545529", 4623901090)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)