-- Lua provided by RyzenAPI
-- Game: Game: Crazy Designer

-- MAIN APPLICATION
addappid(2317570)
-- Game: addappid(2317570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317571, 1, "da0cca7eb40bbf48f081fb596c9526944df759e678aeffaaed73bc1e5d341b06")
addappid(2317574, 1, "b83b3646c31035bf2770749f90defbe5efef56d59957cd5bc34899bc352c3a15")
