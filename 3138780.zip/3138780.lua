-- Lua provided by RyzenAPI
-- Game: Do No Harm

-- MAIN APPLICATION
addappid(3138780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138781, 1, "877abb2ce4370120a9d52d84882d51e8277bf75cf3abaf324184e13ec1e07992")

