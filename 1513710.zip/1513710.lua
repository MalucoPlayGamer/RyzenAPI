-- Lua provided by RyzenAPI
-- Game: Crystal sword

-- MAIN APPLICATION
addappid(1513710)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(1513711, 1, "dc0ddcd8dd02775ca5c3b63f7513eaa1ed1084169c5c445a75e3d54f1532191b")

