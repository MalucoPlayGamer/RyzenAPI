-- Lua provided by RyzenAPI 
-- Game: Gunner-chan!
addappid(2516990)
addappid(2516991, 1, "baff002ac4304f922ae798202a60cfcb316e8fa86204e9d2c7ee1433ede4e940")
