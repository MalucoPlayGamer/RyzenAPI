-- Lua provided by RyzenAPI
-- Game: 1268530

-- MAIN APPLICATION
addappid(1268530)
-- Game: addappid(1268530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268531, 1, "b2a11e73ba61d8ebda43edd02789d8d9d262f468ceb854bf84301b9664a0bac0")
