-- Lua provided by RyzenAPI
-- Game: Shake Ground

-- MAIN APPLICATION
addappid(2003260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003261, 1, "fb406ca9258ee1c28997639b727a627842770c8a962caac7b83d0bd052ece670")

