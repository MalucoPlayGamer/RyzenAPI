-- Lua provided by RyzenAPI
-- Game: SOK

-- MAIN APPLICATION
addappid(765940)
-- Game: addappid(765940)

-- MAIN APP DEPOTS / PACKAGES
addappid(765942,0,"85dd41d2befc08234a6e59836d10030d9ba88b0f1c5059a1691e93e0f0e8ff89")
