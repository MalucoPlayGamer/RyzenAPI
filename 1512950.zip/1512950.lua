-- Lua provided by RyzenAPI
-- Game: Game: BullyBall

-- MAIN APPLICATION
addappid(1512950)
-- Game: addappid(1512950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512951, 1, "02ca5560c165376e3ef727d8ea88c2c132443ffc5d61ec4562f9307c7a1b7601")
