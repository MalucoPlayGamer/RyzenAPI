-- Lua provided by RyzenAPI
-- Game: Star Hunter DX

-- MAIN APPLICATION
addappid(1451030)
-- Game: addappid(1451030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451031, 1, "a2356aeda8ae0020b813c4e5218fb597f8f196c208981b1d76a3619a92910156")
