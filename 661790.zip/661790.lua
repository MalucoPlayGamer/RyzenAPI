-- Lua provided by RyzenAPI
-- Game: Witch Hunt

-- MAIN APPLICATION
addappid(661790)

-- MAIN APP DEPOTS / PACKAGES
addappid(661791, 1, "266ff7926750fa28fecf885c558ddb90d48d1334186691cae57876ff7810869a")
