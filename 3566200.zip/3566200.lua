-- Lua provided by RyzenAPI
-- Game: Pocket City 2

-- MAIN APPLICATION
addappid(3566200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3566201, 1, "332f26f2eacc0ef76e92b336197525ddab991262a8f23b5698dd882668199766")
