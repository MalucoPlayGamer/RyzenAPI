-- Lua provided by RyzenAPI
-- Game: Shave & Stuff

-- MAIN APPLICATION
addappid(2195400)
addappid(3412120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195401, 1, "4f6ea639ef2193920caab2436cc4f585c0f8770a8903d1a2e55b3a6ec5f31283")

