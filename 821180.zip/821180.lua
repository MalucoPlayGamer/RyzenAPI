-- Lua provided by RyzenAPI
-- Game: Reliefs The Time of the Lemures

-- MAIN APPLICATION
addappid(821180)

-- MAIN APP DEPOTS / PACKAGES
addappid(821181, 1, "49df17bc8363df8ffac75863a3314f33976e06ab922a324b4bd3768053008fb3")
