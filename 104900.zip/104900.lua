-- Lua provided by RyzenAPI
-- Game: addappid(104900)

-- MAIN APPLICATION
addappid(104900)
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229002)
addappid(538190)

-- MAIN APP DEPOTS / PACKAGES
addappid(104901, 1, "48074e4e138ef07652210152da60b6899863c39b3fe31652edb0d7f7a81b14a9")
