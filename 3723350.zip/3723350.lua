-- Lua provided by RyzenAPI
-- Game: 3723350

-- MAIN APPLICATION
addappid(3723350)
-- Game: addappid(3723350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723351, 1, "142915f8b8bdc4a0b5c37ba93e66d4c9b77cf0c4610457fd2c6cf1a5c652bfff")
