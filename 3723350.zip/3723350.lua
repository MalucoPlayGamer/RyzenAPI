-- Lua provided by SkyAPI 
-- Game: 在异世界打怪的修仙者
addappid(3723350)
addappid(3723351, 1, "142915f8b8bdc4a0b5c37ba93e66d4c9b77cf0c4610457fd2c6cf1a5c652bfff")
