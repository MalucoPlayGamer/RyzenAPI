-- Lua provided by RyzenAPI
-- Game: 2647820

-- MAIN APPLICATION
addappid(2647820)
-- Game: addappid(2647820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647821, 1, "412f58fb93d2a6fff4fb4bdf5ed0fea2d0acfe2a1df1db3eef0cebac72679521")
