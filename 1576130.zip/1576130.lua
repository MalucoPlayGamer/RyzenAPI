-- Lua provided by RyzenAPI
-- Game: Game: IdolDays

-- MAIN APPLICATION
addappid(1576130)
-- Game: addappid(1576130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576131, 1, "a66f4924cf5369eff548eb10add26908f511c839bd36aa45e9c2c3cefd0c1ac6")
