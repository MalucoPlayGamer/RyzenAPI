-- Lua provided by RyzenAPI 
-- Game: Knock & Run
addappid(2013130)
addappid(2013131, 1, "0c24ed85915e7e37b9fa55a1288b8499d8a13d15fe14387d88561a8cae12cb31")
