-- Lua provided by RyzenAPI
-- Game: Destruction  Paper

-- MAIN APPLICATION
addappid(890200)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006,0,"9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416")
addappid(229012,0,"421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12")

