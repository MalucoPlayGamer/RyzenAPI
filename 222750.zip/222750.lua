-- Lua provided by RyzenAPI
-- Game: Wargame: Airland Battle

-- MAIN APPLICATION
addappid(222750)
addappid(228984)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(222751, 1, "3f2d6f8c10456e4a0760478ca39d094bf2d9b294b60e2bdd4d0ab65c902b7627")
addappid(222752, 1, "508608471f16b894225e0bae998533ffec1736f05ac82d718b8f48e1a2075c95")
addappid(222753, 1, "499e2eec7ad6e72966d27c6286a0d9e35f4ebc41d14f60ecd4c72cf8f3d32283")
addappid(222754, 1, "f2334ad1793862ffd7e3f380c6371835c52eff0491ff225b0d6d1f79db3a6d35")
addappid(222755, 1, "bf18e09eeb551a8bf69cea51ac4f38444ac9871dd20aa40be4b87f937e3ea33c")
addappid(228991, 0, "9fbda43a3010f77add9f586ed10a46746c21f68c5342f66c0ffbb3553ddaade7")
addappid(228992, 0, "01941c999f7ac0827fe8b9b1019863d563240e74e635cd148512778640c34c2d")
addappid(245660, 0, "5adc26ad68fe66254f2bcda7153802c4c1d7d5d680af1f571598d3c97e1e1f3c")
addappid(260850, 0, "522ae065d330e11eaa180942d55caf2aa093d9d12e734ce998b65b42c9ba8e1d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(237720)
