-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2141201)
-- Game: addappid(2141201)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141201,0,"85f9444a30b270a6fe3c144808963cd218b908bfae039f309125486a9135544b")
