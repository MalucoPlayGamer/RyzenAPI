-- Lua provided by RyzenAPI
-- Game: Game: AppID 636360

-- MAIN APPLICATION
addappid(636360)
-- Game: addappid(636360)

-- MAIN APP DEPOTS / PACKAGES
addappid(636361, 1, "58874e7042f4b953b57da3e05533cb310ee78d981e0341eedb9818824771a272")
