-- Lua provided by RyzenAPI
-- Game: Game: Packed Train

-- MAIN APPLICATION
addappid(821400)
-- Game: addappid(821400)

-- MAIN APP DEPOTS / PACKAGES
addappid(821401, 1, "8f7f41c4c7eaf1990cd4cd2f6b76443cd4e3f4d566ae4e8ac39d0ae3e2cc7d44")
addappid(821402, 1, "5014f3b5770ad674cf6ed31bf4d231ca9a7b63a7deb4b7add58be748f969a3ac")
addappid(821403, 1, "85eb9703e8a2a06d67bc62465986c4e17f08717be82ad31fc05ea8838de5ce23")
