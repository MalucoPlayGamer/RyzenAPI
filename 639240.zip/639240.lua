-- Lua provided by RyzenAPI
-- Game: Game: AppID 639240

-- MAIN APPLICATION
addappid(639240)
-- Game: addappid(639240)

-- MAIN APP DEPOTS / PACKAGES
addappid(639241, 1, "75327ae0b695b1b2423a7777b2ceb141ddd8612d7fc946df9d6044566d7f24bf")
