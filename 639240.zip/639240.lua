-- Lua provided by SkyAPI 
-- Game: AppID 639240
addappid(639240)
addappid(639241, 1, "75327ae0b695b1b2423a7777b2ceb141ddd8612d7fc946df9d6044566d7f24bf")
