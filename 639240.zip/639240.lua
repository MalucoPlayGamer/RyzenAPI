-- Lua provided by RyzenAPI
-- Game: CodeRed: Agent Sarah's Story - Day One

-- MAIN APPLICATION
addappid(639240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(639241, 1, "75327ae0b695b1b2423a7777b2ceb141ddd8612d7fc946df9d6044566d7f24bf")

