-- Lua provided by RyzenAPI
-- Game: addappid(4384260)

-- MAIN APPLICATION
addappid(4384260)
addappid(4468000)

-- MAIN APP DEPOTS / PACKAGES
addappid(4384261, 1, "f383c9bfdcd6c28004ae945ad3a8f7b104a7bc6d9636f999d0c0e9afeddc589a")
