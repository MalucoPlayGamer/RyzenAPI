-- Lua provided by RyzenAPI
-- Game: My Neighbor's Lonely Wife 2

-- MAIN APPLICATION
addappid(2274980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274981, 1, "937caf7cd3251da9794abc0be8a72709a603aeec9e31a9c7e6c74895abe7bd5b")
addappid(2274982, 1, "c818f265cd59a57532204d4bd1a932b6cd8a2fbf75bc1539c8c4e2b6f5ed337c")
addappid(2274983, 1, "aa2c860bae4915798c453b5ce63d76dfee3bff5af5f0e2d94ee6bb1ff007071c")
addappid(2274984, 1, "b53be56e0c0cb3d37838ae477d2d9146aeea8bf257d45e34de763dcedd2f47a0")

