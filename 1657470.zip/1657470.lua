-- Lua provided by RyzenAPI
-- Game: Ship Graveyard Simulator Demo

-- MAIN APPLICATION
addappid(1657470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657471, 1, "8113b5abee558be3d316cfde556c2cd54470acf50535d0498d875c7a7b48c54b")

