-- Lua provided by SkyAPI 
-- Game: Ship Graveyard Simulator Demo
addappid(1657470)
addappid(1657471, 1, "8113b5abee558be3d316cfde556c2cd54470acf50535d0498d875c7a7b48c54b")
