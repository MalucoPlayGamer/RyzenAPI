-- Lua provided by SkyAPI 
-- Game: One-Liners
addappid(3593130)
addappid(3593131, 1, "72404842e2e3d7e9d9981879891fe670ff1d728add7f166f1b296a582cef4d57")
