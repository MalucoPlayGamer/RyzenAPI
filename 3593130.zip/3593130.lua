-- Lua provided by RyzenAPI
-- Game: One-Liners

-- MAIN APPLICATION
addappid(3593130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593131, 1, "72404842e2e3d7e9d9981879891fe670ff1d728add7f166f1b296a582cef4d57")

