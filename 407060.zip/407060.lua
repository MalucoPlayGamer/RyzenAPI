-- Lua provided by RyzenAPI
-- Game: AltspaceVR

-- MAIN APPLICATION
addappid(407060)

-- MAIN APP DEPOTS / PACKAGES
addappid(407061, 1, "3f8dc574e74dee1d194ed99bd6f25bbcd9d4b905c21f428100c9f64c9d255128")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
