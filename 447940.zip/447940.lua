-- Lua provided by SkyAPI 
-- Game: AppID 447940
addappid(447940)
addappid(447941, 1, "af935d4f3ef5b227ec05d4979b24f43c4c857374a2df9d477fa066c8d2ae7c14")
