-- Lua provided by RyzenAPI
-- Game: Chook & Sosig: Walk the Plank

-- MAIN APPLICATION
addappid(899470)

-- MAIN APP DEPOTS / PACKAGES
addappid(899471, 1, "f87a7456a1b55beb1a2740952304fbcf4c993b39a98054f2d008814181232c50")

