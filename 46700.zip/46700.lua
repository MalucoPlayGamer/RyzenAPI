-- Lua provided by RyzenAPI
-- Game: Ironclads: American Civil War

-- MAIN APPLICATION
addappid(46700)

-- MAIN APP DEPOTS / PACKAGES
addappid(46701, 1, "be30b0acb0d03b246bd1fbb490f34d711f8fb97bf4f5960d49eefa7d0994627b")
