-- Lua provided by RyzenAPI
-- Game: Game: AppID 296730

-- MAIN APPLICATION
addappid(296730)
-- Game: addappid(296730)

-- MAIN APP DEPOTS / PACKAGES
addappid(296731, 1, "c7e840458ae57de37deb604c0af90cb2a15a45a0a567111e10f66d5b234a43f4")
addappid(307650, 0, "6c3dbb4340c697d20ecfe1ab503af4159a997eebfe6291739015b5e5a669f7c6")
