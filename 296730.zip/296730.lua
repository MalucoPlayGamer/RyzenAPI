-- Lua provided by RyzenAPI
-- Game: AppID 296730

-- MAIN APPLICATION
addappid(296730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(296731, 1, "c7e840458ae57de37deb604c0af90cb2a15a45a0a567111e10f66d5b234a43f4")
addappid(307650, 0, "6c3dbb4340c697d20ecfe1ab503af4159a997eebfe6291739015b5e5a669f7c6")

