-- Lua provided by RyzenAPI
-- Game: OnlyCans: Thirst Date

-- MAIN APPLICATION
addappid(417360)

-- MAIN APP DEPOTS / PACKAGES
addappid(417361, 1, "e4a34ceebd0712faccfb99d4b0509f786d6712b27e2024cf577084dd0fed41a8")

