-- Lua provided by RyzenAPI
-- Game: Nero The Sniper Soundtrack

-- MAIN APPLICATION
addappid(1844070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844071, 1, "1d7688a4a4647b4f827f054228c874582a655c17c4ad84ab08b87eb9792d4990")

