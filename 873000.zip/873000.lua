-- Lua provided by RyzenAPI
-- Game: AppID 873000

-- MAIN APPLICATION
addappid(873000)
-- Game: addappid(873000)

-- MAIN APP DEPOTS / PACKAGES
addappid(873001, 1, "361d1990aec59a69b5bb8463e411098fb77d50286719cefc90669ec37356dbad")
