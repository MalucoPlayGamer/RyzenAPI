-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Zhenji "Race Queen Costume" / 甄姫「レースクイーン風コスチューム」

-- MAIN APPLICATION
addappid(1094187)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094187,0,"c78e83240d598f5fc5f3002fff6c3eb6925c9d86a3b5ea8dee85f5d52ba7f82b")

