-- Lua provided by RyzenAPI
-- Game: Trimurti Online

-- MAIN APPLICATION
addappid(2083800)
-- Game: addappid(2083800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083801, 1, "9858287e9efe25bfe62f8c2c505b5376b6f7618d6563ae8fb50ea94e1eeb3624")
