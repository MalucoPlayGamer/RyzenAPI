-- Lua provided by RyzenAPI
-- Game: Trimurti Online

-- MAIN APPLICATION
addappid(2083800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2083801, 1, "9858287e9efe25bfe62f8c2c505b5376b6f7618d6563ae8fb50ea94e1eeb3624")

