-- Lua provided by RyzenAPI
-- Game: AppID 774771

-- MAIN APPLICATION
addappid(774771)
-- Game: addappid(774771)

-- MAIN APP DEPOTS / PACKAGES
addappid(774772, 1, "99fb2c63703250600d0dc61e558585f8482e9c501dc10b6acdc8eba8abef2096")
