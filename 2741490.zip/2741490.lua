-- Lua provided by RyzenAPI
-- Game: At Tony's

-- MAIN APPLICATION
addappid(2741490)
-- Game: addappid(2741490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741491, 1, "e41191ddbfd9fba2074422ac5025eadb9063a67bb1ad6d8bf5d72905480ec3df")
