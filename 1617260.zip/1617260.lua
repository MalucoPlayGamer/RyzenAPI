-- Lua provided by RyzenAPI
-- Game: Bygone Dreams Original Soundtrack

-- MAIN APPLICATION
addappid(1617260)
-- Game: addappid(1617260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617261, 1, "04dbfd347304b738957161a3680d57da05243ecd7b784b13f1424cbdb4efdfdc")
addappid(1617262, 1, "36c265258a38b53fb91d8d24d96d038656086587a0085b6eb3e16a3956055420")
