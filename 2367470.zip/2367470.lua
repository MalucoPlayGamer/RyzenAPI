-- Lua provided by RyzenAPI
-- Game: Game: Jigsaw Puzzle World

-- MAIN APPLICATION
addappid(2367470)
-- Game: addappid(2367470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367471, 1, "78c417e3858bbf987bb32ee096b91df9c6b4eb974aa35ea562242b41798fe232")
