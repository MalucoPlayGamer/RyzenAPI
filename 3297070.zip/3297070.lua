-- Lua provided by RyzenAPI
-- Game: 3297070

-- MAIN APPLICATION
addappid(3297070)
-- Game: addappid(3297070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3297071, 1, "88959ac31071b55caef5b1fd5727aaa99d6af249cc266d28803774fecfb560da")
