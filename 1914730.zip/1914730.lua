-- Lua provided by RyzenAPI
-- Game: addappid(1914730)

-- MAIN APPLICATION
addappid(1914730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914732,0,"cd40f092692b8e1e3e8f42dff9ce965f64dadd0620f9b6c0c20079a4888569ef")
