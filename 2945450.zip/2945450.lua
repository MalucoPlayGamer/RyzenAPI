-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - SERIALGAMES Living Good City Tileset - Shrine and Temples SET

-- MAIN APPLICATION
addappid(2945450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945450,0,"427d5046a010b0fb14ed3e9bea87d93824510d5ca781aa8292424250cde714ae")

