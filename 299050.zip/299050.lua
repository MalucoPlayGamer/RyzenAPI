-- Lua provided by RyzenAPI
-- Game: Blood II: The Chosen + Expansion

-- MAIN APPLICATION
addappid(299050)
-- Game: addappid(299050)

-- MAIN APP DEPOTS / PACKAGES
addappid(299051, 1, "955a613ec3f1ac594c38e62983096752f30bc7a0d28dd13b7885a625be8e0905")
