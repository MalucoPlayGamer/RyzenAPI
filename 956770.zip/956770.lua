-- Lua provided by RyzenAPI
-- Game: addappid(956770)

-- MAIN APPLICATION
addappid(956770)

-- MAIN APP DEPOTS / PACKAGES
addappid(956770,0,"0519a532a24bb13252554db6c7064719ff1c05f46e0b6c2fad29d59c73ea72f6")
