-- Lua provided by RyzenAPI
-- Game: AppID 389430

-- MAIN APPLICATION
addappid(389430)
-- Game: addappid(389430)

-- MAIN APP DEPOTS / PACKAGES
addappid(389431, 1, "45c96106d80d3b981b64b86862a4fe039fc14ffe4bfcb07f074b688b75bfc347")
