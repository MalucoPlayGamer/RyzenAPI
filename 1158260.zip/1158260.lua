-- Lua provided by RyzenAPI
-- Game: Game: AppID 1158260

-- MAIN APPLICATION
addappid(1158260)
-- Game: addappid(1158260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158261, 1, "dd873d3860458596ea22c5189d52b28b6a25093db68f197d7399eafaf170123a")
