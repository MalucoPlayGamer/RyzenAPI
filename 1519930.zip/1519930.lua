-- Lua provided by RyzenAPI
-- Game: AppID 1519930

-- MAIN APPLICATION
addappid(1519930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519931, 1, "e5fc83e2a561bc7477812fc6aacf8c8c5941372a7b89cfbb3aa86f57fd7d5799")
