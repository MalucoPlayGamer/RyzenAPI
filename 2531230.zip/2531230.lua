-- Lua provided by SkyAPI 
-- Game: Whispering Shadows
addappid(2531230)
addappid(2531231, 1, "55b3b123817b71587e1cb040604f06a1954fd7a06fcbd6a73315758f9fc3dee0")
