-- Lua provided by RyzenAPI
-- Game: Game: Whispering Shadows

-- MAIN APPLICATION
addappid(2531230)
-- Game: addappid(2531230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531231, 1, "55b3b123817b71587e1cb040604f06a1954fd7a06fcbd6a73315758f9fc3dee0")
