-- Lua provided by RyzenAPI
-- Game: Vampire Prison

-- MAIN APPLICATION
addappid(3583660)
-- Game: addappid(3583660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3583661, 1, "2fb36c121c909ba66bfeb128e774cc62f5419dfd0fdccde1ca110b008808a303")
