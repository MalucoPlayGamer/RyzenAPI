-- Lua provided by RyzenAPI
-- Game: Game: Illegal Mahjong

-- MAIN APPLICATION
addappid(2607320)
addappid(2725740)
-- Game: addappid(2607320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607321, 1, "5ab7ebcce380c0dca8786e58b131d4e2ab9f3f002720bb3dfb658b521264fe79")
addappid(2607322, 1, "947ba60d987487084719d44c985763733c52e64cfd78c09b7893c68bbc24255b")
addappid(2607323, 1, "fdea470a6d750a74bd1eb87bdc92b197435cdd6c3360fadc232284d89566df6b")
addappid(2607324, 1, "57b482a362983a994032afe742efec20519c85400544f0afb504919ee38a72cc")
