-- Lua provided by RyzenAPI
-- Game: PlanetSide Arena

-- MAIN APPLICATION
addappid(987350)
addappid(994420)
addappid(994430)
addappid(996700)
addappid(1155050)
addappid(1155070)

-- MAIN APP DEPOTS / PACKAGES
addappid(987351,0,"fddd9bb5b74296ac2356dd6be3857d9bb7f101c2c86841f74811b00a1520f561")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
