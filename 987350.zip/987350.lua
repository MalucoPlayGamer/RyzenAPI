-- Lua provided by RyzenAPI
-- Game: PlanetSide Arena

-- MAIN APPLICATION
addappid(987350)
addappid(994420)
addappid(994430)
addappid(996700)
addappid(1155050)
addappid(1155070)

-- MAIN APP DEPOTS / PACKAGES
addappid(987351,0,"fddd9bb5b74296ac2356dd6be3857d9bb7f101c2c86841f74811b00a1520f561")

