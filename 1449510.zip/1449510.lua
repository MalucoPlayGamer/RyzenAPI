-- Lua provided by RyzenAPI
-- Game: addappid(1449510)

-- MAIN APPLICATION
addappid(1449510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449511, 1, "e6b07555fa59d6cfb756cda0513f545ed40c139358d0cb3acb12013f4e216e26")
