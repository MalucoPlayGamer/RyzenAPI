-- Lua provided by RyzenAPI
-- Game: Game: DREAM LOGIC

-- MAIN APPLICATION
addappid(2110510)
-- Game: addappid(2110510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110511, 1, "0478fd19d89cdb28174ef7c01793314982cdce4be034607c02a043e46ff4bd74")
