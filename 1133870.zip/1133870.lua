-- Lua provided by RyzenAPI
-- Game: Space Engineers 2

-- MAIN APPLICATION
addappid(1133870)
addappid(3365540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1133871, 1, "0d760afa5af25326869f34c4e246af9e2f3b4cf30464ad8587e36b5c5a6ae44e")
