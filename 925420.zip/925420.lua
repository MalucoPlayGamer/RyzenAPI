-- Lua provided by RyzenAPI
-- Game: AppID 925420

-- MAIN APPLICATION
addappid(925420)
-- Game: addappid(925420)

-- MAIN APP DEPOTS / PACKAGES
addappid(925421, 1, "a1d1b93c4791503c866e2870a067c61e897d49fdcb50a7b6fe978d6263a57336")
