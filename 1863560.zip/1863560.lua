-- Lua provided by RyzenAPI
-- Game: η κλοπή του ΚΡΑΣΙΟΥ

-- MAIN APPLICATION
addappid(1863560)
-- Game: addappid(1863560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863562,0,"4c8197bc06d5a752732f23660a5cc7c6f2254250a82296d490505c194c496dbc")
addappid(1863563,0,"80c35b08b813e860158e1e74823fbbdcb17a760e1088ed8bd919135a28e56939")
