-- Lua provided by RyzenAPI
-- Game: Fellowship Playtest

-- MAIN APPLICATION
addappid(3165720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165721, 1, "55538fe917d9c48eef4968835c260e359554768fb2254bda024faed896939dbb")

