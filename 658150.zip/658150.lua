-- Lua provided by RyzenAPI
-- Game: Game: Skeleton Boomerang

-- MAIN APPLICATION
addappid(658150)
addappid(1456460)
-- Game: addappid(658150)

-- MAIN APP DEPOTS / PACKAGES
addappid(658151, 1, "d539296e200ee027c90a07c6ede4d63942d69a29ef178177932ca103bd75fad1")
