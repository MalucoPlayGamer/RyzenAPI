-- Lua provided by RyzenAPI
-- Game: addappid(3457790)

-- MAIN APPLICATION
addappid(3457790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3457791, 1, "7b76ca373d2ea79ee28634ad1d121d4c1617cd5f026acd40f3683ac4ed2665ea")
