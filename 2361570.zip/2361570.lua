-- Lua provided by RyzenAPI
-- Game: Cronous

-- MAIN APPLICATION
addappid(2361570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361571, 1, "c25107d7ce352eda642ac10d87b160f8316fbc3e454d3906e56133e408396e8d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
