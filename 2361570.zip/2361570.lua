-- Lua provided by SkyAPI 
-- Game: Cronous
addappid(2361570)
addappid(2361571, 1, "c25107d7ce352eda642ac10d87b160f8316fbc3e454d3906e56133e408396e8d")
