-- Lua provided by RyzenAPI
-- Game: - Mischief Dungeon Life - 異世界転生した俺のイタズラダンジョンライフ　AshaEdition

-- MAIN APPLICATION
addappid(2184400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184401, 1, "9638e1276548e1c9870454a003a6964a49c2fd53d82944504bfb9cec86829262")

