-- Lua provided by RyzenAPI
-- Game: AppID 2235250

-- MAIN APPLICATION
addappid(2235250)
-- Game: addappid(2235250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235251, 1, "07e19bf6b8bd4ec876ad7695513991f45d4f086b007e8c8bc363afdeeedf5b6a")
