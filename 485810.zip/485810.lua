-- Lua provided by RyzenAPI
-- Game: 485810

-- MAIN APPLICATION
addappid(485810)
-- Game: addappid(485810)

-- MAIN APP DEPOTS / PACKAGES
addappid(485810,0,"5dc259439f7d42676951873627cffb6879b1b1485f01b9ae66bd9e9c992289bf")
