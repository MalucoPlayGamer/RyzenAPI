-- Lua provided by RyzenAPI
-- Game: Anger Foot

-- MAIN APPLICATION
addappid(1978590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978591, 1, "97fd1a955a81c6d401ffd49816ff8ffa4ab5147e00f909d06d946cfdd6204f1d")

