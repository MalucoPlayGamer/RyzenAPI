-- Lua provided by RyzenAPI
-- Game: 2767160

-- MAIN APPLICATION
addappid(2767160)
-- Game: addappid(2767160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767161, 1, "162266d6ce9f0c716128ee910261532fe30a2ab1565a7bc1b4831a5877be13ee")
