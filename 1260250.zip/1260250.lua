-- Lua provided by RyzenAPI
-- Game: SECTOR 40: The Soviet Legacy

-- MAIN APPLICATION
addappid(1260250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1260251, 1, "241a161139f068c2487e7ab4a0e8f2faf28d3c3e194dc75547012c7f9f4f7d57")

