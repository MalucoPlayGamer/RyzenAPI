-- Lua provided by RyzenAPI
-- Game: Game: AppID 1260250

-- MAIN APPLICATION
addappid(1260250)
-- Game: addappid(1260250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260251, 1, "241a161139f068c2487e7ab4a0e8f2faf28d3c3e194dc75547012c7f9f4f7d57")
