-- Lua provided by RyzenAPI
-- Game: Dangerous Waters

-- MAIN APPLICATION
addappid(1600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601, 1, "3366df0426c75f708428a6fa77286625a9943f5eb8ad74c8d55634d3be1e06c6")
