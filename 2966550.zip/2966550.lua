-- Lua provided by RyzenAPI
-- Game: Game: SpreadCheat

-- MAIN APPLICATION
addappid(2966550)
-- Game: addappid(2966550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966551, 1, "706fa5a4d9316190b781c59062f2e3718083772f75362bc8999feca1fdb1c2cb")
