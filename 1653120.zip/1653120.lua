-- Lua provided by RyzenAPI
-- Game: Game: 通天魔塔-MagicTower

-- MAIN APPLICATION
addappid(1653120)
-- Game: addappid(1653120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653121, 1, "0f3d9daa36e772ef5bed44554a761671205416f539e8eab46ef1d061cc68bfe2")
