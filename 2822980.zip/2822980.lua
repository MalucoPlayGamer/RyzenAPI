-- Lua provided by RyzenAPI
-- Game: ARSONATE

-- MAIN APPLICATION
addappid(2822980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2822981,0,"bf5fcc89866cb0dfd74367b785755e40f5b0bd488cdc7148b19a8f5e7d42bce6")

