-- Lua provided by RyzenAPI
-- Game: I Am The Prosecutor: No Evidence? No Problem!

-- MAIN APPLICATION
addappid(1591470)
-- Game: addappid(1591470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591471, 1, "dd667843343b957f0fcbac93917fe5b8a03664c3165187e67402fbc5f563e521")
