-- Lua provided by RyzenAPI
-- Game: Game: Stealth

-- MAIN APPLICATION
addappid(2168090)
-- Game: addappid(2168090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168091, 1, "68716b91e8c2fdb4d5f967d6d3fd4b76f6e58f5e4933f8bbe4f1fd1b935df9ee")
