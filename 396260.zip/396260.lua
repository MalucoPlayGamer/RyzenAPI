-- Lua provided by RyzenAPI
-- Game: AppID 396260

-- MAIN APPLICATION
addappid(396260)
-- Game: addappid(396260)

-- MAIN APP DEPOTS / PACKAGES
addappid(396261, 1, "da76d2dbce0dabb3da39d4d12ea7aa26b18c8b015334df13c9c3d028f1b4fd8c")
