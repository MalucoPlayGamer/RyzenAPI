-- Lua provided by RyzenAPI
-- Game: Battlerace Demo

-- MAIN APPLICATION
addappid(2251520)
-- Game: addappid(2251520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251521, 1, "248a6856fb80cd87c0dab43d3d96c7e24ca3ddb71b9f67412a530169ec941f60")
