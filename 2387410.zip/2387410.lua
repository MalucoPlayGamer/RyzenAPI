-- Lua provided by RyzenAPI
-- Game: Aleph

-- MAIN APPLICATION
addappid(2387410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387411, 1, "eb17d92fd9cd03965e37ed82202364d1eb4a04d7d099ef3d2bd7346464951f02")

