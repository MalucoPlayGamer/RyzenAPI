-- Lua provided by RyzenAPI 
-- Game: Aleph
addappid(2387410)
addappid(2387411, 1, "eb17d92fd9cd03965e37ed82202364d1eb4a04d7d099ef3d2bd7346464951f02")
