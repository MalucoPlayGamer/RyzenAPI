-- Lua provided by RyzenAPI 
-- Game: AppID 1031140
addappid(1031140)
addappid(1031141, 1, "8d89873705504eddc8005dbbd2be1b80b924c00facc0b22b50d9d6806322e4e1")
addappid(1031142, 1, "6ac3ef89142913d63db869672977bdbb9179e227f1562668104fdcbc3a521b43")
