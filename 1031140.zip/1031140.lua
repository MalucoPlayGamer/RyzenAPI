-- Lua provided by RyzenAPI
-- Game: Warhammer Horus Heresy: Legions

-- MAIN APPLICATION
addappid(1321580) -- Horus Heresy Legions - Starter bundle
addappid(1985190) -- Horus Heresy Legions - Expansion bundle
addappid(2436700) -- Warhammer Horus Heresy Legions - World Eaters Skulls bundle
addappid(2961910) -- Warhammer Horus Heresy Legions - Space Wolves bundle
addappid(3697830) -- Warhammer Horus Heresy Legions - Shattered Legions bundle

-- MAIN APP DEPOTS / PACKAGES
addappid(1031140, 1, "49a88bc3f774e46c144afe3c7b8d022bdd918902ccc987840259a68bf0e90617") -- Warhammer Horus Heresy: Legions
addappid(1031141, 1, "8d89873705504eddc8005dbbd2be1b80b924c00facc0b22b50d9d6806322e4e1") -- The Horus Heresy: Legions Content
addappid(1031142, 1, "6ac3ef89142913d63db869672977bdbb9179e227f1562668104fdcbc3a521b43") -- The Horus Heresy: Legions Mac

