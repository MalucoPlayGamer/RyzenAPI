-- Lua provided by RyzenAPI
-- Game: AppID 1071130

-- MAIN APPLICATION
addappid(1071130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071131, 1, "a914fbb852ac9ad17a6936c8b3bf2c068aae9fb9a3352d20ecae59d53eae9367")
