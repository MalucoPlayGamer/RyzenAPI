-- Lua provided by RyzenAPI
-- Game: METAL GEAR SOLID: Peace Walker - Master Collection Version

-- MAIN APPLICATION
addappid(2492660) -- METAL GEAR SOLID: Peace Walker - Master Collection Version
addappid(4864690)
-- addappid(3617210) -- Depot 3617210 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2492661, 1, "51ef63054c63f673fbbca785ad1e04651bbff2630f95fff817df726a10a85499") -- Depot 2492661

