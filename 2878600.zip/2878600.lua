-- Lua provided by RyzenAPI
-- Game: Game: Harry Potter: Quidditch Champions

-- MAIN APPLICATION
addappid(2878600)
addappid(3105320)
-- Game: addappid(2878600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878601, 1, "1f592e4f58b2197dbdc21348883475d72796385505b5ee13ae0e5cd7fc4142a4")
