-- Lua provided by RyzenAPI
-- Game: Harry Potter: Quidditch Champions

-- MAIN APPLICATION
addappid(2878600)
addappid(3105320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878601, 1, "1f592e4f58b2197dbdc21348883475d72796385505b5ee13ae0e5cd7fc4142a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2922880)
