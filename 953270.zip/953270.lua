-- Lua provided by RyzenAPI
-- Game: Game: Dominatrix Simulator: Threshold

-- MAIN APPLICATION
addappid(953270)
-- Game: addappid(953270)

-- MAIN APP DEPOTS / PACKAGES
addappid(953271, 1, "ec29e3f325783c2846416bde359e2c9b6e9736c1249fab7434d6a4c7e48cf5a4")
