-- Lua provided by RyzenAPI
-- Game: Arcana Heart 3 LOVE MAX!!!!!

-- MAIN APPLICATION
addappid(370460)

-- MAIN APP DEPOTS / PACKAGES
addappid(370461, 1, "eed057e333b06d9dc3446456c87aa2a70073123207d6cb85832338c580531803")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
