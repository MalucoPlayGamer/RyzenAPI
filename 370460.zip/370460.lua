-- Lua provided by RyzenAPI
-- Game: Arcana Heart 3 LOVE MAX!!!!!

-- MAIN APPLICATION
addappid(370460)
-- Game: addappid(370460)

-- MAIN APP DEPOTS / PACKAGES
addappid(370461, 1, "eed057e333b06d9dc3446456c87aa2a70073123207d6cb85832338c580531803")
