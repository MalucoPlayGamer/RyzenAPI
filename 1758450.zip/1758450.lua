-- Lua provided by RyzenAPI
-- Game: 狂神无双

-- MAIN APPLICATION
addappid(1758450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758451, 1, "fb2762885113d81790d32423b2477fadcd982cf2a1e36856001bf99875ffe6d7")

