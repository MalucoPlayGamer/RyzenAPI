-- Lua provided by RyzenAPI
-- Game: 3089150

-- MAIN APPLICATION
addappid(3089150)
-- Game: addappid(3089150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089151, 1, "a88a5dd8a76100cfb50fd8e403abd25298872362850f49e1e3b05e070179d2db")
