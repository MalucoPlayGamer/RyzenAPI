-- Lua provided by RyzenAPI
-- Game: 882250

-- MAIN APPLICATION
addappid(882250)
-- Game: addappid(882250)

-- MAIN APP DEPOTS / PACKAGES
addappid(882251, 1, "b4dc0b25c145cdeef78cb8784dab38313013a666898cb30a20109b6295e26943")
