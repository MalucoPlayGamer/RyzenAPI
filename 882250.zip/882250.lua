-- Lua provided by RyzenAPI
-- Game: Metro Sim Hustle

-- MAIN APPLICATION
addappid(882250)
addappid(1658730)

-- MAIN APP DEPOTS / PACKAGES
addappid(882251,0,"b4dc0b25c145cdeef78cb8784dab38313013a666898cb30a20109b6295e26943")

