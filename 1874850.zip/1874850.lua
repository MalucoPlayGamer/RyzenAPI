-- Lua provided by RyzenAPI
-- Game: Neko Maid 18+ Adult Only Content

-- MAIN APPLICATION
addappid(1874850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874850,0,"1b9cf3cce137690baadc1fffde8c74985297d1a81d8d1ca465d1863a52cd2d2c")

