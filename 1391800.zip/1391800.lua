-- Lua provided by RyzenAPI
-- Game: addappid(1391800)

-- MAIN APPLICATION
addappid(1391800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391801, 1, "9acd6c921e8a19e6c791e20a71b89646005164cdcdcac04c31cb09cc159809f9")
