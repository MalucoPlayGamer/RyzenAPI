-- Lua provided by RyzenAPI
-- Game: addappid(3192920)

-- MAIN APPLICATION
addappid(3192920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192921, 1, "815f4ba60ffb98837474e9eeb0227dfd08be7cfa6d866b8954f43bebd1087a85")
