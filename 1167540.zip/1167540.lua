-- Lua provided by SkyAPI 
-- Game: KiKi's adventure
addappid(1167540)
addappid(1167541, 1, "69dd9280d091c2a9f7e81e3bb5c5da8be8dbd00d85567e658db5ad3f03506d2e")
