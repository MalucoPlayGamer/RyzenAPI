-- Lua provided by RyzenAPI
-- Game: Hikari! Love Potion

-- MAIN APPLICATION
addappid(1132710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132711, 1, "e758828a19a0447b80498371b110e88cc5f4acb7bf6b1e1a83f903982110d564")

