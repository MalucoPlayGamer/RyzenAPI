-- Lua provided by RyzenAPI
-- Game: Snowsquall Grip

-- MAIN APPLICATION
addappid(3000420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000421, 1, "08894e4d4960f707a5ef380736aa125ea44793b2ddaf3f83a98fb2b9f09da9e0")

