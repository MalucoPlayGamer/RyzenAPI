-- Lua provided by RyzenAPI 
-- Game: Snowsquall Grip
addappid(3000420)
addappid(3000421, 1, "08894e4d4960f707a5ef380736aa125ea44793b2ddaf3f83a98fb2b9f09da9e0")
