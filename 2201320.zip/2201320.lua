-- Lua provided by RyzenAPI
-- Game: Date Everything!

-- MAIN APPLICATION
addappid(2201320)
addappid(3043460)
addappid(3043470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201321, 1, "173bd7627cf18657ea58531a712c028386d6385bfe84eb20b756333989d603d3")
