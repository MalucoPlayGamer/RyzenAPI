-- Lua provided by RyzenAPI
-- Game: DARQ: Complete Edition

-- MAIN APPLICATION
addappid(433550)
addappid(1210400)

-- MAIN APP DEPOTS / PACKAGES
addappid(433551, 1, "5def0aeaea3e687e72fabacdea718f0ce106fdfc550737c45d6f97290f206f65")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1337690)
