-- Lua provided by RyzenAPI
-- Game: AppID 1951960

-- MAIN APPLICATION
addappid(1951960)
-- Game: addappid(1951960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951961, 1, "7ef0f4b4aefc72ea6baa78c36d373c49d32b90c666c55380d5563d6a785bfd8a")
