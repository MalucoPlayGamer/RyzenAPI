-- Lua provided by RyzenAPI
-- Game: 1341310

-- MAIN APPLICATION
addappid(1341310)
-- Game: addappid(1341310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341311, 1, "099d0e90df44cd95ad3ca3c5c9170cd3dbe70bc52e89619364f36658966252fe")
