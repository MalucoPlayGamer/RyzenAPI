-- Lua provided by RyzenAPI
-- Game: Abandoned Souls

-- MAIN APPLICATION
addappid(2412490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412491, 1, "27fb028bcda032d627cce43aa6ca1903efc68a73df892a5338e5ab984b0d76ed")

