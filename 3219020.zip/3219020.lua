-- Lua provided by RyzenAPI
-- Game: Proverbs Demo

-- MAIN APPLICATION
addappid(3219020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219021, 1, "4999c4b401cb67bd9a81b1d802e74836b9db0aeed0691fb72e347d4cc884c8ce")
