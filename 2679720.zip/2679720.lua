-- Lua provided by RyzenAPI
-- Game: Game: AppID 2679720

-- MAIN APPLICATION
addappid(2679720)
-- Game: addappid(2679720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679721, 1, "8db06c4b4932755c7e45f3f490bbfa971cab593bb33aac926f7287c5c4d00fe1")
