-- Lua provided by RyzenAPI 
-- Game: forma.8
addappid(510240)
addappid(510241, 1, "5f44869a8f51c761080e8c62b6027f2deef07a689e3c967daeb34174795cfdc7")
