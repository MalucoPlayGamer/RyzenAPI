-- Lua provided by RyzenAPI
-- Game: forma.8

-- MAIN APPLICATION
addappid(510240)

-- MAIN APP DEPOTS / PACKAGES
addappid(510241, 1, "5f44869a8f51c761080e8c62b6027f2deef07a689e3c967daeb34174795cfdc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
