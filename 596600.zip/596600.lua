-- Lua provided by RyzenAPI
-- Game: 596600

-- MAIN APPLICATION
addappid(596600)
-- Game: addappid(596600)

-- MAIN APP DEPOTS / PACKAGES
addappid(596601, 1, "cf9e37a63df2e10f0990fedee7e5338d7f60e3252fe67629c4a29aaac033d2bc")
