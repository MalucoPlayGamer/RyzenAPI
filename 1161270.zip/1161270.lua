-- Lua provided by RyzenAPI
-- Game: addappid(1161270)

-- MAIN APPLICATION
addappid(1161270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161271, 1, "1705cce231ed3f958f39b694b7f2d1070432d13a8f261c31e7e550f6f0f96b63")
