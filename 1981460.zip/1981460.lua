-- Lua provided by RyzenAPI
-- Game: 无名者 Demo

-- MAIN APPLICATION
addappid(1981460)
-- Game: addappid(1981460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981461, 1, "317060bca173615c97d693fed043487238314ffd4700ed3dcb3929823bf1384c")
