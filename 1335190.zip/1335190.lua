-- Lua provided by RyzenAPI
-- Game: Tales of the Neon Sea - Original Soundtrack

-- MAIN APPLICATION
addappid(1335190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335192,0,"b1926cf83f58a06c39d31e7e268106638020b21d7698666940895006ab01575d")

