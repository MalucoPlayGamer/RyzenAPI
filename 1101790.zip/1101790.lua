-- Lua provided by RyzenAPI 
-- Game: War Mongrels
addappid(1101790)
addappid(1101791, 1, "f8d3b044372d8c3690c4e3f4babfea50a6efaa479b80a12a8ab1bbcca8d6a2b5")
addappid(1101792, 1, "ab0572947aa0c19d4580eb509977944dfa75e198e12a5bea25676becf8f8fb34")
