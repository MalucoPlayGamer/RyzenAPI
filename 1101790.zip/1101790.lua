-- Lua provided by RyzenAPI
-- Game: War Mongrels

-- MAIN APPLICATION
addappid(1101790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1101791, 1, "f8d3b044372d8c3690c4e3f4babfea50a6efaa479b80a12a8ab1bbcca8d6a2b5")
addappid(1101792, 1, "ab0572947aa0c19d4580eb509977944dfa75e198e12a5bea25676becf8f8fb34")

