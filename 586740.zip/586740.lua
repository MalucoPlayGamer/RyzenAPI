-- Lua provided by RyzenAPI
-- Game: Spirits of Mystery: Song of the Phoenix Collector's Edition

-- MAIN APPLICATION
addappid(586740)

-- MAIN APP DEPOTS / PACKAGES
addappid(586741,0,"16249d7490cd081a65f66cdd3531e6bb7fd350040e190f9fc65e410b16814a8e")

