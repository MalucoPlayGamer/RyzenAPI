-- Lua provided by RyzenAPI
-- Game: addappid(3166780)

-- MAIN APPLICATION
addappid(3166780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166781, 1, "c9001bde7debeb7512146b313167fce6ecaee4485d2a26fcc8ffcf5e2e9c3243")
