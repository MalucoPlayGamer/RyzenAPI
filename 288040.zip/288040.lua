-- Lua provided by RyzenAPI
-- Game: Actual Sunlight

-- MAIN APPLICATION
addappid(228982)
addappid(288040)
addappid(288041)
-- Game: addappid(288040)

-- MAIN APP DEPOTS / PACKAGES
addappid(288042,0,"272c62975c782f715a3fdf6266810eb2d893d90534e3140c17bf76c59e507611")
addappid(288043,0,"7b001e35d072ac623d4601627348ea33642662230d3cead8a54d0d1d854b443d")
