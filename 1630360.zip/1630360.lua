-- Lua provided by RyzenAPI
-- Game: addappid(1630360)

-- MAIN APPLICATION
addappid(1630360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630361, 1, "a77da08e6a17922a6419b31a6063035b33ced32a4a033e1ca3c28d0b38df3a0c")
