-- Lua provided by RyzenAPI
-- Game: Friday the 13th: Killer Puzzle

-- MAIN APPLICATION
addappid(795100)
addappid(807450) -- DLC 807450
addappid(807460) -- DLC 807460
addappid(807470) -- DLC 807470
addappid(807480) -- DLC 807480
addappid(807490) -- Friday the 13th: Killer Puzzle - Episode 6: Slayground
addappid(807500) -- DLC 807500
addappid(807510) -- Friday the 13th: Killer Puzzle - Episode 8: Future Shock
addappid(807520) -- Friday the 13th: Killer Puzzle - Episode 9: Return to Crystal Lake
addappid(807530) -- DLC 807530
addappid(807540) -- Friday the 13th: Killer Puzzle - Episode 11: Knightmare
addappid(807560) -- Friday the 13th: Killer Puzzle - Episode 12: Jurassic Jason
addappid(807620) -- Friday the 13th: Killer Puzzle - Retro Jason
addappid(807630) -- DLC 807630
addappid(807640) -- DLC 807640
addappid(808400) -- DLC 808400
addappid(808410) -- DLC 808410
addappid(808430) -- Friday the 13th: Killer Puzzle - Part 3 Jason
addappid(808440) -- DLC 808440

-- MAIN APP DEPOTS / PACKAGES
addappid(795101, 1, "adee86e7c8b3991dab5bc54f1bf5545a32a0ca89799ab96a12883dfb6755236c") -- (windows, 64-bit)
addappid(795102, 1, "2751bfbfaf93c7a1a1d0fc2b5bcb4cad2e78b9c7207cc7802e500bd98117e558") -- (macos)
addappid(795103, 1, "4ed1a7a806d8a75e12fedac99f6339363d6962f3f74c197f14a311ef7a241098") -- (windows, 32-bit)

