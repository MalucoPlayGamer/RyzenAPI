-- Lua provided by RyzenAPI
-- Game: Game: Pizza Hero

-- MAIN APPLICATION
addappid(2202770)
addappid(3763570)
-- Game: addappid(2202770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202771, 1, "2f15a59ba4a6bb8129f26d0b2fb954b0478582a7ab0fb73c286e148669383812")
