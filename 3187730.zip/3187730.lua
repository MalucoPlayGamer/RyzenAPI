-- Lua provided by SkyAPI 
-- Game: Clicker Clicker Clicker
addappid(3187730)
addappid(3187731, 1, "c6a0e52965ac975ca9da53fee354828a0f10f85b3f2b39ac1ad6177f8848c8d4")
addappid(3187732, 1, "8b0e47c494f1d1d0e744d7d501b2c1962a6526e9c34e739ce8d6dec469426a7d")
addappid(3274550)
