-- Lua provided by RyzenAPI
-- Game: addappid(70900)

-- MAIN APPLICATION
addappid(70900)
addappid(228983)
addappid(229020)

-- MAIN APP DEPOTS / PACKAGES
addappid(70901, 1, "b03bd196fd7df2a207a5b2a906c365cfb1e179c75e5fe887ca4c93b0e4d1423c")
