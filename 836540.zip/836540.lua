-- Lua provided by RyzenAPI
-- Game: Game: AppID 836540

-- MAIN APPLICATION
addappid(836540)
-- Game: addappid(836540)

-- MAIN APP DEPOTS / PACKAGES
addappid(836541, 1, "08d5a341fc7a448c35edafa4a79ea3051b1ebc95ade482928640fb650ae7238c")
