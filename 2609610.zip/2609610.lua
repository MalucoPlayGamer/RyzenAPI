-- Lua provided by RyzenAPI
-- Game: Game: CONVRGENCE

-- MAIN APPLICATION
addappid(2609610)
-- Game: addappid(2609610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609611, 1, "16946e2092c51648d3424fff2d873a1278386e7050edbb4ef7ab8dc071394faa")
