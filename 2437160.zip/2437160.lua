-- Lua provided by RyzenAPI
-- Game: Game: Taste of victory

-- MAIN APPLICATION
addappid(2437160)
-- Game: addappid(2437160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437161, 1, "b4f029171b9dee20db11a2dd83d4464f4aafa936b9cbbb27344b4d4452db7738")
