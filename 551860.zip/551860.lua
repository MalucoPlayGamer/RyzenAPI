-- Lua provided by RyzenAPI
-- Game: AppID 551860

-- MAIN APPLICATION
addappid(551860)

-- MAIN APP DEPOTS / PACKAGES
addappid(551861, 1, "632aa738fbd6c7f663f0393e5403b9a46eb1c33320dd5cd0f48c42bd33224903")
addappid(551862, 1, "d2ef4d6dae3bde95857146230508466e20b6f04381703ea980ea955d11ec0633")
addappid(551863, 1, "399e4db7300385a2e226edb6de5373675941fe659295cf699ee8580b57a7c42f")
addappid(551864, 1, "ac1a815d6ef9b95e37845b192c3f2663b7c64a5065a646b717ca6901f6766e91")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1236550)
