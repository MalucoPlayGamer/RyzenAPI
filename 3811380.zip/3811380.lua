-- Lua provided by RyzenAPI
-- Game: JR East Train Simulator: Senzan Line(Sendai to Yamagata) E721 Series

-- MAIN APPLICATION
addappid(3811380)
-- Game: addappid(3811380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3811381, 1, "2c4a60783cb89943a219bd72f45e0f0cb9cbffce6e3058cd109d06516e8db650")
addappid(3811382, 1, "f95e37634ca26e2ce2cfcd9b52e8e18c403a28d53f647431039e744c21496ad8")
