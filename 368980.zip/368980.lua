-- Lua provided by RyzenAPI
-- Game: Force of Elements

-- MAIN APPLICATION
addappid(368980)
addappid(368981)
addappid(463900)
addappid(463901)
addappid(463902)
addappid(463903)
addappid(463904)
-- Game: addappid(368980)

-- MAIN APP DEPOTS / PACKAGES
addappid(368982,0,"1bffac44452356f761128c3b9ead1c2cb04e42ff73bab4332d0c8819fd7d2e77")
