-- Lua provided by RyzenAPI
-- Game: addappid(1423540)

-- MAIN APPLICATION
addappid(1423540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423541, 1, "14b192e9c563001c023e502717b70ecc59364bbdb4e2e6ecc62fb64506edc76b")
