-- Lua provided by RyzenAPI
-- Game: Space Block Buster

-- MAIN APPLICATION
addappid(1198290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1198291, 1, "c23c936101d255425684393aae41c729225b305168838add90c752fb3e179ecf")

