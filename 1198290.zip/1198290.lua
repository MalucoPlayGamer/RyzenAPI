-- Lua provided by RyzenAPI
-- Game: Space Block Buster

-- MAIN APPLICATION
addappid(1198290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198291, 1, "c23c936101d255425684393aae41c729225b305168838add90c752fb3e179ecf")
