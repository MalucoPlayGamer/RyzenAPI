-- Lua provided by RyzenAPI
-- Game: 2920550

-- MAIN APPLICATION
addappid(2920550)
-- Game: addappid(2920550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920551, 1, "6c1c5b7e5a0d79a8d62f7aa51e627acef12a8da05dd45a94dc63348d8c59a272")
