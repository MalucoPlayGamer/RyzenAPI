-- Lua provided by RyzenAPI 
-- Game: MISKATONIC
addappid(1618910)
addappid(1618911, 1, "dc408271e6a2565f097dcf6831bb1c5dc2416e65a272c627b6a41329afc3db58")
