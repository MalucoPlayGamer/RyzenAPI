-- Lua provided by RyzenAPI
-- Game: Game: Danger Drone

-- MAIN APPLICATION
addappid(2684290)
-- Game: addappid(2684290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684291, 1, "45ca7b00b8fefa0f7a26b3881c8001309ad18c2bf7d68033462b421bdfebae11")
