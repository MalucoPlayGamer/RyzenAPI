-- Lua provided by RyzenAPI
-- Game: football girl

-- MAIN APPLICATION
addappid(1476920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476921, 1, "b1321bea054096786c2da98dc851100c8b45d063143a814882a0f46dbc87220c")

