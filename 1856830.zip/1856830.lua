-- Lua provided by RyzenAPI
-- Game: ElbmarKs

-- MAIN APPLICATION
addappid(1856830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856833,0,"fb6c2107365743b38444aad9c388b17f389a7657816c2b8aeafee45b9fd1a362")

