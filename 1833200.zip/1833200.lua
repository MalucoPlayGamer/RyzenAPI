-- Lua provided by RyzenAPI
-- Game: DuneCrawl

-- MAIN APPLICATION
addappid(1833200)
-- Game: addappid(1833200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833201, 1, "4ebf2349b713cc1a7ac225caad84f56283857c06c4068226438616565443ed3c")
