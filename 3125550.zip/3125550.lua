-- Lua provided by RyzenAPI
-- Game: Haunted School The Presence Behind You

-- MAIN APPLICATION
addappid(3125550)
-- Game: addappid(3125550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125551, 1, "22b9678552d96ddeb201bb4c5deb4ee131292b35a86fc419322149a6df114c50")
