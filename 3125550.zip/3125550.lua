-- Lua provided by RyzenAPI
-- Game: Haunted School The Presence Behind You

-- MAIN APPLICATION
addappid(3125550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3125551, 1, "22b9678552d96ddeb201bb4c5deb4ee131292b35a86fc419322149a6df114c50")

