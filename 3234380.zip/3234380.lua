-- Lua provided by RyzenAPI
-- Game: Game: Once upon a Dungeon - Infinity

-- MAIN APPLICATION
addappid(3234380)
-- Game: addappid(3234380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3234381, 1, "ee4561552d3d2bf2b5b65b09c3cd1d767e9e8cc74819b45ec2350df01d6c1c9e")
