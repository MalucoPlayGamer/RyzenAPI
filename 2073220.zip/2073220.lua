-- Lua provided by RyzenAPI
-- Game: Outland Kingdoms

-- MAIN APPLICATION
addappid(2073220)
-- Game: addappid(2073220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073221, 1, "ee235762952336a22b4aaab9783c0598979a828fa2063ee221520c95249c82bb")
