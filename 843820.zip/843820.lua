-- Lua provided by RyzenAPI
-- Game: Game: AppID 843820

-- MAIN APPLICATION
addappid(843820)
-- Game: addappid(843820)

-- MAIN APP DEPOTS / PACKAGES
addappid(843821, 1, "c6a84a68bc25bc5a000230ab31423020bd8aec1840fd347670418c24e4ab538b")
