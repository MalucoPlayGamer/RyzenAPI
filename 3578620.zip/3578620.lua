-- Lua provided by RyzenAPI
-- Game: 3578620

-- MAIN APPLICATION
addappid(3578620)
-- Game: addappid(3578620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578621, 1, "9dafc660ab062308ebb40811ac41ce98cd76974e959babca4207dd8acf20dc42")
