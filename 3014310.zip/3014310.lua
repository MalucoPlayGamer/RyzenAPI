-- Lua provided by RyzenAPI
-- Game: addappid(3014310)

-- MAIN APPLICATION
addappid(3014310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014311, 1, "7919278ff96fe5ad57455ed711614f32d6193d8590c458737fb21ef1ae9cb7fa")
