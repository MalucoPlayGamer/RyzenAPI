-- Lua provided by RyzenAPI 
-- Game: Turret Tech
addappid(905060)
addappid(905061, 1, "c452f2ecd1fbadddbc067ddf0b24c255d8a3e490fa72692df3dd45f2b3845e88")
