-- Lua provided by RyzenAPI
-- Game: ENDLESS Legend™

-- MAIN APPLICATION
addappid(289130)

-- MAIN APP DEPOTS / PACKAGES
addappid(289131, 1, "17651efdf87f1b0170f2427fcd92f55f0db82ec69c2bcc1d16db1de41bde5330")
addappid(289132, 1, "fa596f34bec7a0a3175f9d2340aacc83316edb51d66320d184de969327c7f897")
addappid(289133, 1, "3e3a761698f4f672dceab29c14043df70e1e5bae73c255815f9d8b4dcd968906")
addappid(289134, 1, "812c66f2a62baf6640f2ccb6cee596eda6fc92793ecbc91099ff7173f19000bc")
addappid(289135, 1, "69661067d1afd6479efd3677d8ef0869395e97c71e14875a79a960269049802c")
addappid(289136, 1, "083fd70c56fa2bfe32b4cacfe0ec14cb34b60e705fd2160b17f37f59e7985236")
addappid(289137, 1, "f940b5be48f653743d7e9627e51ab7c6cbd10d10d2c4267f8322e3a76f7fa368")
addappid(289138, 1, "2d63065246c10ab6ca80fa23951a00ba66f8b711621216ba27c50e6db03c4d0a")
addappid(289139, 1, "15b12cbd21937c0d77ae0992b170689def989e61a2b0be4ecb926f956b90002b")
addappid(289140, 1, "d594aac932f6fbbacb7eb45883e2ca9f50c7270056d28a748fdcf66adcd81ece")
addappid(289141, 1, "11ac62bfb93fdc49221fa14a417a0403c284343e8f73626a92ef65dd9cdd266d")
addappid(289142, 1, "9a0d83de1444ccb8ff1915bee0f5c5205adf741f68d56713eeab398d58be3427")
addappid(289143, 1, "da7fbcc0c7f87167a5b6e87341408b2ddb82d88a7fcf13110841135ce1c8ddb9")
addappid(289144, 1, "5d2d0365664533a0f328ceac26463f61fb75cfc6a031f9e7dceffa25d98b28e3")
addappid(289145, 1, "34d2252843cd857322648bd9ac0ec6e10fd5a24bf209e68452f260a50bbc4e6c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(297650)
addappid(297651)
addappid(297652)
addappid(297800)
addappid(357360)
addappid(374500)
addappid(415700)
addappid(415710)
addappid(415720)
addappid(451050)
addappid(521220)
addappid(600560)
addappid(718570)
addappid(854750)
addappid(988450)
addappid(1523740)
