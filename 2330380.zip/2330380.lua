-- Lua provided by RyzenAPI
-- Game: addappid(2330380)

-- MAIN APPLICATION
addappid(2330380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330381, 1, "5d3dc918faa775f8c28d7fcee6efe82fc0c74f5de3f3faed6053827408fb4250")
