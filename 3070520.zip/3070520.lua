-- Lua provided by RyzenAPI
-- Game: Granny: Escape Together

-- MAIN APPLICATION
addappid(3070520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070521, 1, "a624ab03d223bb7e405e6c834738fca46393c4cf737fb3b154202f53dbc62c18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
