-- Lua provided by RyzenAPI 
-- Game: Granny: Escape Together
addappid(3070520)
addappid(3070521, 1, "a624ab03d223bb7e405e6c834738fca46393c4cf737fb3b154202f53dbc62c18")
