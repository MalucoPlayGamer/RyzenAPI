-- Lua provided by RyzenAPI
-- Game: 3070520

-- MAIN APPLICATION
addappid(3070520)
-- Game: addappid(3070520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070521, 1, "a624ab03d223bb7e405e6c834738fca46393c4cf737fb3b154202f53dbc62c18")
