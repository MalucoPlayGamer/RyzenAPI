-- Lua provided by RyzenAPI
-- Game: Rewrite Arrange Album 'Selene'

-- MAIN APPLICATION
addappid(1856590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856591, 1, "277835b4eeb0b832796294a523c6fa624a14f40000e860ae57ce3843d246b5ee")
addappid(1856599, 1, "3046d17869cdeea86b30ed17c294b0de7d6cf995f8f1533f35739e187c8bfb50")

