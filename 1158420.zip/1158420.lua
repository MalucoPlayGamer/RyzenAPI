-- Lua provided by RyzenAPI
-- Game: addappid(1158420)

-- MAIN APPLICATION
addappid(1158420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158422,0,"42defb551c149cac294ae9f3bd8780e09ae46a3655f300f7ff074c139e95943e")
addappid(1158423,0,"324f007042fcec476a18c338db31cbd06f7dcbc75eb8a17e56bdf2e39f8157fd")
