-- Lua provided by RyzenAPI
-- Game: Drunk Woman

-- MAIN APPLICATION
addappid(3087200)
addappid(3100830)
-- Game: addappid(3087200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087201, 1, "55a4f6a3bd649b35e3cd42fca891737b127f9652cd3883009b0eaf3f040d32d4")
