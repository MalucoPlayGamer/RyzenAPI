-- Lua provided by RyzenAPI
-- Game: Penumbra: Requiem

-- MAIN APPLICATION
addappid(22140)
addappid(229020)

-- MAIN APP DEPOTS / PACKAGES
addappid(22141, 1, "5a273040e1bf4df9111903817afe1f3f9fda0d513111455216028a243ed6d773")
addappid(22142, 1, "56d90961a291d48d53a8df912240f5704a78e36f9c7597b28bb4c17c25c423a0")
addappid(22143, 1, "1ef0ef4b5b26bf94631d68d7634f80ab771a4d1ee3b5e85ceaa05a9c1720a4eb")

