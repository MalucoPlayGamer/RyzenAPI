-- Lua provided by RyzenAPI
-- Game: Knight of the Hamsters

-- MAIN APPLICATION
addappid(328650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(328651, 1, "4aa2030321d37d94307b2eb9b9fd7db1cf08b922d578a3d83f6bcaaf68aba3d6")
addappid(344970, 0, "0546ba3861b53b5423dbeccd23675b5b72fb5fde6991876a1be66304f00e22c2")
