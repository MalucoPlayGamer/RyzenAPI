-- Lua provided by RyzenAPI
-- Game: 287220

-- MAIN APPLICATION
addappid(287220)
-- Game: addappid(287220)

-- MAIN APP DEPOTS / PACKAGES
addappid(287221, 1, "2af449d6decb3e096a52fc23a3efd45be85ae513da9ecc8f8e3ae0d65e2dde48")
addappid(287222, 1, "df4d1b0f6ecd5b35023cb8fba6f5bf821cd41ada929e404d83844a2785272342")
