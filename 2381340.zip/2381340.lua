-- Lua provided by RyzenAPI
-- Game: -256

-- MAIN APPLICATION
addappid(2381340)
-- Game: addappid(2381340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381343,0,"8d5a3078290be0d8bec2652a0cfe2e84147ce6ae7f95fb18445659c6fdf92be5")
addappid(2381344,0,"d40f9b56bebee9a9f060ef08d58908c85354b173b5c7124cb525a3d154fb0eb5")
