-- Lua provided by RyzenAPI
-- Game: addappid(420770)

-- MAIN APPLICATION
addappid(420770)
addappid(454110)

-- MAIN APP DEPOTS / PACKAGES
addappid(420771, 1, "bc35c5439a9b2c019e9281c5f4b8c70303a4d50664321e83a2fcd28f70bddb45")
