-- Lua provided by RyzenAPI
-- Game: Trio Adventures

-- MAIN APPLICATION
addappid(748310)

-- MAIN APP DEPOTS / PACKAGES
addappid(748312,0,"9d8176625fa84f5a119337a0b68243513ac5d9fbb241ac8f1424e1b1b3fade3f")

