-- Lua provided by RyzenAPI
-- Game: The Forgotten Forest

-- MAIN APPLICATION
addappid(410050)

-- MAIN APP DEPOTS / PACKAGES
addappid(410051, 1, "0d2503537ad2c5970d2491994c099ebb5af8be8c8c66c96baa87170ef480ddf6")
