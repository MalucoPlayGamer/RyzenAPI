-- Lua provided by RyzenAPI
-- Game: Island Saver

-- MAIN APPLICATION
addappid(1210250)

