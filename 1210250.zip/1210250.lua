-- Lua provided by RyzenAPI
-- Game: Island Saver

-- MAIN APPLICATION
addappid(1210250)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1247340)
addappid(1354010)
