-- Lua provided by RyzenAPI
-- Game: Beats&Boss Demo

-- MAIN APPLICATION
addappid(3445840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445841, 1, "6866841d705cc2ea76549f204f56b895aea56b7e446e94bf34f0f4ad640ea9d9")
