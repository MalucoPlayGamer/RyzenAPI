-- Lua provided by RyzenAPI
-- Game: Game: AppID 725280

-- MAIN APPLICATION
addappid(725280)
-- Game: addappid(725280)

-- MAIN APP DEPOTS / PACKAGES
addappid(725281, 1, "f66980d2c6f01debf69d5e5eeea1fe4d623466fae06a8b0aaf1ac1633b8b421c")
