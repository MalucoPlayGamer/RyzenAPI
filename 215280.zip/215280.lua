-- Lua provided by RyzenAPI
-- Game: Secret World Legends

-- MAIN APPLICATION
addappid(215280)

-- MAIN APP DEPOTS / PACKAGES
addappid(215281, 1, "f81b1a76698af3fd318a7ef68c62503b7dd3d43c70efe517e00143fef717028f")
addappid(228986, 0, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(215291)
addappid(261130)
addappid(296270)
addappid(296271)
addappid(334590)
addappid(359380)
addappid(428780)
addappid(428890)
addappid(428970)
addappid(429010)
addappid(429011)
addappid(430090)
addappid(430091)
addappid(430092)
addappid(430093)
addappid(430094)
addappid(579930)
addappid(688030)
addappid(819320)
addappid(1017810)
