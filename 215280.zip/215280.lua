-- Lua provided by RyzenAPI
-- Game: Game: Secret World Legends

-- MAIN APPLICATION
addappid(215280)
-- Game: addappid(215280)

-- MAIN APP DEPOTS / PACKAGES
addappid(215281, 1, "f81b1a76698af3fd318a7ef68c62503b7dd3d43c70efe517e00143fef717028f")
addappid(228986, 0, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")
