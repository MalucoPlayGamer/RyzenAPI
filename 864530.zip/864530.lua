-- Lua provided by RyzenAPI
-- Game: Necro Immortallis

-- MAIN APPLICATION
addappid(864530)

-- MAIN APP DEPOTS / PACKAGES
addappid(864531,0,"402898b6f108bf84448eeb14424f7aaa0f9dfac323891cd0dd7b69a0c1ee6914")

