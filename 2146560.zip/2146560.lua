-- Lua provided by RyzenAPI
-- Game: 2146560

-- MAIN APPLICATION
addappid(2146560)
addappid(3052400)
-- Game: addappid(2146560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146561, 1, "b55f86bc978e6fa19a1bfec272cab0c547861f3eb08a75523967b45c7145329b")
