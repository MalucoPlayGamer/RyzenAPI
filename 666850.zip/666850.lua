-- Lua provided by RyzenAPI
-- Game: Beyond the Horizon

-- MAIN APPLICATION
addappid(666850)

-- MAIN APP DEPOTS / PACKAGES
addappid(666851, 1, "192897bce7f38f8f63b2fdfd5f7bb2f5ba6b9da66e78fa80eb5498a8ed7a40d9")

