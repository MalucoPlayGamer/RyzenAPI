-- Lua provided by RyzenAPI
-- Game: Demons Roots

-- MAIN APPLICATION
addappid(1933660)
-- Game: addappid(1933660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933661, 1, "6a72455adb090f5450df3153498406e6ffecbc4c18a79f3eac48edba3517b4fb")
addappid(1933662, 1, "39d4c2545f8f64ed5d98a87a78ed5c41081b19ba05101ad5e24e5e6122612f89")
