-- Lua provided by RyzenAPI
-- Game: Mini Car Money Chase

-- MAIN APPLICATION
addappid(1493410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493411, 1, "1ee46ee5d4fd7da67d6b0a20a606ef94c1e11e9cb87dd3289ffc3f73ac6a668a")
