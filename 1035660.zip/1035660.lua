-- Lua provided by RyzenAPI
-- Game: Game: AppID 1035660

-- MAIN APPLICATION
addappid(1035660)
-- Game: addappid(1035660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035661, 1, "bfae942a6f99092a678841f88a74ca007670dbff2f3202e065dd109d24de366a")
