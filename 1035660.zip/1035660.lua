-- Lua provided by RyzenAPI
-- Game: Chromosome Evil

-- MAIN APPLICATION
addappid(1035660)
addappid(2240370)
addappid(2810130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1035661, 1, "bfae942a6f99092a678841f88a74ca007670dbff2f3202e065dd109d24de366a")

