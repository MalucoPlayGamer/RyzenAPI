-- Lua provided by RyzenAPI
-- Game: 3120730

-- MAIN APPLICATION
addappid(3120730)
-- Game: addappid(3120730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120731, 1, "33628a9c17cff16e2ddf20d6dc49baf0c0c3e7129dab69a37d5c3215271d2ff8")
