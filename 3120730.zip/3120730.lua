-- Lua provided by RyzenAPI
-- Game: Difference

-- MAIN APPLICATION
addappid(3120730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120731, 1, "33628a9c17cff16e2ddf20d6dc49baf0c0c3e7129dab69a37d5c3215271d2ff8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
