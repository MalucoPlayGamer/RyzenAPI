-- Lua provided by SkyAPI 
-- Game: Difference
addappid(3120730)
addappid(3120731, 1, "33628a9c17cff16e2ddf20d6dc49baf0c0c3e7129dab69a37d5c3215271d2ff8")
