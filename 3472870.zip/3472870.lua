-- Lua provided by RyzenAPI
-- Game: Public Toilet Simulator

-- MAIN APPLICATION
addappid(3472870)
-- Game: addappid(3472870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3472871, 1, "f36fd6ae98e5da8c2e8de42e0f3b782c1230e70e31caeda02445b5afb8e8191e")
