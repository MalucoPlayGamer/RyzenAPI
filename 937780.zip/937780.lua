-- Lua provided by RyzenAPI
-- Game: ♞ The Tactics of War ♞

-- MAIN APPLICATION
addappid(937780)

-- MAIN APP DEPOTS / PACKAGES
addappid(937781, 1, "84b8ea0b643aeb1fb7e1044498d10c4886754a01f13ad62aeb64c73051a72a3c")
