-- Lua provided by RyzenAPI
-- Game: Muse Dash

-- MAIN APPLICATION
addappid(774171)
addappid(2593750)
addappid(2593750) -- Muse Plus

-- MAIN APP DEPOTS / PACKAGES
addappid(774171, 1, "334d4f66db94f122ff3175db91062b8efbdcc9d0a3bf0a569888132d4aa70f6e")
addappid(774172, 1, "c4fdeb37adb91f019b5f8f1378c0a63c3a3b90ffec89c7e0394b32a28206d2ec")
addappid(774173, 1, "e3c55a2a1de897657fb5347590d09a3c41d944a2b041848d5cdacb44afed102f")
addappid(1055810, 1, "ecf8e8de3bbebc8dc0a0f6aecb1c46d919f2172bb7e3611cd56ba636d523d880")
addtoken(774171, "1032167890812251798")

