-- Lua provided by SkyAPI 
-- Game: Survive The Cards
addappid(3606580)
addappid(3606581, 1, "a5cc3c957cdf0233c9002e212f84e2817bed137244c1b365cd9006e417f2dd13")
