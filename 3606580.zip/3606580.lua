-- Lua provided by RyzenAPI
-- Game: 3606580

-- MAIN APPLICATION
addappid(3606580)
-- Game: addappid(3606580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3606581, 1, "a5cc3c957cdf0233c9002e212f84e2817bed137244c1b365cd9006e417f2dd13")
