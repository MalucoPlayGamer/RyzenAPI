-- Lua provided by RyzenAPI
-- Game: Caveman World: Mountains of Unga Boonga

-- MAIN APPLICATION
addappid(462960)

-- MAIN APP DEPOTS / PACKAGES
addappid(462961, 1, "93e2fe74ed84440daa0d62936a803c8b8beaf6433f36ed26ec979a8fd22feb6e")
addappid(462962, 1, "ecf46c5feff22f34325820ae3c5bd20a7699f2367a1a171640ffc3893a6118e7")
addappid(462963, 1, "61e9cbbe0cd9fcecfb2c95ae9207256f2a78b29dd13cda6423ba2f5a1ee0c312")

