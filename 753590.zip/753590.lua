-- Lua provided by RyzenAPI
-- Game: Hellbound

-- MAIN APPLICATION
addappid(753590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(753591, 1, "96f72b2e7b96ebdc347602ef2a8bb3a25e4730d8b4b5714476c630895760f90a")
addappid(1461510, 0, "13a8ef767b3ddba5da9023195abe2650179f51f4b228ee380044c11945fdb893")

