-- Lua provided by SkyAPI 
-- Game: Hellbound
addappid(753590)
addappid(753591, 1, "96f72b2e7b96ebdc347602ef2a8bb3a25e4730d8b4b5714476c630895760f90a")
addappid(1461510, 0, "13a8ef767b3ddba5da9023195abe2650179f51f4b228ee380044c11945fdb893")
