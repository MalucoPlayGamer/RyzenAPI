-- Lua provided by RyzenAPI
-- Game: Space Engineers Dedicated Server

-- MAIN APPLICATION
addappid(298740)

-- MAIN APP DEPOTS / PACKAGES
addappid(298741, 1, "ce2400549ab50ecb16948ec137f55be8429c330f1e555431c7e5b57d699d0860")
