-- Lua provided by RyzenAPI
-- Game: Beyond

-- MAIN APPLICATION
addappid(1137880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1137881, 1, "26fd7740ddb5af97c961c18e93dca2dfa6a2e3990eae34a0810602b3997b3bf6")

