-- Lua provided by RyzenAPI
-- Game: Beyond

-- MAIN APPLICATION
addappid(1137880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137881, 1, "26fd7740ddb5af97c961c18e93dca2dfa6a2e3990eae34a0810602b3997b3bf6")
