-- Lua provided by RyzenAPI
-- Game: addappid(3648150)

-- MAIN APPLICATION
addappid(3648150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3648151, 1, "ac8cfd62ae821b24d86614ae25a8a804ac079bd8c6fefa84394e5744187df0e6")
