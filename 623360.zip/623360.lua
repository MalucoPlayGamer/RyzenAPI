-- Lua provided by RyzenAPI
-- Game: Game: Grim Tales: The Legacy Collector's Edition

-- MAIN APPLICATION
addappid(623360)
-- Game: addappid(623360)

-- MAIN APP DEPOTS / PACKAGES
addappid(623361, 1, "622dad4a310ce9d51d42c2131f86b064331cfd1fd5ef47e6b00c1b227a5b92bb")
