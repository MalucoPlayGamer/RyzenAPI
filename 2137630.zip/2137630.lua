-- Lua provided by RyzenAPI
-- Game: AppID 2137630

-- MAIN APPLICATION
addappid(2137630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137631, 1, "37344c03cc8bcbced59ccaa059d667976d1c64e19a0f9c704d089388fcec242f")

