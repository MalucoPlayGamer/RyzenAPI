-- Lua provided by RyzenAPI
-- Game: 932790

-- MAIN APPLICATION
addappid(932790)
-- Game: addappid(932790)

-- MAIN APP DEPOTS / PACKAGES
addappid(932791, 1, "54a6457837b3f7fd3931a98fee0314b7e2ec611669c08b7389c78d89465d319f")
