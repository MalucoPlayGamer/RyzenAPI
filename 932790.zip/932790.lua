-- Lua provided by RyzenAPI
-- Game: ASCENT: Crash Landing

-- MAIN APPLICATION
addappid(932790)

-- MAIN APP DEPOTS / PACKAGES
addappid(932791, 1, "54a6457837b3f7fd3931a98fee0314b7e2ec611669c08b7389c78d89465d319f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
