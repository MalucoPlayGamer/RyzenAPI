-- Lua provided by RyzenAPI
-- Game: addappid(2706720)

-- MAIN APPLICATION
addappid(2706720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706721, 1, "8e790f6843e10e09b2dad0a96304aba2322bbb7234608ee48f9227ac47fba0c2")
