-- Lua provided by RyzenAPI
-- Game: 1869590

-- MAIN APPLICATION
addappid(1869590)
-- Game: addappid(1869590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869591, 1, "945287daf599ce240416ba5b21d64c68ffeb0838dd581d705e3b93b8506d1785")
