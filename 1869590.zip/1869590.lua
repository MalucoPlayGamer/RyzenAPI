-- Lua provided by RyzenAPI
-- Game: Omega Strikers

-- MAIN APPLICATION
addappid(1869590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869591, 1, "945287daf599ce240416ba5b21d64c68ffeb0838dd581d705e3b93b8506d1785")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
