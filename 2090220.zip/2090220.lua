-- Lua provided by RyzenAPI
-- Game: addappid(2090220)

-- MAIN APPLICATION
addappid(2090220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090221, 1, "075490eee0ea9f25b3228b04afd65f6c690162fedd0a1b1ee7084cbec92f590f")
