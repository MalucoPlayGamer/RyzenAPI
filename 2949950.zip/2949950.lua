-- Lua provided by RyzenAPI
-- Game: Game: HAELE 3D - Portrait Studio Lite - Drawing References

-- MAIN APPLICATION
addappid(2949950)
-- Game: addappid(2949950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949951, 1, "b549f031671f1a048c06dec9d8e12b824e59166dd6fdd592e2bfbafad6983785")
