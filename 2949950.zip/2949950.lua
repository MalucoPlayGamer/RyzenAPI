-- Lua provided by RyzenAPI
-- Game: HAELE 3D - Portrait Studio Lite - Drawing References

-- MAIN APPLICATION
addappid(2949950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949951, 1, "b549f031671f1a048c06dec9d8e12b824e59166dd6fdd592e2bfbafad6983785")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
