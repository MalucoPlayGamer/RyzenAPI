-- Lua provided by RyzenAPI
-- Game: World of Tanks — Soundtrack

-- MAIN APPLICATION
addappid(1638640)
-- Game: addappid(1638640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638641, 1, "041a2942e3e8d751702d74c441c1ff9c99aa19bd25720b6a2c96f9afce379231")
