-- Lua provided by RyzenAPI
-- Game: Ultimate Epic Battle Simulator 2

-- MAIN APPLICATION
addappid(1468720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468721, 1, "c0d10ec1395dc0ba8f71593641ac527d1770463e9788a1f0e4a2b27f14dda7f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
