-- Lua provided by RyzenAPI
-- Game: 1468720

-- MAIN APPLICATION
addappid(1468720)
-- Game: addappid(1468720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468721, 1, "c0d10ec1395dc0ba8f71593641ac527d1770463e9788a1f0e4a2b27f14dda7f6")
