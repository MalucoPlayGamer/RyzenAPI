-- Lua provided by RyzenAPI
-- Game: Fire: Ungh’s Quest

-- MAIN APPLICATION
addappid(325520)
-- Game: addappid(325520)

-- MAIN APP DEPOTS / PACKAGES
addappid(325522,0,"9539add703bfaaa0df9d93525dc7e49ad0ce83424ba0e2da859160bc7da9edd4")
addappid(325523,0,"cb572970bcb3f3da8988f43df0f6a6a3bf16918e109df2b0848f2fdd5a80d9d6")
addappid(325524,0,"6250eefe479d2e96acb274b266e9d0048cd6b19dc5ef3a681b8f39ec1ff56177")
addappid(325525,0,"2795ae3ed784d10a744a32cce0565d8e0d86dd35996ba81a0ebac7aa868a1e62")
addappid(325526,0,"680d74203eb38b3a3f4ea875c30550e0526018ea47163cde3d6af7303b452abc")
addappid(325527,0,"71748df9cb3d1a3f2f548054bae8c7a1cd7a4ac26665a3cad510a54ed2e663d1")
addappid(325528,0,"a93947fb9e8c627832cc8cc959bae1d8b7f53d465095f3c0391debe57cf2b699")
addappid(325529,0,"e87a01f6b5526eb1bfc44ab8868f5c0947bef01c8030b8bdfb3abb0c6f1b3251")
addappid(353951,0,"5d9cf07456035a7d2b826f8114fd6c1ea784ff13e2b2267da8b61585fc9a1af5")
