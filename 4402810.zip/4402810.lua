-- 4402810's Lua and Manifest Created by Hubcap Manifest
-- INCREDECK
-- Created: August 29, 2026 at 01:10:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4402810) -- INCREDECK
-- MAIN APP DEPOTS
addappid(4402811, 1, "e574fd5b82d8b86b4bacd65c72e81d69e4d6692e4370f328edf85c52c29d6e51") -- Depot 4402811
setManifestid(4402811, "2744696651190100648", 108242956)