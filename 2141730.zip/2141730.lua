-- Lua provided by RyzenAPI
-- Game: Backrooms: Escape Together

-- MAIN APPLICATION
addappid(2141730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141731, 1, "cfcbb1b05a371faabeb03500c308dbae345a2c7d9a45417a910283c9201e084d")
addappid(2141732, 1, "1038f744a70ce5b445cdbfc9ce77601ae45a36279d0a9ad02b59b714acfba762")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
