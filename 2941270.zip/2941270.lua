-- Lua provided by RyzenAPI
-- Game: Guardians of the Sanctree Demo

-- MAIN APPLICATION
addappid(2941270)
-- Game: addappid(2941270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941271, 1, "729dfb8f366179057be9599cd29262302e1015697d23e7cd0c1026f019871c5a")
