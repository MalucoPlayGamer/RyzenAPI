-- Lua provided by RyzenAPI 
-- Game: Weird West Soundtrack
addappid(1781460)
addappid(1781461, 1, "308933fbee3cc9c34e5f7b1f2e732fa3f34b2da34ff12d3eeb1089c728516fb0")
addappid(1781462, 1, "cf7cf5bc7d990df281e8d8c11a59642b1eac9afe9ff0fc931eae5e053333a553")
