-- Lua provided by SkyAPI 
-- Game: LOST BALLOONS: Airy mates
addappid(2525690)
addappid(2525691, 1, "71a7ab2c1670d06caab3630e8768f3d0c76267d247a73ef7a65631fd7fddbc72")
