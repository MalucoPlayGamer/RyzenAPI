-- Lua provided by RyzenAPI
-- Game: The Bunker 69. Adults Only

-- MAIN APPLICATION
addappid(1187550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187551, 1, "efed108adf1f1ada14319a1e519776691c8b1c091b6b796ce8b78f6d5c22118a")
