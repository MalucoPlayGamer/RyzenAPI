-- Lua provided by RyzenAPI
-- Game: 856220

-- MAIN APPLICATION
addappid(228987)
addappid(228990)
addappid(229006)
addappid(856220)
addappid(856221)
-- Game: addappid(856220)

-- MAIN APP DEPOTS / PACKAGES
addappid(856222,0,"1c455ae3a70c6b829daa1cb7df301fcfd81f942997a673258454d7812118c39c")
