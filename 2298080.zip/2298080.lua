-- Lua provided by RyzenAPI
-- Game: Game: Snafu

-- MAIN APPLICATION
addappid(2298080)
-- Game: addappid(2298080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298081, 1, "98141dc75a5e903c364916eb5dd34d523148a67377085cc0ac72f19a3d60c085")
