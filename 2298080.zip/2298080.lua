-- Lua provided by SkyAPI 
-- Game: Snafu
addappid(2298080)
addappid(2298081, 1, "98141dc75a5e903c364916eb5dd34d523148a67377085cc0ac72f19a3d60c085")
