-- Lua provided by RyzenAPI
-- Game: Data Hacker: Corruption

-- MAIN APPLICATION
addappid(329000)

-- MAIN APP DEPOTS / PACKAGES
addappid(329001, 1, "5c2db948acaf01cb628674e83775d200d1732a9fb7ee9ea3058402e7876a4fcb")
addappid(340670, 0, "043cfd88ecb8599bde30a0bc10d1f8203fb2056528829331c3123be1522f0122")

