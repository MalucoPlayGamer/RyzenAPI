-- Lua provided by SkyAPI 
-- Game: RiftGuard
addappid(3752220)
addappid(3752221, 1, "8f00ff5b9af31c9d2d04e1437a1cb2115471cc1f9a9f67fdd8cbb0960d9fd242")
