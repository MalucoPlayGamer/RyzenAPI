-- Lua provided by RyzenAPI
-- Game: The Lord of the Parties

-- MAIN APPLICATION
addappid(1602880)
-- Game: addappid(1602880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602881, 1, "6e670b0f1474e87aeaed92a5bc334a665744df1f852640eb67f592f3a771f83f")
