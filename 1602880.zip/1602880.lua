-- Lua provided by RyzenAPI
-- Game: The Lord of the Parties

-- MAIN APPLICATION
addappid(1602880)
addappid(1921000)
addappid(1941050)
addappid(2136730)
addappid(2184710)
addappid(2184711)
addappid(2238640)
addappid(2320100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602881,0,"6e670b0f1474e87aeaed92a5bc334a665744df1f852640eb67f592f3a771f83f")

