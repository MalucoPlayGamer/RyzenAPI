-- Lua provided by RyzenAPI
-- Game: Escape From Zombie U:reloaded Demo

-- MAIN APPLICATION
addappid(1977850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977851, 1, "a5be1cc00c5e79583d30351653a06321640ca64a1d09eb8ec8eabaa8e36be5ab")
