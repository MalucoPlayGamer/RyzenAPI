-- Lua provided by RyzenAPI
-- Game: Red Johnson's Chronicles - 1+2 - Steam Special Edition

-- MAIN APPLICATION
addappid(312050)
-- Game: addappid(312050)

-- MAIN APP DEPOTS / PACKAGES
addappid(312051, 1, "9adad7f5c2c49006fa89ab4f284f9bc6065935b57b14bd25a748c62cd4cfdc61")
