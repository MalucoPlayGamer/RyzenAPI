-- Lua provided by RyzenAPI
-- Game: Red Johnson's Chronicles - 1+2 - Steam Special Edition

-- MAIN APPLICATION
addappid(312050)

-- MAIN APP DEPOTS / PACKAGES
addappid(312051, 1, "9adad7f5c2c49006fa89ab4f284f9bc6065935b57b14bd25a748c62cd4cfdc61")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
