-- Lua provided by RyzenAPI
-- Game: SECTOR

-- MAIN APPLICATION
addappid(366960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(366961, 1, "09fbaec44a6a1ba38e59fa4543e34b90d88d5bff8399797fae34176172020778")

