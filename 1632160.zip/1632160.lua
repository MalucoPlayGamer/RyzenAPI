-- Lua provided by RyzenAPI 
-- Game: 祛魅·格心（祛魅3）
addappid(1632160)
addappid(1632161, 1, "cf7924417fbb5223106093efadb4d0338e31dca57c13566824cf6371c3bfd87c")
addappid(1673930, 0, "352778f0c50e0afd2bb41df0c9e1f3b4ebb9c3902218848de6946ac54a12980c")
addappid(1697480, 0, "0bb2fa732a5882c0becada6cd55a32eeda4531e1f9d5e6fefc7897ca575d7b9f")
