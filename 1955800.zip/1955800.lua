-- Lua provided by RyzenAPI
-- Game: Game: TRANSFORMERS: EARTHSPARK - Expedition

-- MAIN APPLICATION
addappid(1955800)
-- Game: addappid(1955800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955801, 1, "fbf1bdecdf5de200758f988a163a5b34dd59d619af0b9e2656271c0ff35d72d2")
