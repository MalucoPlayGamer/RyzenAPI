-- Lua provided by SkyAPI 
-- Game: TRANSFORMERS: EARTHSPARK - Expedition
addappid(1955800)
addappid(1955801, 1, "fbf1bdecdf5de200758f988a163a5b34dd59d619af0b9e2656271c0ff35d72d2")
