-- Lua provided by RyzenAPI
-- Game: Step Away

-- MAIN APPLICATION
addappid(3932880)
addappid(3933750)

