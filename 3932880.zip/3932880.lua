-- Lua provided by RyzenAPI
-- Game: Step Away

-- MAIN APPLICATION
addappid(3932880)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3933750)
