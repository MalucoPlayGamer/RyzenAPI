-- Lua provided by RyzenAPI
-- Game: Altruistic

-- MAIN APPLICATION
addappid(3790230)
-- Game: addappid(3790230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3790231, 1, "830c2a00e91635797aeb8a1e81b7c2db62326df054d8acb69914d541decb9905")
