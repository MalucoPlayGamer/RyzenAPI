-- Lua provided by RyzenAPI
-- Game: Ghostrunner 2

-- MAIN APPLICATION
addappid(2144740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144741, 1, "d8c29346c26cded430d2454682d4c10c4b3ae1605e872fd1a8a829ecb79e1de4")
