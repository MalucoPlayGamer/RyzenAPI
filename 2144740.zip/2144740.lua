-- Lua provided by RyzenAPI
-- Game: Ghostrunner 2

-- MAIN APPLICATION
addappid(2144740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144741, 1, "d8c29346c26cded430d2454682d4c10c4b3ae1605e872fd1a8a829ecb79e1de4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2573290)
addappid(2573300)
addappid(2573310)
addappid(2574920)
addappid(2691130)
addappid(2769320)
addappid(2988270)
addappid(3092910)
addappid(3232490)
