-- Lua provided by RyzenAPI
-- Game: Nandeyanen!? - The 1st Sûtra

-- MAIN APPLICATION
addappid(386090)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(386091, 1, "690155a7a7293f2ff957df77ad8c8d7768fb9ce38b1a73e872345db2ae59c1c9")

