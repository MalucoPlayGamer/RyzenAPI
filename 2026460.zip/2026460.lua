-- Lua provided by RyzenAPI
-- Game: Wreck the Fed

-- MAIN APPLICATION
addappid(2026460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026461, 1, "68d18c5518032496c02e832c4fa93bcc18f48ab724f56746991d3b3c486ae999")
