-- Lua provided by RyzenAPI
-- Game: Stargate: Timekeepers

-- MAIN APPLICATION
addappid(1523650)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1523651, 1, "4ca991b01a8cde33b8c336fa91204e3723a75a1bea88e98044bc71dd04afbbac")
addappid(1523652, 1, "8fc2c0f2a0ab9105e0fb54349c07437f47a84251d7e4c10f73c6e6f5042eb4fe")

