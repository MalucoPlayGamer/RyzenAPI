-- Lua provided by RyzenAPI
-- Game: The Happyhills Homicide

-- MAIN APPLICATION
addappid(3278760)

