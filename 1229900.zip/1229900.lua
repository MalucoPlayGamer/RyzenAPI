-- Lua provided by RyzenAPI
-- Game: AppID 1229900

-- MAIN APPLICATION
addappid(1229900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229901, 1, "217d6fcc0ea569ac7e540360716d762eeb06f25ae3952c0bbeb77dd27077cfe5")
addappid(1350660, 0, "e0cb762418ec06b6b3804d5816c110648a39b4a2987201cd0a75fe4876eb50e1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1256310)
addappid(1606100)
addappid(1682100)
