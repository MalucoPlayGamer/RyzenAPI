-- Lua provided by RyzenAPI
-- Game: 3359280

-- MAIN APPLICATION
addappid(3359280)
-- Game: addappid(3359280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359281, 1, "8d1c76f010f6f613db3ec5e9d7aa3036cf92cf49e0eb654dae085d004fccc743")
