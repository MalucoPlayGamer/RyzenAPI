-- Lua provided by RyzenAPI
-- Game: AppID 675940

-- MAIN APPLICATION
addappid(675940)
-- Game: addappid(675940)

-- MAIN APP DEPOTS / PACKAGES
addappid(675941, 1, "4414eeb0ea9e85599a8890f4caa6c7200402f8915e6724c89fe79fe31fa57a2d")
