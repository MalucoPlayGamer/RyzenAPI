-- Lua provided by RyzenAPI 
-- Game: AppID 1286620
addappid(1286620)
addappid(1286621, 1, "0ec89ef2ebf2e24b67658a01658bc9de1bd2216f447ab86218d5ff36e39b38d6")
