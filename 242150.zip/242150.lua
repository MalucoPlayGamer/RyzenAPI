-- Lua provided by RyzenAPI
-- Game: Orcs Must Die 2 Workshop Tool

-- MAIN APPLICATION
addappid(242150)

-- MAIN APP DEPOTS / PACKAGES
addappid(242151, 1, "59b803c2c1e947c18b86b86a0e309c75aacbbd00998c510311be587fa26192e9")

