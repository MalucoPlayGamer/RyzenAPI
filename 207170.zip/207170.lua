-- Lua provided by SkyAPI 
-- Game: Legend of Grimrock
addappid(207170)
addappid(207171, 1, "76d94b4cd3547087fd6c76b09517238f980fef757bdc865f0d8465cc80615866")
addappid(207172, 1, "8d0064ee42a692ba0df71b0bb6206249e5a1de5a7d6b6542a7bbcbde6c42eacd")
addappid(207173, 1, "bf843fbc32bfa580431394313a15faaff3471fe28ab81b2410291f9a300bab66")
