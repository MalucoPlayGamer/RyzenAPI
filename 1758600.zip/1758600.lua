-- Lua provided by RyzenAPI
-- Game: 1758600

-- MAIN APPLICATION
addappid(1758600)
-- Game: addappid(1758600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758601, 1, "30060d693bbd861e7eb969b3c26bc7fedfbc9291a0981f4cf8bb98d0477a1255")
