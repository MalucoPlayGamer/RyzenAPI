-- Lua provided by RyzenAPI
-- Game: ATRIA-1

-- MAIN APPLICATION
addappid(1758600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758601, 1, "30060d693bbd861e7eb969b3c26bc7fedfbc9291a0981f4cf8bb98d0477a1255")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
