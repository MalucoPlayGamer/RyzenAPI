-- Lua provided by RyzenAPI
-- Game: OutRage: Fight Fest

-- MAIN APPLICATION
addappid(2307870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307871, 1, "eb9b51daa38248e517fcc4a7e3601144a3c515539c5530d645bbd828ea0af86b")
