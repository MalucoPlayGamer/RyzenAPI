-- Lua provided by RyzenAPI
-- Game: 3724480

-- MAIN APPLICATION
addappid(3724480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3724480,0,"51d2ff11e0fdd3292ebbce59a0a6228de758f8eafd7ad2cafd012fb503d3295d")

