-- Lua provided by RyzenAPI
-- Game: 500 CALIBER CONTRACTZ Demo

-- MAIN APPLICATION
addappid(3033620)
-- Game: addappid(3033620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033621, 1, "cb2c69a4a2f602239aba64b1ff7eab77a8d1fb21a09f02637be216d7d6e556ed")
