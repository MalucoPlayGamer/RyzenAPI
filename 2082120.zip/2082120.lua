-- Lua provided by RyzenAPI
-- Game: Game: AppID 2082120

-- MAIN APPLICATION
addappid(2082120)
-- Game: addappid(2082120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082121, 1, "c8c5e4829ef47ae5265340cc94e8e26e7632073092da8aea418708717f55902c")
