-- Lua provided by SkyAPI 
-- Game: AppID 511670
addappid(511670)
addappid(511671, 1, "b2bbcee5cbac1f3c4f265976c1111096e1e97581dd4d834223e4fbd580926b7f")
