-- Lua provided by RyzenAPI
-- Game: addappid(511670)

-- MAIN APPLICATION
addappid(511670)

-- MAIN APP DEPOTS / PACKAGES
addappid(511671, 1, "b2bbcee5cbac1f3c4f265976c1111096e1e97581dd4d834223e4fbd580926b7f")
