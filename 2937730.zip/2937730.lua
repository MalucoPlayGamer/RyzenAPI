-- Lua provided by RyzenAPI
-- Game: CRAST

-- MAIN APPLICATION
addappid(2937730)
-- Game: addappid(2937730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937731, 1, "d3800ad0267745c78c9bd1979b098f06300cd62e6a8b2063d8b3cc5357fa2cd0")
