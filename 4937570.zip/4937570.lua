-- Lua provided by RyzenAPI
-- Game: 猎国沉默专属

-- MAIN APPLICATION
addappid(4937570)

