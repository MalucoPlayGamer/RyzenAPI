-- Lua provided by RyzenAPI
-- Game: GIANTESS PLAYGROUND

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1536790, 1, "be05856934cbbd77f1663b4d2a3d9acb45024b462f5c5820e06e86e575886dec") -- GIANTESS PLAYGROUND
addappid(1536791, 1, "d4dab14b7446b3eb1c13333501a77d290f43d6fdce4f7ba44aff5944c495c802") -- Depot 1536791

