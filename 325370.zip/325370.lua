-- Lua provided by RyzenAPI
-- Game: AppID 325370

-- MAIN APPLICATION
addappid(325370)
addappid(393400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(325371, 1, "5bfa43e89a282837c9442d2c9da98cdb869f5385057bd3e1ae31ec89496a5ded")
addappid(325372, 1, "ff782ff6728c83e581d17eabbcfceb93d38e2e1db848dcc5e1bbfd845ee03559")

