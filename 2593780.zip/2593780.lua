-- Lua provided by RyzenAPI
-- Game: addappid(2593780)

-- MAIN APPLICATION
addappid(2593780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593781, 1, "561f28705ceb23feca9e7670c5e8c0d32f2414c1f965e0cbef4223cf3648ea45")
