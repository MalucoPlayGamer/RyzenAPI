-- Lua provided by RyzenAPI
-- Game: Game: Fraudulent Idols Demo

-- MAIN APPLICATION
addappid(2722720)
-- Game: addappid(2722720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722721, 1, "50c8907fd70e8dbb9329bebee668796f8fab04687343e28956fd39314022a1bf")
