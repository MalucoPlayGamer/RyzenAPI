-- Lua provided by RyzenAPI
-- Game: Game: HF: Probation

-- MAIN APPLICATION
addappid(2430740)
-- Game: addappid(2430740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430741, 1, "20d2d8b5fc73941c519ed3036db3ff9823a1d858d4d81f0681e6a653c6383cff")
