-- Lua provided by RyzenAPI
-- Game: ENDLESS Space™ - Definitive Edition

-- MAIN APPLICATION
addappid(208140)
addappid(208151)
addappid(208152)
addappid(208153)
addappid(208154)
addappid(208155)
addappid(208156)
addappid(208157)
addappid(208158)
addappid(208159)

-- MAIN APP DEPOTS / PACKAGES
addappid(208141, 1, "ab8b58d948cf362ec58513eb932766c6fda4f17542764ad86429ef0b14aa4b36")
addappid(208144, 1, "88f43334b48b2b7a60e358bd047e645888b30011ff649948699b5e40f71a6fc4")
addappid(208148, 1, "ad547d7ebc48b39605358f775d1dd50bb6e7af4517ab956782e6466f366c93e0")
addappid(208149, 1, "fdba7eada69649e69bc37c48ecff69b105fe3da3715f329ce71b7e153958b262")
addappid(241430, 0, "fb80034bd75fb5b28a6f9540650132f379722790f6fb6397de226374fef43d28")

