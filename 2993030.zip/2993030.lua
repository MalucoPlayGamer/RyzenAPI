-- Lua provided by RyzenAPI
-- Game: Pantless Demo

-- MAIN APPLICATION
addappid(2993030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993031, 1, "1e12903651a77e2eec329b1d4ccf1ac2b94bd62d5d04543d574581239538b5ad")

