-- Lua provided by RyzenAPI
-- Game: Blood Bowl: Death Zone

-- MAIN APPLICATION
addappid(602490)

-- MAIN APP DEPOTS / PACKAGES
addappid(602491, 1, "9b689d6d349326091b20289785a6b4b0346d8b6f5a619e5d8c8071cd51c7a114")

