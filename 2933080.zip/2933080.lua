-- Lua provided by SkyAPI 
-- Game: Crime Boss: Rockay City
addappid(2933080)
addappid(2933081, 1, "c19e67580e16bb198a0208353b4ae25e66eee4cb16421cc24f593925c2cd41ec")
addappid(2933083, 1, "33064194c736b017c0d6d0a4b5c01816f9f5153631464c677b5dd445ff27e374")
