-- Lua provided by RyzenAPI
-- Game: Crime Boss: Rockay City

-- MAIN APPLICATION
addappid(2933080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933081, 1, "c19e67580e16bb198a0208353b4ae25e66eee4cb16421cc24f593925c2cd41ec")
addappid(2933083, 1, "33064194c736b017c0d6d0a4b5c01816f9f5153631464c677b5dd445ff27e374")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2934440)
addappid(2934450)
addappid(2934460)
addappid(2939860)
addappid(3115300)
addappid(3245230)
addappid(3337580)
addappid(3634240)
addappid(3787350)
addappid(3916000)
addappid(4053730)
addappid(4391860)
