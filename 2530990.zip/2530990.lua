-- Lua provided by SkyAPI 
-- Game: Solitaire Quest: Garden Story
addappid(2530990)
addappid(2530991, 1, "326633462bc5de518cb19b7e96668322788e2582eee9c2ec798da9e30b0084d1")
