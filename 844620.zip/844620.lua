-- Lua provided by RyzenAPI
-- Game: Odyssee

-- MAIN APPLICATION
addappid(844620)

-- MAIN APP DEPOTS / PACKAGES
addappid(844621,0,"3dbca8a5b986d6a3f8d6f1006cb9106c2c0aca935cf373ac0717b389fb153119")

