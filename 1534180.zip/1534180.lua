-- Lua provided by RyzenAPI
-- Game: Super Woden GP

-- MAIN APPLICATION
addappid(1534180)
-- Game: addappid(1534180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534181, 1, "9cfcf45923bfa5c24c13abc19d6e912501ec542f9d75b96e2f71cdac65832060")
addappid(1534182, 1, "c76d882991521305b252aa7b068a9f0f8afb13512e82e911b022e5c4b1490bf0")
