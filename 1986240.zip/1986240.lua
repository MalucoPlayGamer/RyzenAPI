-- Lua provided by RyzenAPI
-- Game: addappid(1986240)

-- MAIN APPLICATION
addappid(1986240)
addappid(1991030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986241, 1, "f8234d905edf0fe4530dcf216584e326f218694a3c66f0f222f75cf16cd9c067")
