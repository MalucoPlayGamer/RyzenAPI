-- Lua provided by RyzenAPI
-- Game: 985600

-- MAIN APPLICATION
addappid(985600)
addappid(985601)
addappid(985603)
addappid(985604)

-- MAIN APP DEPOTS / PACKAGES
addappid(985602,0,"0ef9f2bd798c5c4262678c0f2ba69d2bfc0533a878a8b1741b8b888961d284c2")
