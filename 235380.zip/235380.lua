-- Lua provided by RyzenAPI
-- Game: Blitzkrieg 3

-- MAIN APPLICATION
addappid(228983)
addappid(228990)
addappid(235380)
addappid(235381)
addappid(235382)
addappid(235383)
addappid(235384)
addappid(235385)
addappid(235386)
addappid(235387)
addappid(235388)

-- MAIN APP DEPOTS / PACKAGES
addappid(235392,0,"03ab03fbd7ffdda24aeaffbd71b4fb5644cef7b16dd7ee593b9b62dc98656e4e")
