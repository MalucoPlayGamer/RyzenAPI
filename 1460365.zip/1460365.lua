-- Lua provided by RyzenAPI
-- Game: addappid(1460365)

-- MAIN APPLICATION
addappid(1460365)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460365,0,"906ecf417ed866d7ee0be94cc06aef853b9605fcef5dc57439b6676623f5ef4f")
