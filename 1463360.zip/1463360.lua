-- Lua provided by RyzenAPI
-- Game: Eugene's Dream: The Daily Ins And Outs Of A Sane Robot In An Insane World

-- MAIN APPLICATION
addappid(1463360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463361, 1, "386d068c16a4fb4d7af0ee37db35e6c5ccf0b0e49171b089090bd3b14dbc3db8")
