-- Lua provided by RyzenAPI
-- Game: Eugene's Dream: The Daily Ins And Outs Of A Sane Robot In An Insane World

-- MAIN APPLICATION
addappid(1463360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463361, 1, "386d068c16a4fb4d7af0ee37db35e6c5ccf0b0e49171b089090bd3b14dbc3db8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
