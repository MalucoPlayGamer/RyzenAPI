-- Lua provided by RyzenAPI
-- Game: Cook with Card

-- MAIN APPLICATION
addappid(4597500) -- Cook with Card

-- MAIN APP DEPOTS / PACKAGES
addappid(4597501, 1, "f2a468aaf696a91d5796164835cf865189b623bdf9c41a1f9d62f6eb55767c97") -- Depot 4597501

