-- 4597500's Lua and Manifest Created by Hubcap Manifest
-- Cook with Card
-- Created: August 19, 2026 at 15:52:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4597500) -- Cook with Card
-- MAIN APP DEPOTS
addappid(4597501, 1, "f2a468aaf696a91d5796164835cf865189b623bdf9c41a1f9d62f6eb55767c97") -- Depot 4597501
setManifestid(4597501, "2378448817263658286", 325327889)