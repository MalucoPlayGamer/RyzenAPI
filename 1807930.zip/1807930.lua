-- Lua provided by RyzenAPI
-- Game: Railway Islands - Puzzle

-- MAIN APPLICATION
addappid(1807930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807931, 1, "bfc0a245f4ec9e140324453539e1d2d68af0284bedfde9a09c5c8d8523bb6a54")
