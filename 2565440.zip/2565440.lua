-- Lua provided by RyzenAPI 
-- Game: The Princess's Dragon
addappid(2565440)
addappid(2565441, 1, "b3ee5a86e78a3f38b542694f7c50f8ef305576d72fa2b605df03f2e22476a0fb")
