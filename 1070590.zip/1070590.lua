-- Lua provided by RyzenAPI
-- Game: Butterfly 2

-- MAIN APPLICATION
addappid(1070590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070591, 1, "8dc4e8f83b9623aeb091450f36182c371dcd8b20cf05e9d70f7da15696a1dd83")
