-- Lua provided by RyzenAPI
-- Game: Last Days of Lazarus

-- MAIN APPLICATION
addappid(1359920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359921, 1, "2af9accf61da340be286b35cb3e7c516b59e34490166c7da2f6d3b4756a2cdce")

