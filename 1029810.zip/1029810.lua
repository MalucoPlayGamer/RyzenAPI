-- Lua provided by RyzenAPI
-- Game: 1029810

-- MAIN APPLICATION
addappid(1029810)
-- Game: addappid(1029810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029811, 1, "599fc0f1ebf63dd7347f15884e666f187070bf5e8d7038f9bfe46f9a84b25fc2")
