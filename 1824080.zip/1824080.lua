-- Lua provided by RyzenAPI
-- Game: LUL inc.

-- MAIN APPLICATION
addappid(1824080)
-- Game: addappid(1824080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824081, 1, "50ab8e509259cc41a1c42fda35bbf4f9f3f52d7605ce0779baebb1bb98dd55ef")
