-- Lua provided by RyzenAPI
-- Game: addappid(1034280)

-- MAIN APPLICATION
addappid(1034280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034281, 1, "1bff69dca3568ab528b447686a581dd7a31911774fb06c95df6641eddb56b1b6")
addappid(1034282, 1, "28cd89c2f0cd65da17eede917429566738c891caf99dd2126af3d4a61fcfa6fa")
