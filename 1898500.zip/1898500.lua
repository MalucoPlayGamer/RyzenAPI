-- Lua provided by RyzenAPI 
-- Game: Worldless
addappid(1898500)
addappid(1898501, 1, "2773c100a041e83acecce199c751e8a758703410e43a712842eab67a270966ec")
