-- Lua provided by RyzenAPI
-- Game: Game: Worldless

-- MAIN APPLICATION
addappid(1898500)
-- Game: addappid(1898500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898501, 1, "2773c100a041e83acecce199c751e8a758703410e43a712842eab67a270966ec")
