-- Lua provided by RyzenAPI
-- Game: Mi Mi Mi

-- MAIN APPLICATION
addappid(1097810)
-- Game: addappid(1097810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097811, 1, "d734ae317f90bbef6fba72ce2e90a4673ba914a4109737c8cbe74da9b842bd15")
