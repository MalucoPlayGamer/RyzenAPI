-- Lua provided by RyzenAPI
-- Game: Brick Breaker Premium

-- MAIN APPLICATION
addappid(874780)

-- MAIN APP DEPOTS / PACKAGES
addappid(874781, 1, "8266a78abe40b3d46f6fe602ae07ea8904453d0c47631de1d803dc59fd6de347")
