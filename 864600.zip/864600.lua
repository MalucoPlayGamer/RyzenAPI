-- Lua provided by RyzenAPI
-- Game: Jade's Dungeon Descent

-- MAIN APPLICATION
addappid(864600)

-- MAIN APP DEPOTS / PACKAGES
addappid(864601, 1, "88f82b5e25ce335a04483dfec1aeb0e0a2de2e4e117e4b2943b0597e19aad39d")
