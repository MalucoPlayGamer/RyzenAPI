-- Lua provided by RyzenAPI
-- Game: Game: Delivery Man

-- MAIN APPLICATION
addappid(2181440)
-- Game: addappid(2181440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181441, 1, "7d8cbb11c608bc6db58e76b2b7adee64054bc7ef4225458d02f6d1c63d3538dc")
