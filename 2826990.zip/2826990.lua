-- Lua provided by SkyAPI 
-- Game: Imperiums: Greek Wars Demo
addappid(2826990)
addappid(2826991, 1, "df65ca1dbd0747c3c298631bf2a06d0836a9b537767d70689b35860b13cd5008")
