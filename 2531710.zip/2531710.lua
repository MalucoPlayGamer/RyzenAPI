-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Winlu Fantasy Tileset - Overworld

-- MAIN APPLICATION
addappid(2531710)
-- Game: addappid(2531710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531710,0,"8223b4a73a39acaa20dd218df3b80c2e54aa8219dcdbd4ecf4ce4d0b64030fc1")
