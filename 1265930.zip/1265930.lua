-- Lua provided by RyzenAPI
-- Game: Life is Strange: Before the Storm Remastered

-- MAIN APPLICATION
addappid(1265930)
addappid(1537870)
-- Game: addappid(1265930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265931, 1, "f03554a039cea967647878f3e6215ee9fe74c906f4a8d5d088201c36534cb435")
