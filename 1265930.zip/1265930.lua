-- Lua provided by RyzenAPI
-- Game: Life is Strange: Before the Storm Remastered

-- MAIN APPLICATION
addappid(1265930)
addappid(1537870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1265931, 1, "f03554a039cea967647878f3e6215ee9fe74c906f4a8d5d088201c36534cb435")

