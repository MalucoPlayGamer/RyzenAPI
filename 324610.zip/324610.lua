-- Lua provided by RyzenAPI
-- Game: addappid(324610)

-- MAIN APPLICATION
addappid(324610)

-- MAIN APP DEPOTS / PACKAGES
addappid(324612,0,"f961eaedb8b663ec55c82cf9e89368fa5a061bce07e74750ee8700ff5700df3c")
