-- Lua provided by RyzenAPI
-- Game: 007 First Light

-- MAIN APPLICATION
addappid(3768760)
addappid(3950810)
addappid(3950820)
addappid(3950830)
addappid(3950850)
addappid(3950870)
addappid(3950880)
addappid(3950900)
addappid(3950910)
addappid(3950930)
addappid(3954230)
addappid(3954250)
addappid(3954260)
addappid(3986520)
addappid(4521800)
addappid(4521810)
addappid(4521820)
addappid(4521830)
addappid(4521840)
addappid(4601250)
addappid(4626160)
addappid(4707780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3768761, 1, "8284c5e8921ec5acbe53f4d45af0260905841dc698ca179dd218ce5a2657ef09")
