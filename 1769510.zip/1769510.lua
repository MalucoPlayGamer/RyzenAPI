-- Lua provided by SkyAPI 
-- Game: FEWAR-DVD
addappid(1769510)
addappid(1769511, 1, "d4965eb98072c73848646aab45e700bf4190c659eca2dbd1dad792d7b033617e")
