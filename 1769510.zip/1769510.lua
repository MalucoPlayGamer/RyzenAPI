-- Lua provided by RyzenAPI
-- Game: FEWAR-DVD

-- MAIN APPLICATION
addappid(1769510)
-- Game: addappid(1769510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769511, 1, "d4965eb98072c73848646aab45e700bf4190c659eca2dbd1dad792d7b033617e")
