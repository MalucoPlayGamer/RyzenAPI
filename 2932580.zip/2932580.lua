-- Lua provided by RyzenAPI
-- Game: addappid(2932580)

-- MAIN APPLICATION
addappid(2932580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932581, 1, "5d4a21bda1f215ee733d19845b1766dd05de4159ca093f8954be6f8dc9024c72")
