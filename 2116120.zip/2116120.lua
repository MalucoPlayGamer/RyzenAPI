-- Lua provided by RyzenAPI
-- Game: Incursion Red River

-- MAIN APPLICATION
addappid(2116120)
addappid(3405150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116121, 1, "8f80a1590d1be6bfdde9c800499b420fe786838c27c69a6572bbb75c85c48007")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
