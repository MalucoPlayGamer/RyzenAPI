-- Lua provided by RyzenAPI
-- Game: Incursion Red River

-- MAIN APPLICATION
addappid(2116120)
addappid(3405150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116121, 1, "8f80a1590d1be6bfdde9c800499b420fe786838c27c69a6572bbb75c85c48007")

