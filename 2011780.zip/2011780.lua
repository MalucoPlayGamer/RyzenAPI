-- Lua provided by RyzenAPI
-- Game: addappid(2011780)

-- MAIN APPLICATION
addappid(2011780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011781, 1, "59ca22e3b50eb4c846ab685754ef4f27537c0f03a9ec37cacdad4d870339d8eb")
