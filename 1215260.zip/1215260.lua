-- Lua provided by RyzenAPI
-- Game: addappid(1215260)

-- MAIN APPLICATION
addappid(1215260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215261, 1, "cf71bb0b320773dd4259d780e80a504bd87295513fe94da6a91f035a4e16688d")
addappid(1234740, 0, "2034faa8c32ba5563fcbac31d0ea0240dae4dbeebb1fa6c060d4e8a4749d7ddf")
