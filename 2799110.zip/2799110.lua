-- Lua provided by RyzenAPI
-- Game: Game: QUICKERFLAK 2

-- MAIN APPLICATION
addappid(2799110)
-- Game: addappid(2799110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799111, 1, "09169aa51a67b253bdf527ba44320c85b3a5762ebaf1689b7a0e0ba887072dfc")
