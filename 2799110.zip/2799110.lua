-- Lua provided by RyzenAPI
-- Game: QUICKERFLAK 2

-- MAIN APPLICATION
addappid(2799110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2799111, 1, "09169aa51a67b253bdf527ba44320c85b3a5762ebaf1689b7a0e0ba887072dfc")

