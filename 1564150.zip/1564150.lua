-- Lua provided by RyzenAPI
-- Game: Game: Lost in Blindness

-- MAIN APPLICATION
addappid(1564150)
-- Game: addappid(1564150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564151, 1, "c25d108b222697eb0ca6632d0344c3885e3ed442889ff139b5beb76dc2e914a2")
