-- Lua provided by RyzenAPI
-- Game: addappid(2564880)

-- MAIN APPLICATION
addappid(2564880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564881, 1, "1396665f5a7948ec042bdaad63e0ff9018df6e666253e452d57353cdbf01d4f5")
