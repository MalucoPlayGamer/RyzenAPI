-- Lua provided by RyzenAPI
-- Game: 远征契约

-- MAIN APPLICATION
addappid(2050560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050561, 1, "e9b2b0b38eccecd36b134b398739d8f401a0d406870ee01b91749e595a2058fe")
