-- Lua provided by RyzenAPI
-- Game: 2358300

-- MAIN APPLICATION
addappid(2358300)
-- Game: addappid(2358300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358301, 1, "6890f1a6a2e70df3c29b3f3ef235fe01536fa042781bb2049cd1b04e82261f3f")
