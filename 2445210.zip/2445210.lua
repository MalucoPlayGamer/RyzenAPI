-- Lua provided by SkyAPI 
-- Game: Imaginary girl -Prequel-
addappid(2445210)
addappid(2445211, 1, "c5b968e9bf1a9b9738ec92d2c8f014796901e609cb6a6eea8d725d3465dd069e")
