-- Lua provided by RyzenAPI
-- Game: Imaginary girl -Prequel-

-- MAIN APPLICATION
addappid(2445210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445211, 1, "c5b968e9bf1a9b9738ec92d2c8f014796901e609cb6a6eea8d725d3465dd069e")
