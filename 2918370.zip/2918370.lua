-- Lua provided by RyzenAPI
-- Game: Delta Force - Black Hawk Down

-- MAIN APPLICATION
addappid(2918370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918372,0,"3fedb72202be223251d2273e7dd1f4a98bd1feb84bcd0043de3fd6a95bbc0e11")

