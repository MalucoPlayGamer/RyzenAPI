-- Lua provided by RyzenAPI
-- Game: Holiday Jigsaw Thanksgiving Day 2

-- MAIN APPLICATION
addappid(1716260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716264,0,"c2ec811789ea08990016c607b2906177e92d09b57982cac5367a2db3d93d767b")

