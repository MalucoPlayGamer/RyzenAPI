-- Lua provided by RyzenAPI
-- Game: Welkin Road

-- MAIN APPLICATION
addappid(432720)
-- Game: addappid(432720)

-- MAIN APP DEPOTS / PACKAGES
addappid(432721, 1, "54eb81082e70b6dc40ad82181612c7070487b7282473e93491ba42bedcbe67ec")
addappid(432724, 1, "8b4c61eceeb346679c008f62120879a9e4c6e03fc00297a377633c0c4d472dfc")
