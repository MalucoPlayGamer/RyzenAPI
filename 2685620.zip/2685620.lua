-- Lua provided by RyzenAPI
-- Game: 反转21克

-- MAIN APPLICATION
addappid(2685620)
addappid(2827800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685621, 1, "11c2d2f63d5e79fe1cb20cb12a1e1c2dbb79b96039a6cf3a4790f18ed24715dd")

