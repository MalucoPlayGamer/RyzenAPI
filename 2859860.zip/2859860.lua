-- Lua provided by RyzenAPI
-- Game: Veloria

-- MAIN APPLICATION
addappid(2859860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859863,0,"dbdf11de9e490280e6d377345bc39a5f5bfcd69237235e3123708f4d3bebf2f5")

