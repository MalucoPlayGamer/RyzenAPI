-- Lua provided by RyzenAPI
-- Game: addappid(1077430)

-- MAIN APPLICATION
addappid(1077430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077431, 1, "b481d2f97d2d4e9538f838dd3bb1dc9adb604bc69bad953e382ccc19f69b36c5")
