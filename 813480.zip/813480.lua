-- Lua provided by RyzenAPI
-- Game: addappid(813480)

-- MAIN APPLICATION
addappid(813480)

-- MAIN APP DEPOTS / PACKAGES
addappid(813481, 1, "7fb5787dd9051bfd826685b7fc12325503758c84c7f52209c95621eded9ceb9c")
