-- Lua provided by RyzenAPI
-- Game: Elara: A Coding Adventure in Space

-- MAIN APPLICATION
addappid(2657610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657612,0,"2868bb9ffc433f34da2d054b6a37d00bf457e2e485a7a49db1e10e1c44f98365")

