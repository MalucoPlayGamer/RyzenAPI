-- Lua provided by RyzenAPI
-- Game: Forest Journeys

-- MAIN APPLICATION
addappid(2874330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2874331, 1, "ac04733f0e230e1c542fc066032a9cd3a748ea951f438b89df1e34ce4e3b48c9")

