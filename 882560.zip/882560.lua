-- Lua provided by RyzenAPI
-- Game: Game: AppID 882560

-- MAIN APPLICATION
addappid(882560)
-- Game: addappid(882560)

-- MAIN APP DEPOTS / PACKAGES
addappid(882561, 1, "f2b09a3d18f5ab2c356eeb37e610d60e6f0e604074e71465abcbd238d12d6217")
