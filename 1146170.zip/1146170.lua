-- Lua provided by RyzenAPI
-- Game: addappid(1146170)

-- MAIN APPLICATION
addappid(1146170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146171, 1, "664ae775396e829b00ea67d0330e361a4c389ae3d3e6df892646a53c26d800dd")
