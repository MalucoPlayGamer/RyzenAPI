-- Lua provided by RyzenAPI
-- Game: 854680

-- MAIN APPLICATION
addappid(854680)
-- Game: addappid(854680)

-- MAIN APP DEPOTS / PACKAGES
addappid(854681, 1, "91b1ac691f42a6e601a8273af9a48b912064b001d845ac2469d6ccf8b5b85216")
