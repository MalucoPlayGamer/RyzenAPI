-- Lua provided by RyzenAPI
-- Game: AppID 854680

-- MAIN APPLICATION
addappid(854680)

-- MAIN APP DEPOTS / PACKAGES
addappid(854681, 1, "91b1ac691f42a6e601a8273af9a48b912064b001d845ac2469d6ccf8b5b85216")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
