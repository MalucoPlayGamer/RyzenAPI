-- Lua provided by RyzenAPI
-- Game: Autocraft

-- MAIN APPLICATION
addappid(2588500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588501, 1, "89c6e5183cf13ed7947fe1626ea142c3e85b74799d8d8acff0fa761218b2b24e")
