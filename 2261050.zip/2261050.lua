-- Lua provided by SkyAPI 
-- Game: For the Queen
addappid(2261050)
addappid(2261051, 1, "a1535ad514a50c3d97428c97bccc22c05317da6c05238b2ed88bb045a236789b")
