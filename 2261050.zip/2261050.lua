-- Lua provided by RyzenAPI
-- Game: For the Queen

-- MAIN APPLICATION
addappid(2261050)
addappid(2478570)
addappid(2773510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261051, 1, "a1535ad514a50c3d97428c97bccc22c05317da6c05238b2ed88bb045a236789b")

