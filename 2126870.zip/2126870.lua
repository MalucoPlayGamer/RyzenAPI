-- Lua provided by RyzenAPI
-- Game: HimeYoku: A Sacrifice of Lust and Grace

-- MAIN APPLICATION
addappid(2126870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2126871, 1, "344475aadb6d3514daa4041ee4af540edc8ec98e261e4814f1018dedbb1633da")
addappid(2126872, 1, "b1bf928faea7e8738bc50500ee23f305752b2dbcef29fd6fcc800baedf3c16e2")

