-- Lua provided by RyzenAPI
-- Game: The Binding of Isaac: Repentance

-- MAIN APPLICATION
addappid(1426300)

-- MAIN APP DEPOTS / PACKAGES
addappid(250911,0,"91f532dc0f4bd27b98705c41e9c5b1171df5c8254c92409b9faf40bbe8708639")
