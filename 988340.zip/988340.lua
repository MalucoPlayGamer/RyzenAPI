-- Lua provided by RyzenAPI
-- Game: Mad Hunting Simulator VR

-- MAIN APPLICATION
addappid(988340)

-- MAIN APP DEPOTS / PACKAGES
addappid(988341, 1, "8e28098e1b08e4201afffa92937d4841c9e3d4f361a21deaf010844ac5c4ca41")

