-- Lua provided by RyzenAPI
-- Game: addappid(2241590)

-- MAIN APPLICATION
addappid(2241590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241592,0,"362dcf3ae7d7fc30844c214dea6e7458bd33d83021ce9582ad7498c7231f718b")
