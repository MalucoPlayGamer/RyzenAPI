-- Lua provided by RyzenAPI
-- Game: Crafty Survivors

-- MAIN APPLICATION
addappid(2137760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137761, 1, "573e82875fce23d4f27f3e5d1b4e125b9520114551a9b17d930b43ae297b25d4")
addappid(2137762, 1, "72fa96f973f2d1e53bff3647e9f35ff4ae096e9f5663f58d36b69cfef575f891")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4888850)
