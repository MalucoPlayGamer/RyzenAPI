-- Lua provided by RyzenAPI
-- Game: Bro Falls

-- MAIN APPLICATION
addappid(1590320)

