-- Lua provided by RyzenAPI
-- Game: Beat Saber - Marshmello - Alone

-- MAIN APPLICATION
addappid(1967800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967800,0,"5581bc362e2d6f3000fccc983e242a6fbcf0dca62f6fc3908f1f11e7f2c6f780")

