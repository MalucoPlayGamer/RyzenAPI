-- Lua provided by RyzenAPI
-- Game: 2818980

-- MAIN APPLICATION
addappid(2818980)
-- Game: addappid(2818980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818981, 1, "b4caf63d87a69cb4c2a0250aabc83b5f835b8d6c1e773196c57b021bbc10419c")
