-- Lua provided by RyzenAPI
-- Game: 3402030

-- MAIN APPLICATION
addappid(3402030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402030,0,"d9e83eaaef71cf6077d7a4c75fba20c02bfe88871e815dc48730eafd1f04c443")
