-- Lua provided by RyzenAPI
-- Game: AppID 872600

-- MAIN APPLICATION
addappid(872600)

-- MAIN APP DEPOTS / PACKAGES
addappid(872601, 1, "578866cb8792e7f8b3019dc890de4caaaf0bbe89a2c2a0f8df34a20eaa101160")

