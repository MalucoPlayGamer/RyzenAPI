-- Lua provided by RyzenAPI
-- Game: My Corp Cargo Simulator

-- MAIN APPLICATION
addappid(2757600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757601, 1, "ac5bd897a8f31229a529a0cf386fe74564bc9eb89415c4b3961e7a598335d5fa")

