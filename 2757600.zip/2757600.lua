-- Lua provided by SkyAPI 
-- Game: My Corp Cargo Simulator
addappid(2757600)
addappid(2757601, 1, "ac5bd897a8f31229a529a0cf386fe74564bc9eb89415c4b3961e7a598335d5fa")
