-- Lua provided by RyzenAPI
-- Game: Stalingrad

-- MAIN APPLICATION
addappid(356260)

-- MAIN APP DEPOTS / PACKAGES
addappid(356261, 1, "209502d911d5c1cf4e32e91226635da9359bdd0623b4ddb42c8021ab517ea2e8")
addappid(356262, 1, "1869c867b5157161f651434d50a2090ea0f6b9a6192151abe9ffd2d664e75ada")
addappid(356263, 1, "df83aa051f15e1c58d6a7fc6bb752e68d6eead48b4fe0bbbd730d29f8dc96c95")
addappid(356264, 1, "c1814106a9fa63589eb95c89b1e4fa096c0a31f6d21f70593a100521b3be4efb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
