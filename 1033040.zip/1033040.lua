-- Lua provided by RyzenAPI
-- Game: addappid(1033040)

-- MAIN APPLICATION
addappid(1033040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033041, 1, "d77a8fd0d23d6c154d13fb6f29f24f8aa769157c1c54b38a5640cc2c58e63d44")
