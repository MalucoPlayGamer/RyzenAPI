-- Lua provided by RyzenAPI
-- Game: 918870

-- MAIN APPLICATION
addappid(918870)
-- Game: addappid(918870)

-- MAIN APP DEPOTS / PACKAGES
addappid(918871, 1, "ba739fd5c439c2ce9d825a4193970360985b8adf9ede8f69cb563a58f44301d3")
