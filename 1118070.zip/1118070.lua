-- Lua provided by RyzenAPI
-- Game: Game: 1976 - Back to midway

-- MAIN APPLICATION
addappid(1118070)
-- Game: addappid(1118070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118071, 1, "e0e960c5a870e75cedfbb16ff53ab8463f0583444b708d86e9812121e2db53f7")
