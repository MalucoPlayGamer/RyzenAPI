-- Lua provided by RyzenAPI
-- Game: House of Legacy

-- MAIN APPLICATION
addappid(2503770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503771, 1, "13bc89e933d261de7af8bc6b3535e664a82327d9c80adeadbdc74f485d4c939f")
