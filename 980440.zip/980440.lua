-- Lua provided by RyzenAPI
-- Game: setManifestid(980442,"4344428796641379467")

-- MAIN APPLICATION
addappid(980440)

-- MAIN APP DEPOTS / PACKAGES
addappid(980442,0,"ec376ab78313b4aca3699ca693530e3b44aceab521462c32a2c720a2ddf9fdc6")

