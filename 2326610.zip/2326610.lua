-- Lua provided by RyzenAPI
-- Game: 2326610

-- MAIN APPLICATION
addappid(2326610)
-- Game: addappid(2326610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326611, 1, "50852fbb435fd534da411751580d79c3a946db5a3b95bceb637f68995b5a17c0")
