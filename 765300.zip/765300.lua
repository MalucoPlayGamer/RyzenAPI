-- Lua provided by RyzenAPI
-- Game: AppID 765300

-- MAIN APPLICATION
addappid(765300)
-- Game: addappid(765300)

-- MAIN APP DEPOTS / PACKAGES
addappid(765301, 1, "8221776b53b10fe3940f8e4a0f6b30590749d46f64e8dcc7536d861faef21194")
