-- Lua provided by RyzenAPI
-- Game: NiGHTS Into Dreams

-- MAIN APPLICATION
addappid(219950)
-- Game: addappid(219950)

-- MAIN APP DEPOTS / PACKAGES
addappid(219951, 1, "c0fd424e8a1a95a16118e829b811263cb79a8f66510826fedba3eadab9cf6daa")
