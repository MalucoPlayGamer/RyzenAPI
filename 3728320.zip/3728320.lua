-- Lua provided by RyzenAPI
-- Game: 3728320

-- MAIN APPLICATION
addappid(3728320)
-- Game: addappid(3728320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3728320,0,"6efd49cc3608ae57bc6d0b2e1c1f790c0b6febd6bd548587d1314e7c1acf35ef")
