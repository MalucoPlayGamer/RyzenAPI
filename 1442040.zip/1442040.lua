-- Lua provided by RyzenAPI
-- Game: 1442040

-- MAIN APPLICATION
addappid(1442040)
-- Game: addappid(1442040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442041, 1, "1bb513b2fca7808abe1c14c5287c80094102006aed63bfbe11f61a293986b056")
