-- Lua provided by RyzenAPI
-- Game: 我反对这门亲事-I'm against this marriage

-- MAIN APPLICATION
addappid(1442040)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1442041, 1, "1bb513b2fca7808abe1c14c5287c80094102006aed63bfbe11f61a293986b056")

