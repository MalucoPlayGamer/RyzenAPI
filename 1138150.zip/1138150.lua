-- Lua provided by RyzenAPI
-- Game: Fiery catacombs

-- MAIN APPLICATION
addappid(1138150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138151, 1, "e31b181b6a601722c7a9e4f850e1ada993ceec0b9f20d9af906333cdef04104e")

