-- Lua provided by RyzenAPI
-- Game: Fragmented City Demo

-- MAIN APPLICATION
addappid(2804540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804542,0,"40356a8f76a4824fc525712b2bd90c06500c87daf94499d9009945356b03e46e")

