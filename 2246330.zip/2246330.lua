-- Lua provided by RyzenAPI
-- Game: Rescue Team: Magnetic Storm

-- MAIN APPLICATION
addappid(2246330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246331, 1, "e1c28a726cb74f63ccca23ab4003a6a2e9a7d15e1ccf192559b5f1a71a5bf241")
