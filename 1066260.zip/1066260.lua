-- Lua provided by RyzenAPI
-- Game: AppID 1066260

-- MAIN APPLICATION
addappid(1066260)
-- Game: addappid(1066260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066261, 1, "ecc2dc3f30b00389a87fd43852ca1f849e6f553ed60df3fdb64f133b772ee84b")
