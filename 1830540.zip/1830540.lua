-- Lua provided by RyzenAPI
-- Game: Rallyallyally

-- MAIN APPLICATION
addappid(1830540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830542,0,"984dc2ba3d548c6ca6ee22ae6cbe88c8e7561912785d54e89996e53881d331b7")
