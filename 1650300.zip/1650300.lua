-- Lua provided by RyzenAPI 
-- Game: AppID 1650300
addappid(1650300)
addappid(1650301, 1, "7c791c6564159c4996660468d52e27e86d70a97b09f0b3e6aa48aff85e25a0e0")
