-- Lua provided by RyzenAPI
-- Game: Re:Night

-- MAIN APPLICATION
addappid(2372240) -- Re:Night

-- MAIN APP DEPOTS / PACKAGES
addappid(2372241, 1, "08e334429e91873e453f8aa49f240178f9359f9bb908c8d449dfaecee88e46a3") -- Depot 2372241
addtoken(2372240, "5828466134870491288")

