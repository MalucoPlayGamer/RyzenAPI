-- 2372240's Lua and Manifest Created by Hubcap Manifest
-- Re:Night
-- Created: August 05, 2026 at 09:27:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2372240) -- Re:Night
addtoken(2372240, "5828466134870491288")
-- MAIN APP DEPOTS
addappid(2372241, 1, "08e334429e91873e453f8aa49f240178f9359f9bb908c8d449dfaecee88e46a3") -- Depot 2372241
setManifestid(2372241, "2219501534044064009", 3625636557)