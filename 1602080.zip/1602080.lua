-- Lua provided by RyzenAPI 
-- Game: Soulstice
addappid(1602080)
addappid(1602081, 1, "0ef50763f874a2a88253fb66ba50b92cdb0b0a78871ec332d3ee2ad98943e6e0")
addappid(2101860, 0, "04be9c575d301dc1606fe8e7a1c44cf98e43711c8b7e326ef00271e48e55cc44")
addappid(2110210)
