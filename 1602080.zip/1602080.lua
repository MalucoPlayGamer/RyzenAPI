-- Lua provided by RyzenAPI
-- Game: Soulstice

-- MAIN APPLICATION
addappid(1602080)
addappid(2110210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602081, 1, "0ef50763f874a2a88253fb66ba50b92cdb0b0a78871ec332d3ee2ad98943e6e0")
addappid(2101860, 0, "04be9c575d301dc1606fe8e7a1c44cf98e43711c8b7e326ef00271e48e55cc44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
