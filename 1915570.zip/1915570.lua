-- Lua provided by RyzenAPI 
-- Game: AppID 1915570
addappid(1915570)
addappid(1915571, 1, "7ee8668cdfe9e2101be2a2d2a05761637a67d5cece7b8cb61fc406555f4006ba")
