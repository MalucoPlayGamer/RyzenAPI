-- Lua provided by RyzenAPI
-- Game: 1915570

-- MAIN APPLICATION
addappid(1915570)
-- Game: addappid(1915570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915571, 1, "7ee8668cdfe9e2101be2a2d2a05761637a67d5cece7b8cb61fc406555f4006ba")
