-- Lua provided by RyzenAPI
-- Game: AppID 1293250

-- MAIN APPLICATION
addappid(1293250)
-- Game: addappid(1293250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293251, 1, "3b71c6d4c55d614520ab81c3bdeb5372b9195d418bedc2e849fd505574142b0f")
