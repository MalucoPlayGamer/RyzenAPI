-- Lua provided by RyzenAPI 
-- Game: Dominance
addappid(2175780)
addappid(2175781, 1, "6aae846fa6953bfedca3f70ee364ce25a2f4648fb8d74112e938cb311e10f913")
