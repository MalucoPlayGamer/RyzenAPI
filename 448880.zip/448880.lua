-- Lua provided by RyzenAPI
-- Game: AppID 448880

-- MAIN APPLICATION
addappid(448880)
-- Game: addappid(448880)

-- MAIN APP DEPOTS / PACKAGES
addappid(448881, 1, "8a39431422f40df959eae2e9f8a4246916b3aa44962285fab2d05c36fbf3d6bc")
