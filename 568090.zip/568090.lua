-- Lua provided by SkyAPI 
-- Game: Tattletail
addappid(568090)
addappid(568091, 1, "c0e7f3e173a7381a72dd1c23f0eedcdee69e96e1b4b7338432e21da395753bf9")
addappid(568092, 1, "2ed584879518feaab07cfb2a962da0c2027d4ab4ed64d3ea7fea1c6a52dd932c")
