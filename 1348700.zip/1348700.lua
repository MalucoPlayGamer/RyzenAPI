-- Lua provided by RyzenAPI
-- Game: addappid(1348700)

-- MAIN APPLICATION
addappid(1348700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348701, 1, "c0a67d0137017c4b8c6f104fd009ae4a3fbc97c29891fa4939df86c9307bb4bd")
