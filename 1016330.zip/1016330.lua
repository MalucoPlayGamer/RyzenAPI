-- Lua provided by SkyAPI 
-- Game: AppID 1016330
addappid(1016330)
addappid(1016331, 1, "21468017ee869b96a7fcaf576a5fefe2cc2335f9472ea6c802b7af36da326609")
addappid(1016332, 1, "1ccc2e9a89b3a1f93e09e403ff046ada3a4e1679216757ce172c40f3a3004464")
