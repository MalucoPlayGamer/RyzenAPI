-- Lua provided by RyzenAPI
-- Game: 三国模拟器 Three Kingdoms Simulator

-- MAIN APPLICATION
addappid(1374430)
-- Game: addappid(1374430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374432,0,"d7528e236a9d188a8b81205ffd83049e7ddba29e9e7e62be3789adc8fd76ebbb")
