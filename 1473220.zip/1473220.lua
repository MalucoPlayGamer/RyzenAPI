-- Lua provided by RyzenAPI
-- Game: Game: Hundred Chances - The Fortress

-- MAIN APPLICATION
addappid(1473220)
-- Game: addappid(1473220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473221, 1, "21cd0d18fed23b72713dd6bca5685fa8767bf1bf119cc86d2ffcaabd3ff3bac8")
