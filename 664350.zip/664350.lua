-- Lua provided by RyzenAPI
-- Game: German Fortress 3D

-- MAIN APPLICATION
addappid(664350)

-- MAIN APP DEPOTS / PACKAGES
addappid(664351, 1, "0a959d3641a1dd38476abfa83d880bbcc9b0e2d80a13fbe4b56966451533f3c9")

