-- Lua provided by RyzenAPI
-- Game: 2356330

-- MAIN APPLICATION
addappid(2356330)
-- Game: addappid(2356330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356331, 1, "4f50d9351e58eacd19fa6e09a78aee3aee66c81bc9c3509ffdbdb4882b7096bf")
