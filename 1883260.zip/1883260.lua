-- Lua provided by RyzenAPI
-- Game: Little Noah: Scion of Paradise

-- MAIN APPLICATION
addappid(1883260)
addappid(2055110)
addappid(2058630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1883261, 1, "64e96126cefb28a7ab462c8a1c6c894597f99b34dbaa22ef8cf444f0a2d43c8c")

