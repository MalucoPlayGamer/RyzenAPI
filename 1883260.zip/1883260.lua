-- Lua provided by RyzenAPI
-- Game: Little Noah: Scion of Paradise

-- MAIN APPLICATION
addappid(1883260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883261, 1, "64e96126cefb28a7ab462c8a1c6c894597f99b34dbaa22ef8cf444f0a2d43c8c")
