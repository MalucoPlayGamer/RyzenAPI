-- Lua provided by RyzenAPI
-- Game: Sword and Fairy

-- MAIN APPLICATION
addappid(1546570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546571, 1, "cc0f374a05a2b117c2fbc7e75564534df000971871283846490724ac2a7fb893")
addappid(1546572, 1, "a14e97e749760bcc4c2d661f37f6502b8df2d3e4a04c71b7aec0c9663d10dc11")
addappid(1546573, 1, "93885a34c035a0cd626eb93ee9252ba3af3934fd9c379b0e692177a494535320")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
