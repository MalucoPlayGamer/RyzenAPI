-- Lua provided by RyzenAPI
-- Game: Sanae Toumaden X2

-- MAIN APPLICATION
addappid(1741030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741031, 1, "f7a6ca36f20488730b736d654fe9535b1cb70ed9c91666fbdd3f069c7eb70212")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
