-- Lua provided by RyzenAPI
-- Game: Game: Sanae Toumaden X2

-- MAIN APPLICATION
addappid(1741030)
-- Game: addappid(1741030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741031, 1, "f7a6ca36f20488730b736d654fe9535b1cb70ed9c91666fbdd3f069c7eb70212")
