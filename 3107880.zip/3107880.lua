-- Lua provided by RyzenAPI
-- Game: 3107880

-- MAIN APPLICATION
addappid(3107880)
addappid(3371810)
-- Game: addappid(3107880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107881, 1, "fb75c64375925583a146badc1bd5bfcd7ef0a0c3676dbf757a758b0cb1fa22a8")
