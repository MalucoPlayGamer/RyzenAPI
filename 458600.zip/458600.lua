-- Lua provided by RyzenAPI
-- Game: ZRoll

-- MAIN APPLICATION
addappid(458600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(458601, 1, "518077c555dcfac75ca8fd2b24327636ac4eae7095ee9b3c4f532dbda3e52061")

