-- Lua provided by SkyAPI 
-- Game: ZRoll
addappid(458600)
addappid(458601, 1, "518077c555dcfac75ca8fd2b24327636ac4eae7095ee9b3c4f532dbda3e52061")
