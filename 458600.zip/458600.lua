-- Lua provided by RyzenAPI
-- Game: Game: ZRoll

-- MAIN APPLICATION
addappid(458600)
-- Game: addappid(458600)

-- MAIN APP DEPOTS / PACKAGES
addappid(458601, 1, "518077c555dcfac75ca8fd2b24327636ac4eae7095ee9b3c4f532dbda3e52061")
