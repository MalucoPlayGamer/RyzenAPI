-- Lua provided by RyzenAPI
-- Game: Takedown: Red Sabre

-- MAIN APPLICATION
addappid(236510)

-- MAIN APP DEPOTS / PACKAGES
addappid(236511, 1, "8d8de4ac836313f7b2a5c1c2af773bd438c25e09fb851cb4960f0091016283d2")
addappid(236512, 1, "6c69370ed74678fd9096e565c4d359307731704a8c8bff9f31e72ee78eb5928f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
