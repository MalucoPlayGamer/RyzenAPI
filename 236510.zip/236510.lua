-- Lua provided by RyzenAPI
-- Game: Game: Takedown: Red Sabre

-- MAIN APPLICATION
addappid(236510)
-- Game: addappid(236510)

-- MAIN APP DEPOTS / PACKAGES
addappid(236511, 1, "8d8de4ac836313f7b2a5c1c2af773bd438c25e09fb851cb4960f0091016283d2")
addappid(236512, 1, "6c69370ed74678fd9096e565c4d359307731704a8c8bff9f31e72ee78eb5928f")
