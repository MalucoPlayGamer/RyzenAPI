-- Lua provided by RyzenAPI
-- Game: Game: I'm the Koala

-- MAIN APPLICATION
addappid(966450)
-- Game: addappid(966450)

-- MAIN APP DEPOTS / PACKAGES
addappid(966451, 1, "b7cbb7d05b2a390e7c4ead072faa459a697c570162bfcd400c7684791100b873")
