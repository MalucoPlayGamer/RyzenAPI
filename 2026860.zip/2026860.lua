-- Lua provided by RyzenAPI
-- Game: Maria Blanchard Virtual Gallery

-- MAIN APPLICATION
addappid(2026860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026861, 1, "950118362374362cda2d4165174c9cf53131cc93a9782a04197bbb8950ca544d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
