-- Lua provided by SkyAPI 
-- Game: Maria Blanchard Virtual Gallery
addappid(2026860)
addappid(2026861, 1, "950118362374362cda2d4165174c9cf53131cc93a9782a04197bbb8950ca544d")
