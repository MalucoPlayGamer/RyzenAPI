-- Lua provided by RyzenAPI
-- Game: Game: Cooks Girls

-- MAIN APPLICATION
addappid(1782230)
-- Game: addappid(1782230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782231, 1, "4077d3e5396cad9525cd4a1e34cd1d64c5e8e2548075c2ce7970676c8aefdc73")
