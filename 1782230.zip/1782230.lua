-- Lua provided by SkyAPI 
-- Game: Cooks Girls
addappid(1782230)
addappid(1782231, 1, "4077d3e5396cad9525cd4a1e34cd1d64c5e8e2548075c2ce7970676c8aefdc73")
