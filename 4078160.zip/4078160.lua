-- Lua provided by RyzenAPI
-- Game: Changeable Guardian ESTIQUE

-- MAIN APP DEPOTS / PACKAGES
addappid(4078160, 1, "0ef4b90c55d95097aba7fc8e918aac6277cfa359428b32fca1cb37f2322afaf3") -- Changeable Guardian ESTIQUE
addappid(4078161, 1, "fa21b24ab856668d0da4e429dd35b79c02790f5d3e7eda368781387a827d9875") -- Depot 4078161

