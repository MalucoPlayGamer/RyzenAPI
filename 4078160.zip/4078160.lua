-- 4078160's Lua and Manifest Created by Hubcap Manifest
-- Changeable Guardian ESTIQUE
-- Created: August 05, 2026 at 13:39:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4078160, 1, "0ef4b90c55d95097aba7fc8e918aac6277cfa359428b32fca1cb37f2322afaf3") -- Changeable Guardian ESTIQUE
-- MAIN APP DEPOTS
addappid(4078161, 1, "fa21b24ab856668d0da4e429dd35b79c02790f5d3e7eda368781387a827d9875") -- Depot 4078161
setManifestid(4078161, "5545723970824783613", 415827976)