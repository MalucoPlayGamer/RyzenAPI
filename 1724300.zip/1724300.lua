-- Lua provided by RyzenAPI
-- Game: addappid(1724300)

-- MAIN APPLICATION
addappid(1724300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724301, 1, "6753c82d95384884aecff58ac027c63714ea7884031c5cdd03707afa8d129e6f")
