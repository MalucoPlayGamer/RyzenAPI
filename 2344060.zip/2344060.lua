-- Lua provided by RyzenAPI
-- Game: Dimensional Animals

-- MAIN APPLICATION
addappid(2344060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344061, 1, "ccbb353b003467b04e4f691eef9a62cb8d774cd442b856d181aee292ff81af3f")
