-- Lua provided by RyzenAPI
-- Game: Art Reborn: Painting Connoisseur

-- MAIN APPLICATION
addappid(2064490)
-- Game: addappid(2064490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064491, 1, "9824a4c5a257d92eb0dacf66d45be78357186ef854455fe498c8767127d5ad3c")
addappid(2186080, 0, "d7684f94c9b908e6adae67f3943f41c8c201d5d3d6b2c33efb1fdbafb4a54a73")
