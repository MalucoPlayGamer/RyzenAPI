-- Lua provided by RyzenAPI
-- Game: Game: Game of Fate 2: A Century's Promise

-- MAIN APPLICATION
addappid(3218600)
-- Game: addappid(3218600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3218601, 1, "a9056353de36f2ccfb10c1b66ad52bba28d64db535fb19c5540bbf759b0a6ec7")
