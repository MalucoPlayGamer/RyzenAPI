-- Lua provided by RyzenAPI
-- Game: Egg RTX

-- MAIN APPLICATION
addappid(2838510)
-- Game: addappid(2838510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838511, 1, "838fc8f370a1027a0bd2a1e6928908e3486ba421d443de981d45b18dfb49f337")
