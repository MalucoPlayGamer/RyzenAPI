-- Lua provided by RyzenAPI
-- Game: Egg RTX

-- MAIN APPLICATION
addappid(2838510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838511, 1, "838fc8f370a1027a0bd2a1e6928908e3486ba421d443de981d45b18dfb49f337")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
