-- Lua provided by RyzenAPI
-- Game: addappid(2657120)

-- MAIN APPLICATION
addappid(2657120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657121, 1, "7b381e90b749582143ed04410e6af148215b1c2f6a94435a3cc2db4eed0f6fba")
