-- Lua provided by RyzenAPI
-- Game: addappid(1698480)

-- MAIN APPLICATION
addappid(1698480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698481, 1, "fe729519dca0a21922206f7dd838622615dddb551429997e6eb43acfb5d28f7e")
