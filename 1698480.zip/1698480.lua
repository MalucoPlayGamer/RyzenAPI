-- Lua provided by SkyAPI 
-- Game: A Sex Slave's  Love Story
addappid(1698480)
addappid(1698481, 1, "fe729519dca0a21922206f7dd838622615dddb551429997e6eb43acfb5d28f7e")
