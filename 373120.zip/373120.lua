-- Lua provided by RyzenAPI
-- Game: Bernie Needs Love

-- MAIN APPLICATION
addappid(373120)

-- MAIN APP DEPOTS / PACKAGES
addappid(373121, 1, "b440930f7ed65ae7eb2adb60588bd49e10c0716eed9389e4fdf89c15c794e0af")
addappid(373122, 1, "dfe174942be10b74cd96963bfc831d33d74dad36bc9aaa816f4b09fdf39af3d6")
addappid(373123, 1, "f28371890cc797f127075c91a1dae05bb2bb71b4b721cc1a8614ec98b6ed468b")
addappid(373124, 1, "67a56c6820c08417bbfad5b2ba5612d8df16daa26124abf53726ce197a36a065")

