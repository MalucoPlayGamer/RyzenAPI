-- Lua provided by RyzenAPI 
-- Game: AppID 1094340
addappid(1094340)
addappid(1094341, 1, "10b61260afb60a0dd5f9a68f7998b2c92a264320d23b05216e48f0466c985d85")
