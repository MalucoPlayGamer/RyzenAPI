-- Lua provided by SkyAPI 
-- Game: Merge Adventure: Magic Dragons
addappid(2495050)
addappid(2495051, 1, "f7a033b22843c0422d527e7d410bee866dd76cd11a73839c7a0826c001512fa0")
addappid(2495052, 1, "d9b4afae33c865de1c33c9eb93ddd9a5607c8eb44728ae8f598fa68087aa00ec")
addappid(2495053, 1, "49f3722d3c8ab41f2f47fea7df04d689729bf339fd6e64fab4f80de3de474768")
