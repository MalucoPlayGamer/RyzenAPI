-- Lua provided by RyzenAPI
-- Game: addappid(933140)

-- MAIN APPLICATION
addappid(933140)

-- MAIN APP DEPOTS / PACKAGES
addappid(933141, 1, "3dff1e0861611035c13d7e37cdac9adfe5d2ddc65e34bdc25ce5ddcc38987884")
