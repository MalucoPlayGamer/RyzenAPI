-- Lua provided by RyzenAPI
-- Game: Sexy New Year

-- MAIN APPLICATION
addappid(2327790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327791, 1, "af7b7e57421f437c07024ea8f58dc19649b41f88a8e6a8e221b1524979e07862")
