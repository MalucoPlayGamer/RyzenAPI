-- Lua provided by RyzenAPI
-- Game: Dung Beetle Adventure

-- MAIN APPLICATION
addappid(2560820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560821, 1, "66f3f77a61181cc851eb541013019ba1f60a85d69a8fd6d2b7e395db45c4ce98")
addappid(2560822, 1, "05ae24e24b969a1ef437789e3d187b3fd07f737b8c7d552c4fbbe8a44d7ff2e9")
addappid(2560823, 1, "767ae3416bf20d20febee718f1ce43c4d93ffa2208a42108fdf27b92712932b4")

