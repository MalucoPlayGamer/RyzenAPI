-- Lua provided by RyzenAPI
-- Game: Game: Crazy Santa

-- MAIN APPLICATION
addappid(1814160)
-- Game: addappid(1814160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814161, 1, "4ec74e7c7546a7b03d8b4695785b08445379b0738823fbad044f2173dbb11125")
