-- Lua provided by RyzenAPI
-- Game: Crazy Santa

-- MAIN APPLICATION
addappid(1814160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814161, 1, "4ec74e7c7546a7b03d8b4695785b08445379b0738823fbad044f2173dbb11125")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
