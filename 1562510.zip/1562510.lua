-- Lua provided by RyzenAPI
-- Game: Falnarion Tactics: Oathbreaker

-- MAIN APPLICATION
addappid(1562510)
-- Game: addappid(1562510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562511, 1, "f632322e07e42c997e77efbae3b5146036aa7ba8a89aa64233f44da72f0fa0f3")
