-- Lua provided by SkyAPI 
-- Game: Falnarion Tactics: Oathbreaker
addappid(1562510)
addappid(1562511, 1, "f632322e07e42c997e77efbae3b5146036aa7ba8a89aa64233f44da72f0fa0f3")
