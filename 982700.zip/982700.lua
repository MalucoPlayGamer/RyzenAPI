-- Lua provided by RyzenAPI
-- Game: Game: AppID 982700

-- MAIN APPLICATION
addappid(982700)
-- Game: addappid(982700)

-- MAIN APP DEPOTS / PACKAGES
addappid(982701, 1, "3c9a8576a3fce9692b075e16f083ec2fb8a4caa9f32b87b4e9f3f766562ba927")
