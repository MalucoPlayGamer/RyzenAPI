-- Lua provided by RyzenAPI
-- Game: AppID 1227780

-- MAIN APPLICATION
addappid(1227780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227781, 1, "f28b6fe7393eb9c7b888b832198bb3ce17bffe51394dda2dbeb85e2967fc3a41")
