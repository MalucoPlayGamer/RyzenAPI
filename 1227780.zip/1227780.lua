-- Lua provided by RyzenAPI
-- Game: Taur

-- MAIN APPLICATION
addappid(1227780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1227781, 1, "f28b6fe7393eb9c7b888b832198bb3ce17bffe51394dda2dbeb85e2967fc3a41")

