-- Lua provided by RyzenAPI
-- Game: Souls Survivors Demo

-- MAIN APPLICATION
addappid(2778680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778681, 1, "c55c9eed252fa637778666f840f0736eb36fb6daa5bb7787309c4771071dc70e")

