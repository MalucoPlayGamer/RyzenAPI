-- Lua provided by SkyAPI 
-- Game: Ember
addappid(339580)
addappid(339581, 1, "dc9e82f5a1316282b607f235e28c02e355d1add8c86686559b3f229884ed668c")
