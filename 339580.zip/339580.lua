-- Lua provided by RyzenAPI
-- Game: Ember

-- MAIN APPLICATION
addappid(339580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(339581, 1, "dc9e82f5a1316282b607f235e28c02e355d1add8c86686559b3f229884ed668c")

