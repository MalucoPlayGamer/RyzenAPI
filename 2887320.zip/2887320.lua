-- Lua provided by RyzenAPI
-- Game: Cats of the Qing Dynasty

-- MAIN APPLICATION
addappid(2887320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887321, 1, "6de7273f466a642c514a01b50e9196d5a61c2a1509f258d45c933dbef76d5058")

