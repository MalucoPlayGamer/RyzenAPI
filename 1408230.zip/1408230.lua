-- Lua provided by RyzenAPI
-- Game: Walkabout Mini Golf VR

-- MAIN APPLICATION
addappid(1408230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408231, 1, "801d8b1cbfc15f01db9306fd2300d43d12ac7cfa46ffde9b86425538d1966813")
