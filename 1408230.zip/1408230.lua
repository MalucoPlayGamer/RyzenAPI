-- Lua provided by RyzenAPI
-- Game: Walkabout Mini Golf VR

-- MAIN APPLICATION
addappid(1408230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408231, 1, "801d8b1cbfc15f01db9306fd2300d43d12ac7cfa46ffde9b86425538d1966813")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1791210)
addappid(1847170)
addappid(1906500)
addappid(2016530)
addappid(2086230)
addappid(2158180)
addappid(2208010)
addappid(2287580)
addappid(2338250)
addappid(2380460)
addappid(2434550)
addappid(2484900)
addappid(2528590)
addappid(2598430)
addappid(2652320)
addappid(2726330)
addappid(2790080)
addappid(2876630)
addappid(3041950)
addappid(3074270)
addappid(3078240)
addappid(3129060)
addappid(3220870)
addappid(3300630)
addappid(3338120)
addappid(3338130)
addappid(3400950)
addappid(3526580)
addappid(3680590)
addappid(3819440)
addappid(3974100)
addappid(4072970)
addappid(4112200)
addappid(4316510)
addappid(4485230)
addappid(4610520)
addappid(4788810)
addappid(4861890)
