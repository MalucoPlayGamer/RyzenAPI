-- Lua provided by RyzenAPI
-- Game: aMAZE St.Patrick

-- MAIN APPLICATION
addappid(1017350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017351, 1, "63b84f882a7402b3fa6778e3ecf69fde025ffd9b4f5087dfcac711791e3b0999")

