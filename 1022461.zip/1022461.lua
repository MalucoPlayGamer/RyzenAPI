-- Lua provided by RyzenAPI
-- Game: DFF NT: Ultimecia Starter Pack

-- MAIN APPLICATION
addappid(1022461)
-- Game: addappid(1022461)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022461,0,"a893e76d268701a0927116bacdf26c3844307a3bde83415b9b89f68ca3a64105")
