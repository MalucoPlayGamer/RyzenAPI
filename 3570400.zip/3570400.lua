-- Lua provided by RyzenAPI
-- Game: 3570400

-- MAIN APPLICATION
addappid(3570400)
-- Game: addappid(3570400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3570401, 1, "dc1362968e848bb2f099b2ba9bcd8cb100874db868ab0e552e769a06f7ca6b24")
