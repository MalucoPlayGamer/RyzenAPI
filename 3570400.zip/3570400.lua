-- Lua provided by RyzenAPI
-- Game: Wall Town Wonders

-- MAIN APPLICATION
addappid(3570400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3570401, 1, "dc1362968e848bb2f099b2ba9bcd8cb100874db868ab0e552e769a06f7ca6b24")

