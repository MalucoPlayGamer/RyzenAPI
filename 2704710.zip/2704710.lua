-- Lua provided by RyzenAPI
-- Game: 2704710

-- MAIN APPLICATION
addappid(2704710)
-- Game: addappid(2704710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704711, 1, "7b7c277d54e787c7d79faa0f4030efcb08bccd798b93b0201500571cc90c3db8")
