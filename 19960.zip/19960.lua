-- Lua provided by RyzenAPI
-- Game: Heroes of Might & Magic V: Hammers of Fate Editor

-- MAIN APPLICATION
addappid(19960)

-- MAIN APP DEPOTS / PACKAGES
addappid(15171,0,"1a9f1e32152cbd8fe3bba033ea4e23961e5f7ad731190ffcaf82e2668912e33e")
addappid(15381,0,"fe22944991f61f8bfb0efc133ca8255b910b0962614f232c714fd06473e7e539")

