-- Lua provided by RyzenAPI
-- Game: Game: AppID 470600

-- MAIN APPLICATION
addappid(470600)
-- Game: addappid(470600)

-- MAIN APP DEPOTS / PACKAGES
addappid(470601, 1, "aa01f334f57dcb3d3aa7dce23d165290c90ca022ba85e3184cff92f58d69ebff")
