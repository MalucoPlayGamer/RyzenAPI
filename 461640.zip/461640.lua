-- Lua provided by RyzenAPI 
-- Game: AppID 461640
addappid(461640)
addappid(461641, 1, "a80d024518314b4ca1dacb584cbfef7d62f5ca1e21e29001e843dafd2bb6ceff")
