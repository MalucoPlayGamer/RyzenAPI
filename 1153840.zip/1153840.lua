-- Lua provided by RyzenAPI
-- Game: Snow Island

-- MAIN APPLICATION
addappid(1153840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153841, 1, "ff52ea06687e4411cc2e5c45071969ed88b76ffd0a4ef6a72a42c2e711aeeb71")
