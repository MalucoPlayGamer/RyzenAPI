-- Lua provided by SkyAPI 
-- Game: Toonstruck
addappid(369830)
addappid(369831, 1, "d33c3f671e46bc2f7d2796b5cf3d0778db0304fb260648f6d8ccb3a77d295792")
