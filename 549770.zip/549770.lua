-- Lua provided by RyzenAPI
-- Game: Paranormal Teens

-- MAIN APPLICATION
addappid(549770)

-- MAIN APP DEPOTS / PACKAGES
addappid(549771, 1, "e5f1feb9bc87eeeadc5a0354f773210487f7d17612da8cdfce4c836ab2243706")
