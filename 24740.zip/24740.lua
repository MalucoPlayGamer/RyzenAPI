-- Lua provided by RyzenAPI
-- Game: Burnout Paradise: The Ultimate Box

-- MAIN APPLICATION
addappid(24740)

-- MAIN APP DEPOTS / PACKAGES
addappid(24741, 1, "bf9b197b173bddfda183a9b2d645aa30840ac2187661b1950a6a326a6e6c2347")
