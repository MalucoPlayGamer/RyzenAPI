-- Lua provided by RyzenAPI
-- Game: Gravity Dash

-- MAIN APPLICATION
addappid(2773890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773891, 1, "9637b644ff129422cd99a92cea8d7f63047d5bcc5b6b806019bc4273594b7654")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
