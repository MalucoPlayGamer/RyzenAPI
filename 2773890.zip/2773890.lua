-- Lua provided by RyzenAPI
-- Game: Gravity Dash

-- MAIN APPLICATION
addappid(2773890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773891, 1, "9637b644ff129422cd99a92cea8d7f63047d5bcc5b6b806019bc4273594b7654")
