-- Lua provided by SkyAPI 
-- Game: TENSEI
addappid(2482150)
addappid(2482151, 1, "b46101b2ed9b7af497c6a4ba60d86e03aa66f0d46cacc75542713de28d7df048")
