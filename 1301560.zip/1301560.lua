-- Lua provided by RyzenAPI
-- Game: Game: Space Roaming

-- MAIN APPLICATION
addappid(1301560)
-- Game: addappid(1301560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301561, 1, "a6b2816661779f31539d86604528d3e4a64d3651c014b0334790d72f4283e37c")
