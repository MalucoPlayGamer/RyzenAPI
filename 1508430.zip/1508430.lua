-- Lua provided by RyzenAPI
-- Game: Kemono Mahjong

-- MAIN APPLICATION
addappid(1508430)
-- Game: addappid(1508430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508431, 1, "b15c9eef7f90cb7a5c170ec177f15217f6cb752e820a719fc8e5114593180303")
