-- Lua provided by RyzenAPI
-- Game: addappid(1429040)

-- MAIN APPLICATION
addappid(1429040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429042,0,"f760a65cd3a0bdeff9450c780aec80dcd50453c1983377673cbdd45e911ab8e8")
