-- Lua provided by RyzenAPI
-- Game: addappid(385070)

-- MAIN APPLICATION
addappid(385070)

-- MAIN APP DEPOTS / PACKAGES
addappid(385071, 1, "f9c59e49f035dec285a85664b1157c39d856d37fb744c87eebdb1dd7537716ae")
