-- Lua provided by RyzenAPI
-- Game: Taco Tom 2

-- MAIN APPLICATION
addappid(727420)

-- MAIN APP DEPOTS / PACKAGES
addappid(727421, 1, "f9eddb0e8d66c8b89f873bd59a57debf06fda59078f3e4aade7325ef688b29c5")

