-- Lua provided by RyzenAPI
-- Game: Acretia - Guardians of Lian

-- MAIN APPLICATION
addappid(2164200)
-- Game: addappid(2164200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164201, 1, "ed173d1e90c40dc1eb05f0ec64b7cc08be9f18c4dd04674f89bdc7c4456491a9")
