-- Lua provided by RyzenAPI
-- Game: Game: D-100

-- MAIN APPLICATION
addappid(2373160)
-- Game: addappid(2373160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373161, 1, "8cd5ed277cd1305c4565081206ab91ce68eb1610473059534f1ee4635c61757b")
