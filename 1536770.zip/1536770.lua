-- Lua provided by RyzenAPI
-- Game: Game: Learn Programming: Python - Retro

-- MAIN APPLICATION
addappid(1536770)
-- Game: addappid(1536770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536771, 1, "1d59f7c91d6ec112855e5d9e347c5d4a233895c7d4cf27120d934731eb021379")
