-- Lua provided by RyzenAPI
-- Game: Immortal: Unchained - Primes Pack

-- MAIN APPLICATION
addappid(883210)
-- Game: addappid(883210)

-- MAIN APP DEPOTS / PACKAGES
addappid(883211, 1, "c3c07687a158e55b4158dc3196b637cc19af94a9a42d63673ec330579a387caf")
