-- Lua provided by RyzenAPI
-- Game: addappid(649600)

-- MAIN APPLICATION
addappid(649600)

-- MAIN APP DEPOTS / PACKAGES
addappid(649602,0,"88a2a2e70b61f153b5fa6fcfacd07868aa6a8c77cfe805f358e00ddc7250314b")
