-- Lua provided by RyzenAPI
-- Game: Game: Smash Crates

-- MAIN APPLICATION
addappid(1553400)
-- Game: addappid(1553400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553401, 1, "a7b455dcc1ad717ccd33579c896039a025be474f770de1e34370799758233532")
