-- Lua provided by RyzenAPI
-- Game: AppID 288830

-- MAIN APPLICATION
addappid(288830)

-- MAIN APP DEPOTS / PACKAGES
addappid(288831, 1, "fadaa1b213befad9d094a88300fe787fb9db446e46ca183e0d4402234a81a1a5")
