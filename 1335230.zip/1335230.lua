-- Lua provided by RyzenAPI 
-- Game: Sumire
addappid(1335230)
addappid(1335231, 1, "3e64f9b8b08f1c1420e3b9cc9d4d3b2d5419ac64431c2575008f1a115ebd7262")
addappid(1335232, 1, "eeb48fa465d91082814608d39a0d78e04e762a66d9a44addcae7fc489149750e")
addappid(1594640, 0, "b4c46643f3305de85bd834a08141ba8551accaecea978fed15ededb959c86f91")
