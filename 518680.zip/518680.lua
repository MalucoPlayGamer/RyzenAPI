-- Lua provided by RyzenAPI
-- Game: Kapsul Infinite

-- MAIN APPLICATION
addappid(518680)

-- MAIN APP DEPOTS / PACKAGES
addappid(518681,0,"b012a024bac14f1f16288afff499f872e6d5877d41982e3df78b3b87823d5d6c")

