-- Lua provided by RyzenAPI
-- Game: addappid(1045340)

-- MAIN APPLICATION
addappid(1045340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045341, 1, "34f8b77a6f8cba7c8f066726cc3e23b303db846156708a3feddb4c4fc09ac963")
addappid(1150860, 0, "6e223eb9d0fb4366b7e743a34d3795a84acb7f1bf2870323e99d346e3915ec3b")
