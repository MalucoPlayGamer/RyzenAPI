-- Lua provided by RyzenAPI
-- Game: Celia's Quest

-- MAIN APPLICATION
addappid(380120)
-- Game: addappid(380120)

-- MAIN APP DEPOTS / PACKAGES
addappid(380124,0,"d2894217c61a256691e1c8877b65b98d823e7e3d1244e237f0653b82ab766355")
