-- Lua provided by RyzenAPI
-- Game: Game: Dee's Nuts 2

-- MAIN APPLICATION
addappid(2669000)
-- Game: addappid(2669000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669001, 1, "a9c1a1dd32eff7227af571b0f4e027956c3c8cb8221e2c433a1ded0dad976dee")
