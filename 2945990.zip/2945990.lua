-- Lua provided by RyzenAPI
-- Game: Mr. Hopp's Playhouse HD

-- MAIN APPLICATION
addappid(2945990)
-- Game: addappid(2945990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945991, 1, "2f003a6f8510c33eba2870c825dcae9b5b882fff569e0deaa33334a0c962902c")
