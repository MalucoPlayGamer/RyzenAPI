-- Lua provided by RyzenAPI
-- Game: addappid(3022350)

-- MAIN APPLICATION
addappid(3022350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022351, 1, "3c80fa594c099533ccc4d073dffa2c6c153a200b3707fb458e6a9dcde238932f")
