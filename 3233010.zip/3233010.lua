-- Lua provided by SkyAPI 
-- Game: AppID 3233010
addappid(3233010)
addappid(3233011, 1, "c0afc8750e949a241b7a7501d13baa794f1d27f07f3388876dc448d0aafeadd2")
