-- Lua provided by RyzenAPI
-- Game: First Class Escape 2: Head in the Clouds

-- MAIN APPLICATION
addappid(1826570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826571, 1, "cba6645679ee2ed190b5ea4ee74efae03c771ffb88cd17bb53f87fe42f229ca2")
