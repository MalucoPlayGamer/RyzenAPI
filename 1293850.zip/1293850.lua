-- Lua provided by RyzenAPI
-- Game: addappid(1293850)

-- MAIN APPLICATION
addappid(1293850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293851, 1, "0d562a2850ac8ebe2ebbd7c07b0d52232c316323a5337e8e0d40eda8053776b8")
