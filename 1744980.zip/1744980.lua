-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Society Islands XP - Bora Bora & Leeward Islands

-- MAIN APPLICATION
addappid(1744980)
-- Game: addappid(1744980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744980,0,"0c9fc2610417b23aea0481ddff95868242795d20ced33725ab569c3e7aeac035")
