-- Lua provided by RyzenAPI 
-- Game: Basket Brawl DX
addappid(2938890)
addappid(2938891, 1, "0b9d85fbaac3cd99380e2a97f450974f775a1819e96fa48584f42fb892f6f684")
