-- Lua provided by RyzenAPI
-- Game: Ma Chao - Officer Ticket / 馬超使用券

-- MAIN APPLICATION
addappid(956750)
-- Game: addappid(956750)

-- MAIN APP DEPOTS / PACKAGES
addappid(956750,0,"3eabce7ffde1e12de1088e33a535f5bc18c8996f91599cad25301ac49c42c656")
