-- Lua provided by RyzenAPI
-- Game: My Girlfriend is... Centaur

-- MAIN APPLICATION
addappid(2981350)
-- Game: addappid(2981350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981351, 1, "46f21bdb495ebb6c4f89aeb868a1c2f71cf60a7d7d7d6762106d5a989a754117")
