-- Lua provided by RyzenAPI
-- Game: Liquor And Wine Shop Simulator - Store Simulator

-- MAIN APPLICATION
addappid(3274060)
-- Game: addappid(3274060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274061, 1, "70d6badbd28b76835097500598c8a6d6f24b65e9876afb07462cbfc87dd74ed5")
