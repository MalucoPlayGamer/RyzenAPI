-- Lua provided by RyzenAPI
-- Game: Dark Raider

-- MAIN APPLICATION
addappid(1199450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199451, 1, "ac8770e11cc64cfb1a33d36ef812d203bbb5392f2422b261361379dd8e46478d")
