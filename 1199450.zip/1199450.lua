-- Lua provided by SkyAPI 
-- Game: AppID 1199450
addappid(1199450)
addappid(1199451, 1, "ac8770e11cc64cfb1a33d36ef812d203bbb5392f2422b261361379dd8e46478d")
