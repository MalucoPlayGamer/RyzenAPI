-- Lua provided by RyzenAPI
-- Game: Game: LineArt Jigsaw Puzzle - Erotica

-- MAIN APPLICATION
addappid(1430160)
addappid(1538660)
-- Game: addappid(1430160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430161, 1, "88bea3566395b387bc8545581e655a9e80c8b0b8f3b5246ad2da24870f83f046")
