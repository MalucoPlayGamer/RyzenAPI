-- Lua provided by RyzenAPI
-- Game: Resident Evil Re:Verse - Premium Pass

-- MAIN APPLICATION
addappid(1607011)
-- Game: addappid(1607011)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607011,0,"dde5c7d921201c6e3a4bf9a1551bb0463bbfaa2b7735075914ff7e2a85503e60")
