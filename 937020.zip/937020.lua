-- Lua provided by RyzenAPI
-- Game: 937020

-- MAIN APPLICATION
addappid(937020)
-- Game: addappid(937020)

-- MAIN APP DEPOTS / PACKAGES
addappid(937021, 1, "1b1d2ec0612dda48d9675f953b1a75f93521e542900770cd8ef8dabc6b676138")
