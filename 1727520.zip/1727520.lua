-- Lua provided by RyzenAPI
-- Game: AppID 1727520

-- MAIN APPLICATION
addappid(1727520)
addappid(1865120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727521, 1, "471a1dd5a7f86787f29bb58fe0adb553b1154f795ce9b7cc482d4fd8709ec9c8")
addappid(1727523, 1, "890fa0f5c251ffef53862215b7f0d621439ba4fc3d6e997ea444b0b7ccee4db8")

