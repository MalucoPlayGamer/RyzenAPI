-- Lua provided by RyzenAPI
-- Game: Touhou Juuouen 〜 Unfinished Dream of All Living Ghost. Demo

-- MAIN APPLICATION
addappid(2400360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400361, 1, "b3038ca8d1cd9010abcd32055c6060b5e2f299f72ee4eb6c20c0582309d38754")

