-- Lua provided by RyzenAPI
-- Game: Mineirinho Shooter DC

-- MAIN APPLICATION
addappid(1212450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212451, 1, "60671adeccd3031374859e2b4077009d8a6688ebc7c0e35321a871238a1d69da")

