-- Lua provided by RyzenAPI
-- Game: 1832420

-- MAIN APPLICATION
addappid(1832420)
-- Game: addappid(1832420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832421, 1, "3a8dedbcaf8d677bbe45576e0f4c43caa20a1b1b57336637e869dfb7f541dd67")
