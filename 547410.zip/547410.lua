-- Lua provided by RyzenAPI
-- Game: Game: Peak Angle: Drift Online

-- MAIN APPLICATION
addappid(547410)
-- Game: addappid(547410)

-- MAIN APP DEPOTS / PACKAGES
addappid(547411, 1, "48236fac534677eb32cf3fff2ab5dfd750cd131efdc61deae29ac5b1868f978c")
