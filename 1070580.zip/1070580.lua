-- Lua provided by RyzenAPI
-- Game: Drift86

-- MAIN APPLICATION
addappid(1070580)
addappid(1810090)
addappid(2162500)
addappid(2384160)
addappid(4634110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070581,0,"4ff6c35a734e65619fb72723e78884c26854f9d5b8fe0a93ecc7e46129639491")

