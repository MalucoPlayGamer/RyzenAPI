-- Lua provided by SkyAPI 
-- Game: AppID 1070580
addappid(1070580)
addappid(1070581, 1, "4ff6c35a734e65619fb72723e78884c26854f9d5b8fe0a93ecc7e46129639491")
