-- Lua provided by SkyAPI 
-- Game: AppID 1892050
addappid(1892050)
addappid(1892051, 1, "981d3144ccc799549d257a536e5f4201694398b85f05f76dc620df1caea3925a")
addappid(1892052, 1, "d01fa92f84aedcb8001bac2cf0ba1f29bd6582f22004c9b08aea00875b759691")
