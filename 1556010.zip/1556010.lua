-- Lua provided by RyzenAPI
-- Game: DriveCrazy

-- MAIN APPLICATION
addappid(1556010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1556011, 1, "4af82db67f54939cb5f00bca90a3453429d7c1f506fd03b3417e7c1f4988621b")
