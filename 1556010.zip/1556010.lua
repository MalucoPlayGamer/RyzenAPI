-- Lua provided by RyzenAPI
-- Game: Game: AppID 1556010

-- MAIN APPLICATION
addappid(1556010)
-- Game: addappid(1556010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556011, 1, "4af82db67f54939cb5f00bca90a3453429d7c1f506fd03b3417e7c1f4988621b")
