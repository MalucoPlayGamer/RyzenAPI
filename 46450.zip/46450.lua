-- Lua provided by RyzenAPI
-- Game: Grotesque Tactics: Evil Heroes

-- MAIN APPLICATION
addappid(46450)

-- MAIN APP DEPOTS / PACKAGES
addappid(46451, 1, "001a2156db37019c365884b9593cf68feff409bd28fefe91f5d9ee776d06f897")
