-- Lua provided by RyzenAPI
-- Game: 3190340

-- MAIN APPLICATION
addappid(3190340)
-- Game: addappid(3190340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3190341, 1, "bf6f5faf26d968ebd89faca85d675266f8f02f8caa6b9ac4a5b71d6b97f27345")
