-- Lua provided by RyzenAPI
-- Game: IllusionCircle

-- MAIN APPLICATION
addappid(1828640)
-- Game: addappid(1828640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828641, 1, "db6b3b284f5de274dfb3060cae5949a109bab4a0990c3fb45c38465230a43db8")
