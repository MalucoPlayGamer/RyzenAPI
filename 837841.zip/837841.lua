-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(837841)

-- MAIN APP DEPOTS / PACKAGES
addappid(863200,0,"3d0a5081782b9876587e4b72264f62f2af2a310e2f1e2b4e442bca512b42e6ce")
