-- Lua provided by RyzenAPI 
-- Game: Retro/Grade
addappid(222660)
addappid(222661, 1, "36fe455aecafd2ca5308c072bae0a14a0d0ab171afec5ff289031788d746f1cc")
