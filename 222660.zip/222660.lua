-- Lua provided by RyzenAPI
-- Game: Retro/Grade

-- MAIN APPLICATION
addappid(222660)
-- Game: addappid(222660)

-- MAIN APP DEPOTS / PACKAGES
addappid(222661, 1, "36fe455aecafd2ca5308c072bae0a14a0d0ab171afec5ff289031788d746f1cc")
