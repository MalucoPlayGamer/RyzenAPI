-- Lua provided by RyzenAPI
-- Game: Game: AppID 228060

-- MAIN APPLICATION
addappid(228060)
-- Game: addappid(228060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228061, 1, "87ccb656a33863d44a2a479cdf717974dfaed1f9f709786d2c684f970cb7f076")
