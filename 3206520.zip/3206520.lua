-- Lua provided by RyzenAPI 
-- Game: AppID 3206520
addappid(3206520)
addappid(3206521, 1, "978c239348ba0f4e5718b2f4642ef9213a2fe0e1c9841dea5cc595872dce9eeb")
