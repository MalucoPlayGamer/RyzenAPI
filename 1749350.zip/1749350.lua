-- Lua provided by RyzenAPI
-- Game: Gobby McGobblenutz Presents: The Art of the Dad Joke: Chapter 1

-- MAIN APPLICATION
addappid(1749350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749351, 1, "034556653a37b1288271658d7678e1b2861bd63eda7381fdc6824d34292ee6bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
