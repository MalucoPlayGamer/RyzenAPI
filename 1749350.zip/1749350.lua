-- Lua provided by RyzenAPI
-- Game: Gobby McGobblenutz Presents: The Art of the Dad Joke: Chapter 1

-- MAIN APPLICATION
addappid(1749350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749351, 1, "034556653a37b1288271658d7678e1b2861bd63eda7381fdc6824d34292ee6bb")

