-- Lua provided by RyzenAPI
-- Game: The Inner World: The Last Wind Monk

-- MAIN APPLICATION
addappid(613470)

-- MAIN APP DEPOTS / PACKAGES
addappid(613471, 1, "39baf8bf4df2f532170aac5688848bfa68b1f70aadb9138b0d0177cd95b6be2c")
addappid(613472, 1, "10b997fecd249ec8b4b917373e26d1941c6684ba0c30e47614b91de1ae1a5a02")
addappid(613473, 1, "912070011fe507a0a7bcaeca35e743ad29783d4bc88813d154f3d8c130dab65b")
addappid(613474, 1, "09a1ac5506600487b8f2098853d8c2ce33a9d4a89e77af2759d1fa0606e1ca3c")

