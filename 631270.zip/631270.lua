-- Lua provided by RyzenAPI
-- Game: Haunted Hotel II: Believe the Lies

-- MAIN APPLICATION
addappid(631270)

-- MAIN APP DEPOTS / PACKAGES
addappid(631271,0,"d99b3a9c5597d023eab72d568b28194ef6a84fc0717c34a35ac632ce50942237")

