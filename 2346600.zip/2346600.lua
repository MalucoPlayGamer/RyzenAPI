-- Lua provided by RyzenAPI
-- Game: Kizuna AI - Touch the Beat! DLC Costume 1: hello, world 2020

-- MAIN APPLICATION
addappid(2346600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346600,0,"453a54e331ae1606491f826b6449ea421ce19dd7a96328801d8de1780609794e")
