-- Lua provided by RyzenAPI
-- Game: Beat The Moles

-- MAIN APPLICATION
addappid(1499780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499781, 1, "eace0653045f7cffe5c1edecfa536136bac0dfdd99518f632ec6d32d700922f3")

