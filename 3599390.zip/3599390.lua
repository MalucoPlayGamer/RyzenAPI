-- Lua provided by RyzenAPI
-- Game: Game: Amber Alert TOTAL VR

-- MAIN APPLICATION
addappid(3599390)
-- Game: addappid(3599390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599391, 1, "b536ab7e519861ebb5a90828bfee392e5b997050143f638ba27391878088c921")
