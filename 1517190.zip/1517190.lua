-- Lua provided by RyzenAPI 
-- Game: The Daunting House
addappid(1517190)
addappid(1517191, 1, "d3d5d5ca1fb78d8755fcdabf51de0d75a5e8e44ce733e2d6c0db9fef526f176a")
