-- Lua provided by RyzenAPI
-- Game: 1517190

-- MAIN APPLICATION
addappid(1517190)
-- Game: addappid(1517190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517191, 1, "d3d5d5ca1fb78d8755fcdabf51de0d75a5e8e44ce733e2d6c0db9fef526f176a")
