-- Lua provided by RyzenAPI
-- Game: Game: AppID 654910

-- MAIN APPLICATION
addappid(654910)
-- Game: addappid(654910)

-- MAIN APP DEPOTS / PACKAGES
addappid(654911, 1, "ba22ab6f8dc7afa4ba410b13900a0c592ec497e7e5a68508e01d0ee5b0531fe7")
