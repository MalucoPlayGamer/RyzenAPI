-- Lua provided by RyzenAPI
-- Game: addappid(2091980)

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2091980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091982,0,"5e57dd698e480fb09f84f51595746a018b8b1c4151927aebf104ab786d1a5700")
