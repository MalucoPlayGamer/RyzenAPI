-- Lua provided by RyzenAPI
-- Game: addappid(438020)

-- MAIN APPLICATION
addappid(438020)

-- MAIN APP DEPOTS / PACKAGES
addappid(438021, 1, "74f0db8e4c1edcb1a7de60957f9eca62bdbd907b9b43a28bc377d1acedc01ede")
