-- Lua provided by RyzenAPI
-- Game: Game: AppID 1202660

-- MAIN APPLICATION
addappid(1202660)
-- Game: addappid(1202660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202661, 1, "95fe6e646705d700526ba32868c3ac3de4f170111db366044cf75d84e3f1c392")
