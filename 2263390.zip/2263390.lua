-- Lua provided by RyzenAPI
-- Game: Lawnmower Game: Ufo Chase

-- MAIN APPLICATION
addappid(2263390)
-- Game: addappid(2263390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263391, 1, "53a5863781167d79ad173da2aa42b6da64bde69a8b61414280acf0ac49031842")
