-- Lua provided by RyzenAPI
-- Game: Aqua Corner

-- MAIN APPLICATION
addappid(3572690)
-- Game: addappid(3572690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3572692,0,"a7d82c6cd8dcd05ddaa235dcf6789c738a9a8e1b7d5cf3dc035d823a97750ffa")
