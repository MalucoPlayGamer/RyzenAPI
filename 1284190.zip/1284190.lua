-- Lua provided by RyzenAPI
-- Game: The Planet Crafter

-- MAIN APPLICATION
addappid(1284190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284192,0,"1f10eb10bfc54e336b5f2e2a5c05001817700491d0c79a7931637a9158c41dc0")

