-- Lua provided by RyzenAPI
-- Game: Botanicula Soundtrack + Art Book

-- MAIN APPLICATION
addappid(650250)

-- MAIN APP DEPOTS / PACKAGES
addappid(650251, 1, "4a487acf1276b1a5746ee715aee403245042aaca858a403b129b56ea2b056352")
addappid(650252, 1, "aae6368971c43a562a16ca206743bf8963713a619d97f428ae9c92303081cda0")

