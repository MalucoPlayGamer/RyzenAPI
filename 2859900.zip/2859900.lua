-- Lua provided by RyzenAPI
-- Game: 2859900

-- MAIN APPLICATION
addappid(2859900)
-- Game: addappid(2859900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859901, 1, "7043ea023cdff81f51f35447a922dd26be322c6be6c2704122815d271284cba5")
