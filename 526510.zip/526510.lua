-- Lua provided by SkyAPI 
-- Game: AppID 526510
addappid(526510)
addappid(526511, 1, "a354047f805e8da5bf93cd17c996cbdcd7e89064144cb1fb893fe399eebe234d")
