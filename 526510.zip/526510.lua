-- Lua provided by RyzenAPI
-- Game: 526510

-- MAIN APPLICATION
addappid(526510)
-- Game: addappid(526510)

-- MAIN APP DEPOTS / PACKAGES
addappid(526511, 1, "a354047f805e8da5bf93cd17c996cbdcd7e89064144cb1fb893fe399eebe234d")
