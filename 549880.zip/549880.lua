-- Lua provided by RyzenAPI
-- Game: RoboSports VR

-- MAIN APPLICATION
addappid(549880)

-- MAIN APP DEPOTS / PACKAGES
addappid(549881, 1, "641eb893eb3170289e6982dbbd0eb719166206cb69154de649a1c7065e51bbb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
