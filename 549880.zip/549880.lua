-- Lua provided by RyzenAPI 
-- Game: RoboSports VR
addappid(549880)
addappid(549881, 1, "641eb893eb3170289e6982dbbd0eb719166206cb69154de649a1c7065e51bbb7")
