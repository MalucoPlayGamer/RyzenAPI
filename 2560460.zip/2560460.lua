-- Lua provided by RyzenAPI
-- Game: Hidden Cats in Spooky Town

-- MAIN APPLICATION
addappid(2560460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560462,0,"d1a137117a4a5bd4dd128b827f1bfcffee2f95caf219375931b5de3a18f21c2d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2645120)
