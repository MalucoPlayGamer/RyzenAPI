-- Lua provided by RyzenAPI
-- Game: addappid(2560460)

-- MAIN APPLICATION
addappid(2560460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560462,0,"d1a137117a4a5bd4dd128b827f1bfcffee2f95caf219375931b5de3a18f21c2d")
