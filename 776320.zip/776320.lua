-- Lua provided by RyzenAPI
-- Game: addappid(776320)

-- MAIN APPLICATION
addappid(776320)

-- MAIN APP DEPOTS / PACKAGES
addappid(776321, 1, "35753b1477ba802af2567ffcefa228f4ccef74f5c06e57cfeaa8ae8ada95415d")
