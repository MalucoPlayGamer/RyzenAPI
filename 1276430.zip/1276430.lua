-- Lua provided by RyzenAPI 
-- Game: AppID 1276430
addappid(1276430)
addappid(1276431, 1, "3f61a8396dba918017da8a94478cf7d0e462373fe0c201c37edeb6ac3f07f143")
