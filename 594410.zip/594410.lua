-- Lua provided by RyzenAPI
-- Game: Game: Western Bank VR

-- MAIN APPLICATION
addappid(594410)
-- Game: addappid(594410)

-- MAIN APP DEPOTS / PACKAGES
addappid(594411, 1, "067ea8105528512692f175ead68bce287dfd4d24080e5a15cfd5ea40ca2c57f8")
