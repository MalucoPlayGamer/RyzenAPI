-- Lua provided by SkyAPI 
-- Game: Liar's Bar
addappid(3097560)
addappid(3097561, 1, "86eb48bd45b0ad6b6c525996f1844bb03ddd150dff04f65f5119418b10017dd3")
