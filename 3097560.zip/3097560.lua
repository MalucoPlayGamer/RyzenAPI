-- Lua provided by RyzenAPI
-- Game: Liar's Bar

-- MAIN APPLICATION
addappid(3097560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097561, 1, "86eb48bd45b0ad6b6c525996f1844bb03ddd150dff04f65f5119418b10017dd3")
