-- Lua provided by RyzenAPI
-- Game: 630510

-- MAIN APPLICATION
addappid(630510)
-- Game: addappid(630510)

-- MAIN APP DEPOTS / PACKAGES
addappid(630511, 1, "76222306002ae4a5ac9004a151ae479ee6902144199df85da74a7d13b53e7d08")
