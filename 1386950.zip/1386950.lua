-- Lua provided by RyzenAPI
-- Game: Heavy Metal Babes

-- MAIN APPLICATION
addappid(1386950)
-- Game: addappid(1386950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386951, 1, "a735ab576e4ce272c1abcfa8f13829431b75b1ff94cc70ab297b2e1a1c9fb5f7")
