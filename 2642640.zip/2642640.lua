-- Lua provided by RyzenAPI
-- Game: 精灵幻境  Elven dreams

-- MAIN APPLICATION
addappid(2642640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2642641, 1, "58736da6ee97ea8f127932afed411ce68b732d7e91469493e823b85958bb513a")

