-- Lua provided by RyzenAPI
-- Game: 2642640

-- MAIN APPLICATION
addappid(2642640)
-- Game: addappid(2642640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642641, 1, "58736da6ee97ea8f127932afed411ce68b732d7e91469493e823b85958bb513a")
