-- Lua provided by RyzenAPI
-- Game: Game: Tad the Lost Explorer

-- MAIN APPLICATION
addappid(1966690)
-- Game: addappid(1966690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966691, 1, "2e19463b8f27d6371e2485354ba2c4af2def38b0b0afda9f158cd25b759dc0a9")
