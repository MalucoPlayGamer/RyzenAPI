-- Lua provided by RyzenAPI
-- Game: Game: Taimanin Collection: Battle Arena

-- MAIN APPLICATION
addappid(1330250)
-- Game: addappid(1330250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330251, 1, "67b833a979fd39d8f80beeced0bb27ff1521d4cd2fcba6b52b67cd27b7a94029")
addappid(1330252, 1, "107eda9ab84ccb2fef5bb065244a12c856fc7c9ef620449ddfa9993bac79fb6e")
