-- Lua provided by RyzenAPI
-- Game: Taimanin Collection: Battle Arena

-- MAIN APPLICATION
addappid(1330250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1330251, 1, "67b833a979fd39d8f80beeced0bb27ff1521d4cd2fcba6b52b67cd27b7a94029")
addappid(1330252, 1, "107eda9ab84ccb2fef5bb065244a12c856fc7c9ef620449ddfa9993bac79fb6e")

