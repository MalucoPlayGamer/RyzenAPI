-- Lua provided by RyzenAPI
-- Game: Perennial Dusk -Kinsenka-

-- MAIN APPLICATION
addappid(3470530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3470531, 1, "509067aa31e7af8e7f39d39f17db94e8c16ce576dc738c93d2e7a44269126753")

