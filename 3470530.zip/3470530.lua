-- Lua provided by RyzenAPI
-- Game: addappid(3470530)

-- MAIN APPLICATION
addappid(3470530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3470531, 1, "509067aa31e7af8e7f39d39f17db94e8c16ce576dc738c93d2e7a44269126753")
