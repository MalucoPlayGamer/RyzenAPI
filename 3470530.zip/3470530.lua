-- Lua provided by SkyAPI 
-- Game: Perennial Dusk -Kinsenka-
addappid(3470530)
addappid(3470531, 1, "509067aa31e7af8e7f39d39f17db94e8c16ce576dc738c93d2e7a44269126753")
