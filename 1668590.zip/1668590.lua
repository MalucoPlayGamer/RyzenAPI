-- Lua provided by RyzenAPI
-- Game: Neokaiju

-- MAIN APPLICATION
addappid(1668590)
-- Game: addappid(1668590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668591, 1, "2ef439423d4847b1cd5035c46bdee1cf202b72095c90f7e1afdf26ea7a23b6e4")
