-- Lua provided by RyzenAPI
-- Game: Neokaiju

-- MAIN APPLICATION
addappid(1668590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668591, 1, "2ef439423d4847b1cd5035c46bdee1cf202b72095c90f7e1afdf26ea7a23b6e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
