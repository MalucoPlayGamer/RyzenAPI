-- Lua provided by SkyAPI 
-- Game: Neokaiju
addappid(1668590)
addappid(1668591, 1, "2ef439423d4847b1cd5035c46bdee1cf202b72095c90f7e1afdf26ea7a23b6e4")
