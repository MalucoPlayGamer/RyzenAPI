-- Lua provided by RyzenAPI
-- Game: addappid(1139000)

-- MAIN APPLICATION
addappid(1139000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139001, 1, "427700ff3da86a8e5ca4a7aabac4d207e7dbb373bd332c05a35f70d0f679a5c9")
