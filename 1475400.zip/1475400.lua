-- Lua provided by RyzenAPI
-- Game: Run Prop, Run! - Puropu Pursuit

-- MAIN APPLICATION
addappid(1475400)
addappid(1648090)
addappid(2470970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1475401, 1, "dfff2f0d9106a210c543f443a3629768747353e8682dcef0b4bb2b57e2394179")
addappid(1475402, 1, "d05235c43642152ec652a8836b6819e2a3e115974362ba394eceaf657171a0e0")
addappid(1475403, 1, "98b58ac5a250b92e5a266e8869f660f962b6521e63c8ca6efb61bdd2b36ddca8")

