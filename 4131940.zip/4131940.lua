-- Lua provided by RyzenAPI
-- Game: Shattered Chess

-- MAIN APPLICATION
addappid(4131940)

-- MAIN APP DEPOTS / PACKAGES
addappid(4131941,0,"aa2bd559228d6994841a50bb8920ed9812e1d2bcd4de1eb1ebc3a66a414c19f7")

