-- Lua provided by RyzenAPI
-- Game: Serious Sam 2 Editor

-- MAIN APPLICATION
addappid(204350)

-- MAIN APP DEPOTS / PACKAGES
addappid(204341,0,"378c61c3fdef5d82815ce8b6ba81abb1083453372412c1101fb7a97753bf09c2")

