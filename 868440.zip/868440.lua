-- Lua provided by RyzenAPI
-- Game: addappid(868440)

-- MAIN APPLICATION
addappid(868440)

-- MAIN APP DEPOTS / PACKAGES
addappid(868441, 1, "1dacf99060e36fd155581b4f6000ccc677e882c0ff554ed8fc71ca419e0f0d3a")
