-- Lua provided by RyzenAPI 
-- Game: President Trump The Way In Uganda
addappid(791750)
addappid(791751, 1, "5840391eb089345e6d37815883f0f2f65e2abbf11bc8dac4bee25049c03646f9")
addappid(794320, 0, "ee58384082766c369a4764bb5d7322da9a524a362be2e3c8044fd6341765953c")
