-- Lua provided by RyzenAPI
-- Game: Game: Orebound

-- MAIN APPLICATION
addappid(2467810)
-- Game: addappid(2467810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467811, 1, "f58c8a69c8e18d048f04a68cdd49976bf5972ab6d4d04daa344735edbbafbf13")
