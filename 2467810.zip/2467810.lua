-- Lua provided by RyzenAPI
-- Game: Orebound

-- MAIN APPLICATION
addappid(2467810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2467811, 1, "f58c8a69c8e18d048f04a68cdd49976bf5972ab6d4d04daa344735edbbafbf13")

