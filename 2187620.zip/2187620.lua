-- Lua provided by RyzenAPI 
-- Game: AppID 2187620
addappid(2187620)
addappid(2187621, 1, "3afc4fa5e19daf501faa1f7e0af8ab216532353dc025e2988bd6783829c6b667")
