-- Lua provided by RyzenAPI
-- Game: Furry Superstar

-- MAIN APPLICATION
addappid(2096170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096171,0,"c9c017e5b14119a8cd649f445917b82b613662dd4dfff200a48caf0f8ce3b361")
addappid(2100910,0,"a162954beb62193b0222189e5cb8233812da4eabf19aa2e17fea88455dd05bd8")

