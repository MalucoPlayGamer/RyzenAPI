-- Lua provided by RyzenAPI
-- Game: Game: Echo Storm

-- MAIN APPLICATION
addappid(2282200)
-- Game: addappid(2282200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282201, 1, "6015496d356c2a97dd6052fca21b97e7227074dba9d31f53a83d1893c83a8a97")
