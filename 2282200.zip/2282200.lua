-- Lua provided by RyzenAPI
-- Game: Echo Storm

-- MAIN APPLICATION
addappid(2282200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282201, 1, "6015496d356c2a97dd6052fca21b97e7227074dba9d31f53a83d1893c83a8a97")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
