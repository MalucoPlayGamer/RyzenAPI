-- Lua provided by RyzenAPI
-- Game: Game: Leashed Soul

-- MAIN APPLICATION
addappid(589850)
-- Game: addappid(589850)

-- MAIN APP DEPOTS / PACKAGES
addappid(589851, 1, "9801cf2d830b694cca102901edc75d843062cb1243fa826f6c95ed775d060c51")
addappid(589852, 1, "8a61a2bf4d04c360ba4ec17d83476b92c49fd80b392a3f0a28d6f6c82c4dcaf1")
addappid(589853, 1, "aa24c709ed194b57c1f96a5a74d4ade9d5b576a682ed76aceffed3786a11887c")
