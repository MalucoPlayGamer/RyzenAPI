-- Lua provided by RyzenAPI
-- Game: Rescue Party: Live!

-- MAIN APPLICATION
addappid(1662570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662571, 1, "419376b9288c575daa7f160abe31cc672ae6794d9a28e252dc415c2135a03fea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
