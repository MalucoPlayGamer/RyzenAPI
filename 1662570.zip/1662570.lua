-- Lua provided by RyzenAPI
-- Game: addappid(1662570)

-- MAIN APPLICATION
addappid(1662570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662571, 1, "419376b9288c575daa7f160abe31cc672ae6794d9a28e252dc415c2135a03fea")
