-- Lua provided by RyzenAPI
-- Game: METAL GEAR SOLID 2: Sons of Liberty - Master Collection Version

-- MAIN APPLICATION
addappid(2131640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2131641, 1, "9e0f2cb55b09888aff90e9aade07595c51381b2dd13720057b88e569fc795868")
addappid(2131642, 1, "a454a9a487006c18009feb3a699f51d070728520c70ad6d82b3946268926e00e")
addappid(2314260, 0, "9eea628721d13db63c23c3818238e17b8ce84693d659577fcb951ec4fb35110f")
addappid(2314261, 0, "39588cf7f429a47c8ebafcd19084333ca255a9e983122f3b329bb57e00661727")

