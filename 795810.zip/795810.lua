-- Lua provided by SkyAPI 
-- Game: AppID 795810
addappid(795810)
addappid(795811, 1, "b99ee5505767d95c17967794b737e597f7c737067e801eb6d54e0f441f47b5fc")
addappid(795812, 1, "cf7aebf3cec565980dbc5f036e1dd889a9b4268bb4ce060efb92384dcfd55c2c")
addappid(795813, 1, "b5fe2198d894ef3fe0d21822df30cada1f69bdadbae6cda18374bf764a293d83")
