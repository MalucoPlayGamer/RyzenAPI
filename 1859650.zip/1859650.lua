-- Lua provided by RyzenAPI
-- Game: Ryzer: The Reflectors Path

-- MAIN APPLICATION
addappid(1859650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859651, 1, "b7c66a50ada5636ed94c1c85bfc753a58d28fbd4221f46de8f78bcff5dce0d7d")

