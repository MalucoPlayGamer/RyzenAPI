-- Lua provided by SkyAPI 
-- Game: AppID 1859650
addappid(1859650)
addappid(1859651, 1, "b7c66a50ada5636ed94c1c85bfc753a58d28fbd4221f46de8f78bcff5dce0d7d")
