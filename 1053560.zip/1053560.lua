-- Lua provided by RyzenAPI
-- Game: Saint Hazel's Horsepital

-- MAIN APPLICATION
addappid(1053560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053561, 1, "d5706700da990c048812690534f837a8d0698460a51395cc40a772270cd04c2b")

