-- Lua provided by RyzenAPI 
-- Game: AppID 1053560
addappid(1053560)
addappid(1053561, 1, "d5706700da990c048812690534f837a8d0698460a51395cc40a772270cd04c2b")
