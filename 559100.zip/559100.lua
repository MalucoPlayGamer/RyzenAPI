-- Lua provided by RyzenAPI
-- Game: Phantom Doctrine

-- MAIN APPLICATION
addappid(559100)
addappid(918640)
addappid(918650)
addappid(918660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(559101, 1, "d85ac756df75b0653fb35b5203badfc2c60921ca06bbcd3ea1d526a84acaa2a4")
addappid(559102, 1, "a100c036d80d90d8f20a508c12e92442713a50880d70a1d9f291d62f78db19ef")
addappid(559103, 1, "aca0af3acf0b2b5b61075731ec0fb85a1994e6312ce7910ad61065924005d9d0")
addappid(907540, 0, "e1c669d1634aa4a7ff1eed77ca339cd3cbfc60b5aedab00cd428fbb489ded48e")
addappid(907550, 0, "d75236b66466e103c63b991db522e244c9f5e33cad440e02873b9bdffb3b5cc4")
addappid(969920, 0, "919e80f5d121501e6f056810137d0d9c31dc062116b62ea28c0866e3f1b2c16d")

