-- Lua provided by RyzenAPI
-- Game: 3497990

-- MAIN APPLICATION
addappid(3497990)
-- Game: addappid(3497990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3497991, 1, "a5c252529f8b6486d16e9fc7d8c7677a8423a853e3979c1a0f2e52015d38fbb6")
