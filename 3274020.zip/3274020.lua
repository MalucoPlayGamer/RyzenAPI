-- Lua provided by RyzenAPI
-- Game: MeiQi 2024 Demo

-- MAIN APPLICATION
addappid(3274020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274021, 1, "453d81067a7420ae8ba2dd40af6fc9ee19b8d3daa104b5f4059dc132a3fdfc75")

