-- Lua provided by RyzenAPI
-- Game: Dogs Huddled Together 挤在一起的狗狗们

-- MAIN APPLICATION
addappid(2723460)
-- Game: addappid(2723460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723461, 1, "36f5d6756ad6a4af5ef20ee07ed073cc4d5d6b034b30fbe4d64e54168e02bcba")
