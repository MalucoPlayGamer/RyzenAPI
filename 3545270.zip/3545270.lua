-- Lua provided by RyzenAPI
-- Game: addappid(3545270)

-- MAIN APPLICATION
addappid(3545270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989,0,"ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
