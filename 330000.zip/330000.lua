-- Lua provided by RyzenAPI
-- Game: Kingdoms CCG

-- MAIN APPLICATION
addappid(330000)

-- MAIN APP DEPOTS / PACKAGES
addappid(330001, 1, "4d4cb5eb21039e923b051082a1386acdf5e10db62848b530a7d29ec89fcb6c9d")
