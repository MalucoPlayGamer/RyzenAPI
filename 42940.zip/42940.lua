-- Lua provided by RyzenAPI
-- Game: Elven Legacy: Siege

-- MAIN APPLICATION
addappid(42940)

-- MAIN APP DEPOTS / PACKAGES
addappid(42941, 1, "1ef8fc434e45fa3b2f3694ebad87e616dc47b96b44d684657e7fa3fd2b978484")
addappid(42942, 1, "7414e5e07770368f0bd9669df971eca47d27a57702adc2bd1cec88debcee386b")

