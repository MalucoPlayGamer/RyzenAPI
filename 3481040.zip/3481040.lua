-- Lua provided by RyzenAPI
-- Game: Apocalypse Survivors

-- MAIN APPLICATION
addappid(3481040)
-- Game: addappid(3481040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3481041, 1, "a477bfd8bb4ee79e291512ae06b9d9dac3804eeaf1ac6e5c884048a5f7eee3c7")
