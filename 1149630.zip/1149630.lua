-- Lua provided by RyzenAPI
-- Game: Game: Project: Gemini

-- MAIN APPLICATION
addappid(1149630)
-- Game: addappid(1149630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149631, 1, "79ea9c171b604e1e94fbd225c112e551bb00e771f03cd5e94ba9c794606bef4d")
