-- Lua provided by RyzenAPI
-- Game: Project: Gemini

-- MAIN APPLICATION
addappid(1149630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1149631, 1, "79ea9c171b604e1e94fbd225c112e551bb00e771f03cd5e94ba9c794606bef4d")

