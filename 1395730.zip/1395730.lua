-- Lua provided by RyzenAPI
-- Game: There Is No Game: Wrong Dimension Soundtrack

-- MAIN APPLICATION
addappid(1395730)
-- Game: addappid(1395730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395731, 1, "138d4bb653d263e7b843a708aa3f97ed48619d5c36712ebf4808b05f5562efae")
