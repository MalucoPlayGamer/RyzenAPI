-- Lua provided by RyzenAPI
-- Game: Jeklynn Heights

-- MAIN APPLICATION
addappid(246820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(246821, 1, "8bcc1a83fbdcfb31004779d69e5cb6b70670ca3b5b7505c23d1229c3da45d01f")

