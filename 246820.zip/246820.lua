-- Lua provided by RyzenAPI
-- Game: Game: Jeklynn Heights

-- MAIN APPLICATION
addappid(246820)
-- Game: addappid(246820)

-- MAIN APP DEPOTS / PACKAGES
addappid(246821, 1, "8bcc1a83fbdcfb31004779d69e5cb6b70670ca3b5b7505c23d1229c3da45d01f")
