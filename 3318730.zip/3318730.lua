-- Lua provided by RyzenAPI
-- Game: Anomalies Detective

-- MAIN APPLICATION
addappid(3318730)
addappid(3435740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318731, 1, "198ebc8821616983c8b14c688db4c01221c341defbc8ec6028fa3e2f8aa0c65e")

