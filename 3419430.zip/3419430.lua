-- Lua provided by RyzenAPI
-- Game: 3419430

-- MAIN APPLICATION
addappid(3419430)
-- Game: addappid(3419430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419431, 1, "ad41f244684b3ba8f8462a3b365e80a6a35012eeafa998c96664f5efc1497c0f")
