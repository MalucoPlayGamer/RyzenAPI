-- Lua provided by SkyAPI 
-- Game: Rogue Lords - Original Soundtrack
addappid(1556030)
addappid(1556031, 1, "71c0622241156b9cb6d6c961048bf8664d39217144008f339e5357ba5a3a8b14")
addappid(1556032, 1, "452eb1b7837f8818c5e955cfad7ff0e71654488212892dfe94b58930e69ac654")
