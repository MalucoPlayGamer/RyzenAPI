-- Lua provided by RyzenAPI
-- Game: Slap Fight

-- MAIN APPLICATION
addappid(2022980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022981, 1, "9613575fd4847a878447be0690d8133add5235a313f625c8384f0bf0b5a623ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
