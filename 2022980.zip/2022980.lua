-- Lua provided by RyzenAPI
-- Game: Game: Slap Fight

-- MAIN APPLICATION
addappid(2022980)
-- Game: addappid(2022980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022981, 1, "9613575fd4847a878447be0690d8133add5235a313f625c8384f0bf0b5a623ae")
