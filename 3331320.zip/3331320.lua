-- Lua provided by RyzenAPI
-- Game: addappid(3331320)

-- MAIN APPLICATION
addappid(3331320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331321, 1, "c5b4f37efe1db24fa5a3c645176980193cd8a9895fee4e7fe6a733f96cea3110")
