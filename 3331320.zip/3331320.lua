-- Lua provided by RyzenAPI
-- Game: Back in Service: a Metro Driver

-- MAIN APPLICATION
addappid(3331320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331321, 1, "c5b4f37efe1db24fa5a3c645176980193cd8a9895fee4e7fe6a733f96cea3110")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
