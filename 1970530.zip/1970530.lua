-- Lua provided by RyzenAPI
-- Game: addappid(1970530)

-- MAIN APPLICATION
addappid(1970530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970531, 1, "6cf9b2e790f6b3f310cd9cf2e3a5338d999410115199fec99b38764a3eac2115")
