-- Lua provided by SkyAPI 
-- Game: Long Journey
addappid(1970530)
addappid(1970531, 1, "6cf9b2e790f6b3f310cd9cf2e3a5338d999410115199fec99b38764a3eac2115")
