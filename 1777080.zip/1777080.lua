-- Lua provided by RyzenAPI
-- Game: Game: AppID 1777080

-- MAIN APPLICATION
addappid(1777080)
-- Game: addappid(1777080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777081, 1, "750c6a86e24a372c05f3b23f900f972ca8ebcfb6e9b2f0282c0e20d540d6a29e")
