-- Lua provided by RyzenAPI
-- Game: The Crew

-- MAIN APPLICATION
addappid(313670) -- The Crew Season Pass - Uplay Activation
addappid(314080) -- The Crew Raid Car Pack - Uplay Activation
addappid(314090) -- The Crew Extreme Car Pack - Uplay Activation
addappid(314091) -- The Crew Speed Car Pack - Uplay Activation
addappid(314092) -- The Crew Vintage Car Pack - Uplay Activation
addappid(314093) -- The Crew Street Edition Pack - Uplay Activation
addappid(314100) -- The Crew WW - Uplay Activation
addappid(314101) -- The Crew RU - Uplay Activation
addappid(314110) -- THE CREW (CLOSED BETA) UPLAY ACTIVATION KEY
addappid(315380) -- The Crew JP - Uplay Activation
addappid(315381) -- The Crew IN - Uplay Activation
addappid(315382) -- The Crew WW Pre-order - Uplay Activation
addappid(315383) -- The Crew RU Pre-order - Uplay Activation
addappid(315384) -- The Crew JP Pre-order - Uplay Activation
addappid(315385) -- The Crew IN Pre-order - Uplay Activation
addappid(315386) -- The Crew WW Gold - Uplay Activation
addappid(315387) -- The Crew RU Gold - Uplay Activation
addappid(315388) -- The Crew JP Gold - Uplay Activation
addappid(315389) -- The Crew IN Gold - Uplay Activation
addappid(315392) -- The Crew Raid Car Pack
addappid(315393) -- The Crew Speed Car Pack
addappid(315394) -- The Crew Extreme Car Pack
addappid(315395) -- The Crew Vintage Car Pack
addappid(315396) -- The Crew Season Pass
addappid(315397) -- The Crew Street Edition Pack
addappid(418990) -- The Crew Wild Run
addappid(420200) -- The Crew Wild Run - Uplay Activation
addappid(512350) -- The Crew Calling All Units
-- addappid(241565) -- Depot 241565 (empty depot)
-- addappid(241566) -- Depot 241566 (empty depot)
-- addappid(241567) -- Depot 241567 (empty depot)
-- addappid(241568) -- Depot 241568 (empty depot)
-- addappid(241569) -- Depot 241569 (empty depot)
-- addappid(241570) -- Depot 241570 (empty depot)
-- addappid(241571) -- Depot 241571 (empty depot)
-- addappid(241572) -- Depot 241572 (empty depot)
-- addappid(241573) -- Depot 241573 (empty depot)
-- addappid(241574) -- Depot 241574 (empty depot)
-- addappid(241575) -- Depot 241575 (empty depot)
-- addappid(241576) -- Depot 241576 (empty depot)
-- addappid(241577) -- Depot 241577 (empty depot)
-- addappid(241578) -- Depot 241578 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(241560, 1, "97adf4cb577ee12b52d9c2aa2d509877ae678e28236900f28d13673f46255748") -- The Crew
addappid(241561, 1, "1be1e7dac5110de350ec4e8bef5adeb9f3462a7b97b0816158c163a30a634e8b") -- WW
addappid(241562, 1, "8aadd8a2edf897c35e27b15ad03ef8b4eab7b060324519e59988e290391dcafc") -- RUS
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
addtoken(313670, "16737821668958723677")
addtoken(314080, "8716120553897170865")
addtoken(314100, "11528921465513125814")
addtoken(315386, "17591918021080711400")
addtoken(315394, "3698383146685848668")
addtoken(315395, "2179651639632082337")
addtoken(315396, "6165790443118215652")
addtoken(315397, "3750957580353811096")
addtoken(420200, "3535908922707767478")

