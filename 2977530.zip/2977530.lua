-- Lua provided by RyzenAPI
-- Game: Skull and Bones - Free Trial

-- MAIN APPLICATION
addappid(2977530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
addappid(2853731,0,"714fcb880dabe47d44a94ed0315e88d867583916d2e1c24d26b648f73870ee9f")

