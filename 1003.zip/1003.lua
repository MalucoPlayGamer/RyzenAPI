-- Lua provided by RyzenAPI
-- Game: Rag Doll Kung Fu Demo

-- MAIN APPLICATION
addappid(1003)
-- Game: addappid(1003)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004, 1, "f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
