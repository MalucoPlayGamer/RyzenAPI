-- Lua provided by SkyAPI 
-- Game: Escape2088
addappid(1440130)
addappid(1440131, 1, "333bb94e0f60e7aa3e54e313243cb08064ed83876808c66f5a8a869eaa8d1730")
