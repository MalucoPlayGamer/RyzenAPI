-- Lua provided by RyzenAPI
-- Game: Game: Escape2088

-- MAIN APPLICATION
addappid(1440130)
-- Game: addappid(1440130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440131, 1, "333bb94e0f60e7aa3e54e313243cb08064ed83876808c66f5a8a869eaa8d1730")
