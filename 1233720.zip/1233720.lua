-- Lua provided by RyzenAPI
-- Game: 1233720

-- MAIN APPLICATION
addappid(1233720)
-- Game: addappid(1233720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233721, 1, "953a972e58ea3013355bfaeabc9b4b540be206a030cca38e3d4125abe6129ead")
