-- Lua provided by RyzenAPI
-- Game: SimplePlanes VR

-- MAIN APPLICATION
addappid(228990)
addappid(1692700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692703,0,"d4303520d402baa1a52f06d6a6a43a9e4e0fadb169222cbd1d44f6f68c06bcba")
addappid(1692704,0,"2822f329af7083c8fb2a0e0ba1c38d1cde257db6aa9427db3115f0de113deb68")

