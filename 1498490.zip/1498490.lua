-- Lua provided by RyzenAPI
-- Game: Game: Dead Herring VR

-- MAIN APPLICATION
addappid(1498490)
-- Game: addappid(1498490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498491, 1, "6f12c4b00d6c058302f543b4f833184689028086dc9d6db7122be492e66ded10")
