-- Lua provided by RyzenAPI 
-- Game: The Legend of Tianding
addappid(1406850)
addappid(1406851, 1, "8a1f9d6033a9c58f1b2e131bd984f57d15b48162ec6d0f6c6df575a6403aea7c")
addappid(1406852, 1, "9b6dfe98ea1640f3fc7bbaa82ef68c4721cc6f664268f45ba481df608eb56ac1")
addappid(1406853, 1, "e7bb89fde7f15c274f524acc8b20b7b0c1ef0be1f23fbc2740a7b6c6ef84f22a")
addappid(1406854, 1, "82bb698ede2c95dbba26d7cb655fd4014553082f138745fff0494b6822540dee")
