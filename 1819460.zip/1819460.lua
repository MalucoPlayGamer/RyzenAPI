-- Lua provided by RyzenAPI
-- Game: AppID 1819460

-- MAIN APPLICATION
addappid(1819460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819461, 1, "9a49390f0d51e7adc680b6ad02d11982f4cef3eea7617f744eb842ccfbed979d")
