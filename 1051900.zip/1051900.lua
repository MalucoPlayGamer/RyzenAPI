-- Lua provided by RyzenAPI
-- Game: addappid(1051900)

-- MAIN APPLICATION
addappid(1051900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051901, 1, "b36433864ad3ab34a56199cccdab973ef27ca9957d7d9d71fef1d78050562d81")
