-- Lua provided by SkyAPI 
-- Game: AppID 1051900
addappid(1051900)
addappid(1051901, 1, "b36433864ad3ab34a56199cccdab973ef27ca9957d7d9d71fef1d78050562d81")
