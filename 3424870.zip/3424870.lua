-- Lua provided by RyzenAPI
-- Game: The Throng

-- MAIN APPLICATION
addappid(3424870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424871, 1, "f17907af573e95d40fd23a07b74ce6deb75d20544230acb70b4c5fa1da6214f1")

