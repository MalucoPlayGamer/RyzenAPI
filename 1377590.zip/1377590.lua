-- Lua provided by RyzenAPI
-- Game: The Island

-- MAIN APPLICATION
addappid(1377590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1377591, 1, "23a1458d93267f2cb613963739765676362486e99156b70ec48b9edbea20e2b1")

