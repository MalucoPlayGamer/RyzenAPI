-- Lua provided by RyzenAPI
-- Game: The Island

-- MAIN APPLICATION
addappid(1377590)
-- Game: addappid(1377590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377591, 1, "23a1458d93267f2cb613963739765676362486e99156b70ec48b9edbea20e2b1")
