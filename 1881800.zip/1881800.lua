-- Lua provided by RyzenAPI
-- Game: CatNab

-- MAIN APPLICATION
addappid(1881800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881801, 1, "44dcf1dbb86531c912e6c7ae99c6d1844eb9ce02d2af5c6017078ceed8eb7f99")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
