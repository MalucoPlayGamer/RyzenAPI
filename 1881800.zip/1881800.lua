-- Lua provided by RyzenAPI
-- Game: CatNab

-- MAIN APPLICATION
addappid(1881800)
-- Game: addappid(1881800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881801, 1, "44dcf1dbb86531c912e6c7ae99c6d1844eb9ce02d2af5c6017078ceed8eb7f99")
