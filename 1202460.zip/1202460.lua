-- Lua provided by RyzenAPI
-- Game: Sayonara Wild Hearts - Original Soundtrack

-- MAIN APPLICATION
addappid(1202460)
-- Game: addappid(1202460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202461, 1, "5bc2f770dfb8a79a86e0f906eed5d346b02cfab2f5b5a7d90e4304cfa54f8755")
