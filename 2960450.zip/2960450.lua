-- Lua provided by RyzenAPI
-- Game: AURA: Hentai Cards - Horny Madness DLC

-- MAIN APPLICATION
addappid(2960450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960450,0,"9ff25f8159273828ed0fde4a068b675b2d8caaa3230a32fe57e43a8a4d772ce6")

