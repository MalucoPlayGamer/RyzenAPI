-- Lua provided by RyzenAPI
-- Game: addappid(984600)

-- MAIN APPLICATION
addappid(984600)

-- MAIN APP DEPOTS / PACKAGES
addappid(984601, 1, "8b55ecd882303f4535d0b5f7e376c42ceae515a3a874ca378854554b549baf45")
