-- Lua provided by RyzenAPI
-- Game: SAS: Zombie Assault 4

-- MAIN APPLICATION
addappid(678800)

