-- Lua provided by RyzenAPI
-- Game: 第七号列车 - Train No. 7 - 像素表情合集

-- MAIN APPLICATION
addappid(1742150)
-- Game: addappid(1742150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742150,0,"d1e4d325206637513711a62507f0ef6f505ff554655f153ee5d567ced03851e8")
