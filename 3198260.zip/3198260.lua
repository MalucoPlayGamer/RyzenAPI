-- Lua provided by RyzenAPI
-- Game: Small Dragon Big Appetite

-- MAIN APPLICATION
addappid(3198260)
-- Game: addappid(3198260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198261, 1, "54ef86a5ec6d5cabfb2baef6335ee197a9623ab9cd4fbcdb9bb61557c8ec95f2")
