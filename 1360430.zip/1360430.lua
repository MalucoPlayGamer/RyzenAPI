-- Lua provided by RyzenAPI
-- Game: Lapso: NIMBO

-- MAIN APPLICATION
addappid(1360430)
-- Game: addappid(1360430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360431, 1, "8481d7ca0e6eba813e565446067ed2e04e368f54c6465285dacf259d50a14704")
