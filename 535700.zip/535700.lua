-- Lua provided by RyzenAPI
-- Game: Game: 3D Chess

-- MAIN APPLICATION
addappid(535700)
-- Game: addappid(535700)

-- MAIN APP DEPOTS / PACKAGES
addappid(535701, 1, "fd90cc7df8442dc43d05fdc07d6721619e2d6c3a93772c8aaeb8e072d92748ac")
addappid(535702, 1, "8cb3e5c7d2d4d41dd51cbcb2c76e975eab76b69ae117af4d43d4aa634abd4153")
addappid(535703, 1, "c08429d3df81e306d2b3a05038a2faf202d4c5e7f12c9e3121398e2922424431")
