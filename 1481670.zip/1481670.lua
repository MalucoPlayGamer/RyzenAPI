-- Lua provided by RyzenAPI
-- Game: Hollywood Hero

-- MAIN APPLICATION
addappid(1481670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481671, 1, "5017247693a78cbdfbe2b537b40211e3c185d98bc60ab25ea9d58eeeacc9141b")

