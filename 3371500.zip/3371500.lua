-- Lua provided by SkyAPI 
-- Game: 傲世修仙录
addappid(3371500)
addappid(3371501, 1, "644d6bac7e76ca6d90494b49b2054b8dfc53e29cbe0b36d68da8a993e826f66b")
