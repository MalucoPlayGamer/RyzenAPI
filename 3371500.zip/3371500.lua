-- Lua provided by RyzenAPI
-- Game: 傲世修仙录

-- MAIN APPLICATION
addappid(3371500)
-- Game: addappid(3371500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371501, 1, "644d6bac7e76ca6d90494b49b2054b8dfc53e29cbe0b36d68da8a993e826f66b")
