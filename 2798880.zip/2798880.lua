-- Lua provided by RyzenAPI
-- Game: Game: DJ SIMULATOR

-- MAIN APPLICATION
addappid(2798880)
-- Game: addappid(2798880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2798881, 1, "f4ed4218dc4ce5d2ea81bbe6e4e4f8d5927cf26c79bbeec404f4a509420ee9e9")
