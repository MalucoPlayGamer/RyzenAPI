-- Lua provided by RyzenAPI
-- Game: Rocketbirds 2 Evolution

-- MAIN APPLICATION
addappid(470210)
addappid(582240)
addappid(628790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(470211, 1, "f4ff02ad92f27b7dba731ccc995a8392124b428af030b4a9562e81612005005c")
addappid(470212, 1, "1225b7ecc3afa56a7a92dbfd8b62d6c82406cd5c4a8302f241e9a97ba55dd20e")
addappid(578970, 0, "75c5ce5ca496b67c5a4c5d09d102b6e93d09dcac52b9c21a4b8e5cc45f01e365")

