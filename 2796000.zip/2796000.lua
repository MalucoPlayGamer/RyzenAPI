-- Lua provided by RyzenAPI
-- Game: Game: Planetary Life Demo

-- MAIN APPLICATION
addappid(2796000)
-- Game: addappid(2796000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796001, 1, "0d26aedb172a239eb17be498e7e4952ce9c3434add1493d899e323f26f93a763")
