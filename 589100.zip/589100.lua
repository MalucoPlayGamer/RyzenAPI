-- Lua provided by RyzenAPI
-- Game: Game: AppID 589100

-- MAIN APPLICATION
addappid(589100)
-- Game: addappid(589100)

-- MAIN APP DEPOTS / PACKAGES
addappid(589101, 1, "30694ca048e0ae35b8482d06ac7071faf9ec6d2b0330a4f2a879975607c9d9ab")
