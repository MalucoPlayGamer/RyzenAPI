-- Lua provided by RyzenAPI 
-- Game: AppID 589100
addappid(589100)
addappid(589101, 1, "30694ca048e0ae35b8482d06ac7071faf9ec6d2b0330a4f2a879975607c9d9ab")
