-- Lua provided by RyzenAPI
-- Game: 934200

-- MAIN APPLICATION
addappid(934200)
-- Game: addappid(934200)

-- MAIN APP DEPOTS / PACKAGES
addappid(934200,0,"d7e36eb610e9e98bead83dd7ab135165eae43a2fc6cf09178e97a59c4e24eae2")
