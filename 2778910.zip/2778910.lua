-- Lua provided by RyzenAPI
-- Game: Succubus 2069 Demo

-- MAIN APPLICATION
addappid(2778910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778911, 1, "e74b324699c27821ae61839fdbea98e500acfba238458f17c06c65d7fc4ee45b")
