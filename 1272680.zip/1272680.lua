-- Lua provided by RyzenAPI
-- Game: Game: Umihara Kawase Fresh!

-- MAIN APPLICATION
addappid(1272680)
-- Game: addappid(1272680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272681, 1, "bd24c028ea07cbfb555b48144cfcb34ce76a924c886099a4c7b15954591092c0")
