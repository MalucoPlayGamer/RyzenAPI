-- Lua provided by RyzenAPI
-- Game: Pillars Of Protection Playtest

-- MAIN APPLICATION
addappid(1709480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709481, 1, "6f1aa5d13384d55a19ce5e3b49a6cde12ff81fae842cb296fbbd9d8ffb2ecfbd")

