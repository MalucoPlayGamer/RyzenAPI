-- Lua provided by SkyAPI 
-- Game: Pillars Of Protection Playtest
addappid(1709480)
addappid(1709481, 1, "6f1aa5d13384d55a19ce5e3b49a6cde12ff81fae842cb296fbbd9d8ffb2ecfbd")
