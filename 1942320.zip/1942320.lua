-- Lua provided by RyzenAPI
-- Game: World's Worst Handyman Demo

-- MAIN APPLICATION
addappid(1942320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942321, 1, "ab2d9b10009cdf611188685e0a6730fbd3853b6101c38674f6be0aaf7d6f53f1")

