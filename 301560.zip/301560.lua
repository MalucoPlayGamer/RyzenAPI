-- Lua provided by RyzenAPI
-- Game: White Night

-- MAIN APPLICATION
addappid(301560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(301561, 1, "13527bba6ab42451763e95c2b70f9a9c2ea55a58fd4c76bf714dcfad339af01a")
addappid(301562, 1, "f75606a230246d3c9b3dd8f360b302921d1af31ea4a9265e8c0ca27f5b091c55")
addappid(301563, 1, "64228a8230587be3f6331a121727e24dc92023974244ae9bbffe52f30c619e84")
addappid(301564, 1, "25096f11550b6b5a601f3fd69e3cc7b8d72ce31fc3315ac9b2abc9c2e128524b")
addappid(301565, 1, "5db8029fe7b840ef7300af93f38c3cf7a7f324ec49ae198a87cde063c6c5b1a3")
addappid(301566, 1, "a8ecb0aaba20bfa7aa358764412737b2299a75c3da761f079f188b897ce559d7")
addappid(301567, 1, "2beb8c3334adf83de4dc960f7c35db679ff2220cdc2c9ff0ed03b7d4ef362111")
