-- Lua provided by RyzenAPI
-- Game: Diamond Hands: To The Moon

-- MAIN APPLICATION
addappid(1727810)
-- Game: addappid(1727810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727811, 1, "7cc6ff443aeb430353545f9df69b81f9c865737cfecf7f74f1d47248e21d32b5")
addappid(1727812, 1, "afe8a733bba1c615c234562e7654fcc32bd2352246b09d109b33484365270bdd")
