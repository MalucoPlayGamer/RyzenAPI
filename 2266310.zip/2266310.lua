-- Lua provided by RyzenAPI
-- Game: 2266310

-- MAIN APPLICATION
addappid(2266310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266310,0,"b9ec07f1f0d9be5c620862b6bcfbbd6c7748c1fbef55bab0e3b191b46435071d")

