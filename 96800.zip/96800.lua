-- Lua provided by RyzenAPI
-- Game: Nexuiz

-- MAIN APPLICATION
addappid(96800)
-- Game: addappid(96800)

-- MAIN APP DEPOTS / PACKAGES
addappid(96801, 1, "2f387e4c71abb677bb15e0dbb9c482ec7d2a4c212fa7422d5716b7482bf8a6a2")
