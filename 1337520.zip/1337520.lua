-- Lua provided by RyzenAPI
-- Game: Game: Risk of Rain Returns

-- MAIN APPLICATION
addappid(1337520)
-- Game: addappid(1337520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337521, 1, "d29ccb9d1e840ba82ffc903c35e40c258c9552e4260a57e3fe2626a181cdb195")
