-- Lua provided by RyzenAPI
-- Game: 1529790

-- MAIN APPLICATION
addappid(1529790)
-- Game: addappid(1529790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529791, 1, "bc0e1cc8b96fd29dfe2f499e906505f5dd2c35d8067fcc0792b7f6c39979053a")
