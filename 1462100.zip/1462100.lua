-- Lua provided by RyzenAPI
-- Game: addappid(1462100)

-- MAIN APPLICATION
addappid(1462100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462101, 1, "5b5edebbece91286940698acf954bec5c0c0742b3c4f3caf62667014879219f8")
