-- Lua provided by RyzenAPI
-- Game: Cipheur

-- MAIN APPLICATION
addappid(3469820)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3559270)
addappid(3559280)
addappid(3559290)
addappid(3559300)
addappid(3570970)
addappid(3570980)
addappid(3570990)
addappid(3571000)
addappid(3571090)
addappid(3571100)
addappid(3571230)
addappid(3571250)
addappid(3571260)
addappid(3571270)
addappid(3571280)
addappid(3571290)
addappid(3580550)
addappid(3580560)
addappid(3580570)
addappid(3580590)
addappid(3650870)
addappid(3650880)
addappid(3650890)
addappid(3865260)
addappid(3865270)
addappid(3865280)
addappid(3865290)
addappid(3874840)
addappid(3954190)
addappid(4254030)
addappid(4254040)
