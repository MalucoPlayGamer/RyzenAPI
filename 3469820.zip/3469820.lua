-- Lua provided by RyzenAPI
-- Game: Cipheur

-- MAIN APPLICATION
addappid(3469820)
