-- Lua provided by RyzenAPI
-- Game: Hotline Miami 2: Wrong Number Digital Comic

-- MAIN APPLICATION
addappid(341190)
-- Game: addappid(341190)

-- MAIN APP DEPOTS / PACKAGES
addappid(341191, 1, "aa65a72a2382da6d7218eee8bb53c711bdf28cb6ec1257ca05b0fc530b1d3d56")
addappid(341192, 1, "f18d77314597474e1f0215ca3d89011a2c2337e3ee0f17084e4ac0af629b41f3")
addappid(341193, 1, "7e7dbf1efea82a3370fe61bddf5e4d9e56b9ab522459fa732c80bfc0082d9fb0")
addappid(341194, 1, "9f49bf887b71b86239ebae78bc78912f99df649209e57a3e92ab4fd86a693014")
addappid(341195, 1, "16473c2f7f587ba81482238d9b93b04d38c4db480723c798fc03a2aba2b18090")
addappid(341196, 1, "9e5c2c9adb7000ea7395d5c2f179776fc71a7a5f0fc6cb066a1d2f5daa0a2d45")
