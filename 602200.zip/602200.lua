-- Lua provided by RyzenAPI 
-- Game: AppID 602200
addappid(602200)
addappid(602201, 1, "29b22b7eee675d455b839ff837188b115a59a2751870327592a712f7b4a5840e")
addappid(602202, 1, "1cd8fdf9b1a22134ac618b5d1a8b4994e42e2cc7a8133e960d94e569cc45a9b6")
