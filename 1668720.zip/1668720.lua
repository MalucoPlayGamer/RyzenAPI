-- Lua provided by RyzenAPI
-- Game: The Cloud Dream of the Nine

-- MAIN APPLICATION
addappid(1668720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668721, 1, "6980285c639b9deb1dbea94e236b497f25e9686a022b508a3cf54891c41b18f9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1797900)
addappid(1816460)
