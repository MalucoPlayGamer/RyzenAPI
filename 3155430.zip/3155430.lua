-- Lua provided by RyzenAPI
-- Game: 3155430

-- MAIN APPLICATION
addappid(3155430)
-- Game: addappid(3155430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155431, 1, "c9290fc1a41f85a41148afce2a76e21d46b02967ad37afb04ef99be396bf5e36")
