-- Lua provided by RyzenAPI
-- Game: Game: AppID 404640

-- MAIN APPLICATION
addappid(404640)
-- Game: addappid(404640)

-- MAIN APP DEPOTS / PACKAGES
addappid(404641, 1, "87365fa0a0fd20c93916f2d5d1d54162f11990987c0c8215835b8946c7150caa")
