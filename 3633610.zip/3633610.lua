-- Lua provided by RyzenAPI
-- Game: Game: Nif Nif Soundtrack

-- MAIN APPLICATION
addappid(3633610)
-- Game: addappid(3633610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3633611, 1, "4b784bd265b6251962c5ce923075d0f1f592f84651247a1195d5ee92e3c3fa39")
addappid(3633612, 1, "3cc8c129c00cce01f727a64e74918bbee2d350955395295dbaac2d59d736c94c")
