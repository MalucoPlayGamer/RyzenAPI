-- Lua provided by SkyAPI 
-- Game: Sift Heads Cartels
addappid(2910320)
addappid(2910321, 1, "a9d8e1fbeb399d82bd3e2f1499338d35ed8a74cd6c87443a7697f11e089d5e22")
