-- Lua provided by RyzenAPI
-- Game: Cognition: An Erica Reed Thriller

-- MAIN APPLICATION
addappid(242780)
addappid(254420)
addappid(254421)
addappid(254422)
addappid(254423)
addappid(316671)

-- MAIN APP DEPOTS / PACKAGES
addappid(242781, 1, "770fc9b687d5bf0b9251e9c6547acc1c509e69e5050256e9f9ac127629648947")
addappid(242782, 1, "f8d68ac831c35e9765b006ef0cc8b7b93a1806476f5c2904401d8d6fa75060a4")
addappid(242783, 1, "6a3e9a7c37c78064e41c6b1ea205decbc5816af5e4a0ac3a5bb9a9b6cdbe8851")
addappid(242784, 1, "1160e33e17dc3de3e17254182418e66fd4f66924cc0672904f63b6b9892cd94a")
addappid(242789, 1, "9d63741a8738fa51d3b14cc5a0f22c6eeb026fe4a16cd5ccfaa13074feda5b9a")
addappid(242790, 1, "28dd69700f30c8c7180450564b4aac7f7553ef16871a8abd90952cf02306aa12")
addappid(316670, 0, "21f98d65a1c9a50b27785b4e1778da677d399d4499667b4426858f4faac68da9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
