-- 1049890's Lua and Manifest Created by Hubcap Manifest
-- Little Witch Nobeta
-- Created: September 29, 2025 at 22:22:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(1049890) -- Little Witch Nobeta
-- MAIN APP DEPOTS
addappid(1049891, 1, "02153bc2f7fd0301d7e52983cd2429bbd69d280649f652f8faa9ac441df65fca") -- Little Witch Nobeta Depot
setManifestid(1049891, "1739799627887432021", 10886041899)
-- DLCS WITH DEDICATED DEPOTS
-- Little Witch Nobeta Collectors Edition (Digital) (AppID: 2153360)
addappid(2153360)
addappid(2153360, 1, "852cd09a882f3c97208c4fd6f531d689ef49a3ebd9f9ccfe3a86539cf74a67af") -- Little Witch Nobeta Collectors Edition (Digital) - Depot 2153360
setManifestid(2153360, "1571709003743138085", 755927401)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2152390) -- Little Witch Nobeta - Bunny  Bear Muppet Skin Bundle
addappid(2242530) -- Little Witch Nobeta - Midnight Kitty, Chinese Dress  Nurse Skin Bundle
addappid(2465440) -- Little Witch Nobeta - Dragon Princess, Knitted Uniform  Land Mine Girl Skin Bundle