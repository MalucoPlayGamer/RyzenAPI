-- Lua provided by RyzenAPI
-- Game: Little Witch Nobeta

-- MAIN APPLICATION
addappid(1049890) -- Little Witch Nobeta
addappid(2152390) -- Little Witch Nobeta - Bunny  Bear Muppet Skin Bundle
addappid(2153360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049891, 1, "02153bc2f7fd0301d7e52983cd2429bbd69d280649f652f8faa9ac441df65fca") -- Little Witch Nobeta Depot
addappid(2153360, 1, "852cd09a882f3c97208c4fd6f531d689ef49a3ebd9f9ccfe3a86539cf74a67af") -- Little Witch Nobeta Collectors Edition (Digital) - Depot 2153360
addappid(2242530) -- Little Witch Nobeta - Midnight Kitty, Chinese Dress  Nurse Skin Bundle
addappid(2465440) -- Little Witch Nobeta - Dragon Princess, Knitted Uniform  Land Mine Girl Skin Bundle

