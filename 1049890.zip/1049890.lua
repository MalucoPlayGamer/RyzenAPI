-- Lua provided by RyzenAPI
-- Game: Little Witch Nobeta

-- MAIN APPLICATION
addappid(1049890)
-- Game: addappid(1049890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049891, 1, "02153bc2f7fd0301d7e52983cd2429bbd69d280649f652f8faa9ac441df65fca")
addappid(2153360, 0, "852cd09a882f3c97208c4fd6f531d689ef49a3ebd9f9ccfe3a86539cf74a67af")
