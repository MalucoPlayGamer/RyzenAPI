-- Lua provided by RyzenAPI
-- Game: 2899040

-- MAIN APPLICATION
addappid(2899040)
-- Game: addappid(2899040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899041, 1, "bf09fa8a6e67aa0dca60f6fe2ff06c35d817f2af1d185644e5e32587fa79190b")
