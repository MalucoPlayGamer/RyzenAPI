-- Lua provided by RyzenAPI
-- Game: Midnight Lane

-- MAIN APPLICATION
addappid(2899040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2899041, 1, "bf09fa8a6e67aa0dca60f6fe2ff06c35d817f2af1d185644e5e32587fa79190b")

