-- Lua provided by SkyAPI 
-- Game: Midnight Lane
addappid(2899040)
addappid(2899041, 1, "bf09fa8a6e67aa0dca60f6fe2ff06c35d817f2af1d185644e5e32587fa79190b")
