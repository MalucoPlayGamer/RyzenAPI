-- Lua provided by RyzenAPI
-- Game: Game: Vampire: The Masquerade - Redemption

-- MAIN APPLICATION
addappid(559680)
-- Game: addappid(559680)

-- MAIN APP DEPOTS / PACKAGES
addappid(559681, 1, "b55a65886880f3beca6f236d4e4686dbb59b1ce92a178273e6790b484d6cca02")
addappid(559682, 1, "8a43798f0163b4801eccebfcd3725508e1e1595dc960e367fb17187cf83ee2cb")
