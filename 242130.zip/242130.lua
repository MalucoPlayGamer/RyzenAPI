-- Lua provided by RyzenAPI
-- Game: Vector Thrust

-- MAIN APPLICATION
addappid(242130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(242131, 1, "b55c3820189dd5bdf8a3f2f2e05a7ee4a96e787fb46584cd54cf249ecd988f4b")

