-- Lua provided by SkyAPI 
-- Game: AppID 242130
addappid(242130)
addappid(242131, 1, "b55c3820189dd5bdf8a3f2f2e05a7ee4a96e787fb46584cd54cf249ecd988f4b")
