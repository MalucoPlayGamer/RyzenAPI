-- Lua provided by SkyAPI 
-- Game: AppID 1452220
addappid(1452220)
addappid(1452221, 1, "a655e07fd398ae47e79b7c7d02fd61126ceb4e694f1609b1c45f765a1c097ab2")
