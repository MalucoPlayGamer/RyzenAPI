-- Lua provided by RyzenAPI 
-- Game: AppID 1237560
addappid(1237560)
addappid(1237561, 1, "ea74f34134b5d0e25f942eab3b5958091556b04021bd2e433b9ae8ed12ad03f6")
