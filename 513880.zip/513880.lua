-- Lua provided by RyzenAPI
-- Game: 513880

-- MAIN APPLICATION
addappid(513880)
-- Game: addappid(513880)

-- MAIN APP DEPOTS / PACKAGES
addappid(513881, 1, "13b388029d5bfe323c871c5ef2625e95fc9969568b2030daa2e21ecf14b61f2a")
addappid(513882, 1, "c2c4111affc4f96c03f2ee8ef8ee4ea049ff05b5efd0660c0a5fd3eced519de7")
addappid(513883, 1, "2334ccd5d78dfa8fabb50ffce63d3ab356b2f910fae927982266e9609aa22df5")
addappid(513884, 1, "7315287685062494193c1ed3a586078f6a6c56829ff527de6101df0cd794fbd2")
