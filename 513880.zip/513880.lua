-- Lua provided by RyzenAPI
-- Game: Panzer Warfare

-- MAIN APPLICATION
addappid(513880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(513881, 1, "13b388029d5bfe323c871c5ef2625e95fc9969568b2030daa2e21ecf14b61f2a")
addappid(513882, 1, "c2c4111affc4f96c03f2ee8ef8ee4ea049ff05b5efd0660c0a5fd3eced519de7")
addappid(513883, 1, "2334ccd5d78dfa8fabb50ffce63d3ab356b2f910fae927982266e9609aa22df5")
addappid(513884, 1, "7315287685062494193c1ed3a586078f6a6c56829ff527de6101df0cd794fbd2")

