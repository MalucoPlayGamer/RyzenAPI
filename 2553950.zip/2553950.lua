-- Lua provided by SkyAPI 
-- Game: AppID 2553950
addappid(2553950)
addappid(2553951, 1, "81920fe134c7d837afc26ca532653b1d40861c45a326258318b35eea04f69118")
