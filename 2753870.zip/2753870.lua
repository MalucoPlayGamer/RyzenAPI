-- Lua provided by SkyAPI 
-- Game: Kickback: Shoot to Move! 👾
addappid(2753870)
addappid(2753871, 1, "13fa2936a46b22b23d6a8da3d747ccd2fb6664d0cb6f243e813b2f8cf8883e50")
