-- Lua provided by RyzenAPI
-- Game: Game: 镇邪

-- MAIN APPLICATION
addappid(1939560)
-- Game: addappid(1939560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939561, 1, "1fdf48f5e9571225c2f3dc6f1ef8f7268abe64543d5135b716358fceacf065de")
