-- Lua provided by RyzenAPI
-- Game: 3439760

-- MAIN APPLICATION
addappid(3439760)
-- Game: addappid(3439760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439761, 1, "85e53bd743c604720a49b296774e1d86b20dec07be4f8f75edd5c693eec04b65")
addappid(3439762, 1, "3d8ff3cdda63cb444e76eae624bfb61c8e92cb81364222deeae131e571e5f478")
