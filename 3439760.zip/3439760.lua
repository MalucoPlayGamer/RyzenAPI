-- Lua provided by SkyAPI 
-- Game: KARMA: The Dark World - Soundtrack
addappid(3439760)
addappid(3439761, 1, "85e53bd743c604720a49b296774e1d86b20dec07be4f8f75edd5c693eec04b65")
addappid(3439762, 1, "3d8ff3cdda63cb444e76eae624bfb61c8e92cb81364222deeae131e571e5f478")
