-- Lua provided by SkyAPI 
-- Game: AppID 1291010
addappid(1291010)
addappid(1291011, 1, "f61fc138f45f4d77105dc0fb4264842bd804e319f0fb57aece98ab3aba1e7027")
addappid(1606930, 0, "98cbd19911b710c59621568a9a64f6605a7a708e6e55f91d793497dc09c8b3ae")
