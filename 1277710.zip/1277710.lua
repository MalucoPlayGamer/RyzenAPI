-- Lua provided by RyzenAPI
-- Game: RoboDo

-- MAIN APPLICATION
addappid(1277710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1277711, 1, "4b24c6b2b3038b0528004798ed413b9bd47bf3e97073c4b399a19d0fda9e24e7")

