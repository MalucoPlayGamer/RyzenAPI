-- Lua provided by RyzenAPI
-- Game: Game: RoboDo

-- MAIN APPLICATION
addappid(1277710)
-- Game: addappid(1277710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277711, 1, "4b24c6b2b3038b0528004798ed413b9bd47bf3e97073c4b399a19d0fda9e24e7")
