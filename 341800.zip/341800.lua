-- Lua provided by RyzenAPI
-- Game: Keep Talking and Nobody Explodes

-- MAIN APPLICATION
addappid(341800)

-- MAIN APP DEPOTS / PACKAGES
addappid(341801, 1, "7a3268e19c324c33a765f5d6411b261b4025d30a399dc9cc1e279ec8d64f33c6")
addappid(341802, 1, "e2113a997e3ff5b772be46811bab8ec43ed7e423dc2737fc54626fbe2c2b49ef")
addappid(341803, 1, "8b152cd65ba73c1b340af9e6476ae1e2e9f288dcec76123797c0271bcdf89c5c")
addappid(341804, 1, "39749b7fbb22631d93260af41062aba00d0490e5aeff02e7c9f0258978f8be85")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
