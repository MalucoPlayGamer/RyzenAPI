-- Lua provided by RyzenAPI
-- Game: Game: Keep Talking and Nobody Explodes

-- MAIN APPLICATION
addappid(341800)
-- Game: addappid(341800)

-- MAIN APP DEPOTS / PACKAGES
addappid(341801, 1, "7a3268e19c324c33a765f5d6411b261b4025d30a399dc9cc1e279ec8d64f33c6")
addappid(341802, 1, "e2113a997e3ff5b772be46811bab8ec43ed7e423dc2737fc54626fbe2c2b49ef")
addappid(341803, 1, "8b152cd65ba73c1b340af9e6476ae1e2e9f288dcec76123797c0271bcdf89c5c")
addappid(341804, 1, "39749b7fbb22631d93260af41062aba00d0490e5aeff02e7c9f0258978f8be85")
