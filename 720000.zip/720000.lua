-- Lua provided by RyzenAPI
-- Game: Don't Panic!

-- MAIN APPLICATION
addappid(720000)

-- MAIN APP DEPOTS / PACKAGES
addappid(720001, 1, "9dd8c84b296801d2f14a801479f4c85ccade951c22daf7b5c8dc06c02ab6cd10")
addappid(720002, 1, "c24a5bffa51e2ae694ced2f95d3f98840b1c11406304e41a1a79a613a6f74c29")
addappid(720003, 1, "b63a099706edc89e25602eadc31fc28af069ca51fba48347ebd01ca0687ccc18")
addappid(720004, 1, "e1a5d53786720b3d56e537d1139a3dcdbeb315ea779b446bc90b7988d608e56a")

