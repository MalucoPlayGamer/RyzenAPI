-- Lua provided by RyzenAPI
-- Game: Return from Core

-- MAIN APPLICATION
addappid(2171630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171631, 1, "a62e00fd9be41fb3cf0c73af2986f688272d6f372e802565be89f70c48a22bef")

