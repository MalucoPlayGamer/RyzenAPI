-- Lua provided by RyzenAPI
-- Game: Missing Pictures : Catherine Hardwicke

-- MAIN APPLICATION
addappid(2177710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177711, 1, "226b40e6de9dd451f6de51da90ce4e2d18b9f12fa3c323b5d409d6fbb9933794")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
