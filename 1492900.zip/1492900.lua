-- Lua provided by RyzenAPI 
-- Game: The Alien Trials
addappid(1492900)
addappid(1492901, 1, "386418dd2970e84c08c117f878d07ecaafb99a5da599cb5e210599b31e029315")
