-- Lua provided by RyzenAPI
-- Game: The Alien Trials

-- MAIN APPLICATION
addappid(1492900)
-- Game: addappid(1492900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492901, 1, "386418dd2970e84c08c117f878d07ecaafb99a5da599cb5e210599b31e029315")
