-- Lua provided by RyzenAPI
-- Game: The Alien Trials

-- MAIN APPLICATION
addappid(1492900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492901, 1, "386418dd2970e84c08c117f878d07ecaafb99a5da599cb5e210599b31e029315")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
