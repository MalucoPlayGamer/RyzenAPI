-- Lua provided by RyzenAPI
-- Game: Game: One Dollar Simulator

-- MAIN APPLICATION
addappid(831470)
-- Game: addappid(831470)

-- MAIN APP DEPOTS / PACKAGES
addappid(831471, 1, "ee894da4a6399b8a7e62fb8d7b2cf5e4f55ea58f61e004133cdcfd2926efcfd8")
