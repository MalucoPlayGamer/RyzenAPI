-- Lua provided by RyzenAPI
-- Game: Game: Christmas Infinity

-- MAIN APPLICATION
addappid(3372960)
-- Game: addappid(3372960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372961, 1, "115c38d21d9c7683fb2bcb2202c3f62d80e7cc8c6f2d9a859bc5ed1b9900835f")
