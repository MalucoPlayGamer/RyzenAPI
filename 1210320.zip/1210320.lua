-- Lua provided by RyzenAPI
-- Game: Potion Craft: Alchemist Simulator

-- MAIN APPLICATION
addappid(1210320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210321, 1, "d8767749a4bd55e51cd4cc1c210399bbbcb0e728f7caab6cdcdabb84ed18d158")
