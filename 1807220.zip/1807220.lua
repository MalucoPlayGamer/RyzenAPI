-- Lua provided by RyzenAPI
-- Game: Game: Welcome to Empyreum

-- MAIN APPLICATION
addappid(1807220)
-- Game: addappid(1807220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807221, 1, "914b416b01a8840b5ed2e54a1ad89c495e9926c22ad55b5b9adce49f64fa4bb3")
