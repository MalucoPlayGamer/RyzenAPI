-- Lua provided by RyzenAPI
-- Game: Welcome to Empyreum

-- MAIN APPLICATION
addappid(1807220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1807221, 1, "914b416b01a8840b5ed2e54a1ad89c495e9926c22ad55b5b9adce49f64fa4bb3")

