-- Lua provided by RyzenAPI
-- Game: The Legend of Evil

-- MAIN APPLICATION
addappid(839520)

-- MAIN APP DEPOTS / PACKAGES
addappid(839521,0,"099ca2c2b7edf1369e2a495e884f41fe57e82e7d3a3ceb47cfe06405af4a4055")

