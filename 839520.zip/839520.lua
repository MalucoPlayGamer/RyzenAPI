-- Lua provided by RyzenAPI
-- Game: The Legend of Evil

-- MAIN APPLICATION
addappid(839520)

-- MAIN APP DEPOTS / PACKAGES
addappid(839521,0,"099ca2c2b7edf1369e2a495e884f41fe57e82e7d3a3ceb47cfe06405af4a4055")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
