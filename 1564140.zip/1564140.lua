-- Lua provided by RyzenAPI
-- Game: 白玉的幻梦 Dream of Hakugyokurou

-- MAIN APPLICATION
addappid(1564140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564141, 1, "d8913b9c2dbb023cc18e80219e3622272f095e33f9a7badb715e9c64d2306e82")

