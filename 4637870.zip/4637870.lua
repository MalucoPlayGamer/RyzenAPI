-- 4637870's Lua and Manifest Created by Hubcap Manifest
-- Smashing Bottles
-- Created: August 24, 2026 at 13:20:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4637870) -- Smashing Bottles
-- MAIN APP DEPOTS
addappid(4637871, 1, "74863986fe72af3be1700ffb29fa63f1c4e59b348f06b39b8f048501a467bdf9") -- Depot 4637871
setManifestid(4637871, "4383811216797806439", 182757992)
addappid(4637872, 1, "3eaf178b29fca3564a3efd3504bb912bad0de75094b6470ab2991ef09f601ccf") -- Depot 4637872
setManifestid(4637872, "1649866767030585615", 266116434)
addappid(4637873, 1, "6b2efb171d9a922a4cea9c376773c6eadbb9bb6470e5069b7661710a8911f02d") -- Depot 4637873
setManifestid(4637873, "1793346052842423960", 149617392)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4995210) -- Smashing Bottles - Supporter Pack