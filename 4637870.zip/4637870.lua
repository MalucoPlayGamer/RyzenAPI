-- Lua provided by RyzenAPI
-- Game: Smashing Bottles

-- MAIN APPLICATION
addappid(4637870) -- Smashing Bottles
addappid(4995210) -- Smashing Bottles - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4637871, 1, "74863986fe72af3be1700ffb29fa63f1c4e59b348f06b39b8f048501a467bdf9") -- Depot 4637871
addappid(4637872, 1, "3eaf178b29fca3564a3efd3504bb912bad0de75094b6470ab2991ef09f601ccf") -- Depot 4637872
addappid(4637873, 1, "6b2efb171d9a922a4cea9c376773c6eadbb9bb6470e5069b7661710a8911f02d") -- Depot 4637873

