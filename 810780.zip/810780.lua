-- Lua provided by RyzenAPI
-- Game: Game: RAIN Project - a touhou fangame

-- MAIN APPLICATION
addappid(810780)
-- Game: addappid(810780)

-- MAIN APP DEPOTS / PACKAGES
addappid(810781, 1, "da00beaacd0e1f3242a535f4af00236103befa524edc1ea67c3f29eea2762ad9")
