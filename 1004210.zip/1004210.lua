-- Lua provided by RyzenAPI
-- Game: Game: AppID 1004210

-- MAIN APPLICATION
addappid(1004210)
-- Game: addappid(1004210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004211, 1, "5b9cf776fa9e6ab3b6985daca10fd0521cb7e7ab311786530e265e42ecc79b15")
