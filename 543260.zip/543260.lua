-- Lua provided by RyzenAPI
-- Game: Wonder Boy: The Dragon's Trap

-- MAIN APPLICATION
addappid(543260)
addappid(649330)

-- MAIN APP DEPOTS / PACKAGES
addappid(543261, 1, "8be7d52c9a7bf3194f869abb115ae09f54626a3b66ec8a241a2cf74a7efb154f")
addappid(543262, 1, "beb8f036efa9a1c124619b6dba8c790b2786e6e79d0ef519fa8dc294ab457558")
addappid(543263, 1, "d6402d545e59f3d1a085f4f560829abc548f99ec853fef2334907b6f644e8828")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
