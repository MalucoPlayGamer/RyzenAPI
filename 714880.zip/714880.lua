-- Lua provided by RyzenAPI
-- Game: AppID 714880

-- MAIN APPLICATION
addappid(714880)
-- Game: addappid(714880)

-- MAIN APP DEPOTS / PACKAGES
addappid(714881, 1, "0bac11b8368a6d7fdd75a579c9b614af886cfda3d5dc662a502a88ff69b68f9f")
