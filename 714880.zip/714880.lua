-- Lua provided by RyzenAPI
-- Game: 大乱斗 Chaos Battle

-- MAIN APPLICATION
addappid(714880)

-- MAIN APP DEPOTS / PACKAGES
addappid(714881, 1, "0bac11b8368a6d7fdd75a579c9b614af886cfda3d5dc662a502a88ff69b68f9f")

