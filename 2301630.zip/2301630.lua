-- Lua provided by SkyAPI 
-- Game: Goblins
addappid(2301630)
addappid(2301631, 1, "992ba737353ff1bf81d3c7fb2464b2de26a1630cf4316f6ceed1fe979915f415")
