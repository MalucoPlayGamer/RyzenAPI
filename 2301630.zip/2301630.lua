-- Lua provided by RyzenAPI
-- Game: Goblins

-- MAIN APPLICATION
addappid(2301630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301631, 1, "992ba737353ff1bf81d3c7fb2464b2de26a1630cf4316f6ceed1fe979915f415")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
