-- Lua provided by RyzenAPI
-- Game: 2301630

-- MAIN APPLICATION
addappid(2301630)
-- Game: addappid(2301630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301631, 1, "992ba737353ff1bf81d3c7fb2464b2de26a1630cf4316f6ceed1fe979915f415")
