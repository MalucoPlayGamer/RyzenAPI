-- Lua provided by RyzenAPI
-- Game: addappid(2239390)

-- MAIN APPLICATION
addappid(2239390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239391, 1, "8623705055e3fea4e280e5f434aab19f0676ba63dd719abacee8da187d8745a8")
