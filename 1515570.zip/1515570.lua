-- Lua provided by SkyAPI 
-- Game: Elsie
addappid(1515570)
addappid(1515571, 1, "2f9830c51f06ee918cf39441ef892a41dc699cc5329f6089f7aadcb8bbd8736b")
