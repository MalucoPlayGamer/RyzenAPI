-- Lua provided by RyzenAPI
-- Game: After War Town

-- MAIN APPLICATION
addappid(2709300)
-- Game: addappid(2709300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709301, 1, "531b68e0d0df018cc051f33a32ff7b33534a027bc588cc73c0ecfabab91b66b9")
