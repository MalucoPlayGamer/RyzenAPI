-- Lua provided by RyzenAPI
-- Game: AppID 345480

-- MAIN APPLICATION
addappid(345480)
-- Game: addappid(345480)

-- MAIN APP DEPOTS / PACKAGES
addappid(345481, 1, "1d72c7f679f290f54b5aee943b53c9a93f748d7169f095d77bc9946d01ce9e91")
addappid(458220, 0, "c31fd6e3d31cdf4caf3ac24cabaff2f5326234ff72da7aab61831347dfe3b6d2")
