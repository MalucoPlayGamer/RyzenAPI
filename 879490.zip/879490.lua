-- Lua provided by RyzenAPI
-- Game: addappid(879490)

-- MAIN APPLICATION
addappid(879490)

-- MAIN APP DEPOTS / PACKAGES
addappid(879491, 1, "da2edebabfdf7168ecfcbd741198068caf6d06bd65231fb54219ec884bcfeeb9")
