-- Lua provided by RyzenAPI
-- Game: Game: AppID 1063540

-- MAIN APPLICATION
addappid(1063540)
-- Game: addappid(1063540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063541, 1, "769f847c505c6dc6fb9b6f59df7507681a4406379a3081f8d9a94a553b4f3744")
