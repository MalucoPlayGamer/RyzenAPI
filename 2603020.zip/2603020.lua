-- Lua provided by RyzenAPI
-- Game: Citadelum

-- MAIN APPLICATION
addappid(2603020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603021, 1, "7524dec83e20cc12831a547d7fec9d1b84f8541f334acf468d7e044f132d6e09")
