-- Lua provided by RyzenAPI
-- Game: Citadelum

-- MAIN APPLICATION
addappid(2603020)
addappid(3358500)
addappid(3450060)
addappid(3480880)
addappid(3896670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2603021, 1, "7524dec83e20cc12831a547d7fec9d1b84f8541f334acf468d7e044f132d6e09")

