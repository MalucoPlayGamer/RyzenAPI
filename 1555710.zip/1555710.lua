-- Lua provided by RyzenAPI
-- Game: 1555710

-- MAIN APPLICATION
addappid(1555710)
-- Game: addappid(1555710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555711, 1, "a812e752bcf321fafa49029dcbded501f69727afaf47b818ac27d76a5cb3f717")
