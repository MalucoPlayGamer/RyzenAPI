-- Lua provided by RyzenAPI
-- Game: FURIDASHI: Drift Cyber Sport

-- MAIN APPLICATION
addappid(658570)

-- MAIN APP DEPOTS / PACKAGES
addappid(658571, 1, "c26927e3da89aa27e58e09c2297e25acda2a8fefc18ef728aa907757ca130edf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(731010)
addappid(731030)
addappid(731090)
addappid(731110)
addappid(731210)
addappid(733700)
addappid(755180)
addappid(755190)
addappid(756720)
addappid(756721)
addappid(756722)
addappid(756723)
addappid(756724)
addappid(756725)
addappid(756726)
addappid(756727)
addappid(756728)
addappid(756729)
addappid(756730)
addappid(756731)
addappid(820820)
addappid(820821)
addappid(829550)
