-- Lua provided by RyzenAPI
-- Game: 658570

-- MAIN APPLICATION
addappid(658570)
-- Game: addappid(658570)

-- MAIN APP DEPOTS / PACKAGES
addappid(658571, 1, "c26927e3da89aa27e58e09c2297e25acda2a8fefc18ef728aa907757ca130edf")
