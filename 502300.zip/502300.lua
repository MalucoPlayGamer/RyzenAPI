-- Lua provided by RyzenAPI
-- Game: Heartomics: Lost Count

-- MAIN APPLICATION
addappid(502300)

-- MAIN APP DEPOTS / PACKAGES
addappid(502301, 1, "05025f85faab2ed43fb117ced7f42ff7ef33b8ee6ea8c09a389e89749bffb858")
addappid(502302, 1, "a14981f589a0610a4b4c87b1f74e22f45c217463f73ac35754b49d02d7905cb6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
