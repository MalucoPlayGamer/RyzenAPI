-- Lua provided by RyzenAPI 
-- Game: NARUTO TO BORUTO: SHINOBI STRIKER
addappid(633230)
addappid(633231, 1, "94df9bad960ed6e04e89edf50a1b7a953c09cd7be9027ee380e41ba0a22e142b")
