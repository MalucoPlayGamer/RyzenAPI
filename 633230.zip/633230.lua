-- Lua provided by RyzenAPI
-- Game: NARUTO TO BORUTO: SHINOBI STRIKER

-- MAIN APPLICATION
addappid(633230)
-- Game: addappid(633230)

-- MAIN APP DEPOTS / PACKAGES
addappid(633231, 1, "94df9bad960ed6e04e89edf50a1b7a953c09cd7be9027ee380e41ba0a22e142b")
