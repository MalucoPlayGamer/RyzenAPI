-- Lua provided by RyzenAPI
-- Game: Game: AppID 879850

-- MAIN APPLICATION
addappid(879850)
-- Game: addappid(879850)

-- MAIN APP DEPOTS / PACKAGES
addappid(879851, 1, "9ba84948aedf9b337216bd8a89e6109773b8f14c87bc53a79b0acda10d22cde0")
