-- Lua provided by RyzenAPI
-- Game: Box: The Game

-- MAIN APPLICATION
addappid(879850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(879851, 1, "9ba84948aedf9b337216bd8a89e6109773b8f14c87bc53a79b0acda10d22cde0")
