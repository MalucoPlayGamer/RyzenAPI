-- Lua provided by RyzenAPI
-- Game: addappid(2013420)

-- MAIN APPLICATION
addappid(2013420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013421, 1, "9c14cc1a8ae2a9b26a39db15e25354237ba74c65067cccfb029046f48ff44aeb")
