-- Lua provided by RyzenAPI 
-- Game: The Castles of Burgundy
addappid(903040)
addappid(903041, 1, "e1abed4cfb450b26cb47bab89a6855376bca6d25d80952320a745e35b786e13a")
