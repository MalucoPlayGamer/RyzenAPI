-- Lua provided by RyzenAPI
-- Game: Game: The Castles of Burgundy

-- MAIN APPLICATION
addappid(903040)
-- Game: addappid(903040)

-- MAIN APP DEPOTS / PACKAGES
addappid(903041, 1, "e1abed4cfb450b26cb47bab89a6855376bca6d25d80952320a745e35b786e13a")
