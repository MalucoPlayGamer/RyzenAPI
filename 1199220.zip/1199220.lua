-- Lua provided by SkyAPI 
-- Game: AppID 1199220
addappid(1199220)
addappid(1199221, 1, "55ed5682a9ab9285f8236b43a5a7f24410fa7ff3fb02c90b078e895392d70ba2")
