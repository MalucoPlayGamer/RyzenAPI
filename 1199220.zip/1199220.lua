-- Lua provided by RyzenAPI
-- Game: An Odyssey: Echoes of War

-- MAIN APPLICATION
addappid(1199220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199221, 1, "55ed5682a9ab9285f8236b43a5a7f24410fa7ff3fb02c90b078e895392d70ba2")
