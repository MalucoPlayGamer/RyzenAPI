-- Lua provided by RyzenAPI
-- Game: Single Espresso Demo

-- MAIN APPLICATION
addappid(3277160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277161, 1, "70d188786dd2505eda401402a3d3b989b86da01601c1a0d3e510983a51398515")

