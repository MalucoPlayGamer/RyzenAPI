-- Lua provided by RyzenAPI
-- Game: Snooker-online multiplayer snooker game!

-- MAIN APPLICATION
addappid(522660)
-- Game: addappid(522660)

-- MAIN APP DEPOTS / PACKAGES
addappid(522661, 1, "74b8c53e09ca9e2cf0f435571113908cf8f93cd2083095c15779d5b0e8ffee3a")
addappid(522662, 1, "bb845a38c2eba9c5c5173b5691d91fd593eefc4870da48a7d618a7c0a65f3ecb")
