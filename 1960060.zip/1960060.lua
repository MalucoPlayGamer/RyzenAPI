-- Lua provided by RyzenAPI
-- Game: Game: Faith & Shield:4044 Tower Defense

-- MAIN APPLICATION
addappid(1960060)
-- Game: addappid(1960060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960061, 1, "fca7571e6abf226c9c918adaacb553e1d95c38bce62d8048dc75f5dfe839ac36")
