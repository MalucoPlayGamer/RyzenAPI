-- Lua provided by RyzenAPI
-- Game: On Point

-- MAIN APPLICATION
addappid(2296750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296751,0,"80f2fba66119156d3ec4a586e57ccca983af5c743ff2c0cd03c262da51f58e5a")

