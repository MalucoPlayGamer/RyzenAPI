-- Lua provided by RyzenAPI
-- Game: 魔女档案 MajyoArchive

-- MAIN APPLICATION
addappid(2838970)
-- Game: addappid(2838970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838971, 1, "a17331c5884a2c0fa12bd180d0eaaa9c5d68a7c2ebe3ba0cf67914b2aa1c091c")
