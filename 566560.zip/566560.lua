-- Lua provided by RyzenAPI
-- Game: Fighters Unleashed

-- MAIN APPLICATION
addappid(566560)

-- MAIN APP DEPOTS / PACKAGES
addappid(566561, 1, "622a4669c1eceb7f3569a310d1f7111903533ad26d60a3a35d293b5eb84070e4")
