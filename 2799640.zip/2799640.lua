-- Lua provided by RyzenAPI
-- Game: 2799640

-- MAIN APPLICATION
addappid(2799640)
-- Game: addappid(2799640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799641, 1, "ab5f6439ecdbf35cce2133bf62006dda3bb47faf2e1d67ae4c77544b8f6f840f")
