-- Lua provided by RyzenAPI
-- Game: WARRIORS: Abyss - 5,000 Karma Embers

-- MAIN APPLICATION
addappid(3358120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358120,0,"0abef5f189b4ff09f6ce15796aa9bbb502493c3f8cd9d38cf01319b93564b26b")

