-- Lua provided by RyzenAPI
-- Game: addappid(461410)

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(461410)

-- MAIN APP DEPOTS / PACKAGES
addappid(461412,0,"8a9d7ca8b55d4df4356160b64f9a4f84f433df47e91e348bb8a57bb51738eda5")
