-- Lua provided by RyzenAPI
-- Game: Grid Masters

-- MAIN APPLICATION
addappid(449330)

-- MAIN APP DEPOTS / PACKAGES
addappid(449331, 1, "a568951439de50f030bf7cceea0ec3da51bda1daee094c6ce2c7d04250254701")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
