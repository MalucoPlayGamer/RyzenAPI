-- Lua provided by RyzenAPI
-- Game: Grid Masters

-- MAIN APPLICATION
addappid(449330)
-- Game: addappid(449330)

-- MAIN APP DEPOTS / PACKAGES
addappid(449331, 1, "a568951439de50f030bf7cceea0ec3da51bda1daee094c6ce2c7d04250254701")
