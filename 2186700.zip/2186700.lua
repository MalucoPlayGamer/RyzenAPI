-- Lua provided by RyzenAPI
-- Game: Contain

-- MAIN APPLICATION
addappid(2186700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2186701, 1, "390c570720164b8c8f9aef3bbca2b99dffa189390a3b984f01ff8955b18921b1")

