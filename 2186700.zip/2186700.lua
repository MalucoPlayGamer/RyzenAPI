-- Lua provided by RyzenAPI
-- Game: addappid(2186700)

-- MAIN APPLICATION
addappid(2186700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186701, 1, "390c570720164b8c8f9aef3bbca2b99dffa189390a3b984f01ff8955b18921b1")
