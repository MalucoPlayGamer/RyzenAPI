-- Lua provided by RyzenAPI
-- Game: AppID 745500

-- MAIN APPLICATION
addappid(745500)

-- MAIN APP DEPOTS / PACKAGES
addappid(745501, 1, "2c21a5809c8cc0aed78bfdd64ae4ff0ccaee39126452255b846bc83040e90275")
