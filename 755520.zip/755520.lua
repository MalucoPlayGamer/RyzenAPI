-- Lua provided by RyzenAPI 
-- Game: Battle Shapes
addappid(755520)
addappid(755521, 1, "0876f5974726c1aab0358a6d4b0359146fc746dca2005c50d401b122f039b440")
