-- Lua provided by RyzenAPI
-- Game: Mortal Sin

-- MAIN APPLICATION
addappid(1494810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494811, 1, "0a511e83da83f4164929f78b0220da9474d343cbf334e814f37b5731de7196be")

