-- Lua provided by SkyAPI 
-- Game: AppID 1494810
addappid(1494810)
addappid(1494811, 1, "0a511e83da83f4164929f78b0220da9474d343cbf334e814f37b5731de7196be")
