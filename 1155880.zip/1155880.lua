-- Lua provided by RyzenAPI
-- Game: The Bonfire 2: Uncharted Shores

-- MAIN APPLICATION
addappid(1155880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155881, 1, "80f5d6ad2575c77182cfab5e8e6f0ca73697208e312b885318b44122ddf944fe")
addappid(1155882, 1, "2566883a3b1606cc82c899eeb80f6d9e1d5aae7ea4d0e51b462097453e577e64")

