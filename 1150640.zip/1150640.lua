-- Lua provided by RyzenAPI
-- Game: Yu-Gi-Oh! Legacy of the Duelist : Link Evolution

-- MAIN APPLICATION
addappid(1150640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1150641, 1, "da5d4255ac28beb6c73a162d4defe9119baeb65faaf3181cb8deb363ae1d156a")
