-- Lua provided by SkyAPI 
-- Game: AppID 1150640
addappid(1150640)
addappid(1150641, 1, "da5d4255ac28beb6c73a162d4defe9119baeb65faaf3181cb8deb363ae1d156a")
