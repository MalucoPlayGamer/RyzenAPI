-- Lua provided by RyzenAPI
-- Game: Ys Origin

-- MAIN APPLICATION
addappid(207350)

-- MAIN APP DEPOTS / PACKAGES
addappid(207351, 1, "d07cb2ff4d007ea8c11d8778b7828c1c65db11c00d199a0e442ff7901494b815")
addappid(207352, 1, "62c70e9616a6e04c41c9880f74a39d22fcde98defe6f3c1d179d2b788cc51ca5")
addappid(207353, 1, "a2f2feee4361ae4f8b4b3c63c65ed0768c23b333eaeacfce2c3e16334cc8a4ab")
addappid(207354, 1, "4880695ae7fddf3ccba5ec7ae64692b9c36d2dc02cbc07968f938bcfb1812091")
addappid(207355, 1, "d995c5aa9b4d763b60d4059f9be58dd6a091c5643a79c00a4aee541150bf73ab")
addappid(207356, 1, "dc65e42516c6efb4b6016a8ed834f56cbf5b8af4df4128fd40ed795bd2f9ac14")
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

