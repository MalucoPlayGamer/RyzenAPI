-- Lua provided by RyzenAPI 
-- Game: Stranger Watch
addappid(3214390)
addappid(3214391, 1, "c58959ae12d2231cd17124adec34e19be3ca6b39893a5bacc8c43358868caec2")
