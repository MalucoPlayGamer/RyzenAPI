-- Lua provided by SkyAPI 
-- Game: The Final Breath
addappid(2549190)
addappid(2549191, 1, "3d6307bb51d317823ec831b662d80b31e9ec473f403c8e5d48e5d5e876048620")
addappid(4074530)
