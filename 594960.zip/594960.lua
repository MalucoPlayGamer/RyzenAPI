-- Lua provided by SkyAPI 
-- Game: AppID 594960
addappid(594960)
addappid(594961, 1, "6f579c3094ac9baa756fc2433f26078bdd73a8c5ec6e8d49988fa8e2e61b88fa")
