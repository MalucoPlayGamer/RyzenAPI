-- Lua provided by RyzenAPI
-- Game: 8-Bit Armies: Arena (Free)

-- MAIN APPLICATION
addappid(594960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(594961, 1, "6f579c3094ac9baa756fc2433f26078bdd73a8c5ec6e8d49988fa8e2e61b88fa")

