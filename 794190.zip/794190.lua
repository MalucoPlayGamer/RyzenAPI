-- Lua provided by RyzenAPI
-- Game: addappid(794190)

-- MAIN APPLICATION
addappid(794190)

-- MAIN APP DEPOTS / PACKAGES
addappid(794191, 1, "7949d7ac6f8243b3b4ac05760cb4d9ce74c78b1b3eeefda785dde505a67a5ca0")
