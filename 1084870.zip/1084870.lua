-- Lua provided by RyzenAPI
-- Game: OSK - The End of Time

-- MAIN APPLICATION
addappid(1084870)
-- Game: addappid(1084870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084871, 1, "9dd6ab98ab6da6c89bf64a2692931c77a1addf76086f32af78e3ba4c3b5c9985")
addappid(1084872, 1, "b49e8287e5678b21e3f349610e0f026e881a2948afd1b907db456b1459fc2bfc")
addappid(1084873, 1, "1f8d728bd662a6638a50a597f2cd1e433d662480c1b0243a6d269ab7473f730d")
