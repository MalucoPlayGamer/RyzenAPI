-- Lua provided by RyzenAPI
-- Game: Beat Saber - Billie Eilish - Therefore I Am

-- MAIN APPLICATION
addappid(1753528)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753528,0,"ae306811ee4263a91dfad5623fe16095fe02b1400f6fcf7f4508781e4af9c447")

