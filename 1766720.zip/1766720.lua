-- Lua provided by RyzenAPI
-- Game: Outlanders

-- MAIN APPLICATION
addappid(1766720)
addappid(2155200)
addappid(2155201)
addappid(2399870)
addappid(2622870)
addappid(2815220)
addappid(2962040)
addappid(3247220)
addappid(3374760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766721, 1, "47efb24c9629e8b7af0f291aee5987a1817b95b9c198fa1c008cfb834fe5e695")
