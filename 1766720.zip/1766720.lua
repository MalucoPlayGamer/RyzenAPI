-- Lua provided by RyzenAPI
-- Game: Game: AppID 1766720

-- MAIN APPLICATION
addappid(1766720)
-- Game: addappid(1766720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766721, 1, "47efb24c9629e8b7af0f291aee5987a1817b95b9c198fa1c008cfb834fe5e695")
