-- Lua provided by RyzenAPI
-- Game: addappid(607260)

-- MAIN APPLICATION
addappid(607260)

-- MAIN APP DEPOTS / PACKAGES
addappid(607261, 1, "1bf9489c348bb3f4aa271ca23d5257a5babfc37fe9d3d47faa58ff9425d8528c")
addappid(607262, 1, "07563fcd28142de0d0dba39da21ab344955caf6f1d434154f90ee94417a88b84")
addappid(607263, 1, "2f831258a1e7a643f5b0b0d8ac30799b73b9cdea9c9198698dd927c7e5225c29")
addappid(607264, 1, "88acbb30534c90651f6ccf5ffbe660b237fac458db5ce6cb00f05c6a092aee3b")
