-- Lua provided by RyzenAPI
-- Game: 2649730

-- MAIN APPLICATION
addappid(2649730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649730,0,"f30ea3d32d7bed49f7fb1180aa43a34f94cb972fdaf4e804172aabe70fefa3df")

