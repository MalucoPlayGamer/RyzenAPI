-- Lua provided by SkyAPI 
-- Game: Neko Odyssey
addappid(2476350)
addappid(2476351, 1, "63eab64ad33514aa6086fb2f142069c677f911d7b8a092d97a04d1063b022b81")
