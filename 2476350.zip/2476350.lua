-- Lua provided by RyzenAPI
-- Game: Neko Odyssey

-- MAIN APPLICATION
addappid(2476350)
-- Game: addappid(2476350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476351, 1, "63eab64ad33514aa6086fb2f142069c677f911d7b8a092d97a04d1063b022b81")
