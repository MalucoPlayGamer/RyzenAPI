-- Lua provided by RyzenAPI
-- Game: Purrfect Date - Visual Novel/Dating Simulator

-- MAIN APPLICATION
addappid(520600)
addappid(759140)

-- MAIN APP DEPOTS / PACKAGES
addappid(520601, 1, "6832042dd529fc7c40aed48f4b5ecc1c33e0d40205362a812718112fbda8882b")
