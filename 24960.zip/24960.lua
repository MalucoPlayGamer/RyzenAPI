-- Lua provided by RyzenAPI
-- Game: addappid(24960)

-- MAIN APPLICATION
addappid(24960)

-- MAIN APP DEPOTS / PACKAGES
addappid(24961, 1, "9900d08628ad2bf35a66c757bc3c82ebc93e898bfc25d9416d198aa9f8b7df89")
