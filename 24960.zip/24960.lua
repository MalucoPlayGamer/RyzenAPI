-- Lua provided by RyzenAPI
-- Game: Battlefield: Bad Company™ 2

-- MAIN APPLICATION
addappid(24960)
addappid(24962)
addappid(24963)
addappid(47880)

-- MAIN APP DEPOTS / PACKAGES
addappid(24961,0,"9900d08628ad2bf35a66c757bc3c82ebc93e898bfc25d9416d198aa9f8b7df89")

