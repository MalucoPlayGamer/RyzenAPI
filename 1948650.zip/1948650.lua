-- Lua provided by RyzenAPI
-- Game: Jigsaw Novel - Futanari Nurse

-- MAIN APPLICATION
addappid(1948650)
-- Game: addappid(1948650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948651, 1, "892ac527ae830e43217fca99a1a541a574f9082ccd221f2ba688c67f8eceb970")
