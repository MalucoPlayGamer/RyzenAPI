-- Lua provided by RyzenAPI
-- Game: Elementallis

-- MAIN APPLICATION
addappid(1304280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304281,0,"bbf064e8f7dce6a390f15f34afbc6484581c2b3890e5df54967a3e9900851fa5")

