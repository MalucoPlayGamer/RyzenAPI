-- Lua provided by RyzenAPI
-- Game: Nomadic Tale (Harvest Elysium)

-- MAIN APPLICATION
addappid(3320340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320341, 1, "007fe85377a715b3ae6f4d90150602ec186945168d29c3118f678e0fa5c8b7bd")
