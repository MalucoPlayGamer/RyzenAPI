-- Lua provided by RyzenAPI
-- Game: Let's Minesweeper

-- MAIN APPLICATION
addappid(2865580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865581, 1, "bced34cca5e9674cbcd6cf05941a91eccf53b6a59fe0ca3aa72dff11e98cc6ec")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3100250)
addappid(3100260)
addappid(3100270)
addappid(3216810)
addappid(3362810)
