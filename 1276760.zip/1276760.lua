-- Lua provided by RyzenAPI
-- Game: DRAGON BALL: THE BREAKERS

-- MAIN APPLICATION
addappid(1276760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276761, 1, "b55d19c1067bef37b1163e7ee075621199e867ed2ecdad10961d829fe48ffe08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1777260)
addappid(1777370)
addappid(1942070)
addappid(1942071)
addappid(1942072)
addappid(1942073)
addappid(1942074)
addappid(1942075)
addappid(1942076)
addappid(1942077)
addappid(1942078)
addappid(2150540)
addappid(2150541)
