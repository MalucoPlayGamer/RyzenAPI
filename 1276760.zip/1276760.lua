-- Lua provided by RyzenAPI
-- Game: addappid(1276760)

-- MAIN APPLICATION
addappid(1276760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276761, 1, "b55d19c1067bef37b1163e7ee075621199e867ed2ecdad10961d829fe48ffe08")
