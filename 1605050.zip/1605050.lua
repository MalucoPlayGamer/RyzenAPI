-- Lua provided by RyzenAPI
-- Game: Crossy Bridge

-- MAIN APPLICATION
addappid(1605050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605051, 1, "30657618e20af2ff273d55f8482e37c9bca6bf302d5ea97d5405ed2694401d6b")

