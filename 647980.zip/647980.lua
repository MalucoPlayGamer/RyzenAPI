-- Lua provided by RyzenAPI
-- Game: Trojan Inc.

-- MAIN APPLICATION
addappid(647980)

-- MAIN APP DEPOTS / PACKAGES
addappid(647981,0,"28288a12d814ba8eddecfd7a6fd83de51e36e1f53306cb5651131cd041a2acd8")

