-- Lua provided by RyzenAPI
-- Game: Trojan Inc.

-- MAIN APPLICATION
addappid(647980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(647981,0,"28288a12d814ba8eddecfd7a6fd83de51e36e1f53306cb5651131cd041a2acd8")

