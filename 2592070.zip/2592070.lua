-- Lua provided by RyzenAPI
-- Game: Roguevive: Prelude

-- MAIN APPLICATION
addappid(2592070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2592071, 1, "d5c0d9c84bc6f3c45ae09bd3c13e5bc04e472f89c5839b0acbdc835566696309")

