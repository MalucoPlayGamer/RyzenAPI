-- Lua provided by RyzenAPI
-- Game: 2592070

-- MAIN APPLICATION
addappid(2592070)
-- Game: addappid(2592070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2592071, 1, "d5c0d9c84bc6f3c45ae09bd3c13e5bc04e472f89c5839b0acbdc835566696309")
