-- Lua provided by RyzenAPI
-- Game: AppID 1067310

-- MAIN APPLICATION
addappid(1067310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067311, 1, "831dcedfbc9aa233d52a1311746432cd0c85a0772fc1e178d1ee8a7f4255be4b")

