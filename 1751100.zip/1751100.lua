-- Lua provided by RyzenAPI
-- Game: addappid(1751100)

-- MAIN APPLICATION
addappid(1751100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751101, 1, "f98d3b09ed8e6763792369a1cff021962ce5a129adf038e9b4e409c2984f6a1e")
