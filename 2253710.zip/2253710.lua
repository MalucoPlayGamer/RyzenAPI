-- Lua provided by RyzenAPI
-- Game: 2253710

-- MAIN APPLICATION
addappid(2253710)
-- Game: addappid(2253710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253711, 1, "a5579ffd838139623a29bf32c7482a76a5fcaad0a98625d818e95488e62c9e73")
