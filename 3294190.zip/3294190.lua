-- Lua provided by RyzenAPI
-- Game: Code Trainer Demo

-- MAIN APPLICATION
addappid(3294190)
-- Game: addappid(3294190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294192,0,"20be08ad46585bd8939a890d458c4bc19289a52aec5a7aa8d52a16e0db3db987")
