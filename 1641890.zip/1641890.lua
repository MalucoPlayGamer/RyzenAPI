-- Lua provided by RyzenAPI
-- Game: Lust from Beyond: M Edition

-- MAIN APPLICATION
addappid(1641890)
-- Game: addappid(1641890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641891, 1, "42fffa773e33caaf34fc4fba3245527648838b6b060b0957625f4bb0b95d5429")
