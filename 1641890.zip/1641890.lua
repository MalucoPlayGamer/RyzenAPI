-- Lua provided by RyzenAPI
-- Game: addappid(1641890)

-- MAIN APPLICATION
addappid(1641890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641891, 1, "42fffa773e33caaf34fc4fba3245527648838b6b060b0957625f4bb0b95d5429")
