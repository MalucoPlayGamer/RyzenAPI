-- Lua provided by RyzenAPI
-- Game: Hacker Evolution

-- MAIN APPLICATION
addappid(70100)
-- Game: addappid(70100)

-- MAIN APP DEPOTS / PACKAGES
addappid(70101, 1, "06b05e068f33e06773343c90c6948e7ae9f32aff611280c0523cb9d479980d5f")
addappid(70102, 1, "b6aeb906d95f362b5b09e1a032f5e400a3665bbab8b7bc9346d05c6ecd2e4f33")
addappid(70103, 1, "53215d776c9a31d6d84baf7e1efeb811d96ace33b8f2cf1886fc5abb45d63446")
addappid(250220, 0, "26c2c6b21a0d0eee84e659982be1060b4fefb437ae70b9c74715c41aca514b95")
addappid(259230, 0, "a0607e185a1ff7e00bf34588c8830b593004dfb1cb3e7d33cded071858817920")
addappid(279820, 0, "53700b01dfd902caef7194f8ed6ba7f1f9160bb789936f7f374f9bd1e843c9bb")
