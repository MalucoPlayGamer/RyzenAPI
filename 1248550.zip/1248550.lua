-- Lua provided by RyzenAPI
-- Game: 1248550

-- MAIN APPLICATION
addappid(1248550)
-- Game: addappid(1248550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248551, 1, "7da016680edbe9df740c5b9c298042fc15fb8d786432a36fa0b1cd0d71cee860")
