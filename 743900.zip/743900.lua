-- Lua provided by RyzenAPI
-- Game: Game: AppID 743900

-- MAIN APPLICATION
addappid(743900)
-- Game: addappid(743900)

-- MAIN APP DEPOTS / PACKAGES
addappid(743901, 1, "c74902c0f8ad2d93265e04fff41f127b40f1936c12544237ee9dd600392c7276")
