-- Lua provided by RyzenAPI
-- Game: AppID 743900

-- MAIN APPLICATION
addappid(743900)

-- MAIN APP DEPOTS / PACKAGES
addappid(743901, 1, "c74902c0f8ad2d93265e04fff41f127b40f1936c12544237ee9dd600392c7276")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
