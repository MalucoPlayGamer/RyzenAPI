-- Lua provided by SkyAPI 
-- Game: THE CURE
addappid(2327830)
addappid(2327831, 1, "7253dfb50836517589224a7e3f9751955a87a4f2c22a2ecb62355f7170adcf8a")
