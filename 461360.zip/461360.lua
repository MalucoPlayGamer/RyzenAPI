-- Lua provided by RyzenAPI
-- Game: 461360

-- MAIN APPLICATION
addappid(461360)
-- Game: addappid(461360)

-- MAIN APP DEPOTS / PACKAGES
addappid(461361, 1, "51338154de247cbb6aafc4d3b32c5ab72c8cc0ad620157332717f0db37aca607")
