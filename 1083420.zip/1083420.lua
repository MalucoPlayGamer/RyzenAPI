-- Lua provided by RyzenAPI
-- Game: Game: Commander Babes

-- MAIN APPLICATION
addappid(1083420)
-- Game: addappid(1083420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083421, 1, "147fd81c2e0b6e9e10a1ac9343bd9f8c3268ba1d1722206f64c926a4c7782a64")
addappid(1083422, 1, "b5e11b46ef280cc5081c3796e2627bc9d2b9d95bc96266bf0e22cf6674a8ac5f")
