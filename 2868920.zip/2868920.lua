-- Lua provided by RyzenAPI
-- Game: Game: AppID 2868920

-- MAIN APPLICATION
addappid(2868920)
-- Game: addappid(2868920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868921, 1, "7e670ee2e01ca5ceb3be600f22eb9f8424526573ea8ede1de14c00fc6eedfb97")
