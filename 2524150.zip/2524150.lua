-- Lua provided by RyzenAPI
-- Game: Heroes de Peronia

-- MAIN APPLICATION
addappid(2524150)
-- Game: addappid(2524150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524151, 1, "8bee98f380d725c726f9af86608540a3eb2d196db608c3c0cc8eef693c6bfe8d")
addappid(2524153, 1, "4d53b60c9a2c8f8c668be68cf34c2d40735766f387d48c9535b2354979686c6c")
addappid(2524154, 1, "c43f4c75631026ba5c22cbedbcbeb90db1e0b4987facae87e9de2fa4922d159c")
