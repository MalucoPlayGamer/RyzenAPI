-- Lua provided by RyzenAPI
-- Game: Beachhead 2000

-- MAIN APPLICATION
addappid(509610)

-- MAIN APP DEPOTS / PACKAGES
addappid(509611, 1, "0e0172b34f724967b1a22d9c2931ba7d7ab6dc8b918cd492e06ce63e1ba96f2f")
