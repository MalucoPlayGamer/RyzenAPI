-- Lua provided by RyzenAPI
-- Game: YoloX - Crosshair Overlay

-- MAIN APPLICATION
addappid(2641350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641352,0,"b0f4c63cdb543d5bb1d0dfb5693998ec72f5395bbddd92c76223ce3474687142")

