-- Lua provided by RyzenAPI
-- Game: 2947980

-- MAIN APPLICATION
addappid(2947980)
-- Game: addappid(2947980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947981, 1, "8ccb8cfad80106f401d220280c89bc81b14c19496e3dc12593a7e8047186c1c1")
