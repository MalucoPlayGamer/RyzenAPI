-- Lua provided by RyzenAPI
-- Game: AppID 2341990

-- MAIN APPLICATION
addappid(2341990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341991, 1, "03b293a219aefad20945ad8acea1b2ca5a90278d9f2bfdb68c1d155d21fc90f8")

