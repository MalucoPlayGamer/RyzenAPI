-- Lua provided by SkyAPI 
-- Game: AppID 2341990
addappid(2341990)
addappid(2341991, 1, "03b293a219aefad20945ad8acea1b2ca5a90278d9f2bfdb68c1d155d21fc90f8")
