-- Lua provided by RyzenAPI
-- Game: Knock on the Coffin Lid

-- MAIN APPLICATION
addappid(1232580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232581, 1, "32718d93ad2804ff032dfb35bdbcd1b786c02ed19a8e40fec6ead1248c34f692")
addappid(1232583, 1, "d745e38afb2ee29d553671803bcd54ec499f0e8d9d479d5d4377b38841c64c5a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2891150)
