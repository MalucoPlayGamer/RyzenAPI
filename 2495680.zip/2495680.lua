-- Lua provided by RyzenAPI
-- Game: CD 2: Trap Master Demo

-- MAIN APPLICATION
addappid(2495680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495681, 1, "61bc142f9bdd8c0fa3e680ae56f945fd6fbe33bfd6b314d31ffbfc6ac5185eff")
