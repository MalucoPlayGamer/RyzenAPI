-- Lua provided by RyzenAPI
-- Game: Hanse - The Hanseatic League

-- MAIN APPLICATION
addappid(599010)

-- MAIN APP DEPOTS / PACKAGES
addappid(599012,0,"abf91047e4a34fad91859cbb18eb3240b096d2eb8c66026f345413f78586920a")
addappid(599013,0,"682be6e42c614232d06041e18b9062d7b7ce1f6b6a9820f762e89317dfd9d6b7")

