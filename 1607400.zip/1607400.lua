-- Lua provided by RyzenAPI
-- Game: addappid(1607400)

-- MAIN APPLICATION
addappid(1607400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607401, 1, "5f827d283db75b5f6ce55d48924bf2f107b70c12385003a13dae9b77d8367b13")
