-- Lua provided by RyzenAPI
-- Game: 665120

-- MAIN APPLICATION
addappid(665120)
-- Game: addappid(665120)

-- MAIN APP DEPOTS / PACKAGES
addappid(665121, 1, "9b42edc15f0a1ce093fb3934a9d07af12166908813a02283f8026e7c8fbff556")
