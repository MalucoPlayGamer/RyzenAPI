-- Lua provided by RyzenAPI
-- Game: Jetman Go

-- MAIN APPLICATION
addappid(665120)

-- MAIN APP DEPOTS / PACKAGES
addappid(665121, 1, "9b42edc15f0a1ce093fb3934a9d07af12166908813a02283f8026e7c8fbff556")
