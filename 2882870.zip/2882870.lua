-- Lua provided by RyzenAPI
-- Game: Game: Doll Impostor

-- MAIN APPLICATION
addappid(2882870)
-- Game: addappid(2882870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882871, 1, "05aaa231aeeb68d9ff8503272ffed7c5f3d348a0c479f034924c0fc2a830ddb0")
