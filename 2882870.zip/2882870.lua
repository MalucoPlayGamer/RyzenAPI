-- Lua provided by RyzenAPI
-- Game: Doll Impostor

-- MAIN APPLICATION
addappid(2882870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882871, 1, "05aaa231aeeb68d9ff8503272ffed7c5f3d348a0c479f034924c0fc2a830ddb0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
