-- Lua provided by RyzenAPI
-- Game: Game: CGWallpapers

-- MAIN APPLICATION
addappid(527350)
-- Game: addappid(527350)

-- MAIN APP DEPOTS / PACKAGES
addappid(527351, 1, "8c90ce130ea37704d75d8691f550e0bf9ad60b76dff8e36e373a365cebe5a72e")
addappid(692240, 0, "9e351208758a078c873c954228003bfb7f465a328f1b8d9ea2d4c6db2e67d9af")
