-- Lua provided by RyzenAPI
-- Game: addappid(2099360)

-- MAIN APPLICATION
addappid(2099360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099361, 1, "12f62c7520c182f1222abae2c671a6b4653dce3b6ce4764606754482aea22b65")
