-- Lua provided by RyzenAPI
-- Game: addappid(1849820)

-- MAIN APPLICATION
addappid(1849820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849821, 1, "1501d925a8ed6f8c94e152eab67d7ba72131eb88383308f9b8de8361ffd030d7")
