-- Lua provided by RyzenAPI
-- Game: addappid(2780690)

-- MAIN APPLICATION
addappid(2780690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780691, 1, "445545545a2ceac3a425ebe876305c1c36a02b2b4d5c823adbba4a50e38036ec")
