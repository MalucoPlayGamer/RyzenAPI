-- Lua provided by SkyAPI 
-- Game: Hidden Cats in Rio de Janeiro
addappid(2780690)
addappid(2780691, 1, "445545545a2ceac3a425ebe876305c1c36a02b2b4d5c823adbba4a50e38036ec")
