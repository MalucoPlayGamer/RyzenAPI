-- Lua provided by RyzenAPI
-- Game: Little Robot

-- MAIN APPLICATION
addappid(3425700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3425701, 1, "a4538798bd394cea9bc20e0c9b7c22c11a81b35e3b3e5371e1ab479ce7fd4385")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
