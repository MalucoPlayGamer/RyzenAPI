-- Lua provided by RyzenAPI
-- Game: addappid(3425700)

-- MAIN APPLICATION
addappid(3425700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3425701, 1, "a4538798bd394cea9bc20e0c9b7c22c11a81b35e3b3e5371e1ab479ce7fd4385")
