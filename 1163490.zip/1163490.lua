-- Lua provided by RyzenAPI
-- Game: Gangsters 1920

-- MAIN APPLICATION
addappid(1163490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163491, 1, "4272f462404f03580d014cc6155ae3cc41fbe948867904bbd5a832691278ad83")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
