-- Lua provided by RyzenAPI
-- Game: Game: Gangsters 1920

-- MAIN APPLICATION
addappid(1163490)
-- Game: addappid(1163490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163491, 1, "4272f462404f03580d014cc6155ae3cc41fbe948867904bbd5a832691278ad83")
