-- Lua provided by RyzenAPI
-- Game: NVL

-- MAIN APPLICATION
addappid(756880)
addappid(915170)

-- MAIN APP DEPOTS / PACKAGES
addappid(756881, 1, "f32bb1a458168ecca1a1cc6dc94ad06d7a37351e394c69a53110713a52d50d22")
