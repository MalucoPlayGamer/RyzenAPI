-- Lua provided by RyzenAPI
-- Game: AppID 1064860

-- MAIN APPLICATION
addappid(1064860)
-- Game: addappid(1064860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064861, 1, "2d03f7b12582b5579cfab68dce281e860e88c851a65bbf89ad961003f804907a")
