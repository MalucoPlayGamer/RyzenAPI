-- Lua provided by RyzenAPI
-- Game: AppID 711380

-- MAIN APPLICATION
addappid(711380)
-- Game: addappid(711380)

-- MAIN APP DEPOTS / PACKAGES
addappid(711381, 1, "6b0c38a33a24fb1b92d3e020e3e8d7eac7f28c0313f85999db8ecb2696130fd9")
