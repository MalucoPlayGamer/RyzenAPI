-- Lua provided by RyzenAPI
-- Game: AppID 711380

-- MAIN APPLICATION
addappid(711380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(711381, 1, "6b0c38a33a24fb1b92d3e020e3e8d7eac7f28c0313f85999db8ecb2696130fd9")

