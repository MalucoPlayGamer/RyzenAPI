-- Lua provided by RyzenAPI
-- Game: MoonWhite

-- MAIN APPLICATION
addappid(2812480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812481, 1, "6a6125fd39d8e2b14b876b8a80d4c9759eb1a2a4dea5cbca31be0d1af0229ef8")
addappid(2812482, 1, "f35ee11ea8834c5f0730aa3d0a1b4d7966003d706a2157958424d6a3477a4f6f")

