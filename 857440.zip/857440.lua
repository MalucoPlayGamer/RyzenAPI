-- Lua provided by SkyAPI 
-- Game: AppID 857440
addappid(857440)
addappid(857441, 1, "570bfc8006a902dec3f69ec51309cc9ff8d575a0c25cfb24a8e3d6b032ebf965")
addappid(857442, 1, "814717a41241b3001d14aba3f944287647a9e3adf8cad37c389830dfdff31494")
addappid(857443, 1, "096979be4e83a8c6a0639e5fab517e4426335a077f4ebefbab0ffc16b62ed631")
