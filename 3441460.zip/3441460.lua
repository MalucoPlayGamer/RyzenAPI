-- Lua provided by RyzenAPI
-- Game: Fuel Harvest Together

-- MAIN APPLICATION
addappid(3441460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441461, 1, "6558fb7f6bd07dea3d09f157e42c67ed1d11b6b21db3ec9e8ef4e9bcc6961ed4")

