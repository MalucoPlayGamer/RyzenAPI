-- Lua provided by RyzenAPI
-- Game: Mystery Tales: Til Death Collector's Edition

-- MAIN APPLICATION
addappid(1300000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300001, 1, "668b16106febae67b653e84e8708913c8f589e1aa35503d744361671861e8cd5")

