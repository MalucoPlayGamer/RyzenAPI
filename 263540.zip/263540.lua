-- Generated with Luie @ https://lua.tools/
-- 263540 - Villagers and Heroes
-- Generated 2026-08-16 20:21:25 UTC
-- # Depots (Total/DLC/Shared): 4/2/0

-- Main AppID
addappid(263540, 1, "3887badc1642540b45dff6c6b077ffcac53911232889a7df7f710205e9b965bc")

-- Main Depots
addappid(263541, 1, "3ec9759585d37f4a737ea2b4adff669a8969c1517eab8fa8c094915d373cf6e7")
setManifestid(263541, "8057458973498803469", 3934815724)
addappid(263542, 1, "ec49d74cc83338f935b55fc7cae4bbfb22c8f4c345c07749de7028de35e6363b") -- Brazilian
setManifestid(263542, "2780729558544104422", 656)

-- DLC's (no depot keys required)
addappid(303930) -- DLC 303930
addappid(305130) -- DLC 305130
addappid(305131) -- DLC 305131
addappid(313610) -- DLC 313610
addappid(313611) -- DLC 313611
addappid(322860) -- DLC 322860
addappid(328520) -- DLC 328520
addappid(402140) -- DLC 402140
addappid(402141) -- DLC 402141
addappid(402142) -- DLC 402142
addappid(402143) -- DLC 402143

-- DLC's (with depot keys)
-- DLC 276050 (AppID: 276050)
addappid(276050)
addappid(276050, 1, "2dcd9ae50977d08cf5535aa01f69e3cc3e8f32d1ee34f541158edd3ca69d28d8")
setManifestid(276050, "7170456457654944793", 11)

-- Missing Depots (We don't have the keys yet lol): 276051
