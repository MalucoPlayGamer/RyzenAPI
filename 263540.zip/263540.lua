-- Lua provided by RyzenAPI
-- Game: Game: Villagers and Heroes

-- MAIN APPLICATION
addappid(263540)
-- Game: addappid(263540)

-- MAIN APP DEPOTS / PACKAGES
addappid(263541, 1, "3ec9759585d37f4a737ea2b4adff669a8969c1517eab8fa8c094915d373cf6e7")
addappid(263542, 1, "ec49d74cc83338f935b55fc7cae4bbfb22c8f4c345c07749de7028de35e6363b")
addappid(276050, 0, "2dcd9ae50977d08cf5535aa01f69e3cc3e8f32d1ee34f541158edd3ca69d28d8")
