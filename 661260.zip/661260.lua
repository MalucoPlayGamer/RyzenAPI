-- Lua provided by RyzenAPI 
-- Game: AppID 661260
addappid(661260)
addappid(661261, 1, "d9c0da089dd0953e0683564858ea639e31619ff810040c374ce1f8e5fe7046b4")
