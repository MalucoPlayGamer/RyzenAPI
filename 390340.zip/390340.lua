-- Lua provided by RyzenAPI
-- Game: Umbrella Corps

-- MAIN APPLICATION
addappid(390340)
addappid(450000)
addappid(450001)
addappid(450002)
addappid(450003)
addappid(450004)
addappid(450005)

-- MAIN APP DEPOTS / PACKAGES
addappid(390341, 1, "94697dc7e634f27b66d696528f489e00c29e13d6c4be110a77dae82b3bc9aa3d")
addappid(390342, 1, "2a97356cf7862c02259840e085c20620ccd757ef1a42b7c305f69673807035f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
