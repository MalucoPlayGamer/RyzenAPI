-- Lua provided by RyzenAPI
-- Game: Lost Dimension

-- MAIN APPLICATION
addappid(626600)
addappid(650230)
addappid(650231)
addappid(650232)
addappid(650233)
addappid(650234)
addappid(650235)
addappid(650236)
addappid(650237)
addappid(650238)
addappid(650239)
addappid(650240)
addappid(650241)
addappid(650242)
addappid(650243)

-- MAIN APP DEPOTS / PACKAGES
addappid(626601,0,"c34b743d7313935b643c6c8b1ab332e6690d877fc6e4d23407076d870fa4ab0b")

