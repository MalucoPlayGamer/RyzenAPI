-- Lua provided by RyzenAPI
-- Game: Game: AppID 626600

-- MAIN APPLICATION
addappid(626600)
-- Game: addappid(626600)

-- MAIN APP DEPOTS / PACKAGES
addappid(626601, 1, "c34b743d7313935b643c6c8b1ab332e6690d877fc6e4d23407076d870fa4ab0b")
