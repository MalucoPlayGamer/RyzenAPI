-- Lua provided by RyzenAPI
-- Game: Lost Dimension

-- MAIN APPLICATION
addappid(626600)
addappid(650230)
addappid(650231)
addappid(650232)
addappid(650233)
addappid(650234)
addappid(650235)
addappid(650236)
addappid(650237)
addappid(650238)
addappid(650239)
addappid(650240)
addappid(650241)
addappid(650242)
addappid(650243)

-- MAIN APP DEPOTS / PACKAGES
addappid(626601,0,"c34b743d7313935b643c6c8b1ab332e6690d877fc6e4d23407076d870fa4ab0b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
