-- Lua provided by RyzenAPI
-- Game: 984150

-- MAIN APPLICATION
addappid(984150)
-- Game: addappid(984150)

-- MAIN APP DEPOTS / PACKAGES
addappid(984151, 1, "9163e528e4f2ae563a2b24331420b1a6b89184db72e2ef966352b496a15f69e4")
