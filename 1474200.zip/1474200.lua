-- Lua provided by RyzenAPI
-- Game: Sudoku RPG

-- MAIN APPLICATION
addappid(1474200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474201, 1, "a0ab3ce49225d0749477eb63f3f7898b9bd8b42acf3a2f26c17e62cedd6a49d3")
