-- Lua provided by RyzenAPI
-- Game: addappid(2660840)

-- MAIN APPLICATION
addappid(2660840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660841, 1, "dbcda86dca05cb75d8925ae3bd9bb40b017736810a8d3fb12230646b8b89b824")
