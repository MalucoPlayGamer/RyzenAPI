-- Lua provided by RyzenAPI 
-- Game: ManaSoul
addappid(2660840)
addappid(2660841, 1, "dbcda86dca05cb75d8925ae3bd9bb40b017736810a8d3fb12230646b8b89b824")
