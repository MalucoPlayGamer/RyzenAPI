-- Lua provided by RyzenAPI
-- Game: Frebbventure

-- MAIN APPLICATION
addappid(2004670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004671, 1, "bf2d74b621ea1eb5bcf732160a5aaf1df601a03f93aef194ecb72e20cd34cfc5")
