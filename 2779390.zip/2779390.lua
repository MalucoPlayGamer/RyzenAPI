-- Lua provided by RyzenAPI
-- Game: Bolt'N'Punch

-- MAIN APPLICATION
addappid(2779390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779391, 1, "19cefa8b08dffdcc0e2913bd68523290dc2fa3ec8da255853f7695497265aaf7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
