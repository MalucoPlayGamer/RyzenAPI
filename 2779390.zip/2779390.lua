-- Lua provided by SkyAPI 
-- Game: Bolt'N'Punch
addappid(2779390)
addappid(2779391, 1, "19cefa8b08dffdcc0e2913bd68523290dc2fa3ec8da255853f7695497265aaf7")
