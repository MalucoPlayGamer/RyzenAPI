-- Lua provided by RyzenAPI
-- Game: Bolt'N'Punch

-- MAIN APPLICATION
addappid(2779390)
-- Game: addappid(2779390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779391, 1, "19cefa8b08dffdcc0e2913bd68523290dc2fa3ec8da255853f7695497265aaf7")
