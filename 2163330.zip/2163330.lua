-- Lua provided by RyzenAPI 
-- Game: Yet Another Zombie Survivors
addappid(2163330)
addappid(2163331, 1, "f83759c39e0a087b6ee076427f28b6fa19f8e6400ef9e3843bc4ea1d0ba5afff")
