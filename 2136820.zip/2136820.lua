-- Lua provided by RyzenAPI
-- Game: addappid(2136820)

-- MAIN APPLICATION
addappid(2136820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136821, 1, "4e3a71a7ffe89a1ecc77933170ba7654cef85770555977ecb0e124db9cf144ce")
