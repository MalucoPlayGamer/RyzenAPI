-- Lua provided by RyzenAPI
-- Game: The Lord of Isekai Brothels

-- MAIN APPLICATION
addappid(2136820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(2136821, 1, "4e3a71a7ffe89a1ecc77933170ba7654cef85770555977ecb0e124db9cf144ce")

