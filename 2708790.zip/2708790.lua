-- Lua provided by RyzenAPI
-- Game: 2708790

-- MAIN APPLICATION
addappid(2708790)
-- Game: addappid(2708790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708791, 1, "8603d680cd2dfeee6da670de7dd0a0618464478381aaa55672071ed1a45c4647")
