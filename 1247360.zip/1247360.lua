-- Lua provided by RyzenAPI
-- Game: addappid(1247360)

-- MAIN APPLICATION
addappid(1247360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247361, 1, "3d13feb22fa2d086d03256bbf57d7946a9a1c82241300c34c3f7caf5b8538396")
