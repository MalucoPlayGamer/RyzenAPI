-- Lua provided by SkyAPI 
-- Game: İfrit
addappid(2124810)
addappid(2124811, 1, "ae99be01b35799e72aab92b87a4b02d88d87e3937ec74ea33b1d72d0275df9af")
