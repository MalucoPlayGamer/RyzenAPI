-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3080090)
addappid(3080092,0,"73414b93eecf0b11ce364c40a1d76593ba247c2edf1de4df2ccdea1d4d324875")
-- setManifestid(3080092,"8912566162116638582")
addappid(3080093,0,"19a5dd5c25d3c01a77d5cb7d8701a93d46e11f41c50bb491b689f8084f637171")
-- setManifestid(3080093,"6932548281361082675")