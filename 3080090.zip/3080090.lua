-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3080090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080092,0,"73414b93eecf0b11ce364c40a1d76593ba247c2edf1de4df2ccdea1d4d324875")
addappid(3080093,0,"19a5dd5c25d3c01a77d5cb7d8701a93d46e11f41c50bb491b689f8084f637171")

