-- Lua provided by RyzenAPI
-- Game: addappid(2457220)

-- MAIN APPLICATION
addappid(2457220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457221, 1, "b40bcd07f6b9e45f12bcdbec383ea1bc0957e15e51c2963f60f779ab7330d1a0")
addappid(3361650, 0, "9c81798a95cbb1149c5e0d86744b89e74f7c14948de24b1a5f7f2b212fa8f416")
