-- Lua provided by RyzenAPI
-- Game: Avowed

-- MAIN APPLICATION
addappid(2457220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457221, 1, "b40bcd07f6b9e45f12bcdbec383ea1bc0957e15e51c2963f60f779ab7330d1a0")
addappid(3361650, 0, "9c81798a95cbb1149c5e0d86744b89e74f7c14948de24b1a5f7f2b212fa8f416")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
