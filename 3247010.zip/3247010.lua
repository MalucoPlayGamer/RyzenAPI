-- Lua provided by RyzenAPI
-- Game: 3247010

-- MAIN APPLICATION
addappid(3247010)
-- Game: addappid(3247010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3247011, 1, "ad0b4339734e0a806841f9ffcf8ef8392610b5044e243accd70d1aef56ad3fc6")
