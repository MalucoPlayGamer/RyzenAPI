-- Lua provided by SkyAPI 
-- Game: Pesadelo - Regressão
addappid(378930)
addappid(378931, 1, "3461e1f67f424ff2e876e1f6cf01621a2ac9ec370968086724742c7a645a8435")
addappid(378933, 1, "41aa1806261801102af7a9649d1e132f1e05960c8f05d6cc7c63ef344f49ae8d")
