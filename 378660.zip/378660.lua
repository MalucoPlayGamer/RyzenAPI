-- Lua provided by RyzenAPI
-- Game: Blues and Bullets

-- MAIN APPLICATION
addappid(378660)
addappid(384380)
addappid(389990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(378661, 1, "480f245f16a4da8d4a6bee0bf95be0653a38261cc7b5433285110de0e0125c1a")
addappid(378662, 1, "d0451a26a83fc569a9c27767be1ef5f97384b5e5d79d75fdf5bf3f0f5d6f491a")
addappid(378663, 1, "c8e1db6b73829cb7547fb843723be6aed1e3da6f7df3496f0ead0c7145da8137")
addappid(378664, 1, "e3c2b5c385ca8b097d6f3c5d19154c7a58c8f4c8d78177ac25a6ec76d39a805d")
addappid(378665, 1, "7829288a108c58b4f39a848c244239b84b64057850893e649cc290b97d34da71")

