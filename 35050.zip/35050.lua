-- Lua provided by RyzenAPI
-- Game: 35050

-- MAIN APPLICATION
addappid(35050)
-- Game: addappid(35050)

-- MAIN APP DEPOTS / PACKAGES
addappid(35051, 1, "02288d66eed4e45d471e6c0440394295ec4146757fd42585947b0b4d5d040e37")
