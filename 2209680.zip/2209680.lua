-- Lua provided by RyzenAPI
-- Game: Beach Invasion 1944

-- MAIN APPLICATION
addappid(2209680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209681, 1, "8c3817a1fc90744498d552b6abfe7879c98fe0c824a7087f57fd9c8aef9386d5")
addappid(2255060, 0, "e7ac77d0e9491bcd58e2e150d07226da949dee1eabe5f0cf4343e8d1f078650a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
