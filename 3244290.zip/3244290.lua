-- Lua provided by SkyAPI 
-- Game: 🌟K-POP STAR🌟
addappid(3244290)
addappid(3244291, 1, "a374a65b427c38bf2f9977f0695797ab98c914041aa0bf4ef64ee1b0bc5a3e33")
