-- Lua provided by RyzenAPI
-- Game: Game: 🌟K-POP STAR🌟

-- MAIN APPLICATION
addappid(3244290)
-- Game: addappid(3244290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244291, 1, "a374a65b427c38bf2f9977f0695797ab98c914041aa0bf4ef64ee1b0bc5a3e33")
