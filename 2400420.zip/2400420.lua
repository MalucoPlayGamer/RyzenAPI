-- Lua provided by RyzenAPI
-- Game: Land of the Survivors

-- MAIN APPLICATION
addappid(2400420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400421, 1, "d06713b28c15342dcd3c44c0b324fe8f03b5c6020dc2d66572f220d7d90172cc")

