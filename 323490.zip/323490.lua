-- Lua provided by RyzenAPI
-- Game: Oblivious Garden ~Carmina Burana

-- MAIN APPLICATION
addappid(323490)
addappid(325660)
addappid(345040)

-- MAIN APP DEPOTS / PACKAGES
addappid(323491, 1, "f002646a85c6930d28fccfee4325641ca2fc4f875b820f87deb1d9d99b6c1507")
addappid(323492, 1, "6cbc5bf7aa4abdcb67c3430b6491b73ba4e0065926819f0f745af5862d878bec")
addappid(323493, 1, "a9471332983be50fd965946e6ee3593a6aa5cdac5f8faecd8fe48086a98c9a09")
