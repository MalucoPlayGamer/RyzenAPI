-- Lua provided by RyzenAPI
-- Game: addappid(614008)

-- MAIN APPLICATION
addappid(614008)

-- MAIN APP DEPOTS / PACKAGES
addappid(632390,0,"3ad508e1674bf9b4262eef46b5d000b10b4fe0c1681bf4373bde19eb7aa52d6c")
