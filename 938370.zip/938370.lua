-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(938370)

-- MAIN APP DEPOTS / PACKAGES
addappid(938372,0,"3f628704c667e6a5794e302a89b36ebffab58a7e914b9e65fa9a3c5f658d0c08")
addappid(938373,0,"d328df05b5326655af4cbff5c9f4dffb6df392f5b257a0fdc15b07ad610dd338")
