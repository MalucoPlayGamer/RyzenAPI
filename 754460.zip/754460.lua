-- Lua provided by RyzenAPI
-- Game: Game: Jisei

-- MAIN APPLICATION
addappid(754460)
-- Game: addappid(754460)

-- MAIN APP DEPOTS / PACKAGES
addappid(754461, 1, "ddfee12d8fb9bbe391eab50ba5bf9e1ebc1cbd54facdf5a7def26d5fabd25650")
