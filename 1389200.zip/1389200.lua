-- Lua provided by RyzenAPI
-- Game: AppID 1389200

-- MAIN APPLICATION
addappid(1389200)
-- Game: addappid(1389200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389201, 1, "8422fe8eaa1c15cef552fce8af630b12f43e3c3946606c03fa7d398400afb2e0")
