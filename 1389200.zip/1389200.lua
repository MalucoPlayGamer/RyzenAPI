-- Lua provided by RyzenAPI 
-- Game: AppID 1389200
addappid(1389200)
addappid(1389201, 1, "8422fe8eaa1c15cef552fce8af630b12f43e3c3946606c03fa7d398400afb2e0")
