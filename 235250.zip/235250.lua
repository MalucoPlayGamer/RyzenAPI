-- Lua provided by RyzenAPI
-- Game: Super Sanctum TD

-- MAIN APPLICATION
addappid(235250)

-- MAIN APP DEPOTS / PACKAGES
addappid(235251, 1, "bb22795698d724cc67722a4520e63e8de275663a616db758e0433bee41a31597")
addappid(235252, 1, "d188ac90d832095aee385dd7a9a68fa68fe6905a451e3b87dc94c974199c88e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
