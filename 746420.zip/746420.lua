-- Lua provided by RyzenAPI
-- Game: Broken Minds

-- MAIN APPLICATION
addappid(746420)
-- Game: addappid(746420)

-- MAIN APP DEPOTS / PACKAGES
addappid(746423,0,"e13af53a4a6d6d723f7264820ff48cf31ae5811fd02965984d45a7c0d9428395")
addappid(966700,0,"7dabce6a288ecc365674cf2857209d598c5033ac9b9f193daf1fdbcf166372fd")
