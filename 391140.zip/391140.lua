-- Lua provided by RyzenAPI
-- Game: Blast-off

-- MAIN APPLICATION
addappid(391140)
addappid(488120)
-- Game: addappid(391140)

-- MAIN APP DEPOTS / PACKAGES
addappid(391141, 1, "f4db88b633351540a468eb8ea2faedc84ecaf8c47953ac5da665dbec9707d6e1")
