-- Lua provided by RyzenAPI
-- Game: Blast-off

-- MAIN APPLICATION
addappid(391140)
addappid(488120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(391141, 1, "f4db88b633351540a468eb8ea2faedc84ecaf8c47953ac5da665dbec9707d6e1")

