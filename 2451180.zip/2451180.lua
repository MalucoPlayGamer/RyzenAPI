-- Lua provided by RyzenAPI
-- Game: Game: AppID 2451180

-- MAIN APPLICATION
addappid(2451180)
-- Game: addappid(2451180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451181, 1, "0a1ca0090c266037c69262e05593ff26b41450dff969ac3f5bffc07ebadc887d")
