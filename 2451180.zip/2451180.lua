-- Lua provided by SkyAPI 
-- Game: AppID 2451180
addappid(2451180)
addappid(2451181, 1, "0a1ca0090c266037c69262e05593ff26b41450dff969ac3f5bffc07ebadc887d")
