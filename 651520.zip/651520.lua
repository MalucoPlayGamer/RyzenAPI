-- Lua provided by RyzenAPI
-- Game: Castle Defender

-- MAIN APPLICATION
addappid(651520)
addappid(651521)
addappid(651523)

-- MAIN APP DEPOTS / PACKAGES
addappid(651522,0,"08042b7710696a6cf6a537eecaacc9d5ebae46163e1c24f07e6fca6739f803c3")

