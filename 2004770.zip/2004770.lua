-- Lua provided by RyzenAPI
-- Game: Dark Notes

-- MAIN APPLICATION
addappid(2004770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004774,0,"2838fd636ec09bb46ce6f2428d1405b5bff80bd87053c6ce4d7e0a1365b0ef1e")
addappid(2004775,0,"a5a0265986b389c4938f0ea866273edf2a5fb0937b9a1d6d74a9ba9eead368ca")
addappid(2004776,0,"e672540c05baee20c10a300d928aec00e0d00a815424e3f1b0f6ea5fb294c1bf")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2963610)
