-- Lua provided by RyzenAPI
-- Game: CROWZ

-- MAIN APPLICATION
addappid(1692070)
addappid(1774640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692071, 1, "1f01b2d90179f350bce547f3b27ccee95fa7776a8de4ddc45831eb53baa1e222")
