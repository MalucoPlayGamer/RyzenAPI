-- Lua provided by RyzenAPI
-- Game: Astra Nova

-- MAIN APPLICATION
addappid(2862220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862221, 1, "a949ac81d07666bb85049dc68c5504f49cd2b086656385bef868a48df00fd119")

