-- Lua provided by RyzenAPI
-- Game: Astra Nova

-- MAIN APPLICATION
addappid(2862220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862221, 1, "a949ac81d07666bb85049dc68c5504f49cd2b086656385bef868a48df00fd119")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
