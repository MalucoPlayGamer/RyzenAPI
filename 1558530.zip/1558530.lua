-- Lua provided by RyzenAPI
-- Game: addappid(1558530)

-- MAIN APPLICATION
addappid(1558530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558531, 1, "62eaa00f24652895e81cd20bdde9ae950ede826e3d00e60b2452dca3de607cbd")
