-- Lua provided by RyzenAPI
-- Game: BATTLE PIXELS

-- MAIN APPLICATION
addappid(434500)
-- Game: addappid(434500)

-- MAIN APP DEPOTS / PACKAGES
addappid(434501, 1, "51195e266db7a5a55f13eae33dfb79330fd49cfb6a610c0afcf8c952ca9d403e")
