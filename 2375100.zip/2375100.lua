-- Lua provided by SkyAPI 
-- Game: Run Penguin Run
addappid(2375100)
addappid(2375101, 1, "85e19d0a3c741ee7883bbcd168dfab9bc94a325c7645fd56f93e4867ed7698dc")
