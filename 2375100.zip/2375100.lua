-- Lua provided by RyzenAPI
-- Game: Run Penguin Run

-- MAIN APPLICATION
addappid(2375100)
-- Game: addappid(2375100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375101, 1, "85e19d0a3c741ee7883bbcd168dfab9bc94a325c7645fd56f93e4867ed7698dc")
