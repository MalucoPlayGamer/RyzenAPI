-- Lua provided by RyzenAPI
-- Game: Love Quest

-- MAIN APPLICATION
addappid(2197550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197551, 1, "c4f6d37bd357ebcf41d7595400f9d24ebe5d0384d91fc700346a42c28c048ea8")

