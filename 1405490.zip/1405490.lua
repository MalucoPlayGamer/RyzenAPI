-- Lua provided by RyzenAPI
-- Game: 1405490

-- MAIN APPLICATION
addappid(1405490)
-- Game: addappid(1405490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405491, 1, "137fee59833feb1de8219a39de52674c03b2264f58cd7c05713fe6fac0bba261")
