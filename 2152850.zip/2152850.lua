-- Lua provided by RyzenAPI
-- Game: 2152850

-- MAIN APPLICATION
addappid(2152850)
-- Game: addappid(2152850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152851, 1, "3b7fc090b1dae44eab3f3dc4bcfb048e09e1182a231e1f674245518ee4db6154")
