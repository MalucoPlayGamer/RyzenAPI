-- Lua provided by RyzenAPI
-- Game: Chroma Zero

-- MAIN APPLICATION
addappid(3121470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3121471, 1, "2da989502fa59ac86714821bca3fcde97c340cef431773f2ce3889622cee2cbe")

