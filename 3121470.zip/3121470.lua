-- Lua provided by RyzenAPI 
-- Game: AppID 3121470
addappid(3121470)
addappid(3121471, 1, "2da989502fa59ac86714821bca3fcde97c340cef431773f2ce3889622cee2cbe")
