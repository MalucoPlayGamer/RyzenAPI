-- Lua provided by SkyAPI 
-- Game: Halloween Riddles Mysterious Griddlers
addappid(1716210)
addappid(1716211, 1, "91a886f537c6f791f7d4d6ca3fde562c47af360f2b06c0d9094b2adf2634d63c")
addappid(1716214, 1, "5e08a91fe8c5b8d48abf57d66701f8bad6ff48696ecbe7984f0a20f185028fe5")
