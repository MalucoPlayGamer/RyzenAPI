-- Lua provided by RyzenAPI
-- Game: AppID 891120

-- MAIN APPLICATION
addappid(891120)
-- Game: addappid(891120)

-- MAIN APP DEPOTS / PACKAGES
addappid(891121, 1, "79e2f856bd06d58adc3bc4c882528a7496b84536a58021119c3a8ffbb7fe0dbd")
