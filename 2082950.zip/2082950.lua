-- Lua provided by RyzenAPI
-- Game: Game: Hansel And Gretel

-- MAIN APPLICATION
addappid(2082950)
-- Game: addappid(2082950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082951, 1, "d0813ab11d04ad73d71e97aab9976726348387af9658c196637ae15b733ad86e")
