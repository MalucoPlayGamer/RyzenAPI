-- Lua provided by SkyAPI 
-- Game: Relic Hunt
addappid(3474060)
addappid(3474061, 1, "f0152e2aca5f3e7b1e7984870bfd7a7922a0b63b4b5ebfcd79f09b18d30006ef")
addappid(3474062, 1, "39b4ec44586310ef1f887766a867c8506bf49600680e910098bc178c86fd85a6")
