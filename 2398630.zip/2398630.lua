-- Lua provided by RyzenAPI
-- Game: Holidays in Khrushchevsk

-- MAIN APPLICATION
addappid(2398630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398631, 1, "0b02710b84413ad55c1c3c8d5f800be350e3368035399d9f76ac09a61c9271df")

