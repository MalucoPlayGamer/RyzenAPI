-- Lua provided by RyzenAPI
-- Game: Holidays in Khrushchevsk

-- MAIN APPLICATION
addappid(2398630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2398631, 1, "0b02710b84413ad55c1c3c8d5f800be350e3368035399d9f76ac09a61c9271df")

