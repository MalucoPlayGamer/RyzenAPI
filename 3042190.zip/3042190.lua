-- Lua provided by RyzenAPI 
-- Game: Nomad Idle
addappid(3042190)
addappid(3042191, 1, "5912d9d3e294fc23fdbe980a157736bc0b31da7caf49d13f3f38dbb708c5e2b1")
