-- Lua provided by RyzenAPI 
-- Game: AppID 1189290
addappid(1189290)
addappid(1189291, 1, "341869491ffef1b4850c649a11044ba5ae1059377781b2a17f8b4761b2c0780a")
