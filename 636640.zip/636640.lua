-- Lua provided by RyzenAPI
-- Game: addappid(636640)

-- MAIN APPLICATION
addappid(636640)

-- MAIN APP DEPOTS / PACKAGES
addappid(636641, 1, "f12e5d22584b800a116af25acf6440f3d39642db36e5d59b197d0d4d5cd2e8aa")
