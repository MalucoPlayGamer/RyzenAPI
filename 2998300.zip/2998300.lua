-- Lua provided by SkyAPI 
-- Game: PERSEVERANCE: Chapter 1
addappid(2998300)
addappid(2998301, 1, "94852ef7d9bbb766af4cfc22b9c8a6172ba1a45e3f618a5a4a63d0443f516f7a")
