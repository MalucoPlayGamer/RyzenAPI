-- Lua provided by RyzenAPI
-- Game: PERSEVERANCE: Chapter 1

-- MAIN APPLICATION
addappid(2998300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998301, 1, "94852ef7d9bbb766af4cfc22b9c8a6172ba1a45e3f618a5a4a63d0443f516f7a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
