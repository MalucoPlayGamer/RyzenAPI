-- Lua provided by RyzenAPI
-- Game: 1980770

-- MAIN APPLICATION
addappid(1980770)
-- Game: addappid(1980770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980771, 1, "f61e6fd67aec718248b58f4c2f3257a55121f836eb9ee7339d895fad96d2f16a")
