-- Lua provided by RyzenAPI
-- Game: addappid(904520)

-- MAIN APPLICATION
addappid(904520)

-- MAIN APP DEPOTS / PACKAGES
addappid(904521, 1, "8a17ee0a301639e2f69d537308bacd19be22a74ac146427fae8b5b22bea6f92c")
