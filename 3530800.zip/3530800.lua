-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Antalya

-- MAIN APPLICATION
addappid(3530800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3530801, 1, "d28bbcb0d7587fff6d8eb6b794508665cd6ebbbbb70a27dd3c7d02d1520c3da2")
