-- Lua provided by SkyAPI 
-- Game: Sky: Children of the Light
addappid(2325290)
addappid(2325291, 1, "3e40fe2122ac9f2163fb1f48ad070765b12801f18221665420d84d8f455bfac1")
