-- Lua provided by RyzenAPI
-- Game: AppID 444290

-- MAIN APPLICATION
addappid(444290)
-- Game: addappid(444290)

-- MAIN APP DEPOTS / PACKAGES
addappid(444291, 1, "b34fdb1c06858db2905ee2e338883c1da6dce809b120fda2b99b37fb84bc96ae")
