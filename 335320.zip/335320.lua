-- Lua provided by RyzenAPI
-- Game: Bet On Soldier

-- MAIN APPLICATION
addappid(335320)

-- MAIN APP DEPOTS / PACKAGES
addappid(335321, 1, "c651ee2b9a03427fd0dcca8794003a2af8dc47bf5bf2a74af893b0f240704001")
addappid(335322, 1, "1fa1305b1d2f5f3887e877480cfafa4916fa7745c4b4befc82fd4abe4cc42be4")
addappid(335323, 1, "f20a2d2a01d9d95034b06ab318e30853bd0e19595473bcd40de95cbd072583c0")
addappid(335324, 1, "f2139bc1ea8e4b7e5a75ff57ce4ca39f58383eb99135fc9acb15b2617bedacef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
