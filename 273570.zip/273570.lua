-- Lua provided by RyzenAPI
-- Game: Descent

-- MAIN APPLICATION
addappid(273570)

-- MAIN APP DEPOTS / PACKAGES
addappid(273571, 1, "161c38fa20dbe8658748eda47031e6c13d9d1016114d2e92aefc46a9de1312a6")

