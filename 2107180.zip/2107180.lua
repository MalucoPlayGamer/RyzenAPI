-- Lua provided by RyzenAPI
-- Game: The Hungry Fly

-- MAIN APPLICATION
addappid(2107180)
-- Game: addappid(2107180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107181, 1, "4b908d5715f0464783f23ff49aadc6d439317b3e45d4a53d45ac812f9466c616")
