-- Lua provided by SkyAPI 
-- Game: The Hungry Fly
addappid(2107180)
addappid(2107181, 1, "4b908d5715f0464783f23ff49aadc6d439317b3e45d4a53d45ac812f9466c616")
