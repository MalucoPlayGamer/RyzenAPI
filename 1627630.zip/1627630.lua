-- Lua provided by RyzenAPI
-- Game: Dungeon Adventure

-- MAIN APPLICATION
addappid(1627630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627631, 1, "153c6cdb2109af998374eb241e45c2e1f6e522194e211e96e36247e115dad51b")

