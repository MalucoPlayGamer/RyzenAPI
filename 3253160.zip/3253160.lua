-- Lua provided by SkyAPI 
-- Game: AppID 3253160
addappid(3253160)
addappid(3253161, 1, "738cb5e5e6bafaea1367e3c65a8887ba14d58db1ac56462f6abe81ed8c8d789b")
