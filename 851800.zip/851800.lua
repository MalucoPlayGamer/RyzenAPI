-- Lua provided by RyzenAPI
-- Game: G2 Fighter / 基因特工

-- MAIN APPLICATION
addappid(851800)

-- MAIN APP DEPOTS / PACKAGES
addappid(851801, 1, "0aeab049adb7f79e3cf7109f88b3511a9c7d35fb933bef32c47397b36561f865")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
