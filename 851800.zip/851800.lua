-- Lua provided by RyzenAPI
-- Game: addappid(851800)

-- MAIN APPLICATION
addappid(851800)

-- MAIN APP DEPOTS / PACKAGES
addappid(851801, 1, "0aeab049adb7f79e3cf7109f88b3511a9c7d35fb933bef32c47397b36561f865")
