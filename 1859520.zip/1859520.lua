-- Lua provided by RyzenAPI
-- Game: Dream Girlfriend: Twitch Thot

-- MAIN APPLICATION
addappid(1859520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859521, 1, "81cad56fa68fa87f551e59d5a5b44502a5dcde3e3fefd80818a1f9c2c846073a")

