-- Lua provided by RyzenAPI
-- Game: MareQuest: An Interactive Tail

-- MAIN APPLICATION
addappid(2391870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391871, 1, "aca787df1f47e99b728c10dc6e3b75d5f6f48b2580bac15711601e19fe91e331")
