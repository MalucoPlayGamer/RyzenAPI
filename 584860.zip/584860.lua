-- Lua provided by RyzenAPI
-- Game: 584860

-- MAIN APPLICATION
addappid(584860)
-- Game: addappid(584860)

-- MAIN APP DEPOTS / PACKAGES
addappid(584861, 1, "97f5b0ea4e762771db8e49cd3f6748517af75e1ec77c0f8369e3e34b4bb4e88a")
