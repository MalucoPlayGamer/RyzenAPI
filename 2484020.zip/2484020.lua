-- Lua provided by RyzenAPI
-- Game: メンヘラオタ姫サークル - Needy Princess Nerd Club -

-- MAIN APPLICATION
addappid(2484020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484021, 1, "7650deb736a894cc3e4910d101f096f650eba540b72afab46ecfde00c7dd90cf")
