-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Tyler Warren RTP Redesign 1

-- MAIN APPLICATION
addappid(1662610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662610,0,"f14b02d3118ff49c1740f9424c58353c0013cf73b66f096080b1eb18a74d12d2")

