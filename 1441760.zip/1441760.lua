-- Lua provided by RyzenAPI
-- Game: Game: My Business

-- MAIN APPLICATION
addappid(1441760)
-- Game: addappid(1441760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441761, 1, "be05f1a7b33b652e03a1c2799fb7ee84490a593977b38043e393bd5f21463ed9")
