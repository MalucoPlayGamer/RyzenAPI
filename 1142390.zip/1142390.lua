-- Lua provided by RyzenAPI
-- Game: Remothered: Broken Porcelain

-- MAIN APPLICATION
addappid(1142390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142391, 1, "5a8e94ccbc874c8de36978b048ce038b31b6ac79a6e0839973300deb85670278")

