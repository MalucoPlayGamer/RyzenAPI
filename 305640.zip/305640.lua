-- Lua provided by SkyAPI 
-- Game: AppID 305640
addappid(305640)
addappid(305641, 1, "52baaf0faf800062be8ff61315a19c76a55c48b181e48bd70d31033583064c20")
addappid(305642, 1, "de4e8e0f193595e01b800400e56fa62e69a3f3cb33fa992fa950ae7c61da1c4f")
addappid(310710)
