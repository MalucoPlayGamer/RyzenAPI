-- Lua provided by RyzenAPI
-- Game: Chessia

-- MAIN APPLICATION
addappid(689270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(689271,0,"6ec12077968694e107c785487caa94a0638efa05815c7ce4cb14b736b4c9f4d4")

