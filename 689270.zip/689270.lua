-- Lua provided by RyzenAPI
-- Game: Chessia

-- MAIN APPLICATION
addappid(689270)

-- MAIN APP DEPOTS / PACKAGES
addappid(689271,0,"6ec12077968694e107c785487caa94a0638efa05815c7ce4cb14b736b4c9f4d4")

