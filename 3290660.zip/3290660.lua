-- Lua provided by RyzenAPI
-- Game: Game: Pirate Cove Simulator

-- MAIN APPLICATION
addappid(3290660)
-- Game: addappid(3290660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290661, 1, "55e9a0238f84b88383e27c1c39a916128f5c831dd45c20c22133f2b788b15f84")
