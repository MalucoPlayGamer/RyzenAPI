-- Lua provided by RyzenAPI
-- Game: SpyParty

-- MAIN APPLICATION
addappid(329070)

-- MAIN APP DEPOTS / PACKAGES
addappid(329071, 1, "274a28f08ec46eca043b6bb08cccabadb96cf5a50bf95b5318aa646c336d3aef")
