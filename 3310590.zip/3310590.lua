-- Lua provided by RyzenAPI
-- Game: addappid(3310590)

-- MAIN APPLICATION
addappid(3310590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310591, 1, "5c1af84a850c32a277eb4a29e4422040d3fef9cebf0840300f83651dabf9ecac")
