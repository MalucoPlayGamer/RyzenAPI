-- Lua provided by RyzenAPI
-- Game: Provenance Unknown: Six Discs

-- MAIN APPLICATION
addappid(4061620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4061621,0,"f6b2bfab6411f06a0fd35529eb94ef5da7ee37da878565087cdea631b52970ba")

