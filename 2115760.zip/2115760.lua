-- Lua provided by RyzenAPI
-- Game: Game: Oppidum

-- MAIN APPLICATION
addappid(2115760)
-- Game: addappid(2115760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115761, 1, "694f8e5ac2f0394f8034e08f3f0828e27d157bd485e1f8176c77f95d8088e616")
