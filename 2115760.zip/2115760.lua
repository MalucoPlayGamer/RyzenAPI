-- Lua provided by RyzenAPI
-- Game: Oppidum

-- MAIN APPLICATION
addappid(2115760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115761, 1, "694f8e5ac2f0394f8034e08f3f0828e27d157bd485e1f8176c77f95d8088e616")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
