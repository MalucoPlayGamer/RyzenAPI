-- Lua provided by RyzenAPI 
-- Game: This Is the Police
addappid(443810)
addappid(443811, 1, "c08a868d958947d5b5433d96302fdfb2a4a4ce03bc0f0a694d1bd9fd28e7b7ba")
addappid(443812, 1, "a51b9e52b4349c91537aaa383d220978279adf74a0f30a2e334cfd49a854bd5a")
addappid(443813, 1, "c4418e4f85626a7df49096d34258aa45506d85cf76fd9781d087e0ea2b7d3cad")
