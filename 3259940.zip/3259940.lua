-- Lua provided by RyzenAPI
-- Game: Game: 舒舒服服小岛时光 Playtest

-- MAIN APPLICATION
addappid(3259940)
-- Game: addappid(3259940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3259941, 1, "37c1547e88a1e93604a1b26335ceedfd0f5b3b24479c1cc93d12916579286fbf")
