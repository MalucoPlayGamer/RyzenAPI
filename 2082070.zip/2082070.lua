-- Lua provided by RyzenAPI
-- Game: Game: 东方冰之勇者记 Demo

-- MAIN APPLICATION
addappid(2082070)
-- Game: addappid(2082070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082071, 1, "9eb5952f00dbf6942e93b9f27ebd8a1c9613f0e2c7426cb11836e956677a8285")
