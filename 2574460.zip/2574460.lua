-- Lua provided by RyzenAPI
-- Game: Scars of Mars

-- MAIN APPLICATION
addappid(2574460)
-- Game: addappid(2574460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574461, 1, "5ef62a081fa3d3f71f34491ce0effad366f03cac5e7639e011d4eb8327eb5feb")
