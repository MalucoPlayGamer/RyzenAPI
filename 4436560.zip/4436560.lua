-- Lua provided by RyzenAPI
-- Game: We Need More Humans!

-- MAIN APPLICATION
addappid(4436560) -- We Need More Humans!

-- MAIN APP DEPOTS / PACKAGES
addappid(4436561, 1, "3ae51b56dba0ce84807f4256da85ee87c34f2e9eed414b2cd8b0150cfa1cb75b") -- Depot 4436561

