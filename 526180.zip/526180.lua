-- Lua provided by RyzenAPI
-- Game: Deus Ex: Mankind Divided™ - VR Experience

-- MAIN APPLICATION
addappid(526180)
addappid(565790)

-- MAIN APP DEPOTS / PACKAGES
addappid(526181, 1, "9ca14e360ec4528eaf4c56b917234e565eb9fa99151bf88eba003a63688415db")
addappid(526182, 1, "beb4c5a6245693d04ffc3f86a2de74e430a79b21230f72c5817c9b15211c37bc")

