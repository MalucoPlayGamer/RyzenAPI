-- Lua provided by RyzenAPI
-- Game: X-Sports

-- MAIN APPLICATION
addappid(2253490) -- X-Sports

-- MAIN APP DEPOTS / PACKAGES
addappid(2253491, 1, "2c656aff143d18084f6527bd93f7421c6f65502f2660ce06bf50f782a6a5ccb3") -- Depot 2253491
addtoken(2253490, "8178654899070619295")

