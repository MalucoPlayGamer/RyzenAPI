-- 2253490's Lua and Manifest Created by Hubcap Manifest
-- X-Sports
-- Created: August 09, 2026 at 00:19:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2253490) -- X-Sports
addtoken(2253490, "8178654899070619295")
-- MAIN APP DEPOTS
addappid(2253491, 1, "2c656aff143d18084f6527bd93f7421c6f65502f2660ce06bf50f782a6a5ccb3") -- Depot 2253491
setManifestid(2253491, "3786179666656141643", 117152665)