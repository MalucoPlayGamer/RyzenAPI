-- Lua provided by RyzenAPI
-- Game: Game: AppID 3228000

-- MAIN APPLICATION
addappid(3228000)
-- Game: addappid(3228000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228001, 1, "6bca35027f9f987dda7200a0cf8dc7ce25121ce6e4a0843db55984287e63f56f")
