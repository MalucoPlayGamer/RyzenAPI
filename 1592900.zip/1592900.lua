-- Lua provided by RyzenAPI
-- Game: PrisonShow

-- MAIN APPLICATION
addappid(1592900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592901, 1, "e797bdec240fd3866e7118fc506fcf22c1a58229d11843b66e833a09054fc51a")

