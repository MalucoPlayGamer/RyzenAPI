-- Lua provided by RyzenAPI
-- Game: Teenage Mutant Ninja Turtles: Portal Power

-- MAIN APPLICATION
addappid(700740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(700741, 1, "955fedc5e1a148ede2e278cdd16a361653d19aa44efda5aa50cc4b09c7fc801c")

