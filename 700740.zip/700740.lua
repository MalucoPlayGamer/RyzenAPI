-- Lua provided by RyzenAPI
-- Game: Game: Teenage Mutant Ninja Turtles: Portal Power

-- MAIN APPLICATION
addappid(700740)
-- Game: addappid(700740)

-- MAIN APP DEPOTS / PACKAGES
addappid(700741, 1, "955fedc5e1a148ede2e278cdd16a361653d19aa44efda5aa50cc4b09c7fc801c")
