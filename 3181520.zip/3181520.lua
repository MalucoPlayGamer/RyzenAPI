-- Lua provided by RyzenAPI
-- Game: addappid(3181520)

-- MAIN APPLICATION
addappid(3181520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181520,0,"b2c89929dff4950c9de05cee2684ea209d064417983fd41cb33542b5bcc329e6")
