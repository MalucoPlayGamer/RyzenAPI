-- Lua provided by RyzenAPI
-- Game: Backroom Company Demo

-- MAIN APPLICATION
addappid(3136910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136911, 1, "ff2de2ee0d9e5710bca15dc1cae43eeb8e3294751defb04190346d00b2bb01ec")
