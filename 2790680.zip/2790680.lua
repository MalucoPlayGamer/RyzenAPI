-- Lua provided by RyzenAPI
-- Game: Welcome to Paradise Island

-- MAIN APPLICATION
addappid(2790680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790681, 1, "8fc4a2a3376918f9ac900663016cead0a3f09a7568c9fbb5d36f41b28ec4a351")
addappid(2790682, 1, "32e8b1a9b858225878d2772e310bc958c143a901d39ddb49bf6c0da4cc6eabfd")
addappid(2790683, 1, "fe952c5faafb1f05af41fc99b3109c5915abbcaec861b9890f798be41e84f7ff")

