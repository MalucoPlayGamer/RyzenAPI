-- Lua provided by RyzenAPI
-- Game: Siege Survival: Gloria Victis Demo

-- MAIN APPLICATION
addappid(1314280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314281, 1, "739161cce1213db1f39a5fefc07262b79bd88dbf15dd15b921e76d16e1f65530")

