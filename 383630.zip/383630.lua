-- Lua provided by RyzenAPI
-- Game: addappid(383630)

-- MAIN APPLICATION
addappid(383630)

-- MAIN APP DEPOTS / PACKAGES
addappid(383631, 1, "bcb8fb8e02382a94fc47524f55a106ac8ef4bd3dbeb2c211fb204aa71ffceb36")
