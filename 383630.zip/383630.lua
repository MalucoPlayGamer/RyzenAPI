-- Lua provided by RyzenAPI
-- Game: SEEP Universe

-- MAIN APPLICATION
addappid(383630)

-- MAIN APP DEPOTS / PACKAGES
addappid(383631, 1, "bcb8fb8e02382a94fc47524f55a106ac8ef4bd3dbeb2c211fb204aa71ffceb36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
