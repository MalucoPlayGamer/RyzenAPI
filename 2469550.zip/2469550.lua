-- Lua provided by RyzenAPI
-- Game: Mortanis Prisoners Prologue

-- MAIN APPLICATION
addappid(2469550)
-- Game: addappid(2469550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469551, 1, "d027f81882363b5af4d1c49691a28de89ad4d4780918f20576be7b5e3a5299fe")
