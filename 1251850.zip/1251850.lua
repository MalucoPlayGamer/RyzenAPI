-- Lua provided by RyzenAPI
-- Game: Inferno - Beyond the 7th Circle

-- MAIN APPLICATION
addappid(1251850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251851, 1, "fc34ac430ba36842408e58c6383630d214ec48c48bcc72f770cf938dd047989b")
addappid(1251852, 1, "a6bebf2f868c750744d17c6cfd16ef74fd0214867402665a6be8c14ac60315c2")
addappid(1251853, 1, "a0aaafdf2bfecf9f678045b3314f0901d1d2a4c1e894abdcc6910817e6f995b0")
