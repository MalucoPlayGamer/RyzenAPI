-- Lua provided by SkyAPI 
-- Game: Aurora Nights
addappid(466870)
addappid(466871, 1, "e79cfc52acb09536d7d2f77c70bfc1c38d66aa2a80f43bc47f2b1ebcedb75276")
