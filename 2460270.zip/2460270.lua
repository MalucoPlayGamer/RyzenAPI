-- Lua provided by RyzenAPI
-- Game: When The Rumors Become Real

-- MAIN APPLICATION
addappid(2460270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460271, 1, "8ca7734f8263bc017538cc2462011026a02e37c4eefdded213834f0efd035528")
