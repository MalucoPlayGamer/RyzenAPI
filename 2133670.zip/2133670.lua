-- Lua provided by RyzenAPI 
-- Game: Perseus: Titan Slayer - Free Trial
addappid(2133670)
addappid(2133671, 1, "c80277409f3d813f4db741e66fb47cd4c31fa1ee39f1992f1c39e33c4c68d7c1")
