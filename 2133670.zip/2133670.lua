-- Lua provided by RyzenAPI
-- Game: Perseus: Titan Slayer - Free Trial

-- MAIN APPLICATION
addappid(2133670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133671, 1, "c80277409f3d813f4db741e66fb47cd4c31fa1ee39f1992f1c39e33c4c68d7c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
