-- Lua provided by RyzenAPI
-- Game: Love, Sam

-- MAIN APPLICATION
addappid(1073820)
-- Game: addappid(1073820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073821, 1, "eef946077d76347d909f1b39bc46c92abcfc29ada14551d226cb0f160f339807")
