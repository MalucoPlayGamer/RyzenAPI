-- Lua provided by RyzenAPI
-- Game: Hauntsters

-- MAIN APPLICATION
addappid(428240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(428241, 1, "cfae2e1f75d729a258d1d2a31258430046f41d8b3b1c1038eb0b97cc2ee4104c")

