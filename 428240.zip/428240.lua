-- Lua provided by RyzenAPI
-- Game: Game: Hauntsters

-- MAIN APPLICATION
addappid(428240)
-- Game: addappid(428240)

-- MAIN APP DEPOTS / PACKAGES
addappid(428241, 1, "cfae2e1f75d729a258d1d2a31258430046f41d8b3b1c1038eb0b97cc2ee4104c")
