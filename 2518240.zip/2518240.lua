-- Lua provided by RyzenAPI
-- Game: addappid(2518240)

-- MAIN APPLICATION
addappid(2518240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518242,0,"e62e8d87295d6ae84bdaca81214762d03705ff7d09824166bf3edb48f923b455")
