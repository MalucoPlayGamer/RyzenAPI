-- Lua provided by RyzenAPI
-- Game: 2095450

-- MAIN APPLICATION
addappid(2095450)
-- Game: addappid(2095450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095451, 1, "8466a2e543018497aabc7a0d9c57c9f82ff98dad268d99bb164868d9fd390233")
