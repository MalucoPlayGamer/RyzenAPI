-- Lua provided by RyzenAPI
-- Game: The Most Beautiful Room in the World

-- MAIN APPLICATION
addappid(1282670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282672,0,"4628293e83977a32cf9f9a953921d47fc58ae95e89c3fc5c9e08527f4fca6a5c")

