-- Lua provided by RyzenAPI
-- Game: AppID 1234290

-- MAIN APPLICATION
addappid(1234290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234291, 1, "dc2ff43245765dcff163e63c5a78cfa720bbae0d6ed8b279f3922ff93171fe50")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
