-- Lua provided by RyzenAPI
-- Game: AppID 1234290

-- MAIN APPLICATION
addappid(1234290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234291, 1, "dc2ff43245765dcff163e63c5a78cfa720bbae0d6ed8b279f3922ff93171fe50")
