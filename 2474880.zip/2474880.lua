-- Lua provided by RyzenAPI
-- Game: Game: Paint by Cubes

-- MAIN APPLICATION
addappid(2474880)
-- Game: addappid(2474880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474881, 1, "46d82744eceadaeb37633a369074699160fcf7b1c07a72aff47357eb20cba5f1")
