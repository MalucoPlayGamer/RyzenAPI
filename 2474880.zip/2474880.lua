-- Lua provided by RyzenAPI 
-- Game: Paint by Cubes
addappid(2474880)
addappid(2474881, 1, "46d82744eceadaeb37633a369074699160fcf7b1c07a72aff47357eb20cba5f1")
