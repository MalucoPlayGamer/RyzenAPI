-- Lua provided by RyzenAPI
-- Game: AppID 982510

-- MAIN APPLICATION
addappid(982510)
-- Game: addappid(982510)

-- MAIN APP DEPOTS / PACKAGES
addappid(982511, 1, "c1b4641f59041c5ce5bf0f8b1ba99304ee476f6024f271642ad2361e08c6b69c")
