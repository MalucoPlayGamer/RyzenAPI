-- Lua provided by RyzenAPI
-- Game: AppID 904960

-- MAIN APPLICATION
addappid(904960)

-- MAIN APP DEPOTS / PACKAGES
addappid(904961, 1, "ccaee3e3e89bab6df15d637bb8b24c1e2a0b6d0feb5d5b9a7a7234be69db7cea")

