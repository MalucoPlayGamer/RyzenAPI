-- Lua provided by RyzenAPI
-- Game: AppID 904960

-- MAIN APPLICATION
addappid(904960)

-- MAIN APP DEPOTS / PACKAGES
addappid(904961, 1, "ccaee3e3e89bab6df15d637bb8b24c1e2a0b6d0feb5d5b9a7a7234be69db7cea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
