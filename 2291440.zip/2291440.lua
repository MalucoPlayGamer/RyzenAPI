-- Lua provided by RyzenAPI
-- Game: RINA RhythmERROR：Prologue

-- MAIN APPLICATION
addappid(2291440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291441, 1, "b554d7bc2ba64ba3e2f333d5817bf7c3ce3c7b6cddf682fd5ee8ecfd8ab05b09")

