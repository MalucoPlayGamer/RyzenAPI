-- Lua provided by RyzenAPI 
-- Game: AppID 3252850
addappid(3252850)
addappid(3252851, 1, "88125251945b5024229d7ea85e8907853f2f1438042c5f0a2a4a20bb7d4e93b5")
