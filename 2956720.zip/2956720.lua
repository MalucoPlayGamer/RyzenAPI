-- Lua provided by RyzenAPI
-- Game: Star Chef Simulator

-- MAIN APPLICATION
addappid(2956720)
-- Game: addappid(2956720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956722,0,"2b4e312fd29b1f78c9707dd8e07567a3c89652ef2e0193d653acfec495d6618c")
