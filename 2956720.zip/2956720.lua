-- Lua provided by RyzenAPI
-- Game: Star Chef Simulator

-- MAIN APPLICATION
addappid(2956720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2956722,0,"2b4e312fd29b1f78c9707dd8e07567a3c89652ef2e0193d653acfec495d6618c")

