-- Lua provided by RyzenAPI
-- Game: Game: AppID 1089600

-- MAIN APPLICATION
addappid(1089600)
-- Game: addappid(1089600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089601, 1, "febd3935e0fb04cee1389129c64eaa851002220a50d3864f3e9a5a4c95a99523")
