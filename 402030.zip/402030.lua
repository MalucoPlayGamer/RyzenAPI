-- Lua provided by RyzenAPI
-- Game: Zenohell

-- MAIN APPLICATION
addappid(402030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(402031, 1, "b1959f7fd8f27e247b6e943e3226774959eeea57442ff1a18e15de68fea88074")

