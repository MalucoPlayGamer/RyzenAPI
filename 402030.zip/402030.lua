-- Lua provided by RyzenAPI
-- Game: addappid(402030)

-- MAIN APPLICATION
addappid(402030)

-- MAIN APP DEPOTS / PACKAGES
addappid(402031, 1, "b1959f7fd8f27e247b6e943e3226774959eeea57442ff1a18e15de68fea88074")
