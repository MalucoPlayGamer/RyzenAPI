-- Lua provided by RyzenAPI
-- Game: AppID 1919590

-- MAIN APPLICATION
addappid(1919590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919591, 1, "9a413d95948077bb749d1ac87416be4b6b0da6b5f64ad460fd8afe1dd4897f1e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2074590)
addappid(2074591)
addappid(2074592)
addappid(2074593)
addappid(2074594)
