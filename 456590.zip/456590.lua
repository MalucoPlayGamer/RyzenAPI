-- Lua provided by RyzenAPI
-- Game: AppID 456590

-- MAIN APPLICATION
addappid(456590)
-- Game: addappid(456590)

-- MAIN APP DEPOTS / PACKAGES
addappid(456591, 1, "8a4b3996ccb5291b0090edb5bedbafbc8357336755c7987c6d0797db9f667407")
