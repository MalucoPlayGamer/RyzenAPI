-- Lua provided by RyzenAPI
-- Game: Solitaire. Dragon Light

-- MAIN APPLICATION
addappid(990400)
-- Game: addappid(990400)

-- MAIN APP DEPOTS / PACKAGES
addappid(990401, 1, "b2bfcb5e7481a659de64a812c1965d4d79421afa53e35758e2f1a913513db82c")
addappid(990402, 1, "b0961d665a920d9389a5c4c82e1de04e863a75f235504df7f07148d66d8bb26f")
addappid(990403, 1, "ed1fa8c0df24430ec7d42df8ee01bcffd9ae26ec8dcf7542e33db07a405580db")
addappid(990404, 1, "bb1ed9882a848e128f96cfb798309228039fac33c23bbfaebb7bc2fe97761993")
addappid(990405, 1, "01ca7feeae3336fb36356ffa3ec6a9c8e7895f95399bee61f2850d311487dcb2")
addappid(990406, 1, "e21c4d960efbb8f401f1afcca118fffcf717cffde0a8f905dd9fe5501ab48454")
addappid(990407, 1, "ea7c427fa7b28a70455e3fc9c647289eae995f235897392958919b7125930f9c")
addappid(990408, 1, "5b3088487bfa5e00c13cdd46d77ca69e8b60b0b4e4e7049a9dd8b319bc706c8a")
