-- Lua provided by RyzenAPI
-- Game: DeadCore

-- MAIN APPLICATION
addappid(284460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(284461, 1, "45ba782ae82222e55daabe3fabd80037f4edf14c8ee57f7e99d54746122bc17b")
addappid(284462, 1, "ee5e8cecf5f77e56caaaaee7b574ded64b64304c621eb2c71204c9b095167120")
addappid(284463, 1, "45ce766bd7eb007fb1c7289814c2afe18568b37b53536f98d24d086737acbe13")

