-- Lua provided by RyzenAPI
-- Game: Casual Sport Series: Hockey

-- MAIN APPLICATION
addappid(2936440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936441,0,"3af9c482ab129acec17c99fd908294cec1af5d86ab0d0098581c010ede5e3eb3")

