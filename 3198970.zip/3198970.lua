-- Lua provided by RyzenAPI
-- Game: AppID 3198970

-- MAIN APPLICATION
addappid(3198970)
-- Game: addappid(3198970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198971, 1, "0649dd0c38e1f9a80d656f05c5b1df34ae5172c835cafb1094685ff3e2e85e5a")
