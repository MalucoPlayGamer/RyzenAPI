-- Lua provided by RyzenAPI
-- Game: Across Killzone

-- MAIN APPLICATION
addappid(1533610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533611, 1, "16d8a4ca4ea2ba326be4a1c0897d22b6483d2ca19cbac01f5f5b1513860b5fc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
