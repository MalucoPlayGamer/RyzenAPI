-- Lua provided by RyzenAPI
-- Game: Game: Across Killzone

-- MAIN APPLICATION
addappid(1533610)
-- Game: addappid(1533610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533611, 1, "16d8a4ca4ea2ba326be4a1c0897d22b6483d2ca19cbac01f5f5b1513860b5fc7")
