-- Lua provided by RyzenAPI
-- Game: addappid(2945610)

-- MAIN APPLICATION
addappid(2945610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945610,0,"bbe5da829bb0f945cca502394f4e116a571e24dc9d17942e537ba40cca9e5edd")
