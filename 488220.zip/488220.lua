-- Lua provided by RyzenAPI
-- Game: AppID 488220

-- MAIN APPLICATION
addappid(488220)
-- Game: addappid(488220)

-- MAIN APP DEPOTS / PACKAGES
addappid(488221, 1, "1a690ffe78624ec8078a6924fe11251dab63b8e17c8779c4e94f27cc863ffca5")
