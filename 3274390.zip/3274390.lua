-- Lua provided by RyzenAPI
-- Game: Bambas!

-- MAIN APPLICATION
addappid(3274390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274391, 1, "c634434d02212c5a6f0553b4ae850bd95418e15ae394cfc1849cea47b4147c2f")
