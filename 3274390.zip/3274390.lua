-- Lua provided by SkyAPI 
-- Game: Bambas!
addappid(3274390)
addappid(3274391, 1, "c634434d02212c5a6f0553b4ae850bd95418e15ae394cfc1849cea47b4147c2f")
