-- Lua provided by RyzenAPI
-- Game: Links E6

-- MAIN APPLICATION
addappid(1620750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620751, 1, "b3647764bec9aa953067926fece1702072d9469159c1e3e121298930aa28f0da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1663020)
addappid(1663021)
addappid(1663022)
