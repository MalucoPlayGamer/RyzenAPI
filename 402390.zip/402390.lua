-- Lua provided by RyzenAPI
-- Game: Hyperdrive Massacre

-- MAIN APPLICATION
addappid(402390)

-- MAIN APP DEPOTS / PACKAGES
addappid(402391, 1, "ed2c1f4161039618572688fd656e77c9811960ab2e43453ce909f1263d9d7af1")
addappid(402392, 1, "29b0f71c328d59462dbfa71d7314a41505e67e331462bd033d42f493a3fc7e75")
addappid(402393, 1, "7411345aee40fc1fa15c0f6c0184f4f03cb79ee323060f3b786c13e5ca34420a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
