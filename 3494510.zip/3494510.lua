-- Lua provided by RyzenAPI 
-- Game: City Tales - Medieval Era Demo
addappid(3494510)
addappid(3494511, 1, "cb029148e105c55984019f75755f9ebfcbe61b86efb7824227cb4721154b1c91")
