-- Lua provided by RyzenAPI
-- Game: Last Meow Standing

-- MAIN APPLICATION
addappid(1986470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1986471, 1, "9c859911479601a7e24765f0d0d1bfe3124be40c24264a466598f72fcd846d04")

