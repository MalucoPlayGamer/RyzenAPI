-- Lua provided by RyzenAPI 
-- Game: Last Meow Standing
addappid(1986470)
addappid(1986471, 1, "9c859911479601a7e24765f0d0d1bfe3124be40c24264a466598f72fcd846d04")
