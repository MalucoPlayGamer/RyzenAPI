-- Lua provided by RyzenAPI
-- Game: You're Not Special

-- MAIN APPLICATION
addappid(991430) -- You're Not Special
addappid(994510)

-- MAIN APP DEPOTS / PACKAGES
addappid(991432, 1, "3ce69ce4f9672e6ecdc944a75f4f13914955d364bd384ec2c23bcca53f4f9d83") -- You're Not Special Mac OS X
addappid(991431, 1, "ae6ad5bdf5e9c0bd735aa42ef14bd4c47d710092ec34b4de99018f184cb9d7c3") -- You're Not Special Windows
addappid(991433, 1, "e2deb7a4625fc789173a3b7b612237732e8616bf48276c2837384339c78c06a7") -- Youre Not Special - Soundtrack - You're Not Special - Soundtrack
