-- Lua provided by RyzenAPI
-- Game: Game: AppID 1365560

-- MAIN APPLICATION
addappid(1365560)
-- Game: addappid(1365560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365561, 1, "bec0ae429ec75fe2ccdb09d88b3e6476c25f092cffc1aea75d26d06e3f4c84e4")
