-- Lua provided by RyzenAPI
-- Game: Game: Too Tired To Die

-- MAIN APPLICATION
addappid(3078920)
-- Game: addappid(3078920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078921, 1, "7d79c56c8fb5bccb260a2307e96f1eb6b2f65f1402c53a83b95f9c05b095ceb1")
