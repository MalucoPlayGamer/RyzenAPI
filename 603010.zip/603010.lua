-- Lua provided by RyzenAPI 
-- Game: AppID 603010
addappid(603010)
addappid(603011, 1, "ce16069b2965e99e14b34d9c3050e3bce188dc1f81ad0c28fd96375f425551eb")
addappid(603012, 1, "192de299562f19608c1c3e6c5559c2c7c41cfd4678f5779c2850f7dd18f21a68")
