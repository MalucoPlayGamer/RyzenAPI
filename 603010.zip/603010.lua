-- Lua provided by RyzenAPI
-- Game: AppID 603010

-- MAIN APPLICATION
addappid(603010)

-- MAIN APP DEPOTS / PACKAGES
addappid(603011, 1, "ce16069b2965e99e14b34d9c3050e3bce188dc1f81ad0c28fd96375f425551eb")
addappid(603012, 1, "192de299562f19608c1c3e6c5559c2c7c41cfd4678f5779c2850f7dd18f21a68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
