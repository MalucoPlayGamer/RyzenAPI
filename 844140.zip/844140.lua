-- Lua provided by RyzenAPI
-- Game: addappid(844140)

-- MAIN APPLICATION
addappid(844140)

-- MAIN APP DEPOTS / PACKAGES
addappid(844141, 1, "2798ba780e93241021f5cb4e2916d06b79cd2c9cc861a016406964f8bed8457d")
