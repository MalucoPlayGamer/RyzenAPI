-- 2297880's Lua and Manifest Created by Hubcap Manifest
-- CODING ROBO
-- Created: August 01, 2026 at 05:07:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2297880) -- CODING ROBO
-- MAIN APP DEPOTS
addappid(2297881, 1, "f3a7b9036b4cfaa251051f2524382d79e9265f3a8fdaef298b4f4447f26751fe") -- Depot 2297881
setManifestid(2297881, "5248550834139379110", 709501887)