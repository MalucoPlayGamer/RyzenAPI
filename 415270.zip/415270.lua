-- Lua provided by RyzenAPI
-- Game: Star Crusade CCG

-- MAIN APPLICATION
addappid(415270)
addappid(477810)
addappid(492330)
addappid(492331)
addappid(546860)
addappid(559880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(415271, 1, "aea65199507cdb6a62bb5bb98252c28611d6924848bb0452e44fde3df069b94c")

