-- Lua provided by RyzenAPI
-- Game: Star Crusade CCG

-- MAIN APPLICATION
addappid(415270)

-- MAIN APP DEPOTS / PACKAGES
addappid(415271, 1, "aea65199507cdb6a62bb5bb98252c28611d6924848bb0452e44fde3df069b94c")
