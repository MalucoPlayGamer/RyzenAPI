-- Lua provided by RyzenAPI
-- Game: Game: AppID 385200

-- MAIN APPLICATION
addappid(385200)
-- Game: addappid(385200)

-- MAIN APP DEPOTS / PACKAGES
addappid(385201, 1, "c0317e07497cf1eb372fa93d74342ea8d75431f22dbf34885a7f0e67d0974198")
