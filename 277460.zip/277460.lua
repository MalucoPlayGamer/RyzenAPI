-- Lua provided by RyzenAPI
-- Game: Game: Praetorians

-- MAIN APPLICATION
addappid(277460)
-- Game: addappid(277460)

-- MAIN APP DEPOTS / PACKAGES
addappid(277461, 1, "2bd0d4e0e56431664131b6c02276d2d18556a7eeb02ba1b1105ae3ac12d50d11")
