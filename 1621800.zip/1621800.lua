-- Lua provided by RyzenAPI
-- Game: The Crackpet Show Demo

-- MAIN APPLICATION
addappid(1621800)
-- Game: addappid(1621800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621801, 1, "70966157c2cf613216e7b4c91e1bef96ee42916e0090170248117d941aabbe9d")
