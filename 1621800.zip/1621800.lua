-- Lua provided by SkyAPI 
-- Game: The Crackpet Show Demo
addappid(1621800)
addappid(1621801, 1, "70966157c2cf613216e7b4c91e1bef96ee42916e0090170248117d941aabbe9d")
