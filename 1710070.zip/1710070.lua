-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 4

-- MAIN APPLICATION
addappid(1710070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710070,0,"52e31438fc5cb0fb0eb89861f1a2f60a239cc4356521031c1f37276151d08705")

