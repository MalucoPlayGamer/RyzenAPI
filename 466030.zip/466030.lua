-- Lua provided by RyzenAPI
-- Game: Otherworld: Spring of Shadows Collector's Edition

-- MAIN APPLICATION
addappid(466030)

-- MAIN APP DEPOTS / PACKAGES
addappid(466031, 1, "59e67589c55f9efbf33cd1810205209f7feab24fb5f67af07d3600a9bad76060")
