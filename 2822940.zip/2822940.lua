-- Lua provided by RyzenAPI
-- Game: AppID 2822940

-- MAIN APPLICATION
addappid(2822940)
-- Game: addappid(2822940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2822941, 1, "5b366c0271e65ba5ba129c1825fdcd3510b6993af3f3f3bdf6fa30fc8ae53755")
