-- Lua provided by RyzenAPI
-- Game: Steps of Debauchery

-- MAIN APPLICATION
addappid(2649970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649971, 1, "9aa3e4d1f2a413dbec23cbda51fe786f5f55564444b24d8bdbc0e05099d2a483")
addappid(2808680, 0, "76b27b3113a09f716499a01206b3d65237b9bf62d0bba7f3ef5bf798d3eb9881")

