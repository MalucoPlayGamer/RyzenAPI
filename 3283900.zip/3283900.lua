-- Lua provided by RyzenAPI
-- Game: addappid(3283900)

-- MAIN APPLICATION
addappid(3283900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3283901, 1, "41fc0c0219e885fce044d5133b34719408391bda9b7b90307c741c9dae75b0c6")
