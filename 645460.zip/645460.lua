-- Lua provided by RyzenAPI
-- Game: Mind Maze

-- MAIN APPLICATION
addappid(645460)
addappid(646320)
addappid(646480)

-- MAIN APP DEPOTS / PACKAGES
addappid(645461, 1, "a6adc79aa561159cdebd0a81d66e25537232dee1c4a8b3a209aaf2328ae29d49")
