-- Lua provided by SkyAPI 
-- Game: AppID 645460
addappid(645460)
addappid(645461, 1, "a6adc79aa561159cdebd0a81d66e25537232dee1c4a8b3a209aaf2328ae29d49")
