-- Lua provided by RyzenAPI 
-- Game: AppID 2943070
addappid(2943070)
addappid(2943071, 1, "80733d32586237f8ab030696c2aa72a65297e942e68717b839e31208d46ae323")
