-- Lua provided by RyzenAPI
-- Game: Game: Cyborg Invasion Shooter 2: Battle Of Earth

-- MAIN APPLICATION
addappid(779060)
-- Game: addappid(779060)

-- MAIN APP DEPOTS / PACKAGES
addappid(779061, 1, "f4015c06ff69507dd4b07c926c6575159767d343138f2c4cbb0f2c8fd3673a1e")
