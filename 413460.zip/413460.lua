-- Lua provided by RyzenAPI
-- Game: AppID 413460

-- MAIN APPLICATION
addappid(413460)

-- MAIN APP DEPOTS / PACKAGES
addappid(413461, 1, "e5165439e94985e0f02d09cb607fc672c2fbe36beaec7e31ec1ca54b9322b373")
