-- Lua provided by SkyAPI 
-- Game: Alekon
addappid(1479390)
addappid(1479391, 1, "2d59e393cadc673f6c838f01ee1ac3da733228c1bfe15850c308438ff48d3ac0")
