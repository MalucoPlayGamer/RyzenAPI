-- Lua provided by RyzenAPI
-- Game: Alekon

-- MAIN APPLICATION
addappid(1479390)
-- Game: addappid(1479390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479391, 1, "2d59e393cadc673f6c838f01ee1ac3da733228c1bfe15850c308438ff48d3ac0")
