-- Lua provided by RyzenAPI
-- Game: Change : A Little Story

-- MAIN APPLICATION
addappid(979790)

-- MAIN APP DEPOTS / PACKAGES
addappid(979791, 1, "de8dfa639365410e27781eea083b28aa2aa2d3a6558038df1f5a024083cb8a21")
