-- Lua provided by RyzenAPI
-- Game: Mighty Party

-- MAIN APPLICATION
addappid(575720)
addappid(616280)
addappid(616300)
addappid(645430)
addappid(698560)
addappid(714230)
addappid(798520)

-- MAIN APP DEPOTS / PACKAGES
addappid(575721, 1, "0d9cd9b3835aa95a08a09ac4622c38603247089b4211036ec91ddef2827dbd01")

