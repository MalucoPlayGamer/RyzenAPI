-- Lua provided by RyzenAPI
-- Game: Battle Grid: Prologue

-- MAIN APPLICATION
addappid(2184680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184681, 1, "7a3b8d695ea5cf6cb136cf5b96fcd6a42b1416e8a79ba4aff95274e0ef6d1ab6")

