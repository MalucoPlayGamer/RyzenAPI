-- Lua provided by RyzenAPI
-- Game: Helenenkapelle VR

-- MAIN APPLICATION
addappid(2840730)
addappid(2851570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2840731, 1, "5c19af4e1e6c78bbf68179366eb14236fd6e7add65e956a4bfaf8faa4e289ffa")

