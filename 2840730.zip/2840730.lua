-- Lua provided by RyzenAPI
-- Game: Helenenkapelle VR

-- MAIN APPLICATION
addappid(2840730)
addappid(2851570)
-- Game: addappid(2840730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840731, 1, "5c19af4e1e6c78bbf68179366eb14236fd6e7add65e956a4bfaf8faa4e289ffa")
