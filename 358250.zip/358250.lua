-- Lua provided by RyzenAPI
-- Game: addappid(358250)

-- MAIN APPLICATION
addappid(358250)

-- MAIN APP DEPOTS / PACKAGES
addappid(358251, 1, "f7d5319340f5f80899d68b4ad882d1a3425e156cdd30ec304e0aa33a4b0c5795")
addappid(358252, 1, "332630ed00abfec7fb400cb14b94bfd3bc9e8bd10e17618c5048b188ec4ba1e5")
