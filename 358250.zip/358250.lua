-- Lua provided by RyzenAPI
-- Game: Cosmo's Cosmic Adventure

-- MAIN APPLICATION
addappid(358250)

-- MAIN APP DEPOTS / PACKAGES
addappid(358251, 1, "f7d5319340f5f80899d68b4ad882d1a3425e156cdd30ec304e0aa33a4b0c5795")
addappid(358252, 1, "332630ed00abfec7fb400cb14b94bfd3bc9e8bd10e17618c5048b188ec4ba1e5")
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)
