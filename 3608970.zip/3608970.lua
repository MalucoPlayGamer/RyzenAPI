-- Lua provided by RyzenAPI
-- Game: 3608970

-- MAIN APPLICATION
addappid(3608970)
-- Game: addappid(3608970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3608970,0,"ea8642009251000bfc629cf5d1b9219ce2d3a90bd3bcbc2d6265f719551ff183")
