-- Lua provided by RyzenAPI
-- Game: 2787050

-- MAIN APPLICATION
addappid(2787050)
-- Game: addappid(2787050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787051, 1, "ee09c2d1722de0b9c4fac681b02960b09a345a8abe726fdb6a62d7da08e52984")
