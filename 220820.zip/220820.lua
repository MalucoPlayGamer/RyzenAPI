-- Lua provided by RyzenAPI
-- Game: Game: Zombie Driver HD

-- MAIN APPLICATION
addappid(220820)
-- Game: addappid(220820)

-- MAIN APP DEPOTS / PACKAGES
addappid(220821, 1, "4996141532ceebad7d1ced4385acfe2e4ffd4ca81dd3d6b37b0b846c850124c1")
addappid(220823, 1, "746b1ebb21f64c72dcefc35312023009a6ab05b23dfc52f832282cdbd7e0bbd5")
addappid(220824, 1, "d7657eae85be299bd5a0e2d3a4fd9376efa367f4475ba446e91c28228e10f0fd")
addappid(220825, 1, "a83d73be99aa729edc6464af10090ecd7af80a540dd5a2f381bd399e8d8c84ec")
addappid(301900, 0, "22b90bceb74c86497d2c97f2308f12c9fbe9bbd285464ba7b5814317842f84d7")
