-- Lua provided by RyzenAPI
-- Game: Game: AppID 3407640

-- MAIN APPLICATION
addappid(3407640)
-- Game: addappid(3407640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3407641, 1, "b771080795e6ab276c8c57ad8b75f83f3e5c3b19020dbcdc56c2883f6c378439")
