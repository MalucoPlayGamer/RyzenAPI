-- Lua provided by RyzenAPI
-- Game: 3023890

-- MAIN APPLICATION
addappid(3023890)
-- Game: addappid(3023890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023891, 1, "a7cd23d66b5fc82bd182e6b9eb94988a435c0c008affc9fb339662e1777032ff")
