-- Lua provided by RyzenAPI
-- Game: Mini Golf Aeons

-- MAIN APPLICATION
addappid(2335910)
addappid(2335950)
-- Game: addappid(2335910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335911, 1, "60023bbc18ebf39fb28989fbd89a5c0362519bea967dff7dc67ca2d5a8cfc483")
