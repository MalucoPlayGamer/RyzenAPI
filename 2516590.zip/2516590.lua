-- Lua provided by RyzenAPI
-- Game: Human Farm - Practice Section

-- MAIN APPLICATION
addappid(2516590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516592,0,"21d4d92bdf08319a790ae451d712001f08edca2f0a2ac7ac794757e31f9fd5c5")
addappid(2516593,0,"ffaf39c20d9a8e86c41e027dc7e79c07e1dfd0aaa65846d15095bc5d42a9cc37")
addappid(2516594,0,"0f3785937bb6176782535789af6bb15ba947ea760a0160025eb6c08777e509a1")
