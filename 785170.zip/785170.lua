-- Lua provided by RyzenAPI
-- Game: addappid(785170)

-- MAIN APPLICATION
addappid(785170)

-- MAIN APP DEPOTS / PACKAGES
addappid(785171, 1, "317d5c5bf70d7c9583eede5a94506be461847c5fad4be8d5b12b0277e0cb3c0b")
