-- Lua provided by RyzenAPI
-- Game: addappid(1151120)

-- MAIN APPLICATION
addappid(1151120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151121, 1, "ce57507e09366c560b8bc451efb1f0ad3dc9c7944b1361246f6f1a58a910a7a9")
