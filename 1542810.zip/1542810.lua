-- Lua provided by RyzenAPI
-- Game: Sunshine Heavy Industries

-- MAIN APPLICATION
addappid(1542810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542812,0,"92de078ec1bd720e72914d0c7b0473dfbb7288ec45b98f1a50b9d3e1ff7e68c4")

