-- Lua provided by RyzenAPI
-- Game: Be kinder and, like, be a Rewinder, dude!

-- MAIN APP DEPOTS / PACKAGES
addappid(4656280) -- Be kinder and, like, be a Rewinder, dude!
addappid(4656281, 1, "7599fc3293f17a22aff09ceef0c2ecc6edd8dec3a7a8f961a33c2166ed53fa2c") -- Depot 4656281

