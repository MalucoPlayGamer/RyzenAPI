-- 4656280's Lua and Manifest Created by Hubcap Manifest
-- Be kinder and, like, be a Rewinder, dude!
-- Created: August 27, 2026 at 13:30:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4656280) -- Be kinder and, like, be a Rewinder, dude!
-- MAIN APP DEPOTS
addappid(4656281, 1, "7599fc3293f17a22aff09ceef0c2ecc6edd8dec3a7a8f961a33c2166ed53fa2c") -- Depot 4656281
setManifestid(4656281, "800356066087894272", 185898369)