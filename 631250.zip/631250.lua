-- Lua provided by RyzenAPI
-- Game: Double Clue: Solitaire Stories

-- MAIN APPLICATION
addappid(631250)

-- MAIN APP DEPOTS / PACKAGES
addappid(631251,0,"1d760b47e902028bdb2671d3db826cde2612d713eb4dc27e0b44bb87881f7675")

