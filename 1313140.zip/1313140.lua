-- Lua provided by RyzenAPI
-- Game: Cult of the Lamb

-- MAIN APPLICATION
addappid(1944680) -- Cult of the Lamb Plush Bonus
addappid(2013550) -- Cult of the Lamb Pre-Order Bonus
addappid(2015880) -- Cult of the Lamb Cultist Pack
addappid(2071370) -- Cult of the Lamb - Frankerz Twitch Drop
addappid(2090900) -- Cult of the Lamb - Ralpherz Twitch Drop
addappid(2090901) -- Cult of the Lamb - Pogchamp Twitch Drop
addappid(2202620) -- Cult of the Lamb - Penguin Twitch Drop
addappid(2202621) -- Cult of the Lamb - Lion Twitch Drop
addappid(2202622) -- Cult of the Lamb - Kiwi Twitch Drop
addappid(2202623) -- Cult of the Lamb - Pelican Twitch Drop
addappid(2202624) -- Cult of the Lamb - Glommer Statue Twitch Drop
addappid(2202625) -- Cult of the Lamb - Beefalo Skeleton Twitch Drop
addappid(2202626) -- Cult of the Lamb PAX East 2023 Bonus
addappid(2331540) -- Cult of the Lamb Heretic Pack
addappid(2646130) -- Cult of the Lamb Sinful Pack
addappid(2647140) -- Cult of the Lamb - Pea Twitch Drop
addappid(2647150) -- Cult of the Lamb - Owe Twitch Drop
addappid(2647160) -- Cult of the Lamb - Ghee Twitch Drop
addappid(2890190) -- Cult of the Lamb Pilgrim Pack
addappid(2945120) -- Cult of the Lamb - Goat Statue Twitch Drop
addappid(2945130) -- Cult of the Lamb - Goat Lantern Twitch Drop
addappid(2945140) -- Cult of the Lamb - Goat Plant Twitch Drop
addappid(3017350) -- Cult of the Lamb - Support a Streamer Pack
addappid(3840050) -- Cult of the Lamb Woolhaven
addappid(4153010) -- Cult of the Lamb - Woolhaven Twitch Drop AnglerFish
addappid(4153020) -- Cult of the Lamb - Woolhaven Twitch Drop SeaButterfly
addappid(4153030) -- Cult of the Lamb - Woolhaven Twitch Drop Jellyfish
addappid(4153040) -- Cult of the Lamb - Woolhaven Twitch Drop Leech
addappid(4153050) -- Cult of the Lamb - Woolhaven Twitch Drop LizardTongue

-- MAIN APP DEPOTS / PACKAGES
addappid(1313140, 1, "27732d161d8388b7c13dd209b6ae7fca2ea73343ba541da90800c6bf521a50c3") -- Cult of the Lamb
addappid(1313141, 1, "e7826851aae21726cd847e809a97378d381ba16449186ce1cdb57c572d703460") -- Depot 1313141
addappid(1313142, 1, "242e4da3afdadce6aa2329f9f1c8c71fe09c06f51a80c105a444734a12c9e3f2") -- Depot 1313142

