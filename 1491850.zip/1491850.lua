-- Lua provided by RyzenAPI
-- Game: ZombieWave-UnlimitedChallenges

-- MAIN APPLICATION
addappid(1491850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491851, 1, "f1ae0ff558253e507ca8afecf9ef55788384fd57ca107fb60b1109f2f6b11a97")

