-- Lua provided by RyzenAPI
-- Game: 404390

-- MAIN APPLICATION
addappid(404390)
-- Game: addappid(404390)

-- MAIN APP DEPOTS / PACKAGES
addappid(404391, 1, "566911551e57f523ead17c65a854bbdee73353cbd947eaf97d0a9d1e6cf60a31")
