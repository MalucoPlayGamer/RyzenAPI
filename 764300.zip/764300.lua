-- Lua provided by RyzenAPI
-- Game: Shantae: Half-Genie Hero Ultimate Edition

-- MAIN APPLICATION
addappid(764300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(764301, 1, "c53e06fd23cbdc911ebffad906d24280eed0fdb37db4986767f3cdf450c6aaf8")

