-- Lua provided by RyzenAPI
-- Game: 764300

-- MAIN APPLICATION
addappid(764300)
-- Game: addappid(764300)

-- MAIN APP DEPOTS / PACKAGES
addappid(764301, 1, "c53e06fd23cbdc911ebffad906d24280eed0fdb37db4986767f3cdf450c6aaf8")
