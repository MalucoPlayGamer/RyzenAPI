-- Lua provided by RyzenAPI
-- Game: Game: 永恒幻境 Eternal Dreamland

-- MAIN APPLICATION
addappid(2722270)
-- Game: addappid(2722270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722271, 1, "8d6a6d6558a8b1c4531e3ad621a235eabb499bbdcda18dad860faf57e4274a7c")
