-- Lua provided by RyzenAPI
-- Game: 永恒幻境 Eternal Dreamland

-- MAIN APPLICATION
addappid(2722270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722271, 1, "8d6a6d6558a8b1c4531e3ad621a235eabb499bbdcda18dad860faf57e4274a7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
