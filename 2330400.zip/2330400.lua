-- Lua provided by RyzenAPI
-- Game: Game: I Have No Nose and I Must Climb

-- MAIN APPLICATION
addappid(2330400)
-- Game: addappid(2330400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330401, 1, "bfd33fb30c01b1101bc26f2cb641dc89a3a089d248a064000bfbafd1664a5c8b")
