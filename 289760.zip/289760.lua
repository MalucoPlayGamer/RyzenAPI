-- Lua provided by RyzenAPI
-- Game: 289760

-- MAIN APPLICATION
addappid(289760)
addappid(362760)
-- Game: addappid(289760)

-- MAIN APP DEPOTS / PACKAGES
addappid(289761, 1, "b57bf9aaed0f70469705d7263e3bb2ca3e4eb64dbc8950b34f7c382db911bc17")
addappid(289762, 1, "9fbacfb3b3adfcaa9c5e34c805a24d165eeaf0bd121d21707a412ee2fa8b50b4")
addappid(289763, 1, "baa78903c49f341ee4b847515b0d6b6bb66dbb45f2ba346f3a3d74e24061bab1")
