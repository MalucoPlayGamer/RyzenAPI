-- Lua provided by RyzenAPI
-- Game: AppID 289760

-- MAIN APPLICATION
addappid(289760)
addappid(362760)

-- MAIN APP DEPOTS / PACKAGES
addappid(289761, 1, "b57bf9aaed0f70469705d7263e3bb2ca3e4eb64dbc8950b34f7c382db911bc17")
addappid(289762, 1, "9fbacfb3b3adfcaa9c5e34c805a24d165eeaf0bd121d21707a412ee2fa8b50b4")
addappid(289763, 1, "baa78903c49f341ee4b847515b0d6b6bb66dbb45f2ba346f3a3d74e24061bab1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
