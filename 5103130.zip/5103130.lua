-- Lua provided by RyzenAPI
-- Game: Starforge Incremental

-- MAIN APPLICATION
addappid(5103130) -- Starforge Incremental

-- MAIN APP DEPOTS / PACKAGES
addappid(5103131, 1, "c4c21b14e0c2de7a63dc8b136e28147fe912976e4754fafc65c53ece33827745") -- Depot 5103131
