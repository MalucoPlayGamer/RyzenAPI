-- Lua provided by RyzenAPI
-- Game: S.O.R.S

-- MAIN APPLICATION
addappid(374620)

-- MAIN APP DEPOTS / PACKAGES
addappid(374621, 1, "1d6f36d30a1cc80db7469b5941e173b22cf07d066edd966b9ab4ea51d8681f9a")

