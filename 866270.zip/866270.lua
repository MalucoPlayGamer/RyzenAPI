-- Lua provided by RyzenAPI
-- Game: 866270

-- MAIN APPLICATION
addappid(866270)
-- Game: addappid(866270)

-- MAIN APP DEPOTS / PACKAGES
addappid(866271, 1, "9ad7102a820da9e3277225152acc2cc0071db26c479b6ca94bd23713d5e5f778")
