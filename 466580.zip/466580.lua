-- Lua provided by RyzenAPI
-- Game: Game: AppID 466580

-- MAIN APPLICATION
addappid(466580)
-- Game: addappid(466580)

-- MAIN APP DEPOTS / PACKAGES
addappid(466581, 1, "25e3e4e89e8511656a63608439afee863691f6ddb726499ef5f8aec139c2f169")
