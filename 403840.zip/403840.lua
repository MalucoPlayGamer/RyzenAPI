-- Lua provided by RyzenAPI
-- Game: Stacks TNT

-- MAIN APPLICATION
addappid(403840)

-- MAIN APP DEPOTS / PACKAGES
addappid(403841, 1, "190a73d877cdb093e453d532b313a093d4b0c57bbe0cd6a691ae89a05379ae97")
