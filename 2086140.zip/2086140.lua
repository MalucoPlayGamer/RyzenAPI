-- Lua provided by RyzenAPI
-- Game: RICE - Repetitive Indie Combat Experience™

-- MAIN APPLICATION
addappid(2086140)
-- Game: addappid(2086140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086141, 1, "247f6a1d30960a7c2b135028ec2c8e05b91d55f7624127a7d114567b2826cbe5")
