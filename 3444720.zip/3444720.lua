-- Lua provided by RyzenAPI
-- Game: The Sultan and his Harem

-- MAIN APPLICATION
addappid(3444720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444721, 1, "077a0bab9b898ae814f4121f6151b4e7c664df087b0da9bd40adfae751c3c71f")
