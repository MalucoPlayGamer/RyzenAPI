-- Lua provided by RyzenAPI
-- Game: 476490

-- MAIN APPLICATION
addappid(476490)
-- Game: addappid(476490)

-- MAIN APP DEPOTS / PACKAGES
addappid(476491, 1, "32870862315e77590ed78988bf651efbd7da1c31bb8a0f2f5854ecb54a9ddbbc")
