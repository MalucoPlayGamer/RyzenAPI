-- Lua provided by RyzenAPI
-- Game: Class Five Memorial GAME

-- MAIN APPLICATION
addappid(1964970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1964971, 1, "a77b92dfbb2b1101090e1a72045f56c11d8492896ced809e9f2ef081f82f6e20")

