-- Lua provided by RyzenAPI
-- Game: Class Five Memorial GAME

-- MAIN APPLICATION
addappid(1964970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964971, 1, "a77b92dfbb2b1101090e1a72045f56c11d8492896ced809e9f2ef081f82f6e20")

