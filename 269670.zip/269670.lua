-- Lua provided by SkyAPI 
-- Game: BADLAND: Game of the Year Edition
addappid(269670)
addappid(269671, 1, "80ef90a3cf557af8085a83d6d535d7c8a107d5ae95adfdebef1168a471529704")
addappid(269672, 1, "2ee3405dca26f0fc5455c6d8cd12d2ca7c88c3c35fd5e31814eac128c73c94fc")
addappid(269673, 1, "d3deef9fb8e29bdda65f20c2c718fd12f2b17eec4d4d51e1b8f9a9ee634a5096")
addappid(367210, 0, "7831ec253295e19f56d18bc1d97ec8c259b9b333146724487ae48dbf86cfe5ed")
