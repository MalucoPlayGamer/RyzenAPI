-- Lua provided by RyzenAPI
-- Game: Game: Sir Whoopass™: Immortal Death

-- MAIN APPLICATION
addappid(1240590)
-- Game: addappid(1240590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240591, 1, "81a27b9cc381a91b16ba3419786c73517a68eafb06e1084a391d78b92f03f5c8")
