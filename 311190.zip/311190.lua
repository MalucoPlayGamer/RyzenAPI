-- Lua provided by RyzenAPI
-- Game: Super Panda Adventures

-- MAIN APPLICATION
addappid(311190)
addappid(313350)
-- Game: addappid(311190)

-- MAIN APP DEPOTS / PACKAGES
addappid(311191, 1, "ee1e7b02a51845ae8413904fd1243bfd9dd47bbe25cb4b25e8b1b7e253e6aa3e")
