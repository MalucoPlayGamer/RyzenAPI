-- Lua provided by RyzenAPI
-- Game: Three Fourths Home: Extended Edition

-- MAIN APPLICATION
addappid(344500)
addappid(344501)
addappid(344502)
addappid(344508)

-- MAIN APP DEPOTS / PACKAGES
addappid(344503,0,"3d3d69cfc8eba378253a85e8687da5ff2b0971696f99508536c09aca099d1db0")
addappid(344504,0,"2f845ffd97abd1b860e6193ac53a12ab3d464d027027c133842fc810c70724a9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(357240)
