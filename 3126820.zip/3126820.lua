-- Lua provided by RyzenAPI
-- Game: Raven's Daring Adventure

-- MAIN APPLICATION
addappid(3126820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126821, 1, "0f3cbc9f1a9e2566dfe1d70faae56a40c2a277137a5eff474d8833b219dba4d8")

