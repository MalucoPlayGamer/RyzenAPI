-- Lua provided by RyzenAPI
-- Game: AppID 399130

-- MAIN APPLICATION
addappid(399130)
-- Game: addappid(399130)

-- MAIN APP DEPOTS / PACKAGES
addappid(399131, 1, "592ea8815ae79377bf2b7bad2357f86097f5050daee4fb6f24e7825627009512")
