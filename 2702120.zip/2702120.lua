-- Lua provided by RyzenAPI
-- Game: 2702120

-- MAIN APPLICATION
addappid(2702120)
-- Game: addappid(2702120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702121, 1, "c2d5ab93eaa4f8a112539f150660f029ea8045a0efee8d85e9265646c85df0e7")
