-- Lua provided by RyzenAPI
-- Game: 1038040

-- MAIN APPLICATION
addappid(1038040)
-- Game: addappid(1038040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038040,0,"56dae01fa93abc7d043e42eba8ebe4344cc4f7c05cae10cc149e73e106399e28")
