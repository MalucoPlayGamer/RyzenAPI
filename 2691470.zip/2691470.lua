-- Lua provided by RyzenAPI
-- Game: addappid(2691470)

-- MAIN APPLICATION
addappid(2691470)
addappid(2691471)
addappid(2691473)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691472,0,"131d982b46f8756bbe8a0cfb8f6724fa817d5ea664397ec79dc2af58461886fd")
