-- Lua provided by RyzenAPI
-- Game: Real Drift

-- MAIN APPLICATION
addappid(817680)

-- MAIN APP DEPOTS / PACKAGES
addappid(817681,0,"4fdde82e9e0db9e99628e95a214f018612268bbdf0d2554bb6eced5c1187c6e8")

