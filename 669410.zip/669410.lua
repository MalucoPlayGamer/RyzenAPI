-- Lua provided by RyzenAPI
-- Game: Exatron Quest 

-- MAIN APPLICATION
addappid(669410)

-- MAIN APP DEPOTS / PACKAGES
addappid(669412,0,"41a0f7f448c1d9450b8340dc0435eacb6f496e482427a8c6213af6eff7752ba1")

