-- Lua provided by RyzenAPI
-- Game: Game: Wizabeasts

-- MAIN APPLICATION
addappid(2020040)
-- Game: addappid(2020040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020041, 1, "d82268be3e40808345a4436b66b7121924826cb5454680db04ecb7670cae93b9")
