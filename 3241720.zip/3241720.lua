-- Lua provided by RyzenAPI 
-- Game: 玩仔的冒险
addappid(3241720)
addappid(3241721, 1, "166f63265f5a7269a9f7edd10583945f77381461230413412d94b96a4f3adf3f")
