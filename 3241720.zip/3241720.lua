-- Lua provided by RyzenAPI
-- Game: 玩仔的冒险

-- MAIN APPLICATION
addappid(3241720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241721, 1, "166f63265f5a7269a9f7edd10583945f77381461230413412d94b96a4f3adf3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
