-- Lua provided by RyzenAPI
-- Game: 809880

-- MAIN APPLICATION
addappid(809880)

-- MAIN APP DEPOTS / PACKAGES
addappid(809883,0,"edde71c9c9a27898179fa7b14291875c2c60edddcb78ea28b4b05e8416eba646")
