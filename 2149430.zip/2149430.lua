-- Lua provided by RyzenAPI 
-- Game: Click To Sail
addappid(2149430)
addappid(2149431, 1, "7f4efbf980764a19d789f9c8e4aec8d0d5a7a739626fbc5fd66484281b76805d")
