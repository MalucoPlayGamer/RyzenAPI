-- Lua provided by RyzenAPI
-- Game: addappid(952340)

-- MAIN APPLICATION
addappid(952340)

-- MAIN APP DEPOTS / PACKAGES
addappid(952341, 1, "74d4def90d84e49c80151c98d15aa7c6a3ab4e3f8a15c6cd39d4815f7635b870")
