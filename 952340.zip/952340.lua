-- Lua provided by RyzenAPI
-- Game: AppID 952340

-- MAIN APPLICATION
addappid(952340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(952341, 1, "74d4def90d84e49c80151c98d15aa7c6a3ab4e3f8a15c6cd39d4815f7635b870")

