-- Lua provided by RyzenAPI
-- Game: Em-A-Zurvival

-- MAIN APPLICATION
addappid(1261750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261751, 1, "4a0be1dc32deb0338caf84855f8e2f3189baf9018ec03a719a064fc4824c735d")
