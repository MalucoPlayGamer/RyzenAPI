-- Lua provided by RyzenAPI
-- Game: AppID 473500

-- MAIN APPLICATION
addappid(473500)

-- MAIN APP DEPOTS / PACKAGES
addappid(473501, 1, "fbacf425d2a26ec49cf6ec9ae61b9ace8c58df79a440594bf7428f3f9dec7537")

