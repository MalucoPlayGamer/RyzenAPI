-- Lua provided by RyzenAPI
-- Game: Game: Tower Dominion

-- MAIN APPLICATION
addappid(3226530)
-- Game: addappid(3226530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226531, 1, "bce32f7a7225638f1c114345d97f78d3462114031739e05859e0b3a07a1eb408")
addappid(3226537, 1, "3242c2ab84f3526a7c899fd3b8e525dcc15c37504a443d684bb7ec77c6d75362")
