-- Lua provided by RyzenAPI
-- Game: Wallachia: Reign of Dracula

-- MAIN APPLICATION
addappid(1189780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1189781, 1, "f023f71844f9471bfcc4cf279fb2f1502945f7eb22184bc0e6a844284c64d6b2")

