-- Lua provided by RyzenAPI
-- Game: Wallachia: Reign of Dracula

-- MAIN APPLICATION
addappid(1189780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189781, 1, "f023f71844f9471bfcc4cf279fb2f1502945f7eb22184bc0e6a844284c64d6b2")
