-- Lua provided by RyzenAPI
-- Game: Setr's Auto Battler

-- MAIN APPLICATION
addappid(1824830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824832,0,"6978cedd60eb61828fad2bca06166f1d30a2d7ebdb501f8dd8aac54b26b900ae")
addappid(1824833,0,"03841df9ccc5ee7922fbc36014b674a6848aa099999ffb9add79a08c96e58184")
addappid(1824834,0,"d7e414bb109d28cf5d42f97a40f709dfed21ce2216c37211797c5a2012df5527")
addappid(1824835,0,"33577c6f9aa2c95f5ea0be3dd81e58dc1101c9bfe6093e370dea0eddd5303611")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
