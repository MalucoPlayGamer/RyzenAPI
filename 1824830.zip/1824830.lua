-- Lua provided by RyzenAPI
-- Game: Setr's Auto Battler

-- MAIN APPLICATION
addappid(1824830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824832,0,"6978cedd60eb61828fad2bca06166f1d30a2d7ebdb501f8dd8aac54b26b900ae")
addappid(1824833,0,"03841df9ccc5ee7922fbc36014b674a6848aa099999ffb9add79a08c96e58184")
addappid(1824834,0,"d7e414bb109d28cf5d42f97a40f709dfed21ce2216c37211797c5a2012df5527")
addappid(1824835,0,"33577c6f9aa2c95f5ea0be3dd81e58dc1101c9bfe6093e370dea0eddd5303611")

