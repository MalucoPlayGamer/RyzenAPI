-- Lua provided by RyzenAPI
-- Game: Retool

-- MAIN APPLICATION
addappid(463440)
addappid(463610)
-- Game: addappid(463440)

-- MAIN APP DEPOTS / PACKAGES
addappid(463441, 1, "2059db970c4dac423498671216092be67619de86462c9984c054e4db5c7b50b7")
addappid(463442, 1, "bed117e39787087dd9151def7f09902664b4d6713000a96b3dfe737d61f86b05")
addappid(463443, 1, "afa824bbaba377dba3d03fac737964e68b1e43efeeddf77eb26608f0a5f1c4b8")
addappid(463444, 1, "e695b2d6502c9d55ec6b948007ebf3bc76ec003e55d42e90926981d3712cdc15")
