-- Lua provided by RyzenAPI
-- Game: Game: Serial Cleaners

-- MAIN APPLICATION
addappid(1337920)
-- Game: addappid(1337920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337921, 1, "a140effde48e651aac967f5e46674b91f7da3b28a86145f7eabdbbfaadc6e099")
addappid(2291430, 0, "79550d37166166393804524969451ed0e9f86992565f971b38a9530c84e43300")
