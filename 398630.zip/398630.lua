-- Lua provided by RyzenAPI
-- Game: AppID 398630

-- MAIN APPLICATION
addappid(398630)
-- Game: addappid(398630)

-- MAIN APP DEPOTS / PACKAGES
addappid(398631, 1, "b9c2a389bec7f4c5a6e96a4e01dc53158f196f2b00ea16edf537e0d8edf0bfb0")
