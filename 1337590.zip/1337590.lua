-- Lua provided by RyzenAPI
-- Game: 1337590

-- MAIN APPLICATION
addappid(1337590)
-- Game: addappid(1337590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337591, 1, "e2ef6de8526553f8c16c6b849098573c6d97a2cf0cdc6a02cb36e60831e8d2f0")
