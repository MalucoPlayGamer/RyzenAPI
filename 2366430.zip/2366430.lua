-- Lua provided by RyzenAPI
-- Game: Game: Windy Meadow - A Roadwarden Tale

-- MAIN APPLICATION
addappid(2366430)
-- Game: addappid(2366430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366431, 1, "91fda876a9d8d0c4f17559066e77a015a7c1c7c56d74e0d1f8ab425e79399d5f")
addappid(2366432, 1, "56b0435c35367b1ae5426009472eff26b443547bfb797b0dad25f8fcd7b5a273")
addappid(2366433, 1, "6f63910d9a7dacb1c92eb25d95628a2a4748aee917cd774c02f7f944ba011fbb")
