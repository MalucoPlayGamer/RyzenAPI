-- Lua provided by RyzenAPI 
-- Game: Richman 7 Soundtrack
addappid(2311450)
addappid(2311451, 1, "7a9ed1a6aead731d8c16267f68c90b9d21e864db14ea3dcbf398d6298ea72c35")
addappid(2311452, 1, "f95b5223d4878a676a5840c964b5768622b177401f167f37e8299d972cf971e1")
