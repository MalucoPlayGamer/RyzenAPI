-- Lua provided by RyzenAPI 
-- Game: AppID 1874910
addappid(1874910)
addappid(1874911, 1, "8679c498b87f92e7225074bf6166b13b0c8073299dd129451362e92a669941f2")
