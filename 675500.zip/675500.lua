-- Lua provided by RyzenAPI
-- Game: ACT IT OUT XL!

-- MAIN APPLICATION
addappid(675500)

-- MAIN APP DEPOTS / PACKAGES
addappid(675501,0,"3930235b5cf80ae3731c16e70df62f0a7aa4982c3cacaf50b75bab23017a53fb")

