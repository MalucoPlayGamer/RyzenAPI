-- Lua provided by RyzenAPI
-- Game: 3115910

-- MAIN APPLICATION
addappid(3115910)
-- Game: addappid(3115910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115911, 1, "ea4e2e7f77fd1e56913aebea1640da0b77ebfe4947f25dc103fb2affa7c3e822")
