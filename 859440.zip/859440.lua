-- Lua provided by RyzenAPI
-- Game: Mars or Die!

-- MAIN APPLICATION
addappid(859440)
-- Game: addappid(859440)

-- MAIN APP DEPOTS / PACKAGES
addappid(859441, 1, "443d48708308a311f6d7865f12022a07155308f0bc453a45bea64855944e932f")
