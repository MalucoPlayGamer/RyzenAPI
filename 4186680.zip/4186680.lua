-- Lua provided by RyzenAPI
-- Game: Algorithmically

-- MAIN APPLICATION
addappid(4186680) -- Algorithmically

-- MAIN APP DEPOTS / PACKAGES
addappid(4186681, 1, "7103c54c7f22f6b5e0be07b18ebf514e113b512d732c60591d9e87acd0df1bfb") -- Depot 4186681

