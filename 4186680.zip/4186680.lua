-- 4186680's Lua and Manifest Created by Hubcap Manifest
-- Algorithmically
-- Created: August 08, 2026 at 22:55:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4186680) -- Algorithmically
-- MAIN APP DEPOTS
addappid(4186681, 1, "7103c54c7f22f6b5e0be07b18ebf514e113b512d732c60591d9e87acd0df1bfb") -- Depot 4186681
setManifestid(4186681, "3610902897482364640", 111941459)