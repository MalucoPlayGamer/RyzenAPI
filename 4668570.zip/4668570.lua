-- Generated with Luie @ https://lua.tools/
-- 4668570 - Party of Lust
-- Generated 2026-08-29 07:12:01 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4668570)

-- Main Depots
addappid(4668571, 1, "52bb667e174593bcad4d849f6344996018f231170c5415d886be0be504d244ba")
setManifestid(4668571, "2965482971928309762", 651824506)
