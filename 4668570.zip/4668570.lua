-- Lua provided by RyzenAPI
-- Game: Party of Lust

-- MAIN APPLICATION
addappid(4668570)

-- MAIN APP DEPOTS / PACKAGES
addappid(4668571, 1, "52bb667e174593bcad4d849f6344996018f231170c5415d886be0be504d244ba")