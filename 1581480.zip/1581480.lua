-- Lua provided by RyzenAPI
-- Game: HUMANITY

-- MAIN APPLICATION
addappid(1581480)
-- Game: addappid(1581480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581481, 1, "681b15c86b5812c55cfb2eac33bb668a5d769685de545086c89e320bd4e9bd46")
