-- Lua provided by RyzenAPI
-- Game: addappid(555710)

-- MAIN APPLICATION
addappid(555710)

-- MAIN APP DEPOTS / PACKAGES
addappid(555711, 1, "7eaa33653310c0607cc636500d56e2139437b71fe70ca7d6be52b3514eb20f78")
addappid(555712, 1, "46db2f61dad4dd50d463c45e3897c5812e9af80ff6784a0ca7d7f482eb265cec")
