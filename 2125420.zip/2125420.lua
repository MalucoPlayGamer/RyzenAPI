-- Lua provided by RyzenAPI
-- Game: Zorbus

-- MAIN APPLICATION
addappid(2125420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125422,0,"a481a85e2f44e9123a38b1c1a79b27b754720a55a8353ecb43217984861cb900")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
