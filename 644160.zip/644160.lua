-- Lua provided by RyzenAPI
-- Game: Reflecting Fate

-- MAIN APPLICATION
addappid(644160)

-- MAIN APP DEPOTS / PACKAGES
addappid(644161, 1, "ec5578670968c582dd3e2cbe072a83e00ca12f934ea12a047fa9c5715d542569")

