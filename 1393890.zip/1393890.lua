-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1393890)
addappid(1393891)
-- Game: addappid(1393890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405840,0,"b199085977c82c880e1a2cb3c92299966645bb74a8bd40f06643a6f03521bd09")
