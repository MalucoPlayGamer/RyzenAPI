-- Lua provided by RyzenAPI
-- Game: Jenny LeClue - Detectivu

-- MAIN APPLICATION
addappid(228987)
addappid(228990)
addappid(229000)
addappid(229006)
addappid(319870)

-- MAIN APP DEPOTS / PACKAGES
addappid(319872,0,"08c498b80d0eeefe3a6b4e274fab7d8b2a2177b6f3c6b747eeba265c2b77afcc")
addappid(319873,0,"7d65df6c26ef46517c9e60bafc9f3dbf8586aa145fdfe1e1fb744718a77bd609")
addappid(319874,0,"6e3ab5690692955bc83444afddbe6c7e943b41fff4547fe2c86c402e9e2f0eee")
addappid(319879,0,"ef08244ac304a736df45196f16af8fbbc16b8cc21a323860ed12e98861648cd5")

