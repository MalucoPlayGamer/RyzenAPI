-- Lua provided by RyzenAPI
-- Game: 238690

-- MAIN APPLICATION
addappid(238690)
-- Game: addappid(238690)

-- MAIN APP DEPOTS / PACKAGES
addappid(238691, 1, "18fad119bce89cea0a37037fa2214c4c65eb6a91af4da0fc0a0a7538efb3e443")
