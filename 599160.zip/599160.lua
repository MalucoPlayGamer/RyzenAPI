-- Lua provided by RyzenAPI
-- Game: 599160

-- MAIN APPLICATION
addappid(228986)
addappid(599160)
addappid(599161)
addappid(599162)
addappid(599163)

-- MAIN APP DEPOTS / PACKAGES
addappid(972360,0,"ed2ae34bf8e1d299b698af5b9cd74a5044079387fff85baafc031c169b2624f3")

