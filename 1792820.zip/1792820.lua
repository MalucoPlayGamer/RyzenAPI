-- Lua provided by SkyAPI 
-- Game: Blade&Sword
addappid(1792820)
addappid(1792821, 1, "f07cfb7d3e6842994c3372791032169262060d4bc2743b26e1e0409ad84bcb4f")
