-- Lua provided by RyzenAPI
-- Game: Blade&Sword

-- MAIN APPLICATION
addappid(1792820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792821, 1, "f07cfb7d3e6842994c3372791032169262060d4bc2743b26e1e0409ad84bcb4f")
