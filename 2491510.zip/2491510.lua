-- Lua provided by RyzenAPI
-- Game: Sun Mystery - Playtest

-- MAIN APPLICATION
addappid(2491510)
-- Game: addappid(2491510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491511, 1, "24180d3fec38cc112eb46f91884b77ede6a87a8b9f3ce5b46857f1ca0745dcc7")
