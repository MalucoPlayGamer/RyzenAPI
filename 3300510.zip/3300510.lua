-- Lua provided by RyzenAPI
-- Game: addappid(3300510)

-- MAIN APPLICATION
addappid(3300510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3300511, 1, "b0e8e78d7388f99a979db9ea33cedd6e6edef348b2dc16c21094515609eea877")
