-- Lua provided by RyzenAPI
-- Game: Bricks Over Blocks

-- MAIN APPLICATION
addappid(3300510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3300511, 1, "b0e8e78d7388f99a979db9ea33cedd6e6edef348b2dc16c21094515609eea877")

