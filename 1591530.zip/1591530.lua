-- Lua provided by RyzenAPI
-- Game: 1591530

-- MAIN APPLICATION
addappid(1591530)
-- Game: addappid(1591530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591531, 1, "6e9cd306f219dd94890d54be33bbca4c598efaa4a8e18fb4582bea1a0ac67973")
