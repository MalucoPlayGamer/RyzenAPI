-- 1591530's Lua and Manifest Created by Hubcap Manifest
-- SAMURAI WARRIORS 5
-- Created: September 30, 2025 at 12:13:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 28
-- Total DLCs: 26
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1591530) -- SAMURAI WARRIORS 5
-- MAIN APP DEPOTS
addappid(1591531, 1, "6e9cd306f219dd94890d54be33bbca4c598efaa4a8e18fb4582bea1a0ac67973") -- Depot 1591531
setManifestid(1591531, "3104118657115041575", 16169709917)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- SAMURAI WARRIORS 5 - Special Costume - Nobunaga Oda (AppID: 1634690)
addappid(1634690)
addappid(1634690, 1, "65ea005dae87fb5522ff04be83d50767d114c5c5eb16d4af6adab84c5a803c50") -- SAMURAI WARRIORS 5 - Special Costume - Nobunaga Oda - Depot 1634690
setManifestid(1634690, "5902346108534933380", 524)
-- SAMURAI WARRIORS 5 - Special Costume - Mitsuhide Akechi (AppID: 1634691)
addappid(1634691)
addappid(1634691, 1, "9038a0077b038b1e33abdc254dfb45b113bd164f07f26d018a2521daef5ce881") -- SAMURAI WARRIORS 5 - Special Costume - Mitsuhide Akechi - Depot 1634691
setManifestid(1634691, "2160342692506782397", 524)
-- SAMURAI WARRIORS 5 - SAMURAI WARRIORS Costume - Nobunaga Oda (AppID: 1634692)
addappid(1634692)
addappid(1634692, 1, "5d3cc3de43279e5dc488f4f75393aadb32f0b2fa9b4f058bec158e35d51899c4") -- SAMURAI WARRIORS 5 - SAMURAI WARRIORS Costume - Nobunaga Oda - Depot 1634692
setManifestid(1634692, "7484842871234664216", 524)
-- SAMURAI WARRIORS 5 - SAMURAI WARRIORS Costume - Mitsuhide Akechi (AppID: 1634693)
addappid(1634693)
addappid(1634693, 1, "54da672d7ce08907b7669f95951a5006029b9b2f58bf63deb194ad4ba95cfdb4") -- SAMURAI WARRIORS 5 - SAMURAI WARRIORS Costume - Mitsuhide Akechi - Depot 1634693
setManifestid(1634693, "5547967832429660983", 524)
-- SAMURAI WARRIORS 5 - Digital Deluxe Edition Bonus (AppID: 1634694)
addappid(1634694)
addappid(1634694, 1, "d344e5a5f3ccdadcb90e45a1505e9f3a00232f1b1e8b12c19abea4933bb7beab") -- SAMURAI WARRIORS 5 - Digital Deluxe Edition Bonus - Depot 1634694
setManifestid(1634694, "6857908661587255354", 524)
-- SAMURAI WARRIORS 5 - Season Pass Bonus (AppID: 1634696)
addappid(1634696)
addappid(1634696, 1, "be25947a35ab4ce739e788e94580dfcacdf316d811c302eaa3c4c3cb1d21d10d") -- SAMURAI WARRIORS 5 - Season Pass Bonus - Depot 1634696
setManifestid(1634696, "673170184085993523", 524)
-- SAMURAI WARRIORS 5 - Additional Horse Ghost (AppID: 1634697)
addappid(1634697)
addappid(1634697, 1, "507dc55f1ea1bf948e0535d25409479484adabb7e523b577b4b13bf48b786289") -- SAMURAI WARRIORS 5 - Additional Horse Ghost - Depot 1634697
setManifestid(1634697, "533820823707109402", 524)
-- SAMURAI WARRIORS 5 - Additional Horse Iron Coat (AppID: 1634698)
addappid(1634698)
addappid(1634698, 1, "d0badb871404c31168a76d76cbc58cc7f9334b8d839f8d6641f8e12de1a32c5e") -- SAMURAI WARRIORS 5 - Additional Horse Iron Coat - Depot 1634698
setManifestid(1634698, "2009299338444718021", 524)
-- SAMURAI WARRIORS 5 - Additional Horse Black Shadow (AppID: 1634699)
addappid(1634699)
addappid(1634699, 1, "b227b4c217c66bdf8791ea32aca6d8caea6e88dfd92f58f15db157960cc74bdc") -- SAMURAI WARRIORS 5 - Additional Horse Black Shadow - Depot 1634699
setManifestid(1634699, "2397972926382974937", 524)
-- SAMURAI WARRIORS 5 - Additional Horse Silver Coat (AppID: 1634700)
addappid(1634700)
addappid(1634700, 1, "4c6af6591fd7eaaf704cb548df57a46468f08ac55a00d6ac99a133043601ee83") -- SAMURAI WARRIORS 5 - Additional Horse Silver Coat - Depot 1634700
setManifestid(1634700, "6459401584539490198", 524)
-- SAMURAI WARRIORS 5 - Additional Horse Armor Coat (AppID: 1634701)
addappid(1634701)
addappid(1634701, 1, "8ac5bc8173fc0b52e903685049d038784226e09e121fedadf884a9ac1f8bf94f") -- SAMURAI WARRIORS 5 - Additional Horse Armor Coat - Depot 1634701
setManifestid(1634701, "7652796538222034124", 524)
-- SAMURAI WARRIORS 5 - Additional Horse Qilin (AppID: 1634702)
addappid(1634702)
addappid(1634702, 1, "321398799fb90a44de3241b42377f08379d10455aab53baa30a161c1601f946f") -- SAMURAI WARRIORS 5 - Additional Horse Qilin - Depot 1634702
setManifestid(1634702, "7678779145897431601", 524)
-- SAMURAI WARRIORS 5 - Additional Weapon Set 1 (AppID: 1634703)
addappid(1634703)
addappid(1634703, 1, "7e31fc47493700d03064b0591cd862ab01b9e341a08bc2831d89c36ebd36ffc3") -- SAMURAI WARRIORS 5 - Additional Weapon Set 1 - Depot 1634703
setManifestid(1634703, "4194167577268152743", 524)
-- SAMURAI WARRIORS 5 - Additional Weapon Set 2 (AppID: 1634704)
addappid(1634704)
addappid(1634704, 1, "ffadd27ff7948fb39fd4c26f6d1828d9668d5087b49a05025cf4709078492028") -- SAMURAI WARRIORS 5 - Additional Weapon Set 2 - Depot 1634704
setManifestid(1634704, "5876683232019940057", 524)
-- SAMURAI WARRIORS 5 - Additional Weapon Set 3 (AppID: 1634705)
addappid(1634705)
addappid(1634705, 1, "d011b496b68e023975f77d637fcbb90644ef32fda9a39ca8104278b7c2498c2e") -- SAMURAI WARRIORS 5 - Additional Weapon Set 3 - Depot 1634705
setManifestid(1634705, "7343416453991975207", 524)
-- SAMURAI WARRIORS 5 - Additional Weapon Set 4 (AppID: 1634706)
addappid(1634706)
addappid(1634706, 1, "3bde77d0ca2ccd97a2d26c059be283a72bf1e30532345df9f809f62c7a2155f5") -- SAMURAI WARRIORS 5 - Additional Weapon Set 4 - Depot 1634706
setManifestid(1634706, "81715202155491175", 524)
-- SAMURAI WARRIORS 5 - Additional Weapon Set 5 (AppID: 1634707)
addappid(1634707)
addappid(1634707, 1, "50c73d1d3ed009c28a177790f37f846e8d4ed4c5d3e04435faba87bbe25daf9a") -- SAMURAI WARRIORS 5 - Additional Weapon Set 5 - Depot 1634707
setManifestid(1634707, "7221544046096126987", 524)
-- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 1 (AppID: 1634708)
addappid(1634708)
addappid(1634708, 1, "f6bfdc7782b955f840a30769c2d98d32d9f7f4030578b19acb0121decfaf747a") -- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 1 - Depot 1634708
setManifestid(1634708, "1543828944416551856", 156346)
-- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 2 (AppID: 1634709)
addappid(1634709)
addappid(1634709, 1, "275f612fb4f6162d5c40ec15f8c7207fc827b2d37de4c65d20344b7a52ac8a21") -- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 2 - Depot 1634709
setManifestid(1634709, "6470204994933181770", 145567)
-- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 3 (AppID: 1634710)
addappid(1634710)
addappid(1634710, 1, "f4c999d43364d49b5a28f4b4b854a848346c730609406d7a9653a2bd9cca1e7d") -- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 3 - Depot 1634710
setManifestid(1634710, "7553139225353339690", 189289)
-- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 4 (AppID: 1634711)
addappid(1634711)
addappid(1634711, 1, "ae284652f598f679a3d61b79de3eff21a85a611b859e027d5460111a02bdb54e") -- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 4 - Depot 1634711
setManifestid(1634711, "5019044352860240577", 184665)
-- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 5 (AppID: 1634712)
addappid(1634712)
addappid(1634712, 1, "39faf0211d10d1854164fe237a2dbf3ce06e3608bf78e63ff5cba2fd12a3ca7c") -- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 5 - Depot 1634712
setManifestid(1634712, "3906254618351633836", 216416)
-- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 6 (AppID: 1634713)
addappid(1634713)
addappid(1634713, 1, "fd5cb9903472c07da75727589ed7f131cd073f83ad49082ec9660da5b67ece2b") -- SAMURAI WARRIORS 5 - Additional Scenario  BGM Set 6 - Depot 1634713
setManifestid(1634713, "6397846493822523713", 186817)
-- SAMURAI WARRIORS 5 - Deluxe Costume - Nobunaga Oda (AppID: 1649710)
addappid(1649710)
addappid(1649710, 1, "5c5e816411764ba9bd99895f2246599586c941ab4fd8fd489590f9e6183b4a8e") -- SAMURAI WARRIORS 5 - Deluxe Costume - Nobunaga Oda - 戦国無双５ - 特製衣装「織田信長」 デポ
setManifestid(1649710, "3259918461951498691", 524)
-- SAMURAI WARRIORS 5 - Deluxe Costume - Mitsuhide Akechi (AppID: 1649711)
addappid(1649711)
addappid(1649711, 1, "e533486a21be97055c1a063b7d9a2cdef238c4a1803afb9ef4eff8e741d6877f") -- SAMURAI WARRIORS 5 - Deluxe Costume - Mitsuhide Akechi - 戦国無双５ - 特製衣装「明智光秀」 デポ
setManifestid(1649711, "7678536919443873635", 524)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1634695) -- SAMURAI WARRIORS 5 - Season Pass