-- Lua provided by RyzenAPI 
-- Game: _keyboardkommander
addappid(1448310)
addappid(1448311, 1, "efdff81ae13fb9b0ccdf3ca1e2c87c7e47354cf84bb411932b4a26a5966e5546")
