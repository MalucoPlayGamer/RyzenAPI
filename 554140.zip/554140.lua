-- Lua provided by RyzenAPI
-- Game: addappid(554140)

-- MAIN APPLICATION
addappid(554140)

-- MAIN APP DEPOTS / PACKAGES
addappid(554141, 1, "cf2e2620c015e09be80f4b72753b0a83c45ef5b95e3495df13e9e30576ac0ba8")
