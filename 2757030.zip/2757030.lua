-- Lua provided by RyzenAPI
-- Game: Muse War

-- MAIN APPLICATION
addappid(2757030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757031, 1, "ee8a4662b9ac7463ff94b24085b0e9b5abadd6a4f1f5e8044af7d6bfeac64f1f")
addappid(2915120, 0, "10098a34c33cbd2677183b1f1e49a65e86b64cc21dd3a47c4dfce362a6b7b785")
addappid(2915130, 0, "253d168d7dc30acdfcc84a8a8f09ffb60b33d9d40ffbed5020af61f20f0332b6")
addappid(2915140, 0, "0794d03fd30e7ed2685f44b3d3558aba7c0bc19cd6f7d08a34ae4686c51499ba")
addappid(2915150, 0, "7d6a44b6cf8aad57092c3186dda92fc99000959100a49c917092b41e5227bf2e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2915160)
