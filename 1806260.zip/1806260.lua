-- Lua provided by RyzenAPI
-- Game: Demeo (Original Soundtrack)

-- MAIN APPLICATION
addappid(1806260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806261, 1, "8befbd42dd31bd2dfadeaba4cd7e7d64a1f1c2305fc02acc56acb11306f49dbc")

