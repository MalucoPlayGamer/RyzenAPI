-- Lua provided by RyzenAPI
-- Game: AppID 1015700

-- MAIN APPLICATION
addappid(1015700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015701, 1, "cfc19c5aca2ffd1adc3f0896974f3be930f4ff46161f60511f6a324dbad2477d")

