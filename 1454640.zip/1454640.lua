-- Lua provided by RyzenAPI
-- Game: A Tale of Paper: Refolded

-- MAIN APPLICATION
addappid(1454640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454641, 1, "d0651c2d34622c0953bd987c256f22c5983ddbcbaa5e42d9b1634c3afe5fa325")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
