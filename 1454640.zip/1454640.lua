-- Lua provided by SkyAPI 
-- Game: A Tale of Paper: Refolded
addappid(1454640)
addappid(1454641, 1, "d0651c2d34622c0953bd987c256f22c5983ddbcbaa5e42d9b1634c3afe5fa325")
