-- Lua provided by RyzenAPI
-- Game: Differently Fast

-- MAIN APPLICATION
addappid(697430)

-- MAIN APP DEPOTS / PACKAGES
addappid(697431,0,"cc7691aeead21f7fb11a4a404f2ec151dc904b00e6c7fb93933aec705b5073f2")

