-- Lua provided by RyzenAPI
-- Game: Blood Bowl: Chaos Edition (Classic)

-- MAIN APPLICATION
addappid(216890)

-- MAIN APP DEPOTS / PACKAGES
addappid(216891, 1, "e617bc43ad8b8e9c645bd66da8ab3b4394306e72897d26aa8d6fffe9d0f45246")
addappid(216892, 1, "6e0aba189dd44e390e83878e3ae4f3cc6fcdf441f7cdf98f17d7908cc11a6c53")
addappid(216893, 1, "14c61c430582ded16a8b536f4af7bee831727d1be123fc9848b26f01415dd4a5")
addappid(216894, 1, "6e9ec9b61852d949109f43351f0402e678dfded02faaf2e487250c934265f102")
addappid(216895, 1, "4b9002a652adfabc49ac8d16bb8485b9744f97bf977a3971db1daecebc3e8e8d")
addappid(216896, 1, "b46a8e76e1d805472f140fb2775cff5b19aa342c5f704e24d546bd868fbbddb1")
addappid(216897, 1, "9040c0de7d4ac343d8f434a664946a0c926a0d27076f1196d9b01f64fc3c0de2")
addappid(216898, 1, "76b81643bf72b9f8ed3bd3fbf321eb30a029b6cfe3f9592c60a93aff35626390")
