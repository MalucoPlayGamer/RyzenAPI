-- Lua provided by RyzenAPI
-- Game: addappid(1106850)

-- MAIN APPLICATION
addappid(1106850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106851, 1, "8ddd756650da7d2101c8e915c77b434afb78e4facdfe82fecb01738bca9077c1")
