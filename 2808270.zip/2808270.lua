-- Lua provided by RyzenAPI
-- Game: Buckshot With Friends

-- MAIN APPLICATION
addappid(2808270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808271, 1, "4687dd7a897df0e74c17fe1563448fae92d9673774b39a089ef01c19c7d09cd9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
