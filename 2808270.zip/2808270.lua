-- Lua provided by RyzenAPI
-- Game: Buckshot With Friends

-- MAIN APPLICATION
addappid(2808270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808271, 1, "4687dd7a897df0e74c17fe1563448fae92d9673774b39a089ef01c19c7d09cd9")
