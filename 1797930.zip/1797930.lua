-- Lua provided by RyzenAPI
-- Game: Game: Para Eyes

-- MAIN APPLICATION
addappid(1797930)
-- Game: addappid(1797930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797931, 1, "bc1e2e14a3ab2e88341765e30be5e29763ebbeab7f66129660c8179541d10722")
