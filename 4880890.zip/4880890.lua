-- Lua provided by RyzenAPI
-- Game: Laundromat Anomaly

-- MAIN APPLICATION
addappid(4880890) -- Laundromat Anomaly

-- MAIN APP DEPOTS / PACKAGES
addappid(4880891, 1, "e2a23e503ee71229900d2c6d07c08649e21a11bc074b4b29506cbafe43ec7c2a") -- Depot 4880891
addappid(4880892, 1, "53eb292e0050b2665abb17c461b846d3efb92c231b234b007b0f25c84984e007") -- Depot 4880892

