-- 4880890's Lua and Manifest Created by Hubcap Manifest
-- Laundromat Anomaly
-- Created: July 31, 2026 at 23:59:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4880890) -- Laundromat Anomaly
-- MAIN APP DEPOTS
addappid(4880891, 1, "e2a23e503ee71229900d2c6d07c08649e21a11bc074b4b29506cbafe43ec7c2a") -- Depot 4880891
setManifestid(4880891, "8304034704881494611", 1424288264)
addappid(4880892, 1, "53eb292e0050b2665abb17c461b846d3efb92c231b234b007b0f25c84984e007") -- Depot 4880892
setManifestid(4880892, "179845192906623924", 1424288264)