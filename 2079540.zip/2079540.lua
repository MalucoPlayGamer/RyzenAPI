-- Lua provided by RyzenAPI
-- Game: The Palace of Unrest

-- MAIN APPLICATION
addappid(2079540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079542,0,"dba3e75292c8832e61c6af51743090ee135f27637e8175138030fce6a3522651")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
