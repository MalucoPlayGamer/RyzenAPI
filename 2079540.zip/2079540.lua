-- Lua provided by RyzenAPI
-- Game: The Palace of Unrest

-- MAIN APPLICATION
addappid(2079540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079542,0,"dba3e75292c8832e61c6af51743090ee135f27637e8175138030fce6a3522651")

