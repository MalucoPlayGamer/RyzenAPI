-- Lua provided by RyzenAPI
-- Game: Realms of Chaos

-- MAIN APPLICATION
addappid(358320)

-- MAIN APP DEPOTS / PACKAGES
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)
addappid(358321, 1, "1a2ce7dcddb0d01011100272892de81c067cb08a1cdd2b20915767feeb0de919")
addappid(358322, 1, "ccaf695c758b3eccfb3a64dd09607991db60085cc286f48f698772e34ebfcae1")

