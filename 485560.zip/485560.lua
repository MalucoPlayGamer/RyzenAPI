-- Lua provided by RyzenAPI
-- Game: AppID 485560

-- MAIN APPLICATION
addappid(485560)

-- MAIN APP DEPOTS / PACKAGES
addappid(485561, 1, "4449cbb4369e3ece1cd13543ddbd19b3751e28eca0c5a16d982b9d6e383d256f")
addappid(485562, 1, "6175e27c5f8c175ca4c40fdc31219933964e5bf0c1fe1d9501511e63068e6b98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
