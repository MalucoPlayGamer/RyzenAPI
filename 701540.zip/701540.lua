-- Lua provided by RyzenAPI
-- Game: EVIL STAR

-- MAIN APPLICATION
addappid(701540)

-- MAIN APP DEPOTS / PACKAGES
addappid(701541,0,"8a545b28bd060e3f8e675a616e0456cfb885918db50c897e7c7bf94b44ba9b68")
addappid(701542,0,"6bae5a0ab36c79f54f7a169d78d4ed1a20a8d115f9dc7f95be8dfc4a4a2cdbc8")
addappid(996330,0,"51f16d9665e1f2b8e750ed4c69f201c5217d3d720aef26feb37dbff6da942cd1")

