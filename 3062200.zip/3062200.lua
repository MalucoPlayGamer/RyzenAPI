-- Lua provided by RyzenAPI
-- Game: Amerzone - The Explorer's Legacy - Demo

-- MAIN APPLICATION
addappid(3062200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062201, 1, "a8f88c4129167922dfdc892c64f5669bbece006474cef6f6218231c777a515bc")
