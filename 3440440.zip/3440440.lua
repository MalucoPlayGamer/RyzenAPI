-- Lua provided by RyzenAPI
-- Game: Liminal Department Demo

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(3440440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440442,0,"655a14af6316d2aec22bd6b26de9bd15fa0a111bf77bf42fe478c687a91736f4")

