-- Lua provided by RyzenAPI
-- Game: Coromon Soundtrack

-- MAIN APPLICATION
addappid(1941270)
-- Game: addappid(1941270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941271, 1, "301d919aa39208ea0b82a609c4d2c26fed3c019cff68ddd756f640dc9034e40d")
addappid(1941272, 1, "d9972723ed7927656bc45b9f14acfb76e05a63afc32e1d4af40ad4255877347f")
