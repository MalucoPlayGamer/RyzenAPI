-- Lua provided by RyzenAPI
-- Game: Burst Squad

-- MAIN APPLICATION
addappid(1510380)
addappid(1536920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510381, 1, "387d234b7499f71801549b752fd0fa0c0905f1c3aacc9662404157056ff1c3cc")

