-- Lua provided by RyzenAPI
-- Game: Burst Squad

-- MAIN APPLICATION
addappid(1510380)
addappid(1536920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1510381, 1, "387d234b7499f71801549b752fd0fa0c0905f1c3aacc9662404157056ff1c3cc")

