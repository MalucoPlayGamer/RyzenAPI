-- Lua provided by RyzenAPI
-- Game: Malice

-- MAIN APPLICATION
addappid(1799220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799221, 1, "d2958acf9d50dce0474ef3c92ac0d2237fd252ae9567b003ea8198f29e4c3fa1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
