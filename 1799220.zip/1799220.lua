-- Lua provided by RyzenAPI
-- Game: Malice

-- MAIN APPLICATION
addappid(1799220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799221, 1, "d2958acf9d50dce0474ef3c92ac0d2237fd252ae9567b003ea8198f29e4c3fa1")

