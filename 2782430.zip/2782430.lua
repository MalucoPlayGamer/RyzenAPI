-- Lua provided by RyzenAPI
-- Game: Crazy module

-- MAIN APPLICATION
addappid(2782430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782431, 1, "8f1a21e5792f37ecc2d0e3caa769077d4e195dd4a7e58fdcce6ed59c71e3a83f")

