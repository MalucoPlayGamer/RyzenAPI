-- Lua provided by RyzenAPI
-- Game: 2843530

-- MAIN APPLICATION
addappid(2843530)
-- Game: addappid(2843530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843531, 1, "3b79c0ecf9ea92fb43430b0bcb3d60e1ab24bec47a955303898e4c1c06284dad")
