-- Lua provided by RyzenAPI
-- Game: 3132500

-- MAIN APPLICATION
addappid(3132500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132500,0,"6cd4e7939eba04f999b6f5c2f1ceee4af2b854bbc1d1d4ccbcd2f2ce8ec84c3f")
