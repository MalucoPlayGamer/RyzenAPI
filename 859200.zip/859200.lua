-- Lua provided by RyzenAPI
-- Game: Chaos of East

-- MAIN APPLICATION
addappid(859200)
addappid(859201)

-- MAIN APP DEPOTS / PACKAGES
addappid(859202,0,"49f600a58e2b433ff6f97b28d328d793f03dabc4b1eebf5d47eace5dad5c4322")

