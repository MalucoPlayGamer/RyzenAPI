-- Lua provided by RyzenAPI
-- Game: Homeworld: Deserts of Kharak

-- MAIN APPLICATION
addappid(281610)
addappid(433240)
addappid(433241)
addappid(433242)

-- MAIN APP DEPOTS / PACKAGES
addappid(281611,0,"b7098d08745b810350e061389ce73e97d97d5411dfd2b3143873c93563d86f3d")
addappid(281612,0,"5957cf5b86ebdcbf0b167c5558651b3dfd7263927ea862f59e75b84934ebe53e")
addappid(281613,0,"4ba88568446783b01096329aa771ccbf5079582b370750f05c6441ae1154f5f1")
addappid(281614,0,"7033c4d115fd98f302adead0b176abb814d677d3e52ab893d2cd7e6b3c97eec2")
addappid(281615,0,"6ff29acefd33aa7515a6f39829a75672ed45d74f10c76fa65e7797fd8530b655")
addappid(281616,0,"d39921fec12f656ddf101a5abdf76dd3a823d13feb97370eaa17633489f13b11")
addappid(436550,0,"3ce2d0e6e8e2ba6f8a9e6d75f492c0086149ba24341323aee1c907eeef1e83f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
