-- Lua provided by RyzenAPI
-- Game: NightGhast

-- MAIN APPLICATION
addappid(3028170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3028171, 1, "6d4557d3a6c57d0b887d30f04a81e3480ab761c10fce835bc0709072876da4f4")

