-- Lua provided by RyzenAPI 
-- Game: NightGhast
addappid(3028170)
addappid(3028171, 1, "6d4557d3a6c57d0b887d30f04a81e3480ab761c10fce835bc0709072876da4f4")
