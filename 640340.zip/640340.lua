-- Lua provided by RyzenAPI
-- Game: addappid(640340)

-- MAIN APPLICATION
addappid(640340)

-- MAIN APP DEPOTS / PACKAGES
addappid(640342,0,"cc338ad4c44f3824104543333522aab5733b8ee0a082f25804e9b06a0a212fcc")
