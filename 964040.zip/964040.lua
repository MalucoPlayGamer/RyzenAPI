-- Lua provided by RyzenAPI
-- Game: Snood

-- MAIN APPLICATION
addappid(964040)
