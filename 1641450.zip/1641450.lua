-- Lua provided by RyzenAPI
-- Game: Listen to the Wind

-- MAIN APPLICATION
addappid(1641450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641451, 1, "486e6bc4da15e4a5c6327a66349d997e5d01b02a50da2e31b63e1a2fdbc36ee6")

