-- Lua provided by RyzenAPI
-- Game: 3200100

-- MAIN APPLICATION
addappid(3200100)
-- Game: addappid(3200100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200101, 1, "6cfbe9b871a17402eccba5262dd9d265b7f301ae48be7bb7954df086c957adff")
