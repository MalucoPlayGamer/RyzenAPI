-- Lua provided by RyzenAPI
-- Game: What's On The Menu?

-- MAIN APPLICATION
addappid(3197560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197561, 1, "a5394c617bbd6317f3208b782c3140be745b01dad55f9b1b421ae76695a8bedf")
