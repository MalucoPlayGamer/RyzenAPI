-- Lua provided by RyzenAPI
-- Game: RC Cars

-- MAIN APPLICATION
addappid(289460)

-- MAIN APP DEPOTS / PACKAGES
addappid(289461, 1, "1cc4bae0900669645310c2d1f1b9dc609b9571bfe22ab58ccf843b95dbc03565")
addappid(289462, 1, "1532bd904fe2664383876a482fe5e9c4f5ce3b409ec18b2b83679d048456e815")
addappid(289463, 1, "768da481f8efe5019e728746c2dd06c16b2d807be7f8b20cc5321005029aaf71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
