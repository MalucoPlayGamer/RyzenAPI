-- Lua provided by RyzenAPI
-- Game: Accelerator

-- MAIN APPLICATION
addappid(492820)

-- MAIN APP DEPOTS / PACKAGES
addappid(492820,0,"ccb3b928ceaebb552c4dd1975d11fd03adbd79f5d247099ec1cbca378862a8f3")
