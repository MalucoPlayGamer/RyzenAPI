-- Lua provided by RyzenAPI
-- Game: Hentai Chicks 2

-- MAIN APPLICATION
addappid(1447490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447491, 1, "fc2b58b1147a832b76bfe49f2b25726404f58c0109fb7238999843b9581cba18")

