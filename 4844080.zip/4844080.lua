-- Lua provided by RyzenAPI
-- Game: Prison Cat

-- MAIN APPLICATION
addappid(4844080) -- Prison Cat

-- MAIN APP DEPOTS / PACKAGES
addappid(4844081, 1, "00d2e331aef43d8f828c1594c88ebecb18f5908ea5949327946151b644c8834d") -- Depot 4844081

