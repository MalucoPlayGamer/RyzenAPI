-- 4844080's Lua and Manifest Created by Hubcap Manifest
-- Prison Cat
-- Created: August 09, 2026 at 09:46:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4844080) -- Prison Cat
-- MAIN APP DEPOTS
addappid(4844081, 1, "00d2e331aef43d8f828c1594c88ebecb18f5908ea5949327946151b644c8834d") -- Depot 4844081
setManifestid(4844081, "4141118540979870483", 200523112)