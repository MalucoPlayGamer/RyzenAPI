-- Lua provided by RyzenAPI
-- Game: Dealer's Life 2

-- MAIN APPLICATION
addappid(1343670)
addappid(1498030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343671, 1, "e546471fe119704f6a2afcadebfb2f0a8cd1d0a9b79c410a3c6971ffd0d6df52")

