-- Lua provided by RyzenAPI
-- Game: Street Food Simulator

-- MAIN APPLICATION
addappid(3330840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330841,0,"3a92935fa57e4ff4bec4b55693d656a9681b45391e68fa30f1de53e5b5d33a4c")

