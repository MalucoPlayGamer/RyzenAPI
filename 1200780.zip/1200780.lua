-- Lua provided by RyzenAPI
-- Game: AppID 1200780

-- MAIN APPLICATION
addappid(1200780)
-- Game: addappid(1200780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200781, 1, "71578e59bc8e1caa04bfe5b5a1241a341a74166b31f5beae55b8a9c875412297")
