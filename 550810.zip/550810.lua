-- Lua provided by RyzenAPI 
-- Game: AppID 550810
addappid(550810)
addappid(550811, 1, "0d21c57e59ae161a466db81522f2c8d9359599db4a5f6300e588d6e57c07dcda")
