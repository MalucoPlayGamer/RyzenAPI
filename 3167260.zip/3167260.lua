-- Lua provided by RyzenAPI
-- Game: Game: AppID 3167260

-- MAIN APPLICATION
addappid(3167260)
-- Game: addappid(3167260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167261, 1, "64f729afde32c0b59748d1f0998122df22b315d2624d4e435c2d90c72db0b98b")
