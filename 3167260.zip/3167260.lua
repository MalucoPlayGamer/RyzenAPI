-- Lua provided by SkyAPI 
-- Game: AppID 3167260
addappid(3167260)
addappid(3167261, 1, "64f729afde32c0b59748d1f0998122df22b315d2624d4e435c2d90c72db0b98b")
