-- Lua provided by RyzenAPI
-- Game: 3602760

-- MAIN APPLICATION
addappid(3602760)
-- Game: addappid(3602760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602761, 1, "1a460d73be9e2278d8ef8c32b535829f15dd2fac4384faae0a2750e8ce2bc2ba")
addappid(3602762, 1, "e76f038a50189b0d8bf782629a304acc96fecc9ee0b50499db2d81c0e31370d4")
