-- Lua provided by RyzenAPI
-- Game: addappid(3655390)

-- MAIN APPLICATION
addappid(3655390)
addappid(3712120)
addappid(3712140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655391, 1, "4289857b0b55b53b17c6143a6727f746e475c76253e99cff492725e4ad9e3e13")
