-- Lua provided by RyzenAPI
-- Game: Alien: Rogue Incursion Evolved Edition

-- MAIN APPLICATION
addappid(3655390)
addappid(3712120)
addappid(3712140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3655391, 1, "4289857b0b55b53b17c6143a6727f746e475c76253e99cff492725e4ad9e3e13")

