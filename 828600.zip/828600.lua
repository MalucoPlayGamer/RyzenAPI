-- Lua provided by RyzenAPI
-- Game: addappid(828600)

-- MAIN APPLICATION
addappid(828600)

-- MAIN APP DEPOTS / PACKAGES
addappid(828601, 1, "0e8a85048a3b667d0ff6818ba31ef2e2e85bc5724cb0f45985f576041db316e6")
