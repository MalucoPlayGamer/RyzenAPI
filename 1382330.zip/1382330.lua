-- Lua provided by RyzenAPI
-- Game: Persona® 5 Strikers

-- MAIN APPLICATION
addappid(1382330)
addappid(1523810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382331, 1, "cb4d47b8650bd74db3b51a92cf07ad418d78b96bd67133d2b4b8b2a3d0ba9538")
addappid(1382332, 1, "2d11674fc11c6ebfab0a1ec662058d2ff40d80e4b968698c2e4fb9c2b5973ae7")
addappid(1482080, 0, "9bc21e38df537abe2d78ec1c094aa47ba429892dde2f0104efc9fd1bc5bc4ea1")
addappid(1482081, 0, "5fccb5605a330f3cf82a4a14924f83ea10e8a1264f86cf3dd89284f3e06abb03")

