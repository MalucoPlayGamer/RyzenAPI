-- Lua provided by RyzenAPI
-- Game: Game: Ding Dong XL

-- MAIN APPLICATION
addappid(862570)
-- Game: addappid(862570)

-- MAIN APP DEPOTS / PACKAGES
addappid(862571, 1, "7320a82dedc21bd57af1a37d48827e7af0fd64c3c0911a4c6b84c332fd2457ef")
addappid(862572, 1, "b210768d79ff7942fcb22ebb1145142ba253934606fa3193668d12ae001ef1c5")
addappid(862573, 1, "c6994fb03a150aa41608a2af2c5aa87724605f902d8fa87aa6eac2c1e242587d")
