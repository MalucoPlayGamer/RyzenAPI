-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Fantasy Market - Magic Tileset

-- MAIN APPLICATION
addappid(3699660)
-- Game: addappid(3699660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699660,0,"04c9d7c908a41553ef994fea25bf7f1732608315dcd1d4625f0a8a7c929f431e")
