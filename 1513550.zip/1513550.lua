-- Lua provided by RyzenAPI
-- Game: Table Tennis Pro

-- MAIN APPLICATION
addappid(1513550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513551, 1, "cd86029f1e6f3ff52447221983cca89331df712fff747b73ae095aff40e43def")
