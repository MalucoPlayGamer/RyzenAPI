-- Lua provided by RyzenAPI
-- Game: addappid(403690)

-- MAIN APPLICATION
addappid(403690)

-- MAIN APP DEPOTS / PACKAGES
addappid(403691, 1, "f7fecb9cf54eceed46d7cc55a4d24db96d409797b73b1d744b2b4c7de214d720")
