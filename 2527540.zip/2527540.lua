-- Lua provided by RyzenAPI 
-- Game: AppID 2527540
addappid(2527540)
addappid(2527541, 1, "ba4216d8d6a9f50de30f836eca207e9145a6402f3c3554bd874f6877df8d12b3")
