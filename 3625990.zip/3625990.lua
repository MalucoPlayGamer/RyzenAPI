-- Lua provided by RyzenAPI 
-- Game: AppID 3625990
addappid(3625990)
addappid(3625991, 1, "7cb147db85fd9b289ec218962821a527097d28aa050499e515b3f1de83ba367c")
