-- Lua provided by RyzenAPI
-- Game: Gougoul Downfall

-- MAIN APPLICATION
addappid(3625990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3625991, 1, "7cb147db85fd9b289ec218962821a527097d28aa050499e515b3f1de83ba367c")

