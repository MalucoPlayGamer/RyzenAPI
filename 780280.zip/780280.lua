-- Lua provided by RyzenAPI
-- Game: Summer Funland

-- MAIN APPLICATION
addappid(780280)

-- MAIN APP DEPOTS / PACKAGES
addappid(780281, 1, "0bd3c8e0b192b05c54a5554abeec5a0a4e79379f32ae834e2e33a4df632f3b84")

