-- Lua provided by RyzenAPI
-- Game: Howard Phillips Lovecar

-- MAIN APPLICATION
addappid(644370)

-- MAIN APP DEPOTS / PACKAGES
addappid(644371, 1, "8560a2f345413cde7e460eb4b60b69a35486927c047d304b23d79df1cb1e2f23")
