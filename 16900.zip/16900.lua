-- Lua provided by RyzenAPI
-- Game: addappid(16900)

-- MAIN APPLICATION
addappid(16900)

-- MAIN APP DEPOTS / PACKAGES
addappid(16901, 1, "bc24c78c8079e2c7c422f606ee6dad18998c54f4a129afdfc3e31e6a333be255")
