-- Lua provided by RyzenAPI
-- Game: Residue: Final Cut

-- MAIN APPLICATION
addappid(265790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
addappid(265791, 1, "4c1e3282f16129d8f48200af5cfabc270beba887877efd775963c7ec892e5243")

