-- Lua provided by RyzenAPI
-- Game: Residue: Final Cut

-- MAIN APPLICATION
addappid(265790)

-- MAIN APP DEPOTS / PACKAGES
addappid(265791, 1, "4c1e3282f16129d8f48200af5cfabc270beba887877efd775963c7ec892e5243")

