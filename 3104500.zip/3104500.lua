-- Lua provided by RyzenAPI
-- Game: Sifu's Quest Demo

-- MAIN APPLICATION
addappid(3104500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104501, 1, "8081bdc906a800961f5f789eb9604ffe141b4abc93004fc3893fe5beda345e66")
