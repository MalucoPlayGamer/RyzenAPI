-- Lua provided by RyzenAPI
-- Game: Takenoko

-- MAIN APPLICATION
addappid(865160)
addappid(1028400)

-- MAIN APP DEPOTS / PACKAGES
addappid(865161,0,"611b8ae1c74f7f95601c3039cdf61b51fa70f7f40e8eb47e20554ff37f3f0db5")

