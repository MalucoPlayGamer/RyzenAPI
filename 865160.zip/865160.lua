-- Lua provided by SkyAPI 
-- Game: Takenoko
addappid(865160)
addappid(865161, 1, "611b8ae1c74f7f95601c3039cdf61b51fa70f7f40e8eb47e20554ff37f3f0db5")
