-- Lua provided by RyzenAPI
-- Game: 三和大神

-- MAIN APPLICATION
addappid(974450)

-- MAIN APP DEPOTS / PACKAGES
addappid(974451, 1, "c54b8d748670432966cdc49c912c8bc86e2e4bd80d3799fa57cf5c4c244a232a")

