-- Lua provided by RyzenAPI 
-- Game: Dark Rising
addappid(710880)
addappid(710881, 1, "3381b9d9cba798fe51878a8430b30647a92fa7bf8c5af543fcf5b4d610b46fab")
addappid(710882, 1, "e43287df1d1574238752e5580394f5e516fa5a71f8a97d212bb0defa5518328f")
