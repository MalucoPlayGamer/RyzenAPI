-- Lua provided by RyzenAPI
-- Game: Dark Rising

-- MAIN APPLICATION
addappid(710880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(710881, 1, "3381b9d9cba798fe51878a8430b30647a92fa7bf8c5af543fcf5b4d610b46fab")
addappid(710882, 1, "e43287df1d1574238752e5580394f5e516fa5a71f8a97d212bb0defa5518328f")

