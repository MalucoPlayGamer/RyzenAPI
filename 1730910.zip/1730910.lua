-- Lua provided by SkyAPI 
-- Game: Hero Road Online
addappid(1730910)
addappid(1730911, 1, "cb6a5b535587bce215374bedfa303d43db9cb9d3e20f61e3b072cb135b5e1e2b")
