-- Lua provided by RyzenAPI
-- Game: 1465410

-- MAIN APPLICATION
addappid(1465410)
-- Game: addappid(1465410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465411, 1, "a263e5aaf4da5c5ea39ba88df8698c3326b0d9c321f4888c7aee8c147c132aab")
