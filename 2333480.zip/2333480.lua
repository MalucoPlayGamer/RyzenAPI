-- Lua provided by RyzenAPI
-- Game: addappid(2333480)

-- MAIN APPLICATION
addappid(2333480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333481, 1, "1ae7f152cae7603aaa72a452a69e26a3c3a520e84556ce5685af749a98d13cb6")
