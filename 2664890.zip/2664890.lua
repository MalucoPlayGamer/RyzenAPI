-- Lua provided by RyzenAPI
-- Game: The Dire

-- MAIN APPLICATION
addappid(2664890)
-- Game: addappid(2664890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664898,0,"8d8bb896c5d6b48096afac5ff69603cc9f927166ea71550f1ce821815aeb5b21")
