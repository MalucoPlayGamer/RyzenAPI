-- Lua provided by RyzenAPI
-- Game: addappid(2841640)

-- MAIN APPLICATION
addappid(2841640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841641, 1, "76085c909acd1cdaa6e7139584c12c9a564fc1c8ae8974f1894bfd6752151f21")
addappid(2841642, 1, "b32e180acddfe8cb280c7510b31e623b15521f25a7ae4e2ba96fd20efe33940c")
addappid(3724400, 0, "38c1d070d37a17c14bdead3d84086b01ebaf10b87cb5a82fb2af8cceeaa95c68")
addappid(3724480, 0, "51d2ff11e0fdd3292ebbce59a0a6228de758f8eafd7ad2cafd012fb503d3295d")
