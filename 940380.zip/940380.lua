-- Lua provided by RyzenAPI 
-- Game: Ascend
addappid(940380)
addappid(940381, 1, "0598c50ad96a41324ec49bc206e9c55d3fe21a8c44d18c68a8c7daa9573c86bd")
