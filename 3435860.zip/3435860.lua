-- Lua provided by RyzenAPI
-- Game: AppID 3435860

-- MAIN APPLICATION
addappid(3435860)
-- Game: addappid(3435860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3435861, 1, "67466bf9434ea477f42ccefbae4f6443b5f7f287946acd134d3d6e57b656d799")
