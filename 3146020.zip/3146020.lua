-- Lua provided by RyzenAPI
-- Game: Game: Resprite

-- MAIN APPLICATION
addappid(3146020)
-- Game: addappid(3146020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146021, 1, "451579aa9aa34646440489b980ff08801f79cde6d61e830877cc029181a6298b")
