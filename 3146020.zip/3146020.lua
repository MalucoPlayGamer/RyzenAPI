-- Lua provided by RyzenAPI
-- Game: Resprite

-- MAIN APPLICATION
addappid(3146020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146021, 1, "451579aa9aa34646440489b980ff08801f79cde6d61e830877cc029181a6298b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
