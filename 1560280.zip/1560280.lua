-- Lua provided by RyzenAPI
-- Game: Stubbs the Zombie in Rebel Without a Pulse - The Fartbook

-- MAIN APPLICATION
addappid(1560280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560280,0,"93f78313ecd26f2d83b2d095ac7af003abd9ba8b9648f63b16709a6794847563")

