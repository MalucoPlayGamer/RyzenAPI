-- Lua provided by RyzenAPI
-- Game: addappid(2938220)

-- MAIN APPLICATION
addappid(2938220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938221, 1, "8935b23c1e5d2b00d132953ee5a0bf45e3bbe7daa712d9ea98212c71a2547570")
