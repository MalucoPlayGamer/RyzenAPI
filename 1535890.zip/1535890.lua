-- Lua provided by RyzenAPI
-- Game: Minicology Demo

-- MAIN APPLICATION
addappid(1535890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535891, 1, "cb6b7b176309a340278201116c0eec4465efbc87b08924cddd186401cf149712")
