-- Lua provided by RyzenAPI
-- Game: Game: AppID 2552650

-- MAIN APPLICATION
addappid(2552650)
-- Game: addappid(2552650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552651, 1, "090c7f2fb659c31cda11888a6d9685e624140ca93a672b3095aa45960fd40f55")
