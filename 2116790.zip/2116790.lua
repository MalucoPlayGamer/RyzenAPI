-- Lua provided by RyzenAPI
-- Game: Warlocks Quarry

-- MAIN APPLICATION
addappid(2116790)
addappid(2381490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(2116791, 1, "d6ca0a4b1a99a4c8a9ea11a5eb18d28ee8449c4b60423c5eefccbf39735d8afc")

