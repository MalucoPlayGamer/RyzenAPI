-- Lua provided by RyzenAPI
-- Game: 3488580

-- MAIN APPLICATION
addappid(3488580)
-- Game: addappid(3488580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3488584,0,"0a12b5c2827b6d71f6fae973159ec4f1308598007bcc1f390db870337a9eef63")
