-- Lua provided by RyzenAPI 
-- Game: Talking Kiteboards by Flexifoil
addappid(1540680)
addappid(1540681, 1, "da13d0a2917e3ea6effc71484a28b39933266bbd24be3c286665411c0f6861a5")
