-- Lua provided by RyzenAPI
-- Game: Talking Kiteboards by Flexifoil

-- MAIN APPLICATION
addappid(1540680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1540681, 1, "da13d0a2917e3ea6effc71484a28b39933266bbd24be3c286665411c0f6861a5")

