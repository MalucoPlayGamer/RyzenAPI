-- Lua provided by RyzenAPI
-- Game: 267180

-- MAIN APPLICATION
addappid(267180)
-- Game: addappid(267180)

-- MAIN APP DEPOTS / PACKAGES
addappid(267181, 1, "758ae5523af42909443d617611c2dcc0af923057c54b5d267ab90586ec39490f")
