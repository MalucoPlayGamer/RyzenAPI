-- Lua provided by RyzenAPI
-- Game: 2016510

-- MAIN APPLICATION
addappid(2016510)
-- Game: addappid(2016510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016512,0,"9e9e243d1638022c94d9d9ace005e8757f745c4af1cca9f4d3ba23c8ee1d8e64")
