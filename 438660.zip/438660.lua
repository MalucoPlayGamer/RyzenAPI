-- Lua provided by RyzenAPI
-- Game: Jerry Rice & Nitus' Dog Football

-- MAIN APPLICATION
addappid(438660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(438661, 1, "93062358d64cb9abbaacc7484c96de784f16779cc36083917feb08885252198a")
addappid(438662, 1, "89d2e1fe54760503b2cfd02c6746b1a194f96abf11793d4e7de582af86ef686d")
