-- Lua provided by RyzenAPI
-- Game: Game: Bloomtown: A Different Story

-- MAIN APPLICATION
addappid(2445990)
-- Game: addappid(2445990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445991, 1, "4355948a6ba13e2b611098fa60a35d167b11d3c6c1f8459e987ed918d0bb3106")
