-- Lua provided by RyzenAPI
-- Game: Pinevale Settlements Demo

-- MAIN APPLICATION
addappid(3259360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3259361, 1, "169c5223090c89e21c261c78ec0a0339ed1e5afa2fae2da7e2f6a777c3f9bb4c")

