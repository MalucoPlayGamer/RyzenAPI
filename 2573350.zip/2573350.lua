-- Lua provided by RyzenAPI
-- Game: Vampire's Kiss

-- MAIN APPLICATION
addappid(2573350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573351, 1, "e3fc9e0a1f433d9e9503299eb225a42a2ef187298ae08385344cce2ae6b889cc")
