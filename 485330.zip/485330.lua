-- Lua provided by RyzenAPI
-- Game: addappid(485330)

-- MAIN APPLICATION
addappid(485330)

-- MAIN APP DEPOTS / PACKAGES
addappid(485331, 1, "2457d6204c6db4f12d1851f9b7c497e03f51c43682488a1970167bab988bab3e")
