-- Lua provided by RyzenAPI
-- Game: AppID 485410

-- MAIN APPLICATION
addappid(485410)
-- Game: addappid(485410)

-- MAIN APP DEPOTS / PACKAGES
addappid(485411, 1, "bf878f7789e74e66bd9d901432b3292be6beb47a4b53e2d581f4705d19179674")
