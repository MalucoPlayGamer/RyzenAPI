-- Lua provided by RyzenAPI
-- Game: addappid(571670)

-- MAIN APPLICATION
addappid(571670)

-- MAIN APP DEPOTS / PACKAGES
addappid(571670,0,"8a636992e8a6d08f9495b72aff5398450e9224d059b6eae321a546d8e94cee74")
