-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(571670)

-- MAIN APP DEPOTS / PACKAGES
addappid(571670,0,"8a636992e8a6d08f9495b72aff5398450e9224d059b6eae321a546d8e94cee74")
