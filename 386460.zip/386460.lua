-- Lua provided by RyzenAPI
-- Game: 386460

-- MAIN APPLICATION
addappid(386460)
-- Game: addappid(386460)

-- MAIN APP DEPOTS / PACKAGES
addappid(386461, 1, "c069bff2a3f0a12320087a8437b4e5bfef73780fd60c0df04d6c711f585b79d9")
