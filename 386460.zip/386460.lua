-- Lua provided by SkyAPI 
-- Game: Baxter's Venture: Director's Cut
addappid(386460)
addappid(386461, 1, "c069bff2a3f0a12320087a8437b4e5bfef73780fd60c0df04d6c711f585b79d9")
