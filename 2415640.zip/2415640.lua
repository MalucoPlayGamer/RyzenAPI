-- Lua provided by RyzenAPI
-- Game: addappid(2415640)

-- MAIN APPLICATION
addappid(2415640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415641, 1, "efbbd8680cba8d7ceb83530b30837d1f30b0ef3b5bdfd9454954d18f2373d470")
