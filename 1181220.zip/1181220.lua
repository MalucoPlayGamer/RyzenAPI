-- Lua provided by SkyAPI 
-- Game: AppID 1181220
addappid(1181220)
addappid(1181221, 1, "535283e64f57eda2bbe6219f41d68645b537c4f2342224cea99e18a0f783fe99")
