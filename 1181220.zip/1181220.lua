-- Lua provided by RyzenAPI
-- Game: addappid(1181220)

-- MAIN APPLICATION
addappid(1181220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181221, 1, "535283e64f57eda2bbe6219f41d68645b537c4f2342224cea99e18a0f783fe99")
