-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator: Ome Line (Tachikawa to Okutama) E233-0 Series

-- MAIN APPLICATION
addappid(3349810)
-- Game: addappid(3349810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349811, 1, "944bedcc1cd636062a64b9ad3fcc4b1286e491f419a49529fccac248c33e8cbf")
addappid(3349812, 1, "7ec06d46460534d73efe5272e9c3d3412b76378ed9b69bc67cfd3b21159c5550")
addappid(3349813, 1, "61c6867003b6280ac9dca3f28c0494988dec9ca120156822ef93f60e8b22be53")
addappid(3349814, 1, "2b338a3b2330d0b39574f36205ab4e37e2768ed58d58960d379eb3c62103588b")
