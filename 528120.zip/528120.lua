-- Lua provided by RyzenAPI
-- Game: Darkness and Flame: Born of Fire

-- MAIN APPLICATION
addappid(528120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(528121, 1, "cfea9202f11105e6b62501390812aad8d359c285f47ee909547e952266b33bf2")
addappid(528122, 1, "9f800e36db266313ad9c3e508135b50f6d49ec319c84a7f5d10ae16d7bbc7083")
addappid(528123, 1, "d41222382aaf0a53365ca2fd80983855fe62f53be2802ab02aaeba9a8487e94c")

