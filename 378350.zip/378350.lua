-- Lua provided by RyzenAPI
-- Game: 378350

-- MAIN APPLICATION
addappid(378350)
-- Game: addappid(378350)

-- MAIN APP DEPOTS / PACKAGES
addappid(378351, 1, "de52b685ee2394a2d7db9a815829a5135e2d69e67865a294121d273b9c54aca1")
