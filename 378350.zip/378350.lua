-- Lua provided by RyzenAPI
-- Game: AppID 378350

-- MAIN APPLICATION
addappid(378350)

-- MAIN APP DEPOTS / PACKAGES
addappid(378351, 1, "de52b685ee2394a2d7db9a815829a5135e2d69e67865a294121d273b9c54aca1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
