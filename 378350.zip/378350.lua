-- Lua provided by SkyAPI 
-- Game: AppID 378350
addappid(378350)
addappid(378351, 1, "de52b685ee2394a2d7db9a815829a5135e2d69e67865a294121d273b9c54aca1")
