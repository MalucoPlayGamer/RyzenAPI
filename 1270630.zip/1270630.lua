-- Lua provided by RyzenAPI
-- Game: addappid(1270630)

-- MAIN APPLICATION
addappid(1270630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270631, 1, "ceb4d0ee01227a9ad19d42ec2df844dff910a0f79b86e89c8cf8834c6abc48d3")
