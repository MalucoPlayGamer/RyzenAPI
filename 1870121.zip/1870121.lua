-- Lua provided by RyzenAPI
-- Game: Bright Memory: Infinite Cheongsam (Blue Flowers) DLC

-- MAIN APPLICATION
addappid(1870121)
-- Game: addappid(1870121)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870121,0,"76810c4f743eb2b4867bdcab19d37502a84d09d662a47ef5b35731f4053470d7")
