-- Lua provided by RyzenAPI
-- Game: 盖世豪侠

-- MAIN APPLICATION
addappid(1776250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776251, 1, "6947c90b8081abeb02f97af9e466afd7f6fb8c0d6b052932f61b0263adf351d1")
