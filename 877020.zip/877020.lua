-- Lua provided by RyzenAPI
-- Game: AppID 877020

-- MAIN APPLICATION
addappid(877020)
-- Game: addappid(877020)

-- MAIN APP DEPOTS / PACKAGES
addappid(877021, 1, "c63504dad08809392d60db0c35d7167d81d7320e94f41b693ac6f6045eff152d")
