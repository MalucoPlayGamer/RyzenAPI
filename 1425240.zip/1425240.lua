-- Lua provided by SkyAPI 
-- Game: Match It!
addappid(1425240)
addappid(1425241, 1, "89c2e42d0a86fdacdab86e9001763b9e9d91373344000a303af901fb314e6d51")
