-- Lua provided by RyzenAPI
-- Game: 1425240

-- MAIN APPLICATION
addappid(1425240)
-- Game: addappid(1425240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425241, 1, "89c2e42d0a86fdacdab86e9001763b9e9d91373344000a303af901fb314e6d51")
