-- Lua provided by RyzenAPI
-- Game: BUGWORLD:ONLINE PRESENTS MITCH MAKER

-- MAIN APPLICATION
addappid(1391090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1391091, 1, "44de23bd7736fcece11eba46498ab14fbab7e0e2aa300c6f7819d736f9db7960")
addappid(1391093, 1, "8158fff61a1f2648a26f9c1f5818d96bb72d0c11118122e73d7180d9a66258af")

