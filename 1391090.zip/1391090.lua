-- Lua provided by RyzenAPI
-- Game: 1391090

-- MAIN APPLICATION
addappid(1391090)
-- Game: addappid(1391090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391091, 1, "44de23bd7736fcece11eba46498ab14fbab7e0e2aa300c6f7819d736f9db7960")
addappid(1391093, 1, "8158fff61a1f2648a26f9c1f5818d96bb72d0c11118122e73d7180d9a66258af")
