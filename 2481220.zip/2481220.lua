-- Lua provided by RyzenAPI
-- Game: Game: Automate Defend Repeat

-- MAIN APPLICATION
addappid(2481220)
-- Game: addappid(2481220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481221, 1, "ff337a43ca59d3da1e9b684f5ef4f6b0d7e985ee57a72fb55bac7008667e24e1")
