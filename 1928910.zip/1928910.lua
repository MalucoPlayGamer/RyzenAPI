-- Lua provided by RyzenAPI
-- Game: TETRIS: Flower Garden

-- MAIN APPLICATION
addappid(1928910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928911, 1, "70b8d0692f73f7862760d2b488a82396bc5168b9a5ad6a835f539c9be6c879d0")
