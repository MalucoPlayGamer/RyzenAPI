-- Lua provided by RyzenAPI
-- Game: Battlepillars Gold Edition

-- MAIN APPLICATION
addappid(280930)

-- MAIN APP DEPOTS / PACKAGES
addappid(280931, 1, "ec5243c6a9a04c36fa503053f35f6de44f78b052625faa8c2a6e70757719f737")
