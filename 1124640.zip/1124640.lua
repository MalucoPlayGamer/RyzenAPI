-- Lua provided by RyzenAPI
-- Game: AppID 1124640

-- MAIN APPLICATION
addappid(1124640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124641, 1, "dd124199dc72af0cb753622f9a91b53934cde3f25f57ee56aa00cdf216d39ba5")
