-- Lua provided by RyzenAPI
-- Game: Sacred Siren

-- MAIN APPLICATION
addappid(1124640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1124641, 1, "dd124199dc72af0cb753622f9a91b53934cde3f25f57ee56aa00cdf216d39ba5")
