-- Lua provided by SkyAPI 
-- Game: Ancient Saga: Vikings Journey
addappid(2307690)
addappid(2307691, 1, "551393ce3320b79a8708cc17484f44c0fcae4072ededbfc8abdcebf581e86114")
addappid(2307692, 1, "0ca5729b2a9574c5738e924a4ac40b7edac938d65d149031f6b330f284530a57")
addappid(2396840)
