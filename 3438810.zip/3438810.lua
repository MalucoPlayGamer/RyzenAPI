-- Lua provided by RyzenAPI
-- Game: Princess Maker : Children of Revelation

-- MAIN APPLICATION
addappid(3438810)
-- Game: addappid(3438810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438811, 1, "999d67931506051d58cb2beeea2b82a5c4c46e5c3934f8ae8c9c7ce2388e3d67")
