-- Lua provided by RyzenAPI
-- Game: Violent Horror Stories: anthology

-- MAIN APPLICATION
addappid(3080380)
-- Game: addappid(3080380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080381, 1, "7b591808c3376391b711d0b7971dfc471d50d8f7722dcfbcea529a1167675094")
