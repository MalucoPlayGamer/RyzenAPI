-- Lua provided by RyzenAPI
-- Game: Partitas

-- MAIN APPLICATION
addappid(1590270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590271, 1, "b7300ff30d735ea6dce820c162949613f8222aba2122779c3b52a2684690d50c")

