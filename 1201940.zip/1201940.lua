-- Lua provided by RyzenAPI
-- Game: 1201940

-- MAIN APPLICATION
addappid(1201940)
-- Game: addappid(1201940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201941, 1, "6a8a4c5699c91529f2c12e994d9e28cfe4be1d72cfe2aa0e1c7ed57064262485")
