-- 1201940's Lua and Manifest Created by Hubcap Manifest
-- Project Speed
-- Created: July 13, 2026 at 07:15:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 7
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(1201940, 1, "e9d37d55483d52b42a230957ea5983808e0a5553ea3b1b85ba3adeda44128f12") -- Project Speed
-- MAIN APP DEPOTS
addappid(1201941, 1, "6a8a4c5699c91529f2c12e994d9e28cfe4be1d72cfe2aa0e1c7ed57064262485") -- Racer Simulator Content
setManifestid(1201941, "7800921029443687823", 3572181799)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)
-- DLCS WITH DEDICATED DEPOTS
-- Racer Simulator - Artwork (AppID: 1203150)
addappid(1203150)
addappid(1203151, 1, "5ae98a64bdb0f8f9d334d52af56df394ca5a828ad5f506a273960b4f05487aa9") -- Racer Simulator - Artwork - Depot 1203151
setManifestid(1203151, "3635574056548162608", 1595098)
-- Racer Simulator - Concept Art (AppID: 1220700)
addappid(1220700)
addappid(1220700, 1, "3d904bf9201b8efe9defaf31890db79ae209a5322c6969204e76b2babca683b7") -- Racer Simulator - Concept Art - Depot 1220700
setManifestid(1220700, "2947847585604300277", 271290)
-- Racer Simulator - Classic Edition (AppID: 1220730)
addappid(1220730)
addappid(1220730, 1, "890987738bb7ad88d10663c90a31402227698fe46feae187e0a4cd4bf9572514") -- Racer Simulator - Classic Edition - Depot 1220730
setManifestid(1220730, "80895790622732550", 2382892201)
-- Project Speed - Expansion Pack 1 (AppID: 1276830)
addappid(1276830)
addappid(1276830, 1, "0a8263057ee944401370b1ceb92b8490143c9580563c303ca8548e72db70c87e") -- Project Speed - Expansion Pack 1 - Depot 1276830
setManifestid(1276830, "5849514947455445496", 2187570804)
-- Project Speed - Expansion Pack 2 (AppID: 1276831)
addappid(1276831)
addappid(1276831, 1, "20822c45e14bab7a1b86ee7b0ef34a43528f3de266c2f4c33e7acc49b08f2dbb") -- Project Speed - Expansion Pack 2 - Depot 1276831
setManifestid(1276831, "9117743293328232012", 1911010358)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2453450) -- Project Speed - Njarovik
addappid(2463010) -- Project Speed - Steampunk Car