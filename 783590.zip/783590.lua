-- Lua provided by RyzenAPI 
-- Game: Age of Gladiators II: Rome
addappid(783590)
addappid(783591, 1, "391dd0ae6b8017a5d8d41098314b2dfc2f3e61164bf7aaa0a978a07eb34174a9")
