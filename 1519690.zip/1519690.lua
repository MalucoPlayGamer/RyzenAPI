-- Lua provided by RyzenAPI
-- Game: STAY

-- MAIN APPLICATION
addappid(1519690)
addappid(1872570)
-- Game: addappid(1519690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519691, 1, "ad10b5e6ed86e7c1729c34d354921f06704dd9f713fd724bad12439c74e40708")
