-- Lua provided by RyzenAPI
-- Game: LiBER

-- MAIN APPLICATION
addappid(1543090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1543091, 1, "947a61acf882d3478df9ce8dc2f1cbdf7e55068fe29c7cc01a5557fd90480a52")

