-- Lua provided by RyzenAPI
-- Game: LiBER

-- MAIN APPLICATION
addappid(1543090)
-- Game: addappid(1543090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543091, 1, "947a61acf882d3478df9ce8dc2f1cbdf7e55068fe29c7cc01a5557fd90480a52")
