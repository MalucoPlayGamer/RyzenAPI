-- Lua provided by RyzenAPI
-- Game: addappid(819160)

-- MAIN APPLICATION
addappid(819160)

-- MAIN APP DEPOTS / PACKAGES
addappid(819161, 1, "0924f323d1eeaf87fabb49c529bc0c5dfb594f8b4ebb1b233c3f0d654aec41bb")
