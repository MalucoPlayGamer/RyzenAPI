-- Lua provided by RyzenAPI
-- Game: Game: AppID 202920

-- MAIN APPLICATION
addappid(202920)
-- Game: addappid(202920)

-- MAIN APP DEPOTS / PACKAGES
addappid(202921, 1, "5911c175e71834a43eb117f8d187e74b21977f48fb2d78e8634827ff229e94f1")
