-- Lua provided by SkyAPI 
-- Game: AppID 202920
addappid(202920)
addappid(202921, 1, "5911c175e71834a43eb117f8d187e74b21977f48fb2d78e8634827ff229e94f1")
