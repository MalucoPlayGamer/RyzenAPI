-- Lua provided by RyzenAPI
-- Game: Dream Engines: Nomad Cities

-- MAIN APPLICATION
addappid(1076750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076751, 1, "969c4466e32df9e8a0eb9c6f7b9079afd4ce8b0cedff88fd52f119984f81fda6")
