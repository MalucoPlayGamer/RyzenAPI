-- Lua provided by RyzenAPI
-- Game: Game: AppID 987230

-- MAIN APPLICATION
addappid(987230)
-- Game: addappid(987230)

-- MAIN APP DEPOTS / PACKAGES
addappid(987231, 1, "a91b37dd3197cf178d5717a6c5c5ebd16c75b82381723735acf5a1fb5d2f570c")
