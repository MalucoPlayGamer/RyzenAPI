-- Lua provided by RyzenAPI
-- Game: AppID 15950

-- MAIN APPLICATION
addappid(15950)
-- Game: addappid(15950)

-- MAIN APP DEPOTS / PACKAGES
addappid(15951, 1, "ea1a6ebe1a100574338713db7c4b888992211231ff0582c40affafb023281e4f")
