-- Lua provided by RyzenAPI 
-- Game: Little Sim World
addappid(1429880)
addappid(1429881, 1, "3faa97d2844a3dbe09fc697d4a781583446c83202f4ef4129091ba7c261426ff")
