-- Lua provided by RyzenAPI
-- Game: VInput

-- MAIN APPLICATION
addappid(2174170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174171, 1, "daaeecf6884a5e04cbd4e3859057d9e15be723131742bdc4142d8d19cad6d702")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
