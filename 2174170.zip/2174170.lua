-- Lua provided by RyzenAPI
-- Game: Game: VInput

-- MAIN APPLICATION
addappid(2174170)
-- Game: addappid(2174170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174171, 1, "daaeecf6884a5e04cbd4e3859057d9e15be723131742bdc4142d8d19cad6d702")
