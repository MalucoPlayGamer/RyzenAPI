-- Lua provided by RyzenAPI
-- Game: Jewel bits

-- MAIN APPLICATION
addappid(414140)
-- Game: addappid(414140)

-- MAIN APP DEPOTS / PACKAGES
addappid(414141, 1, "9f4397d251f38620428c487ab37c5909398e6c52a7d2e239bd506515b4831b57")
