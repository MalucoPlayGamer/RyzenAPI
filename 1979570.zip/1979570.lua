-- Lua provided by RyzenAPI
-- Game: Tomomon

-- MAIN APPLICATION
addappid(1979570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979571, 1, "844232df2a55e212a92ed0176f96a9789f443bbb30fe1bd584e712825c07f6ae")
