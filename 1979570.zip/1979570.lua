-- Lua provided by RyzenAPI
-- Game: Tomomon

-- MAIN APPLICATION
addappid(1979570)
addappid(3132410)
addappid(3237990)
addappid(3284920)
addappid(3317180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1979571, 1, "844232df2a55e212a92ed0176f96a9789f443bbb30fe1bd584e712825c07f6ae")

