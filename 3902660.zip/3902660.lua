-- Lua provided by RyzenAPI
-- Game: Milker Clicker

-- MAIN APPLICATION
addappid(3902660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3902661,0,"994f663d7966ea9aea08343fcb65736f64e1f8398ffb2c27f772604aa57e7a27")

