-- Lua provided by RyzenAPI
-- Game: Space Crisis

-- MAIN APPLICATION
addappid(1383220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383221, 1, "68180457a961abb3dbc5f1c36ab2b8bc4ad0f73495a2c1baf15f082b22c6a0b7")
