-- Lua provided by RyzenAPI
-- Game: Plantera 2: Golden Acorn

-- MAIN APPLICATION
addappid(1091920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091921, 1, "c01bcb85999d2fa414479543489bfb2af548fafe6fb1eae5b8175c581354e6dd")

