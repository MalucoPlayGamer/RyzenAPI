-- Lua provided by RyzenAPI
-- Game: Game: Polylithic

-- MAIN APPLICATION
addappid(1839060)
-- Game: addappid(1839060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839061, 1, "5b8cd3a72f81f37e1883ced52ec6c323c991b69b0ac12bf8e5c5ba758ac5fc2a")
