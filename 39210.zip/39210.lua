-- Lua provided by RyzenAPI 
-- Game: FINAL FANTASY XIV Online
addappid(39210)
addappid(39211, 1, "d0c623233763e6f93f011efe694adc0da08240833523dce4dd7c33452faefd98")
