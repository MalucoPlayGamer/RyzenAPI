-- Lua provided by RyzenAPI
-- Game: 39210

-- MAIN APPLICATION
addappid(39210)
-- Game: addappid(39210)

-- MAIN APP DEPOTS / PACKAGES
addappid(39211, 1, "d0c623233763e6f93f011efe694adc0da08240833523dce4dd7c33452faefd98")
