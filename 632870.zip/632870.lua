-- Lua provided by RyzenAPI 
-- Game: AppID 632870
addappid(632870)
addappid(632871, 1, "bb0872c2ea6d9a04bbf262213c345fb98a4b40db0accda9a7587acb823bd6133")
