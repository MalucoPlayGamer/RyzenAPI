-- Lua provided by RyzenAPI
-- Game: addappid(632870)

-- MAIN APPLICATION
addappid(632870)

-- MAIN APP DEPOTS / PACKAGES
addappid(632871, 1, "bb0872c2ea6d9a04bbf262213c345fb98a4b40db0accda9a7587acb823bd6133")
