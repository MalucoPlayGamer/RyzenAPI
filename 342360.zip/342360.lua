-- Lua provided by RyzenAPI
-- Game: Game: AppID 342360

-- MAIN APPLICATION
addappid(342360)
-- Game: addappid(342360)

-- MAIN APP DEPOTS / PACKAGES
addappid(342361, 1, "371d27d0ecac66883a3d8203042c45f9b3a43c7c606e8bcfe72ea4ee33f35a61")
addappid(342362, 1, "015df4d57035898f2b611876809cded27632562e162e5f44b0001f1fb2c1cde3")
