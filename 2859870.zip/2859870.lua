-- Lua provided by SkyAPI 
-- Game: Duel of games
addappid(2859870)
addappid(2859871, 1, "66d679e011a8a714b6560138ea534b3321d788dae5b7937f23b333655aa3f7e0")
