-- Lua provided by RyzenAPI
-- Game: Game: Duel of games

-- MAIN APPLICATION
addappid(2859870)
-- Game: addappid(2859870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859871, 1, "66d679e011a8a714b6560138ea534b3321d788dae5b7937f23b333655aa3f7e0")
