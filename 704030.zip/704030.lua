-- Lua provided by RyzenAPI
-- Game: Professional Farmer: Cattle and Crops

-- MAIN APPLICATION
addappid(704030)

-- MAIN APP DEPOTS / PACKAGES
addappid(704031, 1, "66464e5166490526b33d5e6e5cf35d660b19770bec6096541a593e059207fa10")
addappid(704032, 1, "f38dccf0b8817419c1dd74c0453d2fbb8341401ec2d15994c5e253cfadf1654a")
addappid(704033, 1, "319cf791404ea340e307000aa9d17ddae6bcb869924fe8cdea782e6b7c4effd5")
addappid(1449340, 0, "800364209a1b75ce7256c7a66cf56a04c4cf8e2fe7fc9e9f529dcb6d49ceb959")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
