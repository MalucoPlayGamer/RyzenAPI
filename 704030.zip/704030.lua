-- Lua provided by SkyAPI 
-- Game: Professional Farmer: Cattle and Crops
addappid(704030)
addappid(704031, 1, "66464e5166490526b33d5e6e5cf35d660b19770bec6096541a593e059207fa10")
addappid(704032, 1, "f38dccf0b8817419c1dd74c0453d2fbb8341401ec2d15994c5e253cfadf1654a")
addappid(704033, 1, "319cf791404ea340e307000aa9d17ddae6bcb869924fe8cdea782e6b7c4effd5")
addappid(1449340, 0, "800364209a1b75ce7256c7a66cf56a04c4cf8e2fe7fc9e9f529dcb6d49ceb959")
