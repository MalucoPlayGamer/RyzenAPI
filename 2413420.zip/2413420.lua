-- Lua provided by RyzenAPI
-- Game: Box To The Beat VR Demo

-- MAIN APPLICATION
addappid(2413420)
-- Game: addappid(2413420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413421, 1, "c8a5560444b569feb3dc63f75c5f843ebe0738eef11246c33dd09dd695a605b2")
