-- Lua provided by RyzenAPI
-- Game: Planetka

-- MAIN APPLICATION
addappid(2878100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878101, 1, "e4671fa3375fc06ea883c7ce0921264bf23be11eb7be1dd113c59f00cd1eb46a")
