-- Lua provided by RyzenAPI
-- Game: Game: Daenerys doesn’t want Hentai

-- MAIN APPLICATION
addappid(1163460)
-- Game: addappid(1163460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163461, 1, "9abfa0f2d27507fb53ac4af9ff0348b2e5131ccd0925816bbf10e98ac4ae7203")
