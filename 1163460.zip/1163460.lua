-- Lua provided by RyzenAPI
-- Game: Daenerys doesn’t want Hentai

-- MAIN APPLICATION
addappid(1163460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1163461, 1, "9abfa0f2d27507fb53ac4af9ff0348b2e5131ccd0925816bbf10e98ac4ae7203")

