-- Lua provided by RyzenAPI
-- Game: The Last Stand: Aftermath

-- MAIN APPLICATION
addappid(1266840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1266841, 1, "14f0398801f38f2631d86d213f5e1321b476f27c89f54870a9b77e0f009af2d2")

