-- Lua provided by RyzenAPI
-- Game: Game: The Last Stand: Aftermath

-- MAIN APPLICATION
addappid(1266840)
-- Game: addappid(1266840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266841, 1, "14f0398801f38f2631d86d213f5e1321b476f27c89f54870a9b77e0f009af2d2")
