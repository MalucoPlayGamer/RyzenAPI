-- Lua provided by RyzenAPI
-- Game: AppID 1998590

-- MAIN APPLICATION
addappid(1998590)
-- Game: addappid(1998590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998591, 1, "1f9702c3ccf534cb1a74adad40d53119858bd693fcd9a54fce469101fd91c74c")
