-- Lua provided by RyzenAPI
-- Game: AppID 1299220

-- MAIN APPLICATION
addappid(1299220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299221, 1, "fb7f3ccab75b3ef5936258000b53204ca77371a1d2b96feac6caff61612c34f3")
