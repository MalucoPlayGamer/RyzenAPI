-- Lua provided by RyzenAPI
-- Game: AppID 1299220

-- MAIN APPLICATION
addappid(1299220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1299221, 1, "fb7f3ccab75b3ef5936258000b53204ca77371a1d2b96feac6caff61612c34f3")

