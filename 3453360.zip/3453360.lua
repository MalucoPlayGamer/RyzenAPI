-- Lua provided by RyzenAPI
-- Game: Tribute

-- MAIN APPLICATION
addappid(3453360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453361, 1, "47efc1103e385a139c9e406c6cc566e5bf71df331cd91e580bf5977b3dd0b0b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
