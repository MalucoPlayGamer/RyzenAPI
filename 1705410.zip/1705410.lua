-- Lua provided by RyzenAPI
-- Game: 1705410

-- MAIN APPLICATION
addappid(1705410)
-- Game: addappid(1705410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705411, 1, "f782154f0073d8b41480bc75bde6f45405d2b8c6634decef750beb4fbd733003")
