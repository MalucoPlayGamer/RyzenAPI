-- Lua provided by RyzenAPI
-- Game: Bloody Efforts

-- MAIN APPLICATION
addappid(1705410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705411, 1, "f782154f0073d8b41480bc75bde6f45405d2b8c6634decef750beb4fbd733003")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
