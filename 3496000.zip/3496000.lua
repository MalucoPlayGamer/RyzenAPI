-- Lua provided by RyzenAPI
-- Game: Ship, Inc.

-- MAIN APPLICATION
addappid(3496000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496001, 1, "ab5f7aa3985fbccdb6589b71db8c36547133ecf078cf8935abd0f2964f35f10a")
