-- Lua provided by RyzenAPI 
-- Game: AppID 1424230
addappid(1424230)
addappid(1424231, 1, "eb4909032cd917aaaf94448da374ca711a01f784817bb93dcfb84af7be77e87d")
addappid(1424232, 1, "51fb0a69919307daf391d19b53617a43f8a7fb773356486b503a3e06c3f93346")
