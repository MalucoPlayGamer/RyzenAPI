-- Lua provided by RyzenAPI
-- Game: addappid(3698950)

-- MAIN APPLICATION
addappid(3698950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3698951, 1, "c87d10122864c1754a6b4de2cc7a64a392de75cadf72c1e81e89fa29a4c23b18")
