-- Lua provided by RyzenAPI
-- Game: Copierre

-- MAIN APPLICATION
addappid(776780)

-- MAIN APP DEPOTS / PACKAGES
addappid(776781,0,"9563287b26bbbaa50c0f575c36fbe1cb7796daa7fb47cb9698d818d05084f199")

