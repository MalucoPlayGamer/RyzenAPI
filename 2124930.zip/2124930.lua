-- Lua provided by RyzenAPI
-- Game: Gum Ball Run

-- MAIN APPLICATION
addappid(2124930)
-- Game: addappid(2124930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124931, 1, "ca71e1a30133bf9f93881e02efb1fafe71e67123b8555c6c23d630280812ba86")
