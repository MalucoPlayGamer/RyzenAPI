-- Lua provided by SkyAPI 
-- Game: Gum Ball Run
addappid(2124930)
addappid(2124931, 1, "ca71e1a30133bf9f93881e02efb1fafe71e67123b8555c6c23d630280812ba86")
