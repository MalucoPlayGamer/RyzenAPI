-- Lua provided by RyzenAPI
-- Game: 1648770

-- MAIN APPLICATION
addappid(1648770)
-- Game: addappid(1648770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648771, 1, "1fbbcbb6f971c9ee39c20d67df69e404ba2dfac9e46d4db013c71298dda47385")
