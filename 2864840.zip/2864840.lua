-- Lua provided by RyzenAPI
-- Game: 2864840

-- MAIN APPLICATION
addappid(2864840)
-- Game: addappid(2864840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864841, 1, "1e47359a890492f229ab10c652dfff5f975f6d7d515e937ed744cfa3979c1ef2")
