-- Lua provided by RyzenAPI
-- Game: Game: SNOW BROS. 2 SPECIAL Demo

-- MAIN APPLICATION
addappid(3251150)
-- Game: addappid(3251150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251151, 1, "df4f08e064920274a863cc3d13f1cba3ab4fab8b15cdf59560691f3fa28604f2")
