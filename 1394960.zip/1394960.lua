-- Lua provided by RyzenAPI
-- Game: 1394960

-- MAIN APPLICATION
addappid(1394960)
-- Game: addappid(1394960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394961, 1, "4870c807169a8155ac5bce04da85459e55bbe6b7c14534ac72447f8dde06f5c9")
