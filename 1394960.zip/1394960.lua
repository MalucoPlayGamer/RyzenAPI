-- Lua provided by RyzenAPI
-- Game: Winter Survival

-- MAIN APPLICATION
addappid(1394960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1394961, 1, "4870c807169a8155ac5bce04da85459e55bbe6b7c14534ac72447f8dde06f5c9")

