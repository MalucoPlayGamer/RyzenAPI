-- Lua provided by RyzenAPI
-- Game: Scribble Ships

-- MAIN APPLICATION
addappid(548130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(548131, 1, "051e75667c8e685a8c31a56340c48c27af2c551f28169b8ffff77066f5092b74")
addappid(548132, 1, "d747eee7baac30dc517cbd8df051caa6c6bf7327312b690aeda8c9ef842e2147")
addappid(548133, 1, "d7a019579d4ad20a5dea3b7a7bd08f20324e2240e7fb9a87a2f6fe63cbfe11d4")
