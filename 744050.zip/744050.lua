-- Lua provided by RyzenAPI
-- Game: AppID 744050

-- MAIN APPLICATION
addappid(744050)
-- Game: addappid(744050)

-- MAIN APP DEPOTS / PACKAGES
addappid(744051, 1, "d480b9d6186aff8974e40b53c22f35d0b94d4a7dd3c807754c96a10032c731ee")
