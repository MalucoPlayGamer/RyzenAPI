-- Lua provided by RyzenAPI
-- Game: Putin VS Zombies

-- MAIN APPLICATION
addappid(1588160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588161, 1, "d93124309fb778266fe9231fdeed39a6c7408fbf0da480965177a37079b615ca")
