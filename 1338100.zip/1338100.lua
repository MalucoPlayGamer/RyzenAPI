-- Lua provided by RyzenAPI
-- Game: Teratopia

-- MAIN APPLICATION
addappid(1338100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338101,0,"7c6923bd168e932de6e7be77a5102c3f01d8efab1465d4f5fd06b45658cc7ca0")

