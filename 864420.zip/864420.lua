-- Lua provided by RyzenAPI
-- Game: Waterside Chirping 水畔空蝉

-- MAIN APPLICATION
addappid(864420)

-- MAIN APP DEPOTS / PACKAGES
addappid(864421, 1, "8c8f91fbbb9d6540a8c3bfb827528e4643569dffbb8dd64c0aa5467a592997f6")
