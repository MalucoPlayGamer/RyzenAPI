-- Lua provided by RyzenAPI
-- Game: addappid(2078290)

-- MAIN APPLICATION
addappid(2078290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078295,0,"f7a584e61224d0523c66291be8fb828de7eaebc45c18bc3d06886110d0303acb")
