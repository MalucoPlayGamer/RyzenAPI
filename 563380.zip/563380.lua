-- Lua provided by RyzenAPI
-- Game: 563380

-- MAIN APPLICATION
addappid(563380)
-- Game: addappid(563380)

-- MAIN APP DEPOTS / PACKAGES
addappid(563381, 1, "bcf826d98d4b820dc6b8dfa2a6caf2440114cf6ef924503ca6f4900f0da52e78")
