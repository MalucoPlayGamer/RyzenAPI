-- Lua provided by RyzenAPI
-- Game: Shadows

-- MAIN APPLICATION
addappid(563380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(563381, 1, "bcf826d98d4b820dc6b8dfa2a6caf2440114cf6ef924503ca6f4900f0da52e78")
