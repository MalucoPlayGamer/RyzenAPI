-- Lua provided by RyzenAPI
-- Game: The Cycle: Frontier

-- MAIN APPLICATION
addappid(868270)
addappid(1947000)
addappid(1947010)
addappid(1947011)
addappid(1947012)
addappid(2089550)
addappid(2089570)
addappid(2130810)
addappid(2357210)
addappid(2357211)
addappid(2357212)

-- MAIN APP DEPOTS / PACKAGES
addappid(868271,0,"9447c8f65231308e83a0afaef6df5e24e5312c2a009113ea8e5f77c8e0830ebc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
