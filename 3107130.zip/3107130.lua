-- Lua provided by RyzenAPI
-- Game: Grit Porn Video Tapes

-- MAIN APPLICATION
addappid(3107130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107131, 1, "8a1e66b153439efc601406237e9f279d1d9426f3ca3dc387659f146f1a8ebd9d")
