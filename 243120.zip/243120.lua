-- Lua provided by RyzenAPI
-- Game: AppID 243120

-- MAIN APPLICATION
addappid(243120)

-- MAIN APP DEPOTS / PACKAGES
addappid(243121, 1, "3f98e2bb91d7570f2ab8d2808569b6533080e355f956a6d19646152f477cdb3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
