-- Lua provided by RyzenAPI
-- Game: AppID 243120

-- MAIN APPLICATION
addappid(243120)
-- Game: addappid(243120)

-- MAIN APP DEPOTS / PACKAGES
addappid(243121, 1, "3f98e2bb91d7570f2ab8d2808569b6533080e355f956a6d19646152f477cdb3c")
