-- Lua provided by RyzenAPI
-- Game: Game: AppID 943760

-- MAIN APPLICATION
addappid(943760)
-- Game: addappid(943760)

-- MAIN APP DEPOTS / PACKAGES
addappid(943761, 1, "a147170ca2933732cbb91a7408ea400003998ff95e85153cf8f100a4826f414d")
