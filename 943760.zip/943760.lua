-- Lua provided by SkyAPI 
-- Game: AppID 943760
addappid(943760)
addappid(943761, 1, "a147170ca2933732cbb91a7408ea400003998ff95e85153cf8f100a4826f414d")
