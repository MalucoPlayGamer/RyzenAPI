-- Lua provided by RyzenAPI
-- Game: Anderson (Alpha)

-- MAIN APPLICATION
addappid(228990)
addappid(863220)
addappid(943550)

-- MAIN APP DEPOTS / PACKAGES
addappid(863222,0,"eb264e2fb2876ecf2686980374057324e0a8af78dc454c416e951c2e7ca4bc08")

