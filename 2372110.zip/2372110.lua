-- Lua provided by RyzenAPI
-- Game: Toon Tumble

-- MAIN APPLICATION
addappid(2372110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372111, 1, "d54c029cac8834cea909d54e9b971ce2bcb0a51abcfc413c460ed8db03f80164")

