-- Lua provided by RyzenAPI
-- Game: 973800

-- MAIN APPLICATION
addappid(973800)
-- Game: addappid(973800)

-- MAIN APP DEPOTS / PACKAGES
addappid(973801, 1, "5193c2b93ed90daafa0813b4bcdcd1304366654647e0481c6109da708c76a5eb")
