-- Lua provided by RyzenAPI
-- Game: UnderRail

-- MAIN APPLICATION
addappid(250520)

-- MAIN APP DEPOTS / PACKAGES
addappid(250521, 1, "8ee38dcc5abe5e4c07b092b116464ab21b1880e9e89820ce97a662b07e78c449")
addappid(694330, 0, "306abce315c15289ae5580c0994ad1890a44ed374a1ec3c3c9b1298874c7a712")
addappid(2604510, 0, "b3c65efc79ec35fe322ea1b14f75eadc38856b0d356c946bb4da331685ec1ea2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
