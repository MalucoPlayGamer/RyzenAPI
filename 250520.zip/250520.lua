-- Lua provided by SkyAPI 
-- Game: UnderRail
addappid(250520)
addappid(250521, 1, "8ee38dcc5abe5e4c07b092b116464ab21b1880e9e89820ce97a662b07e78c449")
addappid(694330, 0, "306abce315c15289ae5580c0994ad1890a44ed374a1ec3c3c9b1298874c7a712")
addappid(2604510, 0, "b3c65efc79ec35fe322ea1b14f75eadc38856b0d356c946bb4da331685ec1ea2")
