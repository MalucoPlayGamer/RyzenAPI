-- Lua provided by RyzenAPI
-- Game: HeartZ: Co-Hope Puzzles

-- MAIN APPLICATION
addappid(347330)

-- MAIN APP DEPOTS / PACKAGES
addappid(347331, 1, "bbc41247d79455195f05ab396e471d945e0595fefc29aa3eb87dc6abf874c478")
addappid(347332, 1, "deed47c827fad3cf3768a7a9144b85148a3ccbdeec0910617977f379f9d40467")
addappid(347333, 1, "2cec5666750f72d31cbcdfe9f870601dd7be78fa381306ace59e0dd089457cdc")
addappid(347334, 1, "09e77d8c0a16cfe708957dd5d8abe735b1d95170c23c155cae1b8d3d0939ec35")
addappid(347335, 1, "42f76da9bfbcbf515dedf57753f1ca8fc3b25bb58c3da056109c0ebca6ef2380")
addappid(347336, 1, "d85aa849a2f8611ed5f5269e4a5a3986e0a6ff1e2d1ab46689dbc2152c6c74ec")
