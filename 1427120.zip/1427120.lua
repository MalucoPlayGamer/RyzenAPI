-- Lua provided by RyzenAPI
-- Game: Consequence

-- MAIN APPLICATION
addappid(1427120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427121, 1, "3f13ddc997783513158b7e0c5b6e5ee965650a7ccda3a50b0a646b45fbddc82e")
