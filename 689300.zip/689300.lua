-- Lua provided by RyzenAPI
-- Game: Monsteria

-- MAIN APPLICATION
addappid(689300)

-- MAIN APP DEPOTS / PACKAGES
addappid(689301, 1, "959fda1ab54a9244bc5799b3c77ed73ed722ea4c8b4e74684e697bd9e5a87fe6")
