-- Lua provided by RyzenAPI
-- Game: AppID 251110

-- MAIN APPLICATION
addappid(251110)

-- MAIN APP DEPOTS / PACKAGES
addappid(251111, 1, "41a7e0ade168ef0d3b642d715bea73e47a1ade2e3829837ec5a696c440d777d4")
addappid(251112, 1, "e87b860e57bf2ad16e51fca61fa78b433e78ea14e98b76fea680139f07dcde82")
addappid(432450, 0, "f57ae1bf3a658aebd1fcd7dc7c8041f546b9e2281debec7ce2ceb742d118d28d")
