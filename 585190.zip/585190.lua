-- Lua provided by RyzenAPI
-- Game: A Gummy's Life

-- MAIN APPLICATION
addappid(585190)

-- MAIN APP DEPOTS / PACKAGES
addappid(585191, 1, "89e112651ccd2dba42337f26e4504db63b90c36131b5f74c4b80fb4c9305696b")
addappid(585192, 1, "337178b9eaca6b3ff40cf858b4c8d47ee5368867af7719de75934e412b23e4f8")
addappid(585193, 1, "4fa20f8b32e60c1c5f967a416769add52cd3b7ddadc6406a03ee124ad948f9d0")

