-- Lua provided by RyzenAPI
-- Game: AppID 404540

-- MAIN APPLICATION
addappid(404540)

-- MAIN APP DEPOTS / PACKAGES
addappid(404541, 1, "ce6e47b279f0be3528a02cd179229ed28ead861f3df624b1cfa38d82c631518b")
