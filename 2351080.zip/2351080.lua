-- Lua provided by RyzenAPI
-- Game: Magic Pussy: Chapter 1

-- MAIN APPLICATION
addappid(2351080)
-- Game: addappid(2351080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351081, 1, "9ea9d5d4c7c53d586f4f0f6ede2c88e6d537085c0d8c842aa76861108bd33dd2")
