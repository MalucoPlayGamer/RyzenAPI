-- Lua provided by SkyAPI 
-- Game: Magic Pussy: Chapter 1
addappid(2351080)
addappid(2351081, 1, "9ea9d5d4c7c53d586f4f0f6ede2c88e6d537085c0d8c842aa76861108bd33dd2")
