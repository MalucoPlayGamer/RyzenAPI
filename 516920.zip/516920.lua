-- Lua provided by RyzenAPI
-- Game: AppID 516920

-- MAIN APPLICATION
addappid(516920)

-- MAIN APP DEPOTS / PACKAGES
addappid(516921, 1, "f8829d61512e5f8b5601fe4f043ccfecff1050c5dec1b0c42fb9eef677b0f54f")
