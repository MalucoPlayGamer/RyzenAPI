-- Lua provided by RyzenAPI
-- Game: AppID 1018320

-- MAIN APPLICATION
addappid(1018320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018321, 1, "ca958bdecb6a10f6ea5069a4328d31be6e0ceaa519e77ac1b0d4bf32b630238b")
