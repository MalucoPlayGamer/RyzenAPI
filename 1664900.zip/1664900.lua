-- Lua provided by RyzenAPI
-- Game: LoveAndBetrayal Playtest

-- MAIN APPLICATION
addappid(1664900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664901, 1, "923b419d09b3688c022ba3d7538b38367b010b06eaea1cdd4370f184f26916df")

