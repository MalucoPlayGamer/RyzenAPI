-- Lua provided by SkyAPI 
-- Game: LoveAndBetrayal Playtest
addappid(1664900)
addappid(1664901, 1, "923b419d09b3688c022ba3d7538b38367b010b06eaea1cdd4370f184f26916df")
