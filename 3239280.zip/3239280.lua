-- Lua provided by RyzenAPI
-- Game: Game: Laundry Store Simulator Demo

-- MAIN APPLICATION
addappid(3239280)
-- Game: addappid(3239280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239281, 1, "b404539705f93e69524f48efa81358b62032147d34bd602f4ff5dff8643fdfba")
