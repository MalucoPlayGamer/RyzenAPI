-- Lua provided by RyzenAPI
-- Game: Legend of Homebody

-- MAIN APPLICATION
addappid(744260)

-- MAIN APP DEPOTS / PACKAGES
addappid(744261, 1, "1cc2b92ba857836197621d2d74c8c6f54328c8620db050dfc40dbffb666b95ba")

