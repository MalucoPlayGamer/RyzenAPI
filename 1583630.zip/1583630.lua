-- Lua provided by RyzenAPI
-- Game: Treasure of Barracuda

-- MAIN APPLICATION
addappid(1583630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583631, 1, "81dc0de213cb6cbaa3f3e896262578b5cdf4354f597ce8b16b507a8378a973e8")

