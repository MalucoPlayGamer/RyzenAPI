-- Lua provided by RyzenAPI
-- Game: Treasure of Barracuda

-- MAIN APPLICATION
addappid(1583630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583631, 1, "81dc0de213cb6cbaa3f3e896262578b5cdf4354f597ce8b16b507a8378a973e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
