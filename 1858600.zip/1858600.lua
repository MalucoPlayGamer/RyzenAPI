-- Lua provided by RyzenAPI
-- Game: AppID 1858600

-- MAIN APPLICATION
addappid(1858600)
-- Game: addappid(1858600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858601, 1, "7d02b8af6e4f6d27c9531f0ecf28c1994ac37c9ae57965a52aa92f8616ba1824")
