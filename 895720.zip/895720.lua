-- Lua provided by RyzenAPI
-- Game: 895720

-- MAIN APPLICATION
addappid(895720)
-- Game: addappid(895720)

-- MAIN APP DEPOTS / PACKAGES
addappid(895721, 1, "d993b8c67c2a7622f2507da6b44ba43adbebbc6b562a009f826959ef90e4e81d")
