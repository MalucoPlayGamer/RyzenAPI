-- Lua provided by RyzenAPI
-- Game: Game: Moose Miners

-- MAIN APPLICATION
addappid(2591410)
-- Game: addappid(2591410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591411, 1, "47624590f47b7cf2be79d4fce5552ee5dbe48897623a297f7e3b357c04069f24")
