-- Lua provided by RyzenAPI
-- Game: Game: Hometopia

-- MAIN APPLICATION
addappid(1138640)
-- Game: addappid(1138640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138641, 1, "3595306a899c5b04a6dccc4ce52479d7e971074b71b2e8a5c187f24fa229945f")
