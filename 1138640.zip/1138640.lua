-- Lua provided by SkyAPI 
-- Game: Hometopia
addappid(1138640)
addappid(1138641, 1, "3595306a899c5b04a6dccc4ce52479d7e971074b71b2e8a5c187f24fa229945f")
