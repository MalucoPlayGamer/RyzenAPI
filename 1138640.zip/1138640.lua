-- Lua provided by RyzenAPI
-- Game: Hometopia

-- MAIN APPLICATION
addappid(1138640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1138641, 1, "3595306a899c5b04a6dccc4ce52479d7e971074b71b2e8a5c187f24fa229945f")

