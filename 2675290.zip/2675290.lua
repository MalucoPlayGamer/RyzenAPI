-- Lua provided by RyzenAPI
-- Game: Game: LASERS

-- MAIN APPLICATION
addappid(2675290)
-- Game: addappid(2675290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675291, 1, "92f90ff1af38a3d8aa4a6c6701a25c09dcb2fbd9c0c8ddd10ba1dfab51b54cfc")
