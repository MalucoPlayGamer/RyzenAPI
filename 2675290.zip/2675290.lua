-- Lua provided by RyzenAPI
-- Game: LASERS

-- MAIN APPLICATION
addappid(2675290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675291, 1, "92f90ff1af38a3d8aa4a6c6701a25c09dcb2fbd9c0c8ddd10ba1dfab51b54cfc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
