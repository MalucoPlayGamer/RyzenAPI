-- Lua provided by SkyAPI 
-- Game: LASERS
addappid(2675290)
addappid(2675291, 1, "92f90ff1af38a3d8aa4a6c6701a25c09dcb2fbd9c0c8ddd10ba1dfab51b54cfc")
