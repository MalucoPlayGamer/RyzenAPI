-- Lua provided by RyzenAPI
-- Game: Christmas Stories: Hans Christian Andersen's Tin Soldier Collector's Edition

-- MAIN APPLICATION
addappid(758600)

-- MAIN APP DEPOTS / PACKAGES
addappid(758601,0,"e9e16c11a1433d0fd68cd7bdb00365a362c9bd088f96a2715bdaa0da481ae26c")

