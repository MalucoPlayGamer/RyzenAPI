-- Lua provided by SkyAPI 
-- Game: 108 Silly Ways to Die
addappid(3159900)
addappid(3159901, 1, "de7ec94f1484dcc239b0bd407445682237a6ac1da0497d4278cb0f3945341a2e")
addappid(3489690)
