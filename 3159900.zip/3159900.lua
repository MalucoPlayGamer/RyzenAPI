-- Lua provided by RyzenAPI
-- Game: Game: 108 Silly Ways to Die

-- MAIN APPLICATION
addappid(3159900)
addappid(3489690)
-- Game: addappid(3159900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159901, 1, "de7ec94f1484dcc239b0bd407445682237a6ac1da0497d4278cb0f3945341a2e")
