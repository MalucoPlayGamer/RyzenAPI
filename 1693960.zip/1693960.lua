-- Lua provided by RyzenAPI
-- Game: Atomic Wilds

-- MAIN APPLICATION
addappid(1693960)
-- Game: addappid(1693960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693961, 1, "6c45167f0742932a585ec52c388f056c6f807bdbd05e22e309f55059a1391c49")
