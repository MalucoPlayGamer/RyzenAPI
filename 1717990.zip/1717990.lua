-- Lua provided by SkyAPI 
-- Game: Fangs
addappid(1717990)
addappid(1717991, 1, "8f7139d72a68a30ca702ccd50ab3c405e6354f5c531d49d993a77471c7676260")
