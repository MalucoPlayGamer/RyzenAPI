-- Lua provided by RyzenAPI
-- Game: Golem Creation Kit

-- MAIN APPLICATION
addappid(650680)
addappid(699520)

-- MAIN APP DEPOTS / PACKAGES
addappid(650681, 1, "ca2bc8a1e6da3ca0e4550ba9007e500f482aa452e51755fa7a76dc709b8a8952")
