-- Lua provided by RyzenAPI
-- Game: addappid(751220)

-- MAIN APPLICATION
addappid(751220)

-- MAIN APP DEPOTS / PACKAGES
addappid(751221, 1, "a2554af4f40bf0ef0fccf7fa2a1749366360956a0dbde109e3eb85a6dc5a4315")
addappid(751222, 1, "3fdd7a00e0aed9416bbe4e9c9b861bcf6b2ba5cbd4025129ba6a952ca1fa0626")
addappid(751223, 1, "1270ed50b99c6d77a8bfaa52a9290042531f90fd9f88417ef398cd89249b113d")
