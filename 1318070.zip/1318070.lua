-- Lua provided by RyzenAPI
-- Game: AppID 1318070

-- MAIN APPLICATION
addappid(1318070)
-- Game: addappid(1318070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318071, 1, "5dd69996dd7c48a9d8450b70f10dab2a99600fe753fe69413b32b7dcdfaaaa8e")
