-- Lua provided by RyzenAPI
-- Game: Game: AppID 1632330

-- MAIN APPLICATION
addappid(1632330)
-- Game: addappid(1632330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632331, 1, "121cb7616699cd277f9015033696f1dda6b7d98e85fef150a2649c329a9e32f0")
