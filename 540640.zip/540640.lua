-- Lua provided by RyzenAPI
-- Game: Game: AppID 540640

-- MAIN APPLICATION
addappid(540640)
-- Game: addappid(540640)

-- MAIN APP DEPOTS / PACKAGES
addappid(540641, 1, "79b02fc92d282e84ebc8ae86790eeefd8a8ee81d2b77bb6191f04545d28d033f")
addappid(541170, 0, "34b5d498f740551f4157c8f0fb73f1b20993b1ab1f07d15b2a37fd20761391ba")
addappid(779720, 0, "d0adc416cebd4fe36576c16364fa0da18b12b45089a21f718bbbf0de32a7b833")
addappid(781060, 0, "25747ac53d661eeab51527f40a0d823dc9acb3973aba49965e776e9bb9a8bff1")
