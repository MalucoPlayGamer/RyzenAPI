-- Lua provided by RyzenAPI 
-- Game: Anmynor Puzzles
addappid(275330)
addappid(275331, 1, "80fe82b15bb79c774b5474e9d7b6abc04172960d74984f60412592a0a616b94b")
