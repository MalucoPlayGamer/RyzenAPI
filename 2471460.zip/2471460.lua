-- Lua provided by RyzenAPI
-- Game: Game: Copycat Demo

-- MAIN APPLICATION
addappid(2471460)
-- Game: addappid(2471460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471461, 1, "00546d00f03af8574ece619e441c275c447b2052550f472e5df15f1695cc423a")
