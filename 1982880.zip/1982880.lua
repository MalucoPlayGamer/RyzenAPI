-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - World Music Pack Vol.1

-- MAIN APPLICATION
addappid(1982880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982880,0,"19b77a8abe2beedad289c77f1c84437315fd1059d47dcfd31f60f3e8651aebf0")
