-- Lua provided by RyzenAPI
-- Game: Ultra Boat Game!!!

-- MAIN APPLICATION
addappid(1671090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671091, 1, "ae696d2c090a8ba12ce8323507f8fd5e91f0942ef7aee1f2035e7e49da3b8d44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
