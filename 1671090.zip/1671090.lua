-- Lua provided by SkyAPI 
-- Game: Ultra Boat Game!!!
addappid(1671090)
addappid(1671091, 1, "ae696d2c090a8ba12ce8323507f8fd5e91f0942ef7aee1f2035e7e49da3b8d44")
