-- Lua provided by SkyAPI 
-- Game: War Trigger 3
addappid(1210360)
addappid(1210361, 1, "052bf1f9f3c61d539c9890f2cf0bcc833f08876caa758a1b21fc940b7c055956")
addappid(1210362, 1, "0632ccf00ed832e5d816941c5389a68e18ce0930a9bad05bf75cf0faeeddd7e8")
