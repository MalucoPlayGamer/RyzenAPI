-- Lua provided by RyzenAPI
-- Game: RAN: Lost Islands Demo

-- MAIN APPLICATION
addappid(1321670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321671, 1, "4b76284dd805fec94ad7185d442ec522428b65b7a11efaf956e510866f104819")
