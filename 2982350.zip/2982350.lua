-- Lua provided by RyzenAPI
-- Game: AppID 2982350

-- MAIN APPLICATION
addappid(2982350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982351, 1, "f58c0924b1703e2a22e21c1c0a3dd905b313ecd2ba0c1ec5860a35befad6d0ca")
