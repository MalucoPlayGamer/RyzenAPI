-- Lua provided by RyzenAPI
-- Game: Game: Hack and Slash Fury

-- MAIN APPLICATION
addappid(3241030)
-- Game: addappid(3241030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241031, 1, "8374bc23e8ae8a391eb5aca60313106ddff1a301dcf3e226bce74af1e324286f")
