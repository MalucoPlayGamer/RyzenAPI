-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2024 Dataeditor

-- MAIN APPLICATION
addappid(2328800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328801, 1, "6a03ee1594544c3663906e12d235231a1bdd4f9e9ca7c113c030b7538019c4bb")

