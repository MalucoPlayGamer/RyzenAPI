-- Lua provided by RyzenAPI
-- Game: AppID 2542550

-- MAIN APPLICATION
addappid(2542550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2542551, 1, "dfc4288d705b7a01a2b460d39631b6fa9578cbcdb732deda92b57b99fc1587f5")

