-- Lua provided by RyzenAPI 
-- Game: AppID 2323970
addappid(2323970)
addappid(2323971, 1, "91cc6c520d524f56890b22696e3afcd618059619a86ff1091584392c3def1e42")
