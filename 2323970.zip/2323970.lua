-- Lua provided by RyzenAPI
-- Game: 异星前哨 - 工具

-- MAIN APPLICATION
addappid(2323970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323971, 1, "91cc6c520d524f56890b22696e3afcd618059619a86ff1091584392c3def1e42")
