-- Lua provided by RyzenAPI
-- Game: Game: Haven Moon

-- MAIN APPLICATION
addappid(493720)
-- Game: addappid(493720)

-- MAIN APP DEPOTS / PACKAGES
addappid(493721, 1, "4482ab97327d7aef5ca3b5c0e02cb24c50ecb83f1f0300ae72faf135b8e3a4fe")
addappid(493722, 1, "058055148b1f761a16f7efc90897934f33c919fde7a515553533b8149103f758")
addappid(493723, 1, "8756e38c59a9d00eeca1a4ef8733983c2290db4cdb8d4e184e5244353b98b983")
