-- Lua provided by RyzenAPI
-- Game: Idle Aqua Driller

-- MAIN APPLICATION
addappid(4656460) -- Idle Aqua Driller

-- MAIN APP DEPOTS / PACKAGES
addappid(4656461, 1, "f9372046492459503955eeff4fb3d4bcfc49cae0e5c8bb747e17e6ac3a7281c2") -- Depot 4656461

