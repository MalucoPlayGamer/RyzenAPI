-- Lua provided by RyzenAPI
-- Game: 2072280

-- MAIN APPLICATION
addappid(2072280)
-- Game: addappid(2072280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072281, 1, "a3e360007d3f73c94f94d0bd142d00956e44c3998c7b008f86a0bd3e42ed8175")
