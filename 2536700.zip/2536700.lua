-- Lua provided by RyzenAPI
-- Game: Game: 一起放烟花 Demo

-- MAIN APPLICATION
addappid(2536700)
-- Game: addappid(2536700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536701, 1, "128f902a969b30595978c26cc701dbdd5c7ce67ae665a474754a478328e18ea1")
