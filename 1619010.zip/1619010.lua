-- Lua provided by RyzenAPI
-- Game: AppID 1619010

-- MAIN APPLICATION
addappid(1619010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619011, 1, "56679c2d6ebb4022ef53ac1185c5ffda3dff3b178c5dfb930c314c5292f8d5f9")

