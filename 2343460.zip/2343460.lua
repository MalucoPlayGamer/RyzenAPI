-- Lua provided by RyzenAPI
-- Game: addappid(2343460)

-- MAIN APPLICATION
addappid(2343460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343461, 1, "6b6f949e90b4c2b83718cc20ce06c64c23bbb926d2e047cbfcc6e57cf6189d4a")
