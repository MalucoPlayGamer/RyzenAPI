-- Lua provided by RyzenAPI
-- Game: Game: AppID 2851620

-- MAIN APPLICATION
addappid(2851620)
-- Game: addappid(2851620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851621, 1, "428a15a26f6d4886c12124574594a339c4c81f87fc0187eb97b8dc82691cdb57")
