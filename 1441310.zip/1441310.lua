-- Lua provided by RyzenAPI
-- Game: 1441310

-- MAIN APPLICATION
addappid(1441310)
-- Game: addappid(1441310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441311, 1, "13befaccbbe10aa46233bd98c91a4a4e21f407230bdbd8dcf43124db4645057f")
