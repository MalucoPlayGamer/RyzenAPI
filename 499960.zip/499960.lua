-- Lua provided by RyzenAPI
-- Game: Game: AppID 499960

-- MAIN APPLICATION
addappid(499960)
-- Game: addappid(499960)

-- MAIN APP DEPOTS / PACKAGES
addappid(499961, 1, "6a35bbd825e0a2607baa1e04310933708f64b9ce0ef20b5e9364d5505fa844d3")
