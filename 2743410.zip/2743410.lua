-- Lua provided by RyzenAPI 
-- Game: The Echo Paradox
addappid(2743410)
addappid(2743411, 1, "bd66965804727c3e437b1cb4f1e419398b1ecb40e6044401611a8602f502116b")
