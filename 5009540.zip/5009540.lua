-- Lua provided by RyzenAPI
-- Game: Ashfire Keep

-- MAIN APPLICATION
addappid(5009540) -- Ashfire Keep

-- MAIN APP DEPOTS / PACKAGES
addappid(5009541, 1, "46faf5250634dce1c361b248c25429af3181c3dc0c7e4f6d5150fab93004aabd") -- Depot 5009541

