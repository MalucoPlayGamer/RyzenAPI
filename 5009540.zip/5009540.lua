-- 5009540's Lua and Manifest Created by Hubcap Manifest
-- Ashfire Keep
-- Created: August 22, 2026 at 02:04:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5009540) -- Ashfire Keep
-- MAIN APP DEPOTS
addappid(5009541, 1, "46faf5250634dce1c361b248c25429af3181c3dc0c7e4f6d5150fab93004aabd") -- Depot 5009541
setManifestid(5009541, "2952128740853906074", 178281200)