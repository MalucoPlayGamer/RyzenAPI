-- Lua provided by RyzenAPI
-- Game: Created: August 20, 2026 at 04:32:10 EDT

-- MAIN APPLICATION
addappid(4532550) -- 守护我的大火箭

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4532551, 1, "31b16714b622d020aa18d8fe4291bce7150e880f4f50060316f921c590535f39") -- Depot 4532551

