-- Lua provided by RyzenAPI
-- Game: Multi Turret Academy Playtest

-- MAIN APPLICATION
addappid(2425880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425881, 1, "a40d764fa6de8a16f037244f73767adc8951b1238ddb94b95b0bce989a5594c5")

