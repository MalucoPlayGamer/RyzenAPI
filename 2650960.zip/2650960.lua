-- Lua provided by RyzenAPI
-- Game: 2650960

-- MAIN APPLICATION
addappid(2650960)
-- Game: addappid(2650960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650960,0,"c9518cf1afb370234b7e4a9b89de404b3b061c9661ab220010010b4ca06ff30c")
