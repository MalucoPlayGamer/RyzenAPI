-- Lua provided by RyzenAPI
-- Game: addappid(2227220)

-- MAIN APPLICATION
addappid(2227220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227222,0,"342859c62f08a7db3c24fcc56ca51dc600a19631f00a48c4b74ce6dfa9db5e0b")
