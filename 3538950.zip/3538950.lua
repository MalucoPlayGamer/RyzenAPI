-- Lua provided by RyzenAPI
-- Game: KunlunWonderland

-- MAIN APPLICATION
addappid(3538950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538951, 1, "123a18cb2025c332c2b97605a14cf1e6318b51caefd4bdc145e85a8d1c4a4261")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
