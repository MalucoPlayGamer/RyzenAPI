-- Lua provided by RyzenAPI
-- Game: Game: KunlunWonderland

-- MAIN APPLICATION
addappid(3538950)
-- Game: addappid(3538950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538951, 1, "123a18cb2025c332c2b97605a14cf1e6318b51caefd4bdc145e85a8d1c4a4261")
