-- Lua provided by RyzenAPI
-- Game: Mirrors - Tomblight Edition

-- MAIN APPLICATION
addappid(709470)
-- Game: addappid(709470)

-- MAIN APP DEPOTS / PACKAGES
addappid(709471, 1, "bea5f8f36cfdf985c7b39692f90c4b3bd619dbdd4f1dda0eb7bce3218d6cbdc9")
