-- Lua provided by RyzenAPI
-- Game: Dimenders

-- MAIN APPLICATION
addappid(2491620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491621, 1, "a222aaa3735b28c615c1aaa589598ebb62e5b94bfca828548c0fc69b8ff17ffb")
