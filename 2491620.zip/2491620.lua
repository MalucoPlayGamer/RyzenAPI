-- Lua provided by RyzenAPI
-- Game: Dimenders

-- MAIN APPLICATION
addappid(2491620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2491621, 1, "a222aaa3735b28c615c1aaa589598ebb62e5b94bfca828548c0fc69b8ff17ffb")

