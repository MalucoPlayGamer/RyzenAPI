-- Lua provided by RyzenAPI
-- Game: Fight the Landlord

-- MAIN APPLICATION
addappid(1349380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349381, 1, "97eaeb829f3f4ad8a0f2c45cd09b1295018ce7316f5056a9df351707db0e3eec")
addappid(2246500, 0, "f63295d0ab93c0bd45f5bf252a09b41ebf69dd462e78a7392e2228a0533a471d")

