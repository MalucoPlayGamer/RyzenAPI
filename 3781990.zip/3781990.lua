-- Lua provided by RyzenAPI
-- Game: 3781990

-- MAIN APPLICATION
addappid(3781990)
-- Game: addappid(3781990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3781991, 1, "1f17b6f144fdd8ba81a9d44152422dcd5b32773a50c87e09e8eb76017cb612df")
