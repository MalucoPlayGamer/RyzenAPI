-- Lua provided by SkyAPI 
-- Game: AppID 3781990
addappid(3781990)
addappid(3781991, 1, "1f17b6f144fdd8ba81a9d44152422dcd5b32773a50c87e09e8eb76017cb612df")
