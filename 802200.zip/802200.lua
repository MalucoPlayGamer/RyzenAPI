-- Lua provided by RyzenAPI
-- Game: Hellbound: Survival Mode

-- MAIN APPLICATION
addappid(802200)

-- MAIN APP DEPOTS / PACKAGES
addappid(802201, 1, "b0b34d25b4f0cd478de64d00bb17ccc14e9fc1cfaffff444f3b79e0fe9bc9dfc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
