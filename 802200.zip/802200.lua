-- Lua provided by RyzenAPI
-- Game: 802200

-- MAIN APPLICATION
addappid(802200)
-- Game: addappid(802200)

-- MAIN APP DEPOTS / PACKAGES
addappid(802201, 1, "b0b34d25b4f0cd478de64d00bb17ccc14e9fc1cfaffff444f3b79e0fe9bc9dfc")
