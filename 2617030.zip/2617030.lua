-- Lua provided by RyzenAPI
-- Game: Game: Pond Scum: A Gothic Swamp Tale

-- MAIN APPLICATION
addappid(2617030)
-- Game: addappid(2617030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617031, 1, "82c2f53aea80d55ca725d81b4651a0f7449bf2bbf4da6f654037a00022b63d27")
