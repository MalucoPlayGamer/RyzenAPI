-- Lua provided by RyzenAPI
-- Game: Riaaf The Spider

-- MAIN APPLICATION
addappid(647040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(647041, 1, "a64bf5b05cd030962f76fc525b6f545e637e26a9d93d20b697768d7052411f53")

