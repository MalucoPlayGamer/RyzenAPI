-- Lua provided by RyzenAPI
-- Game: Riaaf The Spider

-- MAIN APPLICATION
addappid(647040)

-- MAIN APP DEPOTS / PACKAGES
addappid(647041, 1, "a64bf5b05cd030962f76fc525b6f545e637e26a9d93d20b697768d7052411f53")
