-- Lua provided by SkyAPI 
-- Game: AppID 781220
addappid(781220)
addappid(781221, 1, "cc20e347b6052c716047a40927e91ba4c3c6161f80f50910cbc3fd15b52c1268")
