-- Lua provided by RyzenAPI
-- Game: Mouse (Sneaking)

-- MAIN APPLICATION
addappid(776960)

-- MAIN APP DEPOTS / PACKAGES
addappid(776961, 1, "2761e8a57cef9b26e801a2a365131b8650e99f169fa382c22534a4513d437a47")

