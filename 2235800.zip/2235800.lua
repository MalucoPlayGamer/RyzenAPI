-- Lua provided by RyzenAPI
-- Game: Game: Futapunk 2069

-- MAIN APPLICATION
addappid(2235800)
-- Game: addappid(2235800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235801, 1, "bb9f3d03389c127c8199e5786fe2f2cfa005086cf21eee9dd09b15abf767fe2f")
