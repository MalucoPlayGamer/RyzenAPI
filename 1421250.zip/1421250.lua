-- Lua provided by RyzenAPI
-- Game: Tiny Bunny

-- MAIN APPLICATION
addappid(1421250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421251, 1, "26c7441369eb15b5a36a102139161693464b46afa6f77cc7744ea95f920ece2c")
