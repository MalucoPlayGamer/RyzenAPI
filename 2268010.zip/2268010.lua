-- Lua provided by RyzenAPI
-- Game: Chop Goblins Soundtrack

-- MAIN APPLICATION
addappid(2268010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2268011, 1, "77a0f8dcb84d19194ca3ccf99cf42b503f1573b2e179033eced0fa322c02a5c3")

