-- Lua provided by RyzenAPI
-- Game: Crystar - Anamnesis's Clothes

-- MAIN APPLICATION
addappid(1070052)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070052,0,"e8d57676f6c30aba903ac3e8185d82b040fb70c45d78da07b4d632e4f7d6a19f")

