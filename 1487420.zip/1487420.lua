-- Lua provided by RyzenAPI
-- Game: Wilhelm Gustloff's Death

-- MAIN APPLICATION
addappid(1487420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487421, 1, "2a45aa9a35d90afd44662072b05af7eb7144a1fe01371f81db363b2ffd7cbb70")

