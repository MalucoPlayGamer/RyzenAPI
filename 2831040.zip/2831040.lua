-- Lua provided by RyzenAPI
-- Game: Who am I: Remedy Demo

-- MAIN APPLICATION
addappid(2831040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831041, 1, "3db3b3364ce3caf944037c9350f02b78267687c322265607f6783e34f385b8b2")

