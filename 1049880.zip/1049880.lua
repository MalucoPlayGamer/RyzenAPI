-- Lua provided by SkyAPI 
-- Game: AppID 1049880
addappid(1049880)
addappid(1049881, 1, "9d32df594a0079865a1398d100b44468d0350fec1faa269abdc70159ae58293e")
