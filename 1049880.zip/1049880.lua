-- Lua provided by RyzenAPI
-- Game: My Free Farm

-- MAIN APPLICATION
addappid(1049880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049881, 1, "9d32df594a0079865a1398d100b44468d0350fec1faa269abdc70159ae58293e")

