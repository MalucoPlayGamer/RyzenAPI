-- Lua provided by RyzenAPI
-- Game: 1385810

-- MAIN APPLICATION
addappid(1385810)
-- Game: addappid(1385810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385811, 1, "87acfd1d54b10df13b6309e39df4e6013c340f4e782275489e13263e21fb5b0a")
