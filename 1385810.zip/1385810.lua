-- Lua provided by RyzenAPI
-- Game: Naked Warrior

-- MAIN APPLICATION
addappid(1385810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1385811, 1, "87acfd1d54b10df13b6309e39df4e6013c340f4e782275489e13263e21fb5b0a")

