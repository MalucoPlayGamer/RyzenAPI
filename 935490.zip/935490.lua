-- Lua provided by RyzenAPI
-- Game: 935490

-- MAIN APPLICATION
addappid(935490)
-- Game: addappid(935490)

-- MAIN APP DEPOTS / PACKAGES
addappid(935491, 1, "0ea665642d86210e6ecb9f31207cdbfc59060a94cc7c610705d7c5ec65ebf860")
