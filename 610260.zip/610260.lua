-- Lua provided by RyzenAPI
-- Game: American VR Coasters

-- MAIN APPLICATION
addappid(610260)

-- MAIN APP DEPOTS / PACKAGES
addappid(610261, 1, "4e4779aa590a02bfebb86473380cb85876ff75edc3bc5c35c55e9217ea91c429")

