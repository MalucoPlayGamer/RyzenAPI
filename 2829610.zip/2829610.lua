-- Lua provided by RyzenAPI
-- Game: addappid(2829610)

-- MAIN APPLICATION
addappid(2829610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829611, 1, "71f2624e99baefa4ccdebf05fd006f63557c13fbdb0ce8a4180ad349c3944ff4")
addappid(2829613, 1, "7ac80d66dbdbde542ca70aeb91a26ab291dccdcccdf25c8d8a6b23a07e1fc58e")
