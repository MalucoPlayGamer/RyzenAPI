-- Lua provided by RyzenAPI 
-- Game: Phantasy Series Reference Opus
addappid(2188740)
addappid(2188741, 1, "8fe452a44b979ed339570ef0a27700d97bb1e392cd36d47b997e5dcc0ad64207")
