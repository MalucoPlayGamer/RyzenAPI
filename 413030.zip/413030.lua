-- Lua provided by RyzenAPI
-- Game: Game: Mytheon

-- MAIN APPLICATION
addappid(413030)
addappid(429810)
-- Game: addappid(413030)

-- MAIN APP DEPOTS / PACKAGES
addappid(413031, 1, "b3ee0e2031c774710b4886a09f240564c2f29345991f1e9b7b2805b937558810")
