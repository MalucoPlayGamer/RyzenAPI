-- Lua provided by RyzenAPI
-- Game: Kimono Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1146400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146400,0,"82b6082ab96dbe23e28befd21baa3b4f0d51e5a09ee31dc697d79c8cc66943e8")
