-- Lua provided by RyzenAPI
-- Game: A Rogue Escape

-- MAIN APPLICATION
addappid(1476100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476102,0,"6dbaff76af9d8292108acab8278f1f2e6681c658ae41dc9863a3ec651c533773")
