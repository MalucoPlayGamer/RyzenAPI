-- Lua provided by RyzenAPI
-- Game: 2072420

-- MAIN APPLICATION
addappid(2072420)
-- Game: addappid(2072420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072421, 1, "92a83bae26df4f7e9d68f5543b77c107460ac34b33b96cefa7a152a4c37c6f65")
