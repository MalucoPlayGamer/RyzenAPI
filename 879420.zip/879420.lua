-- Lua provided by SkyAPI 
-- Game: Agony UNRATED
addappid(879420)
addappid(879421, 1, "07316666714041110cc72dafe85b60613d189dffb1974a0da18c8f136bd1d8f7")
