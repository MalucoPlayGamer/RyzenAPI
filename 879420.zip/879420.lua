-- Lua provided by RyzenAPI
-- Game: addappid(879420)

-- MAIN APPLICATION
addappid(879420)

-- MAIN APP DEPOTS / PACKAGES
addappid(879421, 1, "07316666714041110cc72dafe85b60613d189dffb1974a0da18c8f136bd1d8f7")
