-- Lua provided by RyzenAPI 
-- Game: Basault VR
addappid(1823830)
addappid(1823831, 1, "7537c39029616744c2b745e13e81595ca47efe2540152f462f1efdbe9a12e88c")
