-- Lua provided by RyzenAPI
-- Game: Game: Basault VR

-- MAIN APPLICATION
addappid(1823830)
-- Game: addappid(1823830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823831, 1, "7537c39029616744c2b745e13e81595ca47efe2540152f462f1efdbe9a12e88c")
