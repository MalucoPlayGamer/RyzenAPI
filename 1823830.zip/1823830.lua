-- Lua provided by RyzenAPI
-- Game: Basault VR

-- MAIN APPLICATION
addappid(1823830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823831, 1, "7537c39029616744c2b745e13e81595ca47efe2540152f462f1efdbe9a12e88c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
