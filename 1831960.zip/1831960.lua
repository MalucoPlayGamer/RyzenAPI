-- Lua provided by RyzenAPI
-- Game: 1831960

-- MAIN APPLICATION
addappid(1831960)
-- Game: addappid(1831960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831961, 1, "8068ed0148a84ed6c281cdb9bb676340a40c15d4e8afc261f3f37ca889f04e2c")
