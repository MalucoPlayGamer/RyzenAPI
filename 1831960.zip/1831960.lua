-- Lua provided by RyzenAPI
-- Game: 烈火冲锋The charge is the fire

-- MAIN APPLICATION
addappid(1831960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831961, 1, "8068ed0148a84ed6c281cdb9bb676340a40c15d4e8afc261f3f37ca889f04e2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
