-- Lua provided by RyzenAPI
-- Game: Game of Thrones - A Telltale Games Series

-- MAIN APPLICATION
addappid(330840)

-- MAIN APP DEPOTS / PACKAGES
addappid(330841, 1, "45a330a980b21b6b4fe1a509f26a559e7353699158c3d475cd2a5b360f3a7eef")
addappid(330842, 1, "df56dd8d32dfd0ba48c0e95ba1f797af8520829b1d5aa1e9049af132496becf1")
addappid(330843, 1, "0198fd050b82c796ca1a0b2f67d7a1c766530964191974528d51282843662006")
addappid(330844, 1, "c35372e821ce9dc6a55297be74fe0571e6a2dc81b68a1d1f8de877c447cedd7a")
addappid(330845, 1, "7918309395c8dcd3b6cd83dc310b45d3cd9af15485625e657243da9336649785")
addappid(330847, 1, "996e5c6640f8b5615d98b08714c9ad2cebcfe18e6b857c300a3be4b578c1df08")
addappid(330849, 1, "5090f37f9dede7ca818faa2b274cc5437d7b823f0a2a340642bc9bb14bc7c628")
addappid(371751, 0, "1206be87468b787669f26fcc172cccb46dac2dcfedcca5b20f894b29ef3bbb19")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
