-- Lua provided by RyzenAPI
-- Game: addappid(2366030)

-- MAIN APPLICATION
addappid(2366030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366031, 1, "adb5d077bac78e8c5f02677187dcf8697b747ae272cb2ad5db786a4e333f4596")
