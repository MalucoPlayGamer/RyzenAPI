-- Lua provided by RyzenAPI
-- Game: Watch Me Jump

-- MAIN APPLICATION
addappid(698770)

-- MAIN APP DEPOTS / PACKAGES
addappid(796850,0,"3dcf359c404a6017be6c68de2ac050cb4a07553c1b5e8353c73ed1cf6b39086a")
