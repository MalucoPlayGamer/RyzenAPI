-- Lua provided by RyzenAPI
-- Game: Ski Hard: Lorsbruck 1978

-- MAIN APPLICATION
addappid(698410)

-- MAIN APP DEPOTS / PACKAGES
addappid(698412,0,"c2cc6996aaa19d4a8a039951040fbd06d897ca62f2a6e29d41ce4388aa9742a9")

