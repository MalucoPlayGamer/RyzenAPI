-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1883800)
addappid(1883801)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883802,0,"6b0b8e9be22318f633fe958c5fb53889604b1f01905129a73c315bf7b69f5a84")

