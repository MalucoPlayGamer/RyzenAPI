-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1883800)
addappid(1883801)
addappid(1883802,0,"6b0b8e9be22318f633fe958c5fb53889604b1f01905129a73c315bf7b69f5a84")
-- setManifestid(1883802,"6101175457262355980")