-- Lua provided by RyzenAPI
-- Game: War Tech Fighters

-- MAIN APPLICATION
addappid(630030)

-- MAIN APP DEPOTS / PACKAGES
addappid(630031, 1, "9ecaa4ad0dbc848f95540ebe2073644ef30dff6875b6c6d90953037e56f305fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
