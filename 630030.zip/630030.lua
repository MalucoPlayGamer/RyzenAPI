-- Lua provided by RyzenAPI
-- Game: addappid(630030)

-- MAIN APPLICATION
addappid(630030)

-- MAIN APP DEPOTS / PACKAGES
addappid(630031, 1, "9ecaa4ad0dbc848f95540ebe2073644ef30dff6875b6c6d90953037e56f305fb")
