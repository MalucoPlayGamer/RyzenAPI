-- Lua provided by RyzenAPI
-- Game: addappid(1153070)

-- MAIN APPLICATION
addappid(1153070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153071, 1, "f00723ef8cca941946c73c76b2edc6cc888769f0b6f759cee1fb178e20e8ee46")
