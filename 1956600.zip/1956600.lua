-- Lua provided by RyzenAPI
-- Game: Game: Yusetsu

-- MAIN APPLICATION
addappid(1956600)
-- Game: addappid(1956600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956601, 1, "9bb0762a66fb0500a17d6c9ec6db35ea7f9d98adc3fcf77851f87b3c99d8bba6")
addappid(2095530, 0, "326526d579e8e8dd232e4c114c989e866d14949d7c82c7a7b67cc6e153f09dcf")
