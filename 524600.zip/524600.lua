-- Lua provided by RyzenAPI
-- Game: Dark Parables: Curse of Briar Rose Collector's Edition

-- MAIN APPLICATION
addappid(524600)

-- MAIN APP DEPOTS / PACKAGES
addappid(524601, 1, "0585928abb73c5973e54ea5db1f9870eed2d08961f386845c745b08d8879f6ee")

