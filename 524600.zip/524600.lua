-- Lua provided by SkyAPI 
-- Game: AppID 524600
addappid(524600)
addappid(524601, 1, "0585928abb73c5973e54ea5db1f9870eed2d08961f386845c745b08d8879f6ee")
