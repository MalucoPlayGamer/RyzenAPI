-- Lua provided by RyzenAPI
-- Game: Game: AppID 460660

-- MAIN APPLICATION
addappid(460660)
-- Game: addappid(460660)

-- MAIN APP DEPOTS / PACKAGES
addappid(460661, 1, "afec94bf22ab012df8697d608fcff9d09cb573d890a72c3ded11cfbb2f0d24c6")
