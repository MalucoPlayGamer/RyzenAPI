-- Lua provided by RyzenAPI
-- Game: 1930730

-- MAIN APPLICATION
addappid(1930730)
-- Game: addappid(1930730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930731, 1, "56fa928028241e012618909f4ac07bc6b9396594aded9ca7f8dbcac7e47d6204")
