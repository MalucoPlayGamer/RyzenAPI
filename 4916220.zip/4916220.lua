-- Lua provided by RyzenAPI
-- Game: The Legend of Fireball

-- MAIN APPLICATION
addappid(4916220)
