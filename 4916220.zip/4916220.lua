-- Lua provided by RyzenAPI
-- Game: The Legend of Fireball

-- MAIN APPLICATION
addappid(4916220)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4943940)
addappid(4943960)
