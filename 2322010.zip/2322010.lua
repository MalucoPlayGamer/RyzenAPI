-- Lua provided by RyzenAPI
-- Game: 2322010

-- MAIN APPLICATION
addappid(2322010)
addappid(2974310)
addappid(2974320)
addappid(2974330)
-- Game: addappid(2322010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322011, 1, "78758c85a2a8b04770fb4fe430ac7a215a959b72e496d94f6a0ec5ac38066f49")
addappid(2974340, 0, "b54ec4dbd1528067329c6ce102d3dc0501401e41b08a6cabc0c947d0c9541baf")
