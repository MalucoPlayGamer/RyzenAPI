-- Lua provided by RyzenAPI
-- Game: addappid(2995330)

-- MAIN APPLICATION
addappid(2995330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2995331, 1, "6890c77052dc8d958d2e4c17b0e650b771a286c2c5e97b792e447e15cf18d7bf")
