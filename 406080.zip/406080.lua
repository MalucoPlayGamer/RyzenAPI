-- Lua provided by RyzenAPI
-- Game: Game: Ant War: Domination

-- MAIN APPLICATION
addappid(406080)
-- Game: addappid(406080)

-- MAIN APP DEPOTS / PACKAGES
addappid(406081, 1, "61d440499f4e479c10da340cc568da772f4e4d839ce9edbeb08dc7c928865f83")
addappid(406082, 1, "9759a00ee94090d44cc2caf69f137fe6c2a72d39d51038a435f52945e8f942b2")
addappid(406083, 1, "d8a541e0509a6c8c748792ab4751e6c110b1577897631262bbad8568811014bf")
