-- Lua provided by RyzenAPI
-- Game: Goosebumps Dead of Night

-- MAIN APPLICATION
addappid(1173150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173151, 1, "2cf1491257d6f4906cdea5f06b615e203975e5685c2d882985a53f3c63dc2007")
