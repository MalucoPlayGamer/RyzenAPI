-- Lua provided by RyzenAPI
-- Game: Game: AppID 1043810

-- MAIN APPLICATION
addappid(1043810)
-- Game: addappid(1043810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043811, 1, "e49b8531e1cc3d1b3405a44cee14b159a511a1029ac6196e292b1b28248e70be")
addappid(3065010, 0, "dc826393ba0e3e8e0f85b6d81a54497c2a2e0f25315c25fae7853ce69b7459df")
