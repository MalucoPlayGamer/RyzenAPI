-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic the Arrival of Spring ALL in Pack

-- MAIN APPLICATION
addappid(2848600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848601, 1, "0c7278d33c5d243b6a0bb4b1f030e196202c107c899e4c4a36226f34725b9918")

