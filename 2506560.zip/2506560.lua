-- Lua provided by RyzenAPI
-- Game: AppID 2506560

-- MAIN APPLICATION
addappid(2506560)
-- Game: addappid(2506560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506561, 1, "6b28689052c911e49b7f140e2f5c0534924aaea9bad8e40cf4d18ca554bc23af")
