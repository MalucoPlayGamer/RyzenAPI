-- Lua provided by RyzenAPI
-- Game: 3384090

-- MAIN APPLICATION
addappid(3384090)
-- Game: addappid(3384090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3384091, 1, "8e7d091643c1da41e472797ecce9727787cc911d99a7af6f1004025cb7d62ed3")
