-- Lua provided by RyzenAPI
-- Game: Plastic Battlegrounds

-- MAIN APPLICATION
addappid(3384090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3384091, 1, "8e7d091643c1da41e472797ecce9727787cc911d99a7af6f1004025cb7d62ed3")

