-- Lua provided by SkyAPI 
-- Game: Onmyoji：the card game
addappid(2183390)
addappid(2183391, 1, "a76a03fb326edd8698728d4223ef1434a2787d093939e14d68eb984fd9752652")
