-- Lua provided by RyzenAPI
-- Game: Onmyoji：the card game

-- MAIN APPLICATION
addappid(2183390)
-- Game: addappid(2183390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183391, 1, "a76a03fb326edd8698728d4223ef1434a2787d093939e14d68eb984fd9752652")
