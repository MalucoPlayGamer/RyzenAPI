-- Lua provided by RyzenAPI
-- Game: DOORMS

-- MAIN APPLICATION
addappid(3336800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3336801, 1, "fb0c1810e59ed85319693f58443a4df0ebfb07ecb95e6e658f274b6ea8c0da11")
