-- Lua provided by RyzenAPI
-- Game: Into the Nightmare

-- MAIN APPLICATION
addappid(1551560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551561, 1, "0ddd4520a10d8a8826c53bf1affb96491e0980a9208ab674d2aecd874d3bc5b9")
addappid(1551562, 1, "3ca0b57a1e5f8baec91decd1446d7ecad24d2708215f92421ae5bd2a2b11516c")
addappid(1551563, 1, "d0b225c70d7879b927f59d6f7c66eff97979af7001bed59e93932ab758659dee")

