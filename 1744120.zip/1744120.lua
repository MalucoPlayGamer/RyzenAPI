-- Lua provided by RyzenAPI
-- Game: Cannibals

-- MAIN APPLICATION
addappid(1744120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744121, 1, "3ae4780ebea24f67c2580df548c1f010411482e74852343fa6eb5a788f4237ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
