-- Lua provided by RyzenAPI
-- Game: Cannibals

-- MAIN APPLICATION
addappid(1744120)
-- Game: addappid(1744120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744121, 1, "3ae4780ebea24f67c2580df548c1f010411482e74852343fa6eb5a788f4237ee")
