-- Lua provided by RyzenAPI
-- Game: Yusha Prototype -Family Friendly- Demo

-- MAIN APPLICATION
addappid(2571080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571081, 1, "ca6ea09668f1e9b3145bb744634e5f4aacf4654649f683f4e459f164ea5445be")

