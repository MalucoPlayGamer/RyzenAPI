-- Lua provided by RyzenAPI
-- Game: 1117930

-- MAIN APPLICATION
addappid(1117930)
-- Game: addappid(1117930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117931, 1, "c0dc37cff53e71fb8d1d6a4992f65966cbf31addfa338ba1125bc5166424bdf3")
