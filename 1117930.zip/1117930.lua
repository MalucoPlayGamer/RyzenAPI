-- Lua provided by RyzenAPI
-- Game: Wonder Blade

-- MAIN APPLICATION
addappid(1117930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117931, 1, "c0dc37cff53e71fb8d1d6a4992f65966cbf31addfa338ba1125bc5166424bdf3")
