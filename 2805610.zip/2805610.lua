-- Lua provided by RyzenAPI 
-- Game: Just skill shooter 3: 2d edition
addappid(2805610)
addappid(2805611, 1, "d992b0dc6e3935d1e8a54ff28d1cdaf6e7da269d9b008fd341494f9ab350a323")
