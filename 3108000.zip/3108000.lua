-- Lua provided by RyzenAPI
-- Game: Only Trump: Up To Presidents!

-- MAIN APPLICATION
addappid(3108000)
-- Game: addappid(3108000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108001, 1, "e47efff0f15dfb3abd1424ea44b291672bbb059cdc8007e2597f597834f91dbd")
