-- Lua provided by RyzenAPI
-- Game: FUSER™ - Fleetwood Mac - "Dreams"

-- MAIN APPLICATION
addappid(1598245)
-- Game: addappid(1598245)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598245,0,"12ad5a69d129bd76066d1d3d0583bbb98ba55a1cbc0f192f9a6f6ec6ce9b2853")
