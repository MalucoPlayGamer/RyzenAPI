-- Lua provided by RyzenAPI
-- Game: Taboos: Flower

-- MAIN APPLICATION
addappid(1082240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082241, 1, "b81fc48b0ca782839f5b2a9779395269735f64123eb8ae382c0c58e6f324a663")

