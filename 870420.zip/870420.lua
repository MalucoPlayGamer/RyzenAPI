-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor 14 Plus

-- MAIN APPLICATION
addappid(870420)
addappid(900240)
addappid(900242)
addappid(914661)
addappid(914662)

-- MAIN APP DEPOTS / PACKAGES
addappid(870421, 1, "244f1ccebf6b74d0ee5ed37df994bff92d9d6ac6704f1143be04a3a8842eae42")

