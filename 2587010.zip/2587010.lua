-- Lua provided by RyzenAPI 
-- Game: Road Motorcycle
addappid(2587010)
addappid(2587011, 1, "c097aa2a8984845b4a9007248cf49f38007cdec6c94461fc1a3e969d5f283130")
