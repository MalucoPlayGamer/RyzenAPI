-- Lua provided by RyzenAPI
-- Game: World of Warships Public Test

-- MAIN APPLICATION
addappid(1248250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248251, 1, "f360bb9f05513cb3b72618ee4270b51f15ace1baeae5ae0b805ddbb8ab0fa870")
addappid(1248252, 1, "fb2b54604edbe7e221f40633dda33d9935201ac56af7d8ea78f6261fbfb29aa6")
addappid(1248254, 1, "bca3c382c7010fb2776e9b50a3e94c49472f88d88d4a8a8ff025b19c971e629b")
addappid(1248256, 1, "05cfe20d92fc0b8b3a6abf194bde266df219f5ac646434956dd77f9ac7e79cd3")

