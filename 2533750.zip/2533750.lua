-- Lua provided by SkyAPI 
-- Game: AppID 2533750
addappid(2533750)
addappid(2533751, 1, "bf13c9cbbe1c35d3918f4f444e68567a7d60fdcab0e1c9082a98355f1a2a86c3")
