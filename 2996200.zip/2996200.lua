-- Lua provided by RyzenAPI 
-- Game: AppID 2996200
addappid(2996200)
addappid(2996201, 1, "f849746ab905312fb50a99b0c2d4b22643c99fa0b20432712ef4810b21d3a40b")
