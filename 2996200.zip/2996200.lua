-- Lua provided by RyzenAPI
-- Game: 勾八狂想曲(J8 Fantasy)

-- MAIN APPLICATION
addappid(2996200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996201, 1, "f849746ab905312fb50a99b0c2d4b22643c99fa0b20432712ef4810b21d3a40b")

