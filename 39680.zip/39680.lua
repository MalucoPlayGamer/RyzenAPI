-- Lua provided by RyzenAPI
-- Game: The Guild II Renaissance

-- MAIN APPLICATION
addappid(39680)
addappid(229002)
-- Game: addappid(39680)

-- MAIN APP DEPOTS / PACKAGES
addappid(39681, 1, "975383d58b0ddd680efabeda8bf2f06d7bad3f1cf18eccb6e8a239e8b779b71e")
addappid(39682, 1, "0de584b38e9b48bb36524a4702c3f15fd4640d443877b838c9dc9bdc6821c298")
addappid(39683, 1, "8cd94368fd8268aab3b06f7b4d59f2021ba16754936d041e51b4ed103e756134")
addappid(39684, 1, "258e4b54a0fddf623f3e61752b655331fe7c8a6139799da47ec9675b1fc70bc8")
addappid(39685, 1, "4b823399fa41a1509f1fceab0fe93e63e7395bb48e4b32aaf579a956cd47ca81")
