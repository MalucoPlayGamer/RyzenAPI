-- Lua provided by RyzenAPI
-- Game: Gulf of Aden - Task Force Somalia

-- MAIN APPLICATION
addappid(407100)

-- MAIN APP DEPOTS / PACKAGES
addappid(407101, 1, "cab605643e196126d03da0bf8047f882ab8c0451700dff0c52a23f99b83dce48")
