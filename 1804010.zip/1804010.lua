-- Lua provided by SkyAPI 
-- Game: Labyrinth Of The Demon King
addappid(1804010)
addappid(1804011, 1, "9e2dda820fdffc53cc3820a3315777e79e7ce3789f88843cea754bca4b09a897")
