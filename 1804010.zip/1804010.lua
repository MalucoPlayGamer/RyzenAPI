-- Lua provided by RyzenAPI
-- Game: Labyrinth Of The Demon King

-- MAIN APPLICATION
addappid(1804010)
-- Game: addappid(1804010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804011, 1, "9e2dda820fdffc53cc3820a3315777e79e7ce3789f88843cea754bca4b09a897")
