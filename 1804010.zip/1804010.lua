-- Lua provided by RyzenAPI
-- Game: Labyrinth Of The Demon King

-- MAIN APPLICATION
addappid(1804010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1804011, 1, "9e2dda820fdffc53cc3820a3315777e79e7ce3789f88843cea754bca4b09a897")

