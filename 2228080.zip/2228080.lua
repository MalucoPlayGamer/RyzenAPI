-- Lua provided by RyzenAPI
-- Game: addappid(2228080)

-- MAIN APPLICATION
addappid(2228080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2228081, 1, "a8eb895830b4df208ef5f939e9623b8bc344c19ff0d72e7a09e72ccaca9b6c20")
