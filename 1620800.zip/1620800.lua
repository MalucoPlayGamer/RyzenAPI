-- Lua provided by RyzenAPI
-- Game: Game: Helix

-- MAIN APPLICATION
addappid(1620800)
-- Game: addappid(1620800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620801, 1, "366007cc7bea76d1f6c2b3e91ab67471f88a4ab5de55df5e109420c99e340f58")
