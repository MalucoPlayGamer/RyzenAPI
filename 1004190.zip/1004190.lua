-- Lua provided by RyzenAPI
-- Game: Game: Flowers in Dark

-- MAIN APPLICATION
addappid(1004190)
-- Game: addappid(1004190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004191, 1, "e0ba6abdfcc363093e08b113ae1b11ce10deaa3978090e01d444cdb16b0722b3")
addappid(1004193, 1, "069ccddd174913cae6756e50436ca4db8836fb6d64c4e4c90022ce38aca3b436")
