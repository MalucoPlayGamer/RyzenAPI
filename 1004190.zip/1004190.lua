-- 1004190's Lua and Manifest Created by Hubcap Manifest
-- Flowers in Dark
-- Created: March 16, 2026 at 13:23:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(1004190) -- Flowers in Dark
-- MAIN APP DEPOTS
addappid(1004191, 1, "e0ba6abdfcc363093e08b113ae1b11ce10deaa3978090e01d444cdb16b0722b3") -- Flowers in Dark Content
setManifestid(1004191, "3618243675379133496", 107819141)
addappid(1004192, 1, "57cea68fc6823ab48eeb8c9c4396e1966826bdc6b224b1b1ce788c6e9c88d847") -- Flowers in Dark cn
setManifestid(1004192, "8046966747585538352", 107819141)
addappid(1004193, 1, "069ccddd174913cae6756e50436ca4db8836fb6d64c4e4c90022ce38aca3b436") -- Flowers in Dark xi
setManifestid(1004193, "925113958820363063", 1279438589)
addappid(1004194, 1, "945da369b5240e3a25d3eeb5cf4accf4750686ae363e31d24f7a3dd23ad505e0") -- Flowers in Dark en
setManifestid(1004194, "1447762353399711474", 107826070)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1007110) -- Flowers in Dark - Reward 1
addappid(1007111) -- Flowers in Dark - Reward 2
addappid(1007112) -- Flowers in Dark - Reward 3
addappid(1007113) -- Flowers in Dark - Reward 5