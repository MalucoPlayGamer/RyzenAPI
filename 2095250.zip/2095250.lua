-- Lua provided by RyzenAPI
-- Game: LASER LAB

-- MAIN APPLICATION
addappid(2095250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095251, 1, "60f9b9d8e83a87337cd375400dffbb459ffbae1fa033a3f700f4d8b515c6239b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
