-- Lua provided by RyzenAPI
-- Game: 2095250

-- MAIN APPLICATION
addappid(2095250)
-- Game: addappid(2095250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095251, 1, "60f9b9d8e83a87337cd375400dffbb459ffbae1fa033a3f700f4d8b515c6239b")
