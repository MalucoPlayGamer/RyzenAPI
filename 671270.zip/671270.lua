-- Lua provided by RyzenAPI
-- Game: addappid(671270)

-- MAIN APPLICATION
addappid(671270)

-- MAIN APP DEPOTS / PACKAGES
addappid(671271, 1, "f72fc0ea0303e30ec880813e8f2d39fed4b74b87fa884ab4c63c02533065fdeb")
