-- Lua provided by RyzenAPI 
-- Game: AppID 737230
addappid(737230)
addappid(737231, 1, "044e36ac375ec2425b8ec993111398584f755c575bce758d223f20aa1d874174")
