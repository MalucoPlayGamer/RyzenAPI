-- Lua provided by RyzenAPI
-- Game: WATERPUNK

-- MAIN APPLICATION
addappid(3859430) -- WATERPUNK

-- MAIN APP DEPOTS / PACKAGES
addappid(3859431, 1, "ca01977da86966bf89bfa3200bfac4536ab069f29bc7a99b5744ecbdd9baac19") -- Depot 3859431
addappid(3859432, 1, "ebc76c22b01e14dc40afebbeceebea2005b7a91b2dcda9f11dec600800ac316e") -- Depot 3859432

