-- 3859430's Lua and Manifest Created by Hubcap Manifest
-- WATERPUNK
-- Created: August 01, 2026 at 00:00:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3859430) -- WATERPUNK
-- MAIN APP DEPOTS
addappid(3859431, 1, "ca01977da86966bf89bfa3200bfac4536ab069f29bc7a99b5744ecbdd9baac19") -- Depot 3859431
setManifestid(3859431, "3455677106506031789", 101459720)
addappid(3859432, 1, "ebc76c22b01e14dc40afebbeceebea2005b7a91b2dcda9f11dec600800ac316e") -- Depot 3859432
setManifestid(3859432, "661532411711159319", 391324240)