-- Lua provided by RyzenAPI
-- Game: Aura: Fate of the Ages

-- MAIN APPLICATION
addappid(65500)
-- Game: addappid(65500)

-- MAIN APP DEPOTS / PACKAGES
addappid(65501, 1, "ea6f598e7210c5eeb2977bd2a7c6784485b0495c96900d6ea5594788e2445754")
addappid(65502, 1, "260948f55e027aae18399ca95a7c23fc16626a1a8ca8d97e8c09f42babe22721")
addappid(65503, 1, "7bf47758fd25c378e23c40663e7f8221d268bd297d46f9fd097eaf5a53cc68bf")
addappid(65504, 1, "9accdc1c67dd6a014ff1c7096a76c1eb4071ab4ffc1efd56e0d1c34949b5cc19")
addappid(65505, 1, "958c9bf2cb8b64af6d779d737a5d618ae022275377bdc22db18146429c20c870")
