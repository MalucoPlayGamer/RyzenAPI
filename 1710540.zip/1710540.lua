-- Lua provided by RyzenAPI
-- Game: Fall of Porcupine

-- MAIN APPLICATION
addappid(1710540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1710541, 1, "a17189c793fe364ad1f3e37da8816994fd4ac68f21be32a86c095d6d2bab585f")

