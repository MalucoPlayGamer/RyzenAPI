-- Lua provided by RyzenAPI
-- Game: 1710540

-- MAIN APPLICATION
addappid(1710540)
-- Game: addappid(1710540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710541, 1, "a17189c793fe364ad1f3e37da8816994fd4ac68f21be32a86c095d6d2bab585f")
