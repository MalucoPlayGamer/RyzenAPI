-- Lua provided by RyzenAPI 
-- Game: Fall of Porcupine
addappid(1710540)
addappid(1710541, 1, "a17189c793fe364ad1f3e37da8816994fd4ac68f21be32a86c095d6d2bab585f")
