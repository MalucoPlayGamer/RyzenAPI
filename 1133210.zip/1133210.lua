-- Lua provided by RyzenAPI 
-- Game: AppID 1133210
addappid(1133210)
addappid(1133211, 1, "8b4f46820499ba3e555da6175158c36cb9ce7abc5601189135a4b6070e9dd8ab")
addappid(1133212, 1, "815e592b23ec86b45013cd286af312f4f646b852eee34ee56ccb2a14967042a3")
