-- Lua provided by RyzenAPI
-- Game: addappid(9930)

-- MAIN APPLICATION
addappid(9930)

-- MAIN APP DEPOTS / PACKAGES
addappid(9931, 1, "975f0399bf8cf91952a032a4491a2604c74a88dab7dcce78f28732f2b6ea2a8a")
