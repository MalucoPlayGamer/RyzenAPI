-- Lua provided by RyzenAPI
-- Game: addappid(3255990)

-- MAIN APPLICATION
addappid(3255990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255991, 1, "e7100be98fdb584187d7f64adbbc9fc29d4234b43353bc5d37a4ff49f5fdf7e5")
