-- Lua provided by RyzenAPI
-- Game: Up Left Out

-- MAIN APPLICATION
addappid(867380)
addappid(867381)
addappid(867383)
-- Game: addappid(867380)

-- MAIN APP DEPOTS / PACKAGES
addappid(867382,0,"1b6a7a46c7dd961a32aed6bc8205a63adda7122507bad0c0a29c394bb6363702")
