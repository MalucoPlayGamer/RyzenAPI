-- Lua provided by RyzenAPI
-- Game: The Lamplighters League

-- MAIN APPLICATION
addappid(1167750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167751, 1, "3cdc036d6f075665343ce9470b131f2947183a72097cdf5b73d3a5f3c9176388")
addappid(2244712, 0, "2e0164af9ababb1d47325d93a2f053b76aaa36b4e8a0a9b23b4b080a89797c56")
