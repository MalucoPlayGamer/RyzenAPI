-- Lua provided by RyzenAPI
-- Game: Big Helmet Heroes

-- MAIN APPLICATION
addappid(2397250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397251, 1, "6068937c03539ca8d38b46d48a053c01df7c3f0640ee8ce795ee6a0eacba5d54")
addappid(3417620, 0, "015c0e9a0ff527b6f52c43e37ea09267bb83bb52536a2ea226e9fd0249fba4e1")
addappid(3493570, 0, "c40723bd66defd32de0ca028373a887c003ae3052c1c2f7adcafcb5e76279bb1")

