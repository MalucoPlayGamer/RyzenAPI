-- Lua provided by RyzenAPI
-- Game: Milford Heaven - Luken's Chronicles

-- MAIN APPLICATION
addappid(485570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(485571, 1, "faad9989448d8ecec07a3625d474dd13d03ae909c6e8ca0c70d6362197c3bf8e")

