-- Lua provided by RyzenAPI
-- Game: addappid(485570)

-- MAIN APPLICATION
addappid(485570)

-- MAIN APP DEPOTS / PACKAGES
addappid(485571, 1, "faad9989448d8ecec07a3625d474dd13d03ae909c6e8ca0c70d6362197c3bf8e")
