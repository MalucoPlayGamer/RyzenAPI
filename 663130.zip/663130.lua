-- Lua provided by RyzenAPI
-- Game: Game Tengoku CruisinMix Special

-- MAIN APPLICATION
addappid(663130)

-- MAIN APP DEPOTS / PACKAGES
addappid(663131, 1, "7b01175f7c4304d84149ae54bd226e15b0d8bb8b11552669813e997d094c3e6d")

