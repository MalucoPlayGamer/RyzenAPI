-- Lua provided by SkyAPI 
-- Game: Game Tengoku CruisinMix Special
addappid(663130)
addappid(663131, 1, "7b01175f7c4304d84149ae54bd226e15b0d8bb8b11552669813e997d094c3e6d")
