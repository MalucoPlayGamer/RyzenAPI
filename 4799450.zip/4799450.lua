-- 4799450's Lua and Manifest Created by Hubcap Manifest
-- Kingdoms vs Zombies
-- Created: August 14, 2026 at 13:46:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4799450) -- Kingdoms vs Zombies
-- MAIN APP DEPOTS
addappid(4799451, 1, "cdb017c74db5edee806c8b5011e8f07940e2c134ba677e73006ba12a8ee0f50b") -- Depot 4799451
setManifestid(4799451, "2302201694533772784", 369941364)