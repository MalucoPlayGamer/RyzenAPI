-- Lua provided by RyzenAPI
-- Game: Kingdoms vs Zombies

-- MAIN APPLICATION
addappid(4799450) -- Kingdoms vs Zombies

-- MAIN APP DEPOTS / PACKAGES
addappid(4799451, 1, "cdb017c74db5edee806c8b5011e8f07940e2c134ba677e73006ba12a8ee0f50b") -- Depot 4799451

