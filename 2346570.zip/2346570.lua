-- Lua provided by RyzenAPI
-- Game: Game: Songs of Life

-- MAIN APPLICATION
addappid(2346570)
-- Game: addappid(2346570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346571, 1, "9947669400a36595569a10a4899eed36ecf737127209b0f7643df3aa04f8221d")
