-- Lua provided by RyzenAPI
-- Game: Songs of Life

-- MAIN APPLICATION
addappid(2346570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2346571, 1, "9947669400a36595569a10a4899eed36ecf737127209b0f7643df3aa04f8221d")

