-- Lua provided by RyzenAPI
-- Game: addappid(312430)

-- MAIN APPLICATION
addappid(312430)

-- MAIN APP DEPOTS / PACKAGES
addappid(312431, 1, "f4035103c1578bc6146d2110f7b5122ad0315037dd9c0904fb75ffa5b46f8b51")
