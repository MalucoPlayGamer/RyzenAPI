-- Lua provided by RyzenAPI
-- Game: AppID 2545630

-- MAIN APPLICATION
addappid(2545630)
-- Game: addappid(2545630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545631, 1, "5ab7cb66b7844e78a385977beb93125242c6c24e8634f6ea4e759baad95cbd06")
