-- Lua provided by RyzenAPI
-- Game: VConnect

-- MAIN APPLICATION
addappid(4818300) -- VConnect

-- MAIN APP DEPOTS / PACKAGES
addappid(4818301, 1, "eeca7634aa559707b2322b943a878e17fec135f3ccdc2a6ee2b67ff9c7b00b4c") -- Depot 4818301
addappid(4818302, 1, "ab2ff28583ad2482a5cfa1dfb8a1cc52f8e9d0faeb213418c8bfa1bc4cb47e7f") -- Depot 4818302

