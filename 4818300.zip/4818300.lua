-- 4818300's Lua and Manifest Created by Hubcap Manifest
-- VConnect
-- Created: August 08, 2026 at 07:57:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4818300) -- VConnect
-- MAIN APP DEPOTS
addappid(4818301, 1, "eeca7634aa559707b2322b943a878e17fec135f3ccdc2a6ee2b67ff9c7b00b4c") -- Depot 4818301
setManifestid(4818301, "1109250276889846088", 214927297)
addappid(4818302, 1, "ab2ff28583ad2482a5cfa1dfb8a1cc52f8e9d0faeb213418c8bfa1bc4cb47e7f") -- Depot 4818302
setManifestid(4818302, "90408840437763017", 201779727)