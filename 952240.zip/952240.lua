-- Lua provided by RyzenAPI
-- Game: AppID 952240

-- MAIN APPLICATION
addappid(952240)
-- Game: addappid(952240)

-- MAIN APP DEPOTS / PACKAGES
addappid(952241, 1, "abf6348cb6c1a5f13543599bb4cdc340018fa0bb831fedda53dcf983adad3926")
