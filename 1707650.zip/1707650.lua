-- Lua provided by RyzenAPI
-- Game: Swords and Sandals Immortals

-- MAIN APPLICATION
addappid(1707650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707651, 1, "d4c47759482306bc49484581e2f05e0037b354ead40d547e9d4e8e46791d970a")

