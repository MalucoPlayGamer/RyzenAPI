-- Lua provided by RyzenAPI
-- Game: Alienzix

-- MAIN APPLICATION
addappid(685230)
-- Game: addappid(685230)

-- MAIN APP DEPOTS / PACKAGES
addappid(685231, 1, "d9c59c3b3593294cdbc873caebadee0e108db0e45ca41ce822461ae6f7f382a7")
