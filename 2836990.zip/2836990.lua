-- Lua provided by RyzenAPI
-- Game: Drunken Rogue

-- MAIN APP DEPOTS / PACKAGES
addappid(2836990, 1, "b9e2c7d43bac6e55110dbb5d2f37844f2397990f504ac3bf658f3c3a3594029b") -- Drunken Rogue
addappid(2836991, 1, "9872bc33f15541cbb6a3c6b1ab7e2b6a8d983d50eef4c4717f1ae3ba34cd8d37") -- Depot 2836991

