-- 2836990's Lua and Manifest Created by Hubcap Manifest
-- Drunken Rogue
-- Created: August 21, 2026 at 22:33:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2836990, 1, "b9e2c7d43bac6e55110dbb5d2f37844f2397990f504ac3bf658f3c3a3594029b") -- Drunken Rogue
-- MAIN APP DEPOTS
addappid(2836991, 1, "9872bc33f15541cbb6a3c6b1ab7e2b6a8d983d50eef4c4717f1ae3ba34cd8d37") -- Depot 2836991
setManifestid(2836991, "1071082870613902", 3178144597)