-- Lua provided by RyzenAPI
-- Game: SOL CRESTA

-- MAIN APPLICATION
addappid(1575640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575641, 1, "5467b5331d7cd63ce66347f5401f150d665c39dd7e13b81072ea5fe2c15e8125")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1798120)
addappid(1802830)
addappid(1802831)
addappid(1802832)
