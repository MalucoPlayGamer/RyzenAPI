-- Lua provided by RyzenAPI
-- Game: Inglorious Waifu VS Nazi Zombies

-- MAIN APPLICATION
addappid(1554700)
-- Game: addappid(1554700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554701, 1, "6444f4304a2edd0d63896731c321b459cb3cde8fc941eeec935bc17ab6f28096")
