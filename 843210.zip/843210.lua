-- Lua provided by RyzenAPI
-- Game: Game: AppID 843210

-- MAIN APPLICATION
addappid(843210)
-- Game: addappid(843210)

-- MAIN APP DEPOTS / PACKAGES
addappid(843211, 1, "614f929c1f3e853f275db6524844eefbcb685e9f47f9bb3a46ba316e9286037b")
