-- Lua provided by RyzenAPI
-- Game: Game: Critter Café

-- MAIN APPLICATION
addappid(2367610)
-- Game: addappid(2367610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367611, 1, "9e1e6bb093891586bb5621c5e8c66057bf6b4415bc64e976982e6b025a86547f")
