-- Lua provided by RyzenAPI
-- Game: 3128430

-- MAIN APPLICATION
addappid(3128430)
-- Game: addappid(3128430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128431, 1, "d190df967a05e05043348c38aea013fb8c9b892d63ef24cd2c10cf11f5034a46")
