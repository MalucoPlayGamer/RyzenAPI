-- Lua provided by RyzenAPI 
-- Game: AppID 656770
addappid(656770)
addappid(656771, 1, "b5b9c614fe43cdde7b47402576a1d873f235cb1b024f792780d67a5273e008e5")
