-- Lua provided by RyzenAPI
-- Game: addappid(1755620)

-- MAIN APPLICATION
addappid(1755620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755621, 1, "2e3da9d6ece21f9ef2df8ef650c11d4a60dbe56b05752311242c5bcfa8f1bef2")
