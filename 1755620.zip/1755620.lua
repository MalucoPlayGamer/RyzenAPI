-- Lua provided by RyzenAPI 
-- Game: Anti Frank's Wrath
addappid(1755620)
addappid(1755621, 1, "2e3da9d6ece21f9ef2df8ef650c11d4a60dbe56b05752311242c5bcfa8f1bef2")
