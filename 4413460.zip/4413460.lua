-- 4413460's Lua and Manifest Created by Hubcap Manifest
-- Airport Manager Simulator 2026
-- Created: August 14, 2026 at 13:47:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4413460) -- Airport Manager Simulator 2026
-- MAIN APP DEPOTS
addappid(4413461, 1, "3a20c9b92c1a8ec91d1773a9133182d73acd91a757252e2313fd9bce748bb158") -- Depot 4413461
setManifestid(4413461, "4096105779224747125", 2609759091)