-- Lua provided by RyzenAPI
-- Game: Airport Manager Simulator 2026

-- MAIN APPLICATION
addappid(4413460) -- Airport Manager Simulator 2026

-- MAIN APP DEPOTS / PACKAGES
addappid(4413461, 1, "3a20c9b92c1a8ec91d1773a9133182d73acd91a757252e2313fd9bce748bb158") -- Depot 4413461

