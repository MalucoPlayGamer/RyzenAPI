-- Lua provided by RyzenAPI
-- Game: 2361580

-- MAIN APPLICATION
addappid(2361580)
-- Game: addappid(2361580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361581, 1, "8d11ccde4a2152feea9dc8f26e4fe6af205becd518507e1055248197dfb33c8e")
