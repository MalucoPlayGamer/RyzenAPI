-- Lua provided by RyzenAPI
-- Game: addappid(80300)

-- MAIN APPLICATION
addappid(80300)

-- MAIN APP DEPOTS / PACKAGES
addappid(80301, 1, "f4aec1e7d633e31c0b9ba517dff7587de445f6702c6d3bd13f5ea3b44901041a")
