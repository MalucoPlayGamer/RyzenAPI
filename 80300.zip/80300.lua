-- Lua provided by SkyAPI 
-- Game: Puzzle Bots
addappid(80300)
addappid(80301, 1, "f4aec1e7d633e31c0b9ba517dff7587de445f6702c6d3bd13f5ea3b44901041a")
