-- Lua provided by RyzenAPI
-- Game: addappid(1584330)

-- MAIN APPLICATION
addappid(1584330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584331, 1, "1b13b7c44326e7167b3cc4286e8443bcaf0489d439a785624cb5e41aa748d55b")
