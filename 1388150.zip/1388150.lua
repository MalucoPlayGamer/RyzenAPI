-- Lua provided by RyzenAPI
-- Game: Dispersion

-- MAIN APPLICATION
addappid(1388150)
-- Game: addappid(1388150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388151, 1, "ee98d5e9d45253246a54f59b55ce2e513e4df63ee3c66f366a0821efe8997659")
