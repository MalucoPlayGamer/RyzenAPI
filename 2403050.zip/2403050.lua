-- Lua provided by RyzenAPI
-- Game: Below the Surface:Assassin's Prison

-- MAIN APPLICATION
addappid(2403050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2403051, 1, "d00a68e61bfeb80caab2254852e71c5e4ad80e47517bdc71b661e71c23379355")

