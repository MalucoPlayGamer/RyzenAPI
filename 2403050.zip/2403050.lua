-- Lua provided by RyzenAPI
-- Game: Below the Surface:Assassin's Prison

-- MAIN APPLICATION
addappid(2403050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403051, 1, "d00a68e61bfeb80caab2254852e71c5e4ad80e47517bdc71b661e71c23379355")

