-- Lua provided by RyzenAPI
-- Game: Game: BattleJuice Alchemist

-- MAIN APPLICATION
addappid(1384060)
-- Game: addappid(1384060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384061, 1, "d52fd4aa558d881a5a1201a40376d1360eca753ddfe6d5b95fdc16d860239ec4")
