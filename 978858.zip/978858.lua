-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Additional Weapon "Inferno Voulge" / 追加武器「火塵双刀」

-- MAIN APPLICATION
addappid(978858)

-- MAIN APP DEPOTS / PACKAGES
addappid(978858,0,"1ac9007668daaa7b047c100b670f87a0e69e768fdf68dd7315980b7e632243d5")

