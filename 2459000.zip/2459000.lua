-- Lua provided by RyzenAPI
-- Game: Cataclismo Demo

-- MAIN APPLICATION
addappid(2459000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459001, 1, "244a9aca207177dd91a4ed2b4f887cbe84f707e3b7bf182e784521463761a490")

