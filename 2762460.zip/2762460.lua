-- Lua provided by RyzenAPI
-- Game: 2762460

-- MAIN APPLICATION
addappid(2762460)
-- Game: addappid(2762460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762461, 1, "02785125c44605582e2fe4054970bd81aa5da80ea43fdc86354cd34a97b5b43f")
