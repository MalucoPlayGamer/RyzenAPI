-- Lua provided by RyzenAPI
-- Game: 8-Bit Armies

-- MAIN APPLICATION
addappid(427250)

-- MAIN APP DEPOTS / PACKAGES
addappid(427251, 1, "b81bfeb36ef17f5b364fa56dc1b76ebdd6a76465b4bbc53f8bc1bf6a60bb860d")
