-- Lua provided by RyzenAPI
-- Game: 8-Bit Armies

-- MAIN APPLICATION
addappid(427250)
addappid(477240)
addappid(482420)
addappid(549610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(427251, 1, "b81bfeb36ef17f5b364fa56dc1b76ebdd6a76465b4bbc53f8bc1bf6a60bb860d")