-- Lua provided by RyzenAPI
-- Game: 1815880

-- MAIN APPLICATION
addappid(1815880)
-- Game: addappid(1815880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815881, 1, "40bddb0d0e73523b2897bf84fa4e395756e3fa29021170f3d781b37b31bb0150")
