-- Lua provided by RyzenAPI
-- Game: Auto Sale Life: Fresh Start

-- MAIN APPLICATION
addappid(2877220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877221, 1, "0e63f29295fca3feaa23179ce564467107c8a88a6859f56f1536f516c8dc7772")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
