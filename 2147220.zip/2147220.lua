-- Lua provided by RyzenAPI
-- Game: 2147220

-- MAIN APPLICATION
addappid(2147220)
-- Game: addappid(2147220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147220,0,"d9be6d05aa5eca0530a97338b5ce85d0aa680ea87d3cf330e242af3d908a44ef")
addappid(2147222,0,"f90956526a139781a45069ee419ce8aed9d0642bdbd267ca0cec80f2e86ac481")
