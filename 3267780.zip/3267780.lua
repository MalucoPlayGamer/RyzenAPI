-- Lua provided by RyzenAPI
-- Game: The Coma 2B: Catacomb - The Survivalist Skin

-- MAIN APPLICATION
addappid(3267780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267780,0,"f0d25088d031643d14c9a1a3a53da334b4b9d49eeff0eaac1d8f2b2c396f7f58")

