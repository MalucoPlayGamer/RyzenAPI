-- Lua provided by RyzenAPI
-- Game: Rose Demo

-- MAIN APPLICATION
addappid(3204180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204181, 1, "866a8c56ebaf8aacbbfbf05585585770bc8f6ad8e51fcad23fd76a319aabaae7")
