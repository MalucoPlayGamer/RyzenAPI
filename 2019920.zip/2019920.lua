-- Lua provided by RyzenAPI 
-- Game: Food Factory
addappid(2019920)
addappid(2019921, 1, "c1d82629f8e9efdf882f8f5fddc3fb2e0186c7a75accc89a32d331a605763354")
