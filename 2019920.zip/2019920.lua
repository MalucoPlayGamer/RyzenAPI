-- Lua provided by RyzenAPI
-- Game: Food Factory

-- MAIN APPLICATION
addappid(2019920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2019921, 1, "c1d82629f8e9efdf882f8f5fddc3fb2e0186c7a75accc89a32d331a605763354")

