-- Lua provided by SkyAPI 
-- Game: Microtopia
addappid(2750000)
addappid(2750001, 1, "db56ace1aeb88aaf504ff834349d568e0aece66bea377f2b39b17b38c31755ac")
addappid(3509030, 0, "e1f3af7f50f8ab33dfe597ce71f02796a6694e462b45b889053e9d03739de202")
