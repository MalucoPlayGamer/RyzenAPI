-- Lua provided by RyzenAPI
-- Game: Game: AppID 278420

-- MAIN APPLICATION
addappid(278420)
addappid(391930)
-- Game: addappid(278420)

-- MAIN APP DEPOTS / PACKAGES
addappid(278421, 1, "21bf63b258e2f8e77d45e155f1b760f423912bfff0c1b47b8d9c99e5591532b0")
addappid(278422, 1, "1c3ab596675162c725343a885f548acec6c9130653a9e55bdfef8af30081df8f")
addappid(278423, 1, "74308b71204a788e32aa0e3eef2fe71a92ca5ff132213f16d6c7c93c95ad924f")
