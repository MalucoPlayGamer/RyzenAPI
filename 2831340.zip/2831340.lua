-- Lua provided by RyzenAPI
-- Game: Rabbit Hole

-- MAIN APPLICATION
addappid(2831340)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3175480)
