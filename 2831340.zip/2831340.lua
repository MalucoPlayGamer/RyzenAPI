-- Lua provided by RyzenAPI
-- Game: Rabbit Hole

-- MAIN APPLICATION
addappid(2831340)

