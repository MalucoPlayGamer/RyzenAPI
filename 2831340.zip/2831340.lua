-- Lua provided by RyzenAPI
-- Game: Rabbit Hole

-- MAIN APPLICATION
addappid(2831340)
addappid(3175480)

