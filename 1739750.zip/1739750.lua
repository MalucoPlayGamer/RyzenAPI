-- Lua provided by RyzenAPI
-- Game: AppID 1739750

-- MAIN APPLICATION
addappid(1739750)
-- Game: addappid(1739750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739751, 1, "29f1d51c9406fc4cc5cca8c35fa84aea57dda003d2588d1509ae9af4b1cfa10c")
addappid(1739753, 1, "98c03c6c02fda2a757dfaeeeb18717646c3e37961fca91ae895195deff521ee0")
