-- Lua provided by RyzenAPI
-- Game: Aqua Rally

-- MAIN APPLICATION
addappid(1029530)
-- Game: addappid(1029530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029531, 1, "7e8179d860217c502f36fda5f7edd3a1ce712348e4319e42573125528c3dd97a")
