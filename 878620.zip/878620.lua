-- Lua provided by RyzenAPI
-- Game: Game: Neotrie VR Multiplayer

-- MAIN APPLICATION
addappid(878620)
-- Game: addappid(878620)

-- MAIN APP DEPOTS / PACKAGES
addappid(878621, 1, "1a95f50201b9d0738df9c5c716add099d61eeb8a5376e740dfa3bf6b5ebbf815")
