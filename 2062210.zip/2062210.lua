-- Lua provided by RyzenAPI
-- Game: Watamari Part1 - A Match Made in Heaven

-- MAIN APPLICATION
addappid(2062210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062211, 1, "23ba4be9b24c55098cc84cb789e2dd4305478ebe2c443857af41477999575135")
addappid(2165890, 0, "df1c70c863ba9c43e70e1389c21f1d2a29f5fb63d43912a9979e5e709285ad1c")
