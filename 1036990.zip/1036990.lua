-- Lua provided by RyzenAPI 
-- Game: AppID 1036990
addappid(1036990)
addappid(1036991, 1, "2d22347b073f6112d5d29571c9858d953943a6acf26e095ba1951d03afb2a2ee")
addappid(1036998, 1, "c88a25f7766ceb19c29c209ad5211f160be3344091e661d00aaccda90284db46")
