-- Lua provided by RyzenAPI
-- Game: AppID 1341780

-- MAIN APPLICATION
addappid(1341780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341781, 1, "379a9a227a4398598e8966382424042bba1198834dcbfd87bce7875d2e05248c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
