-- Lua provided by RyzenAPI
-- Game: AppID 2804380

-- MAIN APPLICATION
addappid(2804380)
-- Game: addappid(2804380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804381, 1, "3ef34037036d832c7af97e7fcaa469d49e6fdc6d236a3b77ae611ab294b0e090")
