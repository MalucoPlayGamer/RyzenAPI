-- Lua provided by RyzenAPI
-- Game: Night Furries

-- MAIN APPLICATION
addappid(1155270)
addappid(1161400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155271, 1, "818697181edb444aa13b9e41d732f0d33d78fadc7c1e6ab9c5e13ab074e9499a")
addappid(1161380, 0, "f5e99bb40278b071fa6cc1b6094c31d0a8c434901e25e3e72d821cc133572165")
addappid(1161390, 0, "e47a06e7ef51b92a88a7c0ccced7d7cd63d143f19669857f02b5adb89a41946b")
