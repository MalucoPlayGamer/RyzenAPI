-- Lua provided by RyzenAPI
-- Game: PhyTetris-Physics Tetris

-- MAIN APPLICATION
addappid(1778780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778781, 1, "2c1f20e750371648022e073e74119807ee0fcdc01649db447a0b48fd92058586")
