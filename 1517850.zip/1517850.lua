-- Lua provided by RyzenAPI
-- Game: Quickie: A Love Hotel Story

-- MAIN APPLICATION
addappid(1517850)
-- Game: addappid(1517850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517851, 1, "95d82c5be3ebf474bb15ca0fbabde95f8d12338a08aceabb4a88b7000d4eea3e")
addappid(1517852, 1, "c93a43df59d79c07dbcaa5b11e37c7802fe865b93e61898814c8dd30821e03e6")
addappid(1517853, 1, "cdd7d75d4c23fb923a1f669f2ee1838d40ad189d3ec474d1dd78cf241f77adb7")
