-- Lua provided by RyzenAPI
-- Game: Furry Finder Demo

-- MAIN APPLICATION
addappid(1955020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955021, 1, "6100e93fdfc3dd4127798368308795c80af982877b8934ba12c3d1604c8fcf31")

