-- Lua provided by RyzenAPI
-- Game: Modern Game Tycoon

-- MAIN APPLICATION
addappid(1776730)
-- Game: addappid(1776730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776731, 1, "31075ba7abca27c0c277001160d35f380a6ab2c8ea1705f3e48c909a395c834e")
