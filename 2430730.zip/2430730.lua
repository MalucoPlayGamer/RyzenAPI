-- Lua provided by RyzenAPI
-- Game: My Child Lebensborn Remastered

-- MAIN APPLICATION
addappid(2430730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430731, 1, "4969e963c3707eba163322c61c63d6075a19046ab01837de13d242e61bbf895e")

