-- Lua provided by SkyAPI 
-- Game: My Child Lebensborn Remastered
addappid(2430730)
addappid(2430731, 1, "4969e963c3707eba163322c61c63d6075a19046ab01837de13d242e61bbf895e")
