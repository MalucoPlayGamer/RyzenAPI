-- Lua provided by RyzenAPI
-- Game: VR Sailing

-- MAIN APPLICATION
addappid(3201570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201571, 1, "86dfd0bc7ba56cabc47474c595ea02f426ce169fed136602d8822cc9dfd10bbe")
