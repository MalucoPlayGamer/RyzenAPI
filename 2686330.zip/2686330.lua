-- Lua provided by RyzenAPI
-- Game: addappid(2686330)

-- MAIN APPLICATION
addappid(2686330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686332,0,"59d2e5e44f699d6279ea7849d9a56f5356b294a3db19bef72ed932cfe6673928")
