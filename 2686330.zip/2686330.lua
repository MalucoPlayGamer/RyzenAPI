-- Lua provided by RyzenAPI
-- Game: NOCLIP

-- MAIN APPLICATION
addappid(2686330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686332,0,"59d2e5e44f699d6279ea7849d9a56f5356b294a3db19bef72ed932cfe6673928")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
