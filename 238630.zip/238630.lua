-- Lua provided by RyzenAPI
-- Game: Fist Puncher

-- MAIN APPLICATION
addappid(238630)
addappid(242270)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(238631, 1, "c37df55a4b913ea6caa6c4d5ead7c42e90b2a615c872f6e7ce7544f2194e3699")
addappid(238633, 1, "67e76c159faba91308eb49190571bfea74aa2ba567746b18b5f1d2f76f4bf1b5")
addappid(238635, 1, "e7462d65a8a8c253499e5d4428e0c447d5ddb5787c052a70e900f1229f4405ff")

