-- Lua provided by RyzenAPI
-- Game: Game: Fist Puncher

-- MAIN APPLICATION
addappid(238630)
addappid(242270)
-- Game: addappid(238630)

-- MAIN APP DEPOTS / PACKAGES
addappid(238631, 1, "c37df55a4b913ea6caa6c4d5ead7c42e90b2a615c872f6e7ce7544f2194e3699")
addappid(238633, 1, "67e76c159faba91308eb49190571bfea74aa2ba567746b18b5f1d2f76f4bf1b5")
addappid(238635, 1, "e7462d65a8a8c253499e5d4428e0c447d5ddb5787c052a70e900f1229f4405ff")
