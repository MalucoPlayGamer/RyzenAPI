-- Lua provided by RyzenAPI
-- Game: ! That Bastard Is Trying To Steal Our Gold !

-- MAIN APPLICATION
addappid(449940)

-- MAIN APP DEPOTS / PACKAGES
addappid(449941, 1, "8741d94399cda0bb58bd50ebfde14e6fa9261718250c473f50d448a997c6d971")
addappid(449942, 1, "daff243560aa20503af1827177466c5f9225624319a603ca6b83e877ca6e9202")
addappid(449943, 1, "f09335fdf3a2cbd705b2b788b66eb422e883a5b9036cf3b621019f13855a1886")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
