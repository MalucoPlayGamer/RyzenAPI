-- Lua provided by RyzenAPI
-- Game: AppID 702110

-- MAIN APPLICATION
addappid(702110)

-- MAIN APP DEPOTS / PACKAGES
addappid(702111, 1, "500fb4a2cc9914d1076b0d971012a6d3a969f2a14193b1a6bcd1b1caabc3208a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
