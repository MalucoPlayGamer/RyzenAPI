-- Lua provided by RyzenAPI
-- Game: AppID 702110

-- MAIN APPLICATION
addappid(702110)
-- Game: addappid(702110)

-- MAIN APP DEPOTS / PACKAGES
addappid(702111, 1, "500fb4a2cc9914d1076b0d971012a6d3a969f2a14193b1a6bcd1b1caabc3208a")
