-- Lua provided by RyzenAPI
-- Game: 1396240

-- MAIN APPLICATION
addappid(1396240)
-- Game: addappid(1396240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396241, 1, "c49f850a8ed604c11ed85e7e6279f7b1ebac6f9bddc9b03b73c47431820437c9")
