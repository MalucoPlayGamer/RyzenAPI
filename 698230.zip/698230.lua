-- Lua provided by RyzenAPI
-- Game: RockBuster

-- MAIN APPLICATION
addappid(698230)

-- MAIN APP DEPOTS / PACKAGES
addappid(698231,0,"1adbad7fe8b3809eab65342ad0bb8b56bc007423c1940c793f0bdde3f8e3dec9")

