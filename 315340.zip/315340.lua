-- Lua provided by RyzenAPI
-- Game: addappid(315340)

-- MAIN APPLICATION
addappid(315340)

-- MAIN APP DEPOTS / PACKAGES
addappid(315341, 1, "2d0575ea4bf3811e03cab99900842f7351934f415c4cb76f6692c9b9e2f7f225")
