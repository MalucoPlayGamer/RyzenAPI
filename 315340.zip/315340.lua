-- Lua provided by RyzenAPI
-- Game: A.R.E.S. Extinction Agenda EX

-- MAIN APPLICATION
addappid(315340)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(315341, 1, "2d0575ea4bf3811e03cab99900842f7351934f415c4cb76f6692c9b9e2f7f225")

