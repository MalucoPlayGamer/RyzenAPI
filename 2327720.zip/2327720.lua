-- Lua provided by RyzenAPI
-- Game: City Car Driving 2.0

-- MAIN APPLICATION
addappid(2327720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327721, 1, "e7f5c17d4db7edb932a65bef69f5d9dcf9f6519ce55c9cc89520deaa8024bc65")

