-- Lua provided by RyzenAPI
-- Game: City Car Driving 2.0

-- MAIN APPLICATION
addappid(2327720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327721, 1, "e7f5c17d4db7edb932a65bef69f5d9dcf9f6519ce55c9cc89520deaa8024bc65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
