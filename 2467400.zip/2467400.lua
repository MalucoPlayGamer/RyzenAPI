-- Lua provided by RyzenAPI 
-- Game: ParryRobot
addappid(2467400)
addappid(2467401, 1, "f31055002de4ba4a6ca47c97add6d94f713b4789b6951de43423c052807871e2")
