-- Lua provided by RyzenAPI
-- Game: addappid(2179520)

-- MAIN APPLICATION
addappid(2179520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179521, 1, "050c32e7ab6af3d2c7bbebd339b9e5402914cf06f084b4458d8f616d69929c85")
