-- Lua provided by SkyAPI 
-- Game: Clans
addappid(281430)
addappid(281431, 1, "6a79013c8fb55a8219dfbb13ed42fcef85f58c15169c502aabcd0dbcbde1a9e0")
