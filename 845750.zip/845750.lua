-- Lua provided by RyzenAPI
-- Game: Don't Play With Dolls

-- MAIN APPLICATION
addappid(845750)

-- MAIN APP DEPOTS / PACKAGES
addappid(845751, 1, "4808365334796c4329c5771b153d7038309f45631e7a1e7508ee3ff0e9a0f302")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
