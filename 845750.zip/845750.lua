-- Lua provided by RyzenAPI
-- Game: Game: Don't Play With Dolls

-- MAIN APPLICATION
addappid(845750)
-- Game: addappid(845750)

-- MAIN APP DEPOTS / PACKAGES
addappid(845751, 1, "4808365334796c4329c5771b153d7038309f45631e7a1e7508ee3ff0e9a0f302")
