-- Lua provided by RyzenAPI
-- Game: Clocker - Original Soundtrack

-- MAIN APPLICATION
addappid(1032190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032190,0,"13e5404936e416f3e0b94a804b85b5673cca2da43346eac4d02e2ff2f4a2b06a")

