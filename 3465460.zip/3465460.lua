-- Lua provided by SkyAPI 
-- Game: AppID 3465460
addappid(3465460)
addappid(3465461, 1, "ea42afeed9f81538ee5c900637f3f988ccd45a7e992116369d155ef05f468dc5")
