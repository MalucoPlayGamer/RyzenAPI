-- Lua provided by RyzenAPI
-- Game: Brick Breaker Heart Collector

-- MAIN APPLICATION
addappid(1639490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639491, 1, "a305238ff75805723af8169abefa2b16f36b452b5f08ba547a803a6d28b03a0e")

