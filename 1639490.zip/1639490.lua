-- Lua provided by RyzenAPI
-- Game: 1639490

-- MAIN APPLICATION
addappid(1639490)
-- Game: addappid(1639490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639491, 1, "a305238ff75805723af8169abefa2b16f36b452b5f08ba547a803a6d28b03a0e")
