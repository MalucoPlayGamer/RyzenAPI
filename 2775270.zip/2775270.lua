-- Lua provided by SkyAPI 
-- Game: AppID 2775270
addappid(2775270)
addappid(2775271, 1, "3d44c477015cdf2349b5590a4e53aef2b16f4c63c08824c16bf047bb4188bf02")
