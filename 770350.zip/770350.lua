-- Lua provided by RyzenAPI
-- Game: addappid(770350)

-- MAIN APPLICATION
addappid(770350)

-- MAIN APP DEPOTS / PACKAGES
addappid(770351, 1, "0a845491849f0c214a6ed63a50ba9de54ed041dfb643545b4664161b243f3e50")
