-- Lua provided by RyzenAPI
-- Game: addappid(750200)

-- MAIN APPLICATION
addappid(750200)

-- MAIN APP DEPOTS / PACKAGES
addappid(750202,0,"d47f517e903365263b24ec1adb4aabd464545d307597cb1a7aaa15d7153c5f94")
