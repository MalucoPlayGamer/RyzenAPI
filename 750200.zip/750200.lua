-- Lua provided by RyzenAPI
-- Game: AWAY: The Survival Series

-- MAIN APPLICATION
addappid(750200)

-- MAIN APP DEPOTS / PACKAGES
addappid(750202,0,"d47f517e903365263b24ec1adb4aabd464545d307597cb1a7aaa15d7153c5f94")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
