-- Lua provided by RyzenAPI
-- Game: Perfect Shot

-- MAIN APPLICATION
addappid(3477950)
-- Game: addappid(3477950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477951, 1, "13654dd3f9138d2acb1163af5a9ff88dfbc9268b61b5786a5acd055e69232461")
