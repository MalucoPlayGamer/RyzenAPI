-- Lua provided by SkyAPI 
-- Game: Pumping Simulator
addappid(1455120)
addappid(1455121, 1, "39dd29fd7b2ac819103d27e8635ac40b2537bd240b51f65271ca69e95063973d")
addappid(1455122, 1, "de71da579c055145b4de9f5138e45ec64fe7dc6c88698616eec15fc6fcf4f194")
