-- Lua provided by SkyAPI 
-- Game: Tightrope Theatre
addappid(1891140)
addappid(1891141, 1, "2b8a30a290a14a8f19acfecb562b08df4bc224c493c420e69962c34e3d303eee")
