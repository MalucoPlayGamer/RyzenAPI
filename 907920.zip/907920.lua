-- Lua provided by RyzenAPI
-- Game: 907920

-- MAIN APPLICATION
addappid(907920)
-- Game: addappid(907920)

-- MAIN APP DEPOTS / PACKAGES
addappid(907921, 1, "a63ff12d1ab58c2228710b92564afd22f1b7c70a95cf18eddfb7346e563229fa")
