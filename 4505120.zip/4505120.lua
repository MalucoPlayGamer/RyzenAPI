-- 4505120's Lua and Manifest Created by Hubcap Manifest
-- Director of Management: Football Club
-- Created: August 12, 2026 at 00:05:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4505120) -- Director of Management: Football Club
-- MAIN APP DEPOTS
addappid(4505121, 1, "586346d93e5f42191ece01d8b3d9a7ec31a447e5596a3cfd2d22aed5cc4635fc") -- Depot 4505121
setManifestid(4505121, "1827001982742610478", 3319632106)