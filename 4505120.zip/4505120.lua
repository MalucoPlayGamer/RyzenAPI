-- Lua provided by RyzenAPI
-- Game: Director of Management: Football Club

-- MAIN APPLICATION
addappid(4505120) -- Director of Management: Football Club

-- MAIN APP DEPOTS / PACKAGES
addappid(4505121, 1, "586346d93e5f42191ece01d8b3d9a7ec31a447e5596a3cfd2d22aed5cc4635fc") -- Depot 4505121

