-- Lua provided by SkyAPI 
-- Game: Bullet Quest
addappid(1946490)
addappid(1946491, 1, "da8b9f7c2fd780e698fe154f1f055fc36eda3734789b08d37dda9b8f207f8fe5")
