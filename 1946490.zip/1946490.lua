-- Lua provided by RyzenAPI
-- Game: Bullet Quest

-- MAIN APPLICATION
addappid(1946490)
-- Game: addappid(1946490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946491, 1, "da8b9f7c2fd780e698fe154f1f055fc36eda3734789b08d37dda9b8f207f8fe5")
