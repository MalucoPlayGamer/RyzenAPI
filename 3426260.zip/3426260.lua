-- Lua provided by RyzenAPI
-- Game: Game: Sex & Coffee ☕️🤎

-- MAIN APPLICATION
addappid(3426260)
-- Game: addappid(3426260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3426261, 1, "a4336cfb51f88aae12daa8587c72fcc64f2800a568b690bd18c84715da13dae3")
