-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Glowing Icon Pack

-- MAIN APPLICATION
addappid(2644800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644800,0,"8f6f0446a326477558724fd0fdb6b38f07d4d1ccdc2dbc707b1b522f401c720d")
