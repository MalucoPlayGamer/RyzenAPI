-- Lua provided by SkyAPI 
-- Game: The Legend of Heroes: Trails from Zero
addappid(1668510)
addappid(1668511, 1, "4dc7ce12681ff9fa9563d3ca8ab00f4da2c966d5b3d8973d37f1518080a8ae18")
addappid(2098610, 0, "221110e4ec72b935c1482c20763910e118019c0e7368284a8185cb11352f4644")
