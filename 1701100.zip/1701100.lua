-- Lua provided by RyzenAPI
-- Game: 1701100

-- MAIN APPLICATION
addappid(1701100)
-- Game: addappid(1701100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701101, 1, "d57b070ee3ef13b101e192f5c8b221d44cec21b0d4866a966cf22f2674dc46ef")
