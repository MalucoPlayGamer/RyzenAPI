-- Lua provided by RyzenAPI
-- Game: 833910

-- MAIN APPLICATION
addappid(833910)
addappid(837340)
-- Game: addappid(833910)

-- MAIN APP DEPOTS / PACKAGES
addappid(833911, 1, "37667946e7737add830f74e184403b23c114f1f0259ddacd0a7055c5f4a9eec0")
