-- Lua provided by RyzenAPI
-- Game: The Inquisitor

-- MAIN APPLICATION
addappid(1880470)
addappid(2475100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880471, 1, "c818b70302c28b1731981e757f019f3380a7845825c820f4565eca92f3ef0c35")
