-- Lua provided by RyzenAPI
-- Game: AppID 411370

-- MAIN APPLICATION
addappid(411370)
-- Game: addappid(411370)

-- MAIN APP DEPOTS / PACKAGES
addappid(411371, 1, "b62cf8ef41b7d77aded6c6df233ad7544c6bd6b8be0f09ad707d62d411d81497")
