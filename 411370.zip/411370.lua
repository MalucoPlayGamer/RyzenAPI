-- Lua provided by RyzenAPI
-- Game: MELTY BLOOD Actress Again Current Code

-- MAIN APPLICATION
addappid(411370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(411371, 1, "b62cf8ef41b7d77aded6c6df233ad7544c6bd6b8be0f09ad707d62d411d81497")

