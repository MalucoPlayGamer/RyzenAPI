-- Lua provided by RyzenAPI
-- Game: Maiden and Spell

-- MAIN APPLICATION
addappid(1004770)
-- Game: addappid(1004770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004771, 1, "8c50bf0d876825852ca0c0d07a09ce2cece4bad9828494aaaa8d72b817d9df14")
addappid(1205731, 0, "bf9174e7e0775f4bcdf491373b7c6dd382cc57a69dde6bf9b49c0c14c55a34bf")
