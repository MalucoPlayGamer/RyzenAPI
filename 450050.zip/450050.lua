-- Lua provided by RyzenAPI
-- Game: 450050

-- MAIN APPLICATION
addappid(450050)
-- Game: addappid(450050)

-- MAIN APP DEPOTS / PACKAGES
addappid(450051, 1, "f6331b7df4c336f04478e0607a4de5baaff0b90d692920324cb290c15ae05a91")
