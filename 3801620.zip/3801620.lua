-- Lua provided by RyzenAPI
-- Game: 3801620

-- MAIN APPLICATION
addappid(3801620)
-- Game: addappid(3801620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3801621, 1, "ee258c21b2b3c1cc0331f4ee01aebf7b870001a6b8af5e839be6ffee14ad83dc")
