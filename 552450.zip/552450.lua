-- Lua provided by RyzenAPI
-- Game: Serious Sam VR: The First Encounter

-- MAIN APPLICATION
addappid(552450)

-- MAIN APP DEPOTS / PACKAGES
addappid(552451, 1, "edb59fa3000afcc510645dbeeb2e98c6b91e86144074431f1eb997adcba6e6a8")
addappid(552452, 1, "fd24994c7e0d176350bbd34735795e3acc911b315e606a9f1f76ff7d98d35350")
addappid(552453, 1, "61be67287c169e75ddb8c4f0dbebf28c207764f7fe6c1aad70bec13a43eeac13")
addappid(552454, 1, "895746946ae687989b80394c2271fff906c6f913a1c3650c7198fd6f3250d52c")
addappid(552455, 1, "ac5290b67d3e9a443cfc88c5e3e7dc2c680bf98f64ff5108fe06b1d1522ce67d")
addappid(552456, 1, "7bf061506ddc99ceb4c0cd53b3e6b0388712ddfff600e21986d23fdead87f677")
addappid(552458, 1, "c2d3a5a2cf0ea159916e8218cecb935a5f9e7b10464d3b0e70da51635a0a5d93")
addappid(552459, 1, "55c7e8463e1b62139e7f60b2c6bd161944c4bdc30efdbcf9d920b73fd4aa976b")

