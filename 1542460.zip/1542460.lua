-- Lua provided by RyzenAPI
-- Game: ZenFarm

-- MAIN APPLICATION
addappid(1542460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542461, 1, "95d6f1ec3c15a06f447465f983af743d7f5259a8a8c676ae209e706b8e487d4e")
