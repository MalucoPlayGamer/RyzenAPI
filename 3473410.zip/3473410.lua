-- Lua provided by RyzenAPI
-- Game: addappid(3473410)

-- MAIN APPLICATION
addappid(3473410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473411, 1, "3710ba886544d5d10e6ee253adf344dad200c41f2bf66db0065693c8badc5a8f")
