-- Lua provided by RyzenAPI
-- Game: AppID 1014850

-- MAIN APPLICATION
addappid(1014850)
-- Game: addappid(1014850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014851, 1, "25571850f0a47f530a2bc8c590ed0007afc4a6bb69d9ecb42da385fef022d2ce")
