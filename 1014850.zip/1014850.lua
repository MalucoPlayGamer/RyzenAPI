-- Lua provided by RyzenAPI
-- Game: Iridium

-- MAIN APPLICATION
addappid(1014850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1014851, 1, "25571850f0a47f530a2bc8c590ed0007afc4a6bb69d9ecb42da385fef022d2ce")
