-- Lua provided by RyzenAPI
-- Game: Badland Bandits

-- MAIN APPLICATION
addappid(378480)
-- Game: addappid(378480)

-- MAIN APP DEPOTS / PACKAGES
addappid(378481, 1, "4057e70384038cc27009c5a1764484fedaecf14db4d614bbc49927f95d8e9331")
addappid(378482, 1, "d3c8ff44a5ccbf56720bf2e2c60a110bef46e72ee2316785e6626358a992d15d")
addappid(378483, 1, "506a76b9cc5959312f896b3fca6708577853194b5bcfa6b36412a65dd83d120c")
