-- Lua provided by RyzenAPI
-- Game: 443800

-- MAIN APPLICATION
addappid(443800)
-- Game: addappid(443800)

-- MAIN APP DEPOTS / PACKAGES
addappid(443801, 1, "c1ae442bf63546863a9646ee891369df73994fabc652b240d0a1e00cca0e02db")
