-- Lua provided by RyzenAPI
-- Game: Game: AdventureBarStory

-- MAIN APPLICATION
addappid(2785950)
-- Game: addappid(2785950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785951, 1, "da730046541d7a73c73828254ae689306e4a1d27b5488998268d395790e3be0b")
