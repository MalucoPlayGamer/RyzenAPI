-- Lua provided by RyzenAPI
-- Game: Game: AppID 2745800

-- MAIN APPLICATION
addappid(2745800)
-- Game: addappid(2745800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2745801, 1, "7fd1640fed6fcd2f238c7c326e52af90bd7c07296c5ddad482cdf8651c20c238")
