-- Lua provided by RyzenAPI
-- Game: 3650650

-- MAIN APPLICATION
addappid(3650650)
-- Game: addappid(3650650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3650651, 1, "7779dc2b4bd7d1ebf1c7e7a8746b822a8c30a62dfb4c8f098add31880c232d0e")
