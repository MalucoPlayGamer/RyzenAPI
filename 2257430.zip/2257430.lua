-- Lua provided by RyzenAPI
-- Game: Game: AppID 2257430

-- MAIN APPLICATION
addappid(2257430)
-- Game: addappid(2257430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257431, 1, "ef135e452abbbf2fe4dd3ea9da556f83d9648a91669f747590a1d43542d23109")
