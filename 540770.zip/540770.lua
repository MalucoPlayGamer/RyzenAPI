-- Lua provided by RyzenAPI
-- Game: Subject 264

-- MAIN APPLICATION
addappid(540770)

-- MAIN APP DEPOTS / PACKAGES
addappid(540771, 1, "0803a605d3069764dcb59e13322774fe943effb324a3c6a47b3c7eebe5b167c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
