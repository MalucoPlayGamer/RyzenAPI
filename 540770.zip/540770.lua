-- Lua provided by RyzenAPI
-- Game: Game: Subject 264

-- MAIN APPLICATION
addappid(540770)
-- Game: addappid(540770)

-- MAIN APP DEPOTS / PACKAGES
addappid(540771, 1, "0803a605d3069764dcb59e13322774fe943effb324a3c6a47b3c7eebe5b167c4")
