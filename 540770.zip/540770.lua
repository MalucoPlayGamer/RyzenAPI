-- Lua provided by SkyAPI 
-- Game: Subject 264
addappid(540770)
addappid(540771, 1, "0803a605d3069764dcb59e13322774fe943effb324a3c6a47b3c7eebe5b167c4")
