-- Lua provided by RyzenAPI
-- Game: PAGER Demo

-- MAIN APPLICATION
addappid(3236390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3236391, 1, "70beb8efa3038dc8380ba441560ef5d9c7eeb95eb853929cb19c25f2dc7242aa")

