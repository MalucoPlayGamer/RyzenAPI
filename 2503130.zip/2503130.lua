-- Lua provided by RyzenAPI
-- Game: Only Fortress

-- MAIN APPLICATION
addappid(2503130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2503131, 1, "d4223e9e811a6f211eed1e667804f2cbaeefd7b06e0d474f37b1945993a749c0")
