-- Lua provided by RyzenAPI
-- Game: Chained: A Victorian Nightmare

-- MAIN APPLICATION
addappid(1198700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1198701, 1, "fd747137cb79c7f405993a0e7991e7b4ed8e978f4c05090ef20ef28727fe20aa")

