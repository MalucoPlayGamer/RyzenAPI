-- Lua provided by RyzenAPI
-- Game: AppID 1198700

-- MAIN APPLICATION
addappid(1198700)
-- Game: addappid(1198700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198701, 1, "fd747137cb79c7f405993a0e7991e7b4ed8e978f4c05090ef20ef28727fe20aa")
