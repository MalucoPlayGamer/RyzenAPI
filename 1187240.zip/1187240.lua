-- Lua provided by RyzenAPI
-- Game: addappid(1187240)

-- MAIN APPLICATION
addappid(1187240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187241, 1, "17836549abaa3813846f96d553a92ee6e89845a29977e2f37c8cb90d092ca0ce")
