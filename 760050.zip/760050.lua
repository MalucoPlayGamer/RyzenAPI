-- Lua provided by RyzenAPI
-- Game: Nightwolf: Survive the Megadome

-- MAIN APPLICATION
addappid(760050)
-- Game: addappid(760050)

-- MAIN APP DEPOTS / PACKAGES
addappid(760051, 1, "80167e7f94b5e10c62b6fd2fddcb4742220a0ba71dae98c977b0b1da43d54ccf")
