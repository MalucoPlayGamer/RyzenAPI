-- Lua provided by RyzenAPI
-- Game: Battle for borders

-- MAIN APPLICATION
addappid(2151900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151901, 1, "c2f789a6a6ecc60138dd1716264742e4f38ba3b64696ff42c2e28f1eb6361ab0")
