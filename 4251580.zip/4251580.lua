-- Lua provided by RyzenAPI
-- Game: Everyday Devil

-- MAIN APPLICATION
addappid(4251580)
