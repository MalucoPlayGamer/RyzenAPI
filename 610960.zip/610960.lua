-- Lua provided by RyzenAPI
-- Game: 红石遗迹 - Red Obsidian Remnant

-- MAIN APPLICATION
addappid(610960)
addappid(950431)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(610961, 1, "159215fbc6958801e512fcfb43651f91a2173d839edccfaf1f1ed838b6ac9688")

