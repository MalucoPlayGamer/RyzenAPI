-- Lua provided by RyzenAPI
-- Game: addappid(610960)

-- MAIN APPLICATION
addappid(610960)
addappid(950431)

-- MAIN APP DEPOTS / PACKAGES
addappid(610961, 1, "159215fbc6958801e512fcfb43651f91a2173d839edccfaf1f1ed838b6ac9688")
