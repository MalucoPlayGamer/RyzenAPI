-- Lua provided by RyzenAPI
-- Game: addappid(2215950)

-- MAIN APPLICATION
addappid(2215950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215951, 1, "f4b617f0fae33692774c28a76c8d8026eceb63ea1aedab620b630601d1f8f748")
