-- Lua provided by RyzenAPI 
-- Game: AppID 2516740
addappid(2516740)
addappid(2516741, 1, "6936ee31f075f8517dbb7cbe2cadaba3d292db2c2b4dbcb27a75a8fc0b4e28d5")
