-- Lua provided by RyzenAPI
-- Game: Game: AppID 681110

-- MAIN APPLICATION
addappid(681110)
-- Game: addappid(681110)

-- MAIN APP DEPOTS / PACKAGES
addappid(681111, 1, "f70ef09fcf9a0d7283167e55635c990e3fe1a90bc2ab65dc7bc450962e720e76")
