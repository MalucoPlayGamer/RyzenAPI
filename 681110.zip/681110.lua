-- Lua provided by RyzenAPI
-- Game: AppID 681110

-- MAIN APPLICATION
addappid(681110)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(681111, 1, "f70ef09fcf9a0d7283167e55635c990e3fe1a90bc2ab65dc7bc450962e720e76")

