-- Lua provided by RyzenAPI
-- Game: Heart of the Woods Original Soundtrack - Snowfall

-- MAIN APPLICATION
addappid(1031420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252421,0,"88f9dea2d91ae225b8047c368f0517d7c9734b588b4f92c8f494534d8ac3555e")
addappid(1252424,0,"00860b2482cd7d382d94dcd73eb7d98103276703268e1031b604d18f93df56d1")

