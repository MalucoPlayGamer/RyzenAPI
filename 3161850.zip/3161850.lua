-- Lua provided by RyzenAPI
-- Game: Boosted Survivors

-- MAIN APPLICATION
addappid(3161850)
-- Game: addappid(3161850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161851, 1, "5cbb946ba153d98818200369d94a3675ce3d65d2935fa69fa35c97c4590ec50f")
