-- Lua provided by RyzenAPI
-- Game: AppID 2639750

-- MAIN APPLICATION
addappid(2639750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639751, 1, "69ad5e3f1fe0503227f5eb4fa1d1daf71d2c7abbd2a43b6ee01d20b4196f5fbd")
