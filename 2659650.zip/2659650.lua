-- Lua provided by RyzenAPI
-- Game: 2659650

-- MAIN APPLICATION
addappid(2659650)
-- Game: addappid(2659650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659651, 1, "71539eefe67d098940e6651c3cae9483cbd05938be208fe83196c387d1fdde99")
