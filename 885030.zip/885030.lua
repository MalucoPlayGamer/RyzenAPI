-- Lua provided by RyzenAPI
-- Game: Platform Builder

-- MAIN APPLICATION
addappid(885030)
addappid(892250)

-- MAIN APP DEPOTS / PACKAGES
addappid(885031,0,"cbd06e08081cefe3fda86f4b36d9d4e079c26e863ea405c1f8623a3ef96a13bd")

