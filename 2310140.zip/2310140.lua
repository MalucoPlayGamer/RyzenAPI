-- Lua provided by RyzenAPI
-- Game: Sex-Loving Family - Arisa After Story -

-- MAIN APPLICATION
addappid(2310140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310140,0,"087d02cb8cceb3d5d1bc531a993ba5d821bd9e4e87925e1cebd182b6cf0ce30b")
