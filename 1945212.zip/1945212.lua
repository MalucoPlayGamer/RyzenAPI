-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit 16-piece Set

-- MAIN APPLICATION
addappid(1945212)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945212,0,"5d52c01281f25a7e44047d428a0eeb576d8f3a8cc6dd6565603163b71e5e2964")
