-- Lua provided by SkyAPI 
-- Game: Call of Juarez Gunslinger Demo
addappid(222400)
addappid(222401, 1, "942261e91707367a185cec495a9b92175308d2b7e5b13f484e63c3078b3dfcfc")
