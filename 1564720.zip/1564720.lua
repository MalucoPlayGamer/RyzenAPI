-- Lua provided by RyzenAPI
-- Game: 先民的遗迹Relics of ancestors

-- MAIN APPLICATION
addappid(1564720)
-- Game: addappid(1564720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564721, 1, "d214703b93c50f1be6e33e18b68c45bc76b4cce9475ec79e52e93b65e32489c8")
