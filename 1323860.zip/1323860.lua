-- Lua provided by RyzenAPI
-- Game: Crowded Blue Dot

-- MAIN APPLICATION
addappid(1323860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323861, 1, "a0c0e32917ce3f31f8136106b8513bf81bfd61d0b0a1902252e6207cc229816b") -- (windows, 64-bit)

