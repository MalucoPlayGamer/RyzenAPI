-- Generated with Luie @ https://lua.tools/
-- 1323860 - Crowded Blue Dot
-- Generated 2026-08-08 19:18:47 UTC
-- # Depots (Total/DLC/Shared): 2/0/0

-- Main AppID
addappid(1323860)

-- Main Depots
addappid(1323861, 1, "a0c0e32917ce3f31f8136106b8513bf81bfd61d0b0a1902252e6207cc229816b") -- (windows, 64-bit)
setManifestid(1323861, "7352200422920936455", 133904381)

-- Missing Depots (We don't have the keys yet lol): 1323862
