-- Lua provided by SkyAPI 
-- Game: AppID 1508060
addappid(1508060)
addappid(1508061, 1, "dd2b24fb3214b7dba760477996c1ab331d9758de838b4162d122d525309ededc")
