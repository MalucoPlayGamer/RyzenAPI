-- Lua provided by RyzenAPI
-- Game: addappid(1508060)

-- MAIN APPLICATION
addappid(1508060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508061, 1, "dd2b24fb3214b7dba760477996c1ab331d9758de838b4162d122d525309ededc")
