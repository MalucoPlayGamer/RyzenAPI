-- Lua provided by RyzenAPI
-- Game: Strange Zoo

-- MAIN APPLICATION
addappid(4210110) -- Strange Zoo

-- MAIN APP DEPOTS / PACKAGES
addappid(4210111, 1, "d642fbeed57c191eb7fb6015b9980278bd97edcc4f94b74369424a6decc4a666") -- Depot 4210111

