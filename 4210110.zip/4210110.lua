-- 4210110's Lua and Manifest Created by Hubcap Manifest
-- Strange Zoo
-- Created: August 22, 2026 at 02:03:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4210110) -- Strange Zoo
-- MAIN APP DEPOTS
addappid(4210111, 1, "d642fbeed57c191eb7fb6015b9980278bd97edcc4f94b74369424a6decc4a666") -- Depot 4210111
setManifestid(4210111, "8043395211944721403", 281410448)