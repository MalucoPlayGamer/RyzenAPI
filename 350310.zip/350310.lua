-- Lua provided by RyzenAPI
-- Game: Game: AppID 350310

-- MAIN APPLICATION
addappid(350310)
addappid(363910)
addappid(363911)
-- Game: addappid(350310)

-- MAIN APP DEPOTS / PACKAGES
addappid(350311, 1, "7d4182ace264a26383af8733bfa078a4388bc7a6a40d3ad3aabb0376a770d954")
