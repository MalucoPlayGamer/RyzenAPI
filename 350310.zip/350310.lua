-- Lua provided by RyzenAPI
-- Game: BLADESTORM: Nightmare

-- MAIN APPLICATION
addappid(350310)
addappid(363910)
addappid(363911)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(350311, 1, "7d4182ace264a26383af8733bfa078a4388bc7a6a40d3ad3aabb0376a770d954")

