-- Lua provided by RyzenAPI
-- Game: addappid(1452200)

-- MAIN APPLICATION
addappid(1452200)
addappid(1587450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452201, 1, "e495fdcd1670ea67d322ded18b5bc0f885c57d76d6b5973601c38ee935be7743")
