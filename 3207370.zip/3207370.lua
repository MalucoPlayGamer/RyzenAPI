-- Lua provided by SkyAPI 
-- Game: Freddy Farmer
addappid(3207370)
addappid(3207371, 1, "f6548eeae0ae79859211eb8ede70af5d9c757d7132f16155ba16b5f531c658eb")
