-- Lua provided by RyzenAPI
-- Game: Study With Me: Lofi Vibes

-- MAIN APPLICATION
addappid(3830160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3830161, 1, "c970cdd8cdd42f3ffc6b1ed7cbedc0168fab618fc120282972654506957a6436")

