-- Lua provided by RyzenAPI
-- Game: 3830160

-- MAIN APPLICATION
addappid(3830160)
-- Game: addappid(3830160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3830161, 1, "c970cdd8cdd42f3ffc6b1ed7cbedc0168fab618fc120282972654506957a6436")
