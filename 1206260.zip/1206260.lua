-- Lua provided by RyzenAPI
-- Game: addappid(1206260)

-- MAIN APPLICATION
addappid(1206260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206261, 1, "9cae36852b43e18b24f38561ef213774dba84f26498eefd1638bd8b73c11e5d9")
