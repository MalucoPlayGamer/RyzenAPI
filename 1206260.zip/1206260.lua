-- Lua provided by RyzenAPI
-- Game: Pilfer

-- MAIN APPLICATION
addappid(1206260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1206261, 1, "9cae36852b43e18b24f38561ef213774dba84f26498eefd1638bd8b73c11e5d9")

