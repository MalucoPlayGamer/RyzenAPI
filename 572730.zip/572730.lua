-- Lua provided by RyzenAPI
-- Game: Nancy Drew: The Silent Spy

-- MAIN APPLICATION
addappid(572730)
addappid(954140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(572731, 1, "c9a69a388a75131dca4cd70c27315f95a1eba94378f185a0bbbc6d334d070317")
