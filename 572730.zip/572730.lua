-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: The Silent Spy

-- MAIN APPLICATION
addappid(572730)
-- Game: addappid(572730)

-- MAIN APP DEPOTS / PACKAGES
addappid(572731, 1, "c9a69a388a75131dca4cd70c27315f95a1eba94378f185a0bbbc6d334d070317")
