-- Lua provided by RyzenAPI
-- Game: Strike Vector EX

-- MAIN APPLICATION
addappid(476360)

-- MAIN APP DEPOTS / PACKAGES
addappid(476361, 1, "18f6fcfa750c7c44cad118d9a5666ce0c487f0be839e92761633bca1c885fb5c")

