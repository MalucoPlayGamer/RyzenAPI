-- Lua provided by RyzenAPI
-- Game: daydream 白日夢

-- MAIN APPLICATION
addappid(1903370)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1964640)
