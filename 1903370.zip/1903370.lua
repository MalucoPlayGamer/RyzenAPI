-- Lua provided by RyzenAPI
-- Game: daydream 白日夢

-- MAIN APPLICATION
addappid(1903370)
