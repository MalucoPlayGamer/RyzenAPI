-- Lua provided by RyzenAPI
-- Game: Mýrdalssandur, Iceland

-- MAIN APPLICATION
addappid(1248990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248991, 1, "c4fe78953e9e14b53b31614636aa1867a21a2744d074674a26d6c1b05bfd81e8")
addappid(1249000, 1, "6fb0f5445eab48ea96ef6e9319e27173fa44317fbbbb36e017a85a88e1fe1e2d")
