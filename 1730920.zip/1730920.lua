-- Lua provided by RyzenAPI
-- Game: Hatch

-- MAIN APPLICATION
addappid(1730920)
-- Game: addappid(1730920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730921, 1, "86125b8fac0ce0d6e6764f3c8239b03c2779f08cdc3a080048a918b9f507c893")
