-- Lua provided by RyzenAPI
-- Game: 攻上凌霄宝殿

-- MAIN APPLICATION
addappid(3578480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578481, 1, "f369d46a405f1b95b5d474299461bd62798779f65db744eaed9d89dd2a23e3b0")

