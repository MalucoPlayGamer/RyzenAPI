-- Lua provided by RyzenAPI
-- Game: ScudBuster

-- MAIN APPLICATION
addappid(425010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(425011, 1, "7c1a981800010cdf902e49bc28861284d3e029964913b9780613f6597db2c11e")
