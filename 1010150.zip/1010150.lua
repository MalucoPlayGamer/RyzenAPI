-- Lua provided by RyzenAPI
-- Game: AppID 1010150

-- MAIN APPLICATION
addappid(1010150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010151, 1, "0895cb08e63cfb3411fb2a1f1f398b4cfd5ccfe13936f0af0719dcfc62d38888")
