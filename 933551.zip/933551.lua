-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Weapons Samurai Warriors Pack 1

-- MAIN APPLICATION
addappid(933551)
-- Game: addappid(933551)

-- MAIN APP DEPOTS / PACKAGES
addappid(933551,0,"86b611b0bf9b81da97045fd10729a84964450bff489b5dbe44ab2686220582a8")
