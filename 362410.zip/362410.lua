-- Lua provided by RyzenAPI
-- Game: addappid(362410)

-- MAIN APPLICATION
addappid(362410)

-- MAIN APP DEPOTS / PACKAGES
addappid(362411, 1, "89219c2ee9d5971df2368938f5b332bffae384dd4e357f99d706021cb6f66eb8")
