-- Lua provided by RyzenAPI
-- Game: PortalSnake

-- MAIN APPLICATION
addappid(2614480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614481, 1, "f4270b43b17420cfafc3a5cd73f596fc546ab2f6ac52d05955e72bb4c5b2ac11")

