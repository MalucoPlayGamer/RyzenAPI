-- Lua provided by RyzenAPI
-- Game: Cats and Seek: Tokyo

-- MAIN APPLICATION
addappid(2925320)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3545910)
