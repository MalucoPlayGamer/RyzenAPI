-- Lua provided by RyzenAPI
-- Game: Cats and Seek: Tokyo

-- MAIN APPLICATION
addappid(2925320)
