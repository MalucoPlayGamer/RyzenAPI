-- Lua provided by RyzenAPI
-- Game: Goblet of Maya

-- MAIN APPLICATION
addappid(557790)

-- MAIN APP DEPOTS / PACKAGES
addappid(557791, 1, "3795c12e3d86519c5e0f6f09978f52061d8872e92129448d2c15eb14b2b78913")

