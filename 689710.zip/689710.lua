-- Lua provided by RyzenAPI
-- Game: AppID 689710

-- MAIN APPLICATION
addappid(689710)

-- MAIN APP DEPOTS / PACKAGES
addappid(689711, 1, "779a008bae378950cbf3af3e52b5cb062455253a91db63ffa1efab828142bb6a")
