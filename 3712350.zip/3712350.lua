-- Lua provided by RyzenAPI
-- Game: Tiny Train Adventures

-- MAIN APP DEPOTS / PACKAGES
addappid(3712350, 1, "05b1e776d6937333bf2f8e914c2be60bf91e306bcc5e5cc650977c5f5da65c54") -- Tiny Train Adventures
addappid(3712351, 1, "7a5407cc012a6f3156404ef074f53e09d8237afbf5922d4bdc8b0c7996dfb1b6") -- Depot 3712351
