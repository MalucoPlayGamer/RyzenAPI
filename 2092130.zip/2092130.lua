-- Lua provided by RyzenAPI
-- Game: Notes From Province

-- MAIN APPLICATION
addappid(2092130)
addappid(2116720)

