-- Lua provided by RyzenAPI
-- Game: Notes From Province

-- MAIN APPLICATION
addappid(2092130)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2116720)
