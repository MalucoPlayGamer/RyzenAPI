-- Lua provided by RyzenAPI
-- Game: Notes From Province

-- MAIN APPLICATION
addappid(2092130)

