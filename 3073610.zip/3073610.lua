-- Lua provided by RyzenAPI
-- Game: WARCANA - Original Soundtrack

-- MAIN APPLICATION
addappid(3073610)
-- Game: addappid(3073610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073611, 1, "c6e811f8d7cbc7215031d6dc2f1e4c473ce43590464de8b7619dcb7c18b7e75e")
addappid(3073612, 1, "1107aa6a7a8c49dd1570f5ac078185b386d2d81f7aba576d9c57cc0fd9c1f597")
