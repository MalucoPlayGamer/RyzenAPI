-- Lua provided by RyzenAPI
-- Game: Killer Inside Us

-- MAIN APPLICATION
addappid(1440280)
addappid(1449610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440281, 1, "013ea5d39e0440f9980303b7d104c0022a85346054720bc2facce3a3a93c7979")
