-- Lua provided by SkyAPI 
-- Game: Killer Inside Us
addappid(1440280)
addappid(1440281, 1, "013ea5d39e0440f9980303b7d104c0022a85346054720bc2facce3a3a93c7979")
addappid(1449610)
