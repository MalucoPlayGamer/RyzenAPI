-- Lua provided by RyzenAPI
-- Game: AppID 890110

-- MAIN APPLICATION
addappid(890110)
-- Game: addappid(890110)

-- MAIN APP DEPOTS / PACKAGES
addappid(890111, 1, "8ffd7ad88d93030270ec212cc212559b058d9857722c143b7120f0f3366f9bac")
