-- Lua provided by RyzenAPI
-- Game: The Survivalists

-- MAIN APPLICATION
addappid(897450)
addappid(1256750)
addappid(4094590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(897451,0,"df0e26a2550f9f01d966469a8644b16bdab4ff313d46eda71b8fdd4c75fbb1bb")
addappid(1378760,0,"d0db88f4fc0da49bb2a4bb7db3695cec059a5e8cb791fd5b860665e7af0a9473")

