-- Lua provided by RyzenAPI 
-- Game: The Survivalists
addappid(897450)
addappid(897451, 1, "df0e26a2550f9f01d966469a8644b16bdab4ff313d46eda71b8fdd4c75fbb1bb")
addappid(1378760, 0, "d0db88f4fc0da49bb2a4bb7db3695cec059a5e8cb791fd5b860665e7af0a9473")
