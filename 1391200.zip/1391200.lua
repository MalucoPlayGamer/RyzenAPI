-- Lua provided by RyzenAPI 
-- Game: Pixel With Your Friends
addappid(1391200)
addappid(1391201, 1, "21a110d4be324cd5b9c44e21b3a71faf393a931f3f215cad9380c8faf95dc954")
