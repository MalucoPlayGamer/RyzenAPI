-- Lua provided by RyzenAPI
-- Game: Rhythm Sprout: Sick Beats & Bad Sweets

-- MAIN APPLICATION
addappid(1475840)
-- Game: addappid(1475840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475841, 1, "1b19e096c75d5aca515f0428b90893ccd9501ce9381ef877adec443589400062")
