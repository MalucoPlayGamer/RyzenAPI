-- Lua provided by RyzenAPI
-- Game: Deadlink

-- MAIN APPLICATION
addappid(1676130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676131, 1, "6492f8579a35f124675e856a40676b1b9300caf4c19a63906aa10a52df244a69")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
