-- Lua provided by RyzenAPI
-- Game: Game: Deadlink

-- MAIN APPLICATION
addappid(1676130)
-- Game: addappid(1676130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676131, 1, "6492f8579a35f124675e856a40676b1b9300caf4c19a63906aa10a52df244a69")
