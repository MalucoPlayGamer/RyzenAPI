-- Lua provided by RyzenAPI
-- Game: Truck Mechanic Simulator 2015

-- MAIN APPLICATION
addappid(331880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(331881, 1, "64c6c2c457589ba191a1deeb2c85bae5a7442d49a9e4b494e3a8289f9a6fa18b")
addappid(331882, 1, "5cc7dcd0c9e8a1be282c138f38b6938abd39c87b14e58323e02ec1ed635a0c21")

