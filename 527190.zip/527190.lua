-- Lua provided by RyzenAPI
-- Game: WORLD END ECONOMiCA episode.03

-- MAIN APPLICATION
addappid(527190)
addappid(782542)
addappid(782543)

-- MAIN APP DEPOTS / PACKAGES
addappid(527191, 1, "b926b1fc67c2bae5f8ded0d6db14ae6ed3cb53c3d6e4ea73bbbc941cbf57631e")
addappid(527192, 1, "1e48b7203819b62dd7da294a2a58bc97792646eef1903d21c0178dd8187015c9")
addappid(782541, 0, "53c8a1d4d4f9a9d290cbebb9252fe704105e65577f71dcc3f188dca0b3a4e3f4")

