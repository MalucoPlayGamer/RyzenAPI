-- Lua provided by RyzenAPI
-- Game: Secret Camera Tenant Pack1

-- MAIN APPLICATION
addappid(1933710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933710,0,"118abcb062288abd39e7a1e2d7ccc6f7ac95491abc451d5ac423f1d49ac51375")

