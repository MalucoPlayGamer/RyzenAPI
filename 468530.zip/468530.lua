-- Lua provided by RyzenAPI
-- Game: addappid(468530)

-- MAIN APPLICATION
addappid(468530)
addappid(542380)

-- MAIN APP DEPOTS / PACKAGES
addappid(468531, 1, "552b97c06b2d69c4cb8fc81cce760b99513e1a08aad001f3dd2182c71c6c0e5e")
addappid(468532, 1, "f67bc4bc0f06d0f5ae409d570c494797509b44b3e987b26ddb3792d7f68526a0")
