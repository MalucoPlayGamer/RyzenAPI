-- Lua provided by RyzenAPI
-- Game: AppID 468530

-- MAIN APPLICATION
addappid(468530)
addappid(542380)

-- MAIN APP DEPOTS / PACKAGES
addappid(468531, 1, "552b97c06b2d69c4cb8fc81cce760b99513e1a08aad001f3dd2182c71c6c0e5e")
addappid(468532, 1, "f67bc4bc0f06d0f5ae409d570c494797509b44b3e987b26ddb3792d7f68526a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
