-- Lua provided by RyzenAPI
-- Game: - Arcane RERaise -

-- MAIN APPLICATION
addappid(603770)

-- MAIN APP DEPOTS / PACKAGES
addappid(603771, 1, "45f53d9bd58a9f3f57f90af1782f07a00e19e6339a2c5efddf297da78a758dc8")
addappid(611920, 0, "ddac2e4cb872ec3aa6fd6014189c82b15b4a2eb0910d0fad3108196e14fbd1b6")
addappid(611921, 0, "0810e78e298afc5ba43858975c2de30e9fcca937e224bf6342c7d09ef37e455b")
addappid(611922, 0, "7221b89bd74214c355e9399c16583b48eeff0ede8fd2373bbe248439d311a7ad")
addappid(611923, 0, "eec3a94e1747f5f4af8d7fea1d02a94f3e986ee872af45e8570f30b5993c6ad0")
addappid(611924, 0, "f28d227ccf4dce878f6b643e43d1fbab8ce4fb42d904f3d7fbd56dbd9b0e8515")
addappid(611925, 0, "a9dd1fa7d72088775c5ed9a0f5e5fcfdfbc2bcc675811cb157a6d2b2bac2a35d")
addappid(611940, 0, "c6a4eebf937e8b3530bb985e058eb0901fab67a28695ba2b2af46ba074e10c32")
addappid(611941, 0, "b9cbe6e627b2274f94272ed191406871ded20d8486600c3f98a08209b71ff236")
addappid(611942, 0, "f6f71f6ba23505cfdcfa0b86a397044b8107f472301e6e36a7c3cd4bafcdef6b")
