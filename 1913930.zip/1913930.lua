-- Lua provided by RyzenAPI
-- Game: Nine Sols Soundtrack

-- MAIN APPLICATION
addappid(1913930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913931, 1, "c42d1d308472f2bdfb55854a826148354354932fa0dc80fcb9fbc3bdbd805c40")
addappid(1913932, 1, "cf359cf7ac3fc6baee747e7e03d62fe991ec60c75ca8d9630fa173c13b9f4f76")

