-- Lua provided by RyzenAPI
-- Game: Narborion Saga

-- MAIN APPLICATION
addappid(581340)

-- MAIN APP DEPOTS / PACKAGES
addappid(581341, 1, "ea2955e2d794c0a2430140c7dccc5615061814701045601a1ab319fa704c1cfb")
