-- Lua provided by RyzenAPI
-- Game: Curse of the Sea Rats

-- MAIN APPLICATION
addappid(1453900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453901, 1, "a1762c219ede8c1a1e369377ef627781aea930f8b8da2d9ff1f4197ad6894187")
