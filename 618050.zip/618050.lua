-- Lua provided by RyzenAPI
-- Game: To The Light

-- MAIN APPLICATION
addappid(618050)
-- Game: addappid(618050)

-- MAIN APP DEPOTS / PACKAGES
addappid(618051, 1, "ede13f13f8b75857bdabeb6cd4c47a1d14672146c9c71a4c12122e734d041ef1")
addappid(996360, 0, "4cc7247b8cd99818dc6e6500200c01b8b80e494d796103c60671d203c495734d")
