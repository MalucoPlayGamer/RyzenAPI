-- Lua provided by RyzenAPI
-- Game: addappid(2934880)

-- MAIN APPLICATION
addappid(2934880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934881, 1, "e5089daa76ccddf24acb57fc136b0f8e3f19507b0347fe194c77d0404af799ea")
