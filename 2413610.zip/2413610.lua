-- Lua provided by RyzenAPI
-- Game: Jumplight Odyssey Demo

-- MAIN APPLICATION
addappid(2413610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413611, 1, "ce8541b622f705b2872e4ec4613c9247e065623456bb148794f88a8056dc8235")

