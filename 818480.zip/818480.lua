-- Lua provided by RyzenAPI
-- Game: 818480

-- MAIN APPLICATION
addappid(818480)
-- Game: addappid(818480)

-- MAIN APP DEPOTS / PACKAGES
addappid(818481, 1, "34a809a0068dedf4111dc71a24026f420dcc094bdb6df6b5960e6af34955945e")
