-- Lua provided by RyzenAPI
-- Game: Gimbal Gravity

-- MAIN APPLICATION
addappid(548390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(548391,0,"37c4ed12f335d66e6ecea84cfb6a0704dc1ebb31651aa4f648120bbbbd6f7e4d")
addappid(548392,0,"a18f9f9dde6392c3b7183acc2d10f006fc6ae916566e256ec726a5377ecbc82c")

