-- Lua provided by RyzenAPI
-- Game: Gimbal Gravity

-- MAIN APPLICATION
addappid(548390)

-- MAIN APP DEPOTS / PACKAGES
addappid(548391,0,"37c4ed12f335d66e6ecea84cfb6a0704dc1ebb31651aa4f648120bbbbd6f7e4d")
addappid(548392,0,"a18f9f9dde6392c3b7183acc2d10f006fc6ae916566e256ec726a5377ecbc82c")

