-- Lua provided by RyzenAPI
-- Game: Ancestors Legacy - Digital Soundtrack

-- MAIN APPLICATION
addappid(799331)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244290,0,"289d7502032f6b1c3997d4591c91fb8af3d0a651bb7d9a2e0a693f91a73756a2")
addappid(1244291,0,"507f9beac37897aa204be8bb89caf44db971691efe67057b8425f26c222e7b8d")
