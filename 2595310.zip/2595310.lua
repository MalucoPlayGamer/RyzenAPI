-- Lua provided by RyzenAPI
-- Game: 2595310

-- MAIN APPLICATION
addappid(2595310)
-- Game: addappid(2595310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595311, 1, "db33713dadafc732eb936c958fbb6ff2fc552ad10aadcfef78ab2a2731ad8724")
