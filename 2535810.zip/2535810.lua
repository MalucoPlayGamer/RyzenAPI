-- Lua provided by SkyAPI 
-- Game: Last Resort
addappid(2535810)
addappid(2535811, 1, "ebd5ee5a381e13488e7f98bf80ff6b8c0e34da63ef46f7011eac2c89ebbae64b")
