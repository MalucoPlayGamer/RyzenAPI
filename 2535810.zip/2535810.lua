-- Lua provided by RyzenAPI
-- Game: Game: Last Resort

-- MAIN APPLICATION
addappid(2535810)
-- Game: addappid(2535810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535811, 1, "ebd5ee5a381e13488e7f98bf80ff6b8c0e34da63ef46f7011eac2c89ebbae64b")
