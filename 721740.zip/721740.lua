-- Lua provided by RyzenAPI
-- Game: Sea Of Fatness

-- MAIN APPLICATION
addappid(721740)

-- MAIN APP DEPOTS / PACKAGES
addappid(721742,0,"54929d9dbf2dfcbe53f02eecf270bca25e24da62db3a16b194773b9731d35c24")
addappid(721743,0,"5af32275f9937ea50267d0f58d739d328447cf3114df148f94fdb36bddb2ac54")
addappid(721744,0,"ef0446d7c74dbe4c9ef3e0d52ea34e552d5f11453c806a3e80ba59973811aa8b")

