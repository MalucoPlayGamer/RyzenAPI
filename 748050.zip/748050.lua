-- Lua provided by RyzenAPI
-- Game: addappid(748050)

-- MAIN APPLICATION
addappid(748050)

-- MAIN APP DEPOTS / PACKAGES
addappid(748051, 1, "14da25de6b400082d7cc4374e21acf276e1b9bf8a56facf0df17bb2a274b2a48")
