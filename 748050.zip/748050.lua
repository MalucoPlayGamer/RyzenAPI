-- Lua provided by RyzenAPI 
-- Game: Initiation
addappid(748050)
addappid(748051, 1, "14da25de6b400082d7cc4374e21acf276e1b9bf8a56facf0df17bb2a274b2a48")
