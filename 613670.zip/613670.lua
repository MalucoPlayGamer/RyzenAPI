-- Lua provided by RyzenAPI
-- Game: The Chronicles of Dragon Wing - Reborn

-- MAIN APPLICATION
addappid(613670)
addappid(650790)
addappid(650910)
addappid(675420)
addappid(675430)
addappid(772280)

-- MAIN APP DEPOTS / PACKAGES
addappid(613671, 1, "7568c384cc9903909cb1caffa17b859b6098d940462d2b4385b9ab341a3947a3")
addappid(675600, 0, "8ad8fac02e1615a1f1f2a3855e16727df240666a824283315eb42331b6a4d3ba")

