-- Lua provided by RyzenAPI
-- Game: addappid(887190)

-- MAIN APPLICATION
addappid(887190)

-- MAIN APP DEPOTS / PACKAGES
addappid(887191, 1, "44b9ca3a0a4d547efa87c25f5406ef6b1d0fdbf79d0c3f6a4d9ee4752e43796d")
