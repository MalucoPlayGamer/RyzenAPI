-- Lua provided by RyzenAPI 
-- Game: Cricket Captain 2018 Demo
addappid(887190)
addappid(887191, 1, "44b9ca3a0a4d547efa87c25f5406ef6b1d0fdbf79d0c3f6a4d9ee4752e43796d")
