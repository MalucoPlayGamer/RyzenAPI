-- Lua provided by RyzenAPI
-- Game: addappid(3037410)

-- MAIN APPLICATION
addappid(3037410)
addappid(3453550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037411, 1, "9eed10fe299d3828e23f2b2bccb218676a85d92a15f24f79617985a1fe344101")
