-- Lua provided by RyzenAPI
-- Game: 8-Bit Invaders!

-- MAIN APPLICATION
addappid(531680)

-- MAIN APP DEPOTS / PACKAGES
addappid(531681, 1, "3c790940d36546d1914f2ab67b09ab22b1f1aa20e1a45f89762c2380b49be880")
