-- Lua provided by RyzenAPI
-- Game: 8-Bit Invaders!

-- MAIN APPLICATION
addappid(531680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(531681, 1, "3c790940d36546d1914f2ab67b09ab22b1f1aa20e1a45f89762c2380b49be880")