-- Lua provided by RyzenAPI
-- Game: Game: Neon Abyss

-- MAIN APPLICATION
addappid(788100)
-- Game: addappid(788100)

-- MAIN APP DEPOTS / PACKAGES
addappid(788101, 1, "1524d54ee8d4105840022012751ba42ac9d631c069c91f661f0869a5801a146e")
