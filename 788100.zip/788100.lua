-- Lua provided by RyzenAPI
-- Game: Neon Abyss

-- MAIN APPLICATION
addappid(788100)
addappid(1262000)
addappid(1518790)
addappid(1851340)

-- MAIN APP DEPOTS / PACKAGES
addappid(788101,0,"1524d54ee8d4105840022012751ba42ac9d631c069c91f661f0869a5801a146e")

