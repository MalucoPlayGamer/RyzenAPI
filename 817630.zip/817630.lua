-- Lua provided by RyzenAPI
-- Game: Island Tribe 3

-- MAIN APPLICATION
addappid(817630)

-- MAIN APP DEPOTS / PACKAGES
addappid(817631, 1, "61ca30db98bcdc11cad6f75ccdf04c3446a85b88b818cb4cbcf2639073401fab")

