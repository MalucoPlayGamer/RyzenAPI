-- Lua provided by SkyAPI 
-- Game: AppID 817630
addappid(817630)
addappid(817631, 1, "61ca30db98bcdc11cad6f75ccdf04c3446a85b88b818cb4cbcf2639073401fab")
