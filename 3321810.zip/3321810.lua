-- Lua provided by RyzenAPI
-- Game: 3321810

-- MAIN APPLICATION
addappid(3321810)
-- Game: addappid(3321810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321811, 1, "313a008403c6c655ec569ee306b0c2eea447d4a319cfe1ad4dcc3fc6e6cba12c")
addappid(3321812, 1, "09c2d44bce1bad341ec3532977c963f0820b05d81764ca376d626f109bb66f9b")
