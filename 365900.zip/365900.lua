-- Lua provided by RyzenAPI
-- Game: Pixel Dungeon

-- MAIN APPLICATION
addappid(365900)

-- MAIN APP DEPOTS / PACKAGES
addappid(365902,0,"1dff27369d7849959400fb97d3848db0a5d2068b6fa3032e0fa2516536fdc102")

