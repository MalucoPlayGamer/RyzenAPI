-- Lua provided by RyzenAPI
-- Game: addappid(1644600)

-- MAIN APPLICATION
addappid(1644600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644601, 1, "4f2cd9bbcaf6be22db6fee0c6d2d52496eedae680df600710e5608b7f7a76516")
