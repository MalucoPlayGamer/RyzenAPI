-- Lua provided by RyzenAPI
-- Game: Strategic Command WWII: War in Europe

-- MAIN APPLICATION
addappid(593030)
-- Game: addappid(593030)

-- MAIN APP DEPOTS / PACKAGES
addappid(593031, 1, "4bc8413f71922e6c678d3f97146a58935a66a5b8cc3120f0419f8ce4fc5128ae")
addappid(732500, 0, "39d847ede89a1858c2329ee663a00d0342b9bfab2d340d8f856208e17d40c7e4")
