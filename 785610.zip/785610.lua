-- Lua provided by RyzenAPI
-- Game: AppID 785610

-- MAIN APPLICATION
addappid(785610)
-- Game: addappid(785610)

-- MAIN APP DEPOTS / PACKAGES
addappid(785611, 1, "5a5d3e470109796b3e02bb0d08cc4885ef4cdff4c4a8b0776fb6dd20934e27c5")
