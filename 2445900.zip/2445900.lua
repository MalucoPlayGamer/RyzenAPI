-- Lua provided by RyzenAPI
-- Game: Game: Succubuzz APP

-- MAIN APPLICATION
addappid(2445900)
-- Game: addappid(2445900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445901, 1, "0d6a7e30cff754b788817e12a4fe270e9bb933fd7173a55b169cc95c60d417fe")
