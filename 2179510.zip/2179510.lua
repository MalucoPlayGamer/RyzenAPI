-- Lua provided by RyzenAPI
-- Game: 2179510

-- MAIN APPLICATION
addappid(2179510)
-- Game: addappid(2179510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179511, 1, "1e9ee0385c05968c29f694bbd3650a298322d98ce365adf7fcc07068f00e65f6")
