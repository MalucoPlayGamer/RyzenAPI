-- Lua provided by RyzenAPI
-- Game: 446310

-- MAIN APPLICATION
addappid(446310)
-- Game: addappid(446310)

-- MAIN APP DEPOTS / PACKAGES
addappid(446311, 1, "417a32b2302f0f4aa1222ef7784b71c6ca992df031e44cc94ca3cd4e56aa6f67")
