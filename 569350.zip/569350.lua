-- Lua provided by RyzenAPI
-- Game: AppID 569350

-- MAIN APPLICATION
addappid(569350)
-- Game: addappid(569350)

-- MAIN APP DEPOTS / PACKAGES
addappid(569351, 1, "0ae915a6f57fe73fda60384bfb0a9323a27386a55b0b90d2780eede1442223aa")
