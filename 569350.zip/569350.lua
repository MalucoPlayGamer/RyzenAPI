-- Lua provided by SkyAPI 
-- Game: AppID 569350
addappid(569350)
addappid(569351, 1, "0ae915a6f57fe73fda60384bfb0a9323a27386a55b0b90d2780eede1442223aa")
