-- Lua provided by RyzenAPI
-- Game: RoboCritters

-- MAIN APPLICATION
addappid(569350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(569351, 1, "0ae915a6f57fe73fda60384bfb0a9323a27386a55b0b90d2780eede1442223aa")

