-- Lua provided by RyzenAPI
-- Game: Hard Love - Darkest Desire

-- MAIN APPLICATION
addappid(1135680)
-- Game: addappid(1135680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135681, 1, "a558942ae000c56634d66f8ffa04eace798b5eac84c4ba347206b3e45ce3f3fb")
