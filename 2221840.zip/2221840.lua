-- Lua provided by RyzenAPI
-- Game: Sex and the Furry Titty 3: Come Inside, Sweety

-- MAIN APPLICATION
addappid(2221840)
addappid(3985260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221841, 1, "9c64d8d4a97700162de3d91372d607c0b32e26b07eacac186762aaa29e0ef4ae")
addappid(2900390, 0, "a50332276e1a9600bd604be4c9fab3ae8197d96cf928ede8088b0e01ceb30213")
addappid(2900400, 0, "86a31dc32f27c42f1d68b0f6018136c2b8d7be96fafe313a544cdb398e6fc260")

