-- Lua provided by RyzenAPI
-- Game: Hot Swap: Cyberlust

-- MAIN APPLICATION
addappid(1740470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1740471, 1, "f328f1abb4d59983bece314c8e464b432a5e4af92cdf7babfe4113462a3d597f")

