-- Lua provided by RyzenAPI 
-- Game: Hot Swap: Cyberlust
addappid(1740470)
addappid(1740471, 1, "f328f1abb4d59983bece314c8e464b432a5e4af92cdf7babfe4113462a3d597f")
