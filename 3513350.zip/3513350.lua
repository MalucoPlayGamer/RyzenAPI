-- Lua provided by RyzenAPI
-- Game: Wuthering Waves

-- MAIN APPLICATION
addappid(3513350)
-- Game: addappid(3513350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3513351, 1, "6778f1059fd9d25eba753ff9611b28a0af891837e17b075d2d6649c715394003")
