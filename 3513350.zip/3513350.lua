-- Lua provided by RyzenAPI
-- Game: Wuthering Waves

-- MAIN APPLICATION
addappid(3513350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3513351, 1, "6778f1059fd9d25eba753ff9611b28a0af891837e17b075d2d6649c715394003")

