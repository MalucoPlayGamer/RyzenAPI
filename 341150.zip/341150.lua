-- Lua provided by RyzenAPI
-- Game: Age of Fear 2: The Chaos Lord GOLD

-- MAIN APPLICATION
addappid(341150)
-- Game: addappid(341150)

-- MAIN APP DEPOTS / PACKAGES
addappid(341151, 1, "024d02dbda756f5a20093d4f499443453be67b77b823c45a9fb7b7164aba4453")
addappid(577110, 0, "501cc0b616484fb372dd19657116bd6734a61a8d7b6736c2bd3c8156a86b89c9")
