-- Lua provided by RyzenAPI
-- Game: Claire

-- MAIN APPLICATION
addappid(3233130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3233131, 1, "2f340fd224774a7a57987aec247d7bedcd7dab06bc8224122eee0e46bda263ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
