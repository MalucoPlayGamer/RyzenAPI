-- Lua provided by RyzenAPI
-- Game: Claire

-- MAIN APPLICATION
addappid(3233130)
-- Game: addappid(3233130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3233131, 1, "2f340fd224774a7a57987aec247d7bedcd7dab06bc8224122eee0e46bda263ff")
