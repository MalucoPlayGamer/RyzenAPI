-- Lua provided by RyzenAPI
-- Game: Caught On Camera

-- MAIN APPLICATION
addappid(2526500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526501, 1, "17a714418c1d3c0257477380d09482f244a73e78f84a289bcda7c5ca4f843600")

