-- Lua provided by RyzenAPI
-- Game: ReDo

-- MAIN APPLICATION
addappid(3438770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438772,0,"2f456066654d99a6902f6be78d128ff5e9ce0b20f62ab6ff9efb083c2ff17da1")
