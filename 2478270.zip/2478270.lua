-- Lua provided by RyzenAPI
-- Game: Bongus Bright-eye & The Great Axe-stravaganza

-- MAIN APPLICATION
addappid(2478270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478271, 1, "424e10374cb7afd631edc2879b8bf7029d49ba46b5899e5056b2004b4f4ff460")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
