-- Lua provided by RyzenAPI
-- Game: Game: Bongus Bright-eye & The Great Axe-stravaganza

-- MAIN APPLICATION
addappid(2478270)
-- Game: addappid(2478270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478271, 1, "424e10374cb7afd631edc2879b8bf7029d49ba46b5899e5056b2004b4f4ff460")
