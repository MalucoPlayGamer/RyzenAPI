-- Lua provided by RyzenAPI
-- Game: Edge of Twilight – Return To Glory

-- MAIN APPLICATION
addappid(489070)
addappid(523040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(489071, 1, "ed33def0635d436b88c42604499fe302488178ff7b1f88645c02e268d2ef889f")

