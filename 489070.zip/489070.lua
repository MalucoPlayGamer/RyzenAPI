-- Lua provided by RyzenAPI
-- Game: addappid(489070)

-- MAIN APPLICATION
addappid(489070)
addappid(523040)

-- MAIN APP DEPOTS / PACKAGES
addappid(489071, 1, "ed33def0635d436b88c42604499fe302488178ff7b1f88645c02e268d2ef889f")
