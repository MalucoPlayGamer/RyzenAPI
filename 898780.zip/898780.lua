-- Lua provided by RyzenAPI
-- Game: Game: Escape Game

-- MAIN APPLICATION
addappid(898780)
-- Game: addappid(898780)

-- MAIN APP DEPOTS / PACKAGES
addappid(898781, 1, "5cedec4120f9c8192747d352e0aa37d2c9143be41c896880fd6e5cd75f8f3fde")
