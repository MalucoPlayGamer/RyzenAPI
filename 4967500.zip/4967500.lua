-- 4967500's Lua and Manifest Created by Hubcap Manifest
-- Tidy Mart
-- Created: August 13, 2026 at 10:29:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4967500) -- Tidy Mart
-- MAIN APP DEPOTS
addappid(4967501, 1, "6e8822414cfe1e0174627131c62f11ec08d8916779168071e558944ec5b33779") -- Depot 4967501
setManifestid(4967501, "426694593118049980", 436444676)
addappid(4967503, 1, "a47ab81056c2563b57b4d04c8a71aa463c8cc8a13e898e40b211f22a435b1b0b") -- Depot 4967503
setManifestid(4967503, "6582394668689922358", 427033699)