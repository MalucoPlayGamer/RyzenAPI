-- Lua provided by RyzenAPI
-- Game: addappid(1944280)

-- MAIN APPLICATION
addappid(1944280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944281, 1, "e8de5ea6295ad5a2d7dfd6a254db4f795b665290864bd7a1680a35d19157fb9b")
