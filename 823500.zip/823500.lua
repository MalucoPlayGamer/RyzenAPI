-- Lua provided by RyzenAPI
-- Game: addappid(823500)

-- MAIN APPLICATION
addappid(823500)

-- MAIN APP DEPOTS / PACKAGES
addappid(823501, 1, "bd62786d436b7bc794ccc6f50cdcfc4c47c11029fbbc4751de27d12fb8fe8622")
