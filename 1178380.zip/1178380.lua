-- Lua provided by SkyAPI 
-- Game: AppID 1178380
addappid(1178380)
addappid(1178381, 1, "393a23d1fa8401cc892374bf031220367ce4c7bcd6a34e2024336c0e37fd2640")
