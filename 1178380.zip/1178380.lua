-- Lua provided by RyzenAPI
-- Game: Resurrector

-- MAIN APPLICATION
addappid(1178380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178381, 1, "393a23d1fa8401cc892374bf031220367ce4c7bcd6a34e2024336c0e37fd2640")
