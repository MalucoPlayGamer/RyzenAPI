-- Lua provided by RyzenAPI
-- Game: Plantera

-- MAIN APPLICATION
addappid(421040)

-- MAIN APP DEPOTS / PACKAGES
addappid(421041, 1, "7cc5811cee7ba21a4935b8bcded31ad76d951429790890def47adf75c0d8dd66")
