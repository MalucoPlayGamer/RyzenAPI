-- Lua provided by RyzenAPI
-- Game: Mysteries of Neverville: The Runestone of Light

-- MAIN APPLICATION
addappid(994870)
-- Game: addappid(994870)

-- MAIN APP DEPOTS / PACKAGES
addappid(994871, 1, "b9e419a484daa04275847762242e5b883d9504963fd15302d5d4c6310723b88b")
addappid(994872, 1, "5480e398d75d985d61d10e05e32244ed485d8806dd552bc235a7e969a8b372ea")
