-- Lua provided by RyzenAPI
-- Game: Tracery of Fate

-- MAIN APPLICATION
addappid(1710670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710671, 1, "a3728d729ddaddacccea2572a459a9a7a68d2ae6584e1d9a1aa00be6675b3e8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
