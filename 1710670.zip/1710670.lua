-- Lua provided by RyzenAPI
-- Game: addappid(1710670)

-- MAIN APPLICATION
addappid(1710670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710671, 1, "a3728d729ddaddacccea2572a459a9a7a68d2ae6584e1d9a1aa00be6675b3e8c")
