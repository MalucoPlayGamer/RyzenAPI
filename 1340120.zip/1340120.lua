-- Lua provided by RyzenAPI 
-- Game: AppID 1340120
addappid(1340120)
addappid(1340121, 1, "79c8b69f3c965d7e23dfc892d5b888da375ebf78268f3d278cc97b879711e0c7")
