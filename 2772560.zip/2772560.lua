-- Lua provided by RyzenAPI
-- Game: Supermarket Simulator: Prologue

-- MAIN APPLICATION
addappid(2772560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772561, 1, "3da4d45a57b2cd22a80b355018508092a907a78926739b69b6bc921d26dbf3da")

