-- Lua provided by RyzenAPI
-- Game: All You Need is Help (Free Trial)

-- MAIN APPLICATION
addappid(3040730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040731, 1, "42ac45322c2490def6801404054b18515dc46de3477332e5a011ee955c1183ea")

