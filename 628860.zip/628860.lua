-- Lua provided by RyzenAPI
-- Game: addappid(628860)

-- MAIN APPLICATION
addappid(628860)

-- MAIN APP DEPOTS / PACKAGES
addappid(628861, 1, "bfe97ee6ce259f5e96a4b08dabb847d92ccb14f8076a2dd4e4b261d86d55ffef")
