-- Lua provided by RyzenAPI
-- Game: AppID 698460

-- MAIN APPLICATION
addappid(698460)

-- MAIN APP DEPOTS / PACKAGES
addappid(698461, 1, "39b102bcd32ba4ffaaf34164f4ff86ea26fecc868c594abe322a11b532724543")
