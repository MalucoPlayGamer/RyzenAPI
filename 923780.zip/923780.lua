-- Lua provided by RyzenAPI
-- Game: 923780

-- MAIN APPLICATION
addappid(923780)
-- Game: addappid(923780)

-- MAIN APP DEPOTS / PACKAGES
addappid(923781, 1, "6b2cb866d1a16b5d6fe516d7bfac50917854d4ed08cb3b51f7a900a8c0a7f754")
