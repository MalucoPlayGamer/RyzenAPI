-- Lua provided by RyzenAPI
-- Game: 2281470

-- MAIN APPLICATION
addappid(2281470)
-- Game: addappid(2281470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281471, 1, "15085feb8968fceada0470a1ccfe2e1486978718317d0bb92b278dc24cba0787")
