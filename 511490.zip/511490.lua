-- Lua provided by RyzenAPI
-- Game: 511490

-- MAIN APPLICATION
addappid(511490)
-- Game: addappid(511490)

-- MAIN APP DEPOTS / PACKAGES
addappid(511491, 1, "d79c86d3cb5b1333b35133be10b6cafabcc9dfea3c22718b582f0dfca2e01378")
addappid(559890, 0, "41f87babf0d65c14147244af465993a5d598f11b065fd44297c78faa849a328e")
