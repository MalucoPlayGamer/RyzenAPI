-- Lua provided by RyzenAPI
-- Game: Malavision: The Beginning

-- MAIN APPLICATION
addappid(511490)

-- MAIN APP DEPOTS / PACKAGES
addappid(511491, 1, "d79c86d3cb5b1333b35133be10b6cafabcc9dfea3c22718b582f0dfca2e01378")
addappid(559890, 0, "41f87babf0d65c14147244af465993a5d598f11b065fd44297c78faa849a328e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
