-- Lua provided by RyzenAPI
-- Game: 1181630

-- MAIN APPLICATION
addappid(1181630)
-- Game: addappid(1181630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181630,0,"bfaa20557577c21ed55f02e2e18d71d6ef1b9ee1f6bc4d69d24f140144f3bb29")
