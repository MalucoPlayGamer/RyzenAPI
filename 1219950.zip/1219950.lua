-- Lua provided by RyzenAPI 
-- Game: AppID 1219950
addappid(1219950)
addappid(1219951, 1, "0223b734643c3d12a3fd73483414256d310a3bc44180a95d963f1c37b17d0548")
