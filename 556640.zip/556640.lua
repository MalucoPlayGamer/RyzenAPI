-- Lua provided by RyzenAPI
-- Game: AppID 556640

-- MAIN APPLICATION
addappid(556640)

-- MAIN APP DEPOTS / PACKAGES
addappid(556641, 1, "039ccae2122280fff2da563de8b26a4813688868e4354ab5aa8b7139bfbbf74a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
