-- Lua provided by RyzenAPI
-- Game: 556640

-- MAIN APPLICATION
addappid(556640)
-- Game: addappid(556640)

-- MAIN APP DEPOTS / PACKAGES
addappid(556641, 1, "039ccae2122280fff2da563de8b26a4813688868e4354ab5aa8b7139bfbbf74a")
