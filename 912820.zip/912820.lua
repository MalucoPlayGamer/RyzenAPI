-- Lua provided by RyzenAPI
-- Game: 912820

-- MAIN APPLICATION
addappid(912820)
-- Game: addappid(912820)

-- MAIN APP DEPOTS / PACKAGES
addappid(912821, 1, "91a0671b52f189615fb08b735941f1fac68c77a2fb07404c2f128f20414b44f1")
