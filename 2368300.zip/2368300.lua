-- Lua provided by RyzenAPI
-- Game: Warside

-- MAIN APPLICATION
addappid(2368300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368301, 1, "40f0f78b50871b3e8d950d42d569d9283ede65b4da0fc2dece4d8e0cfcd5f549")
addappid(2368302, 1, "2373f5521bb91b647fbe1052fca60931521ccc191bef4fc9d7304851e0840b1b")
