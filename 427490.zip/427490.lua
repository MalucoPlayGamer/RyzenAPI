-- Lua provided by RyzenAPI 
-- Game: Shadowhand: RPG Card Game
addappid(427490)
addappid(427491, 1, "ade73b870a46deae32aab201299564a0ae3afc280425236d935a7a816834e051")
addappid(427492, 1, "863d5dcc3551ece9b8865e2a72601c771819857ab449b34df5c7a45842bf8e0e")
addappid(427493, 1, "7de8e8a899764766d09aed6346eed7d81e61613268dc914bb3ab3c237dadd248")
