-- Lua provided by RyzenAPI
-- Game: Melody Mania

-- MAIN APPLICATION
addappid(2394070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394071, 1, "1fdf45dcfd05ab8bb2dbe8a5a4523600137e4914eb130a034f05845fa8d2320f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
