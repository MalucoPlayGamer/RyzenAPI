-- Lua provided by RyzenAPI
-- Game: 2394070

-- MAIN APPLICATION
addappid(2394070)
-- Game: addappid(2394070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394071, 1, "1fdf45dcfd05ab8bb2dbe8a5a4523600137e4914eb130a034f05845fa8d2320f")
