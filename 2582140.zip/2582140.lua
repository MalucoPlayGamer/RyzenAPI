-- Lua provided by RyzenAPI
-- Game: Seafarer: The Ship Sim

-- MAIN APPLICATION
addappid(2582140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582141, 1, "f40d0c88571b28f840178b77be55334a2e94510b18e939af7c2da27f9d855b4e")
