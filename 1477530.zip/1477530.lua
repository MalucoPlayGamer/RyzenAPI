-- Lua provided by RyzenAPI 
-- Game: VALIANT TACTICS EX
addappid(1477530)
addappid(1477531, 1, "da7ac51e8903544142f0b2b49e80c131d8c3a4cf3483a80f17119b66341a8366")
