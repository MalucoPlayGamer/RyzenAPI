-- Lua provided by RyzenAPI
-- Game: Abrissprofi Online

-- MAIN APPLICATION
addappid(823230)

-- MAIN APP DEPOTS / PACKAGES
addappid(823231, 1, "0f83303a06a815a2982a320df627c45305346b1eca9cf74d26b3cd1445222922")
