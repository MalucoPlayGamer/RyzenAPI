-- Lua provided by RyzenAPI
-- Game: Saint Maker - Horror Visual Novel

-- MAIN APPLICATION
addappid(1785300)
-- Game: addappid(1785300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785301, 1, "3cdd3b05f107492d1a560f7e6e1336943071cab8d7ba02d306a47973cbf0d9f3")
