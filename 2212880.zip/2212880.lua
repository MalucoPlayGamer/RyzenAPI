-- Lua provided by SkyAPI 
-- Game: Olho Adventure The DARK Series
addappid(2212880)
addappid(2212881, 1, "c5ec1b847ab9c092e7b714dfbdb1fa6cb788c2c4a7902a15eca5fe0d59ec1533")
