-- Lua provided by RyzenAPI
-- Game: Game: Olho Adventure The DARK Series

-- MAIN APPLICATION
addappid(2212880)
-- Game: addappid(2212880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2212881, 1, "c5ec1b847ab9c092e7b714dfbdb1fa6cb788c2c4a7902a15eca5fe0d59ec1533")
