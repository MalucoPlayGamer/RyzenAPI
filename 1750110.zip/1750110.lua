-- Lua provided by RyzenAPI
-- Game: Game: Frenzy VR

-- MAIN APPLICATION
addappid(1750110)
-- Game: addappid(1750110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750111, 1, "706384dd234e875100fcba55272d64d2f0233fbc1ee42e6af1ed8c3b3673d97e")
