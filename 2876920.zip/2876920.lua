-- Lua provided by RyzenAPI
-- Game: Baimason's Thing Finder Puzzle

-- MAIN APPLICATION
addappid(2876920) -- Baimason's Thing Finder Puzzle

-- MAIN APP DEPOTS / PACKAGES
addappid(2876921, 1, "dc5d52cd176f6431267cf52e1d8e5be865a3685027109d103d675ca4fe083720") -- Depot 2876921
