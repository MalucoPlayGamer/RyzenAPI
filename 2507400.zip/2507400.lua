-- Lua provided by RyzenAPI
-- Game: Game: Penny Blood: Hellbound

-- MAIN APPLICATION
addappid(2507400)
-- Game: addappid(2507400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507401, 1, "b1ddeead6f201c5966ccaff69ed71a0d506f16bfe59ba6ddc36aab0bef6509ec")
