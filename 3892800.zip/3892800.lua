-- Lua provided by RyzenAPI
-- Game: "Ta"

-- MAIN APPLICATION
addappid(3892800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3892801, 1, "f69d3942fc2b99abb3908b808fa59ff143a960f06fa8dc649db543961d0dfb53")

