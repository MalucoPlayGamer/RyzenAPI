-- Lua provided by RyzenAPI
-- Game: Fairy of the treasures - Soundtrack

-- MAIN APPLICATION
addappid(792360)
-- Game: addappid(792360)

-- MAIN APP DEPOTS / PACKAGES
addappid(792361, 1, "b158531a4498dc92bc3dff5a74339c9939b10c603a296823292f38bbe58ecd69")
