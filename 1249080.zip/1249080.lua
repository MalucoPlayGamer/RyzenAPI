-- Lua provided by RyzenAPI
-- Game: Game: Lynn , The Girl Drawn On Puzzles

-- MAIN APPLICATION
addappid(1249080)
addappid(1392279)
-- Game: addappid(1249080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249081, 1, "00507ec8d1e33f96b687161a87713065ebe5e6bc0dea4ac9cc492a29ebbc6bdb")
