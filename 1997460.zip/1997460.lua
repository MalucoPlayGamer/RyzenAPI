-- Lua provided by RyzenAPI
-- Game: 1997460

-- MAIN APPLICATION
addappid(1997460)
-- Game: addappid(1997460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997461, 1, "ccdbf59f237483205ac014255333b0895ceb8e8c558a83c3a02c3bd52dae8ebe")
