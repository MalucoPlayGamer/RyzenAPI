-- Lua provided by RyzenAPI
-- Game: STORROR Parkour Pro

-- MAIN APPLICATION
addappid(3125250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3125253,0,"7161c64494cbeb2a1d23e06b21436c98c8c2af403e0c720ddd4d2b9446ae1a12")

