-- Lua provided by RyzenAPI
-- Game: 3125250

-- MAIN APPLICATION
addappid(3125250)
-- Game: addappid(3125250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125253,0,"7161c64494cbeb2a1d23e06b21436c98c8c2af403e0c720ddd4d2b9446ae1a12")
