-- Lua provided by RyzenAPI
-- Game: The Letter - Original Soundtrack

-- MAIN APPLICATION
addappid(740370)
-- Game: addappid(740370)

-- MAIN APP DEPOTS / PACKAGES
addappid(740371, 1, "ba7aeffa7fd816e49d77822f2b0278488a7eed50dffad7f218e7bcf982bb0cb9")
