-- Lua provided by RyzenAPI
-- Game: Game: YOUR HOUSE

-- MAIN APPLICATION
addappid(2667740)
-- Game: addappid(2667740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667741, 1, "27ca5ca6ee7fb3c0ba8d06250f82cc682112b75260392c6f0435d90ccb891f00")
