-- Lua provided by SkyAPI 
-- Game: YOUR HOUSE
addappid(2667740)
addappid(2667741, 1, "27ca5ca6ee7fb3c0ba8d06250f82cc682112b75260392c6f0435d90ccb891f00")
