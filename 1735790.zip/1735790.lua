-- Lua provided by RyzenAPI
-- Game: Mystery Box: Hidden Secrets

-- MAIN APPLICATION
addappid(1735790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735794,0,"7946f75de636ad1880edd16aa25694e22115b768697d986a67d2bc5425cc673e")

