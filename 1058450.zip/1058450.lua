-- Lua provided by RyzenAPI
-- Game: 1058450

-- MAIN APPLICATION
addappid(1058450)
addappid(1228710)
addappid(1237520)
addappid(1237521)
addappid(1237522)
addappid(1237523)
addappid(1237524)
addappid(1237525)
addappid(1237526)
addappid(1237527)
addappid(1237528)
addappid(1283320)
addappid(1356490)
addappid(1358070)
addappid(1436770)
addappid(1436771)
addappid(1436772)
addappid(1499490)
addappid(1587400)
addappid(1677170)
addappid(1677171)
addappid(1708860)
addappid(1784330)
addappid(1839830)
addappid(1903570)
addappid(1951580)
-- Game: addappid(1058450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058451, 1, "9d9ec7b907faac61db554bc5e6d48e868f54f1efb823793ce6be6e6685715456")
