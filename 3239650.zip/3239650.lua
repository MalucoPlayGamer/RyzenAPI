-- Lua provided by RyzenAPI
-- Game: Garfield Kart 2 - All You Can Drift

-- MAIN APPLICATION
addappid(3239650)
-- Game: addappid(3239650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239651, 1, "3c0165d84de0f2b885c79d35ac1b1c9c9cc5953d909f2d0f678962131190a3d7")
