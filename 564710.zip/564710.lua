-- Lua provided by RyzenAPI
-- Game: Soda Dungeon

-- MAIN APPLICATION
addappid(564710)

