-- Lua provided by RyzenAPI
-- Game: 550370

-- MAIN APPLICATION
addappid(550370)
-- Game: addappid(550370)

-- MAIN APP DEPOTS / PACKAGES
addappid(550371, 1, "17c682540546304467c01fe6fffe89fc0435ac691f329a8bbfba132136b3d227")
