-- Lua provided by RyzenAPI
-- Game: Idle Hamburgers Save the World

-- MAIN APPLICATION
addappid(2194410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194411, 1, "67e47e55569c21314a54bd24d5cfa1bd59cce4a52d06d0922a065cd65d63d93b")
