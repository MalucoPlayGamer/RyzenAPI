-- Lua provided by RyzenAPI
-- Game: 2194410

-- MAIN APPLICATION
addappid(2194410)
-- Game: addappid(2194410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194411, 1, "67e47e55569c21314a54bd24d5cfa1bd59cce4a52d06d0922a065cd65d63d93b")
