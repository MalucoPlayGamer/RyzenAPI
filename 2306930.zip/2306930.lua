-- Lua provided by RyzenAPI
-- Game: addappid(2306930)

-- MAIN APPLICATION
addappid(2306930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306931, 1, "7abfe73b4e0e875117f33d370ec11261e3027a523364ca12a37e18dd5ee56059")
