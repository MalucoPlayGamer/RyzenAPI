-- Lua provided by RyzenAPI
-- Game: RPG Maker - PiXel ScaLer

-- MAIN APPLICATION
addappid(2306930)
-- Game: addappid(2306930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306931, 1, "7abfe73b4e0e875117f33d370ec11261e3027a523364ca12a37e18dd5ee56059")
