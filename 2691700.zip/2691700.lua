-- Lua provided by RyzenAPI
-- Game: addappid(2691700)

-- MAIN APPLICATION
addappid(2691700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691701, 1, "0f55117a6fe5b7af4f0ebaa153bfc13009c5c83622863ec2d2aa65497e049048")
