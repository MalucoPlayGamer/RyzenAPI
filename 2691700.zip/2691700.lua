-- Lua provided by RyzenAPI
-- Game: 28 Babes Later

-- MAIN APPLICATION
addappid(2691700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2691701, 1, "0f55117a6fe5b7af4f0ebaa153bfc13009c5c83622863ec2d2aa65497e049048")

