-- Lua provided by RyzenAPI
-- Game: Game: Mama Station

-- MAIN APPLICATION
addappid(3469990)
-- Game: addappid(3469990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3469991, 1, "51c6bb6e8adac2cf02ebe568c7256eb204b75b331a41f537239d9ae3c1fa244d")
