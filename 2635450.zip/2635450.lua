-- Lua provided by RyzenAPI
-- Game: Brotherhood

-- MAIN APPLICATION
addappid(2635450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2635451,0,"1f9277b5553b8c9fb2a294b1f5ff87a98907900496f30c54c123b2068573c519")

