-- Lua provided by SkyAPI 
-- Game: AppID 1150890
addappid(1150890)
addappid(1150891, 1, "794012bd99c5d53d112a5ccc780c18b059e1f9f9247aac8d3b741b1b329a2b18")
addappid(1150892, 1, "c975f5757915dfb8a8cac2ccaf5e499123b16f372c2558efec24d101a55b4057")
