-- Lua provided by RyzenAPI 
-- Game: Chaos Faction Legacy Collection
addappid(3038340)
addappid(3038341, 1, "365cf568b58c67bce7bab937cd5669dc29e2716bf2060f4a06b180d3c5cb5dab")
