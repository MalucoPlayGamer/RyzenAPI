-- Lua provided by SkyAPI 
-- Game: AppID 572510
addappid(572510)
addappid(572511, 1, "8c4b42d92f80a964ea5c5e433351316bdaaad21848fe54ef6a83001fca358fa3")
addappid(572512, 1, "1a142db2b4225176d3685565f96ac6d64cc8ea582d139dd439781ac74c0ad40d")
