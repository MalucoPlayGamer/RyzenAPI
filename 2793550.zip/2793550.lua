-- Lua provided by SkyAPI 
-- Game: Reel Fishing: Days of Summer
addappid(2793550)
addappid(2793551, 1, "a1732edbcde2a68d2193500eb1f058bb48acc66ed8f2faaa0f94fcc7b87be96c")
