-- Lua provided by RyzenAPI
-- Game: Game: Destroy All Humans! – Clone Carnage

-- MAIN APPLICATION
addappid(1872550)
-- Game: addappid(1872550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872551, 1, "0984235439ceb6e8f1e7df949733c598d79f5ed830d6d260365547d233f78401")
