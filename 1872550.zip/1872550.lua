-- Lua provided by RyzenAPI
-- Game: Destroy All Humans! – Clone Carnage

-- MAIN APPLICATION
addappid(1872550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1872551, 1, "0984235439ceb6e8f1e7df949733c598d79f5ed830d6d260365547d233f78401")

