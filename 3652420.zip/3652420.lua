-- Lua provided by RyzenAPI
-- Game: Game: War of Reproduction: Evolution

-- MAIN APPLICATION
addappid(3652420)
-- Game: addappid(3652420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652421, 1, "feed75f8566c2c805a90b859b83d8cbbc131e3fa62e5baadd0f4b9cf3ea20757")
