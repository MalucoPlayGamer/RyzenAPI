-- Lua provided by RyzenAPI
-- Game: Nock: Hidden Arrow

-- MAIN APPLICATION
addappid(525210)

-- MAIN APP DEPOTS / PACKAGES
addappid(525211,0,"aae88cee8ab4a370a938c07b00dd2cffe1856f03fef1b0027008cd6373132f25")

