-- Lua provided by RyzenAPI
-- Game: North Side

-- MAIN APPLICATION
addappid(546450)

-- MAIN APP DEPOTS / PACKAGES
addappid(546451, 1, "f55c76e7ebdec312eea54a6878ad0f1a7705ce17d2dd07024418f2182fbb505e")

