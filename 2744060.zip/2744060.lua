-- Lua provided by RyzenAPI
-- Game: addappid(2744060)

-- MAIN APPLICATION
addappid(2744060)
addappid(2744061)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744060,0,"e57aab17d957ce339fc8bfa53c929fdaa17fa91f3355b40c9bd25e8ba1f1ff83")
