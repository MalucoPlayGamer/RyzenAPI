-- Lua provided by RyzenAPI
-- Game: addappid(1163300)

-- MAIN APPLICATION
addappid(1163300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163301, 1, "54e115799c4800fc27089513a46c730a9b5f63a1ed565c5b91158e9cd4ff5fa2")
