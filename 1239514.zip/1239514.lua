-- Lua provided by RyzenAPI
-- Game: Brigador - Audiobook

-- MAIN APPLICATION
addappid(1239514)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239550,0,"a7d118240a3cffd6cd9542332ba88e05c8427daa54a448d4fa0b5be61b97672f")
