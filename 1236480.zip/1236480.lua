-- Lua provided by RyzenAPI
-- Game: King of Volleyball

-- MAIN APPLICATION
addappid(1236480)
addappid(1419820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236481, 1, "5c2660e9b4818418e77b7d5338c1678a3bffacedf224883a0455ea33f33939f8")
addappid(1236482, 1, "7c145692851f18b6a7beaa59c6a9f7e671f934936e3137dd33ed1e3e3726cc86")

