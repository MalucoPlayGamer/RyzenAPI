-- Lua provided by RyzenAPI
-- Game: Hentai Cosplay Elf - Artbook 18+

-- MAIN APPLICATION
addappid(1158960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158960,0,"e4c0824d22926929c8373ff8b8ae4f17d2fd067f83826c2f5227b274655afd94")
