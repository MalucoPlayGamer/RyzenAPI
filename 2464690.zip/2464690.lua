-- Lua provided by RyzenAPI
-- Game: Game: CyClones

-- MAIN APPLICATION
addappid(2464690)
-- Game: addappid(2464690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464691, 1, "f2b751d4bf87b6ad2ee7867ca625d07d95b14211d828bd0d5dda7c16d0fbde27")
