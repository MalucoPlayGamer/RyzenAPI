-- Lua provided by SkyAPI 
-- Game: AppID 582580
addappid(582580)
addappid(582581, 1, "53d2cf96d98c0048e1a6733e851e54a3619b0591bdbd5972a7fb58355dce53a3")
