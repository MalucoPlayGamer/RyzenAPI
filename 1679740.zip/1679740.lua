-- Lua provided by RyzenAPI 
-- Game: Once in Flowerlake
addappid(1679740)
addappid(1679741, 1, "c8b46d5d093e16e898fe7e7c0a5e82191b42dbd94b486c28abf5f19ddb133705")
