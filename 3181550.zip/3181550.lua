-- Lua provided by RyzenAPI
-- Game: Beat Saber - Britney Spears - Oops!...I Did It Again

-- MAIN APPLICATION
addappid(3181550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181550,0,"98ed73dab564d08b403966384ec63ffc32b7af0bcfcebe3a1d1e2fc7ae15531b")

