-- Lua provided by RyzenAPI
-- Game: Esper - Make You Live Again

-- MAIN APPLICATION
addappid(668960)

-- MAIN APP DEPOTS / PACKAGES
addappid(668961,0,"aa5f2405ac8215ab5ae7c16ae073c38dfcd9e4cfe3ba0438a69827b4c09e4a55")

