-- Lua provided by RyzenAPI 
-- Game: Grouls
addappid(3047770)
addappid(3047771, 1, "ed9d6421cec01b3d3cd7ecbf3f3e62e707ecfbb87e744c4e43c1458f4e514ae3")
