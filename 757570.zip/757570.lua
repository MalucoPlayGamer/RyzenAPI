-- Lua provided by RyzenAPI 
-- Game: AppID 757570
addappid(757570)
addappid(757571, 1, "39b8e4026597c7f61a8c711df70d4348f67560bf30806ab6e8232a82fe6c8d76")
addappid(757572, 1, "f7889149eec1944e34dadd5a0e6cfae95b95bacc50ff41c25aca83d66f09388d")
