-- Lua provided by RyzenAPI
-- Game: Bullet Heaven 2

-- MAIN APPLICATION
addappid(412670)

-- MAIN APP DEPOTS / PACKAGES
addappid(412671, 1, "2ed1fa18956bfa2f0665505f9b9272bd1700352d9f0f8f311b0bd913f4019306")
