-- Lua provided by RyzenAPI
-- Game: Rage Quest: The Worst Game

-- MAIN APPLICATION
addappid(570810)

-- MAIN APP DEPOTS / PACKAGES
addappid(570811, 1, "61a5bee42c6a5b072302db998f98e6910bfd247277201547e1202b5d09dde3e8")
