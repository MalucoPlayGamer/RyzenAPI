-- Lua provided by RyzenAPI
-- Game: 654470

-- MAIN APPLICATION
addappid(654470)
-- Game: addappid(654470)

-- MAIN APP DEPOTS / PACKAGES
addappid(654471, 1, "5e2b008e57c8343b407acbdcae55fdc8ba4abfe00b300e2381e12b80cd692d26")
