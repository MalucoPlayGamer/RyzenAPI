-- Lua provided by RyzenAPI 
-- Game: Blood Waves
addappid(654470)
addappid(654471, 1, "5e2b008e57c8343b407acbdcae55fdc8ba4abfe00b300e2381e12b80cd692d26")
