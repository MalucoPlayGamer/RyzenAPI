-- Lua provided by RyzenAPI
-- Game: The Mikado Birdgirl in Taichung

-- MAIN APPLICATION
addappid(1368780)
-- Game: addappid(1368780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368781, 1, "279f617f0e60e587594c482b3f1e8f4771fd70a90510eb72656681c8d3a9578c")
