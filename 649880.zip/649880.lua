-- Lua provided by RyzenAPI 
-- Game: Disco Time 80s VR
addappid(649880)
addappid(649881, 1, "b22fece4be5165f4f2fb9b9d2a5c4cac930c8fcafb415c3359044e0034302cfb")
