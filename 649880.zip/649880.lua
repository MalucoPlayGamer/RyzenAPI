-- Lua provided by RyzenAPI
-- Game: Game: Disco Time 80s VR

-- MAIN APPLICATION
addappid(649880)
-- Game: addappid(649880)

-- MAIN APP DEPOTS / PACKAGES
addappid(649881, 1, "b22fece4be5165f4f2fb9b9d2a5c4cac930c8fcafb415c3359044e0034302cfb")
