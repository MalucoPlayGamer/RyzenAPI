-- Lua provided by SkyAPI 
-- Game: INAYAH - Life after Gods
addappid(3199390)
addappid(3199391, 1, "3f8104d107806104482f61b2bb9a3fb224403810614b110776b8c926d43218dd")
