-- Lua provided by RyzenAPI
-- Game: Dead Tapes: Fading Father

-- MAIN APPLICATION
addappid(3716850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716851, 1, "f5363faf25ea50458dcdab38edf38a7e78bce8618a54822556781bb49d711fd9")
