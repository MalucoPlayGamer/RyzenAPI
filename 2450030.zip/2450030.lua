-- Lua provided by RyzenAPI
-- Game: LabyrInk

-- MAIN APPLICATION
addappid(2450030)
-- Game: addappid(2450030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450031, 1, "e73a208b0c44467735eaf329df429410ccd46052142ea0e875e63f87a252f9f3")
