-- Lua provided by RyzenAPI
-- Game: LabyrInk

-- MAIN APPLICATION
addappid(2450030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450031, 1, "e73a208b0c44467735eaf329df429410ccd46052142ea0e875e63f87a252f9f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
