-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3275340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3275340,0,"6a4a01028a95aa8dffea3b6027edb86e7192ac70e9c6c44d6207483fa3bc9792")
