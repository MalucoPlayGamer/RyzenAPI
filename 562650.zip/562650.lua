-- Lua provided by RyzenAPI
-- Game: Cube Master

-- MAIN APPLICATION
addappid(562650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(562651, 1, "ef1a1e0b2d443432c75b9bd5c55575906c37c739796469ac56130197b8334a0c")
