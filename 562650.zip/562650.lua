-- Lua provided by RyzenAPI 
-- Game: AppID 562650
addappid(562650)
addappid(562651, 1, "ef1a1e0b2d443432c75b9bd5c55575906c37c739796469ac56130197b8334a0c")
