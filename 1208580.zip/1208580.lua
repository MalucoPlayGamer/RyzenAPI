-- Lua provided by RyzenAPI
-- Game: Game: Red Rush

-- MAIN APPLICATION
addappid(1208580)
-- Game: addappid(1208580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208581, 1, "51e4a2c38142a1b5b7ef46de2c2a805d2d14f73e6882828098ca1b523f14a7fe")
