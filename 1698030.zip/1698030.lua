-- Lua provided by RyzenAPI
-- Game: NinNinDays2

-- MAIN APPLICATION
addappid(1698030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698031, 1, "a75611d4c9a83844fa3d6a75846b7929ccfd2b0570ee5e30138fb95bbd291e59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
