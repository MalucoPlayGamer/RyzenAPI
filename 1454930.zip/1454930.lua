-- Lua provided by RyzenAPI
-- Game: TechnoRunner

-- MAIN APPLICATION
addappid(1454930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454931, 1, "79e5c96f32d2532fe769b9d5d18925fa3954cc6b1c2b9119d45fecfe601b2cd7")

