-- Lua provided by RyzenAPI
-- Game: AppID 33350

-- MAIN APPLICATION
addappid(33350)
-- Game: addappid(33350)

-- MAIN APP DEPOTS / PACKAGES
addappid(33351, 1, "0a8606f7772c7bffd0ffb72428982ad0d62644da8479bd9be807185a4be97691")
addappid(33352, 1, "705ef16a1ff10719ade87e98622ae2f6e9fb4a9a282b2f9074a2c7ac87d339b4")
addappid(33353, 1, "3dfb9352c01d3578aa049196cfd0a6e7e18b177ee1da66d69bcbb1cf23b5ea1b")
addappid(33354, 1, "9a9bb0b146d1e296b9e757ac1cbbfe8d7f783a8708d4b82a9f23d465484e475b")
addappid(33355, 1, "e16adf25ca58054f62ac23eb419d6999a76c018db40b4f9cd8b5514cf64ab310")
