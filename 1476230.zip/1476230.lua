-- Lua provided by RyzenAPI
-- Game: Elmarion: the Lost Temple

-- MAIN APPLICATION
addappid(1476230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476231, 1, "ebbead00bdef72c94b870eddc1c4bc1a5587be2f2a932a136410fd8780174c39")

