-- Lua provided by RyzenAPI
-- Game: 1252680

-- MAIN APPLICATION
addappid(1252680)
-- Game: addappid(1252680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252681, 1, "55619e8e3c666429e7287b9d4c976ba61e6bddc9b57623ff6ec381f7747014f8")
