-- Lua provided by RyzenAPI
-- Game: Strike Force 3

-- MAIN APPLICATION
addappid(1525910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525911, 1, "ada8a67c6e409c156b0db4b4b1676f514208b9cbdccc24403240e63fd3e870aa")

