-- Lua provided by RyzenAPI
-- Game: Fool's Gold Demo

-- MAIN APPLICATION
addappid(2910250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910251, 1, "e3f6fc0a0aedc8f961322e12c337787a5634fdf0a2481a3c764ebacf81425b3e")

