-- Lua provided by RyzenAPI
-- Game: Game: AppID 469980

-- MAIN APPLICATION
addappid(469980)
-- Game: addappid(469980)

-- MAIN APP DEPOTS / PACKAGES
addappid(469981, 1, "ad23545c62d7f820f617d390d05699032e0421b454ffe7dd48c527515315d297")
