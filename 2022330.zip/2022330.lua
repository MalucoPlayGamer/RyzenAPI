-- Lua provided by RyzenAPI
-- Game: Game: The Riflemen

-- MAIN APPLICATION
addappid(2022330)
addappid(2521030)
-- Game: addappid(2022330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022331, 1, "c8f34d93762e29f11e45241772963388a20805ecf8104d1651b3cd2a2b37c728")
