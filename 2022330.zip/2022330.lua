-- Lua provided by SkyAPI 
-- Game: The Riflemen
addappid(2022330)
addappid(2022331, 1, "c8f34d93762e29f11e45241772963388a20805ecf8104d1651b3cd2a2b37c728")
addappid(2521030)
