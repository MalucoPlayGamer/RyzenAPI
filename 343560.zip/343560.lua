-- Lua provided by RyzenAPI
-- Game: Bob Was Hungry

-- MAIN APPLICATION
addappid(343560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(343561, 1, "d03a6bd34f3c58f56dd76322161a8cbf27f512e0e6a128272f265094b6d8d53c")

