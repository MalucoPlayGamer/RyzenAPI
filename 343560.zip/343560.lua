-- Lua provided by RyzenAPI
-- Game: Bob Was Hungry

-- MAIN APPLICATION
addappid(343560)

-- MAIN APP DEPOTS / PACKAGES
addappid(343561, 1, "d03a6bd34f3c58f56dd76322161a8cbf27f512e0e6a128272f265094b6d8d53c")
