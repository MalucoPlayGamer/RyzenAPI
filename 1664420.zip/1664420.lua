-- Lua provided by RyzenAPI
-- Game: 東方実在相 ～ Dream Logical World Demo

-- MAIN APPLICATION
addappid(1664420)
-- Game: addappid(1664420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664421, 1, "860c68cbaf527fa811a1c5f2f5115db3444b007267ea9969e71caa4e72a574b3")
