-- Lua provided by RyzenAPI
-- Game: Gunpowder Cocktail - Chapter 1

-- MAIN APPLICATION
addappid(2761920)
-- Game: addappid(2761920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761921, 1, "637eb814cf0ca1d5d1af1387a72755459c8a75726b76f428447c8f4a797a4b60")
