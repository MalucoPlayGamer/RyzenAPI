-- Lua provided by RyzenAPI
-- Game: addappid(510620)

-- MAIN APPLICATION
addappid(510620)
addappid(667860)

-- MAIN APP DEPOTS / PACKAGES
addappid(510621, 1, "b15b7c24b14cec3327c3decbdd92ca75ae504b7a48ab800940df5b44600ff1e1")
addappid(510622, 1, "865cf74b7c26635d872500b09c3da9c333bbaf2f738636297bcc10f7e5280af5")
