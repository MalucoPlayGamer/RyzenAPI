-- Lua provided by RyzenAPI
-- Game: Game: Millennium Atoll

-- MAIN APPLICATION
addappid(1477850)
-- Game: addappid(1477850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477851, 1, "a94a24abcde5a59af40cefcba9b95a2fc5914f81e61731f6837e61c084cec02c")
