-- Lua provided by RyzenAPI
-- Game: Dark Ride Simulator

-- MAIN APPLICATION
addappid(2467510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2467511, 1, "3902d1446bff70be50b4666fed7a6de53f9bda70132df3d806e0007ba0b3682c")

