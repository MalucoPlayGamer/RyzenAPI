-- Lua provided by RyzenAPI
-- Game: From Glory To Goo

-- MAIN APPLICATION
addappid(2607060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607061, 1, "f09a280e523e347727fa9c86b9770537f822f21b8ecb8a949923c00c9fd6db83")

