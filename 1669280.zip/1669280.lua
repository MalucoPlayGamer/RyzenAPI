-- Lua provided by RyzenAPI
-- Game: addappid(1669280)

-- MAIN APPLICATION
addappid(1669280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669281, 1, "4403e97e4d2b330afdeb62c2344920279f66d45ec1a4533eab8bc6a1aa2631de")
