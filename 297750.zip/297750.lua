-- Lua provided by RyzenAPI
-- Game: Close Combat - Gateway to Caen

-- MAIN APPLICATION
addappid(297750)
-- Game: addappid(297750)

-- MAIN APP DEPOTS / PACKAGES
addappid(297751, 1, "5ab3de7cc654ed8a2c6d1e88de2964e2b2de2d1eb9554fb9416f3d95308b454d")
addappid(297752, 1, "d7b5d9083a32fb3fb55ed35b88e14d8631acdc0b21b278423ebe022301a0ebc0")
