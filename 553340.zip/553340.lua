-- Lua provided by RyzenAPI
-- Game: SolarGun

-- MAIN APPLICATION
addappid(553340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(553341,0,"29f68947b1aa45e9371aad5034d6f8330abf2c64e8c1521ee8a66f8d7e528cc1")
addappid(553342,0,"8f85285669fc5a33a1bacf25e27e780281909d50a436d21a5d8bf28daf2d769e")
addappid(553343,0,"c7ed666f1f0fb999249613ae2b1285eed4a1f1e4ede769e3ba5fb431f58d812f")

