-- Lua provided by RyzenAPI
-- Game: Mini Gold Coop

-- MAIN APPLICATION
addappid(780410)

-- MAIN APP DEPOTS / PACKAGES
addappid(780411, 1, "87fe273642f97951ebf53b9fe8229a20fefd7258f39e8abfa1ad69bf1def5c61")
