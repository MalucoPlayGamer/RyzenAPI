-- Lua provided by SkyAPI 
-- Game: AppID 2361170
addappid(2361170)
addappid(2361171, 1, "ece2fdae2f266af4edb930ccdd4a05918e98f69e51008e0fd2d17366dca8f071")
