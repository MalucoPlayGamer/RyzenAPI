-- Lua provided by RyzenAPI
-- Game: Roguebreaker

-- MAIN APPLICATION
addappid(731420)

-- MAIN APP DEPOTS / PACKAGES
addappid(731421, 1, "176c12cea065168f8299b92ecd00d56db5af00f7c2a66a2cdf050044aea3ff75")
