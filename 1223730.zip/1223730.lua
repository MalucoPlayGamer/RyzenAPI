-- Lua provided by SkyAPI 
-- Game: AppID 1223730
addappid(1223730)
addappid(1223731, 1, "aa984e9987697f2dae05f17ae1aff514cb3c24400ad0578b2b245e99d4ba48a5")
addappid(1223732, 1, "3a8390951861fdb0a52d91bcc000e85c82bd5ebd05c951708eca54b8a149452c")
