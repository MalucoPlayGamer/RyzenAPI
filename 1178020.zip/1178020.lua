-- Lua provided by SkyAPI 
-- Game: Shot the Body
addappid(1178020)
addappid(1178021, 1, "ff1bc9e0f5f0dabc979c2a94370b59b0d0387d2239ade069813ed6daf2a04084")
