-- Lua provided by RyzenAPI
-- Game: addappid(1178020)

-- MAIN APPLICATION
addappid(1178020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178021, 1, "ff1bc9e0f5f0dabc979c2a94370b59b0d0387d2239ade069813ed6daf2a04084")
