-- Lua provided by RyzenAPI
-- Game: Shot the Body

-- MAIN APPLICATION
addappid(1178020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1178021, 1, "ff1bc9e0f5f0dabc979c2a94370b59b0d0387d2239ade069813ed6daf2a04084")

