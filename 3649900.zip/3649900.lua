-- Lua provided by RyzenAPI
-- Game: Keep Me Gifted

-- MAIN APPLICATION
addappid(3649900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3649901, 1, "d9dc3f56981d0f9745d677a9af9b0e23fb11e3a913f0ac50c74a5e9a116b29ee")

