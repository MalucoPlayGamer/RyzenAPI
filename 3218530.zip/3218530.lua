-- Lua provided by RyzenAPI
-- Game: Game: Best Served Cold

-- MAIN APPLICATION
addappid(3218530)
-- Game: addappid(3218530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3218531, 1, "50ece9f8ddbf60ec708059b18a272a27ce8789161e30aaa57626720f4496c173")
