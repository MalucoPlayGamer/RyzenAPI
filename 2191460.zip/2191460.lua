-- Lua provided by RyzenAPI
-- Game: The Exorcist's Story

-- MAIN APPLICATION
addappid(2191460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191461, 1, "3dc485ecda1982e436597530fc444db91078199558f4d36c340782a366121911")

