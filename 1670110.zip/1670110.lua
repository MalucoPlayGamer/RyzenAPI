-- Lua provided by RyzenAPI
-- Game: Bots Are Stupid Demo

-- MAIN APPLICATION
addappid(1670110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670111, 1, "de92df1f631fa9c5178e3adcac54a6ef2abfbf1cff5f0ca3c27d0d9fdfdc5a4c")
addappid(1670114, 1, "d543dc8506bcb6b963a1818a968e88fda6a8ca44562ab1db40427bf866a37415")

