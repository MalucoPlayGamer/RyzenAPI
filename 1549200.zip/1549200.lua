-- Lua provided by RyzenAPI
-- Game: Game: Anachronism\>

-- MAIN APPLICATION
addappid(1549200)
-- Game: addappid(1549200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549201, 1, "09e018b60b6d670277e38ab488a5528085ddb37a2d1f5a3b7593a03ff9b758a2")
