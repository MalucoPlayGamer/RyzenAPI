-- Lua provided by RyzenAPI
-- Game: Tiny-Tasy Town

-- MAIN APPLICATION
addappid(815210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(815211, 1, "805e83ac035a890e8c69280451c56151b7256edd35b29c57c0ad67e8774470e6")
addappid(815213, 1, "57a75b16f0f0adf3e1d291346f2f2af34fdba16f37103fd88d1ff08b87c8539e")
