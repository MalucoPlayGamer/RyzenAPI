-- Lua provided by RyzenAPI
-- Game: Game: XLaunchpad

-- MAIN APPLICATION
addappid(995660)
-- Game: addappid(995660)

-- MAIN APP DEPOTS / PACKAGES
addappid(995661, 1, "c407ea0e599ecf7ed346d50656c2baa5811b166c7dffaaca8b59a842dd309a5e")
