-- Lua provided by RyzenAPI
-- Game: Relic Dudes

-- MAIN APPLICATION
addappid(2116260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116261, 1, "68a4f44dc94a87094554255d94d42012da4929068ff2d6afb7d3a3a2c7834964")

