-- Lua provided by RyzenAPI
-- Game: Dungeon Brawlers

-- MAIN APPLICATION
addappid(1648050)
-- Game: addappid(1648050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648051, 1, "6b8563a2645bc07a2cbf0de13a984b6471737186b70a9220dcc5f0315c0dd0c9")
