-- Lua provided by RyzenAPI
-- Game: Jack N' Jill DX

-- MAIN APPLICATION
addappid(873560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(873561, 1, "62557dc4720602fde3d38ae805220433ed3f35737c7395c5c53a1949972c31c3")

