-- Lua provided by RyzenAPI
-- Game: Game: Jack N' Jill DX

-- MAIN APPLICATION
addappid(873560)
-- Game: addappid(873560)

-- MAIN APP DEPOTS / PACKAGES
addappid(873561, 1, "62557dc4720602fde3d38ae805220433ed3f35737c7395c5c53a1949972c31c3")
