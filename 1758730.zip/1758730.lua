-- Lua provided by RyzenAPI
-- Game: 1758730

-- MAIN APPLICATION
addappid(1758730)
-- Game: addappid(1758730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758731, 1, "fd7ec556f650394a531f35c4f3473b510ddde88c38dcdf6b5d8d24cd8a553bbe")
