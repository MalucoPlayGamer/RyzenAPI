-- Lua provided by RyzenAPI
-- Game: 772450

-- MAIN APPLICATION
addappid(772450)
-- Game: addappid(772450)

-- MAIN APP DEPOTS / PACKAGES
addappid(772451, 1, "7a3f078c17eab1b7a759e0894f0325f05e1ac8cae0d7e8044ecfd3ce9b4316e8")
