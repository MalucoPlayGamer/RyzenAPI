-- Lua provided by SkyAPI 
-- Game: Prison Bomber
addappid(772450)
addappid(772451, 1, "7a3f078c17eab1b7a759e0894f0325f05e1ac8cae0d7e8044ecfd3ce9b4316e8")
