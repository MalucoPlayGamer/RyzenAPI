-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Layout Data Sci-Fi

-- MAIN APPLICATION
addappid(2928530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928530,0,"7238f821aaf164b1527667af6db34ae95e2fb85e38b50e1f01fb111da07a3e1f")

