-- Lua provided by RyzenAPI
-- Game: Gladiator Guild Manager Soundtrack

-- MAIN APPLICATION
addappid(3041190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041191, 1, "c38d001ce7256536fed2307cdb3e592f5bcb2a8583e5f235ec74845759fea1be")
