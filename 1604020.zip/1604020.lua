-- Lua provided by RyzenAPI
-- Game: Many Bricks Breaker

-- MAIN APPLICATION
addappid(1604020)
-- Game: addappid(1604020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604021, 1, "cb42616dad8707c5c1c406ec900bff46e2ec37dfbd12dae0fccfda5c50566237")
