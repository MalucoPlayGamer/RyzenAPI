-- Lua provided by RyzenAPI
-- Game: 1476080

-- MAIN APPLICATION
addappid(1476080)
-- Game: addappid(1476080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476081, 1, "b3cbc98fca201aeddb37dde4cd3334a78e619c67b764744e423f611bca839197")
