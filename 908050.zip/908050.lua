-- Lua provided by RyzenAPI
-- Game: Summer Catchers

-- MAIN APPLICATION
addappid(908050)

-- MAIN APP DEPOTS / PACKAGES
addappid(908052,0,"33a7696069e754864600d514103f8c02c3bb9828973fd4e3dd1604dfdd057e74")
addappid(908053,0,"f1cd6c93e239a702e72ddee769a001e05f006eb36ba64b728960d5981207d61e")
addappid(1052960,0,"a53efa88e07d78e9ead17bc4df2d93be262a7fca96266ed1be2cdb4e50dd7f3d")

