-- Lua provided by RyzenAPI
-- Game: addappid(1332370)

-- MAIN APPLICATION
addappid(1332370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332372,0,"ff04bd008b10db47889f09e8eb3cea8a83b6b99aea10a4b7197611804e1ff758")
