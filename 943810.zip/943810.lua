-- Lua provided by RyzenAPI
-- Game: AppID 943810

-- MAIN APPLICATION
addappid(943810)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(943811, 1, "7565b48a817cb6cf04becb803a540601541b8ec92847ec106922f7cc54cbeebf")

