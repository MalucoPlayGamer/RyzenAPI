-- Lua provided by RyzenAPI
-- Game: setManifestid(2089142,"7554220443538499274")

-- MAIN APPLICATION
addappid(2089140)
-- Game: addappid(2089140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089142,0,"3ac0ef79245563a35c3fcab00afe46384441d273da0f7ced3fa3f7b36690dd23")
