-- Lua provided by RyzenAPI
-- Game: Super-Patriota Simulator

-- MAIN APPLICATION
addappid(2089140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089142,0,"3ac0ef79245563a35c3fcab00afe46384441d273da0f7ced3fa3f7b36690dd23")

