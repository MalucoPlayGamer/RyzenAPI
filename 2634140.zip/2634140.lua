-- Lua provided by RyzenAPI
-- Game: Endoparasitic VR

-- MAIN APPLICATION
addappid(2634140)
-- Game: addappid(2634140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634141, 1, "59e2ff86c0881e24a1998c502860a4685aa6bf86f6dd2bf5c514834b224a6071")
