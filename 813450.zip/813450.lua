-- Lua provided by RyzenAPI
-- Game: Barbearian

-- MAIN APPLICATION
addappid(813450)

-- MAIN APP DEPOTS / PACKAGES
addappid(813451, 1, "850b45ea2c91dbbee09ad50c4c671176e243b566dbe358bda9e1ee7842ef6cc1")

