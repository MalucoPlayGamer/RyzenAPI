-- Lua provided by RyzenAPI
-- Game: Barbearian

-- MAIN APPLICATION
addappid(813450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(813451, 1, "850b45ea2c91dbbee09ad50c4c671176e243b566dbe358bda9e1ee7842ef6cc1")

