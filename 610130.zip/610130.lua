-- Lua provided by SkyAPI 
-- Game: UltraGoodness
addappid(610130)
addappid(610131, 1, "59cf577ddb2893be61cc23c46363e98657b8c8c5b5154a75e863fda05f66c4ad")
addappid(610132, 1, "4f04c49a400d7f55b6cafd4d134a19d6b0de3d3b3a79621d55123aecb8ca309f")
addappid(644690)
