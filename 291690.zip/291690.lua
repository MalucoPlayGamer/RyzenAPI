-- Lua provided by SkyAPI 
-- Game: Empathy: Path of Whispers
addappid(291690)
addappid(291691, 1, "363366d6b441f4f80dcf7d1fe983a352dc0ce5c4d41d4e84b2a95bf265669c00")
addappid(634170, 0, "768e6bc6c368bed55d2480150f28cb954d8ee942e85e307b22d02c3b6b133b3a")
