-- Lua provided by RyzenAPI
-- Game: Sneaky Seekers Demo

-- MAIN APPLICATION
addappid(2615080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615081, 1, "a16934d046023a699082bd58e018dd14533b6a10e0c1e48e2e546b26603513df")

