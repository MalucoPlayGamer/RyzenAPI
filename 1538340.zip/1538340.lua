-- Lua provided by RyzenAPI
-- Game: addappid(1538340)

-- MAIN APPLICATION
addappid(1538340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538341, 1, "9bf8f282bb46a1c049ef673313027dd99c264042e9f8a70de669d3cd8bf24430")
