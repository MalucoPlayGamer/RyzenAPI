-- Lua provided by RyzenAPI
-- Game: 1656680

-- MAIN APPLICATION
addappid(1656680)
-- Game: addappid(1656680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656681, 1, "11156b99486f799da4d9bf7b6b59628b2e829d7fb0b2ef60bbab83d4203ef0b0")
