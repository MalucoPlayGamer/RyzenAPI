-- Lua provided by RyzenAPI
-- Game: addappid(3696000)

-- MAIN APPLICATION
addappid(3696000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3696001, 1, "9fd5494b1e331287a3cdd1defc6dfa1443be5a07476af86d74dbecb687717b51")
