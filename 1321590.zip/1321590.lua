-- Lua provided by RyzenAPI
-- Game: Game: Dark Tales: Edgar Allan Poe's The Bells Collector's Edition

-- MAIN APPLICATION
addappid(1321590)
-- Game: addappid(1321590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321591, 1, "d355e667807a212522723d56da06367e456985879baf11b71875f76f70db5694")
