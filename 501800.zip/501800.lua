-- Lua provided by RyzenAPI
-- Game: Game: AppID 501800

-- MAIN APPLICATION
addappid(501800)
-- Game: addappid(501800)

-- MAIN APP DEPOTS / PACKAGES
addappid(501801, 1, "7297a381aa119e7764adb0a3321180106badbed8794955c73e720863b6318efc")
