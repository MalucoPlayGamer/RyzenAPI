-- Lua provided by RyzenAPI
-- Game: addappid(47920)

-- MAIN APPLICATION
addappid(47920)

-- MAIN APP DEPOTS / PACKAGES
addappid(47921, 1, "846f2d62beedbc12d6c738867186935dc391a891a1705803f4d04d0fbbd40c3a")
