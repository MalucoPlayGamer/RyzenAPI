-- Lua provided by RyzenAPI
-- Game: Game: AppID 600370

-- MAIN APPLICATION
addappid(600370)
addappid(626180)
-- Game: addappid(600370)

-- MAIN APP DEPOTS / PACKAGES
addappid(600371, 1, "80c597b40936f62da545e75c91ecb46f467a1294bc1bd9f6b80f8f9830382c04")
addappid(600372, 1, "634e981778a1a4406a0ae9fdee820d2b867a929ed396dc22c89cbebc1795bc6d")
addappid(600373, 1, "3798fa421702d52ffe6e3cb5cd72a88f40adda1dc56e2b852dfff03372c1b30a")
