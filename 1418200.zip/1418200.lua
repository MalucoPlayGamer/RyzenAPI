-- Lua provided by RyzenAPI 
-- Game: Accident Demo
addappid(1418200)
addappid(1418201, 1, "dccac23247706f83ac56c37a4dd7f4dc1164d60d2b06f1579b581ed80765e8bd")
