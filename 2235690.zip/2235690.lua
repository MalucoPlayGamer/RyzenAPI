-- Lua provided by RyzenAPI
-- Game: Game: Crochet Cavalcade

-- MAIN APPLICATION
addappid(2235690)
-- Game: addappid(2235690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235691, 1, "017125b18d25679ba6fb75531faa5e3d921537db5f4fd34c316c18afe02b41e9")
