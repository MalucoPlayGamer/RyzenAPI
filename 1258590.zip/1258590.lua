-- Lua provided by RyzenAPI
-- Game: Locked Up

-- MAIN APPLICATION
addappid(1258590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258591, 1, "fff6c0c36eb6188ae8b8bf36a0017622a398a2e9574f2656f8b7731cfe356cdc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
