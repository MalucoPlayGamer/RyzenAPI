-- Lua provided by RyzenAPI
-- Game: Game: Locked Up

-- MAIN APPLICATION
addappid(1258590)
-- Game: addappid(1258590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258591, 1, "fff6c0c36eb6188ae8b8bf36a0017622a398a2e9574f2656f8b7731cfe356cdc")
