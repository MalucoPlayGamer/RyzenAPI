-- Lua provided by RyzenAPI
-- Game: AppID 2994530

-- MAIN APPLICATION
addappid(2994530)
-- Game: addappid(2994530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994531, 1, "1c367875cdbdcc082d9be6e84d0cd697c04418349881e1b554ec062177a9752d")
