-- Lua provided by RyzenAPI
-- Game: Defend Your Crypt

-- MAIN APPLICATION
addappid(457450)
addappid(470200)

-- MAIN APP DEPOTS / PACKAGES
addappid(457451, 1, "4ac48c2f51b082de57ec2870e5d7d7e3c0c979a3fb61018835974e61c67fd302")
addappid(457452, 1, "cecf5874cb3a847ffe4ced1420b86f15c6ec02db445c6b95c6fb6e2abe7c2e6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
