-- 4372610's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Rika is streaming
-- Created: May 17, 2026 at 12:05:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4372610) -- Hentai Clicker: Rika is streaming
-- MAIN APP DEPOTS
addappid(4372611, 1, "478989dd3dd90d0c846412ecabcaac38b4a03efb337df3bd8f2beed6e20ff13b") -- Depot 4372611
setManifestid(4372611, "8258644647713027088", 154551750)