-- Lua provided by RyzenAPI
-- Game: 1253290

-- MAIN APPLICATION
addappid(1253290)
addappid(1253291)

-- MAIN APP DEPOTS / PACKAGES
addappid(932211,0,"3c431672335a74b4aa3a50fc863ad01ee5bdf79ffe9c36d0a7174834ac65d953")

