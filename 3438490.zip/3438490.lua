-- Lua provided by RyzenAPI
-- Game: アンリアリィ・サバイバーズ：わたしたちのときめき無人島ライフ

-- MAIN APPLICATION
addappid(3438490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3438491, 1, "899ed163a5078bf89fb4c512120d2a07bf87f2500008eef55989f5da2e7b32d2")

