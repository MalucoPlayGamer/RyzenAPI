-- Lua provided by RyzenAPI
-- Game: Steel Punk Ball

-- MAIN APPLICATION
addappid(679510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(679511, 1, "3405c6e4cfa57f9ef8f7a4082c0db91d45aaf2931cd9b6d2acd0b8b6c2bcb16a")

