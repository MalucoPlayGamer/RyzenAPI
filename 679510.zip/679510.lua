-- Lua provided by RyzenAPI
-- Game: Steel Punk Ball

-- MAIN APPLICATION
addappid(679510)
-- Game: addappid(679510)

-- MAIN APP DEPOTS / PACKAGES
addappid(679511, 1, "3405c6e4cfa57f9ef8f7a4082c0db91d45aaf2931cd9b6d2acd0b8b6c2bcb16a")
