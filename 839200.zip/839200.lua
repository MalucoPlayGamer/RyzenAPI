-- Lua provided by RyzenAPI
-- Game: addappid(839200)

-- MAIN APPLICATION
addappid(839200)

-- MAIN APP DEPOTS / PACKAGES
addappid(839201, 1, "81861d5643b0cb8b271e1a146efbf44e529b06d88ada0d4623084202e635a471")
