-- Lua provided by RyzenAPI
-- Game: SpedV

-- MAIN APPLICATION
addappid(839200)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(839201, 1, "81861d5643b0cb8b271e1a146efbf44e529b06d88ada0d4623084202e635a471")
