-- Lua provided by RyzenAPI
-- Game: Project CARS 2

-- MAIN APPLICATION
addappid(378860)
addappid(648290)
addappid(648291)
addappid(648292)
addappid(648293)
addappid(648300)
addappid(648301)
addappid(648310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(378861, 1, "c74392086f4c8db1371bb8fcc5198936a5069eec4c43fec26f089f6dc88935a9")

