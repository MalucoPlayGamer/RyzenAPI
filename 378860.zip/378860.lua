-- Lua provided by RyzenAPI
-- Game: 378860

-- MAIN APPLICATION
addappid(378860)
-- Game: addappid(378860)

-- MAIN APP DEPOTS / PACKAGES
addappid(378861, 1, "c74392086f4c8db1371bb8fcc5198936a5069eec4c43fec26f089f6dc88935a9")
