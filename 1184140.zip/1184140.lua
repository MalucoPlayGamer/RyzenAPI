-- Lua provided by RyzenAPI
-- Game: Game: KartRider: Drift

-- MAIN APPLICATION
addappid(1184140)
-- Game: addappid(1184140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184141, 1, "9faa6dda489dcc2ebbeef1b3d802e441d51143cbf35679becde70609cb71601e")
