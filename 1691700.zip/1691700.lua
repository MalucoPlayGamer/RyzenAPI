-- Lua provided by RyzenAPI
-- Game: addappid(1691700)

-- MAIN APPLICATION
addappid(1691700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691701, 1, "5aeca8a8567fd8d25daf5c67bea8b270169c5d7aec03e32c6fb359eceeae5daf")
