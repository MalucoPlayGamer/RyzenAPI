-- Lua provided by RyzenAPI
-- Game: 453170

-- MAIN APPLICATION
addappid(453170)
-- Game: addappid(453170)

-- MAIN APP DEPOTS / PACKAGES
addappid(453171, 1, "2eab8f20e5a95f0d372d798dae61d9a403b133fae3d1c54fd87dc8e11d937e1e")
addappid(453172, 1, "a24d358ef2d669649eefc2edc2ad6dc2d4b60a258d3f6f89e392829f1d634678")
addappid(453173, 1, "8464421a22749389bb956c6381a675179bd76ee997dd8130d704c60755ed93b3")
addappid(453174, 1, "a2f272e37cf1cfc0ae65e529419fe83a540cf8b0f34570cea10bcb97775461a8")
addappid(453175, 1, "c67a4ebf9b14a252809de3eb4a8e4f951e71bb7dcf7edef91fa60ca1d229eace")
