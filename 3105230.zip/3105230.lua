-- Lua provided by RyzenAPI
-- Game: Cybernated Demo

-- MAIN APPLICATION
addappid(3105230)
-- Game: addappid(3105230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3105231, 1, "23d5e2ccb5cb3df4705f8459f251149cda8f4bed62353bf44eb598187d3aa351")
