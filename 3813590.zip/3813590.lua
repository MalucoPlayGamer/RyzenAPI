-- Lua provided by RyzenAPI
-- Game: Summoners War: RUSH

-- MAIN APPLICATION
addappid(3813590)
