-- Lua provided by RyzenAPI
-- Game: Weirdo Soundtrack

-- MAIN APPLICATION
addappid(3456080)
-- Game: addappid(3456080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456081, 1, "44832af1e87e0fd6227ceace26b5a01a681bb509505acb84e4d4467701a49e94")
