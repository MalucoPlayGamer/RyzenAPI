-- Lua provided by RyzenAPI
-- Game: Around Us

-- MAIN APPLICATION
addappid(2179220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179222,0,"9b61eef713b8d88127bd750beed59cfeddf4b4c60d8d079df9baa0eb6605cf60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
