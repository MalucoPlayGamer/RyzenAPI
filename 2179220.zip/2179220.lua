-- Lua provided by RyzenAPI
-- Game: 2179220

-- MAIN APPLICATION
addappid(2179220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179222,0,"9b61eef713b8d88127bd750beed59cfeddf4b4c60d8d079df9baa0eb6605cf60")
