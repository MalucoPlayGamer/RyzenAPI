-- 3930640's Lua and Manifest Created by Hubcap Manifest
-- Farmers Market
-- Created: July 16, 2026 at 05:31:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3930640) -- Farmers Market
-- MAIN APP DEPOTS
addappid(3930641, 1, "c81ab8ba75b7d1a35d87146f8d88d66413aa25152d55009811081c537bb8a5f9") -- Depot 3930641
setManifestid(3930641, "8267383889876326657", 167071910)