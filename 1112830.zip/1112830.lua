-- Lua provided by RyzenAPI 
-- Game: The Watchers
addappid(1112830)
addappid(1112831, 1, "73b8f396378d5ed478b30a368b767d73732e02df516362247ab5780141288bb9")
