-- Lua provided by RyzenAPI
-- Game: Game: The Watchers

-- MAIN APPLICATION
addappid(1112830)
-- Game: addappid(1112830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112831, 1, "73b8f396378d5ed478b30a368b767d73732e02df516362247ab5780141288bb9")
