-- Lua provided by RyzenAPI
-- Game: AppID 880130

-- MAIN APPLICATION
addappid(880130)

-- MAIN APP DEPOTS / PACKAGES
addappid(880131, 1, "b9e42450f5918ed581080ef10eba52dcd2eaa1e0633e974997b8288cfe05806c")
addappid(929720, 0, "ddab24e08835c39f65d585a5eebc378757b80eb400957f43963ab73537a01a08")
addappid(1009840, 0, "fbe2ddbd78cb4ce906faaebdf79df488c79aa841de916f3e824986b0f44417e1")
addappid(1050890, 0, "194755f087234a95f4c11b56bf9c600b4b358ef4385d8be8243e495eefe72889")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1136060)
addappid(1286820)
addappid(1398580)
addappid(1408290)
addappid(1436180)
addappid(1438420)
addappid(1497220)
addappid(1530320)
addappid(1578560)
addappid(1691980)
addappid(1715990)
addappid(1744150)
addappid(2699070)
addappid(4162430)
