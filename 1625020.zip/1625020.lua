-- Lua provided by RyzenAPI
-- Game: 1625020

-- MAIN APPLICATION
addappid(1625020)
-- Game: addappid(1625020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625021, 1, "2678015b34dc9d217cb44e63c2e3023cbb5d2383791a62f186fed1024ddcddb1")
