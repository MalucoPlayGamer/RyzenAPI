-- Lua provided by RyzenAPI
-- Game: Lulu's Temple

-- MAIN APPLICATION
addappid(1919100)
-- Game: addappid(1919100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919101, 1, "9f8ccd647147c44f448aeb777a5e41c4860b94c5762d0a62ea7958ff37c9f4c4")
