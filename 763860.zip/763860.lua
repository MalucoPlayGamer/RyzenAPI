-- Lua provided by RyzenAPI
-- Game: Surgera VR

-- MAIN APPLICATION
addappid(763860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(763861, 1, "8e2a333fb013f9d34fa8b8a4c30a568c5070a9440446e33d24ded30e6cf8c2d7")

