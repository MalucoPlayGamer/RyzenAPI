-- Lua provided by RyzenAPI
-- Game: 763860

-- MAIN APPLICATION
addappid(763860)
-- Game: addappid(763860)

-- MAIN APP DEPOTS / PACKAGES
addappid(763861, 1, "8e2a333fb013f9d34fa8b8a4c30a568c5070a9440446e33d24ded30e6cf8c2d7")
