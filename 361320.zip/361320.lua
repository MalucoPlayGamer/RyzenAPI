-- Lua provided by RyzenAPI
-- Game: Casino Inc.

-- MAIN APPLICATION
addappid(361320)

-- MAIN APP DEPOTS / PACKAGES
addappid(361321, 1, "59420d1ff57b094fc76bd3731c3355ec5dad6cb2690b6904cda506597fe67f08")
