-- Lua provided by RyzenAPI
-- Game: City Bus Manager - Southern Europe

-- MAIN APPLICATION
addappid(1901850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901851, 1, "97e27895e33540fb36f749d279126d5bc3691e11a0502f95c4a232066d80ddc3")
