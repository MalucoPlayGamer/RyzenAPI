-- Lua provided by SkyAPI 
-- Game: Kitten Burst Demo
addappid(1948710)
addappid(1948711, 1, "e33e6a3a03fb532acbaa12321020abaac8dc801b8381f3590bb1e51954d0d718")
