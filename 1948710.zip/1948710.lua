-- Lua provided by RyzenAPI
-- Game: Kitten Burst Demo

-- MAIN APPLICATION
addappid(1948710)
-- Game: addappid(1948710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948711, 1, "e33e6a3a03fb532acbaa12321020abaac8dc801b8381f3590bb1e51954d0d718")
