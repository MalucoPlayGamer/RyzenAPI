-- Lua provided by RyzenAPI
-- Game: addappid(1128800)

-- MAIN APPLICATION
addappid(1128800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128801, 1, "d595b04e3e3cdc8b898f8057b6202e43403e51c92f8a1ff1d048f699650b14fd")
