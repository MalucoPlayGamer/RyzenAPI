-- Lua provided by RyzenAPI
-- Game: 3118450

-- MAIN APPLICATION
addappid(3118450)
-- Game: addappid(3118450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118451, 1, "35e3dd9ebd4841dcf8607883fafd8e26362fa4086cb1080cf131ac1684337e52")
