-- Lua provided by RyzenAPI
-- Game: Cast Cats

-- MAIN APPLICATION
addappid(3118450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118451, 1, "35e3dd9ebd4841dcf8607883fafd8e26362fa4086cb1080cf131ac1684337e52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3162830)
addappid(3342790)
addappid(3457020)
addappid(3457030)
