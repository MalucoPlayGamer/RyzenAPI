-- Lua provided by RyzenAPI
-- Game: Beat Saber - Monstercat Mixtape 2 - Dyro x Conro - "Memory Bank"

-- MAIN APPLICATION
addappid(3274210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274210,0,"c56d334d9d770f01b5f5c791804ec579db50b5df5b23903d48369596649aa829")

