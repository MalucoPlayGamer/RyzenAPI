-- Lua provided by RyzenAPI
-- Game: When Night Comes

-- MAIN APPLICATION
addappid(2405450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405451, 1, "a18cda454fe9b703823069149ed8906b5a62d991efc9d5cd9c51cc92bf8dd03e")

