-- Lua provided by RyzenAPI
-- Game: Yoiyami Dancers: Twilight Danmaku Dancers

-- MAIN APPLICATION
addappid(1998530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1998531, 1, "06316840763ebe0acc0396c37963c6ac5c2433d0d3d5b3af6406160710f18f01")

