-- Lua provided by RyzenAPI
-- Game: Yoiyami Dancers: Twilight Danmaku Dancers

-- MAIN APPLICATION
addappid(1998530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998531, 1, "06316840763ebe0acc0396c37963c6ac5c2433d0d3d5b3af6406160710f18f01")
