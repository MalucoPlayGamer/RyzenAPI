-- Lua provided by RyzenAPI
-- Game: Froggy's Farm & Friends

-- MAIN APPLICATION
addappid(2073410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073411, 1, "8d6f20119c47e7421e8306af19ce3bbdb5f80881974b4f5e1c1320383e7f199a")
