-- Lua provided by RyzenAPI
-- Game: Skibidi Toilet Hero: SEX MOD

-- MAIN APPLICATION
addappid(2889020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889020,0,"a9d772aa444625775530340003f701ec172f8dfd6b87bae7933475da74e08bd1")
