-- Lua provided by SkyAPI 
-- Game: Backrooms Cleanup Crew
addappid(3140990)
addappid(3140991, 1, "d81e674b226c7ab087cff2aedcf107268b8d53a6264227b549fe9b4a0ae7c35f")
