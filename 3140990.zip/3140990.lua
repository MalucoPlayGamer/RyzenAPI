-- Lua provided by RyzenAPI
-- Game: Backrooms Cleanup Crew

-- MAIN APPLICATION
addappid(3140990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140991, 1, "d81e674b226c7ab087cff2aedcf107268b8d53a6264227b549fe9b4a0ae7c35f")
