-- Lua provided by RyzenAPI
-- Game: Pathless Woods Demo

-- MAIN APPLICATION
addappid(1939580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939581, 1, "cd5c861e2396d397857f694e44386b156b5a4c527004e241334a0c6169a60a93")

