-- Lua provided by RyzenAPI
-- Game: Blumgi Soccer

-- MAIN APPLICATION
addappid(2918940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2918941, 1, "08775db9f50e381e3308fc66de58824ee16b5095ac9132e88917032173e773af")

