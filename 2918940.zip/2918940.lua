-- Lua provided by RyzenAPI
-- Game: Game: Blumgi Soccer

-- MAIN APPLICATION
addappid(2918940)
-- Game: addappid(2918940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918941, 1, "08775db9f50e381e3308fc66de58824ee16b5095ac9132e88917032173e773af")
