-- Lua provided by RyzenAPI
-- Game: Game: AppID 51100

-- MAIN APPLICATION
addappid(51100)
-- Game: addappid(51100)

-- MAIN APP DEPOTS / PACKAGES
addappid(51101, 1, "bb15e797a6979e41e53d589426e071f67a12bc03db51366af24550d876bdf47e")
addappid(51104, 1, "44085e870df5a0df78003e5da5e1791199aa626b0c5989dda100b59f1564853d")
