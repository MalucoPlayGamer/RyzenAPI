-- Lua provided by RyzenAPI
-- Game: AppID 51100

-- MAIN APPLICATION
addappid(51100)
addappid(250150)
addappid(250160)
addappid(250170)
addappid(258860)
addappid(284640)
addappid(284641)

-- MAIN APP DEPOTS / PACKAGES
addappid(51101, 1, "bb15e797a6979e41e53d589426e071f67a12bc03db51366af24550d876bdf47e")
addappid(51104, 1, "44085e870df5a0df78003e5da5e1791199aa626b0c5989dda100b59f1564853d")
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

