-- Lua provided by RyzenAPI
-- Game: Aliya's Ascent

-- MAIN APPLICATION
addappid(2660930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660931, 1, "664fc9d1f699fad4351c5731fa01295589dfd7d143cbea6bf65009973adc29a0")

