-- Lua provided by RyzenAPI
-- Game: 2479620

-- MAIN APPLICATION
addappid(2479620)
-- Game: addappid(2479620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479621, 1, "ea9829531486a5ef9c330acdee1a5d5a1a988155965309cfd287e5af728c8322")
