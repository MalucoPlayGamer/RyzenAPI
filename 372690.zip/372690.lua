-- Lua provided by RyzenAPI
-- Game: Game: AppID 372690

-- MAIN APPLICATION
addappid(372690)
-- Game: addappid(372690)

-- MAIN APP DEPOTS / PACKAGES
addappid(372691, 1, "61d1ef6f4c99e6cdc9603bfb89217a2fa708cf422719213660da59e035ae4a9e")
