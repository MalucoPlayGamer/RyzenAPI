-- Lua provided by RyzenAPI
-- Game: Game Of Puzzles: Nature

-- MAIN APPLICATION
addappid(1055890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055891, 1, "72f251c60f4268fb7ba25075c903dabd7e391f7f8c19f2fe719088b25630ad66")
