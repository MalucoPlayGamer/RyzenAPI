-- Lua provided by RyzenAPI
-- Game: Doggo Estates

-- MAIN APPLICATION
addappid(1958950)
-- Game: addappid(1958950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958951, 1, "5a8a560c51dcf928bf8c730f04171634625ce6e7d8461a94b5c05a5342342422")
