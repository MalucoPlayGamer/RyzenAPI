-- Lua provided by SkyAPI 
-- Game: Doggo Estates
addappid(1958950)
addappid(1958951, 1, "5a8a560c51dcf928bf8c730f04171634625ce6e7d8461a94b5c05a5342342422")
