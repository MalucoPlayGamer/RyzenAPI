-- Lua provided by RyzenAPI 
-- Game: HR Simulator
addappid(3179140)
addappid(3179141, 1, "339c1bf9c91692d7738fa88e5756ca66dc42a5d5ddb3fa9f8d0b951c0d663a42")
