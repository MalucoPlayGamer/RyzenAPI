-- Lua provided by RyzenAPI
-- Game: addappid(3179140)

-- MAIN APPLICATION
addappid(3179140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179141, 1, "339c1bf9c91692d7738fa88e5756ca66dc42a5d5ddb3fa9f8d0b951c0d663a42")
