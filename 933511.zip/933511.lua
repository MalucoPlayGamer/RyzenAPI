-- Lua provided by RyzenAPI
-- Game: addappid(933511)

-- MAIN APPLICATION
addappid(933511)

-- MAIN APP DEPOTS / PACKAGES
addappid(933511,0,"4728573505a17b7b646e02b89cac0af435f8feaa544c18484221e077aa88cbb8")
