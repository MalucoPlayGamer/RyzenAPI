-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933511)

-- MAIN APP DEPOTS / PACKAGES
addappid(933511,0,"4728573505a17b7b646e02b89cac0af435f8feaa544c18484221e077aa88cbb8")

