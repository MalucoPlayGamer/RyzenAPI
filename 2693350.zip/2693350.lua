-- Lua provided by RyzenAPI
-- Game: addappid(2693350)

-- MAIN APPLICATION
addappid(2693350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693351, 1, "7f3214ff4758d73548d6a4ec782c08c4e3947fe0646d91d942e6dc9e569236cf")
