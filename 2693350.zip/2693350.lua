-- Lua provided by RyzenAPI
-- Game: 偷外卖模拟器（我在2083年的末世求生）

-- MAIN APPLICATION
addappid(2693350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2693351, 1, "7f3214ff4758d73548d6a4ec782c08c4e3947fe0646d91d942e6dc9e569236cf")

