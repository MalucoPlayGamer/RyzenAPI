-- Lua provided by RyzenAPI
-- Game: Stellar Blade™

-- MAIN APPLICATION
addappid(3489700)
addappid(3596170)
addappid(3596200)
addappid(3596210)
addappid(3596220)
addappid(3662250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489701, 1, "2266ca31f6f2666ebe75906201e72f9398694030ff1c8214aacebcf74dc94ee3")
addappid(3596180, 0, "a55f79607c32a7e24a388464ddc3cfbc91b2dcee6691061bca3fb32d231ccb32")
addappid(3596190, 0, "1e65f8baa259f487dcdc1d3dce1e198dd23c9f7b77236e4e56fcc9f6b915a449")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
