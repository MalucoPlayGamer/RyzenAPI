-- Lua provided by RyzenAPI
-- Game: 562480

-- MAIN APPLICATION
addappid(562480)
-- Game: addappid(562480)

-- MAIN APP DEPOTS / PACKAGES
addappid(562481, 1, "4fd0d39d8bcc146d888d7a27bb749df7dc4b27bb12a3d1ec3147884762a269a0")
addappid(562482, 1, "410b38871f0b8e346454e0a4f5af42a403d96dd7c7df28b61059bcfebb6e882c")
