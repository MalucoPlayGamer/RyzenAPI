-- Lua provided by RyzenAPI
-- Game: Drive//Shaft

-- MAIN APPLICATION
addappid(747590)

-- MAIN APP DEPOTS / PACKAGES
addappid(747591, 1, "a6002cf943fc95d489b8f7634d48545080b0aecccf415f3d49f4d9acdb8df686")
