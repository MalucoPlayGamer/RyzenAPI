-- Lua provided by RyzenAPI
-- Game: AppID 747590

-- MAIN APPLICATION
addappid(747590)
-- Game: addappid(747590)

-- MAIN APP DEPOTS / PACKAGES
addappid(747591, 1, "a6002cf943fc95d489b8f7634d48545080b0aecccf415f3d49f4d9acdb8df686")
