-- Lua provided by RyzenAPI
-- Game: Wild Animal Racing

-- MAIN APPLICATION
addappid(389510)

-- MAIN APP DEPOTS / PACKAGES
addappid(389511, 1, "1ca1ceabd70d7c20f5a909a92e9e7136a71d6f5790ba41643dd729645a4dbab7")
