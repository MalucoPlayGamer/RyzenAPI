-- Lua provided by RyzenAPI
-- Game: AppID 1476420

-- MAIN APPLICATION
addappid(1476420)
-- Game: addappid(1476420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476421, 1, "deb6ec91a12dd1fe9c42840d2e1298a32c8358f270584461da17237b6c48500a")
