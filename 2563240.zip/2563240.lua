-- Lua provided by RyzenAPI
-- Game: AppID 2563240

-- MAIN APPLICATION
addappid(2563240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563241, 1, "b3972ff3c3fc5bcc6dd8f7f3b59da9b0fca7209840c90db877d2f36154ceeca1")
