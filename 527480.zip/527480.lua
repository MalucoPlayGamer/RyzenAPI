-- Lua provided by RyzenAPI
-- Game: Life Beetle

-- MAIN APPLICATION
addappid(527480)

-- MAIN APP DEPOTS / PACKAGES
addappid(527481, 1, "b05c175bb6d2a2936467dc95a5dc4211f136d8910598ffededc56e42d778198f")

