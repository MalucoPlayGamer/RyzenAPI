-- Lua provided by RyzenAPI
-- Game: eXoSpace Combat Engineer

-- MAIN APPLICATION
addappid(2876200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2876202,0,"febda1dee017f9205bbf6e6aca5b82a82c8a0bd43a9959f6a162fa67e60e3875")

