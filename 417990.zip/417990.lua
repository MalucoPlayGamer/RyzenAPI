-- Lua provided by RyzenAPI
-- Game: Major\Minor

-- MAIN APPLICATION
addappid(417990)
-- Game: addappid(417990)

-- MAIN APP DEPOTS / PACKAGES
addappid(417991, 1, "2a83e24e75a06a34d015b79e83dc463eb08382fa19449964a37b947af37c6dee")
addappid(417992, 1, "ede8e21f4a8e3c53087b16590466a43e295e55654fde910f5882ffc5e4b9ba97")
addappid(417993, 1, "24dabc2f2fbe5f1dd058b317d021a86c145d0882ec1b41278b41fb3a2cfb4cf2")
