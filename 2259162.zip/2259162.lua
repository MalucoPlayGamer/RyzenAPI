-- Lua provided by RyzenAPI
-- Game: 2259162

-- MAIN APPLICATION
addappid(2259162)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259162,0,"cd2cb7718330be39b5dcaffab964b16ece074400b72ee7aebcce9886ebe2d455")

