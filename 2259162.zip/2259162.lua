-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Seychelles XP

-- MAIN APPLICATION
addappid(2259162)
-- Game: addappid(2259162)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259162,0,"cd2cb7718330be39b5dcaffab964b16ece074400b72ee7aebcce9886ebe2d455")
