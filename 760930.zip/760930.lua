-- Lua provided by RyzenAPI
-- Game: Game: Bitcoin Farm

-- MAIN APPLICATION
addappid(760930)
-- Game: addappid(760930)

-- MAIN APP DEPOTS / PACKAGES
addappid(760931, 1, "04f12827505af244363f91c511173c3b7b52c47769150a81dd517d23dee66be3")
