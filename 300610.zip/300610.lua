-- Lua provided by RyzenAPI
-- Game: Pure Pool

-- MAIN APPLICATION
addappid(300610)

-- MAIN APP DEPOTS / PACKAGES
addappid(300611, 1, "62c69656df0c1bef82caf1591d71d431aca986b4d787fa273a54a63a15f5e883")
addappid(300612, 1, "dae30d8c2597d245e819d2f4b0d15d24a77552710cade4f2e58e4132b10f9e5d")
addappid(300860, 0, "9ab0fe97b50337ddf8c79bf184c4cb526b4cf0dcde443d74c384f4472ee8dedf")
addappid(305400, 0, "b24f862a38ac3698659e57e0d4728c58756a9c5c408572b88dcd332902ab9d88")
addappid(362360, 0, "be034f06794b3b98786e2a951204fdf99db6dab7c38ffbe4ffadb55db2edd20e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
