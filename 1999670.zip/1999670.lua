-- Lua provided by RyzenAPI
-- Game: Game: Date Ariane Remastered Demo

-- MAIN APPLICATION
addappid(1999670)
-- Game: addappid(1999670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999671, 1, "be5cbf9eb6fb31206ac5a5e327a97cb16ee915d640692944bd8f8f31058f5c7f")
