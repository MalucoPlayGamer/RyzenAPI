-- Lua provided by RyzenAPI
-- Game: AppID 11610

-- MAIN APPLICATION
addappid(11610)

-- MAIN APP DEPOTS / PACKAGES
addappid(11611, 1, "c534cf9fab310441efb5d2f9dcccbe0f9e51070a61b3820fd409bf31ef7d560c")
addappid(228981, 0, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac")
