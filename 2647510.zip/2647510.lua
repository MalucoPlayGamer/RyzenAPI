-- Lua provided by RyzenAPI
-- Game: addappid(2647510)

-- MAIN APPLICATION
addappid(2647510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647511, 1, "cb474fd9b27becd3d1ffc03eda7db2f903120db4c0ade2247f3caa214a0f40c5")
