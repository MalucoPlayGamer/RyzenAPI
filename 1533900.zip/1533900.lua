-- Lua provided by RyzenAPI
-- Game: MAMIYA Demo

-- MAIN APPLICATION
addappid(1533900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533901, 1, "63b2eb064f3f0bd3daa620885bf6fd9ca9c8babeea5bc8b012ec0246490a22b4")
