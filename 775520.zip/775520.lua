-- Lua provided by RyzenAPI
-- Game: Animals Memory: Dinosaurs

-- MAIN APPLICATION
addappid(775520)

-- MAIN APP DEPOTS / PACKAGES
addappid(775521,0,"0b38907b5f6fad9401e8b680d69a9778925f95d242ba5d482132aa2536a7c161")

