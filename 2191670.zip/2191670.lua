-- Lua provided by RyzenAPI
-- Game: AppID 2191670

-- MAIN APPLICATION
addappid(2191670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191671, 1, "20acf61edd269cc0b69619432194ec732553fe9028e64d014749bdbbe3a84202")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2191900)
addappid(2260000)
