-- Lua provided by RyzenAPI
-- Game: Nyanco Impact

-- MAIN APPLICATION
addappid(2191670)
-- Game: addappid(2191670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191671, 1, "20acf61edd269cc0b69619432194ec732553fe9028e64d014749bdbbe3a84202")
