-- Lua provided by RyzenAPI
-- Game: A Difficult Game About ROLLING - ReUpRise

-- MAIN APPLICATION
addappid(1901130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901131, 1, "dc7f702b11238444ee0e2bcb1eeabe6ae401c0bd49d4c0256ae3bd4db2105b71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
