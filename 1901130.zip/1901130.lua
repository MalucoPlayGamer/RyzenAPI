-- Lua provided by RyzenAPI
-- Game: 1901130

-- MAIN APPLICATION
addappid(1901130)
-- Game: addappid(1901130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901131, 1, "dc7f702b11238444ee0e2bcb1eeabe6ae401c0bd49d4c0256ae3bd4db2105b71")
