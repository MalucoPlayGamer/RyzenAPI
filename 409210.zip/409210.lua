-- Lua provided by RyzenAPI
-- Game: 409210

-- MAIN APPLICATION
addappid(409210)
-- Game: addappid(409210)

-- MAIN APP DEPOTS / PACKAGES
addappid(409210,0,"43a0e5ba53c4ddb0351171f12d78d32519486b4da58ccfdda5d77397a1e2f663")
