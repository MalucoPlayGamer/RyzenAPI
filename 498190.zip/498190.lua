-- Lua provided by RyzenAPI
-- Game: 498190

-- MAIN APPLICATION
addappid(498190)
-- Game: addappid(498190)

-- MAIN APP DEPOTS / PACKAGES
addappid(498191, 1, "aa1bfc0278c1e3247a2887e30fed24a6509d4b0df9b67e4568a7b7da42222b9f")
