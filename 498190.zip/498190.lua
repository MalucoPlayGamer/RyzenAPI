-- Lua provided by RyzenAPI
-- Game: Dragon Rage

-- MAIN APPLICATION
addappid(498190)

-- MAIN APP DEPOTS / PACKAGES
addappid(498191, 1, "aa1bfc0278c1e3247a2887e30fed24a6509d4b0df9b67e4568a7b7da42222b9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
