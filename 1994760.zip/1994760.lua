-- Lua provided by SkyAPI 
-- Game: The Fairy's Secret
addappid(1994760)
addappid(1994761, 1, "9677dbc9f5ef404df50b6f96ff6b205110113dacd8ecea62d5ce338c5cc2a05f")
