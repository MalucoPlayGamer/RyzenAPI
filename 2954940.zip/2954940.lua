-- Lua provided by RyzenAPI 
-- Game: Heart of Shadows
addappid(2954940)
addappid(2954941, 1, "2a024adcdad70b310e27ea3856d8f1fe66a4fc78ba9e9fde4c30433b1fe3e7b1")
