-- Lua provided by RyzenAPI
-- Game: 32120

-- MAIN APPLICATION
addappid(32120)
-- Game: addappid(32120)

-- MAIN APP DEPOTS / PACKAGES
addappid(32121, 1, "854a61645586c57b26adefd2df9ed266d435e9973468ac73ff699770466b6ac3")
addappid(32122, 1, "0db3c73fc3f2062eec58bc8ed3272a90f974d7097f1dba32f1732d7ddcc68acc")
addappid(32123, 1, "935059a2efbefa3ff5b6da05cd408b9b34ccaa9a4b11ae3be28cf4ce286fef5c")
addappid(32124, 1, "43bf5b14fb3ee15a5e468495d9a4cd0d9fdefccbe1c4c5ae2532ab581636b6de")
addappid(32125, 1, "6e1035be1fba9df94a134dae51220018d5ddfdad6b26bde52a936d5866d6e550")
addappid(32126, 1, "45fb97afb38140b9402a19602370603f0508b1d88ba59f63e4227805f51c1b33")
