-- 2477710's Lua and Manifest Created by Hubcap Manifest
-- Nimbit Frontier
-- Created: August 17, 2026 at 12:56:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2477710) -- Nimbit Frontier
-- MAIN APP DEPOTS
addappid(2477711, 1, "b508953a644332ddde83c5dcc1dd5a839f0ee990ede276caa8b6fa9bec6eb5c4") -- Depot 2477711
setManifestid(2477711, "1564857854142793073", 1026408600)