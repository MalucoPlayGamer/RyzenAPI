-- Lua provided by RyzenAPI
-- Game: Nimbit Frontier

-- MAIN APPLICATION
addappid(2477710) -- Nimbit Frontier

-- MAIN APP DEPOTS / PACKAGES
addappid(2477711, 1, "b508953a644332ddde83c5dcc1dd5a839f0ee990ede276caa8b6fa9bec6eb5c4") -- Depot 2477711

