-- Lua provided by RyzenAPI
-- Game: addappid(1432182)

-- MAIN APPLICATION
addappid(1432182)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432182,0,"d7dfd383797725ee8b3b37d409f325fff58b964e6885a63ffc5bb5b4b27767c3")
