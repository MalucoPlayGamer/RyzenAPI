-- 4925040's Lua and Manifest Created by Hubcap Manifest
-- Gear Clash: Hero Unite
-- Created: July 30, 2026 at 14:15:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(4925040) -- Gear Clash: Hero Unite
-- MAIN APP DEPOTS
addappid(4925041, 1, "e8e77d152aeedc45d7e3e22476c88be432a3aa3f4390b2261eba4fc569ccc2f8") -- Depot 4925041
setManifestid(4925041, "5792068640977570701", 239486288)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4925100) -- Gear Clash Hero Unite - Penguin Package
addappid(4925110) -- Gear Clash Hero Unite - Cowboy Package