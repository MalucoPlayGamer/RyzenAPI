-- Lua provided by RyzenAPI
-- Game: 730450

-- MAIN APPLICATION
addappid(730450)
-- Game: addappid(730450)

-- MAIN APP DEPOTS / PACKAGES
addappid(730451, 1, "6755acbb679f222647fcd07b01d61fae00d61a71db3738ac86ccf779d6b5a9e6")
