-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1477010)
addappid(1477011)
addappid(1477013)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477012,0,"d8d27a27d12007252c6db515986b51deb8e08ad00542f8146eaf4d6bdf626d64")

