-- Lua provided by RyzenAPI
-- Game: 796980

-- MAIN APPLICATION
addappid(796980)
-- Game: addappid(796980)

-- MAIN APP DEPOTS / PACKAGES
addappid(796981, 1, "874c0b31677227bc6d42d04dbd0382e1ca97a4e6c2f05c65278f60c09fb98da6")
