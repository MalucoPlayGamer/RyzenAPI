-- Lua provided by RyzenAPI
-- Game: addappid(6860)

-- MAIN APPLICATION
addappid(6860)

-- MAIN APP DEPOTS / PACKAGES
addappid(6861, 1, "c3cdb6bf3ebc7489b0730732691a77bbc0102317d229d5d095a5bc4a3f6c4b98")
addappid(6862, 1, "fd3be40379ef630b8c1d2330b32dde338221c64caadfc4f4589b25c4373c2f8d")
addappid(6863, 1, "d09b82c93b3200d9d8676b007c91ce09aa115ed53a9e3ecc74901facac90a2c2")
