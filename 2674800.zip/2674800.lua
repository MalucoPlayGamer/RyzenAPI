-- Lua provided by RyzenAPI
-- Game: AppID 2674800

-- MAIN APPLICATION
addappid(2674800)
-- Game: addappid(2674800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674801, 1, "708ad4f289d2e9dbbdbd9c464f5a7d1ea59ad9ce60c32f384ecd12dbd4545c58")
