-- Lua provided by RyzenAPI
-- Game: Attack of the Earthlings

-- MAIN APPLICATION
addappid(621930)
addappid(953650)

-- MAIN APP DEPOTS / PACKAGES
addappid(621931, 1, "e42ec6de5df27834e1638643fe48edb441772941c913ba7649e56696baa0e53d")
addappid(621932, 1, "be1e39a7d2ec2bf0c1d475e9d53e4d23bf1c29114f2a1d3db0983beb6b354fc8")
