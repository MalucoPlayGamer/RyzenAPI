-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2585540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585540,0,"dd7880d073d241365e41621c04e9d79f870ed37e73a43133ba325ea961d95156")

