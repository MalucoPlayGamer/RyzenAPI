-- Lua provided by RyzenAPI
-- Game: 2243670

-- MAIN APPLICATION
addappid(2243670)
-- Game: addappid(2243670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243671, 1, "b0fe8638f7506cbebdf4b1d77fda41313c11da0023696b13e91c6133e760c0fe")
