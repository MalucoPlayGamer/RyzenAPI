-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2715330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715330,0,"88866cc62cc46f2f3a99af621d7832bb159624290628206aa55d1f9dba5819c0")
