-- Lua provided by RyzenAPI
-- Game: Time Mysteries 3: The Final Enigma

-- MAIN APPLICATION
addappid(319320)

-- MAIN APP DEPOTS / PACKAGES
addappid(319321, 1, "a700fb362d5030bef8d5fe87c0ff61aadbcc99515a906ec6285bdfefa52bf6ac")
addappid(319322, 1, "789d6257a6e21cc56b027992f0e51fe6d2ac9e9c3915db1289b5d21be1481e56")
addappid(319323, 1, "a544b4c548994ca7dd8275e7782d51e1f213213f03fa06fcaf7f1cd2da0d6645")
