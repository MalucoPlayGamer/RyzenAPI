-- Lua provided by RyzenAPI
-- Game: 757730

-- MAIN APPLICATION
addappid(757730)
-- Game: addappid(757730)

-- MAIN APP DEPOTS / PACKAGES
addappid(757731, 1, "ca2778ea1de88fe03e9fc610d45fc6a3514918cbec835d4d001a8cc1082c260f")
