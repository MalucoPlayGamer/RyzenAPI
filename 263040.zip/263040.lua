-- Lua provided by RyzenAPI
-- Game: Bot Colony

-- MAIN APPLICATION
addappid(263040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(263041, 1, "04f0186615d3f23657ee679121e008b71fdd5c5b01c52a6886eed9b12c02f02a")

