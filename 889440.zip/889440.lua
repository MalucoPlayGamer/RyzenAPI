-- Lua provided by RyzenAPI
-- Game: addappid(889440)

-- MAIN APPLICATION
addappid(889440)

-- MAIN APP DEPOTS / PACKAGES
addappid(889441, 1, "32aca97653fd610457c17e920f3ec6fe646a91e05f606c4cc13fc64ca0812c05")
