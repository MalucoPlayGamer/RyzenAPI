-- Lua provided by RyzenAPI
-- Game: Find the Demon 恶魔鉴定守则 Demo

-- MAIN APPLICATION
addappid(2949290)
-- Game: addappid(2949290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949291, 1, "5cf7b8a5a7856d25c141559015907c5a003874cd918acf92a52bcb2d5b919501")
