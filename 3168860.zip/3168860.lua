-- Lua provided by RyzenAPI
-- Game: Game: It's Time, Your Majesty Demo

-- MAIN APPLICATION
addappid(3168860)
-- Game: addappid(3168860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168861, 1, "3913b01f12a96b0dc05bdbca80047d34e4706410d94e6e7c5c061a6f0af1dd8f")
