-- Lua provided by SkyAPI 
-- Game: Escape From School
addappid(1729790)
addappid(1729791, 1, "7ece05487bed10a5fd687c5507a0d9deaffbb9bc8aac1d508f221e5ddd81cc7b")
