-- Lua provided by RyzenAPI
-- Game: Escape From School

-- MAIN APPLICATION
addappid(1729790)
-- Game: addappid(1729790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729791, 1, "7ece05487bed10a5fd687c5507a0d9deaffbb9bc8aac1d508f221e5ddd81cc7b")
