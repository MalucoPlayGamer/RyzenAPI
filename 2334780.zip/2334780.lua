-- Lua provided by RyzenAPI
-- Game: Game: AppID 2334780

-- MAIN APPLICATION
addappid(2334780)
-- Game: addappid(2334780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334781, 1, "71b6db601489fe39fa2042187229473312aabb44fe12c284d25486b1f9687bed")
