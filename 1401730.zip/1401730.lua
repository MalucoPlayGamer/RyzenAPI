-- Lua provided by RyzenAPI 
-- Game: AppID 1401730
addappid(1401730)
addappid(1401731, 1, "9feb5500bb35f27058f1c86e3a465a1f4904b2f5abe5ff891a9928cb702fea64")
