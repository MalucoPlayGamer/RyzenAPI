-- Lua provided by RyzenAPI
-- Game: 514800

-- MAIN APPLICATION
addappid(514800)
-- Game: addappid(514800)

-- MAIN APP DEPOTS / PACKAGES
addappid(514800,0,"1d73f63651604c1bd23b88297403551f06c46f60d55eb0fe5706b5d89cdc6b02")
