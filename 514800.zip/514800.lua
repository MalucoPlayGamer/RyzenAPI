-- Lua provided by RyzenAPI
-- Game: Quantum Break - Original Game Soundtrack

-- MAIN APPLICATION
addappid(514800)

-- MAIN APP DEPOTS / PACKAGES
addappid(514800,0,"1d73f63651604c1bd23b88297403551f06c46f60d55eb0fe5706b5d89cdc6b02")
