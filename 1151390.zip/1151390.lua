-- Lua provided by RyzenAPI
-- Game: addappid(1151390)

-- MAIN APPLICATION
addappid(1151390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151392,0,"67dbea8944bfa8416992ab0782de3fc97e3acc894e8badb48d3179263414dcb5")
