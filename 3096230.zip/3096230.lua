-- 3096230's Lua and Manifest Created by Hubcap Manifest
-- DOGENSTEIN
-- Created: August 05, 2026 at 05:25:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(3096230, 1, "79b36517b69a2fad5c1d96e98ac6d3461bbda480594b7563679dfb315fa3452d") -- DOGENSTEIN
-- MAIN APP DEPOTS
addappid(3096235, 1, "aa76ae9c69ae6e6f941f4c3af587bce93dc89913bfdc0b5c6337cff3c29667d0") -- Depot 3096235
setManifestid(3096235, "4426241445893187407", 444358845)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)