-- Lua provided by RyzenAPI
-- Game: Trekking and Camping | 远足与露营

-- MAIN APPLICATION
addappid(1554780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554781, 1, "c057fb039271f553fc45d735ea65d271886d64cee4615c24bd931c5275e5e018")

