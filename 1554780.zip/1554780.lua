-- Lua provided by SkyAPI 
-- Game: Trekking and Camping | 远足与露营
addappid(1554780)
addappid(1554781, 1, "c057fb039271f553fc45d735ea65d271886d64cee4615c24bd931c5275e5e018")
