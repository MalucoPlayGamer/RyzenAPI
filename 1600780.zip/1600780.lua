-- Lua provided by RyzenAPI
-- Game: MY LITTLE PONY: A Maretime Bay Adventure

-- MAIN APPLICATION
addappid(1600780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600781, 1, "45af09a05a0ac0a1cd3bba85bf0c39883d53b9ca70bc65c9b591d2b56889fd35")
