-- Lua provided by RyzenAPI
-- Game: 2148760

-- MAIN APPLICATION
addappid(2148760)
-- Game: addappid(2148760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148761, 1, "e848127e6a4e302545bd5ae91bf59263bcaad9292d98a99fc4c9fbf2eb45d902")
