-- Lua provided by SkyAPI 
-- Game: AppID 1094920
addappid(1094920)
addappid(1094921, 1, "ad47ab3ec0c2c84e27c8be94a6810ddcaf42718715aa120bfb0246d0cf27a9ab")
