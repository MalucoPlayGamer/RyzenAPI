-- Lua provided by RyzenAPI
-- Game: AppID 1094920

-- MAIN APPLICATION
addappid(1094920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094921, 1, "ad47ab3ec0c2c84e27c8be94a6810ddcaf42718715aa120bfb0246d0cf27a9ab")
