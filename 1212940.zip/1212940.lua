-- Lua provided by SkyAPI 
-- Game: Ayahuasca
addappid(1212940)
addappid(1212941, 1, "4cf068b71dc656c90a14b105241c376b260a3fa8e42ac19a97391ea1adabe742")
