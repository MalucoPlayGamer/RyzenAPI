-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3354690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354690,0,"ac49f77008afe547e74098da19f447568a23d0c76d6cfe50537f0210b1209498")

