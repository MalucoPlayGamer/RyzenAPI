-- Lua provided by RyzenAPI
-- Game: The Sacred Stone

-- MAIN APPLICATION
addappid(432410)

-- MAIN APP DEPOTS / PACKAGES
addappid(432411, 1, "8513f3bde1dd801828e487ccf4236e50fb1d4f32752b2f30ed2379ef2826d848")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
