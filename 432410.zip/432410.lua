-- Lua provided by RyzenAPI
-- Game: The Sacred Stone

-- MAIN APPLICATION
addappid(432410)

-- MAIN APP DEPOTS / PACKAGES
addappid(432411, 1, "8513f3bde1dd801828e487ccf4236e50fb1d4f32752b2f30ed2379ef2826d848")
