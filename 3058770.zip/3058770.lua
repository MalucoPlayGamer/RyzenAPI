-- Lua provided by RyzenAPI
-- Game: addappid(3058770)

-- MAIN APPLICATION
addappid(3058770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058773,0,"8a4b261b51fee56f7180946e71fca7f0424c8f75c78431195ec9d28974d52cde")
