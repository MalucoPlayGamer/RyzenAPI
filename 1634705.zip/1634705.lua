-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Weapon set 3

-- MAIN APPLICATION
addappid(1634705)
-- Game: addappid(1634705)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634705,0,"d011b496b68e023975f77d637fcbb90644ef32fda9a39ca8104278b7c2498c2e")
