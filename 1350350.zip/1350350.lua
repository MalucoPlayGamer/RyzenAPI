-- Lua provided by SkyAPI 
-- Game: AppID 1350350
addappid(1350350)
addappid(1350351, 1, "ae3d924a7deae141934e0636a13ff1dc4b0d339062c3cb8f6ba1cf6f26ce113e")
