-- Lua provided by RyzenAPI
-- Game: Corridor 7: Alien Invasion

-- MAIN APPLICATION
addappid(1341890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341891, 1, "0885d29058c8e2782a804a10363aedae6c60d1e8a0ab5c1ade3430791be52478")
addappid(1341892, 1, "d75acf487a48ab13c7aa6c864e39260ddf8ac0403b962c658e93ead65218485e")
