-- Lua provided by RyzenAPI
-- Game: Roast Party

-- MAIN APPLICATION
addappid(1193560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193561, 1, "bd5385dacda11961c5a25cc2b506fb00e461bbc0aaa235b5d085e882c2c36700")

