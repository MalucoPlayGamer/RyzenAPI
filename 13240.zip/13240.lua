-- Lua provided by RyzenAPI
-- Game: Unreal Tournament: Game of the Year Edition

-- MAIN APPLICATION
addappid(13240)

-- MAIN APP DEPOTS / PACKAGES
addappid(13241, 1, "8bb511cc7650153a16e5fa69714dedd1a0886de2e80faf311f94f9b4a471a3c7")

