-- Lua provided by RyzenAPI
-- Game: 708620

-- MAIN APPLICATION
addappid(708620)
-- Game: addappid(708620)

-- MAIN APP DEPOTS / PACKAGES
addappid(708620,0,"92a348e88309c8eaafefa6b7dd09fe7ebad3b664aa2f376a586f4ebd53ef4934")
