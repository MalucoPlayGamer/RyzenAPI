-- Lua provided by RyzenAPI 
-- Game: Hentai Detective
addappid(1781710)
addappid(1781711, 1, "a8b11733a586e6f6ac9f8d71a95b1af80f08c9dd10e38ff6b9496f1faee21cdc")
