-- Lua provided by RyzenAPI 
-- Game: AppID 2934770
addappid(2934770)
addappid(2934771, 1, "d5583f14ada87ead3bba7f9f6ebd0978c1ed0a99b2a841283406fe36aa913dee")
