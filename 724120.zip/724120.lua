-- Lua provided by RyzenAPI
-- Game: Rise:30 Minutes to Extinction

-- MAIN APPLICATION
addappid(724120)

-- MAIN APP DEPOTS / PACKAGES
addappid(724121, 1, "11a9dba63892063e3b323699e8796a45ba8c2b265486b2da0ac5c258ba9cc145")

