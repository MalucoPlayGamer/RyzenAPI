-- Lua provided by RyzenAPI
-- Game: Dungeon Delver

-- MAIN APPLICATION
addappid(1502760)
-- Game: addappid(1502760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502761, 1, "11d7c7ec517ba1d90daecb84df9da87d4c182cd397157da415d192408e3304ef")
