-- Lua provided by RyzenAPI
-- Game: Six nights to die

-- MAIN APPLICATION
addappid(2483380)
-- Game: addappid(2483380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483381, 1, "0cffc767b2f0751a999efc5ba071fe498e13b501793aa1b51aee9fed085b1c09")
