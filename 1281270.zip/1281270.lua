-- Lua provided by RyzenAPI
-- Game: Game: Fatum Betula

-- MAIN APPLICATION
addappid(1281270)
-- Game: addappid(1281270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281271, 1, "5de696afe622fd7dc08c71e002c0a8199780972a67cde1c0f7babec0b2ca1345")
addappid(1281272, 1, "875b530b4ca3a8daf07f3a7bde0fca92f042367f9e663b7f97c163653db31eee")
