-- Lua provided by RyzenAPI
-- Game: Whispered Secrets: Tying the Knot Collector's Edition

-- MAIN APPLICATION
addappid(1971880)
-- Game: addappid(1971880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971881, 1, "04c1e9f3865595991552fc06636ec2146caec14887ccc4ffc3d926b679794ac7")
