-- Lua provided by RyzenAPI 
-- Game: Madhouse Madness Prologue
addappid(2660620)
addappid(2660621, 1, "5d5925a6e95efb9f35f04cc6d09b977fc5b2c642062e145bdb86fd21c374c3b2")
