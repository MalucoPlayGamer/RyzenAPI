-- Lua provided by RyzenAPI
-- Game: Madhouse Madness Prologue

-- MAIN APPLICATION
addappid(2660620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2660621, 1, "5d5925a6e95efb9f35f04cc6d09b977fc5b2c642062e145bdb86fd21c374c3b2")

