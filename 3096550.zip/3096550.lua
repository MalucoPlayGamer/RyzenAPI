-- Lua provided by RyzenAPI
-- Game: Twilight Wars

-- MAIN APPLICATION
addappid(3096550)

