-- Lua provided by SkyAPI 
-- Game: Salt and Sacrifice
addappid(1437400)
addappid(1437401, 1, "383231df292f47834de077d62e918f54d12a18edd2304ecf501bfca6ee1b23ba")
addappid(1437402, 1, "f5dd3a22e70d94a79e0b96f395c62e8396c49bdb345d5d58784906c1cb68e8f5")
