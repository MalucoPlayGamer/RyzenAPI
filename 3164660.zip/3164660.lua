-- Lua provided by RyzenAPI
-- Game: 3164660

-- MAIN APPLICATION
addappid(3164660)
-- Game: addappid(3164660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164661, 1, "8be6441a40e3daad5a5e060a544fe87a4325389ac0bf79d647c785ec4332c59a")
