-- Lua provided by RyzenAPI
-- Game: Left 4 Dead 2

-- MAIN APPLICATION
addappid(550)
addappid(271840)
addappid(322070)

-- MAIN APP DEPOTS / PACKAGES
addappid(551, 1, "133d1039d438364b5569e91221c10fcd640f141d7700c921c02721ebe87c0459")
addappid(552, 1, "2585a22b53c3e040982897d140378d942a22994ffae3ae2085eddf36af94f84d")
addappid(553, 1, "7bc7ab0b0631017e69adc7251eed912215e5ec3629c4e493aed3d59f7647e206")
addappid(554, 1, "0c3a5e0ba83eb05f47677cb62ca99c7066627aa92de37c4ebde5de2f57b63b91")
addappid(555, 1, "ba7293680729c4c2f0335c1eb7e63230a542519312576e0a2da68072b247cbad")
addappid(556, 1, "fe84c8d4b2c27f6155d890d88f0621f11f094610f3c90b0c47f896daddf75e19")
addappid(557, 1, "4a93866c750e2a770cad19228d2659175631748b443f8813b0b60e652a9a00ef")
addappid(558, 1, "b118e5db5c1f6b7671ed8b832dcb8826cc50b86018c97d995a752f4419757c50")
addappid(559, 1, "aa6a7da182c33f764eb15b5f323b9806273e9fed6c8b60b32e4577b0b5e0d339")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(565)
