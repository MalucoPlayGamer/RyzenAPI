-- Lua provided by RyzenAPI
-- Game: Game: AppID 1078800

-- MAIN APPLICATION
addappid(1078800)
-- Game: addappid(1078800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078801, 1, "e055acc82ce44eef192df6a71e1f77e73041f8c2ace8c737b45d9b1dd42699bb")
addappid(1078802, 1, "22be09693edb0aa8a1b61203a50495ffd6057a49f48c9571fdb7b21c6bbe4520")
