-- Lua provided by RyzenAPI
-- Game: Kingdom of Aurelia: Mystery of the Poisoned Dagger

-- MAIN APPLICATION
addappid(550390)

-- MAIN APP DEPOTS / PACKAGES
addappid(550391,0,"850f97e057a00114fef441f6bd85124547429832da6caa599cc2177cbda929fe")
addappid(550392,0,"576b3d9aa08cb91f1e1e3ae914d2fc955a1c88a205eb21b5c13772e319a71095")

