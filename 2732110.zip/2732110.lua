-- Lua provided by RyzenAPI
-- Game: At Winter's End Soundtrack

-- MAIN APPLICATION
addappid(2732110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732111, 1, "fcbee7aca325e5dbae5e212bd32421337e04bec7770710c7de46055b0401250e")
addappid(2732112, 1, "6c99584e819bf3fe65e40435dc2229cda509d2dd3a7c28c04aec90363b9d1d61")
