-- 1119730's Lua and Manifest Created by Hubcap Manifest
-- Ranch Simulator
-- Created: July 01, 2026 at 01:51:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 2
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1119730, 1, "79dae884d60ab066fb13e508fdbe1d76c1708c54d77d854bde4e376da47a3ae5") -- Ranch Simulator
-- MAIN APP DEPOTS
addappid(1119731, 1, "5ba0690900411cc3e2378222e0e437425d26e3b81707810123555cf0c5606a77") -- Ranch Simulator Content
setManifestid(1119731, "6039016761168206005", 18370854787)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3255980) -- Ranch Simulator Southwest Ranch  Farm Expansion Pack
addappid(4539740) -- Ranch Simulator Highland Cows Pack