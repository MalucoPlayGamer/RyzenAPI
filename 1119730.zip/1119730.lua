-- Lua provided by RyzenAPI
-- Game: Ranch Simulator: Build, Hunt, Farm

-- MAIN APPLICATION
addappid(1119730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119731, 1, "5ba0690900411cc3e2378222e0e437425d26e3b81707810123555cf0c5606a77")
