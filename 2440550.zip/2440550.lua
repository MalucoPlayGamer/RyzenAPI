-- Lua provided by RyzenAPI
-- Game: addappid(2440550)

-- MAIN APPLICATION
addappid(2440550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440555,0,"712a1a56e54a3e9e4905de29182498bb1c67f67d0905d993dbda122c59ab070e")
