-- Lua provided by RyzenAPI
-- Game: One Small Fire At A Time

-- MAIN APPLICATION
addappid(476410)
-- Game: addappid(476410)

-- MAIN APP DEPOTS / PACKAGES
addappid(476411, 1, "d0e61a3d875d51f501788126bffb9991ea9e67c2a329f5a8caebffcb254c755d")
addappid(476412, 1, "c46bc5a469040ec9bc5875ffbf311d4b8f45563bb213fecd03aacfe0f7322f5f")
addappid(476413, 1, "3cf63e293368c97466651d5921a2214b572b2fddba64da49b7a9cb3d7119583a")
addappid(476414, 1, "cc1e418b68b92dd2b35af40ccb75d1b25d8e9819e2edf75b10fd9f8a6a29482b")
addappid(476415, 1, "4f4a07f1a3e4a20c6860cd5a0109d14e5ee8a13839a93407018e73f9ebff78c8")
