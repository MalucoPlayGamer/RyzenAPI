-- Lua provided by RyzenAPI 
-- Game: LIFESPAWN
addappid(1410790)
addappid(1410791, 1, "1b048a96c97fe99872e24767f01e11eaba6c37fd92bdec823c0559550ccb387e")
