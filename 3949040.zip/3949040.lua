-- Lua provided by SkyAPI 
-- Game: RV There Yet?
addappid(3949040)
addappid(3949041, 1, "98435e5f712a11c88e455130e718254b2745a33f7443b2034d634f54af0da031")
