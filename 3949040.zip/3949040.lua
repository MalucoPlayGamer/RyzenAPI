-- Lua provided by RyzenAPI
-- Game: Game: RV There Yet?

-- MAIN APPLICATION
addappid(3949040)
-- Game: addappid(3949040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3949041, 1, "98435e5f712a11c88e455130e718254b2745a33f7443b2034d634f54af0da031")
