-- Lua provided by RyzenAPI
-- Game: BioEden

-- MAIN APP DEPOTS / PACKAGES
addappid(3265840, 1, "2daa2240e462677049b7b049a362ca1e78fe26dc6d2bf119463966ebf32dec1b") -- BioEden
addappid(3265841, 1, "0a78c4d0dfec664183a664ac93519fa38e2e15a2abf06358cbe14f7f90fca5e4") -- Depot 3265841

