-- Lua provided by RyzenAPI
-- Game: 1174500

-- MAIN APPLICATION
addappid(1174500)
-- Game: addappid(1174500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174501, 1, "584dc1e7e8c4c97ca9d6bd9be211dae872c6d94c0da212614d86ee1eb1752558")
