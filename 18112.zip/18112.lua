-- Lua provided by RyzenAPI
-- Game: 18112

-- MAIN APPLICATION
addappid(18112)
-- Game: addappid(18112)

-- MAIN APP DEPOTS / PACKAGES
addappid(18112,0,"b482a449bd35b452981e9bb581023b774ad3677052e2192d15d98abc66b64300")
