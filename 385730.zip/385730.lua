-- Lua provided by RyzenAPI
-- Game: WWE 2K16

-- MAIN APPLICATION
addappid(385730)

-- MAIN APP DEPOTS / PACKAGES
addappid(385731, 1, "80bebb1d9dae5ea48e85969d1d44bb5f207037bb1a0737b785ff9f845c78dde1")
