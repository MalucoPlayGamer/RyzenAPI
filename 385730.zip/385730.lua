-- Lua provided by RyzenAPI
-- Game: WWE 2K16

-- MAIN APPLICATION
addappid(385730)

-- MAIN APP DEPOTS / PACKAGES
addappid(385731, 1, "80bebb1d9dae5ea48e85969d1d44bb5f207037bb1a0737b785ff9f845c78dde1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
