-- Lua provided by RyzenAPI
-- Game: Monster Ops 5

-- MAIN APPLICATION
addappid(3161530)
-- Game: addappid(3161530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161531, 1, "c8e2e085dc93dbe63fc7d8bbec7f1fd91f9aa2f7f1a3a12591253346c3905efc")
