-- Lua provided by RyzenAPI
-- Game: Surfers Code

-- MAIN APPLICATION
addappid(2733280) -- Surfers Code

-- MAIN APP DEPOTS / PACKAGES
addappid(2733281, 1, "b77066703a94e83ddc50cfc3cb21841c587ee376a85cfebad14f96e9a43c968a") -- Depot 2733281

