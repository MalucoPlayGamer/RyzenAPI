-- Lua provided by RyzenAPI
-- Game: addappid(1939100)

-- MAIN APPLICATION
addappid(1939100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939101, 1, "c01ecdeeb5905836fd332ec325fd4068016b5fb685d1d9f96f385aa7b7f1504d")
