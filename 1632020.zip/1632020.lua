-- Lua provided by RyzenAPI
-- Game: 4Prot

-- MAIN APPLICATION
addappid(1632020)
addappid(1708930) -- Student Pack
addappid(1708931) -- Professional Pack
addappid(1715520) -- Pipes Collection
addappid(1715521) -- Decals Industry Collection
addappid(3488240) -- 4Prot - Characters Collection
addappid(3488290) -- 4Prot - VR Expansion Pack
addappid(3488320) -- Kids Collection
addappid(3488330) -- 4Prot - Metalmechanics Collection
addappid(3488340) -- 4Prot - Criminalistics Collection
addappid(3488360) -- 4Prot - Automotive Industry Collection
addappid(3488370) -- 4Prot - Textile Industry Collection
addappid(3488420) -- 4Prot - Food Industry Collection
addappid(3488430) -- 4Prot - Hydrocarbons Industry Collection

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1632021, 1, "09afd910eae4785a99df597e4116abad1ac4537ae4e488f1b44194be725bad0e") -- (windows, 64-bit)
addappid(1632022, 1, "21214a5113f68bd10b6147620d7d45e04e7f367a2bb9c621050e878508db0581") -- (macos, 64-bit)