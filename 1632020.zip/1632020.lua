-- Lua provided by RyzenAPI 
-- Game: AppID 1632020
addappid(1632020)
addappid(1632021, 1, "09afd910eae4785a99df597e4116abad1ac4537ae4e488f1b44194be725bad0e")
addappid(1632022, 1, "21214a5113f68bd10b6147620d7d45e04e7f367a2bb9c621050e878508db0581")
