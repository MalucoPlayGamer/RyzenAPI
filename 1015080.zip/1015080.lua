-- Lua provided by SkyAPI 
-- Game: Vampire & Monsters: Hidden Objects
addappid(1015080)
addappid(1015081, 1, "cc7bc5133a5169308e7e0a53135af09dbd631fcbbe66526f7551f512e8cf8d3b")
