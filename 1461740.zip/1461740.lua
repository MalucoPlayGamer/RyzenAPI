-- Lua provided by RyzenAPI
-- Game: Game: Mouse Painting Master

-- MAIN APPLICATION
addappid(1461740)
-- Game: addappid(1461740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461741, 1, "58750a05f44e441f4ae233955d7e43831ac7bce3c40b8cb87cc57a808244d430")
