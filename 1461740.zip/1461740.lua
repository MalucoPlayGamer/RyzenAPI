-- Lua provided by SkyAPI 
-- Game: Mouse Painting Master
addappid(1461740)
addappid(1461741, 1, "58750a05f44e441f4ae233955d7e43831ac7bce3c40b8cb87cc57a808244d430")
