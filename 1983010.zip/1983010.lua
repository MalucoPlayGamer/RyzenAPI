-- Lua provided by RyzenAPI
-- Game: Game: Furry Hentai Isekai

-- MAIN APPLICATION
addappid(1983010)
-- Game: addappid(1983010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983011, 1, "3c3eccd3c0370af25ce0c721c3aeb67754cc195dc4ed32dadb9b483f4f8de225")
