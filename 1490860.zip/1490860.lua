-- Lua provided by RyzenAPI
-- Game: Til Nord

-- MAIN APPLICATION
addappid(1490860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1490861, 1, "68f223df541d84358725331bee5bf816f85a84e0926c15fd8d321ee47892d8a0")

