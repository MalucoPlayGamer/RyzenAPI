-- Lua provided by RyzenAPI
-- Game: Til Nord

-- MAIN APPLICATION
addappid(1490860)
-- Game: addappid(1490860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490861, 1, "68f223df541d84358725331bee5bf816f85a84e0926c15fd8d321ee47892d8a0")
