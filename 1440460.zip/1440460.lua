-- Lua provided by RyzenAPI
-- Game: Override 2: Super Mech League Demo

-- MAIN APPLICATION
addappid(1440460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440461, 1, "1216f36b31290d9bb2481d3a9e36a20482d71d98ec2f42f90f96c88f26e1d735")
