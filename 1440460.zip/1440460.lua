-- Lua provided by SkyAPI 
-- Game: Override 2: Super Mech League Demo
addappid(1440460)
addappid(1440461, 1, "1216f36b31290d9bb2481d3a9e36a20482d71d98ec2f42f90f96c88f26e1d735")
