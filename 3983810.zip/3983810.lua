-- Lua provided by RyzenAPI
-- Game: The Spike Cross

-- MAIN APPLICATION
addappid(3983810)

