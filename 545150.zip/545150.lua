-- Lua provided by RyzenAPI
-- Game: Beastiarium

-- MAIN APPLICATION
addappid(545150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(545151, 1, "e452a66e5f98b3d9871d1702e6df284f23d48116cb35b2aa0a334f0abfb6e122")

