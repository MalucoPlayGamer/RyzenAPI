-- Lua provided by RyzenAPI
-- Game: REVISITOR

-- MAIN APPLICATION
addappid(1475440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475441, 1, "26df75171a4d36148bb947be0e28932ff0a3f787afa3307353e13890018d69e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
