-- Lua provided by RyzenAPI
-- Game: Dress-Up With Helene: Deluxe!

-- MAIN APPLICATION
addappid(3721180)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3858470)
addappid(3911440)
addappid(3911460)
addappid(3971120)
