-- Lua provided by RyzenAPI
-- Game: Dress-Up With Helene: Deluxe!

-- MAIN APPLICATION
addappid(3721180)
