-- Lua provided by RyzenAPI
-- Game: 送外卖模拟器 Delivery Simulator

-- MAIN APPLICATION
addappid(1353730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353731, 1, "c13d3b91ae9ef8b5abf9b9a1c547802d6bf10d3f007cb8f9a5b8c8a2d6623ee5")
