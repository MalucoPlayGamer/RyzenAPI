-- Lua provided by SkyAPI 
-- Game: Silk Roads: Caravan Kings
addappid(1401840)
addappid(1401841, 1, "fcf5e976a1f7d8ce28dac308004ed5a516cee63341e7b3165185c281c010b735")
