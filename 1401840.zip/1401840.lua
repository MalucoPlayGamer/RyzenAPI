-- Lua provided by RyzenAPI
-- Game: 1401840

-- MAIN APPLICATION
addappid(1401840)
-- Game: addappid(1401840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401841, 1, "fcf5e976a1f7d8ce28dac308004ed5a516cee63341e7b3165185c281c010b735")
