-- Lua provided by RyzenAPI
-- Game: Game: Rumia in the darkness

-- MAIN APPLICATION
addappid(1060240)
-- Game: addappid(1060240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060241, 1, "a26dbbae0ab06630750e352f3821174d3257ae863db4daaec92f2a8f07c71537")
