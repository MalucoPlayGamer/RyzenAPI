-- Lua provided by RyzenAPI
-- Game: 2808570

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2808570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808572,0,"9cb2adadc8637c2632dce8be4859287fe6e868a11f81f1ade65d699cbc724e14")

