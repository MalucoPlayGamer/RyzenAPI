-- Lua provided by RyzenAPI
-- Game: Game: AppID 3231760

-- MAIN APPLICATION
addappid(3231760)
-- Game: addappid(3231760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231761, 1, "119d38faeb5e5001237a70acf521688fd11c482fced976ef2b5fd2723bb2767a")
