-- Lua provided by RyzenAPI
-- Game: 2117780

-- MAIN APPLICATION
addappid(2117780)
-- Game: addappid(2117780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117780,0,"7956aab4a09a5014a0adc0fe7c949410341b46121759b9a6ec4ebb5964f1f82c")
