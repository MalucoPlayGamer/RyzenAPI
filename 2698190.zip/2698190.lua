-- Lua provided by SkyAPI 
-- Game: Trajectory of summer flower Ⅱ
addappid(2698190)
addappid(2698191, 1, "70c0e5debc4b31465e5c77aef78dcb8e2289909d7b096b5af86a75bb78354064")
addappid(2698194, 1, "5b5ae1c57dbced01201b6cd7361144cabd0ae3e6f7c87d01a352cc42139fd731")
