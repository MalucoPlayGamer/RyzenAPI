-- 4341950's Lua and Manifest Created by Hubcap Manifest
-- The Unclosed Case
-- Created: August 11, 2026 at 23:23:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4341950) -- The Unclosed Case
-- MAIN APP DEPOTS
addappid(4341951, 1, "bffc150290e7d8f44105a2df6f4518fdc494d945df556516252da0b03923f446") -- Depot 4341951
setManifestid(4341951, "1556225052211768572", 3152337074)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)