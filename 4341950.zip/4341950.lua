-- Lua provided by RyzenAPI
-- Game: The Unclosed Case

-- MAIN APPLICATION
addappid(4341950) -- The Unclosed Case

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4341951, 1, "bffc150290e7d8f44105a2df6f4518fdc494d945df556516252da0b03923f446") -- Depot 4341951

