-- Lua provided by RyzenAPI
-- Game: Exotic

-- MAIN APPLICATION
addappid(1682530)
-- Game: addappid(1682530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682531, 1, "9fb7ba5780f2eb0513c9dad320ff76b577c85158eee2fdda41e7d2e2dd2384c4")
