-- Lua provided by RyzenAPI
-- Game: 418360

-- MAIN APPLICATION
addappid(418360)
-- Game: addappid(418360)

-- MAIN APP DEPOTS / PACKAGES
addappid(418361, 1, "9e56de0c95f4f42f36fc7a41bbe87c25882bb9b5e8bd5dd6304010460c5f4b44")
addappid(418362, 1, "ec8481210c77ac86416fdd01f5a54a0f1be12cc0f3e2fed1b3e019c330a6661e")
addappid(418363, 1, "5c82b4d31fa4596202bd2a0f68ced78754b19f1209d16f0f525e338a65c98f6e")
