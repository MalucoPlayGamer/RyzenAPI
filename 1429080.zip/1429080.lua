-- Lua provided by SkyAPI 
-- Game: Business Heroes: Street Grub
addappid(1429080)
addappid(1429081, 1, "957ec35b683f79a6ee66f2e49bd2a46461230e6b6ff0ce74e4051a56bdbfef9e")
