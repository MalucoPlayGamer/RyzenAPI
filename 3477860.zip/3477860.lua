-- Lua provided by RyzenAPI
-- Game: Game: SONIC WINGS REUNION

-- MAIN APPLICATION
addappid(3477860)
-- Game: addappid(3477860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477861, 1, "51e8f5e156208337d2880e9eeba43a1c03f15b0b93b68d967ff781bb606ae1e2")
