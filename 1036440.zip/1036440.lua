-- Lua provided by RyzenAPI
-- Game: addappid(1036440)

-- MAIN APPLICATION
addappid(1036440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036441, 1, "65ef468d329ec07660d3ac636b409867f6c1dd61decbdceaec3cf48995be0ca5")
addappid(1122890, 0, "771380e67b79b988ad36f824ba4c5fd3e4653a874a77d4d53fcb2b62371dd9c0")
