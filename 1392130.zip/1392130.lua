-- Lua provided by SkyAPI 
-- Game: Game Of Puzzles: Slavic Mythology
addappid(1392130)
addappid(1392131, 1, "f0ce2083794cdbf6f50c7c9a12882d5f455c82058034f644edbf9ff237d3308a")
