-- Lua provided by RyzenAPI
-- Game: Mortal Kombat Kollection

-- MAIN APPLICATION
addappid(205350)

-- MAIN APP DEPOTS / PACKAGES
addappid(205351, 1, "5302c674742a8d1c333ee38c665e60f69ef96f79d0f8469cda426dd4faf8742c")
