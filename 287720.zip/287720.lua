-- Lua provided by RyzenAPI
-- Game: Nostradamus: The Last Prophecy

-- MAIN APPLICATION
addappid(287720)

-- MAIN APP DEPOTS / PACKAGES
addappid(287721, 1, "4c6a7c1ef7c51ef75bf0ac05622f74aa3ba10baec77461c0c4f6031d97eefd49")
addappid(287722, 1, "e10c70e009bcdcf15f44fb6f2f5c2d47475d5acdfa58bd781452cd634323d6d2")
addappid(287723, 1, "58ed0be6bed2018217ff829cddc9daa3d3d2c9a39eaaae0835e3218a3b40691d")
addappid(287724, 1, "42c07a1d73488c6e6f134a921eb0561e918475230508c221518e2d1de1cc1890")
addappid(287725, 1, "1dcacccf1ca62f186864dc8e2e73ca7dcaa85810909838a88b201ea7371acacd")
addappid(287726, 1, "d000fe6af04b68103ba69850d232985729465fe51b0b5ac86b4df8b71d794d77")
addappid(287727, 1, "1f4eb0a17c19d9a2f6cffe0a01c697fedf7b8dc2d61f5955134e58414f8fd8dc")
addappid(287728, 1, "a54ada6012cc04bafebca8622fa0a83c0508b4c36f873523f656e49526fc8fcb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
