-- Lua provided by RyzenAPI
-- Game: Game: Farm Keeper Demo

-- MAIN APPLICATION
addappid(2472720)
-- Game: addappid(2472720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472721, 1, "000f74988464b8e75b30a98055fb9da76b45231ab4a34059ade90d0a6f3cb488")
