-- Lua provided by SkyAPI 
-- Game: Manhunt
addappid(12130)
addappid(12131, 1, "7d982179160594794fd6947ae7585f4767f8844335209649ed3189b080f9e0fd")
addappid(12132, 1, "b545c3df7ebf6d20468062d5faa869c4ec31340b523260ac5e9b931316d0ede6")
