-- Lua provided by RyzenAPI
-- Game: HentaiTeachers

-- MAIN APPLICATION
addappid(1197210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197211, 1, "9ef3730f3ff2b12c3da29cf3fd2562099cb7e482b81639870a771aafae1a8942")

