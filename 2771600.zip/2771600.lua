-- Generated with Luie @ https://lua.tools/
-- 2771600 - Maid Survivors : Little Angels
-- Generated 2026-08-29 05:26:47 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(2771600)

-- Main Depots
addappid(2771601, 1, "1e16f31c4d20a365685b4337c0d3d40269858759e12f878c4537250e22203aa8")
setManifestid(2771601, "4600265591185794811", 3101118295)

-- Missing Depots (We don't have the keys yet lol): 3642290
