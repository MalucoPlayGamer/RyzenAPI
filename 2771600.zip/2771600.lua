-- Lua provided by RyzenAPI
-- Game: Maid Survivors : Little Angels

-- MAIN APPLICATION
addappid(2771600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771601, 1, "1e16f31c4d20a365685b4337c0d3d40269858759e12f878c4537250e22203aa8")

