-- Lua provided by RyzenAPI
-- Game: addappid(450190)

-- MAIN APPLICATION
addappid(450190)

-- MAIN APP DEPOTS / PACKAGES
addappid(450191, 1, "0efe8856b648cbc5ff460933ab7a926e67a30e921f952f7116d721e02bf31797")
