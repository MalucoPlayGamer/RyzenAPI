-- Lua provided by RyzenAPI
-- Game: 2814820

-- MAIN APPLICATION
addappid(2814820)
-- Game: addappid(2814820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814821, 1, "0e9ad5720b5d643cc08c4151fe8e84fc1946f13c8424e3b17635a6f73ee19eaf")
