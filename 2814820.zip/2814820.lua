-- Lua provided by SkyAPI 
-- Game: HEART of CROWN Online Demo
addappid(2814820)
addappid(2814821, 1, "0e9ad5720b5d643cc08c4151fe8e84fc1946f13c8424e3b17635a6f73ee19eaf")
