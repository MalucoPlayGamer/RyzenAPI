-- Lua provided by RyzenAPI 
-- Game: Mystic Vale
addappid(908070)
addappid(908071, 1, "618ab1194178f93f4c24a60a52a53f5873e6a83400b2fa6a91d8dccc200f4c76")
addappid(908072, 1, "cd87296a64c66616c28eae5a63a759bd6e5121d1e02f3ec8708e9ccc1b4cf424")
addappid(908073, 1, "77f1cfbc68f306970f9de4480686cd5038cd3321506be94c31f08c164b7d85cb")
