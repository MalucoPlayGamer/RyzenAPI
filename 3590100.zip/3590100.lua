-- Lua provided by RyzenAPI
-- Game: Savara - Soundtrack

-- MAIN APPLICATION
addappid(3590100)
-- Game: addappid(3590100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3590101, 1, "90ee7acea3d6ea8585308c05db7b59975b421d7c895a2e84e98077d07c1fe8f6")
addappid(3590102, 1, "2cb1131b0b65f95d995bdd5f11154ce748c152d38fa730b982cf398ab3de74af")
