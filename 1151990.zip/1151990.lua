-- Lua provided by RyzenAPI
-- Game: Slip 'n Slime

-- MAIN APPLICATION
addappid(1151990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151992,0,"a895fc667fc01cb9c52dece3d037501398a8def25950e1e7833d5f3512106d6f")

