-- Lua provided by SkyAPI 
-- Game: Alien Removal Division
addappid(1768550)
addappid(1768551, 1, "633223788234ba70d29a63500768b0af79bb802ad466ef41a1f542b43bec9ee8")
