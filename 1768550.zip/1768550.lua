-- Lua provided by RyzenAPI
-- Game: Alien Removal Division

-- MAIN APPLICATION
addappid(1768550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768551, 1, "633223788234ba70d29a63500768b0af79bb802ad466ef41a1f542b43bec9ee8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
