-- Lua provided by RyzenAPI
-- Game: Game: Alien Removal Division

-- MAIN APPLICATION
addappid(1768550)
-- Game: addappid(1768550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768551, 1, "633223788234ba70d29a63500768b0af79bb802ad466ef41a1f542b43bec9ee8")
