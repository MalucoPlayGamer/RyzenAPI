-- Lua provided by RyzenAPI 
-- Game: AppID 3242130
addappid(3242130)
addappid(3242131, 1, "68c37734e2471161831b57a5c96da8da68a4ca3ac1ef1480951b13e4dea6ddab")
