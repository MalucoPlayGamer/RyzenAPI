-- Lua provided by RyzenAPI
-- Game: Bump Bump Bump

-- MAIN APPLICATION
addappid(812900)

-- MAIN APP DEPOTS / PACKAGES
addappid(812901,0,"5206515fe5b85761641bdbac282f7cc806fc1e17513fa398e9c26f704720f1db")

