-- Lua provided by RyzenAPI
-- Game: Esports Life Tycoon

-- MAIN APPLICATION
addappid(897410)

-- MAIN APP DEPOTS / PACKAGES
addappid(897411, 1, "91d8d8b4f038733a6224bf5f5c3f8eb17101c305480fff34a43d92584c9b5d71")
addappid(897412, 1, "0c04e0a6e4301f1a4e93d112a57fa92788a86100919acd4c6e01f4d2f3d40396")
addappid(897413, 1, "256ae67046f1fe29c99152331bfab0a0a432e7d7f98dae8b62ead8dcedd84bb2")

