-- Lua provided by RyzenAPI
-- Game: 白噪生存指南 Demo

-- MAIN APPLICATION
addappid(3259930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3259931, 1, "f4320f224ec4f9f87a80d8f6ffb54bbe67fae0f12d944ac63f77186fd4cbf263")
