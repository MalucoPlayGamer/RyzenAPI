-- Lua provided by RyzenAPI
-- Game: 1406020

-- MAIN APPLICATION
addappid(1406020)
-- Game: addappid(1406020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406021, 1, "accbd61d0a0da09b367198221b934f36afd8a8d86b303f5b31ad71590a94f105")
