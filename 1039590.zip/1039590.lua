-- Lua provided by RyzenAPI
-- Game: AppID 1039590

-- MAIN APPLICATION
addappid(1039590)
-- Game: addappid(1039590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039591, 1, "0e21d676b69da64e5bbc43dbabfb9a4c0b5d0c0b40c20552013a0a921838abe3")
