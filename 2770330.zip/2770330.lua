-- Lua provided by RyzenAPI
-- Game: Chaos Front

-- MAIN APPLICATION
addappid(2770330) -- Chaos Front

-- MAIN APP DEPOTS / PACKAGES
addappid(2770331, 1, "7cf881fc5becc6e57416f2f5e954c7756b6a2e70dcf95a04988c27f23504709d") -- Depot 2770331

