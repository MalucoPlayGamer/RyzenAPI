-- Lua provided by SkyAPI 
-- Game: MY HERO ONE'S JUSTICE
addappid(748360)
addappid(748361, 1, "43f8f66531c3a765f9735c3547719bb16a16dd4cc43b6a66e5e156135915fb6d")
