-- 748360's Lua and Manifest Created by Hubcap Manifest
-- MY HERO ONE'S JUSTICE
-- Created: September 30, 2025 at 02:29:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(748360) -- MY HERO ONE'S JUSTICE
-- MAIN APP DEPOTS
addappid(748361, 1, "43f8f66531c3a765f9735c3547719bb16a16dd4cc43b6a66e5e156135915fb6d") -- GTGS Content
setManifestid(748361, "8988697188602185037", 11988825165)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(900070) -- MY HERO ONES JUSTICE Mission O.F.A Deku Shoot Style
addappid(921540) -- MY HERO ONES JUSTICE Playable Character Pro Hero Endeavor
addappid(921541) -- MY HERO ONES JUSTICE Mission Above and Beyond Endeavor
addappid(921542) -- MY HERO ONES JUSTICE Playable Character Inasa Yoarashi
addappid(921543) -- MY HERO ONES JUSTICE Additional Mission Gale
addappid(922420) -- MY HERO ONES JUSTICE Playable Character Deku (Shoot Style)