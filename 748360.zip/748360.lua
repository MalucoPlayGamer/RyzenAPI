-- Lua provided by RyzenAPI
-- Game: MY HERO ONE'S JUSTICE

-- MAIN APPLICATION
addappid(748360) -- MY HERO ONE'S JUSTICE
addappid(900070) -- MY HERO ONES JUSTICE Mission O.F.A Deku Shoot Style
addappid(921540) -- MY HERO ONES JUSTICE Playable Character Pro Hero Endeavor
addappid(921541) -- MY HERO ONES JUSTICE Mission Above and Beyond Endeavor
addappid(921542) -- MY HERO ONES JUSTICE Playable Character Inasa Yoarashi
addappid(921543) -- MY HERO ONES JUSTICE Additional Mission Gale
addappid(922420) -- MY HERO ONES JUSTICE Playable Character Deku (Shoot Style)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(748361, 1, "43f8f66531c3a765f9735c3547719bb16a16dd4cc43b6a66e5e156135915fb6d") -- GTGS Content

