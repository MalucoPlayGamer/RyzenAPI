-- Lua provided by RyzenAPI
-- Game: Warbox

-- MAIN APPLICATION
addappid(1550710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550711, 1, "de980e14a66fd5dc0f045e9c8c0714d30f6cb5d3781a1ce633bdf5454d8be7dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
