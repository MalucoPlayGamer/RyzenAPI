-- Lua provided by RyzenAPI
-- Game: Bob The Cube

-- MAIN APPLICATION
addappid(854060)

-- MAIN APP DEPOTS / PACKAGES
addappid(854061, 1, "2ae0bb0ee2b24a18079cca237ac211661c6bd52db62a68a3c108c1311544197e")

