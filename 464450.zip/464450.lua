-- Lua provided by RyzenAPI
-- Game: Game: AppID 464450

-- MAIN APPLICATION
addappid(464450)
-- Game: addappid(464450)

-- MAIN APP DEPOTS / PACKAGES
addappid(464451, 1, "4637e582d79115eb0bb409fe956a83b8d8fefec7a7a92770498f777183444d70")
