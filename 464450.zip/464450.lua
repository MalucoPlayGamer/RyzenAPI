-- Lua provided by RyzenAPI
-- Game: DoDonPachi Resurrection

-- MAIN APPLICATION
addappid(464450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(464451, 1, "4637e582d79115eb0bb409fe956a83b8d8fefec7a7a92770498f777183444d70")
