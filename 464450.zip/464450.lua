-- Lua provided by RyzenAPI 
-- Game: AppID 464450
addappid(464450)
addappid(464451, 1, "4637e582d79115eb0bb409fe956a83b8d8fefec7a7a92770498f777183444d70")
