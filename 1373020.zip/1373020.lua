-- Lua provided by RyzenAPI
-- Game: addappid(1373020)

-- MAIN APPLICATION
addappid(1373020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373021, 1, "cf7c268d907309ae8cfa5d97adb8d869011d638b4a24cffd92b3115f19dcfa5b")
