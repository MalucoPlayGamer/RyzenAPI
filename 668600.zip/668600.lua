-- Lua provided by RyzenAPI
-- Game: AppID 668600

-- MAIN APPLICATION
addappid(668600)

-- MAIN APP DEPOTS / PACKAGES
addappid(668601, 1, "542dce889e3bbf633816609e3158753acc55db2581fb8cecd3ddc6ad5a2e0633")

