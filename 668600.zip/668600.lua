-- Lua provided by RyzenAPI
-- Game: AppID 668600

-- MAIN APPLICATION
addappid(668600)

-- MAIN APP DEPOTS / PACKAGES
addappid(668601, 1, "542dce889e3bbf633816609e3158753acc55db2581fb8cecd3ddc6ad5a2e0633")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
