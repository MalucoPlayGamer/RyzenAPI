-- Lua provided by RyzenAPI
-- Game: addappid(1410370)

-- MAIN APPLICATION
addappid(1410370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410371, 1, "df484db0a09729e4100af1cfa6cb59da327977dcd7d6b7e53545a920a94fe290")
addappid(1410372, 1, "caea3e6357db3d834e9ff6dad3a6c2153df40707d88ac0403398692f697d2c9e")
