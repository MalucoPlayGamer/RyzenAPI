-- Lua provided by RyzenAPI
-- Game: Marle: The Labyrinth of the Black Sea

-- MAIN APPLICATION
addappid(985400)

-- MAIN APP DEPOTS / PACKAGES
addappid(985401, 1, "747ff4cb67d5ce8f3aa837f3cd3f95a596b5408bec00788161ee34c013544ef5")
addappid(985402, 1, "fb962db8415e4864fb131bc1368efff0f4986d2264cbcc0b76aa3bffc7288768")
