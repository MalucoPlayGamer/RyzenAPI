-- Lua provided by RyzenAPI
-- Game: Ylands

-- MAIN APPLICATION
addappid(298610)
-- Game: addappid(298610)

-- MAIN APP DEPOTS / PACKAGES
addappid(298611, 1, "6bc200dd240d5740da26c4c6229c364c925d970444f2648458251f0c56b013d2")
