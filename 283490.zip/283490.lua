-- Lua provided by RyzenAPI
-- Game: AppID 283490

-- MAIN APPLICATION
addappid(283490)
-- Game: addappid(283490)

-- MAIN APP DEPOTS / PACKAGES
addappid(283491, 1, "54f276ceb8090988e796c419073e79297014afc937dd06cfdee4d8dfc290b1dd")
