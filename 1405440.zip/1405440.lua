-- Lua provided by RyzenAPI
-- Game: 1405440

-- MAIN APPLICATION
addappid(1405440)
-- Game: addappid(1405440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405441, 1, "7d2637ef5b0a626181fefbfc4503022e639083e0ec9e0de132784ca514f41b9c")
addappid(1405443, 1, "84dbb2de9ad8ed3a274e68ac671cd9e251b1ad18c7cbd16cb1dfa85440c9c2ae")
