-- Lua provided by RyzenAPI 
-- Game: DOLPHIN HUSTLE
addappid(1964750)
addappid(1964751, 1, "36203c879d9d5548440f9a4b7b561492eddaa400365b6856132d7096dc113ade")
