-- Lua provided by RyzenAPI
-- Game: Filmmaker Tycoon

-- MAIN APPLICATION
addappid(778010)

-- MAIN APP DEPOTS / PACKAGES
addappid(778011,0,"7b759f344af5eb40a09e628ed8acc06660fe73d198d4cb423cb27490f63ad8db")

