-- Lua provided by RyzenAPI
-- Game: Steel Thunder

-- MAIN APPLICATION
addappid(2372300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372301, 1, "d09e9425367805eb88816fdc1b1c2e4d2d5987520dca34b27d5763a73d34b63f")

