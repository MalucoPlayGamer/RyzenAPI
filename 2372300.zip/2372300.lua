-- Lua provided by SkyAPI 
-- Game: Steel Thunder
addappid(2372300)
addappid(2372301, 1, "d09e9425367805eb88816fdc1b1c2e4d2d5987520dca34b27d5763a73d34b63f")
