-- Lua provided by RyzenAPI
-- Game: At The Downstairs

-- MAIN APPLICATION
addappid(1360150)
-- Game: addappid(1360150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360151, 1, "1a06399638879316188e3fc397fcb6ed5d44b28419b5caf36cb0531d274e1889")
