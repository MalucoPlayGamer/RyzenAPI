-- Lua provided by RyzenAPI
-- Game: The Secret of Gillwood

-- MAIN APPLICATION
addappid(992870)

-- MAIN APP DEPOTS / PACKAGES
addappid(992871, 1, "3d1d60af5b91df9dd643c3209ced44fa4995db98fed6316db6d83bda1e476d6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
