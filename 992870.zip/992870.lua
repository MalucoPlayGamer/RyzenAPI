-- Lua provided by RyzenAPI
-- Game: The Secret of Gillwood

-- MAIN APPLICATION
addappid(992870)

-- MAIN APP DEPOTS / PACKAGES
addappid(992871, 1, "3d1d60af5b91df9dd643c3209ced44fa4995db98fed6316db6d83bda1e476d6e")
