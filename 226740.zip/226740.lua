-- Lua provided by RyzenAPI
-- Game: addappid(226740)

-- MAIN APPLICATION
addappid(226740)

-- MAIN APP DEPOTS / PACKAGES
addappid(226741, 1, "18a5502347b334ab2aaf72a5a44fec32b50d013134d8f6d8e8f88de7d76a78cb")
addappid(226742, 1, "a3ba0bd8d4f4866079670dc5079d4e7230a746bbef4d7f586c08e6c18b62c946")
addappid(226743, 1, "74b4edcae8f601d99c8834610f3970f007b12cb36b3abbc7c6f4e4d67e8c0e63")
