-- Lua provided by RyzenAPI
-- Game: 2383700

-- MAIN APPLICATION
addappid(2383700)
-- Game: addappid(2383700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383701, 1, "0d85296ed14bb3c0f747bd81672e32cca85a4f00191c6801e41bad2d1cb7aee5")
