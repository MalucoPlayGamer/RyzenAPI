-- Lua provided by RyzenAPI
-- Game: 290080

-- MAIN APPLICATION
addappid(228982)
addappid(228983)
addappid(228985)
addappid(228986)
addappid(228990)
addappid(290080)

-- MAIN APP DEPOTS / PACKAGES
addappid(290082,0,"7fe86242e513931553ece87c3bdd005c0e25accd5f7621bb3d5496508b1df935")
addappid(290083,0,"1fd913aac8abe6d4058e00aa5a56f1665c01a550fc9c4acb8698127be6dc17c0")
addappid(290084,0,"ff4b1199cdee808b714f21f34b2645c68419c4069e95f979453af6ac163db0c4")
