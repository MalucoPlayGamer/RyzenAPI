-- Lua provided by RyzenAPI
-- Game: Frontline Tactics

-- MAIN APPLICATION
addappid(218310)

-- MAIN APP DEPOTS / PACKAGES
addappid(218311, 1, "98f183badb4c4c037d2c9d3e60c48b593b672f002b2cf45ccac111d58bccc665")
addappid(218312, 1, "865b87482602357bb28444abc0a57da4e241d4ba771990b71446b9b851013447")

