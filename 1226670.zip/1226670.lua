-- Lua provided by RyzenAPI 
-- Game: Rosewater
addappid(1226670)
addappid(1226671, 1, "7bf9199c2c677183c5bfd362e663dcc168028f2f9ab5107b3c5562ea66a1f1a2")
addappid(1226672, 1, "82a14a39edc7cdfdc685062672e3e59eec022e24cbd1ed9f6b935c6cec867108")
addappid(1226673, 1, "ad56e33842458728a711b3f29abc4a6303708c165d227c50151b8b2f80e5af0e")
