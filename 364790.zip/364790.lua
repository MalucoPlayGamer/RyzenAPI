-- Lua provided by RyzenAPI
-- Game: Voyage to Farland

-- MAIN APPLICATION
addappid(364790)

-- MAIN APP DEPOTS / PACKAGES
addappid(364791, 1, "d0cf626ad7915ee5a7a82d36c6269d9263d87e96f1acc4312188cbfb0479f572")
addappid(364792, 1, "dd6d92a56b8973e51059086f8dead62da8612ab64557891e59f2fcaad37ff5e5")
addappid(364793, 1, "83e7c94bf8dbd36e944ea135a9f6443bd323c062a912e478535488dc186ab5ad")
