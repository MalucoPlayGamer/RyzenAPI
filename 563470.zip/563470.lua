-- Lua provided by RyzenAPI
-- Game: AppID 563470

-- MAIN APPLICATION
addappid(563470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(563471, 1, "0a3d56a617e85ae293e2983ede57b361fd1ab001112cd4e57725e12edf9e30aa")

