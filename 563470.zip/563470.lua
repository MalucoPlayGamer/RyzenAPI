-- Lua provided by RyzenAPI 
-- Game: AppID 563470
addappid(563470)
addappid(563471, 1, "0a3d56a617e85ae293e2983ede57b361fd1ab001112cd4e57725e12edf9e30aa")
