-- Lua provided by RyzenAPI
-- Game: Sit on bottle

-- MAIN APPLICATION
addappid(776820)

-- MAIN APP DEPOTS / PACKAGES
addappid(776821, 1, "76c141c739ce6881817228483ad86ad991517ae6c84ad4e280749d336d06bd5b")

