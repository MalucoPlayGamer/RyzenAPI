-- Lua provided by RyzenAPI
-- Game: Farming Simulator 17 - KUHN Equipment Pack

-- MAIN APPLICATION
addappid(570220)

-- MAIN APP DEPOTS / PACKAGES
addappid(570220,0,"7ec03110892ae1557b1ffa299f66b84e4efb93628c933ce564da0562b34e961f")
