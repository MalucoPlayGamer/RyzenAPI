-- Lua provided by SkyAPI 
-- Game: Pierhead Arcade 2
addappid(572620)
addappid(572621, 1, "439aec3048ce5232de97dc362c01c1a7d71775cafaf6db69f578151b6c19fb03")
