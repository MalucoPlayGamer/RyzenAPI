-- Lua provided by RyzenAPI
-- Game: Game: Pierhead Arcade 2

-- MAIN APPLICATION
addappid(572620)
-- Game: addappid(572620)

-- MAIN APP DEPOTS / PACKAGES
addappid(572621, 1, "439aec3048ce5232de97dc362c01c1a7d71775cafaf6db69f578151b6c19fb03")
