-- Lua provided by RyzenAPI
-- Game: 3450250

-- MAIN APPLICATION
addappid(228983)
addappid(228985)
addappid(228990)
addappid(3450250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345801,0,"3b34973273fa5e5251f984266680c63e2a59a24ec3c5360fdbb308a6def9631d")
addappid(1345802,0,"d1d5dfa17fff2a9c5a5719c0ffb80b5fe1e5ad34ec904cc060d71a7cbb351e8a")
addappid(1345803,0,"21d8d7a9b8b9023118e8e43b4d46c5fa083cfd5a1ca6237b54b86f97f49f2a90")
addappid(1466129,0,"c5efd80adb761a23987922e5e1d6eaf3b249dba405e3cc513570fcf6aaf575ee")
