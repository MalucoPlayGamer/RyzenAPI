-- Lua provided by RyzenAPI
-- Game: addappid(1424690)

-- MAIN APPLICATION
addappid(1424690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424692,0,"93681bdb10b895a16a11ae44d4089261dca79c5474430036bdbfd9b1a7bd9149")
