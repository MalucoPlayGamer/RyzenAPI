-- Lua provided by RyzenAPI
-- Game: Lost In Ferry VR

-- MAIN APPLICATION
addappid(1226490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226491, 1, "197f223348f852b36768d23dba42a21c6afdf792409f216547307bd617dfa1cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
