-- Lua provided by RyzenAPI
-- Game: Lost In Ferry VR

-- MAIN APPLICATION
addappid(1226490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226491, 1, "197f223348f852b36768d23dba42a21c6afdf792409f216547307bd617dfa1cd")

