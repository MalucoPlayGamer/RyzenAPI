-- Lua provided by RyzenAPI
-- Game: Parcel Master

-- MAIN APPLICATION
addappid(3192960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192961, 1, "c05cce29eb7706a593b11afee8e674aeaf65c2ec8cd51d68ed273f37ed6b97f2")

