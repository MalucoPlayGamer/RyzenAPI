-- Lua provided by RyzenAPI
-- Game: Grave Keeper

-- MAIN APPLICATION
addappid(979810)
-- Game: addappid(979810)

-- MAIN APP DEPOTS / PACKAGES
addappid(979811, 1, "3afdd8d4c0eed60e38c2585c920860023ecdcc1cea3733e1c6bbf94beb4a1bed")
