-- Lua provided by RyzenAPI
-- Game: Grave Keeper

-- MAIN APPLICATION
addappid(979810)

-- MAIN APP DEPOTS / PACKAGES
addappid(979811, 1, "3afdd8d4c0eed60e38c2585c920860023ecdcc1cea3733e1c6bbf94beb4a1bed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
