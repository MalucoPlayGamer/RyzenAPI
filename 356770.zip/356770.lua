-- Lua provided by RyzenAPI
-- Game: Astronaut Simulator

-- MAIN APPLICATION
addappid(356770)

-- MAIN APP DEPOTS / PACKAGES
addappid(356771, 1, "207e0dd58f33b2ce309d9b0eb91e102430b81e0771660997e6188f9185137c5a")
