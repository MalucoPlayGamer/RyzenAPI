-- Lua provided by RyzenAPI 
-- Game: AppID 356770
addappid(356770)
addappid(356771, 1, "207e0dd58f33b2ce309d9b0eb91e102430b81e0771660997e6188f9185137c5a")
