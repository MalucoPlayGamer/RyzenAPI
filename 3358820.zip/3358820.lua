-- Lua provided by RyzenAPI
-- Game: Game: SnaPaul

-- MAIN APPLICATION
addappid(3358820)
-- Game: addappid(3358820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358821, 1, "ee39dd3b1dda63177bc5b53f1ebadb99bcb7fac35cf0e4c515871fa0dab4ac63")
