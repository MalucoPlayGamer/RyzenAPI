-- Lua provided by RyzenAPI
-- Game: 1486670

-- MAIN APPLICATION
addappid(1486670)
-- Game: addappid(1486670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486671, 1, "aaeb9a30065e8130e84b4621ee34243caad5fca22657c441aeecaea34c913cff")
