-- Lua provided by RyzenAPI 
-- Game: Frozen Cortex
addappid(237350)
addappid(237351, 1, "bbac93807ae0b505b22751556b201b9cdc83e2187d0d2c2e50a9e814a628c6dd")
addappid(237352, 1, "c4ae526b3837a3254a2da15ce8d6cfbc8e48ea60c9b4b8639b824753a5e13052")
addappid(237353, 1, "dcdf4b9bac4ecf90efdea9c08f0db7187c47593a8dbd0356e4a93ada4df1b3ed")
addappid(283811, 0, "cb8c389012e80519824da134d3faf7fa65ff151c5f826b6e553a5e16d6f312b0")
addappid(283812, 0, "96a7be4471d05a8dc93fa412bf8b76bbfd5d2caa85339e992fa9f9d5c9a677c4")
