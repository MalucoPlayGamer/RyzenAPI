-- Lua provided by RyzenAPI
-- Game: Game: IDLE RAID

-- MAIN APPLICATION
addappid(1620160)
-- Game: addappid(1620160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620161, 1, "cf3a36c8331e140426a2bb56405124fc73b02f1a8c422c790aad35ffa2c8679b")
