-- Lua provided by SkyAPI 
-- Game: IDLE RAID
addappid(1620160)
addappid(1620161, 1, "cf3a36c8331e140426a2bb56405124fc73b02f1a8c422c790aad35ffa2c8679b")
