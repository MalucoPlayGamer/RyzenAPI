-- Lua provided by SkyAPI 
-- Game: Best Plumber
addappid(1166580)
addappid(1166581, 1, "c893fa4bc5e5b9b03cdd3d62fe0b097435626f95fb8f463d1be5b6f328462db2")
