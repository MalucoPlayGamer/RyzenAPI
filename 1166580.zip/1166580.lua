-- Lua provided by RyzenAPI
-- Game: Best Plumber

-- MAIN APPLICATION
addappid(1166580)
-- Game: addappid(1166580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166581, 1, "c893fa4bc5e5b9b03cdd3d62fe0b097435626f95fb8f463d1be5b6f328462db2")
