-- Lua provided by RyzenAPI
-- Game: addappid(1194680)

-- MAIN APPLICATION
addappid(1194680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194681, 1, "a0b97ac980cea23e35bb2e9d90bf1a0a3901070bd71929b3fc87b251e8555523")
