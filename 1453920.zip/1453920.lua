-- Lua provided by RyzenAPI
-- Game: Heroes of Three Kingdoms

-- MAIN APPLICATION
addappid(1453920)
addappid(1531280)
addappid(1534920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1453921, 1, "77e691087e5a7418e42cf7c61817add0788b765e338ac18e8e96cc729b30d4b6")

