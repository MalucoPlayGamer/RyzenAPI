-- Lua provided by RyzenAPI
-- Game: Game: Heroes of Three Kingdoms

-- MAIN APPLICATION
addappid(1453920)
addappid(1531280)
addappid(1534920)
-- Game: addappid(1453920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453921, 1, "77e691087e5a7418e42cf7c61817add0788b765e338ac18e8e96cc729b30d4b6")
