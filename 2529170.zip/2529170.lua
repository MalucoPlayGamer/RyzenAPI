-- Lua provided by RyzenAPI
-- Game: Storage Hustle

-- MAIN APPLICATION
addappid(2529170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529171, 1, "498290ee4144fdc16eadcca03390f0654d6de66b9ede870cffeaa6e507978d85")

