-- 1055210's Lua and Manifest Created by Hubcap Manifest
-- Retrograde Arena
-- Created: March 16, 2026 at 14:36:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(1055210, 1, "a1430dcbb4a92454093c5ecad02839855e7871e9856882884687dbea4270c0ca") -- Retrograde Arena
-- MAIN APP DEPOTS
addappid(1055211, 1, "b36ee758dce7e863b4159f83c588cf3472e0581df664fec1e750298062f23229") -- Retrograde Arena Content
setManifestid(1055211, "3085219055364987131", 385179823)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1333400) -- Retrograde Arena - Arms Race Pack
addappid(1333740) -- Retrograde Arena - Supporter Pack
addappid(1333741) -- Retrograde Arena - Deathmatch Pack