-- Lua provided by RyzenAPI
-- Game: Retrograde Arena

-- MAIN APPLICATION
addappid(1333400) -- Retrograde Arena - Arms Race Pack
addappid(1333740) -- Retrograde Arena - Supporter Pack
addappid(1333741) -- Retrograde Arena - Deathmatch Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1055210, 1, "a1430dcbb4a92454093c5ecad02839855e7871e9856882884687dbea4270c0ca") -- Retrograde Arena
addappid(1055211, 1, "b36ee758dce7e863b4159f83c588cf3472e0581df664fec1e750298062f23229") -- Retrograde Arena Content

