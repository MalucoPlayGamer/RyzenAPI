-- Lua provided by RyzenAPI
-- Game: Retrograde Arena

-- MAIN APPLICATION
addappid(1055210)
-- Game: addappid(1055210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055211, 1, "b36ee758dce7e863b4159f83c588cf3472e0581df664fec1e750298062f23229")
