-- Lua provided by RyzenAPI 
-- Game: Rock Zombie
addappid(328640)
addappid(328641, 1, "da80ee8f48f6a86f545b41180382890667f8d6671d858da2d2eaa917de6b0c85")
