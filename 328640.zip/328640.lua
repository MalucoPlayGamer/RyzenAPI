-- Lua provided by RyzenAPI
-- Game: addappid(328640)

-- MAIN APPLICATION
addappid(328640)

-- MAIN APP DEPOTS / PACKAGES
addappid(328641, 1, "da80ee8f48f6a86f545b41180382890667f8d6671d858da2d2eaa917de6b0c85")
