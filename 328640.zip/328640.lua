-- Lua provided by RyzenAPI
-- Game: Rock Zombie

-- MAIN APPLICATION
addappid(328640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(328641, 1, "da80ee8f48f6a86f545b41180382890667f8d6671d858da2d2eaa917de6b0c85")

