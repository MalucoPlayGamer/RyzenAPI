-- Lua provided by RyzenAPI
-- Game: A frog in a well

-- MAIN APPLICATION
addappid(2208520)
addappid(2208521)
addappid(2208523)
addappid(2208524)
addappid(2208525)
addappid(2208526)
addappid(2208527)
addappid(2208528)
addappid(2208529)
-- Game: addappid(2208520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208522,0,"300b9ac02fa3b6528cb4a24b1ad7d6fdc3df7d0e86deb1ac947e55a2d78ef2e4")
