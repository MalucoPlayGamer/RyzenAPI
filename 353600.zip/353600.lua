-- Lua provided by SkyAPI 
-- Game: Spellbind
addappid(353600)
addappid(353601, 1, "dae0a401710cb8dfe48535b4cbb790a1a466ffa201ea7b19d1ed453e599744fc")
