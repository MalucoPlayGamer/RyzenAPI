-- Lua provided by RyzenAPI
-- Game: 353600

-- MAIN APPLICATION
addappid(353600)
-- Game: addappid(353600)

-- MAIN APP DEPOTS / PACKAGES
addappid(353601, 1, "dae0a401710cb8dfe48535b4cbb790a1a466ffa201ea7b19d1ed453e599744fc")
