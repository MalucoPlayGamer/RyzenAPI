-- Lua provided by RyzenAPI
-- Game: Crashday Redline Edition

-- MAIN APPLICATION
addappid(508980)
-- Game: addappid(508980)

-- MAIN APP DEPOTS / PACKAGES
addappid(508981, 1, "35f3e692ec8a8e51a54914195618118c13d797c5d38dfc7af6605af533a47f14")
