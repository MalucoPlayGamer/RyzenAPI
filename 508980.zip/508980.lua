-- Lua provided by RyzenAPI
-- Game: Crashday Redline Edition

-- MAIN APPLICATION
addappid(508980)

-- MAIN APP DEPOTS / PACKAGES
addappid(508981, 1, "35f3e692ec8a8e51a54914195618118c13d797c5d38dfc7af6605af533a47f14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
