-- Lua provided by RyzenAPI
-- Game: AppID 1266640

-- MAIN APPLICATION
addappid(1266640)
-- Game: addappid(1266640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266641, 1, "cea5689df24b938237e176b0cbd08a83ece52696f7ac83811156012add66051f")
addappid(1266642, 1, "cdf2bdbb8e91280a3da5b7b179831a843e74ce44f952d17bfab749b8c8b1919e")
