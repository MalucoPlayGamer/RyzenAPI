-- Lua provided by RyzenAPI
-- Game: Silver Island

-- MAIN APPLICATION
addappid(613610)

-- MAIN APP DEPOTS / PACKAGES
addappid(613611,0,"f0ce327ec83e5a1c0cf6fbbb5b0a172b98ea04de5e9559c2cb3e3228b569b935")

