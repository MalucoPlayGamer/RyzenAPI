-- Lua provided by RyzenAPI
-- Game: addappid(3170640)

-- MAIN APPLICATION
addappid(3170640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170641, 1, "48f6b3dde3140cdffdec8ba3c651d6cedd87f88f4ab010eb3f979d2e07c5812b")
