-- Lua provided by RyzenAPI
-- Game: Game: 18 Wheels of Steel: Extreme Trucker

-- MAIN APPLICATION
addappid(33730)
-- Game: addappid(33730)

-- MAIN APP DEPOTS / PACKAGES
addappid(33731, 1, "5bd30b24ce0019191f41dfdb29cccbe837998dde7cb4b93dcd37a65849a7a2d3")
addappid(33732, 1, "b777fae5bbc0248e2b17398c34d097e1f3e5371aeffdf0529dd01b0613389958")
addappid(33733, 1, "daa6a6766c932cb00371d036fe21e85e3b9e9125f08ac1a8abd6be707edf6ab0")
addappid(33735, 1, "c68add91692b9a3cd4e1a50c21aade8c4d5f61b748eec6831d1f48efb008df4e")
addappid(33736, 1, "7c6fb741f02d39aab6bcdf68f29676345f1deba77075b525134d665282b11add")
addappid(33737, 1, "5d72510e8d767994dcee2f3eafa4fbb4cec3c7c465757ac986e5b9288b39b488")
