-- Lua provided by RyzenAPI
-- Game: Created: August 01, 2026 at 00:34:39 EDT

-- MAIN APPLICATION
addappid(3867250) -- 通梦板

-- MAIN APP DEPOTS / PACKAGES
addappid(3867251, 1, "317a5cf4ab269ce5acc70e1e2804f33becb109609d5d79030421e1a8563fa817") -- Depot 3867251
addappid(3867252, 1, "a35d02d37bd80edb62dd4e5576050764d0b3da489f8abfa70a2dbbe1cd238edf") -- Depot 3867252
addappid(3867253, 1, "e65164c14d08957dfa9dcc4538801d40c6acd11b15fdf9cd0e9b7aab461a049f") -- Depot 3867253

