-- Lua provided by RyzenAPI
-- Game: 235640

-- MAIN APPLICATION
addappid(235640)
-- Game: addappid(235640)

-- MAIN APP DEPOTS / PACKAGES
addappid(210771,0,"015fbe6e5008f3ed4f34e713d72f2c76aa577848a66f3a2dc89726e3da731e2f")
