-- Lua provided by RyzenAPI
-- Game: Road Doom

-- MAIN APPLICATION
addappid(792860)

-- MAIN APP DEPOTS / PACKAGES
addappid(792861, 1, "1e50969a75bafff2aecca19f5e95104b923b139a42824ca2f27ba43d94b72acc")
