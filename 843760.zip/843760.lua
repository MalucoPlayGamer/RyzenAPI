-- Lua provided by RyzenAPI
-- Game: Kemonomichi-White Moment-

-- MAIN APPLICATION
addappid(843760)
-- Game: addappid(843760)

-- MAIN APP DEPOTS / PACKAGES
addappid(843761, 1, "44568877b1030ff0db419a192f63f361b04cdf229759ef607294245298d34c6c")
