-- Lua provided by RyzenAPI
-- Game: Tornado!

-- MAIN APPLICATION
addappid(1024980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024981, 1, "ce2b3402b38172480e8c009381be0760fa8fcdc06d50339423bea909d19db26e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
