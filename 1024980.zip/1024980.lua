-- Lua provided by RyzenAPI 
-- Game: Tornado!
addappid(1024980)
addappid(1024981, 1, "ce2b3402b38172480e8c009381be0760fa8fcdc06d50339423bea909d19db26e")
