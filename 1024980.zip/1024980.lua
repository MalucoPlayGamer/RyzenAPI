-- Lua provided by RyzenAPI
-- Game: Tornado!

-- MAIN APPLICATION
addappid(1024980)
-- Game: addappid(1024980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024981, 1, "ce2b3402b38172480e8c009381be0760fa8fcdc06d50339423bea909d19db26e")
