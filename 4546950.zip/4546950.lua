-- 4546950's Lua and Manifest Created by Hubcap Manifest
-- SupercarKickers
-- Created: August 20, 2026 at 00:01:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4546950) -- SupercarKickers
-- MAIN APP DEPOTS
addappid(4546951, 1, "90a3f77b2c0e18a292636924001cc5753ef87c87ffac37626bdedf8427abd306") -- Depot 4546951
setManifestid(4546951, "3783941292472676017", 1064838454)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)