-- Lua provided by RyzenAPI
-- Game: Game: Caravan

-- MAIN APPLICATION
addappid(352890)
-- Game: addappid(352890)

-- MAIN APP DEPOTS / PACKAGES
addappid(352891, 1, "79ab5a5007e17da99ab614fffb78fc6c7036f51249bcaa5b9238c1732c852eef")
addappid(352892, 1, "3a132ae3443816282e35a80bf8a1b319f638f038ec07abfcfebf86511561902b")
addappid(352893, 1, "bfaeb82edbca23ecc5c03a6fdd19e5774c43b79c0b1a63295a8970a0f365585b")
