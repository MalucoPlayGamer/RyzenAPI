-- Lua provided by RyzenAPI
-- Game: 1714850

-- MAIN APPLICATION
addappid(1714850)
-- Game: addappid(1714850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714851, 1, "124e0cdd0374096839513ad6cd58b16d74117a335f501cfd9e253f3dac8eadc1")
