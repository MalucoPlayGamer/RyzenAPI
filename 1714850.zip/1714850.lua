-- Lua provided by RyzenAPI
-- Game: Twilight Wars: Declassified

-- MAIN APPLICATION
addappid(1714850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714851, 1, "124e0cdd0374096839513ad6cd58b16d74117a335f501cfd9e253f3dac8eadc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
