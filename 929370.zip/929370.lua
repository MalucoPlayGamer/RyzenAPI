-- Lua provided by RyzenAPI
-- Game: Game: AppID 929370

-- MAIN APPLICATION
addappid(929370)
-- Game: addappid(929370)

-- MAIN APP DEPOTS / PACKAGES
addappid(929371, 1, "7a1611168ca0cc367a7718bdc64302fe27210f3c437737de7b5cb22061007114")
