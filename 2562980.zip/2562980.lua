-- Lua provided by RyzenAPI
-- Game: Kwark

-- MAIN APPLICATION
addappid(2562980)
-- Game: addappid(2562980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562983,0,"69223451615d684e5091cc0c571e29a44331b09cdb07c175fb5a6256e6917c33")
