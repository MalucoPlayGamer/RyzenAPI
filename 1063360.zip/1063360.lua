-- Lua provided by RyzenAPI
-- Game: 1063360

-- MAIN APPLICATION
addappid(1063360)
-- Game: addappid(1063360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063361, 1, "9a4b9dee9720008aeb787541a544716eb7f35c6abb5d35f29324d16e8c00dc8a")
