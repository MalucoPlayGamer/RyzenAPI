-- Lua provided by RyzenAPI
-- Game: Game: Rainbow Run

-- MAIN APPLICATION
addappid(1104510)
addappid(1222780)
-- Game: addappid(1104510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104511, 1, "ab5690ccd7c8ab8d4875f30a249b8fe47d5090e76fe18d2217fd1d0ccf767947")
