-- Lua provided by RyzenAPI
-- Game: Rainbow Run

-- MAIN APPLICATION
addappid(1104510)
addappid(1222780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104511, 1, "ab5690ccd7c8ab8d4875f30a249b8fe47d5090e76fe18d2217fd1d0ccf767947")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
