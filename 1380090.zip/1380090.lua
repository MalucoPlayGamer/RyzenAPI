-- Lua provided by RyzenAPI
-- Game: 1380090

-- MAIN APPLICATION
addappid(1380090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380090,0,"fa43c66b8ea42354e5ba2ba88e18b1a73f20822bdcdd32ce3884abb70fd0ac03")
