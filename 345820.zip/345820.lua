-- Lua provided by RyzenAPI
-- Game: Game: Shantae and the Pirate's Curse

-- MAIN APPLICATION
addappid(345820)
-- Game: addappid(345820)

-- MAIN APP DEPOTS / PACKAGES
addappid(345821, 1, "4dcea77b08e111e2805676ba6797b296bee452ce2d8c5f67f41e7a22448506ed")
