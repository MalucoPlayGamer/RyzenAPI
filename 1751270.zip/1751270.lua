-- Lua provided by RyzenAPI
-- Game: addappid(1751270)

-- MAIN APPLICATION
addappid(1751270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751271, 1, "2b913aa70119cb6e5ff7ce049dc52cf0a576b9efb2287be8c90dd5940ce29cab")
