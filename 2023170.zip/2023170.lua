-- Lua provided by RyzenAPI 
-- Game: Vimana
addappid(2023170)
addappid(2023171, 1, "3746897e5c2621d3395119a1c1d02af6d6ab74621089ce71a70726dca89dee98")
