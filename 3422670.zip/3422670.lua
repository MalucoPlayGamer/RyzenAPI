-- Lua provided by RyzenAPI
-- Game: FlowerBots Demo

-- MAIN APPLICATION
addappid(3422670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422671, 1, "0b847c336b25be24b12ab97d0938ed7e35720f755f14a7d9249681a51c6b59d6")

