-- Lua provided by RyzenAPI
-- Game: No Sun To Worship

-- MAIN APPLICATION
addappid(2202470)
-- Game: addappid(2202470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202472,0,"90b94293ef7481a9142c3ecb1911021945b10b11a8ec3d9330817a09a8e3dcd3")
