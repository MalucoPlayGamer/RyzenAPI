-- Lua provided by RyzenAPI
-- Game: 457840

-- MAIN APPLICATION
addappid(457840)
-- Game: addappid(457840)

-- MAIN APP DEPOTS / PACKAGES
addappid(457840,0,"846c080788164d1d2061a324ef6188b0ddaddeb603be1bbc405cfc37aca4865d")
addappid(457844,0,"7ba76ae704d62caf2850b98c73ce0a5cc6a592af3a0692ddd54414d0faccfdd4")
