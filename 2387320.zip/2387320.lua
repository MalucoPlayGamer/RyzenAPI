-- Lua provided by RyzenAPI
-- Game: Final Factory Demo

-- MAIN APPLICATION
addappid(2387320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387321, 1, "b9e6f26cdb01db6aedf3bf5c55eb061a0199289dcafe88c0e31a11a3f3a8dae8")

