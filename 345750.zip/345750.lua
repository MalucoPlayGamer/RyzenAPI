-- Lua provided by RyzenAPI
-- Game: Idol Hands

-- MAIN APPLICATION
addappid(345750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(345751, 1, "22386a92fc8a12b3f64f98c77175519cca587a8a94e507e0abc7e393a677de87")
addappid(345752, 1, "985bb6044760c945a628c37bf3c4b00d2b6a29efe4d31a9d70f6d888c33156af")
addappid(345753, 1, "7254ba77ed4ca17467b821e836a8f6d7499655a4c7ff934c604d39aff87d5250")

