-- Lua provided by RyzenAPI
-- Game: AppID 1041710

-- MAIN APPLICATION
addappid(1041710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041711, 1, "91b21cdff3da916306a711e6b3048847e7fbf6cd0b9d6c9c7b8834b1d98fc9e4")
