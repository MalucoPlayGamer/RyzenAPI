-- Lua provided by RyzenAPI
-- Game: AppID 1041710

-- MAIN APPLICATION
addappid(1041710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041711, 1, "91b21cdff3da916306a711e6b3048847e7fbf6cd0b9d6c9c7b8834b1d98fc9e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
