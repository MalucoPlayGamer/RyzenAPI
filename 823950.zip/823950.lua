-- Lua provided by RyzenAPI
-- Game: Re:Legend

-- MAIN APPLICATION
addappid(823950)
-- Game: addappid(823950)

-- MAIN APP DEPOTS / PACKAGES
addappid(823951, 1, "d081e93224d7c54473d3bad575eea3b6fa1cda560bedf639cda004dc5e4aa309")
