-- Lua provided by RyzenAPI 
-- Game: Dark Years
addappid(382160)
addappid(382161, 1, "670de7ec4ee42a434286a1c73a4c7f11bfd4f8704257253c6d08847c9c9f0f57")
