-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross - The Official Videogame

-- MAIN APPLICATION
addappid(711750)
addappid(736630)
addappid(736640)
addappid(736650)
addappid(736660)
addappid(736670)
addappid(736680)
addappid(736690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(711751, 1, "76864c057b4f17d01ea1d3649e0ed36f4448806213434b223435be879b28a7da")

