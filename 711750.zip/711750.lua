-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross - The Official Videogame

-- MAIN APPLICATION
addappid(711750)
addappid(736630)
addappid(736640)
addappid(736650)
addappid(736660)
addappid(736670)
addappid(736680)
addappid(736690)
-- Game: addappid(711750)

-- MAIN APP DEPOTS / PACKAGES
addappid(711751, 1, "76864c057b4f17d01ea1d3649e0ed36f4448806213434b223435be879b28a7da")
