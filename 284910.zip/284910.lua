-- Lua provided by RyzenAPI
-- Game: Purgatory: War of the Damned

-- MAIN APPLICATION
addappid(284910)

-- MAIN APP DEPOTS / PACKAGES
addappid(284911, 1, "b74a0f0d8b62639853f8494fa96e393905cbcd7ce7f90988c1a2bd6d22c7411a")

