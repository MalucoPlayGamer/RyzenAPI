-- Lua provided by RyzenAPI
-- Game: Farm Your Friends

-- MAIN APPLICATION
addappid(1285270)
addappid(3254980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285271, 1, "755629771cf385c8fa39403ae70461e33837f90b5a9fa2c86f2d39e12e303650")
