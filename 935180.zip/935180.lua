-- Lua provided by RyzenAPI 
-- Game: Puzzle Monarch: Mummy
addappid(935180)
addappid(935181, 1, "c9e3fd0ffb226ef50c4a43fa3c0455ca5d507b4b873c58738d21fbc08ec3551d")
