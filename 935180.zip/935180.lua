-- Lua provided by RyzenAPI
-- Game: 935180

-- MAIN APPLICATION
addappid(935180)
-- Game: addappid(935180)

-- MAIN APP DEPOTS / PACKAGES
addappid(935181, 1, "c9e3fd0ffb226ef50c4a43fa3c0455ca5d507b4b873c58738d21fbc08ec3551d")
