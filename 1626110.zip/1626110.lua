-- Lua provided by RyzenAPI
-- Game: Game: Space Porter

-- MAIN APPLICATION
addappid(1626110)
-- Game: addappid(1626110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1626111, 1, "9c842b16210285cbe2fe6a2bce7d547f3d98ae99cfe75bab0a5542469276b1d2")
