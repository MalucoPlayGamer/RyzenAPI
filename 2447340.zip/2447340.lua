-- Lua provided by SkyAPI 
-- Game: Grave Deceiver
addappid(2447340)
addappid(2447341, 1, "d9cc8935b60d69e191a0c17773442650859500f3f11a43c01b97c4658c4a0d2a")
