-- Lua provided by RyzenAPI
-- Game: Game: Chivalry 2

-- MAIN APPLICATION
addappid(1824220)
addappid(1998240)
addappid(2140440)
-- Game: addappid(1824220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824221, 1, "70ac4fdbb000d0a3f6ff5a9c3756662da90ff180752fb9bf87cc1f7cfc50e49d")
