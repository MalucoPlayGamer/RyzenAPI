-- Lua provided by RyzenAPI
-- Game: Noclipped

-- MAIN APPLICATION
addappid(2093380)
-- Game: addappid(2093380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093381, 1, "7d19cee76363b8c84524c26081d896896c05a09c70d65795998480d1ee46e0a5")
