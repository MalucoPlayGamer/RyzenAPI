-- Lua provided by SkyAPI 
-- Game: Noclipped
addappid(2093380)
addappid(2093381, 1, "7d19cee76363b8c84524c26081d896896c05a09c70d65795998480d1ee46e0a5")
