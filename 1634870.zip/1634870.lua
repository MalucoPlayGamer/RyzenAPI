-- Lua provided by RyzenAPI
-- Game: Open Brush

-- MAIN APPLICATION
addappid(1634870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634871, 1, "95056ac1f7768c1b835f3df160a994e48263a083e2cfb07453f2937b6f015b0f")
addappid(1634872, 1, "556e0a81553d282a2ace8a2ae31545be99228a841c9d76cdb2e3b7d1dd62f304")
addappid(1634873, 1, "4ab62d998ae068db008c5efbd400e6f9f05ee2543596ce6c69726b631355e47e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
