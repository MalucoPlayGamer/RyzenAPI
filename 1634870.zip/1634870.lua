-- Lua provided by RyzenAPI
-- Game: Game: Open Brush

-- MAIN APPLICATION
addappid(1634870)
-- Game: addappid(1634870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634871, 1, "95056ac1f7768c1b835f3df160a994e48263a083e2cfb07453f2937b6f015b0f")
addappid(1634872, 1, "556e0a81553d282a2ace8a2ae31545be99228a841c9d76cdb2e3b7d1dd62f304")
addappid(1634873, 1, "4ab62d998ae068db008c5efbd400e6f9f05ee2543596ce6c69726b631355e47e")
