-- Lua provided by RyzenAPI
-- Game: The Last Train

-- MAIN APPLICATION
addappid(2456860)
addappid(3125520)
-- Game: addappid(2456860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456861, 1, "74a5123cc7d9b0bfa89b2af1435cd3d11c6c732ea46ed824d88402781890dc92")
