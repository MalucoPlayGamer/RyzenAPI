-- Lua provided by RyzenAPI
-- Game: Legends of Persia

-- MAIN APPLICATION
addappid(301220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(301221, 1, "b2219def6c75b234556474832794ffabcb0c63b5bc320a7085df3673434f3ee6")
