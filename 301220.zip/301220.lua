-- Lua provided by RyzenAPI
-- Game: 301220

-- MAIN APPLICATION
addappid(301220)
-- Game: addappid(301220)

-- MAIN APP DEPOTS / PACKAGES
addappid(301221, 1, "b2219def6c75b234556474832794ffabcb0c63b5bc320a7085df3673434f3ee6")
