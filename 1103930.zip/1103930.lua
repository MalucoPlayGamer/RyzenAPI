-- Lua provided by RyzenAPI
-- Game: Shrine of the God-Ape

-- MAIN APPLICATION
addappid(1103930)
-- Game: addappid(1103930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103931, 1, "b3df3c014dc9475064556185d0c2558fac556302918902dd324dd2933ffc672b")
