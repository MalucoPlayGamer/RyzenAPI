-- Lua provided by RyzenAPI
-- Game: 44600

-- MAIN APPLICATION
addappid(44600)
-- Game: addappid(44600)

-- MAIN APP DEPOTS / PACKAGES
addappid(44601, 1, "6514f359473326da133c8ddd4c67ee60e591f118f6dbbc02e69ae2ee8bcbd526")
