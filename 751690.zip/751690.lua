-- Lua provided by RyzenAPI
-- Game: The Mammoth: A Cave Painting

-- MAIN APPLICATION
addappid(751690)

-- MAIN APP DEPOTS / PACKAGES
addappid(751691, 1, "b2603c7d040115a98c227a930b2bbdc61852dee34718af1fb14848fe81a4a73d")
addappid(751692, 1, "c1ad8d2a3b2d4de95c86163cc511cea3987611f90df50dd25b5a4327feb95bf4")
addappid(751693, 1, "205698486671f88f36f8a73f7e4d7325f899d899823cf29713e8a15a6527efde")

