-- Lua provided by RyzenAPI
-- Game: Can't revert

-- MAIN APPLICATION
addappid(3111680)
-- Game: addappid(3111680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111681, 1, "634163fef584284b6e47f63524287a04157c0c37363b2f375469fc4669e18001")
