-- Lua provided by RyzenAPI
-- Game: Kiara And My Ara Ara Adventure

-- MAIN APPLICATION
addappid(1343090)
-- Game: addappid(1343090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343091, 1, "d921ab7a55629a1b3e972b3bd56eebad278874538b21b2ff3a707aaa1bba022d")
addappid(1343092, 1, "c046968cee6aae534a050bba87aa02eaddb779b21a10e8085cd9afa9e8dd8ed0")
addappid(1343093, 1, "f25d6ae6755107d10eaa6dd45314e18aa778208bfe9375b33524a0912a4e893b")
