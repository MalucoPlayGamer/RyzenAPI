-- Lua provided by RyzenAPI
-- Game: WildStar

-- MAIN APPLICATION
addappid(376570)

-- MAIN APP DEPOTS / PACKAGES
addappid(376571, 1, "f5d7701efe6a5df80910eaf65537ac34ca53ad021fc1d2b2b4166b38d03cd1d6")

