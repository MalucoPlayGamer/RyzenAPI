-- Lua provided by RyzenAPI
-- Game: Giana Sisters: Dream Runners

-- MAIN APPLICATION
addappid(352900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(352901, 1, "8c7a1ad3834f5ddca77c8cbaa807f5a49ffdad81b4c138fa72f1ed957599ec40")
addappid(352902, 1, "ca5473ab31fe8cdaa39a521d7477986b7b9f2ff78c09a79cf40a69d1dda9ced6")
addappid(352903, 1, "4d3e6900c138afa77699409a3199df7001c0f77c8b847c6037b098697bb6e1c2")
addappid(352904, 1, "377470882b0be4cf09586e457b3a6117e5b841c146e8a39d859161287250b6e9")
