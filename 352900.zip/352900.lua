-- Lua provided by RyzenAPI
-- Game: Giana Sisters: Dream Runners

-- MAIN APPLICATION
addappid(352900)
-- Game: addappid(352900)

-- MAIN APP DEPOTS / PACKAGES
addappid(352901, 1, "8c7a1ad3834f5ddca77c8cbaa807f5a49ffdad81b4c138fa72f1ed957599ec40")
addappid(352902, 1, "ca5473ab31fe8cdaa39a521d7477986b7b9f2ff78c09a79cf40a69d1dda9ced6")
addappid(352903, 1, "4d3e6900c138afa77699409a3199df7001c0f77c8b847c6037b098697bb6e1c2")
addappid(352904, 1, "377470882b0be4cf09586e457b3a6117e5b841c146e8a39d859161287250b6e9")
