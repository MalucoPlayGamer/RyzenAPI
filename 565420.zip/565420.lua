-- Lua provided by RyzenAPI 
-- Game: Bad Pad Demo
addappid(565420)
addappid(565421, 1, "ac51cf3b5c698bcb2b82382f2adf24743c29e468d47632a64b8c3130b93f9569")
addappid(565423, 1, "63a6bff888733112290dd063392cde7c904f6a737cdeea8a0290a69de006249c")
