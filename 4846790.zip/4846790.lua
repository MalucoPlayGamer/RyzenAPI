-- Lua provided by RyzenAPI
-- Game: Scrap Snap

-- MAIN APPLICATION
addappid(4846790) -- Scrap Snap

-- MAIN APP DEPOTS / PACKAGES
addappid(4846791, 1, "dbc6e7b0d76b05365eb231ac820ff3c005167441b14e1b990539e6a8cc3e52f6") -- Depot 4846791
addappid(4846792, 1, "3c7e5a125a8130fff26afb40ca36d63f6da6cde85fcdcfe1ddf5c390b13b3faf") -- Depot 4846792
