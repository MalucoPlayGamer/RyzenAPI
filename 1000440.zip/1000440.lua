-- Lua provided by RyzenAPI
-- Game: AppID 1000440

-- MAIN APPLICATION
addappid(1000440)
-- Game: addappid(1000440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000441, 1, "c4eecd8e18ac4ed01b2cf882fc115502f33371ecd856a3a682a8bff012f8cb72")
