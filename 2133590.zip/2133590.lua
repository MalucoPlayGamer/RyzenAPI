-- Lua provided by RyzenAPI
-- Game: fig.

-- MAIN APPLICATION
addappid(2133590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133592,0,"51c44facbf26dbbab53a18e65679c770edbccee4bf02ddfb5f22399dfda98ae0")
