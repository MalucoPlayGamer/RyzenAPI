-- Lua provided by RyzenAPI 
-- Game: AppID 2904810
addappid(2904810)
addappid(2904811, 1, "96f147e80d6b774f38cb8b5dfc524f47208b98b30c9518eb861026e42851df1b")
