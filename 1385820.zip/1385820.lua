-- Lua provided by RyzenAPI
-- Game: Game: Ninja Kunoichi

-- MAIN APPLICATION
addappid(1385820)
-- Game: addappid(1385820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385821, 1, "87de791685a6faa8a8d8196e8e946988dbae1bcf3bec2881bc5c1a62bcc42d10")
