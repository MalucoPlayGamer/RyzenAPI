-- Lua provided by RyzenAPI
-- Game: Toy Shire: Room One

-- MAIN APPLICATION
addappid(2517850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517851, 1, "abd91ac83643b858a63475f650b24d5afea36ce8da6f540cf29abcd6b1730d12")
