-- Lua provided by RyzenAPI
-- Game: Bounty Hunter: Ocean Diver

-- MAIN APPLICATION
addappid(830510)
addappid(1409220)
addappid(1409221)
addappid(1409222)
addappid(1409223)
addappid(1409224)
addappid(1409225)
addappid(1409226)
addappid(1409227)
addappid(1409228)
addappid(1409229)

-- MAIN APP DEPOTS / PACKAGES
addappid(830511, 1, "a0e0e4790e548c6fbc10763c70bfc98bf8e2cd0af7a03d5dfec75fb2c4a3c551")

