-- Lua provided by RyzenAPI
-- Game: Ecstasy Elf Shotenken -Naruru's Sexy Adventure-

-- MAIN APPLICATION
addappid(1678770)
addappid(2293160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678771, 1, "33bff329c08279520665d04849dfb09afd677c53b58c61fc877642b09cce64d1")
