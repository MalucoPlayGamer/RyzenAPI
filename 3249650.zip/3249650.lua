-- Lua provided by RyzenAPI
-- Game: Little Fighter 2 Remastered

-- MAIN APPLICATION
addappid(3249650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3249658,0,"4810d60cae6b875340e7648245ae259dd8e6e933cb249b10fa7b7de6025b9239")

