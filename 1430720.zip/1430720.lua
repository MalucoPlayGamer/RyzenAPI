-- Lua provided by RyzenAPI
-- Game: 策马三国志之霸王大陆

-- MAIN APPLICATION
addappid(1430720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430721, 1, "b481ed0e1631674fab64295c28a02cc09b9f2496d6618c27f11c7da1d902d844")

