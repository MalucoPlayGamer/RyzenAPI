-- Lua provided by RyzenAPI
-- Game: Game: AppID 531490

-- MAIN APPLICATION
addappid(531490)
-- Game: addappid(531490)

-- MAIN APP DEPOTS / PACKAGES
addappid(531491, 1, "959a172e747f91fd23adf955d8f8bb60f92b9445c0aa6ecf1c964e5392347bd2")
