-- Lua provided by RyzenAPI
-- Game: 鬼山 / A Ghost Around Me

-- MAIN APPLICATION
addappid(682490)

-- MAIN APP DEPOTS / PACKAGES
addappid(682491, 1, "1f3b502c0251b10d8ea10fa9876e62c7ae0f3e2d1bef11dd14e3c1d395bf4c36")
