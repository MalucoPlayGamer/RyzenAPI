-- Lua provided by RyzenAPI
-- Game: Nova Flow

-- MAIN APPLICATION
addappid(718250)

-- MAIN APP DEPOTS / PACKAGES
addappid(718251,0,"aace44f56adfc087c3efde60aea096fed12596064a80005e89bb9be501085e1f")

