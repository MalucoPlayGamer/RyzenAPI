-- Lua provided by RyzenAPI
-- Game: 来自边境 - From Frontier

-- MAIN APPLICATION
addappid(1348180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348181, 1, "cb6cc73a1741138cfbbf8d65a78b576b1dbab3b622192fc7e15dcb025c350344")
addappid(1348183, 1, "c50eb036de95414fd5782ed64e071d2c967f022bc1ad99c28e3e5ff90bb56942")

