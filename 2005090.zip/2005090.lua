-- Lua provided by RyzenAPI
-- Game: addappid(2005090)

-- MAIN APPLICATION
addappid(2005090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005091, 1, "d0096bb6160560e2c1b02177fc2a21a816d772a0d005ae9fb3dc4f7a0fc7f541")
