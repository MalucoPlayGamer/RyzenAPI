-- Lua provided by RyzenAPI
-- Game: Eastshade

-- MAIN APPLICATION
addappid(715560)

-- MAIN APP DEPOTS / PACKAGES
addappid(715561, 1, "d0102657137d591fdf2e38f01fb3c499a899af9f2ab3227f0cb0ef522930e810")
