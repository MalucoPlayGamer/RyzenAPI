-- Lua provided by RyzenAPI
-- Game: Bouncers

-- MAIN APPLICATION
addappid(772740)

-- MAIN APP DEPOTS / PACKAGES
addappid(772741, 1, "f38eccd8fa591400083962aeb01df485c3eee6abfc9329196dc643f24f2e6fd7")
