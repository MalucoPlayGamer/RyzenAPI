-- Lua provided by RyzenAPI
-- Game: 7 Sins : Lost in Labyrinth

-- MAIN APPLICATION
addappid(2221820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221821, 1, "6ca8f5b7f94d8b38c784fe719b5646173f6c67fc0295e08b07aae392c44bbb4b")
