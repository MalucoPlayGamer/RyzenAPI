-- Lua provided by RyzenAPI
-- Game: The Bard's Tale IV: Director's Cut

-- MAIN APPLICATION
addappid(1091980)
addappid(1107880)
addappid(1107881)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091981,0,"4aba3b2e46b56a044d23df6475d1f7d603e4c348131d668c147679a5cfd9913c")
addappid(1091982,0,"ff8b2c45846b4d26bd8678ed9d4c548f082574222a413b7059c6c11a61815810")
addappid(1091983,0,"7317e994b14f2348f60111cac419249b616a018ed6c2971a2917e4b37497c7bb")
addappid(1091984,0,"cf6a3c6202c0b040a8735d5639ee5e5dbface6d0ae39231737a65a0e38b09198")
addappid(1091985,0,"99b8dcaa3fd945a235fa5ee97b924c9dfaf14bcfaf562296c7f47dd4f2d86fd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
