-- Lua provided by SkyAPI 
-- Game: The Mosquito Gang
addappid(2811100)
addappid(2811101, 1, "8a067378b05efe4b1a2a5b3ec9f0092c228ca6443d094a0bacd78627381d29fd")
