-- Lua provided by RyzenAPI
-- Game: 2811100

-- MAIN APPLICATION
addappid(2811100)
-- Game: addappid(2811100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811101, 1, "8a067378b05efe4b1a2a5b3ec9f0092c228ca6443d094a0bacd78627381d29fd")
