-- Lua provided by RyzenAPI
-- Game: AppID 274310

-- MAIN APPLICATION
addappid(274310)

-- MAIN APP DEPOTS / PACKAGES
addappid(274311, 1, "b8a5679f1113f6a49979eb7be0c48d437a7260269584418eb8071d33497f1e4e")
addappid(274313, 1, "c530c47fde18c3d39b86b706bdf8c1b8cd391ce6e05cc6057fb344ed410936b5")
addappid(274314, 1, "1266a5cf11f15940e270b4455e3ce8a02da5c2f0dbf449d91511315d65e6a32a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
