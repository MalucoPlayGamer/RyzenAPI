-- Lua provided by RyzenAPI
-- Game: Slam Bolt Scrappers

-- MAIN APPLICATION
addappid(96900)

-- MAIN APP DEPOTS / PACKAGES
addappid(96901, 1, "3845d35c2fbeae3046dbce4976051285d22da28fd785c3bb48bf910fb8d7b8cd")

