-- Lua provided by RyzenAPI
-- Game: addappid(2259161)

-- MAIN APPLICATION
addappid(2259161)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259161,0,"8cf7ad1677ed239c72c6b03e3e38e341e93abde44ffdc448c712e49ccd4addb8")
