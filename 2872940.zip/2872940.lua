-- Lua provided by RyzenAPI
-- Game: AdventureBarStory Demo

-- MAIN APPLICATION
addappid(2872940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872941, 1, "690ee4e841c0cdaaae07bdb2e42444053d4d25e7ef55dbbc8c1ef2cc3f5352c8")
