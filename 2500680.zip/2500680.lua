-- Lua provided by RyzenAPI
-- Game: Tiny Chaos

-- MAIN APPLICATION
addappid(2500680)
-- Game: addappid(2500680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500681, 1, "195c6483af539eab014deeceb696679fb031a8c9cfd89dfcc864a237395982b0")
