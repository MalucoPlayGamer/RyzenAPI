-- Lua provided by RyzenAPI
-- Game: Abandoned Knight

-- MAIN APPLICATION
addappid(444790)

-- MAIN APP DEPOTS / PACKAGES
addappid(444791, 1, "b232a2e1b8f96fe9eaf74f654874dbf2a4199273fc2469bdc6f5dcf5abfe6246")

