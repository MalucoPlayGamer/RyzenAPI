-- Lua provided by RyzenAPI
-- Game: Them's Fightin' Herds

-- MAIN APPLICATION
addappid(574980)

-- MAIN APP DEPOTS / PACKAGES
addappid(574981, 1, "dbbef6545bc9032fc2d37759f9a8e9685476037aac6c213039d84d19579872a2")
addappid(574982, 1, "0b69dafa0e40126b3062dbfa7cf051409823c601a565d3ef1ba5d412af3d0345")
addappid(574985, 1, "9d6a154527c69d42644330646fb845f86ab3f99ee2517ad59128cfa145188263")
addappid(574986, 1, "c768e2895d596c6879c11b76d646a8970f0fa92884483bafb7d64a143b43179e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1240390)
addappid(1522430)
addappid(1839170)
addappid(2153120)
addappid(2193830)
addappid(2338530)
addappid(2424370)
addappid(2613600)
