-- Lua provided by RyzenAPI
-- Game: Bobok

-- MAIN APPLICATION
addappid(1783510)
-- Game: addappid(1783510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783512,0,"153d645d104cf0d13a99cdb95b641b746b6af8849307584a2146ba7fe34a2a70")
