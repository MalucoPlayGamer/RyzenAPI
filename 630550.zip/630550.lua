-- Lua provided by RyzenAPI
-- Game: AppID 630550

-- MAIN APPLICATION
addappid(630550)

-- MAIN APP DEPOTS / PACKAGES
addappid(630551, 1, "5ceed683d9cedd786dec127c9fdb1be3ab065d23c0e4c65422e0e6e3e9cc38bb")

