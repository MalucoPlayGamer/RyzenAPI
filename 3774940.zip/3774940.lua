-- Lua provided by RyzenAPI
-- Game: One Last Clip

-- MAIN APPLICATION
addappid(3774940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3774941,0,"6a0c349f0a37b44d4de380a9a8bf9092f72e4d4090856f90a223446a3ab388a0")

