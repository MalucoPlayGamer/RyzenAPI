-- Lua provided by RyzenAPI
-- Game: Crime District

-- MAIN APPLICATION
addappid(1593660)
addappid(1593661)
addappid(1593662)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593663,0,"bb7b2448e05f0899227c6ae6e46d6d4f3762d78c7150f6524f7a3d0930ac741b")

