-- Lua provided by SkyAPI 
-- Game: SquishCraft
addappid(2081180)
addappid(2081181, 1, "8564c2a714db31bcc223f82e3b129a6178c9d2df22d38aa6055ddb0528f5fe49")
