-- Lua provided by RyzenAPI 
-- Game: Sex Adventures - The Job Interview
addappid(1882670)
addappid(1882671, 1, "33c722a0a00975f448db184961ed520201328769a730e8d69ccc8ca210c2c1aa")
