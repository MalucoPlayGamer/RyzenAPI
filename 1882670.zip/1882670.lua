-- Lua provided by RyzenAPI
-- Game: Sex Adventures - The Job Interview

-- MAIN APPLICATION
addappid(1882670)
-- Game: addappid(1882670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882671, 1, "33c722a0a00975f448db184961ed520201328769a730e8d69ccc8ca210c2c1aa")
