-- Lua provided by RyzenAPI
-- Game: Desvelado

-- MAIN APPLICATION
addappid(2878710)
-- Game: addappid(2878710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878711, 1, "b482fc74c7ab7e30907297b7b295855b500577ffa3325375b15d16a4dc57f5e9")
