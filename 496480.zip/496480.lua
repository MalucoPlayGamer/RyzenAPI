-- Lua provided by RyzenAPI
-- Game: 496480

-- MAIN APPLICATION
addappid(496480)
-- Game: addappid(496480)

-- MAIN APP DEPOTS / PACKAGES
addappid(496481, 1, "1c6dccefec8ec716b2ff0f3dedfe4fc22df175ead8b8cc972958b1fb0b2dff75")
