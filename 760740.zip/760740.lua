-- Lua provided by RyzenAPI
-- Game: AppID 760740

-- MAIN APPLICATION
addappid(760740)
-- Game: addappid(760740)

-- MAIN APP DEPOTS / PACKAGES
addappid(760741, 1, "fa384bfef50d01179b15dc168f3602b378e852a0d0ec3ea2329101a338bfc555")
