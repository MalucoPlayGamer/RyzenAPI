-- Lua provided by SkyAPI 
-- Game: Eyes of War
addappid(2343930)
addappid(2343931, 1, "396378d0b188534e18166400651f8ceb3cbfe68b2a374641b0b72a90b7559116")
