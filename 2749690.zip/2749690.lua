-- Lua provided by RyzenAPI
-- Game: 2749690

-- MAIN APPLICATION
addappid(2749690)
-- Game: addappid(2749690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2749691, 1, "f16962e7965efe37b16d42ae2b937ee17311bdd90a5cf7a0fbf8b08dca484194")
