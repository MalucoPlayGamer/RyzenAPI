-- Lua provided by RyzenAPI
-- Game: Pathologic 2

-- MAIN APPLICATION
addappid(505230)

-- MAIN APP DEPOTS / PACKAGES
addappid(505234,0,"f0fd935cbb2178f142e212245516856090e8f87d5b3430eb3272c4a1cee4fea1")
addappid(505235,0,"69758f05f24329364492c4343129d409f887790d296ddf8367bfc919b18e6652")
addappid(505236,0,"55d16d46e4ed068d4e0bb04c82cc73fbb904e86aa5a1f610251e81f49f5cff21")
addappid(1141960,0,"82d31804c2211a13f121c96f8e992eeec32dba17c5b49b24ebbcf6b80f4bcb6c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1080220)
