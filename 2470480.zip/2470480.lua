-- Lua provided by RyzenAPI
-- Game: Game: Paris Transylvania Demo

-- MAIN APPLICATION
addappid(2470480)
-- Game: addappid(2470480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470481, 1, "b104df8d73508381e9691de315beb6422409ff830497445b26d6108cbacf8bc6")
