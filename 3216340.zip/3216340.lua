-- Lua provided by RyzenAPI 
-- Game: Tearscape
addappid(3216340)
addappid(3216341, 1, "dc2515005012b2d7531cdf2b283d58340c4bcb125ebc850bc8f351691b8bf587")
addappid(3216342, 1, "817e9db5b83084630b9e8709d0712ee45c4345dc057665a35aa25d79692d4db2")
addappid(3216343, 1, "cf84ad478310bc0be443e5ea69e03997b750abed2cfca7bf36034dd5a07fe5e8")
