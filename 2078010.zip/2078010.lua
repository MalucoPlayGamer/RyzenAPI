-- Lua provided by RyzenAPI
-- Game: Legends of Immortality

-- MAIN APPLICATION
addappid(2078010)
-- Game: addappid(2078010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078011, 1, "c44034b75d0239e305b6ddb8bf80ddd4cf25adb6df44333088a6a559c40b68a2")
