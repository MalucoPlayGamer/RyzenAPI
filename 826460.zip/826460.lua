-- Lua provided by RyzenAPI
-- Game: The Road to Hades

-- MAIN APPLICATION
addappid(826460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(826461, 1, "1abc6f409759cc3889449f96affbc4ec5e601424434fb9b64308ff1a8af07b59")
addappid(826462, 1, "f73eb58a9bc670ea35593419cc27b0c6ea9b1aac6f61e70714055aff4bfb978c")

