-- Lua provided by RyzenAPI 
-- Game: AppID 826460
addappid(826460)
addappid(826461, 1, "1abc6f409759cc3889449f96affbc4ec5e601424434fb9b64308ff1a8af07b59")
addappid(826462, 1, "f73eb58a9bc670ea35593419cc27b0c6ea9b1aac6f61e70714055aff4bfb978c")
