-- Lua provided by RyzenAPI
-- Game: Operation Lovecraft: Fallen Doll Playtest

-- MAIN APPLICATION
addappid(1810920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810921, 1, "d71c539b125522b912b11034cfd7cccf8a30f3f8269e22a652740504ebf805df")
