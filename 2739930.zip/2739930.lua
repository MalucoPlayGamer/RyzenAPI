-- Lua provided by RyzenAPI
-- Game: addappid(2739930)

-- MAIN APPLICATION
addappid(2739930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739931, 1, "6ac8c1f491946b3f66b9a2ef0544df41a4febb75e35f401bb23065206a41eabb")
