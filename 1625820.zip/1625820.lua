-- Lua provided by RyzenAPI
-- Game: Banish

-- MAIN APPLICATION
addappid(1625820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625821, 1, "971ae320c736f6a7aca71893f91f88a757ddf06ea38f5ee3cac6ea8a5655c111")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
