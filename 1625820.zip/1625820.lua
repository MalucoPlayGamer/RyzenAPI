-- Lua provided by RyzenAPI
-- Game: Banish

-- MAIN APPLICATION
addappid(1625820)
-- Game: addappid(1625820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625821, 1, "971ae320c736f6a7aca71893f91f88a757ddf06ea38f5ee3cac6ea8a5655c111")
