-- Lua provided by RyzenAPI
-- Game: Game: Charles Haunted Mansion

-- MAIN APPLICATION
addappid(2569680)
-- Game: addappid(2569680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569681, 1, "2ec2bdd9658289991542c7a538fc1e903ea675275a2f6c458c10b25ec9e31214")
