-- Lua provided by RyzenAPI
-- Game: 2990180

-- MAIN APPLICATION
addappid(2990180)
-- Game: addappid(2990180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990181, 1, "1f0170de4590b80ef78f92598b834cfd5dc88216e9462c20c31ab4d92ae78568")
