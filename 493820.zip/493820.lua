-- Lua provided by RyzenAPI
-- Game: Rivais Em Batalha

-- MAIN APPLICATION
addappid(493820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(493821, 1, "eef32b778dc687b22efd6d5a1a095ce71635bc997655531bab1902311057e44f")

