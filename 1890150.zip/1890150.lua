-- Lua provided by RyzenAPI
-- Game: 1890150

-- MAIN APPLICATION
addappid(1890150)
-- Game: addappid(1890150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890151, 1, "e4f168318d067185ebca436edef4d4d3988fa5f722ed9a77c9b5f5ff56b5a1b8")
