-- Lua provided by RyzenAPI
-- Game: Rune Gate

-- MAIN APPLICATION
addappid(2522270)
-- Game: addappid(2522270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522271, 1, "3de346ab8e63e268d1f299f9406e791562f22438fd29ac06843a906455ca1a53")
