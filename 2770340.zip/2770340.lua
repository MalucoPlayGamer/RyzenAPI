-- Lua provided by RyzenAPI
-- Game: Oh My Goddess!

-- MAIN APPLICATION
addappid(2770340)
-- Game: addappid(2770340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2770341, 1, "d2058e2602d24fb0d0db90a351cfb3e8866fe893a87ef7c937e4a9a59e0b3a37")
