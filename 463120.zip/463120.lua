-- Lua provided by RyzenAPI
-- Game: addappid(463120)

-- MAIN APPLICATION
addappid(463120)

-- MAIN APP DEPOTS / PACKAGES
addappid(463121, 1, "f5e18c14d90acbc8e4bf5af4b7a60160dd2a6c58a97ac22b20073bba8204d306")
addappid(463122, 1, "b987a56cecfb7d6c969bd11d50996a47d9bd77d31f489b8949a43c2d270680bc")
