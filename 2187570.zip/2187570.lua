-- Lua provided by RyzenAPI
-- Game: MUSHROOMAN

-- MAIN APPLICATION
addappid(2187570)
-- Game: addappid(2187570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187571, 1, "e8aeb39362364b18961f83b9fb365a9a5587f106d1eaaf6cc5eb9c09f77ed258")
