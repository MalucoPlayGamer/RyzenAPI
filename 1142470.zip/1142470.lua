-- Lua provided by RyzenAPI
-- Game: addappid(1142470)

-- MAIN APPLICATION
addappid(1142470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142471, 1, "9dec967c1dffd58123165d4193ea4e5867956edb829a02978a3d77e475453aa7")
