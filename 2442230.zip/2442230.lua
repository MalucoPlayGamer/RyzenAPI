-- Lua provided by RyzenAPI
-- Game: 2442230

-- MAIN APPLICATION
addappid(2442230)
-- Game: addappid(2442230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442231, 1, "ff6e7531a83741ee6415ae31238885128eaca0fab824d38894079d4db938f95c")
