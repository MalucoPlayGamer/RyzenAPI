-- Lua provided by RyzenAPI
-- Game: Flotilla

-- MAIN APPLICATION
addappid(55000)
-- Game: addappid(55000)

-- MAIN APP DEPOTS / PACKAGES
addappid(55001, 1, "b88a00774d87b320fb1c80244d9cb35b906b2b283308f15da2111d6c06ba60b5")
addappid(55002, 1, "9df3f3e19238341e7958d4be74ee44d74857fec887b297bc7c828cd8bd6d1e8b")
addappid(55003, 1, "b795ca1fb16957e37639ea6a26fd75f2177fe48873e7baee782b203b34126829")
