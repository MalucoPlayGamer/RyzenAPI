-- Lua provided by RyzenAPI
-- Game: Deathstate: Abyssal Edition

-- MAIN APPLICATION
addappid(402120)
addappid(435240)
-- Game: addappid(402120)

-- MAIN APP DEPOTS / PACKAGES
addappid(402121, 1, "0e18347331a7ceae015f1b3bfde8e3437460b3f6d9309626071fae64fe62bb78")
