-- Lua provided by RyzenAPI
-- Game: AppID 335210

-- MAIN APPLICATION
addappid(335210)
-- Game: addappid(335210)

-- MAIN APP DEPOTS / PACKAGES
addappid(335211, 1, "b0833ccf5d483296739e47e80e6be23de57cb44c16da89116788dc07550cc0de")
addappid(335212, 1, "cbf2fbd9e48898f8956f3aa8c323804d8c8bf68fc0f445eca408d1eeaa0233d7")
addappid(335214, 1, "1664b70daea8dc47c32f8a3a33ab69876dcfff4460a609345b8bb3a72816acf0")
addappid(335217, 1, "c7afdb6ba0aefe4dc537045314fecc195227763646cb3f25a15cbea77866378b")
