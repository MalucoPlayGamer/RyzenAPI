-- Lua provided by RyzenAPI
-- Game: Game: J8 Hero

-- MAIN APPLICATION
addappid(3081810)
-- Game: addappid(3081810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081811, 1, "6a56c08974a0e00c4cf0f94cd320264545f450163e88e380d4c0052e3ab2722d")
