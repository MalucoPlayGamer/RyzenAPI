-- Lua provided by RyzenAPI
-- Game: Axial Drift

-- MAIN APPLICATION
addappid(1707030)
-- Game: addappid(1707030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707031, 1, "d20bc90936d416f1747af3a2a7e9fe4284a0820285ddd440806a093ff86c0946")
