-- Lua provided by RyzenAPI
-- Game: Axial Drift

-- MAIN APPLICATION
addappid(1707030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707031, 1, "d20bc90936d416f1747af3a2a7e9fe4284a0820285ddd440806a093ff86c0946")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
