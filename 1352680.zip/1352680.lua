-- Lua provided by RyzenAPI
-- Game: Winter War 1939

-- MAIN APPLICATION
addappid(1352680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352681, 1, "2ff1396e81ae50f3ef52806e73dfeeb45049c9a7db7929d1a258cae1af72d3ac")
