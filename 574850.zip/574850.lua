-- Lua provided by RyzenAPI
-- Game: Game: AppID 574850

-- MAIN APPLICATION
addappid(574850)
-- Game: addappid(574850)

-- MAIN APP DEPOTS / PACKAGES
addappid(574851, 1, "09db46342042dafaae6038537c129f2bdfa7bc63c4ff420537f0c55166e3374f")
