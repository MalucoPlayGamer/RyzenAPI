-- Lua provided by RyzenAPI 
-- Game: AppID 329690
addappid(329690)
addappid(329691, 1, "462d0da52d8f000cdb53a31e41efc4535db587e3def3d4e0109c9b8c460282e7")
