-- Lua provided by SkyAPI 
-- Game: AppID 21010
addappid(21010)
addappid(21011, 1, "4c812e2205dc8a382ec0d179bb569d4d4a58da09b57bf37d02afa1cb2724a083")
