-- Lua provided by RyzenAPI
-- Game: AppID 21010

-- MAIN APPLICATION
addappid(21010)

-- MAIN APP DEPOTS / PACKAGES
addappid(21011, 1, "4c812e2205dc8a382ec0d179bb569d4d4a58da09b57bf37d02afa1cb2724a083")
