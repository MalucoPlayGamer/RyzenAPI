-- Lua provided by RyzenAPI
-- Game: 105800

-- MAIN APPLICATION
addappid(105800)
-- Game: addappid(105800)

-- MAIN APP DEPOTS / PACKAGES
addappid(105801, 1, "7523d1244fc178e06a0c5742026ebb904fdf2a0fc623c0ebff3ddbe4813fac25")
addappid(105802, 0, "0e7a12c460700637968abb3f6b31cb07eba03bdd77b73450ca986ab5d81de9e4")
