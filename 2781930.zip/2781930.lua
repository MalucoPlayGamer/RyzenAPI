-- Lua provided by RyzenAPI
-- Game: The Legend of Legacy HD Remastered - Mini Art Book

-- MAIN APPLICATION
addappid(2781930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781930,0,"a44d5035552b1b6495569e4a09d5d71c0ac7b51cfcac88202c12b507d25f836f")
