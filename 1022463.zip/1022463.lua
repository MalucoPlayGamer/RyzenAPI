-- Lua provided by RyzenAPI
-- Game: DFF NT: Kuja Starter Pack

-- MAIN APPLICATION
addappid(1022463)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022463,0,"05ac5d4e76ef69df59596f11e782496e95623707d76b7482db477cfa1dfa0033")

