-- Lua provided by RyzenAPI
-- Game: Onimusha: Warlords

-- MAIN APPLICATION
addappid(761600)

-- MAIN APP DEPOTS / PACKAGES
addappid(761601, 1, "a9cebe81198dc3bda033a39cb706ee6de1b8e574c0ea442ec1e611e2247764de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(961480)
