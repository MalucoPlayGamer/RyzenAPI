-- Lua provided by RyzenAPI
-- Game: Onimusha: Warlords

-- MAIN APPLICATION
addappid(761600)
-- Game: addappid(761600)

-- MAIN APP DEPOTS / PACKAGES
addappid(761601, 1, "a9cebe81198dc3bda033a39cb706ee6de1b8e574c0ea442ec1e611e2247764de")
