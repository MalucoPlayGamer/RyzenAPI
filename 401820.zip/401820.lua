-- Lua provided by RyzenAPI
-- Game: AppID 401820

-- MAIN APPLICATION
addappid(401820)
-- Game: addappid(401820)

-- MAIN APP DEPOTS / PACKAGES
addappid(401821, 1, "69f3b4ec760e019695d908ba10609a45215dcb81997e9cc6b9a127d521c3333a")
