-- Lua provided by RyzenAPI
-- Game: Game: AaaaaAAaaaAAAaaAAAAaAAAAA!!! for the Awesome

-- MAIN APPLICATION
addappid(15560)
addappid(228985)
-- Game: addappid(15560)

-- MAIN APP DEPOTS / PACKAGES
addappid(15561, 1, "9ef70c34efb2d02303d95ca2cfdf6f887d1f2e513f9d2347c5d7dfec982bfd83")
addappid(15562, 1, "d0ee6502b9aa26741a93ca127abe99647a2e572f58787d51319f396d3ed734ab")
addappid(15563, 1, "1518c1953493b8d5dad72c9b0487b29849dca89120a6197ec398c965d08b291b")
