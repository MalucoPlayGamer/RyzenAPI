-- Lua provided by RyzenAPI
-- Game: PANZERKAMPF®

-- MAIN APPLICATION
addappid(2771910)
