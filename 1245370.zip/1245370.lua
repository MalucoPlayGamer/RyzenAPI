-- Lua provided by RyzenAPI
-- Game: Puzzle Forge Dungeon

-- MAIN APPLICATION
addappid(1245370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245371, 1, "d874e9830dbabd9017f4a5ce184969380b13b735896493642e2e601520be0c6c")
