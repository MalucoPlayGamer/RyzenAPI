-- Lua provided by RyzenAPI
-- Game: Princess Guard

-- MAIN APPLICATION
addappid(1145040)
-- Game: addappid(1145040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145041, 1, "f8b1a9d0af037bc8d56d0223cb02b0115b20058fbd3d9ec383633d92bb8c97d7")
