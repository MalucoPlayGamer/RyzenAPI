-- Lua provided by RyzenAPI
-- Game: Princess Guard

-- MAIN APPLICATION
addappid(1145040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145041, 1, "f8b1a9d0af037bc8d56d0223cb02b0115b20058fbd3d9ec383633d92bb8c97d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
