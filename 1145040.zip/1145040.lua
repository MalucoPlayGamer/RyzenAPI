-- Lua provided by SkyAPI 
-- Game: Princess Guard
addappid(1145040)
addappid(1145041, 1, "f8b1a9d0af037bc8d56d0223cb02b0115b20058fbd3d9ec383633d92bb8c97d7")
