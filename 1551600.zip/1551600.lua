-- Lua provided by RyzenAPI
-- Game: addappid(1551600)

-- MAIN APPLICATION
addappid(1551600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551601, 1, "beb80b28f4d5582fa9a601dab6592e94de32fe9b94c5e090ce2e7ada1180814c")
addappid(1551602, 1, "9dc0bcc68c45563a2fdbb860ab52f1fc4ef2eabb02832a9ea4860868643b0f9f")
addappid(1551603, 1, "ae24018b1e2e0d112e71e28270aa0589347f43de0f65c2b731b37a5b5ee4c6cc")
