-- Lua provided by RyzenAPI
-- Game: OMEGA 6 The Triangle Stars

-- MAIN APPLICATION
addappid(3128580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128581, 1, "92261e1edd8d96d61c59ab55af8b4a3f87e080c45a512b871e8097e776fedfff")

