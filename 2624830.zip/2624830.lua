-- Lua provided by RyzenAPI 
-- Game: AppID 2624830
addappid(2624830)
addappid(2624831, 1, "225ccec4edbc0318b0cb258a760cd2c7e293fa66b28b3c8827350acda792de5f")
