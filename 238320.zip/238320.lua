-- Lua provided by RyzenAPI
-- Game: Outlast

-- MAIN APPLICATION
addappid(238320)

-- MAIN APP DEPOTS / PACKAGES
addappid(238321, 1, "4c6dde66a11fc24f39a7e16c0fd5027be8d4227e91867538aef8ee186568ec3a")
addappid(238322, 1, "d9563699204b1071d794df59950c02ee46497d4f9db36c461fa39114bdf0b859")
addappid(238323, 1, "9c0f4b149e80ddf49aa848fe86a8c58dbbdac73fc55870b945ccc74eafd4b7ec")
addappid(238324, 1, "a533af71b69ecc9802e5288c39a3b94942a1e844f2584a8b2d49144fbaa2d3e4")
addappid(238325, 1, "2c90d8d88b5e11e438bf6f0f794fa08da92101921cb4bdc2dfc072cd7348a1c7")
addappid(273300, 0, "ef20a5f980c8264317c95f217597a95cda9dd8e0de23d66237b0374e1b3b4b19")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
