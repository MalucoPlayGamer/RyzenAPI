-- Lua provided by SkyAPI 
-- Game: AppID 896960
addappid(896960)
addappid(896961, 1, "afd883ac275e851e658a635f3dd095250823c6397349d42b1c1fa7cb77478899")
