-- Lua provided by RyzenAPI
-- Game: 896960

-- MAIN APPLICATION
addappid(896960)
-- Game: addappid(896960)

-- MAIN APP DEPOTS / PACKAGES
addappid(896961, 1, "afd883ac275e851e658a635f3dd095250823c6397349d42b1c1fa7cb77478899")
