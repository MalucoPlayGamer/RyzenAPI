-- Lua provided by RyzenAPI 
-- Game: AppID 2264940
addappid(2264940)
addappid(2264941, 1, "987a24f21fdd270942040959fe2cd4964722c18eeba9b9c5460478b854ee8cce")
