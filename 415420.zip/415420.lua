-- Lua provided by RyzenAPI
-- Game: AppID 415420

-- MAIN APPLICATION
addappid(415420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(415421, 1, "c70db1e05ea56dad941c96c1c0ed236175a0f5dc185145c5e71b0ff3aba0f659")
addappid(415422, 1, "6fb0217aea6d7ea2d43d82f81356e873a3a82a2f5f99e618168ea9cefac1e577")
addappid(415423, 1, "b319b84e49d37f24b867d8857d66babbd7509d3b24c648017eade4528498c3f3")

