-- Lua provided by SkyAPI 
-- Game: AppID 415420
addappid(415420)
addappid(415421, 1, "c70db1e05ea56dad941c96c1c0ed236175a0f5dc185145c5e71b0ff3aba0f659")
addappid(415422, 1, "6fb0217aea6d7ea2d43d82f81356e873a3a82a2f5f99e618168ea9cefac1e577")
addappid(415423, 1, "b319b84e49d37f24b867d8857d66babbd7509d3b24c648017eade4528498c3f3")
