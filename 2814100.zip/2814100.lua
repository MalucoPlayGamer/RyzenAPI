-- Lua provided by RyzenAPI
-- Game: MILF's Plaza - Juicy Wallpapers Pack

-- MAIN APPLICATION
addappid(2814100)
-- Game: addappid(2814100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814100,0,"75285352d2e90ee65a97e3123a7abe02d2739ee2382027567c386fccceb9ae31")
