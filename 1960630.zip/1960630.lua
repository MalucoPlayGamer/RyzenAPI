-- Lua provided by RyzenAPI
-- Game: Cursed 2

-- MAIN APPLICATION
addappid(1960630)
-- Game: addappid(1960630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960631, 1, "1f1452e3cdb826543408ae51d6690cd7600ae9e77ef2ee37e18e68615953851d")
