-- Lua provided by RyzenAPI
-- Game: addappid(2478580)

-- MAIN APPLICATION
addappid(2478580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478581, 1, "0b0ec6929fcbe0b6f7c4a16afce07240ee94d5103d4f152bdac14e03f8d00164")
