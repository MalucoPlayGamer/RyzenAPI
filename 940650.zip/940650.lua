-- Lua provided by RyzenAPI
-- Game: Game: AppID 940650

-- MAIN APPLICATION
addappid(940650)
-- Game: addappid(940650)

-- MAIN APP DEPOTS / PACKAGES
addappid(940651, 1, "50b3f62fc200d5d2501e9e7c55b58df174b6351eaa0a158c73bd33283990b1c9")
