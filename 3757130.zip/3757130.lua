-- Lua provided by RyzenAPI
-- Game: Pinsky Protocol

-- MAIN APPLICATION
addappid(3757130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3757131, 1, "eddb3f21c587846bbbfecb1de52c5f2e98a437bcea035d59f80073d00491b3ff")

