-- Lua provided by RyzenAPI
-- Game: Heart and Core

-- MAIN APPLICATION
addappid(2533060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533061, 1, "cbc6abbc34d5a933e61b92799b76eb64a9561b3b3d6bb6c779f27789beb1cfaa")
