-- Lua provided by RyzenAPI
-- Game: EQQO

-- MAIN APPLICATION
addappid(2940170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2940171, 1, "89a3d441f4629b6400c9f9fb3c15c8eed0b24d4d5823d40def6c590f033fe64f")

