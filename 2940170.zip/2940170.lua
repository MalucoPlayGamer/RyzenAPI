-- Lua provided by RyzenAPI
-- Game: addappid(2940170)

-- MAIN APPLICATION
addappid(2940170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940171, 1, "89a3d441f4629b6400c9f9fb3c15c8eed0b24d4d5823d40def6c590f033fe64f")
