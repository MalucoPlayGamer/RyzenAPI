-- Lua provided by RyzenAPI
-- Game: Only Up: With Friends

-- MAIN APPLICATION
addappid(2522520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2522521, 1, "418adc137ef5fa3e9ba329b4be1c04db9e8c9e7f72cf9acc96b39c8f8b6c965f")

