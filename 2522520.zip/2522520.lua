-- Lua provided by RyzenAPI
-- Game: 2522520

-- MAIN APPLICATION
addappid(2522520)
-- Game: addappid(2522520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522521, 1, "418adc137ef5fa3e9ba329b4be1c04db9e8c9e7f72cf9acc96b39c8f8b6c965f")
