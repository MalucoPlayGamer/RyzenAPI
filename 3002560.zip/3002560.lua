-- Lua provided by RyzenAPI
-- Game: 3002560

-- MAIN APPLICATION
addappid(3002560)
-- Game: addappid(3002560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002561, 1, "a97bd7c3d7b4acffe437bd63209d6472cc345cf7e6ee7ac140c62931a68b3b45")
