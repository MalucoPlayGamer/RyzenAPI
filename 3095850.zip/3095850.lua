-- Lua provided by RyzenAPI
-- Game: Game: Diving Focus Demo

-- MAIN APPLICATION
addappid(3095850)
-- Game: addappid(3095850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095851, 1, "97050435534a9ce08eba4ade47fd225c29ef81667bbf0735471fdd64b1a5a8ea")
