-- Lua provided by RyzenAPI
-- Game: AppID 392780

-- MAIN APPLICATION
addappid(392780)

-- MAIN APP DEPOTS / PACKAGES
addappid(392781, 1, "baca0519f680689daea67a45046d095638b4dba8bfb673c4279bb4d24292e8bc")
