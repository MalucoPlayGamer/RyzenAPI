-- Lua provided by RyzenAPI
-- Game: AppID 392780

-- MAIN APPLICATION
addappid(392780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(392781, 1, "baca0519f680689daea67a45046d095638b4dba8bfb673c4279bb4d24292e8bc")

