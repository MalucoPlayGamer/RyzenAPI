-- Lua provided by RyzenAPI
-- Game: addappid(2196370)

-- MAIN APPLICATION
addappid(2196370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196371, 1, "7b0b0d650b2a4f25510ed0551ea135c0f06431d0bfd6ca375c8b670b6c325cca")
