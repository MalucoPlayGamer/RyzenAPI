-- Lua provided by SkyAPI 
-- Game: AppID 2196370
addappid(2196370)
addappid(2196371, 1, "7b0b0d650b2a4f25510ed0551ea135c0f06431d0bfd6ca375c8b670b6c325cca")
