-- Lua provided by RyzenAPI
-- Game: addappid(3594870)

-- MAIN APPLICATION
addappid(3594870)
addappid(3594871)

-- MAIN APP DEPOTS / PACKAGES
addappid(3594870,0,"46d96c21fdfbed8dfbc786e78552410f5a0c63a8339c65b2b5abc6e93ca00319")
