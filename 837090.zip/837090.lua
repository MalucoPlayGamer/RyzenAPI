-- Lua provided by RyzenAPI
-- Game: Chronicles of Mystery - The Tree of Life

-- MAIN APPLICATION
addappid(837090)

-- MAIN APP DEPOTS / PACKAGES
addappid(837091, 1, "5a122deadeaad10025aab300bcf75725b36e981b5a240233d1449456af0f6c41")
addappid(837092, 1, "b9bedd70ef297df21826beebcc0e8268ec04678b877084a1b4de8e52b5a215cd")
addappid(837093, 1, "d3124dc825fb592a53e944b01679be169a5dbb31228a6eeef333fa76e2eb541c")
addappid(837095, 1, "5eb86128788a37ef853ae712277ac578094cb040161e74f08400ec088833a05f")
addappid(837097, 1, "bb8c458c8c72193e53638a14c931f3da66d941ccca7349201c8e94015277f3bc")
