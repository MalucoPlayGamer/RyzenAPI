-- Lua provided by RyzenAPI
-- Game: AppID 485430

-- MAIN APPLICATION
addappid(485430)
-- Game: addappid(485430)

-- MAIN APP DEPOTS / PACKAGES
addappid(485431, 1, "6725a9cf87ab0231ed986a6905725c121e41568e7685aff9c59fc0f9e32ecdf1")
