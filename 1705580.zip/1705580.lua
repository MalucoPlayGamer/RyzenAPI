-- Lua provided by RyzenAPI
-- Game: SiNKR 3

-- MAIN APPLICATION
addappid(1705580)
-- Game: addappid(1705580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705581, 1, "d35099bc0cc5343cf2e83e55b6741a60cc92c0fc69b378667045236c51417c27")
