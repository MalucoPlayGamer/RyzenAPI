-- Lua provided by RyzenAPI
-- Game: AppID 1190820

-- MAIN APPLICATION
addappid(1190820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190821, 1, "52cef21dff4e0cee743ceceacff4c42a3b66d09b677f44e63bdb323427a37e55")

