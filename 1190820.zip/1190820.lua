-- Lua provided by RyzenAPI
-- Game: Booobjz

-- MAIN APPLICATION
addappid(1190820)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1190821, 1, "52cef21dff4e0cee743ceceacff4c42a3b66d09b677f44e63bdb323427a37e55")

