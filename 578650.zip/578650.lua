-- Lua provided by RyzenAPI
-- Game: The Outer Worlds

-- MAIN APPLICATION
addappid(578650)
addappid(1393110)
addappid(1393111)
addappid(1425450)
addappid(2170820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(578651, 1, "a877c80b32c589baa437c2ed817cf77259a5af3619a9159ea1316e9f98f6eda7")

