-- Lua provided by SkyAPI 
-- Game: AppID 578650
addappid(578650)
addappid(578651, 1, "a877c80b32c589baa437c2ed817cf77259a5af3619a9159ea1316e9f98f6eda7")
