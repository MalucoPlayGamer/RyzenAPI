-- Lua provided by SkyAPI 
-- Game: Pocket Stables
addappid(1918530)
addappid(1918531, 1, "d0ea855fdb121c5ee51eade6a05deda1bd15496df0a6787e312442aed09e8ad7")
