-- Lua provided by RyzenAPI
-- Game: 法利恩戰記2 (Furion Chronicles 2)

-- MAIN APPLICATION
addappid(1461060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461061, 1, "05f8c41640ec9b08d09f9a21f07d3388f22bf24ebf3a9dea601160600c3bc3ec")
