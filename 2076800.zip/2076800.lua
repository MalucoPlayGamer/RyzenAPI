-- Lua provided by RyzenAPI
-- Game: Han'yo

-- MAIN APPLICATION
addappid(2076800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076801, 1, "efbda137b2ed329a7f8b534bf665bcc062aee6afbd60725c207f1ae55daedec6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
