-- Lua provided by RyzenAPI
-- Game: addappid(2076800)

-- MAIN APPLICATION
addappid(2076800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076801, 1, "efbda137b2ed329a7f8b534bf665bcc062aee6afbd60725c207f1ae55daedec6")
