-- Lua provided by RyzenAPI
-- Game: Paradox Soul

-- MAIN APPLICATION
addappid(610570)

-- MAIN APP DEPOTS / PACKAGES
addappid(610571, 1, "e090cca9b8979c22db8ae6f778a5f9b44bf819fa259f3884ce6d37c3a6159d54")
