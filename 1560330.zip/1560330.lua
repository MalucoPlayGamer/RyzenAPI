-- Lua provided by RyzenAPI
-- Game: Utopos

-- MAIN APPLICATION
addappid(1560330)
-- Game: addappid(1560330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560331, 1, "89308b16363cf8c2abe4712bdbabd4b6c4ac4ba44fe5094ea08b918e89c0fc91")
addappid(1560332, 1, "6be05d398f0debe86750c8077a3e70c7e83270da12d8f16d17d973ff47cfc6e5")
addappid(1560333, 1, "e37973d5aff4f3696bfd2f6dfe17c0708a9db4a376bcf3171b25e3d135833794")
