-- Lua provided by RyzenAPI
-- Game: AppID 802090

-- MAIN APPLICATION
addappid(802090)
-- Game: addappid(802090)

-- MAIN APP DEPOTS / PACKAGES
addappid(802091, 1, "8c5735e807bc5a50236d9b15f4880d4466b6b4fab16f9c226c6d4a9ee5f8e57d")
