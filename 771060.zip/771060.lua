-- Lua provided by RyzenAPI
-- Game: Game: Iron League

-- MAIN APPLICATION
addappid(771060)
-- Game: addappid(771060)

-- MAIN APP DEPOTS / PACKAGES
addappid(771061, 1, "49b283050b2091c769f8eaa26fa71064385a295abd39994d5271696a16578db9")
