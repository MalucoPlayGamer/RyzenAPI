-- Lua provided by RyzenAPI
-- Game: addappid(204120)

-- MAIN APPLICATION
addappid(204120)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(204121, 1, "3930d10e712e9bc124037d8d0c04e6efacb2777ae10f88f81c7be20084a01786")
