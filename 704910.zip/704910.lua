-- Lua provided by SkyAPI 
-- Game: Tenta Shooter
addappid(704910)
addappid(704911, 1, "c8b27fa3b47460be1e62695898d1891841bf16a812dfae3a099c0441a979367f")
addappid(960180, 0, "c0e42662cfe24c5d941bac2588a2f08c76344d666d78d7fa888c08f6e2e6d83a")
