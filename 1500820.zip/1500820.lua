-- Lua provided by RyzenAPI
-- Game: Caravaneer 2

-- MAIN APPLICATION
addappid(1500820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500821, 1, "e9b519e8a400d28cd321a01c70108cfd7380ae3cb0e47ef1e35725a42d64bb22")

