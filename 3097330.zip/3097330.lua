-- Lua provided by RyzenAPI 
-- Game: ReMix
addappid(3097330)
addappid(3097331, 1, "d3684ca05278743c2c7af0542517a0e2bd68d152b3f1b4f2ba7c2e8178da80bd")
