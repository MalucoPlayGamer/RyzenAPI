-- Lua provided by RyzenAPI
-- Game: Sift Heads - Cartels 4

-- MAIN APPLICATION
addappid(1931380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931385,0,"5545e7e3ef123f56fd7e54c1387edf99ea9a430cef17e3f234eb2ca3c7d129a7")

