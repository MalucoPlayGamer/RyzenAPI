-- Lua provided by RyzenAPI
-- Game: Game: AppID 449510

-- MAIN APPLICATION
addappid(449510)
-- Game: addappid(449510)

-- MAIN APP DEPOTS / PACKAGES
addappid(449511, 1, "88e3e5c25925ebe37ab6f64ecfa3174cb2a59b11af93be5fa7f85cbeed54a002")
addappid(449512, 1, "b6a2312c4ab617bebea1763ea82699e76de51836af8dc6420dba2d4640ff307f")
addappid(449513, 1, "3877f1e9365950e24a948e517f44b6f7b3a1a377b0b7ce8155c5d3910e544b65")
addappid(585730, 0, "723130fcbf24a01a31472cbd6bdf8d6a8c0b830f228b539951ac99d183f4e6a1")
