-- Lua provided by RyzenAPI
-- Game: Game: AppID 939600

-- MAIN APPLICATION
addappid(939600)
-- Game: addappid(939600)

-- MAIN APP DEPOTS / PACKAGES
addappid(939601, 1, "f4e75465a188b0e55cede0b24e0f966acec908328158ba0bde0a631706ab95dc")
addappid(1122080, 0, "3b53bf735a5b70862d44d949ec1971197407a73fb046e1ca1b2e110f0bbb2e49")
addappid(1132060, 0, "d227ccb8b0a81fb853d20a60e3021460685db180fa638b87a1ff17d8d8c0dd8d")
