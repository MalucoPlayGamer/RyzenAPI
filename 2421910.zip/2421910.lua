-- Lua provided by RyzenAPI
-- Game: 2421910

-- MAIN APPLICATION
addappid(2421910)
-- Game: addappid(2421910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421912,0,"8d19462abb3f3b2fb941bb2ecf44ebe2e46a9f247e9ce0d358b370da64d60cf2")
