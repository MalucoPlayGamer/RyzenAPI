-- Lua provided by RyzenAPI
-- Game: RetroArch  - Flycast

-- MAIN APPLICATION
addappid(1222633)
-- Game: addappid(1222633)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222633,0,"d022b689d6cb6319ead684f218f909d6afa81747ac8fc50b7b082c5e463e5197")
addappid(1790150,0,"bd748839ff662dc825cca3eee8876abc25e5fa0a1a889af06d7cf81e04d44ffd")
addappid(1790151,0,"d540c98da504551bc44430b727e0e2565f55720f6ab0ed2cca55660445edab7f")
