-- Lua provided by RyzenAPI
-- Game: Eternity: The Last Unicorn

-- MAIN APPLICATION
addappid(714250)

-- MAIN APP DEPOTS / PACKAGES
addappid(714251, 1, "8243946b9bfbe0d36d4bb18b96790cb1ad680419ad73e4d0173e20aaf3fc34c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1037450)
addappid(1037451)
