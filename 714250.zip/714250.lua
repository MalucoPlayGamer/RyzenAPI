-- Lua provided by RyzenAPI
-- Game: 714250

-- MAIN APPLICATION
addappid(714250)
-- Game: addappid(714250)

-- MAIN APP DEPOTS / PACKAGES
addappid(714251, 1, "8243946b9bfbe0d36d4bb18b96790cb1ad680419ad73e4d0173e20aaf3fc34c7")
