-- Lua provided by RyzenAPI
-- Game: addappid(47540)

-- MAIN APPLICATION
addappid(47540)

-- MAIN APP DEPOTS / PACKAGES
addappid(47541, 1, "2d8cf93ad357bcc8473b50736ef700629b6556b4582e43889f94e29b387f577b")
