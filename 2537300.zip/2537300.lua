-- Lua provided by RyzenAPI
-- Game: addappid(2537300)

-- MAIN APPLICATION
addappid(2537300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537301, 1, "feb1e5b66e2df854e69f56c6cb349c677178739462fb62533f74bd2cfe058713")
