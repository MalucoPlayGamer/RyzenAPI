-- Lua provided by RyzenAPI
-- Game: Axial Disc 1

-- MAIN APPLICATION
addappid(1638430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638431, 1, "36fc00614cd1a920e89a8e74b0352c0c875e40be9d274e96c3c8eb648b63c924")

