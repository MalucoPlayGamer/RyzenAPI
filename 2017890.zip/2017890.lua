-- Lua provided by RyzenAPI
-- Game: 2017890

-- MAIN APPLICATION
addappid(2017890)
-- Game: addappid(2017890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017891, 1, "0b973c5f43a191a2924ffd80627dee92f6e0513a3185e4d779e18afe005dc755")
