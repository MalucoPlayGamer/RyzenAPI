-- Lua provided by RyzenAPI
-- Game: Haunt the House: Terrortown Soundtrack

-- MAIN APPLICATION
addappid(421940)

-- MAIN APP DEPOTS / PACKAGES
addappid(421941, 1, "a7f9775bf358fc38bad364a7de235913db694ebab25783a675de9d2ff22b9df0")
