-- Lua provided by RyzenAPI
-- Game: Game: AppID 306640

-- MAIN APPLICATION
addappid(306640)
-- Game: addappid(306640)

-- MAIN APP DEPOTS / PACKAGES
addappid(306641, 1, "fcf265f36fd15aaca4b9aeedfd0fa6748cdacb8981afe7384a1e691f74b74873")
addappid(306642, 1, "ac00ef23e470e4bc49586c0de7dcb26f47e11a64cefa8f92313229be7cde512c")
