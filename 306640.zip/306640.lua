-- Lua provided by RyzenAPI
-- Game: Battle Academy 2: Eastern Front

-- MAIN APPLICATION
addappid(306640)
addappid(345930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(306641, 1, "fcf265f36fd15aaca4b9aeedfd0fa6748cdacb8981afe7384a1e691f74b74873")
addappid(306642, 1, "ac00ef23e470e4bc49586c0de7dcb26f47e11a64cefa8f92313229be7cde512c")

