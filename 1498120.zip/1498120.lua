-- Lua provided by RyzenAPI
-- Game: Lewd Island

-- MAIN APPLICATION
addappid(1498120)
-- Game: addappid(1498120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498121, 1, "4b1fb40e9b9ab6cb4c500769f4497fee34fa66eb4570a914560228949733e058")
addappid(2230970, 0, "e0a08a843365c0a402a7470d88ad0a4ec886470b3e2641761fdefcb0baf0b672")
