-- Lua provided by RyzenAPI
-- Game: Perennial Order Demo

-- MAIN APPLICATION
addappid(2508660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508661, 1, "929405d57401c0b6d93c672492b2c258ff61411783843ffb87fd27b1301dc59d")
