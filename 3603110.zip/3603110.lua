-- Lua provided by RyzenAPI 
-- Game: Favela Kick: The Final Goal
addappid(3603110)
addappid(3603111, 1, "228008b72bf1f85409d463d647623150d07b3f56e9b352dc8ef7f6e38c9c69b1")
