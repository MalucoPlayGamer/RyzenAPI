-- Lua provided by RyzenAPI
-- Game: Question Mark

-- MAIN APPLICATION
addappid(2301150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301151,0,"6a304905beee46ba2ae40cbff65c32886088f1d44b70dc3cfbdc4e176c777a51")

