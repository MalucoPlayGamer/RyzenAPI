-- 4380750's Lua and Manifest Created by Hubcap Manifest
-- Emerald Flower
-- Created: August 05, 2026 at 06:23:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4380750) -- Emerald Flower
-- MAIN APP DEPOTS
addappid(4380751, 1, "8cea5881266ceebe200a974c25263179750779afec38382a464666378b5c309f") -- Depot 4380751
setManifestid(4380751, "5767477336777433813", 136305272)
addappid(4380752, 1, "e2402761bcb41e150f40ff9b19cb8f36f4823389d2c0ed32b2fbf507718ac107") -- Depot 4380752
setManifestid(4380752, "1577664280244859375", 166633657)