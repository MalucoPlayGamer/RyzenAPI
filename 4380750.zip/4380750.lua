-- Lua provided by RyzenAPI
-- Game: Emerald Flower

-- MAIN APPLICATION
addappid(4380750) -- Emerald Flower

-- MAIN APP DEPOTS / PACKAGES
addappid(4380751, 1, "8cea5881266ceebe200a974c25263179750779afec38382a464666378b5c309f") -- Depot 4380751
addappid(4380752, 1, "e2402761bcb41e150f40ff9b19cb8f36f4823389d2c0ed32b2fbf507718ac107") -- Depot 4380752

