-- Lua provided by RyzenAPI
-- Game: 2014710

-- MAIN APPLICATION
addappid(2014710)
-- Game: addappid(2014710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014711, 1, "e5ec165683245f94bdd5f52ccd7980febffddeadba8730d1ff46af1582cd444d")
