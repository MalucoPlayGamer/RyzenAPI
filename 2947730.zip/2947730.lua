-- Lua provided by RyzenAPI
-- Game: Game: 3D PUZZLE - Hospital 1

-- MAIN APPLICATION
addappid(2947730)
-- Game: addappid(2947730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947731, 1, "7a6533bab1bb9c4fe4e1ad140a307140885414f5500f3c49f80669e90174fb9e")
