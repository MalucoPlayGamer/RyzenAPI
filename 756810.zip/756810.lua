-- Lua provided by RyzenAPI
-- Game: M.A.X. 2: Mechanized Assault & Exploration

-- MAIN APPLICATION
addappid(756810)

-- MAIN APP DEPOTS / PACKAGES
addappid(756811, 1, "d55aaca66642ca30bdcbce10fbbb16ed5a2bca2ff3bd0bd2464228abf38c6722")
