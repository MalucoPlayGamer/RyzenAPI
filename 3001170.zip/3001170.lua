-- Lua provided by RyzenAPI
-- Game: DoomSurvivors Demo

-- MAIN APPLICATION
addappid(3001170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001171, 1, "cda3521ee3e7a7f35bfef669a0fc8724b63c36b973dc5ac1926bd5116dd14504")
