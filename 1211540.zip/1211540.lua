-- Lua provided by RyzenAPI
-- Game: Sokpop S06: bobo robot

-- MAIN APPLICATION
addappid(1211540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1211541, 1, "54e624708711745d45e4d2cfabff8d919868d278827f910530c609c747b195c4")
addappid(1211542, 1, "399ebbde3cc69d7f14a5d59b6fe0b21f06e0db813a08ab11ab67cad1efeed6cf")

