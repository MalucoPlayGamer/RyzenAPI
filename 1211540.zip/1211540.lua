-- Lua provided by SkyAPI 
-- Game: AppID 1211540
addappid(1211540)
addappid(1211541, 1, "54e624708711745d45e4d2cfabff8d919868d278827f910530c609c747b195c4")
addappid(1211542, 1, "399ebbde3cc69d7f14a5d59b6fe0b21f06e0db813a08ab11ab67cad1efeed6cf")
