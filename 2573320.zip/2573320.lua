-- Lua provided by RyzenAPI
-- Game: Beyond Hanwell Teaser: The Royal Hallamshire

-- MAIN APPLICATION
addappid(2573320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573321, 1, "bbb664a34546ab26eed89b99953da81d655214722e0eeaa4886d92ff83364654")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
