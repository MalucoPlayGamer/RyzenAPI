-- Lua provided by RyzenAPI
-- Game: Beyond Hanwell Teaser: The Royal Hallamshire

-- MAIN APPLICATION
addappid(2573320)
-- Game: addappid(2573320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573321, 1, "bbb664a34546ab26eed89b99953da81d655214722e0eeaa4886d92ff83364654")
