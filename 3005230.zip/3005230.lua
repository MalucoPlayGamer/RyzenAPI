-- Lua provided by RyzenAPI
-- Game: Game: AppID 3005230

-- MAIN APPLICATION
addappid(3005230)
-- Game: addappid(3005230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3005231, 1, "7b594e9a139c88c76bfc88a8b76c94da082011ac726f8174f478f23fe942d8a3")
