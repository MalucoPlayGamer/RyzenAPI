-- Lua provided by RyzenAPI
-- Game: 2593580

-- MAIN APPLICATION
addappid(2593580)
-- Game: addappid(2593580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593581, 1, "1b4f03273c7867fa66ebf3c0c5ce2a2973ea7bf5897a42194d8309233ae72609")
