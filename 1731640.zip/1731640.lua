-- Lua provided by RyzenAPI
-- Game: FUSER™ - The Proclaimers - "I'm Gonna Be (500 Miles)"

-- MAIN APPLICATION
addappid(1731640)
-- Game: addappid(1731640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731640,0,"7f0b942f2e9d721c2e5836632c5e0cb383c6f6d5c61aad043181bff2311a75c6")
