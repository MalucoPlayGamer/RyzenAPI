-- Lua provided by RyzenAPI
-- Game: addappid(1731640)

-- MAIN APPLICATION
addappid(1731640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731640,0,"7f0b942f2e9d721c2e5836632c5e0cb383c6f6d5c61aad043181bff2311a75c6")
