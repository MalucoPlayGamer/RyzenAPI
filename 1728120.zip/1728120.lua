-- Lua provided by RyzenAPI
-- Game: AppID 1728120

-- MAIN APPLICATION
addappid(1728120)
-- Game: addappid(1728120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728121, 1, "511dafac6f6d910201668446f5b82c074a186bca9f1e400768fff51df4e4b4db")
