-- Lua provided by RyzenAPI
-- Game: 2719240

-- MAIN APPLICATION
addappid(228990)
addappid(2719240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719244,0,"e4dc23c647c8b7ed574bf391b3cb58b21c0afe19916cd9938453f9e2ca70fdca")

