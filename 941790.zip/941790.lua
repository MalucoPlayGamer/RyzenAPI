-- Lua provided by RyzenAPI 
-- Game: AppID 941790
addappid(941790)
addappid(941791, 1, "99389e67e2a86eaf9c5e20e961b005117777c953bcef6b812d9e23418db86596")
