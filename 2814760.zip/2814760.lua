-- Lua provided by RyzenAPI
-- Game: Game: AppID 2814760

-- MAIN APPLICATION
addappid(2814760)
-- Game: addappid(2814760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814761, 1, "4cf5f171eadd4210c50206203d57bf04b9ab217bfa385c2c5f4fc079bf316827")
