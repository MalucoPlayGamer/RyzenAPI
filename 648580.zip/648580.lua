-- Lua provided by RyzenAPI
-- Game: AppID 648580

-- MAIN APPLICATION
addappid(648580)

-- MAIN APP DEPOTS / PACKAGES
addappid(648581, 1, "12e5d1c8e33a92c3c0c398b1eaa8fe9e046fe163b1bdbcea4265a5aaa191f455")
addappid(648583, 1, "8860d9a259ebb9b67fed967da42dd9d31be34c7373a8a123f2508389cfc9cf6d")
addappid(648584, 1, "07440d9678e65fd6940faf35ee4df1f73e225bd5323b6ff5677aa6a870bffd9e")
addappid(648585, 1, "c6fab8869f5bcd008c5effe390843d61ce947c1d528ce87ec1dc6096849ae60f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
