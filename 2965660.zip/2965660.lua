-- Lua provided by RyzenAPI
-- Game: PILGRIM

-- MAIN APPLICATION
addappid(2965660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2965661, 1, "f0915354709d3813ae653f8bd002cfb65030eda052000e004b678946d8060ce4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
