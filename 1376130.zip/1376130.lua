-- Lua provided by RyzenAPI
-- Game: Game: Marble Odyssey Demo

-- MAIN APPLICATION
addappid(1376130)
-- Game: addappid(1376130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376131, 1, "2c3203739892cb1b631513328eac8b511777a453c623caf293f0f72aaacb0a24")
