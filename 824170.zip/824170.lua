-- Lua provided by RyzenAPI
-- Game: Relic Raiders

-- MAIN APPLICATION
addappid(824170)

-- MAIN APP DEPOTS / PACKAGES
addappid(824171,0,"d3ce998ec33d5448dcaaac165973bae3bf62f7443d7a5044f1d3201496e2f5e6")

