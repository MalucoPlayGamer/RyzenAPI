-- Lua provided by RyzenAPI
-- Game: Japan Stigmatized Property3 -日本事故物件監視協会-

-- MAIN APPLICATION
addappid(4611990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4611991,0,"4ed9df1199a53ccc356b697ab4f76168f7b42c633e2a61778854ef4394ab53e6")

