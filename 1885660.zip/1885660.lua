-- Lua provided by RyzenAPI
-- Game: ManServant: Gay Visual Novel

-- MAIN APPLICATION
addappid(1885660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885661, 1, "8aa1a0fa1d5db5977e7f9fae84e89819df509aac678c34a144f84ff77b4e1b97")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2115370)
addappid(2115371)
