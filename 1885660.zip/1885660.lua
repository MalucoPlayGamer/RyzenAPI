-- Lua provided by RyzenAPI 
-- Game: ManServant: Gay Visual Novel
addappid(1885660)
addappid(1885661, 1, "8aa1a0fa1d5db5977e7f9fae84e89819df509aac678c34a144f84ff77b4e1b97")
