-- Lua provided by RyzenAPI
-- Game: 773500

-- MAIN APPLICATION
addappid(773500)
-- Game: addappid(773500)

-- MAIN APP DEPOTS / PACKAGES
addappid(773500,0,"0fb72a29c23cb8b58c2490577d2e7d8776c3a66f742ae2eac982bd313fa9ae5a")
