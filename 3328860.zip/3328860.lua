-- Lua provided by RyzenAPI
-- Game: Game: Colorfire Redux

-- MAIN APPLICATION
addappid(3328860)
-- Game: addappid(3328860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328861, 1, "fe5d6d9700e15a37af8529c78656e3c9f39f60db9bcbe499a1f8b6c334d90d0c")
