-- Lua provided by RyzenAPI
-- Game: AppID 312350

-- MAIN APPLICATION
addappid(312350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(312351, 1, "2f8ec280159319d6348d741ab3dc4188d311b6823794bd2fb7dbef443da79bb6")

