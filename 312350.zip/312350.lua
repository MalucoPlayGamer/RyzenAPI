-- Lua provided by RyzenAPI
-- Game: 312350

-- MAIN APPLICATION
addappid(312350)
-- Game: addappid(312350)

-- MAIN APP DEPOTS / PACKAGES
addappid(312351, 1, "2f8ec280159319d6348d741ab3dc4188d311b6823794bd2fb7dbef443da79bb6")
