-- Lua provided by RyzenAPI
-- Game: Game: Assassins vs Pirates

-- MAIN APPLICATION
addappid(425150)
-- Game: addappid(425150)

-- MAIN APP DEPOTS / PACKAGES
addappid(425151, 1, "9bc185190b6b7f1e152350135eebcfe56d50034722136858ba07e1aeb06aa3b1")
