-- Lua provided by RyzenAPI
-- Game: addappid(656180)

-- MAIN APPLICATION
addappid(656180)

-- MAIN APP DEPOTS / PACKAGES
addappid(656181, 1, "c4bbe663251a9a02e1891c7941d8b222b11fa48914688293f3ddb7a6dcaf007d")
