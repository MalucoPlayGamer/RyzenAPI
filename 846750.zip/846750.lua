-- Lua provided by RyzenAPI
-- Game: Catburglar

-- MAIN APPLICATION
addappid(846750)

-- MAIN APP DEPOTS / PACKAGES
addappid(846751,0,"f1ca13cd457bf09ee001f1b85955523e3c0103e8b3577c08b11f46d17e52757e")

