-- Lua provided by RyzenAPI
-- Game: AppID 960170

-- MAIN APPLICATION
addappid(960170)
-- Game: addappid(960170)

-- MAIN APP DEPOTS / PACKAGES
addappid(960171, 1, "3c5ce74d30cabd2719f1c02a20785834585116b6af6b6c8ca442bcbf2188c3dc")
addappid(960172, 1, "7dd37697da6de8f7366d7c8e5027d96576ff62c6857aceec24df52c34a2121b0")
