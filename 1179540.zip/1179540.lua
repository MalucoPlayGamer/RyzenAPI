-- Lua provided by RyzenAPI
-- Game: Game: AppID 1179540

-- MAIN APPLICATION
addappid(1179540)
-- Game: addappid(1179540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179541, 1, "235b727be2612eb39aa77b4e79372cf28597ee14f4b012a58a40a6c8528ab5b8")
