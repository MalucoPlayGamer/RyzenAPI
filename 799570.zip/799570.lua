-- Lua provided by RyzenAPI
-- Game: Angles

-- MAIN APPLICATION
addappid(799570)
-- Game: addappid(799570)

-- MAIN APP DEPOTS / PACKAGES
addappid(799571, 1, "9aaaae07714e70c1a29dd01003d8e47565a5ebb82932f19ac207b8e143aaf0e2")
