-- Lua provided by RyzenAPI
-- Game: Angles

-- MAIN APPLICATION
addappid(799570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(799571, 1, "9aaaae07714e70c1a29dd01003d8e47565a5ebb82932f19ac207b8e143aaf0e2")

