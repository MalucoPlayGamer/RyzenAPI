-- Lua provided by RyzenAPI 
-- Game: Mouselash
addappid(3210870)
addappid(3210871, 1, "3a9f271fc6a7615edfe6cac3c718b059b0aac14184aa7f63d5436e61db5dadd9")
