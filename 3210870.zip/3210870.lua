-- Lua provided by RyzenAPI
-- Game: 3210870

-- MAIN APPLICATION
addappid(3210870)
-- Game: addappid(3210870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210871, 1, "3a9f271fc6a7615edfe6cac3c718b059b0aac14184aa7f63d5436e61db5dadd9")
