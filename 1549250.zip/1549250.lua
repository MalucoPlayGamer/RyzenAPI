-- Lua provided by RyzenAPI
-- Game: UNDECEMBER: The Forge

-- MAIN APPLICATION
addappid(1549250)
-- Game: addappid(1549250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549251, 1, "7e230bfcb49098fbe0d250fb813ec962c07beec2d4c8f6bba1990b9566b97c26")
