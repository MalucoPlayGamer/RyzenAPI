-- Lua provided by RyzenAPI
-- Game: KABUKI FIRE

-- MAIN APPLICATION
addappid(3369200)
-- Game: addappid(3369200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369201, 1, "89f8a7eb2a2cd5df29e37a63ecc9b234bf25e9d4dd4afb5d1889fcd8915fc821")
