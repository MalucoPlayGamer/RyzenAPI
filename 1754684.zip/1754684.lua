-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Sophie's Costume "Comfy and Casual"

-- MAIN APPLICATION
addappid(1754684)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754684,0,"4c4249b7ae1cbad87da903e7b1094b9807fa78daec77ddbdf33e630c4d119478")
addtoken(1754684,"12796335806120162501")
