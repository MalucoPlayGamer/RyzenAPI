-- Lua provided by RyzenAPI
-- Game: Necesse Dedicated Server

-- MAIN APPLICATION
addappid(1169370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
addappid(1169372,0,"af24d587afa3ce18770a736acf26dc2a909f59f798297426bb44b2daf4d6f671")
addappid(1169373,0,"2f173e48364362772f3e67c2617da9477563b80b2d6269686c1d70e8b4b95842")
addappid(1169374,0,"4eec9f55c4aa08f07680fd4f5cc07b7fa47744750c4a8abaff81817cf39dfbea")
addappid(1169375,0,"d080867e59f70208d59c4979a4bdfd5abeb571e98c496b5dafe5ac10c058bcd7")

