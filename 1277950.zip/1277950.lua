-- Lua provided by RyzenAPI
-- Game: Heart's Medicine - Season One

-- MAIN APPLICATION
addappid(1277950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277951, 1, "78d9a06b328c3591759325838b0c6d7d6f0a6ad97dbb21a69363bc844867ba7c")

