-- Lua provided by RyzenAPI
-- Game: Catnight

-- MAIN APPLICATION
addappid(1779070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779073,0,"568efc9d8d0b61f17c1a2f08008eb2d82460de78bb629eab6a53c7963618aad2")
