-- Lua provided by RyzenAPI
-- Game: Catnight

-- MAIN APPLICATION
addappid(1779070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779073,0,"568efc9d8d0b61f17c1a2f08008eb2d82460de78bb629eab6a53c7963618aad2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
