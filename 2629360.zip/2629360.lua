-- Lua provided by RyzenAPI
-- Game: FreeJack Online Playtest

-- MAIN APPLICATION
addappid(2629360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629361, 1, "e8181136a0897e0ba5cd6bd89ad6a705cc833b5db49076f6ff57ebd901491506")

