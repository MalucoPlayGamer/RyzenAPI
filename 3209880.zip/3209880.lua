-- Lua provided by RyzenAPI
-- Game: Game: AppID 3209880

-- MAIN APPLICATION
addappid(3209880)
-- Game: addappid(3209880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209881, 1, "ebceb716640b1e382b9262be97be72c2b84824d4048750464f0d7964e096cb37")
