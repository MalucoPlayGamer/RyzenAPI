-- Lua provided by RyzenAPI
-- Game: AppID 3134200

-- MAIN APPLICATION
addappid(3134200)
-- Game: addappid(3134200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134201, 1, "03742ecd4a56f05e6e48f2649d266465dd5cae829805ef7dda5ce3280fc18981")
