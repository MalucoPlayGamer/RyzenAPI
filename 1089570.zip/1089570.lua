-- Lua provided by RyzenAPI
-- Game: addappid(1089570)

-- MAIN APPLICATION
addappid(1089570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089571, 1, "8f9a72db2ce5c805a60912da9be2015a2d2f895f2194c353e7dea9dc2bb61a4a")
