-- Lua provided by SkyAPI 
-- Game: KAKUDO - Original Game Soundtrack
addappid(2064170)
addappid(2064171, 1, "6a3e9e6050175e5707a1ddfcf6d70a45898baf2696343cc11b8392d93b512ca5")
addappid(2064172, 1, "54f682e327df38ee01b55963469d9b6fee8539d5582a26a7c292cf2e6e0c0051")
