-- Lua provided by RyzenAPI
-- Game: AppID 778600

-- MAIN APPLICATION
addappid(778600)

-- MAIN APP DEPOTS / PACKAGES
addappid(778601, 1, "c7f5ee8fde22b93589a1b38284681280265221b9d72d41c6eaab65b5427c46b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
