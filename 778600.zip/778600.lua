-- Lua provided by RyzenAPI
-- Game: AppID 778600

-- MAIN APPLICATION
addappid(778600)
-- Game: addappid(778600)

-- MAIN APP DEPOTS / PACKAGES
addappid(778601, 1, "c7f5ee8fde22b93589a1b38284681280265221b9d72d41c6eaab65b5427c46b1")
