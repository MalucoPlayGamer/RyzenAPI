-- Lua provided by RyzenAPI
-- Game: Fast Royal

-- MAIN APPLICATION
addappid(2088400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088401, 1, "755750c6f420813d62d6ce3b4035eb1643c235c70c4e386f1cbb0f7941bee39b")

