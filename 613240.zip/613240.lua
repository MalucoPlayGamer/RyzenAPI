-- Lua provided by RyzenAPI
-- Game: Stonekeep

-- MAIN APPLICATION
addappid(613240)
-- Game: addappid(613240)

-- MAIN APP DEPOTS / PACKAGES
addappid(613241, 1, "1462a25912f20b04c027cb6180bb7b3bd893d4f9f622c0af592d1a3e18edcc2a")
addappid(613242, 1, "9ad1b02a73ecd4abc827a33ecdc68ff868dfb223aee1209eab28010ec99a84de")
addappid(613243, 1, "5b93680f869ab4cc2683148bf7c9f788e6ac816c8646559a4bab8cf9a80fcdbf")
