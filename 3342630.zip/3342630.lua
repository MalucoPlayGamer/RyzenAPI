-- Lua provided by RyzenAPI
-- Game: Escape From Sandhill

-- MAIN APPLICATION
addappid(3342630)
-- Game: addappid(3342630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342631, 1, "a5eae055aa97751768570dbe840833287e0f96d33f90795a8645610648b74f0f")
