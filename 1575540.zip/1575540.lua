-- Lua provided by RyzenAPI
-- Game: Symbiotic Love - Yuri Visual Novel

-- MAIN APPLICATION
addappid(1575540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575541, 1, "7403f1e4d937b0cde3a2a044f588ef3246732f0032688f4450dd69f027d04e11")

