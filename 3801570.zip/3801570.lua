-- Lua provided by RyzenAPI
-- Game: Knight vs Monsters

-- MAIN APPLICATION
addappid(3801570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3801571, 1, "461756b1af33ef50c8a228514246b06b2869f23c4eaebfa3b37f9f30e610f9cf")

