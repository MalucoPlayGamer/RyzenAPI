-- Lua provided by RyzenAPI
-- Game: Game: Knight vs Monsters

-- MAIN APPLICATION
addappid(3801570)
-- Game: addappid(3801570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3801571, 1, "461756b1af33ef50c8a228514246b06b2869f23c4eaebfa3b37f9f30e610f9cf")
