-- Lua provided by RyzenAPI
-- Game: Game: Black River

-- MAIN APPLICATION
addappid(585090)
-- Game: addappid(585090)

-- MAIN APP DEPOTS / PACKAGES
addappid(585091, 1, "2c4778cea28004edde256a42959b22e1d130bec61339c1bd71042eaa048262aa")
