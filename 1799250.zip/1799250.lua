-- Lua provided by RyzenAPI
-- Game: Monster girl Capture mainland

-- MAIN APPLICATION
addappid(1799250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799250,0,"667167655303e8256412f08905b1afb96cfbfe6bf9c63171944a570d5fca8cc5")
