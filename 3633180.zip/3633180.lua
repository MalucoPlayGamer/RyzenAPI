-- Lua provided by RyzenAPI
-- Game: Undead Horde: Dark Conqueror

-- MAIN APPLICATION
addappid(3633180)
-- Game: addappid(3633180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3633181, 1, "c131906faeb327c72bb2ad71d94102d05c56bf1aa8ce61cee350337bbad66763")
