-- Lua provided by RyzenAPI
-- Game: Paws Coven

-- MAIN APPLICATION
addappid(4238920)

-- MAIN APP DEPOTS / PACKAGES
addappid(4238921,0,"d966f5dbd2f94f2cf8bf3417f8c3ac50e63c55be1d89528eb3e0c6de60ce5f47")

