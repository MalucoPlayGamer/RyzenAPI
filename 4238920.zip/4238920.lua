-- Lua provided by RyzenAPI
-- Game: Paws Coven

-- MAIN APPLICATION
addappid(4238920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4238921,0,"d966f5dbd2f94f2cf8bf3417f8c3ac50e63c55be1d89528eb3e0c6de60ce5f47")

