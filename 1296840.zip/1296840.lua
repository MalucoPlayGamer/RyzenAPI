-- Lua provided by RyzenAPI
-- Game: addappid(1296840)

-- MAIN APPLICATION
addappid(1296840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296841, 1, "951bbca6978bbe98f82d9b7aab29895631f468a4936742edffa26fd506d28834")
