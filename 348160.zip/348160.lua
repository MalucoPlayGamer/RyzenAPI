-- Lua provided by RyzenAPI
-- Game: Game: RUMP! - It's a Jump and Rump!

-- MAIN APPLICATION
addappid(348160)
-- Game: addappid(348160)

-- MAIN APP DEPOTS / PACKAGES
addappid(348161, 1, "8269992929378edb1230425822369c96537f1a5439665f0616b558452529af46")
