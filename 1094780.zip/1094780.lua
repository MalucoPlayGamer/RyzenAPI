-- Lua provided by SkyAPI 
-- Game: AppID 1094780
addappid(1094780)
addappid(1094781, 1, "4bb3628dc1eb56e6e42becfe2801675a4102c378dcf1941b150fd58c9bb84bd9")
