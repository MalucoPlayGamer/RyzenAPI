-- Lua provided by RyzenAPI
-- Game: Fisher Online

-- MAIN APPLICATION
addappid(1094780)
addappid(1420500)
addappid(1632740)
addappid(2320970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094780,0,"a602e7add7705c1ccd13fddf271696bd872eb5bd8eb2ab4cff20ccdbb0b867eb")
addappid(1094781,0,"4bb3628dc1eb56e6e42becfe2801675a4102c378dcf1941b150fd58c9bb84bd9")

