-- Lua provided by RyzenAPI
-- Game: 603120

-- MAIN APPLICATION
addappid(603120)
-- Game: addappid(603120)

-- MAIN APP DEPOTS / PACKAGES
addappid(603121, 1, "fa769532c4a9d00bae0c0767ba04b9fc876314606e1d1dca1831e09963cab845")
