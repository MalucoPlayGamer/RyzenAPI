-- Lua provided by SkyAPI 
-- Game: Happy Campers
addappid(603120)
addappid(603121, 1, "fa769532c4a9d00bae0c0767ba04b9fc876314606e1d1dca1831e09963cab845")
