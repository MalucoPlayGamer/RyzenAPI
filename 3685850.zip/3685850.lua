-- Lua provided by RyzenAPI
-- Game: addappid(3685850)

-- MAIN APPLICATION
addappid(3685850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3685851, 1, "849e78b1b62d858ccd08132f32c0f3d9ec59a5bea0596b86351aaf301b4327f8")
