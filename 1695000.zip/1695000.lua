-- Lua provided by RyzenAPI
-- Game: Rainbow Sea

-- MAIN APPLICATION
addappid(1695000)
-- Game: addappid(1695000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695003,0,"a6893d675b6bdfa78c864f5b7c68f0fb4bab74895183e2afe8ad2a6212901540")
