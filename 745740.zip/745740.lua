-- Lua provided by RyzenAPI
-- Game: Reflex

-- MAIN APPLICATION
addappid(745740)

-- MAIN APP DEPOTS / PACKAGES
addappid(745741, 1, "41e4e5c04fdb6fe8b2d641d8c743d5fecfa2ac49f00fc4426cf65686a1cc3d7a")

