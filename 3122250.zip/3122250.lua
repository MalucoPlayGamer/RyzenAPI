-- Lua provided by RyzenAPI
-- Game: 9 Kings Demo

-- MAIN APPLICATION
addappid(3122250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122251, 1, "a00fb06e481d2763ed688df8aca5fa0578d3e5ccce658c6094ab1e6272f93504")
