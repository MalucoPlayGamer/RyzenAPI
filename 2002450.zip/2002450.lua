-- Lua provided by RyzenAPI
-- Game: 停留此刻 Stay in the moment

-- MAIN APPLICATION
addappid(2002450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002451, 1, "e0e607a2e39b48a6823293ae4c78692bbcc7414432ebf791e25a66458bccdfeb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
