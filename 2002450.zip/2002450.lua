-- Lua provided by RyzenAPI
-- Game: 2002450

-- MAIN APPLICATION
addappid(2002450)
-- Game: addappid(2002450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002451, 1, "e0e607a2e39b48a6823293ae4c78692bbcc7414432ebf791e25a66458bccdfeb")
