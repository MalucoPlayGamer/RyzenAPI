-- Lua provided by RyzenAPI
-- Game: Geo

-- MAIN APPLICATION
addappid(513480)
addappid(566010)

-- MAIN APP DEPOTS / PACKAGES
addappid(513481, 1, "19d225c79447c7db77493dd3014d961b5a970fd2ede2bea67d980f7a2459f5b6")

