-- Lua provided by RyzenAPI
-- Game: Soul at Stake Test Server

-- MAIN APPLICATION
addappid(884600)

-- MAIN APP DEPOTS / PACKAGES
addappid(884601, 1, "0c8b21c044474c0138a4c316598a365d1bae4f29e078c2071012995d898db4b6")

