-- Lua provided by RyzenAPI
-- Game: Dodge This!

-- MAIN APPLICATION
addappid(1032260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1032261, 1, "4e6ee511988a359835dd461abc16e2b2e598b048b84ffd76b6869f38b31ba514")

