-- Lua provided by RyzenAPI
-- Game: 1032260

-- MAIN APPLICATION
addappid(1032260)
-- Game: addappid(1032260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032261, 1, "4e6ee511988a359835dd461abc16e2b2e598b048b84ffd76b6869f38b31ba514")
