-- Lua provided by RyzenAPI
-- Game: addappid(831540)

-- MAIN APPLICATION
addappid(831540)

-- MAIN APP DEPOTS / PACKAGES
addappid(831541, 1, "348bdd7a3c24965890acc0f038dc38e86728322867d8e1fcafab92a9acd8579c")
