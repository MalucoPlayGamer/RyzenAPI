-- Lua provided by SkyAPI 
-- Game: Mini Mecum
addappid(1965840)
addappid(1965841, 1, "9e21fdf4bec1142bbeb37c873391cb9e631c91a208c4db547450b1827df71470")
