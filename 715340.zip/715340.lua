-- Lua provided by RyzenAPI
-- Game: Sticks

-- MAIN APPLICATION
addappid(715340)

-- MAIN APP DEPOTS / PACKAGES
addappid(715341, 1, "de110bfbcdc690d86615a557ce602e0707da73a7e29813ad6f3b9fa0d604ba2c")
