-- Lua provided by RyzenAPI
-- Game: AppID 1239080

-- MAIN APPLICATION
addappid(1239080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1239081, 1, "fdc10940105c7507be41605c7c23f22212b60ef06404fe78a42a87827baa704e")
addappid(1239082, 1, "42f890eeeb4f8437c6b77d8ec5c1456d2c29c69c5160257351264ed8e968e4bb")

