-- Lua provided by RyzenAPI
-- Game: The Waters Above: Prelude

-- MAIN APPLICATION
addappid(885650)

-- MAIN APP DEPOTS / PACKAGES
addappid(885651, 1, "c4ab74d615c61f3d848c7dc8a956bf169fcd3263d2eb733ac08b1c93b2bf4656")
addappid(885652, 1, "4f43ec08133bd58995585669049adc2aa1971f0b41e7e4b1f955a8592f4c45e2")
addappid(885653, 1, "5f3fb29fc5ebeebd8888c232459f6032ef655b609506f75e45fc867e61cdfd19")
