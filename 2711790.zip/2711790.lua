-- Lua provided by RyzenAPI
-- Game: 2711790

-- MAIN APPLICATION
addappid(2711790)
-- Game: addappid(2711790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711790,0,"ba6f85c9192f1f69c1483a55904906400e7ffa476c2af208bacf2e8079c661e9")
