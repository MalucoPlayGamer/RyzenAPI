-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Another World Hero Generator 2 for MZ

-- MAIN APPLICATION
addappid(2711790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711790,0,"ba6f85c9192f1f69c1483a55904906400e7ffa476c2af208bacf2e8079c661e9")
