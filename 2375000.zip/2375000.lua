-- Lua provided by RyzenAPI
-- Game: Sun Haven Soundtrack Vol. 2

-- MAIN APPLICATION
addappid(2375000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375001, 1, "9e35d8896c45172937a1b2ffe2f95285b7be1a250c0e89ce0d9bdcf4cca754d5")

