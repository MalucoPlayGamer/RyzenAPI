-- Lua provided by RyzenAPI
-- Game: 1122203

-- MAIN APPLICATION
addappid(1122203)
-- Game: addappid(1122203)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122203,0,"cdf59efafb21be6044a7445964a50138f9aa97e3e966c22eb568b2f529ad2708")
