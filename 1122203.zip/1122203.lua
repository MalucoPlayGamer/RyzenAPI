-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - St. Tropez

-- MAIN APPLICATION
addappid(1122203)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122203,0,"cdf59efafb21be6044a7445964a50138f9aa97e3e966c22eb568b2f529ad2708")
