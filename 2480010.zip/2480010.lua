-- Lua provided by RyzenAPI
-- Game: Sugar Mess - Let's Play Jolly Battle

-- MAIN APPLICATION
addappid(2480010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2480011, 1, "8001ed20378e406b8b118e5b5be4e50d8b7f8204c3589cbda2a754e5082c45b3")

