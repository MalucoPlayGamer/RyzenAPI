-- Lua provided by RyzenAPI
-- Game: 2707170

-- MAIN APPLICATION
addappid(2707170)
-- Game: addappid(2707170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707171, 1, "f7c9139d6c433c086b2ea1415cb4969a168be760273e1ac9f558cb90973f41bf")
