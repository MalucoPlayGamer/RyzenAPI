-- Lua provided by SkyAPI 
-- Game: Jujutsu Kaisen Cursed Clash DEMO
addappid(2707170)
addappid(2707171, 1, "f7c9139d6c433c086b2ea1415cb4969a168be760273e1ac9f558cb90973f41bf")
