-- Lua provided by RyzenAPI
-- Game: Necrolepsy

-- MAIN APPLICATION
addappid(985590)
-- Game: addappid(985590)

-- MAIN APP DEPOTS / PACKAGES
addappid(985591, 1, "e213309645a231c323665c5173139e448dd866ca1b808b93794e35a75d52676f")
