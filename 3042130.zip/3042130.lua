-- Lua provided by RyzenAPI
-- Game: 3042130

-- MAIN APPLICATION
addappid(3042130)
-- Game: addappid(3042130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042131, 1, "f673188308b01674dd4dd2d465433eacd8c24dc102447cbb82fcb258f43427e5")
