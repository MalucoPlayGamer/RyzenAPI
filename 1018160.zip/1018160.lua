-- Lua provided by RyzenAPI
-- Game: MXGP 2019 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(1018160)
addappid(1089730)
addappid(1089740)
-- Game: addappid(1018160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018161, 1, "2995102927266c11f32a81867e602c57d1ab4c1b0f4a253c07a7ded6857987c8")
