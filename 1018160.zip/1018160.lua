-- Lua provided by RyzenAPI
-- Game: MXGP 2019 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(1018160)
addappid(1089730)
addappid(1089740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018161, 1, "2995102927266c11f32a81867e602c57d1ab4c1b0f4a253c07a7ded6857987c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
