-- Lua provided by RyzenAPI
-- Game: Birthdays the Beginning / バースデイズ・ザ・ビギニング - Avatar Ornament Set / 紛れ込みアバター君

-- MAIN APPLICATION
addappid(610040)

-- MAIN APP DEPOTS / PACKAGES
addappid(610040,0,"7b1692822ca7d95838b366949af1c7be1aaa30a6c9c021d55f77ae73b8a0b396")

