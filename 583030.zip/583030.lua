-- Lua provided by RyzenAPI
-- Game: addappid(583030)

-- MAIN APPLICATION
addappid(583030)

-- MAIN APP DEPOTS / PACKAGES
addappid(583031, 1, "9e326d6aae0f960b14ccc36ced84bc06c0d7a149c97a6471ab3da01fc80cf2bc")
