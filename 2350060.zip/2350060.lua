-- Lua provided by RyzenAPI
-- Game: Game: AppID 2350060

-- MAIN APPLICATION
addappid(2350060)
-- Game: addappid(2350060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350061, 1, "d720373d678af3af26972ada3ed3a53016fd770c8c2fcf85267e7853437b7272")
