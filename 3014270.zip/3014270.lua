-- Lua provided by RyzenAPI
-- Game: Game: Fuga: Melodies of Steel Little Tail Bronx Archives

-- MAIN APPLICATION
addappid(3014270)
-- Game: addappid(3014270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014271, 1, "90b556508f8cf87b02f190277041d8088749413170513ea21a3466f73754a7c7")
