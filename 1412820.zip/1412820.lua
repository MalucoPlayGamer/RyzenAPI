-- Lua provided by RyzenAPI
-- Game: Grimace Run

-- MAIN APPLICATION
addappid(1412820)
-- Game: addappid(1412820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412821, 1, "6cc387b419a62213c8e4d3ea68b491976474c31c87b2652bd4c4e93325fb4de1")
