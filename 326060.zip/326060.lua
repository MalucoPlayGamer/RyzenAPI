-- Lua provided by RyzenAPI
-- Game: Game: Starlight Drifter

-- MAIN APPLICATION
addappid(326060)
-- Game: addappid(326060)

-- MAIN APP DEPOTS / PACKAGES
addappid(326061, 1, "d5aa59012d47215cdd1d3c8cbced9e23ea5619624ee3c9ee1b8a061aaa19c647")
addappid(390480, 0, "e986d441791921f9f79711d7f39ba40cd917a31af1fccf27c224dde5f6208d49")
addappid(455170, 0, "4596e408a47608fc4331b7db956734b45a778b02a18ff4ffc696acf121a2646c")
