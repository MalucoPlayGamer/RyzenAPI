-- Lua provided by RyzenAPI
-- Game: AppID 318620

-- MAIN APPLICATION
addappid(318620)
-- Game: addappid(318620)

-- MAIN APP DEPOTS / PACKAGES
addappid(318621, 1, "1843f3f2f79e211043bcb8b1fc1561ee9ec9f191df952fd68f55eb1d9349fb5b")
