-- Lua provided by RyzenAPI
-- Game: addappid(675910)

-- MAIN APPLICATION
addappid(675910)

-- MAIN APP DEPOTS / PACKAGES
addappid(675911, 1, "66183d41b328ada6d7b07940fc5206a66df44b30a07f63f3c25719eb7158d155")
