-- Lua provided by RyzenAPI
-- Game: Cyanide & Happiness - Freakpocalypse (Episode 1)

-- MAIN APPLICATION
addappid(869880)

-- MAIN APP DEPOTS / PACKAGES
addappid(869881, 1, "99a25066986c62e044971b607099c706f771068140691fffa7314056659d851d")
addappid(869882, 1, "a8f30cadd759cc672fbed516cb7d750e30b43b54a043345f73700b1e7bb08371")
addappid(869883, 1, "393a1489284d6b34cc52154ff1a8435668719d7d1925b5d4acda7ebe30b61d70")
