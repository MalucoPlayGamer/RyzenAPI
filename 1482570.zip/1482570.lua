-- Lua provided by RyzenAPI
-- Game: addappid(1482570)

-- MAIN APPLICATION
addappid(1482570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482571, 1, "91f561175b2f487ac894952ab8ed6342997f799c20e7e46fdb972c30b96b9ca8")
