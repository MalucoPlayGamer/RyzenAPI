-- Lua provided by RyzenAPI
-- Game: Sofie: The Echoes™

-- MAIN APPLICATION
addappid(2946320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946321, 1, "d55aa9bc4ab6903f7b972d58d645794b84a92f262abc32d6987eb0d07896509b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
