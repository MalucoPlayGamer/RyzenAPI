-- Lua provided by RyzenAPI
-- Game: Sofie: The Echoes™

-- MAIN APPLICATION
addappid(2946320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946321, 1, "d55aa9bc4ab6903f7b972d58d645794b84a92f262abc32d6987eb0d07896509b")
