-- Lua provided by RyzenAPI
-- Game: Game: Pogo Rogue

-- MAIN APPLICATION
addappid(2870280)
-- Game: addappid(2870280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870281, 1, "b4e8e79b3a627b465842e316709def551b08b8ccaea553d0feb3600e861c25b6")
addappid(2870282, 1, "d50f82af1747b2c3e269bd2ea00fe7f0d9356278ff1adc0fe2bdcfa7c226f174")
