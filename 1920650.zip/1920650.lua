-- Lua provided by RyzenAPI 
-- Game: Contrablade: Stadium Rush
addappid(1920650)
addappid(1920651, 1, "6431ad685e5905f8648d639b6a5caacacb08ed7a604a5f7e3cb6ad61be596b0a")
