-- Lua provided by RyzenAPI
-- Game: addappid(1920650)

-- MAIN APPLICATION
addappid(1920650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920651, 1, "6431ad685e5905f8648d639b6a5caacacb08ed7a604a5f7e3cb6ad61be596b0a")
