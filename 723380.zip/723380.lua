-- Lua provided by RyzenAPI
-- Game: Wraith

-- MAIN APPLICATION
addappid(723380)

-- MAIN APP DEPOTS / PACKAGES
addappid(723381,0,"3afa163df121e215ecb5f8dcb73c7e79bf2a27904934aa2087eab11e198e325b")

