-- Lua provided by RyzenAPI
-- Game: Pirates of the Asteroid Belt

-- MAIN APPLICATION
addappid(1550950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1550951, 1, "55a8fccd60cf6d66af6828638d1c2599fc94cf4dbcbd3a5fa920e974a9a17053")

