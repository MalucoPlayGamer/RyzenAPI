-- Lua provided by RyzenAPI
-- Game: Pirates of the Asteroid Belt

-- MAIN APPLICATION
addappid(1550950)
-- Game: addappid(1550950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550951, 1, "55a8fccd60cf6d66af6828638d1c2599fc94cf4dbcbd3a5fa920e974a9a17053")
