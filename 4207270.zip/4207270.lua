-- Lua provided by RyzenAPI
-- Game: Survivors: Island Adventure

-- MAIN APPLICATION
addappid(4207270)

