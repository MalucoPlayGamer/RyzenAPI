-- Lua provided by RyzenAPI
-- Game: Game: Telltale Texas Hold ‘Em

-- MAIN APPLICATION
addappid(8330)
-- Game: addappid(8330)

-- MAIN APP DEPOTS / PACKAGES
addappid(8331, 1, "b69134616c78495af3fe8058603b2ebc2a20d77edaae7334c7c3c863680ea028")
