-- Lua provided by RyzenAPI
-- Game: Dream Girls Collection

-- MAIN APPLICATION
addappid(1722770)
addappid(1726230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722771, 1, "63024aad8d16be25f704795814e8158f933f4c2df367aa7a28dc57cb1de0cd03")

