-- Lua provided by RyzenAPI
-- Game: AppID 1722770

-- MAIN APPLICATION
addappid(1722770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722771, 1, "63024aad8d16be25f704795814e8158f933f4c2df367aa7a28dc57cb1de0cd03")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1726230)
