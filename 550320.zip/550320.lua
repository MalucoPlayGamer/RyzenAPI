-- Lua provided by RyzenAPI
-- Game: art of rally

-- MAIN APPLICATION
addappid(550320)
addappid(2250420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(550321, 1, "1adbb6079be99d7bbfa2bb6b8c2c7e446527b5fe5d4595c60bc1827778184715")
addappid(550322, 1, "b717a52a646b68cc50f02c06b3b4a5a2d0105de315d2bc614e98f88d1e6ca85d")
addappid(550323, 1, "37c2957c38798570700f82893fb8769997be89f6c03368e95d70f2029c97033f")
addappid(1421640, 0, "05b2b8e62573a1dfbccc75328d6fa8c5cb53f5fe9b11ba227f1425a5ee6d2a2d")

