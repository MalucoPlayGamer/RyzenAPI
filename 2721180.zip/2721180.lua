-- Lua provided by RyzenAPI
-- Game: Hardcore!!! MILF Sex party

-- MAIN APPLICATION
addappid(2721180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721181, 1, "7c6481ec5dc04bb59e85e0197368413086e84616590f779d7296ea350e3d9d48")

