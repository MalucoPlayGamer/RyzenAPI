-- Lua provided by RyzenAPI 
-- Game: Two Legs
addappid(1564950)
addappid(1564951, 1, "727ccdc1bc3ca2bb7ae07a4ce07b8d52b29734ceec815c32b8a8c6c6541f616b")
