-- Lua provided by RyzenAPI
-- Game: 388160

-- MAIN APPLICATION
addappid(388160)
-- Game: addappid(388160)

-- MAIN APP DEPOTS / PACKAGES
addappid(388161, 1, "b7d36ed10d1cf2c7da92dfdf2dccf7c46e0e6e8acaca49424b7e513c4b7c5f3a")
