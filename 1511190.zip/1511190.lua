-- Lua provided by RyzenAPI
-- Game: Super Toy Cars Offroad

-- MAIN APPLICATION
addappid(1511190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511191, 1, "06c4cb6629d53e7f8c40eb3d899bb680ca5692041193bb03b43c367bc3065560")
