-- Lua provided by RyzenAPI
-- Game: LOOPERS

-- MAIN APPLICATION
addappid(1811500)
-- Game: addappid(1811500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811501, 1, "0d09ba15e0345b7f8c05ca7f8f82e9960ac0cfc62cd74e3206b266a998d38291")
