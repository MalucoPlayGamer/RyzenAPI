-- Lua provided by RyzenAPI
-- Game: AppID 721940

-- MAIN APPLICATION
addappid(721940)
-- Game: addappid(721940)

-- MAIN APP DEPOTS / PACKAGES
addappid(721941, 1, "e5e89158a2d12c9bdae926f1ac51a44e83d120ae23259186eebe0694fa5d7d5b")
