-- Lua provided by RyzenAPI
-- Game: Money Simulator Demo

-- MAIN APPLICATION
addappid(3009520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009521, 1, "57839474da56af3093c8de536583b2bc8f552d41f98dca37c9e584f07a3b8c74")
