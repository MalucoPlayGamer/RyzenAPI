-- Lua provided by SkyAPI 
-- Game: AppID 3009520
addappid(3009520)
addappid(3009521, 1, "57839474da56af3093c8de536583b2bc8f552d41f98dca37c9e584f07a3b8c74")
