-- Lua provided by RyzenAPI
-- Game: Streetoir

-- MAIN APPLICATION
addappid(2639980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639981, 1, "c65753b357d9dd047c8cf613660d55c1a11a614ad0093e758ec9d6c519338ff0")

