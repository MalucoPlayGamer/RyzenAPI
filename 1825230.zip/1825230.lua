-- Lua provided by RyzenAPI
-- Game: Come Home - Mari Clothing Expansion

-- MAIN APPLICATION
addappid(1825230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825231, 1, "8e30bfe6721ffed59b8fffba26a1126a93278abe94eda006f0ca8e8386813237")

