-- Lua provided by SkyAPI 
-- Game: AppID 1295210
addappid(1295210)
addappid(1295211, 1, "8856374cc75c58d787c7e1db9f68a638bae4287aa6e58c954b36e3b984bcc0c5")
