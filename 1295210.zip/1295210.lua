-- Lua provided by RyzenAPI
-- Game: 1295210

-- MAIN APPLICATION
addappid(1295210)
-- Game: addappid(1295210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295211, 1, "8856374cc75c58d787c7e1db9f68a638bae4287aa6e58c954b36e3b984bcc0c5")
