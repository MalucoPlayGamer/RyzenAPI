-- Lua provided by SkyAPI 
-- Game: Soul In the Chamber
addappid(1896650)
addappid(1896651, 1, "7dea12245a5ca7bfb1fdfe44d630bf7e3a9b2a76329c04733352170b58446872")
