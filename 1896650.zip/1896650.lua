-- Lua provided by RyzenAPI
-- Game: 1896650

-- MAIN APPLICATION
addappid(1896650)
-- Game: addappid(1896650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896651, 1, "7dea12245a5ca7bfb1fdfe44d630bf7e3a9b2a76329c04733352170b58446872")
