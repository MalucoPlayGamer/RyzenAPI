-- Lua provided by RyzenAPI
-- Game: Soul In the Chamber

-- MAIN APPLICATION
addappid(1896650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1896651, 1, "7dea12245a5ca7bfb1fdfe44d630bf7e3a9b2a76329c04733352170b58446872")

