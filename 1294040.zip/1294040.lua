-- Lua provided by RyzenAPI
-- Game: AppID 1294040

-- MAIN APPLICATION
addappid(1294040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1294041, 1, "59ba5d738c802e86a9d8f9f5b4b0cfe1fc321197f6dc46041828816a249b5299")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
