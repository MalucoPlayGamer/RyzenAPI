-- Lua provided by RyzenAPI
-- Game: AppID 3209670

-- MAIN APPLICATION
addappid(3209670)
-- Game: addappid(3209670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209671, 1, "b5db08ecf2af5847e3e5ff0120cd3809bb5f8d27d09cf66a66e6a30bfb1d7c26")
