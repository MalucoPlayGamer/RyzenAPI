-- Lua provided by RyzenAPI
-- Game: 2422400

-- MAIN APPLICATION
addappid(2422400)
-- Game: addappid(2422400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422401, 1, "9a58fa0cdab7cf97bc77ef8fca0ee6c5dd5062a3a42be62af620eedfaba48220")
