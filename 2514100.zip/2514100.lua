-- Lua provided by RyzenAPI
-- Game: Keepers Of The Lost Arts

-- MAIN APPLICATION
addappid(2514100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514101, 1, "c97a21e02ff4fd6adf1a5c90e6774042512c6b598f76cbd086fe5617a42a4d9e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
