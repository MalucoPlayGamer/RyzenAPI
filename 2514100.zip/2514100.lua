-- Lua provided by RyzenAPI
-- Game: addappid(2514100)

-- MAIN APPLICATION
addappid(2514100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514101, 1, "c97a21e02ff4fd6adf1a5c90e6774042512c6b598f76cbd086fe5617a42a4d9e")
