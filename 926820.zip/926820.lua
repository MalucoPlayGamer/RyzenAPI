-- Lua provided by RyzenAPI
-- Game: Eternal Space Battles

-- MAIN APPLICATION
addappid(926820)
-- Game: addappid(926820)

-- MAIN APP DEPOTS / PACKAGES
addappid(926821, 1, "4899b2dfc40d1ea5284ebe30749a06c44653e8b86ed84992644b63c4ae45450b")
