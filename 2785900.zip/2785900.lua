-- Lua provided by RyzenAPI
-- Game: addappid(2785900)

-- MAIN APPLICATION
addappid(2785900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785901, 1, "e77d7c7d3fbdfc88549ab199127aae27181cb29ac26a622723cc86ba78878baa")
