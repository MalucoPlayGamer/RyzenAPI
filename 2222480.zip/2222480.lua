-- Lua provided by RyzenAPI
-- Game: Game: AppID 2222480

-- MAIN APPLICATION
addappid(2222480)
-- Game: addappid(2222480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222481, 1, "dc1532b23900735b09161dc399b0afe8f92af20a6b87a88e64a30886b628445f")
