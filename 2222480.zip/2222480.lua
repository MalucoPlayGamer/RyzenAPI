-- Lua provided by RyzenAPI 
-- Game: AppID 2222480
addappid(2222480)
addappid(2222481, 1, "dc1532b23900735b09161dc399b0afe8f92af20a6b87a88e64a30886b628445f")
