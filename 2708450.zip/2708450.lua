-- Lua provided by RyzenAPI
-- Game: 2708450

-- MAIN APPLICATION
addappid(2708450)
-- Game: addappid(2708450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708451, 1, "8c6f7bf45712ece5d9740fe165fa2a63ae75963489ea49ba1b04e0093a8f118f")
