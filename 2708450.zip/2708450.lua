-- Lua provided by RyzenAPI
-- Game: Oh Deer

-- MAIN APPLICATION
addappid(2708450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708451, 1, "8c6f7bf45712ece5d9740fe165fa2a63ae75963489ea49ba1b04e0093a8f118f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
