-- Lua provided by RyzenAPI
-- Game: Monk Took Book

-- MAIN APP DEPOTS / PACKAGES
addappid(4022090, 1, "72b983fa5096d8d9594673ddd1563df8199ec34b259917122f360a57d7c09f58") -- Monk Took Book
addappid(4022091, 1, "785e7f053cfd960055db5f6d6323440823a5b2c1984bbd644f22f1f37d55dbeb") -- Depot 4022091

