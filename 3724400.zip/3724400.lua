-- Lua provided by RyzenAPI
-- Game: addappid(3724400)

-- MAIN APPLICATION
addappid(3724400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3724400,0,"38c1d070d37a17c14bdead3d84086b01ebaf10b87cb5a82fb2af8cceeaa95c68")
