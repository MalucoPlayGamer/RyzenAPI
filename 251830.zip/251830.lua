-- Lua provided by SkyAPI 
-- Game: AppID 251830
addappid(251830)
addappid(251831, 1, "57e041bbf2f07d9a1b3f63b4a7be01f80ec1acce51f3aa2449970b0d9be0c174")
addappid(251832, 1, "52a01582b98739c09d3562b07b39083348cf98bb4a5ce579e42969a0c6b38d38")
