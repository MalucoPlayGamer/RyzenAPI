-- Lua provided by RyzenAPI
-- Game: Stick It To The Man!

-- MAIN APPLICATION
addappid(251830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(251831, 1, "57e041bbf2f07d9a1b3f63b4a7be01f80ec1acce51f3aa2449970b0d9be0c174")
addappid(251832, 1, "52a01582b98739c09d3562b07b39083348cf98bb4a5ce579e42969a0c6b38d38")

