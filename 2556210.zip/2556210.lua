-- Lua provided by RyzenAPI
-- Game: Home trip

-- MAIN APPLICATION
addappid(2556210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556211, 1, "1248aad22f69142b891aea376242a8aed46db407103be6eca325853aa4fabebe")
