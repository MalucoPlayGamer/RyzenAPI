-- Lua provided by RyzenAPI
-- Game: AppID 695760

-- MAIN APPLICATION
addappid(695760)

-- MAIN APP DEPOTS / PACKAGES
addappid(695761, 1, "83c37a3f1e63e214079d1c50b03be19166b61b0a9962f18983c04b6d07755115")
addappid(695762, 1, "9c9b2b3323b1cffcf50743199baeefd76fbbd9d0c59dd5a0f2aefcb25fe00fbd")
