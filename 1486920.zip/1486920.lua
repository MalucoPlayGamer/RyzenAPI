-- Lua provided by RyzenAPI
-- Game: Tempest Rising

-- MAIN APPLICATION
addappid(1486920)
addappid(3478280)
-- Game: addappid(1486920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486921, 1, "26528db8fe19a223ddd4dbc280b52006e6b4aad5884ce084762e313c91d0de46")
