-- Lua provided by RyzenAPI
-- Game: Tempest Rising

-- MAIN APPLICATION
addappid(3478250)
addappid(3478280) -- Tempest Rising - Pre-order DLC
addappid(3710570) -- Tempest Rising - Deluxe Pre-order Bonus Pack
addappid(4764990)
-- addappid(4114220) -- Tempest Rising: The Veti’s Wrath (unreleased)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1486920, 1, "4f3870d90f0e6cedd1a0cc4ca85ebe56d874543cb0f2ff9d6f0ef4d76eb4729e") -- Tempest Rising
addappid(1486921, 1, "26528db8fe19a223ddd4dbc280b52006e6b4aad5884ce084762e313c91d0de46") -- Depot 1486921
addappid(3478250, 1, "9e5ff25c95b392c64f062155f91ef29f7378057b6e0f5e2742daf764e74f0aa4") -- Tempest Rising - Digital Artbook - Depot 3478250
addappid(4764990, 1, "df414ba7cc33e187046ccd3edd653a0559971467f6a0a1b697a89c352011d84e") -- Tempest Rising - Map Editor - Depot 4764990
addtoken(3478250, "832652260017266002")

