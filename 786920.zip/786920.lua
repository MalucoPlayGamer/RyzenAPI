-- Lua provided by RyzenAPI
-- Game: 786920

-- MAIN APPLICATION
addappid(786920)
-- Game: addappid(786920)

-- MAIN APP DEPOTS / PACKAGES
addappid(786921, 1, "a08494d3eee64b1b7edadaedcbe7830f3bf795c715cca0ee2e74574dbe6d74a1")
