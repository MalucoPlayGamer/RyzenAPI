-- Lua provided by RyzenAPI
-- Game: Super Retro BoxBot

-- MAIN APPLICATION
addappid(2709060)
-- Game: addappid(2709060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709061, 1, "14280f2343295ad415b51eef882fc4f47bb94a172f4d4d40460a4ea066c06980")
