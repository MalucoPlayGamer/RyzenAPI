-- Lua provided by RyzenAPI
-- Game: 2739410

-- MAIN APPLICATION
addappid(2739410)
-- Game: addappid(2739410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739410,0,"596ccb10e7fefc2578ab9ff5d64b1e22d7a6afe5e3469ffc20043f076ff2ef30")
