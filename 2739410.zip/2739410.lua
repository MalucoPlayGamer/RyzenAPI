-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - EX Graphic Baseset Outdoor

-- MAIN APPLICATION
addappid(2739410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739410,0,"596ccb10e7fefc2578ab9ff5d64b1e22d7a6afe5e3469ffc20043f076ff2ef30")

