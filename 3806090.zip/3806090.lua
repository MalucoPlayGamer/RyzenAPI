-- Lua provided by RyzenAPI
-- Game: 3806090

-- MAIN APPLICATION
addappid(3806090)
-- Game: addappid(3806090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3806091, 1, "44991f7de790f39e08c97bcc2bcaed0070040fd4215198f33cefd9b6f5236bc8")
