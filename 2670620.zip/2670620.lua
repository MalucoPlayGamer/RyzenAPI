-- Lua provided by RyzenAPI
-- Game: Heroine Anthem Zero 2 : Scalescars Oath Demo

-- MAIN APPLICATION
addappid(2670620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670621, 1, "91effa7c80b53c596233f1fc54fae068256cdad21ccef4ae2d7479ea1e439200")

