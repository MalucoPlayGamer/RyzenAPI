-- Lua provided by SkyAPI 
-- Game: Clash Force
addappid(703620)
addappid(703621, 1, "edb8feb16ea557e731889f733a6a656be1525a9fb4e4c9394468bae0b2b05817")
addappid(741660, 0, "58e77ba41538fa9974333d6addc2229f7f0d6c82ee5737592b3b4c6f6ce1b849")
