-- Lua provided by RyzenAPI
-- Game: Clash Force

-- MAIN APPLICATION
addappid(703620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(703621, 1, "edb8feb16ea557e731889f733a6a656be1525a9fb4e4c9394468bae0b2b05817")
addappid(741660, 0, "58e77ba41538fa9974333d6addc2229f7f0d6c82ee5737592b3b4c6f6ce1b849")

