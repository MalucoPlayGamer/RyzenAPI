-- Lua provided by RyzenAPI
-- Game: 641970

-- MAIN APPLICATION
addappid(641970)
-- Game: addappid(641970)

-- MAIN APP DEPOTS / PACKAGES
addappid(641970,0,"45aa379241edb181f606488fa37409ab6a495faedb90418c0a3d3781d10d17f9")
