-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3354490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354490,0,"684cfef148c6863d0a434362a932ccdddea9f6f4ee623573894bbe4db073a40d")
