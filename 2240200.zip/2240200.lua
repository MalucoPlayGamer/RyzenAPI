-- Lua provided by RyzenAPI
-- Game: Game: Final Fort

-- MAIN APPLICATION
addappid(2240200)
-- Game: addappid(2240200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240201, 1, "473d74e503ba4a5faff6dc45239f50615f049715450d4691909b067a479862a6")
