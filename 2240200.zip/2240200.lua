-- Lua provided by SkyAPI 
-- Game: Final Fort
addappid(2240200)
addappid(2240201, 1, "473d74e503ba4a5faff6dc45239f50615f049715450d4691909b067a479862a6")
