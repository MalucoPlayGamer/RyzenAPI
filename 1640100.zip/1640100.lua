-- Lua provided by RyzenAPI
-- Game: addappid(1640100)

-- MAIN APPLICATION
addappid(1640100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640101, 1, "563921823d0c31430b387f5d1ca205daec8016942ce422ddcaed5c69e3c43860")
