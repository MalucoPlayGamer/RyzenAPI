-- Lua provided by RyzenAPI
-- Game: addappid(764780)

-- MAIN APPLICATION
addappid(764780)
addappid(802250)

-- MAIN APP DEPOTS / PACKAGES
addappid(764781, 1, "0226b7d38ff7c8026722d9797d47c03ee21e46262aecfaecc84318702598c2fd")
