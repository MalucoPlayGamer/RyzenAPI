-- Lua provided by RyzenAPI 
-- Game: The Redress of Mira
addappid(1843860)
addappid(1843861, 1, "49ecade7d3455778ae558aad6e70f0652cf69b8c01931a4adcf7351206a7d436")
