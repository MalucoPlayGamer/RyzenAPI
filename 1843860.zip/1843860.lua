-- Lua provided by RyzenAPI
-- Game: The Redress of Mira

-- MAIN APPLICATION
addappid(1843860)
-- Game: addappid(1843860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843861, 1, "49ecade7d3455778ae558aad6e70f0652cf69b8c01931a4adcf7351206a7d436")
