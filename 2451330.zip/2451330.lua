-- Lua provided by RyzenAPI
-- Game: Monster Mop Up Demo

-- MAIN APPLICATION
addappid(2451330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451331, 1, "7964006115205cb9fa997fa3589c00aa582c699e6b9064f7fd245b7356b7726b")
