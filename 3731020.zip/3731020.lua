-- Lua provided by RyzenAPI
-- Game: Five Hearts Under One Roof season2

-- MAIN APPLICATION
addappid(3731020)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4054090)
addappid(4745180)
