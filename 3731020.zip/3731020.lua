-- Lua provided by RyzenAPI
-- Game: Five Hearts Under One Roof season2

-- MAIN APPLICATION
addappid(3731020)
addappid(4054090)
addappid(4745180)

