-- Lua provided by RyzenAPI
-- Game: Five Hearts Under One Roof season2

-- MAIN APPLICATION
addappid(3731020)

