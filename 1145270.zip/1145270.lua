-- Lua provided by RyzenAPI
-- Game: Misfire

-- MAIN APPLICATION
addappid(1145270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145271, 1, "428d6ce0abac70cde1ff0c59018f4f5ddcc27f4afc83a6c3a6a7202b007917fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
