-- Lua provided by RyzenAPI
-- Game: 1145270

-- MAIN APPLICATION
addappid(1145270)
-- Game: addappid(1145270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145271, 1, "428d6ce0abac70cde1ff0c59018f4f5ddcc27f4afc83a6c3a6a7202b007917fc")
