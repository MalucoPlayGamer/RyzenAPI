-- Lua provided by RyzenAPI
-- Game: Pirates Girls

-- MAIN APPLICATION
addappid(1337270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337271, 1, "7ffc1b3a7a25a06510bb049b149249a76441dcc1189cfb705f15614d96bb35bd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1342720)
