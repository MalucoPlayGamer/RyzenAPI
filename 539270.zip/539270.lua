-- Lua provided by RyzenAPI
-- Game: Mahjong

-- MAIN APPLICATION
addappid(539270)

-- MAIN APP DEPOTS / PACKAGES
addappid(539271, 1, "d28934b2930159970def770e9ab910584b56ea532b220e1c58e7ace962b23eeb")
