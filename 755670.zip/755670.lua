-- Lua provided by RyzenAPI
-- Game: Sleep Tight

-- MAIN APPLICATION
addappid(755670)
-- Game: addappid(755670)

-- MAIN APP DEPOTS / PACKAGES
addappid(755671, 1, "eeb9e0fd25295fb7be5b9b539db0bb446713dbebbe10901cbaebbb95d54d6a43")
