-- Lua provided by RyzenAPI
-- Game: Sleep Tight

-- MAIN APPLICATION
addappid(755670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(755671, 1, "eeb9e0fd25295fb7be5b9b539db0bb446713dbebbe10901cbaebbb95d54d6a43")

