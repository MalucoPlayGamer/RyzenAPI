-- Lua provided by RyzenAPI
-- Game: Game: Dynast.io

-- MAIN APPLICATION
addappid(792200)
-- Game: addappid(792200)

-- MAIN APP DEPOTS / PACKAGES
addappid(792201, 1, "35c1261da908240f874c8d2ffe2d7a90925ebad31cc4724e2e423af3285036c9")
addappid(792205, 1, "da44425dfe3de323171b57be7ddbddb741b3d753bccffe7f8c91fa0857b112b3")
