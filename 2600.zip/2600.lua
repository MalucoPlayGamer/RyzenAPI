-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade - Bloodlines

-- MAIN APPLICATION
addappid(2600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601, 1, "9d9a44e23934058d06dd944ade19bcb15c26d94c19606d9780c300b7590b3eea")
addappid(2602, 1, "b927197ffca00e23bf86b5bff4a74aecafb78b6b60e661eb1b4461f4bdff6b20")
addappid(2603, 1, "b6b13add8afbdac9895ceae218f9d35243e840fb8a89fd9ff5c11a6ab33e3036")
addappid(2604, 1, "bd949f3356db457ac868d03ed76922436bf32e542357418b5e40c0cc73d3bbd5")
addappid(2605, 1, "d7952ec7dac0218ed27476b8c6fbfd6c5dba91b98a4dacd67b7dc0aa366218e0")
