-- Lua provided by RyzenAPI
-- Game: Mira

-- MAIN APPLICATION
addappid(1185740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185741, 1, "d9fcb1fe5af6d5a028746071391b9f27f19e1fbda065f2cd47306d3b7daa777f")

