-- Lua provided by RyzenAPI
-- Game: The 5th Door

-- MAIN APPLICATION
addappid(3623590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3623591, 1, "ac9906f3b609881847b3a1ce0d4255919566485caaef8a229556fc4499371eb4")

