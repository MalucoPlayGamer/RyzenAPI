-- Lua provided by RyzenAPI
-- Game: Paranormal Torment

-- MAIN APPLICATION
addappid(3512250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3512251, 1, "e3ab3f291a46078e0daa4ca3b8cbb5f12e4c404740fd4220d0099e29f0cb54d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
