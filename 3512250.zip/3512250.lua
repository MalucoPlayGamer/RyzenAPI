-- Lua provided by RyzenAPI
-- Game: Game: Paranormal Torment

-- MAIN APPLICATION
addappid(3512250)
-- Game: addappid(3512250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3512251, 1, "e3ab3f291a46078e0daa4ca3b8cbb5f12e4c404740fd4220d0099e29f0cb54d7")
