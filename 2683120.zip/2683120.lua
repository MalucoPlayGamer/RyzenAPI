-- Lua provided by RyzenAPI
-- Game: Game: Nickelodeon All-Star Brawl 2 Soundtrack

-- MAIN APPLICATION
addappid(2683120)
-- Game: addappid(2683120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683121, 1, "e3c95d1932b9d70395febacc4157e02544afb9f0d9665d241604b321ff88b260")
addappid(2683122, 1, "cf0c1ba5c7149f8fae268b6214f11edd432b3fc9effa857aaf80b3747a68e7e7")
