-- Lua provided by RyzenAPI
-- Game: addappid(747770)

-- MAIN APPLICATION
addappid(747770)

-- MAIN APP DEPOTS / PACKAGES
addappid(747771, 1, "c82ac2ccb1548127bd4d6dda7066a8667fb7f4d27f88ccfc1cc424bcf3db5ccd")
