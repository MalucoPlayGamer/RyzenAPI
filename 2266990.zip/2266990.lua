-- Lua provided by SkyAPI 
-- Game: AppID 2266990
addappid(2266990)
addappid(2266991, 1, "6b45eae750833c720ee7f7a15e2eab6b932c89e3f5ed344bf4c5c749263e755c")
