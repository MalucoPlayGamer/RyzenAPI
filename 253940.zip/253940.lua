-- Lua provided by RyzenAPI
-- Game: Septerra Core

-- MAIN APPLICATION
addappid(253940)
addappid(1026170)
addappid(1026171)

-- MAIN APP DEPOTS / PACKAGES
addappid(253941, 1, "9dbcbcafcb69036082c5f8a83bb10cddce77f94e7f7717e514655acb0ebf7da6")
addappid(253942, 1, "714b396dae7052a02c51b195b302776c2a97ffdece79b104d6e961fc9c9bd60d")
addappid(253943, 1, "034baf94401944101af6e1c7fa65a9d49db27ef5fde7d9a4136f0d48249790e2")
addappid(253944, 1, "818be4dedbdbc508a8aade25844aabfe98b536b6f1c3645ae0169b9eb4273540")
addappid(253945, 1, "4501e71544df9f912c22417f4198a9f0a2d6b8f3ea432521780acebd1e47f479")
addappid(253946, 1, "163022f544ac4411e98cf23538eb7db5105adc405cf5be55d2fceb5dfdfa4177")
addappid(253947, 1, "2dc751af3495312532f209936de110540ee91e514a4f6ba35fce424e82c996ab")

