-- Lua provided by RyzenAPI 
-- Game: AppID 1724020
addappid(1724020)
addappid(1724021, 1, "90ac1826bc71c2faffc7b02dfec77363e21e88346118c2b766998a49b952908b")
