-- Lua provided by RyzenAPI
-- Game: Space Tower Defense

-- MAIN APPLICATION
addappid(1724020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724021, 1, "90ac1826bc71c2faffc7b02dfec77363e21e88346118c2b766998a49b952908b")
