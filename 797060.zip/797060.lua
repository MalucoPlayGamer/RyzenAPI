-- Lua provided by SkyAPI 
-- Game: Qubika
addappid(797060)
addappid(797061, 1, "d63c879d6e7895f39788dad5b1db25fe29b490836682607b02d9c0962b631530")
