-- Lua provided by RyzenAPI
-- Game: Promise Mascot Agency Soundtrack - Side Ryo Koike

-- MAIN APPLICATION
addappid(3560770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3560771, 1, "6a6efd18eb66ec9517a09b27d3d9f0c2351f82b4486a7914b842dd31d6003dc0")
addappid(3560772, 1, "59194679c381b2d8f6701ac2c36cca444a0f918044f739fe560a0ca244764d6e")

