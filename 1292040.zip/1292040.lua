-- Lua provided by RyzenAPI
-- Game: AppID 1292040

-- MAIN APPLICATION
addappid(1292040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292041, 1, "836506c34f6abdd447cf965ad146f98440a5a5677c188d95fdebbbb3b66d8215")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
