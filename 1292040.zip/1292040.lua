-- Lua provided by RyzenAPI 
-- Game: AppID 1292040
addappid(1292040)
addappid(1292041, 1, "836506c34f6abdd447cf965ad146f98440a5a5677c188d95fdebbbb3b66d8215")
