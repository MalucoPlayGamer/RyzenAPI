-- Lua provided by RyzenAPI
-- Game: Spirits: Ciel Bleu

-- MAIN APPLICATION
addappid(671230)
-- Game: addappid(671230)

-- MAIN APP DEPOTS / PACKAGES
addappid(671231, 1, "94a056bd05498138f69072b71b72599dd104027b32842b60e0336b20ee918b69")
