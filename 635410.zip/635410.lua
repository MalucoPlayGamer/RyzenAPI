-- Lua provided by RyzenAPI
-- Game: addappid(635410)

-- MAIN APPLICATION
addappid(635410)

-- MAIN APP DEPOTS / PACKAGES
addappid(635411, 1, "f6e9fe40778e6d0a88154e286f57448dab9d2f566f0e72e68d42cf5d39d709f0")
