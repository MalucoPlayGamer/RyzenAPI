-- Lua provided by RyzenAPI
-- Game: Defendoooooor!!

-- MAIN APPLICATION
addappid(683230)

-- MAIN APP DEPOTS / PACKAGES
addappid(683232,0,"df599072b0481ae441ca09f637749244a2cb0136ef86e494265a9bdb39424489")
