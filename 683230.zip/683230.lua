-- Lua provided by RyzenAPI
-- Game: Defendoooooor!!

-- MAIN APPLICATION
addappid(683230)
addappid(709090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(683232,0,"df599072b0481ae441ca09f637749244a2cb0136ef86e494265a9bdb39424489")

