-- Lua provided by RyzenAPI
-- Game: Brigandine The Legend of Runersia

-- MAIN APPLICATION
addappid(1843940)
-- Game: addappid(1843940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843941, 1, "81263a8e970eb65704838f4ab3a37a4bd64796f185e5efeebdc968c9774402dc")
