-- Lua provided by SkyAPI 
-- Game: Brigandine The Legend of Runersia
addappid(1843940)
addappid(1843941, 1, "81263a8e970eb65704838f4ab3a37a4bd64796f185e5efeebdc968c9774402dc")
