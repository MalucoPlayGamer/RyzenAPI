-- Lua provided by RyzenAPI
-- Game: addappid(774791)

-- MAIN APPLICATION
addappid(774791)

-- MAIN APP DEPOTS / PACKAGES
addappid(774793,0,"2355ca63641fd1643bc1bd0af9c781ef93fa213dc57972913f1bc3bbb8d1787c")
