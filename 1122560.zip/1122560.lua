-- Lua provided by RyzenAPI
-- Game: 1122560

-- MAIN APPLICATION
addappid(1122560)
-- Game: addappid(1122560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122560,0,"a6b7d30467d264673e6f6ed01252f08d4b0c8f119f7bc2e2141a463e576a1aef")
