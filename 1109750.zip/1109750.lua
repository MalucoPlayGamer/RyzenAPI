-- Lua provided by RyzenAPI
-- Game: 1109750

-- MAIN APPLICATION
addappid(1109750)
-- Game: addappid(1109750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109751, 1, "8e313b4148ee9131a1319fe584d301f9fa0deda170b6be4eb6b640da90f0c38a")
