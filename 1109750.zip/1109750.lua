-- Lua provided by RyzenAPI
-- Game: Terracotta - Shards of Doom

-- MAIN APPLICATION
addappid(1109750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1109751, 1, "8e313b4148ee9131a1319fe584d301f9fa0deda170b6be4eb6b640da90f0c38a")

