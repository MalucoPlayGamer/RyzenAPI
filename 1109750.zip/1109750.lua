-- Lua provided by SkyAPI 
-- Game: Terracotta - Shards of Doom
addappid(1109750)
addappid(1109751, 1, "8e313b4148ee9131a1319fe584d301f9fa0deda170b6be4eb6b640da90f0c38a")
