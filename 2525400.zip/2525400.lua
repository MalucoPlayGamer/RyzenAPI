-- Lua provided by RyzenAPI
-- Game: 2525400

-- MAIN APPLICATION
addappid(2525400)
-- Game: addappid(2525400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525401, 1, "d754c6d79edd3d6304bd0acc3a9ff7e35af72afdd38abb2c47cfa50f7931b0ae")
