-- Lua provided by RyzenAPI
-- Game: Game: Neon White - Original Soundtrack

-- MAIN APPLICATION
addappid(2054540)
-- Game: addappid(2054540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054541, 1, "db19d619e5d413db988a693a9d1b376d8077eb03342753f4f3c14b16ebd63e56")
addappid(2054542, 1, "0475dd560315e07c621bcfc02bcda83d2510bdd27e3bea87a7a40973e00a8a05")
