-- Lua provided by RyzenAPI
-- Game: Ghost Girl Lasling

-- MAIN APPLICATION
addappid(2127420)
addappid(2139720) -- Ghost Girl Lasling Shop Description in Arabic
addappid(2282180)
addappid(2872550)
addappid(3713460)
-- addappid(2126542) -- Depot 2126542 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948470, 1, "1ffd5aabe2b77e875ac68ac2260615b3e5b787373572460e1b920cde24851755") -- Ghost Girl Lasling
addappid(1948471, 1, "6a75668b926a3a4f52dac6225886ae521ed2dd9c90ae9870123d07f80f2eb3da") -- Depot 1948471
addappid(1948472, 1, "3b06be31fca7be03ba89698bbf84768571556c644f20dffefcfca03e6ee5650f") -- Depot 1948472
addappid(1948473, 1, "75457f432a973445f9761b658ccf1c21a3b7c7715da5377f19eaac4dfcf46b5f") -- Depot 1948473
addappid(1948474, 1, "3f5c76c19fcf9e0a37d5b902f7726b7050f4b77ca5234ca55962fc64b0695e46") -- Depot 1948474
addappid(1948475, 1, "eb67c0cbfeadef34a02200c7acb18245043665b5c10f81712de737cf6335ec65") -- Depot 1948475
addappid(1948476, 1, "6e3fde0e7fcb2da1cc69547d6a7e508e1afaa9c97ce81e5d73f2f9b063caa528") -- Depot 1948476
addappid(1948477, 1, "e32c390118ff2f0197ab07acfdc703414de543a4d0b7bfd9037dd8309a9f47fb") -- Depot 1948477
addappid(1948478, 1, "ba423d036d5fa7901671c56dd68908c0177da221a41c90d4f1fbb57cf11ac3bc") -- Depot 1948478
addappid(1948479, 1, "b6fea10e03d9d488d459d268699a066a539a1802efd8e63c7954f3fea8b63671") -- Depot 1948479
addappid(2126541, 1, "03a3dc385011cdf8e7375c20e206e2f99116b505a18de6725c1047cc7fe6e241") -- Depot 2126541
addappid(2126543, 1, "a2b0487204fc450fedb705df0875c98e14041eadcb1ed56ef6c88231159ddbf3") -- Depot 2126543
addappid(2126544, 1, "0ea3e51a9958418d0a4bf38b1209c38592ff54ec7b44d0a6af80259c27db06d3") -- Depot 2126544
addappid(2126545, 1, "b4c75a1cf40f281db3bda7994666412c3bfdc9c74a1a883faaf29a76de663efb") -- Depot 2126545
addappid(2126546, 1, "8a675ddfb887059f3ab1b8a76a223ebfad0828c709300277e8d2ee1041f63ee0") -- Depot 2126546
addappid(2126547, 1, "1e8e93e43e4dd771f1b77ef2653dd9aff7b31fd48d96927551c18d37bb40ee2a") -- Depot 2126547
addappid(2126548, 1, "020893417781edc0d51f81e66850046d3fbe97849c00197726cac22b62bdda05") -- Depot 2126548
addappid(2126549, 1, "5f9dc18ae43c5e0e4837b79742ee0a08ef2adcc72bdc9122001e4d163291ba11") -- Depot 2126549
addappid(2127421, 1, "52994f8faf7395fdb46cf6fd29593ad6bacd3853abdfe2ac1322440c2902aa8d") -- Ghost Girl Lasling DLC - R18 ASMR - Depot 2127421
addappid(2127422, 1, "dde0f4e58aa59a3a450c276e1ff12f3ed25f25e019907a3b8fc34e75dd3b49b2") -- Ghost Girl Lasling DLC - R18 ASMR - Depot 2127422
addappid(2127423, 1, "0796b35005529981fb44e8486ab37a13a30ad0730d2b1326428d55223f1be182") -- Ghost Girl Lasling DLC - R18 ASMR - Depot 2127423
addappid(2282181, 1, "bd545d9b25bac0ba5f446cca2a17a8af8f6bf5f5eea993c0d6c4ed8df3a8b7be") -- Creators talks and project designs DLC (18) - Depot 2282181
addappid(2282182, 1, "32dedfdd6ae2cfde87a2771f72df420fb425f60a5e30cbb4567433234aecf0f3") -- Creators talks and project designs DLC (18) - Depot 2282182
addappid(2282183, 1, "264c1792bb65419564a44dbf967f20be4c1a44b546a574b1e0232a98e889c094") -- Creators talks and project designs DLC (18) - Depot 2282183
addappid(2872551, 1, "a6454135eede1185780b5a3164b24b02da40058ed7ef601e05bb99f95f013e6d") -- Ghost Girl Lasling-Chibi Stickers - Depot 2872551
addappid(3713461, 1, "4c24606e5b97d35a60af7d63b273012f5e6578392ce99105d9de8924c70a3500") -- Ghost Girl Lasling-3D printable High-poly Model - Depot 3713461

