-- Lua provided by RyzenAPI
-- Game: Astro Tripper

-- MAIN APPLICATION
addappid(110600)

-- MAIN APP DEPOTS / PACKAGES
addappid(110601, 1, "7a9812387ce101d1dd1e106ca493d8acf41aadd806b73a92d2a967416819872b")
