-- Lua provided by RyzenAPI
-- Game: Thick Air

-- MAIN APPLICATION
addappid(525350)

-- MAIN APP DEPOTS / PACKAGES
addappid(525351,0,"c71949f247fbd1da0f2d3f5b1e1bca34c5b8898007eea2ca2df14848848630fd")

