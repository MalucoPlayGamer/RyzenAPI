-- Lua provided by RyzenAPI
-- Game: Zombie Vikings

-- MAIN APPLICATION
addappid(337480)
addappid(412960)

-- MAIN APP DEPOTS / PACKAGES
addappid(337481, 1, "516cb87c0f412da60930f9996450d36cf5eb6dcbafebeff1014dea0de81d0865")
