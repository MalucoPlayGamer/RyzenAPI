-- Lua provided by RyzenAPI
-- Game: Purrfect Tale

-- MAIN APPLICATION
addappid(2482000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482006,0,"c9abb7bf9524933209136621bf9e225208563e9ef9fe5849b9ea393efe1db898")
