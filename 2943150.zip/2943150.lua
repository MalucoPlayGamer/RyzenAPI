-- Lua provided by RyzenAPI
-- Game: 2943150

-- MAIN APPLICATION
addappid(2943150)
-- Game: addappid(2943150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943151, 1, "83d9416c7201258e613cdf22fcf65d51464cc090bbd6ca77845acfc71cfc8467")
