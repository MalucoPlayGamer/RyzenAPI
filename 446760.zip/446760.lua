-- Lua provided by RyzenAPI
-- Game: AppID 446760

-- MAIN APPLICATION
addappid(446760)

-- MAIN APP DEPOTS / PACKAGES
addappid(446761, 1, "ad0596a6897a8a369ef2b0cee1debf1c307baec708c7be869cb5c5bf7de77ce3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
