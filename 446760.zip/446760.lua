-- Lua provided by RyzenAPI 
-- Game: AppID 446760
addappid(446760)
addappid(446761, 1, "ad0596a6897a8a369ef2b0cee1debf1c307baec708c7be869cb5c5bf7de77ce3")
