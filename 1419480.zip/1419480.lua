-- Lua provided by RyzenAPI
-- Game: Love's Sweet Garnish 2

-- MAIN APPLICATION
addappid(1419480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419481, 1, "44236353eb5c99ccaf194171339257cba18c3ccdfe434d649089ffc7d526093c")

