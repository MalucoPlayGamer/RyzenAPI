-- Lua provided by RyzenAPI
-- Game: AppID 2387660

-- MAIN APPLICATION
addappid(2387660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387661, 1, "61ed4eb76b6ae007ace2c6df957f1fe58567ded9a7fa72338b0abe874acc3813")
