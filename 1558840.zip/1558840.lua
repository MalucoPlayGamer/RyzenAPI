-- Lua provided by RyzenAPI
-- Game: 1558840

-- MAIN APPLICATION
addappid(1558840)
-- Game: addappid(1558840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558841, 1, "20ed44dd186847a70800bc6990e1c2be0549acec93a300f0bf7632ada2adc53d")
