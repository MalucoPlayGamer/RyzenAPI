-- Lua provided by RyzenAPI
-- Game: Path of Kami: Journey Begins

-- MAIN APPLICATION
addappid(1558840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558841, 1, "20ed44dd186847a70800bc6990e1c2be0549acec93a300f0bf7632ada2adc53d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2181070)
addappid(2181071)
