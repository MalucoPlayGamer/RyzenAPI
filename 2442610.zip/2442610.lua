-- Lua provided by RyzenAPI
-- Game: addappid(2442610)

-- MAIN APPLICATION
addappid(2442610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442611, 1, "198d5ec40f27dd9558dfcdd93e0b8ac85bcd0a62a8036056d9e6e42cd7e3aec3")
