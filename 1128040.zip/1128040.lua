-- Lua provided by RyzenAPI
-- Game: addappid(1128040)

-- MAIN APPLICATION
addappid(1128040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128040,0,"9514ce5a7c317e082947dc875f5770d506dbe4a64abf93f50de80e32a7264fd7")
