-- Lua provided by RyzenAPI
-- Game: 3268660

-- MAIN APPLICATION
addappid(3268660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268662,0,"3d4b7c003d6753cce17fd7919ffc852d6adbc23d5a53ee1905ca053d48db23d4")
