-- Lua provided by RyzenAPI
-- Game: Match It Sexy

-- MAIN APPLICATION
addappid(2518350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518351, 1, "194e287d95cd44bfd6f35b4577e34af3182635fed2fa7e70caf687a0c52e7c33")
