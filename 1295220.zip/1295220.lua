-- Lua provided by RyzenAPI
-- Game: Super Buff HD

-- MAIN APPLICATION
addappid(1295220)
-- Game: addappid(1295220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295221, 1, "3324b9aa6b4ae5975c0c8a28799aaa32bfb486d6e05f2b550d1cbb1a40ad5e5f")
