-- Lua provided by RyzenAPI 
-- Game: Lust for Darkness
addappid(523650)
addappid(523651, 1, "3fcae53b2129b8e912a4b0915a98443cc46e07b19c089ae76488c26b85e6147e")
addappid(523652, 1, "149c15d463012d7bb98ca4710c6d814e9c1803d839bd3072b60d44a101ae7ce0")
