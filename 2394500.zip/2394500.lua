-- Lua provided by RyzenAPI
-- Game: ia scatter city

-- MAIN APPLICATION
addappid(2394500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394501, 1, "3cd53dbdcb509fb1343420b4f65c427739a45b3bcf5a8de25be43b2c173c8296")

