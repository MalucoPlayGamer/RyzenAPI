-- Lua provided by RyzenAPI
-- Game: ia scatter city

-- MAIN APPLICATION
addappid(2394500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394501, 1, "3cd53dbdcb509fb1343420b4f65c427739a45b3bcf5a8de25be43b2c173c8296")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
