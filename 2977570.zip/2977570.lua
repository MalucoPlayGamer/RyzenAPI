-- Lua provided by RyzenAPI
-- Game: REVEREND

-- MAIN APPLICATION
addappid(2977570)
-- Game: addappid(2977570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977571, 1, "c3757ad930973de2f3736add1820e989cc17f7489fcccbd954271c9158031f16")
