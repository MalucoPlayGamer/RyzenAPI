-- Generated with Luie @ https://lua.tools/
-- 4029740 - Puppergeist
-- Generated 2026-08-21 21:58:28 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4029740)

-- Main Depots
addappid(4029741, 1, "90f124013887447e1c058ae34271771f0414816ab3e5a598eae70e01b3929eb0")
setManifestid(4029741, "3253045427997846563", 2651644907)
