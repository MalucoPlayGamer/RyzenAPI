-- Lua provided by RyzenAPI
-- Game: High Speed Cataclysm

-- MAIN APPLICATION
addappid(1415520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415521, 1, "77d33d4e1ddab9f324fa38f87e3f6f4ffc4acc858631b88c636c12b2e418c30f")

