-- Lua provided by RyzenAPI
-- Game: addappid(2979840)

-- MAIN APPLICATION
addappid(2979840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2979841, 1, "1819d46beb0adc60c3b8a5070cda3438272228e116dce001889bd01cda804494")
