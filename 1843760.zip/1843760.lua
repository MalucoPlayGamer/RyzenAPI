-- Lua provided by RyzenAPI
-- Game: addappid(1843760)

-- MAIN APPLICATION
addappid(1843760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843761, 1, "81a3002f1b3e8f69c62e3142cf4ebe0bd387d906c795529aa3747e961f136f72")
