-- Lua provided by RyzenAPI
-- Game: addappid(425340)

-- MAIN APPLICATION
addappid(425340)
addappid(449570)

-- MAIN APP DEPOTS / PACKAGES
addappid(425341, 1, "a2758e11a2380dcba6ebd43bec0173e7e72bb464ebd8cd296641ca492a90e12d")
