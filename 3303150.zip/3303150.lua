-- Lua provided by RyzenAPI
-- Game: 3303150

-- MAIN APPLICATION
addappid(3303150)
-- Game: addappid(3303150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3303152,0,"510a3ad1d98da63e719d0cc255f63789cd430afe94532d07b2179ea2821b4b96")
