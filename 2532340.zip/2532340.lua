-- Lua provided by RyzenAPI
-- Game: Unaware in The City

-- MAIN APPLICATION
addappid(2532340)
-- Game: addappid(2532340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532341, 1, "44781234023af7d32ac61583c9b9b3be400b89530e2a73bc1e6162ebf79a82cd")
addappid(3312450, 0, "e8c80dbbd711db602977b32a384c9fd3b33b8e3dd8c2a593ba5c0f186af63976")
