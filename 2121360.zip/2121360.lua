-- Lua provided by RyzenAPI
-- Game: 东北之夏

-- MAIN APPLICATION
addappid(2121360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121361, 1, "cdb2eea95ce5d57010ab3cfbc7bc845629e3859fb33723a3de6970fd6835fb02")

