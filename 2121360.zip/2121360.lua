-- Lua provided by RyzenAPI
-- Game: 东北之夏

-- MAIN APPLICATION
addappid(2121360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2121361, 1, "cdb2eea95ce5d57010ab3cfbc7bc845629e3859fb33723a3de6970fd6835fb02")

