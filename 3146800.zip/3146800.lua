-- Lua provided by RyzenAPI
-- Game: Seed in Demo

-- MAIN APPLICATION
addappid(3146800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146802,0,"b2946259625ea10f51ba5877c73010e0e6f5bd20ea7d7ac1bf26d8b79efd4caa")

