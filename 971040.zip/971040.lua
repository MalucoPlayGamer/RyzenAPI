-- Lua provided by RyzenAPI
-- Game: Game: AppID 971040

-- MAIN APPLICATION
addappid(971040)
-- Game: addappid(971040)

-- MAIN APP DEPOTS / PACKAGES
addappid(971041, 1, "8468e99b8b75cbf6ce4ed450850da14c08fd974268b94991e7b6e018c9505b1a")
