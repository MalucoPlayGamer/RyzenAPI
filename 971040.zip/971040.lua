-- Lua provided by RyzenAPI
-- Game: AppID 971040

-- MAIN APPLICATION
addappid(971040)

-- MAIN APP DEPOTS / PACKAGES
addappid(971041, 1, "8468e99b8b75cbf6ce4ed450850da14c08fd974268b94991e7b6e018c9505b1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
