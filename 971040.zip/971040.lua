-- Lua provided by SkyAPI 
-- Game: AppID 971040
addappid(971040)
addappid(971041, 1, "8468e99b8b75cbf6ce4ed450850da14c08fd974268b94991e7b6e018c9505b1a")
