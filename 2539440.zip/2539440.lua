-- Lua provided by SkyAPI 
-- Game: Stay
addappid(2539440)
addappid(2539441, 1, "9ca5a6b1acc46c8a98a0c822df91b33ba22aa2051ad1b8634dafb56893b40d18")
