-- Lua provided by RyzenAPI
-- Game: Color Splash: Monkeys

-- MAIN APPLICATION
addappid(2951850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951851, 1, "d60c11a84e3e6f62d977a47e748c0d4d0646368bd42c62d749b39563c2290d29")
