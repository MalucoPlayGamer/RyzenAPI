-- Lua provided by SkyAPI 
-- Game: AppID 2951850
addappid(2951850)
addappid(2951851, 1, "d60c11a84e3e6f62d977a47e748c0d4d0646368bd42c62d749b39563c2290d29")
