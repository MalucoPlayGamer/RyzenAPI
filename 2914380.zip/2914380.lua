-- Lua provided by SkyAPI 
-- Game: Fertility, Crime, and Economy Demo
addappid(2914380)
addappid(2914381, 1, "bcbbc6729c9e4e0c74a7ed0f4cf8e07a7a8bc1b56d91601f9bda34ac9d93f579")
