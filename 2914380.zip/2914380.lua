-- Lua provided by RyzenAPI
-- Game: Fertility, Crime, and Economy Demo

-- MAIN APPLICATION
addappid(2914380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914381, 1, "bcbbc6729c9e4e0c74a7ed0f4cf8e07a7a8bc1b56d91601f9bda34ac9d93f579")
