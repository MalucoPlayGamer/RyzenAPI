-- Lua provided by RyzenAPI
-- Game: addappid(657440)

-- MAIN APPLICATION
addappid(657440)

-- MAIN APP DEPOTS / PACKAGES
addappid(657441, 1, "688453635caca5702910cd950bed77a27ae839327ed94a43b6df0ceb90efc278")
