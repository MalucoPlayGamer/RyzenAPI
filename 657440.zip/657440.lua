-- Lua provided by RyzenAPI
-- Game: Burn It Down

-- MAIN APPLICATION
addappid(657440)

-- MAIN APP DEPOTS / PACKAGES
addappid(657441, 1, "688453635caca5702910cd950bed77a27ae839327ed94a43b6df0ceb90efc278")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
