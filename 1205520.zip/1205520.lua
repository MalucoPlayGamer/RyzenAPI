-- Lua provided by RyzenAPI
-- Game: 1205520

-- MAIN APPLICATION
addappid(1205520)
-- Game: addappid(1205520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205521, 1, "b99be1c4c7eca21bcdb0f4946d4642f5f5885e89f1834baeb607e5f511da4031")
addappid(1205522, 1, "26cceed1a84feacac00e326ba0a24ce8c7fec167e0d136ec6d4bd32e71ac2998")
