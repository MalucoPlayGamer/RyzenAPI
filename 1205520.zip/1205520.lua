-- Lua provided by RyzenAPI
-- Game: Pentiment

-- MAIN APPLICATION
addappid(1205520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1205521, 1, "b99be1c4c7eca21bcdb0f4946d4642f5f5885e89f1834baeb607e5f511da4031")
addappid(1205522, 1, "26cceed1a84feacac00e326ba0a24ce8c7fec167e0d136ec6d4bd32e71ac2998")

