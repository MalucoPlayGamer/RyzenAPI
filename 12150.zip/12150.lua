-- Lua provided by RyzenAPI
-- Game: addappid(12150)

-- MAIN APPLICATION
addappid(12150)

-- MAIN APP DEPOTS / PACKAGES
addappid(12151, 1, "7d78588a024003c4989d9dc5a5d86d60223495c8c86c8d2b9591278d0e1e112d")
