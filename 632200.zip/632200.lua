-- Lua provided by SkyAPI 
-- Game: AppID 632200
addappid(632200)
addappid(632201, 1, "5022f4637b994f2d9f12fe20ac7e45b51590737e03ac7a3712530e46d13c8ff1")
addappid(632202, 1, "565703022cfa2ad8e5c5a115d268a4207dbe7653e4f4f6fbb0bdaeed5fba3462")
