-- Lua provided by RyzenAPI
-- Game: SEX Room [18+]

-- MAIN APPLICATION
addappid(2246850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246851, 1, "c1afb26983c4c7afe285ab916f092dc89c4da470d0f40c22d8a327609aed1cb7")
