-- Lua provided by RyzenAPI
-- Game: addappid(3249090)

-- MAIN APPLICATION
addappid(3249090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249091, 1, "09e67e150b01724bab28d744e6b38301f77ddf035aee5e82d4a7f0d1facc79b4")
