-- Lua provided by RyzenAPI
-- Game: Game: Soccer Manager 2022

-- MAIN APPLICATION
addappid(1777760)
-- Game: addappid(1777760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777761, 1, "8d83c8f50192adc1b9e471ccbc1d36c3b85d8aea877fece013be09dd0612ec18")
