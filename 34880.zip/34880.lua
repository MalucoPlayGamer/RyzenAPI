-- Lua provided by RyzenAPI
-- Game: Sniper Ghost Warrior 2 Demo

-- MAIN APPLICATION
addappid(34880)
addappid(228982)
addappid(228983)
addappid(228990)
-- Game: addappid(34880)

-- MAIN APP DEPOTS / PACKAGES
addappid(34881, 1, "33f66213ecd3a8561dee04b178505b94b5ed24622197dc622b22b4762d17f3c5")
