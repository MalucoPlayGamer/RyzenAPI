-- Lua provided by RyzenAPI 
-- Game: Red Lake
addappid(357290)
addappid(357291, 1, "216b7741d502d642ffcb9acfc48c764039adc5b17128061f253f7d2f42fcbaa8")
