-- Lua provided by RyzenAPI
-- Game: Game: Gunship Battle2 VR: Steam Edition

-- MAIN APPLICATION
addappid(700990)
-- Game: addappid(700990)

-- MAIN APP DEPOTS / PACKAGES
addappid(700991, 1, "a6bf834ea4bc20e1017c348ddc63c654f7fde0512cfc164548871e4bac8b3adf")
