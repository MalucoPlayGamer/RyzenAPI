-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass – Easy String Switching Exercise 2

-- MAIN APPLICATION
addappid(1089229)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089229,0,"b8c33b10fade8f971b5534d7be27be5150e25434429cbbc1bf4a157342a89f6f")

