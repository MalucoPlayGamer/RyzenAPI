-- Lua provided by RyzenAPI
-- Game: 3814680

-- MAIN APPLICATION
addappid(3814680)
-- Game: addappid(3814680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3814681, 1, "828c7170d42e584b12fc6ae9fc5cdbf39defd334d82da58717b9e82c29c9ed5d")
