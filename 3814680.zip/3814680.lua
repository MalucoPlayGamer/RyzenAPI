-- Lua provided by SkyAPI 
-- Game: Huntsman
addappid(3814680)
addappid(3814681, 1, "828c7170d42e584b12fc6ae9fc5cdbf39defd334d82da58717b9e82c29c9ed5d")
