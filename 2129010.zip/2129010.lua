-- Lua provided by RyzenAPI
-- Game: Game: AppID 2129010

-- MAIN APPLICATION
addappid(2129010)
-- Game: addappid(2129010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129011, 1, "24d3861f63d987c2252e87c2efd378f2b96948b54bcdbe394ce8af67249bcc8b")
