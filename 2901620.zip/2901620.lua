-- Lua provided by RyzenAPI
-- Game: 2901620

-- MAIN APPLICATION
addappid(2901620)
-- Game: addappid(2901620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901621, 1, "b9a8a4960003bb2dca528aafd9e9ba7d5744d0ca58a83fd6941b373d5ae99a99")
