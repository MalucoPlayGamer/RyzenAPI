-- Lua provided by RyzenAPI
-- Game: Slobbish Dragon Princess 2

-- MAIN APPLICATION
addappid(1752150)
-- Game: addappid(1752150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752151, 1, "e7457b45d49ceed90e3ac11f5c7850a80b60494b73ed5177dd13858753a35ab1")
