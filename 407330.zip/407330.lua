-- Lua provided by RyzenAPI
-- Game: Sakura Dungeon

-- MAIN APPLICATION
addappid(407330)
addappid(487460)

-- MAIN APP DEPOTS / PACKAGES
addappid(407331, 1, "77a95be39a8ae433204433f7881a06a0bda402394fea9325853a9efc835e0769")
