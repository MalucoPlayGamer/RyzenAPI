-- Lua provided by RyzenAPI
-- Game: Anarchy Arcade

-- MAIN APPLICATION
addappid(266430)

-- MAIN APP DEPOTS / PACKAGES
addappid(266431, 1, "3d052e64a9f1c780d40de3395b9b7fbaac5736e3bd38fbc41eb05e00de390ada")
addappid(266432, 1, "dd353c7c24201628ac90878d27b8654e028c26333e9d11c819c46467303ea6a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
