-- Lua provided by RyzenAPI
-- Game: 25 Cadre of Death

-- MAIN APPLICATION
addappid(904860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(904861, 1, "766e47d920e107c8dc00d1d9f68aac3d3e96e590168426a74fbc2025ad32f38b")
