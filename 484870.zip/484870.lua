-- Lua provided by RyzenAPI
-- Game: 484870

-- MAIN APPLICATION
addappid(484870)
-- Game: addappid(484870)

-- MAIN APP DEPOTS / PACKAGES
addappid(484871, 1, "ea7713b7deca854600b6f7ff92a54460cd23f5d80a7da0676b9a910860863f25")
