-- Lua provided by RyzenAPI
-- Game: WWE 2K26

-- MAIN APPLICATION
addappid(3717070)
addappid(4125680)
addappid(4181550)
addappid(4181560)
addappid(4181570)
addappid(4181590)
addappid(4333560)
addappid(4357050)
addappid(4429680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3717071, 1, "1bf7a881a3e1aceec7d3d40622e631e3d7472b7fb4a051051a5e151bb63d7c21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4181540)
addappid(4181580)
addappid(4181610)
addappid(4181620)
addappid(4181630)
