-- Lua provided by RyzenAPI
-- Game: 3717070

-- MAIN APPLICATION
addappid(3717070)
addappid(4125680)
addappid(4181550)
addappid(4181560)
addappid(4181570)
addappid(4181590)
addappid(4333560)
addappid(4357050)
addappid(4429680)
-- Game: addappid(3717070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3717071, 1, "1bf7a881a3e1aceec7d3d40622e631e3d7472b7fb4a051051a5e151bb63d7c21")
