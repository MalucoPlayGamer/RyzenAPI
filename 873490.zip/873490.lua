-- Lua provided by RyzenAPI
-- Game: 不落城-Unconquered Castle

-- MAIN APPLICATION
addappid(873490)
-- Game: addappid(873490)

-- MAIN APP DEPOTS / PACKAGES
addappid(873491, 1, "081dfaad2cefc813b76e3038b0e01a94bcd4ffd952b1eadc08f5e458c8ff315a")
addappid(948910, 0, "089b3aa58a9e7fa5afc25ebb8ce14dedd235bf30da291b23d43cb21e9277337d")
