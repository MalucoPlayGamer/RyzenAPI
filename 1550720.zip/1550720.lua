-- Lua provided by SkyAPI 
-- Game: Fly Corp Demo
addappid(1550720)
addappid(1550721, 1, "2441f0b0d7c57e89e3e730c4c44a4b6e9480c89c0b2f6775958620a65372c252")
