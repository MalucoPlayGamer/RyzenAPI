-- Lua provided by RyzenAPI
-- Game: Fly Corp Demo

-- MAIN APPLICATION
addappid(1550720)
-- Game: addappid(1550720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550721, 1, "2441f0b0d7c57e89e3e730c4c44a4b6e9480c89c0b2f6775958620a65372c252")
