-- Lua provided by RyzenAPI
-- Game: Game: Fear Followers Demo

-- MAIN APPLICATION
addappid(3134270)
-- Game: addappid(3134270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134271, 1, "cccbf240498b1d4c3d6772680f35212213a30246b19c598042d121cdbe616445")
