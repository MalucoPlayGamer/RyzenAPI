-- Lua provided by RyzenAPI
-- Game: Game: AppID 722940

-- MAIN APPLICATION
addappid(722940)
-- Game: addappid(722940)

-- MAIN APP DEPOTS / PACKAGES
addappid(722941, 1, "a166b291e4eec22e202162f384c3096be997c913b20842668589d348fbe51644")
