-- Lua provided by RyzenAPI
-- Game: AppID 1246460

-- MAIN APPLICATION
addappid(1246460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246461, 1, "2d79f638bf60420283ef27bab0f75fcd4fce2c41b03de8fa1589f9fd94a49359")

