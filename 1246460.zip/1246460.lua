-- Lua provided by SkyAPI 
-- Game: AppID 1246460
addappid(1246460)
addappid(1246461, 1, "2d79f638bf60420283ef27bab0f75fcd4fce2c41b03de8fa1589f9fd94a49359")
