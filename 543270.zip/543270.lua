-- Lua provided by RyzenAPI
-- Game: Mr. Shadow

-- MAIN APPLICATION
addappid(543270)

-- MAIN APP DEPOTS / PACKAGES
addappid(543271,0,"07415cd0c91c095c5d8756b25971606fe8f459f370ea00738ee53f444b796988")
addappid(746450,0,"148d22ebd5ecbc1f201b1e7e097a8bd8e0fd4868450dda0983b69cdbcecd22b9")

