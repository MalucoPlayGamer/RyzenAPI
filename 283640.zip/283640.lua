-- Lua provided by RyzenAPI
-- Game: Game: AppID 283640

-- MAIN APPLICATION
addappid(283640)
-- Game: addappid(283640)

-- MAIN APP DEPOTS / PACKAGES
addappid(283641, 1, "9bb07dc1413dfdab7e73e7730848c64f8b54a906a58c58e8708383f3965216a7")
addappid(283642, 1, "1a4e4f92c5aea2ccdca7ceaabd4d3df1974be48952b3cef7bed117b772dec3ec")
addappid(283643, 1, "e2a720c6534df5c2478154a7da322b8af416ece44d1290f589261505f9473a97")
