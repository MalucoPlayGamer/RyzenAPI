-- 4566470's Lua and Manifest Created by Hubcap Manifest
-- Hentai Furry Goat
-- Created: August 17, 2026 at 14:36:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4566470) -- Hentai Furry Goat
-- MAIN APP DEPOTS
addappid(4566471, 1, "6947a8d9727dc6d7f508fdc638ae4eae82cdfb3dc487f3c3163d2275eaf87697") -- Depot 4566471
setManifestid(4566471, "6896425837879135537", 237945013)