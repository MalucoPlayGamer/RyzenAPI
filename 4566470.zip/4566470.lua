-- Lua provided by RyzenAPI
-- Game: Hentai Furry Goat

-- MAIN APPLICATION
addappid(4566470) -- Hentai Furry Goat

-- MAIN APP DEPOTS / PACKAGES
addappid(4566471, 1, "6947a8d9727dc6d7f508fdc638ae4eae82cdfb3dc487f3c3163d2275eaf87697") -- Depot 4566471

