-- Lua provided by RyzenAPI
-- Game: OHV

-- MAIN APPLICATION
addappid(1783780)
-- Game: addappid(1783780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783781, 1, "c86a6a9cbefa7cd76e6db48e0c3f74e432973bf7bd855e4936797a1842a64292")
