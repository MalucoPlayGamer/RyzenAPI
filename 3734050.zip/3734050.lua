-- Lua provided by RyzenAPI
-- Game: Time Space Rebuild-4K

-- MAIN APPLICATION
addappid(3734050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3734050,0,"2bae00c40fb24175198b8ab28dd97f2ee745917121e4df9f1968b417ea43d098")

