-- Lua provided by RyzenAPI
-- Game: AppID 509600

-- MAIN APPLICATION
addappid(509600)
-- Game: addappid(509600)

-- MAIN APP DEPOTS / PACKAGES
addappid(509601, 1, "0d454512479fecc9db9c2399b580be7b467b0af8563463e5b7935d9a2664821f")
addappid(509602, 1, "b48e8848e309399fc8ee8021ac9eb08c2e22bad216a56dfc17c4ef49d9f9d8cd")
addappid(509603, 1, "72b6cbbf2e07def57c02a94030fd15c104f60ddfca9ad2e722ce74098b1e941f")
