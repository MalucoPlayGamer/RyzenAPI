-- Lua provided by RyzenAPI
-- Game: Game: THE LAST BREATH

-- MAIN APPLICATION
addappid(2442490)
-- Game: addappid(2442490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442491, 1, "90ad5dc19a8c68341dc22d0a844d6d74f11068cfdd51fb11960c3166c4b1c715")
