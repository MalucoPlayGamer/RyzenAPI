-- Lua provided by RyzenAPI
-- Game: THE LAST BREATH

-- MAIN APPLICATION
addappid(2442490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442491, 1, "90ad5dc19a8c68341dc22d0a844d6d74f11068cfdd51fb11960c3166c4b1c715")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
