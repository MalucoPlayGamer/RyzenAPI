-- Lua provided by RyzenAPI
-- Game: The Last Gap

-- MAIN APPLICATION
addappid(4542980) -- The Last Gap

-- MAIN APP DEPOTS / PACKAGES
addappid(4542981, 1, "e2d7753e6633030bf771985b683bb978fc28bc364c531b24ce487e911ee74310") -- Depot 4542981

