-- 4542980's Lua and Manifest Created by Hubcap Manifest
-- The Last Gap
-- Created: August 10, 2026 at 14:56:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4542980) -- The Last Gap
-- MAIN APP DEPOTS
addappid(4542981, 1, "e2d7753e6633030bf771985b683bb978fc28bc364c531b24ce487e911ee74310") -- Depot 4542981
setManifestid(4542981, "1405686366378425400", 355510604)