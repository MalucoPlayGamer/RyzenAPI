-- Lua provided by RyzenAPI
-- Game: 857810

-- MAIN APPLICATION
addappid(857810)
-- Game: addappid(857810)

-- MAIN APP DEPOTS / PACKAGES
addappid(857811, 1, "bb1df0dac7f84cc14781eda3698fc60b6247e9e5d7e5db40708999b15a834ce3")
