-- Lua provided by RyzenAPI
-- Game: Exark

-- MAIN APP DEPOTS / PACKAGES
addappid(3435610, 1, "04081d2d68ac6ae79fc758bf2c5af2f157aa7bae3a46232daca58d923463bc7f")
addappid(3435611, 1, "8d8fb238e9c2af0af6c2d74a8032b3a762eececaf708780272c76cb0e8b38c06")

