-- Generated with Luie @ https://lua.tools/
-- 3435610 - Exark
-- Generated 2026-08-28 00:48:33 UTC
-- # Depots (Total/DLC/Shared): 3/2/0

-- Main AppID
addappid(3435610, 1, "04081d2d68ac6ae79fc758bf2c5af2f157aa7bae3a46232daca58d923463bc7f")

-- Main Depots
addappid(3435611, 1, "8d8fb238e9c2af0af6c2d74a8032b3a762eececaf708780272c76cb0e8b38c06")
setManifestid(3435611, "461290993120322197", 1580176942)

-- Missing Depots (We don't have the keys yet lol): 5103511, 5103512
