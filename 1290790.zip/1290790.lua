-- Lua provided by RyzenAPI
-- Game: Yardlings

-- MAIN APPLICATION
addappid(1290790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1290791, 1, "1e5362122603a7d51b96926ed5a8afde766d1664160368c39c53805e9dc7b6d6")

