-- Lua provided by RyzenAPI
-- Game: Royale King

-- MAIN APPLICATION
addappid(2631520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631521, 1, "d37daf69f8248da2dae31df18a15dfab0c0ce1623ed6fd5664954fc226d12d9a")
addappid(2631522, 1, "d9bab57e6dbfa1808eb8f2a2b56806d29e3cf2c270ba0cbba0a33e8112fa4adc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
