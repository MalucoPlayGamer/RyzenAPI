-- Lua provided by RyzenAPI
-- Game: Just Move Fall Dungeon Endless Abyss

-- MAIN APPLICATION
addappid(3856040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3856041,0,"73eb39cd2ebccd9f31719847bef74f6318beebd885879b9007391f0ae48e9c31")

