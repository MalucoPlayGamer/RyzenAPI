-- Lua provided by RyzenAPI
-- Game: AppID 2868840

-- MAIN APPLICATION
addappid(2868840)
-- Game: addappid(2868840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868841, 1, "ed043fd4ac0899cd0b5fc59d5407115ff4f87793b162ba16fe49c7e2893938ab")
addappid(2868842, 1, "7036cfd5ff85a70ca002aeddf573311c3906b0f7d8d83d099592e759ddca5b31")
addappid(2868843, 1, "6e4518ed758f09a3fb1c07ed1ef14a8ccfb4bac6e1fc452adc1e1d8a1c024e42")
