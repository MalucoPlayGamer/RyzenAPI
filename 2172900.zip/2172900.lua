-- Lua provided by RyzenAPI
-- Game: Game: Little Friends: Puppy Island

-- MAIN APPLICATION
addappid(2172900)
-- Game: addappid(2172900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172901, 1, "0898013863773d6bbfa86ba39840c099abc2c257511a792b5b74962b792e5037")
