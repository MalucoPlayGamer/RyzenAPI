-- Lua provided by RyzenAPI
-- Game: addappid(2465420)

-- MAIN APPLICATION
addappid(2465420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465421, 1, "ab54a3e324c50c69aaaefde898a64b043358b50c8c66693a0227769fa6ef5976")
