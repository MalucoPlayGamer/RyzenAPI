-- Lua provided by RyzenAPI
-- Game: Deer Journey

-- MAIN APPLICATION
addappid(1995240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1995241, 1, "d877da95677601044272538e9ea1bd4ba3a077a3f6f1b0eae7b91e0e2ee6af7e")

