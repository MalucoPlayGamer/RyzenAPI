-- Lua provided by RyzenAPI 
-- Game: Deer Journey
addappid(1995240)
addappid(1995241, 1, "d877da95677601044272538e9ea1bd4ba3a077a3f6f1b0eae7b91e0e2ee6af7e")
