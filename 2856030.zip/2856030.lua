-- Lua provided by RyzenAPI
-- Game: Beach Club Simulator 2024

-- MAIN APPLICATION
addappid(2856030)
-- Game: addappid(2856030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856031, 1, "b52efc48d48ee079c9b22d7f0aa8a9c0a3b1396ebf39f5d369a652cec149a72b")
