-- Lua provided by RyzenAPI
-- Game: 月白星斗 Playtest

-- MAIN APPLICATION
addappid(2978590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978591, 1, "59e367a3a16cb26b8ad096868397c1e467b339e6a12540664a446a5aec6b2501")
