-- Lua provided by RyzenAPI
-- Game: AppID 486310

-- MAIN APPLICATION
addappid(486310)

-- MAIN APP DEPOTS / PACKAGES
addappid(486311, 1, "55d4f89d2de478e56174b8d328c7f2cf6356a7a36e70ac6087570b7340014c25")
addappid(486312, 1, "285ea09481510676b6bc8d7085cef31097dad5949c2af0b0d64ddac9809a51b8")
addappid(486313, 1, "6dd1a18bc834b22c8c7acc444f771c85ba4860a01bd67f92ee1619b69a347681")
addappid(813460, 0, "0c08ebf285d2725c3e5a5b3455aeb94c94517b1561e0dee0e1392bc71316f980")
addappid(815410, 0, "eb73c1ff656f6f35183d7151f928e7ee5c0febfd19bdfe0d6681d5c7ba03ac62")
addappid(942280, 0, "6fdc2e276db144dd798489d84bf45f9d6fd77799f5fb87a792745fbf509a1fae")
addappid(1179550, 0, "84ff840229fe4bb248725d90d138b8d6caf028dc12fde39a21f890e7848a1e29")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2615950)
addappid(2615960)
addappid(2615970)
addappid(2615980)
addappid(2615990)
addappid(2616000)
addappid(2616010)
