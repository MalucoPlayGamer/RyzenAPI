-- Lua provided by SkyAPI 
-- Game: AppID 1057090
addappid(1057090)
addappid(1057091, 1, "f2095fc72f59315e1315914a5a349e23488d3e48897b16bc733e6cad2ca059a1")
