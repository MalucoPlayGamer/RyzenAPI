-- Lua provided by RyzenAPI
-- Game: AppID 1057090

-- MAIN APPLICATION
addappid(1057090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057091, 1, "f2095fc72f59315e1315914a5a349e23488d3e48897b16bc733e6cad2ca059a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
