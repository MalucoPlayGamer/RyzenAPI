-- Lua provided by RyzenAPI
-- Game: NecroNomNomNom: Eldritch Horror Dating

-- MAIN APPLICATION
addappid(2057360)
-- Game: addappid(2057360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057361, 1, "bb37333b7356718c74f76f27f79b3ac5f724d438038fd021cd73909c9260c0f7")
