-- Lua provided by RyzenAPI
-- Game: Grimshade

-- MAIN APPLICATION
addappid(858100)

-- MAIN APP DEPOTS / PACKAGES
addappid(858101,0,"ded30b19c66716c7ecdd7c21f95dee7ac61ed80b3c154f4e1e4a1b292ee96972")

