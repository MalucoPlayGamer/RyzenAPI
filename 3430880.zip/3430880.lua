-- Lua provided by RyzenAPI
-- Game: 3430880

-- MAIN APPLICATION
addappid(3430880)
addappid(3430881)
addappid(3430882)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430883,0,"2e94b04f562757a91cbf9543eb0506ac8b66f317056c8bce50a9bd94b9d2064a")
