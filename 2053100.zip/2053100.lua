-- Lua provided by RyzenAPI
-- Game: addappid(2053100)

-- MAIN APPLICATION
addappid(2053100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053101, 1, "2bb9db9ebc01684cc60836198bfb6e1cd7d7e214d4707f26cfe21b0c08e8ec1d")
addappid(2053103, 1, "1e392e8ff95d7f73cccfe0a7d1793d26e1f4447cf152e264cf65b644adc88012")
