-- Lua provided by RyzenAPI
-- Game: Peach Hills Division

-- MAIN APPLICATION
addappid(2191210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191211, 1, "4226dc1b8476b0a339b42b11bdbee9b94811cc78846624fef7ac6b05fbb2966f")

