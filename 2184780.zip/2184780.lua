-- Lua provided by RyzenAPI
-- Game: Train1999 Demo

-- MAIN APPLICATION
addappid(2184780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184781, 1, "bb3ae379687e2bb49e395aec6f9bcc22b50742a017d1c29cdda02d4742f84ade")
