-- Lua provided by RyzenAPI
-- Game: Game: Furry Feet 2

-- MAIN APPLICATION
addappid(2625650)
-- Game: addappid(2625650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625651, 1, "4fee94f8bcce8d800ad8a5556d62d33b8c1edf779fff2388bb76978bfafc7a4d")
addappid(2894810, 0, "e6e918867e13142e113bf0a7f5d5d6e4d0b2b36a865cf869e438a64338333389")
