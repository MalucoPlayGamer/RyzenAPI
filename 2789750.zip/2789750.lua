-- Lua provided by RyzenAPI
-- Game: addappid(2789750)

-- MAIN APPLICATION
addappid(2789750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789751, 1, "b66f6246c4aec87611ef8537cface22d81dd0babaa40b15b0a28a7b9d89d330c")
