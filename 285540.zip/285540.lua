-- Lua provided by RyzenAPI
-- Game: 285540

-- MAIN APPLICATION
addappid(285540)
-- Game: addappid(285540)

-- MAIN APP DEPOTS / PACKAGES
addappid(285541, 1, "6894615d71a4d6d86a4c307a0f34e08d1b2f28a3ab4f852a8968c1d846906887")
