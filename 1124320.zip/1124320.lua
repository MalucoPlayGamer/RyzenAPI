-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1124320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124320,0,"84fb91582af18197ecf5b0d52bb71058693b67cf0ea82020bc62a296111f803b")

