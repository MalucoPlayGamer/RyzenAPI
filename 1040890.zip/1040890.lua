-- Lua provided by SkyAPI 
-- Game: Slime Simulator Games
addappid(1040890)
addappid(1040891, 1, "fa13cf5565aed6b24a5732674354eeaa0c4a07a7e79073ddcd6515c97c41ad21")
addappid(1040892, 1, "993cc761dde88595527ed326ce97c192d024033f2dc83c0b5cd4a2884159bbba")
