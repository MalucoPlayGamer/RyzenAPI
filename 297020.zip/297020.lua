-- Lua provided by RyzenAPI
-- Game: AppID 297020

-- MAIN APPLICATION
addappid(297020)

-- MAIN APP DEPOTS / PACKAGES
addappid(297021, 1, "7957393ed52b4e280679ae349ab2c1ab9eb02c6c9536cba4a92077ab5dbf0cf7")
addappid(464970, 0, "fa07eae2488d9ce6b654278dfeccc8eb7fa4d4dfa44b44508995e44277b1ff2e")
