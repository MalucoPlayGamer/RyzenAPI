-- Lua provided by RyzenAPI
-- Game: A Rite from the Stars

-- MAIN APPLICATION
addappid(792370)

-- MAIN APP DEPOTS / PACKAGES
addappid(792371,0,"4edb46518c35a49a2015d623eba5ea190adf5a2495c1e1be843ed55fef14c81d")

