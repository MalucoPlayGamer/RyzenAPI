-- Lua provided by RyzenAPI
-- Game: 1584760

-- MAIN APPLICATION
addappid(1584760)
-- Game: addappid(1584760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584761, 1, "e4cdabc481536a4278124de0e42b9c67238b99b1d1c0b5c490a235518c1dd117")
