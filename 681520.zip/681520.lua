-- Lua provided by RyzenAPI
-- Game: The Rodinia Project

-- MAIN APPLICATION
addappid(681520)

-- MAIN APP DEPOTS / PACKAGES
addappid(681521,0,"c967ea22a14edecdd574de701e0d1faeb50dd7d16cb79096a764e1206157f625")

