-- Lua provided by RyzenAPI
-- Game: Trafic Road Rush

-- MAIN APPLICATION
addappid(976850)

-- MAIN APP DEPOTS / PACKAGES
addappid(976851, 1, "aa50c466d17651e0d97efc1d44fc4f3aae73e777f65437e14c29f9f350fe90f5")

