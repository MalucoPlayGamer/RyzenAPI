-- Lua provided by RyzenAPI
-- Game: Parcel Simulator

-- MAIN APPLICATION
addappid(2424010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424011, 1, "71e36409b0b470ee13b0613adc2c1467c1547fd8eed25a2e2771ec8c230f1aed")
