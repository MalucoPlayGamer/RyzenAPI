-- Lua provided by RyzenAPI
-- Game: Game: Call of Juarez

-- MAIN APPLICATION
addappid(3020)
-- Game: addappid(3020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021, 1, "4b079596230beba0ed878fb301f655a022b655a4889e1f270872db208232de21")
addappid(3022, 1, "9299584187e97949ab69d6308e2606e25c1ff500e0e9ee7cc574bcb92435a5a4")
addappid(3023, 1, "1b81dde606c7baefb0400442805d3b61197a68c4127980a2b04582f7f3978db7")
addappid(3024, 1, "3969ac09b67e412bd46726e2efe2dfed7ce6ce00e8007e05044a52df9e3984ac")
addappid(3025, 1, "77fbcbcf3d3e7cd841325d14e586fbbb7dc1d8618e7c6d18469e11307bf0bd14")
addappid(3026, 1, "aace1422ac3aa72fca2ec77622b6c396dcef54eab28f59d2395e6b401a0f8484")
addappid(3027, 1, "0c92d52b172d18c6bee0da8106bfe9ee8226373f3e80b7633f5000f19c715da1")
