-- Lua provided by RyzenAPI
-- Game: Smalland: Survive the Wilds Soundtrack

-- MAIN APPLICATION
addappid(3385510)
-- Game: addappid(3385510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3385511, 1, "37a3f6974653dba1c475694d2e76eea55ef2ac4ccdf55bebd262c8b61730d4c5")
