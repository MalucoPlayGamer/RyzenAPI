-- Lua provided by SkyAPI 
-- Game: Kamimachi Site - Dating story
addappid(989580)
addappid(989581, 1, "443726899fd9176ec47c9d3d5a82530046ce8d3b343779130d4b8a5bcc3a2d11")
addappid(989584, 1, "4a4e3076c724d9c720e96b6524d15414fc8e51fcc62fb58fc8a8b68bb16c18e1")
addappid(989585, 1, "84c9884137eff58cfe3be15823ed0bef721ce660037bc6f5f9ed326188a11705")
