-- Lua provided by RyzenAPI
-- Game: Saleblazers

-- MAIN APPLICATION
addappid(1419850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419851, 1, "0a55957bc94d9449b32b00478cc33206b02bea57467d367badd10e05b4108a44")
addappid(1419852, 1, "66ef23d25cff9bc223d0b614e9fad2a8dbe25786243a14f1e07fcb8b4861a4ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2012410)
