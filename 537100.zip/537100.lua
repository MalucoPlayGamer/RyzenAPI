-- Lua provided by RyzenAPI
-- Game: Shuffle!

-- MAIN APPLICATION
addappid(537100)

-- MAIN APP DEPOTS / PACKAGES
addappid(537101, 1, "1242ee25f2d3a6d7db518a0c4ba684ea1e60c7208ccfbfb30e0c94eff5266944")

