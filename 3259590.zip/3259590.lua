-- Lua provided by RyzenAPI
-- Game: Lost In Static Demo

-- MAIN APPLICATION
addappid(3259590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3259591, 1, "5df98ca724a530c29fca82ece758b1582b6de8ef2beaae49f8801fb1f48655af")

