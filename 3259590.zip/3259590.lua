-- Lua provided by RyzenAPI 
-- Game: AppID 3259590
addappid(3259590)
addappid(3259591, 1, "5df98ca724a530c29fca82ece758b1582b6de8ef2beaae49f8801fb1f48655af")
