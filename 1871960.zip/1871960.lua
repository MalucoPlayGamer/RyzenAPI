-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1871960)
-- Game: addappid(1871960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871960,0,"93fb58964a84c31a721bbb52a9af08b4bc39fd35e0f6f2bb51700e7b1bbec298")
