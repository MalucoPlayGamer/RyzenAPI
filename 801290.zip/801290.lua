-- Lua provided by RyzenAPI
-- Game: Game: AppID 801290

-- MAIN APPLICATION
addappid(801290)
-- Game: addappid(801290)

-- MAIN APP DEPOTS / PACKAGES
addappid(801291, 1, "e56db289229de0e078365dafd22618699da05061024e55d3a862e70ea38644d7")
