-- Lua provided by RyzenAPI
-- Game: Thanatos

-- MAIN APPLICATION
addappid(493440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(493441, 1, "88fc813a218e5ac442603fe3801f12b9ce8c009a0af04b3f9698b80842bc1ef1")

