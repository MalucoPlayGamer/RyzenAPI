-- Lua provided by RyzenAPI
-- Game: AppID 493440

-- MAIN APPLICATION
addappid(493440)
-- Game: addappid(493440)

-- MAIN APP DEPOTS / PACKAGES
addappid(493441, 1, "88fc813a218e5ac442603fe3801f12b9ce8c009a0af04b3f9698b80842bc1ef1")
