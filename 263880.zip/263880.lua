-- Lua provided by RyzenAPI
-- Game: Aqua Kitty - Milk Mine Defender

-- MAIN APPLICATION
addappid(263880)

-- MAIN APP DEPOTS / PACKAGES
addappid(263881, 1, "5dd0e7a67f690ff6bf995eb21ec12689e59738e0817a08da2bd13d7ea009b5d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
