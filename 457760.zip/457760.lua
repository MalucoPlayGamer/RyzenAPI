-- Lua provided by RyzenAPI
-- Game: Game: The Signal From Tölva

-- MAIN APPLICATION
addappid(457760)
-- Game: addappid(457760)

-- MAIN APP DEPOTS / PACKAGES
addappid(457761, 1, "dc782026ff6754288a77412f1f1d4276340522f4e51e0732f2939f6193a6900d")
addappid(457762, 1, "6b7b429704ead54a1c30fb63bf0a836e35311b65a2558bd57888f787fa500ada")
addappid(457763, 1, "e2c20e0a1450d35c1dd5a62579f5e83875ef3188a2c3debc0e9910f24a15d49f")
