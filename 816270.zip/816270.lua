-- Lua provided by RyzenAPI
-- Game: Sounds of Verity

-- MAIN APPLICATION
addappid(816270)

-- MAIN APP DEPOTS / PACKAGES
addappid(816271, 1, "5740732827bf1382d1d36a2c5d14f3cb0498ddd5787892e17c73053bf923a90a")

