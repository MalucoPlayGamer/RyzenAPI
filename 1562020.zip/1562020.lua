-- Lua provided by RyzenAPI
-- Game: Game: Abyss of Neptune

-- MAIN APPLICATION
addappid(1562020)
-- Game: addappid(1562020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562021, 1, "530a2ff288df1d8d8b1d79f836e0a0f6063249fa6bd9726a43b750b63746db26")
