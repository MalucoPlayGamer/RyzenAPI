-- Lua provided by RyzenAPI
-- Game: Abyss of Neptune

-- MAIN APPLICATION
addappid(1562020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1562021, 1, "530a2ff288df1d8d8b1d79f836e0a0f6063249fa6bd9726a43b750b63746db26")

