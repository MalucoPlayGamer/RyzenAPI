-- Lua provided by RyzenAPI
-- Game: Roman's Christmas / 罗曼圣诞探案集

-- MAIN APPLICATION
addappid(926340)

-- MAIN APP DEPOTS / PACKAGES
addappid(926341, 1, "766e7d27ef7ff71889fb79d865627398fa5a8017f56882139339da3354f0c386")
