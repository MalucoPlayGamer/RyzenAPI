-- Lua provided by RyzenAPI
-- Game: My Harem - Artbook 18+

-- MAIN APPLICATION
addappid(1263250)
-- Game: addappid(1263250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263250,0,"8cfc1c74a3db689b3a9728f8226e90e44c503243e32ad7a521c97c2dbe881b85")
