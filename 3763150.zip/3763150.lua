-- Lua provided by RyzenAPI
-- Game: Game: Gorilla Smash

-- MAIN APPLICATION
addappid(3763150)
-- Game: addappid(3763150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3763151, 1, "575cb3f87960943e9a22c3d131270330a046134637d0d818020d91d16137e066")
