-- Lua provided by RyzenAPI
-- Game: Multiplayer Platform Golf

-- MAIN APPLICATION
addappid(2263920)
-- Game: addappid(2263920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263922,0,"47516fd72708b232cbedd4155c61954d67bde24bb3f0582553ecdc460f201b34")
