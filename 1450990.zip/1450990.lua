-- Lua provided by RyzenAPI
-- Game: 1450990

-- MAIN APPLICATION
addappid(1450990)
-- Game: addappid(1450990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450990,0,"cc986f17a20b8e5d094f55f7ad8fb6a2b475e6a4fdc0c665a8d5a5ef8b3a40ba")
