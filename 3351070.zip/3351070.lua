-- Lua provided by RyzenAPI
-- Game: ConsTance

-- MAIN APPLICATION
addappid(3351070)
-- Game: addappid(3351070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351071, 1, "4640ec16bfc36e6e45f04a331a4aaa6de918488154c8a2367ead2133244adbe6")
