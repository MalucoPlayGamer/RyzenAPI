-- Lua provided by RyzenAPI
-- Game: AppID 331120

-- MAIN APPLICATION
addappid(331120)
-- Game: addappid(331120)

-- MAIN APP DEPOTS / PACKAGES
addappid(331121, 1, "0d1d103fc77eb898800f699d766365811ecb69768a222d104aba54438dc27fbb")
