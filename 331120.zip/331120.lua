-- Lua provided by SkyAPI 
-- Game: AppID 331120
addappid(331120)
addappid(331121, 1, "0d1d103fc77eb898800f699d766365811ecb69768a222d104aba54438dc27fbb")
