-- Lua provided by RyzenAPI
-- Game: *NEW* SCUFFED EPIC BHOP SIMULATOR 2023 (POG CHAMP)

-- MAIN APPLICATION
addappid(1465860)
addappid(1492920)
addappid(1500080)
addappid(1504530)

