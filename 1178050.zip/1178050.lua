-- Lua provided by RyzenAPI
-- Game: AppID 1178050

-- MAIN APPLICATION
addappid(1178050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178051, 1, "227bbde1a07fb08e634dc3a913d114e5eac353a489f7b89cf9726d7cae16d923")
