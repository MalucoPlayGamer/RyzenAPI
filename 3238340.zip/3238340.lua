-- Lua provided by RyzenAPI
-- Game: AppID 3238340

-- MAIN APPLICATION
addappid(3238340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238341, 1, "b4fe5d24163a1294372cbecc309bfcd40ed1ca58a9425b68d96cf9e7b1c3a6c0")
