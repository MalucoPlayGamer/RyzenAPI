-- Lua provided by RyzenAPI
-- Game: 2430300

-- MAIN APPLICATION
addappid(2430300)
-- Game: addappid(2430300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430301, 1, "2560a30d2ba228236ba455ff829fa62b74ca54369d992dcdcee90441e4fc9050")
