-- Lua provided by RyzenAPI
-- Game: Deep Space Outpost

-- MAIN APPLICATION
addappid(1712110) -- Deep Space Outpost

-- MAIN APP DEPOTS / PACKAGES
addappid(1712111, 1, "e40984c75b5981d0c726bdee87c9ee9eec27232bf251d945f751700698a83aa6") -- Depot 1712111

