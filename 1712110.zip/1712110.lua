-- 1712110's Lua and Manifest Created by Hubcap Manifest
-- Deep Space Outpost
-- Created: August 12, 2026 at 01:02:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1712110) -- Deep Space Outpost
-- MAIN APP DEPOTS
addappid(1712111, 1, "e40984c75b5981d0c726bdee87c9ee9eec27232bf251d945f751700698a83aa6") -- Depot 1712111
setManifestid(1712111, "6097904505835373602", 81693440)