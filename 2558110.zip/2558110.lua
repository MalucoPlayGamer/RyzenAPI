-- Lua provided by RyzenAPI
-- Game: Skibidi Toilet Skibidi Boom

-- MAIN APPLICATION
addappid(2558110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558111, 1, "dfdbed0e4d685ba6bdfd33c1e079b6f9442062fee01dfb9f4d3cd71b423d69fe")
