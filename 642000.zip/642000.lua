-- Lua provided by RyzenAPI
-- Game: Regenesis Arcade Lite

-- MAIN APPLICATION
addappid(642000)
-- Game: addappid(642000)

-- MAIN APP DEPOTS / PACKAGES
addappid(642001, 1, "1fd0456d3f86781d665c613de1e16d25ae68cd746ba563d7e6af4ca2399d47b7")
