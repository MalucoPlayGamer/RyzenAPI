-- Lua provided by RyzenAPI
-- Game: 할 짓 없는 군주님

-- MAIN APPLICATION
addappid(2817210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817211, 1, "ae3395c97075dea5b251d561604c3dcf3f41425085253c271fe069bdb2fe6418")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
