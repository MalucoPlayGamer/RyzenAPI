-- Lua provided by RyzenAPI
-- Game: Catch a Falling Star

-- MAIN APPLICATION
addappid(451880)

-- MAIN APP DEPOTS / PACKAGES
addappid(451881, 1, "3f73e2649f8bffbcd6b38edb8853b74aca559c30a2d6e49d8c475faeed3ef09a")
