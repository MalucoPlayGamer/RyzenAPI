-- 4843210's Lua and Manifest Created by Hubcap Manifest
-- Hell Deck
-- Created: August 04, 2026 at 09:24:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4843210) -- Hell Deck
-- MAIN APP DEPOTS
addappid(4843212, 1, "b4e654863cfc9a19ce1a9803016df2c50d962fc7e399d6fd9a63888e0ad868c3") -- Depot 4843212
setManifestid(4843212, "8391204514833122851", 885062553)
addappid(4843213, 1, "31b590cd32a085f0a25cfebdba1adbf43b40b53bee924b3be42ae43177cf9705") -- Depot 4843213
setManifestid(4843213, "301009560465059863", 1173371184)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4843211) -- Depot 4843211 (empty depot)
-- addappid(4843214) -- Depot 4843214 (empty depot)