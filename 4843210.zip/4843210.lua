-- Lua provided by RyzenAPI
-- Game: Hell Deck

-- MAIN APPLICATION
addappid(4843210) -- Hell Deck
-- addappid(4843211) -- Depot 4843211 (empty depot)
-- addappid(4843214) -- Depot 4843214 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(4843212, 1, "b4e654863cfc9a19ce1a9803016df2c50d962fc7e399d6fd9a63888e0ad868c3") -- Depot 4843212
addappid(4843213, 1, "31b590cd32a085f0a25cfebdba1adbf43b40b53bee924b3be42ae43177cf9705") -- Depot 4843213

