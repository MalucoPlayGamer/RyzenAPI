-- Lua provided by SkyAPI 
-- Game: Survival & Horror: Hangman's Rope
addappid(2358790)
addappid(2358791, 1, "6aba2e692958b7769ad32cce63c3e14d793b6018da7ca5f6d8c15cb16f9ce440")
