-- Lua provided by RyzenAPI
-- Game: Game: Survival & Horror: Hangman's Rope

-- MAIN APPLICATION
addappid(2358790)
-- Game: addappid(2358790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358791, 1, "6aba2e692958b7769ad32cce63c3e14d793b6018da7ca5f6d8c15cb16f9ce440")
