-- Lua provided by RyzenAPI
-- Game: 899908

-- MAIN APPLICATION
addappid(899908)

-- MAIN APP DEPOTS / PACKAGES
addappid(899908,0,"58dba26e1f18d159dcb41b7d199a240933a6c95f59f4b2d580676f23ccae4ae3")

