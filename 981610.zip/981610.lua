-- Lua provided by RyzenAPI
-- Game: Dark Fantasy: Artwork and Music

-- MAIN APPLICATION
addappid(981610)
-- Game: addappid(981610)

-- MAIN APP DEPOTS / PACKAGES
addappid(981610,0,"b3affb6b4740afeba24d648fc7c369d81ca81b95e02312697e8cee3b35154671")
