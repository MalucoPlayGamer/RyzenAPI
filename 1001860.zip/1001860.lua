-- Lua provided by RyzenAPI
-- Game: Casual Desktop Game

-- MAIN APPLICATION
addappid(1001860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001861, 1, "1455cd136f5c5f8d79698ede9729f407512e3beac696b7334d06fd7a377240d1")

