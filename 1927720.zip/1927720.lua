-- Lua provided by RyzenAPI
-- Game: AppID 1927720

-- MAIN APPLICATION
addappid(1927720)
-- Game: addappid(1927720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927721, 1, "11be65e06d8be73b1734f1008690fdce6cf649de649dca1948ce0bec7c25920e")
