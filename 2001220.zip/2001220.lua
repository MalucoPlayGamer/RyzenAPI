-- Lua provided by RyzenAPI
-- Game: addappid(2001220)

-- MAIN APPLICATION
addappid(2001220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001221, 1, "8edc060329f3c0f84b22f9ef7a0d7d8a8bfde1c5a77a56c836494f4431b774e9")
