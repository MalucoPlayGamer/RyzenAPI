-- Lua provided by RyzenAPI
-- Game: Haunted Hotel: Charles Dexter Ward Collector's Edition

-- MAIN APPLICATION
addappid(866740)

-- MAIN APP DEPOTS / PACKAGES
addappid(866741, 1, "77b6ae66bd9288313c2f1583e204e34c038cd59a1e86b21112976dc0f8e14f0a")
