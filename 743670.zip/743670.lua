-- Lua provided by RyzenAPI 
-- Game: Senpa.io
addappid(743670)
addappid(743671, 1, "b99f0ca52d1b02009a21ac88dcd1cc209284591d9091fb5c0535603bdcd3398d")
