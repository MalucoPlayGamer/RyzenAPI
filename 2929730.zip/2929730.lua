-- Lua provided by RyzenAPI
-- Game: addappid(2929730)

-- MAIN APPLICATION
addappid(2929730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929731, 1, "feb9a59a7445b3b1b7987c883f4d051d32a4ddf6e7e6120943838b72e3affc4f")
