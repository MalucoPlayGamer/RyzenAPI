-- Lua provided by RyzenAPI
-- Game: Demonfo

-- MAIN APPLICATION
addappid(3446960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446961, 1, "7fa3de35a828096a3b5cf930420dbc15efcb3c7ab2c51c65891a4d6bb3a0b685")
