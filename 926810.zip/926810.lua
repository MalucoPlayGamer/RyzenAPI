-- Lua provided by RyzenAPI
-- Game: Dark Places

-- MAIN APPLICATION
addappid(926810)

-- MAIN APP DEPOTS / PACKAGES
addappid(926811, 1, "fbcb5b2a3cdcbae5dc251f05a89f27e696254f50bfb8efde7445a4a1a63189b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(926830)
addappid(984970)
