-- Lua provided by RyzenAPI
-- Game: Game: Dark Places

-- MAIN APPLICATION
addappid(926810)
-- Game: addappid(926810)

-- MAIN APP DEPOTS / PACKAGES
addappid(926811, 1, "fbcb5b2a3cdcbae5dc251f05a89f27e696254f50bfb8efde7445a4a1a63189b7")
