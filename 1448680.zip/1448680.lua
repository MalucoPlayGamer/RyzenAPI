-- Lua provided by RyzenAPI
-- Game: 1448680

-- MAIN APPLICATION
addappid(1448680)
-- Game: addappid(1448680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448681, 1, "5e5a84abfafbbd02b4f29c5fbadea27044d7b8980db17e860255aef53c7c9079")
