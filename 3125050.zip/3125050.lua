-- Lua provided by RyzenAPI
-- Game: Lust Fantasy 💜

-- MAIN APPLICATION
addappid(3125050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125051, 1, "594f3226e04ed4ba4104698fbbd574fd4cbfa1a03cbf2bf72617ba79a66266a6")

