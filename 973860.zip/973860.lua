-- Lua provided by RyzenAPI
-- Game: addappid(973860)

-- MAIN APPLICATION
addappid(973860)

-- MAIN APP DEPOTS / PACKAGES
addappid(973861, 1, "98a2965eb7661165ed4122512696b8f2d5f3b7ab1d1accad1c2b5ae6ec56010e")
