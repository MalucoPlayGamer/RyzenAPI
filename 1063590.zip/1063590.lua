-- Lua provided by RyzenAPI
-- Game: Rogue Masters

-- MAIN APPLICATION
addappid(1063590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063591, 1, "6aa269e41a71a6c9a558bedd4ebace3769c1852b0c6ff9d674afa82fdc6e0e4a")

