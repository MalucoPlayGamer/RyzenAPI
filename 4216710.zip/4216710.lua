-- Lua provided by RyzenAPI
-- Game: Jackpot Valley Slots

-- MAIN APPLICATION
addappid(4216710)

