-- Lua provided by RyzenAPI
-- Game: 1Quest

-- MAIN APPLICATION
addappid(332710)

-- MAIN APP DEPOTS / PACKAGES
addappid(332711, 1, "1d50fbece5b1c6a95bc0f6ac984f133fa3e83f1012912409c3d77c70ae853335")

