-- Lua provided by RyzenAPI
-- Game: Upload Simulator Silicon

-- MAIN APPLICATION
addappid(2542800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542801, 1, "f5b615a96f7bea9ea324dd3461bf4ed1df481d9c9f4289db1c00a9138f8a0447")

