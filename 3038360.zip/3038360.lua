-- Lua provided by RyzenAPI
-- Game: Pharmacy Simulator Prologue

-- MAIN APPLICATION
addappid(3038360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038361, 1, "794b07119420bc535beee2e57f44c97738db0928d5b59a02db1230709776e7ce")

