-- Lua provided by RyzenAPI
-- Game: Alexandria - Port of Worlds

-- MAIN APPLICATION
addappid(1946150)
addappid(1946360)
-- Game: addappid(1946150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946151, 1, "f33a54c5d3f1dd4573121c58a01d4f966e0b4a10cc645ae6097a59b97fa93021")
