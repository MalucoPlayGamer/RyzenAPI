-- Lua provided by RyzenAPI
-- Game: Knightly Passions: In the Grip of Ice

-- MAIN APPLICATION
addappid(3163410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163410,0,"ba44913a416e099e0ec56db09e8f878791582679c53da635c5b8344e1b9e6ae0")
