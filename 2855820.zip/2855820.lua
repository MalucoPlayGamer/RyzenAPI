-- Lua provided by SkyAPI 
-- Game: Lethal Women: World of Femdom and Espionage
addappid(2855820)
addappid(2855821, 1, "a6ff97cc0b27a02885197cab736ee0e48979c1cd73ac9838dff2e8509909eab7")
