-- Lua provided by RyzenAPI
-- Game: addappid(2855820)

-- MAIN APPLICATION
addappid(2855820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2855821, 1, "a6ff97cc0b27a02885197cab736ee0e48979c1cd73ac9838dff2e8509909eab7")
