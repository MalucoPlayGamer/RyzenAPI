-- Lua provided by RyzenAPI
-- Game: 2636560

-- MAIN APPLICATION
addappid(2636560)
-- Game: addappid(2636560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636561, 1, "35c5b67135d0fe7b426c26730df9ef7a154e03342b093ee7debf684a54215830")
