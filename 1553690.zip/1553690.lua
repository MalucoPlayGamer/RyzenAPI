-- Lua provided by RyzenAPI
-- Game: How does it work!?

-- MAIN APPLICATION
addappid(1553690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1553691, 1, "430d33722ce7952d1cff3f0c7cf7c9ea81771c2549c8e0cc146307d78d4d4a1c")

