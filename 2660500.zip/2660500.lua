-- Lua provided by RyzenAPI
-- Game: Game: Devilish Blind Date

-- MAIN APPLICATION
addappid(2660500)
-- Game: addappid(2660500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660501, 1, "111f636a267fa7fc579796e2c6853480a780d6a0335e57fab4ac92386d49c567")
