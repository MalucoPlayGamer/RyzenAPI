-- Lua provided by RyzenAPI
-- Game: 1291660

-- MAIN APPLICATION
addappid(1291660)
-- Game: addappid(1291660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291661, 1, "2a68fa2210e2a10bbd3894196e41c65290716bfd684a07b5ce4056abfc788e76")
