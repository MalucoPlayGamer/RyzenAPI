-- Lua provided by SkyAPI 
-- Game: 花都之恋
addappid(1846630)
addappid(1846631, 1, "92da98b6afc27149dbeb71c07f4ea61c4166d3a5725f0f9572b882e8fd0ec293")
addappid(2457620, 0, "5c83432f11d8b004416203fe71cdc57b4cc7eb97f3acac9cd2f311d243aea2fa")
