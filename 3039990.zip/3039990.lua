-- Lua provided by RyzenAPI
-- Game: Game: KannaSchool

-- MAIN APPLICATION
addappid(3039990)
-- Game: addappid(3039990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039991, 1, "ff8af1da02cd16d0b9ec367bc536128062eea4e5e9fa2ae373e6a3d0639804f1")
