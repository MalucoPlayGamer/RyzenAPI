-- Lua provided by RyzenAPI
-- Game: Game: AppID 1201840

-- MAIN APPLICATION
addappid(1201840)
-- Game: addappid(1201840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201841, 1, "e971e7e9f104bfd6853ce261902c1a1a4e2707b13676ecd890fd9af5a297079a")
