-- Lua provided by RyzenAPI
-- Game: Antagonist

-- MAIN APPLICATION
addappid(585260)

-- MAIN APP DEPOTS / PACKAGES
addappid(585261,0,"f5370d37645a7cf8487280bb0e80d06697da60b7bb79eec0272b6c2c4aa9a2c3")

