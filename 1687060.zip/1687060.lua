-- Lua provided by RyzenAPI
-- Game: Game: Lord of the Click 2

-- MAIN APPLICATION
addappid(1687060)
-- Game: addappid(1687060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687061, 1, "469d45d019a5024e4fcd8816456153b61794bc92a8a82eca60b6a3feb503b28f")
