-- Lua provided by RyzenAPI
-- Game: Bite At The Museum

-- MAIN APPLICATION
addappid(1607620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607621, 1, "b140285fab7bc931ea90f5fa18d59e406dbb61a61bac34bfaa32377b5913c099")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
