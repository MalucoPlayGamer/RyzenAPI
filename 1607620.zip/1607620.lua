-- Lua provided by RyzenAPI
-- Game: Bite At The Museum

-- MAIN APPLICATION
addappid(1607620)
-- Game: addappid(1607620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607621, 1, "b140285fab7bc931ea90f5fa18d59e406dbb61a61bac34bfaa32377b5913c099")
