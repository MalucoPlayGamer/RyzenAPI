-- Lua provided by RyzenAPI
-- Game: Game: Super Arter

-- MAIN APPLICATION
addappid(2136060)
-- Game: addappid(2136060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136061, 1, "bad544af25dc012c4ae8d3ce6cc2ffb2c28de78ea094d15a1a981d84238dca35")
