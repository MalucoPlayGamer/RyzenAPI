-- Lua provided by RyzenAPI
-- Game: Guardians: Royal Journey

-- MAIN APPLICATION
addappid(1661130)
-- Game: addappid(1661130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661131, 1, "3fe48080430ce07bee987a217dd501144e8f02c82a8a82e5fbcf85e793f30de8")
