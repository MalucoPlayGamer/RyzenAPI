-- Lua provided by RyzenAPI
-- Game: Airport CEO

-- MAIN APPLICATION
addappid(673610)
-- Game: addappid(673610)

-- MAIN APP DEPOTS / PACKAGES
addappid(673611, 1, "9f0b556d411e7ebde77ca0569d8faa85396635a8e9b4ea272e9613540539e869")
addappid(673616, 1, "596071bb27eb0d9f0963e79976fa22ab4b23f697685afa0dee1811c5b58d28dc")
