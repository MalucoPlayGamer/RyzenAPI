-- Lua provided by RyzenAPI
-- Game: Game: Eden Crafters Demo

-- MAIN APPLICATION
addappid(2973900)
-- Game: addappid(2973900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973901, 1, "e8827a4e97b347bb459b2395dbd012f6b1125ed279f1b52a08e71bc065a2a1c1")
