-- Lua provided by RyzenAPI
-- Game: addappid(1228760)

-- MAIN APPLICATION
addappid(1228760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228761, 1, "f2caeea2a90b10321548f8a74b5858e03a449f4a51219bf9f308a468c9a1d47f")
