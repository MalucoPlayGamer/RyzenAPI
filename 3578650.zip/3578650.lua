-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Tsundere ~Prideful and Competitive~ GP-03

-- MAIN APPLICATION
addappid(3578650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578651, 1, "66f3d816585e6fddd5360429d58f0e70d8fd364556450bf7c386af00203000af")

