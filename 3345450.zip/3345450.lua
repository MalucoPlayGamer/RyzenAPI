-- Lua provided by RyzenAPI
-- Game: addappid(3345450)

-- MAIN APPLICATION
addappid(3345450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345451, 1, "5dd67ba4de593ef6a436e82279b0a5f8e937f580f529acff6fa7ca26fde428bd")
