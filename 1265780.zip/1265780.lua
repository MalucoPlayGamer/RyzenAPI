-- Lua provided by RyzenAPI
-- Game: AppID 1265780

-- MAIN APPLICATION
addappid(1265780)
addappid(2374460)
addappid(2374461)
addappid(2374462)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1265781, 1, "d6efa315d9ac1c7366b52d132e072b9580b6735097724994b4f38e98581a2500")
addappid(2374463, 0, "a9ffc1c757ce562741fd4fc0ec03f45e443703333609b70ef4abe0277676c74c")

