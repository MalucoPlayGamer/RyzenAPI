-- Lua provided by RyzenAPI 
-- Game: AppID 1265780
addappid(1265780)
addappid(1265781, 1, "d6efa315d9ac1c7366b52d132e072b9580b6735097724994b4f38e98581a2500")
addappid(2374460)
addappid(2374461)
addappid(2374462)
addappid(2374463, 0, "a9ffc1c757ce562741fd4fc0ec03f45e443703333609b70ef4abe0277676c74c")
