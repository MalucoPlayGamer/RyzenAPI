-- Lua provided by SkyAPI 
-- Game: 逆乱水浒之山贼王
addappid(2459790)
addappid(2459791, 1, "2c71ff57d1a4cbe894cda90f7995737cd1715243bf8e44bf58aab0d706e8c5c8")
