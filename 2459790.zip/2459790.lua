-- Lua provided by RyzenAPI
-- Game: Game: 逆乱水浒之山贼王

-- MAIN APPLICATION
addappid(2459790)
-- Game: addappid(2459790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459791, 1, "2c71ff57d1a4cbe894cda90f7995737cd1715243bf8e44bf58aab0d706e8c5c8")
