-- Lua provided by RyzenAPI
-- Game: Hitman GO: Definitive Edition

-- MAIN APPLICATION
addappid(427820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(427821, 1, "f1e2827dde33dd2caf07c194c102b0fe836eab030e5b0fa6a86fc6698cd1cd78")
addappid(427823, 1, "20d124ba8382c97602812b4c67904e924764eaf9fa4fe641af175b1f44105f95")
addappid(427824, 1, "e32cdeafd6f7623df1c5287a0d7d83175e6e2cc67bc28ba96e6774482d87a695")
