-- Lua provided by RyzenAPI
-- Game: 427820

-- MAIN APPLICATION
addappid(427820)
-- Game: addappid(427820)

-- MAIN APP DEPOTS / PACKAGES
addappid(427821, 1, "f1e2827dde33dd2caf07c194c102b0fe836eab030e5b0fa6a86fc6698cd1cd78")
addappid(427823, 1, "20d124ba8382c97602812b4c67904e924764eaf9fa4fe641af175b1f44105f95")
addappid(427824, 1, "e32cdeafd6f7623df1c5287a0d7d83175e6e2cc67bc28ba96e6774482d87a695")
