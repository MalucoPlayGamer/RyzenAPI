-- Lua provided by RyzenAPI
-- Game: 3089070

-- MAIN APPLICATION
addappid(3089070)
-- Game: addappid(3089070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089071, 1, "cfd30bba743df834ad53f490daeb26ed12ce4c41c3e62bc7f9850bddfbb67315")
