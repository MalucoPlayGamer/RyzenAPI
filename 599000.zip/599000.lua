-- Lua provided by RyzenAPI
-- Game: addappid(599000)

-- MAIN APPLICATION
addappid(599000)

-- MAIN APP DEPOTS / PACKAGES
addappid(599001, 1, "8dd5b4ba1f3e4e56f971e5c3f245ab578a003acc8cb5c2d6f07ebcbf3808f11c")
addappid(599002, 1, "d68c0df41011a5bd6c68c707a5cc1b1d0165825aa8f2fed7183d07b783e5b26d")
