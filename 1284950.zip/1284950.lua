-- Lua provided by RyzenAPI
-- Game: Witcheye

-- MAIN APPLICATION
addappid(1284950)
-- Game: addappid(1284950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284951, 1, "b1d0d5bcd5501e39ac88eae3bf4ee1912464b7c657701c69718709b6f9b94b27")
