-- Lua provided by RyzenAPI
-- Game: 2672270

-- MAIN APPLICATION
addappid(2672270)
-- Game: addappid(2672270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672271, 1, "73e5dd7c6eadeef96f0f05a1b67fca09105473d30abb97a99bae5afba900e111")
