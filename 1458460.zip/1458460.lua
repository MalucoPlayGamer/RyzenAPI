-- Lua provided by RyzenAPI
-- Game: Island Raft Survival 2021: Ocean Escape

-- MAIN APPLICATION
addappid(1458460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458461, 1, "6595a3a287151bfabd68cd2fe3b237432fadabb8415d916d78a87218bda29da3")

