-- Lua provided by RyzenAPI
-- Game: 101 Cats in New Delhi

-- MAIN APPLICATION
addappid(3451960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451961, 1, "c86f0a1dfcc2628fcf0660ab5c8dd6f7020b1eff074b00f33ed5c070ba4e794b")

