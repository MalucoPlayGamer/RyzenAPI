-- Lua provided by RyzenAPI
-- Game: Perfect Universe

-- MAIN APPLICATION
addappid(405720)

-- MAIN APP DEPOTS / PACKAGES
addappid(405721, 1, "4b18116c370ab00d2d5f5439e088a8e2a263435b57ec67dcab1ca7a7507c9ac0")
