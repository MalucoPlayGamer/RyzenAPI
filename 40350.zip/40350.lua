-- Lua provided by RyzenAPI
-- Game: Lost Horizon

-- MAIN APPLICATION
addappid(40350)
-- Game: addappid(40350)

-- MAIN APP DEPOTS / PACKAGES
addappid(40351, 1, "891653a753e5e5d247aacfbca6badc9d76bd4fb9e9853ae09bfb8fb29ee13f8f")
addappid(40352, 1, "25e6d1aed1c462419399fbebddb98ae86e72e6fa8cc6894bf0867bc7e3b0046b")
addappid(40353, 1, "cc539e2d7b8117942b8863108b6f5fdc6aa00ac8d1006a76459a90f89a737670")
addappid(40354, 1, "b17da726b3140fd10ab35182d2f4cbae85f7bce637232e93e0f380629c4db2c4")
addappid(40355, 1, "a5b172659950f628d7a64b01c8ca069c9f05d318fff176e8620bf9abdb946546")
