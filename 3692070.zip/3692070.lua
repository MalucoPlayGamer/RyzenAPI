-- Lua provided by RyzenAPI
-- Game: addappid(3692070)

-- MAIN APPLICATION
addappid(3692070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3692071, 1, "2c807238ca3544f0ca1ec424fa6ad9d16c673f4ad228f693511506d238125ce5")
