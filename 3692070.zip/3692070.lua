-- Lua provided by RyzenAPI
-- Game: One Man´s Trash

-- MAIN APPLICATION
addappid(3692070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3692071, 1, "2c807238ca3544f0ca1ec424fa6ad9d16c673f4ad228f693511506d238125ce5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
