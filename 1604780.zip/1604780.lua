-- Lua provided by RyzenAPI 
-- Game: Lovely Planet Remix
addappid(1604780)
addappid(1604781, 1, "a053353af3382b46ad8a0b99f1f3fb70a3295da5c1e44507a98dca7611c7e4bc")
addappid(1604782, 1, "7790e87f3293e3ec10f5f403dd2a9b6632c8a391eb3185889b0667ec9b76f991")
