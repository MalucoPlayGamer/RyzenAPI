-- Lua provided by RyzenAPI
-- Game: addappid(1191940)

-- MAIN APPLICATION
addappid(1191940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191941, 1, "3a4d77cc3b5b87e61df1428e57a367b17e8c5a833cd8ab66ba5f3070114c4489")
