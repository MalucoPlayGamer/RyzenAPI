-- Lua provided by RyzenAPI
-- Game: AppID 1145030

-- MAIN APPLICATION
addappid(1145030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145031, 1, "c6aa523a66da9a94f76c4126a6ad17ff4fba45d8d361a74b4c81ead83ff56b91")

