-- Lua provided by RyzenAPI
-- Game: Strategic Mind: Blitzkrieg

-- MAIN APPLICATION
addappid(1200330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200331, 1, "aebf66c90a7897876cf03a667e23f824ab0a4df5a246ee5ab08712fdb5ece79b")
addappid(1200332, 1, "2ddf228462c2aca8f28fa333c1305f0139c6b76cf9994e046fc57b6fcf25c35c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
