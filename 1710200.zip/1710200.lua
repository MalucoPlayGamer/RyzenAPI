-- Lua provided by RyzenAPI
-- Game: addappid(1710200)

-- MAIN APPLICATION
addappid(1710200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710201, 1, "c2de8c936ddc20e23ea154c72c49d84d0cdf1bfb0f51d72467273bfef4e11fb9")
