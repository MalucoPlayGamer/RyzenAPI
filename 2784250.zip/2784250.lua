-- Lua provided by RyzenAPI
-- Game: 100 Cats Mexico

-- MAIN APPLICATION
addappid(2784250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784251, 1, "bba21d95ca70da7c8d222a30338a8ca00b0320d82c18e112028e6bb5fd8367df")

