-- Lua provided by RyzenAPI
-- Game: Game: GOD WARS The Complete Legend - Art Book (In English)

-- MAIN APPLICATION
addappid(1071110)
-- Game: addappid(1071110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071111, 1, "34f4e1307be405bf1be2b0203e2705e0103ec2920123447a875b432063fbeac1")
