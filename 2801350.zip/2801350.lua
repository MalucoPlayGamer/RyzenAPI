-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Spirit of France Tileset

-- MAIN APPLICATION
addappid(2801350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2801350,0,"7ab8eabab89eaf1fe4f5579e511f8e1d069a07cc781c0f951236d96282308b49")

