-- Lua provided by RyzenAPI
-- Game: At Home Alone II

-- MAIN APPLICATION
addappid(1120360)
addappid(1132962)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120361,0,"396f7849cca6b2065a6f74260493e6b079fee3150e9c17865d652232a5132a9e")
addappid(1120362,0,"bd06c84c42c12aeb55c3afa5ff370ed6db1c5d3726f74ea5db36a0d3560b6f50")
addappid(1120363,0,"2040026440afca93d537e8df800b1f95494639eb3925e1262e0f48c450f52223")
addappid(1132963,0,"3180c6aa80ae8dd61e959d7786fc1c7d3f685468bc6957f85e38b1b8c5ab779d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1132960)
