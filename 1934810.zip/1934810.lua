-- Lua provided by RyzenAPI
-- Game: 驯龙物语

-- MAIN APPLICATION
addappid(1934810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934813,0,"8f09c30d0714c8acc91d57aa91a66ac73139bff38464601416e1333cc29aac79")

