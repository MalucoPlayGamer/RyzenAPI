-- Lua provided by RyzenAPI
-- Game: addappid(284100)

-- MAIN APPLICATION
addappid(284100)

-- MAIN APP DEPOTS / PACKAGES
addappid(284101, 1, "66152da777fb68f29aa10cbff6b276236b3f4094d715ef3ce41ac2f0fbfed1a5")
addappid(536790, 0, "b4a7c188ecd0010f115e11edfb5ed0b56c98efc41da79471493904f192a6b84a")
