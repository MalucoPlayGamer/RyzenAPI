-- Lua provided by RyzenAPI
-- Game: Unclaimed World

-- MAIN APPLICATION
addappid(284100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(284101, 1, "66152da777fb68f29aa10cbff6b276236b3f4094d715ef3ce41ac2f0fbfed1a5")
addappid(536790, 0, "b4a7c188ecd0010f115e11edfb5ed0b56c98efc41da79471493904f192a6b84a")

