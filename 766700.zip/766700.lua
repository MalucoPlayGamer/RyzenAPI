-- Lua provided by RyzenAPI
-- Game: PearsAndGrayWitch

-- MAIN APPLICATION
addappid(766700)

-- MAIN APP DEPOTS / PACKAGES
addappid(766701, 1, "14312413c7f0952b18c2634aa2f1b2af93bb80ebdd02a87fb361d0ea49c5dd39")

