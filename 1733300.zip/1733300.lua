-- Lua provided by RyzenAPI 
-- Game: My Stepmom is a Futanari 2
addappid(1733300)
addappid(1733301, 1, "07d63e6d48d6b4f646c7aa6acddc1b6cc9220d70d6f205d7625cacded9ef02bc")
