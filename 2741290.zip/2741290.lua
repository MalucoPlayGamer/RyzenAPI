-- Lua provided by RyzenAPI
-- Game: Time To Morp: First Contact

-- MAIN APPLICATION
addappid(2741290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741291, 1, "230ae86a688bc9de09dae339ec222564a8f149e4a0501a5c87b48d0014565bff")

