-- Lua provided by RyzenAPI
-- Game: Tricky Machines

-- MAIN APPLICATION
addappid(1495380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1495381, 1, "4b32257a58788575a5a234fa38c84285b13d900072b166ccf4fa962da9327f04")

