-- Lua provided by RyzenAPI
-- Game: Game: Tricky Machines

-- MAIN APPLICATION
addappid(1495380)
-- Game: addappid(1495380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495381, 1, "4b32257a58788575a5a234fa38c84285b13d900072b166ccf4fa962da9327f04")
