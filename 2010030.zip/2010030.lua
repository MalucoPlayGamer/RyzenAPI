-- Lua provided by RyzenAPI
-- Game: Denizen

-- MAIN APPLICATION
addappid(2010030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010031, 1, "ad79833ee6091179507f4008cbbba4cc167bc833221fe09c2d6fa512dd106a0b")
