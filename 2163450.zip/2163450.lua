-- Lua provided by RyzenAPI
-- Game: Game: Molytropia: Cloud in Shape of Hurt

-- MAIN APPLICATION
addappid(2163450)
-- Game: addappid(2163450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163451, 1, "8f002f1371e35f5343cf37d11926c1c609aa12268d5f68dd06f088c32f3c151d")
