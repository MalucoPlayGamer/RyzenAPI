-- Lua provided by RyzenAPI
-- Game: shapez 2 - Factory

-- MAIN APPLICATION
addappid(2162800)
-- Game: addappid(2162800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162802,0,"163ae6ae731b47cb94170aee0ed8a4d4ecc62c6082bc319cc270e20c5eb0f759")
addappid(2162803,0,"9b7c2e9a0f8d2a28b522233286436b360fffb4830d45a69a5a0bf35573da8647")
addappid(2162804,0,"aba21c81613972e41bf5e0131f382113d13fbdee073a02f7065cfc4256630232")
