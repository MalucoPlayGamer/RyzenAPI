-- Lua provided by RyzenAPI
-- Game: 2356410

-- MAIN APPLICATION
addappid(2356410)
-- Game: addappid(2356410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356411, 1, "aff75f211c9b1838e39dab9a9dd597b5165bbda9647cedee595302c40d4d0e74")
