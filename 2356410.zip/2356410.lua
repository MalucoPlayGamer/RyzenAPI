-- Lua provided by RyzenAPI 
-- Game: Magical Girl Clicker Demo
addappid(2356410)
addappid(2356411, 1, "aff75f211c9b1838e39dab9a9dd597b5165bbda9647cedee595302c40d4d0e74")
