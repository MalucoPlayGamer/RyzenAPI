-- Lua provided by RyzenAPI
-- Game: Picross Fairytale: Legend of the Mermaid

-- MAIN APPLICATION
addappid(820040)
-- Game: addappid(820040)

-- MAIN APP DEPOTS / PACKAGES
addappid(820041, 1, "36639abce2d040d7d7027e0b2144285bfc0fe6fa643d3e5cead6c8b6a964927c")
addappid(820042, 1, "3d5c880ed2e271ccc451b4f466bc2eb017602dcc5a25a7352766e3b0cffec1e1")
