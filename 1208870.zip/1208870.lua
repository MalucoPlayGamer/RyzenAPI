-- Lua provided by RyzenAPI
-- Game: Game: AppID 1208870

-- MAIN APPLICATION
addappid(1208870)
-- Game: addappid(1208870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208871, 1, "237661040e33722beb2e0f3b83397f8acb3b820a4a8164835d65cacc83211090")
