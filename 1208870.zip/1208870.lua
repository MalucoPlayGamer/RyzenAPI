-- Lua provided by RyzenAPI
-- Game: AppID 1208870

-- MAIN APPLICATION
addappid(1208870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208871, 1, "237661040e33722beb2e0f3b83397f8acb3b820a4a8164835d65cacc83211090")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
