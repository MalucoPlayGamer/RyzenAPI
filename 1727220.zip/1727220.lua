-- Lua provided by RyzenAPI 
-- Game: Summoner's Mess
addappid(1727220)
addappid(1727221, 1, "d2b364c51a14308cea2ca4a1248ce07ee065ecb85d74a13eca1ea9a796c8bdab")
