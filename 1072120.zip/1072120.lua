-- Lua provided by RyzenAPI
-- Game: 1072120

-- MAIN APPLICATION
addappid(1072120)
-- Game: addappid(1072120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072121, 1, "9548145bfecd53c278aee43cacfb426119c884eb9d5fb68ae967f238f7aa94dc")
