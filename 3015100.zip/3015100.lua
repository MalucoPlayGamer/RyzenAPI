-- Lua provided by RyzenAPI
-- Game: Apocalyptic cat

-- MAIN APPLICATION
addappid(3015100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015101, 1, "b7322f739b1f72c1e23928d1e7d98493a58dd11ab3c93778598169ea609751f8")
