-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Sexual Guidance Class

-- MAIN APPLICATION
addappid(3705430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3705431, 1, "7526c2976bae6b79ab802f8841ae368037b61bca5b9168492a93425e1b8389f1")

