-- Lua provided by RyzenAPI
-- Game: DFF NT: Vayne Carudas Solidor Starter Pack

-- MAIN APPLICATION
addappid(1022330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022330,0,"1f8c03f19c046acb51439c94de63846c2db11971cb55114c392dfcf2d90d0e4d")
