-- Lua provided by RyzenAPI
-- Game: 495740

-- MAIN APPLICATION
addappid(495740)
-- Game: addappid(495740)

-- MAIN APP DEPOTS / PACKAGES
addappid(495741, 1, "8db9e2e6792948acb51d6274f1a310c8a4ca1c9274b69c8e97aedc4f59772fc7")
