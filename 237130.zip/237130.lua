-- Lua provided by RyzenAPI
-- Game: 237130

-- MAIN APPLICATION
addappid(237130)
-- Game: addappid(237130)

-- MAIN APP DEPOTS / PACKAGES
addappid(237131, 1, "78ff017143a93dcf6557d265bf6bd0fac33d1d402eba91fc19742c9f1d20cc65")
