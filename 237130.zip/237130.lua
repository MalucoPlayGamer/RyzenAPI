-- Lua provided by SkyAPI 
-- Game: AppID 237130
addappid(237130)
addappid(237131, 1, "78ff017143a93dcf6557d265bf6bd0fac33d1d402eba91fc19742c9f1d20cc65")
