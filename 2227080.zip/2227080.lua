-- Lua provided by RyzenAPI
-- Game: Game: Snow Moon Flower

-- MAIN APPLICATION
addappid(2227080)
-- Game: addappid(2227080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227081, 1, "6c3f0a942ede88b8f343a975a5811b20914fb11e0d685926a7f20f236676898e")
addappid(2227082, 1, "110ec189769bbc4c0852e7363e6b64df89320159eb71d1dfc6291138d5494cc9")
addappid(2227083, 1, "4976c96faf8d25ea96af48c7dee58549f1d75c4b17ae6e8ba94af10f0ee12287")
