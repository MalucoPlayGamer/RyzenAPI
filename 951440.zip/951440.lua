-- Lua provided by RyzenAPI
-- Game: Volcanoids

-- MAIN APPLICATION
addappid(951440)
-- Game: addappid(951440)

-- MAIN APP DEPOTS / PACKAGES
addappid(951441, 1, "2d6239f6c1966e82449a17ba6bd6f9e6ce67d829c47334b4e387471b2188eb3b")
addappid(951442, 1, "21a4d319b66948fe58b5d634c907c1072ec2afffca1161e286eeeb4450f86d26")
