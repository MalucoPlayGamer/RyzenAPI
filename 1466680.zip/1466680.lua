-- Lua provided by RyzenAPI
-- Game: Game: Sakura MMO Extra

-- MAIN APPLICATION
addappid(1466680)
-- Game: addappid(1466680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466681, 1, "233c5c900735f8ba4f8fe6c487715b185c776b47b8592d7974e50e5592eb89a1")
