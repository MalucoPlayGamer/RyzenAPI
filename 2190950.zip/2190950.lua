-- Lua provided by RyzenAPI
-- Game: WORDKOUR

-- MAIN APPLICATION
addappid(2190950)
-- Game: addappid(2190950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190951, 1, "3d3d5c61e8fa3e4c321863c9a7743b562facd250d6dd12cb939e4ebf956b9224")
