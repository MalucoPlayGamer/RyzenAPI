-- Lua provided by RyzenAPI
-- Game: WORDKOUR

-- MAIN APPLICATION
addappid(2190950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2190951, 1, "3d3d5c61e8fa3e4c321863c9a7743b562facd250d6dd12cb939e4ebf956b9224")

