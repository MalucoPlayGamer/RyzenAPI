-- Lua provided by RyzenAPI 
-- Game: AppID 2419820
addappid(2419820)
addappid(2419821, 1, "96fb5a95f359b9c4bc0c7a5fa42257222b9cce06feb3e5673e1e425efea8e9b9")
