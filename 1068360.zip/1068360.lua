-- Lua provided by RyzenAPI
-- Game: Fearmonium

-- MAIN APPLICATION
addappid(1068360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068361, 1, "f721a7c1099971bdd3f569d29d27998122354908db2daa0e88099d8d9ea75677")
