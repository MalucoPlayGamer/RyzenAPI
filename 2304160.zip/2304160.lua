-- Lua provided by RyzenAPI
-- Game: Furry Futa 💘

-- MAIN APPLICATION
addappid(2304160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304162,0,"6d719d727e6a8d7ce10b301eef3f1dc7b222e9bee10561480af19a3ecb0aa700")
