-- Lua provided by RyzenAPI
-- Game: 416270

-- MAIN APPLICATION
addappid(416270)
-- Game: addappid(416270)

-- MAIN APP DEPOTS / PACKAGES
addappid(416271, 1, "c400659836e2dbfc21e1620867358ef14cb9cd80276ec54b19eccf9f2d7a5750")
