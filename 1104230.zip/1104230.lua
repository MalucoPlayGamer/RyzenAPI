-- Lua provided by SkyAPI 
-- Game: The Last Escape of Yeti
addappid(1104230)
addappid(1104231, 1, "7cf508c1b6b44c7de2f05fe58cd5cda93c39ffb14268bffa2e100554c55f7afd")
