-- Lua provided by RyzenAPI
-- Game: Mask of Fury

-- MAIN APPLICATION
addappid(789150)

-- MAIN APP DEPOTS / PACKAGES
addappid(789151, 1, "d41e49ff6deabf7a24f9a3f6dee638944d760065d8febfbcdefad28371cc43be")

