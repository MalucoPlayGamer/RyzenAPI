-- Lua provided by RyzenAPI
-- Game: AirMech Wastelands

-- MAIN APPLICATION
addappid(595770)

-- MAIN APP DEPOTS / PACKAGES
addappid(595771, 1, "975bef2dda2eacbf91ab191733cc08dcf6266cb72738366a3df582392ecda709")

