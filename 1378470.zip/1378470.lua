-- Lua provided by RyzenAPI
-- Game: Now There Be Goblins: Tower Defense VR

-- MAIN APPLICATION
addappid(1378470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378471, 1, "89d711fffb72ecf8cdd2d64f66c32c21b9e5c0981e87274fe668804a8d85a848")
