-- Lua provided by SkyAPI 
-- Game: Now There Be Goblins: Tower Defense VR
addappid(1378470)
addappid(1378471, 1, "89d711fffb72ecf8cdd2d64f66c32c21b9e5c0981e87274fe668804a8d85a848")
