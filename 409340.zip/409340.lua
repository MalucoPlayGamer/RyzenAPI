-- Lua provided by RyzenAPI
-- Game: AppID 409340

-- MAIN APPLICATION
addappid(409340)
addappid(470080)

-- MAIN APP DEPOTS / PACKAGES
addappid(409341, 1, "2fa6b5f66bb6b81ec1648af7ea6ef675ab5617c98501b20cee1a4e6fe8baf9b5")
