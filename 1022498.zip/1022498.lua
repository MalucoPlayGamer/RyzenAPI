-- Lua provided by RyzenAPI
-- Game: DFF NT: SeeD Uniform Appearance Set for Squall Leonhart

-- MAIN APPLICATION
addappid(1022498)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022498,0,"586fe17f15a2f03f1aa66538a8d2954f0584ee6c3db7aec90e6bb182a9d6d035")

