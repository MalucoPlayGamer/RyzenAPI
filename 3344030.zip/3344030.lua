-- Lua provided by RyzenAPI
-- Game: VIDeoPHOBIA

-- MAIN APPLICATION
addappid(3344030)
-- Game: addappid(3344030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3344031, 1, "8026dddb7501baecd42b93b511516ad372dbd71ed6c0957abda8b4ad17a8a5d3")
