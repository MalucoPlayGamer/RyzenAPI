-- Lua provided by RyzenAPI
-- Game: Driving License Test

-- MAIN APPLICATION
addappid(1507320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507321, 1, "ab44ccb4ec242fc322f7e2c55beb76dbdff6ba86e85bcaadc2d9e75ae0077fb1")
