-- Lua provided by RyzenAPI
-- Game: AppID 820050

-- MAIN APPLICATION
addappid(820050)
-- Game: addappid(820050)

-- MAIN APP DEPOTS / PACKAGES
addappid(820051, 1, "789e7db951aca3b81a8d1489a11df6b3a9b1d0629a4078ed9e4d2abf66b402d9")
