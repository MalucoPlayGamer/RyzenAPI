-- Lua provided by RyzenAPI
-- Game: IFU

-- MAIN APPLICATION
addappid(2666080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666081, 1, "18239b0f11d1b28d33a0ee59fe914f6afea32bedb79f5f2584021bbc10ffcd35")
