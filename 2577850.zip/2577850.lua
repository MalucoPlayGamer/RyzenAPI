-- Lua provided by RyzenAPI
-- Game: addappid(2577850)

-- MAIN APPLICATION
addappid(2577850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577851, 1, "5f0a47d460b62926365d3c4e1085bc9f420c712fbf96bc19a729d4c8c8ccf0c3")
