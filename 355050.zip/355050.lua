-- Lua provided by RyzenAPI
-- Game: Sky Force Anniversary

-- MAIN APPLICATION
addappid(355050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(355051, 1, "45f5471564796971fdd4929d40e49a496e77c657782bc592420e5224d4f89145")
addappid(355052, 1, "c88aedce43e5a898212b74e2a69ef611b0dfc83ccb3b6ebe21d2d75159b11df3")
addappid(355053, 1, "b5e40013226ee4808e126ffc4a45cebe85bfe22b96955361b7a3a9e97e10f834")
addappid(367810, 0, "ce83456f8dfe4e427d3d5b7819344465fceab4e8eee949546cc79727c76508da")

