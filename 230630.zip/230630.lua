-- Lua provided by RyzenAPI
-- Game: Game: AppID 230630

-- MAIN APPLICATION
addappid(230630)
-- Game: addappid(230630)

-- MAIN APP DEPOTS / PACKAGES
addappid(230631, 1, "4c2d9ad1b8845042daa463106005d0007a8c1d61bbb8892348e8b5cdaffb1406")
