-- Lua provided by RyzenAPI
-- Game: Vapor World: Over The Mind

-- MAIN APPLICATION
addappid(1996090) -- Vapor World: Over The Mind

-- MAIN APP DEPOTS / PACKAGES
addappid(1996091, 1, "ddb21729a2e8eebf759ffc8978e92151736934a682fddc239f3ef46b9f64729a") -- Depot 1996091

