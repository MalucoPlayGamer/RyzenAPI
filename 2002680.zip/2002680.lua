-- Lua provided by RyzenAPI
-- Game: addappid(2002680)

-- MAIN APPLICATION
addappid(2002680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002681, 1, "f94883ef5ce1c3e6cdea96851153d700a1f4aa12b0bab8a2944e137ef843a180")
