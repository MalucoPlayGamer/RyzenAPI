-- Lua provided by SkyAPI 
-- Game: S.P.I.K.E: ARENA
addappid(789200)
addappid(789201, 1, "11c4f01625329ff0ff21c74e5bf3a6dca81786143c755b285bbc150087737314")
addappid(789204, 1, "63ae4cb1ec75767a278b0bc21a61fb4377fb5fe73eae1cc8b661a73b52a2b155")
