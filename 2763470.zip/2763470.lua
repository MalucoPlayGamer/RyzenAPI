-- Lua provided by RyzenAPI
-- Game: addappid(2763470)

-- MAIN APPLICATION
addappid(2763470)
addappid(3755130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763471, 1, "d1d293a207f44dea5ae5fedfa32bcc876d804990f69103a39662b41f30e442c8")
