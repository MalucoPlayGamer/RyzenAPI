-- Lua provided by RyzenAPI
-- Game: Game: Kill The Clock

-- MAIN APPLICATION
addappid(2763470)
addappid(3755130)
-- Game: addappid(2763470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763471, 1, "d1d293a207f44dea5ae5fedfa32bcc876d804990f69103a39662b41f30e442c8")
