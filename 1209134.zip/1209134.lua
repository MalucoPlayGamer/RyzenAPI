-- Lua provided by RyzenAPI
-- Game: addappid(1209134)

-- MAIN APPLICATION
addappid(1209134)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209134,0,"a6b682362e8ca572883d8fa7a9cbe5d675bc71e821a6ebd528d8645969a1c4ab")
