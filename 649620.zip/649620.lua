-- Lua provided by RyzenAPI
-- Game: AppID 649620

-- MAIN APPLICATION
addappid(649620)

-- MAIN APP DEPOTS / PACKAGES
addappid(649621, 1, "6af3def046591b92f8072fdb55855f507cbee4c328dc1952d7804f1905cfea4e")
