-- Lua provided by RyzenAPI
-- Game: Elmarion: Dragon's Princess

-- MAIN APPLICATION
addappid(1468040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468041, 1, "551280d2c2c79a4171aa047e6a16799727e680e66a25f3071e42823e8f5e6e0a")
