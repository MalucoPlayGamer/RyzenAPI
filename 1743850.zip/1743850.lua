-- Lua provided by RyzenAPI 
-- Game: HYPER DEMON
addappid(1743850)
addappid(1743851, 1, "4542812225d88ed246fc6f5b269158a5e15d6d9f75b57361e0185944175a9fa3")
addappid(1743859, 1, "56a8a0709b1877c6628f1aac9841bf088da9a8dad317dc8d6521de3558bcec2f")
