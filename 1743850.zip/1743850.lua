-- Lua provided by RyzenAPI
-- Game: HYPER DEMON

-- MAIN APPLICATION
addappid(1743850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743851, 1, "4542812225d88ed246fc6f5b269158a5e15d6d9f75b57361e0185944175a9fa3")
addappid(1743859, 1, "56a8a0709b1877c6628f1aac9841bf088da9a8dad317dc8d6521de3558bcec2f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
