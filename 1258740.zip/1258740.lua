-- Lua provided by SkyAPI 
-- Game: AppID 1258740
addappid(1258740)
addappid(1258741, 1, "333cc36da18ee28253c5dcedee37858e449c97d3df6e9618f20f8540712fc39d")
addappid(1258742, 1, "e6c0fe164d33686134aa4baa7a8ae8535a7a3fdcf2da90a1d3f1f4a3df825253")
