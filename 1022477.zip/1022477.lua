-- Lua provided by RyzenAPI
-- Game: addappid(1022477)

-- MAIN APPLICATION
addappid(1022477)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022477,0,"e972fea559d661f1d563c5482bd8b853cd07d7908ef880b79391fa32397cc90d")
