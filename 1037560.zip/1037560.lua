-- Lua provided by SkyAPI 
-- Game: Fat Prisoner Simulator
addappid(1037560)
addappid(1037561, 1, "4422bf5929242d83de5f596056206a06c899f6bd41df3a6258857996bcf3cde9")
