-- Lua provided by RyzenAPI
-- Game: Game: Fat Prisoner Simulator

-- MAIN APPLICATION
addappid(1037560)
-- Game: addappid(1037560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037561, 1, "4422bf5929242d83de5f596056206a06c899f6bd41df3a6258857996bcf3cde9")
