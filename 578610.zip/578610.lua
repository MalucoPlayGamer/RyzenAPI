-- Lua provided by RyzenAPI
-- Game: Super Pixel Smash

-- MAIN APPLICATION
addappid(578610)

-- MAIN APP DEPOTS / PACKAGES
addappid(578611, 1, "fff073672c711cf9c0ee65c48d8495b20baed7881e3603a91a8d3ad2cc135e03")
