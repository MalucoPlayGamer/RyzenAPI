-- Lua provided by RyzenAPI
-- Game: Paranormal place Demo

-- MAIN APPLICATION
addappid(2947810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947811, 1, "094f3140236af3e225dad1c3ca52c7ec3c9ccf1fb4007ba87c19dd828913c06f")

