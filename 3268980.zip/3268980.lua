-- Lua provided by SkyAPI 
-- Game: AWAKEN - Astral Blade Soundtrack
addappid(3268980)
addappid(3268981, 1, "d13a2616074945630a8783a6718bdf19afd7aad84686cc63ffc97a7aac599c6a")
addappid(3268982, 1, "20b83b5892e766fcd9be07a31a18ca75ce2f63f90525db219c0c0c3e807e1be2")
