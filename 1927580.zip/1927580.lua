-- Lua provided by RyzenAPI
-- Game: Poly Memory: Birds

-- MAIN APPLICATION
addappid(1927580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927581, 1, "d419212d1ac94b63ba5123542e02ef2ac61109f843b1ca5f96d093f5bdbf1225")

