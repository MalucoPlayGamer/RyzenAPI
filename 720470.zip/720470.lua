-- Lua provided by RyzenAPI
-- Game: Caveman Alive

-- MAIN APPLICATION
addappid(720470)

-- MAIN APP DEPOTS / PACKAGES
addappid(720471, 1, "0507073b3cbe618b28bd2724cb916f46c18add6d8f6845f0ff4539f5ee01c3f7")

