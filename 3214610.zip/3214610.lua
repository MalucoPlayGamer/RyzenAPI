-- 3214610's Lua and Manifest Created by Hubcap Manifest
-- Cinderia
-- Created: May 28, 2026 at 09:43:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3214610, 1, "ad78c2c95377bc0b6665cfcf37b4255da0a85ca5d8825e180a5171dbb08c7b0c") -- Cinderia
addtoken(3214610, "16472338112919955715")
-- MAIN APP DEPOTS
addappid(3214611, 1, "11606ac2e0d357064a1b121a23ed7409bcc466ceefa174aa3a08b275753d6115") -- Depot 3214611
-- setManifestid(3214611, "3236156327715141174", 10826910365)