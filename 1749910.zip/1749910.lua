-- Lua provided by RyzenAPI
-- Game: In Sound Mind Soundtrack

-- MAIN APPLICATION
addappid(1749910)
-- Game: addappid(1749910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749911, 1, "a113da3b3f468fb101e55bce614724dc187dd733eb0c9360030b9bc8eee51926")
