-- Lua provided by RyzenAPI
-- Game: Steel Rats™ original soundtrack

-- MAIN APPLICATION
addappid(969100)

-- MAIN APP DEPOTS / PACKAGES
addappid(969100,0,"3427421d862d07af2da5ec5ea6ae5dbf7cd6c0ce3c14db11f9b7eb2cd1d8e338")
