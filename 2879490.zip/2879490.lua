-- Lua provided by RyzenAPI
-- Game: Game: SMYS : Classic

-- MAIN APPLICATION
addappid(2879490)
-- Game: addappid(2879490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879491, 1, "6beef6c041d529f9b5e955196f18b22b1518a7adf5fa3e7f815b332af698d1ec")
