-- Lua provided by RyzenAPI
-- Game: addappid(2776290)

-- MAIN APPLICATION
addappid(2776290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776291, 1, "0a86a75d0cb5a68a6c12a22b6e37bfd1169fc3881669e27824342ddbadf0045c")
