-- Lua provided by SkyAPI 
-- Game: Pricolage -IDOLIZED-
addappid(2510890)
addappid(2510891, 1, "623c690db512a02c036e3f5678316db38ec9b4ec59679248e7f4f70a23b1f9e7")
addappid(2510892, 1, "c0730f505deb8391b73f045c51633a8907ee8c4793eb1bed4b9ac7930878f1a6")
