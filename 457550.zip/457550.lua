-- Lua provided by RyzenAPI
-- Game: AppID 457550

-- MAIN APPLICATION
addappid(457550)

-- MAIN APP DEPOTS / PACKAGES
addappid(457551, 1, "edb611db92ec055ba62c71f74f722c0227565e108b5c2bf07b513a9e7cde3e53")

