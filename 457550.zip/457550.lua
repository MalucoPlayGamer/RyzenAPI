-- Lua provided by RyzenAPI
-- Game: Bigscreen Beta

-- MAIN APPLICATION
addappid(457550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(457551, 1, "edb611db92ec055ba62c71f74f722c0227565e108b5c2bf07b513a9e7cde3e53")

