-- Lua provided by RyzenAPI
-- Game: It's a Wrap! Demo

-- MAIN APPLICATION
addappid(1958880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958881, 1, "e9681e16c60959fc420d876d7ad9c5c75867019bd0e8f133ef5070385562b421")
