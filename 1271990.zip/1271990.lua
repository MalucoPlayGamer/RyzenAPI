-- Lua provided by RyzenAPI
-- Game: Game: AppID 1271990

-- MAIN APPLICATION
addappid(1271990)
-- Game: addappid(1271990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271991, 1, "c89bdfc69ee9b2bf31f72c79cd1efb70b6ff224b24849eebcc1a1748f736587f")
