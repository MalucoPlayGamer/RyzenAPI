-- Lua provided by SkyAPI 
-- Game: AppID 1271990
addappid(1271990)
addappid(1271991, 1, "c89bdfc69ee9b2bf31f72c79cd1efb70b6ff224b24849eebcc1a1748f736587f")
