-- Lua provided by RyzenAPI 
-- Game: Bogdan's Сlinic
addappid(3730730)
addappid(3730731, 1, "a682b36036775cf6d9ac1a3e12988bbde39282556345dd3489c0a2b10b6fbac4")
