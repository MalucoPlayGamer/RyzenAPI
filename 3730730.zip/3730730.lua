-- Lua provided by RyzenAPI
-- Game: Bogdan's Сlinic

-- MAIN APPLICATION
addappid(3730730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3730731, 1, "a682b36036775cf6d9ac1a3e12988bbde39282556345dd3489c0a2b10b6fbac4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
