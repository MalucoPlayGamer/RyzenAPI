-- Lua provided by RyzenAPI
-- Game: Kelipot

-- MAIN APPLICATION
addappid(1090440)
-- Game: addappid(1090440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090441, 1, "22948559f6761c0cd917bae549bd5ad6e65d72e5ebe4fed35547242c1840446e")
