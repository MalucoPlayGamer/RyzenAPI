-- Lua provided by RyzenAPI
-- Game: HJ: Sacrifice

-- MAIN APPLICATION
addappid(759870)

-- MAIN APP DEPOTS / PACKAGES
addappid(759871, 1, "670d3650e5fc9849d7c2e5c7d43d48bb49b6cda0d80c95e87c556e0ff3c2510b")
