-- Lua provided by RyzenAPI
-- Game: Li Lei and Han Meimei Demo

-- MAIN APPLICATION
addappid(1842670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842671, 1, "6dc6a3e873f8e362c6e14cbe0b20cf652e1ef6d2d31f666bf8f2a1a02c9b0680")
