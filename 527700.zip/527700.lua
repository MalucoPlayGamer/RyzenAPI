-- Lua provided by RyzenAPI
-- Game: Containment Initiative

-- MAIN APPLICATION
addappid(527700)

-- MAIN APP DEPOTS / PACKAGES
addappid(527701, 1, "1e62b89655324ba90021442eab75471a254c282f5c7c79927647f454c4d8e8f4")
