-- Lua provided by RyzenAPI
-- Game: Terminus: Zombie Survivors

-- MAIN APPLICATION
addappid(1534980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534981, 1, "9f940a36197a584e7fcc6806bad77514d91f7fae2df88396688351ddfedc2108")
