-- Lua provided by RyzenAPI
-- Game: 968580

-- MAIN APPLICATION
addappid(968580)
-- Game: addappid(968580)

-- MAIN APP DEPOTS / PACKAGES
addappid(968581, 1, "50feb4e8904848585b3bfeb9b56ce84aad88171b4ac7ea601a7bb9af38170f98")
