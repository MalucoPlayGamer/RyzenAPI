-- Lua provided by RyzenAPI
-- Game: Dawn of Kagura: Hatsuka's Story

-- MAIN APPLICATION
addappid(1839340)
-- Game: addappid(1839340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839342,0,"79fdcbe842c5289cb35702f58ea0fdf741a502442ba730c17d357101c0e0384c")
addappid(1839343,0,"b1d2c139dd0b0b67f8fee9debc9f66e579d17f179e0c12dd28467f60f9dc6d62")
