-- Lua provided by RyzenAPI
-- Game: Trackmania² Lagoon Demo

-- MAIN APPLICATION
addappid(600730)
-- Game: addappid(600730)

-- MAIN APP DEPOTS / PACKAGES
addappid(600731, 1, "c3f02f9a8da398756ea508fc0c58c5f9c2bfd42638a677ab39ab9249f5622230")
