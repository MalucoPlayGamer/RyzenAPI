-- Lua provided by RyzenAPI
-- Game: Game: AppID 628770

-- MAIN APPLICATION
addappid(628770)
-- Game: addappid(628770)

-- MAIN APP DEPOTS / PACKAGES
addappid(628771, 1, "b549b8d6edd4095f0e745b35ba38021cfb2dad6af5f3773619d88c4ed1b471ec")
addappid(628772, 1, "fd848194a88921b15e23e6df61bd53ad0c40d969a09351cf76d5974445eac35f")
addappid(628773, 1, "7af91849e5d9003c0fedf9ffc36082efda651ddae08a53fa914a12ca2191f5bb")
addappid(788620, 0, "a08adf2eb73e6fcad2396b9d0c11f115d3560d1d094a91153bcf9ee13d1f50fc")
addappid(880740, 0, "99f15b89563d740dde438e1a7dfeb9f71104467b1efa958d6c848518007d0635")
addappid(953080, 0, "29055687d4d3cf8cef699d542e1a4fb137ccc15f060d95ba2329a2d415b31933")
addappid(1156710, 0, "34fc58ff6e6d269b4deb9a881eccf24e23c0ff6edc0b67c7b268aef61c8c00de")
