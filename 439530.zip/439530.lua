-- Lua provided by RyzenAPI
-- Game: Rock-N-Rogue: A Boo Bunny Plague Adventure

-- MAIN APPLICATION
addappid(439530)
-- Game: addappid(439530)

-- MAIN APP DEPOTS / PACKAGES
addappid(439531, 1, "d16ea89a762b3be9542e85bc1707e5c3ef41ef0cb4cdbb72a7e17b411ff9d7d2")
