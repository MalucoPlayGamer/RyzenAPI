-- Lua provided by RyzenAPI
-- Game: addappid(2996170)

-- MAIN APPLICATION
addappid(2996170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996171, 1, "d9aa36d54d307ec6577f2a11e393ea73f5815b9a288ff7177f5634f65bf4f4d6")
