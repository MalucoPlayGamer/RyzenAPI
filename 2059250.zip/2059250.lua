-- Lua provided by RyzenAPI
-- Game: addappid(2059250)

-- MAIN APPLICATION
addappid(2059250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059251, 1, "071b94a8fae7aa77b82b888c0f355fc33c7dfd2e0a750a332defdeb6851fa9ca")
