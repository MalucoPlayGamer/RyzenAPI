-- Lua provided by SkyAPI 
-- Game: AppID 33420
addappid(33420)
addappid(33421, 1, "861b3f3d2782d67fac666be1f488f819ab78b2079b91a8aa773c29157f5c372b")
