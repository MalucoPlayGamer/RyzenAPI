-- Lua provided by RyzenAPI 
-- Game: Mutazione
addappid(1080750)
addappid(1080751, 1, "ef98eef7b7724c17b83585096697ea6b90ec0943205455a0f2d3d8c6037000d0")
addappid(1080752, 1, "31c2e78a7bcf1df77d2bece74972eabcf4a024393b63ee23dba33e2fd5733e58")
addappid(1080753, 1, "307f92dce48f1c9fe0ca2d38d671c5e7b522534c8c86300b1402db21064b8b04")
