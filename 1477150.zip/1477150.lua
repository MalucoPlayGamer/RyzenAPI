-- Lua provided by RyzenAPI
-- Game: addappid(1477150)

-- MAIN APPLICATION
addappid(1477150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477151, 1, "fe14382c7eb380c12079d6d6a830f30bab14d40df65573c8a8d4e184f0886248")
