-- Lua provided by SkyAPI 
-- Game: AppID 1477150
addappid(1477150)
addappid(1477151, 1, "fe14382c7eb380c12079d6d6a830f30bab14d40df65573c8a8d4e184f0886248")
