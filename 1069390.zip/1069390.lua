-- Lua provided by RyzenAPI 
-- Game: Morningdew Farms: A Gay Farming Game
addappid(1069390)
addappid(1069391, 1, "2057cefeeaea92b7c4cd09e30756a437478d2a6ed9ba1a2ff4b76ce892abd8fa")
addappid(1154280)
addappid(1160990)
