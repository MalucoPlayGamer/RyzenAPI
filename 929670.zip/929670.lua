-- Lua provided by RyzenAPI
-- Game: 929670

-- MAIN APPLICATION
addappid(929670)
-- Game: addappid(929670)

-- MAIN APP DEPOTS / PACKAGES
addappid(929671, 1, "5f355a501d90cfe3762756146281fd34ee4a51d28ad816b8f7dd08a3cc8ffbf2")
