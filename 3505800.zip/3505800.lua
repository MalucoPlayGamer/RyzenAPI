-- Lua provided by RyzenAPI
-- Game: Yurei Hunt

-- MAIN APPLICATION
addappid(3505800)
-- Game: addappid(3505800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3505801, 1, "9521415f6188d413f1ceb9f8efa8aa01177dd315142a3d95cd6bd73c320ad8ed")
