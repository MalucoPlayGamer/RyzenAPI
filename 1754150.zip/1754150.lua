-- Lua provided by RyzenAPI
-- Game: Car Tuning Simulator

-- MAIN APPLICATION
addappid(1754150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754151, 1, "98b28c381410b9a0c575dfe45f293f4c26298a596d52311c3f5f4a4e5cdea4c0")

