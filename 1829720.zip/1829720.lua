-- Lua provided by RyzenAPI
-- Game: addappid(1829720)

-- MAIN APPLICATION
addappid(1829720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829721, 1, "f337ab8d90a02606417fd0c36e4c7a7ca839e5929b9a21e5a55e0922d38797e1")
