-- Lua provided by RyzenAPI
-- Game: 458890

-- MAIN APPLICATION
addappid(458890)
-- Game: addappid(458890)

-- MAIN APP DEPOTS / PACKAGES
addappid(458891, 1, "249d0e04bb20ea53decf6b8da4841ffa40f4633edb550a47754f63890e15bd46")
