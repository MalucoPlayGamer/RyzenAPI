-- Lua provided by RyzenAPI
-- Game: Game: AppID 2169110

-- MAIN APPLICATION
addappid(2169110)
-- Game: addappid(2169110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169111, 1, "48cf83420546100088006140555f884d24bb673cffbf5c4e3fa16b47578eec83")
