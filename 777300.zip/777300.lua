-- Lua provided by RyzenAPI
-- Game: Game: The Placebos

-- MAIN APPLICATION
addappid(777300)
-- Game: addappid(777300)

-- MAIN APP DEPOTS / PACKAGES
addappid(777301, 1, "a5d041e760a8b2e73627d3bdcda7b6dc3b4143355f2d2d88d21ac202046745f8")
