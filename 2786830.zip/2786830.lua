-- Lua provided by RyzenAPI
-- Game: Epstein

-- MAIN APPLICATION
addappid(2786830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2786831, 1, "9ac66787a0819a751f10893dc70e31fc2156ba8bde047972c7efb58f03ca9c10")

