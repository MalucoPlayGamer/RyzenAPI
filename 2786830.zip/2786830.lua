-- Lua provided by RyzenAPI
-- Game: Epstein

-- MAIN APPLICATION
addappid(2786830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786831, 1, "9ac66787a0819a751f10893dc70e31fc2156ba8bde047972c7efb58f03ca9c10")

