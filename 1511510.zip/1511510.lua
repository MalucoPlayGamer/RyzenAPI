-- Lua provided by RyzenAPI
-- Game: addappid(1511510)

-- MAIN APPLICATION
addappid(1511510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511510,0,"105105c35ff61a61e071de9af09959e38f359143f92f11a76c35f2a41ba4a7dd")
