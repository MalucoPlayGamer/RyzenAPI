-- Lua provided by RyzenAPI
-- Game: Veiled Tales

-- MAIN APPLICATION
addappid(2772720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772721, 1, "e0f23f00e34b9d179b15c993e698f6ee61550892dabc8a35eab7d2c236852807")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
