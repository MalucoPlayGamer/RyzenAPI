-- Lua provided by RyzenAPI
-- Game: Veiled Tales

-- MAIN APPLICATION
addappid(2772720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772721, 1, "e0f23f00e34b9d179b15c993e698f6ee61550892dabc8a35eab7d2c236852807")

