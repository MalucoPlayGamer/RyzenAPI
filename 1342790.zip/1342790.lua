-- Lua provided by RyzenAPI
-- Game: GangV | VR & PC Battle Royale

-- MAIN APPLICATION
addappid(1342790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342791, 1, "34f9a250ba70e4afa7ace7a8c61c9695a6925af03105e8b06cfed6812f11b5a5")

