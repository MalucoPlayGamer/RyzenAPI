-- Lua provided by RyzenAPI
-- Game: Kind Words - Soundtrack

-- MAIN APPLICATION
addappid(1155430)
addappid(3250570)
-- Game: addappid(1155430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155430,0,"d7221817040f4d76726e394a0f5fa85c1fb54ea5fca77a057dbf7ebf95425dd3")
