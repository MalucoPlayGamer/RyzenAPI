-- Lua provided by RyzenAPI
-- Game: Chess Valley

-- MAIN APPLICATION
addappid(1485580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485581, 1, "58701112f3ad57948351f162d1da7c24574444bbeb4c31a5ec0e13b4f69dc0be")

