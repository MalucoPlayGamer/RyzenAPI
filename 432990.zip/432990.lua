-- Lua provided by RyzenAPI
-- Game: AppID 432990

-- MAIN APPLICATION
addappid(432990)

-- MAIN APP DEPOTS / PACKAGES
addappid(432991, 1, "6ce71c77dad28cd84e30524193fd35878d07da34db382586023585a5543ff7a9")
addappid(432992, 1, "4b19f05dcfd6396eb3ea92d82c0d51bb42433ea9c288a5581d3964d51271dab0")
addappid(432993, 1, "c65a842f14f2ae4caefc563248712457436f5a15b9cfc4b2f0e8eded428b7976")
addappid(432994, 1, "bfe42a60a5e69cd14bd0260763c002aa060cf956ca570c09947d0d09ac232c5e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
