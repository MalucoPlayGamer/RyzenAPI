-- Lua provided by RyzenAPI
-- Game: addappid(755790)

-- MAIN APPLICATION
addappid(755790)
addappid(938460)

-- MAIN APP DEPOTS / PACKAGES
addappid(755791, 1, "bc4906600d31988cd434d2673a231a2f915a8ff93a0247b4afbdec016979e5f8")
