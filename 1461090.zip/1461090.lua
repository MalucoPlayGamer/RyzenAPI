-- Lua provided by RyzenAPI
-- Game: 喰人記

-- MAIN APPLICATION
addappid(1461090)
-- Game: addappid(1461090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461091, 1, "fee9e50f86d2a050a21ae51630a9b116b1059e10d05cdc1bf275f6100936280b")
