-- Lua provided by RyzenAPI
-- Game: 1932360

-- MAIN APPLICATION
addappid(1932360)
addappid(3273050)
-- Game: addappid(1932360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932361, 1, "3b0dadab4594e07904a8a17102a2596166fb5954b0517071d047e8b9a7d46e0c")
