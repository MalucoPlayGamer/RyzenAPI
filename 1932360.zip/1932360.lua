-- Lua provided by RyzenAPI
-- Game: Death Duel VR

-- MAIN APPLICATION
addappid(1932360)
addappid(3273050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932361, 1, "3b0dadab4594e07904a8a17102a2596166fb5954b0517071d047e8b9a7d46e0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
