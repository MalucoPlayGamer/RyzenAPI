-- Lua provided by RyzenAPI
-- Game: 1386890

-- MAIN APPLICATION
addappid(1386890)
-- Game: addappid(1386890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386891, 1, "e4dfcc461bf3196d4b03cf55f895537a7b64f64daf8579c1dadbd4158c499091")
