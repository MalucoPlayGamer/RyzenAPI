-- Lua provided by RyzenAPI
-- Game: Hyper Dash

-- MAIN APPLICATION
addappid(1386890)
addappid(3557840)
addappid(3557850)
addappid(3642790)
addappid(3642800)
addappid(3743040)
addappid(3918550)
addappid(4075010)
addappid(4201820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386891, 1, "e4dfcc461bf3196d4b03cf55f895537a7b64f64daf8579c1dadbd4158c499091")

