-- Lua provided by RyzenAPI
-- Game: Game: Stagelands – eternal defense

-- MAIN APPLICATION
addappid(2595880)
-- Game: addappid(2595880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595881, 1, "40c30b4736dc8db4e7b20762beda63e6494c721df918c186515e1ef497022e83")
