-- Lua provided by RyzenAPI
-- Game: Daydream: Forgotten Sorrow

-- MAIN APPLICATION
addappid(1542110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1542111, 1, "04321ff9f2ae8d71864cf09a7457b535d2514ea68a6f40bb96e1490d49d37294")

