-- Lua provided by RyzenAPI
-- Game: Daydream: Forgotten Sorrow

-- MAIN APPLICATION
addappid(1542110)
-- Game: addappid(1542110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542111, 1, "04321ff9f2ae8d71864cf09a7457b535d2514ea68a6f40bb96e1490d49d37294")
