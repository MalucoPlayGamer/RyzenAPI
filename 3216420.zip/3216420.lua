-- Lua provided by RyzenAPI 
-- Game: EcoGnomix Original Soundtrack
addappid(3216420)
addappid(3216421, 1, "0372b8dbaa024aa7284be8bb11808818687377aebde6f8360d68cb2ba831c047")
addappid(3216422, 1, "dfba124c8e7769ba936ebc2ae2c9c03240e3d17a5ef81a6724638a9b53f40628")
