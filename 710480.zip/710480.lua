-- Lua provided by RyzenAPI
-- Game: 710480

-- MAIN APPLICATION
addappid(710480)
-- Game: addappid(710480)

-- MAIN APP DEPOTS / PACKAGES
addappid(710481, 1, "66eb1da5f047d0da014e76bb67b9f4eb2de053d25141ed74ee48779a99a81eeb")
addappid(710482, 1, "7b2b0c54d402b4435dd5ea99d09a4b642e1a9ce191d42ed3f03368668537975e")
