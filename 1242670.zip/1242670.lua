-- Lua provided by RyzenAPI
-- Game: RollingSky

-- MAIN APPLICATION
addappid(1242670)
-- Game: addappid(1242670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242671, 1, "9493dce6761cebfb13fe2b5d43f19d53b55ea1d2f7a3bc1488382f6a27efb0b0")
