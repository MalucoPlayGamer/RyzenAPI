-- Lua provided by RyzenAPI
-- Game: Game: Heroes of Annihilated Empires

-- MAIN APPLICATION
addappid(4800)
-- Game: addappid(4800)

-- MAIN APP DEPOTS / PACKAGES
addappid(4801, 1, "d3b6f59a0c423a7e5d6e7404982381da5d59bcf73f5e6e4d561356f2a6b85955")
addappid(4802, 1, "1d7ea4cb5cfd887d5129d51a6b906fd41ddf9952a239924626cfa9c351933e54")
addappid(4803, 1, "867103e78e66a364e736a4793406b9f6d2c157c5f568c6b206e6ab975cd5bc1f")
addappid(4804, 1, "c02f42fdff14623cac0973b5814b7d93a06466a8b34ee23838d3180d597da423")
addappid(4805, 1, "85c4d8d051ef96993c5791331239fcae9e3fb251d18db2ddad23cda35f2a6684")
addappid(4815, 1, "6b644142dd172dc2ce671bb971595b23b5f298b8b60974500341d8e40c430f47")
