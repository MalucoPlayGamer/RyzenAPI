-- Lua provided by RyzenAPI
-- Game: MOVAFORT

-- MAIN APPLICATION
addappid(2079600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079601, 1, "6545429edbbba93d4ecbee2ccc0d30e51decbf5a1105c28db4e7eb7c5b8c40f0")
