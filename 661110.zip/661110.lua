-- Lua provided by RyzenAPI
-- Game: Shattered God - Quest for the Divine Relic

-- MAIN APPLICATION
addappid(661110)

-- MAIN APP DEPOTS / PACKAGES
addappid(661111, 1, "989ad7586f79a850ae0daab32b1a993f093a762ea2432587b3447d9963d5dd69")
