-- Lua provided by RyzenAPI
-- Game: Shattered God - Quest for the Divine Relic

-- MAIN APPLICATION
addappid(661110)

-- MAIN APP DEPOTS / PACKAGES
addappid(661111, 1, "989ad7586f79a850ae0daab32b1a993f093a762ea2432587b3447d9963d5dd69")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
