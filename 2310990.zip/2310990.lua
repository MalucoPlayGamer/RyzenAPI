-- Lua provided by RyzenAPI
-- Game: Emergency Parking Only

-- MAIN APPLICATION
addappid(2310990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310991, 1, "f279c3fb08c2cb7009f83342a05911b6bb3da855adcc1335032eed698eb4837e")
