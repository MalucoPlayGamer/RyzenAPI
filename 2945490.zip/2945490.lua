-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2945490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945490,0,"dac84bfcb38c38f65053a0bc06988298432b02ac27ba51205b89a6c143a2cba9")

