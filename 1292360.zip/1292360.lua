-- Lua provided by RyzenAPI
-- Game: AppID 1292360

-- MAIN APPLICATION
addappid(1292360)
-- Game: addappid(1292360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292361, 1, "4f54e7408d46a8cbf86049e404f5686782f62783557bdb29fffad4ce6b9eb052")
