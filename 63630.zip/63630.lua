-- Lua provided by RyzenAPI
-- Game: 63630

-- MAIN APPLICATION
addappid(63630)
-- Game: addappid(63630)

-- MAIN APP DEPOTS / PACKAGES
addappid(63631, 1, "9f93514265104430fab86a86b5fd58134980712d898dec69e7d19ab54a1271f6")
