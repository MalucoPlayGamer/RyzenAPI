-- Lua provided by RyzenAPI 
-- Game: SHADOW
addappid(2740290)
addappid(2740291, 1, "6f98f93505e9c28d8b5efc24348f69adf8a2096730c7e71d5ada8f99db0ff9fe")
