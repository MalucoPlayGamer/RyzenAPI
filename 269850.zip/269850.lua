-- Lua provided by RyzenAPI 
-- Game: AppID 269850
addappid(269850)
addappid(269851, 1, "78c10d816df8c8ff532c3e507a825b8daab0591645bdbaf9b24bc94e06c5f711")
