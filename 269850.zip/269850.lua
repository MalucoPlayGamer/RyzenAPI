-- Lua provided by RyzenAPI
-- Game: Get Packed

-- MAIN APPLICATION
addappid(269850)

-- MAIN APP DEPOTS / PACKAGES
addappid(269851, 1, "78c10d816df8c8ff532c3e507a825b8daab0591645bdbaf9b24bc94e06c5f711")

