-- Lua provided by RyzenAPI
-- Game: setManifestid(229000,"4622705914179893434")

-- MAIN APPLICATION
addappid(229000)
addappid(229001)
addappid(1141120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141122,0,"6403f4bccd615b628a25a15a30e20f4b484a1d483b48ab3d6d2005ba5b73487b")
