-- Lua provided by RyzenAPI
-- Game: No More Room in Hell

-- MAIN APPLICATION
addappid(224260)

-- MAIN APP DEPOTS / PACKAGES
addappid(224261, 1, "bfd0df36252eee487fc1f04740fe609457da8672f9d0672da0a96026f09109be")
addappid(224262, 1, "6c375fbc3957e3f37c6faec07844205e5069a1cdd2ece11b8918e901599f1f7c")
addappid(224265, 1, "405e32e56a563553f8c3b22f9b6655e1a871f43b6b4fd95220243cf46e91442b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
