-- Lua provided by SkyAPI 
-- Game: No More Room in Hell
addappid(224260)
addappid(224261, 1, "bfd0df36252eee487fc1f04740fe609457da8672f9d0672da0a96026f09109be")
addappid(224262, 1, "6c375fbc3957e3f37c6faec07844205e5069a1cdd2ece11b8918e901599f1f7c")
addappid(224265, 1, "405e32e56a563553f8c3b22f9b6655e1a871f43b6b4fd95220243cf46e91442b")
