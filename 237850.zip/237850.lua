-- Lua provided by RyzenAPI
-- Game: Dreamfall Chapters

-- MAIN APPLICATION
addappid(237850)
addappid(320530)

-- MAIN APP DEPOTS / PACKAGES
addappid(237851, 1, "cc8c0a6d5bf2175fdb5c4bbaa54937b674048689e21012b3ef9459911b5315d4")
addappid(237852, 1, "cec4a703c0c7e2169630e97e5ae0673d8f50f4049ddab4466d8b01266a787987")
addappid(237853, 1, "eaee00f0e8a12ffa168a4b67a2041824b4d431071757b7e59ae74206c1f2eee1")
addappid(237854, 1, "72c880bbc8796f2884adbd04ac2fb4e110549a04c975d35490708b96e32d6a4f")
addappid(237855, 1, "f495fdc106a95d9e2472eea3ce96c60708f41d18de584ff5feffb6618d9b88ea")
addappid(237856, 1, "3d4db27b23ffcb507e32ad00372f40f3e1d17cd816e288d8af3439bb22687a08")
addappid(237857, 1, "b495f105e6c3898b5ac219f5b3f887c01f307ea02f3d72014a5565f1d6815e30")
addappid(237858, 1, "11cab906dd226c2a3e108ec4de63d14327e5c739d17e69169faa31f756ed8ea3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(635300)
