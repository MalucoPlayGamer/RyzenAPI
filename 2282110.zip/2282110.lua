-- Lua provided by RyzenAPI
-- Game: 2282110

-- MAIN APPLICATION
addappid(2282110)
-- Game: addappid(2282110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282111, 1, "c67f771286b488b73a9a58d369ba3447d7341c4f84c636a85d0fe8e3b3a90e57")
