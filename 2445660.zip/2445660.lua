-- Lua provided by RyzenAPI
-- Game: Shipping Manager

-- MAIN APPLICATION
addappid(2445660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445662,0,"2ba5a6a3e94fe7c41efbf4ca6b631e1f1d1843596cd54129a2e8c8b1b11c8d91")
addappid(2445663,0,"3ef1dcac532ce33fe55451864e5037f3c98ca742d895b86007cabbcea29f81fe")

