-- Lua provided by SkyAPI 
-- Game: AppID 1350850
addappid(1350850)
addappid(1350851, 1, "405db8b7c4a841788f69d59a7d464e7dc88345c49012a8b3141e20582f02d186")
addappid(1350852, 1, "f40f6ae684caa6e4f551b6de1ce886b79686fcadf27fb8bf66009e6e8367450d")
