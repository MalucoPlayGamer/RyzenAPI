-- 4456630's Lua and Manifest Created by Hubcap Manifest
-- Incremental Fishing
-- Created: August 12, 2026 at 15:00:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4456630) -- Incremental Fishing
-- MAIN APP DEPOTS
addappid(4456631, 1, "ce083e8ac2a3cb968334a959f10f361c88ca4c1e16edaa2a55ce6ddae569764e") -- Depot 4456631
setManifestid(4456631, "2410623410957560290", 174540838)