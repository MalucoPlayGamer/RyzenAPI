-- Lua provided by RyzenAPI
-- Game: Incremental Fishing

-- MAIN APPLICATION
addappid(4456630) -- Incremental Fishing

-- MAIN APP DEPOTS / PACKAGES
addappid(4456631, 1, "ce083e8ac2a3cb968334a959f10f361c88ca4c1e16edaa2a55ce6ddae569764e") -- Depot 4456631

