-- 4456630's Lua and Manifest Created by Hubcap Manifest
-- Incremental Fishing
-- Created: August 28, 2026 at 03:21:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4456630) -- Incremental Fishing
-- MAIN APP DEPOTS
addappid(4456631, 1, "ce083e8ac2a3cb968334a959f10f361c88ca4c1e16edaa2a55ce6ddae569764e") -- Depot 4456631
setManifestid(4456631, "4366557390898906907", 166517321)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5065280) -- Incremental Fishing - Supporter Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4456632) -- Depot 4456632 (empty depot)