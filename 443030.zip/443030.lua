-- Lua provided by RyzenAPI
-- Game: Conan Exiles Dedicated Server

-- MAIN APPLICATION
addappid(443030)

-- MAIN APP DEPOTS / PACKAGES
addappid(443031, 1, "f55c3e712ca3baf14da3e30c692f9b628b999e144b6570916b42db300bad2e64")
addappid(443032, 1, "820f1c7ccd1463eaa7052a7802e9dbb4e02f45b77ae274e2a9d3463982595814")
