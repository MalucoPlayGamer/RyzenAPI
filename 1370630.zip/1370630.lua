-- Lua provided by RyzenAPI 
-- Game: Sport Girls
addappid(1370630)
addappid(1370631, 1, "243f3666afa81d7c935abaac5c20bf01d7c869478e87ec5ab0ba69827210d167")
