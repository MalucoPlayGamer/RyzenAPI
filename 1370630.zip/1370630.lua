-- Lua provided by RyzenAPI
-- Game: Game: Sport Girls

-- MAIN APPLICATION
addappid(1370630)
-- Game: addappid(1370630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370631, 1, "243f3666afa81d7c935abaac5c20bf01d7c869478e87ec5ab0ba69827210d167")
