-- Lua provided by RyzenAPI
-- Game: Epic Battle Fantasy 4

-- MAIN APPLICATION
addappid(265610)

-- MAIN APP DEPOTS / PACKAGES
addappid(265611, 1, "f31d7fcbf607c5bb60f1f78a65e853c3027dff5ae93da65568dd1e0f5bdfa9e0")
