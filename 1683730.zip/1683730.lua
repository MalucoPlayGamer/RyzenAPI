-- Lua provided by RyzenAPI
-- Game: Welcome to PINEHILLS

-- MAIN APPLICATION
addappid(1683730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683731, 1, "e6a59ef8065a7322b1ec91b1fd0cb4a0b0678fc6b0dd688f503f303de046595d")
