-- Lua provided by RyzenAPI
-- Game: addappid(3459740)

-- MAIN APPLICATION
addappid(3459740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3459741, 1, "ae4f43738951ec39e2b747a29d3a09ccc9f0d376b6837e0d10c1a1d4cb36c7d9")
