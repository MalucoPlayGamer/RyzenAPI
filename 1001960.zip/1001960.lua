-- Lua provided by RyzenAPI
-- Game: AppID 1001960

-- MAIN APPLICATION
addappid(1001960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1001961, 1, "2c0ba50fd8046212b9a800b3eeb7ff12b8ee66d9c5533e6181012554429b9d6c")

