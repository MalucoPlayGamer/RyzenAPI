-- Lua provided by RyzenAPI
-- Game: Game: AppID 1001960

-- MAIN APPLICATION
addappid(1001960)
-- Game: addappid(1001960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001961, 1, "2c0ba50fd8046212b9a800b3eeb7ff12b8ee66d9c5533e6181012554429b9d6c")
