-- Lua provided by RyzenAPI
-- Game: 2017640

-- MAIN APPLICATION
addappid(2017640)
-- Game: addappid(2017640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017641, 1, "082ede6de577c3d26b17790d30fc75be73d0ffde4a0162ab83d419c926e28c7e")
