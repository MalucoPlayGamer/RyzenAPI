-- Lua provided by RyzenAPI 
-- Game: Steve's Warehouse: Physics. Roguelike. Chaos.
addappid(2902440)
addappid(2902441, 1, "a0f93ab42387d5cd212ba9413aee0c2a6f6e104b97a5ccdeaab71ab3e77a9cca")
