-- Lua provided by RyzenAPI
-- Game: addappid(2902440)

-- MAIN APPLICATION
addappid(2902440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902441, 1, "a0f93ab42387d5cd212ba9413aee0c2a6f6e104b97a5ccdeaab71ab3e77a9cca")
