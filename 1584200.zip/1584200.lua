-- Lua provided by RyzenAPI 
-- Game: AppID 1584200
addappid(1584200)
addappid(1584201, 1, "7588baeb595b4810dec94c4d620715aad4aa257970af6529f09a99d407062d9a")
