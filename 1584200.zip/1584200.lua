-- Lua provided by RyzenAPI
-- Game: AppID 1584200

-- MAIN APPLICATION
addappid(1584200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1584201, 1, "7588baeb595b4810dec94c4d620715aad4aa257970af6529f09a99d407062d9a")

