-- Lua provided by RyzenAPI
-- Game: 1584200

-- MAIN APPLICATION
addappid(1584200)
-- Game: addappid(1584200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584201, 1, "7588baeb595b4810dec94c4d620715aad4aa257970af6529f09a99d407062d9a")
