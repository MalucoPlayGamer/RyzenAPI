-- Lua provided by RyzenAPI
-- Game: Ring Stars

-- MAIN APPLICATION
addappid(2545020)
-- Game: addappid(2545020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545021, 1, "96954d6bff981547f057077c4712854a4b797c7b87a025ebe5e25050430a0f14")
