-- Lua provided by RyzenAPI
-- Game: Game: Stick Slasher

-- MAIN APPLICATION
addappid(2549950)
-- Game: addappid(2549950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549951, 1, "987109c00113a6e83c2493991666449c288a67f79ea055463dfc0459f6928e71")
