-- Lua provided by SkyAPI 
-- Game: EvilMorph
addappid(562490)
addappid(562491, 1, "546e16df79e1b914fdb5b9f594da5283caf80a7c05c20586b03e7e1a3d8bcf92")
addappid(586500, 0, "467663deb75b3b89ec7f065991a554189b56e08d4a099c5b8840281960b83472")
