-- Lua provided by RyzenAPI
-- Game: Game: Half-Life: VR Mod

-- MAIN APPLICATION
addappid(1908720)
-- Game: addappid(1908720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908721, 1, "aa4fa33a4780625c1de2d18cfb0935b9a62a8934819e1beb1eee3505f6f5fa24")
