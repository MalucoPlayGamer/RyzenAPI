-- Lua provided by RyzenAPI
-- Game: Half-Life: VR Mod

-- MAIN APPLICATION
addappid(1908720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1908721, 1, "aa4fa33a4780625c1de2d18cfb0935b9a62a8934819e1beb1eee3505f6f5fa24")

