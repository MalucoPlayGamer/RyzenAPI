-- Lua provided by RyzenAPI
-- Game: 726430

-- MAIN APPLICATION
addappid(726430)
-- Game: addappid(726430)

-- MAIN APP DEPOTS / PACKAGES
addappid(726431, 1, "a876d74c4b962714f623a930fdda4a46f45fb7479b270186fb3f282ca4afd708")
