-- Lua provided by RyzenAPI
-- Game: GoalkeepVr

-- MAIN APPLICATION
addappid(573550)

-- MAIN APP DEPOTS / PACKAGES
addappid(573551, 1, "8669b5afb340479ef11d6dcbfce9736df5872ed198aaf67a5305ae2b9e840bc3")
