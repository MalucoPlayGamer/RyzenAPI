-- Lua provided by SkyAPI 
-- Game: GoalkeepVr
addappid(573550)
addappid(573551, 1, "8669b5afb340479ef11d6dcbfce9736df5872ed198aaf67a5305ae2b9e840bc3")
