-- Lua provided by RyzenAPI
-- Game: 1.80战神微变

-- MAIN APPLICATION
addappid(4714000)

