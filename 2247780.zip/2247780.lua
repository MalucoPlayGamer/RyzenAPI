-- Lua provided by RyzenAPI
-- Game: Eastern Europe Bus Sim

-- MAIN APPLICATION
addappid(2247780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247781, 1, "56220ca2977c7ae5847495f512e81fd5ce93a3f245d3f9f09f8865569930168e")
