-- Lua provided by SkyAPI 
-- Game: Dark Throne : The Queen Rises
addappid(2124570)
addappid(2124571, 1, "77f85568e970a6a487420350d9fc0b79fcca1f5ab5054ed76052d1ac2578c415")
addappid(2124572, 1, "3ab317b406cf7b034a08aac862610286a77d2ff2c70d385f074778dbb21b60b8")
