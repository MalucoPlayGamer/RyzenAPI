-- Lua provided by RyzenAPI
-- Game: Dark Throne : The Queen Rises

-- MAIN APPLICATION
addappid(2124570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2124571, 1, "77f85568e970a6a487420350d9fc0b79fcca1f5ab5054ed76052d1ac2578c415")
addappid(2124572, 1, "3ab317b406cf7b034a08aac862610286a77d2ff2c70d385f074778dbb21b60b8")

