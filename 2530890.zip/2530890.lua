-- Lua provided by RyzenAPI
-- Game: Fruit Conflict

-- MAIN APPLICATION
addappid(2530890)
addappid(2734960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530891, 1, "44a33cceab7180540a23b850bc71bda9ed645ad283474895da9bffbf185376de")

