-- Lua provided by RyzenAPI 
-- Game: Eternal Edge +
addappid(896440)
addappid(896441, 1, "11e0aae44dcf338283a530a05af164937cf7ccab736cf492de6892f0f1a5776e")
