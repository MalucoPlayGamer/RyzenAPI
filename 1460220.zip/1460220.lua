-- Lua provided by RyzenAPI
-- Game: Evil Nun: The Broken Mask

-- MAIN APPLICATION
addappid(1460220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460221, 1, "a9e01bf44a482319d5c8e88061cf2ed4d9cd91c0746c8eea1dc5ab9aa54635cd")

