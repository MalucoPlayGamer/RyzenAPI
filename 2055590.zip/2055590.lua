-- Lua provided by RyzenAPI
-- Game: Star Overdrive

-- MAIN APPLICATION
addappid(2055590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055591, 1, "aac10a225fadffc8c80bb9d6a5fc56bc91de6418ca92399910c044aab6044da4")
addappid(3710290, 0, "b48f950dc13e00a049d63ac95e4e2332c07a5ce7c5f0216feaf4f042f5ca7c47")
addappid(3710300, 0, "2dcfe00ace555c859797454b56baf36aeac90ef743a13aa6a846545b2662a3f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
