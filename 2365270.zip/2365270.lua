-- Lua provided by RyzenAPI
-- Game: addappid(2365270)

-- MAIN APPLICATION
addappid(2365270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365271, 1, "674e9e026208f2bb4b4c04fb55cd4f06f2260e3817db2ba9b2570175f928aed5")
