-- Lua provided by RyzenAPI
-- Game: Darksiders II - Van Der Schmash Hammer

-- MAIN APPLICATION
addappid(215818)

-- MAIN APP DEPOTS / PACKAGES
addappid(215818,0,"06dd9b71b99b73be3f5f9c30c9f520a5a682214b407fc5c870eda4236e56b3f9")

