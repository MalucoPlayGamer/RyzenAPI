-- Lua provided by RyzenAPI
-- Game: Spooky Shelter

-- MAIN APPLICATION
addappid(2343720)
addappid(2344420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2343722,0,"6e918579c93dc494146a53159b4f8f381eef2d8679644933a59477ec37c799c4")

