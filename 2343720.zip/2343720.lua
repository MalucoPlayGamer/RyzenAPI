-- Lua provided by RyzenAPI
-- Game: Spooky Shelter

-- MAIN APPLICATION
addappid(2343720)
-- Game: addappid(2343720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343722,0,"6e918579c93dc494146a53159b4f8f381eef2d8679644933a59477ec37c799c4")
