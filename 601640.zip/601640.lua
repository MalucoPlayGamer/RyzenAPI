-- Lua provided by RyzenAPI
-- Game: The guard of dungeon

-- MAIN APPLICATION
addappid(601640)
addappid(754550)
-- Game: addappid(601640)

-- MAIN APP DEPOTS / PACKAGES
addappid(601641, 1, "e3cf57f84aa4b57a601a3c44b1f74d51e61c26e4cf340962e7f91fe43ae9e4ef")
