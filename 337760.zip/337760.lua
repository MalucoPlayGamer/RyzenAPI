-- Lua provided by RyzenAPI
-- Game: 337760

-- MAIN APPLICATION
addappid(337760)
-- Game: addappid(337760)

-- MAIN APP DEPOTS / PACKAGES
addappid(337761, 1, "d5e736d872e11a20134998be4c7239ccba877f53a58d1c3e8d916712ec73f157")
