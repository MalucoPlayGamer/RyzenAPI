-- Lua provided by RyzenAPI
-- Game: AppID 337760

-- MAIN APPLICATION
addappid(337760)

-- MAIN APP DEPOTS / PACKAGES
addappid(337761, 1, "d5e736d872e11a20134998be4c7239ccba877f53a58d1c3e8d916712ec73f157")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
