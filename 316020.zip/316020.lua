-- Lua provided by RyzenAPI 
-- Game: Hangeki
addappid(316020)
addappid(316021, 1, "072ef7faad74f5531c458207e197f156644d5d8f1d31915e7c20da24de7392ba")
