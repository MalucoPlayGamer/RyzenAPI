-- Lua provided by RyzenAPI
-- Game: Game: Hangeki

-- MAIN APPLICATION
addappid(316020)
-- Game: addappid(316020)

-- MAIN APP DEPOTS / PACKAGES
addappid(316021, 1, "072ef7faad74f5531c458207e197f156644d5d8f1d31915e7c20da24de7392ba")
