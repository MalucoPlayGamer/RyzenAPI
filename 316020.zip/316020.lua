-- Lua provided by RyzenAPI
-- Game: Hangeki

-- MAIN APPLICATION
addappid(316020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(316021, 1, "072ef7faad74f5531c458207e197f156644d5d8f1d31915e7c20da24de7392ba")

