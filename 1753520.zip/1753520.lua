-- Lua provided by RyzenAPI
-- Game: addappid(1753520)

-- MAIN APPLICATION
addappid(1753520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753520,0,"550f7dd878fcdc1566ab1663ef1c2384e17cda77ef21eb05df069c6b57603f24")
