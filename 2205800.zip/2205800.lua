-- Lua provided by RyzenAPI
-- Game: CyberBrick

-- MAIN APPLICATION
addappid(2205800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205801, 1, "0f100f223bdf7ed845d5dde87018a9eae9e10ca4965de90e8d9d6f6d1c2c7324")

