-- Lua provided by RyzenAPI
-- Game: Arashi: Castles of Sin - Final Cut

-- MAIN APPLICATION
addappid(2434420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434421, 1, "29674b002b73cdb667eb4db46c77859144bc398e193bd5c8e04267b6ab5185fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
