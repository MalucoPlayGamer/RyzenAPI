-- Lua provided by RyzenAPI
-- Game: Arashi: Castles of Sin - Final Cut

-- MAIN APPLICATION
addappid(2434420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434421, 1, "29674b002b73cdb667eb4db46c77859144bc398e193bd5c8e04267b6ab5185fc")
