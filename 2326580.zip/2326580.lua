-- Lua provided by SkyAPI 
-- Game: AppID 2326580
addappid(2326580)
addappid(2326581, 1, "ef53199e5f90be69a1e600e720e03dfa889ca33d36da567b32bdce74d91bd92d")
addappid(2326582, 1, "e40b2d5fa707dba9114813c0eeb2a751688a9a5f3a0714c7df19e9bee2d5195e")
