-- Lua provided by RyzenAPI
-- Game: Vanity Fair: The Pursuit

-- MAIN APPLICATION
addappid(2758000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758001, 1, "70d82cd1e81fe339eb087ae9438c39ee6e0540ab7f6efeaab136e4ca57f85199")

