-- Lua provided by RyzenAPI
-- Game: addappid(2383850)

-- MAIN APPLICATION
addappid(2383850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383851, 1, "70749174c310acb373d939645ea5c977e7af5ee22ea1d2086c2f0ddb89312ba3")
