-- Lua provided by RyzenAPI
-- Game: Piano at 5 a.m.

-- MAIN APPLICATION
addappid(2378460)
-- Game: addappid(2378460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378461, 1, "28d4f3a5740eec456c28cb620c00fcd741129c8b7a92a37e8c4a2ffc756df768")
addappid(2378462, 1, "7b59f4f8c2fd997adc2016daac5c5fc8cc6f7963f7d45ae3f118057c152f7a6d")
addappid(2378463, 1, "70bf77d0a46e09852c1dfb8ab45fb0fcd577d1cf1cb945b44dc4ea693d1b1e01")
