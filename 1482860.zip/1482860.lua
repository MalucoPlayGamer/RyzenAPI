-- Lua provided by RyzenAPI
-- Game: Idle Research

-- MAIN APPLICATION
addappid(1482860)

