-- Lua provided by RyzenAPI
-- Game: AppID 1608470

-- MAIN APPLICATION
addappid(1608470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1608471, 1, "685dfc0ea1beebf4266f2b08e2afdf0aa7ca8b42ebda0205ad12b214aa51fb96")

