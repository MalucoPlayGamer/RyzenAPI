-- Lua provided by RyzenAPI
-- Game: addappid(1608470)

-- MAIN APPLICATION
addappid(1608470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608471, 1, "685dfc0ea1beebf4266f2b08e2afdf0aa7ca8b42ebda0205ad12b214aa51fb96")
