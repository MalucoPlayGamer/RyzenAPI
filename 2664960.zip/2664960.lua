-- Lua provided by RyzenAPI
-- Game: Game: 帝缚山海

-- MAIN APPLICATION
addappid(2664960)
-- Game: addappid(2664960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664961, 1, "00d9b2e021b2e72fe14dc2e20da1a4b7a34a615e5af78c3cb5c3268da1f356e4")
