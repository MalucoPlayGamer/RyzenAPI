-- 3417940's Lua and Manifest Created by Hubcap Manifest
-- Cat Chaos
-- Created: August 05, 2026 at 22:37:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3417940) -- Cat Chaos
-- MAIN APP DEPOTS
addappid(3417942, 1, "dd2e300ad2d1699da67fe510c0cebf82ef9cce85c53cd7df27dba551cf92aa59") -- Depot 3417942
setManifestid(3417942, "7088647548971386702", 723245029)
addappid(3417941, 1, "e0d5ad983ecc92d00a5333049fc9cf738669351e4388897b367c691e71b518fb") -- Depot 3417941
setManifestid(3417941, "7708618161075562157", 761377338)