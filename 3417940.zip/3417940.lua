-- Lua provided by RyzenAPI
-- Game: Cat Chaos

-- MAIN APPLICATION
addappid(3417940) -- Cat Chaos

-- MAIN APP DEPOTS / PACKAGES
addappid(3417941, 1, "e0d5ad983ecc92d00a5333049fc9cf738669351e4388897b367c691e71b518fb") -- Depot 3417941
addappid(3417942, 1, "dd2e300ad2d1699da67fe510c0cebf82ef9cce85c53cd7df27dba551cf92aa59") -- Depot 3417942

