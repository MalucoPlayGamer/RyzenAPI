-- Lua provided by RyzenAPI
-- Game: 2800010

-- MAIN APPLICATION
addappid(2800010)
-- Game: addappid(2800010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800011, 1, "badca74ae01b1374e5136ef535177ab5084661172932daaf3fb29e97e0b78b25")
