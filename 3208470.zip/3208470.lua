-- Lua provided by RyzenAPI
-- Game: Magic Sword

-- MAIN APPLICATION
addappid(3208470)
-- Game: addappid(3208470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208471, 1, "412df573175f23f8616bb235fe0fd34045fc5c926198e9c58611b0b5c4515b4b")
