-- Lua provided by SkyAPI 
-- Game: Magic Sword
addappid(3208470)
addappid(3208471, 1, "412df573175f23f8616bb235fe0fd34045fc5c926198e9c58611b0b5c4515b4b")
