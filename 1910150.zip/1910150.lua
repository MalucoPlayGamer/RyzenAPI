-- Lua provided by RyzenAPI
-- Game: Walk of Life

-- MAIN APPLICATION
addappid(1910150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1910151, 1, "5cbbc95cccd40e60f11b5d0fb36915125437fd13361dfa371a3d98e334b8a79b")
addappid(1910152, 1, "50e35cf8f7bd0eef3ab674d866f80c22f2c5948017df217f5cc7d4ced8b16d6b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
