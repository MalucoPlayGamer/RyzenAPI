-- Lua provided by RyzenAPI
-- Game: 1543150

-- MAIN APPLICATION
addappid(1543150)
-- Game: addappid(1543150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543151, 1, "55ad2e5b849e1520d2b78cc3b48d7f6569773710fd24f0e950beacb5530f57e0")
