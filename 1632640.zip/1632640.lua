-- Lua provided by RyzenAPI 
-- Game: Bouncing Traveler
addappid(1632640)
addappid(1632641, 1, "60ca1a308b6cdfe3a49f55b82bcc92a53c2038840d74c2e4200c3b301fe386c3")
