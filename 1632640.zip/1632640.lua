-- Lua provided by RyzenAPI
-- Game: Bouncing Traveler

-- MAIN APPLICATION
addappid(1632640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632641, 1, "60ca1a308b6cdfe3a49f55b82bcc92a53c2038840d74c2e4200c3b301fe386c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
