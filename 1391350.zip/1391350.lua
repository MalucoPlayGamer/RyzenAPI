-- Lua provided by RyzenAPI
-- Game: Game: Happy Summer Holiday

-- MAIN APPLICATION
addappid(1391350)
-- Game: addappid(1391350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391351, 1, "151c8ad15ee34813867ada93876daaab5d3103542425e5425db4c58720963f6b")
