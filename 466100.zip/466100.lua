-- Lua provided by RyzenAPI
-- Game: Witches' Legacy: The Ties That Bind Collector's Edition

-- MAIN APPLICATION
addappid(466100)

-- MAIN APP DEPOTS / PACKAGES
addappid(466101, 1, "0ac2ddd5c68f63c31a1e2d8910192ac5a39dd8bb73444ca530c67c27c4aa6f11")

