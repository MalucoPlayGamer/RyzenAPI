-- Lua provided by RyzenAPI
-- Game: dungeon & heros

-- MAIN APPLICATION
addappid(1314170)
-- Game: addappid(1314170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314171, 1, "f5021c637fdd2bdfa73f38bc2df383697c073a43fa909717aedcf50d40df0430")
