-- Lua provided by RyzenAPI 
-- Game: Ghost Frequency Demo
addappid(3272570)
addappid(3272571, 1, "8f1d8d5c53bf949aa5af07c0f86616107a0ad7845e70101f5615d02c133b167b")
