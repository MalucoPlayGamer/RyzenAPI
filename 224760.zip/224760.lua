-- Lua provided by RyzenAPI 
-- Game: FEZ
addappid(224760)
addappid(224761, 1, "5cee956b25656115e424eafff4ed6154f0a0cfa95f7878f5e4b522e56a3e13a8")
addappid(224762, 1, "7841263bdb917e406f920643dc5e5788092320529e1dec608ac1670ad49ce3af")
addappid(224764, 1, "bf3f852a124f683798dfa5f480cb73e8367d227452ff1aab19ce8519463b685a")
addappid(228983)
addappid(229002)
