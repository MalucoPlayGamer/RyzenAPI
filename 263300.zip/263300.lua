-- Lua provided by RyzenAPI
-- Game: BlazBlue: Calamity Trigger

-- MAIN APPLICATION
addappid(263300)

-- MAIN APP DEPOTS / PACKAGES
addappid(263301, 1, "7697b7e83a550c2d028f063eb6d7e86cdcf158a48efd1a9c7ee08b3de077b1e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
