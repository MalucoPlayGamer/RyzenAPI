-- Lua provided by SkyAPI 
-- Game: CHAM THE CAT ADVENTURE
addappid(2729380)
addappid(2729381, 1, "80480a316ade375236dc3465f06ce517bad3642d7e98ac74bb54821e9bec17e7")
