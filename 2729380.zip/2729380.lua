-- Lua provided by RyzenAPI
-- Game: Game: CHAM THE CAT ADVENTURE

-- MAIN APPLICATION
addappid(2729380)
-- Game: addappid(2729380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729381, 1, "80480a316ade375236dc3465f06ce517bad3642d7e98ac74bb54821e9bec17e7")
