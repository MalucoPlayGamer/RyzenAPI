-- Lua provided by RyzenAPI
-- Game: 339160

-- MAIN APPLICATION
addappid(339160)
addappid(339165)
-- Game: addappid(339160)

-- MAIN APP DEPOTS / PACKAGES
addappid(339163,0,"7f22d04c61e9bf3d0bdeb9eabda7cd230be64cf94ecefc3a7afeb341fbccaea3")
addappid(339164,0,"0aafa82c63cb04068af89bb51195c2d877c0a6c1b9fdd82f81b08d2185e52d3a")
