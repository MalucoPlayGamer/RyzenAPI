-- Lua provided by SkyAPI 
-- Game: Chocolat Rush
addappid(987670)
addappid(987671, 1, "d63234c9b67847e6429238172eda9500c098aa5fe3cffa10d95416b143e35cc9")
