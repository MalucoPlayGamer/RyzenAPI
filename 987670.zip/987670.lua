-- Lua provided by RyzenAPI
-- Game: Game: Chocolat Rush

-- MAIN APPLICATION
addappid(987670)
-- Game: addappid(987670)

-- MAIN APP DEPOTS / PACKAGES
addappid(987671, 1, "d63234c9b67847e6429238172eda9500c098aa5fe3cffa10d95416b143e35cc9")
