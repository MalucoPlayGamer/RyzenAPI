-- Lua provided by RyzenAPI
-- Game: CPU Invaders

-- MAIN APPLICATION
addappid(595440)

-- MAIN APP DEPOTS / PACKAGES
addappid(595441, 1, "7d3a7a171cd9af08c1c1e15e01989c2bb40d68a37959e6c2a26cc9d5d09b17e9")
addappid(595830, 0, "ea349e8b1ce40b0029c431721a0a30ab08422c1aecd199c2e2fe0b9335800620")

