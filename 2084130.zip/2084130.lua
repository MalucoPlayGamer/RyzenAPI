-- Lua provided by RyzenAPI
-- Game: 2084130

-- MAIN APPLICATION
addappid(2084130)
-- Game: addappid(2084130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084131, 1, "1df7a8ad8fb65e00fdb59b757e91829567f12a36d47899de9478572bd9bdfd99")
