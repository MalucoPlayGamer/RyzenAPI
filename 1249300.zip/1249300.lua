-- Lua provided by RyzenAPI
-- Game: Game: AppID 1249300

-- MAIN APPLICATION
addappid(1249300)
-- Game: addappid(1249300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249301, 1, "80264b38248dccd78b021af904f9c2ffb7635d5a20e9c5e0ae13bd6a184ae4fb")
addappid(1249302, 1, "4287b737e01b583688fedc1cd415748e14831c08062a69d6cdbb8ffeddee95ad")
addappid(1249303, 1, "3c34bbc42f8b218ff3282766a07ee27c2907a0d10c9fd6a7f9e6df74ca1b7a0f")
