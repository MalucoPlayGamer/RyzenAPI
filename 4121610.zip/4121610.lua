-- 4121610's Lua and Manifest Created by Hubcap Manifest
-- Something to Drink?
-- Created: July 20, 2026 at 22:26:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4121610) -- Something to Drink?
-- MAIN APP DEPOTS
addappid(4121611, 1, "5482d9886612f2f5d58b28fde6f14522daec64b349753ab2d1b9054d0143bb4f") -- Depot 4121611
setManifestid(4121611, "3029181676043849526", 660558293)