-- Lua provided by RyzenAPI
-- Game: Something to Drink

-- MAIN APPLICATION
addappid(4121610)
addappid(4121610) -- Something to Drink?

-- MAIN APP DEPOTS / PACKAGES
addappid(4121611, 1, "5482d9886612f2f5d58b28fde6f14522daec64b349753ab2d1b9054d0143bb4f") -- Depot 4121611

