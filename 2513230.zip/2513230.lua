-- Lua provided by RyzenAPI
-- Game: Game: Pawggle

-- MAIN APPLICATION
addappid(2513230)
-- Game: addappid(2513230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2513231, 1, "7f14c22e3207c6a10786c4eb66ffd4d10c21ed854a45f5bdb60636a59ef054ac")
addappid(2513232, 1, "eac5a4e335342310ee506940da50cf5d206aa3e0580e6bd8e5427f261576a74b")
addappid(2513233, 1, "708be9c15dbde82f2e715e6220edc627550be10ea10bf7dfde6d612128e8f886")
