-- Lua provided by RyzenAPI
-- Game: Metal Commando

-- MAIN APPLICATION
addappid(1464730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464731, 1, "7899ce5ced39a0eaaf8ff72770fa0c7c5600365078d0e99c26695b25065c047c")

