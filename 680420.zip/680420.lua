-- Lua provided by RyzenAPI
-- Game: OUTRIDERS

-- MAIN APPLICATION
addappid(680420)

-- MAIN APP DEPOTS / PACKAGES
addappid(680421, 1, "a26f7079369468f2a0e6523cce9b57fbc6421f862d170e08c766049159d3a220")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1228540)
addappid(1785250)
