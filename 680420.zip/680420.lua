-- Lua provided by RyzenAPI
-- Game: Game: OUTRIDERS

-- MAIN APPLICATION
addappid(680420)
-- Game: addappid(680420)

-- MAIN APP DEPOTS / PACKAGES
addappid(680421, 1, "a26f7079369468f2a0e6523cce9b57fbc6421f862d170e08c766049159d3a220")
