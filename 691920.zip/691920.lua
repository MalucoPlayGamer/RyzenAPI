-- Lua provided by RyzenAPI
-- Game: 691920

-- MAIN APPLICATION
addappid(691920)
-- Game: addappid(691920)

-- MAIN APP DEPOTS / PACKAGES
addappid(691921, 1, "02ec4727dd0fd80dda9ccbf2cbaba89b95d4d225d161834aa784ad08f681ae34")
