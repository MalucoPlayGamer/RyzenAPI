-- Lua provided by RyzenAPI
-- Game: The Ultimate Death Clock

-- MAIN APPLICATION
addappid(2443910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443911, 1, "44ae304eb25dd3e52869f0ef2da41b3a2c04938c97b8b36707158aae25ef68ce")

