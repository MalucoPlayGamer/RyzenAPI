-- Lua provided by SkyAPI 
-- Game: The Ultimate Death Clock
addappid(2443910)
addappid(2443911, 1, "44ae304eb25dd3e52869f0ef2da41b3a2c04938c97b8b36707158aae25ef68ce")
