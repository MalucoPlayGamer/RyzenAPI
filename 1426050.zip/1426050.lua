-- Lua provided by RyzenAPI
-- Game: Fractured Online

-- MAIN APPLICATION
addappid(1426050)
-- Game: addappid(1426050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426051, 1, "692704f53a665d6c07500a71471483471a6417262c5b3cf7d227ed340886fb60")
