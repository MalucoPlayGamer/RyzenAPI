-- Lua provided by SkyAPI 
-- Game: Fractured Online
addappid(1426050)
addappid(1426051, 1, "692704f53a665d6c07500a71471483471a6417262c5b3cf7d227ed340886fb60")
