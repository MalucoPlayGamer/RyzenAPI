-- Lua provided by RyzenAPI
-- Game: 苍白花树繁茂之时Blood Flowers Demo

-- MAIN APPLICATION
addappid(2144550)
-- Game: addappid(2144550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144551, 1, "a19c89ee6a8faf629e42e6d440cf8fd4a215ea9115c88881848baa7dfaf2f0e1")
