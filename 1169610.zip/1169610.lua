-- Lua provided by RyzenAPI
-- Game: addappid(1169610)

-- MAIN APPLICATION
addappid(1169610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169610,0,"97f0c92df6796e05ac6704d2d1e65dd26e7999d2fe1dfac78bdd105cd83d8ccc")
