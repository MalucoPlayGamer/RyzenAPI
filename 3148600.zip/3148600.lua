-- Lua provided by SkyAPI 
-- Game: GEO-DEUX
addappid(3148600)
addappid(3148601, 1, "af77aeadbfe14ee428ca5b7651548e24f123e3e832a9ae1009a5624310901cc6")
addappid(3148602, 1, "8e23766dc02e6ba7fe125d609ae34cb939cba7c03fe07770a4f87b2e6a4dffcd")
