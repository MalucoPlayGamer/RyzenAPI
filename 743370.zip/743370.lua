-- Lua provided by RyzenAPI
-- Game: Soccer Manager 2018

-- MAIN APPLICATION
addappid(743370)
-- Game: addappid(743370)

-- MAIN APP DEPOTS / PACKAGES
addappid(743371, 1, "125adce360cceb2daf81435138172621885aa7632a6d5c36dc9864fc9eed6407")
