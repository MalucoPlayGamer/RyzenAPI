-- Lua provided by RyzenAPI
-- Game: District XiLin - 西林区

-- MAIN APPLICATION
addappid(2637190)
-- Game: addappid(2637190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637191, 1, "93161ace88fd059689532be3f2113e7954a98251140b84fe0baaee857e9ac320")
