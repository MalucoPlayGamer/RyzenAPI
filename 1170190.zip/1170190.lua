-- Lua provided by RyzenAPI
-- Game: Bogatyr

-- MAIN APPLICATION
addappid(1170190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1170191, 1, "5dea927f543bf3a7a5f835baebaef2e2bad442ed770c45b18c19ad6921bf9a0b")

