-- Lua provided by RyzenAPI
-- Game: AppID 1170190

-- MAIN APPLICATION
addappid(1170190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170191, 1, "5dea927f543bf3a7a5f835baebaef2e2bad442ed770c45b18c19ad6921bf9a0b")
