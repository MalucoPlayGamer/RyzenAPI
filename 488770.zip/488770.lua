-- Lua provided by SkyAPI 
-- Game: AppID 488770
addappid(488770)
addappid(488771, 1, "6f826f218be4c64b5b82081c494ab3b9fff196ed9ceaf70331db3062728509be")
addappid(488773, 1, "1b7000e5913268252593dea472f2a4c88a2d22b3f69b2a2f6b1fbc294348bc70")
