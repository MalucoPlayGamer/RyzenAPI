-- Lua provided by RyzenAPI
-- Game: Counterpick Labs

-- MAIN APPLICATION
addappid(2837280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2837282,0,"933c67158739a42d8bba63825169cb570c8def7102f74281cc2e8df32cced7ee")
addappid(2837283,0,"e4e48a5e2ecda312fc2a00961b5c7ace459bf2c89a4750718d230d7dbf721044")
addappid(2837284,0,"d9bd3837dbb65ea4d53334d66dfe139c518c68eb9b87e87ec5aa8b18a4b7bdc6")

