-- Lua provided by RyzenAPI
-- Game: 760640

-- MAIN APPLICATION
addappid(760640)
-- Game: addappid(760640)

-- MAIN APP DEPOTS / PACKAGES
addappid(760641, 1, "fc5142989bcce5ee38544d856dcdb773b564d490c3f08abd7a1826a45ff3711e")
