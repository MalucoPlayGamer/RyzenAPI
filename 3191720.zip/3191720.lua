-- Lua provided by SkyAPI 
-- Game: AppID 3191720
addappid(3191720)
addappid(3191721, 1, "4960bfc7d1d95a452f332849b470babe71918b2bbc695bf6bce601e5f5730b1a")
