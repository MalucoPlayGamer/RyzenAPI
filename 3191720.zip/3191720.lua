-- Lua provided by RyzenAPI
-- Game: addappid(3191720)

-- MAIN APPLICATION
addappid(3191720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191721, 1, "4960bfc7d1d95a452f332849b470babe71918b2bbc695bf6bce601e5f5730b1a")
