-- Lua provided by RyzenAPI
-- Game: addappid(2306740)

-- MAIN APPLICATION
addappid(2306740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306741, 1, "3a6f65c019f1f2bf1a0812a31c5a4f27ba0a40c72689ee3d2db8eb4a49e6467c")
addappid(2431340, 0, "bff6faa6e7cb13954ff24a48f90322dbf66a17328f48ba2a580d2ea3ca1ce88a")
