-- Lua provided by RyzenAPI
-- Game: Game: Dark Envoy Soundtrack

-- MAIN APPLICATION
addappid(2660910)
-- Game: addappid(2660910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660911, 1, "60f178e83ba34523b43be9046aa924f3ec92479c175fb1f749b1d8791fee1bbb")
