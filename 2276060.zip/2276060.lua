-- Lua provided by RyzenAPI
-- Game: Truck Simulator Ultimate 3D

-- MAIN APPLICATION
addappid(2276060)
-- Game: addappid(2276060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276061, 1, "cf41e8a0c8e39e9bbb65b08dd6aff71b23985c654cd66761987ded2b22ae2f00")
