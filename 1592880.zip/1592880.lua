-- Lua provided by RyzenAPI
-- Game: Sokocat - Islands

-- MAIN APPLICATION
addappid(1592880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1592881, 1, "74f11b327e9df38b9be7c82c1cceefa58b5f62b7c7c898e603588792cb4ba4ad")

