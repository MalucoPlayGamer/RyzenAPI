-- Lua provided by RyzenAPI
-- Game: AppID 914400

-- MAIN APPLICATION
addappid(914400)
-- Game: addappid(914400)

-- MAIN APP DEPOTS / PACKAGES
addappid(914401, 1, "5b2d76175ecb50c5bc9db959b2829c61b3144a9c72eb1cb88a44cea32c80b3ff")
