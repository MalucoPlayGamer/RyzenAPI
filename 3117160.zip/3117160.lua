-- Lua provided by RyzenAPI
-- Game: 3117160

-- MAIN APPLICATION
addappid(3117160)
addappid(3117161)
addappid(3117162)
addappid(3117164)
-- Game: addappid(3117160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3117163,0,"630633cc5d4e1f733e9d7f77a1f654a1b1b72336aee168403aa0d9913e8cfbba")
addappid(3158830,0,"2b59e7de81aa7fca25609fd63746971a050959cfde801e0d62e1e50da6d83bfe")
