-- Lua provided by SkyAPI 
-- Game: Golf Tour
addappid(2761960)
addappid(2761961, 1, "bfc2ef5dab8d2be7ef990ff9b0bf5a8072ee8b8d5095ae810c6aadaf923a5c4f")
