-- Lua provided by RyzenAPI
-- Game: VoidBound Demo

-- MAIN APPLICATION
addappid(2622440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622441, 1, "60028ca608987b5765c4faf953a5803ff68c2846b2912aa682eb7308fbb78412")
