-- Lua provided by RyzenAPI
-- Game: Boyfriend Dungeon

-- MAIN APPLICATION
addappid(674930)

-- MAIN APP DEPOTS / PACKAGES
addappid(674931, 1, "aeab3185ea4877938e9a4a9e2feb7d8950c41473c4110beeefc209e40db975b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1808990)
