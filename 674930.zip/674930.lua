-- Lua provided by SkyAPI 
-- Game: Boyfriend Dungeon
addappid(674930)
addappid(674931, 1, "aeab3185ea4877938e9a4a9e2feb7d8950c41473c4110beeefc209e40db975b2")
