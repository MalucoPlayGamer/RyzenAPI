-- Lua provided by RyzenAPI
-- Game: paradise of desire

-- MAIN APPLICATION
addappid(1972550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972551, 1, "b05a906f56fdb18a7c720416bb76096bf296fc509c6ad5d650701b27ed90eb3d")
