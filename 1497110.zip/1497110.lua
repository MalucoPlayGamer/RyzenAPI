-- Lua provided by RyzenAPI
-- Game: Melodramatica

-- MAIN APPLICATION
addappid(1497110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497111, 1, "1d33bd3072560967e45921468c36a00ebb82143e32e986b0bb1a95ac2f816e5e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
