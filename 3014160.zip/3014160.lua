-- Lua provided by RyzenAPI
-- Game: addappid(3014160)

-- MAIN APPLICATION
addappid(3014160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014161, 1, "7bd8a663ef2ea18cca90113abecc9b4cd97e79225054e662782a60ae93eaaddb")
