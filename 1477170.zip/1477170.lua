-- Lua provided by SkyAPI 
-- Game: Empires Shall Fall
addappid(1477170)
addappid(1477171, 1, "b24d419c2438171eca15d16e3528c55e1cb75a6b6d9ee2021a5a73954524c8c9")
