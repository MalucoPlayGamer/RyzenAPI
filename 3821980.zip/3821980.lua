-- Lua provided by RyzenAPI
-- Game: 3821980

-- MAIN APP DEPOTS / PACKAGES
addappid(3821980, 1)
-- Game: addappid(3821980, 1)
