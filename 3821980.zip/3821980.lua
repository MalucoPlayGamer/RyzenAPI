-- Lua provided by RyzenAPI
-- Game: addappid(3821980, 1)

-- MAIN APP DEPOTS / PACKAGES
addappid(3821980, 1)
