-- Lua provided by RyzenAPI
-- Game: Neon Abyss 2 - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(3821980, 1)
