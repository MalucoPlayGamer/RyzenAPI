-- 4918900's Lua and Manifest Created by Hubcap Manifest
-- Guild's Requiem
-- Created: August 05, 2026 at 13:25:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4918900) -- Guild's Requiem
-- MAIN APP DEPOTS
addappid(4918901, 1, "20af1a389684d9f5f1beec895dfe8c762e26f06f3cbb3a51abd7c24d4ae26802") -- Depot 4918901
setManifestid(4918901, "2445135912795719523", 507945688)
addappid(4918902, 1, "b8dc598b8155bf9d54619ead37c69e9b2c27e713db1547662e1350a30c646246") -- Depot 4918902
setManifestid(4918902, "6877973531953674637", 475003864)
addappid(4918903, 1, "8e60b934a9713eba8fbee15eaa8362bdb677f47d738aa4ba047fa7443e2a3e54") -- Depot 4918903
setManifestid(4918903, "3485288453138922573", 593769862)