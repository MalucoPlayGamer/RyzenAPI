-- Lua provided by RyzenAPI
-- Game: Game: PANIC STATION

-- MAIN APPLICATION
addappid(1386980)
-- Game: addappid(1386980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386981, 1, "83021d53176c9edb57ea03ea22b74f50596814cc37d413f5b2bd62095cee0c2f")
