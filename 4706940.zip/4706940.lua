-- 4706940's Lua and Manifest Created by Hubcap Manifest
-- Furry Adventure!
-- Created: August 17, 2026 at 14:42:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4706940) -- Furry Adventure!
-- MAIN APP DEPOTS
addappid(4706941, 1, "02a919e80f852adb0c291ed80eff5f9660142e7c716e177e02a3473abcf64003") -- Depot 4706941
setManifestid(4706941, "3879135538740222037", 3242538117)