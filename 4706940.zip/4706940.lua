-- Lua provided by RyzenAPI
-- Game: Furry Adventure!

-- MAIN APPLICATION
addappid(4706940) -- Furry Adventure!

-- MAIN APP DEPOTS / PACKAGES
addappid(4706941, 1, "02a919e80f852adb0c291ed80eff5f9660142e7c716e177e02a3473abcf64003") -- Depot 4706941

