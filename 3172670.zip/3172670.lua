-- Lua provided by RyzenAPI
-- Game: Sex Arena: Passion of Aquilon 💋⚔️

-- MAIN APPLICATION
addappid(3172670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172671, 1, "5af754b4d0fc021eb39db5a02fd4e703a3cf7a7c0c66f35c83294a7f669cb70e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3668750)
addappid(3668760)
addappid(3668770)
