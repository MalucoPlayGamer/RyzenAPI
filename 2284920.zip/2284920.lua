-- Lua provided by RyzenAPI 
-- Game: Traveler Music
addappid(2284920)
addappid(2284921, 1, "260226989514b0cd5fae0a9e4ddbe5ec792ae682b2c22ae94bd8525489609a85")
