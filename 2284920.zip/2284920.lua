-- Lua provided by RyzenAPI
-- Game: Game: Traveler Music

-- MAIN APPLICATION
addappid(2284920)
-- Game: addappid(2284920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2284921, 1, "260226989514b0cd5fae0a9e4ddbe5ec792ae682b2c22ae94bd8525489609a85")
