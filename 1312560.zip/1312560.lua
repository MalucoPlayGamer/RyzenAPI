-- Lua provided by RyzenAPI
-- Game: Crimson Imprint plus -Nonexistent Christmas- Demo

-- MAIN APPLICATION
addappid(1312560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312561, 1, "259a0ba449eb29b13c1af8c7bcee0b08ecd322f4f2eecd2dd39160acf73fe248")
