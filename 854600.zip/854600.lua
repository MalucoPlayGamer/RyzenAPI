-- Lua provided by RyzenAPI
-- Game: 854600

-- MAIN APPLICATION
addappid(854600)
-- Game: addappid(854600)

-- MAIN APP DEPOTS / PACKAGES
addappid(854601, 1, "e9f0482d96163d09a580e7e83f2be7d864b2fd8ca8cd7f183ae47647bdd7e465")
