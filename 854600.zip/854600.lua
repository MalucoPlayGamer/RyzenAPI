-- Lua provided by SkyAPI 
-- Game: Pamali: Indonesian Folklore Horror Demo
addappid(854600)
addappid(854601, 1, "e9f0482d96163d09a580e7e83f2be7d864b2fd8ca8cd7f183ae47647bdd7e465")
