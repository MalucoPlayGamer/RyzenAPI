-- Lua provided by RyzenAPI
-- Game: Dawn of Horror

-- MAIN APPLICATION
addappid(4550280) -- Dawn of Horror

-- MAIN APP DEPOTS / PACKAGES
addappid(4550281, 1, "ed093d32d867016aabfc954951ff15cbb70d9eb090d1b177208d8a3dd30c4c10") -- Depot 4550281

