-- 4550280's Lua and Manifest Created by Hubcap Manifest
-- Dawn of Horror
-- Created: August 13, 2026 at 00:55:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4550280) -- Dawn of Horror
-- MAIN APP DEPOTS
addappid(4550281, 1, "ed093d32d867016aabfc954951ff15cbb70d9eb090d1b177208d8a3dd30c4c10") -- Depot 4550281
setManifestid(4550281, "6561455142020641833", 14230039136)