-- Lua provided by RyzenAPI
-- Game: Levana Horror Tale

-- MAIN APPLICATION
addappid(3141360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141361, 1, "0d5369781a2f020312dee2ee35f0f141d9443caad7e1453814b5a01b63bfb1cf")
