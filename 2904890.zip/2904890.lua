-- Lua provided by RyzenAPI
-- Game: 2904890

-- MAIN APPLICATION
addappid(2904890)
-- Game: addappid(2904890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904891, 1, "d20b433efdeedffdb199d29dbcd052c1513e8cae68b32ddc5b2935bcab8e8257")
