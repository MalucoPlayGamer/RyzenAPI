-- Lua provided by RyzenAPI
-- Game: Godfall: Embers

-- MAIN APPLICATION
addappid(4810250)
