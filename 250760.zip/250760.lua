-- Lua provided by RyzenAPI
-- Game: Shovel Knight: Treasure Trove

-- MAIN APPLICATION
addappid(250760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(250761, 1, "897c8575e16463ffb846336d3c94feddcdbc5a10976ca1c1e6c3b21134aabf00")
addappid(250763, 1, "b2f715c24260faeb8476ccb07fe99ca9ca105e4e5a868b2a1afe6217c2901e34")
addappid(250764, 1, "53390b208ea0022be6f8a23a23c47c6352fbe3de4198c7cf2e0ebb9bc370afb1")

