-- Lua provided by RyzenAPI 
-- Game: 挂到1000级-Idle to level 1000
addappid(3561020)
addappid(3561021, 1, "57e7a000e4b0302718c5288dc010de41b669e7241efd9c6d937400cc4b56a724")
