-- Lua provided by RyzenAPI
-- Game: addappid(1253190)

-- MAIN APPLICATION
addappid(1253190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253191, 1, "8a8ed7c2bcdd9795d10a6ddde44593143dacc6e4e33b585ef097d70ce5f28063")
