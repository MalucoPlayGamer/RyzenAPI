-- Lua provided by RyzenAPI
-- Game: addappid(1064610)

-- MAIN APPLICATION
addappid(1064610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064611, 1, "a71125a50d857b67abb7dda5f7dfaa8dc8eb4d1f8fbb1a61c35eec261815c026")
addappid(1064612, 1, "9874da48dad93891ad9ca9fe0e27b53dc918af224f5395be14697be90ab81850")
