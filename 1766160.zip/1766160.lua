-- Lua provided by RyzenAPI
-- Game: Line Strike

-- MAIN APPLICATION
addappid(1766160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1766161, 1, "3a665850c973f643d5747c18926de9ffd935550a511ba2fa140785f136054fb9")
addappid(1766162, 1, "96d85538dfe8903d0fcdd10ddd282a5239e7d95194acbdbedc52851e39205bc5")

