-- Lua provided by RyzenAPI 
-- Game: Line Strike
addappid(1766160)
addappid(1766161, 1, "3a665850c973f643d5747c18926de9ffd935550a511ba2fa140785f136054fb9")
addappid(1766162, 1, "96d85538dfe8903d0fcdd10ddd282a5239e7d95194acbdbedc52851e39205bc5")
