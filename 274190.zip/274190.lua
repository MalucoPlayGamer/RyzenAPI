-- 274190's Lua and Manifest Created by Hubcap Manifest
-- Broforce
-- Created: July 22, 2026 at 13:06:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(274190, 1, "b65691240348b3e3dff1ccfbf9e6804d135aefafda370b874040150cc323fcff") -- Broforce
-- MAIN APP DEPOTS
addappid(274191, 1, "995563ca038cedb11588f1581c6227e191f0d933b321007dfb5af38b067a22e1") -- Broforce Content
setManifestid(274191, "7370563841668439350", 549145899)
addappid(274192, 1, "1a1b429b34e032df4bfd32b4489004894fc2ab7eacc81668cb68e8d10b14880b") -- Broforce Mac
setManifestid(274192, "6287900867923783365", 538419627)
addappid(274193, 1, "d94cef3f8dc9e61a38bc357b20890a0548992043d21eda4ab356f30e297ae46c") -- Broforce Linux
setManifestid(274193, "483845359829962807", 571899614)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)