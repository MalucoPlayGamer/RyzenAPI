-- Lua provided by RyzenAPI
-- Game: Game: Broforce

-- MAIN APPLICATION
addappid(274190)
addappid(410790)
-- Game: addappid(274190)

-- MAIN APP DEPOTS / PACKAGES
addappid(274191, 1, "995563ca038cedb11588f1581c6227e191f0d933b321007dfb5af38b067a22e1")
addappid(274192, 1, "1a1b429b34e032df4bfd32b4489004894fc2ab7eacc81668cb68e8d10b14880b")
addappid(274193, 1, "d94cef3f8dc9e61a38bc357b20890a0548992043d21eda4ab356f30e297ae46c")
