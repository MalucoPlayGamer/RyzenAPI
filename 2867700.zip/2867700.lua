-- Lua provided by RyzenAPI
-- Game: 2867700

-- MAIN APPLICATION
addappid(2867700)
-- Game: addappid(2867700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867701, 1, "a225a9869aaad6ac708cf48f46c7749fe3edefd39d98296dd83d0d22194f5b5a")
