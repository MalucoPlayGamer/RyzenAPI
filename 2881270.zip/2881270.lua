-- Lua provided by SkyAPI 
-- Game: Randy & Manilla
addappid(2881270)
addappid(2881271, 1, "219022978c5fb0ae9cd76ea1f9b4cc7825f26b6b7bcd550ff720a78b758c1f80")
