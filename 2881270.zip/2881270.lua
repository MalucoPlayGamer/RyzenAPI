-- Lua provided by RyzenAPI
-- Game: Randy & Manilla

-- MAIN APPLICATION
addappid(2881270)
-- Game: addappid(2881270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881271, 1, "219022978c5fb0ae9cd76ea1f9b4cc7825f26b6b7bcd550ff720a78b758c1f80")
