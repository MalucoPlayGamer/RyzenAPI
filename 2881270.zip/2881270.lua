-- Lua provided by RyzenAPI
-- Game: Randy & Manilla

-- MAIN APPLICATION
addappid(2881270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881271, 1, "219022978c5fb0ae9cd76ea1f9b4cc7825f26b6b7bcd550ff720a78b758c1f80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
