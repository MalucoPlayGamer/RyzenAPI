-- Lua provided by RyzenAPI
-- Game: Bomber Arena

-- MAIN APPLICATION
addappid(971280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(971281, 1, "311f4d7a65738ead053c1eda5b07563c6f6099d0cee25f7997bcbd398a2618c7")

