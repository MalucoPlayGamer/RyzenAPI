-- Lua provided by RyzenAPI
-- Game: addappid(971280)

-- MAIN APPLICATION
addappid(971280)

-- MAIN APP DEPOTS / PACKAGES
addappid(971281, 1, "311f4d7a65738ead053c1eda5b07563c6f6099d0cee25f7997bcbd398a2618c7")
