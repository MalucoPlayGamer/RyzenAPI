-- Lua provided by RyzenAPI
-- Game: Christmas Town - Passion House

-- MAIN APPLICATION
addappid(2065240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065241, 1, "c59a4466d62ddcf5e9fd9d5403af111ef4153d1af9fd5d2c5c519fba0b6343a2")

