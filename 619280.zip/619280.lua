-- Lua provided by RyzenAPI
-- Game: AppID 619280

-- MAIN APPLICATION
addappid(619280)

-- MAIN APP DEPOTS / PACKAGES
addappid(619281, 1, "98dde9f904af0c611c78f25f3458ac75397623de965f89d08319b408e2ea46c9")
addappid(620470, 0, "53c370cc932fa605099503c6718765330716b7e7e2e954c44fd2b49d4d2f7080")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
