-- Lua provided by RyzenAPI
-- Game: Carrom 2.0 || كيرم 2.0

-- MAIN APPLICATION
addappid(3416440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416441, 1, "76dbfe4962eb7359850b0c6ca74195614d42e51f51690702aa49e3d54ee9af4d")

