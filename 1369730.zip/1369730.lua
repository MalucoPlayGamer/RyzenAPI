-- Lua provided by RyzenAPI
-- Game: Citizens Unite!: Earth x Space

-- MAIN APPLICATION
addappid(1369730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1369731, 1, "8c33b015e6ee368a3720f52d854134429a86ea3d4aeb291be5fa6fe5954f308d")

