-- Lua provided by RyzenAPI
-- Game: Citizens Unite!: Earth x Space

-- MAIN APPLICATION
addappid(1369730)
-- Game: addappid(1369730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369731, 1, "8c33b015e6ee368a3720f52d854134429a86ea3d4aeb291be5fa6fe5954f308d")
