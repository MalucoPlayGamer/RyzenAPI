-- Lua provided by RyzenAPI
-- Game: AppID 1352520

-- MAIN APPLICATION
addappid(1352520)
addappid(2184190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1352521, 1, "8ac51fbbf5e07ca65a76f24bd74fa74386d72cbd1f20bffefdacf846fc093373")

