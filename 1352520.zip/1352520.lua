-- Lua provided by RyzenAPI
-- Game: AppID 1352520

-- MAIN APPLICATION
addappid(1352520)
addappid(2184190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352521, 1, "8ac51fbbf5e07ca65a76f24bd74fa74386d72cbd1f20bffefdacf846fc093373")
