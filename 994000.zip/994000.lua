-- Lua provided by RyzenAPI
-- Game: Game: AppID 994000

-- MAIN APPLICATION
addappid(994000)
-- Game: addappid(994000)

-- MAIN APP DEPOTS / PACKAGES
addappid(994001, 1, "688530212fbb94d3b4289c6cf75e0eae5cadba4cf5eddd7261fa1d4e07ae4d6b")
