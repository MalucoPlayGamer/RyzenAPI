-- Lua provided by RyzenAPI
-- Game: Aka Demo

-- MAIN APPLICATION
addappid(2165260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165261, 1, "36b9f206e52c5f57ba4fd0763d61a0d2974f05b84bb4c89b35d87622ed715d67")
