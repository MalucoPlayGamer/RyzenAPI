-- Lua provided by RyzenAPI
-- Game: Beat Saber - Metallica - "Creeping Death"

-- MAIN APPLICATION
addappid(3354480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354480,0,"f0a9162538852393dd116be7663656223f3b921348178839b60c515ac6acffd2")
