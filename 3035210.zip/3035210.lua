-- Lua provided by RyzenAPI
-- Game: addappid(3035210)

-- MAIN APPLICATION
addappid(3035210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035210,0,"ebba4c441b880d0ef27d7bdb186aa4544ab1e4d385627cb7ba77a4bb74b19ac5")
