-- Lua provided by RyzenAPI
-- Game: Neglected

-- MAIN APPLICATION
addappid(1300360)
addappid(1584700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300361, 1, "82e5b9100b41b25277d64ab711eaca5266afcb40e819379ce0c0c9e11c94e859")
addappid(1300362, 1, "c4d3da0c552fea48d1c2c335aa52a70ce3f1000831b1c50f6ca795b6ed5d5e89")
addappid(1300363, 1, "cf2eb3be1d21e68194dfc1753b648ffa3145cb03425a3ab5d96e265066db6d48")
addappid(1300364, 1, "e9a252fbc08cc84fcc6f9205a55b5b5275203a93c65e2b23ded21b45eecf7cfd")
addappid(1300369, 1, "e05152a0165fd0aa9575fbfe3132bec2e779dbfad5660ffb520470ac2b0eb4c6")

