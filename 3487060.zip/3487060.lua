-- Lua provided by RyzenAPI
-- Game: Youtubers Life 3

-- MAIN APPLICATION
addappid(3487060)
-- Game: addappid(3487060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487061, 1, "a45085f2752e82e06b9b112531e9a91d431e75d9ed1a041b26b6e1e498743b39")
