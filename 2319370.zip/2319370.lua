-- Lua provided by RyzenAPI
-- Game: addappid(2319370)

-- MAIN APPLICATION
addappid(2319370)
addappid(2342120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319371, 1, "b2797778b432df9477d64841d4b29004a227b07e96d584f2f9cce8d0eb051057")
