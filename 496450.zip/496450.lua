-- Lua provided by SkyAPI 
-- Game: J.A.C.K.
addappid(496450)
addappid(496451, 1, "77b10e78e35ae60790d9b91b750334e87f289048329162258f418dc0294d6b3b")
addappid(496453, 1, "9de3f08d05a2981b70633058d81988962304c41b0deaf74afeaa1c3beed958c8")
