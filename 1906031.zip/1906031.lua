-- Lua provided by RyzenAPI
-- Game: addappid(1906031)

-- MAIN APPLICATION
addappid(1906031)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906031,0,"2a11e43b5c80bc1e3b03cef48b406ac2ecfc9bf9f6a427c660badbb87b7686dc")
