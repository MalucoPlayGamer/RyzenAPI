-- Lua provided by RyzenAPI
-- Game: Z-Island

-- MAIN APPLICATION
addappid(4574600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4574601,0,"1bdc405aa0c53d216cf186baf1346f4a9dec07c2f674daec0bae8e760e53ff6c")

