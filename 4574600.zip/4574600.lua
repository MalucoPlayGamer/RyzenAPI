-- Lua provided by RyzenAPI
-- Game: Z-Island

-- MAIN APPLICATION
addappid(4574600)

-- MAIN APP DEPOTS / PACKAGES
addappid(4574601,0,"1bdc405aa0c53d216cf186baf1346f4a9dec07c2f674daec0bae8e760e53ff6c")

