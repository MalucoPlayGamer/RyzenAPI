-- Lua provided by RyzenAPI
-- Game: Space Rescue: Code Pink

-- MAIN APPLICATION
addappid(1407210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407211, 1, "e2d62960a0bc3e8206104f21bc4d5c25e31dac1382c26373717541bc5c61ddd9")

