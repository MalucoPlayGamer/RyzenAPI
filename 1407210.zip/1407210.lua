-- Lua provided by SkyAPI 
-- Game: AppID 1407210
addappid(1407210)
addappid(1407211, 1, "e2d62960a0bc3e8206104f21bc4d5c25e31dac1382c26373717541bc5c61ddd9")
