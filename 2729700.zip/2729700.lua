-- Lua provided by RyzenAPI
-- Game: 2729700

-- MAIN APPLICATION
addappid(2729700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729700,0,"a62a5e63a1f2bdadce5cf7e6720f0a7cfc9d484b496943ddd9781e82b408581a")
