-- Lua provided by RyzenAPI
-- Game: AppID 643000

-- MAIN APPLICATION
addappid(643000)
-- Game: addappid(643000)

-- MAIN APP DEPOTS / PACKAGES
addappid(643001, 1, "d87ac86fac7806c4b56acdc69c57661d460034e0d9d81ec658f7c735e1365e46")
