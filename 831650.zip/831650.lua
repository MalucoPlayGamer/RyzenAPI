-- Lua provided by RyzenAPI
-- Game: Chronus Arc

-- MAIN APPLICATION
addappid(831650)

-- MAIN APP DEPOTS / PACKAGES
addappid(831651,0,"f1b3f2719e6c88b9bd2c5dd0f334a9d963f63abbcb87a1e0453f0f88ac8f382a")

