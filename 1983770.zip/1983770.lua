-- Lua provided by RyzenAPI
-- Game: 1983770

-- MAIN APPLICATION
addappid(1983770)
-- Game: addappid(1983770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983779,0,"bffb38acccf74ed7f5080675967be7266a45a60c82a38093441c360ab1be893e")
