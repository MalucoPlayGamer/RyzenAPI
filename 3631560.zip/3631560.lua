-- Lua provided by SkyAPI 
-- Game: AppID 3631560
addappid(3631560)
addappid(3631561, 1, "1e3f14f1d1d73d3da57e05f1d51807b4fe94fb70f30e048781164c848d553a64")
