-- Lua provided by RyzenAPI
-- Game: 3631560

-- MAIN APPLICATION
addappid(3631560)
-- Game: addappid(3631560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631561, 1, "1e3f14f1d1d73d3da57e05f1d51807b4fe94fb70f30e048781164c848d553a64")
