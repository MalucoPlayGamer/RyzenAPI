-- Lua provided by RyzenAPI
-- Game: 未择之路

-- MAIN APPLICATION
addappid(3631560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3631561, 1, "1e3f14f1d1d73d3da57e05f1d51807b4fe94fb70f30e048781164c848d553a64")

