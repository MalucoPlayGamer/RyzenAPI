-- Lua provided by RyzenAPI
-- Game: Game: Didnapper 2

-- MAIN APPLICATION
addappid(1813820)
-- Game: addappid(1813820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813821, 1, "89ad9bc6a80dc5b7cbce4794c34ed0ca1700026147864098923e1c843652a4a1")
