-- Lua provided by SkyAPI 
-- Game: Didnapper 2
addappid(1813820)
addappid(1813821, 1, "89ad9bc6a80dc5b7cbce4794c34ed0ca1700026147864098923e1c843652a4a1")
