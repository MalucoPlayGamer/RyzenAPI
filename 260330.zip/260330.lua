-- Lua provided by RyzenAPI
-- Game: AppID 260330

-- MAIN APPLICATION
addappid(260330)
-- Game: addappid(260330)

-- MAIN APP DEPOTS / PACKAGES
addappid(260331, 1, "efd1777e9ebee3cc62df9903d46b384834fe984052b232bc317a6b3e3eac8fe8")
addappid(299370, 0, "15a18f5031907bc6fcec925d54ad4c0526cdf92d6dc7562270b0be2c47a66500")
