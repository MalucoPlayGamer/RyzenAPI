-- Lua provided by RyzenAPI
-- Game: AppID 260330

-- MAIN APPLICATION
addappid(260330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(260331, 1, "efd1777e9ebee3cc62df9903d46b384834fe984052b232bc317a6b3e3eac8fe8")
addappid(299370, 0, "15a18f5031907bc6fcec925d54ad4c0526cdf92d6dc7562270b0be2c47a66500")

