-- Lua provided by RyzenAPI
-- Game: 332530

-- MAIN APPLICATION
addappid(332530)
-- Game: addappid(332530)

-- MAIN APP DEPOTS / PACKAGES
addappid(332531, 1, "06990d6bdcb22f1717d4b1f0c2cf3941f08595d99e24568cded76d79299eb2d5")
addappid(332532, 1, "6881bc7b19213d1b7ed481cefa9e66fab1bba67e0a62174ef085f2f9671c590d")
addappid(332533, 1, "7d0f0286d4e95cf997ee45542dc6d0ee40988fbbaac5fb3073dfa7fcd88c490f")
