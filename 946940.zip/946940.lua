-- Lua provided by RyzenAPI
-- Game: addappid(946940)

-- MAIN APPLICATION
addappid(946940)
addappid(946941)

-- MAIN APP DEPOTS / PACKAGES
addappid(946940,0,"18222fbf11e96b9760accf8e9935f7d4a6c73a7a624c5460bb08b644db7ea0c5")
