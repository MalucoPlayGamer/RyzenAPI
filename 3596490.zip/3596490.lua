-- Lua provided by RyzenAPI
-- Game: Coffee & Boobs - Digital Artbook

-- MAIN APPLICATION
addappid(3596490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3596490,0,"a462e16bd2cd531eb492662d2271359a027603846e00b1e529ca3cf14773de78")

