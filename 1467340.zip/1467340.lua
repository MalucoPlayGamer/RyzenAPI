-- Lua provided by SkyAPI 
-- Game: Quintaesencia
addappid(1467340)
addappid(1467341, 1, "9136f31bba83f88e93cda3d30d214aa03b8a8fb156cd3048b91447a4374187fa")
addappid(1467343, 1, "066e4c0a194a55b869a4c14d6fd54ab64425121044aba8d97f39a8ff5b4c99e5")
