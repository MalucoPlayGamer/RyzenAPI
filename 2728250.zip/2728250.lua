-- Lua provided by RyzenAPI
-- Game: 2728250

-- MAIN APPLICATION
addappid(2728250)
-- Game: addappid(2728250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2728251, 1, "1690e81628ca4cec7160226d58e983b68f8c69d85caf5c3852b7d3a5a011487e")
