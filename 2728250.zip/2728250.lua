-- Lua provided by RyzenAPI 
-- Game: The Backrooms: Descent
addappid(2728250)
addappid(2728251, 1, "1690e81628ca4cec7160226d58e983b68f8c69d85caf5c3852b7d3a5a011487e")
