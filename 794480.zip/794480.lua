-- Lua provided by RyzenAPI
-- Game: Ottoman Empire: Spectacular Millennium

-- MAIN APPLICATION
addappid(794480)

-- MAIN APP DEPOTS / PACKAGES
addappid(794481,0,"eb1af84d06b8dd4d6f920cd9eca4b340c6180bb3444a755602774b1bac549927")

