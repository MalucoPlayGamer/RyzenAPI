-- Lua provided by RyzenAPI
-- Game: Ottoman Empire: Spectacular Millennium

-- MAIN APPLICATION
addappid(794480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(794481,0,"eb1af84d06b8dd4d6f920cd9eca4b340c6180bb3444a755602774b1bac549927")

