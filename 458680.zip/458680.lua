-- Lua provided by RyzenAPI
-- Game: Auto Age: Standoff

-- MAIN APPLICATION
addappid(458680)
addappid(458681)

-- MAIN APP DEPOTS / PACKAGES
addappid(458682,0,"7d2d53227b7cb88b5fb868544fe577c519f9ac8c42ea475be9764e4b3391e1b0")
addappid(458683,0,"9aa39e5d08a5e4e6512fdf944f3d837747565529ffc6d39360396363f01eb004")
