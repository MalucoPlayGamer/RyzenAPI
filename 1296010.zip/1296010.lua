-- Lua provided by RyzenAPI
-- Game: AppID 1296010

-- MAIN APPLICATION
addappid(1296010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1296011, 1, "b30fb60db15e9e7a6de0622b9ae2e2662924e362d37e2e1d538a27574295f5f6")

