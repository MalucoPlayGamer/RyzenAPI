-- Lua provided by RyzenAPI 
-- Game: AppID 1296010
addappid(1296010)
addappid(1296011, 1, "b30fb60db15e9e7a6de0622b9ae2e2662924e362d37e2e1d538a27574295f5f6")
