-- Lua provided by RyzenAPI
-- Game: The Insider – interactive movie

-- MAIN APPLICATION
addappid(1304620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304621, 1, "015d534e11ca358bff492fbbd5afdbd3a6e48d68378d8cf7d2d16dfcf422c9d2")
