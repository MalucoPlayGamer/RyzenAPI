-- Lua provided by RyzenAPI
-- Game: Darksiders II Deathinitive Edition Soundtrack

-- MAIN APPLICATION
addappid(417380)

-- MAIN APP DEPOTS / PACKAGES
addappid(417380,0,"97f1b46140d3354376234356899709c8ebcd79301ae26e323593f72c911bd036")

