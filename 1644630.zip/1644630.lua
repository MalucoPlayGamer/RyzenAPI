-- Lua provided by RyzenAPI
-- Game: 1644630

-- MAIN APPLICATION
addappid(1644630)
-- Game: addappid(1644630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644631, 1, "1348346a603c8cb3035e552c94bed7161aee8a04cde94540d033c598b61e13ec")
