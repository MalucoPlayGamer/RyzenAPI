-- Lua provided by RyzenAPI
-- Game: AppID 1837520

-- MAIN APPLICATION
addappid(1837520)
-- Game: addappid(1837520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837521, 1, "df15add4a0ca1c51499c87d8716e39f31dc6fa9fade50e06bb89a962ce5d859c")
