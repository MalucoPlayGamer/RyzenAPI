-- Lua provided by SkyAPI 
-- Game: From Fire Emergence Demo
addappid(3073730)
addappid(3073731, 1, "b03d92da95abba5f4c24c0e65974c9b946a8272e419e173769d74dec97e5d521")
