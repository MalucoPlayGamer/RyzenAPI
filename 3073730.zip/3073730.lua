-- Lua provided by RyzenAPI
-- Game: From Fire Emergence Demo

-- MAIN APPLICATION
addappid(3073730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073731, 1, "b03d92da95abba5f4c24c0e65974c9b946a8272e419e173769d74dec97e5d521")
