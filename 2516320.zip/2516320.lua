-- Lua provided by RyzenAPI
-- Game: Whispered Promises ~ 14 Days of Love with Anna Demo

-- MAIN APPLICATION
addappid(2516320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516322,0,"e0adef740fe9beafcb73de4440b7c1ee99c641a6141d654a384313e0c23c96a5")
addappid(2516323,0,"599810e32f84d882bfcd560ce99fd254923ea5c0ddb6fbf50cb163aa1e7d81b2")
addappid(2516324,0,"77ee0d3573d7e7db44e3546da00cb22b59514061949c15b724d827e1f185c1eb")

