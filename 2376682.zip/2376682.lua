-- Lua provided by RyzenAPI
-- Game: Sonic Superstars - LEGO Eggman

-- MAIN APPLICATION
addappid(2376682)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376682,0,"d6cda1ed45d3181f448124fafa140b64a9b3980145720d0b44d98abd4da5df7d")

