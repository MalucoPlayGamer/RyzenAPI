-- Lua provided by RyzenAPI
-- Game: Game: AppID 3296260

-- MAIN APPLICATION
addappid(3296260)
-- Game: addappid(3296260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296261, 1, "8215c059edf838cd50aaf2942c0307b92c521b70d8acbfcc2df9e0754cf2c874")
addappid(3296263, 1, "958541e33d3c7ddcf4f1c144af55908c7d01ed146c246d12605461adc9cfd95a")
