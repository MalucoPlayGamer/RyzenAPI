-- Lua provided by RyzenAPI
-- Game: 异能都市

-- MAIN APPLICATION
addappid(2450890)
-- Game: addappid(2450890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450891, 1, "3b63c3bbc9f7ce50c067aee511a064345fa92fc886b7dc40b99d240da994f909")
