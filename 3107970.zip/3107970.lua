-- Lua provided by RyzenAPI
-- Game: Difficult times 2

-- MAIN APPLICATION
addappid(3107970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107971, 1, "58690bc0540486539d096bdbe1937030b4f826f94ef766e68f372e09a00ec68b")
