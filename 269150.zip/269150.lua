-- Lua provided by RyzenAPI
-- Game: Luxuria Superbia

-- MAIN APPLICATION
addappid(269150)
-- Game: addappid(269150)

-- MAIN APP DEPOTS / PACKAGES
addappid(269151, 1, "9162fef78609840845eedd7301c778b600dda7d9b8918878bb7dd2b02b5d68ae")
addappid(269152, 1, "c8286e01ec06264577ad2307350d95309ce41bc1c41874e95d92488e70bd989d")
addappid(269153, 1, "ec1c2decccee287f4b022c88ea9df0d83bde47aac8c83e1bbdc2a5d2a2011964")
