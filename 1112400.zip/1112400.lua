-- Lua provided by RyzenAPI
-- Game: Project Torque - Free 2 Play MMO Racing Game

-- MAIN APPLICATION
addappid(228982)
addappid(228990)
addappid(229000)
addappid(1112400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112402,0,"7c73e5081cb5e20497ce7f17556b670a96885e758507f5066ae188de93339a93")
