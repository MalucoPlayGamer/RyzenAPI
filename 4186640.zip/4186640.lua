-- 4186640's Lua and Manifest Created by Hubcap Manifest
-- CharmEdge Deck
-- Created: August 14, 2026 at 09:14:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4186640) -- CharmEdge Deck
-- MAIN APP DEPOTS
addappid(4186642, 1, "760830b5623c353575208fd6ae3d331592532dc8fbf793977a4abd2e64dc8c7c") -- Depot 4186642
setManifestid(4186642, "2245356658009457769", 649196314)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4186641) -- Depot 4186641 (empty depot)