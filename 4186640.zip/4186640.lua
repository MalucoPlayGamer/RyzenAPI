-- Lua provided by RyzenAPI
-- Game: CharmEdge Deck

-- MAIN APPLICATION
addappid(4186640) -- CharmEdge Deck
-- addappid(4186641) -- Depot 4186641 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4186642, 1, "760830b5623c353575208fd6ae3d331592532dc8fbf793977a4abd2e64dc8c7c") -- Depot 4186642

