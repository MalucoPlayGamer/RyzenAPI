-- Lua provided by RyzenAPI
-- Game: Neuro Horror

-- MAIN APPLICATION
addappid(2142860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142861, 1, "0b13313febba559ba405118282cc3c24333542daa647017d2fa2edeaab000a39")
