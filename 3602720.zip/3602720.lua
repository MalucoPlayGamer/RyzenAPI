-- Lua provided by RyzenAPI
-- Game: CashGrab: Refunded

-- MAIN APPLICATION
addappid(3602720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602721, 1, "bd2ff05c474b86c3b998f13032d7bd53af26f64526fb510d5b1396226b46d703")

