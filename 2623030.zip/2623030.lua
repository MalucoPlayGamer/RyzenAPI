-- Lua provided by RyzenAPI
-- Game: addappid(2623030)

-- MAIN APPLICATION
addappid(2623030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623031, 1, "d44270c8981b24e3db14f778cd810a5adfd6744a9af571cc170f99e1bcc7d69d")
