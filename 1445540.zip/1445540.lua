-- Lua provided by RyzenAPI 
-- Game: The Chronicles of Moses and the Exodus
addappid(1445540)
addappid(1445541, 1, "a7671512440e65af0f3397893ed9922f55a6de9d7d5857526c9e03f383dc8073")
