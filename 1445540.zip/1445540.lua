-- Lua provided by RyzenAPI
-- Game: Game: The Chronicles of Moses and the Exodus

-- MAIN APPLICATION
addappid(1445540)
-- Game: addappid(1445540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445541, 1, "a7671512440e65af0f3397893ed9922f55a6de9d7d5857526c9e03f383dc8073")
