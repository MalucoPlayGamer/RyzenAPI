-- Lua provided by RyzenAPI
-- Game: MADE : Interactive Movie – 01. Run away!

-- MAIN APPLICATION
addappid(1484050)
-- Game: addappid(1484050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484051, 1, "00bd0947cf4132d614172f521f1ee0309c6e420e8b7ce55b9e4b8876295703ba")
