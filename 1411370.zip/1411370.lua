-- Lua provided by RyzenAPI
-- Game: Game: Astrotester

-- MAIN APPLICATION
addappid(1411370)
-- Game: addappid(1411370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411371, 1, "c599580a36809d8166a4aeb3cfcb3914ba7e6bb2bd57f30dd690c2807416fe73")
