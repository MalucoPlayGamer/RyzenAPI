-- Lua provided by RyzenAPI
-- Game: 武林绝学之功夫传奇

-- MAIN APPLICATION
addappid(4781400)

