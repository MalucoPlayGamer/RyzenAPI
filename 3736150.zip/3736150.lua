-- Lua provided by RyzenAPI
-- Game: 氷点下30度の絶望

-- MAIN APPLICATION
addappid(3736150)

