-- Lua provided by RyzenAPI
-- Game: Pretend Cars Racing 2

-- MAIN APPLICATION
addappid(2942330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942330,0,"b0e1fdbb48bb8691619eb34316c98022c6897250f599512ee5b5f6a2eebe9046")
addappid(2942331,0,"67c4fcb0fffc2d6acc9f5f9d15936c8bd1ec737966f6676e16d0c3e5b9dd424a")

