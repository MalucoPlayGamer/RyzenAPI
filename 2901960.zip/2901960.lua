-- Lua provided by RyzenAPI
-- Game: addappid(2901960)

-- MAIN APPLICATION
addappid(2901960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901961, 1, "5368b72c46350872fe0d6a8d789a12e4dc37f6c7c6d358ad9e9c9d22b9c23ce8")
