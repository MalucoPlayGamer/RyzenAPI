-- Lua provided by RyzenAPI
-- Game: Headmaster

-- MAIN APPLICATION
addappid(621010)
addappid(1209560)

-- MAIN APP DEPOTS / PACKAGES
addappid(621011,0,"4298f8b63c7a776e65b91b97cedb7262c15ad2a4ab5dce379d5de411c8278823")

