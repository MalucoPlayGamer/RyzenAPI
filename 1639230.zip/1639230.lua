-- Lua provided by RyzenAPI
-- Game: MoonFall / Butterfly Lovers

-- MAIN APPLICATION
addappid(1639230)
addappid(1802060)
-- Game: addappid(1639230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639231, 1, "f8459fbfdd6583bac8d79cd7a0bfb794ee006a4ae908b4d7beecfe44eb04ba5b")
