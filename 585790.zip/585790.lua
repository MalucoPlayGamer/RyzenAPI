-- Lua provided by RyzenAPI
-- Game: Fergus The Fly

-- MAIN APPLICATION
addappid(585790)

-- MAIN APP DEPOTS / PACKAGES
addappid(585791, 1, "baae6e6e769c078238317ab22881ce6fc965b3f3b156cba19b36512f8ba457f3")
