-- Lua provided by RyzenAPI
-- Game: 1710750

-- MAIN APPLICATION
addappid(1710750)
-- Game: addappid(1710750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710751, 1, "c0754499d4b7926438037e3f3fcab6d387bde2d2556e973a526fcc47f0d630e3")
