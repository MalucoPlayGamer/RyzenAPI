-- Lua provided by RyzenAPI
-- Game: Ashina: The Red Witch: Prologue

-- MAIN APPLICATION
addappid(1259180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1259181, 1, "c9c4b8d1a09aee89627e18b127c7f452fa7d5ae875fead71e5ae40fbfe849d9b")
