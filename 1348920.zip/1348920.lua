-- Lua provided by RyzenAPI
-- Game: Game: Wind Peaks

-- MAIN APPLICATION
addappid(1348920)
-- Game: addappid(1348920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348921, 1, "ac3b5e3c8367dd5ed81b7c05e30f479db11feeec903d363ec6a900729f997bf1")
