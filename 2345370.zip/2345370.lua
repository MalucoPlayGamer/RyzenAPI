-- Lua provided by RyzenAPI
-- Game: Digs Mini Icy

-- MAIN APPLICATION
addappid(2345370)
addappid(2345371)
addappid(2345373)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345372,0,"ed82188dc24818e7533686c5d84195cc6eec8d48367d18fe7b89530349dbb814")
