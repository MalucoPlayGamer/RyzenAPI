-- Lua provided by RyzenAPI
-- Game: addappid(491260)

-- MAIN APPLICATION
addappid(491260)

-- MAIN APP DEPOTS / PACKAGES
addappid(491261, 1, "1651f38d8ffd663d0ca7bac0915539f0f8b67f9fed812b485643cebf9fc4c06b")
addappid(491262, 1, "4f53394254613dbf271ab524348c1fda535106aed152be2cdb746711a7398adb")
