-- Lua provided by RyzenAPI
-- Game: The Losers Team

-- MAIN APPLICATION
addappid(3519290)
-- Game: addappid(3519290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519291, 1, "7774c03eda89e0362b5b893b7706a67c0acc39a59ecde1356aa278e3dd0937b1")
