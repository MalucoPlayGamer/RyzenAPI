-- Lua provided by RyzenAPI 
-- Game: Human Fast Food
addappid(3281090)
addappid(3281091, 1, "83f74aab0962f2d798a8f33b745badc9f22a13f6753e520e90ad33cdca164876")
