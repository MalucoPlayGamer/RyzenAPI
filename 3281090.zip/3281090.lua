-- Lua provided by RyzenAPI
-- Game: Human Fast Food

-- MAIN APPLICATION
addappid(3281090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3281091, 1, "83f74aab0962f2d798a8f33b745badc9f22a13f6753e520e90ad33cdca164876")

