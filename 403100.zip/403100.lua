-- Lua provided by RyzenAPI
-- Game: 403100

-- MAIN APPLICATION
addappid(403100)
addappid(403101)
addappid(403103)
addappid(403104)
addappid(403105)
addappid(403106)
addappid(403107)
addappid(403108)
addappid(403109)
-- Game: addappid(403100)

-- MAIN APP DEPOTS / PACKAGES
addappid(403102,0,"b2b3af80f774cb98b139b477e5313893b1a3afe1c9ee50f98514559e31909c1d")
