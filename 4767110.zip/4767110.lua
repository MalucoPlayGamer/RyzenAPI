-- Lua provided by RyzenAPI
-- Game: Wheelchair For Two

-- MAIN APPLICATION
addappid(4767110)

-- MAIN APP DEPOTS / PACKAGES
addappid(4767111, 1, "d371a335a97b577d194e59a22933ae0b22e36dd4c75258fe0038a3342105698a")

