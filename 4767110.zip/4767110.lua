-- Generated with Luie @ https://lua.tools/
-- 4767110 - Wheelchair For Two
-- Generated 2026-08-28 00:13:06 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4767110)

-- Main Depots
addappid(4767111, 1, "d371a335a97b577d194e59a22933ae0b22e36dd4c75258fe0038a3342105698a")
setManifestid(4767111, "499479223799118945", 2820523972)
