-- Lua provided by RyzenAPI
-- Game: Lords of the Fallen - Artbook

-- MAIN APPLICATION
addappid(2387920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387921, 1, "e69a9bfb62c1ca78c5fbb00518ff2251ada2f55dadfdbe8d842ee5174c83c3ac")

