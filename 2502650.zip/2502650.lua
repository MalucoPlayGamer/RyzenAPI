-- Lua provided by RyzenAPI
-- Game: Daisho: Survival of a Samurai

-- MAIN APPLICATION
addappid(2502650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2502651, 1, "8dec62e822e945e8e1ab4a38f883078680976be52d514feac74aa411a81d2850")

