-- Lua provided by RyzenAPI 
-- Game: AppID 2412470
addappid(2412470)
addappid(2412471, 1, "e7201ead0434bbc13ba444ecdd5c793daf7fa97b0e1c5e284d4ff66d8da26801")
