-- Lua provided by RyzenAPI
-- Game: 蛾厂变形记 Demo

-- MAIN APPLICATION
addappid(2412470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412471, 1, "e7201ead0434bbc13ba444ecdd5c793daf7fa97b0e1c5e284d4ff66d8da26801")
