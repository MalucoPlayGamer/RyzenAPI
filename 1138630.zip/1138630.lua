-- Lua provided by RyzenAPI
-- Game: Heroes Swipe Right

-- MAIN APPLICATION
addappid(1138630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138631, 1, "443631ab812c81b87a1872d245c262a4e97a49a38bc3dd6b13f0c86c91251af4")

