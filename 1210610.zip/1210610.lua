-- Lua provided by RyzenAPI
-- Game: addappid(1210610)

-- MAIN APPLICATION
addappid(1210610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210611, 1, "bfc8630c6c64ac5633cf01520be394cab8f3e8a0bf43960656477d629254cfad")
