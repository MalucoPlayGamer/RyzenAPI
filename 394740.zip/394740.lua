-- Lua provided by RyzenAPI
-- Game: addappid(394740)

-- MAIN APPLICATION
addappid(394740)

-- MAIN APP DEPOTS / PACKAGES
addappid(394741, 1, "add429c1e6d13b138b789b6f29379a6907248dfac7b0287486f7d451fe13e04f")
