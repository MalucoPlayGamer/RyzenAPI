-- Lua provided by RyzenAPI
-- Game: Streamline

-- MAIN APPLICATION
addappid(393660)

-- MAIN APP DEPOTS / PACKAGES
addappid(393661, 1, "a6bc67bf4a2d9dddd3239ca6d0871f33001660b84cd44de13251a9cde600f04f")
