-- Lua provided by RyzenAPI
-- Game: Lempo

-- MAIN APPLICATION
addappid(1891620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891621, 1, "b5af56243cac74a103c9d44117981f80d5d5cf23e23ab702d4e822a1e602c80b")
