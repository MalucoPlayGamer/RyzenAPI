-- Lua provided by RyzenAPI
-- Game: AppID 2522650

-- MAIN APPLICATION
addappid(2522650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522651, 1, "293d1b6447fe3bf03aab148a513fb49a60b57bae9d35b79c1e79712eceb30f2b")

