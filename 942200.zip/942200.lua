-- Lua provided by RyzenAPI
-- Game: 942200

-- MAIN APPLICATION
addappid(942200)
-- Game: addappid(942200)

-- MAIN APP DEPOTS / PACKAGES
addappid(942201, 1, "21cb98a766189b88e303ff57aa062e50aeb0fc26893b37ec33746226072177ed")
