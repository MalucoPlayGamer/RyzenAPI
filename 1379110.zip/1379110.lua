-- Lua provided by RyzenAPI
-- Game: Anime Feet

-- MAIN APPLICATION
addappid(1379110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379111, 1, "96388cacc3da0b74711293bd243390ce6724941e12e6e3e4f1682584217810a5")
addappid(1410990, 0, "a4d38a3440b7a094609158c1e70224adb46313416aa8a35984eb2ccd04a304ce")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1445550)
