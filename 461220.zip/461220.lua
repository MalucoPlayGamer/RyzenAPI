-- Lua provided by RyzenAPI
-- Game: AppID 461220

-- MAIN APPLICATION
addappid(461220)
-- Game: addappid(461220)

-- MAIN APP DEPOTS / PACKAGES
addappid(461221, 1, "73ac9496c0f9f9547b82543b3c7ea00193cc3c42e2b28647749d1357bda00bf6")
