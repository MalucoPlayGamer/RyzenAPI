-- Lua provided by SkyAPI 
-- Game: AppID 439310
addappid(439310)
addappid(439311, 1, "782dc70ccad4f47c03db6dbde260fd427da6e110622e4a97dd2f5d5a99246f5d")
addappid(439312, 1, "cd8db49e6a73a9e8143aab22828eff7b2d34c796a9e8eb57ae95fa02324faff3")
addappid(473660)
