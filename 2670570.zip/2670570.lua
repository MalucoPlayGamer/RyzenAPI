-- Lua provided by RyzenAPI
-- Game: Panda Go Demo

-- MAIN APPLICATION
addappid(2670570)
addappid(2670571)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626361,0,"c734fb0bf2ad487d805d61f857e7876a71b8100e455e6dc35d9b8cfec03f7247")

