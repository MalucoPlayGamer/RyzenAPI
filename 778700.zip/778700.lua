-- Lua provided by RyzenAPI
-- Game: Amorous

-- MAIN APPLICATION
addappid(778700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(778701, 1, "85e3342acf9d3dfff636b97429043bb97174258c1280a7c489684dc147c119ae")
addappid(778702, 1, "1ec079de75c9b30a5623c457ba74f0192f94024fc0e8a72b437648ca46038550")
addappid(778703, 1, "604896fd7851dd487160a06b8993c5fa0323a1ddf803781b9552b1dc05aaaf7e")
addappid(778704, 1, "ed5d8d2727e61b8c9e07c1d6a076ade49d8c6064063ca32fa2bc972dda79f8b5")

