-- Lua provided by RyzenAPI
-- Game: Game: Room Escape: Mark's Room

-- MAIN APPLICATION
addappid(997810)
-- Game: addappid(997810)

-- MAIN APP DEPOTS / PACKAGES
addappid(997811, 1, "b4cfc736a05b1854755c1094a095d0b665227fa672f2adbb632ecaa1e2102cd4")
