-- Lua provided by RyzenAPI
-- Game: AppID 1140040

-- MAIN APPLICATION
addappid(1140040)
-- Game: addappid(1140040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140041, 1, "eca866850139b6e1df763eb51a9bc0926529a357c050fb173e4dd6c847b75913")
