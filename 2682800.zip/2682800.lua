-- Lua provided by RyzenAPI
-- Game: 2682800

-- MAIN APPLICATION
addappid(2682800)
-- Game: addappid(2682800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682801, 1, "77c2ad2e932d56b5d0adabf4b73a87c46bf76786f4de6d9825987f781d203fd0")
