-- Lua provided by RyzenAPI
-- Game: AppID 1958240

-- MAIN APPLICATION
addappid(1958240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1958241, 1, "59eb7a05493bc7989e8e6a0947b2b71afcb575400162b3df31f8c2c467de5acd")

