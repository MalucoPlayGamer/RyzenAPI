-- Lua provided by RyzenAPI
-- Game: Game: Crystal Story: The Hero and the Evil Witch

-- MAIN APPLICATION
addappid(1300190)
-- Game: addappid(1300190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300191, 1, "179b847fee2f9c3a4654d7993f135c4ece5d1f5e757a73baaa8a2c45da15108e")
