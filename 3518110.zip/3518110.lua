-- Lua provided by RyzenAPI
-- Game: addappid(3518110)

-- MAIN APPLICATION
addappid(3518110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3518111, 1, "158e16f41d8e718922eff576e3d84214cf5d688e7fc47cab9c31e2f1625d5f91")
