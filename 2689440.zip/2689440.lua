-- Lua provided by RyzenAPI
-- Game: Game: The Dawning Letters -Sunrise-

-- MAIN APPLICATION
addappid(2689440)
-- Game: addappid(2689440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689441, 1, "bcd08f1c7f74bd975ca879229a3da245555c7e1f349fa892f87a7bcb80c233e6")
