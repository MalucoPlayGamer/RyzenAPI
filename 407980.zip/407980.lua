-- Lua provided by RyzenAPI
-- Game: Sakura Beach 2

-- MAIN APPLICATION
addappid(407980)
-- Game: addappid(407980)

-- MAIN APP DEPOTS / PACKAGES
addappid(407981, 1, "b1a4eee8b6aa4020cdd40f746ac5e83aa27427d3b00ab7ce2702c45a1298ea57")
