-- Lua provided by RyzenAPI
-- Game: Game: Barman Simulator

-- MAIN APPLICATION
addappid(3196800)
-- Game: addappid(3196800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196801, 1, "ffc840c1e225c5b4a5e1b7f6d92182c9a2f96ba0ef6dfe74bc72304037163823")
