-- Lua provided by SkyAPI 
-- Game: AppID 2788500
addappid(2788500)
addappid(2788501, 1, "1e90d422e1e919f130f7b1764a5d4bc4a20f65ec14be60155fa9ec02fa10b255")
