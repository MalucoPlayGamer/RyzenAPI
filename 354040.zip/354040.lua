-- Lua provided by RyzenAPI
-- Game: Game: AppID 354040

-- MAIN APPLICATION
addappid(354040)
-- Game: addappid(354040)

-- MAIN APP DEPOTS / PACKAGES
addappid(354041, 1, "571438ef633de038f37fb9c30e38a85ca2d521fbf8f8dedef0354e95239d9644")
