-- Lua provided by RyzenAPI
-- Game: AppID 354040

-- MAIN APPLICATION
addappid(354040)

-- MAIN APP DEPOTS / PACKAGES
addappid(354041, 1, "571438ef633de038f37fb9c30e38a85ca2d521fbf8f8dedef0354e95239d9644")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
