-- Lua provided by SkyAPI 
-- Game: AppID 354040
addappid(354040)
addappid(354041, 1, "571438ef633de038f37fb9c30e38a85ca2d521fbf8f8dedef0354e95239d9644")
