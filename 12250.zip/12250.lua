-- Lua provided by RyzenAPI
-- Game: Game: Grand Theft Auto: San Andreas

-- MAIN APPLICATION
addappid(12250)
-- Game: addappid(12250)

-- MAIN APP DEPOTS / PACKAGES
addappid(12251, 1, "6a67a5fe83afaa99f8fcaf506ebeec31961220c470a9462362ccf8e0f7480ded")
