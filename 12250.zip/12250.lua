-- Lua provided by SkyAPI 
-- Game: Grand Theft Auto: San Andreas
addappid(12250)
addappid(12251, 1, "6a67a5fe83afaa99f8fcaf506ebeec31961220c470a9462362ccf8e0f7480ded")
