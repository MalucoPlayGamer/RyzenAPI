-- Lua provided by SkyAPI 
-- Game: Looks Good
addappid(2367190)
addappid(2367191, 1, "7cf1e0a075e24ecc5868bd7e842dcd7db6ad8508c215724fa0c1a1e879d36218")
