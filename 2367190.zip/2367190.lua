-- Lua provided by RyzenAPI
-- Game: 2367190

-- MAIN APPLICATION
addappid(2367190)
-- Game: addappid(2367190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367191, 1, "7cf1e0a075e24ecc5868bd7e842dcd7db6ad8508c215724fa0c1a1e879d36218")
