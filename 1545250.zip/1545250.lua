-- Lua provided by RyzenAPI
-- Game: ECHOLOCAUTION

-- MAIN APPLICATION
addappid(1545250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545251,0,"d77886ff4cea75ad6a1c89f6d0653de560a3cfbf89512df573528e3966e760ae")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1574350)
