-- Lua provided by RyzenAPI
-- Game: 3661670

-- MAIN APPLICATION
addappid(3661670)
-- Game: addappid(3661670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3661671, 1, "dcfc42dcfa2faeddae3dc672ccfb11ef2f9f64acae8ad3eed08129344bddaf1e")
