-- Lua provided by RyzenAPI
-- Game: iTownGamePlay UNIVERSE

-- MAIN APPLICATION
addappid(667120)

-- MAIN APP DEPOTS / PACKAGES
addappid(667121, 1, "d84bb987a6a34495fa9bb49169b4cf830a18eda4d384f9fef149d4ced0da7375")
addappid(667281, 0, "c351d40b7ad17788e88f491ed74fb94358ea5f2cf6d50cc3706e7f938985cee6")

