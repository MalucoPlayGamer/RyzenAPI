-- Lua provided by RyzenAPI
-- Game: iTownGamePlay UNIVERSE

-- MAIN APPLICATION
addappid(667120)

-- MAIN APP DEPOTS / PACKAGES
addappid(667121, 1, "d84bb987a6a34495fa9bb49169b4cf830a18eda4d384f9fef149d4ced0da7375")
addappid(667281, 0, "c351d40b7ad17788e88f491ed74fb94358ea5f2cf6d50cc3706e7f938985cee6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(761270)
addappid(771900)
