-- Lua provided by RyzenAPI
-- Game: Monster Farm

-- MAIN APPLICATION
addappid(919560)

-- MAIN APP DEPOTS / PACKAGES
addappid(919561, 1, "6298dc9e1298f5b08a56d3641c66ae50282b146d6e726e8307356261cb17b4a6")
