-- Lua provided by RyzenAPI
-- Game: Light - Die to Survive Demo

-- MAIN APPLICATION
addappid(3093110)
-- Game: addappid(3093110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3093111, 1, "f812b0ad60f629eb452bd5f43a6fbc9cd77607fed556cf257cf2d826b241a7d6")
