-- Lua provided by RyzenAPI
-- Game: Logout

-- MAIN APPLICATION
addappid(798950)
-- Game: addappid(798950)

-- MAIN APP DEPOTS / PACKAGES
addappid(798951, 1, "0be9c456bc7c6465e201fae486793b00a5dacd6f23c789e05704f8fea682908b")
