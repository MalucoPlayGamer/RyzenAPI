-- Lua provided by RyzenAPI
-- Game: GEX Trilogy

-- MAIN APPLICATION
addappid(3183970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3183971, 1, "b4e4d1572d3872ae6123b0f4e052110e020d7b4e80df78ac63879c078eb73f88")

