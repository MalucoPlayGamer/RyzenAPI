-- Lua provided by RyzenAPI
-- Game: GEX Trilogy

-- MAIN APPLICATION
addappid(3183970)
-- Game: addappid(3183970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183971, 1, "b4e4d1572d3872ae6123b0f4e052110e020d7b4e80df78ac63879c078eb73f88")
