-- Lua provided by RyzenAPI
-- Game: 5 Star Miami Resort

-- MAIN APPLICATION
addappid(952230)

-- MAIN APP DEPOTS / PACKAGES
addappid(952231, 1, "6f27a8287566dbe77bbf15a7ae81900ccd9b7373ab1df92cf966989b25559c54")

