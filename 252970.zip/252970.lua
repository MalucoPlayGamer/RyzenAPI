-- Lua provided by RyzenAPI
-- Game: McDROID

-- MAIN APPLICATION
addappid(252970)
addappid(318010)
addappid(368330)
addappid(400950)
addappid(401110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(252971, 1, "5b06caed6e25d516871719b3f932c7b4137e886e6194c25dd75f2f83848d0026")
addappid(252972, 1, "8a6bd3c38a696b017b9f7122c9efdd1a5006c41919003ebea37b7a6089a3d8a3")
addappid(252973, 1, "f89f6d751973fc34a7a6c9cb394f0be7d12618d9170e485115709f3aacaf68e5")
