-- Lua provided by RyzenAPI
-- Game: Power Grid

-- MAIN APPLICATION
addappid(2983910)
-- Game: addappid(2983910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983911, 1, "fb379c565a66ebee124b2e7a9294f6b54c26735ef8a7ce72443078752524cc5c")
