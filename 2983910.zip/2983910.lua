-- Lua provided by RyzenAPI 
-- Game: Power Grid
addappid(2983910)
addappid(2983911, 1, "fb379c565a66ebee124b2e7a9294f6b54c26735ef8a7ce72443078752524cc5c")
