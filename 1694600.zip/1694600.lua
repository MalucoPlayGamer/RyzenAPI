-- Lua provided by RyzenAPI
-- Game: THE HOUSE OF THE DEAD: Remake

-- MAIN APPLICATION
addappid(1694600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1694601, 1, "48ad40834a958d8d6aeb0b6e34c894835c8cb4809b9e6817753cfd65188121e2")

