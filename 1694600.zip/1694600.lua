-- Lua provided by SkyAPI 
-- Game: AppID 1694600
addappid(1694600)
addappid(1694601, 1, "48ad40834a958d8d6aeb0b6e34c894835c8cb4809b9e6817753cfd65188121e2")
