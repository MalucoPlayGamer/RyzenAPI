-- Lua provided by RyzenAPI
-- Game: 2540

-- MAIN APPLICATION
addappid(2540)
-- Game: addappid(2540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541, 1, "62df5236f4d186f950efd49c2ef1133636ced19c4c7c94acea10b2720a5b27da")
