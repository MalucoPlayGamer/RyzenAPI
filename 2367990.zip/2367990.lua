-- Lua provided by RyzenAPI
-- Game: Blazing Ace Demo

-- MAIN APPLICATION
addappid(2367990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367991, 1, "8249826c6e5bdce93e9086839de78dee5444899bb1109418f11d1f68b9d7798c")

