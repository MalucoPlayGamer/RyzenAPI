-- Lua provided by RyzenAPI
-- Game: Game: Wound Man

-- MAIN APPLICATION
addappid(2392810)
addappid(4735090)
-- Game: addappid(2392810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392811, 1, "62d16919bc8a73bde5b6be8ed837e46b2994c2b75430f19017dedf19abb8a6fb")
