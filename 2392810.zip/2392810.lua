-- Lua provided by RyzenAPI 
-- Game: Wound Man
addappid(2392810)
addappid(2392811, 1, "62d16919bc8a73bde5b6be8ed837e46b2994c2b75430f19017dedf19abb8a6fb")
addappid(4735090)
