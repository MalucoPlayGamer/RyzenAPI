-- Lua provided by RyzenAPI
-- Game: White Shadows

-- MAIN APPLICATION
addappid(1158890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158891, 1, "ef547d439d9eca10e7bd722ae5a3cd3b752d73de5f29d7e17142a7d89909baac")
