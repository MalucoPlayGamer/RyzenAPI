-- Lua provided by RyzenAPI
-- Game: Dickland: Racing

-- MAIN APPLICATION
addappid(2494680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494681, 1, "128f83aad59468b78c08a145b73d6ccd4522acadd91b1d2a8a1aadc2386cc0f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
