-- Lua provided by SkyAPI 
-- Game: AppID 3411650
addappid(3411650)
addappid(3411651, 1, "3615ec523d92af843b08803368d8fa09553588acea18b1003aa4c40f8d3a2117")
