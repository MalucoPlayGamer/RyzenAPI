-- Lua provided by RyzenAPI
-- Game: The Art of Observer System Redux

-- MAIN APPLICATION
addappid(1396070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396071, 1, "7e7efb23210216b93088af6af82e9d48d44249fd5bb58a7d5a6af0ed72cbf7fa")

