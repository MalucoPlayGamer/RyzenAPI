-- Lua provided by RyzenAPI
-- Game: The Drone Racing League Simulator

-- MAIN APPLICATION
addappid(641780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(641781, 1, "6007f43b30ef857415cd88b55161c8a9fe93da642affcd4588f9c22b0914efcb")
addappid(641782, 1, "ce0db1a233b82857a21dc853b97efef663201fb98d9ab1b25fb2a14924fc26d2")

