-- Lua provided by RyzenAPI
-- Game: 641780

-- MAIN APPLICATION
addappid(641780)
-- Game: addappid(641780)

-- MAIN APP DEPOTS / PACKAGES
addappid(641781, 1, "6007f43b30ef857415cd88b55161c8a9fe93da642affcd4588f9c22b0914efcb")
addappid(641782, 1, "ce0db1a233b82857a21dc853b97efef663201fb98d9ab1b25fb2a14924fc26d2")
