-- Lua provided by RyzenAPI
-- Game: Falcon A.T.

-- MAIN APPLICATION
addappid(286790)
-- Game: addappid(286790)

-- MAIN APP DEPOTS / PACKAGES
addappid(286792,0,"1a10f101fb5f40c67d8178d6de87aa072ae0d152834b7568ff8eb5fe49a4f89d")
addappid(286793,0,"3f100961831990198481ec53f01d23696443cdf0e40601cc39c7cdaf8a13ebe7")
addappid(286794,0,"097e4617da5a7f2b2e93c507416b374edff5d32e4da17e254f01d9bfb64921bb")
