-- Lua provided by RyzenAPI
-- Game: addappid(426590)

-- MAIN APPLICATION
addappid(426590)

-- MAIN APP DEPOTS / PACKAGES
addappid(426592,0,"ecd85510b98fa722cd11fbcef13adb31dd0b7c0fe485d755c96fad6393972b97")
