-- Lua provided by RyzenAPI
-- Game: 1239511

-- MAIN APPLICATION
addappid(1239511)
-- Game: addappid(1239511)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239530,0,"bf854a3724957aff93ebbb422aacc8cbb3942e8084cf58215fb6a3d10bf53d9e")
addappid(1239535,0,"70be4e8fdcd409387d665c71ebdadc67a482cd648f3a2d18516194fe3c2d2a5e")
