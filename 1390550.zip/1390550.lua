-- Lua provided by RyzenAPI
-- Game: Game: FAR: Lone Sails Demo

-- MAIN APPLICATION
addappid(1390550)
-- Game: addappid(1390550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390551, 1, "dd7b13c12de1c2b685592bd7da59a83d616e95b15cd877712c79926f47305218")
