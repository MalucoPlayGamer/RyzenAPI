-- Lua provided by RyzenAPI
-- Game: 490950

-- MAIN APPLICATION
addappid(490950)
addappid(490951)
addappid(490953)
addappid(490954)
addappid(490955)

-- MAIN APP DEPOTS / PACKAGES
addappid(490952,0,"947c5b26dfcc63a99113b4f9fd95e324fd2bd3a1fb7ba0db465847c5e7ff29af")

