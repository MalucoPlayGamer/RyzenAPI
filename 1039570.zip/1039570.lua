-- Lua provided by RyzenAPI
-- Game: addappid(1039570)

-- MAIN APPLICATION
addappid(1039570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039571, 1, "31019e947f6378d376c6c81a38340cec6223c79fa24995a3c9b33b106dceb56b")
