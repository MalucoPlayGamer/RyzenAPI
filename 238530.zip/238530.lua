-- Lua provided by RyzenAPI
-- Game: Super Puzzle Platformer Deluxe

-- MAIN APPLICATION
addappid(238530)

-- MAIN APP DEPOTS / PACKAGES
addappid(238531, 1, "f8e158ee6a4eaa95a38cd9b6452f16f34b91ccf2a5e50b103547409d60868d1c")
addappid(238532, 1, "4bc4ce26d3a7e7cc2c0c4a7a9bf86aa5ffac9bbdc5e1285b2a341003e0f152a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
