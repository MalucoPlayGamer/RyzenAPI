-- Lua provided by RyzenAPI
-- Game: addappid(1852000)

-- MAIN APPLICATION
addappid(1852000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852001, 1, "e5e773fe69047ee9f3bdc2c6fd69731b7dd3304c79f87c255d57acf38ef66410")
