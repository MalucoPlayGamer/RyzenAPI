-- Lua provided by RyzenAPI
-- Game: 1252000

-- MAIN APPLICATION
addappid(1252000)
-- Game: addappid(1252000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252001, 1, "4c4dae0b0ee89b653b4a0dffa400b67bac683d36c81b84957abad0bc416d04d5")
addappid(1252002, 1, "ab4b5228452bb8883bf7d8af382de1270f44bb77aba920085358a4c36b20a9dd")
addappid(1252003, 1, "f1e827d1b32fc3fdd7c67637f2926598bf73a8a360c481ef2971efff650af1c2")
