-- Lua provided by RyzenAPI
-- Game: Game: DiscStorm

-- MAIN APPLICATION
addappid(330670)
-- Game: addappid(330670)

-- MAIN APP DEPOTS / PACKAGES
addappid(330671, 1, "5021c5f499f27359afa1f22b244c2a3873c542218edea150ad9588fb9f918f22")
addappid(330672, 1, "1cc96140969dd176bba7a58860b1663a64cd0ad87ab5fc4745043faf63eb57b4")
addappid(330673, 1, "af067440a8305e1ea420b66eae95a4cd25d7c7e3c6ef40c4bdaf1e2c5cfdd0e5")
addappid(374530, 0, "20c1b6e25eb37528b43318243de6d642c7f6ae0767a11b8067ba5dacc8f79bbe")
