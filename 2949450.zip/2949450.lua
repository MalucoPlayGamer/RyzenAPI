-- Lua provided by RyzenAPI
-- Game: addappid(2949450)

-- MAIN APPLICATION
addappid(2949450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949451, 1, "9d5b0fda5ee7de10e5a90550ba7eb154140294b85198e38e3add78ba32477ec3")
