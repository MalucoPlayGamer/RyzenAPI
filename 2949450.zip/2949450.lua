-- Lua provided by RyzenAPI 
-- Game: 从画面中出来的我推Vtuber的同居生活 ～梦魔可爱ASMR主播是地雷系？～
addappid(2949450)
addappid(2949451, 1, "9d5b0fda5ee7de10e5a90550ba7eb154140294b85198e38e3add78ba32477ec3")
