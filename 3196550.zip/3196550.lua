-- Lua provided by RyzenAPI
-- Game: 花奴令 HUANU POEMS

-- MAIN APPLICATION
addappid(3196550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3196551, 1, "219c98232ac909c816efe8fce4d1f41ac51190d80bbc9616ce691e6180ec6ac3")
