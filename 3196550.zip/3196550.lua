-- Lua provided by RyzenAPI
-- Game: addappid(3196550)

-- MAIN APPLICATION
addappid(3196550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196551, 1, "219c98232ac909c816efe8fce4d1f41ac51190d80bbc9616ce691e6180ec6ac3")
