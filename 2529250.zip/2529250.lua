-- Lua provided by RyzenAPI
-- Game: Mini Settlers Demo

-- MAIN APPLICATION
addappid(2529250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529251, 1, "62f0c0cee89761685724915dd43460dba5a44deabb893b0719bca675d733a101")
