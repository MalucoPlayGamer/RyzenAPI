-- Lua provided by RyzenAPI
-- Game: Please, Don't Touch Anything 3D

-- MAIN APPLICATION
addappid(529590)
-- Game: addappid(529590)

-- MAIN APP DEPOTS / PACKAGES
addappid(529591, 1, "f6ce111e6132204142e6fdd5121a5afd2727914b5ff430728c993d14404e421a")
addappid(529592, 1, "47f2fbb5efee29c7d8b1d732c56741730b74e76eeabaf93fe0d5cc80a37d65c7")
addappid(529593, 1, "283c2d47cd51b2ff9fa09b65d07aaefb0b78fdec2c806b852ed54eac0555144a")
