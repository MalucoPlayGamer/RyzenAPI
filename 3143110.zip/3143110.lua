-- Lua provided by RyzenAPI
-- Game: Game: Elden Sword

-- MAIN APPLICATION
addappid(3143110)
-- Game: addappid(3143110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143111, 1, "6dc9e03be1796dcebee6992d829ad545d3cc9e6fb89534f86223b48513f953b9")
