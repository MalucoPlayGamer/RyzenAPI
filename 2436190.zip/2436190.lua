-- Lua provided by RyzenAPI
-- Game: Survivors Will

-- MAIN APPLICATION
addappid(2436190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2436191, 1, "6bf99673d30b261e0fad58850b959e0895d6c79f91dfbd2ad7052df1f50a4c3f")

