-- Lua provided by RyzenAPI
-- Game: 1460180

-- MAIN APPLICATION
addappid(1460180)
addappid(1460181)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460180,0,"93c4e336b2984b2f6d0d0be15c004b6c4faaf972c66433d910cbeb7c7ca49838")

