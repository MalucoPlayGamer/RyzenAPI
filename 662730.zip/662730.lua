-- Lua provided by RyzenAPI
-- Game: 662730

-- MAIN APPLICATION
addappid(662730)
-- Game: addappid(662730)

-- MAIN APP DEPOTS / PACKAGES
addappid(662731, 1, "56830b9421d421991097dfb5e5dcc5c3bf3a7cd240a38761a35561d92e97b828")
addappid(662732, 1, "1b1a8540c187dd8a03cfbd8cd28dc615e4b2f746cec92c81c4f0d85b2d208602")
