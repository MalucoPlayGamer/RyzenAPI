-- Lua provided by RyzenAPI
-- Game: iVIBRATE Ultimate Edition

-- MAIN APPLICATION
addappid(1462490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462494,0,"308b8a220f020a445584b551861d9a395693802620404f0046095a160f3134d2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1791470)
addappid(1791471)
addappid(1870950)
