-- Lua provided by RyzenAPI
-- Game: Poop Clicker

-- MAIN APPLICATION
addappid(351160)
-- Game: addappid(351160)

-- MAIN APP DEPOTS / PACKAGES
addappid(351161, 1, "bddc3393ed9335c1e7319cdc4810c42075d5ff127486c053d9fd5e3da36b69dd")
