-- Lua provided by RyzenAPI
-- Game: 修炼成仙

-- MAIN APPLICATION
addappid(2547120)
-- Game: addappid(2547120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547121, 1, "1994479c7a42749db12be52c283f7a165bbb01779c23de676ee4610bef858479")
