-- Lua provided by RyzenAPI
-- Game: Minesweeper Arcade

-- MAIN APPLICATION
addappid(2187850)
-- Game: addappid(2187850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187851, 1, "c9fdddadb9cf7537216a8afe997d8f771fbf8a7c922abf732ed724789f7ab48e")
