-- Lua provided by RyzenAPI
-- Game: addappid(1788920)

-- MAIN APPLICATION
addappid(1788920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788921, 1, "2259ea3e982e539c41d8202673a3d7dcde23e3014fce47252c83c6df689cf8cd")
addappid(1788924, 1, "f9cd614aebee44bfdb409163b4abf640e3bef8e09a6ae835ae14fbaa2338afe0")
