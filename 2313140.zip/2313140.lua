-- Lua provided by RyzenAPI
-- Game: OPPAI Ero App Academy Bigger, Better, Electric Boobaloo!

-- MAIN APPLICATION
addappid(2313140)
addappid(2998690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313141, 1, "a3719539c04fc523597e4662b83bc76beacc03a657df11231569586d5f92eeeb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
