-- Lua provided by RyzenAPI
-- Game: addappid(2313140)

-- MAIN APPLICATION
addappid(2313140)
addappid(2998690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313141, 1, "a3719539c04fc523597e4662b83bc76beacc03a657df11231569586d5f92eeeb")
