-- Lua provided by RyzenAPI
-- Game: Space Reign

-- MAIN APPLICATION
addappid(1762570)
-- Game: addappid(1762570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762571, 1, "5801a701e02460b48cb05757b53942ea34105ab70ce791d18b04344fb4e5e5d0")
