-- Lua provided by RyzenAPI
-- Game: The Count Lucanor

-- MAIN APPLICATION
addappid(440880)

-- MAIN APP DEPOTS / PACKAGES
addappid(440881, 1, "710c93b2414b26fa55b5a4fa57db1b49a1a708ff384c41e3cf23418ee776732f")
addappid(440882, 1, "8e7934bbc569e9a218b57cbd3ca343c53dd5b391914d49660b5697e8116158ac")
addappid(440883, 1, "8ecd527e5356b6e738cefad5a5829f685273d514c6f0c5477df4d63ba2cfa6fa")
addappid(440885, 1, "e9585e123d5bbb80f69fcdbef4a8ef2c12a47afbc4be62793ba2650b07d3668e")

