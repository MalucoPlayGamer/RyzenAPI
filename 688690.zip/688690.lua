-- Lua provided by RyzenAPI
-- Game: Game: AppID 688690

-- MAIN APPLICATION
addappid(688690)
-- Game: addappid(688690)

-- MAIN APP DEPOTS / PACKAGES
addappid(688691, 1, "66e323d36d8514f75d523b0497539a45796fe2253bf8c18b001fe775965f6d32")
