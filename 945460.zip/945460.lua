-- Lua provided by RyzenAPI
-- Game: Zombie Builder Defense

-- MAIN APPLICATION
addappid(945460)
-- Game: addappid(945460)

-- MAIN APP DEPOTS / PACKAGES
addappid(945461, 1, "523726336668b928387a24a58d7a14e79fe9086cb407f90eb906621190b37fdd")
