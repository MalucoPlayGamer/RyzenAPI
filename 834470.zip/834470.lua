-- Lua provided by RyzenAPI
-- Game: addappid(834470)

-- MAIN APPLICATION
addappid(834470)

-- MAIN APP DEPOTS / PACKAGES
addappid(834471, 1, "30fa6d7fa2e428d7f7b64391ae48abecf61ac0297cacd67e9e27424bbef498fc")
