-- Lua provided by SkyAPI 
-- Game: The Great Axe
addappid(3592340)
addappid(3592341, 1, "194be574d810fdc552e89cc6b3927b8f27ea52d55bd0192f52df4f02b029190c")
