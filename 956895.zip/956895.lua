-- Lua provided by RyzenAPI
-- Game: 956895

-- MAIN APPLICATION
addappid(956895)
-- Game: addappid(956895)

-- MAIN APP DEPOTS / PACKAGES
addappid(956895,0,"a71e9a4bc4b006ea1d1d4883cda58862f948b6ef197e20d13b4142ab2e52f69b")
