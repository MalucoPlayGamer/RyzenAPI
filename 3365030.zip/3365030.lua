-- Lua provided by RyzenAPI
-- Game: Atelier Ryza: Ever Darkness & the Secret Hideout DX

-- MAIN APPLICATION
addappid(3365030)
addappid(3782450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365031,0,"ed0362b8bfac94a627decf3ed0f4413bbfa39ccf6bcb02819e0ee86ce2b3df22")

