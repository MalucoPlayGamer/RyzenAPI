-- Lua provided by RyzenAPI
-- Game: 2978220

-- MAIN APPLICATION
addappid(2978220)
-- Game: addappid(2978220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978221, 1, "6320a81024dd63f6403a12ad1925b4de1ec1fa8b85f7ec04be518f79a8033db2")
