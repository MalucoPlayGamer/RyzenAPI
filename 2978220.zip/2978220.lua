-- Lua provided by RyzenAPI
-- Game: OneKind

-- MAIN APPLICATION
addappid(2978220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2978221, 1, "6320a81024dd63f6403a12ad1925b4de1ec1fa8b85f7ec04be518f79a8033db2")

