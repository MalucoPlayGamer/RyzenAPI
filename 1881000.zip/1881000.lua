-- Lua provided by RyzenAPI
-- Game: 1881000

-- MAIN APPLICATION
addappid(1881000)
-- Game: addappid(1881000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881001, 1, "d209243cdcd03f08fbdec47d3677b6abe6868c8b8a7f40c65732d3779e6cb1bf")
