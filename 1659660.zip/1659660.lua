-- Lua provided by SkyAPI 
-- Game: AppID 1659660
addappid(1659660)
addappid(1659661, 1, "6f87f2b0a883c29a946b4b5c6331218796e13433dfa4421620734db40411997f")
