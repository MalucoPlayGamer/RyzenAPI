-- Lua provided by RyzenAPI
-- Game: Sophia the Traveler Demo

-- MAIN APPLICATION
addappid(1659660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659661, 1, "6f87f2b0a883c29a946b4b5c6331218796e13433dfa4421620734db40411997f")

