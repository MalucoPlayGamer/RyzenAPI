-- Lua provided by RyzenAPI
-- Game: Delven

-- MAIN APPLICATION
addappid(2430500)
-- Game: addappid(2430500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430501, 1, "9e99471b9d1bb75e8877c0b3de4d3db826ee6c0ef1918c7ea70bc2e4e2e02a29")
