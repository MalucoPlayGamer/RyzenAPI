-- Lua provided by RyzenAPI
-- Game: 341440

-- MAIN APPLICATION
addappid(341440)
-- Game: addappid(341440)

-- MAIN APP DEPOTS / PACKAGES
addappid(341441, 1, "16f7b1f73e0dcc294f9e668609c7a0ecd69b7cdad3def853dcfe8517b39c5e7f")
