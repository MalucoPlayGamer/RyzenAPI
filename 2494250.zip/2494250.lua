-- Lua provided by RyzenAPI
-- Game: 2494250

-- MAIN APPLICATION
addappid(2494250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494250,0,"6fbac1b05b4e9bb70dd3df8668778c966c84faefd5edadb34170d3d5a63f5a52")
