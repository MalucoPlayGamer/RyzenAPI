-- Lua provided by RyzenAPI
-- Game: The Forgotten City

-- MAIN APPLICATION
addappid(874260)
addappid(1662400)
-- Game: addappid(874260)

-- MAIN APP DEPOTS / PACKAGES
addappid(874261, 1, "3b1c4d8d491dc8fd3c3008d70b84c957db612d2b51979b810b16af4043994602")
addappid(1662430, 0, "76c7803b10279dd7ffe2bfb17f597ea39152272bfa09e024299cb80f9b37864f")
