-- Lua provided by RyzenAPI
-- Game: AppID 874260

-- MAIN APPLICATION
addappid(874260)
addappid(1662400)

-- MAIN APP DEPOTS / PACKAGES
addappid(874261, 1, "3b1c4d8d491dc8fd3c3008d70b84c957db612d2b51979b810b16af4043994602")
addappid(1662430, 0, "76c7803b10279dd7ffe2bfb17f597ea39152272bfa09e024299cb80f9b37864f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
