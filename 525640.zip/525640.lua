-- Lua provided by RyzenAPI
-- Game: Bullets And More VR - BAM VR

-- MAIN APPLICATION
addappid(525640)
-- Game: addappid(525640)

-- MAIN APP DEPOTS / PACKAGES
addappid(525641, 1, "8ee0c68452d392f89003441e1b5523f6895711eef8ee9fb4ec9fd66c441c0055")
