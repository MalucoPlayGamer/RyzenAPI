-- Lua provided by RyzenAPI
-- Game: MORTEM

-- MAIN APPLICATION
addappid(585740)
addappid(765050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(585741,0,"fd036da98933a9ba505935d37a8d35b09d9c80c54f49a73d19b17406dfe401af")

