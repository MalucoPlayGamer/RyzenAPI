-- Lua provided by RyzenAPI
-- Game: MORTEM

-- MAIN APPLICATION
addappid(585740)
addappid(765050)

-- MAIN APP DEPOTS / PACKAGES
addappid(585741,0,"fd036da98933a9ba505935d37a8d35b09d9c80c54f49a73d19b17406dfe401af")

