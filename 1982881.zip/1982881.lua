-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1982881)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982881,0,"cf724007ade8601c55a7e2982f95ff79d806fcab351682167f58f5236f92999c")
