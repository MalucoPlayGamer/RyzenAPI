-- Lua provided by SkyAPI 
-- Game: AppID 2258020
addappid(2258020)
addappid(2258021, 1, "bcbf24077d420bc3e4a39439462f8db68b1fdcc452c4b18ec2447eb7b9338a5e")
