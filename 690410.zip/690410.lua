-- Lua provided by RyzenAPI
-- Game: Twisted: Enhanced Edition

-- MAIN APPLICATION
addappid(690410)

-- MAIN APP DEPOTS / PACKAGES
addappid(690411,0,"a5eacf2df0bedb32b316f644989f040d72cb1ed5d1a1ca585e4f7efc5c57f3af")

