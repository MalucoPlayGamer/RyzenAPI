-- Lua provided by RyzenAPI
-- Game: 2343590

-- MAIN APPLICATION
addappid(2343590)
-- Game: addappid(2343590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343591, 1, "f6c26e6ef6a25227f0dc029eaebcf241fb1a3a552a75b7c601abceda4e0e5791")
