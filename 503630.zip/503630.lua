-- Lua provided by RyzenAPI
-- Game: INVASION!

-- MAIN APPLICATION
addappid(503630)

-- MAIN APP DEPOTS / PACKAGES
addappid(503631, 1, "396f14456bff183f4184cd0001458858f8d3abec4e2e9bb3826fcccdb306c86a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
