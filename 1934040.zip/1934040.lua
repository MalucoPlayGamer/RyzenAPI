-- Lua provided by RyzenAPI
-- Game: 1934040

-- MAIN APPLICATION
addappid(1934040)
-- Game: addappid(1934040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934041, 1, "eac39b3ca9d9a1d1cc4e60d5c48f077d0e9d11b511cbb2257d953c5776836a87")
