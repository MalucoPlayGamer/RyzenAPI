-- Lua provided by RyzenAPI
-- Game: Game: Retail Company Simulator Demo

-- MAIN APPLICATION
addappid(3142430)
-- Game: addappid(3142430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142431, 1, "8c44401e01f4c0f991d472867de5117779f098755b839c93fed180e975368ae9")
