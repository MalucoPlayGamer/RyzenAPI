-- Lua provided by RyzenAPI 
-- Game: AppID 4018200
addappid(4018200)
addappid(4018201, 1, "cefedf1b4433130809574f308f4c2213ae1c562da4af42c9fc1a6bcb12067084")
