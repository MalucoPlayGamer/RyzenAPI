-- Lua provided by RyzenAPI
-- Game: Idosra: The Electric Renaissance

-- MAIN APPLICATION
addappid(2808350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808353,0,"2793835f489f3fa614086d07520ec4c83a58f9805e63b4c20490f5c3eb1a5a1c")

