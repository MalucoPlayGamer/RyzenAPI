-- Lua provided by RyzenAPI
-- Game: Shop Heroes

-- MAIN APPLICATION
addappid(506140)

-- MAIN APP DEPOTS / PACKAGES
addappid(506141, 1, "c630c7d14c21bd7f3d185266b3712bee4262bd9be58ee44e130fb8d31f845615")
