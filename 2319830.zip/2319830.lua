-- Lua provided by RyzenAPI
-- Game: Hentai Festival

-- MAIN APPLICATION
addappid(2319830)
-- Game: addappid(2319830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319831, 1, "96e306357a490fd0e45656028edef99ec4a4ce00e0366d4730e326ed29e9e8a5")
