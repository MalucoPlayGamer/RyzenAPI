-- Lua provided by SkyAPI 
-- Game: Avoid!
addappid(1539890)
addappid(1539891, 1, "540af0f27364489f760ec8512b7189e782c92d0a727938bb58b67b9100ffe7d5")
