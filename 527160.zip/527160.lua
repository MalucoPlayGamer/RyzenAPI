-- Lua provided by RyzenAPI
-- Game: Game: AppID 527160

-- MAIN APPLICATION
addappid(527160)
-- Game: addappid(527160)

-- MAIN APP DEPOTS / PACKAGES
addappid(527161, 1, "a11583a5f2c78fa797154e496fa33b1afbe2a221c79cf2f0a553898e85d0154c")
