-- Lua provided by RyzenAPI
-- Game: AppID 349110

-- MAIN APPLICATION
addappid(349110)
-- Game: addappid(349110)

-- MAIN APP DEPOTS / PACKAGES
addappid(349111, 1, "51981459713b696d9f2d8668d340ca55628ff19ade51410f2fb82846ec5316ce")
