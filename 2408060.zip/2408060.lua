-- Lua provided by RyzenAPI
-- Game: Low and Furious

-- MAIN APPLICATION
addappid(2408060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408061, 1, "a13a5fce044dee61b75e63f7c4da2a662873c5e148c9ae20478c4bbaf9427ff6")
