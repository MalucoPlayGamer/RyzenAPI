-- Lua provided by RyzenAPI
-- Game: THE LAST PLAYER:VR Battle Royale

-- MAIN APPLICATION
addappid(1015610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015611, 1, "8bcb89b9429874df56c00af5bc3359a8af0d3345ddee93209d8aa443d27ba193")

