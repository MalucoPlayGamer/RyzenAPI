-- 3964430's Lua and Manifest Created by Hubcap Manifest
-- Astro Nova
-- Created: July 28, 2026 at 11:11:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3964430) -- Astro Nova
-- MAIN APP DEPOTS
addappid(3964431, 1, "e68134d975f66d75b7f686c330a5434198e48c1ad3ba14f6907789716bbbb088") -- Depot 3964431
setManifestid(3964431, "7623295778231987232", 214059701)