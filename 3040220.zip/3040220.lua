-- Lua provided by RyzenAPI
-- Game: Captain Blood

-- MAIN APPLICATION
addappid(3040220)
-- Game: addappid(3040220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040221, 1, "4e420c4703c98612bdd32e142ab68e49de39d49835b722b523ddede7ae026a17")
