-- Lua provided by RyzenAPI
-- Game: Game: AppID 3021050

-- MAIN APPLICATION
addappid(3021050)
-- Game: addappid(3021050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021051, 1, "ce7311885cab50ab0b05b39312bbf4162f2d62d8a796078820049231b44bd62f")
