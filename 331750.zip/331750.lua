-- Lua provided by RyzenAPI
-- Game: Disney•Pixar WALL-E

-- MAIN APPLICATION
addappid(331750)

-- MAIN APP DEPOTS / PACKAGES
addappid(331751, 1, "769e3087769b5529710f7c807aa97793227c0d8c845a5a586d4db4063e4e6c93")
addappid(331752, 1, "ca3a52271ae0e1d3c01beed45988c3fea574e09f44feebd0dd58a614bc048176")
addappid(331753, 1, "3da074292cdaaa15448f09c85e5340a254b09748b24ba8f29dfa96701e454016")
addappid(331754, 1, "ab437334c7b1273c8e9ef550dac716e5ffaa2287028822b159498e3cdc327865")
addappid(331755, 1, "a1436329feaa9178e92554f95a086f6b33660fa9dd7aa24341fbfc49c99ce74d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
