-- Lua provided by RyzenAPI 
-- Game: Challenge Dream Cat
addappid(1780260)
addappid(1780261, 1, "a0f3e9336d1e3fe17c4baf1b21f5bcb56f02f1e42aed42fb7bd8ffbd5d78975a")
addappid(1848240, 0, "6341db4f385c6a2878a2f28dbe9301656f5738af3be17d91c3073d8a15d7952e")
