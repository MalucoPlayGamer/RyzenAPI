-- Lua provided by SkyAPI 
-- Game: Crayon Computer
addappid(2650830)
addappid(2650831, 1, "7acf861f568286a8104b7084faf1a44c65e57cefae22bc1acb1ae6f485e1f763")
