-- Lua provided by RyzenAPI
-- Game: Game: Crayon Computer

-- MAIN APPLICATION
addappid(2650830)
-- Game: addappid(2650830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650831, 1, "7acf861f568286a8104b7084faf1a44c65e57cefae22bc1acb1ae6f485e1f763")
