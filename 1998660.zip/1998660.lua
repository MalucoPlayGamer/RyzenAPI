-- Lua provided by RyzenAPI
-- Game: 1998660

-- MAIN APPLICATION
addappid(1998660)
-- Game: addappid(1998660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998661, 1, "83e09ed016f241452da5cc4c5831d740b1f4eb7ad7faf68412cd7200e47cd53a")
