-- 3889600's Lua and Manifest Created by Hubcap Manifest
-- Gridfall
-- Created: June 26, 2026 at 11:35:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3889600) -- Gridfall
-- MAIN APP DEPOTS
addappid(3889601, 1, "57e0c259a6d71afd385e91049897a759a2f449df7cb60bc1f92015e4caa938d8") -- Depot 3889601
setManifestid(3889601, "4859821504746346984", 680027195)