-- Lua provided by RyzenAPI
-- Game: Game: Doodle God: Mighty Trio

-- MAIN APPLICATION
addappid(771250)
addappid(817750)
-- Game: addappid(771250)

-- MAIN APP DEPOTS / PACKAGES
addappid(771251, 1, "90273e08f2ada0bcd85b1af9b44e27699b25150d41a6590c7fab848764d7b452")
