-- Lua provided by RyzenAPI
-- Game: Doodle God: Mighty Trio

-- MAIN APPLICATION
addappid(771250)
addappid(817750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(771251, 1, "90273e08f2ada0bcd85b1af9b44e27699b25150d41a6590c7fab848764d7b452")

