-- Lua provided by RyzenAPI
-- Game: Puff Love Story

-- MAIN APPLICATION
addappid(3389860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389861, 1, "7a2947e2e7ddc5793ff93ff4654f0db5787540aa12f002da8c167b6bea7f11ef")
addappid(3389870, 0, "4af3d235ae6fbfdc7cfd7df362d7f150d0601b896e540882ed06f8b98209c8f1")

