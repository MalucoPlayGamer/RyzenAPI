-- Lua provided by RyzenAPI
-- Game: VocabVan

-- MAIN APPLICATION
addappid(3088820)
