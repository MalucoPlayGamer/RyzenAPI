-- Lua provided by RyzenAPI
-- Game: AppID 2135850

-- MAIN APPLICATION
addappid(2135850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135851, 1, "9e972786812002c9c8c5aca1bfe56f1801fdbde6d0debcff0c9de30d0a1efc8d")
