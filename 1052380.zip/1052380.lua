-- Lua provided by RyzenAPI
-- Game: Ikeda : The Scrap Hunter E.P.

-- MAIN APPLICATION
addappid(1052380)
addappid(1139852)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052381, 1, "a8effd872c3d0a5fcbc4c3816c4528388b61d4898acd06a5ce4a2b2507dd6478")

