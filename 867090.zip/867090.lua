-- Lua provided by RyzenAPI
-- Game: 867090

-- MAIN APPLICATION
addappid(867090)
-- Game: addappid(867090)

-- MAIN APP DEPOTS / PACKAGES
addappid(867091, 1, "95b0261bdaffc2bd89b02a19e229f8aee1208ce35f28cd017d6e8da0bd872f37")
