-- Lua provided by RyzenAPI
-- Game: addappid(2321350)

-- MAIN APPLICATION
addappid(2321350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321351, 1, "6d9e6635d0cd7b9cf6e9624e1a52c5f20170aa5ce6cc2cd5557310f89e2c45df")
addappid(3158000, 0, "8c46ed612e36313a7d6c5bb86df5c5b37cde9d932a6502d0c9aa129cef74cde4")
