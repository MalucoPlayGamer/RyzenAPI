-- Lua provided by RyzenAPI
-- Game: they killed your cat

-- MAIN APPLICATION
addappid(3489420) -- They Killed Your Cat

-- MAIN APP DEPOTS / PACKAGES
addappid(3489422, 1, "bbee12f24557390efa56bb08d68fdffafaf80df7f2ab539e7d6fad04d3ad0a31") -- Depot 3489422
