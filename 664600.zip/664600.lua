-- Lua provided by RyzenAPI
-- Game: Memories of Home

-- MAIN APPLICATION
addappid(664600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(664601,0,"9116d1a737c353b306a6c3aff48da62f885eb77281188e22d1ac6042d2b319f7")

