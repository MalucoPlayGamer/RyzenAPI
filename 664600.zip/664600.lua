-- Lua provided by RyzenAPI
-- Game: Memories of Home

-- MAIN APPLICATION
addappid(664600)

-- MAIN APP DEPOTS / PACKAGES
addappid(664601,0,"9116d1a737c353b306a6c3aff48da62f885eb77281188e22d1ac6042d2b319f7")

