-- Lua provided by RyzenAPI
-- Game: AppID 1149860

-- MAIN APPLICATION
addappid(1149860)
addappid(1167500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149861, 1, "c335b5569aede02109e592fe17eb0a9c0e1dfc95fc1e1d0c1c582271f6989cb2")

