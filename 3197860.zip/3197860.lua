-- Lua provided by SkyAPI 
-- Game: Infinite Idle: Online Clicker RPG
addappid(3197860)
addappid(3197861, 1, "14aa175c0a5cf2a84207801849b3cb6dfe3a2eacb34ec9e51009fa5c5974888a")
