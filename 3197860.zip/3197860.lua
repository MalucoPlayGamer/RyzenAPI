-- Lua provided by RyzenAPI
-- Game: addappid(3197860)

-- MAIN APPLICATION
addappid(3197860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197861, 1, "14aa175c0a5cf2a84207801849b3cb6dfe3a2eacb34ec9e51009fa5c5974888a")
