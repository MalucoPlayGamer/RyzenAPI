-- Lua provided by RyzenAPI
-- Game: Magical Girl Survivors: Prologue

-- MAIN APPLICATION
addappid(2141330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2141331, 1, "ebdcc55b50c91d3598093835d8ebb4d6e7caf8eb2e8fc9b5e519176e75f74aaf")

