-- Lua provided by RyzenAPI
-- Game: Magical Girl Survivors: Prologue

-- MAIN APPLICATION
addappid(2141330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141331, 1, "ebdcc55b50c91d3598093835d8ebb4d6e7caf8eb2e8fc9b5e519176e75f74aaf")
