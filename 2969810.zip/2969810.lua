-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Axonos - Owen Roberts International Airport

-- MAIN APPLICATION
addappid(2969810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969810,0,"a978562fd573a1f43b6bb2bca889cfd1f49dc188bd41bf920e88d3691a8a26cf")
