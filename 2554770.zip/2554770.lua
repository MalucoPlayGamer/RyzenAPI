-- Lua provided by RyzenAPI
-- Game: 2554770

-- MAIN APPLICATION
addappid(2554770)
-- Game: addappid(2554770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554771, 1, "ea094dc694af96d16c8904d24af63d9a85103f59945b620d6d64d85adfe8fcec")
