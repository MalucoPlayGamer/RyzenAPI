-- Lua provided by RyzenAPI
-- Game: DEATH IN UNISON

-- MAIN APPLICATION
addappid(2454890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454891, 1, "79c08f047305cc5e13da78089edf4c6107ad436761e59708c76910911a82c856")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
