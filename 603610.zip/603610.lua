-- Lua provided by RyzenAPI
-- Game: Game: AppID 603610

-- MAIN APPLICATION
addappid(603610)
-- Game: addappid(603610)

-- MAIN APP DEPOTS / PACKAGES
addappid(603611, 1, "8db540fa371ff9f93e33df0e24aff2be66ca57eeaffc72b975f694f17fdb0212")
