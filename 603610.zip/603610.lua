-- Lua provided by SkyAPI 
-- Game: AppID 603610
addappid(603610)
addappid(603611, 1, "8db540fa371ff9f93e33df0e24aff2be66ca57eeaffc72b975f694f17fdb0212")
