-- Lua provided by RyzenAPI
-- Game: AEGIS 2186

-- MAIN APPLICATION
addappid(603610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(603611, 1, "8db540fa371ff9f93e33df0e24aff2be66ca57eeaffc72b975f694f17fdb0212")

