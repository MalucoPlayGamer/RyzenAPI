-- Lua provided by RyzenAPI 
-- Game: Football, Tactics & Glory
addappid(375530)
addappid(375531, 1, "531ccfe7bb71efdd67df507ba75737ccd4b93307333854b86f6d4274b354b24a")
