-- Lua provided by RyzenAPI
-- Game: Football, Tactics & Glory

-- MAIN APPLICATION
addappid(375530)
-- Game: addappid(375530)

-- MAIN APP DEPOTS / PACKAGES
addappid(375531, 1, "531ccfe7bb71efdd67df507ba75737ccd4b93307333854b86f6d4274b354b24a")
