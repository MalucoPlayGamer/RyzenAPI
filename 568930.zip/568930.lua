-- Lua provided by RyzenAPI
-- Game: The Land of Pain

-- MAIN APPLICATION
addappid(568930)
addappid(1829290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(568931, 1, "35b29763e257a5b1a6c4c6252c5dabdd87681106de0326819af16c02d95d555f")

