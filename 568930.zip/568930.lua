-- Lua provided by RyzenAPI
-- Game: Game: AppID 568930

-- MAIN APPLICATION
addappid(568930)
-- Game: addappid(568930)

-- MAIN APP DEPOTS / PACKAGES
addappid(568931, 1, "35b29763e257a5b1a6c4c6252c5dabdd87681106de0326819af16c02d95d555f")
