-- Lua provided by RyzenAPI
-- Game: addappid(2154330)

-- MAIN APPLICATION
addappid(2154330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154331, 1, "301400af25781cf3689238601d5557b04a6df2cc65971d4da3ae48d5fd2b4ae3")
