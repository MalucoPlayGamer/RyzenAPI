-- Lua provided by SkyAPI 
-- Game: Oblin Party
addappid(2643290)
addappid(2643291, 1, "daeb43351c7851a519908976e7807925107bc0679096ce3c8f9f14ffc0f32c6c")
