-- Lua provided by RyzenAPI
-- Game: Oblin Party

-- MAIN APPLICATION
addappid(2643290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643291, 1, "daeb43351c7851a519908976e7807925107bc0679096ce3c8f9f14ffc0f32c6c")
