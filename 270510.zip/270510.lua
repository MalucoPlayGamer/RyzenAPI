-- Lua provided by RyzenAPI
-- Game: EPOCH

-- MAIN APPLICATION
addappid(270510)

-- MAIN APP DEPOTS / PACKAGES
addappid(270511, 1, "09b08136bb6e71a3f6fff4712a8cc7c06a625bf2f4892ebe0bf8522a3cc41cc5")

