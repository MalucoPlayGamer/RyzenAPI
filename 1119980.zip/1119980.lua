-- Lua provided by RyzenAPI
-- Game: In Sound Mind

-- MAIN APPLICATION
addappid(1119980)
addappid(1756610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119981, 1, "732d08165eb2d508fe8b3082419c091f9bcc1d837a162337009d686b73fc80eb")

