-- Lua provided by RyzenAPI
-- Game: Undead Under Night Rain

-- MAIN APPLICATION
addappid(1957010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957011, 1, "1fe0b0c1dc16fdb66562623cd4df37442381e33ac9e97d56f1107018973f87a6")

