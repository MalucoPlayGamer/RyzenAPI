-- Lua provided by RyzenAPI
-- Game: Ironclads 2: Caroline Islands War 1885

-- MAIN APPLICATION
addappid(647840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(647841,0,"71ca93d2aaba3cf7bff410a1a9e8f76547bb71d73c8f5b01be4cc2a97f4bd00c")

