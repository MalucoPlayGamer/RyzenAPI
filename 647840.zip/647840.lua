-- Lua provided by RyzenAPI
-- Game: Ironclads 2: Caroline Islands War 1885

-- MAIN APPLICATION
addappid(647840)

-- MAIN APP DEPOTS / PACKAGES
addappid(647841,0,"71ca93d2aaba3cf7bff410a1a9e8f76547bb71d73c8f5b01be4cc2a97f4bd00c")

