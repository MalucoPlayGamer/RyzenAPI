-- Lua provided by RyzenAPI
-- Game: Alien Zombie Megadeath

-- MAIN APPLICATION
addappid(110610)

-- MAIN APP DEPOTS / PACKAGES
addappid(110611, 1, "9dfbbdf3b94a033f8c06787246f44c8d2ab9a132070410cf1074a672a53df870")
