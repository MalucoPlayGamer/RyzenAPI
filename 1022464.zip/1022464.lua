-- Lua provided by RyzenAPI
-- Game: 1022464

-- MAIN APPLICATION
addappid(1022464)
-- Game: addappid(1022464)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022464,0,"ae7be3d303b8235bb7b66ee6ee002cd53c0be7dcfe8f18f16132d2da093eded6")
