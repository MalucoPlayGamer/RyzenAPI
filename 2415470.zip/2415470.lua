-- Lua provided by RyzenAPI
-- Game: Thirty Days

-- MAIN APPLICATION
addappid(2415470)
-- Game: addappid(2415470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415471, 1, "fad4c94d5d94db6fdb6621f86ec57e99c8cf7847ee1adf637813d6bd5a48ca66")
