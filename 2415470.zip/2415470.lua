-- Lua provided by RyzenAPI 
-- Game: Thirty Days
addappid(2415470)
addappid(2415471, 1, "fad4c94d5d94db6fdb6621f86ec57e99c8cf7847ee1adf637813d6bd5a48ca66")
