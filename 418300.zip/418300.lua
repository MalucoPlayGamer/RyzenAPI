-- Lua provided by RyzenAPI
-- Game: Wick

-- MAIN APPLICATION
addappid(418300)
-- Game: addappid(418300)

-- MAIN APP DEPOTS / PACKAGES
addappid(418301, 1, "8bb09e7419495585645e48ad56a5165f87a6cccf26cc8d0f4b67c61b786f49ca")
addappid(418302, 1, "fdfc1c7f21b59b15f7f2afeeab6520256d78e6a46126d4153a699fb431b5d431")
