-- Lua provided by RyzenAPI
-- Game: Crudelis

-- MAIN APPLICATION
addappid(424010)
addappid(427790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(424011, 1, "8ded9d2c34e1cbc92c964bc90f5c3cf4229e0654c7ebb049e01e525ef77169a0")

