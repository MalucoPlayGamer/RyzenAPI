-- Lua provided by RyzenAPI
-- Game: Crudelis

-- MAIN APPLICATION
addappid(424010)
addappid(427790)
-- Game: addappid(424010)

-- MAIN APP DEPOTS / PACKAGES
addappid(424011, 1, "8ded9d2c34e1cbc92c964bc90f5c3cf4229e0654c7ebb049e01e525ef77169a0")
