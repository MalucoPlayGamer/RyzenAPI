-- Lua provided by RyzenAPI
-- Game: Knights of the Road

-- MAIN APPLICATION
addappid(2324390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324391, 1, "3f33c92a727bd946da14e1d377ddc268c2bf6e6261610bea0b231622fbbfb706")

