-- Lua provided by SkyAPI 
-- Game: AppID 1350470
addappid(1350470)
addappid(1350471, 1, "3b7f30b8802c20fa5bfdb64794ff19f4c71726b214a97e326bf1d362ad0f17a6")
