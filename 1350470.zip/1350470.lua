-- Lua provided by RyzenAPI
-- Game: addappid(1350470)

-- MAIN APPLICATION
addappid(1350470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350471, 1, "3b7f30b8802c20fa5bfdb64794ff19f4c71726b214a97e326bf1d362ad0f17a6")
