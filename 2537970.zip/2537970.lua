-- Lua provided by RyzenAPI
-- Game: Game: 莎比编辑器 SUBE

-- MAIN APPLICATION
addappid(2537970)
-- Game: addappid(2537970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537971, 1, "ce8b4fa1789b0a7ab441aec03a7be3c3a0d8f858fd52933440524c7d0c1c5a7c")
