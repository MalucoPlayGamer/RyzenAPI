-- Lua provided by RyzenAPI
-- Game: 莎比编辑器 SUBE

-- MAIN APPLICATION
addappid(2537970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537971, 1, "ce8b4fa1789b0a7ab441aec03a7be3c3a0d8f858fd52933440524c7d0c1c5a7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
