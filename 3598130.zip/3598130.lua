-- Lua provided by RyzenAPI
-- Game: 3598130

-- MAIN APPLICATION
addappid(3598130)
-- Game: addappid(3598130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3598131, 1, "56eac719157fc4e046db028572dcdfa51b67ed80c44354cfe5d6b6dfbbff667a")
