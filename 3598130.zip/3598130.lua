-- Lua provided by RyzenAPI
-- Game: Big Rigs: Over the Road Racing

-- MAIN APPLICATION
addappid(3598130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3598131, 1, "56eac719157fc4e046db028572dcdfa51b67ed80c44354cfe5d6b6dfbbff667a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3610200)
