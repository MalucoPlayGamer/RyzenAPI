-- Lua provided by RyzenAPI
-- Game: Reactor Tech²

-- MAIN APPLICATION
addappid(1444020)
-- Game: addappid(1444020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444021, 1, "52a5969d2ab6984b468a7a02f5531fce7b65f7f3f6256d7e2611752a1c09e6ba")
