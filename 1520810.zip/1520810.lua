-- Lua provided by RyzenAPI
-- Game: Flatline

-- MAIN APPLICATION
addappid(1520810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520811, 1, "b7e478969febf9f0f90a9221575bb3c8699643406e2cfc63e6d69db40e7492b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
