-- Lua provided by RyzenAPI
-- Game: Flatline

-- MAIN APPLICATION
addappid(1520810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520811, 1, "b7e478969febf9f0f90a9221575bb3c8699643406e2cfc63e6d69db40e7492b6")

