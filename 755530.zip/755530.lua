-- Lua provided by RyzenAPI
-- Game: Factorybelts 2

-- MAIN APPLICATION
addappid(755530)

-- MAIN APP DEPOTS / PACKAGES
addappid(755531,0,"093ad14d1850aad7547096d2fdfd2bb04e52b4eab7756ceab4cce96e25483a21")

