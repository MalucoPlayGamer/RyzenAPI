-- Lua provided by RyzenAPI
-- Game: Everquest: Underfoot

-- MAIN APPLICATION
addappid(24180)

-- MAIN APP DEPOTS / PACKAGES
addappid(24121,0,"35fcb8cb4fdec713121264246da4b225ecd790107db697df4ce07a20ac8753a1")

