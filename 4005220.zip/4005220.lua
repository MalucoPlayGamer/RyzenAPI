-- 4005220's Lua and Manifest Created by Hubcap Manifest
-- Deep Blue Sushi
-- Created: August 21, 2026 at 15:59:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4005220) -- Deep Blue Sushi
-- MAIN APP DEPOTS
addappid(4005221, 1, "a6d69f88f05a5cdd8e5a895a9bb7c771ddf8cb52bdd683b7042e95adbb945a1b") -- Depot 4005221
setManifestid(4005221, "6168536105599792731", 12186128350)