-- Lua provided by RyzenAPI
-- Game: Monster Tiles TD: Tower Wars

-- MAIN APPLICATION
addappid(2447060)
