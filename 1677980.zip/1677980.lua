-- Lua provided by RyzenAPI
-- Game: Unmatched: Digital Edition

-- MAIN APPLICATION
addappid(1677980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677981, 1, "99ca608474cf814129775af810c40c9656cc08c60209cb88b3deef09b202b87a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2006711)
addappid(2006712)
addappid(2006713)
addappid(2006714)
addappid(2006720)
addappid(2011620)
addappid(2011621)
addappid(2011622)
addappid(2011623)
addappid(2011624)
addappid(2011625)
addappid(2313510)
addappid(2313511)
addappid(2313512)
addappid(2325630)
addappid(4900910)
addappid(4900920)
