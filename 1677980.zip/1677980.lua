-- Lua provided by RyzenAPI
-- Game: Unmatched: Digital Edition

-- MAIN APPLICATION
addappid(1677980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677981, 1, "99ca608474cf814129775af810c40c9656cc08c60209cb88b3deef09b202b87a")

