-- Lua provided by RyzenAPI
-- Game: addappid(1368920)

-- MAIN APPLICATION
addappid(1368920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368920,0,"ad68647e0a401a6af4e3c2f4659cdb4fa639cd77d35a11e8466880a24471e687")
