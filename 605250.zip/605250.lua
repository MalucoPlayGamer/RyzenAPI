-- Lua provided by RyzenAPI
-- Game: Cluckles' Adventure

-- MAIN APPLICATION
addappid(605250)
addappid(615300)
-- Game: addappid(605250)

-- MAIN APP DEPOTS / PACKAGES
addappid(605251, 1, "d4c7e828a2fee201ad2a49a9f5f7c11135a504a1341589325e070e5a50790df7")
