-- Lua provided by RyzenAPI
-- Game: Game: bead

-- MAIN APPLICATION
addappid(659810)
-- Game: addappid(659810)

-- MAIN APP DEPOTS / PACKAGES
addappid(659811, 1, "b2d95fee576cdd3fb0cdba3d0a1642543ae83da0ad04e08e71570af65cf3bffe")
