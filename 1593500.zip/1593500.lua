-- Lua provided by RyzenAPI
-- Game: God of War

-- MAIN APPLICATION
addappid(1593500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593501, 1, "77f7390a115063bccc41240f71e0bf27d42c6a7c0424657756fe3f99f26a287a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
