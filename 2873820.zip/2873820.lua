-- Lua provided by RyzenAPI
-- Game: Game: AppID 2873820

-- MAIN APPLICATION
addappid(2873820)
-- Game: addappid(2873820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873821, 1, "2f18795a1358b5401aa775a297c88aeb9d101aa788bef17f0b3a13fb48ad9c48")
