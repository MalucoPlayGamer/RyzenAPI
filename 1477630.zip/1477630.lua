-- Lua provided by RyzenAPI
-- Game: Game: Swing Dunk

-- MAIN APPLICATION
addappid(1477630)
-- Game: addappid(1477630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477631, 1, "62feb9a5d4c2bd2b54916137fbe0d9340d2bf125199975cd40b176c89ec4ea91")
