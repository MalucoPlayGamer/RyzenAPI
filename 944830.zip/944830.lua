-- Lua provided by RyzenAPI
-- Game: Game: Swap Swap

-- MAIN APPLICATION
addappid(944830)
-- Game: addappid(944830)

-- MAIN APP DEPOTS / PACKAGES
addappid(944831, 1, "5a8e8f4f1f9abff7a218323f11bec2bb9bd9b5034d9c1296c1c58aa4b435fc51")
