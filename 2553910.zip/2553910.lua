-- Lua provided by RyzenAPI
-- Game: Amazing Grace -What color is your attribute?-

-- MAIN APPLICATION
addappid(2553910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553911, 1, "2834b771652b8e1a325032c96271bf3b78cf619767af52d68ea6bfd4fc3b889a")

