-- Lua provided by RyzenAPI
-- Game: The LEGO® Movie - Videogame

-- MAIN APPLICATION
addappid(267530)
addappid(272710)

-- MAIN APP DEPOTS / PACKAGES
addappid(267531, 1, "0b297c5aeb6e1e9201043c2ff63592f5ecd8a96380ae7e9141ca51a5eca54441")
addappid(267532, 1, "f29f049e71654ffeb9ccf535381e0d483f0a1e995b78c53faf30aafafbf39c79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
