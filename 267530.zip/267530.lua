-- Lua provided by RyzenAPI 
-- Game: The LEGO® Movie - Videogame
addappid(267530)
addappid(267531, 1, "0b297c5aeb6e1e9201043c2ff63592f5ecd8a96380ae7e9141ca51a5eca54441")
addappid(267532, 1, "f29f049e71654ffeb9ccf535381e0d483f0a1e995b78c53faf30aafafbf39c79")
addappid(272710)
