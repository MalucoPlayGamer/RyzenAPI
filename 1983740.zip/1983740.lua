-- Lua provided by RyzenAPI
-- Game: Cryptid Coffeehouse

-- MAIN APPLICATION
addappid(1983740)
