-- Lua provided by RyzenAPI
-- Game: Cryptid Coffeehouse

-- MAIN APPLICATION
addappid(1983740)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4695810)
