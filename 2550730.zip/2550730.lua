-- Lua provided by SkyAPI 
-- Game: 勇者屠龙 之 永恒幻想
addappid(2550730)
addappid(2550731, 1, "fcc8257968cabf6b76f30d21bee84d2fc7f55cef583a7681af9f4f9aac29a663")
