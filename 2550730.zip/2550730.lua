-- Lua provided by RyzenAPI
-- Game: 勇者屠龙 之 永恒幻想

-- MAIN APPLICATION
addappid(2550730)
-- Game: addappid(2550730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550731, 1, "fcc8257968cabf6b76f30d21bee84d2fc7f55cef583a7681af9f4f9aac29a663")
