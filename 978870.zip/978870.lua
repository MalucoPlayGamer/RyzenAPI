-- Lua provided by RyzenAPI
-- Game: 978870

-- MAIN APPLICATION
addappid(978870)
-- Game: addappid(978870)

-- MAIN APP DEPOTS / PACKAGES
addappid(978871, 1, "669490d41ad5d6500f220884fefd6ba8a0cfb02ae311dd00fe854ac9394102ab")
