-- Lua provided by RyzenAPI 
-- Game: AppID 748760
addappid(748760)
addappid(748761, 1, "1ca059bd6c76d4b60e5ceb3288e4ca9974b0e4c894025a93e10844927d1144b2")
