-- Lua provided by RyzenAPI
-- Game: AppID 327980

-- MAIN APPLICATION
addappid(327980)

-- MAIN APP DEPOTS / PACKAGES
addappid(327981, 1, "4bb64be87aaca208b3e69377666d11754dc00a12375d42992f407d96362d99e6")
addappid(327982, 1, "61aa2d15f3071921609082ab63ac31c17434eec82a6421ee30f946042488407a")
addappid(327983, 1, "f55aa955592064e342fe2ad156a9d4713b8268941765a7b17580c2976297b5cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
