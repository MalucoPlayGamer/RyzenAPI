-- Lua provided by RyzenAPI
-- Game: 懒人修仙传2

-- MAIN APPLICATION
addappid(1266630)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1266631, 1, "b8d09177a277d4ada7e54654ddd8b634bad67d2f79f86e409895f13227731986")

