-- Lua provided by RyzenAPI
-- Game: Lots of Cats in Every Moment

-- MAIN APPLICATION
addappid(3080240)
