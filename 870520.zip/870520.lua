-- Lua provided by RyzenAPI
-- Game: addappid(870520)

-- MAIN APPLICATION
addappid(870520)

-- MAIN APP DEPOTS / PACKAGES
addappid(870521, 1, "ddea58c799d1264eda65839c5ba826555ccc98e892694642edb33dd8402929e7")
