-- Lua provided by RyzenAPI
-- Game: 太平洋之嵐6 ～ 史上最大的激戰諾曼第攻防戰! Pacific Storm 6 - Battle for Normandy

-- MAIN APPLICATION
addappid(870520)

-- MAIN APP DEPOTS / PACKAGES
addappid(870521, 1, "ddea58c799d1264eda65839c5ba826555ccc98e892694642edb33dd8402929e7")
