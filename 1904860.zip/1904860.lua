-- Lua provided by RyzenAPI
-- Game: Legends of Kingdom Rush

-- MAIN APPLICATION
addappid(1904860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904861, 1, "b379a969a4e62c36ab125ebb98b3244cfb4a9f7d2620f2f25030130208ad1078")
addappid(1904862, 1, "ce2749ccaad1c0b1e73c94d7547964a6480921deea5a61843ee360b380e67f13")

