-- Lua provided by RyzenAPI
-- Game: AppID 280010

-- MAIN APPLICATION
addappid(280010)
-- Game: addappid(280010)

-- MAIN APP DEPOTS / PACKAGES
addappid(280011, 1, "4dfc825c49ec3f6cecedaf3269c80dd037a63fc34b18d85d5e6ae60e4f9366a6")
addappid(280012, 1, "da05407405ab7cb7f3e474a11f52b69b13f71f111544eb48a08b278cf119b796")
