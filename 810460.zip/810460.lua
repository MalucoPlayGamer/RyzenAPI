-- Lua provided by RyzenAPI
-- Game: addappid(810460)

-- MAIN APPLICATION
addappid(810460)

-- MAIN APP DEPOTS / PACKAGES
addappid(810461, 1, "33cf13282ccf28dd979ddadd1e975f7644c7a0b53e4e86da8793e03f79efd78e")
