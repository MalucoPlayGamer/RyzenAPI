-- Lua provided by RyzenAPI
-- Game: Game: AppID 2789700

-- MAIN APPLICATION
addappid(2789700)
-- Game: addappid(2789700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789701, 1, "a29c0a87d05bf4a573706838cce810fa7d63eefd0f8d0b453b0d1fd0622a00d5")
