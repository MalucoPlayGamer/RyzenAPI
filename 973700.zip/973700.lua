-- Lua provided by RyzenAPI
-- Game: Disassembly VR

-- MAIN APPLICATION
addappid(973700)

-- MAIN APP DEPOTS / PACKAGES
addappid(973701, 1, "fdee0b71ffb7f6920e0ea195d2758560b7506fcdf9627f0789b97fa502fe60a8")
