-- Lua provided by SkyAPI 
-- Game: Disassembly VR
addappid(973700)
addappid(973701, 1, "fdee0b71ffb7f6920e0ea195d2758560b7506fcdf9627f0789b97fa502fe60a8")
