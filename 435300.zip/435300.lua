-- Lua provided by RyzenAPI
-- Game: We Know the Devil

-- MAIN APPLICATION
addappid(435300)
-- Game: addappid(435300)

-- MAIN APP DEPOTS / PACKAGES
addappid(435301, 1, "13a95fd4d1ff663ed3a6779529b9035415ff55da3f6a7859418ad29ee731515f")
addappid(435302, 1, "8fafc0ff4c2da211fad5f193542b3dfbc0161c373bd98a0a1dd931cf72039a8e")
