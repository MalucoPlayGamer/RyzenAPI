-- Lua provided by RyzenAPI
-- Game: Game: Cannons-Defenders: Steam Edition

-- MAIN APPLICATION
addappid(617710)
-- Game: addappid(617710)

-- MAIN APP DEPOTS / PACKAGES
addappid(617711, 1, "4525f384b8c95d6f5d4c60f6709979bbf7f73a916e67f97d47255a4470a7f25f")
