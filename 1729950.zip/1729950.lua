-- Lua provided by RyzenAPI
-- Game: 1729950

-- MAIN APPLICATION
addappid(1729950)
addappid(1729951)
-- Game: addappid(1729950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733870,0,"91baa4b22eeecd3425ade6a223c5ea6955a71e03d05a304800cc6ec294ac2066")
