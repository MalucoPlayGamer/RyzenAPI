-- Lua provided by RyzenAPI
-- Game: Trace Vector

-- MAIN APPLICATION
addappid(297410)
-- Game: addappid(297410)

-- MAIN APP DEPOTS / PACKAGES
addappid(297411, 1, "75eb1b9a0965cafde181916cfdcf0dcdcffe63450d7d477b1b3536883ca83aad")
addappid(297412, 1, "d11dfada7cb20321aad15d7cb0ab3d63efdcb247b45c1547275ffee8f85c47ef")
addappid(297413, 1, "8fd46fd7bed7a83d412c00613aa0f1b9ca53f825dafbafb9f1fa1639580f630f")
addappid(311460, 0, "230cab587d7ef3644466584145fe776efa0a59f2155fee971a66ed8546d46cbe")
