-- Lua provided by RyzenAPI
-- Game: Caladrius Blaze

-- MAIN APPLICATION
addappid(386770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(386771, 1, "6d593cbf6fae8a644dfffa89f4d73a50e1d9a2f42b63be3a3faa53743108cc0e")
