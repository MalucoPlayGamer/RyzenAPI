-- Lua provided by RyzenAPI
-- Game: AppID 386770

-- MAIN APPLICATION
addappid(386770)

-- MAIN APP DEPOTS / PACKAGES
addappid(386771, 1, "6d593cbf6fae8a644dfffa89f4d73a50e1d9a2f42b63be3a3faa53743108cc0e")
