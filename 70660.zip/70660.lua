-- Lua provided by SkyAPI 
-- Game: Worms Pinball
addappid(70660)
addappid(70661, 1, "c3e3a4acaa46325146739ee060efd5043ac4e00112b74ccef3f0caef8c7463e7")
