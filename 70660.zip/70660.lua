-- Lua provided by RyzenAPI
-- Game: Game: Worms Pinball

-- MAIN APPLICATION
addappid(70660)
-- Game: addappid(70660)

-- MAIN APP DEPOTS / PACKAGES
addappid(70661, 1, "c3e3a4acaa46325146739ee060efd5043ac4e00112b74ccef3f0caef8c7463e7")
