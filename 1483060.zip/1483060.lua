-- Lua provided by RyzenAPI
-- Game: addappid(1483060)

-- MAIN APPLICATION
addappid(1483060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483061, 1, "de3aae247cbde46a36c9207712176733a1bd39f434177a29f44c31e3f60b138a")
