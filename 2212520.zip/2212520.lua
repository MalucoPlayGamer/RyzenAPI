-- Lua provided by RyzenAPI
-- Game: 2212520

-- MAIN APPLICATION
addappid(2212520)
addappid(4041670)
-- Game: addappid(2212520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2212521, 1, "75a52130ec7082aa488806c2243c65ddd6e4fa8fde5bd11a6104e9d5c79b2da0")
