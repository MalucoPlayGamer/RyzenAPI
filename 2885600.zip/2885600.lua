-- Lua provided by RyzenAPI
-- Game: 2885600

-- MAIN APPLICATION
addappid(2885600)
-- Game: addappid(2885600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885601, 1, "72460fbe5b03c99f9072023215f687fffb970cce64fac386f5f8c8181505f7c1")
