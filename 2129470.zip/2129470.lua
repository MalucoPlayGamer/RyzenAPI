-- Lua provided by RyzenAPI
-- Game: Knights of Pen and Paper 3

-- MAIN APPLICATION
addappid(2129470)
-- Game: addappid(2129470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129471, 1, "cb067af53a9a55e38a3bac87a18c52885913d9bb7520d779c34bf833018741c0")
