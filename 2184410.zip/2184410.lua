-- Lua provided by RyzenAPI
-- Game: addappid(2184410)

-- MAIN APPLICATION
addappid(2184410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184411, 1, "611bded0ee2f7eb0a3d4a49c9c28f01612d4d175c0f9e03a017fd88eb515c85a")
