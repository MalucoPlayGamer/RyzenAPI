-- 4212530's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Yumi is streaming
-- Created: June 18, 2026 at 05:25:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4212530) -- Hentai Clicker: Yumi is streaming
-- MAIN APP DEPOTS
addappid(4212531, 1, "d98bc1faaf5d6200a445c912d56703dc819b79606c6bdae776c73e4ddb12a2f3") -- Depot 4212531
setManifestid(4212531, "4883985996826971798", 176003551)