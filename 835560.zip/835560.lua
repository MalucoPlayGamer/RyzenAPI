-- Lua provided by RyzenAPI
-- Game: Game: Ancient Rush 2

-- MAIN APPLICATION
addappid(835560)
-- Game: addappid(835560)

-- MAIN APP DEPOTS / PACKAGES
addappid(835561, 1, "9924be2513da1afa1063e7cc2ee8d499f7ea280c7ceeaf4109b23583c342f3f5")
