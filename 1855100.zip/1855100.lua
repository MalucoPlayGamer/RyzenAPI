-- Lua provided by RyzenAPI
-- Game: 1855100

-- MAIN APPLICATION
addappid(1855100)
-- Game: addappid(1855100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855101, 1, "a0ece4af353634b43aa0dd8b09a07bf77c6b2a32ad791c45d310cc564caa8461")
