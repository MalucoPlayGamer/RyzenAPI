-- Lua provided by RyzenAPI
-- Game: Dog Adventure

-- MAIN APPLICATION
addappid(1855100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1855101, 1, "a0ece4af353634b43aa0dd8b09a07bf77c6b2a32ad791c45d310cc564caa8461")

