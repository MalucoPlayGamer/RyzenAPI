-- Lua provided by RyzenAPI
-- Game: 1219120

-- MAIN APPLICATION
addappid(1219120)
-- Game: addappid(1219120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219121, 1, "eaef335b47a1f539319321d9cc3dc7386691a471d0172fa501bce183de625f12")
