-- Lua provided by RyzenAPI
-- Game: RETRO-PIXEL COLOR PALETTE: Color by Number

-- MAIN APPLICATION
addappid(1219120)
addappid(1220210)
addappid(1225800)
addappid(1226720)
addappid(1230630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219121, 1, "eaef335b47a1f539319321d9cc3dc7386691a471d0172fa501bce183de625f12")

