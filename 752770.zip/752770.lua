-- Lua provided by RyzenAPI
-- Game: GyroShooter

-- MAIN APPLICATION
addappid(752770)

-- MAIN APP DEPOTS / PACKAGES
addappid(752771,0,"9b0b992a211c442abde64c2e7717f0521527953160f31880244a26f0204a1258")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
