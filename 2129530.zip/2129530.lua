-- Lua provided by RyzenAPI 
-- Game: REANIMAL
addappid(2129530)
addappid(2129531, 1, "8c619e3fd74002747f22974390275782dc2b568bc92b52859f0c5688a4a663f7")
addappid(3954470)
addappid(4112550)
addappid(4351720, 0, "6dba1be22c2161793226a2567e1ab5d6f153799494d7b26684d00e692ec041be")
