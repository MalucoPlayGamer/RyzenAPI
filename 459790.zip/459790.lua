-- Lua provided by RyzenAPI
-- Game: NEKOPARA Vol. 1 - Theme Song

-- MAIN APPLICATION
addappid(459790)
-- Game: addappid(459790)

-- MAIN APP DEPOTS / PACKAGES
addappid(459798,0,"d77381f4b9f74e0e8f939d3a53d057072f98f4184ec005325fc3b2377a2d8cec")
addappid(459799,0,"89f5b106b7c98f21c17818f2abf82b1111e634feeb6bd449554b4b000d9ddeb3")
