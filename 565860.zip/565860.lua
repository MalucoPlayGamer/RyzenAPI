-- Lua provided by RyzenAPI
-- Game: Tomato Way

-- MAIN APPLICATION
addappid(565860)
-- Game: addappid(565860)

-- MAIN APP DEPOTS / PACKAGES
addappid(565861, 1, "7ad49c5976269a684f943f106056d0c0a1968a75826a46bc5348543cb4fa54e0")
