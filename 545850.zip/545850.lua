-- Lua provided by RyzenAPI
-- Game: Shady Brook - A Dark Mystery Text Adventure

-- MAIN APPLICATION
addappid(545850)

-- MAIN APP DEPOTS / PACKAGES
addappid(545851, 1, "31f6a62ed069cfd9df862c2736061e04cb9c833df4e969d1f67647b361219af7")

