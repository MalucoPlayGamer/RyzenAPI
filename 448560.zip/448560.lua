-- Lua provided by SkyAPI 
-- Game: Mind Games
addappid(448560)
addappid(448561, 1, "4842252941384a444aac92f389889b4b466470f62d6ba3230efdb870e65bb762")
addappid(448562, 1, "d90e5a1d83bf02cc3a4ee22ada084d4a1a4eb7eb1cf65c7c5d2be874e307a947")
addappid(448563, 1, "5340b7203c3113fc5fc76da1fc5bde959dffa6a66bb9215d8e3d0e96a1fcf27b")
