-- Lua provided by RyzenAPI
-- Game: Mind Games

-- MAIN APPLICATION
addappid(448560)

-- MAIN APP DEPOTS / PACKAGES
addappid(448561, 1, "4842252941384a444aac92f389889b4b466470f62d6ba3230efdb870e65bb762")
addappid(448562, 1, "d90e5a1d83bf02cc3a4ee22ada084d4a1a4eb7eb1cf65c7c5d2be874e307a947")
addappid(448563, 1, "5340b7203c3113fc5fc76da1fc5bde959dffa6a66bb9215d8e3d0e96a1fcf27b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
