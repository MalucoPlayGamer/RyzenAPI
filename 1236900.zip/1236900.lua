-- Lua provided by RyzenAPI
-- Game: Verdant Village

-- MAIN APPLICATION
addappid(1236900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1236901, 1, "5871379e2e3a50acc017076a3e123c213811da56ec84e862d9f73e872f38d367")

