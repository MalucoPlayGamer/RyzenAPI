-- Lua provided by RyzenAPI
-- Game: Game: AppID 1236900

-- MAIN APPLICATION
addappid(1236900)
-- Game: addappid(1236900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236901, 1, "5871379e2e3a50acc017076a3e123c213811da56ec84e862d9f73e872f38d367")
