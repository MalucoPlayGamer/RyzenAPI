-- Lua provided by RyzenAPI
-- Game: Game: Dream City

-- MAIN APPLICATION
addappid(3042840)
-- Game: addappid(3042840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042841, 1, "d477984eb2361b6d1706cb28ddcf9a13f1e2e1df6a1c6bc5736146787095ac6b")
