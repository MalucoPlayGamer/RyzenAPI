-- Lua provided by RyzenAPI
-- Game: addappid(1482640)

-- MAIN APPLICATION
addappid(1482640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482641, 1, "d4222a28dc590666da199dc68dce1e0220d91ac792dfb71ac9c203eb43ddb2f2")
