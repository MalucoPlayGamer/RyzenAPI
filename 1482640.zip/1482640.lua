-- Lua provided by RyzenAPI
-- Game: Nurose

-- MAIN APPLICATION
addappid(1482640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1482641, 1, "d4222a28dc590666da199dc68dce1e0220d91ac792dfb71ac9c203eb43ddb2f2")

