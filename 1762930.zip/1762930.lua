-- Lua provided by RyzenAPI
-- Game: Goat Simulator: Remastered

-- MAIN APPLICATION
addappid(1762930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762931, 1, "612ee27641d14fa8b5a84c3aa603d8f3bd28a1228ea0dc1bd92bb2339df8cef7")

