-- Lua provided by RyzenAPI 
-- Game: Goat Simulator: Remastered
addappid(1762930)
addappid(1762931, 1, "612ee27641d14fa8b5a84c3aa603d8f3bd28a1228ea0dc1bd92bb2339df8cef7")
