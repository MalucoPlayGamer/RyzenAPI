-- Lua provided by RyzenAPI
-- Game: Goat Simulator: Remastered

-- MAIN APPLICATION
addappid(1762930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762931, 1, "612ee27641d14fa8b5a84c3aa603d8f3bd28a1228ea0dc1bd92bb2339df8cef7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
