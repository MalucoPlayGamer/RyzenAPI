-- Lua provided by RyzenAPI 
-- Game: Epicenter VR
addappid(1887760)
addappid(1887761, 1, "a94edab3e94f90d177a4c14c0728b69e380606c1291aa56d89e4f4516abf5913")
