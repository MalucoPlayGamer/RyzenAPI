-- Lua provided by RyzenAPI
-- Game: Game: Epicenter VR

-- MAIN APPLICATION
addappid(1887760)
-- Game: addappid(1887760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887761, 1, "a94edab3e94f90d177a4c14c0728b69e380606c1291aa56d89e4f4516abf5913")
