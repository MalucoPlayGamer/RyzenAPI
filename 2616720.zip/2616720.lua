-- Lua provided by RyzenAPI
-- Game: GESTALT: The Fifth Day

-- MAIN APPLICATION
addappid(2616720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616724,0,"7339bf1c17f0ae5a2d858f7a174d10964fffdbcbe31b59c7bad9ac8daf28f8a0")
addappid(2616727,0,"84fcec0f52bdf333fe86df4f3a752fde75c7720fabc1c31fe78edaf767c706b7")
