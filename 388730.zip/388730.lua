-- Lua provided by RyzenAPI 
-- Game: AppID 388730
addappid(388730)
addappid(388731, 1, "c7fec08f30374fada803e7b1e0312c43e2d61bb469952e5a7c69634d38d6aa0c")
