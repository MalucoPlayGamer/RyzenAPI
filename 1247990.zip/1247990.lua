-- Lua provided by RyzenAPI 
-- Game: AppID 1247990
addappid(1247990)
addappid(1247991, 1, "fdd9813f85b0636a2841e7bedbfa427f907703f7e0099909f66c68607c538b4e")
