-- Lua provided by RyzenAPI
-- Game: Game: AppID 1247990

-- MAIN APPLICATION
addappid(1247990)
-- Game: addappid(1247990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247991, 1, "fdd9813f85b0636a2841e7bedbfa427f907703f7e0099909f66c68607c538b4e")
