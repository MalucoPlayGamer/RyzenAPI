-- Lua provided by RyzenAPI
-- Game: Waifu Aim Trainer

-- MAIN APPLICATION
addappid(3217380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3217381, 1, "cfe7ba544dc5f6b6be82cd999ed7db868c9dd7069487a6947b059e3f66370ddc")

