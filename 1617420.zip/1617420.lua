-- Lua provided by RyzenAPI
-- Game: Logistics Simulator

-- MAIN APPLICATION
addappid(1617420)
-- Game: addappid(1617420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617421, 1, "b85126bb785516154da36faf11cfb4dc862e65c2bf05eac0d3abf17db9990782")
