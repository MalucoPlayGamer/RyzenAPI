-- Lua provided by RyzenAPI
-- Game: Trans Ops - Transitional Operations

-- MAIN APPLICATION
addappid(2450240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450241, 1, "fc99a4b525def7913ff70fbb3ee251238fa226756817665cea152184d925a883")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
