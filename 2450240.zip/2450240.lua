-- Lua provided by RyzenAPI
-- Game: Trans Ops - Transitional Operations

-- MAIN APPLICATION
addappid(2450240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450241, 1, "fc99a4b525def7913ff70fbb3ee251238fa226756817665cea152184d925a883")

