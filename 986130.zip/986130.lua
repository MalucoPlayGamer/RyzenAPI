-- Lua provided by SkyAPI 
-- Game: Shadows of Doubt
addappid(986130)
addappid(986131, 1, "dc54e19011f6a1e01179024b4bc2924a39fea01c682a31bd460075bb7882ab34")
addappid(3229880, 0, "e15b606fff7e6421b843b4c26b2127e49b7e36af9c5e94f0367a5698b77a636a")
