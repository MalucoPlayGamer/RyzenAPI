-- Lua provided by RyzenAPI
-- Game: Barrok

-- MAIN APPLICATION
addappid(3114860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114861, 1, "176d97b332f6a1ef837d17b3f314e64db50f665b5eeed8fae4a219f1a4a4cb01")
