-- Lua provided by RyzenAPI
-- Game: Game: Sanguine Rose

-- MAIN APPLICATION
addappid(1243420)
-- Game: addappid(1243420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243421, 1, "f449ff7cf8b33d9706d3865df51b6bb67cedded663511f39e5d10a9e3a6c3e74")
