-- Lua provided by RyzenAPI
-- Game: Hot And Lovely 2

-- MAIN APPLICATION
addappid(1256690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256691, 1, "a07b349d44dd90e6f1751202133d1b9ca645c558e9fc38f7d59ee3f9c691f919")
addappid(1270240, 0, "d4e0d3415af2d4b1308f8ec65a395eaa05af88a39864db0a14b798a6cd5fbef9")

