-- Lua provided by RyzenAPI
-- Game: Good puzzle: Castles

-- MAIN APPLICATION
addappid(1455090)
addappid(1469730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455091, 1, "8eab040eadf6ba81ee05113c4e2dea4da6b0272a67bae2e167d73ac7c9573c04")
