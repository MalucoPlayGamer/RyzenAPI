-- Lua provided by RyzenAPI
-- Game: 337670

-- MAIN APPLICATION
addappid(337670)
-- Game: addappid(337670)

-- MAIN APP DEPOTS / PACKAGES
addappid(337671, 1, "94995733948eb27f609dc314b8017293610af0d5a7ab5da8bce49556cf6da6d2")
