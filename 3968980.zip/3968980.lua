-- Lua provided by RyzenAPI
-- Game: Heavenly Guitars

-- MAIN APPLICATION
addappid(3968980)
