-- Lua provided by RyzenAPI
-- Game: Settled

-- MAIN APPLICATION
addappid(445750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(445751, 1, "0b9b31aa438985d8a5629201cad7a737daea0bb98ec38bbcb2a43e4594618c30")

