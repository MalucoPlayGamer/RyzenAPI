-- Lua provided by RyzenAPI
-- Game: AppID 445750

-- MAIN APPLICATION
addappid(445750)
-- Game: addappid(445750)

-- MAIN APP DEPOTS / PACKAGES
addappid(445751, 1, "0b9b31aa438985d8a5629201cad7a737daea0bb98ec38bbcb2a43e4594618c30")
