-- Lua provided by RyzenAPI
-- Game: AKAZU Off limits

-- MAIN APPLICATION
addappid(2848610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848611, 1, "760ef05aa76a70c0f0ba49e1cc79ea50415e06de07193f29d8e2cc730f24596c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
