-- Lua provided by RyzenAPI 
-- Game: AKAZU Off limits
addappid(2848610)
addappid(2848611, 1, "760ef05aa76a70c0f0ba49e1cc79ea50415e06de07193f29d8e2cc730f24596c")
