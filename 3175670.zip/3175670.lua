-- Lua provided by RyzenAPI
-- Game: Defense Builder

-- MAIN APPLICATION
addappid(3175670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175671, 1, "2cdbff526a6a1f6f52e680afd6d910b3e83895cde454ed5ace37f46dd0063e78")
