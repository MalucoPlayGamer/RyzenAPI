-- Lua provided by RyzenAPI
-- Game: Hacker Man

-- MAIN APPLICATION
addappid(1957240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957241, 1, "5e25330e3d92fe969dfa18cf62307b7389d34c968347703f18dea626fbcca72c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
