-- Lua provided by RyzenAPI 
-- Game: Hacker Man
addappid(1957240)
addappid(1957241, 1, "5e25330e3d92fe969dfa18cf62307b7389d34c968347703f18dea626fbcca72c")
