-- Lua provided by RyzenAPI
-- Game: Mr. Prepper Demo

-- MAIN APPLICATION
addappid(1322840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322841, 1, "e122d108ed686b9a398d83108016e221bf0165864eaf351e8d539da23e5adfb3")
