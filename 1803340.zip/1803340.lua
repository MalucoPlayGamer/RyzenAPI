-- Lua provided by RyzenAPI
-- Game: 山：临界幸存者 试玩版

-- MAIN APPLICATION
addappid(1803340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803341, 1, "b09d4d1f8df5104b570755e62e47618f5d285a442568ddf98b6002a875791e94")
