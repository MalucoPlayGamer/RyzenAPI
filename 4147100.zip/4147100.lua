-- Lua provided by RyzenAPI
-- Game: Knights of Fiona

-- MAIN APPLICATION
addappid(4147100) -- Knights of Fiona
addappid(4634830) -- Knights of Fiona - Story Pass

-- MAIN APP DEPOTS / PACKAGES
addappid(4147101, 1, "5dbb3863565a0d62f2b592365ebe13f79139108d8656a6936cc5c248e82e9cdc") -- Depot 4147101

