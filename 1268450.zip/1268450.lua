-- Lua provided by RyzenAPI
-- Game: addappid(1268450)

-- MAIN APPLICATION
addappid(1268450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268452,0,"f26bbf5b350a8162789d764de40225972cba1d8aa724d4b0dc0690d881bbb218")
