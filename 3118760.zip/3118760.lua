-- Lua provided by RyzenAPI
-- Game: 3118760

-- MAIN APPLICATION
addappid(3118760)
-- Game: addappid(3118760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118761, 1, "f59a5714b31baf3154cb928e0ee1b50767644e8b753111883b5b765a6abd6faa")
