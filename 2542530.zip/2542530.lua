-- Lua provided by RyzenAPI 
-- Game: Waking Up: Way Back Home
addappid(2542530)
addappid(2542531, 1, "bc487344f0446e8e3ebc0f779887f0e0b95834661212d602564a3cf8fd9020e5")
addappid(2542532, 1, "e781b1b6425ff3d154ae64b8b0d36657948e45b96c26ea9c442478199cc78458")
addappid(2542533, 1, "80b26ab96c98ac5b1709ed5ef2bb3b8e5830f2c452ab6c639cacaecef4231af5")
