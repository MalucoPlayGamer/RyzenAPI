-- Lua provided by RyzenAPI
-- Game: addappid(2052040)

-- MAIN APPLICATION
addappid(2052040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052041, 1, "c74ccfb10c89445ff894aa81581e2be00bd9dd819acf8033ab3131e2517c933b")
