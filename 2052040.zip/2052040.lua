-- Lua provided by SkyAPI 
-- Game: Golden Lap
addappid(2052040)
addappid(2052041, 1, "c74ccfb10c89445ff894aa81581e2be00bd9dd819acf8033ab3131e2517c933b")
