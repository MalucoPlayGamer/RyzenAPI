-- Lua provided by RyzenAPI
-- Game: Golden Lap

-- MAIN APPLICATION
addappid(2052040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052041, 1, "c74ccfb10c89445ff894aa81581e2be00bd9dd819acf8033ab3131e2517c933b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
