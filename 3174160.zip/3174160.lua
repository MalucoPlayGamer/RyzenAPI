-- Lua provided by SkyAPI 
-- Game: Paws and Whiskers
addappid(3174160)
addappid(3174161, 1, "fb97c1a6e7432638f9efa539bdcb582ae38c0c0e8e0e0771e571a4f34a48e666")
