-- Lua provided by RyzenAPI
-- Game: Paws and Whiskers

-- MAIN APPLICATION
addappid(3174160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174161, 1, "fb97c1a6e7432638f9efa539bdcb582ae38c0c0e8e0e0771e571a4f34a48e666")

