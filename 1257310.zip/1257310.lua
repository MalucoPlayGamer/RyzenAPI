-- Lua provided by RyzenAPI
-- Game: Game: AppID 1257310

-- MAIN APPLICATION
addappid(1257310)
-- Game: addappid(1257310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257311, 1, "6cc79864e94d06035d073b17d5afeefbd53cf04c976d26ab69c254347605f605")
