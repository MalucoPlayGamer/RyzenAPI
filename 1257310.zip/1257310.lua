-- Lua provided by RyzenAPI
-- Game: AppID 1257310

-- MAIN APPLICATION
addappid(1257310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257311, 1, "6cc79864e94d06035d073b17d5afeefbd53cf04c976d26ab69c254347605f605")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
