-- Lua provided by RyzenAPI
-- Game: addappid(1022474)

-- MAIN APPLICATION
addappid(1022474)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022474,0,"4da27c1f0c2e65a700d7d159724944d5aba5d209cc0bd7704c7d3f737044063a")
