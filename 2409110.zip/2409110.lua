-- Lua provided by RyzenAPI
-- Game: REAL WEB LEGENDS: Carter's Quest

-- MAIN APPLICATION
addappid(2409110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409111, 1, "f847d0a0213066560df5579ef6140e78b37ccd9fc1a0464b1d008bb347aab18b")
