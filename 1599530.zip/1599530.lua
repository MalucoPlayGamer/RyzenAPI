-- Lua provided by RyzenAPI
-- Game: Little adventure

-- MAIN APPLICATION
addappid(1599530)
-- Game: addappid(1599530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599531, 1, "b746ab8ecb93dac187df6608f71ab1e3e85d183962778c0f6f900bc3848fbd99")
