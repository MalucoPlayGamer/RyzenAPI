-- Lua provided by RyzenAPI
-- Game: Ultimate General: Civil War

-- MAIN APPLICATION
addappid(502520)

-- MAIN APP DEPOTS / PACKAGES
addappid(502521, 1, "ad4835ef3ca4b2ab3c10eb9165897f84b2d1493b75a5393b7c1c1d64d7649f60")
addappid(502522, 1, "e81a439c2c75ffba417730ee765cce28248aaf092bebd116e95768d7f3094f15")
