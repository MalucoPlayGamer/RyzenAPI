-- Lua provided by RyzenAPI
-- Game: addappid(3399980)

-- MAIN APPLICATION
addappid(3399980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399981, 1, "033792c34fce9da2dbe13712b99da37c120f407ea4b0149df792101a538fe95a")
