-- Lua provided by RyzenAPI
-- Game: 394260

-- MAIN APPLICATION
addappid(394260)
-- Game: addappid(394260)

-- MAIN APP DEPOTS / PACKAGES
addappid(394261, 1, "37cb86fdae38df4bc216a79dde8830e43d8f9e7b9de936d9c0f0332ee9633eba")
