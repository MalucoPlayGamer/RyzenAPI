-- Lua provided by RyzenAPI
-- Game: Dance Magic

-- MAIN APPLICATION
addappid(394260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(394261, 1, "37cb86fdae38df4bc216a79dde8830e43d8f9e7b9de936d9c0f0332ee9633eba")
