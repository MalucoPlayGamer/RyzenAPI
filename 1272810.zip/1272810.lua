-- Lua provided by RyzenAPI
-- Game: 1272810

-- MAIN APPLICATION
addappid(1272810)
-- Game: addappid(1272810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272811, 1, "0abbbc7f9cae255275ddf448f8ab3d1208f0ca7418ce248c829ab1f77fba1cc8")
addappid(1272812, 1, "bf12088bc03fef2b0b9c1795e6055e1ece33819fb3954133a98cecad20b116de")
