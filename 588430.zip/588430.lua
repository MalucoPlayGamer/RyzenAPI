-- Lua provided by RyzenAPI
-- Game: Fallout Shelter

-- MAIN APPLICATION
addappid(588430)
addappid(615510)
addappid(617490)
addappid(617500)
addappid(617510)
addappid(617520)
addappid(617530)

-- MAIN APP DEPOTS / PACKAGES
addappid(588431,0,"81d996a10800cbb00139fb9543976314983bc892251111299329bbf277e87865")
addappid(588432,0,"8716ccb13bc85d5d209f9f7614e6d6bb3ae06667410c7cea5192234273f94c0f")

