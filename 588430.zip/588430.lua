-- Lua provided by RyzenAPI 
-- Game: Fallout Shelter
addappid(588430)
addappid(588431, 1, "81d996a10800cbb00139fb9543976314983bc892251111299329bbf277e87865")
addappid(588432, 1, "8716ccb13bc85d5d209f9f7614e6d6bb3ae06667410c7cea5192234273f94c0f")
