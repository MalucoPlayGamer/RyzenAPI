-- Lua provided by RyzenAPI
-- Game: addappid(1594340)

-- MAIN APPLICATION
addappid(1594340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594341, 1, "87a98d607692c08f796ef1f7c217f8884a6a79b6eea71f8419b22efd2a3d720d")
addappid(1594342, 1, "e41be7b513b33b5d8ba09d77cbcac6106b6f9cd245addf848b69b62577691c4e")
