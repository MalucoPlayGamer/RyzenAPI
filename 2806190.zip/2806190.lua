-- Lua provided by RyzenAPI
-- Game: Game: Loopstructor Demo

-- MAIN APPLICATION
addappid(2806190)
-- Game: addappid(2806190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806191, 1, "d08747dac1a98674298b229ad25396a7fc956b822fb35ffc1567146cc757fd9d")
