-- Lua provided by RyzenAPI 
-- Game: Loopstructor Demo
addappid(2806190)
addappid(2806191, 1, "d08747dac1a98674298b229ad25396a7fc956b822fb35ffc1567146cc757fd9d")
