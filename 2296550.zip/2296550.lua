-- Lua provided by RyzenAPI
-- Game: 2296550

-- MAIN APPLICATION
addappid(2296550)
-- Game: addappid(2296550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296551, 1, "994797aef82fe80d6f97c48f11ecd3692850bd111ad65296b834eac1a5ee6391")
