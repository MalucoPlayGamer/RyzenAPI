-- Lua provided by RyzenAPI 
-- Game: Axon TD: Uprising - Tower Defense
addappid(2296550)
addappid(2296551, 1, "994797aef82fe80d6f97c48f11ecd3692850bd111ad65296b834eac1a5ee6391")
