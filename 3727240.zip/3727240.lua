-- Lua provided by RyzenAPI
-- Game: Poker Adventurers

-- MAIN APPLICATION
addappid(3727240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3727241, 1, "dc8f644ef2aadf736c1c558f6fc932b15c8a68d3866979173ac30046751449b0")

