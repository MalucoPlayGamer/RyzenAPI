-- Lua provided by SkyAPI 
-- Game: Poker Adventurers
addappid(3727240)
addappid(3727241, 1, "dc8f644ef2aadf736c1c558f6fc932b15c8a68d3866979173ac30046751449b0")
