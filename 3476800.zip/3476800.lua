-- Lua provided by RyzenAPI
-- Game: Anturi

-- MAIN APPLICATION
addappid(3476800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3476801, 1, "c6693ecfd7a8c0e9f2d552aca94109b0797bf644c61df9cc34e3f7a3f9c30e3c")

