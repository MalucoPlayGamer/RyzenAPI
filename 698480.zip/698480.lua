-- Lua provided by RyzenAPI
-- Game: Hippo Sports

-- MAIN APPLICATION
addappid(698480)

-- MAIN APP DEPOTS / PACKAGES
addappid(698481,0,"f4ca9c573b978bf211fd6d6eb9a0da0b62d81bc3c6c21bc26eab44bc82bc3239")

