-- Lua provided by RyzenAPI
-- Game: Laundering Simulator

-- MAIN APPLICATION
addappid(3432750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432751,0,"7532e8278f37755820a38828f8d2d43429580561facaed6b5f3e422c6ac7b201")

