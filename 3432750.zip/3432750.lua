-- Lua provided by RyzenAPI
-- Game: Laundering Simulator

-- MAIN APPLICATION
addappid(3432750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3432751,0,"7532e8278f37755820a38828f8d2d43429580561facaed6b5f3e422c6ac7b201")

