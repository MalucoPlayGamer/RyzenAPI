-- Lua provided by RyzenAPI
-- Game: Sudoku Atlas

-- MAIN APPLICATION
addappid(4931410) -- Sudoku Atlas

-- MAIN APP DEPOTS / PACKAGES
addappid(4931411, 1, "f24c372b81c2255bfd723a3a29b3da8d74d6385669351c837b0d8263d3cad418") -- Depot 4931411
addappid(4931412, 1, "54ee73eea003d6fd170fd86331c9c6b91b087c90612d85968c0db4ae5c2b0162") -- Depot 4931412
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
