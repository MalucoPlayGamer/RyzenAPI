-- Lua provided by RyzenAPI
-- Game: addappid(1878810)

-- MAIN APPLICATION
addappid(1878810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878813,0,"34dffe3d1e3d9b8b88a0b3bb44e861fbc318b88fefa37835db4a521f95759950")
