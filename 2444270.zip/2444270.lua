-- Lua provided by RyzenAPI
-- Game: Nyaruru Soundtrack

-- MAIN APPLICATION
addappid(2444270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444271, 1, "77e5c365ad60977f5112277b8d27578ac20d3f09aa1ca646fd37037502df0aa6")
addappid(2444273, 1, "5ae72f8354e722b950665ac6968c0b6050c45d51bbe0a61bf9e4f6db2b7a1d9a")

