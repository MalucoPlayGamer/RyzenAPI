-- Lua provided by RyzenAPI
-- Game: 1637820

-- MAIN APPLICATION
addappid(1637820)
-- Game: addappid(1637820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637821, 1, "20cc0a12ad371f52eb5b61a041ebbfacc3a7b75be4e5906455cfb1a0f07d9b69")
