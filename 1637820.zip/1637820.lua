-- Lua provided by SkyAPI 
-- Game: The Way Home
addappid(1637820)
addappid(1637821, 1, "20cc0a12ad371f52eb5b61a041ebbfacc3a7b75be4e5906455cfb1a0f07d9b69")
