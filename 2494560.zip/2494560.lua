-- Lua provided by RyzenAPI
-- Game: Game: Soulslinger: Envoy of Death Demo

-- MAIN APPLICATION
addappid(2494560)
-- Game: addappid(2494560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494561, 1, "ad34fbe2efdbb76a38aa8190080ea893c00ade703af41c9fb754d0123c19eb0e")
