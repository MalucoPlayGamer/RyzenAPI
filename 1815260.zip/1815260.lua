-- Lua provided by RyzenAPI
-- Game: CHESS CROWN

-- MAIN APPLICATION
addappid(1815260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815261, 1, "fb9ff8570748d0a5a294a94d296c0c7de1be2cf7cb0b6e23998fea52d40b5be2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
