-- Lua provided by RyzenAPI 
-- Game: CHESS CROWN
addappid(1815260)
addappid(1815261, 1, "fb9ff8570748d0a5a294a94d296c0c7de1be2cf7cb0b6e23998fea52d40b5be2")
