-- Lua provided by RyzenAPI
-- Game: 2689370

-- MAIN APPLICATION
addappid(2689370)
-- Game: addappid(2689370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689371, 1, "159f215ae0c930dd777f6ec447c90bdceb7958253473c419f3594309ffab8418")
