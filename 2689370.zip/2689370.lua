-- Lua provided by RyzenAPI
-- Game: Zombie Raid Playtest

-- MAIN APPLICATION
addappid(2689370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689371, 1, "159f215ae0c930dd777f6ec447c90bdceb7958253473c419f3594309ffab8418")

