-- Lua provided by RyzenAPI
-- Game: 1262304

-- MAIN APPLICATION
addappid(1262304)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262304,0,"2f295ccfad30ace04159d4232c58962efccb2c7eb6c37373db2afccc4f94c4fc")

