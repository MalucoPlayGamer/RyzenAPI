-- Lua provided by RyzenAPI
-- Game: Secret Archives

-- MAIN APPLICATION
addappid(2374660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374661, 1, "0877b612ec7223a0ee8665ae8f84656c4aa45278269679f9c3ad761a47af4030")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
