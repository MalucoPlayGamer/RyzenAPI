-- Lua provided by RyzenAPI
-- Game: Game: Secret Archives

-- MAIN APPLICATION
addappid(2374660)
-- Game: addappid(2374660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374661, 1, "0877b612ec7223a0ee8665ae8f84656c4aa45278269679f9c3ad761a47af4030")
