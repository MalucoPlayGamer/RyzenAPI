-- Lua provided by RyzenAPI
-- Game: 514490

-- MAIN APPLICATION
addappid(514490)
-- Game: addappid(514490)

-- MAIN APP DEPOTS / PACKAGES
addappid(514491, 1, "f25999d73a6cc7bf034b9239164135b88373183d305253750ddfc0abe627cf23")
