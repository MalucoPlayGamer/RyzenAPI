-- Lua provided by RyzenAPI
-- Game: addappid(2059380)

-- MAIN APPLICATION
addappid(2059380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059381, 1, "985baf541c8ca334157e41fae12f0899fc451643d3db571fb87a3ef02eab4755")
