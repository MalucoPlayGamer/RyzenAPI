-- Lua provided by RyzenAPI
-- Game: River City Girls Zero

-- MAIN APPLICATION
addappid(1851020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1851021, 1, "586d11a154c392ae1dab758517af83642c0c02ffaa0c2bbede1e1192c77d12f8")

