-- Lua provided by RyzenAPI
-- Game: 1851020

-- MAIN APPLICATION
addappid(1851020)
-- Game: addappid(1851020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851021, 1, "586d11a154c392ae1dab758517af83642c0c02ffaa0c2bbede1e1192c77d12f8")
