-- Lua provided by RyzenAPI
-- Game: addappid(1453030)

-- MAIN APPLICATION
addappid(1453030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453031, 1, "04318b65b2c181e9f59f0f420c8f6b79fea0f92d40b11fae8a3cab560486dc4d")
