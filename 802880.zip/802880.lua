-- Lua provided by RyzenAPI
-- Game: Muv-Luv

-- MAIN APPLICATION
addappid(802880)
addappid(1501130)
addappid(1616080)
addappid(1811020)
addappid(2289470)

-- MAIN APP DEPOTS / PACKAGES
addappid(802881,0,"c574b04d71af23a128e4ebf8e1cd89073a400e22562beb4bd1fea487f982101b")
addappid(802882,0,"77a82c6b5b90727448de015daf6a0448a1cb7eee568fb8c01f5d0106b9819fde")
addappid(1501130,0,"f952c9a4b961eb0ba883cf2c1625d7916e6b31386b28facefa829b7021e91402")
addappid(1616080,0,"cd4c9fc1576e6ec5275cf262a7637e12b79c4d21c9cf928cb42d9b011465b365")
addappid(1811020,0,"0f89773e664d15d1e97a3fdb6a7ce1b84bab8310aebfad6dfb8fbe16ab1f3606")
addappid(2289470,0,"55ed27863e4afb123aa9c424ffb25ab0c60ac6628f075a840da2efcdfc2b7f13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
