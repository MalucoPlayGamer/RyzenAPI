-- Lua provided by RyzenAPI
-- Game: Muv-Luv

-- MAIN APPLICATION
addappid(802880)
-- Game: addappid(802880)

-- MAIN APP DEPOTS / PACKAGES
addappid(802881, 1, "c574b04d71af23a128e4ebf8e1cd89073a400e22562beb4bd1fea487f982101b")
addappid(802882, 1, "77a82c6b5b90727448de015daf6a0448a1cb7eee568fb8c01f5d0106b9819fde")
addappid(1501130, 0, "f952c9a4b961eb0ba883cf2c1625d7916e6b31386b28facefa829b7021e91402")
addappid(1616080, 0, "cd4c9fc1576e6ec5275cf262a7637e12b79c4d21c9cf928cb42d9b011465b365")
addappid(1811020, 0, "0f89773e664d15d1e97a3fdb6a7ce1b84bab8310aebfad6dfb8fbe16ab1f3606")
