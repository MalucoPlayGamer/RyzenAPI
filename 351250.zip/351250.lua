-- Lua provided by RyzenAPI
-- Game: 351250

-- MAIN APPLICATION
addappid(351250)
addappid(377440)
-- Game: addappid(351250)

-- MAIN APP DEPOTS / PACKAGES
addappid(351251, 1, "afcab84ff11f1fd4d02cf9a8c3d3e5b3a7f7928488ed9032fadb575990e39b99")
