-- Lua provided by RyzenAPI
-- Game: addappid(1122740)

-- MAIN APPLICATION
addappid(1122740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122741, 1, "07d9349d04cb2e0dffa7eaad3c9f7f9854450a4e6261ebac76f298c0b09c2ff9")
