-- Lua provided by RyzenAPI
-- Game: Game: 小白兔电商~Bunny e-Shop

-- MAIN APPLICATION
addappid(1111460)
-- Game: addappid(1111460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111461, 1, "9d700b248094587daf680af4ab5b65bb8506f3e53bfea3693bcd9c528a336957")
addappid(1796170, 0, "6b1c0481f79cf61f11536b19682613eb52e87e3f726e53b524e81730f5b0bbd6")
addappid(2274630, 0, "5785cc9c6864b561f27b0600d9befa86fa4b10df8af0f8ee177737cbf61ce2b3")
addappid(2732260, 0, "b3eb39bac63fa42f6a4216804c1e0c7020077af97c28291009f93cf6080c32d9")
