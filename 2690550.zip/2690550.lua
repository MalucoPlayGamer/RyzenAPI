-- Lua provided by RyzenAPI
-- Game: addappid(2690550)

-- MAIN APPLICATION
addappid(2690550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690550,0,"833f4d727687fd8f9e5910b6cb82231626a607cdcb8e97c0837a1bfcfa0ff437")
