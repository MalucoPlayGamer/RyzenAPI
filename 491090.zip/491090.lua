-- Lua provided by RyzenAPI
-- Game: Game: Ant Queen

-- MAIN APPLICATION
addappid(491090)
-- Game: addappid(491090)

-- MAIN APP DEPOTS / PACKAGES
addappid(491091, 1, "16ab5f5e362503defdce3237ffd5fe67bc3bbd77c671740778d44a0236183b8a")
addappid(491092, 1, "2e191c7748373b92cbfcba2461709e54502f94288da9d6c65b3680adc6a4400f")
addappid(491093, 1, "a2543ec76faa5a8592d078c7f26d30a121c1288cb0a72702f4b6d5a50f22cadb")
addappid(491094, 1, "9cb1132338082954d75be373865cc7f72f6da3eff629c28725fb0d588038c9ae")
