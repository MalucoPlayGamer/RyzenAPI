-- Lua provided by RyzenAPI
-- Game: Resonite

-- MAIN APPLICATION
addappid(2519830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2519831, 1, "2633d2ee5c77932af737e5d10f8f636e6f781e9482f3ffbfd71a8ae249f6f8b9")
addappid(2519832, 1, "760c2a3c7b5dbeaa4532d4b81a21900d6440e6a88fb795ff79078eef18c9393e")

