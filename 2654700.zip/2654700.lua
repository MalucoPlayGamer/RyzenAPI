-- Lua provided by RyzenAPI
-- Game: 扔彩虹模擬器 | Coin Toss Rainbow Simulator

-- MAIN APPLICATION
addappid(2654700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654701, 1, "f03c561f2335ace67249aa50fcf669dff123a51a9242f488f06628555b0d57ec")
