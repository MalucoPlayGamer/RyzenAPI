-- Lua provided by RyzenAPI
-- Game: Game: 江华号

-- MAIN APPLICATION
addappid(2513140)
-- Game: addappid(2513140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2513141, 1, "ea1815ae05e806c5cb9088028ee2348204cf0359b8537678845d955f52a0b72d")
