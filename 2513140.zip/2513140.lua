-- Lua provided by SkyAPI 
-- Game: 江华号
addappid(2513140)
addappid(2513141, 1, "ea1815ae05e806c5cb9088028ee2348204cf0359b8537678845d955f52a0b72d")
