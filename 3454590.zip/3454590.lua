-- Lua provided by RyzenAPI
-- Game: Game: Cornerpond

-- MAIN APPLICATION
addappid(3454590)
-- Game: addappid(3454590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454591, 1, "721b3732c3593445451bac7fe0fb1c0e3fe1663ed8539be6ec9dfdeca9d879dd")
