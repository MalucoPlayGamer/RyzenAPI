-- Lua provided by RyzenAPI
-- Game: addappid(2715370)

-- MAIN APPLICATION
addappid(2715370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715371, 1, "22ecf529cee5bf749df2a81369ac83288b5bf607aaff1d5b327ee8fdf29740fc")
