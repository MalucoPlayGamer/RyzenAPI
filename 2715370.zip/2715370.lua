-- Lua provided by SkyAPI 
-- Game: Ancient Cultivatrix
addappid(2715370)
addappid(2715371, 1, "22ecf529cee5bf749df2a81369ac83288b5bf607aaff1d5b327ee8fdf29740fc")
