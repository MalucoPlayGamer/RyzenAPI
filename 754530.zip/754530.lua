-- Lua provided by RyzenAPI
-- Game: Game: IL-2 Sturmovik: Cliffs of Dover Blitz Edition

-- MAIN APPLICATION
addappid(754530)
-- Game: addappid(754530)

-- MAIN APP DEPOTS / PACKAGES
addappid(754531, 1, "86c933a54c222ac3c85d5c2e604020eab3ea4fffa17d766c695c8057b2b6f746")
addappid(1049440, 0, "130ea19f4d6b9e445096eb00f1432d83ac222460aa3169b1907159f874b4a4b1")
