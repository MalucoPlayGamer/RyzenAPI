-- Lua provided by RyzenAPI
-- Game: The Rat Plague

-- MAIN APPLICATION
addappid(2063500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063501, 1, "b07e56a22cf5434968e6e38b88910771fc5a9890ee2b97791445b5da3f4622a6")

