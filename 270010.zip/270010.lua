-- Lua provided by RyzenAPI
-- Game: AppID 270010

-- MAIN APPLICATION
addappid(270010)

-- MAIN APP DEPOTS / PACKAGES
addappid(270011, 1, "fd7334ac24177dbc3aef2892e457b75a609f0dbb61fb3cca5906b79263cc145f")
