-- Lua provided by RyzenAPI 
-- Game: Double Shot Gals
addappid(1600830)
addappid(1600831, 1, "396cc54633e6cf3397b93f0dea94637d11784f47cdd669ddfb8773fbd2de62eb")
