-- Lua provided by RyzenAPI
-- Game: Game: Project Rose

-- MAIN APPLICATION
addappid(2799490)
-- Game: addappid(2799490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799491, 1, "c8e628f52b4a01848f749059397479f384b5470901b984c843812870ed1e047d")
