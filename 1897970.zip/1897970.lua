-- Lua provided by RyzenAPI
-- Game: Mini Island: Aroma

-- MAIN APPLICATION
addappid(1897970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897971, 1, "c8d65b216d5f82f7fc3138842233ad1ee68bb44baaed55c14debc1994781e6dd")
