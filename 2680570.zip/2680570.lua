-- Lua provided by RyzenAPI
-- Game: Morbid: The Lords of Ire Demo

-- MAIN APPLICATION
addappid(2680570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680571, 1, "88d50655e0edf0f55ce8db995241b5d5242dd96ddd4ed7a009b231f4440892b5")

