-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VII REMAKE Original Soundtrack Plus

-- MAIN APPLICATION
addappid(3365670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365671, 1, "87bf49cbb0d9a54f8b064181471f67550cf246c1715f6e484f169d68df01d6be")

