-- Lua provided by RyzenAPI
-- Game: 3365670

-- MAIN APPLICATION
addappid(3365670)
-- Game: addappid(3365670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365671, 1, "87bf49cbb0d9a54f8b064181471f67550cf246c1715f6e484f169d68df01d6be")
