-- Lua provided by RyzenAPI
-- Game: SOL CRESTA "Wing Galiber" DLC

-- MAIN APPLICATION
addappid(1802831)
-- Game: addappid(1802831)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802831,0,"dd3f806655983c10f17cc745b161c330db728bfc3735a55816f53897ee717134")
