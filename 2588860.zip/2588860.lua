-- Lua provided by RyzenAPI
-- Game: Game: Virtual AI - KURONYAM

-- MAIN APPLICATION
addappid(2588860)
-- Game: addappid(2588860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588861, 1, "fe0869c13a596e77a02c008faa7e7ca90927d0919ef7f23c40c4a53aa52fd593")
addappid(2588862, 1, "7a3dba3d29756b48ee74d57803a6a5a98a55d6cb3e4078acf0330c6be71d2bbe")
addappid(2588865, 1, "9bfb6607bb8e9648eef4b834b21d388cec4471ec05dbead112681a8ca0d44ad9")
addappid(2588866, 1, "138d84ef908fd47c840a15d65020836e50a6ec7595f3bef9bb61085550ddd869")
addappid(2588867, 1, "cfffd01f082ae82a79ce2525c340a7ede3a03f2086be2964d28c4e6fa1f6b9f1")
