-- Lua provided by RyzenAPI
-- Game: Game: Shanubis

-- MAIN APPLICATION
addappid(2178970)
-- Game: addappid(2178970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178971, 1, "d0786c65b5e0453a9fa26b5c8296a496d3472684458a7db61fab179f9395a694")
