-- Lua provided by RyzenAPI
-- Game: OVERKILL's The Walking Dead

-- MAIN APPLICATION
addappid(717690)
addappid(880410)
addappid(880411)
addappid(880412)
addappid(880420)
addappid(880430)
addappid(880440)
addappid(880450)
addappid(880451)
addappid(977220)
addappid(987170)
addappid(991910)
addappid(996990)
addappid(999050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(717691, 1, "ee3135c6362dd5e9ba05e1b1fce5e91dc098ac0aefb3b3916bbd964610e4147f")
addappid(880413, 0, "90d2e91c8d3b0f5c8496ba9b45061134fbb7b190ecbdbee13022e09b187333ec")
addappid(880414, 0, "a9e5564471a3a6b09aed183aa3dbf77c699d72c98b65ba2dac92e114a36740b6")

