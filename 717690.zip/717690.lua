-- Lua provided by RyzenAPI
-- Game: 717690

-- MAIN APPLICATION
addappid(717690)
addappid(880410)
addappid(880411)
addappid(880412)
addappid(880420)
addappid(880430)
addappid(880440)
addappid(880450)
addappid(880451)
addappid(977220)
addappid(987170)
addappid(991910)
addappid(996990)
addappid(999050)
-- Game: addappid(717690)

-- MAIN APP DEPOTS / PACKAGES
addappid(717691, 1, "ee3135c6362dd5e9ba05e1b1fce5e91dc098ac0aefb3b3916bbd964610e4147f")
addappid(880413, 0, "90d2e91c8d3b0f5c8496ba9b45061134fbb7b190ecbdbee13022e09b187333ec")
addappid(880414, 0, "a9e5564471a3a6b09aed183aa3dbf77c699d72c98b65ba2dac92e114a36740b6")
