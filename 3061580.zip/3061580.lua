-- Lua provided by RyzenAPI
-- Game: 3061580

-- MAIN APPLICATION
addappid(3061580)
-- Game: addappid(3061580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3061581, 1, "e6e3f9356c163360bf9d08b351816ab0aa0564e6f2cc2bc411466235e783abea")
