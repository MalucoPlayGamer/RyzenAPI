-- Lua provided by RyzenAPI 
-- Game: Отделение 38
addappid(3061580)
addappid(3061581, 1, "e6e3f9356c163360bf9d08b351816ab0aa0564e6f2cc2bc411466235e783abea")
