-- Lua provided by RyzenAPI
-- Game: Nature and Girls

-- MAIN APPLICATION
addappid(1668870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668871, 1, "11b02b8f41906c164fb159e4d6e974b803da92beff16423f6cf1ea35a5f50ac8")
