-- Lua provided by RyzenAPI
-- Game: SuperCluster: Void

-- MAIN APPLICATION
addappid(610740)

-- MAIN APP DEPOTS / PACKAGES
addappid(610741,0,"e6754634cc67bd4069f570f38bc344b6ed8f6935b33fcbe87b31e98f5335f0ea")

