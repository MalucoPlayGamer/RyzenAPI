-- Lua provided by RyzenAPI
-- Game: Sevyal

-- MAIN APPLICATION
addappid(2452220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452221, 1, "861b56631a59db79a40c2a34c9b97b8a3bda824811178d6fa3c26425d36bab2a")
