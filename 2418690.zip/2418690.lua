-- Lua provided by RyzenAPI
-- Game: AppID 2418690

-- MAIN APPLICATION
addappid(2418690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418691, 1, "cd3148d6d3cb2f00f7a53db81747c37e7fec9f3ac4edeec9bf29786e24cc66bf")
