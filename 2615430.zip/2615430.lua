-- Lua provided by RyzenAPI
-- Game: Witchroid Vania: A Magical Girl’s Fantastical Adventures

-- MAIN APPLICATION
addappid(2615430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615431, 1, "7f0c3da34c3f046c6f28cc339be3e7a23b8854ae2d8ee8c2cfba189dbd539788")

