-- Lua provided by RyzenAPI
-- Game: Doomsday on Demand

-- MAIN APPLICATION
addappid(847310)

-- MAIN APP DEPOTS / PACKAGES
addappid(847311,0,"fa919d07c94c5acaac5f6660671e96f86efd6a95b60bbf378163244a99471126")

