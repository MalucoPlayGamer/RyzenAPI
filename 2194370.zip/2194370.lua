-- Lua provided by RyzenAPI 
-- Game: AppID 2194370
addappid(2194370)
addappid(2194371, 1, "0347a81b7667895477ec0133f93b2a70b246dc65c83f270dda7c95bd444b76c0")
