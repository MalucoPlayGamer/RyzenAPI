-- Lua provided by RyzenAPI 
-- Game: PiM World
addappid(2824770)
addappid(2824771, 1, "8b839846b4ce343e8b902c7e5bcceed70239926d843b185899e24cb87a0f0821")
