-- Lua provided by RyzenAPI
-- Game: Girl Who Shrunk the Neighbors

-- MAIN APPLICATION
addappid(2822970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2822971, 1, "ebbe07f7fac3b67d41138350d1dec2ae6888a63b8ed1ab63e14abe1db1bf0d12")

