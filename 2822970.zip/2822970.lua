-- Lua provided by RyzenAPI
-- Game: 2822970

-- MAIN APPLICATION
addappid(2822970)
-- Game: addappid(2822970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2822971, 1, "ebbe07f7fac3b67d41138350d1dec2ae6888a63b8ed1ab63e14abe1db1bf0d12")
