-- Lua provided by RyzenAPI
-- Game: AppID 501120

-- MAIN APPLICATION
addappid(501120)

-- MAIN APP DEPOTS / PACKAGES
addappid(501121, 1, "b5427093cdf085accff4c5a0ee45db5fdff08ddb3a96350cee48b1a65faae644")

