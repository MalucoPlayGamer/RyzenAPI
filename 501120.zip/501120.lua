-- Lua provided by RyzenAPI
-- Game: AppID 501120

-- MAIN APPLICATION
addappid(501120)

-- MAIN APP DEPOTS / PACKAGES
addappid(501121, 1, "b5427093cdf085accff4c5a0ee45db5fdff08ddb3a96350cee48b1a65faae644")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
