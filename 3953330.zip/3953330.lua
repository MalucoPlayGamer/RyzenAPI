-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Office Sex Handler

-- MAIN APPLICATION
addappid(3953330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3953331,0,"9a9294791ae47d083df4045b1597b9ebc29fe4ba1de90ef2aa4607734830da58")

