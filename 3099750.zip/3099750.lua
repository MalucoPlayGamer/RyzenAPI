-- Lua provided by RyzenAPI
-- Game: addappid(3099750)

-- MAIN APPLICATION
addappid(3099750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099751, 1, "7725dfc03c8d15012483dc1e809c9dd1f63b0549c13dc27dfdc1d36dd67275ca")
