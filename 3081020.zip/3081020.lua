-- Lua provided by RyzenAPI
-- Game: 3081020

-- MAIN APPLICATION
addappid(3081020)
-- Game: addappid(3081020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081021, 1, "fcec21963e8e93eadecec12c9f395b44ec5c58dbabc9d7de94cf40dea947cf38")
