-- Lua provided by RyzenAPI
-- Game: Awita: The Journey of Hope Demo

-- MAIN APPLICATION
addappid(2613260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613261, 1, "161c9ed2d9c41318edc8a6dc2d0c8d9d7442fdb97ef06567626265a08d4a6067")

