-- Lua provided by RyzenAPI
-- Game: Dungeon Royale

-- MAIN APPLICATION
addappid(1404500)
-- Game: addappid(1404500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404501, 1, "1af3b7a2a1d73d874f39f2fbdcc3f18eceb3edc4def70705672fb5fe1c806aef")
