-- Lua provided by RyzenAPI
-- Game: Engine Evolution 2022

-- MAIN APPLICATION
addappid(1871990)
-- Game: addappid(1871990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871991, 1, "50a46b8d10f6444a2d11cd980adcfcec04e0fffb83a36cc311b106a69603b4f2")
