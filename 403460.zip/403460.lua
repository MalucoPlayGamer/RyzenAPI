-- Lua provided by RyzenAPI
-- Game: AppID 403460

-- MAIN APPLICATION
addappid(403460)

-- MAIN APP DEPOTS / PACKAGES
addappid(403461, 1, "39727f286f4a8676df8de186ff2fedba6bc90973dfe0424ec6c04751e13e3ecc")
