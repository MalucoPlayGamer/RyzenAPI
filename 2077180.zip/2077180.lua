-- Lua provided by RyzenAPI
-- Game: SCP: Daybreak

-- MAIN APPLICATION
addappid(2077180)
addappid(2207730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2077181, 1, "531914749d2450f94e185b87a897133fd6958e93dac77f3cbbd67c5d8f66fd32")

