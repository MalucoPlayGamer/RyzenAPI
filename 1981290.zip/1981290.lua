-- Lua provided by RyzenAPI
-- Game: Mini Treasure Girl

-- MAIN APPLICATION
addappid(1981290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981291, 1, "e69957a28fc3ae927159d8fa38c1b8ba5c67641055436697dff7fd93d8c5ddf6")
