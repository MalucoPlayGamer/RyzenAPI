-- Lua provided by RyzenAPI 
-- Game: AppID 2507680
addappid(2507680)
addappid(2507681, 1, "47ca9f2812f93544c828b3e77f3695fefe0a091a6d2f6cb741493fa6171d55b7")
