-- Lua provided by RyzenAPI
-- Game: 暴食的怪獸公主：惑星美食之旅 Demo

-- MAIN APPLICATION
addappid(2507680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507681, 1, "47ca9f2812f93544c828b3e77f3695fefe0a091a6d2f6cb741493fa6171d55b7")
