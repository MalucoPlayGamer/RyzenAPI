-- Lua provided by RyzenAPI
-- Game: addappid(2100790)

-- MAIN APPLICATION
addappid(2100790)
addappid(4144260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100791, 1, "90da84c021dc6a7720f62ef16f1f8a5c3771051fa24ea2f78836e3746a6adb1f")
