-- Lua provided by SkyAPI 
-- Game: FunnyPizzaLand
addappid(2100790)
addappid(2100791, 1, "90da84c021dc6a7720f62ef16f1f8a5c3771051fa24ea2f78836e3746a6adb1f")
addappid(4144260)
