-- Lua provided by RyzenAPI
-- Game: Larcenauts Spectator Mode

-- MAIN APPLICATION
addappid(2162380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2162381, 1, "29e6c0609ea0d8ba68f69497f8adf40154ebeffac4c21f94d1e126cfc80523dc")

