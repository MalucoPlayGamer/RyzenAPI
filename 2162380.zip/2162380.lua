-- Lua provided by RyzenAPI 
-- Game: Larcenauts Spectator Mode
addappid(2162380)
addappid(2162381, 1, "29e6c0609ea0d8ba68f69497f8adf40154ebeffac4c21f94d1e126cfc80523dc")
