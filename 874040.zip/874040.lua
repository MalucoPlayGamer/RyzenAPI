-- Lua provided by RyzenAPI
-- Game: addappid(874040)

-- MAIN APPLICATION
addappid(228990)
addappid(874040)
addappid(874041)
addappid(874043)

-- MAIN APP DEPOTS / PACKAGES
addappid(874042,0,"e2153fe669824632242b84aa90702c7aa001f2f1e7cbce19b0a679c66edcab8e")
