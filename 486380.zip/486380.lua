-- Lua provided by SkyAPI 
-- Game: Shigatari
addappid(486380)
addappid(486381, 1, "bf7754149f9296468c29488a4e62d03f874c6900930a009733bf97aa9a14855e")
