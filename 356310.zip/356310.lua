-- Lua provided by RyzenAPI
-- Game: METAL SLUG DEFENSE

-- MAIN APPLICATION
addappid(356310)
-- Game: addappid(356310)

-- MAIN APP DEPOTS / PACKAGES
addappid(356311, 1, "b08171977e36da82ff71ca17c77072decd2d6e69d472fde3c4530d448f0b27e4")
