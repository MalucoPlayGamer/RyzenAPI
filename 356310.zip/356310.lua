-- Lua provided by RyzenAPI
-- Game: METAL SLUG DEFENSE

-- MAIN APPLICATION
addappid(356310)

-- MAIN APP DEPOTS / PACKAGES
addappid(356311, 1, "b08171977e36da82ff71ca17c77072decd2d6e69d472fde3c4530d448f0b27e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(361470)
addappid(362500)
addappid(362520)
addappid(362530)
addappid(362540)
addappid(362550)
addappid(362560)
addappid(362570)
addappid(362580)
addappid(362590)
