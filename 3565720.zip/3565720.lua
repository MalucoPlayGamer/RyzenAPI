-- Lua provided by RyzenAPI
-- Game: Starfield Battlegrounds

-- MAIN APPLICATION
addappid(3565720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3565721, 1, "32ef8d1d38235760d1ea37a37aa9a0a21f6508c48407ac2874826dedd80d1065")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
