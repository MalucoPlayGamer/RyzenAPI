-- Lua provided by RyzenAPI
-- Game: 3565720

-- MAIN APPLICATION
addappid(3565720)
-- Game: addappid(3565720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3565721, 1, "32ef8d1d38235760d1ea37a37aa9a0a21f6508c48407ac2874826dedd80d1065")
