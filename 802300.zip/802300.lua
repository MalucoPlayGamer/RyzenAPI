-- Lua provided by RyzenAPI
-- Game: Baseball Kings VR

-- MAIN APPLICATION
addappid(802300)

-- MAIN APP DEPOTS / PACKAGES
addappid(802301,0,"44bf1d67f7bd24416608bdbf360fc966424eeee16a3707fd5d28f9c67ccd9f57")

