-- Lua provided by RyzenAPI
-- Game: 500380

-- MAIN APPLICATION
addappid(500380)
-- Game: addappid(500380)

-- MAIN APP DEPOTS / PACKAGES
addappid(500381, 1, "8fcab0694af7468f74cbe45d6903dc2830f6f6a02012c3bc27587ed88f6d2af7")
