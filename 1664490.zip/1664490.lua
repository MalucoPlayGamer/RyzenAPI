-- Lua provided by RyzenAPI
-- Game: 1664490

-- MAIN APPLICATION
addappid(1664490)
-- Game: addappid(1664490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664491, 1, "222f63e5f8e78b533afcd92c7eebc5ba72ab81bfa07eaba3e475902fbae08e12")
addappid(1664492, 1, "85e57e8874175d96d8c3d95c7be6c1547990fb38fb80c4646387df5dfac8ea70")
