-- Lua provided by RyzenAPI
-- Game: addappid(525290)

-- MAIN APPLICATION
addappid(525290)

-- MAIN APP DEPOTS / PACKAGES
addappid(525291, 1, "853fd14f4d499761553e8587d80c65f97cac269e3e598135b0b59f2bd689a9b0")
