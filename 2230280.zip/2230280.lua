-- Lua provided by RyzenAPI
-- Game: Tiny Civilization

-- MAIN APPLICATION
addappid(2230280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230281, 1, "6907470a25cd285b128bcbbb1b183192afd4491ec29a00a72356e2078a33a771")

