-- Lua provided by RyzenAPI
-- Game: Planetary Life

-- MAIN APPLICATION
addappid(2471970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471971,0,"ba869eccc07b6d6aa6a1dd54cb57600b01c63a81500e4a7d350c45e730b79ac8")

