-- Lua provided by RyzenAPI
-- Game: Stardeus

-- MAIN APPLICATION
addappid(1380910)
-- Game: addappid(1380910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380916,0,"fc2db05cca8e14734f1a076ce34983bcdf572ce38c993626651a6aec6661fc30")
addappid(1380917,0,"6792f8df6cceb2a4fc92bb55538119f02c616db79b55776c76e64ebf39d9c7de")
addappid(1380918,0,"d1b43ac1e50c72425f628ffbde5ca8ffaa42b9a7ee1d3b78467f7f94f46d59d0")
