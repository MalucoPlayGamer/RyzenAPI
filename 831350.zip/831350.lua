-- Lua provided by RyzenAPI
-- Game: Hovercraft Drive

-- MAIN APPLICATION
addappid(831350)

-- MAIN APP DEPOTS / PACKAGES
addappid(831351,0,"4fe10babf409b6f4bd6b48ba7f21b3a1eea37bfca1f1caf4bf24cb151eca4da1")

