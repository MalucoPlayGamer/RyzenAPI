-- Lua provided by RyzenAPI
-- Game: Game: AppID 824090

-- MAIN APPLICATION
addappid(824090)
-- Game: addappid(824090)

-- MAIN APP DEPOTS / PACKAGES
addappid(824091, 1, "06bd9463f0fa05613dcbc00d5e8cbc36ea99d04267f98be930a86af5d9a1813a")
