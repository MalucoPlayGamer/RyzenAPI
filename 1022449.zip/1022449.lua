-- Lua provided by RyzenAPI
-- Game: DFF NT: Sephiroth Starter Pack

-- MAIN APPLICATION
addappid(1022449)
-- Game: addappid(1022449)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022449,0,"d51ecfcfc99a3ecafcde78cf4150bd39c8b8c9e681dc8bc564d9c4996617b1e3")
