-- Lua provided by RyzenAPI
-- Game: Dark Chronicles: The Soul Reaver

-- MAIN APPLICATION
addappid(1596640)
-- Game: addappid(1596640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596641, 1, "975bfdc0d8466120d1c0cee1213bfbf18cefe38d1980fb65803bcaca39cc5285")
