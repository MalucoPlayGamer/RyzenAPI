-- Lua provided by RyzenAPI
-- Game: Game: Diaries of a Spaceport Janitor

-- MAIN APPLICATION
addappid(436500)
-- Game: addappid(436500)

-- MAIN APP DEPOTS / PACKAGES
addappid(436501, 1, "bb8b0447dceeb438c083b0c9c6f4a32678776339976e5bf184eb35152a35e711")
addappid(436502, 1, "7f0ffe0fdd356a88d3bfdfe68b7a750c9d0b7d7aad5a562a56d5400601fe22eb")
