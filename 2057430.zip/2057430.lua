-- Lua provided by RyzenAPI 
-- Game: The Wraith of the Galaxy
addappid(2057430)
addappid(2057431, 1, "0742515e022b97fa594d98211b17914b27cdaa1474e7596fb65f0f9dd4c19ace")
