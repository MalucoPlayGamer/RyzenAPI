-- Lua provided by RyzenAPI
-- Game: The Wraith of the Galaxy

-- MAIN APPLICATION
addappid(2057430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2057431, 1, "0742515e022b97fa594d98211b17914b27cdaa1474e7596fb65f0f9dd4c19ace")

