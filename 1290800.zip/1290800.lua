-- Lua provided by RyzenAPI
-- Game: Rock and Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1290800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290800,0,"a3d8a936ccc9bea27585093622f9cae7d792a8ade68d46b491e5525fad795f73")

