-- Lua provided by RyzenAPI
-- Game: 2657920

-- MAIN APPLICATION
addappid(2657920)
-- Game: addappid(2657920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657922,0,"6c43ad77760d54071aa6a6ae73bc808e3963977f0fedb4af99d57c2f32abaecf")
