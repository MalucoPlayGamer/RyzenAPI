-- Lua provided by RyzenAPI
-- Game: addappid(3117690)

-- MAIN APPLICATION
addappid(3117690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3117691, 1, "be93e1efb62205fa1a6101397229bda0764d40c20087474b4ba8db934e46125e")
