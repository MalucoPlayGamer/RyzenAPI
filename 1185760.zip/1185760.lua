-- Lua provided by RyzenAPI
-- Game: 1185760

-- MAIN APPLICATION
addappid(1185760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185760,0,"751212c4a72a8b854e6a58eeebfb0eea0c6b381966b1ffaaba818ca3d84460eb")

