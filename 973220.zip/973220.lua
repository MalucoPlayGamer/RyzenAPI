-- Lua provided by RyzenAPI
-- Game: Game: SiNKR 2

-- MAIN APPLICATION
addappid(973220)
-- Game: addappid(973220)

-- MAIN APP DEPOTS / PACKAGES
addappid(973221, 1, "07fa046001faaacf22f395e4041b446f972a7b63006e53bb944037e2a3c212b3")
