-- Lua provided by RyzenAPI
-- Game: Solitaire Club

-- MAIN APPLICATION
addappid(630470)

-- MAIN APP DEPOTS / PACKAGES
addappid(630471, 1, "e30ee289a0e176498bd7e1a1fea0749bfda5a22166cf9c0058a339ef6c74a788")
addappid(630472, 1, "d8d8c8125b5a39522331a90a617c65a3868d42c1a8335f5b6b22f26a4387c5a0")
addappid(630473, 1, "7a1b39976f0521d3fa05c68cabe2de6e6704275adb428eeaa8c6b5282cba61e5")
addappid(630474, 1, "e03238a8397037ecc0ccde64b3251cc0dd7bc1fe765522a5f7bcc5eed4acd255")
addappid(630475, 1, "6da88c6babb891c24337c0eb1969a60274d74e7b4dc4c61a5d2b0c445e828b59")

