-- Lua provided by RyzenAPI
-- Game: 御寇三世：星图

-- MAIN APPLICATION
addappid(1513820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513821,0,"8c83c2e65269ea37bc7fe3b4aee61c4a408ecc5f5ae71ffb58d971e393710015")

