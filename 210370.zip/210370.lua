-- Lua provided by RyzenAPI
-- Game: Game: AppID 210370

-- MAIN APPLICATION
addappid(210370)
-- Game: addappid(210370)

-- MAIN APP DEPOTS / PACKAGES
addappid(210371, 1, "a2d6cac7857587ff102f3290c0261d5c50a3472de178b982605965909bcf70cf")
