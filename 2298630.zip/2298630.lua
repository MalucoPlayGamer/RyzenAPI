-- Lua provided by RyzenAPI
-- Game: E30 Drift Car Simulator

-- MAIN APPLICATION
addappid(2298630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298631, 1, "831a275a1dc724f045d285b349678da26b2954e43164517a79831daef05bb405")

