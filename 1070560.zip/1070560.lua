-- Lua provided by RyzenAPI
-- Game: Steam Linux Runtime 1.0 (scout)

-- MAIN APPLICATION
addappid(1070560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070561, 1, "4c947d1708cad6cce83c36773cbb1b28b928a86befc5e9edb3d31634b532c638")

