-- Lua provided by RyzenAPI
-- Game: Little Sim World Demo

-- MAIN APPLICATION
addappid(2990030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990031, 1, "357bb7fda389f43e3ad60a42cd6cc9cbbe6566f7ba4c3ecdda51137749838251")
