-- Lua provided by RyzenAPI
-- Game: Surviving the Aftermath

-- MAIN APPLICATION
addappid(684450)

-- MAIN APP DEPOTS / PACKAGES
addappid(684451, 1, "ecae554f887c65bddfa54bffde64e0fe5c4315fb7bd3421186694d4b3555b45a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1436890)
addappid(1600410)
addappid(1766280)
addappid(1803780)
addappid(1803781)
addappid(1803782)
addappid(2146190)
