-- Lua provided by RyzenAPI
-- Game: 684450

-- MAIN APPLICATION
addappid(684450)
-- Game: addappid(684450)

-- MAIN APP DEPOTS / PACKAGES
addappid(684451, 1, "ecae554f887c65bddfa54bffde64e0fe5c4315fb7bd3421186694d4b3555b45a")
