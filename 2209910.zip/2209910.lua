-- Lua provided by RyzenAPI
-- Game: addappid(2209910)

-- MAIN APPLICATION
addappid(2209910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209911, 1, "00f56562a69d4180a7a100c5a1baed95ad76e6b8db522548b6bc49f2671ae2ba")
