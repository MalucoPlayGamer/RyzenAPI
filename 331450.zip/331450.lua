-- Lua provided by RyzenAPI
-- Game: Disney•Pixar Finding Nemo

-- MAIN APPLICATION
addappid(331450)

-- MAIN APP DEPOTS / PACKAGES
addappid(331451, 1, "02bce50635d9a523aaefc2b51ab10f85593c28cd5a81a4c89ca3aed8b61f53cf")
addappid(331452, 1, "8a8551af8c0902df46859ffefa5869e8d4bad64d4550cbd707d9582fdc387d54")
addappid(331453, 1, "a55e070cc1d7725c1c815c2577beea0efeefd26314d2206e253516bf015986a7")
addappid(331454, 1, "5085daa3fbf0db130d48563cd1cc26eb07e2f8a6b51acc029579cd929bdf7d87")
addappid(331455, 1, "d19d819f6e783c71a2022d778e44ff6ad70715026a2812f6dc6a16b7c099b63c")
addappid(331456, 1, "3bf16e5468bd61ae335e251db39cdc5be0362b274e92933c18bb4a2049d67349")
addappid(331457, 1, "c390174696781fb635e66e0407920b24d9ddbecb8535b8cae4c6cd879edb5d8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
