-- Lua provided by RyzenAPI
-- Game: Not a Masterpıece

-- MAIN APPLICATION
addappid(2898740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2898741, 1, "a2e2af4687376ff1730446c4dd1b0b34423fcfa4633b827b2e43d45bbc2cdbd7")

