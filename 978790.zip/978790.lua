-- Lua provided by RyzenAPI
-- Game: addappid(978790)

-- MAIN APPLICATION
addappid(978790)

-- MAIN APP DEPOTS / PACKAGES
addappid(978791, 1, "c2b2c93f8b56e1cc805e4eae151d0bf2bf55cec24ab86e6e7c0d7a7fd9062f00")
addappid(978792, 1, "10ddc36e71d9888b7a763e4f8b50321b4aa5e09184913a25ee4608bb8e34cff5")
