-- Lua provided by RyzenAPI
-- Game: 962302

-- MAIN APPLICATION
addappid(962302)
-- Game: addappid(962302)

-- MAIN APP DEPOTS / PACKAGES
addappid(962302,0,"dad6a3951d5338d125926c8361e890810054a6edb17578730da34a9d7c8b4cf8")
