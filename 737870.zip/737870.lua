-- Lua provided by RyzenAPI
-- Game: setManifestid(737872,"2658516043939998574")

-- MAIN APPLICATION
addappid(737870)
-- Game: addappid(737870)

-- MAIN APP DEPOTS / PACKAGES
addappid(737872,0,"6c332df981d1822e0456e410b5c6f7df2b932c8f670cc76f3736675bc4924abd")
