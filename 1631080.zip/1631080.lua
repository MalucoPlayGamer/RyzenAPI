-- Lua provided by RyzenAPI
-- Game: HoneySelect2Libido DX

-- MAIN APPLICATION
addappid(1631080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631081, 1, "01c82c96527d7e375cfdbfea412814279f1d24510b9e34e863c0ec1225da59f7")
