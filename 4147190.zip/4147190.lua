-- Lua provided by RyzenAPI
-- Game: Risky Business

-- MAIN APPLICATION
addappid(4147190)

-- MAIN APP DEPOTS / PACKAGES
addappid(4147191, 1, "9f13124402a28564aec502fc1d5c5caeb185942dc490bb848d8986e20175fb7b")

