-- Generated with Luie @ https://lua.tools/
-- 4147190 - Risky Business
-- Generated 2026-08-22 04:53:11 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(4147190)

-- Main Depots
addappid(4147191, 1, "9f13124402a28564aec502fc1d5c5caeb185942dc490bb848d8986e20175fb7b")
setManifestid(4147191, "284753255231238557", 1112938162)

-- Missing Depots (We don't have the keys yet lol): 4973331
