-- Lua provided by RyzenAPI
-- Game: V Gate

-- MAIN APPLICATION
addappid(2542520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542521, 1, "158dc9bb18b4b68e04961a68b83b3ff38ee3fea7b67e85b2ff12924f5d7beef9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
