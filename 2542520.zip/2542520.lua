-- Lua provided by RyzenAPI
-- Game: 2542520

-- MAIN APPLICATION
addappid(2542520)
-- Game: addappid(2542520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542521, 1, "158dc9bb18b4b68e04961a68b83b3ff38ee3fea7b67e85b2ff12924f5d7beef9")
