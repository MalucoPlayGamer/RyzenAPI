-- Lua provided by RyzenAPI
-- Game: Mecha BREAK

-- MAIN APPLICATION
addappid(2452280)
