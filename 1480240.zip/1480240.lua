-- Lua provided by SkyAPI 
-- Game: You Pilot A Piece Of S***: GAIDEN
addappid(1480240)
addappid(1480241, 1, "372925afbd12e28b2c4a950934b35a3f42ec8e1f3a182ea1b4a7218db72b1dc2")
