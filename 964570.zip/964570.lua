-- Lua provided by RyzenAPI
-- Game: addappid(964570)

-- MAIN APPLICATION
addappid(964570)

-- MAIN APP DEPOTS / PACKAGES
addappid(964571, 1, "fbe3fcf5b3655b9af52267b5b64d3dd42a77383786fa9b4b0a9685c4e972ba74")
