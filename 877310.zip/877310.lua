-- Lua provided by RyzenAPI
-- Game: Sumerian Blood: Gilgamesh against the Gods

-- MAIN APPLICATION
addappid(877310)

-- MAIN APP DEPOTS / PACKAGES
addappid(877311,0,"ad062f8e9f5bfd98ffd0363841987221924f88a28115256fe70c19b6eb2a6f6c")

