-- Lua provided by RyzenAPI
-- Game: 1937510

-- MAIN APPLICATION
addappid(1937510)
-- Game: addappid(1937510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937511, 1, "b15019e1d6bb29f477124cc38e441a399f621ad9df81ef74eacc624f9805089a")
