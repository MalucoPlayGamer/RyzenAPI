-- Lua provided by RyzenAPI
-- Game: Bouncy Cube

-- MAIN APPLICATION
addappid(1785800)
-- Game: addappid(1785800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785801, 1, "a13df65bdb0fa59b7354e44225c09123723c11157148c97f6b7665e404a7934a")
