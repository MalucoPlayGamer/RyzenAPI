-- Lua provided by RyzenAPI
-- Game: Yumeutsutsu Re:Master demo

-- MAIN APPLICATION
addappid(1085060)
-- Game: addappid(1085060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085061, 1, "90865f345b5db14f24f77e86c794fcadf8da48a610fd690d1003c6607f411d9f")
addappid(1085062, 1, "2a4a4d15335a2693f8795a55f0b8309307a8fd9177fe0c699c7087953ac00e8f")
addappid(1085064, 1, "f906b5694e137116b1f1a6bc6ca8d1313ac93fbb8236ccf6a51e583e46290892")
