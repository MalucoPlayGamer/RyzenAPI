-- Lua provided by SkyAPI 
-- Game: AppID 543960
addappid(543960)
addappid(543961, 1, "a2df5b66af9e5cd6c5325e23b3dd34047cd3a638ffd8efac3e269740cda79033")
