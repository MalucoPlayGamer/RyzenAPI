-- 4299940's Lua and Manifest Created by Hubcap Manifest
-- The Purple Forest Ritual
-- Created: July 26, 2026 at 08:07:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4299940) -- The Purple Forest Ritual
-- MAIN APP DEPOTS
addappid(4299941, 1, "240c21ec34fc2ef713ba9ffb19653492681f42b6da0e6f20cb8420838e61905d") -- Depot 4299941
setManifestid(4299941, "2176054095439378003", 587669475)