-- Lua provided by RyzenAPI
-- Game: 2785690

-- MAIN APPLICATION
addappid(2785690)
-- Game: addappid(2785690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785691, 1, "7a1982eb8a877642502baa6972b748d6c3011a21a7e33b199d35abb95d9eeaab")
