-- Lua provided by RyzenAPI
-- Game: Glass Wings

-- MAIN APPLICATION
addappid(2271520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271521, 1, "ab7fca18161d8490938ea48082c340372068011a75c97e392a7d8fda9b45f3da")
