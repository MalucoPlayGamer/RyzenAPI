-- Lua provided by RyzenAPI
-- Game: Glass Wings

-- MAIN APPLICATION
addappid(2271520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271521, 1, "ab7fca18161d8490938ea48082c340372068011a75c97e392a7d8fda9b45f3da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
