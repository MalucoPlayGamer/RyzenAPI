-- Lua provided by RyzenAPI
-- Game: Venba Soundtrack

-- MAIN APPLICATION
addappid(2500630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500631, 1, "5ce40848ece4bdc6601eec86e6c2d1a99cec6f3fdf5a426546a843dfeaaff79d")
addappid(2500632, 1, "aebdba56ad0b072395d425daf49a4ec7e9ee93d70d9b6fbf445a52ca0a79cb58")

