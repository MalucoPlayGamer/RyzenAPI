-- Lua provided by RyzenAPI
-- Game: addappid(3773690)

-- MAIN APPLICATION
addappid(3773690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3773691, 1, "2a67c38aa7335b3e9d42466838958c6bd9dd04a12faacbc53ed3e66db223cd92")
