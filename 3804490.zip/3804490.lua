-- Lua provided by RyzenAPI
-- Game: 3804490

-- MAIN APPLICATION
addappid(3804490)
-- Game: addappid(3804490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3804490,0,"e38a4bb69cfdd7c2d7f6f03f803f5009ee0954a31af2c80ef206705b6f781e8b")
