-- Lua provided by RyzenAPI
-- Game: 760660

-- MAIN APPLICATION
addappid(760660)
-- Game: addappid(760660)

-- MAIN APP DEPOTS / PACKAGES
addappid(760661, 1, "9367f1d1c85d6f1d66347408aa4cbfb4972eef3923aa5e3a015c2621a04b7857")
