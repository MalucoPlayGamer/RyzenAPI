-- Lua provided by RyzenAPI
-- Game: AppID 760660

-- MAIN APPLICATION
addappid(760660)

-- MAIN APP DEPOTS / PACKAGES
addappid(760661, 1, "9367f1d1c85d6f1d66347408aa4cbfb4972eef3923aa5e3a015c2621a04b7857")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
