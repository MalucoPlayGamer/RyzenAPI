-- Lua provided by SkyAPI 
-- Game: AppID 760660
addappid(760660)
addappid(760661, 1, "9367f1d1c85d6f1d66347408aa4cbfb4972eef3923aa5e3a015c2621a04b7857")
