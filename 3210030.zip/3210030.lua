-- Lua provided by RyzenAPI
-- Game: 3210030

-- MAIN APPLICATION
addappid(3210030)
-- Game: addappid(3210030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210031, 1, "24788adec5eae5116e6d6befa9c85f13d940c51e9ece7aa6262497812d74cb7a")
