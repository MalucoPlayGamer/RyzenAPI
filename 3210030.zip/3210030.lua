-- Lua provided by RyzenAPI 
-- Game: AppID 3210030
addappid(3210030)
addappid(3210031, 1, "24788adec5eae5116e6d6befa9c85f13d940c51e9ece7aa6262497812d74cb7a")
