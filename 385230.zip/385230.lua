-- Lua provided by RyzenAPI
-- Game: 385230

-- MAIN APPLICATION
addappid(385230)
-- Game: addappid(385230)

-- MAIN APP DEPOTS / PACKAGES
addappid(385231, 1, "9394fa207e02dc1792136d82f80234fdff0cde6be00a4b14bf323d624a5367dc")
addappid(385232, 1, "f0b6f32239a69aa4db4b08ba833c6866df3140990e9942c05dc8d1cbf2d39d6b")
