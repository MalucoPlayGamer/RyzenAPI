-- Lua provided by RyzenAPI
-- Game: MULTIPLAYER OBBY

-- MAIN APPLICATION
addappid(2668760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2668761, 1, "c86b42938c240d6852c9d3eb0b9b1140609bce5b38906b34db8e7879ec8aea80")
