-- Lua provided by RyzenAPI 
-- Game: AppID 2668760
addappid(2668760)
addappid(2668761, 1, "c86b42938c240d6852c9d3eb0b9b1140609bce5b38906b34db8e7879ec8aea80")
