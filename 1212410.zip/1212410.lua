-- Lua provided by RyzenAPI
-- Game: 1212410

-- MAIN APPLICATION
addappid(1212410)
-- Game: addappid(1212410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212411, 1, "e7963909e0bab73e562adb96c9ccf4d249440f88aab68b084329b12fa37a16a1")
