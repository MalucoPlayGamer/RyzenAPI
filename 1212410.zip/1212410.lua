-- Lua provided by RyzenAPI
-- Game: Hourglass

-- MAIN APPLICATION
addappid(1212410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212411, 1, "e7963909e0bab73e562adb96c9ccf4d249440f88aab68b084329b12fa37a16a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
