-- Lua provided by RyzenAPI
-- Game: Candy Disaster-Original Soundtracks "Nightclub & Desert"

-- MAIN APPLICATION
addappid(1517980)
-- Game: addappid(1517980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517981, 1, "db185e6730eb41269e42bb680f67b42ac1a13d427dd60a44990b10ec760e8d17")
addappid(1517982, 1, "f8e26f2c7cedd8fbd6bccbaffe9c03afbd1afae06ed8a176a40fab4e8b287c7f")
