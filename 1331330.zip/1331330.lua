-- Lua provided by RyzenAPI
-- Game: 1331330

-- MAIN APPLICATION
addappid(1331330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331332,0,"af3b0810dabe41fbee5db81db2fefd6c19d52cc34dd4e38faa580439cfd0cdda")
addappid(1331334,0,"360767f2facdf345f542780b76425a5d94cd8ddee46beb49f8dd337f9f09712c")
