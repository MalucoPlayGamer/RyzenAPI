-- Lua provided by RyzenAPI
-- Game: Transpile Girl Rescue Operation! Demo

-- MAIN APPLICATION
addappid(2752950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752951, 1, "473975d815bcc286a27149b4f063f665fc37164f78491826e1154854b28c93a9")

