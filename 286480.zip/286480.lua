-- Lua provided by RyzenAPI
-- Game: Game: Black Mirror III

-- MAIN APPLICATION
addappid(286480)
-- Game: addappid(286480)

-- MAIN APP DEPOTS / PACKAGES
addappid(286481, 1, "af6107129c41be8acf62b3347941eb5c5be9835b85d363a4f942fec9c0ea042c")
addappid(286482, 1, "c3db19be7d8d17782f9674b372dd5a82ed1204fa84a451ff895fea872f5cc0be")
addappid(286483, 1, "7a45b207affe8b17c74f9330e3595258e517782cb936f51a6b2296a8bd606dc5")
addappid(286484, 1, "b15a4b0291659be3b88ce89886b8f2646eb6e9f5aba37889b62ea72913d7eb8a")
addappid(286485, 1, "9cda0c4849c4f256ea0eefaa2e167e0c3ce7db490ffe0cbed4daebb0f041abdd")
addappid(286486, 1, "42cb4e80a2c3dd807f03a907ef556a3c86689cdc0d7edbe34c3355ffe974a90b")
addappid(286487, 1, "a83c1ed0fa4feddd6b9b7165a45368f024930496491d87ae9b015057fe379f21")
addappid(286488, 1, "811b6efa491898bcebd9b0b92fde71f9b171dac97498a16b307a5a09e07d2318")
