-- Lua provided by RyzenAPI
-- Game: Skilltree Saga

-- MAIN APPLICATION
addappid(315320)

-- MAIN APP DEPOTS / PACKAGES
addappid(315321, 1, "46f27be0a8342eefa0e037649018430b1f7bd4688274e5766a15b00d8f19b99d")

