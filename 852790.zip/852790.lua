-- Lua provided by RyzenAPI
-- Game: The Adventure of Magical Girl

-- MAIN APPLICATION
addappid(852790)

-- MAIN APP DEPOTS / PACKAGES
addappid(852791, 1, "0db3b21ff43ce7818236f10eea6f22f9dc1f583248e1c1659112a4d6c1af74ca")
addappid(852792, 1, "ff4ac7456d1851bd3994bc321d448f33f069f34aa4478f425880c870456c9ee3")
