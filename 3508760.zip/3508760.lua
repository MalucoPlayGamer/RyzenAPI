-- Lua provided by RyzenAPI
-- Game: Sex Dorm🔞

-- MAIN APPLICATION
addappid(3508760)
-- Game: addappid(3508760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3508761, 1, "80409de2a8d51fdd6f9d2f3335e28975153760a0b5b95c5316c36a01e3e21bc6")
