-- Lua provided by RyzenAPI
-- Game: Winter tramp

-- MAIN APPLICATION
addappid(1994850)
-- Game: addappid(1994850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994851, 1, "5348dabd1a5e9ff26ff9f6ea61e864e5978b3e6545302b5ea0a2144b0e29b0e5")
