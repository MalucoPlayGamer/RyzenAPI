-- Lua provided by RyzenAPI
-- Game: 589280

-- MAIN APPLICATION
addappid(589280)
-- Game: addappid(589280)

-- MAIN APP DEPOTS / PACKAGES
addappid(589281, 1, "b694f75ce1822e5132b0d2706ef7348a07bfe87971562426959a4c026de7cedc")
