-- Lua provided by RyzenAPI
-- Game: AppID 589280

-- MAIN APPLICATION
addappid(589280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(589281, 1, "b694f75ce1822e5132b0d2706ef7348a07bfe87971562426959a4c026de7cedc")

