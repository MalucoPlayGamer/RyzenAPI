-- Lua provided by RyzenAPI 
-- Game: AppID 1256930
addappid(1256930)
addappid(1256931, 1, "75cbe244e29bf8ee02997c30905938e7743342cbf289abfe1b1cb5f77b107669")
addappid(1256932, 1, "d39e02606e76fce219fab111aeb277bbf98ddc185d502a0f4cfda43b658eea67")
