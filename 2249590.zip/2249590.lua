-- Lua provided by RyzenAPI
-- Game: addappid(2249590)

-- MAIN APPLICATION
addappid(2249590)
addappid(3109770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249591, 1, "51190b8464ef8dc57418d4e5ea37e0a1a660d3431f93a4e9bc3bbf85ffb6e5b9")
