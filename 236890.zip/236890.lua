-- Lua provided by RyzenAPI
-- Game: addappid(236890)

-- MAIN APPLICATION
addappid(236890)

-- MAIN APP DEPOTS / PACKAGES
addappid(236891, 1, "cb1b577fce05eb46811362428bf261f749e86525b5bd4f5af51d39990d53fb81")
