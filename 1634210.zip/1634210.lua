-- Lua provided by RyzenAPI 
-- Game: Puzz/LR
addappid(1634210)
addappid(1634211, 1, "7b91ff31959842f542594319acc60c4a3df7437c29ee5b28e2c32a31df00a098")
addappid(1634212, 1, "ca6e5b4affa6f17db12d9a17ecc39af24666da6ba13bd4e8b193fe0995963f0d")
