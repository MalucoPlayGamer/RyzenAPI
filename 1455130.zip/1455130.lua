-- Lua provided by RyzenAPI 
-- Game: Number One Rich
addappid(1455130)
addappid(1455131, 1, "d94f273e64e3631c028787bf5835f84f64043eda0fbea68fae1d66b38ecb8f2c")
