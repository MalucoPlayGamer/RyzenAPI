-- Lua provided by RyzenAPI
-- Game: Hentai Story Cleopatra

-- MAIN APPLICATION
addappid(1223320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223321, 1, "1d7f4f6e49a1a34196a792662466498692c5d1e5e8727835e1134d84311e561a")

