-- Lua provided by RyzenAPI
-- Game: 1022423

-- MAIN APPLICATION
addappid(1022423)
-- Game: addappid(1022423)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022423,0,"0a998c16befd37bcac9585987d525c863effe927f305023126dcf4c4a5de392b")
