-- Lua provided by RyzenAPI
-- Game: Game: AppID 3224430

-- MAIN APPLICATION
addappid(3224430)
-- Game: addappid(3224430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224431, 1, "2c73bd864ed75a50734971990f961e2cab102da008c6817cf65e245ded2c5880")
