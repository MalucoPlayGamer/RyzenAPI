-- Lua provided by RyzenAPI
-- Game: Duck Game

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- XNA 4.0 Redist (Shared from App 228980)
addappid(312530, 1, "2c26ba42d788bcc26090e8a341292a36dac4d957afe604dc6acfbf9974a0fcc2") -- Duck Game
addappid(312531, 1, "b9374086d144780234e7f09982d63d8e798114d8fb41a432381154f6bfca1a63") -- Duck Game Content

