-- Lua provided by RyzenAPI
-- Game: Game: AppID 312530

-- MAIN APPLICATION
addappid(312530)
-- Game: addappid(312530)

-- MAIN APP DEPOTS / PACKAGES
addappid(312531, 1, "b9374086d144780234e7f09982d63d8e798114d8fb41a432381154f6bfca1a63")
