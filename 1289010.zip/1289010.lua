-- Lua provided by RyzenAPI
-- Game: Haypi Monster 3

-- MAIN APPLICATION
addappid(1289010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289011, 1, "2645da63a7228b49049f37c09393186c062d93943cd5aa8a7dd5f8dca5a0c363")

