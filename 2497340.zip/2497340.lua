-- Lua provided by RyzenAPI
-- Game: Rolling Atop It

-- MAIN APPLICATION
addappid(2497340)
-- Game: addappid(2497340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497343,0,"44bd12aa6f754ecea9a9783357189c903d4fd2d726998780e12a723231bae91e")
