-- Lua provided by RyzenAPI
-- Game: addappid(3513480)

-- MAIN APPLICATION
addappid(3513480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3513481, 1, "256681a3a3358b2c194ed262467d04edc4be6687f0da2f59c051299d024dc22e")
