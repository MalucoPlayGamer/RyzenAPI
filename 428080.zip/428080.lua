-- Lua provided by RyzenAPI
-- Game: AppID 428080

-- MAIN APPLICATION
addappid(428080)

-- MAIN APP DEPOTS / PACKAGES
addappid(428081, 1, "713cf125db093beece21c12454c6e82fdeb603ca846e5eb9f760596509c84ccc")

