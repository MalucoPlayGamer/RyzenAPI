-- Lua provided by RyzenAPI
-- Game: Racket: Nx

-- MAIN APPLICATION
addappid(428080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(428081, 1, "713cf125db093beece21c12454c6e82fdeb603ca846e5eb9f760596509c84ccc")
