-- Lua provided by RyzenAPI
-- Game: addappid(322610)

-- MAIN APPLICATION
addappid(322610)

-- MAIN APP DEPOTS / PACKAGES
addappid(322611, 1, "e07a9c94d49a59dabeb588c1effd0e68788e401333d2317693715f150e28e52c")
addappid(322612, 1, "6835339ae66e0f9e94a4f39bc0f38c91035cd8e41cff5506f0c5823c0f3fddca")
