-- Lua provided by RyzenAPI
-- Game: Dream Life in the Country Side

-- MAIN APPLICATION
addappid(3442040)
-- Game: addappid(3442040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3442041, 1, "e32be7205c393ad15198ebdd07964b3612a84c5c54871e864ca90bbf4cde39e2")
