-- Lua provided by RyzenAPI
-- Game: Battle Suit Aces

-- MAIN APPLICATION
addappid(2870530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870531,0,"ef0f08514098789e750352a93e39be905ffd94e115b0f1af85ebcf67a662e3c4")

