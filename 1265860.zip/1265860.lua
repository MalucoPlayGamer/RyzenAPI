-- Lua provided by RyzenAPI
-- Game: NASCAR Heat 5

-- MAIN APPLICATION
addappid(1265860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265861, 1, "d1fb947b5e4c2ae3e7a0f3a3c27f4c93cfe826d8a3bb8b4d54af380b079d6277")
addappid(1374660, 0, "ec4fd279bdc703a3dc19c22a9c36235b4d63fec331a00a6298821e4db526debf")
addappid(1387920, 0, "c83e12eeaf2699ffbe419d001371da6cfca3b6f43af5dc3d2370642d92f6df89")
addappid(1387921, 0, "36befe588eaaadd2355e4da0e54714d4e4f32032ad432c6aa6a2f437bc4b557a")
addappid(1387922, 0, "f8d4c752114146236b178d573aa184c56a889ab7b94150d93b84e1ed4f6762ba")
addappid(1462450, 0, "55d2ff037d67b3e6e50240a9d7dea0ecaa04c8a57cf9e213856fa7de5bfcee63")
addappid(1462451, 0, "29e8f239338bea97a5ab889015374059773ab6734463919d5547a3150ebc659c")
addappid(1486020, 0, "4513f237add65d1ca811fa9f480f61094b9a30d933c00a237992b92b45ba8bc2")
addappid(2119510, 0, "fe2eafb36dfa679f13da6ba0a02a48392bdb5ea0ca9fb22d8bfdb9cb191c0a9a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1268570)
addappid(1310310)
addappid(1310320)
