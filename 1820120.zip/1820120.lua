-- Lua provided by RyzenAPI
-- Game: addappid(1820120)

-- MAIN APPLICATION
addappid(1820120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820121, 1, "44cfeeb8be5c198d4b84c39e01bd2c65d9d925ed104b9ffd840a398e87fe5229")
