-- Lua provided by RyzenAPI
-- Game: Road Scars: Origins

-- MAIN APPLICATION
addappid(346500)

-- MAIN APP DEPOTS / PACKAGES
addappid(346501, 1, "7a25129d49c624f5c047209de31b622cf7f983d6db61d9c6d541bfe5d4256732")
addappid(346502, 1, "60e85808f3455cfe9f72cc1e4aa3829fff9557761ec62d13992b17f6af9dcd06")
addappid(838020, 0, "e7f2b9edd56c4dec184e978da59f038501806d6ccd3dc068789efc0ac13f60a6")

