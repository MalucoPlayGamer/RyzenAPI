-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(899907)
-- Game: addappid(899907)

-- MAIN APP DEPOTS / PACKAGES
addappid(899907,0,"3549adf88d6f2d42248ae018100afee3892ad710b5aab15280a6f4b4174c013a")
