-- Lua provided by RyzenAPI
-- Game: AppID 695100

-- MAIN APPLICATION
addappid(695100)
-- Game: addappid(695100)

-- MAIN APP DEPOTS / PACKAGES
addappid(695101, 1, "0cf7ed0658760c8560ad50e33d2ea3b16b44c4d27ba1d772eae2b9be81214346")
addappid(924730, 0, "0969ab3dfd9317348372ade52d92be0e2a78d4dfdd0c3c6358af8743611c820e")
