-- Lua provided by RyzenAPI
-- Game: Neko Hacker Plus

-- MAIN APPLICATION
addappid(1677180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1677181, 1, "4f3aa3766ccd3f3aa99f18e43bccc41d3b6ee089e9eeb76cd6329dfd45f1cd8d")
addappid(1679140, 0, "a4811d6c69e36ed7d5bcb47759f65ce8d47e99b888b2dbbf0e805b18115a1567")
addappid(1760780, 0, "7eb2863b87c6c8c83889ea28a66f8d0ae6cd8684f0d6b9515ffec1cd7974676e")

