-- Lua provided by RyzenAPI
-- Game: Once Upon a Galaxy

-- MAIN APPLICATION
addappid(3062740)

