-- Lua provided by RyzenAPI
-- Game: addappid(349270)

-- MAIN APPLICATION
addappid(349270)
addappid(1187880)

-- MAIN APP DEPOTS / PACKAGES
addappid(349271, 1, "e83e9c4740369fa6a27e274b27dbcbd23be3349ea449af8f16fb5338c07b5ee6")
addappid(349273, 1, "8d0f13bfeb6548af16fdc43f90a0cef080cb4d2b71fa2d236056f579c8d2ca3f")
addappid(349274, 1, "4c0eaa14432e4e61e8d3fb11bc8103fcfe88ae0b86edee11b8cc6f443c7ed707")
