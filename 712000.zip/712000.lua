-- Lua provided by RyzenAPI
-- Game: 712000

-- MAIN APPLICATION
addappid(712000)
addappid(712001)
addappid(712002)
addappid(712003)
addappid(712004)
addappid(712005)
addappid(712006)

-- MAIN APP DEPOTS / PACKAGES
addappid(712007,0,"02a7803fa9f5d7bc88bec6a2394f0482709eca0f0e987c2cde86bc3168e64e32")
