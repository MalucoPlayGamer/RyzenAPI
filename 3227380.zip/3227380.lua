-- Lua provided by RyzenAPI
-- Game: Tanks Racing Sim

-- MAIN APPLICATION
addappid(3227380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227381, 1, "e431989890256fd35d9990f5ca32248c14aec83bb8da8900a358f01e39c96cca")

