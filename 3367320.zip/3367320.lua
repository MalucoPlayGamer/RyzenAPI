-- Lua provided by RyzenAPI
-- Game: Bessie's Milk Delivery

-- MAIN APPLICATION
addappid(3367320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367322,0,"bebd983adfdfb79f1e0ede40f0b90fe19d5b8442b02e443a668439c342bd0502")

