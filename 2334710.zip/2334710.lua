-- Lua provided by RyzenAPI
-- Game: I was born poor

-- MAIN APPLICATION
addappid(2334710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334711, 1, "2797fb881dfff81d0149597966942dba10e851f43598dcd7d74ac25643b90300")

