-- Lua provided by RyzenAPI
-- Game: Windbound

-- MAIN APPLICATION
addappid(1162130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162131, 1, "e93b5c7761cc84b7584df71c15afa8583afd3b0788e1c115971854138f55bae0")
