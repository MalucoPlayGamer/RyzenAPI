-- Lua provided by RyzenAPI
-- Game: Fuck in police

-- MAIN APPLICATION
addappid(2812750)
addappid(2813780)
addappid(2813790)
addappid(2813800)
addappid(2813810)
addappid(2813820)
addappid(2813830)
addappid(2813840)
addappid(2813850)
addappid(2813860)
addappid(2813870)
addappid(2813880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812751, 1, "0ea90f95f6ab8e04ab85c0e095b1c7928543f1caf4f768033e785fb993a70803")

