-- Lua provided by RyzenAPI
-- Game: Hodgepodge Hunch

-- MAIN APPLICATION
addappid(2313160)
addappid(2865310)
addappid(3235900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313161, 1, "3c274771914696c53d8909f775dd2917f399ae9ad4a206a06d0c8407a12b5949")

