-- Lua provided by RyzenAPI
-- Game: Game: How Much Items - Tanks

-- MAIN APPLICATION
addappid(3471090)
-- Game: addappid(3471090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471091, 1, "f24bdf05eb8a69c8ac9f99e683c0ba95fd2958731568648ee0604ca4f9999c19")
