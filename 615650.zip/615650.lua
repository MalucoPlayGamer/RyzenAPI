-- Lua provided by RyzenAPI
-- Game: Game: The Professor Presents: #GotHandles

-- MAIN APPLICATION
addappid(615650)
-- Game: addappid(615650)

-- MAIN APP DEPOTS / PACKAGES
addappid(615651, 1, "a7878d1dc18401743f4a0c353e937b04be384f1f52651fa8329d8d56f0c5857a")
