-- Lua provided by RyzenAPI
-- Game: Poly Puzzle: Dogs

-- MAIN APPLICATION
addappid(1856730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856731, 1, "5f65e2cf1871355367a5ee7815e880f131ef907100c866fc257b89739d9191e8")
