-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Heroine Character Generator 4 for MZ

-- MAIN APPLICATION
addappid(1890441)
-- Game: addappid(1890441)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890441,0,"8ed2d4b39a447556608e206b7f89c889e899f32e7da8dd57009686d7f349b1fe")
