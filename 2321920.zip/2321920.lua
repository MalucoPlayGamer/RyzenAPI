-- Lua provided by RyzenAPI
-- Game: Game: Terra Nil Soundtrack

-- MAIN APPLICATION
addappid(2321920)
-- Game: addappid(2321920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321921, 1, "d7e0bead85e04144b11b025955e57bee60719ef6039763421f8df77e221324c0")
addappid(2321922, 1, "7652bc1e59b03e26923d7c4638c23042118b2130b773de128df3e411157370c3")
