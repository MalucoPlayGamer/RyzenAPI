-- Lua provided by SkyAPI 
-- Game: Terra Nil Soundtrack
addappid(2321920)
addappid(2321921, 1, "d7e0bead85e04144b11b025955e57bee60719ef6039763421f8df77e221324c0")
addappid(2321922, 1, "7652bc1e59b03e26923d7c4638c23042118b2130b773de128df3e411157370c3")
