-- Lua provided by RyzenAPI
-- Game: 3795560

-- MAIN APPLICATION
addappid(3795560)
-- Game: addappid(3795560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795561, 1, "ed367e78c991a592395a4a9d1bc225e14848fe86b4f3ec824ed67220fd72fea6")
