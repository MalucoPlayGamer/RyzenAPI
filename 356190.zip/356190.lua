-- Lua provided by RyzenAPI
-- Game: AppID 356190

-- MAIN APPLICATION
addappid(356190)
addappid(561630)
addappid(561631)
addappid(580030)
addappid(580090)
addappid(580500)
addappid(581770)
addappid(581771)
addappid(581772)
addappid(581773)
addappid(629580)
addappid(716270)
addappid(740710)
addappid(784070)
addappid(784870)
addappid(819920)
addappid(866850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(356191, 1, "260abd037eed772bf36b780e13d94ab075cc04f2f80fa4f3e39b907c037892ae")
addappid(533110, 0, "acd25e0fcc2aac0e70af4b8df205e6a8e8258823362cc5279c0aeaf96c3bf0b3")
addappid(561650, 0, "ad42072d011a1042b773c99fa9967be93667a884ce3c2f13cdc7d724f7f97276")
addappid(561950, 0, "b5325bbdf2c67fac37d9cffdd972e7306630fa3ce77980cca227726d314ed78d")
addappid(666840, 0, "d25e071b5d2da2b43e96908d43ebd3364908a5f141731e9482e79c0cf621344f")

