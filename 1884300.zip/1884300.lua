-- Lua provided by RyzenAPI
-- Game: addappid(1884300)

-- MAIN APPLICATION
addappid(1884300)
addappid(1913660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884301, 1, "4bda6f728176961cbd422ee28aac72c6e31a3c7c5028f2b40e6c2956626e811f")
