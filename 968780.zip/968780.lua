-- Lua provided by RyzenAPI
-- Game: Fairyland: Fairylines

-- MAIN APPLICATION
addappid(968780)

-- MAIN APP DEPOTS / PACKAGES
addappid(968781, 1, "f775601ae37445c2be1111617a21ddf461746628784eba8aa65969475c12d80d")
