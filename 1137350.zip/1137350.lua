-- Lua provided by RyzenAPI
-- Game: Filament

-- MAIN APPLICATION
addappid(1137350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137351, 1, "c70aeca04d007d3764519cb0d44437295e4ef1ab2c14f887b50c96f173e1582f")
addappid(1137352, 1, "4409c601d88587b225e90121898057514caf7eeca250e49e59012b7a40d01735")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1294800)
