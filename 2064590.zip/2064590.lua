-- Lua provided by RyzenAPI
-- Game: Pathfinder: Wrath of the Righteous – The Treasure of the Midnight Isles

-- MAIN APPLICATION
addappid(2064590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064591, 1, "bf6060c08264c2af171931854651cd93d7faba80f1ae5ad944f461caa9ce0f40")
addappid(2064592, 1, "a7baed388cf7c5b772067891998f3dfd2f10b49332fa5a4c9c1ed3d18cc0c86a")
