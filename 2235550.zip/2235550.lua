-- Lua provided by RyzenAPI
-- Game: 2235550

-- MAIN APPLICATION
addappid(2235550)
addappid(3693840)
-- Game: addappid(2235550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235551, 1, "4a3a833293d076add7bfbac51657b66e32afab7a33a40b173afef8d2d835cafb")
