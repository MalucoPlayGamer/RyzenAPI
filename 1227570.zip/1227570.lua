-- Lua provided by RyzenAPI
-- Game: AppID 1227570

-- MAIN APPLICATION
addappid(1227570)
addappid(1317180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227571, 1, "9581f9a4bc8e847cc78e7cd6d0f1cd82d839484adc763ada7044a8dfa23c8f1c")

