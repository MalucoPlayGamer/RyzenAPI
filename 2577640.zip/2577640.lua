-- Lua provided by RyzenAPI
-- Game: Multi Turret Academy: Prologue

-- MAIN APPLICATION
addappid(2577640)
-- Game: addappid(2577640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577641, 1, "62f12036a0bf4011695860ee8c3ea6b1cd479fb2df352360ce3309e2bd203a8f")
