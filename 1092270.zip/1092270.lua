-- Lua provided by SkyAPI 
-- Game: Hunt the Thailand Hidden
addappid(1092270)
addappid(1092271, 1, "df6c8c587978f5a72d8459e1aad92528f7120a558f2b0bc4e04edb7bf45c9f33")
