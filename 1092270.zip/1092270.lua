-- Lua provided by RyzenAPI
-- Game: Game: Hunt the Thailand Hidden

-- MAIN APPLICATION
addappid(1092270)
-- Game: addappid(1092270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092271, 1, "df6c8c587978f5a72d8459e1aad92528f7120a558f2b0bc4e04edb7bf45c9f33")
