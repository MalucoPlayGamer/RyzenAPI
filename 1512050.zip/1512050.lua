-- Lua provided by RyzenAPI 
-- Game: World Turtles
addappid(1512050)
addappid(1512051, 1, "0a4301ca7c3cda8ffcbd7c02f7739f54bc30680b0b623c5db7d340abcad82ece")
addappid(1512052, 1, "b1cdaee6f114f1add4126f0a932f4b8f3288c5941991af8cdc09c12f30f1a9f7")
addappid(1512053, 1, "6eaffbbe0f288a30f998d3df164fae78dd65373ac21f50dc4b6a527fe2de0391")
