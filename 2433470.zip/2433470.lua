-- Lua provided by RyzenAPI
-- Game: Romance Club - Stories I Play

-- MAIN APPLICATION
addappid(2433470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433471, 1, "ac667597d93736b83175f22d67c434f6c04f67dae653ff76076652028bb35bb4")

