-- Lua provided by RyzenAPI
-- Game: Hush Hush - 18+ Uncensored DLC

-- MAIN APPLICATION
addappid(2070760)
-- Game: addappid(2070760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070763,0,"f1bf9b4024178a76ece0f6ca6d62cbbecde6a335a36d7cd1137c69db3b245a8e")
