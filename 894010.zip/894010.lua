-- Lua provided by RyzenAPI
-- Game: Game: AppID 894010

-- MAIN APPLICATION
addappid(894010)
-- Game: addappid(894010)

-- MAIN APP DEPOTS / PACKAGES
addappid(894011, 1, "f41ad12ddc458e409cf2cf21ad1396dc4d8dc34a03d3e536aba7ec3c607ff455")
