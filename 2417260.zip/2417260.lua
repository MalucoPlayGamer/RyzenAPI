-- Lua provided by RyzenAPI
-- Game: Game: Deceived by the Host

-- MAIN APPLICATION
addappid(2417260)
-- Game: addappid(2417260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417261, 1, "aeca2190bf9ef77ffe26ecc34205563c63c33844dfe95e985ac94ceda199d222")
addappid(2417262, 1, "d6f52327dadb291eb696c3aa5544035bf5536fff12e617a0895497cfb3f8e226")
addappid(2417263, 1, "d764390faf5b84b676b647b34577df42b4da7382ee23b8958573b205a40c770d")
