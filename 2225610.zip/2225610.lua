-- Lua provided by RyzenAPI
-- Game: Ready, Steady, Ship!

-- MAIN APPLICATION
addappid(2225610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225611, 1, "87b7e2ef9260ef1e50f836dec07c0977970fed5f4de57f0859a9f567009e8adf")

