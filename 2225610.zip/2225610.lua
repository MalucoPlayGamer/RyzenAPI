-- Lua provided by SkyAPI 
-- Game: Ready, Steady, Ship!
addappid(2225610)
addappid(2225611, 1, "87b7e2ef9260ef1e50f836dec07c0977970fed5f4de57f0859a9f567009e8adf")
