-- Lua provided by RyzenAPI
-- Game: Cute Dark Elves - Artbook 18+

-- MAIN APPLICATION
addappid(1614800)
-- Game: addappid(1614800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614800,0,"3d49d2c36876070d6373af3c7a75653ab2517c5ba32e798e5dafd5679edd3945")
