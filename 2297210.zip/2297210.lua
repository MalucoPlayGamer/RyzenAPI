-- Lua provided by RyzenAPI
-- Game: Plungeroo

-- MAIN APPLICATION
addappid(2297210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2297211, 1, "da1dafc4942c38bad71da8518201675ff7f8db2c70deb532cb145bea3a15276b")
