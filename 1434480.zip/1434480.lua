-- Lua provided by RyzenAPI
-- Game: AppID 1434480

-- MAIN APPLICATION
addappid(1434480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434481, 1, "a4e304c5a768f37e3e52e54632aaa976970624ee3510536e27f1d79593a5f6a3")
addappid(1434482, 1, "5907da1bc4f051c2d884da897a9fa7a6c79c2dcd728a94818cf1918096dc9304")
addappid(1434483, 1, "e1c5253d9443b34b634afeb741740436184cc0d7f84c02ab07c0a736bb55e5c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2702160)
