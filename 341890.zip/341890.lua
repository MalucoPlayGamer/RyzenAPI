-- Lua provided by RyzenAPI
-- Game: AppID 341890

-- MAIN APPLICATION
addappid(341890)

-- MAIN APP DEPOTS / PACKAGES
addappid(341891, 1, "b3baf0eb561b52dcb7f4a42e8c48576b3ff1f992557cc612a78f215df32fb6f2")
addappid(341894, 1, "09caaa56b678c57890c546c85b42c45f8fc5916d2abb6d095df9e23ba77f6274")

