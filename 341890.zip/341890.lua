-- Lua provided by RyzenAPI
-- Game: Hitbox

-- MAIN APPLICATION
addappid(341890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(341891, 1, "b3baf0eb561b52dcb7f4a42e8c48576b3ff1f992557cc612a78f215df32fb6f2")
addappid(341894, 1, "09caaa56b678c57890c546c85b42c45f8fc5916d2abb6d095df9e23ba77f6274")
