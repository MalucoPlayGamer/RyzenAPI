-- Lua provided by RyzenAPI
-- Game: addappid(2202150)

-- MAIN APPLICATION
addappid(2202150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202151, 1, "cc298563988251a75443c9a1454a3396e6dfcd339dea10d7699f3a51d750b3ae")
