-- Lua provided by RyzenAPI
-- Game: Santa Simulator

-- MAIN APPLICATION
addappid(991480)

-- MAIN APP DEPOTS / PACKAGES
addappid(991481, 1, "5a7b3c2fb8da8444c849676dbce228ad587034a5e1e792e51ff9a7163822b5ab")

