-- Lua provided by RyzenAPI
-- Game: Jack the Barbarian

-- MAIN APPLICATION
addappid(852160)

-- MAIN APP DEPOTS / PACKAGES
addappid(852161, 1, "c71f9b79aff78488bc1cfb88eaf41f8848a8e7400fb5618afe933b283e692f59")

