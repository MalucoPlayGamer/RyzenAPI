-- Lua provided by RyzenAPI
-- Game: Dark Arcana: The Carnival

-- MAIN APPLICATION
addappid(284730)
-- Game: addappid(284730)

-- MAIN APP DEPOTS / PACKAGES
addappid(284731, 1, "ebce26abd7da9ef6387363dc6bd4de034376732fa18cc499b31bbeac10909f0c")
addappid(284732, 1, "d28490f58f96b5a26188f200ca99d754c8d940402ffca815a02e265ad682b546")
addappid(284733, 1, "bc4044e2fc1637757cc1a2da6230c0aea8a456b9f9a8e3519c44e80e0663301e")
