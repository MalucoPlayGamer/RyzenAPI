-- Lua provided by RyzenAPI
-- Game: 汽车帝国

-- MAIN APPLICATION
addappid(1607310)
-- Game: addappid(1607310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607311, 1, "395c78c33b9ede2a76725fa278e70b70db139d4646601acf94bae9e8c835a143")
