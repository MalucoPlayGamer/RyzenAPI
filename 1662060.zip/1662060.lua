-- Lua provided by RyzenAPI
-- Game: Moon Farming - Prologue

-- MAIN APPLICATION
addappid(1662060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662061, 1, "c4010aeb3a70880e89a4ddbb651e5ec9e93a71d5c6b6109a9f2dc5ddc24880e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
