-- Lua provided by RyzenAPI
-- Game: 1662060

-- MAIN APPLICATION
addappid(1662060)
-- Game: addappid(1662060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662061, 1, "c4010aeb3a70880e89a4ddbb651e5ec9e93a71d5c6b6109a9f2dc5ddc24880e8")
