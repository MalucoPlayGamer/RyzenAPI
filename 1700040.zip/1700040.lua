-- Lua provided by RyzenAPI
-- Game: Neon Nights Pinball

-- MAIN APPLICATION
addappid(1700040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700041, 1, "21de592ac29e6cdee4d5338be60e597549ef197eb96d03a4e7645b90e6b01092")
