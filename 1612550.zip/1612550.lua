-- Lua provided by RyzenAPI
-- Game: 1612550

-- MAIN APPLICATION
addappid(1612550)
-- Game: addappid(1612550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612551, 1, "350e03a01a4b84c6bcebdaa744a4872b2fa4783a1f9da29ae24dae3319504e1f")
