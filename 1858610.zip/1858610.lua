-- Lua provided by RyzenAPI
-- Game: My Cute Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1858610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858610,0,"0e9a9d9abf843c9f422f845bd4636b021942579a907e0b64c8f0cd638566dd87")

