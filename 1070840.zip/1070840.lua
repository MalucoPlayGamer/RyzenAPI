-- Lua provided by RyzenAPI
-- Game: AppID 1070840

-- MAIN APPLICATION
addappid(1070840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070841, 1, "f42add96bcd64fccafea30625be2ff79cfa98d627fbc5244493d2df939b6c927")
