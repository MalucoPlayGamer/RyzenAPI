-- Lua provided by RyzenAPI
-- Game: BlackHoopS

-- MAIN APPLICATION
addappid(937770)

-- MAIN APP DEPOTS / PACKAGES
addappid(937773,0,"8bc6ecf016f2173510faf0e073d929a1b647cff0cec25d9e44a6e17d7402c331")
