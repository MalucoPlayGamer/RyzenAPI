-- Lua provided by RyzenAPI
-- Game: Oozing Islands

-- MAIN APPLICATION
addappid(1680380)
-- Game: addappid(1680380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680381, 1, "a72b110da530d3ae5eff87a372d2dc27da9b3e167aeed12402fd496cbb233f37")
