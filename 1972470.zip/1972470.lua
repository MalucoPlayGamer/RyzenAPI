-- Lua provided by RyzenAPI
-- Game: Under Contract

-- MAIN APPLICATION
addappid(1972470)
-- Game: addappid(1972470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972471, 1, "1549e8e73488583468f6a9fcdf615fa1e3a6bd62a89764ebdb18005d03182fe7")
