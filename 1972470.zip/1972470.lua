-- Lua provided by RyzenAPI 
-- Game: Under Contract
addappid(1972470)
addappid(1972471, 1, "1549e8e73488583468f6a9fcdf615fa1e3a6bd62a89764ebdb18005d03182fe7")
