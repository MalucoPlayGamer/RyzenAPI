-- Lua provided by RyzenAPI 
-- Game: Minesweeper & Dungeon RPG - 扫雷与地下城
addappid(3156010)
addappid(3156011, 1, "b7ff720de094aaddeb92cc79f94ec4311e7a20b86b9e25d5993ddf001b7b77e5")
