-- Lua provided by RyzenAPI
-- Game: Game: AppID 1178790

-- MAIN APPLICATION
addappid(1178790)
-- Game: addappid(1178790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178791, 1, "83a0b55b7617bf9b5b5486d119ad8149889388e6e6623448878596ff4ebbad46")
