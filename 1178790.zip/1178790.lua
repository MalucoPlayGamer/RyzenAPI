-- Lua provided by RyzenAPI
-- Game: Shiren the Wanderer: The Tower of Fortune and the Dice of Fate

-- MAIN APPLICATION
addappid(1178790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1178791, 1, "83a0b55b7617bf9b5b5486d119ad8149889388e6e6623448878596ff4ebbad46")

