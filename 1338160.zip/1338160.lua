-- Lua provided by RyzenAPI
-- Game: 1338160

-- MAIN APPLICATION
addappid(1338160)
-- Game: addappid(1338160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338161, 1, "a6efb533b08ca94b8f7bde21161cd02b93d8800fcdd5791484e80606ef3aa2fe")
