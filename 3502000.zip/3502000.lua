-- Lua provided by RyzenAPI
-- Game: Try them all!

-- MAIN APPLICATION
addappid(3502000)
-- Game: addappid(3502000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3502001, 1, "31db9a2f319dc25762c6cd69bed9aefd17e6e4eff92ca094ba7e64164ec63526")
