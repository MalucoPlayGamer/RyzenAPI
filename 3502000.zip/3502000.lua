-- Lua provided by RyzenAPI
-- Game: Try them all!

-- MAIN APPLICATION
addappid(3502000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3502001, 1, "31db9a2f319dc25762c6cd69bed9aefd17e6e4eff92ca094ba7e64164ec63526")

