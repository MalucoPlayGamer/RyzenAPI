-- Lua provided by RyzenAPI
-- Game: addappid(2846250)

-- MAIN APPLICATION
addappid(2846250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846251, 1, "3212838e95a1ab37e15cebf05b346b68d8e76bbff963cd7e65091f159e71b30d")
