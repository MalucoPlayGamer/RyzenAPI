-- Lua provided by RyzenAPI
-- Game: THE LAST SURVIVOR

-- MAIN APPLICATION
addappid(989540)
-- Game: addappid(989540)

-- MAIN APP DEPOTS / PACKAGES
addappid(989541, 1, "1efaa83c8ed632946b793d0facf3926394593f7cccbf6a779f758aeb27655701")
