-- Lua provided by RyzenAPI
-- Game: ARK: Survival Evolved

-- MAIN APPLICATION
addappid(346110)
addappid(473850)
addappid(508150)
addappid(512540)
addappid(642250)
addappid(696680)
addappid(696680) -- ARK Survival Evolved Season Pass
addappid(708770)
addappid(887380)
addappid(1100810)
addappid(1113410)
addappid(1270830)
addappid(1691800)
addappid(1887560)
addappid(3537070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(346110, 1, "e16ff7f08225d9ae3635a98833a1c63acc58b2a104b0b37a9605d494683787be") -- ARK: Survival Evolved
addappid(346111, 1, "5edb307972cd5bf1e3081aedc986ef721dfd27cae16d0a976c6b7ea6e8ff2089")
addappid(346111, 1, "5edb307972cd5bf1e3081aedc986ef721dfd27cae16d0a976c6b7ea6e8ff2089") -- ARK: Survival Evolved Content
addappid(346113, 1, "3cde616ad9b9f9def5512691fe0a3ba1dfe8a6d773e68ea3b01f73b5f4f5a6bd")
addappid(346113, 1, "3cde616ad9b9f9def5512691fe0a3ba1dfe8a6d773e68ea3b01f73b5f4f5a6bd") -- ARK: Survival Evolved Content Mac OS X
addappid(346114, 1, "d8d49ab98f0f7530c0c2926213c7ac64625712a2efbbc96e6b3f06943741f806")
addappid(346114, 1, "d8d49ab98f0f7530c0c2926213c7ac64625712a2efbbc96e6b3f06943741f806") -- The Center - ARK Expansion Map - TheCenter ARK Expansion Windows
addappid(346115, 1, "32f03ae1bf21e71fbd0361230a6442e2a221bbfced8fdb4fd37b7ab0225cb99c")
addappid(346115, 1, "32f03ae1bf21e71fbd0361230a6442e2a221bbfced8fdb4fd37b7ab0225cb99c") -- The Center - ARK Expansion Map - The Center ARK Expansion Mac
addappid(346117, 1, "5a2bbc7508560b4d6f663c0db1923379ce85a1d08ac9750e64bdb821968e5245")
addappid(346117, 1, "5a2bbc7508560b4d6f663c0db1923379ce85a1d08ac9750e64bdb821968e5245") -- Primitive - ARK Total Conversion - Primitive+ Windows
addappid(346118, 1, "8cffc3c5d721b966af7b470e8ed392cb0440ca975c4f28c6b20bbb0ae437d903")
addappid(346118, 1, "8cffc3c5d721b966af7b470e8ed392cb0440ca975c4f28c6b20bbb0ae437d903") -- Primitive - ARK Total Conversion - Primitive+ Mac
addappid(375351, 0, "80573113a7bf294555b4c8e4e041c69e7a5a69527a4b65d3ce6f47c2382488a7")
addappid(375351, 1, "80573113a7bf294555b4c8e4e041c69e7a5a69527a4b65d3ce6f47c2382488a7") -- ARK Scorched Earth - Expansion Pack - Scorched Earth Expansion Pack - Windows
addappid(375352, 0, "4165ab1d0803718ec4e69bdea9e03cdb00d9be97d60761600f69aa02635a6818")
addappid(375352, 1, "4165ab1d0803718ec4e69bdea9e03cdb00d9be97d60761600f69aa02635a6818") -- ARK Scorched Earth - Expansion Pack - Scorched Earth Expansion Pack - Mac
addappid(375354, 0, "e2fa71e01810bbd554e94713e84efb084e0a99ff78f21fba3c201410f74e9a19")
addappid(375354, 1, "e2fa71e01810bbd554e94713e84efb084e0a99ff78f21fba3c201410f74e9a19") -- Ragnarok - ARK Expansion Map - Content Depot Windows
addappid(375355, 0, "538aa57c154732fc995904719ff0ae3ebde300e4f4d6be40ec1241b6abef9c54")
addappid(375355, 1, "538aa57c154732fc995904719ff0ae3ebde300e4f4d6be40ec1241b6abef9c54") -- Ragnarok - ARK Expansion Map - Content Depot Mac
addappid(375357, 0, "9bc45b9b59f3f32154ee76b47ff8b6015e92d5a6342c444bed3eb210bcd24b60")
addappid(375357, 1, "9bc45b9b59f3f32154ee76b47ff8b6015e92d5a6342c444bed3eb210bcd24b60") -- ARK Aberration - Expansion Pack - New Content Windows
addappid(375358, 0, "380b1dd0c8d2a98996c20021513e4af8768d5c1c19b0299d428c149ea6419be0")
addappid(375358, 1, "380b1dd0c8d2a98996c20021513e4af8768d5c1c19b0299d428c149ea6419be0") -- ARK Aberration - Expansion Pack - New Content Mac
addappid(473851, 0, "99fb597107882942ca94e2038215f03f8707d57b059460ec6bde8265bf020733")
addappid(473851, 1, "99fb597107882942ca94e2038215f03f8707d57b059460ec6bde8265bf020733") -- ARK Extinction - Expansion Pack - Newest Content Windows
addappid(473852, 0, "cf96b8769d1734315042b0239dd110a83d831f4da2cfcc6066d52dd26e294069")
addappid(473852, 1, "cf96b8769d1734315042b0239dd110a83d831f4da2cfcc6066d52dd26e294069") -- ARK Extinction - Expansion Pack - Newest Content Mac
addappid(473854, 0, "dac71f84f6dd940b7bfe12e5df2bb98eff8ba622d76c30091c52ecfd60bbf334")
addappid(473854, 1, "dac71f84f6dd940b7bfe12e5df2bb98eff8ba622d76c30091c52ecfd60bbf334") -- Valguero - ARK Expansion Map - Digiorno Windows
addappid(473855, 0, "f4ab0847fc2c5a996d0dd7e62142319b91e057364458f627065a679042de5cf2")
addappid(473855, 1, "f4ab0847fc2c5a996d0dd7e62142319b91e057364458f627065a679042de5cf2") -- Valguero - ARK Expansion Map - Digiorno Mac
addappid(473857, 0, "c9bb21644270fd6883bc3f007aa66f625ea3281ad2196900dfbbdf12ceb58ce2")
addappid(473857, 1, "c9bb21644270fd6883bc3f007aa66f625ea3281ad2196900dfbbdf12ceb58ce2") -- ARK Genesis Season Pass - 9035768 Windows
addappid(473858, 0, "41f8a645e812903465d0edae936402edbec301d6e0704cddc3192e6a661dc133")
addappid(473858, 1, "41f8a645e812903465d0edae936402edbec301d6e0704cddc3192e6a661dc133") -- ARK Genesis Season Pass - 9035768 Mac
addappid(512541, 0, "267b9da1ca97290bf9311789c2c78a0226dc149b33b708f638318bffb9466d07")
addappid(642251, 0, "000551f44eb27848ac700992f1cc63b8647dd6ff487f61be75d715690f7ffaa8")
addappid(708771, 0, "7a010e1818b19197008fec7530f81134496e048b22799ab8dbaa15afc934640b")
addappid(887381, 0, "9ee1587cedb1f2530eedff959f611469b80c52a19d671aaf5ca90c9b8cf2923f")
addappid(1100811, 0, "b79b9927e9dc5b5e4a01d8bd53ca4fd403aa3e00a6d9b328df9517e17eb5b741")
addappid(1113411, 0, "fabb760fd389664584fd71e1f32755adcae789c57c7080d91f8a46e1a660bae3")
addappid(1270831, 0, "9db4e7056d0b077245b0193c7efee5978c425e8a3e4bf2946fdca79a09358829")
addappid(1318680, 0, "4d062d18a7fe719d0a98a1025f680ac6ef26cb347f030a51453c02dcd8351916")
addappid(1318685, 0, "323f243a7ced4f90628ba9da901ca96302350c23c625153d21425d93df0a62cf")
addappid(1318685, 1, "323f243a7ced4f90628ba9da901ca96302350c23c625153d21425d93df0a62cf") -- Crystal Isles - ARK Expansion Map - HotPocketz Windows
addappid(1318686, 0, "dd79aabbad1a2c16599b9c57ea58081e50c7ebd49a68a445823000c509361a43")
addappid(1318686, 1, "dd79aabbad1a2c16599b9c57ea58081e50c7ebd49a68a445823000c509361a43") -- Crystal Isles - ARK Expansion Map - HotPocketz Mac
addappid(1691801, 0, "db89fe99710be8d80b85377d37210487dbce8b9bfb8e90767f97e138d3e0206e")
addappid(1691801, 1, "db89fe99710be8d80b85377d37210487dbce8b9bfb8e90767f97e138d3e0206e") -- Lost Island - ARK Expansion Map - PizzaRollz Windows
addappid(1691802, 0, "c8ad6983cc292e1bacdb1b413aef29dd704430d075258337a58edf62a8d04fd6")
addappid(1691802, 1, "c8ad6983cc292e1bacdb1b413aef29dd704430d075258337a58edf62a8d04fd6") -- Lost Island - ARK Expansion Map - PizzaRollz Mac
addappid(1691805, 0, "f926b2b5de3cc1a5f85b15e97ea6bac7a123a0a986d32cf3f77669e4b65ebc44")
addappid(1887561, 0, "a3f5aa53c16af324c6b57326578ce7a4341c7aef7a14ff52ccfa35cba9fccbc7")
addappid(1887561, 1, "a3f5aa53c16af324c6b57326578ce7a4341c7aef7a14ff52ccfa35cba9fccbc7") -- Fjordur - ARK Expansion Map - Lemonbar Windows
addappid(1887562, 0, "9412a47f669490322d818e4b5d4d184fae7b3ac2ee0db526751f9da74ecd8901")
addappid(1887562, 1, "9412a47f669490322d818e4b5d4d184fae7b3ac2ee0db526751f9da74ecd8901") -- Fjordur - ARK Expansion Map - Lemonbar Mac
addappid(1887565, 0, "1cfee4900783d7c2b56c8aa3288ade97d875296edb363cf38f307d1706c6da1b")
addappid(3537070, 0, "9a07e220390d63d22b6fca95fca32f71bcad2d28494d72ee2c79b5afcb84c473")
addappid(3537070, 1, "9a07e220390d63d22b6fca95fca32f71bcad2d28494d72ee2c79b5afcb84c473") -- Aquatica - ARK Expansion Map - Depot 3537070

