-- Lua provided by RyzenAPI
-- Game: setManifestid(2649192,"1337265187116192941")

-- MAIN APPLICATION
addappid(2649190)
-- Game: addappid(2649190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649192,0,"db69c54a38f29ef8c4a72a7007e25332b85cdd7d980964d397f5aacd613845e6")
