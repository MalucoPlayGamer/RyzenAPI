-- Lua provided by RyzenAPI
-- Game: Y. Village - The Visitors

-- MAIN APPLICATION
addappid(2649190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649192,0,"db69c54a38f29ef8c4a72a7007e25332b85cdd7d980964d397f5aacd613845e6")

