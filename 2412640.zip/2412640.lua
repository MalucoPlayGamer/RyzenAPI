-- Lua provided by RyzenAPI
-- Game: Another Day

-- MAIN APPLICATION
addappid(2412640)
-- Game: addappid(2412640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412641, 1, "d250668d101fbc630df9edeab362d4f7a06b0dc935635254545da08ea3d3d8e1")
