-- Lua provided by RyzenAPI
-- Game: Expansion VR

-- MAIN APPLICATION
addappid(2669520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669521, 1, "af21b07a830ded3934d3e654bed2358f976babe8d5e38b4c545ac1951007d79a")

