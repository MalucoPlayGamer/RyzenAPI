-- Lua provided by RyzenAPI
-- Game: 白娘子

-- MAIN APPLICATION
addappid(1989920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1989921, 1, "6d6f62dbd1e0b5d971ebdb4463f2675c4bd9e7bebcd1777389701395c6052bc9")

