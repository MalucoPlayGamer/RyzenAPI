-- Lua provided by RyzenAPI
-- Game: Game: 白娘子

-- MAIN APPLICATION
addappid(1989920)
-- Game: addappid(1989920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989921, 1, "6d6f62dbd1e0b5d971ebdb4463f2675c4bd9e7bebcd1777389701395c6052bc9")
