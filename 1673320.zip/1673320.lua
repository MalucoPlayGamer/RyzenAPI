-- Lua provided by RyzenAPI
-- Game: addappid(1673320)

-- MAIN APPLICATION
addappid(1673320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673321, 1, "a2485ce14b59e21c1e95fecc200d1eab3461d1dfd8188bb847de19a1177853e3")
