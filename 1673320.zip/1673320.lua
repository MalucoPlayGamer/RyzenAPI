-- Lua provided by RyzenAPI
-- Game: Survivor

-- MAIN APPLICATION
addappid(1673320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1673321, 1, "a2485ce14b59e21c1e95fecc200d1eab3461d1dfd8188bb847de19a1177853e3")

