-- Lua provided by RyzenAPI
-- Game: Zenith

-- MAIN APPLICATION
addappid(438420)

-- MAIN APP DEPOTS / PACKAGES
addappid(438421, 1, "a793e11af095a43fa085ff68d1529c07994365f97ca77c8390ebbef6e193dc22")

