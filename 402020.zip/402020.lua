-- Lua provided by RyzenAPI
-- Game: The Park®

-- MAIN APPLICATION
addappid(402020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(402021, 1, "965b7740342886093003e1806ddb24128695974f0c0b2621e5d6adfc6c458cc0")

