-- Lua provided by RyzenAPI
-- Game: The Park®

-- MAIN APPLICATION
addappid(402020)
-- Game: addappid(402020)

-- MAIN APP DEPOTS / PACKAGES
addappid(402021, 1, "965b7740342886093003e1806ddb24128695974f0c0b2621e5d6adfc6c458cc0")
