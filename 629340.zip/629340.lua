-- Lua provided by RyzenAPI
-- Game: 629340

-- MAIN APPLICATION
addappid(629340)

-- MAIN APP DEPOTS / PACKAGES
addappid(629342,0,"431e1b83ff13cebdf1c7d21aa45dc9cccfba3041ffc89942c8cae298137c105d")

