-- Lua provided by RyzenAPI
-- Game: Aperion Cyberstorm

-- MAIN APPLICATION
addappid(492860)

-- MAIN APP DEPOTS / PACKAGES
addappid(492861, 1, "ed15dcb09b1c235b613d21255104b340faa1e43f446c164e8bd46cddf3a09db8")

