-- Lua provided by RyzenAPI
-- Game: Neongarten

-- MAIN APPLICATION
addappid(3211750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211751, 1, "3121c2519e84fee9198b24182e49a914b770d64f79f4a26738f420c3cb01fea7")
