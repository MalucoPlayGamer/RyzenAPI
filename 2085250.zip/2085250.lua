-- Lua provided by RyzenAPI
-- Game: Lunar Soil Playtest

-- MAIN APPLICATION
addappid(2085250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085251, 1, "42b59c6d518bc5e4fcdc7dc34865245eb6c08eb41d40b9b7a5987a199dd6b61c")

