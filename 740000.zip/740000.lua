-- Lua provided by RyzenAPI
-- Game: 绝境幸存者 Escape Zombie Land

-- MAIN APPLICATION
addappid(740000)

-- MAIN APP DEPOTS / PACKAGES
addappid(740001, 1, "c7b9884afb3a18221e7dc874ba54e84b44387755b75acaa19182f82eb8a5f367")
