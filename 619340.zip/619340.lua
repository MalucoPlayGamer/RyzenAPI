-- Lua provided by RyzenAPI
-- Game: Game: EGOS - Tales of Fallen Souls

-- MAIN APPLICATION
addappid(619340)
-- Game: addappid(619340)

-- MAIN APP DEPOTS / PACKAGES
addappid(619341, 1, "9dac26c0e403d044f79fc24b2d6cc6a44aeb8cef4601361b4f7b2506e2cdbd53")
addappid(619342, 1, "ace66c45d1bc040d28d7df5d433c22056f5c57400a48e26f43868ba57349c9c9")
addappid(619343, 1, "8391849fe36c2250efa58d413c9d97dce49947e975eaef172c6cc84ecff3fa5b")
addappid(746980, 0, "6c21730d222a5386f845fda1c951fdc3932d66b0a8104e1f55310ca96074dd97")
addappid(854430, 0, "d0a8fe32f3339be039513fa540ee441a2e5996b82cd8167adee392b59813076f")
