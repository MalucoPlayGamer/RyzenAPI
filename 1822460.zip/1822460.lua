-- Lua provided by RyzenAPI
-- Game: Pwnk: Stream Battle Royale

-- MAIN APPLICATION
addappid(1822460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822461, 1, "b0b8bba7b225c2f91541c756db3fd79230ca390e8aa778d01e284b1e3cff83e1")
