-- 4186750's Lua and Manifest Created by Hubcap Manifest
-- HOT ASSES
-- Created: August 17, 2026 at 14:25:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4186750) -- HOT ASSES
-- MAIN APP DEPOTS
addappid(4186751, 1, "68d2a2c4dfd8daae510844de070ad93c9177afce9fd12688ab951b31704813c5") -- Depot 4186751
setManifestid(4186751, "3086663761467775263", 332445813)