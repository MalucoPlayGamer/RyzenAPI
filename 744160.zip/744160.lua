-- Lua provided by RyzenAPI
-- Game: addappid(744160)

-- MAIN APPLICATION
addappid(228986)
addappid(744160)
addappid(744161)

-- MAIN APP DEPOTS / PACKAGES
addappid(744162,0,"a7445d73a8fc4a9791ee25e5996bf741b79f283e0d893468ced8036e87753c85")
