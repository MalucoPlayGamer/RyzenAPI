-- Lua provided by RyzenAPI
-- Game: Game: AppID 1000470

-- MAIN APPLICATION
addappid(1000470)
-- Game: addappid(1000470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000471, 1, "26af513042851d029a4543ecc754f325c032ca7724c7e3ca46a3b5303847a9e1")
