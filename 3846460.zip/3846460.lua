-- Lua provided by RyzenAPI
-- Game: Monument Valley 3 - Original Soundtrack

-- MAIN APPLICATION
addappid(3846460)
-- Game: addappid(3846460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3846461, 1, "92e455b32f0aa0549e215eea41bbf6733438b7f1689ab7d4950741167d24cee9")
addappid(3846462, 1, "9789597a2190cc623a1bd273b7f37f47b30580980121c251c7e3dd1d4686f87d")
