-- Lua provided by RyzenAPI
-- Game: Jump, Dodge, Die, Repeat

-- MAIN APPLICATION
addappid(2389940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389941, 1, "92702ab2cd13408a2a10549353e089c109c72fce220962f13115d62ff35c7fb6")

