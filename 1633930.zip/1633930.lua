-- Lua provided by RyzenAPI
-- Game: addappid(1633930)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1633930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633932,0,"6a2dff556f4d01cc0f1e8d0a551c2723a954196f8f84a9b3f2745f4b6d4a9308")
addappid(1633933,0,"1f698f654fb74a6edaca07af49332058f19d81282cfb6c106fc6afd7efef2e6c")
