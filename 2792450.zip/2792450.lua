-- Lua provided by SkyAPI 
-- Game: Backrooms: Partygoers
addappid(2792450)
addappid(2792451, 1, "75bc7cbe02dc0af8405ff1f98455f31a6c4e1945776da649c281a8b0c52161c9")
