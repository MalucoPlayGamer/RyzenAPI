-- Lua provided by RyzenAPI
-- Game: addappid(2792450)

-- MAIN APPLICATION
addappid(2792450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2792451, 1, "75bc7cbe02dc0af8405ff1f98455f31a6c4e1945776da649c281a8b0c52161c9")
