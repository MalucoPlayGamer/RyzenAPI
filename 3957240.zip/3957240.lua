-- Lua provided by RyzenAPI
-- Game: Sail Girl

-- MAIN APPLICATION
addappid(3957240)
addappid(4074540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3957241,0,"af9b9897bdd4e4f63f2182e89dc8aef2f78249e4b17dd4f47b1b1f8da2a4426e")

