-- Lua provided by SkyAPI 
-- Game: AppID 1305440
addappid(1305440)
addappid(1305441, 1, "eaec19d11adb4ce8e40399205c77930cf8d110d380f4e8f5aac539b51c27a215")
addappid(1305442, 1, "661b83dc416cfaa1d51f576ccbea6a7604925381defeff6cd2f225a030bb8cab")
