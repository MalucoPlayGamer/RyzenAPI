-- Lua provided by RyzenAPI
-- Game: AppID 1305440

-- MAIN APPLICATION
addappid(1305440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305441, 1, "eaec19d11adb4ce8e40399205c77930cf8d110d380f4e8f5aac539b51c27a215")
addappid(1305442, 1, "661b83dc416cfaa1d51f576ccbea6a7604925381defeff6cd2f225a030bb8cab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
