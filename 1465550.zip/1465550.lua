-- Lua provided by SkyAPI 
-- Game: One Lonely Outpost
addappid(1465550)
addappid(1465551, 1, "d1fbf1bf0079cb20a0887561780ae1c476d124b71e6f8658dbbdab8de7f325c6")
