-- Lua provided by RyzenAPI
-- Game: One Lonely Outpost

-- MAIN APPLICATION
addappid(1465550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465551, 1, "d1fbf1bf0079cb20a0887561780ae1c476d124b71e6f8658dbbdab8de7f325c6")
