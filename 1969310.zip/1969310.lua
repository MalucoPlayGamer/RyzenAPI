-- Lua provided by RyzenAPI
-- Game: addappid(1969310)

-- MAIN APPLICATION
addappid(1969310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969311, 1, "8d63241056e626a16cd1655bec19a2cc617ec067fef464da4954a5920e94fe00")
