-- Lua provided by RyzenAPI
-- Game: Blood and Bacon

-- MAIN APPLICATION
addappid(434570)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(434571, 1, "ad7814e149bef4d6db5bc73964c3cbd64d313e7c77f6eea5076c5b826a4226c3")

