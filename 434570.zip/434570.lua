-- Lua provided by RyzenAPI
-- Game: AppID 434570

-- MAIN APPLICATION
addappid(434570)

-- MAIN APP DEPOTS / PACKAGES
addappid(434571, 1, "ad7814e149bef4d6db5bc73964c3cbd64d313e7c77f6eea5076c5b826a4226c3")

