-- Lua provided by RyzenAPI
-- Game: night nite

-- MAIN APPLICATION
addappid(2707970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707971, 1, "a77ec69e1bfa49a3f89b34bc5e298f8982ac26f3c4f429159e7b6e932079f1c3")
addappid(2707973, 1, "6bdfd5995fc38d61237c6986af0bc49c17b576cce2de40103bf0f6a28287dac0")
addappid(2707974, 1, "c5821b805bb7a5d81ba913cbf60780d27a0d86bd9ec6bcbea93eabe045c08d7f")
