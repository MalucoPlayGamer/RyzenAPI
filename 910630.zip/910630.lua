-- Lua provided by RyzenAPI
-- Game: Arcade Spirits

-- MAIN APPLICATION
addappid(910630)
-- Game: addappid(910630)

-- MAIN APP DEPOTS / PACKAGES
addappid(910631, 1, "2bf2600edaabacbf5e40d51285545b99b6445a1564f4ff7587e6e6bc11c7f2e6")
addappid(1009711, 0, "db65636e389507230ef9746e4cf4d38d9604d628fa19a9d7db9d8cada864122e")
