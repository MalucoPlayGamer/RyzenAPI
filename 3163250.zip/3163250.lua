-- Lua provided by RyzenAPI
-- Game: 44 Hidden Naomis Demo

-- MAIN APPLICATION
addappid(3163250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163251, 1, "ededf8d0476e62278d84894dba1ea07d58decf86431589702b9f72aaa966e804")
addappid(3163254, 1, "b9376761890fbf5f46ec7402c094158df67a6093e2ab7d3fa328081f2c7ca4c6")
