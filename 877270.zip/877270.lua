-- Lua provided by RyzenAPI
-- Game: The Pirates of Sector 7

-- MAIN APPLICATION
addappid(877270)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(877271, 1, "69e8650d60c57857bf722300787a57b49a9997344aa1d330bf13cdf3ccc230f7")

