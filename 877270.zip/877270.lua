-- Lua provided by RyzenAPI
-- Game: Game: The Pirates of Sector 7

-- MAIN APPLICATION
addappid(877270)
-- Game: addappid(877270)

-- MAIN APP DEPOTS / PACKAGES
addappid(877271, 1, "69e8650d60c57857bf722300787a57b49a9997344aa1d330bf13cdf3ccc230f7")
