-- Lua provided by RyzenAPI
-- Game: BAIKO

-- MAIN APPLICATION
addappid(843530)

-- MAIN APP DEPOTS / PACKAGES
addappid(843531, 1, "b57be835d86b917de2de1c917513f385c4377d2dec6dd63de68a6c910c76665b")

