-- Lua provided by RyzenAPI
-- Game: AppID 361110

-- MAIN APPLICATION
addappid(361110)
-- Game: addappid(361110)

-- MAIN APP DEPOTS / PACKAGES
addappid(361111, 1, "9973809ecc67ef25630c7df1dc20db34efb4f1005edb296b58888a651eba9939")
