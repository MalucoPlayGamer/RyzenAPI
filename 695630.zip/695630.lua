-- Lua provided by RyzenAPI
-- Game: addappid(695630)

-- MAIN APPLICATION
addappid(695630)

-- MAIN APP DEPOTS / PACKAGES
addappid(695631, 1, "5aebf9a9bc60ae419cc76c3376703aa58fdb5e3632fd29f9100a4ffe190b9c25")
