-- Lua provided by RyzenAPI
-- Game: Chinese Paladin：Sword and Fairy

-- MAIN APPLICATION
addappid(695630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(695631, 1, "5aebf9a9bc60ae419cc76c3376703aa58fdb5e3632fd29f9100a4ffe190b9c25")
