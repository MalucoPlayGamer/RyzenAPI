-- Lua provided by RyzenAPI
-- Game: DFF NT: Squall Leonhart Starter Pack

-- MAIN APPLICATION
addappid(1022460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022460,0,"1a2aa7eb0f3fe4de5e21dacc91b97e92716e1e3cb994d6927a471be36c0c1afc")
