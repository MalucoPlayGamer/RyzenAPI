-- Lua provided by RyzenAPI
-- Game: Space Drilling Station Demo

-- MAIN APPLICATION
addappid(2418210)
-- Game: addappid(2418210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418211, 1, "5d33bace5b76391d07e733d0f17903cced0c6c72c443c19b09ba485df1d4620b")
