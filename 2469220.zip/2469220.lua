-- Lua provided by RyzenAPI
-- Game: Trine 5: A Clockwork Conspiracy Soundtrack

-- MAIN APPLICATION
addappid(2469220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469221, 1, "9163c9ad5efaba4546c77351ab078eb0c89cad1b370ce1ccb2d4f68a18b65e9b")
addappid(2469222, 1, "829896ae9162156d7743831a5ee06a92931cb56648c58708bcb2fca3ac29de60")
