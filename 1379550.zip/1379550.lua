-- Lua provided by RyzenAPI
-- Game: The USB Stick Found in the Grass

-- MAIN APPLICATION
addappid(1379550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379551, 1, "cdc39163de66e2cd7fb3f73133c3db7fb9f97d127948deba79b23f3f19c8ecbb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
