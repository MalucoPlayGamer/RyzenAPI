-- Lua provided by RyzenAPI 
-- Game: The USB Stick Found in the Grass
addappid(1379550)
addappid(1379551, 1, "cdc39163de66e2cd7fb3f73133c3db7fb9f97d127948deba79b23f3f19c8ecbb")
