-- Lua provided by RyzenAPI
-- Game: addappid(282530)

-- MAIN APPLICATION
addappid(282530)

-- MAIN APP DEPOTS / PACKAGES
addappid(282531, 1, "78b00fe441d2e79a385692a33656b40466cd88e7680ce7c54f4b7b628d7922eb")
