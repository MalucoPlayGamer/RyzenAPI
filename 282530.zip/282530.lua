-- Lua provided by RyzenAPI
-- Game: Castlevania: Lords of Shadow – Mirror of Fate HD

-- MAIN APPLICATION
addappid(282530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(282531, 1, "78b00fe441d2e79a385692a33656b40466cd88e7680ce7c54f4b7b628d7922eb")

