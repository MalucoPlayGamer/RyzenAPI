-- Lua provided by RyzenAPI
-- Game: Game: Carnage in Space: Ignition

-- MAIN APPLICATION
addappid(748650)
-- Game: addappid(748650)

-- MAIN APP DEPOTS / PACKAGES
addappid(748651, 1, "4157553769739c7c55f33ff3a2cac2f26391c4b0530c9b942f7f99aa752cf92e")
addappid(748652, 1, "d53c975b06866f13139088de53a740d5b34b8fa9d0d7bdb0f39e09c2c3e2a94b")
addappid(748653, 1, "e033bd8b084c4aa9b08894b1e5cce9ddfa8d0d4d13b3281c97e93b8a8da387f7")
addappid(748654, 1, "15d88908e63b0c8dd88f50d3e83cfbdbbe1d60e77c0b01414915ebe3e9805a0e")
