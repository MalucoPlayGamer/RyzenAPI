-- 2856600's Lua and Manifest Created by Hubcap Manifest
-- Augmented Empire
-- Created: October 02, 2025 at 10:04:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2856600) -- Augmented Empire
-- MAIN APP DEPOTS
addappid(2856601, 1, "2c92f056b446bfed873f5efff1f161d0a14816f2b02c301d8d5a9ea8b564b06e") -- Depot 2856601
setManifestid(2856601, "3206889078957597342", 3469568681)