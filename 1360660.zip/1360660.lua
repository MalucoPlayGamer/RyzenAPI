-- Lua provided by RyzenAPI
-- Game: Neon Blight

-- MAIN APPLICATION
addappid(1360660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360661, 1, "76418a4d771fee6e8b059e0697d1b7f4c24688613944dd991a0d0144ac8e4130")

