-- Lua provided by RyzenAPI 
-- Game: Difficult times
addappid(3107960)
addappid(3107961, 1, "42ff8afd2c64adb2c3a5c1f81bc6685c55bbbb0bc6c0530a5392097ece5b4754")
