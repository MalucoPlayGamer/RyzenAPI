-- Lua provided by RyzenAPI
-- Game: AppID 2251140

-- MAIN APPLICATION
addappid(2251140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251141, 1, "52390f39fa3a4b1c2ccc7e532a3cfb8ac9c6cb054f385ec9e22ebe3f71ec737a")
