-- Lua provided by RyzenAPI 
-- Game: Zombie Army VR
addappid(2058030)
addappid(2058031, 1, "0d54e331589650da120f533f76fc488cedf68cd52d891b44a538648c28aa2e9d")
