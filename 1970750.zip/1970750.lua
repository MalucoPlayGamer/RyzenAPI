-- Lua provided by RyzenAPI
-- Game: SpearFrog

-- MAIN APPLICATION
addappid(1970750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970751, 1, "752e23a6fbcb441a65c85a5363c9c80de1646d348dd05227e8d6b9f179af75a8")

