-- Lua provided by RyzenAPI
-- Game: WARSAW RISING: City of Heroes

-- MAIN APPLICATION
addappid(1026420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026421, 1, "fba1bfd66f2fa15b4c5f573353fee50e8649040c0112c0dd67984c39e264ea5b")
addappid(2940140, 0, "c12a689c1179c57453f4a5f33d7626e56817fe67867585b19321010af067749a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
