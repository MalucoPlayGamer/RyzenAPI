-- Lua provided by RyzenAPI
-- Game: Audioshield

-- MAIN APPLICATION
addappid(412740)
-- Game: addappid(412740)

-- MAIN APP DEPOTS / PACKAGES
addappid(412741, 1, "4a12a41d663c97e64d230554f39c83c85f1724ee494c5c6d62a644cdf6cf890a")
