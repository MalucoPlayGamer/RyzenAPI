-- Lua provided by RyzenAPI
-- Game: Game: Sprint Vector

-- MAIN APPLICATION
addappid(590690)
-- Game: addappid(590690)

-- MAIN APP DEPOTS / PACKAGES
addappid(590691, 1, "9d2aabc21b774883c5fe6725558bb734d9a18ceda67a6282da54179d55433eb6")
