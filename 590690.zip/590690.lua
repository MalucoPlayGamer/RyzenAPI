-- Lua provided by RyzenAPI
-- Game: Sprint Vector

-- MAIN APPLICATION
addappid(590690)

-- MAIN APP DEPOTS / PACKAGES
addappid(590691, 1, "9d2aabc21b774883c5fe6725558bb734d9a18ceda67a6282da54179d55433eb6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
