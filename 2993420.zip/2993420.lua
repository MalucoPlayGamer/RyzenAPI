-- Lua provided by RyzenAPI
-- Game: 2993420

-- MAIN APPLICATION
addappid(2993420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993420,0,"b18e7ad669951547b272d8e2fe5f7df5c04188fe8b88d4ac3ec671bdfbc825fa")
