-- Lua provided by RyzenAPI
-- Game: The Music of Dreadnought OST

-- MAIN APPLICATION
addappid(858300)

-- MAIN APP DEPOTS / PACKAGES
addappid(858300,0,"cd2f16184a9bffb7bea1213ba1926aa2157f33c0a7a6e88b4d45c187b505dda8")
