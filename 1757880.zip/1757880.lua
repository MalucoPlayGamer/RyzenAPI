-- Lua provided by RyzenAPI
-- Game: addappid(1757880)

-- MAIN APPLICATION
addappid(1757880)
addappid(1759300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757881, 1, "d25131f460e3e830928eefa54a37bd156c2e5a2cb66be54edd18c254c4d85e88")
