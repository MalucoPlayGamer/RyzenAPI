-- Lua provided by RyzenAPI
-- Game: Stories of Submission: Learn Your Place

-- MAIN APPLICATION
addappid(1355370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355371, 1, "318147c75b5b8853c9d65b4129c0b3b224ad2d20fd9c9f5fa831957937be7969")
