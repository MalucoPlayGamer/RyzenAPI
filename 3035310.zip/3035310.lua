-- Lua provided by RyzenAPI
-- Game: Femdom Wife Game - Emily

-- MAIN APPLICATION
addappid(3035310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035311,0,"c33161d51b039ce4a7068d4eea32ee55951cb090b4229b8555918a466d457c93")

