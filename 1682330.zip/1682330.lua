-- Lua provided by RyzenAPI 
-- Game: AppID 1682330
addappid(1682330)
addappid(1682331, 1, "8b07ee2857dbc9b3010eb51d2393e2989a84fbcb4409bbdb01159ff524c01385")
