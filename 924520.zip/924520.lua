-- Lua provided by RyzenAPI
-- Game: 924520

-- MAIN APPLICATION
addappid(924520)
-- Game: addappid(924520)

-- MAIN APP DEPOTS / PACKAGES
addappid(924521, 1, "770396d23c0ba6db8e84bf49f3b4bf39265bfcaabe3cf769227324c8c7d3c842")
