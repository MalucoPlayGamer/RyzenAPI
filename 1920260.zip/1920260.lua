-- Lua provided by RyzenAPI
-- Game: addappid(1920260)

-- MAIN APPLICATION
addappid(1920260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920261, 1, "785ca16fec4ca67bd390ec5c158518bc749349d4f68fc1af65036bad8808085f")
