-- Lua provided by RyzenAPI
-- Game: Magnetta

-- MAIN APPLICATION
addappid(485750)

-- MAIN APP DEPOTS / PACKAGES
addappid(485751, 1, "47afd7264604871b9e5ade092be766be04bdcc8f31d3e412d4861963cc603613")
addappid(520830, 0, "3c42d16dc42402c13c48b731c7698ad028ae41cb90bd0afe9d4e0e035291815b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
