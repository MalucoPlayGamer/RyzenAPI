-- Lua provided by RyzenAPI
-- Game: Magnetta

-- MAIN APPLICATION
addappid(485750)

-- MAIN APP DEPOTS / PACKAGES
addappid(485751, 1, "47afd7264604871b9e5ade092be766be04bdcc8f31d3e412d4861963cc603613")
addappid(520830, 0, "3c42d16dc42402c13c48b731c7698ad028ae41cb90bd0afe9d4e0e035291815b")

