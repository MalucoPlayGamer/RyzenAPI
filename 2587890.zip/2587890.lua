-- Lua provided by RyzenAPI
-- Game: Poon Puzzle

-- MAIN APPLICATION
addappid(2587890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587891, 1, "c1e63e2eb2ba5eae62a85cce7075fa575103d6102f17667d40db07928712b509")
