-- Lua provided by RyzenAPI
-- Game: Fishing The Abyss

-- MAIN APPLICATION
addappid(3313310)
addappid(3599320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313311, 1, "24aefdfd75079cd737d52974848e0578283933d6fe98ea1fa58d63ec52390411")
