-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2025

-- MAIN APPLICATION
addappid(2935400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2935401, 1, "4ad6a6de868abeda4f80b0fa95892d355c9c89466cade83f3c846287b97513c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
