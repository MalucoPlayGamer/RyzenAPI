-- Lua provided by RyzenAPI
-- Game: Game: Pro Basketball Manager 2025

-- MAIN APPLICATION
addappid(2935400)
-- Game: addappid(2935400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2935401, 1, "4ad6a6de868abeda4f80b0fa95892d355c9c89466cade83f3c846287b97513c7")
