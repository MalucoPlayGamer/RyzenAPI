-- Lua provided by RyzenAPI
-- Game: addappid(2746340)

-- MAIN APPLICATION
addappid(2746340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746341, 1, "08ca8c616b3b23c5b0a13109d63d1595800fd7013b9bd6f166e4c978f2f82c17")
