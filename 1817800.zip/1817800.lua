-- Lua provided by SkyAPI 
-- Game: Oddsparks: An Automation Adventure
addappid(1817800)
addappid(1817801, 1, "b59ebe145d953e10adb462fd930cbf0da37483e64c0896babf1861638f87b6a5")
