-- Lua provided by RyzenAPI
-- Game: 1817800

-- MAIN APPLICATION
addappid(1817800)
-- Game: addappid(1817800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817801, 1, "b59ebe145d953e10adb462fd930cbf0da37483e64c0896babf1861638f87b6a5")
