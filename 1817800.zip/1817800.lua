-- Lua provided by RyzenAPI
-- Game: Oddsparks: An Automation Adventure

-- MAIN APPLICATION
addappid(1817800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817801, 1, "b59ebe145d953e10adb462fd930cbf0da37483e64c0896babf1861638f87b6a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3073500)
addappid(3678620)
addappid(3678630)
addappid(3678640)
addappid(3678650)
addappid(3916680)
