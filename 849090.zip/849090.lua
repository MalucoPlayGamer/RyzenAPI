-- Lua provided by RyzenAPI
-- Game: 849090

-- MAIN APPLICATION
addappid(849090)
-- Game: addappid(849090)

-- MAIN APP DEPOTS / PACKAGES
addappid(849091, 1, "93f375f6a38a75faeb94acaa57caa7f90156e1333bd187f22bb153c7a2d6c4af")
