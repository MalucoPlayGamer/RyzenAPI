-- Lua provided by RyzenAPI
-- Game: 1547500

-- MAIN APPLICATION
addappid(1547500)
-- Game: addappid(1547500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547501, 1, "6e571fb2fd78f9fa703746fe9941dbff94f5cc3af7e9ec36acc8dc6ddafed80c")
