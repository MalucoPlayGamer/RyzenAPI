-- Lua provided by SkyAPI 
-- Game: AppID 1547500
addappid(1547500)
addappid(1547501, 1, "6e571fb2fd78f9fa703746fe9941dbff94f5cc3af7e9ec36acc8dc6ddafed80c")
