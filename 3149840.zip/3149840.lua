-- Lua provided by RyzenAPI
-- Game: Скуф на рыбалке

-- MAIN APPLICATION
addappid(3149840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3149841, 1, "2f33b10d7294fd95579a4326817dd0dad7e062ebeaadd85abc56da16133b2df9")
