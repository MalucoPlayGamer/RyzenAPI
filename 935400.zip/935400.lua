-- Lua provided by RyzenAPI
-- Game: Alchemy Garden

-- MAIN APPLICATION
addappid(935400)

-- MAIN APP DEPOTS / PACKAGES
addappid(935401, 1, "40b04e348ab9cbb7994bdb8d9163f52c86d23ee7b0e0280bd2ece32bd53bb34b")

