-- Lua provided by RyzenAPI
-- Game: addappid(290770)

-- MAIN APPLICATION
addappid(290770)
addappid(334180)

-- MAIN APP DEPOTS / PACKAGES
addappid(290771, 1, "c68e7ad2b6cbfebb7afb78a0fcd14356834637f30675c47c085d34d339ef31af")
addappid(290772, 1, "4a1f06efa5c741f3cca85e0432130930bd06b1dcd3f87fdbfe00e419615c65a4")
addappid(290773, 1, "bbe1a0fc884eed93c46424c0c260e7ecc6b5e516baef2913eb70e11677c22780")
