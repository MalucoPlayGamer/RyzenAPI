-- Lua provided by RyzenAPI
-- Game: 1819190

-- MAIN APPLICATION
addappid(1819190)
-- Game: addappid(1819190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819191, 1, "a758de9917105d73eaafd2f6aab25d0bdc4aff0531d44081910fd2791eb2d486")
