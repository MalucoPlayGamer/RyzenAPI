-- Lua provided by RyzenAPI
-- Game: Rescue Helicopter

-- MAIN APPLICATION
addappid(1819190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819191, 1, "a758de9917105d73eaafd2f6aab25d0bdc4aff0531d44081910fd2791eb2d486")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
