-- Lua provided by RyzenAPI
-- Game: SPLITGATE: Arena Reloaded

-- MAIN APPLICATION
addappid(2918300)
addappid(3145160)
addappid(3145180)
addappid(3145200)
addappid(3757860)
addappid(3757870)
addappid(3757880)
addappid(4229070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2918301, 1, "9d061488b9ecc524b88fe2bfaeceddc348f7c7cab3d038b0f34fbb3c31a7f722")

