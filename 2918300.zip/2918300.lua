-- Lua provided by RyzenAPI
-- Game: SPLITGATE: Arena Reloaded

-- MAIN APPLICATION
addappid(2918300)
addappid(4229070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918301, 1, "9d061488b9ecc524b88fe2bfaeceddc348f7c7cab3d038b0f34fbb3c31a7f722")

