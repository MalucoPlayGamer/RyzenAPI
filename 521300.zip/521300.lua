-- Lua provided by RyzenAPI
-- Game: 521300

-- MAIN APPLICATION
addappid(521300)
-- Game: addappid(521300)

-- MAIN APP DEPOTS / PACKAGES
addappid(521302,0,"1b86bc6b037f642cd03198901f39e6f51aa7cd8710781ca3ae323c4d20efd30f")
