-- Lua provided by RyzenAPI
-- Game: Zoria: Age of Shattering Digital Bestiary

-- MAIN APPLICATION
addappid(2853200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853200,0,"f3efe572a9ca0110c3719018471c306defd99105fc5cfda1995531a9aa81d777")

