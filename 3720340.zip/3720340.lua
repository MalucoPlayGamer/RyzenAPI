-- Lua provided by RyzenAPI
-- Game: your wife, mother and daughter

-- MAIN APPLICATION
addappid(3720340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720341, 1, "faf3e011c1cf43d15dd428305db68c7c70d8de9b992183daee8305f1cca2e994")

