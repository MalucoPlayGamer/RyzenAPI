-- Lua provided by SkyAPI 
-- Game: Craftomation 101: Programming & Craft
addappid(1724140)
addappid(1724141, 1, "1e4e8afa0f3ccdd424ab57c22d719aaef9f15414e01e2b0bd5978a1d375daf7a")
addappid(1724142, 1, "80e95775b166fd5c5f4fed62d29b263ba81d6961aee79ea8604d2e90e3dd9c98")
addappid(1724143, 1, "0cdb97bfd7aafe350e07c63f4259705b55d914492da72dd5df7d9c7db7a12c1d")
