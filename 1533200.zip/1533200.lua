-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Mystic Voices Sound Pack

-- MAIN APPLICATION
addappid(1533200)
-- Game: addappid(1533200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533200,0,"d43681be5adaccb29268dd61f17c4a326012e2d4fecf6180daab002b522eef59")
