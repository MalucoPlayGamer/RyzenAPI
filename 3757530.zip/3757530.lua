-- Lua provided by RyzenAPI
-- Game: Game: Anaria

-- MAIN APPLICATION
addappid(3757530)
-- Game: addappid(3757530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3757531, 1, "5738ee6f9275b4e6efb3ad1b931a795cd015f0de8c7eebbb06c931b804c65563")
