-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel (Manga) Vol. 3

-- MAIN APPLICATION
addappid(3298980)
-- Game: addappid(3298980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298981, 1, "f4bff5d8db72ca88ee88630cc4dd2cc277ef4c629de0eda53c27285b49f2bb65")
