-- Lua provided by RyzenAPI
-- Game: Tsuki ni Yorisou Otome no Sahou 2

-- MAIN APPLICATION
addappid(3446150)
-- Game: addappid(3446150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446151, 1, "d709f60e06a1c27e406523c460b2937e4a616bcf65cce5e31dc2d9e89c69f92e")
