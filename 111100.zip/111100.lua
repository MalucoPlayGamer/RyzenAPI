-- Lua provided by RyzenAPI
-- Game: Snuggle Truck

-- MAIN APPLICATION
addappid(111100)
addappid(203070)
addappid(203090)
addappid(203100)
addappid(203110)
addappid(203120)
addappid(203130)

-- MAIN APP DEPOTS / PACKAGES
addappid(111101,0,"776b5f47a73f4aa4a362151106c10a694f0a48b0a1518ad6846bbce55581253c")
addappid(111102,0,"d8cb021c9ebd294163b23db5b07ab06e529979776b59f4584b482193e7e8d277")
addappid(111103,0,"283a88e4f2d8f66cd162a714fb97ecb00ca2a8bdfef20b4766ce3a4576cb2036")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
