-- Lua provided by SkyAPI 
-- Game: Snuggle Truck
addappid(111100)
addappid(111101, 1, "776b5f47a73f4aa4a362151106c10a694f0a48b0a1518ad6846bbce55581253c")
addappid(111102, 1, "d8cb021c9ebd294163b23db5b07ab06e529979776b59f4584b482193e7e8d277")
addappid(111103, 1, "283a88e4f2d8f66cd162a714fb97ecb00ca2a8bdfef20b4766ce3a4576cb2036")
addappid(228985)
