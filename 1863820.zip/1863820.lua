-- Lua provided by RyzenAPI
-- Game: Game: First Steps

-- MAIN APPLICATION
addappid(1863820)
-- Game: addappid(1863820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863821, 1, "3dce3f2ae9dfedb5b584ecff61dfec408daa858f58fbbf1369cc14478916a39d")
