-- Lua provided by RyzenAPI
-- Game: setManifestid(1344433,"8101635788651867737")

-- MAIN APPLICATION
addappid(1344430)
-- Game: addappid(1344430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344433,0,"fd3189f90d60826c10ea0636ef1bfe6cea0c9c1326dd7153a6cf243673f3d14f")
