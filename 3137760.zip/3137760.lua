-- Lua provided by RyzenAPI
-- Game: Game: Symphonia Demo

-- MAIN APPLICATION
addappid(3137760)
-- Game: addappid(3137760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137761, 1, "7c16de5af226646d03f74bb5c8fd2a12dc0601692643c70114817108aa1c4966")
