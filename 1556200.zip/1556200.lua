-- Lua provided by RyzenAPI
-- Game: Predator: Hunting Grounds

-- MAIN APPLICATION
addappid(1556200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556201, 1, "7a1631859e10145a80ee71e4738ec99e651fe132374c97e98c06d77c5a64ef89")
