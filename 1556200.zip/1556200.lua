-- Lua provided by RyzenAPI
-- Game: Predator: Hunting Grounds

-- MAIN APPLICATION
addappid(1556200)
addappid(1599480)
addappid(1599481)
addappid(1599482)
addappid(1599483)
addappid(1599484)
addappid(1599485)
addappid(1599486)
addappid(1605820)
addappid(1636840)
addappid(1696000)
addappid(1756590)
addappid(1847080)
addappid(1870540)
addappid(1919280)
addappid(1996830)
addappid(2198530)
addappid(2225270)
addappid(3189160)
addappid(3228960)
addappid(3228970)
addappid(3228980)
addappid(3228990)
addappid(3873870)
addappid(4043800)
addappid(4146790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556201,0,"7a1631859e10145a80ee71e4738ec99e651fe132374c97e98c06d77c5a64ef89")

