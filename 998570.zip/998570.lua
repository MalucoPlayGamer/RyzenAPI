-- Lua provided by RyzenAPI 
-- Game: AppID 998570
addappid(998570)
addappid(998571, 1, "064e971b4aa6c12f0807b48ea9697f62b30ce8abc4d1ff95940c244bd3641ef4")
