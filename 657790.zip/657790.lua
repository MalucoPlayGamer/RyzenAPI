-- Lua provided by RyzenAPI
-- Game: addappid(657790)

-- MAIN APPLICATION
addappid(657790)

-- MAIN APP DEPOTS / PACKAGES
addappid(657791, 1, "8c7dc99f1aa723cb9eb5114e7a9d4d4f95ced6d3aadc33b6563231a19324441d")
addappid(657792, 1, "240e4b62d8e92059b5dd07a64f1ccd4c1e5dd817b23b1ea9c291dd98216989a4")
addappid(657793, 1, "1379fe4ef5fe8536a675e5f15e8f5cde53b9da41cab37842b50c7cad95773179")
