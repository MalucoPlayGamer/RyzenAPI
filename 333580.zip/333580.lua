-- Lua provided by RyzenAPI
-- Game: Slow Down, Bull

-- MAIN APPLICATION
addappid(333580)

-- MAIN APP DEPOTS / PACKAGES
addappid(333581, 1, "d82d897e85dd066a46f80b8ab891e136e7a1a6e17e31ea550839020b273d28c4")
addappid(333584, 1, "1cca08aa43ceb0fffd6598c5ccc32c382656ab655bca0fcf6814a1c68859e02d")
