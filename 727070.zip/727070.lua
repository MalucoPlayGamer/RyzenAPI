-- Lua provided by RyzenAPI
-- Game: 727070

-- MAIN APPLICATION
addappid(727070)
-- Game: addappid(727070)

-- MAIN APP DEPOTS / PACKAGES
addappid(727071, 1, "06e192b0257a48300821a257eddacf05b75a52d1d5432842d7d9b7bd8c865f97")
