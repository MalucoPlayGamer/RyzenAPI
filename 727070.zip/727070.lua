-- Lua provided by SkyAPI 
-- Game: Hex
addappid(727070)
addappid(727071, 1, "06e192b0257a48300821a257eddacf05b75a52d1d5432842d7d9b7bd8c865f97")
