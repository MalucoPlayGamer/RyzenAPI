-- Lua provided by RyzenAPI
-- Game: 死寂（Deathly Stillness）

-- MAIN APPLICATION
addappid(1727650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727651, 1, "bc8ab7b5b3063d5620446c75d05611a8c3a92584d35351293a7dbca3d8608c63")
addappid(1727652, 1, "7046700ac4e3a03b7f952c87265edb4d1b887e582dfb633c4f75f76fb7608470")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
