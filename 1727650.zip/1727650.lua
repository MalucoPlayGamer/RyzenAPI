-- Lua provided by RyzenAPI
-- Game: 死寂（Deathly Stillness）

-- MAIN APPLICATION
addappid(1727650)
-- Game: addappid(1727650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727651, 1, "bc8ab7b5b3063d5620446c75d05611a8c3a92584d35351293a7dbca3d8608c63")
addappid(1727652, 1, "7046700ac4e3a03b7f952c87265edb4d1b887e582dfb633c4f75f76fb7608470")
