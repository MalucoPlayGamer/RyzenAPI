-- Lua provided by RyzenAPI
-- Game: Border Patrol

-- MAIN APPLICATION
addappid(3134670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134671, 1, "903d547893af06d53757748d78dbc86a2a985551aae3ab9bbd795b56f026b78d")

