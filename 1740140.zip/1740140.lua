-- Lua provided by SkyAPI 
-- Game: SWAT
addappid(1740140)
addappid(1740141, 1, "02b399c4cea1d505c8f92ba3540617ee8f757942ca255dad5c43b8c0b0f3904f")
