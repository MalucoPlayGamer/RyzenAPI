-- Lua provided by RyzenAPI
-- Game: SWAT

-- MAIN APPLICATION
addappid(1740140)
-- Game: addappid(1740140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740141, 1, "02b399c4cea1d505c8f92ba3540617ee8f757942ca255dad5c43b8c0b0f3904f")
