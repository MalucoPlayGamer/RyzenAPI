-- Lua provided by RyzenAPI
-- Game: A Lose Hero in the Castle of the Succubi

-- MAIN APPLICATION
addappid(1747330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747331, 1, "13774bd6c42e18f408e012783486acd0802048822b7088854d2928ad17464e3b")

