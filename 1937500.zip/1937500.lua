-- Lua provided by RyzenAPI
-- Game: 1937500

-- MAIN APPLICATION
addappid(1937500)
-- Game: addappid(1937500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937501, 1, "88b023a604b78607ab4a19ae2c69a3067612b1293aa6b9411294c80b2adcde37")
