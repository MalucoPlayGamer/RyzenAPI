-- Lua provided by RyzenAPI
-- Game: War Of Freedom

-- MAIN APPLICATION
addappid(1574030)
-- Game: addappid(1574030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574031, 1, "09c190fd8bea99000feceda99c0896596bb1a621504e4ebf7d47927fad15ac53")
