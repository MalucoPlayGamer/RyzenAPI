-- Lua provided by RyzenAPI
-- Game: ANONYMOUS;CODE

-- MAIN APPLICATION
addappid(2291020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291022,0,"816e2992b480d75c05adcfa3086d8611613c6eaef0550ce50c1ab01ebdce1af1")
addappid(2291023,0,"6326500f537e8b38461f2a322953cd965bb8bebe00f2f93ddb5fb0b74bb95ae9")
addappid(2291024,0,"cbc777868262207a2748160b33231cfa31a9749baaf61620c41296a1ad8e13c9")
addappid(2459571,0,"850d7eba48f8d279681b755bb7a30cfa4f6e445567ea7449fa0b0dc963a61e2d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2459570)
