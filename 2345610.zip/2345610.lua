-- Lua provided by RyzenAPI
-- Game: 人类动物园原声集 Human Zoo OST

-- MAIN APPLICATION
addappid(2345610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345611, 1, "4084054fb105f13fa5928f98bc8259391006bca27ed0d55c09437b2f3f71c0f2")
