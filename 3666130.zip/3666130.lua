-- Lua provided by RyzenAPI
-- Game: 街漓芳传 - 数字设定集

-- MAIN APPLICATION
addappid(3666130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3666130,0,"52b13e5f5bf74c4c034af9959e97c4e0b60e73306afac7075e132b0d5f311cc4")
