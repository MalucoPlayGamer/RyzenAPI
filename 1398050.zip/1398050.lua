-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1398050)
addappid(1398051)
-- Game: addappid(1398050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398050,0,"54656e43d8581e493f460ebc845a9a1d073157e4b7e187638494b73384fa8b73")
