-- Lua provided by RyzenAPI
-- Game: Estranged: The Departure

-- MAIN APPLICATION
addappid(582890)
-- Game: addappid(582890)

-- MAIN APP DEPOTS / PACKAGES
addappid(582891, 1, "3b2dd3d9b422d91f7d87582fadb2896d90c7449d35cdcfe7985cbe72fe75e3d8")
addappid(582892, 1, "9a02eb2e209c7b20840fe471c72808b0a02a57cb5443482e3b4e83c137da66fa")
addappid(582893, 1, "391a184ca090a95626d90d2917fd56056cf7a2cf4142bb6d1f1bc2070a286a57")
addappid(582894, 1, "80b197e580c472c225b3fd81c19471168e7e4a3447cbec96d7575a42d8a58efe")
