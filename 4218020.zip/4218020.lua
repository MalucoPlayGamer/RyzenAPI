-- Lua provided by RyzenAPI
-- Game: Sex Trainer's Diary: Hidden Kink

-- MAIN APPLICATION
addappid(4218020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4218021,0,"1a8623c305220f5168211b99b41ebd13025ae0403479f9411a71208a8db3496f")
addappid(4218022,0,"cb84f2cdfcbe4ec8c086ccc381937d95b83541806f9b639d54a0e59cbc5117a7")
addappid(4218023,0,"8be1ff746819c6308fbf330f0b8932b38a80dec22ba00283f5b52edbb79b1160")
addappid(4218024,0,"eb8d439e24209f86685b8fc0edbea659a950318dd1bcf90b0bbe5401452c7001")

