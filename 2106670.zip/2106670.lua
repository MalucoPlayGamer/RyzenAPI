-- Lua provided by RyzenAPI 
-- Game: Gatekeeper
addappid(2106670)
addappid(2106671, 1, "8020620a882ace556b89574d5c6bbce83c6d3034bf72959e40f2e0988702e7bc")
addappid(2967620, 0, "51627f4bbb1aacbdae1721d28a86576389b54b4953819b8347387cb000877884")
