-- Lua provided by RyzenAPI
-- Game: Zefyr: A Thief's Melody Soundtrack

-- MAIN APPLICATION
addappid(3687840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3687841, 1, "3db29bacbe4251194b8afc943acd870a1dd2599ab1b1bbf6b31d911275334805")

