-- Lua provided by RyzenAPI
-- Game: AppID 1468310

-- MAIN APPLICATION
addappid(1468310)
-- Game: addappid(1468310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468311, 1, "13c01a6e4628ce6aad926b6c4cc38de162c9581dd0de2ac3225dcb88d2e575eb")
addappid(1468312, 1, "5148f1f952541fcfb81d5c92396fd3452df89eec290c8b1d1dc00f42138c1203")
