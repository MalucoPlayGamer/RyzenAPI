-- Lua provided by RyzenAPI
-- Game: Game: Watertime

-- MAIN APPLICATION
addappid(3056770)
-- Game: addappid(3056770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056771, 1, "a6342f79321f4b3c99f50f82b169d4f186e7af04c43dde31644346c1769055f2")
