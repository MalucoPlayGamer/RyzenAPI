-- Lua provided by SkyAPI 
-- Game: Watertime
addappid(3056770)
addappid(3056771, 1, "a6342f79321f4b3c99f50f82b169d4f186e7af04c43dde31644346c1769055f2")
