-- Lua provided by RyzenAPI
-- Game: 33160

-- MAIN APPLICATION
addappid(33160)
-- Game: addappid(33160)

-- MAIN APP DEPOTS / PACKAGES
addappid(33161, 1, "9c9ab1f9b6f8bf6a4e0d1402954aa635cccbf458ff1c78ea3d8ba432f808a31c")
