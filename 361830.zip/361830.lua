-- Lua provided by RyzenAPI
-- Game: addappid(361830)

-- MAIN APPLICATION
addappid(361830)

-- MAIN APP DEPOTS / PACKAGES
addappid(361831, 1, "daa45ff402488cf8ea7c7a87f473b8c2c3b89913b2921c36c13cfd0070bc38a6")
