-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Literature Trivia

-- MAIN APPLICATION
addappid(861740)

-- MAIN APP DEPOTS / PACKAGES
addappid(861741, 1, "c929f9c6f7c3c4fdb5edcd1d4be5341cfb575c6c657384a1b229ccaafb3a197f")
