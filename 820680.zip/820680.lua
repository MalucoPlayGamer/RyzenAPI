-- Lua provided by RyzenAPI
-- Game: addappid(820680)

-- MAIN APPLICATION
addappid(820680)

-- MAIN APP DEPOTS / PACKAGES
addappid(820681, 1, "d3030d2f481e5e37159b519622993d37a62a0c2e6f2d9e4a005b4ae056caa682")
