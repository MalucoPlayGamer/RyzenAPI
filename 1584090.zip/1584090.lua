-- Lua provided by RyzenAPI
-- Game: Touhou Mystia's Izakaya

-- MAIN APPLICATION
addappid(1584090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584091, 1, "7626ba6bac1a68d11a5685cac46137800840a0c24bbda35037b7fa1dffeaaf96")
addappid(1584092, 1, "914bb29fcfe720613f9b7634be5361e77eaab81ce101b0a04d9b06c01d5f1b3b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1838750)
addappid(1927110)
addappid(2122050)
addappid(2191950)
addappid(2399330)
addappid(2399331)
addappid(2829050)
