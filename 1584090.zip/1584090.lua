-- Lua provided by RyzenAPI 
-- Game: Touhou Mystia's Izakaya
addappid(1584090)
addappid(1584091, 1, "7626ba6bac1a68d11a5685cac46137800840a0c24bbda35037b7fa1dffeaaf96")
addappid(1584092, 1, "914bb29fcfe720613f9b7634be5361e77eaab81ce101b0a04d9b06c01d5f1b3b")
