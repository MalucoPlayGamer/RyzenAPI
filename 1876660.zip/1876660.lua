-- Lua provided by RyzenAPI
-- Game: addappid(1876660)

-- MAIN APPLICATION
addappid(1876660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876661, 1, "b801e21c0d95bd99912dfb3a2bd76b8972ecfb04af9cfe9537676ac7326857f3")
