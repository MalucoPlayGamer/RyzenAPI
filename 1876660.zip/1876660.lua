-- Lua provided by RyzenAPI
-- Game: Start Programming

-- MAIN APPLICATION
addappid(1876660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876661, 1, "b801e21c0d95bd99912dfb3a2bd76b8972ecfb04af9cfe9537676ac7326857f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
