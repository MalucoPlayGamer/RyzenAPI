-- Lua provided by RyzenAPI
-- Game: The Pilgrim

-- MAIN APPLICATION
addappid(1132880)
-- Game: addappid(1132880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132881, 1, "d96a37f2e964f560c053f892a9e94aa60a08055a3b96aa1119e89fd7d4da51fd")
