-- Lua provided by RyzenAPI
-- Game: 763710

-- MAIN APPLICATION
addappid(763710)
-- Game: addappid(763710)

-- MAIN APP DEPOTS / PACKAGES
addappid(763711, 1, "b7bd531f1ff6eb95b105a83f29816d9386113ab6bd40061bfa106712e1adbbb7")
