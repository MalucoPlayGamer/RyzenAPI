-- Lua provided by RyzenAPI
-- Game: Edge of Dreams

-- MAIN APPLICATION
addappid(1261020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1261021, 1, "1d664b1321edf3064df41a2c6da164544316538b4b9c343ab06350d5c205554f")

