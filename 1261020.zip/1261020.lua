-- Lua provided by RyzenAPI
-- Game: Edge of Dreams

-- MAIN APPLICATION
addappid(1261020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261021, 1, "1d664b1321edf3064df41a2c6da164544316538b4b9c343ab06350d5c205554f")
