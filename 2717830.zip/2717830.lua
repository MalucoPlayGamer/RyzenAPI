-- Lua provided by RyzenAPI
-- Game: Trash Goblin Demo

-- MAIN APPLICATION
addappid(2717830)
-- Game: addappid(2717830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717831, 1, "7caecee1f94394eb0cc983957eeba7a29360927987c50bd74d0d29d4c9432987")
