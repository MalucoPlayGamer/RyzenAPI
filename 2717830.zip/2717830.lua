-- Lua provided by SkyAPI 
-- Game: Trash Goblin Demo
addappid(2717830)
addappid(2717831, 1, "7caecee1f94394eb0cc983957eeba7a29360927987c50bd74d0d29d4c9432987")
