-- Lua provided by RyzenAPI
-- Game: 1574900

-- MAIN APPLICATION
addappid(1574900)
-- Game: addappid(1574900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574901, 1, "f9729ddb9e16b7e3fd87d0f3a825826c9a78a51fc3e98ce6f4874e1f845fb6f4")
