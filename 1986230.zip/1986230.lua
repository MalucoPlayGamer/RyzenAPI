-- Lua provided by RyzenAPI
-- Game: What if your girl was a frog?

-- MAIN APPLICATION
addappid(1986230)
addappid(1997700)
-- Game: addappid(1986230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986231, 1, "7d99e8ad1d5e1105c63eaef7d4c9339f648ea536f88f5bd1a290fb008781e71c")
