-- Lua provided by RyzenAPI
-- Game: 已下架

-- MAIN APPLICATION
addappid(1240910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240911, 1, "7e889ee5e40298975fa12da34cdb89c0a10affb7b6ad84fd8c3a3543ea632ca7")
