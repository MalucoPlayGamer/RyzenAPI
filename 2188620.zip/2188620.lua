-- Lua provided by RyzenAPI
-- Game: It Returned To The Desert

-- MAIN APPLICATION
addappid(2188620)
-- Game: addappid(2188620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188621, 1, "a8dccf437b144cba8a2a69c4b5b6096a99eb92123e481035b8742b57d00d717c")
