-- Lua provided by RyzenAPI
-- Game: 趣拼拼：肖像画 Pleasure Puzzle:Portrait

-- MAIN APPLICATION
addappid(939620)
addappid(946820)
addappid(1355740)
addappid(1355741)

-- MAIN APP DEPOTS / PACKAGES
addappid(939621,0,"8b6fc8f2a8bb111d0457c5352cea414bafd02ecb69cf4fa0653568b9467e043e")
addappid(946820,0,"3c63f481c93b8e9baeec5cd75dd69e995b975e9cb13e641980e93334888614ae")
addappid(1355740,0,"55808d009376daa686f8f10da916f1ad90eca8331d6e76292b10f2b7a50ea109")
addappid(1355741,0,"f900f6a4216e737dd1766ebcbca143aec6d593e2c2b5ea8e3e9d23a0af450122")

