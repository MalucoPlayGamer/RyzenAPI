-- Lua provided by SkyAPI 
-- Game: Sky Rogue Original Soundtrack
addappid(586070)
addappid(586071, 1, "d81b5022ce834d7a04aa79f8b1c6dd1a1cc2fc0926e0d10e363356595730c4b3")
