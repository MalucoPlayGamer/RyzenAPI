-- Lua provided by RyzenAPI
-- Game: 3159440

-- MAIN APPLICATION
addappid(3159440)
-- Game: addappid(3159440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159441, 1, "dbf73ccb3e98f3de21ee28008f403a25d04f581571ab326e6e9ed476289ac265")
