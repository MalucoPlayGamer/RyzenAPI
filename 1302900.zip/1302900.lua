-- Lua provided by RyzenAPI
-- Game: Game: Hot Brass Original Soundtrack

-- MAIN APPLICATION
addappid(1302900)
-- Game: addappid(1302900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302901, 1, "425f87187ce4420e99e422aebc3ba516a91e17f7bdb5f8674acebcd707df2cad")
addappid(1302902, 1, "20d462c19235b553f5219c1f56a24354911ec645f24826814ecb827c6ca068b1")
