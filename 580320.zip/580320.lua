-- Lua provided by RyzenAPI
-- Game: addappid(580320)

-- MAIN APPLICATION
addappid(580320)

-- MAIN APP DEPOTS / PACKAGES
addappid(580321, 1, "cf50608b2efe1938cb55c836486ee7b0e425f3ba6e04f72db23e9b184a0a75d3")
addappid(580322, 1, "f6dbe6d6003d0ac31bafe9fe43dbb3d947e32d7b448d0c37a53efd7e670f3806")
addappid(580323, 1, "8c66a3d8395d4bb5ad6a0291120d9437fc4265e2af29f347b79f9baf26190656")
