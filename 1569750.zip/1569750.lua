-- Lua provided by RyzenAPI
-- Game: 1569750

-- MAIN APPLICATION
addappid(1569750)
addappid(1569753)
addappid(1569754)
-- Game: addappid(1569750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569752,0,"d10299de9a87c0f7248102793f835c70e82179d9d153e4629adb72ef2ada17fa")
