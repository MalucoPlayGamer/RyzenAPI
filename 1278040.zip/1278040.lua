-- Lua provided by RyzenAPI
-- Game: Storynth

-- MAIN APPLICATION
addappid(1278040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278041, 1, "7be11c8fadf183ee5ce42b2ac6361b6d037df41649c34cb53187d6c9bb2cc61b")

