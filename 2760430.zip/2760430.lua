-- Lua provided by RyzenAPI
-- Game: The Wandering Korun Demo

-- MAIN APPLICATION
addappid(2760430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2760434,0,"067b3f21657cdb9f820cc6d3d0d65a7f922889048d25cb0f6b98a2905fa3aff8")

