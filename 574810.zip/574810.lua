-- Lua provided by RyzenAPI 
-- Game: AppID 574810
addappid(574810)
addappid(574811, 1, "a2652c729af47399b3bc7a88b73d9fb3c53e7ce52e6029e2ec1ca64e6b6cbd1e")
