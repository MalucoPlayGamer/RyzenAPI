-- Lua provided by RyzenAPI
-- Game: 1082050

-- MAIN APPLICATION
addappid(1082050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082050,0,"6e7b04303e7e34b1c2e89d7a6e629d3d9ef45dfb8e73c7b2e8d62dd95efc0a2b")

