-- Lua provided by RyzenAPI
-- Game: Game: AppID 960040

-- MAIN APPLICATION
addappid(960040)
-- Game: addappid(960040)

-- MAIN APP DEPOTS / PACKAGES
addappid(960041, 1, "7e90bfc86d32d0bcb9055f0e3350f8737c44cf7e329a83f1f8414fba915b5cc6")
