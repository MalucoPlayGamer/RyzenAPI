-- Lua provided by RyzenAPI
-- Game: Rage Room

-- MAIN APPLICATION
addappid(745130)

-- MAIN APP DEPOTS / PACKAGES
addappid(745131, 1, "9725bfe33e672b337e18fa1903b1e1434281b5e52305d300be57d385c6afeb35")
