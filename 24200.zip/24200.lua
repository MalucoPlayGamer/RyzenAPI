-- Lua provided by RyzenAPI
-- Game: DC Universe™ Online

-- MAIN APPLICATION
addappid(24200)
-- Game: addappid(24200)

-- MAIN APP DEPOTS / PACKAGES
addappid(24201, 1, "17d1c9cf133958672c3d48342a0f4671b8dcc817ee766f998491396eb867ae22")
addappid(24202, 1, "ed24bbf44ffc7611a2f95a65efdf1d3acb28b2e81daec24343d2d0a39597c3a1")
addappid(24203, 1, "b6c629c3950fada9a199fcdf1d4ee2da1eb73bda65fe27d0d8ec486808a772c9")
addappid(24204, 1, "72a3ee199d446c9d1675c101fe96f452e2c79d39fa9a9b8d6484ddc296513554")
addappid(24205, 1, "b5d257f7e4917c13175ffcbfe83ee1181fd8e8846283ccd598315010dbef0541")
addappid(228984, 0, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068")
addappid(228990, 0, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
