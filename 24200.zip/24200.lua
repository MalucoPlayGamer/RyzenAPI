-- 24200's Lua and Manifest Created by Hubcap Manifest
-- DC Universe Online
-- Created: July 11, 2026 at 03:25:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 55
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(24200, 1, "7b8d4f5db7ca89cf7b8bc9a33384f1ec2fdb547de2ebcd8fb2a2374dff0ef041") -- DC Universe Online
-- MAIN APP DEPOTS
addappid(24201, 1, "17d1c9cf133958672c3d48342a0f4671b8dcc817ee766f998491396eb867ae22") -- DC Universe Online Depot
setManifestid(24201, "6562009443130731009", 47118421058)
addappid(24202, 1, "ed24bbf44ffc7611a2f95a65efdf1d3acb28b2e81daec24343d2d0a39597c3a1") -- DC Universe Online German
setManifestid(24202, "7694686693114963036", 9979778253)
addappid(24203, 1, "b6c629c3950fada9a199fcdf1d4ee2da1eb73bda65fe27d0d8ec486808a772c9") -- DC Universe Online Spanish
setManifestid(24203, "8555493766400482716", 9894928319)
addappid(24204, 1, "72a3ee199d446c9d1675c101fe96f452e2c79d39fa9a9b8d6484ddc296513554") -- DC Universe Online French
setManifestid(24204, "5719945599168021436", 9719594604)
addappid(24205, 1, "b5d257f7e4917c13175ffcbfe83ee1181fd8e8846283ccd598315010dbef0541") -- DC Universe Online Italian
setManifestid(24205, "6364685712868402857", 9919442024)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- DC Universe Online - Banes Venom Key (AppID: 24208)
addappid(24208)
addappid(24208, 1, "f4f7de0af60d6d762c588a07da712e3f97ae1d8f20125b47b3d0744639f5e40a") -- DC Universe Online - Banes Venom Key - DC Universe Online - Bane's Venom Key
setManifestid(24208, "7982137356589746531", 791)
-- DC Universe Online - Standard Key (AppID: 24209)
addappid(24209)
addappid(24209, 1, "3f5b86f88108995e16b64b759add3d13bbc5ff1624921ff1630222f6ae0786c2") -- DC Universe Online - Standard Key - DC Universe Online - Standard Key
setManifestid(24209, "311351568859746664", 791)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(215990) -- DC Universe Online Power Bundle
addappid(215991) -- DC Universe Online DLC 5
addappid(215992) -- DC Universe Online Fight For The Light
addappid(215993) -- DC Universe Online Lightning Strikes 
addappid(215994) -- DC Universe Online The Battle For Earth
addappid(215995) -- DC Universe Online The Last Laugh
addappid(215996) -- DC Universe Online Home Turf
addappid(215997) -- DC Universe Online Origin Crisis
addappid(215998) -- DC Universe Online Ultimate Edition Bundle
addappid(249750) -- DC Universe Online - Sons of Trigon
addappid(275020) -- DC Universe Online  War of the Light
addappid(299270) -- DC Universe Online - Amazon Fury Part I
addappid(315800) -- DC Universe Online - Halls of Power Part I
addappid(331740) -- DC Universe Online - War of the Light Part II
addappid(333910) -- DC Universe Online  Starter Bundle
addappid(333920) -- DC Universe Online Legends Bundle
addappid(333921) -- DC Universe Online Complete Bundle
addappid(347570) -- DC Universe Online - Amazon Fury Part II
addappid(361180) -- DC Universe Online - Ultimate Edition
addappid(361181) -- DC Universe Online - Episode Pack I
addappid(361182) -- DC Universe Online - Episode Pack II
addappid(361183) -- DC Universe Online - Power Bundle
addappid(371740) -- DC Universe Online - Halls of Power Part II
addappid(393850) -- DC Universe Online - The Bombshell Paradox  Corrupted Zamaron
addappid(402230) -- DC Universe Online - Desecrated Cathedral  OA Under Siege
addappid(410280) -- DC Universe Online - Episode 17 The Flash Museum Burglary  Unholy Matrimony
addappid(418350) -- DC Universe Online - Episode 18 Blackest Day  The Demons Pit
addappid(425620) -- DC Universe Online - Episode 19  Deep Desires  The Demons Plan
addappid(435550) -- DC Universe Online - Episode 20  Blackest Night  Wasteland Wonderland
addappid(443100) -- DC Universe Online - Episode 21 The First Piece  Prison Break
addappid(452050) -- DC Universe Online - Episode 22 The Phantom Zone  Science Spire
addappid(461610) -- DC Universe Online - Episode 23 Brainiacs Bottle Ship  The Will of Darkseid
addappid(476520) -- DC Universe Online - Episode 24 Darkseids War Factory  Harleys Heist
addappid(494390) -- DC Universe Online - Episode Pack III
addappid(494391) -- DC Universe Online - Ultimate Edition (2016)
addappid(494392) -- DC Universe Online - Power Bundle (2016)
addappid(496220) -- DC Universe Online - Episode 25 Iceberg Lounge  A Rip In Time
addappid(511480) -- DC Universe Online - Episode 26  Wayne Manor Gala  Kandor Central Tower
addappid(546520) -- DC Universe Online - Episode 27 Amazon Fury Part III
addappid(557020) -- DC Universe Online - Episode Pack IV
addappid(637380) -- DC Universe Online - Episode 28 Age of Justice
addappid(720900) -- DC Universe Online - Episode 29 Riddled With Crime
addappid(757020) -- DC Universe Online - Episode 30 Earth 3
addappid(763370) -- DC Universe Online - Starter Pack by LexCorp
addappid(837360) -- DC Universe Online - Episode 31  Deluge
addappid(900820) -- DC Universe Online - Episode 32 - Teen Titans The Judas Contract
addappid(978730) -- DC Universe Online - Episode 33  Atlantis
addappid(1050480) -- DC Universe Online - Episode 34  Justice League Dark
addappid(1146540) -- DC Universe Online - Episode 35  Metal Part I
addappid(1182050) -- DC Universe Online - Episode 36  Metal Part II
addappid(1280110) -- DC Universe Online - Episode 37 Birds of Prey
addappid(1367930) -- DC Universe Online - Episode 38 Wonderverse
addappid(1443150) -- DC Universe Online - Episode 39 Long Live The Legion