-- Lua provided by RyzenAPI
-- Game: Scarlet Defiance: The Wall Between Us Demo

-- MAIN APPLICATION
addappid(3063080)
-- Game: addappid(3063080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3063081, 1, "bf3e2bb1a8db01af4f23954c6c2d82cdcea8e42c87cc9761fd6d062101de15b2")
