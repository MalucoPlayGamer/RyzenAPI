-- Lua provided by SkyAPI 
-- Game: AppID 835510
addappid(835510)
addappid(835511, 1, "be9a14950c5badfd27235eac38ad212b69c123e1059b2f0da8da5b85a68660ef")
