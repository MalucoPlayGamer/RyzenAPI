-- Lua provided by RyzenAPI
-- Game: Game: AppID 835510

-- MAIN APPLICATION
addappid(835510)
-- Game: addappid(835510)

-- MAIN APP DEPOTS / PACKAGES
addappid(835511, 1, "be9a14950c5badfd27235eac38ad212b69c123e1059b2f0da8da5b85a68660ef")
