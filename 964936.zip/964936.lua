-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Bao Sanniang (Cheerleaders Costume) / 鮑三娘 「チアガール風コスチューム」

-- MAIN APPLICATION
addappid(964936)

-- MAIN APP DEPOTS / PACKAGES
addappid(964936,0,"32c8dbad4baae70dcb5ad167497df1cd04b0c0ae0a061cb904dcf52c573c9059")

