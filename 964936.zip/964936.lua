-- Lua provided by RyzenAPI
-- Game: 964936

-- MAIN APPLICATION
addappid(964936)

-- MAIN APP DEPOTS / PACKAGES
addappid(964936,0,"32c8dbad4baae70dcb5ad167497df1cd04b0c0ae0a061cb904dcf52c573c9059")
