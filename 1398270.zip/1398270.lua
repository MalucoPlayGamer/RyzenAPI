-- Lua provided by SkyAPI 
-- Game: Furgal's Jetpack
addappid(1398270)
addappid(1398271, 1, "1b3d01c84814cc91c644f08ba748a5728c6cc32e899048979b3665b6a8647507")
