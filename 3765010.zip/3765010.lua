-- Lua provided by RyzenAPI
-- Game: Forensics Crime Scene Detective

-- MAIN APPLICATION
addappid(3765010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3765011,0,"862296624beb296f31c01dfabcf03e1cd32a053be26dfb9d894a0ff8a084435c")
addappid(3765011, 1, "862296624beb296f31c01dfabcf03e1cd32a053be26dfb9d894a0ff8a084435c") -- Depot 3765011

