-- Lua provided by RyzenAPI 
-- Game: Breakpoint
addappid(1273250)
addappid(1273251, 1, "cddb1dcfe1b2bc9da316a68fad5a85894cf992389af0b92b118f01301a5f0fdf")
