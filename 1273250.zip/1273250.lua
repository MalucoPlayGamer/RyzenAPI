-- Lua provided by RyzenAPI
-- Game: addappid(1273250)

-- MAIN APPLICATION
addappid(1273250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273251, 1, "cddb1dcfe1b2bc9da316a68fad5a85894cf992389af0b92b118f01301a5f0fdf")
