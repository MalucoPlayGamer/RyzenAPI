-- Lua provided by RyzenAPI
-- Game: 拯救大魔王:重生 Falsemen: Rebirth

-- MAIN APPLICATION
addappid(859280)

-- MAIN APP DEPOTS / PACKAGES
addappid(859281, 1, "d1b152d1a2f8eb983097ff7c656bd70d310423cfa9c59e75a5d63922dae54bbb")
addappid(1040640, 0, "f43b982cb5073c4274bcc1b2c295950e28b8e516a0b5c60ca7793935c5f05c90")

