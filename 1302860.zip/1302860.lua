-- Lua provided by RyzenAPI
-- Game: Assembly Planter

-- MAIN APPLICATION
addappid(1302860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302861, 1, "0e8356362899936e975b38cdcafdf7501f7b15d7079349532010688a912f7fec")
