-- Lua provided by RyzenAPI 
-- Game: Assembly Planter
addappid(1302860)
addappid(1302861, 1, "0e8356362899936e975b38cdcafdf7501f7b15d7079349532010688a912f7fec")
