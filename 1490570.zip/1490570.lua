-- Lua provided by RyzenAPI
-- Game: git gud

-- MAIN APPLICATION
addappid(1490570)
addappid(4278690)
addappid(5118140)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1490571, 1, "a032a3480ce420c34be09064b2a2092ecf6c1bb8768a332b66aabc6846252cda")

