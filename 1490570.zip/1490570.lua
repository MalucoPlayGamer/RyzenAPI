-- Lua provided by RyzenAPI
-- Game: addappid(1490570)

-- MAIN APPLICATION
addappid(1490570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490571, 1, "a032a3480ce420c34be09064b2a2092ecf6c1bb8768a332b66aabc6846252cda")
