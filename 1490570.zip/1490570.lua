-- Lua provided by RyzenAPI 
-- Game: git gud
addappid(1490570)
addappid(1490571, 1, "a032a3480ce420c34be09064b2a2092ecf6c1bb8768a332b66aabc6846252cda")
