-- Lua provided by RyzenAPI
-- Game: Game: Just Skill Shooter

-- MAIN APPLICATION
addappid(2417160)
-- Game: addappid(2417160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417161, 1, "e9202c4949d165b54e3d4f9b8dd72faaea60de38dfd7056f157949253a6708c4")
