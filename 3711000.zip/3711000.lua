-- Lua provided by SkyAPI 
-- Game: Trash Goblin Soundtrack
addappid(3711000)
addappid(3711001, 1, "80ced70ae333f910e9c1853f4c42b523e390b1f023a407826f68b36bf19d9f11")
addappid(3711002, 1, "b36488e07031dc790f97da93a19efb97d1855adfed4a6c607561839e1a19cad8")
