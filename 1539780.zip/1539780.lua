-- Lua provided by RyzenAPI
-- Game: Winning Love by Daylight [Ep 1 Demo]

-- MAIN APPLICATION
addappid(1539780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539782,0,"cd4bae9f6dc34e363226bfc6d6ba02ee68feaa206cf737d421c069194aed36aa")

