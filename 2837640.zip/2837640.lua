-- Lua provided by RyzenAPI
-- Game: Crowd Diver

-- MAIN APPLICATION
addappid(2837640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837641, 1, "b6b56af04b0f7a7c3a3ca8f289e2f16a72737a44d7675edfae2d641575600f3e")

