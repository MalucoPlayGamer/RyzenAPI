-- Lua provided by RyzenAPI
-- Game: 562570

-- MAIN APPLICATION
addappid(562570)
-- Game: addappid(562570)

-- MAIN APP DEPOTS / PACKAGES
addappid(562571, 1, "c38b018242d8f11d8ae47b9897dc49273ccdb5203e8048fc6be58fd202ee4f90")
