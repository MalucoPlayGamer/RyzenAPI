-- Lua provided by SkyAPI 
-- Game: Access Denied
addappid(562570)
addappid(562571, 1, "c38b018242d8f11d8ae47b9897dc49273ccdb5203e8048fc6be58fd202ee4f90")
