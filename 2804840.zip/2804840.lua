-- Lua provided by RyzenAPI
-- Game: Echoes Of Despair

-- MAIN APPLICATION
addappid(2804840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804841, 1, "ccd1ef87abcec272d426459f4cc9c565631b23f1d227f660bc6b128927f0bafc")

