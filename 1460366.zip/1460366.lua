-- Lua provided by RyzenAPI
-- Game: 1460366

-- MAIN APPLICATION
addappid(1460366)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460366,0,"fde4a5f6cda264fd71f29217c0246641c39c21e20ff816619aac2fc4ae1ac9d3")

