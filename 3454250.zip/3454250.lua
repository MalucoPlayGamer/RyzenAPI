-- Lua provided by SkyAPI 
-- Game: AppID 3454250
addappid(3454250)
addappid(3454251, 1, "bec37b015eb2039de50813b169d293c4ed65363a66a852cf024f5be7b7bc979d")
