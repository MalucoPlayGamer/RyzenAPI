-- Lua provided by RyzenAPI
-- Game: 3454250

-- MAIN APPLICATION
addappid(3454250)
-- Game: addappid(3454250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454251, 1, "bec37b015eb2039de50813b169d293c4ed65363a66a852cf024f5be7b7bc979d")
