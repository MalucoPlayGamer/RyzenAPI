-- Lua provided by RyzenAPI
-- Game: CITYCONOMY: Service for your City

-- MAIN APPLICATION
addappid(304580)
addappid(417710)
addappid(417711)
addappid(417712)
addappid(417713)
addappid(417714)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(304581, 1, "77771fcf44eeb2832bac62b319d519eec940a71561d226a553ebecefe5102e6c")
addappid(304582, 1, "4bfccbcb81268600d159c1a4916bb7cab90b36780d141b6c3417f4f7aef35d71")
addappid(304584, 1, "c6ef88b5f6037948deec4c138bb54da673c977f5e81dd09a8b27d38d87953da8")

