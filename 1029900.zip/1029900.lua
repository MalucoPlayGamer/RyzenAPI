-- Lua provided by RyzenAPI
-- Game: AppID 1029900

-- MAIN APPLICATION
addappid(1029900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(1029901, 1, "b99ffb15af5bea99af25cb1d3bb25831cf334f2e022789c44f5895f84afde6c8")

