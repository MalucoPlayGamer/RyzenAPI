-- Lua provided by RyzenAPI
-- Game: AppID 415180

-- MAIN APPLICATION
addappid(415180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229010, 1, "9ea8b334311d1b69b962aac11d4cce01f3dfb21722d4198c12314f2d67a0196f") -- (windows)
addappid(415181, 1, "126b649309728e1e456777dba442a150bbb9db018500181f6c2388f4e2a9d098")

