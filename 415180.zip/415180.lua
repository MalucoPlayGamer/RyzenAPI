-- Lua provided by RyzenAPI 
-- Game: AppID 415180
addappid(415180)
addappid(415181, 1, "126b649309728e1e456777dba442a150bbb9db018500181f6c2388f4e2a9d098")
