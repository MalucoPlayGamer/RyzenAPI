-- Lua provided by RyzenAPI
-- Game: Mission Control: NanoMech

-- MAIN APPLICATION
addappid(338030)

-- MAIN APP DEPOTS / PACKAGES
addappid(338031, 1, "40a972aa28c49a7f2ee2d32045728254f9e2f3035105d232cc206bbe273db6e1")
addappid(338033, 1, "d091a70d8cdb5c18820e9e25e637e9c9553b5d13e5e44aee0ddae53792dd0985")

