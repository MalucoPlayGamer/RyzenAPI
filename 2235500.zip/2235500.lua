-- Lua provided by RyzenAPI
-- Game: Forest Of Relics

-- MAIN APPLICATION
addappid(2235500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235501, 1, "3a8c9c9e7f711cd53dd5efeb2d9b1ccdd65505cbf6883548e549fc8c4ad070c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
