-- Lua provided by RyzenAPI
-- Game: 2235500

-- MAIN APPLICATION
addappid(2235500)
-- Game: addappid(2235500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235501, 1, "3a8c9c9e7f711cd53dd5efeb2d9b1ccdd65505cbf6883548e549fc8c4ad070c3")
