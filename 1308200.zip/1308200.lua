-- Lua provided by SkyAPI 
-- Game: AppID 1308200
addappid(1308200)
addappid(1308201, 1, "c34dec6b284636a826872948ec6dc700dad030a4a059a1c42b891262b41ccff8")
addappid(1308203, 1, "fe3e9dd36b572bf0a08a89a650886b96c6b7a3a153a833c7448db70dde68c9d6")
