-- Lua provided by RyzenAPI
-- Game: Game: Twizzle Puzzle: Dinosaurs

-- MAIN APPLICATION
addappid(2989680)
-- Game: addappid(2989680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989681, 1, "a2f9bd7d3cdac720156493b8624111e08c023d4f8c8554e150a0ddd80bfc532f")
