-- Lua provided by RyzenAPI
-- Game: Choppa: Rescue Rivals

-- MAIN APPLICATION
addappid(1173100) -- Choppa: Rescue Rivals

-- MAIN APP DEPOTS / PACKAGES
addappid(1173101, 1, "9c63c807389c916c7a435a8ee61d865dd94443650f9f8b75b3002d9001de0b05") -- Depot 1173101

