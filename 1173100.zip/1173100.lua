-- 1173100's Lua and Manifest Created by Hubcap Manifest
-- Choppa: Rescue Rivals
-- Created: August 14, 2026 at 10:14:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1173100) -- Choppa: Rescue Rivals
-- MAIN APP DEPOTS
addappid(1173101, 1, "9c63c807389c916c7a435a8ee61d865dd94443650f9f8b75b3002d9001de0b05") -- Depot 1173101
setManifestid(1173101, "6675432952142112359", 1099034510)