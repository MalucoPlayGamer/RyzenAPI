-- Lua provided by RyzenAPI
-- Game: Hentai Pussy 5

-- MAIN APPLICATION
addappid(2226890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226891, 1, "169a48734c9e23a64a935fcdd6b144d654926709b3036bfa8ea168ffe511d752")
