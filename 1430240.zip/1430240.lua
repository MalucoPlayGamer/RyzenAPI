-- Lua provided by RyzenAPI
-- Game: The Space in Between

-- MAIN APPLICATION
addappid(1430240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430241, 1, "0c523f00ac3ef3c54a3607a1ee2516fbbdbd75229857f13226df258047428e0e")
addappid(1430242, 1, "eaed93675416230e41df9eda451ee21e47d0f97e4569a68272c0af4a8558d73d")
