-- Lua provided by RyzenAPI
-- Game: Game: AppID 2580390

-- MAIN APPLICATION
addappid(2580390)
-- Game: addappid(2580390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580391, 1, "52a13772c6f76e3734b5a02a6e219ab4fa5b10f1560594c37d31f999a771b5a0")
