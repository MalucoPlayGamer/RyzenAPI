-- Lua provided by SkyAPI 
-- Game: Rebots
addappid(993030)
addappid(993031, 1, "24e8e8d9d8399c4248973df0451691acec7ded79fa5113fec09418cc50a27aca")
