-- Lua provided by RyzenAPI
-- Game: Kozyrev Horrors

-- MAIN APPLICATION
addappid(2821830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2821831, 1, "c38b1fedca49fc4a8f5e90b8818bb5972349b25bd04e88d6a52c08a7281bc0f1")

