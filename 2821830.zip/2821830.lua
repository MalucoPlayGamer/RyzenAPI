-- Lua provided by RyzenAPI 
-- Game: Kozyrev Horrors
addappid(2821830)
addappid(2821831, 1, "c38b1fedca49fc4a8f5e90b8818bb5972349b25bd04e88d6a52c08a7281bc0f1")
