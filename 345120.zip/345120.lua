-- Lua provided by RyzenAPI
-- Game: Vox Populi Vox Dei 2

-- MAIN APPLICATION
addappid(345120)
