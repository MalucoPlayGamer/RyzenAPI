-- Lua provided by SkyAPI 
-- Game: Russian World
addappid(829940)
addappid(829941, 1, "12f260113ee50eaebf631550ccc046f511f7a54eda64807d1a60e05b09d816ba")
addappid(829942, 1, "4987451367c1f14691451075a3f5246a78ee77f178f7d1cb15f7c7db7da9b141")
