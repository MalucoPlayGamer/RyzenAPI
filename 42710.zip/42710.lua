-- Lua provided by RyzenAPI
-- Game: Call of Duty®: Black Ops

-- MAIN APPLICATION
addappid(42702)
addappid(42703)
addappid(42705)
addappid(42706)
addappid(42707)
addappid(42708)
addappid(42709)
addappid(42710)
addappid(42711)
addappid(42713)
addappid(214632)
addappid(214633)
addappid(214635)
addappid(214636)
addappid(214637)
addappid(214638)

-- MAIN APP DEPOTS / PACKAGES
addappid(42704,0,"ef154528aeaf6541d4b637fa5e7820e12f45f66844c66bae380dd91921e73e23")
addappid(42715,0,"dd7c7b2cb4e026a6797f04fcb6794dd0b344ecbb922aa2e155f19dcb57e2bc8d")
addappid(42717,0,"5fda7eac8f2937f0902fdee5e4557d58b5d44c0387b46815ca4c68a13a5be40a")
addappid(42722,0,"41ff5db29a861668118f45abadc21bc18576a07e8f08da29528b5eb7167c62a3")
addappid(214634,0,"06082554b254b4f2109aa1af5abe42d001cb05f5fff01ffc38d20339ad9cd0d3")
addappid(214645,0,"6b22dcf0120eec6c5325356e6f881820c99d077ce7a358b2bf7023447f51f672")
addappid(214647,0,"6cb4d4a4e558b3d83d5f40d0493e8cb1ede9c0b83ea32dab40c3751916aee923")
