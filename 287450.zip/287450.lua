-- Lua provided by RyzenAPI
-- Game: Rise of Nations: Extended Edition

-- MAIN APPLICATION
addappid(287450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(287451, 1, "3cb5ae6ce64fe256aa10220410daf46e31d5cb040f817d00b251f347371e53cb")
addappid(287452, 1, "611ea42d873916de1da5565c82f58c97908116a141ac3d78168e0a255e04ee44")
addappid(287453, 1, "3025b9b74c2e7cd02170380c812ce2ff92c94d9f2d4b650e3f6235dea33c35bb")

