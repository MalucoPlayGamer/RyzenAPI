-- Lua provided by RyzenAPI
-- Game: Gibbon: Beyond the Trees

-- MAIN APPLICATION
addappid(1837330)
-- Game: addappid(1837330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837331, 1, "bbc067021179adbbc8e50291a69316a5ce74fd8e5a77c1621be7b6ca38ef7d4b")
