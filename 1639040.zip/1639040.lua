-- Lua provided by RyzenAPI
-- Game: There Will Be No Turkey This Christmas

-- MAIN APPLICATION
addappid(1639040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639041, 1, "630d24399e84d2145ae040ab54a8609d09675f51b28df7a281681876737abd46")
