-- Lua provided by RyzenAPI
-- Game: MediBang Paint for Desktop

-- MAIN APPLICATION
addappid(2485190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485191, 1, "9d3fd9fbc2ecbc50f090cc0da7ad018240dae3fc9e38f69412572f7b0f72536d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
