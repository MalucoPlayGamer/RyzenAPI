-- Lua provided by RyzenAPI 
-- Game: TEVI - Original Soundtrack
addappid(2633990)
addappid(2633991, 1, "d9d115474e08bb2bf938e23119d68cd8f9357cba7c1a6cde4d063dedf8d0c302")
addappid(2633992, 1, "788fa810691d8374702fde5b65300978aa56c4c07f77a10d200d00236644c126")
