-- Lua provided by RyzenAPI
-- Game: Comit the Astrodian 2

-- MAIN APPLICATION
addappid(597090)

-- MAIN APP DEPOTS / PACKAGES
addappid(597091, 1, "90df70b95860faaf98b7c90d8e0a53793b75cf70d80a9f5a7747c1e0f3227030")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
