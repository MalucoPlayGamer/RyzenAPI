-- Lua provided by SkyAPI 
-- Game: Comit the Astrodian 2
addappid(597090)
addappid(597091, 1, "90df70b95860faaf98b7c90d8e0a53793b75cf70d80a9f5a7747c1e0f3227030")
