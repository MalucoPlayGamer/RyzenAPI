-- Lua provided by RyzenAPI
-- Game: Game: Backrooms: The Hunt

-- MAIN APPLICATION
addappid(2409100)
-- Game: addappid(2409100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409101, 1, "0f03e91ccdc8077c44e9c35549aba64217eb633afb3b6e80d8d7367d2fcf4451")
