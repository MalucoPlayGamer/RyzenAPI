-- Lua provided by RyzenAPI
-- Game: Battle Girls

-- MAIN APPLICATION
addappid(404170)

-- MAIN APP DEPOTS / PACKAGES
addappid(404171, 1, "0ef9fbc1bbfdf18bf783611bd74e26d66091c2e3d4a1d4240acb77c605911bc7")
addappid(494270, 0, "8cbb4d1d4bfc5146d700d46a5edf97d6501e6889cdb7afd7de00a6dd4e6dda7e")
addappid(552640, 0, "42602bf891290f9c298e9773c47401adfd3c2bef381cf655a74ae6be2dcb8f0d")
addappid(552641, 0, "241cfff39aaa8aab7506c96de812bdd8b301ece9fdb8a6955467d75fd6842aed")
addappid(552642, 0, "b73e2a28b0973ab85923601f2afe5af94066ca2b5cb61d42bfce1b68c085aa32")
addappid(552643, 0, "17cdaae145ca5f28337cb22c2f080c6b7dd57c61c27d5039327d2c4f16d8cfbd")

