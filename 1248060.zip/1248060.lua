-- Lua provided by RyzenAPI
-- Game: AppID 1248060

-- MAIN APPLICATION
addappid(1248060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248061, 1, "475f797e335e27ddcd4cbf01075cd21575204571580416182c6c4d8227e9758d")
addappid(1248062, 1, "6d2b0efe376fc1a442bfbf859c2eda72037de9e999a58aa114e6e64fac6fd97e")
addappid(1248063, 1, "2938c7c090b1d62a41f2c267e94868b34f5e5bc9facc388b96e4dc788f8bc02c")
addappid(1581130, 0, "a0d54181576ebcac0c46882afdec67dd40410f94d9939be0d0bfa7000f6b0aa7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
