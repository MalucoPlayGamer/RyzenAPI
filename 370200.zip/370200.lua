-- Lua provided by RyzenAPI
-- Game: Game: AppID 370200

-- MAIN APPLICATION
addappid(370200)
-- Game: addappid(370200)

-- MAIN APP DEPOTS / PACKAGES
addappid(370201, 1, "76d30a868563b3ac7a222bdf677b74c17fe07f2d723a7719ec23783d5e898180")
