-- Lua provided by RyzenAPI
-- Game: Car Manufacture

-- MAIN APPLICATION
addappid(983380)

-- MAIN APP DEPOTS / PACKAGES
addappid(983381, 1, "926edc9b87c8795c4aa84cfbf12c56ec508922e075da0591934bbd294dce0c07")

