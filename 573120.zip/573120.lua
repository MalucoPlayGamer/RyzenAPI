-- Lua provided by RyzenAPI
-- Game: Dead In Vinland

-- MAIN APPLICATION
addappid(573120)
addappid(896640)
addappid(969140)
addappid(1037050)

-- MAIN APP DEPOTS / PACKAGES
addappid(573121, 1, "592cdd75498402ba2d03ca1ec0796aae664a1a1bcd99e35d3122364b0afa80f4")
addappid(573122, 1, "5b1d23c7281aa8d52d3afe96f3b558eeb39781ed18c6584fa538e8944b900261")
addappid(573123, 1, "cd844c3faa74896c4e5d5a4b92536a913739da5940b71b1e5d54ad8a6631b241")

