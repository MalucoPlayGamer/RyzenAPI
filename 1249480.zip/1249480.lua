-- Lua provided by RyzenAPI 
-- Game: Ex-Zodiac
addappid(1249480)
addappid(1249481, 1, "7cb7c3493874a956662d8f3acde4a894cc25e0fbaf8f3f2b82c8de08ef9a6d43")
