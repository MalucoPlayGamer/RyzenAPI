-- Lua provided by RyzenAPI
-- Game: Dead Signal

-- MAIN APPLICATION
addappid(2599300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2599301, 1, "8dbbd17bdd211ebd482e840547994b475c34c94d4b80e1f405125aabf4026dd5")

