-- Lua provided by RyzenAPI
-- Game: addappid(2599300)

-- MAIN APPLICATION
addappid(2599300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599301, 1, "8dbbd17bdd211ebd482e840547994b475c34c94d4b80e1f405125aabf4026dd5")
