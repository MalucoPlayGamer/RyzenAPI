-- Lua provided by RyzenAPI
-- Game: Forever Skies

-- MAIN APPLICATION
addappid(1641960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641962,1,"a91698830f3b24f3601c1b3045067a2bd67bc0e2182a4d752f413cdaecc32329")

