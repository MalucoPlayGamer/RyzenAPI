-- Lua provided by RyzenAPI
-- Game: Forever Skies

-- MAIN APPLICATION
addappid(1641960)
addappid(2635800)
addappid(3625790)
addappid(4196930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641962,0,"a91698830f3b24f3601c1b3045067a2bd67bc0e2182a4d752f413cdaecc32329")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
