-- Lua provided by RyzenAPI
-- Game: Shiver: Poltergeist Collector's Edition

-- MAIN APPLICATION
addappid(545640)

-- MAIN APP DEPOTS / PACKAGES
addappid(545641,0,"8478dd9f00cd34bce559079121971df63fad925ce8f72e8adbbafef53190fc2b")

