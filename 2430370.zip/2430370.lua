-- Lua provided by RyzenAPI
-- Game: Striker Zone: Gun Games Online

-- MAIN APPLICATION
addappid(2430370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430371, 1, "b97848e1bbe7711ce94da8fbdf70e85a7a916de7034abab6fff4564ff05ac770")
addappid(2430372, 1, "e1f927a038892b6af9007c4b3675c71e442341baffb2378f33259d144eec4edc")
addappid(2430373, 1, "cd6d3fb48b3d8b4b7a0b629a5b94170ee1463040efcaa30c36b3e48dd3126b90")

