-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – Rocksmith Easy Exercises, Vol. 2

-- MAIN APPLICATION
addappid(1089222)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089222,0,"8148c074bec19a5266a673b4b0b8eb06190b8aa230db7b3c950da197236159bf")

