-- Lua provided by SkyAPI 
-- Game: AppID 2222720
addappid(2222720)
addappid(2222721, 1, "9bcd3cb4ffba7eabb29977d4df3e732d903702e93da6fda2880db48a2587cdd5")
