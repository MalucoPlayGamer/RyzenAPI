-- Lua provided by RyzenAPI
-- Game: 走亲戚大作战

-- MAIN APPLICATION
addappid(3007490)
-- Game: addappid(3007490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007491, 1, "5bc1e23bed2c14be4ecc1fe17f648b2d41e6ad550ad3c8941dafd20af1940d91")
