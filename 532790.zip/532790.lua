-- Lua provided by RyzenAPI
-- Game: AppID 532790

-- MAIN APPLICATION
addappid(532790)
addappid(1048510)
addappid(1048511)
addappid(1048512)
addappid(3992600)
addappid(3996800)
addappid(3996820)
-- Game: addappid(532790)

-- MAIN APP DEPOTS / PACKAGES
addappid(532791, 1, "5031e75920df33014e680cad671ff0895f9e439d33eedb5b5878aa407d5cb177")
