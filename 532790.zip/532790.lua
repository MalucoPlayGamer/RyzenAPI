-- Lua provided by RyzenAPI
-- Game: AppID 532790

-- MAIN APPLICATION
addappid(532790)
addappid(1048510)
addappid(1048511)
addappid(1048512)
addappid(3992600)
addappid(3996800)
addappid(3996820)

-- MAIN APP DEPOTS / PACKAGES
addappid(532791, 1, "5031e75920df33014e680cad671ff0895f9e439d33eedb5b5878aa407d5cb177")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
