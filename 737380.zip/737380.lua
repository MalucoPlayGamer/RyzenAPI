-- Lua provided by RyzenAPI
-- Game: Cutthroat

-- MAIN APPLICATION
addappid(737380)
addappid(752230)

-- MAIN APP DEPOTS / PACKAGES
addappid(737381,0,"93fbe631f05a287763782401d5a0611a128910504f98452e0b4e7a33775cefb6")

