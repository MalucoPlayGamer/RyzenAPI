-- Lua provided by RyzenAPI
-- Game: addappid(1678010)

-- MAIN APPLICATION
addappid(228990)
addappid(1678010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678012,0,"e0c1c161cf838799e3524d216094698fdb504e0795af9a283c3eda00f678eac1")
