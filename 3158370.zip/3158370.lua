-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3158370)
addappid(3158371)
addappid(3158372)
addappid(3158374)

-- MAIN APP DEPOTS / PACKAGES
addappid(3158373,0,"6c5d678627f4c980379b3ec7c47012a37e458a1bd1696190197179c1768948ff")
