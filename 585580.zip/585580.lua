-- Lua provided by RyzenAPI
-- Game: AppID 585580

-- MAIN APPLICATION
addappid(585580)

-- MAIN APP DEPOTS / PACKAGES
addappid(585581, 1, "991f4993c61c6d08152bb9d57b39b3b347f91022b093a83ef6e1ddb6b9b46eed")

