-- Lua provided by RyzenAPI
-- Game: Castle Crashers Demo

-- MAIN APPLICATION
addappid(207100)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(207101, 1, "929286cd335a46bf59eaea2a3cb7dceb4455a1f3910e8538680407e55ff3cad7")

