-- Lua provided by RyzenAPI
-- Game: AppID 1252260

-- MAIN APPLICATION
addappid(1252260)
-- Game: addappid(1252260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252261, 1, "4a6ef8dbe63a36f7ccc7ab0c478a7586e40758b429ab200d8e196aad3a807f40")
