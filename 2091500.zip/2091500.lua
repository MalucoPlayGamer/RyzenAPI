-- Lua provided by RyzenAPI
-- Game: Warlords Under Siege

-- MAIN APPLICATION
addappid(2091500)
-- Game: addappid(2091500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091501, 1, "4e845660c7eeae140561f31c279fb36b625f9c0277bda568e4a729dc867f16c3")
