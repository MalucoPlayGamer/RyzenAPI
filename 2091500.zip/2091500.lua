-- Lua provided by RyzenAPI
-- Game: Warlords Under Siege

-- MAIN APPLICATION
addappid(2091500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2091501, 1, "4e845660c7eeae140561f31c279fb36b625f9c0277bda568e4a729dc867f16c3")

