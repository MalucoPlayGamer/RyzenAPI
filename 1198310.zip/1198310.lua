-- Lua provided by RyzenAPI
-- Game: Mr.King Luo!Don't be kidding

-- MAIN APPLICATION
addappid(1198310)
addappid(1336720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198311, 1, "f7f2fa561b2bd86abcf0437743db59fa3d13214577a5bd38d5a7ec7aa5c6d64d")
