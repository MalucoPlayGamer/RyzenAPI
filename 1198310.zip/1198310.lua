-- Lua provided by RyzenAPI
-- Game: AppID 1198310

-- MAIN APPLICATION
addappid(1198310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198311, 1, "f7f2fa561b2bd86abcf0437743db59fa3d13214577a5bd38d5a7ec7aa5c6d64d")

