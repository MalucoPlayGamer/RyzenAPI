-- Lua provided by RyzenAPI
-- Game: HellSlave II: Judgment of the Archon

-- MAIN APPLICATION
addappid(3399900) -- HellSlave II: Judgment of the Archon

-- MAIN APP DEPOTS / PACKAGES
addappid(3399901, 1, "88e72ec90e6674a5ee2936a5caa8bf7b135728e41aff3c67f29c844a4ce2eb29") -- Depot 3399901

