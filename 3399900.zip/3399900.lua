-- 3399900's Lua and Manifest Created by Hubcap Manifest
-- HellSlave II: Judgment of the Archon
-- Created: August 04, 2026 at 14:29:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3399900) -- HellSlave II: Judgment of the Archon
-- MAIN APP DEPOTS
addappid(3399901, 1, "88e72ec90e6674a5ee2936a5caa8bf7b135728e41aff3c67f29c844a4ce2eb29") -- Depot 3399901
setManifestid(3399901, "5149550153041011647", 1846398054)