-- Lua provided by RyzenAPI
-- Game: Invisibox

-- MAIN APPLICATION
addappid(620940)

-- MAIN APP DEPOTS / PACKAGES
addappid(620941,0,"4c7b5f0d3b606ce8d38bd02d2285c7353c622e2f5f7ec62d98453a32627249dc")

