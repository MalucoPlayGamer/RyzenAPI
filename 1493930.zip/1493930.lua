-- Lua provided by RyzenAPI
-- Game: AppID 1493930

-- MAIN APPLICATION
addappid(1493930)
-- Game: addappid(1493930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493931, 1, "d5c592e60cf79ddd70e990efd5c50a672a8f474ebb24bda0c2a8afd988236d6f")
