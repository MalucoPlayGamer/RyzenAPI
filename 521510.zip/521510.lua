-- Lua provided by RyzenAPI
-- Game: addappid(521510)

-- MAIN APPLICATION
addappid(521510)
addappid(572280)

-- MAIN APP DEPOTS / PACKAGES
addappid(521511, 1, "5e3aa711b088a2bd31c0c02e83e7487cf5da958e795e7ebacb207d393060d31c")
