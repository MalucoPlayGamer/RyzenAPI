-- Lua provided by RyzenAPI
-- Game: MAGICAL×SPIRAL

-- MAIN APPLICATION
addappid(521510)
addappid(572280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(521511, 1, "5e3aa711b088a2bd31c0c02e83e7487cf5da958e795e7ebacb207d393060d31c")

