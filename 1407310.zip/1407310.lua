-- Lua provided by RyzenAPI
-- Game: Potion Party Demo

-- MAIN APPLICATION
addappid(1407310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407311, 1, "6a2494ceaf27da86d31ec60eb29f34efaafdf078426406750817b06df9c7a730")
