-- Lua provided by RyzenAPI
-- Game: GAMECINE VR

-- MAIN APPLICATION
addappid(1298620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298621, 1, "df83de7864301c01153cc7ba8b3d3ecf9f507f0863a6ee9d42c1da79ee7f5a4b")

