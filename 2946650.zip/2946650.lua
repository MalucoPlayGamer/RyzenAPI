-- Lua provided by RyzenAPI
-- Game: A Promise Best Left Unkept - Bonus Scenes [Season 2]

-- MAIN APPLICATION
addappid(2946650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946650,0,"4034aed620d002a0d8f7993413811d40c4d1f93323125c553cde0d3677ed1cbc")

