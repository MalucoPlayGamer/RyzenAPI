-- Lua provided by RyzenAPI
-- Game: 1875390

-- MAIN APPLICATION
addappid(1875390)
-- Game: addappid(1875390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875391, 1, "c6c40f5e21ca295efd72202a24dade6da2cdb2a3e1b40ccd4da44e6517561040")
