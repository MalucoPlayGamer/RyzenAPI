-- Lua provided by RyzenAPI
-- Game: 2244800

-- MAIN APPLICATION
addappid(2244800)
-- Game: addappid(2244800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244801, 1, "13f0ea930820b8fd67d96f0991c87b325088a0b894266eaeaaba1ecd2a46d20a")
