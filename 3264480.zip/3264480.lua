-- Lua provided by RyzenAPI
-- Game: addappid(3264480)

-- MAIN APPLICATION
addappid(3264480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264482,0,"892994075a51e5151e3bde5df83dedede314d7d5dc3130fa7fbf0f889de06d36")
addappid(3264484,0,"a00037f7d0db6d2338c16a1fae58969db1d336201b9546bccdd8c169cad61021")
