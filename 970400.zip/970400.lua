-- Lua provided by RyzenAPI
-- Game: Our Lovely Escape

-- MAIN APPLICATION
addappid(970400)

-- MAIN APP DEPOTS / PACKAGES
addappid(970401, 1, "bb7e343327e83b38bf089c7acae55e77a2460d20e5dc9adc4549d21334751afb")
addappid(1145710, 0, "d0e9c561fb6cc681a6155301f988614167896133bb09b330c595a1448130ed24")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1145711)
