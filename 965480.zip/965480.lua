-- Lua provided by RyzenAPI
-- Game: AppID 965480

-- MAIN APPLICATION
addappid(965480)
-- Game: addappid(965480)

-- MAIN APP DEPOTS / PACKAGES
addappid(965481, 1, "98bbbd669842f3528c5c58a50ff358ae7e2eeb402513aa7281efa863d10ee1a1")
