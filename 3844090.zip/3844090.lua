-- Lua provided by SkyAPI 
-- Game: Fatebound Cards: Sundering Cities
addappid(3844090)
addappid(3844091, 1, "ec908d5b39879dc194054a72a66489c0b27229127fa5e7682b5805be1ba81ba1")
