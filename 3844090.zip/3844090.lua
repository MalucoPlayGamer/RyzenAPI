-- Lua provided by RyzenAPI
-- Game: Fatebound Cards: Sundering Cities

-- MAIN APPLICATION
addappid(3844090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3844091, 1, "ec908d5b39879dc194054a72a66489c0b27229127fa5e7682b5805be1ba81ba1")

