-- Lua provided by SkyAPI 
-- Game: Vacuum Ball
addappid(1897140)
addappid(1897141, 1, "1465ababdfa9caa4b2b9df0b753e10432886b3125e8c6b31a8afdee601d8f6aa")
