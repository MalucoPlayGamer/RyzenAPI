-- Lua provided by RyzenAPI
-- Game: 1102901

-- MAIN APPLICATION
addappid(1102901)
-- Game: addappid(1102901)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102901,0,"af418e87c5ccc41a75a8932bb2c7862af8255a4d887951b45c7aacd88f46da81")
