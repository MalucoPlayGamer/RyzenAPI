-- Lua provided by RyzenAPI
-- Game: AL･FINE

-- MAIN APPLICATION
addappid(545330)

-- MAIN APP DEPOTS / PACKAGES
addappid(545331, 1, "3ffa15cd87d16388a440aa20d742db34e287042257c8f310241d16629b5e6527")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
