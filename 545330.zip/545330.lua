-- Lua provided by SkyAPI 
-- Game: AL･FINE
addappid(545330)
addappid(545331, 1, "3ffa15cd87d16388a440aa20d742db34e287042257c8f310241d16629b5e6527")
