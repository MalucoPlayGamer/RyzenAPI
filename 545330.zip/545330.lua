-- Lua provided by RyzenAPI
-- Game: Game: AL･FINE

-- MAIN APPLICATION
addappid(545330)
-- Game: addappid(545330)

-- MAIN APP DEPOTS / PACKAGES
addappid(545331, 1, "3ffa15cd87d16388a440aa20d742db34e287042257c8f310241d16629b5e6527")
