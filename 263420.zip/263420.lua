-- Lua provided by RyzenAPI
-- Game: 263420

-- MAIN APPLICATION
addappid(263420)
-- Game: addappid(263420)

-- MAIN APP DEPOTS / PACKAGES
addappid(263421, 1, "cad605676adff0807de1caff96d6d8545f228f88ab756ae6bc512b1cc686df90")
addappid(263422, 1, "939c76dc7fa850c6aa2ac704c70106163151afad637617cd0588a0a08b42cf39")
addappid(263423, 1, "46f6efb2d9902aa54ea516fe71ddc94f732c0d97bc1c0d6aaa57a1fdb4d3540b")
