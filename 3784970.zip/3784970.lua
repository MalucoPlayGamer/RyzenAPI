-- Lua provided by RyzenAPI
-- Game: The Way of the Ace Playtest

-- MAIN APPLICATION
addappid(3784970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3784971, 1, "6766e90f8dc623e173b4b662e40b39323d48584e9e1f4700e1c0966c7ec0b227")
