-- Lua provided by RyzenAPI
-- Game: addappid(887410)

-- MAIN APPLICATION
addappid(887410)

-- MAIN APP DEPOTS / PACKAGES
addappid(887411, 1, "d8ec25af21ecead64cc1047973c7a6960f625d2bc229b6cfe27af466c05d3de7")
