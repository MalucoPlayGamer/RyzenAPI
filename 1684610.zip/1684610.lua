-- Lua provided by RyzenAPI
-- Game: 1684610

-- MAIN APPLICATION
addappid(1684610)
-- Game: addappid(1684610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684611, 1, "422d0ca7bed09fca322fcb54c895d42cd7867afd3ea1f248b18839caddd7222e")
