-- 4635890's Lua and Manifest Created by Hubcap Manifest
-- Night Guard - The Last Shift
-- Created: August 20, 2026 at 19:12:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4635890) -- Night Guard - The Last Shift
-- MAIN APP DEPOTS
addappid(4635891, 1, "937bdb38480fd6a4787b0f3483cecf9da18c4f4d303d5644f305c0eed54a146d") -- Depot 4635891
setManifestid(4635891, "2698791033284270282", 221553133)