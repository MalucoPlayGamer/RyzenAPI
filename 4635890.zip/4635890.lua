-- Lua provided by RyzenAPI
-- Game: Night Guard - The Last Shift

-- MAIN APPLICATION
addappid(4635890) -- Night Guard - The Last Shift

-- MAIN APP DEPOTS / PACKAGES
addappid(4635891, 1, "937bdb38480fd6a4787b0f3483cecf9da18c4f4d303d5644f305c0eed54a146d") -- Depot 4635891

