-- Lua provided by RyzenAPI
-- Game: 1657020

-- MAIN APPLICATION
addappid(1657020)
-- Game: addappid(1657020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657021, 1, "772ee3f53b1ed1ec81225f81015afcc114aa20bfc366df37444534a64829d949")
