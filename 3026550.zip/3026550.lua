-- Lua provided by RyzenAPI
-- Game: Fluff's Adventure: A Tale of Fur and Steel Demo

-- MAIN APPLICATION
addappid(3026550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026551, 1, "5e9a877257bb853d5351e616e688f41826be36959e52363e1576ab733365f028")
