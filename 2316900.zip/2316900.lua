-- Lua provided by RyzenAPI
-- Game: Metavaxx

-- MAIN APPLICATION
addappid(2316900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316901,0,"345779ee4b514f13b4527b563da3ae02844e6967e0c80a6ab273c379e23d11e2")

