-- Lua provided by RyzenAPI
-- Game: Game: Aethergate: Battle of Artefacts

-- MAIN APPLICATION
addappid(3529190)
-- Game: addappid(3529190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3529191, 1, "eb06768242e72f566426cd0b266bdc702b2cfc9855d69ef3b2d6890bf6545d6b")
