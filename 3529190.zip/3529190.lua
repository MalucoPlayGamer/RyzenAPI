-- Lua provided by RyzenAPI
-- Game: Aethergate: Battle of Artefacts

-- MAIN APPLICATION
addappid(3529190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3529191, 1, "eb06768242e72f566426cd0b266bdc702b2cfc9855d69ef3b2d6890bf6545d6b")

