-- Lua provided by RyzenAPI
-- Game: Flinthook

-- MAIN APPLICATION
addappid(401710)
addappid(616530)

-- MAIN APP DEPOTS / PACKAGES
addappid(401711, 1, "db930d487cb7e59bfba46fa92912cacadca15c41201ed079d9fa85a9131fc7b4")
addappid(401712, 1, "2a5a7cedbd0f54f20a9df51b9301545d4105f909d254790102b802233048adf3")
addappid(401713, 1, "ca579e882348afd24bfc10391cc233f6e6ef2c1ffd4a3fa994b9de7bc426cc73")
addappid(401714, 1, "5a43b04304739046da049c34df95b8805091a8d1dfa58096925ee9f9b41257f0")

