-- Lua provided by RyzenAPI
-- Game: Flinthook

-- MAIN APPLICATION
addappid(401710)
addappid(616530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(401711, 1, "db930d487cb7e59bfba46fa92912cacadca15c41201ed079d9fa85a9131fc7b4")
addappid(401712, 1, "2a5a7cedbd0f54f20a9df51b9301545d4105f909d254790102b802233048adf3")
addappid(401713, 1, "ca579e882348afd24bfc10391cc233f6e6ef2c1ffd4a3fa994b9de7bc426cc73")
addappid(401714, 1, "5a43b04304739046da049c34df95b8805091a8d1dfa58096925ee9f9b41257f0")

