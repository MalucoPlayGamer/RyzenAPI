-- Lua provided by RyzenAPI
-- Game: 1857940

-- MAIN APPLICATION
addappid(1857940)
-- Game: addappid(1857940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857940,0,"c828e4cba33d14cd5aa417b124ebf3ae9599cc4f5f01939ef29d206a7644f0e2")
