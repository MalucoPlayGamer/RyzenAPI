-- Lua provided by RyzenAPI
-- Game: Claws of Furry

-- MAIN APPLICATION
addappid(656580)

-- MAIN APP DEPOTS / PACKAGES
addappid(656581,0,"070e1e30beca3fe44d8c4ae150bcc76fef64fb9a2e48b5870172d76d03240973")

