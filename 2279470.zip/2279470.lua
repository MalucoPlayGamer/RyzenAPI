-- Lua provided by RyzenAPI
-- Game: Street Sense 2

-- MAIN APPLICATION
addappid(2279470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279471, 1, "05e3a42f983130cc4e67a2050fd6a187ec8ecbc3cbf83490a47eb14aae2f5991")
addappid(2279472, 1, "e4ac3d9ae61aa7a354c3ecd61b4c02d6fb4f0141dd8bb4121408c18e6e1f8e3d")

