-- Lua provided by RyzenAPI
-- Game: addappid(765610)

-- MAIN APPLICATION
addappid(765610)

-- MAIN APP DEPOTS / PACKAGES
addappid(765611, 1, "a49f71f63981377c755a8b2e3a0d296aa451ba260c835dce3049483d606b0ab8")
