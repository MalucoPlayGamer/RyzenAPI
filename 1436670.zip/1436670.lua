-- Lua provided by RyzenAPI
-- Game: Game: Pumpkin Jack Original Soundtrack

-- MAIN APPLICATION
addappid(1436670)
-- Game: addappid(1436670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436671, 1, "f0129d23ad4fa1375adc29f3052f3509b81a3e2d102677ce4118445de2a372e0")
addappid(1436672, 1, "a9c7be88eb7c930a6e9ce630cf09a5c5b9ef1663d218b725ff83a001291455a3")
