-- Lua provided by RyzenAPI
-- Game: Dancin Divas Demo

-- MAIN APPLICATION
addappid(2022320)
-- Game: addappid(2022320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022321, 1, "af14e289928986bfae067542999da5a90b86619fbd59be8f9de991444d069c3e")
