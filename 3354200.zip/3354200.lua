-- Lua provided by RyzenAPI
-- Game: Bakso Simulator 2

-- MAIN APPLICATION
addappid(3354200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354201,0,"c7d1a8fc80f9948dd4fb4a61a595d81b35de48b347f6f9a95f4d4d97d6dadb61")

