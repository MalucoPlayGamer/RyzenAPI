-- Lua provided by RyzenAPI
-- Game: Train Valley Origins

-- MAIN APPLICATION
addappid(3451440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451441, 1, "842c2aca561de0611a4f21a9991e94b18d41b151599c18c4c76f92c8758bcd1b")
