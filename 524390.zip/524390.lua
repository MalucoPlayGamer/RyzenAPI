-- Lua provided by RyzenAPI
-- Game: PCMark 10

-- MAIN APPLICATION
addappid(524390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(524391, 1, "d0f906dbe47db053001d53f1890e418dc5d4d140d59eccf92ef66dff1f1d8898")
addappid(524392, 1, "62f8228a77ed5a3cee2fd802c9afe806f501b4195cc37d66a5868be915a2d0b6")
addappid(524393, 1, "24e1ec96a5877bd7352a4bf230ceb831592d4253b2d866cf16a89929bfbce826")
