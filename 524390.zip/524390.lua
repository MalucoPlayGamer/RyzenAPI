-- Lua provided by RyzenAPI 
-- Game: AppID 524390
addappid(524390)
addappid(524391, 1, "d0f906dbe47db053001d53f1890e418dc5d4d140d59eccf92ef66dff1f1d8898")
addappid(524392, 1, "62f8228a77ed5a3cee2fd802c9afe806f501b4195cc37d66a5868be915a2d0b6")
addappid(524393, 1, "24e1ec96a5877bd7352a4bf230ceb831592d4253b2d866cf16a89929bfbce826")
