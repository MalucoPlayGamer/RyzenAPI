-- Lua provided by RyzenAPI
-- Game: The Mutineer

-- MAIN APPLICATION
addappid(1385670)
-- Game: addappid(1385670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385671, 1, "2555ca65c7c041d8705a67d8d26c7297862f9b0b56a7aeae87288f072a6dd867")
