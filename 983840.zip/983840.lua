-- Lua provided by RyzenAPI
-- Game: Game: AppID 983840

-- MAIN APPLICATION
addappid(983840)
-- Game: addappid(983840)

-- MAIN APP DEPOTS / PACKAGES
addappid(983841, 1, "e068b4baa3515c27c1331eab2ac8891cd1d1ee227da5c0aaf415ca4639dd0e7d")
