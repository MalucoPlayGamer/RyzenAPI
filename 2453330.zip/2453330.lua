-- Lua provided by RyzenAPI
-- Game: Midnight Heist Demo

-- MAIN APPLICATION
addappid(2453330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453331, 1, "c8c54f2a4942b0d7ac4a815f17b0fa7d1aaa4cc3c0cac3cb0279e0d404f4580e")
