-- Lua provided by RyzenAPI
-- Game: addappid(2529120)

-- MAIN APPLICATION
addappid(2529120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529121, 1, "7b596a9f1c177977de7a3626a7bc624007bbc310a506eadbf0b904de1cf6a5ef")
