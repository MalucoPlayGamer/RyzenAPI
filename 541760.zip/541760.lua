-- Lua provided by RyzenAPI
-- Game: The Frontier

-- MAIN APPLICATION
addappid(541760)

-- MAIN APP DEPOTS / PACKAGES
addappid(541761, 1, "34ae10f0e858d445cda5dcb562af72a340365f5ee84a24927407795e52f3f5df")
