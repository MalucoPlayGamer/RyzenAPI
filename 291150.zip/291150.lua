-- Lua provided by RyzenAPI
-- Game: Evolution RTS

-- MAIN APPLICATION
addappid(291150)
-- Game: addappid(291150)

-- MAIN APP DEPOTS / PACKAGES
addappid(291151, 1, "a1389316fe7deeef48b1bdc41f6446e6b3af7121874df1ad3f100f59c38d8775")
