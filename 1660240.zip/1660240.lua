-- Lua provided by RyzenAPI
-- Game: AppID 1660240

-- MAIN APPLICATION
addappid(1660240)
-- Game: addappid(1660240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660241, 1, "4a0a6003d51abb23251a7fb4e63ee5c9336c4c60d71e4f25cbc3dffeca686126")
