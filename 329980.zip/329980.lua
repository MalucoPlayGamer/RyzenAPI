-- Lua provided by RyzenAPI
-- Game: ASA: A Space Adventure - Remastered Edition

-- MAIN APPLICATION
addappid(329980)

-- MAIN APP DEPOTS / PACKAGES
addappid(329983,0,"ba953d6519758334d4de9eeb12e82a7d458313a1b5e5f154a822fdfd90e25ef9")
addappid(1561790,0,"104e202eaecf884d053a2583b16b550095212460c51eb57359d3d1aa0ca9dc97")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
