-- Lua provided by RyzenAPI
-- Game: Stockwrk7

-- MAIN APPLICATION
addappid(743770)
-- Game: addappid(743770)

-- MAIN APP DEPOTS / PACKAGES
addappid(743772,0,"97910ebc746b8ba9863c24364e732c6fea22b6218f6be7b650551b21834ca3b3")
