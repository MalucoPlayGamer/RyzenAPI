-- Lua provided by RyzenAPI
-- Game: addappid(1667320)

-- MAIN APPLICATION
addappid(1667320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667321, 1, "395e98290fd955758ca4ba113379fb59506f24b951642a822dfac986b545cffa")
