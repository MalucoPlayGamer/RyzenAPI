-- Lua provided by RyzenAPI 
-- Game: PRODUCER 2021
addappid(1667320)
addappid(1667321, 1, "395e98290fd955758ca4ba113379fb59506f24b951642a822dfac986b545cffa")
