-- Lua provided by RyzenAPI
-- Game: 975530

-- MAIN APPLICATION
addappid(975530)
-- Game: addappid(975530)

-- MAIN APP DEPOTS / PACKAGES
addappid(975530,0,"db07704036e9a8464a0953d0e15e3d09e21706044348adcf0ad70c9fca92d6ef")
