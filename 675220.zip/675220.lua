-- Lua provided by RyzenAPI
-- Game: SoulFrost

-- MAIN APPLICATION
addappid(675220)
addappid(690880)

-- MAIN APP DEPOTS / PACKAGES
addappid(675221, 1, "d994e67126f3b4b738e8fd46cf18fa17463c3f70b7ee471fda0e302f58436f96")
