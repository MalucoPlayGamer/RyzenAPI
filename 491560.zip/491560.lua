-- Lua provided by RyzenAPI
-- Game: 491560

-- MAIN APPLICATION
addappid(491560)
-- Game: addappid(491560)

-- MAIN APP DEPOTS / PACKAGES
addappid(491561, 1, "05ca412c17f705ed77591efdbbfc596c2138d1cde2dfbfa6a3f42f373ea9da60")
addappid(491562, 1, "8da7a6106bdbb18c465fab6819474fb413e2663d8148f60243e27ea4b1370273")
