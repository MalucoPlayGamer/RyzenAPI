-- Lua provided by RyzenAPI
-- Game: Momonga Pinball Adventures

-- MAIN APPLICATION
addappid(491560)

-- MAIN APP DEPOTS / PACKAGES
addappid(491561, 1, "05ca412c17f705ed77591efdbbfc596c2138d1cde2dfbfa6a3f42f373ea9da60")
addappid(491562, 1, "8da7a6106bdbb18c465fab6819474fb413e2663d8148f60243e27ea4b1370273")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
