-- Lua provided by RyzenAPI
-- Game: Cyber Slayer

-- MAIN APPLICATION
addappid(2153410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153411, 1, "e789c660202f0ae9e7bf6a0fcff9f82faadf6f803920b9c7a1103fb4a10ddef7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
