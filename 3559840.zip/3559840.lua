-- Lua provided by RyzenAPI
-- Game: Sakura Hime 6

-- MAIN APPLICATION
addappid(3601070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3559840, 1, "7e841be408d7b5267fab333449c67d96b31723d05a27fa321f015a3b7ef04696") -- Sakura Hime 6
addappid(3559841, 1, "2ff0ffad4ba92410ea12630a93a0d4cd3659f7aeaa455429d4ed33ef300a5e34") -- Depot 3559841
addappid(3601070, 1, "702c671a1a5590e22230205f6ab94028ecc798307e3dbd3f0300f7d523699773") -- Sakura Hime 6 - 18 Adult Only Content - Depot 3601070

