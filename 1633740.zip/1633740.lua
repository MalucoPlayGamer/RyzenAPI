-- Lua provided by RyzenAPI 
-- Game: Pegasus: Broken Wings
addappid(1633740)
addappid(1633741, 1, "01f7d3655f16d97276816e754066bf50b56a5582a5e50488ffc202bc6651d885")
