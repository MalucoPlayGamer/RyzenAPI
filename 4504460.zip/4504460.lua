-- Lua provided by RyzenAPI
-- Game: Lihiman

-- MAIN APPLICATION
addappid(4504460)

-- MAIN APP DEPOTS / PACKAGES
addappid(4504461, 1, "b1c736de4b4c520321aabd153ae984e3f5f108e1c62b038713b5909d82a3541f") -- Main

