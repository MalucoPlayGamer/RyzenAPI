-- Lua provided by RyzenAPI
-- Game: Game: Meria and The Island of Orcs

-- MAIN APPLICATION
addappid(1720040)
-- Game: addappid(1720040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720041, 1, "d450f34ed8c767727bb92ab0af0b21d70f5f78ba9d4e4dcd9e2eebddde44dbb2")
