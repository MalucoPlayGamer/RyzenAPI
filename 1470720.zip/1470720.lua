-- Lua provided by RyzenAPI
-- Game: 1470720

-- MAIN APPLICATION
addappid(1470720)
-- Game: addappid(1470720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470721, 1, "5509c4a88a08894e4ca67a52998f24a41e315fb2b6655f5af7bbe5ea0f3c8807")
