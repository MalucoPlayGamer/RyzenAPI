-- Lua provided by RyzenAPI
-- Game: addappid(2406000)

-- MAIN APPLICATION
addappid(2406000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406001, 1, "86a85e99dd003a7e27234e3dda41ed78d165f37613a46a122f6cd0fac88eeea2")
