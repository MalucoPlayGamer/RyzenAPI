-- Lua provided by SkyAPI 
-- Game: The Devourer: Hunted Souls Demo
addappid(2406000)
addappid(2406001, 1, "86a85e99dd003a7e27234e3dda41ed78d165f37613a46a122f6cd0fac88eeea2")
