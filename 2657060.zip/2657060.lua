-- Lua provided by RyzenAPI
-- Game: addappid(2657060)

-- MAIN APPLICATION
addappid(2657060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657060,0,"e0d5e7a570d792711265ff7532a2dc8bce4648837e8d86c94dcf77f531c09baf")
