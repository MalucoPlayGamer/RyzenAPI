-- Lua provided by RyzenAPI 
-- Game: AppID 2213210
addappid(2213210)
addappid(2213211, 1, "e41e035dc541e8d44360b584530c1fd7a3e98b14043fa95c8b548eea3dccbc89")
