-- Lua provided by RyzenAPI
-- Game: Mech Arena

-- MAIN APPLICATION
addappid(1809860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809861, 1, "c105271e37ef1d8d04d75c37fc06afd0abffb50916e7fa7729b4e4e9460fc393")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
