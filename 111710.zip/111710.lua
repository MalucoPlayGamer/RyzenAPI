-- Lua provided by RyzenAPI
-- Game: Nuclear Dawn - Dedicated Server

-- MAIN APPLICATION
addappid(111710)

-- MAIN APP DEPOTS / PACKAGES
addappid(111711, 1, "ad279ccf1a7f89714d081c149024c4371c8be8d533bf00ce8017b87555d57427")
