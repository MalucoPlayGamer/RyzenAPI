-- Lua provided by RyzenAPI
-- Game: 武侠乂

-- MAIN APPLICATION
addappid(840140)
addappid(891630)
addappid(891660)

-- MAIN APP DEPOTS / PACKAGES
addappid(840141,0,"f49770c8a2459b40b140922d19bd4faadbd28736ee72a09e55084bf50d1d6241")

