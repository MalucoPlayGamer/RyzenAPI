-- Lua provided by RyzenAPI
-- Game: 武侠乂 The Swordsmen X

-- MAIN APPLICATION
addappid(840140)

-- MAIN APP DEPOTS / PACKAGES
addappid(840141, 1, "f49770c8a2459b40b140922d19bd4faadbd28736ee72a09e55084bf50d1d6241")

