-- Lua provided by RyzenAPI
-- Game: 武侠乂

-- MAIN APPLICATION
addappid(840140)
addappid(891630)
addappid(891660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(840141,0,"f49770c8a2459b40b140922d19bd4faadbd28736ee72a09e55084bf50d1d6241")

