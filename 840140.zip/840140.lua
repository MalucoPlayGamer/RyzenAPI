-- Lua provided by RyzenAPI
-- Game: 840140

-- MAIN APPLICATION
addappid(840140)
-- Game: addappid(840140)

-- MAIN APP DEPOTS / PACKAGES
addappid(840141, 1, "f49770c8a2459b40b140922d19bd4faadbd28736ee72a09e55084bf50d1d6241")
