-- Lua provided by RyzenAPI
-- Game: 盗墓密探

-- MAIN APPLICATION
addappid(2178310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178311, 1, "7df3a6799c8d114d64e97debc84ff71be9ffec5a68d2b5c39761135d2404482c")

