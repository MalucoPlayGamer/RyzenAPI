-- Lua provided by RyzenAPI
-- Game: Adabana Odd Tales Demo

-- MAIN APPLICATION
addappid(1263380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263381, 1, "a6c3ee2329fcf8d9eb78844fa7df1e0563ab9232012f740ec0d0ddfe96688a88")

