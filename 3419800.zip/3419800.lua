-- Lua provided by RyzenAPI
-- Game: The Little Pixel That Could

-- MAIN APPLICATION
addappid(3419800)
-- Game: addappid(3419800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419801, 1, "5dfb8c1ac5f69a5be3338f051ccf56cec663525e279b1c59c72ea8e107c13dd1")
