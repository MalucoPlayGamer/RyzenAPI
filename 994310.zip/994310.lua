-- Lua provided by RyzenAPI
-- Game: Let's Sing 2019

-- MAIN APPLICATION
addappid(994310)
-- Game: addappid(994310)

-- MAIN APP DEPOTS / PACKAGES
addappid(994311, 1, "32b8218d110a3de281cf43858b900d7372507801d5f5783adadb522706a5ec82")
