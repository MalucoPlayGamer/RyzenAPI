-- Lua provided by RyzenAPI
-- Game: addappid(3224740)

-- MAIN APPLICATION
addappid(3224740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224741, 1, "cc293068b15752edf32dad5f0ed70304634b9ddbc371e0341719962ce1e25a05")
