-- Lua provided by RyzenAPI
-- Game: The Adventures of Jason and the Argonauts

-- MAIN APPLICATION
addappid(1022840)
-- Game: addappid(1022840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022841, 1, "2f63cac0ceaa3ff3e1e30e0aecffcd85407930a0690d946afba56e3df4a33f1e")
addappid(1022842, 1, "97fb778352688b20f174a6457be980e8076c9ea0c5b620c396bb689d56bc15fc")
addappid(1022843, 1, "1777bfb42b734e5d6dafe9e2cdc8dc8db8bb7c10b6346f18cb1c86bf2c14f821")
addappid(1022844, 1, "d9414829353fe894c1fce9590de41b458c15e77e14c75a8bbeffe5129e0c20cd")
addappid(1022845, 1, "472837674dfcaa1cf9e9e128bbce1aea99c8006a408c58df306d9e34f4dc4284")
addappid(1022846, 1, "6a53d42b9d4637d1c2c23442394a619df240d68e138efff7e093b5dda2c1e494")
addappid(1022847, 1, "d4692780cd1e66713c2f3a4ab5e2bad3fc8a40c1100dca78dca66374618a2038")
