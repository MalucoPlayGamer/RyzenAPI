-- Lua provided by RyzenAPI
-- Game: 473710

-- MAIN APPLICATION
addappid(473710)
-- Game: addappid(473710)

-- MAIN APP DEPOTS / PACKAGES
addappid(473711, 1, "1399a4320213b65286d52fc7811860d21c6eacac633a9b333e7abfa90110e939")
