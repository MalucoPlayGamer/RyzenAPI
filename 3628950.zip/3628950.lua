-- Lua provided by SkyAPI 
-- Game: Succubus Successor: Delilah's Juicy Journey
addappid(3628950)
addappid(3628951, 1, "e3609b671bf2f7a6bac8a1a1400c623a98744aae13e7439da56e6d0671149ec6")
addappid(3628952, 1, "b87ab725b1e81ad396d09037ad31b1ea27ba5d61cbc7ffadb2f8bb7fb7f3a8f6")
addappid(4718751, 1, "7b316edcb17b5b61df21a8bf5fe913d30c407c8a13ad347fc9adc21b058c92f9")
addappid(4644260, 0, "41a885b51961ef2218d73264db11ba87f3edce28e17d081837d0b78f4d22298f")
addappid(4718750, 0, "9186347a9f3be8ed1990497511ee6d3363f4a48a60c513a7261cf017523163fd")
