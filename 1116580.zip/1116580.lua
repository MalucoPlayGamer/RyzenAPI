-- Lua provided by RyzenAPI
-- Game: addappid(1116580)

-- MAIN APPLICATION
addappid(1116580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116581, 1, "9b166a74a81bae2ce800971f23d929c918158fcabab663fa6a103fbac57d50e6")
