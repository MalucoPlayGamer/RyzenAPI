-- Lua provided by RyzenAPI
-- Game: AppID 1116580

-- MAIN APPLICATION
addappid(1116580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116581, 1, "9b166a74a81bae2ce800971f23d929c918158fcabab663fa6a103fbac57d50e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
