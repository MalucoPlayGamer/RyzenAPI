-- Lua provided by RyzenAPI
-- Game: Karambola

-- MAIN APPLICATION
addappid(765480)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3172920)
