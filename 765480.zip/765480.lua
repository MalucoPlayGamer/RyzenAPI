-- Lua provided by RyzenAPI
-- Game: Karambola

-- MAIN APPLICATION
addappid(765480)
addappid(3172920)

