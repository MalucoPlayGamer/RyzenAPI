-- Lua provided by RyzenAPI
-- Game: addappid(2669360)

-- MAIN APPLICATION
addappid(2669360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669361, 1, "d0945427a75897ebf551e5d57660b66c67e276511b1e0bef90039bf01c0e3de9")
