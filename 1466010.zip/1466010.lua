-- Lua provided by SkyAPI 
-- Game: FPV Speed Drone
addappid(1466010)
addappid(1466011, 1, "63c3100d471150b2e4da29b267ae5c91b8f0751339b25d0912e31c86ee132a9d")
