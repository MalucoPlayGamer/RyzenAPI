-- 4669670's Lua and Manifest Created by Hubcap Manifest
-- Curse of the Crimson Stag
-- Created: August 27, 2026 at 05:42:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4669670) -- Curse of the Crimson Stag
addtoken(4669670, "17025159380152276463")
-- MAIN APP DEPOTS
addappid(4669671, 1, "b57297abaa91b7fbdec59af9f7c20aa737e8ee5d0a484a5f65b968e1585c7793") -- Depot 4669671
setManifestid(4669671, "7962159853773704906", 0)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4669730) -- Depot 4669730 (empty depot)