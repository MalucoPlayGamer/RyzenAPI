-- Lua provided by RyzenAPI
-- Game: Curse of the Crimson Stag

-- MAIN APPLICATION
addappid(4669670) -- Curse of the Crimson Stag
-- addappid(4669730) -- Depot 4669730 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4669671, 1, "b57297abaa91b7fbdec59af9f7c20aa737e8ee5d0a484a5f65b968e1585c7793") -- Depot 4669671
addtoken(4669670, "17025159380152276463")

