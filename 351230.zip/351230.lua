-- Lua provided by RyzenAPI
-- Game: Counter Spell

-- MAIN APPLICATION
addappid(351230)

-- MAIN APP DEPOTS / PACKAGES
addappid(351231, 1, "78a3de16d5a9ca0f922a748b0444a83b04a154c3e827dfc2c79e288f17aab8fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
