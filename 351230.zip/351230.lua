-- Lua provided by RyzenAPI
-- Game: addappid(351230)

-- MAIN APPLICATION
addappid(351230)

-- MAIN APP DEPOTS / PACKAGES
addappid(351231, 1, "78a3de16d5a9ca0f922a748b0444a83b04a154c3e827dfc2c79e288f17aab8fb")
