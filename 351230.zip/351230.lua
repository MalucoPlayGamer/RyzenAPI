-- Lua provided by SkyAPI 
-- Game: Counter Spell
addappid(351230)
addappid(351231, 1, "78a3de16d5a9ca0f922a748b0444a83b04a154c3e827dfc2c79e288f17aab8fb")
