-- Lua provided by RyzenAPI
-- Game: Glowstick

-- MAIN APPLICATION
addappid(2508360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508361, 1, "b34f98311e7d5356db3be7d255dc4e190a0d9d61bd21b51a9810f66f43c914e2")
