-- Lua provided by RyzenAPI
-- Game: Shoe it All!

-- MAIN APPLICATION
addappid(2978860) -- Shoe it All!

-- MAIN APP DEPOTS / PACKAGES
addappid(2978861, 1, "598ab650eac1ee0dcd7688b6c97d4836e8ffa5960016d6d02c0080ea83107102") -- Depot 2978861
addappid(2978862, 1, "cd3c7411081396535ba51d39f361d4629f63b7790c44d6d9cc67b89e36ee168c") -- Depot 2978862

