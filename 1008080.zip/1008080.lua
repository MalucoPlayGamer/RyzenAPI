-- Lua provided by RyzenAPI
-- Game: SYNCED

-- MAIN APPLICATION
addappid(1008080)
addappid(2436610)
addappid(2490070)
addappid(2519330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1008081, 1, "d8e5fe395c03c0998ce33a882c7ee4cbece04a5c210a55ee1ab6e8b559ff5cae")

