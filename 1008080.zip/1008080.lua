-- Lua provided by RyzenAPI
-- Game: SYNCED

-- MAIN APPLICATION
addappid(1008080)
-- Game: addappid(1008080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008081, 1, "d8e5fe395c03c0998ce33a882c7ee4cbece04a5c210a55ee1ab6e8b559ff5cae")
