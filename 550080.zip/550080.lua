-- Lua provided by RyzenAPI
-- Game: AppID 550080

-- MAIN APPLICATION
addappid(550080)

-- MAIN APP DEPOTS / PACKAGES
addappid(550081, 1, "1ddd3d3b41df501150dd597a0c75938b7db179123198cb3ff609901871234148")
addappid(556760, 0, "16acfe2d8b8d854b022ecb03717386ca755d57872758427ac6a1b73529409991")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
