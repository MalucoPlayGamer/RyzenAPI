-- Lua provided by RyzenAPI
-- Game: Game: AppID 1112940

-- MAIN APPLICATION
addappid(1112940)
-- Game: addappid(1112940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112941, 1, "3176779d8ec73d185e0bab63e09ea794903872a528e96b6928e48b0eea0b8f71")
