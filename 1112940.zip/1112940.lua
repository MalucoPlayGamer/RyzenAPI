-- Lua provided by SkyAPI 
-- Game: AppID 1112940
addappid(1112940)
addappid(1112941, 1, "3176779d8ec73d185e0bab63e09ea794903872a528e96b6928e48b0eea0b8f71")
