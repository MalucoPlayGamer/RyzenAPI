-- Lua provided by RyzenAPI
-- Game: AppID 1112940

-- MAIN APPLICATION
addappid(1112940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112941, 1, "3176779d8ec73d185e0bab63e09ea794903872a528e96b6928e48b0eea0b8f71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
