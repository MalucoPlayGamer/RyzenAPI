-- Lua provided by RyzenAPI
-- Game: Game: Backfirewall_

-- MAIN APPLICATION
addappid(1920100)
-- Game: addappid(1920100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920101, 1, "0f725f21cd8403396b1078567c7ab310c00a412c2283475bc4481d6725d6f963")
