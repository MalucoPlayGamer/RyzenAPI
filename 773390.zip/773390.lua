-- Lua provided by RyzenAPI
-- Game: Aim Trainer Pro

-- MAIN APPLICATION
addappid(773390)
-- Game: addappid(773390)

-- MAIN APP DEPOTS / PACKAGES
addappid(773391, 1, "c1b1edb798f24055c677e872c5f60b99a71970382d3a47a1cafbcf1e7a72b7e5")
