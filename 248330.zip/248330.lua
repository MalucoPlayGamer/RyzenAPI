-- Lua provided by RyzenAPI
-- Game: addappid(248330)

-- MAIN APPLICATION
addappid(248330)

-- MAIN APP DEPOTS / PACKAGES
addappid(248331, 1, "d1a34f2c0b4b7e5511c79ae2cdb361e58afbbdc564ab87469ff8205997fdc9a8")
addappid(248332, 1, "2bf8162bafc4554e3a7965e394c99adc15f734ba46eaca35a3b9cd085878461f")
