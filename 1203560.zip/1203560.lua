-- Lua provided by SkyAPI 
-- Game: AppID 1203560
addappid(1203560)
addappid(1203561, 1, "762a055b14235a7782cf2724d4df04fcc924a29a792808138e9ff0edc29b3bb6")
