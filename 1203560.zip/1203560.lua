-- Lua provided by RyzenAPI
-- Game: AppID 1203560

-- MAIN APPLICATION
addappid(1203560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1203561, 1, "762a055b14235a7782cf2724d4df04fcc924a29a792808138e9ff0edc29b3bb6")

