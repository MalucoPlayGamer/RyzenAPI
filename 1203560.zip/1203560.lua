-- Lua provided by RyzenAPI
-- Game: 1203560

-- MAIN APPLICATION
addappid(1203560)
-- Game: addappid(1203560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203561, 1, "762a055b14235a7782cf2724d4df04fcc924a29a792808138e9ff0edc29b3bb6")
