-- Lua provided by SkyAPI 
-- Game: SAMUDRA
addappid(1116260)
addappid(1116261, 1, "f611537201f93b8710a52797c5e8cf61e3e51e6cd35bfc1edfd557a9d0468d7c")
addappid(1799330, 0, "733af9e10a0c1bc0704985b072d0c2f5cf6791055b858569b4dcb7d1efab12f2")
