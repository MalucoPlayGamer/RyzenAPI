-- Lua provided by RyzenAPI
-- Game: Game: Battle royale simulator

-- MAIN APPLICATION
addappid(913180)
-- Game: addappid(913180)

-- MAIN APP DEPOTS / PACKAGES
addappid(913181, 1, "dc847f375bad2f0ee3730825a7860376e511f96cd2dd2d05fcfbbfbb8cab8414")
