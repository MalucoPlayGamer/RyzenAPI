-- Lua provided by SkyAPI 
-- Game: AppID 2577530
addappid(2577530)
addappid(2577531, 1, "e556c5656d0c6bf98aec371e24f560399ff567c2912247b4f6fa94fd7bdf7d9f")
