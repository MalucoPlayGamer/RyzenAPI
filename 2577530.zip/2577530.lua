-- Lua provided by RyzenAPI
-- Game: 尊无二上 Demo

-- MAIN APPLICATION
addappid(2577530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577531, 1, "e556c5656d0c6bf98aec371e24f560399ff567c2912247b4f6fa94fd7bdf7d9f")

