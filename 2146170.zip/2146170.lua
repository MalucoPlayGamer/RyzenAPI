-- Lua provided by RyzenAPI
-- Game: Baten Kaitos I & II HD Remaster

-- MAIN APPLICATION
addappid(2146170)
-- Game: addappid(2146170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146171, 1, "79680b029dd7bb86bfb4203bb1496a2a45198b31bfa573d55147e698e2777655")
addappid(2627850, 0, "0835a4f30f1c48cb74e2cf66e26b68c036e44f2508716a5ac8ce693b9d7ca8d4")
