-- Lua provided by RyzenAPI
-- Game: addappid(958510)

-- MAIN APPLICATION
addappid(958510)

-- MAIN APP DEPOTS / PACKAGES
addappid(958511, 1, "85169293ecac411056c93188b860fa613e0a28100bdb27755c3e0fdecd99f5b0")
