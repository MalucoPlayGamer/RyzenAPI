-- Lua provided by RyzenAPI
-- Game: Assault on Hyperion Base

-- MAIN APPLICATION
addappid(958510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(958511, 1, "85169293ecac411056c93188b860fa613e0a28100bdb27755c3e0fdecd99f5b0")

