-- Lua provided by RyzenAPI
-- Game: AppID 2751020

-- MAIN APPLICATION
addappid(2751020)
-- Game: addappid(2751020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751021, 1, "3a992e2f29238cfb11cf9b8fbb88481fcc0d489ab1c54476e63236c8456f803a")
