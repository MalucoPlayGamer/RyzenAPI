-- Lua provided by RyzenAPI
-- Game: AppID 636910

-- MAIN APPLICATION
addappid(636910)

-- MAIN APP DEPOTS / PACKAGES
addappid(636911, 1, "787a3773bcd045f608681e34b21b8aac0aadb7dde49b9ac8988387c360afd132")

