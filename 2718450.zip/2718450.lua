-- Lua provided by RyzenAPI
-- Game: The Backrooms Regret

-- MAIN APPLICATION
addappid(2718450)
-- Game: addappid(2718450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718451, 1, "473bc35bcc9862e840d8a259bfea8bff252df55499132be9b3dce15bc4783c4b")
