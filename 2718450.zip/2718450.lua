-- Lua provided by RyzenAPI 
-- Game: The Backrooms Regret
addappid(2718450)
addappid(2718451, 1, "473bc35bcc9862e840d8a259bfea8bff252df55499132be9b3dce15bc4783c4b")
