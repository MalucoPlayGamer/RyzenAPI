-- Lua provided by RyzenAPI
-- Game: Gangster War

-- MAIN APPLICATION
addappid(1538410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538411, 1, "87433c6de74b10d4e94e7a97500e633af984541e681b2d402b47d51fd61006ad")

