-- Lua provided by RyzenAPI
-- Game: Game: DrugRunner

-- MAIN APPLICATION
addappid(2197000)
-- Game: addappid(2197000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197001, 1, "48c071b6a6b95c5f2b5312b536e4b8283019966e4a2d26e96df4559ba3d420ad")
