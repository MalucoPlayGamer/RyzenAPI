-- Lua provided by RyzenAPI
-- Game: DrugRunner

-- MAIN APPLICATION
addappid(2197000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197001, 1, "48c071b6a6b95c5f2b5312b536e4b8283019966e4a2d26e96df4559ba3d420ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
