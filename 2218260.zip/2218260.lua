-- Lua provided by RyzenAPI
-- Game: Nuclear Option Playtest

-- MAIN APPLICATION
addappid(2218260)
-- Game: addappid(2218260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218261, 1, "e07af924a2876271bc5acd63a662ed957f9bdbddd0e085a191c11ef54a405093")
