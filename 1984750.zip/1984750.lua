-- Lua provided by RyzenAPI
-- Game: My Furry Maid - 18+ Adult Only Patch

-- MAIN APPLICATION
addappid(1984750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984750,0,"628c6661b992d444fc02e265cb763106a5c4bd5a86a1d84127874af88e453a4c")
