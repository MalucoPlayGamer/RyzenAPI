-- Lua provided by RyzenAPI 
-- Game: AppID 1171660
addappid(1171660)
addappid(1171661, 1, "ca351a6e67213a4ab5ebb054eeeffa895a7461ff9d1d0f70931bb502019ceba8")
