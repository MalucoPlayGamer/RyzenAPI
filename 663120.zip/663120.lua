-- Lua provided by RyzenAPI
-- Game: 663120

-- MAIN APPLICATION
addappid(663120)
-- Game: addappid(663120)

-- MAIN APP DEPOTS / PACKAGES
addappid(663121, 1, "ee4969a01f7fa6915f3dcdd699353fce79c0ab7d115d764e7ad4bd6f0c96c6cf")
