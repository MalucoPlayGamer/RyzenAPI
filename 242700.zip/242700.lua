-- Lua provided by RyzenAPI
-- Game: Game: Injustice: Gods Among Us Ultimate Edition

-- MAIN APPLICATION
addappid(242700)
-- Game: addappid(242700)

-- MAIN APP DEPOTS / PACKAGES
addappid(242701, 1, "a1bf375c183697499d648e6a4b10fbaf6f0913d6c54a0c99c44d9a4b45479bc1")
