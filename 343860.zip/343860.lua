-- Lua provided by SkyAPI 
-- Game: Tacoma
addappid(343860)
addappid(343861, 1, "695ce80ed38ba63dfb0c7a1778f6ce3137e33ea48511a80046ba99a38e65d92c")
addappid(343863, 1, "89494882033df309593c1aacfa762b82169a948cd2ad978bfe1330bf775f52ee")
addappid(343864, 1, "6aba3b1515b4dfc9e20468b44b7cb52ee91b0b654c261e07da875a6cdc07921e")
