-- Lua provided by RyzenAPI
-- Game: Funbag Fantasy: Sideboob Story

-- MAIN APPLICATION
addappid(1035030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035031, 1, "0134114223dfe558eca2cfd0e178c58630e1ebbd774b4ae34edda5a0d3a0d0e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
