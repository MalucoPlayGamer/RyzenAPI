-- Lua provided by RyzenAPI
-- Game: 32760

-- MAIN APPLICATION
addappid(32760)
-- Game: addappid(32760)

-- MAIN APP DEPOTS / PACKAGES
addappid(32761, 1, "7f0219c9ee8d955651d3d1d3c33730980cfabfc65cdb9d495a7fbdf8fbc98c82")
