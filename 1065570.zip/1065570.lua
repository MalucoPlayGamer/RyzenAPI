-- Lua provided by RyzenAPI
-- Game: addappid(1065570)

-- MAIN APPLICATION
addappid(1065570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065571, 1, "bbef690375302b251bc0dea85b1e2021840a20d97e9f37e53cf27bc29d856bbe")
