-- Lua provided by RyzenAPI
-- Game: Cyber Gun

-- MAIN APPLICATION
addappid(1065570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1065571, 1, "bbef690375302b251bc0dea85b1e2021840a20d97e9f37e53cf27bc29d856bbe")

