-- Lua provided by RyzenAPI
-- Game: busy streets

-- MAIN APPLICATION
addappid(3051080)
-- Game: addappid(3051080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051081, 1, "85c319ed7c130240380e3b434aaa790675d4e905e827e2a7b57e99b689bd0043")
