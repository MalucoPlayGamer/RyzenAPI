-- Lua provided by SkyAPI 
-- Game: R2BEAT（アールツービート）
addappid(2340400)
addappid(2340401, 1, "d7667a74cecab017b288ec8b1f8e2ee38045728af0806099836c0d842e2b2aa5")
