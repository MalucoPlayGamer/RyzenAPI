-- Lua provided by RyzenAPI
-- Game: R2BEAT（アールツービート）

-- MAIN APPLICATION
addappid(2340400)
-- Game: addappid(2340400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340401, 1, "d7667a74cecab017b288ec8b1f8e2ee38045728af0806099836c0d842e2b2aa5")
