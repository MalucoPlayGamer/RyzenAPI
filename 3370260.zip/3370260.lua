-- Lua provided by RyzenAPI
-- Game: White Room: Mind’s Prison

-- MAIN APPLICATION
addappid(3370260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3370261, 1, "7250bf9a0f2945dc3a34a87a901d7e3d79d8d385188a983a6bafaf76b66fe90a")

