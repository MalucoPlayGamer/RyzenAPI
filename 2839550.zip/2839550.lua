-- Lua provided by RyzenAPI
-- Game: Everything: All in 1

-- MAIN APPLICATION
addappid(2839550)
addappid(4592170)
addappid(4700380)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2839551, 1, "33a46b7fe95ee36b22a1d0be42324d36df99dc47acb1ea6fb5736252503d38e4")

