-- Lua provided by RyzenAPI
-- Game: BALAN WONDERWORLD

-- MAIN APPLICATION
addappid(1341050)
-- Game: addappid(1341050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341051, 1, "d232cbd1f3818d4d5822bba9cfc2cacf735d3bbfc0ec2fcd6430638c3782474a")
