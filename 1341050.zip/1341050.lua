-- Lua provided by RyzenAPI
-- Game: BALAN WONDERWORLD

-- MAIN APPLICATION
addappid(1341050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341051, 1, "d232cbd1f3818d4d5822bba9cfc2cacf735d3bbfc0ec2fcd6430638c3782474a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
