-- Lua provided by RyzenAPI
-- Game: 2503780

-- MAIN APPLICATION
addappid(2503780)
-- Game: addappid(2503780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503781, 1, "fb9e6087c9e7eaf0deb7fb93da10bad6b8427a3cb6ed9bcf5a28de8fba9f5bc8")
addappid(2503786, 1, "d72af15acfd6db1a8dc93c45242fe9528d26b7278bbd281b802d3edb465c5fdd")
addappid(2503787, 1, "36d019bcbe6925c95e85982b177d5e2264cbde2b49c20474dd46467c812c12e7")
addappid(2503788, 1, "ad998cfcf52cd65d4350bf17616ba6b1f550cc477b0ddccca671fa70e7e2c136")
