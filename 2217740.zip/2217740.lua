-- Lua provided by RyzenAPI
-- Game: Kitty Survivors: Rogues of Catmere

-- MAIN APPLICATION
addappid(2217740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217741, 1, "026772f8d6ee37677d75c3da9f5e7dbc11f4cff882a64674424d0c8c5ca87849")
