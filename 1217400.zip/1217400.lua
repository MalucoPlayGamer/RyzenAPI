-- Lua provided by RyzenAPI
-- Game: Sierra Ops : Episode 2 - Dissonance and Resonance

-- MAIN APPLICATION
addappid(1217400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217400,0,"3b6ca79a225685b8907fef52b1e5a7a6e33277d7a6ba458031841711ceda0572")

