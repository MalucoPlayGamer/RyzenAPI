-- Lua provided by RyzenAPI
-- Game: 孤独之旅 Lonely journey

-- MAIN APPLICATION
addappid(2867190)
addappid(2890670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867191, 1, "2ab4f97557f8136b16ee8387005ee3f6cf91f55067be21d0d5ba1bee3f2f1fc7")

