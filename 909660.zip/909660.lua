-- Lua provided by SkyAPI 
-- Game: Vagrus - The Riven Realms
addappid(909660)
addappid(909661, 1, "b78c9f863001a8a018cb92afa84b794a77c1c8bb300df1b381ae7a288f24700f")
addappid(1761710, 0, "afd666f882ea51fa1a5d59e334c5ae115a434ab24ee05886b17d76c3bdbb1176")
