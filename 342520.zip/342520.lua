-- Lua provided by SkyAPI 
-- Game: BoxesWithGuns
addappid(342520)
addappid(342521, 1, "4d26c0e86cbaa37428403679618fecd2eac1e127ee81f9fb57866c372482d646")
