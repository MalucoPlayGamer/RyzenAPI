-- Lua provided by RyzenAPI
-- Game: BoxesWithGuns

-- MAIN APPLICATION
addappid(342520)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(342521, 1, "4d26c0e86cbaa37428403679618fecd2eac1e127ee81f9fb57866c372482d646")

