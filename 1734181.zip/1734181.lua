-- Lua provided by RyzenAPI
-- Game: FUSER™ - Deep Purple - "Smoke On The Water"

-- MAIN APPLICATION
addappid(1734181)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734181,0,"6461de93aca00deb0c9394e9005b0ba39796d7d3a1300d577bd0fce9e0a610c3")

