-- Lua provided by RyzenAPI
-- Game: Game: Veranoia: Nightmare of Case 37

-- MAIN APPLICATION
addappid(2709220)
-- Game: addappid(2709220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709221, 1, "5105f168944278e70587595254d9054726c8662496f084435c1bd52893430c80")
