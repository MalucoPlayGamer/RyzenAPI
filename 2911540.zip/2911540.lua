-- Lua provided by RyzenAPI
-- Game: Hentai Tales: The Entrance To Isekai

-- MAIN APPLICATION
addappid(2911540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911541, 1, "d2445540694c7eaa84570a5586f93fd614111a45e325341b161101266561f4c3")

