-- Lua provided by RyzenAPI
-- Game: Game: Elf Discipline Ceremony

-- MAIN APPLICATION
addappid(2696060)
-- Game: addappid(2696060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696061, 1, "6e1eddf856af93e1784ccefb3e8308dae76877b722e3ef97f6b56b2a4e78e16d")
