-- Lua provided by RyzenAPI
-- Game: Game: Tower Escape

-- MAIN APPLICATION
addappid(2009860)
-- Game: addappid(2009860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009861, 1, "7e292e8cb3cf95b0558b69ff123c547cff17df81ac2dbcb9ee7da4a288da7829")
addappid(2009862, 1, "225ec065f98c4b83def041a68979e7121f9246171e2335389c20f247b5138452")
addappid(2009863, 1, "e1528958a4bf6410f181435ccf9140a33860f3648fd8c23b9a0ad2f972be9e9f")
