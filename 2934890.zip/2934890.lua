-- Lua provided by RyzenAPI
-- Game: The Last Visit: 98th

-- MAIN APPLICATION
addappid(2934890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934891, 1, "9bdf0feae053d611654e7552f5c078f406fadfaaf6c3f8c767f0a41647e7944e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
