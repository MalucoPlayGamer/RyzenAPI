-- Lua provided by RyzenAPI
-- Game: 2934890

-- MAIN APPLICATION
addappid(2934890)
-- Game: addappid(2934890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934891, 1, "9bdf0feae053d611654e7552f5c078f406fadfaaf6c3f8c767f0a41647e7944e")
