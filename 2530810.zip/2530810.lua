-- Lua provided by RyzenAPI
-- Game: Game: Ghost In The Mirror

-- MAIN APPLICATION
addappid(2530810)
-- Game: addappid(2530810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530811, 1, "9850c293f65ee0708202f8f68ac0e0b568b4c40097b390eb7584aa5caeb4a542")
