-- Lua provided by RyzenAPI
-- Game: addappid(3086700)

-- MAIN APPLICATION
addappid(3086700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086701, 1, "e58806a350f2d6f30ce5ba070989b0e24b5dc05821f085aec2a02c386c8d0d18")
