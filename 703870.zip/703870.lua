-- Lua provided by RyzenAPI 
-- Game: AppID 703870
addappid(703870)
addappid(703871, 1, "d201c4cdddd2cf315b5e455c0d817a047cbd77d34a6047fff9a2bc679fd35460")
