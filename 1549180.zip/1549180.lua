-- Lua provided by RyzenAPI 
-- Game: Propnight
addappid(1549180)
addappid(1549181, 1, "8f9b5f4b72f4772d919240c93c87f9ef2b242ce4d4e01367469d44566a4e8e60")
addappid(2196290, 0, "6d80cb80f6e1c7519d06043e29ab686b48ac4f2417b14c00fabdf320c5b15a83")
