-- Lua provided by RyzenAPI
-- Game: Propnight

-- MAIN APPLICATION
addappid(1549180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1549181, 1, "8f9b5f4b72f4772d919240c93c87f9ef2b242ce4d4e01367469d44566a4e8e60")
addappid(2196290, 0, "6d80cb80f6e1c7519d06043e29ab686b48ac4f2417b14c00fabdf320c5b15a83")

