-- Lua provided by RyzenAPI
-- Game: Game: Insert Paper

-- MAIN APPLICATION
addappid(661490)
-- Game: addappid(661490)

-- MAIN APP DEPOTS / PACKAGES
addappid(661491, 1, "43327799164cb967d3603047be2f4d465bcb97be533e9482b23dae257293c17b")
