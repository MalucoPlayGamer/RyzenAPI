-- Lua provided by RyzenAPI
-- Game: Uniform Girl

-- MAIN APPLICATION
addappid(1265240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265241, 1, "a6c021e44d08e5dee447bcc0aaa3aad4d1fef22feb02a7ff10c10fa49dd84c64")
addappid(1268010, 0, "6ff7642b0bfe0406724becce7aa385709e503180527b7b00a564b442a2d3470a")

