-- Lua provided by RyzenAPI
-- Game: HeroOfMetal-Episode01

-- MAIN APPLICATION
addappid(1083270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083271, 1, "aa4e627493bdad21f1b4355d2cb38dc20238bb66b735d99b9d9031259e78509b")

