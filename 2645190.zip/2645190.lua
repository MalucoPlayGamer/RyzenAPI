-- Lua provided by RyzenAPI
-- Game: Game: Agnostic Requiem

-- MAIN APPLICATION
addappid(2645190)
-- Game: addappid(2645190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645191, 1, "62cb0906743824c136a22186aee3e45096e020f3f0b399106445588833c3fd87")
