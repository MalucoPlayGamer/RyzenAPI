-- Lua provided by RyzenAPI
-- Game: 1519900

-- MAIN APPLICATION
addappid(1519900)
-- Game: addappid(1519900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519901, 1, "c670271ea3153aefca599ff7149e9d6746a875f55220cea232290b7d2cc656d1")
