-- Lua provided by RyzenAPI
-- Game: MASAGORO

-- MAIN APPLICATION
addappid(1519900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1519901, 1, "c670271ea3153aefca599ff7149e9d6746a875f55220cea232290b7d2cc656d1")

