-- Lua provided by RyzenAPI
-- Game: Ten Trials of Babel: The Doppelganger Maze

-- MAIN APPLICATION
addappid(1900340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900341, 1, "6adb9d04ad8d9d76219a77c3893eb2907e3fb1955a55904ad80fa536205a3b03")
addappid(1900342, 1, "db10bfd61b5a47363ad10349849fbcc85203b281d601458a2a4ed2c6a1a507b9")
addappid(1900343, 1, "87c769ed3f11b5798e6baa8a6bcab565addd697fe1271f79be8aafea1abde592")
addappid(1900344, 1, "5c80485a38d081b21850206fdc5839eeb7cb7a9aeb7b2bb1856b3dc7a20ef9eb")
addappid(1900345, 1, "15f0f929c95d62e79075a6551062983c2fcb4130fc3729c5876aec6579b983b4")
