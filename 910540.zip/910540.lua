-- Lua provided by RyzenAPI
-- Game: addappid(910540)

-- MAIN APPLICATION
addappid(910540)

-- MAIN APP DEPOTS / PACKAGES
addappid(910542,0,"2f513df0370989e6f56ccccf28276464767383a3fb434d1a9f124df2477c30fb")
