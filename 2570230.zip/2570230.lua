-- Lua provided by RyzenAPI
-- Game: HAELE 3D - Hand Poses Lite - Drawing References

-- MAIN APPLICATION
addappid(2570230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2570231, 1, "d784d4f87477a90d8372b64117628f159d7eca7eabf37123788f278e08ac19be")

