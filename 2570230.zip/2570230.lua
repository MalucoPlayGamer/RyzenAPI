-- Lua provided by RyzenAPI
-- Game: HAELE 3D - Hand Poses Lite - Drawing References

-- MAIN APPLICATION
addappid(2570230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570231, 1, "d784d4f87477a90d8372b64117628f159d7eca7eabf37123788f278e08ac19be")

