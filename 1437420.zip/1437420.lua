-- Lua provided by RyzenAPI
-- Game: Two Parsecs From Earth

-- MAIN APPLICATION
addappid(1437420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437421, 1, "809ed8ed989e9fc7b56d20788ef6907e801ffadf1dc334ef355c1f0626734c8b")

