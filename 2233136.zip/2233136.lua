-- Lua provided by RyzenAPI
-- Game: Beat Saber - Guns N' Roses - "Sweet Child O' Mine"

-- MAIN APPLICATION
addappid(2233136)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233136,0,"43f6659cd0833c37e12c9c72757f8236476502dd6a16a3c9fe1dad9d16e34b16")

