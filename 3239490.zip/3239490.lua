-- Lua provided by RyzenAPI
-- Game: Dorpie Demo

-- MAIN APPLICATION
addappid(3239490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239491, 1, "d8b393674ddd036aafaaeb989ec1c57c3813189d65b2334971a66e596b4dc3e7")

