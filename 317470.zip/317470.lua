-- Lua provided by RyzenAPI
-- Game: Game: AppID 317470

-- MAIN APPLICATION
addappid(317470)
-- Game: addappid(317470)

-- MAIN APP DEPOTS / PACKAGES
addappid(317471, 1, "23f4d249e22a6f86ea334389d0e6479f4f645e5d77c78e97c5c860cb2a3d16fe")
