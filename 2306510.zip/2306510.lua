-- Lua provided by RyzenAPI
-- Game: addappid(2306510)

-- MAIN APPLICATION
addappid(2306510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306511, 1, "625aafa1d2c645bd1a1efa573e60872cedb189db2296a9b8eb8590ba8fd978b4")
