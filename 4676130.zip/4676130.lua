-- Lua provided by RyzenAPI
-- Game: That Time I Got Reincarnated as a Tyrant God

-- MAIN APP DEPOTS / PACKAGES
addappid(4676130, 1, "97a87f7b4692365b938d23ce58448d58cd9c0030bd3321a5deebd7747d776f89") -- That Time I Got Reincarnated as a Tyrant God
addappid(4676131, 1, "f8c5d5564d0343b9ed39f70562d4a62a53ba6fb6882929975d1cd9431c3727b0") -- Depot 4676131
addappid(4676132, 1, "58c5b9500965f2da9fd23e449dda7325e45bbf205faf4cca42480dde0b91018d") -- Depot 4676132
addappid(4676133, 1, "6be56a386ee830eeffde578b888fb865c7633c72ca914bb3b72d9f2628bcfc55") -- Depot 4676133

