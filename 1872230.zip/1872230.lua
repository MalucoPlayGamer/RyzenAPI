-- Lua provided by RyzenAPI
-- Game: 1872230

-- MAIN APPLICATION
addappid(1872230)
-- Game: addappid(1872230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872231, 1, "7b59e5f4e4cc4a9353489f754b372f98afed3c12866cffe54ab2ca920f3f8df2")
