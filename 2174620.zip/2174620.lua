-- Lua provided by RyzenAPI
-- Game: Agelast

-- MAIN APPLICATION
addappid(2174620)
-- Game: addappid(2174620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174621, 1, "38a94075146ae128e18b231e697332c2d6dc341599bdfe5176a12af42b9ae485")
