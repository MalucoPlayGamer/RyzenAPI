-- Lua provided by RyzenAPI
-- Game: Valkie 64

-- MAIN APPLICATION
addappid(2190590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2190591, 1, "3c8443701424ff29ae845fa509ecc037fd85fac3014bc9a7d6d165e53f2b9eb8")

