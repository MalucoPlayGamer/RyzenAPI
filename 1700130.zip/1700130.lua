-- Lua provided by RyzenAPI
-- Game: Baking Bustle: Ashley’s Dream

-- MAIN APPLICATION
addappid(1700130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700131, 1, "a005a8ded36ebb55a50f32f8fd5dd0cd2642821f4a0e7f0f325060cdb17654aa")
