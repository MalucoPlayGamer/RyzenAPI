-- Lua provided by RyzenAPI
-- Game: Oylinder

-- MAIN APPLICATION
addappid(2167880)
-- Game: addappid(2167880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167881, 1, "79173e8ab18b3c8865371c9614540e232852d08117a8b1ef0825c521649ee87f")
