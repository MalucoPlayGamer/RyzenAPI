-- Lua provided by RyzenAPI
-- Game: 603560

-- MAIN APPLICATION
addappid(603560)
-- Game: addappid(603560)

-- MAIN APP DEPOTS / PACKAGES
addappid(603561, 1, "870a25e186666ba437aef4ba83f99f9c12e6d44fd870eee6922fecceddeb9425")
