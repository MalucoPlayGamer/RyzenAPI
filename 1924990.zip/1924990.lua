-- Lua provided by RyzenAPI
-- Game: HOBGOB ～Please Save Me～

-- MAIN APPLICATION
addappid(1924990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924991, 1, "7be392b43658bcf98310a1c2c78e442f85e345bc832f551213997a4914fe2179")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
