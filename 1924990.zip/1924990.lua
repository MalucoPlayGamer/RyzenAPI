-- Lua provided by RyzenAPI
-- Game: HOBGOB ～Please Save Me～

-- MAIN APPLICATION
addappid(1924990)
-- Game: addappid(1924990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924991, 1, "7be392b43658bcf98310a1c2c78e442f85e345bc832f551213997a4914fe2179")
