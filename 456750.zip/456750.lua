-- Lua provided by RyzenAPI
-- Game: Game: AppID 456750

-- MAIN APPLICATION
addappid(456750)
-- Game: addappid(456750)

-- MAIN APP DEPOTS / PACKAGES
addappid(456751, 1, "3a987aa1ca2a1b6c823c7b0d895d43624334eaf5f6a13e0142aed70f435c0a6a")
