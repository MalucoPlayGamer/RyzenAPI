-- Lua provided by RyzenAPI
-- Game: AppID 456750

-- MAIN APPLICATION
addappid(456750)

-- MAIN APP DEPOTS / PACKAGES
addappid(456751, 1, "3a987aa1ca2a1b6c823c7b0d895d43624334eaf5f6a13e0142aed70f435c0a6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
