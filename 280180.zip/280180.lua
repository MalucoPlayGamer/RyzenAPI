-- Lua provided by RyzenAPI
-- Game: Game: AppID 280180

-- MAIN APPLICATION
addappid(280180)
-- Game: addappid(280180)

-- MAIN APP DEPOTS / PACKAGES
addappid(280181, 1, "4919552860402c6f0eef11145c45e9251c784ec35b0b62d8cf3d4871368181d4")
