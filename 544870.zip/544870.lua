-- Lua provided by RyzenAPI
-- Game: addappid(544870)

-- MAIN APPLICATION
addappid(544870)

-- MAIN APP DEPOTS / PACKAGES
addappid(544871, 1, "cd55f59ddf1cfc8800784099258b5a2c0e23b96bce7f38189e908c34b1c80794")
