-- Lua provided by RyzenAPI 
-- Game: Blood Ties
addappid(544870)
addappid(544871, 1, "cd55f59ddf1cfc8800784099258b5a2c0e23b96bce7f38189e908c34b1c80794")
