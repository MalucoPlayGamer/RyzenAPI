-- Lua provided by RyzenAPI
-- Game: addappid(1240930)

-- MAIN APPLICATION
addappid(1240930)
addappid(1240937)
addappid(1240938)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240936,0,"4345f26748e9dbf34d76911db8bf9f2a4b381d717f796724142e9c8ad69376b2")
