-- Lua provided by RyzenAPI
-- Game: addappid(1759480)

-- MAIN APPLICATION
addappid(1759480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759481, 1, "c0d88002c2b567d3baf4e5b0e05a5927f8c893327d4dc308041e5b6855a4edaf")
