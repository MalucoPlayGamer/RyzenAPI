-- Lua provided by RyzenAPI
-- Game: 674190

-- MAIN APPLICATION
addappid(674190)
-- Game: addappid(674190)

-- MAIN APP DEPOTS / PACKAGES
addappid(674192,0,"cbcf758e4a2396ceddfd7b1cee707c95be0d0937d547e4b92b1bac8cd64e3351")
