-- Lua provided by SkyAPI 
-- Game: Hyper Hentai Devil Hell
addappid(2390580)
addappid(2390581, 1, "632387e000ce23a216ae2e47e6a3e8edf32ddc829bef061668b7f7b0f5cd7e73")
