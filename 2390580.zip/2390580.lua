-- Lua provided by RyzenAPI
-- Game: addappid(2390580)

-- MAIN APPLICATION
addappid(2390580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390581, 1, "632387e000ce23a216ae2e47e6a3e8edf32ddc829bef061668b7f7b0f5cd7e73")
