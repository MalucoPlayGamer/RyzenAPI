-- Lua provided by RyzenAPI
-- Game: DFF NT: Laevateinn, Shantotto's 4th Weapon

-- MAIN APPLICATION
addappid(1022428)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022428,0,"07433bda7eb414c814ae3df8de68e9a5d6edc6f3d78888252250198e4c299111")

