-- Lua provided by RyzenAPI
-- Game: addappid(1929970)

-- MAIN APPLICATION
addappid(1929970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929970,0,"520663c7457b3e010a7e1ed010156ace5335402df51c1aac7094bee08ff7d856")
