-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Nina is streaming

-- MAIN APPLICATION
addappid(3574850)
-- Game: addappid(3574850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3574851, 1, "b9da4b94bae2c8a80bf03952075940cab48a83f4057a9c373eaf53747c2623e3")
