-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Nina is streaming

-- Main AppID
addappid(3574850) -- Hentai Clicker: Nina is streaming

-- Main Depots
addappid(3574851, 1, "b9da4b94bae2c8a80bf03952075940cab48a83f4057a9c373eaf53747c2623e3") -- (windows)
-- setManifestid(3574851, "42436981655462868", 163066061)

-- Missing Depots (We don't have the keys yet lol): 3574852, 3574853
