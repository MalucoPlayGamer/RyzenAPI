-- Lua provided by RyzenAPI
-- Game: Beat Saber - Lizzo - "2 Be Loved (Am I Ready)"

-- MAIN APPLICATION
addappid(2122140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122140,0,"108a5755cbb1c1eb0597a7d76c25554eaa8547177742fb5b0375da4744579ef0")
