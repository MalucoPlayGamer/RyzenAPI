-- Lua provided by RyzenAPI
-- Game: CustomBullet

-- MAIN APPLICATION
addappid(2087960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2087961, 1, "ca71630c6702d9e4a3af32c8d927299c62f37710904cd2a15d989679501275e5")

