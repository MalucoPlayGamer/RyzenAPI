-- Lua provided by SkyAPI 
-- Game: CustomBullet
addappid(2087960)
addappid(2087961, 1, "ca71630c6702d9e4a3af32c8d927299c62f37710904cd2a15d989679501275e5")
