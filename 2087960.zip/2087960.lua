-- Lua provided by RyzenAPI
-- Game: CustomBullet

-- MAIN APPLICATION
addappid(2087960)
-- Game: addappid(2087960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087961, 1, "ca71630c6702d9e4a3af32c8d927299c62f37710904cd2a15d989679501275e5")
