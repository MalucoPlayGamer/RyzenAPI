-- Lua provided by SkyAPI 
-- Game: Countryballs Conquest
addappid(3318550)
addappid(3318551, 1, "87ff4a1edfe9b72be496952ce8c5bb25bc46ab0d12a10ac21d79432e940e374f")
