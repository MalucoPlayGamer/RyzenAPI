-- Lua provided by RyzenAPI
-- Game: Countryballs Conquest

-- MAIN APPLICATION
addappid(3318550)
-- Game: addappid(3318550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318551, 1, "87ff4a1edfe9b72be496952ce8c5bb25bc46ab0d12a10ac21d79432e940e374f")
