-- Lua provided by RyzenAPI
-- Game: addappid(783770)

-- MAIN APPLICATION
addappid(783770)

-- MAIN APP DEPOTS / PACKAGES
addappid(783771, 1, "eab6d5c6a89d83a1d96df1b18a1530aafb7f97ec49eddf75c3ae546d638e1583")
