-- Lua provided by RyzenAPI
-- Game: Ironsight

-- MAIN APPLICATION
addappid(783770)
addappid(1195300)
addappid(1195301)
addappid(1230130)
addappid(1230131)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(783771, 1, "eab6d5c6a89d83a1d96df1b18a1530aafb7f97ec49eddf75c3ae546d638e1583")

