-- Lua provided by RyzenAPI
-- Game: setManifestid(823942,"3025449957547568660")

-- MAIN APPLICATION
addappid(823940)
-- Game: addappid(823940)

-- MAIN APP DEPOTS / PACKAGES
addappid(823942,0,"904d8e95044d4f7917995acde5b23b301fc168cd7bc90b92d892c140619aa589")
