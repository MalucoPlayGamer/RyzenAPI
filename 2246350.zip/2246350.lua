-- Lua provided by RyzenAPI
-- Game: 2246350

-- MAIN APPLICATION
addappid(2246350)
-- Game: addappid(2246350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246351, 1, "56171c150cba9c9d5ba209a02040d822948c721c9ce8dfe67900ead1eab05b61")
