-- Lua provided by RyzenAPI
-- Game: Kinda Heroes: The cutest RPG ever!

-- MAIN APPLICATION
addappid(1307780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307781, 1, "b5ba175875098411ed70ffd0d55c84efbb383e36aa388dce2bf3429d65af6b9b")
