-- Lua provided by RyzenAPI
-- Game: Joint Operations: Combined Arms Gold

-- MAIN APPLICATION
addappid(32770)

-- MAIN APP DEPOTS / PACKAGES
addappid(32771, 1, "0b29186655efcb2c4bc6892361e468720f0487505714a82f70c264bde1b68768")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
