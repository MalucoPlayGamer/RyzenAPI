-- Lua provided by RyzenAPI
-- Game: Joint Operations: Combined Arms Gold

-- MAIN APPLICATION
addappid(32770)

-- MAIN APP DEPOTS / PACKAGES
addappid(32771, 1, "0b29186655efcb2c4bc6892361e468720f0487505714a82f70c264bde1b68768")
