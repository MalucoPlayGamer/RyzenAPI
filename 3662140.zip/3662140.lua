-- Lua provided by RyzenAPI
-- Game: The Firestorm is Coming

-- MAIN APPLICATION
addappid(3662140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3662141, 1, "580a91536b359b40f6f01c51c50bf8f3d2b5ea730bfc982be4c48f3b243eb210")

