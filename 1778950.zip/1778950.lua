-- Lua provided by RyzenAPI
-- Game: Stalker in black

-- MAIN APPLICATION
addappid(1778950)
-- Game: addappid(1778950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778951, 1, "a3dfa43b80a1d8ae71961c30b27b6473c63a1c6e7004c981ce0f3c069177da6c")
