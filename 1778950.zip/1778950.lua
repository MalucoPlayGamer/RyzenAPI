-- Lua provided by RyzenAPI
-- Game: Stalker in black

-- MAIN APPLICATION
addappid(1778950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1778951, 1, "a3dfa43b80a1d8ae71961c30b27b6473c63a1c6e7004c981ce0f3c069177da6c")

