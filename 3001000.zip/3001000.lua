-- Lua provided by RyzenAPI
-- Game: Last Stand: Defense

-- MAIN APPLICATION
addappid(3001000)
-- Game: addappid(3001000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001008,0,"3ea33b6d8aac6f84209c492808f2e8152744520cfd5911fbed6ab6c985311562")
