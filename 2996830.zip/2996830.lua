-- Lua provided by RyzenAPI
-- Game: Game: Nobody Wants to Die Soundtrack

-- MAIN APPLICATION
addappid(2996830)
-- Game: addappid(2996830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996831, 1, "94a10689e1f5fdb739c5757b587f91ef70d1f1cf0e0ed9ec8c9fe310b0cb9613")
