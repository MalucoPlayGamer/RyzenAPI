-- Lua provided by RyzenAPI
-- Game: Virtua Unlimited Project

-- MAIN APPLICATION
addappid(1934030)
-- Game: addappid(1934030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934031, 1, "e3923b3395468af6e17ac5109f9631b2749fc7ac9d4595c758c63dcc89d11e19")
addappid(2916920, 0, "e9dab7693fbb5aa187967084fee47d6e484e73596482edb09a4ee3f20b663372")
addappid(3313620, 0, "6e2627898d7cdfbc2ca0d952fa6283cc15a7f4514679f39623836ef25b777018")
