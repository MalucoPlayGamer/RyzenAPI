-- Lua provided by RyzenAPI
-- Game: AppID 744280

-- MAIN APPLICATION
addappid(744280)
-- Game: addappid(744280)

-- MAIN APP DEPOTS / PACKAGES
addappid(744281, 1, "78af644e483981942062c8f28d4f7f382b56f7855b7061de0f5938cc73a6b49c")
