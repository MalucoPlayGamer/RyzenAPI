-- Lua provided by RyzenAPI
-- Game: Day Island

-- MAIN APPLICATION
addappid(1361150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361151, 1, "08a9269b76f6775b68cabd329b369257b4f276493a7d62ad7ba211938cb09fff")
