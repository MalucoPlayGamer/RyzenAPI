-- Lua provided by RyzenAPI
-- Game: The Overlord Isn't Another Isekai Protagonist, Is He?

-- MAIN APPLICATION
addappid(1945540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945541, 1, "7f6b44a0afaad5deac163d51f4302032bb2fe563d65fb484c99a234c625c0365")

