-- Lua provided by RyzenAPI
-- Game: Shawarma Legend

-- MAIN APPLICATION
addappid(3036080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036081, 1, "43c6cbc48dd25cd831e560ab88eaec5ec6ea5759d28d66933d6ae1a4badb30db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
