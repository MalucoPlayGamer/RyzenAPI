-- Lua provided by RyzenAPI
-- Game: Shawarma Legend

-- MAIN APPLICATION
addappid(3036080)
-- Game: addappid(3036080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036081, 1, "43c6cbc48dd25cd831e560ab88eaec5ec6ea5759d28d66933d6ae1a4badb30db")
