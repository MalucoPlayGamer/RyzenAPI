-- Lua provided by RyzenAPI
-- Game: Sword of the Necromancer: Resurrection

-- MAIN APPLICATION
addappid(2782880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2782881, 1, "39c02db18b94bbade1d2cd650ab83bdf7626604a456bc8211c73645ae0cb6ea9")

