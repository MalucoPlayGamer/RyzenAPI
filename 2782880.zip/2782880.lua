-- Lua provided by RyzenAPI 
-- Game: Sword of the Necromancer: Resurrection
addappid(2782880)
addappid(2782881, 1, "39c02db18b94bbade1d2cd650ab83bdf7626604a456bc8211c73645ae0cb6ea9")
