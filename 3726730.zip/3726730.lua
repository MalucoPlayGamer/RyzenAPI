-- Lua provided by RyzenAPI
-- Game: Dreamcards

-- MAIN APPLICATION
addappid(3726730) -- Dreamcards

-- MAIN APP DEPOTS / PACKAGES
addappid(3726731, 1, "f80577dbebff25956bcb4dfd6d0fdf709995aa5e106f8814b30224bce1f5a2ec") -- Depot 3726731
addappid(3726732, 1, "c1c496d5157d98332cdde325297a2c34bf5acdc82bb263eec41ee7851a36fcc5") -- Depot 3726732

