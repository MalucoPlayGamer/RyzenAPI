-- Lua provided by SkyAPI 
-- Game: Quadrober Simulator
addappid(3268080)
addappid(3268081, 1, "cf55db5cf877301c8a031d0e315e3c13b7e0e4e9715d21b5fff936a24f6a0279")
