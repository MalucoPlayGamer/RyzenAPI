-- Lua provided by RyzenAPI
-- Game: Strong Bad's Cool Game for Attractive People: Episode 3

-- MAIN APPLICATION
addappid(8360)

-- MAIN APP DEPOTS / PACKAGES
addappid(8361, 1, "fbc4a4a9dfe54a2b25080a4133338d71a5101b6260dfc173180b7acf49125353")
addappid(8362, 1, "37e53dd420fe0370275e41bf83d6a3789a51ef3a4223c6e690651396d79d7932")
