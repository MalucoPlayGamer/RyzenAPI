-- Lua provided by RyzenAPI
-- Game: addappid(1832470)

-- MAIN APPLICATION
addappid(1832470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832471, 1, "21c22a640770f2de7152dddfd7a1fb842b39b9d62aa3ade9c3d0bcd95384ecdc")
