-- 4829710's Lua and Manifest Created by Hubcap Manifest
-- Castleborne Survivors
-- Created: July 20, 2026 at 12:43:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4829710) -- Castleborne Survivors
-- MAIN APP DEPOTS
addappid(4829711, 1, "9d77cf2ee36f96fa6d20293edf7de7699e822f734049c4706466f20087a6844a") -- Depot 4829711
setManifestid(4829711, "3231039435607738429", 147749480)
addappid(4829712, 1, "ddd3f974030db0f07451a10b51ca28da475357df9eb66bfcdf4af5616aff8785") -- Depot 4829712
setManifestid(4829712, "3733084518048081568", 231338725)