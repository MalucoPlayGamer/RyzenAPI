-- Lua provided by SkyAPI 
-- Game: AppID 475630
addappid(475630)
addappid(475631, 1, "c441dfb97fcf7c8d5b15007fd19b0256ff53f00f941122cda09cac1908161b64")
