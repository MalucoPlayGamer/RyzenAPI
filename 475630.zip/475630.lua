-- Lua provided by RyzenAPI
-- Game: Crush Online

-- MAIN APPLICATION
addappid(475630)

-- MAIN APP DEPOTS / PACKAGES
addappid(475631, 1, "c441dfb97fcf7c8d5b15007fd19b0256ff53f00f941122cda09cac1908161b64")

