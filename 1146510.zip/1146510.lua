-- Lua provided by RyzenAPI
-- Game: 1146510

-- MAIN APPLICATION
addappid(1146510)
-- Game: addappid(1146510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146511, 1, "38aba1bad55e768163291bf2dfd6be4d032f2f8c5eac7d5e86ec56b2b61fbc47")
