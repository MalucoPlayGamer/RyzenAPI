-- Lua provided by RyzenAPI
-- Game: Eyes: The Horror Game

-- MAIN APPLICATION
addappid(2633640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633641, 1, "354896175274e7b6283e32965671d842b6ebd9fa2e8fb78d15c7b833e7d21ebc")
