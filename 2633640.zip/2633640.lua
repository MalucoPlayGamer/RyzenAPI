-- Lua provided by SkyAPI 
-- Game: Eyes: The Horror Game
addappid(2633640)
addappid(2633641, 1, "354896175274e7b6283e32965671d842b6ebd9fa2e8fb78d15c7b833e7d21ebc")
