-- Lua provided by RyzenAPI
-- Game: 956030

-- MAIN APPLICATION
addappid(956030)
-- Game: addappid(956030)

-- MAIN APP DEPOTS / PACKAGES
addappid(956031, 1, "75884c27d6c016d8447cccfc4a991978700636057c81b3c60e040069cfebef06")
addappid(956032, 1, "49b723404e8ac804dd7708e523f7ad9cb0d2d0afb10db1b981f86bce1d042f78")
