-- Lua provided by RyzenAPI
-- Game: addappid(272510)

-- MAIN APPLICATION
addappid(272510)
addappid(301890)
addappid(301891)
addappid(301892)
addappid(301893)
addappid(301894)
addappid(301895)
addappid(301896)
addappid(301897)
addappid(316060)
addappid(318710)

-- MAIN APP DEPOTS / PACKAGES
addappid(272511, 1, "932caa02917545e704d495fd2f676f374ffe636bc90d9107abed070afe4a91f7")
