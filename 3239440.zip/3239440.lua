-- Lua provided by RyzenAPI
-- Game: Spirit Valley Demo

-- MAIN APPLICATION
addappid(3239440)
-- Game: addappid(3239440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239441, 1, "e425b25197296ec94ce8345a9ba14bb6aec7c937bafdce9eebe64666deaa76c9")
