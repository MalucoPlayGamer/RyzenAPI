-- Lua provided by RyzenAPI
-- Game: Icycle: On Thin Ice

-- MAIN APPLICATION
addappid(658990)

-- MAIN APP DEPOTS / PACKAGES
addappid(658991, 1, "7c5e6cc545f9dd990df0f7a69f5bb41626a34e39c3a9c9dc995ea0a44b04e722")
