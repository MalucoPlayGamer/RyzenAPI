-- Lua provided by RyzenAPI
-- Game: I'mitation The Eight Suicide Note

-- MAIN APPLICATION
addappid(1277970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1277971, 1, "1230129d89ad38b0f1540be71dfe646a3fe266a43c40cae8ba7b356df3c567a0")
