-- Lua provided by RyzenAPI
-- Game: AppID 1277970

-- MAIN APPLICATION
addappid(1277970)
-- Game: addappid(1277970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277971, 1, "1230129d89ad38b0f1540be71dfe646a3fe266a43c40cae8ba7b356df3c567a0")
