-- Lua provided by RyzenAPI
-- Game: Reviver Demo

-- MAIN APPLICATION
addappid(2249390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249391, 1, "c0ebd02f5b3f3b3bceb19e364ef0571580c8eee5881edad5cfa7af0dab8af91b")

