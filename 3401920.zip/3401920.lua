-- Lua provided by RyzenAPI
-- Game: Upin & Ipin Universe

-- MAIN APPLICATION
addappid(3401920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3401921, 1, "1ed51cfdf48a0b8fd26e081ce4b7c70a17e0a028d99b3a0100ad2dd8f840e9f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
