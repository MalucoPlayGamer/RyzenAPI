-- Lua provided by RyzenAPI
-- Game: addappid(3401920)

-- MAIN APPLICATION
addappid(3401920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3401921, 1, "1ed51cfdf48a0b8fd26e081ce4b7c70a17e0a028d99b3a0100ad2dd8f840e9f6")
