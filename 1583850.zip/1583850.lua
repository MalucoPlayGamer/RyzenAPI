-- Lua provided by RyzenAPI
-- Game: Asleep: Act 1

-- MAIN APPLICATION
addappid(1583850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583852,0,"c3d2f13f2463f0ef3889b720b716ab78839f096f9caaf35bd36eac0562f88c3f")
addappid(1583856,0,"59baf9e0611e162dc8928d5280982627850e32c84289b7cd252ca2ea3427371b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3368680)
