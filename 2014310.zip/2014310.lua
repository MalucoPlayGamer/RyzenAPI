-- Lua provided by RyzenAPI
-- Game: Game: AppID 2014310

-- MAIN APPLICATION
addappid(2014310)
-- Game: addappid(2014310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014311, 1, "cad0a65002415ec44203d4075704251e60a562c4114631acc6c02f2f7608e0ec")
