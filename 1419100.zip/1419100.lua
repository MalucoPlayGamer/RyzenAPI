-- Lua provided by RyzenAPI
-- Game: The Unexpected Quest Prologue

-- MAIN APPLICATION
addappid(1419100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1419101, 1, "527d9a4ad2dff6b9e0ab957234e7a3727612229475795a0c1742c791d9fe3be5")

