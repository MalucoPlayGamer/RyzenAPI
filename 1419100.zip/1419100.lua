-- Lua provided by RyzenAPI
-- Game: The Unexpected Quest Prologue

-- MAIN APPLICATION
addappid(1419100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419101, 1, "527d9a4ad2dff6b9e0ab957234e7a3727612229475795a0c1742c791d9fe3be5")
