-- Lua provided by RyzenAPI
-- Game: Rise of the Triad: Ludicrous Edition

-- MAIN APPLICATION
addappid(1421490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1421491, 1, "4c96fc77e80893f97175c55d238caa7a765baccf22cfacce856d510565a99a8c")
addappid(1421492, 1, "23e0a537b2489a3466936cfdfdd60bd99d40ab67b8e259b9986c164b94d7ba45")

