-- Lua provided by RyzenAPI
-- Game: Tiny Dino

-- MAIN APPLICATION
addappid(3678750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3678751, 1, "1d89380dc35b3163ecfea1eb84b56c8872a97d796dd13c48b6afe7122889e589")

