-- Lua provided by SkyAPI 
-- Game: Tiny Dino
addappid(3678750)
addappid(3678751, 1, "1d89380dc35b3163ecfea1eb84b56c8872a97d796dd13c48b6afe7122889e589")
