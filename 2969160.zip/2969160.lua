-- Lua provided by RyzenAPI
-- Game: 2969160

-- MAIN APPLICATION
addappid(2969160)
-- Game: addappid(2969160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969161, 1, "8a72f527e85e3515970130c2b7cfd62faecc546adb25d2f2abdb5ce1c129dddd")
