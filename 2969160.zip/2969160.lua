-- Lua provided by RyzenAPI
-- Game: AppID 2969160

-- MAIN APPLICATION
addappid(2969160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2969161, 1, "8a72f527e85e3515970130c2b7cfd62faecc546adb25d2f2abdb5ce1c129dddd")

