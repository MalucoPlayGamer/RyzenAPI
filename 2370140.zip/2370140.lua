-- Lua provided by RyzenAPI
-- Game: addappid(2370140)

-- MAIN APPLICATION
addappid(2370140)
addappid(3029930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370141, 1, "3e08c3e137d2bc8ede251c314d20b62e07b0185ddb75a98655791633bcf3513c")
