-- Lua provided by RyzenAPI
-- Game: 1495320

-- MAIN APPLICATION
addappid(1495320)
-- Game: addappid(1495320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495321, 1, "ca5070e2afd6a9665bbb4aaf33a228a623ac43c0c7b7a001a618a7cfcb2f6b53")
