-- Lua provided by RyzenAPI
-- Game: Eternal Step

-- MAIN APPLICATION
addappid(374240)

-- MAIN APP DEPOTS / PACKAGES
addappid(374241, 1, "d0f02bdd9e22444b140b80dc80ddd03a676517ad9693ff6bdafd8e28c1ccabec")
addappid(374244, 1, "107488d58119e0b9a21398652d6e6c639a9f70748e8cca0b8fbd7b2e5a146d2e")
addappid(374245, 1, "486bcc3c2b3f456a18f3ef94de96259f97a14cc93b10fe7452118c32e1bc0605")
addappid(374246, 1, "ce0dda51ae31cf9246d742463870bef8f11fd5f01b4a0a185786d232943e767d")
