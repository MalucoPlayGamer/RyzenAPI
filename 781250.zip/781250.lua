-- Lua provided by RyzenAPI 
-- Game: Eternam
addappid(781250)
addappid(781251, 1, "28ea2a565094a6a1e6285631a68485874f4c2b52848ed49a5c26abc03be7d09c")
