-- Lua provided by RyzenAPI
-- Game: addappid(2148940)

-- MAIN APPLICATION
addappid(2148940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148941, 1, "1531c29a8cbf475745e2d9425ce28181cf2d96eaadb3897069634c1c6c9c3679")
