-- Lua provided by SkyAPI 
-- Game: Japanese Cultural Property VR Museum
addappid(2139520)
addappid(2139521, 1, "213ef653c041cdb1c705fe535a1f441ed02ce8987eeb8d8ec8f22d9b76a02f72")
