-- Lua provided by RyzenAPI
-- Game: 2139520

-- MAIN APPLICATION
addappid(2139520)
-- Game: addappid(2139520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139521, 1, "213ef653c041cdb1c705fe535a1f441ed02ce8987eeb8d8ec8f22d9b76a02f72")
