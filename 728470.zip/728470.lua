-- Lua provided by RyzenAPI
-- Game: ASTRONEER Dedicated Server

-- MAIN APPLICATION
addappid(728470)

-- MAIN APP DEPOTS / PACKAGES
addappid(728471, 1, "3f3333026546371f042320023bc3bc2534ddc21f5a74cce0e7471aca33815f63")

