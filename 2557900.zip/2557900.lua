-- Lua provided by RyzenAPI
-- Game: Survival on a deserted island

-- MAIN APPLICATION
addappid(2557900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2557901, 1, "5bfb285402014f1206c638d32dea1e7ad4a7b5a5bd422ae4b30aa3ad436e5069")

