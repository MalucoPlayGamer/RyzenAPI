-- Lua provided by RyzenAPI
-- Game: 2557900

-- MAIN APPLICATION
addappid(2557900)
-- Game: addappid(2557900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2557901, 1, "5bfb285402014f1206c638d32dea1e7ad4a7b5a5bd422ae4b30aa3ad436e5069")
