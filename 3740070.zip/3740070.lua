-- Lua provided by RyzenAPI
-- Game: Fear Night Tales - Brothers Kebab Saloon

-- MAIN APPLICATION
addappid(3740070)
-- Game: addappid(3740070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3740071, 1, "46f9fe1473b827ff38ef597d5d543441dac058a0758df7e9414d0364887888c3")
