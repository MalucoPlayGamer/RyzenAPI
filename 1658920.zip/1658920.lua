-- Lua provided by RyzenAPI
-- Game: Crown Wars: The Black Prince

-- MAIN APPLICATION
addappid(1658920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658921, 1, "75993344fb9b31485b7e0598513345bda18b0db53f1930bc5d19ba3ab5841c7a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2727730)
addappid(2727740)
addappid(2727750)
addappid(2727760)
