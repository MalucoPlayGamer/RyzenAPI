-- Lua provided by RyzenAPI
-- Game: Crown Wars: The Black Prince

-- MAIN APPLICATION
addappid(1658920)
-- Game: addappid(1658920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658921, 1, "75993344fb9b31485b7e0598513345bda18b0db53f1930bc5d19ba3ab5841c7a")
