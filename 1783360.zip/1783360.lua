-- Lua provided by RyzenAPI
-- Game: Meg's Monster

-- MAIN APPLICATION
addappid(1783360)
addappid(3790820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783361, 1, "9d02af782feeec83328e64fa77e4d309c034bc0bebeb8cfffe34ce35ce645417")

