-- Lua provided by RyzenAPI 
-- Game: AppID 945920
addappid(945920)
addappid(945921, 1, "165fe59190a43ff5d3024263fe92b63a64429e70087511c1c7b06b75808be34d")
