-- Lua provided by RyzenAPI
-- Game: MACHI KORO With Everyone  Demo

-- MAIN APPLICATION
addappid(2959700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959701, 1, "4ed0b9e44bbd3992cedf402029f5b8f27134c05a18f222483ac9832115c2397e")
