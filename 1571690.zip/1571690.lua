-- Lua provided by RyzenAPI
-- Game: 1571690

-- MAIN APPLICATION
addappid(1571690)
-- Game: addappid(1571690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571691, 1, "b4fd79e95fc359fa05eb3227444147aea72f2b4de139bf7d74397bd3dc3c2b68")
