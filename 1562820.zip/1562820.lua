-- Lua provided by RyzenAPI
-- Game: SUCCUBUS Demo

-- MAIN APPLICATION
addappid(1562820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562821, 1, "15853dc5869e53fe65b45556ee0e028d98efcdd364d162d4aaf23a4abc90ef18")

