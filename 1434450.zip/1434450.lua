-- Lua provided by RyzenAPI
-- Game: Hero by Chance: Lady Man

-- MAIN APPLICATION
addappid(1434450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434450,0,"45cfbf1c0d7c8e8344a309c38b19422ed9fae25616ee4560845e34bd4bb930c2")
