-- Lua provided by RyzenAPI
-- Game: Automation - The Car Company Tycoon Game

-- MAIN APPLICATION
addappid(293760)
addappid(350690)

-- MAIN APP DEPOTS / PACKAGES
addappid(293761, 1, "fb8222a3b3e27287488f679bac5fcfad63a0e0788aba25dc92daef1b8bcc8a20")
addappid(293763, 1, "7ec9b41ee31af226e692adbb59e357a8ca86bef110eee64952d7c03046822520")
addappid(359180, 0, "ed26582ba2f857a7988fddd419b3349a3ea2c59cea1259d7f6d52383e1fd9252")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
