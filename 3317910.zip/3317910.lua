-- Lua provided by RyzenAPI
-- Game: Heroes of Valor Playtest

-- MAIN APPLICATION
addappid(3317910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317911, 1, "958fc114ac3b5e4fb8f46107dfe91dc9255f8105c5b9d4e66be468d1db4d9c05")
