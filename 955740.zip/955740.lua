-- Lua provided by RyzenAPI
-- Game: Mini Healer

-- MAIN APPLICATION
addappid(955740)

-- MAIN APP DEPOTS / PACKAGES
addappid(955741, 1, "7d6b1d71f6b8c1b0e0da7742a713fc5c2bd8ce341599e1072e86b1ba40a9a84a")
