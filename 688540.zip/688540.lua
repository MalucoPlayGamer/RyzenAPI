-- Lua provided by RyzenAPI
-- Game: AppID 688540

-- MAIN APPLICATION
addappid(688540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(688541, 1, "4ab92f086dd11ccdda52175de5301341c928d8b2739401c43b4da0732019a99e")

