-- Lua provided by RyzenAPI
-- Game: AppID 688540

-- MAIN APPLICATION
addappid(688540)
-- Game: addappid(688540)

-- MAIN APP DEPOTS / PACKAGES
addappid(688541, 1, "4ab92f086dd11ccdda52175de5301341c928d8b2739401c43b4da0732019a99e")
