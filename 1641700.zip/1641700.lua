-- Lua provided by RyzenAPI
-- Game: Game: Moving Out 2

-- MAIN APPLICATION
addappid(1641700)
addappid(2410580)
-- Game: addappid(1641700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641701, 1, "87425c1557b863d4091a52a61a146d1634d5de17464e6e2107c05b2806ffd4ce")
addappid(2502500, 0, "4f8bd8296b8af0d840f53c6d1f93d57613db76ade437a0105e5c4fabc4475410")
