-- Lua provided by RyzenAPI
-- Game: Noobkillers

-- MAIN APPLICATION
addappid(1792650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1792651, 1, "3704610256d92716a17fbfc4c9e3a3b8e5d35e3c58c46c12de5cc060fc827485")

