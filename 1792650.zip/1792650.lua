-- Lua provided by RyzenAPI
-- Game: Game: AppID 1792650

-- MAIN APPLICATION
addappid(1792650)
-- Game: addappid(1792650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792651, 1, "3704610256d92716a17fbfc4c9e3a3b8e5d35e3c58c46c12de5cc060fc827485")
