-- Lua provided by RyzenAPI
-- Game: AppID 873290

-- MAIN APPLICATION
addappid(873290)
-- Game: addappid(873290)

-- MAIN APP DEPOTS / PACKAGES
addappid(873291, 1, "b65a13c08bacce24227dd2bd854fee233179b5d97c3667a7930cc9c55484b62b")
addappid(873292, 1, "552b089bfc5fb757eb58b06e2114d750ffa3b4c7d8383277f9e786342b8b4b30")
addappid(873293, 1, "a5b87c16a286fee8da30f248fbf7e01f7e7d2e393b4ce99fe6077771a10c28bd")
