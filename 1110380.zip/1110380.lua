-- Lua provided by RyzenAPI
-- Game: Fit For a King

-- MAIN APPLICATION
addappid(1110380)
-- Game: addappid(1110380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110381, 1, "b22fe7f5bfc0e6bde26cdcf80b72e7e59f47f16239c3c07ef6a750f53028dfb3")
