-- Lua provided by RyzenAPI 
-- Game: Metal Dead
addappid(302690)
addappid(302691, 1, "8a2d2ef9d31896813b935df61b370bf2b197d0558f10b5acd520a0727e8d1238")
