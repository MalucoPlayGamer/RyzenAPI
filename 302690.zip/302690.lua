-- Lua provided by RyzenAPI
-- Game: addappid(302690)

-- MAIN APPLICATION
addappid(302690)

-- MAIN APP DEPOTS / PACKAGES
addappid(302691, 1, "8a2d2ef9d31896813b935df61b370bf2b197d0558f10b5acd520a0727e8d1238")
