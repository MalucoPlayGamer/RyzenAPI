-- Lua provided by RyzenAPI 
-- Game: Ultros - Demo
addappid(2709040)
addappid(2709041, 1, "1d31de507af89c62d312e91171440f1543fc305c3f51d22ca1938e9b0d102614")
