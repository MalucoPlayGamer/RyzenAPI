-- Lua provided by RyzenAPI
-- Game: JQ: dogs & cats

-- MAIN APPLICATION
addappid(816250)

-- MAIN APP DEPOTS / PACKAGES
addappid(816251, 1, "7b923d59526309ff5ad0fb0e1fc957036b2f13ce26ae15d33d0b470c2f5aebed")
