-- Lua provided by RyzenAPI
-- Game: addappid(2966400)

-- MAIN APPLICATION
addappid(2966400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966401, 1, "8efc6bf92eaa09d8099bcc6d50bc038f5b173737879ed5a58c957b6bd3980ec5")
