-- Lua provided by RyzenAPI
-- Game: Game: Aragami 2 - Soundtrack

-- MAIN APPLICATION
addappid(1797200)
-- Game: addappid(1797200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797201, 1, "19ec49003e64f734481727d21065a60c345c83f0c44c878039ee0859957973ce")
addappid(1797202, 1, "466af69c0bfa1e4d8b237877dccb7766f79f4a15b20e51689a525d695192526d")
