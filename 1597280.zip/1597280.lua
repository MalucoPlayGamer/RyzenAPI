-- Lua provided by RyzenAPI
-- Game: Live Empire 2

-- MAIN APPLICATION
addappid(1597280)
addappid(1719820)
-- Game: addappid(1597280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597281, 1, "3e2b294c33f31fb3439af7ffb33ea41cfea550a720299b8a9e78f5016908759e")
addappid(1719800, 0, "06ff72a5f8717b869c00de765cc3ae43c219997139652842a42bf740f8bc710e")
