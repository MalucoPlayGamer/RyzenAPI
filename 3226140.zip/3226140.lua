-- Lua provided by RyzenAPI
-- Game: Coffee Please

-- MAIN APPLICATION
addappid(3226140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226141, 1, "63dd1edaebc06b259c5d283bbd4763689f622ab7733bd3173e140e1e35d456e2")
