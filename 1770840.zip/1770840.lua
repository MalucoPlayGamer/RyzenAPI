-- Lua provided by RyzenAPI
-- Game: The medical examination diary: the exciting days of me and my senpai

-- MAIN APPLICATION
addappid(1770840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1770841, 1, "a8fb207778be9fe014733c246481fd7bda3e28ee3b1b6f6d7b6b3ac84bf6b22d")

