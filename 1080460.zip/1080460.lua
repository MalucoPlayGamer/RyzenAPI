-- Lua provided by SkyAPI 
-- Game: AppID 1080460
addappid(1080460)
addappid(1080461, 1, "99846492d5b0615c9f129226cc492cde9569df37c7e70f3d2a982d164a6e8187")
