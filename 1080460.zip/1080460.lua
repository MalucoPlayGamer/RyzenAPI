-- Lua provided by RyzenAPI
-- Game: Game: AppID 1080460

-- MAIN APPLICATION
addappid(1080460)
-- Game: addappid(1080460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080461, 1, "99846492d5b0615c9f129226cc492cde9569df37c7e70f3d2a982d164a6e8187")
