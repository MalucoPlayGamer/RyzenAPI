-- Lua provided by SkyAPI 
-- Game: Rising Hell
addappid(657000)
addappid(657001, 1, "e9b8fb8d9210904da3a6b3f0aaf1b24514564d02f701a970861cfb60d1ca473c")
