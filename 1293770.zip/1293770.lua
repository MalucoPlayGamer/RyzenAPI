-- Lua provided by RyzenAPI
-- Game: AppID 1293770

-- MAIN APPLICATION
addappid(1293770)
-- Game: addappid(1293770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293771, 1, "02c7f05bbba15880f133bc0b24d6b3d08f4f66fa80774d9f1ed8de0f140d9488")
