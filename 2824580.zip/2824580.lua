-- Lua provided by RyzenAPI
-- Game: Terry's Other Games

-- MAIN APPLICATION
addappid(2824580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824581, 1, "8a90e1e60596221ea975f5a494f919e4a8fd97e4926734dd5cdef51ec2769ab8")

