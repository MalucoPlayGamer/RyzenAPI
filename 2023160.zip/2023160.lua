-- Lua provided by RyzenAPI
-- Game: 2023160

-- MAIN APPLICATION
addappid(2023160)
-- Game: addappid(2023160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023161, 1, "4079dfeddd03c1fd345be8876f0334d258f937ae28a162dbdbfb17f0b23268c4")
