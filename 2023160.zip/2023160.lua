-- Lua provided by RyzenAPI
-- Game: Monster Showdown: Prologue

-- MAIN APPLICATION
addappid(2023160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023161, 1, "4079dfeddd03c1fd345be8876f0334d258f937ae28a162dbdbfb17f0b23268c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
