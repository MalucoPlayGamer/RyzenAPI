-- Lua provided by RyzenAPI
-- Game: Critical Failure

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2610640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610648,0,"d34f5b078a83deaccb8ebc1857d001f7100dce35d3d271ec2a16a00635ed0b93")

