-- Lua provided by RyzenAPI
-- Game: 3296800

-- MAIN APPLICATION
addappid(3296800)
-- Game: addappid(3296800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296801, 1, "276527398cee5ae75a21e2a010daadd8b10987f2e7030c1c3a4726f09413c501")
