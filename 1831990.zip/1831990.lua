-- Lua provided by RyzenAPI
-- Game: addappid(1831990)

-- MAIN APPLICATION
addappid(1831990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831991, 1, "f3f33a4d1311b47f2fc0c71d97df8aeb4e50da1de94e67511e5539d4df225586")
