-- Lua provided by RyzenAPI
-- Game: addappid(1522120)

-- MAIN APPLICATION
addappid(1522120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522122,0,"c7280c4393ca201b2cd4542482333f6ea536b823f8de1810674ffd759fcbcc3a")
