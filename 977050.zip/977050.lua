-- Lua provided by SkyAPI 
-- Game: AppID 977050
addappid(977050)
addappid(977051, 1, "b08c62829c2cf6ec114e9ee8be942d8a69ebf20449f655481ddeec142f46e1db")
addappid(977052, 1, "c517cbd81177c7f78ea51954260a85c71acd0678f170e3e8ae26a05d6bd2a653")
addappid(977053, 1, "5964768345741dbfef987df0e86fa2beffa0cde05efc961afef09561a48788f5")
