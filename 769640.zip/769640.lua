-- Lua provided by RyzenAPI
-- Game: Lordian: Karma

-- MAIN APPLICATION
addappid(769640)

-- MAIN APP DEPOTS / PACKAGES
addappid(769641,0,"e86753cd36b139cdf747c48777e0fe12d67c9c1751b96e6bd2b51fadfb42c096")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
