-- Lua provided by RyzenAPI
-- Game: Lordian: Karma

-- MAIN APPLICATION
addappid(769640)

-- MAIN APP DEPOTS / PACKAGES
addappid(769641,0,"e86753cd36b139cdf747c48777e0fe12d67c9c1751b96e6bd2b51fadfb42c096")

