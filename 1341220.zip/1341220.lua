-- Lua provided by RyzenAPI
-- Game: BlackJack Math

-- MAIN APPLICATION
addappid(1341220)
addappid(1341224)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341223,0,"a1896e8f2898cc08f0fb67397fa68e127821a29f9ae3586a56414d7350e5d075")

