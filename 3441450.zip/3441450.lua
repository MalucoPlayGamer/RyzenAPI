-- Lua provided by RyzenAPI
-- Game: addappid(3441450)

-- MAIN APPLICATION
addappid(3441450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441451, 1, "c2d5f3ab2133d0a3c60445feeac7ffa7fd9034e44e88579c3a8c847d6a7503e2")
