-- Lua provided by RyzenAPI
-- Game: The Eerie Inn VR

-- MAIN APPLICATION
addappid(910530)
-- Game: addappid(910530)

-- MAIN APP DEPOTS / PACKAGES
addappid(910531, 1, "78b31d21cf86a86549e732ae850414763491d0b99c9565ac083562fd8180615f")
