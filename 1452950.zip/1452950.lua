-- Lua provided by RyzenAPI
-- Game: Seditionis: Tower Defense

-- MAIN APPLICATION
addappid(1452950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452951,0,"7d65b7709f8ba1db32071005908086b85de0de7a501ddda7abb54ada72e7001b")

