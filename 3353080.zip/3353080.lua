-- Lua provided by RyzenAPI
-- Game: 2024: Aliens Are Coming

-- MAIN APPLICATION
addappid(3353080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3353081, 1, "1aa2d2d8faff66235c685c09a8b74ca60b6dc6f87d6b0ca6c8940243dba4b92c")