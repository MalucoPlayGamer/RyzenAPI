-- Lua provided by RyzenAPI
-- Game: Powargrid

-- MAIN APPLICATION
addappid(453130)
-- Game: addappid(453130)

-- MAIN APP DEPOTS / PACKAGES
addappid(453132,0,"dfdc46b0ff0c327ec565892b057dfe956ccab760e55862c721e35db02ba9c172")
addappid(453133,0,"7a242c04ddb199b2544ae026fd79065dc28e69d5a6a1a99b5f501c43b6094836")
addappid(453134,0,"76530dbf73570e8496ba6d6eab4b8d92d2cdd8ca084c5afd605413f4bb660b90")
