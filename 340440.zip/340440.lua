-- Lua provided by SkyAPI 
-- Game: AppID 340440
addappid(340440)
addappid(340441, 1, "7908e2dd9c973d23264fa0e45f2e2bc02f4d5d3cbb5617690bf478f842151cb4")
