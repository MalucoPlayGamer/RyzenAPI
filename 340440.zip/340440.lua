-- Lua provided by RyzenAPI
-- Game: addappid(340440)

-- MAIN APPLICATION
addappid(340440)

-- MAIN APP DEPOTS / PACKAGES
addappid(340441, 1, "7908e2dd9c973d23264fa0e45f2e2bc02f4d5d3cbb5617690bf478f842151cb4")
