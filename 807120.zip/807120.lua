-- Lua provided by RyzenAPI
-- Game: Iratus: Lord of the Dead

-- MAIN APPLICATION
addappid(807120)

-- MAIN APP DEPOTS / PACKAGES
addappid(807121, 1, "4abef78e7146eb9c67587777f09791efc6f89486b2c3be18305d0c97517e563a")
addappid(807122, 1, "58909b15a93a8b9a68eaebd7deaaf1f6b4e5eb5981988c06575017e21fecb2ba")
addappid(807123, 1, "078ba2905e885aa615df92e12f069767efdf974378229f6e7966e34287c3c205")
addappid(1018330, 0, "f7ba2e39c03e365a2901925687991bbd8c3668839d9df5239c5d3dddae5822bc")
addappid(1125270, 0, "1f83eecd6bc6cdef44ea0d4edbcc703ade8549efba78d54ef865edf1362a088a")

