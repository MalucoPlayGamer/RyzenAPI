-- Lua provided by RyzenAPI
-- Game: 2515920

-- MAIN APPLICATION
addappid(2515920)
-- Game: addappid(2515920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515921, 1, "f2b056e0656ace91fda702f161d59967be68e910eb55d57832c299b44bd7942f")
