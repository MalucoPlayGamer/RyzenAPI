-- Lua provided by RyzenAPI
-- Game: Necrosmith 2 Playtest

-- MAIN APPLICATION
addappid(2676910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676911, 1, "8d2b50ea115043d34b26018c3e3a7d1008a62e24e62e0afdcad63862c913f25a")
