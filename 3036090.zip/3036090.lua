-- Lua provided by RyzenAPI
-- Game: Hermit and Pig Demo

-- MAIN APPLICATION
addappid(3036090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036091, 1, "ff25b3193dc99b455bb5e574f0e19f033f934b1fc56e1bd22103e297df064079")

