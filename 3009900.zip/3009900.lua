-- Lua provided by SkyAPI 
-- Game: System Malfunction
addappid(3009900)
addappid(3009901, 1, "f8cab3c1d2f9a78c1327ac453e368e689c611febde32f4a207da5cc741e6fed3")
