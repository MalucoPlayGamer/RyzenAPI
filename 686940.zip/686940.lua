-- Lua provided by RyzenAPI
-- Game: Game: AppID 686940

-- MAIN APPLICATION
addappid(686940)
-- Game: addappid(686940)

-- MAIN APP DEPOTS / PACKAGES
addappid(686941, 1, "8a54a656f7028f11b74736e3b65722ccf07c1105107121b1eb4cea308c73f58f")
