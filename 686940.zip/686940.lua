-- Lua provided by RyzenAPI
-- Game: AppID 686940

-- MAIN APPLICATION
addappid(686940)
addappid(709500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(686941, 1, "8a54a656f7028f11b74736e3b65722ccf07c1105107121b1eb4cea308c73f58f")

