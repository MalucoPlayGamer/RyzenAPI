-- Lua provided by RyzenAPI
-- Game: Monster Care Simulator

-- MAIN APPLICATION
addappid(3288270)
-- Game: addappid(3288270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288271, 1, "3fb90eeaf9bded22b7e94db0b157e734d017d6c5409e84add5ae511ce9958730")
