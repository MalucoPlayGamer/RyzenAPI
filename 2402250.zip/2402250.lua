-- Lua provided by RyzenAPI
-- Game: The Art of Layers of Fear

-- MAIN APPLICATION
addappid(2402250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402251, 1, "ecfc226980d395722ffa727cb8515aa57d1d3b4e3a3651cf93b21acd4d0c077f")
