-- Lua provided by RyzenAPI
-- Game: Hellblade II: Senua’s Saga

-- MAIN APPLICATION
addappid(2461850)
-- Game: addappid(2461850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461851, 1, "3805dcaa86b71b66a1c801a5d51ccbeeabe1dac943203014f8810e33d77a0814")
