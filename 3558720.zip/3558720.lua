-- Lua provided by RyzenAPI
-- Game: Out of Sight VR

-- MAIN APPLICATION
addappid(3558720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3558721, 1, "f8416581142cb6812c72a937bdb5df289667d94564989da1b535a696131193ec")

