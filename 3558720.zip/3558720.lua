-- Lua provided by RyzenAPI
-- Game: Out of Sight VR

-- MAIN APPLICATION
addappid(3558720)
-- Game: addappid(3558720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558721, 1, "f8416581142cb6812c72a937bdb5df289667d94564989da1b535a696131193ec")
