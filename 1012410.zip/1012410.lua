-- Lua provided by RyzenAPI
-- Game: AppID 1012410

-- MAIN APPLICATION
addappid(1012410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012411, 1, "4d918da5e554bc2c4744eeab9c10b0b488e78f5d0d60b691c2d4b69aa7a419de")
