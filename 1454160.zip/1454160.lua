-- Lua provided by SkyAPI 
-- Game: One More Island
addappid(1454160)
addappid(1454161, 1, "6244fbc6720cc1ec1cbb68d9474ba487d26ef80cd20f58f5a3c7c00f81ddaf0c")
