-- Lua provided by RyzenAPI
-- Game: addappid(1454160)

-- MAIN APPLICATION
addappid(1454160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454161, 1, "6244fbc6720cc1ec1cbb68d9474ba487d26ef80cd20f58f5a3c7c00f81ddaf0c")
