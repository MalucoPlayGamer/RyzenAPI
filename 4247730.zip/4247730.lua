-- Lua provided by RyzenAPI
-- Game: BookStore Simulator

-- MAIN APPLICATION
addappid(4247730) -- BookStore Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4247731, 1, "2e9d861129222066aadc845df04d615796c8ef05c5a39ecb6a1eb1785a24b4bc") -- Depot 4247731

