-- 4247730's Lua and Manifest Created by Hubcap Manifest
-- BookStore Simulator
-- Created: August 10, 2026 at 14:55:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4247730) -- BookStore Simulator
-- MAIN APP DEPOTS
addappid(4247731, 1, "2e9d861129222066aadc845df04d615796c8ef05c5a39ecb6a1eb1785a24b4bc") -- Depot 4247731
setManifestid(4247731, "1258143707831490663", 15124842857)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)