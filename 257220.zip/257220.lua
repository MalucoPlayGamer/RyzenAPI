-- Lua provided by RyzenAPI
-- Game: Secret Files: Sam Peters

-- MAIN APPLICATION
addappid(257220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(257221, 1, "d30281421efea837991d237cdecd72e89d73e9f2196b0dc94c73018e27958663")
addappid(257222, 1, "ee8288c329fc1307a267af5595aaf666322b0f510fd76ba9359511c639b57008")
addappid(257223, 1, "fd476e49e1cef0dff49b36bc4b8eb8ace5b154d498799f394c6e468d3d9371a8")
addappid(257224, 1, "e8f3f51673b727840793905ec8d430ba7b8dc4d03aa27af95448c773ba48e0a3")

