-- Lua provided by RyzenAPI
-- Game: Out There: Ω Edition

-- MAIN APPLICATION
addappid(334420)

-- MAIN APP DEPOTS / PACKAGES
addappid(334421, 1, "05c72bbf1b9b9704120aed3fb0e46b9f1714b9c6acde11b33ca9254d0df59693")
addappid(334422, 1, "165e289e11367c7f68924ecf634ebc69293aa3ba5ab7f4de2c649c3213241b4f")
addappid(334423, 1, "7caaf894d2f9df959e74a05d65bfe86ecaf473917deb964094667e5f3a9927a8")

