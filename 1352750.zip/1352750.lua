-- Lua provided by RyzenAPI
-- Game: Game: Comic&Picture Shelf

-- MAIN APPLICATION
addappid(1352750)
-- Game: addappid(1352750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352751, 1, "c789af9bf87f78deb8f6ef0bc9da31edea275b7d2eac253f75ecbda847d86f8f")
