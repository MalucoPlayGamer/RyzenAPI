-- Lua provided by RyzenAPI
-- Game: Game: Conur Life

-- MAIN APPLICATION
addappid(1888330)
-- Game: addappid(1888330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888331, 1, "c033e079926ea92675f64ff053d61a78f3871510a52f4b9b8a84a9c180261964")
