-- Lua provided by RyzenAPI
-- Game: Conur Life

-- MAIN APPLICATION
addappid(1888330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888331, 1, "c033e079926ea92675f64ff053d61a78f3871510a52f4b9b8a84a9c180261964")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
