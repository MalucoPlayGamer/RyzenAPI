-- Lua provided by RyzenAPI
-- Game: addappid(547990)

-- MAIN APPLICATION
addappid(547990)

-- MAIN APP DEPOTS / PACKAGES
addappid(547991, 1, "1cfa608ef5a03d7ecafcff01b796cd47c3eb6585ef87d15bc1df79fdfbdb1db8")
