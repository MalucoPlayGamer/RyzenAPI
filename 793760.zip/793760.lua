-- Lua provided by RyzenAPI
-- Game: My Sweet Waifu

-- MAIN APPLICATION
addappid(793760)

-- MAIN APP DEPOTS / PACKAGES
addappid(793761,0,"e44e4039dcc14d433252aadb63107a39c9090a1aecd1f21b11abddfcbd533852")

