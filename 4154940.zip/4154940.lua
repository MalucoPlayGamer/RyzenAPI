-- Lua provided by RyzenAPI
-- Game: Fathom's End

-- MAIN APPLICATION
addappid(4154940)

-- MAIN APP DEPOTS / PACKAGES
addappid(4154941,0,"20691fd1427282c7792144ad180b6a9bd77ce5010cb2b16d0b7c07d5d9ccc129")

