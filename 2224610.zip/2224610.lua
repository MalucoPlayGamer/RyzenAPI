-- Lua provided by RyzenAPI
-- Game: Project Planet - Earth vs Humanity

-- MAIN APPLICATION
addappid(2224610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224611, 1, "454981030adf3bc687b74872769a6d05f66ce00bcd809305e50171a74e7521d7")
