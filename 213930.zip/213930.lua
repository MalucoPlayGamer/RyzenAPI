-- Lua provided by RyzenAPI
-- Game: 213930

-- MAIN APPLICATION
addappid(213930)
-- Game: addappid(213930)

-- MAIN APP DEPOTS / PACKAGES
addappid(213930,0,"5020dedf86e51956d18cf005a1cf2f761437f9eb6daa89c8593972edb4a51149")
