-- Lua provided by RyzenAPI
-- Game: AppID 3280170

-- MAIN APPLICATION
addappid(3280170)
-- Game: addappid(3280170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3280171, 1, "77db591899179991333cbb9ed2dd724cbdcf8c2cd5e962f4477789f96936b254")
