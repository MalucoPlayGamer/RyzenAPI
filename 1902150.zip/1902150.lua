-- Lua provided by RyzenAPI
-- Game: 1902150

-- MAIN APPLICATION
addappid(1902150)
-- Game: addappid(1902150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902151, 1, "99c8ccf16c72257db4981826cb5b79b3a1cfb70239e94e0aeb0421d27de8c229")
