-- Lua provided by RyzenAPI
-- Game: Game: EMZOMBED

-- MAIN APPLICATION
addappid(2609760)
-- Game: addappid(2609760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609761, 1, "e2a38cea8d5821063268c45b22799e562dc9923f292ff015ff08e33cf5d372ad")
