-- Lua provided by RyzenAPI
-- Game: EMZOMBED

-- MAIN APPLICATION
addappid(2609760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2609761, 1, "e2a38cea8d5821063268c45b22799e562dc9923f292ff015ff08e33cf5d372ad")

