-- Lua provided by RyzenAPI 
-- Game: AppID 431950
addappid(431950)
addappid(431951, 1, "1569ebae29342eeb46fd50fcaf6bcd28dead1d8b1a4fac0e58724e61fe084414")
addappid(1217540, 0, "421fc620da0bd2a39836460e98672caa1a95bc205a7bcd307077e3fe1503473c")
addappid(1311170, 0, "7d2eeb36985ad254067c84a4b05b289e4ab150db9432f3a6b4e64b37675ba7d7")
