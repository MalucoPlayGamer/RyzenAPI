-- Lua provided by RyzenAPI
-- Game: Age of Fear 4: The Iron Killer

-- MAIN APPLICATION
addappid(431950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(431951, 1, "1569ebae29342eeb46fd50fcaf6bcd28dead1d8b1a4fac0e58724e61fe084414")
addappid(1217540, 0, "421fc620da0bd2a39836460e98672caa1a95bc205a7bcd307077e3fe1503473c")
addappid(1311170, 0, "7d2eeb36985ad254067c84a4b05b289e4ab150db9432f3a6b4e64b37675ba7d7")

