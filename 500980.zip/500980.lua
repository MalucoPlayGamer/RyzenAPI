-- Lua provided by RyzenAPI
-- Game: AppID 500980

-- MAIN APPLICATION
addappid(500980)

-- MAIN APP DEPOTS / PACKAGES
addappid(500981, 1, "7769a689c4744f9b732aee7ccde87dfaa7d515fd2a9965a20b70b090b1ef1174")
