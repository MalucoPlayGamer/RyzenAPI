-- Lua provided by RyzenAPI
-- Game: CPUCores :: System Hardware Analyzer

-- MAIN APPLICATION
addappid(726480)

-- MAIN APP DEPOTS / PACKAGES
addappid(726480,0,"c80d3dd9033b9fef991db1e79159287307918debf93ce1b757b27e21bc1edf78")
