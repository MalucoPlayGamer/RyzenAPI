-- Lua provided by RyzenAPI
-- Game: The Soul Inside Us Demo

-- MAIN APPLICATION
addappid(3033390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033391, 1, "f3debf319ceb965868df0b8a9bc0aa19a52e12da6c4cf6799ad42107399e7dd7")
