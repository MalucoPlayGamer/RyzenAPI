-- Lua provided by RyzenAPI
-- Game: CyberBlocker Complete Edition

-- MAIN APPLICATION
addappid(2123390)
-- Game: addappid(2123390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123391, 1, "cbde53535f57a2035bd25a31cd44843db8afd59fc9cb7d274e8e7154a7ee949d")
