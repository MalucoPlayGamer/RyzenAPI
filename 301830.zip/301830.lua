-- Lua provided by SkyAPI 
-- Game: AppID 301830
addappid(301830)
addappid(301831, 1, "e1dc404204560ce7d60931e22b7845848726458b5f91888527e0afb01003256c")
