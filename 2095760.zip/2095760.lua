-- Lua provided by RyzenAPI
-- Game: 2095760

-- MAIN APPLICATION
addappid(2095760)
-- Game: addappid(2095760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095761, 1, "08d7dd2c5818119474accc14737bd7fc0038df05faec67fd0db80f2daea9ddd4")
