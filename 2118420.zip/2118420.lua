-- Lua provided by RyzenAPI
-- Game: addappid(2118420)

-- MAIN APPLICATION
addappid(2118420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118421, 1, "ca6c947bc32d228f3036759070557ce4d3fb7aa4dd11074ddfe44680ba6e7d09")
