-- Lua provided by RyzenAPI
-- Game: Game: The Heart of Darkness

-- MAIN APPLICATION
addappid(1413990)
-- Game: addappid(1413990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413991, 1, "2cdebe17c37274d85751047e31615a87f6b0e9fa2195f5a98d58192d763c3d53")
addappid(1413992, 1, "10b310a30c15e65a617b2916acb27030a98c02469170bfa5a7a0d332d2969ccf")
addappid(1413993, 1, "f60809d67f6ebad8563538371c3ba65c0d2ebcca8afa7a1e8d88ae615f497c81")
