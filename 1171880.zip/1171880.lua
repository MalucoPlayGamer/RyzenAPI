-- Lua provided by SkyAPI 
-- Game: AppID 1171880
addappid(1171880)
addappid(1171881, 1, "619ccf0bed7885e7143c267988e3adc93a9c24833a3a3c5209967b159dea309f")
