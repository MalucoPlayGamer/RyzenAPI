-- Lua provided by RyzenAPI
-- Game: Game: AppID 1171880

-- MAIN APPLICATION
addappid(1171880)
-- Game: addappid(1171880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171881, 1, "619ccf0bed7885e7143c267988e3adc93a9c24833a3a3c5209967b159dea309f")
