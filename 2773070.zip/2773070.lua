-- Lua provided by RyzenAPI 
-- Game: AppID 2773070
addappid(2773070)
addappid(2773071, 1, "11c1c78c668b0a6a7c523cb8e74967061f9c862864729837ca4568fe22d32008")
