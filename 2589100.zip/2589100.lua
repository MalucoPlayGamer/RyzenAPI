-- Lua provided by RyzenAPI
-- Game: addappid(2589100)

-- MAIN APPLICATION
addappid(2589100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589102,0,"3a2d36580ddca77e52ce6df6455d75e78aac01de0cf3fcc8044d1f9f151c96ae")
addappid(2589103,0,"ad28fa01d393bf7b1f958c2774cad5ba1f3fa79dff76fe2a61abcc8f94b82cd8")
