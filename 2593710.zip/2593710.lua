-- Lua provided by RyzenAPI
-- Game: AppID 2593710

-- MAIN APPLICATION
addappid(2593710)
-- Game: addappid(2593710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593711, 1, "6761396a32df35143f09e3fb76c7f66c614bb3512bd229faf87844bf13d96dfe")
