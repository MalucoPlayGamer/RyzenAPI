-- Lua provided by RyzenAPI
-- Game: Remothered: Tormented Fathers

-- MAIN APPLICATION
addappid(633360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(633361, 1, "9b459f3b16a4d0811bf35761f3cb745df15e4c21aaded331057f3c32db5ac741")
addappid(748290, 0, "2f22bacf5772a265e7c342c297bf4f199bd70ddce7a38634eca4fd8a18979721")
addappid(748291, 0, "db65a8396cc7453dc20621d32dfa0499ade6555520a12af8bcc236bb2fe9265f")
addappid(1285950, 0, "41ea8b8f5a82aec62c150b29acb86eb259969ca26e8632f6aca1a97f488d715a")

