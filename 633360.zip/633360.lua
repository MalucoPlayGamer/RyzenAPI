-- Lua provided by RyzenAPI 
-- Game: Remothered: Tormented Fathers
addappid(633360)
addappid(633361, 1, "9b459f3b16a4d0811bf35761f3cb745df15e4c21aaded331057f3c32db5ac741")
addappid(748290, 0, "2f22bacf5772a265e7c342c297bf4f199bd70ddce7a38634eca4fd8a18979721")
addappid(748291, 0, "db65a8396cc7453dc20621d32dfa0499ade6555520a12af8bcc236bb2fe9265f")
addappid(1285950, 0, "41ea8b8f5a82aec62c150b29acb86eb259969ca26e8632f6aca1a97f488d715a")
