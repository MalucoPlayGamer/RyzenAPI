-- Lua provided by RyzenAPI
-- Game: Jigsaw Puzzle Dreams

-- MAIN APPLICATION
addappid(1653970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653971, 1, "9b8650952b2b934a8243f4e6e7696f6699a925d391b34dde30b5b921d625335f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1832730)
addappid(1832731)
addappid(1832732)
addappid(1832733)
addappid(1832734)
addappid(2763190)
