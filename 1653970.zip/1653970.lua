-- Lua provided by RyzenAPI 
-- Game: Jigsaw Puzzle Dreams
addappid(1653970)
addappid(1653971, 1, "9b8650952b2b934a8243f4e6e7696f6699a925d391b34dde30b5b921d625335f")
