-- Lua provided by SkyAPI 
-- Game: AppID 465840
addappid(465840)
addappid(465841, 1, "35d94d108a102c82a477128700e60841b3f889b8996a5a1fd1e3d25a50d4394e")
