-- Lua provided by RyzenAPI
-- Game: Intersolar Overdrive

-- MAIN APPLICATION
addappid(963510)

-- MAIN APP DEPOTS / PACKAGES
addappid(963511, 1, "65bf66a72196998bf4bbe7df873a741d20aa77f0cce0d8d0740fdd6e2bc3e251")
