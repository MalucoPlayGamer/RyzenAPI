-- Lua provided by RyzenAPI
-- Game: AppID 714370

-- MAIN APPLICATION
addappid(714370)
addappid(978220)
addappid(1019200)
addappid(1019201)
addappid(1037520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(714371, 1, "636b89371d3506d1a8edec63d4fd097a5a8e48e38818ea3d2829f2b0fadc2874")

