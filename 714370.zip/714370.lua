-- Lua provided by RyzenAPI
-- Game: Game: AppID 714370

-- MAIN APPLICATION
addappid(714370)
-- Game: addappid(714370)

-- MAIN APP DEPOTS / PACKAGES
addappid(714371, 1, "636b89371d3506d1a8edec63d4fd097a5a8e48e38818ea3d2829f2b0fadc2874")
