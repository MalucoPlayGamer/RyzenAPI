-- Lua provided by RyzenAPI
-- Game: Game: Musician Simulator

-- MAIN APPLICATION
addappid(3006010)
-- Game: addappid(3006010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006011, 1, "3d529d9240534e58f5c8a082014ad116cb2b23d5bd2fb2eb8dae75e510bad099")
