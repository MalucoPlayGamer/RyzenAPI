-- Lua provided by RyzenAPI
-- Game: Game: Maid Mansion Soundtrack

-- MAIN APPLICATION
addappid(1374190)
-- Game: addappid(1374190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374191, 1, "0aa08f8c24138d753312f628631cde165b7532ec6303221c19f8398e8c3174fd")
addappid(1374192, 1, "42dfba8620509887648fce4bee5ac0254cef713d7b153293eeb4a1e2c51f1062")
