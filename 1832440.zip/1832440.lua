-- Lua provided by RyzenAPI 
-- Game: Happy's Humble Burger Farm: Super Barnyard Buds (OST)
addappid(1832440)
addappid(1832441, 1, "28afca393aed6e7ce85640324bbc972ac39a5099b1ba53c119466ab13025c469")
