-- Lua provided by RyzenAPI
-- Game: 643820

-- MAIN APPLICATION
addappid(643820)
-- Game: addappid(643820)

-- MAIN APP DEPOTS / PACKAGES
addappid(643821, 1, "fbba8afb80ce904f98af1335b5092fac29c414e39ac7267baad1f06e62119010")
