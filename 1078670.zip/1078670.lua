-- Lua provided by RyzenAPI
-- Game: AppID 1078670

-- MAIN APPLICATION
addappid(1078670)
-- Game: addappid(1078670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078671, 1, "23d30f22d19b27291ad07b68157341186b6bad4a0aeb18385ebf4411280dbe43")
