-- Lua provided by RyzenAPI
-- Game: Table Tennis Toon!

-- MAIN APPLICATION
addappid(2713750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2713751, 1, "51ed968ead73a44207dcca5f090d21418ff4bc97c7628c91aae114e56d0794e2")

