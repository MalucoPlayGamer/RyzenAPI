-- Lua provided by RyzenAPI
-- Game: Game: ∀kashicforce

-- MAIN APPLICATION
addappid(857460)
addappid(1067340)
-- Game: addappid(857460)

-- MAIN APP DEPOTS / PACKAGES
addappid(857461, 1, "1e981f20c047047f29c3a0993de6ab1e7a50909fcfa05b8f4646f6b7426f222a")
