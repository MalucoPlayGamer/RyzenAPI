-- Lua provided by RyzenAPI
-- Game: addappid(2565730)

-- MAIN APPLICATION
addappid(2565730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565731, 1, "7c9a6fc1bb93c7fd8a497f7e2e46d93d861ba7859222e4acba95e68e2c3a4624")
