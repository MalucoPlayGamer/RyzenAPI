-- Lua provided by RyzenAPI
-- Game: Spirits' Creek

-- MAIN APPLICATION
addappid(2134920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134921, 1, "be4d840e569b54ed91b4f7d94509253173e81d8cd20248a852bc8e2c3c4a4ef1")

