-- Lua provided by RyzenAPI
-- Game: NBA 2K9

-- MAIN APPLICATION
addappid(7740)

-- MAIN APP DEPOTS / PACKAGES
addappid(7741, 1, "51b2915addc64a23da51dc4fea7ce1cb402c007b2deb376c431ba327f96d9ee1")

