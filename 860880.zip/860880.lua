-- Lua provided by RyzenAPI 
-- Game: AppID 860880
addappid(860880)
addappid(860881, 1, "3c035932d501efe884b09ea938c44186eb4b726318778a177bb454b89a523c93")
