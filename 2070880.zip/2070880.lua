-- Lua provided by RyzenAPI
-- Game: Creative Console

-- MAIN APPLICATION
addappid(2070880)
-- Game: addappid(2070880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070881, 1, "79613b86d245b9f6a88767eb685e393007f02c8d1696976765d42f7e5095e56b")
