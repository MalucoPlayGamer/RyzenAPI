-- Lua provided by RyzenAPI
-- Game: SONIC X SHADOW GENERATIONS: Art Book with Mini Soundtrack

-- MAIN APP DEPOTS / PACKAGES
addappid(2999160, 1)

