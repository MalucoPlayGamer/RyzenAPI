-- Lua provided by RyzenAPI
-- Game: 2999160

-- MAIN APP DEPOTS / PACKAGES
addappid(2999160, 1)
-- Game: addappid(2999160, 1)
