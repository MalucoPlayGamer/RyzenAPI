-- Lua provided by RyzenAPI
-- Game: Chex

-- MAIN APPLICATION
addappid(2241410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241412,0,"a306f141760ab3712aaf8e7dcb275b7dd450815b8dcbeb4e04571f022912f46c")

