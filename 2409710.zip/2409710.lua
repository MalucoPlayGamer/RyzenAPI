-- Lua provided by RyzenAPI
-- Game: addappid(2409710)

-- MAIN APPLICATION
addappid(2409710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409711, 1, "eefa1f98b563ba25569868b47a9c4a7e2434658cd9e7e80744fd321037bab5cd")
