-- Lua provided by RyzenAPI
-- Game: Game: AppID 2163730

-- MAIN APPLICATION
addappid(2163730)
-- Game: addappid(2163730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163731, 1, "98a53e4ec50ab7ff5880d76ae2e0eced9902cb9ca556b0b98128848a371e5dc6")
