-- Lua provided by SkyAPI 
-- Game: AppID 2163730
addappid(2163730)
addappid(2163731, 1, "98a53e4ec50ab7ff5880d76ae2e0eced9902cb9ca556b0b98128848a371e5dc6")
