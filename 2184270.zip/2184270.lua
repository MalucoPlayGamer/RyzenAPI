-- Lua provided by RyzenAPI
-- Game: Traveler

-- MAIN APPLICATION
addappid(2184270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184273,0,"e73227fc562b8a0e919debb8552014188dc3eaae7b83af1c1571858254264854")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2184300)
