-- Lua provided by RyzenAPI
-- Game: Traveler

-- MAIN APPLICATION
addappid(2184270)
-- Game: addappid(2184270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184273,0,"e73227fc562b8a0e919debb8552014188dc3eaae7b83af1c1571858254264854")
