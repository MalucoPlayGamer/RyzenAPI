-- Lua provided by RyzenAPI
-- Game: Game: Cafe Maid - Hentai Edition

-- MAIN APPLICATION
addappid(1586710)
-- Game: addappid(1586710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586711, 1, "93406ab674f96958167baea5b0807fd423030e320a691ef5dc13ed15db87ac33")
