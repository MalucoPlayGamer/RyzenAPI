-- Lua provided by RyzenAPI
-- Game: Cafe Maid - Hentai Edition

-- MAIN APPLICATION
addappid(1586710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586711, 1, "93406ab674f96958167baea5b0807fd423030e320a691ef5dc13ed15db87ac33")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2922380)
addappid(2922390)
