-- Lua provided by RyzenAPI
-- Game: AppID 1508890

-- MAIN APPLICATION
addappid(1508890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1508891, 1, "21e96ca753afc53d1dca90697a75491c06b55fd4d19d700d3ef0271678c8c092")

