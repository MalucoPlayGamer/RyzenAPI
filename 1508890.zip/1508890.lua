-- Lua provided by RyzenAPI
-- Game: 1508890

-- MAIN APPLICATION
addappid(1508890)
-- Game: addappid(1508890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508891, 1, "21e96ca753afc53d1dca90697a75491c06b55fd4d19d700d3ef0271678c8c092")
