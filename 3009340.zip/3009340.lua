-- Lua provided by SkyAPI 
-- Game: Duck N Roll Demo
addappid(3009340)
addappid(3009341, 1, "5a3b5e67f77a9639e9677bd103ca13ba7ff2859f63b3d367e2ebab8e1d748cd9")
