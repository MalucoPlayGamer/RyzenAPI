-- Lua provided by RyzenAPI
-- Game: Ascend to ZERO

-- MAIN APPLICATION
addappid(2697940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697940, 1, "104a8d0cf337b481a9af6651ef8d757f5e9457e86a92be8817aa5e691eb51a38")
addappid(2697941,0,"6425240483352d0f9aa08a06730dbed1e5a8ec489a48d39d0617cd0574ca96a1")
addappid(2697941, 1, "6425240483352d0f9aa08a06730dbed1e5a8ec489a48d39d0617cd0574ca96a1") -- Depot 2697941



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4786430)
