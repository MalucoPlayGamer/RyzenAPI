-- Lua provided by RyzenAPI
-- Game: Game: Multiverse Loot Hunter

-- MAIN APPLICATION
addappid(2776450)
-- Game: addappid(2776450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776451, 1, "d344b9a8eb3356663a0ad386889d0a675acdf4e1b2e41aa43d220e0ef38e65a8")
addappid(2776452, 1, "5dfd6d9811882cd6da7723ad0578e41691fde46e771cf807bc1c88eb807aa733")
