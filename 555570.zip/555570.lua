-- Lua provided by RyzenAPI
-- Game: Infestation: The New Z

-- MAIN APPLICATION
addappid(555570)
