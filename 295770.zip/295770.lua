-- Lua provided by RyzenAPI
-- Game: Rogue Shooter: The FPS Roguelike

-- MAIN APPLICATION
addappid(295770)

-- MAIN APP DEPOTS / PACKAGES
addappid(295771, 1, "ae17741a46bb6be936835cfb62646c0e3faebf7df1068a9f9fde867d52e203bf")

