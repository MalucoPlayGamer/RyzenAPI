-- Lua provided by RyzenAPI
-- Game: AppID 750780

-- MAIN APPLICATION
addappid(750780)

-- MAIN APP DEPOTS / PACKAGES
addappid(750781, 1, "ed677af2a4e62c361c644eaf20182de29a633b688c9a97cf9575a2ff60c39e6b")
