-- Lua provided by RyzenAPI
-- Game: Arm of Revenge Re-Edition

-- MAIN APPLICATION
addappid(1503630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503631, 1, "45c7e1f0896614cf1c95bc71be35255448ddc6f1caeadc8603264279dc7a5097")
