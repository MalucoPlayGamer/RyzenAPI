-- Lua provided by RyzenAPI
-- Game: 2803870

-- MAIN APPLICATION
addappid(2803870)
-- Game: addappid(2803870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803871, 1, "a6c74f098d5806b5ae10d0d92af25922f894f5f19f9dd444abd0bc4333e02b92")
