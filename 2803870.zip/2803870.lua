-- Lua provided by SkyAPI 
-- Game: AppID 2803870
addappid(2803870)
addappid(2803871, 1, "a6c74f098d5806b5ae10d0d92af25922f894f5f19f9dd444abd0bc4333e02b92")
