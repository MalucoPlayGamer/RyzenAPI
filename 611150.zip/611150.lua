-- Lua provided by RyzenAPI
-- Game: 611150

-- MAIN APPLICATION
addappid(611150)

-- MAIN APP DEPOTS / PACKAGES
addappid(611152,0,"46eaddbf0fe5db8bd34d55c1c035b677c04117ad19ea33cd7c20f71dae871246")

