-- Lua provided by RyzenAPI
-- Game: Super Mecha Champions

-- MAIN APPLICATION
addappid(1368910)
-- Game: addappid(1368910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368911, 1, "e5ac17a7d1ee4b1f9e4fdd826159962c541ee7333591955e93fcdb345ddbbca2")
