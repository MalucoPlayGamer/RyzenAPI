-- Lua provided by RyzenAPI
-- Game: Frame of Mind

-- MAIN APPLICATION
addappid(1485250)
-- Game: addappid(1485250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485251, 1, "691548217cfd998c1c6b236b649ca3b484c4dde3488108c7ce7d5891b4469184")
