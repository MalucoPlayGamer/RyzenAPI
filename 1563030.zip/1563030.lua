-- Lua provided by RyzenAPI
-- Game: Dangerous Lands

-- MAIN APPLICATION
addappid(1563030)
-- Game: addappid(1563030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563031, 1, "c0d8dc7f3843028db46b69d0cdb4a2cb4bfd08644e02fda1b05c25e0d725bf58")
