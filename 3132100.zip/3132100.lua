-- Lua provided by RyzenAPI
-- Game: Game: GIRLDIVERS Demo

-- MAIN APPLICATION
addappid(3132100)
-- Game: addappid(3132100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132101, 1, "8daf55392ec8c36a3d480d674681db6e3816801e61548592e93faeb7986cb594")
