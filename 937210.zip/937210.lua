-- Lua provided by RyzenAPI
-- Game: Game: МЫЛО УРОНИЛ

-- MAIN APPLICATION
addappid(937210)
-- Game: addappid(937210)

-- MAIN APP DEPOTS / PACKAGES
addappid(937211, 1, "d2d93f2f2d393b81d1792fd93c7767065e6ab7ade3cce70592b9706a4e3afda6")
