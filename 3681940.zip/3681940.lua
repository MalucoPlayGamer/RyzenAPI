-- Lua provided by RyzenAPI
-- Game: addappid(3681940)

-- MAIN APPLICATION
addappid(3681940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3681941, 1, "07bc6d908c36acc66b0c31bcb55aab4750a67b5903d93d288607c9649eb96dff")
