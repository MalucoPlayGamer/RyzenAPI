-- Lua provided by RyzenAPI
-- Game: Wildmender

-- MAIN APPLICATION
addappid(1599330)
addappid(2540280)
addappid(2540290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1599331, 1, "afd9a47ff2961d2300f050adb60d8518347475523c6708a9208f349156cc6835")

