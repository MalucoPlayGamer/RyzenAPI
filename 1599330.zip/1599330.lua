-- Lua provided by RyzenAPI
-- Game: Wildmender

-- MAIN APPLICATION
addappid(1599330)
-- Game: addappid(1599330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599331, 1, "afd9a47ff2961d2300f050adb60d8518347475523c6708a9208f349156cc6835")
