-- Lua provided by RyzenAPI
-- Game: Gerty

-- MAIN APPLICATION
addappid(455100)

-- MAIN APP DEPOTS / PACKAGES
addappid(455101, 1, "100fe0b55a4b0986a3182f4ac5ffc4c1e573968b5504067ce657041c14db0f2d")
