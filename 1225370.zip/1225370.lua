-- Lua provided by RyzenAPI
-- Game: Blast Rush Classic

-- MAIN APPLICATION
addappid(1225370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1225371, 1, "4bca2e6d6b67ddc57f1c4151fec7522a469ea3017d3dfbd9f92c338918f60007")

