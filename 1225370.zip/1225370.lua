-- Lua provided by RyzenAPI
-- Game: 1225370

-- MAIN APPLICATION
addappid(1225370)
-- Game: addappid(1225370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225371, 1, "4bca2e6d6b67ddc57f1c4151fec7522a469ea3017d3dfbd9f92c338918f60007")
