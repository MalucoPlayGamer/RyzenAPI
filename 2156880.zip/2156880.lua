-- Lua provided by RyzenAPI 
-- Game: Sex Adventures - The Bar Hookup
addappid(2156880)
addappid(2156881, 1, "33368b6d3a41102584ff513afd193f74c46e6bf1c9e6b36993ddb4f5e5650809")
