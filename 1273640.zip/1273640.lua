-- Lua provided by RyzenAPI
-- Game: 1273640

-- MAIN APPLICATION
addappid(1273640)
-- Game: addappid(1273640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273643,0,"fce3bc68b76c781b1084d70637da3afdc29bc96358e7e31a803210c64d694b9b")
