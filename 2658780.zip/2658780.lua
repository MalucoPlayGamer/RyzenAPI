-- Lua provided by RyzenAPI 
-- Game: Wild Angels | Episode 1
addappid(2658780)
addappid(2658781, 1, "099c34193ddaa4fcfd933c0f15df7386047f084162507a18ca68d57843b97f52")
