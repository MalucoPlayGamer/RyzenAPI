-- Lua provided by RyzenAPI 
-- Game: AppID 438920
addappid(438920)
addappid(438921, 1, "eb427e6d9e7b596c09de4dd55b47138ab8f27100515ced0e9fcae2151c15a30c")
addappid(438922, 1, "3b0493f812cb8fc7fd1b38425e9cb8f5b814a24b78150c6907e38fac6bb33716")
