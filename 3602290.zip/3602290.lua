-- Lua provided by RyzenAPI
-- Game: FEMBOY FUTA HOUSE

-- MAIN APPLICATION
addappid(3963390)
addappid(3963400)
addappid(3963410)
addappid(3963420)
addappid(3963430) -- FEMBOY FUTA HOUSE - Hot Extra Costumes
addappid(3963440) -- FEMBOY FUTA HOUSE - Dirty Election
addappid(4131790) -- FEMBOY FUTA HOUSE - Kinky Field Trip
addappid(4669020)
addappid(4834770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602290, 1, "d798833008ca2ae8e3f1850f3e98e2cd6b8b16196c1d4c389badbce9bc0fe50e")
addappid(3602291, 1, "902bbf5f342cf5125a99fb40b231479b9547a9f597d3c915f9c91f72d27b875d") -- (windows)
addappid(3963390, 1, "1d4ff18e36cb5855151cb3e52a33f0717b51a4d7a26d5e72c97de74292263eec")
addappid(3963401, 1, "3ffc7b607cd75d95d3f06937ae1c57fd053812a8fdf613065def5a336aa58e11")
addappid(3963411, 1, "81712a9b58ab7f48580fe1c40a380c9089f22250d34cd694a7e3241599a3a55f")
addappid(3963420, 1, "70f8d950f1e77bd927f59391cd61634caf6bfb04632b34c6b0f7ad5341db11c5")
addappid(4669021, 1, "f0619469526ef0dcf330d1a2e74796ccdbb61cf99344cf4d2c6d9ad1e05457da")
addappid(4834771, 1, "addedec93ff7e4244149bec9a2e9fe2b584da3e8d66a01111e3cf0997c2b2082")

