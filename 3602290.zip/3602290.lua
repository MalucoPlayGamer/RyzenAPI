-- 3602290's Lua and Manifest Created by Hubcap Manifest
-- FEMBOY FUTA HOUSE
-- Created: May 16, 2026 at 07:40:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 7 (1 excluded)

-- MAIN APPLICATION
addappid(3602290, 1, "d798833008ca2ae8e3f1850f3e98e2cd6b8b16196c1d4c389badbce9bc0fe50e") -- FEMBOY FUTA HOUSE
-- MAIN APP DEPOTS
addappid(3602291, 1, "902bbf5f342cf5125a99fb40b231479b9547a9f597d3c915f9c91f72d27b875d") -- Depot 3602291
setManifestid(3602291, "3180391892144815688", 5275846532)
-- DLCS WITH DEDICATED DEPOTS
-- FEMBOY FUTA HOUSE - Digital Artbook (AppID: 3963390)
addappid(3963390)
addappid(3963390, 1, "1d4ff18e36cb5855151cb3e52a33f0717b51a4d7a26d5e72c97de74292263eec") -- FEMBOY FUTA HOUSE - Digital Artbook - Depot 3963390
setManifestid(3963390, "3275917072001749456", 20909889)
-- FEMBOY FUTA HOUSE - Wallpapers Pack (AppID: 3963410)
addappid(3963410)
addappid(3963411, 1, "81712a9b58ab7f48580fe1c40a380c9089f22250d34cd694a7e3241599a3a55f") -- FEMBOY FUTA HOUSE - Wallpapers Pack - Depot 3963411
setManifestid(3963411, "4091445764721133555", 239791891)
-- FEMBOY FUTA HOUSE - Animations Pack (AppID: 3963420)
addappid(3963420)
addappid(3963420, 1, "70f8d950f1e77bd927f59391cd61634caf6bfb04632b34c6b0f7ad5341db11c5") -- FEMBOY FUTA HOUSE - Animations Pack - Depot 3963420
setManifestid(3963420, "81016670117772740", 971794459)
-- FEMBOY FUTA HOUSE - Comics (AppID: 4669020)
addappid(4669020)
addappid(4669021, 1, "f0619469526ef0dcf330d1a2e74796ccdbb61cf99344cf4d2c6d9ad1e05457da") -- FEMBOY FUTA HOUSE - Comics - Depot 4669021
setManifestid(4669021, "835011936454345467", 200628583)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3963430) -- FEMBOY FUTA HOUSE - Hot Extra Costumes
addappid(3963440) -- FEMBOY FUTA HOUSE - Dirty Election
addappid(4131790) -- FEMBOY FUTA HOUSE - Kinky Field Trip
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4669010) -- DLC 4669010 (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3602292) -- Depot 3602292 (empty depot)