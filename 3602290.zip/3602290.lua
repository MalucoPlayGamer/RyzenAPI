-- Lua provided by RyzenAPI
-- Game: FEMBOY FUTA HOUSE

-- MAIN APPLICATION
addappid(3602290)
addappid(3963430)
addappid(3963440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602291, 1, "902bbf5f342cf5125a99fb40b231479b9547a9f597d3c915f9c91f72d27b875d")
addappid(3963390, 0, "1d4ff18e36cb5855151cb3e52a33f0717b51a4d7a26d5e72c97de74292263eec")
addappid(3963411, 0, "81712a9b58ab7f48580fe1c40a380c9089f22250d34cd694a7e3241599a3a55f")
addappid(3963420, 0, "70f8d950f1e77bd927f59391cd61634caf6bfb04632b34c6b0f7ad5341db11c5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3963410)
addappid(4131790)
addappid(4669010)
addappid(4669020)
addappid(4834770)
addappid(5060190)
