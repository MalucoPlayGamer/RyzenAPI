-- Lua provided by RyzenAPI
-- Game: The Ghost of Joe Papp

-- MAIN APPLICATION
addappid(696310)

-- MAIN APP DEPOTS / PACKAGES
addappid(696311, 1, "dde1e14911a45f83e49dab71bb213f19ff080d14374aa3bb42ffab71eecbd935")
addappid(696312, 1, "7b70fa0d3a5c3f449f151114c4e06be4f1891c63f22107070c57e73969a230ab")
addappid(696313, 1, "3aec91b357fb3f69132278cc1afc15cd1e5af191594595d3330fb16071627cfd")

