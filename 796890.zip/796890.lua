-- Lua provided by RyzenAPI 
-- Game: AppID 796890
addappid(796890)
addappid(796891, 1, "8eecdb96c38100f4200b761f39ced3a285a8a59ca4ff29c6235c03c48e6db3f0")
