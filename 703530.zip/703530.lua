-- Lua provided by RyzenAPI
-- Game: 703530

-- MAIN APPLICATION
addappid(703530)
-- Game: addappid(703530)

-- MAIN APP DEPOTS / PACKAGES
addappid(703531, 1, "070dd4968f8253a676da19289c01d41a4153b12f29aef6e6c79b4f61f506ccd7")
