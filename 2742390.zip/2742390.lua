-- Lua provided by RyzenAPI
-- Game: Monster Run: Downfall of the Empire Demo

-- MAIN APPLICATION
addappid(2742390)
-- Game: addappid(2742390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742391, 1, "295d6fe451f12ec3b132e783929ab6168f119e28fe412fb7a71eed8910f9a0a4")
