-- Lua provided by RyzenAPI 
-- Game: Life of a Wizard
addappid(596910)
addappid(596911, 1, "1076d041438df4886d11ffb04b59dbe3e51705657dfffd2a176513f7279bc76f")
