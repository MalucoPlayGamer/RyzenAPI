-- Lua provided by RyzenAPI
-- Game: Game: Life of a Wizard

-- MAIN APPLICATION
addappid(596910)
-- Game: addappid(596910)

-- MAIN APP DEPOTS / PACKAGES
addappid(596911, 1, "1076d041438df4886d11ffb04b59dbe3e51705657dfffd2a176513f7279bc76f")
