-- Lua provided by RyzenAPI
-- Game: Game: AppID 2104090

-- MAIN APPLICATION
addappid(2104090)
-- Game: addappid(2104090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104091, 1, "4f10da91c61a70050d24c77dd77c441ae2443cb5318a667ceb5de23b179d6ec2")
