-- Lua provided by RyzenAPI
-- Game: The Sushi Spinnery

-- MAIN APPLICATION
addappid(1921780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921781, 1, "b59398d42dfb6af1dae10b4f5e7504dc9cd31321adf6389d85ddfda08248b96b")
