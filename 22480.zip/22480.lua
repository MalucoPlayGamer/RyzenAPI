-- Lua provided by RyzenAPI
-- Game: 22480

-- MAIN APPLICATION
addappid(22480)
-- Game: addappid(22480)

-- MAIN APP DEPOTS / PACKAGES
addappid(22481, 1, "1df35ae076aaefb54e330ebfd49a2f1d5bf8757d67cec1a1f0cd83e390a86119")
