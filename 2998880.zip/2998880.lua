-- Lua provided by RyzenAPI
-- Game: Hot & Lewd: Miami

-- MAIN APPLICATION
addappid(2998880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998881, 1, "9ce05364592e2d5e03413ce4dd777eca4473cbc3eb5126626d1b203ad0f07c7c")
