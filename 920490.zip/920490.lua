-- Lua provided by RyzenAPI
-- Game: AppID 920490

-- MAIN APPLICATION
addappid(920490)
-- Game: addappid(920490)

-- MAIN APP DEPOTS / PACKAGES
addappid(920491, 1, "c6800cbcdb088aee9ea0481c759bacc9677de929ceb9752df329cfe9460b32d3")
addappid(920630, 0, "ec10298b3b47f8477e645d509c9d6d093ea8c59a5b2ce74372d669c4c1353250")
