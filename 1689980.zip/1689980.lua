-- Lua provided by RyzenAPI
-- Game: Game: Yummy Mahjong

-- MAIN APPLICATION
addappid(1689980)
-- Game: addappid(1689980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689981, 1, "1086b4d0b0a32a42dbbe2b814f28479da579e3e2769bb66b5c2f5d8673ce2a9d")
