-- Lua provided by RyzenAPI 
-- Game: AppID 3507670
addappid(3507670)
addappid(3507671, 1, "3ecd2ce4509782859b10e3dff5c038e567709ba11569b78a5de73584224b494e")
