-- Lua provided by SkyAPI 
-- Game: Pinball FX Midnight
addappid(2337640)
addappid(2337641, 1, "2615fb4210d766d8335a5be85c8284f95ee109c96c7e78b8ae2bac430bbe50e7")
