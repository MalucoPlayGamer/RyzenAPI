-- Lua provided by RyzenAPI
-- Game: Pinball FX Midnight

-- MAIN APPLICATION
addappid(2337640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337641, 1, "2615fb4210d766d8335a5be85c8284f95ee109c96c7e78b8ae2bac430bbe50e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2660520)
addappid(2660530)
addappid(2660540)
addappid(2660550)
addappid(2815240)
addappid(2987650)
addappid(3229800)
addappid(4321450)
