-- Lua provided by RyzenAPI
-- Game: The Highrise Demo

-- MAIN APPLICATION
addappid(2175130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175131, 1, "2ec0d7504c3a9445019c974da5e25c04f5fd913984a2051ef3f177c0a08d5b3c")

