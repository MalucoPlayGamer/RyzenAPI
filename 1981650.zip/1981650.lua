-- Lua provided by RyzenAPI
-- Game: addappid(1981650)

-- MAIN APPLICATION
addappid(1981650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981651, 1, "b78f4b84dccd3d2b8a28c8e86c90c42a9b53b950f90852ed886c4d443a46a2a1")
