-- Lua provided by RyzenAPI
-- Game: Aliens&Asteroids

-- MAIN APPLICATION
addappid(661030)

-- MAIN APP DEPOTS / PACKAGES
addappid(661031,0,"9318598059654f8ae4a8fb682c27c5192d42eb41364b048c222f6afb7ae07ae8")

