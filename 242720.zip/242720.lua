-- Lua provided by RyzenAPI 
-- Game: AppID 242720
addappid(242720)
addappid(242721, 1, "60a6cfe38874b1357510233685d5997724f731e76d8e439072bb4b80464371b9")
