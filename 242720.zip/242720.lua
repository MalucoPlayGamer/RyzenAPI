-- Lua provided by RyzenAPI
-- Game: GunZ 2: The Second Duel

-- MAIN APPLICATION
addappid(242720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(242721, 1, "60a6cfe38874b1357510233685d5997724f731e76d8e439072bb4b80464371b9")

