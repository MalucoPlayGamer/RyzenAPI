-- Lua provided by SkyAPI 
-- Game: Yondu's Journey
addappid(2318020)
addappid(2318021, 1, "8552a8c8c8936e8e41061f5b9225be941f37513a08524f239b4bbbfe03213788")
