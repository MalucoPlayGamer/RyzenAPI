-- Lua provided by RyzenAPI
-- Game: FEIST

-- MAIN APPLICATION
addappid(327060)

-- MAIN APP DEPOTS / PACKAGES
addappid(327062,0,"7bca01f5079ef9e5a9c31024c9ecab2f7d900ff8aa91b6d935d24e4f361a9ae4")

