-- Lua provided by RyzenAPI
-- Game: First Class Escape: The Train of Thought

-- MAIN APPLICATION
addappid(1738610)
-- Game: addappid(1738610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738611, 1, "e429ae2240d76a7864cc1e706df1748c5c28bb24387e232f33132fc2d3172567")
