-- 2015830's Lua and Manifest Created by Hubcap Manifest
-- Pingo Adventure
-- Created: August 11, 2026 at 14:39:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2015830) -- Pingo Adventure
-- MAIN APP DEPOTS
addappid(2015831, 1, "220e0d34ff25d7fd8a54919edda36dcf8fcaa1c209dc1f9ebb5e71afadfdcfc9") -- Depot 2015831
setManifestid(2015831, "9174763170656035595", 3669716144)
addappid(2015832, 1, "08865da193ae144fee2faf1db8828cc753e36e42d0a0d490204bcbc8ae6f533f") -- Depot 2015832
setManifestid(2015832, "8560926060127169335", 4234709696)