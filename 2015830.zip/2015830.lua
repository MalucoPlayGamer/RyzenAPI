-- Lua provided by RyzenAPI
-- Game: Pingo Adventure

-- MAIN APPLICATION
addappid(2015830) -- Pingo Adventure

-- MAIN APP DEPOTS / PACKAGES
addappid(2015831, 1, "220e0d34ff25d7fd8a54919edda36dcf8fcaa1c209dc1f9ebb5e71afadfdcfc9") -- Depot 2015831
addappid(2015832, 1, "08865da193ae144fee2faf1db8828cc753e36e42d0a0d490204bcbc8ae6f533f") -- Depot 2015832

