-- Lua provided by RyzenAPI
-- Game: Lucky Farm

-- MAIN APPLICATION
addappid(2771180)
-- Game: addappid(2771180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771183,0,"4adf93dcf067259970b36800795b52e55379914913e578680779deb8ba7bf440")
