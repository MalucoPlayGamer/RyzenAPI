-- Lua provided by RyzenAPI
-- Game: Dissolution

-- MAIN APPLICATION
addappid(920470)

-- MAIN APP DEPOTS / PACKAGES
addappid(920471, 1, "7ea71e3ef48b6cc748fa0baf063ee85cefe654863937cee534aeacade5b07631")

