-- Lua provided by RyzenAPI
-- Game: Ultimate ADOM - Caverns of Chaos

-- MAIN APPLICATION
addappid(1266820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266821, 1, "abf03c7018f0696ef305209934d49616203bf478375ff67cd63d82bd7f01c49d")
addappid(1266822, 1, "11393a87c330e22732f3a2e6c882acf68070db08025b62a40ea2fd8a9c765698")
addappid(1266823, 1, "22d40991627b298d4228ada29a414cb02f864f606b467ea8fcd92974941ea092")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
