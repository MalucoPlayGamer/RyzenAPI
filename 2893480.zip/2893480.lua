-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Notorious B.I.G. - "Hypnotize"

-- MAIN APPLICATION
addappid(2893480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893480,0,"67e9ee729741e2e5c60ab8c6e96b617409f4a74502f5bcf4518e43ef9d9e9293")
