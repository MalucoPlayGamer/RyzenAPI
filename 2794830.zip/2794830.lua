-- Lua provided by RyzenAPI
-- Game: Cinnabunny

-- MAIN APPLICATION
addappid(2794830)
-- Game: addappid(2794830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794831, 1, "67535234c22f3cfe512a95e9fa560480021d8db47c1eb095329bbc2baf093c45")
