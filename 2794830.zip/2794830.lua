-- Lua provided by SkyAPI 
-- Game: Cinnabunny
addappid(2794830)
addappid(2794831, 1, "67535234c22f3cfe512a95e9fa560480021d8db47c1eb095329bbc2baf093c45")
