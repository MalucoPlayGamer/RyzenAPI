-- Lua provided by RyzenAPI
-- Game: Cinnabunny

-- MAIN APPLICATION
addappid(2794830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794831, 1, "67535234c22f3cfe512a95e9fa560480021d8db47c1eb095329bbc2baf093c45")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
