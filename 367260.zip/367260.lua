-- Lua provided by SkyAPI 
-- Game: Dwarven Brawl Bros
addappid(367260)
addappid(367261, 1, "be07248b9dd80d10c0b17cd41823607898214e5ce57d5e7469a0fbf746ce138d")
addappid(367900)
