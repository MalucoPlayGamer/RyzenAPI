-- Lua provided by RyzenAPI
-- Game: 18Hell:Lost

-- MAIN APPLICATION
addappid(2773230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773232,0,"5a63ea2ee809ae9135b018a223200ad4fec73ed4ad49702fedebd2665ea1d400")
