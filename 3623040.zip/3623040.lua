-- Lua provided by RyzenAPI
-- Game: addappid(3623040)

-- MAIN APPLICATION
addappid(3623040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3623042,0,"702ea6075ac68ab1c53b3eb2c6f52b0503e0a2d6a4b45ef45a5b6d697522ff13")
