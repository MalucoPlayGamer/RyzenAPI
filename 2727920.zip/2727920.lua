-- Lua provided by RyzenAPI
-- Game: 100% Orange Juice - Character Song Pack: Star Baker Breaker

-- MAIN APPLICATION
addappid(2727920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737020,0,"1edb1a41f4ee5174176a09df4866f5f14e0fe5d2f541fd9d8e216658c7e66233")
addappid(2737021,0,"26a95eca87f78b38d1b7b6d669da514459b6b765946c5ef79e411938d1d743e8")
