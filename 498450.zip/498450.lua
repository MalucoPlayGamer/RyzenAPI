-- Lua provided by RyzenAPI
-- Game: A Week of Circus Terror

-- MAIN APPLICATION
addappid(498450)

-- MAIN APP DEPOTS / PACKAGES
addappid(498451, 1, "57a13de6d7f13d5f07cd7161fdab6c21c7fa204120d4c98873c361a5a6a14e22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
