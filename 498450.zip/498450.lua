-- Lua provided by RyzenAPI 
-- Game: A Week of Circus Terror
addappid(498450)
addappid(498451, 1, "57a13de6d7f13d5f07cd7161fdab6c21c7fa204120d4c98873c361a5a6a14e22")
