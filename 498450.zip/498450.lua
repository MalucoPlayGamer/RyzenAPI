-- Lua provided by RyzenAPI
-- Game: 498450

-- MAIN APPLICATION
addappid(498450)
-- Game: addappid(498450)

-- MAIN APP DEPOTS / PACKAGES
addappid(498451, 1, "57a13de6d7f13d5f07cd7161fdab6c21c7fa204120d4c98873c361a5a6a14e22")
