-- Lua provided by RyzenAPI
-- Game: Pâquerette Down the Bunburrows Demo

-- MAIN APPLICATION
addappid(1640020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640021, 1, "6e87e46d741d2c42b404f575d0aea803511cf24ec41cf20871f2f453a297dbed")
