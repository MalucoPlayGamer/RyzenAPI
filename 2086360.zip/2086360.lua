-- Lua provided by RyzenAPI
-- Game: 2086360

-- MAIN APPLICATION
addappid(2086360)
-- Game: addappid(2086360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086361, 1, "66fdde9d794d89ad6259ed6bc8489b70ce1b263689d25f7d37530b5a75c13f2e")
