-- Lua provided by SkyAPI 
-- Game: Double Dragon Advance
addappid(2086360)
addappid(2086361, 1, "66fdde9d794d89ad6259ed6bc8489b70ce1b263689d25f7d37530b5a75c13f2e")
