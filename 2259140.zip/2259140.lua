-- Lua provided by RyzenAPI
-- Game: Brutal Strike Playtest

-- MAIN APPLICATION
addappid(2259140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259141, 1, "c784cf8ded0ba6cd7258a290624f5543cc407e889ef809e6105bbb9b242613ac")
