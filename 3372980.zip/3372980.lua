-- Lua provided by RyzenAPI
-- Game: Game: Tower Wizard

-- MAIN APPLICATION
addappid(3372980)
-- Game: addappid(3372980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372981, 1, "96854c520e39fd615815985aa82022d8d382f5c390742938e086ddb4abba21c4")
