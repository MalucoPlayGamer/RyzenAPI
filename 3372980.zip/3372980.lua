-- Lua provided by RyzenAPI 
-- Game: Tower Wizard
addappid(3372980)
addappid(3372981, 1, "96854c520e39fd615815985aa82022d8d382f5c390742938e086ddb4abba21c4")
