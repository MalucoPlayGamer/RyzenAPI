-- Lua provided by RyzenAPI
-- Game: For Your Tranquility

-- MAIN APPLICATION
addappid(2183320)
-- Game: addappid(2183320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183321, 1, "360b426795971c25240bb56068593efb5343403a873a68c016b5a7c1a1f7c9e9")
