-- Lua provided by RyzenAPI
-- Game: 2824170

-- MAIN APPLICATION
addappid(2824170)
-- Game: addappid(2824170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824171, 1, "90e5023a85bc9eaf4c9418c02e6268e8a6d02d15bcb5f8b58ba75f1299d7304c")
