-- Lua provided by RyzenAPI
-- Game: Game: Disco Samurai Demo

-- MAIN APPLICATION
addappid(2775190)
-- Game: addappid(2775190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775191, 1, "619dffa150516a7ee081a568e5682f1fa881c88805c454c0063f6b239b0e7321")
