-- Lua provided by RyzenAPI
-- Game: Game: Super Hexagon

-- MAIN APPLICATION
addappid(221640)
addappid(228988)
-- Game: addappid(221640)

-- MAIN APP DEPOTS / PACKAGES
addappid(221641, 1, "8ffc476f2f7d1d5261a3b12125ffb217d76090278a1fed5945344816ab4d7bb1")
addappid(221642, 1, "73c567c342c35e5ae5151e0ca0e978d5a078c2095a16994bfceb6e0b3d100486")
addappid(221643, 1, "890f03b2a76e12192828bcffe118d5f1487791cc86f5a59a89ec7d6ce76f8b44")
