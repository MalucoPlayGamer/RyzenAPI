-- Lua provided by RyzenAPI
-- Game: Game: Unicycle Pizza Time!

-- MAIN APPLICATION
addappid(3138570)
-- Game: addappid(3138570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138571, 1, "630f53001020ffa65ca3ac8d4b3da57d269e578b1fc75a82297d8ffadf910e42")
