-- Lua provided by RyzenAPI
-- Game: 3008550

-- MAIN APPLICATION
addappid(3008550)
-- Game: addappid(3008550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008551, 1, "4cff8a2dc7f58ce52adf4ee8151d479816bb24739f37647a16d16cbe4a1d5d4a")
