-- Lua provided by RyzenAPI
-- Game: Anno 2205

-- MAIN APPLICATION
addappid(375910)
addappid(415100)
addappid(415101)
addappid(415102)
addappid(415103)
addappid(415104)
addappid(415105)
addappid(415106)
addappid(415107)
addappid(415110)
addappid(415111)
addappid(415112)
addappid(415113)
addappid(415120)
addappid(416480)
addappid(441720)
addappid(446920)
addappid(500370)
addappid(526040)

-- MAIN APP DEPOTS / PACKAGES
addappid(375911, 1, "182272756cd7d2e9435c26d5373f062cc7c9ae607dff99b08d842b0065e08caa")
addappid(375912, 1, "d6b71f3cacc4aa39f645de996e49e223c635c189fe29f8c65632c701000d3967")
addappid(375913, 1, "e322baeeda8e801dbfa05a9c1e01ddbb0d54d4b8babaebd7f47c782611efb289")
addappid(375914, 1, "a3651529c460d814d5d3e31e8210e8223d0bb152d4987af688e813dbeae6cd70")
addappid(375915, 1, "088426768d4072cb8c5e7d9db4197e33aed42c55d18e830c4f212b1a878aeef6")
addappid(375916, 1, "016fd13196fc7120beddf81f9c7fded71c810925dec849b8123b9f9c7828bb63")
addappid(375917, 1, "ca7b2ffe751b151c8277f400d7f48922bebc8b57c0903ae0d2e503b78bab41ef")
addappid(375918, 1, "44456fe896b55b58774bde906cf3f7896d85341fd8c0cd8ed9b4989ac3d0da9e")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

