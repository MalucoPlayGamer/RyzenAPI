-- Lua provided by RyzenAPI
-- Game: Playing God

-- MAIN APPLICATION
addappid(1358930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1358931, 1, "8c6221436d8d128f914eddd902e6cb9db47d43798aa26a1b0509c79ddbbf17cf")

