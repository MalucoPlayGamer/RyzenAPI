-- Lua provided by RyzenAPI
-- Game: 1358930

-- MAIN APPLICATION
addappid(1358930)
-- Game: addappid(1358930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358931, 1, "8c6221436d8d128f914eddd902e6cb9db47d43798aa26a1b0509c79ddbbf17cf")
