-- Lua provided by RyzenAPI
-- Game: 3251830

-- MAIN APPLICATION
addappid(3251830)
-- Game: addappid(3251830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251831, 1, "1c42303b75eac4f9507d2a0e8d35744c4be93b3afd874b8586337ce31627791b")
