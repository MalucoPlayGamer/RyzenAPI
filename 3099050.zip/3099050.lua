-- Lua provided by RyzenAPI
-- Game: 3099050

-- MAIN APPLICATION
addappid(3099050)
-- Game: addappid(3099050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099051, 1, "28fd9261089a0320d7167a2e2b1fdd485083bff737bb91ac4a355d166807fde0")
