-- Lua provided by RyzenAPI 
-- Game: AppID 3099050
addappid(3099050)
addappid(3099051, 1, "28fd9261089a0320d7167a2e2b1fdd485083bff737bb91ac4a355d166807fde0")
