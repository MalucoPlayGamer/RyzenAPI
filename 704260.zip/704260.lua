-- Lua provided by RyzenAPI
-- Game: Las Vegas International  [KLAS] airport for Tower!3D Pro

-- MAIN APPLICATION
addappid(704260)

-- MAIN APP DEPOTS / PACKAGES
addappid(704260,0,"2e19f8968317f3ca1f5df520c95bc2b10b690fec3c3e615ca035ab1e70d8aaf7")

