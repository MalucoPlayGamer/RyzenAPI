-- Lua provided by RyzenAPI
-- Game: AppID 1229890

-- MAIN APPLICATION
addappid(1229890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229891, 1, "a1f06aa89568a963f833f075177045e11ba0bdde744a8e9d4a54f25a4623bbe7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2688450)
