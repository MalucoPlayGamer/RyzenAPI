-- Lua provided by RyzenAPI
-- Game: DESORDRE : A Puzzle Game Adventure

-- MAIN APPLICATION
addappid(2097490)
-- Game: addappid(2097490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097491, 1, "6ac4e1782fca5407078215dd7bda2ac39b06cce8748b8fb52dc48ce34b7542fd")
