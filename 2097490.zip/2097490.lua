-- Lua provided by RyzenAPI
-- Game: DESORDRE : A Puzzle Game Adventure

-- MAIN APPLICATION
addappid(2097490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097491, 1, "6ac4e1782fca5407078215dd7bda2ac39b06cce8748b8fb52dc48ce34b7542fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
