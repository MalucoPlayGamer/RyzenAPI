-- Lua provided by RyzenAPI
-- Game: Vivat Slovakia

-- MAIN APPLICATION
addappid(2132690)
-- Game: addappid(2132690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132691, 1, "65089430108460a99f1873b6dd45308d6f6363e72b61179582cb7562e11af745")
