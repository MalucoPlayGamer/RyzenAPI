-- Lua provided by RyzenAPI
-- Game: Yarimono

-- MAIN APPLICATION
addappid(2696050)
addappid(3593650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696055,0,"25043be4f82f396d723a71516561347bda08810502afdc20dea5cbe5b75a2bc8")
addappid(3171570,0,"006677b4d7eb93ef97bd8ade42a0c84efe2ca2a7983f406b1f79b4bcfeabe666")
addappid(3593651,0,"cdac6a93224f65139edcce3b7fb21a294db38b14f5cf1b5e5f96687a45f35f0b")

