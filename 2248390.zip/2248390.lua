-- Lua provided by RyzenAPI
-- Game: 2248390

-- MAIN APPLICATION
addappid(2248390)
-- Game: addappid(2248390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248391, 1, "5cb1d67355d60647e7ae19e8cf54ae409aa853563254f8f38dcadf8fb7af71b6")
