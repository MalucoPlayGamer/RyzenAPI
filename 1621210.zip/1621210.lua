-- Lua provided by RyzenAPI
-- Game: Nemithia

-- MAIN APPLICATION
addappid(1621210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621211, 1, "e6b21c222e5ce9af05eee87eadc79762568f90213ed67464096a13d7cd3fa6b4")
addappid(1621212, 1, "6cccfc8a789cd08b86fae59329d6c5f3ff5f6a1c4165f80c2e504d3df67f1ffe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
