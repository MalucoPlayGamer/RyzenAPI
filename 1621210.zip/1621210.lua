-- Lua provided by RyzenAPI
-- Game: addappid(1621210)

-- MAIN APPLICATION
addappid(1621210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621211, 1, "e6b21c222e5ce9af05eee87eadc79762568f90213ed67464096a13d7cd3fa6b4")
addappid(1621212, 1, "6cccfc8a789cd08b86fae59329d6c5f3ff5f6a1c4165f80c2e504d3df67f1ffe")
