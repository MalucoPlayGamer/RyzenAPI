-- Lua provided by RyzenAPI
-- Game: Mommy

-- MAIN APPLICATION
addappid(1204220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204221, 1, "48e1bb8640a9f05ba91e8ea048d669f1ff0eabb805fb02a4fb5a57ee50eeffa7")
addappid(1233090, 0, "cb1de15bda531688b2608a6954a9052d89bbc7fb352cc3ac97898b0edad6348a")

