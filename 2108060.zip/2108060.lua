-- Lua provided by RyzenAPI 
-- Game: The Ramsey
addappid(2108060)
addappid(2108061, 1, "70e502e32c9e4bc3da5b398d42b8f8ea7bfb4bc552dd849e92d0aa9a321e3fff")
