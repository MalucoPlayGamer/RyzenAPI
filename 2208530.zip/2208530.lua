-- Lua provided by RyzenAPI 
-- Game: Alchemia Story
addappid(2208530)
addappid(2208531, 1, "2d07a32d96c9755e2a880c75ae3c6e865d29d5b1173ef6665e7cf25104ced3fb")
