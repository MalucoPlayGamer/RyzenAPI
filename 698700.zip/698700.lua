-- Lua provided by RyzenAPI
-- Game: Game: Rise of the Third Power

-- MAIN APPLICATION
addappid(698700)
-- Game: addappid(698700)

-- MAIN APP DEPOTS / PACKAGES
addappid(698701, 1, "023012bfaba0d66e20f641fd7efd919cdb7a27242a95b30a87304d8182fea8b1")
