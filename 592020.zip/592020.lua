-- Lua provided by RyzenAPI
-- Game: SmuggleCraft

-- MAIN APPLICATION
addappid(592020)
addappid(637910)

-- MAIN APP DEPOTS / PACKAGES
addappid(592023,0,"2592d03d1f4ef9529ca857748f846701e825b0c9fbd10f47dea8c43065052ae8")
addappid(592025,0,"5fc65904cb56b6d6ca77eab5bcd2d16cd8277bde5f9370da031374af0ff7454c")
addappid(592028,0,"213ae8d39aaadbc1529ebb8a565105ff74e3366dfe0790d57470edbecd3d2a66")

