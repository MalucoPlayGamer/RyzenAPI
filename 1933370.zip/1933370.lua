-- Lua provided by RyzenAPI
-- Game: Mark of the Deep

-- MAIN APPLICATION
addappid(1933370)
addappid(4374400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1933371, 1, "1d846a28687fda6a4b1d471c6a2cbe5e68e6be29938a1a119f84ec5988dba0e3")

