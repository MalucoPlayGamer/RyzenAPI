-- Lua provided by RyzenAPI
-- Game: Mark of the Deep

-- MAIN APPLICATION
addappid(1933370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933371, 1, "1d846a28687fda6a4b1d471c6a2cbe5e68e6be29938a1a119f84ec5988dba0e3")
