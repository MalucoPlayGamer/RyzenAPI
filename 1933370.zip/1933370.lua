-- Lua provided by SkyAPI 
-- Game: Mark of the Deep
addappid(1933370)
addappid(1933371, 1, "1d846a28687fda6a4b1d471c6a2cbe5e68e6be29938a1a119f84ec5988dba0e3")
