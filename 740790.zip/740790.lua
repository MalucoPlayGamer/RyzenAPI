-- Lua provided by RyzenAPI
-- Game: Goldmine

-- MAIN APPLICATION
addappid(740790)
addappid(740793)
addappid(740794)

-- MAIN APP DEPOTS / PACKAGES
addappid(740792,0,"31262b8f0b48f74b7d73e7d18be62d6407436f704ab5b7f62e7f644c1f575130")
addtoken(740790,8691906323340740305)

