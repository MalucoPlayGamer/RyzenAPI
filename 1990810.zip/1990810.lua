-- Lua provided by RyzenAPI
-- Game: Game: AppID 1990810

-- MAIN APPLICATION
addappid(1990810)
-- Game: addappid(1990810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990811, 1, "df4af2f1c395bd591a022905cd990846b6b5e18d04c214dbf180fc0f6594d490")
