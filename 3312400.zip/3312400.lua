-- Lua provided by RyzenAPI
-- Game: Lust o’ Heaven

-- MAIN APPLICATION
addappid(3312400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3312401,0,"109a0aee34e66885c856fe78d01b0ddcc672512af866b89e9a088fdbfcfd5ce1")

