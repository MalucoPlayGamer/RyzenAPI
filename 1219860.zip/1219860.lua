-- Lua provided by RyzenAPI
-- Game: Monster Girls You-ki Chan

-- MAIN APPLICATION
addappid(1219860)
-- Game: addappid(1219860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219861, 1, "75fca48f9bffa71c5a30be9c3cca96d38b72e1a60ef6972b3c56930c29299298")
