-- Lua provided by RyzenAPI 
-- Game: Lennod Jump Game
addappid(2349850)
addappid(2349851, 1, "034e7920da536e86a73c753156aac93431f067b05745cf76ee5f28fffbb6f3a0")
