-- Lua provided by RyzenAPI
-- Game: Lennod Jump Game

-- MAIN APPLICATION
addappid(2349850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2349851, 1, "034e7920da536e86a73c753156aac93431f067b05745cf76ee5f28fffbb6f3a0")

