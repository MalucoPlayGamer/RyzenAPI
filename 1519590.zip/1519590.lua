-- Lua provided by RyzenAPI
-- Game: Sentimental Trickster: Yaoi BL Gay Visual Novel

-- MAIN APPLICATION
addappid(1519590)
-- Game: addappid(1519590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519591, 1, "04508425fd7c0999fff2bc268b47db0fcd753a140b690d0a785e6cc21fc135d1")
