-- Lua provided by SkyAPI 
-- Game: Outcast - A New Beginning Demo
addappid(2775330)
addappid(2775331, 1, "3ba072ac50bf85ee591156e9f751841efe410d9331210076a7133a3614379709")
