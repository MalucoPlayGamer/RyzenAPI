-- Lua provided by RyzenAPI
-- Game: Titan Revenge

-- MAIN APPLICATION
addappid(2697890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697891, 1, "002bf37168a8c6dee1f3182ca62f7bb6399fd49f2ed81d538f13b899b02e1cc2")
