-- Lua provided by RyzenAPI
-- Game: Form Fitting

-- MAIN APPLICATION
addappid(2365640)
-- Game: addappid(2365640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365641, 1, "e8e41cf786331e094463435b69064f734f1e3dfcf4c3e98cf847c109f525b8e9")
