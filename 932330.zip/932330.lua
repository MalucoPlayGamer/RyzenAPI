-- Lua provided by RyzenAPI
-- Game: AppID 932330

-- MAIN APPLICATION
addappid(932330)

-- MAIN APP DEPOTS / PACKAGES
addappid(932331, 1, "bee2c5d7114b78b9ac600fe93b450b7b7f49611f606ea7e91ea75b458be82633")

