-- Lua provided by RyzenAPI
-- Game: 1226070

-- MAIN APPLICATION
addappid(1226070)
-- Game: addappid(1226070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226071, 1, "3d4bc56ca37cf9a543638a1755d10cab4c7c0f0b1a19c808342b4e3016f35e41")
