-- Lua provided by RyzenAPI
-- Game: addappid(753060)

-- MAIN APPLICATION
addappid(753060)

-- MAIN APP DEPOTS / PACKAGES
addappid(753061, 1, "2c8d200ebbf16fabb37d915977ab7043abd14f631e1e4abae817c8b0030efb82")
