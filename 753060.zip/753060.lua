-- Lua provided by RyzenAPI
-- Game: Lucky Night VR

-- MAIN APPLICATION
addappid(753060)

-- MAIN APP DEPOTS / PACKAGES
addappid(753061, 1, "2c8d200ebbf16fabb37d915977ab7043abd14f631e1e4abae817c8b0030efb82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
