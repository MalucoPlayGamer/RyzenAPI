-- Lua provided by RyzenAPI
-- Game: Game: The Bright Star Of Seraph-Katis-

-- MAIN APPLICATION
addappid(2841200)
-- Game: addappid(2841200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841201, 1, "ba00d867877e52f51fdab486b43d7590fb5f5b93e4452f0d57b662a933d83fa7")
