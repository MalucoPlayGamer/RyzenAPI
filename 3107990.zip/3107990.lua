-- Lua provided by RyzenAPI
-- Game: Convoluted Incident: Pinch me

-- MAIN APPLICATION
addappid(3107990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107991, 1, "0830861ddb7bef684256ea5d835f58c63daff7f851fbc9f183b568f01d5a9074")

