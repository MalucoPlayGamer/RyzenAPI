-- Lua provided by RyzenAPI
-- Game: 1809770

-- MAIN APPLICATION
addappid(1809770)
-- Game: addappid(1809770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809771, 1, "6aa3c924af9c5cbdf91f03700cd07987bca19a05d26387d5d3f3c6824be89b37")
