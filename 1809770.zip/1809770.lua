-- Lua provided by RyzenAPI
-- Game: Lust for Darkness VR: M Edition

-- MAIN APPLICATION
addappid(1809770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809771, 1, "6aa3c924af9c5cbdf91f03700cd07987bca19a05d26387d5d3f3c6824be89b37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
