-- Lua provided by RyzenAPI 
-- Game: Lust for Darkness VR: M Edition
addappid(1809770)
addappid(1809771, 1, "6aa3c924af9c5cbdf91f03700cd07987bca19a05d26387d5d3f3c6824be89b37")
