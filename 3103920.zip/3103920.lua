-- Lua provided by RyzenAPI
-- Game: 暖雪 Warm Snow Soundtrack

-- MAIN APPLICATION
addappid(3103920)
-- Game: addappid(3103920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103921, 1, "262d55135ec30ece5d5a40aea542e08860544a172174e1fa3fb83f5b5f280865")
addappid(3103922, 1, "3d789642a8d9be48d90d3e01dde8a11252e004366b92ffe75bb4b8ca9fc4935c")
