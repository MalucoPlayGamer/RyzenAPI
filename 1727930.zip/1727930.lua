-- Lua provided by RyzenAPI 
-- Game: Gorge
addappid(1727930)
addappid(1727931, 1, "2959e58e6dcaadc423544c95ff83d84f2104def0052590220ea9042f05cebb7a")
addappid(1734090)
