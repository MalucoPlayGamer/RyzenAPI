-- Lua provided by RyzenAPI
-- Game: addappid(968800)

-- MAIN APPLICATION
addappid(968800)

-- MAIN APP DEPOTS / PACKAGES
addappid(968801, 1, "6fcd43ea26eefed3f8ae89f26eb93a958f61668473a54a80afdbddd6d66f0185")
