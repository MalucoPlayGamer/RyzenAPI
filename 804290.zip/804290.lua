-- Lua provided by RyzenAPI 
-- Game: Training aim
addappid(804290)
addappid(804291, 1, "3424e68140415c24c2c7ca9a5100ce0b2e0b911546d537b95583113701d8022c")
addappid(804299, 1, "1942b86ae823f8977c8aaabd9e882385b313a0945dcb85a255ecabed480d6b5b")
