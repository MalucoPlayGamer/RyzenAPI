-- Lua provided by RyzenAPI
-- Game: PC FISH: Taskbar Aquarium

-- MAIN APPLICATION
addappid(4842670)
