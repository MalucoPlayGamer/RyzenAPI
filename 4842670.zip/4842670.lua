-- Lua provided by RyzenAPI
-- Game: PC FISH: Taskbar Aquarium

-- MAIN APPLICATION
addappid(4842670)
addappid(5005980)
addappid(5005990)
addappid(5111630)

