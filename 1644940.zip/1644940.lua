-- Lua provided by SkyAPI 
-- Game: Loddlenaut
addappid(1644940)
addappid(1644941, 1, "464fd291bfa8822d7f22ffd27c95057fc1147f61e3042d6364d0f997dcd89c8c")
addappid(1644942, 1, "f57f4ef8861cf1107b4449ba280dc77ad487d2f35e15e5c5849ef07c6cc47b17")
