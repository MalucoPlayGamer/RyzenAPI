-- Lua provided by RyzenAPI
-- Game: 1845230

-- MAIN APPLICATION
addappid(1845230)
-- Game: addappid(1845230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845231, 1, "0a95bae1bbb16eee92c7e187111ef0fc422f5901b682d2904099dd87f1ecfdba")
addappid(1845232, 1, "aa20040166eaf58d0f441fa212452b7dd4cfbd754ae4af8daf4f9a230faf1281")
addappid(1845233, 1, "9c5ff9c4810495298b399c1523f2dbe9f561ada5033ea66d67d403b5ad56443e")
