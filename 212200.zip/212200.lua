-- Lua provided by RyzenAPI 
-- Game: Mabinogi
addappid(212200)
addappid(212201, 1, "a18ac0318ad0eff5c9052bb8e32d8d54757ddac953c7d10186934b3c36427ba3")
