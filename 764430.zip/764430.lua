-- Lua provided by RyzenAPI
-- Game: 764430

-- MAIN APPLICATION
addappid(764430)
-- Game: addappid(764430)

-- MAIN APP DEPOTS / PACKAGES
addappid(764431, 1, "ecb7e1a2dba9cfe4141eab3d7e8e29413bf48b697790c8b392b0f4f0b7ed8e96")
addappid(764432, 1, "3d851696db9a71f8598814dd787ce4f347b42c265acde3d0642fe589a0575db2")
