-- Lua provided by RyzenAPI
-- Game: Tower Realm

-- MAIN APPLICATION
addappid(4550370) -- Tower Realm
addappid(4613820) -- Tower Realm The Saga Of Tower Chapter 2
addappid(4613830) -- Tower Realm Rhythmic Cultivation Chapter 1

-- MAIN APP DEPOTS / PACKAGES
addappid(4550371, 1, "cc5d8bf21b776f362537855e98abd39eb94960dff5777b1ee40ca4172006fbbf") -- Depot 4550371

