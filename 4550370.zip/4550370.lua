-- 4550370's Lua and Manifest Created by Hubcap Manifest
-- Tower Realm
-- Created: August 12, 2026 at 04:33:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(4550370) -- Tower Realm
-- MAIN APP DEPOTS
addappid(4550371, 1, "cc5d8bf21b776f362537855e98abd39eb94960dff5777b1ee40ca4172006fbbf") -- Depot 4550371
setManifestid(4550371, "4129578020906284149", 757746384)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4613820) -- Tower Realm The Saga Of Tower Chapter 2
addappid(4613830) -- Tower Realm Rhythmic Cultivation Chapter 1