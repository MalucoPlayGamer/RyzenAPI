-- 4992700's Lua and Manifest Created by Hubcap Manifest
-- TRAIN 9
-- Created: August 12, 2026 at 22:54:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4992700) -- TRAIN 9
-- MAIN APP DEPOTS
addappid(4992701, 1, "a3ba9991d916726a75b62e539a1c6f3f748abe08a6d1f3ad09a98f77948d2234") -- Depot 4992701
setManifestid(4992701, "5278553388204127846", 699652806)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)