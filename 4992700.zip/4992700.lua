-- Lua provided by RyzenAPI
-- Game: TRAIN 9

-- MAIN APPLICATION
addappid(4992700) -- TRAIN 9

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4992701, 1, "a3ba9991d916726a75b62e539a1c6f3f748abe08a6d1f3ad09a98f77948d2234") -- Depot 4992701

