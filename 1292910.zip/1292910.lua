-- Lua provided by RyzenAPI
-- Game: Accident: The Pilot

-- MAIN APPLICATION
addappid(1292910)
-- Game: addappid(1292910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292911, 1, "867a4e269afc60cd61cbf91a9ffd173bb4719ab47f119e432c03e1b5e4b54a8b")
