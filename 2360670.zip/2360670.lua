-- Lua provided by RyzenAPI
-- Game: addappid(2360670)

-- MAIN APPLICATION
addappid(2360670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360671, 1, "ba66b2cc4cf21270281b4049212c5c3d8324bd6c55878b122e4b046e888af66e")
