-- Lua provided by RyzenAPI
-- Game: Wolfenstein II: The Freedom Chronicles - Episode 1

-- MAIN APPLICATION
addappid(624620)
-- Game: addappid(624620)

-- MAIN APP DEPOTS / PACKAGES
addappid(762750,0,"2ed466db2835036b650efcff72a34931a88fca7ff32c2990317e9a2e435a5936")
