-- Lua provided by RyzenAPI
-- Game: ONE PIECE: PIRATE WARRIORS 4

-- MAIN APPLICATION
addappid(1130840)
addappid(1203040)
addappid(1203041)
addappid(1203042)
addappid(1203043) -- ONE PIECE PIRATE WARRIORS 4 - Month 1 Bundle Bonus
addappid(1203044) -- ONE PIECE PIRATE WARRIORS 4 - Charlotte Katakuri Early Unlock
addappid(1203045) -- ONE PIECE PIRATE WARRIORS 4 - Character Pass
addappid(2449140)
addappid(2449170)
addappid(2449171)
addappid(2449250)
addappid(2452120)
addappid(2458610) -- ONE PIECE PIRATE WARRIORS 4 Character Pass 2
addappid(2469230) -- ONE PIECE PIRATE WARRIORS 4 Additional Episodes Pack
addappid(2469232)
addappid(2617310)
addappid(2617330)
addappid(3798480)
addappid(3798490) -- ONE PIECE PIRATE WARRIORS 4 Character Pass 3
addappid(3846080)
addappid(3846090)
-- addappid(2469231) -- Depot 2469231 (empty depot)
-- addappid(2617320) -- Depot 2617320 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1089090, 1, "710228b049046b0de02d331ad48aae083520027713d32afd7053768d212532d1") -- ONE PIECE: PIRATE WARRIORS 4
addappid(1089091, 1, "49964ca34e77b3aee8889132d8de8da22521d34a3cdfbfda9c74bdfb995a6bd3") -- B-Bound Content
addappid(1130840, 1, "139786567849d65b72a9e95a65a33c440aab4f87e84f16c5967eece9f002c31a") -- ONE PIECE PIRATE WARRIORS 4 Whole Cake Island Pack - B-Bound - DLC1 (1130840) デポ
addappid(1203040, 1, "23721734da64a0e0eed9e25288becfacbd86526db03272187e504b5a454ce809") -- ONE PIECE PIRATE WARRIORS 4 The Worst Generation Pack - B-Bound - DLC2 (1203040) Depot
addappid(1203041, 1, "bf69c2c5c04fd1c592fc1d9ff6100309b370feb381996dfc7586d5a0fbc5cc3e") -- ONE PIECE PIRATE WARRIORS 4 Land of Wano Pack - B-Bound - DLC3 (1203041) Depot
addappid(1203042, 1, "daa2e5d518b63ac6b8878c5ea4c540165ffdc4f7dfa078bfc99e165da8803a65") -- ONE PIECE PIRATE WARRIORS 4 Anime Song Pack - B-Bound - DLC4 (1203042) Depot
addappid(2449140, 1, "a5b90a998cb9fd64fa11da5687004b175f17d545d9b5b2d68e8631c6bc2a841d") -- ONE PIECE PIRATE WARRIORS 4 The Battle of Onigashima Pack - Depot 2449140
addappid(2449170, 1, "676e606a6905bec5553299076d2e2cec4d11ccf9cd6f669e7c3d3277e732441d") -- ONE PIECE PIRATE WARRIORS 4 One Piece Film Red Pack - Depot 2449170
addappid(2449171, 1, "045e54225fe6c77786bfcd2e7a99f704190372cc286e260d2ec38e4a597cebd0") -- ONE PIECE PIRATE WARRIORS 4 Legend Dawn Pack - Depot 2449171
addappid(2449250, 1, "cb4ad443ede1955f0390dfd14006088a10213c6a97269acc9454b933b2395d30") -- ONE PIECE PIRATE WARRIORS 4 Yamatos Grand Tour Logbook  Soul Map 1 - Depot 2449250
addappid(2452120, 1, "b54bcf33357770b5d13a1e145d50d48aaa4dfed4be53b630f92cb1e4864838be") -- ONE PIECE PIRATE WARRIORS 4 Onigashima Battle Law Costume - Depot 2452120
addappid(2469232, 1, "4db2e09ac0239d465a9b16bbc8a751c66cb387980ce813c30b1773a0ef26c58c") -- ONE PIECE PIRATE WARRIORS 4 One Piece Film Red Anime Song Pack - Depot 2469232
addappid(2617310, 1, "8c03ebaf59f386bc358b416d055f137dce85c2baf4603c07a179b3d6c669f96e") -- ONE PIECE PIRATE WARRIORS 4 Kobys Combat Chronicle  Soul Map 2 - Depot 2617310
addappid(2617330, 1, "a5a15512c615494b0ac80cd28d8aaf459e3b5ea8c2b8071caac2ade8b61d6b45") -- ONE PIECE PIRATE WARRIORS 4 Path to the King of the Pirates  Soul Map 3 - Depot 2617330
addappid(3798480, 1, "d2ef4e6b851e5ac5cbb5538730ca14e8dd37e1eebe81f4debf9b0b71a356bad5") -- ONE PIECE PIRATE WARRIORS 4 Shanks Additional Special Move Divine Departure - Depot 3798480
addappid(3846080, 1, "bf9e74c7282f3322f89ecf01ab0a507ae6db747f612e7753813d5afcbedb2922") -- ONE PIECE PIRATE WARRIORS 4 Character Pack 7 Future Island Egghead Pack - Depot 3846080
addappid(3846090, 1, "c1c033f3a5b121486e5dd1a33e9157b7b3859dba5372c4dbeb1627cbd6d9e9e4") -- ONE PIECE PIRATE WARRIORS 4 Character Pack 8 Special Selection Pack - Depot 3846090
addtoken(1203043, "316931438837035431")
addtoken(1203044, "16499482579822565625")
addtoken(1203045, "4729094100341584419")

