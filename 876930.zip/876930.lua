-- Lua provided by RyzenAPI
-- Game: Fancy Skiing 2: Online

-- MAIN APPLICATION
addappid(876930)
addappid(876931)
addappid(876933)

-- MAIN APP DEPOTS / PACKAGES
addappid(876932,0,"9c4e026bd92933a0cd9a9bb047a7d4bcf9706fda10ba35c8060f19eea50d53b2")

