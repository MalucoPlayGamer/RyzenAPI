-- Lua provided by RyzenAPI
-- Game: The Prison Experiment

-- MAIN APPLICATION
addappid(857240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(857241, 1, "ed00a5d7a20ef9af4cd287560a4697b130e3ffe36b63041445d9f84e74196772")
