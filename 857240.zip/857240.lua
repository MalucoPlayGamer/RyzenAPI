-- Lua provided by RyzenAPI
-- Game: Game: AppID 857240

-- MAIN APPLICATION
addappid(857240)
-- Game: addappid(857240)

-- MAIN APP DEPOTS / PACKAGES
addappid(857241, 1, "ed00a5d7a20ef9af4cd287560a4697b130e3ffe36b63041445d9f84e74196772")
