-- Lua provided by RyzenAPI
-- Game: Game: Ikenfell

-- MAIN APPLICATION
addappid(854940)
-- Game: addappid(854940)

-- MAIN APP DEPOTS / PACKAGES
addappid(854941, 1, "06aa4f1d162e979c09789fa6809c004c3b27a3c0b2616523957003bd3b7ec3ee")
addappid(854942, 1, "e7c29ec9bb65330607f02112ee20f63bb34c815d7b41d6405702413d34442cfb")
