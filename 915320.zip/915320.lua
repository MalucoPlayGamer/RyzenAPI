-- Lua provided by RyzenAPI
-- Game: Pixel Strike 3D

-- MAIN APPLICATION
addappid(915320)

