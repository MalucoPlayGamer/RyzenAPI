-- Lua provided by RyzenAPI
-- Game: 534010

-- MAIN APPLICATION
addappid(228983)
addappid(534010)
addappid(534011)
-- Game: addappid(534010)

-- MAIN APP DEPOTS / PACKAGES
addappid(534012,0,"64743cef518cc9354ab1b27d0ffeab15957ac56be93faf10be64e8d08dd6226e")
addappid(534013,0,"7eb865a05adaa93dac79156837240cabd3a1d124526d84746c28175b1f601809")
