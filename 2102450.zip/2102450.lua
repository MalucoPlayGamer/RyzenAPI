-- Lua provided by RyzenAPI
-- Game: Enotria: The Last Song

-- MAIN APPLICATION
addappid(2102450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102451, 1, "4ff61b91c2226debba14e316ae7bcd8ceaf0742273e88455dcc564ff892f3d61")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
