-- Lua provided by RyzenAPI
-- Game: addappid(2102450)

-- MAIN APPLICATION
addappid(2102450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102451, 1, "4ff61b91c2226debba14e316ae7bcd8ceaf0742273e88455dcc564ff892f3d61")
