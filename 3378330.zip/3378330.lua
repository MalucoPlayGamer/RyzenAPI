-- Lua provided by RyzenAPI
-- Game: Rekindled Trails

-- MAIN APPLICATION
addappid(3378330)
-- Game: addappid(3378330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3378332,0,"936c4c9b401d39f058a91ee4808573bdfb1af3ee1a188f9789ff9833915f3281")
