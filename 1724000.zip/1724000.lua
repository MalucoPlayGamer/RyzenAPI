-- Lua provided by RyzenAPI
-- Game: Game: Time Lock VR 2

-- MAIN APPLICATION
addappid(1724000)
-- Game: addappid(1724000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724001, 1, "f2c85b3b19d1098f600291e7982cdb18c0267de43ce90bd28db653a912814f67")
