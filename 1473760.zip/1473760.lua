-- Lua provided by RyzenAPI
-- Game: Beyond the Storm

-- MAIN APPLICATION
addappid(1473760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473761, 1, "70a0ce07e2ede64764f241e97c4814e714d78eae62261bcf59853bb89c7f4b14")
