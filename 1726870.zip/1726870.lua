-- Lua provided by RyzenAPI
-- Game: Nebraska

-- MAIN APPLICATION
addappid(1726870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726871, 1, "41772c39615dacd0e9324eb15cd80ffee80090b080f9aada6adbda00c257300d")
