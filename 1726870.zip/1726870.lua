-- Lua provided by RyzenAPI
-- Game: Nebraska

-- MAIN APPLICATION
addappid(1726870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726871, 1, "41772c39615dacd0e9324eb15cd80ffee80090b080f9aada6adbda00c257300d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
