-- Lua provided by RyzenAPI
-- Game: The Other Side

-- MAIN APPLICATION
addappid(2764750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764751, 1, "113da5665350affbeacc447a5fa24af4497a26a4a316a4984b60d4bf90286252")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
