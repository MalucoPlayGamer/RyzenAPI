-- Lua provided by SkyAPI 
-- Game: The Other Side
addappid(2764750)
addappid(2764751, 1, "113da5665350affbeacc447a5fa24af4497a26a4a316a4984b60d4bf90286252")
