-- Lua provided by RyzenAPI
-- Game: 2764750

-- MAIN APPLICATION
addappid(2764750)
-- Game: addappid(2764750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764751, 1, "113da5665350affbeacc447a5fa24af4497a26a4a316a4984b60d4bf90286252")
