-- Lua provided by RyzenAPI
-- Game: addappid(997030)

-- MAIN APPLICATION
addappid(997030)

-- MAIN APP DEPOTS / PACKAGES
addappid(997031, 1, "076242024cd5b7fffc41ce3e1ba4b4a6cfa6733ac746df0ac2b7f964328281ce")
