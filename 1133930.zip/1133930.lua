-- Lua provided by RyzenAPI
-- Game: Forgotten Hill Disillusion

-- MAIN APPLICATION
addappid(1133930)
-- Game: addappid(1133930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133932,0,"8bf38b5ecff4f0891018bc2507e7fabc8985b75e436539fc06ada0d96ca6c2e7")
