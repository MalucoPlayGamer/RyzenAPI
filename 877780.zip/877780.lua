-- Lua provided by RyzenAPI
-- Game: Puzzles for smart: Cats

-- MAIN APPLICATION
addappid(877780)
-- Game: addappid(877780)

-- MAIN APP DEPOTS / PACKAGES
addappid(877781, 1, "6d4b8071859c0f6cc5518a5faeacdf6898b0f4cf602f4b3903ff474d79d11f50")
