-- Lua provided by RyzenAPI
-- Game: Short Snow | Cold Survival Game

-- MAIN APPLICATION
addappid(3054440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054441, 1, "ebf4804f30552083c811eb2963acc9d753e3f3b05f69f0c8fc28293c577b7600")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4583520)
addappid(4589120)
