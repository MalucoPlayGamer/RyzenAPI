-- Lua provided by RyzenAPI
-- Game: PURE

-- MAIN APPLICATION
addappid(322600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(322601, 1, "3afaa5bb55c29997215ae2b39cd997ce4cd56430009dafd6f028c1c1af2751d4")
addappid(322602, 1, "9b5175f2d09ee066cb45b37f26f40c44b6623f800fec583eff673db4b424c70f")
