-- Lua provided by RyzenAPI
-- Game: addappid(1272860)

-- MAIN APPLICATION
addappid(1272860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272861, 1, "cf4375dd31de365e8a933c66afe33e20fcba6eb580638d316bc583abef012ab2")
