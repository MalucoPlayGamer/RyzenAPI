-- Lua provided by RyzenAPI
-- Game: Satellite Rush

-- MAIN APPLICATION
addappid(429350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(429351, 1, "9cfde126a17c9e4b1be6e57f91b9d1d917a71e2bfde9db19adbc5c60088792be")
addappid(429352, 1, "64da5227b0c80e7683aebb2603376fcdc003b87647a8cbf8abd89eb63ddcc98a")
addappid(429353, 1, "9347f7a412b8f1f1982129857e36b199722663002da59dfb2f5448379009327b")

