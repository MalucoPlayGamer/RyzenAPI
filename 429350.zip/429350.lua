-- Lua provided by RyzenAPI
-- Game: Game: AppID 429350

-- MAIN APPLICATION
addappid(429350)
-- Game: addappid(429350)

-- MAIN APP DEPOTS / PACKAGES
addappid(429351, 1, "9cfde126a17c9e4b1be6e57f91b9d1d917a71e2bfde9db19adbc5c60088792be")
addappid(429352, 1, "64da5227b0c80e7683aebb2603376fcdc003b87647a8cbf8abd89eb63ddcc98a")
addappid(429353, 1, "9347f7a412b8f1f1982129857e36b199722663002da59dfb2f5448379009327b")
