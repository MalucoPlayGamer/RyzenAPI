-- Lua provided by RyzenAPI
-- Game: vivid/stasis

-- MAIN APPLICATION
addappid(2093940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093941, 1, "d46d8baaf351d33099c4dbe17e03bcaba5aca7d5af33fa6c7500c817c7acac23")
