-- Lua provided by RyzenAPI
-- Game: Game: Paper Bride 5 Two Lifetimes

-- MAIN APPLICATION
addappid(2600570)
-- Game: addappid(2600570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600571, 1, "7b191170bf3922606ed4b964f02b54d89ef18f8a9d85a9cc22d522adb18681af")
addappid(2600572, 1, "686e9be23af10ea9242959390553bf0cc9c588b10d1af489c9732cca8de3e7f7")
addappid(2600573, 1, "e593d48577943cc1f8d2d46996754d6040382bfdd4e921e9b1b9d4bfa221fc9e")
addappid(2620390, 0, "b5fafffda5c6d47e17ee2837fa96bf1d9e199fe56d7b3d429bc2645fc27b5c6a")
addappid(2620410, 0, "fb48e290465565a286ace8ac47c10f5cf335a426d4b8e83ae6c353b7e0bb6b47")
