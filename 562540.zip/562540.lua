-- Lua provided by RyzenAPI
-- Game: Game: AppID 562540

-- MAIN APPLICATION
addappid(562540)
-- Game: addappid(562540)

-- MAIN APP DEPOTS / PACKAGES
addappid(562541, 1, "a1c16120660832a15f479678bdab8e8f8b6dea5696e8698457002b8e5f464490")
