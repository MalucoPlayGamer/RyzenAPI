-- Lua provided by RyzenAPI
-- Game: 3561510

-- MAIN APPLICATION
addappid(3561510)
-- Game: addappid(3561510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561511, 1, "d5915a04ff7a4da342d9b861d4a1854b54838ac90779c9245ff1f4051bbcecbf")
