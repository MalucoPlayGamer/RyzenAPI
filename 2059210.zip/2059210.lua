-- Lua provided by RyzenAPI
-- Game: Game: DragonLoop

-- MAIN APPLICATION
addappid(2059210)
-- Game: addappid(2059210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059211, 1, "18e8a52ae739db338ab4d00204372e403a7965a7e1122e5e7a1b247b023807ed")
