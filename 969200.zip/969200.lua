-- Lua provided by RyzenAPI
-- Game: 969200

-- MAIN APPLICATION
addappid(969200)
-- Game: addappid(969200)

-- MAIN APP DEPOTS / PACKAGES
addappid(969201, 1, "04d60afc369628cc2fe13374ce1d87f427ef90310901a833c43f9d76cc89ae23")
