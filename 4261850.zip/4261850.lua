-- 4261850's Lua and Manifest Created by Hubcap Manifest
-- 掌舵人 BIZ Helmsman
-- Created: August 09, 2026 at 09:47:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(4261850) -- 掌舵人 BIZ Helmsman
-- MAIN APP DEPOTS
addappid(4261851, 1, "776071e0c190b1b4e10b082081e8a12914efe259bb3d279ba4542340d8d9117f") -- Depot 4261851
setManifestid(4261851, "3242584588399883382", 3546895743)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)