-- Lua provided by RyzenAPI
-- Game: The 18th Floor

-- MAIN APPLICATION
addappid(855320)

-- MAIN APP DEPOTS / PACKAGES
addappid(855321, 1, "0919d68fab014edf68e4eff74fa2a263492ac39585de08a2dad4a537fec6d436")
