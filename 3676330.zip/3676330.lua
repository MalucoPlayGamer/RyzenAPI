-- Lua provided by RyzenAPI
-- Game: NoFlash

-- MAIN APPLICATION
addappid(3676330)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3737570)
