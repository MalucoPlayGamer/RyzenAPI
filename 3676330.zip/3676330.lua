-- Lua provided by RyzenAPI
-- Game: NoFlash

-- MAIN APPLICATION
addappid(3676330)
addappid(3737570)

