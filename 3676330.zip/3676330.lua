-- Lua provided by RyzenAPI
-- Game: NoFlash

-- MAIN APPLICATION
addappid(3676330)
