-- Lua provided by SkyAPI 
-- Game: Dungeon Girl
addappid(1614250)
addappid(1614251, 1, "f6944ae83ed51de4d6704874e0925fbb895b638ff80aa530d5c56df9e1f60dc1")
