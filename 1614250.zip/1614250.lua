-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Girl

-- MAIN APPLICATION
addappid(1614250)
-- Game: addappid(1614250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614251, 1, "f6944ae83ed51de4d6704874e0925fbb895b638ff80aa530d5c56df9e1f60dc1")
