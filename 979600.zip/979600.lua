-- Lua provided by SkyAPI 
-- Game: AppID 979600
addappid(979600)
addappid(979601, 1, "ef58c51ad39127c238966b5d6bf365b985eb7888311d326632b36bbca6e15ade")
