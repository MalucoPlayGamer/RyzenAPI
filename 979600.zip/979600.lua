-- Lua provided by RyzenAPI
-- Game: addappid(979600)

-- MAIN APPLICATION
addappid(979600)

-- MAIN APP DEPOTS / PACKAGES
addappid(979601, 1, "ef58c51ad39127c238966b5d6bf365b985eb7888311d326632b36bbca6e15ade")
