-- Lua provided by RyzenAPI
-- Game: 2140900

-- MAIN APPLICATION
addappid(2140900)
-- Game: addappid(2140900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140901, 1, "4db766c8b3e05e0d0d2c073caea434cc7728e567adfd63e610955fa9dc4866e7")
