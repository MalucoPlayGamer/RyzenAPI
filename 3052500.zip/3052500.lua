-- Lua provided by RyzenAPI
-- Game: ColdRidge

-- MAIN APPLICATION
addappid(3052500)
-- Game: addappid(3052500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052501, 1, "0d39bf1cd067bc92ba4c2520be5d90aaa6ae9570141f067d008ef3b4ad2422f7")
