-- Lua provided by RyzenAPI
-- Game: Undefined Game Pack

-- MAIN APPLICATION
addappid(2957890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957891, 1, "2eb42fb81830246cbe2712dde4feb7703317157e3a7dbd943d2f684bb03580fb")
