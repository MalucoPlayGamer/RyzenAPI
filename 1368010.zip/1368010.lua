-- Lua provided by RyzenAPI
-- Game: Game: AppID 1368010

-- MAIN APPLICATION
addappid(1368010)
-- Game: addappid(1368010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368011, 1, "bf979df2d347fc8c141990a74a53a9bb993a5fb2cb7f4973b9fe1797610fa3b1")
