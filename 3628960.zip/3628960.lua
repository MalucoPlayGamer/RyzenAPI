-- Lua provided by RyzenAPI
-- Game: Game: Miscrits: World of Creatures

-- MAIN APPLICATION
addappid(3628960)
-- Game: addappid(3628960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3628961, 1, "f10ed5c194953aeca74402dee7d719b0d603f179260dc8754b597624b4a77c8c")
addappid(3628962, 1, "b7b4852742e80b89588031dd3cf884f2530d9e7c27ab68479f2856f5d8640a8c")
addappid(3628963, 1, "fb38cdebcf71bd2531861dec6e8ef6ed2a5c6e5a93e6e2f22d79a8065707a181")
