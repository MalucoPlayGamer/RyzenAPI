-- Lua provided by SkyAPI 
-- Game: LEGO® Bricktales Soundtrack
addappid(2147170)
addappid(2147171, 1, "23a684f5f5d86b3fa0487c9f2ccf7d951bacae8d3b7d4b3a053d92492afc9d85")
