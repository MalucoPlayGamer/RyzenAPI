-- Lua provided by RyzenAPI
-- Game: Game: AppID 1054840

-- MAIN APPLICATION
addappid(1054840)
-- Game: addappid(1054840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054841, 1, "541a37e58fb378e599828534b912657e6c31b26df6dbaade2e7537cdecdbe411")
