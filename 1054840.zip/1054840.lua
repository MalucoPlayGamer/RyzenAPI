-- Lua provided by SkyAPI 
-- Game: AppID 1054840
addappid(1054840)
addappid(1054841, 1, "541a37e58fb378e599828534b912657e6c31b26df6dbaade2e7537cdecdbe411")
