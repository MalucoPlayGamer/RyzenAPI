-- Lua provided by RyzenAPI
-- Game: 1880640

-- MAIN APPLICATION
addappid(1880640)
-- Game: addappid(1880640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880641, 1, "56d1886f57004fca0bc87bf54020d041f6d4675cffffc09f57631abf1f8e9550")
