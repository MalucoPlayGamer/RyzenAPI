-- Lua provided by SkyAPI 
-- Game: A Butterfly's Dream
addappid(1880640)
addappid(1880641, 1, "56d1886f57004fca0bc87bf54020d041f6d4675cffffc09f57631abf1f8e9550")
