-- Lua provided by RyzenAPI
-- Game: Grim

-- MAIN APPLICATION
addappid(1403940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403941, 1, "e9c4b83b15205559a241dad59af21a44c5030b2a08c23f26b8118aa57f7e4957")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
