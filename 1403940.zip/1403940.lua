-- Lua provided by RyzenAPI
-- Game: Game: Grim

-- MAIN APPLICATION
addappid(1403940)
-- Game: addappid(1403940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403941, 1, "e9c4b83b15205559a241dad59af21a44c5030b2a08c23f26b8118aa57f7e4957")
