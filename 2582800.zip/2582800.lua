-- Lua provided by RyzenAPI
-- Game: 2582800

-- MAIN APPLICATION
addappid(2582800)
-- Game: addappid(2582800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582803,0,"cbcdb71552a6f2e75e753661b4ce57f2347f0fe9726e2f0ed825bb79ce2c2c02")
