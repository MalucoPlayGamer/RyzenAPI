-- Lua provided by RyzenAPI
-- Game: AppID 1135380

-- MAIN APPLICATION
addappid(1135380)
-- Game: addappid(1135380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135381, 1, "27c029607d6bacab3f188d448332a9babd6255d070f270fd4f12c6578cc85a21")
