-- Lua provided by RyzenAPI 
-- Game: AppID 1135380
addappid(1135380)
addappid(1135381, 1, "27c029607d6bacab3f188d448332a9babd6255d070f270fd4f12c6578cc85a21")
