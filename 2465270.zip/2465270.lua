-- Lua provided by RyzenAPI
-- Game: Game: AppID 2465270

-- MAIN APPLICATION
addappid(2465270)
-- Game: addappid(2465270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465271, 1, "43447a02cef624e3c800d052eab26674d46cec25919438c3c8c92d75d2d38257")
