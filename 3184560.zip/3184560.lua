-- Lua provided by RyzenAPI
-- Game: addappid(3184560)

-- MAIN APPLICATION
addappid(3184560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3184561, 1, "4f657e71a2fb871fccaaf4a7e5b46f651ae4dd04bad8c3a0bcf77c18e449e453")
