-- Lua provided by RyzenAPI
-- Game: addappid(1744390)

-- MAIN APPLICATION
addappid(1744390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744391, 1, "69f40e87126cafe5f0b94f5f58256d7d02e7e8c422ebd977c939d77ebf581315")
