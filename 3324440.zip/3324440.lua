-- Lua provided by RyzenAPI
-- Game: AppID 3324440

-- MAIN APPLICATION
addappid(3324440)
-- Game: addappid(3324440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3324441, 1, "19fd9762189bd47d24d391a9c149ee465c870d87604d118457e97f158d83186d")
addappid(3324442, 1, "c5ff1676835b1fef054b9698c7cf6871dd31decc4cb4b40358afa0abceadd9f0")
