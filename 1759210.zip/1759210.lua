-- Lua provided by RyzenAPI
-- Game: Greed Is Bad

-- MAIN APPLICATION
addappid(1759210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759211, 1, "eb0f18abdd8886f716b41c5a616480158063a4d7b6521b2a64602ec4fa2ff284")

