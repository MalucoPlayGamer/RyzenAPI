-- Lua provided by RyzenAPI
-- Game: Project Terminus VR

-- MAIN APPLICATION
addappid(1437280)
-- Game: addappid(1437280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437281, 1, "dda65ee780417904f089d2855c930f02f7fc3b68b84efc1fa6ffb0125f22328e")
