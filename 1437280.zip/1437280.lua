-- Lua provided by SkyAPI 
-- Game: Project Terminus VR
addappid(1437280)
addappid(1437281, 1, "dda65ee780417904f089d2855c930f02f7fc3b68b84efc1fa6ffb0125f22328e")
