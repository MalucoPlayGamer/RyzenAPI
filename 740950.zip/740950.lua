-- Lua provided by SkyAPI 
-- Game: OverKill
addappid(740950)
addappid(740951, 1, "0091e71dc5b4165cfb3ca57129aae241d3aeeb0467a77dcefadbbe2b1d78fe0b")
