-- Lua provided by RyzenAPI
-- Game: Hero's Warband Demo

-- MAIN APPLICATION
addappid(3087170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087171, 1, "3ed322b8bdfe1f46dc5da2be23122385f78dfb217d5f0edca8ca7ba171eb03a1")

