-- Lua provided by RyzenAPI
-- Game: 3087170

-- MAIN APPLICATION
addappid(3087170)
-- Game: addappid(3087170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087171, 1, "3ed322b8bdfe1f46dc5da2be23122385f78dfb217d5f0edca8ca7ba171eb03a1")
