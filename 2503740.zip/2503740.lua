-- Lua provided by RyzenAPI
-- Game: Storm Striker

-- MAIN APPLICATION
addappid(2503740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2503744,0,"d38e2c7ad44465fa4a2731b2e29abb622931323af9f26e2a1597038db3de0ec6")

