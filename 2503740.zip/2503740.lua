-- Lua provided by RyzenAPI
-- Game: Storm Striker

-- MAIN APPLICATION
addappid(2503740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503744,0,"d38e2c7ad44465fa4a2731b2e29abb622931323af9f26e2a1597038db3de0ec6")

