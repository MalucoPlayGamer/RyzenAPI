-- Lua provided by RyzenAPI
-- Game: addappid(461170)

-- MAIN APPLICATION
addappid(461170)

-- MAIN APP DEPOTS / PACKAGES
addappid(461171, 1, "e65e6065c17253bdb4cf6240c625d85ed011bc1e746801e732aa3ee1a145f179")
addappid(461173, 1, "2557f958f77f1e5e35a1cbe27e68ceb595ac59dd6e468bf23af246de4343b953")
