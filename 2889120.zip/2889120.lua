-- Lua provided by SkyAPI 
-- Game: Absolute Fear -AOONI- / 最恐 -青鬼-
addappid(2889120)
addappid(2889121, 1, "4d0c1133c3056c07ac1bdbe6e2388e661261eac16513c7d70e7c4fcbbc688f67")
