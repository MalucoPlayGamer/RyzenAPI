-- Lua provided by RyzenAPI
-- Game: 2889120

-- MAIN APPLICATION
addappid(2889120)
-- Game: addappid(2889120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889121, 1, "4d0c1133c3056c07ac1bdbe6e2388e661261eac16513c7d70e7c4fcbbc688f67")
