-- Lua provided by RyzenAPI
-- Game: Realm of the Mad God Exalt

-- MAIN APPLICATION
addappid(200210)

-- MAIN APP DEPOTS / PACKAGES
addappid(200211, 1, "9ae303368ff69745334984bde698e4e833d11fab5988a5e68be8f2fbe40f53eb")
addappid(200212, 1, "b650ff7755b7e5a88f6300810462e10ed91afae5d3846a62d33906699591db08")
