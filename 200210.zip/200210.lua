-- Lua provided by RyzenAPI
-- Game: Realm of the Mad God Exalt

-- MAIN APPLICATION
addappid(200210)

-- MAIN APP DEPOTS / PACKAGES
addappid(200211, 1, "9ae303368ff69745334984bde698e4e833d11fab5988a5e68be8f2fbe40f53eb")
addappid(200212, 1, "b650ff7755b7e5a88f6300810462e10ed91afae5d3846a62d33906699591db08")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(270740)
addappid(270741)
addappid(270742)
addappid(270743)
addappid(270744)
addappid(270745)
addappid(294180)
addappid(308160)
addappid(308161)
addappid(308162)
addappid(308163)
addappid(308164)
addappid(547760)
addappid(548380)
addappid(556880)
addappid(1390710)
addappid(3306740)
addappid(3306750)
addappid(3306760)
addappid(3306770)
