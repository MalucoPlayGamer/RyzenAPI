-- Lua provided by RyzenAPI
-- Game: Once Human Demo

-- MAIN APPLICATION
addappid(2958310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958311, 1, "f3d8ad3f6b0446e992cf8b6fed4d28ebfeaa4bfc71f1bcc1ae0f0761d6f8f173")
