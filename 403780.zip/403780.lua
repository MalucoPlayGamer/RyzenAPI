-- Lua provided by RyzenAPI
-- Game: AppID 403780

-- MAIN APPLICATION
addappid(403780)

-- MAIN APP DEPOTS / PACKAGES
addappid(403781, 1, "741a690e1c850e457f51a9620125061a8fbf3016b6e7e589d04bcfa97ee044ab")
addappid(403782, 1, "a45bb8f87ccecd41f470f4c1987d9c4fba0cc93dbe3f74f1c7aec5ea52e3291e")
addappid(403783, 1, "32c45abfe5e712a4793e81f7a500c96ad01d3ef68bc4f9a7f9acb97a7bb67393")
