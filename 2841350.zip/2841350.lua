-- Lua provided by RyzenAPI
-- Game: Age of Water: The First Voyage

-- MAIN APPLICATION
addappid(2841350)
-- Game: addappid(2841350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841351, 1, "8648febb32402d3753605b9a4afa55ea972a97afd03c9fcbdbe67e76f6c11d3e")
