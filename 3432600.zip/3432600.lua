-- Lua provided by RyzenAPI
-- Game: BDSM Oasis - interactive physics simulation

-- MAIN APPLICATION
addappid(3432600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432601, 1, "de15edfde8f805bf22347f5e677530a1becf00728e8933e95b7391e1483b69f7")

