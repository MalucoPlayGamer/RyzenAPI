-- Lua provided by SkyAPI 
-- Game: Heard of the Story?
addappid(1881940)
addappid(1881941, 1, "abc8ea52fe9c9d6d2db8ee7ef6f205427c4ccff0078e54fa39bb1ea0dda9eeec")
