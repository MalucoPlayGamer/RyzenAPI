-- Lua provided by RyzenAPI
-- Game: Game: Heard of the Story?

-- MAIN APPLICATION
addappid(1881940)
-- Game: addappid(1881940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881941, 1, "abc8ea52fe9c9d6d2db8ee7ef6f205427c4ccff0078e54fa39bb1ea0dda9eeec")
