-- Lua provided by RyzenAPI
-- Game: Daigaku Gurashi

-- MAIN APPLICATION
addappid(2118850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118851, 1, "56c31950d10d0b80c83f026ae4915e170bff57cd143644aed9f7d77f3e870b3a")
