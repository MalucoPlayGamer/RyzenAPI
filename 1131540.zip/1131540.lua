-- Lua provided by RyzenAPI
-- Game: My Light In The Dark

-- MAIN APPLICATION
addappid(1131540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131541, 1, "5ac0a9666e6ad57ee9881dfc960167c05cc408bdd9405175a7162eec97e4132b")

