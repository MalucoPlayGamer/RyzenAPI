-- Lua provided by RyzenAPI
-- Game: Fox Spirit: A Two-Tailed Adventure

-- MAIN APPLICATION
addappid(1324420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324421, 1, "9446c3884370568209b63ea2df8c0a764f8d096f940fb57e56fa667d63fe2f5d")

