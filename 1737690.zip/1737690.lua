-- Lua provided by RyzenAPI
-- Game: Yacht Dice

-- MAIN APPLICATION
addappid(1737690)
-- Game: addappid(1737690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737691, 1, "f2988a076c40cf87ace412fc1898280a011fafd0d59d14bd74763a7da3fc3ea9")
