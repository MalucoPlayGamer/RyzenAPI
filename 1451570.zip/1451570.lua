-- Lua provided by RyzenAPI
-- Game: Game: Cosmic Magus

-- MAIN APPLICATION
addappid(1451570)
-- Game: addappid(1451570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451571, 1, "af4fb13ba2778e964f78b31ee296d0425782a8a61286a2762fdb66e2a0244ef1")
