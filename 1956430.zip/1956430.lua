-- Lua provided by RyzenAPI
-- Game: Terminal Velocity™: Boosted Edition

-- MAIN APPLICATION
addappid(1956430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1956431, 1, "1cc6e2a7dd13f5dab102a119953dbf65a0839b976122ed039e138ad5145ded4b")

