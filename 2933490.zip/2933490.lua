-- Lua provided by RyzenAPI
-- Game: Game: Nine Floors

-- MAIN APPLICATION
addappid(2933490)
-- Game: addappid(2933490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933491, 1, "3f5180d86f048c5fd6fac5925e83dcc31849dc88c27bdc49a8bd91666f9eb3c3")
addappid(2933492, 1, "eebf60d18a92791f27416fe1fca7601fb354f3d69b2819a1e5b980b83b1333be")
