-- Lua provided by RyzenAPI
-- Game: NEAR DEADline

-- MAIN APPLICATION
addappid(1347140)
