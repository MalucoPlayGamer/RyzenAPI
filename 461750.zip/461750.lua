-- Lua provided by RyzenAPI
-- Game: Game: AppID 461750

-- MAIN APPLICATION
addappid(461750)
-- Game: addappid(461750)

-- MAIN APP DEPOTS / PACKAGES
addappid(461751, 1, "4bbf01652ac31bb1e44bd0da83aeb730847106fad0054f0ca06e9c5b80ffd262")
