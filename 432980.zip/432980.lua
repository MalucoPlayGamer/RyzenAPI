-- Lua provided by RyzenAPI
-- Game: INVERSUS Deluxe

-- MAIN APPLICATION
addappid(432980)

-- MAIN APP DEPOTS / PACKAGES
addappid(432981, 1, "88b98458f2cb97e91f4005e51fef52203722d987754329fbb200e8ea525266bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
