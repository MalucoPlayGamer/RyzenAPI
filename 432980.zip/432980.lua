-- Lua provided by SkyAPI 
-- Game: INVERSUS Deluxe
addappid(432980)
addappid(432981, 1, "88b98458f2cb97e91f4005e51fef52203722d987754329fbb200e8ea525266bb")
