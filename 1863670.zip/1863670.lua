-- Lua provided by RyzenAPI
-- Game: Game: Mystwood Manor

-- MAIN APPLICATION
addappid(1863670)
-- Game: addappid(1863670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863671, 1, "48f0861f50d491d54e04a73a1c18681e5ac8ab1f8d2f7e5ee3e8be1e3d6de26d")
addappid(1863672, 1, "5a3d6efc6d8f5e6692f2f7f3ceb6658c43853455ffbf7ed757838b49d7ed9361")
addappid(2170070, 0, "074c968debe442b6e36b663082160a3a772eac1dbb79a66dab92fce4fd916533")
