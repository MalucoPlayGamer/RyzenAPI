-- Lua provided by RyzenAPI
-- Game: addappid(798380)

-- MAIN APPLICATION
addappid(798380)

-- MAIN APP DEPOTS / PACKAGES
addappid(798381, 1, "d05ede7192a7c5a6d20f186dcaa2c952481ef360a71c09222322761cd7e17a7f")
