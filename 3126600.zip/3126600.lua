-- Lua provided by RyzenAPI
-- Game: Game: The Depths of Despair Demo

-- MAIN APPLICATION
addappid(3126600)
-- Game: addappid(3126600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126601, 1, "601b9f2ca8c05c44c754f07769573c6ca6ed68177f43f0e68a24841ce711a5c9")
