-- Lua provided by RyzenAPI
-- Game: Undomestic

-- MAIN APPLICATION
addappid(2484430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484431, 1, "d86ae699a4308c8341c6000e249864ec8ecb6a3ddb3ba61a70e0bbf20c7f9d9b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
