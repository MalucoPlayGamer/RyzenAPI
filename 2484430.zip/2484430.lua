-- Lua provided by RyzenAPI
-- Game: Undomestic

-- MAIN APPLICATION
addappid(2484430)
-- Game: addappid(2484430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484431, 1, "d86ae699a4308c8341c6000e249864ec8ecb6a3ddb3ba61a70e0bbf20c7f9d9b")
