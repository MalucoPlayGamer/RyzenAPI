-- 4870970's Lua and Manifest Created by Hubcap Manifest
-- Rustbound
-- Created: July 21, 2026 at 06:25:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4870970) -- Rustbound
-- MAIN APP DEPOTS
addappid(4870971, 1, "6ff8d337f3b3dd63adba3a24e99dcb1e412553805e5b720a081dd06171e59dbb") -- Depot 4870971
setManifestid(4870971, "4110143464563485129", 1831833403)