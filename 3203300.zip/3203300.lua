-- Lua provided by RyzenAPI
-- Game: 3203300

-- MAIN APPLICATION
addappid(3203300)
-- Game: addappid(3203300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3203301, 1, "3afcdb72fa0843e78c55563bd7f874c6c7aa64fcfedfdd9cbc537acb035f09b3")
