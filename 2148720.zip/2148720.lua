-- Lua provided by RyzenAPI
-- Game: Cruise Control Mode On!

-- MAIN APPLICATION
addappid(2148720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148721, 1, "35fc2a5a61dbd387adcf44433986559be44defc66a9b558f7ba8a4950607051c")

