-- Lua provided by RyzenAPI
-- Game: ASTROSWARM

-- MAIN APPLICATION
addappid(2664720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664721, 1, "cc4df76df2424a55607af46b883b015a1dabfd1bc030575d108d6bcaafbd8e4c")

