-- Lua provided by RyzenAPI
-- Game: ASTROSWARM

-- MAIN APPLICATION
addappid(2664720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664721, 1, "cc4df76df2424a55607af46b883b015a1dabfd1bc030575d108d6bcaafbd8e4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
