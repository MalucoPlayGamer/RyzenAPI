-- Lua provided by RyzenAPI 
-- Game: AppID 3187720
addappid(3187720)
addappid(3187721, 1, "52450de6f45084788309514f75797ccc333975a70b3c8b7024290bb1b1940346")
