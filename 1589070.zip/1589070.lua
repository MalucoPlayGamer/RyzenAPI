-- Lua provided by SkyAPI 
-- Game: VR Bukkake
addappid(1589070)
addappid(1589071, 1, "d6f6a6429f3028ea1521ad09c0187eb2346e4d9d4f739ca40a875efc42e98a1f")
