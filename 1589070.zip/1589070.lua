-- Lua provided by RyzenAPI
-- Game: 1589070

-- MAIN APPLICATION
addappid(1589070)
-- Game: addappid(1589070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589071, 1, "d6f6a6429f3028ea1521ad09c0187eb2346e4d9d4f739ca40a875efc42e98a1f")
