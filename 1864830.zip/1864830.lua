-- Lua provided by RyzenAPI
-- Game: Emblem of Valor

-- MAIN APPLICATION
addappid(1864830)
-- Game: addappid(1864830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864831, 1, "8dc4b5a4232bb39b83db77957a0bcb35d759fdb99329dd32ca65848864cf6c5f")
