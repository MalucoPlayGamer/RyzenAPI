-- Lua provided by RyzenAPI
-- Game: 629400

-- MAIN APPLICATION
addappid(629400)
-- Game: addappid(629400)

-- MAIN APP DEPOTS / PACKAGES
addappid(629401, 1, "d450e0503fff30720578a870a74299337faf21a7d0471541664a0f7c95cf4ba0")
