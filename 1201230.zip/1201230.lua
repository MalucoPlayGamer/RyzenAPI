-- Lua provided by RyzenAPI
-- Game: 1201230

-- MAIN APPLICATION
addappid(1201230)
-- Game: addappid(1201230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201231, 1, "b2ce4abeded7a446c478d1a949abc7982249874043d61c350dd730218df6643a")
