-- Lua provided by RyzenAPI
-- Game: Wind Rider

-- MAIN APPLICATION
addappid(2874290)
