-- Lua provided by SkyAPI 
-- Game: The Troop
addappid(1363740)
addappid(1363741, 1, "223a4e8b4d22145b7c6c2eef9c6bef5b527c4ec5e7f14c4bcd348bb656e0e766")
