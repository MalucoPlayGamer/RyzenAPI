-- Lua provided by RyzenAPI
-- Game: Game: AppID 372330

-- MAIN APPLICATION
addappid(372330)
-- Game: addappid(372330)

-- MAIN APP DEPOTS / PACKAGES
addappid(372331, 1, "dfe9f46f58d89a8a7dda65b7f5e3ce3161cf8a9882a92ff2c67cb59c1bf2d84e")
