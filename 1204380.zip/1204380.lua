-- Lua provided by RyzenAPI
-- Game: AppID 1204380

-- MAIN APPLICATION
addappid(1204380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204381, 1, "28fea30e740fe53fc44225f770c65eedc9bb0296160c75d0208ebbafbfb048b9")

