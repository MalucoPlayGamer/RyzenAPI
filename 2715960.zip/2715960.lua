-- Lua provided by RyzenAPI
-- Game: 2715960

-- MAIN APPLICATION
addappid(2715960)
addappid(2723530)
-- Game: addappid(2715960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715961, 1, "a23ef5d0e3e7cd05e1730c2050dc403d5bff82b36e790e334608ad4bde200ecb")
