-- Lua provided by RyzenAPI
-- Game: Crazy Drift

-- MAIN APPLICATION
addappid(2166990)
-- Game: addappid(2166990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166991, 1, "454477ba87138b5e0219bda98f96555e781c11bf39b300fc4e86830666ab5dbf")
