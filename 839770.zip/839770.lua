-- Lua provided by RyzenAPI
-- Game: Phoenix Point

-- MAIN APPLICATION
addappid(839770)
addappid(1357360)
addappid(1357370)
addappid(1357371)
addappid(1357372)
addappid(1619320)
addappid(1622220)
addappid(1622221)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(839770,0,"0d41e5b2f0274fda368919edf5d919041cd8cfa668a7ae163e5f443347166a4d")
addappid(839771,0,"332cfa106a9342d144de52e56d95ebe11b1bf5415e689c29c215f712db05bea2")
addappid(839772,0,"a01b87c7941269bd761f2fc72e04b128fcd189680dd341f17c466ceb0f6d7205")
addappid(1357480,0,"aa477376a0154312123af1c97856b852a6917ca69bf759537ffa6c36ac700550")

