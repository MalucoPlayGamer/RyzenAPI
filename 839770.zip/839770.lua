-- Lua provided by RyzenAPI
-- Game: Game: Phoenix Point

-- MAIN APPLICATION
addappid(839770)
-- Game: addappid(839770)

-- MAIN APP DEPOTS / PACKAGES
addappid(839771, 1, "332cfa106a9342d144de52e56d95ebe11b1bf5415e689c29c215f712db05bea2")
addappid(839772, 1, "a01b87c7941269bd761f2fc72e04b128fcd189680dd341f17c466ceb0f6d7205")
addappid(1357480, 0, "aa477376a0154312123af1c97856b852a6917ca69bf759537ffa6c36ac700550")
