-- Lua provided by RyzenAPI
-- Game: AppID 856370

-- MAIN APPLICATION
addappid(856370)
addappid(970020)

-- MAIN APP DEPOTS / PACKAGES
addappid(856371, 1, "ace45142a35566d35259e73c175292d3e3f3ba5849beb0b268855639f0255bfa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
