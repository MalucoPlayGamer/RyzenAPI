-- Lua provided by RyzenAPI
-- Game: Game: AppID 856370

-- MAIN APPLICATION
addappid(856370)
addappid(970020)
-- Game: addappid(856370)

-- MAIN APP DEPOTS / PACKAGES
addappid(856371, 1, "ace45142a35566d35259e73c175292d3e3f3ba5849beb0b268855639f0255bfa")
