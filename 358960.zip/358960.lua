-- Lua provided by RyzenAPI
-- Game: Canabalt

-- MAIN APPLICATION
addappid(358960)

-- MAIN APP DEPOTS / PACKAGES
addappid(358961, 1, "30708dcedf2c200deca06f6e89486db278da7c4a9ae8e247f6ac743f557bd310")
addappid(358962, 1, "6d8d906e04ce62afe6a43854dca0cb5d46fc5c5bc405931150f6d327b2a0de43")
addappid(358963, 1, "1efc212f4a27cdbf03bf93ba5e143fc3e7e89432a29e1b0f166511540d4e5e00")
addappid(358964, 1, "fa6d6427b99bbb79eae72dd0cb6b421dc4d648c7a02e73d48751ff6579e8ef68")

