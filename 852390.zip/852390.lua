-- Lua provided by RyzenAPI
-- Game: SwordBounce

-- MAIN APPLICATION
addappid(852390)
-- Game: addappid(852390)

-- MAIN APP DEPOTS / PACKAGES
addappid(852391, 1, "7a3992e17b1f0c41902ec1f86558acf9ec4459346d9867809db094f7bf5b1599")
