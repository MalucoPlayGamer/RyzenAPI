-- Lua provided by SkyAPI 
-- Game: SwordBounce
addappid(852390)
addappid(852391, 1, "7a3992e17b1f0c41902ec1f86558acf9ec4459346d9867809db094f7bf5b1599")
