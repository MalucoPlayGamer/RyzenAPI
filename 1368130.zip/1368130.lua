-- Lua provided by RyzenAPI
-- Game: Game: Park Beyond

-- MAIN APPLICATION
addappid(1368130)
-- Game: addappid(1368130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368131, 1, "944c9fe646bce1f48127a62c82b40fc6f3524264b3b8b8c42d0b574768cee88d")
