-- Lua provided by RyzenAPI
-- Game: 943410

-- MAIN APPLICATION
addappid(943410)
-- Game: addappid(943410)

-- MAIN APP DEPOTS / PACKAGES
addappid(943411, 1, "2605a94381e522e8c52592be25a927a45b3b9a86e98f07c6c120184307dd5ed9")
