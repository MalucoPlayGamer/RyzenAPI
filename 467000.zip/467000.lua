-- Lua provided by RyzenAPI
-- Game: Game: AppID 467000

-- MAIN APPLICATION
addappid(467000)
-- Game: addappid(467000)

-- MAIN APP DEPOTS / PACKAGES
addappid(467001, 1, "3534572443ce1283f8599a863792143ffb23faa9a0caefb9464e47412383acb9")
