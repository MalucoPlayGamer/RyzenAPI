-- Lua provided by RyzenAPI
-- Game: Dungeon Tracer

-- MAIN APPLICATION
addappid(3310900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310901, 1, "103796c12ad7a4a24faa6fe1f9f78611d1b87662db52023f5bd1ed158a16ad17")
