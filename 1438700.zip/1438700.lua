-- Lua provided by RyzenAPI 
-- Game: Silicon Valley Investor
addappid(1438700)
addappid(1438701, 1, "7d351e3dc4cda020368496b2c44207cf4e946ee67a47b836cbe3fc5b72195a05")
