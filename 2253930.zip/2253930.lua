-- Lua provided by SkyAPI 
-- Game: Kamikaze Lassplanes
addappid(2253930)
addappid(2253931, 1, "be43d2ec2928a93cfcb96cdb9b4fc2653b53b7b2a9dca4fd13458f67caf8c3a7")
