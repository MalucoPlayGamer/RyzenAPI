-- Lua provided by RyzenAPI
-- Game: Game: Kamikaze Lassplanes

-- MAIN APPLICATION
addappid(2253930)
-- Game: addappid(2253930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253931, 1, "be43d2ec2928a93cfcb96cdb9b4fc2653b53b7b2a9dca4fd13458f67caf8c3a7")
