-- Lua provided by RyzenAPI
-- Game: 617730

-- MAIN APPLICATION
addappid(617730)
-- Game: addappid(617730)

-- MAIN APP DEPOTS / PACKAGES
addappid(617731, 1, "1de3902a26d69d30fde1e8c997aa9f6c9686958e3920c0f3f09edd969dc01e24")
