-- Lua provided by RyzenAPI 
-- Game: Prodeus MIDI Soundtrack
addappid(1668440)
addappid(1668441, 1, "857b31d2728c15fba639d22bbe09f1184721c5f69e770ad6d0a7fbcbe9bbcd63")
addappid(1668442, 1, "5fd9c0721eb8ad7855412f2abf2d827801e02310ce5bd041387450a94a277819")
