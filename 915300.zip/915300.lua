-- Lua provided by RyzenAPI
-- Game: The planet's rescuer

-- MAIN APPLICATION
addappid(915300)

-- MAIN APP DEPOTS / PACKAGES
addappid(915301, 1, "7bedc5f44e1541d92f9dee24b824063d667e60deca461072771bbc0a85a75fdb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
