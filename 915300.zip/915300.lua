-- Lua provided by RyzenAPI
-- Game: Game: The planet's rescuer

-- MAIN APPLICATION
addappid(915300)
-- Game: addappid(915300)

-- MAIN APP DEPOTS / PACKAGES
addappid(915301, 1, "7bedc5f44e1541d92f9dee24b824063d667e60deca461072771bbc0a85a75fdb")
