-- Lua provided by RyzenAPI
-- Game: addappid(1181120)

-- MAIN APPLICATION
addappid(1181120)
addappid(1183440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181121, 1, "c3944bbc8cf99e979662f315675d0a6a45c71d841a48a009424d74b53bb45b4f")
