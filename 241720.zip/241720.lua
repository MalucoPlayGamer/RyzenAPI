-- Lua provided by RyzenAPI
-- Game: Guncraft

-- MAIN APPLICATION
addappid(241720)
addappid(259120)
addappid(259121)
addappid(259122)
addappid(280030)
addappid(280031)
addappid(280032)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(241721, 1, "117e504e4d82f8e86b226a8cc0080e5043147732abc225961716e03f075cde37")
