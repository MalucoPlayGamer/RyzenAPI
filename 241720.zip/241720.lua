-- Lua provided by RyzenAPI
-- Game: Game: AppID 241720

-- MAIN APPLICATION
addappid(241720)
-- Game: addappid(241720)

-- MAIN APP DEPOTS / PACKAGES
addappid(241721, 1, "117e504e4d82f8e86b226a8cc0080e5043147732abc225961716e03f075cde37")
