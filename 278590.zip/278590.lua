-- Lua provided by RyzenAPI
-- Game: AppID 278590

-- MAIN APPLICATION
addappid(278590)
addappid(445710)
addappid(680160)

-- MAIN APP DEPOTS / PACKAGES
addappid(278591, 1, "c20c19a69ec2de82d9d670815ec25699a91aa72b337d187d5641dc56cffde414")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
