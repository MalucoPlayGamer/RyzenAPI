-- Lua provided by RyzenAPI
-- Game: AppID 278590

-- MAIN APPLICATION
addappid(278590)
addappid(445710)
addappid(680160)

-- MAIN APP DEPOTS / PACKAGES
addappid(278591, 1, "c20c19a69ec2de82d9d670815ec25699a91aa72b337d187d5641dc56cffde414")

