-- Lua provided by RyzenAPI
-- Game: 3231900

-- MAIN APPLICATION
addappid(3231900)
-- Game: addappid(3231900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231901, 1, "6dcb95fd9e72e950108b5e6e5592ff97bdec60ae393a3613b1d78edef2250978")
