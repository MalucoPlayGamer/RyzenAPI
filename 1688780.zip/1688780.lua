-- Lua provided by RyzenAPI
-- Game: Light Fighter

-- MAIN APPLICATION
addappid(1688780)
-- Game: addappid(1688780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688781, 1, "dd57db33b0b31fb1c40d74fa4348c480035cb49026d25d4a8933e0181e5ee128")
