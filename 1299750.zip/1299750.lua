-- Lua provided by RyzenAPI
-- Game: Wizodd

-- MAIN APPLICATION
addappid(1299750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299752,0,"f4a9d29ab2d98e8c8d6a4ddc33b9f987642b064a9f1992867e1d32a84fead692")

