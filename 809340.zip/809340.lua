-- Lua provided by RyzenAPI
-- Game: addappid(809340)

-- MAIN APPLICATION
addappid(809340)

-- MAIN APP DEPOTS / PACKAGES
addappid(809341, 1, "a89b9e148839b1e571551bd16ed7f24bd94e6cbb3d7ef0b1e76eac82f4ce111e")
