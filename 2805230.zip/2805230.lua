-- Lua provided by RyzenAPI
-- Game: addappid(2805230)

-- MAIN APPLICATION
addappid(2805230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805231, 1, "a01f3f89380ea090925946fac5eb6778db16b94a4da278b26e7147ef66d56549")
