-- Lua provided by RyzenAPI
-- Game: 1679870

-- MAIN APPLICATION
addappid(1679870)
-- Game: addappid(1679870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679871, 1, "4c87c9da6f5ed85198f2cc4e54ea75a7b0536ec3dcd19c1506c7c644e9bbac58")
