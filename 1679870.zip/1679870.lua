-- Lua provided by RyzenAPI 
-- Game: Arcana: Heat and Cold. Season 2
addappid(1679870)
addappid(1679871, 1, "4c87c9da6f5ed85198f2cc4e54ea75a7b0536ec3dcd19c1506c7c644e9bbac58")
