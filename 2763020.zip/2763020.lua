-- Lua provided by RyzenAPI
-- Game: ROAD

-- MAIN APPLICATION
addappid(2763020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2763021, 1, "18ade402352dcddc6403b2ba307e827fccf374d781aeb0343c62a803274eeddb")

