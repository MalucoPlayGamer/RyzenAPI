-- Lua provided by RyzenAPI
-- Game: addappid(2763020)

-- MAIN APPLICATION
addappid(2763020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763021, 1, "18ade402352dcddc6403b2ba307e827fccf374d781aeb0343c62a803274eeddb")
