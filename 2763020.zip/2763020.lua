-- Lua provided by RyzenAPI 
-- Game: ROAD
addappid(2763020)
addappid(2763021, 1, "18ade402352dcddc6403b2ba307e827fccf374d781aeb0343c62a803274eeddb")
