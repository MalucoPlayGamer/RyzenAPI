-- Lua provided by RyzenAPI
-- Game: The Silent Kingdom Demo

-- MAIN APPLICATION
addappid(1832190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832191, 1, "c7b90c4dea6a9094a81ec57667d3485b6034e744394be0b51907097fa202b54f")
