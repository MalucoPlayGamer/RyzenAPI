-- Lua provided by RyzenAPI
-- Game: 1410600

-- MAIN APPLICATION
addappid(1410600)
-- Game: addappid(1410600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410601, 1, "52bd6574fe1e3061edceaa54f8ddda85a335516454c9bff58a408dcff3362e92")
addappid(1410602, 1, "e3f48486ed21f08d0667308cb2c83f180b4e55f39b7c8bdf656355753da34f5a")
