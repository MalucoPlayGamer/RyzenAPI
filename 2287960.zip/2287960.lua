-- Lua provided by RyzenAPI
-- Game: Stigmata of Sacrilege

-- MAIN APPLICATION
addappid(2287960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287961, 1, "149e0764e8dc545c9a55fa06ded87ed0efc156c3eeea62909431558226abb780")
addappid(2287962, 1, "6d18dd3feae1034bc8b74e4e446b2ad191d24a446e918ca7d89abe1fa17e54e9")
addappid(2287963, 1, "b09786b450811dc90b82b05a80215c5eef362037903bb304bf370aedf17795c3")

