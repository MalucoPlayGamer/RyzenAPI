-- Lua provided by RyzenAPI
-- Game: 我的人生

-- MAIN APPLICATION
addappid(3393750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393751, 1, "aa594473abe92a4caee2336729550c42f1ab7471cf27c013d40b1f4bd9ef78ee")
addappid(3465771, 0, "b13174efa306cb1a63eb3a1776894b516190036b67dbbae7e773cbf93a5ea27e")
addappid(3465772, 0, "c858d0d6cffa42471c30d373158a4ddfd11eb4e1630833960babce76833ac613")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3465770)
addappid(4293420)
