-- Lua provided by RyzenAPI
-- Game: 我的人生

-- MAIN APPLICATION
addappid(3393750)
-- Game: addappid(3393750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393751, 1, "aa594473abe92a4caee2336729550c42f1ab7471cf27c013d40b1f4bd9ef78ee")
addappid(3465771, 0, "b13174efa306cb1a63eb3a1776894b516190036b67dbbae7e773cbf93a5ea27e")
addappid(3465772, 0, "c858d0d6cffa42471c30d373158a4ddfd11eb4e1630833960babce76833ac613")
