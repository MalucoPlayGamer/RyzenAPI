-- Lua provided by RyzenAPI
-- Game: addappid(356040)

-- MAIN APPLICATION
addappid(356040)

-- MAIN APP DEPOTS / PACKAGES
addappid(356041, 1, "4008b22f417ee9e2c479e326ecfe34e6dfbb9694bad680c106d7fd6ee0f3395f")
addappid(356042, 1, "66dee9dc10d45594d8b49a125a1acb007b41c113c11e72e30d27db12b471acaf")
addappid(356043, 1, "7d149893ac0eff9fc6376b3545d9b928550219b83c83b884bf7d98fe5bb8eb08")
