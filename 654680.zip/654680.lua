-- Lua provided by RyzenAPI
-- Game: Ziggurat 3D Chess

-- MAIN APPLICATION
addappid(654680)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(654681, 1, "6a55ecc5c8c6b52fe58839ff28329e47adb2a8e5cdcc40d3dfdc5dea93877602")

