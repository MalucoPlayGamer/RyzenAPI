-- Lua provided by RyzenAPI
-- Game: Game: Zapling Bygone

-- MAIN APPLICATION
addappid(1489110)
-- Game: addappid(1489110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489111, 1, "2b95610a075bed0ad11abb9cb04e591350e3b158eb236bbbf738a3c028929bc0")
