-- Lua provided by RyzenAPI
-- Game: Beholder

-- MAIN APPLICATION
addappid(475550)
addappid(616950)
-- Game: addappid(475550)

-- MAIN APP DEPOTS / PACKAGES
addappid(475551, 1, "4902dde8f25ea91e0f9a3483d3e61f42bf6ab67c8ad3ebcb74ac68daf0cf5f0d")
addappid(475552, 1, "a69a657a63f49f8e265a37331614998b817e2bfde8f4573c2d057b269da10b6d")
addappid(475554, 1, "00919b8430902e236141946ccb41baf927c9683f3c084fc6f35bb4a4e059fde3")
addappid(475555, 1, "3387cba10af199dfbde58bda91ec2b98cb36d190c9a47184a91028f25e3f9622")
addappid(616951, 0, "7d0af3aaa508cb227d6c427b9cd2a47e39bb74e9d3d318b9568d913f921882cc")
addappid(616952, 0, "d0e98673590c82d318cba9b3ed52f82be4dea2bbd066e51a1dd9496439ae09ef")
addappid(616953, 0, "2d70c412c3abc28b4b7a6e2f3f24b975d7ec308a91cc855318f2ecbb31c6f811")
