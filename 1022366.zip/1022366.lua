-- Lua provided by RyzenAPI
-- Game: 1022366

-- MAIN APPLICATION
addappid(1022366)
-- Game: addappid(1022366)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022366,0,"82667ad825b4e11edc27797d04a319b28cd57a3bc7b7281334aece8814aa839b")
