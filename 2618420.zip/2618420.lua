-- Lua provided by RyzenAPI
-- Game: Infection Crisis : Fight For Life

-- MAIN APPLICATION
addappid(2618420)
addappid(2619380)
-- Game: addappid(2618420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618421, 1, "c76ed4e33c5ba20b11331bc59262bc4e0036cfd45e1d7eee4204780b53cf44e1")
