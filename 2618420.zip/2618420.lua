-- Lua provided by RyzenAPI
-- Game: Infection Crisis : Fight For Life

-- MAIN APPLICATION
addappid(2618420)
addappid(2619380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618421, 1, "c76ed4e33c5ba20b11331bc59262bc4e0036cfd45e1d7eee4204780b53cf44e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
