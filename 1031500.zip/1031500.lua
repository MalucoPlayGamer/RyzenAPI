-- Lua provided by RyzenAPI 
-- Game: AppID 1031500
addappid(1031500)
addappid(1031501, 1, "ac603b728975f79527735299520f16b04461535deb82e933056e930bc793d413")
