-- Lua provided by RyzenAPI
-- Game: SUPER ROBOT WARS V

-- MAIN APPLICATION
addappid(1031500)
addappid(1126720)
addappid(1128560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1031501, 1, "ac603b728975f79527735299520f16b04461535deb82e933056e930bc793d413")
