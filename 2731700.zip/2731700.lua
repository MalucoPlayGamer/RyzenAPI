-- Lua provided by RyzenAPI
-- Game: Game: AppID 2731700

-- MAIN APPLICATION
addappid(2731700)
-- Game: addappid(2731700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731701, 1, "ab8cb93d057f30c875da0ba48a3648409d940eccfcfdeed123eb3772b24c3eb9")
