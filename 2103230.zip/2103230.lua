-- Lua provided by SkyAPI 
-- Game: MACROSS -Shooting Insight-
addappid(2103230)
addappid(2103231, 1, "858a7b36202fa56abfee4b60b61dd0f089b55293604578d898d3d40050264df4")
addappid(2203520, 0, "422c610c04d5b04793a1c171b47948e66a561757639c7e46cfdd3b2aa5b89d11")
