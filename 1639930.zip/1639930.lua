-- Lua provided by RyzenAPI
-- Game: Game: Last Days

-- MAIN APPLICATION
addappid(1639930)
-- Game: addappid(1639930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639931, 1, "3651882622fc5fca5acac782010e3b2aeb33797dc527c2bc46a45c068dfa97b9")
