-- Lua provided by RyzenAPI
-- Game: AppID 2172510

-- MAIN APPLICATION
addappid(2172510)
-- Game: addappid(2172510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172511, 1, "6f467a7ea5a537952bf28c9570a7d2378439a6a97ec2234d5a9080e7c9c7ad1c")
addappid(2193980, 0, "3dcac0251f8e6de68b9dc88ab70ef820cffc5b68e3b27f29d1a2b3bc1275fbdc")
