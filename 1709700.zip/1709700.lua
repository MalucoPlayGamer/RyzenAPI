-- Lua provided by RyzenAPI
-- Game: 1709700

-- MAIN APPLICATION
addappid(1709700)
-- Game: addappid(1709700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709701, 1, "43373173c8c4d0d299b169ebd91f14e00b63aed0517cd4fa610907ce24dd387e")
