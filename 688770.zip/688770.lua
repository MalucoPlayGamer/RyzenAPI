-- Lua provided by RyzenAPI
-- Game: TETRUX: Online

-- MAIN APPLICATION
addappid(688770)

-- MAIN APP DEPOTS / PACKAGES
addappid(688771, 1, "97cfa63a8402828a8e590bc9af1dfd4c8074ec29fa48a771b8c4bc89b873b938")
