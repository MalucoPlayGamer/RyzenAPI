-- Lua provided by SkyAPI 
-- Game: AppID 586090
addappid(586090)
addappid(586091, 1, "e2e4abb46543b9aec5d6018a25454c3302b2e8d542268c2ee7f9ab8cd455ca9c")
