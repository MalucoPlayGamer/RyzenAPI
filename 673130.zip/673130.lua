-- Lua provided by RyzenAPI
-- Game: AppID 673130

-- MAIN APPLICATION
addappid(673130)

-- MAIN APP DEPOTS / PACKAGES
addappid(673131, 1, "b13838081ef22aafb9bc5c9f9c2c8ab96fc951ecad54ea4e79e4e2b2cc856ae4")
addappid(1198780, 0, "144c01050c8c2f5f7633531c0638f340b63f299c9eb41baee1df1278dd237b50")
addappid(1852860, 0, "0ae35df91c89a8e534c5b7d1e1efd6edb0863cfc2d4ea8f3c65f517fdf620a7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
