-- Lua provided by RyzenAPI
-- Game: addappid(2354300)

-- MAIN APPLICATION
addappid(2354300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354301, 1, "d35d83f71193d88e7506d9c07bc4c13b23182446340c8fdb307e52a02db045ca")
