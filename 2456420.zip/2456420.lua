-- Lua provided by RyzenAPI
-- Game: HUNTER×HUNTER NEN×IMPACT

-- MAIN APPLICATION
addappid(2456420)
addappid(3486300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456421, 1, "ecb4a0327002788ea35407a4e1085e3a8e3fa904cd592f506c31b567ad6a6b8d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3486310)
addappid(3486320)
addappid(3486330)
addappid(3486340)
