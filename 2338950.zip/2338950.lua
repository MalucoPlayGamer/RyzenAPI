-- Lua provided by RyzenAPI
-- Game: Dream Ploy Will

-- MAIN APPLICATION
addappid(2338950)
-- Game: addappid(2338950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338951, 1, "25c032e8eb6074cd485a26db99535e3cd46883f299784fe9fc85e05d691e73f7")
