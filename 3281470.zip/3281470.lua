-- Lua provided by RyzenAPI 
-- Game: Nova Drift Demo
addappid(3281470)
addappid(3281471, 1, "f054630dc593915eb0f1080f42e0878cea93c9886c52942ff6e5def19a7da61c")
