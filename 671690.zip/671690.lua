-- Lua provided by RyzenAPI
-- Game: [MARS] Total Warfare

-- MAIN APPLICATION
addappid(671690)
addappid(843670)
addappid(843671)
addappid(843672)
addappid(851500)
addappid(1578530)
addappid(1578531)

-- MAIN APP DEPOTS / PACKAGES
addappid(671691, 1, "18c69879e5d72f1a735978a7a37df13607a80c53d1f0d1359a7c89b09be567fb")

