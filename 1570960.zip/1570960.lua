-- Lua provided by RyzenAPI
-- Game: Grey Instinct

-- MAIN APPLICATION
addappid(1570960)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1570970)
