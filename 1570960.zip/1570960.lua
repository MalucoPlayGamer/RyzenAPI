-- Lua provided by RyzenAPI
-- Game: Grey Instinct

-- MAIN APPLICATION
addappid(1570960)
addappid(1570970)

