-- Lua provided by RyzenAPI
-- Game: Grey Instinct

-- MAIN APPLICATION
addappid(1570960)

