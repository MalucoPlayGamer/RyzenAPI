-- Lua provided by RyzenAPI
-- Game: Rotund Rebound

-- MAIN APPLICATION
addappid(1000750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000751, 1, "82d7fd199e6b8beceb4b6f847083c25729b37be4c54c3693b1825569170a8a97")
addappid(1000752, 1, "8993fb32db16d71ace9ede168fc10d255d39fe77a9ed3bf8db2f5cf7dd437c2a")
addappid(1000753, 1, "d7ec4361efb503f7778e7236b5d8d51af32dc97ec411c60ea1efcbbd40712df9")
