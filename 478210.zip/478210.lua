-- Lua provided by RyzenAPI
-- Game: Game: BUDDY

-- MAIN APPLICATION
addappid(478210)
-- Game: addappid(478210)

-- MAIN APP DEPOTS / PACKAGES
addappid(478211, 1, "15b8f1879f81aa017ffa9d5e9bafe616bcd657b247ffd5b6e4a5cbd5ed2324dc")
