-- Lua provided by RyzenAPI
-- Game: SMITE 2 Playtest

-- MAIN APPLICATION
addappid(2781320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781321, 1, "cf2c5add2f73e54d521a1f094722ef5bbd84ef6a22cec5ea265e96bc7bd22f8b")

