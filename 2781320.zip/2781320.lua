-- Lua provided by SkyAPI 
-- Game: SMITE 2 Playtest
addappid(2781320)
addappid(2781321, 1, "cf2c5add2f73e54d521a1f094722ef5bbd84ef6a22cec5ea265e96bc7bd22f8b")
