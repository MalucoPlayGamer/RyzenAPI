-- Lua provided by RyzenAPI
-- Game: Phantoms

-- MAIN APPLICATION
addappid(2702020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702021, 1, "94aef28efe1741e009303c50350ddc9a26a19d2921435c8212edb30eb098f2a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
