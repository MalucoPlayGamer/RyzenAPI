-- Lua provided by RyzenAPI
-- Game: addappid(1274500)

-- MAIN APPLICATION
addappid(1274500)
addappid(1274508)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050161,0,"d15bc11e6b31c14446d63d7dd555ec40bce272d774af7dd0a21beccc1951a6a2")
