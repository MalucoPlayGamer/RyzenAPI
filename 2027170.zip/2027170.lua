-- Lua provided by RyzenAPI
-- Game: SIMBA THE CAT

-- MAIN APPLICATION
addappid(2027170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027171, 1, "d5c13fff97ac59978fcab8d979ae6abc8a6d477c35afbc1723708e5e312c7597")
