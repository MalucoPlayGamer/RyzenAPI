-- Lua provided by RyzenAPI
-- Game: Game: Limoria

-- MAIN APPLICATION
addappid(3351140)
-- Game: addappid(3351140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351141, 1, "e6340bf55090bdb9a0a5d7149a9240cec31cc72c1a2ff50c737a48dfd3ae4ab9")
