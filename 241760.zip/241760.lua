-- Lua provided by RyzenAPI
-- Game: Kill to Collect

-- MAIN APPLICATION
addappid(241760)
addappid(457430)

-- MAIN APP DEPOTS / PACKAGES
addappid(241761, 1, "061d3b0848011a2edd82db31166a2046226602c9bc280b76d24adab522438ec5")
addappid(241762, 1, "6f79e01f194a5fcd463b9c67bb789f3e0cb72259d63b609a6add4d228340f963")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
