-- Lua provided by RyzenAPI 
-- Game: ExoTanks
addappid(731250)
addappid(731251, 1, "df829238ba148bc5df42bad65028dd7dc16aa4a06a06fb2cf87815e35f9d10d5")
