-- Lua provided by RyzenAPI
-- Game: Naev Soundtrack

-- MAIN APPLICATION
addappid(1411430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411431, 1, "9072b80ef62dda3ba0e5188dce4808dedca973b5874d2dc231c2ac3456076b5d")
