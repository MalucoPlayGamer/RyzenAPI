-- Lua provided by RyzenAPI
-- Game: Tavernier

-- MAIN APPLICATION
addappid(517370)

-- MAIN APP DEPOTS / PACKAGES
addappid(517371,0,"6f67240102f18240455dea9d18cba1c0ef4b85bdf3b3f4c5996ca96c3932de32")
addappid(517372,0,"05f40a664fd770f8b85947533d3cf7f42a46a26bc512b2d1db60baa5201f5e76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
