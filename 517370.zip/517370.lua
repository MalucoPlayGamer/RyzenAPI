-- Lua provided by RyzenAPI
-- Game: Tavernier

-- MAIN APPLICATION
addappid(517370)

-- MAIN APP DEPOTS / PACKAGES
addappid(517371,0,"6f67240102f18240455dea9d18cba1c0ef4b85bdf3b3f4c5996ca96c3932de32")
addappid(517372,0,"05f40a664fd770f8b85947533d3cf7f42a46a26bc512b2d1db60baa5201f5e76")

