-- Lua provided by RyzenAPI
-- Game: 1740520

-- MAIN APPLICATION
addappid(1740520)
-- Game: addappid(1740520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740520,0,"162e87a29cf4b0725535bd5764fc52d2f3458a261d4107be6aff1aa5ea406aac")
