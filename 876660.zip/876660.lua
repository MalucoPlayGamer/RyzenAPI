-- Lua provided by RyzenAPI
-- Game: Aground Demo

-- MAIN APPLICATION
addappid(229020)
addappid(876660)
-- Game: addappid(876660)

-- MAIN APP DEPOTS / PACKAGES
addappid(876651,0,"51839908ab76ff543b63bc94d1d74a75931d453eb14c113b57e168df3fbbf382")
addappid(876652,0,"f30f53c32eff36b1f5c87c8031438bab2762337d3f12600023d1e0d4330fff8a")
addappid(876653,0,"4c184ded5deafa43eb4bea5ce88affb5ecc3574bb7cc574101e0d4376eecb960")
addappid(876654,0,"0180086f402ebb4cd72e8b817ed515bd7f6874c27b8d7cd6c5488b3495859268")
