-- Lua provided by RyzenAPI
-- Game: AppID 857370

-- MAIN APPLICATION
addappid(857370)
addappid(897282)

-- MAIN APP DEPOTS / PACKAGES
addappid(857371, 1, "9c41d6af636a4b3c5722f65a42e1fa2eee9cf9f2e7dcc3217c90ea96d6932edd")
addappid(857372, 1, "9554b564ca67d8a4c8a5939da98e9333ec3fba3106b43b17004016c280b252d1")
addappid(872430, 0, "b57ae0d9da0a4dca1440c3c8050213ad12cc6e6ff9169d7141fe7c01be5953fd")
addappid(897280, 0, "c598d5873f8ea3b3bff0deb312991ed070fec808dcaaf9e4558e9b61cd5e9eca")
