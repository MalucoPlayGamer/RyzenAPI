-- Lua provided by RyzenAPI
-- Game: 孙悟空大战机器金刚 / Sun Wukong VS Robot

-- MAIN APPLICATION
addappid(1008830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008831, 1, "db7f89199eee529e1d5fdf41230ff258d45950a1198598b63c0fac73c23fe107")
