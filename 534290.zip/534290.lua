-- Lua provided by RyzenAPI
-- Game: Cursed Castilla (Maldita Castilla EX)

-- MAIN APPLICATION
addappid(534290)

-- MAIN APP DEPOTS / PACKAGES
addappid(534291, 1, "21597f24caa9fe7ffaef0eb9643eda0e93b86c7d8de0d1506a85e9bde6d3a39c")
