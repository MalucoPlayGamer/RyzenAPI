-- Lua provided by RyzenAPI
-- Game: Cursed Castilla (Maldita Castilla EX)

-- MAIN APPLICATION
addappid(534290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(534291, 1, "21597f24caa9fe7ffaef0eb9643eda0e93b86c7d8de0d1506a85e9bde6d3a39c")

