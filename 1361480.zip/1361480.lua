-- Lua provided by RyzenAPI 
-- Game: AppID 1361480
addappid(1361480)
addappid(1361481, 1, "85c14b19ff3af3c619d481e978e6f97ca3be37c2bf7c081909ab10d241a5efa0")
