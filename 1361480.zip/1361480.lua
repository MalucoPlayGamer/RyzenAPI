-- Lua provided by RyzenAPI
-- Game: Robots, Death & Venice

-- MAIN APPLICATION
addappid(1361480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1361481, 1, "85c14b19ff3af3c619d481e978e6f97ca3be37c2bf7c081909ab10d241a5efa0")
