-- Lua provided by SkyAPI 
-- Game: Cartel Simulator
addappid(2536490)
addappid(2536491, 1, "028814ed8b11b2e4fbf0e49ea3f734242caaf1f9f27c09ff1ba80df50491d52f")
