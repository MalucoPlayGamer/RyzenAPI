-- Lua provided by RyzenAPI
-- Game: Angry Boy

-- MAIN APPLICATION
addappid(2961320)
-- Game: addappid(2961320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2961321, 1, "4a0c1a2a24f942126f79cb5d8cb0da094dd31b5be8a814fcc86a654819ebe2ad")
