-- Lua provided by RyzenAPI
-- Game: Game: Acts of Blood Demo

-- MAIN APPLICATION
addappid(3304670)
-- Game: addappid(3304670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304671, 1, "cb8a83fb811482e2f22587127a28ad0ae92032aff274e645513d87ae8336debe")
