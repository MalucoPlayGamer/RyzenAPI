-- Lua provided by RyzenAPI
-- Game: Game: vSpatial

-- MAIN APPLICATION
addappid(858900)
-- Game: addappid(858900)

-- MAIN APP DEPOTS / PACKAGES
addappid(858901, 1, "da2d99bb814cfd10e23c4baf93c0860f8a6cef7c479f82db978ab3240914869a")
