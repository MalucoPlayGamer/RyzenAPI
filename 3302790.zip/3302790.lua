-- Lua provided by RyzenAPI
-- Game: AppID 3302790

-- MAIN APPLICATION
addappid(3302790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3302791, 1, "61fe5f6b51e37be26953f7d59d1ec67be86b727e3c878a8e0b2cba3a8e1f4d49")
