-- Lua provided by RyzenAPI
-- Game: 1719670

-- MAIN APPLICATION
addappid(1719670)
-- Game: addappid(1719670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719671, 1, "94673553d3248a111cca6aa3ee1a127a6c18f0bcbf945318e1012bb3ab79a35f")
