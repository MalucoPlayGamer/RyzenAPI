-- Lua provided by RyzenAPI
-- Game: Bulls and Cows - Wild West

-- MAIN APPLICATION
addappid(2795840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795841, 1, "8da80d32218efc08200faf04bfe43544a31fd71918300d62d1eadd3e2a8fc826")

