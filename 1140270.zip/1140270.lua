-- Lua provided by RyzenAPI
-- Game: Monster Prom 2: Monster Camp

-- MAIN APPLICATION
addappid(1140270)
addappid(1436710)
addappid(1438010)
addappid(1452150)
addappid(1487530)
addappid(1493620)
addappid(1542400)
addappid(1550910)
addappid(1584870)
addappid(1760120)
addappid(1762780)
addappid(2299810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140270,0,"df4bab94d15a235bb3ba603a21cc67e9e6f79a6bf3fbf9ea72ec9cf875901edc")
addappid(1140271,0,"9727eefb776387eb2d9f1c1e1e3e739be5e66a06707a2564aaaa346d199f0d70")
addappid(1140272,0,"cb023c9bf6cd80deadf40f85b3587965b0a39d3ee9410d9764177ddc927d8d69")
addappid(1140273,0,"9b2b6a04d2c6b328e784ed0bb76ccaf9941cd2d7e4762d51b524327e30715a4f")

