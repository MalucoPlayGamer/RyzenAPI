-- Lua provided by RyzenAPI
-- Game: Rising Front

-- MAIN APPLICATION
addappid(1560250)
-- Game: addappid(1560250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560250, 1, "f758b39466d7e1577827f7e91403e069e8d615ac84e3e8a5d362e5f0c4fd047e") -- Rising Front
addappid(1560252, 1, "f3f6f6db116ce81041fc3f358582e5ad09e76e9b0c54dd65b85851ef11bce0e9") -- Depot 1560252
