-- Lua provided by RyzenAPI
-- Game: AppID 928970

-- MAIN APPLICATION
addappid(928970)

-- MAIN APP DEPOTS / PACKAGES
addappid(928971, 1, "b448059368253862fdc1e9d11c41ad74597bf663dafcf9dc5d24c60487ffacc4")
