-- Lua provided by RyzenAPI
-- Game: Gardenia: Prologue

-- MAIN APPLICATION
addappid(1730560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730561, 1, "c9bf0206648aa337bc14fc07f95e622f793c6beee3d6f80fdb2536e5833ed351")

