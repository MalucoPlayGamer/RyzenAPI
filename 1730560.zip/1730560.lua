-- Lua provided by RyzenAPI
-- Game: AppID 1730560

-- MAIN APPLICATION
addappid(1730560)
-- Game: addappid(1730560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730561, 1, "c9bf0206648aa337bc14fc07f95e622f793c6beee3d6f80fdb2536e5833ed351")
