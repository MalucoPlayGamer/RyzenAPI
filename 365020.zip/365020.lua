-- Lua provided by RyzenAPI
-- Game: Game: Gynophobia

-- MAIN APPLICATION
addappid(365020)
-- Game: addappid(365020)

-- MAIN APP DEPOTS / PACKAGES
addappid(365021, 1, "8628ef468250a32db022b817eb50b2e772f063c3363388979cb057e3b4f58ecf")
addappid(365022, 1, "9e4fe43109c9848f98a71aa009688fca35b0c7982650a488f092c969d7d47445")
