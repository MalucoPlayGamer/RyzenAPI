-- Lua provided by SkyAPI 
-- Game: Touhou Mini Map
addappid(2187160)
addappid(2187161, 1, "8b5fd94e3b8aee6a1c841476470e8ffbb6fecbb9e9d9eb0f41023691930a141a")
