-- Lua provided by RyzenAPI
-- Game: Witch and Hero(魔女と勇者)

-- MAIN APPLICATION
addappid(434130)

-- MAIN APP DEPOTS / PACKAGES
addappid(434131, 1, "74bc661c1b02d13ce7c58a846fa31789c71860df23f0becc6c974657084bffd1")
