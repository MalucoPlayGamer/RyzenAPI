-- Lua provided by RyzenAPI
-- Game: SEDOMAIRI / せどまいり

-- MAIN APPLICATION
addappid(1684220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684221, 1, "ebc66a7796d89630aa09b24ef4c414d52194e65a359caa51b5a6e7983e5afb43")
