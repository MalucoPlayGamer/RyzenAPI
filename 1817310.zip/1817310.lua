-- Lua provided by RyzenAPI
-- Game: Game: 69 Megumi Love

-- MAIN APPLICATION
addappid(1817310)
-- Game: addappid(1817310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817311, 1, "c02ceb17e80c2de4edef97f07d7e2581de955ddf31a6c75540677e315b64cfba")
