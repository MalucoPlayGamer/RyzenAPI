-- Lua provided by RyzenAPI
-- Game: Wizards:Home

-- MAIN APPLICATION
addappid(459050)

-- MAIN APP DEPOTS / PACKAGES
addappid(459051, 1, "f45715fb042f792e570cb291770bca09831683bb6d11333e0e175dc4366695db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
