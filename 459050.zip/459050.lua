-- Lua provided by RyzenAPI
-- Game: Wizards:Home

-- MAIN APPLICATION
addappid(459050)

-- MAIN APP DEPOTS / PACKAGES
addappid(459051, 1, "f45715fb042f792e570cb291770bca09831683bb6d11333e0e175dc4366695db")
