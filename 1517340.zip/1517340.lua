-- Lua provided by RyzenAPI
-- Game: From The Darkness

-- MAIN APPLICATION
addappid(1517340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517341, 1, "04e006ecc8ca586b0168dff007ea2c719b8b2b4b8a8522640b9af43b2fdc77c4")
