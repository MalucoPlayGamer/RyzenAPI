-- Lua provided by RyzenAPI
-- Game: magnussoft® Screen Recorder Professional

-- MAIN APPLICATION
addappid(3739610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3739611, 1, "061b4e88d56b98f973dfa5e0fb0743229acab7faa87062ebdeca226791571738")
