-- Lua provided by RyzenAPI
-- Game: magnussoft® Screen Recorder Professional

-- MAIN APPLICATION
addappid(3739610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3739611, 1, "061b4e88d56b98f973dfa5e0fb0743229acab7faa87062ebdeca226791571738")

