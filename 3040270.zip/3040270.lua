-- Lua provided by RyzenAPI
-- Game: Bees vs Zombees

-- MAIN APPLICATION
addappid(3040270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040271, 1, "95597d05bb1b8740856432a51dc2072090f89a6a39f378d7d6f183ac9f100264")

