-- Lua provided by RyzenAPI
-- Game: Ubaste

-- MAIN APPLICATION
addappid(2144350)
-- Game: addappid(2144350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144351, 1, "3ab8040361ad00b3a137f8435f7fc9a5a672e1a04dab4f51435f7526a8573d68")
