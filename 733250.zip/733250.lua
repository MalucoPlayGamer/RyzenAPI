-- Lua provided by RyzenAPI
-- Game: Mover

-- MAIN APPLICATION
addappid(733250)

-- MAIN APP DEPOTS / PACKAGES
addappid(733251,0,"bfceeb57a7aba48a00ec2c95ff125f07cfcf03d4058a00066768a8d586f01047")
addappid(733252,0,"064df5cf475fe3f3bc02d55cf35891d2d1fc503392978dfd7603174ba34910b9")
addappid(733253,0,"f3d91a407bf1cf895cfb8a583364ad45f780b7c0b6b50de23a10c3b20eaa7c4f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
