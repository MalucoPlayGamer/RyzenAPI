-- Lua provided by RyzenAPI
-- Game: Blink

-- MAIN APPLICATION
addappid(447210)
-- Game: addappid(447210)

-- MAIN APP DEPOTS / PACKAGES
addappid(447211, 1, "96b777d4500af049f25477f65e86354a5af724110dbe13d31f5caa52d952e2d9")
addappid(597690, 0, "613cbacd1ce74faffe6d7c3967b72457bc5643d09f36074b65e8f41f37110334")
