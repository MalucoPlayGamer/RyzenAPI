-- Lua provided by RyzenAPI
-- Game: MXGP 2021 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(1610470)
addappid(1722430)
-- Game: addappid(1610470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610471, 1, "f04bdfa894c6da4bde731026e5e3a971faa1e0eca5da09e7fb254500419e464c")
