-- Lua provided by RyzenAPI
-- Game: MXGP 2021 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(1610470)
addappid(1722430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610471, 1, "f04bdfa894c6da4bde731026e5e3a971faa1e0eca5da09e7fb254500419e464c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
