-- Lua provided by SkyAPI 
-- Game: Zup! 7
addappid(658560)
addappid(658561, 1, "5983143651112761711e8979b972f4c2b0e325926753a09bcdfa129c2449d81e")
addappid(769610)
