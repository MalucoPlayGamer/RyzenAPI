-- Lua provided by RyzenAPI
-- Game: Zup! 7

-- MAIN APPLICATION
addappid(658560)
addappid(769610)
-- Game: addappid(658560)

-- MAIN APP DEPOTS / PACKAGES
addappid(658561, 1, "5983143651112761711e8979b972f4c2b0e325926753a09bcdfa129c2449d81e")
