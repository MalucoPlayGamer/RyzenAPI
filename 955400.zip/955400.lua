-- Lua provided by RyzenAPI
-- Game: Bonds

-- MAIN APPLICATION
addappid(955400)

-- MAIN APP DEPOTS / PACKAGES
addappid(955401, 1, "a6758af8e45deadb1d9988e511175fa9dbb507ad0bae5f6dd353b7aa53bc37cf")
addappid(955402, 1, "033a7e1e7894aa78f0102b7492a07e571235b74d5e948c28a8c3669ac69516a0")
addappid(955403, 1, "bfb285772e4b097cb443778d61b0c3f1c23d23e444ef55cb404c0fbf41baea98")
addappid(955404, 1, "bf9a97b87a5e95ca3473da027a2c4e716b4e072ac78cbccc90ccfe4c00957113")
