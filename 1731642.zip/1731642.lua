-- Lua provided by RyzenAPI
-- Game: addappid(1731642)

-- MAIN APPLICATION
addappid(1731642)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731642,0,"09c69d2a630698fc28e98dd26f676ae14bd9dc416220d07edd5811b8fe58927a")
