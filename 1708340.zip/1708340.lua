-- Lua provided by RyzenAPI 
-- Game: BlazingAngel Mistletear
addappid(1708340)
addappid(1708341, 1, "f4bb44d48690320f2487cea49a20c69938227b4a1973442ee5359a03db672634")
