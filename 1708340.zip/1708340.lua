-- Lua provided by RyzenAPI
-- Game: BlazingAngel Mistletear

-- MAIN APPLICATION
addappid(1708340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708341, 1, "f4bb44d48690320f2487cea49a20c69938227b4a1973442ee5359a03db672634")

