-- Lua provided by RyzenAPI
-- Game: addappid(396820)

-- MAIN APPLICATION
addappid(396820)

-- MAIN APP DEPOTS / PACKAGES
addappid(396821, 1, "91e73c92d98d8c12ce4f9174ca973d55cc2ec33686f4b7a57b86db131900d84d")
