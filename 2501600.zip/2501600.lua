-- Lua provided by RyzenAPI
-- Game: addappid(2501600)

-- MAIN APPLICATION
addappid(2501600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2501601, 1, "dc29f8c0cff596b5043b1023fd2ef27fc4d14e5568f19b6ed055d2e16cc4ff86")
