-- Lua provided by RyzenAPI
-- Game: Sayaka's Addiction

-- MAIN APPLICATION
addappid(3421070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421071, 1, "22a9dacf487c4102818c032a3bf8b9afbb244bb17aefc240c1b0787628a61748")
addappid(3421072, 1, "b3ab5206bee357ff258e9a6c842e2f6a34dfdeba7c1864b0da1a00acfe5c7fe7")
addappid(3421074, 1, "968304077825a559101732789a1eed1bbc3a7798029849be2c60d6d581000202")

