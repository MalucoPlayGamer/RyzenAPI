-- Lua provided by RyzenAPI
-- Game: Wavy Trip

-- MAIN APPLICATION
addappid(1729080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729081, 1, "02ed5e88920aea326bb4249f239afa2a37b097de8621b3e47016642252884df7")

