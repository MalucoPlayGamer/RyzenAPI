-- Lua provided by SkyAPI 
-- Game: AppID 1729080
addappid(1729080)
addappid(1729081, 1, "02ed5e88920aea326bb4249f239afa2a37b097de8621b3e47016642252884df7")
