-- Lua provided by RyzenAPI
-- Game: 2872860

-- MAIN APPLICATION
addappid(2872860)
-- Game: addappid(2872860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872861, 1, "c297fbfb6f54ef65b21e518148bbda7097e5188ee2db69325ec47b1e64e02fd4")
