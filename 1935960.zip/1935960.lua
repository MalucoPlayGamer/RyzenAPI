-- Lua provided by RyzenAPI
-- Game: Drifter's Tales

-- MAIN APPLICATION
addappid(1935960)
addappid(1950880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935961, 1, "a8a41d0566813ccf72425fe0154f8a6e38e072df1257e621141bd31764faa05c")

