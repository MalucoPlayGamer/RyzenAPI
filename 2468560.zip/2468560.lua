-- Lua provided by RyzenAPI
-- Game: Tay Son Dynasty

-- MAIN APPLICATION
addappid(2468560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468561, 1, "171a9bf884930335739a314ba194202ffee588b3e792da850c01a2e304868f0b")

