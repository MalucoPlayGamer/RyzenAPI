-- Lua provided by RyzenAPI
-- Game: Defense Legend 5: Survivor TD

-- MAIN APPLICATION
addappid(3697150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3697151, 1, "a31c8071142e0824e8b4021247a5e48838c925b04ea10f2cf7b7f09eb2515d63")
