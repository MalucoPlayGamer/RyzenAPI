-- Lua provided by RyzenAPI 
-- Game: UnHolY JaiL TRPG
addappid(3001100)
addappid(3001101, 1, "8bd164b4e9ec07e958ab44fe16297309baee61a66296ee6c910cd9a753149099")
