-- Lua provided by RyzenAPI 
-- Game: LUNA (Free)
addappid(1450110)
addappid(1450111, 1, "349bff7b006992011276594bc0d9c0a6ef63df6f471b08f732a8ca8422213673")
