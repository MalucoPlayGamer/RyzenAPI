-- Lua provided by RyzenAPI
-- Game: Game: LUNA (Free)

-- MAIN APPLICATION
addappid(1450110)
-- Game: addappid(1450110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450111, 1, "349bff7b006992011276594bc0d9c0a6ef63df6f471b08f732a8ca8422213673")
