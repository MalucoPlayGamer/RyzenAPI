-- Lua provided by RyzenAPI
-- Game: Lost Connections

-- MAIN APPLICATION
addappid(2471780)
-- Game: addappid(2471780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471781, 1, "d0a46c3e2ded8ef8bdc0274503c21affe91b20e7a621b8c4bef5c4a63d802623")
