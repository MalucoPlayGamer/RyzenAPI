-- Lua provided by SkyAPI 
-- Game: AppID 3219650
addappid(3219650)
addappid(3219651, 1, "0b49cd2eb7ea49c1fb5a689031adf4ad8e959b31be9ef4c39b1c1b58659b6a43")
