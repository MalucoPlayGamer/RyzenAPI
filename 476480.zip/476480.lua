-- Lua provided by RyzenAPI 
-- Game: Heaven Forest - VR MMO
addappid(476480)
addappid(476481, 1, "8c2c7159f3adb4d4b446e7e9962b4e9ea35ac5733e231ad5add4fb8c8c7798d9")
addappid(476482, 1, "a15c1c4d4f7dfaab86d4b6e48b713048dbb6385bb5599a71b907bcf3b3bfc1c5")
addappid(476483, 1, "c5be653e73d77483750aa28270ddcaa5b98616e0d632e20bfd6b2ef2c815578e")
