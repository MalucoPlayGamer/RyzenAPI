-- Lua provided by SkyAPI 
-- Game: AppID 1000760
addappid(1000760)
addappid(1000761, 1, "2b20a70539d569957131ecfdd97a5eecd80ae4c8596703030e10c3b8dc641c62")
