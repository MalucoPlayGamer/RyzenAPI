-- Lua provided by RyzenAPI
-- Game: Game: AppID 3264120

-- MAIN APPLICATION
addappid(3264120)
-- Game: addappid(3264120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264121, 1, "b458c3cd0e7a3dd4ce2e529e0fc8222e8b0a3da66133715539921df3bf959c88")
