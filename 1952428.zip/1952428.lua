-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Nature Pack Vol.2

-- MAIN APPLICATION
addappid(1952428)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952428,0,"da27d4056487c01695e4883ada8d7b2558654b746b05f425f774889e204e66d6")
