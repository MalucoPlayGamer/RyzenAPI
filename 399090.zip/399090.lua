-- Lua provided by RyzenAPI
-- Game: AppID 399090

-- MAIN APPLICATION
addappid(399090)

-- MAIN APP DEPOTS / PACKAGES
addappid(399091, 1, "7ea409c7898e7ef6aa151fb6087a9f8bf286ef4d866e376d4ccaea6093e206a5")
addappid(399092, 1, "8c1b702de8c0e9acee2c99fb4bc3e3a5dcc0f8f2600c1de0eda337c72588e0e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
