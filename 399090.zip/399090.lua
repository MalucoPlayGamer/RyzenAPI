-- Lua provided by RyzenAPI
-- Game: 399090

-- MAIN APPLICATION
addappid(399090)
-- Game: addappid(399090)

-- MAIN APP DEPOTS / PACKAGES
addappid(399091, 1, "7ea409c7898e7ef6aa151fb6087a9f8bf286ef4d866e376d4ccaea6093e206a5")
addappid(399092, 1, "8c1b702de8c0e9acee2c99fb4bc3e3a5dcc0f8f2600c1de0eda337c72588e0e0")
