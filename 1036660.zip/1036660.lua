-- Lua provided by RyzenAPI
-- Game: MiniGolf Maker

-- MAIN APPLICATION
addappid(1036660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036661, 1, "c400ecb48c0be417a131b10078ae791047587fd3b4b56e32d18a7b9f2ef8914a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
