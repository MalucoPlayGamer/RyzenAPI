-- Lua provided by SkyAPI 
-- Game: MiniGolf Maker
addappid(1036660)
addappid(1036661, 1, "c400ecb48c0be417a131b10078ae791047587fd3b4b56e32d18a7b9f2ef8914a")
