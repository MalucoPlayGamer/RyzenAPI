-- Lua provided by RyzenAPI
-- Game: Game: MiniGolf Maker

-- MAIN APPLICATION
addappid(1036660)
-- Game: addappid(1036660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036661, 1, "c400ecb48c0be417a131b10078ae791047587fd3b4b56e32d18a7b9f2ef8914a")
