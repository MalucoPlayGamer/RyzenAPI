-- Lua provided by RyzenAPI
-- Game: Sigi - A Fart for Melusina Soundtrack

-- MAIN APPLICATION
addappid(3713570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3713571, 1, "35743806c7c8a3c0556e0697316dd5ef6775a1f4eac2ccd4a580db0f3ee673cd")
addappid(3713572, 1, "4d981875230f6872d9d6e9d923b652eb0111e70ce56af953eddfab184a2bbd91")
