-- Lua provided by RyzenAPI 
-- Game: AppID 1339450
addappid(1339450)
addappid(1339451, 1, "ac3a2a8aaa011fbfde4ec3e5baa28028f53bac20aea92f9c4a187fc549626313")
