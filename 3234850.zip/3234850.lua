-- 3234850's Lua and Manifest Created by Hubcap Manifest
-- HYPERWIRED
-- Created: July 03, 2026 at 11:54:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3234850) -- HYPERWIRED
-- MAIN APP DEPOTS
addappid(3234851, 1, "068f66f438fa25ac78d6c1c6b65bb9f4a9ecce989743a184c2b28e3b83e64907") -- Depot 3234851
setManifestid(3234851, "178835571339018934", 168856196)