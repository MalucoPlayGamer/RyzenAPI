-- Lua provided by RyzenAPI
-- Game: Bingo Pinball Gameroom

-- MAIN APPLICATION
addappid(2370030)
-- Game: addappid(2370030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370032,0,"9bf074e844fe75663916be1a173aefc3451a49e73c2593dc378318bcc0bd6881")
addappid(2370033,0,"ca7fdbbbabe0efc6b3d9178c4c44b87b74f23a84ae722a570c6f9c77e7969595")
addappid(2509010,0,"35d0f1dcd3a2f1b61ad6c52427f174d1db02f6873f7111d862a94a0e0f4b7d1a")
