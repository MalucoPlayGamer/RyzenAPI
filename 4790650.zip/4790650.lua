-- 4790650's Lua and Manifest Created by Hubcap Manifest
-- Forge Maiden
-- Created: August 07, 2026 at 23:04:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4790650) -- Forge Maiden
-- MAIN APP DEPOTS
addappid(4790651, 1, "472005944cb57f90aa7c58410e34d05929769caf6e50e105f73760eb5e5f4ebd") -- Depot 4790651
setManifestid(4790651, "8678020293751386080", 3534305114)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4807330) -- Forge Maiden Supporter Pack