-- Lua provided by RyzenAPI
-- Game: Forge Maiden

-- MAIN APPLICATION
addappid(4790650) -- Forge Maiden
addappid(4807330) -- Forge Maiden Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4790651, 1, "472005944cb57f90aa7c58410e34d05929769caf6e50e105f73760eb5e5f4ebd") -- Depot 4790651

