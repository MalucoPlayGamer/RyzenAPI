-- Lua provided by RyzenAPI
-- Game: Akuya

-- MAIN APPLICATION
addappid(545490)

-- MAIN APP DEPOTS / PACKAGES
addappid(545491,0,"470e34118ae18725228e45f81c8354492ac3f0494afda06d55ff04ecc3b057ad")

