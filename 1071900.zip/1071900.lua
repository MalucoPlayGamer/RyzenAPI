-- Lua provided by RyzenAPI
-- Game: addappid(1071900)

-- MAIN APPLICATION
addappid(1071900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071901, 1, "ac58d66f2f955f8fbb02b8403546c0b92266a8546f2f7f3623da11d9188e348c")
