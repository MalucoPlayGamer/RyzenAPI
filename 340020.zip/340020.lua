-- Lua provided by RyzenAPI
-- Game: NoseBound

-- MAIN APPLICATION
addappid(340020)

-- MAIN APP DEPOTS / PACKAGES
addappid(340021,0,"3e7c19c6b14c85d52b241db9004562772cc8f3467de1ed2e65cb14804fbb1ad4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
