-- Lua provided by RyzenAPI
-- Game: NoseBound

-- MAIN APPLICATION
addappid(340020)

-- MAIN APP DEPOTS / PACKAGES
addappid(340021,0,"3e7c19c6b14c85d52b241db9004562772cc8f3467de1ed2e65cb14804fbb1ad4")

