-- Lua provided by RyzenAPI
-- Game: addappid(6910)

-- MAIN APPLICATION
addappid(6910)

-- MAIN APP DEPOTS / PACKAGES
addappid(6911, 1, "cf2a169df8a3d3b3f57cfc63beb733d6b57fa66bf7fece02cda285f12c026905")
