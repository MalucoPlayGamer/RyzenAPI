-- Lua provided by RyzenAPI
-- Game: 1554010

-- MAIN APPLICATION
addappid(1554010)
-- Game: addappid(1554010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554011, 1, "af8315d33c3010fd388c8b64db73bc99b850a9d24a1c8b41df0acc415e7aac64")
