-- Lua provided by RyzenAPI
-- Game: 我的变色龙女友My Chameleon Girlfriend

-- MAIN APPLICATION
addappid(1554010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554011, 1, "af8315d33c3010fd388c8b64db73bc99b850a9d24a1c8b41df0acc415e7aac64")
