-- Lua provided by RyzenAPI
-- Game: Hentai Furry Pig

-- MAIN APPLICATION
addappid(4492190) -- Hentai Furry Pig

-- MAIN APP DEPOTS / PACKAGES
addappid(4492191, 1, "82d8dcdc0da4cd0f4369510e85c2689fc07b85612ae802de8a502ee8d52a6c63") -- Depot 4492191

