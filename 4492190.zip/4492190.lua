-- 4492190's Lua and Manifest Created by Hubcap Manifest
-- Hentai Furry Pig
-- Created: August 17, 2026 at 14:33:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4492190) -- Hentai Furry Pig
-- MAIN APP DEPOTS
addappid(4492191, 1, "82d8dcdc0da4cd0f4369510e85c2689fc07b85612ae802de8a502ee8d52a6c63") -- Depot 4492191
setManifestid(4492191, "4439353886460127884", 202141508)