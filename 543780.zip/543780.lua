-- Lua provided by RyzenAPI
-- Game: Game: AppID 543780

-- MAIN APPLICATION
addappid(543780)
-- Game: addappid(543780)

-- MAIN APP DEPOTS / PACKAGES
addappid(543781, 1, "28dfe26606f21b413e6321eac32d4956fe9dfcc71487fc4495387499fee1b27b")
