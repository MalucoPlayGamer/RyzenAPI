-- Lua provided by RyzenAPI 
-- Game: STUG
addappid(1920500)
addappid(1920501, 1, "c98b20136f839f78ec8a56120e3d29ecaba9228580639646cb9fcee337f8fa0b")
