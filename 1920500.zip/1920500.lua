-- Lua provided by RyzenAPI
-- Game: STUG

-- MAIN APPLICATION
addappid(1920500)
-- Game: addappid(1920500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920501, 1, "c98b20136f839f78ec8a56120e3d29ecaba9228580639646cb9fcee337f8fa0b")
