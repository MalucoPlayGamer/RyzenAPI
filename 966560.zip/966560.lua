-- Lua provided by RyzenAPI
-- Game: addappid(966560)

-- MAIN APPLICATION
addappid(966560)

-- MAIN APP DEPOTS / PACKAGES
addappid(966561, 1, "f35c5d8c6dc56bcc6dc855f35662de83854d95581d5335bb6fe5e7246f7f3fc8")
