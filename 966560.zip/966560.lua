-- Lua provided by RyzenAPI
-- Game: ROGAN: The Thief in the Castle

-- MAIN APPLICATION
addappid(966560)
addappid(1100020)
addappid(1102920)
addappid(1102921)
addappid(1102922)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(966561,0,"f35c5d8c6dc56bcc6dc855f35662de83854d95581d5335bb6fe5e7246f7f3fc8")
addappid(1102920,0,"82bc5bbf7bd4d4f8d181e722f7ef1d6be8eb8b933c2072041eae30ef63a12b3a")
addappid(1102921,0,"b05c69dfce24a0293f486237b21d97e2a6e1937efced1adbaf1fc8c2f8e6ec74")

