-- Lua provided by RyzenAPI
-- Game: Power Rangers: Battle for the Grid

-- MAIN APPLICATION
addappid(1110100)
addappid(1117450)
addappid(1120460)
addappid(1120461)
addappid(1136310)
addappid(1136311)
addappid(1136312)
addappid(1136313)
addappid(1147380)
addappid(1147381)
addappid(1147382)
addappid(1147383)
addappid(1331010)
addappid(1331011)
addappid(1331020)
addappid(1331021)
addappid(1605840)
addappid(1605870)
addappid(1605871)
addappid(1605872)
addappid(1605873)
addappid(1711030)
addappid(1711031)
addappid(1711032)
addappid(1711033)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110101,0,"1fd55a19345044b7eaaaca3fc753bf8178b5368d2214c15d013f68b29db8a4a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
