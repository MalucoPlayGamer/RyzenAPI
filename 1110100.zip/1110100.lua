-- Lua provided by RyzenAPI
-- Game: 1110100

-- MAIN APPLICATION
addappid(1110100)
addappid(1117450)
addappid(1120460)
addappid(1120461)
-- Game: addappid(1110100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110101, 1, "1fd55a19345044b7eaaaca3fc753bf8178b5368d2214c15d013f68b29db8a4a1")
