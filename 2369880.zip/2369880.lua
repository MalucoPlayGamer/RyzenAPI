-- Lua provided by RyzenAPI
-- Game: Dungeon Survival

-- MAIN APPLICATION
addappid(2369880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2369881, 1, "c11328b9802ce878f3d9ae51541ab12f4c41bf0b6b29d14b670e2d521691aeda")

