-- Lua provided by RyzenAPI
-- Game: Dungeon Survival

-- MAIN APPLICATION
addappid(2369880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369881, 1, "c11328b9802ce878f3d9ae51541ab12f4c41bf0b6b29d14b670e2d521691aeda")
