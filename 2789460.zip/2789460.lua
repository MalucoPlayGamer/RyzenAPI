-- Lua provided by RyzenAPI
-- Game: Ale Abbey - Monastery Brewery Tycoon

-- MAIN APPLICATION
addappid(2789460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789461, 1, "266dc778b045f2700546991ea108ed40f7292d2220571673bb625e677c80bac9")

