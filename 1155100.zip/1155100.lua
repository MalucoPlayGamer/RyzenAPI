-- Lua provided by RyzenAPI
-- Game: AppID 1155100

-- MAIN APPLICATION
addappid(1155100)
-- Game: addappid(1155100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155101, 1, "aa5f7fc55b71721ae2fd7ed94cb58c51394169f54b65790603a1c665a0349d0e")
