-- Lua provided by RyzenAPI
-- Game: addappid(2332660)

-- MAIN APPLICATION
addappid(2332660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2332661, 1, "8b247f96220f819c8e6bc50e7c67ce166ccd00a69b710a37b59318cc19ee37ca")
