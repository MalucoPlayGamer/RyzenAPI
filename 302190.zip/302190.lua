-- Lua provided by RyzenAPI 
-- Game: Amerzone: The Explorer’s Legacy (1999)
addappid(302190)
addappid(302191, 1, "3aee4c6afd0e85bb888062b0ac797a18b8c7324f057423e8fa577c76eb127d70")
addappid(302192, 1, "af66cff71ea9db089b4c8a38bf3013b1b504fa9a3813b4f9cb456e2eb1b531b4")
addappid(302193, 1, "6a1f5593f7793d7e6eceb12550bb078c16fcd795801b9a0629d5b921ef01177b")
addappid(302194, 1, "0af99cc86fdbcb9f6f992e2f5d2b66a5abff689f48cebadb993fc522655a5d68")
addappid(302195, 1, "161c6a12dc51fc534e4734b621560a986bac8fc6e6fe1537cbed2e247b6a94e7")
addappid(302196, 1, "7a60d37d62c6ac324b720f9e71f8462dbc82742abad8793b619e97c037c65e3e")
