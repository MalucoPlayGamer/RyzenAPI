-- Lua provided by RyzenAPI
-- Game: Millennium Dream

-- MAIN APPLICATION
addappid(3470560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3470561,0,"c400239376934280aa7af1c97f0cc31bc639a354de507ad0f319a11714a4e23d")

