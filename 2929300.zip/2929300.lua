-- Lua provided by RyzenAPI
-- Game: QUESTSCAPE: Survival

-- MAIN APPLICATION
addappid(2929300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929301, 1, "fcf386e5c24dbc086db6df0f10c339147ef09fead51c80df8e5fe5366b68ecb7")

