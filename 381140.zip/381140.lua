-- Lua provided by RyzenAPI
-- Game: 381140

-- MAIN APPLICATION
addappid(381140)
-- Game: addappid(381140)

-- MAIN APP DEPOTS / PACKAGES
addappid(381141, 1, "c0dcd0f1fd446120abbba9d45d668ef577d7b3c0b40041472794f2cb538ec6f9")
