-- Lua provided by RyzenAPI
-- Game: Game: Table Ball

-- MAIN APPLICATION
addappid(2094090)
-- Game: addappid(2094090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094091, 1, "be129ecf604810cd6d17327e6857880e9f649bb053883799baab2de7b4a04645")
addappid(2094092, 1, "96c9086d803bc31dc7da4133ee52632846c008b2da387c62d665eb8d63fbc0b0")
addappid(2094093, 1, "f5aca4183cb0a676a9dcb3da888df71a69f1fc2a4e1709f469ab9143535cb601")
