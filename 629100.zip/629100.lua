-- Lua provided by RyzenAPI
-- Game: Cadenza: Music, Betrayal and Death Collector's Edition

-- MAIN APPLICATION
addappid(629100)

-- MAIN APP DEPOTS / PACKAGES
addappid(629101, 1, "863dc0c304a9abbdc5bbce60fd87308dd091fdfcdd49635425c480c5a6ec0550")
