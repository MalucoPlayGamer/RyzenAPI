-- Lua provided by RyzenAPI
-- Game: Game: Dark the Dead

-- MAIN APPLICATION
addappid(3025760)
-- Game: addappid(3025760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025761, 1, "58d651a78c8255b92618be00512ce97ae16c2343250b4471cbfebec1fcc244b5")
