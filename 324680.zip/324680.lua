-- Lua provided by RyzenAPI
-- Game: Game: Impossible Creatures Steam Edition

-- MAIN APPLICATION
addappid(324680)
-- Game: addappid(324680)

-- MAIN APP DEPOTS / PACKAGES
addappid(324681, 1, "b3fd3e2726a0841ca8defe09e1769d9156e65900535eee901ff48a79fc11673a")
addappid(324682, 1, "24e2d148be83197f5907a80c908b698dad718d4d0810ea0621db131b898096f3")
addappid(324683, 1, "b04fcbb88ea3abcc1796d7cf486f614026a9adc3f83e4f4504e140b9953f9a7e")
addappid(324684, 1, "870badc03e2b613f078c06c03e7cbcdd3232793fa42272a0b6530281a9166671")
addappid(324685, 1, "f7c8bc473a7cfb7fa144e56e927d19720884188283237c51f818376351cdfaa2")
