-- Lua provided by RyzenAPI
-- Game: Leisure Suit Larry 6 - Shape Up Or Slip Out

-- MAIN APPLICATION
addappid(765910)

-- MAIN APP DEPOTS / PACKAGES
addappid(765911, 1, "66d771aff0ee2689d95554f8fa59b6e9221dd0f3574294c8dd3f5c37213d3e15")

