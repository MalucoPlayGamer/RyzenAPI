-- Lua provided by RyzenAPI
-- Game: addappid(1219300)

-- MAIN APPLICATION
addappid(1219300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219302,0,"c1f4efa4ecfd3b079d4a5e1a08811bef5600bc5868efdb9452e347777705881d")
