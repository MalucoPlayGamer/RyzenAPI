-- Lua provided by RyzenAPI
-- Game: addappid(1805590)

-- MAIN APPLICATION
addappid(1805590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805591, 1, "8463f9ec9d2553611e3cfcf124e9f50b3bd43151e542cc131dd79198040af0c0")
