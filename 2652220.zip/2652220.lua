-- Lua provided by RyzenAPI
-- Game: 2652220

-- MAIN APPLICATION
addappid(2652220)
-- Game: addappid(2652220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2652221, 1, "da2a842826ec67a3124cd09fd593d88bdc4ad50eb815805f5912549dbe14f517")
