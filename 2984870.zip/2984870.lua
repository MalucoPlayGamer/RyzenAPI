-- Lua provided by RyzenAPI
-- Game: Game: Rabbit and Steel Soundtrack

-- MAIN APPLICATION
addappid(2984870)
-- Game: addappid(2984870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984871, 1, "b794d332bb63c9e0f0da3606648dbb2368bceb6c39165ba39d75012f9108e3f9")
addappid(2984872, 1, "524f3f6f37355bca5ec3b8a21d79f76fd6730a2e4e694696ea6400acd57a4d9e")
