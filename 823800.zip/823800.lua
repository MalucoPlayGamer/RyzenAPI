-- Lua provided by RyzenAPI
-- Game: Kitty Play

-- MAIN APPLICATION
addappid(823800)

-- MAIN APP DEPOTS / PACKAGES
addappid(823801,0,"12fd806b78b9a006c9d69b9388e3c2de216904f084391bf66a6f96494ece7225")
addappid(823802,0,"3ce47abdef3a3e58fdf7a3cd80cefc0dc4eff181cf2f6d2dcefb072eafd20109")
addappid(823803,0,"588ff08e9e7f0ad786d49ac43f2c432527540b1e2da9398effda8b47f64bc6c0")

