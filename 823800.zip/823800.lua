-- Lua provided by RyzenAPI
-- Game: Kitty Play

-- MAIN APPLICATION
addappid(823800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(823801,0,"12fd806b78b9a006c9d69b9388e3c2de216904f084391bf66a6f96494ece7225")
addappid(823802,0,"3ce47abdef3a3e58fdf7a3cd80cefc0dc4eff181cf2f6d2dcefb072eafd20109")
addappid(823803,0,"588ff08e9e7f0ad786d49ac43f2c432527540b1e2da9398effda8b47f64bc6c0")

