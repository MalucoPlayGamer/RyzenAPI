-- Lua provided by RyzenAPI
-- Game: Fish 'n Ships

-- MAIN APPLICATION
addappid(3704940)
-- Game: addappid(3704940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3704941, 1, "e3b62aad691b89fe774c988d47efe5b87733cac1e32faafab2e6f0e75f167269")
