-- Lua provided by RyzenAPI
-- Game: Bombunter

-- MAIN APPLICATION
addappid(3705490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3705491, 1, "12aeecbd5289c91c3dd29ed8c787a1855436aac2130976a930f6bd8dbb832cd4")
