-- Lua provided by RyzenAPI
-- Game: Game: Cursed Bet

-- MAIN APPLICATION
addappid(2460900)
-- Game: addappid(2460900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460901, 1, "debfd07445a9b103c6bd2caa947ea9254b689cebbd8e24832eb8cba849d1b9ed")
