-- Lua provided by RyzenAPI
-- Game: Game: a new life.

-- MAIN APPLICATION
addappid(1297160)
addappid(1316110)
-- Game: addappid(1297160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297161, 1, "90064446f49fafe45889fa65725e7d1ff4429ff46c7acccc3a15005197f337cc")
addappid(1297162, 1, "10c82cecfcd259269d23e759dec8dbe785f3cb79117ae5a6d62e99337237ce80")
addappid(1297163, 1, "304365f016cd0643b7699400ec9bfb9239a31e8bfed331016965352d4404d3c0")
