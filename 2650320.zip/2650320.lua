-- Lua provided by RyzenAPI
-- Game: addappid(2650320)

-- MAIN APPLICATION
addappid(2650320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650321, 1, "0a0649712ac08796a6f28dee43215f22f17a688861b164cd7317dd825eefbde6")
