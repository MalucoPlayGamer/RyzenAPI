-- Lua provided by RyzenAPI 
-- Game: POWERNAUT DECAY
addappid(2650320)
addappid(2650321, 1, "0a0649712ac08796a6f28dee43215f22f17a688861b164cd7317dd825eefbde6")
