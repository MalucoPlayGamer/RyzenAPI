-- Lua provided by RyzenAPI
-- Game: Four Kings One War - Virtual Reality

-- MAIN APPLICATION
addappid(932600)
addappid(932601)
-- Game: addappid(932600)

-- MAIN APP DEPOTS / PACKAGES
addappid(932600,0,"05613cd1b476d7c9fa09af759470b2f7a268fa4db1bb29a1b28bc797ca61a8b3")
