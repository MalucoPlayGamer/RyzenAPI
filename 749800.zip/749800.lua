-- Lua provided by RyzenAPI
-- Game: AppID 749800

-- MAIN APPLICATION
addappid(749800)

-- MAIN APP DEPOTS / PACKAGES
addappid(749801, 1, "2fe100792ba92b7770a45c06eb09a189caba54547335949e4d79718054725e05")
addappid(793860, 0, "3e87d579053a28fe428a88f1cac2bcd64b2ceb4849ebf2d2d8eda13071155d30")
addappid(793861, 0, "96d87a38550c312e263284ff423b1ea1aa208d0966fd65cfba9dac401a771b61")
addappid(854010, 0, "874e564bbf4050971a4af74d8cc42c09d333f6763aa82f85d329a7479f4174af")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(856020)
