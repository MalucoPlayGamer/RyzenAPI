-- Lua provided by RyzenAPI
-- Game: Game: Halfway

-- MAIN APPLICATION
addappid(253150)
-- Game: addappid(253150)

-- MAIN APP DEPOTS / PACKAGES
addappid(253151, 1, "d0581e243c602ab3d8839886f6985926ae17d3f04b6d714bc2b928339994db72")
addappid(253152, 1, "9a504fd8fba7ed049fa98b591136e1b52c221ea6182d14eca8262b4e691ff132")
addappid(253153, 1, "eaf5e337be86298362252e6b16dc1fb86db4a4009e18bc0f866cad6b1a71b046")
addappid(253154, 1, "4b1eebeb9a305c8219de73e1de67a4ca4feecfb72089c07ad163cf5e2c3f76da")
