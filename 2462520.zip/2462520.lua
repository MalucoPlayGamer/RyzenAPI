-- Lua provided by RyzenAPI
-- Game: I'm on Observation Duty 7

-- MAIN APPLICATION
addappid(2462520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462521, 1, "f4b0a0d97098ab3c5ce7a7aa4a7706a3a2068a75ac0797988bf046afb51fa8ac")
addappid(2462522, 1, "e1c314b4a036bbae337e561fc2aa3fa5fb3ae20522c67bb9dbcf49d10b603b2e")
addappid(2462523, 1, "bcc77e77d2a3f8539c2b12090e9cd4941a0aa0f8dc1325afaac2c9e6e7a1b807")
