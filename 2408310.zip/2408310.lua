-- Lua provided by RyzenAPI
-- Game: Cat

-- MAIN APPLICATION
addappid(2408310)

