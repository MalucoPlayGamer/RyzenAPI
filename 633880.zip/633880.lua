-- Lua provided by RyzenAPI
-- Game: Lone Warrior

-- MAIN APPLICATION
addappid(633880)

-- MAIN APP DEPOTS / PACKAGES
addappid(633881, 1, "091aebbe01030a7356db011ac95ac70d09a108df5dbba86f313ca460739e58ea")

