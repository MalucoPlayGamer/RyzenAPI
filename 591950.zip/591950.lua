-- Lua provided by RyzenAPI
-- Game: Game: AppID 591950

-- MAIN APPLICATION
addappid(591950)
-- Game: addappid(591950)

-- MAIN APP DEPOTS / PACKAGES
addappid(591951, 1, "4002f6f0709947aab1ab008bea8670c40055f0520ad47bbb440b012030188dac")
