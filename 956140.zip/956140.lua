-- Lua provided by RyzenAPI
-- Game: 956140

-- MAIN APPLICATION
addappid(956140)
-- Game: addappid(956140)

-- MAIN APP DEPOTS / PACKAGES
addappid(956141, 1, "ffeebdb4e0f90a8e212ac2171e953332ca0fc33bf6da5e9f90858a5eba192f6a")
