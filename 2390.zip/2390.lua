-- Lua provided by RyzenAPI
-- Game: addappid(2390)

-- MAIN APPLICATION
addappid(2390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391, 1, "2563e199dddbea163dc4d0ec2a908a1980e7bc09ea3e5d9e09cc41943e9ca690")
