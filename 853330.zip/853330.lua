-- Lua provided by RyzenAPI
-- Game: N.I.C.E. 2

-- MAIN APPLICATION
addappid(853330)

-- MAIN APP DEPOTS / PACKAGES
addappid(853331, 1, "97e3b80bea5a16d59406bc403faea459d22ab705297e568a0c7d6a314bc53672")
