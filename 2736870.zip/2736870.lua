-- Lua provided by RyzenAPI 
-- Game: Kill It With Fire 2 Demo
addappid(2736870)
addappid(2736871, 1, "c8a40b700f891728a3000a942056fc14cb74cd7a24c2bcf93c7c5cd61264a45f")
