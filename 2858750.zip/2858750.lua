-- Lua provided by RyzenAPI
-- Game: Oh Boy Cheese Remastered

-- MAIN APPLICATION
addappid(2858750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858751,0,"2d0610b471ec714af2ff1e8266d32016b08ab443c848f5d701c74a7fadd28659")

