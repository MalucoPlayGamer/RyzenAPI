-- Lua provided by RyzenAPI
-- Game: The Inheritance of Crimson Manor

-- MAIN APPLICATION
addappid(1553120)
addappid(3506360)
-- Game: addappid(1553120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553121, 1, "d2e51c927ce792457ab9cc2fcbfabae4132907ead4e91d633dbd1dd398c45d9d")
