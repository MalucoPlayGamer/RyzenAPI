-- Lua provided by RyzenAPI
-- Game: RuneTech

-- MAIN APPLICATION
addappid(857890)

-- MAIN APP DEPOTS / PACKAGES
addappid(857891,0,"c09e499aff9349b985d4e1282dba21794f58b93505676d894054dde14aec9bfa")
addappid(857892,0,"cdf998fd439c1c34db403f827a2abaafc52165494080f36998d5cabeae2f2e5a")
addappid(857893,0,"7a1bdbb52795ca4178fa1b91751c8282e431270b4d73dca5c6f189f72a0c701c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
