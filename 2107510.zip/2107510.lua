-- Lua provided by RyzenAPI
-- Game: 2107510

-- MAIN APPLICATION
addappid(2107510)
-- Game: addappid(2107510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107510,0,"3b0af1076eca77b7becd91fffc4698281fef99bc06ba98c1dd31f11aa63b5f8c")
addtoken(2107510,"17624319664149755126")
