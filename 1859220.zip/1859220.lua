-- Lua provided by RyzenAPI
-- Game: 1859220

-- MAIN APPLICATION
addappid(1859220)
-- Game: addappid(1859220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859221, 1, "169c3593f21edb30d124c8dc8cf8fc4b53d2379991740b7a9449feeff80ae967")
