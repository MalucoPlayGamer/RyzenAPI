-- 2836460's Lua and Manifest Created by Hubcap Manifest
-- Cozy Marbles
-- Created: August 21, 2026 at 01:45:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2836460, 1, "4965c40afbdaedbd56ae82b06c0530fee8509258ebb9871551f0651db6276f82") -- Cozy Marbles
-- MAIN APP DEPOTS
addappid(2836461, 1, "0b3cb666e077e5f57a0dfa71354ed500cde016907918ab5862064177cc524f40") -- Depot 2836461
setManifestid(2836461, "3088717109680510707", 883931058)
-- DLCS WITH DEDICATED DEPOTS
-- Cozy Marbles - Supporter Pack (AppID: 4870440)
addappid(4870440)
addappid(4870441, 1, "4ce00a3d126f4382e474d7d316a64a2a5d57ec17544c0bf62d6868ef2333d6f0") -- Cozy Marbles - Supporter Pack - Depot 4870441
setManifestid(4870441, "3344556138053724634", 238491423)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4870440) -- Depot 4870440 (empty depot)