-- Lua provided by RyzenAPI
-- Game: addappid(488590)

-- MAIN APPLICATION
addappid(488590)

-- MAIN APP DEPOTS / PACKAGES
addappid(488591, 1, "463ebc1e6e0d08b7ac17a925e8960474b170394cc272d2d66c356539c9e9667d")
