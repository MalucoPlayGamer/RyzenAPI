-- Lua provided by RyzenAPI 
-- Game: AppID 488590
addappid(488590)
addappid(488591, 1, "463ebc1e6e0d08b7ac17a925e8960474b170394cc272d2d66c356539c9e9667d")
