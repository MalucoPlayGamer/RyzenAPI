-- Lua provided by RyzenAPI
-- Game: Space Robinson: Hardcore Roguelike Action

-- MAIN APPLICATION
addappid(953870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(953871, 1, "3d3b65c29a9c6fc335ef0e00f3c4bd84daa316f4fe26c129050bdbf7cb821994")
addappid(953872, 1, "5254ac4f817eb437d684b24acb3d65a918918f16e522042c7055e35b05160c94")
addappid(953873, 1, "2bed80ce58f7c087e34070f664744ab820c4a3b2ceabaccc2d8da46f13d7962e")

