-- Lua provided by RyzenAPI
-- Game: Hydroneer

-- MAIN APPLICATION
addappid(1106840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1106841, 1, "114df5212d170463951d552d5a36142d36654afbb6117152ad0cc34fee155477")
addappid(2659380, 0, "a4dbcd198ebee0417d9d38e429a3089d950b236f5834f4b33c552f8c58df9ed2")
