-- Lua provided by RyzenAPI 
-- Game: Cubotrox
addappid(526800)
addappid(526801, 1, "68f73820ffcc2481693f6c609970c1ff8ca3e7d3f9ac21a9a8115f9b6af1d5d9")
addappid(526802, 1, "0e56b5b8c6e4199fe40e0cba909d8414833305931dba704aea540efded354d45")
addappid(526803, 1, "a44c04757f9c9e8016b9f92eba7073d63b7653d9bb945eea180be8138a5c8664")
