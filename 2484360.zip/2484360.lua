-- Lua provided by RyzenAPI
-- Game: Please, Forgive Me

-- MAIN APPLICATION
addappid(2484360)
-- Game: addappid(2484360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484361, 1, "47945dab07d43e704f8123f91378c7da3e59edaa742e542bbaf2e0979b1bb272")
