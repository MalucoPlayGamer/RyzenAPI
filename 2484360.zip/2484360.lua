-- Lua provided by RyzenAPI
-- Game: Please, Forgive Me

-- MAIN APPLICATION
addappid(2484360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2484361, 1, "47945dab07d43e704f8123f91378c7da3e59edaa742e542bbaf2e0979b1bb272")

