-- Lua provided by RyzenAPI
-- Game: AppID 790610

-- MAIN APPLICATION
addappid(790610)
-- Game: addappid(790610)

-- MAIN APP DEPOTS / PACKAGES
addappid(790611, 1, "e1ff1cf20f52f872edd17dbe4e047d1d0d58d8130824bd8e7b231f5cf6b85975")
