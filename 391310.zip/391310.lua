-- Lua provided by RyzenAPI
-- Game: 391310

-- MAIN APPLICATION
addappid(391310)
addappid(601690)
-- Game: addappid(391310)

-- MAIN APP DEPOTS / PACKAGES
addappid(391311, 1, "964912d770987c664fe9afb08ae11888efacb61600de657990b915360e727dc6")
