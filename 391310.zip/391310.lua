-- Lua provided by RyzenAPI
-- Game: Alien Attack

-- MAIN APPLICATION
addappid(391310)
addappid(601690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(391311, 1, "964912d770987c664fe9afb08ae11888efacb61600de657990b915360e727dc6")

