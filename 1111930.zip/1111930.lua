-- Lua provided by RyzenAPI
-- Game: Game: Underspace

-- MAIN APPLICATION
addappid(1111930)
-- Game: addappid(1111930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111931, 1, "706597de7cd9dd2b7c65b15cc6c365e43553ecebda513be74f31eac28600f624")
