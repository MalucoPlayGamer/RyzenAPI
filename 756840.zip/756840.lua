-- Lua provided by RyzenAPI
-- Game: 摩尼遊戯TOKOYO

-- MAIN APPLICATION
addappid(756840)

-- MAIN APP DEPOTS / PACKAGES
addappid(756844,0,"493e3aaead8f02c6ce4aa0fc7b1e1f92081355a9a2eefe52214a8334c1afd64e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
