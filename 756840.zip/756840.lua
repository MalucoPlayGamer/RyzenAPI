-- Lua provided by RyzenAPI
-- Game: setManifestid(756844,"7172335554905185417")

-- MAIN APPLICATION
addappid(756840)

-- MAIN APP DEPOTS / PACKAGES
addappid(756844,0,"493e3aaead8f02c6ce4aa0fc7b1e1f92081355a9a2eefe52214a8334c1afd64e")
