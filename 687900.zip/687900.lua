-- Lua provided by RyzenAPI
-- Game: unWorded

-- MAIN APPLICATION
addappid(687900)

-- MAIN APP DEPOTS / PACKAGES
addappid(687901, 1, "59aaa7b7f7493a02649db3985482da3502f3856e29ffa72b7e3e54ba0fa29177")
addappid(687902, 1, "4537917bc3238b98d0d407e97e7a86deaec01e2998c238e8419e2cfeb89d54f2")

