-- Lua provided by RyzenAPI 
-- Game: Furry Aim Trainer
addappid(2940490)
addappid(2940491, 1, "acb7f9e48ea2bca6750bbed6a329bafa85966f29553dc320180d270527096969")
