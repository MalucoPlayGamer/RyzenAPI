-- Lua provided by RyzenAPI
-- Game: DFF NT: Violet Robe Appearance Set for the Emperor

-- MAIN APPLICATION
addappid(1022476)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022476,0,"95e5e5674a22d243462422b5a8353eb5b61fdabb11b1d8f169dac7344d5c194d")

