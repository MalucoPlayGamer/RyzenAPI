-- Lua provided by RyzenAPI
-- Game: 2341530

-- MAIN APPLICATION
addappid(2341530)
-- Game: addappid(2341530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341531, 1, "6fbfc7d49c46282475628873f4a839c23f6de01e5fcc6c43f3163d14a146f719")
