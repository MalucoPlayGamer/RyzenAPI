-- Lua provided by RyzenAPI
-- Game: Game: AppID 918670

-- MAIN APPLICATION
addappid(918670)
-- Game: addappid(918670)

-- MAIN APP DEPOTS / PACKAGES
addappid(918671, 1, "7c53d7cac6803501904ab005f46dc5449cf7037c415b6c37f39e38b3c0662d5e")
