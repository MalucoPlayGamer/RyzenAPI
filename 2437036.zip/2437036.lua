-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Berlin Brandenburg V2

-- MAIN APPLICATION
addappid(2437036)
-- Game: addappid(2437036)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437036,0,"d12c11c1af13a3fd8a826cfadb529812ff88a60df1183a392320ca59458ded53")
