-- Lua provided by RyzenAPI
-- Game: AppID 3510750

-- MAIN APPLICATION
addappid(3510750)
-- Game: addappid(3510750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3510751, 1, "2cc7bc496bf527088049ecac1271d1fdee46a83bdd58e5b7ddbd8eaf6de1be80")
