-- Lua provided by RyzenAPI
-- Game: Depths Of Horror: Mushroom Day

-- MAIN APPLICATION
addappid(1590840)
-- Game: addappid(1590840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590841, 1, "17dd82949e7d040fd9977dd1114bd67d6507a76a6e6a101984c2413542a3325e")
