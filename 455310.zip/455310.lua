-- Lua provided by RyzenAPI
-- Game: addappid(455310)

-- MAIN APPLICATION
addappid(455310)

-- MAIN APP DEPOTS / PACKAGES
addappid(455311, 1, "bd9e9847673eaca8193bfb89e6fc91c26f1900a1561372be7adc700ac95659b9")
