-- Lua provided by RyzenAPI
-- Game: It's a Gluttonous Life

-- MAIN APPLICATION
addappid(2478730)
-- Game: addappid(2478730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478731, 1, "33d30763763f679b85d792e31e990b4d68f5d2e4610a7b7576e9d08ffbeb21ec")
