-- Lua provided by RyzenAPI
-- Game: Game: Witch & Bun Cats

-- MAIN APPLICATION
addappid(2591360)
-- Game: addappid(2591360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591361, 1, "253e242abd060cec68e14b2f979efa1330e8169f169fd6002802fb8ea0d300a7")
