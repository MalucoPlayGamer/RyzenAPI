-- Lua provided by RyzenAPI
-- Game: 1392390

-- MAIN APPLICATION
addappid(1392390)
-- Game: addappid(1392390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392391, 1, "764d86bea3fcffc58e89dea1f1688f957b5b540ec1f600a6dadb8842dd73cadc")
