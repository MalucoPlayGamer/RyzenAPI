-- Lua provided by RyzenAPI 
-- Game: Mini Star Quest
addappid(3491430)
addappid(3491431, 1, "771e7393772807bb5684990054782609bc7351a5ab3a40103d08d983c57569c5")
