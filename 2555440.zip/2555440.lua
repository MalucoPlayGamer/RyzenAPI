-- Lua provided by RyzenAPI
-- Game: Game: The Mythical City

-- MAIN APPLICATION
addappid(2555440)
-- Game: addappid(2555440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555441, 1, "f72b8ce6d108289e8b8a33d6034b16bcfb4a0bb35880ef9521672bd111d0e7ab")
