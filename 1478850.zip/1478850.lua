-- Lua provided by RyzenAPI
-- Game: Vendir: Plague of Lies

-- MAIN APPLICATION
addappid(1478850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1478851, 1, "996ea734501c30742789b0168b312fd19fda1cb77b41291f27ad49a5f0274ac5")

