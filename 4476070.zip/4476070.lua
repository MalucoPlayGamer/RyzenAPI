-- Lua provided by RyzenAPI
-- Game: Astrophobia

-- MAIN APPLICATION
addappid(4476070) -- Astrophobia

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4476073, 1, "ebba9f7804e9b44ed1ee582453f3be4144aa01ccb975e950fbba2ae502207eaf") -- Depot 4476073

