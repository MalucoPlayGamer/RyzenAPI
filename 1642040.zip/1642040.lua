-- Lua provided by RyzenAPI
-- Game: AppID 1642040

-- MAIN APPLICATION
addappid(1642040)
-- Game: addappid(1642040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642041, 1, "26e7e59e2ac5ed5e8a2ff8e3c9fcf71f6728e68d4359b4e384c1b68cb8f23e9a")
