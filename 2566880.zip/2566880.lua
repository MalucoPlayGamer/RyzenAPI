-- Lua provided by RyzenAPI
-- Game: MOOD

-- MAIN APPLICATION
addappid(2566880)
addappid(4205890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566881, 1, "f9dfa593ff18e41b74e0a6d249476c53e87f19ace72190d265cadef19b08ff31")

