-- Lua provided by RyzenAPI
-- Game: Little Marisa's Disaster Journey

-- MAIN APPLICATION
addappid(838940)

-- MAIN APP DEPOTS / PACKAGES
addappid(838941, 1, "a1e42c3b4cf5cd1add3eebdd0ba362150c416038b336042062c42f25735211ee")

