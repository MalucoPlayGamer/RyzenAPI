-- Lua provided by RyzenAPI
-- Game: 2968180

-- MAIN APPLICATION
addappid(2968180)
-- Game: addappid(2968180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968181, 1, "ba33540742d0d2e5b27657956e0dee0ce6747b50a26e2093b230c55f8afbf43d")
