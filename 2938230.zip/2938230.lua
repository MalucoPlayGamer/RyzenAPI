-- Lua provided by RyzenAPI
-- Game: Sealed Bite: Extended Demo

-- MAIN APPLICATION
addappid(2938230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938234,0,"fd2b76e92997220389ddd239d47cfc09ed4198937c34c38796642f4a9eefa210")

