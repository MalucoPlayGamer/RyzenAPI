-- Lua provided by RyzenAPI 
-- Game: AppID 2619740
addappid(2619740)
addappid(2619741, 1, "e2f33e7583ca3f73d60310b736095582e447c8ad5042818cbce37a37b2480ed0")
