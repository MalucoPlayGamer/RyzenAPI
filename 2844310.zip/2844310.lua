-- Lua provided by RyzenAPI 
-- Game: Minigames Mayhem
addappid(2844310)
addappid(2844311, 1, "85cd51f2b78677c2d7266e1dcd5af6ab66940584571c50f5ef36de0c600868d3")
