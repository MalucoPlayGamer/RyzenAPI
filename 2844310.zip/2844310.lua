-- Lua provided by RyzenAPI
-- Game: Game: Minigames Mayhem

-- MAIN APPLICATION
addappid(2844310)
-- Game: addappid(2844310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844311, 1, "85cd51f2b78677c2d7266e1dcd5af6ab66940584571c50f5ef36de0c600868d3")
