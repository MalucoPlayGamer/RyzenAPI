-- Lua provided by RyzenAPI
-- Game: Game: AppID 566990

-- MAIN APPLICATION
addappid(566990)
-- Game: addappid(566990)

-- MAIN APP DEPOTS / PACKAGES
addappid(566991, 1, "86248b09c1489e11a3210fa2ab98408e3c111d3bc15c47492332e011019bd58d")
