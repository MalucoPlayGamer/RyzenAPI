-- Lua provided by RyzenAPI
-- Game: Paze Knight Ellen and the Dungeon town Sodom

-- MAIN APPLICATION
addappid(1997130)
addappid(2323450)
-- Game: addappid(1997130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997131, 1, "8b3749b3b893659a5beae7123a8d560eae74aa3845e3c0c45ce8092ce8a23b08")
