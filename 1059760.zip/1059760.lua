-- Lua provided by RyzenAPI
-- Game: Game: AppID 1059760

-- MAIN APPLICATION
addappid(1059760)
-- Game: addappid(1059760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059761, 1, "c4c2df1557af69d65b85a3be1fe8f0691ab0de03e803e35defbef4cc03c8eacf")
