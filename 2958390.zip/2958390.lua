-- Lua provided by RyzenAPI
-- Game: AppID 2958390

-- MAIN APPLICATION
addappid(2958390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958391, 1, "4b6fe5b9b354daaf25f3a77b271849bd6b3163a0706d5a78f35ab38e0f1bed46")

