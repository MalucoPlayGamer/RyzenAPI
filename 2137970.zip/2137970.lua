-- Lua provided by RyzenAPI 
-- Game: 喵之旅人 Demo
addappid(2137970)
addappid(2137971, 1, "5240b3e8a65f99aa40acafdee052a0dbe553d5b62e0ad6e02192976632ecea1b")
