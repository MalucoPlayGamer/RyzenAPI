-- Lua provided by SkyAPI 
-- Game: Race With Ryan
addappid(1054990)
addappid(1054991, 1, "5b91d2beb5401eb156ce4c72fee77e668cad566ad5e4cc84031c190d2db531f5")
