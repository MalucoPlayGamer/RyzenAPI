-- Lua provided by RyzenAPI
-- Game: Race With Ryan

-- MAIN APPLICATION
addappid(1054990)
-- Game: addappid(1054990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054991, 1, "5b91d2beb5401eb156ce4c72fee77e668cad566ad5e4cc84031c190d2db531f5")
