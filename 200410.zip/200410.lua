-- Lua provided by RyzenAPI
-- Game: SOL: Exodus

-- MAIN APPLICATION
addappid(200410)
addappid(209990)
addappid(209991)

-- MAIN APP DEPOTS / PACKAGES
addappid(200411, 1, "a82927905a9c90d02599ca3b10c4bb19ad09b01f9d67ddf348faa95d96df7256")
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)

