-- Lua provided by RyzenAPI
-- Game: addappid(200410)

-- MAIN APPLICATION
addappid(200410)

-- MAIN APP DEPOTS / PACKAGES
addappid(200411, 1, "a82927905a9c90d02599ca3b10c4bb19ad09b01f9d67ddf348faa95d96df7256")
