-- Lua provided by RyzenAPI
-- Game: AppID 485460

-- MAIN APPLICATION
addappid(485460)

-- MAIN APP DEPOTS / PACKAGES
addappid(485461, 1, "5131d8aebabbdfbd6909338cef76a6bb60f6a3fe481c00a504024ce138f11dc4")
addappid(485462, 1, "2d10d46425ebec9be6336cebc5815ba12255404e9626149fb600f853b32755df")
addappid(485463, 1, "860fd97160dd63d80400d18806b9392bfaa425ff7438a7c6a0337e25580b6158")
addappid(485466, 1, "98fdb412eb06f929c7d3fb500d561c8aced0dbdd8bacc1ce5a2152db5b1f3d44")
addappid(485467, 1, "3b1b6c291821d8653984161741fa9b4064142790a795406d406eac745a542d0a")
addappid(865730, 0, "7ff7c0b8b862e0bf4d1d125a14023033eb583be16688e59784aa941979056884")
addappid(870848, 0, "990a41f94fe1c1543c5fd37fd1beba8be6b0fc09307a97620a00405f8a698544")
addappid(870849, 0, "3a0d8657fcf5154cc8f56bf77a3da5caae2da0567bdff676f64455dca558a209")
addappid(910030, 0, "4fc156ce52fc611fbd060ef20d6d2e44357c70aeba77a5d48003a24478de361b")
addappid(911590, 0, "a5ef847f57553c68b58210921e326d7346c00530c6bf01087d9e5303b28f6fcf")
addappid(958730, 0, "95e35a25d48d5728b0ce92febaa1430b537eaed949466b952f4d719cef526512")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(533650)
addappid(870840)
addappid(870841)
addappid(870842)
addappid(870843)
addappid(870844)
addappid(870845)
addappid(870846)
addappid(870847)
addappid(870850)
addappid(870851)
addappid(870852)
addappid(870853)
addappid(870854)
addappid(903100)
addappid(907120)
addappid(911000)
