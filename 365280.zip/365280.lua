-- Lua provided by RyzenAPI
-- Game: 365280

-- MAIN APPLICATION
addappid(365280)
-- Game: addappid(365280)

-- MAIN APP DEPOTS / PACKAGES
addappid(365281, 1, "643a7b3e0686bd3080ea4076ccbce7d466dd809cb92bedd87b933344bd6bffc8")
