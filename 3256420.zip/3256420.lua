-- Lua provided by RyzenAPI
-- Game: 3256420

-- MAIN APPLICATION
addappid(3256420)
-- Game: addappid(3256420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3256421, 1, "113752287ce8c5d03ccd3cd2509532519ff97c8f0f2ddd390c2de79ea5de9f2e")
