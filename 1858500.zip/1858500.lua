-- Lua provided by RyzenAPI
-- Game: addappid(1858500)

-- MAIN APPLICATION
addappid(1858500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858501, 1, "917ad1c14f74dad562e66a1c47f53d97a4ff2ab41717aaa4c1fa6d895ab9e59a")
