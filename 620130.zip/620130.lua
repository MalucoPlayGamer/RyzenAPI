-- Lua provided by RyzenAPI
-- Game: 620130

-- MAIN APPLICATION
addappid(620130)
addappid(640390)
-- Game: addappid(620130)

-- MAIN APP DEPOTS / PACKAGES
addappid(620131, 1, "9bc22287b0c840416a4ec12253e1ddd0cbbe4e739e30c38304f76dd866e8d27e")
