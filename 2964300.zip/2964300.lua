-- Lua provided by RyzenAPI
-- Game: City Bus Simulator 2024

-- MAIN APPLICATION
addappid(2964300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964301, 1, "2881b5eb149171d1043d38d0e97e51502b11f41b8a718a87b5ead30fe88595bd")

