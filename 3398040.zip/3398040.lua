-- Lua provided by RyzenAPI
-- Game: Unrailed 2: Back on Track – Soundtrack

-- MAIN APPLICATION
addappid(3398040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3398050,0,"5dcc0dfd9e1e3c98cb265b2b4a9492eef4b3fd9f270e7576b2e6ed1feb28f07c")
addappid(3398051,0,"e3a1280804b4895be2fa660fd9809e9a36c712d0b8dcc6ba9bd360fca376c1be")
