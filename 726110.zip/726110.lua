-- Lua provided by RyzenAPI
-- Game: 726110

-- MAIN APPLICATION
addappid(726110)
-- Game: addappid(726110)

-- MAIN APP DEPOTS / PACKAGES
addappid(726111, 1, "4845f2c6c3547897e98ffbf62233c51c623652c3f1724691bbaffedfb921b7ad")
