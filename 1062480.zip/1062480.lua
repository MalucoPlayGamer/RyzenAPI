-- Lua provided by RyzenAPI
-- Game: Songs of Skydale

-- MAIN APPLICATION
addappid(1062480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062481, 1, "6a3e8221495726cfb003b3796d7fb586a9fafd1da16854059d7d9d1f732db3ec")
