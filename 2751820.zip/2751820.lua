-- Lua provided by RyzenAPI
-- Game: Hypotheses on the Symmetry between Vision and Hands

-- MAIN APPLICATION
addappid(2751820)
-- Game: addappid(2751820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751821, 1, "54385b51a95888b907b38503663dc1b0b7192bb46f54a205c89da244a40ca4f9")
