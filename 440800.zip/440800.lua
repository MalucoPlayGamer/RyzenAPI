-- Lua provided by RyzenAPI
-- Game: Trial by Viking

-- MAIN APPLICATION
addappid(440800)

-- MAIN APP DEPOTS / PACKAGES
addappid(440801, 1, "7429bb0091a10334375eb9933fddb519a956e0b6e10df73fb9bb161210925ca3")
addappid(440802, 1, "bd2bded6045f0d443ed7818154d955e632ae01f754e1598e5b8f4151890a4c99")
addappid(440803, 1, "d36b0ab2ca0bedf44e7b17159f9aeb5ec14ef5d59027927338f67bdde60d1af0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
