-- Lua provided by SkyAPI 
-- Game: Trial by Viking
addappid(440800)
addappid(440801, 1, "7429bb0091a10334375eb9933fddb519a956e0b6e10df73fb9bb161210925ca3")
addappid(440802, 1, "bd2bded6045f0d443ed7818154d955e632ae01f754e1598e5b8f4151890a4c99")
addappid(440803, 1, "d36b0ab2ca0bedf44e7b17159f9aeb5ec14ef5d59027927338f67bdde60d1af0")
