-- Lua provided by RyzenAPI
-- Game: Game: Indies' Lies

-- MAIN APPLICATION
addappid(1638390)
-- Game: addappid(1638390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638391, 1, "f99c31551e5d5235510688baf6c95c1449adb1df88da4e56ad2cfc0cc4864025")
