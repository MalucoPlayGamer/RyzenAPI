-- Lua provided by RyzenAPI
-- Game: addappid(3042320)

-- MAIN APPLICATION
addappid(3042320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042321, 1, "a44f4b3002a9d0aa76a8d2e4f510d18aaf221e30d4f6054a5150bc09564c37d1")
