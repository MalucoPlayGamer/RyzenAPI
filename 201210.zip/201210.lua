-- Lua provided by RyzenAPI
-- Game: Pox Nora

-- MAIN APPLICATION
addappid(201210)

-- MAIN APP DEPOTS / PACKAGES
addappid(201212,0,"bfe82ddd4316cf061286add495e0b41806b6296cb6244ce82f297fc9793f69fe")
addappid(201214,0,"ee455a5e29aa42de607991a9ea5aaf47a1e2d38648265257bfbe0cd2e2abb185")
addappid(201215,0,"9c0c25fdb339169d8d6dcbf9d53e0fa7fdd13f02e782148f00255e77df8d503f")
addappid(201216,0,"ec6a2fcdead13424ee1cc696c7d9f127b1242c1e6d2943e05848e4c775885575")
addappid(201217,0,"02f20fd612f8caf0e05c127d2908123af4901c57d0b1862c1b46b3e3db160993")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(649430)
addappid(649431)
