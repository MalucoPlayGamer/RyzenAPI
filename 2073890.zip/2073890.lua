-- Lua provided by RyzenAPI
-- Game: addappid(2073890)

-- MAIN APPLICATION
addappid(2073890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073891, 1, "9eec519b8798d3420e97eb0a4a3d53c06e06555c080c0806be60dcd30d3b86d1")
