-- Lua provided by RyzenAPI
-- Game: 768950

-- MAIN APPLICATION
addappid(768950)
-- Game: addappid(768950)

-- MAIN APP DEPOTS / PACKAGES
addappid(768951, 1, "00ebed1b085324bca2caf481f714a16e89bc3d181f803ea7f54d127562399fde")
