-- Lua provided by RyzenAPI
-- Game: Golden Fever

-- MAIN APPLICATION
addappid(676590)

-- MAIN APP DEPOTS / PACKAGES
addappid(676591, 1, "961fb8eb91b0b42de853108b4d2a8a13157d41446c2c187db94e5d5e20e505c3")
