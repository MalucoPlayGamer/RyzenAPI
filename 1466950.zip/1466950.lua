-- Lua provided by SkyAPI 
-- Game: HangOutGame
addappid(1466950)
addappid(1466951, 1, "9dd3397c4375f2396447407e54940dfab28b185baa1a0f5c24cd352a78126fb3")
