-- Lua provided by RyzenAPI
-- Game: HangOutGame

-- MAIN APPLICATION
addappid(1466950)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1466951, 1, "9dd3397c4375f2396447407e54940dfab28b185baa1a0f5c24cd352a78126fb3")

