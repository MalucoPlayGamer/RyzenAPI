-- Lua provided by RyzenAPI
-- Game: Game: Shadows in Silence

-- MAIN APPLICATION
addappid(2626760)
-- Game: addappid(2626760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626761, 1, "2044851470e2a54f669e33af17fbf08f9861ef229baf42b76ecf045ce28e02a3")
