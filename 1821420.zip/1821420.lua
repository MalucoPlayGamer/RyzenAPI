-- Lua provided by RyzenAPI
-- Game: Battle Of The Robots

-- MAIN APPLICATION
addappid(1821420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821421, 1, "0f39fb9dde057720b72f444def1f1274e9f3cb5021a233e7baa1ac64ba3a937b")

