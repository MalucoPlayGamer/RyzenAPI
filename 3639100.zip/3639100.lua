-- Lua provided by RyzenAPI
-- Game: No Customers Left

-- MAIN APPLICATION
addappid(3639100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3639101, 1, "f60f307653d09e1c36c3e35a98248099ec90769721444bf0c5f75fcf3533692a")

