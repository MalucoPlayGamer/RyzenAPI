-- Lua provided by RyzenAPI
-- Game: Cupid Nonogram

-- MAIN APPLICATION
addappid(1787160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787161, 1, "cab7d931dcd84433fbb22feabd198c9edfa6d0df710545294d7ff6a28c31900b")

