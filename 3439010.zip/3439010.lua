-- Lua provided by RyzenAPI
-- Game: Clicker Conquest

-- MAIN APPLICATION
addappid(3439010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439011, 1, "a9e53291a9a4e50be6d09db72f61c50938385f4818cc463871cc93bda60597da")
