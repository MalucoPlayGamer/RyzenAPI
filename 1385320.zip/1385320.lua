-- Lua provided by RyzenAPI
-- Game: Pipe Mania

-- MAIN APPLICATION
addappid(1385320)
-- Game: addappid(1385320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385321, 1, "83ff194654916a5c553ffa6f15663366f8a719d6674c3a1bd3c4d9e9f570e901")
