-- Lua provided by RyzenAPI
-- Game: Pipe Mania

-- MAIN APPLICATION
addappid(1385320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385321, 1, "83ff194654916a5c553ffa6f15663366f8a719d6674c3a1bd3c4d9e9f570e901")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
