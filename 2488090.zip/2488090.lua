-- Lua provided by RyzenAPI
-- Game: Moving Down

-- MAIN APPLICATION
addappid(2488090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488091, 1, "b488c15dbee913d75fe28d78436d0028eb6572dcf3c74335ba66f15f6fc09b6c")

