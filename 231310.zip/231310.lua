-- Lua provided by RyzenAPI 
-- Game: MirrorMoon EP
addappid(231310)
addappid(231311, 1, "8ff22352e87d01ad9ce52a62c802b057fc22e68206e35f75c3e359b42728afcb")
addappid(231312, 1, "b9224d939ac695bae09653140a9243ae5656ec235a737d4a464a266560ab77b0")
addappid(231313, 1, "104fa11f6c7285cfe8f6637be5c7969076b6b6d3a3282e9bcb8e75f2bdb39268")
