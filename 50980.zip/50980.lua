-- Lua provided by RyzenAPI
-- Game: 50980

-- MAIN APPLICATION
addappid(50980)
-- Game: addappid(50980)

-- MAIN APP DEPOTS / PACKAGES
addappid(50981, 1, "2c5d90b29c51649b6c6f93df3f80d12512014429fc75371508ac1f12430b0ed5")
