-- Lua provided by RyzenAPI
-- Game: Planet Breakout 2

-- MAIN APPLICATION
addappid(2192730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192731, 1, "c06df5cefecfc5295b75b41879f5b4ac8e991b90b6088879ebbd3fd597637267")

