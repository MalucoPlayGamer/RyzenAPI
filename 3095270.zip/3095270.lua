-- Lua provided by RyzenAPI
-- Game: 3095270

-- MAIN APPLICATION
addappid(3095270)
-- Game: addappid(3095270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095271, 1, "dd68c5cc3f39b419cf8ab69e831e560119d0409f7b2fa35eb0dbdb70ac9fb173")
