-- Lua provided by RyzenAPI
-- Game: Big Bia

-- MAIN APPLICATION
addappid(585020)

-- MAIN APP DEPOTS / PACKAGES
addappid(585021, 1, "23176bfe5faaf7051a59dc1d95f405e25eb00a11a91cab88de200ce32561b322")
addappid(2053810, 0, "3b9ba26372919d8eacb68483d7bd4ca7760e8e239ad1aee280dde0923cea8486")

