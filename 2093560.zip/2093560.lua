-- Lua provided by RyzenAPI 
-- Game: Flowstone Saga Demo
addappid(2093560)
addappid(2093561, 1, "66d8cacbf7f614439a23405bc7616cebeba7e43696db45f25a261e60ee1b618c")
