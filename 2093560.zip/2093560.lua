-- Lua provided by RyzenAPI
-- Game: Game: Flowstone Saga Demo

-- MAIN APPLICATION
addappid(2093560)
-- Game: addappid(2093560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093561, 1, "66d8cacbf7f614439a23405bc7616cebeba7e43696db45f25a261e60ee1b618c")
