-- Lua provided by RyzenAPI 
-- Game: AppID 740570
addappid(740570)
addappid(740571, 1, "619beea571027e9af2be31c7aa4b0cd10941968ab5faa28490ee980ba82ccc0f")
