-- Lua provided by RyzenAPI
-- Game: addappid(2313700)

-- MAIN APPLICATION
addappid(2313700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313701, 1, "96431a8a22bd40bb4eaad78944c3edcc24fa407ee951d461050bc7d4f4ac4cde")
