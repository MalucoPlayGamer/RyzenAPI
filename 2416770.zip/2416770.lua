-- Lua provided by RyzenAPI
-- Game: 绛河之上 Under Supernova

-- MAIN APPLICATION
addappid(2416770)
-- Game: addappid(2416770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416771, 1, "b2e1b82195c932c73e3c2992bb2ed7a1a43eded7254c4ad47134559bcd5de30c")
