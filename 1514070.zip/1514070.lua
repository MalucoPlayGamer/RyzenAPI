-- Lua provided by RyzenAPI
-- Game: Video Realms

-- MAIN APPLICATION
addappid(1514070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1514071, 1, "b962830b7c27d867ea0e70147a9e14ade7d03d1f196013217332f9a4bb9979ab")

