-- Lua provided by RyzenAPI
-- Game: Video Realms

-- MAIN APPLICATION
addappid(1514070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514071, 1, "b962830b7c27d867ea0e70147a9e14ade7d03d1f196013217332f9a4bb9979ab")

