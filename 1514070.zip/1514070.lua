-- Lua provided by RyzenAPI 
-- Game: Video Realms
addappid(1514070)
addappid(1514071, 1, "b962830b7c27d867ea0e70147a9e14ade7d03d1f196013217332f9a4bb9979ab")
