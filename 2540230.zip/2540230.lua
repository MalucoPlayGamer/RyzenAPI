-- Lua provided by RyzenAPI
-- Game: 2540230

-- MAIN APPLICATION
addappid(2540230)
-- Game: addappid(2540230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540231, 1, "933febb3cc52d39a1771b47ce0940662aac561415f19400a3ab8a505133ddf82")
