-- Lua provided by RyzenAPI
-- Game: Game: Zombiolence

-- MAIN APPLICATION
addappid(2477100)
-- Game: addappid(2477100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477101, 1, "1627fc45329f88d30f50efe22e60e4be5e8061c24ce4c22e37e7cde0153cfdae")
