-- Lua provided by RyzenAPI
-- Game: Mount & Blade

-- MAIN APPLICATION
addappid(22100)

-- MAIN APP DEPOTS / PACKAGES
addappid(22101, 1, "5a9ac546184db83715113ec2264a81ecd6265215ab82a48d9f418a7b5de6bd85")
addappid(22102, 1, "e3f82a8419434df96396ddc6da4add2bcc83a4072896c32f874c166a270ffcfd")
addappid(22103, 1, "d6688b7489b0b51a462223a9c7dbf21e259417a1ee0b3b13b2f419b7b30b6bad")
addappid(22104, 1, "18ffe98874c955275dbdb3814a8ca67b3e8c7e99c0a80635f0a83f5f843b07e7")

