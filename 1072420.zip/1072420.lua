-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST BUILDERS™ 2

-- MAIN APPLICATION
addappid(1072420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072421, 1, "ea3e24679754c7e32fd45950b725fab07df1573119307b7c85950f38fc293ecc")
addappid(1162620, 0, "7c87d006544dc296935202dbe2c8041875f6d5652b052f610098412bf718a3e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
