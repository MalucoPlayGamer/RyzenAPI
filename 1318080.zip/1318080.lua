-- Lua provided by SkyAPI 
-- Game: AppID 1318080
addappid(1318080)
addappid(1318081, 1, "2720c1d6baba3042116a3824916bbe02a6dee971992f4ce830db8cd9746bdaf8")
