-- Lua provided by RyzenAPI
-- Game: Game: AppID 1318080

-- MAIN APPLICATION
addappid(1318080)
-- Game: addappid(1318080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318081, 1, "2720c1d6baba3042116a3824916bbe02a6dee971992f4ce830db8cd9746bdaf8")
