-- Lua provided by RyzenAPI
-- Game: addappid(3044800)

-- MAIN APPLICATION
addappid(3044800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044801, 1, "2b5f8eef74e10d8f72c27fc3ed575e472a8460194989cb2b41ad2d40bae4bf24")
