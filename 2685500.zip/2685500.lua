-- Lua provided by SkyAPI 
-- Game: Falling with Ice Phoenix!
addappid(2685500)
addappid(2685501, 1, "56d4ce5a7ddc4f9380bdc6771b93de03c22223e08bee1ad29f7d592dc74d4dc3")
