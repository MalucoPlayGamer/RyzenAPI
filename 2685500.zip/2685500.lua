-- Lua provided by RyzenAPI
-- Game: Game: Falling with Ice Phoenix!

-- MAIN APPLICATION
addappid(2685500)
-- Game: addappid(2685500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685501, 1, "56d4ce5a7ddc4f9380bdc6771b93de03c22223e08bee1ad29f7d592dc74d4dc3")
