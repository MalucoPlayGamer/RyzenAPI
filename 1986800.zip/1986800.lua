-- Lua provided by RyzenAPI
-- Game: Insurrection: Cyborgs Awakening

-- MAIN APPLICATION
addappid(1986800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1986801, 1, "c1b8637b26e831b62509e28dfd431c17835aedd96ccfe7eec3272f4ac01b1b16")

