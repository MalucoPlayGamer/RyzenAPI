-- Lua provided by RyzenAPI
-- Game: Insurrection: Cyborgs Awakening

-- MAIN APPLICATION
addappid(1986800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986801, 1, "c1b8637b26e831b62509e28dfd431c17835aedd96ccfe7eec3272f4ac01b1b16")

