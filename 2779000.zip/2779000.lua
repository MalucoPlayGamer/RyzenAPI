-- Lua provided by SkyAPI 
-- Game: AppID 2779000
addappid(2779000)
addappid(2779001, 1, "f03332d018d10aca6c95dfacd9813b804af09507c4d60ce63d3e76d64df394ad")
