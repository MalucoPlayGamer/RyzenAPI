-- Lua provided by RyzenAPI
-- Game: addappid(314660)

-- MAIN APPLICATION
addappid(314660)
addappid(391880)
addappid(400780)

-- MAIN APP DEPOTS / PACKAGES
addappid(314661, 1, "33cee64cb46f8b3be3c8aedbfe80f3dfa5422a0dac55061795fff9c3d37c544e")
addappid(314662, 1, "65f2b31b5ea12d28643a4a79d6a0b3a2fbf60d5e8872002dc7d650636f69d371")
addappid(314663, 1, "3ebe1774ff941c29c57607265efa83a3c975319ddc48ab94a946ce7ae476ea51")
addappid(441040, 0, "8dbdf620128c28a1351657a716e482c29a00446196009764ef7dfe5ee02c69c3")
