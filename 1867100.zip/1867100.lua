-- Lua provided by RyzenAPI
-- Game: 1867100

-- MAIN APPLICATION
addappid(1867100)
-- Game: addappid(1867100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867101, 1, "e975b4adbe8ebc37cc112a93ff2298d0c3f68fb4c1abc066fad08b4b1fee04d5")
