-- Lua provided by SkyAPI 
-- Game: CODEDOOR
addappid(2577320)
addappid(2577321, 1, "ad2e23b6ed425ceb4a8382305289f21c8c03a6181f0fe9fa7cee8ee2e9736db0")
