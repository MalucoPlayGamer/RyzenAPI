-- Lua provided by RyzenAPI
-- Game: CODEDOOR

-- MAIN APPLICATION
addappid(2577320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2577321, 1, "ad2e23b6ed425ceb4a8382305289f21c8c03a6181f0fe9fa7cee8ee2e9736db0")

