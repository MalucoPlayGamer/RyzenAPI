-- Lua provided by RyzenAPI
-- Game: Game: Winter Resort Simulator 2

-- MAIN APPLICATION
addappid(1420770)
-- Game: addappid(1420770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420771, 1, "9ac7be0c7ff4039d7438a7c53a4f4b3e36277570075428d8fe7fe4a1a5c582d3")
addappid(1429910, 0, "463390aa4571d704fc03156ea5dba5465bb292b3b57b8c04fb28f04a7d5ec775")
addappid(1499590, 0, "c4abaa7adc6406e4d28b66ef5badd07b2d50dc4addcf80e306259ef93dce90dd")
addappid(1784720, 0, "9a8e9b866b07086a97bfe47f7dacfcd8226617909234d6b30cdda4f70f3f1c98")
