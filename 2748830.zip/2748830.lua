-- Lua provided by RyzenAPI
-- Game: Seedsow Lullaby

-- MAIN APPLICATION
addappid(2748830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2748831, 1, "cb2d67d322c512b61ad764667c94d3fd3eb7d8807ebb92c730ee85959b923caa")

