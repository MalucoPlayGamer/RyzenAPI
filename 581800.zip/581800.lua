-- Lua provided by RyzenAPI
-- Game: AppID 581800

-- MAIN APPLICATION
addappid(581800)
-- Game: addappid(581800)

-- MAIN APP DEPOTS / PACKAGES
addappid(581801, 1, "0f46ed5cf04635775d050d60eb3e7039b94219645243ae7609806f4fbd084d1e")
