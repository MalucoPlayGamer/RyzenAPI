-- Lua provided by RyzenAPI 
-- Game: AppID 581800
addappid(581800)
addappid(581801, 1, "0f46ed5cf04635775d050d60eb3e7039b94219645243ae7609806f4fbd084d1e")
