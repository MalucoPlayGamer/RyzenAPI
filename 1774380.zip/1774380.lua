-- Lua provided by RyzenAPI
-- Game: 1774380

-- MAIN APPLICATION
addappid(1774380)
-- Game: addappid(1774380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774382,0,"86dda64bcccea17a85c1f9ba8fc73707a6d2da1f100d5581c0603d605d257cd8")
