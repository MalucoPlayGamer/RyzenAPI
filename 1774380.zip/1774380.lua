-- Lua provided by RyzenAPI
-- Game: Cine Tracer 2

-- MAIN APPLICATION
addappid(1774380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1774382,0,"86dda64bcccea17a85c1f9ba8fc73707a6d2da1f100d5581c0603d605d257cd8")

