-- Lua provided by RyzenAPI
-- Game: Forest Doesn’t Care

-- MAIN APPLICATION
addappid(3922100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3922101,0,"3468a1c496a6a6b3625a766f69eeb528105e887b64b5e9ada5fe4314049a4279")

