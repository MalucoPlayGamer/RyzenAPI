-- Lua provided by RyzenAPI
-- Game: Forest Doesn’t Care

-- MAIN APPLICATION
addappid(3922100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3922101,0,"3468a1c496a6a6b3625a766f69eeb528105e887b64b5e9ada5fe4314049a4279")

