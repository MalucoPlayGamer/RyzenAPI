-- Lua provided by RyzenAPI
-- Game: Mute Crimson+

-- MAIN APPLICATION
addappid(384280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(384281, 1, "de348af065a7135e0ea7889f6f9b721f2cdddd7623fb2a3cfa682e2c1f7845e8")
addappid(384282, 1, "fc61f5cc78a4acc6668e8126387d0756af073a8d4bbb0fb0f27c8eddac4d7195")
addappid(384283, 1, "88f2f1b6ad78926cf39c780e18ec337e2de4013e1969371e5285f5423ed8469a")
addappid(384284, 1, "0c647a64ff802f5afbcae8624efb4eb12612d0a36d89809cbd5a716df2647162")
addappid(384285, 1, "3bc148198928eca916eaa5ef0aff58a6ddb5a99fbdf82d60539627b0a67df745")
