-- Lua provided by RyzenAPI 
-- Game: Flan's MS
addappid(2992570)
addappid(2992571, 1, "aaac9998d9c082e20fa49100b4bbd6e558abed365b110e871e7db1f88aa7d0e6")
