-- Lua provided by SkyAPI 
-- Game: RUSH
addappid(844040)
addappid(844041, 1, "9cdcd8b5258d260f4019b8a5f6b333e045bd28eb7b016d4cb17b680a0ea4026e")
