-- Lua provided by RyzenAPI
-- Game: 844040

-- MAIN APPLICATION
addappid(844040)
-- Game: addappid(844040)

-- MAIN APP DEPOTS / PACKAGES
addappid(844041, 1, "9cdcd8b5258d260f4019b8a5f6b333e045bd28eb7b016d4cb17b680a0ea4026e")
