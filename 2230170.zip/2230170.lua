-- Lua provided by RyzenAPI
-- Game: The Cenozoic Era

-- MAIN APPLICATION
addappid(2230170)
-- Game: addappid(2230170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230171, 1, "5f8b0002938a1de726a657b08f057b1f1864f1d8e7c3a4ead726a3a217b18750")
