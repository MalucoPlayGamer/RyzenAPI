-- Lua provided by SkyAPI 
-- Game: Anetona
addappid(1371280)
addappid(1371281, 1, "f9366b2b951859a70929a31c62ed99c7b8218c6859288621d12416dd1b2eaeb9")
