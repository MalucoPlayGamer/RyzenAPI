-- Lua provided by RyzenAPI
-- Game: addappid(3177050)

-- MAIN APPLICATION
addappid(3177050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177051, 1, "4da4e402ae79264236ff827b9eec627d160896a4bf2770eb519a1fbfcf2c768d")
