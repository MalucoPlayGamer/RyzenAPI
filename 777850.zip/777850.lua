-- Lua provided by RyzenAPI
-- Game: Cannon Crew

-- MAIN APPLICATION
addappid(777850)

-- MAIN APP DEPOTS / PACKAGES
addappid(777851,0,"3c2a3e6d86d27271899e253a393ddfa1dcee47a42f6b9acd6177390ceb43359c")

