-- Lua provided by SkyAPI 
-- Game: Hartacon Tactics
addappid(575850)
addappid(575851, 1, "b952c06affdbf2320dd7add584f1ad317a645316a3480604e97029bcad3555b5")
