-- Lua provided by RyzenAPI
-- Game: Hartacon Tactics

-- MAIN APPLICATION
addappid(575850)

-- MAIN APP DEPOTS / PACKAGES
addappid(575851, 1, "b952c06affdbf2320dd7add584f1ad317a645316a3480604e97029bcad3555b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
