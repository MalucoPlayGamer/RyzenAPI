-- Lua provided by RyzenAPI
-- Game: El Matador

-- MAIN APPLICATION
addappid(289280)

-- MAIN APP DEPOTS / PACKAGES
addappid(289281, 1, "c5c03de52a93d7fdc96a751c68864a1f4c2126d6cda214c5d091f289fbc52b28")
addappid(289282, 1, "03cf54dc704a3a556af6f1105c92e58321fb7d6fab783a85ceef00a44947f018")
addappid(289283, 1, "05e203bf96ded0d4c70ef51adbb9b8c8d32ab70f618359c700a9a17345b9ae99")
addappid(289284, 1, "3dec16fdf146da2fd1b538b11e075aa05b4454a5b9b425305b5372b0ceda3084")
addappid(289285, 1, "d5ac09a35e6b453f4f29e2e9d508ad4eb123281a640b1f6a51df88f0feeb0d94")
addappid(289286, 1, "3803c7e8b927ecb9f9bc46853edddb2d853f293848c8d68f8fdfdaf9477c17ee")
addappid(289287, 1, "93697655733bccef157d2755ae536cbafbfe840bd54cdb8e4d28d3d1bf9ede1e")

