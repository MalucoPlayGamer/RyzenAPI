-- Lua provided by RyzenAPI
-- Game: Twisted Gallery 异馆

-- MAIN APPLICATION
addappid(3426920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3426924,0,"e1e18a6d8befad27c095cdd009fb567d5bfa4c1cd106cb115b7bfb9dde302345")

