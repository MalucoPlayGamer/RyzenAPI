-- Lua provided by RyzenAPI
-- Game: addappid(3426920)

-- MAIN APPLICATION
addappid(3426920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3426924,0,"e1e18a6d8befad27c095cdd009fb567d5bfa4c1cd106cb115b7bfb9dde302345")
