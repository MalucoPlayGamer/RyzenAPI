-- Lua provided by RyzenAPI 
-- Game: Animal Shelter
addappid(1239320)
addappid(1239321, 1, "031692e90ed54217c1b361b298f1d03b582c03b2d3c2ce1d63b6d03e02c7131b")
