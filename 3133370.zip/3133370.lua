-- Lua provided by RyzenAPI
-- Game: Slime Princess Demo

-- MAIN APPLICATION
addappid(3133370)
-- Game: addappid(3133370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133371, 1, "1b37a1933ab41c5465a1801828dabdb4fc63d27d6db0a9a6b0e7c4fe84fcd51d")
