-- Lua provided by RyzenAPI
-- Game: 2470140

-- MAIN APPLICATION
addappid(2470140)
-- Game: addappid(2470140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470141, 1, "d9e68c36597bf3212c36232f9a262c58a7fa550693951ddffd0fe8ce8d9f8874")
