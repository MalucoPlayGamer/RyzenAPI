-- Lua provided by RyzenAPI
-- Game: addappid(2916190)

-- MAIN APPLICATION
addappid(2916190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916191, 1, "b93cc4fa05d9aca1a0fc772b02af56fd730977141fd791885bce2644d59c6c85")
