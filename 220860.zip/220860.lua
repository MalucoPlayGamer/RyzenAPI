-- Lua provided by RyzenAPI 
-- Game: McPixel
addappid(220860)
addappid(220861, 1, "33aed2a681580b6c703a513e13d1a71b6fe41678fbb37c7329467fb29c181162")
addappid(220862, 1, "98ed185dd78a88b71f3d60d3b9fd85f81527633f56bdb9f0f5478695e3a272ab")
