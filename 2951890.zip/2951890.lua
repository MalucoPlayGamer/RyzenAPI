-- Lua provided by RyzenAPI
-- Game: Game: The Cursed Tape

-- MAIN APPLICATION
addappid(2951890)
-- Game: addappid(2951890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951891, 1, "d84b32d9dfb5121bf9e7ca38d6243648d164668022616b4d1960267c8978066e")
