-- Lua provided by RyzenAPI
-- Game: 见诡录：色孽 Haunting Record: Sins of Lust

-- MAIN APPLICATION
addappid(3229690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229691, 1, "d5441d0c1ffdc35cfeb4473ecf5323cb2f8a53546db7b3b2ec69af91a495b0d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
