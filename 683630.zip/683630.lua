-- Lua provided by RyzenAPI
-- Game: Half Past Disaster

-- MAIN APPLICATION
addappid(683630)
addappid(689630)

-- MAIN APP DEPOTS / PACKAGES
addappid(683631,0,"d3ac0c4b7529a115c47a8579f1b8c8a3bfb66329d707f7fc4ae28f6a0be96bd2")
addappid(683632,0,"b44c95c02c77311f17be5143958f218b3794e1c4e55db02f3b2b8c341b4ba936")

