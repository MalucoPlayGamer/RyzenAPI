-- Lua provided by RyzenAPI
-- Game: Sister Ray

-- MAIN APPLICATION
addappid(3200290)
addappid(5091490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200291,0,"f7392f97b439d8454727bb864789c64644a56ff99cbce444e8758478fb616ba0")

