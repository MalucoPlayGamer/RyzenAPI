-- Lua provided by RyzenAPI
-- Game: AppID 415660

-- MAIN APPLICATION
addappid(415660)
addappid(530800)
addappid(530801)
addappid(541840)
-- Game: addappid(415660)

-- MAIN APP DEPOTS / PACKAGES
addappid(415661, 1, "76223eef77fd19d177f128dd5ab0ad1512e980f7530f3f977f96d556fa2d67ed")
