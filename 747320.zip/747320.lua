-- Lua provided by RyzenAPI
-- Game: AppID 747320

-- MAIN APPLICATION
addappid(747320)
-- Game: addappid(747320)

-- MAIN APP DEPOTS / PACKAGES
addappid(747321, 1, "fcf5159c12f09cd49f7d076e7fdbf8a6a18b1b454b9f07b9ba1fd15a1b4993dc")
