-- Lua provided by RyzenAPI
-- Game: Game: Sodaman

-- MAIN APPLICATION
addappid(2178990)
-- Game: addappid(2178990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178991, 1, "a9f6c5856df876fa48e853a39ae1fc88934d3bbfe6ae31f220a7a14b7dce9916")
addappid(2178992, 1, "6b62515b6c4760a5613f6a145f90c85222f5c846b4f1ac3f91c0bc5a8d245d28")
addappid(2178993, 1, "d64c6676c59e648db1fa780d1c67f6f9fd188402c85122b3c9b274972b6f10e5")
