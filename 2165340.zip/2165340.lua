-- Lua provided by RyzenAPI 
-- Game: Quiz.com
addappid(2165340)
addappid(2165341, 1, "436872d52d7805bb66a0513daa80a1f9d90e310b69cf483aafe2c75f62c0ecfb")
addappid(2165342, 1, "10701d1592f25f7499116a912bd46253763d753d35463332b45a2a31fe66fd4e")
