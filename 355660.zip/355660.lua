-- Lua provided by SkyAPI 
-- Game: AppID 355660
addappid(355660)
addappid(355661, 1, "2af8e2190c5a3d8ca0ec136e3063675221527da3126f1d387515026d259c76b9")
