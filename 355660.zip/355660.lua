-- Lua provided by RyzenAPI
-- Game: Game: AppID 355660

-- MAIN APPLICATION
addappid(355660)
-- Game: addappid(355660)

-- MAIN APP DEPOTS / PACKAGES
addappid(355661, 1, "2af8e2190c5a3d8ca0ec136e3063675221527da3126f1d387515026d259c76b9")
