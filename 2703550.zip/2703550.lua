-- Lua provided by RyzenAPI
-- Game: Vigaro Runner

-- MAIN APPLICATION
addappid(2703550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703551, 1, "4efac5503975e2684d7e23e72a54b9aac3820402f9c06cae90fadad5a1b97a58")
