-- Lua provided by RyzenAPI
-- Game: addappid(1533420)

-- MAIN APPLICATION
addappid(1533420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533421, 1, "e362c1777b3cf17e41f84b830ad1d0c5b96de7ed16ef08b6488101c1c4cbf33d")
