-- Lua provided by RyzenAPI
-- Game: Neon White

-- MAIN APPLICATION
addappid(1533420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533421, 1, "e362c1777b3cf17e41f84b830ad1d0c5b96de7ed16ef08b6488101c1c4cbf33d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
