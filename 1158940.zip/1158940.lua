-- Lua provided by RyzenAPI
-- Game: addappid(1158940)

-- MAIN APPLICATION
addappid(1158940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158941, 1, "f9130b661ac759f41c7e32b772b9a1a5921b7f7b58f84dbddfd9a291d5d789b1")
