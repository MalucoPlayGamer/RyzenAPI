-- Lua provided by RyzenAPI
-- Game: Blazing Sails

-- MAIN APPLICATION
addappid(1158940)
addappid(1371650)
addappid(1371651)
addappid(1371652)
addappid(1371654)
addappid(1437780)
addappid(1437781)
addappid(1437782)
addappid(1437783)
addappid(1437784)
addappid(1455700)
addappid(1497090)
addappid(1691460)
addappid(1815620)
addappid(1822630)
addappid(1906340)
addappid(2672710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158941,0,"f9130b661ac759f41c7e32b772b9a1a5921b7f7b58f84dbddfd9a291d5d789b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
