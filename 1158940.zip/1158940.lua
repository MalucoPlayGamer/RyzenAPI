-- Lua provided by RyzenAPI
-- Game: Blazing Sails

-- MAIN APPLICATION
addappid(1158940)
addappid(1371650)
addappid(1371651)
addappid(1371652)
addappid(1371654)
addappid(1437780)
addappid(1437781)
addappid(1437782)
addappid(1437783)
addappid(1437784)
addappid(1455700)
addappid(1497090)
addappid(1691460)
addappid(1815620)
addappid(1822630)
addappid(1906340)
addappid(2672710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158941,0,"f9130b661ac759f41c7e32b772b9a1a5921b7f7b58f84dbddfd9a291d5d789b1")

