-- Lua provided by RyzenAPI
-- Game: AppID 2778480

-- MAIN APPLICATION
addappid(2778480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2778481, 1, "9bc705e6feeb8bfdded7956c5fad10039f2193433e132ce005c3c1ac604bf91d")

