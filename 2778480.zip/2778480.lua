-- Lua provided by RyzenAPI
-- Game: 2778480

-- MAIN APPLICATION
addappid(2778480)
-- Game: addappid(2778480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778481, 1, "9bc705e6feeb8bfdded7956c5fad10039f2193433e132ce005c3c1ac604bf91d")
