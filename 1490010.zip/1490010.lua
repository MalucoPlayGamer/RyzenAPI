-- Lua provided by RyzenAPI
-- Game: addappid(1490010)

-- MAIN APPLICATION
addappid(1490010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490011, 1, "5a194563e095c31038fa80a3ed4a9dd3f1c6f611e90edfa74d8b24823fbbeec6")
