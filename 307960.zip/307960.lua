-- Lua provided by RyzenAPI
-- Game: IL-2 Sturmovik: Battle of Stalingrad

-- MAIN APPLICATION
addappid(307960)
-- Game: addappid(307960)

-- MAIN APP DEPOTS / PACKAGES
addappid(307961, 1, "23b7d427a0663be8f3d3540b80b7a0bb9d98b7f4e6d17ddc7a7224ac5d20e947")
