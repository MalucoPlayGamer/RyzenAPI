-- Lua provided by RyzenAPI
-- Game: Eastside Hockey Manager

-- MAIN APPLICATION
addappid(301120)

-- MAIN APP DEPOTS / PACKAGES
addappid(301121, 1, "a1aae15b3642a74cdd36402411ca4d9c073ce963f7b78674f2c45789b446bc61")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
