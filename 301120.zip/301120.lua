-- Lua provided by RyzenAPI
-- Game: Eastside Hockey Manager

-- MAIN APPLICATION
addappid(301120)
-- Game: addappid(301120)

-- MAIN APP DEPOTS / PACKAGES
addappid(301121, 1, "a1aae15b3642a74cdd36402411ca4d9c073ce963f7b78674f2c45789b446bc61")
