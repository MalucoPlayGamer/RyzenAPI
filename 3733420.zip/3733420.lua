-- Lua provided by RyzenAPI
-- Game: Galactic Warship Soundtrack

-- MAIN APPLICATION
addappid(3733420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3733421, 1, "900ab552371a4c1e597f5e09b1a45d7ae7db941add7ab2be12c06e85925583b2")

