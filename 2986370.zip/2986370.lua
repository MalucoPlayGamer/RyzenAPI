-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2986370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2986372,0,"3c33608cb0e40db3a3b700286443175881b1b14cc8fd17721e09a50c570791fc")

