-- Lua provided by RyzenAPI
-- Game: Cards and Guns Demo

-- MAIN APPLICATION
addappid(2382510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382511, 1, "601a3fefd09be53f316bf2054cef54499966f66d570f86d31678dbdc2a96061d")
