-- Lua provided by RyzenAPI
-- Game: Mago: The Villain's Burger

-- MAIN APPLICATION
addappid(1809650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809651, 1, "2680ddbe9f7fd7ba4f11eaaf6ba9552b370d8fd47004a94fea51c38b281cbc00")

