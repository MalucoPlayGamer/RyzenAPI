-- Lua provided by SkyAPI 
-- Game: Muffin Knight
addappid(263700)
addappid(263701, 1, "62e1cd14a596344c2ccde8e8631b001125cc3e25d58923abaf662e45558c1e43")
addappid(263702, 1, "8fde0f9178769e723f82420570ab2f3113156d2e046996a7bcc510d7fab74164")
