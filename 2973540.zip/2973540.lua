-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Hospital 2

-- MAIN APPLICATION
addappid(2973540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973541, 1, "1a8b4626ce24980dfb8467331b8dc97c6bc333ade45afa2ba4c02510748687a0")