-- Lua provided by RyzenAPI
-- Game: 1456230

-- MAIN APPLICATION
addappid(1456230)
addappid(1593540)
-- Game: addappid(1456230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456231, 1, "b1bb4a2eb4d408b49757585b486c2b24220743271af5a19f1cc7c67d5a485024")
