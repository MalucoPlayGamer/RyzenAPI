-- Lua provided by RyzenAPI
-- Game: Game: 橘猫猫的幻想

-- MAIN APPLICATION
addappid(2863810)
-- Game: addappid(2863810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863811, 1, "12dc23f3f9958d8aad00d41202af50379c661b1023be865dbf729d950fca80de")
