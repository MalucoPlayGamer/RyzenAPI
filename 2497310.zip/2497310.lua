-- Lua provided by RyzenAPI
-- Game: R & P: Prologue

-- MAIN APPLICATION
addappid(2497310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497311, 1, "669a112d758321385034b24b6311977ba78adcacaee76ae5348a907b26a2ab84")
