-- Lua provided by RyzenAPI
-- Game: R & P: Prologue

-- MAIN APPLICATION
addappid(2497310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497311, 1, "669a112d758321385034b24b6311977ba78adcacaee76ae5348a907b26a2ab84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
