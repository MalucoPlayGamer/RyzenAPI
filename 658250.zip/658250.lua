-- Lua provided by RyzenAPI 
-- Game: Xtrike
addappid(658250)
addappid(658251, 1, "00b38e88601f8e8f26a8b81cd696df96b9a4644e9732653f3babb96c2ddf14ec")
addappid(658253, 1, "6fc6ca729399319ce3e2f3056b65ce1852b91b7df056dfcb959103f8eadc1d5a")
