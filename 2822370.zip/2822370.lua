-- Lua provided by SkyAPI 
-- Game: Chocolate Factory Simulator
addappid(2822370)
addappid(2822371, 1, "3d00909cdf5c419e6e9e79c7ea78c7b6b25a0ae1e34a061e66fc947fb0e10018")
