-- Lua provided by RyzenAPI
-- Game: Freelancer Life Simulator: Prologue

-- MAIN APPLICATION
addappid(1518090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518091, 1, "e12c9003008cc5a8399cba047799588d002bd4738e818f8c95227dc77ac4cba0")

