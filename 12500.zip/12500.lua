-- Lua provided by RyzenAPI
-- Game: 12500

-- MAIN APPLICATION
addappid(12500)
-- Game: addappid(12500)

-- MAIN APP DEPOTS / PACKAGES
addappid(12501, 1, "4fd092e7687bafe9b9008c9a01def28b1d4ae3246ffa9f073a6fe722e808b590")
