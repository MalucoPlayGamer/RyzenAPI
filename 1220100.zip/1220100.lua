-- Lua provided by RyzenAPI
-- Game: addappid(1220100)

-- MAIN APPLICATION
addappid(1220100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220101, 1, "78049c1a79a8bca9383cc48176aaab95c26daeadd6677114c236601633c4f239")
