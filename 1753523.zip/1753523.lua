-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1753523)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753523,0,"f112a12eddb325e4be602d89839569996f10d221fd7090293c5ff90efe04f067")
