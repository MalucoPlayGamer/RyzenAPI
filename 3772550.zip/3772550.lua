-- Lua provided by RyzenAPI
-- Game: addappid(3772550)

-- MAIN APPLICATION
addappid(3772550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3772551, 1, "164bec0d572c3488a4d02af76f429dd8edd74a60c00f0968887e2a9b3a90de22")
