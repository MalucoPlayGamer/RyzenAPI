-- Lua provided by RyzenAPI
-- Game: Scary Together

-- MAIN APPLICATION
addappid(3772550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3772551, 1, "164bec0d572c3488a4d02af76f429dd8edd74a60c00f0968887e2a9b3a90de22")

