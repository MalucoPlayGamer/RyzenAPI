-- Lua provided by RyzenAPI 
-- Game: Scary Together
addappid(3772550)
addappid(3772551, 1, "164bec0d572c3488a4d02af76f429dd8edd74a60c00f0968887e2a9b3a90de22")
