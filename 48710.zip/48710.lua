-- Lua provided by RyzenAPI
-- Game: Mount & Blade: Warband Demo

-- MAIN APPLICATION
addappid(48710)

-- MAIN APP DEPOTS / PACKAGES
addappid(48711, 1, "111b99b97c72acccd0f2d2e38723ce6f2eb4b08637d3f41c52ea8b4a74ed5c05")
