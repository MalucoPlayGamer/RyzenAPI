-- Lua provided by RyzenAPI
-- Game: Inkbound

-- MAIN APPLICATION
addappid(1062810)
addappid(2616400)
addappid(2616410)
addappid(2766440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062811,0,"e49351772dca11a35a40ecc97cfa7253bbf0ecd03f78e78275a79b7776110da9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
