-- Lua provided by RyzenAPI
-- Game: 1062810

-- MAIN APPLICATION
addappid(1062810)
-- Game: addappid(1062810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062811, 1, "e49351772dca11a35a40ecc97cfa7253bbf0ecd03f78e78275a79b7776110da9")
