-- Lua provided by RyzenAPI
-- Game: Inkbound

-- MAIN APPLICATION
addappid(1062810)
addappid(2616400)
addappid(2616410)
addappid(2766440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062811,0,"e49351772dca11a35a40ecc97cfa7253bbf0ecd03f78e78275a79b7776110da9")

