-- Lua provided by RyzenAPI
-- Game: AppID 2462600

-- MAIN APPLICATION
addappid(2462600)
-- Game: addappid(2462600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462601, 1, "d4fe02a99ef2f4f4523d889df887d0b3e10913577663707505ba5cc5a4ae4dc9")
