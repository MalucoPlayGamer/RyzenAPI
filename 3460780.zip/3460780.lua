-- Lua provided by RyzenAPI
-- Game: Game: Hidden Cats: Japan

-- MAIN APPLICATION
addappid(3460780)
-- Game: addappid(3460780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460781, 1, "80caaba71097e3f0b03eba0a1f4d84184a73df78763bbbff13c5b48fd4f25793")
