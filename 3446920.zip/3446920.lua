-- Lua provided by RyzenAPI
-- Game: Mecharashi

-- MAIN APPLICATION
addappid(3446920)

