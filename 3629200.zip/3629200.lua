-- Lua provided by RyzenAPI
-- Game: Synthesis of Corruption

-- MAIN APPLICATION
addappid(3629200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629201,0,"153bad82dec45dd8990d412ece83114d3413c5e9279580b784749ccfaba63b00")

