-- Lua provided by RyzenAPI
-- Game: Open The Door

-- MAIN APPLICATION
addappid(849000)

-- MAIN APP DEPOTS / PACKAGES
addappid(849001, 1, "9778cf5369bf20de632959e03e0f93e14cae5c312b2679ab8a4e035c35488bba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
