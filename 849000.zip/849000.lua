-- Lua provided by RyzenAPI
-- Game: Open The Door

-- MAIN APPLICATION
addappid(849000)

-- MAIN APP DEPOTS / PACKAGES
addappid(849001, 1, "9778cf5369bf20de632959e03e0f93e14cae5c312b2679ab8a4e035c35488bba")
