-- Lua provided by RyzenAPI
-- Game: 3404260

-- MAIN APPLICATION
addappid(3404260)
-- Game: addappid(3404260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3404261, 1, "973bb66b7d1dcddebad49a40c9bad583fb090e27d3df4fc57fea8b9732ce6680")
