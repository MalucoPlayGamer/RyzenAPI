-- Lua provided by SkyAPI 
-- Game: Blondes
addappid(2357150)
addappid(2357151, 1, "337405fff25c1cfa35c7041078eceab31158ed573084689bb76b1dfd3a03ec88")
