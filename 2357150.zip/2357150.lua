-- Lua provided by RyzenAPI
-- Game: Blondes

-- MAIN APPLICATION
addappid(2357150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357151, 1, "337405fff25c1cfa35c7041078eceab31158ed573084689bb76b1dfd3a03ec88")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2418310)
