-- Lua provided by RyzenAPI
-- Game: Call of Bitcoin

-- MAIN APPLICATION
addappid(836260)

-- MAIN APP DEPOTS / PACKAGES
addappid(836261, 1, "513aeddea63f90c91ab42e8a7e382fd9679139f4ee8b2fffd0d7275a79153034")

