-- Lua provided by RyzenAPI
-- Game: 3023490

-- MAIN APPLICATION
addappid(3023490)
-- Game: addappid(3023490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023491, 1, "c9bf695369430873040b6637b52a4f445ed8dae14e90d6d29b40b6eb3f2bdcf8")
