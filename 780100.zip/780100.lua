-- Lua provided by RyzenAPI
-- Game: ClearMem :: Free Up Your RAM

-- MAIN APPLICATION
addappid(780100)

-- MAIN APP DEPOTS / PACKAGES
addappid(780101, 1, "11e39ba3408bdab9ecc9d6fa5515f3e19eb728cf20b4da47445d6b66e8399d57")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
