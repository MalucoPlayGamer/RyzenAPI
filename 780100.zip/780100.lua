-- Lua provided by RyzenAPI
-- Game: ClearMem :: Free Up Your RAM

-- MAIN APPLICATION
addappid(780100)
-- Game: addappid(780100)

-- MAIN APP DEPOTS / PACKAGES
addappid(780101, 1, "11e39ba3408bdab9ecc9d6fa5515f3e19eb728cf20b4da47445d6b66e8399d57")
