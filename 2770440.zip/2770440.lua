-- Lua provided by RyzenAPI
-- Game: Game: Guardians of Eden OST

-- MAIN APPLICATION
addappid(2770440)
-- Game: addappid(2770440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2770441, 1, "ec2da21fb0d0a49f000e3828ff9a74a629f0b46d99d762b69541c3a8c6cabb79")
