-- Lua provided by RyzenAPI
-- Game: Epica

-- MAIN APPLICATION
addappid(1281480)
-- Game: addappid(1281480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281481, 1, "7ede8ea7f22190851d3511ff2393d127b6e15fb2b71d62b44a77faf198417cfc")
