-- Lua provided by SkyAPI 
-- Game: Epica
addappid(1281480)
addappid(1281481, 1, "7ede8ea7f22190851d3511ff2393d127b6e15fb2b71d62b44a77faf198417cfc")
