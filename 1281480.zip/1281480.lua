-- Lua provided by RyzenAPI
-- Game: Epica

-- MAIN APPLICATION
addappid(1281480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1281481, 1, "7ede8ea7f22190851d3511ff2393d127b6e15fb2b71d62b44a77faf198417cfc")

