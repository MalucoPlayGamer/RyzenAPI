-- Lua provided by RyzenAPI
-- Game: SpellRogue Demo

-- MAIN APPLICATION
addappid(2586850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586851, 1, "d24d1c112034f873876d67cfe936dbe478b4836ca75bbeb3e008aa7eedf9c739")
