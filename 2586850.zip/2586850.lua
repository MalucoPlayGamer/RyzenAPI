-- Lua provided by RyzenAPI
-- Game: 2586850

-- MAIN APPLICATION
addappid(2586850)
-- Game: addappid(2586850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586851, 1, "d24d1c112034f873876d67cfe936dbe478b4836ca75bbeb3e008aa7eedf9c739")
