-- Lua provided by RyzenAPI
-- Game: addappid(1376580)

-- MAIN APPLICATION
addappid(1376580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376581, 1, "e9170023ba8bc98eb5a4d8fa8e3f5c0b9ba0f64ab1967e5f05d71abf70adc746")
