-- Lua provided by RyzenAPI
-- Game: AppID 628530

-- MAIN APPLICATION
addappid(628530)

-- MAIN APP DEPOTS / PACKAGES
addappid(628531, 1, "93d719e2b0621b4d28341cbae8f05edfa5c685e50521a26dd4192c7857c155ce")
addappid(628532, 1, "45a1ff52420a222084199b3f2f98a64888431f513b2d7bffa016ee3119351855")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
