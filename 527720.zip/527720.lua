-- Lua provided by RyzenAPI 
-- Game: Keep Defending
addappid(527720)
addappid(527721, 1, "4f2a1100642bdcc6664eaac4c40d61802302158e9e02239434864421461ae308")
