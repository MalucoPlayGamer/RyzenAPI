-- Lua provided by RyzenAPI
-- Game: Hidden & Dangerous 2: Courage Under Fire

-- MAIN APPLICATION
addappid(703320)

-- MAIN APP DEPOTS / PACKAGES
addappid(703321, 1, "90d29815666210aca48efac852ec34cfd11f206aa0a418afab806939dac3df65")
addappid(703322, 1, "2e0ccc974522b48c11eb220529d8a37d7e5650fe7bb7202e7242a4a31f5eae30")
addappid(703323, 1, "958686c7b5c48a318167c85bf8b5bd0896dfefd6da5d23cc70dc66a576886a4f")
addappid(703324, 1, "156290b6fe77b2ec8616d628b99249b6eec191220881f415df0f73380435afd9")
addappid(703325, 1, "2067eaacd05cec3c3e9e13af641644ebea54fa88a0a3f3b4fd2b5944648cb2dd")
addappid(703326, 1, "52707f9b1f7c68d7f020c50f455da8b1777c7ac50b8beb64e3e7cf1eac5639b1")
addappid(703327, 1, "6405fe98ba1a966e721fece3b2080db81878e705826f6c3273a86c4e8dd85b0b")
