-- Lua provided by RyzenAPI
-- Game: Game: Can't Live Without Electricity

-- MAIN APPLICATION
addappid(2337140)
-- Game: addappid(2337140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337141, 1, "53c0d8b0cbd2014b8b5a4837c1c6a035fc5b6813ac4acd2ca489ae973c61b475")
