-- Lua provided by SkyAPI 
-- Game: Factory Town
addappid(860890)
addappid(860891, 1, "9142a0e86a8b973c9d887ccf6e038c5e77a482fe359542e9326e13365ed43c06")
addappid(860892, 1, "b390a5e8fdd3806a130738f79c9f0a89801c1b23bb079ae53d2095331ac7b99d")
