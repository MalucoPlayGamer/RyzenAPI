-- Lua provided by RyzenAPI
-- Game: Game: AppID 1975360

-- MAIN APPLICATION
addappid(1975360)
-- Game: addappid(1975360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975361, 1, "4817875083c0bc6915a88f5f46621248f5c0555dcf9cfc2a31cd2f71b845c656")
