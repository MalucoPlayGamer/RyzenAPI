-- Lua provided by RyzenAPI
-- Game: AppID 1975360

-- MAIN APPLICATION
addappid(1975360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975361, 1, "4817875083c0bc6915a88f5f46621248f5c0555dcf9cfc2a31cd2f71b845c656")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
