-- Lua provided by RyzenAPI
-- Game: Game: Survival: Fountain of Youth Demo

-- MAIN APPLICATION
addappid(1967730)
-- Game: addappid(1967730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967731, 1, "2a18038f66565dac89eafea166d4579acdd50db034627e6f3b9f5fd07caa6b2e")
