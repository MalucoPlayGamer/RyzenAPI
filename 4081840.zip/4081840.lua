-- Lua provided by RyzenAPI
-- Game: Escape from Yandere

-- MAIN APPLICATION
addappid(4081840)

-- MAIN APP DEPOTS / PACKAGES
addappid(4081841, 1, "d7484400be27a04b6ecee36e7cedb34112d26303e4f9778b8a331a0283c8f8c9")
