-- Lua provided by RyzenAPI
-- Game: AppID 1687030

-- MAIN APPLICATION
addappid(1687030)
-- Game: addappid(1687030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687031, 1, "0303923ac3decfee030399143ba563ad46adc751be806e10c3fd7e9f4c4c60ea")
