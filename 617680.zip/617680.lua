-- Lua provided by RyzenAPI
-- Game: Drunk-Fu: Wasted Masters

-- MAIN APPLICATION
addappid(617680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(617681, 1, "e1d701ec402557502c48f34799ef35b1e14d5817f5d5f5f2fc211cc106f29c96")

