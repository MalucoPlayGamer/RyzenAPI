-- Lua provided by RyzenAPI
-- Game: Game: AppID 617680

-- MAIN APPLICATION
addappid(617680)
-- Game: addappid(617680)

-- MAIN APP DEPOTS / PACKAGES
addappid(617681, 1, "e1d701ec402557502c48f34799ef35b1e14d5817f5d5f5f2fc211cc106f29c96")
