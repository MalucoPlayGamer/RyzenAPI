-- Lua provided by RyzenAPI
-- Game: 521940

-- MAIN APPLICATION
addappid(521940)
-- Game: addappid(521940)

-- MAIN APP DEPOTS / PACKAGES
addappid(521941, 1, "694e26bb00764247ee3196901b928d1e9cf6a58c00a7a52bbc26fe19de3baa0a")
addappid(521942, 1, "4e9f05e55418eb9451a2b4529b27f949c698eb33cdd84e75652efd92e1ca826d")
