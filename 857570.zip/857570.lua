-- Lua provided by RyzenAPI
-- Game: World of Feudal

-- MAIN APPLICATION
addappid(857570)

-- MAIN APP DEPOTS / PACKAGES
addappid(857571, 1, "88d6249e66b7c6d4238d3e36ee2aef6e2e8ad69397c1bec7a87c51e34514e9ee")

