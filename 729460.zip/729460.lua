-- Lua provided by RyzenAPI
-- Game: Distant Space 2

-- MAIN APPLICATION
addappid(729460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(729461, 1, "c7787a356d48c4f237d7d7c5edbaf19ab01f988d2d6f375ae8155148a4c7bdd6")

