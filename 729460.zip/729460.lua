-- Lua provided by RyzenAPI
-- Game: 729460

-- MAIN APPLICATION
addappid(729460)
-- Game: addappid(729460)

-- MAIN APP DEPOTS / PACKAGES
addappid(729461, 1, "c7787a356d48c4f237d7d7c5edbaf19ab01f988d2d6f375ae8155148a4c7bdd6")
