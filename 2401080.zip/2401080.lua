-- Lua provided by RyzenAPI
-- Game: addappid(2401080)

-- MAIN APPLICATION
addappid(2401080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401081, 1, "a6f760965a6604695f442e0d86a2ef270a1d0647c58dbe6bf35f8f348e44e1bc")
