-- Lua provided by RyzenAPI
-- Game: Incandescent

-- MAIN APPLICATION
addappid(380550)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(380551, 1, "264d4343b7642e139aa4e158931d1a8c36f23b96422f097ecc20f2b80452724b")
