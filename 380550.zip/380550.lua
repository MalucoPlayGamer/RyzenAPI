-- Lua provided by RyzenAPI
-- Game: Game: AppID 380550

-- MAIN APPLICATION
addappid(380550)
-- Game: addappid(380550)

-- MAIN APP DEPOTS / PACKAGES
addappid(380551, 1, "264d4343b7642e139aa4e158931d1a8c36f23b96422f097ecc20f2b80452724b")
