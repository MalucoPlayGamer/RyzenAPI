-- Lua provided by RyzenAPI 
-- Game: AppID 552890
addappid(552890)
addappid(552891, 1, "238fe6e94759dd9f0fd91074b63a920b7a6feac6da12efa112288d8da060282b")
