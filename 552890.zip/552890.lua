-- Lua provided by RyzenAPI
-- Game: Zombie Panic! Source Mod Tools

-- MAIN APPLICATION
addappid(552890)

-- MAIN APP DEPOTS / PACKAGES
addappid(552891, 1, "238fe6e94759dd9f0fd91074b63a920b7a6feac6da12efa112288d8da060282b")

