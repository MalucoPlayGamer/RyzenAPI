-- Lua provided by RyzenAPI
-- Game: addappid(1188800)

-- MAIN APPLICATION
addappid(1188800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188801, 1, "bb721622d7680f78624208c91ad918e5b4689e5d9c2dc680345eb0ffd5a5c875")
