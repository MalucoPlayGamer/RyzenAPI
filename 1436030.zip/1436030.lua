-- Lua provided by RyzenAPI
-- Game: Ragnaröck Demo

-- MAIN APPLICATION
addappid(1436030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436031, 1, "de7b1df1dbf991c86bfe27e1faf7a793ca3a4ed5cfc347bff655d6f7f0744d50")

