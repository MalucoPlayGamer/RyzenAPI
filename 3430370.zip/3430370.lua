-- Lua provided by RyzenAPI
-- Game: 3430370

-- MAIN APPLICATION
addappid(3430370)
-- Game: addappid(3430370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430371, 1, "fa8b4799612372a79aeef60aeadc7581fa20877fcb864af0e7b3ce84972459a8")
