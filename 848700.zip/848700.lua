-- Lua provided by SkyAPI 
-- Game: AppID 848700
addappid(848700)
addappid(848701, 1, "3ce4afbf1d5b90ead4d3f6915a33d64d6f7d1c844b8b3a9742ce4ff9d48d10bb")
