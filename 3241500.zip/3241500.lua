-- Lua provided by RyzenAPI
-- Game: Augurium Mortis Demo

-- MAIN APPLICATION
addappid(3241500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241502,0,"f4624e8acf38de834332a4b625a276c42273fa744252c78c71aea6171a752fe7")

