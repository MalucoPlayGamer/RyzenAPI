-- Lua provided by RyzenAPI
-- Game: Voxel Project VR Demo

-- MAIN APPLICATION
addappid(3148280)
-- Game: addappid(3148280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148281, 1, "549621e176c196b0ce5d800529e2a44a903103919e9d1926474c996eaf4d60ba")
