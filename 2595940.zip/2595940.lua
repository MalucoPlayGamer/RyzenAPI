-- Lua provided by RyzenAPI
-- Game: Magical Bakery

-- MAIN APPLICATION
addappid(2595940)
addappid(3049310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595941, 1, "ea7028796adb4b8c3ec8308c5b16b9f311e42817fddf44855ec727b981cc41a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
