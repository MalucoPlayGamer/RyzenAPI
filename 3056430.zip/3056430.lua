-- Lua provided by SkyAPI 
-- Game: Steel Warrior
addappid(3056430)
addappid(3056431, 1, "fb1224232ef2aa45a678131a4234a11d6129d4e182e3340d98ca75c6003b3d93")
