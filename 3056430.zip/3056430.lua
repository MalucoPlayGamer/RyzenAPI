-- Lua provided by RyzenAPI
-- Game: Game: Steel Warrior

-- MAIN APPLICATION
addappid(3056430)
-- Game: addappid(3056430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056431, 1, "fb1224232ef2aa45a678131a4234a11d6129d4e182e3340d98ca75c6003b3d93")
