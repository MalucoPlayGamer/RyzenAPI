-- Lua provided by RyzenAPI
-- Game: addappid(334850)

-- MAIN APPLICATION
addappid(334850)

-- MAIN APP DEPOTS / PACKAGES
addappid(334851, 1, "f3baba63d5137efff62c2c5e33a9597327f6d9140d2db5449efc86fc45fba4fb")
