-- Lua provided by RyzenAPI
-- Game: 1931: Scheherazade at the Library of Pergamum

-- MAIN APPLICATION
addappid(334850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(334851, 1, "f3baba63d5137efff62c2c5e33a9597327f6d9140d2db5449efc86fc45fba4fb")

