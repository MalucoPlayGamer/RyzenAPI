-- Lua provided by RyzenAPI
-- Game: The Growth Journey

-- MAIN APPLICATION
addappid(416610)
-- Game: addappid(416610)

-- MAIN APP DEPOTS / PACKAGES
addappid(416611, 1, "da4569ec1582cd316755008281ef0fc4b257aa873dd98003c3debdc121239d5b")
addappid(416612, 1, "1ac726f026af1a57dc646c0dc193c3a6a150c68a3fccfacc545d728ce2eff7b3")
addappid(416613, 1, "7422b2ead12945914e426ab40eff9768c57a50fd5d4ff7742edc2baa03896ce6")
addappid(431820, 0, "ec29c3a00f84fb46fb309907e9be6a90733465399cd6a40809b23301409eab2a")
