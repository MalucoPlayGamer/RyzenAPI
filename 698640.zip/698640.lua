-- Lua provided by RyzenAPI
-- Game: Game: Deep Sky Derelicts

-- MAIN APPLICATION
addappid(698640)
-- Game: addappid(698640)

-- MAIN APP DEPOTS / PACKAGES
addappid(698641, 1, "4424bef307f10780448a5871e9f820c61fa0414c45811682453045bcc5eae1f5")
addappid(698642, 1, "5902e55ea6cd266c85dfd176b443286aa7c9450dc262c03db32a47530d5870d1")
addappid(698643, 1, "dd96bd78aa84d754ae4c49ec89ffdc9c4b7bfc35fc1658c9f4d3312faa1e653e")
addappid(698644, 1, "337281a6a3fef91c11f8c467acbd0d4ee5decfa25e5c4068b62ddf51d3714691")
addappid(1076630, 0, "1d1c6fdadf36a0dc422c3b5a2896c91168129326289438fa5961e901d8076c4f")
addappid(1076631, 0, "f0892273c9cf7b0784b3ddc102f05d8d8201e97ebc0eaeaddc324b1f499ec140")
addappid(1076632, 0, "e50f4621562777a8f2ac3abec9a6af1547bd23c241fddaef2425bbbf53f39eec")
addappid(1189700, 0, "ded38d6bb54d657af46d6aaea9f714f65f0f221678e2f741c074ca3504ec9103")
addappid(1189701, 0, "081eb68b1fdae8142b0763f8a30bcb8ef3bcbb88f6e6fdbb3cd86644a56a878f")
addappid(1189702, 0, "468ce7d11facff6a159f769a6568fb6a117d7ddbb28aa7be6491c41bbbf6e0b8")
