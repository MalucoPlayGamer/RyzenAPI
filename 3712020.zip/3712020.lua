-- Lua provided by RyzenAPI
-- Game: Game: 意识分裂开篇季

-- MAIN APPLICATION
addappid(3712020)
-- Game: addappid(3712020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3712021, 1, "befead842594f096b8b7184b1a12ab7dddcdb21b1beefe7c5737c8647a00e4d2")
