-- Lua provided by RyzenAPI
-- Game: 意识分裂开篇季

-- MAIN APPLICATION
addappid(3712020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3712021, 1, "befead842594f096b8b7184b1a12ab7dddcdb21b1beefe7c5737c8647a00e4d2")

