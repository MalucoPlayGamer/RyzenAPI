-- Lua provided by RyzenAPI
-- Game: AppID 562320

-- MAIN APPLICATION
addappid(562320)

-- MAIN APP DEPOTS / PACKAGES
addappid(562321, 1, "4147260545c782afdeac0ca9007eb817208e7f6b62f8537d932288257e4cc691")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
