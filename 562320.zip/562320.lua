-- Lua provided by RyzenAPI
-- Game: AppID 562320

-- MAIN APPLICATION
addappid(562320)
-- Game: addappid(562320)

-- MAIN APP DEPOTS / PACKAGES
addappid(562321, 1, "4147260545c782afdeac0ca9007eb817208e7f6b62f8537d932288257e4cc691")
