-- Lua provided by RyzenAPI
-- Game: Uphill Skiing

-- MAIN APPLICATION
addappid(646380)
-- Game: addappid(646380)

-- MAIN APP DEPOTS / PACKAGES
addappid(646381, 1, "d0f9c890a7ede1cc63fe2926452f5345caa00429349daa6df3df65eee8bcbd30")
