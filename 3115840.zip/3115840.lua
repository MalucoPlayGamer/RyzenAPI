-- Lua provided by RyzenAPI
-- Game: Sexy Girl Next Door - Virtual Valentine Sex

-- MAIN APPLICATION
addappid(3115840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115841, 1, "3180f7ad45376d2df8da7e98444b2ae2b7434f57b731ca208afc9079867f4ef4")
