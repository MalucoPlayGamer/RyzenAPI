-- Lua provided by RyzenAPI
-- Game: AppID 1576550

-- MAIN APPLICATION
addappid(1576550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576551, 1, "bab48580e3a77f6277bbc46da4204dffedc96d883bbe309e249b915ca638c4cb")
