-- Lua provided by RyzenAPI
-- Game: addappid(793690)

-- MAIN APPLICATION
addappid(793690)

-- MAIN APP DEPOTS / PACKAGES
addappid(793691, 1, "9cf372b33668d0ca6a6211e7810518ab791b9b76d14b715ed9199b8709c2f60a")
