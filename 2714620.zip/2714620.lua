-- Lua provided by RyzenAPI
-- Game: Game: Duck Detective: The Ghost of Glamping

-- MAIN APPLICATION
addappid(2714620)
-- Game: addappid(2714620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2714621, 1, "e57ebdcab7f8de91e53f0713b235d9a603b6cdb47cc1157a489b3da92f92e770")
