-- Lua provided by RyzenAPI
-- Game: Game: AppID 1963120

-- MAIN APPLICATION
addappid(1963120)
addappid(1963160)
addappid(1963161)
addappid(1963162)
addappid(1963163)
-- Game: addappid(1963120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963121, 1, "1418226a7aae6226936c7aa7748cf23112272ac2334daf5efe4090706338bf37")
