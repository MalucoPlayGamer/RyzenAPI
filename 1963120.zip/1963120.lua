-- Lua provided by RyzenAPI 
-- Game: AppID 1963120
addappid(1963120)
addappid(1963121, 1, "1418226a7aae6226936c7aa7748cf23112272ac2334daf5efe4090706338bf37")
addappid(1963160)
addappid(1963161)
addappid(1963162)
addappid(1963163)
