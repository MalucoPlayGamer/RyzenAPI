-- Lua provided by RyzenAPI
-- Game: Ghostland Yard

-- MAIN APPLICATION
addappid(2051130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051131, 1, "d26ab2ba3edceac44a8b15e55a10a144151e65f48029bb05b7d8c0c8da9813d3")

