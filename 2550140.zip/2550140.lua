-- Lua provided by RyzenAPI
-- Game: 2550140

-- MAIN APPLICATION
addappid(2550140)
-- Game: addappid(2550140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550141, 1, "5965f2ff3c44de79fca6cb993d1a11cc54ad501d714247880b7e1ad90786bcc5")
