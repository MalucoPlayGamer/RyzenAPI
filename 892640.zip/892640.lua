-- Lua provided by RyzenAPI
-- Game: FAN'CIE VEER! (Fish Are Nasty, Cake Is Excellent Vektor Evading Emblazed Rapture)

-- MAIN APPLICATION
addappid(892640)

-- MAIN APP DEPOTS / PACKAGES
addappid(892641, 1, "d328a027ff4a5f55fd468c19e395d863f4497f6e33db3340ed8ef0bf8b18a19d")

