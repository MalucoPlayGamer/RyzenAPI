-- Lua provided by RyzenAPI
-- Game: addappid(2260490)

-- MAIN APPLICATION
addappid(2260490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260492,0,"68f295482e320ba517014ca931b6ef8bcf7942b2ed7de5fb3ba64b1d702fef40")
