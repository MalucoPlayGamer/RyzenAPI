-- Lua provided by RyzenAPI
-- Game: Game: 白噪生存指南 Playtest

-- MAIN APPLICATION
addappid(3014560)
-- Game: addappid(3014560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014561, 1, "36b732f950099bf1b8cf7b5d3719cc6c99e63ee013f7213c68cfd94cd904a0b1")
