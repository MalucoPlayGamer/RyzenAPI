-- Lua provided by RyzenAPI
-- Game: 樱花校园之恋模拟器

-- MAIN APPLICATION
addappid(2532320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532321, 1, "9c790156c8c42b90b120f4a5e47cac25dc66410750581a500d4bc651aa382a16")

