-- Lua provided by RyzenAPI
-- Game: HudSight - crosshair overlay

-- MAIN APPLICATION
addappid(1477830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477831, 1, "c4664a1b98d39823730ed0c7029bba2bea148ba932f8d40623184faa9d95fe05")
