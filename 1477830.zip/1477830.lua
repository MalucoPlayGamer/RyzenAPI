-- Lua provided by RyzenAPI 
-- Game: HudSight - crosshair overlay
addappid(1477830)
addappid(1477831, 1, "c4664a1b98d39823730ed0c7029bba2bea148ba932f8d40623184faa9d95fe05")
