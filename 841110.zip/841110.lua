-- Lua provided by RyzenAPI
-- Game: Game: AppID 841110

-- MAIN APPLICATION
addappid(841110)
-- Game: addappid(841110)

-- MAIN APP DEPOTS / PACKAGES
addappid(841111, 1, "7989bf1a4f3d5068ae4a085b57c30d2a0a477beccfb661d5fde839d3d99a7493")
