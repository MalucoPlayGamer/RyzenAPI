-- Lua provided by RyzenAPI
-- Game: addappid(1123140)

-- MAIN APPLICATION
addappid(1123140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123141, 1, "f2c4796670a6e9fdf5e753ca69bb4df72de8952d3f5180f75adc56c349b2c70b")
