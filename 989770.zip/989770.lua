-- Lua provided by RyzenAPI
-- Game: Biker Garage: Mechanic Simulator

-- MAIN APPLICATION
addappid(989770)
addappid(1210200)
addappid(1227560)
addappid(1258490)
addappid(1341350)
addappid(1341351)

-- MAIN APP DEPOTS / PACKAGES
addappid(989771,0,"16a8b3864d0378e7b5c3b18ad8f7b83be889fb0fff20d0f41f3c1a22b3add192")

