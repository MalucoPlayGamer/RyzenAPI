-- Lua provided by RyzenAPI
-- Game: Game: Biker Garage: Mechanic Simulator

-- MAIN APPLICATION
addappid(989770)
-- Game: addappid(989770)

-- MAIN APP DEPOTS / PACKAGES
addappid(989771, 1, "16a8b3864d0378e7b5c3b18ad8f7b83be889fb0fff20d0f41f3c1a22b3add192")
