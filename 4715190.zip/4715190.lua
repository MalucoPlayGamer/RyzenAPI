-- 4715190's Lua and Manifest Created by Hubcap Manifest
-- Only Farming - Cozy Harvesting Game
-- Created: August 17, 2026 at 14:42:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4715190) -- Only Farming - Cozy Harvesting Game
-- MAIN APP DEPOTS
addappid(4715191, 1, "3fd1283805e18566c362618736e0ada9464d52b79c7bf7390cfdceb05bb322df") -- Depot 4715191
setManifestid(4715191, "3220336470592246871", 130095888)