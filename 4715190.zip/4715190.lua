-- Lua provided by RyzenAPI
-- Game: Only Farming - Cozy Harvesting Game

-- MAIN APPLICATION
addappid(4715190) -- Only Farming - Cozy Harvesting Game

-- MAIN APP DEPOTS / PACKAGES
addappid(4715191, 1, "3fd1283805e18566c362618736e0ada9464d52b79c7bf7390cfdceb05bb322df") -- Depot 4715191

