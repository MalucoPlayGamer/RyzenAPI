-- Lua provided by RyzenAPI
-- Game: Pizza Game

-- MAIN APPLICATION
addappid(710710)

-- MAIN APP DEPOTS / PACKAGES
addappid(710711,0,"f0a44588a884a0d32febed4d185b78053a42700835528e1299f86bebba693995")

