-- Lua provided by RyzenAPI
-- Game: Viki Spotter: Professions

-- MAIN APPLICATION
addappid(935440)

-- MAIN APP DEPOTS / PACKAGES
addappid(935441, 1, "e77fe2113e8fb82677854ed60829bf0bad61bedcea1d0b01f68b189a0c0e2972")

