-- Lua provided by RyzenAPI
-- Game: Mafia II Demo

-- MAIN APPLICATION
addappid(50280)
-- Game: addappid(50280)

-- MAIN APP DEPOTS / PACKAGES
addappid(50281, 1, "56759616a5670d576ba26edd62566d521b0b4bcdae44e280ad92155f4c53914f")
addappid(50285, 1, "57a9d7ec7936b195f1f7f633632de11d2d3778f28ef787fda07b234ff0722cd2")
addappid(50286, 1, "ea460f099008ae28446f67f0eddd0686833f34233d16d3f6b2b2f743340ef88a")
addappid(50289, 1, "c29ec016c9b16ff1ec5fb7f9fd7b141fbd23a6d72ef2040fe7dab8fb76179445")
addappid(50290, 1, "16c8dca37112a414fb3f50a2d5f799699cef706f5d8bb8a6ef2eac8eb497442d")
