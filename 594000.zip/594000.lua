-- Lua provided by RyzenAPI
-- Game: addappid(594000)

-- MAIN APPLICATION
addappid(594000)

-- MAIN APP DEPOTS / PACKAGES
addappid(594001, 1, "14d9ebf3bead8e6a0d0641192ed3999e2b02e41fe3999bef9c0ab4fea0ce4c44")
addappid(1064560, 0, "b082b8100170172c5ded021b0f08e041fb7b5d59314cfe6693507bc47883c93d")
