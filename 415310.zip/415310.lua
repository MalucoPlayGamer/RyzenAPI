-- Lua provided by RyzenAPI
-- Game: 415310

-- MAIN APPLICATION
addappid(415310)
-- Game: addappid(415310)

-- MAIN APP DEPOTS / PACKAGES
addappid(415311, 1, "706edac69bfa1d68d0cc569b8a6b34fc158817242096430c10da296a97ea8a7d")
