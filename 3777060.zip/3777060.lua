-- Lua provided by RyzenAPI 
-- Game: Gold Miner:Classic Edition
addappid(3777060)
addappid(3777061, 1, "dd1f55a4e091d904244cdd3d10c8f77d867475716419896c4e53be1afbce421e")
