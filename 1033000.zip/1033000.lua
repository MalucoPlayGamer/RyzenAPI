-- Lua provided by RyzenAPI
-- Game: Shoot The Zombirds VR

-- MAIN APPLICATION
addappid(1033000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033001, 1, "85496b73fa4864ec90b55facaa94d26935ac358daa5817df5e391b29830ea47a")

