-- Lua provided by RyzenAPI
-- Game: Tales of Monkey Island: Chapter 5 - Rise of the Pirate God

-- MAIN APPLICATION
addappid(31210)

-- MAIN APP DEPOTS / PACKAGES
addappid(31211, 1, "298fd42388858414ae542ee172c84f73a5f6e4ce6fb0058277b433e29402d091")

