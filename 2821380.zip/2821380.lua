-- Lua provided by RyzenAPI
-- Game: Daydam Knight

-- MAIN APPLICATION
addappid(2821380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821381, 1, "9ad44ccd432ca2d805c4aca7b47b624c8c548771a042e5396f83833b246e0038")
