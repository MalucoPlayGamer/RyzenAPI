-- Lua provided by RyzenAPI
-- Game: AppID 1229250

-- MAIN APPLICATION
addappid(1229250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229251, 1, "bea7218f81e1b435ce4c3019efdcdc064a0cbf5449eb0397a6f092e4bd1c148a")
addappid(1229252, 1, "d86e041522ac349ecfe30bffb2f59b04e908042014fc0f9818d6dd2b87b7283f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
