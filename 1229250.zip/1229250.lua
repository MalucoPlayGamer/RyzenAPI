-- Lua provided by SkyAPI 
-- Game: AppID 1229250
addappid(1229250)
addappid(1229251, 1, "bea7218f81e1b435ce4c3019efdcdc064a0cbf5449eb0397a6f092e4bd1c148a")
addappid(1229252, 1, "d86e041522ac349ecfe30bffb2f59b04e908042014fc0f9818d6dd2b87b7283f")
