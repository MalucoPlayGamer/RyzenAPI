-- Lua provided by RyzenAPI
-- Game: GodsArena Online

-- MAIN APPLICATION
addappid(3754990)

