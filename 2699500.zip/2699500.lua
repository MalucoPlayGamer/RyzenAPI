-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2699500)
addappid(2699501)
addappid(2699503)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699502,0,"3d8c1dfa845845717c0cae86bfc7202d70bbf2bdbda2b488017d177be646d392")

