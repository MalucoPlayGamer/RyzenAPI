-- Lua provided by RyzenAPI
-- Game: addappid(3411720)

-- MAIN APPLICATION
addappid(3411720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411723,0,"2eea92a396d750e42a922f8de5649d3891fa6ce2f664f80632ad27e199f3894b")
