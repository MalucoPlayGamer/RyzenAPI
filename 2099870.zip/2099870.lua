-- Lua provided by RyzenAPI
-- Game: Game: Ever Seen a Cat? - Paper Edition + Wallpapers

-- MAIN APPLICATION
addappid(2099870)
-- Game: addappid(2099870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099871, 1, "8faf5b0d5ae3e686bd42f0fb24efb7c15643ac60913098d4dc651e6677956922")
