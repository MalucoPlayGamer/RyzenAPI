-- Lua provided by RyzenAPI
-- Game: Game: Spartaga

-- MAIN APPLICATION
addappid(657930)
-- Game: addappid(657930)

-- MAIN APP DEPOTS / PACKAGES
addappid(657931, 1, "5518b49024e0e238891dbe4e5ba0d48f9c82299c59c68c5d61e46c0d2254c029")
