-- Lua provided by RyzenAPI
-- Game: Empyrion - Galactic Survival

-- MAIN APPLICATION
addappid(383120)
addappid(2765930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(383121, 1, "34c1757941c6a2a64511d2d07327a24569014d7bd684b4259ec76f37f7aedc55")

