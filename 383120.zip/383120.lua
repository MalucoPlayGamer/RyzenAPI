-- Lua provided by RyzenAPI
-- Game: Empyrion - Galactic Survival

-- MAIN APPLICATION
addappid(383120)
addappid(2765930)

-- MAIN APP DEPOTS / PACKAGES
addappid(383121, 1, "34c1757941c6a2a64511d2d07327a24569014d7bd684b4259ec76f37f7aedc55")
