-- Lua provided by RyzenAPI
-- Game: Duskborn

-- MAIN APPLICATION
addappid(2474900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474901, 1, "e38f3d2ec659ce08b6b29c6aa65c37e56f681fd9c9ece8623d350d6a82b4cf45")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
