-- Lua provided by RyzenAPI
-- Game: Game: Duskborn

-- MAIN APPLICATION
addappid(2474900)
-- Game: addappid(2474900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474901, 1, "e38f3d2ec659ce08b6b29c6aa65c37e56f681fd9c9ece8623d350d6a82b4cf45")
