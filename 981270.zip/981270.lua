-- Lua provided by RyzenAPI
-- Game: AppID 981270

-- MAIN APPLICATION
addappid(981270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(981271, 1, "3253539efddae878ce8ff552af6854cb1d560b818844c9279cbf98d2645e536d")
addappid(981272, 1, "84ab7cf2aee38e685622d10f7694082a918df2dddde59b5e29599ba00f79a841")

