-- Lua provided by RyzenAPI
-- Game: Game: AppID 981270

-- MAIN APPLICATION
addappid(981270)
-- Game: addappid(981270)

-- MAIN APP DEPOTS / PACKAGES
addappid(981271, 1, "3253539efddae878ce8ff552af6854cb1d560b818844c9279cbf98d2645e536d")
addappid(981272, 1, "84ab7cf2aee38e685622d10f7694082a918df2dddde59b5e29599ba00f79a841")
