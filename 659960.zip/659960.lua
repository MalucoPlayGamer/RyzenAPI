-- Lua provided by RyzenAPI
-- Game: 659960

-- MAIN APPLICATION
addappid(659960)
-- Game: addappid(659960)

-- MAIN APP DEPOTS / PACKAGES
addappid(659961, 1, "d611bba1e59e9d5da67e5e9addc3edef8ad05f1dbc35220b6891ae890f644e52")
