-- Lua provided by RyzenAPI
-- Game: Lockdown Lewd UP! ❤️ New Hope Edition

-- MAIN APPLICATION
addappid(1353900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353901, 1, "dab2018c9a2adf9d313a6eff259a8e95f7a1df196842a5e57dd4900d53e2019f")

