-- Lua provided by RyzenAPI
-- Game: addappid(1762920)

-- MAIN APPLICATION
addappid(1762920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762921, 1, "2b556d491c0185aec882eb5252ea56099eee2065d02ca72be151f125f3ced049")
