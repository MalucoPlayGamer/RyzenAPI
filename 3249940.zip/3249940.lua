-- Lua provided by RyzenAPI
-- Game: Try to survive Today Demo

-- MAIN APPLICATION
addappid(3249940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249941, 1, "736c73289e96877f17551a1b2a8d966857900721d7dcf91448f1f4b668868691")
