-- Lua provided by RyzenAPI
-- Game: Diastone: Memories

-- MAIN APPLICATION
addappid(803130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(803131, 1, "b388ee8caff446f350cac86c2a82a2cdb002457d8d4ad811a37f379a572b249f")

