-- Lua provided by RyzenAPI
-- Game: Diastone: Memories

-- MAIN APPLICATION
addappid(803130)

-- MAIN APP DEPOTS / PACKAGES
addappid(803131, 1, "b388ee8caff446f350cac86c2a82a2cdb002457d8d4ad811a37f379a572b249f")
