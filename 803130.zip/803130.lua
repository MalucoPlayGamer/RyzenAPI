-- Lua provided by SkyAPI 
-- Game: Diastone: Memories
addappid(803130)
addappid(803131, 1, "b388ee8caff446f350cac86c2a82a2cdb002457d8d4ad811a37f379a572b249f")
