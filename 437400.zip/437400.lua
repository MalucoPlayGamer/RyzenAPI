-- Lua provided by RyzenAPI
-- Game: 437400

-- MAIN APPLICATION
addappid(437400)
-- Game: addappid(437400)

-- MAIN APP DEPOTS / PACKAGES
addappid(437401, 1, "7dd898a1f03b206024873f8060470aa7995f29e1cc520c4f5e37b81fa37bd6bf")
