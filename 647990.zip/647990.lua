-- Lua provided by RyzenAPI
-- Game: Batter Up! VR

-- MAIN APPLICATION
addappid(647990)

-- MAIN APP DEPOTS / PACKAGES
addappid(647991,0,"a4b8c0d5eedf74252a3e1afc104a9ca04e9cb97a14537f5a0aefac050f5ba65c")

