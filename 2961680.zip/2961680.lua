-- Lua provided by RyzenAPI 
-- Game: LustRunner 3069: Tokyo Crisis
addappid(2961680)
addappid(2961681, 1, "02f9d4491b366b29a357009525e21203ae0f83f8b63923624e6202e9d9286471")
