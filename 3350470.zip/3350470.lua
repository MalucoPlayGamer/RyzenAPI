-- Lua provided by RyzenAPI
-- Game: addappid(3350470)

-- MAIN APPLICATION
addappid(3350470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350471, 1, "aa455c139ed574eeb891aa6af5fc41b4e177da3a64738c09fa7371a200156726")
