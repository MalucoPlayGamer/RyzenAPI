-- Lua provided by RyzenAPI
-- Game: Toilet Run

-- MAIN APPLICATION
addappid(629240)

-- MAIN APP DEPOTS / PACKAGES
addappid(629241, 1, "ffc72f4b6c6d5f329d0fd55fb52f0a90a38814861afc84fac7faaa4f6593d2d2")

