-- Lua provided by RyzenAPI
-- Game: Game: AppID 782350

-- MAIN APPLICATION
addappid(782350)
-- Game: addappid(782350)

-- MAIN APP DEPOTS / PACKAGES
addappid(782351, 1, "df54a04e2d7d0042c3fdd919bff564a4c82ae1a654f1a13b525f050dea03ab2e")
