-- Lua provided by RyzenAPI
-- Game: addappid(1983700)

-- MAIN APPLICATION
addappid(1983700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983701, 1, "354f8e3dd7688c063616d537c0dbdc9bbc4b950e9c822236b78a924cb4cf91b6")
