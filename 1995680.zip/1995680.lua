-- Lua provided by RyzenAPI 
-- Game: Twilight bride :VORMSLEGEND
addappid(1995680)
addappid(1995681, 1, "4da94335659e46128a2d24ccb7e9d036f171438691aa81f7d88f02b45a47aa39")
addappid(2067880)
