-- Lua provided by SkyAPI 
-- Game: AppID 2064080
addappid(2064080)
addappid(2064081, 1, "e85c2037eaf94c553f77c8b2d1d28f010a57a56ca0c4eb8036adc39a3e6ea475")
