-- Lua provided by RyzenAPI
-- Game: addappid(1837480)

-- MAIN APPLICATION
addappid(1837480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837481, 1, "e140fb5933b11af9d8299dc0e970924ee6e1fb0095d1a4c8e2569071456fc45b")
