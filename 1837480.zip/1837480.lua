-- Lua provided by RyzenAPI 
-- Game: Vietnam War
addappid(1837480)
addappid(1837481, 1, "e140fb5933b11af9d8299dc0e970924ee6e1fb0095d1a4c8e2569071456fc45b")
