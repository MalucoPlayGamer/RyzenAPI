-- Lua provided by RyzenAPI
-- Game: Befriended Curse

-- MAIN APPLICATION
addappid(2655580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655582,0,"fb8936cafc31bf5147f6377d69f58b1c194959f9f73ba24f1a5744fa7acd52c9")

