-- Lua provided by RyzenAPI
-- Game: Befriended Curse

-- MAIN APPLICATION
addappid(2655580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2655582,0,"fb8936cafc31bf5147f6377d69f58b1c194959f9f73ba24f1a5744fa7acd52c9")

