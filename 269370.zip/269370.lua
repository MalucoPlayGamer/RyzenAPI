-- Lua provided by RyzenAPI
-- Game: 269370

-- MAIN APPLICATION
addappid(269370)
-- Game: addappid(269370)

-- MAIN APP DEPOTS / PACKAGES
addappid(269371, 1, "240963bc6fb5afc9425a8a87fa7fd374228202ae5024d22882d9b4233b49903f")
