-- Lua provided by RyzenAPI
-- Game: Reaper - Tale of a Pale Swordsman

-- MAIN APPLICATION
addappid(269370)

-- MAIN APP DEPOTS / PACKAGES
addappid(269371, 1, "240963bc6fb5afc9425a8a87fa7fd374228202ae5024d22882d9b4233b49903f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
