-- Lua provided by RyzenAPI
-- Game: Fetish Locator: S&M Studio

-- MAIN APPLICATION
addappid(3763690) -- Fetish Locator: S&M Studio

-- MAIN APP DEPOTS / PACKAGES
addappid(3763699, 1, "7621cfcf106ea0dbe9f8abdc242b97389fb2e9bc1e7da41058e8ed2a41c87c92") -- Depot 3763699

