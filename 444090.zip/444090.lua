-- Lua provided by RyzenAPI
-- Game: AppID 444090

-- MAIN APPLICATION
addappid(444090)

-- MAIN APP DEPOTS / PACKAGES
addappid(444091, 1, "10c4cdddc6b9a90adbc280dcfaeda6519a17ccfc4de1c42a3e9245e0ee6a6f00")
addappid(444092, 1, "6b75ddbb48d744a88b26d0ba4121a677fb7fd5858ce6b24788372890a2a1d794")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(444120)
addappid(550460)
addappid(550461)
addappid(664770)
addappid(703350)
addappid(751120)
addappid(803380)
addappid(803381)
addappid(803510)
addappid(961090)
addappid(978000)
addappid(980720)
addappid(995960)
addappid(995970)
addappid(1012960)
addappid(1038330)
addappid(1103990)
addappid(1271270)
addappid(1517460)
addappid(1517480)
addappid(1517481)
addappid(1517482)
addappid(1559290)
addappid(1663130)
addappid(1663240)
addappid(1721880)
addappid(1843930)
addappid(1843931)
addappid(1843932)
addappid(1895320)
addappid(2012730)
addappid(2087420)
