-- Lua provided by RyzenAPI
-- Game: Game: Six Days in Fallujah

-- MAIN APPLICATION
addappid(1548850)
-- Game: addappid(1548850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548851, 1, "5ddd294e2b084b4ae33865370c91bf4f1f505788577332bd9542a4cf4d01835c")
