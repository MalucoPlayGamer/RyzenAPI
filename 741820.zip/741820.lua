-- Lua provided by RyzenAPI
-- Game: Prey: Typhon Hunter

-- MAIN APPLICATION
addappid(741820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(741821, 1, "5f89b711a0810988e3e58ca86d7ce89ab236b5198c56dd0c58b2f0163c1c8f1f")

