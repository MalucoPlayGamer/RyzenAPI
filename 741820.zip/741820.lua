-- Lua provided by RyzenAPI 
-- Game: AppID 741820
addappid(741820)
addappid(741821, 1, "5f89b711a0810988e3e58ca86d7ce89ab236b5198c56dd0c58b2f0163c1c8f1f")
