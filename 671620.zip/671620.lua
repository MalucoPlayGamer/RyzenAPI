-- Lua provided by RyzenAPI
-- Game: AppID 671620

-- MAIN APPLICATION
addappid(671620)

-- MAIN APP DEPOTS / PACKAGES
addappid(671621, 1, "f9b541fe6128134bb21c1c789f4a1ab889ccf7c086772dce6736f196fc12b3d0")

