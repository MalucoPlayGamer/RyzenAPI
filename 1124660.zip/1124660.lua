-- Lua provided by RyzenAPI
-- Game: Game: AppID 1124660

-- MAIN APPLICATION
addappid(1124660)
-- Game: addappid(1124660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124661, 1, "e2fa07bb6651e5cb4438d0f63b73b9f92f688170371c152edddd0d77ff3388e4")
