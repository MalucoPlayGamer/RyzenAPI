-- Lua provided by RyzenAPI
-- Game: Creepy Tale 2 Soundtrack

-- MAIN APPLICATION
addappid(1688410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688411, 1, "a6747ff09cd607474ac7afd3cf71a6fcb48932ad18419737b7bc199b27f6f67b")

