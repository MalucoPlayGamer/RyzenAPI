-- Lua provided by RyzenAPI
-- Game: BigFool

-- MAIN APPLICATION
addappid(3038590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038591, 1, "bc8bcc77842d51a12bb30f7db41e56806d43d14290b45b5bbda7afd7f4f70d2c")
