-- Lua provided by RyzenAPI
-- Game: BigFool

-- MAIN APPLICATION
addappid(3038590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3038591, 1, "bc8bcc77842d51a12bb30f7db41e56806d43d14290b45b5bbda7afd7f4f70d2c")

