-- Lua provided by SkyAPI 
-- Game: The Wizard's Lair
addappid(507360)
addappid(507361, 1, "518e4a160f967d3626ef9e491f80fc3d7e062e83062954395fa6afe0b1d7c690")
addappid(507362, 1, "2cd483c412ab1031e6aa9848234a43eb0046680f678f8fe4f67b0dd2757fb49b")
