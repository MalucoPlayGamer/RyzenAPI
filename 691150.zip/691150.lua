-- Lua provided by RyzenAPI
-- Game: Saku Saku: Love Blooms with the Cherry Blossoms

-- MAIN APPLICATION
addappid(691150)

-- MAIN APP DEPOTS / PACKAGES
addappid(691151, 1, "d18313321742241d60effde961effd838964f5feda7ccf91e28743ac5c542b7e")

