-- Lua provided by RyzenAPI
-- Game: 691150

-- MAIN APPLICATION
addappid(691150)
-- Game: addappid(691150)

-- MAIN APP DEPOTS / PACKAGES
addappid(691151, 1, "d18313321742241d60effde961effd838964f5feda7ccf91e28743ac5c542b7e")
