-- Lua provided by RyzenAPI
-- Game: AppID 1110960

-- MAIN APPLICATION
addappid(1110960)
-- Game: addappid(1110960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110961, 1, "f93442c8541fa1b31df66860432cdd1e355c65a89a91fce8fa53d903cd88cdc0")
addappid(1110963, 1, "7d1e81d1bfae1592f7cba1d2be78609c5853475ea37ee50a299416faac60b9bf")
