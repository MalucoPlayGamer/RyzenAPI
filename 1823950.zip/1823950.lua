-- Lua provided by RyzenAPI
-- Game: Laysara: Summit Kingdom

-- MAIN APPLICATION
addappid(1823950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823951, 1, "3416cb65c4840209c65ad9ba8f329819b3f5dfef7fac10cdfa40f94e4676c68b")
