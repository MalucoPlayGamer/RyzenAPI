-- Lua provided by RyzenAPI
-- Game: Laysara: Summit Kingdom

-- MAIN APPLICATION
addappid(1823950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823951, 1, "3416cb65c4840209c65ad9ba8f329819b3f5dfef7fac10cdfa40f94e4676c68b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
