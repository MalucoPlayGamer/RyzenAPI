-- Lua provided by RyzenAPI
-- Game: Driver Booster Upgrade to Pro(Lifetime)

-- MAIN APPLICATION
addappid(920630)

-- MAIN APP DEPOTS / PACKAGES
addappid(920630,0,"ec10298b3b47f8477e645d509c9d6d093ea8c59a5b2ce74372d669c4c1353250")

