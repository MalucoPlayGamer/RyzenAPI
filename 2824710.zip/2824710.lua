-- Lua provided by RyzenAPI 
-- Game: thanks mom
addappid(2824710)
addappid(2824711, 1, "019cde2d2f05aa91779538b0d9e1b52e21c5327db304617a1e1985c4aba50873")
addappid(2824713, 1, "88199c3b55db212a333c5cad4cc194dd050ceff1f66111b15db9381f762d4645")
