-- Lua provided by RyzenAPI
-- Game: Game: AppID 1283770

-- MAIN APPLICATION
addappid(1283770)
-- Game: addappid(1283770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283771, 1, "e0226e5eb397c8d9decaa25f08a574b4f4b3c30e51117348c80d12c7ba6d304b")
