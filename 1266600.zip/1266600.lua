-- Lua provided by RyzenAPI
-- Game: 亦春秋 Power Of Seasons

-- MAIN APPLICATION
addappid(1266600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266601, 1, "c0ec8300e9ea4da1242ff01805fd4406ef1ce871c7b0df3a98c62c121fb8a9e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
