-- Lua provided by RyzenAPI
-- Game: Tides of Tomorrow

-- MAIN APPLICATION
addappid(2678080)
addappid(4212570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2678081,0,"e3ad26ed33c39f69df7e2b6fe575021a59b655ac1402a64641bb3de639b88e26")