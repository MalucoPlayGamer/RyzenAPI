-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy 5

-- MAIN APPLICATION
addappid(844160)

-- MAIN APP DEPOTS / PACKAGES
addappid(844161, 1, "13606887cc9ee3bcdbc7ff697fb2f11f7e02e94974d0acb955089549703f5a98")

