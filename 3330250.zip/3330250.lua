-- Lua provided by RyzenAPI
-- Game: addappid(3330250)

-- MAIN APPLICATION
addappid(3330250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330251, 1, "a7633b3d30636dfe1dae9b0d4f95964133d913e1bc86fef04e6300f14129dca2")
