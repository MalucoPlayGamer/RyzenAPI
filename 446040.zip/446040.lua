-- Lua provided by RyzenAPI
-- Game: AppID 446040

-- MAIN APPLICATION
addappid(446040)
-- Game: addappid(446040)

-- MAIN APP DEPOTS / PACKAGES
addappid(446041, 1, "ff4226084648597d8a137eeba576eae75d57a088e2e5f22647345adc40817e8d")
