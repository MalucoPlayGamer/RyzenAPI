-- Lua provided by RyzenAPI
-- Game: 2506860

-- MAIN APPLICATION
addappid(2506860)
-- Game: addappid(2506860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506861, 1, "14224a6bf27d23ba5440a9e940aba9a7633747cd0c8fa9f83ca0bcf876550ab2")
