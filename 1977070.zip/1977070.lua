-- Lua provided by RyzenAPI
-- Game: Peacemaker: Glorious Princess

-- MAIN APPLICATION
addappid(1977070)
addappid(2963690)
-- Game: addappid(1977070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977071, 1, "460f9931bd85aa79a1e9b74ec74c227a472d39425139ffd1e449159f16302e1a")
