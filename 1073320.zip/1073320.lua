-- Lua provided by RyzenAPI
-- Game: Meteorfall: Krumit's Tale

-- MAIN APPLICATION
addappid(1073320)
-- Game: addappid(1073320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073321, 1, "7c33c0dcaa4dcb0bbaa1892ac312337d380ef2f2e91d025feafb5c153a8cbaa3")
addappid(1073322, 1, "44f79bc65a7ab1128cbb1d9f0ad82f03658347ecb00d2e7921551edebbebcdf3")
