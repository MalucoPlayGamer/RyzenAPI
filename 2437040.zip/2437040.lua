-- Lua provided by RyzenAPI
-- Game: 2437040

-- MAIN APPLICATION
addappid(2437040)
-- Game: addappid(2437040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437041, 1, "7a80b4b78e12dafadeedf2e716f4801c20cac4ffa264476987aad1fb71e6893c")
