-- Lua provided by SkyAPI 
-- Game: Italian Brainrot: In Prison
addappid(3466570)
addappid(3466571, 1, "d5bc6bf0c3120b74b9f1710f8e5b0bc839376188d1d97a97e383171ced2e7e9c")
