-- Lua provided by RyzenAPI
-- Game: Italian Brainrot: In Prison

-- MAIN APPLICATION
addappid(3466570)
-- Game: addappid(3466570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3466571, 1, "d5bc6bf0c3120b74b9f1710f8e5b0bc839376188d1d97a97e383171ced2e7e9c")
