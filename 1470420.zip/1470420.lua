-- Lua provided by RyzenAPI
-- Game: Re:Turn 2 - Runaway

-- MAIN APPLICATION
addappid(1470420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470421, 1, "b0f292df6fc1ccebb16d3c9ecac51f7dd28d8760b2b9ff690af607d08e8ef6fb")
