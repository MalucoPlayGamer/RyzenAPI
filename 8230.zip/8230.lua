-- Lua provided by RyzenAPI
-- Game: Sam & Max 104: Abe Lincoln Must Die!

-- MAIN APPLICATION
addappid(8230)

-- MAIN APP DEPOTS / PACKAGES
addappid(8231, 1, "2978f3726d322d5042f7133652c042eea1a561b98a6e8cf64ec6e91fa3bba335")
addappid(8232, 1, "a17df1a12a3b23dc46b5b0effaffa355b04424b4cb9951767d2d8da1da1105ed")
addappid(8233, 1, "a8b0b5a88022efa26c5771c8d25d6dfc7e3191a439ab63b1592f9bb7125e9225")
addappid(8234, 1, "a03954ae52c33e7aaf43e436cbfb98fb50e66395c0a41a46bfe4abd85c243394")
