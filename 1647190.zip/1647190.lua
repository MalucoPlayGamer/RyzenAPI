-- Lua provided by RyzenAPI
-- Game: addappid(1647190)

-- MAIN APPLICATION
addappid(1647190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647191, 1, "c1a9aaf752c396c3f9f409bccab326fae59edfb0cb771125f71baf3c60384ae6")
