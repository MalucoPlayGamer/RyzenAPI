-- Lua provided by RyzenAPI
-- Game: Asian Food Cart Tycoon

-- MAIN APPLICATION
addappid(2224430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224431, 1, "747fca9443df849525ac0cb69aa5d23f8724aceb25736f691965778ce6e47ff0")
