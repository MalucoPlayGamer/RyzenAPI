-- Lua provided by RyzenAPI
-- Game: Seeking Light

-- MAIN APPLICATION
addappid(1986790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986791, 1, "f5fe1648c7fa3fb0c28d7b82c741c9882073932db579225c16db797f3827611d")

