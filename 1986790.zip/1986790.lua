-- Lua provided by RyzenAPI
-- Game: Seeking Light

-- MAIN APPLICATION
addappid(1986790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986791, 1, "f5fe1648c7fa3fb0c28d7b82c741c9882073932db579225c16db797f3827611d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
