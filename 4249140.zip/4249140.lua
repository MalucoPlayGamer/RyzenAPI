-- Lua provided by RyzenAPI
-- Game: Game: Dino Crisis 2

-- MAIN APPLICATION
addappid(4249140)
-- Game: addappid(4249140)

-- MAIN APP DEPOTS / PACKAGES
addappid(4249141, 1, "2a97406feb503f79a2659d4eb10ded1fcc7e960755f4c6734cafe23a97cbfc0b")
addappid(4249142, 1, "28a1d86a2a3e8b911afedb883fe2e799c427aed72e842e210b3d572edcc11e95")
addappid(4249143, 1, "3b71cda097300405475593b676983749db2088db265180279be47ff5ce7e8b0a")
