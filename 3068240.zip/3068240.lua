-- Lua provided by RyzenAPI
-- Game: My Lovely Empress Original Soundtrack

-- MAIN APPLICATION
addappid(3068240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068241, 1, "ff0acca214ac51d3a00f23bc38718ea7b9abe69e6b88f016438db8529a048b37")
