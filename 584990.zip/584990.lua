-- Lua provided by RyzenAPI
-- Game: The Long Reach

-- MAIN APPLICATION
addappid(584990)
addappid(819860)

-- MAIN APP DEPOTS / PACKAGES
addappid(584991, 1, "c1da98eb9bf0f1a91b5076cb2d3e79fb711194b5d28c5c4751a882ae77a9a686")
