-- Lua provided by RyzenAPI
-- Game: 1160910

-- MAIN APPLICATION
addappid(1160910)
-- Game: addappid(1160910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160911, 1, "41ef205d39f92ad1e90abfba5e238276c6aaf648e6919e97ac43936f1ef1ca5c")
