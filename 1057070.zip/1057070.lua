-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Fateful Strike

-- MAIN APPLICATION
addappid(1057070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057070,0,"e8054538ea46b34322358445f5d858bae3bd035180845ee8cb024f0cfe1c11e6")

