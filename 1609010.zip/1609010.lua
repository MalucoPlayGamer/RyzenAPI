-- Lua provided by RyzenAPI 
-- Game: Forever to you!
addappid(1609010)
addappid(1609011, 1, "6ba02f4c1edcf68684ba00bc062ab97cb6b0ab7ceb1564816387b2c771b2c0b9")
