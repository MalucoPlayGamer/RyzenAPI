-- Lua provided by RyzenAPI
-- Game: Forever to you!

-- MAIN APPLICATION
addappid(1609010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609011, 1, "6ba02f4c1edcf68684ba00bc062ab97cb6b0ab7ceb1564816387b2c771b2c0b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2173560)
addappid(2654060)
