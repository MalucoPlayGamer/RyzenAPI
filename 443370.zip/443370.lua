-- Lua provided by RyzenAPI
-- Game: 443370

-- MAIN APPLICATION
addappid(443370)
-- Game: addappid(443370)

-- MAIN APP DEPOTS / PACKAGES
addappid(443371, 1, "6c7a6581365e80238dcf7bf1d3a8f3b5040b6e7a30ab3fb3e9a2c4bb7dd49118")
