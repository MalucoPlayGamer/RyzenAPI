-- Lua provided by RyzenAPI
-- Game: Football Manager 2021

-- MAIN APPLICATION
addappid(1263850)
addappid(1275920)
addappid(1435920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263851, 1, "393286ab5b3719aa7df267db6a9b2e49b7469f0ff169c9552b9f37b9f0c4f3e4")
addappid(1263852, 1, "232a66f8662088261c1d9f45d276286bffdde04680862618a09ad17fcd2ec39d")
addappid(1263853, 1, "cbf5662ff14067047d3297cf68ef514c36637ebc2673c5eadb2c9c686b51b9a9")
