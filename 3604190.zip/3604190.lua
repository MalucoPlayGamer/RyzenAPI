-- Lua provided by RyzenAPI
-- Game: Dune: Awakening - Digital Artbook

-- MAIN APPLICATION
addappid(3604190)
-- Game: addappid(3604190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3604191, 1, "c572ef768fbab850c416f10be050771ed650c63967a64819d1b61d1a34e3cbaa")
