-- Lua provided by RyzenAPI
-- Game: addappid(2517310)

-- MAIN APPLICATION
addappid(2517310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517311, 1, "6fe33390db2c2102f8745ea2cfe432836e4337a33b4e78ef71456aa4e37529d0")
