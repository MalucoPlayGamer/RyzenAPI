-- Lua provided by SkyAPI 
-- Game: StellarPlans
addappid(2911230)
addappid(2911231, 1, "dd2bf981e95adfaf239badaa57e0c052dac0608a06b06e7754d5f66bae5cb020")
