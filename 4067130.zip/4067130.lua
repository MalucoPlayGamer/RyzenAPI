-- Lua provided by RyzenAPI
-- Game: Drifter Star: Evolution

-- MAIN APPLICATION
addappid(4067130)
-- Game: addappid(4067130)

-- MAIN APP DEPOTS / PACKAGES
addappid(4067131, 1, "6bafa449fca946195270e20ff8af3684b2e1175616289ca2563c22d6d554128e")
