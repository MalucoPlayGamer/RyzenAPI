-- Lua provided by RyzenAPI
-- Game: Game: Mines & Dragons

-- MAIN APPLICATION
addappid(1681620)
-- Game: addappid(1681620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681621, 1, "80851116357f989ea808b37d9e4184548b8e50b1e559fff78335658fd7f84604")
