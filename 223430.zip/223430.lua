-- Lua provided by RyzenAPI 
-- Game: Miner Wars 2081
addappid(223430)
addappid(223431, 1, "1413343891ca90c8383066c4e6bc3c30629be13d1d9ea89d1eab27ef2a49efb7")
addappid(223432, 1, "7f116a3b00036b2fafd21530a8bdd8c4b1c61906301ecce8f11973af473234d5")
addappid(228983)
addappid(228990)
addappid(229002)
