-- Lua provided by RyzenAPI
-- Game: Automation

-- MAIN APPLICATION
addappid(1698690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698691, 1, "f7b1dedf0c39402b0627ff06cd9147ba079cfb5487210908150036039941af41")
