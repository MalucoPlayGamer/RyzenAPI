-- Lua provided by RyzenAPI
-- Game: Dakar Desert Rally

-- MAIN APPLICATION
addappid(1839940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839941, 1, "8f924538be442401883aeda4ee2eb3506110ac183491035aaa1678919b38b928")
addappid(2104841, 0, "bc3ed06b82ea19157151b3ea4ca93f2695332190687529f2a0b4835e7cdf26eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2104840)
addappid(2154020)
addappid(2173060)
addappid(2173080)
addappid(2173090)
addappid(2173100)
addappid(2173110)
addappid(2175710)
addappid(2307510)
