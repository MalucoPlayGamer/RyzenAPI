-- Lua provided by SkyAPI 
-- Game: Dakar Desert Rally
addappid(1839940)
addappid(1839941, 1, "8f924538be442401883aeda4ee2eb3506110ac183491035aaa1678919b38b928")
addappid(2104841, 0, "bc3ed06b82ea19157151b3ea4ca93f2695332190687529f2a0b4835e7cdf26eb")
