-- Lua provided by RyzenAPI
-- Game: addappid(2086060)

-- MAIN APPLICATION
addappid(2086060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086061, 1, "34b648a0101c0de854ad9e13b687d301e4a4fb207942c8c634b8ca3783254ace")
