-- Lua provided by RyzenAPI
-- Game: Cocaine Dealer

-- MAIN APPLICATION
addappid(1341300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341302,0,"c2603a4517c093f8d5588137790d2c0f23badfa0ec39dec12ca13d3ff4d4b0d4")

