-- Lua provided by RyzenAPI
-- Game: 1498030

-- MAIN APPLICATION
addappid(1498030)
-- Game: addappid(1498030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498030,0,"024739f8f56283f5db6be913f481a53033a03eef94b10d62acbff5ef3bfc0d8b")
