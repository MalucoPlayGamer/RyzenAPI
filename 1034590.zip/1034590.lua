-- Lua provided by SkyAPI 
-- Game: AppID 1034590
addappid(1034590)
addappid(1034591, 1, "eb2a5034e6f5210c7758666dc8257c490572fc0df626bad3b7c9e7ddffa497f4")
