-- Lua provided by RyzenAPI
-- Game: Game: AppID 1034590

-- MAIN APPLICATION
addappid(1034590)
-- Game: addappid(1034590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034591, 1, "eb2a5034e6f5210c7758666dc8257c490572fc0df626bad3b7c9e7ddffa497f4")
