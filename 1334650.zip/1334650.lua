-- Lua provided by RyzenAPI
-- Game: addappid(1334650)

-- MAIN APPLICATION
addappid(1334650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334651, 1, "add151969972b0a6d23b90823f6d620f6c6d0532f249272fe1b567a32a9aaed3")
