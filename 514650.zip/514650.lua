-- Lua provided by RyzenAPI
-- Game: Orbital X

-- MAIN APPLICATION
addappid(514650)
addappid(514651)
addappid(514653)
addappid(514654)
addappid(514655)
addappid(514656)

-- MAIN APP DEPOTS / PACKAGES
addappid(514652,0,"4c4f6a9eccf4d357f48f2868ec77a39a774292e4ca893025815ea0e93cc1e7a9")
