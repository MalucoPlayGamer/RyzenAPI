-- Lua provided by RyzenAPI
-- Game: Ready, Steady, Ship! Demo

-- MAIN APPLICATION
addappid(2244950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244953,0,"134486421d27b28e3aa460f273275d6901c34750088c7edf2783f4017bbcdeb1")

