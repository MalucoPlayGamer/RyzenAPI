-- Lua provided by RyzenAPI
-- Game: Victim Complex

-- MAIN APPLICATION
addappid(2840800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840801, 1, "30713fdb068e11374205db719029f6c43f161546ef22b9c6a03a5498e33e9359")

