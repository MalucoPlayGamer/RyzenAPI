-- Lua provided by SkyAPI 
-- Game: AppID 2840800
addappid(2840800)
addappid(2840801, 1, "30713fdb068e11374205db719029f6c43f161546ef22b9c6a03a5498e33e9359")
