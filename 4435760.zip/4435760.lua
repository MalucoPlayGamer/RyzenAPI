-- Generated with Luie @ https://lua.tools/
-- 4435760 - Hellbridge
-- Generated 2026-08-22 05:20:43 UTC
-- # Depots (Total/DLC/Shared): 3/2/0

-- Main AppID
addappid(4435760)

-- Main Depots
addappid(4435761, 1, "cbfe9cd3ab1e02dd5d756eb11fd7edf978ea884af1bc4d3bfd8340a8deec0fcb")
setManifestid(4435761, "5237832400685485951", 1500452920)

-- Missing Depots (We don't have the keys yet lol): 5054961, 5054962
