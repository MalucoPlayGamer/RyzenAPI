-- Lua provided by RyzenAPI
-- Game: Hellbridge

-- MAIN APPLICATION
addappid(4435760)

-- MAIN APP DEPOTS / PACKAGES
addappid(4435761, 1, "cbfe9cd3ab1e02dd5d756eb11fd7edf978ea884af1bc4d3bfd8340a8deec0fcb")

