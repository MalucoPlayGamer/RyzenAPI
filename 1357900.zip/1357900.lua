-- Lua provided by RyzenAPI
-- Game: 1357900

-- MAIN APPLICATION
addappid(1357900)
-- Game: addappid(1357900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357901, 1, "f9f75e1744819bc2b3c0de7c3c8d6217842e99745b7337ec5caeda33654ec76a")
addappid(1357902, 1, "565d354a29803cfc1e496aeea16db1670f574b34d4442b581abd0fdaeb1fd037")
