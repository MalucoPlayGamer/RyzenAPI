-- Lua provided by RyzenAPI
-- Game: Inside Demo

-- MAIN APPLICATION
addappid(2598040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598041, 1, "e4855daa40020862ad4f0511d9f19d5d9d3a1a4a94831f36e483748c32a08f22")

