-- Lua provided by RyzenAPI
-- Game: AppID 552900

-- MAIN APPLICATION
addappid(552900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552901, 1, "824dbe3cb67de35ed9e468e4f02d8f19fe437d8b5825d1e94151d887f26f73b5")

