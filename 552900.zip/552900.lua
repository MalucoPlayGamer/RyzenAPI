-- Lua provided by RyzenAPI 
-- Game: AppID 552900
addappid(552900)
addappid(552901, 1, "824dbe3cb67de35ed9e468e4f02d8f19fe437d8b5825d1e94151d887f26f73b5")
