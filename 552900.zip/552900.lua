-- Lua provided by RyzenAPI
-- Game: 552900

-- MAIN APPLICATION
addappid(552900)
-- Game: addappid(552900)

-- MAIN APP DEPOTS / PACKAGES
addappid(552901, 1, "824dbe3cb67de35ed9e468e4f02d8f19fe437d8b5825d1e94151d887f26f73b5")
