-- Lua provided by RyzenAPI
-- Game: 3263670

-- MAIN APPLICATION
addappid(3263670)
-- Game: addappid(3263670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263671, 1, "ac4c1ab513c7fb993286cbc35067ec8b8516dba3305ed1637037c2ed4e325440")
