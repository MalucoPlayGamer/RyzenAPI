-- Lua provided by SkyAPI 
-- Game: Tequila Zombies 3
addappid(599880)
addappid(599881, 1, "1910fb53476d98d2dafa5e37ee268f60d1bdec580e9b787c79c2020ea938186e")
