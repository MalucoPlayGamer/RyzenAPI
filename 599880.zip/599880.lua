-- Lua provided by RyzenAPI
-- Game: Game: Tequila Zombies 3

-- MAIN APPLICATION
addappid(599880)
-- Game: addappid(599880)

-- MAIN APP DEPOTS / PACKAGES
addappid(599881, 1, "1910fb53476d98d2dafa5e37ee268f60d1bdec580e9b787c79c2020ea938186e")
