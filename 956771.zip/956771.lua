-- Lua provided by RyzenAPI
-- Game: 956771

-- MAIN APPLICATION
addappid(956771)

-- MAIN APP DEPOTS / PACKAGES
addappid(956771,0,"dbf25bf323ace20b80d09afc5f0d1e80f6fe0dbd50886218af7759bff8e4ee8e")
