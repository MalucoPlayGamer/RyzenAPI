-- Lua provided by RyzenAPI
-- Game: AppID 392890

-- MAIN APPLICATION
addappid(392890)

-- MAIN APP DEPOTS / PACKAGES
addappid(392891, 1, "a02bd7ced7b8f4d3464e516ab5fce5dff4c82fa352e325c6b773c275ba3b485e")
addappid(392892, 1, "f1fdcc8c1d2fcb82eb2cf9dbcd06a3dd4f7cf49243d81460f15dafed996539fc")
addappid(392893, 1, "3c890aa46bb4ce1d38e54d0f3311d57bf36298d7986721890040e492d04f0290")
addappid(392894, 1, "05519f361a92d18c5b2be983447b4f08c6d47c231a35d03b268d967350d40c33")
addappid(392895, 1, "5bcfa986c75d9fbbdccc8edd3a7b572aa8cd8741c1b9552f48d49b49cd41c764")
addappid(392896, 1, "f4f0d9dc812930428f5ae3be58d09869209c1587ce3b57cc1c3d018ccdca465a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
