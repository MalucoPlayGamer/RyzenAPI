-- Lua provided by RyzenAPI
-- Game: AppID 429690

-- MAIN APPLICATION
addappid(429690)

-- MAIN APP DEPOTS / PACKAGES
addappid(429691, 1, "474f09329fb06752e4f9cabbfd6f14b675c1e3e171b3e0256d34322a8ed00d90")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
