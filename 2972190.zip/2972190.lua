-- Lua provided by RyzenAPI
-- Game: Game: AppID 2972190

-- MAIN APPLICATION
addappid(2972190)
-- Game: addappid(2972190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2972191, 1, "eadc346eff7c86eb91ce2701b4c72802132b0056281654fbb6f68ee458a0701a")
