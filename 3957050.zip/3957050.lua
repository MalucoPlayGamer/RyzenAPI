-- Lua provided by RyzenAPI
-- Game: Ballatory

-- MAIN APPLICATION
addappid(3957050) -- Ballatory
addappid(4865320) -- Ballatory - Animal Core Skins
addappid(4865330) -- Ballatory - Food Core Skins
addappid(4865340) -- Ballatory - Fantasy Core Skins
addappid(4865350) -- Ballatory - Space Core Skin

-- MAIN APP DEPOTS / PACKAGES
addappid(3957051, 1, "5e9c6a0cfda34f7bb08c3e991722a4f6ffd37329626c0cb4ca8f5481cf577479") -- Depot 3957051
addappid(3957052, 1, "c81abb9f6e800a85755249fb702b0357e0e5f780fc53d4ada571992a9ecfe0aa") -- Depot 3957052
addappid(3957053, 1, "f601ecd67b209d3aabe3a41c79250c625c2aa0e90251d122eacee63a3785dad3") -- Depot 3957053

