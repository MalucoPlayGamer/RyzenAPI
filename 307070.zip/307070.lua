-- Lua provided by RyzenAPI
-- Game: addappid(307070)

-- MAIN APPLICATION
addappid(307070)

-- MAIN APP DEPOTS / PACKAGES
addappid(307071, 1, "fab4c652f6e155f3eb0e46d77c3477d5954fd16176f8b81cd307c11ea1781fb4")
