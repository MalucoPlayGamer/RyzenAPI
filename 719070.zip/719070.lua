-- Lua provided by RyzenAPI
-- Game: 719070

-- MAIN APPLICATION
addappid(719070)
-- Game: addappid(719070)

-- MAIN APP DEPOTS / PACKAGES
addappid(719071, 1, "5712accc56a3d014a219de09edaff8a30cf7887399fd867aedf8e9ebd7e38cea")
