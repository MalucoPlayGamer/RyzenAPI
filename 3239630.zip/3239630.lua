-- Lua provided by RyzenAPI
-- Game: Game: AppID 3239630

-- MAIN APPLICATION
addappid(3239630)
-- Game: addappid(3239630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239631, 1, "6c65c1606bc8e370a9e002ce86dc4021d82441528cd26196ba521d37b7d61d64")
