-- Lua provided by RyzenAPI
-- Game: The Expedition

-- MAIN APPLICATION
addappid(3621410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3621411, 1, "794cfd03d96d6e1e1746e4c54c6981d64656af0ef93659eac2fced74295ad4a6")

