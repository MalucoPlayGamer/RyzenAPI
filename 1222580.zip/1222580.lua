-- Lua provided by RyzenAPI
-- Game: Rustissimo

-- MAIN APPLICATION
addappid(1222580)
addappid(1244230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222581, 1, "1d57127189f5edadd39007b707d50c0971957cc4e85001abb7dfb906d8d84dc1")
addappid(1222582, 1, "5be5eb243a0bc7b9910e2e42fa01a6bb7cb57a0639d3bf9921c519e114d46837")

