-- Generated with Luie @ https://lua.tools/
-- 1222580 - Rustissimo
-- Generated 2026-08-21 04:00:07 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(1222580)

-- Main Depots
addappid(1222581, 1, "1d57127189f5edadd39007b707d50c0971957cc4e85001abb7dfb906d8d84dc1")
setManifestid(1222581, "1678807181068096533", 6776444)

-- DLC's (with depot keys)
-- Rustissimo PRO (AppID: 1244230)
addappid(1244230)
addappid(1222582, 1, "5be5eb243a0bc7b9910e2e42fa01a6bb7cb57a0639d3bf9921c519e114d46837")
setManifestid(1222582, "4191742754037264338", 6125683)
