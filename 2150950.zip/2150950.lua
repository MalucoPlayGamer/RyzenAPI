-- Lua provided by RyzenAPI
-- Game: Paranormal Observation

-- MAIN APPLICATION
addappid(2150950)
-- Game: addappid(2150950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150951, 1, "85514e7530b4c7753303abbc2f7c377dd16ba32cddd91ac6dedc1b20b234cb11")
