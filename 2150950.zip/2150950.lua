-- Lua provided by RyzenAPI
-- Game: Paranormal Observation

-- MAIN APPLICATION
addappid(2150950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150951, 1, "85514e7530b4c7753303abbc2f7c377dd16ba32cddd91ac6dedc1b20b234cb11")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
