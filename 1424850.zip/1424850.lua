-- Lua provided by SkyAPI 
-- Game: Hentai Vs Orcs
addappid(1424850)
addappid(1424851, 1, "f7580a227b49b129cccf2068d7db36385713e77c70f99fa1a6d9c4a337348f7e")
