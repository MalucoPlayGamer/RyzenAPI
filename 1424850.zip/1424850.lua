-- Lua provided by RyzenAPI
-- Game: Hentai Vs Orcs

-- MAIN APPLICATION
addappid(1424850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424851, 1, "f7580a227b49b129cccf2068d7db36385713e77c70f99fa1a6d9c4a337348f7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
