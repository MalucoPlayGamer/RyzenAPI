-- Lua provided by RyzenAPI
-- Game: Battle Cry of Freedom

-- MAIN APPLICATION
addappid(1358710)
addappid(2306940)
addappid(2317210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358711, 1, "70d6f39a5f0c5b6b288ce013e15b6bc178de93e16d2160472502d4a9451f3a0f")
