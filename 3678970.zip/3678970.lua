-- 3678970's Lua and Manifest Created by Hubcap Manifest
-- TBH: Task Bar Hero
-- Created: June 01, 2026 at 22:41:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(3678970) -- TBH: Task Bar Hero
-- MAIN APP DEPOTS
addappid(3678971, 1, "8d0b4ba64ffc2eaa7b8f853cd4ad4e91d7a57d637bcf3f33aba1da9c6d6360f0") -- Depot 3678971
setManifestid(3678971, "7907987201091767613", 577942062)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4427390) -- TBH  Task Bar Hero - Supporter Pack
addappid(4427400) -- TBH  Task Bar Hero - 3 Stash Pack
addappid(4427410) -- TBH  Task Bar Hero - Priest (Class)
addappid(4427420) -- TBH  Task Bar Hero - Hunter (Class)
addappid(4427430) -- TBH  Task Bar Hero - Slayer (Class)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3678972) -- Depot 3678972 (empty depot)