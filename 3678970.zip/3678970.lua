-- Lua provided by RyzenAPI
-- Game: TBH: Task Bar Hero

-- MAIN APPLICATION
addappid(3678970)
addappid(4427390)
addappid(4427400)
addappid(4427410)
addappid(4427420)
addappid(4427430)
addappid(4876910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3678971,0,"8d0b4ba64ffc2eaa7b8f853cd4ad4e91d7a57d637bcf3f33aba1da9c6d6360f0")

