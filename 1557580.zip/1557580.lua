-- Lua provided by RyzenAPI
-- Game: DON'T LOOK AWAY

-- MAIN APPLICATION
addappid(1557580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1557581, 1, "51de7ec463e591c3d2fd99abeb738149e5001d9031a543d7e3e86afff9730e8e")

