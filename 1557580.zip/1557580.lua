-- Lua provided by RyzenAPI
-- Game: DON'T LOOK AWAY

-- MAIN APPLICATION
addappid(1557580)
-- Game: addappid(1557580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557581, 1, "51de7ec463e591c3d2fd99abeb738149e5001d9031a543d7e3e86afff9730e8e")
