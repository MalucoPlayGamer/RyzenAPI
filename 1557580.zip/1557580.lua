-- Lua provided by SkyAPI 
-- Game: DON'T LOOK AWAY
addappid(1557580)
addappid(1557581, 1, "51de7ec463e591c3d2fd99abeb738149e5001d9031a543d7e3e86afff9730e8e")
