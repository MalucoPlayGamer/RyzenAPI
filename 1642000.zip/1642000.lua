-- Lua provided by RyzenAPI
-- Game: Game: 《Rail of Möbius》Demo

-- MAIN APPLICATION
addappid(1642000)
-- Game: addappid(1642000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642001, 1, "5750d2830c1310b23464d1bbc832b243d95fa3583d2ae6f5df764c8e0345c670")
