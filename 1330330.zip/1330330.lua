-- Lua provided by RyzenAPI
-- Game: 1330330

-- MAIN APPLICATION
addappid(1330330)
-- Game: addappid(1330330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330331, 1, "4adc7e73de7a5a36aeb4db937e48c1c1fc8fb7ef9a03d58a78f47e5b211270c1")
