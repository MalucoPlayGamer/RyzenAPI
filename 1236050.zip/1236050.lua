-- Lua provided by RyzenAPI
-- Game: AppID 1236050

-- MAIN APPLICATION
addappid(1236050)
-- Game: addappid(1236050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236051, 1, "7f7c54569a4601e368b62752bda3bdf762a6421285abebb27b679ab23c8ef4e5")
