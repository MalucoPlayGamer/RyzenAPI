-- Lua provided by RyzenAPI
-- Game: AppID 1236050

-- MAIN APPLICATION
addappid(1236050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236051, 1, "7f7c54569a4601e368b62752bda3bdf762a6421285abebb27b679ab23c8ef4e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
