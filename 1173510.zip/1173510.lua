-- Lua provided by RyzenAPI
-- Game: XSOverlay

-- MAIN APPLICATION
addappid(1173510)
-- Game: addappid(1173510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173512,0,"03d912ed45219d3b301dc3856a3f14b87d220e0b4ac603dbfbcd25960e5251e0")
