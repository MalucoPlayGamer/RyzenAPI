-- Lua provided by RyzenAPI
-- Game: AppID 674800

-- MAIN APPLICATION
addappid(674800)
-- Game: addappid(674800)

-- MAIN APP DEPOTS / PACKAGES
addappid(674801, 1, "6ebebfdc3e4f4787b1a08c41cb9ebd3750ca9828f7516bc7c12a7a3310ce8f60")
