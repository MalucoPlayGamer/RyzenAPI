-- Lua provided by RyzenAPI
-- Game: Soldiers Of Freedom

-- MAIN APPLICATION
addappid(696500)
-- Game: addappid(696500)

-- MAIN APP DEPOTS / PACKAGES
addappid(696501, 1, "2c5d2232c17b96b680994e06b8c729c14cb0fece6f7484940b1f94d7b77af341")
