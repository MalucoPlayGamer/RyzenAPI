-- Lua provided by RyzenAPI
-- Game: Game: Train Bandit

-- MAIN APPLICATION
addappid(655370)
-- Game: addappid(655370)

-- MAIN APP DEPOTS / PACKAGES
addappid(655371, 1, "1e73f990b5f61f32499bc6ae4375da916cfb783ea755514a767049e2596effee")
