-- Lua provided by RyzenAPI
-- Game: Train Bandit

-- MAIN APPLICATION
addappid(655370)

-- MAIN APP DEPOTS / PACKAGES
addappid(655371, 1, "1e73f990b5f61f32499bc6ae4375da916cfb783ea755514a767049e2596effee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
