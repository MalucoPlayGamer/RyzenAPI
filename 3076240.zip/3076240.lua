-- Lua provided by RyzenAPI 
-- Game: True Nightmare - Roadside Сafe
addappid(3076240)
addappid(3076241, 1, "afcd43434aacd18423b38725e878fd802a25a9e615fc9cece435ffce929d7156")
