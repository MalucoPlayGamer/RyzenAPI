-- Lua provided by RyzenAPI
-- Game: 355690

-- MAIN APPLICATION
addappid(355690)
-- Game: addappid(355690)

-- MAIN APP DEPOTS / PACKAGES
addappid(355691, 1, "28409bd1e5a7b810bcb850e75409fb984c246a83041ec0f8e576d241a6a59cbd")
