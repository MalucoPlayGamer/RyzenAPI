-- Lua provided by RyzenAPI
-- Game: Deputy Dangle

-- MAIN APPLICATION
addappid(355690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(355691, 1, "28409bd1e5a7b810bcb850e75409fb984c246a83041ec0f8e576d241a6a59cbd")

