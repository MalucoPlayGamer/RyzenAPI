-- Lua provided by SkyAPI 
-- Game: AppID 995170
addappid(995170)
addappid(995171, 1, "072e2eff831a077b98d97b9555b021a3adf0f453de3308bd960cd40f6667e68a")
