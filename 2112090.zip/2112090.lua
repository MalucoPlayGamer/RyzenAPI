-- Lua provided by RyzenAPI
-- Game: addappid(2112090)

-- MAIN APPLICATION
addappid(2112090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112094,0,"4f44305dff9dab69d269feaddae7465e9c8918b417ec1baa82ff8d8e128daacd")
addappid(2112098,0,"8e09c37dc0c3a94ba0a7388ea02928a544e0062669947eeeb48b9ceb79bc6932")
