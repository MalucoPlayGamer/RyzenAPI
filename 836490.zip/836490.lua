-- Lua provided by RyzenAPI
-- Game: 月夜下的紅茶杯 ~ Blacktea With Moon

-- MAIN APPLICATION
addappid(836490)

-- MAIN APP DEPOTS / PACKAGES
addappid(836491, 1, "356759337a5f2f90d1d62bc848b6e8a69cafb4d63bbfe48a4b00aacf91a7411e")
addappid(836492, 1, "9880d6313d02c6999955b44bb28f9072a8b0cf30537b7c23b29d84710c99ea5d")
