-- Lua provided by RyzenAPI
-- Game: Killer Klowns From Outer Space: The Game

-- MAIN APPLICATION
addappid(1556100)
addappid(2736800)
addappid(2833400)
addappid(2833410)
addappid(2921240)
addappid(2921250)
addappid(2921260)
addappid(2921270)
addappid(2921290)
addappid(3080640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1556101, 1, "655ed65b30e5ecd8a89b096ebbc51004a279894d4808674176db5c27e9297939")

