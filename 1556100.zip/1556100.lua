-- Lua provided by RyzenAPI
-- Game: Killer Klowns From Outer Space: The Game

-- MAIN APPLICATION
addappid(1556100)
addappid(2736800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556101, 1, "655ed65b30e5ecd8a89b096ebbc51004a279894d4808674176db5c27e9297939")
