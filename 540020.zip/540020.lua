-- Lua provided by RyzenAPI
-- Game: AppID 540020

-- MAIN APPLICATION
addappid(540020)

-- MAIN APP DEPOTS / PACKAGES
addappid(540021, 1, "3a07f9bb739d570e1e1cd3151a7ae5fbd745f7302ead5519cafded758f47aff1")

