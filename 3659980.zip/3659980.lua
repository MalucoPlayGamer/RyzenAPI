-- Lua provided by RyzenAPI
-- Game: Tease and Please: Charlotte Edition

-- MAIN APPLICATION
addappid(3659980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3659984,0,"44bfd8e032ed2352f09a46da777decb0f30cc3e93450757d57d7fa282d20b04d")

