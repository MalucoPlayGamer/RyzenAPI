-- Lua provided by RyzenAPI
-- Game: Game: 古剑奇谭(GuJian)

-- MAIN APPLICATION
addappid(570780)
-- Game: addappid(570780)

-- MAIN APP DEPOTS / PACKAGES
addappid(570781, 1, "a212409474ac059a4bd0de6f78c80e44daff087ff475cba093b874f2b0cf4bb5")
