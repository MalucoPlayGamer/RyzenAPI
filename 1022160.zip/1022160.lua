-- Lua provided by RyzenAPI
-- Game: AppID 1022160

-- MAIN APPLICATION
addappid(1022160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022161, 1, "f4c1fb5ec34b7139581f9cc21234c83efc5bdfc6466c580b44ba212b7fcfe21a")

