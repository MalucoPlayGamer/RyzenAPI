-- Lua provided by RyzenAPI
-- Game: Rain World - Soundtrack

-- MAIN APPLICATION
addappid(610070)

-- MAIN APP DEPOTS / PACKAGES
addappid(610070,0,"f63bf7ebc4155578831d31a1a4dfa4cc941b91f5834ef4126562b0d08b2c3cc4")

