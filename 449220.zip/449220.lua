-- Lua provided by RyzenAPI
-- Game: A grande bagunça espacial - The big space mess

-- MAIN APPLICATION
addappid(449220)

-- MAIN APP DEPOTS / PACKAGES
addappid(449221, 1, "0aaa0f2f74fa7a69cd8c04801841550c3d3c2a11261d2f3a792848e550a40932")
