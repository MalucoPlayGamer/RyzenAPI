-- Lua provided by RyzenAPI
-- Game: Game: AppID 1126600

-- MAIN APPLICATION
addappid(1126600)
-- Game: addappid(1126600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126601, 1, "301cae3e865ec2abce35de756df2d8ba87ea01ba4872120c55f6184240126bc6")
