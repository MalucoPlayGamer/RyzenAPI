-- Lua provided by SkyAPI 
-- Game: HOLE: Bottomless
addappid(3352070)
addappid(3352071, 1, "634617dd1e098cb288e3f126083a75b073456da00fc106f2c0e5885e8d240202")
