-- Lua provided by RyzenAPI
-- Game: Game: HOLE: Bottomless

-- MAIN APPLICATION
addappid(3352070)
-- Game: addappid(3352070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3352071, 1, "634617dd1e098cb288e3f126083a75b073456da00fc106f2c0e5885e8d240202")
