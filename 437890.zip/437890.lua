-- Lua provided by RyzenAPI
-- Game: 437890

-- MAIN APPLICATION
addappid(437890)
addappid(497740)
-- Game: addappid(437890)

-- MAIN APP DEPOTS / PACKAGES
addappid(437891, 1, "5095d986ff8ed1bf44b70838e85fed7904d4de96659d64777e4e3f19031adfb1")
addappid(437892, 1, "7e6f8185fc5f9ffe36d74e71190d759a5518cb57f1861bcb6dc6a6e92fc43823")
