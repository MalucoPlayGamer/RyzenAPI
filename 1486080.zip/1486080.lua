-- Lua provided by SkyAPI 
-- Game: Time Master
addappid(1486080)
addappid(1486081, 1, "e74ff1524e51241b991e364de189eac6f4831f78af1d9eaf915492bb72471590")
addappid(1486082, 1, "566a4c589ea5408b43be056b3ac92bcff551a021bb438a32cc38a90b48bb23ca")
