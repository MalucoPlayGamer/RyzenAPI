-- Lua provided by RyzenAPI
-- Game: Proton Experimental

-- MAIN APPLICATION
addappid(1493710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493711, 1, "fe5a344520702440fcaf4f43f02af4b128229789f09d7595b05c3932e2aa0676")
