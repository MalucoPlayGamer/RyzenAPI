-- Lua provided by RyzenAPI
-- Game: AppID 347080

-- MAIN APPLICATION
addappid(347080)
addappid(407410)
-- Game: addappid(347080)

-- MAIN APP DEPOTS / PACKAGES
addappid(347081, 1, "1ff2a29948f0b4865e20ccdf797aa17492a989aa6cd45e4d359758d556c4636f")
