-- Lua provided by RyzenAPI
-- Game: AppID 347080

-- MAIN APPLICATION
addappid(347080)
addappid(407410)

-- MAIN APP DEPOTS / PACKAGES
addappid(347081, 1, "1ff2a29948f0b4865e20ccdf797aa17492a989aa6cd45e4d359758d556c4636f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
