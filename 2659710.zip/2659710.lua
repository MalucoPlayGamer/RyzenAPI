-- Lua provided by RyzenAPI
-- Game: Carnaval Simulator

-- MAIN APPLICATION
addappid(2659710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659711, 1, "bff9a0e45d94c58c21e39be8f808acf92e96d3583b688817da2ae33fc0a96145")

