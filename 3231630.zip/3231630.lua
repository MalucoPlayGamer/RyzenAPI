-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3231630)
addappid(3231631)
addappid(3231632)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231633,0,"4c216d971dfd7eb2ec8799e0fde858d0d73d8b29da86a15a01d70ffce04a55e1")
addappid(3231634,0,"7a71a9a6c44714f98d8c09a19c38721b85c27be56ea921ce95db5bfbfbbdd274")

