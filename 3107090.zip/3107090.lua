-- Lua provided by RyzenAPI
-- Game: Game: AppID 3107090

-- MAIN APPLICATION
addappid(3107090)
-- Game: addappid(3107090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107091, 1, "1144b1b9c97027d63269fa745278a3761c3ca42c8d81ffaa45b060911f9977e2")
