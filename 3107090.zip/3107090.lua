-- Lua provided by SkyAPI 
-- Game: AppID 3107090
addappid(3107090)
addappid(3107091, 1, "1144b1b9c97027d63269fa745278a3761c3ca42c8d81ffaa45b060911f9977e2")
