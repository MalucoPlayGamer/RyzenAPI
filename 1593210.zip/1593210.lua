-- Lua provided by RyzenAPI
-- Game: Shinobi's Way - a jigsaw chess tale

-- MAIN APPLICATION
addappid(1593210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593211, 1, "36f2c10e8b9aedc26404b99f3bfe695eaf90bd0154ac063061b54df28955d0e7")

