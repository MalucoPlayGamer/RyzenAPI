-- Lua provided by RyzenAPI
-- Game: addappid(1561920)

-- MAIN APPLICATION
addappid(1561920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561921, 1, "47737985af27000afed6873bf062e84c71b3eb217f23e30a09e4ef87d6eec6a4")
