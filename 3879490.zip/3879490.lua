-- Lua provided by RyzenAPI
-- Game: Game: MOUSE: P.I. For Hire Comic Book

-- MAIN APPLICATION
addappid(3879490)
-- Game: addappid(3879490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3879491, 1, "a609219532d6690630d1cccd2eb190817cca2d15d8380c0d3ba2bb1d91108f67")
