-- Lua provided by RyzenAPI
-- Game: Katana Robo: RTA

-- MAIN APPLICATION
addappid(2658810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658811, 1, "a117edbc274aea08553c313f794856f4f5c02f232d8c0a67f8ab3ec031372f55")

