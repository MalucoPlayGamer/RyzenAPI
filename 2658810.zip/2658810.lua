-- Lua provided by SkyAPI 
-- Game: Katana Robo: RTA
addappid(2658810)
addappid(2658811, 1, "a117edbc274aea08553c313f794856f4f5c02f232d8c0a67f8ab3ec031372f55")
