-- Lua provided by RyzenAPI
-- Game: Katana Robo: RTA

-- MAIN APPLICATION
addappid(2658810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658811, 1, "a117edbc274aea08553c313f794856f4f5c02f232d8c0a67f8ab3ec031372f55")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
