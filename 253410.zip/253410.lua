-- Lua provided by RyzenAPI
-- Game: Ravensword: Shadowlands

-- MAIN APPLICATION
addappid(253410)

-- MAIN APP DEPOTS / PACKAGES
addappid(253411, 1, "6aa87f4b8e487887b7cd2953cc69f7a9ec34228fb7070276d13bad3385435c14")
addappid(253412, 1, "f25b4bc3d538ba3c154583ab96df2d62342c110fad4427be6829401b90dc5fe6")
addappid(253413, 1, "3ce2e4e3b180f02d72c66a25bf3e56fa42b40a0d400d694f4dea1d1384a6b532")

