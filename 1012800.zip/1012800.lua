-- Lua provided by RyzenAPI
-- Game: WhiTaers: Gongren Edition

-- MAIN APPLICATION
addappid(1012800)
-- Game: addappid(1012800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012801, 1, "d0d7be5cd55e5aac73e784f4b884d03680e811b45c4fab05753c488496c6ae58")
