-- Lua provided by RyzenAPI
-- Game: 3657210

-- MAIN APPLICATION
addappid(3657210)
-- Game: addappid(3657210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3657211, 1, "e0e61f4993c2929f4ad84eea55c473f50fd8a91e974c3b1073028caaf9b75591")
