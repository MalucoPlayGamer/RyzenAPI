-- Lua provided by RyzenAPI
-- Game: 1172190

-- MAIN APPLICATION
addappid(1172190)
-- Game: addappid(1172190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172191, 1, "dab759e68fc373b58bedf2e7d54638d77b13a2722d89aaca62436186a6860235")
