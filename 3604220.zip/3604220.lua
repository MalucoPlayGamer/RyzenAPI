-- Lua provided by RyzenAPI
-- Game: addappid(3604220)

-- MAIN APPLICATION
addappid(3604220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3604221, 1, "097fdf68f44fc23c373347de56bbea98e6d39a7384a07a0ff8ff955630e6f3d0")
