-- Lua provided by RyzenAPI
-- Game: Dreadful River

-- MAIN APPLICATION
addappid(1807360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807361, 1, "dbe3ded982c0c964e7611ef16c1206b8f9340c32ff2a71d8926e0abe77b1dba5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
