-- Lua provided by RyzenAPI
-- Game: Dreadful River

-- MAIN APPLICATION
addappid(1807360)
-- Game: addappid(1807360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807361, 1, "dbe3ded982c0c964e7611ef16c1206b8f9340c32ff2a71d8926e0abe77b1dba5")
