-- Lua provided by RyzenAPI
-- Game: Game: Three Kingdoms The Last Warlord-Art Upgrade Pack

-- MAIN APPLICATION
addappid(2350160)
-- Game: addappid(2350160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350161, 1, "293246b9dea1db132b7db393d701e46d257e9872cd360125457e02758e3e0978")
