-- Lua provided by RyzenAPI
-- Game: Big Rigs: Over the Road Racing Soundtrack

-- MAIN APPLICATION
addappid(3614190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614192,0,"cfeae6abc8521b5cade74f162a241d54abfaab9f7974659246e4fcbfe572455f")
