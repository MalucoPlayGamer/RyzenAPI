-- Lua provided by RyzenAPI
-- Game: 3614190

-- MAIN APPLICATION
addappid(3614190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614192,0,"cfeae6abc8521b5cade74f162a241d54abfaab9f7974659246e4fcbfe572455f")
