-- Lua provided by RyzenAPI
-- Game: 458230

-- MAIN APPLICATION
addappid(458230)
-- Game: addappid(458230)

-- MAIN APP DEPOTS / PACKAGES
addappid(458231, 1, "2761abc8670a079031dbf9bc5bc741fc9eef890a7c7abde6eb1c02c92b7a1b17")
