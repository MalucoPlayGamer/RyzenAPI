-- Lua provided by RyzenAPI
-- Game: 2427100

-- MAIN APPLICATION
addappid(2427100)
-- Game: addappid(2427100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427101, 1, "13cfa8e15334e264c30b5542536ac26aa8c0c7fd4e5e0c0c6da46d93ec2dd05e")
