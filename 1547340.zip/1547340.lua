-- Lua provided by RyzenAPI
-- Game: 1547340

-- MAIN APPLICATION
addappid(1547340)
-- Game: addappid(1547340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547341, 1, "59b60212446612d5ebf4fbbab58e4790d3879a37e978b7de1b8fcb94580d79a7")
