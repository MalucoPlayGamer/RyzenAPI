-- Lua provided by RyzenAPI
-- Game: Book Of Potentia 2

-- MAIN APPLICATION
addappid(665740)

-- MAIN APP DEPOTS / PACKAGES
addappid(665741, 1, "0d25ca4d12404083adb91b0b759086d6d6a95c58da4a0818e8ca0a98a965ca82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
