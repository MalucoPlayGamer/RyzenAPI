-- Lua provided by RyzenAPI
-- Game: Book Of Potentia 2

-- MAIN APPLICATION
addappid(665740)

-- MAIN APP DEPOTS / PACKAGES
addappid(665741, 1, "0d25ca4d12404083adb91b0b759086d6d6a95c58da4a0818e8ca0a98a965ca82")
