-- Lua provided by RyzenAPI
-- Game: The Frozen Kingdom

-- MAIN APPLICATION
addappid(3171470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856210, 1, "7b684092e9ee37ca96359ec2586f341659c026cb8747c1b8ae6885da694fbcff") -- The Frozen Kingdom
addappid(1856211, 1, "1be2cd5e0c73d6eb957cb8d86204fd0d88d84a9a952fff145fe142c278ad8002") -- Depot 1856211
addappid(3171470, 1, "e1d460b895f7a4dc37572a749fa9532b75ffe8957a2b512366acaab20712596a") -- The Frozen Kingdom art-book - Depot 3171470

