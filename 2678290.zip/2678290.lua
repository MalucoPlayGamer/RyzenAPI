-- Lua provided by RyzenAPI
-- Game: EternAlgoRhythm

-- MAIN APPLICATION
addappid(2678290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678291, 1, "206ca02c433ca6a8f51bacb6b29fae1c0fcad152050463316d021a2db497ac9d")

