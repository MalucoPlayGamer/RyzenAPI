-- Lua provided by RyzenAPI
-- Game: Miraculous: Rise of the Sphinx

-- MAIN APPLICATION
addappid(1740660)
addappid(2178630)
-- Game: addappid(1740660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740661, 1, "f8e096077be7f52ba8371fb9570957f1cdfec672af65cb0534fc0f18f723ee52")
