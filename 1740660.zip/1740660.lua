-- Lua provided by RyzenAPI
-- Game: addappid(1740660)

-- MAIN APPLICATION
addappid(1740660)
addappid(2178630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740661, 1, "f8e096077be7f52ba8371fb9570957f1cdfec672af65cb0534fc0f18f723ee52")
