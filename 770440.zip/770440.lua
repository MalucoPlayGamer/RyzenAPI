-- Lua provided by RyzenAPI
-- Game: AppID 770440

-- MAIN APPLICATION
addappid(770440)

-- MAIN APP DEPOTS / PACKAGES
addappid(770441, 1, "b4f314a0f6a0c1593b0842b85c141b34fed2da959b5e3a676ed2329a8de04f2f")

