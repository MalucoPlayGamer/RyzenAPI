-- Lua provided by RyzenAPI
-- Game: Preventive Strike

-- MAIN APPLICATION
addappid(740280)

-- MAIN APP DEPOTS / PACKAGES
addappid(740281,0,"e682bdde0b894dd0eaaf2127fb602385f7803d27816ff5a76f825070013e0c94")

