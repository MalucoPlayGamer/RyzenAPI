-- Lua provided by RyzenAPI
-- Game: Preventive Strike

-- MAIN APPLICATION
addappid(740280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(740281,0,"e682bdde0b894dd0eaaf2127fb602385f7803d27816ff5a76f825070013e0c94")

