-- Lua provided by RyzenAPI
-- Game: The Last Monster Master

-- MAIN APPLICATION
addappid(722600)

-- MAIN APP DEPOTS / PACKAGES
addappid(722601,0,"3730a1d452de584b3d07174a978328ad3af863092a382e5a2b78a5484ed567bf")

