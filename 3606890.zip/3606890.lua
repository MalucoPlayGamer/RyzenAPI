-- Lua provided by RyzenAPI
-- Game: Upload Labs

-- MAIN APPLICATION
addappid(3606890)
addappid(3606990)
addappid(3958950)
addappid(3958960)
addappid(4085930)
addappid(4387380)

