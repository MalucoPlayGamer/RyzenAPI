-- Lua provided by RyzenAPI
-- Game: Upload Labs

-- MAIN APPLICATION
addappid(3606890)

