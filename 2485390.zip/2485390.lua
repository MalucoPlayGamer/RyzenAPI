-- Lua provided by RyzenAPI
-- Game: Game: The Bookwalker Soundtrack

-- MAIN APPLICATION
addappid(2485390)
-- Game: addappid(2485390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485391, 1, "efbc35e4ccef0e2db91239b5b2cae3eb431a161b70c276283be19a72cfbda927")
