-- Lua provided by RyzenAPI
-- Game: 1726310

-- MAIN APPLICATION
addappid(1726310)
-- Game: addappid(1726310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726311, 1, "6e7fd95ead116c6d5ca7aec5c27fe5c49e08c2199f8af0aed6dfd8604f9950c8")
