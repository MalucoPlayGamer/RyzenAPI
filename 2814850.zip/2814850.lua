-- Lua provided by RyzenAPI 
-- Game: FAIRY TAIL DUNGEONS Demo
addappid(2814850)
addappid(2814851, 1, "fa057f8f197e8808771f893b9641f680ba2e872b844fea12993bcb949dd04083")
