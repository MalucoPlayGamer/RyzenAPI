-- Lua provided by RyzenAPI
-- Game: Game: The Botanist

-- MAIN APPLICATION
addappid(1240270)
-- Game: addappid(1240270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240271, 1, "449306cc6a2e85cd22a4c3ee4b0f5b0d586610924391b758375906c1395a9454")
