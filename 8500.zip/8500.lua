-- Lua provided by RyzenAPI
-- Game: EVE Online

-- MAIN APPLICATION
addappid(235883) -- Eve Online - Steam Starter Pack Sub
addappid(235884) -- EVE Online - Base Game Key
addappid(320550) -- Core Starter Pack
addappid(320551) -- Colonist Add-On
addappid(320552) -- Explorer Add-On
addappid(320553) -- Industrialist Add-On
addappid(320554) -- Skirmisher Add-On
addappid(320555) -- Premium Edition
addappid(323110) -- Starter Pack Ownership
addappid(369320) -- EVE Online: 900 Aurum
addappid(369321) -- EVE Online: 2000 Aurum
addappid(369322) -- EVE Online: 5150 Aurum
addappid(369324) -- EVE Online: 10750 Aurum
addappid(369325) -- EVE Online: 23000 Aurum
addappid(629790) -- DLC 629790
addappid(629791) -- DLC 629791
addappid(629792) -- DLC 629792
addappid(629793) -- DLC 629793
addappid(629794) -- DLC 629794
addappid(629795) -- DLC 629795
addappid(629796) -- DLC 629796
addappid(659290) -- EVE Online: Alpha Pack
addappid(695740) -- EVE Online: 1 month subscription
addappid(695741) -- EVE Online: 3 month subscription
addappid(695742) -- EVE Online: 6 month subscription
addappid(695743) -- EVE Online: 12 month subscription
addappid(743620) -- DLC 743620
addappid(748100) -- DLC 748100
addappid(748101) -- DLC 748101
addappid(748102) -- DLC 748102
addappid(766710) -- DLC 766710
addappid(766711) -- DLC 766711
addappid(766712) -- EVE Online: 10 Daily Alpha Injectors
addappid(1063450) -- DLC 1063450
addappid(1088740) -- DLC 1088740
addappid(1125050) -- EVE Online: 7 Days Omega Time
addappid(1155450) -- DLC 1155450
addappid(1190010) -- DLC 1190010
addappid(1190011) -- DLC 1190011
addappid(1190012) -- DLC 1190012
addappid(1190013) -- DLC 1190013
addappid(1222280) -- DLC 1222280
addappid(1230480) -- DLC 1230480
addappid(1230481) -- DLC 1230481
addappid(1230482) -- DLC 1230482
addappid(1230483) -- DLC 1230483
addappid(1308110) -- EVE Online: Starter Pack - 17 Birthday Celebration
addappid(1345930) -- DLC 1345930
addappid(1396360) -- DLC 1396360
addappid(1427220) -- DLC 1427220
addappid(1427221) -- DLC 1427221
addappid(1465270) -- DLC 1465270
addappid(1465271) -- DLC 1465271
addappid(1465272) -- DLC 1465272
addappid(1537550) -- DLC 1537550
addappid(1610800) -- DLC 1610800
addappid(1610801) -- DLC 1610801
addappid(1676120) -- DLC 1676120
addappid(1759020) -- DLC 1759020
addappid(1759021) -- DLC 1759021
addappid(1759022) -- DLC 1759022
addappid(1759170) -- DLC 1759170
addappid(1792090) -- DLC 1792090
addappid(1832020) -- DLC 1832020
addappid(1983081) -- EVE Online: 24 Months Omega Time
addappid(1983083) -- EVE Online: 100 PLEX
addappid(1983085) -- EVE Online: 1000 PLEX
addappid(1983086) -- EVE Online: 1500 PLEX
addappid(1983087) -- EVE Online: 3000 PLEX
addappid(1983088) -- EVE Online: 6000 PLEX
addappid(1983089) -- EVE Online: 12000 PLEX
addappid(1983090) -- EVE Online: 20000 PLEX
addappid(1983170) -- EVE Online: 500 PLEX
addappid(2005520) -- EVE Online: 1 Multiple Character Training
addappid(2830570) -- EVE Online: Starter Pack 2024
addappid(4383520) -- EVE Online: Level 2 Mastery pack (2026)
addappid(4383530) -- EVE Online: Level 3 Mastery pack (2026)
addappid(4383540) -- EVE Online: Level 4 Mastery pack (2026)
addappid(4383550) -- EVE Online: Level 5 Mastery pack (2026)
addappid(4399740) -- EVE Online: Level 1 Mastery pack (2026)

-- MAIN APP DEPOTS / PACKAGES
addappid(8500, 1, "dea24eb80b8e68a8c736965aa5d4aff1d4f9ea05abceb7a8417e109f8383729c")
addappid(8501, 1, "c566ea8e7e68fe163d7758b78b008c027d90bd8d74760589f03048805054cae8") -- (windows)
addappid(8503, 1, "5c1802653b1a7b773e0611da0582add68784999ecc329ad20da788fe6825339f") -- (macos)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addtoken(748100, "15970335550637361698")

