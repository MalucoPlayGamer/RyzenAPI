-- Lua provided by RyzenAPI
-- Game: Frog Island

-- MAIN APP DEPOTS / PACKAGES
addappid(2332150, 1, "7dc9ab3944eeace503ce6a09e15106d87a0af2c88c4f8e1aac6f5676fae2fe09") -- Frog Island
addappid(2332151, 1, "f8257dedde5c69b69296613afd771f3b36ef02929dabc24c6c685319d293b2a8") -- Depot 2332151
addappid(2332153, 1, "fdc42fc8e593ec68cd924c577fe330f50944b0e3472edc3fe5dcde62c594b73c") -- Depot 2332153

