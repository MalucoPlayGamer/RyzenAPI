-- 2332150's Lua and Manifest Created by Hubcap Manifest
-- Frog Island
-- Created: August 27, 2026 at 13:28:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2332150, 1, "7dc9ab3944eeace503ce6a09e15106d87a0af2c88c4f8e1aac6f5676fae2fe09") -- Frog Island
-- MAIN APP DEPOTS
addappid(2332151, 1, "f8257dedde5c69b69296613afd771f3b36ef02929dabc24c6c685319d293b2a8") -- Depot 2332151
setManifestid(2332151, "3689674086378715131", 1314020600)
addappid(2332153, 1, "fdc42fc8e593ec68cd924c577fe330f50944b0e3472edc3fe5dcde62c594b73c") -- Depot 2332153
setManifestid(2332153, "8551290007215626188", 1317517512)