-- Lua provided by RyzenAPI
-- Game: addappid(1240300)

-- MAIN APPLICATION
addappid(1240300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240300,0,"039b0fbf37c92d42276708c6310feca0d10e9b197a1eca76b2e4f37d3cbf27a3")
