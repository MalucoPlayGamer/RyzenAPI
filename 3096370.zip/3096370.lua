-- Lua provided by RyzenAPI
-- Game: 3096370

-- MAIN APPLICATION
addappid(3096370)
-- Game: addappid(3096370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096371, 1, "cf380fb2ddefa75716b712a06aa253058b91cf76861db4ceb90872a089b22165")
