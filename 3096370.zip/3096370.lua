-- Lua provided by RyzenAPI
-- Game: Hyper Empire

-- MAIN APPLICATION
addappid(3096370)
addappid(3771200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096371, 1, "cf380fb2ddefa75716b712a06aa253058b91cf76861db4ceb90872a089b22165")
