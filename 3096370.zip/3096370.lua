-- Lua provided by RyzenAPI 
-- Game: AppID 3096370
addappid(3096370)
addappid(3096371, 1, "cf380fb2ddefa75716b712a06aa253058b91cf76861db4ceb90872a089b22165")
