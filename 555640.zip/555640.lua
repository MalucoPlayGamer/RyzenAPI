-- Lua provided by RyzenAPI
-- Game: Japanese School Life

-- MAIN APPLICATION
addappid(555640)

-- MAIN APP DEPOTS / PACKAGES
addappid(555641, 1, "7432b47d01674e922a1e2b53914b417ac636b07539602d1e5f0f95fd809e1c60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
