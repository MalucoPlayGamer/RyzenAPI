-- Lua provided by RyzenAPI
-- Game: LUMINES REMASTERED

-- MAIN APPLICATION
addappid(851670)
addappid(852430)

-- MAIN APP DEPOTS / PACKAGES
addappid(851671,0,"a52d6f893a3bd97c89b5a9791a7431131e438415e5ed0751b73f56a7f717604b")
addappid(852430,0,"795802960c12b5951c1a45aeab49469f719a12197a218b569bac79fd475e4acf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
