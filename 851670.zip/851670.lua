-- Lua provided by RyzenAPI
-- Game: Game: AppID 851670

-- MAIN APPLICATION
addappid(851670)
-- Game: addappid(851670)

-- MAIN APP DEPOTS / PACKAGES
addappid(851671, 1, "a52d6f893a3bd97c89b5a9791a7431131e438415e5ed0751b73f56a7f717604b")
