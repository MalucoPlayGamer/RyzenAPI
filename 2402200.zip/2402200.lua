-- Lua provided by RyzenAPI
-- Game: Hidden Kitten

-- MAIN APPLICATION
addappid(2402200)
-- Game: addappid(2402200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402201, 1, "50ba32485dc44c7ea78e25218284a403c922ef314d276f2970abba6ec9d928f6")
