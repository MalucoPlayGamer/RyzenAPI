-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - High Fantasy Generator Pack for MZ

-- MAIN APPLICATION
addappid(1680920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680920,0,"2a43daaf0b2da0bc6fd35630626816b9ca7db0d754588fe73c97ce239b5d0f94")

