-- Lua provided by RyzenAPI
-- Game: addappid(933539)

-- MAIN APPLICATION
addappid(933539)

-- MAIN APP DEPOTS / PACKAGES
addappid(933539,0,"464af5704ff766505d9ce5e4950c26a1175b696c846281379dddb59cefa7197e")
