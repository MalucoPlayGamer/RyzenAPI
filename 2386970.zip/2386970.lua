-- Lua provided by RyzenAPI
-- Game: addappid(2386970)

-- MAIN APPLICATION
addappid(2386970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386971, 1, "fb1fa81fd627d1e63b3cd8a976393d9ad139a50ce95e52bcaa0db3b06984eae4")
