-- Lua provided by RyzenAPI
-- Game: 1022509

-- MAIN APPLICATION
addappid(1022509)
-- Game: addappid(1022509)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022509,0,"774532824feda3cc9e06b0691f76daf62ec78cdddb8fd1de0032726ce75f4eed")
