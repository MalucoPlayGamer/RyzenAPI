-- Lua provided by RyzenAPI
-- Game: DFF NT: Virtuous Mercenary Appearance Set for Ramza Beoulve

-- MAIN APPLICATION
addappid(1022509)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022509,0,"774532824feda3cc9e06b0691f76daf62ec78cdddb8fd1de0032726ce75f4eed")
