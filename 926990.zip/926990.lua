-- Lua provided by RyzenAPI
-- Game: 926990

-- MAIN APPLICATION
addappid(926990)
addappid(1529920)
addappid(1529930)
addappid(1970630)
addappid(2874030)
-- Game: addappid(926990)

-- MAIN APP DEPOTS / PACKAGES
addappid(926991, 1, "28d993a32040d80b634e5f3338c3f228c75b765f38f99568a398e53b75670e8f")
addappid(926992, 1, "b6898f382435b9c540dae42e9a2b5fdf283a5c4f340c3294e032e782a89ff950")
