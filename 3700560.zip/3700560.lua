-- Lua provided by RyzenAPI
-- Game: Unbound Souls Playtest

-- MAIN APPLICATION
addappid(3700560)
-- Game: addappid(3700560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3700561, 1, "83f6c3661293a4ee12093f2bbc00f7e06256a03b1020f8231acfa5a5c50f23c1")
