-- Lua provided by RyzenAPI
-- Game: Alchemist's Fantasy R ~ A Girl's Alchemic Furnace ~

-- MAIN APPLICATION
addappid(2390000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390001, 1, "af5fecb753e6548352f37813ffd01b29226320661d0d0354681ad013dfc92567")
addappid(2390002, 1, "ad99ea15389192754327cd341b34e4a0752b42920bb2b38d02d59e0989800fa0")
