-- Lua provided by SkyAPI 
-- Game: Otherwar
addappid(1526870)
addappid(1526871, 1, "1645d3ee1125c44d41bf2adba218e5d6b066653d58501dda24f44b802ee0b607")
