-- Lua provided by RyzenAPI
-- Game: Otherwar

-- MAIN APPLICATION
addappid(1526870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526871, 1, "1645d3ee1125c44d41bf2adba218e5d6b066653d58501dda24f44b802ee0b607")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1526880)
addappid(1576040)
addappid(1576041)
