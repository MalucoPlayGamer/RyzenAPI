-- Lua provided by RyzenAPI
-- Game: Break the Empire

-- MAIN APPLICATION
addappid(2975180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975181, 1, "5256036a7a12a705a8201da13609d7359d0f847acc1381d5ddf29b1619cdc4c6")

