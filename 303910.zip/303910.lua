-- Lua provided by RyzenAPI
-- Game: addappid(303910)

-- MAIN APPLICATION
addappid(303910)

-- MAIN APP DEPOTS / PACKAGES
addappid(303911, 1, "38c5fc19d3030c73c9a92e364990bda991dcb083385ce3b364b6b811a19cf149")
