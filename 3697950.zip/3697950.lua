-- Lua provided by RyzenAPI
-- Game: Game: Scratchers

-- MAIN APPLICATION
addappid(3697950)
-- Game: addappid(3697950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3697951, 1, "360a2dabc4bcf7130dab9974b690da3e4a822732cefb7ac5d595849e3df51f8a")
