-- Lua provided by SkyAPI 
-- Game: Scratchers
addappid(3697950)
addappid(3697951, 1, "360a2dabc4bcf7130dab9974b690da3e4a822732cefb7ac5d595849e3df51f8a")
