-- Lua provided by RyzenAPI
-- Game: Home Design 3D

-- MAIN APPLICATION
addappid(420000)
addappid(788430)

-- MAIN APP DEPOTS / PACKAGES
addappid(420001, 1, "d757129515954ff5ff3bf232afc98b9081be7bb965387e233de9165426c12ad6")
addappid(420002, 1, "21e39bf79aa7c22e12fbe15325852741b2483ec93116c9584545af1bcb9eb3a1")

