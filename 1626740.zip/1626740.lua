-- Lua provided by SkyAPI 
-- Game: Horny Alice: Gothic Run
addappid(1626740)
addappid(1626741, 1, "9d5232365882b679cc095712a6420753cb516955a6d378858f54e7714ad17620")
