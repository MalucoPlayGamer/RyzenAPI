-- Lua provided by RyzenAPI
-- Game: Game: Horny Alice: Gothic Run

-- MAIN APPLICATION
addappid(1626740)
-- Game: addappid(1626740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1626741, 1, "9d5232365882b679cc095712a6420753cb516955a6d378858f54e7714ad17620")
