-- Lua provided by SkyAPI 
-- Game: Possessions
addappid(1999850)
addappid(1999851, 1, "e98654c81b12270289b6e85461d0fc3006be981744c7ec36b32b31dba1b36437")
addappid(1999852, 1, "49d63a205f143c7cc085b8be96e48a8ef83730149d5e674b2ad7d637f133ac58")
