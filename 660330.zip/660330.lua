-- Lua provided by RyzenAPI
-- Game: Ragnarok Re:Start

-- MAIN APPLICATION
addappid(660330)

-- MAIN APP DEPOTS / PACKAGES
addappid(660331, 1, "39666e9b287b9d9a6e679b65597ae9bc32400626136e414e8e0347d7ad3d64c6")
