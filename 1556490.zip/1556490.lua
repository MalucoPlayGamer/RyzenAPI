-- Lua provided by RyzenAPI
-- Game: 1556490

-- MAIN APPLICATION
addappid(1556490)
-- Game: addappid(1556490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556491, 1, "56b717234ff080ad7072a3139b48f34cb76aeaf250290a8443a8477901a8ccfa")
