-- Lua provided by RyzenAPI 
-- Game: Lobotomy
addappid(3505700)
addappid(3505701, 1, "572c2ee1aa84c75b8fca7243ce8791961ce01a594ebefe1c9a10f30be80e1551")
