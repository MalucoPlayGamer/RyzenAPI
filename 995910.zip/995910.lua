-- Lua provided by RyzenAPI
-- Game: 995910

-- MAIN APPLICATION
addappid(995910)
-- Game: addappid(995910)

-- MAIN APP DEPOTS / PACKAGES
addappid(995911, 1, "d083428e53ff58a99eedb63a15340fb3cf0c3c4e2ed4471dce9ee5b6889726cf")
