-- Lua provided by RyzenAPI
-- Game: 1130440

-- MAIN APPLICATION
addappid(1130440)
-- Game: addappid(1130440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130441, 1, "ed1897299e7553a4033a8ebdef174f5d997018e0a9b252510e97cb18cb4127ca")
