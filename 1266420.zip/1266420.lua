-- Lua provided by RyzenAPI
-- Game: addappid(1266420)

-- MAIN APPLICATION
addappid(1266420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266421, 1, "7b98926d6354ff8bc30e00899817e10bbc20c3612abea337be933a4f1cf1e4ad")
