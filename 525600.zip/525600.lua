-- Lua provided by RyzenAPI
-- Game: Dyno Adventure

-- MAIN APPLICATION
addappid(525600)

-- MAIN APP DEPOTS / PACKAGES
addappid(525601,0,"0e43978e5a763c7a386754e36e2b456c316560adc346934c7986e229a0592a8f")
addappid(525602,0,"e2416d9114ded3da99f5f6efb243bbeadf0b5a5c20206384193ab917746fed18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
