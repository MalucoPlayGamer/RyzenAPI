-- Lua provided by RyzenAPI
-- Game: Princess Safia & Her Lesbian Master

-- MAIN APPLICATION
addappid(3287070)
-- Game: addappid(3287070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3287071, 1, "98cbde6eaa884644d285e124d202e7220a62a0c0f54c68454f7f7fbe83a25b13")
