-- Lua provided by RyzenAPI
-- Game: Princess Safia & Her Lesbian Master

-- MAIN APPLICATION
addappid(3287070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3287071, 1, "98cbde6eaa884644d285e124d202e7220a62a0c0f54c68454f7f7fbe83a25b13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
