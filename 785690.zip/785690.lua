-- Lua provided by RyzenAPI
-- Game: Game: desTRUCKtors: Warfare Showdown

-- MAIN APPLICATION
addappid(785690)
-- Game: addappid(785690)

-- MAIN APP DEPOTS / PACKAGES
addappid(785691, 1, "c4a3f14f1f6ab8c4c6c6765b4ef1f138befb0ede8f44d36fc4aabc595c6c2461")
addappid(785692, 1, "ca995f8ac3ef50c3c02047605b1e36695a9e26c627a2e05b25673554a72b6aaf")
