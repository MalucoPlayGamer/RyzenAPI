-- Lua provided by SkyAPI 
-- Game: AppID 491100
addappid(491100)
addappid(491101, 1, "1025d0b655f99c9446a89c217d8df6ba3d8e4ec08bd32c87a529c7b9f36e3952")
