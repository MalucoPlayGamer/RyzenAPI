-- Lua provided by RyzenAPI
-- Game: 2217110

-- MAIN APPLICATION
addappid(2217110)
-- Game: addappid(2217110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217111, 1, "eb7fd0267841d9694942a2e835aa6a136ce27eea0a8b059c4bb9313db4d6f1d6")
