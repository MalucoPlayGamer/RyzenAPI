-- Lua provided by RyzenAPI
-- Game: DuelVox: Max Quality

-- MAIN APPLICATION
addappid(1587940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1587941, 1, "863fc9b26b7da9ee7fbbe7b52ae957cb6b1cbdf3355e021f24d7ff77543f50f1")

