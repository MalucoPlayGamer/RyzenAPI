-- Lua provided by RyzenAPI 
-- Game: DuelVox: Max Quality
addappid(1587940)
addappid(1587941, 1, "863fc9b26b7da9ee7fbbe7b52ae957cb6b1cbdf3355e021f24d7ff77543f50f1")
