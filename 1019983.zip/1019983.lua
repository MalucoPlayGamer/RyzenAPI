-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Zhong Hui Special Scenario / 鍾会「追加ＩＦシナリオセット」

-- MAIN APPLICATION
addappid(1019983)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019983,0,"0c0b3b05158288f1971157f50a0c38eb47982c46063a85bcf9ac9db731e8b3df")
