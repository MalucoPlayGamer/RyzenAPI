-- Lua provided by RyzenAPI
-- Game: Game: Planet Nomads

-- MAIN APPLICATION
addappid(504050)
-- Game: addappid(504050)

-- MAIN APP DEPOTS / PACKAGES
addappid(504051, 1, "902430b7c5e46640a659c7c1bd47abab7781aed3b62e8448365a79df199d720e")
addappid(504054, 1, "8fb844c26bb15d5610b21743b3214b94e4555213051f9b4b788d6329d282bc87")
