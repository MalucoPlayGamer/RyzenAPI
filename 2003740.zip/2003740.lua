-- Lua provided by RyzenAPI
-- Game: 2003740

-- MAIN APPLICATION
addappid(2003740)
-- Game: addappid(2003740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003741, 1, "56c472594ebce701e04f9a77b31c822aeebbc70dc85b9d20fc4c4566b1404b3e")
