-- Lua provided by RyzenAPI
-- Game: addappid(940580)

-- MAIN APPLICATION
addappid(940580)
addappid(1075460)

-- MAIN APP DEPOTS / PACKAGES
addappid(940581, 1, "5c7cc0b84571bed28199c9ebdeffb43d0f7907f522da74793b3b7e2986bc4a6e")
