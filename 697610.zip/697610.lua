-- Lua provided by RyzenAPI
-- Game: Idle Bouncer

-- MAIN APPLICATION
addappid(697610)
