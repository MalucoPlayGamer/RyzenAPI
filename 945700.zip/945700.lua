-- Lua provided by RyzenAPI
-- Game: addappid(945700)

-- MAIN APPLICATION
addappid(945700)
addappid(997100)
addappid(999470)
addappid(999520)
addappid(1000680)
addappid(1000690)
addappid(1025640)
addappid(1025660)
addappid(1025680)

-- MAIN APP DEPOTS / PACKAGES
addappid(945701, 1, "ee5ac2e290c93cdba0776c9aa93507defe13c201f530ab72906c27dee3b53cd9")
