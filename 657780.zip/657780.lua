-- Lua provided by RyzenAPI
-- Game: Rome Circus Maximus: Chariot Race VR

-- MAIN APPLICATION
addappid(657780)
addappid(657781)
addappid(657782)

-- MAIN APP DEPOTS / PACKAGES
addappid(657783,0,"af7fd1ba9dd0a095ef5c104b1da9f4a24ca571ab57f69f7f038f2dca77fd9c93")
