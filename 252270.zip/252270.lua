-- Lua provided by RyzenAPI
-- Game: addappid(252270)

-- MAIN APPLICATION
addappid(252270)

-- MAIN APP DEPOTS / PACKAGES
addappid(252271, 1, "54c031a70d12a15b8801d705cae996e6ac9de682806a2de0fe93ed0ffe9c906d")
