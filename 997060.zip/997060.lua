-- Lua provided by RyzenAPI
-- Game: Game: Kotodama: The 7 Mysteries of Fujisawa

-- MAIN APPLICATION
addappid(997060)
-- Game: addappid(997060)

-- MAIN APP DEPOTS / PACKAGES
addappid(997061, 1, "9c5ff087766d53425fc82aa3ae04455e33ca1203a8fbf07623fe5c35369dc57d")
