-- Lua provided by RyzenAPI
-- Game: Dashie's Puh-ranormal Activity

-- MAIN APPLICATION
addappid(1393210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393211, 1, "d55ae9c9b227e315de9cb4d1f92ab2ec0a94480bbe297251c454f25de8d20d04")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
