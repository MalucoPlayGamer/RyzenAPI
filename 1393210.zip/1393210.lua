-- Lua provided by SkyAPI 
-- Game: Dashie's Puh-ranormal Activity
addappid(1393210)
addappid(1393211, 1, "d55ae9c9b227e315de9cb4d1f92ab2ec0a94480bbe297251c454f25de8d20d04")
