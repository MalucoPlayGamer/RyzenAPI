-- Lua provided by RyzenAPI
-- Game: Game: Dashie's Puh-ranormal Activity

-- MAIN APPLICATION
addappid(1393210)
-- Game: addappid(1393210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393211, 1, "d55ae9c9b227e315de9cb4d1f92ab2ec0a94480bbe297251c454f25de8d20d04")
