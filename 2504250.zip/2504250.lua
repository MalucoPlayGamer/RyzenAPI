-- Lua provided by SkyAPI 
-- Game: Telebbit
addappid(2504250)
addappid(2504251, 1, "2e76340594cf5e363e7f646754149fd1362c8dfca4917fd63479163a5a94ed20")
