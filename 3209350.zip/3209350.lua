-- Lua provided by RyzenAPI 
-- Game: AppID 3209350
addappid(3209350)
addappid(3209351, 1, "fecd4691bfdd1ef18b0de779c8516554034ec3cc0da9c2b995c4cca3dc73317a")
