-- Lua provided by RyzenAPI
-- Game: Cats and Seek: Tokyo Demo

-- MAIN APPLICATION
addappid(3209350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209351, 1, "fecd4691bfdd1ef18b0de779c8516554034ec3cc0da9c2b995c4cca3dc73317a")
