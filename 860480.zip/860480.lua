-- Lua provided by RyzenAPI
-- Game: Fernz Gate

-- MAIN APPLICATION
addappid(860480)

-- MAIN APP DEPOTS / PACKAGES
addappid(860481,0,"d5efb41d575136f40de393eb30aec6abed646cc837bbee39714912a881e7e303")

