-- Lua provided by RyzenAPI
-- Game: Eggcelerate!

-- MAIN APPLICATION
addappid(1535490)
addappid(1902100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1535491, 1, "63510aca70e5c3f4b26dd47ad43bc09caf87d46325d291718c6d6d383b3ea444")

