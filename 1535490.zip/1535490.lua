-- Lua provided by RyzenAPI
-- Game: Eggcelerate!

-- MAIN APPLICATION
addappid(1535490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535491, 1, "63510aca70e5c3f4b26dd47ad43bc09caf87d46325d291718c6d6d383b3ea444")
