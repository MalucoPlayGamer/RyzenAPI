-- Lua provided by RyzenAPI
-- Game: Scary Hospital Horror Game

-- MAIN APPLICATION
addappid(1343580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343581, 1, "fb0bd5ddd9035c3f2b48119be375c95ee25741cacd9bff7e8ec506d819754fb5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
