-- Lua provided by RyzenAPI 
-- Game: Scary Hospital Horror Game
addappid(1343580)
addappid(1343581, 1, "fb0bd5ddd9035c3f2b48119be375c95ee25741cacd9bff7e8ec506d819754fb5")
