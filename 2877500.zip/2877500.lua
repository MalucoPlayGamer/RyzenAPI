-- Lua provided by RyzenAPI
-- Game: Crop Chronicles

-- MAIN APPLICATION
addappid(2877500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877501, 1, "64f8fb0ca92c2368e4c04ff1d45eb2d000990e59357347588e21dc36b0f7cf8b")
