-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Medieval: Underdeep

-- MAIN APPLICATION
addappid(1468870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468870,0,"b31e2e1ab5bd4996616178599cb7821e2a5c83bb583ee075111976bd237a8a83")
