-- 4429930's Lua and Manifest Created by Hubcap Manifest
-- Water You Doing?
-- Created: August 26, 2026 at 12:22:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4429930) -- Water You Doing?
-- MAIN APP DEPOTS
addappid(4429931, 1, "5fb5d51f8f8bd6def247ca6a2ac00c8ff4001c739567bb2d6bfcfe0142192c55") -- Depot 4429931
setManifestid(4429931, "5196963219976475783", 4160012957)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4429932) -- Depot 4429932 (empty depot)