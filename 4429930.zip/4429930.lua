-- Lua provided by RyzenAPI
-- Game: Water You Doing?

-- MAIN APPLICATION
addappid(4429930) -- Water You Doing?
-- addappid(4429932) -- Depot 4429932 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4429931, 1, "5fb5d51f8f8bd6def247ca6a2ac00c8ff4001c739567bb2d6bfcfe0142192c55") -- Depot 4429931

