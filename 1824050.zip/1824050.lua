-- Lua provided by RyzenAPI
-- Game: Perfect Date Demo

-- MAIN APPLICATION
addappid(1824050)
-- Game: addappid(1824050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824051, 1, "86cb3b72c82ad05aaf7592c0ee18f8b71538e40bf044e93f72c03f59f292dd2a")
