-- Lua provided by RyzenAPI
-- Game: AppID 1166540

-- MAIN APPLICATION
addappid(1166540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166541, 1, "ee4d03ea963da16c45957168c5f96d1a30eac8c028bcebe18f6d86d0d583b896")
