-- Lua provided by RyzenAPI
-- Game: FUSER™ - The Killers - "Mr. Brightside"

-- MAIN APPLICATION
addappid(1427671)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427671,0,"a427c25ff75858e8d1a086c86dec4501c1e3cc75f57232cff142766a71bbc14e")
addtoken(1427671,11004441846419118566)
