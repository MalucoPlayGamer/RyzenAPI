-- Lua provided by RyzenAPI 
-- Game: ABYSS OF THE SACRIFICE
addappid(1442160)
addappid(1442161, 1, "6b0a89259a9a72925f2b8cfb23fc17064ed2812895b9985b30f822f58527a291")
