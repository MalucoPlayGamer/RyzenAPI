-- Lua provided by RyzenAPI
-- Game: Roboquest VR

-- MAIN APPLICATION
addappid(3151760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151761,0,"b8c320b856a47cd9ae7b67aca35238cbc65a85eba17f119c84c684c49b55f8ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
