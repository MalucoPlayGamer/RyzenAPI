-- Lua provided by RyzenAPI
-- Game: Roboquest VR

-- MAIN APPLICATION
addappid(3151760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151761,0,"b8c320b856a47cd9ae7b67aca35238cbc65a85eba17f119c84c684c49b55f8ef")

