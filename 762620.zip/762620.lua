-- Lua provided by RyzenAPI
-- Game: AppID 762620

-- MAIN APPLICATION
addappid(762620)
addappid(764020)
-- Game: addappid(762620)

-- MAIN APP DEPOTS / PACKAGES
addappid(762621, 1, "0157ceae2003dc8ea187239594573f0f43a9190fbbc6df3fea2f70e94bdcb4f3")
