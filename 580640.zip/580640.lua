-- Lua provided by RyzenAPI
-- Game: Game: End State

-- MAIN APPLICATION
addappid(580640)
-- Game: addappid(580640)

-- MAIN APP DEPOTS / PACKAGES
addappid(580641, 1, "ff6da53b42d6064b9785e3887970966b7d1f271ca9ddc59b6eceecd3e1b426ab")
