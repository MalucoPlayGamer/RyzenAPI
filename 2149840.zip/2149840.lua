-- Lua provided by RyzenAPI
-- Game: Goblins Strike Back -Instant Fuck Heroines-

-- MAIN APPLICATION
addappid(2149840)
-- Game: addappid(2149840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149841, 1, "1c78d7198a94267bcd36f0baf737a50a3b4c37356710708e8eaee637f8cf87e5")
addappid(2149842, 1, "4e08d2c41a93d91b8848ef122fc51cb31e5848d7bef4b16e998941e93dd15fb1")
addappid(2149843, 1, "4f9696875a6554aec8718fbb8422fc8d5fb9afd5bf35f3cfe5416039279c86bd")
addappid(2149844, 1, "550d517276e640644ebff0da3ab843a39f623d972556d407cab15f22afc58b74")
