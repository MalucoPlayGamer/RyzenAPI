-- Lua provided by RyzenAPI
-- Game: Omni Magic!

-- MAIN APPLICATION
addappid(1994450)
addappid(2339750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994451, 1, "edd17511c14471c794c0a67a76787b57ee7d6c6cdf8e3a84a6c15a7f46f6472f")

