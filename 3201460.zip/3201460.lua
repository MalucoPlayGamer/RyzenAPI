-- Lua provided by RyzenAPI 
-- Game: AppID 3201460
addappid(3201460)
addappid(3201461, 1, "1dc91d2e021268b88a203afd9f817372aa76e32ba7d0d7acdac30a86535306f5")
