-- Lua provided by RyzenAPI
-- Game: 行星之旅-VR

-- MAIN APPLICATION
addappid(3201460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201461, 1, "1dc91d2e021268b88a203afd9f817372aa76e32ba7d0d7acdac30a86535306f5")
