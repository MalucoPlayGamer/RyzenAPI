-- Lua provided by RyzenAPI
-- Game: Lil Gator Game

-- MAIN APPLICATION
addappid(1586800)
addappid(3205060)
-- Game: addappid(1586800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586801, 1, "227ab3e720c1ec72a87cbd830e798cf009052c2b03872d8fec0ed09e0fba893e")
