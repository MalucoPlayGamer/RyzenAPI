-- Lua provided by RyzenAPI
-- Game: Game: AppID 521200

-- MAIN APPLICATION
addappid(521200)
-- Game: addappid(521200)

-- MAIN APP DEPOTS / PACKAGES
addappid(521201, 1, "562d0f5388bcd45994ab54d74d1daa68917872f8a80cb9cb3031a906ec647854")
addappid(523690, 0, "0a1e5cab8df3ff50c9e83a15d4cd4c75d358d082af52f8f948b2470315aed620")
