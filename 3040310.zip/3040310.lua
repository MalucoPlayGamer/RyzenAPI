-- Lua provided by RyzenAPI
-- Game: AppID 3040310

-- MAIN APPLICATION
addappid(3040310)
-- Game: addappid(3040310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040311, 1, "ca2afe0f5e168670fe283794ac4c2ea3b5168c6b8b1794afa249354f693d08e3")
