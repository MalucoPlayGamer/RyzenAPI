-- Lua provided by RyzenAPI 
-- Game: AppID 3040310
addappid(3040310)
addappid(3040311, 1, "ca2afe0f5e168670fe283794ac4c2ea3b5168c6b8b1794afa249354f693d08e3")
