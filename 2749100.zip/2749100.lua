-- Lua provided by RyzenAPI
-- Game: Dawnmaker

-- MAIN APPLICATION
addappid(2749100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2749102,0,"1e18e1d3753d9ef9f325b9ce218c385f7631e685a28c7aa2f3acbb25d069cb68")

