-- Lua provided by RyzenAPI
-- Game: addappid(2749100)

-- MAIN APPLICATION
addappid(2749100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2749102,0,"1e18e1d3753d9ef9f325b9ce218c385f7631e685a28c7aa2f3acbb25d069cb68")
