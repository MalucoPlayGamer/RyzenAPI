-- Lua provided by RyzenAPI
-- Game: BotMobile

-- MAIN APPLICATION
addappid(2805630)
-- Game: addappid(2805630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805631, 1, "43f6c6992c6011d885f3b6225c49f37319e30953be828b639a51a772fb1f33b6")
