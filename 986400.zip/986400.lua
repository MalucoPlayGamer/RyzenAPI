-- Lua provided by RyzenAPI
-- Game: 986400

-- MAIN APPLICATION
addappid(986400)
-- Game: addappid(986400)

-- MAIN APP DEPOTS / PACKAGES
addappid(986401, 1, "1e297d716ae230749edae3697db2042fc34f7e2343a3b6af5ca0fe1b82dd4a96")
