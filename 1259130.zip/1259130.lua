-- Lua provided by RyzenAPI
-- Game: Game: AppID 1259130

-- MAIN APPLICATION
addappid(1259130)
-- Game: addappid(1259130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259131, 1, "79bef9d1d94b6244daec74f12d397add0870792e2e2b77e9bbbefb34a2c19230")
