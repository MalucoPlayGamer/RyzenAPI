-- Lua provided by RyzenAPI
-- Game: Grifford Academy

-- MAIN APPLICATION
addappid(2445780)
-- Game: addappid(2445780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445781, 1, "ebf9ebd5dc0d18e6e3a507ed82a75dd6203980322c7d3ac92f3b1cdad4005b50")
