-- Lua provided by RyzenAPI
-- Game: Demetrios - The BIG Cynical Adventure

-- MAIN APPLICATION
addappid(451570)
-- Game: addappid(451570)

-- MAIN APP DEPOTS / PACKAGES
addappid(451571, 1, "562b6f76823ed4a62cb9ec4a6f404f7be62f6a151aac9490bf72c1fd92d61a6a")
addappid(451572, 1, "d8632f9025b5a4d6e11086fe558df5d79b948d15c2eebcdc6d0437095c2cb554")
addappid(489780, 0, "d557b5793fcff4a55152f46df0af024a7a67e0799c864236f37c29af89cf1fab")
