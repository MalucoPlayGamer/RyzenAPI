-- Lua provided by RyzenAPI 
-- Game: AppID 571550
addappid(571550)
addappid(571551, 1, "8ec99945804318d49d964b8a520340418858e280c95dfd3e0d59feb964a8198d")
