-- Lua provided by RyzenAPI
-- Game: Hawks Tactical

-- MAIN APPLICATION
addappid(571550)

-- MAIN APP DEPOTS / PACKAGES
addappid(571551, 1, "8ec99945804318d49d964b8a520340418858e280c95dfd3e0d59feb964a8198d")
