-- Lua provided by RyzenAPI
-- Game: Hexcells

-- MAIN APPLICATION
addappid(265890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(265891, 1, "ab3f7b7dc383d2f0afafcefa4956c3d78d2d649f17c54bd7aa09c98b96276ae7")
addappid(265892, 1, "bc26b2cf53cb879e5fc213aef17d0cf77be4a655040ead1f8252b25284a1d011")
addappid(265893, 1, "0adc0b2b77b48210a0a04e9bb50e3c055cde94b1e710f2ef8eb3eac6d3477d27")

