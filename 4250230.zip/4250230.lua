-- 4250230's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Lexxa is streaming
-- Created: June 13, 2026 at 12:11:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4250230) -- Hentai Clicker: Lexxa is streaming
-- MAIN APP DEPOTS
addappid(4250231, 1, "67cd83cfcc8c79eec8f232f290c211b6e90481e2a723c135febe251d6978059e") -- Depot 4250231
setManifestid(4250231, "1648462731030321089", 154598768)