-- Lua provided by RyzenAPI
-- Game: BDSM: Big Drunk Satanic Massacre

-- MAIN APPLICATION
addappid(669950)

-- MAIN APP DEPOTS / PACKAGES
addappid(669951, 1, "ef0c567e8bc3932deeb99e492deaddcf6babef0c90d4039032e6cee107d4e49c")
addappid(669952, 1, "f5ff71405536578d468dda73605095853e453c5fae37b280c7d277e2a772bb81")
addappid(1159900, 0, "7275fb5d4f479f8472bef0d631ad671d50b968fc262d9fd83d56e6b843da0bd9")
addappid(1173920, 0, "06555e2bf3426f7760d3a6bd8cb8fa09dd939a37ef4add411843b39b423ce940")
