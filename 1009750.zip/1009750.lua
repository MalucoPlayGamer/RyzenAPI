-- Lua provided by RyzenAPI
-- Game: 1009750

-- MAIN APPLICATION
addappid(1009750)
-- Game: addappid(1009750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009751, 1, "a7a6a3665117606d82c72bbd228a88d9bbfaa2f7e2547eff0cc2e63083869261")
