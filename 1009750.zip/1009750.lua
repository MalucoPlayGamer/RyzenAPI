-- Lua provided by RyzenAPI
-- Game: Flappatron

-- MAIN APPLICATION
addappid(1009750)
addappid(1197860)
addappid(1262820)
addappid(1271880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009751, 1, "a7a6a3665117606d82c72bbd228a88d9bbfaa2f7e2547eff0cc2e63083869261")
