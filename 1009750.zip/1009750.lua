-- Lua provided by RyzenAPI 
-- Game: AppID 1009750
addappid(1009750)
addappid(1009751, 1, "a7a6a3665117606d82c72bbd228a88d9bbfaa2f7e2547eff0cc2e63083869261")
