-- Lua provided by RyzenAPI
-- Game: Hidden Cats in Berlin

-- MAIN APPLICATION
addappid(2736480)
addappid(2887530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736481, 1, "d26016540df6a8d7724ad918891c51425fe178f5054000ce4ecf76f008839e56")
