-- Lua provided by RyzenAPI
-- Game: Game: La Tale

-- MAIN APPLICATION
addappid(721030)
-- Game: addappid(721030)

-- MAIN APP DEPOTS / PACKAGES
addappid(721031, 1, "fa2d86fd6be05d7cb519eaf22afe2ed139e40cb7413d8205b7610a2d732778fe")
