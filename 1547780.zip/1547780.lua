-- Lua provided by RyzenAPI
-- Game: 1547780

-- MAIN APPLICATION
addappid(1547780)
-- Game: addappid(1547780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547781, 1, "0aa8617dba87f13190cd508a9c64bebf37bbb3f9fd47803e037182f3ac4b6a18")
