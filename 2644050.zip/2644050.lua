-- Lua provided by RyzenAPI
-- Game: Echoes of Elysium

-- MAIN APPLICATION
addappid(2644050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644051,0,"8ec0d1dfffe339d662802170aec22c44a21cc376bedb0b0b426d5fd1a0bc087b")

