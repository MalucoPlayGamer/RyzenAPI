-- Lua provided by RyzenAPI
-- Game: Old Friend

-- MAIN APPLICATION
addappid(570000)

-- MAIN APP DEPOTS / PACKAGES
addappid(570001,0,"cceabc16cf599408e745facebace82cab826c4c7302fdcc60619ac3c56248ec8")

