-- Lua provided by RyzenAPI
-- Game: TrickShot Simulator

-- MAIN APPLICATION
addappid(3384190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3384191, 1, "97901f88cd379424859440c2461e5c102d52c718ec07bf823788ac9a39f9087d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
