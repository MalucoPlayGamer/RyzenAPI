-- Lua provided by RyzenAPI
-- Game: addappid(1950200)

-- MAIN APPLICATION
addappid(1950200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950201, 1, "712c08d52fef0d06d19b824f58fed3ff5738f67886a0dfae8cdb6f5277ae6ac6")
