-- Lua provided by RyzenAPI
-- Game: Game: SQUASER 9

-- MAIN APPLICATION
addappid(3710620)
-- Game: addappid(3710620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3710621, 1, "16cb6c3e376d7c18c81bff9c0d3ee8824d5aac82a730666985b11cf5e702763f")
