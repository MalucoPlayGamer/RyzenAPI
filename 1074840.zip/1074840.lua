-- Lua provided by SkyAPI 
-- Game: AppID 1074840
addappid(1074840)
addappid(1074841, 1, "d2d239e6c36f757cf814eae51f65bee95b34f2adbebf5ea6e7657c97bf6e6596")
