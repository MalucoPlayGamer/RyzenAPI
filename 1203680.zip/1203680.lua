-- Lua provided by RyzenAPI
-- Game: 1203680

-- MAIN APPLICATION
addappid(1203680)
-- Game: addappid(1203680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203682,0,"6e63a7f853cda35f0c0b746100d4ba9d730ff6ea5bc3215e5630f39018bef305")
