-- Lua provided by RyzenAPI
-- Game: Game: Avatar of the Wolf

-- MAIN APPLICATION
addappid(643570)
-- Game: addappid(643570)

-- MAIN APP DEPOTS / PACKAGES
addappid(643571, 1, "e1dad5b585f325a8ed22ee59d5900655994c22571e636ffca9f06feb7a02f778")
