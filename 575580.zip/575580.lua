-- Lua provided by RyzenAPI
-- Game: Game: AppID 575580

-- MAIN APPLICATION
addappid(575580)
-- Game: addappid(575580)

-- MAIN APP DEPOTS / PACKAGES
addappid(575581, 1, "865973aec2980449f3d768088e90ef71d7220f81fc983f983c050e196d488dd2")
