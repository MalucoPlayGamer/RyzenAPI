-- Lua provided by RyzenAPI
-- Game: Queen of Seas

-- MAIN APPLICATION
addappid(575580)
addappid(672530)
addappid(675930)

-- MAIN APP DEPOTS / PACKAGES
addappid(575581, 1, "865973aec2980449f3d768088e90ef71d7220f81fc983f983c050e196d488dd2")

