-- Lua provided by SkyAPI 
-- Game: AppID 575580
addappid(575580)
addappid(575581, 1, "865973aec2980449f3d768088e90ef71d7220f81fc983f983c050e196d488dd2")
