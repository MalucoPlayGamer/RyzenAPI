-- Lua provided by RyzenAPI
-- Game: Emilia's PLAYROOM VR Demo

-- MAIN APPLICATION
addappid(2580030)
-- Game: addappid(2580030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580031, 1, "e2321c9b051d1c0d68b70fbb998fe05c0d01b7f894ae4210deb4669ebe381add")
