-- Lua provided by RyzenAPI
-- Game: Arkheim - Realms at War

-- MAIN APPLICATION
addappid(1856740)
-- Game: addappid(1856740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856741, 1, "dd76ea1be992c5a7bd055a2d9e998c0b4b742098d400df1c08ac5e3f7e826721")
