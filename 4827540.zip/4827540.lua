-- Lua provided by RyzenAPI
-- Game: Galactic Simulator 3

-- MAIN APPLICATION
addappid(4827540) -- Galactic Simulator 3
addappid(4827570) -- Galactic Simulator 3 Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4827541, 1, "a897a03c397f1c37bdf8794b77fea2055fe27737b7215f831757d97472f7abb8") -- Depot 4827541
addappid(4827542, 1, "adad31b5464d21f4631103bdfdba4805ec660bb8e9eaafcad65348ea01ded511") -- Depot 4827542

