-- Lua provided by RyzenAPI
-- Game: AppID 814600

-- MAIN APPLICATION
addappid(814600)

-- MAIN APP DEPOTS / PACKAGES
addappid(814601, 1, "78c4fa2a73487e213224df669cfdbd31bcf758e2c74f4c75328a91bc538c3992")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
