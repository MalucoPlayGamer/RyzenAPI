-- Lua provided by RyzenAPI
-- Game: 伽尔兰特：我的冒险故事 Demo

-- MAIN APPLICATION
addappid(2066670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066671, 1, "aca6dad391783d090cb83b7c09be154792d2bd80f67e26827543d03b5a9388db")

