-- Lua provided by RyzenAPI
-- Game: Game: Hatone

-- MAIN APPLICATION
addappid(2478860)
-- Game: addappid(2478860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478861, 1, "10bb84ce8af53a3175ee934762f91bbf77ac6274d6d5a89f2958c45f5475e697")
