-- Lua provided by RyzenAPI
-- Game: addappid(924330)

-- MAIN APPLICATION
addappid(924330)

-- MAIN APP DEPOTS / PACKAGES
addappid(924333,0,"b7dd0bd60535c0faa0485e0d7dff0cca8148d35dd5d36a99343d484c4e6d0876")
addappid(924334,0,"71b01e36a6dd24038abf359c24132e66ad48379fdaa28db0f3c06930c78ab6cd")
