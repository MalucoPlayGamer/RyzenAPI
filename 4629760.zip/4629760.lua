-- 4629760's Lua and Manifest Created by Hubcap Manifest
-- Elsewar
-- Created: July 30, 2026 at 14:11:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4629760) -- Elsewar
-- MAIN APP DEPOTS
addappid(4629761, 1, "b53746201f97ebc8dc4ebf821bea7aec4c7bb124c1f0bbb1797e95437128aa3d") -- Depot 4629761
setManifestid(4629761, "2674423075883975842", 736262392)