-- Lua provided by RyzenAPI
-- Game: Game: Nemesis of the Roman Empire

-- MAIN APPLICATION
addappid(433290)
-- Game: addappid(433290)

-- MAIN APP DEPOTS / PACKAGES
addappid(433291, 1, "70da914b59c3650e582fb5387537135201d04fbbacdbab78053396ab317cf308")
