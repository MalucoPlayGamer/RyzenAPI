-- Lua provided by RyzenAPI
-- Game: Undercity

-- MAIN APPLICATION
addappid(694140)

-- MAIN APP DEPOTS / PACKAGES
addappid(694141,0,"f8358279b23a1182b282d943cb4f30deefea19a2641d471084233dbd995320be")

