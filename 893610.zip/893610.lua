-- Lua provided by RyzenAPI
-- Game: Game: Skautfold: Into the Fray

-- MAIN APPLICATION
addappid(893610)
-- Game: addappid(893610)

-- MAIN APP DEPOTS / PACKAGES
addappid(893611, 1, "6cfa791ba1b43e6191f36419e06b2663108f2212f70687c3852fc75e3875db88")
