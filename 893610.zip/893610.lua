-- Lua provided by RyzenAPI
-- Game: Skautfold: Into the Fray

-- MAIN APPLICATION
addappid(893610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(893611, 1, "6cfa791ba1b43e6191f36419e06b2663108f2212f70687c3852fc75e3875db88")

