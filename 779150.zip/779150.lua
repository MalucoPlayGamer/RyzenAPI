-- Lua provided by RyzenAPI
-- Game: Shadow of Something

-- MAIN APPLICATION
addappid(779150)
-- Game: addappid(779150)

-- MAIN APP DEPOTS / PACKAGES
addappid(779151, 1, "3ff3ab75bf2a231e2f688afeff129c5b0ff0909c9d70fffc7504904eabd047cf")
