-- Lua provided by RyzenAPI
-- Game: Tangle Tower

-- MAIN APPLICATION
addappid(359510)

-- MAIN APP DEPOTS / PACKAGES
addappid(359511, 1, "4cf3afa340d68d6a4677231a98b5fb96380211929e412cb586a4323ef34b0d58")
addappid(359512, 1, "e4d39d18e0d09e3af86b2c52c68114bb03e5c39337a09ebedc336fb829ac5b61")

