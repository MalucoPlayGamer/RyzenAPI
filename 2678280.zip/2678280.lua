-- Lua provided by RyzenAPI
-- Game: Operation Food to Gold

-- MAIN APPLICATION
addappid(2678280) -- Operation Food to Gold
addappid(2733290) -- Operation Food to Gold - Hip to be Blob DLC
addappid(2733300) -- Operation Food to Gold - Dating your commander DLC
addappid(2831880) -- Operation Food to Gold - 18 Costume - Yukari
addappid(3091210) -- Operation Food to Gold - Rhythm game from Hell

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
addappid(2678281, 1, "0ee3509dca5247d6a63e98a58ef87448e57ed8a7e515e886a2220984a41fcd0c") -- Depot 2678281

