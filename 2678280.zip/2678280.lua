-- Lua provided by RyzenAPI
-- Game: 2678280

-- MAIN APPLICATION
addappid(2678280)
-- Game: addappid(2678280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678281, 1, "0ee3509dca5247d6a63e98a58ef87448e57ed8a7e515e886a2220984a41fcd0c")
