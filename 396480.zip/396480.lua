-- Lua provided by RyzenAPI 
-- Game: Battlevoid: Harbinger
addappid(396480)
addappid(396481, 1, "116820a2f4583c8583e2c0c40b29e5cacc7c85b44574212d733bcd57df355582")
addappid(411030, 0, "182e0565b8d9064970b8b81d19d4a9e893f81eace165641cacb4d8fc7dc4eaa7")
