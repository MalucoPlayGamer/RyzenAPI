-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432159)
-- Game: addappid(1432159)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432159,0,"64068a58c39057d3cfb6f5fed85ec29e3a46f6bc8b46db1a7b8888ae639d3c90")
