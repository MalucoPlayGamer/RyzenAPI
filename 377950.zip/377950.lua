-- Lua provided by RyzenAPI
-- Game: Jamestown+

-- MAIN APPLICATION
addappid(377950)

-- MAIN APP DEPOTS / PACKAGES
addappid(377951, 1, "11201cd64365b77991628af092070e46ab48e9d3daffb9e08c6860d65120c8ff")

