-- Lua provided by RyzenAPI
-- Game: Jamestown+

-- MAIN APPLICATION
addappid(377950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(377951, 1, "11201cd64365b77991628af092070e46ab48e9d3daffb9e08c6860d65120c8ff")

