-- Lua provided by RyzenAPI
-- Game: addappid(753610)

-- MAIN APPLICATION
addappid(753610)

-- MAIN APP DEPOTS / PACKAGES
addappid(753611, 1, "a53995eafaf5d147301bb681fd48d12c47e481f321d88efda2ae45b76f5862c6")
