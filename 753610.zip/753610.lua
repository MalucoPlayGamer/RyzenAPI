-- Lua provided by RyzenAPI
-- Game: J.A.W.S

-- MAIN APPLICATION
addappid(753610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(753611, 1, "a53995eafaf5d147301bb681fd48d12c47e481f321d88efda2ae45b76f5862c6")

