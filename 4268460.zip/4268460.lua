-- Lua provided by RyzenAPI
-- Game: ShoreTiles

-- MAIN APP DEPOTS / PACKAGES
addappid(4268460, 1, "7bf613688e3db044cb4287e4095f616c99aaa723473f2581109db004f8f46e8f") -- ShoreTiles
addappid(4268462, 1, "909929b1b832bc05eecf44cad26df50c3671d05b8ef8ed9e5fac125b5bc34aa7") -- Depot 4268462
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
