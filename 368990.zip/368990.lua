-- Lua provided by RyzenAPI
-- Game: Despair

-- MAIN APPLICATION
addappid(368990)
-- Game: addappid(368990)

-- MAIN APP DEPOTS / PACKAGES
addappid(368991, 1, "1e0e54803f9536e308b3d5196101198439327a1a9030742207b775ebb75c3394")
