-- Lua provided by RyzenAPI
-- Game: Despair

-- MAIN APPLICATION
addappid(368990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(368991, 1, "1e0e54803f9536e308b3d5196101198439327a1a9030742207b775ebb75c3394")

