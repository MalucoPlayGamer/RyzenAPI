-- Lua provided by RyzenAPI
-- Game: addappid(577980)

-- MAIN APPLICATION
addappid(577980)

-- MAIN APP DEPOTS / PACKAGES
addappid(577981, 1, "85f2fc1c39aa2148bb604016f7ee6c26f9e302f55dbeeec0cf394c5c22080402")
