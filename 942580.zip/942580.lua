-- Lua provided by RyzenAPI
-- Game: An Adventurer's Tale

-- MAIN APPLICATION
addappid(942580)

-- MAIN APP DEPOTS / PACKAGES
addappid(942581, 1, "5bf1dc304ce5f8881b538da72313fe15f8e735ea2290b6c9f13ed312e3d778c0")
addappid(1060520, 0, "45774116d78abd7eda659afcb8a7a73d8d0a57ce3b2f09b811486e80a109be57")
