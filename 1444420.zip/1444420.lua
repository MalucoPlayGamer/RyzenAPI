-- Lua provided by RyzenAPI
-- Game: WOMG Lite version

-- MAIN APPLICATION
addappid(1444420)
-- Game: addappid(1444420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444421, 1, "865d5ec872eb44ed7f82d7924b0a8ce5118401dd154af9c8fa105bafb636026f")
addappid(1444422, 1, "cf69997e7ee22d00a2764921a7509c4ec7ad439145a8355d22af2857af98ae84")
