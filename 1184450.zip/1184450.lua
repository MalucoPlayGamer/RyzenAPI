-- Lua provided by RyzenAPI
-- Game: AppID 1184450

-- MAIN APPLICATION
addappid(1184450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184451, 1, "8b08bac7881e56c4c18ab235494f4cac58cae12342a1cb9d376605ed77a40302")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
