-- Lua provided by SkyAPI 
-- Game: AppID 1184450
addappid(1184450)
addappid(1184451, 1, "8b08bac7881e56c4c18ab235494f4cac58cae12342a1cb9d376605ed77a40302")
