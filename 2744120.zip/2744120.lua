-- Lua provided by RyzenAPI
-- Game: Push The Cat with WASD Demo

-- MAIN APPLICATION
addappid(2744120)
-- Game: addappid(2744120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744121, 1, "eb37428d9cb3b754310992919d51dcdd75fb33892a03b952f7bf87e6044bbf16")
