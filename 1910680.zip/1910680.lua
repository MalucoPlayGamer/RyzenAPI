-- Lua provided by SkyAPI 
-- Game: Orb of Creation
addappid(1910680)
addappid(1910681, 1, "8c2123e28967083cfa594cc9dbc20d6036c17ad7fb9503eb27f5a43925829f31")
