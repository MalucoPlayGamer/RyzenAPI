-- Lua provided by RyzenAPI
-- Game: 1910680

-- MAIN APPLICATION
addappid(1910680)
-- Game: addappid(1910680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1910681, 1, "8c2123e28967083cfa594cc9dbc20d6036c17ad7fb9503eb27f5a43925829f31")
