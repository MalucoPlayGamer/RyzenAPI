-- Lua provided by RyzenAPI
-- Game: The Witcher Adventure Game

-- MAIN APPLICATION
addappid(303800)
-- Game: addappid(303800)

-- MAIN APP DEPOTS / PACKAGES
addappid(303801, 1, "35a5209e8c14b94a5672dd91212227234cf1af7c498dbf0e9c8ee61c2862de28")
addappid(303802, 1, "02db5c16585b1d6de0b2f62a22bb6ee9d6ca70f073a0b931f8d94d2861fc475c")
addappid(303803, 1, "9335d47b6d805ce40e6e7407987ebdf2e13865f84df60bb141fa4b30498378d9")
addappid(303804, 1, "d266ef38af7197bc6213426b154f7fc16014278388c15638b2f7f3f4ea3c20b5")
