-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Ghost Recon Wildlands Open Beta

-- MAIN APPLICATION
addappid(584210)
addappid(592531)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(584211, 1, "b147673499f505ee11747b2dcec7492fdab7c8e59c035a10cffb319cce8ab607")
