-- Lua provided by RyzenAPI
-- Game: AppID 584210

-- MAIN APPLICATION
addappid(584210)
-- Game: addappid(584210)

-- MAIN APP DEPOTS / PACKAGES
addappid(584211, 1, "b147673499f505ee11747b2dcec7492fdab7c8e59c035a10cffb319cce8ab607")
