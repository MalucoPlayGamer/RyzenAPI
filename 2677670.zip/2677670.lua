-- Lua provided by RyzenAPI
-- Game: Horny Holiday

-- MAIN APPLICATION
addappid(2677670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677671, 1, "9d369cc48124724feb8afd0e6099e18c0c518dcf1e1d200d9dbc52fc900ed522")
