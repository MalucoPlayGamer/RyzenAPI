-- Lua provided by RyzenAPI
-- Game: Pereelous

-- MAIN APPLICATION
addappid(3719900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3719901,0,"707800ae172697dcaa74d9992ff2c9d344f15aeccd3ca2ddd48ed07702d28734")

