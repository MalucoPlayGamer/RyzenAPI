-- Lua provided by RyzenAPI
-- Game: 488050

-- MAIN APPLICATION
addappid(488050)
-- Game: addappid(488050)

-- MAIN APP DEPOTS / PACKAGES
addappid(488051, 1, "67e42d404db5738626f8cb42b46752bb4d499a6d5263b6284e663a69355eda7a")
