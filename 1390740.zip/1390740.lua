-- Lua provided by RyzenAPI
-- Game: 1390740

-- MAIN APPLICATION
addappid(1390740)
-- Game: addappid(1390740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390741, 1, "aa00af6030ecff83a85feda084440bbe7cf01b4abad38948b1bfd1a4e40d9361")
