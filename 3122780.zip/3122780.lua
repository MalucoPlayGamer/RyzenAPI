-- Lua provided by RyzenAPI
-- Game: Defender Of Falyndor Demo

-- MAIN APPLICATION
addappid(3122780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122781, 1, "a5ec5806f80209323f3e13b10f1d681f4ef32e55071d2a9e98cfc1772ac14d9f")
