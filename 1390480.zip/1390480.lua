-- Lua provided by RyzenAPI
-- Game: Game: Never BreakUp Beta

-- MAIN APPLICATION
addappid(1390480)
-- Game: addappid(1390480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390481, 1, "8eaaca0df14eedc4372b6d16149f1d6ca4892cbef6e97fed03233bdede90e703")
