-- Lua provided by RyzenAPI
-- Game: Flag Collection

-- MAIN APPLICATION
addappid(1384890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384891, 1, "198a367a13ef8374487e0b4f485460c5d8de45798d8d901d910bd83bc14e8bba")

