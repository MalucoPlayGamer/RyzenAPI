-- Lua provided by RyzenAPI
-- Game: addappid(3277440)

-- MAIN APPLICATION
addappid(3277440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277441, 1, "c2e606db33ba64ffa04651f217a4b6c3498928ebc75c6d3cb008227c70eee086")
