-- Lua provided by RyzenAPI 
-- Game: 许愿岛 Hope Isle Demo
addappid(3277440)
addappid(3277441, 1, "c2e606db33ba64ffa04651f217a4b6c3498928ebc75c6d3cb008227c70eee086")
