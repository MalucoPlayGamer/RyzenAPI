-- Lua provided by RyzenAPI
-- Game: Jury - Episode 1: Before the Trial

-- MAIN APPLICATION
addappid(2258290)
addappid(2874140)
addappid(3734730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258291, 1, "1a498a1ba9af0cd8e2465b653d7674c5b7030f799400a9f8927d91780c40be4f")

