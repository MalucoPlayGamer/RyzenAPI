-- Lua provided by RyzenAPI
-- Game: Tayutama 2 -you're the only one-

-- MAIN APPLICATION
addappid(552280)

-- MAIN APP DEPOTS / PACKAGES
addappid(552281, 1, "5a3b0f87c504b47ec60fba6a1f3956622b8201b2b38d7cb7b689a6dde89cfa81")
addappid(552282, 1, "9c9ddf599fe4d37a266b7e980fa04a1fc39aad1f7f8e950fb9eb6c467342e06f")
addappid(552283, 1, "6de6d8419d5948a56ef8691bf1bfb06f42cd1c21a251f2fd5fd3cc36b34afcea")

