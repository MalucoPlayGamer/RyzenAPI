-- Lua provided by SkyAPI 
-- Game: They're Alive!
addappid(3341420)
addappid(3341421, 1, "633257312e1c09b42fe33f1cdb4d4c69a3c62d046631496ad6b8b7c9acafe1f9")
addappid(3341422, 1, "7f2e3efc5ba73e6d360b437f3560036019cb7da09088c4af5ae6861067f1d504")
