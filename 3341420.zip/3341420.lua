-- Lua provided by RyzenAPI
-- Game: They're Alive!

-- MAIN APPLICATION
addappid(3341420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341421, 1, "633257312e1c09b42fe33f1cdb4d4c69a3c62d046631496ad6b8b7c9acafe1f9")
addappid(3341422, 1, "7f2e3efc5ba73e6d360b437f3560036019cb7da09088c4af5ae6861067f1d504")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
