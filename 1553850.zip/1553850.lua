-- Lua provided by SkyAPI 
-- Game: Tartaron
addappid(1553850)
addappid(1553851, 1, "414cf4c7193d3061f81f6b243a878a37098c8da3375f9cb1f43bfe2b5afa864b")
