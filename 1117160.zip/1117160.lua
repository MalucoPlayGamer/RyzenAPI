-- Lua provided by RyzenAPI
-- Game: 1117160

-- MAIN APPLICATION
addappid(1117160)
-- Game: addappid(1117160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117161, 1, "8de6b86fa18fec979e02cebbe314b17c481265bd135dace12a6abe12df242736")
