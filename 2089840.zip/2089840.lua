-- Lua provided by RyzenAPI
-- Game: addappid(2089840)

-- MAIN APPLICATION
addappid(2089840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089840,0,"cf0ee3bde87a208b2bf9425b695b287a2997de71728df89f826fca1667197f85")
