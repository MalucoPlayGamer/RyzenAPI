-- Lua provided by RyzenAPI
-- Game: Copy Kitty

-- MAIN APPLICATION
addappid(349250)

-- MAIN APP DEPOTS / PACKAGES
addappid(349251, 1, "2e5a312dea0b6053bd6537894f55103a9fc34bc6ef023cf487c7d67904ccfb4b")
addappid(914310, 0, "476034bdcd0af47cc5eb21beb89bc0c929580661278cf1ebfd214aa8f59c7745")

