-- Lua provided by RyzenAPI
-- Game: Copy Kitty

-- MAIN APPLICATION
addappid(349250)

-- MAIN APP DEPOTS / PACKAGES
addappid(349251, 1, "2e5a312dea0b6053bd6537894f55103a9fc34bc6ef023cf487c7d67904ccfb4b")
addappid(914310, 0, "476034bdcd0af47cc5eb21beb89bc0c929580661278cf1ebfd214aa8f59c7745")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
