-- Lua provided by RyzenAPI
-- Game: addappid(2768920)

-- MAIN APPLICATION
addappid(2768920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768921, 1, "38b8d4ff94b3e335d6aa2b37efcc03730ee253858b3f5ee29b5a858e6cd9b286")
