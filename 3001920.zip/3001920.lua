-- Lua provided by RyzenAPI 
-- Game: AppID 3001920
addappid(3001920)
addappid(3001921, 1, "e9d2782af891eec389985b0df74a34046a397fdafb4426cc1669a3d5aab731ca")
