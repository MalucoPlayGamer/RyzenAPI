-- Lua provided by SkyAPI 
-- Game: AppID 2411000
addappid(2411000)
addappid(2411001, 1, "dc407d1beb12c35b7335288817907526cbc60e5e8c22623f211fd934044ac624")
