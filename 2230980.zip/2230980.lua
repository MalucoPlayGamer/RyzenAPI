-- Lua provided by RyzenAPI
-- Game: Caribbean Legend

-- MAIN APPLICATION
addappid(2230980)
addappid(2628610)
addappid(2749310)
addappid(3162620)
addappid(3398030)
addappid(3549890)
addappid(3549900)
addappid(3549910)
addappid(4454410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2230981, 1, "e7fe65b71497e767bb8766c4fe56dc415b2d80b04c17e0b513f8f63c913fc4f4")
addappid(2230982, 1, "91bee1c1f2bfb0853316a2d1104ede22aaee2beca78ccecfbbc4c586eee29a8d")

