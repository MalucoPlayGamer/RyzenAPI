-- Lua provided by RyzenAPI
-- Game: Game: A Familiar Fairytale Dyslexic Text Based Adventure

-- MAIN APPLICATION
addappid(929570)
-- Game: addappid(929570)

-- MAIN APP DEPOTS / PACKAGES
addappid(929571, 1, "a9a057ec8fbfe73e2d81fbf157c45930a41909dd598897aef7423280e8ffc8d6")
