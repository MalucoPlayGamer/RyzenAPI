-- Lua provided by RyzenAPI
-- Game: Volcano Princess Demo

-- MAIN APPLICATION
addappid(1688740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688741, 1, "2c6713512f3bb401e9b44cf156200294cc84cbca109caf55a59c6da9a2475f00")

