-- Lua provided by RyzenAPI
-- Game: 恶娑海 Demo

-- MAIN APPLICATION
addappid(1814650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814651, 1, "9e11d24e04fe01ee34d089a236ba979bf1a44879a7ee68938fb4ae2d74fd5c5e")
