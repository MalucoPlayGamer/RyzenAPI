-- Lua provided by RyzenAPI
-- Game: House of Lizards

-- MAIN APPLICATION
addappid(2230070)
-- Game: addappid(2230070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230071, 1, "da11a05a1fe5d159c5a18f9fc5bce558c1130d844111a20353aa29f1937a05bb")
addappid(2230074, 1, "1dfa4ab8d9f052fac078cc6fb5427299ceab48fdf7bff028899c10ae541639fb")
