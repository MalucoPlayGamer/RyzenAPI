-- Lua provided by RyzenAPI
-- Game: Airline Manager

-- MAIN APPLICATION
addappid(1641650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641651, 1, "58027028b5bfdaf7f01e4b31fca3f7548ff5ca23e8ea1909a5c220fd78666e7b")

