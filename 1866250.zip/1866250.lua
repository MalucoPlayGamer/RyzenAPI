-- Lua provided by RyzenAPI
-- Game: addappid(1866250)

-- MAIN APPLICATION
addappid(1866250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866251, 1, "2fc07cc4af51fcc526ecb8a4b00999d1b2356eb75509b65da34c98268fb03dd3")
