-- Lua provided by RyzenAPI
-- Game: addappid(2263970)

-- MAIN APPLICATION
addappid(2263970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263971, 1, "b33aa4a5e530984027774a34ed7eb7945f4fa5fe02b86a2479f6c35ad98ca588")
