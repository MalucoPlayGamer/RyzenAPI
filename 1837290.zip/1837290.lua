-- Lua provided by RyzenAPI
-- Game: 7Days Origins Demo

-- MAIN APPLICATION
addappid(1837290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837291, 1, "a14e486cef2b07fc50cb80803af015139fdeab6cad6fa14bfbdbdf3227559a2a")

