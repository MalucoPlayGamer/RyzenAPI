-- Lua provided by RyzenAPI 
-- Game: Thursday Nite Thunkin'
addappid(2512500)
addappid(2512501, 1, "5fc8342e8f7b93a539cb3ba05bfb50d3f89bb1756a362cb37eaaba57eb5fcdef")
