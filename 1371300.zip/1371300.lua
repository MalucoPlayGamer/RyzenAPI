-- Lua provided by RyzenAPI
-- Game: Cuba2077

-- MAIN APPLICATION
addappid(1371300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1371301, 1, "f68b0c432e0c37ef93189fd75cf16550f3a05ef740fd98fd2e73ffbb0eaaf162")

