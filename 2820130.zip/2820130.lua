-- Lua provided by RyzenAPI
-- Game: Anno 1602 History Edition

-- MAIN APPLICATION
addappid(2820130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820131, 1, "c0f6156078303176fa2f1c09fc839007ca4f44a47254c8baa15afbea21356359")
