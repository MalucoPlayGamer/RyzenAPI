-- Lua provided by RyzenAPI
-- Game: 1710080

-- MAIN APPLICATION
addappid(1710080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710080,0,"e22cabfc35fce5a3464c4d624e5a1d0816a77a4fd088c39711e57cccdee5aedf")

