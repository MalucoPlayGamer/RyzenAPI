-- Lua provided by RyzenAPI
-- Game: Hellsplit: Arena

-- MAIN APPLICATION
addappid(1039880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039881, 1, "c82e45950978f480b8308f86005c508ac9eb7f2a67dd3563162ca69a90dcc269")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
