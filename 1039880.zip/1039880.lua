-- Lua provided by RyzenAPI
-- Game: Hellsplit: Arena

-- MAIN APPLICATION
addappid(1039880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039881, 1, "c82e45950978f480b8308f86005c508ac9eb7f2a67dd3563162ca69a90dcc269")

