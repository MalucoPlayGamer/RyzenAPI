-- Lua provided by RyzenAPI
-- Game: AppID 1284280

-- MAIN APPLICATION
addappid(1284280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284281, 1, "481818acd22bdac7f110e4cd2a9c72f604e67cebf3dd3ac7892b5a93f2ee369b")

