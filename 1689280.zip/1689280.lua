-- Lua provided by RyzenAPI
-- Game: 1689280

-- MAIN APPLICATION
addappid(1689280)
-- Game: addappid(1689280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689281, 1, "c64db2c5b9204ffff9c2b4a8daf2b7c3b5380e9cc90480d02506cd32bee7b34f")
