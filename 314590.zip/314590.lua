-- Lua provided by RyzenAPI
-- Game: Game: room13

-- MAIN APPLICATION
addappid(314590)
-- Game: addappid(314590)

-- MAIN APP DEPOTS / PACKAGES
addappid(314591, 1, "c01a93119fc96f13cad36c94215b5b5e0af894d4e40c61db81577e4d5097c5d2")
