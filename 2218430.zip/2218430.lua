-- Lua provided by RyzenAPI
-- Game: 2218430

-- MAIN APPLICATION
addappid(2218430)
-- Game: addappid(2218430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218431, 1, "f38e7cb77062ce4b827ceb945c0090e9885625a146bda5b90553ba7efaf65e2b")
