-- Lua provided by RyzenAPI
-- Game: addappid(300510)

-- MAIN APPLICATION
addappid(300510)

-- MAIN APP DEPOTS / PACKAGES
addappid(300511, 1, "850ddd12aeecd05786134e8fe0da76aeac6e554d07de67424005a75f1c0e8194")
