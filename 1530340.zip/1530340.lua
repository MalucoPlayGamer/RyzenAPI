-- Lua provided by RyzenAPI
-- Game: Incremental Epic Hero

-- MAIN APPLICATION
addappid(1530340) -- Incremental Epic Hero
addappid(1555850) -- Incremental Epic Hero - Starter Pack
addappid(1555851) -- Incremental Epic Hero - Global Skill Slot Pack
addappid(1555852) -- Incremental Epic Hero - Premium Nitro Pack
addappid(1555853) -- Incremental Epic Hero - Monster Gold Cap Pack
addappid(1580930) -- Incremental Epic Hero - IEH2 Support Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1530341, 1, "02de71228eb52224216364767c0e607d40a99a08843a4578d189f7910e8e3da6") -- Incremental Epic Hero Content
addappid(1530342, 1, "8b0ed05666219d5dd243e8f037da262cbf80924847efdad8b6c57ab3b2e41c65") -- Incremental Epic Hero for Mac

