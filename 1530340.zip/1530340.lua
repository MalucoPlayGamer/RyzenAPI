-- 1530340's Lua and Manifest Created by Hubcap Manifest
-- Incremental Epic Hero
-- Created: September 29, 2025 at 19:04:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1530340) -- Incremental Epic Hero
-- MAIN APP DEPOTS
addappid(1530341, 1, "02de71228eb52224216364767c0e607d40a99a08843a4578d189f7910e8e3da6") -- Incremental Epic Hero Content
setManifestid(1530341, "3090184936705141749", 436265304)
addappid(1530342, 1, "8b0ed05666219d5dd243e8f037da262cbf80924847efdad8b6c57ab3b2e41c65") -- Incremental Epic Hero for Mac
setManifestid(1530342, "7551909646311270834", 432077208)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1555850) -- Incremental Epic Hero - Starter Pack
addappid(1555851) -- Incremental Epic Hero - Global Skill Slot Pack
addappid(1555852) -- Incremental Epic Hero - Premium Nitro Pack
addappid(1555853) -- Incremental Epic Hero - Monster Gold Cap Pack
addappid(1580930) -- Incremental Epic Hero - IEH2 Support Pack