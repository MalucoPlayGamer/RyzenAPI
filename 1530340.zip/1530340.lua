-- Lua provided by SkyAPI 
-- Game: Incremental Epic Hero
addappid(1530340)
addappid(1530341, 1, "02de71228eb52224216364767c0e607d40a99a08843a4578d189f7910e8e3da6")
addappid(1530342, 1, "8b0ed05666219d5dd243e8f037da262cbf80924847efdad8b6c57ab3b2e41c65")
