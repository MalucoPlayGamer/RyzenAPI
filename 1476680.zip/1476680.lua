-- Lua provided by RyzenAPI
-- Game: addappid(1476680)

-- MAIN APPLICATION
addappid(1476680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476681, 1, "63a4c48347c3e464c7aa29705bdcf4b31ecfac6da8188a30d8719dcc6fbdf760")
