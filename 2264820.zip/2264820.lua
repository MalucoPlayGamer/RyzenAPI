-- Lua provided by RyzenAPI
-- Game: The Road To Harvest: Food From Across The Ocean

-- MAIN APPLICATION
addappid(2264820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264821, 1, "2605261abac7a7b76cf13babce228cc49a83b5747eddd8123f87777f997c6976")
addappid(2264822, 1, "77ff33b7e3d28ef24134016aded827131eb45b34f0b81a5e92e5e6d28dd0de18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
