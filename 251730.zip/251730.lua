-- Lua provided by RyzenAPI
-- Game: Legend of Grimrock 2

-- MAIN APPLICATION
addappid(251730)

-- MAIN APP DEPOTS / PACKAGES
addappid(251731, 1, "9eb6976ef8121eb22a66cf7637f46bf150604d67f3b00c507a57396e4df473b8")
addappid(251732, 1, "5c874825fa53d3804870cfcfd2c68930e4c97d983477116985948af69263b897")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
