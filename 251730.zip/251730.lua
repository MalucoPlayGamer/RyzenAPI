-- Lua provided by RyzenAPI 
-- Game: Legend of Grimrock 2
addappid(251730)
addappid(251731, 1, "9eb6976ef8121eb22a66cf7637f46bf150604d67f3b00c507a57396e4df473b8")
addappid(251732, 1, "5c874825fa53d3804870cfcfd2c68930e4c97d983477116985948af69263b897")
