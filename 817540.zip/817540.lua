-- Lua provided by RyzenAPI
-- Game: SpellForce 3: Soul Harvest

-- MAIN APPLICATION
addappid(817540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(817541, 1, "f6d9aac4ffbfa6cb4a3ca69203948e45b6fa1f24d662d0ab9e794cb8d5e56eaa")
addappid(817542, 1, "edf26b51fa35b94f0bccaac8b01ab1244eff399971e535ca85ad2046122534c6")
addappid(817544, 1, "9f1b59eba57170e4d0fce28dadd99a9d5c33b50a0cd690a0c5237ffb89b9ac3e")
addappid(1093260, 0, "89df9a57631c1625fac25cb39bd9a9c5273e02309f53eeb8f3856830eae32138")
addappid(1161740, 0, "b970511d4666d1ef87faf2d22a19c7c15e0fab06555a12c7e43e8b0e810f4358")

