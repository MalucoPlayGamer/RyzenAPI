-- Lua provided by RyzenAPI
-- Game: AppID 881230

-- MAIN APPLICATION
addappid(881230)
-- Game: addappid(881230)

-- MAIN APP DEPOTS / PACKAGES
addappid(881231, 1, "9d2d74c8146956ebbdc0871e8279b00692eb49826769c8b92c4517d0c3def634")
