-- Lua provided by RyzenAPI
-- Game: The Complex: Found Footage

-- MAIN APPLICATION
addappid(1942120)
-- Game: addappid(1942120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942121, 1, "64a251eca9514673ecddef18764f5530d62027957829514c28e1721a95eb3f19")
