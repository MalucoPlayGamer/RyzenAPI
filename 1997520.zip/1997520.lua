-- Lua provided by RyzenAPI
-- Game: Futanari Sex - The New Boss

-- MAIN APPLICATION
addappid(1997520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997521, 1, "2234cef33f1b6a69061c6a08b5abb5bb33fdfb9be270c4fc1768c354f7f30689")

