-- Lua provided by RyzenAPI
-- Game: Virush

-- MAIN APPLICATION
addappid(617060)

-- MAIN APP DEPOTS / PACKAGES
addappid(617061,0,"274f93ce047958edffab448a75beec1eda76f95cc9d0f0d79c5d5f9cd4cb50c8")

