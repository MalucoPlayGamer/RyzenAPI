-- Lua provided by RyzenAPI
-- Game: Game: VED Demo

-- MAIN APPLICATION
addappid(2085110)
-- Game: addappid(2085110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085111, 1, "d11fc3768d1a70ecfc786a0cb5205062b008e311da40fb938c647c57bb007ac5")
