-- Lua provided by RyzenAPI 
-- Game: Bumballon
addappid(1750490)
addappid(1750491, 1, "41520a81e1aabf108a02ff0b1edbb947ffb6d7ec7a2e4d5fbded4b586abbee9b")
