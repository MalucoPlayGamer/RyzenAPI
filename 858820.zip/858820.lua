-- Lua provided by RyzenAPI
-- Game: Tribes of Midgard

-- MAIN APPLICATION
addappid(858820)

-- MAIN APP DEPOTS / PACKAGES
addappid(858821, 1, "396cc73b4dbae399058e283549bd4e3a305081d85808c286ab9989f1c9d0bade")

