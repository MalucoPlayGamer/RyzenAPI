-- Lua provided by RyzenAPI
-- Game: Tribes of Midgard

-- MAIN APPLICATION
addappid(858820)
addappid(1663080)
addappid(1669720)

-- MAIN APP DEPOTS / PACKAGES
addappid(858821,0,"396cc73b4dbae399058e283549bd4e3a305081d85808c286ab9989f1c9d0bade")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
