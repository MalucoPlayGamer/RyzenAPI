-- Lua provided by RyzenAPI
-- Game: String Tyrant

-- MAIN APPLICATION
addappid(1286980)
-- Game: addappid(1286980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286981, 1, "85642b3781601d0ea98e6167749dbe59789a0f5fae8262d8abe3c47888e21fbb")
addappid(1286982, 1, "c85be2c6f1af607416701d7adcfb861858aedc029417532092200c5e0fc19303")
