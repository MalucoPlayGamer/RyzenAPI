-- Lua provided by RyzenAPI
-- Game: addappid(1266800)

-- MAIN APPLICATION
addappid(1266800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266801, 1, "4ef1b0a2f158c7be05d8931db1f56fcd106c126b082d1ee3fdb383cf16a899b4")
