-- Lua provided by SkyAPI 
-- Game: AppID 1266800
addappid(1266800)
addappid(1266801, 1, "4ef1b0a2f158c7be05d8931db1f56fcd106c126b082d1ee3fdb383cf16a899b4")
