-- Lua provided by RyzenAPI
-- Game: Seen

-- MAIN APPLICATION
addappid(1069740)
-- Game: addappid(1069740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069741, 1, "3d9028c6042daaad0dc99c21300723e0f0a22db07a393d2f1e04b940fdda054b")
