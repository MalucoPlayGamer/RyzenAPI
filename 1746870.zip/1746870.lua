-- Lua provided by RyzenAPI
-- Game: Serene Asylum

-- MAIN APPLICATION
addappid(1746870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1746871, 1, "d4420325d17bfe1d8baaeb75eaef06d5306967950b9bf196f96cdc0a1f5d3ddc")

