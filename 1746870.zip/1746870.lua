-- Lua provided by RyzenAPI
-- Game: Game: Serene Asylum

-- MAIN APPLICATION
addappid(1746870)
-- Game: addappid(1746870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746871, 1, "d4420325d17bfe1d8baaeb75eaef06d5306967950b9bf196f96cdc0a1f5d3ddc")
