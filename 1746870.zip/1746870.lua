-- Lua provided by SkyAPI 
-- Game: Serene Asylum
addappid(1746870)
addappid(1746871, 1, "d4420325d17bfe1d8baaeb75eaef06d5306967950b9bf196f96cdc0a1f5d3ddc")
