-- Lua provided by RyzenAPI
-- Game: addappid(916630)

-- MAIN APPLICATION
addappid(916630)

-- MAIN APP DEPOTS / PACKAGES
addappid(916631, 1, "7030d377bef5d6825b3f90ce07f9fcb9f35bad5c60101f8708ffa7751f9b17ac")
