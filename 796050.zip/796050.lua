-- Lua provided by RyzenAPI
-- Game: The Agency of Anomalies: Mind Invasion Collector's Edition

-- MAIN APPLICATION
addappid(796050)

-- MAIN APP DEPOTS / PACKAGES
addappid(796051,0,"bacebc033f37faff98828195d11e3bd76dbf6cf22835e7a6f964d522f5ba0a3f")

