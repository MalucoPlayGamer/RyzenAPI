-- Lua provided by SkyAPI 
-- Game: AppID 1092430
addappid(1092430)
addappid(1092431, 1, "38b767149be746fc883346561319cd03325549f148e20049c439ea5b91facfcd")
