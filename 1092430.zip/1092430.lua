-- Lua provided by RyzenAPI
-- Game: Budget Cuts 2: Mission Insolvency

-- MAIN APPLICATION
addappid(1092430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092431, 1, "38b767149be746fc883346561319cd03325549f148e20049c439ea5b91facfcd")
