-- Lua provided by RyzenAPI
-- Game: Game: Beard Blade

-- MAIN APPLICATION
addappid(1546940)
-- Game: addappid(1546940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546941, 1, "7da984a8b78e6eadf9145cfe279f6559150cea5726eb9cea03755d20ef61b8fe")
