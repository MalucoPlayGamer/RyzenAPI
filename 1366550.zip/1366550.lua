-- Lua provided by RyzenAPI
-- Game: addappid(1366550)

-- MAIN APPLICATION
addappid(1366550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366551, 1, "4b738ec78a895d17c3434b69047f18bcea821e266fe692650aa57de68811b8ef")
