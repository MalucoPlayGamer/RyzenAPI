-- Lua provided by RyzenAPI
-- Game: 2460130

-- MAIN APPLICATION
addappid(2460130)
-- Game: addappid(2460130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460131, 1, "ba74027a5588542cc8cca5e583fad278b2e7d8053ff4bb18ade19d2a0d46487b")
