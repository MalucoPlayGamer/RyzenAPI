-- Lua provided by RyzenAPI
-- Game: Teenage Mutant Ninja Turtles: Mutants Unleashed

-- MAIN APPLICATION
addappid(2460130)
addappid(2885730)
addappid(2885740)
addappid(2885750)
addappid(2885760)
addappid(2885790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460131, 1, "ba74027a5588542cc8cca5e583fad278b2e7d8053ff4bb18ade19d2a0d46487b")

