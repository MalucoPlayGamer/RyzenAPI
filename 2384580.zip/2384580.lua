-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS: ORIGINS

-- MAIN APPLICATION
addappid(3319840)
addappid(3319850)
addappid(3319860)
addappid(3319870)
addappid(3319880) -- DYNASTY WARRIORS ORIGINS - Official Book  Original Soundtrack (Digital Edition)
addappid(3319890)
addappid(3319940)
addappid(4038930)
addappid(4101630)
-- addappid(2530290) -- Depot 2530290 (empty depot)
-- addappid(3319900)
-- addappid(3319910)
-- addappid(3319920)
-- addappid(3319930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(2384580, 1, "a48f892e064b01728580d88a2c13d6a003d87d467d7b5a16703684926b74965f") -- DYNASTY WARRIORS: ORIGINS
addappid(2384581, 1, "c9bfe8a78dc43f75438b3a8e602c7a322b0b53418f80be108058121a71371130") -- Depot 2384581
addappid(3319840, 1, "e3daad5e8a9c79487f8ea299232fe177f346a535339aced3dbb44b4123959142") -- DYNASTY WARRIORS ORIGINS - Protagonists Costume Nameless Warrior Garb - Depot 3319840
addappid(3319850, 1, "95133ff39c5da8ae0536933d236bb7eab7c1df24a6fedc606bcf5d0867c1a016") -- DYNASTY WARRIORS ORIGINS - Early Works Soundtrack Collection (Digital Edition) - Depot 3319850
addappid(3319860, 1, "eb5c039bb499de6dea3bb580083c831393d697ff12404bae8b7ffcc0d8fe9f28") -- DYNASTY WARRIORS ORIGINS - Official Book (Digital Edition, Japanese version) - Depot 3319860
addappid(3319870, 1, "69380b72ac8cb5b3f7914bbb0e828d1529ef6b2a20076ceb73945c656515e5c7") -- DYNASTY WARRIORS ORIGINS - Original Soundtrack (Digital Edition) - Depot 3319870
addappid(3319890, 1, "ee47966cbf4e985ece4730ea8e94a7766202486517e1dba9de172b6fe849760d") -- DYNASTY WARRIORS ORIGINS - Letters - Depot 3319890
addappid(3319940, 1, "3a41ae63aea1d4d9ba069358a1159daa92ead59d2790df626c089512e6018c1f") -- DYNASTY WARRIORS ORIGINS - ICHIRAN Noodles - Depot 3319940
addappid(4038930, 1, "f9f14de8b63c682e209ed7e0b885d5abd784ee5f1f3b08a333eb5902acf60692") -- DYNASTY WARRIORS ORIGINS Visions of Four Heroes - Depot 4038930
addappid(4101630, 1, "9e59d656348d3145eb23e69ece591c42ff3bc4b295de26c1d672729625f07fae") -- DYNASTY WARRIORS ORIGINS - Protagonists Costume Yellow Turban Attire - Depot 4101630
addtoken(3319840, "8824614407371289400")
addtoken(3319850, "10944105112804011624")
addtoken(3319860, "525880456765100502")
addtoken(3319870, "1595971489372741222")
addtoken(3319890, "4925446025434514146")
