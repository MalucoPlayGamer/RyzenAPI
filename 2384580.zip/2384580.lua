-- Lua provided by RyzenAPI
-- Game: addappid(2384580)

-- MAIN APPLICATION
addappid(2384580)
addappid(2530290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384581, 1, "c9bfe8a78dc43f75438b3a8e602c7a322b0b53418f80be108058121a71371130")
