-- Lua provided by RyzenAPI
-- Game: AppID 466560

-- MAIN APPLICATION
addappid(466560)
addappid(820561)

-- MAIN APP DEPOTS / PACKAGES
addappid(466561, 1, "073598adfc95cad9b9866fb7b6625dc6ab9ff54d5f00dff91733906ab3da0042")
addappid(466562, 1, "18aa806b07e8263d3ddfb7adfef61370fec1d963ccdac5661cc60635dd17251c")
addappid(466563, 1, "7ca18b39eccf8746ad6f9eb347ba3aa9f34b7a84457dd1f68330df695df5613f")
addappid(466564, 1, "9dc832b17369b422c11784a8553ad9101ecabd9fbc8ae4f00a2011736317dc31")
addappid(466565, 1, "bb7151f689032a72537d03a88738c298310558b9b87554aa697a430b3d35ae87")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(820560)
addappid(888650)
addappid(971630)
addappid(1036760)
addappid(1088640)
addappid(1223060)
addappid(1401490)
addappid(1644210)
addappid(1876990)
addappid(2138500)
addappid(2228200)
addappid(2515460)
addappid(2658730)
addappid(2946220)
addappid(3352480)
addappid(3691650)
