-- Lua provided by RyzenAPI
-- Game: 3314120

-- MAIN APPLICATION
addappid(3314120)
-- Game: addappid(3314120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3314123,0,"0af055f4d23b63876a5c4549ca547a2f1ad48a6ba4affe67d15135d99fb3e220")
