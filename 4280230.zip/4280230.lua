-- Lua provided by RyzenAPI
-- Game: Super Wash Simulator

-- MAIN APPLICATION
addappid(4280230)

-- MAIN APP DEPOTS / PACKAGES
addappid(4280231,0,"a5f4837f3836f9bce1f412b455bebfe38730c6851fe8dc41393feb1606e9e45a")

