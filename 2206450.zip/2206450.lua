-- Lua provided by RyzenAPI
-- Game: 2206450

-- MAIN APPLICATION
addappid(2206450)
-- Game: addappid(2206450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206451, 1, "02f448b9bb901e6d06b3e316022978fda5c5dd5fbfb4a28501b9fbcecb7c99d7")
