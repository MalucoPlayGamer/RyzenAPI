-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Dark Fantasy Resource Pack

-- MAIN APPLICATION
addappid(1351030)
-- Game: addappid(1351030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351030,0,"a08e6fd8fa4a479fd7a743554ccb0e6d7ef04262ab4b54472e5717debafff774")
