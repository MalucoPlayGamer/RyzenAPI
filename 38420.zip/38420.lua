-- Lua provided by RyzenAPI
-- Game: Fallout Tactics: Brotherhood of Steel

-- MAIN APPLICATION
addappid(38420)
addappid(228981)
addappid(229003)

-- MAIN APP DEPOTS / PACKAGES
addappid(38421, 1, "3c59b3a57bb592dfafa5efd40b04edcfc40894051e736ea3f56710d3ac4b3dca")
addappid(38422, 1, "5bfe7489ada702d4ff97c803a9aab95116c53da4884e19741865964c98c378d3")
addappid(38423, 1, "0c06cf1646d49b310fc62d9ddbabecc5cf480ed6cbde716ad608e15c98208fa9")
addappid(38424, 1, "fecde89bb824bbefabb1837dc231d5fa8738403a3c91c2b55b52b198d35cf00c")
addappid(38425, 1, "f236fe4209a34b19464954db73b0f80681b39172bb52a85a57750f4db2bab93b")
addappid(38426, 1, "784b4c04d17ea543dca2a2e450a64b39425812942e0455d22baa3580bb4950f5")
addappid(38427, 1, "3d73157d9e861da58909e20c4903afcb6c5fc77ce3a2fb68ee42134f036e5684")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
