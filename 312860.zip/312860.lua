-- Lua provided by RyzenAPI
-- Game: Defense Grid 2: Steam Special Edition Upgrade

-- MAIN APPLICATION
addappid(312860)

-- MAIN APP DEPOTS / PACKAGES
addappid(312861, 1, "64c6fcd0371663c5affd39da66f849ebff07ba078c1f50c7c39cf80e72135236")
addappid(312862, 1, "ed9a44a3094da778b280d3421fa743021dab8853ab90135f48d2f2e8c047cf83")
addappid(312863, 1, "21de05b4eb40ffc66bdce8814b4e4501e4d9071cf2b8974dd0a2b6f6c37b9ac1")

