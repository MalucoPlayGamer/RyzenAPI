-- Lua provided by RyzenAPI
-- Game: Game: The Caretaker

-- MAIN APPLICATION
addappid(1399620)
-- Game: addappid(1399620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399621, 1, "37416405e27bab9f01e6999158831d66997dc10ddc62b6665e79d739b15ddff5")
