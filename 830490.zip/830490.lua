-- Lua provided by RyzenAPI
-- Game: Achievement Lurker: You are going to have to work for these nuts

-- MAIN APPLICATION
addappid(830490)

-- MAIN APP DEPOTS / PACKAGES
addappid(830491, 1, "afbf5852d1236b239cd5fde492718680cdd0cbbf8af0bdcc47405d1b64816742")

