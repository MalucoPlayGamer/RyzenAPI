-- Lua provided by RyzenAPI 
-- Game: AppID 830490
addappid(830490)
addappid(830491, 1, "afbf5852d1236b239cd5fde492718680cdd0cbbf8af0bdcc47405d1b64816742")
