-- Lua provided by RyzenAPI
-- Game: Reclaim The Sea

-- MAIN APPLICATION
addappid(2096860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096861, 1, "24446ffca57ab3304efe64361d4bd2c06259ab5405488e9da7ab5357a3ebb86d")
