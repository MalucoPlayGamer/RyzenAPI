-- Lua provided by RyzenAPI
-- Game: Police Shootout

-- MAIN APPLICATION
addappid(1279240)
-- Game: addappid(1279240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279241, 1, "6c7e2adf80892dbf61707bba1a31cf697afdce06b91b65023410fbd01b7f2398")
