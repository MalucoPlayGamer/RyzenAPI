-- Lua provided by RyzenAPI
-- Game: Police Shootout

-- MAIN APPLICATION
addappid(1279240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1279241, 1, "6c7e2adf80892dbf61707bba1a31cf697afdce06b91b65023410fbd01b7f2398")

