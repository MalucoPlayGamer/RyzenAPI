-- Lua provided by RyzenAPI
-- Game: addappid(334750)

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228990)
addappid(334750)
addappid(334751)
addappid(334752)
addappid(334753)
addappid(334754)
addappid(334755)
addappid(334756)
addappid(334757)
addappid(334758)
addappid(334759)
addappid(360860)

-- MAIN APP DEPOTS / PACKAGES
addappid(375470,0,"81b44f32a3e2ff73a3c65cd32ca0996bed4c60b9aece8105f7c7e452cb652aca")
addtoken(334750,932265690087102853)
