-- Lua provided by RyzenAPI
-- Game: 278910

-- MAIN APPLICATION
addappid(278910)
addappid(278913)
addappid(278914)
addappid(278915)
addappid(278919)
addappid(278920)
addappid(278921)
-- Game: addappid(278910)

-- MAIN APP DEPOTS / PACKAGES
addappid(278916,0,"a225e59fabf525f1c00691744ff0b027784ba790fd52459b28068968ace977f2")
addappid(278917,0,"ce289d7fe48abea9c1a9eb4d9f01e92ff740d6b32d60dbcb4a1b2533632ccf5f")
addappid(278918,0,"79acd990aa221c0e8338d232d425130484c74b28964bc2adeaf078848d814912")
