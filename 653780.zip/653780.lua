-- Lua provided by RyzenAPI
-- Game: 653780

-- MAIN APPLICATION
addappid(653780)
-- Game: addappid(653780)

-- MAIN APP DEPOTS / PACKAGES
addappid(653781, 1, "88ed29df703cee4e624a15cd6481c2f53ab7e2329c435e75d3264d40ea22609e")
