-- Lua provided by RyzenAPI
-- Game: Defend Your Kingdom

-- MAIN APPLICATION
addappid(653780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(653781, 1, "88ed29df703cee4e624a15cd6481c2f53ab7e2329c435e75d3264d40ea22609e")
