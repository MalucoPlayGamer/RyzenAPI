-- Lua provided by RyzenAPI
-- Game: 3349930

-- MAIN APPLICATION
addappid(3349930)
-- Game: addappid(3349930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349931, 1, "a48d412ef740ea5135e2adf8cc32d5c1ffd23e0cf2b2a5d69f56d17e976d50f9")
