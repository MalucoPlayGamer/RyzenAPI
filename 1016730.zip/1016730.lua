-- Lua provided by RyzenAPI
-- Game: Deck of Ashes

-- MAIN APPLICATION
addappid(1016730) -- Deck of Ashes
addappid(1066120)
addappid(1066121)
addappid(1066122)
addappid(1155280) -- Deck of Ashes - Skin pack
addappid(1337470)
addappid(1337490)
addappid(1684600) -- Deck of Ashes - Tome of Dimensions

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1016731, 1, "2642a4cca1e180519a9b2838383fd35473c1d563dc5657cac08d19b4629803d0") -- Deck of Ashes Content
addappid(1016732, 1, "6f38a190b4a3d4b5799f4fe91f4cbff84496b7a6efb03541b98e494a12dd70ec") -- Хранилище Deck of Ashes Mac
addappid(1066120, 1, "440b9ffd0f213b364f4b8dabd8dea2cd74ebebf8c799517e7744a2164d68364d") -- Deck of Ashes - Original Soundtrack - Хранилище Deck of Ashes - Original Soundtrack (1066120)
addappid(1066121, 1, "56557a09fc0e1b0fec53fa3e621fab52465ff9c509cccf998f636fdc4a11410f") -- Deck of Ashes - Digital Expanded Artbook  - Хранилище Deck of Ashes - Digital Art Book (1066121)
addappid(1066122, 1, "d6396b279b77c8b412b53c84478faf4ba09dd0f6de5a5a58c427053d12db03f7") -- Deck of Ashes - Print-Ready Posters - Хранилище Deck of Ashes - Print-Ready Posters (1066122)
addappid(1337470, 1, "19aed3a1f6a20150bdf311516fb5c7f239875420a0ce7dc0db8e0b977da99885") -- Deck of Ashes - HD Wallpapers - Хранилище Deck of Ashes - Digital wallpaper (1337470)
addappid(1337490, 1, "997fb1687b0baa0ee8e85bb2a1f930c4e97d1309555d0f74397ed5246a47980c") -- Deck of Ashes - Gratitude Card from Dev team - Хранилище Deck of Ashes - Developers letter (1337490)

