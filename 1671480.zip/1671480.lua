-- Lua provided by RyzenAPI 
-- Game: ABRISS - build to destroy
addappid(1671480)
addappid(1671481, 1, "671a737996ab5fae24142fb3ef2f91ce2c41926f43aeb6baf6899b434274f86b")
