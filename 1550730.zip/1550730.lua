-- Lua provided by RyzenAPI
-- Game: Ikonei Island: An Earthlock Adventure

-- MAIN APPLICATION
addappid(1550730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550731, 1, "218619bb271620fc73c2fd6fdf292caafb3d9f5a77df17f59e7baf8ef2467253")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2841850)
addappid(2845680)
addappid(2869700)
