-- Lua provided by RyzenAPI
-- Game: addappid(1550730)

-- MAIN APPLICATION
addappid(1550730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550731, 1, "218619bb271620fc73c2fd6fdf292caafb3d9f5a77df17f59e7baf8ef2467253")
