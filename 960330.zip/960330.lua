-- Lua provided by RyzenAPI
-- Game: Game: AppID 960330

-- MAIN APPLICATION
addappid(960330)
-- Game: addappid(960330)

-- MAIN APP DEPOTS / PACKAGES
addappid(960331, 1, "c4130171fd598404290edd57abad9487976f701a90f4fa995d236737a8484216")
