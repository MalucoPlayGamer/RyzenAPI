-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Starfighter™

-- MAIN APPLICATION
addappid(32350)

-- MAIN APP DEPOTS / PACKAGES
addappid(32351, 1, "33a38e803deeb8e9ee7b67089502525661fc9beb7d9d1a8345cb977f2a97fa1d")
addappid(32352, 1, "7cd87cb9d26ccaf2a3ef91fe5cbd50ca7a6cd0fd082242d4c4d4e80e068b93c2")
addappid(32353, 1, "0414e3644cc42713d61c0b00fefc02eb89d02ab8c5e613f147cab7861e58186d")
addappid(32354, 1, "ac59093b1d35c2d1f036efa45af78a6c357c65b6d9895f474391bede10165264")
addappid(32355, 1, "bdeb2af40141f1e65d193c2caea1de434675714c5445ffd8fdf8a0da2c23af1c")
addappid(32356, 1, "45fe2d69380362a00cbcfa5ed3fec57bc3207d25b6d438b34394382b106646a8")

