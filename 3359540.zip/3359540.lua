-- Lua provided by RyzenAPI
-- Game: Sex Supermarket

-- MAIN APPLICATION
addappid(3359540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3359541, 1, "49821c11a8dd51daeecd6efbac21ff83f0b8fdaf91bcc03a7dd8f86ab93ec3c4")

