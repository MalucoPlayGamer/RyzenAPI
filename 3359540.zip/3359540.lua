-- Lua provided by RyzenAPI
-- Game: Game: Sex Supermarket

-- MAIN APPLICATION
addappid(3359540)
-- Game: addappid(3359540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359541, 1, "49821c11a8dd51daeecd6efbac21ff83f0b8fdaf91bcc03a7dd8f86ab93ec3c4")
