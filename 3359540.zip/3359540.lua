-- Lua provided by RyzenAPI 
-- Game: Sex Supermarket
addappid(3359540)
addappid(3359541, 1, "49821c11a8dd51daeecd6efbac21ff83f0b8fdaf91bcc03a7dd8f86ab93ec3c4")
