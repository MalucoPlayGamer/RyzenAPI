-- Lua provided by RyzenAPI
-- Game: Seek Girl Ⅱ

-- MAIN APPLICATION
addappid(1149660)
-- Game: addappid(1149660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149661, 1, "5eaff49e16659003bb3b7f72329e6b2c58193f6f261904b2a5e7ff7ae57cc1e5")
addappid(1163330, 0, "4813e5c81a54ce05e6c5b70b5f95864dbbc831deb7c6548bbebb95df076733f3")
addappid(1213540, 0, "a2ac22db77fc6d08d33f4b35deb3bef34f26239a7f1eb7fbfea9e63b575099a1")
