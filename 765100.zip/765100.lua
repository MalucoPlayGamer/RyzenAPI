-- Lua provided by RyzenAPI 
-- Game: AppID 765100
addappid(765100)
addappid(765101, 1, "982aee3cc0309870c3f259d2b3577203c918af99406df1981b8f214ae220ebbf")
