-- Lua provided by RyzenAPI
-- Game: AppID 765100

-- MAIN APPLICATION
addappid(765100)
-- Game: addappid(765100)

-- MAIN APP DEPOTS / PACKAGES
addappid(765101, 1, "982aee3cc0309870c3f259d2b3577203c918af99406df1981b8f214ae220ebbf")
