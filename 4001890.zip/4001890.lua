-- Generated with Luie @ https://lua.tools/
-- 4001890 - How to Fish
-- Generated 2026-08-21 20:59:11 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4001890)

-- Main Depots
addappid(4001891, 1, "b5c8ad37740a8db6d370a6934bf203cfaeb3343003e6277ffc96c63f4df2b7ca")
setManifestid(4001891, "5639719782218182861", 641712844)
