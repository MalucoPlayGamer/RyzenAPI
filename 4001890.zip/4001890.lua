-- Lua provided by RyzenAPI
-- Game: How to Fish

-- MAIN APP DEPOTS / PACKAGES
addappid(4001890, 1, "ea507a303e64f6def87ca6899e164350a1a1fb3a4b109542949345340ba47227")
addappid(4001891, 1, "b5c8ad37740a8db6d370a6934bf203cfaeb3343003e6277ffc96c63f4df2b7ca")

