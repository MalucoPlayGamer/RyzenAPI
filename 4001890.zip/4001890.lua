-- Generated with Luie @ https://lua.tools/
-- 4001890 - How to Fish
-- Generated 2026-08-28 00:41:23 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4001890, 1, "ea507a303e64f6def87ca6899e164350a1a1fb3a4b109542949345340ba47227")

-- Main Depots
addappid(4001891, 1, "b5c8ad37740a8db6d370a6934bf203cfaeb3343003e6277ffc96c63f4df2b7ca")
setManifestid(4001891, "5701625971253625176", 642757891)
