-- Lua provided by RyzenAPI
-- Game: How to Fish

-- MAIN APPLICATION
addappid(4001890)

-- MAIN APP DEPOTS / PACKAGES
addappid(4001891, 1, "b5c8ad37740a8db6d370a6934bf203cfaeb3343003e6277ffc96c63f4df2b7ca")

