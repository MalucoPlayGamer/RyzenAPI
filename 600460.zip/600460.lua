-- Lua provided by RyzenAPI
-- Game: Dustwind

-- MAIN APPLICATION
addappid(600460)

-- MAIN APP DEPOTS / PACKAGES
addappid(600461, 1, "a8ab7eaa8a346366a62f98324aa42fc47810de3eddadec629dd8929afc9248f0")

