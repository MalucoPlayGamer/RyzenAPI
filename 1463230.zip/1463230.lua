-- Lua provided by RyzenAPI
-- Game: Beat Saber - BTS - "Dionysus"

-- MAIN APPLICATION
addappid(1463230)
-- Game: addappid(1463230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463231, 1, "43ed58427f50deb053b0fd86fcf268f81db89d40d5ccd5d4414966cfcfdc9c3a")
