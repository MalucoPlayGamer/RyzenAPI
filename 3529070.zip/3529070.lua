-- Lua provided by RyzenAPI
-- Game: addappid(3529070)

-- MAIN APPLICATION
addappid(3529070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3529070,0,"b026350733364aae827ef7a7c5167c3ee7ee13282002f1996ed6bd765db6bc23")
