-- Lua provided by RyzenAPI
-- Game: Into the M.A.W.

-- MAIN APPLICATION
addappid(2925490) -- Into the M.A.W.

-- MAIN APP DEPOTS / PACKAGES
addappid(2925491, 1, "f74e733232649250c5a004da60db7e723a2736cc91fa4c3bdf0df838d69576d1") -- Depot 2925491
