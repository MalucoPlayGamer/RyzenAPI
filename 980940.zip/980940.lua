-- Lua provided by RyzenAPI
-- Game: My Little Blacksmith Shop

-- MAIN APPLICATION
addappid(980940)

-- MAIN APP DEPOTS / PACKAGES
addappid(980942,0,"30404ab3164bd60f33290dbab3496be4700278cebdf2a5deeab80214da9b0f81")
