-- Lua provided by RyzenAPI
-- Game: My Little Blacksmith Shop

-- MAIN APPLICATION
addappid(980940)

-- MAIN APP DEPOTS / PACKAGES
addappid(980942,0,"30404ab3164bd60f33290dbab3496be4700278cebdf2a5deeab80214da9b0f81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
