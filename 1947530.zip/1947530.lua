-- Lua provided by RyzenAPI
-- Game: Fidget Spinner RPG

-- MAIN APPLICATION
addappid(1947530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947531, 1, "0ef3620e8b2a9cc80d08ece39c228181e9c4bfd8bc73726fd833cd3fab243ec6")

