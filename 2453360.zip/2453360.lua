-- Lua provided by SkyAPI 
-- Game: Cluckmech Oasis
addappid(2453360)
addappid(2453361, 1, "c28f6652a67eef84e3fb87549167532fdbb74636978127507da233265dfee2bd")
addappid(2453362, 1, "f1094c165f85c9d4a1114a63db62848ece4273c6f60268c0ca82e3c6303929fd")
addappid(3347900)
