-- Lua provided by RyzenAPI
-- Game: chess

-- MAIN APPLICATION
addappid(1758330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758331, 1, "072debb8c9710f31610769b5c4c6a1a1fb9dc3515ccbca7551562ee283c13482")
