-- Lua provided by RyzenAPI
-- Game: AppID 2566210

-- MAIN APPLICATION
addappid(2566210)
-- Game: addappid(2566210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566211, 1, "43970b3988a7ee7cecb474a513a6b7ff1daf229f1d90e72370f30c4b94b0aa46")
