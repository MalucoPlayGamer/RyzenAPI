-- Lua provided by RyzenAPI
-- Game: addappid(1589390)

-- MAIN APPLICATION
addappid(1589390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589391, 1, "e4bf16d48ec926d40e8f575c25b1b52783f6d83647689c02e10ac2fac0d2f54d")
