-- Lua provided by RyzenAPI
-- Game: Pine Harbor

-- MAIN APPLICATION
addappid(2448030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448031, 1, "3ba584ce0b7eaee4557b7b3d2a3198e97054b14612bda301cf0136686c7879d0")
