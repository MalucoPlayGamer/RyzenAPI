-- Lua provided by RyzenAPI
-- Game: 3748790

-- MAIN APPLICATION
addappid(3748790)
-- Game: addappid(3748790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3748791, 1, "fcac35d1de655a1e0e2a20401ec5ef34281a505a30cefac32f83e1dcd3d53fe1")
