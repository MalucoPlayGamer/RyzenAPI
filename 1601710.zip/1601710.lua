-- Lua provided by RyzenAPI
-- Game: addappid(1601710)

-- MAIN APPLICATION
addappid(1601710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601711, 1, "4dabdf7807cff2bed7fd7cee387135ba44e5d23d98eaa21f7a12245ecf1d1a68")
