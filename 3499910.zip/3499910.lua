-- Lua provided by RyzenAPI
-- Game: Dachs Hunter

-- MAIN APPLICATION
addappid(3499910)
-- Game: addappid(3499910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499911, 1, "fcbeef766829e111be7ca4dc24f47b4336a65916bf79e340a337a111d80b8a5b")
