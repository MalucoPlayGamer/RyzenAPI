-- Lua provided by RyzenAPI
-- Game: addappid(2754830)

-- MAIN APPLICATION
addappid(2754830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754831, 1, "eb46028169cf9966707797dbb9162fce3d569f8b57410a5c653cf47c1e413e5b")
