-- Lua provided by RyzenAPI
-- Game: Screamer

-- MAIN APPLICATION
addappid(697580)

-- MAIN APP DEPOTS / PACKAGES
addappid(697582,0,"bf936b435313843c59abe246dd8dbd26b15483501bbb0938e3750c8b65fe5f59")
