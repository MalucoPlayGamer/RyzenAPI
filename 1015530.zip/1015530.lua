-- Lua provided by RyzenAPI
-- Game: 1015530

-- MAIN APPLICATION
addappid(1015530)
-- Game: addappid(1015530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015531, 1, "50e3683d02b12344bd551c41d120dada6e84d0fde17d78ef7ceee1335c1cfcf2")
