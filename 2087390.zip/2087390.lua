-- Lua provided by SkyAPI 
-- Game: Neon Fighter
addappid(2087390)
addappid(2087391, 1, "4ca0c5b27395a66119089d3f2819ae9060384fb48693963f438201005a72024e")
