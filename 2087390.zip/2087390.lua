-- Lua provided by RyzenAPI
-- Game: Game: Neon Fighter

-- MAIN APPLICATION
addappid(2087390)
-- Game: addappid(2087390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087391, 1, "4ca0c5b27395a66119089d3f2819ae9060384fb48693963f438201005a72024e")
