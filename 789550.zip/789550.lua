-- Lua provided by RyzenAPI 
-- Game: AppID 789550
addappid(789550)
addappid(789551, 1, "0678791065548a396f6b35cc08d548150c60a1f31fddca512ee8f062df2d5762")
