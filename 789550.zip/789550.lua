-- Lua provided by RyzenAPI
-- Game: 789550

-- MAIN APPLICATION
addappid(789550)
-- Game: addappid(789550)

-- MAIN APP DEPOTS / PACKAGES
addappid(789551, 1, "0678791065548a396f6b35cc08d548150c60a1f31fddca512ee8f062df2d5762")
