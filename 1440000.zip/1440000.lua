-- Lua provided by RyzenAPI
-- Game: addappid(1440000)

-- MAIN APPLICATION
addappid(1440000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440001, 1, "082191e1717b81437130dccd45ebb0ed6d64ff4ed7fed9f6179d76ddc7202bdb")
