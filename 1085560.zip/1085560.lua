-- Lua provided by RyzenAPI
-- Game: Hentai energy II

-- MAIN APPLICATION
addappid(1085560)
-- Game: addappid(1085560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085561, 1, "eea6ec9d7dd5aa31738d722111b8f83663e093ad1506cb8afa8140a8fa3c96cc")
