-- Lua provided by RyzenAPI
-- Game: AppID 1282110

-- MAIN APPLICATION
addappid(1282110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282111, 1, "d4eb58a3128b219b600d14447f31d2ef94be5a4fed135505c5c4b62cd192cbee")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1524860)
addappid(1524861)
addappid(1524862)
