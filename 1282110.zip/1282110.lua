-- Lua provided by SkyAPI 
-- Game: AppID 1282110
addappid(1282110)
addappid(1282111, 1, "d4eb58a3128b219b600d14447f31d2ef94be5a4fed135505c5c4b62cd192cbee")
