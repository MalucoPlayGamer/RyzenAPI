-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Rogue Trader - Lex Imperialis

-- MAIN APPLICATION
addappid(3622820)
-- Game: addappid(3622820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3622821, 1, "734180a123f43796ae882d1d4aff76d40e67dbe95392726ea51c7651634014a1")
