-- Lua provided by RyzenAPI
-- Game: Pesterquest

-- MAIN APPLICATION
addappid(1144030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144031, 1, "c8318cb589a33ab0fe2072722aa200dac9629970b9db6bc7ae35debf6ef72f72")

