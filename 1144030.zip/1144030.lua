-- Lua provided by RyzenAPI
-- Game: 1144030

-- MAIN APPLICATION
addappid(1144030)
-- Game: addappid(1144030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144031, 1, "c8318cb589a33ab0fe2072722aa200dac9629970b9db6bc7ae35debf6ef72f72")
