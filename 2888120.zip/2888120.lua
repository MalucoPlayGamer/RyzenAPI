-- Lua provided by RyzenAPI
-- Game: Auto Clicker

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
addappid(2888120, 1, "7c087240bc727a86581c1634a49b1a840411443674844aa142cd27ab87353386") -- Auto Clicker
addappid(2888121, 1, "b20988ae99c439cd232a80fbd00df8b82fe180c19e0928f2d4aab0308a36e19f") -- Depot 2888121
addappid(2888122, 1, "2c329e38e5bf306bdf8eaec2536ac34c14ec9511dc71015538a16c3f08ce297a") -- Depot 2888122

