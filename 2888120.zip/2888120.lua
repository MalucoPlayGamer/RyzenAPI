-- 2888120's Lua and Manifest Created by Hubcap Manifest
-- Auto Clicker
-- Created: August 16, 2026 at 21:47:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2888120, 1, "7c087240bc727a86581c1634a49b1a840411443674844aa142cd27ab87353386") -- Auto Clicker
-- MAIN APP DEPOTS
addappid(2888121, 1, "b20988ae99c439cd232a80fbd00df8b82fe180c19e0928f2d4aab0308a36e19f") -- Depot 2888121
setManifestid(2888121, "3704021022099455659", 671558722)
addappid(2888122, 1, "2c329e38e5bf306bdf8eaec2536ac34c14ec9511dc71015538a16c3f08ce297a") -- Depot 2888122
setManifestid(2888122, "7264909928769509275", 684317440)
-- SHARED DEPOTS (from other apps)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)