-- Lua provided by RyzenAPI
-- Game: addappid(2888120)

-- MAIN APPLICATION
addappid(2888120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888121, 1, "b20988ae99c439cd232a80fbd00df8b82fe180c19e0928f2d4aab0308a36e19f")
