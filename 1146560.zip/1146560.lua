-- Lua provided by RyzenAPI
-- Game: AppID 1146560

-- MAIN APPLICATION
addappid(1146560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146561, 1, "5d4149adc04480718214ca39aa1e96aa0455f0b20f5d47a80573893f68363393")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
