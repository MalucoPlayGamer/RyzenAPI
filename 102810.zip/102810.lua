-- Lua provided by RyzenAPI
-- Game: Game: Gatling Gears

-- MAIN APPLICATION
addappid(102810)
-- Game: addappid(102810)

-- MAIN APP DEPOTS / PACKAGES
addappid(102811, 1, "8fa3beae0a6c6f6426ff464926c547c0afa75f73517515651ef51fbfddd46d90")
