-- Lua provided by RyzenAPI 
-- Game: Gatling Gears
addappid(102810)
addappid(102811, 1, "8fa3beae0a6c6f6426ff464926c547c0afa75f73517515651ef51fbfddd46d90")
