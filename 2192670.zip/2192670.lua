-- Lua provided by RyzenAPI
-- Game: 2192670

-- MAIN APPLICATION
addappid(2192670)
-- Game: addappid(2192670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192671, 1, "03435df060b604babc9988bf7db75a7149c552d3929d2e52cce96a6b7a8172c1")
