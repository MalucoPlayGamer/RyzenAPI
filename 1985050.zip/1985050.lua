-- Lua provided by RyzenAPI
-- Game: Field of Glory: Kingdoms

-- MAIN APPLICATION
addappid(1985050)
addappid(3297820)
addappid(4056900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1985051, 1, "4163d53617fe646682ace0eb1ac032be866bb8d07f085dedf4c6ab912dab10b9")
addappid(1985052, 1, "2eebd9c2c00f0e7e9ce888badfadd23ebbb9b8d9fa9e67c95cf01156c7abf121")

