-- Lua provided by RyzenAPI
-- Game: Space Armor 2

-- MAIN APPLICATION
addappid(853760)

-- MAIN APP DEPOTS / PACKAGES
addappid(853761,0,"a8a1d2bd7c75873eb223590c124c7c456abf391926dfb1d5a88b003cb0b7e84e")

