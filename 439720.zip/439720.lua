-- Lua provided by RyzenAPI
-- Game: Unending Galaxy

-- MAIN APPLICATION
addappid(439720)

-- MAIN APP DEPOTS / PACKAGES
addappid(439722,0,"de481b1c0d425d7a7d5dbb441409c30b69fbb7583f7f1eb336956f62851a87ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
