-- Lua provided by RyzenAPI
-- Game: addappid(439720)

-- MAIN APPLICATION
addappid(439720)

-- MAIN APP DEPOTS / PACKAGES
addappid(439722,0,"de481b1c0d425d7a7d5dbb441409c30b69fbb7583f7f1eb336956f62851a87ba")
