-- Lua provided by RyzenAPI 
-- Game: AppID 3174700
addappid(3174700)
addappid(3174701, 1, "e732f733b6b6c3af4078bccf3665a065318f2a71be95888abb56ef57c1f98ae6")
