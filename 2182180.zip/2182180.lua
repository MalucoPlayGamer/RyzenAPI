-- Lua provided by RyzenAPI
-- Game: 中国式相亲 Demo

-- MAIN APPLICATION
addappid(2182180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182182,0,"6bb5e498b7d5216bc65e0d6c014cb55b88c6965fcd53e913cb807b09f19c4cd4")

