-- Lua provided by RyzenAPI
-- Game: Game: 6th Floor

-- MAIN APPLICATION
addappid(2968600)
-- Game: addappid(2968600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968601, 1, "14af28541d5bad772626a66bd1d1df556458761344456b4be7fa49963d03f2c5")
