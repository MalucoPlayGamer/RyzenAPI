-- Lua provided by RyzenAPI
-- Game: 6th Floor

-- MAIN APPLICATION
addappid(2968600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2968601, 1, "14af28541d5bad772626a66bd1d1df556458761344456b4be7fa49963d03f2c5")
