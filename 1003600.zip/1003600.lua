-- Lua provided by RyzenAPI
-- Game: NashBored

-- MAIN APPLICATION
addappid(1003600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003601, 1, "7353ae2f0105676cc90e3ae5b135de07287f54bfab44232c01857ee1ae07ecdd")
