-- Lua provided by RyzenAPI
-- Game: GunSuit Guardians

-- MAIN APPLICATION
addappid(2278830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278831, 1, "ad6cb8837069ea6644138a2e7af9b92f501571ccf225117eb4fe32fa8629c986")
