-- Lua provided by RyzenAPI
-- Game: Songbringer

-- MAIN APPLICATION
addappid(367080)
addappid(847540)

-- MAIN APP DEPOTS / PACKAGES
addappid(367081, 1, "33b6703e9911f7705e8c17574244baaef92ff8576d1c43e358106fcf71d1f275")

