-- Lua provided by RyzenAPI
-- Game: AppID 367080

-- MAIN APPLICATION
addappid(367080)
-- Game: addappid(367080)

-- MAIN APP DEPOTS / PACKAGES
addappid(367081, 1, "33b6703e9911f7705e8c17574244baaef92ff8576d1c43e358106fcf71d1f275")
