-- Lua provided by SkyAPI 
-- Game: Domino Simulator
addappid(1246490)
addappid(1246491, 1, "67d923441b4b83c24b8de2731748f12200e6beccb75141eaaa11e6c736155ef1")
