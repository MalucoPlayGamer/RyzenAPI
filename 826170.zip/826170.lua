-- Lua provided by RyzenAPI 
-- Game: Laser Ball
addappid(826170)
addappid(826171, 1, "b554b8d3202b79bb04530ebc5ffad75c9b438e59f16e83e1b70eba143ad046a5")
