-- Lua provided by RyzenAPI
-- Game: 826170

-- MAIN APPLICATION
addappid(826170)
-- Game: addappid(826170)

-- MAIN APP DEPOTS / PACKAGES
addappid(826171, 1, "b554b8d3202b79bb04530ebc5ffad75c9b438e59f16e83e1b70eba143ad046a5")
