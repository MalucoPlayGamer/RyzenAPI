-- Lua provided by RyzenAPI
-- Game: 1031510

-- MAIN APPLICATION
addappid(1031510)
-- Game: addappid(1031510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031511, 1, "e7f11a666207c8b4d689d0d41096268edca6014bd3817d1d2d8ef27f67a6eb34")
