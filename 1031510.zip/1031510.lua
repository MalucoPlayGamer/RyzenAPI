-- Lua provided by RyzenAPI
-- Game: AppID 1031510

-- MAIN APPLICATION
addappid(1031510)
addappid(1126740)
addappid(1128550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1031511, 1, "e7f11a666207c8b4d689d0d41096268edca6014bd3817d1d2d8ef27f67a6eb34")

