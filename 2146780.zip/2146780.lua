-- Lua provided by RyzenAPI
-- Game: Mutagenic Demo

-- MAIN APPLICATION
addappid(2146780)
-- Game: addappid(2146780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146781, 1, "0e17d67845d3607303310400b4b49a81172471cd98b4da0fcd751419bd639d52")
