-- Lua provided by RyzenAPI
-- Game: AppID 603330

-- MAIN APPLICATION
addappid(603330)
-- Game: addappid(603330)

-- MAIN APP DEPOTS / PACKAGES
addappid(603331, 1, "fe75a0c466f72ecfa7e0972d4b0c80ace2574f34665c18652de568362b2fbf5b")
