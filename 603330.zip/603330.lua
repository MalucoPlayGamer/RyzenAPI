-- Lua provided by RyzenAPI
-- Game: Blasted Road Terror

-- MAIN APPLICATION
addappid(603330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(603331, 1, "fe75a0c466f72ecfa7e0972d4b0c80ace2574f34665c18652de568362b2fbf5b")

