-- 2827820's Lua and Manifest Created by Hubcap Manifest
-- The Relic: The First Guardian
-- Created: July 31, 2026 at 00:09:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2827820) -- The Relic: The First Guardian
-- MAIN APP DEPOTS
addappid(2827821, 1, "c3fbbc085fc10ff5dd383b515d99c94bdf739b231d5bd4f68bec099b0b41631c") -- Depot 2827821
setManifestid(2827821, "4550460471836663790", 30659114191)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4891540) -- The Night of the Unextinguished Flame