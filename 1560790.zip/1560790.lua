-- Lua provided by RyzenAPI
-- Game: Romance after dark

-- MAIN APPLICATION
addappid(1560790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560791, 1, "efbc89d01aac772123f49a931d590de2d3229ad8714155ad3bd412683e69f270")

