-- Lua provided by RyzenAPI 
-- Game: Romance after dark
addappid(1560790)
addappid(1560791, 1, "efbc89d01aac772123f49a931d590de2d3229ad8714155ad3bd412683e69f270")
