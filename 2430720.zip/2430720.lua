-- Lua provided by RyzenAPI
-- Game: SolForge Fusion - Early Access Demo

-- MAIN APPLICATION
addappid(2430720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430721, 1, "131074a1e575947f816b22e6d6caff07898c4c6e58abc31437d19083f822337d")

