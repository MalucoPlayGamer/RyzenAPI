-- Lua provided by SkyAPI 
-- Game: AppID 2430720
addappid(2430720)
addappid(2430721, 1, "131074a1e575947f816b22e6d6caff07898c4c6e58abc31437d19083f822337d")
