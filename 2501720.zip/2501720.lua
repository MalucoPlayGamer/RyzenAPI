-- Lua provided by RyzenAPI
-- Game: Game: AppID 2501720

-- MAIN APPLICATION
addappid(2501720)
-- Game: addappid(2501720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2501721, 1, "2d40171666df2397cd92d85cc1757d65a4da5b6843ce8376aaeafc0c022ef7e2")
