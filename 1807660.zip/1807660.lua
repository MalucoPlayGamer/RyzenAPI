-- Lua provided by RyzenAPI
-- Game: 1807660

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1807660)
-- Game: addappid(1807660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807662,0,"5cba4ec9a62a167d753cd27098b41c168b684c7bfea2191b56f4d6c68711978b")
