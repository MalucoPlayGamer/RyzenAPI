-- Lua provided by RyzenAPI
-- Game: BlastZone 2

-- MAIN APPLICATION
addappid(349260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(349261, 1, "0546db72bdc5b397d8b35c1dfe383b41f2bd0fb155805574da95fe5291c10fa3")
addappid(349262, 1, "0ec44122ea06da05ac81bfa0436fdbf226e8a9442773e6712cecbd14832efdf5")
addappid(349263, 1, "e1add37c84fa7b422efa72395752811972e10ef84e99e0e5352daff63411d34b")
addappid(822060, 0, "57454fbe78c0da7cf446df5c77f2381fa3b62baf819ed82078efe6267fab9f94")
addappid(822061, 0, "ed12f357e8c1ef7db9bc556a446100d8280d80e2a8c7168c1800d01ef75f3b12")
