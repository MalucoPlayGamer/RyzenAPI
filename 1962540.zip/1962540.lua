-- Lua provided by RyzenAPI
-- Game: Still Heroes

-- MAIN APPLICATION
addappid(1962540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962541, 1, "0c1f7ac17d34059ab7ef9f31af2606bb8f4a0ffb49a8d095e4554c9c4d659022")
