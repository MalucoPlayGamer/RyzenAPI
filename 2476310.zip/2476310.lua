-- Lua provided by RyzenAPI
-- Game: AppID 2476310

-- MAIN APPLICATION
addappid(2476310)
-- Game: addappid(2476310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476311, 1, "d4b629aa3bdcafce3b4f9a2b64c0c897c2c1160f031c8999843602a9363ad49b")
