-- Lua provided by SkyAPI 
-- Game: Amber Isle - Soundtrack
addappid(3185690)
addappid(3185691, 1, "bdfafaa7cbe0c718bd8cee9625d3bf4013ab1bbe4a46ac65a1624f7d6e27f097")
addappid(3185692, 1, "c99fad40328ef7feed101f6628c7ef708892ad5ef57e2e00b5f89805a038ec7c")
