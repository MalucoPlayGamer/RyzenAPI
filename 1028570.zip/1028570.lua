-- Lua provided by RyzenAPI
-- Game: 1028570

-- MAIN APPLICATION
addappid(1028570)
-- Game: addappid(1028570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028572,0,"50ceb877902abf873a4f4674a724093101b6a9cae5618ffa5b756e6797a7e86c")
