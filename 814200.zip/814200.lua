-- Lua provided by RyzenAPI 
-- Game: Simple Story - Alex
addappid(814200)
addappid(814201, 1, "f016d272c643b15831d055507e39552f34a3769a7f5a3072ae6092410a868f75")
addappid(814202, 1, "5348e037dd129d57cac7b8867f9a8be0a91d46ea49a724097d896a55337bea36")
addappid(821600)
addappid(821601)
addappid(827600)
addappid(828560)
addappid(1028290)
