-- Lua provided by RyzenAPI
-- Game: Game: AppID 382380

-- MAIN APPLICATION
addappid(382380)
-- Game: addappid(382380)

-- MAIN APP DEPOTS / PACKAGES
addappid(382381, 1, "78d219ad7fd72d943665b33ff647c126922175a7ecc6ffbf9c9e3a683dd8d6cd")
