-- Lua provided by RyzenAPI
-- Game: 277680

-- MAIN APPLICATION
addappid(277680)
-- Game: addappid(277680)

-- MAIN APP DEPOTS / PACKAGES
addappid(277681, 1, "024a1d2fe5ee5a27d7cdd03abb3c7b97b5e35f16f1d92ff31d41b985bec88337")
addappid(277682, 1, "6ab683cbf86fa4f288a8beb95e9122bb51fa72acb1e806cfec70df7da77d3a9c")
addappid(277683, 1, "0682252959c648808d3c63773aac750b1305a434a33b956fdcebf5d3630056cb")
addappid(277684, 1, "9d10091440dae0c94c76f023d8e515d0f1657875089ef2ce63947eec6bdd2fa0")
