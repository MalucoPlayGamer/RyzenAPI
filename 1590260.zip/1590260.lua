-- Lua provided by RyzenAPI
-- Game: Cube Space

-- MAIN APPLICATION
addappid(1590260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590261, 1, "6594488a0731a5bdbe6557c3a20bd37a145ea5c41735990ff156c6cc63ee98d9")
