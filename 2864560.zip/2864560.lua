-- Lua provided by RyzenAPI
-- Game: Rune Factory: Guardians of Azuma

-- MAIN APPLICATION
addappid(2864560)
addappid(3010040)
addappid(3139940)
addappid(3139950)
addappid(3139970)
addappid(3139980)
addappid(3139990)
addappid(3140000)
addappid(3140010)
addappid(3140020)
addappid(3140030)
addappid(3140040)
addappid(3140240)
addappid(3402710)
addappid(3717920)
addappid(3717930)
addappid(3717940)
addappid(3717960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864561, 1, "12f559d70c2bf66c2fe46e7363637bf089c3d3ca08c883741f9f7e3f20fdddbe")
addappid(3717950, 1, "b12e4d792b17735ff82a052e418ef9f13f6d10a415e43c14c5f636d5a6494a7e")
addappid(3717961, 1, "122ad1b3c64b71b1440fc3cb727a4f6cd907ef479de026349ecfcf63107bc0c8")
addappid(3717962, 1, "5bc470285e8ce83ba8858d73031d2f0f0e4d337d5b70ae72877b9826019339ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3966040)
