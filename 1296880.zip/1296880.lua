-- Lua provided by SkyAPI 
-- Game: Sausage Hunter
addappid(1296880)
addappid(1296881, 1, "a610faff0ec901784fd47b086c6c03cc2832f3afb1efb6f0c97a36ca16a7681a")
