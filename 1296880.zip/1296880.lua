-- Lua provided by RyzenAPI
-- Game: 1296880

-- MAIN APPLICATION
addappid(1296880)
-- Game: addappid(1296880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296881, 1, "a610faff0ec901784fd47b086c6c03cc2832f3afb1efb6f0c97a36ca16a7681a")
