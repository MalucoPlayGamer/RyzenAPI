-- Lua provided by RyzenAPI
-- Game: Cargo, Please!

-- MAIN APP DEPOTS / PACKAGES
addappid(4160920) -- Cargo, Please!
addappid(4160921, 1, "fc2cc31f59cb64ffaf274332e8fd12864f40cd2460258bdeb2193f82f30620af") -- Depot 4160921

