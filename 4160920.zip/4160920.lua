-- 4160920's Lua and Manifest Created by Hubcap Manifest
-- Cargo, Please!
-- Created: August 05, 2026 at 22:44:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4160920) -- Cargo, Please!
-- MAIN APP DEPOTS
addappid(4160921, 1, "fc2cc31f59cb64ffaf274332e8fd12864f40cd2460258bdeb2193f82f30620af") -- Depot 4160921
setManifestid(4160921, "453834243009593839", 2480910312)