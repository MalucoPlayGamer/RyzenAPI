-- Lua provided by RyzenAPI
-- Game: The Last Crown: Midnight Horror

-- MAIN APPLICATION
addappid(291770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(291771, 1, "221f4a95bd4f585936d2df7bbbe3b8f5c3bd62dea2ac5350d13fd88eadd69a8c")
addappid(291772, 1, "1bbaaabde6d9143501fd11215482937296f95e7a79f3761ca4e8edf9fdf817d2")

