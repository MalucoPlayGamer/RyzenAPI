-- Lua provided by RyzenAPI
-- Game: Game: Cybernetica: Final

-- MAIN APPLICATION
addappid(1549710)
-- Game: addappid(1549710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549711, 1, "24dee20bb0c69cc59ea161f8f5fe2d002a36c7084d7cd1a104c20ac03e15c230")
