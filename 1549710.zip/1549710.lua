-- Lua provided by SkyAPI 
-- Game: Cybernetica: Final
addappid(1549710)
addappid(1549711, 1, "24dee20bb0c69cc59ea161f8f5fe2d002a36c7084d7cd1a104c20ac03e15c230")
