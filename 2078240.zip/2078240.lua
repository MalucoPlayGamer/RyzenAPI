-- Lua provided by RyzenAPI
-- Game: Super Owlboy

-- MAIN APPLICATION
addappid(2078240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078241, 1, "51eb61c10e02922d59d52391a8a017f54210742402e5a9829c8bbef7c4e62828")

