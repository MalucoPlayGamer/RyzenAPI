-- Lua provided by RyzenAPI
-- Game: Game: AppID 250870

-- MAIN APPLICATION
addappid(250870)
addappid(256480)
addappid(289010)
-- Game: addappid(250870)

-- MAIN APP DEPOTS / PACKAGES
addappid(250871, 1, "dfbb9ec9658b07bfc5640d8288c4f14f1a348cced19d3d5178cea0d387678232")
addappid(250873, 1, "d1482eb087297459c917af1c4633f2b6e6a737916fee1fdd2a182bc1315739ff")
