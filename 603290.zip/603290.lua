-- Lua provided by RyzenAPI
-- Game: 603290

-- MAIN APPLICATION
addappid(603290)
-- Game: addappid(603290)

-- MAIN APP DEPOTS / PACKAGES
addappid(603291, 1, "50d774bf4e6bb62991e25365f8303c8496fcfd7879d8d4a61bb9291622fd3d5d")
