-- Lua provided by RyzenAPI
-- Game: Game: Bloodstained: Ritual of the Night - Soundtrack

-- MAIN APPLICATION
addappid(1101300)
-- Game: addappid(1101300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101301, 1, "bd09c580de1639fa13a7995f7008aff6d3e9a44e3db5f743fd2379292f756763")
