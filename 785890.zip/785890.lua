-- Lua provided by RyzenAPI
-- Game: Game: Hexologic

-- MAIN APPLICATION
addappid(785890)
-- Game: addappid(785890)

-- MAIN APP DEPOTS / PACKAGES
addappid(785891, 1, "d710717cb096ec7c3e0176712a73752e192045587df4f50522ee45f4197488c3")
addappid(785892, 1, "8f058d74f981f23b26796967565f80362abb231f7c9d4d7cb231752d7fb731f0")
addappid(785893, 1, "bb9ffd5dc1d72221740acd8d0b50ddce34da931589ec30e5ed7dcb109a44d131")
