-- Lua provided by RyzenAPI
-- Game: addappid(1059860)

-- MAIN APPLICATION
addappid(1059860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059861, 1, "cf929b0190b843a5acd64f9489b3e93dfcfd5db6556cd8131e1b57cef7acd85b")
