-- Lua provided by RyzenAPI
-- Game: End Gate - The Last Passenger Soundtrack

-- MAIN APPLICATION
addappid(3129850)
-- Game: addappid(3129850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129851, 1, "f27c9e9617abec96e300b3c5947de2c8c66630e45abff4d8830b5d0499fa6bbf")
