-- Lua provided by SkyAPI 
-- Game: Hentai Pleasure
addappid(1654160)
addappid(1654161, 1, "79e51ffc03a8c486eb378fd8303d454690ab52f8b3a6792ed1869634e20f2d9d")
