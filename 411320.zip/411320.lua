-- Lua provided by RyzenAPI
-- Game: Codename: Panzers, Phase Two

-- MAIN APPLICATION
addappid(411320)
addappid(431081)
addappid(431082)

-- MAIN APP DEPOTS / PACKAGES
addappid(411321, 1, "68ac9ed75545623bfe29d7a8c06f0812a4dea6dd5deeb255eb6422e6d42e7a4d")
addappid(411322, 1, "b5682011d65fc918dec544c81cf4da1e9513a848fc8b9e63fafcb9104f756fb6")
addappid(411323, 1, "6f6b05a15616ba01e909725e47ce9b20ce08e007539920f8466d3fb0044b8db2")
addappid(411324, 1, "505e6648aa8d7cd0ba33f9ad0b89e5b28a5454df5613fd5df7d8c1f0bbd207ef")
addappid(411325, 1, "fafb2d7a29bb3808ae9532e46e8879df3fff37ab6d6ff65921c87a4646eaeb9b")
addappid(411326, 1, "3e375256a672c2c8a3d3ca008783f27044bf8ad5488fa76a582d4ff71bf9150f")
addappid(411327, 1, "a7bca6dfeedcd28d789eaa28c57bbc1e15d8259ad38235849b9a9e93fed8d96d")
addappid(411328, 1, "308818343b66237b50fb2113b455401e6a387b76ec30c207d68c5b3e9b33a8af")
addappid(411329, 1, "6d91b0717fa9e725217046b48f4e19ed20c8614984f1cd94cb4f38d55eda6fad")
addappid(431080, 0, "4851b710105860102db1b97426ba26fe077b0b3f45d54b984a036d8f3a4c1534")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
