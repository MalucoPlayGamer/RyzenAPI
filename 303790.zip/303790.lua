-- Lua provided by RyzenAPI
-- Game: Faery - Legends of Avalon

-- MAIN APPLICATION
addappid(303790)

-- MAIN APP DEPOTS / PACKAGES
addappid(303791, 1, "d8b7ac242238f3a39290e33c316baf46e66326ee619378bc2ca796067a0442b3")
addappid(303792, 1, "4e6d0241ae4b724c2df1e3157699c1790a5f4e58eb163134b13d5d48d2b565dd")
addappid(303793, 1, "0ca88260bf965e4acdfc6880d0cd68a8b8922582082e0e465b57d6410f8f8a7e")
addappid(303794, 1, "0cf1d547c8dc9ecf7bf65e6b5f0e359575f1ab27d27e0354e18bc486cf0dce8e")
addappid(303795, 1, "755aee2e74e9d70cf76f34c1e4c832d7815a6180f96afc60040ad559d060e0a1")
addappid(303796, 1, "ae8535920f6e47f62d571be79d17c54e57e687e971de9d693cd9882dda8decd0")
addappid(303797, 1, "79f364d6d71897245470d3a9f9fc8e5e71509f3c2d2e9398970bbdaf89010d8f")
addappid(303798, 1, "8d9f8cb2a16de1e7c93bdf1db9b44e62a0382fa25e2813256be6b1a707c814af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
