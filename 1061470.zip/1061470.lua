-- Lua provided by RyzenAPI 
-- Game: AppID 1061470
addappid(1061470)
addappid(1061471, 1, "7af0dd8741533ff6496b7e9c5f9179bdafe81e7172cfde740bbd254e5458cd7f")
