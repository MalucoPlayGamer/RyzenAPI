-- Lua provided by RyzenAPI
-- Game: AppID 1061470

-- MAIN APPLICATION
addappid(1061470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061471, 1, "7af0dd8741533ff6496b7e9c5f9179bdafe81e7172cfde740bbd254e5458cd7f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1071210)
addappid(1080510)
