-- Lua provided by RyzenAPI
-- Game: 10 Miles To Safety

-- MAIN APPLICATION
addappid(1015140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1015141, 1, "7c909687c7b3b777be863b969f3a963db9733edf3b6b9959553f887fa58e301d")
