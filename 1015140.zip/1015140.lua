-- Lua provided by RyzenAPI
-- Game: 1015140

-- MAIN APPLICATION
addappid(1015140)
-- Game: addappid(1015140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015141, 1, "7c909687c7b3b777be863b969f3a963db9733edf3b6b9959553f887fa58e301d")
