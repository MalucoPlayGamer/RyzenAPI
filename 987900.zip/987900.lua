-- Lua provided by RyzenAPI
-- Game: Seeker

-- MAIN APPLICATION
addappid(987900)
-- Game: addappid(987900)

-- MAIN APP DEPOTS / PACKAGES
addappid(987901, 1, "ec452f7c1c6ac7f43728480e443ad22ceb1810da699c92a497acfeb0f9479148")
