-- Lua provided by RyzenAPI
-- Game: Game: Monster Sanctuary Soundtrack

-- MAIN APPLICATION
addappid(1475980)
-- Game: addappid(1475980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475981, 1, "62162065e3a0a4b79c36dce925c9e922dedf3d583cad1a8579c6c271b11a9469")
