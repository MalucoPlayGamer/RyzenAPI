-- Lua provided by SkyAPI 
-- Game: Monster Sanctuary Soundtrack
addappid(1475980)
addappid(1475981, 1, "62162065e3a0a4b79c36dce925c9e922dedf3d583cad1a8579c6c271b11a9469")
