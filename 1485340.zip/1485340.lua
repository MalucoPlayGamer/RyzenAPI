-- Lua provided by RyzenAPI
-- Game: AppID 1485340

-- MAIN APPLICATION
addappid(1485340)
-- Game: addappid(1485340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485341, 1, "a6cd73595b36ff9147a2e16bac1373fe845e535c2318b66b40a80d49d2bed87d")
