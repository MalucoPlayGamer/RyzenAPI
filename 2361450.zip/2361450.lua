-- Lua provided by SkyAPI 
-- Game: Missiles Away
addappid(2361450)
addappid(2361451, 1, "4be8c07c93abc9c477d2f08a22ec61ca4c2228d4a00f4666af471ed5a4e32d98")
