-- Lua provided by RyzenAPI
-- Game: AppID 592590

-- MAIN APPLICATION
addappid(592590)

-- MAIN APP DEPOTS / PACKAGES
addappid(592591, 1, "4ed1b191895fd3ad5b8b08391c00c3d83f6ab7491ebe356d5b50d2c5ddb79e05")

