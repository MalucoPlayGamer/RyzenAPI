-- Lua provided by RyzenAPI
-- Game: Abstract Arena

-- MAIN APPLICATION
addappid(678230)
addappid(679350)

-- MAIN APP DEPOTS / PACKAGES
addappid(678231, 1, "8d98dbedc4f59334219f0bd75ae65cbd41c639fbfdf11aa03669cbdb0fad2872")
