-- Lua provided by RyzenAPI
-- Game: 1432154

-- MAIN APPLICATION
addappid(1432154)
-- Game: addappid(1432154)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432154,0,"e29e2ecf9ace104c3f6cc131fab1fa3f47a311f893924f5af30ecccf1b4cc8c2")
