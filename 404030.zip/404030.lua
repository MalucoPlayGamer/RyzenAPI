-- Lua provided by RyzenAPI
-- Game: Game: Lucky Rabbit Reflex!

-- MAIN APPLICATION
addappid(404030)
-- Game: addappid(404030)

-- MAIN APP DEPOTS / PACKAGES
addappid(404031, 1, "5b676959ddf3b44699ba3a9c2f9869635603a0cf0731c65c19aa0bf7a18c8ce8")
