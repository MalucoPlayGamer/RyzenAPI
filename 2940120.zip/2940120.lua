-- Lua provided by RyzenAPI
-- Game: Game: Shattered Void

-- MAIN APPLICATION
addappid(2940120)
-- Game: addappid(2940120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940121, 1, "8ceea93e2e3dc971e9d154e84f3a637b951bd1d3165dd63a41077aa5a01aa989")
addappid(2940122, 1, "ac3309898c36d0acbf1e5bc81b4031b6b21c8f406b858e643841ca7713708cde")
addappid(2940123, 1, "4675d7c6c1fb1fb8a777d406de076d867d7e7d0b309c8eb1f633c3babc820e26")
addappid(2940124, 1, "ed6951a49099e79956b85646e231082038861346a72780e6aacf02ddc1d2bec8")
