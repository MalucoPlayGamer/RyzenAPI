-- Lua provided by RyzenAPI
-- Game: addappid(1708580)

-- MAIN APPLICATION
addappid(1708580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708581, 1, "80a28dfd1924309b366180a2073c9c4767832bee8371e1efe8ca3cea2047f16f")
