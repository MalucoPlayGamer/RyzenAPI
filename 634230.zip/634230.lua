-- Lua provided by RyzenAPI
-- Game: AppID 634230

-- MAIN APPLICATION
addappid(634230)
-- Game: addappid(634230)

-- MAIN APP DEPOTS / PACKAGES
addappid(634231, 1, "7b03c91a1e34b622e1cc702f88657fc8f5b58081f772d9d8468efd6772a573b9")
