-- Lua provided by RyzenAPI
-- Game: 3351670

-- MAIN APPLICATION
addappid(3351670)
-- Game: addappid(3351670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3351671, 1, "0bbf44ad9691d13b17e751ddb0d89da52ea6abd606d6a17c8730f423a48586a0")
