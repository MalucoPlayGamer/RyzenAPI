-- Lua provided by RyzenAPI
-- Game: 3345760

-- MAIN APPLICATION
addappid(3345760)
-- Game: addappid(3345760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345762,0,"57034874ae9582f1cf78048a3ddfff29ab5bc0a58c591ecfba978bcdf8dfed86")
