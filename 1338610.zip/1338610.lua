-- Lua provided by RyzenAPI 
-- Game: Guardian Chronicle
addappid(1338610)
addappid(1338611, 1, "e8f9a380b109b9464ff52aece3703f66b2c6f81fc3da15d70493869b30642fca")
