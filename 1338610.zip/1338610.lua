-- Lua provided by RyzenAPI
-- Game: Guardian Chronicle

-- MAIN APPLICATION
addappid(1338610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338611, 1, "e8f9a380b109b9464ff52aece3703f66b2c6f81fc3da15d70493869b30642fca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
