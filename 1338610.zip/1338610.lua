-- Lua provided by RyzenAPI
-- Game: Game: Guardian Chronicle

-- MAIN APPLICATION
addappid(1338610)
-- Game: addappid(1338610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338611, 1, "e8f9a380b109b9464ff52aece3703f66b2c6f81fc3da15d70493869b30642fca")
