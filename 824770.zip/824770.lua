-- Lua provided by RyzenAPI
-- Game: Game: AppID 824770

-- MAIN APPLICATION
addappid(824770)
-- Game: addappid(824770)

-- MAIN APP DEPOTS / PACKAGES
addappid(824771, 1, "3a152024bfde84c458c88a820e40af73161228ba92785ef067a5463078d18358")
