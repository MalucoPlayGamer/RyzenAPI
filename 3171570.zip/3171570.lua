-- Lua provided by RyzenAPI
-- Game: Game: Yarimono ~ DLC 1

-- MAIN APPLICATION
addappid(3171570)
-- Game: addappid(3171570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171571, 1, "3ec0a8d4b8c0f87b6df335032a93b2d866d94819cce90ef8deb6123dc6e602e7")
