-- 3306040's Lua and Manifest Created by Hubcap Manifest
-- Kiana & Biscuit - Pirates on a Visit!
-- Created: August 11, 2026 at 12:04:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3306040, 1, "276a118671c2fe9740c23838a9e064fafad3caa175f7305e3d1f48eb4d013d78") -- Kiana & Biscuit - Pirates on a Visit!
-- MAIN APP DEPOTS
addappid(3306042, 1, "9a499213896f4d5ddb25bf792e454c781de3418657e1db811e32459d9cfc0326") -- Depot 3306042
setManifestid(3306042, "6845790209972485951", 260723954)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3306041) -- Depot 3306041 (empty depot)