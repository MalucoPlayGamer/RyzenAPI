-- Lua provided by RyzenAPI
-- Game: Kiana & Biscuit - Pirates on a Visit!

-- MAIN APPLICATION
-- addappid(3306041) -- Depot 3306041 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(3306040, 1, "276a118671c2fe9740c23838a9e064fafad3caa175f7305e3d1f48eb4d013d78") -- Kiana & Biscuit - Pirates on a Visit!
addappid(3306042, 1, "9a499213896f4d5ddb25bf792e454c781de3418657e1db811e32459d9cfc0326") -- Depot 3306042

