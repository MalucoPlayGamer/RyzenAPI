-- Lua provided by RyzenAPI 
-- Game: AppID 3211900
addappid(3211900)
addappid(3211901, 1, "b05142cd291d04784b6ef3d105a193761f32fe50b130b2f5a8af205ada57b1c8")
