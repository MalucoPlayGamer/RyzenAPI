-- Lua provided by RyzenAPI
-- Game: Game: AppID 3026280

-- MAIN APPLICATION
addappid(3026280)
-- Game: addappid(3026280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026281, 1, "4ed56238dce91814b6c508d7516c02d5f853547179f7bc77d1a969d0bbba32cd")
