-- Lua provided by RyzenAPI
-- Game: The Backrooms: Mass Extinction

-- MAIN APPLICATION
addappid(1486280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486282,0,"1b06d4a4ca5eb4e0cdf8b460d897f89de40334953e4d0ccfad39ce07694b391e")

