-- Lua provided by RyzenAPI
-- Game: KAMIMAHOU 神之国的魔法使

-- MAIN APPLICATION
addappid(1768880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768881, 1, "1c47021257f207f958dae1737e7e72994bb42ad179a06555dd1cab63affb3e5d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
