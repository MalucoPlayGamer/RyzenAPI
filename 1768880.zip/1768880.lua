-- Lua provided by RyzenAPI
-- Game: 1768880

-- MAIN APPLICATION
addappid(1768880)
-- Game: addappid(1768880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768881, 1, "1c47021257f207f958dae1737e7e72994bb42ad179a06555dd1cab63affb3e5d")
