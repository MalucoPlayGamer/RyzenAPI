-- Lua provided by RyzenAPI
-- Game: addappid(834380)

-- MAIN APPLICATION
addappid(834380)

-- MAIN APP DEPOTS / PACKAGES
addappid(834381, 1, "a8f027bb8c68dcd90971e5a32ccee54616b06b7c8afeef0f2dcd3002f0cb846e")
addappid(834382, 1, "681773a1698443d8d276a81a824d7a88d4362bf6ba5dcaaa18bbfb72e3a97304")
addappid(834383, 1, "d31b193c5d2f6efe4723e4c826296e259a85b43cbbe90f9120c70952e132adce")
