-- Lua provided by RyzenAPI
-- Game: 1581860

-- MAIN APPLICATION
addappid(1581860)
-- Game: addappid(1581860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581861, 1, "c22a3ee2801efda76b28a58e473630cb8b1daa57ce233cd933ac878d82c4815f")
