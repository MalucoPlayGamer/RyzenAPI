-- Lua provided by RyzenAPI
-- Game: setManifestid(2825074,"4123419740737897605")

-- MAIN APPLICATION
addappid(2825070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825074,0,"ede2df12484deac8a87afdb4bc3edd22045cebd8332b96be45062ee26201b4ab")
