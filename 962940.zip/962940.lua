-- Lua provided by RyzenAPI
-- Game: 962940

-- MAIN APPLICATION
addappid(962940)
addappid(1009170)
-- Game: addappid(962940)

-- MAIN APP DEPOTS / PACKAGES
addappid(962941, 1, "cbd924aa4c0da678b9d9d5e4871a9cd9dc42a1e456292dcf01ee934b02c2211b")
