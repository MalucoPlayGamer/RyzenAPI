-- Lua provided by RyzenAPI
-- Game: Game: Shank Demo

-- MAIN APPLICATION
addappid(6130)
-- Game: addappid(6130)

-- MAIN APP DEPOTS / PACKAGES
addappid(6131, 1, "fce74ad15d99e0cf29dff80aef32916f2376f871c2acc59709666608c4e06c98")
