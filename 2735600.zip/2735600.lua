-- Lua provided by RyzenAPI
-- Game: addappid(2735600)

-- MAIN APPLICATION
addappid(2735600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735601, 1, "ef7ff40190884e74b13e747c659c789a4dbdf92b704b5fa80f78888cf029d155")
