-- Lua provided by RyzenAPI
-- Game: Vagrant Hearts

-- MAIN APPLICATION
addappid(337980)
addappid(392440)

-- MAIN APP DEPOTS / PACKAGES
addappid(337981, 1, "362b4456a04c55648f45537fa2880984998ebcc0322e42a566dd4b8b3340822d")

