-- Lua provided by RyzenAPI
-- Game: Within Skerry

-- MAIN APPLICATION
addappid(1871510)
-- Game: addappid(1871510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871511, 1, "d397f616f96a2dde1a7105c0d6cc7f5295d3da8cb0ff95c18abb09095b7a2693")
