-- Lua provided by RyzenAPI
-- Game: Adventure of Bears

-- MAIN APPLICATION
addappid(1433940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433941, 1, "8b2ddf3c664af1e10707c2385545609b75c2526bebd3d403fbadaaee3d24b050")

