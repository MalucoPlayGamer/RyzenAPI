-- Lua provided by RyzenAPI
-- Game: addappid(1848150)

-- MAIN APPLICATION
addappid(1848150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848151, 1, "032194ea189dee8eae97bc8da058a5709a5b56e166fa3d9c16edad596074f6d7")
