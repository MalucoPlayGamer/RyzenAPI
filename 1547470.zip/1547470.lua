-- Lua provided by RyzenAPI
-- Game: PewPew!

-- MAIN APPLICATION
addappid(1547470)
-- Game: addappid(1547470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547471, 1, "73086b43050a00604aa527b9989206d729e1baea035f3f2f631576a0305341ef")
