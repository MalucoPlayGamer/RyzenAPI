-- Lua provided by RyzenAPI
-- Game: Joe Wander and the Enigmatic Adventures

-- MAIN APPLICATION
addappid(2063310)
-- Game: addappid(2063310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063311, 1, "bea1cbef7553fd74c5b6adfe046d2c591ce75336b67ee290483cb9d2f398d57b")
