-- Lua provided by RyzenAPI
-- Game: Game: Circuit Dude

-- MAIN APPLICATION
addappid(662410)
-- Game: addappid(662410)

-- MAIN APP DEPOTS / PACKAGES
addappid(662411, 1, "8e6ad5776a176d9ed422b2e60fd9556471887b1e49758ff2a259c1979083c0bb")
