-- Lua provided by RyzenAPI 
-- Game: Shark Attack Deathmatch 2
addappid(330580)
addappid(330581, 1, "c2cc9a6c8959fa9829292ad79376ee52a4c9ee7d4692a33ee982c9824bed2199")
