-- Lua provided by RyzenAPI
-- Game: Shark Attack Deathmatch 2

-- MAIN APPLICATION
addappid(330580)
-- Game: addappid(330580)

-- MAIN APP DEPOTS / PACKAGES
addappid(330581, 1, "c2cc9a6c8959fa9829292ad79376ee52a4c9ee7d4692a33ee982c9824bed2199")
