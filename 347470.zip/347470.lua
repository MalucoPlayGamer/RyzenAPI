-- Lua provided by RyzenAPI
-- Game: Mayan Death Robots

-- MAIN APPLICATION
addappid(347470)

-- MAIN APP DEPOTS / PACKAGES
addappid(347471, 1, "747ccae6cff11a447de6101889bce11011ad7094a915ef7d9577a38d6db7b563")
