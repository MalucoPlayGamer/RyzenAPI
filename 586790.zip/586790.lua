-- Lua provided by RyzenAPI
-- Game: Game: Hold your houses

-- MAIN APPLICATION
addappid(586790)
-- Game: addappid(586790)

-- MAIN APP DEPOTS / PACKAGES
addappid(586791, 1, "198222aad144fd696bbac750b2855380957289a9d3807c27acaaa83cb97df8bc")
