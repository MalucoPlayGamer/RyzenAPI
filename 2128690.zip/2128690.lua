-- Lua provided by RyzenAPI
-- Game: addappid(2128690)

-- MAIN APPLICATION
addappid(2128690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128691, 1, "3bed920c7e869ebb3ec0f6955a43a4ff3652e7ba9ebac9106890eb66e5dcefc9")
