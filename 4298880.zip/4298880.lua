-- 4298880's Lua and Manifest Created by Hubcap Manifest
-- Timber Rush
-- Created: June 05, 2026 at 07:27:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4298880) -- Timber Rush
-- MAIN APP DEPOTS
addappid(4298882, 1, "7cb93d1e10746be5ee9c675b88b46d893e6f0f42c2cb0c539697282704f7d757") -- Depot 4298882
-- setManifestid(4298882, "8250943223348259073", 176923157)
addappid(4298883, 1, "f7275b174229f7c306174020ce12e32a6d6a9065acfc97bb82b4b607a1e464a1") -- Depot 4298883
-- setManifestid(4298883, "205462871412151772", 197954199)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4298881) -- Depot 4298881 (empty depot)