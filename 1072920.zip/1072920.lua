-- Lua provided by RyzenAPI
-- Game: HomeWork Is Crazy / 作业疯了

-- MAIN APPLICATION
addappid(1072920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072921, 1, "85ef2490b8c5a563d1ffb5836ed8118ee4bd17c1b828b909f5d9a17392535b91")

