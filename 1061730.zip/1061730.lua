-- Lua provided by RyzenAPI
-- Game: Super Monkey Ball: Banana Blitz HD

-- MAIN APPLICATION
addappid(1061730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061731, 1, "2c82b4ee2bda3fffea8a8525d3098f4d2c004bdc9fdb8ccd036927753a873249")

