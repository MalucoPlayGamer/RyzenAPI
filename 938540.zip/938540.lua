-- Lua provided by RyzenAPI
-- Game: AppID 938540

-- MAIN APPLICATION
addappid(938540)

-- MAIN APP DEPOTS / PACKAGES
addappid(938541, 1, "53c48e40b46e4d8c442a55d7eca73a6ab0bc111bd7c749ea3e78d8fc9128165c")
