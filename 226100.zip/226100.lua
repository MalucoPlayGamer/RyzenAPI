-- Lua provided by RyzenAPI
-- Game: PixelJunk™ Nom Nom Galaxy

-- MAIN APPLICATION
addappid(226100)
addappid(228990)
addappid(410760)

-- MAIN APP DEPOTS / PACKAGES
addappid(226101, 1, "2be75cb43a2529abd431e7a756b1764e32683a9b93c04d641dd78578fc58ffbd")
addappid(410761, 1, "e2b20e183d4dc2991d1090cbd4f04a1f5817ddd568da5c7247c83a1ea7f8c751")
