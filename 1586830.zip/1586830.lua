-- Lua provided by RyzenAPI
-- Game: addappid(1586830)

-- MAIN APPLICATION
addappid(1586830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586831, 1, "87daeab32390b679587f4ef457775d6a67b956d0444ebf55d30736e301ea9ef7")
