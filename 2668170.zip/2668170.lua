-- Lua provided by SkyAPI 
-- Game: Lust Bunker [18+]
addappid(2668170)
addappid(2668171, 1, "8446d95b2341f2db06a8fa85ad1285f224dd07d9f2dcb92ef29dcb6e3d272f64")
