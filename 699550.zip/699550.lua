-- Lua provided by RyzenAPI
-- Game: addappid(699550)

-- MAIN APPLICATION
addappid(699550)

-- MAIN APP DEPOTS / PACKAGES
addappid(699551, 1, "8507e72188a49316a4e622fe08a4d60f8a6d20d13f8b9d58fe955a26b9c1a2dd")
