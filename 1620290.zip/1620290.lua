-- Lua provided by SkyAPI 
-- Game: Zombie Cure Lab
addappid(1620290)
addappid(1620291, 1, "e695370de91e380b55b97bfa3200cf50460c83ff53830ce89c160bdc75513f45")
