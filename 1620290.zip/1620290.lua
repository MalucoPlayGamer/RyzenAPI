-- Lua provided by RyzenAPI
-- Game: Zombie Cure Lab

-- MAIN APPLICATION
addappid(1620290)
-- Game: addappid(1620290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620291, 1, "e695370de91e380b55b97bfa3200cf50460c83ff53830ce89c160bdc75513f45")
