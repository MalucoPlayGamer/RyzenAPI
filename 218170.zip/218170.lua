-- Lua provided by RyzenAPI
-- Game: Age of Conan: Unchained (US Version)

-- MAIN APPLICATION
addappid(218170)
addappid(218180)
addappid(268590)

-- MAIN APP DEPOTS / PACKAGES
addappid(218171, 1, "cf9f9c85b394c61c710fdd36ea4048c3b431489eec6160c8a65619681edee112")
