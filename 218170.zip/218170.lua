-- Lua provided by RyzenAPI 
-- Game: AppID 218170
addappid(218170)
addappid(218171, 1, "cf9f9c85b394c61c710fdd36ea4048c3b431489eec6160c8a65619681edee112")
