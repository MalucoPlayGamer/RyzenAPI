-- Lua provided by RyzenAPI
-- Game: Rocketbirds: Hardboiled Chicken

-- MAIN APPLICATION
addappid(215510)
-- Game: addappid(215510)

-- MAIN APP DEPOTS / PACKAGES
addappid(215511, 1, "305888227605833beae84e7b1f6fc3eb218fc4cc781ed57750893907c46407bd")
addappid(215512, 1, "3dc53b6842e0b886144f438f4c2b8f61973e164f0f785aad68215770119278d9")
addappid(215513, 1, "9edf073c2e61c87234d7485a95ebfb947624421692c19c8b7f8eaf6a088b6bec")
