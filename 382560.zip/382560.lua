-- Lua provided by RyzenAPI
-- Game: Hot Lava

-- MAIN APPLICATION
addappid(382560)

-- MAIN APP DEPOTS / PACKAGES
addappid(382561, 1, "c7cd9dead01a600a3c00ea545eb74a140a35557e5ace4ac29434b0d1472c2b3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
