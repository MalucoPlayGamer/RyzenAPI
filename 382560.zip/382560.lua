-- Lua provided by RyzenAPI
-- Game: addappid(382560)

-- MAIN APPLICATION
addappid(382560)

-- MAIN APP DEPOTS / PACKAGES
addappid(382561, 1, "c7cd9dead01a600a3c00ea545eb74a140a35557e5ace4ac29434b0d1472c2b3e")
