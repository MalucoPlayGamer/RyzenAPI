-- Lua provided by SkyAPI 
-- Game: Pro Gymnast Demo
addappid(1322420)
addappid(1322421, 1, "67cd8f03c517cce59938b46ad0e01b735646cd6a9d8c97f06850fc590aacc0bd")
