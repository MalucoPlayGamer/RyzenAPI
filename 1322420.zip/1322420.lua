-- Lua provided by RyzenAPI
-- Game: Pro Gymnast Demo

-- MAIN APPLICATION
addappid(1322420)
-- Game: addappid(1322420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322421, 1, "67cd8f03c517cce59938b46ad0e01b735646cd6a9d8c97f06850fc590aacc0bd")
