-- Lua provided by RyzenAPI
-- Game: Two of us

-- MAIN APPLICATION
addappid(1843980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843981, 1, "3a5f9b54a1075e1ee60571238b4298ece8aa6e75f7ca63a317b708878bcb4fb5")
