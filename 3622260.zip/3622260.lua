-- Lua provided by RyzenAPI
-- Game: Game: April Grove

-- MAIN APPLICATION
addappid(3622260)
-- Game: addappid(3622260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3622261, 1, "52df43ca76d0cd527f777a45966ad8ca14b82a8eaa4a2719d27376f2f71d1293")
