-- Lua provided by RyzenAPI
-- Game: Absence of Light

-- MAIN APPLICATION
addappid(2058460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058461, 1, "557acfa5e603452d5ab72c563be01b023c502d9faa0612c92c4681150f427232")

