-- Lua provided by RyzenAPI
-- Game: 1099460

-- MAIN APPLICATION
addappid(1099460)
-- Game: addappid(1099460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099461, 1, "94261a1c03f0c9a8125dad04b1d0d075d1c1d75276c1157f5ccfb5dded7b1de1")
