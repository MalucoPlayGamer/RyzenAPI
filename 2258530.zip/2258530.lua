-- Lua provided by RyzenAPI
-- Game: addappid(2258530)

-- MAIN APPLICATION
addappid(2258530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258531, 1, "543a40a6ab18b392f4ffa7e7bbcc3bb4da77070a02792209db6d8f2b1293ddac")
