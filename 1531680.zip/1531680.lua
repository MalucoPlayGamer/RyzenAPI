-- Lua provided by RyzenAPI
-- Game: 修真之路

-- MAIN APPLICATION
addappid(1531680)
-- Game: addappid(1531680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531681, 1, "2a4bd27ac3c760c319f9fd605690c644667a26990453152af446407d6f4c9e13")
