-- Lua provided by RyzenAPI
-- Game: GlobalQuarantine

-- MAIN APPLICATION
addappid(3710770)
-- Game: addappid(3710770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3710771, 1, "d672d9031d880f45c64b1d77f6a6122a0bf9ad2bd5385f808f47aae6d062f980")
