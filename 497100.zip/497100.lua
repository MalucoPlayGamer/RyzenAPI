-- Lua provided by RyzenAPI
-- Game: 497100

-- MAIN APPLICATION
addappid(497100)
-- Game: addappid(497100)

-- MAIN APP DEPOTS / PACKAGES
addappid(497101, 1, "d8c58b751eaf552c87b35b9644ae68fde4c21d08b08275afdd44d271690f74fe")
