-- Lua provided by RyzenAPI 
-- Game: Krosfighter
addappid(2635820)
addappid(2635821, 1, "cf7b5a726ea9c0193aae2eab66f6c1896c981f425ea7b0a29bc2f36b53429ec6")
