-- Lua provided by RyzenAPI
-- Game: addappid(681820)

-- MAIN APPLICATION
addappid(681820)

-- MAIN APP DEPOTS / PACKAGES
addappid(681821, 1, "e35e37ed82fe1940f5a55d30efec4060d46f5c794d675532a34f5423cbf3618a")
