-- Lua provided by RyzenAPI
-- Game: Game: UnMetal Demo

-- MAIN APPLICATION
addappid(1315850)
-- Game: addappid(1315850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315851, 1, "f41b01cba8c479bdca64e71d07518cdc584da2e236bdb2933219b6308e55b06a")
