-- Lua provided by RyzenAPI
-- Game: Contagion Dedicated Server

-- MAIN APPLICATION
addappid(293030)

-- MAIN APP DEPOTS / PACKAGES
addappid(293031, 1, "94abaa2865412cba984d605d0f47121545470bf5099541193b8863063f1bccf4")
addappid(293032, 1, "8f42ee7a7bdcdfd1f305f8c1a33fe838b1985302f582a28d3d295762fc0c7df8")
addappid(293033, 1, "d8ff80da4992ae3f0b3e481117dbd28989da82811016b8dab354e8af0643c4a9")

