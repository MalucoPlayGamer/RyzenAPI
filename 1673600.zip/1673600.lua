-- Lua provided by SkyAPI 
-- Game: Game For Anna
addappid(1673600)
addappid(1673601, 1, "6531b40c5c4c3b8e2fb157e414b1a2a2f22c3aedfc3277db7c6e1ec73da04eb1")
