-- Lua provided by RyzenAPI
-- Game: Game For Anna

-- MAIN APPLICATION
addappid(1673600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1673601, 1, "6531b40c5c4c3b8e2fb157e414b1a2a2f22c3aedfc3277db7c6e1ec73da04eb1")

