-- Lua provided by RyzenAPI
-- Game: addappid(1209510)

-- MAIN APPLICATION
addappid(1209510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209511, 1, "782a3b6209e12ffb83da1b8fd9e5c8b6d10406491b374fb93c376cba006bd0aa")
