-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - OldHospital

-- MAIN APPLICATION
addappid(3009770)
-- Game: addappid(3009770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009771, 1, "c36e9bee086641cc95883e14010eeca6da301d09cc5d5a44a4382c2836d7e9b7")
