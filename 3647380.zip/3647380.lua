-- Lua provided by RyzenAPI
-- Game: Ascension Gamebook

-- MAIN APPLICATION
addappid(3647380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3647381, 1, "943798ccd8ce13ff742c81adb87a74223f4940a5b11378baffad71134c6cdf89")

