-- Lua provided by RyzenAPI
-- Game: AppID 529100

-- MAIN APPLICATION
addappid(529100)
-- Game: addappid(529100)

-- MAIN APP DEPOTS / PACKAGES
addappid(529101, 1, "dd2254b407b41f9c0a66f3b9932993de53681e12bcb246f0370f7327c597f31f")
