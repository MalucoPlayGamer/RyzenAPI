-- Lua provided by RyzenAPI 
-- Game: Halloween Girl
addappid(981790)
addappid(981791, 1, "6fac8795bf844fba8cdabf6f144589f8264b496ba257b1166f116668974027e7")
addappid(982190, 0, "831e67e5727f1294889ff93b6d0b723d68ef4e415d3ca3227c90389d1770100a")
