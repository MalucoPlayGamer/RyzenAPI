-- Lua provided by RyzenAPI
-- Game: STATIC: Investigator Training

-- MAIN APPLICATION
addappid(354720)

-- MAIN APP DEPOTS / PACKAGES
addappid(354721, 1, "0b6cfd64a9ead5c3af00fdd5a720d4da7abd28667a34b59abc98c87ceb3e29b1")

