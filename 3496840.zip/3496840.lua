-- Lua provided by RyzenAPI
-- Game: Organic Burger Simulator

-- MAIN APPLICATION
addappid(3496840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496841, 1, "708f623e4f6545318f4cdb84db1f7b44fc81fa379bcab775c48b5f452cc8de22")
