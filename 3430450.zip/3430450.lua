-- Lua provided by RyzenAPI
-- Game: Zombie Graveyard Simulator

-- MAIN APPLICATION
addappid(3430450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430451, 1, "d6332436b602f2c28d7293d6ed4ff8c47276e5035de5e2f55b3049ccd5f1e948")
