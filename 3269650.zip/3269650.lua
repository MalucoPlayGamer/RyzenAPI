-- Lua provided by RyzenAPI
-- Game: Isle of the Night: Pirate Survivors

-- MAIN APPLICATION
addappid(3269650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269651, 1, "54dc89dd54071ba35d8956c7c9633983123ba043bbdccb42d42f19569a05cb9f")

