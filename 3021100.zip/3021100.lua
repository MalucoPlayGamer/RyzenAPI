-- Lua provided by RyzenAPI
-- Game: Five Hearts Under One Roof

-- MAIN APPLICATION
addappid(3021100)
-- Game: addappid(3021100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021101, 1, "7e7c0976f19ebf717f8bdf5b661b1bec4163b9972058f6b40f37f41ea75a5ad5")
addappid(3021102, 1, "b823062bd11419706eb109653048db1167267957791dbd3cd9de278b1df22fd4")
addappid(3021103, 1, "c2efb6191fffcccf257712a9903c4ec9c3b6dbd1785540d1a747756791f3eb29")
