-- Lua provided by RyzenAPI
-- Game: addappid(1287420)

-- MAIN APPLICATION
addappid(1287420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287421, 1, "7722b97f16d4e337ffdd3f44973be8aa16668e09a0aa4b21e61473f971d52648")
