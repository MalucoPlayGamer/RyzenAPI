-- Lua provided by RyzenAPI
-- Game: PiLKO

-- MAIN APPLICATION
addappid(1287420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287421, 1, "7722b97f16d4e337ffdd3f44973be8aa16668e09a0aa4b21e61473f971d52648")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
