-- Lua provided by SkyAPI 
-- Game: The Island Story
addappid(1209650)
addappid(1209651, 1, "abf730f677201184526d578ee6a7d508c4c90b0f528e81f337da697297a35a55")
