-- Lua provided by RyzenAPI
-- Game: The Island Story

-- MAIN APPLICATION
addappid(1209650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209651, 1, "abf730f677201184526d578ee6a7d508c4c90b0f528e81f337da697297a35a55")
