-- Lua provided by RyzenAPI
-- Game: Speedball Arena

-- MAIN APPLICATION
addappid(566380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(566381, 1, "410d2bde1eed2d80a133cb3b0d67ae49ec0cfd51b5b760f5507bde05447058d0")

