-- Lua provided by RyzenAPI
-- Game: 566380

-- MAIN APPLICATION
addappid(566380)
-- Game: addappid(566380)

-- MAIN APP DEPOTS / PACKAGES
addappid(566381, 1, "410d2bde1eed2d80a133cb3b0d67ae49ec0cfd51b5b760f5507bde05447058d0")
