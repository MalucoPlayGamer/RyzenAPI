-- Lua provided by RyzenAPI
-- Game: Game: Tux and Fanny

-- MAIN APPLICATION
addappid(2094730)
-- Game: addappid(2094730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094731, 1, "96a49629890b8f453aefae78572708fbf4f3c6a33d563560fcf0537a593d3824")
addappid(2094732, 1, "be99a49d92cc1e25f26e6744a24c0f2d47204a93ca453d041e68ce7f2b64a876")
addappid(2094733, 1, "ae6ed504da501741a9ffb37e981665d283e7a8b1e2479e09d44863976c25bece")
