-- Lua provided by RyzenAPI
-- Game: addappid(1685500)

-- MAIN APPLICATION
addappid(1685500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685501, 1, "4803e542f2a47fb88e289fa8aa61ccdb2c4eddfc1694d049054ea52e55f504da")
