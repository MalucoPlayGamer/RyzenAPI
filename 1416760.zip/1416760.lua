-- Lua provided by RyzenAPI
-- Game: AppID 1416760

-- MAIN APPLICATION
addappid(1416760)
-- Game: addappid(1416760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416761, 1, "a87a48ea64cdd2baeafb971f2408f0dc97b4ae491dc4de5eaf7a319527d405b7")
