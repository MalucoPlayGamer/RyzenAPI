-- Lua provided by RyzenAPI
-- Game: ServiceIT: You can do IT Demo

-- MAIN APPLICATION
addappid(2293720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293721, 1, "a03c1c7c0a1edbfe5c20485c9ee2e808d98e34563077371c30078aacbfaf1024")

