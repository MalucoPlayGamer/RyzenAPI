-- Lua provided by RyzenAPI
-- Game: Game: AppID 372390

-- MAIN APPLICATION
addappid(372390)
-- Game: addappid(372390)

-- MAIN APP DEPOTS / PACKAGES
addappid(372391, 1, "19577866ed87f03469d6c0866b3c77a951dfce214008f76d35f55084a256d83a")
