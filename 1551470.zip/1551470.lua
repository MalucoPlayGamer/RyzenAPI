-- Lua provided by RyzenAPI
-- Game: Voidwalkers: The Gates Of Hell

-- MAIN APPLICATION
addappid(1551470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551471, 1, "2a2a65f2f62f5a53e3b22058553526ffcc765f1fe25ef16f6119e6b230d73af6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1745890)
addappid(2007820)
addappid(2054700)
addappid(2054710)
addappid(2074880)
