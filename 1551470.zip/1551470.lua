-- Lua provided by RyzenAPI
-- Game: Voidwalkers: The Gates Of Hell

-- MAIN APPLICATION
addappid(1551470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551471, 1, "2a2a65f2f62f5a53e3b22058553526ffcc765f1fe25ef16f6119e6b230d73af6")

