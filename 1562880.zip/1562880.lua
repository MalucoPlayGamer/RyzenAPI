-- Lua provided by RyzenAPI
-- Game: addappid(1562880)

-- MAIN APPLICATION
addappid(1562880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562881, 1, "e4d70a7e376c3c7f96eb5532efdbcad486e6eef03feaf084cc804597a2c585e2")
