-- Lua provided by SkyAPI 
-- Game: Ponk's Jam
addappid(1562880)
addappid(1562881, 1, "e4d70a7e376c3c7f96eb5532efdbcad486e6eef03feaf084cc804597a2c585e2")
