-- Lua provided by SkyAPI 
-- Game: The Twins' Experiment
addappid(1733100)
addappid(1733101, 1, "84ea184ff16db263ce801ea972da7c92b6a6ca11147d945facfd4bccab131c25")
