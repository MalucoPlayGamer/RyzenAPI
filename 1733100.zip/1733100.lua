-- Lua provided by RyzenAPI
-- Game: 1733100

-- MAIN APPLICATION
addappid(1733100)
-- Game: addappid(1733100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733101, 1, "84ea184ff16db263ce801ea972da7c92b6a6ca11147d945facfd4bccab131c25")
