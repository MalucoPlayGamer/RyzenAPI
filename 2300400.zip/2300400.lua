-- Lua provided by RyzenAPI
-- Game: Quacktown Smackdown

-- MAIN APPLICATION
addappid(2300400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300401, 1, "4de8b6e28519d5b1ef75e9b269a941f8dd5204d17d65a9179769337803911142")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
