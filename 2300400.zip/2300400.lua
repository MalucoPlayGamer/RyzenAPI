-- Lua provided by SkyAPI 
-- Game: Quacktown Smackdown
addappid(2300400)
addappid(2300401, 1, "4de8b6e28519d5b1ef75e9b269a941f8dd5204d17d65a9179769337803911142")
