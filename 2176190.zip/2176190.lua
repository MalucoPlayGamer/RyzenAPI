-- Lua provided by RyzenAPI
-- Game: 2176190

-- MAIN APPLICATION
addappid(2176190)
-- Game: addappid(2176190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176191, 1, "24dfb38ae3541ec8a8dbe8db8e25c4a41f94402a2f10bca26e0b542793989470")
