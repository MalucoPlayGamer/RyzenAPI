-- Lua provided by RyzenAPI
-- Game: addappid(1876460)

-- MAIN APPLICATION
addappid(1876460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876463,0,"47add6a7e0a4017d8290b4bce8ee75f7f5446b0b73d1f3c5d8359b3c049063ba")
