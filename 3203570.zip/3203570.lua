-- Lua provided by RyzenAPI
-- Game: Game: VR Sailing

-- MAIN APPLICATION
addappid(3203570)
-- Game: addappid(3203570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3203571, 1, "5d023177137ed0a99796910004c756d3466c6188797869ef936989509cbc9a3f")
