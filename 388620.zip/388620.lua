-- Lua provided by SkyAPI 
-- Game: DungeonUp
addappid(388620)
addappid(388621, 1, "3674eec2515a55146571b46e5948401893110f5c692c46db92739e909d06affe")
addappid(388623, 1, "fd06be32b9607d2b356de2f098fa7a1970c5dee0e2d0f4ac8fee80c2b0eda703")
