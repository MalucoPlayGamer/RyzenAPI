-- Lua provided by RyzenAPI
-- Game: 404号公寓

-- MAIN APPLICATION
addappid(2873810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873811,0,"a0aa44130857a82bf2dbc19ab45a2c2eeabfcf19b4c664ac46e9136a789ba9b6")

