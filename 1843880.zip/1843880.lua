-- Lua provided by RyzenAPI
-- Game: 1843880

-- MAIN APPLICATION
addappid(1843880)
-- Game: addappid(1843880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843881, 1, "51be61af33b960e634846e649dff1c1038d076e26189a5fbb985ce83dc68412d")
