-- Lua provided by RyzenAPI 
-- Game: Tumblebugs
addappid(1843880)
addappid(1843881, 1, "51be61af33b960e634846e649dff1c1038d076e26189a5fbb985ce83dc68412d")
