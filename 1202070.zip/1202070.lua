-- Lua provided by RyzenAPI
-- Game: Gachi Revenge

-- MAIN APPLICATION
addappid(1202070)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1202071, 1, "9fc939e7c0240e911d399c6f42222b280eb18a4382f9f522afb0a536f5528415")

