-- Lua provided by RyzenAPI
-- Game: Game: Gachi Revenge

-- MAIN APPLICATION
addappid(1202070)
-- Game: addappid(1202070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202071, 1, "9fc939e7c0240e911d399c6f42222b280eb18a4382f9f522afb0a536f5528415")
