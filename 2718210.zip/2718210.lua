-- Lua provided by RyzenAPI
-- Game: The Skirmish

-- MAIN APPLICATION
addappid(2718210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718211, 1, "4a290671573e46b91d5bba989542668a7ec5c069901149607d69fd6707ebf11c")

