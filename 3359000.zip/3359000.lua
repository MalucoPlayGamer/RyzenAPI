-- Lua provided by RyzenAPI
-- Game: Game: Arisen Force: Life Devotee Soundtrack

-- MAIN APPLICATION
addappid(3359000)
-- Game: addappid(3359000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359001, 1, "182a817e15612f0f274f55202f21f18b878ff664e814eff53bd548fddfc9efed")
addappid(3359003, 1, "e046eb75c90646891119bd5504b3746271169889d30157c94367bf9f6238ca2c")
