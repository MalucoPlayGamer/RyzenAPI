-- Lua provided by RyzenAPI
-- Game: 3337210

-- MAIN APPLICATION
addappid(3337210)
-- Game: addappid(3337210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337211, 1, "3d38aa8ad06b229923cbf832a61d5b436b8e8a8064272c54df1ad51860fb2818")
