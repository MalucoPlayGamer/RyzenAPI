-- Lua provided by SkyAPI 
-- Game: GIRLS MADE PUDDING
addappid(3337210)
addappid(3337211, 1, "3d38aa8ad06b229923cbf832a61d5b436b8e8a8064272c54df1ad51860fb2818")
