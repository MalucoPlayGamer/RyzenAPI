-- Lua provided by RyzenAPI
-- Game: addappid(2384220)

-- MAIN APPLICATION
addappid(2384220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384220,0,"decce403f9fb494c6810466d4ec7f07cebf19063a086d5b934902d9a89c98b32")
