-- Lua provided by RyzenAPI
-- Game: Game: AppID 1184560

-- MAIN APPLICATION
addappid(1184560)
-- Game: addappid(1184560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184561, 1, "d05af4e8581d9d020ce5cee673f2e1c0323654d78848601b0064ebf091193f44")
