-- Lua provided by RyzenAPI
-- Game: 884980

-- MAIN APPLICATION
addappid(884980)
-- Game: addappid(884980)

-- MAIN APP DEPOTS / PACKAGES
addappid(884981, 1, "75d00da97f8955a2d4ad7eb92e237e4916eec8ddcecfe561a889a6745efab747")
