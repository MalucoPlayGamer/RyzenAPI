-- Lua provided by RyzenAPI
-- Game: addappid(1556610)

-- MAIN APPLICATION
addappid(1556610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556611, 1, "27ce1cd265fc45c02b3f3df76d8b3b51a3b626b443cdef7b9cf67057619b1f02")
