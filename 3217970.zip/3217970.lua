-- Lua provided by SkyAPI 
-- Game: Yet Another Killing Game
addappid(3217970)
addappid(3217971, 1, "9f59a013d3c787a37facc3342f56f8476762455144705e5c932e00482d9c411b")
