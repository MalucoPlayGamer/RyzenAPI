-- Lua provided by RyzenAPI
-- Game: AppID 447850

-- MAIN APPLICATION
addappid(447850)
-- Game: addappid(447850)

-- MAIN APP DEPOTS / PACKAGES
addappid(447851, 1, "123f7929a22e9532b687884a0e50126da219d0a7f936ac5fb6a812cf16988f93")
