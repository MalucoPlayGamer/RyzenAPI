-- Lua provided by SkyAPI 
-- Game: AppID 447850
addappid(447850)
addappid(447851, 1, "123f7929a22e9532b687884a0e50126da219d0a7f936ac5fb6a812cf16988f93")
