-- Lua provided by RyzenAPI 
-- Game: AppID 1134370
addappid(1134370)
addappid(1134371, 1, "7f16bf42e37420a1dafe7d5c808348a7729a622adeb0feb1e78edabe21983e75")
