-- Lua provided by RyzenAPI
-- Game: AppID 1134370

-- MAIN APPLICATION
addappid(1134370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134371, 1, "7f16bf42e37420a1dafe7d5c808348a7729a622adeb0feb1e78edabe21983e75")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
