-- Lua provided by RyzenAPI 
-- Game: AppID 1322310
addappid(1322310)
addappid(1322311, 1, "f8619e5044d57138fb55930ad610ad4687ccbd6b29bc58d328200f05bb91e9db")
addappid(1322312, 1, "db19dfa097cdff8ffb8d60364d783d8a5c085cfac0078b65d15390783e2c85fb")
addappid(1397150, 0, "6c092bb6553b5ecb56f595b511d3db03d22c0198cbf197280b14b2baf6be8beb")
