-- Lua provided by RyzenAPI
-- Game: City Ambulance Car Driving

-- MAIN APPLICATION
addappid(2291490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291491, 1, "08cf165c9b2347b55c3de7c29f03805831359e84a008d673d1ba281fa2b89528")

