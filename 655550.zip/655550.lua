-- Lua provided by RyzenAPI
-- Game: 655550

-- MAIN APPLICATION
addappid(655550)
-- Game: addappid(655550)

-- MAIN APP DEPOTS / PACKAGES
addappid(655551, 1, "3d5dd48fdb0c3167db46d6d63f30d3761e87bda29c421edd40dcc2f5894dcebe")
