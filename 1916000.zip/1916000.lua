-- Lua provided by RyzenAPI
-- Game: Divine Combat

-- MAIN APPLICATION
addappid(1916000)
-- Game: addappid(1916000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916001, 1, "c1bc9ede93cb024f2d49897f120bc2df132e64d6dfaa2cf6a342ea9a16790214")
