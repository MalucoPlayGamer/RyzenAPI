-- Lua provided by RyzenAPI
-- Game: Apex Aim Trainer

-- MAIN APPLICATION
addappid(1188540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188541, 1, "e6350b82e8e40961b6f72332e875746a49f94ac1304b658aa57c6375a877c617")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
