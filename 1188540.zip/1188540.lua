-- Lua provided by SkyAPI 
-- Game: Apex Aim Trainer
addappid(1188540)
addappid(1188541, 1, "e6350b82e8e40961b6f72332e875746a49f94ac1304b658aa57c6375a877c617")
