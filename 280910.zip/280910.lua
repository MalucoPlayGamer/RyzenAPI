-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(280910)

-- MAIN APP DEPOTS / PACKAGES
addappid(280912,0,"e5e87ac99f9ca3e62275e3fef3c565291d789c777db9c84b9580de5cfd82a0ad")
addappid(280913,0,"0f163b10eff05e29313fca44e81d7c59fd636ba64be5ce6ca97717634e203d19")
addappid(280914,0,"179cba5c5fafd3673ff04c9ee6a07681e311a9f668960c62e09d8113627cbcaa")

