-- Lua provided by RyzenAPI
-- Game: 1205361

-- MAIN APPLICATION
addappid(1205361)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205361,0,"0be334e22a66edcfadd98cf35053c9d47fe10b9d7ceecaa388d6acbade4260fb")

