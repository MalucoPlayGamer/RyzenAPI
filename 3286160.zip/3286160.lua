-- Lua provided by RyzenAPI
-- Game: Game: Liquor Store Simulator Demo

-- MAIN APPLICATION
addappid(3286160)
-- Game: addappid(3286160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286161, 1, "6a2032cf6ddad507675621151e7791d6bd4b54cc0df55108ac249185e89fcdfe")
