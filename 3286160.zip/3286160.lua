-- Lua provided by SkyAPI 
-- Game: Liquor Store Simulator Demo
addappid(3286160)
addappid(3286161, 1, "6a2032cf6ddad507675621151e7791d6bd4b54cc0df55108ac249185e89fcdfe")
