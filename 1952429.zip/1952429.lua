-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Outdoor Building Pack Vol.1

-- MAIN APPLICATION
addappid(1952429)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952429,0,"9be883c9e6d5f4cdb9a07060045f15c2d61da916419eb3951f5443578b5a3c27")
