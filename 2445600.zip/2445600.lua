-- Lua provided by RyzenAPI
-- Game: addappid(2445600)

-- MAIN APPLICATION
addappid(2445600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445601, 1, "697204437d94dd6cfbbb6bae7fdb37caed5cc4e7d78be3671fbb0f8f57db17dc")
