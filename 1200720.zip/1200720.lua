-- Lua provided by RyzenAPI
-- Game: Making*Lovers

-- MAIN APPLICATION
addappid(1200720)
-- Game: addappid(1200720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200721, 1, "ee69b430d83df979704ff1ea25477f34409fdceac3e6d2d42f0b6fdf31d5eeca")
