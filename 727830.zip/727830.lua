-- Lua provided by RyzenAPI
-- Game: 727830

-- MAIN APPLICATION
addappid(727830)
-- Game: addappid(727830)

-- MAIN APP DEPOTS / PACKAGES
addappid(727831, 1, "4ccdbfa1d55d54ea2c2439ce9682da6ea72e8672be43b71446a8fb668fffe74b")
