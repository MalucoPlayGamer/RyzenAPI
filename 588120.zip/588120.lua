-- Lua provided by RyzenAPI
-- Game: Game: AppID 588120

-- MAIN APPLICATION
addappid(588120)
-- Game: addappid(588120)

-- MAIN APP DEPOTS / PACKAGES
addappid(588121, 1, "edf03e222f7709d87fbe3eae42472f475aaedc6eeff427696863b19bfbbc5d13")
