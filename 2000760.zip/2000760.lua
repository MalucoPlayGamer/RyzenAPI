-- Lua provided by SkyAPI 
-- Game: Boiling Point: Road to Hell
addappid(2000760)
addappid(2000761, 1, "e7d1bc4228bd01b41617d4b182ce0f7e572fdf4cf5a0e512d9bb88b9d9c1c7f5")
