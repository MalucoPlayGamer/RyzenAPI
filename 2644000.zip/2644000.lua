-- Lua provided by RyzenAPI
-- Game: Hentai Midori

-- MAIN APPLICATION
addappid(2644000)
-- Game: addappid(2644000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644001, 1, "ca742c4094cc7ffbce38674a883f12611cdf06ae92571f6055b7c58cfd532829")
