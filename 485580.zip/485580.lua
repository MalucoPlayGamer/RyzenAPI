-- Lua provided by RyzenAPI
-- Game: AppID 485580

-- MAIN APPLICATION
addappid(485580)
addappid(525090)
-- Game: addappid(485580)

-- MAIN APP DEPOTS / PACKAGES
addappid(485581, 1, "606f7ab941b950156e5b54b6fe8c5365d47da19e00c0412b7d4773bcda911c1d")
