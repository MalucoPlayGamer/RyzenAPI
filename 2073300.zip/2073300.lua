-- Lua provided by RyzenAPI
-- Game: GameGuru MAX FREE trial version

-- MAIN APPLICATION
addappid(2073300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073301, 1, "3f68aaf6162792beb8d843e30e91aab78bb10a897373aa78d1cf9092a0351e03")
addappid(2073302, 1, "1d33a2267991eac97570764af63104915a873e5cfe0a3375fd51f5cd2700a02c")

