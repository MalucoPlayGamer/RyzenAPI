-- Lua provided by RyzenAPI
-- Game: Grape Jelly

-- MAIN APPLICATION
addappid(716940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(716941, 1, "cac6951586e29fffd852c6e6aeca37b10b5666baa719a959cc4114adf9015960")

