-- Lua provided by RyzenAPI
-- Game: Game: Grape Jelly

-- MAIN APPLICATION
addappid(716940)
-- Game: addappid(716940)

-- MAIN APP DEPOTS / PACKAGES
addappid(716941, 1, "cac6951586e29fffd852c6e6aeca37b10b5666baa719a959cc4114adf9015960")
