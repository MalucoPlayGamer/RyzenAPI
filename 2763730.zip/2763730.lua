-- Lua provided by RyzenAPI
-- Game: AppID 2763730

-- MAIN APPLICATION
addappid(2763730)
-- Game: addappid(2763730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763731, 1, "b052c6a1cfc842b3ec4bae5dd8c754940b10ea4374ad10c98738dd4baba1f4d8")
addappid(2763732, 1, "ce6ef67b7ea9f4fcbff0596663458de4029093912127286dcaea341eac42a014")
