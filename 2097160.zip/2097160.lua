-- Lua provided by SkyAPI 
-- Game: Monster Mystery
addappid(2097160)
addappid(2097161, 1, "bbbd78c7d9b4fc4ccfdfa90de534715431b17b5201981622e82674811cd6b990")
