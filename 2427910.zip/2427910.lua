-- Lua provided by RyzenAPI
-- Game: Neonscape

-- MAIN APPLICATION
addappid(2427910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2427911, 1, "4cb8d5cada76edbddf5b0e636e92fc8770433460d1149ee51143c8156e19d111")

