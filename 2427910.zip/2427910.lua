-- Lua provided by RyzenAPI
-- Game: addappid(2427910)

-- MAIN APPLICATION
addappid(2427910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427911, 1, "4cb8d5cada76edbddf5b0e636e92fc8770433460d1149ee51143c8156e19d111")
