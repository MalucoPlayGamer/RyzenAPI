-- Lua provided by RyzenAPI
-- Game: 576050

-- MAIN APPLICATION
addappid(576050)
-- Game: addappid(576050)

-- MAIN APP DEPOTS / PACKAGES
addappid(576051, 1, "1d596ab08da5728a5a0d65945f465d557bab3f3ef38b5383de788abe016ebc0f")
