-- Lua provided by RyzenAPI
-- Game: addappid(3226460)

-- MAIN APPLICATION
addappid(3226460)
addappid(3398850)
addappid(3398860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226461, 1, "7925e91b821bb5818ded269e6ed58610c50d8375f813d07bc23b17bcd668a1fc")
addappid(3699541, 0, "213cadc9974edb8cc49b85e38d5e0892b9e9c3b644282260c6751b6f67172ebc")
addappid(3699551, 0, "9c5c4477d10e9f257c9ef0e0c341ab0dd66d03d25b01abfe98f5cb9f4e30db50")
