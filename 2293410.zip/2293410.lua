-- Lua provided by RyzenAPI
-- Game: AppID 2293410

-- MAIN APPLICATION
addappid(2293410)
-- Game: addappid(2293410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293411, 1, "16f662dcbbb519d209ea9a0a9325bd4c85caa38d948b099f61d42676a2923ef1")
