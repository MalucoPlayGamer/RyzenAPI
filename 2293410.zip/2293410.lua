-- Lua provided by RyzenAPI
-- Game: Drift Experience Japan

-- MAIN APPLICATION
addappid(2293410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2293411, 1, "16f662dcbbb519d209ea9a0a9325bd4c85caa38d948b099f61d42676a2923ef1")

