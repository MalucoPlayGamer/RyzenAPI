-- Lua provided by RyzenAPI
-- Game: The Search

-- MAIN APPLICATION
addappid(566190)

-- MAIN APP DEPOTS / PACKAGES
addappid(566191, 1, "5c76371212c74bcc380d0d59ffde4d7d7513545cb9ff1694106313c12af617c6")
