-- Lua provided by RyzenAPI
-- Game: addappid(41080)

-- MAIN APPLICATION
addappid(41080)

-- MAIN APP DEPOTS / PACKAGES
addappid(41081, 1, "86fc6dd516f4145af2bdceed3ab7c4d3e4c597b7c813dfbda3cc8fa25fd7eaab")
addappid(41082, 1, "ab803b957861cdbcf4b02bfa1100f3fcdb6f288d66847127e78f266665c296c9")
addappid(41083, 1, "9a5c1b881a65469478b34c2e55eefe785872ae2fa8e7de05c8c4ecfc37304e6a")
