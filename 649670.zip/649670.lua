-- Lua provided by RyzenAPI
-- Game: addappid(649670)

-- MAIN APPLICATION
addappid(649670)

-- MAIN APP DEPOTS / PACKAGES
addappid(649671, 1, "662327461241efbc3439cf6091db30c926e71e55a60dd52f82c037b94155c4eb")
