-- Lua provided by RyzenAPI
-- Game: Game: Wrongworld

-- MAIN APPLICATION
addappid(664750)
-- Game: addappid(664750)

-- MAIN APP DEPOTS / PACKAGES
addappid(664751, 1, "dfd165a5210aacacc8181388ccf0c4339715540825ad3334614f90d286f98929")
