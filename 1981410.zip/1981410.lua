-- Lua provided by RyzenAPI
-- Game: Game: Mega Man Battle Network Legacy Collection Vol. 1 - Custom PET Pack Vol. 1

-- MAIN APPLICATION
addappid(1981410)
-- Game: addappid(1981410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981411, 1, "0781ec8d271e9fd1566848a58458231722c5675f354a1438e6819013bf4282cc")
