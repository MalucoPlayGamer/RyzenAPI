-- Lua provided by RyzenAPI
-- Game: AppID 1129610

-- MAIN APPLICATION
addappid(1129610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129611, 1, "777d0b1ec94ace090b3e9e0abc026ede0a859b8f38a7f1e65874d19af6f11aa8")
