-- Lua provided by RyzenAPI
-- Game: addappid(2726080)

-- MAIN APPLICATION
addappid(2726080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726081, 1, "33c54ca916926e51f4ce3eeb52877b80e000da795a261a1d97793b584f362f2f")
