-- Lua provided by RyzenAPI
-- Game: Game: The Entrepreneur

-- MAIN APPLICATION
addappid(2523910)
-- Game: addappid(2523910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523911, 1, "67e6c922170e8ab03e5bc77540eee6605cced7b1baa9ab3a1e167eb8b914a08f")
