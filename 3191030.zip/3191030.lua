-- Lua provided by RyzenAPI
-- Game: 3191030

-- MAIN APPLICATION
addappid(3191030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191032,0,"fe1f138f1cbca290e8c586f5e6bab023a77a3e86abeeb58de673d1530ad5dc69")

