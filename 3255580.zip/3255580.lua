-- Lua provided by RyzenAPI
-- Game: addappid(3255580)

-- MAIN APPLICATION
addappid(3255580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255581, 1, "91a424609fb5d30688b21ed55284a91aab4bc4fcabf0a01d869bca07aac56b66")
