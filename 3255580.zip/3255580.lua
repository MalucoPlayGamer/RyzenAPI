-- Lua provided by RyzenAPI 
-- Game: AppID 3255580
addappid(3255580)
addappid(3255581, 1, "91a424609fb5d30688b21ed55284a91aab4bc4fcabf0a01d869bca07aac56b66")
