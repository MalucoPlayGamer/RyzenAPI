-- Lua provided by RyzenAPI
-- Game: addappid(2312630)

-- MAIN APPLICATION
addappid(2312630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312631, 1, "9051ce48ed3960dbce345fe1b508105994ee407f07cac93e502af30287997a77")
