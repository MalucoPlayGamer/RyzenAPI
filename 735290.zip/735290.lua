-- Lua provided by RyzenAPI
-- Game: Genesis Noir

-- MAIN APPLICATION
addappid(735290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(735291, 1, "baa69afd24e04db660470ede76abdc4303e56e7817e7ca35ac7139094e832e05")
addappid(735292, 1, "f1c6abd8949ad766837ee601e83c8af689ac18c73c5bfb63188933fe6f32d3db")
addappid(1550160, 0, "ce0e741a4397f62b34ef62b7515a531070ffb5f171d2849c192105f12343d658")
addappid(1550161, 0, "e41be509896afe0da2c1b4521dbe93488b04e6aa62de3c4fe831c8aed72330b8")
addappid(1550162, 0, "b68f7616983a66702fd169e767934c616c2b8264ccda30d5bf4b6acf5bab85cb")

