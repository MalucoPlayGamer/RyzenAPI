-- Lua provided by RyzenAPI
-- Game: Someday You'll Return: Director's Cut

-- MAIN APPLICATION
addappid(2229350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229351, 1, "b840b7438abd16e9c47772fdb3e8ed96c68904da984e5bc212ac7ac501a97153")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
