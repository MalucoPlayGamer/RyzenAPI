-- Lua provided by RyzenAPI
-- Game: 2229350

-- MAIN APPLICATION
addappid(2229350)
-- Game: addappid(2229350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229351, 1, "b840b7438abd16e9c47772fdb3e8ed96c68904da984e5bc212ac7ac501a97153")
