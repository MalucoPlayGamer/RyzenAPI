-- Lua provided by RyzenAPI
-- Game: 3779190

-- MAIN APPLICATION
addappid(3779190)
-- Game: addappid(3779190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3779191, 1, "7bcc298ced116a495598ac3f65054fd7a7de70fa91489899fbf3f27be4c37f70")
