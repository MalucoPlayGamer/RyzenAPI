-- Lua provided by RyzenAPI
-- Game: addappid(417480)

-- MAIN APPLICATION
addappid(417480)

-- MAIN APP DEPOTS / PACKAGES
addappid(417481, 1, "8a0c13f76cd186fa9f0dc61b4b842091ea7687ea2aa138e51f415120cf07e1be")
