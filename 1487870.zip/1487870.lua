-- Lua provided by RyzenAPI
-- Game: AppID 1487870

-- MAIN APPLICATION
addappid(1487870)
-- Game: addappid(1487870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487871, 1, "8ddadc002c68816cbb694f1920e8ab8979e5fccdc43db43a660b4480d1f5902c")
