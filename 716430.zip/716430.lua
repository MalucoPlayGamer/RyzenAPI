-- Lua provided by RyzenAPI
-- Game: addappid(716430)

-- MAIN APPLICATION
addappid(716430)

-- MAIN APP DEPOTS / PACKAGES
addappid(716431, 1, "6842eeefceacd5afcb80792e401c206241d274a6e22154ec9c893bbc2f21dde1")
