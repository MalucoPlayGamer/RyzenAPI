-- Lua provided by SkyAPI 
-- Game: Bug Aviators in Theme Park
addappid(1036270)
addappid(1036271, 1, "a217f7d4a3bdbd2dabcc785c0cce3c38bfaf64ca7e1efbc3c851c6585f1a309e")
addappid(1036272, 1, "39677c1ec87b04e2153d01eca22fcf32434d0f24ff53a835fb2fc55f62f53a4c")
