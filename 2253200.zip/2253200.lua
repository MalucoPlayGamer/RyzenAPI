-- Lua provided by RyzenAPI 
-- Game: The Devil's Face
addappid(2253200)
addappid(2253201, 1, "adf5d408a05e20212f2a6ce6a2fada639e8dc9c766a31035ba4ca721e2eef8f4")
