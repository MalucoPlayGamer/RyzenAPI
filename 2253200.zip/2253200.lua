-- Lua provided by RyzenAPI
-- Game: The Devil's Face

-- MAIN APPLICATION
addappid(2253200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253201, 1, "adf5d408a05e20212f2a6ce6a2fada639e8dc9c766a31035ba4ca721e2eef8f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
