-- Lua provided by RyzenAPI
-- Game: addappid(1026880)

-- MAIN APPLICATION
addappid(1026880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026881, 1, "e362a1cec154cedadc3c2dd52d25e8f9968ef23caedbbf84ef3708d588a2b682")
