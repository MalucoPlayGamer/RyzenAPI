-- Lua provided by SkyAPI 
-- Game: Crafty Survivors Soundtrack
addappid(3763190)
addappid(3763191, 1, "e54d0e32910b0b511a9f11c358261c312815a885d304a004d48c4a5663e0a3d7")
addappid(3763192, 1, "9f40cf7254a017026f9c4266e4b0e96f72aefa8b32e5971febd89d377c90a142")
