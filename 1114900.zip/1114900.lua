-- Lua provided by RyzenAPI
-- Game: Ayo the Clown

-- MAIN APPLICATION
addappid(1114900)
-- Game: addappid(1114900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114902,0,"4d0dfb1470adf86d2ce42dff7d53e580245894fa167c44dba5984d3a544c93e4")
addappid(1114903,0,"d525fed5353b3511fb970fc6dfa0bc9f52cec498485a49361dba667d893c0369")
addappid(1114904,0,"80c553a8ea802988dcb1d78c79e101a68f9b815275e1037b5fa5eb413adfbf45")
