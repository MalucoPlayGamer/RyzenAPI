-- Lua provided by RyzenAPI
-- Game: BM Love Cafe

-- MAIN APPLICATION
addappid(3175720)
-- Game: addappid(3175720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175721, 1, "71573c1731fb949527f6c97d8059f7fc0b56ca2cceec834c0e2e5b04160fc093")
