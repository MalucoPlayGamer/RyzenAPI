-- Lua provided by SkyAPI 
-- Game: Dragons Reef
addappid(3437470)
addappid(3437471, 1, "434a5d77d7491a979403c379d2acef3a748071462a6b78e3fb382ec1f3a7a30e")
