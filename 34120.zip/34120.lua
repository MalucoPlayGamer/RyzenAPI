-- Lua provided by SkyAPI 
-- Game: AppID 34120
addappid(34120)
addappid(34121, 1, "b5d52a0165b1238841871acc34608b6635e195bc7659daa24f1d858b9a2e604c")
