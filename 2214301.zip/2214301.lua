-- Lua provided by RyzenAPI
-- Game: addappid(2214301)

-- MAIN APPLICATION
addappid(2214301)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214301,0,"d1962210f4c034ad3b8d2b8970a3feb71a9db587d49e50fdd1e47f6f9756a4b4")
