-- Lua provided by RyzenAPI
-- Game: The Girl Who Kicked a Rabbit

-- MAIN APPLICATION
addappid(2427130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427132,0,"5bdf51eb160ef45ea4b07bb5b36164322c2d50d2a550f59472118e093e06cb51")

