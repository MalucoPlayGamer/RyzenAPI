-- Lua provided by RyzenAPI
-- Game: nophenia

-- MAIN APPLICATION
addappid(3979330)
-- Game: addappid(3979330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3979331, 1, "47484307c73b1f97a81419da0cb70426e044e7dd2185f4e6f9114b6da96f82dc")
addappid(3979333, 1, "5d7c40f0fc7d50150b87eb63b53266bc15b2730badc04fc30b2bd9d8d9d4f22e")
addappid(3979334, 1, "1f4d041ccc2fbc8ae0612efe77c4edcaef13c212a323f98c15f96fdbe3120228")
