-- Lua provided by RyzenAPI
-- Game: Final Theosis

-- MAIN APPLICATION
addappid(576020)

-- MAIN APP DEPOTS / PACKAGES
addappid(576021, 1, "a93efd09faa1c20e46b6167f35d2800cc573149b393056fcda78fa3a7904896c")

