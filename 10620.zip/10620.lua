-- Lua provided by RyzenAPI 
-- Game: Empire: Total War™ Demo
addappid(10620)
addappid(10621, 1, "7d427ec1717cef428116fe56638e5e6b76c70c04631d9c773310dfb88faace22")
addappid(10622, 1, "4f86c5159a2259d373346ff78db7a7981ca0fd972f364dac67775a668a3ac81b")
addappid(10623, 1, "572c0343fdd63c23673e11f1f6a2f5d3879d3adf887fff7e26a637d7234c722c")
addappid(10624, 1, "4dbfa59cfbd57d6628bebf546d8a07bce9bda13c8b98c12f6f62c877ae1f8879")
