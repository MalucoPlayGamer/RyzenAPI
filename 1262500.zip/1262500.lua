-- Lua provided by RyzenAPI
-- Game: Mirastell

-- MAIN APPLICATION
addappid(1262500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262501, 1, "d6c5ecba456770deb5a6851240fd20e74acc27623a8107a8e6a42a7a850aaf4f")

