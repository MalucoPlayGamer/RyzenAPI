-- Lua provided by RyzenAPI
-- Game: addappid(922090)

-- MAIN APPLICATION
addappid(922090)

-- MAIN APP DEPOTS / PACKAGES
addappid(922091, 1, "5146b3a49ff8c7fdcdb569a6d32bcfb633b04c5f82464148b5ddfdeb0297a55a")
