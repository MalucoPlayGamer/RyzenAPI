-- Lua provided by RyzenAPI
-- Game: Super Indie Karts

-- MAIN APPLICATION
addappid(323670)
-- Game: addappid(323670)

-- MAIN APP DEPOTS / PACKAGES
addappid(323671, 1, "6ac502cd6be4c8be5d6c59a4e229889e6ab3e229bcc66af21c22172e9ce39744")
addappid(323672, 1, "9d9977b338f9f3162c4cfd056a1e234bca507d709ae2f25728afafa0d889f6b6")
addappid(323673, 1, "a850a9ebf1fafaa9b7ddb7919bd892bb11c95158f4cdae83aacbf9e4a566ebda")
addappid(323674, 1, "3f7c0379d369a59670b3be9c865adba055be1fca49934bb37e0c7a8f42562d04")
