-- Lua provided by RyzenAPI
-- Game: 436740

-- MAIN APPLICATION
addappid(436740)
-- Game: addappid(436740)

-- MAIN APP DEPOTS / PACKAGES
addappid(436741, 1, "f3e0ef656ddaac41a465f11d2b320d22a58ad31e1f57d0866937b18431624b42")
