-- Lua provided by RyzenAPI
-- Game: 2985840

-- MAIN APPLICATION
addappid(2985840)
-- Game: addappid(2985840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985841, 1, "e9af02e6c6b881fa85029e349913cafdedd808b4e65dd37ca48dcdf8532b5e16")
