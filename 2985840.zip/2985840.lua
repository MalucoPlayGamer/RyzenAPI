-- Lua provided by SkyAPI 
-- Game: Undead Onslaught
addappid(2985840)
addappid(2985841, 1, "e9af02e6c6b881fa85029e349913cafdedd808b4e65dd37ca48dcdf8532b5e16")
