-- Lua provided by RyzenAPI
-- Game: Game: Godless

-- MAIN APPLICATION
addappid(1677090)
-- Game: addappid(1677090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677091, 1, "86bfe412eae81f415c7f8026420443cd71c905bbb0bbd050a24115aa1aa02567")
