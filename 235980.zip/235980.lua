-- Lua provided by RyzenAPI 
-- Game: Tetrobot and Co.
addappid(235980)
addappid(235981, 1, "d54837ec290fb8741635793d481602e59be799ea927927592ac7fe40cab1a4e9")
addappid(235982, 1, "446ff38144f067788485ada8351e7c07b6c9f57bbf736f8f4ee19221888bc464")
addappid(235983, 1, "f5bf249205e3cd7265fd707ceeab2035bd0611ad090fa4b2d333fa2b63fdd776")
addappid(258470)
