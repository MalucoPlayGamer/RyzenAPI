-- Lua provided by SkyAPI 
-- Game: Scare Girl
addappid(2161810)
addappid(2161811, 1, "33759200ab94c47ba6265d092e74e1b1759ca038ab0514c8648e51f49f975dfc")
