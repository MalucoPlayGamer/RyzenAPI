-- Lua provided by RyzenAPI
-- Game: Survived By

-- MAIN APPLICATION
addappid(606140)
addappid(990760)
addappid(990761)
addappid(990762)

-- MAIN APP DEPOTS / PACKAGES
addappid(606141,0,"eead5ccb0e81ae52326b6ce99d723ec9f43037682495714f56e5e59cf610925a")

