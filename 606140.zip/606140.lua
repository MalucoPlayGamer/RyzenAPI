-- Lua provided by SkyAPI 
-- Game: Survived By
addappid(606140)
addappid(606141, 1, "eead5ccb0e81ae52326b6ce99d723ec9f43037682495714f56e5e59cf610925a")
