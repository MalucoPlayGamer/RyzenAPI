-- Lua provided by RyzenAPI
-- Game: Game: Survived By

-- MAIN APPLICATION
addappid(606140)
-- Game: addappid(606140)

-- MAIN APP DEPOTS / PACKAGES
addappid(606141, 1, "eead5ccb0e81ae52326b6ce99d723ec9f43037682495714f56e5e59cf610925a")
