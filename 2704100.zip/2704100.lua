-- Lua provided by RyzenAPI 
-- Game: Little Heroes
addappid(2704100)
addappid(2704101, 1, "86df36619b578ef0939382d01a6bc16267816fcd7ca17a61d699dce335daa987")
