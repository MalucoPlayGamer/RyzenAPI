-- Lua provided by RyzenAPI
-- Game: Little Heroes

-- MAIN APPLICATION
addappid(2704100)
-- Game: addappid(2704100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704101, 1, "86df36619b578ef0939382d01a6bc16267816fcd7ca17a61d699dce335daa987")
