-- Lua provided by RyzenAPI
-- Game: Toilet Battle Hero

-- MAIN APPLICATION
addappid(3668520)
addappid(3728980)
addappid(3728990)
addappid(3729000)
addappid(3756280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668521, 1, "0f1494b4fc6c354313215a91bfe7714554ecdefaf5c6b4d75a4d5683bc588baf")

