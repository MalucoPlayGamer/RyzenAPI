-- Lua provided by RyzenAPI
-- Game: Toilet Battle Hero

-- MAIN APPLICATION
addappid(3668520)
-- Game: addappid(3668520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668521, 1, "0f1494b4fc6c354313215a91bfe7714554ecdefaf5c6b4d75a4d5683bc588baf")
