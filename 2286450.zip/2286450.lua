-- Lua provided by RyzenAPI
-- Game: Striving for Light: Survival

-- MAIN APPLICATION
addappid(2286450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286451, 1, "960114b97c1a1820c4a4b0520262a54b173816095d97f40025a7a5f5f64dd9f1")
