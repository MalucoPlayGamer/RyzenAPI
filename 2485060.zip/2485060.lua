-- Lua provided by RyzenAPI
-- Game: W.O.L.F

-- MAIN APPLICATION
addappid(2485060)
-- Game: addappid(2485060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485061, 1, "626e47e7a533dbf37918b93a7d366e61950f21bd6d14dde5b0866cee64b042ef")
