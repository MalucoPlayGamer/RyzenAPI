-- Lua provided by RyzenAPI
-- Game: Game: AppID 1263830

-- MAIN APPLICATION
addappid(1263830)
-- Game: addappid(1263830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263831, 1, "9feefc51f73374e4370f4da54ae21ca0fea8cdcbd56489b23bd49a1e051efbed")
addappid(1263832, 1, "8db23b67e192d88131b9c3daa208275a567a43913b030b90da4aafe6a3a60ce6")
