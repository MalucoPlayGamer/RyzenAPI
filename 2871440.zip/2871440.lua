-- Lua provided by RyzenAPI
-- Game: 2871440

-- MAIN APPLICATION
addappid(2871440)
-- Game: addappid(2871440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871441, 1, "177789be0d1f54d2f49a562e606e04c2acf3cf092ed1938a3ce20f70f36254a6")
