-- Lua provided by RyzenAPI
-- Game: Hover Junkers

-- MAIN APPLICATION
addappid(380220)

-- MAIN APP DEPOTS / PACKAGES
addappid(380221, 1, "1964c1d622e487110a985541a60db13beda614635b981c8596c2c4605fea9c88")
