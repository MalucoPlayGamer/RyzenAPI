-- Lua provided by RyzenAPI
-- Game: Baby Goat Billy

-- MAIN APPLICATION
addappid(1461960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461961, 1, "ba26b4c4a5e1017b48529b309cb39e41fc6bc510531bba7f543402c2bddcd67a")
