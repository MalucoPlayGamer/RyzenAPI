-- Lua provided by RyzenAPI
-- Game: Lex Mortis

-- MAIN APPLICATION
addappid(348450)

-- MAIN APP DEPOTS / PACKAGES
addappid(348451, 1, "0b7450db18fb2942892f38c671d664253cfaff23c83eb93072761137ce9cb2f1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
