-- Lua provided by RyzenAPI
-- Game: Lex Mortis

-- MAIN APPLICATION
addappid(348450)

-- MAIN APP DEPOTS / PACKAGES
addappid(348451, 1, "0b7450db18fb2942892f38c671d664253cfaff23c83eb93072761137ce9cb2f1")
