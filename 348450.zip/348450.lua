-- Lua provided by SkyAPI 
-- Game: Lex Mortis
addappid(348450)
addappid(348451, 1, "0b7450db18fb2942892f38c671d664253cfaff23c83eb93072761137ce9cb2f1")
