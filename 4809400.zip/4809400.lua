-- Lua provided by RyzenAPI
-- Game: Longevity: Path of the Immortal

-- MAIN APPLICATION
addappid(4809400)
