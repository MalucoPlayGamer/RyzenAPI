-- Lua provided by RyzenAPI
-- Game: Game: AppID 2237830

-- MAIN APPLICATION
addappid(2237830)
-- Game: addappid(2237830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237831, 1, "3f089ca26611a18ba4f136276573bd2676854d6ea1f1543d9368857cc2ca207f")
