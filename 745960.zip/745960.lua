-- Lua provided by RyzenAPI
-- Game: A Sky Full of Stars 仰望夜空的星辰

-- MAIN APPLICATION
addappid(745960)

-- MAIN APP DEPOTS / PACKAGES
addappid(745961, 1, "309e7f250b9403d01357d409cebb5b5519d20d66d6c611b8f0dc80aa3357e2b0")
addappid(745962, 1, "28310e2072729c6258ec10a03bfa5d2993865e04dc7080d35d08fe474c0da161")
addappid(745963, 1, "ae7a19e08e4bb8ed81df223cd1935c872d77fcf778cc46141ff50a1eaf720f6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
