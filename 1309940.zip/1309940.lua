-- Lua provided by RyzenAPI
-- Game: Game: Lorera

-- MAIN APPLICATION
addappid(1309940)
-- Game: addappid(1309940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309941, 1, "f3d39d4700fe773c343fdc83856d5fed9bc8729b58f6b3b523b7fd3ee2deb50a")
