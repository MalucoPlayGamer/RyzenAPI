-- Lua provided by RyzenAPI
-- Game: FixForce

-- MAIN APPLICATION
addappid(3933150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3933151,0,"f4c9c6ea658b7d50f0dba186316ad4dc2e023b23f2d423271d5ae17c8b05f2a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
