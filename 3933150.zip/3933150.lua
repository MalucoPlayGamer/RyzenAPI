-- Lua provided by RyzenAPI
-- Game: FixForce

-- MAIN APPLICATION
addappid(3933150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3933151,0,"f4c9c6ea658b7d50f0dba186316ad4dc2e023b23f2d423271d5ae17c8b05f2a3")

