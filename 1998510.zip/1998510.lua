-- Lua provided by RyzenAPI
-- Game: BDSM Apocalypse

-- MAIN APPLICATION
addappid(1998510)
-- Game: addappid(1998510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998519,0,"19b9a48cb4af4c9237466cc3ff7f5e66746cf127b8528e9036a8701c3b36b503")
