-- 4601670's Lua and Manifest Created by Hubcap Manifest
-- Visseron Idle
-- Created: July 10, 2026 at 17:28:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4601670, 1, "552d2f6e6ca0e7b558300f2c5a887f35413cf61783c27302fc5eca0188307954") -- Visseron Idle
-- MAIN APP DEPOTS
addappid(4601671, 1, "30ffc5660eb20a99ebbb0efd0f5a9b051b9931d8af027e5ab918d1cc824b3564") -- Depot 4601671
setManifestid(4601671, "1364285071189190169", 542968869)