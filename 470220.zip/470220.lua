-- Lua provided by RyzenAPI
-- Game: UNO

-- MAIN APPLICATION
addappid(470220)

-- MAIN APP DEPOTS / PACKAGES
addappid(470222,0,"2820c6fb1f2edf4a12c136aeb6a9fa7bbbc8dfb9cd49cdd4874f9719215e7d23")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(560940)
addappid(560941)
addappid(571810)
addappid(1246520)
addappid(1253960)
addappid(1253970)
addappid(1557490)
addappid(1563620)
addappid(1563621)
addappid(1599770)
addappid(1636790)
addappid(1755710)
addappid(1756270)
addappid(1903460)
addappid(1903461)
addappid(2997170)
addappid(2997210)
addappid(3180590)
addappid(3180600)
addappid(3976180)
addappid(3976190)
addappid(4084330)
addappid(4084340)
addappid(4093730)
addappid(4093740)
addappid(4502610)
