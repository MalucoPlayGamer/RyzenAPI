-- Lua provided by RyzenAPI
-- Game: UNO

-- MAIN APPLICATION
addappid(470220)
-- Game: addappid(470220)

-- MAIN APP DEPOTS / PACKAGES
addappid(470222,0,"2820c6fb1f2edf4a12c136aeb6a9fa7bbbc8dfb9cd49cdd4874f9719215e7d23")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
