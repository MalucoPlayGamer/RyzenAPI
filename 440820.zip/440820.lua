-- Lua provided by RyzenAPI
-- Game: Game: AppID 440820

-- MAIN APPLICATION
addappid(440820)
-- Game: addappid(440820)

-- MAIN APP DEPOTS / PACKAGES
addappid(440821, 1, "b7326aa9312d03f8acabdcb537792cd63cf4e5b611a7a17a5ae5c3055ccea894")
