-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade - Bloodhunt

-- MAIN APPLICATION
addappid(760160)

-- MAIN APP DEPOTS / PACKAGES
addappid(760162,0,"f17790c22c03b2a644728617e972e55d1cf23f841d19bc5b1fb121881baf6032")
