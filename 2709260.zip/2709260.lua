-- Lua provided by RyzenAPI
-- Game: addappid(2709260)

-- MAIN APPLICATION
addappid(2709260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709261, 1, "f6ba3f93a4fb62f066c89bf4a05250058fa575e0f05b3caf2edcb0b5374e2394")
