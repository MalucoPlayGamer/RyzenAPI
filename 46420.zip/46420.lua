-- Lua provided by RyzenAPI
-- Game: 46420

-- MAIN APPLICATION
addappid(46420)
-- Game: addappid(46420)

-- MAIN APP DEPOTS / PACKAGES
addappid(46421, 1, "54c46cce28b45e868447c614ff28b2b73ebd74a4f300e3691418451d02c05c34")
