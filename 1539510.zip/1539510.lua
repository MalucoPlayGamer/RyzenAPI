-- Lua provided by RyzenAPI
-- Game: Temptations X: Darkest Fantasy

-- MAIN APPLICATION
addappid(1539510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539511, 1, "7b2e234c40966216c4c87bc25fa1f669159b3f161da13835b2658ceda3df2405")
