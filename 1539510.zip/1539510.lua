-- Lua provided by RyzenAPI
-- Game: Temptations X: Darkest Fantasy

-- MAIN APPLICATION
addappid(1539510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539511, 1, "7b2e234c40966216c4c87bc25fa1f669159b3f161da13835b2658ceda3df2405")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
