-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Global Scenery: Africa

-- MAIN APPLICATION
addappid(2126103)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126103,0,"f732a17dbc8b3b744b456cf8f6d81fca28428bd199c0f6076dcc1846481d5326")
