-- Lua provided by RyzenAPI
-- Game: Game: Mandragora Demo

-- MAIN APPLICATION
addappid(2423720)
-- Game: addappid(2423720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423721, 1, "0a103cdf3fdea3fa163e420434b88e25157b36261ef0d20b268df8ed96c9e2d0")
