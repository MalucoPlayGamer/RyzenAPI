-- Lua provided by RyzenAPI
-- Game: SLICE

-- MAIN APPLICATION
addappid(840310)
addappid(1217000)

-- MAIN APP DEPOTS / PACKAGES
addappid(840311, 1, "ce0afa560379c2441b7e357d5dbef7ce332fef3b1085f7768627d2acde49fdd8")
