-- Lua provided by RyzenAPI
-- Game: addappid(1158370)

-- MAIN APPLICATION
addappid(1158370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158371, 1, "ea9d3540ceeb1f8c6c7afb13b6016e03a03d02ce8f2ccf07256b10dfc59f9f80")
addappid(1797210, 0, "9afbe7ea836eca57736c4b607c5654b1efd0af0aaa30b15ee941ef4d67201503")
