-- Lua provided by RyzenAPI
-- Game: Edge Of The Abyss Awaken - Character Skin: Ninjia Girl

-- MAIN APPLICATION
addappid(1880260)
-- Game: addappid(1880260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880261, 1, "8b9c3ca33b8b73208f6d00b6923ac2ab21ea55f99ea3a79acb9d60045a55ded8")
