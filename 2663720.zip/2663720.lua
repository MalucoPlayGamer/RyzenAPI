-- Lua provided by SkyAPI 
-- Game: FORSISTED : The Sacred Souls
addappid(2663720)
addappid(2663721, 1, "a6ff0b161cfa81c044637bdf5d0d23ec00d0d5909be24258fc6fc20563673c7b")
