-- Lua provided by RyzenAPI
-- Game: Cyberpunk 3776

-- MAIN APPLICATION
addappid(343170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(343172,0,"6aa04467d552fb0e20afbbb4eade11471557e746c54ec86586095a023df61256")
addappid(343173,0,"1d80e6f3633fb3e4a8244ac876ffc67128580ecb46050007f9cf26f073c72c49")

