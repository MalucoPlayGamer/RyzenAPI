-- Lua provided by RyzenAPI
-- Game: 2713150

-- MAIN APPLICATION
addappid(2713150)
-- Game: addappid(2713150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2713151, 1, "aad466f5239a9596a4c6f1d88527fffa33ebdd705b19542f0eadc94288e5e767")
