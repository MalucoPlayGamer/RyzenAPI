-- Lua provided by RyzenAPI
-- Game: AppID 3207660

-- MAIN APPLICATION
addappid(3207660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207661, 1, "b82c0586c31e6075a812b1de9d79e4ee23c0bc2ae9b8c3d1106f5d0acfd46b0d")
