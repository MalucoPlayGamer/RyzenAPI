-- Lua provided by RyzenAPI
-- Game: Game: AppID 898140

-- MAIN APPLICATION
addappid(898140)
addappid(904910)
addappid(904911)
-- Game: addappid(898140)

-- MAIN APP DEPOTS / PACKAGES
addappid(898141, 1, "cb36f2353a298c2ddc7180ae6c70361f37f028678e9c1f196bc48e1d55fbbf6d")
