-- Lua provided by RyzenAPI 
-- Game: INVICTA: The Next Queen
addappid(2432450)
addappid(2432451, 1, "1fad598357d6881f6a716897999d7b7db5eb573d2f5ab019cca5463f6bf86891")
