-- Lua provided by RyzenAPI
-- Game: Game: INVICTA: The Next Queen

-- MAIN APPLICATION
addappid(2432450)
-- Game: addappid(2432450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432451, 1, "1fad598357d6881f6a716897999d7b7db5eb573d2f5ab019cca5463f6bf86891")
