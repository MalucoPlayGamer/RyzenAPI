-- Lua provided by RyzenAPI
-- Game: 1573430

-- MAIN APPLICATION
addappid(1573430)
-- Game: addappid(1573430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573431, 1, "ee3b7adaa679cb4291767fe54c2265e7c5ee9da2479adb23e9c47dc29e5dfd98")
