-- Lua provided by RyzenAPI
-- Game: Plebby Quest: The Crusades

-- MAIN APPLICATION
addappid(334310)

-- MAIN APP DEPOTS / PACKAGES
addappid(334311, 1, "85dd89314a030b17c09d905733744e59bdc25adb6ab84c2eee091bfa9c53df49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1558310)
