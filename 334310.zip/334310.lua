-- Lua provided by RyzenAPI
-- Game: Plebby Quest: The Crusades

-- MAIN APPLICATION
addappid(334310)

-- MAIN APP DEPOTS / PACKAGES
addappid(334311, 1, "85dd89314a030b17c09d905733744e59bdc25adb6ab84c2eee091bfa9c53df49")

