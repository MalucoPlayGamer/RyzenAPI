-- Lua provided by RyzenAPI
-- Game: 3402090

-- MAIN APPLICATION
addappid(3402090)
-- Game: addappid(3402090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402090,0,"af24423b8173284c8e56e3430467f9ae0eaacb859552bf0ba1864c17c9afb5d9")
