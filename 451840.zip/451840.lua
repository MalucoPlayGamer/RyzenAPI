-- Lua provided by RyzenAPI
-- Game: 451840

-- MAIN APPLICATION
addappid(451840)
-- Game: addappid(451840)

-- MAIN APP DEPOTS / PACKAGES
addappid(451841, 1, "510137d5cccb824ef9e246997c7390f8c1d00952f9beae3c55745d4b76078c60")
