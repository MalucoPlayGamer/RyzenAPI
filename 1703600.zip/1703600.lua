-- Lua provided by RyzenAPI
-- Game: 1703600

-- MAIN APPLICATION
addappid(1703600)
-- Game: addappid(1703600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703601, 1, "66014c6d74e09c05d890c269e9b325cd24c593dd88f07f90b49c2c4b14d4be1c")
