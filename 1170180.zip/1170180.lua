-- Lua provided by RyzenAPI
-- Game: Beat.School: DJ Simulator

-- MAIN APPLICATION
addappid(1170180)
-- Game: addappid(1170180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170181, 1, "2c718a2551c729038e1bb44e0cc42082a06682d7dfae99bd82bba5160265952a")
