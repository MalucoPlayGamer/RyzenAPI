-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Global Scenery: Australia, Oceania, Pacific

-- MAIN APPLICATION
addappid(2126105)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126105,0,"bcd7afa11f663c96da29723b920eed7e32eeef9482967f8b8b12a4a219f85563")

