-- Lua provided by RyzenAPI
-- Game: Game: Sudoku Jigsaw / 拼图数独

-- MAIN APPLICATION
addappid(858040)
-- Game: addappid(858040)

-- MAIN APP DEPOTS / PACKAGES
addappid(858041, 1, "05098a5977b60b00c01815d2daf936bc716726faf68fbcdc4ca0778778c0c87d")
