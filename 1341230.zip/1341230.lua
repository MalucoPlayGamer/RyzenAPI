-- Lua provided by SkyAPI 
-- Game: AppID 1341230
addappid(1341230)
addappid(1341231, 1, "ef0ddc21f1f8b34a5666754f8ff2694be25aec401198bfa744ec53c74e647ae7")
