-- Lua provided by RyzenAPI
-- Game: addappid(1341230)

-- MAIN APPLICATION
addappid(1341230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341231, 1, "ef0ddc21f1f8b34a5666754f8ff2694be25aec401198bfa744ec53c74e647ae7")
