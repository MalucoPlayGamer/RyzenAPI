-- Lua provided by SkyAPI 
-- Game: BlackSmith HIT
addappid(508170)
addappid(508171, 1, "92556636ca575ea1e3e25a958cb993f5292da388bad202fd4950853af8c39f3b")
addappid(508172, 1, "fcb032cd9832175603e898a7ad75dde89e2dd1ee416c7a7b42b37b687dc7c11e")
addappid(508173, 1, "70e4f4fa733e8b5b41c4c3d79d2aa53adc1d8cff339d56e8f740f5d951f6681a")
