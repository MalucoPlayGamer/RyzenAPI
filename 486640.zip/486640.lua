-- Lua provided by RyzenAPI
-- Game: Cheaters Blackjack 21

-- MAIN APPLICATION
addappid(486640)

-- MAIN APP DEPOTS / PACKAGES
addappid(486641, 1, "11e0b4803812fc9bcd902426fc4430926236e73eee036ebc50eb434eff57b2f7")
addappid(486642, 1, "f56025c36e2faa73d14ef1c2302a2c488e4df069d96b69ba633131355237db81")
