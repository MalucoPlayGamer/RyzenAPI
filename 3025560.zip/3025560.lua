-- Lua provided by RyzenAPI
-- Game: Oceanhorn: Chronos Dungeon

-- MAIN APPLICATION
addappid(3025560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025561, 1, "facaccb8281391a0cbe8c81f48e4a218c6f794d8efd09a77f07143a3b38db85a")
