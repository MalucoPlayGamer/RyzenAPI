-- Lua provided by RyzenAPI
-- Game: Defy Gravity Extended

-- MAIN APPLICATION
addappid(96100)
-- Game: addappid(96100)

-- MAIN APP DEPOTS / PACKAGES
addappid(96105,0,"ed5e1d5573787d40d353ac2363493695f0eba267f5b3b31602d156327b558638")
addappid(451030,0,"398217ef80d1a7176922e0e6f9adea9337067aa2d967bc5d194a95fd2a86ea86")
