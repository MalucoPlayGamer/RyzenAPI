-- Lua provided by RyzenAPI
-- Game: addappid(2463180)

-- MAIN APPLICATION
addappid(2463180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463181, 1, "3a39b6ada21e2a5f9b3475ab2a93d620a4de8fdb48ac6467529d77e18d5bd69b")
