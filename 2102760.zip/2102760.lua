-- Lua provided by RyzenAPI 
-- Game: OVER‧DeviL: Legend of the sacred stone
addappid(2102760)
addappid(2102761, 1, "af5071d1b38831343d1ae657a4d0249a44e0b246713089330cd0554eb5805146")
addappid(2102762, 1, "222a648d3618638ccaa20d5aa859568cf5d58be8ab5b95f14384f089c48cc509")
addappid(2102763, 1, "61900f2acf9510ff3fc6f8250cdb0000910a4aec47aeae675867491a8bfa68b1")
