-- Lua provided by RyzenAPI
-- Game: Discovr™ Egypt: King Tut's Tomb

-- MAIN APPLICATION
addappid(459170)

-- MAIN APP DEPOTS / PACKAGES
addappid(459171, 1, "23249959d0788bba954e92e4918aed1ee0471fba3807a1e57a4e8ba1e9edefe4")
