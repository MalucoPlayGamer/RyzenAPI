-- Lua provided by SkyAPI 
-- Game: Discovr™ Egypt: King Tut's Tomb
addappid(459170)
addappid(459171, 1, "23249959d0788bba954e92e4918aed1ee0471fba3807a1e57a4e8ba1e9edefe4")
