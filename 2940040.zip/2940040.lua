-- Lua provided by RyzenAPI
-- Game: Game: Trolls vs Vikings: Reborn

-- MAIN APPLICATION
addappid(2940040)
-- Game: addappid(2940040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940041, 1, "5da71a4c5ce92ae5f59611776ec9b9c2ee051cc574af66a29a71e2fbcf80d11a")
