-- Lua provided by RyzenAPI
-- Game: 3344370

-- MAIN APPLICATION
addappid(3344370)
-- Game: addappid(3344370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3344371, 1, "6b55e927cc7681ca7cd4d43d037c9a0e980a8d65c0731f70b3e8bdda5dd5b1b8")
