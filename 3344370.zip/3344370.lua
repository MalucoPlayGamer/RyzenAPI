-- Lua provided by RyzenAPI 
-- Game: ZeroSpace Playtest
addappid(3344370)
addappid(3344371, 1, "6b55e927cc7681ca7cd4d43d037c9a0e980a8d65c0731f70b3e8bdda5dd5b1b8")
