-- Lua provided by RyzenAPI
-- Game: 3483400

-- MAIN APPLICATION
addappid(3483400)
-- Game: addappid(3483400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3483400,0,"8f2706fe64f86426091cbb9a23dedbc3ec0c53a78877abb9b549edded5f436ea")
