-- Lua provided by RyzenAPI
-- Game: addappid(3211280)

-- MAIN APPLICATION
addappid(3211280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211281, 1, "af43620bcdd1a237e6393dd272ed7d217f50620b9c33d0c69d2893c0b8399273")
