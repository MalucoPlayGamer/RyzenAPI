-- Lua provided by RyzenAPI
-- Game: Legendary Tales

-- MAIN APPLICATION
addappid(1465070)
addappid(3818820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1465071, 1, "1415a107722524a2fbf0afed7076e502036b7e38e8a8b2be8d290acad9eb6dac")
addappid(2562561, 0, "378693b54e965dcf055312c03b36d9dda7d38da62aa9901c3ed981a9633a9670")

