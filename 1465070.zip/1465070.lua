-- Lua provided by RyzenAPI
-- Game: Legendary Tales

-- MAIN APPLICATION
addappid(1465070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465071, 1, "1415a107722524a2fbf0afed7076e502036b7e38e8a8b2be8d290acad9eb6dac")
addappid(2562561, 0, "378693b54e965dcf055312c03b36d9dda7d38da62aa9901c3ed981a9633a9670")
