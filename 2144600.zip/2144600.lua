-- Lua provided by RyzenAPI
-- Game: Eterspire

-- MAIN APPLICATION
addappid(2144600)

