-- Lua provided by RyzenAPI
-- Game: Game: Face The Abyss

-- MAIN APPLICATION
addappid(3111800)
-- Game: addappid(3111800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111801, 1, "af0f3da13437f846387c8675a54472f0a5debad7eb6986495609a43c0aeae2f2")
