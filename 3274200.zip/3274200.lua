-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3274200)
-- Game: addappid(3274200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274200,0,"230aa54b0a7885f0643ec5d52ceea093584a4b2e4c67ad1301086b9468e1f508")
