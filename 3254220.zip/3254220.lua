-- Lua provided by RyzenAPI
-- Game: 简易指针制作器

-- MAIN APPLICATION
addappid(3254220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3254221,0,"7eaebcc7f5d1131fc18a63109a7c39c05e3d9b77c984a6c24aee9f9711587f4d")

