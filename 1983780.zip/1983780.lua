-- Lua provided by RyzenAPI
-- Game: AppID 1983780

-- MAIN APPLICATION
addappid(1983780)
-- Game: addappid(1983780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983781, 1, "55a7c8ece4e8e6f82dd6c006434dfad6935cc080beb771ba199700deaca172cb")
