-- Lua provided by RyzenAPI
-- Game: AppID 1983780

-- MAIN APPLICATION
addappid(1983780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983781, 1, "55a7c8ece4e8e6f82dd6c006434dfad6935cc080beb771ba199700deaca172cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
