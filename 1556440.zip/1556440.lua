-- Lua provided by RyzenAPI
-- Game: 1556440

-- MAIN APPLICATION
addappid(1556440)
-- Game: addappid(1556440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556441, 1, "a4d8e59320182f29cbc553b900c3bc507f8b00a1a672fc9ce64cc01c1b70fbc4")
