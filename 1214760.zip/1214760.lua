-- Lua provided by RyzenAPI
-- Game: Game: Shine's Adventures 4 (Nightmare)

-- MAIN APPLICATION
addappid(1214760)
-- Game: addappid(1214760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214761, 1, "5fdc74ee4e45616a9f677bdf135527227288011d22ef7b38c7ba2617da8b7af1")
