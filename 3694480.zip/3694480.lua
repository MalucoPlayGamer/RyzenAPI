-- Lua provided by RyzenAPI
-- Game: A Game About Feeding A Black Hole

-- MAIN APP DEPOTS / PACKAGES
addappid(3694480, 1, "7b1d62583c220a3619f49ec1f24532f0c854dfebfd164670728cc641efb0e65e") -- A Game About Feeding A Black Hole
addappid(3694481, 1, "1ceeda365ed01bb83356761229c2cb119ef51c000d5c4d42d7850541cf4fed3d") -- Depot 3694481
addappid(3694482, 1, "f73a2f7ba186d19530f949308999cbbe1e44d5575d7cf389713122454cb3650d") -- Depot 3694482
addappid(3694483, 1, "bd2845a04c5c2ba7d568677d9d591c9904fabd742767184a2127681e2fba009b") -- Depot 3694483

