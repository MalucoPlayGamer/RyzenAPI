-- 3694480's Lua and Manifest Created by Hubcap Manifest
-- A Game About Feeding A Black Hole
-- Created: May 14, 2026 at 16:10:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3694480, 1, "7b1d62583c220a3619f49ec1f24532f0c854dfebfd164670728cc641efb0e65e") -- A Game About Feeding A Black Hole
-- MAIN APP DEPOTS
addappid(3694481, 1, "1ceeda365ed01bb83356761229c2cb119ef51c000d5c4d42d7850541cf4fed3d") -- Depot 3694481
--setManifestid(3694481, "258626587988265684", 320541532)
addappid(3694482, 1, "f73a2f7ba186d19530f949308999cbbe1e44d5575d7cf389713122454cb3650d") -- Depot 3694482
--setManifestid(3694482, "7245555125317086981", 287897772)
addappid(3694483, 1, "bd2845a04c5c2ba7d568677d9d591c9904fabd742767184a2127681e2fba009b") -- Depot 3694483
--setManifestid(3694483, "9148709243848308146", 404122160)