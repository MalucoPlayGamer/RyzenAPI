-- Lua provided by SkyAPI 
-- Game: Assault of the Robots
addappid(1052900)
addappid(1052901, 1, "b7900d31910c37d98bffc0c5874aa85cdfb607e626863595785be86ca4bae006")
