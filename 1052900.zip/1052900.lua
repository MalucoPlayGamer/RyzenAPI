-- Lua provided by RyzenAPI
-- Game: addappid(1052900)

-- MAIN APPLICATION
addappid(1052900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052901, 1, "b7900d31910c37d98bffc0c5874aa85cdfb607e626863595785be86ca4bae006")
