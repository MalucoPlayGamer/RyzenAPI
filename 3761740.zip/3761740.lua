-- Lua provided by RyzenAPI
-- Game: Arrow Dungeon

-- MAIN APPLICATION
addappid(3761740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3761741, 1, "b7c16cc06fe6f6e1b0e9248bf8d048af0a5ee3e8ce9e1b500177d9617b5844c9")
