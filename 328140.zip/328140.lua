-- Lua provided by RyzenAPI
-- Game: Emergency 5 - Deluxe Edition

-- MAIN APPLICATION
addappid(328140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(328141, 1, "ec775b91fc93e5c2e6192fe7bbabf4b2c1c1aac1d04deac87edc3301b3e67876")
addappid(328143, 1, "0a0f878199e9f121d391aaa230be918d2a38117a1a278613a305dd74ee39bff9")
addappid(328148, 1, "f0dec10ba6ef43bad56580b8e2f159a80d342ab9c759cc602b569394d3dc3a51")
addappid(328149, 1, "0d303b1efbf5803196ffe1ccd8837ca540e1b09fc853c23d9394f4f4c28f0743")
