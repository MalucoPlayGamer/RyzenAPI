-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 3 Ex

-- MAIN APPLICATION
addappid(1536080)
-- Game: addappid(1536080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536081, 1, "96084e7502c3f5e2d7b38870706e24b049bace5b7fdafd0246241e9aecf18500")
addappid(1536082, 1, "19e848a23309b28e06a8f6ea13d5a7d880f7a11acf1ae5eebf2b97418b31e629")
addappid(1536083, 1, "5b1117b4c535334235ef9f5e4cdea558e96206edf9176e9937cdc35a3096228a")
