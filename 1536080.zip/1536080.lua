-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 3 Ex

-- MAIN APPLICATION
addappid(1536080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1536081, 1, "96084e7502c3f5e2d7b38870706e24b049bace5b7fdafd0246241e9aecf18500")
addappid(1536082, 1, "19e848a23309b28e06a8f6ea13d5a7d880f7a11acf1ae5eebf2b97418b31e629")
addappid(1536083, 1, "5b1117b4c535334235ef9f5e4cdea558e96206edf9176e9937cdc35a3096228a")

