-- Lua provided by RyzenAPI
-- Game: Trash in the Flower Garden

-- MAIN APPLICATION
addappid(2701360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701361, 1, "e48a8dd5d49080dac91589c96796c64c6634f7bc69f0d68f8bda6ae6fdd3edfe")

