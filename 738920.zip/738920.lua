-- Lua provided by RyzenAPI
-- Game: Sexy Serial Killer

-- MAIN APPLICATION
addappid(738920)

-- MAIN APP DEPOTS / PACKAGES
addappid(738921, 1, "6b2eec2f538c9ed2a2a4f84ad2385936f2d5cf6938ea101a93ee6575ff4f98c3")

