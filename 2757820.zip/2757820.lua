-- Lua provided by RyzenAPI
-- Game: Sensual Adventures - Treasure Island

-- MAIN APPLICATION
addappid(2757820)
addappid(4492140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757821, 1, "21327821c613e14063d8ec3e05e2e3cdbedbdeb5e1050c9f57bda3d3848d91b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
