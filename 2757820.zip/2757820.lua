-- Lua provided by RyzenAPI
-- Game: Game: Sensual Adventures - Treasure Island

-- MAIN APPLICATION
addappid(2757820)
addappid(4492140)
-- Game: addappid(2757820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757821, 1, "21327821c613e14063d8ec3e05e2e3cdbedbdeb5e1050c9f57bda3d3848d91b0")
