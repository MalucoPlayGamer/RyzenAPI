-- Lua provided by RyzenAPI
-- Game: addappid(757330)

-- MAIN APPLICATION
addappid(757330)

-- MAIN APP DEPOTS / PACKAGES
addappid(757331, 1, "60befdef48bd4d4ec033822421f5c2aff63acb19e36f7e794c9676f17c8304b1")
