-- Lua provided by RyzenAPI
-- Game: 1338040

-- MAIN APPLICATION
addappid(1338040)
-- Game: addappid(1338040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338041, 1, "8911dcbe313c35b1019d4d342f813b31cfb22f65726890eb1f9eeaaea5dfc951")
