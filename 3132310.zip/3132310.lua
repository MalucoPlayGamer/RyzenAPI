-- Lua provided by RyzenAPI
-- Game: Restraint combat erotic RPG Elpis Aigis

-- MAIN APPLICATION
addappid(3132310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132312,0,"2c72ed5318bed2ac15048b1b1d68cf9a6edd229998a4aa09be64806ebed7b2be")
addappid(3132313,0,"5a7bde0e193dadcdfcd7216e8ccd108af1af8b838a343ce4331a5c7e5d9817dd")
