-- Lua provided by RyzenAPI
-- Game: Inscryption Soundtrack

-- MAIN APPLICATION
addappid(1752910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752911, 1, "80f569d2b988630a5cc1cbde0330a14b63998f0cec0cbae3b0d1d55151a56ea7")
addappid(1752912, 1, "70a90c244aa045cac996ad39596e36257020ef3cf09f2500468250db9f70fb07")

