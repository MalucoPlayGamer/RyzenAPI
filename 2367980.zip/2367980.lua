-- Lua provided by RyzenAPI
-- Game: Game: The Witch, Wife, & the Wish

-- MAIN APPLICATION
addappid(2367980)
-- Game: addappid(2367980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367981, 1, "c6ecf02fd794b04a016b97d71f47a760cce8f603d5bd03c24e88eb86c125e000")
addappid(2367982, 1, "ab438b650cadad5a414d4c2ed5428508872fc67c686909153bd32b5b0ee71467")
addappid(2367983, 1, "ae078242bc8c71d3580a7aea79c3c7d360f834101c29568dacf9a3939807aefc")
