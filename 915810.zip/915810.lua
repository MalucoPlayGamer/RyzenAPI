-- Lua provided by RyzenAPI
-- Game: AppID 915810

-- MAIN APPLICATION
addappid(915810)
addappid(1938860)
addappid(1938880)
addappid(1945960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(915811, 1, "d7b9540b9686b8d615fa43442db4e31e903d7770c28306479c875f17e92ed930")

