-- Lua provided by RyzenAPI
-- Game: Game: AppID 915810

-- MAIN APPLICATION
addappid(915810)
-- Game: addappid(915810)

-- MAIN APP DEPOTS / PACKAGES
addappid(915811, 1, "d7b9540b9686b8d615fa43442db4e31e903d7770c28306479c875f17e92ed930")
