-- Lua provided by RyzenAPI
-- Game: AppID 924070

-- MAIN APPLICATION
addappid(924070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(924071, 1, "fd33abee36f2c391d26de7805ec480da66a6cc16d482790733e26ad3c9075f52")

