-- Lua provided by RyzenAPI
-- Game: 924070

-- MAIN APPLICATION
addappid(924070)
-- Game: addappid(924070)

-- MAIN APP DEPOTS / PACKAGES
addappid(924071, 1, "fd33abee36f2c391d26de7805ec480da66a6cc16d482790733e26ad3c9075f52")
