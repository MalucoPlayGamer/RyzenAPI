-- Lua provided by RyzenAPI
-- Game: 1453230

-- MAIN APPLICATION
addappid(1453230)
-- Game: addappid(1453230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453231, 1, "8d076015b8daf3fce4cafcf96975497e634ff637f62459c9e6d3796541638ec0")
