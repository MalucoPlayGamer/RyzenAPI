-- Lua provided by RyzenAPI
-- Game: HIIS

-- MAIN APPLICATION
addappid(1453230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1453231, 1, "8d076015b8daf3fce4cafcf96975497e634ff637f62459c9e6d3796541638ec0")

