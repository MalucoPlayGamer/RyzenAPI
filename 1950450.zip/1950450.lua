-- Lua provided by RyzenAPI
-- Game: Game: Loop Queen-Escape Dungeon 3

-- MAIN APPLICATION
addappid(1950450)
addappid(4337600)
-- Game: addappid(1950450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950451, 1, "1ffccddc2535c02d22b5227b4c7297e8eafeae544af23ba786b112d8de379811")
addappid(1950452, 1, "cb2d3980bec0b5e23080bf43d039ad9000204d325e08c7da64487f8a05533530")
