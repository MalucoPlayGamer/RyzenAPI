-- Lua provided by RyzenAPI
-- Game: Farm Frenzy: Hurricane Season

-- MAIN APPLICATION
addappid(361930)
addappid(361931)
addappid(361932)
addappid(361934)
addappid(361935)
addappid(361936)
addappid(361937)
addappid(361938)
addappid(361939)
addappid(361940)
addappid(361941)
-- Game: addappid(361930)

-- MAIN APP DEPOTS / PACKAGES
addappid(361933,0,"e62ce0edb8aefef47bd303cf973cb2e4306c1b0a45e33548db69f4d3e889e662")
