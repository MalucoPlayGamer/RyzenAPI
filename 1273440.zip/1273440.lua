-- Lua provided by RyzenAPI
-- Game: OverDrift Festival

-- MAIN APPLICATION
addappid(1273440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273441, 1, "8378f9c5f0915c3bad49814640ad793a9a9d6562e5609f3b4f5ae304e01f9b1d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1921830)
addappid(1921831)
addappid(1921832)
addappid(1921833)
addappid(2544050)
addappid(2747490)
addappid(2747500)
addappid(2747510)
addappid(2747520)
