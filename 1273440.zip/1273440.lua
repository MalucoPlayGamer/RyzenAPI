-- Lua provided by RyzenAPI
-- Game: Game: OverDrift Festival

-- MAIN APPLICATION
addappid(1273440)
-- Game: addappid(1273440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273441, 1, "8378f9c5f0915c3bad49814640ad793a9a9d6562e5609f3b4f5ae304e01f9b1d")
