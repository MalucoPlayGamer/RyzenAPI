-- Lua provided by RyzenAPI
-- Game: Turtle Racer

-- MAIN APPLICATION
addappid(2225130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225131, 1, "746a7b3ef7337e120b631d97b82e02c84c7200be2270af0829b2ff6b537a5704")

