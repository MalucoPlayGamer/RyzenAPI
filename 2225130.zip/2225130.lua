-- Lua provided by RyzenAPI
-- Game: Turtle Racer

-- MAIN APPLICATION
addappid(2225130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2225131, 1, "746a7b3ef7337e120b631d97b82e02c84c7200be2270af0829b2ff6b537a5704")

