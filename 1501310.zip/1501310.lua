-- 1501310's Lua and Manifest Created by Hubcap Manifest
-- The Ranchers
-- Created: July 30, 2026 at 13:02:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1501310) -- The Ranchers
-- MAIN APP DEPOTS
addappid(1501311, 1, "088b0440005c5c7d768fd5220477fcb73b0079cb37329030b0ec4f6fad0ecb81") -- Depot 1501311
setManifestid(1501311, "6686620497352807145", 14523728092)