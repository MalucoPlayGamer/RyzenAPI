-- Lua provided by RyzenAPI
-- Game: Golf Gang Soundtrack

-- MAIN APPLICATION
addappid(1990840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990844,0,"0408357333733ebf087c321eebe401b6309f60f50cb035ac14a39e4585cd6baa")
addappid(1990846,0,"218d9cf66e6327df2f2392dab2094c52d4fcac0a6c446446386c0ee9ce6e5363")
