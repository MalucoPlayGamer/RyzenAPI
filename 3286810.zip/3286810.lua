-- Lua provided by RyzenAPI
-- Game: Game: Lana Longbeard And The Golden Stacks - Prologue

-- MAIN APPLICATION
addappid(3286810)
-- Game: addappid(3286810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286811, 1, "381aa26ee9d10f615ff0a67a87112ea66eae8eaa2bd307be6b079f612769f933")
