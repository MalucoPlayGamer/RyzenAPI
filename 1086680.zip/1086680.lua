-- Lua provided by RyzenAPI
-- Game: AppID 1086680

-- MAIN APPLICATION
addappid(1086680)
-- Game: addappid(1086680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086681, 1, "db5fa9f34de36643c96d0334babbadcfe9ee5c84c1f22f870a4ea0481b3f4844")
