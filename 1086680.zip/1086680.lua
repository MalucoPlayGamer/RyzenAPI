-- Lua provided by RyzenAPI
-- Game: Violet rE:-The Final reExistence-

-- MAIN APPLICATION
addappid(1086680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1086681, 1, "db5fa9f34de36643c96d0334babbadcfe9ee5c84c1f22f870a4ea0481b3f4844")
