-- Lua provided by RyzenAPI
-- Game: Game: AVA: Dark History

-- MAIN APPLICATION
addappid(1162320)
-- Game: addappid(1162320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162321, 1, "4d579ab18701a0e468bc8f81f1493b5e12501aacef0923ad197452ba7852030b")
