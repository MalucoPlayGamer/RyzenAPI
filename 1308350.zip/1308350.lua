-- Lua provided by RyzenAPI
-- Game: addappid(1308350)

-- MAIN APPLICATION
addappid(1308350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308351, 1, "d0ccf01f483bff8bfc6db99f0c296ee236a3a7d66b790f7cada7e81e7d3ca072")
