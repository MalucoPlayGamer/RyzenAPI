-- Lua provided by RyzenAPI
-- Game: Hideko

-- MAIN APPLICATION
addappid(3256030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3256031, 1, "2b3ee96b7cfcd12620ac007674da2ae97cb241a441c69aecb3372ad894883ab3")
addappid(3256032, 1, "bc4365456b52c8007c75b9b67978d2193811714d44db5e3ba1c28d64236187d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
