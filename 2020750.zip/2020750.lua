-- Lua provided by RyzenAPI
-- Game: addappid(2020750)

-- MAIN APPLICATION
addappid(2020750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020751, 1, "8df056ddd3f977144f33cf40e42b8f8ba8f93659f7cbc57256042c8975f1ac3a")
