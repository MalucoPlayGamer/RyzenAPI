-- 4729260's Lua and Manifest Created by Hubcap Manifest
-- Booty Manners
-- Created: August 11, 2026 at 23:25:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4729260) -- Booty Manners
-- MAIN APP DEPOTS
addappid(4729261, 1, "8a9129a750c1c2ddff787398d9060e8ca6a97babce8ac62c41120c41df2d9529") -- Depot 4729261
setManifestid(4729261, "2919511054534406985", 235650752)
addappid(4729262, 1, "3b92eb57ae44350646c7dd12d1ed50ca138defc73c08daf37314a679d238af1d") -- Depot 4729262
setManifestid(4729262, "601527147305916426", 243264556)