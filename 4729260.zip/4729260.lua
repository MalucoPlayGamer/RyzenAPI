-- Lua provided by RyzenAPI
-- Game: Booty Manners

-- MAIN APPLICATION
addappid(4729260) -- Booty Manners

-- MAIN APP DEPOTS / PACKAGES
addappid(4729261, 1, "8a9129a750c1c2ddff787398d9060e8ca6a97babce8ac62c41120c41df2d9529") -- Depot 4729261
addappid(4729262, 1, "3b92eb57ae44350646c7dd12d1ed50ca138defc73c08daf37314a679d238af1d") -- Depot 4729262

