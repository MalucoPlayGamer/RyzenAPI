-- Lua provided by RyzenAPI
-- Game: NARUTO SHIPPUDEN: Ultimate Ninja STORM 2

-- MAIN APPLICATION
addappid(543870)

-- MAIN APP DEPOTS / PACKAGES
addappid(543871, 1, "3c04bda9a8a328aa4d425eb8c6858a4f7b108a9fa13e390d5e628b949ecb083d")

