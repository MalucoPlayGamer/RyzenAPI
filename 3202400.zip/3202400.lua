-- Lua provided by RyzenAPI
-- Game: Game: Ball Race Party

-- MAIN APPLICATION
addappid(3202400)
-- Game: addappid(3202400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202401, 1, "6292e03d00128ba6935c19b6529c3771e16898f2b53910c7d65b468b33c90d6b")
