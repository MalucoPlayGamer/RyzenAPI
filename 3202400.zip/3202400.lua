-- Lua provided by SkyAPI 
-- Game: Ball Race Party
addappid(3202400)
addappid(3202401, 1, "6292e03d00128ba6935c19b6529c3771e16898f2b53910c7d65b468b33c90d6b")
