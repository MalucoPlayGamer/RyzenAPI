-- Lua provided by SkyAPI 
-- Game: DEATHWATCHERS Demo
addappid(3027360)
addappid(3027361, 1, "8daef9e23060f795d6478a14ad1b21e1801e6bcc3015928b2a963157efc06b2e")
