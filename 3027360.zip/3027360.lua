-- Lua provided by RyzenAPI
-- Game: 3027360

-- MAIN APPLICATION
addappid(3027360)
-- Game: addappid(3027360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027361, 1, "8daef9e23060f795d6478a14ad1b21e1801e6bcc3015928b2a963157efc06b2e")
