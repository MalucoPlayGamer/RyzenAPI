-- Lua provided by RyzenAPI
-- Game: AppID 1210110

-- MAIN APPLICATION
addappid(1210110)
addappid(1353361)
addappid(1353390)
addappid(1398040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1210111, 1, "73cce7a1c4a35fecb022a0f0b83a29e2ae506f394efe17be585437c1707a8bea")
addappid(1210112, 1, "c0d7fed7b2dff1583ace6082f7e29c6d65c5e8d9532b37ad50869d6cf06124b3")
addappid(1353360, 0, "c96d9f90ed0d64f2a7ff7fd9debe3966062960ab737ace9ae9d20b9c65bfd4d2")
addappid(1356050, 0, "408d796bed0e1c3b49e083bac0690bbcea2dce0818da047636029fc2d4658b8b")

