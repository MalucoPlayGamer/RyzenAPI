-- Lua provided by RyzenAPI
-- Game: AppID 998480

-- MAIN APPLICATION
addappid(998480)
-- Game: addappid(998480)

-- MAIN APP DEPOTS / PACKAGES
addappid(998481, 1, "b6ecfa920f0926fb37e9a88b7a7995c10ed0879416e8a7b5411d01cb9bc2b434")
