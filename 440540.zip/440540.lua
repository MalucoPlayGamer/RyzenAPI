-- Lua provided by SkyAPI 
-- Game: Ara Fell: Enhanced Edition
addappid(440540)
addappid(440541, 1, "e3f9e4c86a19ca3b45a137cc4b7fab957e8822897f89ded993762af55fa79639")
addappid(440542, 1, "8e85b75210b140f4cec5a7ce3021483951871e9c14f076869db761a8ec851202")
addappid(440543, 1, "7b2410d08089949d1d6a450257234659ad830bf3165c9f6a662c3d6bfad0ea7b")
