-- Lua provided by RyzenAPI
-- Game: Ambush

-- MAIN APPLICATION
addappid(1602380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602381, 1, "ba5ad339d194f873a9e345c5d47ca447049e9b821bcc0f7bf9f399121fc37380")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
