-- Lua provided by RyzenAPI
-- Game: Game: Ambush

-- MAIN APPLICATION
addappid(1602380)
-- Game: addappid(1602380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602381, 1, "ba5ad339d194f873a9e345c5d47ca447049e9b821bcc0f7bf9f399121fc37380")
