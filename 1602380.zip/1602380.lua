-- Lua provided by RyzenAPI 
-- Game: Ambush
addappid(1602380)
addappid(1602381, 1, "ba5ad339d194f873a9e345c5d47ca447049e9b821bcc0f7bf9f399121fc37380")
