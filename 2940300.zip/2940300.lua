-- Lua provided by RyzenAPI
-- Game: Stickman Strikes: Conquer Fantasy World Demo

-- MAIN APPLICATION
addappid(2940300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940301, 1, "215d969a8ed8433684af6f3b114f5ceb95209af0b8d39982392b4d7afb4bcc17")

