-- Lua provided by RyzenAPI
-- Game: addappid(2437034)

-- MAIN APPLICATION
addappid(2437034)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437034,0,"61dae1e9dc6fc498f1c9d1a2f86d06ec9bae8d73bc5cb82072afa6fed6496c7d")
