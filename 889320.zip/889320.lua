-- Lua provided by RyzenAPI
-- Game: Цветок

-- MAIN APPLICATION
addappid(889320)
-- Game: addappid(889320)

-- MAIN APP DEPOTS / PACKAGES
addappid(889321, 1, "5fb44517a2cc55ba3efdf2e1e57befe31cbabe0be1bc11420c481a2e1439f82e")
