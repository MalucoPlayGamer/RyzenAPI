-- Lua provided by RyzenAPI
-- Game: AppID 2529400

-- MAIN APPLICATION
addappid(2529400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529401, 1, "0a46f05a9308538701d49df512345e56e21722a31137c1ee5cc0617c6273b6c6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2530190)
addappid(2648500)
addappid(2650700)
