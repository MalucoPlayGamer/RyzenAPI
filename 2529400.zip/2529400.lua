-- Lua provided by RyzenAPI
-- Game: Legend of Peks

-- MAIN APPLICATION
addappid(2529400)
addappid(2530190)
addappid(2648500)
addappid(2650700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529401, 1, "0a46f05a9308538701d49df512345e56e21722a31137c1ee5cc0617c6273b6c6")

