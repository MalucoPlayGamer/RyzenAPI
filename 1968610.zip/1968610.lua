-- Lua provided by RyzenAPI
-- Game: addappid(1968610)

-- MAIN APPLICATION
addappid(1968610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968611, 1, "705d122fb35d8afcd2c5d3354a61cb49618392a595a39452441d4ab9cf0b4729")
