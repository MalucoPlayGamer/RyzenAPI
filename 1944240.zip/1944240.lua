-- Lua provided by SkyAPI 
-- Game: Touch Some Grass
addappid(1944240)
addappid(1944241, 1, "6ecea9076b75c0b46017e19580d77d10be8ee08ceedaf3330b9710b264ed5caf")
addappid(1944242, 1, "65fdf728772f10b41db2ab5a6ad01e31385a156abfe9ae7383a1e3a53ca48a6e")
