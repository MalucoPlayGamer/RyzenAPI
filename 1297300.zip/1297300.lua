-- Lua provided by RyzenAPI
-- Game: 1297300

-- MAIN APPLICATION
addappid(1297300)
-- Game: addappid(1297300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297301, 1, "e288d5efaff30c86b4f76c9bf803a1b9cada07fa149c403f71d182ef086920e3")
