-- Lua provided by RyzenAPI 
-- Game: AppID 1297300
addappid(1297300)
addappid(1297301, 1, "e288d5efaff30c86b4f76c9bf803a1b9cada07fa149c403f71d182ef086920e3")
