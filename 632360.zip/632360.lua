-- Lua provided by RyzenAPI
-- Game: Game: Risk of Rain 2

-- MAIN APPLICATION
addappid(632360)
addappid(1607890)
addappid(2306620)
-- Game: addappid(632360)

-- MAIN APP DEPOTS / PACKAGES
addappid(632361, 1, "074d702b52f219d0d3440d09a1ded40e4ab4468c8a77b96dd97b1467a3e1a9f0")
