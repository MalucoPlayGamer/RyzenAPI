-- Lua provided by RyzenAPI
-- Game: Pipistrello and the Cursed Yoyo

-- MAIN APPLICATION
addappid(2870350)
-- Game: addappid(2870350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870351, 1, "014e88c9a0e9fc00ffb0740ed4f56b6ed3383525d7d73c9932091454621d2034")
