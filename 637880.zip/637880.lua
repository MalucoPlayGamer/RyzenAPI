-- Lua provided by RyzenAPI
-- Game: AppID 637880

-- MAIN APPLICATION
addappid(637880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(637881, 1, "14ceb5a83034cf2bfca3ee00c8545d739d6b034596b5327fe1ee18180256d0ab")
addappid(637882, 1, "2ff8026a7cdf71ee9259d5f7d6f7cf9b153f0a3bdca35107976d53842cf9c9f4")

