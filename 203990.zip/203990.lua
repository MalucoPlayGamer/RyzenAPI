-- Lua provided by RyzenAPI
-- Game: 203990

-- MAIN APPLICATION
addappid(203990)
-- Game: addappid(203990)

-- MAIN APP DEPOTS / PACKAGES
addappid(203991, 1, "52bfd4631a2b41a644884f71d749a71c5efaa6c6349ca496cc83b44371e05854")
addappid(203992, 1, "54ce634d9a9556e59e4190dd25831a8cb7a612bd0b6c142c58e5afcdff1400ca")
