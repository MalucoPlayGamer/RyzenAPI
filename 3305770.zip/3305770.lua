-- Lua provided by RyzenAPI
-- Game: Flipper Frenzy

-- MAIN APPLICATION
addappid(3305770)
-- Game: addappid(3305770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3305771, 1, "afd311e4972d48ff3a65f7af20c00f6a603f596400f67c792723937e325ff0b8")
