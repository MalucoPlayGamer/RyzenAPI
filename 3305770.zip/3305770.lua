-- Lua provided by RyzenAPI
-- Game: Flipper Frenzy

-- MAIN APPLICATION
addappid(3305770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3305771, 1, "afd311e4972d48ff3a65f7af20c00f6a603f596400f67c792723937e325ff0b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
