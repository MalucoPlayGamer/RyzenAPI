-- Lua provided by RyzenAPI
-- Game: addappid(2594030)

-- MAIN APPLICATION
addappid(2594030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594030,0,"297d194cfd1c31d494974ef29a53b79fcd3fd53f7c25c93c12c4fa68ad1f9c33")
