-- Lua provided by RyzenAPI
-- Game: Serious Sam 2017 Dedicated Server

-- MAIN APPLICATION
addappid(564390)

-- MAIN APP DEPOTS / PACKAGES
addappid(564391, 1, "8efb3ca4ae8577c711681b907c415a12f42e93684bf0eafd7a56cca1d4551029")
addappid(564392, 1, "dbc0d40f9f0ea1e446e59d0c529e2c836847a792d5e08d838925fb9ab4272b59")
addappid(564393, 1, "173855ee4c9c42b1f57f4225c64d26a7efb0856529e6e8138651c29ad0aeeae9")

