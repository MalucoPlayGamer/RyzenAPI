-- Lua provided by RyzenAPI
-- Game: Natural Instincts: European Forest

-- MAIN APPLICATION
addappid(1168610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168611, 1, "ec49e8fd01eb9bb1115c892f2f51b496012eccd262c50cec4d3bb838d5011235")
addappid(1168612, 1, "5698a481674498d28fb2305c07ae1b3a661f7b4a3c84b5edee57d33f833e0d68")
