-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(596500)
addappid(596501)
addappid(596503)
-- Game: addappid(596500)

-- MAIN APP DEPOTS / PACKAGES
addappid(596502,0,"6a6dad5ed8cd561bc260dd7335d00ef65c733bb1b58aaf085c1ed154c0530f23")
