-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(596500)
addappid(228989)
-- setManifestid(228989,"550968249685141759")
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(596501)
addappid(596502,0,"6a6dad5ed8cd561bc260dd7335d00ef65c733bb1b58aaf085c1ed154c0530f23")
-- setManifestid(596502,"4396382713455874558")
addappid(596503)