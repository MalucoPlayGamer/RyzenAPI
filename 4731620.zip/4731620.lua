-- 4731620's Lua and Manifest Created by Hubcap Manifest
-- Fortune Mill
-- Created: June 13, 2026 at 15:59:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4731620, 1, "323e0c812438942073346a9b370c6bdad31486ba3878de1a7421611b692db30d") -- Fortune Mill
-- MAIN APP DEPOTS
addappid(4731621, 1, "978b2c28748a6230e06184bdf0f1ba24eacbcf10c6ae1de8a88495c9e94b6370") -- Depot 4731621
setManifestid(4731621, "359352785110084", 285975610)
addappid(4731622, 1, "820fb39b6a0511676b4205940b0836a065014b20ac197c52b31063ede2537cad") -- Depot 4731622
setManifestid(4731622, "1806200437534226287", 465226910)