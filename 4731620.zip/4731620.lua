-- 4731620's Lua and Manifest Created by Hubcap Manifest
-- Fortune Mill
-- Created: June 06, 2026 at 02:48:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4731620) -- Fortune Mill
-- MAIN APP DEPOTS
addappid(4731621, 1, "978b2c28748a6230e06184bdf0f1ba24eacbcf10c6ae1de8a88495c9e94b6370") -- Depot 4731621
setManifestid(4731621, "109895295367900101", 285975642)