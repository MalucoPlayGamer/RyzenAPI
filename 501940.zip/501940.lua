-- Lua provided by RyzenAPI
-- Game: Hikikomori No Chuunibyou

-- MAIN APPLICATION
addappid(501940)

-- MAIN APP DEPOTS / PACKAGES
addappid(501941, 1, "37d28ae3c52ef678781182a8ed98362df16d166ff612e471aface13fab85884a")

