-- Lua provided by RyzenAPI 
-- Game: Flying Hero VR
addappid(1314300)
addappid(1314301, 1, "c2a203d327c00b8dd7aac5c8dee1e93ad045886c60894b9f2f72953164e38c8b")
addappid(1314302, 1, "5efd756415b2fe150e980118b125f4829eac25f707291398d68e5cec36e8f058")
