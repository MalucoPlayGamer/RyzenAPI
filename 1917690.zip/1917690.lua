-- Lua provided by RyzenAPI 
-- Game: Any World Demo
addappid(1917690)
addappid(1917691, 1, "0d737db8e8fb198cefb1bd738b57e2a725c637228b0c096c20c90e2ea78ee1c8")
