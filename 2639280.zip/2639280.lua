-- Lua provided by RyzenAPI
-- Game: Game: 𣸩

-- MAIN APPLICATION
addappid(2639280)
-- Game: addappid(2639280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639281, 1, "5497cc8f39bad4e4483dada97bbac8bd50a7cadee795b0b3c4268500e4f5be6b")
