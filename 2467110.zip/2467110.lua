-- Lua provided by RyzenAPI
-- Game: addappid(2467110)

-- MAIN APPLICATION
addappid(2467110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467111, 1, "b6a313fc79124abf6e1877db37a8b763df3a5c4aa50490e1ef5ac5fdb8788805")
