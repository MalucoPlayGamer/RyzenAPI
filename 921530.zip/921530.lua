-- Lua provided by RyzenAPI
-- Game: Demon King Domination: Deluxe Edition

-- MAIN APPLICATION
addappid(921530)

-- MAIN APP DEPOTS / PACKAGES
addappid(921531, 1, "57791497e4d6cb9c0b550cb48ec677abb28539d2333150a6f6f789736cfc9daf")
addappid(921532, 1, "a1c4d60952dbbce7b8095ee4f39e161bb8479725f343291b9324a0204b0fa9ea")
addappid(921533, 1, "86e7bfc804cfe91b930e9734f49d09c47b190f91368b1052ac1c62e6e9aca37d")
addappid(921534, 1, "c1c8c899fd64ea66d5e8b2ee9cb171ee7657e4f5cbb8496a535bed33d76b4956")
