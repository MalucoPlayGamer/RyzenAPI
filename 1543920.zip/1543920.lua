-- Lua provided by RyzenAPI
-- Game: GroundFall Demo

-- MAIN APPLICATION
addappid(1543920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543921, 1, "b0e0920937d4fd39418216fdd5d5a7ac58322e3c2440898c22d2f053c9e7327b")
