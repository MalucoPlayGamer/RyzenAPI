-- Lua provided by RyzenAPI
-- Game: Game: Plot of the Druid

-- MAIN APPLICATION
addappid(1108170)
-- Game: addappid(1108170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108171, 1, "8e677a65238208ff8f9be7787c8843245a4c0d6805b1fdaddaa34c663db81c7d")
