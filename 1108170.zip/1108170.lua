-- Lua provided by RyzenAPI
-- Game: Plot of the Druid

-- MAIN APPLICATION
addappid(1108170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1108171, 1, "8e677a65238208ff8f9be7787c8843245a4c0d6805b1fdaddaa34c663db81c7d")

