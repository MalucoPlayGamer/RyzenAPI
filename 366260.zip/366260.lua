-- Lua provided by RyzenAPI
-- Game: Game: METAL SLUG 2

-- MAIN APPLICATION
addappid(366260)
-- Game: addappid(366260)

-- MAIN APP DEPOTS / PACKAGES
addappid(366261, 1, "69b8102179125157d9dcb8e8877acff2c4b338ea684fe60fae1d6039c800dbb6")
