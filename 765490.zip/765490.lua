-- Lua provided by SkyAPI 
-- Game: AppID 765490
addappid(765490)
addappid(765491, 1, "bde881c371e18f624626da0d8d5367b90a8c1fbd8fe0b74feaf4596201956ebb")
addappid(838600, 0, "4c0f8240523b51d2cc6e27db52dc131b78dc4d8d97a169dd752c0c2d38d66122")
