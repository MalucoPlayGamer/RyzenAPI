-- Lua provided by RyzenAPI
-- Game: addappid(1903640)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1903640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903642,0,"b60e4bcf0c180947147c7ed1e9a7a4782ff0775058dea6c93d9e301dcd94569f")
