-- Lua provided by RyzenAPI
-- Game: Game: Fish to Dish: Idle Sushi

-- MAIN APPLICATION
addappid(3399960)
addappid(3794640)
-- Game: addappid(3399960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399961, 1, "75fff869bf1e3b3efae630f35b85d7c3d28a1b63925fd400453e875bc455ab0d")
