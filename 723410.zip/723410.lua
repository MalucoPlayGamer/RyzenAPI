-- Lua provided by RyzenAPI
-- Game: Doomtrooper CCG

-- MAIN APPLICATION
addappid(723410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(723411, 1, "5ede76c227957adb9d6f044535e3abcb6a069467981b21baf215b60bddec74fc")
addappid(723412, 1, "53c87698a9e3572d6393232ad06a32d0a8ec8614cbca5da8dc23321d8b372166")
addappid(723413, 1, "ba65a19da483504d3fc20aa4e431e025daccf5e5f76cb747477e48fa1d10d06e")

