-- Lua provided by RyzenAPI
-- Game: 1544260

-- MAIN APPLICATION
addappid(1544260)
-- Game: addappid(1544260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544261, 1, "70b01d08a30db72bcee5a75db27ec4a16c227a9b46aa13b11eb46e416fb20fb4")
