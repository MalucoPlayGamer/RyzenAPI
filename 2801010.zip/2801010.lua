-- Lua provided by RyzenAPI 
-- Game: KICK ME!
addappid(2801010)
addappid(2801011, 1, "744f9bf351904cce4eb93a7561b32a54f3ae9efde51de3dcf97bcccae0f2ba93")
