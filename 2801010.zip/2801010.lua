-- Lua provided by RyzenAPI
-- Game: KICK ME!

-- MAIN APPLICATION
addappid(2801010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2801011, 1, "744f9bf351904cce4eb93a7561b32a54f3ae9efde51de3dcf97bcccae0f2ba93")

