-- Lua provided by RyzenAPI
-- Game: The Test: Hypothesis Rising

-- MAIN APPLICATION
addappid(1282200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1282201, 1, "966764ff6a277719faf61655ab8071838dedcd31058fd72d748a6460a667e1d3")

