-- 4676380's Lua and Manifest Created by Hubcap Manifest
-- Grind 'Em All
-- Created: July 20, 2026 at 12:44:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4676380) -- Grind 'Em All
-- MAIN APP DEPOTS
addappid(4676381, 1, "a00a6c3276673a5715b1a7f1f5dcd46a91ae2b71a2322ada24c189806e124bd0") -- Depot 4676381
setManifestid(4676381, "5401585330793893381", 225112924)