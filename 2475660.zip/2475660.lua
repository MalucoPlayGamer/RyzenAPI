-- Lua provided by RyzenAPI
-- Game: Cozy Keep Demo

-- MAIN APPLICATION
addappid(2475660)
-- Game: addappid(2475660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475661, 1, "824d34a31ccf83d65c7ecba337b0741bec4d41d4c0db9442edfb8d5de438ac3e")
