-- Lua provided by RyzenAPI
-- Game: Game: The Maze Escaper

-- MAIN APPLICATION
addappid(1371120)
-- Game: addappid(1371120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371121, 1, "15a82ac06d2830d700c927dc3e5a47d0652ef9997f5ad04a58cc93b4460ae9e6")
