-- Lua provided by RyzenAPI
-- Game: Granblue Fantasy: Relink

-- MAIN APPLICATION
addappid(881020)
addappid(2183570)
addappid(2694640)
addappid(2694650)
addappid(2694660)
addappid(2694670)
addappid(2710000)
addappid(2782160)
addappid(2782170)
addappid(2782180)
addappid(2782190)
addappid(2782200)
addappid(2799840)
addappid(2799850)
addappid(2853950)
addappid(2853960)
addappid(2853970)
addappid(2853980)
addappid(2853990)
addappid(2854000)
addappid(2854010)
addappid(2854020)
addappid(2944840)
addappid(2944850)
addappid(2944860)
addappid(2944870)
addappid(2944880)
addappid(2944890)
addappid(2944900)

-- MAIN APP DEPOTS / PACKAGES
addappid(881021, 1, "87a89e2a3e05613b1fa823d2a8d3796cb8e38972563f929ba9bee212ece2a40f")

