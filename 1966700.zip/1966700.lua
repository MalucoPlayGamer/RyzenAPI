-- Lua provided by RyzenAPI
-- Game: Windfolk: Sky is just the Beginning

-- MAIN APPLICATION
addappid(1966700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966701, 1, "104b323223dd3726f2b15eb06f9ac77eb86bc644a081fc44c8e12ea61ca9723d")
