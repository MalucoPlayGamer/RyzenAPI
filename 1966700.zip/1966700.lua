-- Lua provided by SkyAPI 
-- Game: Windfolk: Sky is just the Beginning
addappid(1966700)
addappid(1966701, 1, "104b323223dd3726f2b15eb06f9ac77eb86bc644a081fc44c8e12ea61ca9723d")
