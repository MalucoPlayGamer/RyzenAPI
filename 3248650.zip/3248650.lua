-- Lua provided by RyzenAPI
-- Game: JOBifAI

-- MAIN APPLICATION
addappid(3248650)
-- Game: addappid(3248650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248652,0,"f0c1469d0f055890f59f7b773d104b96527d91d8e5a658060f14926bafee20a5")
