-- Lua provided by RyzenAPI
-- Game: Class of '09: The Flip Side

-- MAIN APPLICATION
addappid(2757330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757331, 1, "d946e6c07a904fab0e7e0edfc2d127ec160c81f34924f2609896c23f4707b2a1")
