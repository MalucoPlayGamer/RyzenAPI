-- Lua provided by SkyAPI 
-- Game: Class of '09: The Flip Side
addappid(2757330)
addappid(2757331, 1, "d946e6c07a904fab0e7e0edfc2d127ec160c81f34924f2609896c23f4707b2a1")
