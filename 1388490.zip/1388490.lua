-- Lua provided by RyzenAPI
-- Game: 1388490

-- MAIN APPLICATION
addappid(1388490)
-- Game: addappid(1388490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388491, 1, "f92b6dc35ab727c8e5b41d6ec4961c4e3fa1c9f593f3565d73716b8909afa6a3")
