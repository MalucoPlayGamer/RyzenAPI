-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Global Scenery: North America

-- MAIN APPLICATION
addappid(2126100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126100,0,"316aad671d9560fc08df579689455ce826de2d37e01cd82e3261619d28078d54")
