-- Lua provided by RyzenAPI
-- Game: 1348390

-- MAIN APPLICATION
addappid(1348390)
-- Game: addappid(1348390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348391, 1, "83dd23f8ebf15429ba37eb351292fe512f84998e9f0a1730c39cf0ee9ae14f7c")
