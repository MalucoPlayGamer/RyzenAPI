-- Lua provided by SkyAPI 
-- Game: I am an Air Traffic Controller 4
addappid(1348390)
addappid(1348391, 1, "83dd23f8ebf15429ba37eb351292fe512f84998e9f0a1730c39cf0ee9ae14f7c")
