-- Lua provided by RyzenAPI
-- Game: I am an Air Traffic Controller 4

-- MAIN APPLICATION
addappid(1348390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348391, 1, "83dd23f8ebf15429ba37eb351292fe512f84998e9f0a1730c39cf0ee9ae14f7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1453720)
addappid(1839300)
addappid(2314640)
addappid(2659940)
addappid(2670310)
