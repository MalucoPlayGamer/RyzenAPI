-- Lua provided by RyzenAPI 
-- Game: AppID 2456320
addappid(2456320)
addappid(2456321, 1, "1887559f9405b07599d67f70af5be98a15940ef9b36e0642380a21516f9236b9")
