-- Lua provided by RyzenAPI
-- Game: Cervus Blade

-- MAIN APPLICATION
addappid(2456320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2456321, 1, "1887559f9405b07599d67f70af5be98a15940ef9b36e0642380a21516f9236b9")

