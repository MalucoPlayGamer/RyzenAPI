-- Lua provided by RyzenAPI
-- Game: Queen's Quest: Tower of Darkness

-- MAIN APPLICATION
addappid(390200)

-- MAIN APP DEPOTS / PACKAGES
addappid(390201, 1, "ca9fde3ed43b6fac0a94d7679d7b651dbd50e8bc3f5d577db7e0d12f21b90820")
