-- Lua provided by RyzenAPI
-- Game: 3422700

-- MAIN APPLICATION
addappid(3422700)
-- Game: addappid(3422700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422702,0,"f5b059ef5f75926e998475daa7dad8ad5bd6b30bad7328f2f38e55843c60e5fc")
