-- Lua provided by RyzenAPI
-- Game: Factory Outlet Simulator

-- MAIN APPLICATION
addappid(2981590)
-- Game: addappid(2981590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981591, 1, "5a6db8bb15eeaa91122159bb74280599ad225e066e12d734fa66940fd6758905")
