-- Lua provided by RyzenAPI
-- Game: River City Saga: Three Kingdoms

-- MAIN APPLICATION
addappid(1013220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1013221, 1, "245761dac7fd224f5bbc07b1b2c9bbb420edcf65007bd5d118d88100808e861c")

