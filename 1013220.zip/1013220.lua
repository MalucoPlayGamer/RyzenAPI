-- Lua provided by RyzenAPI
-- Game: 1013220

-- MAIN APPLICATION
addappid(1013220)
-- Game: addappid(1013220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013221, 1, "245761dac7fd224f5bbc07b1b2c9bbb420edcf65007bd5d118d88100808e861c")
