-- Lua provided by RyzenAPI
-- Game: Unreal Strike

-- MAIN APPLICATION
addappid(2417360)
addappid(2492700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2417361, 1, "745b288d164c590a95f1acae62fa3a78415c2de12b779c517c3dd2c50ffa0af6")
