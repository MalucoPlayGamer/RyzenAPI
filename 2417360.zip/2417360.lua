-- Lua provided by RyzenAPI
-- Game: AppID 2417360

-- MAIN APPLICATION
addappid(2417360)
-- Game: addappid(2417360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417361, 1, "745b288d164c590a95f1acae62fa3a78415c2de12b779c517c3dd2c50ffa0af6")
