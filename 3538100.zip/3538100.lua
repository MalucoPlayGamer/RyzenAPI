-- Lua provided by RyzenAPI 
-- Game: Mouse
addappid(3538100)
addappid(3538101, 1, "f7d71567aeb2246296fdd82d427f1a58dc2f9378e13542436921bcbbbeb1efc9")
