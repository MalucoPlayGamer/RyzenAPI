-- Lua provided by RyzenAPI
-- Game: Mouse

-- MAIN APPLICATION
addappid(3538100)
-- Game: addappid(3538100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538101, 1, "f7d71567aeb2246296fdd82d427f1a58dc2f9378e13542436921bcbbbeb1efc9")
