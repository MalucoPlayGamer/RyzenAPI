-- Lua provided by RyzenAPI
-- Game: addappid(1915620)

-- MAIN APPLICATION
addappid(1915620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915620,0,"0fd8ad2d8accc6ba4b6dca249dc76a9bfbda845a5e3336fbf2d3ac0707c60cd4")
