-- Lua provided by RyzenAPI
-- Game: addappid(2780470)

-- MAIN APPLICATION
addappid(2780470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780471, 1, "9f6fd8fe81cad0b0a76da19c447b4be1639cd14b8223fe65e50494f4da469830")
