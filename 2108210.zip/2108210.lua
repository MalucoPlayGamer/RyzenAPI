-- Lua provided by RyzenAPI
-- Game: Game: ENDER OCEAN - Your mission: "Clean the Ocean"

-- MAIN APPLICATION
addappid(2108210)
-- Game: addappid(2108210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108211, 1, "63c718943555a5f58c3239fd979b21e19b5f7f249820fc30bfb9f5fd94bab4b0")
addappid(2108212, 1, "7c6f2ec46f90c1a7d038b7eb946e60d5395bae35eb6034d2336321c78e7177fd")
addappid(2108213, 1, "3496b66dda17c252486468944c4aa422e26b5147c0bc964e82e58016f6dd0270")
