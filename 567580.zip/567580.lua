-- Lua provided by RyzenAPI
-- Game: Game: Duke of Alpha Centauri

-- MAIN APPLICATION
addappid(567580)
-- Game: addappid(567580)

-- MAIN APP DEPOTS / PACKAGES
addappid(567581, 1, "476a44785809ff7dd5ebe7858716d6805d886719f1001583a62f471d52d414b5")
addappid(567582, 1, "2e4135ed62571a6fd122b47d0cd1a21c42cf003c9a348afe7885eabc04ab6dce")
addappid(567583, 1, "829b81e5a4d81e091db9cfc0d0a20aa83e7387db4f955731adfd4d0d1a35fc76")
addappid(567584, 1, "f9cf1ec047dad17f072890c2f8e7d20d0cd2e3b9b6cb4f116d5ffd17d45624ce")
addappid(567585, 1, "799df18a62ccbd3006c9b7983dd535a5556c88976dcfd095c4200505e478865d")
addappid(567586, 1, "b8e57a468b24ca06bed6ec260a5fa44445765f249c33db75f68f6d2a2d577327")
