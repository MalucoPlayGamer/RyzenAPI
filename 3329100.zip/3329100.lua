-- Lua provided by RyzenAPI
-- Game: addappid(3329100)

-- MAIN APPLICATION
addappid(3329100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3329101, 1, "ae81a943862b789cfcd8930d16b609cc824f720449a4c2c20a5418f7e56bae3c")
