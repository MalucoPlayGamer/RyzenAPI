-- Lua provided by RyzenAPI
-- Game: Game: Puzzle Light

-- MAIN APPLICATION
addappid(1606300)
-- Game: addappid(1606300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606301, 1, "de968b89cde46409c1721e3232d2c7df3d330b2f10005376b2a6bf9f48e66017")
