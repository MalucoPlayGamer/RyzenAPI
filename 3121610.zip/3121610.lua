-- Lua provided by RyzenAPI
-- Game: AppID 3121610

-- MAIN APPLICATION
addappid(3121610)
-- Game: addappid(3121610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3121611, 1, "2e18d3a779f9c81e8905eaaffdd21536dc355ba5415faab798f6364bcf3e299c")
