-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Radioactive"

-- MAIN APPLICATION
addappid(1099582)
-- Game: addappid(1099582)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099582,0,"5b502a81735b8d79e123c4c1ff9aeb52d22a796b8dd035701c8e492e71b17545")
