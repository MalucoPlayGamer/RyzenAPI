-- Lua provided by RyzenAPI
-- Game: Game: 骑士派对

-- MAIN APPLICATION
addappid(2520770)
-- Game: addappid(2520770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520771, 1, "568315870a01bf5e812386dd7c12b2410b847d38b2f60483f27c33d6db85eba0")
