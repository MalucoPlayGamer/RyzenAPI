-- Lua provided by RyzenAPI
-- Game: COGEN: Sword of Rewind - Additional Story ＆ Playable Character: Copen (Gunvolt Chronicles: Luminous Avenger iX 2) / COGEN: 大鳥こはくと刻の剣 - 追加シナリオ＆プレイ可能キャラクター：アキュラ編（『白き鋼鉄のX（イクス）2』より）

-- MAIN APPLICATION
addappid(1644070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644070,0,"8c35038ca15f02195b7dbc947e69f44dbf7e011c4eba384ec9c0a53a17b2e06d")
