-- Lua provided by RyzenAPI
-- Game: addappid(1644070)

-- MAIN APPLICATION
addappid(1644070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644070,0,"8c35038ca15f02195b7dbc947e69f44dbf7e011c4eba384ec9c0a53a17b2e06d")
