-- Lua provided by RyzenAPI 
-- Game: AppID 2568540
addappid(2568540)
addappid(2568541, 1, "4e905a14a331a92cf6f4f66c8c863591f550ab32a4b1f8f2b143af36a23a0842")
