-- Lua provided by RyzenAPI
-- Game: 741320

-- MAIN APPLICATION
addappid(741320)
-- Game: addappid(741320)

-- MAIN APP DEPOTS / PACKAGES
addappid(741321, 1, "d93d20f50ddf991ccf9d2fd1fe2409da8c13b253b17a0a4cda79164333fd334c")
