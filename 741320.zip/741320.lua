-- Lua provided by RyzenAPI
-- Game: The Song of Terminus  終焉的迴響:護界者之歌

-- MAIN APPLICATION
addappid(741320)

-- MAIN APP DEPOTS / PACKAGES
addappid(741321, 1, "d93d20f50ddf991ccf9d2fd1fe2409da8c13b253b17a0a4cda79164333fd334c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
