-- Lua provided by RyzenAPI
-- Game: ROOM FOOTBALL - Hangar

-- MAIN APPLICATION
addappid(3571650)
-- Game: addappid(3571650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3571651, 1, "86f269526aba61447362293744d145ec4a2e61bc3f6fb3857ee6f8a2b034f97c")
