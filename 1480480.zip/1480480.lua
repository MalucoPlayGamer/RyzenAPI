-- Lua provided by RyzenAPI
-- Game: Game: DesktopMMD3:Miss Fish

-- MAIN APPLICATION
addappid(1480480)
-- Game: addappid(1480480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480481, 1, "533b63957e993205df6e70b7101637078b3541fcf288a459f175794ea25b6094")
