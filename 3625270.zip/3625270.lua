-- Lua provided by SkyAPI 
-- Game: MateEngine
addappid(3625270)
addappid(3625271, 1, "734456d4a0a4052b952e0aa76968df9f9c584b67bf4b28aeada100b6ed9d0860")
