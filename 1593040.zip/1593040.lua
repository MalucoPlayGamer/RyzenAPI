-- Lua provided by RyzenAPI
-- Game: Game: Belle-de-Nuit

-- MAIN APPLICATION
addappid(1593040)
addappid(2189510)
-- Game: addappid(1593040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593041, 1, "37af3a88c080b326ba0ed06db67fcf5a66b90ee4fa8c9760899e0f57ea122262")
