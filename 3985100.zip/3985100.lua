-- 3985100's Lua and Manifest Created by Hubcap Manifest
-- Jolt: Neon Breaker
-- Created: June 28, 2026 at 22:02:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3985100) -- Jolt: Neon Breaker
-- MAIN APP DEPOTS
addappid(3985101, 1, "9b7fdc947755351297ce82f25ba2665a5678af18bc1f1a36b8e71a4a62b05db2") -- Depot 3985101
-- setManifestid(3985101, "8527070960800595323", 471965431)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- setManifestid(228990, "1829726630299308803", 102931551)