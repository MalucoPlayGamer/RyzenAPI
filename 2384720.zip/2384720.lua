-- Lua provided by RyzenAPI
-- Game: 2384720

-- MAIN APPLICATION
addappid(2384720)
-- Game: addappid(2384720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384721, 1, "6ec7934f41c8cf5a2e1a1bab847f6d285ce1a184b9d7e2dc551d02bbff575b66")
