-- Lua provided by RyzenAPI 
-- Game: Astebros
addappid(2384720)
addappid(2384721, 1, "6ec7934f41c8cf5a2e1a1bab847f6d285ce1a184b9d7e2dc551d02bbff575b66")
