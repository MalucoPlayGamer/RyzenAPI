-- Lua provided by RyzenAPI
-- Game: Cowboy 3030

-- MAIN APPLICATION
addappid(2347550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347551, 1, "2f92a9d2769ae4b66e3b55b9a3c6daab5329c27b00dea0309d0d8c85fadd7803")
