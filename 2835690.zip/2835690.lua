-- Lua provided by RyzenAPI
-- Game: The Demons Told Me to Make This Game

-- MAIN APPLICATION
addappid(2835690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835691,0,"d11c01f0fc25f52236a4dc9cc1783c5a36ac3ce823abbdceab724b8746433ec1")

