-- Lua provided by RyzenAPI
-- Game: AppID 1624850

-- MAIN APPLICATION
addappid(1624850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624851, 1, "02de30ee6fd4e64db054003c196a836bd551b6e45a66afb7c23f86bb276a9ed4")

