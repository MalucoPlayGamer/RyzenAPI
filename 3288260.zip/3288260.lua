-- Lua provided by RyzenAPI
-- Game: Black Myth: Wukong Soundtrack Selection

-- MAIN APPLICATION
addappid(3288260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288261, 1, "dd58656a765e3490f9479f111d16728b1ffa1b0b474076884b122c344153ff52")
addappid(3288262, 1, "d00c5648814e85abd2a3d949042a2a715d5a3b9b437c754479b01ef7fd74e42a")
