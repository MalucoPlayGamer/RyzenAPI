-- Lua provided by RyzenAPI 
-- Game: Cthulhu Dungeon
addappid(1780850)
addappid(1780851, 1, "376362b3df097afcdb1481ace3391e648e05ca248d72f6ffb7b351f085f749fa")
