-- Lua provided by RyzenAPI
-- Game: AppID 275810

-- MAIN APPLICATION
addappid(275810)

-- MAIN APP DEPOTS / PACKAGES
addappid(275811, 1, "2c39b1bd4e2db7c2caae3eb03f9e77821534a1caa35121bd9d84c5645eda8e81")
