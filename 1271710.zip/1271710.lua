-- Lua provided by RyzenAPI
-- Game: LEWDAPOCALYPSE Hentai Evil

-- MAIN APPLICATION
addappid(1271710)
addappid(1656810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1271711, 1, "a3a6de30266dc9e93ce5bcc3c3ba66e63b18924664b1c90487964f36d12185d2")
addappid(1271712, 1, "7f5b9a1664d9c609f9e7b93be44a07fbd0a410a87a97df0b8e6c2d4388639784")
addappid(1271713, 1, "fc3e7cfe1abbdbfed4d1bca01891a1878676db08e42a39708f2b3ca25a122b13")
addappid(1271714, 1, "b095aab93efa36d1db3a56680d4d5fbc5dcb31e4393b292eef22d57767899c9d")
addappid(1557600, 0, "c8c66efb07ec609b9ea152edd73740aed51ef75a0ee6f2b9d7bb548577b3a35f")
addappid(1557601, 0, "b6fd4a1868f280da4811cabf51ede69d15a534b676d9ea7078be0b1770f1e953")
addappid(1557602, 0, "b82584435fa3d8b8feb0b6073bbc43ac281374b7b6d6ee401dbfc4b8be1fe58b")
addappid(1557603, 0, "421ab9c41ef4ef97fb5068b3db093fdbc291e441c1b0e4cbe20189e50426029f")

