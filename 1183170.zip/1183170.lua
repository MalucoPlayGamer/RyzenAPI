-- Lua provided by RyzenAPI
-- Game: All World Pro Wrestling

-- MAIN APPLICATION
addappid(1183170)
addappid(1880600)
addappid(2083930)
addappid(2688460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183171, 1, "443a2bed7d1cd70206045807de63494de46bb9226dfa04a5362b964cba90bd6c")
