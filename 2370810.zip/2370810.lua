-- Lua provided by RyzenAPI
-- Game: 2370810

-- MAIN APPLICATION
addappid(2370810)
-- Game: addappid(2370810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370811, 1, "9f314acb0a6a4ce0ae2bbacaeda67eafcb8f8992a8f022bd1bbf0fa71c565097")
