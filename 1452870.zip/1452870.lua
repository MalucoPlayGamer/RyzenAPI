-- Lua provided by RyzenAPI
-- Game: 1452870

-- MAIN APPLICATION
addappid(1452870)
-- Game: addappid(1452870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452871, 1, "52b4978cb8d8837dc45c1735ca98a50f66072c4c421eb8d6236021a5e1bfc593")
