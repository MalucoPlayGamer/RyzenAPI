-- Lua provided by RyzenAPI
-- Game: METAL SLUG

-- MAIN APPLICATION
addappid(366250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(366251, 1, "18bc66a5022fe72217b5b96fc8037949a0c72eaa950794ea50710fb49048a126")

