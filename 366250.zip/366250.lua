-- Lua provided by RyzenAPI 
-- Game: METAL SLUG
addappid(366250)
addappid(366251, 1, "18bc66a5022fe72217b5b96fc8037949a0c72eaa950794ea50710fb49048a126")
