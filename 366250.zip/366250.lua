-- Lua provided by RyzenAPI
-- Game: Game: METAL SLUG

-- MAIN APPLICATION
addappid(366250)
-- Game: addappid(366250)

-- MAIN APP DEPOTS / PACKAGES
addappid(366251, 1, "18bc66a5022fe72217b5b96fc8037949a0c72eaa950794ea50710fb49048a126")
