-- Lua provided by RyzenAPI
-- Game: Game: AppID 3169520

-- MAIN APPLICATION
addappid(3169520)
-- Game: addappid(3169520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169521, 1, "9c327e47da8ad83eb864ec73bad3a78e2f7ff2844fd4cc6c3ed89e72725e9217")
