-- Lua provided by RyzenAPI
-- Game: AppID 3169520

-- MAIN APPLICATION
addappid(3169520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169521, 1, "9c327e47da8ad83eb864ec73bad3a78e2f7ff2844fd4cc6c3ed89e72725e9217")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
