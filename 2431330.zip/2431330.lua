-- Lua provided by RyzenAPI
-- Game: Galactic Grinder

-- MAIN APPLICATION
addappid(2431330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431331, 1, "a0edb42b05deea4ad03083ded3c83d4f6e310ddfec668f48746c4eae6c70dc9e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
