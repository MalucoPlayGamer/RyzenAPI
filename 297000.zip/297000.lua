-- Lua provided by RyzenAPI
-- Game: Heroes® of Might & Magic® III - HD Edition

-- MAIN APPLICATION
addappid(297000)

-- MAIN APP DEPOTS / PACKAGES
addappid(297001, 1, "4b3876bb11de20abf48be0187cad2ee5cb05df559c6237151a38949d3e3d3d06")
addappid(297002, 1, "7680d67c08c4b53a627228eb687993dd7b79ff3049744216beb531454140fdc2")
addappid(297003, 1, "7404d773e9b09d5c5b144be2d681fbde65cc5d1b6af3557de4373f0f87722e3e")
addappid(297004, 1, "ee203d8287724fdf18734e2e86dc32b67c3701c5b06b0e7de24fc86c5b6d1dde")
addappid(297005, 1, "e4d6b0aa050073aa13ad107fe647d6f3a347dcdff0d406825ccd90b423f6443e")
addappid(297006, 1, "9d1c9183eeea0a698de2fa20a16cc675f7a6d22ea5e3ca374792780066845ab1")
addappid(297007, 1, "ef93db498712a3638bb91a59ecfdc60c1e5352b51538a235c3b768be6473f52d")
addappid(297008, 1, "85cdd2bd13269b5b64817cd8357b5c31c7b50bfe07bb909211d7300a8defb97d")
addappid(297009, 1, "9aa1ba0976937103c0fcebedf4dc77527c756deb7027d93330d2f9844ef02b89")
addappid(297010, 1, "eed35e67a39f0fa4f383a7f4d08e30437a7e860641e816b985dabe630b4c1873")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
