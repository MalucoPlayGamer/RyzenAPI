-- Lua provided by RyzenAPI
-- Game: Snowmania

-- MAIN APPLICATION
addappid(764830)

-- MAIN APP DEPOTS / PACKAGES
addappid(764831,0,"7e336f83677948da40071cac1ed1bb0f0b2bdac0629e92e92a8beaf84423cadb")

