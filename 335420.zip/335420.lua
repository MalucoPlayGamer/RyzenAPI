-- Lua provided by RyzenAPI
-- Game: AppID 335420

-- MAIN APPLICATION
addappid(335420)
-- Game: addappid(335420)

-- MAIN APP DEPOTS / PACKAGES
addappid(335421, 1, "ddc91f996977de44211c8bf211a1184a9fad48b9aa84fcee2c6e47aac5633c0e")
