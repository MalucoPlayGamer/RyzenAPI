-- Lua provided by SkyAPI 
-- Game: AppID 335420
addappid(335420)
addappid(335421, 1, "ddc91f996977de44211c8bf211a1184a9fad48b9aa84fcee2c6e47aac5633c0e")
