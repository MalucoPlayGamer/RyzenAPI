-- Lua provided by RyzenAPI
-- Game: AppID 335420

-- MAIN APPLICATION
addappid(335420)

-- MAIN APP DEPOTS / PACKAGES
addappid(335421, 1, "ddc91f996977de44211c8bf211a1184a9fad48b9aa84fcee2c6e47aac5633c0e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
