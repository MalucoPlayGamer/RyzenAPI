-- Lua provided by RyzenAPI
-- Game: Game: Tribal Legends

-- MAIN APPLICATION
addappid(2367330)
-- Game: addappid(2367330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367331, 1, "4091f2a11e12c42b1c7ddbcd7ea02ce3a39fde41ff7e17abf2370c1a883a0af7")
