-- Lua provided by RyzenAPI
-- Game: addappid(940710)

-- MAIN APPLICATION
addappid(940710)

-- MAIN APP DEPOTS / PACKAGES
addappid(940711, 1, "ae061c0dae36e1e644026d8935cce8f98b374fc44774f434c103af5078feb355")
