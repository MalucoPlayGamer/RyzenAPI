-- Lua provided by RyzenAPI
-- Game: Colt Canyon

-- MAIN APPLICATION
addappid(940710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(940711, 1, "ae061c0dae36e1e644026d8935cce8f98b374fc44774f434c103af5078feb355")

