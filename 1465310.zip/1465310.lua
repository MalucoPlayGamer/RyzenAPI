-- Lua provided by RyzenAPI
-- Game: 1465310

-- MAIN APPLICATION
addappid(1465310)
-- Game: addappid(1465310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465311, 1, "6d3a47b1de70ea122e8cff9f67217673ccd3dd4bd43135d4fb80189a327c051d")
