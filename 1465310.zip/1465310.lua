-- Lua provided by SkyAPI 
-- Game: AppID 1465310
addappid(1465310)
addappid(1465311, 1, "6d3a47b1de70ea122e8cff9f67217673ccd3dd4bd43135d4fb80189a327c051d")
