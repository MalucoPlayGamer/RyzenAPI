-- Lua provided by RyzenAPI
-- Game: Vertical Strike Endless Challenge

-- MAIN APPLICATION
addappid(313390)
-- Game: addappid(313390)

-- MAIN APP DEPOTS / PACKAGES
addappid(313391, 1, "9854fcfb06a581cb341c23f2ad3478990257affeeff08ee81936423f3866efa3")
