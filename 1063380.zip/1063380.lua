-- Lua provided by RyzenAPI
-- Game: Game: AppID 1063380

-- MAIN APPLICATION
addappid(1063380)
-- Game: addappid(1063380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063381, 1, "83b0826f3e38f8076647cb190ad466d7fa1c35cf795b128299e034534a48ddf8")
