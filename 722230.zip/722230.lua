-- Lua provided by RyzenAPI
-- Game: AppID 722230

-- MAIN APPLICATION
addappid(722230)

-- MAIN APP DEPOTS / PACKAGES
addappid(722231, 1, "94b747f37a809a5a77d8628b093f8caf92817f56341635102443e5a07d99518a")
addappid(722232, 1, "f71a14e75e5a45dc6df53860b890e506363d94ce040206da2d067a19bea98a3c")
addappid(722233, 1, "f35985b76f9dcf4abaa1b4e4e0e026740ddfa989c57d73c47eb85bdc6065a0a1")
addappid(1899671, 0, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
