-- Lua provided by RyzenAPI
-- Game: Lumione Demo

-- MAIN APPLICATION
addappid(1342320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342321, 1, "8f5d1da27dd71bc4f8dac2ae57a8cb80364899e7a549f8ba34dac444117e40db")
