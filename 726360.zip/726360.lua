-- Lua provided by RyzenAPI
-- Game: BOOBS SAGA: Prepare To Hentai Edition

-- MAIN APPLICATION
addappid(726360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(726361, 1, "c3ec439c08e164681b5f733141690adba97c51bfef1ea860c8e9217e4b77c1b2")
addappid(726362, 1, "70a22559247dfdd14eb3a57c7b130f177702b1a55876df63c23292f218bc253d")
addappid(1080320, 0, "e77ff748564171e1d6c4b157ff4a7ba89f0f3d3485e2aa0da46954a87ae0ceb0")

