-- Lua provided by RyzenAPI
-- Game: 626200

-- MAIN APPLICATION
addappid(626200)
-- Game: addappid(626200)

-- MAIN APP DEPOTS / PACKAGES
addappid(626201, 1, "099b355afb049ed50ba0e398abf8e73420160ee7b420a9a6f6d45abc78a4efd4")
