-- Lua provided by RyzenAPI
-- Game: Age of Wonders 4

-- MAIN APPLICATION
addappid(1669000)
addappid(2260160)
addappid(3181480)
addappid(3181540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669001, 1, "c9f8c2fa2410e5cdca74811acc196b199d9831a62e6f4365e521fcadca9d12a5")
addappid(1669002, 1, "c4f706f7261dee685e2d74998d61a7b4fb175bb47659cce89b560f89fe30ff61")
addappid(2257970, 0, "2725cc874450911b4c09f09607e3a3125e1daa5574ee01d74fe2b27e7d8400f0")
addappid(2257990, 0, "7e40f1272e9d72fa90cb32e8faf281b53d56bd56d220983df52143d7590517e8")
addappid(2330150, 0, "279b4878ac89aace60e568e256cfa63ceff174760e2873b46fece3f4435209cb")
addappid(2367860, 0, "0deaaf18077207ee03464d1de42b12c00ac5a7d0030f00d7f27ddf8f1c93d0f4")
addappid(2401830, 0, "8c4094bd7b64677817f0211860cbf741b9157cafe4a11f2421288c69ae5107e8")
addappid(2401850, 0, "c29a39c1b2c6028d82b7dd85839375cca70dda4dfdee57687761ae35e4c082e5")
addappid(2401860, 0, "46a1086fb27c2492df2940ac528d7793ed980733ce1c2ea0ab216202a1244dd7")
addappid(2914280, 0, "efa7dbf9c27c1c8fe6553dab29b0e257ecb8c3a3235765ae79671ff744affd13")
addappid(3119880, 0, "bc0d77b48758274a4e61539d17c04865ad8c53089786afd2de063fe74551ba6e")
addappid(3181500, 0, "f597777e5312438bf357be4399b5be50ebe4b75a469dd5afcb5093d146926979")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3976440)
addappid(3976880)
addappid(3976890)
addappid(3976900)
addappid(3976910)
addappid(4143090)
