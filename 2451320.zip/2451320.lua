-- Lua provided by RyzenAPI
-- Game: Game: Bulletstorm VR

-- MAIN APPLICATION
addappid(2451320)
-- Game: addappid(2451320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451321, 1, "34cc9819562a8ffd452c5d9ec6d682cea2200e6203234a6f205a3ecaf31ca509")
