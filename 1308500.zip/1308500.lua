-- Lua provided by SkyAPI 
-- Game: Soul Elegy
addappid(1308500)
addappid(1308501, 1, "4271e2b47fd71f541dd647bc717ed9fda6801647972b355b78384c0e15824c98")
addappid(1308504, 1, "abaad527e909280e0f0e5383c43eebd2c5b0892478773c6a31e3d743568158a8")
