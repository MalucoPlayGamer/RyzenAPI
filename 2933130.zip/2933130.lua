-- Lua provided by RyzenAPI
-- Game: The Lord of the Rings: Return to Moria™

-- MAIN APPLICATION
addappid(2933130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933131, 1, "571136626b31c8951f3afe863e98bd7d8c833657d08311b65aa528309cb9b6ef")
addappid(3184500, 0, "f496d95994c7faaae378d2296549e6dcf8caba08288406472ede9bf5c3cdf2ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3308250)
addappid(3349540)
addappid(3560550)
addappid(3739100)
addappid(3739110)
addappid(3874660)
