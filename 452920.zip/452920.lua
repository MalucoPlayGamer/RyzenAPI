-- Lua provided by RyzenAPI
-- Game: Laser Disco Defenders

-- MAIN APPLICATION
addappid(452920)
addappid(516710)

-- MAIN APP DEPOTS / PACKAGES
addappid(452921, 1, "fee79c5f599d6c900d41def97c39dc83a11c3d680ccc528425520f2ea1bcd641")
addappid(452922, 1, "f5d4a0737035b3586ad41a45ff118d6e26ee47a682a2183031350040c5d1bbc0")
addappid(452923, 1, "34d6b276eb21b84f6e3fbbf5efee234a7101f570bc884bc78e27abe15c2e5ddc")
