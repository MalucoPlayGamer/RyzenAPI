-- Lua provided by RyzenAPI
-- Game: Unbroken: The Awakening

-- MAIN APPLICATION
addappid(2377020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377021, 1, "68a061415032c4d0d5e99f549787e53d66f7163a8c512cb33b1a38b1af8abfc6")

