-- Lua provided by RyzenAPI
-- Game: Race of Life - Act 1

-- MAIN APPLICATION
addappid(2454570)
-- Game: addappid(2454570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454571, 1, "ed0e3b7a9771eb707f29c1b9a097f52337e5333bf50fd8547a720481303f1f44")
addappid(3436070, 0, "19296ae1e3095819bb9dd5c3c5e4094c470b707d3a106c40dfa58b5bb69b1ab7")
addappid(3443210, 0, "21e20af7a49c74b9736bc56745a594f7834df0ede26cfaa903996d58a23e1a2c")
