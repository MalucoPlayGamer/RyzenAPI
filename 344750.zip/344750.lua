-- Lua provided by RyzenAPI
-- Game: AppID 344750

-- MAIN APPLICATION
addappid(344750)
-- Game: addappid(344750)

-- MAIN APP DEPOTS / PACKAGES
addappid(344751, 1, "f6d18d6ad45730ff50c2411e83a39f9da4f1ebfc3e757b075a4814f672581750")
