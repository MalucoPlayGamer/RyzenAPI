-- Lua provided by RyzenAPI
-- Game: Boss 101

-- MAIN APPLICATION
addappid(380920)

-- MAIN APP DEPOTS / PACKAGES
addappid(380921, 1, "d23690be6ec7b696ac8db8788918bb4237b62b2083262620caaef765f46a68fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
