-- Lua provided by RyzenAPI
-- Game: 380920

-- MAIN APPLICATION
addappid(380920)
-- Game: addappid(380920)

-- MAIN APP DEPOTS / PACKAGES
addappid(380921, 1, "d23690be6ec7b696ac8db8788918bb4237b62b2083262620caaef765f46a68fb")
