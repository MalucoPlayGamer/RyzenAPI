-- Lua provided by SkyAPI 
-- Game: God of War Ragnarök Soundtrack
addappid(2974310)
addappid(2974311, 1, "fadc9bf7352e7ae30b2451f6605c9cc89ea27b23388f2788cd5223df14bac32f")
