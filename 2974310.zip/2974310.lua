-- Lua provided by RyzenAPI
-- Game: Game: God of War Ragnarök Soundtrack

-- MAIN APPLICATION
addappid(2974310)
-- Game: addappid(2974310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2974311, 1, "fadc9bf7352e7ae30b2451f6605c9cc89ea27b23388f2788cd5223df14bac32f")
