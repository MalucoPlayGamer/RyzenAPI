-- Lua provided by SkyAPI 
-- Game: You Are The Code
addappid(3333330)
addappid(3333331, 1, "ea0f60adb161a01dd40b65d4b6042a230dd760fa2e2e64402eabf6ca2c80164e")
