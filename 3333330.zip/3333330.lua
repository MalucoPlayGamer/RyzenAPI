-- Lua provided by RyzenAPI
-- Game: 3333330

-- MAIN APPLICATION
addappid(3333330)
-- Game: addappid(3333330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333331, 1, "ea0f60adb161a01dd40b65d4b6042a230dd760fa2e2e64402eabf6ca2c80164e")
