-- Lua provided by SkyAPI 
-- Game: Fluff labs
addappid(1565850)
addappid(1565851, 1, "6a283d02e5ed9e95481388745229023506388369115d75b06c8e08af7a897d10")
