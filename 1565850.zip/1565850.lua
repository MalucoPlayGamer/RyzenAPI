-- Lua provided by RyzenAPI
-- Game: Fluff labs

-- MAIN APPLICATION
addappid(1565850)
-- Game: addappid(1565850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565851, 1, "6a283d02e5ed9e95481388745229023506388369115d75b06c8e08af7a897d10")
