-- Lua provided by RyzenAPI
-- Game: Fluff labs

-- MAIN APPLICATION
addappid(1565850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1565851, 1, "6a283d02e5ed9e95481388745229023506388369115d75b06c8e08af7a897d10")

