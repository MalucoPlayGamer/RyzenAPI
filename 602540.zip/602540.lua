-- Lua provided by RyzenAPI
-- Game: The Ancient Remains

-- MAIN APPLICATION
addappid(602540)

-- MAIN APP DEPOTS / PACKAGES
addappid(602541,0,"09cbc47445bcba570d358ee797b63e44e5e770e075546380a3bcb785c75b8cef")

