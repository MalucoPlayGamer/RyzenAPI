-- Lua provided by RyzenAPI
-- Game: Demons Never Lie

-- MAIN APPLICATION
addappid(1138410)
-- Game: addappid(1138410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138411, 1, "2b643e566d481066d822b5404f9db731a0f225530ffbef9052daa9f249bc9e0c")
addappid(1138412, 1, "29b718656e4d926e1e270c9cc26e6e9429b3051888d3beab2d304d9a654a43c3")
addappid(1138413, 1, "8c457c9dc0fed45147aed2c0cf21944ebfb27d68da94d7cdcc9706caacc79727")
