-- Lua provided by RyzenAPI
-- Game: Garrison: Archangel

-- MAIN APPLICATION
addappid(682450)

-- MAIN APP DEPOTS / PACKAGES
addappid(682451, 1, "d6fd4dd3659c9cd60bf03cd876e3b1b03ce3c49b5d2cd6f7936be16effed0dee")

