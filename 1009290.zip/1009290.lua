-- Lua provided by RyzenAPI
-- Game: SWORD ART ONLINE Alicization Lycoris

-- MAIN APPLICATION
addappid(1009290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009291, 1, "d056e798388b47bfa05dc596efe9ae0b226e75296d2c87f950fb8aee7dbc2913")

