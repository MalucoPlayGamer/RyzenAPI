-- Lua provided by RyzenAPI
-- Game: SWORD ART ONLINE Alicization Lycoris

-- MAIN APPLICATION
addappid(1009290) -- SWORD ART ONLINE Alicization Lycoris
addappid(1271790) -- SWORD ART ONLINE Alicization Lycoris - Blooming of Forget-me-not
addappid(1271791) -- SWORD ART ONLINE Alicization Lycoris - Blooming of Matricaria
addappid(1271792) -- SWORD ART ONLINE Alicization Lycoris Premium Pass
addappid(1271793) -- SWORD ART ONLINE Alicization Lycoris Design Contest Costumes
addappid(1271794) -- SWORD ART ONLINE Alicization Lycoris Warmaid Outfit
addappid(1272170) -- SWORD ART ONLINE Alicization Lycoris 200 SAO Coins

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1009291, 1, "d056e798388b47bfa05dc596efe9ae0b226e75296d2c87f950fb8aee7dbc2913") -- pole6 Content

