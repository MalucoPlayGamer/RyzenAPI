-- Lua provided by RyzenAPI
-- Game: The Manga Works

-- MAIN APPLICATION
addappid(1921770)
-- Game: addappid(1921770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921771, 1, "efbec05324f279711446ea16cfc8a976a2463037d07dceaeaacacd2e76114c48")
