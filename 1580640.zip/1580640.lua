-- Lua provided by RyzenAPI
-- Game: 1580640

-- MAIN APPLICATION
addappid(1580640)
-- Game: addappid(1580640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580641, 1, "12d0c4011e8cb2fae1acc13d69706cbc1925e0e6f6c14117c9334e83ddb2956a")
