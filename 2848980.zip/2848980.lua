-- Lua provided by SkyAPI 
-- Game: Spellfolio Demo
addappid(2848980)
addappid(2848981, 1, "ae070405f784e82ae895a44d53ef917d12d569bbd2e90fdbb0ea7b7d5c819359")
