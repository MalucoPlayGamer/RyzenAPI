-- Lua provided by RyzenAPI
-- Game: PAW Patrol The Movie: Adventure City Calls

-- MAIN APPLICATION
addappid(1434310)
-- Game: addappid(1434310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434311, 1, "4977cb9a9b46e50971758a0cd55ae5013f7234c125425aa650cd2423b31756d1")
