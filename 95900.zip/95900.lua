-- Lua provided by RyzenAPI
-- Game: Air Conflicts: Secret Wars

-- MAIN APPLICATION
addappid(95900)

-- MAIN APP DEPOTS / PACKAGES
addappid(95901, 1, "82648a9a8470f0b6b037b1cbaa830e3205d32514b8a891fafac77d607424b847")
addappid(95902, 1, "1dc2c94cd60c8bda7fa905994d4e89faa294a78f37d0f8d6d3ec2c4838d69d6c")
addappid(95903, 1, "ef9fbc76a1895c8a172b9656bb91a57a76236c35e49cf635b7b66ab8ce6c0a7c")
addappid(95904, 1, "9d8d16faf7eede625a93163cf090982af06cb7a5eb04bf60055f9e03905ae85b")
addappid(95905, 1, "c472f2061287080b12b1ad28511fa3cb807b8babcd6c03ffc064a8b490ee20f1")
addappid(95906, 1, "b967d9e75d20661625234b2b39766f3729c25f9db086416a2e4412be1fe7db67")
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

