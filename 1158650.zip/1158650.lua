-- Lua provided by SkyAPI 
-- Game: MindLess
addappid(1158650)
addappid(1158651, 1, "18336778c8d7d48df2b701e06eb1c7c1b0353b89d3c72236455373da69f97922")
