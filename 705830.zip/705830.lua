-- Lua provided by RyzenAPI
-- Game: 万视VR

-- MAIN APPLICATION
addappid(705830)

-- MAIN APP DEPOTS / PACKAGES
addappid(705831, 1, "27631728ced92444f36c20d54528559ed2dca04de00200feec71d4ca8c66e2b8")
