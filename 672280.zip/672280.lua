-- Lua provided by RyzenAPI 
-- Game: AppID 672280
addappid(672280)
addappid(672281, 1, "0a9576bfc202caf30c10c23fcc0f06b2f02388e97f21f08bb72f085dc2a88858")
