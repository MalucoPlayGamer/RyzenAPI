-- Lua provided by RyzenAPI
-- Game: AppID 672280

-- MAIN APPLICATION
addappid(672280)

-- MAIN APP DEPOTS / PACKAGES
addappid(672281, 1, "0a9576bfc202caf30c10c23fcc0f06b2f02388e97f21f08bb72f085dc2a88858")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
