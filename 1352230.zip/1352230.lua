-- Lua provided by RyzenAPI
-- Game: 1917 : The Prologue

-- MAIN APPLICATION
addappid(1352230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1352231, 1, "0b94a6105885262fd6380758c0f94825fd49dbe40a613becb933f5481af13479")
