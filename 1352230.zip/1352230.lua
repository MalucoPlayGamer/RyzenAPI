-- Lua provided by RyzenAPI
-- Game: Game: AppID 1352230

-- MAIN APPLICATION
addappid(1352230)
-- Game: addappid(1352230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352231, 1, "0b94a6105885262fd6380758c0f94825fd49dbe40a613becb933f5481af13479")
