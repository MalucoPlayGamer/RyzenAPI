-- Lua provided by RyzenAPI 
-- Game: AppID 488280
addappid(488280)
addappid(488281, 1, "9efd2d088e55f4693b95b8bbcb134237c9998ef5dd69039f80b3cbad33c1559f")
