-- Lua provided by RyzenAPI
-- Game: addappid(1723070)

-- MAIN APPLICATION
addappid(1723070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723071, 1, "787a6ea05e21fea73f4a9c7fbbaa2fcc9713eae47aa0e5265581bb9fc32ec91c")
