-- Lua provided by SkyAPI 
-- Game: Potato Flowers in Full Bloom Demo
addappid(1723070)
addappid(1723071, 1, "787a6ea05e21fea73f4a9c7fbbaa2fcc9713eae47aa0e5265581bb9fc32ec91c")
