-- Lua provided by RyzenAPI
-- Game: The Voidness - Lidar Horror Survival Game

-- MAIN APPLICATION
addappid(2276850)
-- Game: addappid(2276850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276851, 1, "7e9f84f8aeab368231e06fc9f9f0f6d2651ac3c612a3ed668b38762d56e55ed5")
