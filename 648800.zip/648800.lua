-- Lua provided by RyzenAPI
-- Game: Raft

-- MAIN APPLICATION
addappid(648800)
-- Game: addappid(648800)

-- MAIN APP DEPOTS / PACKAGES
addappid(648801, 1, "69b674ffb72cbe77ce081b29070056279accc29956cad5d38d31e0d3e2090632")
