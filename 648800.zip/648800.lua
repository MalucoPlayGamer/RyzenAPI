-- Lua provided by RyzenAPI
-- Game: Raft

-- MAIN APPLICATION
addappid(648800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(648801, 1, "69b674ffb72cbe77ce081b29070056279accc29956cad5d38d31e0d3e2090632")
