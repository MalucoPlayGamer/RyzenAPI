-- Lua provided by RyzenAPI
-- Game: Distant Worlds: Universe

-- MAIN APPLICATION
addappid(261470)

-- MAIN APP DEPOTS / PACKAGES
addappid(261471, 1, "85f9db5eed51b24a0245022b4d3c683f94b7c247ebd98e710db9851d22f5d9c9")

