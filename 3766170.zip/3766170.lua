-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost In Japan Find & Color

-- MAIN APPLICATION
addappid(3766170)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3846310)
