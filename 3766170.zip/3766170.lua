-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost In Japan Find & Color

-- MAIN APPLICATION
addappid(3766170)
