-- Lua provided by RyzenAPI
-- Game: 2793370

-- MAIN APPLICATION
addappid(2793370)
-- Game: addappid(2793370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793371, 1, "6fa32d707cc6ffb49cd0cf356a2e40e5386a2d0edac95bcd5363be541d5dfb3c")
