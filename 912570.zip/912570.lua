-- Lua provided by RyzenAPI
-- Game: AppID 912570

-- MAIN APPLICATION
addappid(912570)

-- MAIN APP DEPOTS / PACKAGES
addappid(912571, 1, "0fee296aa361e41f67ec0b4d46a61ca82cf1ddc50bffbb80856d76bc4d7a2fbb")
addappid(912573, 1, "1385167787a93e05582293b2986d7c4ff23541e65f09edb245e70f80d25355bd")
addappid(912574, 1, "b841d9e52adccf535ff97904c4f446420591150b99ec9a4236f62fb8d668eb48")
addappid(1237600, 0, "cc5959a3ca11d0d58bc80c2a33c3fa446fc6d24f51ae958296220bee3c37e3cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
