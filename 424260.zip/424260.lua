-- Lua provided by RyzenAPI
-- Game: Feelings Adrift

-- MAIN APPLICATION
addappid(424260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(424261, 1, "5face3a42f3cb460f745c099fe331b5d269a2514d059cfa5711bbba33600fbba")

