-- Lua provided by RyzenAPI
-- Game: AppID 424260

-- MAIN APPLICATION
addappid(424260)
-- Game: addappid(424260)

-- MAIN APP DEPOTS / PACKAGES
addappid(424261, 1, "5face3a42f3cb460f745c099fe331b5d269a2514d059cfa5711bbba33600fbba")
