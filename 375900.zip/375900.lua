-- Lua provided by RyzenAPI
-- Game: Trackmania® Turbo

-- MAIN APPLICATION
addappid(375900)
addappid(455060)

-- MAIN APP DEPOTS / PACKAGES
addappid(375901, 1, "65ced03e5fb7f84f5ed2788f8f8ec90a6cc0d2ed73b1c1dc8575d0ad8a5cf303")
addappid(455061, 0, "7f989b6cd2b07b2c23d4d65df64af240b7831fac59622192eb22b5b7d2c9da9c")
addappid(455062, 0, "304f3bdb10a0b5d70595ddae15273837d77ed1326d3a99381fc8567a7ba385ce")

