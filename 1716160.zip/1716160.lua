-- Lua provided by RyzenAPI
-- Game: Photo Puzzles HD

-- MAIN APPLICATION
addappid(1716160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716161, 1, "bfb8473a95bcc696097a2a0bee932867218564542712abf430efff3e95597835")

