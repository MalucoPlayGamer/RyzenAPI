-- Lua provided by RyzenAPI
-- Game: addappid(1339900)

-- MAIN APPLICATION
addappid(1339900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339901, 1, "132bd39c212613f46b3ebea2f0bd580d7cb00fc7b5cfc8733bf86920da7cb11f")
