-- Lua provided by RyzenAPI
-- Game: YinYang Street: Separate Ways

-- MAIN APPLICATION
addappid(3450370)
-- Game: addappid(3450370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3450371, 1, "d83d97babbd6263b48a2774c48abdce0ec4b0694fa873e72c9eff5c6790d78b6")
addappid(3666130, 0, "52b13e5f5bf74c4c034af9959e97c4e0b60e73306afac7075e132b0d5f311cc4")
