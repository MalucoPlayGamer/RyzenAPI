-- Lua provided by RyzenAPI
-- Game: 1563170

-- MAIN APPLICATION
addappid(1563170)
-- Game: addappid(1563170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563171, 1, "f28a15952b03f201ed3c5b152e90f8e7c096e3ad252325016a795c2fe26b186e")
