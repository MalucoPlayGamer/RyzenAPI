-- Lua provided by RyzenAPI
-- Game: Boundless

-- MAIN APPLICATION
addappid(324510)
addappid(331130)
addappid(914080)
addappid(914081)

-- MAIN APP DEPOTS / PACKAGES
addappid(324511, 1, "5949aa5ee9020a85be7ba50830fd9095024b38cc0151ba60dc620fb4de328815")
addappid(324512, 1, "40cf338428e05dfea02e8f140904ab7b362a8b925139d921434ceb5276c5d00a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(586550)
addappid(697291)
addappid(697292)
addappid(697293)
addappid(697300)
addappid(697301)
addappid(721320)
