-- Lua provided by RyzenAPI
-- Game: Living together with Fox Demon

-- MAIN APPLICATION
addappid(1528560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528561, 1, "8cefcac931f4343c5e9cf54bbfba7b1d25679404d89fd7011664471498f3ec92")

