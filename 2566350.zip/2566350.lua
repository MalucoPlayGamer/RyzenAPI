-- Lua provided by RyzenAPI
-- Game: I Got Trapped in the Succubus's Dream!

-- MAIN APPLICATION
addappid(2566350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566351, 1, "cc1580a01fc2e80c8a60d289f88d76781ad13cf9278ef31b21a89e9cd100b8d7")
addappid(2566352, 1, "1e6e15a2c20a86307427ac4b949459163344a2f9388932cb10bfe5a64327958e")
addappid(2566353, 1, "8ec310513dc5da2af17c22d511af93bcaa95447b4b681e6fe3a6872a1156be73")

