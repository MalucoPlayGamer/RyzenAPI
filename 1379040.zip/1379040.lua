-- Lua provided by RyzenAPI
-- Game: 1379040

-- MAIN APPLICATION
addappid(1379040)
-- Game: addappid(1379040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379041, 1, "41fbcd464feca8b3959f77436f5e601ce212b50a22ad99557373e91cb175c3a5")
