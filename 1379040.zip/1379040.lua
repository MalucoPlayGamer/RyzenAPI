-- Lua provided by RyzenAPI
-- Game: Pixel Ninja

-- MAIN APPLICATION
addappid(1379040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(1379041, 1, "41fbcd464feca8b3959f77436f5e601ce212b50a22ad99557373e91cb175c3a5")

