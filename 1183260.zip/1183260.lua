-- Lua provided by RyzenAPI
-- Game: TrymenT ―献给渴望改变的你― AlphA篇

-- MAIN APPLICATION
addappid(1183260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183261, 1, "08b2454859bd905e0aa8662ef44e0512b42a06c86c81ade814f3bfaf2b31de84")

