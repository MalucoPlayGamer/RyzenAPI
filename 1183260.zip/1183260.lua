-- Lua provided by RyzenAPI
-- Game: TrymenT ―献给渴望改变的你― AlphA篇

-- MAIN APPLICATION
addappid(1183260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183261, 1, "08b2454859bd905e0aa8662ef44e0512b42a06c86c81ade814f3bfaf2b31de84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
