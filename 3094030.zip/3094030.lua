-- Lua provided by SkyAPI 
-- Game: AppID 3094030
addappid(3094030)
addappid(3094031, 1, "850703725a0e55ff59bd007ac91e43d1790d0182751cfe80b0e72769349fa505")
addappid(3094032, 1, "fb4bfda78d51c71bb139d8b9ca038f0d395e706e5595aaac3ca715a582a4ce98")
