-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Orochi Pack 3

-- MAIN APPLICATION
addappid(933532)
-- Game: addappid(933532)

-- MAIN APP DEPOTS / PACKAGES
addappid(933532,0,"0648f430d7418ae18e09cde0dea4f781afa300d71b07c7633818ef7dd9961444")
