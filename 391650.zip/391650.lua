-- Lua provided by RyzenAPI 
-- Game: AppID 391650
addappid(391650)
addappid(391651, 1, "cfdcb9e54d5797b68d753380978b66f0d738ef62c8ff405e040e31ca65c91d6c")
