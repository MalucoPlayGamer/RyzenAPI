-- Lua provided by RyzenAPI 
-- Game: AppID 718980
addappid(718980)
addappid(718981, 1, "47da06220fa14a1e64721e97f0ffec5c7115227bc94128403927fd0f330793e2")
