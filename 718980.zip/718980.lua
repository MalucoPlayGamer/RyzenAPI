-- Lua provided by RyzenAPI
-- Game: Grey Zone

-- MAIN APPLICATION
addappid(718980)
addappid(758130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(718981, 1, "47da06220fa14a1e64721e97f0ffec5c7115227bc94128403927fd0f330793e2")
