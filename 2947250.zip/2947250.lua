-- Lua provided by RyzenAPI 
-- Game: Select Oblige
addappid(2947250)
addappid(2947251, 1, "6d0861870a053c1290abd283206876e140e9f70d51c85136178370ad6754b01f")
