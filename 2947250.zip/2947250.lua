-- Lua provided by RyzenAPI
-- Game: Game: Select Oblige

-- MAIN APPLICATION
addappid(2947250)
-- Game: addappid(2947250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947251, 1, "6d0861870a053c1290abd283206876e140e9f70d51c85136178370ad6754b01f")
