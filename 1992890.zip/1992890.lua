-- Lua provided by RyzenAPI
-- Game: 欢乐金蟾捕鱼

-- MAIN APPLICATION
addappid(1992890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992891, 1, "7cd6a6f374836e54f2191c76ef0f4cfb3047041580ba86225e23ff713e061a9f")

