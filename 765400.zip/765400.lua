-- Lua provided by RyzenAPI 
-- Game: Christmas Tale - Visual Novel
addappid(765400)
addappid(765401, 1, "e730062874b0d60d9a6ac7dd040fcfc28c52bd40cc3c0dc4778d6e1f2e65ff63")
addappid(768500, 0, "44ca309f128aaa2247a8ac5552806416f179b4ba4dd8d8185441ba2e3a1a7c26")
