-- Lua provided by RyzenAPI
-- Game: Abiotic Factor

-- MAIN APPLICATION
addappid(228984)
addappid(228985)
addappid(228989)
addappid(228990)
addappid(427410)

-- MAIN APP DEPOTS / PACKAGES
addappid(427413,0,"ff587f4073cb5fc9fb07cc1f4a0932a48fdbcab584bf8f74339e959cedc42e2b")
