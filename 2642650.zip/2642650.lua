-- Lua provided by RyzenAPI
-- Game: Diari Demo

-- MAIN APPLICATION
addappid(2642650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642651, 1, "12e1bc440a39cc7bb465ad990bff04be1941bbf7a694d9e97829a7bdf99e160f")

