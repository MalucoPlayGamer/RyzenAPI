-- Lua provided by RyzenAPI
-- Game: Game: AppID 793190

-- MAIN APPLICATION
addappid(793190)
-- Game: addappid(793190)

-- MAIN APP DEPOTS / PACKAGES
addappid(793191, 1, "c2685a50d737222449ac70eee76832d9bbe41e13d2345edd6458e50c459826ce")
