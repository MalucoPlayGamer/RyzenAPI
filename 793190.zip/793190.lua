-- Lua provided by SkyAPI 
-- Game: AppID 793190
addappid(793190)
addappid(793191, 1, "c2685a50d737222449ac70eee76832d9bbe41e13d2345edd6458e50c459826ce")
