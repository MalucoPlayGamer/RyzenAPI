-- Lua provided by RyzenAPI
-- Game: AppID 793190

-- MAIN APPLICATION
addappid(793190)

-- MAIN APP DEPOTS / PACKAGES
addappid(793191, 1, "c2685a50d737222449ac70eee76832d9bbe41e13d2345edd6458e50c459826ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
