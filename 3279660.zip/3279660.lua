-- Lua provided by RyzenAPI
-- Game: Game: 相亲模拟器 Demo

-- MAIN APPLICATION
addappid(3279660)
-- Game: addappid(3279660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279661, 1, "021cf46aaf7d0252c53d28deb47915cd27ecdada8157ad342de434894187b4aa")
