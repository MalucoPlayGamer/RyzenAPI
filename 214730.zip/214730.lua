-- Lua provided by RyzenAPI
-- Game: Space Rangers HD: A War Apart

-- MAIN APPLICATION
addappid(214730)

-- MAIN APP DEPOTS / PACKAGES
addappid(214731, 1, "b78ae8746e4426fd76e93cadd1a2ee778a0788ec82ac7e29939f66bcc4ba469b")
addappid(214732, 1, "fdf0e9440a18fc6a0236fce38c24b7b7a1f55be4cf1fbe5cb64dea29c5b108a3")

