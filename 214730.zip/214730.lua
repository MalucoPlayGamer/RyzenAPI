-- Lua provided by RyzenAPI
-- Game: Space Rangers HD: A War Apart

-- MAIN APPLICATION
addappid(214730)

-- MAIN APP DEPOTS / PACKAGES
addappid(214731, 1, "b78ae8746e4426fd76e93cadd1a2ee778a0788ec82ac7e29939f66bcc4ba469b")
addappid(214732, 1, "fdf0e9440a18fc6a0236fce38c24b7b7a1f55be4cf1fbe5cb64dea29c5b108a3")
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

