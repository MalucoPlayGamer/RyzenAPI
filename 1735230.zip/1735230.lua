-- Lua provided by SkyAPI 
-- Game: Stones Keeper: Prologue
addappid(1735230)
addappid(1735231, 1, "3c237d8326107b7dffe19a000be6fcb993ff33409d2b3054e9d7478cff3c1ce7")
