-- Lua provided by RyzenAPI
-- Game: Stones Keeper: Prologue

-- MAIN APPLICATION
addappid(1735230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735231, 1, "3c237d8326107b7dffe19a000be6fcb993ff33409d2b3054e9d7478cff3c1ce7")
