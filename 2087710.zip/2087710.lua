-- Lua provided by RyzenAPI
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 5 - Hyper Dyne Side Arms - Round 1

-- MAIN APPLICATION
addappid(2087710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087711, 1, "97cef1630aaa8efd1f24b08f996b55ad974dff12483c46de85ad1e97fad4a509")
addappid(2087712, 1, "238b227794e37b02ceaa1320f2a764acda2cc36b75607ce8d5aaf5a1e56a85f3")
addappid(2087713, 1, "5170ea461fbc512599723b72f836ee303b172ddba45e1b557b344cf150658028")
addappid(2087714, 1, "05893a0c159c4658ee600d6534af0589085f0f1b0fb1c4a37970c2e5d9443bb6")
addappid(2087715, 1, "84f1d75374ba90dcef4a72cec8a86bbdb6b5162db1cd5fb7795caaad20bc7627")
addappid(2087716, 1, "4b9f847296a78f96e331cd82abb7db74dfd1c4b6debe6779a2983fd1eff6ef2e")
