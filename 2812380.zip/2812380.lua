-- Lua provided by RyzenAPI
-- Game: Burkina Faso: Radical Insurgency

-- MAIN APPLICATION
addappid(2812380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812381,0,"db4e6661de0a77d4ade32aa133c6c87a149bec25ed694059b038ed6829d1ca20")

