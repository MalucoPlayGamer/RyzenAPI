-- Lua provided by RyzenAPI
-- Game: Faerie Solitaire Harvest

-- MAIN APPLICATION
addappid(348910)

-- MAIN APP DEPOTS / PACKAGES
addappid(348911, 1, "aba07a487564e58b08b7815adc5583879fc4de884d612af1044d200b9c69c827")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
