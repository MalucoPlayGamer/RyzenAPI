-- Lua provided by RyzenAPI
-- Game: Faerie Solitaire Harvest

-- MAIN APPLICATION
addappid(348910)

-- MAIN APP DEPOTS / PACKAGES
addappid(348911, 1, "aba07a487564e58b08b7815adc5583879fc4de884d612af1044d200b9c69c827")
