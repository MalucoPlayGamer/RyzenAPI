-- Lua provided by RyzenAPI
-- Game: addappid(1639210)

-- MAIN APPLICATION
addappid(1639210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639211, 1, "0e0f2f80be48cf0476e7c853c30cf40fc7e62c0ce415a98617efd1158d5dbb2b")
