-- Lua provided by RyzenAPI
-- Game: Hexus

-- MAIN APPLICATION
addappid(323250)

-- MAIN APP DEPOTS / PACKAGES
addappid(323251, 1, "40bbaf0261cb394cea8ee7fa187de2e4d57dc0337e63b8118376dbfb7a7361e8")
