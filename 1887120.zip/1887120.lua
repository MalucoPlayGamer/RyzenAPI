-- Lua provided by RyzenAPI
-- Game: addappid(1887120)

-- MAIN APPLICATION
addappid(1887120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887121, 1, "0aeb547d495f829b157be41befd8fbf36eb3bc31b9ae9b265e1223a52c8d2ccb")
addappid(1887122, 1, "6e2e15036dc247cc1c39ccb8ea3758fb80ffe2b586c16ecd644eb0cc30fccb58")
