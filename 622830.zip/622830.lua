-- Lua provided by RyzenAPI
-- Game: Battle Chess

-- MAIN APPLICATION
addappid(622830)
-- Game: addappid(622830)

-- MAIN APP DEPOTS / PACKAGES
addappid(622832,0,"4afb7998fac1466523ada35007735610649b82b6cabc9442997858e893b2ff49")
