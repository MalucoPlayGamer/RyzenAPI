-- Lua provided by RyzenAPI
-- Game: addappid(3188830)

-- MAIN APPLICATION
addappid(3188830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3188831, 1, "fcaa01d5cf116526dfb6b4cd3639f8707c0bb73b9b7f86854766081f20f88b53")
