-- Lua provided by RyzenAPI
-- Game: I'm Still Here

-- MAIN APPLICATION
addappid(3188830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3188831, 1, "fcaa01d5cf116526dfb6b4cd3639f8707c0bb73b9b7f86854766081f20f88b53")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
