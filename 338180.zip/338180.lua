-- Lua provided by RyzenAPI
-- Game: Batla

-- MAIN APPLICATION
addappid(338180)

-- MAIN APP DEPOTS / PACKAGES
addappid(338181, 1, "313ebac97efc1f0d422346d5a5f6da4ae9f4cece1f50613e33fee6459f949cd3")
