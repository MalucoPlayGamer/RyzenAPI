-- Lua provided by RyzenAPI
-- Game: addappid(1475430)

-- MAIN APPLICATION
addappid(1475430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475431, 1, "c3571dc19a0e9331b341bceaae579d2658b083fac900b290332801ac75990fef")
