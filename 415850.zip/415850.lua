-- Lua provided by RyzenAPI
-- Game: addappid(415850)

-- MAIN APPLICATION
addappid(415850)

-- MAIN APP DEPOTS / PACKAGES
addappid(415851, 1, "e3df9a5e3acabbf240cbd08fad6e29a3143a90b4f121246125b6c3d4199562b4")
