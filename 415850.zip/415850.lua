-- Lua provided by RyzenAPI
-- Game: BAD END

-- MAIN APPLICATION
addappid(415850)

-- MAIN APP DEPOTS / PACKAGES
addappid(415851, 1, "e3df9a5e3acabbf240cbd08fad6e29a3143a90b4f121246125b6c3d4199562b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
