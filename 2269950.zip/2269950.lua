-- Lua provided by RyzenAPI
-- Game: The Karters 2: Turbo Charged

-- MAIN APPLICATION
addappid(2269950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269951, 1, "8831fc2d89d3edc51afe5f2405b6694c493318df489caef0602335566ee648bf")
