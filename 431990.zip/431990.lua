-- Lua provided by RyzenAPI
-- Game: AppID 431990

-- MAIN APPLICATION
addappid(431990)
-- Game: addappid(431990)

-- MAIN APP DEPOTS / PACKAGES
addappid(431991, 1, "ea3c6ad423567169061e4abe64085fe4f4538afca62fe94b80f5d0c665c88be0")
