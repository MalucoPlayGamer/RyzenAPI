-- Lua provided by RyzenAPI
-- Game: AppID 1278520

-- MAIN APPLICATION
addappid(1278520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278521, 1, "5f848e06840fa20a7cfd22395e77c8a94a346fadb9cd4ce17d5304ea0b203b2d")
