-- Lua provided by RyzenAPI
-- Game: WackyMoles

-- MAIN APPLICATION
addappid(525870)

-- MAIN APP DEPOTS / PACKAGES
addappid(525871,0,"9e34def6aee6b7ef53a052d9f68594cf074b4cd81b452649a966ee169e7d2375")

