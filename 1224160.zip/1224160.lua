-- Lua provided by SkyAPI 
-- Game: Sisterly Lust
addappid(1224160)
addappid(1224161, 1, "d5544e74b3c5b6c1909aaf1b859f4d80352e775d5e472cae1d9286484c78f8dd")
