-- Lua provided by RyzenAPI
-- Game: Pro Cycling Manager 2022

-- MAIN APPLICATION
addappid(1767560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1767561, 1, "404fc1e99bd5ca63e5ddff39fae3d3354de0cbe19d20bea8504082d6abfdec70")

