-- Lua provided by RyzenAPI
-- Game: Pro Cycling Manager 2022

-- MAIN APPLICATION
addappid(1767560)
-- Game: addappid(1767560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767561, 1, "404fc1e99bd5ca63e5ddff39fae3d3354de0cbe19d20bea8504082d6abfdec70")
