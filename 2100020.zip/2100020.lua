-- Lua provided by RyzenAPI
-- Game: Lou's Lagoon

-- MAIN APPLICATION
addappid(4831360) -- Lous Lagoon Deluxe Pack
addappid(4890570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100020, 1, "bff0c5304bbbde13e0d6c7a555f1b71ed7762079e94d98da2b0992c974c25f00") -- Lou's Lagoon
addappid(2100021, 1, "01a65b174aaf04d6a5bac593c360161f3f0454d8b3ac85e08525880723894918") -- Depot 2100021
addappid(4890570, 1, "d02a5846fa9d4187fd32526af7d6658a94be334dfa0bbc0b1f4af5edf0486079") -- Lous Lagoon Digital Artbook - Depot 4890570

