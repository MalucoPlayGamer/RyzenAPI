-- 2100020's Lua and Manifest Created by Hubcap Manifest
-- Lou's Lagoon
-- Created: August 27, 2026 at 06:29:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2100020, 1, "bff0c5304bbbde13e0d6c7a555f1b71ed7762079e94d98da2b0992c974c25f00") -- Lou's Lagoon
-- MAIN APP DEPOTS
addappid(2100021, 1, "01a65b174aaf04d6a5bac593c360161f3f0454d8b3ac85e08525880723894918") -- Depot 2100021
setManifestid(2100021, "7188827490180976970", 9718024692)
-- DLCS WITH DEDICATED DEPOTS
-- Lous Lagoon Digital Artbook (AppID: 4890570)
addappid(4890570)
addappid(4890570, 1, "d02a5846fa9d4187fd32526af7d6658a94be334dfa0bbc0b1f4af5edf0486079") -- Lous Lagoon Digital Artbook - Depot 4890570
setManifestid(4890570, "4629110426845429241", 35713302)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4831360) -- Lous Lagoon Deluxe Pack 