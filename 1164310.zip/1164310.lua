-- Lua provided by RyzenAPI
-- Game: Fairytale Solitaire. Witch Charms

-- MAIN APPLICATION
addappid(1164310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164311, 1, "b46f1e06d8a9d09af82b59d513a01931b73954e8e619f6316a800f5075009e63")
addappid(1164314, 1, "5a146d25d61b4073774f5666884fd80060f39e0b1f09cc05e9c929ebe48bec2c")

