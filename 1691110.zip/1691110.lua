-- Lua provided by RyzenAPI
-- Game: AppID 1691110

-- MAIN APPLICATION
addappid(1691110)
-- Game: addappid(1691110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691111, 1, "41af8142b53a393e4ec39f987f1cf9ffd59043b4d501f197de976f98d69f33b5")
