-- Lua provided by RyzenAPI
-- Game: Prototype ONE DAY I AM

-- MAIN APPLICATION
addappid(1397940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397941, 1, "35927667fe9e153d02e3c087a64135aa7b263a892a4d1ba789caa3344c22af3b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
