-- Lua provided by RyzenAPI
-- Game: addappid(1397940)

-- MAIN APPLICATION
addappid(1397940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397941, 1, "35927667fe9e153d02e3c087a64135aa7b263a892a4d1ba789caa3344c22af3b")
