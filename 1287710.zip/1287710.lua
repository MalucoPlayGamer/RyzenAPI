-- Lua provided by RyzenAPI
-- Game: Rary

-- MAIN APPLICATION
addappid(1287710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287711, 1, "af267467c241cdbfb0f5868e6a6beda917d081bb66e4a77a5851328d940e98d8")
