-- Lua provided by RyzenAPI
-- Game: addappid(2837260)

-- MAIN APPLICATION
addappid(2837260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837261, 1, "0d4b28525427b40d499a1103fcc9ed73101aecb2bbb2294d69daca4193affb74")
