-- Lua provided by RyzenAPI
-- Game: Gun Shop: Tidy Up

-- MAIN APP DEPOTS / PACKAGES
addappid(5050370, 1, "f9e082691e7af9ed1311c5fea808bf70b30630ae1b86b55816fb8b5bd8d889fc") -- Gun Shop: Tidy Up
addappid(5050371, 1, "3d770f1c2df29b8c4c5ecc11ccbbdb9a90a9e52024d24fbd25cb92f22ac2d91b") -- Depot 5050371
