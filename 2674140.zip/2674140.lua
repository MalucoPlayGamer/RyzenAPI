-- Lua provided by RyzenAPI
-- Game: A Game´s Tale

-- MAIN APPLICATION
addappid(2674140)
-- Game: addappid(2674140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674141, 1, "e1ff92f3efaaaf0ab084821859f1f21a7e3a180bf999c3553fe2272c3637ad31")
