-- Lua provided by RyzenAPI
-- Game: addappid(810500)

-- MAIN APPLICATION
addappid(810500)

-- MAIN APP DEPOTS / PACKAGES
addappid(810501, 1, "961e04b3623f017c42572c3ca7cef69c0ddc1447422359c752ee94ad925db11b")
