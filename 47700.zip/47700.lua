-- Lua provided by RyzenAPI
-- Game: addappid(47700)

-- MAIN APPLICATION
addappid(47700)

-- MAIN APP DEPOTS / PACKAGES
addappid(47701, 1, "c1296dcf3e8a49e22a22de6ccbb0d4e450ba89e5695ff23b77f01abdc923cb74")
addappid(47702, 1, "4dce552f3bd51490bffcaa9fa0dac7a30228347c52fd22f3217bc8ded451ee07")
addappid(47703, 1, "36a2e0096468d75a99eaaf49e4ecac3f25526266fcc0904d9f47d81861ee0cc2")
addappid(47704, 1, "0dab9db38b361f61baf75fa0ad9bbc71acfd409428af9b7131836209b68cd738")
addappid(47705, 1, "67e26bc6e3fd69ef8be7de45e0a34e72028d8bd8448da3712b1e339d451da66a")
addappid(47706, 1, "e4dcf4b8e2af3fc467d2ff44ed753e9d713a51a1e27b29ac8ba4b73c4212ffd7")
addappid(47707, 1, "949c76a7be73f766239cb85735a31f602665814cd17a3549826a5fe3da976a3d")
addappid(47708, 1, "c8c71a7e4994fd7d336e6e3af63259fc9c517e13ec74db6bc7d541518366d81b")
