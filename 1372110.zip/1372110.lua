-- Lua provided by RyzenAPI
-- Game: Game: JoJo's Bizarre Adventure: All-Star Battle R

-- MAIN APPLICATION
addappid(1372110)
-- Game: addappid(1372110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372111, 1, "219ba7ad894442207719fbcc8f5108ead1e6a7990e9570faff49adedcb1a0673")
