-- Lua provided by RyzenAPI
-- Game: JoJo's Bizarre Adventure: All-Star Battle R

-- MAIN APPLICATION
addappid(1372110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372111, 1, "219ba7ad894442207719fbcc8f5108ead1e6a7990e9570faff49adedcb1a0673")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1941060)
addappid(1941061)
addappid(1941062)
addappid(1941063)
addappid(2001010)
addappid(2001011)
addappid(2001012)
addappid(2001013)
addappid(2001014)
addappid(2382760)
addappid(2382761)
addappid(2382762)
addappid(2382763)
addappid(2382764)
