-- Lua provided by SkyAPI 
-- Game: Buried
addappid(2605640)
addappid(2605641, 1, "49912a0afdb198a7d2f29975217498c7f619dc813e6cf40871112995bd31aeb4")
