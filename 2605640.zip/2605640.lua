-- Lua provided by RyzenAPI
-- Game: Buried

-- MAIN APPLICATION
addappid(2605640)
-- Game: addappid(2605640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605641, 1, "49912a0afdb198a7d2f29975217498c7f619dc813e6cf40871112995bd31aeb4")
