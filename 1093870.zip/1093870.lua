-- Lua provided by RyzenAPI
-- Game: Game: Block

-- MAIN APPLICATION
addappid(1093870)
-- Game: addappid(1093870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093871, 1, "7870bb488101ca5ec07d36fc035dd43a8977b3374063455e4f418874be7073e3")
