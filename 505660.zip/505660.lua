-- Lua provided by RyzenAPI 
-- Game: The Crystal Nebula
addappid(505660)
addappid(505661, 1, "1a2b5c577ba5fc042437d8930bda94f42865d09be52dc1a1a628ed680323404e")
