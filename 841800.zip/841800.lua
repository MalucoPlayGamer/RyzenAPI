-- Lua provided by RyzenAPI
-- Game: Game: Super Heroes: Men in VR beta

-- MAIN APPLICATION
addappid(841800)
-- Game: addappid(841800)

-- MAIN APP DEPOTS / PACKAGES
addappid(841801, 1, "80fe3c4b4abcd2a42282badb11cddb38e4be8538f6e2e884e80a432e4639d550")
