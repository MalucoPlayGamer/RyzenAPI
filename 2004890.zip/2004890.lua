-- Lua provided by RyzenAPI
-- Game: Nude In The Castle

-- MAIN APPLICATION
addappid(2004890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004891, 1, "7f37f29b60626ddb6d9f73c1e4b1d50923c102146a4ea5e83c6658687347bb7b")

