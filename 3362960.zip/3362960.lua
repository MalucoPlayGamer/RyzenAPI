-- Lua provided by RyzenAPI
-- Game: Twinkleby

-- MAIN APPLICATION
addappid(3362960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362961,0,"257e81861f78112a666969a60ac4e0fecf2a4e45c39bc0a8180996ce3b565adb")

