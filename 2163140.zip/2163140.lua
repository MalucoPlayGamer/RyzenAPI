-- Lua provided by RyzenAPI
-- Game: Ornament Express

-- MAIN APPLICATION
addappid(2163140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163141, 1, "76afa288bc23498357db6e724d67cb8f2b2564bccb594c682d6173336c151958")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
