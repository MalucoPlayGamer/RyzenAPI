-- Lua provided by RyzenAPI
-- Game: Ornament Express

-- MAIN APPLICATION
addappid(2163140)
-- Game: addappid(2163140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163141, 1, "76afa288bc23498357db6e724d67cb8f2b2564bccb594c682d6173336c151958")
