-- Lua provided by RyzenAPI
-- Game: Behind These Eyes

-- MAIN APPLICATION
addappid(666620)

-- MAIN APP DEPOTS / PACKAGES
addappid(666621,0,"d88ea8326e2626d276a25da02026d3f43a8766c34885b7e91355faba2f85f1d8")
addappid(666622,0,"27bdc989e27af6313d6ff7f7dddae7eb3e592228f209280f63f9da7f61077c35")

