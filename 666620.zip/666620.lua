-- Lua provided by RyzenAPI
-- Game: Behind These Eyes

-- MAIN APPLICATION
addappid(666620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(666621,0,"d88ea8326e2626d276a25da02026d3f43a8766c34885b7e91355faba2f85f1d8")
addappid(666622,0,"27bdc989e27af6313d6ff7f7dddae7eb3e592228f209280f63f9da7f61077c35")

