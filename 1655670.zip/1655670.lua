-- Lua provided by SkyAPI 
-- Game: Rob Riches
addappid(1655670)
addappid(1655671, 1, "aaf52648cd0522775a4f1d4d3632c2df9bca8848bf14cb24daa9b9c8c8e2e951")
