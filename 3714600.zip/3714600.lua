-- Lua provided by RyzenAPI
-- Game: 3714600

-- MAIN APPLICATION
addappid(3714600)
-- Game: addappid(3714600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3714601, 1, "14f9fbc7d993fae50efc1a417b5e8ec4f253ba2cb6c7179072ebf7a957c84997")
