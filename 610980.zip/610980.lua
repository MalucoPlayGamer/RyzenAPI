-- Lua provided by RyzenAPI
-- Game: The Midnight Sanctuary

-- MAIN APPLICATION
addappid(610980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(610981, 1, "21a40bc812482df98ef5ff91c5bec8d1cb0383948d0bd255f8af56d6e7b27f80")
addappid(610982, 1, "f5e5fd37483054c1545b384cdf84be3b99f0d26fbf4a028924ae351f86351fda")

