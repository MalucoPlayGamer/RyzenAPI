-- Lua provided by RyzenAPI
-- Game: 610980

-- MAIN APPLICATION
addappid(610980)
-- Game: addappid(610980)

-- MAIN APP DEPOTS / PACKAGES
addappid(610981, 1, "21a40bc812482df98ef5ff91c5bec8d1cb0383948d0bd255f8af56d6e7b27f80")
addappid(610982, 1, "f5e5fd37483054c1545b384cdf84be3b99f0d26fbf4a028924ae351f86351fda")
