-- Lua provided by RyzenAPI
-- Game: Relentless Frontier

-- MAIN APPLICATION
addappid(1677900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677901, 1, "67511f650f862a5f67c9f01046aaf4fcd2793472c35e5a9808b19f3e3065fa8a")
