-- Lua provided by RyzenAPI
-- Game: Evil School

-- MAIN APPLICATION
addappid(3818020) -- Evil School

-- MAIN APP DEPOTS / PACKAGES
addappid(3818021, 1, "3c3bea1d791631b31077c7668fc448570f9862cc9659dbf5cd10e829859b853f") -- Depot 3818021

