-- Lua provided by RyzenAPI
-- Game: Slitherise

-- MAIN APPLICATION
addappid(3191770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191771, 1, "23877733f7f89a99364f204898303f23e822bd3ef9131ca217c1c4ea07de00ad")

