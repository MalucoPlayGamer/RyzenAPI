-- Lua provided by RyzenAPI 
-- Game: Rakuen Original Soundtrack
addappid(572910)
addappid(572911, 1, "43ea65146ec0f37ef8ed0e61bca7fce78944d99948ba76e8c20cbeb50f1bab16")
