-- Lua provided by RyzenAPI
-- Game: Sketch! Run!

-- MAIN APPLICATION
addappid(602920)

-- MAIN APP DEPOTS / PACKAGES
addappid(602921, 1, "b04d8b19aa69bf72e7359452f42daaa1be378fa69ae3b07fee988956e84907a4")
