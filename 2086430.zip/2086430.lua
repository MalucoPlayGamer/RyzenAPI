-- Lua provided by RyzenAPI
-- Game: NIMRODS

-- MAIN APPLICATION
addappid(2086430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086432,0,"027b957a020894379976c203d53558eacd1459e14c73fd73986c6e45e423fd19")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3954450)
