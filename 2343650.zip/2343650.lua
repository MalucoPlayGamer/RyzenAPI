-- Lua provided by RyzenAPI
-- Game: AppID 2343650

-- MAIN APPLICATION
addappid(2343650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343651, 1, "205cbeba322400b81d2f61e963e0756c12ddce8b3804a9d834803617ef5ae788")
addappid(2343652, 1, "28ef60b067b379c0b1989179f7c3b27aa1f4aaa9b1fa7d28a0310d057be02396")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2534320)
addappid(2534330)
addappid(2534340)
addappid(2635090)
addappid(2781060)
