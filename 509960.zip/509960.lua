-- Lua provided by RyzenAPI 
-- Game: Pinga Ponga
addappid(509960)
addappid(509961, 1, "5991e5c44dcd25de99cf0a8b7363c2d1929a9d2c159ad2e00d15a8ce88a637e9")
