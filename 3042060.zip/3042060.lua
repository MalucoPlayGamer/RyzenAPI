-- Lua provided by RyzenAPI 
-- Game: Legend of the Moon
addappid(3042060)
addappid(3042061, 1, "48faed337f0ef86322527db9e20b5c69014ff78ae52d35bf40d516096724ed11")
