-- Lua provided by RyzenAPI
-- Game: 1452030

-- MAIN APPLICATION
addappid(1452030)
-- Game: addappid(1452030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452031, 1, "75957cd8ffc9d62877eafd54d96e3bb937370c2e46b0e3a9363a2ca6426b852e")
