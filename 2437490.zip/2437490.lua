-- Lua provided by RyzenAPI
-- Game: Reaper's Isle

-- MAIN APPLICATION
addappid(2437490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2437491, 1, "10082a5eec3071a876c3a940291e9c89464014380499ad6c6002eb07a1c4839f")

