-- Lua provided by RyzenAPI
-- Game: 3416270

-- MAIN APPLICATION
addappid(3416270)
-- Game: addappid(3416270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416271, 1, "0ecdeeb8452f2ecf55679a501da1e504ba30b6e434826e1f6b55f29db630b5c6")
