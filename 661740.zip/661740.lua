-- Lua provided by RyzenAPI
-- Game: Morphite

-- MAIN APPLICATION
addappid(661740)
-- Game: addappid(661740)

-- MAIN APP DEPOTS / PACKAGES
addappid(661741, 1, "f64b31fba8440ccbe06a3b1019e7b1ee5724582f7b045d66637e802a2c049252")
