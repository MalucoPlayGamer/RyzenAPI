-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Scenario & BGM Set 4

-- MAIN APPLICATION
addappid(1634711)
-- Game: addappid(1634711)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634711,0,"ae284652f598f679a3d61b79de3eff21a85a611b859e027d5460111a02bdb54e")
