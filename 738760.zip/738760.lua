-- Lua provided by RyzenAPI
-- Game: the Line

-- MAIN APPLICATION
addappid(738760)
addappid(894080)

-- MAIN APP DEPOTS / PACKAGES
addappid(738761,0,"09659b392d03ebb478c652c5a195be79064dada87d51539a8e37bab2a5fceef6")

