-- Lua provided by RyzenAPI
-- Game: 心霊旅館

-- MAIN APPLICATION
addappid(2773930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2773931, 1, "088aa1e8bb68b6e0c40f8c8f252b97cfb700e53c147faf87c09a0b447493f4de")

