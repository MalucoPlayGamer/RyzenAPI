-- Lua provided by SkyAPI 
-- Game: 心霊旅館
addappid(2773930)
addappid(2773931, 1, "088aa1e8bb68b6e0c40f8c8f252b97cfb700e53c147faf87c09a0b447493f4de")
