-- Lua provided by RyzenAPI
-- Game: Game: 心霊旅館

-- MAIN APPLICATION
addappid(2773930)
-- Game: addappid(2773930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773931, 1, "088aa1e8bb68b6e0c40f8c8f252b97cfb700e53c147faf87c09a0b447493f4de")
