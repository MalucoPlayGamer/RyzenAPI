-- Lua provided by RyzenAPI
-- Game: 2244794

-- MAIN APPLICATION
addappid(2244794)
-- Game: addappid(2244794)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244794,0,"1f5efe2a90f203022873f69691bdd0a252cb600b4ce1676a39ac7da041731d88")
