-- Lua provided by RyzenAPI 
-- Game: Fragments
addappid(1479940)
addappid(1479941, 1, "9af7980e5cc8bb9d5c30a2b3d50bf276b2642e342a63dcb0c1f3a14a78fe1f2a")
