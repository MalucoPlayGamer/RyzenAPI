-- Lua provided by RyzenAPI
-- Game: Game: Knights in Tight Spaces

-- MAIN APPLICATION
addappid(2315400)
-- Game: addappid(2315400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315401, 1, "7bc82ef006cc54f59a83a8a8d5b497c94a4c4e17908a1bacc40e26b351ccdf2c")
