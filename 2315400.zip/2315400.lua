-- Lua provided by RyzenAPI 
-- Game: Knights in Tight Spaces
addappid(2315400)
addappid(2315401, 1, "7bc82ef006cc54f59a83a8a8d5b497c94a4c4e17908a1bacc40e26b351ccdf2c")
