-- Lua provided by RyzenAPI
-- Game: BROK the InvestiGator - Prologue

-- MAIN APPLICATION
addappid(1318790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1318791, 1, "6038ea5e8711be2cc2438b6bde465148a5d2e67026e5688e1e0530c595d42be9")

