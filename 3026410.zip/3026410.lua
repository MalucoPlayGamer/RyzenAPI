-- Lua provided by RyzenAPI
-- Game: 3026410

-- MAIN APPLICATION
addappid(3026410)
-- Game: addappid(3026410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026413,0,"dad8e32e054cd7141054fa9b56fdbeaf94b2a10ed312b51cb3203ff3ee1109fa")
