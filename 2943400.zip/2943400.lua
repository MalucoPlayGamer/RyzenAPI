-- Lua provided by RyzenAPI
-- Game: addappid(2943400)

-- MAIN APPLICATION
addappid(2943400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943401, 1, "337230ca63ed274dd7016ac28031e09d7ab1c5dbd337eb4dc8b82a7c16d20a90")
