-- Lua provided by RyzenAPI
-- Game: addappid(834920)

-- MAIN APPLICATION
addappid(834920)

-- MAIN APP DEPOTS / PACKAGES
addappid(834921, 1, "8a8bfd2e9b6fc2458729185fcb6acc12bbb782a024e684ac50aa94810dafb6bf")
