-- Lua provided by RyzenAPI
-- Game: Let's Learn Korean! Hangul

-- MAIN APPLICATION
addappid(1255040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255041, 1, "75ce54e7780664db32127ae5a6b11511d1a51fb918f94be4d4e276eac126c51c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
