-- Lua provided by RyzenAPI
-- Game: AppID 1021000

-- MAIN APPLICATION
addappid(1021000)
-- Game: addappid(1021000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021001, 1, "7a0b82be234693044e6c268d9bae8c149420b9d61a389bfc67aef13f70e3efdf")
