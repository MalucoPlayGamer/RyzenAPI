-- Lua provided by RyzenAPI
-- Game: Game: ADULT SHERIFF

-- MAIN APPLICATION
addappid(1192730)
addappid(1206460)
-- Game: addappid(1192730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192731, 1, "50da66b2d9bfb519f926dac12b60cb304dfe2332c345a2e9c5d151933d041c87")
