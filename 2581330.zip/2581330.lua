-- Lua provided by SkyAPI 
-- Game: Moonstone Island Soundtrack
addappid(2581330)
addappid(2581331, 1, "5c3be39d3cc670be841eee2fad2211313e06ccc6023f4300f574d9f7e9dc4b10")
