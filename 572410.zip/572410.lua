-- Lua provided by RyzenAPI
-- Game: Steel Division: Normandy 44

-- MAIN APPLICATION
addappid(572410)
addappid(617050)
addappid(617051)
addappid(617780)
addappid(639060)
addappid(639061)
addappid(639062)
addappid(640180)
addappid(710800)
addappid(718600)
addappid(718630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(572411, 1, "19017ed9ddb4c15f7803607f33f247a1c2816ea9c19d9994f4a46c1c95d5fa33")
addappid(572412, 1, "321459ca7df971af5f121f32857c16223eb03585ab93bc6bac8839bf544864f3")
addappid(639063, 0, "6c6e7ff33cbc13a2cc7b1af926591bef4a4cdc18ce8aeb39cfdc937080f65fb0")
addappid(639064, 0, "aa8ae552357350197a26fca0e30fbb6a3cd86880d5c261cdef8583011c6e6b85")
addappid(639065, 0, "06f6ed8dd66c68e41eddadfd0a916be5a9cabcdc00891be0b364934c540ef8b1")
addappid(639066, 0, "f68b84d33f5c2135077d7f15878b1fe294d967fb8908d2bc14800fb031828e6e")
addappid(639067, 0, "3bd33135a3b8451bd929d4b1cfe06c76beacb4fc263b3fa8dff49d02a37235ca")
addappid(640960, 0, "ba5457c2ed67d0419f1bc24c14a8fa74f26f0f7cc44a71aae1ece9268dc298cd")
