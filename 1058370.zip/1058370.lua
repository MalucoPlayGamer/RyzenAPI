-- Lua provided by RyzenAPI
-- Game: Bone Voyage

-- MAIN APPLICATION
addappid(1058370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058371, 1, "d592e9ebc82dd53aba096a683a1d2e0ac5fd8ff20906f042666fff40a22a6ed2")
