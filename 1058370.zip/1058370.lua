-- Lua provided by RyzenAPI
-- Game: Bone Voyage

-- MAIN APPLICATION
addappid(1058370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058371, 1, "d592e9ebc82dd53aba096a683a1d2e0ac5fd8ff20906f042666fff40a22a6ed2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
