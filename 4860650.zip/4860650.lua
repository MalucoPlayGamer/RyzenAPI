-- Lua provided by RyzenAPI
-- Game: Floor Glitch

-- MAIN APPLICATION
addappid(4860650) -- Floor Glitch

-- MAIN APP DEPOTS / PACKAGES
addappid(4860651, 1, "835b4690ebad31e4cec90538ab3c6adee564f84888578a5464fd734233f03075") -- Depot 4860651

