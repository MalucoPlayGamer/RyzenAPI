-- Lua provided by RyzenAPI
-- Game: Eternights: Original Soundtrack

-- MAIN APPLICATION
addappid(2412331)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412331,0,"c94ca2e410ab51f20d02e9f030770966a0ebce092de7b36703f10c29bec95cae")
addappid(2412359,0,"cd3ae3ad50dc02711ad2c928ff12f1302be9b2f29f5c80fd1043768f9ea6c95f")

