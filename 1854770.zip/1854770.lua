-- Lua provided by RyzenAPI
-- Game: addappid(1854770)

-- MAIN APPLICATION
addappid(1854770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854771, 1, "e21ea0011d958e2c364c4e268283d71a3ebbba9281b22e8887891e4601b1f04a")
