-- Lua provided by RyzenAPI
-- Game: Braise Satan

-- MAIN APPLICATION
addappid(3295990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295991, 1, "995df399d0a09d8ce78f8688c7aa857558079ca69227488099790310e6ffe5f6")

