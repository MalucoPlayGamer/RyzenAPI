-- Lua provided by RyzenAPI
-- Game: WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure

-- MAIN APPLICATION
addappid(3034340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034341, 1, "3a6a236ea24a132fe1716b2a9fc3e6759885451b54d6e1a27ee8a84bf6ef12ce")
addappid(3328650, 0, "baf8a8ba06872d7730ae92598f3deb2ec2a6d4bc84c8a58a97e2ecca730fd214")
addappid(3612220, 0, "e35048b6bba03b9cfbd8e333944f15349f755c10130dece975728f59875d2ef1")
addappid(3612230, 0, "2a96e06665dbfea94af26ac57d5433acd1896dda6dafeb2e4b342691a340a687")
addappid(3612240, 0, "215b32d9ba2b00a5cd48dd90a2bb12e34edbdd5b66617831b9dc5b1e980dd338")
addappid(3612260, 0, "fe150aea1c34cf9044822f8de51910a2faea428cc6c172b2309344cfaa72add5")

