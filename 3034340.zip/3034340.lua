-- 3034340's Lua and Manifest Created by Hubcap Manifest
-- ワールドネバーランド　エルネア王国の日々　Another Life Adventure
-- Created: August 23, 2026 at 14:19:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 38
-- Total DLCs: 37 (1 excluded)

-- MAIN APPLICATION
addappid(3034340, 1, "ffda67f4e6af8c8fb9b5a31b8165b8f979752180a81a612c46e8b98387af6d1b") -- ワールドネバーランド　エルネア王国の日々　Another Life Adventure
-- MAIN APP DEPOTS
addappid(3034341, 1, "3a6a236ea24a132fe1716b2a9fc3e6759885451b54d6e1a27ee8a84bf6ef12ce") -- Depot 3034341
setManifestid(3034341, "5210244094148652374", 724542189)
-- DLCS WITH DEDICATED DEPOTS
-- Cherry Blossom Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 3177940)
addappid(3177940)
addappid(3177940, 1, "b352a3503c5be7e7a7f4bb70cc6d177528461be2a392ebebc41296231873c93a") -- Cherry Blossom Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 3177940
setManifestid(3177940, "5733337283817081487", 6343909)
-- Easter Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 3328640)
addappid(3328640)
addappid(3328640, 1, "b47f14b8a0e4a39b84f9dd54dd6a611749eed7da9c086b0bf27d4f535e501dad") -- Easter Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 3328640
setManifestid(3328640, "2302042142041343495", 6887786)
-- Elnea Kingdom DLC  Wa-Style Set (AppID: 3328650)
addappid(3328650)
addappid(3328650, 1, "baf8a8ba06872d7730ae92598f3deb2ec2a6d4bc84c8a58a97e2ecca730fd214") -- Elnea Kingdom DLC  Wa-Style Set - Depot 3328650
setManifestid(3328650, "2048977591034482523", 6330046)
-- Elnea Kingdom DLC  Challenge Dungeons (AppID: 3328660)
addappid(3328660)
addappid(3328660, 1, "c972578be2654e2e1c83979b82ae84a2b653bf227e14a043d9663e7e70fbb0d2") -- Elnea Kingdom DLC  Challenge Dungeons - Depot 3328660
setManifestid(3328660, "1396954023500806660", 112114741)
-- Elnea Kingdom DLC  Country Outfits (AppID: 3612220)
addappid(3612220)
addappid(3612220, 1, "e35048b6bba03b9cfbd8e333944f15349f755c10130dece975728f59875d2ef1") -- Elnea Kingdom DLC  Country Outfits - Depot 3612220
setManifestid(3612220, "1733231179151778360", 6885753)
-- Elnea Kingdom DLC  Wedding Attire (AppID: 3612230)
addappid(3612230)
addappid(3612230, 1, "2a96e06665dbfea94af26ac57d5433acd1896dda6dafeb2e4b342691a340a687") -- Elnea Kingdom DLC  Wedding Attire - Depot 3612230
setManifestid(3612230, "1213779359493509786", 4631303)
-- Elnea Kingdom DLC  Town Outfits (AppID: 3612240)
addappid(3612240)
addappid(3612240, 1, "215b32d9ba2b00a5cd48dd90a2bb12e34edbdd5b66617831b9dc5b1e980dd338") -- Elnea Kingdom DLC  Town Outfits - Depot 3612240
setManifestid(3612240, "2166997134056213901", 7328691)
-- Elnea Kingdom DLC  Handcraft Tools Set (AppID: 3612260)
addappid(3612260)
addappid(3612260, 1, "fe150aea1c34cf9044822f8de51910a2faea428cc6c172b2309344cfaa72add5") -- Elnea Kingdom DLC  Handcraft Tools Set - Depot 3612260
setManifestid(3612260, "7527958863002250114", 14350263)
-- Elnea Kingdom DLC - Seaside Wedding Set (AppID: 3828600)
addappid(3828600)
addappid(3828600, 1, "71712e3a6eaf278205d60c5f37c6d2b849cb22c8b680a5529f5cb06d7992f81b") -- Elnea Kingdom DLC - Seaside Wedding Set - Depot 3828600
setManifestid(3828600, "7660613059938715620", 8111891)
-- Elnea Kingdom DLC - Summer Wear Set (AppID: 3828630)
addappid(3828630)
addappid(3828630, 1, "bcba9d834fb6f1c3e65dd80bf0f2ff04b954ce53d9b6861f4600bd0ee95db058") -- Elnea Kingdom DLC - Summer Wear Set - Depot 3828630
setManifestid(3828630, "8189993107319163059", 6197401)
-- Elnea Kingdom DLC - Summer Sailor Set (AppID: 3828640)
addappid(3828640)
addappid(3828640, 1, "c22ef2daf774e436fc751354d5bf6c67314577f5451067ffee4affb16efe4aab") -- Elnea Kingdom DLC - Summer Sailor Set - Depot 3828640
setManifestid(3828640, "2538557174731099628", 7387302)
-- Elnea Kingdom DLC - Frontier Summer Clothes Set (AppID: 3828650)
addappid(3828650)
addappid(3828650, 1, "8bfc7b85eb91b36d8f7d431ec1d46328ef1ebf8ee2e6e8704d89df6ecd17bd15") -- Elnea Kingdom DLC - Frontier Summer Clothes Set - Depot 3828650
setManifestid(3828650, "2255470030656328288", 7283407)
-- Elnea Kingdom DLC - Japanese Autumn Festival Set (AppID: 3828660)
addappid(3828660)
addappid(3828660, 1, "924dd11c364c374b9f571be8dbcc5a18cf1dfb7e564ed80fd5fcca17551ccf68") -- Elnea Kingdom DLC - Japanese Autumn Festival Set - Depot 3828660
setManifestid(3828660, "5354532305626637300", 7372836)
-- Elnea Kingdom DLC - Autumn Colors Set (AppID: 3828670)
addappid(3828670)
addappid(3828670, 1, "41641fb32f71c5852dcc1b944f18b88c4b72f520549e9530a667784adb526d84") -- Elnea Kingdom DLC - Autumn Colors Set - Depot 3828670
setManifestid(3828670, "4621287853070833704", 8294270)
-- Monster Event Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 3978140)
addappid(3978140)
addappid(3978140, 1, "b93e85eaf5047aeae221ef374ad05945b33687cfadb4a342a74a2c874ceee547") -- Monster Event Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 3978140
setManifestid(3978140, "609973788294252981", 7643028)
-- Halloween Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4021460)
addappid(4021460)
addappid(4021460, 1, "bb3412415ae977f3986b53739c4b376fb9fba416e472dd18179b58388787bbce") -- Halloween Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4021460
setManifestid(4021460, "5518495175235387819", 6323422)
-- Nightfall Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4021470)
addappid(4021470)
addappid(4021470, 1, "26862b1c9963c59116cae8c7760992edd21694727cd4263c0d3c43b34ad1e37c") -- Nightfall Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4021470
setManifestid(4021470, "537988314331997438", 6494847)
-- Gift from Naruelu Kingdom - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4021480)
addappid(4021480)
addappid(4021480, 1, "8c7a86a9e9a52a6d708a01cb5bcae9409acf79beb77f68931d174cdc1694a0af") -- Gift from Naruelu Kingdom - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4021480
setManifestid(4021480, "9026391977203023329", 7596934)
-- Ihm Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4021490)
addappid(4021490)
addappid(4021490, 1, "2f1d85b22d2f82a09843ce3663445695371929f9dd8996832deb50efd15f2946") -- Ihm Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4021490
setManifestid(4021490, "2144533708689698219", 580670)
-- Nol Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4021500)
addappid(4021500)
addappid(4021500, 1, "a6e86516eb895feebfb52646e0c450e70cf4ac3e77d74ead9abc8797bfa9a8f8") -- Nol Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4021500
setManifestid(4021500, "2490076929300676854", 6929851)
-- Nol Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4021520)
addappid(4021520)
addappid(4021520, 1, "a2909667c3a7f0cc0a23cb7814741ac52978648aaec69fa5cbe1b9be13293252") -- Nol Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4021520
setManifestid(4021520, "7705380515346976150", 7161700)
-- Wa-Style New Year Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4195700)
addappid(4195700)
addappid(4195700, 1, "36bd7f1626da2a850f68815d3b4867931c4acc587010175d3ea5131ebe046f23") -- Wa-Style New Year Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4195700
setManifestid(4195700, "4241480239525860618", 7336929)
-- Fluffy Town Furs - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4195710)
addappid(4195710)
addappid(4195710, 1, "f83dd1d841d8eef0c2179c3c7776e2960122902f4d2d6392c1c1ebe06b65f707") -- Fluffy Town Furs - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4195710
setManifestid(4195710, "2899254229808718373", 7376677)
-- Chocolate Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4195720)
addappid(4195720)
addappid(4195720, 1, "de337dbf0d6403c5b4ac913d37f363dc3d0aaadce5b48e696243334b0c8cc713") -- Chocolate Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4195720
setManifestid(4195720, "6681742303601228252", 7506657)
-- Fishing Coats - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4195730)
addappid(4195730)
addappid(4195730, 1, "2626b1e1bfc1ca456a20e13b50c2d2bedc8e77e6cf7941ea7914eeacd11a9991") -- Fishing Coats - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4195730
setManifestid(4195730, "1326535352031036765", 6897730)
-- Flower Trimmed Wear - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4195750)
addappid(4195750)
addappid(4195750, 1, "286f80a5ba5136598fd280dcbec77a370976c33051d22423533b72fced857752") -- Flower Trimmed Wear - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4195750
setManifestid(4195750, "8330324685838086479", 6451128)
-- Pioneer Spring Outfits - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4195760)
addappid(4195760)
addappid(4195760, 1, "29f7a64797f66e402f49fe97631acedca6988d01b6f6ca6199bb62b8086e76ef") -- Pioneer Spring Outfits - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4195760
setManifestid(4195760, "2667487101807844955", 6313637)
-- Spring Tea Party - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4521150)
addappid(4521150)
addappid(4521150, 1, "14d457ee13ca41709035358d68611a6d2baa7df0837dbfc26f3b4198d9a4e9a7") -- Spring Tea Party - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4521150
setManifestid(4521150, "6228895349984380411", 7206695)
-- Floral Spring Outfit - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4521160)
addappid(4521160)
addappid(4521160, 1, "06c1452078e6943b42626438901a09f74f5b237ad1b910d7aa2d4d432285d918") -- Floral Spring Outfit - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4521160
setManifestid(4521160, "3384931852988700914", 7179046)
-- Fresh Green Season Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4521170)
addappid(4521170)
addappid(4521170, 1, "8c36be09dac3fc8145091f185fa6c2bc30789928053ef5ff3b60c9c88f506684") -- Fresh Green Season Attire - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4521170
setManifestid(4521170, "7133718697226123381", 7546851)
-- Island Resort - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4521180)
addappid(4521180)
addappid(4521180, 1, "57aa73f8089be4952651b41caec69aea222db8d843fbe7d65b90da0737f1c26d") -- Island Resort - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4521180
setManifestid(4521180, "1072294188635336042", 6948605)
-- Donut Day - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4521190)
addappid(4521190)
addappid(4521190, 1, "e887aa128a17ea41002cfc3aab1fdccb6510792a313688a5b61dfbd9bfcadff5") -- Donut Day - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4521190
setManifestid(4521190, "5906629853450002938", 1536020)
-- Modern Wedding - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4521200)
addappid(4521200)
addappid(4521200, 1, "0cb3f612920c871c858a97ac9e600fbb23c9823fa59c30ff9a56d81dae0dff88") -- Modern Wedding - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4521200
setManifestid(4521200, "7498328900044725422", 12539571)
-- Courier Uniforms - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4771070)
addappid(4771070)
addappid(4771070, 1, "c9a0e11cda93506a1c5e7f26fc06315a127d7b840fcd0439c4d00c06dbe7f056") -- Courier Uniforms - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4771070
setManifestid(4771070, "910792543586462814", 7055891)
-- Summer in the Kingdom - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4771090)
addappid(4771090)
addappid(4771090, 1, "e08e621809d435f679aa3e925947f5f7574b8c53b8834fb4e38a27e13e8b3113") -- Summer in the Kingdom - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4771090
setManifestid(4771090, "889098715059460496", 6727238)
-- Sunflower Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4771100)
addappid(4771100)
addappid(4771100, 1, "05d4fb97c9a19e3e846850fd6cf4faeccf169ba95873a256bf78302bd9071420") -- Sunflower Set - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4771100
setManifestid(4771100, "1639438453614699780", 5908200)
-- Summer Hiking Wear - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure (AppID: 4778140)
addappid(4778140)
addappid(4778140, 1, "d5db51a21fb278e7723708294120f58c42b4ee0762397cb891d74aadbcd854a8") -- Summer Hiking Wear - WorldNeverland - Daily Life in the Elnea Kingdom - Another Life Adventure - Depot 4778140
setManifestid(4778140, "8092231925642995440", 7534487)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4778150) -- DLC 4778150 (unreleased)