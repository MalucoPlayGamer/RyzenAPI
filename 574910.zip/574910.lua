-- Lua provided by RyzenAPI
-- Game: Game: The Bits That Saved The Universe

-- MAIN APPLICATION
addappid(574910)
-- Game: addappid(574910)

-- MAIN APP DEPOTS / PACKAGES
addappid(574911, 1, "2c484f596134a0753dc156b12dbca893ec03c3d152ae5abf51879d3dbf6ff82b")
