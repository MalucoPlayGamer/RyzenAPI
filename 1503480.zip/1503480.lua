-- Lua provided by RyzenAPI
-- Game: Paradigm Shift

-- MAIN APPLICATION
addappid(1503480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503481, 1, "5441c0bf5c5ee684c63b2e5f6f313d18e9c7e128e9a73bb26d3f3dd11e3fc618")
addappid(1503484, 1, "b288b37e3978529aa73ddac04ca43ed4a0e26081ee5512f659b6c55b9f170017")
