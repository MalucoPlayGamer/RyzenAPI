-- Lua provided by SkyAPI 
-- Game: Save the throne
addappid(2753110)
addappid(2753111, 1, "307b8880293b7251bd3654951485a832a7ff413266511880e81ad84b8854396f")
