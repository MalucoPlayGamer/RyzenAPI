-- Lua provided by RyzenAPI
-- Game: Storage Guys

-- MAIN APPLICATION
addappid(3103460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103461, 1, "d39ad94d5d576b272e0e477f4c472db92b57a0b879fbdac451a1700784b97512")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
