-- Lua provided by RyzenAPI
-- Game: addappid(276870)

-- MAIN APPLICATION
addappid(276870)

-- MAIN APP DEPOTS / PACKAGES
addappid(276871, 1, "e43abc38c2b595f6a72fadb2a1dd6d627cbc498407310124e4ec2778b9364ee5")
