-- Lua provided by RyzenAPI
-- Game: Game: Kukui 2

-- MAIN APPLICATION
addappid(1182260)
-- Game: addappid(1182260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182261, 1, "7896ff17c2a799bb724dcb998ebac8bfd7cec184166ff63316f59246109059c2")
