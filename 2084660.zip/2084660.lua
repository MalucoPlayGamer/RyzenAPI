-- Lua provided by RyzenAPI
-- Game: Master of The Earth: Chapter 1

-- MAIN APPLICATION
addappid(2084660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084661, 1, "76129de27c463cbf79c1564fe35f7de346f8eb85c82e4cd9e6766db6307a3a7c")
