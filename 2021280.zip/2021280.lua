-- Lua provided by RyzenAPI
-- Game: Game: Inside My Mind 2

-- MAIN APPLICATION
addappid(2021280)
-- Game: addappid(2021280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021281, 1, "fb1a9472d30695bd4532c42daa406a0bb6df1b3377c1b5a8944169585bf15b45")
