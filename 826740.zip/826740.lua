-- Lua provided by RyzenAPI
-- Game: 826740

-- MAIN APPLICATION
addappid(826740)
-- Game: addappid(826740)

-- MAIN APP DEPOTS / PACKAGES
addappid(826741, 1, "b74923e2f8b4e6672f08dbfe7f6fbd51df449c7af7dc4c86a7533be0db89e97b")
