-- Lua provided by SkyAPI 
-- Game: Rise of the Slime
addappid(826740)
addappid(826741, 1, "b74923e2f8b4e6672f08dbfe7f6fbd51df449c7af7dc4c86a7533be0db89e97b")
