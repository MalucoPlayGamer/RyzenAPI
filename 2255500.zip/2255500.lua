-- Lua provided by RyzenAPI
-- Game: Game: Mechanic Heroes Demo

-- MAIN APPLICATION
addappid(2255500)
-- Game: addappid(2255500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255501, 1, "b097a16528701e60972b76b3f15592e6f2e37295583dfd8f36dad975a9b8280e")
