-- Lua provided by SkyAPI 
-- Game: HeadHorse Legacy
addappid(2073790)
addappid(2073791, 1, "d93bfe38c36134e0f4f8bc8d61167208470b96a96035477545c210ec270802b2")
