-- Lua provided by RyzenAPI
-- Game: Pratfall

-- MAIN APPLICATION
addappid(4327880) -- Pratfall - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4244510, 1, "956c9391ad465b7ec5a1594b981371d733a6b3efa0a2a2281c73c592de99e91d") -- Pratfall
addappid(4244511, 1, "f51cc41519216d4769c3d179a9ca0908c96de20df61c3a4b5e461f27e8a75dec") -- Depot 4244511

