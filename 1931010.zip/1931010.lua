-- Lua provided by SkyAPI 
-- Game: Spirittea
addappid(1931010)
addappid(1931011, 1, "89f624162d1048ed54375ffda17a403e4a68dbc31db25dee01a2c1ec1d08c240")
