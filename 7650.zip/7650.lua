-- Lua provided by RyzenAPI
-- Game: X-COM: Terror From the Deep

-- MAIN APPLICATION
addappid(7650)

-- MAIN APP DEPOTS / PACKAGES
addappid(7651, 1, "7dac116ddfe0ab3e06866b2a6dfffd44d546fac5d9f1c90a0068ee4a90aad536")
