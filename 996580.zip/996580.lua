-- Lua provided by RyzenAPI
-- Game: Spyro™ Reignited Trilogy

-- MAIN APPLICATION
addappid(996580)

-- MAIN APP DEPOTS / PACKAGES
addappid(996581, 1, "43f678f5e86f5f0e6f236ba830580719be039e1185121a7650e3a5733e593865")
addappid(996582, 1, "6cab8b3208e30fc352684bb5ca8390e5e7e22926b56cf58545f72b528e87a923")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
