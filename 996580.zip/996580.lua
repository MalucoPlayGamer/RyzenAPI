-- Lua provided by SkyAPI 
-- Game: Spyro™ Reignited Trilogy
addappid(996580)
addappid(996581, 1, "43f678f5e86f5f0e6f236ba830580719be039e1185121a7650e3a5733e593865")
addappid(996582, 1, "6cab8b3208e30fc352684bb5ca8390e5e7e22926b56cf58545f72b528e87a923")
