-- Lua provided by SkyAPI 
-- Game: Neko Maid
addappid(1849890)
addappid(1849891, 1, "e43bfe52b4cb42da892c849f4a5c4075e4d878c7a1dfbdd651eceec0f70c5fa4")
