-- Lua provided by RyzenAPI
-- Game: 超级星探 OST

-- MAIN APPLICATION
addappid(3088060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088061, 1, "4a700bdd8335781e4b891772da7efcb14a3d4a92b5dde0f84affef437200d9cc")
