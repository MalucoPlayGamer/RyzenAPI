-- Lua provided by RyzenAPI
-- Game: Dissimilation

-- MAIN APPLICATION
addappid(795320)

-- MAIN APP DEPOTS / PACKAGES
addappid(795321,0,"05dcff9fc4e7c67f6ddd826903484c6ad9e16458111f09baab158c07c423c224")

