-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(659970)

-- MAIN APP DEPOTS / PACKAGES
addappid(659970,0,"26664e0346dffd597fc9e4f7d7119a70358418164430782c73e4af445fcd50fc")
addappid(659972,0,"a3285c35dd6403e50854ce3470b2610e1efdc7e571cd7298983ee98d22858975")

