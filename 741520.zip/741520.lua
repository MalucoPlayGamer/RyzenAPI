-- Lua provided by RyzenAPI
-- Game: Professor Lupo and his Horrible Pets

-- MAIN APPLICATION
addappid(741520)
addappid(741526)
addappid(741527)

-- MAIN APP DEPOTS / PACKAGES
addappid(741522,0,"8e954747e7162135c340f022f0bb5fb7f94fd412d03fcb5f59dc2fdd53c8e406")
addappid(741523,0,"08d6e88b0bb5f53b70cdc98b68ca8956ae01231b394c0aec6e5b3633f00a10b6")
