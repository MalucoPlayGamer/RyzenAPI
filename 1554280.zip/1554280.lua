-- Lua provided by RyzenAPI
-- Game: Asteroids Maneuvers

-- MAIN APPLICATION
addappid(1554280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554281, 1, "5ee9b24e1c2d05f7a53ad34b458bc0797fc52143d6aedb878717c178b19e1a21")

