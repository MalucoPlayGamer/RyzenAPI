-- Lua provided by RyzenAPI
-- Game: 2549780

-- MAIN APPLICATION
addappid(2549780)
-- Game: addappid(2549780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549781, 1, "07df7d7e96816e68a61e7a46e41d9b8066dafeb91f53f39125a28170a8f974e7")
