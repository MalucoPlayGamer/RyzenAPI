-- Lua provided by SkyAPI 
-- Game: Flairtender
addappid(586020)
addappid(586021, 1, "812e81b6ad7d790a4a82d0f04abb73736770b5dc4c1685632f8f91fe35f6f537")
