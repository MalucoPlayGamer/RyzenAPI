-- Lua provided by RyzenAPI
-- Game: addappid(586020)

-- MAIN APPLICATION
addappid(586020)

-- MAIN APP DEPOTS / PACKAGES
addappid(586021, 1, "812e81b6ad7d790a4a82d0f04abb73736770b5dc4c1685632f8f91fe35f6f537")
