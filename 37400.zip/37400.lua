-- Lua provided by SkyAPI 
-- Game: Time Gentlemen, Please! and Ben There, Dan That! Special Edition  Double Pack
addappid(37400)
addappid(37401, 1, "939b20dd2240324f97b163b4ad45b4e8382fb1691e7e07b33d9661c62fbe17b8")
