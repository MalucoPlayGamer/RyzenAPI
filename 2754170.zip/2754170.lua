-- Lua provided by RyzenAPI 
-- Game: AppID 2754170
addappid(2754170)
addappid(2754171, 1, "e7feb783e9bff0abb61b60c0d57e1985925acb96c85c8b6307706732b867472c")
