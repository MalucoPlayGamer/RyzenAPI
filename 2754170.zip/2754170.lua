-- Lua provided by RyzenAPI
-- Game: Sore wa Maichiru Sakura no You ni -Re:BIRTH-

-- MAIN APPLICATION
addappid(2754170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754171, 1, "e7feb783e9bff0abb61b60c0d57e1985925acb96c85c8b6307706732b867472c")
