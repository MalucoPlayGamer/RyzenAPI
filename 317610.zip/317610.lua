-- Lua provided by RyzenAPI
-- Game: AppID 317610

-- MAIN APPLICATION
addappid(317610)

-- MAIN APP DEPOTS / PACKAGES
addappid(317611, 1, "3888f92d8cddf34c5b1c5f06f0ca2e5a6537d16540ecc2662ceb2c5afae824a2")
addappid(317612, 1, "cc6dd5ef6186eca1a3c85f7fb5d88dd092f8e6514064daccad6d443ecc6f4ce0")
addappid(317613, 1, "ff005da951d840dddea7cc2f5344d860cbc8b7dfd4bae0d0637c9e80a2c2399d")
addappid(328790, 0, "aa2e475533714732a436bb7a573f23038b59918a9847fd468b83f26effdcc3ba")
