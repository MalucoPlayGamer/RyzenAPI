-- Lua provided by RyzenAPI
-- Game: Vizzle

-- MAIN APPLICATION
addappid(1691860)
-- Game: addappid(1691860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691863,0,"03286b9e03a94492bde7292ea150139bbb9760ec27913c0a46d2df87f5d4a135")
