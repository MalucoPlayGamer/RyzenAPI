-- Lua provided by RyzenAPI
-- Game: Game: The Day Before

-- MAIN APPLICATION
addappid(1372880)
-- Game: addappid(1372880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372881, 1, "c2f266082b4666e8fccf6b72330a6db8c7173c85d7ea8e7438cad8faae710a49")
