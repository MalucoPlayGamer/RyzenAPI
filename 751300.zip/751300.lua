-- Lua provided by RyzenAPI
-- Game: Alice Mystery Garden

-- MAIN APPLICATION
addappid(751300)
-- Game: addappid(751300)

-- MAIN APP DEPOTS / PACKAGES
addappid(751301, 1, "dff49742712b209bc43d03e3ef474a70b428d9ad7f6ffec3f14fcbb6a36bdc04")
