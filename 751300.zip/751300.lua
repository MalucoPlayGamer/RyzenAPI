-- Lua provided by RyzenAPI
-- Game: Alice Mystery Garden

-- MAIN APPLICATION
addappid(751300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(751301, 1, "dff49742712b209bc43d03e3ef474a70b428d9ad7f6ffec3f14fcbb6a36bdc04")

