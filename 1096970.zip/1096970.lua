-- Lua provided by RyzenAPI
-- Game: Game: AppID 1096970

-- MAIN APPLICATION
addappid(1096970)
-- Game: addappid(1096970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096971, 1, "243839a5ec07d6d0bd2d4849b0e096dff59116424ac67aec72b31a09fd0d7d8d")
