-- Lua provided by RyzenAPI
-- Game: 1515890

-- MAIN APPLICATION
addappid(1515890)
-- Game: addappid(1515890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515891, 1, "04504030aa61f3f714c01240824dab1fafee42c7de7df2dc296fb87592334a52")
