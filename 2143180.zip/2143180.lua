-- Lua provided by RyzenAPI
-- Game: Hide Time

-- MAIN APPLICATION
addappid(2143180)
addappid(2289760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143181, 1, "959edf76f1c44ec8807292fff15a35d3d656aad1433896bbe86ae94ad6fc94b9")
