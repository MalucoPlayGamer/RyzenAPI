-- Lua provided by RyzenAPI
-- Game: AppID 1171260

-- MAIN APPLICATION
addappid(1171260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171261, 1, "27b8ec8bfda936a49eec4a9ae79d4cffc16ac9de24309a6c0653a446206b7ed7")

