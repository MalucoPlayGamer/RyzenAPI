-- Lua provided by SkyAPI 
-- Game: Node Farm Demo
addappid(2954390)
addappid(2954391, 1, "a587781697f469d9a7096cc4028b3221608e343cd59b0a4cdf07541a0445cbb4")
