-- Lua provided by RyzenAPI 
-- Game: ZOMBI
addappid(339230)
addappid(339231, 1, "f0b86f54800c1995321f383a3bf663832f819e48efaf6b4b5b61037ef391700a")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
