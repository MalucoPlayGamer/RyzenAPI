-- Lua provided by RyzenAPI
-- Game: addappid(2059670)

-- MAIN APPLICATION
addappid(2059670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059671, 1, "0a2c533e27e31b54193a233e8c1c5b3d8502134d795d09231ac1306aaafe9eb2")
