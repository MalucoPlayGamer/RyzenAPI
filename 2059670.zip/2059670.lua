-- Lua provided by RyzenAPI
-- Game: Moss II VR

-- MAIN APPLICATION
addappid(2059670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059671, 1, "0a2c533e27e31b54193a233e8c1c5b3d8502134d795d09231ac1306aaafe9eb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
