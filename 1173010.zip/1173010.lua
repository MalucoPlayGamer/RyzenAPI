-- Lua provided by RyzenAPI 
-- Game: AppID 1173010
addappid(1173010)
addappid(1173011, 1, "ef757ea3058d8a35fe07b0c60b743fd294fc74740fe8b5d1ab968591d7a0d31b")
