-- Lua provided by RyzenAPI
-- Game: Bahamut and the Waqwaq Tree

-- MAIN APPLICATION
addappid(2525300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525301, 1, "6d91d381135a5a8ce727b959e7490e8a5f4c591c8f0edc10675d4575c9789ae2")

