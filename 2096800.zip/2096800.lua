-- Lua provided by RyzenAPI
-- Game: Steel Saviour Reloaded

-- MAIN APPLICATION
addappid(2096800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096801, 1, "a1dd2eb9a6890a32f01f32a811940568a0bde324c7f2018759bed2f0429e05f4")
addappid(2096802, 1, "bfd5ad6817c5da601b193da6ab501f335295016c6b6562e45be0d4d9343a430c")

