-- Lua provided by RyzenAPI
-- Game: addappid(2023180)

-- MAIN APPLICATION
addappid(2023180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023181, 1, "7b18076d53604db478e5cc63f368a4e5b3aa28dbdef73404eab859f8ba52984f")
