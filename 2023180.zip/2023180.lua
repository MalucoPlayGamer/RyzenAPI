-- Lua provided by SkyAPI 
-- Game: Fixeight
addappid(2023180)
addappid(2023181, 1, "7b18076d53604db478e5cc63f368a4e5b3aa28dbdef73404eab859f8ba52984f")
