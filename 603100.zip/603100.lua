-- Lua provided by RyzenAPI
-- Game: ATOMINE

-- MAIN APPLICATION
addappid(603100)

-- MAIN APP DEPOTS / PACKAGES
addappid(603101, 1, "e89b8be1edc861a04e5b1b75af419e6f4090f86e03c8475b8d0facc5be27a4b2")
