-- Lua provided by RyzenAPI
-- Game: addappid(2793310)

-- MAIN APPLICATION
addappid(2793310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793311, 1, "37da9a14882ecf7f8481e8fecbeb97a4ca93ef12135962378d6b7c8b6d0e6548")
