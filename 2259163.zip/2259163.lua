-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Society Islands XP - Bora Bora & Leeward Islands

-- MAIN APPLICATION
addappid(2259163)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259163,0,"2d68a6dcb0c82a89bf131c6d27dbfaaad67da2622a9a93a1d10389d1985aeeec")

