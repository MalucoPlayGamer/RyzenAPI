-- Lua provided by RyzenAPI
-- Game: Rogue : Genesia Demo

-- MAIN APPLICATION
addappid(2099800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099801, 1, "9756a3540038ad4a27127803ffb8d7597fa16aa0ebfb90003cfc68f0d74aae27")
