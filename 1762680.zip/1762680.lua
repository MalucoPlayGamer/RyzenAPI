-- Lua provided by RyzenAPI
-- Game: 1762680

-- MAIN APPLICATION
addappid(1762680)
-- Game: addappid(1762680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762681, 1, "5c76bca43379c05edfee79a522dfa0b7a9bf26348b49f122d03bafdb059a4d9f")
