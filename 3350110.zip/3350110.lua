-- Lua provided by RyzenAPI
-- Game: The Alchemist & His Battle-Scarred Homunculus

-- MAIN APPLICATION
addappid(3350110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350111, 1, "6ec28f806a66590f5ffc14d64b32091101b7773ec4a730bb1b3a97d1505c1593")
