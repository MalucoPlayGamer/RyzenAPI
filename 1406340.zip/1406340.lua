-- Lua provided by RyzenAPI
-- Game: addappid(1406340)

-- MAIN APPLICATION
addappid(1406340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406341, 1, "1afc73e915741a3dfe8f91409ab56ac514fe2a6945c0c96e1e61c09f72b08ccc")
