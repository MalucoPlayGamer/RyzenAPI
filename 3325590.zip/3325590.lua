-- Lua provided by RyzenAPI
-- Game: addappid(3325590)

-- MAIN APPLICATION
addappid(3325590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3325591, 1, "8debdfd8c76316a5a1f87b85582accd4d40911938ec7c026057f7f8f41799d0e")
