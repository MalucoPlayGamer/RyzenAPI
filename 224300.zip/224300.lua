-- Lua provided by RyzenAPI
-- Game: 224300

-- MAIN APPLICATION
addappid(224300)
-- Game: addappid(224300)

-- MAIN APP DEPOTS / PACKAGES
addappid(224301, 1, "953941e58e80d8b4acb7fcbff1f3b078b421e7784a47146e40e80b68d6b5b43d")
