-- Lua provided by RyzenAPI
-- Game: Yukikoi Melt

-- MAIN APPLICATION
addappid(1253390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253391, 1, "922e86a990aa02008774e02e30f64266c0f6051311e2ea4ec65b38caac76f399")

