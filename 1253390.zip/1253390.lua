-- Lua provided by RyzenAPI
-- Game: Yukikoi Melt

-- MAIN APPLICATION
addappid(1253390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1253391, 1, "922e86a990aa02008774e02e30f64266c0f6051311e2ea4ec65b38caac76f399")

