-- Lua provided by RyzenAPI
-- Game: addappid(1566730)

-- MAIN APPLICATION
addappid(1566730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566731, 1, "3e2c64284271d3c0482432a8fb687bc012c9924fce6f9cdcf445b657f2cd3d6e")
