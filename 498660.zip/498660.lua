-- Lua provided by RyzenAPI
-- Game: Mind Spheres

-- MAIN APPLICATION
addappid(498660)
-- Game: addappid(498660)

-- MAIN APP DEPOTS / PACKAGES
addappid(498661, 1, "d58f94369040c331a297bdd9383df7c9e6e35c102987c26f738dea1f5f37978a")
addappid(498662, 1, "acb8a860b4f45790a6ffc52ce5466ef56dd97da54787aa496a4093a302fa2362")
addappid(499360, 0, "361910a44e227ef3bd16997c1f0656239ef5e7c622029b3ba355078dbc3b1ada")
