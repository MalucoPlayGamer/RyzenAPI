-- Lua provided by RyzenAPI 
-- Game: Smithworks
addappid(1568540)
addappid(1568541, 1, "0b970857c7b5e1c6829e6ad710e72531de961cd562afec2b4d222e989e9af680")
addappid(1568542, 1, "dbd015960306cc73acaa00b93f43c9505780cd8f3462e25bbdd50055449ab436")
