-- Lua provided by RyzenAPI 
-- Game: Tsukai Furushita Kotoba Ya Uta Wo MV
addappid(1165570)
addappid(1165571, 1, "8b6d0d489901506744c2ad16d8af0382ad301c7c00933de4dcdf07e49db3aed4")
