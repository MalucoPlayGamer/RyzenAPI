-- Lua provided by RyzenAPI
-- Game: Game: Batman - The Telltale Series

-- MAIN APPLICATION
addappid(498240)
-- Game: addappid(498240)

-- MAIN APP DEPOTS / PACKAGES
addappid(498241, 1, "6c3bfd45e0c0888d53d77be4d8c5f9f9ac745bbfbc61b3f81c3a4b2ff15390d1")
addappid(498243, 1, "118d1faeacd0f5fa58ff309617486561f6a983c9922cb1d835c1ab00b5dc2ac2")
addappid(498245, 1, "ec94676efe67a10c81d467fb50d858aaa2a20a142262f7389bb1e15a5203aafe")
addappid(498247, 1, "30a00f813ae353e6c441aa69c45657666a025ffc3c496263d9460d56f3366394")
addappid(498249, 1, "637bcbca7f69f1156553179e06a46a6069b5c26ab446c9e008519f04825960e5")
addappid(551921, 1, "280a2f38a432603d9fd38ab47042cb8ea9ba0106122810b0567d73a53af795c0")
addappid(551923, 1, "b96b7801bbd84a7e9b67feb3c387cebfb97fa4bd8dcd144d419f16cdadd1bd5b")
addappid(1182000, 0, "f4113e2f7553cb4c80de09e3e18df32b995c39b5ff085a2ac76fc0104e16841d")
