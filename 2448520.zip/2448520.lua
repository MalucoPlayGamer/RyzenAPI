-- Lua provided by SkyAPI 
-- Game: AppID 2448520
addappid(2448520)
addappid(2448521, 1, "f16ad479ec9a7cb8c64316dd8edd1ad1d3eb84ae56f1347c9b2d60bcdc462688")
