-- Lua provided by RyzenAPI
-- Game: Backpack Hero Demo

-- MAIN APPLICATION
addappid(2066510)
-- Game: addappid(2066510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066512,0,"c9879e9b7d358246d38ba88d591d0a631f67ff40081326811e0ab4e115de0e4f")
