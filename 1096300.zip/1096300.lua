-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(1096300)
addappid(1096301)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096302,0,"0c01d776a2328ff123757cce5e09d1042417b0ecf3ff349fdbda5ffb32b0a609")
