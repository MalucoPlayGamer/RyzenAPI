-- Lua provided by RyzenAPI
-- Game: addappid(2553760)

-- MAIN APPLICATION
addappid(2553760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553761, 1, "4a8e82d464475f673b22908d4d7d25923871fb1abacc89e2a0e6cf6a2f153714")
