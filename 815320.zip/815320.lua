-- Lua provided by RyzenAPI 
-- Game: AppID 815320
addappid(815320)
addappid(815321, 1, "df180193b266632dd8345e2b74629f8acf54831a7d618c03e8a8d77b6455c233")
