-- Lua provided by RyzenAPI
-- Game: Game: AppID 815320

-- MAIN APPLICATION
addappid(815320)
-- Game: addappid(815320)

-- MAIN APP DEPOTS / PACKAGES
addappid(815321, 1, "df180193b266632dd8345e2b74629f8acf54831a7d618c03e8a8d77b6455c233")
