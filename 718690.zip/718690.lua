-- Lua provided by RyzenAPI
-- Game: SteamWorld Dig 2 OST Feat. El Huervo

-- MAIN APPLICATION
addappid(718690)
-- Game: addappid(718690)

-- MAIN APP DEPOTS / PACKAGES
addappid(718690,0,"ef9669daa2e84c6149f47ab4bf518cbbd51a08c9efe8157bba8f756bde669117")
