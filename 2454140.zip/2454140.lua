-- Lua provided by SkyAPI 
-- Game: Bichito Clicker
addappid(2454140)
addappid(2454141, 1, "66d287306069ea73c45b34a39828352be4ab115b627d7da0399540d113467026")
