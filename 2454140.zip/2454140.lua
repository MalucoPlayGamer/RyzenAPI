-- Lua provided by RyzenAPI
-- Game: Bichito Clicker

-- MAIN APPLICATION
addappid(2454140)
-- Game: addappid(2454140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454141, 1, "66d287306069ea73c45b34a39828352be4ab115b627d7da0399540d113467026")
