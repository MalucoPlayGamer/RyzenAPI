-- Lua provided by RyzenAPI
-- Game: Glasswinged Ascension

-- MAIN APPLICATION
addappid(668670)

-- MAIN APP DEPOTS / PACKAGES
addappid(668671, 1, "8750df955879ba77129d8e2525c397e80077b97e6abf182ffe85f354d1225f76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
