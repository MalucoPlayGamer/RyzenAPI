-- Lua provided by RyzenAPI
-- Game: Glasswinged Ascension

-- MAIN APPLICATION
addappid(668670)

-- MAIN APP DEPOTS / PACKAGES
addappid(668671, 1, "8750df955879ba77129d8e2525c397e80077b97e6abf182ffe85f354d1225f76")
