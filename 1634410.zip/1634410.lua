-- Lua provided by RyzenAPI
-- Game: 1634410

-- MAIN APPLICATION
addappid(1634410)
-- Game: addappid(1634410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634411, 1, "473baf1a71712fb02e1c49b7f8836c57f7a0417fa2006e37baf1af259aa0bc8b")
