-- Lua provided by RyzenAPI
-- Game: Billy 101

-- MAIN APPLICATION
addappid(1836280)
-- Game: addappid(1836280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836281, 1, "747629782380d0ff6482bf1d59a5daeef81137b6383811365a1f72ecca1e9bb8")
