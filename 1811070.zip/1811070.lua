-- Lua provided by RyzenAPI
-- Game: Fritz 18 Steam Edition

-- MAIN APPLICATION
addappid(1811070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811071, 1, "202de4598932881af5363945f8226a69828ec459c042766c14263d2f9287ed73")
addappid(1811072, 1, "2f8c53d2e62564d30e137fe8539d82781e0fd0f10a974780263f896ca234c2d3")
addappid(1811074, 1, "45f678381644345a21ae024cd1e9aefd6f947f68d8ba6aa64eb89f6e8a200783")
addappid(1811076, 1, "139a9510e513ec98bde27b45da2254d25ffbf70b099d19ab9237f376705d6d5c")
addappid(1811077, 1, "10e9dc82690fec922a8cb6bc47114b11267ef6fa05e9913f3be16b4f05cc0c33")
addappid(1811078, 1, "1d0c015e79e8224544db2fbcc4f2dec87b2276fbb4172dc09cf2f77854297b8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
