-- Lua provided by RyzenAPI
-- Game: Nelo

-- MAIN APPLICATION
addappid(537000)

-- MAIN APP DEPOTS / PACKAGES
addappid(537002,0,"fe935a4ed69f191d70aae08d8637b084b83b08c859dff857453e35a2e2a0bd8c")

