-- Lua provided by RyzenAPI
-- Game: PolyClassic: Wild

-- MAIN APPLICATION
addappid(1631850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631851, 1, "56565eee6f500507a5234f6e111440b86b4b73f93f9c316fa685a6ff5f3777a4")
