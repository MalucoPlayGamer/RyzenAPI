-- Lua provided by RyzenAPI
-- Game: The Supper

-- MAIN APPLICATION
addappid(1171370)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1172110)
