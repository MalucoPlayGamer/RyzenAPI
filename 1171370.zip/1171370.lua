-- Lua provided by RyzenAPI
-- Game: The Supper

-- MAIN APPLICATION
addappid(1171370)
addappid(1172110)

