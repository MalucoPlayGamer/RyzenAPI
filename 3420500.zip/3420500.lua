-- Lua provided by RyzenAPI
-- Game: Temple-Cobolia-Benchmark

-- MAIN APPLICATION
addappid(3420500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3420501, 1, "08fcd76f0a3b28886bc0baa9a33497964ca2796bee21dc7d89a0e05020f7c0b1")
