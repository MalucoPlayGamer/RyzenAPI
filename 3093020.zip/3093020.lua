-- Lua provided by RyzenAPI
-- Game: addappid(3093020)

-- MAIN APPLICATION
addappid(3093020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3093021, 1, "076481e8dd48a50f8cf36c4fa3240142752032b0ff483886d4a1cf4cfbae0be2")
