-- Lua provided by RyzenAPI
-- Game: Colorful Life

-- MAIN APPLICATION
addappid(565640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(565641, 1, "c1681a91f30e19780a3195b06efad7249613b1831baf03f2f4cf4c3ce77deecf")

