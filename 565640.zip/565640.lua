-- Lua provided by RyzenAPI
-- Game: Game: Colorful Life

-- MAIN APPLICATION
addappid(565640)
-- Game: addappid(565640)

-- MAIN APP DEPOTS / PACKAGES
addappid(565641, 1, "c1681a91f30e19780a3195b06efad7249613b1831baf03f2f4cf4c3ce77deecf")
