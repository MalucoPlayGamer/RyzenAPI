-- Lua provided by RyzenAPI
-- Game: 2491140

-- MAIN APPLICATION
addappid(2491140)
-- Game: addappid(2491140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491141, 1, "a24a3d01333bea786b8a28261ea8a23388330d83395d60f783817a4a3bacaa67")
