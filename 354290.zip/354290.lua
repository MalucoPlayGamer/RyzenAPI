-- Lua provided by RyzenAPI
-- Game: LoveBeat

-- MAIN APPLICATION
addappid(354290)

-- MAIN APP DEPOTS / PACKAGES
addappid(354291, 1, "e5dde6c353b6184cb4ea88d8a4111f8dca95ce263833ce38c55980d42b0eb050")
