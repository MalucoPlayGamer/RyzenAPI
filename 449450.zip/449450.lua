-- Lua provided by RyzenAPI
-- Game: Game: SPLIT BULLET

-- MAIN APPLICATION
addappid(449450)
-- Game: addappid(449450)

-- MAIN APP DEPOTS / PACKAGES
addappid(449451, 1, "d27fe74daa640b04e0348239e6548dc98ed34f4143606b3633c5a045a2fc306d")
