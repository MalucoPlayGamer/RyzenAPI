-- Lua provided by RyzenAPI
-- Game: Bobbi_Cities

-- MAIN APPLICATION
addappid(708280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(708281, 1, "7f73b1af1cba4a1d93271293fdbac13fd1294a7611d305dca1c6ee52c6056379")

