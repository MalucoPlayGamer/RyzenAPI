-- Lua provided by RyzenAPI
-- Game: 708280

-- MAIN APPLICATION
addappid(708280)
-- Game: addappid(708280)

-- MAIN APP DEPOTS / PACKAGES
addappid(708281, 1, "7f73b1af1cba4a1d93271293fdbac13fd1294a7611d305dca1c6ee52c6056379")
