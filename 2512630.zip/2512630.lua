-- Lua provided by RyzenAPI
-- Game: One Life To Alice

-- MAIN APPLICATION
addappid(2512630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512631, 1, "d1ab8babc89fa48cad461d1aa9c822a6116c4865077ec833da8462732179674a")
