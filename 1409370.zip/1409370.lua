-- Lua provided by RyzenAPI
-- Game: Psych

-- MAIN APPLICATION
addappid(1409370)
-- Game: addappid(1409370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409371, 1, "e73bf269109c7a55507ebcde5292da8a9dd1b2e74ac7866bd58822d951ae3711")
