-- Lua provided by RyzenAPI
-- Game: Octahedron: Transfixed Edition

-- MAIN APPLICATION
addappid(434660)
addappid(825590)

-- MAIN APP DEPOTS / PACKAGES
addappid(434661, 1, "77c04a15d60179a95e7cd0a5b110f5cb8940e9ea6db4e6d6d35392bb865034fe")

