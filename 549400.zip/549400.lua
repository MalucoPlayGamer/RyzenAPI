-- Lua provided by RyzenAPI
-- Game: Ironclads 2: War of the Pacific

-- MAIN APPLICATION
addappid(549400)

-- MAIN APP DEPOTS / PACKAGES
addappid(549401,0,"b342167d5c64bec54bca180d53ee8543027ea1b8e4ea4b3a29ac909b71dfaced")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
