-- Lua provided by RyzenAPI
-- Game: Dice Eater: A Supernatural Mystery Card Game

-- MAIN APPLICATION
addappid(3360110)
-- Game: addappid(3360110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3360111, 1, "4028556d6a721934b2daa74ab565a951602bd984e4b70cf7decf9f7b551d2f2e")
