-- Lua provided by RyzenAPI
-- Game: Sexy Memory Puzzle - Spanking Girls

-- MAIN APPLICATION
addappid(2420530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420531, 1, "d361089e03449ba0a4dc481f9ad40861974c16022e6df02a0ecb994dbe916171")
