-- Lua provided by RyzenAPI
-- Game: 1901200

-- MAIN APPLICATION
addappid(1901200)
-- Game: addappid(1901200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901201, 1, "453541cc90571f403b754bf319e87b3efb02b33c98a23b5c9b6aa44202c3c744")
