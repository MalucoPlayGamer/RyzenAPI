-- Lua provided by RyzenAPI
-- Game: Game: Riddle Joker

-- MAIN APPLICATION
addappid(1277930)
-- Game: addappid(1277930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277931, 1, "b3f09329b6a21d00c30e4eb199d906ced33932b7f75e2528e33e1ce41c3c4d7b")
