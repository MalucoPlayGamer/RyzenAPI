-- Lua provided by RyzenAPI
-- Game: Eternal Hope

-- MAIN APPLICATION
addappid(1162280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162281, 1, "14794ccf7ff5ef784069dea896939ce167c3c75b18a8c40073dfc4740f6ce2ad")

