-- Lua provided by RyzenAPI
-- Game: Tamayura Mirai

-- MAIN APPLICATION
addappid(1960830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960831, 1, "a90ea531b57341d0e69e959b043b491ead2f679bc518a527f4cc7ce8c229ba7d")
