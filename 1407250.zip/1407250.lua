-- Lua provided by RyzenAPI
-- Game: Fugitive Criminal

-- MAIN APPLICATION
addappid(1407250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407251, 1, "c0f36e7141ac648017357038fae3e53f858214d6073f6de3ebe845751c4b4f36")
