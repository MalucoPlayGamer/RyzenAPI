-- Lua provided by RyzenAPI
-- Game: Game: Wolfenstein 3D

-- MAIN APPLICATION
addappid(2270)
-- Game: addappid(2270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271, 1, "7e60644d271cb1e11f0f6436a8cceabfb8ea472ecbd207d5f9d50924ce33ca82")
