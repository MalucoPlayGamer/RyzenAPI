-- Lua provided by RyzenAPI
-- Game: Shoot The Wall

-- MAIN APPLICATION
addappid(3544500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3544501, 1, "807356f33c4c63c6da957a81d4cfd6685a3ba9cf1ea74c1c7a89e95edbcfdb46")
