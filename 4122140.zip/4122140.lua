-- 4122140's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Bethy is streaming
-- Created: July 09, 2026 at 02:49:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4122140) -- Hentai Clicker: Bethy is streaming
-- MAIN APP DEPOTS
addappid(4122141, 1, "99604fdea73d4429dc44e15c415c0a26661a5b55f6468d70ca14f44e75af95e9") -- Depot 4122141
setManifestid(4122141, "1852401537192332161", 173155407)