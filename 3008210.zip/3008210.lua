-- Lua provided by RyzenAPI
-- Game: We Heist Too: Theft & Stealth Game

-- MAIN APPLICATION
addappid(3008210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3008211,0,"ee781577a4cf9c49231b0def01c4264762245f9ba4e2046836d11ae0e6f2b695")

