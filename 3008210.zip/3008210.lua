-- Lua provided by RyzenAPI
-- Game: We Heist Too: Theft & Stealth Game

-- MAIN APPLICATION
addappid(3008210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008211,0,"ee781577a4cf9c49231b0def01c4264762245f9ba4e2046836d11ae0e6f2b695")

