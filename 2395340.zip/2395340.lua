-- Lua provided by RyzenAPI
-- Game: Game: 妄想症：恶灵密室 Demo

-- MAIN APPLICATION
addappid(2395340)
-- Game: addappid(2395340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395341, 1, "78c68d315db65cbd8b7efafc51853b28e602d4dfdbf493ec6ae80c610e60b691")
