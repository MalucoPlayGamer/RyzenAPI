-- Lua provided by RyzenAPI 
-- Game: AppID 921720
addappid(921720)
addappid(921721, 1, "05fc594bd19de11948b77912c28cd7a415c000087f9981a5f6f92d2ebfddaf65")
