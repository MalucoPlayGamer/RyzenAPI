-- Lua provided by RyzenAPI
-- Game: Game: AppID 921720

-- MAIN APPLICATION
addappid(921720)
-- Game: addappid(921720)

-- MAIN APP DEPOTS / PACKAGES
addappid(921721, 1, "05fc594bd19de11948b77912c28cd7a415c000087f9981a5f6f92d2ebfddaf65")
