-- Lua provided by RyzenAPI
-- Game: Sengoku:Battle Royal Demo

-- MAIN APPLICATION
addappid(2994340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994341, 1, "daf9818370202d7933284991fd05b9daf3d2accc954db573060d765047d2e37d")

