-- 3180830's Lua and Manifest Created by Hubcap Manifest
-- Circuit Stance
-- Created: August 13, 2026 at 08:31:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3180830) -- Circuit Stance
-- MAIN APP DEPOTS
addappid(3180831, 1, "3ff1ae286e2c110859274b313908223a0d0c6c78f0fb3678b9d22fe7aa9d3a94") -- Depot 3180831
setManifestid(3180831, "5301738125093811665", 1221836674)