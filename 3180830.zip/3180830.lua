-- Lua provided by RyzenAPI
-- Game: Circuit Stance

-- MAIN APPLICATION
addappid(3180830) -- Circuit Stance

-- MAIN APP DEPOTS / PACKAGES
addappid(3180831, 1, "3ff1ae286e2c110859274b313908223a0d0c6c78f0fb3678b9d22fe7aa9d3a94") -- Depot 3180831

