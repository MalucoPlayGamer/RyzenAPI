-- Lua provided by SkyAPI 
-- Game: Skautfold: Shrouded in Sanity
addappid(444590)
addappid(444591, 1, "915000a389b53a76d7cbc351bfe7fb8f9dd3503d9325d2eb675236c5adc88973")
addappid(491640)
