-- Lua provided by RyzenAPI
-- Game: 3037180

-- MAIN APPLICATION
addappid(3037180)
-- Game: addappid(3037180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037181, 1, "9bf67fe08ee40e301fee63f14a8b0723ff36d0a02ba9bc02bfd29ee270f68b9c")
