-- Lua provided by RyzenAPI
-- Game: 1567820

-- MAIN APPLICATION
addappid(1567820)
-- Game: addappid(1567820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567821, 1, "dba6392ae0a4f35f18ba78f959e559af8b81e1d4c393f3583ed0545e1779834a")
addappid(1567822, 1, "6598a993b4ff3ead31fc3bdbdc0de9f8b9b9b645fe5d6559c86687ee9ee577ef")
