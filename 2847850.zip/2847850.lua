-- Lua provided by RyzenAPI
-- Game: Ultimate Monkey Race

-- MAIN APPLICATION
addappid(2847850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2847851, 1, "3b3ca051925a09383adc5a5f80e0dd467e3add361352891c127d2ec87b643325")
