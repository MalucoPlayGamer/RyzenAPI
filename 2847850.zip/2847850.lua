-- Lua provided by RyzenAPI
-- Game: Ultimate Monkey Race

-- MAIN APPLICATION
addappid(2847850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2847851, 1, "3b3ca051925a09383adc5a5f80e0dd467e3add361352891c127d2ec87b643325")

