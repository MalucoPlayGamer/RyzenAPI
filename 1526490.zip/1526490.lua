-- Lua provided by RyzenAPI
-- Game: Fear Surrounds

-- MAIN APPLICATION
addappid(1526490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526491, 1, "860a8f75aa96058cd70aac2c16b89aa9916dc1770ba8049c8c70614386e5d95d")
