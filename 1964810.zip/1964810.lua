-- Lua provided by RyzenAPI
-- Game: Meekanoid

-- MAIN APPLICATION
addappid(1964810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964811, 1, "f29be444c96c314a8243961cac9e248c63cbe66de0578c2386478871d146e289")
