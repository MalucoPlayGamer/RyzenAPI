-- Lua provided by RyzenAPI
-- Game: CAPCOM GO! Apollo VR Planetarium

-- MAIN APPLICATION
addappid(1116650)
addappid(1120200)
addappid(1197740)
addappid(1197800)

