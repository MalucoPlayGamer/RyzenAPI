-- Lua provided by RyzenAPI
-- Game: CAPCOM GO! Apollo VR Planetarium

-- MAIN APPLICATION
addappid(1116650)

