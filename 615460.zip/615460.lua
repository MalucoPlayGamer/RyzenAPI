-- Lua provided by RyzenAPI
-- Game: Game: Bitcoin VR

-- MAIN APPLICATION
addappid(615460)
-- Game: addappid(615460)

-- MAIN APP DEPOTS / PACKAGES
addappid(615461, 1, "a57656f5f9e6089d7d4f68c75948fe38c206afccc4f509ff235e10240f604a3c")
