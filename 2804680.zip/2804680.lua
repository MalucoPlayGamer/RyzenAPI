-- Lua provided by RyzenAPI
-- Game: Only Way is Down

-- MAIN APPLICATION
addappid(2804680)
addappid(3800810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804681, 1, "7b698f6d57277b3ead21e6caa0ccf9a58062cdf8ee2d9de08bd185a2da32474c")

