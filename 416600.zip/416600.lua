-- Lua provided by RyzenAPI
-- Game: Full Metal Furies

-- MAIN APPLICATION
addappid(416600)
-- Game: addappid(416600)

-- MAIN APP DEPOTS / PACKAGES
addappid(416601, 1, "518c401dc1d1c756315999592ba9d8b8555f0b93fff363242c093fa2c81227ea")
addappid(416603, 1, "603e711d93edc5e3bde752f6e6c151756c1d9b2a33a9cca6e2d3f11111ca8406")
addappid(416604, 1, "4ea5bca66198a5856eb5daa7b313237bb8d1c90e0c3377980b4e9da575604bea")
