-- Lua provided by RyzenAPI
-- Game: Full Metal Furies

-- MAIN APPLICATION
addappid(416600)

-- MAIN APP DEPOTS / PACKAGES
addappid(416601, 1, "518c401dc1d1c756315999592ba9d8b8555f0b93fff363242c093fa2c81227ea")
addappid(416603, 1, "603e711d93edc5e3bde752f6e6c151756c1d9b2a33a9cca6e2d3f11111ca8406")
addappid(416604, 1, "4ea5bca66198a5856eb5daa7b313237bb8d1c90e0c3377980b4e9da575604bea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
