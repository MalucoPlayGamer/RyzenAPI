-- Lua provided by RyzenAPI
-- Game: GraFi Halloween

-- MAIN APPLICATION
addappid(1172660)
-- Game: addappid(1172660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172661, 1, "9cf0e5420f655b47c603b1f54c1a8685fbf59964fd4445353d3be34348ca4bef")
