-- Lua provided by RyzenAPI
-- Game: 734700

-- MAIN APPLICATION
addappid(734700)
-- Game: addappid(734700)

-- MAIN APP DEPOTS / PACKAGES
addappid(734701, 1, "8c3546ba0d573f63afa957f141b87f2a5ebb2ea8d3a37ad0380794c46b35a984")
