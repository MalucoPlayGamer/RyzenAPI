-- Lua provided by RyzenAPI
-- Game: Game: AppID 1180380

-- MAIN APPLICATION
addappid(1180380)
-- Game: addappid(1180380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180381, 1, "69a24603072934f624b1d6084c4abbfad1b9112d3b0e2091d84e24b5cc016067")
