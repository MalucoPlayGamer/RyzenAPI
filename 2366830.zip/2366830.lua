-- Lua provided by RyzenAPI
-- Game: addappid(2366830)

-- MAIN APPLICATION
addappid(2366830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366831, 1, "517f6b48800e248f99c6455cae2bbedbd5a18b3d5da815c553160fefa8880448")
addappid(2366832, 1, "e41d5bb1324d2a008ca1a42ba9c937d587c453f3eb4c6c3edeceee62eb566492")
