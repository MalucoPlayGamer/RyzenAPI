-- Lua provided by SkyAPI 
-- Game: X-COM: Interceptor
addappid(7730)
addappid(7731, 1, "9bcca39524fe77c764f26a90a1cf91c6ffcead199407323ec346ca473166f9e4")
