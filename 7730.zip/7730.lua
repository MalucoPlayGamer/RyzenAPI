-- Lua provided by RyzenAPI
-- Game: 7730

-- MAIN APPLICATION
addappid(7730)
-- Game: addappid(7730)

-- MAIN APP DEPOTS / PACKAGES
addappid(7731, 1, "9bcca39524fe77c764f26a90a1cf91c6ffcead199407323ec346ca473166f9e4")
