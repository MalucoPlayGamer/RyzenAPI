-- Lua provided by RyzenAPI
-- Game: AppID 1888410

-- MAIN APPLICATION
addappid(1888410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888411, 1, "e6f8af141de8d04b6d7a63fafda0ef59d5446d5ceba74664c58fcdb341016eac")
