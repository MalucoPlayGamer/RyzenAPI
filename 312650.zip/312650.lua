-- Lua provided by RyzenAPI
-- Game: 312650

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(312650)
addappid(312651)
addappid(312655)
addappid(312656)
addappid(312657)
addappid(312658)
addappid(312659)
addappid(558837)
addappid(558838)
addappid(558839)
addappid(594434)
addappid(594435)
addappid(594436)
addappid(594437)
addappid(594438)
addappid(594439)
addappid(594441)
addappid(594442)
addappid(594443)
addappid(594444)
addappid(594445)
addappid(594446)
addappid(594447)
addappid(594448)
addappid(594449)
addappid(594455)
addappid(594456)

-- MAIN APP DEPOTS / PACKAGES
addappid(312652,0,"cd8395452141636947b17340c29b3b647acbab669d2550aa2f1ff1dcf0d6ec42")
addappid(312653,0,"491f228dde11d17a4e01db82c2cfddfe680ea2190b73bfe226c29b83cd5e3cd6")
addappid(312654,0,"39d04a0b39d70fd288dafdd09f88f080f6003ce843abd91009538997253e6772")

