-- Lua provided by RyzenAPI
-- Game: Battlezone Gold Edition

-- MAIN APPLICATION
addappid(312650)
addappid(558830)
addappid(558831)
addappid(558832)
addappid(558833)
addappid(558834)
addappid(558835)
addappid(558836)
addappid(594430)
addappid(594431)
addappid(594432)
addappid(594433)
addappid(594440)
addappid(594450)
addappid(594451)
addappid(594452)
addappid(594453)
addappid(594454)
addappid(594460)
addappid(594461)
addappid(594462)
addappid(594463)
addappid(594464)
addappid(594470)
addappid(594480)
addappid(623130)
addappid(623131)
addappid(623132)
addappid(623133)
addappid(623134)

-- MAIN APP DEPOTS / PACKAGES
addappid(312652,0,"cd8395452141636947b17340c29b3b647acbab669d2550aa2f1ff1dcf0d6ec42")
addappid(312653,0,"491f228dde11d17a4e01db82c2cfddfe680ea2190b73bfe226c29b83cd5e3cd6")
addappid(312654,0,"39d04a0b39d70fd288dafdd09f88f080f6003ce843abd91009538997253e6772")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
