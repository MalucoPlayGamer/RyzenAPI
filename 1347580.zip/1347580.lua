-- Lua provided by RyzenAPI 
-- Game: シルヴァリオ トリニティ-Beyond the Horizon-
addappid(1347580)
addappid(1347581, 1, "e89ddc65c1c75c83ff90fa4aca383f1967a3509f0516de4efee2d26ee31d9965")
