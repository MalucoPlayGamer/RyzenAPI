-- Lua provided by SkyAPI 
-- Game: AppID 1042590
addappid(1042590)
addappid(1042591, 1, "9094a7da01fa98963ccc9c177e38bee4e0f536479b12983369dbbc1930c49dc4")
