-- Lua provided by RyzenAPI
-- Game: Game: AppID 1526600

-- MAIN APPLICATION
addappid(1526600)
-- Game: addappid(1526600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526601, 1, "82913fc7f27873499b75229fef80c369b8556e55f13c6ce523afe489f35c8465")
