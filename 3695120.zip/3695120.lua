-- Lua provided by RyzenAPI
-- Game: addappid(3695120)

-- MAIN APPLICATION
addappid(3695120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3695121, 1, "ef43c9048324adb1b520a52fb5a4836681e226b2cbbdd0e3ad1dea184e6d03af")
