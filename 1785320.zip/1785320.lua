-- Lua provided by RyzenAPI
-- Game: addappid(1785320)

-- MAIN APPLICATION
addappid(1785320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785321, 1, "b7b15bb0f12a1ecff0edb9c9b7c7fc55172cd3849ec6b40f908189d0e5dacb28")
