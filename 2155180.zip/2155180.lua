-- Lua provided by RyzenAPI
-- Game: Pioneers of Pagonia

-- MAIN APPLICATION
addappid(2155180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155181, 1, "d38873bac59e2a12948771b27a94623a3ece822844d75202b42361f61b5b1504")
addappid(2721120, 0, "669357bce75468df0e5d7d4e09d2444ab6dacbc04427ed6fe88482429c099289")
addappid(3322960, 0, "346ce58d54bd6101aed396886f8de43ea868f0c24455479ed66d9e321b855ba2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4351430)
addappid(4518280)
addappid(5070310)
