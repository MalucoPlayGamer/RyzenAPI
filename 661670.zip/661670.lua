-- Lua provided by RyzenAPI
-- Game: Renegade Grounds: Episode 1

-- MAIN APPLICATION
addappid(661670)

-- MAIN APP DEPOTS / PACKAGES
addappid(661671, 1, "88eb1a399df8094eefc4e5e992c7b74638133d93ff0688082da26620b99de5c1")
addappid(661672, 1, "d24d6778debb56c8a03f73538a631516b873d3065f0ef82d1fc11081d62747fc")
addappid(661673, 1, "a7aece83c2371f46fc9ed7bf179cd890354b2760a05f26c9bd89292dfd750e98")

