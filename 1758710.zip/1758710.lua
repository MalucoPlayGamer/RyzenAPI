-- Lua provided by RyzenAPI
-- Game: Timothy and the Tower of Mu Demo

-- MAIN APPLICATION
addappid(1758710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758711, 1, "fd7a0c8033f6f15b86d8df97162f08521b0c7d749bdd7635bb5d966af3ba115d")

