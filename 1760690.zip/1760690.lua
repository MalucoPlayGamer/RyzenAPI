-- Lua provided by RyzenAPI
-- Game: 1760690

-- MAIN APPLICATION
addappid(1760690)
-- Game: addappid(1760690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760691, 1, "fb3f3c38c4cf9e6fbf92f1af61713faa6d5b5e9d959e299807980595b80f4f36")
addappid(1760692, 1, "a85a5ae6242b119494a8b09b7bd8443b3ef37da79181e8e4d8cbfea3996ac189")
