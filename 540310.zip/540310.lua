-- Lua provided by RyzenAPI
-- Game: GrottyScape

-- MAIN APPLICATION
addappid(540310)

-- MAIN APP DEPOTS / PACKAGES
addappid(540311, 1, "903afbb5e36af41119d8ad4265264244e78b4f5b7f44be285a4e23fa7a20b61d")
