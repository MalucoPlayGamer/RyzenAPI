-- Lua provided by RyzenAPI
-- Game: The Experiment

-- MAIN APPLICATION
addappid(2480930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480931, 1, "45c05ba4cdd395c0fbc14865b5d5ffa1b6902c17c06d29b38bd1addc302694ff")
