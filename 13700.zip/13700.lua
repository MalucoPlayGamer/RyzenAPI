-- Lua provided by RyzenAPI
-- Game: Savage 2: A Tortured Soul

-- MAIN APPLICATION
addappid(13700)

-- MAIN APP DEPOTS / PACKAGES
addappid(13702,0,"2cd31c24f81c8acc3b11fb5b9b9285b01ff793953a63eaae7123dd742f01ddfd")
addappid(13703,0,"1368925fcd4dfb706aaa34c750b3cbc10a4668c1d4ae633f9114e1742b605b4f")
addappid(13704,0,"d84854c3de39846e9db54a302db6c0785d7ea09782bdb966446fd34806f2328a")
addappid(13705,0,"53390d6616c1282f47475848f41c7a4e30a4c1b6aad957ad6cb6b3e62909565d")

