-- Lua provided by RyzenAPI
-- Game: Game: Screaming Loaf

-- MAIN APPLICATION
addappid(1813910)
-- Game: addappid(1813910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813911, 1, "3690cfe7b55a64dcbf484ff13baf920a00d07eae694a9a4ee6e5370fb45cb5b6")
addappid(1813912, 1, "d1fb8d743f458fcdc72f72995b5487c1c76a505f4fbfb230bd50cd144a4e6916")
