-- Lua provided by RyzenAPI
-- Game: Pine: A Story of Loss

-- MAIN APPLICATION
addappid(2058340)
-- Game: addappid(2058340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058341, 1, "a8376233245df1b53856467b0282a90a3a16e36c9ca6140ab4657a2938601d5b")
addappid(2058342, 1, "5ad347e997211bd5f684a90434c4ba1001a9b591c8a57fce6eb39c857c512368")
