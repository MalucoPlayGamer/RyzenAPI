-- Lua provided by RyzenAPI
-- Game: AppID 307880

-- MAIN APPLICATION
addappid(307880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(307881, 1, "d7cf047c98350788d5abd608ed43de218509c555762b3df08b439e62f6ad630b")
addappid(307882, 1, "6fae1a49ceaa0f2d708622b4c8e7d6c8d9719ff30a5c154a474726796eaabc76")
addappid(307883, 1, "8fcda1c8f874850455b00ccca7bec09548aaf523bd9286dff3b32170bb2777c7")

