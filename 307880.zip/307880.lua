-- Lua provided by RyzenAPI
-- Game: Game: AppID 307880

-- MAIN APPLICATION
addappid(307880)
-- Game: addappid(307880)

-- MAIN APP DEPOTS / PACKAGES
addappid(307881, 1, "d7cf047c98350788d5abd608ed43de218509c555762b3df08b439e62f6ad630b")
addappid(307882, 1, "6fae1a49ceaa0f2d708622b4c8e7d6c8d9719ff30a5c154a474726796eaabc76")
addappid(307883, 1, "8fcda1c8f874850455b00ccca7bec09548aaf523bd9286dff3b32170bb2777c7")
