-- Lua provided by RyzenAPI
-- Game: Office Management 101 Demo

-- MAIN APPLICATION
addappid(1884710)
-- Game: addappid(1884710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884711, 1, "4b470547f37e07e7b5c7c7c1840c289cf4e09b7310cfc84ef8079afddfe9df2c")
