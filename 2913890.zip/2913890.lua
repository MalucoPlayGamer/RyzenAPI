-- Lua provided by RyzenAPI
-- Game: addappid(2913890)

-- MAIN APPLICATION
addappid(2913890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913891, 1, "5e6219c9deed6e86d679385af73c080285f85cebdfcacaa4bc6b78e8d7256f5c")
