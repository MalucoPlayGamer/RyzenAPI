-- Lua provided by RyzenAPI
-- Game: Casino Simulator

-- MAIN APPLICATION
addappid(2913890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913891, 1, "5e6219c9deed6e86d679385af73c080285f85cebdfcacaa4bc6b78e8d7256f5c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
