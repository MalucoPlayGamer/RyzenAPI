-- Lua provided by RyzenAPI
-- Game: The Note

-- MAIN APPLICATION
addappid(345920)

-- MAIN APP DEPOTS / PACKAGES
addappid(345921, 1, "e67365ffc35f22b1451dedcf87d384b3f9fa2e07c29dc3fbf1f63c476faec0a0")

