-- Lua provided by RyzenAPI
-- Game: World Of Mystery

-- MAIN APPLICATION
addappid(2194400)
addappid(2279030)
addappid(2279031)
addappid(2279032)
addappid(2316230)
addappid(2316231)
addappid(2316232)
addappid(2332670)
addappid(2341980)
addappid(2341981)
addappid(2352200)
addappid(2386810)
addappid(2399210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194401, 1, "8fda80d4b1cd60fed12bd69c14336856c086d1452af833e9d72f0bb44725a303")

