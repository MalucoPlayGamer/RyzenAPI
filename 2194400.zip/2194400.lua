-- Lua provided by RyzenAPI
-- Game: addappid(2194400)

-- MAIN APPLICATION
addappid(2194400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194401, 1, "8fda80d4b1cd60fed12bd69c14336856c086d1452af833e9d72f0bb44725a303")
