-- Lua provided by SkyAPI 
-- Game: Annotation of Love
addappid(787220)
addappid(787221, 1, "e410b9dfd9e2bc6b99c9c33ebbd64e28534f122af5324e43c0b0cff11a6bdb07")
addappid(787222, 1, "41e0ee85c392bcb5eb09b8e08bd32373a893cb5383242bd55ea5326de4a34110")
addappid(787223, 1, "8a35b41ed019fc724b3c6480ca7ae1a0b7e3320ca93db13c632d20c37e5ae5b3")
addappid(787224, 1, "bfde983447d8a1bb38d0dd104553f0d795ed7f380d3902f96da38f5e3580d0c1")
addappid(801830)
