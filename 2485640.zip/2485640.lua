-- Lua provided by RyzenAPI
-- Game: Game: Infection Free Zone – Prologue

-- MAIN APPLICATION
addappid(2485640)
-- Game: addappid(2485640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485641, 1, "efe613d352823afdaef4572d31b7efaefc2d43a19d0bd9efbfe9e4875e994a13")
