-- Lua provided by RyzenAPI
-- Game: 328060

-- MAIN APPLICATION
addappid(328060)
-- Game: addappid(328060)

-- MAIN APP DEPOTS / PACKAGES
addappid(328061, 1, "e4dd0730dd46734a1b2d1b4fcf29f1f6ec6037088245d7d89121f3fff136c6a7")
