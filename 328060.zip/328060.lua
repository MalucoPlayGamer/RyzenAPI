-- Lua provided by RyzenAPI
-- Game: Tales Runner

-- MAIN APPLICATION
addappid(328060)
addappid(340230)
addappid(340231)
addappid(340232)
addappid(340233)
addappid(470150)
addappid(470151)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(328061, 1, "e4dd0730dd46734a1b2d1b4fcf29f1f6ec6037088245d7d89121f3fff136c6a7")

