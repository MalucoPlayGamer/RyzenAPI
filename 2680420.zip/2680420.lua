-- Lua provided by RyzenAPI
-- Game: Game: Secret with Sophia -Lite version-

-- MAIN APPLICATION
addappid(2680420)
-- Game: addappid(2680420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680421, 1, "896854622dbdffe7457b7797a26ea522e810c76bf713f424e843efa6deb33f55")
addappid(2680422, 1, "9f2a2f257749acf0c9474af9378ecc61548271d36ef7e0e71459b6e82bb40ca4")
addappid(2680423, 1, "a423eac82f4c70ea71106eab7d388ee8535f4e95b238c29b5c46ad3e4a71df97")
addappid(2680424, 1, "1757f597d05aa7780465d82b523b93a18b591eacda49b3637a34348437b14f6e")
addappid(2680425, 1, "3912941426ba4ec9e80376e75be4c1cc38dac324e1cab65510a9b30c53ab10e2")
