-- Lua provided by RyzenAPI
-- Game: AppID 1315210

-- MAIN APPLICATION
addappid(1315210)
-- Game: addappid(1315210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315211, 1, "11ec127bec4c65adeccbe81123d572c903de773967508f3c19270c1a96f06a77")
