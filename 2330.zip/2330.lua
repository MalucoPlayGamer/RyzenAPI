-- Lua provided by RyzenAPI
-- Game: Quake II Mission Pack: The Reckoning

-- MAIN APPLICATION
addappid(2330)
-- Game: addappid(2330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331, 1, "6b49e3ab6db1dd656ba4916d6358597fc809d1868dcc32d3edb427163805143e")
