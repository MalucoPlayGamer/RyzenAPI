-- Lua provided by RyzenAPI
-- Game: addappid(2309670)

-- MAIN APPLICATION
addappid(2309670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309671, 1, "9673ac82b7c1a3a2643fffa9c39cc2e514c89d4c8e16cf0bc2b9b2380ed30805")
