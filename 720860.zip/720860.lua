-- Lua provided by RyzenAPI
-- Game: RAID: World War II Soundtrack

-- MAIN APPLICATION
addappid(720860)

-- MAIN APP DEPOTS / PACKAGES
addappid(720861, 1, "c36fe6f1ff1de1c920d44086427094c57e4b569881cf06ab4e9dd5acde452548")
