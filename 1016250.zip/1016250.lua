-- Lua provided by RyzenAPI 
-- Game: AppID 1016250
addappid(1016250)
addappid(1016251, 1, "8e4178ec4ca976d0771d23b9b6ac141eb6f8597b918b6970e643277b07e6dd55")
addappid(1034010, 0, "4eae0d9d697e0602e8a7e7ea6292c37465e9df896c08183fee1a7f6745d473c0")
