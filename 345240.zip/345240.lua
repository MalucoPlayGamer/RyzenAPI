-- Lua provided by RyzenAPI
-- Game: AppID 345240

-- MAIN APPLICATION
addappid(345240)

-- MAIN APP DEPOTS / PACKAGES
addappid(345241, 1, "23a56ed1a725d128362ca910247fcbe5c0cdba5379a325b4e91a5f531839bd72")
addappid(345242, 1, "e7905b2fd4446ac06a9193b6f6b3a1c47b0f33718b6ff64f8622eea02ae616e9")
addappid(345243, 1, "775d78f00071623697273dbf848bbf94433da8dfe9b2a55c8263a01c688c34e9")
addappid(345244, 1, "d924e3c6baaeb5ebf75151d24fe09d8aa8cf153043f5606617acc80676aff7e4")
addappid(345246, 1, "b7866576c32b8a29ed2596b35e7f5fb5c1ee67d8b36d5cfe33cb780a6aedecbd")
addappid(372531, 0, "85fd9e7e0a0f07b17dcb14263b94e436306270f02200d7a6669de0ba70602504")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
