-- Lua provided by RyzenAPI
-- Game: Light Of The Ancients

-- MAIN APPLICATION
addappid(3753680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3753681, 1, "dd1f8dd9aa39e7e261667083b03ba9c8b43327f8a9b292581d23debdf0534315")

