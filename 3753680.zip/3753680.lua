-- Lua provided by RyzenAPI
-- Game: Light Of The Ancients

-- MAIN APPLICATION
addappid(3753680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3753681, 1, "dd1f8dd9aa39e7e261667083b03ba9c8b43327f8a9b292581d23debdf0534315")

