-- Lua provided by RyzenAPI
-- Game: Furnish Master

-- MAIN APPLICATION
addappid(2004080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004081, 1, "048651261b393620e00590bc7deec13ca5b1d1ff073dabe3ce28f3f9b2ea96b5")
addappid(2004082, 1, "005ecce28d60b424fb0071d3ec6ec95696eb495defd69cbca892e91e27c53b82")
addappid(2004083, 1, "539dd61806b33c0b427c92c4227efb7aaa9203659235f1567b2389d079e369ca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
