-- Lua provided by RyzenAPI
-- Game: addappid(2957700)

-- MAIN APPLICATION
addappid(2957700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957701, 1, "07c5a7aa4b5e25f17592c0c77dfce3bb5544a9a5a45ce72803703caf9d819b17")
