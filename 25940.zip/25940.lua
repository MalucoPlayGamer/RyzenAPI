-- Lua provided by RyzenAPI
-- Game: East India Company: Pirate Bay

-- MAIN APPLICATION
addappid(25940)
-- Game: addappid(25940)

-- MAIN APP DEPOTS / PACKAGES
addappid(25941, 1, "6724929eaeebbf3c5551c957567df618ef6592b228e6cf47909d9f537923f028")
