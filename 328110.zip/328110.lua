-- Lua provided by RyzenAPI
-- Game: Game: Shelter Soundtrack

-- MAIN APPLICATION
addappid(328110)
-- Game: addappid(328110)

-- MAIN APP DEPOTS / PACKAGES
addappid(328111, 1, "74fb877bd968c56462d611d3451501eb14e7370502139e253b9ab479a80958d1")
