-- Lua provided by RyzenAPI
-- Game: Game: AppID 925810

-- MAIN APPLICATION
addappid(925810)
-- Game: addappid(925810)

-- MAIN APP DEPOTS / PACKAGES
addappid(925811, 1, "da54347c79718eba633762bf6c91eaedb7b02e4f4d1c4ddd2ea12b1a882ad304")
