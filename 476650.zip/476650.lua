-- Lua provided by RyzenAPI
-- Game: addappid(476650)

-- MAIN APPLICATION
addappid(476650)

-- MAIN APP DEPOTS / PACKAGES
addappid(476651, 1, "3523e73546fd4c2a6a91804e5067f10277297887e37693c5b63b5de2b064796d")
addappid(476652, 1, "4cfa9248ca344c1f4a2b787b32fbcffba68523e0ca8247770f68226e8024d3d8")
addappid(476653, 1, "47c3ddcc66ddd1fa80d4afed0bb0884cae5865c9e11fffa2fc9e730e1ecfc304")
addappid(533570, 0, "212e3ebeef7b649d3968f18b1e67ac1ec45a7201a9b69a28cf78aa6f56ba28c6")
