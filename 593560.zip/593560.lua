-- Lua provided by RyzenAPI
-- Game: The Last Cargo

-- MAIN APPLICATION
addappid(593560)
-- Game: addappid(593560)

-- MAIN APP DEPOTS / PACKAGES
addappid(593561, 1, "d58112b5edfba117cc1b6747c909e8595240dddcaa8a8baff0c61c71e9cfed0f")
