-- Lua provided by SkyAPI 
-- Game: The Last Cargo
addappid(593560)
addappid(593561, 1, "d58112b5edfba117cc1b6747c909e8595240dddcaa8a8baff0c61c71e9cfed0f")
