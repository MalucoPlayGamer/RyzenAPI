-- Lua provided by RyzenAPI
-- Game: Game: Aimlabs VR

-- MAIN APPLICATION
addappid(1845630)
-- Game: addappid(1845630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845631, 1, "5ecfa892d703ae4355121dcf404239e6737beb157912867fcd7a05703b70fc76")
