-- Lua provided by RyzenAPI
-- Game: 2960770

-- MAIN APPLICATION
addappid(2960770)
-- Game: addappid(2960770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960771, 1, "c754869c3fe7c99d217c5062703d4ebea5445911727691bb5fcc44129c45f4aa")
