-- Lua provided by RyzenAPI 
-- Game: AppID 3246140
addappid(3246140)
addappid(3246141, 1, "0f8764bb7476b19117be0338b247b6cf37f9a42f9ba3eecebfc7b6e3d8901843")
