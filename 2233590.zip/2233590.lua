-- Lua provided by RyzenAPI
-- Game: mummification

-- MAIN APPLICATION
addappid(2233590)
-- Game: addappid(2233590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233591, 1, "738dd42dcb91a4474e6a70e057336a3668b21de2c276305fb20db7b7d8c01db3")
