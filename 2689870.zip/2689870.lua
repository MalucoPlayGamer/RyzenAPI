-- Lua provided by RyzenAPI
-- Game: Rekindling The Flame

-- MAIN APPLICATION
addappid(2689870)
-- Game: addappid(2689870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689871, 1, "31b0982295b4c8347d958443fd649db0937794c345dba587270f2104224aa471")
