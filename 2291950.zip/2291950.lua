-- Lua provided by RyzenAPI
-- Game: Game: Samira: Taken From Time

-- MAIN APPLICATION
addappid(2291950)
-- Game: addappid(2291950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291951, 1, "4113da1d6e4e529fb168c4b78707cd1d8392087301fe2d2049fb894c775638b3")
