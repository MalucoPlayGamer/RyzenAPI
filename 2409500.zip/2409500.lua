-- Lua provided by RyzenAPI
-- Game: Inspector Gadget - MAD Time Party

-- MAIN APPLICATION
addappid(2409500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409501, 1, "b7ad4993b3f1bb36218cbaf4cf707771059b1941a7f19dc6eafeef9896697889")

