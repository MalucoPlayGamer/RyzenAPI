-- Lua provided by RyzenAPI
-- Game: Game: The Grave Keeper

-- MAIN APPLICATION
addappid(3324640)
-- Game: addappid(3324640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3324641, 1, "369288bc5210b91f84124d543f9a07d5873e64b868ff0e05eb6f260d1be36013")
