-- Lua provided by RyzenAPI
-- Game: AppID 665780

-- MAIN APPLICATION
addappid(665780)

-- MAIN APP DEPOTS / PACKAGES
addappid(665781, 1, "1df95da31df812b29cafb0f7e9792ffee2d7db82bfb2a220c4ef1993c5b66e56")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
