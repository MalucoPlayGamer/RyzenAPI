-- Lua provided by SkyAPI 
-- Game: The Red Hood
addappid(1900970)
addappid(1900971, 1, "7eb10669f43e8753309b1519478f4e3cdf6299dc7fa09512603403b65d1df13e")
