-- Lua provided by RyzenAPI
-- Game: The Red Hood

-- MAIN APPLICATION
addappid(1900970)
-- Game: addappid(1900970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900971, 1, "7eb10669f43e8753309b1519478f4e3cdf6299dc7fa09512603403b65d1df13e")
