-- Lua provided by RyzenAPI
-- Game: Ella's Nightmare

-- MAIN APPLICATION
addappid(4253590) -- Ella's Nightmare

-- MAIN APP DEPOTS / PACKAGES
addappid(4253591, 1, "260a9f986c504d468a7ffd76daa2599242b6dbe42457cf979781cae100fd1b0b") -- Depot 4253591

