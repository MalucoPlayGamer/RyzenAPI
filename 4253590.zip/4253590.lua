-- 4253590's Lua and Manifest Created by Hubcap Manifest
-- Ella's Nightmare
-- Created: August 03, 2026 at 07:24:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4253590) -- Ella's Nightmare
-- MAIN APP DEPOTS
addappid(4253591, 1, "260a9f986c504d468a7ffd76daa2599242b6dbe42457cf979781cae100fd1b0b") -- Depot 4253591
setManifestid(4253591, "433524316081825949", 866083747)