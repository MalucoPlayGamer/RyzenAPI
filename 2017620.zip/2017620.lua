-- Lua provided by RyzenAPI
-- Game: 2017620

-- MAIN APPLICATION
addappid(2017620)
-- Game: addappid(2017620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017621, 1, "a9440494e8588bb7ddfe63a8f32b08f33e52e82bd075f4ceebe44e1282c52178")
