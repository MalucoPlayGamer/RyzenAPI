-- Lua provided by RyzenAPI
-- Game: Maestro: Notes of Life Collector's Edition

-- MAIN APPLICATION
addappid(786100)

-- MAIN APP DEPOTS / PACKAGES
addappid(786101,0,"b8512af8f56d02099adb96d97f69f40ec85426f997c3818e68ff0999c05a3c2d")

