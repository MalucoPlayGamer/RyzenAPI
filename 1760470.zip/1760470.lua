-- Lua provided by RyzenAPI
-- Game: Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles:  Character Avatar (Final Selection Tanjiro)

-- MAIN APPLICATION
addappid(1760470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760470,0,"70a688482c965ca7753eff82322f589bf14c05bcc6e641908f54ab17610a84b0")

