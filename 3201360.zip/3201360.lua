-- Lua provided by RyzenAPI 
-- Game: AppID 3201360
addappid(3201360)
addappid(3201361, 1, "804bd2d633af4561c3aca312d1b02d20058ab0f23421179886c81a8657cea48d")
addappid(3201362, 1, "b9ee9b14dfe8f90ed197ee8a65334198fced4378e87ff8b054632427b94e1492")
