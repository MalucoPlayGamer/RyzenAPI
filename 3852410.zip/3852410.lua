-- Lua provided by RyzenAPI
-- Game: Dominated by: Yandere Goth Gamer Girl

-- MAIN APPLICATION
addappid(3852410)
-- Game: addappid(3852410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3852411, 1, "e834cc4ae25d4a45f76e26775746ed9a834aad808ed4832e0df6ce603e1913e3")
