-- Lua provided by RyzenAPI 
-- Game: Dominated by: Yandere Goth Gamer Girl
addappid(3852410)
addappid(3852411, 1, "e834cc4ae25d4a45f76e26775746ed9a834aad808ed4832e0df6ce603e1913e3")
