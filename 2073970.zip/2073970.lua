-- Lua provided by RyzenAPI
-- Game: addappid(2073970)

-- MAIN APPLICATION
addappid(2073970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073971, 1, "4efa13136c985dca59d12af9944210c343466c623d2c6dc2c87f01dd9f147e17")
