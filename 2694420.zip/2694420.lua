-- Lua provided by RyzenAPI
-- Game: Game: KILL KNIGHT

-- MAIN APPLICATION
addappid(2694420)
-- Game: addappid(2694420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694421, 1, "41b79bf0668eb35661a60a9ce93dfa31b3618636b9f20997a4ac84f765f1f1fd")
