-- Lua provided by SkyAPI 
-- Game: KILL KNIGHT
addappid(2694420)
addappid(2694421, 1, "41b79bf0668eb35661a60a9ce93dfa31b3618636b9f20997a4ac84f765f1f1fd")
