-- Lua provided by RyzenAPI
-- Game: 2224120

-- MAIN APPLICATION
addappid(2224120)
-- Game: addappid(2224120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224121, 1, "2f3662c2fe923544971a5db230e55754180f04eccfa4a3a044ece3b73862f889")
