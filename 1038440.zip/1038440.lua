-- Lua provided by RyzenAPI
-- Game: AppID 1038440

-- MAIN APPLICATION
addappid(1038440)
-- Game: addappid(1038440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038441, 1, "a81fed533bdb1c4527ee8e496d1571d1ba95844b1f9bd41d26a6beee06dca5e7")
