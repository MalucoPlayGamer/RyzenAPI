-- Lua provided by RyzenAPI
-- Game: Game: GrumpyTunez

-- MAIN APPLICATION
addappid(1921570)
-- Game: addappid(1921570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921571, 1, "4816f2ace54d3056e96d11763b0eb435ad190e73a61b241925f4cb1bacf4971e")
