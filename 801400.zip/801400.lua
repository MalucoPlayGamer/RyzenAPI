-- Lua provided by RyzenAPI
-- Game: Hoser Hockey

-- MAIN APPLICATION
addappid(801400)

-- MAIN APP DEPOTS / PACKAGES
addappid(801401,0,"0ccd43f4510e6da6ff7f40e180e2ac4c87a621ade2e5cb43961e4b9f4db6432a")

