-- Lua provided by RyzenAPI
-- Game: Hoser Hockey

-- MAIN APPLICATION
addappid(801400)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(801401,0,"0ccd43f4510e6da6ff7f40e180e2ac4c87a621ade2e5cb43961e4b9f4db6432a")

