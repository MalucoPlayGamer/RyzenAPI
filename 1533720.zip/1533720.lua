-- Lua provided by RyzenAPI
-- Game: 1533720

-- MAIN APPLICATION
addappid(1533720)
-- Game: addappid(1533720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533721, 1, "1c8b6c4ad4cbd6e93baac9733897c3ed02947912d23ef05b5ed7c8d8a14d33c4")
