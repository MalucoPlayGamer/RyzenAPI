-- Lua provided by RyzenAPI
-- Game: 547470

-- MAIN APPLICATION
addappid(547470)
-- Game: addappid(547470)

-- MAIN APP DEPOTS / PACKAGES
addappid(547471, 1, "89e5e270ebe0a225f946fd4cd78d3d1d24e4c0013aa8f3eccc3378bfb319dec0")
