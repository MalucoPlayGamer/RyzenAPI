-- Lua provided by RyzenAPI
-- Game: 3083300

-- MAIN APPLICATION
addappid(3083300)
-- Game: addappid(3083300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3083301, 1, "3eed75a70a6242e6d25b6bb98fec84b9995a70fc0061bf1cbc9a021a1d6f00fd")
addappid(3083302, 1, "4795bd4b73dd1b1ba26f7937c2ecda0f1ee6c7a20def5ec60cd2af193a2cf0e7")
