-- Lua provided by RyzenAPI
-- Game: 1726190

-- MAIN APPLICATION
addappid(1726190)
-- Game: addappid(1726190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726191, 1, "9b4d1e2d8934084a9a20b71b65e17f4d42a112416bbfbc040acd75163c3de26a")
