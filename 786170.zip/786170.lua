-- Lua provided by RyzenAPI
-- Game: Bomb Bay

-- MAIN APPLICATION
addappid(786170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(786171,0,"d1fc0d89da878a7fc9127a2fadc9e4dc761b3865c6258c162e2158dacf5d5327")

