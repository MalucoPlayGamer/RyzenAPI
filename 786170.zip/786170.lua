-- Lua provided by RyzenAPI
-- Game: Bomb Bay

-- MAIN APPLICATION
addappid(786170)

-- MAIN APP DEPOTS / PACKAGES
addappid(786171,0,"d1fc0d89da878a7fc9127a2fadc9e4dc761b3865c6258c162e2158dacf5d5327")

