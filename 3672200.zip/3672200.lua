-- Lua provided by RyzenAPI
-- Game: Archons - Soundtrack

-- MAIN APPLICATION
addappid(3672200)
-- Game: addappid(3672200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3672202,0,"093edd44c51a78a066beb53cf4788047d101347673f509945a13ee172e78628d")
addappid(3672203,0,"a073f67579894a6676e25977082324987b4ecf2abf30cb4fea8de151eedca3bf")
