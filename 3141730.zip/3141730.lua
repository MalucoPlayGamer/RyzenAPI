-- Lua provided by RyzenAPI
-- Game: Monster Battles Demo

-- MAIN APPLICATION
addappid(3141730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141731, 1, "63ac7d919654b092963ce2de60eb88fd431bb43213ab8a66fea5fd002352cba4")
