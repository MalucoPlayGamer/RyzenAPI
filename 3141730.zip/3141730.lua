-- Lua provided by SkyAPI 
-- Game: AppID 3141730
addappid(3141730)
addappid(3141731, 1, "63ac7d919654b092963ce2de60eb88fd431bb43213ab8a66fea5fd002352cba4")
