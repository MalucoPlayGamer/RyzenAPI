-- Lua provided by RyzenAPI
-- Game: addappid(1473050)

-- MAIN APPLICATION
addappid(1473050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473051, 1, "34e85dedecd33f4800f3c2954442cc5ba81024dd174c5b4dd1061de6e625f05d")
