-- Lua provided by RyzenAPI
-- Game: 2772640

-- MAIN APPLICATION
addappid(2772640)
-- Game: addappid(2772640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772641, 1, "2be98a7e0f6065e7193a2ef6ac8ebb5d632922a9316bbd717ed047b5a7b30d03")
