-- Lua provided by RyzenAPI
-- Game: AppID 1087190

-- MAIN APPLICATION
addappid(1087190)
-- Game: addappid(1087190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087191, 1, "67b61fec47482d16ed468c531fc59fce9b287c381c9b8002d602a7e9d2086532")
