-- Lua provided by SkyAPI 
-- Game: AppID 1087190
addappid(1087190)
addappid(1087191, 1, "67b61fec47482d16ed468c531fc59fce9b287c381c9b8002d602a7e9d2086532")
