-- Lua provided by RyzenAPI
-- Game: Tea Party Simulator 2015™

-- MAIN APPLICATION
addappid(363620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(363621, 1, "87dc36b7d52a11856febde9a4dbaa8cc7ca7a3cae7b923a948748a90094bc69a")
addappid(363622, 1, "8adc2ec5b8350baad024300f0233673c7d711a7a5f162bcd4ed877f6f4d9cee8")
addappid(363623, 1, "1995908688525c79279c01fdacfd49f5cf0e5976570c2fae5371ac72230692e6")

