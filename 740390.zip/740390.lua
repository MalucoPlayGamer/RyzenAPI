-- Lua provided by RyzenAPI
-- Game: Terrorist Elimination

-- MAIN APPLICATION
addappid(740390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(740391, 1, "8312f5cb81f767fb14005da9986a9d635ee6be7ce6217fdbff0b3a5529b56174")

