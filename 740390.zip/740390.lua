-- Lua provided by RyzenAPI
-- Game: Terrorist Elimination

-- MAIN APPLICATION
addappid(740390)
-- Game: addappid(740390)

-- MAIN APP DEPOTS / PACKAGES
addappid(740391, 1, "8312f5cb81f767fb14005da9986a9d635ee6be7ce6217fdbff0b3a5529b56174")
