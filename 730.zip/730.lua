-- Lua provided by RyzenAPI
-- Game: Counter-Strike 2

-- MAIN APPLICATION
addappid(730)

-- MAIN APP DEPOTS / PACKAGES
addappid(731, 1, "bca9a9cde94bb4dff61849c6a87230ee45867a590fdd28826366e35e7d62c08e")
addappid(732, 1, "da1f76913633e9ce1b2bda5ec464dc507205388fac5c4c614b6a2706cdbd0912")
addappid(733, 1, "23c8e9a91561a5fb08abf22f2ac98929f4aad68a12164268d3b2800c3db4fb03")
addappid(734, 1, "54fd243c5463c16ec7d32b5b4c7b792b3f2d3f75009ac3e81135ff999b56187f")
addappid(735, 1, "a0ef69f0cf8abd70aa9ed79755fbe4d98cf7c6723ba9e0c66e0f7102e49541e6")
addappid(736, 1, "e81988c241b4ec9fc7fe1ab34697689f131a48c78da95c985ed347fb43bdc6de")
addappid(737, 1, "c80f96efa325374c18c6d5d63ccd2687b1680a908c6def5c5c808e695f1ddbf9")
addappid(738, 1, "fbc1a292c9b75e33512ed82476267efbf34f1ed1b177651ed8b091cf7174d183")
addappid(2347770, 0, "b23a737920b6a72f932a5bcdbdf51770d7d4d394a13f95b1cf29db28c1043d88")
addappid(2347771, 0, "b80e2b4bd2a244ba996a013850b5d2f46c897f382164181b382c5d672fcb5090")
addappid(2347772, 0, "7938abf64ef719e6414d5e385f90ccbef9c6a2c21ab42b471a09641d2b2ba32f")
addappid(2347773, 0, "d030f2b7078446257db4b4decd86a38b0ae3816b4847a04e609277e20f25d5d7")
addappid(2347774, 0, "71e79678830ea0234437b03526e2ede2decfed847ce20bae413718b47db44bea")
addappid(2347779, 0, "a3d6504606875447dc6dedcba78bebb3e0a122fb30a504ef805536f216354271")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1490530)
addappid(1766730)
addappid(2279720)
addappid(2279721)
