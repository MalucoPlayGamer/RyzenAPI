-- Lua provided by RyzenAPI
-- Game: 1432160

-- MAIN APPLICATION
addappid(1432160)
-- Game: addappid(1432160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432160,0,"45dbff42908549b26f4e1235109ad693bc8ea5b542d9a95027d9b9bb49fd1297")
