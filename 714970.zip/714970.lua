-- Lua provided by RyzenAPI
-- Game: 714970

-- MAIN APPLICATION
addappid(714970)
-- Game: addappid(714970)

-- MAIN APP DEPOTS / PACKAGES
addappid(714971, 1, "b268a9ed954e23a9f9aa2c96a7277fec5d5d937fecd187e0d6dbc2f75cc3298e")
