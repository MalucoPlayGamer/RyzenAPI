-- Lua provided by RyzenAPI
-- Game: addappid(289840)

-- MAIN APPLICATION
addappid(289840)

-- MAIN APP DEPOTS / PACKAGES
addappid(289841, 1, "7b4bdd9d1763fa17398231b16bbd222a080aaa8ef30d4af187606681531334fd")
addappid(289842, 1, "34f8647b16b0890d7f990e88a39706eb1fd18e3c9af4480d03ea7baebaecd9df")
