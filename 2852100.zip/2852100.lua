-- Lua provided by RyzenAPI
-- Game: addappid(2852100)

-- MAIN APPLICATION
addappid(2852100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852101, 1, "7c0009418b5300989695696681ebce869af23f4a12bd7b45b3bcd8e63144bbd2")
