-- Lua provided by RyzenAPI
-- Game: Adventures of Shuggy

-- MAIN APPLICATION
addappid(211440)

-- MAIN APP DEPOTS / PACKAGES
addappid(211441, 1, "29105c9ad5dcb3f3b147de6cebc6f4ff815bf47b77b85f8c464f8b303acdc379")
addappid(211442, 1, "ef55cb86af8e033dfb8e1e6794261e08a98b22b5d809ff6d14266eaee319bef8")
addappid(211443, 1, "efce7fa98a28b53d97a32f29bf1357631d1f80743c96471901015749e332a81d")
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

