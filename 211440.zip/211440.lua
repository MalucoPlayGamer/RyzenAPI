-- Lua provided by RyzenAPI
-- Game: AppID 211440

-- MAIN APPLICATION
addappid(211440)
-- Game: addappid(211440)

-- MAIN APP DEPOTS / PACKAGES
addappid(211441, 1, "29105c9ad5dcb3f3b147de6cebc6f4ff815bf47b77b85f8c464f8b303acdc379")
addappid(211442, 1, "ef55cb86af8e033dfb8e1e6794261e08a98b22b5d809ff6d14266eaee319bef8")
addappid(211443, 1, "efce7fa98a28b53d97a32f29bf1357631d1f80743c96471901015749e332a81d")
