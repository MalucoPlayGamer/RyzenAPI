-- Lua provided by SkyAPI 
-- Game: AppID 875310
addappid(875310)
addappid(875311, 1, "51d6377232183924e8e75c6c952a9eb62004b8fd5f9ab1af1e8f4cfac9bbe2ba")
