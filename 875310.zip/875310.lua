-- Lua provided by RyzenAPI
-- Game: LIBERATED

-- MAIN APPLICATION
addappid(875310)
addappid(1356330)
addappid(1356331)
addappid(1382900)

-- MAIN APP DEPOTS / PACKAGES
addappid(875311,0,"51d6377232183924e8e75c6c952a9eb62004b8fd5f9ab1af1e8f4cfac9bbe2ba")
addappid(1382900,0,"d168e49bfbad79dcdc6bbfb178a581fdbf4e75936053f6af38f907eb50201264")

