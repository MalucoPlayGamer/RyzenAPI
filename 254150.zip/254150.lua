-- Lua provided by RyzenAPI
-- Game: Unholy Heights Demo

-- MAIN APPLICATION
addappid(254150)
-- Game: addappid(254150)

-- MAIN APP DEPOTS / PACKAGES
addappid(254151, 1, "352743d35ea506abcb76b2cad22474899e8aed9a61df86147d087fd8048aafdc")
