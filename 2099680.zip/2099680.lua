-- Lua provided by RyzenAPI
-- Game: Game: Rent A Car Simulator 24

-- MAIN APPLICATION
addappid(2099680)
-- Game: addappid(2099680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099681, 1, "61e4dcf362cf08c756eff5ab9266ff8161c641590ef31363afd83d6ba2a3d025")
