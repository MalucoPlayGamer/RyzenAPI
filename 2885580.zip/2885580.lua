-- Lua provided by RyzenAPI
-- Game: Void Whispers

-- MAIN APPLICATION
addappid(2885580)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2912740)
