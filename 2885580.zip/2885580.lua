-- Lua provided by RyzenAPI
-- Game: Void Whispers

-- MAIN APPLICATION
addappid(2885580)
addappid(2912740)

