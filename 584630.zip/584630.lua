-- Lua provided by RyzenAPI
-- Game: 584630

-- MAIN APPLICATION
addappid(584630)

-- MAIN APP DEPOTS / PACKAGES
addappid(584630,0,"d0cdaec081e00c08f4fd46b907f3e868e1eb6a9dc63fa00602d3ef39df8c69ce")

