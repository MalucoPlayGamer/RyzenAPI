-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1494603)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494603,0,"940b7c88c59854c2d628179e35c1f49a9522f00982a6b133b61e0f55a509bc92")
