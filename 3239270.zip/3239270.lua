-- Lua provided by RyzenAPI
-- Game: addappid(3239270)

-- MAIN APPLICATION
addappid(3239270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239271, 1, "94c30ac47ad9c694a516a45cbc89f73e179cf4456d6aec9a1c0c95b1378084b3")
