-- Lua provided by RyzenAPI
-- Game: Game: Mech Armada

-- MAIN APPLICATION
addappid(1389360)
-- Game: addappid(1389360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389361, 1, "6a09cd3ce1b5b608ba93a86a4520829825c02abdaed6b935477f94a49c422d57")
