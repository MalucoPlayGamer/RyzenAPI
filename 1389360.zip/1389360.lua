-- Lua provided by RyzenAPI
-- Game: Mech Armada

-- MAIN APPLICATION
addappid(1389360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389361, 1, "6a09cd3ce1b5b608ba93a86a4520829825c02abdaed6b935477f94a49c422d57")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
