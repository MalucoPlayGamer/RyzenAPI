-- Lua provided by RyzenAPI
-- Game: Final Fall

-- MAIN APPLICATION
addappid(3599470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599471, 1, "08ea7ec502be02e2ee6c58e754173fe90a22cc0ebc0776101d586e5ccb06464c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
