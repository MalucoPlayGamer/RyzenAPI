-- Lua provided by RyzenAPI
-- Game: Final Fall

-- MAIN APPLICATION
addappid(3599470)
-- Game: addappid(3599470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599471, 1, "08ea7ec502be02e2ee6c58e754173fe90a22cc0ebc0776101d586e5ccb06464c")
