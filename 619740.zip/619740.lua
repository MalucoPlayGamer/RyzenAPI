-- Lua provided by RyzenAPI
-- Game: AppID 619740

-- MAIN APPLICATION
addappid(619740)

-- MAIN APP DEPOTS / PACKAGES
addappid(619741, 1, "e3718f017488d3f40e4eb65ebf98b0d17e3a5d7f53b8aa5a2f1635f2ed3ff795")

