-- Lua provided by RyzenAPI
-- Game: AppID 619740

-- MAIN APPLICATION
addappid(619740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(619741, 1, "e3718f017488d3f40e4eb65ebf98b0d17e3a5d7f53b8aa5a2f1635f2ed3ff795")

