-- Lua provided by RyzenAPI
-- Game: Coloring Book for Kids

-- MAIN APPLICATION
addappid(1507410)
addappid(1551950)
-- Game: addappid(1507410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507411, 1, "4cd2a03f5d0e072737d141edf7558d85a5d1941c4bf544e553521d2395c9c2ae")
addappid(1507412, 1, "cddcac456af9923f700b9a9f9def55c0b48233ccb7365301024edbb89a378966")
