-- Lua provided by RyzenAPI
-- Game: Game: Heroes & Generals

-- MAIN APPLICATION
addappid(227940)
addappid(228990)
-- Game: addappid(227940)

-- MAIN APP DEPOTS / PACKAGES
addappid(227941, 1, "f6d8fa9d552fda55851a00d183cd4587f841c49b093d2cfc59fe9bb1c299d121")
