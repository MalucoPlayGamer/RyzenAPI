-- Lua provided by RyzenAPI
-- Game: 770340

-- MAIN APPLICATION
addappid(770340)
-- Game: addappid(770340)

-- MAIN APP DEPOTS / PACKAGES
addappid(770341, 1, "d9211c1b50c17e0e7e701912faf14130acaa44cfb93d2b35e74d47a3aa89ac82")
