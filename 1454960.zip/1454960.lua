-- Lua provided by RyzenAPI
-- Game: addappid(1454960)

-- MAIN APPLICATION
addappid(1454960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454961, 1, "de38b3fa3bb4a4fd3f44e58e58bdb04fc12ba323eeee5397e4f64936f7627eb3")
