-- Lua provided by RyzenAPI
-- Game: Delicious - Emily's New Beginning

-- MAIN APPLICATION
addappid(544710)
-- Game: addappid(544710)

-- MAIN APP DEPOTS / PACKAGES
addappid(544711, 1, "3038292d1245f158a5d0d1036f6eae2d452b81894515bfcb5a47d2652a90cc7a")
