-- Lua provided by RyzenAPI
-- Game: Pico Pico Dungeon!

-- MAIN APPLICATION
addappid(3050800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050801, 1, "fc037fc35614c0e4cb6627cfa734ce6310bab730ff4abd444b2f7f9f6a42ec52")
