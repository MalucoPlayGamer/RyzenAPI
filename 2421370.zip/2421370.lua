-- Lua provided by RyzenAPI 
-- Game: Cryptis
addappid(2421370)
addappid(2421371, 1, "3ea75c7e895296c82f2e6a3bb30194a28df0aa85e443a27746d57646cc0b735e")
