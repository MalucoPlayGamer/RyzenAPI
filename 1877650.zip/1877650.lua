-- Lua provided by RyzenAPI
-- Game: Zero Orders Tactics

-- MAIN APPLICATION
addappid(1877650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877651, 1, "ded1721502f07a23fd66c270180e5864b403cfcca0ba195dd0544b70f5be8018")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3279550)
addappid(4116860)
