-- Lua provided by RyzenAPI
-- Game: Hero of the Kingdom: The Lost Tales 1

-- MAIN APPLICATION
addappid(1249130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249131, 1, "876a9d14cb19eda18399739f840c8c4043dbf5554c1cf5076b7fc9f8f52e382b")
addappid(1249132, 1, "db077e1219abfa3723dd8bcd855a5b014a97c8f89124786f2aef2afc2c3f90d0")
addappid(1249133, 1, "2ddca95b00408e112046babd3f05407b5ccee6a13685a44ed34594a8d2583b81")
addappid(1249134, 1, "181dba0fab2c3b9c69d47b18bebc2059620192a3a367d2643fc4e413748458f7")
