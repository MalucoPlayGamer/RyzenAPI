-- Lua provided by RyzenAPI
-- Game: addappid(881690)

-- MAIN APPLICATION
addappid(881690)

-- MAIN APP DEPOTS / PACKAGES
addappid(881691, 1, "4e9b6c88c53adcdc26258732da448fb1472ff02f68db48caf85f74bf58d2eb87")
