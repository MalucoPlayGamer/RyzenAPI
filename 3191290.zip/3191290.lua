-- Lua provided by RyzenAPI 
-- Game: AppID 3191290
addappid(3191290)
addappid(3191291, 1, "31b80b55ce4f6e375d96d4758f8fdd7cd67caa636326946a8638c9ce2705691d")
