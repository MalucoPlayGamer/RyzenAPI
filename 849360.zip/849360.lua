-- Lua provided by RyzenAPI
-- Game: Wrecking Towers

-- MAIN APPLICATION
addappid(849360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(849361, 1, "017da7d1648b852f9483f33901f8d1938cf9dc25f37939b458a5540b7f92be7e")

