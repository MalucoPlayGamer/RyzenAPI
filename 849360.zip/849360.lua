-- Lua provided by SkyAPI 
-- Game: AppID 849360
addappid(849360)
addappid(849361, 1, "017da7d1648b852f9483f33901f8d1938cf9dc25f37939b458a5540b7f92be7e")
