-- Lua provided by RyzenAPI
-- Game: 849360

-- MAIN APPLICATION
addappid(849360)
-- Game: addappid(849360)

-- MAIN APP DEPOTS / PACKAGES
addappid(849361, 1, "017da7d1648b852f9483f33901f8d1938cf9dc25f37939b458a5540b7f92be7e")
