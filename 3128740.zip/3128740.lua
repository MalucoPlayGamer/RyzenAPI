-- Lua provided by RyzenAPI
-- Game: Beff Jezos Simulator

-- MAIN APPLICATION
addappid(3128740)
-- Game: addappid(3128740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128741, 1, "d1955de2d3a4b90777926e083bbe6a24c960a34197a53acda90172f56892ffc6")
