-- Lua provided by RyzenAPI
-- Game: Game: The night of fire stealing 2/盗火之夜2

-- MAIN APPLICATION
addappid(1607100)
-- Game: addappid(1607100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607101, 1, "3afacbab94b105213698d70f4b5a095d6eff6438d42748bda3177c08faf57c3c")
