-- Lua provided by RyzenAPI
-- Game: The night of fire stealing 2/盗火之夜2

-- MAIN APPLICATION
addappid(1607100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607101, 1, "3afacbab94b105213698d70f4b5a095d6eff6438d42748bda3177c08faf57c3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
