-- Lua provided by RyzenAPI
-- Game: Taimanin Yukikaze 1: Trial

-- MAIN APPLICATION
addappid(1205560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205561, 1, "b1672528cbd44270883f641d330040c38023e4cc59571190385e6144ce4e293c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
