-- Lua provided by RyzenAPI
-- Game: Game: Taimanin Yukikaze 1: Trial

-- MAIN APPLICATION
addappid(1205560)
-- Game: addappid(1205560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205561, 1, "b1672528cbd44270883f641d330040c38023e4cc59571190385e6144ce4e293c")
