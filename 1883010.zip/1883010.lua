-- Lua provided by SkyAPI 
-- Game: Strange Tales of Mid-Lake Pavilion Original Sound Track
addappid(1883010)
addappid(1883011, 1, "cd2c57a4df24f25c5300024693529aeab7adcdcc1f03fd208a06c9265a0244ad")
addappid(1883012, 1, "340eab1605c6108e3e11ded1593b3c1a628cd03d90f3c504f5f835e660f2c777")
