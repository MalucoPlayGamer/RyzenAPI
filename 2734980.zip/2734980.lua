-- Lua provided by RyzenAPI
-- Game: Game: Forward Brave Demo

-- MAIN APPLICATION
addappid(2734980)
-- Game: addappid(2734980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2734981, 1, "82a2709393180cfd2c3878b144168dc152529e6acd8efe9f340241804ac41861")
