-- Lua provided by RyzenAPI
-- Game: Cakefoot

-- MAIN APPLICATION
addappid(2869020)
-- Game: addappid(2869020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869023,0,"4e941dd6727f36884b68827d8ab150662e3b40210d1b0b85f4a77288dd3224fd")
addappid(2869024,0,"f1dd2ce2aef68cfe7af8a1463b211a6fa836dbe95d2d4a29e08f23b6db514f94")
