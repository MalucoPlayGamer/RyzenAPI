-- Lua provided by RyzenAPI
-- Game: Kingdom: The Far Reaches

-- MAIN APPLICATION
addappid(700880)
-- Game: addappid(700880)

-- MAIN APP DEPOTS / PACKAGES
addappid(700881, 1, "a260ab54e5e5d597926097ff4d9d751b56658ae9349f581b5a81c8509b277017")
