-- Lua provided by RyzenAPI
-- Game: Jerez's Arena Ⅲ Original Soundtrack

-- MAIN APPLICATION
addappid(3709900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3709901, 1, "3f3d45da079ad4ab3051e315db57f0cc7a2f3524afdf0202010959454326681d")
addappid(3709902, 1, "b8f5efea6544bb75de457b0fdb5bd388a3298c88dabb4b80a8b201b23a4ef942")
