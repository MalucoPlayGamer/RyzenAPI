-- Lua provided by RyzenAPI
-- Game: AppID 1219910

-- MAIN APPLICATION
addappid(1219910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1219911, 1, "ca448a14c6b5b57c1572b26964929e249702b0bd491407194373fbdc255506dd")

