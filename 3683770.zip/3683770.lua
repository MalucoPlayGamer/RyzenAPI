-- 3683770's Lua and Manifest Created by Hubcap Manifest
-- Boba Cafe Simulator
-- Created: July 24, 2026 at 06:08:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3683770, 1, "806268cd176417e23f4b6cf0384a0398611ff81017d30b394ab10e9ad26b0d96") -- Boba Cafe Simulator
-- MAIN APP DEPOTS
addappid(3683771, 1, "33607e45578e4e6c16c8a04b37464bc01872718a1021df09fbc986410192064f") -- Depot 3683771
setManifestid(3683771, "5677056652811326897", 2552989642)
addappid(3683772, 1, "45f179e1f84c69b6a0056baddf27163c4497c273bf8f1bb55988134d8095fd38") -- Depot 3683772
setManifestid(3683772, "2906821960561499509", 3170723544)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)