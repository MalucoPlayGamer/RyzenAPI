-- Lua provided by RyzenAPI
-- Game: BIG POGO MAN

-- MAIN APPLICATION
addappid(876310)

-- MAIN APP DEPOTS / PACKAGES
addappid(876311, 1, "956ea0a230dfaff47488fe4946855a80edc4b460c6d1c2fb7d4027da041bdeb8")
