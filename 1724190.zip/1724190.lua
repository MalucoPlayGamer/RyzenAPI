-- Lua provided by RyzenAPI
-- Game: Come Home

-- MAIN APPLICATION
addappid(1724190)
addappid(2268610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724191, 1, "c8f08976b38b00a45b64838247237115d9cc259ebd2052417b8fdc8ec40b3359")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1825230)
addappid(1955140)
addappid(2096990)
addappid(2177840)
