-- Lua provided by RyzenAPI
-- Game: 1724190

-- MAIN APPLICATION
addappid(1724190)
addappid(2268610)
-- Game: addappid(1724190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724191, 1, "c8f08976b38b00a45b64838247237115d9cc259ebd2052417b8fdc8ec40b3359")
