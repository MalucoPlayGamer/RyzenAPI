-- Lua provided by RyzenAPI 
-- Game: AppID 1591350
addappid(1591350)
addappid(1591351, 1, "4471532d6f9943c39e9a87d106ca85ceb249e778842b7d081c1c61086592ef5c")
