-- Lua provided by RyzenAPI
-- Game: 黑暗之岛

-- MAIN APPLICATION
addappid(1175320)
-- Game: addappid(1175320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175321, 1, "812444da6f9d1f9fade2bd87031ed70f28137a400d83f72fcf93c17212c7618a")
addappid(1175322, 1, "bd9d5ba6204e59dac5ff240a52a3c6ce73ddce3021cfeeea19b01e7ab446605d")
