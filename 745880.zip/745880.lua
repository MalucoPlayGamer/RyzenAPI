-- Lua provided by RyzenAPI
-- Game: 東方天空璋 ～ Hidden Star in Four Seasons.

-- MAIN APPLICATION
addappid(745880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(745881, 1, "26d1b54ca40b0eca437e7c3a73984d5486f65964c52b4255876fab4719ac2e3e")

