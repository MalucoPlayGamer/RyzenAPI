-- Lua provided by RyzenAPI
-- Game: addappid(745880)

-- MAIN APPLICATION
addappid(745880)

-- MAIN APP DEPOTS / PACKAGES
addappid(745881, 1, "26d1b54ca40b0eca437e7c3a73984d5486f65964c52b4255876fab4719ac2e3e")
