-- Lua provided by RyzenAPI
-- Game: Mullet Mad Jack ARTBOOK

-- MAIN APPLICATION
addappid(2902200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902201, 1, "bf83ad69169fe2b6bd9a96ca69e8d4c26d8bf44b29393b3f559e203d3193f77f")
