-- Lua provided by RyzenAPI 
-- Game: Crib Demo
addappid(2879880)
addappid(2879881, 1, "c0f48e30d873475ddad3a6cffd2a0df27f4965059601dcd9cfcd56355c63dd90")
