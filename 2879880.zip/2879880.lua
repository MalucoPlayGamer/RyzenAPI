-- Lua provided by RyzenAPI
-- Game: Game: Crib Demo

-- MAIN APPLICATION
addappid(2879880)
-- Game: addappid(2879880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879881, 1, "c0f48e30d873475ddad3a6cffd2a0df27f4965059601dcd9cfcd56355c63dd90")
