-- Lua provided by RyzenAPI
-- Game: AppID 810160

-- MAIN APPLICATION
addappid(810160)
-- Game: addappid(810160)

-- MAIN APP DEPOTS / PACKAGES
addappid(810161, 1, "512ec8010740215190a0660963b75a4648fc3bc6e7fc86af28a8edc439ee03fe")
