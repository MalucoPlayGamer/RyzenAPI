-- Lua provided by RyzenAPI
-- Game: ASCII Game Series: Pinball

-- MAIN APPLICATION
addappid(810160)

-- MAIN APP DEPOTS / PACKAGES
addappid(810161, 1, "512ec8010740215190a0660963b75a4648fc3bc6e7fc86af28a8edc439ee03fe")
