-- Lua provided by RyzenAPI
-- Game: AppID 645820

-- MAIN APPLICATION
addappid(645820)
-- Game: addappid(645820)

-- MAIN APP DEPOTS / PACKAGES
addappid(645821, 1, "6daf288bac4e45f416e20400325981a9b145919fae0fd186bf420d7f33c1c4a1")
addappid(1065370, 0, "be0c14efc630c81d31bb6c3371b192ac15cfe0b36b3550ce39e5218e2923073c")
