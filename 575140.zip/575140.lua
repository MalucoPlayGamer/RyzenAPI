-- Lua provided by RyzenAPI
-- Game: Cemetery Warrior 3

-- MAIN APPLICATION
addappid(575140)

-- MAIN APP DEPOTS / PACKAGES
addappid(575141, 1, "161779bc5c9f721926e2353d62a7f464e45387c3d95eef4711612c16a9d54f11")
