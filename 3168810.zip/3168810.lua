-- Lua provided by RyzenAPI
-- Game: Six Shake Coin

-- MAIN APPLICATION
addappid(3168810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168811, 1, "a5bae56870328b8dd69081898ad8f993a17ce2a7a93342e3677a8ed74a0ee44a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
