-- Lua provided by RyzenAPI
-- Game: 1385700

-- MAIN APPLICATION
addappid(1385700)
-- Game: addappid(1385700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385701, 1, "09bb7a294f589189694dc62128fdd9eaa696975c17d0d65c2bb54e99c712d332")
