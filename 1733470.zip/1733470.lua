-- Lua provided by RyzenAPI
-- Game: DIY Lady Fighting

-- MAIN APPLICATION
addappid(1733470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733470,0,"3bedcf58e5fbb358dcf1b0459dea9a450953a7985336f2464d435f843aeb264a")

