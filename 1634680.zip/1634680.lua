-- Lua provided by RyzenAPI
-- Game: addappid(1634680)

-- MAIN APPLICATION
addappid(1634680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634681, 1, "28c2d6ab2577fc32273cf08dbf89f2804c40e98e7aed1e07cda7d652aca3b083")
