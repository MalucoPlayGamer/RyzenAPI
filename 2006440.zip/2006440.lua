-- Lua provided by RyzenAPI
-- Game: 2006440

-- MAIN APPLICATION
addappid(2006440)
-- Game: addappid(2006440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006441, 1, "47e8768b280df1fa9fabdb32479227950f892353aaad67fb739a6dabde7653bc")
