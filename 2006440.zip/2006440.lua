-- Lua provided by SkyAPI 
-- Game: Secret Backrooms
addappid(2006440)
addappid(2006441, 1, "47e8768b280df1fa9fabdb32479227950f892353aaad67fb739a6dabde7653bc")
