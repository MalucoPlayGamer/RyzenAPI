-- Lua provided by RyzenAPI
-- Game: Secret Backrooms

-- MAIN APPLICATION
addappid(2006440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006441, 1, "47e8768b280df1fa9fabdb32479227950f892353aaad67fb739a6dabde7653bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
