-- Lua provided by RyzenAPI
-- Game: AppID 877760

-- MAIN APPLICATION
addappid(877760)
-- Game: addappid(877760)

-- MAIN APP DEPOTS / PACKAGES
addappid(877761, 1, "6ced8306f01d977896a7d875ae989f62b3f197a2d84340df720b7cd22ac78dfe")
