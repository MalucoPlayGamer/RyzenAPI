-- Lua provided by RyzenAPI
-- Game: Game: After the Collapse

-- MAIN APPLICATION
addappid(727570)
-- Game: addappid(727570)

-- MAIN APP DEPOTS / PACKAGES
addappid(727571, 1, "d831e262dcb259d4676e5e7560364a2ec55d93b9545a7959fc71d24fe5e893da")
