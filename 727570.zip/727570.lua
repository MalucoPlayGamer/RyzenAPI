-- Lua provided by SkyAPI 
-- Game: After the Collapse
addappid(727570)
addappid(727571, 1, "d831e262dcb259d4676e5e7560364a2ec55d93b9545a7959fc71d24fe5e893da")
