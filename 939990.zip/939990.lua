-- Lua provided by RyzenAPI
-- Game: Boxing School

-- MAIN APPLICATION
addappid(939990)
addappid(2543230)

-- MAIN APP DEPOTS / PACKAGES
addappid(939991, 1, "c2421537696ceda9c4d78e4bd73a712522fd6e79b00217ae0d32670292be352a")
