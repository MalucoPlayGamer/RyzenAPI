-- Lua provided by RyzenAPI
-- Game: Game: AppID 3222380

-- MAIN APPLICATION
addappid(3222380)
-- Game: addappid(3222380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3222381, 1, "488178a1754da8faeb953a31c9ab18f89f5ec98ef9620ac34be6bf5d8e1cf389")
