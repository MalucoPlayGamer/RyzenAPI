-- Lua provided by RyzenAPI
-- Game: Mech Chip

-- MAIN APPLICATION
addappid(1010830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010831, 1, "fb61d43f96c755d1016b5e6d5d78f45b7fcbf371df9d3544b84b2cc9f74d479c")
