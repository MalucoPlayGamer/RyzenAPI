-- Lua provided by RyzenAPI
-- Game: AppID 332700

-- MAIN APPLICATION
addappid(332700)
addappid(854130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(332701, 1, "eedba49f8f40f3f2adda21c6552f56536edd344f8a41c07d3032af6511492ef5")

