-- Lua provided by RyzenAPI
-- Game: AppID 332700

-- MAIN APPLICATION
addappid(332700)

-- MAIN APP DEPOTS / PACKAGES
addappid(332701, 1, "eedba49f8f40f3f2adda21c6552f56536edd344f8a41c07d3032af6511492ef5")

