-- Lua provided by RyzenAPI
-- Game: 818390

-- MAIN APPLICATION
addappid(818390)
-- Game: addappid(818390)

-- MAIN APP DEPOTS / PACKAGES
addappid(818391, 1, "f7345196f15993683fadf4655b3673bb0f4a3f8bb37046b75841cc765cbe2f7a")
