-- Lua provided by RyzenAPI
-- Game: Guan Xing - Officer Ticket / 関興使用券

-- MAIN APPLICATION
addappid(956924)
-- Game: addappid(956924)

-- MAIN APP DEPOTS / PACKAGES
addappid(956924,0,"af670691b806805311ade1e8ee3aafa776e8f11a5678184022364d55127557d2")
