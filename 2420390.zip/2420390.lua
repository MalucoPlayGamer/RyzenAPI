-- Lua provided by RyzenAPI
-- Game: Game: CODA

-- MAIN APPLICATION
addappid(2420390)
-- Game: addappid(2420390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420391, 1, "25fa93e405fbfb60370b675c477a0daebadca45d8fb0f1e83c0305f8cc32407e")
