-- Lua provided by RyzenAPI
-- Game: Game: Mosa Lina

-- MAIN APPLICATION
addappid(2477090)
-- Game: addappid(2477090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477091, 1, "0fac80b280839321d5fe5d4a2606992c20f50433cd74f963a5c858f61888c831")
addappid(2477092, 1, "8cfe2ff697198fef1759e5abd7adbdfbb36a8da547276959d3b1feb32befbd9d")
addappid(2477093, 1, "0d8d8107193534a9c5316ec18f50cc8c7e5095d87b9e03ee79d5de155f5841b9")
