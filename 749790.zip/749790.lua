-- Lua provided by RyzenAPI
-- Game: 谜题姐妹 Puzzle Sisters OST

-- MAIN APPLICATION
addappid(749790)

-- MAIN APP DEPOTS / PACKAGES
addappid(749792,0,"c70d76cbcf19f763bf707f010603d3fbdbf9fd1640c299901e3d52dfc1232627")

