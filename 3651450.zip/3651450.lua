-- Lua provided by RyzenAPI
-- Game: Fight With Valkyries [18+]

-- MAIN APPLICATION
addappid(3651450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3651451, 1, "97c1b241ad82309b18707396b47f60946f9310f2fde6bd0b93e2765b090f0ef8")
