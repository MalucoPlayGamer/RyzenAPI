-- Lua provided by RyzenAPI
-- Game: Black Geyser: Couriers of Darkness

-- MAIN APPLICATION
addappid(1374930)
addappid(3909990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374931, 1, "c270aeaaed9c1c5bbd776e971c73a6bf462029b123b7be91be60ef7563971c4e")
addappid(1374932, 1, "04ad92102303ccac9cb715d90b477c7793b81d365adfdc1edc510886c3bd62d8")
addappid(1374933, 1, "c5a1e16dedc331b716b4838e144c6580ff9a1b7cb7ffcdc9a8cfe0b1ca704277")

