-- Lua provided by RyzenAPI
-- Game: addappid(337220)

-- MAIN APPLICATION
addappid(337220)

-- MAIN APP DEPOTS / PACKAGES
addappid(337221, 1, "ce01e13a4fa2069e394b22440ff4eb1eedce9f5281f82edc4a1d2f13b17ef32c")
