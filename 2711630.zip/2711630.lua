-- Lua provided by RyzenAPI
-- Game: Aery - Cyber City

-- MAIN APPLICATION
addappid(2711630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711631, 1, "33c87b12fa745fda25015ad55f59f8c09ab920642ec1a2724cccad70ef080e85")
