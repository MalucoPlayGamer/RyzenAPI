-- Lua provided by RyzenAPI
-- Game: Nothing Good Can Come Of This

-- MAIN APPLICATION
addappid(1096990)
-- Game: addappid(1096990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096991, 1, "9240ca96e375875819a1af285a7ff9295e35bae3effcc336c9840cfba189c175")
