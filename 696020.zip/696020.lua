-- Lua provided by RyzenAPI
-- Game: Surface: Game of Gods Collector's Edition

-- MAIN APPLICATION
addappid(696020)

-- MAIN APP DEPOTS / PACKAGES
addappid(696021, 1, "b672f5b6e1a5637d11b7c031e2173c943d653398b87328e3e2683026fafe8c4d")
