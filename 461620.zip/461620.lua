-- Lua provided by RyzenAPI
-- Game: Predynastic Egypt

-- MAIN APPLICATION
addappid(461620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(461621, 1, "152570305e0c473385e01fbb8dea0c65665e65b9cdfc28c9f9a2ae451472137e")
addappid(461622, 1, "9382d0349d075105b2c51e7f987e65698546f782209cd53a12ebd163220a69b3")
addappid(461623, 1, "2660c190087f1e48b9f80714160de3f36c67e9b19287da331e598eb455a442d8")
