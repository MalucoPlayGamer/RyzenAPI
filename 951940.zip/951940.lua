-- Lua provided by SkyAPI 
-- Game: Almost There: The Platformer
addappid(951940)
addappid(951941, 1, "33bdb8a3fcd7b0d4fc80cb1ba01877f151dbc3c3cf19aa1f511587c228ac0146")
addappid(951942, 1, "cf3256867db3d767a989dc73a9462668909647126a13a3a6f5ba23d74a1e7783")
addappid(951943, 1, "5676805348bd0a40af724716a104c684f4421503891f82599ffafd4e3b2a1beb")
