-- Lua provided by RyzenAPI
-- Game: Flail Your Arm, Hit the Ball: Return of KUSOGAKI

-- MAIN APPLICATION
addappid(3585340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3585341, 1, "a23fc43aba2d1ec67c0243db532345afe5ab6c973f26b406af7fb11f0e5613d7")

