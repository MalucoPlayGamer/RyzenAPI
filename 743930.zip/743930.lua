-- Lua provided by RyzenAPI
-- Game: Game: AppID 743930

-- MAIN APPLICATION
addappid(743930)
-- Game: addappid(743930)

-- MAIN APP DEPOTS / PACKAGES
addappid(743931, 1, "0546e923b3c078030eb219b6c54c7f55a3c0b55d90f797252f739b98ddfef0c9")
