-- Lua provided by RyzenAPI
-- Game: 927320

-- MAIN APPLICATION
addappid(927320)
-- Game: addappid(927320)

-- MAIN APP DEPOTS / PACKAGES
addappid(927321, 1, "a523bd93915091072b7996767a32f83ca6d76e170ea071fef4e279b0bcdf8ea9")
