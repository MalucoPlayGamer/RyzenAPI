-- Lua provided by RyzenAPI
-- Game: Spire Horizon Online

-- MAIN APPLICATION
addappid(2598020)
addappid(3348950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598021, 1, "31150bab404b7925f35a9e0d9d631c53d1262f691b9bdcbbfedaeaf2ef420ebf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
