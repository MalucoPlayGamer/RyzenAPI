-- Lua provided by RyzenAPI
-- Game: 2598020

-- MAIN APPLICATION
addappid(2598020)
addappid(3348950)
-- Game: addappid(2598020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598021, 1, "31150bab404b7925f35a9e0d9d631c53d1262f691b9bdcbbfedaeaf2ef420ebf")
