-- Lua provided by RyzenAPI
-- Game: Ignatius

-- MAIN APPLICATION
addappid(1457710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457711, 1, "7d06e1f66f8f89a651284e308c6142e65717f153cd558dca20b7c9244af77b9c")
