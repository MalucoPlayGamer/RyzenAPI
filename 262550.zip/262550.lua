-- Lua provided by RyzenAPI
-- Game: AppID 262550

-- MAIN APPLICATION
addappid(262550)
-- Game: addappid(262550)

-- MAIN APP DEPOTS / PACKAGES
addappid(262551, 1, "5a0f4982e850a7d52474cdba2827f95f9e95e3339df0376d1d7a02d33b242e8a")
