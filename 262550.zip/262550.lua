-- Lua provided by RyzenAPI
-- Game: AppID 262550

-- MAIN APPLICATION
addappid(262550)

-- MAIN APP DEPOTS / PACKAGES
addappid(262551, 1, "5a0f4982e850a7d52474cdba2827f95f9e95e3339df0376d1d7a02d33b242e8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
