-- Lua provided by SkyAPI 
-- Game: Red Bit Ninja
addappid(364900)
addappid(364901, 1, "ea2b2ccb5d1101af77e0fefbd60f184b0a423ed6ee59645ff6f4b5dc382213ed")
