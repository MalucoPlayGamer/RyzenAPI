-- Lua provided by SkyAPI 
-- Game: Clanfolk
addappid(1700870)
addappid(1700871, 1, "279d4f9fe1b44e97299ee0c570d08dfc6aa69119cc9c5c1a5d1cc3467f4811c7")
