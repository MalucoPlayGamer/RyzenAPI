-- Lua provided by RyzenAPI
-- Game: Jigsaw Masterpieces

-- MAIN APPLICATION
addappid(977490)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1011100)
addappid(1013780)
addappid(1036810)
addappid(1037360)
addappid(1037370)
addappid(1058970)
addappid(1059700)
addappid(1059720)
