-- Lua provided by RyzenAPI
-- Game: Jigsaw Masterpieces

-- MAIN APPLICATION
addappid(977490)
