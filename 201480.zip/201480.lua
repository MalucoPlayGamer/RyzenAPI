-- Lua provided by RyzenAPI
-- Game: Serious Sam: The Random Encounter

-- MAIN APPLICATION
addappid(201480)

-- MAIN APP DEPOTS / PACKAGES
addappid(201481, 1, "7d8677c89f43373ed654414529ec97c918c96879878618601dd3a11261deef09")

