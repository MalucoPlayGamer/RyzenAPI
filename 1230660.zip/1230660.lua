-- Lua provided by RyzenAPI
-- Game: addappid(1230660)

-- MAIN APPLICATION
addappid(1230660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230663,0,"75b9a01194a4d7ecadee69c9f503f37eb57223a52948d81f448c4f8a7d1bf2c0")
