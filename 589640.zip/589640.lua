-- Lua provided by RyzenAPI
-- Game: Spoids

-- MAIN APPLICATION
addappid(589640)

-- MAIN APP DEPOTS / PACKAGES
addappid(589641, 1, "f3910ebb839022f44f09575a46ecac531cae5fdbeaced2fcc96ecc18788d65b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
