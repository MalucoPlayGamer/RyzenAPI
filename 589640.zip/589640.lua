-- Lua provided by RyzenAPI
-- Game: 589640

-- MAIN APPLICATION
addappid(589640)
-- Game: addappid(589640)

-- MAIN APP DEPOTS / PACKAGES
addappid(589641, 1, "f3910ebb839022f44f09575a46ecac531cae5fdbeaced2fcc96ecc18788d65b8")
