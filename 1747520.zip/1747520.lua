-- Lua provided by RyzenAPI
-- Game: 1747520

-- MAIN APPLICATION
addappid(1747520)
-- Game: addappid(1747520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747521, 1, "810f176cad40b4cb5bad94e12f8865b67a7ff00635c848d1a64c0d5f7720f5d5")
