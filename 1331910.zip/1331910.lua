-- Lua provided by RyzenAPI
-- Game: Morkredd

-- MAIN APPLICATION
addappid(1331910)
addappid(1415980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331911, 1, "ae196963fc048c042eaed0866a5b52dc33cdff8d0ff03ae3ab325fabb062f1bc")

