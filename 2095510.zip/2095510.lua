-- Lua provided by RyzenAPI
-- Game: Game: Scholar's Mate

-- MAIN APPLICATION
addappid(2095510)
-- Game: addappid(2095510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095511, 1, "d78f8727ea67cd93aa51482428468efdf2a56873c9cb2b0f9396cfde84b5c923")
