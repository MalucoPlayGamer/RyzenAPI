-- Lua provided by RyzenAPI
-- Game: Game: Puzzle Agent 2

-- MAIN APPLICATION
addappid(94590)
-- Game: addappid(94590)

-- MAIN APP DEPOTS / PACKAGES
addappid(94591, 1, "f5eabc419cbb567b02140d3329be7fe93036887717258139730bcbdce0a1df02")
addappid(94592, 1, "3e7980ab009d6a6a64e8533e7f29115b02740072d911e085008571b6c94c903c")
