-- Lua provided by RyzenAPI
-- Game: 1163910

-- MAIN APPLICATION
addappid(1163910)
-- Game: addappid(1163910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163911, 1, "dd806730902dce8fe340552a64eda63d1d4edf2bbe4717b61aed55019f139045")
