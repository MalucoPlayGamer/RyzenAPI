-- Lua provided by RyzenAPI
-- Game: addappid(2197760)

-- MAIN APPLICATION
addappid(2197760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197761, 1, "d33fc0e6572c086141a0f9ed264ca49275b0d00a86fee78c8522632c9c814fc7")
