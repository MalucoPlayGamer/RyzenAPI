-- Lua provided by RyzenAPI
-- Game: 1053680

-- MAIN APPLICATION
addappid(1053680)
-- Game: addappid(1053680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053681, 1, "c6aed26c3e0ae48aa7358a1fa5da6e0e862a29c350f9b2f13fd067993129a454")
