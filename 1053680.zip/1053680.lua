-- Lua provided by SkyAPI 
-- Game: Granny Simulator
addappid(1053680)
addappid(1053681, 1, "c6aed26c3e0ae48aa7358a1fa5da6e0e862a29c350f9b2f13fd067993129a454")
