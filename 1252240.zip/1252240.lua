-- Lua provided by RyzenAPI
-- Game: Game: Aeon Drive

-- MAIN APPLICATION
addappid(1252240)
-- Game: addappid(1252240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252241, 1, "f2bf3658c5da86177138a1d3a47eb60fda53b25dd3cef2ffccadb205c3885ac3")
addappid(1252242, 1, "c7a392baf0b70766389e68e21ae1200ae40edd23a09d9cb59a9cd22942988e49")
addappid(1252243, 1, "3561e0a1b1a5067d0b9542b79caa2bfca0c72d8937c91900fae1894251b010c5")
