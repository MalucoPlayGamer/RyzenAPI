-- Lua provided by RyzenAPI
-- Game: Laika: Aged Through Blood Demo

-- MAIN APPLICATION
addappid(2478170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478171, 1, "4ccb4076f79b4d3c45e49243f2fe96faf17f721057038fe2a09ba5b4d91810ae")

