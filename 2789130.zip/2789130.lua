-- Lua provided by RyzenAPI
-- Game: Highway Police Simulator

-- MAIN APPLICATION
addappid(2789130)
addappid(4218980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2789131, 1, "08fe257efe8783e52e4cf5f5f0d49c87da1448cef591b737b8a5cd6f510f6452")
addappid(2789132, 1, "812f9fc26eeeff34c48354b5030e607dbafa597fccb44a3dcbf58dc90f60bd34")

