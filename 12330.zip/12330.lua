-- Lua provided by RyzenAPI
-- Game: addappid(12330)

-- MAIN APPLICATION
addappid(12330)

-- MAIN APP DEPOTS / PACKAGES
addappid(12331, 1, "e3093a31f45d4de9aa4b60dd8c195a211af98b4848e0ae075f22cd78468543fc")
addappid(12332, 1, "3576a0a4873502d5405745cbabfc26c3a12899bab4673f42a9d6f4b6cb220734")
addappid(12333, 1, "8359f77d6ae9575e6219f2dfb29dece4d1ae91662ef79eb705bae554ed64d8c0")
