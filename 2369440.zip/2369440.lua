-- Lua provided by RyzenAPI
-- Game: 2369440

-- MAIN APPLICATION
addappid(2369440)
-- Game: addappid(2369440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369441, 1, "ccbcc76657eab4becb3e67d50c7776a42f38434ed879ff4dc97af9ebaeb023e6")
