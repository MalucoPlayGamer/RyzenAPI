-- Lua provided by RyzenAPI
-- Game: addappid(1981970)

-- MAIN APPLICATION
addappid(1981970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981971, 1, "39c9b5ec3ce27852d2f6cb18ab544c271e6691f56b4654e0642fb286a59e2b02")
