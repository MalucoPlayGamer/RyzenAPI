-- Lua provided by RyzenAPI
-- Game: Hentai Sweet Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1082320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082320,0,"021c2ddbf9018bb99a4a7a682b336b6b0f687b72048f682f6cf68ed65e724fc5")

