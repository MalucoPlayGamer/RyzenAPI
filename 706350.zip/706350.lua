-- Lua provided by RyzenAPI
-- Game: Mari and the Black Tower

-- MAIN APPLICATION
addappid(706350)

-- MAIN APP DEPOTS / PACKAGES
addappid(706351, 1, "471d08a871e3ff6802734972cd03b235fb427739bf666ca03973267153596327")

