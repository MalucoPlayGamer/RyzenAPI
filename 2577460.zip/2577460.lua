-- Lua provided by RyzenAPI
-- Game: The Explorator Demo

-- MAIN APPLICATION
addappid(2577460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577461, 1, "97e80c820e893cc5378299b67f22f7640f2a033a224e2a63d67da60df131b604")

