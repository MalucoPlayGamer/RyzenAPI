-- Lua provided by RyzenAPI
-- Game: 3029820

-- MAIN APPLICATION
addappid(3029820)
-- Game: addappid(3029820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029821, 1, "60031b73d42ead35d77383add371662c4a8d630ac1da5a154fe2db8e6c3ed872")
