-- Lua provided by RyzenAPI
-- Game: Lovers in a Dangerous Spacetime

-- MAIN APPLICATION
addappid(252110)

-- MAIN APP DEPOTS / PACKAGES
addappid(252111, 1, "3a988540053e6b38bd72cbfe5f3d7f492d1816581219bc21014fe069d240f14d")
addappid(252112, 1, "fdc17c96027f667ae98e482b4177d3fefceda4aa26e911955f366f76e77771a9")
addappid(252113, 1, "cd3e4de229bc2d15de0044ba3469ea1d09eac3447539a63dd6874f219a6fc3de")
