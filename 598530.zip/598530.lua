-- Lua provided by RyzenAPI
-- Game: Naev

-- MAIN APPLICATION
addappid(598530)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(598531, 1, "4e37a0e408a320f531dafec38e8655e57eaf6f82b69f605f62c17395a65fb188")
addappid(598532, 1, "bd0eae8dd43e8e356e8c4f253f5da16965d38b4df015bc2e58475b5554b26806")
addappid(598534, 1, "47ed43ee392e7f3b3b129369c2e271f8a9897ce4a185725d15a6147f7746ad7f")
addappid(598536, 1, "c5f898d41948d006e91ec3048c09c32dc604cc2c9de1e352f9226e6559a636e4")
