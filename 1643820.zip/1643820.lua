-- Lua provided by RyzenAPI
-- Game: addappid(1643820)

-- MAIN APPLICATION
addappid(1643820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643821, 1, "cdee832fd9030d65168f119add112f7d12be8ce1018f9b79d88fab846300072c")
