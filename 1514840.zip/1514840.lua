-- Lua provided by RyzenAPI
-- Game: Game: All-In-One Sports VR

-- MAIN APPLICATION
addappid(1514840)
-- Game: addappid(1514840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514841, 1, "b39f11c39af1571c64ef5c15d5922dfec1f128df636c2f3dac6fa58473c6643c")
