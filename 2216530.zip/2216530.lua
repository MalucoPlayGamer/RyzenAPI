-- Lua provided by RyzenAPI
-- Game: Vengeful Guardian: Moonrider (Original Game Soundtrack)

-- MAIN APPLICATION
addappid(2216530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216532,0,"b718f54ad689a07d070b82565e6ec39f86106bd12bae9dfcc61f81c38479a87f")
addappid(2216533,0,"7e20bf11d6f3b05e13b4203af1fc158b3bf8b38d82998f892dd21b3c9e5d9f0d")

