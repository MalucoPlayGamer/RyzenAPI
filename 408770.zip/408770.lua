-- Lua provided by RyzenAPI
-- Game: Highschool Possession

-- MAIN APPLICATION
addappid(408770)
-- Game: addappid(408770)

-- MAIN APP DEPOTS / PACKAGES
addappid(408771, 1, "2b607147d5eed7894c78f1d685e63880e9b28b87e0c2cf6594d4ce4debbf955e")
