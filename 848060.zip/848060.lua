-- Lua provided by RyzenAPI
-- Game: 848060

-- MAIN APPLICATION
addappid(848060)
-- Game: addappid(848060)

-- MAIN APP DEPOTS / PACKAGES
addappid(848061, 1, "06cbfd6b0e44d03a1d95f9ede613519060e0d433f95edb2cd9f9b161014ad0ef")
addappid(1208250, 0, "c759774851b1573f7e0e6702d53b905c470ddf0d0563145823f0d571e2c74fcf")
