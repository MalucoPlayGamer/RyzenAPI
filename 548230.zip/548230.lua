-- Lua provided by RyzenAPI
-- Game: Game: SPINGUN

-- MAIN APPLICATION
addappid(548230)
-- Game: addappid(548230)

-- MAIN APP DEPOTS / PACKAGES
addappid(548231, 1, "ec5b52f7b69d6f7ce33bdbb069f7bc6969c8816260f5a2ac38db8c0ab6250951")
addappid(548232, 1, "21628001a5bd9922dd504e6eaa236b8e44edd4a6afae9d908b7d65ca8b1a337d")
addappid(548233, 1, "83dc5da3d6285e4d850eb9233461536c57b0d485937d4d93056b0108f0b638f9")
