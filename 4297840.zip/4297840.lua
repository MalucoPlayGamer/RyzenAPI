-- Lua provided by RyzenAPI
-- Game: Rock Bottom

-- MAIN APPLICATION
addappid(4297840)

-- MAIN APP DEPOTS / PACKAGES
addappid(4297841,0,"b9868b3b6b0c77f0aa3ff3c6429d69fb0dda5f48d3f061a451d9c08df374cc03")

