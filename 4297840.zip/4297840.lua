-- Lua provided by RyzenAPI
-- Game: Rock Bottom

-- MAIN APPLICATION
addappid(4297840)

-- MAIN APP DEPOTS / PACKAGES
addappid(4297840, 1, "524f754694f6a820d3c6f196dd4eb0a89072137a3cb67e0f27d36c3c82c6ff16")
addappid(4297841, 1, "b9868b3b6b0c77f0aa3ff3c6429d69fb0dda5f48d3f061a451d9c08df374cc03")

