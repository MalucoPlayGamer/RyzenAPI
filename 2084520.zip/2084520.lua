-- Lua provided by RyzenAPI
-- Game: addappid(2084520)

-- MAIN APPLICATION
addappid(2084520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084521, 1, "ad942bb900eb86df24d5be97efe3f231ffa4e0d192d14a3d2110ae13dae9b47e")
