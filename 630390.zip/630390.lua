-- Lua provided by RyzenAPI
-- Game: Safari Venture

-- MAIN APPLICATION
addappid(630390)

-- MAIN APP DEPOTS / PACKAGES
addappid(630391, 1, "b0096998baa59dbb68730d6d5bba3ee8808829af22b271a380cba42e55ca59bc")
addappid(630392, 1, "c651e66a5130da04abf38aceeb20b9049cd11d9a283d97bdb4fff39d8aeb2fa7")
addappid(630393, 1, "e0cb3fc3c10714b20e75a39a64d80458975b168c338356422d383095ce303566")
addappid(630394, 1, "53c3c820cda80f73b5a21ae9fe9c16d46c7eb4f3f2fe481e2f921545131ceea3")
