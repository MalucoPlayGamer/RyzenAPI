-- Lua provided by RyzenAPI
-- Game: Dark Nights with Poe and Munro

-- MAIN APPLICATION
addappid(1098170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098172,0,"91c6f5becd84ac89fb718239a193bfb25d88bd073afe8446e5dc95d54e2cc4fc")
addappid(1098173,0,"e5eb425766c3001ed857e4589eaacf9f254c76757544bd875818cec0e0141622")
addappid(1098174,0,"39967f6e1d2dc18fc4605885df531331e92b771ce9c811fb810dc51bc41c35bc")
addappid(1098175,0,"cd6b0c242e1297cf1bef163d1410ffbd4adacc873c8c6367701c0ff4570bc90a")
addappid(1098176,0,"4a23ec682dac949dce5a10c366c3d5e76c17e0a321f92f3debbd0d91a513c9ff")

