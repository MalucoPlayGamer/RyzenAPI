-- Lua provided by RyzenAPI
-- Game: Exp Parasite

-- MAIN APPLICATION
addappid(1356790)
-- Game: addappid(1356790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356791, 1, "88bbdfc2245412b5d33890ce36b356113a2a3ea992ed574f700cb912943e57ec")
