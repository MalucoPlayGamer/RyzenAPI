-- Lua provided by SkyAPI 
-- Game: Exp Parasite
addappid(1356790)
addappid(1356791, 1, "88bbdfc2245412b5d33890ce36b356113a2a3ea992ed574f700cb912943e57ec")
