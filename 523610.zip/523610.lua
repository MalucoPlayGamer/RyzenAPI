-- Lua provided by RyzenAPI
-- Game: addappid(523610)

-- MAIN APPLICATION
addappid(523610)

-- MAIN APP DEPOTS / PACKAGES
addappid(523611, 1, "0f4d68ed4a28cd45c60888ed60d6547467cdad4e56c1c7de1abf6c408730d855")
