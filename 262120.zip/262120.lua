-- Lua provided by RyzenAPI
-- Game: Toy Soldiers: Complete

-- MAIN APPLICATION
addappid(262120)

-- MAIN APP DEPOTS / PACKAGES
addappid(262121, 1, "90fc6f3e6b57459e65cfdaec121da2e529341abf715518b788a1dc9392fc49cd")
