-- Lua provided by RyzenAPI
-- Game: addappid(3111480)

-- MAIN APPLICATION
addappid(3111480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111481, 1, "f44206ee96f430685a2ac8b4ffbf80e623ca4d01b38326286cfa8a6ffcb2c37f")
