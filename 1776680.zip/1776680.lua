-- Lua provided by RyzenAPI
-- Game: Block'Em! Demo

-- MAIN APPLICATION
addappid(1776680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776681, 1, "6d02cabe5eca56959d33e0b58abfbd5d51f52e48ccb026b922908b8a394185a7")

