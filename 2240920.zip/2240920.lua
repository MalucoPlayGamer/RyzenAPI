-- Lua provided by RyzenAPI
-- Game: Game: AppID 2240920

-- MAIN APPLICATION
addappid(2240920)
-- Game: addappid(2240920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240921, 1, "05ac5ed98d79a5cb688058a59e2e2d9b179bb7fffb8b521c7e03cb5f16537e1c")
