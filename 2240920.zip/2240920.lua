-- Lua provided by SkyAPI 
-- Game: AppID 2240920
addappid(2240920)
addappid(2240921, 1, "05ac5ed98d79a5cb688058a59e2e2d9b179bb7fffb8b521c7e03cb5f16537e1c")
