-- Lua provided by RyzenAPI
-- Game: Aragami

-- MAIN APPLICATION
addappid(280160)
addappid(564400)

-- MAIN APP DEPOTS / PACKAGES
addappid(280161, 1, "a59b45b063a8d869318256c985ac25e690a1c67fa4c92e41924ea722d974b2a2")
addappid(280162, 1, "42a8d521589e158321b9c8ae88910a025b49945181ce5f7a3e7c9de42afd20ea")
addappid(280163, 1, "9ad4d3149291c5c6d4aef407c905420c7b879cff221059a04bdd5b1f18fcb3ba")
addappid(280164, 1, "59df90bcdfb2452f6892515a393beb5bbdb21340d210e0f2e30b4aa7f9dad7a0")
addappid(462390, 0, "12cf4bda64deaa146ed0fc9bf1afe76de4d542178cbf4304bf6b2d1e75b17758")
