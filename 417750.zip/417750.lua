-- Lua provided by RyzenAPI
-- Game: Game: AppID 417750

-- MAIN APPLICATION
addappid(417750)
-- Game: addappid(417750)

-- MAIN APP DEPOTS / PACKAGES
addappid(417751, 1, "c8898b03b6d4036bf95faa8d91a5b36a6bf1085f25bf5fb63dab2995d8938e42")
