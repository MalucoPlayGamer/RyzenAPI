-- Lua provided by RyzenAPI
-- Game: 34000

-- MAIN APPLICATION
addappid(34000)
-- Game: addappid(34000)

-- MAIN APP DEPOTS / PACKAGES
addappid(34001, 1, "1da49c9c066958eec3eae2cfca3c9373e81bb53d02c87da754cbe25dd2ae9996")
addappid(34002, 1, "33e36ee9fcf16a03739abf6cc496811a7632401cc025f305dc1adac7db1e4c99")
