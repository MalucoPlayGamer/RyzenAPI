-- Lua provided by RyzenAPI
-- Game: NITE Team 4 - Military Hacking Division

-- MAIN APPLICATION
addappid(544390)
addappid(971750)
addappid(1041830)
addappid(1041831)
addappid(1194000)

-- MAIN APP DEPOTS / PACKAGES
addappid(544391, 1, "ebcafe4b46b3bcfd36982aa1e1a9fe42702ca4e228e88ebc83daf120c1b539ea")
addappid(544392, 1, "92c49fcaa4def580126ef5c2ef58785e9c632ce55614d185cf4a7dd466fa7f43")
addappid(544393, 1, "6bced8446d12820d9a098a9e7fd83873a74940bd7284dc644371b03a2ed205dc")
addappid(544394, 1, "85a44e790f6e5d8eb7b0f37a398412786848ff8d407089fbc760ff74cdb0da05")

