-- Lua provided by RyzenAPI
-- Game: addappid(1612780)

-- MAIN APPLICATION
addappid(1612780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612781, 1, "ee08e32e050de9d437206154ab7d76fa10be7728e765abd345d8a35a2e79040c")
