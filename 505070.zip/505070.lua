-- Lua provided by RyzenAPI
-- Game: Secrets of Me

-- MAIN APPLICATION
addappid(505070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(505071, 1, "f98294675d32c0189bf2bb9510532db78d9563f629090440c8de77e1c0cc4555")
