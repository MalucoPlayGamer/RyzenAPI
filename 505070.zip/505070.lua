-- Lua provided by RyzenAPI
-- Game: Game: AppID 505070

-- MAIN APPLICATION
addappid(505070)
-- Game: addappid(505070)

-- MAIN APP DEPOTS / PACKAGES
addappid(505071, 1, "f98294675d32c0189bf2bb9510532db78d9563f629090440c8de77e1c0cc4555")
