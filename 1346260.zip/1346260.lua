-- Lua provided by RyzenAPI
-- Game: Another road

-- MAIN APPLICATION
addappid(1346260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346261, 1, "c1b23879d0d8ead8af9384c38bc9b3d4552e690b22f68830b13f20ff2073288b")

