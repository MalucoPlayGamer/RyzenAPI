-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 2: Lost Legends & the Secret Fairy

-- MAIN APPLICATION
addappid(1257290)
addappid(1441710)
addappid(1441711)
addappid(1441712)
addappid(1441713)
addappid(1441714)
addappid(1441715)
addappid(1441716)
addappid(1441717)
addappid(1441718)
addappid(1441719)
addappid(1441720)
addappid(1441721)
addappid(1441722)
addappid(1441723)
addappid(1441724)
addappid(1441725)
addappid(1441726)
addappid(1441727)
addappid(1441728)
addappid(1441729)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257291, 1, "9cb68a1cc3e8a80bd31c5d9afb86ded98606fd2dd196cc12eaab0482234583ab")
addappid(1441730, 0, "92e0247ba226536e7fc9e9fb23b14eed86b1cfc5189504a5ca617073b4e507b4")
addappid(1441731, 0, "a6fd6f5dc402e3788cf42e6b76ad277a517d40d43b3fd53f775e64151cdbe50b")
addappid(1604850, 0, "652e5dfa317e237d3f5b8824109876856ba0196f6c7d852e0652be086237bfb9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
