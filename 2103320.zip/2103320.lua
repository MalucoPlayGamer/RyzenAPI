-- Lua provided by RyzenAPI
-- Game: Screaming Noppy

-- MAIN APPLICATION
addappid(2103320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103321, 1, "a5ea670e6f7674b3a7579949440cb13083dda9050aa6199b97b708c374cbab41")

