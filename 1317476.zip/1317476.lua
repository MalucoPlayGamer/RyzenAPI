-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1317476)
addappid(1317742)
addappid(1317743)
addappid(1317745)
addappid(1317746)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317476,0,"14d086adde95e1d6de1d780f477542d15a44ac5146fc6cac4e3d7e29b43dbf3b")
addappid(1317740,0,"6cebf8b4c82202b56695134e688bb5cbd2a1ec142103b03b520dedb2f0d97b58")
addappid(1317741,0,"762ae9766290dec1556a7bff890d3308ef588ce89bb4729b29e1d93707f17850")
addappid(1317744,0,"2cffce8a7c6d4c8fc5034f2a1487ae5a58213bca342f710186214015c452d023")

