-- Lua provided by RyzenAPI
-- Game: 2687670

-- MAIN APPLICATION
addappid(228988)
addappid(229007)
addappid(2687670)
-- Game: addappid(2687670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677751,0,"91ea9b47c5e7f5a0d687007a4492d1ad388b3577ad5129afaeefb0489b98fa49")
