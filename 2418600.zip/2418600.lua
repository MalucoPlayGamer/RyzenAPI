-- Lua provided by RyzenAPI
-- Game: addappid(2418600)

-- MAIN APPLICATION
addappid(2418600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418601, 1, "e999a06dae131bc4dc2375a1a15090e222d268dae80d73d94b063569dff5b131")
