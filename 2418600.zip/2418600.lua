-- Lua provided by RyzenAPI
-- Game: Los Pingheros

-- MAIN APPLICATION
addappid(2418600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418601, 1, "e999a06dae131bc4dc2375a1a15090e222d268dae80d73d94b063569dff5b131")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
