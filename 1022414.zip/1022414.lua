-- Lua provided by RyzenAPI
-- Game: addappid(1022414)

-- MAIN APPLICATION
addappid(1022414)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022414,0,"15e42ac0981e21cf2ccc2bc288ba5a9d083333fb8fd3a7d0c114e10e35304780")
