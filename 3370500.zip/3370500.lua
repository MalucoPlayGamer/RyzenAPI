-- Lua provided by RyzenAPI 
-- Game: MINE : FOREVER
addappid(3370500)
addappid(3370501, 1, "ea4772f484d5f3c6f6bd3d458671cca6c3c76fb96c23d9b9c7a4014685c8c0ec")
