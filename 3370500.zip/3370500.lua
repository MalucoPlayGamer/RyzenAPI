-- Lua provided by RyzenAPI
-- Game: Game: MINE : FOREVER

-- MAIN APPLICATION
addappid(3370500)
-- Game: addappid(3370500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3370501, 1, "ea4772f484d5f3c6f6bd3d458671cca6c3c76fb96c23d9b9c7a4014685c8c0ec")
