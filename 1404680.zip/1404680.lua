-- Lua provided by RyzenAPI
-- Game: Succubus Hunter

-- MAIN APPLICATION
addappid(1404680)
-- Game: addappid(1404680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404680,0,"4303eaee0a90e3962f37e575661e426dd6609a816256e83816a0a27569a36759")
