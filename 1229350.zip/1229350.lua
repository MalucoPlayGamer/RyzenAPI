-- Lua provided by RyzenAPI
-- Game: The Witcher 2: Assassins of Kings Enhanced Edition Soundtrack

-- MAIN APPLICATION
addappid(1229350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229351, 1, "9bce762ae63040692fbc726810f9eab9d3649fed3aa66c89d88a2ea7ade83880")
addappid(1229352, 1, "1d2af59f426b27399f5119bd99967de2e62cddfe51b6e31206514091645ac0b7")
