-- Lua provided by RyzenAPI
-- Game: this game will end in 205 clicks.

-- MAIN APPLICATION
addappid(3585630)
addappid(3898670)

