-- Lua provided by RyzenAPI
-- Game: AppID 1924490

-- MAIN APPLICATION
addappid(1924490)
-- Game: addappid(1924490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924491, 1, "ea75f2dc76f9a9ef6730bac2ebf3b2175a571491ccef70f6a60fc8dff2e7b72c")
