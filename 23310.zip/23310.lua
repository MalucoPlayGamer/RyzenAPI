-- Lua provided by RyzenAPI
-- Game: addappid(23310)

-- MAIN APPLICATION
addappid(23310)

-- MAIN APP DEPOTS / PACKAGES
addappid(23311, 1, "111eb114b1ea7ea59cff11836cd226bb90f5ed4a50966040f3e485c6ce5f0e00")
