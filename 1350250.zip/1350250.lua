-- Lua provided by RyzenAPI
-- Game: Game: AppID 1350250

-- MAIN APPLICATION
addappid(1350250)
-- Game: addappid(1350250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350251, 1, "49eeb392f2d8dd225d52aeede1f55445a3d345556f1fa5c615d9b12bb2c62797")
