-- Lua provided by RyzenAPI
-- Game: Stardeus Demo

-- MAIN APPLICATION
addappid(1719580)
-- Game: addappid(1719580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719582,0,"d864c2d2dc46564683c8e784068dced8b3e9b534d7e32f79a8aab1fd4c5e562b")
