-- Lua provided by SkyAPI 
-- Game: FREEDOM WARS Remastered
addappid(3004100)
addappid(3004101, 1, "a4dcf5fa4a35b461898f324cadee75e864b642d9e6e96bea6210671255187917")
addappid(3242020, 0, "a271f413ac140befa3d41901f62fdabf73c826aa8aed90f33d9a3ebc86694fc5")
addappid(3242030, 0, "f64d6a873141ae5a82236b606f525357cb45d0798c054d52641c93dd5a52d2d5")
