-- Lua provided by RyzenAPI
-- Game: FREEDOM WARS Remastered

-- MAIN APPLICATION
addappid(3004100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004101, 1, "a4dcf5fa4a35b461898f324cadee75e864b642d9e6e96bea6210671255187917")
addappid(3242020, 0, "a271f413ac140befa3d41901f62fdabf73c826aa8aed90f33d9a3ebc86694fc5")
addappid(3242030, 0, "f64d6a873141ae5a82236b606f525357cb45d0798c054d52641c93dd5a52d2d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
