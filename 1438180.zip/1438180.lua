-- Lua provided by RyzenAPI
-- Game: addappid(1438180)

-- MAIN APPLICATION
addappid(1438180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438180,0,"84131c282e42c7be2ca16ac0cd74f237981a49291c218d39d582eb0c1c9a34d2")
