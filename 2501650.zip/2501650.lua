-- Lua provided by RyzenAPI
-- Game: Electrogical

-- MAIN APPLICATION
addappid(2501650)
-- Game: addappid(2501650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2501651, 1, "e8a43f819a674267221c71fb92d4c460858b9ee27871ce9718677ef872a44274")
