-- 1710930's Lua and Manifest Created by Hubcap Manifest
-- Bubble People
-- Created: August 12, 2026 at 05:37:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1710930, 1, "ada172fba6a9ee2d20414c12cad1f3b1b0d39031cd2f8343a32d9f1c02e9d5b0") -- Bubble People
-- MAIN APP DEPOTS
addappid(1710931, 1, "75898e8dd6506427ba90cdfa3109edbef556248ed3cc53ce979e4bfd531da88f") -- Depot 1710931
setManifestid(1710931, "1381505354868952013", 218540790)