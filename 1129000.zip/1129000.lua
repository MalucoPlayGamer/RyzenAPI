-- Lua provided by RyzenAPI 
-- Game: AppID 1129000
addappid(1129000)
addappid(1129001, 1, "0ce5e2c0efd545724bc7e624435a5b40c69094e1d3482b1c4c7fd3589b613c46")
