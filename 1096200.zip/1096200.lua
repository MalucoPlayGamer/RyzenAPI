-- Lua provided by RyzenAPI 
-- Game: AppID 1096200
addappid(1096200)
addappid(1096201, 1, "d15e5e452d70c1a25830f7c77af8fc624c866d4b13c97d8ca285196dffa207fa")
addappid(1096202, 1, "2a7a2c97e04d0346eab764e369410f2707569f4df69ae8413a338c1dee1d08e4")
