-- Lua provided by RyzenAPI
-- Game: The Orville - Interactive Fan Experience

-- MAIN APPLICATION
addappid(1096200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1096201, 1, "d15e5e452d70c1a25830f7c77af8fc624c866d4b13c97d8ca285196dffa207fa")
addappid(1096202, 1, "2a7a2c97e04d0346eab764e369410f2707569f4df69ae8413a338c1dee1d08e4")

