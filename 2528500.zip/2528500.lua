-- Lua provided by RyzenAPI
-- Game: Pseudoregalia Original Soundtrack

-- MAIN APPLICATION
addappid(2528500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2528501, 1, "e23628834d79fcdb3f5daa91b8cec5190bc13f3f28ac644be325f25c8bf75572")

