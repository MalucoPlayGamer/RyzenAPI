-- Lua provided by RyzenAPI 
-- Game: Pseudoregalia Original Soundtrack
addappid(2528500)
addappid(2528501, 1, "e23628834d79fcdb3f5daa91b8cec5190bc13f3f28ac644be325f25c8bf75572")
