-- Lua provided by RyzenAPI
-- Game: DARK SOULS™ II: Scholar of the First Sin

-- MAIN APPLICATION
addappid(335300)

-- MAIN APP DEPOTS / PACKAGES
addappid(335301, 1, "cf0e82e9ee3c3dd620a31184d8fb9d60c9e6641be15cdd5cc6da9960e822384a")
addappid(335302, 1, "7a10a8968977653c95ac43dc8e7799f02750283f840618910466e264e85f97c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
