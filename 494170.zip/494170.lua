-- Lua provided by RyzenAPI
-- Game: Miniature Garden

-- MAIN APPLICATION
addappid(494170)
-- Game: addappid(494170)

-- MAIN APP DEPOTS / PACKAGES
addappid(494171, 1, "add4147c23bccf61955d3f471e848ca287b4d1a3f0cab06c74fbd295696de8b3")
