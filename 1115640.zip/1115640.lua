-- Lua provided by RyzenAPI
-- Game: addappid(1115640)

-- MAIN APPLICATION
addappid(1115640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115641, 1, "29aaedc793fa0d1ba802963623253ab9e50cce7575280f361a7ceab000885a57")
