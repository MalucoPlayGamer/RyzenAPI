-- Lua provided by RyzenAPI
-- Game: addappid(1665080)

-- MAIN APPLICATION
addappid(1665080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665081, 1, "d01a798e93f814c92972c34ebdccdbc7117016f657bb04d33187b72ae0d1bf97")
