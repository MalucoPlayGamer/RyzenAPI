-- Lua provided by RyzenAPI
-- Game: addappid(2867510)

-- MAIN APPLICATION
addappid(2867510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867511, 1, "0788ebd187c706ab574294a1adca7df895f9266ca79d078cf49fcad12581820e")
