-- Lua provided by SkyAPI 
-- Game: The Wizard's Pen™
addappid(3580)
addappid(3581, 1, "a3b31cfce4da35fb38128a3b3aff102b0f7d9e63c8f8f5280335de9402fd4201")
