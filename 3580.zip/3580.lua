-- Lua provided by RyzenAPI
-- Game: Game: The Wizard's Pen™

-- MAIN APPLICATION
addappid(3580)
-- Game: addappid(3580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3581, 1, "a3b31cfce4da35fb38128a3b3aff102b0f7d9e63c8f8f5280335de9402fd4201")
