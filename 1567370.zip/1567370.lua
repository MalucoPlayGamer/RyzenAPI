-- Lua provided by RyzenAPI
-- Game: addappid(1567370)

-- MAIN APPLICATION
addappid(1567370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567371, 1, "eb1b52039bd62cca8090bcb4ca8a38bc035ec5b0adb16b5975ec519717a4cafd")
