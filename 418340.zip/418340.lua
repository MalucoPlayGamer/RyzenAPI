-- Lua provided by RyzenAPI
-- Game: RWBY: Grimm Eclipse

-- MAIN APPLICATION
addappid(418340)
addappid(580830)
addappid(580831)
addappid(580832)
addappid(580833)

-- MAIN APP DEPOTS / PACKAGES
addappid(418341, 1, "ade09f55759d653638fce3d34ad06beee4bea3741206b782b2ec6f7f0c42dbab")
addappid(418342, 1, "cb9c501665380571dad0c2e4656eebded54ed4f0ee33090a157f64e5fc665190")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(522120)
addappid(954100)
addappid(954101)
addappid(954102)
addappid(954103)
