-- Lua provided by RyzenAPI
-- Game: addappid(208030)

-- MAIN APPLICATION
addappid(208030)

-- MAIN APP DEPOTS / PACKAGES
addappid(208031, 1, "bb70116b6e07071d13df127e05a5591785de68ea6976f772f2f995f8186bff00")
