-- Lua provided by SkyAPI 
-- Game: AppID 208030
addappid(208030)
addappid(208031, 1, "bb70116b6e07071d13df127e05a5591785de68ea6976f772f2f995f8186bff00")
