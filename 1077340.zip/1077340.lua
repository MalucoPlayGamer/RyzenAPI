-- Lua provided by RyzenAPI
-- Game: Downtown Drift

-- MAIN APPLICATION
addappid(1077340)
addappid(2009740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077341, 1, "a1068e3477114102ae7cde992f52c36f533729071d3c95a8cb61edea28bb9861")
