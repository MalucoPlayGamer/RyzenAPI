-- Lua provided by RyzenAPI
-- Game: Bunny Girl Story 18+ Adult Only Content

-- MAIN APPLICATION
addappid(1934070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934070,0,"4b96826194f09c9c948fe8796d93fd94a5436c55e3ab43a38e0e6590697ba4cd")
