-- Lua provided by SkyAPI 
-- Game: AppID 1202650
addappid(1202650)
addappid(1202651, 1, "db8aa9b9cc274017588e105f37433576e9b699f5552cee9c8878b8c403e35f9b")
