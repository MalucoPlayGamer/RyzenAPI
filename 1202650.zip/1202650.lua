-- Lua provided by RyzenAPI
-- Game: addappid(1202650)

-- MAIN APPLICATION
addappid(1202650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202651, 1, "db8aa9b9cc274017588e105f37433576e9b699f5552cee9c8878b8c403e35f9b")
