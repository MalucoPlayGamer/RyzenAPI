-- Lua provided by RyzenAPI
-- Game: Dead Reckoning: Silvermoon Isle Collector's Edition

-- MAIN APPLICATION
addappid(586690)

-- MAIN APP DEPOTS / PACKAGES
addappid(586691,0,"4dbd543245f1fda859e9eaeb16a1fb1a2ed4cb152802f7d060e7b9f847f3d3b1")

