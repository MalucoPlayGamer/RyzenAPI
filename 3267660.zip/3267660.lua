-- Lua provided by RyzenAPI
-- Game: [Demo] The Backrooms: Rescue Expedition

-- MAIN APPLICATION
addappid(3267660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267661, 1, "cda4add68279344263a3368bcd3030d5ec70739f050444606abeb7aa4051213f")
