-- Lua provided by SkyAPI 
-- Game: Cooking Craze
addappid(2540630)
addappid(2540631, 1, "bd07c0908fbf8b44991612c18d5d5806d829adb35620205b55774337931d4150")
