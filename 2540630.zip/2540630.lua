-- Lua provided by RyzenAPI
-- Game: Cooking Craze

-- MAIN APPLICATION
addappid(2540630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540631, 1, "bd07c0908fbf8b44991612c18d5d5806d829adb35620205b55774337931d4150")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2707750)
addappid(2707760)
addappid(2707770)
addappid(2707780)
addappid(2707790)
addappid(2708360)
addappid(2709720)
