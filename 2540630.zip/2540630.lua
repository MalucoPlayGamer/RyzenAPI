-- Lua provided by RyzenAPI
-- Game: Cooking Craze

-- MAIN APPLICATION
addappid(2540630)
-- Game: addappid(2540630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540631, 1, "bd07c0908fbf8b44991612c18d5d5806d829adb35620205b55774337931d4150")
