-- Lua provided by RyzenAPI
-- Game: Beat Saber: Billie Eilish - 'I Didn't Change My Number'

-- MAIN APPLICATION
addappid(1753525)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753525,0,"d6f95d06ec5266f1c8a59a63d13f85b08417366ea4ef80a15025dc4ae9f9a65b")

