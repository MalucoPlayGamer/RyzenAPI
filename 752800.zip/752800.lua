-- Lua provided by RyzenAPI
-- Game: Mysterious Realms RPG

-- MAIN APPLICATION
addappid(752800)
-- Game: addappid(752800)

-- MAIN APP DEPOTS / PACKAGES
addappid(752801, 1, "7eca84366aa3be3961f5823253abb2b7e17d9d32c4d91db4ce07a4d6e81eb6b0")
