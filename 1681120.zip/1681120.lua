-- Lua provided by RyzenAPI
-- Game: Dark Side of Fate

-- MAIN APPLICATION
addappid(1681120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681121, 1, "d9fbb3a6f09a7c7af9fbb5311320732f0a1e5ffeace8319324e121b084c94cf7")

