-- Lua provided by SkyAPI 
-- Game: Path of the Abyss
addappid(1768650)
addappid(1768651, 1, "3851d9d428d99c555d4edabbbe52ccd16c6e88d08202634eac75ed472d72fcb1")
