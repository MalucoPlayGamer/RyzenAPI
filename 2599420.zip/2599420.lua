-- Lua provided by RyzenAPI
-- Game: Dynasty

-- MAIN APPLICATION
addappid(2599420)
-- Game: addappid(2599420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599421, 1, "e5f62f0535bbee8446c0bb3d0129d5fcf6b36809ec9f02715ea1094ecbaff4ae")
