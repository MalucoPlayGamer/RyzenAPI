-- Lua provided by RyzenAPI
-- Game: Monaco: What's Yours Is Mine

-- MAIN APPLICATION
addappid(113020)
addappid(228983)
addappid(228990)
-- Game: addappid(113020)

-- MAIN APP DEPOTS / PACKAGES
addappid(113021, 1, "2efbe56d783a510f9a8f67178e4f2e0b697aba6b3d3b4d72fbb6e80de6791353")
addappid(113023, 1, "ac960a3da367fd055b66581b7d987555f264a7dbaab7248e3292f219f0674b4e")
addappid(234451, 0, "7d699fca524ff3192afa1fda02e03f40074e8da1c8f5642fdbc89b123b082c3f")
