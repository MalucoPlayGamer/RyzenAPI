-- Lua provided by RyzenAPI
-- Game: AppID 3489860

-- MAIN APPLICATION
addappid(3489860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489861, 1, "d8b530b4083bd62077d9c3e777d04074956f949d0fbee2e33da20d45252dcc08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
