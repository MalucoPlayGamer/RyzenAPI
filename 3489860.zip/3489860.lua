-- Lua provided by RyzenAPI
-- Game: AppID 3489860

-- MAIN APPLICATION
addappid(3489860)
-- Game: addappid(3489860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489861, 1, "d8b530b4083bd62077d9c3e777d04074956f949d0fbee2e33da20d45252dcc08")
