-- Lua provided by RyzenAPI
-- Game: addappid(32420)

-- MAIN APPLICATION
addappid(32420)

-- MAIN APP DEPOTS / PACKAGES
addappid(32421, 1, "a5e7b7f88907d46970d3bc66de5adcc8f61f53e4a274dd54af416a90bfcaaea6")
