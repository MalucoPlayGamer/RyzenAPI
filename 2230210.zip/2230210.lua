-- Lua provided by RyzenAPI
-- Game: Game: Hentai Ojou

-- MAIN APPLICATION
addappid(2230210)
-- Game: addappid(2230210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230211, 1, "6963390e4c66ca5c0453b1b5f626d145ff382b635bcbcf77004bfb7fe849c5f9")
