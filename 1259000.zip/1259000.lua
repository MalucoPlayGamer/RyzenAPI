-- Lua provided by RyzenAPI
-- Game: Game: Damascus

-- MAIN APPLICATION
addappid(1259000)
-- Game: addappid(1259000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259001, 1, "eafe60ef1aad564c830abf85eab20a572eb213138f1c07cec43b1d43308b9965")
