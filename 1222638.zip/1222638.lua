-- Lua provided by RyzenAPI
-- Game: RetroArch - EasyRPG

-- MAIN APPLICATION
addappid(1222638)
-- Game: addappid(1222638)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222638,0,"d5310bf9d3cd64eef4b9ec8872e100ac5ff1cf3d8f1228444dc5172081426b97")
addappid(1790110,0,"ce5acb07afd69e18b258e0a8b61d8f5d81ac996f342ea0c34be652f6de4adb05")
addappid(1790111,0,"f15bea4f82c90879667f4044cc79c94911a6f39460be4e5f020cc672d6c469b0")
