-- Lua provided by RyzenAPI
-- Game: 918170

-- MAIN APPLICATION
addappid(918170)
-- Game: addappid(918170)

-- MAIN APP DEPOTS / PACKAGES
addappid(918171, 1, "00baaf98f15a12cc86cdd164f95ab6997db2979d2554c83713a7f5611433653d")
