-- Lua provided by RyzenAPI
-- Game: Curiosity

-- MAIN APPLICATION
addappid(918170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(918171, 1, "00baaf98f15a12cc86cdd164f95ab6997db2979d2554c83713a7f5611433653d")

