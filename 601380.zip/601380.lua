-- Lua provided by RyzenAPI
-- Game: AppID 601380

-- MAIN APPLICATION
addappid(601380)
-- Game: addappid(601380)

-- MAIN APP DEPOTS / PACKAGES
addappid(601381, 1, "e723d5306b373c02f02a6c2d1e251158a11e2cf9a776f36aa8db25e2964ebab2")
