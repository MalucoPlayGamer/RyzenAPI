-- Lua provided by RyzenAPI
-- Game: 555440

-- MAIN APPLICATION
addappid(555440)
-- Game: addappid(555440)

-- MAIN APP DEPOTS / PACKAGES
addappid(555441, 1, "f61436a9e031da3683880eb427897fbedf798806e8b42b0f0f3a42d2806c9c1e")
