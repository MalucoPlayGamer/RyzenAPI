-- Lua provided by RyzenAPI
-- Game: AppID 555440

-- MAIN APPLICATION
addappid(555440)
addappid(872770)
addappid(915350)
addappid(920440)
addappid(1024660)
addappid(1083130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(555441, 1, "f61436a9e031da3683880eb427897fbedf798806e8b42b0f0f3a42d2806c9c1e")

