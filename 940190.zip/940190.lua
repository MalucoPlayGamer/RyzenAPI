-- Lua provided by RyzenAPI
-- Game: Game: Chuckie Egg 2017

-- MAIN APPLICATION
addappid(940190)
-- Game: addappid(940190)

-- MAIN APP DEPOTS / PACKAGES
addappid(940191, 1, "7344f9332f74ad3b2c0f8d389d0bf31563400983b7547538fd640aba088b761d")
