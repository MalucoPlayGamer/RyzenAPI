-- Lua provided by RyzenAPI
-- Game: Woodle Tree Adventures

-- MAIN APPLICATION
addappid(299460)

-- MAIN APP DEPOTS / PACKAGES
addappid(299461, 1, "b06c5999156282cf82600f8b242f9efea5956e2c44c996f76af3bfcbad8fb127")
addappid(299462, 1, "4303f2addfb1c28c23423af792695709cee49ee95aa2aa0143522494fceaac26")
addappid(299463, 1, "887fadb64b52a90d4480f51cd34b77596826cfe8a34d05e3ec7a178dd217edd1")
addappid(450130, 0, "b64aeb1da7c277c7ccbd55313a18cb5c3de770ac55bb8b065c86086bd22e0ad2")
