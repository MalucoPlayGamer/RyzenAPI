-- Lua provided by SkyAPI 
-- Game: Atex Brawl
addappid(852530)
addappid(852531, 1, "0723a2fbf5cc0529e1d1e942f44fd4a5dee44f393e8b28493816d84e2a51ae3e")
