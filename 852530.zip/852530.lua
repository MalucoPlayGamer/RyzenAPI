-- Lua provided by RyzenAPI
-- Game: addappid(852530)

-- MAIN APPLICATION
addappid(852530)

-- MAIN APP DEPOTS / PACKAGES
addappid(852531, 1, "0723a2fbf5cc0529e1d1e942f44fd4a5dee44f393e8b28493816d84e2a51ae3e")
