-- Lua provided by RyzenAPI
-- Game: addappid(765570)

-- MAIN APPLICATION
addappid(765570)

-- MAIN APP DEPOTS / PACKAGES
addappid(765571, 1, "1245abda75fe9ae24782dbc348b4a6b8c13b33b727b6bb18e7675dd5ca10565e")
