-- Lua provided by RyzenAPI
-- Game: AppID 765570

-- MAIN APPLICATION
addappid(765570)

-- MAIN APP DEPOTS / PACKAGES
addappid(765571, 1, "1245abda75fe9ae24782dbc348b4a6b8c13b33b727b6bb18e7675dd5ca10565e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
