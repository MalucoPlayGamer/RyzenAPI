-- 2644080's Lua and Manifest Created by Hubcap Manifest
-- Fishtronomy
-- Created: August 03, 2026 at 22:42:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2644080, 1, "a6f5ef70f955ab58a09d43c841ef4ce38f8375886888935da39dc8bba12f1dfe") -- Fishtronomy
-- MAIN APP DEPOTS
addappid(2644081, 1, "6880290b795271b5c90542bc6e519e56aa46c0a0d8e873fe927dff8952d7c5ed") -- Depot 2644081
setManifestid(2644081, "7210728094985368003", 147614416)