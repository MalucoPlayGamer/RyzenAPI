-- Lua provided by RyzenAPI
-- Game: Fishtronomy

-- MAIN APP DEPOTS / PACKAGES
addappid(2644080, 1, "a6f5ef70f955ab58a09d43c841ef4ce38f8375886888935da39dc8bba12f1dfe") -- Fishtronomy
addappid(2644081, 1, "6880290b795271b5c90542bc6e519e56aa46c0a0d8e873fe927dff8952d7c5ed") -- Depot 2644081

