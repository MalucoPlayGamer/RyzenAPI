-- Lua provided by SkyAPI 
-- Game: AppID 2604740
addappid(2604740)
addappid(2604741, 1, "c7b9c17a0329f604b8e4e47921a61c8383ca4f526623f3bc7bbfd1abab7cf64e")
