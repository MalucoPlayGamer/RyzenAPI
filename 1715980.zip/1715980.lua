-- Lua provided by RyzenAPI
-- Game: Bail or Jail(OBAKEIDORO!)

-- MAIN APPLICATION
addappid(1715980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715981, 1, "da55df3736fb8684723172988b5a6ea0d63ac9a6071f5f97569cbc8e85ca5eb5")
