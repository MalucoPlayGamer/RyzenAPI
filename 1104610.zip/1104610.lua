-- Lua provided by RyzenAPI
-- Game: Touhou Fan-made Virtual Autography

-- MAIN APPLICATION
addappid(1104610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104611, 1, "dcb34c6b12f381a73044d6817a285395a19598d96ea58f32db4491c2b463cbec")

