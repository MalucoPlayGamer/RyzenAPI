-- Lua provided by RyzenAPI
-- Game: Dark Eden Origin

-- MAIN APPLICATION
addappid(658510)

-- MAIN APP DEPOTS / PACKAGES
addappid(658511, 1, "5e487bbf850ae679694ccc92ef32e9d1f4ad72cc647c353634af3906a3b11424")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
