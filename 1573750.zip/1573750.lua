-- Lua provided by RyzenAPI
-- Game: 1573750

-- MAIN APPLICATION
addappid(1573750)
-- Game: addappid(1573750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573751, 1, "a0d4b62b57f67f4da04b173f3d236461e35d961cdd7560a99ce783bf31bbefce")
