-- Lua provided by RyzenAPI
-- Game: 981340

-- MAIN APPLICATION
addappid(981340)
-- Game: addappid(981340)

-- MAIN APP DEPOTS / PACKAGES
addappid(981341, 1, "2272a7514573b4e06c3d216dfcf1fa2a872bdb9aec98d5aa99364c5621a101a9")
