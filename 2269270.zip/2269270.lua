-- Lua provided by RyzenAPI
-- Game: Desolation

-- MAIN APPLICATION
addappid(2269270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2269271, 1, "edf95ddde7435e08b3b7a6c8495dfe010b5188d909a9f0f9b740f6f65e0447c6")

