-- Lua provided by RyzenAPI
-- Game: Game: Desolation

-- MAIN APPLICATION
addappid(2269270)
-- Game: addappid(2269270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269271, 1, "edf95ddde7435e08b3b7a6c8495dfe010b5188d909a9f0f9b740f6f65e0447c6")
