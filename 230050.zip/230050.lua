-- Lua provided by RyzenAPI
-- Game: DLC Quest

-- MAIN APPLICATION
addappid(230050)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(230051, 1, "50dee201bc1ab15631892ab706683ccc7b32002ce04728e16bc3e14f31affce8")
addappid(230052, 1, "98c762f73b9d57832c69d6276aab5d4d783893b0e23cf730c75e09bd6841c8f5")
