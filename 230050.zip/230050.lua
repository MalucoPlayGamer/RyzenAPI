-- Lua provided by RyzenAPI
-- Game: AppID 230050

-- MAIN APPLICATION
addappid(230050)
-- Game: addappid(230050)

-- MAIN APP DEPOTS / PACKAGES
addappid(230051, 1, "50dee201bc1ab15631892ab706683ccc7b32002ce04728e16bc3e14f31affce8")
addappid(230052, 1, "98c762f73b9d57832c69d6276aab5d4d783893b0e23cf730c75e09bd6841c8f5")
