-- Lua provided by RyzenAPI
-- Game: Total War: WARHAMMER III Playtest

-- MAIN APPLICATION
addappid(2005120)
-- Game: addappid(2005120)

-- MAIN APP DEPOTS / PACKAGES
addappid(372531,0,"85fd9e7e0a0f07b17dcb14263b94e436306270f02200d7a6669de0ba70602504")
