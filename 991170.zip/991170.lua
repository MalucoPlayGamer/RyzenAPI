-- Lua provided by RyzenAPI
-- Game: AppID 991170

-- MAIN APPLICATION
addappid(991170)

-- MAIN APP DEPOTS / PACKAGES
addappid(991171, 1, "4ee4065953e41adc175e0e877c6be766730aaf3a3606ae4d7d29d6139d351336")
addappid(1424060, 0, "3d2dfafe236dd736a3de689b896016bcb3d47c4241d72ca54c4e0e1f3aa79bb0")
addappid(1554910, 0, "8b1427199ef7b033f88bb6d3f4bfa862668fa62f990c711161b3926db33a730b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
