-- Lua provided by RyzenAPI
-- Game: Barn Finders

-- MAIN APPLICATION
addappid(991170)
-- Game: addappid(991170)

-- MAIN APP DEPOTS / PACKAGES
addappid(991171, 1, "4ee4065953e41adc175e0e877c6be766730aaf3a3606ae4d7d29d6139d351336")
addappid(1424060, 0, "3d2dfafe236dd736a3de689b896016bcb3d47c4241d72ca54c4e0e1f3aa79bb0")
addappid(1554910, 0, "8b1427199ef7b033f88bb6d3f4bfa862668fa62f990c711161b3926db33a730b")
