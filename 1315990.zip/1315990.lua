-- Lua provided by RyzenAPI
-- Game: Blackstorm - Dedicated Server

-- MAIN APPLICATION
addappid(1315990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315991, 1, "43d85224e8400476d5e4197fac568f4b200342bee1d96a38e48ab92f249339d1")
