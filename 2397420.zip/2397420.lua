-- Lua provided by RyzenAPI
-- Game: Game: Hot Candy Land

-- MAIN APPLICATION
addappid(2397420)
-- Game: addappid(2397420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397421, 1, "46bccef97917ff4849df9d4c053a4f404f71b095a8b8b7092d4c95c31bd4f207")
addappid(2397422, 1, "0d42bedd3e809cef642be46a2647c11b13708d06b6105d7101fe078f5f78a907")
