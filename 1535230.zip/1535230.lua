-- Lua provided by SkyAPI 
-- Game: Elementite Demo
addappid(1535230)
addappid(1535231, 1, "a7bd2da24d49f1677bfafc0dd5575947aebd03993ce600ee87f80306df6a6ae9")
