-- Lua provided by RyzenAPI
-- Game: Lawgivers II

-- MAIN APPLICATION
addappid(1407180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407182,0,"37d832db8bea2b43cfaea7753226ee774e87420661eec39535b2c19b125b0db6")

