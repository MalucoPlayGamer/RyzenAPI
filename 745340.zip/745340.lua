-- Lua provided by RyzenAPI
-- Game: Super Meat Shooter

-- MAIN APPLICATION
addappid(745340)
addappid(761230)
addappid(761231)

-- MAIN APP DEPOTS / PACKAGES
addappid(745341, 1, "e9abb258c377d8fac6ec416ce833feac21a4cf3e1d50bfbf510cad434e29bfcf")

