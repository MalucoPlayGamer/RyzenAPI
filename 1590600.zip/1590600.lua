-- Lua provided by RyzenAPI
-- Game: OPPAI Academy Big, Bouncy, Booby Babes!

-- MAIN APPLICATION
addappid(1590600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1590601, 1, "b47f223ca8e1d6ab3321fd199e480a8a71928ea0ae354f1b09b5f49dfb2424f8")

