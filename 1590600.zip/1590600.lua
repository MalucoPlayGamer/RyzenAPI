-- Lua provided by RyzenAPI
-- Game: addappid(1590600)

-- MAIN APPLICATION
addappid(1590600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590601, 1, "b47f223ca8e1d6ab3321fd199e480a8a71928ea0ae354f1b09b5f49dfb2424f8")
