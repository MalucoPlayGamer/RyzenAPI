-- Lua provided by RyzenAPI
-- Game: addappid(386140)

-- MAIN APPLICATION
addappid(228985)
addappid(386140)
addappid(386141)
addappid(386142)
addappid(386143)
addappid(386146)

-- MAIN APP DEPOTS / PACKAGES
addappid(386144,0,"b6aa23266b1043e1dfc00cdcdf495ee756a5de6783c60b725acc20366bb6800c")
addappid(386145,0,"7c956e853ed31380a4834a4f69c693742dfef442dcd9d59fa08fa448af4dd000")
