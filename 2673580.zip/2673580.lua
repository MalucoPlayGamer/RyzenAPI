-- Lua provided by RyzenAPI
-- Game: Phenomena Embattled Demo

-- MAIN APPLICATION
addappid(2673580)
-- Game: addappid(2673580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673582,0,"626a1f301106a7b44300f763886b4814afc164221116d3bcdb04d89cd50a9fa5")
