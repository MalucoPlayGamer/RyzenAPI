-- Lua provided by RyzenAPI
-- Game: Skullnight

-- MAIN APPLICATION
addappid(1905350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905351, 1, "690537f1f76c960f94473f70c739aacf077fe21059f992861c59695aa76f13bc")

