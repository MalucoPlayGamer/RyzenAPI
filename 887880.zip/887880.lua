-- Lua provided by RyzenAPI
-- Game: O.C.D. - On Completeness & Dissonance

-- MAIN APPLICATION
addappid(887880)

-- MAIN APP DEPOTS / PACKAGES
addappid(887881, 1, "5cfa24daa0ae08b43350a718469122641fd67e30df4156a463205a0f5bcd434f")
addappid(894150, 0, "37044eec4005f62049a8dee3c2305e1771472431dafa9356333e7bfd3ca9a7f5")

