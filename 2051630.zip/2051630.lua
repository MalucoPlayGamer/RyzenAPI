-- Lua provided by SkyAPI 
-- Game: AppID 2051630
addappid(2051630)
addappid(2051631, 1, "918b1e701f711f4c479df9c3ad11c45e987b3b00c82a53330d5204cec1dfb2b1")
