-- 3459880's Lua and Manifest Created by Hubcap Manifest
-- FantasyJourney
-- Created: July 31, 2026 at 23:59:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3459880) -- FantasyJourney
-- MAIN APP DEPOTS
addappid(3459881, 1, "37033ec64da43c9acb4b67804daf8785717abdb9469335da88a7a14154b218d6") -- Depot 3459881
setManifestid(3459881, "1546194656177950529", 7946207942)