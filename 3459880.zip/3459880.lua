-- Lua provided by RyzenAPI
-- Game: FantasyJourney

-- MAIN APPLICATION
addappid(3459880) -- FantasyJourney

-- MAIN APP DEPOTS / PACKAGES
addappid(3459881, 1, "37033ec64da43c9acb4b67804daf8785717abdb9469335da88a7a14154b218d6") -- Depot 3459881

