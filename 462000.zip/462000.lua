-- Lua provided by SkyAPI 
-- Game: AppID 462000
addappid(462000)
addappid(462001, 1, "57bfe9f2a3727f08291198ecc1285b01ec40dc26d16f5b125d87f82be6663ede")
