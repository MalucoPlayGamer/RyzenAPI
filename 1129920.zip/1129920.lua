-- Lua provided by RyzenAPI
-- Game: Tales From Off-Peak City Vol. 1

-- MAIN APPLICATION
addappid(1129920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129921, 1, "3a41f1066bb4c9b8e1f3c6b65e919141c35baeb44facbf92748ab71cd6aaabe0")

