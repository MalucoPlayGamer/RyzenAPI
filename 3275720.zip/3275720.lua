-- Lua provided by RyzenAPI
-- Game: Drinking Song

-- MAIN APPLICATION
addappid(3275720)
-- Game: addappid(3275720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3275721, 1, "578adcca5abcbd68f09f0274fb8f604326dcb5bfed93a0b8f8038b881910d9f5")
