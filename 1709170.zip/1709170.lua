-- Lua provided by RyzenAPI
-- Game: 1709170

-- MAIN APPLICATION
addappid(1709170)
-- Game: addappid(1709170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709171, 1, "86487c8b59baf7be6997f32f9daaf6bb6328b445144c9b9fbe93a870c5638e2a")
addappid(1709172, 1, "dc68df5cc61219babcf4521f56cc62013b18beef298f257eb3bad986d5b65800")
addappid(1709173, 1, "ff685bcae1f58ed7af4fce54fab2f3bbd6453a3d1a4f4fd3111c5e364cbff598")
addappid(1709174, 1, "47c524f50c1a4e4cb207b5e3989ec90bb9838f11702e848bc84de648c05a2387")
