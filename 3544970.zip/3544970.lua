-- Lua provided by RyzenAPI
-- Game: addappid(3544970)

-- MAIN APPLICATION
addappid(3544970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3544971, 1, "d72dc273fe4a6d5501c169fd1229dd780d69a3924d701174719bd9a44a6d3fad")
