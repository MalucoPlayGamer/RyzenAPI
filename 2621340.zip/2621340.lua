-- Lua provided by RyzenAPI
-- Game: 2621340

-- MAIN APPLICATION
addappid(2621340)
-- Game: addappid(2621340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621341, 1, "1f7a99ba884bde6ab4f7e05f2970af7688b6a19cc251b9a28cf0e6a5bf5bc56b")
