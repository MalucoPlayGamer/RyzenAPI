-- Lua provided by RyzenAPI
-- Game: Arkan: The dog adventurer

-- MAIN APPLICATION
addappid(1157040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1157041, 1, "2bf73a3c829ad0136079d645fb049a7f82371d4663c9355ca5abded5a9fa9a2b")
