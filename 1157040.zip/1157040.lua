-- Lua provided by SkyAPI 
-- Game: AppID 1157040
addappid(1157040)
addappid(1157041, 1, "2bf73a3c829ad0136079d645fb049a7f82371d4663c9355ca5abded5a9fa9a2b")
