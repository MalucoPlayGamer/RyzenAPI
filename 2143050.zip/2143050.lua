-- Lua provided by RyzenAPI
-- Game: Game: Red Line

-- MAIN APPLICATION
addappid(2143050)
-- Game: addappid(2143050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143051, 1, "006d5e324d2494285a556f0a57d9d61469d47328bcafeb8a2af41e1d5189f2ff")
