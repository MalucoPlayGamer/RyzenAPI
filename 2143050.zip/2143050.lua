-- Lua provided by SkyAPI 
-- Game: Red Line
addappid(2143050)
addappid(2143051, 1, "006d5e324d2494285a556f0a57d9d61469d47328bcafeb8a2af41e1d5189f2ff")
