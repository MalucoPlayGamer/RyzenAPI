-- Lua provided by RyzenAPI
-- Game: Game: AppID 788270

-- MAIN APPLICATION
addappid(788270)
-- Game: addappid(788270)

-- MAIN APP DEPOTS / PACKAGES
addappid(788271, 1, "59923ed9782393e4afef3d2d5a4abc291d0dcd88e68dbc75b57a729f3851ba36")
