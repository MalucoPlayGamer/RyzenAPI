-- Lua provided by RyzenAPI
-- Game: Hello Neighbor

-- MAIN APP DEPOTS / PACKAGES
addappid(521890,0,"a435c6dd7fc5ad1c4fda215293efd2efd71f9c63e48e9eb0c96b9de022379587")
addappid(521895,0,"dfdc4fe90929b42105c21652ff271204a22e73f3e8dc82bb776c33551a460cf6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
