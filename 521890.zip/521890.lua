-- Lua provided by RyzenAPI
-- Game: Hello Neighbor

-- MAIN APP DEPOTS / PACKAGES
addappid(521890,0,"a435c6dd7fc5ad1c4fda215293efd2efd71f9c63e48e9eb0c96b9de022379587")
addappid(521895,0,"dfdc4fe90929b42105c21652ff271204a22e73f3e8dc82bb776c33551a460cf6")
-- Game: addappid(521890,0,"a435c6dd7fc5ad1c4fda215293efd2efd71f9c63e48e9eb0c96b9de022379587")
