-- Lua provided by RyzenAPI
-- Game: Kingdom Eighties Demo

-- MAIN APPLICATION
addappid(2162940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162941, 1, "9b37e84e54065939501c6bd6578142ed0ed99ad67faa6b74f4ba4b527c7a4c06")

