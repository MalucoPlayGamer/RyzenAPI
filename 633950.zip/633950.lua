-- Lua provided by RyzenAPI
-- Game: Fall of Light: Darkest Edition

-- MAIN APPLICATION
addappid(633950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(633951, 1, "33a6f329a004622c1e7f865460408184e5c3d80bb4e6e326c07d400d05f83aa9")
addappid(633952, 1, "dc76b71bbfe43adf34428fc954aa983f135954ca42a0e985ed20bdd8da79ae20")
