-- Lua provided by RyzenAPI
-- Game: Game: AppID 633950

-- MAIN APPLICATION
addappid(633950)
-- Game: addappid(633950)

-- MAIN APP DEPOTS / PACKAGES
addappid(633951, 1, "33a6f329a004622c1e7f865460408184e5c3d80bb4e6e326c07d400d05f83aa9")
addappid(633952, 1, "dc76b71bbfe43adf34428fc954aa983f135954ca42a0e985ed20bdd8da79ae20")
