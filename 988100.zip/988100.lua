-- Lua provided by RyzenAPI
-- Game: Super Phantom Cat

-- MAIN APPLICATION
addappid(988100)

-- MAIN APP DEPOTS / PACKAGES
addappid(988101, 1, "a18840607f68fbf86ef87aadf5e1284dcc7f5bf04d603cb24c3ff39d9e813ce9")
addappid(1048340, 0, "7a32f8550606484b0c391df3943a7feb7042aba636d9d720b659832a7740b157")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
