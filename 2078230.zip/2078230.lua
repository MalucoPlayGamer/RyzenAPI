-- Lua provided by RyzenAPI
-- Game: addappid(2078230)

-- MAIN APPLICATION
addappid(2078230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078232,0,"a7eb0d5dab2bf1ac43efa6c5b2174fad39792483606b806c42be4dfccdbddaaa")
