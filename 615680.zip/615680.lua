-- Lua provided by SkyAPI 
-- Game: Vagrant Hearts Zero
addappid(615680)
addappid(615681, 1, "c625765a783248c3b98a1898d902df56cfb478cd5eb354d1de4077a505f835c4")
