-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 17

-- MAIN APPLICATION
addappid(795630)

-- MAIN APP DEPOTS / PACKAGES
addappid(795631, 1, "d3dc3dc8d22d7471a7e172547dce280d35de7360a061c19b2783820cbea89f7f")
