-- Lua provided by RyzenAPI
-- Game: addappid(2870580)

-- MAIN APPLICATION
addappid(2870580)
addappid(4119790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870581, 1, "b06d96787bf753259a791ca5ad5dfe001ec6fd828585000d036ad6c4fb6a1ed4")
