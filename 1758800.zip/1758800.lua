-- Lua provided by RyzenAPI
-- Game: addappid(1758800)

-- MAIN APPLICATION
addappid(1758800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758801, 1, "caff9b2359df1dbe009e6dc244aeac0f8108cf253db50966078b332fa330a5ae")
