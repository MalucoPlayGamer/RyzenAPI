-- Lua provided by RyzenAPI
-- Game: Marfusha:Sentinel Girls

-- MAIN APPLICATION
addappid(1456820)
-- Game: addappid(1456820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456821, 1, "f0839f5ae8a1d8ae984464c4e6070ec72da6bb0a01b4d67c3930a9dab240db13")
addappid(1456822, 1, "3c9cb8ab842002071ad9376fb351f9f5370b2dda73294bf0687607ddb14fc85b")
addappid(1456823, 1, "319a6fba97b72514b79a55d7ce4a788f5f6bdfa08fb97768f45acbe5dc991402")
addappid(1512080, 0, "e9f6028233437a7743c327a099cf17162a93b23bb265ff098b3230e8ba32317e")
