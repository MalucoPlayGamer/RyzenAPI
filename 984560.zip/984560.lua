-- Lua provided by RyzenAPI
-- Game: addappid(984560)

-- MAIN APPLICATION
addappid(984560)

-- MAIN APP DEPOTS / PACKAGES
addappid(984561, 1, "ce8f0e51e95273bba00585c5c914ece8a74500f6fbda69093fe1d7557e60004a")
addappid(984562, 1, "f16335c7fa63ddbe62b829194bd0c7d28e6e92e4b458fc36d053387624ea703d")
