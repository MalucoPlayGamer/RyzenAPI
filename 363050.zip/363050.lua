-- Lua provided by RyzenAPI
-- Game: Let's Explore the Airport (Junior Field Trips)

-- MAIN APPLICATION
addappid(363050)
-- Game: addappid(363050)

-- MAIN APP DEPOTS / PACKAGES
addappid(363051, 1, "5f6137a792a7478db323a30b0a2af836e6ca44d388adfcd461d03dc264f12ddd")
addappid(363052, 1, "c41eacbf95ad75732f377a528ba44b8f6e7054ebeb4f0877aafbffc2c3a5ebbf")
addappid(363053, 1, "412606ccd210d6cc5000cd438a8d5bf220a9062481a7af1ca3dd84cbf51244b6")
addappid(363054, 1, "8991ffb35ba5f77e46d760b283492e7b16731e1760f5156664c30d2716e87aa7")
addappid(363055, 1, "66425649779601c9b2c9a49b9e4cd97b8d6ca30db2c97da204213b7b7a84c926")
addappid(363056, 1, "5e2dbf0fac859192bc29331169020e9e7f396beca3ea72b820c9663242ed013d")
addappid(363057, 1, "04ee55f19398915f687dbc226a502714eaced04ed7d647221f6616c24c97fc5f")
