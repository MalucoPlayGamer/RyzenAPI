-- Lua provided by RyzenAPI
-- Game: addappid(2358600)

-- MAIN APPLICATION
addappid(2358600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358601, 1, "8e27f0d052d5ad721acbfd67517592acf6e825d4858064d79e6dc643e108aa40")
