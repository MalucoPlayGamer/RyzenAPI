-- Lua provided by RyzenAPI
-- Game: 627310

-- MAIN APPLICATION
addappid(627310)
-- Game: addappid(627310)

-- MAIN APP DEPOTS / PACKAGES
addappid(627311, 1, "d0ec2b6b96f1be4338a3772177b36b2873c458e8c5f59c902db2beb35735eb84")
addappid(627319, 1, "11a62dc09ca7cec270759f519b7fade37b9c97b0e10caf341d5f40d0a2a49863")
