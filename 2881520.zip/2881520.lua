-- Lua provided by RyzenAPI
-- Game: River City Saga: Three Kingdoms Next

-- MAIN APPLICATION
addappid(2881520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881521, 1, "2bfcdd5d13743e0588e20326971000bced299550c52f363b3b7c4882ad36d068")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
