-- Lua provided by RyzenAPI
-- Game: Game: River City Saga: Three Kingdoms Next

-- MAIN APPLICATION
addappid(2881520)
-- Game: addappid(2881520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881521, 1, "2bfcdd5d13743e0588e20326971000bced299550c52f363b3b7c4882ad36d068")
