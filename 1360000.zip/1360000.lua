-- Lua provided by RyzenAPI
-- Game: Game: AppID 1360000

-- MAIN APPLICATION
addappid(1360000)
-- Game: addappid(1360000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360001, 1, "75516c3077794330ba3a9c5d117ae0a3e26afd8137ade1df24743136af5712d3")
