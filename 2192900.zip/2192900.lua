-- Lua provided by RyzenAPI
-- Game: Game: Knock'Em Out

-- MAIN APPLICATION
addappid(2192900)
-- Game: addappid(2192900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192901, 1, "0c1840ea3034ffc95b8876adba1d2abbc0276437392add138754347775fd121b")
