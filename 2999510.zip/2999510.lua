-- Lua provided by RyzenAPI
-- Game: Care Bears: To The Rescue

-- MAIN APPLICATION
addappid(2999510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999511, 1, "c932b5cad3dbddf2bafac130ed39a725608cdd7880cc1937e4d1ce68a1a51238")

