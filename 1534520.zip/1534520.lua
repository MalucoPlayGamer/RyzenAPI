-- Lua provided by RyzenAPI
-- Game: Game: STRAY KITTEN

-- MAIN APPLICATION
addappid(1534520)
-- Game: addappid(1534520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534521, 1, "2df01bd1f60d9ebbac38348b030c48cb2f1c2859d51fbe2550722176266b0078")
