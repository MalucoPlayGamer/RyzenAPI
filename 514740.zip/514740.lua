-- Lua provided by RyzenAPI
-- Game: Game: Final Cut: Death on the Silver Screen Collector's Edition

-- MAIN APPLICATION
addappid(514740)
-- Game: addappid(514740)

-- MAIN APP DEPOTS / PACKAGES
addappid(514741, 1, "4902fbd6ed9936f2e9a61973b03cc12a676fcf5d1578194ae218da621ee4a9ad")
