-- Lua provided by RyzenAPI
-- Game: My Hotel: Echoes of the Past

-- MAIN APPLICATION
addappid(2080210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080211, 1, "d4e0e4321a32e0e08bd7dd9cd5ae6e253fab80ffc5e2eff9a8c303218440ff07")

