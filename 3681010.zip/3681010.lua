-- Lua provided by RyzenAPI
-- Game: 3681010

-- MAIN APPLICATION
addappid(3681010)
addappid(4003880)
addappid(4003890)
addappid(4003900)
addappid(4003910)
addappid(4003920)
addappid(4003930)
addappid(4003940)
addappid(4232000)
addappid(4232020)
addappid(4232030)
-- Game: addappid(3681010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3681011, 1, "1c16eb875f0bd40521cc0ddb2ff4eb5772f0b1976252122abc5f9a09ddaaf995")
addappid(3681013, 1, "b97a4048032dc27c3cf1c6887e6069b0f0d51da2c352c671278b00eb4423de35")
