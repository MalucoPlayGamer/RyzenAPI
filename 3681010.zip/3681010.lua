-- Lua provided by RyzenAPI
-- Game: Nioh 3

-- MAIN APPLICATION
addappid(3681010)
addappid(4003880)
addappid(4003890)
addappid(4003900)
addappid(4003910)
addappid(4003920)
addappid(4003930)
addappid(4003940)
addappid(4003950)
addappid(4232000)
addappid(4232020)
addappid(4232030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3681011,0,"1c16eb875f0bd40521cc0ddb2ff4eb5772f0b1976252122abc5f9a09ddaaf995")
addappid(3681012,0,"b7bbd78bac448c4d49e1373da25413b0d4cd06a418cd429a4d89dc9da6a9bfe8")
addappid(3681013,0,"b97a4048032dc27c3cf1c6887e6069b0f0d51da2c352c671278b00eb4423de35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
