-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 5 prequel

-- MAIN APPLICATION
addappid(1545290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1545291, 1, "542bc68b0494dabda78b6bfeec61dec775ed50fb1bf84efd95f5f67f297432c0")

