-- Lua provided by RyzenAPI
-- Game: addappid(1545290)

-- MAIN APPLICATION
addappid(1545290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545291, 1, "542bc68b0494dabda78b6bfeec61dec775ed50fb1bf84efd95f5f67f297432c0")
