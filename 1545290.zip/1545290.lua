-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 5 prequel

-- MAIN APPLICATION
addappid(1545290)
-- Game: addappid(1545290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545291, 1, "542bc68b0494dabda78b6bfeec61dec775ed50fb1bf84efd95f5f67f297432c0")
