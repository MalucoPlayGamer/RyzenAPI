-- Lua provided by SkyAPI 
-- Game: Black Mirror
addappid(581300)
addappid(581301, 1, "727f2172308315838b2ff74914e28305f61f4fc0b65fef0a2267d9fa0370c81b")
addappid(581302, 1, "080309e8f2201e1b0e8644b578fbcf70af3adbaa84112462d4637b4afe203d68")
addappid(755700)
