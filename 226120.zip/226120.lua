-- Lua provided by RyzenAPI
-- Game: Weird Worlds: Return to Infinite Space

-- MAIN APPLICATION
addappid(226120)

-- MAIN APP DEPOTS / PACKAGES
addappid(226121, 1, "897650d3b0dac0833f7a480d1157903f5271a5562a64e772f7f9da015b16fd3d")
addappid(226122, 1, "6704254232a4769df0f3b962391ba0468ff411f1f3ebb02e116529d58fa42003")
addappid(226123, 1, "6d45d3d392ff646b929f917875a7ec512dd1cc7d24ac8c2ae81a0d156bb56331")

