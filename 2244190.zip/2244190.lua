-- Lua provided by RyzenAPI
-- Game: Game: AppID 2244190

-- MAIN APPLICATION
addappid(2244190)
-- Game: addappid(2244190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244191, 1, "45e57dd34826b08fcfd852afbe7309804906dd53d54c4330fdfacef4548896c7")
