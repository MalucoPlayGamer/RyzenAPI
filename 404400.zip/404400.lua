-- Lua provided by RyzenAPI
-- Game: 404400

-- MAIN APPLICATION
addappid(404400)
addappid(404401)

-- MAIN APP DEPOTS / PACKAGES
addappid(404402,0,"af4d208e6d099b4bd183a95a5810574e21a435dd0bb467c7bed0ee242895595f")
