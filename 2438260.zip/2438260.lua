-- Lua provided by RyzenAPI
-- Game: addappid(2438260)

-- MAIN APPLICATION
addappid(2438260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438262,0,"600390a61ffe67a207ee8cabca4adc32500abd97e0d8c8dfe8ea5d781caaafbd")
