-- Lua provided by SkyAPI 
-- Game: Dummy Dungeon
addappid(1891030)
addappid(1891031, 1, "fc4008b2c41c435682783b041bc5933df95967b05897bc0af6487d665f4817eb")
