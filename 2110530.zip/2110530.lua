-- Lua provided by RyzenAPI
-- Game: 2110530

-- MAIN APPLICATION
addappid(2110530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110530,0,"717b19a80ea4f75ecd817d7e5d7d958f9fa3e89918ef65f4dc97d0a01fae2f88")

