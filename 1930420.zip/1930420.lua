-- Lua provided by RyzenAPI
-- Game: Game: 狂人游戏：中国精神病人

-- MAIN APPLICATION
addappid(1930420)
-- Game: addappid(1930420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930421, 1, "26e10e25ac4868fbace3d107de6088433f64f49a43e269587831a154221d9613")
