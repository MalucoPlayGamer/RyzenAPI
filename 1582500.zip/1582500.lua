-- Lua provided by RyzenAPI
-- Game: Purple War

-- MAIN APPLICATION
addappid(1582500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582501, 1, "29ffaf35e8866b644e3ec13f732b3e58a116981c0acd83840ee448d005e1eed7")
addappid(2315850, 0, "026ccf8ac9c62bc000d4f3da0ca9e9009e9d8d9d3d52422d8defeb2ac1918025")

