-- Lua provided by RyzenAPI
-- Game: Game: AppID 438180

-- MAIN APPLICATION
addappid(438180)
-- Game: addappid(438180)

-- MAIN APP DEPOTS / PACKAGES
addappid(438181, 1, "f1f24ab72c74d86e2a18d4905b102031459d47a449dc2f67fc1b3f65abda9fef")
