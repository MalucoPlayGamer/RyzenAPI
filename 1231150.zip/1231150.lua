-- Lua provided by RyzenAPI
-- Game: 1231150

-- MAIN APPLICATION
addappid(1231150)
-- Game: addappid(1231150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231151, 1, "9e6d3010f8ba6dc185a669c16da6967ea41fffb3b8042e8a29f002e8658df617")
