-- Lua provided by RyzenAPI
-- Game: Treasure 'n Trio

-- MAIN APPLICATION
addappid(3214530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214531, 1, "31a18f524b1fdbb178986f0e087f5a5054866ac54335129eaffe3b58ac358a98")

