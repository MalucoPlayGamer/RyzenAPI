-- Lua provided by SkyAPI 
-- Game: AppID 2655680
addappid(2655680)
addappid(2655681, 1, "d4f80e5d2e8e7948144b80b99d7d2c970d63e699b9cde5a1d7971512c9655620")
