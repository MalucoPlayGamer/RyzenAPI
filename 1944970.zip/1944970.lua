-- Lua provided by RyzenAPI
-- Game: Hidden Farm Top-Down 3D

-- MAIN APPLICATION
addappid(1944970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944971, 1, "e0393f99d5d7b670cefe5988d233386be267a31d220164e96392dc29890781d8")
