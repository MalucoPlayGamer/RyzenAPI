-- Lua provided by RyzenAPI 
-- Game: FATAL FRAME / PROJECT ZERO: Maiden of Black Water
addappid(1732190)
addappid(1732191, 1, "41fbca52fbea25bd47005f1c64a88877acf4621890040a4dd2f54ee07b05e8dd")
addappid(1751200, 0, "5ad283afb5d2525d5f7bf5c1c95ad9847aa9be16a9df4f98015ef0adc76b81e5")
addappid(1751201, 0, "b89827dae7308c51c72ff8c69f724f1db76dfefae10b759f846106bb90446bb7")
addappid(1751202)
addappid(1751203, 0, "4adafabbc0acd89e419fa3d001b3e5145f9c1610b20ea41c589f71c86630359f")
addappid(1751204, 0, "07ff8fbe297d5350d7cf72088d7c4363bc7f39f8039601e30a222ab5548c8129")
