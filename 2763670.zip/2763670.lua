-- Lua provided by RyzenAPI
-- Game: Arctic Eggs

-- MAIN APPLICATION
addappid(2763670)
-- Game: addappid(2763670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763671, 1, "334609a04e348bc9288fcbe62b64f9e81f5f37202436e25bda9cf458151e3eeb")
addappid(2763672, 1, "14b0ff4e177b80f2818529365dfc67eea74ad7837d7b692c841265fa5ab53290")
addappid(2763674, 1, "f31c3585e3cfb6aad7fc68e5861bf96cfbc080083054a9ded9bce4407ca661af")
