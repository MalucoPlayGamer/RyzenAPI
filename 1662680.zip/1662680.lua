-- Lua provided by SkyAPI 
-- Game: UROS: A Trip Through Shadows
addappid(1662680)
addappid(1662681, 1, "bf5eee50a3e2959591da6e0e967bf50ca5e8b14ec5bb94b973318b57756fbe59")
