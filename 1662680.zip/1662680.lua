-- Lua provided by RyzenAPI
-- Game: Game: UROS: A Trip Through Shadows

-- MAIN APPLICATION
addappid(1662680)
-- Game: addappid(1662680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662681, 1, "bf5eee50a3e2959591da6e0e967bf50ca5e8b14ec5bb94b973318b57756fbe59")
