-- Lua provided by RyzenAPI
-- Game: UROS: A Trip Through Shadows

-- MAIN APPLICATION
addappid(1662680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662681, 1, "bf5eee50a3e2959591da6e0e967bf50ca5e8b14ec5bb94b973318b57756fbe59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
