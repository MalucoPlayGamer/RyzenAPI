-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KCLE Airport

-- MAIN APPLICATION
addappid(3734640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3734640,0,"9fde90219519e8eca62429f2b13595596f59821d5e7853f61273d26c051b79ff")
