-- Lua provided by RyzenAPI
-- Game: Bouncing Duck Simulator

-- MAIN APPLICATION
addappid(696560)

-- MAIN APP DEPOTS / PACKAGES
addappid(696561, 1, "3e9820f7ad2e01b6878df2037e243767983c58a1183e4245997a6868d413fc7b")

