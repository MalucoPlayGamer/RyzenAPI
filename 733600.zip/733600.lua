-- Lua provided by RyzenAPI
-- Game: addappid(733600)

-- MAIN APPLICATION
addappid(733600)

-- MAIN APP DEPOTS / PACKAGES
addappid(733601, 1, "ed0ec3de5589dce6d2ae99af68f3dddc0379b0d9295ebd1ae24bc16e6253e2cc")
