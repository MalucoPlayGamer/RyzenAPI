-- Lua provided by RyzenAPI
-- Game: Stay away from zombies

-- MAIN APPLICATION
addappid(1922320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922321, 1, "d5de5d9614a9cdf2b5d40f448a9b691304b49fd24ee0bdb7aa2c0eff62de0426")
