-- Lua provided by RyzenAPI
-- Game: addappid(1396900)

-- MAIN APPLICATION
addappid(1396900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396901, 1, "00fa3f7188a92eeb2a465a894789b912cf504d49fe9be3234390313bebae6199")
