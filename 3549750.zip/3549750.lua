-- Lua provided by RyzenAPI
-- Game: 3549750

-- MAIN APPLICATION
addappid(3549750)
-- Game: addappid(3549750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549751, 1, "3905e2e8f3c1e13e60beddbc1d4473e5a28eca041ae9ee017dff3dfef357287d")
