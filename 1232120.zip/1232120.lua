-- Lua provided by RyzenAPI
-- Game: Aether Field

-- MAIN APPLICATION
addappid(1232120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232121, 1, "38bd9159fee9790a57842a0b6b27826254472962c634af1e1663581a0e5e31ba")

