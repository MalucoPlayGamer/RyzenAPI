-- Lua provided by RyzenAPI
-- Game: Damned

-- MAIN APPLICATION
addappid(251170)
-- Game: addappid(251170)

-- MAIN APP DEPOTS / PACKAGES
addappid(251171, 1, "16155b68227364a56839d09e3c66ba36318745c8f5d2b419db1f8317b90e452b")
