-- Lua provided by RyzenAPI
-- Game: Damned

-- MAIN APPLICATION
addappid(251170)

-- MAIN APP DEPOTS / PACKAGES
addappid(251171, 1, "16155b68227364a56839d09e3c66ba36318745c8f5d2b419db1f8317b90e452b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
