-- Lua provided by RyzenAPI
-- Game: Happy Claus Christmas Edition

-- MAIN APPLICATION
addappid(989300)

-- MAIN APP DEPOTS / PACKAGES
addappid(989301, 1, "3672373c4603f519f5aaa69b1c8815439300b6b90c8e702ddaf74a23807f686d")

