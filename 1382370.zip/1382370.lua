-- Lua provided by RyzenAPI
-- Game: AppID 1382370

-- MAIN APPLICATION
addappid(1382370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382371, 1, "886c08fbb6e9eaad33d8ca4984a68adfabd7cddb3fcf6b0ba65b9f689dd9cf22")
