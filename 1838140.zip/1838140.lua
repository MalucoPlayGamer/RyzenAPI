-- Lua provided by RyzenAPI
-- Game: Snowman Adventure

-- MAIN APPLICATION
addappid(1838140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1838141, 1, "4ed5cb982f4b28a12621a4440f1fafd2c8d693b9e8dc443107d71431396754e3")

