-- Lua provided by RyzenAPI
-- Game: Snowman Adventure

-- MAIN APPLICATION
addappid(1838140)
-- Game: addappid(1838140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838141, 1, "4ed5cb982f4b28a12621a4440f1fafd2c8d693b9e8dc443107d71431396754e3")
