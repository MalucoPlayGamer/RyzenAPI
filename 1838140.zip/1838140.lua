-- Lua provided by SkyAPI 
-- Game: Snowman Adventure
addappid(1838140)
addappid(1838141, 1, "4ed5cb982f4b28a12621a4440f1fafd2c8d693b9e8dc443107d71431396754e3")
