-- Lua provided by RyzenAPI
-- Game: A Castle Full of Cats: Bag of Treats

-- MAIN APPLICATION
addappid(2136020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136020,0,"31b3231281d000c2aebd90ee503091b4c20375da966e079492f12837bd682623")
