-- Lua provided by RyzenAPI
-- Game: Game: Prison Life 2

-- MAIN APPLICATION
addappid(2125160)
-- Game: addappid(2125160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125161, 1, "245bc07100842ee5b556c9e2fdc15a5440537c3222d28f5bde555562eab65aa5")
