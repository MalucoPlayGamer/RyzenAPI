-- Lua provided by RyzenAPI
-- Game: Game: Sneaky Sneaky

-- MAIN APPLICATION
addappid(259410)
addappid(333320)
-- Game: addappid(259410)

-- MAIN APP DEPOTS / PACKAGES
addappid(259411, 1, "5ad81cc406e28fbc5d018f9088e599bec7ba63d2746f6d8fdfab7b319ab91062")
addappid(259412, 1, "e24c31065a4cf0f241378e4af776268c9bad0d9b7ea8d9dd539abe3f66893b03")
