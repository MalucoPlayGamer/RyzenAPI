-- Lua provided by RyzenAPI
-- Game: Sneaky Sneaky

-- MAIN APPLICATION
addappid(259410)
addappid(333320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(259411, 1, "5ad81cc406e28fbc5d018f9088e599bec7ba63d2746f6d8fdfab7b319ab91062")
addappid(259412, 1, "e24c31065a4cf0f241378e4af776268c9bad0d9b7ea8d9dd539abe3f66893b03")

