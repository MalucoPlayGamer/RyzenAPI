-- Lua provided by RyzenAPI
-- Game: Bombing!! 2: A Graffiti Paradise

-- MAIN APPLICATION
addappid(2109570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109571, 1, "14e5b0067d38988199833c4bf9cc51f9c03d15cfb72301e63c7e70e15ade9163")
