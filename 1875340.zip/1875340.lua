-- Lua provided by RyzenAPI
-- Game: AppID 1875340

-- MAIN APPLICATION
addappid(1875340)
-- Game: addappid(1875340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875341, 1, "46d256533ee5f0d7e930565b91f357fb839eefb67cf091d92854c2d167e8af65")
addappid(1875342, 1, "2ddadb2fb9d30574322160bdf328f98e7da965fe2b40172f3d459a3eb35afab4")
