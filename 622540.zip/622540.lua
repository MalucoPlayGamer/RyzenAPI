-- Lua provided by RyzenAPI
-- Game: The Frost

-- MAIN APPLICATION
addappid(622540)

-- MAIN APP DEPOTS / PACKAGES
addappid(622541, 1, "7d4d5021b10c8c7e2850c9c45ba2ee872e5b36bd2fafb0f3dd7d31660e656859")
