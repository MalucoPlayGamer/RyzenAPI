-- Lua provided by RyzenAPI
-- Game: The Frost

-- MAIN APPLICATION
addappid(622540)

-- MAIN APP DEPOTS / PACKAGES
addappid(622541, 1, "7d4d5021b10c8c7e2850c9c45ba2ee872e5b36bd2fafb0f3dd7d31660e656859")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
