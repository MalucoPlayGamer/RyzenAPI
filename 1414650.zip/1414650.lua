-- Lua provided by RyzenAPI
-- Game: EDENGATE: The Edge of Life

-- MAIN APPLICATION
addappid(1414650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414651, 1, "53b7962b90a24b6e2eda8aa64b04502419eccbd98a19b50219d41e9320f99e6c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
