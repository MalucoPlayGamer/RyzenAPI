-- Lua provided by RyzenAPI
-- Game: Game: EDENGATE: The Edge of Life

-- MAIN APPLICATION
addappid(1414650)
-- Game: addappid(1414650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414651, 1, "53b7962b90a24b6e2eda8aa64b04502419eccbd98a19b50219d41e9320f99e6c")
