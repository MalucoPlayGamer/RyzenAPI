-- Lua provided by SkyAPI 
-- Game: EDENGATE: The Edge of Life
addappid(1414650)
addappid(1414651, 1, "53b7962b90a24b6e2eda8aa64b04502419eccbd98a19b50219d41e9320f99e6c")
