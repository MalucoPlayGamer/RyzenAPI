-- Lua provided by RyzenAPI
-- Game: Game: One Night ~Young Bride for One Night~

-- MAIN APPLICATION
addappid(3277480)
-- Game: addappid(3277480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277481, 1, "735e3eacb6ae39f1ecfbf8ffbed241483f08dc27d5e9b8a5d7144d3759c7ae4d")
