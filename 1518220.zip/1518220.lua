-- Lua provided by RyzenAPI
-- Game: Game: Spells & Secrets

-- MAIN APPLICATION
addappid(1518220)
-- Game: addappid(1518220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518221, 1, "04c793c261aeb6342f499033796093071e25588f0e9adae2a95080859138b2d3")
