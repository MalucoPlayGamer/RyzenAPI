-- Lua provided by RyzenAPI
-- Game: Survival Planet

-- MAIN APPLICATION
addappid(807870)

-- MAIN APP DEPOTS / PACKAGES
addappid(807871,0,"e6bab327ce9c1724ece9c970551efb6c7d0972749739160eb95dcb0447816ad6")

