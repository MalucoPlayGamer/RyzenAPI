-- Lua provided by RyzenAPI
-- Game: WolfGirl RoomMate

-- MAIN APPLICATION
addappid(3138460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138461, 1, "dd61631a079a88253e9f54a0ea882a4a7e82c11f5fb5c2cacb81bf0110137e07")

