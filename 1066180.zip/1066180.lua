-- Lua provided by RyzenAPI
-- Game: Crisis Brigade 2 reloaded

-- MAIN APPLICATION
addappid(1066180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066181, 1, "58af9da345854588a9c9abe311f2713e8b4841fb70dd6542b63f3557cb3569ff")

