-- Lua provided by RyzenAPI
-- Game: Vasilisa

-- MAIN APPLICATION
addappid(3550710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3550711,0,"470aec9363303d5ec69ec7088d91fa3015ad24470c153cae60dbd649f1b65efa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
