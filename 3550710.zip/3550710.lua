-- Lua provided by RyzenAPI
-- Game: Vasilisa

-- MAIN APPLICATION
addappid(3550710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3550711,0,"470aec9363303d5ec69ec7088d91fa3015ad24470c153cae60dbd649f1b65efa")

