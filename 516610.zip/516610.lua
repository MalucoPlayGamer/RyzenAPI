-- Lua provided by SkyAPI 
-- Game: Guardian war VR
addappid(516610)
addappid(516611, 1, "bdc4dd50fdaf2662ba2e16b4fb5189565ff2ba72cfd3cb4dbbf6fb6e2c0e0f97")
