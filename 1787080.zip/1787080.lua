-- Lua provided by RyzenAPI
-- Game: Office No.41: Prototype Edition

-- MAIN APPLICATION
addappid(1787080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1787081, 1, "33717e9eace141149757901b5dad5f81e8e54a1b269b2a0b5e6b39e054515dc2")

