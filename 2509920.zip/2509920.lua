-- Lua provided by RyzenAPI
-- Game: Sliding Rails

-- MAIN APPLICATION
addappid(2509920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509921, 1, "a0923f63c1492d01d8470fda326a9281a7d3a46557bea924405bdce9c86083b0")

