-- Lua provided by RyzenAPI
-- Game: 1387500

-- MAIN APPLICATION
addappid(1387500)
-- Game: addappid(1387500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387501, 1, "edbe09eb93f94f20b214a9219a8104ab2d2784f024eed9837b2370d04a600eae")
