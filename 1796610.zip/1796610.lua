-- Lua provided by RyzenAPI
-- Game: Winding Road

-- MAIN APPLICATION
addappid(1796610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796611, 1, "404d60c4e1db339cd198102fbd5b509aa7ec7952c5e40cd486cc80e552e3ab58")
