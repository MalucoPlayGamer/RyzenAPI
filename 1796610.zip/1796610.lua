-- Lua provided by SkyAPI 
-- Game: Winding Road
addappid(1796610)
addappid(1796611, 1, "404d60c4e1db339cd198102fbd5b509aa7ec7952c5e40cd486cc80e552e3ab58")
