-- Lua provided by RyzenAPI
-- Game: AppID 250700

-- MAIN APPLICATION
addappid(250700)

-- MAIN APP DEPOTS / PACKAGES
addappid(250701, 1, "8846b1cf8f4b40f8d38498d503fcd18574c7a503204fab7a9cc37375835d73d1")
addappid(250702, 1, "0d47aa7f9269eae100a5d63fc378c91536403fe1f108731c5db950990951dc20")
addappid(250703, 1, "803a634a0275123201434cce7b3fb981abf26d512a5a6084665ec7b01f76165a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
