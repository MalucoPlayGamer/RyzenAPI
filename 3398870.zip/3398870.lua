-- Lua provided by RyzenAPI
-- Game: Game: Dooms Hair Salon

-- MAIN APPLICATION
addappid(3398870)
-- Game: addappid(3398870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3398871, 1, "5728497db55ff3ca7d92a4d797fbe2fb2a70f6b384e0b909e94feb5a10cb19e1")
