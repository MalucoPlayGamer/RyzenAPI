-- Lua provided by RyzenAPI
-- Game: 3398870

-- MAIN APPLICATION
addappid(3398870)
-- Game: addappid(3398870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3398871, 1, "5728497db55ff3ca7d92a4d797fbe2fb2a70f6b384e0b909e94feb5a10cb19e1")
