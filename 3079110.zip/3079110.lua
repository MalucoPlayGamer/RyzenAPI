-- Lua provided by RyzenAPI
-- Game: 谬撒牌MiuSa

-- MAIN APPLICATION
addappid(3079110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079111, 1, "75d4fbb328021ed5be705f6d3122bda9784c22a3bb6c50bc7838083817f70bb1")
