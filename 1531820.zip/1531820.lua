-- Lua provided by RyzenAPI
-- Game: The Last Stand: Aftermath Demo

-- MAIN APPLICATION
addappid(1531820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531821, 1, "64aea5425ea9d22af9f555d1348bf3a11e0b54f7bc3092ca621b0714935490b2")
