-- Lua provided by RyzenAPI
-- Game: addappid(950620)

-- MAIN APPLICATION
addappid(950620)

-- MAIN APP DEPOTS / PACKAGES
addappid(950621, 1, "f0a967c2d200e58f94b1dc142e07f6c93ca43ca1ff93802cbd015b9005df0717")
