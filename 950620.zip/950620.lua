-- Lua provided by RyzenAPI
-- Game: Priest Simulator: Vampire Show

-- MAIN APPLICATION
addappid(950620)
addappid(2947900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(950621,0,"f0a967c2d200e58f94b1dc142e07f6c93ca43ca1ff93802cbd015b9005df0717")

