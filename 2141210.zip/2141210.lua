-- Lua provided by RyzenAPI
-- Game: 2141210

-- MAIN APPLICATION
addappid(2141210)
-- Game: addappid(2141210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141211, 1, "b64d3c3ab7a3d93c14c0573dafc8fdd9b89cff1fbfb9d4f34f4c36cb829949a1")
