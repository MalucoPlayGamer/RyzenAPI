-- Lua provided by RyzenAPI
-- Game: Game: Mega Man Battle Network Legacy Collection Vol. 2 - Custom PET Pack Vol. 2

-- MAIN APPLICATION
addappid(1981420)
-- Game: addappid(1981420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981421, 1, "02d4248870812a753f49e554a0a1d2444e001b367a2bc8d97f12a759d9213876")
