-- Lua provided by RyzenAPI
-- Game: 1462420

-- MAIN APPLICATION
addappid(1462420)
-- Game: addappid(1462420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462421, 1, "e0a172dcc4ec9fef80c3a05a0fcc1675ef7e61decd4e8b3c99a7000affbbf0c4")
