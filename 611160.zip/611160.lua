-- Lua provided by RyzenAPI
-- Game: Game: AppID 611160

-- MAIN APPLICATION
addappid(611160)
-- Game: addappid(611160)

-- MAIN APP DEPOTS / PACKAGES
addappid(611161, 1, "1d4a12f21676fd663cc69900627e400a095d52282d5532607e33bc63ce5c7f1c")
