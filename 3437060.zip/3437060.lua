-- Lua provided by RyzenAPI
-- Game: Black Fairy Tale

-- MAIN APPLICATION
addappid(3437060)
-- Game: addappid(3437060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437061, 1, "d3cd2f76f1f81178696186ad47d053231f9546331b1802bff2577ee9c76ad622")
