-- Lua provided by SkyAPI 
-- Game: AppID 228100
addappid(228100)
addappid(228101, 1, "fb01144a1442fa137d9f57ae3e970213598ee49bd64d885ce492774e9c9764d8")
