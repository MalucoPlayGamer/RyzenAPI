-- Lua provided by RyzenAPI
-- Game: Game: AppID 228100

-- MAIN APPLICATION
addappid(228100)
-- Game: addappid(228100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228101, 1, "fb01144a1442fa137d9f57ae3e970213598ee49bd64d885ce492774e9c9764d8")
