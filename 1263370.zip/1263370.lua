-- Lua provided by RyzenAPI
-- Game: Seek Girl:Fog Ⅰ

-- MAIN APPLICATION
addappid(1263370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263371, 1, "2a0bf5389b61094c049b4307befee675b84180f69c6e45388f628f4f1da51af3")
addappid(1270320, 0, "ad5b9d6f3dcae60a4c522e40ae02d907752458b401bf99fe8551ca585b3936f6")
