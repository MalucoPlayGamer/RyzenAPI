-- Lua provided by RyzenAPI
-- Game: 이세계메이드

-- MAIN APPLICATION
addappid(2417840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417841, 1, "73aa6353b6f3eaf4cb49193755a1c45bdfea67d7a8a47fea4ffea1538598d45f")

