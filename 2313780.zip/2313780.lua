-- Lua provided by RyzenAPI
-- Game: 2313780

-- MAIN APPLICATION
addappid(2313780)
-- Game: addappid(2313780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313781, 1, "a5e5570142b2be65d94f3b133ad637b225e020d6ea7c03cf1a6989676e99a213")
