-- Lua provided by SkyAPI 
-- Game: Bad Dream: Purgatory
addappid(2313780)
addappid(2313781, 1, "a5e5570142b2be65d94f3b133ad637b225e020d6ea7c03cf1a6989676e99a213")
