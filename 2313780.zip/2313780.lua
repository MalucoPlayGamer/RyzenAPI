-- Lua provided by RyzenAPI
-- Game: Bad Dream: Purgatory

-- MAIN APPLICATION
addappid(2313780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313781, 1, "a5e5570142b2be65d94f3b133ad637b225e020d6ea7c03cf1a6989676e99a213")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
