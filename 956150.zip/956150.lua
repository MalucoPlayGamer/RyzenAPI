-- Lua provided by RyzenAPI
-- Game: 956150

-- MAIN APPLICATION
addappid(956150)
-- Game: addappid(956150)

-- MAIN APP DEPOTS / PACKAGES
addappid(956151, 1, "649a1d2f1482634991ddf0f17eb75ac396dc8350cad9abd0419c42cc9e16a177")
