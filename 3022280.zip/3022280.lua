-- Lua provided by RyzenAPI 
-- Game: AppID 3022280
addappid(3022280)
addappid(3022281, 1, "efeaa712b47adf3955d1123064144eb531767d3009ff45e92a29bd1a8b871b35")
