-- Lua provided by RyzenAPI
-- Game: addappid(948320)

-- MAIN APPLICATION
addappid(948320)

-- MAIN APP DEPOTS / PACKAGES
addappid(948321, 1, "c5ba4129d352991fae0fd2a23ec9d19e7c1d9da0a424df6a8344b4fabc929afe")
