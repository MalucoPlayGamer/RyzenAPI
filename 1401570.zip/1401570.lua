-- Lua provided by RyzenAPI 
-- Game: Cold Call
addappid(1401570)
addappid(1401571, 1, "66bcac18074fc04add217300eeb9f02ee843cd40895d7cbc80c2949488476827")
