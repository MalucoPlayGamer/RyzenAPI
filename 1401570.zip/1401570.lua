-- Lua provided by RyzenAPI
-- Game: Cold Call

-- MAIN APPLICATION
addappid(1401570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401571, 1, "66bcac18074fc04add217300eeb9f02ee843cd40895d7cbc80c2949488476827")

