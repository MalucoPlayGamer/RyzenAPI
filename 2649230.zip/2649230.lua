-- Lua provided by RyzenAPI 
-- Game: AppID 2649230
addappid(2649230)
addappid(2649231, 1, "d49e519872af71af2f7d0fc608e41d73fe97effdfef8e51ca891441ff0c7aae7")
addappid(2708430, 0, "a8cb268cbc983d7e79a579c590259bc9e02b73c68aec681f30c5deb4fd1c2c28")
