-- Lua provided by RyzenAPI
-- Game: 3016740

-- MAIN APPLICATION
addappid(3016740)
-- Game: addappid(3016740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016741, 1, "79756d96a402e9dbe2cef7a763db12e8a71b8d978bcd9b5b4aa0367262192f5a")
