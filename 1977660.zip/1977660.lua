-- Lua provided by RyzenAPI
-- Game: ELEGIES: Aya

-- MAIN APPLICATION
addappid(1977660)
addappid(1977661)
addappid(1977663)
addappid(1977664)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977662,0,"50d518952809dbac1519f391a18c8ba3302b02f61ff8f5175eacd0869c00299b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2594830)
