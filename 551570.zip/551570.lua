-- Lua provided by RyzenAPI
-- Game: 551570

-- MAIN APPLICATION
addappid(551570)
-- Game: addappid(551570)

-- MAIN APP DEPOTS / PACKAGES
addappid(551571, 1, "9641a632d141f43fb90f0f5eb95663858a10ecc17d04b998abf3443a2d4d8b7b")
