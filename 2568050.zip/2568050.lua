-- Lua provided by RyzenAPI
-- Game: 2568050

-- MAIN APPLICATION
addappid(2568050)
-- Game: addappid(2568050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568051, 1, "4b5abc62369a8c6348d91aca1f0e512c8a76ead0c2d11fbe7ecd4ec7dbb19c57")
