-- Lua provided by RyzenAPI
-- Game: Mark's Magnificent Marble Maze Demo

-- MAIN APPLICATION
addappid(1985890)
-- Game: addappid(1985890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985891, 1, "c52c93d1e85bdc3e974b800ca6ad0694633e0c577e4ce4b495e9c90a93d40e3b")
