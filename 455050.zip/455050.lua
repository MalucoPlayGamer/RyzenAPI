-- Lua provided by RyzenAPI
-- Game: Dishonored Soundtrack

-- MAIN APPLICATION
addappid(455050)
-- Game: addappid(455050)

-- MAIN APP DEPOTS / PACKAGES
addappid(455050,0,"7309451125339a5268e63000095622854d39e4a980240307deefabe8a46b7300")
