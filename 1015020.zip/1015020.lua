-- Lua provided by RyzenAPI
-- Game: 记忆重构/Memories

-- MAIN APPLICATION
addappid(1015020)
addappid(1015021)
-- Game: addappid(1015020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015022,0,"052b6fe0a43400053f2b208de38fbd83ef255b969e3742c0f896fc561588414b")
addappid(1015023,0,"3af132128c430ad9cda8714cc17c39ab03464a1de2912a8a62056f93236c33ec")
