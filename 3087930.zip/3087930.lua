-- Lua provided by RyzenAPI
-- Game: Pebble Knights

-- MAIN APPLICATION
addappid(3087930)

