-- Lua provided by RyzenAPI
-- Game: AppID 243950

-- MAIN APPLICATION
addappid(243950)

-- MAIN APP DEPOTS / PACKAGES
addappid(243951, 1, "b55c21cfc77326a685d251641f5e91360889847efdca7a1400166c3824f83b20")
addappid(243952, 1, "4029ab571fa8427de6cccc1cc0f6e3b29ae70e3b901809465fe05f93b0536aba")
addappid(243953, 1, "7eba4abd5e0198c242b6326924470225c1b8ff1df3aec575db1d9511b86cc439")
addappid(243954, 1, "5aafb6c3f33fe13e3faa443a01f47d75409e27e65a58772c7174bd7342f66641")
addappid(243955, 1, "121407be5e120a3e4363c14032bdcb0f345c3560fc4b264046241f84cfe13fa8")
addappid(243956, 1, "d688d33c4b1128ac332e472c2c6d7cd605949153e696a56e8f3cff30497a396c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(243959)
