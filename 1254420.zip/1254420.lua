-- Lua provided by RyzenAPI
-- Game: My psychedelic world

-- MAIN APPLICATION
addappid(1254420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254421, 1, "ce817dde8f7392e5b19f20622b15ff71a698a3e52feea9ed9476798a53036c74")
