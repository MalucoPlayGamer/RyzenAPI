-- Lua provided by RyzenAPI
-- Game: Fall Of The MS Estonia

-- MAIN APPLICATION
addappid(2848550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848551, 1, "5cf9b7dc998049218bab8b87dbb8d6d00f62d1e708bd9512bb2a5daafd52e61e")
