-- Lua provided by RyzenAPI
-- Game: Game: Lewd Family

-- MAIN APPLICATION
addappid(3270440)
-- Game: addappid(3270440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3270441, 1, "9921080bafa23f9f94567aeab8e08ddbf30745fac27a0177a7988298a8398eab")
