-- Lua provided by RyzenAPI
-- Game: REKA Demo

-- MAIN APPLICATION
addappid(1783630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783631, 1, "417cb5100712b4ac129ad467304d4f67307ccbb1b5785baf1e5d140cc34b09f3")
