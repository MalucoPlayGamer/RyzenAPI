-- Lua provided by RyzenAPI 
-- Game: AppID 1040460
addappid(1040460)
addappid(1040461, 1, "d74095e3e9d34dae975c58b7b4d2052b442b978df7719b5597683978062adcb5")
