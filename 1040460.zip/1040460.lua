-- Lua provided by RyzenAPI
-- Game: Space Scavenger

-- MAIN APPLICATION
addappid(1040460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040461, 1, "d74095e3e9d34dae975c58b7b4d2052b442b978df7719b5597683978062adcb5")

