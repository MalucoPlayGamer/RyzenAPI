-- Lua provided by RyzenAPI
-- Game: Game: Base Defense

-- MAIN APPLICATION
addappid(632730)
-- Game: addappid(632730)

-- MAIN APP DEPOTS / PACKAGES
addappid(632731, 1, "5716240db7325cc8e77dd4bd89b742f3ff69c2132ae3c13dd27a0381e1cbcb75")
