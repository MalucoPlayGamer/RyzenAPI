-- Lua provided by RyzenAPI
-- Game: Triteckka: The pure shooter

-- MAIN APPLICATION
addappid(915430)

-- MAIN APP DEPOTS / PACKAGES
addappid(915431, 1, "2235d483373eeb6611d89f5ab31188397400379e7266ee0a27a8e6aea5977ebb")
