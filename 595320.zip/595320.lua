-- Lua provided by RyzenAPI
-- Game: addappid(595320)

-- MAIN APPLICATION
addappid(595320)

-- MAIN APP DEPOTS / PACKAGES
addappid(595321, 1, "f09d5c11d7fd08923c681903dadc1f2d14596082579b2d9cbe4f5b159553fd5e")
