-- Lua provided by RyzenAPI
-- Game: Sailaway - The Sailing Simulator

-- MAIN APPLICATION
addappid(552920)
addappid(552922)
addappid(552924)
addappid(552925)
addappid(552926)
addappid(552927)

-- MAIN APP DEPOTS / PACKAGES
addappid(552923,0,"722fdded09e9926badd578d8fd69d7d893cfb21180564aac883ec48822be5cef")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(870640)
