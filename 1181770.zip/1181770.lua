-- Lua provided by RyzenAPI
-- Game: Beat Saber - Tokyo Machine – "PLAY"

-- MAIN APPLICATION
addappid(1181770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181770,0,"f1721ab76836bd427184cd59d6568ed1ce4e8be1306940a7a518123ee7879e6b")

