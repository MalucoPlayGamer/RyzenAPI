-- Lua provided by RyzenAPI
-- Game: addappid(3024540)

-- MAIN APPLICATION
addappid(3024540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024541, 1, "1528a0036a27e7b0d5096b901a8fef83c7f43b88aa0d2d69d2931590cfb1a7ad")
