-- Lua provided by RyzenAPI
-- Game: Game: Lust Mansion 🔞

-- MAIN APPLICATION
addappid(2936260)
-- Game: addappid(2936260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936261, 1, "c37a92c560d495393a65bb7e6fbacd83a2003e6d50895fd7c0a6df1098b9fe14")
