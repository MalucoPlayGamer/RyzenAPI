-- Lua provided by RyzenAPI
-- Game: 981160

-- MAIN APPLICATION
addappid(981160)
-- Game: addappid(981160)

-- MAIN APP DEPOTS / PACKAGES
addappid(981161, 1, "9d5576626b86c013c8b46f3337544faeb7949a6331ebdfe3b9545c9a0ab8a3d6")
