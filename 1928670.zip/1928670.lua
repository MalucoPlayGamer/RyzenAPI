-- Lua provided by RyzenAPI
-- Game: Hajis هاجس

-- MAIN APPLICATION
addappid(1928670)
-- Game: addappid(1928670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928677,0,"2dedead27d9feb2c3d919b11fbf8fc5c1aae8440724e55774e91bae657111b2b")
