-- Lua provided by RyzenAPI
-- Game: Outpost

-- MAIN APPLICATION
addappid(1127110)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2213280)
