-- Lua provided by RyzenAPI
-- Game: Outpost

-- MAIN APPLICATION
addappid(1127110)
addappid(2213280)

