-- Lua provided by RyzenAPI
-- Game: Floor 9

-- MAIN APPLICATION
addappid(3106510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106511, 1, "ebc537e37ae52b3b8b0fba4afd15b18593ab6647728a4de4b0432010843130dc")

