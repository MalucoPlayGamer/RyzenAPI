-- Lua provided by RyzenAPI
-- Game: Goddess Scroll - The Last Starlight

-- MAIN APPLICATION
addappid(3677520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3677521, 1, "bf357ca4e3236aa709136da7ff0e1b7427aabfe84160e582eb4aa4c1d0494c95")
