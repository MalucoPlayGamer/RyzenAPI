-- Lua provided by RyzenAPI
-- Game: 46720

-- MAIN APPLICATION
addappid(46720)
-- Game: addappid(46720)

-- MAIN APP DEPOTS / PACKAGES
addappid(46721, 1, "4535ce1dca05ebcf5bf96a07ecc913997a53e48e9c375fff77e16178634268f5")
