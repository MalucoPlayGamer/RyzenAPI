-- Lua provided by RyzenAPI
-- Game: addappid(862020)

-- MAIN APPLICATION
addappid(862020)

-- MAIN APP DEPOTS / PACKAGES
addappid(862021, 1, "63c17a3d8a3dd830b1de323ade3b34dbe1dcaaba21794f1eccbe52fa2cf7af66")
