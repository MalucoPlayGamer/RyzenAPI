-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Elemental Dungeon Tileset - Dark Light Lightning Metal

-- MAIN APPLICATION
addappid(1517700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517700,0,"8a4ca2c62596fd582eba474c8962918a2b8a75c5dddec1319879c5bea6cb1ca7")

