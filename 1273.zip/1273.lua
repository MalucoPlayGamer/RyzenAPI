-- Lua provided by RyzenAPI
-- Game: 1273

-- MAIN APPLICATION
addappid(1273)
-- Game: addappid(1273)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271,0,"7b336f657f13dfbfec5f51cf4413a4f949511c089d713ab1fa279568cc0e4ac9")
addappid(1273,0,"404e78d96539e9861d5cbf9c0777155cf6c602ed57720a328ede46e03890fe8c")
