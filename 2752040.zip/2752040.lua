-- Lua provided by RyzenAPI
-- Game: PlayStatus - Media & Controller Battery Overlay

-- MAIN APPLICATION
addappid(2752040)
-- Game: addappid(2752040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752041, 1, "8950bc893424c4dc580126c9450e075aa4b5b4097b016536636d0193e497d3a1")
