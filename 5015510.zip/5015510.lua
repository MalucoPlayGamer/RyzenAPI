-- Lua provided by RyzenAPI
-- Game: Sycamore End

-- MAIN APPLICATION
addappid(5015510) -- Sycamore End

-- MAIN APP DEPOTS / PACKAGES
addappid(5015511, 1, "e9d49dd03729cfded0543174085100c8302202d9753db61f82f2760ce8fb0798") -- Depot 5015511
