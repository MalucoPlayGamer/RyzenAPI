-- Lua provided by RyzenAPI
-- Game: Hentai Beauty

-- MAIN APPLICATION
addappid(2205710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205711, 1, "a640664ccf36950f290f3d8f6e7547d0707cde076788a764afc181f260d49227")

