-- Lua provided by RyzenAPI
-- Game: AppID 344410

-- MAIN APPLICATION
addappid(344410)
-- Game: addappid(344410)

-- MAIN APP DEPOTS / PACKAGES
addappid(344411, 1, "0e87ab588295219d5497de648bcb20b6762843de6a320cff2049a2d291d927da")
addappid(362850, 0, "c72acab6dcd3061c2b17a736e738d0025a53924e89ce544d15a6b0439ff76280")
addappid(397010, 0, "de293ffd2da1dbf71e4d2ab15d174f2faacf9bee5d5bede3578da16a9bbd7aa6")
