-- Lua provided by RyzenAPI
-- Game: 3DMark

-- MAIN APPLICATION
addappid(223850)
addappid(487680)

-- MAIN APP DEPOTS / PACKAGES
addappid(223851, 1, "3de227c648bb03f2e1c49c79d24114cec185486be4058e6f76eb4175b5c8ee1c")
addappid(223853, 1, "b891cf73a4f710c4d361a757912867ddea5cb77f8cdc2520e1bd9c64aefeb43d")
addappid(223856, 1, "c597efcdf5cf687d07b63f3521b6c1bdba41bcf0a2d3e3656d74a80425b08e06")
addappid(223857, 1, "3b9c04fda6f4eec1130cfadfa5524ed579db2b1a2ea05e642b589fdbd22d154e")
addappid(223858, 1, "a149d2384c242a0f24db11102ba5192e6be5b24e4e9f5478d6f81715e1be2600")
addappid(223859, 1, "7ba109e7f86954b3752a77be9bcf62ac11fca73888fd16451324d316a8a648c7")
addappid(223860, 1, "34c1fa8d4ac0296046d8b013606ccd07dabafc06f5fd315998163a027ad36570")
addappid(496106, 1, "6ea0283e4e59b867500f3a10bffbf76ddc462694f60eec5c36a701679f60afbf")
addappid(1498801, 0, "f3523fbbdddc65bee537e1d0e876edce5b25fdb11c8697178bd36e8041fb0377")
addappid(2313300, 0, "0967c1e1a31aee44ccf8e1af64012d56de566e0db5f89ef87cb1357b923fc33f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(223852)
addappid(393480)
addappid(402290)
addappid(406950)
addappid(406960)
addappid(407080)
addappid(428810)
addappid(496100)
addappid(496101)
addappid(496102)
addappid(496103)
addappid(496104)
addappid(556150)
addappid(1276160)
addappid(1322770)
addappid(1498800)
addappid(1654370)
addappid(2019730)
addappid(2695340)
addappid(3941790)
