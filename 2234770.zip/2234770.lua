-- Lua provided by RyzenAPI
-- Game: Lachesis or Atropos

-- MAIN APPLICATION
addappid(2234770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234771, 1, "860060a9a84f5e1367af974dbc8c9f2cab65a28e07c5d66ded30470460c387ca")
addappid(2234772, 1, "e1da8f0bfc3583d57c8038543738799546d8ea01a06a3574eaafefc4a9eeaf62")
addappid(2234773, 1, "f726d95608a168e74070769f85d6db7ea1205d9fb10c4b81d715f4217f3e108c")

