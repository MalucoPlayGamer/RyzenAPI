-- Lua provided by RyzenAPI
-- Game: 1189230

-- MAIN APPLICATION
addappid(1189230)
-- Game: addappid(1189230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189231, 1, "f8d92d9cdca24a29f325a07562c5ee83b1bb3877fc6b6f9f2b6bd7d9582a44b1")
