-- Lua provided by RyzenAPI
-- Game: Door in the Woods

-- MAIN APPLICATION
addappid(1189230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1189231, 1, "f8d92d9cdca24a29f325a07562c5ee83b1bb3877fc6b6f9f2b6bd7d9582a44b1")
