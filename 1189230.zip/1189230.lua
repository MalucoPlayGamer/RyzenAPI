-- Lua provided by SkyAPI 
-- Game: AppID 1189230
addappid(1189230)
addappid(1189231, 1, "f8d92d9cdca24a29f325a07562c5ee83b1bb3877fc6b6f9f2b6bd7d9582a44b1")
