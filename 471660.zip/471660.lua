-- Lua provided by RyzenAPI
-- Game: addappid(471660)

-- MAIN APPLICATION
addappid(471660)

-- MAIN APP DEPOTS / PACKAGES
addappid(471661, 1, "fa47dcaf8b712981e6798057e5751b205f65fbf9734b9758ffe0e8f6da8d25d2")
