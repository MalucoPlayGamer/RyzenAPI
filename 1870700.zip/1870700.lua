-- Lua provided by RyzenAPI
-- Game: The Edge of Allegoria

-- MAIN APPLICATION
addappid(1870700)
-- Game: addappid(1870700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870701, 1, "34c1693d2dfdaa905068ef71ccab2040658d8ac8b25252288b4c9f0b867536b1")
