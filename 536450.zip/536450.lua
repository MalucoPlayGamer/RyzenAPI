-- Lua provided by RyzenAPI
-- Game: Vzerthos: The Heir of Thunder

-- MAIN APPLICATION
addappid(536450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(536451, 1, "697b8bfdacc895aa8f21a7b6cfa9ef28e846d6cc4592250332d368f5383280c9")
addappid(536452, 1, "27d9dfc6bc89064e117c2f795215a6521a8dd2fe34092f0153f9eae3c46dfa88")

