-- Lua provided by RyzenAPI
-- Game: Shank 2

-- MAIN APPLICATION
addappid(102840)

-- MAIN APP DEPOTS / PACKAGES
addappid(102841, 1, "587dc4fdaaf24f4ad2e33f9a1ba61025351157eede5dc3c0a9f0bed831a488e6")
addappid(102842, 1, "816fb7aa5ffc8dc6efd4acab2e7dbb021e82a3f204aa31acabe49b30595afe12")
addappid(102843, 1, "216e6bdba1724e1df133dadb1d937883e1e75efd47efb41f45fb295667c00ed7")
