-- Lua provided by RyzenAPI
-- Game: AppID 661330

-- MAIN APPLICATION
addappid(661330)

-- MAIN APP DEPOTS / PACKAGES
addappid(661331, 1, "9bc760d02d9967a097d7bf8a0816912ca0f61ccf83b7cab9e3c8bc8ec650867d")

