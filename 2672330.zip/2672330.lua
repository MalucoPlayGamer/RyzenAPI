-- Lua provided by RyzenAPI
-- Game: addappid(2672330)

-- MAIN APPLICATION
addappid(2672330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672330,0,"f8c2b71cc3248022d64db44a94f16604fd2905179325464ea77cbee9b787ed5d")
