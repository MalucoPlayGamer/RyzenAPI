-- Lua provided by RyzenAPI
-- Game: Game: Memories Off -Innocent Fille- for Dearest

-- MAIN APPLICATION
addappid(1200110)
-- Game: addappid(1200110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200111, 1, "cc8acc21f39ddb32136b839ba861937af7aa43346751e9157b3d3bd804b14cfc")
addappid(1200112, 1, "09f2953a70301382f4cb78f8e3c8c6b212275379e4966fd509c10fd937dda49a")
addappid(1200113, 1, "e916f3cdb63f2b46a636b3dbdf818c09db8ba8d8265ed32f358b35c3c97d112d")
addappid(1200114, 1, "3c3a2216c36bc02af20dcc6caf8839259a139b343bc91b834acd10a75d62ca89")
