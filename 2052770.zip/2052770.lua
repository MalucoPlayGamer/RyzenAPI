-- Lua provided by RyzenAPI
-- Game: Aquarist VR

-- MAIN APPLICATION
addappid(2052770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052771, 1, "94a5f32ab0ec18c9fe195a4feab2410ef7eb4d33cfc5a64299b03abb8b5c5172")

