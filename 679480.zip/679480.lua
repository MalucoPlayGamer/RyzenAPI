-- Lua provided by RyzenAPI
-- Game: 生死线 Dead Line

-- MAIN APPLICATION
addappid(679480)
-- Game: addappid(679480)

-- MAIN APP DEPOTS / PACKAGES
addappid(679481, 1, "4ad7cd01d5d197acfa754b6b89c112892c96858bef5f99c169961a789b70cabd")
