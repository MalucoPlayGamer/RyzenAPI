-- Lua provided by RyzenAPI
-- Game: AppID 3413130

-- MAIN APPLICATION
addappid(3413130)
-- Game: addappid(3413130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413131, 1, "8d10dd726ac837007fcd76bb843b619538f139fa8b8d4d022d14fc3db935224b")
