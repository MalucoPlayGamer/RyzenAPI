-- Lua provided by RyzenAPI
-- Game: AppID 1284410

-- MAIN APPLICATION
addappid(1284410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284411, 1, "b4cf4afd8eeb499a6acaf240167a6533e792b4bc1d5fdd6d15cd7139b12dd9f8")
addappid(1284412, 1, "9ba94be7146078072633928c53dbf225831777bd0a6a05f194bc3bfce4c053fe")
addappid(1284413, 1, "650d3822a1c9cfc4d8a216e443b97a5c880dea998e8d9cc90b18eda8d42a12e3")
addappid(1284414, 1, "b350f1adf75e9abda18394b2f716561156c0eabb960cdffdde4b3abef1edf445")
addappid(1284415, 1, "c1bae2e8ad347fb19a97f6a7165db325fa2cc2a906abc4c0ce2935f7b8d92b90")
addappid(1284416, 1, "966c05fb33286e72da3eb562aceefdd04286d9fcf01932c1fc853941f6aab989")
addappid(1288440, 0, "c237d9e0cd701027e822be12d2cb9b0ffe4dcdd03eb4b88831e5f1774ab537fb")

