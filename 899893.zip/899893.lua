-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - “Amazing Grace”

-- MAIN APPLICATION
addappid(899893)

-- MAIN APP DEPOTS / PACKAGES
addappid(899893,0,"030a55f86fb17878be83bf47cad84ad75c32ba44d0304eb9f605c63c8cc8c1b8")

