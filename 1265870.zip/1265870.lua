-- Lua provided by RyzenAPI
-- Game: Game: Cave Digger

-- MAIN APPLICATION
addappid(1265870)
-- Game: addappid(1265870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265871, 1, "37f877219b7b74d4978e48713ad023a30d61f3c2dad56b53366225910b6e023b")
