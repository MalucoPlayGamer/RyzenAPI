-- Lua provided by RyzenAPI
-- Game: Farewell North Demo

-- MAIN APPLICATION
addappid(1787530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787532,0,"5af04c90a40f50652a4d8042fa88ae3097def01189bcb21884a043aa235b8862")

