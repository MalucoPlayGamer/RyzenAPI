-- Lua provided by RyzenAPI
-- Game: White Noise 2

-- MAIN APPLICATION
addappid(503350)

-- MAIN APP DEPOTS / PACKAGES
addappid(503351, 1, "103437322f8f76317df80c381186b61f3c780641ed8011500af2e737b2294384")
addappid(503352, 1, "94ba7eab39e452bc18b05f620c9b7409a04f0bba7aa4dc43ddece500477178ec")
addappid(503353, 1, "c84d5963fd3003ff227a862a21d520ffdd2b475629df58b832e4ac66f0928dd8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(610520)
addappid(623890)
addappid(638460)
addappid(657350)
addappid(691440)
addappid(691441)
