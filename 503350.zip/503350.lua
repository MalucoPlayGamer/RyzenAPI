-- Lua provided by RyzenAPI
-- Game: Game: White Noise 2

-- MAIN APPLICATION
addappid(503350)
-- Game: addappid(503350)

-- MAIN APP DEPOTS / PACKAGES
addappid(503351, 1, "103437322f8f76317df80c381186b61f3c780641ed8011500af2e737b2294384")
addappid(503352, 1, "94ba7eab39e452bc18b05f620c9b7409a04f0bba7aa4dc43ddece500477178ec")
addappid(503353, 1, "c84d5963fd3003ff227a862a21d520ffdd2b475629df58b832e4ac66f0928dd8")
