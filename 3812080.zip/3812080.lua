-- Lua provided by RyzenAPI
-- Game: 不帰上 -Fukiage-

-- MAIN APPLICATION
addappid(3812080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3812081, 1, "3c2388a68ad866eb114f7a5aac5e178181781cfed3d43c432106b997994fcfc2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
