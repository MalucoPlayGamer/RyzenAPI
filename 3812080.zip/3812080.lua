-- Lua provided by RyzenAPI
-- Game: addappid(3812080)

-- MAIN APPLICATION
addappid(3812080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3812081, 1, "3c2388a68ad866eb114f7a5aac5e178181781cfed3d43c432106b997994fcfc2")
