-- Lua provided by RyzenAPI
-- Game: AppID 1173940

-- MAIN APPLICATION
addappid(1173940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1173941, 1, "b79fbee561efb0f38b096347f9a796ab1734e2e9a6a03082103f37858153bf73")

