-- Lua provided by RyzenAPI 
-- Game: AppID 1173940
addappid(1173940)
addappid(1173941, 1, "b79fbee561efb0f38b096347f9a796ab1734e2e9a6a03082103f37858153bf73")
