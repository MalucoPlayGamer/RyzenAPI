-- Lua provided by RyzenAPI
-- Game: 2791020

-- MAIN APPLICATION
addappid(2791020)
-- Game: addappid(2791020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791021, 1, "90042d158043c453a7be8954fdba9b4370c038396de535a36adaf9d416f579a6")
