-- Lua provided by RyzenAPI
-- Game: 定制女友

-- MAIN APPLICATION
addappid(2791020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791021, 1, "90042d158043c453a7be8954fdba9b4370c038396de535a36adaf9d416f579a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
