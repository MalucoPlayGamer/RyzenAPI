-- Lua provided by RyzenAPI
-- Game: Game: DogFight Time

-- MAIN APPLICATION
addappid(1777110)
-- Game: addappid(1777110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777111, 1, "d6c5259faf9e61f54a7f580d07976a2859d576110cdfce2db7fcbfa786ebd7db")
