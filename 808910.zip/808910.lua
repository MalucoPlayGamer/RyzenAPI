-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Episode I Racer

-- MAIN APPLICATION
addappid(808910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(808911, 1, "f81faf29686e1bea39b4d169ff0ba90438a314a7646ab6c326a678b924e384ff")

