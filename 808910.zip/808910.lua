-- Lua provided by RyzenAPI 
-- Game: STAR WARS™ Episode I Racer
addappid(808910)
addappid(808911, 1, "f81faf29686e1bea39b4d169ff0ba90438a314a7646ab6c326a678b924e384ff")
