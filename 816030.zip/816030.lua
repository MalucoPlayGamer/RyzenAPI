-- Lua provided by RyzenAPI
-- Game: Alice Must Find The Key To Escape (Hidden Objects)

-- MAIN APPLICATION
addappid(816030)

-- MAIN APP DEPOTS / PACKAGES
addappid(816031,0,"67efc07372b77167759ba196fe20823dcea7b98b704445553b2968106bd9869c")

