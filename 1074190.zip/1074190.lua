-- Lua provided by RyzenAPI
-- Game: Dragon Spirits

-- MAIN APPLICATION
addappid(1074190)
-- Game: addappid(1074190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074191, 1, "1d577ca46478e011d314007fd76b519c93a6bd23237af86969956193ebb21731")
addappid(1074192, 1, "0759c53ab8a7debfc57644edb78fe9dda2accdc060545dfe646564f5a40094a9")
