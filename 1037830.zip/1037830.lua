-- Lua provided by RyzenAPI
-- Game: 1037830

-- MAIN APPLICATION
addappid(1037830)
-- Game: addappid(1037830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037831, 1, "fba589db8afa3072ea228ebef61ffc9af99adb4d72187c139003cb8eeb77727c")
