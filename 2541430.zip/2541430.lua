-- Lua provided by RyzenAPI
-- Game: AppID 2541430

-- MAIN APPLICATION
addappid(2541430)
-- Game: addappid(2541430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541431, 1, "c8d5fc5074c612288c1e9f60eafcb37462c7dcf9c0964c24f64d911331bd45e7")
