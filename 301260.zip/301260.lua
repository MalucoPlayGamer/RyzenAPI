-- Lua provided by RyzenAPI
-- Game: Gardens Inc. 2: The Road to Fame

-- MAIN APPLICATION
addappid(301260)

-- MAIN APP DEPOTS / PACKAGES
addappid(301261, 1, "a3ec5f5842c92fc35e055674ca811990129ca4e4efcb7b78962ab365fcf9bd31")
addappid(301262, 1, "b7433719c799b7bc992509b958634039697ed0e130300673b67ee39786d06b35")
addappid(301263, 1, "a7ee24e988b24d8dddf5d493d16a044f74d9b2cf4a0d16fb233820c752ba0ee8")
addappid(301264, 1, "51d7e3b66020600f485c71be48c2e03347201afcbc247ed7c8051d578307c19f")
addappid(301265, 1, "d4bd2e102b1bbc7e60fd424af67637eaa44506ecdb7be2568afb55076f3100ff")
addappid(301266, 1, "a599ee9808cf00b75bfceaa5474d126eb148aedc880edd4a18ebffee10fe652c")

