-- Lua provided by RyzenAPI
-- Game: addappid(1291340)

-- MAIN APPLICATION
addappid(1291340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291341, 1, "e48062fcbad31518ebfc15ef58484aa135b22e600c05a4203431779eab8bc6e3")
addappid(1291342, 1, "f58a8f5b52a3db214461ed2ec8281531fb66e61c15dfe36fca249b06a2addeb7")
