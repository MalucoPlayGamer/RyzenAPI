-- Lua provided by RyzenAPI
-- Game: Game: AppID 207510

-- MAIN APPLICATION
addappid(207510)
-- Game: addappid(207510)

-- MAIN APP DEPOTS / PACKAGES
addappid(207511, 1, "c692edb910826d6fff784b643cd4b026604aca74d3a3105401fae511d8030db6")
