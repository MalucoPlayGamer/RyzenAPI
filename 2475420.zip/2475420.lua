-- Lua provided by RyzenAPI 
-- Game: Parking Tycoon: Business Simulator
addappid(2475420)
addappid(2475421, 1, "5e9cb2d1f8d00f54f2ccd5177fa09c903cd6af2aa393170a7c5cc04d9186e8a5")
addappid(2948360)
