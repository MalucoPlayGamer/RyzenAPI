-- Lua provided by RyzenAPI
-- Game: addappid(2475420)

-- MAIN APPLICATION
addappid(2475420)
addappid(2948360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475421, 1, "5e9cb2d1f8d00f54f2ccd5177fa09c903cd6af2aa393170a7c5cc04d9186e8a5")
