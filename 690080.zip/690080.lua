-- Lua provided by RyzenAPI
-- Game: Game: Deadly Traps

-- MAIN APPLICATION
addappid(690080)
-- Game: addappid(690080)

-- MAIN APP DEPOTS / PACKAGES
addappid(690081, 1, "9a63518d0d4e0c531427ee24ecfbc44a473b42523c04d7105bfe752e22b00bab")
