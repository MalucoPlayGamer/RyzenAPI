-- Lua provided by RyzenAPI
-- Game: addappid(892398)

-- MAIN APPLICATION
addappid(892398)

-- MAIN APP DEPOTS / PACKAGES
addappid(892398,0,"100e3c632a058cb029ffed30b38b9a4f5314713a8a52fbff18b853d4b9f69b9e")
