-- Lua provided by RyzenAPI
-- Game: addappid(2874850)

-- MAIN APPLICATION
addappid(2874850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2874851, 1, "3f431c13ede7ef54395418d0201e4188b9d50a6e78e1a2608c0b360dce3d56f6")
