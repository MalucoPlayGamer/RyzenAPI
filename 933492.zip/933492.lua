-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933492)

-- MAIN APP DEPOTS / PACKAGES
addappid(933492,0,"1f390a7cb5a538761834f8ebcff02184359cafd4a1da0a5c5fc2250c7808ed53")
addtoken(933492,13669332657106836264)

