-- Lua provided by RyzenAPI
-- Game: Trading Card Inspector

-- MAIN APPLICATION
addappid(3723750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723751,0,"992e6d7da94a7f791ad2541101970268f977fcc603293cf9f8a879792b412995")

