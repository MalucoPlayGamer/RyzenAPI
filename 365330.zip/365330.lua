-- Lua provided by RyzenAPI
-- Game: Game: iaidoka_interlude

-- MAIN APPLICATION
addappid(365330)
-- Game: addappid(365330)

-- MAIN APP DEPOTS / PACKAGES
addappid(365331, 1, "44d63d897486ed75dfb44904098d5405a99cc640bb571ab55b7d56ee632cc8d5")
