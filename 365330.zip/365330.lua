-- Lua provided by RyzenAPI 
-- Game: iaidoka_interlude
addappid(365330)
addappid(365331, 1, "44d63d897486ed75dfb44904098d5405a99cc640bb571ab55b7d56ee632cc8d5")
