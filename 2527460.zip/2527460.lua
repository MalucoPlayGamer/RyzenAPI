-- Lua provided by RyzenAPI
-- Game: Arcana Alchemia

-- MAIN APPLICATION
addappid(2527460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2527461, 1, "496bbe368c7728a91cc3cd45e78f711a1389b4bc48be030f8d8795869776618f")

