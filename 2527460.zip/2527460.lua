-- Lua provided by RyzenAPI
-- Game: Arcana Alchemia

-- MAIN APPLICATION
addappid(2527460)
-- Game: addappid(2527460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527461, 1, "496bbe368c7728a91cc3cd45e78f711a1389b4bc48be030f8d8795869776618f")
