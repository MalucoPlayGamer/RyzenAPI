-- Lua provided by RyzenAPI
-- Game: There Is No Game: Jam Edition 2015

-- MAIN APPLICATION
addappid(1241700)
