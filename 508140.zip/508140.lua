-- Lua provided by RyzenAPI 
-- Game: AppID 508140
addappid(508140)
addappid(508141, 1, "d3d4ac8f851b14994be3848b26e799f26ad0fd211c93a81e55b267c36302bd28")
