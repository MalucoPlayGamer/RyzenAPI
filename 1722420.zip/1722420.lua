-- Lua provided by RyzenAPI
-- Game: Game: Cologne 3D

-- MAIN APPLICATION
addappid(1722420)
-- Game: addappid(1722420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722421, 1, "c2330e43837f21c0642826e1e5b41ebfaf9f44f6fbab87a2e7d99920515e63ba")
