-- Lua provided by RyzenAPI
-- Game: 1078320

-- MAIN APPLICATION
addappid(1078320)
addappid(1989450)
-- Game: addappid(1078320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078321, 1, "4bd190ebd1862d7a2cdeb1711f7c72d1e87524cfe0edb93854149fa401abd503")
addappid(1078322, 1, "5c8468af21987ffff1fb3d99ef36091edc26b2f76d7fe252d6a5c790da3f7e46")
addappid(1078323, 1, "1a3831c7a7779dea5ebaa66b2fca5a12b5115e755af8c6a040f4cc506ce4a7db")
