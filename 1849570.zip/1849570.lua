-- Lua provided by RyzenAPI
-- Game: Love Stories: When Pastel Meets Grotesque

-- MAIN APPLICATION
addappid(1849570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849572,0,"2495c1a42b50376c637f370a1abcb3b0c891bf6cad365b3b7d38dd0ec4ab7b30")

