-- Lua provided by RyzenAPI
-- Game: Led It Rain VR

-- MAIN APPLICATION
addappid(1088160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088161, 1, "8e5136b1551b6ccb119d689a63a561a66cb75aa1cadbd242c6d96290f4e5fb76")

