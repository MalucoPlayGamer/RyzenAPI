-- Lua provided by RyzenAPI
-- Game: addappid(357770)

-- MAIN APPLICATION
addappid(357770)

-- MAIN APP DEPOTS / PACKAGES
addappid(357771, 1, "e2a890d6458a7d79a9dcef594eeeea7c5dfb19f6a8ef7a38872dda4b40e995bd")
