-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] Onryo | 怨霊

-- MAIN APPLICATION
addappid(1267310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267311, 1, "739dfa3a8ca9993cdc4465094ef3a78238555f53beacbc188da4046451562c35")

