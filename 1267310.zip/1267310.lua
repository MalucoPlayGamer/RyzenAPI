-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] Onryo | 怨霊

-- MAIN APPLICATION
addappid(1267310)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1267311, 1, "739dfa3a8ca9993cdc4465094ef3a78238555f53beacbc188da4046451562c35")

