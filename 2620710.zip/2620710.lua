-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2620710)
-- Game: addappid(2620710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620712,0,"8cd49294b0f370fa8906149ae6369b21c991ff1baf5aef7bf8658c7f1b4c91fd")
