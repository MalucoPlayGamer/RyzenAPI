-- Lua provided by RyzenAPI
-- Game: Kingdom Come: Deliverance – OST Essentials

-- MAIN APPLICATION
addappid(794220)

-- MAIN APP DEPOTS / PACKAGES
addappid(794220,0,"de3c5ab13fbb0b4db72d4ac98003270686f9a05812e94fc0f5dd444e0f7ae344")
