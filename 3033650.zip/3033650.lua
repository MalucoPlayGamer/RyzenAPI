-- Lua provided by RyzenAPI
-- Game: Dragonscale Monastery Demo

-- MAIN APPLICATION
addappid(3033650)
-- Game: addappid(3033650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033651, 1, "567e5e477b9e6a354c905eda7d243e155338338e4e0178b95ef3d5d7eb599c6c")
