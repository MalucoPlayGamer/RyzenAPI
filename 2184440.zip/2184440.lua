-- Lua provided by RyzenAPI
-- Game: ASU Global

-- MAIN APPLICATION
addappid(2184440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184442,0,"4f6be7b9f01d2f1877c5e645455742fbe5c61b33f8f9c1e256a01a6ed158e8a4")

