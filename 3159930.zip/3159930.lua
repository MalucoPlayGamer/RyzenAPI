-- Lua provided by RyzenAPI
-- Game: Cats in the Forbidden City

-- MAIN APPLICATION
addappid(3159930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159931, 1, "93d0cf38c66ae17f036e8d6d1176a6b4347c8d385c26c1d665e5b515f523b09d")

