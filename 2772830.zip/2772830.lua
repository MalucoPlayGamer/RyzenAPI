-- Lua provided by RyzenAPI
-- Game: Vespera_Hotel

-- MAIN APPLICATION
addappid(2772830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2772831, 1, "b38aa851dca39877187a055d7f8a5cb086246476f915630d8a14a972e24babfe")

