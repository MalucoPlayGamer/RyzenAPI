-- Lua provided by RyzenAPI
-- Game: Game: Vespera_Hotel

-- MAIN APPLICATION
addappid(2772830)
-- Game: addappid(2772830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772831, 1, "b38aa851dca39877187a055d7f8a5cb086246476f915630d8a14a972e24babfe")
