-- Lua provided by RyzenAPI
-- Game: Truck Racer

-- MAIN APPLICATION
addappid(256070)
-- Game: addappid(256070)

-- MAIN APP DEPOTS / PACKAGES
addappid(256071, 1, "7a11b3282c953c72a2e4bdb9f92ba7056b36a78b3c227edbe3fa39344848fc3b")
