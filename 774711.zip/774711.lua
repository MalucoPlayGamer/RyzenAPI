-- Lua provided by RyzenAPI
-- Game: 774711

-- MAIN APPLICATION
addappid(774711)
addappid(774712)

-- MAIN APP DEPOTS / PACKAGES
addappid(774713,0,"79253872a49ce3e92a99bce73e94cf649fc3e2cc738f52adeecb6bb5e7a5957f")

