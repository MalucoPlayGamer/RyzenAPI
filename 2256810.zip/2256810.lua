-- Lua provided by RyzenAPI
-- Game: addappid(2256810)

-- MAIN APPLICATION
addappid(2256810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256811, 1, "cd126dd3ac7a3b081723c4d23dfd733595d3df0db063fd572d99410e5bb3a3f6")
