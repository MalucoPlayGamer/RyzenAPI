-- Lua provided by RyzenAPI
-- Game: Game: Through the Nightmares

-- MAIN APPLICATION
addappid(1266210)
-- Game: addappid(1266210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266211, 1, "33b4541b986e768f05d4bd8fdf23275005282dcd09eeea6c39f8daffc0252deb")
