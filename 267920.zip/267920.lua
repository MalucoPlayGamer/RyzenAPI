-- Lua provided by RyzenAPI
-- Game: addappid(267920)

-- MAIN APPLICATION
addappid(267920)

-- MAIN APP DEPOTS / PACKAGES
addappid(267921, 1, "04db5f5ad8ee6866d67ca87f21e7d826d6da8f630e853cd762904bd5f5eaeba7")
