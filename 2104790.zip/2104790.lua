-- Lua provided by RyzenAPI
-- Game: Griddy

-- MAIN APPLICATION
addappid(2104790)
-- Game: addappid(2104790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104791, 1, "2f6d6b58100945df3b00b41cfa76f24e8722fc161d38349e69e31fd3773e772d")
