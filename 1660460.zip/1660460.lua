-- Lua provided by RyzenAPI
-- Game: Hoples

-- MAIN APPLICATION
addappid(1660460)
-- Game: addappid(1660460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660461, 1, "da5da2383cbc3d8a42712a0c6606b5f3d784aa842543832302b7fef274aa041c")
