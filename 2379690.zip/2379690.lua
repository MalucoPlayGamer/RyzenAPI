-- Lua provided by RyzenAPI
-- Game: Retirement Home Tower Defense

-- MAIN APPLICATION
addappid(2379690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379691, 1, "7efadbc63db48b317367a333f55c1dc3ddec4b1aac16855bd5ba05b4841a9d68")

