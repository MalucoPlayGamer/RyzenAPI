-- Lua provided by RyzenAPI
-- Game: Retirement Home Tower Defense

-- MAIN APPLICATION
addappid(2379690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379691, 1, "7efadbc63db48b317367a333f55c1dc3ddec4b1aac16855bd5ba05b4841a9d68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
