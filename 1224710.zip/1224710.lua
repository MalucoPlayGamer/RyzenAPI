-- Lua provided by RyzenAPI
-- Game: 洞穴探险队 Caver

-- MAIN APPLICATION
addappid(1224710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224711, 1, "eb05a9eb8bc8f594e774bbbd03337fc050a1ae7011b8750a8fc8b19e27aa97bf")
