-- Lua provided by RyzenAPI
-- Game: addappid(1631230)

-- MAIN APPLICATION
addappid(1631230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631231, 1, "a4890c5d09043e1a6f0fa50ff15722af3720ce476044e9d6cbc330183e356a0c")
