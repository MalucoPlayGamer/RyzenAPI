-- Lua provided by RyzenAPI
-- Game: addappid(497800)

-- MAIN APPLICATION
addappid(497800)

-- MAIN APP DEPOTS / PACKAGES
addappid(497801, 1, "dabded1f278652d00db4814d1cc9f989b28c5bbf90a37107c7a340fb58eb5758")
