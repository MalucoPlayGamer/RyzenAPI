-- Lua provided by RyzenAPI
-- Game: Game: Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles

-- MAIN APPLICATION
addappid(1490890)
addappid(1669200)
addappid(1669201)
addappid(1669202)
addappid(1669203)
addappid(1669204)
addappid(1769970)
addappid(1769971)
addappid(1977370)
addappid(1977380)
addappid(1977381)
addappid(1981880)
addappid(1981881)
addappid(1981882)
addappid(1981883)
addappid(1981884)
addappid(1981930)
addappid(1996370)
-- Game: addappid(1490890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490891, 1, "20196f9d842139359a0275126f03992d9510d5b96c4213c38ad6d95c6d72d402")
addappid(1490892, 1, "bdc29d9de058b8459886d61b7f88c71610e007379c25d7965d289e5a5ef2c35b")
addappid(1490893, 1, "aff3930bfe0975c776a9dbe8c34b6b96167ab0db098e0764ba3b15b288ed1548")
addappid(1490894, 1, "d2ec4b7a405fdbac76fa443457c80f5b157516d888a2c8abe599a50033cf2e32")
addappid(1760470, 0, "70a688482c965ca7753eff82322f589bf14c05bcc6e641908f54ab17610a84b0")
addappid(1760480, 0, "82dca9e50950f252b389747c8f4e33a4754f34fd7d8e93b2d8a013532b6a4d0e")
addappid(1760490, 0, "c5e244432a04f26054022a4f38c1419c2c743df9b79d9a706bdf38cf2fb41856")
addappid(1760500, 0, "07cfb0664655d5544016861463b28175d000e7880ecaea791cc4739c26f8069f")
addappid(1777140, 0, "010c8f072b3fc9a3f7b089be2e56dedc947bc221f9bf5ee6e98bb09bc6d0b032")
