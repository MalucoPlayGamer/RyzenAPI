-- Lua provided by RyzenAPI
-- Game: 952120

-- MAIN APPLICATION
addappid(952120)
-- Game: addappid(952120)

-- MAIN APP DEPOTS / PACKAGES
addappid(952121, 1, "d93cb031217aef410b88f27618d94717fa52de594f3e54b51d4ef42f55359821")
