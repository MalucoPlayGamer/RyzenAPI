-- Lua provided by RyzenAPI
-- Game: Three Kingdoms 2018 阿达三国志2018 简体中文 竖版

-- MAIN APPLICATION
addappid(952120)

-- MAIN APP DEPOTS / PACKAGES
addappid(952121, 1, "d93cb031217aef410b88f27618d94717fa52de594f3e54b51d4ef42f55359821")

