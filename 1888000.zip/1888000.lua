-- Lua provided by RyzenAPI
-- Game: Bloody Rampage City

-- MAIN APPLICATION
addappid(1888000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888001, 1, "718f12549751486eb362065d8ed1c8568763bd8be11f207eb242b0e47cf25992")
