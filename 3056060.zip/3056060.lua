-- Lua provided by RyzenAPI
-- Game: Cheese Collector

-- MAIN APPLICATION
addappid(3056060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056061, 1, "90bdfce153d73fdde6832fab4cafa8cfcb21e1729fd1c83d3bd217bb6b46bdca")

