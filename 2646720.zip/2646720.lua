-- Lua provided by RyzenAPI
-- Game: Dead Weight

-- MAIN APPLICATION
addappid(2646720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646721,0,"6ffb22934c2201fc62cde9db6cd75d6b21c506cc4bf7e070364a532ca19f02ed")

