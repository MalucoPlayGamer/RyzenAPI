-- Lua provided by RyzenAPI
-- Game: addappid(1514540)

-- MAIN APPLICATION
addappid(1514540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514541, 1, "cf57623e3bddbc12d2d208c1fb3d6f2f81759f1910dfb0cc446f974dcbfa1e36")
