-- Lua provided by SkyAPI 
-- Game: 急射小机枪大战天启尸潮 Demo
addappid(1514540)
addappid(1514541, 1, "cf57623e3bddbc12d2d208c1fb3d6f2f81759f1910dfb0cc446f974dcbfa1e36")
