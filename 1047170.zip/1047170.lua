-- Lua provided by RyzenAPI
-- Game: AppID 1047170

-- MAIN APPLICATION
addappid(1047170)
-- Game: addappid(1047170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047171, 1, "a89a5818c57035abdbf89361d9f379db34040e798b31dc626936c77dceb864e0")
