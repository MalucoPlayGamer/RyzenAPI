-- Lua provided by RyzenAPI
-- Game: Your Love Ai

-- MAIN APPLICATION
addappid(3826970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3826971,0,"2680f888783ca5b990cad47617cc7d6888ccd7c35cf8356e135cfbea5d93811a")

