-- Lua provided by RyzenAPI
-- Game: Archeologist Simulator

-- MAIN APPLICATION
addappid(1439190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439191, 1, "eac93e13d857f4f002a20f2650b7a73e64c8c4f380c19920eb118efff01414de")

