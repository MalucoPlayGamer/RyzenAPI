-- Lua provided by RyzenAPI
-- Game: AppID 291390

-- MAIN APPLICATION
addappid(291390)

-- MAIN APP DEPOTS / PACKAGES
addappid(291391, 1, "608e5dc21a53591bb8f42e64e780118884b63e2fd5bf2540df2f042f83f57306")
addappid(291392, 1, "a64cee753d8dffe807f3df924347119dc74ebe6f014ef0a9874565d6cd974c29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
