-- Lua provided by RyzenAPI
-- Game: AppID 358410

-- MAIN APPLICATION
addappid(358410)
-- Game: addappid(358410)

-- MAIN APP DEPOTS / PACKAGES
addappid(358411, 1, "19849d0221113af16bb987cae4ba5f6c2f206b69e4dcc139ee3fab5b6ba961db")
addappid(358412, 1, "6f245a548c493c235c89619ee0eb9be052cef8ca60da5bc4a2730475d7a2be92")
