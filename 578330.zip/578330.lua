-- Lua provided by RyzenAPI
-- Game: LEGO® City Undercover

-- MAIN APPLICATION
addappid(578330)

-- MAIN APP DEPOTS / PACKAGES
addappid(578331, 1, "44ff08a81901dccc5bc670947c0f15975cb4bb01eb44faad587a3d10424ae17a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
