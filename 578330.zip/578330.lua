-- Lua provided by RyzenAPI
-- Game: addappid(578330)

-- MAIN APPLICATION
addappid(578330)

-- MAIN APP DEPOTS / PACKAGES
addappid(578331, 1, "44ff08a81901dccc5bc670947c0f15975cb4bb01eb44faad587a3d10424ae17a")
