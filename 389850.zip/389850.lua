-- Lua provided by RyzenAPI
-- Game: addappid(389850)

-- MAIN APPLICATION
addappid(228985)
addappid(389850)

-- MAIN APP DEPOTS / PACKAGES
addappid(389853,0,"eefd5e23aefcfbab554a5f4b0532cd1cc447b18a7a68d71a8436303fa51568b9")
