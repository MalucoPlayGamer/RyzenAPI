-- Lua provided by RyzenAPI
-- Game: Game: Dracula: Origin

-- MAIN APPLICATION
addappid(11050)
addappid(229033)
-- Game: addappid(11050)

-- MAIN APP DEPOTS / PACKAGES
addappid(11051, 1, "bd512cb29b3c0f0300e5d43d6f6ac512a9ee5464fb85dd22b64f810cc201f29e")
addappid(11052, 1, "19b5037aaaf771332167b11f6773f2143acfda7c8efc1581a78901bb8938d195")
addappid(11053, 1, "a8fcbf1fb8feaf5975491a71cdbee45b3b9752b15b9c32c0a3d4e0c88cb3901a")
addappid(11054, 1, "7ffb33ca5ac1aa632c24655810a2575f5ee05187c379e8f0009e63cc6cd1c9da")
addappid(11055, 1, "ba091a6399d33e107761365b51c9b3ba8592884c1bc599bf20c4d4751d1ef6b7")
addappid(11056, 1, "8d7b107810dd03f39ed73f2c8d41c7601c8afb45bcf2772436b6992b0cafc9ae")
addappid(11057, 1, "217d767fef4305f51c37deb8889b80dc540ee287bd143e4f0c106ce7a06010b0")
addappid(11058, 1, "fa20b7c375e367fc3ea194bd93a682b63bb55cdf3f5c303415c813193d41a813")
addappid(11059, 1, "ffaafdc39115957965b1ebed82cb45cecd2257145fc8a0bbbfd5b03e1849b655")
