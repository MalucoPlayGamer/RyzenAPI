-- Lua provided by RyzenAPI
-- Game: Save and Survive

-- MAIN APPLICATION
addappid(2878360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878361, 1, "5cd0d0032181b60d8b4aa2a8f39eb7adc1b2940dfe32793dd0129c71d1d85ee5")

