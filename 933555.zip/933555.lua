-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Weapons Samurai Warriors Pack 5

-- MAIN APPLICATION
addappid(933555)

-- MAIN APP DEPOTS / PACKAGES
addappid(933555,0,"e997e23174982354576af8e250750d0220b470506929d9b548bc42ad7e0c7389")

