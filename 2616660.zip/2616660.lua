-- Lua provided by RyzenAPI
-- Game: addappid(2616660)

-- MAIN APPLICATION
addappid(2616660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616661, 1, "9fbb30448e08e3730e68e45701a6b2b280fb7c6044cbb0c358dbf0b09de1a1de")
