-- Lua provided by RyzenAPI 
-- Game: Ultra Foodmess 2 Demo
addappid(2616660)
addappid(2616661, 1, "9fbb30448e08e3730e68e45701a6b2b280fb7c6044cbb0c358dbf0b09de1a1de")
