-- Lua provided by RyzenAPI
-- Game: 剑心崛起

-- MAIN APPLICATION
addappid(2873100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873101, 1, "2240d5c461d7c3bb1c65da715dfe5f2352cb347bb4253dc1fc3916b54c66d57b")

