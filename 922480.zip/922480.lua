-- Lua provided by RyzenAPI
-- Game: Game: Auto Battle Royale

-- MAIN APPLICATION
addappid(922480)
-- Game: addappid(922480)

-- MAIN APP DEPOTS / PACKAGES
addappid(922481, 1, "f24dc3de91b3c95ee01726aa4c8fe8eb9a70c6537822e977f178a82e3bf56736")
addappid(922482, 1, "d262efdd5dd5675f94ca0c50da0a0ad3aef3a50406f37f606cad5fca94c8b417")
