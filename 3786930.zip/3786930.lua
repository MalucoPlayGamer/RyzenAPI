-- Lua provided by RyzenAPI
-- Game: addappid(3786930)

-- MAIN APPLICATION
addappid(3786930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3786931, 1, "6f28fcbb60edd23913692fd30862517e6bd4d46bafaff48c9b9fd85f35c187e9")
