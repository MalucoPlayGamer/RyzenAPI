-- Lua provided by RyzenAPI
-- Game: addappid(860530)

-- MAIN APPLICATION
addappid(860530)

-- MAIN APP DEPOTS / PACKAGES
addappid(860531, 1, "c26795652f02a8d1615f97c109e046c1664971a19cecfe17f2e79c9f6cd1d743")
