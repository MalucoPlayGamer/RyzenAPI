-- Lua provided by RyzenAPI
-- Game: Mech Builder

-- MAIN APPLICATION
addappid(2870420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870421, 1, "9740b034c8f797deda1999d63c23282f1d6c1420fd7e3eb3a38aed9b15c5f9a7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3198690)
addappid(3198710)
addappid(3930850)
