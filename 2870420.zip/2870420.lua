-- Lua provided by RyzenAPI
-- Game: addappid(2870420)

-- MAIN APPLICATION
addappid(2870420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870421, 1, "9740b034c8f797deda1999d63c23282f1d6c1420fd7e3eb3a38aed9b15c5f9a7")
