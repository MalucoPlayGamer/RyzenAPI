-- Lua provided by SkyAPI 
-- Game: Mech Builder
addappid(2870420)
addappid(2870421, 1, "9740b034c8f797deda1999d63c23282f1d6c1420fd7e3eb3a38aed9b15c5f9a7")
