-- Lua provided by RyzenAPI
-- Game: AppID 279260

-- MAIN APPLICATION
addappid(279260)

-- MAIN APP DEPOTS / PACKAGES
addappid(279261, 1, "18b1893b13207f2ec09fcb019fec477141cbe6d6f25eaeeec9968d543c13ce3f")

