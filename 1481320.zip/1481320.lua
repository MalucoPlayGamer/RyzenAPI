-- Lua provided by RyzenAPI
-- Game: Game: AppID 1481320

-- MAIN APPLICATION
addappid(1481320)
-- Game: addappid(1481320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481321, 1, "b9cfff11870a6f997369c4d58d6d654723fe63ec2271bf8e90db3059bf9de5a2")
addappid(1481322, 1, "86599c33dd16c77f321f7259fb15275c7cc5681a61abe10daaef85e924bb0f6a")
