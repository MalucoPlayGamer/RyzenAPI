-- Lua provided by RyzenAPI
-- Game: Woodboy

-- MAIN APPLICATION
addappid(955860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(955861, 1, "6651a2fece30679dedd7beefc1782d1dd430ddeb45b51d9c80c279e03c924007")

