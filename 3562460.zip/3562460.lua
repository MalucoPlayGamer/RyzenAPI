-- Lua provided by RyzenAPI
-- Game: 3562460

-- MAIN APPLICATION
addappid(3562460)
-- Game: addappid(3562460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3562461, 1, "b10613bec3c3e33c82630b3dde8e6cd804eed9fdc636c2ec87f4d9d1eb9c6f33")
