-- Lua provided by SkyAPI 
-- Game: The Whispering Woods
addappid(3562460)
addappid(3562461, 1, "b10613bec3c3e33c82630b3dde8e6cd804eed9fdc636c2ec87f4d9d1eb9c6f33")
