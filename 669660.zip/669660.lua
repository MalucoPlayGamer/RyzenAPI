-- Lua provided by RyzenAPI
-- Game: addappid(669660)

-- MAIN APPLICATION
addappid(669660)

-- MAIN APP DEPOTS / PACKAGES
addappid(669661, 1, "0fcf28b8e849dc438b256034ed7e7e3d4d93fcf1d77038f77adb674e3440734d")
