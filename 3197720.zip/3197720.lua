-- Lua provided by RyzenAPI
-- Game: Game: Him, the Smile ＆ bloom

-- MAIN APPLICATION
addappid(3197720)
addappid(3282830)
-- Game: addappid(3197720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197721, 1, "efc30a9a5d3b9483d2189a111f3f07c99c719c5656b7296e204658a903043690")
