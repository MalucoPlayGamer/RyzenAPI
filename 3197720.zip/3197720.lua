-- Lua provided by RyzenAPI 
-- Game: Him, the Smile ＆ bloom
addappid(3197720)
addappid(3197721, 1, "efc30a9a5d3b9483d2189a111f3f07c99c719c5656b7296e204658a903043690")
addappid(3282830)
