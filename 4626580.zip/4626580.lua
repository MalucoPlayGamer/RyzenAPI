-- Lua provided by RyzenAPI
-- Game: Endless Isolation

-- MAIN APPLICATION
addappid(4626580) -- Endless Isolation

-- MAIN APP DEPOTS / PACKAGES
addappid(4626581, 1, "969369973bf98f7917ee2a50ba8abd746f7fc418fc412f319b42cdf96ff5e816") -- Depot 4626581

