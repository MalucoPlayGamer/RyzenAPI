-- Lua provided by RyzenAPI
-- Game: Space Live - Advent of the Net Idols

-- MAIN APPLICATION
addappid(421710)

-- MAIN APP DEPOTS / PACKAGES
addappid(421711, 1, "74dc9f21465157b57a3cd4427b77d3b8eef4a495030972b8f007adc89dc6b314")
addappid(421712, 1, "e99ed637565cacdf8527341e79627552078747777e1e525c5ea15dc51ecfc56e")
addappid(421713, 1, "1b8ff62611320539c24f1afec65a730d46da5b31b0c1951f0aae4597b673c9ad")
