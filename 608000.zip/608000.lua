-- Lua provided by RyzenAPI
-- Game: Buzz Aldrin: Cycling Pathways to Mars

-- MAIN APPLICATION
addappid(608000)

-- MAIN APP DEPOTS / PACKAGES
addappid(608001, 1, "9d5cca365f9dc8d96ac8b5e008f6b798d5d3d519fd079490b080489d28ec480a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
