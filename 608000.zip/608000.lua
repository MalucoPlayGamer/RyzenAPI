-- Lua provided by RyzenAPI 
-- Game: Buzz Aldrin: Cycling Pathways to Mars
addappid(608000)
addappid(608001, 1, "9d5cca365f9dc8d96ac8b5e008f6b798d5d3d519fd079490b080489d28ec480a")
