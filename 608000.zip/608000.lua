-- Lua provided by RyzenAPI
-- Game: addappid(608000)

-- MAIN APPLICATION
addappid(608000)

-- MAIN APP DEPOTS / PACKAGES
addappid(608001, 1, "9d5cca365f9dc8d96ac8b5e008f6b798d5d3d519fd079490b080489d28ec480a")
