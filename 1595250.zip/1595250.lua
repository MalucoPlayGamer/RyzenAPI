-- Lua provided by RyzenAPI
-- Game: Dirty Blood

-- MAIN APPLICATION
addappid(1595250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595251, 1, "089cdc3c9b27063411c72acf0b84edd4734bb3182544cfa03c70cf1973e73679")

