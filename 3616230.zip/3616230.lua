-- Lua provided by SkyAPI 
-- Game: GLYPHS
addappid(3616230)
addappid(3616231, 1, "8628299a0eda426439e7759c507a0fd9a1b777078584c9f1b38a613743506755")
