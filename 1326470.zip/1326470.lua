-- Lua provided by RyzenAPI
-- Game: Sons Of The Forest

-- MAIN APPLICATION
addappid(1326470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326471, 1, "dcc8b76a7563c836c1aed54a46abf85e7fec5fccabc0dd8e176d2151173e508e")

