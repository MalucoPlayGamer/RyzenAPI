-- Lua provided by RyzenAPI
-- Game: How Old is James? Demo

-- MAIN APPLICATION
addappid(3095620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095621, 1, "1b5d2ba9680b49da5e3920be07dae16ff4421e986c8129332f4d19982f4ca7db")
