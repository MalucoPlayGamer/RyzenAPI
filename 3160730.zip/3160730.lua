-- Lua provided by RyzenAPI
-- Game: Bunnies Huddled Together

-- MAIN APPLICATION
addappid(3160730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160731, 1, "e5be3eefa3152d31e0772f3e5c834bb30c33a71e48147d04dc4bc7661156c3ca")

