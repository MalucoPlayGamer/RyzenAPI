-- Lua provided by RyzenAPI
-- Game: addappid(1341470)

-- MAIN APPLICATION
addappid(1341470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341471, 1, "b07e49f4d69468a972db15398f05526e05cccd9c5790bc39c1b9c76e54c3a706")
