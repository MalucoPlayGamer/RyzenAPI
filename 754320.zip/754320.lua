-- Lua provided by RyzenAPI
-- Game: Pixel Noir

-- MAIN APPLICATION
addappid(754320)
-- Game: addappid(754320)

-- MAIN APP DEPOTS / PACKAGES
addappid(754322,0,"fe5aff76f7ed310c68c77a5449e3ede09a3d863f6f4d48f58af03369d6978314")
addappid(754323,0,"ae4d9ffa4bac3f8435e5d5cd94654370010cfffed8410a140bcb6352cb75c736")
addappid(754324,0,"06a7e5d77ca5b58d825ce6879e374bce093319262dffe9f8ba8a74a7dd52fe81")
