-- Lua provided by RyzenAPI
-- Game: Forgotlings

-- MAIN APPLICATION
addappid(2059570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059571,0,"c7b5777084612a0ded801bf50657a90471e277e77fac6a2a970b5efd93245987")
addappid(4414390,0,"c16d98b707c5aa7f682fa2224decb8dc9cfc7b2f333caa6f29dac24647ce2545")

