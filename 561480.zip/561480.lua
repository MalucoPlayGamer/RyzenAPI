-- Lua provided by RyzenAPI
-- Game: addappid(561480)

-- MAIN APPLICATION
addappid(561480)

-- MAIN APP DEPOTS / PACKAGES
addappid(561481, 1, "ad7984f01a8b75c68d026fc22b43f77226ec01ba30f6d21f1b7e77f79d5dac25")
