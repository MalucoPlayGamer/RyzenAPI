-- Lua provided by SkyAPI 
-- Game: AppID 561480
addappid(561480)
addappid(561481, 1, "ad7984f01a8b75c68d026fc22b43f77226ec01ba30f6d21f1b7e77f79d5dac25")
