-- Lua provided by RyzenAPI
-- Game: 96 Mill

-- MAIN APPLICATION
addappid(561480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(561481, 1, "ad7984f01a8b75c68d026fc22b43f77226ec01ba30f6d21f1b7e77f79d5dac25")
