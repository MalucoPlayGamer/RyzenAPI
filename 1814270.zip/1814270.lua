-- Lua provided by RyzenAPI
-- Game: Game: Metallophobia

-- MAIN APPLICATION
addappid(1814270)
-- Game: addappid(1814270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814271, 1, "3c3856014b256ae30aeb53c49892b75528144800a8448ce3e2c0299dc6e742c6")
