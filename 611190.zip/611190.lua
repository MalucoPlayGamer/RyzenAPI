-- Lua provided by RyzenAPI
-- Game: Game: ROGUE SHIFT

-- MAIN APPLICATION
addappid(611190)
-- Game: addappid(611190)

-- MAIN APP DEPOTS / PACKAGES
addappid(611191, 1, "94665d371467a9ddd89e6ca370c6e9bef71afd7deec904bc5bd4b740ba49673c")
