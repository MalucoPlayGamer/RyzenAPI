-- Lua provided by RyzenAPI
-- Game: Game: Ritual Night

-- MAIN APPLICATION
addappid(1834980)
-- Game: addappid(1834980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1834981, 1, "471be04c66d6b4e5441bdb06a86891f197049d8a2461b28deffcddebdf1b4d08")
