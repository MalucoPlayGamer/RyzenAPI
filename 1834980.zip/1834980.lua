-- Lua provided by RyzenAPI
-- Game: Ritual Night

-- MAIN APPLICATION
addappid(1834980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1834981, 1, "471be04c66d6b4e5441bdb06a86891f197049d8a2461b28deffcddebdf1b4d08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3264470)
addappid(3266340)
