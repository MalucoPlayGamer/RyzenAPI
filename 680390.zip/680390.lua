-- Lua provided by RyzenAPI
-- Game: Hidden Dragon: Legend

-- MAIN APPLICATION
addappid(680390)

-- MAIN APP DEPOTS / PACKAGES
addappid(680391,0,"1bb8a3105586cb6bf88cda2f300680ab9f319b83edf1be6eb925611662e9153f")
addappid(803100,0,"2080388d8a70d133a247162f5bef480a5612aacac656c25dcd9f981113e9737f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
