-- Lua provided by RyzenAPI
-- Game: Hidden Dragon: Legend

-- MAIN APPLICATION
addappid(680390)

-- MAIN APP DEPOTS / PACKAGES
addappid(680391,0,"1bb8a3105586cb6bf88cda2f300680ab9f319b83edf1be6eb925611662e9153f")
addappid(803100,0,"2080388d8a70d133a247162f5bef480a5612aacac656c25dcd9f981113e9737f")

