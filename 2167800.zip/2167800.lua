-- Lua provided by RyzenAPI
-- Game: Idle Cyber Dungeon

-- MAIN APPLICATION
addappid(2167800)
-- Game: addappid(2167800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167801, 1, "d5fff08cb29efcf1d2a584032d93b1b99bc06f11781a9f0930fc36635b298b45")
