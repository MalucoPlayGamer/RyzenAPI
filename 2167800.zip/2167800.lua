-- Lua provided by SkyAPI 
-- Game: Idle Cyber Dungeon
addappid(2167800)
addappid(2167801, 1, "d5fff08cb29efcf1d2a584032d93b1b99bc06f11781a9f0930fc36635b298b45")
