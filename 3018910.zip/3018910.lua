-- Lua provided by RyzenAPI
-- Game: Game: Homeless

-- MAIN APPLICATION
addappid(3018910)
-- Game: addappid(3018910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018911, 1, "e73e226ca0ccba791c398672e55e15b5c8e433913c399c68a2fb78a936593848")
