-- Lua provided by RyzenAPI
-- Game: Homeless

-- MAIN APPLICATION
addappid(3018910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3018911, 1, "e73e226ca0ccba791c398672e55e15b5c8e433913c399c68a2fb78a936593848")

