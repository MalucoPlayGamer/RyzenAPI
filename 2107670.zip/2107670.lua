-- Lua provided by RyzenAPI
-- Game: Game: Warhaven

-- MAIN APPLICATION
addappid(2107670)
-- Game: addappid(2107670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107671, 1, "ff8753b5841d71183713c55f5b73151c70728a024780c8ef6602625a6d9774c0")
