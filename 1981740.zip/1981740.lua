-- Lua provided by RyzenAPI 
-- Game: Palmas
addappid(1981740)
addappid(1981741, 1, "ab82de49ce01b7b83d22bad8352239641838854e98d54398469d1602c0239078")
