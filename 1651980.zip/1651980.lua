-- Lua provided by RyzenAPI
-- Game: Game: Tizahl's Quest

-- MAIN APPLICATION
addappid(1651980)
-- Game: addappid(1651980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651981, 1, "1be60a87c39e9870986c066a303107fe05efb7839ec0d16604f3f47747e74249")
