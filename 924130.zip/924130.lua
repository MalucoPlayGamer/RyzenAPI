-- Lua provided by RyzenAPI
-- Game: Game: Slime-san: Creator

-- MAIN APPLICATION
addappid(924130)
-- Game: addappid(924130)

-- MAIN APP DEPOTS / PACKAGES
addappid(924131, 1, "94bb4c0a94d02889a43549c0d392114653dd52d8ecd5a98f9184208d576facf4")
addappid(924132, 1, "732a2bcf5e4487ce2c52f3ef54dc751e80db1c3b1f33c88499c84d77d83cef63")
addappid(924133, 1, "33ba20a346d2f1ffc3e37d8afad058e228368f259f707938769b10e4ec1c2a43")
addappid(924134, 1, "121f554d1876923416c0e92daa04556fed8005d2a37de74ed799c2816d179b68")
