-- Lua provided by RyzenAPI
-- Game: addappid(1293590)

-- MAIN APPLICATION
addappid(1293590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293590,0,"f3ecca40c28535495db0e6b948f66500cf9896f1154a86452bbc16fca8f4da6b")
