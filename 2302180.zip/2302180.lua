-- Lua provided by RyzenAPI
-- Game: Game: DESTROY Simulator VR

-- MAIN APPLICATION
addappid(2302180)
-- Game: addappid(2302180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302181, 1, "5438877376ee2c8e0f3075895846515134bf571bd0ac45546ef3fb3869e49a6c")
