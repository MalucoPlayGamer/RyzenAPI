-- Lua provided by RyzenAPI 
-- Game: DESTROY Simulator VR
addappid(2302180)
addappid(2302181, 1, "5438877376ee2c8e0f3075895846515134bf571bd0ac45546ef3fb3869e49a6c")
