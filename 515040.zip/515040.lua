-- Lua provided by RyzenAPI
-- Game: Make America Great Again: The Trump Presidency

-- MAIN APPLICATION
addappid(515040)
-- Game: addappid(515040)

-- MAIN APP DEPOTS / PACKAGES
addappid(515041, 1, "3b609c7b62753b45401d6e3f1a11ced9a38c3046190c4032c0b428e15457f817")
