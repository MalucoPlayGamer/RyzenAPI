-- Lua provided by RyzenAPI
-- Game: Lust for Darkness VR

-- MAIN APPLICATION
addappid(1563160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563161, 1, "6fec67a86dfb44541ce1e6ce954f2f886f7a2ca9b8009817965541555a474262")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
