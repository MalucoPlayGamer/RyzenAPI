-- Lua provided by RyzenAPI
-- Game: Game: Lust for Darkness VR

-- MAIN APPLICATION
addappid(1563160)
-- Game: addappid(1563160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563161, 1, "6fec67a86dfb44541ce1e6ce954f2f886f7a2ca9b8009817965541555a474262")
