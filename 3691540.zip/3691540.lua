-- Lua provided by RyzenAPI
-- Game: addappid(3691540)

-- MAIN APPLICATION
addappid(3691540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3691540,0,"7eadceb592dedc740c09d32c09a911612993d1ccb6947c05047f3c5915da9596")
