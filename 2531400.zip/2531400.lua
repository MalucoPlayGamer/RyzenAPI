-- Lua provided by RyzenAPI
-- Game: Audio Trip: Swanky Song Pack

-- MAIN APPLICATION
addappid(2531400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531400,0,"e7056f3a807b0dca1c5310bc983d78d110d01ed41589ce8fa79c534547507d9b")
