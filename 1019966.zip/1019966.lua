-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Additional Weapon "Tooth & Nail" / 追加武器「投牙弓」

-- MAIN APPLICATION
addappid(1019966)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019966,0,"0eb600f4ca81a67a4d4a1af63b18d0aceb184849ecf02c39aeb6062c1f66faed")

