-- Lua provided by RyzenAPI
-- Game: Evil God Korone

-- MAIN APPLICATION
addappid(1748610)
-- Game: addappid(1748610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748612,0,"96ed625e38f8f719faf47a1e6b7806e4d5d9ea5ae63e05cc5d8d7dcad03b7625")
addappid(1748614,0,"aa4edb2eda635e20b16810bcaa338caa84c5bd3f971003a76ffff7d053123442")
