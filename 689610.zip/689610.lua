-- Lua provided by RyzenAPI
-- Game: Hunt 'n Sneak

-- MAIN APPLICATION
addappid(689610)

-- MAIN APP DEPOTS / PACKAGES
addappid(689611,0,"0e752831ceb382a19cf731e9beb95b0e7724205fedb66fd89046826769848312")

