-- Lua provided by RyzenAPI
-- Game: Formula Legends

-- MAIN APPLICATION
addappid(3194360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194361, 1, "2eab901f3297c0706ad8606e564f7913bf97b561233741ca20f0de137d4142f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4060830)
addappid(4060840)
addappid(4143900)
addappid(4143910)
addappid(4143920)
addappid(4216430)
addappid(4222670)
addappid(4362310)
addappid(4362320)
