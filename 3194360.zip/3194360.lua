-- Lua provided by RyzenAPI
-- Game: Formula Legends

-- MAIN APPLICATION
addappid(3194360)
-- Game: addappid(3194360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194361, 1, "2eab901f3297c0706ad8606e564f7913bf97b561233741ca20f0de137d4142f3")
