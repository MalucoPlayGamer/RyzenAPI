-- Lua provided by RyzenAPI
-- Game: Sitting Ducks

-- MAIN APPLICATION
addappid(4397060)

-- MAIN APP DEPOTS / PACKAGES
addappid(4397061,0,"29cbf9a54c5a3b1ebb10307cb864ec39d6a07ebf12092cbb1cfa845a1d0053d6")

