-- Lua provided by RyzenAPI
-- Game: Sitting Ducks

-- MAIN APPLICATION
addappid(4397060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4397061,0,"29cbf9a54c5a3b1ebb10307cb864ec39d6a07ebf12092cbb1cfa845a1d0053d6")

