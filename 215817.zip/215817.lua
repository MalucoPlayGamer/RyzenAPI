-- Lua provided by RyzenAPI
-- Game: 215817

-- MAIN APPLICATION
addappid(215817)
-- Game: addappid(215817)

-- MAIN APP DEPOTS / PACKAGES
addappid(215817,0,"8fd4d8aa8b001d60e1d0c45e70a1d11b678884a844679fe8186a838715f7f128")
