-- Lua provided by RyzenAPI
-- Game: 3616070

-- MAIN APPLICATION
addappid(3616070)
-- Game: addappid(3616070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3616071, 1, "3ee78e46d9e4e22bcf739f0af257b6ca881c38dd984e2814a3031b02089da7e5")
