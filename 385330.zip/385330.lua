-- Lua provided by RyzenAPI
-- Game: Game: Stray Cat Crossing

-- MAIN APPLICATION
addappid(385330)
-- Game: addappid(385330)

-- MAIN APP DEPOTS / PACKAGES
addappid(385331, 1, "60be3b7f461e29387175a79bbf860835f868e44873f231c9d75bf8f01ebde1d0")
