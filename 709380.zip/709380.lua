-- Lua provided by RyzenAPI
-- Game: Circularity

-- MAIN APPLICATION
addappid(709380)

-- MAIN APP DEPOTS / PACKAGES
addappid(709381, 1, "e7011f71d980abfa8250a50e8c2a0765fbae667056afea33b2cedf3b6e45f446")
addappid(709382, 1, "d5da6474bc3ecf97ba34745a9b8e5bf539bdefac8247c6c5fd1d10e544de1f42")
addappid(709383, 1, "68581a0414f8f0c2a7c20e83b4e76c3082dbbb3934bf94a665788279652816aa")
addappid(709384, 1, "bb4e23aa46146afb89d5824c5fd6d5dca21d923e5c647d2bd6f319c5df0b24bb")
addappid(709385, 1, "0e3889a3ea983936d13bc824a0cda10448720a7333fbf435bc7a958ab56b89be")
