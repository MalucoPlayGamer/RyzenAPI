-- Lua provided by RyzenAPI
-- Game: Just Crow Things

-- MAIN APPLICATION
addappid(2537920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537921, 1, "45cf9fbc262eec34ddb3cce17f830867f537ef472002a004e2d07f0fc8788a6d")

