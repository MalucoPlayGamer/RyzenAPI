-- Lua provided by RyzenAPI
-- Game: 修真元界  XiuZhen Metaverse

-- MAIN APPLICATION
addappid(1807960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807961, 1, "7b6d935ca8fdf53c91605bddfb49fddd5a8a283631f15e9274442cba90a0a5f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
