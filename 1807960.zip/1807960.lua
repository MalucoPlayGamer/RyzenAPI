-- Lua provided by RyzenAPI
-- Game: addappid(1807960)

-- MAIN APPLICATION
addappid(1807960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807961, 1, "7b6d935ca8fdf53c91605bddfb49fddd5a8a283631f15e9274442cba90a0a5f6")
