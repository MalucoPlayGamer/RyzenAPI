-- Lua provided by SkyAPI 
-- Game: Puzzline
addappid(2088670)
addappid(2088671, 1, "222878297522456099ee85c6c05de5126f6a3abad126defd5c9ec9e69599c633")
