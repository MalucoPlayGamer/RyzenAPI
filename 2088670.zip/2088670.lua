-- Lua provided by RyzenAPI
-- Game: 2088670

-- MAIN APPLICATION
addappid(2088670)
-- Game: addappid(2088670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088671, 1, "222878297522456099ee85c6c05de5126f6a3abad126defd5c9ec9e69599c633")
