-- Lua provided by RyzenAPI
-- Game: DACHstudio Jigsaw Puzzle Box

-- MAIN APPLICATION
addappid(2833590)

