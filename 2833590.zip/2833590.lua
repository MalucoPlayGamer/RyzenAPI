-- Lua provided by RyzenAPI
-- Game: DACHstudio Jigsaw Puzzle Box

-- MAIN APPLICATION
addappid(2833590)
addappid(2865620)
addappid(2865630)
addappid(2876170)
addappid(2889050)
addappid(2928630)
addappid(3001630)
addappid(3051390)
addappid(3223950)
addappid(3380910)
addappid(3470380)
addappid(3560840)
addappid(3585910)
addappid(4155440)

