-- Lua provided by RyzenAPI
-- Game: Lost Island

-- MAIN APPLICATION
addappid(1837280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1837281, 1, "ec997232ff6fcdcd51f6f21457cbbd6f7a2791c4434e06ec8236e5e8958a9441")

