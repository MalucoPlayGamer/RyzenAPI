-- Lua provided by SkyAPI 
-- Game: Lost Island
addappid(1837280)
addappid(1837281, 1, "ec997232ff6fcdcd51f6f21457cbbd6f7a2791c4434e06ec8236e5e8958a9441")
