-- Lua provided by RyzenAPI
-- Game: An Other Golf Game Demo

-- MAIN APPLICATION
addappid(3274450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274451, 1, "ac0244e02466197d1507d4dca8b1e93f86d4a4537b583b3803685a55395526ad")
