-- Lua provided by RyzenAPI
-- Game: Game: AppID 937580

-- MAIN APPLICATION
addappid(937580)
-- Game: addappid(937580)

-- MAIN APP DEPOTS / PACKAGES
addappid(937581, 1, "5f85c99877d388a24913d32bcf8bd7bcaaa3004757419a8cfa1c97bea85391a3")
