-- Lua provided by RyzenAPI
-- Game: AppID 937580

-- MAIN APPLICATION
addappid(937580)

-- MAIN APP DEPOTS / PACKAGES
addappid(937581, 1, "5f85c99877d388a24913d32bcf8bd7bcaaa3004757419a8cfa1c97bea85391a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
