-- Lua provided by RyzenAPI 
-- Game: AppID 1203430
addappid(1203430)
addappid(1203431, 1, "269457448b7f664b47671c4d6d31dc8395021987fd6973e457f5364e24737ec3")
