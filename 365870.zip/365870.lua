-- Lua provided by RyzenAPI
-- Game: AppID 365870

-- MAIN APPLICATION
addappid(365870)
-- Game: addappid(365870)

-- MAIN APP DEPOTS / PACKAGES
addappid(365871, 1, "0efc9653078aca9ee92b48745e318021307aaa5bbd5e0a1e1e0192e2a207367b")
