-- Lua provided by RyzenAPI
-- Game: Freeways

-- MAIN APPLICATION
addappid(780210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(780211, 1, "fc6214507735818e62e64d94ab620d9391d6390a62b76e135b489483cdcd4ac0")
addappid(780212, 1, "d72ae46ccdd7fc790cff1f94142f98c782617e1803de262fbcb4d87ad6cf9a14")

