-- Lua provided by RyzenAPI
-- Game: Sweet Escape VR

-- MAIN APPLICATION
addappid(462480)
-- Game: addappid(462480)

-- MAIN APP DEPOTS / PACKAGES
addappid(462481, 1, "3a1ea247fd1979d1c070492e9429431af8f9cf76ac1f8ed6115877fec992a26e")
