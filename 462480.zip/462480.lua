-- Lua provided by RyzenAPI 
-- Game: Sweet Escape VR
addappid(462480)
addappid(462481, 1, "3a1ea247fd1979d1c070492e9429431af8f9cf76ac1f8ed6115877fec992a26e")
