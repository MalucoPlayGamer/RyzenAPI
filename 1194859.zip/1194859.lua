-- Lua provided by RyzenAPI
-- Game: 1194859

-- MAIN APPLICATION
addappid(1194859)
-- Game: addappid(1194859)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194859,0,"5244e605453fe1f32a592a72bbacbadf0373bb85ba9dc6d157da45918cb783a5")
