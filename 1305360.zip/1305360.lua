-- Lua provided by RyzenAPI
-- Game: 1305360

-- MAIN APPLICATION
addappid(1305360)
-- Game: addappid(1305360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305360,0,"203c34bb4c6b14fd1812454532dd3b72326807790b735edcc793b0cd456fafa6")
