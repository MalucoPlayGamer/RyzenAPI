-- Lua provided by RyzenAPI
-- Game: Game: AppID 214230

-- MAIN APPLICATION
addappid(214230)
-- Game: addappid(214230)

-- MAIN APP DEPOTS / PACKAGES
addappid(214231, 1, "3547ddc3808a205c910928fd8c68cee5f706a67ad7a2a41564a356273863ad8d")
addappid(214232, 1, "4ce2fd7aae28ce77f5f7f18b80cb7ea90baabb8532b6d5373f6e5f6e79efe1cc")
