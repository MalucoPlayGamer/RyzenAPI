-- Lua provided by RyzenAPI
-- Game: Watcher Of The Abyss

-- MAIN APPLICATION
addappid(2022030)
-- Game: addappid(2022030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022031, 1, "166041cf59e163405b81355f2a114f719b8da3a816177bc110d9325d000e63a8")
