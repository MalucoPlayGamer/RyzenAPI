-- Lua provided by RyzenAPI
-- Game: Shop-Like - The Rogue-Like Item Shop Experience

-- MAIN APPLICATION
addappid(1888450)
-- Game: addappid(1888450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888451, 1, "0a50836853e9168d2832766a767f8d345ca88e8da4a011ba8ef8ef71d2d9f697")
