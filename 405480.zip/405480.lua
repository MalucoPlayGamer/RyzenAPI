-- Lua provided by RyzenAPI
-- Game: Tomorrow

-- MAIN APPLICATION
addappid(405480)

-- MAIN APP DEPOTS / PACKAGES
addappid(405481, 1, "7a6423e28002ea6b109244b5b9c6dfddcec3b410974098a0f22a860932452b11")
