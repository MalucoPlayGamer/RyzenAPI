-- Lua provided by RyzenAPI
-- Game: Pic-Me!

-- MAIN APPLICATION
addappid(3265280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265281, 1, "c493caa2dc1caab54d2c3175e98e8967a73ef8b572aa3b9446c768fb9a0d9cee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
