-- Lua provided by RyzenAPI
-- Game: Higurashi When They Cry Hou - Ch.6 Tsumihoroboshi

-- MAIN APPLICATION
addappid(668350)

-- MAIN APP DEPOTS / PACKAGES
addappid(668351, 1, "6c4a7f4c52841397f660157461442b31702f16850b728ef9c72b52b3fc6f6c5b")

