-- Lua provided by RyzenAPI
-- Game: 3D Escape Room：Mystic Manor

-- MAIN APPLICATION
addappid(3612480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3612481, 1, "d5f6794ee8c1214a5f06e165aafe64a55c8a9118249457f0cf92a1cbd6332a15")

