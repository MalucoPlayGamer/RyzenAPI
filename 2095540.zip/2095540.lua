-- Lua provided by RyzenAPI
-- Game: Lurch

-- MAIN APPLICATION
addappid(2095540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095541, 1, "78ef975c3616d81b7b3c635796c82c6ba4ce4fe0c7dd749771f896deb0a4e5f8")
