-- Lua provided by RyzenAPI
-- Game: Lurch

-- MAIN APPLICATION
addappid(2095540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2095541, 1, "78ef975c3616d81b7b3c635796c82c6ba4ce4fe0c7dd749771f896deb0a4e5f8")

