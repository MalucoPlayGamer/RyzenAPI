-- Lua provided by RyzenAPI 
-- Game: Civil War: 1865
addappid(620630)
addappid(620631, 1, "445e33046e52e2165a6419e9bed7f152b74e0ff5911ffcfa0a2c2afec1276df6")
addappid(620632, 1, "37fb1014db28c291812e8fe99a14171e824e035328a573767439d9e2bd416bfa")
