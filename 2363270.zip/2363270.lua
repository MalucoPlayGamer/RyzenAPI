-- Lua provided by RyzenAPI
-- Game: Darkside

-- MAIN APPLICATION
addappid(2363270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363271, 1, "5e40d7117ab457410d42d5aa7ae61ae65d84714b73f0f3cc92cc263273c93c83")

