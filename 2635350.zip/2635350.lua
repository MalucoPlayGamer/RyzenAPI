-- Lua provided by RyzenAPI
-- Game: United Penguin Kingdom

-- MAIN APPLICATION
addappid(2635350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635351, 1, "f2daf32eb00314d34d9c47c1be8c9f983c39a5b5b74782a1e30f0884600e529f")
