-- Lua provided by RyzenAPI
-- Game: 1719790

-- MAIN APPLICATION
addappid(1719790)
-- Game: addappid(1719790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719791, 1, "479fedfcfac901b0b38c691983a74f46e2a9b3c201741190e00d9d9964e7309d")
