-- Lua provided by RyzenAPI
-- Game: addappid(1173140)

-- MAIN APPLICATION
addappid(1173140)
addappid(1173141)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173140,0,"012eaa221b0a375c66d62ef1f37f67519f22863c8931e98cfc1517defaae5334")
