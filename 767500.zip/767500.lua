-- Lua provided by RyzenAPI
-- Game: Once in Yaissor 2

-- MAIN APPLICATION
addappid(767500)

-- MAIN APP DEPOTS / PACKAGES
addappid(767501, 1, "f80216b5b95c2da2b5abb53059a0fd60d35c414562fc7ec11c0454feaa6d0d46")

