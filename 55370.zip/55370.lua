-- Lua provided by RyzenAPI
-- Game: Game: AppID 55370

-- MAIN APPLICATION
addappid(55370)
-- Game: addappid(55370)

-- MAIN APP DEPOTS / PACKAGES
addappid(55371, 1, "a70aeec33eefcef4641550d67d0076d241ab69d524da731e2c22936ed7de98b2")
addappid(55372, 1, "fb6f10018637e68ed564476855851c7d7fff3e8e4088edc88249531f33f8b142")
