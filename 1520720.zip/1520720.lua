-- Lua provided by RyzenAPI
-- Game: Game: AppID 1520720

-- MAIN APPLICATION
addappid(1520720)
-- Game: addappid(1520720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520721, 1, "37f87468014942c2b9fdec29b42bd57bb8551e2bddcc23940955e50113704d08")
