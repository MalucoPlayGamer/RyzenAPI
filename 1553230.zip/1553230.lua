-- Lua provided by RyzenAPI
-- Game: Trailer Shop Simulator

-- MAIN APPLICATION
addappid(1553230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1553232,0,"bf4cdef3e9e2227e28289438e64415e9ce67d6ce91b0a3d64dc83093d2a28d8e")

