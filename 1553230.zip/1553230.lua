-- Lua provided by RyzenAPI
-- Game: Trailer Shop Simulator

-- MAIN APPLICATION
addappid(1553230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553232,0,"bf4cdef3e9e2227e28289438e64415e9ce67d6ce91b0a3d64dc83093d2a28d8e")
