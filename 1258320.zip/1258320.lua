-- Lua provided by SkyAPI 
-- Game: AppID 1258320
addappid(1258320)
addappid(1258321, 1, "b886397dc92ae1b0055cea3aee4cb89b92cc55c590dd03c6be43ba00e48dc227")
