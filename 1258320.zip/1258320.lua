-- Lua provided by RyzenAPI
-- Game: 1258320

-- MAIN APPLICATION
addappid(1258320)
-- Game: addappid(1258320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258321, 1, "b886397dc92ae1b0055cea3aee4cb89b92cc55c590dd03c6be43ba00e48dc227")
