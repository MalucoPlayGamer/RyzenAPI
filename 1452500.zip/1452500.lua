-- Lua provided by RyzenAPI
-- Game: The Good Life

-- MAIN APPLICATION
addappid(1452500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452501, 1, "e1ca7e42ab21c060681f4f016383fcda2084c640177538e95f8e4ed89d4672e2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1690960)
addappid(1690961)
addappid(1690962)
addappid(1690963)
addappid(1690964)
addappid(2148360)
