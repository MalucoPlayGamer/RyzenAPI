-- Lua provided by RyzenAPI
-- Game: Game: The Good Life

-- MAIN APPLICATION
addappid(1452500)
-- Game: addappid(1452500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452501, 1, "e1ca7e42ab21c060681f4f016383fcda2084c640177538e95f8e4ed89d4672e2")
