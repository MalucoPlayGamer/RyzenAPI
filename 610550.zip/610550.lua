-- Lua provided by RyzenAPI
-- Game: 610550

-- MAIN APPLICATION
addappid(610550)
-- Game: addappid(610550)

-- MAIN APP DEPOTS / PACKAGES
addappid(610551, 1, "4c6ab54f83708ef160dc54761d81db7947e7186eacbf007a98d6b4193f192846")
