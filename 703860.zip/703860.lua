-- Lua provided by RyzenAPI
-- Game: AppID 703860

-- MAIN APPLICATION
addappid(703860)

-- MAIN APP DEPOTS / PACKAGES
addappid(703861, 1, "09c40820ee2149ac742cb889ee425838b816bfd811a24611754d5e3014e3cd1c")
addappid(703862, 1, "543b249135907913fb40c5758d13de652db2ef2be886d9e3a9acf64827144445")
addappid(703863, 1, "c94108cf18535b3db3209e773c3f3be425a454fcc013009c09a0b8480cebd946")
addappid(703865, 1, "c0b247bc92fefb6dd38eb09a158b34ada27b0204b959fb4ab3515b4d36bcc4d3")
addappid(703866, 1, "c78e81b9dad9fad9437a8ffe822a2cec2bfb50079ecb1d5c4191117ef585dce7")
addappid(703867, 1, "bdf15b06c3f1d05441784d999d7b45b5037e52c82869b5375fab5f63f3f92695")
addappid(703868, 1, "0b09b0114293eeb2a5d419d7c9dfae45441f626996f7a5560a64ab1bb705ff49")
addappid(703869, 1, "d8363172736234b0023ee9be1c88923af6a1a1945b98928ace5f2cbb2b9d6c3e")
addappid(1059131, 0, "c042e78b438b9a8db740aa1e90c15a43f775f412873e664eb4d13b5a8bb03155")
addappid(1059132, 0, "24f3937743551dbd62fbc41fab07d0eb8f91e5110977c5495bd4d09e227e5e14")
addappid(1059133, 0, "5fce7cfb8a41935288a7a4da08e70aa503eb6a8c6d5d7561f581d89e540390ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1085440)
addappid(1085450)
addappid(1085460)
addappid(1085470)
addappid(1085480)
addappid(1085490)
addappid(1085500)
addappid(1146320)
