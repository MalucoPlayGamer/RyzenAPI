-- Lua provided by RyzenAPI
-- Game: Blacksmith Simulator

-- MAIN APPLICATION
addappid(1959120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1959121, 1, "f055ff85e7816e82bf90409cdfd8b4d208771fa39cc473fec0938b9cd2fd6402")

