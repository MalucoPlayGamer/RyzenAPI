-- Lua provided by RyzenAPI
-- Game: Game: Blacksmith Simulator

-- MAIN APPLICATION
addappid(1959120)
-- Game: addappid(1959120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959121, 1, "f055ff85e7816e82bf90409cdfd8b4d208771fa39cc473fec0938b9cd2fd6402")
