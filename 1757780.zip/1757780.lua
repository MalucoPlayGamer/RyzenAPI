-- Lua provided by RyzenAPI
-- Game: Sex with the Devil: VR Sex Scenes

-- MAIN APPLICATION
addappid(1757780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757780,0,"16f714ddfd12984ca758839cc66d0e83a142d8cce3f15d25bc91f64b5d01400c")

