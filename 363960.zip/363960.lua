-- Lua provided by RyzenAPI
-- Game: Devils & Demons

-- MAIN APPLICATION
addappid(363960)

-- MAIN APP DEPOTS / PACKAGES
addappid(363961, 1, "6ab030a69a51b1a385a9447266626c7fe5b0ad00ef490e12794ed5ae200f60c3")
