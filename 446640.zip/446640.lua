-- Lua provided by RyzenAPI
-- Game: Space Pilgrim Episode IV: Sol

-- MAIN APPLICATION
addappid(446640)

-- MAIN APP DEPOTS / PACKAGES
addappid(446641, 1, "d221dc1a4e58ccc22883b3dae813a8ff802693c712ef61916f0080c61ab70a9f")

