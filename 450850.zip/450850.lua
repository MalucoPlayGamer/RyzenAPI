-- Lua provided by RyzenAPI
-- Game: Cube Land Arena

-- MAIN APPLICATION
addappid(450850)
-- Game: addappid(450850)

-- MAIN APP DEPOTS / PACKAGES
addappid(450851, 1, "701186d2dea328e78ed584235f80c5a327d7d59d2b6ad825ff9929009b4ab3af")
addappid(450852, 1, "82d8cd9396ad1bc2618cd9078195166474a66162ad5d726eb36a076a227b1ee1")
