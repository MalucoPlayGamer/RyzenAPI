-- Lua provided by RyzenAPI
-- Game: Game: Crosshair Genie

-- MAIN APPLICATION
addappid(2367970)
-- Game: addappid(2367970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367971, 1, "965585ad08379857c076fb30b92581bb54d42c39e8daf8ea2df1c65bfedee976")
