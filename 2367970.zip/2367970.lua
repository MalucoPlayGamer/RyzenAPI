-- Lua provided by RyzenAPI
-- Game: Crosshair Genie

-- MAIN APPLICATION
addappid(2367970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367971, 1, "965585ad08379857c076fb30b92581bb54d42c39e8daf8ea2df1c65bfedee976")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
