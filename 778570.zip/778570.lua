-- Lua provided by RyzenAPI
-- Game: Bustories

-- MAIN APPLICATION
addappid(778570)

-- MAIN APP DEPOTS / PACKAGES
addappid(778571, 1, "eac37e728c7c3db30bb3f1a93683f24725390c77993caaee7427059111654679")
addappid(838920, 0, "09785926acc1b7d1fba89ceb2730c0a3bff714989376f7b8d153e6daae77da27")
