-- Lua provided by RyzenAPI
-- Game: 1243200

-- MAIN APPLICATION
addappid(1243200)
-- Game: addappid(1243200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243201, 1, "f5c85e0646f3e06181082d35cc7be486b0a3da9e7cbbbb3d3b79c6bb2f28f1e9")
