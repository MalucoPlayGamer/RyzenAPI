-- 4536070's Lua and Manifest Created by Hubcap Manifest
-- 多肉小憩
-- Created: August 11, 2026 at 00:20:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4536070) -- 多肉小憩
-- MAIN APP DEPOTS
addappid(4536071, 1, "ecd2fe74956e976a1449d9f60485c243955e9e2751853356bc586c05b10267ee") -- Depot 4536071
setManifestid(4536071, "1521416636544605408", 115496800)