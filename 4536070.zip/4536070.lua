-- Lua provided by RyzenAPI
-- Game: Created: August 11, 2026 at 00:20:29 EDT

-- MAIN APPLICATION
addappid(4536070) -- 多肉小憩

-- MAIN APP DEPOTS / PACKAGES
addappid(4536071, 1, "ecd2fe74956e976a1449d9f60485c243955e9e2751853356bc586c05b10267ee") -- Depot 4536071

