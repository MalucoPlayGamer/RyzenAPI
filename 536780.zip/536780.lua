-- Lua provided by RyzenAPI
-- Game: Lost Grimoires: Stolen Kingdom

-- MAIN APPLICATION
addappid(536780)

-- MAIN APP DEPOTS / PACKAGES
addappid(536781, 1, "4f57bf6fe01ddfb05a82e1b2b0b6d43e280a008c447bdb603737c2eb452a1207")
addappid(536782, 1, "612b6f831324bfaa574fd8409315ed8217fbbfccf316a999566c3902be14daf2")
addappid(536783, 1, "b4a22408da9cdef3470af879c35bacf96f0afe2f3db896724d25a791a3fa4182")

