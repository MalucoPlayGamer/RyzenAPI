-- Lua provided by RyzenAPI
-- Game: addappid(585990)

-- MAIN APPLICATION
addappid(585990)
addappid(589330)

-- MAIN APP DEPOTS / PACKAGES
addappid(585991, 1, "2cee6596ae691f3ac37c6ebc2c8c117f66dcf9c72403b528e7f3edae7a5cb4f9")
addappid(585995, 1, "07488ef3c19e869ef9b212c126d01ed626bdc79ccbc375e1e7c6f71c236eb821")
