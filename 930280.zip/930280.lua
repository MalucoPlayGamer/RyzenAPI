-- Lua provided by SkyAPI 
-- Game: Murder Mystery Machine
addappid(930280)
addappid(930281, 1, "a3a8196e901301b3056ee44e98121a1a7a88f4de599992389a92b6bb521a2242")
