-- Lua provided by RyzenAPI
-- Game: Game: AppID 3685260

-- MAIN APPLICATION
addappid(3685260)
-- Game: addappid(3685260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3685261, 1, "2b252691f064082fd12c1dc04d5064b6a01e285301edf4a68eb9d9f4568d1aef")
