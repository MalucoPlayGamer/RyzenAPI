-- Lua provided by SkyAPI 
-- Game: AppID 3685260
addappid(3685260)
addappid(3685261, 1, "2b252691f064082fd12c1dc04d5064b6a01e285301edf4a68eb9d9f4568d1aef")
