-- Lua provided by RyzenAPI
-- Game: True Fear: Forsaken Souls Part 1

-- MAIN APPLICATION
addappid(440420)
-- Game: addappid(440420)

-- MAIN APP DEPOTS / PACKAGES
addappid(440421, 1, "cd2c23953d2cbb0f7104a2f17f9439812277c4786896c4bd333f52476c42cb2a")
