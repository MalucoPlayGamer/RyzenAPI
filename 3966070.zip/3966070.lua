-- Lua provided by RyzenAPI
-- Game: The Dead Thread

-- MAIN APPLICATION
addappid(3966070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3966071,0,"aee82036f90ad479c8590bf6def126da1722782230f75646c6df544b9872917b")
addappid(4544300,0,"483e3722b820ccb1a78c15c5f98eb70dcfa8249c28694cbf9208e113a0f498b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
