-- Lua provided by RyzenAPI
-- Game: Eternal Silence Dedicated Server

-- MAIN APPLICATION
addappid(205)
addappid(206)
addappid(207)
addappid(208)
addappid(1004)
addappid(17555)

-- MAIN APP DEPOTS / PACKAGES
addappid(17551,0,"7ee4d5e756b000d39e666fac2f0331ecb099e2e0e6bf9bc79104d29bbb6ed898")

