-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Scenario & BGM Set 2

-- MAIN APPLICATION
addappid(1634709)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634709,0,"275f612fb4f6162d5c40ec15f8c7207fc827b2d37de4c65d20344b7a52ac8a21")
