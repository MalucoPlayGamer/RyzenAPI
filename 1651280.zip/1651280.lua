-- Lua provided by SkyAPI 
-- Game: Burnit Quest
addappid(1651280)
addappid(1651281, 1, "9bcd5bea944a0a3bb20412330e12e0e6181febe3da394fb61703cd91d0eaec55")
