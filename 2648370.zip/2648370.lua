-- Lua provided by RyzenAPI
-- Game: Before The Sun Rises

-- MAIN APPLICATION
addappid(2648370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2648371, 1, "482f4e885379accfa7900edbb9c3c95388eab3aac6039934a44c54dd220a6e84")

