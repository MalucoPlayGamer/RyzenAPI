-- Lua provided by RyzenAPI
-- Game: Game: Before The Sun Rises

-- MAIN APPLICATION
addappid(2648370)
-- Game: addappid(2648370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648371, 1, "482f4e885379accfa7900edbb9c3c95388eab3aac6039934a44c54dd220a6e84")
