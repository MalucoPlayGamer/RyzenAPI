-- Lua provided by RyzenAPI
-- Game: How To Punish A Witch

-- MAIN APPLICATION
addappid(1314290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314291, 1, "fe04cc60ccc9d89ce8b4e979ca848a4d59c583d13b6b983a718effb052240f07")

