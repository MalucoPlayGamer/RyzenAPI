-- Lua provided by RyzenAPI
-- Game: addappid(3163790)

-- MAIN APPLICATION
addappid(3163790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163791, 1, "77d75c0da5f538fa9b229d5ea7cdf887518ccbb5fd6296bcd5145417d7f9d20f")
