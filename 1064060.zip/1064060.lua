-- Lua provided by RyzenAPI
-- Game: Game: AppID 1064060

-- MAIN APPLICATION
addappid(1064060)
-- Game: addappid(1064060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064061, 1, "6a1e155b6dc4784fe394d390ca044619fe9526f5f5163d8522e18f12076a53a0")
