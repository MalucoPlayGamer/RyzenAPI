-- 4881490's Lua and Manifest Created by Hubcap Manifest
-- FinSim
-- Created: August 16, 2026 at 06:51:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4881490) -- FinSim
-- MAIN APP DEPOTS
addappid(4881491, 1, "79f58241f24107e268ff9d0d3d660c9cf5233fcbbcb7c4712f33b2dc5c3ec9b8") -- Depot 4881491
setManifestid(4881491, "457111474644809552", 529196670)
addappid(4881492, 1, "bccf029b8265057b30dcef67ee315f4d4e03063bb33e12444de556ba7de28217") -- Depot 4881492
setManifestid(4881492, "5656031568825135089", 454820254)