-- Lua provided by RyzenAPI
-- Game: FinSim

-- MAIN APPLICATION
addappid(4881490) -- FinSim

-- MAIN APP DEPOTS / PACKAGES
addappid(4881491, 1, "79f58241f24107e268ff9d0d3d660c9cf5233fcbbcb7c4712f33b2dc5c3ec9b8") -- Depot 4881491
addappid(4881492, 1, "bccf029b8265057b30dcef67ee315f4d4e03063bb33e12444de556ba7de28217") -- Depot 4881492

