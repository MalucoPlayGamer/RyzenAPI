-- Lua provided by RyzenAPI
-- Game: No Seat?

-- MAIN APPLICATION
addappid(432270)

-- MAIN APP DEPOTS / PACKAGES
addappid(432271, 1, "12efba2f23075611eafee9a11912bb8f0bc84898400e1d46a2f769c916c6a1a1")
