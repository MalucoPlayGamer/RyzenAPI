-- Lua provided by RyzenAPI
-- Game: Game: Conquest of Empires 2

-- MAIN APPLICATION
addappid(2542860)
-- Game: addappid(2542860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542861, 1, "4d27abe6cd9fe7a43c9ad499f1de65d76324667dd28a06b0ea9f8cdd2de920f1")
