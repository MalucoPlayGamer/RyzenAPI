-- Lua provided by RyzenAPI
-- Game: The Riftbreaker: Prologue

-- MAIN APPLICATION
addappid(1293860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293861, 1, "e5ff00db29decfb2e3e8d2f3284bfd258f1f4c50f754efb391850dd7a4b3c746")
