-- Lua provided by RyzenAPI
-- Game: The Riftbreaker: Prologue

-- MAIN APPLICATION
addappid(1293860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293861, 1, "e5ff00db29decfb2e3e8d2f3284bfd258f1f4c50f754efb391850dd7a4b3c746")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
