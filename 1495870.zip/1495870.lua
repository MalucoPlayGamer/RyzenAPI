-- Lua provided by RyzenAPI
-- Game: PowerNap: Ultimate Game Updater

-- MAIN APPLICATION
addappid(1495870)
-- Game: addappid(1495870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495871, 1, "51c0b1b8f1670e7a0c2051df9bb79788eea4aa0c53fdcc7f17660cf7c14646f3")
