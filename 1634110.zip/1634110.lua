-- Lua provided by SkyAPI 
-- Game: Sculpture Hentai Edition
addappid(1634110)
addappid(1634111, 1, "b5ce3136b9c3364f3aab462922cbd14b00f5abd56c29c2d7edb186972ed703f9")
