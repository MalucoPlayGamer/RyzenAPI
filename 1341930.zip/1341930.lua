-- Lua provided by RyzenAPI
-- Game: Furry Woof

-- MAIN APPLICATION
addappid(1341930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341931, 1, "3e36f50bd5289c16516771cd6d22c2ab47e04e93b78b3d9f3039afde8d99ad76")
