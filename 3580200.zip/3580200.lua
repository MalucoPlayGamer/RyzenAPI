-- Lua provided by SkyAPI 
-- Game: Monster Train 2 Soundtrack
addappid(3580200)
addappid(3580201, 1, "4afd1e31d378ad261f6b8386e75f1643303afb15cb334291f55a380753bbbca4")
addappid(3580202, 1, "5953ab5f73eada762a0f19db98c496ef9aa879c3bd653e4fd335ed5808c2d5a2")
