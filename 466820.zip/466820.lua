-- Lua provided by RyzenAPI
-- Game: Zenodyne R

-- MAIN APPLICATION
addappid(466820)

-- MAIN APP DEPOTS / PACKAGES
addappid(466821, 1, "626c42e4961995aaa20878957189fe2a6bfe736d49629ea169408b003ff1f812")
addappid(471410, 0, "fddedfc93b2893864a15a5e8324ec48a3372a68e38924fce26e5aa4df59b3d95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
