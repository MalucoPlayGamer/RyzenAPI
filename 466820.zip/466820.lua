-- Lua provided by RyzenAPI 
-- Game: Zenodyne R
addappid(466820)
addappid(466821, 1, "626c42e4961995aaa20878957189fe2a6bfe736d49629ea169408b003ff1f812")
addappid(471410, 0, "fddedfc93b2893864a15a5e8324ec48a3372a68e38924fce26e5aa4df59b3d95")
