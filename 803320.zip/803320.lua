-- Lua provided by RyzenAPI 
-- Game: AppID 803320
addappid(803320)
addappid(803321, 1, "d9e140e75452acc517950697ce3021b92d545503ef29c0264db2c34a6fcce778")
