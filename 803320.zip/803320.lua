-- Lua provided by RyzenAPI
-- Game: Game: AppID 803320

-- MAIN APPLICATION
addappid(803320)
-- Game: addappid(803320)

-- MAIN APP DEPOTS / PACKAGES
addappid(803321, 1, "d9e140e75452acc517950697ce3021b92d545503ef29c0264db2c34a6fcce778")
