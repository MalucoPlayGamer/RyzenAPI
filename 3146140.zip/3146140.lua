-- Lua provided by RyzenAPI
-- Game: F-22: Air Dominance Fighter

-- MAIN APPLICATION
addappid(3146140)
-- Game: addappid(3146140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146141, 1, "df2e5059c2e8d4dbf576e1de1fda6fe462d852a974ea4878b5ed3373b7eab917")
