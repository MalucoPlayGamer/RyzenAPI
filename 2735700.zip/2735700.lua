-- Lua provided by RyzenAPI
-- Game: Maneuver

-- MAIN APPLICATION
addappid(2735700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735701, 1, "37c75b91876972627daad90f779b6b91dd85061ddfb22076511f4f291f9e82dc")
