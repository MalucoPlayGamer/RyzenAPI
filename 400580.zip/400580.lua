-- Lua provided by RyzenAPI
-- Game: Black Closet

-- MAIN APPLICATION
addappid(400580)
addappid(400581)
addappid(400583)
addappid(400584)
addappid(400586)

-- MAIN APP DEPOTS / PACKAGES
addappid(400582,0,"b8e774b20894acb3bd5b75ed93c9f2360e972ea6c42683c904d26c6af27b9acd")
addappid(400585,0,"66ed3fc0a72e4b2a768567b7ca7e873c5b656a849db1d2b29aa1bd4398172db5")
