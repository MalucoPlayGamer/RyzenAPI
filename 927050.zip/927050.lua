-- Lua provided by RyzenAPI
-- Game: 927050

-- MAIN APPLICATION
addappid(927050)
-- Game: addappid(927050)

-- MAIN APP DEPOTS / PACKAGES
addappid(927051, 1, "acd351067db74a87de9b186545f34571b0a3fc05893dd4fc232939d91e916a2e")
