-- Lua provided by RyzenAPI
-- Game: SpongeBob SquarePants: Battle for Bikini Bottom - Rehydrated

-- MAIN APPLICATION
addappid(969990)

-- MAIN APP DEPOTS / PACKAGES
addappid(969991, 1, "57d1e3f2c41fa70a907141460fe0aa4929500b4df7b13e24cfeca58089466401")
