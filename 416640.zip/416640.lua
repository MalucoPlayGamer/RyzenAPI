-- Lua provided by RyzenAPI
-- Game: Game: AppID 416640

-- MAIN APPLICATION
addappid(416640)
-- Game: addappid(416640)

-- MAIN APP DEPOTS / PACKAGES
addappid(416641, 1, "8fb2fd1b9d0f3e7ee347549947d814e0c12218824cac2577d004a0c34faed3ba")
