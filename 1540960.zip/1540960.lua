-- Lua provided by RyzenAPI
-- Game: Underworld Idle

-- MAIN APPLICATION
addappid(1540960)
addappid(2268970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540961, 1, "2cbd1a5fdfae634ea0d59d1c6218fce7898a41bb8510e06df3ef31e317cc2a6b")
