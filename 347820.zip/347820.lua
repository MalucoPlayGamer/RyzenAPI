-- Lua provided by RyzenAPI 
-- Game: Street Arena
addappid(347820)
addappid(347821, 1, "d6281dc904761ff9b043362dc9057bc5a28d284a0799e1be3839010db2c8d3ad")
addappid(347822, 1, "fc99e8b8526b6cd4367aaab5e04e9ea75ff2233fe968db6e56e7583574da2372")
addappid(347823, 1, "8330dad05737f956ae77436fd8462a8e7413e51f8883cddcbe666e7954de4cb2")
