-- Lua provided by RyzenAPI
-- Game: Street Arena

-- MAIN APPLICATION
addappid(347820)

-- MAIN APP DEPOTS / PACKAGES
addappid(347821, 1, "d6281dc904761ff9b043362dc9057bc5a28d284a0799e1be3839010db2c8d3ad")
addappid(347822, 1, "fc99e8b8526b6cd4367aaab5e04e9ea75ff2233fe968db6e56e7583574da2372")
addappid(347823, 1, "8330dad05737f956ae77436fd8462a8e7413e51f8883cddcbe666e7954de4cb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
