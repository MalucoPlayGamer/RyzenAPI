-- Lua provided by RyzenAPI
-- Game: Shining Plume 2

-- MAIN APPLICATION
addappid(597810)

-- MAIN APP DEPOTS / PACKAGES
addappid(597811, 1, "585e513bfa7cac8334bc33eb96d14151198204ffde41be2f290bb2e7a788f5a5")
