-- Lua provided by RyzenAPI
-- Game: Goat's Tale (Classic)

-- MAIN APPLICATION
addappid(1702180)
addappid(1847090)
-- Game: addappid(1702180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702181, 1, "b28c87395fd7fd381ce09deaa4835e455560c8923fa81d15c485ed014794139b")
