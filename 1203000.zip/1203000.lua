-- Lua provided by RyzenAPI
-- Game: Asterix & Obelix XXL 3  - The Crystal Menhir Demo

-- MAIN APPLICATION
addappid(1203000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203001, 1, "e5100612001a1ba3cc794114b11fe7a689c6bcd80aa8a5888f7ce0cc650f910b")

