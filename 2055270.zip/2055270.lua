-- Lua provided by RyzenAPI
-- Game: Tile Tale

-- MAIN APPLICATION
addappid(2055270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2055271, 1, "bcc0343c78d7c20adeed2feb7f05be39b819e990af439e779ccc710053d6bc59")
addappid(2055272, 1, "98a7fed087629fd829929889b41ff2a1ab52a5d5e4fa5de81a14ff7babd84556")

