-- Lua provided by RyzenAPI
-- Game: Tile Tale

-- MAIN APPLICATION
addappid(2055270)
-- Game: addappid(2055270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055271, 1, "bcc0343c78d7c20adeed2feb7f05be39b819e990af439e779ccc710053d6bc59")
addappid(2055272, 1, "98a7fed087629fd829929889b41ff2a1ab52a5d5e4fa5de81a14ff7babd84556")
