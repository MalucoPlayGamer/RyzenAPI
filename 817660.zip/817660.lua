-- Lua provided by RyzenAPI
-- Game: addappid(817660)

-- MAIN APPLICATION
addappid(817660)

-- MAIN APP DEPOTS / PACKAGES
addappid(817661, 1, "46af384505efb874e23c076cbf7406e1c87a99c929a6bdc4513261e8ef1cfc37")
addappid(817662, 1, "f62dc54b2b68b6ce17ad5db2846cc3af21d0e69e3a40c5be99b80881a95981cd")
addappid(817663, 1, "6cc6d8f88aa33d3c4de6e2f56facc7dd3bdd9ed4ffd29cdfdfbca3ece85e3630")
addappid(817664, 1, "028054d90efa76dddc73e23a804dd4e85de322574afa38f286c6918c7917816d")
addappid(837060, 0, "3d3a5f4652e5de817e4f30e3120cec6cde6e9dc24e21de5c7ef41bdb30f1aad6")
