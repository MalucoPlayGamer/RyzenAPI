-- Lua provided by RyzenAPI
-- Game: 530700

-- MAIN APPLICATION
addappid(228985)
addappid(228990)
addappid(530700)
addappid(530701)
addappid(530703)
addappid(530704)
addappid(530705)
addappid(530706)
addappid(530707)
addappid(530708)
addappid(530709)
addappid(536160)
addappid(536161)
addappid(536162)
addappid(536163)
addappid(536164)
addappid(536165)
addappid(536166)
addappid(536167)
addappid(536168)
addappid(536169)
addappid(536170)
addappid(536171)
addappid(536172)
addappid(536173)
addappid(536174)

-- MAIN APP DEPOTS / PACKAGES
addappid(530702,0,"27f4e1163e3afed23b640905f4e402ed9946a49fe08904a8a57540889df11c58")

