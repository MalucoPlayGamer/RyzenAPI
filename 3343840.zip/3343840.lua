-- Lua provided by RyzenAPI
-- Game: Dino running from a FURRY: GAMESFORFARM

-- MAIN APPLICATION
addappid(3343840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3343841, 1, "5d5c2006da313c45c3a3e3ce9edfbc11e3e5218dbb03449ea17360bcda79df9c")

