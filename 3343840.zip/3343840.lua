-- Lua provided by RyzenAPI
-- Game: AppID 3343840

-- MAIN APPLICATION
addappid(3343840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343841, 1, "5d5c2006da313c45c3a3e3ce9edfbc11e3e5218dbb03449ea17360bcda79df9c")

