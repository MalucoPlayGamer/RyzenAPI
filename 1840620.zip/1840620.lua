-- Lua provided by RyzenAPI
-- Game: Trialtime Reborn

-- MAIN APPLICATION
addappid(1840620)
addappid(1932140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1840621, 1, "74ba71ddedcaddd9dbb5306e39a0fc9049f3d173d92e9ed5fb631a3c0cc9d5ac")

