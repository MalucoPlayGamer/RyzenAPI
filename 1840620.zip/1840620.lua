-- Lua provided by RyzenAPI
-- Game: Game: Trialtime Reborn

-- MAIN APPLICATION
addappid(1840620)
addappid(1932140)
-- Game: addappid(1840620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840621, 1, "74ba71ddedcaddd9dbb5306e39a0fc9049f3d173d92e9ed5fb631a3c0cc9d5ac")
