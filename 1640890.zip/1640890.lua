-- Lua provided by RyzenAPI
-- Game: Hell of an Office

-- MAIN APPLICATION
addappid(1640890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640891, 1, "7110617114b69198ae185b92e9b87278eaace66e97d06a9a7fbf3614bcaeacc0")
addappid(2322960, 0, "7415f0e68c8928cf87240cc78396592cb9f2f6dad592b5b9293d3f1f04484f0b")
