-- Lua provided by RyzenAPI
-- Game: House Flipper 2

-- MAIN APPLICATION
addappid(2649200)
addappid(3363370) -- House Flipper 2 - Co-op DLC
addappid(3672960) -- House Flipper 2 - Scooby-Doo DLC
addappid(4351410) -- House Flipper 2 - Sakura DLC
-- addappid(1190972) -- Depot 1190972 (empty depot)
-- addappid(3680100) -- House Flipper 2 - Pets DLC (unreleased)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190970, 1, "f2f1aaf6899f899ad07cb2da7594595d1acc24d732a23f7a4a16cc959e5c697b") -- House Flipper 2
addappid(1190971, 1, "a6202777d416dcf4d2f36cc5f7a69f90cca6e1bfbde6e27eaa4e97e86c7d3196") -- Depot 1190971
addappid(2649200, 1, "75c666e7e7f011eddb178036bbb4b16446378ef945ecf6811f32e2a4f96bfcc7") -- House Flipper 2 - Supporter Pack - Depot 2649200

