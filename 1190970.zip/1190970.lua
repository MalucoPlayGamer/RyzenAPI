-- Lua provided by RyzenAPI 
-- Game: House Flipper 2
addappid(1190970)
addappid(1190971, 1, "a6202777d416dcf4d2f36cc5f7a69f90cca6e1bfbde6e27eaa4e97e86c7d3196")
addappid(2649200, 0, "75c666e7e7f011eddb178036bbb4b16446378ef945ecf6811f32e2a4f96bfcc7")
addappid(3363370)
addappid(3672960)
