-- Lua provided by SkyAPI 
-- Game: Cowboys &amp; Zombies VR Demo
addappid(2201360)
addappid(2201361, 1, "d491c54269d8a9884e82f200a8795769758ccded73b05789635ee607f409862a")
