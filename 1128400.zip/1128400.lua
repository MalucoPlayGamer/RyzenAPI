-- Lua provided by RyzenAPI
-- Game: Crystar - Limited Edition OST

-- MAIN APPLICATION
addappid(1128400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128400,0,"5a7a197f762fabb467a96602e110f2c2b260e11dacfb70775c9c0931d1b70c92")

