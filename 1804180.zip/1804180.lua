-- Lua provided by SkyAPI 
-- Game: Cristalix
addappid(1804180)
addappid(1804181, 1, "eeca45cc58590101c3bd6d02a595857ba6db9b04c536c4469de4073626d94108")
