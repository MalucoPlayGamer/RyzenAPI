-- Lua provided by RyzenAPI
-- Game: Game: Cristalix

-- MAIN APPLICATION
addappid(1804180)
-- Game: addappid(1804180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804181, 1, "eeca45cc58590101c3bd6d02a595857ba6db9b04c536c4469de4073626d94108")
