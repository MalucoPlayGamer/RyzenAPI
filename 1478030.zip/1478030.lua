-- Lua provided by RyzenAPI
-- Game: Mambo Wave

-- MAIN APPLICATION
addappid(1478030)
addappid(1514630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478031, 1, "d616ddd0be18cda4f9eb7730151e4ba6aca199a65034601e7129c9585d534fbb")
