-- Lua provided by RyzenAPI
-- Game: East 73: Magenta Fairytale

-- MAIN APPLICATION
addappid(769550)
-- Game: addappid(769550)

-- MAIN APP DEPOTS / PACKAGES
addappid(769551, 1, "d29bcc6d01f8dd9af3d7a2d27f0eded7b685dc5071f7ff02ad7c97dbf05c5654")
