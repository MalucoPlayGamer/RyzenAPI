-- Lua provided by RyzenAPI
-- Game: Star Leaping Story

-- MAIN APPLICATION
addappid(2184010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184011, 1, "1349ce101d9a9b2c025d62045ed5d94a4170ad977d1eddd163b9140f79557326")
