-- Lua provided by RyzenAPI 
-- Game: Kargo Demo
addappid(2022340)
addappid(2022341, 1, "c49bdf912728df2720b174362e881f1331b941f819dd81c4a309d2d352bdf2bd")
