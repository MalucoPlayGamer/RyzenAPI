-- Lua provided by RyzenAPI
-- Game: Game: Face of Another

-- MAIN APPLICATION
addappid(3272170)
-- Game: addappid(3272170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272171, 1, "9f82713795833a32d5a2da624079d04fb41499ff1957c70957ce4df91aacf8c1")
