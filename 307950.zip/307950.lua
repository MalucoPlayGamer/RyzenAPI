-- Lua provided by RyzenAPI
-- Game: Caliber

-- MAIN APPLICATION
addappid(307950)

-- MAIN APP DEPOTS / PACKAGES
addappid(307951, 1, "70bc1392b20dcf9bb99cda6f727f5e4b76a6e6ec8f89387c23c65026eab97076")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2339640)
addappid(2339641)
addappid(2339642)
addappid(2339643)
addappid(2339644)
addappid(2440170)
addappid(2440171)
addappid(2440172)
addappid(2440173)
addappid(2440174)
addappid(2440175)
addappid(2440176)
addappid(2440177)
addappid(2440178)
addappid(2440179)
addappid(2440190)
addappid(2440191)
addappid(2440192)
addappid(2440193)
addappid(2440194)
addappid(2440195)
addappid(2440196)
addappid(2440197)
addappid(2440198)
addappid(2440199)
addappid(3525980)
addappid(3525990)
addappid(3526000)
addappid(3526010)
addappid(3526020)
addappid(3526030)
addappid(3526040)
addappid(3526050)
