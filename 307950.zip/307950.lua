-- Lua provided by RyzenAPI
-- Game: Caliber

-- MAIN APPLICATION
addappid(307950)
-- Game: addappid(307950)

-- MAIN APP DEPOTS / PACKAGES
addappid(307951, 1, "70bc1392b20dcf9bb99cda6f727f5e4b76a6e6ec8f89387c23c65026eab97076")
