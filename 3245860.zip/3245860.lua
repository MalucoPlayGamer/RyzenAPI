-- Lua provided by RyzenAPI
-- Game: 3245860

-- MAIN APPLICATION
addappid(3245860)
-- Game: addappid(3245860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245861, 1, "b77e265e8ba26ee3346e169655d5282933a18fcf80e6fb35bd625f900d2a8972")
