-- Lua provided by RyzenAPI
-- Game: Game: At Home

-- MAIN APPLICATION
addappid(1048640)
-- Game: addappid(1048640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048641, 1, "42859f0c79db8a3b03c55864c6e0894923f3d4b9cce8158f959c0af9c859389e")
