-- Lua provided by RyzenAPI 
-- Game: PANDORA
addappid(2362540)
addappid(2362541, 1, "327256eb665815ceb5f6d213684b9b51d1df3dab27b1bed3e9c997ec4f0c10d2")
