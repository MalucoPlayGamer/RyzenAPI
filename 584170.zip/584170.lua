-- Lua provided by RyzenAPI
-- Game: Freedom Locomotion VR

-- MAIN APPLICATION
addappid(584170)

-- MAIN APP DEPOTS / PACKAGES
addappid(584171, 1, "1723ab46e10bd7ed7174c0d3c746248e09e0d58b5837b170937af939ea6db7c6")

