-- Lua provided by RyzenAPI
-- Game: Yield! Fall of Rome

-- MAIN APPLICATION
addappid(1561960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561962,0,"0660405628a3843952e55a1c68adde5756fc35f494c32eec8f30a7ee10e63125")
addappid(1561963,0,"3226137c81eb9f51c29e9ec4a1a7491650d811a63575bbd670d78914e6b1dd52")
addappid(3372030,0,"6879ab82d6eafbad1b970c3efe19aa47409251de5cf3e3e6c38f11d90364c0ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
