-- Lua provided by RyzenAPI
-- Game: Blacktop Hoops Demo

-- MAIN APPLICATION
addappid(2051790)
-- Game: addappid(2051790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051791, 1, "b06d9baeb32f66764d0ff011287917e18495d8fed6e2562c655e7096137cd3c9")
