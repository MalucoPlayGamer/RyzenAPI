-- Lua provided by RyzenAPI 
-- Game: Dark Fall 2: Lights Out
addappid(260710)
addappid(260711, 1, "6410a8120a62ae2291edc4073d678d5ab111d2ed1c0b78382b1795b4b695ae84")
