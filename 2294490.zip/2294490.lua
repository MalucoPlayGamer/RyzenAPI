-- Lua provided by RyzenAPI
-- Game: Under The Hood Demo

-- MAIN APPLICATION
addappid(2294490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294491, 1, "3aa36a120300679a44ffdd136368485e4f96f93e5b024778678abfae5a741c03")

