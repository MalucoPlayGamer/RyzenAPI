-- Lua provided by RyzenAPI
-- Game: 1775: Rebellion

-- MAIN APPLICATION
addappid(422610)
addappid(587740)

-- MAIN APP DEPOTS / PACKAGES
addappid(422611, 1, "ce9d906cb1c5ced89f162586a68ea325847efccb818a300cf0ca9d3c66a2bb9f")
addappid(422612, 1, "53e2593319aeeb2c5beb9373973dbd840ca86fea924b813a71d5a01243c0ab32")

