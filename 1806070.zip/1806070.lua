-- Lua provided by RyzenAPI
-- Game: addappid(1806070)

-- MAIN APPLICATION
addappid(1806070)
addappid(1806071)
addappid(1806073)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806072,0,"152634c4bf4fb46ca7b4100e101aebd6545b622ede0e951dd56ae1651856f85f")
