-- Lua provided by RyzenAPI
-- Game: addappid(502150)

-- MAIN APPLICATION
addappid(502150)

-- MAIN APP DEPOTS / PACKAGES
addappid(502151, 1, "8b5d9dd6309b110ccc3cc4005dbf6b362202bd94095f43aec08ad8f17c6de161")
