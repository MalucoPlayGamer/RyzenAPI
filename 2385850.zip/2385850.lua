-- Lua provided by SkyAPI 
-- Game: JACKPOT
addappid(2385850)
addappid(2385851, 1, "319c449ee345066199be4adc7f39e6b6024d528302e311e98eb15af7441b6569")
