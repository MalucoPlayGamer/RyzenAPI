-- Lua provided by RyzenAPI
-- Game: Game: JACKPOT

-- MAIN APPLICATION
addappid(2385850)
-- Game: addappid(2385850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385851, 1, "319c449ee345066199be4adc7f39e6b6024d528302e311e98eb15af7441b6569")
