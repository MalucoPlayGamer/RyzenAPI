-- Lua provided by RyzenAPI
-- Game: White Wings ホワイトウィングス Dakimakuras DLC

-- MAIN APPLICATION
addappid(1204160)
-- Game: addappid(1204160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204160,0,"443a39f895b7a42c3c8f44c89b3f79c943059a4a9c88d96da1af8a6d09ed4207")
