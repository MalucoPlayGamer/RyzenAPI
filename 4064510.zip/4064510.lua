-- Lua provided by RyzenAPI
-- Game: MOLE

-- MAIN APPLICATION
addappid(4064510)

-- MAIN APP DEPOTS / PACKAGES
addappid(4064511,0,"df34e08e49ab90f50a08fe86fb64f5d468cceaba6d98bf61d69ddd888c5afe91")

