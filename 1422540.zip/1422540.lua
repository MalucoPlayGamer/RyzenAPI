-- Lua provided by RyzenAPI 
-- Game: 云端之约
addappid(1422540)
addappid(1422541, 1, "75593f931da78d6941d765c55398eaaac3ae204b1d1657e06922f6789bee9f06")
