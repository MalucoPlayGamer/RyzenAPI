-- Lua provided by RyzenAPI
-- Game: Who Is You

-- MAIN APPLICATION
addappid(1152550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152551, 1, "76c4c540d7b31f0326c5314a7f34ecc08534e12a9e7427025c0b33b61b9e26a4")

