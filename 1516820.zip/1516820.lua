-- Lua provided by RyzenAPI
-- Game: Game: 春秋

-- MAIN APPLICATION
addappid(1516820)
-- Game: addappid(1516820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516821, 1, "768cff85bab97b468a5e8ff29a29973e65befc3d6019b806e37d299141d319ba")
