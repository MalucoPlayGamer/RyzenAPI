-- Lua provided by RyzenAPI 
-- Game: Mausoleum of the Medusa
addappid(547260)
addappid(547261, 1, "e6ae055a0323fbdefdc9e068533b1cf1df5dfc0a2048190640c11dee16449efe")
addappid(547262, 1, "59fef634e7da45687667deb83e8092ab11ca3307f55b3d51417603e546137b7c")
addappid(547263, 1, "6521fd41a66c2f66f3698e7ef6c21ec96b0bb8623a24660e37ec1d4e14137d0e")
addappid(547264, 1, "1083a739d20f3d15b5fef14f6d8a4c2354cb96244e0eb12fa008589a33a09c3c")
