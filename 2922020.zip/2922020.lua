-- Lua provided by RyzenAPI 
-- Game: Sex Ghoul Fling🧟❤️
addappid(2922020)
addappid(2922021, 1, "81ff12ac23baf7f0be63af101da9da0e931ef9bb1225a5f01f45a081842df2be")
