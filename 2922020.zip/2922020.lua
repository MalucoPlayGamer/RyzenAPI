-- Lua provided by RyzenAPI
-- Game: Sex Ghoul Fling🧟❤️

-- MAIN APPLICATION
addappid(2922020)
-- Game: addappid(2922020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922021, 1, "81ff12ac23baf7f0be63af101da9da0e931ef9bb1225a5f01f45a081842df2be")
