-- Lua provided by RyzenAPI
-- Game: Fortune Summoners

-- MAIN APPLICATION
addappid(203510)
-- Game: addappid(203510)

-- MAIN APP DEPOTS / PACKAGES
addappid(203511, 1, "aa0e9c29573bcde7050bedd69a5fae6bf6e7609d6f7d15ee144a57f04b51ed2c")
