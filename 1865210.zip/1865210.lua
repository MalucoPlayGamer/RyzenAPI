-- Lua provided by RyzenAPI
-- Game: Game: 69 Lily Hot

-- MAIN APPLICATION
addappid(1865210)
-- Game: addappid(1865210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865211, 1, "772e1ecfb3242c3e9d4f721002fd84a23c9f6bc8d831ab7e5894849e0d468d6a")
