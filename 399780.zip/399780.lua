-- Lua provided by RyzenAPI
-- Game: Expand

-- MAIN APPLICATION
addappid(399780)
addappid(402690)

-- MAIN APP DEPOTS / PACKAGES
addappid(399781, 1, "b848c729a5d67d698ad14e080bcf67e3b359e859e8b728aea912dfb314366f2d")
addappid(399782, 1, "50e94bdde699dde889b9b1e3f23f8b959fbf9902a5294fd8c5a4894c821e4532")
addappid(399783, 1, "a9a5b446e5db06947bb2ef4a7f0794366661998c80ffc866e6836b02b1894bd2")
addappid(399784, 1, "6e9bdf6f827505d05327bafed1022f9d45538303d1664143b5dea27297a29bff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
