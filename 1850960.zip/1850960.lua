-- Lua provided by RyzenAPI
-- Game: The Jackbox Party Pack 9

-- MAIN APPLICATION
addappid(1850960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1850961, 1, "05833bceb7eb7d22c5667a1162c1e2425e6dbb937993cb169c67378d79b0a4e8")
addappid(1850962, 1, "402333fd39742593d4f73769fe978f7a577877fbc2ac1c2d42bf0662ae838263")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")

