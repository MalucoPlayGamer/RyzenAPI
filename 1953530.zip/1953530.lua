-- Lua provided by SkyAPI 
-- Game: The Last Man
addappid(1953530)
addappid(1953531, 1, "1b2929260c3dc42677a0d13ef22f4ab9b5e8568dae13a893abb661243e510934")
