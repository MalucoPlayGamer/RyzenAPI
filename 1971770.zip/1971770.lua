-- Lua provided by RyzenAPI
-- Game: Game: Wandering in Space VR

-- MAIN APPLICATION
addappid(1971770)
-- Game: addappid(1971770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971771, 1, "4b1c85b1e298cc34f21894e7746f336f79c9c7e469ed03da52526a02704040ce")
