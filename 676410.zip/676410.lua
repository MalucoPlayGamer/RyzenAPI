-- Lua provided by RyzenAPI
-- Game: Embrace of Ocean: Story of Hope

-- MAIN APPLICATION
addappid(676410)

-- MAIN APP DEPOTS / PACKAGES
addappid(676411,0,"a585fe365755b7c63365f8548e1c19dd1a39ae147db6e2d71fc45e6ea442722e")

