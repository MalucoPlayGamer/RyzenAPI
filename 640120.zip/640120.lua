-- Lua provided by RyzenAPI
-- Game: addappid(640120)

-- MAIN APPLICATION
addappid(640120)

-- MAIN APP DEPOTS / PACKAGES
addappid(640121, 1, "b71dcd6ae324547dffb978cdf4df0d3b0cf8b789ee3c39fe37bedaa73667b93b")
