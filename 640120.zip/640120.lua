-- Lua provided by RyzenAPI
-- Game: Youropa

-- MAIN APPLICATION
addappid(640120)

-- MAIN APP DEPOTS / PACKAGES
addappid(640121, 1, "b71dcd6ae324547dffb978cdf4df0d3b0cf8b789ee3c39fe37bedaa73667b93b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
