-- Lua provided by RyzenAPI
-- Game: CounterSide

-- MAIN APPLICATION
addappid(1976440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976441, 1, "3e2056d7a2ef32e4beb859050fbb0c1237893bcfd749a41177967323faa5454e")
