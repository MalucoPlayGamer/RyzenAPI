-- Lua provided by RyzenAPI 
-- Game: CounterSide
addappid(1976440)
addappid(1976441, 1, "3e2056d7a2ef32e4beb859050fbb0c1237893bcfd749a41177967323faa5454e")
