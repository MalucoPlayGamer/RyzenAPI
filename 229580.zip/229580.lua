-- Lua provided by RyzenAPI
-- Game: Dream

-- MAIN APPLICATION
addappid(229580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229581, 1, "87113658a8a4d8c134fc4e4753997d783877425d1cd3758feb6cd961901279ef")
addappid(384710, 0, "8ee4af81e2ede9c660060071565d438f059976901b2f04feaa81a1d2ca6a7c4a")

