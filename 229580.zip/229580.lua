-- Lua provided by RyzenAPI
-- Game: Dream

-- MAIN APPLICATION
addappid(229580)
-- Game: addappid(229580)

-- MAIN APP DEPOTS / PACKAGES
addappid(229581, 1, "87113658a8a4d8c134fc4e4753997d783877425d1cd3758feb6cd961901279ef")
addappid(384710, 0, "8ee4af81e2ede9c660060071565d438f059976901b2f04feaa81a1d2ca6a7c4a")
