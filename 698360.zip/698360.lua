-- Lua provided by RyzenAPI
-- Game: Within Whispers: The Fall

-- MAIN APPLICATION
addappid(698360)

-- MAIN APP DEPOTS / PACKAGES
addappid(698361,0,"149e4a5b30124ba65e30f69f8f5d653205a7f0dad01915baf427eb5d607282a7")

