-- Lua provided by RyzenAPI
-- Game: Game: VR-太阳系

-- MAIN APPLICATION
addappid(2429330)
-- Game: addappid(2429330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429331, 1, "789ea3a0b4abf89cfa15ba3b2e5ce0cdba0918551afc8b47d3bbf7abe50dea10")
