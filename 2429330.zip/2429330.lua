-- Lua provided by RyzenAPI
-- Game: VR-太阳系

-- MAIN APPLICATION
addappid(2429330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429331, 1, "789ea3a0b4abf89cfa15ba3b2e5ce0cdba0918551afc8b47d3bbf7abe50dea10")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
