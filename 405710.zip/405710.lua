-- Lua provided by RyzenAPI
-- Game: AppID 405710

-- MAIN APPLICATION
addappid(405710)

-- MAIN APP DEPOTS / PACKAGES
addappid(405711, 1, "cfd7a671e35ff2e375a721a925e7c92d0fa9f60dabc74c172a0b8bacb67c31d1")
addappid(405712, 1, "d683b0b47b0b3a78ef2fd175e1933f76c2fbe41a0a45a222dd002a3062f44349")
addappid(405713, 1, "43b9920e7123ef9216719afdc3edfca086a75ae73a128d30c6948f065c5c0e1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
