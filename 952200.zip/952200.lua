-- Lua provided by RyzenAPI
-- Game: stikir

-- MAIN APPLICATION
addappid(952200)

-- MAIN APP DEPOTS / PACKAGES
addappid(952201, 1, "15b2440723c3a73f4b90ad2e7a570cf366435029d46cdc9ff89a73914a982c85")

