-- Lua provided by RyzenAPI
-- Game: Rusty's Retirement

-- MAIN APPLICATION
addappid(2666510)
addappid(2943560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666511, 1, "87c44f717e4f4a2bc193e9fef7d8ddf9e01972a6fd582a8c6940c56c564e501e")
addappid(2666512, 1, "36002f9d0ef88f73fbfaa26203e579f6c53e4b234a6dea6004419be23d09b212")
