-- Lua provided by RyzenAPI
-- Game: Game: Rune Factory 5

-- MAIN APPLICATION
addappid(1702330)
-- Game: addappid(1702330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702331, 1, "b8d15bd8808333d12fc5b91c1963429c6c5d544b5a43925efd97f49c631ac4fc")
