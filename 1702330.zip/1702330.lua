-- Lua provided by RyzenAPI
-- Game: Rune Factory 5

-- MAIN APPLICATION
addappid(1702330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702331, 1, "b8d15bd8808333d12fc5b91c1963429c6c5d544b5a43925efd97f49c631ac4fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1874800)
addappid(1874801)
addappid(1874802)
addappid(1874803)
addappid(1874804)
addappid(1874805)
addappid(1874806)
addappid(1874807)
addappid(1874808)
addappid(1874809)
addappid(1874820)
addappid(2067360)
