-- Lua provided by RyzenAPI
-- Game: AppID 757200

-- MAIN APPLICATION
addappid(757200)

-- MAIN APP DEPOTS / PACKAGES
addappid(757201, 1, "1378b129779fff935c966565a8879cadb0e353bdacb526c8fbd0ff4e485b8f98")
addappid(757202, 1, "3b7223dc40b57e46cda428ce47de3b3cfc65b52af5cd6203a8c837cd848db5cc")
addappid(757203, 1, "7518dee614fee1870c9ad0f1497ac6eac64ea5659a081adee6ee640c9a827edb")
addappid(757204, 1, "7ce1a4ee3f20065b09875e49560492c327c0e39060711d9e7d7b3fad04853fef")
addappid(757205, 1, "7eab33ad67553acf52936747dc2ad84ae2aa452b12d9b4ec3564547d6b9a5790")
addappid(757206, 1, "9fb58bf74f139ef2036f3e62d6ab56b08b90cad052c71b3c1bf07bcd0f9d0c87")
addappid(757207, 1, "58bc91594666a67e2cf905f65385980f4cd256519d322b5337899cfe1bae6aea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
