-- Lua provided by RyzenAPI
-- Game: Game: 大富翁少女/Rich Girls

-- MAIN APPLICATION
addappid(1802860)
-- Game: addappid(1802860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802861, 1, "ee98a7b8e931f48f13f4a76466a0c4aff482b920aeff2688e3ec496595b7d396")
addappid(1813621, 0, "3e2654b46ce3f023ff90d2919551d51ea30f3681a6f481ec459a5b7ff282e7f0")
addappid(1813622, 0, "12b14a2704c7f9627814be9a96e90f1d984ed22193c291ba2aa9ead3d7203720")
addappid(1814450, 0, "c05c459984165420c43e50bbd9ac01e201e6acd674eb6a6a1660bff0cb86dd42")
