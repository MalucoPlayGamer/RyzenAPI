-- Lua provided by RyzenAPI
-- Game: 253840

-- MAIN APPLICATION
addappid(253840)
addappid(589560)
addappid(639310)
addappid(664790)
addappid(686710)
addappid(686711)
-- Game: addappid(253840)

-- MAIN APP DEPOTS / PACKAGES
addappid(253841, 1, "2b179febc3199ba5e83ba4dbf43d6d067b18a7ecb0d66a2d58fd1b378bace83a")
