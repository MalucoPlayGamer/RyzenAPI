-- Lua provided by RyzenAPI
-- Game: Shantae: Half-Genie Hero

-- MAIN APPLICATION
addappid(253840)
addappid(589560)
addappid(639310)
addappid(664790)
addappid(686710)
addappid(686711)

-- MAIN APP DEPOTS / PACKAGES
addappid(253841, 1, "2b179febc3199ba5e83ba4dbf43d6d067b18a7ecb0d66a2d58fd1b378bace83a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
