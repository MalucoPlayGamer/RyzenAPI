-- Lua provided by RyzenAPI
-- Game: Worms Clan Wars

-- MAIN APPLICATION
addappid(233840)

-- MAIN APP DEPOTS / PACKAGES
addappid(233841, 1, "3724b86e2d0d2c3db052bfc0367d12cde6fe2be6d90c4b99b5a835ba6085e957")
addappid(233842, 1, "d09b24bdec52c0c40d6a4bcb1af04e4bce3f0b5084ade8fdb51ff8c79b9df4a7")
addappid(233843, 1, "aa858ab7bdf21797d90c32e23be0aa79636be56404e38e9e8b5e8aeaaec53ff4")
addappid(233844, 1, "01b8288489e2f9e692d616f4d98e6a4a45b96582dd16ec6e9546b880e91fd683")
addappid(233845, 1, "eafd1d2eb9ba7e4b8227023cf8576a684f1d1977268401f999a4998417b1915a")
addappid(233846, 1, "5bed584d6b7724391505421bfd3e94b185138efc8e73a710943980cfec5599e4")
addappid(233849, 1, "88089202ac332c3cdbcc10e28561f7a5986cb6842e282f7441ba17594b7f41a4")
addappid(233850, 1, "5f5288d270adc1e50932faf70f17c266edce2d617757743228659b9141c78340")
addappid(233851, 1, "95431eccc23f1bbe97c5a2d175367cd0f09072a61337564e11f74b614c124a2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(243831)
addappid(264820)
