-- Lua provided by SkyAPI 
-- Game: Simpler Times Demo
addappid(2515510)
addappid(2515511, 1, "4671d65197a89d53b0652ccd58680c574663861f51479dd348687b051c5c5994")
