-- Lua provided by RyzenAPI
-- Game: Game: Simpler Times Demo

-- MAIN APPLICATION
addappid(2515510)
-- Game: addappid(2515510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515511, 1, "4671d65197a89d53b0652ccd58680c574663861f51479dd348687b051c5c5994")
