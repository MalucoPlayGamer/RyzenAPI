-- Lua provided by RyzenAPI
-- Game: Game: Grandma, No!

-- MAIN APPLICATION
addappid(2362680)
-- Game: addappid(2362680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362681, 1, "1a0c570021bab6c5aa4294d70efa9ca2565dc87f1600f5b98408884d1890bbb5")
addappid(3743920, 0, "86d5f3ae7962d79611f7f9316e1467554382f510dc0973c66562cf00afc5398f")
