-- Lua provided by RyzenAPI
-- Game: Grandma, No!

-- MAIN APPLICATION
addappid(2362680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2362681, 1, "1a0c570021bab6c5aa4294d70efa9ca2565dc87f1600f5b98408884d1890bbb5")
addappid(3743920, 0, "86d5f3ae7962d79611f7f9316e1467554382f510dc0973c66562cf00afc5398f")

