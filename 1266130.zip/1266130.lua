-- Lua provided by RyzenAPI
-- Game: Game: One Step From Eden Soundtrack

-- MAIN APPLICATION
addappid(1266130)
-- Game: addappid(1266130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266131, 1, "e83f3385a246e0a3977cea45243986483e3139248149b2664f47bcba98b2b2c8")
addappid(1266132, 1, "5fa9e2e73a134b7b5a9b018801de7c50e4d023b825d8f8b5a6c62818a695e685")
