-- Lua provided by RyzenAPI 
-- Game: One Step From Eden Soundtrack
addappid(1266130)
addappid(1266131, 1, "e83f3385a246e0a3977cea45243986483e3139248149b2664f47bcba98b2b2c8")
addappid(1266132, 1, "5fa9e2e73a134b7b5a9b018801de7c50e4d023b825d8f8b5a6c62818a695e685")
