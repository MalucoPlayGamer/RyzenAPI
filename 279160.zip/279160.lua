-- Lua provided by RyzenAPI
-- Game: 279160

-- MAIN APPLICATION
addappid(279160)
-- Game: addappid(279160)

-- MAIN APP DEPOTS / PACKAGES
addappid(279161, 1, "b0e2ba86cfb960e0c6745371ef03a612606d4714c098ed130355d42240cb6b8c")
