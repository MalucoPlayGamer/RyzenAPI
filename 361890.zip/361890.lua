-- Lua provided by RyzenAPI
-- Game: Chronostorm: Siberian Border

-- MAIN APPLICATION
addappid(361890)

-- MAIN APP DEPOTS / PACKAGES
addappid(361891, 1, "cf80f17989c9eb4f5de905e29e3c655bc460ca57ab5a2425b32996fb83f5ed22")
addappid(361892, 1, "57561c6e08b03b4f48721732a461c27040e2a6a7f5de9429e513f79144a3a44a")
