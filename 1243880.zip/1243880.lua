-- Lua provided by RyzenAPI 
-- Game: AppID 1243880
addappid(1243880)
addappid(1243881, 1, "9c76c46b4e15c982e34a35e5fcad6928f0edd9f79bfc5bd39c1fc18d4e70b35d")
