-- Lua provided by RyzenAPI
-- Game: Game: AppID 1243880

-- MAIN APPLICATION
addappid(1243880)
-- Game: addappid(1243880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243881, 1, "9c76c46b4e15c982e34a35e5fcad6928f0edd9f79bfc5bd39c1fc18d4e70b35d")
