-- Lua provided by SkyAPI 
-- Game: AppID 1016630
addappid(1016630)
addappid(1016631, 1, "90b264959d549ec083c54f1f929e664a64dd2be50c6f9302378dc26df68fe4dd")
