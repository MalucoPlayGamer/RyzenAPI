-- Lua provided by RyzenAPI
-- Game: Game: AppID 1016630

-- MAIN APPLICATION
addappid(1016630)
-- Game: addappid(1016630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016631, 1, "90b264959d549ec083c54f1f929e664a64dd2be50c6f9302378dc26df68fe4dd")
