-- Lua provided by RyzenAPI
-- Game: Spheroid

-- MAIN APPLICATION
addappid(399100)

-- MAIN APP DEPOTS / PACKAGES
addappid(399101, 1, "771ccf359abb52ff42ea5a95bee31bd33d43a7a3e7cbe106f24eb10edc8a8e95")

