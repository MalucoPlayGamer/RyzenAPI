-- Lua provided by RyzenAPI
-- Game: Lasagna Boy

-- MAIN APPLICATION
addappid(1590330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590331, 1, "282e2bc58f654456d2a7007dfdb9370546a1886996d27602c5846e2c5d49ebcb")
