-- Lua provided by RyzenAPI
-- Game: Lycoris

-- MAIN APPLICATION
addappid(3342190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342191, 1, "b304a55e26a298a6570c55d40e6f1699e41534c3beef5b53ce90d15f28a8c3c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5048590)
addappid(5051660)
addappid(5051680)
