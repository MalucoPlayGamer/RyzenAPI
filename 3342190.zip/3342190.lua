-- Lua provided by RyzenAPI 
-- Game: Lycoris
addappid(3342190)
addappid(3342191, 1, "b304a55e26a298a6570c55d40e6f1699e41534c3beef5b53ce90d15f28a8c3c0")
