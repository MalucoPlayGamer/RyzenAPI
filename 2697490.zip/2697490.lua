-- Lua provided by RyzenAPI
-- Game: 欺神弄鬼

-- MAIN APPLICATION
addappid(2697490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697491, 1, "4597f45d9ef1e69cfed27b87576d5f3b2b962dfeb9ee469aa7a28738d7069cfb")
addappid(2697492, 1, "d55b322d81492867c57230e2563f7f2289935625c339196559782a227da25962")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
