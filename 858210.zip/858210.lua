-- Lua provided by RyzenAPI
-- Game: addappid(858210)

-- MAIN APPLICATION
addappid(858210)

-- MAIN APP DEPOTS / PACKAGES
addappid(858211, 1, "58e0679d07528daeb35c94909da808aae291b0fe82ed12acb7a36e5184996211")
addappid(858212, 1, "c43ede038eccd94404e47d5f61330fd8797267aff1a17b9df3f1e9ee475f31c1")
