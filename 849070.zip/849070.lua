-- Lua provided by SkyAPI 
-- Game: AppID 849070
addappid(849070)
addappid(849071, 1, "bb7681be3163c41d5ab0dbf0d2f1aa369f4c78fe9fda87a450009c892d3e1380")
