-- Lua provided by RyzenAPI
-- Game: Game: AppID 849070

-- MAIN APPLICATION
addappid(849070)
-- Game: addappid(849070)

-- MAIN APP DEPOTS / PACKAGES
addappid(849071, 1, "bb7681be3163c41d5ab0dbf0d2f1aa369f4c78fe9fda87a450009c892d3e1380")
