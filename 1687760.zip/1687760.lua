-- Lua provided by RyzenAPI
-- Game: Exos Heroes

-- MAIN APPLICATION
addappid(1687760)
-- Game: addappid(1687760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687761, 1, "845814fb11d98995d63e505a918776c40257b212ae030a91548777c5ae396e43")
