-- Lua provided by RyzenAPI
-- Game: 3163820

-- MAIN APPLICATION
addappid(3163820)
-- Game: addappid(3163820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163821, 1, "31ef28ea0ad1d67bab2bd3a31e7ffbd006a2f42ab18d03778503e8df0aba6b95")
