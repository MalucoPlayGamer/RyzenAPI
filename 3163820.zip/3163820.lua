-- Lua provided by SkyAPI 
-- Game: Habilis Demo
addappid(3163820)
addappid(3163821, 1, "31ef28ea0ad1d67bab2bd3a31e7ffbd006a2f42ab18d03778503e8df0aba6b95")
