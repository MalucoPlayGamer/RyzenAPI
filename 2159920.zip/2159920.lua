-- Lua provided by RyzenAPI
-- Game: addappid(2159920)

-- MAIN APPLICATION
addappid(2159920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159921, 1, "9a09dd1220e71d62e42f13949d2eadf4db1ff2d7d85ea4472f1709677a6413bb")
