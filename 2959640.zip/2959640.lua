-- Lua provided by RyzenAPI
-- Game: 終わりの森 -Forest of soul slave-

-- MAIN APPLICATION
addappid(2959640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959644,0,"fcfa27fbb68fe3ee8809436bb6bef9e143b192fd7299c7a67b0edeea561c0ef2")

