-- Lua provided by RyzenAPI
-- Game: Game: Sine Mora EX

-- MAIN APPLICATION
addappid(606730)
-- Game: addappid(606730)

-- MAIN APP DEPOTS / PACKAGES
addappid(606731, 1, "1e054109f19a5a101d5739a9c79b89842ecc3afb08686af505c3bf29a8af2af8")
