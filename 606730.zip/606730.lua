-- Lua provided by RyzenAPI
-- Game: Sine Mora EX

-- MAIN APPLICATION
addappid(606730)

-- MAIN APP DEPOTS / PACKAGES
addappid(606731, 1, "1e054109f19a5a101d5739a9c79b89842ecc3afb08686af505c3bf29a8af2af8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
