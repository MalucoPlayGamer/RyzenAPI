-- Lua provided by RyzenAPI
-- Game: addappid(1373580)

-- MAIN APPLICATION
addappid(1373580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373581, 1, "23e65f306e25b8bacc15036ab123b4df691fb4f459bd97b69bfe43c67acfb94e")
