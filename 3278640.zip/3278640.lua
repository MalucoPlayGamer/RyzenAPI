-- Lua provided by RyzenAPI
-- Game: New Year Simulator 2025 Demo

-- MAIN APPLICATION
addappid(3278640)
-- Game: addappid(3278640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278641, 1, "e392548c769c973692e9e5e66e841da5c68f5d4d80e42754f3e662bcc981d0e8")
