-- Lua provided by RyzenAPI
-- Game: Cozy Marbles Demo

-- MAIN APPLICATION
addappid(3015200)
-- Game: addappid(3015200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015201, 1, "a78831a4b776d1c5af9638e2fbf8290768e775c07353c8cb91d4722c98fac73b")
