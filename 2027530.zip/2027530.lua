-- Lua provided by RyzenAPI
-- Game: Game: non-binary

-- MAIN APPLICATION
addappid(2027530)
-- Game: addappid(2027530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027531, 1, "454fa42b2d0e95a9ddd2b217b0d37bb47e4413ba3324838f7115407f86ce0c20")
addappid(2027532, 1, "69cc4b9f4b26835046f08f753e2b8dc10e88f9765276730bf21aceb7b5f9fc79")
addappid(2027533, 1, "4f02de60bfcec8e991ccb89e18bf2383e8e2386b72df75484bdb46d55736f7f6")
