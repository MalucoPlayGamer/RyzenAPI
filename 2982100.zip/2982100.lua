-- Lua provided by RyzenAPI
-- Game: Game: Fish-Click Squad!

-- MAIN APPLICATION
addappid(2982100)
-- Game: addappid(2982100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982101, 1, "5222c355e517a15ee218f9237c000297d9ceef3e8b7ec14330b17c6222dff7a2")
