-- Lua provided by RyzenAPI
-- Game: Fish-Click Squad!

-- MAIN APPLICATION
addappid(2982100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982101, 1, "5222c355e517a15ee218f9237c000297d9ceef3e8b7ec14330b17c6222dff7a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
