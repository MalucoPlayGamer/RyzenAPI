-- Lua provided by RyzenAPI
-- Game: Game: LoveChoice

-- MAIN APPLICATION
addappid(939400)
-- Game: addappid(939400)

-- MAIN APP DEPOTS / PACKAGES
addappid(939401, 1, "3a2d79ac79062d664b483de2432f7042712b61c292f6a6de153249683d1c76e4")
addappid(939402, 1, "ac228093fd16a88922f12faeeccd2a47f022b9b2a19b4715b90a973d79c1b802")
addappid(939403, 1, "6f515d8ff7bef0ac5ea03920ce8931a0d24e5a30dc5fdcbbce36979bee4fc59a")
addappid(942430, 0, "660daf7e115e3c7aad818c634ad80a793ab166d030aaafa7fe56e9890558275d")
addappid(1111070, 0, "f974ed2eb86589f385785228ad9c78e49cdaceea79c5797e78d060d32796f5f8")
addappid(1156960, 0, "3ff5f18c9af43aa87be45be6f03c868644fc166a8ed2369cca4dfd3a8f6c07d0")
