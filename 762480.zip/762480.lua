-- Lua provided by RyzenAPI
-- Game: AppID 762480

-- MAIN APPLICATION
addappid(762480)

-- MAIN APP DEPOTS / PACKAGES
addappid(762481, 1, "d2d0a5dbd398eeaeff653c739f040d4a9978d42733f24cdbacd0ee73aa7e9413")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
