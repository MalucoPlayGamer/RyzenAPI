-- Lua provided by RyzenAPI
-- Game: Game: AppID 762480

-- MAIN APPLICATION
addappid(762480)
-- Game: addappid(762480)

-- MAIN APP DEPOTS / PACKAGES
addappid(762481, 1, "d2d0a5dbd398eeaeff653c739f040d4a9978d42733f24cdbacd0ee73aa7e9413")
