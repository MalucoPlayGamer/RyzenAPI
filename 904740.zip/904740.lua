-- Lua provided by RyzenAPI
-- Game: 东方试闻广纪 ~ Perfect Memento of Touhou Question

-- MAIN APPLICATION
addappid(904740)
-- Game: addappid(904740)

-- MAIN APP DEPOTS / PACKAGES
addappid(904741, 1, "199e4ea68b4de6282d492337a04ccf85d21fa838e6d207201bd8df4ca64adc2e")
addappid(904742, 1, "a7bcd41e44c5241f5cd5561efa83d21a0df1f3628795e44f18d620296c3ef7c1")
addappid(916360, 0, "65f4c2d0fac677cad75963d4c98f03b6b70851f523f7fa66d7c9165e2e91e09d")
addappid(916361, 0, "58ccba3f4dfa63d8fee1580b730cb7b971bb7cc41af14140c09d161b3287b8eb")
