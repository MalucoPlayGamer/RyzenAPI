-- Lua provided by RyzenAPI
-- Game: Ghost Pub

-- MAIN APPLICATION
addappid(3337710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337711, 1, "807d45539e2d237e60ca34316c4cbf5091c58a1b890658e5a90b011daedd0715")
