-- Lua provided by RyzenAPI
-- Game: Tetraclash Reforged

-- MAIN APPLICATION
addappid(4431180) -- Tetraclash Reforged

-- MAIN APP DEPOTS / PACKAGES
addappid(4431182, 1, "91c2fef6a7aae27379b68a1bb88f74f36ca54a9261d73e73fee83cf993f2ee82") -- Depot 4431182

