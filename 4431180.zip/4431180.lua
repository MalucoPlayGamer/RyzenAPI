-- 4431180's Lua and Manifest Created by Hubcap Manifest
-- Tetraclash Reforged
-- Created: August 24, 2026 at 07:09:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4431180) -- Tetraclash Reforged
-- MAIN APP DEPOTS
addappid(4431182, 1, "91c2fef6a7aae27379b68a1bb88f74f36ca54a9261d73e73fee83cf993f2ee82") -- Depot 4431182
setManifestid(4431182, "6827306179894184623", 2775866348)