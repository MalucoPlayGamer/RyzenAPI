-- Lua provided by RyzenAPI
-- Game: Snakecremental

-- MAIN APPLICATION
addappid(3570430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3570433,0,"82df73b2df34172bf4aa906504721c572871ef91a30b94f386b4d5ade0c8e3ef")
