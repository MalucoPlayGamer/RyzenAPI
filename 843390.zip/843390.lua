-- Lua provided by SkyAPI 
-- Game: Vertigo 2
addappid(843390)
addappid(843391, 1, "d6719362ab7b91b7b7ec67588c8c21cb1ba032f364c426766125ebaecd54b480")
addappid(3305800, 0, "f69390528fc96dd5af5b5de38f49b813fe1cb30ce5e819d718aeec1cd385d6b8")
