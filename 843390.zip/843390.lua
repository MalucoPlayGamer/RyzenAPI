-- Lua provided by RyzenAPI
-- Game: Vertigo 2

-- MAIN APPLICATION
addappid(843390)

-- MAIN APP DEPOTS / PACKAGES
addappid(843391, 1, "d6719362ab7b91b7b7ec67588c8c21cb1ba032f364c426766125ebaecd54b480")
addappid(3305800, 0, "f69390528fc96dd5af5b5de38f49b813fe1cb30ce5e819d718aeec1cd385d6b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
