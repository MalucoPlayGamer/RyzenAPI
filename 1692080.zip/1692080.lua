-- Lua provided by RyzenAPI 
-- Game: SVFI
addappid(1692080)
addappid(1692081, 1, "b0eb4797a1aa370628b12a367482f2163f60d1c091ab9206a462f8092fa04ca4")
