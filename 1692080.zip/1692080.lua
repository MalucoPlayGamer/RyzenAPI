-- Lua provided by RyzenAPI
-- Game: SVFI

-- MAIN APPLICATION
addappid(1692080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692081, 1, "b0eb4797a1aa370628b12a367482f2163f60d1c091ab9206a462f8092fa04ca4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1718750)
addappid(1758570)
addappid(1813870)
addappid(1991700)
