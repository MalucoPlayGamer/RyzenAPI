-- Lua provided by RyzenAPI 
-- Game: AppID 843790
addappid(843790)
addappid(843791, 1, "23d97b8b8489124133ec6d1088cf5241bca7bd007b3b6e202a25d440f5577754")
