-- Lua provided by RyzenAPI
-- Game: 23530

-- MAIN APPLICATION
addappid(23530)
-- Game: addappid(23530)

-- MAIN APP DEPOTS / PACKAGES
addappid(23531, 1, "b0fc760193586cb634e4639fd3512cd892a30d8c75e7a0f7bc679a49b1f54b12")
addappid(23532, 1, "1cbb52f4c5155a7b18731f2f5337d1b42bed4938a923c467e47670f40cbb3806")
