-- Lua provided by RyzenAPI
-- Game: theBlu

-- MAIN APPLICATION
addappid(2217730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217731, 1, "117fa56cfcd395b013177631ef7eae49acac72e61165fd73cb31494d6e6f0c89")

