-- Lua provided by RyzenAPI
-- Game: Shiver

-- MAIN APPLICATION
addappid(727730)

-- MAIN APP DEPOTS / PACKAGES
addappid(727731, 1, "9eb431740f5f158091d84c7a6b089c9efee3fc84caf2c4f5a813bb00d8e5d3b8")
addappid(727732, 1, "eb4430f9ed3a223bc55460ce81045c0655993d54d9212f640be7a1cbfde808b3")
addappid(727733, 1, "e5ae7d57bd954ef26613af597e8a439db60144cceea81a08356c02a6b6422f4c")

