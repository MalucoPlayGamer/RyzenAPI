-- Lua provided by RyzenAPI
-- Game: addappid(2698780)

-- MAIN APPLICATION
addappid(2698780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698781, 1, "828d5f7224a4a0900737bb184f8ebcb2f7db10894724f2ca7d7d06c9904cf1cd")
