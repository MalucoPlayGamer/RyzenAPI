-- Lua provided by RyzenAPI
-- Game: ContractVille

-- MAIN APPLICATION
addappid(2698780)
addappid(3969000)
addappid(4075310)
addappid(4207210)
addappid(4376710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698781,0,"828d5f7224a4a0900737bb184f8ebcb2f7db10894724f2ca7d7d06c9904cf1cd")

