-- Lua provided by RyzenAPI
-- Game: ContractVille

-- MAIN APPLICATION
addappid(2698780)
addappid(3969000)
addappid(4075310)
addappid(4207210)
addappid(4376710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698781,0,"828d5f7224a4a0900737bb184f8ebcb2f7db10894724f2ca7d7d06c9904cf1cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
