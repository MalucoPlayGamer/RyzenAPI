-- Lua provided by RyzenAPI
-- Game: addappid(3558260)

-- MAIN APPLICATION
addappid(3558260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558261, 1, "6580c4468c2882592a278cd5729d0e781f017daf5fdda67b6093feb5be9ad78d")
