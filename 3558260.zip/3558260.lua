-- Lua provided by RyzenAPI
-- Game: 奈布的冒险 - Naib's Adventure

-- MAIN APPLICATION
addappid(3558260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3558261, 1, "6580c4468c2882592a278cd5729d0e781f017daf5fdda67b6093feb5be9ad78d")

