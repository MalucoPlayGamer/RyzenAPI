-- Lua provided by RyzenAPI
-- Game: addappid(773440)

-- MAIN APPLICATION
addappid(773440)

-- MAIN APP DEPOTS / PACKAGES
addappid(773441, 1, "3e1ef28b0e7848c8e2f5f235d11e9c50e4ce645814591fae35e3850587eb7f07")
