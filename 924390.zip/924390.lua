-- Lua provided by RyzenAPI
-- Game: Ozapell Mystery Text Adventure

-- MAIN APPLICATION
addappid(924390)

-- MAIN APP DEPOTS / PACKAGES
addappid(924391, 1, "41df0e2247d6bffe43c98c55da919fe3877fead259e314ef892a8d2a9b7bf017")
