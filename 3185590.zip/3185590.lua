-- Lua provided by RyzenAPI
-- Game: addappid(3185590)

-- MAIN APPLICATION
addappid(3185590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3185591, 1, "678d81fd4ccba55d0ab3da5dd526b31f2753814a7f44e08f2343228e92f43e20")
