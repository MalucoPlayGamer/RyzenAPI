-- Lua provided by RyzenAPI
-- Game: Along the Edge

-- MAIN APPLICATION
addappid(504390)

-- MAIN APP DEPOTS / PACKAGES
addappid(504392,0,"14671570ab864ed4e00973fe2773d2c8a8bc233b9484010b7c992fb06421d354")

