-- Lua provided by RyzenAPI
-- Game: Rogue Sentry

-- MAIN APPLICATION
addappid(1555770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555771, 1, "5ec298b8699698cdf80b9b543a1dedccb4d0d243ddf1f8c9d51a52d4d74af184")
