-- Lua provided by RyzenAPI
-- Game: AppID 741560

-- MAIN APPLICATION
addappid(741560)

-- MAIN APP DEPOTS / PACKAGES
addappid(741561, 1, "ed5ad6764dc63d62fb7e2d6caf6926d0c6b13d1d1cb6f46f0ffdc1830b4f66f4")
