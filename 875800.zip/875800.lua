-- Lua provided by RyzenAPI
-- Game: Wasteland Remastered

-- MAIN APPLICATION
addappid(875800)

-- MAIN APP DEPOTS / PACKAGES
addappid(875801, 1, "f116095f880297a886450d3bdce43172644d13644efb3f24d9e3ac2678e31af7")

