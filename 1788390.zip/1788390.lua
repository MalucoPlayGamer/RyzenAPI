-- Lua provided by RyzenAPI
-- Game: Insect Seeker

-- MAIN APPLICATION
addappid(1788390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788391, 1, "d419d4898988ce8132b52690a8a6c4c269b8bf4d83e4415203b252e159cc5112")
