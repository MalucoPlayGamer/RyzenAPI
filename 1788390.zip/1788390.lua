-- Lua provided by RyzenAPI
-- Game: Insect Seeker

-- MAIN APPLICATION
addappid(1788390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1788391, 1, "d419d4898988ce8132b52690a8a6c4c269b8bf4d83e4415203b252e159cc5112")

