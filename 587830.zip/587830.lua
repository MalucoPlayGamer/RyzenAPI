-- Lua provided by RyzenAPI
-- Game: addappid(587830)

-- MAIN APPLICATION
addappid(587830)

-- MAIN APP DEPOTS / PACKAGES
addappid(587831, 1, "49b5f4c6096039c9d390c31d76a335e5d0463fcab4fc7701cffdc55e42e42a76")
