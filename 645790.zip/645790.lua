-- Lua provided by SkyAPI 
-- Game: AppID 645790
addappid(645790)
addappid(645791, 1, "feccfd5342a7e4ba0fd54520406e7d5a935f755868e1f92a0630768e0d8dc1ec")
