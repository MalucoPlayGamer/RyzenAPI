-- Lua provided by RyzenAPI
-- Game: AppID 645790

-- MAIN APPLICATION
addappid(645790)

-- MAIN APP DEPOTS / PACKAGES
addappid(645791, 1, "feccfd5342a7e4ba0fd54520406e7d5a935f755868e1f92a0630768e0d8dc1ec")
