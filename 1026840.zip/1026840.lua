-- Lua provided by RyzenAPI
-- Game: Ultra Fight Da ! Kyanta 2

-- MAIN APPLICATION
addappid(1026840)
-- Game: addappid(1026840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026841, 1, "4f3dd504e06823c06451c5582130186525dd7285123606d759a31fd398ff467c")
