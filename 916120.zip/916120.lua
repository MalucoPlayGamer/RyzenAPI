-- Lua provided by RyzenAPI
-- Game: Rascals

-- MAIN APPLICATION
addappid(916120)

-- MAIN APP DEPOTS / PACKAGES
addappid(916121, 1, "67de557740de47e7b9cdde9105bcdea573dc2edbfb94b8a7b97822010bbd0a25")
