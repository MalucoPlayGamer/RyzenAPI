-- Lua provided by RyzenAPI
-- Game: Game: A Planet of Mine Legacy

-- MAIN APPLICATION
addappid(1170980)
-- Game: addappid(1170980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170981, 1, "d1dfd559075f865d16e36f49fbb7e99f9a6f162a0a0d5aa946dda0f5e4fde8a2")
