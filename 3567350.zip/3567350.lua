-- Lua provided by RyzenAPI
-- Game: Deadly Joy

-- MAIN APPLICATION
addappid(3567350)
addappid(3703400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3567351, 1, "3b868ee7ecefd35dede6486ffd9a0d92f8fdc9066d2e0b1db95414ea161ed08c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
