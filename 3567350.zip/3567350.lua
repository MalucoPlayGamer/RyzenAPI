-- Lua provided by RyzenAPI
-- Game: 3567350

-- MAIN APPLICATION
addappid(3567350)
addappid(3703400)
-- Game: addappid(3567350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3567351, 1, "3b868ee7ecefd35dede6486ffd9a0d92f8fdc9066d2e0b1db95414ea161ed08c")
