-- Lua provided by RyzenAPI
-- Game: You Shall Not Jump: PC Master Race Edition

-- MAIN APPLICATION
addappid(649000)
-- Game: addappid(649000)

-- MAIN APP DEPOTS / PACKAGES
addappid(649001, 1, "3c2e5275ad5f61ea3be9fecdb70281d948256ece1d5e6ae47481dd790f257ec6")
