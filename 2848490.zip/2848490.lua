-- Lua provided by RyzenAPI
-- Game: LipTrip ~My Boss Is My Heat Suppressant?!~ Soundtrack

-- MAIN APPLICATION
addappid(2848490)
addappid(2848491)
addappid(2848492)
addappid(2848493)
addappid(2848494)
addappid(2848497)
addappid(2848498)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848495,0,"ba64447db4661cf36ba422a211a54743a4dc32817ed0dff42566efd050bed6d1")
addappid(2848496,0,"7eafe63370a19b5719cb59dacd6d255566c14335eabc916c41e3779c896eafe2")
