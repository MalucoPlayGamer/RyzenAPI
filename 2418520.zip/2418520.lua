-- 2418520's Lua and Manifest Created by Hubcap Manifest
-- Farm Together 2
-- Created: August 06, 2026 at 07:06:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2418520, 1, "642adfecb8375f832de004975c86f76e69c45dc04744d4892a00c54fa708d523") -- Farm Together 2
-- MAIN APP DEPOTS
addappid(2418521, 1, "b6dcb6a58e587a247bf3b0b52bd350fd82061e80a8241d850b7c960e1a1d71ba") -- Depot 2418521
setManifestid(2418521, "8117482954128138898", 1208915487)
addappid(2418522, 1, "e5ad2ced2bcacfc70ee06a58946c9578454480ca23214852204bc8a3a3247300") -- Depot 2418522
setManifestid(2418522, "7628220796110843090", 1243936432)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3724330) -- Farm Together 2 - Explorer Pack
addappid(3985700) -- Farm Together 2 - Meadow Pack
addappid(4094000) -- Farm Together 2 - Gothic Pack
addappid(4232610) -- Farm Together 2 - Frosty Pack
addappid(4580980) -- Farm Together 2 - Cyber Pack