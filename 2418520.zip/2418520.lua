-- Lua provided by RyzenAPI 
-- Game: Farm Together 2
addappid(2418520)
addappid(2418521, 1, "b6dcb6a58e587a247bf3b0b52bd350fd82061e80a8241d850b7c960e1a1d71ba")
addappid(2418522, 1, "e5ad2ced2bcacfc70ee06a58946c9578454480ca23214852204bc8a3a3247300")
addappid(3724330)
