-- Lua provided by RyzenAPI
-- Game: Metaphor: ReFantazio - Prologue Demo

-- MAIN APPLICATION
addappid(3130330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130331, 1, "c14735f2116debc71117f6e4bd96a9e89734623b28a15563762ee7054608b801")
