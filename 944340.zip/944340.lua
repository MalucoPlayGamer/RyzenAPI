-- Lua provided by RyzenAPI
-- Game: 944340

-- MAIN APPLICATION
addappid(944340)
-- Game: addappid(944340)

-- MAIN APP DEPOTS / PACKAGES
addappid(944341, 1, "6881ae6d56f14002106eaa3395aca839cf2eba7963feb2092b676a119580c2bf")
