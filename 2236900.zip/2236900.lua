-- Lua provided by RyzenAPI
-- Game: Game: AppID 2236900

-- MAIN APPLICATION
addappid(2236900)
-- Game: addappid(2236900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236901, 1, "aebbc49d9d84f8bdfd68ba53182273a24afd8270839207c4007735adaf24cb32")
