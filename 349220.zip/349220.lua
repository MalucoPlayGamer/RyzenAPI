-- Lua provided by RyzenAPI
-- Game: addappid(349220)

-- MAIN APPLICATION
addappid(349220)
addappid(379750)
addappid(569850)
addappid(760340)

-- MAIN APP DEPOTS / PACKAGES
addappid(349221, 1, "63d62289132fce52684c0edcc5ec49b6f8ceccbe99859ffc667f92d9398a7cd9")
addappid(349222, 1, "1471e1599f8377acab3adde4dfbbc6827f39a1f3b39113e2e288a82a6c08388e")
addappid(349223, 1, "499922e2f380d802c6c0b95733579a991c1259a7fcb3629b6323d5d22282bfc0")
addappid(349224, 1, "3707ccb9c2d81c9365dc15691a6d326cfb7fccda8724f7cd6acb9db0be003fa7")
addappid(396810, 0, "d0abb7eb9331688ab9b2e67d3ffcf0115286c82c1a2ac01b5edc165436f5fe29")
addappid(397370, 0, "ec734f9d41ef63c30798187bb594e29de3b8938399bcb1d260ca6db4ef6c1d59")
