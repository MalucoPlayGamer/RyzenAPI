-- Lua provided by SkyAPI 
-- Game: Cook OL
addappid(1986070)
addappid(1986071, 1, "ec44e185341b320abed07b8d77a84875c2f56e8dd25f1ee482b73139b7d3c9d6")
