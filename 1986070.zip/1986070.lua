-- Lua provided by RyzenAPI
-- Game: Cook OL

-- MAIN APPLICATION
addappid(1986070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986071, 1, "ec44e185341b320abed07b8d77a84875c2f56e8dd25f1ee482b73139b7d3c9d6")

