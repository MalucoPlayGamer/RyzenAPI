-- Lua provided by RyzenAPI
-- Game: Lord of the Rings: War in the North

-- MAIN APPLICATION
addappid(32800)

-- MAIN APP DEPOTS / PACKAGES
addappid(32802,0,"10b9e8252758a0c55cd70d0ccaae029a76980b8ae7a73c0a45c7743dfdfad065")
addappid(32803,0,"9550d4c9bc7379680abd169767e8c9963940e4ae82847d2e803321d749e69250")
addappid(32804,0,"2ba55bf8ff15c7d2e9b66da5ad233678dbacc1935b659f8dfd8d1dbd4a7a4421")
addappid(32805,0,"cbfadf1197cef0ef75989ffb7a55763ed38fe99f51f79bfc80c108fefee805fd")
addappid(32806,0,"a40c71dcd6cc0120cc4119e706f8db7cbe365c56b7ce5ee9ea3a8bca20566fe8")
addappid(32807,0,"8a90761e8b31037ff9e112dbc877e925c8da47febaa0614cc589f1844a8e793a")
addappid(32808,0,"a7b704b5462039247e25a07ae14c124b70fb67bbb990566c6414562b5b2fe5c8")
addappid(32809,0,"b671f792b1a1ba659d68d71c1fecbeb10745f22a9d9a739a4e81a5454bda3daf")
addappid(32810,0,"bfdd58c12089ef3308958bfc15ff0f1406d691ee5f07a32e037f438a49133740")
addappid(32811,0,"ef92963ceef72e2b86e0c281840ab594728ab6012e49e072c55c1a3cc1042bf5")
addappid(32814,0,"baf7ee5dcaffb0584fcfa871a430f2d401167285042b5013495b05f9a91b41c4")
addappid(32815,0,"e4b31587091c196c0ede7143130a21fed4f077a00fae0505f9af8591e4cc7cb8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(32830)
addappid(32831)
addappid(32832)
addappid(32833)
addappid(32834)
