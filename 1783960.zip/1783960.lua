-- Lua provided by RyzenAPI
-- Game: addappid(1783960)

-- MAIN APPLICATION
addappid(1783960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783961, 1, "69323c057e577fefefaffe3434ba95320c219f9b6fb86dcd179b68a71430a5b0")
