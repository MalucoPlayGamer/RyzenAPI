-- Lua provided by RyzenAPI
-- Game: addappid(2577520)

-- MAIN APPLICATION
addappid(2577520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577521, 1, "5e8d39fd18f24d2cb1ef4b499064ae3a026e90777fa847d8695845ea58c64524")
