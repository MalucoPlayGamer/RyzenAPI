-- Lua provided by SkyAPI 
-- Game: Race Race Racer
addappid(1190380)
addappid(1190381, 1, "e35c3dbfe5f749dd7867e0696b0a4653927ac205b0e338ed5d55e51f84e89686")
