-- Lua provided by RyzenAPI
-- Game: Race Race Racer

-- MAIN APPLICATION
addappid(1190380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190381, 1, "e35c3dbfe5f749dd7867e0696b0a4653927ac205b0e338ed5d55e51f84e89686")

