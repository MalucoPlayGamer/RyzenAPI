-- Lua provided by RyzenAPI
-- Game: 467660

-- MAIN APPLICATION
addappid(467660)
-- Game: addappid(467660)

-- MAIN APP DEPOTS / PACKAGES
addappid(467661, 1, "bb60992510d4cd7e4c854ab1099be01618a38f64d867c4ed1cb094e2e3aecba8")
