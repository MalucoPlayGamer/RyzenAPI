-- Lua provided by RyzenAPI
-- Game: Game: You, Calligrapher

-- MAIN APPLICATION
addappid(1593700)
-- Game: addappid(1593700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593701, 1, "192be818ae189ce3a72b3c89e38cdf8b152461020008a5bd05870d11a34b2e8a")
