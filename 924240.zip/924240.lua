-- Lua provided by RyzenAPI
-- Game: Them and Us Demo

-- MAIN APPLICATION
addappid(924240)
-- Game: addappid(924240)

-- MAIN APP DEPOTS / PACKAGES
addappid(924248,0,"253c7612ab0a910ef9a4a599f7f6885da8020bba5ef5965e6fd8d3938dc34ed4")
