-- Lua provided by RyzenAPI 
-- Game: AppID 465920
addappid(465920)
addappid(465921, 1, "007619356d5b33481278b82b2196bf8adc824fda28bfc77709605206270ffbfa")
