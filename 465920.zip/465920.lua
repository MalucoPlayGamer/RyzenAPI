-- Lua provided by RyzenAPI
-- Game: Echoes of the Past: The Revenge of the Witch Collector's Edition

-- MAIN APPLICATION
addappid(465920)

-- MAIN APP DEPOTS / PACKAGES
addappid(465921, 1, "007619356d5b33481278b82b2196bf8adc824fda28bfc77709605206270ffbfa")
