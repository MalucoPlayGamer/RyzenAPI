-- Lua provided by RyzenAPI
-- Game: Game: Wraiths of SENTINEL

-- MAIN APPLICATION
addappid(1662750)
-- Game: addappid(1662750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662751, 1, "e15a53722aca4e47d330ba0f19f7d53c34dc8930464c622c614ae65d7ae229a4")
