-- Lua provided by RyzenAPI
-- Game: addappid(3206200)

-- MAIN APPLICATION
addappid(3206200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206201, 1, "481e3c72ac2a28662516e387d1f758c8d44ec0f5b6d23a4d0c707989e7d60cd3")
