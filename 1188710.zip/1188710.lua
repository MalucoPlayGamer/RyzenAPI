-- Lua provided by SkyAPI 
-- Game: Bloodholic
addappid(1188710)
addappid(1188711, 1, "0838510e4bc97239acb5b1f4909ff9239715bc1db254abe582227f249231cd73")
