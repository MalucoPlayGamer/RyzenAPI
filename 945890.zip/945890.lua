-- Lua provided by RyzenAPI
-- Game: Game: Hentai no Hero

-- MAIN APPLICATION
addappid(945890)
-- Game: addappid(945890)

-- MAIN APP DEPOTS / PACKAGES
addappid(945891, 1, "38cb27a1abc5b96e3893ce56bcab998972b94af20ec90e9f47cc492a82d5e8e8")
