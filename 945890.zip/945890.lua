-- Lua provided by RyzenAPI
-- Game: Hentai no Hero

-- MAIN APPLICATION
addappid(945890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(945891, 1, "38cb27a1abc5b96e3893ce56bcab998972b94af20ec90e9f47cc492a82d5e8e8")

