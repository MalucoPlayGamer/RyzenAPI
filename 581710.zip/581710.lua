-- Lua provided by RyzenAPI
-- Game: addappid(581710)

-- MAIN APPLICATION
addappid(581710)

-- MAIN APP DEPOTS / PACKAGES
addappid(581711, 1, "f8e4453470302cb20603befa0ae3297c6827063d26290cdd5be3b2b16af38169")
