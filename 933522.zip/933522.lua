-- Lua provided by RyzenAPI
-- Game: 933522

-- MAIN APPLICATION
addappid(933522)
-- Game: addappid(933522)

-- MAIN APP DEPOTS / PACKAGES
addappid(933522,0,"cb78261ed2eeb2eba74e96764a4b68c2c1553d34a2fa64f11363491b2965098d")
