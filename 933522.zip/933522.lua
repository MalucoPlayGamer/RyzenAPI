-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Jin Pack

-- MAIN APPLICATION
addappid(933522)

-- MAIN APP DEPOTS / PACKAGES
addappid(933522,0,"cb78261ed2eeb2eba74e96764a4b68c2c1553d34a2fa64f11363491b2965098d")
