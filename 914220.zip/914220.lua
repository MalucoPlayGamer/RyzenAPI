-- Lua provided by RyzenAPI
-- Game: Land of Puzzles: Castles

-- MAIN APPLICATION
addappid(914220)

-- MAIN APP DEPOTS / PACKAGES
addappid(914221, 1, "70a611d5b810e17cd19bfefb0e669ee0fd054d9f24155ce33a531f9428af8386")

