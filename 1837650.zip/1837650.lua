-- Lua provided by RyzenAPI
-- Game: 1837650

-- MAIN APPLICATION
addappid(1837650)
-- Game: addappid(1837650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837651, 1, "2f069a953ee97fe43e5339f4f1b25159ec236830dd8a304835de4f215d0e6cea")
