-- Lua provided by RyzenAPI
-- Game: 3221660

-- MAIN APPLICATION
addappid(3221660)
-- Game: addappid(3221660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3221661, 1, "a8de9081d2bb7a613b7c3dc7941c2b46587e9b38586f50d0962ff0e54eec801a")
