-- Lua provided by SkyAPI 
-- Game: AppID 3221660
addappid(3221660)
addappid(3221661, 1, "a8de9081d2bb7a613b7c3dc7941c2b46587e9b38586f50d0962ff0e54eec801a")
