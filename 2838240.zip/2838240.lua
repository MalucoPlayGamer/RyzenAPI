-- Lua provided by RyzenAPI
-- Game: addappid(2838240)

-- MAIN APPLICATION
addappid(2838240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838240,0,"920f7cef68343dae5ee7c45df6fc630b15294fb126668411cdf770d4a195c262")
