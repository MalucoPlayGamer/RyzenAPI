-- Lua provided by RyzenAPI
-- Game: 1786260

-- MAIN APPLICATION
addappid(1786260)
-- Game: addappid(1786260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786261, 1, "ea2f19db30af1bfb5ab74a6b0e9d9142be91013c4d98bebdc99a52239d3ed6f1")
