-- Lua provided by RyzenAPI
-- Game: Game: Sonic Colors: Ultimate

-- MAIN APPLICATION
addappid(2055290)
-- Game: addappid(2055290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055291, 1, "35b064414a398875b2ba3c0482f2a5916ea85dd34c317a67157a42a8a6090b51")
