-- Lua provided by RyzenAPI
-- Game: Succubus Melnea

-- MAIN APPLICATION
addappid(1934360)
addappid(2305690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934361, 1, "e8d1b548d48eb3defe3b34987ae5562ce32583c3d40a05e1e2811fe5f6c21ada")

