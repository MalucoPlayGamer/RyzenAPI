-- Lua provided by RyzenAPI
-- Game: addappid(2339650)

-- MAIN APPLICATION
addappid(2339650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339651, 1, "b2b175209a113786a26fcc70ef9692a2a715da13fdebcf13cd2b0b820a282f4c")
