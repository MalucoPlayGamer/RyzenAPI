-- Lua provided by RyzenAPI
-- Game: Game: Them and Us - Soo Yun

-- MAIN APPLICATION
addappid(3438980)
-- Game: addappid(3438980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438981, 1, "d5abe8082cf3536010c7b0a86166d263179b91c142f6737e1792e5c7449276c7")
