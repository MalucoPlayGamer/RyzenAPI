-- Lua provided by RyzenAPI
-- Game: 恐龙岛

-- MAIN APPLICATION
addappid(3139890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3139891, 1, "0d6a1dd1b167221ae493fcfd7d637899ead4a54a8381f2603ba1c21c870541f4")

