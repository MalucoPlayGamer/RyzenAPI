-- Lua provided by RyzenAPI
-- Game: ItsJustAStory

-- MAIN APPLICATION
addappid(2435060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435061, 1, "386727befb27aeedebc43d221606614ad14410539d0471e2a8366318c0a94dcf")
