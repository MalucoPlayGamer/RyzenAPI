-- Lua provided by RyzenAPI 
-- Game: AppID 2435060
addappid(2435060)
addappid(2435061, 1, "386727befb27aeedebc43d221606614ad14410539d0471e2a8366318c0a94dcf")
