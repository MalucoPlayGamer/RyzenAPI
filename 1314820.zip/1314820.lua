-- Lua provided by RyzenAPI
-- Game: 1314820

-- MAIN APPLICATION
addappid(1314820)
-- Game: addappid(1314820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314821, 1, "1187d54a7b9a8e29f42660f278dbcad2b958292903ae0c0a09cadf75a4cac7bf")
addappid(1314822, 1, "95088eddabb262c23c3f6c6ce78108bef9bc6cb1520b0c520a403a09d66ab767")
