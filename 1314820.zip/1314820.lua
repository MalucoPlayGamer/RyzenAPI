-- Lua provided by RyzenAPI
-- Game: AppID 1314820

-- MAIN APPLICATION
addappid(1314820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314821, 1, "1187d54a7b9a8e29f42660f278dbcad2b958292903ae0c0a09cadf75a4cac7bf")
addappid(1314822, 1, "95088eddabb262c23c3f6c6ce78108bef9bc6cb1520b0c520a403a09d66ab767")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
