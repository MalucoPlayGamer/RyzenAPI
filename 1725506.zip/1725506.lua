-- Lua provided by RyzenAPI
-- Game: Beat Saber: Skrillex – 'Scary Monsters and Nice Sprites'

-- MAIN APPLICATION
addappid(1725506)
-- Game: addappid(1725506)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725506,0,"f22662cb36c4d7b5a37f2d76f54acf47eb5c4dd8a8d7e11e8a9f43c9d3d5f0ce")
