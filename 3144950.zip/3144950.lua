-- Lua provided by RyzenAPI
-- Game: Pet Lands

-- MAIN APPLICATION
addappid(3144950)
-- Game: addappid(3144950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144951, 1, "fdadcdb4423eb2a2d8c114de8f8238a47f3209ee475b32bde7517af2546984ea")
