-- Lua provided by RyzenAPI
-- Game: Pet Lands

-- MAIN APPLICATION
addappid(3144950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144951, 1, "fdadcdb4423eb2a2d8c114de8f8238a47f3209ee475b32bde7517af2546984ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
