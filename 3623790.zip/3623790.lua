-- Lua provided by RyzenAPI
-- Game: Dreamrealms Resurgence

-- MAIN APPLICATION
addappid(3623790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3623791, 1, "3368f9771f460ddf4594ed47bdd750509e5a0c2885162f2806a9313f363991bf")

