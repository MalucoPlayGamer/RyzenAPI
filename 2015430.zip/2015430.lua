-- Lua provided by RyzenAPI
-- Game: Jigoku Unko: Toripuru

-- MAIN APPLICATION
addappid(2015430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015431, 1, "ea96d2a8598563ced85fd035dd1ef9b7dd466f90b970204cf515efcad19748c3")
