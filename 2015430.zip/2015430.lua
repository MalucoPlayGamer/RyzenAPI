-- Lua provided by RyzenAPI
-- Game: Jigoku Unko: Toripuru

-- MAIN APPLICATION
addappid(2015430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015431, 1, "ea96d2a8598563ced85fd035dd1ef9b7dd466f90b970204cf515efcad19748c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
