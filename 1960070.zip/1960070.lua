-- Lua provided by RyzenAPI
-- Game: RIN: The Last Child

-- MAIN APPLICATION
addappid(1960070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960071, 1, "8c531f878e1591280b6e0a6edf437e0a4981e6048e601af47fdbdc5fa50badc5")

