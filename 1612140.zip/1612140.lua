-- Lua provided by SkyAPI 
-- Game: Мухосранск | Russian City Sim
addappid(1612140)
addappid(1612141, 1, "c0352fa5344c068fa97bb5bfa820e6cdda3bd8167e13f5975c8bdd0ad45fc4ae")
