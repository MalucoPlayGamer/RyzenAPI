-- Lua provided by RyzenAPI
-- Game: Мухосранск | Russian City Sim

-- MAIN APPLICATION
addappid(1612140)
-- Game: addappid(1612140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612141, 1, "c0352fa5344c068fa97bb5bfa820e6cdda3bd8167e13f5975c8bdd0ad45fc4ae")
