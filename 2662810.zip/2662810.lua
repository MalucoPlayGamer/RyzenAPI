-- Lua provided by RyzenAPI
-- Game: Dungeon Minesweeper

-- MAIN APPLICATION
addappid(2662810)
-- Game: addappid(2662810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662811, 1, "9cdc359a400a7a8dc27b6eae7729564099487dcdd3a292eebac6707df541bf3b")
