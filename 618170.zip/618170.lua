-- Lua provided by RyzenAPI
-- Game: Game: AppID 618170

-- MAIN APPLICATION
addappid(618170)
-- Game: addappid(618170)

-- MAIN APP DEPOTS / PACKAGES
addappid(618171, 1, "9a2805a73ff957da49665cb5f7b8b521a5e0509950aa993f60443eddc3cc0ba4")
addappid(618172, 1, "45316b63a61c7eb739e1c1b1ed9fad503ede6b76b222e52ae1a4d01367144b68")
addappid(618173, 1, "1259b7e59955caea71e31147a42a7edae05e2d04eb3225fa819dab864b28d228")
