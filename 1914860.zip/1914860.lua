-- Lua provided by RyzenAPI
-- Game: Overbowed Demo

-- MAIN APPLICATION
addappid(1914860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914861, 1, "6be903d3c5fe8f81505fd2a6fdcdd80c94929ab9e5d51c690b58c75e2f5cbe60")
