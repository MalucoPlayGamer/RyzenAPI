-- Lua provided by RyzenAPI
-- Game: Global Protocol: New World Order

-- MAIN APPLICATION
addappid(4500270)

-- MAIN APP DEPOTS / PACKAGES
addappid(4500271,0,"148968212a4e649e57378b52f756649c02ebdae667f9bfe24391c683a6c8098c")

