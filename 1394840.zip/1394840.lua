-- Lua provided by RyzenAPI
-- Game: Ice Cream Truck Demo

-- MAIN APPLICATION
addappid(1394840)
-- Game: addappid(1394840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394841, 1, "29079a14cc99e2c3d5518431254dcf423f513c6c53c7f3eff404a6aae34a5786")
