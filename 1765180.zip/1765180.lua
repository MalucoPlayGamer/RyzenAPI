-- Lua provided by RyzenAPI
-- Game: Shunga Frame

-- MAIN APPLICATION
addappid(1765180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765181, 1, "a70eb67a1c6594359d794fce1de7eebc9357fca1e49fa3f020925683bc5d4320")

