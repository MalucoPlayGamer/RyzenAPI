-- Lua provided by RyzenAPI
-- Game: AppID 2844920

-- MAIN APPLICATION
addappid(2844920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844921, 1, "bf2b154bd9cbc35915b1ab301bf5751731b87a3da6f69a055b36c8d6fe5dc7e6")
