-- Lua provided by RyzenAPI
-- Game: 798840

-- MAIN APPLICATION
addappid(798840)
-- Game: addappid(798840)

-- MAIN APP DEPOTS / PACKAGES
addappid(798841, 1, "b76b149da694cf2ce80690e30879f3eeb86839127d379a035a7bfeac8fc3bc87")
