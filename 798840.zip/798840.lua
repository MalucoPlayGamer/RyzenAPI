-- Lua provided by RyzenAPI
-- Game: Panzer War: Definitive Edition

-- MAIN APPLICATION
addappid(798840)

-- MAIN APP DEPOTS / PACKAGES
addappid(798840,0,"cbeb0611bd2afc590f8e06791c7a52c570b71ea85d05306337eb28451615b3ff")
addappid(798841,0,"b76b149da694cf2ce80690e30879f3eeb86839127d379a035a7bfeac8fc3bc87")
addappid(798842,0,"93b94c8e57323e45a9d1a4da0f1f948463b7c853336f0bb812455479ab031a7a")
addappid(1019010,0,"028184b23abeefba817fc00511303f0bf14688df05a8eb25ac850f2f798f7ff3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
