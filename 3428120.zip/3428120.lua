-- Lua provided by RyzenAPI
-- Game: addappid(3428120)

-- MAIN APPLICATION
addappid(3428120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428121, 1, "68574c2be9ebe8ffc2d39fb96947f0e13a8549c33f73f97ba5f65424e9208c9e")
