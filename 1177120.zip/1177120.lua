-- Lua provided by RyzenAPI
-- Game: Game: AppID 1177120

-- MAIN APPLICATION
addappid(1177120)
-- Game: addappid(1177120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177121, 1, "72afc03a1574800c9bfb3a3aa094172f5d85aa234be044f5b1d8f9527ea932ca")
addappid(1177122, 1, "8ba35482798168615395a872004793ae9dbc49dfc7643fbf9e14c10fbc078af6")
