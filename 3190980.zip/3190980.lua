-- Lua provided by RyzenAPI
-- Game: 3190980

-- MAIN APPLICATION
addappid(3190980)
-- Game: addappid(3190980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3190981, 1, "79fd247371c1344289aad350206a0eb03908b04c3db9def610af297babe74d4f")
