-- Lua provided by RyzenAPI
-- Game: Lord of the click

-- MAIN APPLICATION
addappid(1044170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044171, 1, "955e48c3529ff4cb047f63d549307aa3a4dc41ea3eb5effbe8261a3344e31664")

