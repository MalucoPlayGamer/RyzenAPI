-- Lua provided by RyzenAPI
-- Game: Unknown Pharaoh

-- MAIN APPLICATION
addappid(576100)
-- Game: addappid(576100)

-- MAIN APP DEPOTS / PACKAGES
addappid(576101, 1, "c51fe2692d52518d537471f412e31a387c66a76f337d3472b60d4061262af97c")
