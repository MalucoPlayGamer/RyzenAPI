-- Lua provided by RyzenAPI
-- Game: Fast and Low

-- MAIN APPLICATION
addappid(1097620)
addappid(4513870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097621, 1, "6100da7a3d68eac914d9479b7a776d917e688cc1414b490021096bc2a1bb64cb")

