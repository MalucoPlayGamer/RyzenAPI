-- Lua provided by RyzenAPI
-- Game: addappid(1424670)

-- MAIN APPLICATION
addappid(1424670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424671, 1, "2dc40d3b1110457d9ac2169018eaee8ebc193d25c4ce9d2069e8e5b54af8fd2d")
