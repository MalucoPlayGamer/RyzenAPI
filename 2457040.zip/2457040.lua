-- Lua provided by SkyAPI 
-- Game: Thyria: Step Into Dreams
addappid(2457040)
addappid(2457041, 1, "4e7cd9c008a2eb634e0d18519f755e46a4626bdb0f9e74a2dc6c75cb542fa1ae")
addappid(2457042, 1, "7b24cb1789889a79aba18c400d159339842d90b0f4cbb0867fb6be62796745d5")
addappid(2457043, 1, "50a981a60b1d7dfba8dba1b028c69fe440cd873fc9b3d7cf82414bec28602eb4")
