-- Lua provided by RyzenAPI
-- Game: Game: The Dead Cloud Forest

-- MAIN APPLICATION
addappid(765630)
-- Game: addappid(765630)

-- MAIN APP DEPOTS / PACKAGES
addappid(765631, 1, "9c68bf29ccc032d0641c4223de67e8cf8422e93350e3430e3daee29aed1585df")
