-- Lua provided by RyzenAPI
-- Game: Moorhuhn: Tiger and Chicken

-- MAIN APPLICATION
addappid(321940)

-- MAIN APP DEPOTS / PACKAGES
addappid(321941, 1, "f5372197722c9922598cf309941b7f5e10ac23c26a057395b48d78d724e0d1d4")
addappid(321942, 1, "892978f2b99794452c529a23541db60c660a37e304dd3ef7204b68c602fea825")
addappid(321943, 1, "75a09d1450f630c9de747a6eea5246091886de6987a6bddcd292f700b03e1438")
addappid(321944, 1, "2d28f9fdb6f8ed6b1618aeabaa29e4e4d8e9735b91536e11a887ca90ae4f9225")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
