-- Lua provided by RyzenAPI
-- Game: addappid(1803190)

-- MAIN APPLICATION
addappid(1803190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803191, 1, "f7af4abad5bf9f99b5e337bdddb509acfb51c67f38382f5bb2dd93446c3b8eb4")
