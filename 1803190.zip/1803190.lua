-- Lua provided by RyzenAPI
-- Game: SimRail - The Railway Simulator: Prologue

-- MAIN APPLICATION
addappid(1803190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1803191, 1, "f7af4abad5bf9f99b5e337bdddb509acfb51c67f38382f5bb2dd93446c3b8eb4")

