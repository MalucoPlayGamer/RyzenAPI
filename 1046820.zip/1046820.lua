-- Lua provided by RyzenAPI
-- Game: I'm on Observation Duty

-- MAIN APPLICATION
addappid(1046820)
-- Game: addappid(1046820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046821, 1, "6bb56e4bf27dc7489280e84f72104014a04fe77d0cfe74f682d5479eedc13813")
addappid(1046822, 1, "b9942d5978857a9a96b647a3644c38ad0688b617e54b2824262462aac88cbc44")
addappid(1046823, 1, "f9e8259e7fd7e1817fe579805797766e9a13f7c7dbf21dddd1b68a60e66ab8ad")
