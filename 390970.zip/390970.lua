-- Lua provided by RyzenAPI
-- Game: Russian Horror Story

-- MAIN APPLICATION
addappid(390970)

-- MAIN APP DEPOTS / PACKAGES
addappid(390971, 1, "5a5f238410d4b652ae675a41158da130dac6b0f0055edb9178068bac2fbb534f")

