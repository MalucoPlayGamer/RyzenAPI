-- Lua provided by RyzenAPI
-- Game: The Seven Deadly Sins: Origin

-- MAIN APPLICATION
addappid(3679080)

