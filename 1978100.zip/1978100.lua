-- Lua provided by SkyAPI 
-- Game: Grand Prix Story
addappid(1978100)
addappid(1978101, 1, "1c0987a7ec731e924a8e37da591536169bd7656ad14d571a27a3a42dbdb4c43c")
