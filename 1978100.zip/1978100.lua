-- Lua provided by RyzenAPI
-- Game: Grand Prix Story

-- MAIN APPLICATION
addappid(1978100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978101, 1, "1c0987a7ec731e924a8e37da591536169bd7656ad14d571a27a3a42dbdb4c43c")
