-- Lua provided by RyzenAPI
-- Game: VRidge - GameWarp unlock

-- MAIN APPLICATION
addappid(2677770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677772,0,"17c6aac88d841231e529c5f7bc5885899e656250e5ce8e0229cc406f3a0425e7")

