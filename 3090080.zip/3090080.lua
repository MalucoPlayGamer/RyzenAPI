-- Lua provided by RyzenAPI
-- Game: Killed by Love 99 Times

-- MAIN APPLICATION
addappid(3090080)
-- Game: addappid(3090080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090081, 1, "adcba58ecfd597611114c32dc3b3bc16220ca21ad91d1e39086760ec809eb433")
addappid(3090082, 1, "b24027a72013c63c904c6f1bb5ba9665ef670dc78cd9b83d45e78ee575caac17")
