-- Lua provided by RyzenAPI
-- Game: addappid(623050)

-- MAIN APPLICATION
addappid(623050)

-- MAIN APP DEPOTS / PACKAGES
addappid(623052,0,"11f3bdcf781cad220b79b131664b8575b99f4cfd5cd84023fd2005753d86a30a")
