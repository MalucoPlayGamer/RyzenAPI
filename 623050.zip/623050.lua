-- Lua provided by RyzenAPI
-- Game: CyberClub-2077

-- MAIN APPLICATION
addappid(623050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(623052,0,"11f3bdcf781cad220b79b131664b8575b99f4cfd5cd84023fd2005753d86a30a")

