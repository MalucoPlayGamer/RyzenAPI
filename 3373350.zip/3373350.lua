-- Lua provided by RyzenAPI
-- Game: Echoes of the Plum Grove - The Art of Echoes of the Plum Grove

-- MAIN APPLICATION
addappid(3373350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3373351, 1, "eac3a236eb7b7b8a6b5ccc84d8b290c39edfaaf15f7f329b326fc650c6f911d6")
