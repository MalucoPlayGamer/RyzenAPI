-- Lua provided by RyzenAPI
-- Game: Children of Liberty

-- MAIN APPLICATION
addappid(264440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(264441, 1, "fa33334c3cf2836a858abaea390c8cc8bbd15f1b491d352172d0f657ac7d0ed6")
addappid(264442, 1, "430871811db7e165d8cd0830f34b07dd55b2fa1eaac981f7fff600ddf1943979")
addappid(264443, 1, "9bd6c193102f20a4d5e6c29051aa6f316876ba7c855caa2cb622f8e131322c40")
