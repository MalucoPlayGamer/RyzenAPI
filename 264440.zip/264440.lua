-- Lua provided by RyzenAPI
-- Game: 264440

-- MAIN APPLICATION
addappid(264440)
-- Game: addappid(264440)

-- MAIN APP DEPOTS / PACKAGES
addappid(264441, 1, "fa33334c3cf2836a858abaea390c8cc8bbd15f1b491d352172d0f657ac7d0ed6")
addappid(264442, 1, "430871811db7e165d8cd0830f34b07dd55b2fa1eaac981f7fff600ddf1943979")
addappid(264443, 1, "9bd6c193102f20a4d5e6c29051aa6f316876ba7c855caa2cb622f8e131322c40")
