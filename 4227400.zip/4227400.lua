-- Generated with Luie @ https://lua.tools/
-- 4227400 - Sineus Arena Survivors
-- Generated 2026-08-08 18:07:44 UTC
-- # Depots (Total/DLC/Shared): 3/2/0

-- Main AppID
addappid(4227400)

-- Main Depots
addappid(4227401, 1, "19a03039b1de96dcdacce6757c31e17384dc5cecf6006b3bbc35e43a82d25d24")
setManifestid(4227401, "5900720439029410025", 1246882064)

-- DLC's (no depot keys required)
addappid(4877370) -- Sineus Arena Survivors: Dark Triumph Skin Pack

-- Missing Depots (We don't have the keys yet lol): 4877342, 4877343
