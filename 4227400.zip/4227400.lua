-- Lua provided by RyzenAPI
-- Game: Sineus Arena Survivors

-- MAIN APPLICATION
addappid(4227400)
addappid(4227400) -- Sineus Arena Survivors

-- MAIN APP DEPOTS / PACKAGES
addappid(4227401, 1, "19a03039b1de96dcdacce6757c31e17384dc5cecf6006b3bbc35e43a82d25d24") -- Depot 4227401

