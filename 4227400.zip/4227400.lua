-- 4227400's Lua and Manifest Created by Hubcap Manifest
-- Sineus Arena Survivors
-- Created: June 22, 2026 at 21:29:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4227400) -- Sineus Arena Survivors
-- MAIN APP DEPOTS
addappid(4227401, 1, "19a03039b1de96dcdacce6757c31e17384dc5cecf6006b3bbc35e43a82d25d24") -- Depot 4227401
-- setManifestid(4227401, "4995489785281355602", 1400257687)