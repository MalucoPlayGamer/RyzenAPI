-- Lua provided by RyzenAPI
-- Game: Game: AppID 472420

-- MAIN APPLICATION
addappid(472420)
-- Game: addappid(472420)

-- MAIN APP DEPOTS / PACKAGES
addappid(472421, 1, "c07cd609b86b462439ae677ea460bc7c0ea5cb2d0ce964991867f5defa5194a5")
addappid(472422, 1, "95c66f04ff1bd90503f7d1d33403ccf1bf55156cd1c60e9056c369de40703ce8")
addappid(472423, 1, "00a2c52bd76e3527e84d98c37c56b0d8b9bfb978e444dabf7c24f3942e4e7d56")
addappid(472424, 1, "d252198a57f125568ab0665ffb25319407f261f88cecba62ed0ec65fa03b624b")
addappid(472425, 1, "8b6cc7affd03f337456e4fbc1fc1cafa24b521f4dcfdf617eb7d617348d9e009")
