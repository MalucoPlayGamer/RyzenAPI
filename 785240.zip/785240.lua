-- Lua provided by RyzenAPI
-- Game: 785240

-- MAIN APPLICATION
addappid(785240)
-- Game: addappid(785240)

-- MAIN APP DEPOTS / PACKAGES
addappid(785241, 1, "d4c8bac4f69bb07c37f0159831a0cec2794184daa7a83bb380ec5774910c38f2")
