-- Lua provided by RyzenAPI
-- Game: Zoochosis

-- MAIN APPLICATION
addappid(2458560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458561, 1, "d0ea71d310e5aea1e7a51ffc602de7221b630660cdcf955af6d5558221804634")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
