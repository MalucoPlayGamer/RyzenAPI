-- Lua provided by RyzenAPI
-- Game: 2458560

-- MAIN APPLICATION
addappid(2458560)
-- Game: addappid(2458560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458561, 1, "d0ea71d310e5aea1e7a51ffc602de7221b630660cdcf955af6d5558221804634")
