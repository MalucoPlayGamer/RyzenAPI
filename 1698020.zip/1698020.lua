-- Lua provided by RyzenAPI
-- Game: Reflection

-- MAIN APPLICATION
addappid(1698020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698021, 1, "2af20a714d5a0c99998f5ad493d001a20bdbacbe39fa15ba1883d6661665c75c")

