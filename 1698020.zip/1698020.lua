-- Lua provided by SkyAPI 
-- Game: Reflection
addappid(1698020)
addappid(1698021, 1, "2af20a714d5a0c99998f5ad493d001a20bdbacbe39fa15ba1883d6661665c75c")
