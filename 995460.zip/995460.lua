-- Lua provided by RyzenAPI
-- Game: Miracle Snack Shop

-- MAIN APPLICATION
addappid(995460)

-- MAIN APP DEPOTS / PACKAGES
addappid(995461, 1, "8d022531f3f5b671d1dde868fce3fedc144e9693f91ef7b8f3bd5d036f21aaa7")
addappid(1022120, 0, "3eb4a1a3f17e9848f947c50a5658b5503669d06677f5cd8be549d21bf39f7b69")
addappid(1055880, 0, "0fe2f2c09c3ecdca9593e174822b7b8fe7e821a4d1b9133aa061dccece2e48c9")
