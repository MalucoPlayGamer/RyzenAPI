-- Lua provided by RyzenAPI
-- Game: 2376686

-- MAIN APPLICATION
addappid(2376686)
-- Game: addappid(2376686)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376686,0,"5966b1059b51f7a0848e75844f5bf15635d7add8d093eeb9f8a8c1e10c2a1465")
