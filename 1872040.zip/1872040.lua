-- Lua provided by RyzenAPI
-- Game: 1872040

-- MAIN APPLICATION
addappid(1872040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872044,0,"59c55db6df4787f953fcfbd6fab3aa2ab60be6d8aeeb59b98062929abe5933b8")
