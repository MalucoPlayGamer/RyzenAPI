-- Lua provided by RyzenAPI
-- Game: addappid(1174690)

-- MAIN APPLICATION
addappid(1174690)
addappid(1274460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174691, 1, "748d5f93fffe0d6a43062a97575802a3bdbd5a3476e063d0d912f1d9705360e5")
