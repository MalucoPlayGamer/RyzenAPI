-- Lua provided by RyzenAPI
-- Game: Game: Exoborne Playtest

-- MAIN APPLICATION
addappid(3362820)
-- Game: addappid(3362820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362821, 1, "dc885a72e8f229f40f48cdf59759b4e024e009f0f414dd14ece8701b7f57670e")
