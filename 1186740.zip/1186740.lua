-- Lua provided by RyzenAPI
-- Game: Kyle is Famous: Complete Edition

-- MAIN APPLICATION
addappid(1186740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186741, 1, "637ed21832e943d4938d51c69f42bea191cabce5c304267f7c9d24aae59ac8b9")

