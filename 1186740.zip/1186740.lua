-- Lua provided by RyzenAPI
-- Game: Kyle is Famous

-- MAIN APPLICATION
addappid(1186740)
addappid(1206940)
addappid(1263080)
addappid(1779250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186740,0,"c6e10cf252b3a2980d8be0756879ed3051cdaf84d3d2a2bf78edb7d5cbf85c9c")
addappid(1186741,0,"637ed21832e943d4938d51c69f42bea191cabce5c304267f7c9d24aae59ac8b9")
addappid(1186742,0,"fb6c9cdf2f17549bcef8b86b56645f380c9b86ffcdadc62d258945f43cc4e638")
addappid(1186743,0,"01d9c20c003c31de8820b6688b2c44b98e3e4b1f3e3e0a2d21edb1d96140273c")
addappid(1186744,0,"9a26c3c763fd1c207a2862bc9beb0acef766a2284f23cf81b1247d1d732d8c84")

