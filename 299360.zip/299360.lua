-- Lua provided by RyzenAPI
-- Game: Block N Load

-- MAIN APPLICATION
addappid(299360)

-- MAIN APP DEPOTS / PACKAGES
addappid(299361, 1, "394576267284389eaf3010f5050ccb267801e7e4e4e175d4bdf48a73673671d5")
addappid(299362, 1, "bdd44fb2ae37ad961973e02021b411573bf47ccacba194be305de1c7ca69b555")
addappid(299363, 1, "dfd58b920b8e60bca241633b7a0cb898b94a0a70418d52ab9b9a459bf21ab2fc")
addappid(299366, 1, "edb0f6717ed56b01529eace2f688cae844990e04810e97772467147175055105")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(335250)
addappid(367890)
addappid(400840)
addappid(400841)
addappid(400842)
addappid(401610)
