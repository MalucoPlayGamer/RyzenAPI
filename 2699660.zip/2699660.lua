-- Lua provided by RyzenAPI
-- Game: Game: PowerWash Adventure

-- MAIN APPLICATION
addappid(2699660)
addappid(2737890)
-- Game: addappid(2699660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699661, 1, "09a590e041aad9ba10e1c32aaf05985553752dbd2bcf8d117327d77a5edb9dcf")
