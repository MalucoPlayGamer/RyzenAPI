-- Lua provided by RyzenAPI
-- Game: Game: EARTH DEFENSE FORCE 6

-- MAIN APPLICATION
addappid(2291060)
-- Game: addappid(2291060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291061, 1, "ef65bad7cbcbeb5d90b878628c65692b54fd08921c88e56631d6057a5bc570aa")
addappid(2291062, 1, "01f24cef1191cc9cc16474edca81396ce9ef8f77333fa533cb326d556a4f10c4")
