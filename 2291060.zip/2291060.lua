-- Lua provided by RyzenAPI
-- Game: EARTH DEFENSE FORCE 6

-- MAIN APPLICATION
addappid(2291060)
addappid(2378070)
addappid(2378071)
addappid(2378072)
addappid(2378073)
addappid(2378074)
addappid(2378075)
addappid(2378076)
addappid(2378077)
addappid(2378078)
addappid(2378079)
addappid(2378080)
addappid(2378081)
addappid(2378082)
addappid(2378083)
addappid(2378084)
addappid(2378085)
addappid(2378086)
addappid(2378087)
addappid(2378088)
addappid(2793640)
addappid(2793650)
addappid(2793660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2291061, 1, "ef65bad7cbcbeb5d90b878628c65692b54fd08921c88e56631d6057a5bc570aa")
addappid(2291062, 1, "01f24cef1191cc9cc16474edca81396ce9ef8f77333fa533cb326d556a4f10c4")

