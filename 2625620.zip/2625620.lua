-- Lua provided by SkyAPI 
-- Game: AppID 2625620
addappid(2625620)
addappid(2625621, 1, "673442d6524278a802390329ad435ba6afa7f5e354c8ee77c28b84f95f0e5b08")
