-- Lua provided by RyzenAPI
-- Game: Dealer Simulator

-- MAIN APPLICATION
addappid(2625620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625621, 1, "673442d6524278a802390329ad435ba6afa7f5e354c8ee77c28b84f95f0e5b08")
