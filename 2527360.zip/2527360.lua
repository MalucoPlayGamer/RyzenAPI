-- Lua provided by RyzenAPI
-- Game: 2527360

-- MAIN APPLICATION
addappid(2527360)
-- Game: addappid(2527360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527361, 1, "19bd878fdd926da5c4f346e2fbdba6111fb90a305eb8f9db72a2b0f1e63ea155")
