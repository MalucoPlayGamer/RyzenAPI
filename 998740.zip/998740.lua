-- Lua provided by RyzenAPI
-- Game: 998740

-- MAIN APPLICATION
addappid(998740)
-- Game: addappid(998740)

-- MAIN APP DEPOTS / PACKAGES
addappid(998741, 1, "3d93e1b7aa260a0821a5fe689926f87387ed2742e5dfa4ad7a6fc01b52019a9b")
addappid(998742, 1, "68cea13c1d7d0c4b3c6e4287d2e6dd1aa65195e242a7e4eb2ebc2a8c494894ac")
