-- Lua provided by RyzenAPI
-- Game: Frequent Flyer

-- MAIN APPLICATION
addappid(229000)
addappid(554150)

-- MAIN APP DEPOTS / PACKAGES
addappid(554152,0,"633383c64735fdb9f43f139145b6e48081e277104a50eeeec819651fd23249a4")
addappid(554153,0,"22fa1fb4d84ad81a25bda9a836bd18c8c85199523d444d50ae8ae28b41f6dc11")
addappid(554154,0,"16ee6eecce7b50ab88ed44c00cd1036ba5ba12c6ffddb6c7cfe6f114791d3cf7")

