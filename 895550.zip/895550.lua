-- Lua provided by RyzenAPI
-- Game: Total 15

-- MAIN APPLICATION
addappid(895550)
addappid(897870)

-- MAIN APP DEPOTS / PACKAGES
addappid(895551, 1, "3f2f3d7f95e4a4158447c83e662c01b661257d672f80ef373f99dff6e69d46bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
