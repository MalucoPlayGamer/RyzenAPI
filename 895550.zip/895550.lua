-- Lua provided by RyzenAPI
-- Game: 895550

-- MAIN APPLICATION
addappid(895550)
addappid(897870)
-- Game: addappid(895550)

-- MAIN APP DEPOTS / PACKAGES
addappid(895551, 1, "3f2f3d7f95e4a4158447c83e662c01b661257d672f80ef373f99dff6e69d46bf")
