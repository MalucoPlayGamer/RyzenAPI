-- Lua provided by RyzenAPI
-- Game: Dominated by: Yandere Goth Idol Sister

-- MAIN APPLICATION
addappid(3845590)
-- Game: addappid(3845590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3845591, 1, "db678d8fd3c8169d50f63b6e33e4efe4d9d921ded3e76be8e93208d93fc0127f")
