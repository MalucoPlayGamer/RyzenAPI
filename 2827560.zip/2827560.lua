-- Lua provided by RyzenAPI
-- Game: 100 Romantic Cats

-- MAIN APPLICATION
addappid(2827560)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3512330)
addappid(3512340)
