-- Lua provided by RyzenAPI
-- Game: 100 Romantic Cats

-- MAIN APPLICATION
addappid(2827560)

