-- Lua provided by SkyAPI 
-- Game: All-Time Battle
addappid(1427640)
addappid(1427641, 1, "708213369f47a4d951ab198e07158c662dc2e237361ce04f32210169669d7636")
