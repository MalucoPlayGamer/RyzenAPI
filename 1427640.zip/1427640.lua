-- Lua provided by RyzenAPI
-- Game: Game: All-Time Battle

-- MAIN APPLICATION
addappid(1427640)
-- Game: addappid(1427640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427641, 1, "708213369f47a4d951ab198e07158c662dc2e237361ce04f32210169669d7636")
