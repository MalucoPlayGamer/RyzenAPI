-- Lua provided by RyzenAPI
-- Game: addappid(1191330)

-- MAIN APPLICATION
addappid(1191330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191331, 1, "0e91dd0a12107a16724a0f96316dc113d01df4ec15cde5873049f4c0297fcd54")
