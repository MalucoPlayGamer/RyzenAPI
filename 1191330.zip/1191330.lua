-- Lua provided by RyzenAPI 
-- Game: Inferna
addappid(1191330)
addappid(1191331, 1, "0e91dd0a12107a16724a0f96316dc113d01df4ec15cde5873049f4c0297fcd54")
