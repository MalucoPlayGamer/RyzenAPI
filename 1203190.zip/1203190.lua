-- Lua provided by RyzenAPI
-- Game: AppID 1203190

-- MAIN APPLICATION
addappid(1203190)
-- Game: addappid(1203190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203191, 1, "46aa2b5ac9dd960c2fb3808c8033df048fede7062052f754db267609ecbef621")
