-- Lua provided by RyzenAPI
-- Game: Game: HueBots

-- MAIN APPLICATION
addappid(397400)
-- Game: addappid(397400)

-- MAIN APP DEPOTS / PACKAGES
addappid(397401, 1, "d444546e753babc62a2e1bac05997686c7a087f5b0a41392236998c441a0c2ab")
addappid(397402, 1, "e2a84f9fea3d0a45f6c20793e09e8da4237c55cfc12af4069de008d8fb0c7b95")
addappid(397403, 1, "6bb6dbe4f21f28116a496fd64bec89df3dccb03c6d3e5bcc10e0544a2ca91ce8")
addappid(397404, 1, "7d10e6f8113479763427910f26ffb206b9d41a8e52e4983f542480c348a239d0")
