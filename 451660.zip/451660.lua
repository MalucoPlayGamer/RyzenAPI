-- Lua provided by RyzenAPI 
-- Game: Trucker
addappid(451660)
addappid(451661, 1, "397699784e036575647a73c6eef7114b24b74274d1fcec253ca277e31b05c789")
