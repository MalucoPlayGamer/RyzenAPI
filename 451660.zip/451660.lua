-- Lua provided by RyzenAPI
-- Game: Trucker

-- MAIN APPLICATION
addappid(451660)
-- Game: addappid(451660)

-- MAIN APP DEPOTS / PACKAGES
addappid(451661, 1, "397699784e036575647a73c6eef7114b24b74274d1fcec253ca277e31b05c789")
