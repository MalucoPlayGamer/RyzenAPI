-- Lua provided by RyzenAPI
-- Game: Game: Primordialis

-- MAIN APPLICATION
addappid(3011360)
-- Game: addappid(3011360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011361, 1, "cc38851f59c1e27c4374122e71df3502f280875cc1c89272e9c846373c8265fb")
