-- Lua provided by RyzenAPI
-- Game: Game: Rudra: A Tale of Time

-- MAIN APPLICATION
addappid(2316820)
-- Game: addappid(2316820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316821, 1, "816affa60a22d394a2f0f21419fbad277e843119f7560b387a9c25597e0318db")
