-- Lua provided by SkyAPI 
-- Game: Foxhole
addappid(505460)
addappid(505461, 1, "bb4f2b312b248a9d82f22ce92055a5df6819410a63a872976e5541e2a22a4434")
addappid(4217460)
