-- Lua provided by RyzenAPI
-- Game: Foxhole

-- MAIN APPLICATION
addappid(505460)
addappid(4217460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(505461, 1, "bb4f2b312b248a9d82f22ce92055a5df6819410a63a872976e5541e2a22a4434")

