-- Lua provided by RyzenAPI
-- Game: Game: AppID 1333940

-- MAIN APPLICATION
addappid(1333940)
-- Game: addappid(1333940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333941, 1, "337de3deb21911ef8670cb134f12237281f736d1fe196f5b25c6f1dbca7c957b")
