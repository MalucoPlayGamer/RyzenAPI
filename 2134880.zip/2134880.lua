-- Lua provided by RyzenAPI
-- Game: Game: AppID 2134880

-- MAIN APPLICATION
addappid(2134880)
-- Game: addappid(2134880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134881, 1, "625b0a15cba60bacfd9dae1986fe73b9861fc4e85bc8a56a55e8158de8ac9043")
