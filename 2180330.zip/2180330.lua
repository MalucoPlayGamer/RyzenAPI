-- Lua provided by RyzenAPI
-- Game: addappid(2180330)

-- MAIN APPLICATION
addappid(2180330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180331, 1, "529644d914a79c35e87b3c13ae1ac503ab66eb0cd662cb2648e7e28831c88d7a")
