-- Lua provided by RyzenAPI
-- Game: Shardlight

-- MAIN APPLICATION
addappid(336130)

-- MAIN APP DEPOTS / PACKAGES
addappid(336131, 1, "fb318a3837fd589643057a0b91e6932df74037f9ea4e0ac0e99aa33608e1f8d1")
addappid(336132, 1, "ccd6002e77a1c7ee2c6ce2be9f8cfbfdce3c4e7cb0f62ac0e021b4c761e8685c")
addappid(336133, 1, "5d6613f04c184f56516c316fb98b72570f3b139c62bc53b736a82bd2b62b2d72")
addappid(336134, 1, "fa03cf55df353647c0bb85ffb6cdd45253b526bc148ff54e06ba2ac31aaad3c2")
addappid(447870, 0, "fbf7bc183072212be848e637802a0ebf76d552133a20a8a598f175c87ff79725")

