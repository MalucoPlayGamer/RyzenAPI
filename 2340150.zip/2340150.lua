-- Lua provided by RyzenAPI
-- Game: Wojak wants Hentai

-- MAIN APPLICATION
addappid(2340150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340151, 1, "7a4893691ec9a778e8d69ae91a75730ea3410730e9fd7b87ac854e16946e6160")
