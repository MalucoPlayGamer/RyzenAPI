-- Lua provided by RyzenAPI
-- Game: Wojak wants Hentai

-- MAIN APPLICATION
addappid(2340150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340151, 1, "7a4893691ec9a778e8d69ae91a75730ea3410730e9fd7b87ac854e16946e6160")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
