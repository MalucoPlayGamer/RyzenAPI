-- Lua provided by RyzenAPI
-- Game: addappid(744750)

-- MAIN APPLICATION
addappid(744750)

-- MAIN APP DEPOTS / PACKAGES
addappid(744751, 1, "4b740b8304d3754f6ba142e3d4e8063f26e9fb39d0086e138030e65ea9ef3396")
