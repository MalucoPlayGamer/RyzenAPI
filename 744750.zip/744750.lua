-- Lua provided by RyzenAPI
-- Game: AppID 744750

-- MAIN APPLICATION
addappid(744750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(744751, 1, "4b740b8304d3754f6ba142e3d4e8063f26e9fb39d0086e138030e65ea9ef3396")

