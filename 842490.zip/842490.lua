-- Lua provided by RyzenAPI
-- Game: BOXiGON!

-- MAIN APPLICATION
addappid(842490)
-- Game: addappid(842490)

-- MAIN APP DEPOTS / PACKAGES
addappid(842491, 1, "918a2e49295149c5d0a174351850bb8eca5c320ff93a5c54c2b0a24bfa1a0cc5")
