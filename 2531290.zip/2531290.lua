-- Lua provided by RyzenAPI
-- Game: VTOL VR: EF-24 Mischief - Electronic Warfare

-- MAIN APPLICATION
addappid(2531290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531290,0,"d5fd310d63d0468ce9b645c74008874bedc3c31bc1e6d1d774b896306c6d10e8")

