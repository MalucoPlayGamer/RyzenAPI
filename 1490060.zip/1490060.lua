-- Lua provided by RyzenAPI
-- Game: Game: Disillusion

-- MAIN APPLICATION
addappid(1490060)
-- Game: addappid(1490060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490061, 1, "0c790ee53fc6ff2598ec1cc3b8dc029f0313a5ac921f4847020833add49e8596")
