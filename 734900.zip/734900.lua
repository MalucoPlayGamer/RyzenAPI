-- Lua provided by SkyAPI 
-- Game: Chemically Bonded
addappid(734900)
addappid(734901, 1, "58f648be4e1bf91eb9e78e1cdc1ba6674497fa8f7ba5786ff790b471b84294a8")
