-- Lua provided by RyzenAPI
-- Game: Chemically Bonded

-- MAIN APPLICATION
addappid(734900)

-- MAIN APP DEPOTS / PACKAGES
addappid(734901, 1, "58f648be4e1bf91eb9e78e1cdc1ba6674497fa8f7ba5786ff790b471b84294a8")
