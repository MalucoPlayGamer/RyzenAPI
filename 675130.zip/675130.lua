-- Lua provided by RyzenAPI
-- Game: AEGYPTUS

-- MAIN APPLICATION
addappid(675130)

-- MAIN APP DEPOTS / PACKAGES
addappid(675131, 1, "e456029379780d925c4efb50b5a5a7c953740f58ac04a631e0068087f106701b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
