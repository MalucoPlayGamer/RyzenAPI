-- Lua provided by RyzenAPI
-- Game: Soul Axiom Rebooted

-- MAIN APPLICATION
addappid(1206620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206621, 1, "fc5e6ae5957e99eb27fda99a57c9ec9403b8c5abd52d62a28c29344d839dad41")
addappid(1206622, 1, "b817d02f27358b3af510608e7220ff991844f8e5aa4608a8d4764b24c4875246")
addappid(1206623, 1, "4d055beb8bc7e6053c3562707c7fe93c87a2fe4f425572d1fbe5d1898cc241c5")
addappid(1206624, 1, "38918ca8cde9b13cb3a23e57f1c3ff0505b73dc3ecbe452451fad40dced4fab3")

