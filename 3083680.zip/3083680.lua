-- Lua provided by RyzenAPI
-- Game: Manny's 2 Demo

-- MAIN APPLICATION
addappid(3083680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3083681, 1, "73cd5edb48b94737b11bf820f855ad0cc48dd73d27a28cec89206e3cf8345b8b")
