-- Lua provided by RyzenAPI
-- Game: Game: Starchaser: Priestess of the Night Sky

-- MAIN APPLICATION
addappid(365850)
-- Game: addappid(365850)

-- MAIN APP DEPOTS / PACKAGES
addappid(365851, 1, "bc010393b72f5209c0f7b971694d1c385e30b986336525f4993a4cc3fd21c973")
