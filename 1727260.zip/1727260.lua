-- Lua provided by RyzenAPI
-- Game: Puzzle Fever

-- MAIN APPLICATION
addappid(1727260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727261, 1, "31a39a3fbe658211162785bb3ada4bd331433f4eaed8a7dfedf60c1b22673e53")

