-- Lua provided by RyzenAPI
-- Game: addappid(1412510)

-- MAIN APPLICATION
addappid(1412510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412511, 1, "eb583b11cb7a9de3bf59d206aac2f6ee28cf34ad1a095d640d010bc5ccfd48d3")
