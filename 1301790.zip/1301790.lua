-- Lua provided by RyzenAPI
-- Game: Minute of Islands Demo

-- MAIN APPLICATION
addappid(1301790)
-- Game: addappid(1301790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301791, 1, "b47e08018b9344759b96fbbac1465fa993651b0dee51c70ec75d361710ab38f8")
