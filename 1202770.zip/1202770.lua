-- Lua provided by RyzenAPI
-- Game: kirakira stars idol project AI

-- MAIN APPLICATION
addappid(1202770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202771, 1, "9734ff3ef6977eb156fd3020fc7d8274c397018093819b9bf4cf191ad1a24234")

