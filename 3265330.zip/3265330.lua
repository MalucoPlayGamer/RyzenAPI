-- Lua provided by RyzenAPI
-- Game: Game: Tsunagari Chess School

-- MAIN APPLICATION
addappid(3265330)
-- Game: addappid(3265330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265331, 1, "06c2c7ddf6fac6c5c8a3235af85a92878902911a28b76ef116c40869847a8c19")
