-- Lua provided by RyzenAPI
-- Game: 2096470

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2096470)
-- Game: addappid(2096470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096472,0,"65cd864ec2c0c916e47d3f679ed59164314f2a975b77ed0e4c12b434075d7c29")
