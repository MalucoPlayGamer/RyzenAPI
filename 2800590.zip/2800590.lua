-- Lua provided by RyzenAPI
-- Game: addappid(2800590)

-- MAIN APPLICATION
addappid(2800590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800592,0,"bffb1a708f8b142781bf8344425fdb2668707d2831405be9acc3f451e2f96bdc")
