-- Lua provided by RyzenAPI
-- Game: addappid(3738660)

-- MAIN APPLICATION
addappid(3738660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3738661, 1, "b8353b93c0b66c1907b1d39dcfd4a741c0bc0b96295281bc896e7a485cfb1bc0")
