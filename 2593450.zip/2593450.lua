-- Lua provided by SkyAPI 
-- Game: AppID 2593450
addappid(2593450)
addappid(2593451, 1, "b72668e0eaf69804000c2d16f332ba66544d2e14847669a5afd29dd43267db8e")
