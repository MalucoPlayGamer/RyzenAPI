-- Lua provided by RyzenAPI
-- Game: Sushi Rush

-- MAIN APPLICATION
addappid(1990710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990711, 1, "16efefe449c5327e8a69ebe8e82d355a73dd5502bf9f196d5067bb944dd7faf1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2167720)
addappid(2167721)
addappid(2167722)
addappid(2167723)
addappid(2167724)
addappid(2167725)
addappid(2167726)
addappid(2167727)
addappid(2167728)
addappid(2167729)
addappid(2167730)
addappid(2167731)
addappid(2167732)
addappid(2167733)
addappid(2167734)
addappid(2167735)
addappid(2167736)
addappid(2167737)
addappid(2167738)
addappid(2167739)
addappid(2167740)
addappid(2167741)
addappid(2167742)
addappid(2167743)
addappid(2167744)
