-- Lua provided by RyzenAPI
-- Game: Sushi Rush

-- MAIN APPLICATION
addappid(1990710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990711, 1, "16efefe449c5327e8a69ebe8e82d355a73dd5502bf9f196d5067bb944dd7faf1")

