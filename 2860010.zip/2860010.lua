-- Lua provided by RyzenAPI
-- Game: addappid(2860010)

-- MAIN APPLICATION
addappid(2860010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2860011, 1, "ed79acb965c2c07030b10c9195db5fa04aa543459a87af2687a7355f1a2733ec")
