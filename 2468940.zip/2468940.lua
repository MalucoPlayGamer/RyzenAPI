-- Lua provided by RyzenAPI
-- Game: Game: Medved Hellraiser 2

-- MAIN APPLICATION
addappid(2468940)
-- Game: addappid(2468940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468941, 1, "4d751769358335a2907ffc3b4a161867a68e56092c0aff0b660ef8b889b4ecca")
