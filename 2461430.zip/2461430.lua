-- Lua provided by RyzenAPI
-- Game: The Assistant Season 1

-- MAIN APPLICATION
addappid(2461430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461433,0,"81c307687a8ce34dfaba630de7889122016d253be24d16e7912bfc31073c258c")

