-- Lua provided by RyzenAPI
-- Game: AppID 2167510

-- MAIN APPLICATION
addappid(2167510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167511, 1, "0eb957c09cc555ebac4ef58a89b63e993b9f260b64fc4da5fffad66e54125d43")

