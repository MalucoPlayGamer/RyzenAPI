-- Lua provided by RyzenAPI
-- Game: Fiz and the Rainbow Planet

-- MAIN APPLICATION
addappid(2299930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299931, 1, "bdb2b65bf30233f9cdeb7f3393c7caf8b21095dbc54e0b929e06ba09ffbda492")

