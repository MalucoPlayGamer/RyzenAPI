-- Lua provided by RyzenAPI
-- Game: AppID 530320

-- MAIN APPLICATION
addappid(530320)
addappid(949640)
addappid(949641)
addappid(949642)
-- Game: addappid(530320)

-- MAIN APP DEPOTS / PACKAGES
addappid(530321, 1, "2fcc2f98b1e63cc18c8a21e44f65c511682944cb56a98c34c7f1f26c46ce73c2")
addappid(530322, 1, "5b48c09e4efa2e960bfe989fe695c88da2300a441e5680a52f0b96194e3f6595")
