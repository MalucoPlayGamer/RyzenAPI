-- Lua provided by RyzenAPI
-- Game: Lightmatter

-- MAIN APPLICATION
addappid(994140)

-- MAIN APP DEPOTS / PACKAGES
addappid(994141, 1, "ea16096ea3a0f5e3aa7874463acb942869bba945d40c618db444df081c864393")
