-- Lua provided by RyzenAPI
-- Game: Lightmatter

-- MAIN APPLICATION
addappid(994140)
addappid(1179290)

-- MAIN APP DEPOTS / PACKAGES
addappid(994141,0,"ea16096ea3a0f5e3aa7874463acb942869bba945d40c618db444df081c864393")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
