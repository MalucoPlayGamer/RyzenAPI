-- Lua provided by RyzenAPI
-- Game: ALPEN GHOUL: Prologue

-- MAIN APPLICATION
addappid(2336600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336601, 1, "987b50d7f022641db3dbaad2b567f0d1acca6d3f6d1aedd295acc15c832d6a05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
