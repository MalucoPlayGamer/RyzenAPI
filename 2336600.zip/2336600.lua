-- Lua provided by RyzenAPI
-- Game: Game: ALPEN GHOUL: Prologue

-- MAIN APPLICATION
addappid(2336600)
-- Game: addappid(2336600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336601, 1, "987b50d7f022641db3dbaad2b567f0d1acca6d3f6d1aedd295acc15c832d6a05")
