-- Lua provided by RyzenAPI
-- Game: Sudocats

-- MAIN APPLICATION
addappid(1725640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725642,0,"537ac520a4697350d930ee58abe69f32b0c9e28410b174847399d663ec3309fb")
addappid(1725643,0,"fd252ffd56267531d3c42541c1e54c58760a9d0b061f22d6daf6494e5cfa138e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1923540)
