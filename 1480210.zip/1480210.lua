-- Lua provided by SkyAPI 
-- Game: The Garden of Orilon
addappid(1480210)
addappid(1480211, 1, "c3af97bd3e7724c6b1350158b459225a1439ac3a02cd3b58224ece2c50b02c77")
