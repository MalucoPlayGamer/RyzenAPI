-- Lua provided by RyzenAPI
-- Game: Sheryl ~The Alchemist of the Island Ruins~

-- MAIN APPLICATION
addappid(2787300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787301, 1, "29c6114e3ed35fa456162ea80b511747aa931c5765380669d9ed43b893694057")
addappid(2787302, 1, "9a0257c651ab8dbf2f8d57701a42e1680c778daf29a1acd8d44a5301e0e5e743")
addappid(2787303, 1, "c64f19aeb54d7daabdd7506008a7254f803c7fa9f54b78f28aaf046a73b58a6f")

