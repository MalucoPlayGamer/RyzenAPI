-- Lua provided by RyzenAPI
-- Game: Game: AppID 996250

-- MAIN APPLICATION
addappid(996250)
-- Game: addappid(996250)

-- MAIN APP DEPOTS / PACKAGES
addappid(996251, 1, "eeaefe8082a85c0d5badd9995be62681fcee2d7b72b197226d03009c1745fb0d")
addappid(996252, 1, "b8e7a864433521d50f3b5228ba16279a5e43369fdbe4b6bbed554fcfa1b12cc8")
