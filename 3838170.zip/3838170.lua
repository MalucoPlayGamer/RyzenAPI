-- Lua provided by RyzenAPI
-- Game: addappid(3838170)

-- MAIN APPLICATION
addappid(3838170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3838173,0,"cf0e0ee9464496b260158aeb73aafcb581355d341c54dea61c754676c1a3ac7c")
