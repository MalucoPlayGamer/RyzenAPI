-- Lua provided by RyzenAPI
-- Game: Verdun

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(242860)

-- MAIN APP DEPOTS / PACKAGES
addappid(242862,0,"32493f099e4630cef4e58c575e9302d1b4a7244b95daaf6071c2374e90f1252d")
addappid(242863,0,"6d09b107eff398052d8fa3d8eab0a49589f76b365235bc8d1dddb13e1824176a")
addappid(242864,0,"79aaf5a49662def1bd78635305a019574a88a36b73848bf24a1006660af3d11b")
addappid(242865,0,"2433b5b1705fea4c3b2ae8da1a58d02e96ee4c1139a99ade8abaa208548919a4")
addappid(242869,0,"1a65b012a3ca4c6942ef5002edd237efba12dc92e94c92d6156065388bd34274")
addappid(987070,0,"6a0fbf9ab1b574a31dc0ce5fa29c80486a7fefbf931545a375d550a0a3729e7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(439480)
addappid(763450)
