-- Lua provided by RyzenAPI
-- Game: Game: AppID 1202200

-- MAIN APPLICATION
addappid(1202200)
-- Game: addappid(1202200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202201, 1, "c64a197ca6dffdd997a3a8120f31ff6f6e2eadb82b35d468f0d2004336811c57")
addappid(1202203, 1, "2862f273c179e48a93d61f7f405e56079293c0b88e5e9b7e9f2fab1bbcc64a04")
