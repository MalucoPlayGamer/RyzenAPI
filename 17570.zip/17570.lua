-- Lua provided by RyzenAPI
-- Game: Pirates Vikings & Knights II

-- MAIN APPLICATION
addappid(17570)

-- MAIN APP DEPOTS / PACKAGES
addappid(17571, 1, "4a1c581b77b373a666d449bae6e72f01b1868352c5ceb2d606c5e88e1e3d2d86")
addappid(17572, 1, "9c0577379b199785fa69ef129b5a6a7e69142863171ee8009faa73148cb53777")
addappid(17573, 1, "a3a1bb8d1b13a3b386caca0798afab668b15dea59982132bd674d31212228692")
addappid(17574, 1, "9db5b4f397b7d0b2cf811b1a2e81923f147227388de5635c08eb4cccc03a7e27")
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
