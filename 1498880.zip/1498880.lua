-- Lua provided by RyzenAPI
-- Game: addappid(1498880)

-- MAIN APPLICATION
addappid(1498880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498881, 1, "b460512c361a94e29a743c2a95d5b5bcc43e564303d0d39a5a2feb1597e136b5")
