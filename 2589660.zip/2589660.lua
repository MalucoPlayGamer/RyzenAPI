-- Lua provided by RyzenAPI
-- Game: Mayfly Demo

-- MAIN APPLICATION
addappid(2589660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589661, 1, "369684c9f78c9e8145140849e0edb2cd87f9080a982cc13ae1e7562d6c4a6315")

