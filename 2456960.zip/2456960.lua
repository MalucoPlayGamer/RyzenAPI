-- Lua provided by RyzenAPI
-- Game: The 7th Guest VR

-- MAIN APPLICATION
addappid(2456960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456961, 1, "093f0e7ce52e048725039916f8eb51194851a69c4e688f21b88cd1ccfdb31443")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
