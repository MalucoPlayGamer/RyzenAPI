-- Lua provided by RyzenAPI
-- Game: The 7th Guest VR

-- MAIN APPLICATION
addappid(2456960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456961, 1, "093f0e7ce52e048725039916f8eb51194851a69c4e688f21b88cd1ccfdb31443")

