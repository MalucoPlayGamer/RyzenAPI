-- Lua provided by RyzenAPI
-- Game: Chair Simulator

-- MAIN APPLICATION
addappid(1610870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610872,0,"1ec3ba398d65fa8cf99bf5e10370cbb17a0b025e647c4a33cc43a67888724412")
addappid(1610873,0,"b8e39905086327aa4648795057cce7d0dc83cc89b2ece1c67fabe4d56d3c2d72")

