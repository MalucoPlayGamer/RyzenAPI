-- Lua provided by RyzenAPI
-- Game: 3203370

-- MAIN APPLICATION
addappid(3203370)
-- Game: addappid(3203370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3203373,0,"5b0a637543b83268c24a4c0b612ea57ca39e1da3ed4e29e7f139f330da94cf17")
