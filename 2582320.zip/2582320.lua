-- Lua provided by RyzenAPI 
-- Game: Mixtape
addappid(2582320)
addappid(2582321, 1, "bf956320114c20821c9daa9195bbe47763d47fd8755086843025b3354e081337")
