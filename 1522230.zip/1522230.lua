-- Lua provided by RyzenAPI
-- Game: Wild West Crops

-- MAIN APPLICATION
addappid(1522230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522231, 1, "6e2002246d63e9acce81384e3074e03a772f7c71d665f59aa05ea6470d560a84")

