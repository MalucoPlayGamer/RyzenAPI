-- Lua provided by RyzenAPI
-- Game: Going Dark Demo

-- MAIN APPLICATION
addappid(3110170)
-- Game: addappid(3110170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3110171, 1, "762b3af286a57686caf51277f68b7efdf3338297beb8da43c62744320ca84cd4")
