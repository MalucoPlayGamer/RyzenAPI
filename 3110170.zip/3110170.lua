-- Lua provided by RyzenAPI 
-- Game: Going Dark Demo
addappid(3110170)
addappid(3110171, 1, "762b3af286a57686caf51277f68b7efdf3338297beb8da43c62744320ca84cd4")
