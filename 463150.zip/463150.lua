-- Lua provided by RyzenAPI
-- Game: BARRIER X

-- MAIN APPLICATION
addappid(463150)

-- MAIN APP DEPOTS / PACKAGES
addappid(463151, 1, "edfe111fd30fc68ba756820d4ddc6049be6133e8b3c57ccf0f8369e63d53d368")
