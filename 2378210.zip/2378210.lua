-- Lua provided by RyzenAPI
-- Game: 2378210

-- MAIN APPLICATION
addappid(2378210)
-- Game: addappid(2378210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378211, 1, "7a8117f4e0e377c96e59de42bf9e736fa9390c85c9511f50cdff55b436a8c50b")
