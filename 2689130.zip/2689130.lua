-- Lua provided by RyzenAPI
-- Game: CipherCraft: Cyber Guardian Introduction

-- MAIN APPLICATION
addappid(2689130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689131, 1, "e5ea246d8d81795a84df591e67e2fdced5a3d0f143d74659f9c391a363e2d140")
