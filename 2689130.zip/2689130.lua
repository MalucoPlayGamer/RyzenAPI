-- Lua provided by RyzenAPI
-- Game: CipherCraft: Cyber Guardian Introduction

-- MAIN APPLICATION
addappid(2689130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689131, 1, "e5ea246d8d81795a84df591e67e2fdced5a3d0f143d74659f9c391a363e2d140")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
