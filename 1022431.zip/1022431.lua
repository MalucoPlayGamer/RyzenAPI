-- Lua provided by RyzenAPI
-- Game: DFF NT: Armaments IV, Noctis Lucis Caelum's 4th Weapon Set

-- MAIN APPLICATION
addappid(1022431)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022431,0,"6a98f023178d022ac1ecef6e2fb0fed22961831f081582a7921283286359528a")

