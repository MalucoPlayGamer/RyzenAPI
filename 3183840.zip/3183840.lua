-- Lua provided by RyzenAPI
-- Game: Ticker

-- MAIN APPLICATION
addappid(3183840)
-- Game: addappid(3183840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183841, 1, "d7b503985500980b9312a438b204de9574c6ee2d276194a1b15951c99a0ed101")
