-- Lua provided by RyzenAPI
-- Game: The one who pulls out the sword will be crowned king

-- MAIN APPLICATION
addappid(1865370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865371, 1, "d800069a6ca70837a1f5532a8059703b1b970bb4d8c41998b2fdb1ea2c818ac6")
addappid(1865372, 1, "96df74c6284eb09a25342dd3c0e43af918df5a83694d79a7787cea7256d51b36")
addappid(1865373, 1, "8908837b43e4ff84d3b58e3be2c07d52a694fc39c8ba5c380e3822fb42e62910")
addappid(1865374, 1, "3045c314f0ef12524b589191125db082426a3910e98c7c25df16f8e003ea4c7b")
addappid(1865375, 1, "197768e04aa6694b1c74cf959f1c15d33494482726b55ebc58edbc18dff3ec3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
