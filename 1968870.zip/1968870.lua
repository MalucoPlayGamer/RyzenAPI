-- Lua provided by RyzenAPI
-- Game: 1968870

-- MAIN APPLICATION
addappid(1968870)
-- Game: addappid(1968870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968871, 1, "5ae12d6517feee81bcada845c4bfaccdc2fb50575bb6e56c9ba381fe36cb2c28")
