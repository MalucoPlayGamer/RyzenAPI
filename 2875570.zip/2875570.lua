-- Lua provided by RyzenAPI
-- Game: 2875570

-- MAIN APPLICATION
addappid(2875570)
-- Game: addappid(2875570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875571, 1, "1cef1c7f3528c418aec901284957e7ea262f53bf96c2ff727b90726c5cf55fb7")
