-- Lua provided by RyzenAPI
-- Game: Warlocks Deeds

-- MAIN APPLICATION
addappid(2479780)
addappid(2536190)
addappid(2723410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(2479781, 1, "72503a0289589b510cf6a22fee7ea77c30747e7ee1e52da87372daef70bb96c2")

