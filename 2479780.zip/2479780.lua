-- Lua provided by RyzenAPI
-- Game: Game: Warlocks Deeds

-- MAIN APPLICATION
addappid(2479780)
-- Game: addappid(2479780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479781, 1, "72503a0289589b510cf6a22fee7ea77c30747e7ee1e52da87372daef70bb96c2")
