-- Lua provided by RyzenAPI
-- Game: Sonar Shock

-- MAIN APPLICATION
addappid(2673660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673661, 1, "e25800f9ddda9528a5a5aadda04f850aea218c0a5d8289db5bad011cc93a4969")
