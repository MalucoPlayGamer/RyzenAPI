-- Lua provided by RyzenAPI
-- Game: AppID 2941310

-- MAIN APPLICATION
addappid(2941310)
-- Game: addappid(2941310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941311, 1, "3b85abdf0c3d6bbb8b56c22beafd63bddc38a875be9204734de7a1fa25e62755")
