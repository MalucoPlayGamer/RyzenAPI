-- Lua provided by RyzenAPI
-- Game: EDENS ZERO

-- MAIN APPLICATION
addappid(3125750)
-- Game: addappid(3125750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125751, 1, "8e98d35380e0ac080fbc6342eca2d99a14165fb1f54e883ecf81a691c99c1ecf")
