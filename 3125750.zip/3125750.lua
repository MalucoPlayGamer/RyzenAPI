-- Lua provided by RyzenAPI
-- Game: EDENS ZERO

-- MAIN APPLICATION
addappid(3125750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125751, 1, "8e98d35380e0ac080fbc6342eca2d99a14165fb1f54e883ecf81a691c99c1ecf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3273490)
addappid(3345380)
addappid(3345400)
addappid(3345410)
addappid(3345420)
