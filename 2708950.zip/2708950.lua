-- Lua provided by RyzenAPI
-- Game: Game: Corruption Town

-- MAIN APPLICATION
addappid(2708950)
-- Game: addappid(2708950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708951, 1, "6c6256dc770672ddf4140c20c4641576e8eb467bb291b04045a6967d8a9745b4")
