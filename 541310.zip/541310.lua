-- Lua provided by RyzenAPI
-- Game: 541310

-- MAIN APPLICATION
addappid(541310)
-- Game: addappid(541310)

-- MAIN APP DEPOTS / PACKAGES
addappid(541312,0,"908ab9daccfd27a8287e038ddb8128630d20b38eb14c479f9ea901d2904beb65")
