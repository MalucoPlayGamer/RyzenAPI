-- Lua provided by RyzenAPI
-- Game: Tuttle: Star Flower Harvest

-- MAIN APPLICATION
addappid(2371400)
-- Game: addappid(2371400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371401, 1, "53de1299495ce00dbc1538a6b56bfc104940202a69823c3d103e3e71494e72f3")
