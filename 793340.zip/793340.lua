-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(793340)
-- Game: addappid(793340)

-- MAIN APP DEPOTS / PACKAGES
addappid(793340,0,"bd06bb1698afa2af01978471b55053f3d92f35b4656938851d9ffb37668ae31b")
