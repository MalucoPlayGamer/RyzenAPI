-- Lua provided by RyzenAPI
-- Game: 3335600

-- MAIN APPLICATION
addappid(3335600)
-- Game: addappid(3335600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3335601, 1, "055c4c11e19644df769ecb6e9b3baee5b7d4fd6cfba1f6e49dff362c90c871b9")
