-- Lua provided by RyzenAPI
-- Game: Hentai Cho

-- MAIN APPLICATION
addappid(3329130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3329131, 1, "25e44db0b239c9bbccc6cb2054d82733b9d635386203c2740958ca01e084c825")

