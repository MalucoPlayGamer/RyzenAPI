-- Lua provided by RyzenAPI
-- Game: Cupid Bistro 2

-- MAIN APPLICATION
addappid(769680)

-- MAIN APP DEPOTS / PACKAGES
addappid(769681, 1, "7402038cc8df5b7fce59baa0bf9a53c66f75b3115dfa479aeab8f7538462ffde")
