-- Lua provided by RyzenAPI
-- Game: Jagged Alliance 3

-- MAIN APPLICATION
addappid(1084160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1084161, 1, "4f94d949152ea26f9a3c60c1a8dd75fc4ac15d586bc1fc97ce67745a3be5faee")
addappid(1084162, 1, "1c73c3e64d01f3e0dd21767f188b872224a190a6a9c295bd430b8fbcbe8771cc")

