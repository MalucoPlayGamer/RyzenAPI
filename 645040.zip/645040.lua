-- Lua provided by RyzenAPI
-- Game: Dark Train: Soundtrack

-- MAIN APPLICATION
addappid(645040)

-- MAIN APP DEPOTS / PACKAGES
addappid(645041, 1, "0c182e4b1dfe7226726be34e6ddaf7d04321aab84949d86d2588598231b8f04c")

