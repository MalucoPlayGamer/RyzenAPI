-- Lua provided by RyzenAPI
-- Game: Mecha Knights: Nightmare

-- MAIN APPLICATION
addappid(1163870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163872,0,"7359302c516854ebf5e76fb9fcfa5abae1195cbe92a7111243958f4f88ce5727")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2500350)
addappid(2995910)
