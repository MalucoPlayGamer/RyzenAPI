-- Lua provided by RyzenAPI
-- Game: 1545430

-- MAIN APPLICATION
addappid(1545430)
addappid(2291470)
-- Game: addappid(1545430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545431, 1, "7fb7db8bc3593b7f307ccb55be26a8e994de629d5f6352e1de830bf582c012ea")
