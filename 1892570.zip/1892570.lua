-- Lua provided by RyzenAPI
-- Game: Colored Effects

-- MAIN APPLICATION
addappid(1892570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892571, 1, "3b6363a78cc5ec266d26ee2ccbe09b528c51e57eeebe52a0beeb7513d74b3ac9")

