-- Lua provided by SkyAPI 
-- Game: Colored Effects
addappid(1892570)
addappid(1892571, 1, "3b6363a78cc5ec266d26ee2ccbe09b528c51e57eeebe52a0beeb7513d74b3ac9")
