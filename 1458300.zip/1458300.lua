-- Lua provided by RyzenAPI
-- Game: The Gap

-- MAIN APPLICATION
addappid(1458300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458301, 1, "b9b0464ccaf56518a3d1dcc20795d7b087e0e74ce00d259e23b2132fc2640e20")

