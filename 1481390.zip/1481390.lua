-- Lua provided by RyzenAPI
-- Game: Per Aspera Audio Drama

-- MAIN APPLICATION
addappid(1481390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481391, 1, "d2f367ed075d863b7ebc5f835c06c8aea63d275304149fc972774983227d3108")
