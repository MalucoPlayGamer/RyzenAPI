-- Lua provided by RyzenAPI
-- Game: Trireme Commander

-- MAIN APPLICATION
addappid(766460)

-- MAIN APP DEPOTS / PACKAGES
addappid(766461,0,"327035bbae09254ea23652130880a398aa119c679d296c3e313f72ad4d33ed82")

