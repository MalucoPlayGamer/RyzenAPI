-- Lua provided by RyzenAPI
-- Game: Trireme Commander

-- MAIN APPLICATION
addappid(766460)

-- MAIN APP DEPOTS / PACKAGES
addappid(766461,0,"327035bbae09254ea23652130880a398aa119c679d296c3e313f72ad4d33ed82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
