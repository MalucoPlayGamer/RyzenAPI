-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2651000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651000,0,"c9664423dcad5407f849b5b9bf9b580dc639bc7e8afb7945c9e047f63028e9d0")

