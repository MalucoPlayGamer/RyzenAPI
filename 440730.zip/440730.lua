-- Lua provided by RyzenAPI
-- Game: Survival Zombies The Inverted Evolution

-- MAIN APPLICATION
addappid(440730)

-- MAIN APP DEPOTS / PACKAGES
addappid(440731, 1, "67285746d060d595742412d83c164ee83a61099a3b35ad3222381fbd17eff116")
addappid(440732, 1, "939bad7969e670292e673a935f70ff489eb5e13bcfbbf2ceec74cb1ad6a27bb5")
addappid(440733, 1, "0d236bb5c5082dab50d39abd8d6fa5c9e2d2e5e3737d767c31b956a623896183")
addappid(440734, 1, "11f8c1b0fea71647ff99a665dd167ff24ef3e2a3c2e95eb5c3b1315f2b5ce133")
