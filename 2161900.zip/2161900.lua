-- Lua provided by RyzenAPI
-- Game: 2161900

-- MAIN APPLICATION
addappid(2161900)
-- Game: addappid(2161900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161901, 1, "74cec4f05ff79d5a3a7a0bdbaf3a985439813bd57c6b8722cb833c0345e48c63")
