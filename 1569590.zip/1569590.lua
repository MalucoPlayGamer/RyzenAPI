-- Lua provided by RyzenAPI
-- Game: OnlyFuck - RuRu's Adventures

-- MAIN APPLICATION
addappid(1569590)
addappid(1665100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569591, 1, "8adcaa1363a964a85d1846a2ca15c7ce9a469aff61de0cab529374981243db2e")
