-- Lua provided by RyzenAPI
-- Game: Game: AppID 57710

-- MAIN APPLICATION
addappid(57710)
-- Game: addappid(57710)

-- MAIN APP DEPOTS / PACKAGES
addappid(57711, 1, "a5a49915695fea06659fa08a88072515a2e52e8c6c4f8c23d4a601e63dd8eaa0")
