-- Lua provided by RyzenAPI
-- Game: addappid(684420)

-- MAIN APPLICATION
addappid(684420)

-- MAIN APP DEPOTS / PACKAGES
addappid(684421, 1, "9ddd0d1a901e13ffa4dab400fae31922af98c6f67a8519f747c3e2dac9287722")
