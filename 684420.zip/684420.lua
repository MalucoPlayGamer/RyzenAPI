-- Lua provided by SkyAPI 
-- Game: Steampunk Syndicate 2
addappid(684420)
addappid(684421, 1, "9ddd0d1a901e13ffa4dab400fae31922af98c6f67a8519f747c3e2dac9287722")
