-- Lua provided by RyzenAPI
-- Game: Steampunk Syndicate 2

-- MAIN APPLICATION
addappid(684420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(684421, 1, "9ddd0d1a901e13ffa4dab400fae31922af98c6f67a8519f747c3e2dac9287722")

