-- Lua provided by RyzenAPI
-- Game: 2312500

-- MAIN APPLICATION
addappid(2312500)
-- Game: addappid(2312500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312501, 1, "6b77e9de390f309ed02accce02af0e766f53a9a6592ed797144a3336553246c2")
