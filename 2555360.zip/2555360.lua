-- Lua provided by RyzenAPI
-- Game: Immortals of Aveum™ Demo

-- MAIN APPLICATION
addappid(2555360)
-- Game: addappid(2555360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555361, 1, "68c4433d09b8b1e7064458172ca73c18174f53e560e5027f2aad0b4d1b0f8cb0")
