-- Lua provided by RyzenAPI
-- Game: Fireboy & Watergirl 2: The Light Temple

-- MAIN APPLICATION
addappid(5085370) -- Fireboy & Watergirl 2: The Light Temple

-- MAIN APP DEPOTS / PACKAGES
addappid(5085371, 1, "e9d1ec25d683ed62f5c520d7830a61b1aabfdaef4a75a379178d4f37e0324d0c") -- Depot 5085371
