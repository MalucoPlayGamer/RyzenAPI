-- Lua provided by RyzenAPI
-- Game: 357120

-- MAIN APPLICATION
addappid(357120)
-- Game: addappid(357120)

-- MAIN APP DEPOTS / PACKAGES
addappid(357121, 1, "37194f448fdd11d9d3e4c966b59edf508b165620cfbf3047312bd719c6c10223")
addappid(357122, 1, "e35d7a43182e0d848aece20af448583b899f7057fc9aba1a394eb35e360d3db9")
