-- Lua provided by RyzenAPI
-- Game: Million Star Ship

-- MAIN APPLICATION
addappid(2911460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911461, 1, "44ad39cf19d553a589b592f20745396c62279a3cb16e659ae5cf8823be5a3fe8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
