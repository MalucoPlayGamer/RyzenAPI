-- Lua provided by SkyAPI 
-- Game: Million Star Ship
addappid(2911460)
addappid(2911461, 1, "44ad39cf19d553a589b592f20745396c62279a3cb16e659ae5cf8823be5a3fe8")
