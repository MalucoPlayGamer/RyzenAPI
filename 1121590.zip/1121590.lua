-- Lua provided by RyzenAPI
-- Game: AppID 1121590

-- MAIN APPLICATION
addappid(1121590)
-- Game: addappid(1121590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121591, 1, "dadfab103c1d558bae91a654ba90f85660585881bf5e7975d6d4ade01df458ac")
