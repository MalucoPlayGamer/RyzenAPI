-- Lua provided by RyzenAPI
-- Game: addappid(1044480)

-- MAIN APPLICATION
addappid(1044480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044481, 1, "eb5400ca87459cd40a4d1dcd44c72e34e357970566b38466edbb9d7a60950d23")
