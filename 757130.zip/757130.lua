-- Lua provided by RyzenAPI
-- Game: Paintball War

-- MAIN APPLICATION
addappid(757130)
-- Game: addappid(757130)

-- MAIN APP DEPOTS / PACKAGES
addappid(757131, 1, "1dfc6b675d4365a4fd634b550e797ee3cb25c3d7ffb91272e223522f28ad5566")
