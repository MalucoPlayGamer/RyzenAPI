-- Lua provided by SkyAPI 
-- Game: Paintball War
addappid(757130)
addappid(757131, 1, "1dfc6b675d4365a4fd634b550e797ee3cb25c3d7ffb91272e223522f28ad5566")
