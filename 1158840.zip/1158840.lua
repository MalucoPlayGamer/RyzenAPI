-- Lua provided by RyzenAPI
-- Game: addappid(1158840)

-- MAIN APPLICATION
addappid(1158840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158841, 1, "c7d8e74d051f28fb4ed1d124438fa953739a6c71fb77d21adfbdaad76e105f28")
