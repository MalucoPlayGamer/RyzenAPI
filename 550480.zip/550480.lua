-- Lua provided by RyzenAPI
-- Game: AppID 550480

-- MAIN APPLICATION
addappid(550480)
-- Game: addappid(550480)

-- MAIN APP DEPOTS / PACKAGES
addappid(550481, 1, "6e1429ff0ec13df88901a032bc151577cb9076a98cbaa06fe60d402e1e108439")
