-- Lua provided by RyzenAPI 
-- Game: Garden Rescue: Christmas Edition
addappid(418160)
addappid(418161, 1, "3ee1a22b422b5d0b86d8e25a7a201acc084171691bebc06b0646a54ffa26150f")
