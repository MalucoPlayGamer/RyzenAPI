-- Lua provided by RyzenAPI
-- Game: 2183910

-- MAIN APPLICATION
addappid(2183910)
-- Game: addappid(2183910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183911, 1, "75baf4526800f78d4b95ce1f3a417ad92dff9e1733325ef56bba08edc15de4f9")
