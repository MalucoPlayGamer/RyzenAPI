-- Lua provided by SkyAPI 
-- Game: AppID 1155680
addappid(1155680)
addappid(1155681, 1, "b1ca79fda755786d531e187a0315746ee633b4e4a83ec1689d7ea7174097029a")
