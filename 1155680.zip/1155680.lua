-- Lua provided by RyzenAPI
-- Game: Game: AppID 1155680

-- MAIN APPLICATION
addappid(1155680)
-- Game: addappid(1155680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155681, 1, "b1ca79fda755786d531e187a0315746ee633b4e4a83ec1689d7ea7174097029a")
