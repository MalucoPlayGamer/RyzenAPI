-- Lua provided by RyzenAPI
-- Game: Goblintown: Really Hard Driving Game

-- MAIN APPLICATION
addappid(3417510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3417511, 1, "82923f6d966077a0b27b51b4bda1c169308085be88b1278d62a3557b657432dc")

