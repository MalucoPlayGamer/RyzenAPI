-- Lua provided by RyzenAPI
-- Game: Goblintown: Really Hard Driving Game

-- MAIN APPLICATION
addappid(3417510)
-- Game: addappid(3417510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417511, 1, "82923f6d966077a0b27b51b4bda1c169308085be88b1278d62a3557b657432dc")
