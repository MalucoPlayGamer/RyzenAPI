-- Lua provided by SkyAPI 
-- Game: Horny Housewives
addappid(2681490)
addappid(2681491, 1, "f59032afc98d768481b0c0753c99e848b03126c31bec8e8c7b920119896a79eb")
