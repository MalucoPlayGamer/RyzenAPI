-- Lua provided by RyzenAPI
-- Game: addappid(1619520)

-- MAIN APPLICATION
addappid(1619520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619521, 1, "1ab8c00375deb010f355c6bf2d5694790029242fdffafd27bb134159a46d7053")
