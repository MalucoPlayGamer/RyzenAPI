-- Lua provided by RyzenAPI
-- Game: Barony

-- MAIN APPLICATION
addappid(371970)
addappid(1010820)
addappid(1010821)
addappid(1010822)

-- MAIN APP DEPOTS / PACKAGES
addappid(371970,0,"7ddb00a4dd4ff1611227dd7dc0fa1560d7d533475f5077bd9c5db86e828d887f")
addappid(371971,0,"0f85f3847bc67b4d0875d0bee3bde60951129c06cc7aa6a6e2903240d94c3ddb")
addappid(371972,0,"67e87aa283676e2c78d2a3f8bb8651825e3afd860a0d39da946fbefd252348be")
addappid(371973,0,"2e77491f70fc80a27667adf0df2a1ee28d9ecff8357be343c465f47e62cca248")
addappid(470540,0,"04abc82a5fff78401c74b7dc6d2772e9cf3b93f8094dfffc634f9bdbb4bb4b8e")

