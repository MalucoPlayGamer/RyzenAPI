-- Lua provided by RyzenAPI
-- Game: Game: ITORAH

-- MAIN APPLICATION
addappid(1132910)
-- Game: addappid(1132910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132911, 1, "eff471f7ebff550f7ab4b9e9ca3a7298ebbf899dbab2d5b810aec511c89657fc")
