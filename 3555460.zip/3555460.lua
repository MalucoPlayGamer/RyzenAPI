-- Lua provided by RyzenAPI
-- Game: Game: KILL ALL ENEMIES

-- MAIN APPLICATION
addappid(3555460)
-- Game: addappid(3555460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3555461, 1, "fb706482e49dc1d85f63a189c05bab2c47e1351ca61db3982f76be9af4bc3262")
