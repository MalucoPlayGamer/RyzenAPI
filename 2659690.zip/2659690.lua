-- Lua provided by SkyAPI 
-- Game: Operation Athena
addappid(2659690)
addappid(2659691, 1, "db08365853a2e7869e3659642ba32e322fd69794411fda17330b12b42f94a5d7")
