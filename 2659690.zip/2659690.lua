-- Lua provided by RyzenAPI
-- Game: Game: Operation Athena

-- MAIN APPLICATION
addappid(2659690)
-- Game: addappid(2659690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659691, 1, "db08365853a2e7869e3659642ba32e322fd69794411fda17330b12b42f94a5d7")
