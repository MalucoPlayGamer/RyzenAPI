-- Lua provided by RyzenAPI
-- Game: Operation Athena

-- MAIN APPLICATION
addappid(2659690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659691, 1, "db08365853a2e7869e3659642ba32e322fd69794411fda17330b12b42f94a5d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
