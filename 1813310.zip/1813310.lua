-- Lua provided by RyzenAPI 
-- Game: Spin Fighter
addappid(1813310)
addappid(1813311, 1, "fd04bf1b71c800459a599d7f5754f5aae611b1f0f2a22d0717b865b72b603c0d")
