-- Lua provided by RyzenAPI
-- Game: Zhulik.exe

-- MAIN APPLICATION
addappid(768300)
-- Game: addappid(768300)

-- MAIN APP DEPOTS / PACKAGES
addappid(768301, 1, "df7b59fe118987b97bfe87780bc55feec28575549052dc9caf493ea6ad6154fb")
