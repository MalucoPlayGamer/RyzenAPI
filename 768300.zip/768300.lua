-- Lua provided by RyzenAPI
-- Game: Zhulik.exe

-- MAIN APPLICATION
addappid(768300)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(768301, 1, "df7b59fe118987b97bfe87780bc55feec28575549052dc9caf493ea6ad6154fb")

