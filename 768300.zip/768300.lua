-- Lua provided by RyzenAPI 
-- Game: Zhulik.exe
addappid(768300)
addappid(768301, 1, "df7b59fe118987b97bfe87780bc55feec28575549052dc9caf493ea6ad6154fb")
