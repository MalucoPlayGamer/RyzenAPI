-- Lua provided by SkyAPI 
-- Game: Isolationist Nightclub Simulator
addappid(1523100)
addappid(1523101, 1, "17cce73df04e74a445d7351417ef55ff0836cef1d99f89dbd2f6f0410c4f9a96")
