-- Lua provided by RyzenAPI
-- Game: AppID 434030

-- MAIN APPLICATION
addappid(434030)
addappid(500620)
addappid(643730)
addappid(643731)
addappid(771830)
addappid(794140)
addappid(794141)
addappid(794143)
addappid(820940)
addappid(898700)
addappid(932760)
addappid(1121620)
addappid(1121621)
addappid(1121622)
addappid(1214170)
addappid(1312980)
addappid(1478120)
addappid(1523430)

-- MAIN APP DEPOTS / PACKAGES
addappid(434031, 1, "175c430691e521db8fe3ca4e9c0e7471a0ced159a324a77faa349ab1fec3ab8a")
addappid(434032, 1, "bc3c122d047b0325ec444882f25f32be59b6d711188e8f9f52f7f3728d9f1cb9")
addappid(434033, 1, "676dcd2f2777f6e5df9d01e5fab20b1e359a0eaa60c988514bc0913fded566d7")
addappid(486110, 0, "0d78cb63689cb549d65a331cf0ac394a419332057d1511a0d9f6a0a39d1bbfe4")
addappid(570310, 0, "c7e19959b7f2db49cbfd3c29f2ab1de049b1bd895657cf7417611c5e8b99f36e")
addappid(611210, 0, "726aecba90cc8e3493ef831c06f383324a044d325c4ceac757fc82bc7329e732")
addappid(684610, 0, "ef8d153c2cb302f162e17d385971fe875f23a7212ceae008885134bf007e5fd0")
addappid(742410, 0, "fbde2ddf388673293c8c8494c45ac201a108a0aacc1ae33d54792fb269de79ab")
addappid(1101750, 0, "6f2e0afaba5d3442474b5aaeea047054d6337bad12a25f3601b35374371b3bf5")
