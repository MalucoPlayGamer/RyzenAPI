-- Lua provided by RyzenAPI
-- Game: Soldier of Failure 2

-- MAIN APPLICATION
addappid(729170)

-- MAIN APP DEPOTS / PACKAGES
addappid(729171, 1, "3181225a4a125872274d1495e829186882f7dd831e277645b525178ee3b19ddd")

