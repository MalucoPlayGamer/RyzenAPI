-- Lua provided by RyzenAPI
-- Game: AppID 1133590

-- MAIN APPLICATION
addappid(1133590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133591, 1, "6b8f14eb4be1ed5d256dc6309a7d6ec110bccb230ccbcb3146ea40e4f03736e5")
