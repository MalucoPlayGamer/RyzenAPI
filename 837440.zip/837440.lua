-- Lua provided by RyzenAPI
-- Game: AppID 837440

-- MAIN APPLICATION
addappid(837440)
-- Game: addappid(837440)

-- MAIN APP DEPOTS / PACKAGES
addappid(837441, 1, "7de7d2e7bff27af3820c7f62f2d072076fa30b6ab36df404e456266a84b06312")
