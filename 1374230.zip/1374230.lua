-- Lua provided by RyzenAPI
-- Game: addappid(1374230)

-- MAIN APPLICATION
addappid(1374230)
addappid(3040920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374231, 1, "0aa2cf4d17822ea9a0b8747eb87e7fc814ccb3ca99fe2a175d3037342e97f801")
