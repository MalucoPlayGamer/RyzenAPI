-- Lua provided by RyzenAPI
-- Game: AppID 248610

-- MAIN APPLICATION
addappid(248610)

-- MAIN APP DEPOTS / PACKAGES
addappid(248611, 1, "0695526bbbb43e62c7531313675df58a53e76d10ae48e062c1de0c5123134e10")
addappid(248612, 1, "65be3ad26e823055a301a2d7564228bb985023c7a49dd15b2253c3d211c9ad48")
addappid(248613, 1, "edc62c1fe8b8bc652157671569bddec3d67bb635b87b9dcb6f6a33090757ea42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
