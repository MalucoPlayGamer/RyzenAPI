-- Lua provided by RyzenAPI
-- Game: addappid(268990)

-- MAIN APPLICATION
addappid(268990)

-- MAIN APP DEPOTS / PACKAGES
addappid(268991, 1, "5a5d7fabd733f6155ea75ed7bdd87df63bf5027a632d7ad68172d7d9ea622daf")
addappid(268992, 1, "21972c71a596f8a566685eca56e99b8d88065fe3ffbe6840613ae4d3e716ad71")
addappid(268993, 1, "88dad0aed0e2fef3b00dbca54c8c558a069cc0e76652597aaafb2dceb373d692")
