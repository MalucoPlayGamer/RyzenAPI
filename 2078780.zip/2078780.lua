-- Lua provided by RyzenAPI
-- Game: 2078780

-- MAIN APPLICATION
addappid(2078780)
-- Game: addappid(2078780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078781, 1, "9331580fe1976da8789b6cf60b75e49b9f8fc6791b7a60af76ae1327c73e5dde")
addappid(2126820, 0, "77c214fe95315ae81213dc871c63d573512efec574a99e50a17ac0d6aa141fcd")
