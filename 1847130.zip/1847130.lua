-- Lua provided by RyzenAPI
-- Game: Tokyo Detectives

-- MAIN APPLICATION
addappid(1847130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847131, 1, "28ab79ad144ea8a1afa52ebabbb3631a3f6f3eddcd9d517d1116613dfd9ddb68")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1848550)
addappid(1862540)
addappid(1925840)
