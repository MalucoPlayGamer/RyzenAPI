-- Lua provided by RyzenAPI
-- Game: Game: Tokyo Detectives

-- MAIN APPLICATION
addappid(1847130)
-- Game: addappid(1847130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847131, 1, "28ab79ad144ea8a1afa52ebabbb3631a3f6f3eddcd9d517d1116613dfd9ddb68")
