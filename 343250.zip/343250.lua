-- Lua provided by RyzenAPI
-- Game: Gene

-- MAIN APPLICATION
addappid(343250)
-- Game: addappid(343250)

-- MAIN APP DEPOTS / PACKAGES
addappid(343251, 1, "e6e0a50b95fd1549429879e189112c0d5c5967c6ef806d33a2252286f326662c")
