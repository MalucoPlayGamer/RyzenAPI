-- Lua provided by RyzenAPI
-- Game: Game: LustyVerse: ShackBang

-- MAIN APPLICATION
addappid(2208620)
-- Game: addappid(2208620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208621, 1, "3b7b4d033e001ee53823432a1efa6477c3b1c173c2f55cd4553db775b1957e77")
