-- Lua provided by RyzenAPI
-- Game: Sky Break

-- MAIN APPLICATION
addappid(405370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(405371, 1, "11b1de8e26d83d024fc5438851acbc4f82407e745b79e3ee41f08548f1e946e2")
addappid(405372, 1, "7db3126578612ecc7a29e5f589a6fba90bf13128f68dca006daae4b5d2e462dd")
addappid(405373, 1, "cf38a064614137fe71c529c78b8a82fb86962f75f742a8f6cf5a8623c93ea66e")
addappid(405374, 1, "53c4fcce43e33c14cc7cafe3ce6f48b0cdf1139d1e34f86feb5c7800f9289de9")

