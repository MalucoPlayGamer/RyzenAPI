-- Lua provided by RyzenAPI
-- Game: Game: AppID 3388650

-- MAIN APPLICATION
addappid(3388650)
-- Game: addappid(3388650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388651, 1, "eb7a30cc4b60ed277c689d8992cdb410069623388b24b92b2102c0cfdeaf9115")
