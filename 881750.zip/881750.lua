-- Lua provided by RyzenAPI
-- Game: 881750

-- MAIN APPLICATION
addappid(881750)
-- Game: addappid(881750)

-- MAIN APP DEPOTS / PACKAGES
addappid(881751, 1, "d53a06e8a2d94594a42e3c5bf0e049582d2016635376d5c0d7844d8e11ac930d")
