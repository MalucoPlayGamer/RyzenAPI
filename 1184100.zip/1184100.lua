-- Lua provided by RyzenAPI
-- Game: 1184100

-- MAIN APPLICATION
addappid(1184100)
-- Game: addappid(1184100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184100,0,"7f00df5f68430d124fa0e1196e9abe13b5b14dacdd288d1473702128e0b34b41")
