-- Lua provided by RyzenAPI
-- Game: Never Mourn

-- MAIN APPLICATION
addappid(1839820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839821, 1, "e99280bc664279995e281a12b0b14e1fa01a23379e63214cbacb4dc98a900381")

