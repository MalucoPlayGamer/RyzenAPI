-- Lua provided by RyzenAPI 
-- Game: Horatio Goes Snowboarding
addappid(1589380)
addappid(1589381, 1, "ed855c1dee062a97b3ddcac4668e6bce8de15f6af1a8a45192432be7ba2ff3a5")
