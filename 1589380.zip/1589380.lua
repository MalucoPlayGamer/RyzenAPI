-- Lua provided by RyzenAPI
-- Game: 1589380

-- MAIN APPLICATION
addappid(1589380)
-- Game: addappid(1589380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589381, 1, "ed855c1dee062a97b3ddcac4668e6bce8de15f6af1a8a45192432be7ba2ff3a5")
