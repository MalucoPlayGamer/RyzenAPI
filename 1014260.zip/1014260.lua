-- Lua provided by RyzenAPI
-- Game: Passageway of the Ancients

-- MAIN APPLICATION
addappid(1014260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014261, 1, "69f6d9a52f4ef5c3b48c0ba6b71e6a0b05e76d817afdd08538cf89137e23720c")
