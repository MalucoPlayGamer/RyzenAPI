-- Lua provided by RyzenAPI
-- Game: The Bonfire 2: Uncharted Shores Demo

-- MAIN APPLICATION
addappid(1322630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322631, 1, "7d82abdd3101b9a67fdad05255b41522eb392c05400736bb31afe72a8eb260f9")

