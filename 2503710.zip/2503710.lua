-- Lua provided by RyzenAPI 
-- Game: Only One Way Up
addappid(2503710)
addappid(2503711, 1, "fa860d578426edd72d5d7f7d1fdad710e67f61c570fa1159175ecc51b231592c")
