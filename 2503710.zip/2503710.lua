-- Lua provided by RyzenAPI
-- Game: 2503710

-- MAIN APPLICATION
addappid(2503710)
-- Game: addappid(2503710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503711, 1, "fa860d578426edd72d5d7f7d1fdad710e67f61c570fa1159175ecc51b231592c")
