-- Lua provided by RyzenAPI
-- Game: Only One Way Up

-- MAIN APPLICATION
addappid(2503710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2503711, 1, "fa860d578426edd72d5d7f7d1fdad710e67f61c570fa1159175ecc51b231592c")

