-- Lua provided by RyzenAPI
-- Game: 1684151

-- MAIN APPLICATION
addappid(1684151)
-- Game: addappid(1684151)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684151,0,"618ce65f30692b2ff60ce804ca968b771751b5d4f9ef25b41aa921215e3d16d4")
