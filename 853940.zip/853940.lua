-- Lua provided by RyzenAPI
-- Game: 853940

-- MAIN APPLICATION
addappid(853940)
-- Game: addappid(853940)

-- MAIN APP DEPOTS / PACKAGES
addappid(853941, 1, "da3a46d4c70e51f88d915b620e5a5001669dba082a79a25eede5b71ee4a2e443")
