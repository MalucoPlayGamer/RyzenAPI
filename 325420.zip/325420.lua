-- Lua provided by RyzenAPI
-- Game: Game: Homebrew - Patent Unknown

-- MAIN APPLICATION
addappid(325420)
-- Game: addappid(325420)

-- MAIN APP DEPOTS / PACKAGES
addappid(325421, 1, "533aed92aa2a457de972f5d057cd056df57eff35485abd6957c84065065c053e")
