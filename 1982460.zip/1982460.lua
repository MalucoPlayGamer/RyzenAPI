-- Lua provided by RyzenAPI
-- Game: Game: AppID 1982460

-- MAIN APPLICATION
addappid(1982460)
-- Game: addappid(1982460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982461, 1, "2662e346c6e3116d8339fdc3c31ce542005222a26965dfb34e5083604f30ae5a")
