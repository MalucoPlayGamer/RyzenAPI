-- Lua provided by RyzenAPI
-- Game: MINE!

-- MAIN APPLICATION
addappid(687320)
-- Game: addappid(687320)

-- MAIN APP DEPOTS / PACKAGES
addappid(687321, 1, "6f05300434a9fc95744f1f594e822552b02e8e9e52cc46ba0e0180eca72726ec")
