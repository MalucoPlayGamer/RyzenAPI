-- Lua provided by SkyAPI 
-- Game: MINE!
addappid(687320)
addappid(687321, 1, "6f05300434a9fc95744f1f594e822552b02e8e9e52cc46ba0e0180eca72726ec")
