-- Lua provided by SkyAPI 
-- Game: Viking Squad
addappid(325930)
addappid(325931, 1, "8d081a112d6fa679e9b366661df7c2af74477b99d154e36b305b3f89959d030f")
addappid(325932, 1, "c6c9f1296c389b611092dcb0067f7a2d69fc9cead1b6fb74536883af09f1a652")
