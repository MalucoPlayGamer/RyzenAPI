-- Lua provided by RyzenAPI
-- Game: Zombie Survival Game Online

-- MAIN APPLICATION
addappid(2268560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2268561, 1, "e4d6af434888e2da6177fb3a412e7e2ad3a19966d33a6539262a9b8f7805c880")

