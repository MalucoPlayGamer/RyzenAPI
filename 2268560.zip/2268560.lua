-- Lua provided by RyzenAPI
-- Game: 2268560

-- MAIN APPLICATION
addappid(2268560)
-- Game: addappid(2268560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2268561, 1, "e4d6af434888e2da6177fb3a412e7e2ad3a19966d33a6539262a9b8f7805c880")
