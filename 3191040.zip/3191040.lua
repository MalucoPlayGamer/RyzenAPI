-- Lua provided by RyzenAPI
-- Game: Five Nights at Restroom 2 Demo

-- MAIN APPLICATION
addappid(3191040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191041, 1, "fba37d39a4d578756b5ad121300d5d68add093a21c8d2ba909789138499a9f3c")
