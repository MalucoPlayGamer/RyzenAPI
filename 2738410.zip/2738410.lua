-- Lua provided by RyzenAPI
-- Game: 2738410

-- MAIN APPLICATION
addappid(2738410)
-- Game: addappid(2738410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738411, 1, "b20747cab7f797dfd494abf64140792dd9e2f3de872ac912d2039e65e5997c1b")
