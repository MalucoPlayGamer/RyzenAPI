-- Lua provided by RyzenAPI
-- Game: Game: Blaster Simulator

-- MAIN APPLICATION
addappid(446450)
-- Game: addappid(446450)

-- MAIN APP DEPOTS / PACKAGES
addappid(446451, 1, "baf1cad5088569c623e0bcc19d6abe8de9356917fabdb1100862f967c4d03912")
addappid(446452, 1, "0f0d0186b5118430d24fb47a37d7b658e5227fb127be3f693999aadcfdb55437")
addappid(446453, 1, "a7ac6ce94d33c4c316d0e1a91220566a7c35696cd5c982a40e95a5b2c94c66df")
addappid(446454, 1, "c1d2871d40947bea31ca7a236cf78c6a875f42393cffa9fffa467775a9e0dda5")
addappid(446455, 1, "b1e5854cde4361a1566cecae9f6db249b90e029bc7143b449fae372deb2066bb")
addappid(446456, 1, "2b48fe6d895d6fc83511648816f5a3324eb429584f4a0932085d315bc5c8c1d1")
addappid(446457, 1, "d6eefe0be18555bb40e4384f2daef05ef8cf3bd84566b15a338965396a1cde81")
addappid(446458, 1, "d23cb4a20507b80445a6a8a3aeaa64e6755fa7efda82f88e201832aa6d3fb979")
