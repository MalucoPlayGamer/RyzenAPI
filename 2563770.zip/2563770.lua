-- Lua provided by RyzenAPI
-- Game: School: The Hardest RPG in Your Life

-- MAIN APPLICATION
addappid(2563770)
-- Game: addappid(2563770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563771, 1, "7b8f238b76291f009aa6e0b3e2368ae41e0dde3265ae0e3c350b613c8afefd3c")
