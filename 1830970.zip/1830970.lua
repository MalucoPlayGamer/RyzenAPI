-- Lua provided by RyzenAPI
-- Game: Game: AppID 1830970

-- MAIN APPLICATION
addappid(1830970)
-- Game: addappid(1830970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830971, 1, "f7ef2e3ef26e54cdea6c86bcf9f73af26e43faacd6ce3dfdbfb60c599bc2034f")
