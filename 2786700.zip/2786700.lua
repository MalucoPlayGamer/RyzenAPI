-- Lua provided by RyzenAPI
-- Game: Victor's Test Night

-- MAIN APPLICATION
addappid(2786700)
-- Game: addappid(2786700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786701, 1, "6d57fd96ec5b3e12d65dce0faf6f4ec2c6b00ca5b654bfad202af1048b24c7e3")
