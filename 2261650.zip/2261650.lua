-- Lua provided by RyzenAPI
-- Game: Pet Dragon Girl

-- MAIN APPLICATION
addappid(2261650)
addappid(2268090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261651, 1, "d0ff9de9211b0f996a259e049a85623df7df68f6b094642bc35db0ed632ff9e3")

