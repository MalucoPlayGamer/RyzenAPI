-- Lua provided by RyzenAPI
-- Game: R.I.P.D.: The Game

-- MAIN APPLICATION
addappid(237590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(237591, 1, "fac899c68ce000ccff63c453cba27244427bb2b105afb6a38005883687997284")
addappid(237592, 1, "8f4482e1e36125d8e1ecd1e23407be7ac914d830b00e8498cac83ca47e3b11b8")
addappid(237596, 1, "0c421d378ef2dbb6517d3256f14d881c74b644ce58cae396bde364d3145931b9")
