-- Lua provided by RyzenAPI
-- Game: My Best Friend Kouta

-- MAIN APPLICATION
addappid(2371820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371821, 1, "8c1c3dd5b19736d46b401b927ce6fa18e7cabaa276253fd31465d5203407f93c")
