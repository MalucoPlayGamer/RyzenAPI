-- Lua provided by RyzenAPI 
-- Game: Best Day Ever
addappid(1286380)
addappid(1286381, 1, "daec0999199c2a22ac6485bbad9bc9228b59b237494220d0dd9cd81116ccd478")
