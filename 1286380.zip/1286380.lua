-- Lua provided by RyzenAPI
-- Game: Best Day Ever

-- MAIN APPLICATION
addappid(1286380)
-- Game: addappid(1286380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286381, 1, "daec0999199c2a22ac6485bbad9bc9228b59b237494220d0dd9cd81116ccd478")
