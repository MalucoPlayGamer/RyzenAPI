-- Lua provided by RyzenAPI 
-- Game: AppID 926800
addappid(926800)
addappid(926801, 1, "35361d7c835a3440d7f1625a916e4a897a357b635a863fa5c13d60bf8115bc81")
addappid(926802, 1, "ce084efb0f6663befc307297f0d9b1dc152c55ea7e8bc5583d71ee8dc26fa682")
