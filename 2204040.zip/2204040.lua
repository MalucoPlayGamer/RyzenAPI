-- Lua provided by RyzenAPI
-- Game: Inheritance: Ladeina's Path

-- MAIN APPLICATION
addappid(2204040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204041, 1, "ee439f95b877449b8a024d1f210a132b4bd4c18a6e3d0fa538907786692c7bf3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2212240)
addappid(2395090)
