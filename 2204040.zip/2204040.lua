-- Lua provided by RyzenAPI
-- Game: 2204040

-- MAIN APPLICATION
addappid(2204040)
-- Game: addappid(2204040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204041, 1, "ee439f95b877449b8a024d1f210a132b4bd4c18a6e3d0fa538907786692c7bf3")
