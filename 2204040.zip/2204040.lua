-- Lua provided by SkyAPI 
-- Game: Inheritance: Ladeina's Path
addappid(2204040)
addappid(2204041, 1, "ee439f95b877449b8a024d1f210a132b4bd4c18a6e3d0fa538907786692c7bf3")
