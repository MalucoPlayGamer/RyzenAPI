-- Lua provided by RyzenAPI
-- Game: Game: AppID 942600

-- MAIN APPLICATION
addappid(942600)
-- Game: addappid(942600)

-- MAIN APP DEPOTS / PACKAGES
addappid(942601, 1, "e426707981331a9f47554bda2f4364e9b2fbffe708a7a86b046a3f8b4206c5ac")
