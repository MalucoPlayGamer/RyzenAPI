-- Lua provided by SkyAPI 
-- Game: Everdell
addappid(1722840)
addappid(1722841, 1, "4d1ad96591ed74669b1cd366bb7492af69a83b6b68eb33a2a34d96ebfb5e6650")
addappid(3029430)
