-- Lua provided by RyzenAPI
-- Game: VoiceBot

-- MAIN APPLICATION
addappid(374400)

-- MAIN APP DEPOTS / PACKAGES
addappid(374401, 1, "99467c9b1ca1addba943fe61d5dab63c27ce76e7140e65abb1fd6467bacaff31")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(375060)
