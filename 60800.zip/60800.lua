-- Lua provided by RyzenAPI
-- Game: Numen: Contest of Heroes

-- MAIN APPLICATION
addappid(60800)

-- MAIN APP DEPOTS / PACKAGES
addappid(60801, 1, "fc7f4b6c1b13daaefd1ddbddb83c589796685f37cfd253e6c9adca43e7a57d01")
