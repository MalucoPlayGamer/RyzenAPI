-- Lua provided by RyzenAPI 
-- Game: Castle of Secrets
addappid(1825110)
addappid(1825111, 1, "90fda124d16af6b7711db2d6b2173bf8228241be02ceeb29b892ab39aef07c3f")
