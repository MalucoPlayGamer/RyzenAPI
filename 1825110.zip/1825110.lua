-- Lua provided by RyzenAPI
-- Game: addappid(1825110)

-- MAIN APPLICATION
addappid(1825110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825111, 1, "90fda124d16af6b7711db2d6b2173bf8228241be02ceeb29b892ab39aef07c3f")
