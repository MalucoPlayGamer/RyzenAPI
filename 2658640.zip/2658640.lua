-- Lua provided by RyzenAPI
-- Game: Oasis Mission: Colony Sim

-- MAIN APPLICATION
addappid(2658640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658641, 1, "a759022eb2275e3a6a62f892dbaa9fffffc30933244919f493bd6ffe01ac809a")
