-- Lua provided by RyzenAPI
-- Game: Hentai Milf Quiz 3

-- MAIN APPLICATION
addappid(1420960)
-- Game: addappid(1420960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420961, 1, "b8004253da915147f50398d5f329829c9afc599e78e0e0d4d82c99c307fb1c38")
