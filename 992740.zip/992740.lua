-- Lua provided by RyzenAPI
-- Game: 祈風 Inorikaze

-- MAIN APPLICATION
addappid(992740)
-- Game: addappid(992740)

-- MAIN APP DEPOTS / PACKAGES
addappid(992741, 1, "21f1d65938a1ea966078a4eea8fbb91b07238c72554a6fcd4115889af166f31f")
addappid(1025220, 0, "8932c058fac2abf92351627b1c919571de26f5a726ba68498cd41cb4b90766c8")
