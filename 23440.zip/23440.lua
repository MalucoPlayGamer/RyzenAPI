-- Lua provided by RyzenAPI
-- Game: 23440

-- MAIN APPLICATION
addappid(23421)
addappid(23440)
-- Game: addappid(23440)

-- MAIN APP DEPOTS / PACKAGES
addappid(23422,0,"e4f0007e5cb97373de4b6e7661408badfedfceede8583293a1cd96120d894f73")
