-- Lua provided by RyzenAPI
-- Game: Cross Princess

-- MAIN APPLICATION
addappid(1301620)
-- Game: addappid(1301620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301621, 1, "92e4f0127a67a3c11994cd633972d90cf424c3467006aaada190965ab66be903")
