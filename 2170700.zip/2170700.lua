-- Lua provided by RyzenAPI
-- Game: Game: Arcade Classics

-- MAIN APPLICATION
addappid(2170700)
-- Game: addappid(2170700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170701, 1, "a3d9ef02e60c0dbe6082232aad43f03cf96f99f09edb37a6e2cbaf21ed94dda4")
