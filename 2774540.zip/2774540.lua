-- Lua provided by RyzenAPI
-- Game: Game: G.O.P.O.T.A 2

-- MAIN APPLICATION
addappid(2774540)
-- Game: addappid(2774540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774541, 1, "a6c04cac425ab4d9397a54a132d21729ff1ad10a80781568c62375d0752425c9")
