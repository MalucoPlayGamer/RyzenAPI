-- Lua provided by RyzenAPI
-- Game: Alien Crusader

-- MAIN APPLICATION
addappid(786370)

-- MAIN APP DEPOTS / PACKAGES
addappid(786371, 1, "db503d87d604f11d3c29d013040e88e649090166a92d5cd088c99235fd556a7f")

