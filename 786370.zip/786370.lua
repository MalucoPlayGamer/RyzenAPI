-- Lua provided by RyzenAPI 
-- Game: Alien Crusader
addappid(786370)
addappid(786371, 1, "db503d87d604f11d3c29d013040e88e649090166a92d5cd088c99235fd556a7f")
