-- Lua provided by RyzenAPI
-- Game: AppID 348710

-- MAIN APPLICATION
addappid(348710)
addappid(392170)
addappid(392171)

-- MAIN APP DEPOTS / PACKAGES
addappid(348711, 1, "f460cf42e7b38eebbd87467bf8b117bca52723d1f9caac3c01398388992206fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
