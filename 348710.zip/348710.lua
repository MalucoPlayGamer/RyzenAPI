-- Lua provided by RyzenAPI
-- Game: addappid(348710)

-- MAIN APPLICATION
addappid(348710)
addappid(392170)
addappid(392171)

-- MAIN APP DEPOTS / PACKAGES
addappid(348711, 1, "f460cf42e7b38eebbd87467bf8b117bca52723d1f9caac3c01398388992206fd")
