-- Lua provided by SkyAPI 
-- Game: Sapu
addappid(2250710)
addappid(2250711, 1, "c0f14404748e8c309c409ab6ae3b50a493d00188a31f4698506f437db11e4433")
