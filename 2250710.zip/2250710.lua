-- Lua provided by RyzenAPI
-- Game: Game: Sapu

-- MAIN APPLICATION
addappid(2250710)
-- Game: addappid(2250710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250711, 1, "c0f14404748e8c309c409ab6ae3b50a493d00188a31f4698506f437db11e4433")
