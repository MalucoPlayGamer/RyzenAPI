-- Lua provided by RyzenAPI
-- Game: addappid(2066420)

-- MAIN APPLICATION
addappid(2066420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066421, 1, "d4fcb9a072cd451fcd2f6266aad6dd22ec18f64084e9c474dbe789cdcf6d72d5")
