-- Lua provided by RyzenAPI
-- Game: AppID 1148490

-- MAIN APPLICATION
addappid(1148490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148491, 1, "7535016d05b44336cd132067a2e69fe57c043127d2252d41b8a3a72fa5e5a0c5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2351520)
