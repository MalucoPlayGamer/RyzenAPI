-- Lua provided by RyzenAPI
-- Game: Mystery Society 2: Hidden Puzzles

-- MAIN APPLICATION
addappid(2367650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367651, 1, "a0e52255b175dc15394cd590672acf7b55d0f3fa09295ce689e17771f47c8c3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
