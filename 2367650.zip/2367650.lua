-- Lua provided by RyzenAPI
-- Game: Mystery Society 2: Hidden Puzzles

-- MAIN APPLICATION
addappid(2367650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367651, 1, "a0e52255b175dc15394cd590672acf7b55d0f3fa09295ce689e17771f47c8c3d")
