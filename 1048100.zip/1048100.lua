-- Lua provided by RyzenAPI
-- Game: Peekaboo

-- MAIN APPLICATION
addappid(1048100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048101, 1, "94ca484727a3e58a706790af564b80ca72cecf051b432b1a38d118b336a634cc")
