-- Lua provided by RyzenAPI
-- Game: addappid(3837430)

-- MAIN APPLICATION
addappid(3837430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3837431, 1, "0bdbe24d0aedacdfdfc3edfe59b7797e855c0578c1b2704f27ac9089510bb4ed")
