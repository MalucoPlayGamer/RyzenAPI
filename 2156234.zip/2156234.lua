-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2156234)
-- Game: addappid(2156234)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156234,0,"3550e2162f484e952e30614c9c840a49b386a5feedb62f0fa7e6e35ca41711f3")
