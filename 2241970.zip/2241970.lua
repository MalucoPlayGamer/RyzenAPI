-- Lua provided by RyzenAPI
-- Game: 2241970

-- MAIN APPLICATION
addappid(2241970)
-- Game: addappid(2241970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241971, 1, "ac44ed3cac938a955d080899c591caa259ea79404612d465d4caf28c5825f8ff")
