-- Lua provided by RyzenAPI
-- Game: Game: Foodslingers

-- MAIN APPLICATION
addappid(2145460)
-- Game: addappid(2145460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2145461, 1, "38d598ec2602246aed9b527390019d4aa158c852621845f5a11d3c48ca2b8891")
