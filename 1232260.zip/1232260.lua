-- Lua provided by RyzenAPI 
-- Game: AppID 1232260
addappid(1232260)
addappid(1232261, 1, "b3c5fa93e7bae28edc30dcf18a2ab53148006bea82fc310dbb02afafe866bc22")
