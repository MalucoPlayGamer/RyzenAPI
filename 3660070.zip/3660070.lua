-- Lua provided by RyzenAPI
-- Game: Game: Disaster Blaster Soundtrack

-- MAIN APPLICATION
addappid(3660070)
-- Game: addappid(3660070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3660071, 1, "960909f82834e715ebcc18de1add002c34bbbebe6efbab6f8b016bcdd81cd78b")
