-- Lua provided by RyzenAPI
-- Game: Game: Ultra Strikers Playtest

-- MAIN APPLICATION
addappid(2984560)
-- Game: addappid(2984560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984561, 1, "daf7e3fd2f3256e8fc631194e7b693ec1aa7c74d5d292ef87d9b793806b339e6")
