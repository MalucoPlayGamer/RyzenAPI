-- Lua provided by RyzenAPI
-- Game: Methods: The Detective Competition Soundtrack

-- MAIN APPLICATION
addappid(1307000)
-- Game: addappid(1307000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307001, 1, "f3f86395f2d7ecde7d6c139a92ad01c7d62f054fe79aab138a23a64dbe15833d")
addappid(1307002, 1, "7940104b777ec04da03a56b2d597765ee65c09b2c19b20bcbf7ed4757a3088f1")
