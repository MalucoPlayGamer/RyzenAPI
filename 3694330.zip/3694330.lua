-- Lua provided by RyzenAPI
-- Game: 3694330

-- MAIN APPLICATION
addappid(3694330)
-- Game: addappid(3694330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3694332,0,"9f282568f1fecfe8d626a1ed585ab27e6ccf8ae63677356764c290f80ee95b2e")
