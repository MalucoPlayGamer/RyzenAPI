-- Lua provided by RyzenAPI
-- Game: Spheroids

-- MAIN APPLICATION
addappid(586430)
-- Game: addappid(586430)

-- MAIN APP DEPOTS / PACKAGES
addappid(586431, 1, "8a5de2b7fac4f20524c330fb7853e25cc1f5d6d7952b0baf452633ab264b9bce")
