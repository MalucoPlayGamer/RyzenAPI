-- Lua provided by SkyAPI 
-- Game: Spheroids
addappid(586430)
addappid(586431, 1, "8a5de2b7fac4f20524c330fb7853e25cc1f5d6d7952b0baf452633ab264b9bce")
