-- Lua provided by RyzenAPI
-- Game: Faulty Apprentice - 18+ Uncensored Content

-- MAIN APPLICATION
addappid(1287760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287761, 1, "8940765059c35af8bcf5dc17931f7d4fca302ca498054231bf1db40e9763487c")

