-- Lua provided by RyzenAPI
-- Game: AppID 473690

-- MAIN APPLICATION
addappid(473690)
addappid(893770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(473691, 1, "3312a7c16cbea08e1ab0efce7eebada0c68a417edc76466f95d5b103f4d12e4f")
addappid(473694, 1, "e0ed94e1ed766df45ef0b17441f159950a9fac4e2a3c52f39403d60baad44d4b")
addappid(681701, 0, "35ed234bedd36ab001622e99af90b864103284ebaedceb8dcb1157c5e4456d4b")

