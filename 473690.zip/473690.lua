-- Lua provided by RyzenAPI
-- Game: AppID 473690

-- MAIN APPLICATION
addappid(473690)

-- MAIN APP DEPOTS / PACKAGES
addappid(473691, 1, "3312a7c16cbea08e1ab0efce7eebada0c68a417edc76466f95d5b103f4d12e4f")
addappid(473694, 1, "e0ed94e1ed766df45ef0b17441f159950a9fac4e2a3c52f39403d60baad44d4b")
addappid(681701, 0, "35ed234bedd36ab001622e99af90b864103284ebaedceb8dcb1157c5e4456d4b")
