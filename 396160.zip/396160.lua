-- Lua provided by RyzenAPI
-- Game: Secret Of Magia

-- MAIN APPLICATION
addappid(396160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(396161, 1, "d96b1ec77c062e1cd4774ef40a9662f199dba5b835ca0efeee866c79c6bb64f8")

