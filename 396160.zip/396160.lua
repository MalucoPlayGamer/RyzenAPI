-- Lua provided by RyzenAPI
-- Game: 396160

-- MAIN APPLICATION
addappid(396160)
-- Game: addappid(396160)

-- MAIN APP DEPOTS / PACKAGES
addappid(396161, 1, "d96b1ec77c062e1cd4774ef40a9662f199dba5b835ca0efeee866c79c6bb64f8")
