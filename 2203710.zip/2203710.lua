-- Lua provided by RyzenAPI
-- Game: Hunted: Kalevala

-- MAIN APPLICATION
addappid(2203710)
-- Game: addappid(2203710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203711, 1, "60fa923713524feb34739f074d7ee3b1a72d62b379001b4466421bc01dd6cb51")
