-- Lua provided by RyzenAPI
-- Game: Hunted: Kalevala

-- MAIN APPLICATION
addappid(2203710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203711, 1, "60fa923713524feb34739f074d7ee3b1a72d62b379001b4466421bc01dd6cb51")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
