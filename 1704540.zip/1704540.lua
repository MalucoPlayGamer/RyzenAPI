-- Lua provided by RyzenAPI
-- Game: Pico Islands

-- MAIN APPLICATION
addappid(1704540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704541, 1, "6667b7cab43ffde557f384326e3c60fd72da570f3920ee5cf603cf1de2b43310")
