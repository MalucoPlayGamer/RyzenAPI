-- Lua provided by RyzenAPI 
-- Game: Spicy Strip Poker
addappid(2244660)
addappid(2244661, 1, "7a0431f7bfd7cfbec090c138250fe361828e46982133746c4bbf24846352ce1a")
