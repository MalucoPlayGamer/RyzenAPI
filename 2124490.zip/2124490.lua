-- Lua provided by RyzenAPI
-- Game: Game: SILENT HILL 2

-- MAIN APPLICATION
addappid(2124490)
addappid(2951540)
addappid(3097490)
addappid(3097500)
-- Game: addappid(2124490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124491, 1, "1a14569bdc22983489a37bb81ed420c6230f43e84548d0ec0d4a3e9687861955")
addappid(2951541, 1, "e089852efbe924984e137b7c02cf0f4d4481f091625dd22b61be2e5ffd02b994")
