-- Lua provided by RyzenAPI
-- Game: SILENT HILL 2

-- MAIN APPLICATION
addappid(2124490)
addappid(2951540)
addappid(3097490)
addappid(3097500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124491, 1, "1a14569bdc22983489a37bb81ed420c6230f43e84548d0ec0d4a3e9687861955")
addappid(2951541, 1, "e089852efbe924984e137b7c02cf0f4d4481f091625dd22b61be2e5ffd02b994")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
