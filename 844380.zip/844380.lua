-- Lua provided by RyzenAPI
-- Game: Cave Digger VR

-- MAIN APPLICATION
addappid(844380)
addappid(870600)
addappid(894780)
addappid(955990)

-- MAIN APP DEPOTS / PACKAGES
addappid(844382,0,"2c60161b5938462b0e3ad7934d77e9b1173d50dbf835584f95a3c1115ebaab93")

