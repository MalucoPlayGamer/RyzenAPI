-- Lua provided by SkyAPI 
-- Game: AppID 1420330
addappid(1420330)
addappid(1420331, 1, "27d5364225b60c2d1823a2ab35598473391c551e0a7b0a388c09663026b89c68")
