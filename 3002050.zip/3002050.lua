-- Lua provided by RyzenAPI
-- Game: addappid(3002050)

-- MAIN APPLICATION
addappid(3002050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002051, 1, "6be0257e69d24e487930c9ab6589c1028fdc62c8aff752e2aecfc1f158d3239e")
