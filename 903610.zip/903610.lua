-- Lua provided by RyzenAPI
-- Game: CINERIS SOMNIA - Original Soundtrack

-- MAIN APPLICATION
addappid(903610)

-- MAIN APP DEPOTS / PACKAGES
addappid(903610,0,"b8e8bfb3acdbeae530c346e8ef0289552c8b428b186cdd3d6e20df16d0770b9c")

