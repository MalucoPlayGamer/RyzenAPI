-- Lua provided by RyzenAPI
-- Game: 战场英雄物语

-- MAIN APPLICATION
addappid(1150850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150851, 1, "daa3420e10d520b791561b40fb3528445cb0496e4b576e2a650fba808c4401d1")

