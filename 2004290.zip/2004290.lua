-- Lua provided by RyzenAPI
-- Game: Game: Instant War

-- MAIN APPLICATION
addappid(2004290)
-- Game: addappid(2004290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004291, 1, "9c56c0d7255703de2c49b860e8f4b28954c431bcb52baa4bf386bc056aa6fc18")
