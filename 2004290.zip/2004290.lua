-- Lua provided by RyzenAPI
-- Game: Instant War

-- MAIN APPLICATION
addappid(2004290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004291, 1, "9c56c0d7255703de2c49b860e8f4b28954c431bcb52baa4bf386bc056aa6fc18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
