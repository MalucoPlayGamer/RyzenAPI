-- Lua provided by RyzenAPI
-- Game: 见诡录：阴魂街 Haunting Record: Phantom Street

-- MAIN APPLICATION
addappid(3387330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3387331, 1, "a65e36e4acf591a021a0bfcd7b3c3c6b9ced4d958abdf3bf0c5d2a36c2df5432")

