-- Lua provided by RyzenAPI
-- Game: Sex Simulator 2020

-- MAIN APPLICATION
addappid(1422240)
-- Game: addappid(1422240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422241, 1, "17c4a51b5fbbaf369cd37c80248f0578192dc44c5faa9b5a27ada860c909b80c")
