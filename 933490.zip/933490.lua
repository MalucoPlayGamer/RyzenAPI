-- Lua provided by RyzenAPI
-- Game: addappid(933490)

-- MAIN APPLICATION
addappid(933490)

-- MAIN APP DEPOTS / PACKAGES
addappid(933490,0,"1412f8846c6281e321fa601919eb5ab9f4a41dc100ff1a5e276d9b9e1bce357a")
