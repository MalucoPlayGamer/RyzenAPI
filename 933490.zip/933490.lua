-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(933490)

-- MAIN APP DEPOTS / PACKAGES
addappid(933490,0,"1412f8846c6281e321fa601919eb5ab9f4a41dc100ff1a5e276d9b9e1bce357a")
