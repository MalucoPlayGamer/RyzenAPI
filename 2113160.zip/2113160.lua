-- Lua provided by RyzenAPI
-- Game: 2113160

-- MAIN APPLICATION
addappid(2113160)
-- Game: addappid(2113160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113161, 1, "6126397113fe225d042f3b5832ed1123fb1f4a759c1ddc7262e7afca01d72890")
