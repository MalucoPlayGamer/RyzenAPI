-- Lua provided by RyzenAPI 
-- Game: Goetia 2
addappid(1984110)
addappid(1984111, 1, "195348ff3d1789b859caf0ef20a4413470e4ba738771f366e10bf4af5b8d09b5")
