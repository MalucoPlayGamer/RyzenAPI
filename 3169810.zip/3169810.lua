-- Lua provided by RyzenAPI
-- Game: Days with girlfriends : Kello&Cammy

-- MAIN APPLICATION
addappid(3169810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169811, 1, "0f12f6da56b5ebf1f6d8a6f52dff9d597532f5987cf543bf8c98cef46446517b")
