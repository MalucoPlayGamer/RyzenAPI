-- Lua provided by RyzenAPI
-- Game: PBA Basketball Slam: Arcade Edition

-- MAIN APPLICATION
addappid(1372990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372991, 1, "0cdc379cc6eda66bf12ba3a983bd1181bca203762babbc98cf89cf5ba47f910c")
