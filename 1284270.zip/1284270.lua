-- Lua provided by RyzenAPI 
-- Game: Defective Holiday OST
addappid(1284270)
addappid(1284271, 1, "9d4dc749675880df7e41c2596885976d903e1afb5e13f19e7f8e98c837675665")
