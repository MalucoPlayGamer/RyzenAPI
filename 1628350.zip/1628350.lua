-- Lua provided by RyzenAPI
-- Game: AppID 1628350

-- MAIN APPLICATION
addappid(1628350)
-- Game: addappid(1628350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628351, 1, "34d2f12079df06725c158782f1ce1db27ba66c6dd9f5610a901fcc7dd5b9bcae")
