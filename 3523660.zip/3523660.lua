-- Lua provided by RyzenAPI
-- Game: Adult Fairy Tale -Collector Viscount-

-- MAIN APPLICATION
addappid(3523660)
-- Game: addappid(3523660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3523661, 1, "38cdbe60a249ccff111d3c5426d1849868f44319bc0c2e95e27cf908717ec3a9")
