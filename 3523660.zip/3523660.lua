-- Lua provided by SkyAPI 
-- Game: Adult Fairy Tale -Collector Viscount-
addappid(3523660)
addappid(3523661, 1, "38cdbe60a249ccff111d3c5426d1849868f44319bc0c2e95e27cf908717ec3a9")
