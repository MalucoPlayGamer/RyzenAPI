-- Lua provided by RyzenAPI
-- Game: Wordle -  中文

-- MAIN APPLICATION
addappid(1532580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532580,0,"36ce460e321e83e855a15098122c67a1fb9556e0af491d77b798e0b69a50298e")

