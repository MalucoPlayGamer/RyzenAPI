-- Lua provided by SkyAPI 
-- Game: AppID 1020060
addappid(1020060)
addappid(1020061, 1, "1e7023dc19f3af0fa63f9c9809bf008fbefe0b916d30917ebfa77847294188cf")
