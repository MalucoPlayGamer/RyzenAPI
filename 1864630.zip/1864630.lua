-- Lua provided by SkyAPI 
-- Game: AppID 1864630
addappid(1864630)
addappid(1864631, 1, "3f598bf06d559bac35b4126c67d4c13870d24d9a413a97c62ceaea905c08f5ce")
