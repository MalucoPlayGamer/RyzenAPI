-- Lua provided by RyzenAPI
-- Game: AppID 1864630

-- MAIN APPLICATION
addappid(1864630)
-- Game: addappid(1864630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864631, 1, "3f598bf06d559bac35b4126c67d4c13870d24d9a413a97c62ceaea905c08f5ce")
