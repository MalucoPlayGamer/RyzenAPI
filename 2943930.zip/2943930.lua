-- Lua provided by RyzenAPI
-- Game: Game: BOBR KURWA

-- MAIN APPLICATION
addappid(2943930)
-- Game: addappid(2943930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943931, 1, "9a8295462d215b03c99abb084288d93fa8f300454f3b55a33e55e95d92709e0c")
