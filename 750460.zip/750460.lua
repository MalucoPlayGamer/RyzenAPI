-- Lua provided by RyzenAPI
-- Game: WRONGED

-- MAIN APPLICATION
addappid(750460)
-- Game: addappid(750460)

-- MAIN APP DEPOTS / PACKAGES
addappid(750462,0,"c457b2e3cf00515b9c02379faef51415466b40bf0ba1887a694b9a423223849c")
