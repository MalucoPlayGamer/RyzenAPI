-- Lua provided by RyzenAPI
-- Game: AppID 343710

-- MAIN APPLICATION
addappid(343710)

-- MAIN APP DEPOTS / PACKAGES
addappid(343711, 1, "b9045328a96d74fc8de918d9735fa1ecbbccfaf49a6b625a1c018ebe907d6e58")
addappid(343712, 1, "315eb95050f3595a5b06dcb1dd115fab04343c109b9d310ededcc1a66c520fdc")
addappid(343713, 1, "56f00637415a1a87c6e998531b391b0537cc10e4623199420b7995cdae0fd4aa")
addappid(768730, 0, "a2104da33818066a66cf7a4a3cc5530303dcc7019815efbe38f3c6819508551a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
