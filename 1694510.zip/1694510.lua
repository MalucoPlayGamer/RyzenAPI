-- Lua provided by RyzenAPI
-- Game: Barista Simulator

-- MAIN APPLICATION
addappid(1694510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694511, 1, "1c0709139b9ceccdb08516f2ffddcbc2a1900c721a9435c515ffb008d890e97b")

