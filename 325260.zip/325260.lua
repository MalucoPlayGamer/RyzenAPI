-- Lua provided by RyzenAPI
-- Game: PANZER BALL

-- MAIN APPLICATION
addappid(325260)

-- MAIN APP DEPOTS / PACKAGES
addappid(325261, 1, "9526235b93c6a72cf29081a7460ff8c062bf5322102a2deebfabb2fdf3a0ebc4")
