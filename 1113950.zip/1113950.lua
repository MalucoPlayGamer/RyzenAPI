-- Lua provided by RyzenAPI
-- Game: addappid(1113950)

-- MAIN APPLICATION
addappid(1113950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113951, 1, "9f1074f8cfd28669cf37131747ac33dbd9af51c938c013f62b5af9fc24b02b48")
