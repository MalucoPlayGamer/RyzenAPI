-- Lua provided by RyzenAPI
-- Game: AppID 1113950

-- MAIN APPLICATION
addappid(1113950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113951, 1, "9f1074f8cfd28669cf37131747ac33dbd9af51c938c013f62b5af9fc24b02b48")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
