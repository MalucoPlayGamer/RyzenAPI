-- Lua provided by RyzenAPI
-- Game: Game: AppID 3520240

-- MAIN APPLICATION
addappid(3520240)
-- Game: addappid(3520240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3520241, 1, "52780802f8de8f384eb00096f92f1d49ac37e31cb64e219d8994b92fc24f8ba8")
