-- Lua provided by RyzenAPI
-- Game: Vlad Voievod Dracula. Episode 1

-- MAIN APPLICATION
addappid(1794430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794432,0,"06e23b8b3f507c94821da07ba485ffd822f0a993f285afa1d33eeaae14b06ad3")

