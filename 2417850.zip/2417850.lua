-- Lua provided by RyzenAPI
-- Game: Yolk Heroes: A Long Tamago

-- MAIN APPLICATION
addappid(2417850)
-- Game: addappid(2417850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417851, 1, "646bd332901e6eded07e2694bb11432d59607f6e7450835cac0cd91f524914ca")
