-- Lua provided by RyzenAPI 
-- Game: City Supermarket Simulator
addappid(3614600)
addappid(3614601, 1, "28caec4338cc5bdb2f293098155ccd11e0216e73272fff6dfe8432a6a168235d")
