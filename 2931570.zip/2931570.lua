-- Lua provided by RyzenAPI
-- Game: addappid(2931570)

-- MAIN APPLICATION
addappid(2931570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931571, 1, "c610b355bdc8a01b4b5d1a944e489e5a6d79c0de85abdeea7492850eeb4de9c0")
