-- Lua provided by RyzenAPI
-- Game: Game: The Journey Home

-- MAIN APPLICATION
addappid(519170)
-- Game: addappid(519170)

-- MAIN APP DEPOTS / PACKAGES
addappid(519171, 1, "9db8e534c91761ab54c78c263ead4739f132cab494dbda5e7f5ef4b5788c7438")
