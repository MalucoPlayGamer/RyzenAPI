-- Lua provided by RyzenAPI
-- Game: 1721020

-- MAIN APPLICATION
addappid(1721020)
-- Game: addappid(1721020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721021, 1, "22ddd5bf07e73cfbb9c0f0ec452508d92e7d59743df4cdeb50ed13a707d07202")
