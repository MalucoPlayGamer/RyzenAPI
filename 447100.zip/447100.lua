-- Lua provided by RyzenAPI
-- Game: 447100

-- MAIN APPLICATION
addappid(447100)
-- Game: addappid(447100)

-- MAIN APP DEPOTS / PACKAGES
addappid(447101, 1, "a4550bb04ff552b4b8e10d1e019d380c81a5b2dc284bda63fd425aefc1b20308")
