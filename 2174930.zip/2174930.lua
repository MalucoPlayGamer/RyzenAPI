-- Lua provided by RyzenAPI
-- Game: Slippery Richard! ~ He's Taller Than My Husband ~

-- MAIN APPLICATION
addappid(2174930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174931, 1, "d30ea8d6e5e655129c8f47ac837fb5a7e96d00555c939a3678df26536208e65b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
