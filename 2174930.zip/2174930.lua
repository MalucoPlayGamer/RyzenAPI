-- Lua provided by RyzenAPI
-- Game: 2174930

-- MAIN APPLICATION
addappid(2174930)
-- Game: addappid(2174930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174931, 1, "d30ea8d6e5e655129c8f47ac837fb5a7e96d00555c939a3678df26536208e65b")
