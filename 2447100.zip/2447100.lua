-- Lua provided by RyzenAPI
-- Game: Scarred

-- MAIN APPLICATION
addappid(2447100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2447101, 1, "45664cca6484d1396e655d45793115e26c623b3a3c649ee69c21b48817acc834")

