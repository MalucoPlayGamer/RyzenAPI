-- Lua provided by RyzenAPI
-- Game: 1+1=？ Demo

-- MAIN APPLICATION
addappid(3409860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3409861, 1, "8fd5162a011ea406c137ec9e26b5fc8549ebc197348cad88ebdfa90516ac54a0")
