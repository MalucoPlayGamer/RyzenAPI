-- Lua provided by RyzenAPI
-- Game: Drive And Unwind

-- MAIN APPLICATION
addappid(3675210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3675211, 1, "ea5c4aaf6878b7b78879bb9af856a587ae3fd7fbbbbf6352a8a92c84341fc6e3")
