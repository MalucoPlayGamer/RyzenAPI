-- Lua provided by RyzenAPI
-- Game: Game: AppID 718090

-- MAIN APPLICATION
addappid(718090)
-- Game: addappid(718090)

-- MAIN APP DEPOTS / PACKAGES
addappid(718091, 1, "87addfed6e1bfaf483043649dac87c7c7d46eeb80c8445241feed81f08bd2ea0")
