-- Lua provided by RyzenAPI
-- Game: The Hero Unmasked!

-- MAIN APPLICATION
addappid(684060)
-- Game: addappid(684060)

-- MAIN APP DEPOTS / PACKAGES
addappid(684061, 1, "4f21588460774a5d58af47b780dbe132e7ceb48aa60410cfa4013d872c12d08a")
