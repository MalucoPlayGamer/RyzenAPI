-- Lua provided by RyzenAPI
-- Game: Awe

-- MAIN APPLICATION
addappid(371450)
-- Game: addappid(371450)

-- MAIN APP DEPOTS / PACKAGES
addappid(371451, 1, "f4b65ef4fe40649e4868ed731cc19f8c4343b0971ee70f0464c38acf4d558597")
addappid(371452, 1, "619c342c48381792855978053adede0c886f1ae40c6fe5b88423cfc7af25b609")
addappid(371453, 1, "b27bf04a9342e22f93e29c98989fbe00596b1ddd64bdb97c643c0f61f3cbeca9")
addappid(371454, 1, "77d1b3c5f4e4ac861f6739fd6ef5813bc4eff7a5c162cbd041a75df3599b1ade")
