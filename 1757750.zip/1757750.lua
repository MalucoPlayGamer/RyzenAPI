-- Lua provided by RyzenAPI
-- Game: addappid(1757750)

-- MAIN APPLICATION
addappid(1757750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757751, 1, "0d72563398ee575fcb575c9596fea6f1d64b7c93f5e15692c534beb8b4a729c9")
