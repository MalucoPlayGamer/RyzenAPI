-- Lua provided by RyzenAPI
-- Game: 2321580

-- MAIN APPLICATION
addappid(2321580)
-- Game: addappid(2321580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321581, 1, "a69fd7eeac36c2ebb36a11777b2558b949e28a58473bad48194cf782e4520a6a")
