-- Lua provided by SkyAPI 
-- Game: StormEdge: Wind of Change
addappid(2321580)
addappid(2321581, 1, "a69fd7eeac36c2ebb36a11777b2558b949e28a58473bad48194cf782e4520a6a")
