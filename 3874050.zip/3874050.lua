-- Lua provided by RyzenAPI
-- Game: Duck Life 4 Classic

-- MAIN APPLICATION
addappid(3874050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3874051,0,"c46b60c07f69dc0abdfe9ba97d372da0b9ca0933bee49b89fbf3d21f48ca04ba")

