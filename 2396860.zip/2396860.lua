-- Lua provided by RyzenAPI
-- Game: ～ Innocent Stuck-up Girls! ～ 肉食ギャルは清純派！？

-- MAIN APPLICATION
addappid(2396860)
-- Game: addappid(2396860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396861, 1, "02fb1bc49332cba095b3010a6bdeaaea2adc227cbd9ff58386caa954f9979386")
