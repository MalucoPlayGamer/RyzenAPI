-- Lua provided by RyzenAPI
-- Game: Morbid Catastrophe

-- MAIN APPLICATION
addappid(2362980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362981,0,"7cd6556869d16b7a535e7c00c5fd36b3040b49200394325dd25f138c7d4ef843")

