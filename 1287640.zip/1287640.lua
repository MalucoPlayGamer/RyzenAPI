-- Lua provided by RyzenAPI
-- Game: CAGE-FACE | Case 1: The Mine

-- MAIN APPLICATION
addappid(1287640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287641, 1, "fbadb00abb783d08f551be606443e2f7c4b3c0c29a9fa8370631a827c47fa3c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
