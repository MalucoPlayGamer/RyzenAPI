-- Lua provided by RyzenAPI
-- Game: CAGE-FACE | Case 1: The Mine

-- MAIN APPLICATION
addappid(1287640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287641, 1, "fbadb00abb783d08f551be606443e2f7c4b3c0c29a9fa8370631a827c47fa3c0")

