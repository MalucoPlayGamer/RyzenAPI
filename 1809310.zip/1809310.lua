-- Lua provided by RyzenAPI 
-- Game: 侠之信条
addappid(1809310)
addappid(1809311, 1, "3c1477c17360883f332878dcf6d44ee1cf0b79c5cf70bd3b746d7887f9d1a33c")
