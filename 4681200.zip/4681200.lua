-- Lua provided by RyzenAPI
-- Game: Severed Light

-- MAIN APPLICATION
addappid(4681200)

-- MAIN APP DEPOTS / PACKAGES
addappid(4681201,0,"cacd5268e429fc968952cf0e3e1f47c28610691ad7adede79061b81c77d6b9fc")

