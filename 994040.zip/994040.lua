-- Lua provided by RyzenAPI
-- Game: Lichtspeer: Double Speer Edition

-- MAIN APPLICATION
addappid(994040)
-- Game: addappid(994040)

-- MAIN APP DEPOTS / PACKAGES
addappid(994041, 1, "4584668c19a11ff187ce39f6eb83dab60c9ec299d64cf12ae5c02f82a5e46cdb")
