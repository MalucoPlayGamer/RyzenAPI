-- Lua provided by SkyAPI 
-- Game: AppID 994040
addappid(994040)
addappid(994041, 1, "4584668c19a11ff187ce39f6eb83dab60c9ec299d64cf12ae5c02f82a5e46cdb")
