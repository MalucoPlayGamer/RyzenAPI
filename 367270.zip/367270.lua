-- Lua provided by RyzenAPI
-- Game: addappid(367270)

-- MAIN APPLICATION
addappid(367270)

-- MAIN APP DEPOTS / PACKAGES
addappid(367271, 1, "c24ac20cf1f18da2f3050fd65c5595e621ed1a0f1232c99cae8caf5545dcf52b")
