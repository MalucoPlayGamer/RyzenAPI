-- Lua provided by RyzenAPI
-- Game: The Amazing Shrinking Giraffe

-- MAIN APPLICATION
addappid(1033220)
-- Game: addappid(1033220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033221, 1, "ef15a615911e7bc3b392a3589b501dc51a082039fecb53a1a5728ebcf2f129ed")
