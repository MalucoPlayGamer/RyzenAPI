-- Lua provided by SkyAPI 
-- Game: AppID 1211080
addappid(1211080)
addappid(1211081, 1, "954e9e0cd250f181cfd3efa9d4fd3abb9b75d2958d40e706a2ef622764a02458")
