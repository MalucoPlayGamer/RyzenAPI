-- Lua provided by RyzenAPI
-- Game: Paint the Town Red Soundtrack

-- MAIN APPLICATION
addappid(1703630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703631, 1, "d6f6f177c6b10b9575b1f8286ff53ce59b8f2fd75c1e20afcaa644c2fc2ae983")
addappid(1703632, 1, "d50a267d8f8e525b838db3e410e8ac1fa6719ac4770c9abb3a3bc3f3bf5a6f62")

