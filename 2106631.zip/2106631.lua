-- Lua provided by RyzenAPI
-- Game: 2106631

-- MAIN APPLICATION
addappid(2106631)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109000,0,"9943dec535fa5d2ed7f56d0daa091119f18edef440e5cd925bbdfd893753eee6")
addappid(2109001,0,"ae762ec59270fa75e3126c763edc2aa0df1f93f4967da6d9d1d957dcc573ddc7")

