-- Lua provided by RyzenAPI
-- Game: AppID 224420

-- MAIN APPLICATION
addappid(224420)

-- MAIN APP DEPOTS / PACKAGES
addappid(224421, 1, "1b9d91427298e15a4151d204738b61cd90f1f5aa512f5e7911958bf3f2ca6b5d")
addappid(224422, 1, "1a59fc848861578467b8f92d523ee53f42036fdc1ae69cbce4ffb2f401b2dd4f")
addappid(224423, 1, "5983691315c2669a72a555ef24ab70a951730545fbd26ab9ba8cdabddaab728b")
addappid(224424, 1, "26ab881df7d90d07bd635741e2689f439adf17383ad93b21d990cca4f9c9e550")
addappid(224425, 1, "02c20f9d145b38eed4bf90cb11552afa25478d806c84242ca2d31320829c32d1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(233010)
