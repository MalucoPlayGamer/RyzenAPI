-- Lua provided by RyzenAPI
-- Game: The Last Companion

-- MAIN APPLICATION
addappid(1110720)
addappid(1175820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110721, 1, "c7999753970ad34f7379b4917de34e2bafcdcbfefcfd78f6370f83b9b3ad0588")
