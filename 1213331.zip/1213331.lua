-- Lua provided by RyzenAPI
-- Game: 1213331

-- MAIN APPLICATION
addappid(1213331)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213331,0,"57ce3c465db5fa9c9818e4d2dd6f2d9be899072b329c26cf38b9af18aa7f186f")
