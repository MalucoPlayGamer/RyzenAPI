-- Lua provided by RyzenAPI
-- Game: Car Manufacture Demo

-- MAIN APPLICATION
addappid(1760610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760611, 1, "281b0f939d6b4e9e1b4e9c520900be123b814401e982afdf0710cd613bd099dd")
