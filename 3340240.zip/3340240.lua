-- Lua provided by RyzenAPI
-- Game: LINGKARAN：リンカラン

-- MAIN APPLICATION
addappid(3340240)
-- Game: addappid(3340240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340241, 1, "7a8c031d9766ca7228ab07eab92a0204323369dc39924e82da2ba7bc3313a241")
