-- Lua provided by RyzenAPI
-- Game: Everybody's Gone to the Rapture

-- MAIN APPLICATION
addappid(417880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(417881, 1, "9b6cbc83069b2be57078184b482130c16a1e23d015513740f8d68d808f2edfca")

