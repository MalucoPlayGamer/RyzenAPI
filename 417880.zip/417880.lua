-- Lua provided by RyzenAPI
-- Game: Everybody's Gone to the Rapture

-- MAIN APPLICATION
addappid(417880)

-- MAIN APP DEPOTS / PACKAGES
addappid(417881, 1, "9b6cbc83069b2be57078184b482130c16a1e23d015513740f8d68d808f2edfca")
