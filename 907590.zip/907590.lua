-- Lua provided by RyzenAPI 
-- Game: AppID 907590
addappid(907590)
addappid(907591, 1, "9ec9939728deb4e0635145ea51862a3f590ada848b2cd0c673765864ccd163c1")
