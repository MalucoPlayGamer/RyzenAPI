-- Lua provided by RyzenAPI
-- Game: Data mining

-- MAIN APPLICATION
addappid(907590)

-- MAIN APP DEPOTS / PACKAGES
addappid(907591, 1, "9ec9939728deb4e0635145ea51862a3f590ada848b2cd0c673765864ccd163c1")
