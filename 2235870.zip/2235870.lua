-- Lua provided by RyzenAPI
-- Game: Purrrifiers - Friend's Pass

-- MAIN APPLICATION
addappid(2235870)
-- Game: addappid(2235870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235871, 1, "fa5a0853b6e4b260aafa19955a5a027aaa711ccc37bdad10bf325e17613035b4")
