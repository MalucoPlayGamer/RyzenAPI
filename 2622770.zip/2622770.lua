-- Lua provided by RyzenAPI
-- Game: Game: In Fair Spirits

-- MAIN APPLICATION
addappid(2622770)
-- Game: addappid(2622770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622771, 1, "e3839ea664c36a80aef5ca3626aeb833ce9c3df04b5943519cd3ec26f3610b9a")
