-- Lua provided by RyzenAPI
-- Game: Wizdom Academy

-- MAIN APPLICATION
addappid(2668000)
addappid(3679700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668001, 1, "3dd1c855b7c0bb401b866d7c25733268d3d4cb89542df6a8dc98910a67c60484")
