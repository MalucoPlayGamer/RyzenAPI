-- Lua provided by RyzenAPI
-- Game: Game: AppID 2474140

-- MAIN APPLICATION
addappid(2474140)
-- Game: addappid(2474140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474141, 1, "46fd38fb66965afe67f6748f506e43283b7732169a28e5ca9d58ef709994db60")
