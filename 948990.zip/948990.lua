-- Lua provided by RyzenAPI
-- Game: Grottesco Absurdus

-- MAIN APPLICATION
addappid(948990)

-- MAIN APP DEPOTS / PACKAGES
addappid(948991, 1, "c7fdf2d80ebcb330ad4c89436eac7f6b2d2149a8554ab4847439802546818d0c")
