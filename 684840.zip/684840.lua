-- Lua provided by RyzenAPI
-- Game: AppID 684840

-- MAIN APPLICATION
addappid(684840)

-- MAIN APP DEPOTS / PACKAGES
addappid(684841, 1, "ced6a49f7c34a43ca1d3782fe79e8d8507167dd452c42d6cfee38f9103619dca")

