-- Lua provided by RyzenAPI
-- Game: Death in the Family

-- MAIN APPLICATION
addappid(1762830)
-- Game: addappid(1762830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762831, 1, "408d524f10a05cef62ce817bb4d8b764bd31da0cd6b9f0efe9c25542eb5bfa59")
