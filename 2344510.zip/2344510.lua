-- Lua provided by RyzenAPI
-- Game: Pineapple on pizza Soundtrack

-- MAIN APPLICATION
addappid(2344510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344511, 1, "b2db9923dd24cb7aba13734c309e11b7e0f1b5eed9c12767dc93c15673cfec87")
