-- Lua provided by RyzenAPI
-- Game: Bird Watcher

-- MAIN APPLICATION
addappid(772990)

-- MAIN APP DEPOTS / PACKAGES
addappid(772991,0,"e745a582113e477c63a707df56d729ffb5201638e4a39e9185a57a1c31381ff3")

