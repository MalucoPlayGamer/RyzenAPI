-- Lua provided by RyzenAPI
-- Game: 2486810

-- MAIN APPLICATION
addappid(2486810)
addappid(3418790)
-- Game: addappid(2486810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486811, 1, "2192003476d53cf412632dcbb66e1b56c5c94c75f8f52df905dbb9af15be4786")
