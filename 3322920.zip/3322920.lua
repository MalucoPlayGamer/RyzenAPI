-- Lua provided by RyzenAPI
-- Game: Game: HIBE STUDIO: Interactive Live Streaming For Gamers & Vtubers

-- MAIN APPLICATION
addappid(3322920)
-- Game: addappid(3322920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3322921, 1, "03697948961e416f7673f266dcd1f8426f37c6251a6d236806c1fcb10e05f919")
