-- Lua provided by SkyAPI 
-- Game: Incubus Quest
addappid(2429890)
addappid(2429891, 1, "76dd8db80eba3bc525ff44ab1462dec969b01a37b9b9961b7ac9422ada77b952")
addappid(2429892, 1, "43bace3eb3e558886863ea0decf1f07a00dfdecaf0928e5430173b21e4b39b80")
addappid(2429893, 1, "8f0a9d5d6dba91f2504336a48e2b55bd7f92cd9f631dc1f8599359b69081eb36")
