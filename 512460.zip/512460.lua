-- Lua provided by RyzenAPI
-- Game: Nature And Life - Drunk On Nectar

-- MAIN APPLICATION
addappid(512460)
addappid(4465660)
addappid(4552130)
addappid(4552470)

-- MAIN APP DEPOTS / PACKAGES
addappid(512461, 1, "40c7e672d2a785fc780013f4d47ef85cfca018ce287ee1929b8cb1c271a0e827")
