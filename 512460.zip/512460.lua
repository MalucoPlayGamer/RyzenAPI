-- Lua provided by RyzenAPI
-- Game: AppID 512460

-- MAIN APPLICATION
addappid(512460)

-- MAIN APP DEPOTS / PACKAGES
addappid(512461, 1, "40c7e672d2a785fc780013f4d47ef85cfca018ce287ee1929b8cb1c271a0e827")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4465660)
addappid(4552130)
addappid(4552470)
