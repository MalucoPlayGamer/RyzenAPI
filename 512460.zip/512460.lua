-- Lua provided by RyzenAPI 
-- Game: AppID 512460
addappid(512460)
addappid(512461, 1, "40c7e672d2a785fc780013f4d47ef85cfca018ce287ee1929b8cb1c271a0e827")
