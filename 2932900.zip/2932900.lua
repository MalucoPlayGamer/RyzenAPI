-- Lua provided by RyzenAPI
-- Game: Acre Crisis

-- MAIN APPLICATION
addappid(2932900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932901,0,"74ed6f22882dfe79e8995e5fd73f27ac4b25f5363ff96eea29e79cd3fa0b05af")

