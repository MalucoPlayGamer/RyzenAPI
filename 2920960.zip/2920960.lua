-- Lua provided by RyzenAPI
-- Game: Game: Before I Go Demo

-- MAIN APPLICATION
addappid(2920960)
-- Game: addappid(2920960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920961, 1, "5d97f89c91f468ad6aeb3b6e2e8ef091db7888e3c684ba1ba9fccbb0b56495aa")
