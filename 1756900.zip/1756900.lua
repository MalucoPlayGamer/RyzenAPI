-- Lua provided by RyzenAPI 
-- Game: Shoot!
addappid(1756900)
addappid(1756901, 1, "8104248b67f09992b5cc6f3399d2a70f2fb88f9047fdf1a1f9e27626d4c879e6")
