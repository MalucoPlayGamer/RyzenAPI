-- Lua provided by RyzenAPI
-- Game: Oh My Wrench

-- MAIN APPLICATION
addappid(3336280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3336281, 1, "e00278505ec5fe0aaba2acf39f39f2fef16681193647f81eb33f5b45396ecd95")
addappid(3336282, 1, "48df49af2dcacaa26baa66fb2ca54a31ea641e108ca390a07ef1e7112de75d9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
