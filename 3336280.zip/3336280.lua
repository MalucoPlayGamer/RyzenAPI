-- Lua provided by RyzenAPI
-- Game: Oh My Wrench

-- MAIN APPLICATION
addappid(3336280)
-- Game: addappid(3336280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3336281, 1, "e00278505ec5fe0aaba2acf39f39f2fef16681193647f81eb33f5b45396ecd95")
addappid(3336282, 1, "48df49af2dcacaa26baa66fb2ca54a31ea641e108ca390a07ef1e7112de75d9f")
