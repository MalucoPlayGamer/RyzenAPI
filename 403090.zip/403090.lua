-- Lua provided by RyzenAPI
-- Game: Rescue Team 2

-- MAIN APPLICATION
addappid(403090)

-- MAIN APP DEPOTS / PACKAGES
addappid(403091, 1, "092126992911fbb30a4afbe230d6389c2b1bf22eb7622c4c9503f9bb8181ef6d")
