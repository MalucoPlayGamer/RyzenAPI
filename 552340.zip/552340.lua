-- Lua provided by RyzenAPI
-- Game: Danger Room

-- MAIN APPLICATION
addappid(552340)

-- MAIN APP DEPOTS / PACKAGES
addappid(552341,0,"d235ed0dd14b14bba0f127c9dac8646afa9faab1584970039f38ece6e032a283")

