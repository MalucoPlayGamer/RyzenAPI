-- Lua provided by RyzenAPI
-- Game: NBA 2K24

-- MAIN APPLICATION
addappid(2338770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338771, 1, "fccdfbb689cd6d6d8c67f7d748c81e0171e74c1fa072643d2ce27d439a871065")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2413250)
addappid(2413251)
addappid(2413260)
addappid(2413261)
addappid(2413262)
addappid(2413263)
addappid(2413264)
addappid(2413265)
addappid(2413266)
addappid(2413267)
addappid(2413268)
addappid(2413269)
addappid(2413270)
addappid(2413271)
addappid(2413272)
addappid(2413273)
addappid(2413274)
addappid(2413275)
addappid(2514210)
addappid(2514220)
addappid(2514230)
addappid(2514240)
