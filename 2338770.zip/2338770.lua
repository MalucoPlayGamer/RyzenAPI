-- Lua provided by RyzenAPI
-- Game: NBA 2K24

-- MAIN APPLICATION
addappid(2338770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338771, 1, "fccdfbb689cd6d6d8c67f7d748c81e0171e74c1fa072643d2ce27d439a871065")

