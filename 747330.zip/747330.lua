-- Lua provided by RyzenAPI
-- Game: The adventure of Kroos

-- MAIN APPLICATION
addappid(747330)

-- MAIN APP DEPOTS / PACKAGES
addappid(747331,0,"19a88af7c1e87be1f6f2776b36d66377dc87a6436f07bc6fd19438d7a190ea8b")

