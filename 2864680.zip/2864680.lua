-- Lua provided by RyzenAPI 
-- Game: Diatomic
addappid(2864680)
addappid(2864681, 1, "f1e729a676738cf4e08cc46a6b2d3dea5a2086d394f0eb5fbd9140398c3f3d9d")
