-- Lua provided by RyzenAPI
-- Game: Game: Crow Country Demo

-- MAIN APPLICATION
addappid(2556780)
-- Game: addappid(2556780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556781, 1, "519094aed878c5a394fbeb128e8b54744ff77c54b389032029245edbc2345a99")
