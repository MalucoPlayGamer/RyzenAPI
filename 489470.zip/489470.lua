-- Lua provided by RyzenAPI
-- Game: addappid(489470)

-- MAIN APPLICATION
addappid(489470)

-- MAIN APP DEPOTS / PACKAGES
addappid(489471, 1, "6af8235801adcfbfba32f51fd0cdf27f450f7a44333e914d73fd89e4d248ad51")
