-- Lua provided by RyzenAPI
-- Game: 1187020

-- MAIN APPLICATION
addappid(1187020)
-- Game: addappid(1187020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187021, 1, "bffc60ffcd69a6d3bf7fa94527f9ce1f1acf787311e23f2d9ec53efb2aad9935")
