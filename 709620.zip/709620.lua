-- Lua provided by RyzenAPI
-- Game: Squareboy vs Bullies: Arena Edition

-- MAIN APPLICATION
addappid(709620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(709621, 1, "a1c74ce4486eafa7c275aa9e67803c04894f7d5b2e848a3f85dfbc76e0569403")
