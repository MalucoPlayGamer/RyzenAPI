-- Lua provided by RyzenAPI
-- Game: AppID 709620

-- MAIN APPLICATION
addappid(709620)
-- Game: addappid(709620)

-- MAIN APP DEPOTS / PACKAGES
addappid(709621, 1, "a1c74ce4486eafa7c275aa9e67803c04894f7d5b2e848a3f85dfbc76e0569403")
