-- Lua provided by RyzenAPI
-- Game: The King Got Too Much Gold

-- MAIN APPLICATION
addappid(4839430) -- The King Got Too Much Gold

-- MAIN APP DEPOTS / PACKAGES
addappid(4839431, 1, "f185ffa0033d73cf050fb732944707a70df87dd89c934530a053875d8a1963e7") -- Depot 4839431
