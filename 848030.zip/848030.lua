-- Lua provided by RyzenAPI
-- Game: AppID 848030

-- MAIN APPLICATION
addappid(848030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(848031, 1, "27d54c8b2ef0a50753e507cccb69f32609d503e2f150c98f912665e94e50c61c")

