-- Lua provided by SkyAPI 
-- Game: AppID 848030
addappid(848030)
addappid(848031, 1, "27d54c8b2ef0a50753e507cccb69f32609d503e2f150c98f912665e94e50c61c")
