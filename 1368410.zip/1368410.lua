-- Lua provided by RyzenAPI 
-- Game: PSYCRON
addappid(1368410)
addappid(1368411, 1, "31ee476684d8f4b200164fbb869d36b49ab0ada2200324bcafda6725c06b210f")
