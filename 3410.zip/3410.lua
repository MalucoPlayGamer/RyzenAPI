-- Lua provided by RyzenAPI 
-- Game: Heavy Weapon Deluxe
addappid(3410)
addappid(3411, 1, "43a26b22a7833d442394111ed874fbd808ef0889910975a20f0dd7515438bc74")
