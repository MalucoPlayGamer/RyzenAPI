-- Lua provided by RyzenAPI
-- Game: Game: Heavy Weapon Deluxe

-- MAIN APPLICATION
addappid(3410)
-- Game: addappid(3410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411, 1, "43a26b22a7833d442394111ed874fbd808ef0889910975a20f0dd7515438bc74")
