-- 4251090's Lua and Manifest Created by Hubcap Manifest
-- Keep It Contained
-- Created: August 08, 2026 at 07:57:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4251090) -- Keep It Contained
-- MAIN APP DEPOTS
addappid(4251091, 1, "5a59a40c786ffe1e5fb0a1edee1d815ea360895b5305ca4bd659897650fb9409") -- Depot 4251091
setManifestid(4251091, "1447472234998781367", 3894691208)