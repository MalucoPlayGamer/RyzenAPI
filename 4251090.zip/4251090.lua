-- Lua provided by RyzenAPI
-- Game: Keep It Contained

-- MAIN APPLICATION
addappid(4251090) -- Keep It Contained

-- MAIN APP DEPOTS / PACKAGES
addappid(4251091, 1, "5a59a40c786ffe1e5fb0a1edee1d815ea360895b5305ca4bd659897650fb9409") -- Depot 4251091

