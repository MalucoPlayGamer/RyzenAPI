-- Lua provided by RyzenAPI
-- Game: 3087910

-- MAIN APPLICATION
addappid(3087910)
-- Game: addappid(3087910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087911, 1, "7395c056b2095389d3428492e5dc6b8ca7b9d8e374132ff56bb6c5b93a1eb4c0")
