-- Lua provided by RyzenAPI
-- Game: 1161330

-- MAIN APPLICATION
addappid(1161330)
addappid(1361140)
-- Game: addappid(1161330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161331, 1, "2fe3b37846a45d85ee7f071879ed4ecefaf97eeb7c00804dcdbfd6d6acc1af91")
addappid(1161332, 1, "228ee566da00e7f9e6ae30623d22d0ac7de7c5cab6611a0df04afabb09904df3")
addappid(1161333, 1, "73e28e13b6f7f6293eeddbd34031b2cbc2f5711cfda6c595a69771fc30ad5e14")
