-- Lua provided by RyzenAPI
-- Game: Fruit Juice

-- MAIN APPLICATION
addappid(1589040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589041, 1, "d80bc83c74944387ab25180f1e2341b15aee45ac93e8ff18817eb5cc60622b7b")

