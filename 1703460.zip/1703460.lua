-- Lua provided by RyzenAPI
-- Game: Game: Balls! Balls!

-- MAIN APPLICATION
addappid(1703460)
-- Game: addappid(1703460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703461, 1, "c5fb4d0170cd26091f386e23ef6df3aa38fed79a08d0f3f3d41c6d700c8e990e")
