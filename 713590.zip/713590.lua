-- Lua provided by RyzenAPI
-- Game: AppID 713590

-- MAIN APPLICATION
addappid(713590)
-- Game: addappid(713590)

-- MAIN APP DEPOTS / PACKAGES
addappid(713591, 1, "ad3f9a8e32e4a3d2ff190e99e7a8b039da353e6c11b9b61f8268b50f522a218f")
