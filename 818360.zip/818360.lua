-- Lua provided by RyzenAPI
-- Game: Wildbus

-- MAIN APPLICATION
addappid(818360)

-- MAIN APP DEPOTS / PACKAGES
addappid(818361, 1, "b70411a8313662da72f68216daab121a3c01cc0804c2bdaa2f4ebc98c5b17f7e")
