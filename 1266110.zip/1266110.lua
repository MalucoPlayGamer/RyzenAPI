-- Lua provided by RyzenAPI
-- Game: 1266110

-- MAIN APPLICATION
addappid(1266110)
-- Game: addappid(1266110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266111, 1, "bcd543667c8b6eaba445b8a3483bbda13670ccd2e2edef89a51e27d660874df1")
