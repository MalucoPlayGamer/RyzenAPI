-- Lua provided by RyzenAPI
-- Game: 606490

-- MAIN APPLICATION
addappid(606490)
-- Game: addappid(606490)

-- MAIN APP DEPOTS / PACKAGES
addappid(606491, 1, "085da11c84f059d8e67fb863556fb0224e528e03a2a2af583e473e0f98c79f76")
