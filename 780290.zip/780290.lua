-- Lua provided by RyzenAPI
-- Game: Gloomhaven

-- MAIN APPLICATION
addappid(780290)

-- MAIN APP DEPOTS / PACKAGES
addappid(780291, 1, "556d7497acead556deb456600974b551adc59260250f1973267ad37ae195d1a5")
addappid(780293, 1, "12f6ead505a8cbecc6ad3d247b35354e6c1e559719461616ca1411cf624f2e65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1809490)
addappid(1958560)
addappid(2584170)
