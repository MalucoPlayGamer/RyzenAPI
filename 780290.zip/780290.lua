-- Lua provided by RyzenAPI
-- Game: Game: Gloomhaven

-- MAIN APPLICATION
addappid(780290)
-- Game: addappid(780290)

-- MAIN APP DEPOTS / PACKAGES
addappid(780291, 1, "556d7497acead556deb456600974b551adc59260250f1973267ad37ae195d1a5")
addappid(780293, 1, "12f6ead505a8cbecc6ad3d247b35354e6c1e559719461616ca1411cf624f2e65")
