-- Lua provided by SkyAPI 
-- Game: Gloomhaven
addappid(780290)
addappid(780291, 1, "556d7497acead556deb456600974b551adc59260250f1973267ad37ae195d1a5")
addappid(780293, 1, "12f6ead505a8cbecc6ad3d247b35354e6c1e559719461616ca1411cf624f2e65")
