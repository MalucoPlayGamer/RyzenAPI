-- Lua provided by RyzenAPI
-- Game: addappid(3743430)

-- MAIN APPLICATION
addappid(3743430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3743431, 1, "c35ed33ce0802db08fb4bf3dc8baab65325617bece0dd7407e58fd7ee2ff4904")
addappid(3743750, 0, "f00ade6913ccdfd051d745d0f2c8c3680cb82f91f0eda8d23328885269c9af4d")
