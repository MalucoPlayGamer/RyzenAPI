-- Lua provided by RyzenAPI
-- Game: Boundary: Benchmark

-- MAIN APPLICATION
addappid(1420640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1420641, 1, "1c924542a09f6e6de6ff8fa85bdf8c454a4a523a1b210e512f0b490f75038d95")

