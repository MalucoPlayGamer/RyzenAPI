-- Lua provided by RyzenAPI
-- Game: Boundary: Benchmark

-- MAIN APPLICATION
addappid(1420640)
-- Game: addappid(1420640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420641, 1, "1c924542a09f6e6de6ff8fa85bdf8c454a4a523a1b210e512f0b490f75038d95")
