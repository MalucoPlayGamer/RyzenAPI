-- Lua provided by RyzenAPI
-- Game: Fishing Adventure VR

-- MAIN APPLICATION
addappid(1200220)
-- Game: addappid(1200220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200222,0,"78a11fb5a0645535e179dd2a44ae95054b90918a8960d386680d518814d115a2")
