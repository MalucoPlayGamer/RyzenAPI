-- Lua provided by RyzenAPI
-- Game: AV Director Life!

-- MAIN APPLICATION
addappid(3181220)
-- Game: addappid(3181220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181222,0,"5961bc414641c16c702484d3f4cf3766cf313190006888cd9b8e1896f174c2f0")
