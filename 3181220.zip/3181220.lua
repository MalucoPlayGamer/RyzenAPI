-- Lua provided by RyzenAPI
-- Game: AV Director Life!

-- MAIN APPLICATION
addappid(3181220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3181222,0,"5961bc414641c16c702484d3f4cf3766cf313190006888cd9b8e1896f174c2f0")

