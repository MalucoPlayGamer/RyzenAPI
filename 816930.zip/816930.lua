-- Lua provided by RyzenAPI
-- Game: Production Sound / 产声

-- MAIN APPLICATION
addappid(816930)
-- Game: addappid(816930)

-- MAIN APP DEPOTS / PACKAGES
addappid(816931, 1, "d4a1767e83fe28e7632d561a3c59f8309c3ec6930af6fcd073bd487848233a7e")
