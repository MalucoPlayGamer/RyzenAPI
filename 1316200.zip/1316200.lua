-- Lua provided by RyzenAPI
-- Game: House Sitter

-- MAIN APPLICATION
addappid(1316200)
-- Game: addappid(1316200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316201, 1, "69cb3c271b35fe6e07671fde694c3f5848e853712ff9f558b4420a5b4c41f2ef")
