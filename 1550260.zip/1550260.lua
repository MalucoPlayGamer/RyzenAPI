-- Lua provided by RyzenAPI
-- Game: BloodRayne Betrayal: Fresh Bites

-- MAIN APPLICATION
addappid(1550260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1550261, 1, "a78534d3959f9eb22deb76d4df06869128e67e33c2b3e94d4ba06c9c7c1301f1")

