-- Lua provided by RyzenAPI
-- Game: 1550260

-- MAIN APPLICATION
addappid(1550260)
-- Game: addappid(1550260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550261, 1, "a78534d3959f9eb22deb76d4df06869128e67e33c2b3e94d4ba06c9c7c1301f1")
