-- Lua provided by RyzenAPI
-- Game: 1263740

-- MAIN APPLICATION
addappid(1263740)
-- Game: addappid(1263740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263741, 1, "d7c25a558c01020d8bbcdc4e2c481bb240ef8ce7668359786560c027ad721242")
