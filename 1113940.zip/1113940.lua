-- Lua provided by RyzenAPI
-- Game: Electronic Super Joy 2

-- MAIN APPLICATION
addappid(1113940)
addappid(1121810)
addappid(1240750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113941,0,"649be9f71acef2c88f6aa789c3dbc0f6fc9a5acb5199c091a6a857df49a99635")
addappid(1113942,0,"0bf3610e02600d52f4ecdeab45ab9ee45dba451dd70d44a1ad090ee3e486c1ed")
addappid(1113943,0,"e60a3a7a1ceebd89e20582b592087908de0aef6ede4712c12c94e039911964bd")
addappid(1121810,0,"328c176fe0d5846c7de1d21edd3b02bca63cd29de771a04069750e7b519cd2e8")

