-- Lua provided by RyzenAPI
-- Game: Game: Mirror Chains

-- MAIN APPLICATION
addappid(2078460)
-- Game: addappid(2078460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078461, 1, "fc5be92a2f9936cf6ee46b57bcb72e8d9a32013976eaedfd2be7c3b754962881")
