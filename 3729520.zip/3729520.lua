-- Lua provided by RyzenAPI
-- Game: Gladiator Guild Manager – The Price of Glory (Comic Book)

-- MAIN APPLICATION
addappid(3729520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3729520,0,"009effc5ecee6e99fe2673f499a3fa7005096d469b82d6e19be8d46259e457e3")

