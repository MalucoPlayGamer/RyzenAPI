-- Lua provided by RyzenAPI
-- Game: addappid(3729520)

-- MAIN APPLICATION
addappid(3729520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3729520,0,"009effc5ecee6e99fe2673f499a3fa7005096d469b82d6e19be8d46259e457e3")
