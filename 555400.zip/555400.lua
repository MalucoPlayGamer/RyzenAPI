-- Lua provided by SkyAPI 
-- Game: Collision Course
addappid(555400)
addappid(555401, 1, "97f581f923b46e87eef87bbf0b1ccfa9b9ce8076136407005f890adae4195797")
