-- Lua provided by RyzenAPI
-- Game: Game: Collision Course

-- MAIN APPLICATION
addappid(555400)
-- Game: addappid(555400)

-- MAIN APP DEPOTS / PACKAGES
addappid(555401, 1, "97f581f923b46e87eef87bbf0b1ccfa9b9ce8076136407005f890adae4195797")
