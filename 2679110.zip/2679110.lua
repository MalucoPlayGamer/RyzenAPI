-- Lua provided by RyzenAPI 
-- Game: AppID 2679110
addappid(2679110)
addappid(2679111, 1, "c03ee93b6d112eec08ca485811c50dbe33d1c26bf8c5492a9262ff1b688016aa")
