-- Lua provided by RyzenAPI
-- Game: addappid(2679110)

-- MAIN APPLICATION
addappid(2679110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679111, 1, "c03ee93b6d112eec08ca485811c50dbe33d1c26bf8c5492a9262ff1b688016aa")
