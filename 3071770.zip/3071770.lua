-- Lua provided by RyzenAPI
-- Game: Midnight Shift

-- MAIN APPLICATION
addappid(3071770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071771,0,"948b19ed0b100161dd03a106736747671011f559f881a661c5a3b64c5e3cd7f9")

