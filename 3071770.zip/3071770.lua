-- Lua provided by RyzenAPI
-- Game: Midnight Shift

-- MAIN APPLICATION
addappid(3071770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071771,0,"948b19ed0b100161dd03a106736747671011f559f881a661c5a3b64c5e3cd7f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
