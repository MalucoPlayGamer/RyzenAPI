-- Lua provided by RyzenAPI
-- Game: 375930

-- MAIN APPLICATION
addappid(375930)
-- Game: addappid(375930)

-- MAIN APP DEPOTS / PACKAGES
addappid(375931, 1, "54e9aef36eddc2e64aead9a1759b75d1fe2a9e56d0e13566c4f98a2c3f2a4923")
