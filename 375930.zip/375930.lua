-- Lua provided by RyzenAPI
-- Game: Trap Them

-- MAIN APPLICATION
addappid(375930)

-- MAIN APP DEPOTS / PACKAGES
addappid(375931, 1, "54e9aef36eddc2e64aead9a1759b75d1fe2a9e56d0e13566c4f98a2c3f2a4923")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
