-- Lua provided by RyzenAPI
-- Game: The Day in a Life of a Dayfly

-- MAIN APPLICATION
addappid(3778680)

