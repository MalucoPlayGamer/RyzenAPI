-- Lua provided by RyzenAPI
-- Game: 715070

-- MAIN APPLICATION
addappid(715070)

-- MAIN APP DEPOTS / PACKAGES
addappid(715070,0,"a2e27df7b7c67efc00f7d547afe33167d60d2194e15fe6f89ab37fef7397b161")

