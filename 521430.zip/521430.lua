-- Lua provided by RyzenAPI 
-- Game: Super Switch
addappid(521430)
addappid(521431, 1, "781867add4d332f657d356c70abb8a3771efff7d196001aab0ac66983801c5d0")
