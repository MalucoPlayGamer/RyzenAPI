-- Lua provided by RyzenAPI
-- Game: Emi - Christmas Special

-- MAIN APPLICATION
addappid(2700910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700912,0,"b792e9edefecc8e54db5208ee2ec4ea924750b098d494bec911a483ede36a865")

