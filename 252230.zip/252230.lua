-- Lua provided by RyzenAPI
-- Game: AppID 252230

-- MAIN APPLICATION
addappid(252230)

-- MAIN APP DEPOTS / PACKAGES
addappid(252231, 1, "6b0244d1820746431ad37ffbf89c9097bd8cc1951694ac1b17fd2a8c3aeb5eb3")

