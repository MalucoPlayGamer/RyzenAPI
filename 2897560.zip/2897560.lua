-- Lua provided by RyzenAPI
-- Game: 刷啊刷

-- MAIN APPLICATION
addappid(2897560)
-- Game: addappid(2897560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897561, 1, "4f6800e63cab91f63f375f7981ae5a70f796eb3f3ca4a624a41d7b15279d000a")
