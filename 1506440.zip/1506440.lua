-- Lua provided by RyzenAPI
-- Game: 1506440

-- MAIN APPLICATION
addappid(1506440)
-- Game: addappid(1506440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506441, 1, "ca547e8b33bcb542e248a6c8d7dfd1c0a321de6d83c2514153c4ab413f4544b8")
addappid(2190550, 0, "eac11c81e65af970011b7cd011c49bd74eaa948b5b88725766d738f7ca41910f")
