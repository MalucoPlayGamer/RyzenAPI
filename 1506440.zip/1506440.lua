-- Lua provided by RyzenAPI
-- Game: Batora: Lost Haven

-- MAIN APPLICATION
addappid(1506440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1506441, 1, "ca547e8b33bcb542e248a6c8d7dfd1c0a321de6d83c2514153c4ab413f4544b8")
addappid(2190550, 0, "eac11c81e65af970011b7cd011c49bd74eaa948b5b88725766d738f7ca41910f")

