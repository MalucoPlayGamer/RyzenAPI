-- Lua provided by RyzenAPI
-- Game: AppID 2330850

-- MAIN APPLICATION
addappid(2330850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2330851, 1, "971b781263bbfed287463cb8f8916234ce7f68fbf29a3f945faa7c4303cc4c90")

