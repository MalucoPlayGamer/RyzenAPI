-- Lua provided by RyzenAPI
-- Game: Game: AppID 2330850

-- MAIN APPLICATION
addappid(2330850)
-- Game: addappid(2330850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330851, 1, "971b781263bbfed287463cb8f8916234ce7f68fbf29a3f945faa7c4303cc4c90")
