-- Lua provided by SkyAPI 
-- Game: AppID 2330850
addappid(2330850)
addappid(2330851, 1, "971b781263bbfed287463cb8f8916234ce7f68fbf29a3f945faa7c4303cc4c90")
