-- Lua provided by RyzenAPI
-- Game: Substance Painter 2019

-- MAIN APPLICATION
addappid(978680)
-- Game: addappid(978680)

-- MAIN APP DEPOTS / PACKAGES
addappid(978681, 1, "e287eb2034b0ee04f7bf69fbc6b5cf41f37e018eb2d6ed7be8c8666b0790294e")
