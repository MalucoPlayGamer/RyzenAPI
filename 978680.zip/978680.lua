-- Lua provided by RyzenAPI
-- Game: Substance Painter 2019

-- MAIN APPLICATION
addappid(978680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(978681, 1, "e287eb2034b0ee04f7bf69fbc6b5cf41f37e018eb2d6ed7be8c8666b0790294e")

