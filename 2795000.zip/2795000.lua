-- Lua provided by RyzenAPI
-- Game: The WereCleaner

-- MAIN APPLICATION
addappid(2795000)

