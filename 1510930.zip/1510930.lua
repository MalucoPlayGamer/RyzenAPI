-- Lua provided by RyzenAPI
-- Game: 1510930

-- MAIN APPLICATION
addappid(1510930)
-- Game: addappid(1510930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510932,0,"a9aa9919e2ba49cb5b86eccf8d4de68951400988d9afa0f6132348340dfab91b")
