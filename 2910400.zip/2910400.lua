-- Lua provided by RyzenAPI
-- Game: Elemental Novice

-- MAIN APPLICATION
addappid(2910400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910401, 1, "fbae3ad535f51242f045bfba93ce1332a66665c4d7d847e0f4f5b08b4a50192d")

