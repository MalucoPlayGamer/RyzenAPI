-- Lua provided by RyzenAPI
-- Game: Elemental Novice

-- MAIN APPLICATION
addappid(2910400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910401, 1, "fbae3ad535f51242f045bfba93ce1332a66665c4d7d847e0f4f5b08b4a50192d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
