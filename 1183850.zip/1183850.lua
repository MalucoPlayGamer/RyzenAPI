-- Lua provided by RyzenAPI
-- Game: AppID 1183850

-- MAIN APPLICATION
addappid(1183850)
-- Game: addappid(1183850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183851, 1, "c0ce2b458574a8225ce91291995fb4ca7134c53945d2fdc44fcff33811a209f1")
