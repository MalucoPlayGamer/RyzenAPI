-- Lua provided by RyzenAPI
-- Game: addappid(1967141)

-- MAIN APPLICATION
addappid(1967141)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967141,0,"0b160112340bb00e7333bd6144d1af8a2af10e6544fdd19bf3da7a71a685bcbe")
