-- 3975750's Lua and Manifest Created by Hubcap Manifest
-- The Gate Must Stand
-- Created: June 18, 2026 at 12:15:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3975750) -- The Gate Must Stand
addtoken(3975750, "12133288366030907655")
-- MAIN APP DEPOTS
addappid(3975751, 1, "4dda65677decba6d73b7cdcb0663e231f5014c04938815a294b4673744a64915") -- Depot 3975751
-- setManifestid(3975751, "373332865714740779", 2183780025)