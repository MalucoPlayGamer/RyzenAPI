-- Lua provided by RyzenAPI
-- Game: The Gate Must Stand

-- MAIN APPLICATION
addappid(3975750) -- The Gate Must Stand

-- MAIN APP DEPOTS / PACKAGES
addappid(3975751, 1, "4dda65677decba6d73b7cdcb0663e231f5014c04938815a294b4673744a64915") -- Depot 3975751
addtoken(3975750, "12133288366030907655")

