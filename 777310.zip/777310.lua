-- Lua provided by RyzenAPI
-- Game: Game: Battle Of Keys

-- MAIN APPLICATION
addappid(777310)
-- Game: addappid(777310)

-- MAIN APP DEPOTS / PACKAGES
addappid(777311, 1, "254722d28d4dda1d7de0f99896565b1c17ba890b868b9601992fc08f4bcb4493")
