-- Lua provided by RyzenAPI
-- Game: AppID 244870

-- MAIN APPLICATION
addappid(244870)

-- MAIN APP DEPOTS / PACKAGES
addappid(244871, 1, "34dac08f93dcbe61683d61c403125088913132f0bafadca66c3844790a1c5ccb")
addappid(244872, 1, "b8ddf57fd7ba5d35085ad0d6ae7de52c15f311a037b635d401498507f0b8eb84")
addappid(244873, 1, "8eb46c9fdab8bcc51491805d9a1ba2d45cd3ae50599c582d22a844db7f31c061")
addappid(244874, 1, "e5ef0aa443fd87166e37b48d29fc74b49ce733db9f887147ac9614724d291739")
addappid(244875, 1, "56953e900336a51e529c2670f80511c73f83005ea468e4abecaaa45762716897")
addappid(271400, 0, "e269a79ef9d742012d3b7bbb93e32638c2cfd53c80d7082d796d823d64ed9fe9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(317770)
