-- Lua provided by RyzenAPI
-- Game: Game: Princess Daphne and the Orcs

-- MAIN APPLICATION
addappid(1384330)
-- Game: addappid(1384330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384331, 1, "f7cf34a4a93addc4c03004aeca3e6c5327371d61b9adad5b3b6c955069d408a9")
addappid(1560190, 0, "7f3c2c378a62c82b456d2ae1cfaa4a84465b6ee5f8817666cc3644902a40edf4")
addappid(1560191, 0, "7da4449a0cc7ed9b3cce65b00bcf6f902c996570183f223052b2664b6eeef9b2")
addappid(1560192, 0, "3f1f77b5854ad290d3870a0a0ff28bdc7457a3ab9636844706bf83b905963839")
addappid(1560193, 0, "1fccb299124f2b333661c8f562db5aa166cddd3875d280abdc46fe8599388162")
