-- Lua provided by RyzenAPI
-- Game: Another Try 2

-- MAIN APPLICATION
addappid(2788040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788041, 1, "3f69ba9ea50c91ad5ef8da8f9f48a2ace93fd2e9884cb1a7b00666a3a81e0508")

