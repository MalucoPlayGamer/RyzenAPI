-- Lua provided by RyzenAPI
-- Game: Another Try 2

-- MAIN APPLICATION
addappid(2788040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2788041, 1, "3f69ba9ea50c91ad5ef8da8f9f48a2ace93fd2e9884cb1a7b00666a3a81e0508")

