-- Lua provided by RyzenAPI
-- Game: addappid(333760)

-- MAIN APPLICATION
addappid(333760)

-- MAIN APP DEPOTS / PACKAGES
addappid(333761, 1, "c21dfd1757190995a5f4039e3d42f62978ae72f9c5a3f4661cc807dc2e2a504a")
