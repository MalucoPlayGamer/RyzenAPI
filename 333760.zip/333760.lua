-- Lua provided by RyzenAPI
-- Game: Vintage Year

-- MAIN APPLICATION
addappid(333760)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(333761, 1, "c21dfd1757190995a5f4039e3d42f62978ae72f9c5a3f4661cc807dc2e2a504a")

