-- Lua provided by RyzenAPI
-- Game: The Black Pool

-- MAIN APPLICATION
addappid(2189670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189671, 1, "afd10f48bc4fbc58fb2d395ed077b9caa8bda667587d27eceddd5702de1ae9d3")

