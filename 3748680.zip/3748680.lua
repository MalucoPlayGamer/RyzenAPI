-- Lua provided by RyzenAPI
-- Game: addappid(3748680)

-- MAIN APPLICATION
addappid(3748680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3748681, 1, "cda2b02ab438ed5407e092cece439ba5feea3e6c849a739fc8f7b12feeaace30")
