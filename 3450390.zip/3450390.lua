-- Lua provided by RyzenAPI
-- Game: E.T.E

-- MAIN APPLICATION
addappid(3450390)
-- Game: addappid(3450390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3450391, 1, "4f1317153dca330343d47c1f3b8a69f5b3d743819787992db4c1add858ef9347")
