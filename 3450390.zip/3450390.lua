-- Lua provided by SkyAPI 
-- Game: E.T.E
addappid(3450390)
addappid(3450391, 1, "4f1317153dca330343d47c1f3b8a69f5b3d743819787992db4c1add858ef9347")
