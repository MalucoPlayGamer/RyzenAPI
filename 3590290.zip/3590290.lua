-- Lua provided by RyzenAPI
-- Game: DIVE or DIE Children of Rain

-- MAIN APPLICATION
addappid(3590290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3590291, 1, "e76788b1238e9150d3314de776f6b6527278284f95605c58cbe7af06036dc74b") -- Depot 3590291

