-- Lua provided by RyzenAPI
-- Game: Cibele

-- MAIN APPLICATION
addappid(408120)
addappid(414590)

-- MAIN APP DEPOTS / PACKAGES
addappid(408122,0,"d2eaf2dfbfb3efbb0fbd9da95ca2dc46d6de47d8db463886eed54b4ad0091fb4")
addappid(408123,0,"7244507187f5cd93be22e7175a38fe2c70b79452fb60f3cf191f6e6fdd122530")

