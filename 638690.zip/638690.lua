-- Lua provided by RyzenAPI
-- Game: addappid(638690)

-- MAIN APPLICATION
addappid(638690)

-- MAIN APP DEPOTS / PACKAGES
addappid(638691, 1, "6df6802363523f5ff8a7a3b6b64767c587ecf8d0e57fb1685a8f3327384d3712")
