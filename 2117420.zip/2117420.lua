-- Lua provided by SkyAPI 
-- Game: Prime Horror II
addappid(2117420)
addappid(2117421, 1, "384391f7186cc9c93b0b2c267a6ec995c56a1a28603e19e9b23ff3a14bede7be")
