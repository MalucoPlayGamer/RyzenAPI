-- Lua provided by RyzenAPI
-- Game: Prime Horror II

-- MAIN APPLICATION
addappid(2117420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117421, 1, "384391f7186cc9c93b0b2c267a6ec995c56a1a28603e19e9b23ff3a14bede7be")
