-- Lua provided by RyzenAPI
-- Game: Prime Horror II

-- MAIN APPLICATION
addappid(2117420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117421, 1, "384391f7186cc9c93b0b2c267a6ec995c56a1a28603e19e9b23ff3a14bede7be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
