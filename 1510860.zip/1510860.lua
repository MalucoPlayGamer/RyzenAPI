-- Lua provided by RyzenAPI
-- Game: Out of Sight

-- MAIN APPLICATION
addappid(1510860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510862,0,"15b75f5443a9826e61a556c737efedb8f1d9617513158fe0fe08b3aeb579d95d")

