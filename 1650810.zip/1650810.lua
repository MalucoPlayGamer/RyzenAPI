-- Lua provided by RyzenAPI
-- Game: Loopmancer

-- MAIN APPLICATION
addappid(1650810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650811, 1, "320d82338aaaaa9f587391d29251c3bc8cc8711b11b755a7d2e4c945f0ee1fb1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
