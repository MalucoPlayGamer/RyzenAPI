-- Lua provided by RyzenAPI
-- Game: Loopmancer

-- MAIN APPLICATION
addappid(1650810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650811, 1, "320d82338aaaaa9f587391d29251c3bc8cc8711b11b755a7d2e4c945f0ee1fb1")
