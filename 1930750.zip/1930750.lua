-- Lua provided by RyzenAPI
-- Game: 1930750

-- MAIN APPLICATION
addappid(228988)
addappid(1930750)
addappid(1930752)
addappid(1930755)
addappid(1930756)
-- Game: addappid(1930750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930753,0,"0e588e611a0bd4bdb3f55857122c7af914a0b0f223a3ccf776f4a82552d6ec8d")
addappid(1930754,0,"3e9d2ef6dd24d2cdfa78fbff5e646adaedc73207cc059707653dc88b69c38b15")
