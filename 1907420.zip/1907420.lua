-- Lua provided by SkyAPI 
-- Game: SEARCH ALL - MUSHROOMS
addappid(1907420)
addappid(1907421, 1, "c556d4ae599f6164187f4e8995e813ae97a32096bbefcf4e3c4a463ee44c3000")
