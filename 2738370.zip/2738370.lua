-- Lua provided by RyzenAPI
-- Game: Party Friends Demo

-- MAIN APPLICATION
addappid(2738370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738371, 1, "c1f862e313b196abe52ffe10017d95efda633edaf12f5ca17802976691c15459")
