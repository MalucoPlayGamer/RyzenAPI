-- Lua provided by RyzenAPI
-- Game: Realms of Arkania 2 - Star Trail Classic

-- MAIN APPLICATION
addappid(270750)

-- MAIN APP DEPOTS / PACKAGES
addappid(270751, 1, "d74c371c893a89eccce3433d113e4b5d7c5cb6a876f13fd00eeccf3d7794590d")
addappid(270752, 1, "74d6d52637cd0eae77db80c5dd7621c7fc90d9f56c7189574d264a47b9bb10a1")
addappid(270753, 1, "49c767d37675fdc5abaa8ed7066fd481a463235646bf35edca153bcd0d25cb51")
addappid(270754, 1, "8c0802f041c2f1ade8e89f028e011d256d49bd144f67291b08ec351a7924acf9")
addappid(270755, 1, "13f26f0b47e3cf1cd326409d550096e13447379ac2e3d6fe0cd443825b29df96")
addappid(270756, 1, "0bf662e8cf638e08920fb8dfde38393ffb9a44ddc17c2916786703523e796f43")
addappid(270757, 1, "facc61c84345b7e77bdaf27bbcee33bc1dbbc1e25c60ec9f0fc592dfc2c6da84")
