-- Lua provided by RyzenAPI
-- Game: Lazy Devil's game life /废宅魔王的幸福生活

-- MAIN APPLICATION
addappid(825410)

-- MAIN APP DEPOTS / PACKAGES
addappid(825411, 1, "db330d72c2849ec23324bec3a0f20acb673f1aa4b6132c04fe48474327c47041")
