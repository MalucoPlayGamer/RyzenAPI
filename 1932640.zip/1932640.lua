-- Lua provided by RyzenAPI 
-- Game: Suikoden I&II HD Remaster Gate Rune and Dunan Unification Wars
addappid(1932640)
addappid(1932641, 1, "8cbcc48378f983709b2bd2959cf190421f3e54c57008b7a1f81ba6bfd9aad886")
addappid(2148630)
