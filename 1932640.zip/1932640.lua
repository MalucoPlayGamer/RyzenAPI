-- Lua provided by RyzenAPI
-- Game: Game: Suikoden I&II HD Remaster Gate Rune and Dunan Unification Wars

-- MAIN APPLICATION
addappid(1932640)
addappid(2148630)
-- Game: addappid(1932640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932641, 1, "8cbcc48378f983709b2bd2959cf190421f3e54c57008b7a1f81ba6bfd9aad886")
