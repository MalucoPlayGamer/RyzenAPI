-- Lua provided by RyzenAPI
-- Game: 1019985

-- MAIN APPLICATION
addappid(1019985)
-- Game: addappid(1019985)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019985,0,"459a8b0cee68845f49ca08be9df76eaafd5f7c6daaecf2f1fb392099c485aca4")
