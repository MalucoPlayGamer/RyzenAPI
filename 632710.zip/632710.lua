-- Lua provided by RyzenAPI
-- Game: AppID 632710

-- MAIN APPLICATION
addappid(632710)
-- Game: addappid(632710)

-- MAIN APP DEPOTS / PACKAGES
addappid(632711, 1, "13530080863c21eca99320f7e2436e3023c9c0530ba5ecaafbf9649ba8f180cd")
