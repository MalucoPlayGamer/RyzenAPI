-- Lua provided by SkyAPI 
-- Game: SlavicPunk: Oldtimer
addappid(1820140)
addappid(1820141, 1, "c90779cca7e2f6f2c16f4716f2684af4e970214f2bb32b824c52108c165405a5")
