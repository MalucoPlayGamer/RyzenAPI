-- Lua provided by RyzenAPI
-- Game: SlavicPunk: Oldtimer

-- MAIN APPLICATION
addappid(1820140)
-- Game: addappid(1820140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820141, 1, "c90779cca7e2f6f2c16f4716f2684af4e970214f2bb32b824c52108c165405a5")
