-- Lua provided by RyzenAPI
-- Game: OrcinUS: Orca Pod Rescue

-- MAIN APPLICATION
addappid(2723270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723275,0,"df7eac7c18dba7c2a69929c083f3bc85202c0e09d712b5191767a913ad2790e0")

