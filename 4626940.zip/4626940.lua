-- Lua provided by RyzenAPI
-- Game: Scratch the Ticket

-- MAIN APPLICATION
addappid(4626940) -- Scratch the Ticket

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4626941, 1, "7432783b01898bdfc1970bdc0351ec130f3d79f76d599e592ab4493b55628c94") -- Depot 4626941

