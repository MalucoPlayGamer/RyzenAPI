-- Lua provided by RyzenAPI
-- Game: GRIDROAD

-- MAIN APPLICATION
addappid(2677310)
-- Game: addappid(2677310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677311, 1, "ce05f5daeb38532c2a8eb83987f455bfd13108f3bad4645d70f420428a28e6dc")
