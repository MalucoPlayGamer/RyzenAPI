-- Lua provided by RyzenAPI 
-- Game: ASMR Slicing
addappid(2841130)
addappid(2841131, 1, "61fadeb1649a3a776c4ea5e7c8df91944f9976b644a3b20ed022add2621b04f2")
