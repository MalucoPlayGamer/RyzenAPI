-- Lua provided by RyzenAPI
-- Game: Astebreed: Definitive Edition

-- MAIN APPLICATION
addappid(283680)

-- MAIN APP DEPOTS / PACKAGES
addappid(283681, 1, "7f6bf8bdaabd54b84f7cc819600e938825736736627d92ecfd174915f12a6dfe")
