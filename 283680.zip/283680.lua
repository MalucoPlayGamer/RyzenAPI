-- Lua provided by RyzenAPI
-- Game: Astebreed: Definitive Edition

-- MAIN APPLICATION
addappid(283680)

-- MAIN APP DEPOTS / PACKAGES
addappid(283681, 1, "7f6bf8bdaabd54b84f7cc819600e938825736736627d92ecfd174915f12a6dfe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
