-- Lua provided by RyzenAPI
-- Game: Game: Ghost Castle

-- MAIN APPLICATION
addappid(1892410)
-- Game: addappid(1892410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892411, 1, "aa56d817f64fc662393131a543c0069855b1b4c9919dc96a08957c37587b612e")
