-- Lua provided by SkyAPI 
-- Game: Ghost Castle
addappid(1892410)
addappid(1892411, 1, "aa56d817f64fc662393131a543c0069855b1b4c9919dc96a08957c37587b612e")
