-- Lua provided by RyzenAPI 
-- Game: Blair Witch
addappid(1092660)
addappid(1092661, 1, "59cdb3684096d4b28b71d4110325106d934d393edb803d6becbcbe8229849c2a")
addappid(1141710, 0, "dcc5cfa6fd9395d86a57b093ab819f127ebbc7672b685b7bae6dd8122fe1ca97")
addappid(1141711, 0, "15c710f9a66b05cab51e142a8273a08015ea27b8a885087c03293c63dd37cf9e")
