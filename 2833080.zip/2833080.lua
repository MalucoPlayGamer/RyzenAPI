-- Lua provided by RyzenAPI
-- Game: 2833080

-- MAIN APPLICATION
addappid(2833080)
-- Game: addappid(2833080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833084,0,"6a0ded985ef7ce3c6dc1656a979ae861de49969a377d7e286d3c3c24292fb0a9")
