-- Lua provided by RyzenAPI
-- Game: Chilie Peppers

-- MAIN APPLICATION
addappid(779770)

-- MAIN APP DEPOTS / PACKAGES
addappid(779771, 1, "390ddeb6c2b380dd7d49fa9d4855c597c1c72394b68bbb94391ba32459e11f95")
