-- Lua provided by RyzenAPI
-- Game: Slav Junkie Simulator

-- MAIN APPLICATION
addappid(2631500)
-- Game: addappid(2631500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631501, 1, "e7a2ca69252a8ab208c5a209266ed85ea8e08d7e4b969cbb10c502157ba471fc")
