-- Lua provided by RyzenAPI
-- Game: AppID 1133690

-- MAIN APPLICATION
addappid(1133690)
-- Game: addappid(1133690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133691, 1, "cf739ce8ef32577791c95614f0244ed7a4718c20a68b37523b755ae6bfc252a0")
