-- Lua provided by RyzenAPI
-- Game: Time Carnage

-- MAIN APPLICATION
addappid(912650)

-- MAIN APP DEPOTS / PACKAGES
addappid(912651, 1, "7a986639a9eaa757647c569a3978c6ee5ff93ad629199bc32281c3d218d32fcd")
addappid(912652, 1, "a6f0fec13fc93e1e462b425a13f801ea4dd97359ce43f40b1ff98485ca916047")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
