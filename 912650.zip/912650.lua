-- Lua provided by RyzenAPI
-- Game: Game: Time Carnage

-- MAIN APPLICATION
addappid(912650)
-- Game: addappid(912650)

-- MAIN APP DEPOTS / PACKAGES
addappid(912651, 1, "7a986639a9eaa757647c569a3978c6ee5ff93ad629199bc32281c3d218d32fcd")
addappid(912652, 1, "a6f0fec13fc93e1e462b425a13f801ea4dd97359ce43f40b1ff98485ca916047")
