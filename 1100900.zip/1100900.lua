-- Lua provided by RyzenAPI 
-- Game: Artifact Adventure Gaiden DX
addappid(1100900)
addappid(1100901, 1, "46036a5e87c8cd3e7bc749a108b4caa5bce5f9f6c4da1221d8c247e393302d6c")
