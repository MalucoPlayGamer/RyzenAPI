-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9 Empires - Unisex Custom Azure Dragon Armor Set

-- MAIN APPLICATION
addappid(1684148)
-- Game: addappid(1684148)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684148,0,"7bd8440b3fc203d0d0a95cbfc0ef5f4393706b4439a5533833200e83d3d8cc86")
