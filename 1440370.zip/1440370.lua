-- Lua provided by RyzenAPI
-- Game: Game: Before Dark

-- MAIN APPLICATION
addappid(1440370)
-- Game: addappid(1440370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440371, 1, "2304f10b328f1252e0ab196ad454b872f482e33070d76ab67a6362b01cc57246")
