-- Lua provided by RyzenAPI
-- Game: addappid(2070440)

-- MAIN APPLICATION
addappid(2070440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070441, 1, "1dca56befbcb30a1124f55af767839f13ef0d3bca23b7e6c5b1cc2eaf70109c2")
