-- Lua provided by RyzenAPI
-- Game: 2517810

-- MAIN APPLICATION
addappid(2517810)
-- Game: addappid(2517810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517811, 1, "0281dca6c56f2c6ffceb74ee7f5745213bc69079953534a9d104a8bd64545484")
