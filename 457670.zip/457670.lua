-- Lua provided by RyzenAPI
-- Game: Vrideo

-- MAIN APPLICATION
addappid(457670)

-- MAIN APP DEPOTS / PACKAGES
addappid(457671, 1, "850321f4aba6eb668baa8fa8cf904f689326923f395171b2f2006f9c44a21e46")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
