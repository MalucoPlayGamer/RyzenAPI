-- Lua provided by RyzenAPI 
-- Game: Vrideo
addappid(457670)
addappid(457671, 1, "850321f4aba6eb668baa8fa8cf904f689326923f395171b2f2006f9c44a21e46")
