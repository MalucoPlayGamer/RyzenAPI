-- Lua provided by RyzenAPI
-- Game: Workplace Fantasy - New Girl Chapter

-- MAIN APPLICATION
addappid(2626390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626390,0,"4f84453ae42b864391def14a64ea4d671247a7901028bfd862caa3696ef944e9")

