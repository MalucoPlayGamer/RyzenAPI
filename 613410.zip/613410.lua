-- Lua provided by RyzenAPI
-- Game: Delphinia Chronicle

-- MAIN APPLICATION
addappid(613410)
addappid(615981)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(613411, 1, "a84304d9a6fd2bac5b575a0d807a736427e45b559a9e0cfd15d523aac4c37b5f")

