-- Lua provided by RyzenAPI
-- Game: Delphinia Chronicle

-- MAIN APPLICATION
addappid(613410)
addappid(615981)

-- MAIN APP DEPOTS / PACKAGES
addappid(613411, 1, "a84304d9a6fd2bac5b575a0d807a736427e45b559a9e0cfd15d523aac4c37b5f")
