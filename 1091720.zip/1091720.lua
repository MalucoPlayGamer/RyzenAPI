-- Lua provided by RyzenAPI
-- Game: 叙事曲：难忘的回忆 / Ballade: with Memories

-- MAIN APPLICATION
addappid(228987)
addappid(1091720)
addappid(1091721)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091722,0,"c2aa559463e4c2e8d2101d6241337556f51ee7ec53ee820bd4a777fd036dba53")
addappid(1092200,0,"b8511e62ec9980f2112657e03619007d679d6cd8a5f099710a6a20fb4e13e125")

