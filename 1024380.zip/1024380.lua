-- Lua provided by RyzenAPI
-- Game: Second Extinction™

-- MAIN APPLICATION
addappid(1024380)
addappid(1414350)
addappid(1414351)
addappid(1414352)
addappid(1414353)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024381,0,"6af0fd07101ec6ffc837645d413cdce5b0f5170ddc3363b882007e346ee24b8b")

