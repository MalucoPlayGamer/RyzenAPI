-- Lua provided by RyzenAPI
-- Game: Second Extinction™

-- MAIN APPLICATION
addappid(1024380)
addappid(1414350)
addappid(1414351)
addappid(1414352)
addappid(1414353)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024381,0,"6af0fd07101ec6ffc837645d413cdce5b0f5170ddc3363b882007e346ee24b8b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
