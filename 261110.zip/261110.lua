-- Lua provided by RyzenAPI
-- Game: Killer is Dead - Nightmare Edition

-- MAIN APPLICATION
addappid(261110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(261111, 1, "ff9740958a5c5a4a40e1bb7c34ebccb7118231fac738cdfb22ad5cfc7daabb3a")
addappid(261112, 1, "9c67bd4ee7cf816411e75721ce8452d8c584f276cad8cc1fdf5b1988314e3c23")

