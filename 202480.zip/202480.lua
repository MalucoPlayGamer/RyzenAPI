-- Lua provided by RyzenAPI
-- Game: addappid(202480)

-- MAIN APPLICATION
addappid(202480)

-- MAIN APP DEPOTS / PACKAGES
addappid(202481, 1, "b224a4cc74e24aae7e56b4cc75500b00a8c5dd8f58758f14c62706381f321c69")
