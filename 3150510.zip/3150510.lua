-- Lua provided by RyzenAPI
-- Game: Game: Humiliation Dungeon Survivors

-- MAIN APPLICATION
addappid(3150510)
-- Game: addappid(3150510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150511, 1, "34066e9be5c399ebc44d8488519085f85c7b7f38a150a9d109841b6099f9823b")
