-- Lua provided by RyzenAPI 
-- Game: AppID 3390940
addappid(3390940)
addappid(3390941, 1, "7ddf685675ecf7dc61525e3762cca2b1dc57e67a6d74f4d7fb6a49e4949a37f2")
addappid(3390942, 1, "6e83912877e570fc0a442712b9b1292feb23b0ce7ada5d9fc2f0d35b1b1ee31d")
addappid(3390943, 1, "c8cc8adf60f6285e6aeff4c6bd5083409993c07ad86a65fcd3257fb017eaae88")
addappid(3390944, 1, "3fb0f3e1a0401bb39b13bd2d3fbec566b666b1bb3aca1f80df4f359aa04d2215")
