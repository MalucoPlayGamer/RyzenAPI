-- Lua provided by RyzenAPI
-- Game: 镜花饴情 Mirage Sugar Acacia

-- MAIN APPLICATION
addappid(2404110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404111, 1, "d28b5fa51345adcb428d77be6659a7c045d63ff95a5843c992771e05446986c4")
