-- Lua provided by RyzenAPI
-- Game: Game: Naughty Store Manager

-- MAIN APPLICATION
addappid(3389290)
-- Game: addappid(3389290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389291, 1, "333c9a9fe0841737fda0d3de543f7f0d87cee426b8462f71bd6977de4809b63d")
