-- Lua provided by RyzenAPI
-- Game: addappid(2111840)

-- MAIN APPLICATION
addappid(2111840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111840,0,"7c2a49faf9e0831972d5a40694f9cf153dc44c25214bef13a8a56f09cac3ef6b")
