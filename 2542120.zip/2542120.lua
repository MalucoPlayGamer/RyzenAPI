-- Lua provided by RyzenAPI
-- Game: addappid(2542120)

-- MAIN APPLICATION
addappid(2542120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542121, 1, "ddd21357db67ee08b9fe146fe995760876a9fd89db8fd7e4389a982f7d28cf14")
