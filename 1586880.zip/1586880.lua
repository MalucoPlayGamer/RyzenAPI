-- Lua provided by RyzenAPI
-- Game: Game: Essays on Empathy

-- MAIN APPLICATION
addappid(1586880)
-- Game: addappid(1586880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586881, 1, "764ed9aa4051b5e9b7b650b78eb2381292054aeaeb134eefa9a92fb8210dc351")
