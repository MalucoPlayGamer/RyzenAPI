-- Lua provided by RyzenAPI
-- Game: Hunted

-- MAIN APPLICATION
addappid(1765060)
addappid(2181650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1765061, 1, "cffca6c6a765b039c2509569bf7d923c05c4692747fc6a4fd98ba484209aa754")
addappid(1765062, 1, "9cf79a7ad004dd8e7a9146124c8692874f05d4746be71c1c8076a5200497a8ed")

