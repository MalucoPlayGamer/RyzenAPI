-- Lua provided by RyzenAPI
-- Game: Game: Hunted

-- MAIN APPLICATION
addappid(1765060)
-- Game: addappid(1765060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765061, 1, "cffca6c6a765b039c2509569bf7d923c05c4692747fc6a4fd98ba484209aa754")
addappid(1765062, 1, "9cf79a7ad004dd8e7a9146124c8692874f05d4746be71c1c8076a5200497a8ed")
