-- Lua provided by RyzenAPI
-- Game: Game: AppID 1987130

-- MAIN APPLICATION
addappid(1987130)
-- Game: addappid(1987130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987131, 1, "b8f2499b083b18310d64bd98e82b259f65615802548adf48c0652afb8ed5197d")
