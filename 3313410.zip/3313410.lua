-- Lua provided by RyzenAPI
-- Game: 刻印战记1：法利兹传

-- MAIN APPLICATION
addappid(3313410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313411, 1, "28029911b40fefbac8174cd11e934fc3da3c6616c88685170ce5fea9c97c5868")

