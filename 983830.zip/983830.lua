-- Lua provided by SkyAPI 
-- Game: Rogue
addappid(983830)
addappid(983831, 1, "76116713705d3b7fafcb6867aeb1f88b3366d5ed06864c657de90efe1d03bb8b")
