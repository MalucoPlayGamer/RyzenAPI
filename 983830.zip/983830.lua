-- Lua provided by RyzenAPI
-- Game: Rogue

-- MAIN APPLICATION
addappid(983830)

-- MAIN APP DEPOTS / PACKAGES
addappid(983831, 1, "76116713705d3b7fafcb6867aeb1f88b3366d5ed06864c657de90efe1d03bb8b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
