-- Lua provided by RyzenAPI
-- Game: Game: Orbital Racer

-- MAIN APPLICATION
addappid(723100)
-- Game: addappid(723100)

-- MAIN APP DEPOTS / PACKAGES
addappid(723101, 1, "4b11ed9a069f437077c16a404577928723d4763f5e215c15999c7cd9f1c48fd0")
