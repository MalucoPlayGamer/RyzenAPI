-- Lua provided by SkyAPI 
-- Game: Fly Fly Dragon!
addappid(2471620)
addappid(2471621, 1, "5a45592a7651d848784179a4bfa9944575ead18319f33add11beec8e852bc01d")
