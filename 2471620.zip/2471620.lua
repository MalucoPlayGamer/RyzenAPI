-- Lua provided by RyzenAPI
-- Game: Fly Fly Dragon!

-- MAIN APPLICATION
addappid(2471620)
-- Game: addappid(2471620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471621, 1, "5a45592a7651d848784179a4bfa9944575ead18319f33add11beec8e852bc01d")
