-- Lua provided by RyzenAPI
-- Game: Game: 3D PUZZLE - Factory

-- MAIN APPLICATION
addappid(2756860)
-- Game: addappid(2756860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756861, 1, "3a86fc3f3068189b6f4e8957dbf191b17b260d0bc87b1b95a67d4e6424e37eb3")
