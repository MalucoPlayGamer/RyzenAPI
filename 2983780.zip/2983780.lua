-- Lua provided by RyzenAPI
-- Game: addappid(2983780)

-- MAIN APPLICATION
addappid(2983780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983781, 1, "04fb3bd53f6f4a84a10004174ad12f9e79a2afc85d750089d745206f85f2acb6")
