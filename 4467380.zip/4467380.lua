-- 4467380's Lua and Manifest Created by Hubcap Manifest
-- Holy Crap! I'm Out of Paper! : The In-Law Survival Guide
-- Created: August 15, 2026 at 22:31:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4467380) -- Holy Crap! I'm Out of Paper! : The In-Law Survival Guide
-- MAIN APP DEPOTS
addappid(4467381, 1, "b257946580429280db0df847e5855b3dc9f7f492a013538690ed68c2eb511c92") -- Depot 4467381
setManifestid(4467381, "5269703865753670278", 1120509416)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4467382) -- Depot 4467382 (empty depot)