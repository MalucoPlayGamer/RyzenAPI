-- Lua provided by RyzenAPI
-- Game: Holy Crap! I'm Out of Paper! : The In-Law Survival Guide

-- MAIN APPLICATION
addappid(4467380) -- Holy Crap! I'm Out of Paper! : The In-Law Survival Guide
-- addappid(4467382) -- Depot 4467382 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4467381, 1, "b257946580429280db0df847e5855b3dc9f7f492a013538690ed68c2eb511c92") -- Depot 4467381

