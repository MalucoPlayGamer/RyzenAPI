-- Lua provided by RyzenAPI
-- Game: Stolen Dolls

-- MAIN APPLICATION
addappid(2207080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207081, 1, "3b0506b1f76d0654545e2ab224fb3f7ed71dbf8829358fe8d2a04bb7bfcac688")

