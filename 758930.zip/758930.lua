-- Lua provided by RyzenAPI
-- Game: Captain Forever Trilogy

-- MAIN APPLICATION
addappid(758930)

-- MAIN APP DEPOTS / PACKAGES
addappid(758931, 1, "fea811e876b855379f18bd680fcabac83c5beb5f3272e4914080039751c48732")
addappid(758932, 1, "a28c4cddf3873de0b408830c619e8c0c1d732c58dfb28a9c6ea8db99e8643292")
