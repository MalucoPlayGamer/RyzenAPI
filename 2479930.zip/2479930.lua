-- Lua provided by SkyAPI 
-- Game: Police Car SUV Simulator
addappid(2479930)
addappid(2479931, 1, "59e460e60b2e60486925a70f2bb83b711c2d6d2a890d4322fe656a072f694fe8")
