-- Lua provided by RyzenAPI
-- Game: What's Your Gender?

-- MAIN APPLICATION
addappid(1761630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761631, 1, "de1161c16f3e9187a0b85c94981335efd0bbf7779d51ee59b6494796b0b2632c")
