-- Lua provided by RyzenAPI
-- Game: What's Your Gender?

-- MAIN APPLICATION
addappid(1761630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1761631, 1, "de1161c16f3e9187a0b85c94981335efd0bbf7779d51ee59b6494796b0b2632c")

