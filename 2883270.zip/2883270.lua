-- Lua provided by RyzenAPI
-- Game: hacker

-- MAIN APPLICATION
addappid(2883270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883271, 1, "855c203444aae4ca9d22f5efc92368a7b2dff6ef2168f05e019135642bbb6aa8")

