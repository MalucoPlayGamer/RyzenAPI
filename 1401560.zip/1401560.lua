-- Lua provided by RyzenAPI
-- Game: Kilta

-- MAIN APPLICATION
addappid(1401560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401561, 1, "ea4b891e9f2a56554b4f398dae65a29c22f00149ffdfc678f822a3b4f235eeba")

