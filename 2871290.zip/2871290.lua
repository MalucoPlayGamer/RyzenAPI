-- Lua provided by RyzenAPI
-- Game: 2871290

-- MAIN APPLICATION
addappid(2871290)
-- Game: addappid(2871290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871291, 1, "2d8179193d9921894853fbd899ba4ff629dba49ec669eb88c7263b1b8db35cd9")
