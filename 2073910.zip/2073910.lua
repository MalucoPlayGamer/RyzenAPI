-- Lua provided by SkyAPI 
-- Game: A Webbing Journey
addappid(2073910)
addappid(2073911, 1, "b3ae7461810864e27c36bd149241b1306ad3ec5010f6b8dc0468ffb6f4a4f84e")
addappid(2073912, 1, "2289fbb79fb8c4703004d8badb359ddeedb8f02f34d20e785200c926a065d62a")
addappid(2073913, 1, "06ebf7801074876dfd84d74d32cbb071d0ef345b43d621987c25c4736a4ec9d4")
