-- Lua provided by RyzenAPI
-- Game: Game: Lucky Mark

-- MAIN APPLICATION
addappid(2450720)
-- Game: addappid(2450720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450721, 1, "5f5bab30f74be05d4684276721e1b3840d65cb62c33af85fb464acc7e1f84c37")
