-- Lua provided by RyzenAPI
-- Game: MOMIBOSU

-- MAIN APPLICATION
addappid(2487340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487341, 1, "07be30fcdffc5ebd31385b7f473091a8c9337a00524bdff323ce4380c419dbea")
