-- Lua provided by RyzenAPI
-- Game: Game: Street Heat

-- MAIN APPLICATION
addappid(744040)
-- Game: addappid(744040)

-- MAIN APP DEPOTS / PACKAGES
addappid(744041, 1, "ac8db23b16a067f8ce661cbbc5e90d69b562f4b0a3d32c9ed95742b3779983af")
