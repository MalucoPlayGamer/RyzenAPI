-- Lua provided by RyzenAPI 
-- Game: Street Heat
addappid(744040)
addappid(744041, 1, "ac8db23b16a067f8ce661cbbc5e90d69b562f4b0a3d32c9ed95742b3779983af")
