-- Lua provided by RyzenAPI
-- Game: Street Heat

-- MAIN APPLICATION
addappid(744040)
addappid(758380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(744041, 1, "ac8db23b16a067f8ce661cbbc5e90d69b562f4b0a3d32c9ed95742b3779983af")

