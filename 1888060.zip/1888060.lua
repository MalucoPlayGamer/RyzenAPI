-- Lua provided by RyzenAPI
-- Game: addappid(1888060)

-- MAIN APPLICATION
addappid(1888060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888061, 1, "4f9fcd0fc3521272a4ad25c0efe92a252d108985b8a602fb676a6d98630e8674")
