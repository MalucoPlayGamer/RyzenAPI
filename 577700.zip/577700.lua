-- Lua provided by RyzenAPI
-- Game: 577700

-- MAIN APPLICATION
addappid(577700)
-- Game: addappid(577700)

-- MAIN APP DEPOTS / PACKAGES
addappid(577701, 1, "96ef989ce5b5d34be8c0614e894a83366c5bc25503bc8eee06b95d1317c4db5c")
