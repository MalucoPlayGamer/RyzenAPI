-- Lua provided by SkyAPI 
-- Game: School Trip
addappid(1777930)
addappid(1777931, 1, "001bdd7f1989bb89519d97c9a240fec4176509448444168c555d2be6d8c7e62d")
