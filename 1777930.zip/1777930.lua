-- Lua provided by RyzenAPI
-- Game: School Trip

-- MAIN APPLICATION
addappid(1777930)
-- Game: addappid(1777930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777931, 1, "001bdd7f1989bb89519d97c9a240fec4176509448444168c555d2be6d8c7e62d")
