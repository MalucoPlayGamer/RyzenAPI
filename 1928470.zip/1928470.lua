-- Lua provided by RyzenAPI
-- Game: Game: AppID 1928470

-- MAIN APPLICATION
addappid(1928470)
-- Game: addappid(1928470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928471, 1, "bbedda4303858f89c7a1130984fb5e1d6c1b51a17e962f958bf6a45cd384e3c7")
