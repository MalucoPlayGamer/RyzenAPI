-- Lua provided by RyzenAPI
-- Game: Sora no Ao to Shiro to

-- MAIN APPLICATION
addappid(2135500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2135501, 1, "b9f7762079477d5f7a966cebda8f8f279d725978f5530f48705d7863b185a8f8")
addappid(2135502, 1, "817c1aee9245644deb94529cc89dd8a3b3e2fd3eeb95dc7b243652ff08b20207")

