-- Lua provided by RyzenAPI
-- Game: Redemption Cemetery: The Stolen Time Collector's Edition

-- MAIN APPLICATION
addappid(1996810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996811, 1, "c79acc6cbf0036c2f06dcb4ea380af0b2349cd595fa0d7f62222ccfe06a654a7")
