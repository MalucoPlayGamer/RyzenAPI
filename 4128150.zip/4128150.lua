-- Lua provided by RyzenAPI
-- Game: The Riese Project

-- MAIN APPLICATION
addappid(4128150)

-- MAIN APP DEPOTS / PACKAGES
addappid(4128151,0,"6789a86f39af4d3fab86bf0374824876a93827ad1def3d6f6a8309615e887bd1")

