-- Lua provided by RyzenAPI
-- Game: The Riese Project

-- MAIN APPLICATION
addappid(4128150)

-- MAIN APP DEPOTS / PACKAGES
addappid(4128151,0,"6789a86f39af4d3fab86bf0374824876a93827ad1def3d6f6a8309615e887bd1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
