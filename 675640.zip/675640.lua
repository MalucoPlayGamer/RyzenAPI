-- Lua provided by RyzenAPI
-- Game: Game: AppID 675640

-- MAIN APPLICATION
addappid(675640)
-- Game: addappid(675640)

-- MAIN APP DEPOTS / PACKAGES
addappid(675641, 1, "8daa267861f20d258b6a5a061e16f01442729319f2bfcc48499551ad53168552")
