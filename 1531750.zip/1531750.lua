-- Lua provided by RyzenAPI 
-- Game: AppID 1531750
addappid(1531750)
addappid(1531751, 1, "96af34d070bf0d1f2a8b674cd234816e153b7f238a841454a84397e33fde5a8a")
