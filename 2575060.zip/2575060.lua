-- Lua provided by RyzenAPI
-- Game: Game: Lively Chair Simulator

-- MAIN APPLICATION
addappid(2575060)
-- Game: addappid(2575060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2575061, 1, "f1b326e2430e98a46f0aac2271d1124132a8e0437b1428f46812311f688b4f4e")
