-- Lua provided by SkyAPI 
-- Game: Lively Chair Simulator
addappid(2575060)
addappid(2575061, 1, "f1b326e2430e98a46f0aac2271d1124132a8e0437b1428f46812311f688b4f4e")
