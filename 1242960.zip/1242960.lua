-- Lua provided by RyzenAPI
-- Game: AppID 1242960

-- MAIN APPLICATION
addappid(1242960)
-- Game: addappid(1242960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242961, 1, "7d6b27bd6b0abe6ddc0bad3fad8278ad598052ce6cb20e497ff3929b8515eaa3")
