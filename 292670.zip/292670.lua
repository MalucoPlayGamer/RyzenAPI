-- Lua provided by SkyAPI 
-- Game: AppID 292670
addappid(292670)
addappid(292671, 1, "6adc67d4935eac876f28d1648ac2a987cf09206fa179a47a046a857e06b80523")
