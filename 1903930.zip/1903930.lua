-- Lua provided by RyzenAPI
-- Game: City Bus Manager - Africa

-- MAIN APPLICATION
addappid(1903930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903931, 1, "55dd41191c8029a8397dd18c5466c533f950dc8fb716aef15c343851e5f75f5e")

