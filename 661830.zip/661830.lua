-- Lua provided by RyzenAPI
-- Game: Lunarsea

-- MAIN APPLICATION
addappid(661830)
-- Game: addappid(661830)

-- MAIN APP DEPOTS / PACKAGES
addappid(661831, 1, "73f7fc6ad3688551e504195c0e7fcdd58279ae0e099d0391216691684b7b94d9")
