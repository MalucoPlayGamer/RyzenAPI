-- Lua provided by RyzenAPI
-- Game: Gamer Stop Simulator

-- MAIN APPLICATION
addappid(3499220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499221, 1, "f6b9f2ef54f88905959a816065804c8594b6491e7874afdf3d7c46d30504b08a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4337350)
addappid(4337360)
addappid(4337370)
