-- Lua provided by RyzenAPI
-- Game: Gamer Stop Simulator

-- MAIN APPLICATION
addappid(3499220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499221, 1, "f6b9f2ef54f88905959a816065804c8594b6491e7874afdf3d7c46d30504b08a")

