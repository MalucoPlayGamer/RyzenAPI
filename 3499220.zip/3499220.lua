-- Lua provided by RyzenAPI 
-- Game: Gamer Stop Simulator
addappid(3499220)
addappid(3499221, 1, "f6b9f2ef54f88905959a816065804c8594b6491e7874afdf3d7c46d30504b08a")
