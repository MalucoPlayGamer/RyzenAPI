-- Lua provided by RyzenAPI
-- Game: addappid(402750)

-- MAIN APPLICATION
addappid(402750)

-- MAIN APP DEPOTS / PACKAGES
addappid(402751, 1, "07a839f07ba09a53fe716bb7cba9f54e3ba2b9205ff90556aab8e7dce5a23c5c")
