-- Lua provided by RyzenAPI 
-- Game: Osmos
addappid(29180)
addappid(29181, 1, "d0c47e8295db1ca538e2428678f22c7f2bc280c1e4490f466f9095ca3c2c4290")
addappid(29182, 1, "7ba8d9c00b7bbd5587f0f243ada293be2629e036b72cc895a65a5e633ba8ffc4")
addappid(29183, 1, "1ab38f033f5eb5137eda710dc2ddab2d7d487647595c36d4f7b70201dbab0a00")
