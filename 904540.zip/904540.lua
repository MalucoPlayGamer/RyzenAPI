-- Lua provided by RyzenAPI
-- Game: Indiana Jones® and the Infernal Machine™

-- MAIN APPLICATION
addappid(904540)

-- MAIN APP DEPOTS / PACKAGES
addappid(904541, 1, "229e34f822789cfbad371bf2ba71fe45dd552513bfcc80a47a3bda97f3ccb879")

