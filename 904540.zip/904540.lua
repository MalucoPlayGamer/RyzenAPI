-- Lua provided by RyzenAPI
-- Game: Indiana Jones® and the Infernal Machine™

-- MAIN APPLICATION
addappid(904540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(904541, 1, "229e34f822789cfbad371bf2ba71fe45dd552513bfcc80a47a3bda97f3ccb879")

