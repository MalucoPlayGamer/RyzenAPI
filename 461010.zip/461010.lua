-- Lua provided by RyzenAPI 
-- Game: Roll'd
addappid(461010)
addappid(461011, 1, "2b7af5f6fd509a7e5667f4dac7e60268e6af942d718ed5c01ce55d06ab1ca907")
addappid(461012, 1, "e7f16a4dcfe9de2a5aa98f290b5732f78e099c4d086a54d79ace6607f14e293c")
addappid(461013, 1, "4f041809f41605b8fbe6bdcc80a693dec0608e421a3cfa23f618574122ad0b1d")
