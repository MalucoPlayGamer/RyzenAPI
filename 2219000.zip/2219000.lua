-- Lua provided by RyzenAPI
-- Game: addappid(2219000)

-- MAIN APPLICATION
addappid(2219000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219001, 1, "38e570b65bae7fd172f56d7cc23ce824736c6137580ef5a8630b23f1b699b2ed")
