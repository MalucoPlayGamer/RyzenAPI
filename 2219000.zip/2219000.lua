-- Lua provided by RyzenAPI
-- Game: A Promise Best Left Unkept

-- MAIN APPLICATION
addappid(2219000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219001, 1, "38e570b65bae7fd172f56d7cc23ce824736c6137580ef5a8630b23f1b699b2ed")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2612460)
addappid(2946650)
