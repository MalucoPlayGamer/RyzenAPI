-- Lua provided by SkyAPI 
-- Game: Collab Ball
addappid(1907280)
addappid(1907281, 1, "e5f6fab26cb2484443f76ca9148b852bd91bb2da9a638c71b598c5ea97cf426b")
