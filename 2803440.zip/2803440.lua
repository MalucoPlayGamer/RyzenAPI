-- Lua provided by RyzenAPI
-- Game: Voxile Demo (Adventure + Survival)

-- MAIN APPLICATION
addappid(2803440)
-- Game: addappid(2803440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803441, 1, "fc05ef3da563704eb8827e451e67ab5dba850ff19b6a72548f6cec74f6e067fd")
