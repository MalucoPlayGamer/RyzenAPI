-- Lua provided by RyzenAPI
-- Game: Hunt: Showdown 1896 (Test Server)

-- MAIN APPLICATION
addappid(770720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(770721, 1, "7d95331c5898d89c44337f6501d58b84aaea43479055549b734951a636cb274c")
addappid(770722, 1, "678bb329711e2b70f39e33ec0b3aced3a9beed1a93f7905bf0b04c037b5fee19")
addappid(770723, 1, "e026ead86d7ce05f1477adbcdf473e0a40042aeac18e9641055b844690f4512b")
addappid(770724, 1, "606284f7a70e4a44baab32ce9ee45b66c1b5d3a13893e5096b60dc182dd6bde5")

