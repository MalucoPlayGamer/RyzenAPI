-- Lua provided by SkyAPI 
-- Game: Hunt: Showdown 1896 (Test Server)
addappid(770720)
addappid(770721, 1, "7d95331c5898d89c44337f6501d58b84aaea43479055549b734951a636cb274c")
addappid(770722, 1, "678bb329711e2b70f39e33ec0b3aced3a9beed1a93f7905bf0b04c037b5fee19")
addappid(770723, 1, "e026ead86d7ce05f1477adbcdf473e0a40042aeac18e9641055b844690f4512b")
addappid(770724, 1, "606284f7a70e4a44baab32ce9ee45b66c1b5d3a13893e5096b60dc182dd6bde5")
