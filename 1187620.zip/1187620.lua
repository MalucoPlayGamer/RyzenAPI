-- Lua provided by RyzenAPI
-- Game: Hentai Pazu

-- MAIN APPLICATION
addappid(1187620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187622,0,"6fdb6131aaa705eb39bdc81aa0ebe6cc4cbdbb6d6087d292827f4b285ec3ba75")

