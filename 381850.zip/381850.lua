-- Lua provided by RyzenAPI
-- Game: My Paper Boat

-- MAIN APPLICATION
addappid(381850)
-- Game: addappid(381850)

-- MAIN APP DEPOTS / PACKAGES
addappid(381851, 1, "3470a46027c504f68e9bfaaae1e1516c3889e19c2c2be91c045b89413750b0e3")
addappid(381852, 1, "b366a2d25da997f6ad0fc749ad0d3b07dd4d16c825120d0034579eed54437884")
addappid(381853, 1, "e4f87d6d1c2c4c1b79b78e5d61db0650ee393bda3ac09765f403c18ede4ea26e")
addappid(381854, 1, "40e95a750e46ac7824a73173334b18ae9f2f8ed60e957dc8d029e0cf258bf1f8")
addappid(381855, 1, "c5dbae0e49357dd6dac244f4a051dde65e2c7626de2c09ebf3c4f014a1af64ce")
