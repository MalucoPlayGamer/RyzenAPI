-- Lua provided by RyzenAPI
-- Game: Beat Saber - Outkast - "Hey Ya!"

-- MAIN APPLICATION
addappid(2893470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893470,0,"439f3f7c6426a6382b273916a0e15feecf45d576385b0588d5e49006aab4a321")

