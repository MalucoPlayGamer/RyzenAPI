-- Lua provided by RyzenAPI
-- Game: Tabletop Hero

-- MAIN APPLICATION
addappid(2591290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591291, 1, "9776a2f82d624991e8d515b0ef3851f9b7d1e02c098fb1cc889f57b7b00f9855")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
