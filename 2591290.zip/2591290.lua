-- Lua provided by SkyAPI 
-- Game: Tabletop Hero
addappid(2591290)
addappid(2591291, 1, "9776a2f82d624991e8d515b0ef3851f9b7d1e02c098fb1cc889f57b7b00f9855")
