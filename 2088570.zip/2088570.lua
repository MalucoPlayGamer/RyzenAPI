-- Lua provided by RyzenAPI
-- Game: Game: Tiny Rogues

-- MAIN APPLICATION
addappid(2088570)
-- Game: addappid(2088570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088571, 1, "122e3270335372157a11a595038524e4cd4bfd7b2b9851c40ca5c25be3f85914")
