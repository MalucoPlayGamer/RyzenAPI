-- Lua provided by RyzenAPI
-- Game: Astro Miner

-- MAIN APPLICATION
addappid(2751340)
addappid(2854860)
addappid(2854870)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2751341, 1, "2abf20530bb91ecffd240ffb795bb4b0f367fbd2064f5d43c9077f542816ec8f")

