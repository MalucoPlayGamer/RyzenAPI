-- Lua provided by RyzenAPI
-- Game: Astro Miner

-- MAIN APPLICATION
addappid(2751340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751341, 1, "2abf20530bb91ecffd240ffb795bb4b0f367fbd2064f5d43c9077f542816ec8f")
