-- Lua provided by RyzenAPI
-- Game: addappid(2000660)

-- MAIN APPLICATION
addappid(228990)
addappid(2000660)
addappid(2000663)
addappid(2000664)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000662,0,"361b922fef650352b85e7c886548a60ca182c4eb549a5b2ca3a6be1736c40673")
