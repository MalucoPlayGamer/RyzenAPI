-- Lua provided by RyzenAPI
-- Game: 2403

-- MAIN APPLICATION
addappid(2403)
-- Game: addappid(2403)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404, 1, "94e6f92022edb275f6c91c1310daec94ffdadc617100174f71496c784eaeb36c")
