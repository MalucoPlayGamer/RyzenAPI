-- Lua provided by RyzenAPI
-- Game: Suffer The Night

-- MAIN APPLICATION
addappid(2176850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176851, 1, "b5f57a2b6ad4a55b717018792d2732dfe6d0b650d9b2a30cea1da02bbfb80fb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
