-- Lua provided by SkyAPI 
-- Game: Suffer The Night
addappid(2176850)
addappid(2176851, 1, "b5f57a2b6ad4a55b717018792d2732dfe6d0b650d9b2a30cea1da02bbfb80fb4")
