-- Lua provided by RyzenAPI
-- Game: Game: Suffer The Night

-- MAIN APPLICATION
addappid(2176850)
-- Game: addappid(2176850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176851, 1, "b5f57a2b6ad4a55b717018792d2732dfe6d0b650d9b2a30cea1da02bbfb80fb4")
