-- Lua provided by RyzenAPI
-- Game: Happy Lab

-- MAIN APPLICATION
addappid(649960)
addappid(2744610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(649961, 1, "2e8b8d139af63a0c5c67cd512da0dc5c6faaf44552f02383a04fd90b27e5545a")
