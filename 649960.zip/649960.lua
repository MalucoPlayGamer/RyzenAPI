-- Lua provided by RyzenAPI
-- Game: AppID 649960

-- MAIN APPLICATION
addappid(649960)

-- MAIN APP DEPOTS / PACKAGES
addappid(649961, 1, "2e8b8d139af63a0c5c67cd512da0dc5c6faaf44552f02383a04fd90b27e5545a")
