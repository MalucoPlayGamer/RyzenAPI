-- Lua provided by RyzenAPI
-- Game: 1706800

-- MAIN APPLICATION
addappid(1706800)
-- Game: addappid(1706800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706802,0,"bafef2215f0a70ac62689a4607b3fc9e6fcdb8c9b40e9192323796980f7ed573")
