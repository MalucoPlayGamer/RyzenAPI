-- Lua provided by RyzenAPI
-- Game: Game: Bratz™: Flaunt your fashion

-- MAIN APPLICATION
addappid(2088340)
-- Game: addappid(2088340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088341, 1, "fd11b9a65e3c35c93c30300190a553c7ff7818a770ce9d4ebe300cd5feb1648b")
addappid(2281810, 0, "9ba242810f5c322aa5ee50f8c392e92eca2f05a3e7d3cb956a6c145c146349a3")
addappid(2451150, 0, "2f7cd491c89e7060d0596f14ad62d06a86b62f40d3fcc14b96b347dd83af0dfc")
