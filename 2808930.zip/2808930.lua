-- Lua provided by RyzenAPI
-- Game: Lust Goddess

-- MAIN APPLICATION
addappid(3348530) -- Lust Goddess — Mascot Asha
addappid(3366800) -- Lust Goddess — Mascot Mitsuki
addappid(3366830) -- Lust Goddess — Mascot Belle
addappid(3376940) -- Lust Goddess - Mascot O-Rinn
addappid(3380970) -- Lust Goddess — Mascot Grace
addappid(3403340) -- Lust Goddess — Mascot Morana
addappid(3403350) -- Lust Goddess — Sixtine
addappid(3405500) -- Lust Goddess — Lilith
addappid(3415650) -- Lust Goddess — Mascot Wendy
addappid(3426250) -- Lust Goddess — Mascot Lorraine
addappid(3453920) -- Lust Goddess — Mascot Lucretia
addappid(3474560) -- Lust Goddess — Mascot Nymeria
addappid(3490010) -- Lust Goddess — Mascot Thora
addappid(3490150) -- Lust Goddess — Mascot Hilda
addappid(3490160) -- Lust Goddess — Mascot Blanche
addappid(3544070) -- Lust Goddess — Mascot Arachne
addappid(3587920) -- Lust Goddess — Mascot Kirsten
addappid(3594950) -- Lust Goddess — Mascot Charlotte
addappid(3610320) -- Lust Goddess — Mascot Harper
addappid(3612650) -- Lust Goddess - Mascot Casey
addappid(3629220) -- Lust Goddess — Mascot Omega
addappid(3632030) -- Lust Goddess — Mascot Zoe & Chloe
addappid(3632080) -- Lust Goddess — Mascot Rose
addappid(3632110) -- Lust Goddess — Mascot Viktoria
addappid(3632160) -- Lust Goddess — Mascot Ravenna
addappid(3632180) -- Lust Goddess — Mascot Bea
addappid(3632220) -- Lust Goddess — Mascot Nicole
addappid(3824110) -- Lust Goddess - Mascot River
addappid(3824190) -- Lust Goddess — Mascot Zelia
addappid(3866020) -- Lust Goddess — Mascot Naomi
addappid(3937050) -- Lust Goddess — Mascot Alisha
addappid(3967090) -- Lust Goddess — Mascot Pixie
addappid(4076040) -- Lust Goddess — Mascot Selina
addappid(4081330) -- Lust Goddess — Mascot Tsintah
addappid(4081340) -- Lust Goddess — Mascot Vespina
addappid(4081350) -- Lust Goddess — Mascot Britney
addappid(4212490) -- Lust Goddess — Mascot Kiana
addappid(4224650) -- Lust Goddess — Mascot Kitty New Year
addappid(4341370) -- Lust Goddess — Mascot Bonita
addappid(4383360) -- Lust Goddess — Mascot Vivienne
addappid(4484030) -- Lust Goddess — Mascot Shelby
addappid(4539940) -- Lust Goddess — Mascot Nonna
addappid(4601150) -- Lust Goddess — Mascot Irma
addappid(4627610) -- Lust Goddess — Mascot Esther
addappid(4627620) -- Lust Goddess — Mascot Agrat
addappid(4716460) -- Lust Goddess — Mascot Falenia
addappid(4844680) -- Lust Goddess — Mascot Justina
addappid(4870550) -- Lust Goddess — Mascot Faye Summer
addappid(4870660) -- Lust Goddess — Mascot Zelia Summer
addappid(4993030) -- Lust Goddess — Mascot Maddie
addappid(5032720)
addappid(5036960) -- Lust Goddess — Mascot Inferna

-- MAIN APP DEPOTS / PACKAGES
addappid(2808930, 1, "1412473c625b8149dc359871838506dfb8d3cc7911dfbca08538d2f4861e5da6")
addappid(2808931, 1, "56d0d282de07ffeea381c878beba19735867e44776afdbd8dd5bba34de41db9e") -- (windows)
addappid(2808932, 1, "4e6ec6d50ec30535e617715f1f8031adbb9512e759e369469e271977753128f3") -- (macos)

