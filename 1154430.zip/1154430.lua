-- Lua provided by RyzenAPI
-- Game: RPG Character Builder

-- MAIN APPLICATION
addappid(1154430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154431, 1, "75fae577b1c4a08de1bb480f4363a4e8d2e7d2a3bf840560ebcddc955c3bbcb5")
addappid(1154432, 1, "73309065b8ddb58b467da42012d863b1396690255c130a8df0e53c2b9f72afdd")
