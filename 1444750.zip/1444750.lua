-- Lua provided by RyzenAPI
-- Game: DreamWatcher

-- MAIN APPLICATION
addappid(1444750)
-- Game: addappid(1444750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444751, 1, "632d6408f8155d5ff3cb8f025a501c3c232a8672b4c7133212a865bc6bc38ce9")
