-- Lua provided by RyzenAPI 
-- Game: JR EAST Train Simulator Demo
addappid(3214350)
addappid(3214351, 1, "e6b2355a5ebede375a4b4dcd7d01b9839598ec67159cd4ee9813638fa02669eb")
