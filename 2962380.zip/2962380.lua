-- Lua provided by RyzenAPI
-- Game: Old School Rally Demo

-- MAIN APPLICATION
addappid(2962380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962381, 1, "9fde9057759910faacc97bbc70cc7f619f195368cb881c56260e9bf51031d4de")
