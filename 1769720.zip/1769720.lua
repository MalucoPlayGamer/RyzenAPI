-- Lua provided by RyzenAPI
-- Game: SCP Foundation: ITTLG - Chapter 1

-- MAIN APPLICATION
addappid(1769720)
-- Game: addappid(1769720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769721, 1, "afa71536685dcc0bf31dc81064c6bf6dce479305ddc2c888d11c323f941a2c56")
