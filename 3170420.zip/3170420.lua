-- Lua provided by RyzenAPI
-- Game: 3170420

-- MAIN APPLICATION
addappid(3170420)
-- Game: addappid(3170420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170420,0,"83a8d1f0ee10df4b8d6faaa33c7e904e7a990e873de65297ca14e9f157364f67")
