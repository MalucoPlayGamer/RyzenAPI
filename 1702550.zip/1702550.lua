-- Lua provided by RyzenAPI
-- Game: The Birth of an Artificial Intelligence

-- MAIN APPLICATION
addappid(1702550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702551, 1, "8574c52b4a99f164e3dc863d8604ced078b27f99e2bb287b772dc7e999967826")

