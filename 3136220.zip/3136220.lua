-- Lua provided by RyzenAPI 
-- Game: GIRLS VS TENTACLES
addappid(3136220)
addappid(3136221, 1, "c8eeceed5c11d6d010fc8231464a4fadf39c0ac8f47e2150fb620b9b1571127c")
