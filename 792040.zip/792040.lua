-- Lua provided by RyzenAPI
-- Game: Detective Di: The Silk Rose Murders

-- MAIN APPLICATION
addappid(792040)
-- Game: addappid(792040)

-- MAIN APP DEPOTS / PACKAGES
addappid(792041, 1, "ddc0b39afe833013dab20799ada7eb5d52d57b9f95fe51839e2329422a4706d0")
addappid(792042, 1, "47ef6bd04780b4c843919f5efec3464bf7156d8196fac2a1e547b6c205043637")
addappid(1131340, 0, "007496a62f897ee53ec8e20baf9b90659b6727f44e5c11e0a1143e0959199f8b")
addappid(1400770, 0, "1645aa076e52da50e07eba61f8dfe95046506c51a117c4da2518b2acb82394fa")
