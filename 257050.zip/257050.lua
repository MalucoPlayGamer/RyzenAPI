-- Lua provided by RyzenAPI
-- Game: addappid(257050)

-- MAIN APPLICATION
addappid(257050)
addappid(367830)

-- MAIN APP DEPOTS / PACKAGES
addappid(257051, 1, "778809f8ce0704e68c9e2cafa716f25972674dc435087daa83037f4e20d424a6")
