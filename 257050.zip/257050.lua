-- Lua provided by RyzenAPI
-- Game: Darkout

-- MAIN APPLICATION
addappid(257050)
addappid(367830)

-- MAIN APP DEPOTS / PACKAGES
addappid(257051, 1, "778809f8ce0704e68c9e2cafa716f25972674dc435087daa83037f4e20d424a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
