-- Lua provided by RyzenAPI
-- Game: Slum Guide

-- MAIN APPLICATION
addappid(3070560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070563,0,"18d8b2b08cf46033eeae29a73d6b7e57196248c266e4108714a81de4de5190c6")
