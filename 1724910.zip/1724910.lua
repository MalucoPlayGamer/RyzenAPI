-- Lua provided by RyzenAPI
-- Game: 幻想曹操传 Fantasy of Caocao

-- MAIN APPLICATION
addappid(1724910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724911, 1, "3a817a66dfedb0988208507aff4b0f4cdf4d01d230c2bd15b96939706fa5effe")

