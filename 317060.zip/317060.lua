-- Lua provided by RyzenAPI
-- Game: Attractio

-- MAIN APPLICATION
addappid(317060)

-- MAIN APP DEPOTS / PACKAGES
addappid(317061, 1, "8cfed0d7b8565f8a95f2c6b1b8fd82fa88f9c783a2c455ac228246be6419e23d")
addappid(317062, 1, "ddb7da7005d15e077f1a5ad2e71dfc4bccbff126223c0d9f17ebac875a84ee8e")
addappid(317063, 1, "7cf513fd6a25681cff792ed13330cb8036653c52e5809aa0181edac7049dc0e6")
addappid(317064, 1, "9f3a8a339367925e8fa56fa32c6286ee294e22baaa93b0541a9ce318577bc833")
