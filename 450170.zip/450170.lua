-- Lua provided by RyzenAPI
-- Game: 450170

-- MAIN APPLICATION
addappid(450170)
-- Game: addappid(450170)

-- MAIN APP DEPOTS / PACKAGES
addappid(450171, 1, "4b3577ce65bf6eec9e6e65f3cdb55709dc34feaf1bcf42848b7bb12599bbffe1")
addappid(450172, 1, "cef888022048b699e57931678ca1e979b1c3e998d310e34c2b1be0f5437790c2")
addappid(450173, 1, "65425466111afadebf6e5f97acf0ac109fdc263c615343d7a1776cc7e32c9aa4")
