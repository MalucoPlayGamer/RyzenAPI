-- Lua provided by RyzenAPI
-- Game: BOOR

-- MAIN APPLICATION
addappid(450170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(450171, 1, "4b3577ce65bf6eec9e6e65f3cdb55709dc34feaf1bcf42848b7bb12599bbffe1")
addappid(450172, 1, "cef888022048b699e57931678ca1e979b1c3e998d310e34c2b1be0f5437790c2")
addappid(450173, 1, "65425466111afadebf6e5f97acf0ac109fdc263c615343d7a1776cc7e32c9aa4")

