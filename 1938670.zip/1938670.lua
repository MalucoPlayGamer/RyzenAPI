-- Lua provided by SkyAPI 
-- Game: Easter Bunny
addappid(1938670)
addappid(1938671, 1, "f09918111ef30d3dc9e23e228cd92e9a8d2892bb748992452e5b49486fe30eec")
