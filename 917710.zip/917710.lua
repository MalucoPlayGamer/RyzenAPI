-- Lua provided by RyzenAPI
-- Game: 917710

-- MAIN APPLICATION
addappid(917710)
-- Game: addappid(917710)

-- MAIN APP DEPOTS / PACKAGES
addappid(917711, 1, "3264f8612045dfde61a440e78dd53404a2a421a47b531f9ba9fb96741922613e")
