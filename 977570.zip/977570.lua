-- Lua provided by RyzenAPI
-- Game: 977570

-- MAIN APPLICATION
addappid(977570)
-- Game: addappid(977570)

-- MAIN APP DEPOTS / PACKAGES
addappid(977571, 1, "fe7ba80b220522148bb6215cd1b8ed60dc9d71334919648f0f20e8de79125cf4")
