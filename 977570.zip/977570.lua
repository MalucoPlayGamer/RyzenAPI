-- Lua provided by SkyAPI 
-- Game: AppID 977570
addappid(977570)
addappid(977571, 1, "fe7ba80b220522148bb6215cd1b8ed60dc9d71334919648f0f20e8de79125cf4")
