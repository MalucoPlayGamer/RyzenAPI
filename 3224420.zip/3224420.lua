-- Lua provided by RyzenAPI
-- Game: Milky Way Idle

-- MAIN APPLICATION
addappid(3224420)

