-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2010120)
-- Game: addappid(2010120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010120,0,"63b26c9bb8ffad65701bffe8fbdc07f16d4f5499b9468a467f81c3b1cee767fc")
addappid(2010122,0,"607b100be088cf8d03afe9e2157dbfc34a8f983b7c326c35a9e705a8892410ed")
