-- Lua provided by RyzenAPI
-- Game: Mori's Nightmare : Hide and seek

-- MAIN APPLICATION
addappid(1524230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524231, 1, "8e1dc75b32f20d4a93efe75ebb5fdc03a16155173c6b562fe2c8b0d1351eb435")
