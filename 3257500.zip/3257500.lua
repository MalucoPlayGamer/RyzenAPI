-- Lua provided by RyzenAPI
-- Game: AppID 3257500

-- MAIN APPLICATION
addappid(3257500)
-- Game: addappid(3257500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257501, 1, "9bb33cdc16d8d83b0c4611abe736f1489b066050f0c5ff30bd9ee639d368c69b")
