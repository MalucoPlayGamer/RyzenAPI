-- Lua provided by RyzenAPI
-- Game: Fortune-499

-- MAIN APPLICATION
addappid(840610)
-- Game: addappid(840610)

-- MAIN APP DEPOTS / PACKAGES
addappid(840611, 1, "4ca9ef070201004d6c4caf1b870607041cacbc1c727109b002d71747a42d2230")
addappid(840612, 1, "6d58784ca05ef8a49406601bc10cba4c9e4714ed8bc4331836c8bee0bba111cd")
