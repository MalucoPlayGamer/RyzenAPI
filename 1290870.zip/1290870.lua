-- Lua provided by RyzenAPI
-- Game: addappid(1290870)

-- MAIN APPLICATION
addappid(1290870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290870,0,"dd0d33ff050628bd1430ea46f85af5c8fcbae3494d7f2d3fa8ef22c86689d823")
