-- Lua provided by RyzenAPI 
-- Game: The Riftbreaker: Soundtrack
addappid(1788250)
addappid(1788251, 1, "b2a19470be78ace76af70e77ff2bb6dcf96a3ef4a08c8d64465020d67d00a71b")
addappid(1788252, 1, "180c12c50f7d8774638acb31c428226ad46c4553d3a41cdb9e097e250333c53d")
