-- 4149910's Lua and Manifest Created by Hubcap Manifest
-- Guildamation
-- Created: July 09, 2026 at 02:25:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4149910, 1, "98b0f007da306f2a41e3605dacf8b4aea1e8eb2ebabfda8f38482bb26c66d37a") -- Guildamation
-- MAIN APP DEPOTS
addappid(4149911, 1, "3e7fb8e8036348a808382bd0db52e2c5e76cee110bb8d8571d2c4601395a05bc") -- Depot 4149911
setManifestid(4149911, "2978372086942587465", 388212624)