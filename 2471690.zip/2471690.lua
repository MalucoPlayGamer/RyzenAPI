-- Lua provided by RyzenAPI
-- Game: Stress Chess

-- MAIN APPLICATION
addappid(2471690)
-- Game: addappid(2471690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471691, 1, "809541daaec559cd74a120ddeed6b2231e144d302c99923e8fb3c53a1c3145a4")
