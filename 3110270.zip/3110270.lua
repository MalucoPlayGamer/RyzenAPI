-- Lua provided by RyzenAPI
-- Game: 3110270

-- MAIN APPLICATION
addappid(3110270)
-- Game: addappid(3110270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3110271, 1, "4fec77228ba9496dc38cf32faefc5abc05042c94979ba7dd505d4d1ebc25a035")
