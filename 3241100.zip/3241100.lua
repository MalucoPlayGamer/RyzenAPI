-- Lua provided by RyzenAPI
-- Game: WALKING IN FOG

-- MAIN APPLICATION
addappid(3241100)
-- Game: addappid(3241100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241101, 1, "ab99c529e819a6eb8f619d7244c84932765a8d8abb1cf038d1bd01be400e6a25")
