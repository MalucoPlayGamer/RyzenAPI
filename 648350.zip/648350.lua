-- Lua provided by RyzenAPI
-- Game: Jurassic World Evolution

-- MAIN APPLICATION
addappid(648350)

-- MAIN APP DEPOTS / PACKAGES
addappid(648351, 1, "4fd37bc5e006aad39f9082a111b9e6ab7d94dd90024a7ac60f2b96d05327f8ec")
