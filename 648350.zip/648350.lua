-- Lua provided by RyzenAPI
-- Game: Jurassic World Evolution

-- MAIN APPLICATION
addappid(648350) -- Jurassic World Evolution
addappid(817550) -- Jurassic World Evolution - Deluxe DLC
addappid(817560) -- Jurassic World Evolution - Pre-order Content
addappid(953940) -- Jurassic World Evolution Secrets of Dr Wu
addappid(965420) -- Jurassic World Evolution - JingleJam
addappid(979930) -- Jurassic World Evolution Cretaceous Dinosaur Pack
addappid(988470) -- Jurassic World Evolution Carnivore Dinosaur Pack
addappid(1028430) -- Jurassic World Evolution Claires Sanctuary
addappid(1107760) -- Jurassic World Evolution Herbivore Dinosaur Pack
addappid(1144410) -- Jurassic World Evolution Return To Jurassic Park
addappid(1144420) -- Jurassic World Evolution Raptor Squad Skin Collection

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(648351, 1, "4fd37bc5e006aad39f9082a111b9e6ab7d94dd90024a7ac60f2b96d05327f8ec") -- Nero Content

