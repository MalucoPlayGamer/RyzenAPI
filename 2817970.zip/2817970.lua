-- Lua provided by RyzenAPI
-- Game: 2817970

-- MAIN APPLICATION
addappid(2817970)
addappid(2817971)
-- Game: addappid(2817970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817972,0,"d65d81fb4cad860f2049eb8caf80ccdf0ad3d6fcc78066ee99e8f15c6f3b95f3")
addappid(2817973,0,"02b5f05847b219ce5156001131ff0d41a7942d9acb37354e08c9af697f646795")
addappid(2817974,0,"c7e01d85b7e50e0b0e742dcea5a844f11c9056fbd300e7ca1fede60c97511bd6")
