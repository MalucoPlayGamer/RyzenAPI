-- Lua provided by RyzenAPI
-- Game: Game: AppID 3358810

-- MAIN APPLICATION
addappid(3358810)
-- Game: addappid(3358810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358811, 1, "45675c1a59144e90342560e6aafdb38ba0efd901423bf5346eaf219144f46256")
