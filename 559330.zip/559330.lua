-- Lua provided by RyzenAPI
-- Game: Game: AppID 559330

-- MAIN APPLICATION
addappid(559330)
addappid(1379360)
-- Game: addappid(559330)

-- MAIN APP DEPOTS / PACKAGES
addappid(559331, 1, "f4ef3082041497b35ebeb409ed59e009c2463965c5aa69dabfaa8fe138dc6919")
