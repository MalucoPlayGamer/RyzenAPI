-- Lua provided by RyzenAPI
-- Game: A Fisherman's Tale

-- MAIN APPLICATION
addappid(559330)
addappid(1379360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(559331, 1, "f4ef3082041497b35ebeb409ed59e009c2463965c5aa69dabfaa8fe138dc6919")
