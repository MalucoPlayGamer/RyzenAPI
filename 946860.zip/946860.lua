-- Lua provided by RyzenAPI
-- Game: Game: AppID 946860

-- MAIN APPLICATION
addappid(946860)
-- Game: addappid(946860)

-- MAIN APP DEPOTS / PACKAGES
addappid(946861, 1, "d649408b5cbc4436d35ed7659ce15ccfe88a95895a4c2f229de7fc14419be1c0")
addappid(946862, 1, "95b5b01722088132a06c90d2b1888efaf85acf2101ca747c20b159fda5c9c768")
addappid(946863, 1, "9fde6ba5d9cd5718262679a0c70ee065c29a005f600fd533c643782f4bde00eb")
