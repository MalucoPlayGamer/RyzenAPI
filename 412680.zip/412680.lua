-- Lua provided by RyzenAPI
-- Game: addappid(412680)

-- MAIN APPLICATION
addappid(412680)

-- MAIN APP DEPOTS / PACKAGES
addappid(412681, 1, "abe3e8ff4ed46a384307cbe0924d455dd904fbdd808c2f331a3cbb1214d013ee")
