-- Lua provided by RyzenAPI
-- Game: Insomnia: Theater in the Head

-- MAIN APPLICATION
addappid(2085360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085361, 1, "42825ad8cde4bed323cc272e6b12c1c8a4b4a9d92781c02bc51cacd0333277d5")

