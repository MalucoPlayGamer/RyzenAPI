-- Lua provided by RyzenAPI
-- Game: 3155640

-- MAIN APPLICATION
addappid(3155640)
-- Game: addappid(3155640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155641, 1, "0d4bde46c7c91515c73523621bfd728cae6e43d78293dc559db833111f783fe6")
