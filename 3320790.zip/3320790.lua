-- Lua provided by RyzenAPI
-- Game: Game: Caught Lacking - Femboy Edition

-- MAIN APPLICATION
addappid(3320790)
-- Game: addappid(3320790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320791, 1, "b39b0a3f6d974702d56cb0d3abaccb7644b4da688659f8ca082b71733292b825")
