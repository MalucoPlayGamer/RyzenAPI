-- Lua provided by RyzenAPI
-- Game: 寂寞神明的心愿手记

-- MAIN APPLICATION
addappid(1682410)
-- Game: addappid(1682410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682411, 1, "48ecf522dff537246945a239d9bb11b17af12a847985de29f1ea5393022dc991")
