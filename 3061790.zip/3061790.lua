-- Lua provided by RyzenAPI 
-- Game: Vox Populi: USA 2024
addappid(3061790)
addappid(3061791, 1, "b385e91b70aadbf19659ec37a24cc0d3db21b6eb41e429bf387c53ba8a4da84b")
