-- Lua provided by RyzenAPI
-- Game: 3061790

-- MAIN APPLICATION
addappid(3061790)
-- Game: addappid(3061790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3061791, 1, "b385e91b70aadbf19659ec37a24cc0d3db21b6eb41e429bf387c53ba8a4da84b")
