-- 4691990's Lua and Manifest Created by Hubcap Manifest
-- A Weird Game About Sausage
-- Created: August 06, 2026 at 11:25:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4691990, 1, "fb0146a034875c0f1bc58ddfa421c6e8274e2d9c388a433c224e8332510f4beb") -- A Weird Game About Sausage
-- MAIN APP DEPOTS
addappid(4691991, 1, "f6d28b1f70e87d2c168d2a689286382ee4b374b76b7f469c30299d480b0e9b52") -- Depot 4691991
setManifestid(4691991, "7288273297611489446", 990787543)