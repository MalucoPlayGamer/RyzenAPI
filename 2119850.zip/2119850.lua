-- Lua provided by SkyAPI 
-- Game: Maki: Paw of Fury
addappid(2119850)
addappid(2119851, 1, "a862c2c05358671c92ba2ba2815244c184eafaf2ecac8a1a885d228279c0630e")
