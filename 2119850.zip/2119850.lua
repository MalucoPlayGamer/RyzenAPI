-- Lua provided by RyzenAPI
-- Game: Maki: Paw of Fury

-- MAIN APPLICATION
addappid(2119850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119851, 1, "a862c2c05358671c92ba2ba2815244c184eafaf2ecac8a1a885d228279c0630e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3167870)
addappid(3167880)
addappid(3167890)
