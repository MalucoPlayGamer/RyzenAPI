-- Lua provided by RyzenAPI
-- Game: 2000190

-- MAIN APPLICATION
addappid(2000190)
-- Game: addappid(2000190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000191, 1, "9004d9d4e766e81724c95e81cb6fa347dd26accf5ab1101b5f4ffd070230c9cd")
