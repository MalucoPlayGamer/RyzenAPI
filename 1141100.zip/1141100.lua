-- Lua provided by RyzenAPI
-- Game: Lilitales

-- MAIN APPLICATION
addappid(1141100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141101, 1, "0df173864d1ac34c543fb837c639d3997df280af4a43a3b02cbb64c4d0e8f969")
addappid(1141102, 1, "e9284ae858b4e8a8793aa9678a194975b068a02bbbd7f17d6b3140bed0bf7c8f")

