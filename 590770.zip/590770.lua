-- Lua provided by RyzenAPI
-- Game: Vectonic

-- MAIN APPLICATION
addappid(590770)

-- MAIN APP DEPOTS / PACKAGES
addappid(590771, 1, "57324366e7a8d180e33a2cb5937c193c06efd99819c6351c54d00c0aaa97ef6c")

