-- Lua provided by RyzenAPI
-- Game: Game: Red Planet Rampart

-- MAIN APPLICATION
addappid(2711230)
-- Game: addappid(2711230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711231, 1, "b034eeaecc73c5f7b326d0ddf1b5bdb3bfa5b2c4b054a19273560b52e556467d")
