-- Lua provided by RyzenAPI
-- Game: 2234600

-- MAIN APPLICATION
addappid(2234600)
-- Game: addappid(2234600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234601, 1, "01180b703702f56880eb06515befc58c249988055df2d923336398ca4b6bab21")
addappid(2234602, 1, "b070bdff6f60f1aee8512e6214d4e86eb039f74f0d7bc8befbcc10cdb02db8e8")
