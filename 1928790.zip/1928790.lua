-- Lua provided by SkyAPI 
-- Game: AppID 1928790
addappid(1928790)
addappid(1928791, 1, "455d0707434f44c60e3f0d0945cea452df90ca7c58d12706e99e82eb72db4b61")
addappid(1928795, 1, "82f9b7910f8a1507ce1ffec62778199f83898d45d8ec85fbd7a59d6d79b44ee9")
