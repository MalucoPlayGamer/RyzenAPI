-- Lua provided by RyzenAPI
-- Game: 2684010

-- MAIN APPLICATION
addappid(2684010)
-- Game: addappid(2684010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684011, 1, "84f984047bcf927d79d0d783ebea4322fd436d6063a76eb921fe6aa37265a10f")
