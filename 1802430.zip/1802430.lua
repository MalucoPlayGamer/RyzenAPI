-- Lua provided by RyzenAPI
-- Game: A Maze Fox

-- MAIN APPLICATION
addappid(1802430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802431, 1, "445b0173b026c7fa4eaa3c985061197459aad2fc4e9d7ad17f0d942561620f14")
