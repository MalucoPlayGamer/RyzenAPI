-- Lua provided by RyzenAPI 
-- Game: AppID 376620
addappid(376620)
addappid(376621, 1, "3d8fb900a39e639ffc6b469340709f2a5d0abc55906da3b799c467007941913b")
