-- Lua provided by RyzenAPI
-- Game: The Princess, the Stray Cat, and Matters of the Heart 2

-- MAIN APPLICATION
addappid(1128260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128261, 1, "7445558ec7b9491cc3a3ace14df9ef9a74e49c2d151d50ccc06228490faab35a")
addappid(1186540, 0, "aeb987eabff5d1166d8ff1267444d443617122dbff474d4de409d951b079fa49")
