-- Lua provided by RyzenAPI
-- Game: 448610

-- MAIN APPLICATION
addappid(448610)
-- Game: addappid(448610)

-- MAIN APP DEPOTS / PACKAGES
addappid(448612,0,"bd1bf860f365c9242cdc816da8a5b2e39f8247f2b80648c24407804571423aa1")
