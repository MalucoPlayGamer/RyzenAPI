-- Lua provided by RyzenAPI
-- Game: 2586710

-- MAIN APPLICATION
addappid(2586710)
-- Game: addappid(2586710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586711, 1, "e7a2a101d563bc845dfacff78e67bce69307f5bc85afd1ae3dfea7a17d62a8b1")
