-- Lua provided by RyzenAPI
-- Game: 鬼人偶/Ghost Doll

-- MAIN APPLICATION
addappid(2017600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017601, 1, "f86b68be26402a168dc62a6659ace24e2fd5a24bc590fd049f3d6bf3e9175548")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
