-- Lua provided by RyzenAPI
-- Game: 鬼人偶/Ghost Doll

-- MAIN APPLICATION
addappid(2017600)
-- Game: addappid(2017600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017601, 1, "f86b68be26402a168dc62a6659ace24e2fd5a24bc590fd049f3d6bf3e9175548")
