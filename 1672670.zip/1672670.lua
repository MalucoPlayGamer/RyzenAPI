-- Lua provided by RyzenAPI
-- Game: 彷徨之街 The Street of Adrift

-- MAIN APPLICATION
addappid(1672670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672671, 1, "c533a45a4e94ed704c34ee330d6f2e5f2969396d60b213688ea5218eb06efcf8")
