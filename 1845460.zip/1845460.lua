-- Lua provided by RyzenAPI 
-- Game: Milo
addappid(1845460)
addappid(1845461, 1, "6e0f21c590a6161f2520b421c397235bc947118aca57f214c139be7e5f877431")
