-- Lua provided by RyzenAPI
-- Game: Tell me your story

-- MAIN APPLICATION
addappid(1415570) -- Tell me your story
addappid(2851070) -- Tell Me Your Story - Rose Artbook
addappid(2851080) -- Tell Me Your Story - Peanut Artbook
addappid(2851090) -- Tell Me Your Story - Amelia Artbook

-- MAIN APP DEPOTS / PACKAGES
addappid(1415571, 1, "07c50b0153e27a107abac59629065a76265eae722dc4374c0d210ff6d9efff0e") -- Depot 1415571

