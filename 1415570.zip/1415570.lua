-- Lua provided by RyzenAPI 
-- Game: Tell Me Your Story
addappid(1415570)
addappid(1415571, 1, "07c50b0153e27a107abac59629065a76265eae722dc4374c0d210ff6d9efff0e")
