-- Lua provided by RyzenAPI
-- Game: Sokobond Express

-- MAIN APPLICATION
addappid(1701330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1701331, 1, "951071e735aebd8709e33876eacbae41bf6b1782f230325b85ae460c8fa7e098")
addappid(1701332, 1, "c221927d4520995964f980abd4679da6a3099c3d76967b642e38214bb8669637")
addappid(1701333, 1, "7aa46167f7c0317a25770c438f1678f05308e9827a34cb26292feefd50120c52")

