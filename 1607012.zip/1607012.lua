-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1607012)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607012,0,"5769c59d7cf4a036fe9287374f3e37b8cd1878b6494e98a015ed637488072525")
