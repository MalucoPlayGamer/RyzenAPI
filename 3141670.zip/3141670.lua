-- Lua provided by SkyAPI 
-- Game: Wander Hero Demo
addappid(3141670)
addappid(3141671, 1, "594b438b5dcdba0c1dc833577d71e1c4f6ab1188cd6f9728e7d18b8aea365931")
