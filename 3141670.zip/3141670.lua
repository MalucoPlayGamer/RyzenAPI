-- Lua provided by RyzenAPI
-- Game: Wander Hero Demo

-- MAIN APPLICATION
addappid(3141670)
-- Game: addappid(3141670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141671, 1, "594b438b5dcdba0c1dc833577d71e1c4f6ab1188cd6f9728e7d18b8aea365931")
