-- Lua provided by RyzenAPI
-- Game: Factory Engineer

-- MAIN APPLICATION
addappid(514290)

-- MAIN APP DEPOTS / PACKAGES
addappid(514291,0,"3931e8d301ece2597b1a6281342bef26984655164eae25691410c5fb76a4a4bb")
addappid(514292,0,"460c8cb632ec28ac5c04e2bff6de8764cbbfd396ab7540f3a1dab804ef15888a")
addappid(514293,0,"3e79340e61ebeb6b3d0a9d729380465c228881322d959dd7efeafb15f9aff738")

