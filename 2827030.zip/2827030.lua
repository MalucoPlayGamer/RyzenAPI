-- Lua provided by RyzenAPI
-- Game: ARK: The Center Ascended

-- MAIN APPLICATION
addappid(2827030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827030,0,"ca47571a30440cd0d827bee6a57a945cf56d25fd4dbc19435d608994b021302a")

