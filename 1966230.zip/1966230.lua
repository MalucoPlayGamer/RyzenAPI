-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1966230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966235,0,"dcf780591037496f982a1b28b49c9206c162f03673827ed5d4803aaaaa04a145")

