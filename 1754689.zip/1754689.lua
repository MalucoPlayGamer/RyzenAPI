-- Lua provided by RyzenAPI
-- Game: 1754689

-- MAIN APPLICATION
addappid(1754689)
-- Game: addappid(1754689)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754689,0,"8e2305c7b006bfa0897d3829a86905e4b2b5c16d0ecdff30ef23ff218b70759e")
