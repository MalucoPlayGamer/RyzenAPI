-- Lua provided by RyzenAPI 
-- Game: AppID 859640
addappid(859640)
addappid(859641, 1, "6cebe057c760b78675c8e0e9347b10ce73758de2d079852743e8dfb2332fd8e2")
