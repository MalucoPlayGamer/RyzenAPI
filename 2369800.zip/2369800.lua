-- Lua provided by SkyAPI 
-- Game: Choo Choo Survivor Demo
addappid(2369800)
addappid(2369801, 1, "c27907ff2085b9ee6ebbdb933a4c507ef415933d9064f9de935089f465949159")
