-- Lua provided by RyzenAPI
-- Game: Hilda and the tower of Lust

-- MAIN APPLICATION
addappid(2551290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551291, 1, "98ffb3ce298d2d3f1d6df90b1038b9be34f5ed6bcc03ed17c99b487a899c0914")
addappid(2551292, 1, "64a60888b63fe8540f1fc22ff0c7153ce93207a24079c7bafe015e80e40c4a9f")
addappid(2551293, 1, "1e01defccd4dcf87d104642a48be975d5a81d668b3eddf9f4bfe26b931ade976")
addappid(2551294, 1, "927d5238f5d001637c78ee5df25e064fe6218d6ebabde2bfc65962a4b45c5076")
