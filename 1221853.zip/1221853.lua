-- Lua provided by RyzenAPI
-- Game: AUDICA - asms - "Reeds of Mitatrush"

-- MAIN APPLICATION
addappid(1221853)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221853,0,"90e436e263f9e11bfff2fb29a0359ecc12472c6fee2eb06155f2661c447165fa")

