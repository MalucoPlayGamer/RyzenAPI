-- Lua provided by RyzenAPI
-- Game: 3431040

-- MAIN APPLICATION
addappid(3431040)
-- Game: addappid(3431040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3431041, 1, "cc51fcec3d8dda778605464eef88ae266cdbc612a843106a170839a7060289fc")
