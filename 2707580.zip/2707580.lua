-- Lua provided by RyzenAPI
-- Game: Safe House

-- MAIN APPLICATION
addappid(2707580)
-- Game: addappid(2707580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707581, 1, "80077ebc4849c66d5a8717e0224ba0ac51b5efe8a1feaed2f636431d2a3b06e5")
