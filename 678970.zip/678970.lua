-- Lua provided by RyzenAPI
-- Game: 678970

-- MAIN APPLICATION
addappid(678970)
-- Game: addappid(678970)

-- MAIN APP DEPOTS / PACKAGES
addappid(678971, 1, "f86ee222b289e64fce346bce109b5f11cb41b9ec341044ec0a34491dbefa4fba")
