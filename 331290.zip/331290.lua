-- Lua provided by RyzenAPI
-- Game: Miko Gakkou: Second Year

-- MAIN APPLICATION
addappid(331290)
-- Game: addappid(331290)

-- MAIN APP DEPOTS / PACKAGES
addappid(331291, 1, "07356931333434b06841d7d6863889b5269177fe191a62f380e7aee14f602939")
