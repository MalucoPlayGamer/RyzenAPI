-- Lua provided by RyzenAPI
-- Game: 1053760

-- MAIN APPLICATION
addappid(1053760)
-- Game: addappid(1053760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053761, 1, "f8cbe2ecc79fae86f0e5fc22eac21d1e5d5b99198e024c36a54bd62f612e639e")
