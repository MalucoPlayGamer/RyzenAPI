-- Lua provided by RyzenAPI
-- Game: Game: AppID 1094870

-- MAIN APPLICATION
addappid(1094870)
-- Game: addappid(1094870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094871, 1, "f2ad6cb2376ac03af5620aa80433db9e8e310bec98488fa5cfa604e69a01ee26")
