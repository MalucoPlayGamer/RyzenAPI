-- Lua provided by RyzenAPI
-- Game: 2650930

-- MAIN APPLICATION
addappid(2650930)
-- Game: addappid(2650930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650930,0,"3b3ff890a97c73af5ee3c6a5230239921298294a851be87cf34e7dabcc54864a")
