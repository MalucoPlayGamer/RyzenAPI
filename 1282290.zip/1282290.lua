-- Lua provided by RyzenAPI
-- Game: Holdfast: Nations At War - SDK

-- MAIN APPLICATION
addappid(1282290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282291, 1, "039084314573bf20e55dfa9c9dcb100fd5722ec5af8eddbe73cd6eaf9d8141cd")
