-- Lua provided by RyzenAPI
-- Game: STAR WARS Jedi: Survivor™

-- MAIN APPLICATION
addappid(1774580)
addappid(2161370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774581, 1, "94d6a0b0e4e36aadffcbc197792207f773276593c72faf9b02b4b4200135a36f")
addappid(1774582, 1, "b6efa1ef672dce88aa6a6a094211c19110ebe78cf04b8bb87f7ba76e7cf15243")
addappid(3340993, 1, "0f76c015b201b1c8249b6a433ef0873f41ef923a5653bef68f10f8cbc051f414")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1774590)
addappid(2161740)
addappid(2161741)
addappid(2161742)
addappid(2334020)
