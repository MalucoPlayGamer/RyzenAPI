-- Lua provided by RyzenAPI
-- Game: STAR WARS Jedi: Survivor™

-- MAIN APPLICATION
addappid(1774580)
addappid(2161370)
-- Game: addappid(1774580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774581, 1, "94d6a0b0e4e36aadffcbc197792207f773276593c72faf9b02b4b4200135a36f")
addappid(1774582, 1, "b6efa1ef672dce88aa6a6a094211c19110ebe78cf04b8bb87f7ba76e7cf15243")
addappid(3340993, 1, "0f76c015b201b1c8249b6a433ef0873f41ef923a5653bef68f10f8cbc051f414")
