-- Lua provided by RyzenAPI
-- Game: EMERGENCY

-- MAIN APPLICATION
addappid(850170)

-- MAIN APP DEPOTS / PACKAGES
addappid(850171, 1, "6090bf1ee1d2a41e5508537c28e84b6eea51d774b841eaf4ee9b51637a081291")
addappid(850172, 1, "aa065557f7c98c8e40679ff83caa3c2626826e3bd56d93d0cd2f4b8ca9a1592d")
addappid(850173, 1, "ff87a1b152a382fe473065ebeac492cb811c929956c194888925ba89abb23876")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
