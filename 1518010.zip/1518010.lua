-- Lua provided by RyzenAPI
-- Game: AppID 1518010

-- MAIN APPLICATION
addappid(1518010)
-- Game: addappid(1518010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518011, 1, "cf95173740efa6ac4fac10114e67cba5dcda264175cf92a809c4599fec9f8636")
