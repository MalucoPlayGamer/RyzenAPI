-- Lua provided by RyzenAPI
-- Game: Adventure Allies

-- MAIN APPLICATION
addappid(3003680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3003681, 1, "7c266c233c1a8af1df7d1e591019d43d637c7184fbe7ed06b9b9ee27a570ce0d")
