-- Lua provided by RyzenAPI
-- Game: Figure Shop Simulator

-- MAIN APPLICATION
addappid(3604560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3604561,0,"d03520f4a6486c7f802870eb7e44c7268dd1d657627cd9ec2cd3488f7bdbfa66")

