-- Lua provided by RyzenAPI
-- Game: AppID 1238040

-- MAIN APPLICATION
addappid(1238040)
addappid(1238050)
addappid(1295710)
addappid(1295712)
addappid(1295713)
addappid(1295714)
addappid(1295715)
addappid(1295716)
addappid(1295717)
addappid(1295718)
addappid(1295719)
addappid(1295720)
addappid(1295721)
addappid(1295722)
addappid(1295723)
addappid(1295724)
addappid(1295725)
addappid(1295726)
addappid(1295727)
addappid(1978860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1238041, 1, "08a3ec0a1b51976e2b521880a921c4dde15e493a470e886cf19ea4b5aa07e7e9")
addappid(1238042, 1, "c7a969cc36689d88a9e8aa904e607a3de7cb43fc060c15c4e9f5bad6d8def1d0")
addappid(1238043, 1, "ced8a8da227e381ed4aa47cc46e558f1543fe799aeefa5253bded9cf6c6729fa")
addappid(1238044, 1, "498b81afab583f2e8459f557dfa30e02c030059363ab5a54996b135d38bb8ce7")
addappid(1238045, 1, "cb5b2dffc15dd03506553b0274fbce52cf312a321ca22a6914ff6af7372ea90e")
addappid(1238046, 1, "79857925711acc8a4add20bafa227f98ded2728c32da78cb53a32524d4f1260e")
addappid(1238047, 1, "09d433f78e4b866ced9aa7a2195d643e2e132f91a39a8125354dfc0cdb8fdd0a")
addappid(1238048, 1, "9730ddfceb15ee498cff2852df766cd9d3579aff2e1756ee3c28b5dd72c27824")

