-- Lua provided by RyzenAPI
-- Game: Game: AppID 710270

-- MAIN APPLICATION
addappid(710270)
-- Game: addappid(710270)

-- MAIN APP DEPOTS / PACKAGES
addappid(710271, 1, "c32c2583261c779a7c858f5f982e71afe806ea8b8d14352504488522df04f122")
