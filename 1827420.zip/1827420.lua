-- Lua provided by RyzenAPI
-- Game: addappid(1827420)

-- MAIN APPLICATION
addappid(1827420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827421, 1, "ee7cfae26320db22f559565da380d2ec00567250320e15ff8321f3ef721a81c9")
