-- Generated with Luie @ https://lua.tools/
-- 4787680 - Furry Adventure 2
-- Generated 2026-07-30 17:20:57 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4787680)

-- Main Depots
addappid(4787681, 1, "8f91b94a85847ffcbea3a13fd836c72a74ddc7da110e58a67a075154646b2e73")
setManifestid(4787681, "4996320061682665430", 3240882389)
