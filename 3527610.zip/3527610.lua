-- Lua provided by RyzenAPI
-- Game: Game: Money Theft

-- MAIN APPLICATION
addappid(3527610)
-- Game: addappid(3527610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3527611, 1, "a5d1a06ef764858f647760d3e4b8717b0c2b611bc55f5d5e6da971818123ff3e")
