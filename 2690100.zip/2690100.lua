-- Lua provided by RyzenAPI
-- Game: TYPECAST Soundtrack

-- MAIN APPLICATION
addappid(2690100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690101, 1, "edb1606eadc577dfc1093f4d84462aacccf52a81733623cae5bc8b40e586afe7")
addappid(2690102, 1, "d200593544a77d71802d5207e6daa3222f672afc5165df6e4782b0bdc1882ba2")
