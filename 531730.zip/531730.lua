-- Lua provided by RyzenAPI
-- Game: Corona Blossom Vol.2 The Truth From Beyond

-- MAIN APPLICATION
addappid(531730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(531731, 1, "3a5ecbf007c1a2163f82c88c7cdd9464ab2a6e25771cab3206d8c953b351dee7")
addappid(531732, 1, "f3b120745c5bf52eae5627341ab8e069de4f655dab102108c90a61f9c9a97e46")

