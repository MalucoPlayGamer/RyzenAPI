-- Lua provided by RyzenAPI
-- Game: Game: Pedro's Adventures in Spanish [Learn Spanish]

-- MAIN APPLICATION
addappid(1602930)
-- Game: addappid(1602930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602931, 1, "494308dffb78f3d69ba5b5a64a96876429707b94c02243b8211629865c1e3cb5")
