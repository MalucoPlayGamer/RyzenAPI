-- Lua provided by RyzenAPI
-- Game: Game: Hijacker Jack : ARCADE FMV

-- MAIN APPLICATION
addappid(1422730)
-- Game: addappid(1422730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422731, 1, "718d021c5dd3931a157a40194b96c658199943246416c6fa2de26096955f0f4b")
