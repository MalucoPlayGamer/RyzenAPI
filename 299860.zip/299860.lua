-- Lua provided by RyzenAPI
-- Game: Beasts of Prey

-- MAIN APPLICATION
addappid(299860)

-- MAIN APP DEPOTS / PACKAGES
addappid(299861, 1, "bb41a84ddf3273a7d6254a254b6bee1af0c753f8659fa59ce196217f89be7146")
addappid(299862, 1, "2e1dfbe09d029165ef420e05db5c0c153b67b9093b1d9876b05eee840bf4bb30")
addappid(299863, 1, "a8abf838522dd10dabdef3f32481ccb099242add34826d19637cca136eddcaa9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
