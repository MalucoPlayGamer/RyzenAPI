-- Lua provided by RyzenAPI
-- Game: Beasts of Prey

-- MAIN APPLICATION
addappid(299860)
-- Game: addappid(299860)

-- MAIN APP DEPOTS / PACKAGES
addappid(299861, 1, "bb41a84ddf3273a7d6254a254b6bee1af0c753f8659fa59ce196217f89be7146")
addappid(299862, 1, "2e1dfbe09d029165ef420e05db5c0c153b67b9093b1d9876b05eee840bf4bb30")
addappid(299863, 1, "a8abf838522dd10dabdef3f32481ccb099242add34826d19637cca136eddcaa9")
