-- Lua provided by RyzenAPI
-- Game: Game: Crysis Remastered

-- MAIN APPLICATION
addappid(1715130)
-- Game: addappid(1715130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715131, 1, "24355fe086b76003e1311e9e110fa69dfa08cb060f9f31d9d91af0a32fc37234")
