-- Lua provided by RyzenAPI
-- Game: addappid(1076580)

-- MAIN APPLICATION
addappid(1076580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076580,0,"99e55e27d7f9f46e140d5d8129048c4ef1fb721e22f52b358be15e1aee791738")
