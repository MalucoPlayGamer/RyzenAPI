-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2291520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291520,0,"589af9532bbae680183d84886f8be081df702bef77603b295f7ab71371d0465d")
