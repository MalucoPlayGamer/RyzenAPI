-- Lua provided by RyzenAPI
-- Game: Game: AppID 368220

-- MAIN APPLICATION
addappid(368220)
-- Game: addappid(368220)

-- MAIN APP DEPOTS / PACKAGES
addappid(368221, 1, "83dab33a0e382b45f7abde03d3c60e30fb00746367cdb717038ce07cd90d6dfc")
addappid(368222, 1, "351df8f00c33ec81f5e95d58ba674d0117eb5b5d4347b3cb076a35c7f51721d1")
