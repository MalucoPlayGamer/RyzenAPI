-- Lua provided by RyzenAPI 
-- Game: RAKETENWASCHMACHINE
addappid(1556120)
addappid(1556121, 1, "90541901a25f4dc7a388b1441729f17c812bb4529727a9e6cba22f5c8799cc2e")
