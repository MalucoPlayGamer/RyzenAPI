-- Lua provided by RyzenAPI
-- Game: Rite of Passage: Hide and Seek Collector's Edition

-- MAIN APPLICATION
addappid(786090)
-- Game: addappid(786090)

-- MAIN APP DEPOTS / PACKAGES
addappid(786091, 1, "ba12674d616e7de9e35b1fc722df17573b99b776d8de89c9e7d0d1459b7a25f9")
