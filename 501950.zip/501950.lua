-- Lua provided by RyzenAPI
-- Game: Rogue Islands

-- MAIN APPLICATION
addappid(501950)

-- MAIN APP DEPOTS / PACKAGES
addappid(501951, 1, "692120d9cd155d41d31f1c374c2ce3e8e8466411ebe77a08fa7364da671196d4")
