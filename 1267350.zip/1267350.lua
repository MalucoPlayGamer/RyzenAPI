-- Lua provided by RyzenAPI 
-- Game: AppID 1267350
addappid(1267350)
addappid(1267351, 1, "7cb55ea31f40f898bae9f4ba84811bbc0387c38322feaa1e680b18ec3a2bb528")
