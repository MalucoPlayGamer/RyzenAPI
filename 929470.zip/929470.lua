-- Lua provided by RyzenAPI
-- Game: Mahjong Valentine's Day

-- MAIN APPLICATION
addappid(929470)

-- MAIN APP DEPOTS / PACKAGES
addappid(929475,0,"bbdcec72ed23ed5c91d68ad9e9cc2e71f914adbdd17da004adc917c9a8790318")

