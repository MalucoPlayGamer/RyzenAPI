-- Lua provided by RyzenAPI
-- Game: VR Regatta - The Sailing Game

-- MAIN APPLICATION
addappid(468240)
addappid(979340)

-- MAIN APP DEPOTS / PACKAGES
addappid(468241, 1, "df74c97035207a3d95f2c8ea734a6ccc29b7b020b6671f124d9f60278954a549")
addappid(1040100, 0, "6687fe35c7e87e93ae6f7aad29d357b2adee9b5a432a9b401ec36e3e5583b94f")
