-- Lua provided by RyzenAPI
-- Game: Sheaf - Together EP

-- MAIN APPLICATION
addappid(1072530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072531, 1, "e8da847da837b7ffdcc873e2b04833573d9e8ad8dcf913ded5be27949efe702b")
