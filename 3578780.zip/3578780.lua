-- Lua provided by RyzenAPI
-- Game: 3578780

-- MAIN APPLICATION
addappid(3578780)
-- Game: addappid(3578780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578781, 1, "5419685cf1fbff506f9e1866fbb3d500057abb081bdf239f099bfc2e1b042d5f")
