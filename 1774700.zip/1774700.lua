-- Lua provided by RyzenAPI
-- Game: INVERT

-- MAIN APPLICATION
addappid(1774700)
-- Game: addappid(1774700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774701, 1, "8f72f7ef9fa9229adedd0dafdc221a5472f13637c199cf8b216bbf50df619fe2")
