-- Lua provided by SkyAPI 
-- Game: My Universe - Cooking Star Restaurant
addappid(1407190)
addappid(1407191, 1, "8e315ae68a1ac3d34836c6d8d3fedac4d0b9ab4693185076c5e55145735b6add")
