-- Lua provided by RyzenAPI
-- Game: My Universe - Cooking Star Restaurant

-- MAIN APPLICATION
addappid(1407190)
-- Game: addappid(1407190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407191, 1, "8e315ae68a1ac3d34836c6d8d3fedac4d0b9ab4693185076c5e55145735b6add")
