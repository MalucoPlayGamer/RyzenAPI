-- Lua provided by RyzenAPI
-- Game: Game: AppID 695970

-- MAIN APPLICATION
addappid(695970)
-- Game: addappid(695970)

-- MAIN APP DEPOTS / PACKAGES
addappid(695971, 1, "efa126e09b1c7514851909a917c7eee18ae0a60ebdc37bf336a904b38d953c76")
addappid(791230, 0, "81ef2147ad9d6ee9ba3d296ad6402ef73402de435fafa2282bb7c628821aad0f")
