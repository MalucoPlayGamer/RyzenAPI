-- Lua provided by RyzenAPI
-- Game: 3756640

-- MAIN APPLICATION
addappid(3756640)
-- Game: addappid(3756640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3756641, 1, "b627e6ad73246f4bfc3caad6f2ffac92b802fc85e11bfb5c8c5f6a22aba933d0")
