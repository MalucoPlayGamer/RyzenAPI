-- Lua provided by RyzenAPI
-- Game: 2993640

-- MAIN APPLICATION
addappid(2993640)
-- Game: addappid(2993640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993641, 1, "daeb6aa47148392090e3b28247e08ed698b675c92e60d9f1fa7f7a94dc486ba1")
