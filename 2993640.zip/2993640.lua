-- Lua provided by RyzenAPI 
-- Game: AppID 2993640
addappid(2993640)
addappid(2993641, 1, "daeb6aa47148392090e3b28247e08ed698b675c92e60d9f1fa7f7a94dc486ba1")
