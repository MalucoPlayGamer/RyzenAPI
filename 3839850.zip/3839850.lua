-- Lua provided by RyzenAPI
-- Game: Crystal of Atlan

-- MAIN APPLICATION
addappid(3839850)
