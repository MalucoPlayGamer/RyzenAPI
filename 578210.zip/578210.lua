-- Lua provided by RyzenAPI
-- Game: AppID 578210

-- MAIN APPLICATION
addappid(578210)

-- MAIN APP DEPOTS / PACKAGES
addappid(578211, 1, "e5ee44a06a9d0182fe1cccbe639a0f47a05652f99dacb3c1e0aef7afc7bf1193")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
