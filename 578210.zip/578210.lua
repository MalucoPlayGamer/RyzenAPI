-- Lua provided by RyzenAPI
-- Game: Game: AppID 578210

-- MAIN APPLICATION
addappid(578210)
-- Game: addappid(578210)

-- MAIN APP DEPOTS / PACKAGES
addappid(578211, 1, "e5ee44a06a9d0182fe1cccbe639a0f47a05652f99dacb3c1e0aef7afc7bf1193")
