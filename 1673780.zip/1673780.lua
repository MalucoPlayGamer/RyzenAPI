-- Lua provided by RyzenAPI
-- Game: Game: New Meaning

-- MAIN APPLICATION
addappid(1673780)
-- Game: addappid(1673780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673781, 1, "1d23cd4e4a302fa5e92a48e5167b9a7c05a0445c7352e2818cf81ff663118f2c")
