-- Lua provided by RyzenAPI 
-- Game: New Meaning
addappid(1673780)
addappid(1673781, 1, "1d23cd4e4a302fa5e92a48e5167b9a7c05a0445c7352e2818cf81ff663118f2c")
