-- Lua provided by RyzenAPI
-- Game: The Durka: You will (not) die

-- MAIN APPLICATION
addappid(1595380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595382,0,"cd845d2d86d48cf8fd7b7da6c05e60d57b1077986416511c5268aa223c8cfd87")
