-- Lua provided by RyzenAPI
-- Game: Cubic Cosmos

-- MAIN APPLICATION
addappid(3332600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332601,0,"74ad616dffca7e41b002a8a879e69b2f184763eb812d4f589dd81dda0a09268a")

