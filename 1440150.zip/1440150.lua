-- Lua provided by RyzenAPI
-- Game: Pixel Survivor - Pixel Up!

-- MAIN APPLICATION
addappid(1440150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440154,0,"57c22ac58b13e1163f738fc75ee7547b776c670af3173f156358dc3548863c00")
