-- Lua provided by RyzenAPI
-- Game: Unsung Heroes: The Golden Mask

-- MAIN APPLICATION
addappid(1029870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029871, 1, "931a1500612e40c6b4336e893a936e4670cad61d2a21dc83b0354075b02c093b")
