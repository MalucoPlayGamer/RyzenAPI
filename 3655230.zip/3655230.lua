-- Lua provided by SkyAPI 
-- Game: AppID 3655230
addappid(3655230)
addappid(3655231, 1, "e14dbd05b8dc650e2673d85f92d72af5efea25828e3288f2b506c0029b79f2e8")
