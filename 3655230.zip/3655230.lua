-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Mumbai

-- MAIN APPLICATION
addappid(3655230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655231, 1, "e14dbd05b8dc650e2673d85f92d72af5efea25828e3288f2b506c0029b79f2e8")
