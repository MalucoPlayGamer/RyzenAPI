-- Lua provided by RyzenAPI
-- Game: Game: The Wendigo

-- MAIN APPLICATION
addappid(603230)
-- Game: addappid(603230)

-- MAIN APP DEPOTS / PACKAGES
addappid(603231, 1, "d389744b8c858246313af8a69af7404260898199262d91641e4362f5e921aa59")
