-- Lua provided by SkyAPI 
-- Game: The Wendigo
addappid(603230)
addappid(603231, 1, "d389744b8c858246313af8a69af7404260898199262d91641e4362f5e921aa59")
