-- Lua provided by RyzenAPI
-- Game: 355560

-- MAIN APPLICATION
addappid(355560)
addappid(450870)
addappid(450890)
-- Game: addappid(355560)

-- MAIN APP DEPOTS / PACKAGES
addappid(355561, 1, "f3c290dde213309da3f0a885f97f2c0850d508ea83782c261937b04703fa531d")
