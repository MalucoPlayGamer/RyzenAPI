-- Lua provided by RyzenAPI 
-- Game: Trigger Runners
addappid(355560)
addappid(355561, 1, "f3c290dde213309da3f0a885f97f2c0850d508ea83782c261937b04703fa531d")
addappid(450870)
addappid(450890)
