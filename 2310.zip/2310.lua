-- Lua provided by RyzenAPI
-- Game: Quake

-- MAIN APPLICATION
addappid(2310)
-- Game: addappid(2310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311, 1, "d854f0dbf7aef388219ae3af1c437d156dc6ecd64ef81439e276abbec1872689")
