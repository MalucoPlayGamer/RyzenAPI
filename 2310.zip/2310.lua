-- Lua provided by RyzenAPI
-- Game: Quake

-- MAIN APPLICATION
addappid(2310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311, 1, "d854f0dbf7aef388219ae3af1c437d156dc6ecd64ef81439e276abbec1872689")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
