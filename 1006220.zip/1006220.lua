-- Lua provided by RyzenAPI
-- Game: Type Knight

-- MAIN APPLICATION
addappid(1006220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006221, 1, "6657268a42e97c1b688bf86b84cd99a252cf416f9a2ca48238163d86e46120b1")

