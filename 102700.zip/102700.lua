-- Lua provided by RyzenAPI
-- Game: A.V.A. Alliance of Valiant Arms™

-- MAIN APPLICATION
addappid(102700)
addappid(224240)
addappid(224241)
addappid(224242)
addappid(224243)
addappid(224244)
addappid(224245)
addappid(306300)
addappid(333850)
addappid(334050)
addappid(334060)
addappid(539100)
addappid(539101)
addappid(539102)
addappid(539103)
addappid(539104)

-- MAIN APP DEPOTS / PACKAGES
addappid(102701,0,"e66050361f7f3b2106063586f8495479e8da775676b8f4c0e9a1eac5255afd61")

