-- Lua provided by RyzenAPI
-- Game: AppID 102700

-- MAIN APPLICATION
addappid(102700)
-- Game: addappid(102700)

-- MAIN APP DEPOTS / PACKAGES
addappid(102701, 1, "e66050361f7f3b2106063586f8495479e8da775676b8f4c0e9a1eac5255afd61")
