-- Lua provided by RyzenAPI
-- Game: Flight Sim World

-- MAIN APPLICATION
addappid(389280)
addappid(389291)
addappid(630911)
addappid(630912)
addappid(630913)
addappid(630914)
addappid(630915)
addappid(630916)
addappid(630917)
addappid(630919)
addappid(728031)
addappid(728033)
addappid(728034)
addappid(728035)
addappid(728036)
addappid(728037)
addappid(728038)
addappid(728039)
addappid(728040)
addappid(728041)
addappid(728042)
addappid(728043)
addappid(728044)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(389281, 1, "98da055a26706664aa65a72cda49a99b6d4006c9b673241bf43e06ea3a2a37cd")
addappid(389282, 1, "cbea3df975759d7b5421e208498a104c7a54b4f0a6e8c929c85e69ce1791e4e0")
addappid(630910, 0, "beb9b4b01d2232c1bc3a34e2c35a61a03ec34128f9aa7e0100aad3610b520c93")
addappid(630918, 0, "bf01663d3c7d8de0ceaa814512a8d452a84a036d9b11b22536420a62f4146cf3")
addappid(728030, 0, "89c60e46c3e4159db490e1e9904503920c938022a3b022ae2293d03e77b6715c")
addappid(728032, 0, "17abeba4a2b69dfc147bda20e484ded963219aadeca3f2f0c84e714d3ca7336b")

