-- Lua provided by RyzenAPI
-- Game: 2300300

-- MAIN APPLICATION
addappid(2300300)
-- Game: addappid(2300300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300301, 1, "4351ff2357a57d9d1ffa322c0581c5f4acefe518f2513ca378503a6093e7a3e0")
