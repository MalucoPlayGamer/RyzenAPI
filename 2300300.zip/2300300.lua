-- Lua provided by RyzenAPI 
-- Game: Growth
addappid(2300300)
addappid(2300301, 1, "4351ff2357a57d9d1ffa322c0581c5f4acefe518f2513ca378503a6093e7a3e0")
