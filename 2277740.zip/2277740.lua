-- Lua provided by RyzenAPI 
-- Game: Steer Madness
addappid(2277740)
addappid(2277741, 1, "f8419f7aaacf1adbf046cbca329b8ce7e3bb70bdc2792b6628396f6c0d101992")
addappid(2277742, 1, "97b1872f81b3bd3585255c81d172d7e83989807741d4731cd2648aef47ffc069")
