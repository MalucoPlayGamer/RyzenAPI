-- Lua provided by RyzenAPI
-- Game: Steer Madness

-- MAIN APPLICATION
addappid(2277740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277741, 1, "f8419f7aaacf1adbf046cbca329b8ce7e3bb70bdc2792b6628396f6c0d101992")
addappid(2277742, 1, "97b1872f81b3bd3585255c81d172d7e83989807741d4731cd2648aef47ffc069")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
