-- Lua provided by RyzenAPI
-- Game: The Black Pepper Crew Demo

-- MAIN APPLICATION
addappid(2160210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160211, 1, "37164466bdf9c6b5e9cfd35daff8be19d7b14639278edcb75c0bc254a3127100")

