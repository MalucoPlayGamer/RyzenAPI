-- Lua provided by RyzenAPI
-- Game: Karagon (Survival Robot Riding FPS)

-- MAIN APPLICATION
addappid(1818610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818611, 1, "4093b254c82aeb2d6c74366eeac13bfcf52f364895fdf38aef9a624d3e1aa96c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
