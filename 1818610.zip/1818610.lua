-- Lua provided by RyzenAPI
-- Game: Karagon (Survival Robot Riding FPS)

-- MAIN APPLICATION
addappid(1818610)
-- Game: addappid(1818610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818611, 1, "4093b254c82aeb2d6c74366eeac13bfcf52f364895fdf38aef9a624d3e1aa96c")
