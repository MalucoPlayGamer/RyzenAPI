-- Lua provided by RyzenAPI
-- Game: Hero Z TPS

-- MAIN APPLICATION
addappid(2187640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187641, 1, "165c4cb917fde905bc27a76207ce7922a86edf3d4b5eaf51e849ee67b79a51db")
