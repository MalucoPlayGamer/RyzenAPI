-- Lua provided by RyzenAPI
-- Game: addappid(2539960)

-- MAIN APPLICATION
addappid(2539960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539961, 1, "dac10501442541a4ba27221d67e05dc9ae3a71803939ba45c6b91f93ccb77110")
