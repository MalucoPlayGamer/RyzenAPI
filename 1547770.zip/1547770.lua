-- Lua provided by RyzenAPI
-- Game: 游戏人生：心魔 Demo

-- MAIN APPLICATION
addappid(1547770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547771, 1, "88e88d7bd663c38835d653c187d5a124a434eca1cfccd881ab5967dac72fc6de")

