-- Lua provided by RyzenAPI
-- Game: SysAdmin Odyssey. Back to the office

-- MAIN APPLICATION
addappid(1794240)
addappid(4693480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1794242,0,"1a434e120da4761aff2011382d10cdb6a4f7fe9e5020e7585e20e54ae00b81d3")

