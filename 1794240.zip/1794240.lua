-- Lua provided by RyzenAPI
-- Game: SysAdmin Odyssey. Back to the office

-- MAIN APPLICATION
addappid(1794240)
addappid(4693480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794242,0,"1a434e120da4761aff2011382d10cdb6a4f7fe9e5020e7585e20e54ae00b81d3")

