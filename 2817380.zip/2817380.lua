-- Lua provided by RyzenAPI 
-- Game: Watch Your Eggs! VR Demo
addappid(2817380)
addappid(2817381, 1, "6961ef22ab5d866f240ec75d16e9ec7f4b827d3dad06cd1785345c8959a84779")
