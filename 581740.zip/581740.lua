-- Lua provided by RyzenAPI
-- Game: AppID 581740

-- MAIN APPLICATION
addappid(581740)

-- MAIN APP DEPOTS / PACKAGES
addappid(581741, 1, "da8727f9a786936f13725f49ba2d6c17acd097ef2aeeaa924651ef02ee3181e1")

