-- Lua provided by RyzenAPI
-- Game: HUNGER

-- MAIN APPLICATION
addappid(581740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(581741, 1, "da8727f9a786936f13725f49ba2d6c17acd097ef2aeeaa924651ef02ee3181e1")

