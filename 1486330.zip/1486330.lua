-- Lua provided by RyzenAPI
-- Game: 1486330

-- MAIN APPLICATION
addappid(1486330)
-- Game: addappid(1486330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486331, 1, "d4602a5a45058cb233b2b0ac2be9cdc2f0fdcc16036b4276b0bd45e3911204c0")
