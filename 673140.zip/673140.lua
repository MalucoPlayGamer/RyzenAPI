-- Lua provided by RyzenAPI
-- Game: AppID 673140

-- MAIN APPLICATION
addappid(673140)
-- Game: addappid(673140)

-- MAIN APP DEPOTS / PACKAGES
addappid(673141, 1, "33b77b082f7becb97ed7d685dcb6a9949b27434219dd3c43d99489a14e952639")
