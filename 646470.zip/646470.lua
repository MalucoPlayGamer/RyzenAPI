-- Lua provided by RyzenAPI
-- Game: Alicia Quatermain: Secrets Of The Lost Treasures

-- MAIN APPLICATION
addappid(646470)

-- MAIN APP DEPOTS / PACKAGES
addappid(646471, 1, "ee6e45e3171757a81fb5b12e0e79d4d19a42a4bacd27ba6d923176dd18caedf6")

