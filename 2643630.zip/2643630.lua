-- Lua provided by RyzenAPI
-- Game: Game: Sweet Beauties

-- MAIN APPLICATION
addappid(2643630)
-- Game: addappid(2643630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643631, 1, "cbe083b2dbb9561c66a6f79f3e00547ffd83f60831868a814e9f0f80eac39f93")
