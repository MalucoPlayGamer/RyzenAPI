-- Lua provided by RyzenAPI 
-- Game: Sweet Beauties
addappid(2643630)
addappid(2643631, 1, "cbe083b2dbb9561c66a6f79f3e00547ffd83f60831868a814e9f0f80eac39f93")
