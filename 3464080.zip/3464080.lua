-- Lua provided by RyzenAPI
-- Game: Cats & Critters: A Dungeon Claw-er

-- MAIN APPLICATION
addappid(3464080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464081, 1, "c45fc104e37ff90a2663060f6d0a83a717cd718a56795a739aea3f42f9e7dd25")
