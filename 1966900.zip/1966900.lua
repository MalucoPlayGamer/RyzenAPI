-- Lua provided by RyzenAPI 
-- Game: 20 Minutes Till Dawn
addappid(1966900)
addappid(1966901, 1, "86150b62505519576e84ebd1a2f5deb2dc1464e5c9fbfd04ddc370fedc59fd82")
addappid(1966902, 1, "8305cb4192af5fea999a2848f6e8d308a2ea46840438d349e65b86514510d0bb")
