-- Lua provided by RyzenAPI
-- Game: 春と修羅｜Haru to Shura

-- MAIN APPLICATION
addappid(1352910)
addappid(1676080)
addappid(1960730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1352911, 1, "53621b31288ffca5ce18bb41b847eefe73e687a0251c80749e024871ad1cd56e")

