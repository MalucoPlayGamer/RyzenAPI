-- Lua provided by RyzenAPI
-- Game: 春と修羅｜Haru to Shura

-- MAIN APPLICATION
addappid(1352910)
-- Game: addappid(1352910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352911, 1, "53621b31288ffca5ce18bb41b847eefe73e687a0251c80749e024871ad1cd56e")
