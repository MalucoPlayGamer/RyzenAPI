-- Lua provided by RyzenAPI
-- Game: ICBM: Escalation

-- MAIN APPLICATION
addappid(2647680)
addappid(3535540)
addappid(3886420)
addappid(4782620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647680,0,"c242cf1fa20dc1df63043f2aa9695af3c54b72aac4f1962b3cb873f3f40a224d")
addappid(2647681,0,"b1bf03cc4418c9b103c1d3e63e121d3b36137b3a70cd03b7662c3b155a365a91")
addappid(2647682,0,"89cba265964e76f3b0c5986e82b514b75d3292ad19c6e554cde5d67a57906e4e")

