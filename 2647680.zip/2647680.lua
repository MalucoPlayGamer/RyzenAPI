-- Lua provided by RyzenAPI
-- Game: Game: ICBM: Escalation

-- MAIN APPLICATION
addappid(2647680)
-- Game: addappid(2647680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647681, 1, "b1bf03cc4418c9b103c1d3e63e121d3b36137b3a70cd03b7662c3b155a365a91")
addappid(2647682, 1, "89cba265964e76f3b0c5986e82b514b75d3292ad19c6e554cde5d67a57906e4e")
