-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2748380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2748380,0,"13eb880c3f1913b24c7aab76ba6b8a85e1ebeb39709c67af64ded989294bfb05")

