-- Lua provided by RyzenAPI
-- Game: Wrench

-- MAIN APPLICATION
addappid(936720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(936721, 1, "47fee21c655a367280f84ab94293dbed9db10c1d056f343cd3d8c7da843abca0")

