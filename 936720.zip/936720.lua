-- Lua provided by RyzenAPI
-- Game: Wrench

-- MAIN APPLICATION
addappid(936720)
-- Game: addappid(936720)

-- MAIN APP DEPOTS / PACKAGES
addappid(936721, 1, "47fee21c655a367280f84ab94293dbed9db10c1d056f343cd3d8c7da843abca0")
