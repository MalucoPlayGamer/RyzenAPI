-- Lua provided by RyzenAPI
-- Game: Paradise Delight

-- MAIN APPLICATION
addappid(1729070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729071, 1, "b2ac17d4fadf17656ef7194002baba38fbf9d0accf6792220add7ca12d8317c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
