-- Lua provided by SkyAPI 
-- Game: Paradise Delight
addappid(1729070)
addappid(1729071, 1, "b2ac17d4fadf17656ef7194002baba38fbf9d0accf6792220add7ca12d8317c7")
