-- Lua provided by RyzenAPI
-- Game: Paradise Delight

-- MAIN APPLICATION
addappid(1729070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729071, 1, "b2ac17d4fadf17656ef7194002baba38fbf9d0accf6792220add7ca12d8317c7")

