-- Lua provided by RyzenAPI
-- Game: Yerba Mate Tycoon

-- MAIN APPLICATION
addappid(1404560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404561, 1, "71d9e5ffae6824ac56f8f9aeae64b2c078dc648df231350798e1498aaee82134")
addappid(1404562, 1, "cdddfbc9ce8b92b37b4eddf5dc5b087778c641c52b4a07160c868a936c44966c")
addappid(1404563, 1, "67abc5f9ece9cffee8ebcac405c00ee9d09d68be205caa59e312425f4778919b")

