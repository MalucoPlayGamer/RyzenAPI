-- Lua provided by RyzenAPI
-- Game: Bouncy Weapons

-- MAIN APPLICATION
addappid(4389400)

-- MAIN APP DEPOTS / PACKAGES
addappid(4389401,0,"d605f5841266e96d9c743b15b39bda7f6556d2132fd647c3fc0a8df12cde3731")

