-- Lua provided by RyzenAPI
-- Game: Startup Freak

-- MAIN APPLICATION
addappid(722660)

-- MAIN APP DEPOTS / PACKAGES
addappid(722661,0,"bc68e18557c7d1cc17de4db54b27ef1aadbc77c9b87cf69ea84bf5ad5431d759")

