-- Lua provided by RyzenAPI
-- Game: 2027350

-- MAIN APPLICATION
addappid(2027350)
-- Game: addappid(2027350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027351, 1, "36e106431a4e8f4197d4ca6738ea828ded991ce2346d0970a01898ad00b811ea")
