-- Lua provided by RyzenAPI
-- Game: Hexguardian Demo

-- MAIN APPLICATION
addappid(2460950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460951, 1, "73dff2c0e3a9b4a4667aebdc9c4c14a72edacea8f87286b4015c4265b3e6750f")
