-- Lua provided by RyzenAPI
-- Game: Arcade Tycoon ™ : Simulation Game

-- MAIN APPLICATION
addappid(750520)
-- Game: addappid(750520)

-- MAIN APP DEPOTS / PACKAGES
addappid(750521, 1, "fa50c87338b89189541bc8e3fddfa6c13be174eb656164f66aaa520167d964f7")
