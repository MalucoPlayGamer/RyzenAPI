-- Lua provided by RyzenAPI
-- Game: The Killbox: LEO

-- MAIN APPLICATION
addappid(722750)

-- MAIN APP DEPOTS / PACKAGES
addappid(722751, 1, "ae9c622e8f9fdffb4575e8f529ecbfa9dc62bd54808f8ca9cd7a231cf5a02b44")
addappid(722752, 1, "cab522a7f0f8f46bcc82e4d0fa27b88d84115eb6ba90232a240517ce6692fdbc")

