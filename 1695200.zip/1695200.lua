-- Lua provided by SkyAPI 
-- Game: 星月之歌2
addappid(1695200)
addappid(1695201, 1, "b7c10c01b48353c0ed30eabf9dcae2bda54ecb743aa9be597a6a2d0c15609a4d")
