-- Lua provided by RyzenAPI
-- Game: Game: AppID 2456120

-- MAIN APPLICATION
addappid(2456120)
-- Game: addappid(2456120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456121, 1, "337185c15832a7fdbbd245d99a38aafafe7509911025c8b5a4937f567b4a472c")
