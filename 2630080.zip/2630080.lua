-- Lua provided by RyzenAPI
-- Game: 2630080

-- MAIN APPLICATION
addappid(2630080)
-- Game: addappid(2630080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2630081, 1, "93aaa5e0f9c21de6a3051791eb23c9ce24e31eb2cf150ecabf25e25f3f7654be")
