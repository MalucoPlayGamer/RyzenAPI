-- Lua provided by RyzenAPI
-- Game: AppID 313010

-- MAIN APPLICATION
addappid(313010)

-- MAIN APP DEPOTS / PACKAGES
addappid(313011, 1, "f90814fa619626319a6acd09a33c557adcab4940d9062b4c8f4700f1bba4671f")
addappid(313012, 1, "27e52f41c498c3339029671bdede415099ee11b9989544b5abd88dc97c5ea839")
addappid(313013, 1, "f8ad7f755f9ed9adbbdcf814cb13c2a9a3991c0be14174a038fe068e9d172220")
addappid(313014, 1, "4e7b87a0b79bcc22db7b2f1cedfd5b672d5cfbccd2fb4360452be15f9e7daa35")
addappid(313015, 1, "1b996dbebecdf0d5eb9e6421c39eadddbf5147826baf86095d789958bac32466")
addappid(313016, 1, "efaf9bfb4798932540a03df3ebc71e36c037c738c86d321e0bf440b36bd717b9")
addappid(313017, 1, "164e0d0f2e5255d356994907fe2a9ece16473878aa539490fdd7bd90fe4c007d")
addappid(313018, 1, "941c3571520bc6198aaf157e0a67a902f97001e74bb1e2bcd69b619129c9c1f6")
addappid(313019, 1, "a895efa716ff21cc8acd73b2cb69404887fa26d5a662187835869a1e8eaea487")
addappid(349860, 0, "d0fe5b791a6bb26c2c115fd0993c64064796a26823a2bd826e677772ea93753c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(415750)
