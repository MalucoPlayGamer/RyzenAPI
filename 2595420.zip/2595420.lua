-- Lua provided by RyzenAPI
-- Game: HELL HUNTER - Anti-Nomen

-- MAIN APPLICATION
addappid(2595420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595421, 1, "dc269ff152413272445d3636d06b58d8f91885dd2f368d7a927fcfceaab6bf54")
