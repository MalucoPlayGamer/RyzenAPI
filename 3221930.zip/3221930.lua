-- Lua provided by RyzenAPI
-- Game: Onikura Demo

-- MAIN APPLICATION
addappid(3221930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3221931, 1, "6de678f17e595de1ad2f193f9bbdcab653429d6219761bf97dbc31fd1c5ad514")

