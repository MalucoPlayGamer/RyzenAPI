-- Lua provided by RyzenAPI
-- Game: Game: Crash And Run

-- MAIN APPLICATION
addappid(1720140)
-- Game: addappid(1720140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720141, 1, "7775307145cba306400e4c937a2e06436a9d4a85533ff0895b924000ed19575b")
