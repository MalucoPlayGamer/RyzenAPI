-- Lua provided by RyzenAPI 
-- Game: Crash And Run
addappid(1720140)
addappid(1720141, 1, "7775307145cba306400e4c937a2e06436a9d4a85533ff0895b924000ed19575b")
