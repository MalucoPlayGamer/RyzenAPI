-- Lua provided by RyzenAPI
-- Game: Koa and the Five Pirates of Mara

-- MAIN APPLICATION
addappid(1819450)
-- Game: addappid(1819450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819451, 1, "1e01ca49c0ab289d7b5e33680b1bd84d85691eb9b37e88ed0ac599364a9d3a74")
