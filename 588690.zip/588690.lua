-- Lua provided by SkyAPI 
-- Game: Peace, Death!
addappid(588690)
addappid(588691, 1, "9947ffb1a67ded53babb54d1ebbb57c662c64586b3114105af73fcba289cb34d")
addappid(588692, 1, "21f1173eac48f69d002f34eb8a386cadfe4b3cb34f99a3ca6d0970ca6fc446ce")
addappid(609440, 0, "a089bb6f1c71102bd95d2419b112bf708c54cfd86cfe0b418a65ce0bdbb62130")
