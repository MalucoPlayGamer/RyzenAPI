-- Lua provided by RyzenAPI
-- Game: AppID 914450

-- MAIN APPLICATION
addappid(914450)

-- MAIN APP DEPOTS / PACKAGES
addappid(914451, 1, "eb5f58e3186f01d1f84a1a5eded04b8b5860f1a93fe85cc5df70c575c7dcf6b5")

