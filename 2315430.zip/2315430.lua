-- Lua provided by RyzenAPI
-- Game: Game: The Executive - Movie Industry Tycoon

-- MAIN APPLICATION
addappid(2315430)
-- Game: addappid(2315430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315431, 1, "3c10b450fd01b2a223c4efb4b565fafb56309518f23a7475025782f7137cee3c")
