-- Lua provided by RyzenAPI
-- Game: MY HERO ACADEMIA: All’s Justice

-- MAIN APPLICATION
addappid(2362050)
addappid(3792210)
addappid(3792220)
addappid(3792230)
addappid(3792270)
addappid(3792280)
addappid(3792290)
addappid(3792310)
addappid(3792320)
addappid(3792330)
addappid(3792340)
addappid(3792350)
addappid(3792370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2362051, 1, "de25173640dc896951725a366eb08a505411f96b148ad83194421ec180aeb3f7")

