-- Lua provided by RyzenAPI
-- Game: addappid(2362050)

-- MAIN APPLICATION
addappid(2362050)
addappid(3792210)
addappid(3792220)
addappid(3792230)
addappid(3792270)
addappid(3792280)
addappid(3792290)
addappid(3792310)
addappid(3792320)
addappid(3792330)
addappid(3792340)
addappid(3792350)
addappid(3792370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362051, 1, "de25173640dc896951725a366eb08a505411f96b148ad83194421ec180aeb3f7")
