-- Lua provided by RyzenAPI
-- Game: Beat The Dictators

-- MAIN APPLICATION
addappid(514550)
-- Game: addappid(514550)

-- MAIN APP DEPOTS / PACKAGES
addappid(514551, 1, "cc25bbdd477eb1ac7ad09aa96ba632282a9d4f6c8446d3b34feb3dd6516ddde4")
