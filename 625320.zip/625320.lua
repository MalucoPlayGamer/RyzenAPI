-- Lua provided by RyzenAPI
-- Game: No Clue VR

-- MAIN APPLICATION
addappid(625320)
addappid(625321)
addappid(625322)
addappid(625323)
addappid(625324)
addappid(625329)
-- Game: addappid(625320)

-- MAIN APP DEPOTS / PACKAGES
addappid(625328,0,"9e9f1608fa70692dc3c2cb9786d037f38eadaa8957eb495ea5767b6e9dd6725a")
