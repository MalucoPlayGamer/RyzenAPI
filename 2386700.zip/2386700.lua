-- Lua provided by RyzenAPI
-- Game: Game: Enchanted Voyage

-- MAIN APPLICATION
addappid(2386700)
-- Game: addappid(2386700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386701, 1, "7e4c5a592859522a4e088943115057baa540bc3a3bd5a1858869c1731f63761a")
