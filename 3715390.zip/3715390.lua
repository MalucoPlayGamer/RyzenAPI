-- Lua provided by RyzenAPI
-- Game: Game: Star Gun

-- MAIN APPLICATION
addappid(3715390)
-- Game: addappid(3715390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3715391, 1, "43e5b5321a1d9146d7d8e81bd646aa864a39e276837a9c23590e577bc8456b9e")
