-- Lua provided by RyzenAPI
-- Game: Prompt - Soundtrack

-- MAIN APPLICATION
addappid(384410)

-- MAIN APP DEPOTS / PACKAGES
addappid(384410,0,"db8128faf6b2128059da25e8efb75b282d67596fb791a603fc1270831fccb551")
