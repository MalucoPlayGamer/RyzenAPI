-- Lua provided by RyzenAPI
-- Game: addappid(2733860)

-- MAIN APPLICATION
addappid(2733860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733861, 1, "1a6bce425519209d085f4599750a940ba80fe26cdedc57c536cba005398f57dd")
