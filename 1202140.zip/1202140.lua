-- Lua provided by SkyAPI 
-- Game: Portal Dungeon: Goblin Escape
addappid(1202140)
addappid(1202141, 1, "c9bfa376568a7af420197dc929a96a60e193214490f238d0ed52efecc6108369")
