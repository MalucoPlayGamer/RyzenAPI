-- Lua provided by RyzenAPI
-- Game: 2989860

-- MAIN APPLICATION
addappid(2989860)
-- Game: addappid(2989860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989861, 1, "ed37edecb3fe16e574b80a7ce84b07b2338e60c5c7d89786e632ee7006362bff")
