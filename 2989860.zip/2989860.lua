-- Lua provided by RyzenAPI
-- Game: Ells Tales: Egg

-- MAIN APPLICATION
addappid(2989860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2989861, 1, "ed37edecb3fe16e574b80a7ce84b07b2338e60c5c7d89786e632ee7006362bff")

