-- Lua provided by RyzenAPI
-- Game: SUPER Dungeon Muncher

-- MAIN APPLICATION
addappid(3095800)
-- Game: addappid(3095800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095801, 1, "1e7d5e0605a4cb659dbb59b252223bb93967ab0ee6d7fbc039f808e25ce0e0ef")
