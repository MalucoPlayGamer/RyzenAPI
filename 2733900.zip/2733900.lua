-- Lua provided by RyzenAPI
-- Game: Yet Another Fantasy Title (YAFT) Demo

-- MAIN APPLICATION
addappid(2733900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733901, 1, "5162964c6d927932743d40ea924f039d6bdb480a1c04e532ef69b2ee90867d7d")
