-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy 2

-- MAIN APPLICATION
addappid(764560)

-- MAIN APP DEPOTS / PACKAGES
addappid(764561, 1, "17436998f1cafa3eb906674a025fb46020c5a5f4d36bde963f69f08dff60cbee")

