-- Lua provided by RyzenAPI
-- Game: Game: Bellfortis Demo

-- MAIN APPLICATION
addappid(3238770)
-- Game: addappid(3238770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238771, 1, "78b869ba03277e7fd1f49a8532aa693d611dcb602d56592b2963fff321e8b1db")
