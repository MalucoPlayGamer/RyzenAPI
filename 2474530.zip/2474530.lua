-- Lua provided by RyzenAPI
-- Game: To Pixelia Demo

-- MAIN APPLICATION
addappid(2474530)
-- Game: addappid(2474530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474531, 1, "bdc3c429b8031655a8ae7d9448b6acab85eea88899966598948d2fc122c12821")
