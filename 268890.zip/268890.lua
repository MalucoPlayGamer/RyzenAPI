-- Lua provided by RyzenAPI
-- Game: Masters of the World - Geopolitical Simulator 3

-- MAIN APPLICATION
addappid(268890)
addappid(278480)
addappid(278481)
addappid(278482)
addappid(278483)
-- Game: addappid(268890)

-- MAIN APP DEPOTS / PACKAGES
addappid(268891, 1, "b507a97370bb0c268e6fbf4af93979255282661cfdb4df3b0adb93a3fa885783")
addappid(268892, 1, "90ef8653643c56d0e0bbb1d6cb6398f156417bbbd533cc0fdd2b081910cef104")
addappid(268893, 1, "99478e1f3d0c73a63bf8b40edfeefb6700d976ffe7b6e60336a8cb7fe4a208f2")
addappid(268894, 1, "5bdce05a68246b8212927322f5c114b41ec9d2bf64530c935fc6bbe3eb190fef")
addappid(268895, 1, "8904c244e72da25f80f654a0d100de8c547b9ff1dc4c552f0118cb4f3734acca")
addappid(268896, 1, "264668b12f04ba6b14d003f310e6c2e8d6f40a4fae108b89b05fa7b7a24a369b")
addappid(268897, 1, "ee13fd9d51ebab7f927ffe6e46372e64f924a3dc02a8728a292dfd6e7d5a523e")
addappid(268898, 1, "fe43cb8c100cddf12ffbdee800cbc1e244373962b73f8353092521926e2dd3ad")
addappid(268899, 1, "ceab5d6e163be518152bc0ca4403de08f7c1ebf3a07a9651e627c2a9f76e42e2")
addappid(268900, 1, "b70c1c000644394fd43cf13b45e7a87320cacac05e90d160aeac1aa713fcb321")
