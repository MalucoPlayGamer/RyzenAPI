-- Lua provided by RyzenAPI
-- Game: Dark Deception: Monsters & Mortals

-- MAIN APPLICATION
addappid(1266690)
-- Game: addappid(1266690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266691, 1, "a75098ec064c590cb31c5612219a75678d3696789d4889429ec7de680e824c01")
