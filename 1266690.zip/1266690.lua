-- Lua provided by RyzenAPI
-- Game: Dark Deception: Monsters & Mortals

-- MAIN APPLICATION
addappid(1266690)
addappid(1450740)
addappid(1450741)
addappid(1508810)
addappid(1590860)
addappid(1825940)
addappid(1825941)
addappid(1825942)
addappid(2849550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1266691, 1, "a75098ec064c590cb31c5612219a75678d3696789d4889429ec7de680e824c01")

