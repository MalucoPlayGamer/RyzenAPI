-- Lua provided by RyzenAPI 
-- Game: Night in Riverager
addappid(1500380)
addappid(1500381, 1, "1ae1016240feb1511c84df7756356cf24c5023408a03a21567d90ed9fb75deb4")
