-- Lua provided by RyzenAPI
-- Game: Omen of Sorrow Demo

-- MAIN APPLICATION
addappid(2097690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097691, 1, "8d774806a13f3ec8ee58e5328cc597af204135b1a9a295972acad5abf82aad2f")
