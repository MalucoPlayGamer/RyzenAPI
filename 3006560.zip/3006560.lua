-- Lua provided by RyzenAPI
-- Game: Game: Нужен Трах Soundtrack

-- MAIN APPLICATION
addappid(3006560)
-- Game: addappid(3006560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006561, 1, "ca7f98e451d128fb07680a16390def93f21ecf00e82da6622996d4a82b18b335")
