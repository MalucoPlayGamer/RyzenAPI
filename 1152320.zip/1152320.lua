-- Lua provided by RyzenAPI
-- Game: Atelier Shallie: Alchemists of the Dusk Sea DX

-- MAIN APPLICATION
addappid(1152320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1152321, 1, "ae344591aa0d55d6339a5de23f85512f23dd11d608e3fa2ea158a4345a6b5eb0")
