-- Lua provided by RyzenAPI
-- Game: AppID 801880

-- MAIN APPLICATION
addappid(801880)

-- MAIN APP DEPOTS / PACKAGES
addappid(801881, 1, "d92eb5ce522e058bc1606199eb3c671f4c21fbbd6db6e7c0856e8da8669a6761")
