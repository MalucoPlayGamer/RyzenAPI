-- Lua provided by RyzenAPI
-- Game: Beat Saber - Survivor - "Eye of the Tiger"

-- MAIN APPLICATION
addappid(2233131)
-- Game: addappid(2233131)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233131,0,"3d8dfa69707e50ba26a4e05a5a05cde285be0abbd6da7b76e394f4b14758a276")
