-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Whatever It Takes"

-- MAIN APPLICATION
addappid(1099585)
-- Game: addappid(1099585)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099585,0,"30f874d0272ec9de4754cd971e16a71fb01b33963b29936e111ca7f2542b5b6c")
