-- Lua provided by RyzenAPI
-- Game: Zero Hour

-- MAIN APPLICATION
addappid(1359090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359091, 1, "0894c1b6a123aba0a839dc8fa514cdf47430cfd10b68f14b9bf892b4fb51ebcf")

