-- Lua provided by RyzenAPI
-- Game: Zero Hour

-- MAIN APPLICATION
addappid(1359090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359091, 1, "0894c1b6a123aba0a839dc8fa514cdf47430cfd10b68f14b9bf892b4fb51ebcf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2616600)
addappid(2726290)
addappid(2726300)
addappid(2744030)
addappid(2751840)
addappid(3179440)
