-- Lua provided by RyzenAPI
-- Game: Servant of the Lake

-- MAIN APPLICATION
addappid(3636770) -- Servant of the Lake

-- MAIN APP DEPOTS / PACKAGES
addappid(3636773, 1, "47efd8d9e4421b857f586ee20c067790f4360b03d9b21e7137ceb751d0c6d638") -- Depot 3636773
addappid(3636774, 1, "6dde3b2c075c250b5d135902338e5991ce3da4992f204d3e3140821d89390c5a") -- Depot 3636774

