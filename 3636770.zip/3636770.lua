-- 3636770's Lua and Manifest Created by Hubcap Manifest
-- Servant of the Lake
-- Created: August 13, 2026 at 10:28:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3636770) -- Servant of the Lake
-- MAIN APP DEPOTS
addappid(3636773, 1, "47efd8d9e4421b857f586ee20c067790f4360b03d9b21e7137ceb751d0c6d638") -- Depot 3636773
setManifestid(3636773, "8351238151391218366", 681341085)
addappid(3636774, 1, "6dde3b2c075c250b5d135902338e5991ce3da4992f204d3e3140821d89390c5a") -- Depot 3636774
setManifestid(3636774, "7828023302062724829", 726541723)