-- Lua provided by RyzenAPI
-- Game: 1329600

-- MAIN APPLICATION
addappid(1329600)
-- Game: addappid(1329600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329601, 1, "cb95132f4e610353d7100a9dbad2807cc2418a27ba36ddc05186cfbe31b8894a")
