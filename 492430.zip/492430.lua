-- Lua provided by RyzenAPI
-- Game: Alteric

-- MAIN APPLICATION
addappid(492430)
addappid(500160)

-- MAIN APP DEPOTS / PACKAGES
addappid(492431, 1, "8595654deca95ef04d24cad51afc0ea447c78b663b48f8cd2f7a77492da89f31")
addappid(492432, 1, "ef0385748a0edd6cff42f09f6655d3ca356d7f4ff462e9352af3e35ea89ebc98")
