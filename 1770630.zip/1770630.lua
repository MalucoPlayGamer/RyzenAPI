-- Lua provided by RyzenAPI
-- Game: Game: Fear in The Modern House - CH3

-- MAIN APPLICATION
addappid(1770630)
-- Game: addappid(1770630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770631, 1, "03df7bbade8897a465365b399db64af3957b90e1e2ee70c3ea91121b9f8e657b")
