-- Lua provided by RyzenAPI
-- Game: Baby Hands

-- MAIN APPLICATION
addappid(708820)

-- MAIN APP DEPOTS / PACKAGES
addappid(708821, 1, "9e5d886640aeaff33b14f3376df0f0ec07c8173894edc03b10def8bc28becf68")
