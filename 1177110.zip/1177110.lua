-- Lua provided by RyzenAPI
-- Game: AppID 1177110

-- MAIN APPLICATION
addappid(1177110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177111, 1, "f24fce49995b7881f0b7074219308db73f01917831556c77fc0c3c6c28f840ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
