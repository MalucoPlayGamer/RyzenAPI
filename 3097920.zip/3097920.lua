-- Lua provided by RyzenAPI
-- Game: Game: AppID 3097920

-- MAIN APPLICATION
addappid(3097920)
-- Game: addappid(3097920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097921, 1, "5aea4a97542233b3d3ee9357ee68a6cc6e11c35873da3e30fe5dcb1613110d58")
