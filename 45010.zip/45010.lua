-- Lua provided by RyzenAPI
-- Game: Sol Survivor Demo

-- MAIN APPLICATION
addappid(45010)
-- Game: addappid(45010)

-- MAIN APP DEPOTS / PACKAGES
addappid(45011, 1, "bf64834084b2dcb22fb95de78fbf7049f6ef3624244b8b2d0a1098235c910c7b")
