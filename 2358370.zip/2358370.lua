-- Lua provided by RyzenAPI
-- Game: Game: Eternights Demo

-- MAIN APPLICATION
addappid(2358370)
-- Game: addappid(2358370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358371, 1, "1324c588f55e0401962cb97cce8c92c6c3eebd5fc0e5547eecc9c95de0ed4840")
