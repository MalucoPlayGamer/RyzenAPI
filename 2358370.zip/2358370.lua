-- Lua provided by SkyAPI 
-- Game: Eternights Demo
addappid(2358370)
addappid(2358371, 1, "1324c588f55e0401962cb97cce8c92c6c3eebd5fc0e5547eecc9c95de0ed4840")
