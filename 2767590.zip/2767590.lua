-- Lua provided by RyzenAPI
-- Game: I Love You Freddy Demo

-- MAIN APPLICATION
addappid(2767590)
-- Game: addappid(2767590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767591, 1, "bdc8f8b634c5dda1e8df91ae23596a469d8eb0030adee1583ce07d33d10f807f")
