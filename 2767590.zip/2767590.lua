-- Lua provided by SkyAPI 
-- Game: I Love You Freddy Demo
addappid(2767590)
addappid(2767591, 1, "bdc8f8b634c5dda1e8df91ae23596a469d8eb0030adee1583ce07d33d10f807f")
