-- Lua provided by RyzenAPI
-- Game: Game: 69 Mary Love

-- MAIN APPLICATION
addappid(1794520)
-- Game: addappid(1794520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794521, 1, "e89ff5cccddece9496f6f5a598eabd0822844cf9a5342a61b9e0937067117cb4")
