-- 4640620's Lua and Manifest Created by Hubcap Manifest
-- Flux Ascendant
-- Created: July 28, 2026 at 04:08:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4640620, 1, "042c73bd191fc95c1ddadf99c842611b11589123dcd3bb7a794ba750fb7d1a9c") -- Flux Ascendant
-- MAIN APP DEPOTS
addappid(4640621, 1, "9e0e9fefe82a4d67cbe16b9be952890326368b736d706b57a10e223c5830b67a") -- Depot 4640621
setManifestid(4640621, "6279091222834803560", 353288424)