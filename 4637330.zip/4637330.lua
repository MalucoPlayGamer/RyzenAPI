-- 4637330's Lua and Manifest Created by Hubcap Manifest
-- 公司崛起 Company Rising
-- Created: June 20, 2026 at 09:59:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4637330) -- 公司崛起 Company Rising
-- MAIN APP DEPOTS
addappid(4637331, 1, "d2ddecd34d155374dbb141bd8e94ab200df11b9f3be60365a0ed1ca177ab37ce") -- Depot 4637331
setManifestid(4637331, "240848724516420699", 299500852)
addappid(4637332, 1, "d7ba79fed95a2cb5dd75295cac51ab26a83735d7159cec1dd2b9da6ad274c3a7") -- Depot 4637332
setManifestid(4637332, "8645234300945916283", 421941870)