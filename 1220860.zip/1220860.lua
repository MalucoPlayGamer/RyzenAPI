-- Lua provided by RyzenAPI
-- Game: Citywars Savage Demo

-- MAIN APPLICATION
addappid(1220860)
-- Game: addappid(1220860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220861, 1, "46f099b1575df76d54c99e428789bfb6887bc871388b124896ec30d1f91f9e66")
