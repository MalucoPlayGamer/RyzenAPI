-- Lua provided by RyzenAPI
-- Game: Li Dian - Officer Ticket / 李典使用券

-- MAIN APPLICATION
addappid(956921)

-- MAIN APP DEPOTS / PACKAGES
addappid(956921,0,"17d57c8fa0dbbc14094bffe9b381c151aa4089b585233a988a5522a7d5acd6ea")
