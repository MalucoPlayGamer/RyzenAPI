-- Lua provided by RyzenAPI
-- Game: The Three Kingdoms of Shadows: Xuzhou

-- MAIN APPLICATION
addappid(3155310) -- The Three Kingdoms of Shadows: Xuzhou

-- MAIN APP DEPOTS / PACKAGES
addappid(3155311, 1, "6cd54e75b1718c2a3493feb9cdb4af57cbdb7badfd71b596ad6118e84ce030ca") -- Depot 3155311

