-- 3155310's Lua and Manifest Created by Hubcap Manifest
-- The Three Kingdoms of Shadows: Xuzhou
-- Created: August 13, 2026 at 08:31:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3155310) -- The Three Kingdoms of Shadows: Xuzhou
-- MAIN APP DEPOTS
addappid(3155311, 1, "6cd54e75b1718c2a3493feb9cdb4af57cbdb7badfd71b596ad6118e84ce030ca") -- Depot 3155311
setManifestid(3155311, "6838004483420970929", 815425040)