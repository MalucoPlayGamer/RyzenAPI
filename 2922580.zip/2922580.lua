-- Lua provided by RyzenAPI
-- Game: Wrong Number

-- MAIN APPLICATION
addappid(3383300)
addappid(3511280)
addappid(3511290)
-- addappid(3658870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922580, 1, "5e589c5c1ac255d9af5ec42e6032221b50d8a6f01f25b0cf226abbc3b9fa8f93") -- Wrong Number
addappid(2922581, 1, "451ffde5751f0005d5be5301c64d09d44669db89ca0437c675a60a2ad7d1a3de") -- Depot 2922581
addappid(3383300, 1, "db4556caaee2278a7879d7b8ed4ad17a29ff03fb1217c26aa8305f6c381f1ffa") -- Wrong Number - Artbook and Guide - Depot 3383300
addappid(3511280, 1, "81906aaf3fb4ab1626ad1ab066d5a75873ccbc3952c19c852f1106991d601ba8") -- Wrong Number - Going 69 in a 50 zone (ebook) - Depot 3511280
addappid(3511290, 1, "ac2265ac75ad82fed4db5869624a6b9f52018f1d591f03d13cbfb315a6636ea6") -- Wrong Number - On the 69th day of Xmas (ebook) - Depot 3511290

