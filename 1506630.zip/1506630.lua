-- Lua provided by RyzenAPI
-- Game: Minicraft Shooter

-- MAIN APPLICATION
addappid(1506630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506631, 1, "54f5c9bc8dac7213091bc054a180fe0db405522826116d1b032b240a9fd023f4")
