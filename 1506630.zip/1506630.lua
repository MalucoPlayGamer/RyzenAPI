-- Lua provided by SkyAPI 
-- Game: Minicraft Shooter
addappid(1506630)
addappid(1506631, 1, "54f5c9bc8dac7213091bc054a180fe0db405522826116d1b032b240a9fd023f4")
