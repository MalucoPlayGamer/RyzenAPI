-- Lua provided by RyzenAPI
-- Game: Game: Voxile

-- MAIN APPLICATION
addappid(2283580)
-- Game: addappid(2283580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283581, 1, "9b84af9059367218f69b366e157a18614b0841913a555a78865df2f4515b2e7f")
