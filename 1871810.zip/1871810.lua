-- Lua provided by RyzenAPI
-- Game: addappid(1871810)

-- MAIN APPLICATION
addappid(1871810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871811, 1, "03366eaa7a73a2f62d0848be652fd4ebaca1a98e4256c0c01e4cc9f6519f41e3")
