-- Lua provided by RyzenAPI
-- Game: Soda Crisis

-- MAIN APPLICATION
addappid(1592670)
-- Game: addappid(1592670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592671, 1, "c76c6c2baf3753b43d2df99b889ba87778acc090242c5b96c13fffe90498edce")
addappid(1592672, 1, "17acd8b1aeac4586a23ee760aa63ab71033851d8d6975e5b0989b938fd4d73f4")
addappid(1592673, 1, "32cf45f7724948c5940142eec44247b6d09f6114ea75de9c737e15b32c9e1c96")
