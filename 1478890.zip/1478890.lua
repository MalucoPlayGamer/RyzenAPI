-- Lua provided by RyzenAPI
-- Game: Cursed Treasure 2 Ultimate Edition Demo

-- MAIN APPLICATION
addappid(1478890)
-- Game: addappid(1478890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478891, 1, "6175ce9c325d9cd237fc0c9219284fa27707dc07a648fa79909d408fabd81f73")
