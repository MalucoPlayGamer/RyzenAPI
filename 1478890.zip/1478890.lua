-- Lua provided by SkyAPI 
-- Game: Cursed Treasure 2 Ultimate Edition Demo
addappid(1478890)
addappid(1478891, 1, "6175ce9c325d9cd237fc0c9219284fa27707dc07a648fa79909d408fabd81f73")
