-- Lua provided by RyzenAPI
-- Game: 1909921

-- MAIN APPLICATION
addappid(1909921)
-- Game: addappid(1909921)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909921,0,"0760dd65601f876cdec3d4b9627eb8fc02eb05e781e1e136c352ac9b342f8601")
