-- Lua provided by SkyAPI 
-- Game: Cheaters Cheetah
addappid(3438990)
addappid(3438991, 1, "b28c98c31d1500062773f31e0d6d1a27a7f51af07491ed4584a485c2e9a3fba3")
