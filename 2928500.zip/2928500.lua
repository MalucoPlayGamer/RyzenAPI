-- Lua provided by RyzenAPI
-- Game: Endless Casual Drive

-- MAIN APPLICATION
addappid(2928500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928501, 1, "6dba6de37d60e4428bba78f6f9ed2ba4fc71a5fa33137d636fcebdf380d577d5")
