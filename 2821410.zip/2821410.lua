-- Lua provided by RyzenAPI
-- Game: Game: AppID 2821410

-- MAIN APPLICATION
addappid(2821410)
-- Game: addappid(2821410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821411, 1, "5fa5d23175eb257e0423ffbd43271a483de47e2b51be1228f001d0ff726d5ef8")
