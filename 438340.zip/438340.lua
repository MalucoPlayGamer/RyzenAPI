-- Lua provided by RyzenAPI
-- Game: 438340

-- MAIN APPLICATION
addappid(438340)
-- Game: addappid(438340)

-- MAIN APP DEPOTS / PACKAGES
addappid(438341, 1, "5325f888f9c3d60a04cf6eccf063c6a052b63a5ff57424c1d85a6fd6974d56ec")
