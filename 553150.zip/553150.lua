-- Lua provided by RyzenAPI
-- Game: VR Dungeon

-- MAIN APPLICATION
addappid(553150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(553151, 1, "e9eb291a9772a47b8b4e2104d45681c2995e2837f7dfab26a1fdc0cd926f408e")

