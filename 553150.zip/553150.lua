-- Lua provided by RyzenAPI
-- Game: Game: VR Dungeon

-- MAIN APPLICATION
addappid(553150)
-- Game: addappid(553150)

-- MAIN APP DEPOTS / PACKAGES
addappid(553151, 1, "e9eb291a9772a47b8b4e2104d45681c2995e2837f7dfab26a1fdc0cd926f408e")
