-- Lua provided by RyzenAPI
-- Game: addappid(2897490)

-- MAIN APPLICATION
addappid(2897490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897491, 1, "8f72f4e9efd23f57a6a5e16c910c2b55e79ce11773a0163c949e38217c8e06d8")
