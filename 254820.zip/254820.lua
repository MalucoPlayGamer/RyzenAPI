-- Lua provided by RyzenAPI
-- Game: AppID 254820

-- MAIN APPLICATION
addappid(254820)
-- Game: addappid(254820)

-- MAIN APP DEPOTS / PACKAGES
addappid(254821, 1, "54b7a08c5ec82f3c1351a8f0c728854f7632dd37a598e0e179b0054a8fbc0594")
