-- Lua provided by RyzenAPI
-- Game: Ground Control Anthology

-- MAIN APPLICATION
addappid(254820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(254821, 1, "54b7a08c5ec82f3c1351a8f0c728854f7632dd37a598e0e179b0054a8fbc0594")

