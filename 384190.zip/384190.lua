-- Lua provided by RyzenAPI
-- Game: ABZÛ

-- MAIN APPLICATION
addappid(384190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(384191, 1, "5e3d2d48766f08b9e0feb762f7f850c7c50d54e19f83e8c55d98e61b05324696")
addappid(577450, 0, "efbe34ac7ecfa79956ca5d53f43011169bc1f827522f7862d0350ff52fda0685")

