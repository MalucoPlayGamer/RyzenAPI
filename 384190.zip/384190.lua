-- Lua provided by RyzenAPI
-- Game: Game: AppID 384190

-- MAIN APPLICATION
addappid(384190)
-- Game: addappid(384190)

-- MAIN APP DEPOTS / PACKAGES
addappid(384191, 1, "5e3d2d48766f08b9e0feb762f7f850c7c50d54e19f83e8c55d98e61b05324696")
addappid(577450, 0, "efbe34ac7ecfa79956ca5d53f43011169bc1f827522f7862d0350ff52fda0685")
