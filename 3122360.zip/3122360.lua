-- Lua provided by SkyAPI 
-- Game: Catbo
addappid(3122360)
addappid(3122361, 1, "bd9e49e21bc8078ec679ae04fd701bd54fd8945f2fc5c7c5faef207a1001d148")
