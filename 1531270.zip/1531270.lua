-- Lua provided by RyzenAPI
-- Game: Dance with me

-- MAIN APPLICATION
addappid(1531270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531271, 1, "081a71d7469f33af861d8b3aef9fb785b14f2f5b01ed90b2c8466f8b2e6e83f5")
