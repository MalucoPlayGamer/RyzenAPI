-- Lua provided by RyzenAPI
-- Game: When the Darkness comes

-- MAIN APPLICATION
addappid(1021950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1021951, 1, "22d947220933bc55360ac852765acad07cbe3830f1887b77342670d7c093e48d")

