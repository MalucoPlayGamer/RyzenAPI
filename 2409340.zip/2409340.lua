-- Lua provided by SkyAPI 
-- Game: AppID 2409340
addappid(2409340)
addappid(2409341, 1, "d61f6047b7bd5fe0085716ba0a3728aade67bab669232fb4a049e0c925bdbcae")
