-- Lua provided by RyzenAPI
-- Game: RUNGORE: Beginner Experience

-- MAIN APPLICATION
addappid(2113050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113051, 1, "bc80e90efb71349cd8d1ed7df1d7e3c0bd14e7fcac9604f8cf322d2d2c14fd4c")
