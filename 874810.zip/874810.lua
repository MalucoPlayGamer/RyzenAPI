-- Lua provided by RyzenAPI
-- Game: Brick Breaker Premium 3

-- MAIN APPLICATION
addappid(874810)

-- MAIN APP DEPOTS / PACKAGES
addappid(874811, 1, "403567e1c465f2dd178a6141c18bc459ac6c4d55696f2604e9693a430a7ddd6f")
