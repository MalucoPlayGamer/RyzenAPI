-- Lua provided by RyzenAPI 
-- Game: Kickoff Legends
addappid(542940)
addappid(542941, 1, "98bb878799014c9d678339efbd9b0ec7f30fe1f170a61bce8cf00378ea7be880")
addappid(542942, 1, "6536254b9db69c47ba56e011003f43438774fc0e5838df98f2794a667b419c55")
addappid(542943, 1, "84eb6e012c70a9c68da5ae843e1b5f1aa39cab8110c2652b8fa8fddc09ca7eb3")
