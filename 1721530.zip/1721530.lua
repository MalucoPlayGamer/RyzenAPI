-- Lua provided by RyzenAPI 
-- Game: The Captain
addappid(1721530)
addappid(1721531, 1, "965ca8befd0eb53e42f35db6d720d9f594787bb5018e5ce4bfe4d06050a66693")
addappid(1721532, 1, "81c70f7e08aebe4a87ff127a00bfbe670cfec1c8b4c668ff261bb9950ee1dbd3")
addappid(1721533, 1, "8df591aa6bd7f899bee4edf545d51fbc04a0c75d51d226f34ae4c6c3f3f4c337")
