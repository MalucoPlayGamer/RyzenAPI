-- Lua provided by RyzenAPI
-- Game: Arcane Afterfall

-- MAIN APPLICATION
addappid(3220170)
-- Game: addappid(3220170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220171, 1, "06b7306cbaee83df05e06399fe2543d028aa31595cef54e8e806b5c658c150b4")
addappid(3220172, 1, "10ba88403e133e46a83a34466c0f53d3a99c67d18f844be551e7e608d470120d")
