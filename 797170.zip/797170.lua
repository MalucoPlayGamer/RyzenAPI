-- Lua provided by RyzenAPI
-- Game: Game: AppID 797170

-- MAIN APPLICATION
addappid(797170)
-- Game: addappid(797170)

-- MAIN APP DEPOTS / PACKAGES
addappid(797171, 1, "a3ce18ec251dc1351b2712e0ef2c4c8c0365aa5bcc6b7e622174424371b6f4e2")
