-- Lua provided by RyzenAPI 
-- Game: 1hr Meditation
addappid(2450220)
addappid(2450221, 1, "49021f228c6447786c09ee22518cd4cebb3e1572ce38b8226bcec20ddb13bf1d")
addappid(2450222, 1, "def3e19015f7626f03893eefcd15000b87a7559b55705fa684b32766314406e0")
