-- Lua provided by RyzenAPI
-- Game: addappid(3122350)

-- MAIN APPLICATION
addappid(3122350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122351, 1, "5c35ee2cf4d4dac54a3a3c14956417fca4345fc4898c9ef00c1d4ca0b7f39124")
