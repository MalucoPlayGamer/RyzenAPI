-- Lua provided by RyzenAPI
-- Game: My Fire Is Bigger Than Yours

-- MAIN APP DEPOTS / PACKAGES
addappid(4428630, 1, "9c7269f7a44475cd98f4b0a7b7e23baf46405648ca3a79e546627fb3d58c05a5") -- My Fire Is Bigger Than Yours
addappid(4428631, 1, "b4c7caa1b35149b6286859b63e591c4726f91dac17a40d62fa1a7d32c70033bc") -- Depot 4428631

