-- Lua provided by RyzenAPI
-- Game: addappid(773630)

-- MAIN APPLICATION
addappid(773630)

-- MAIN APP DEPOTS / PACKAGES
addappid(773631, 1, "fc77f5279a799a5d0bdea98f1b880a74c1a2d9ddd5d835aaf4b40445568b4720")
