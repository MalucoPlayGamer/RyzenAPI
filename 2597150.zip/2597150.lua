-- Lua provided by RyzenAPI
-- Game: Gorgon Shield Demo

-- MAIN APPLICATION
addappid(2597150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597151, 1, "49ea993b1b05dd7d7cfe12f5bfb7d9ca16147f66b4b484b931876377ab6a2a0e")

