-- Lua provided by SkyAPI 
-- Game: Noah and Black Magician
addappid(1594010)
addappid(1594011, 1, "35a9b2ba6e7ff36a414229b15a01b104f7558dc067619405cf04a450983f1d58")
