-- Lua provided by RyzenAPI
-- Game: Noah and Black Magician

-- MAIN APPLICATION
addappid(1594010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594011, 1, "35a9b2ba6e7ff36a414229b15a01b104f7558dc067619405cf04a450983f1d58")

