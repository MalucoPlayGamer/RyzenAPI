-- Lua provided by RyzenAPI
-- Game: addappid(252070)

-- MAIN APPLICATION
addappid(252070)

-- MAIN APP DEPOTS / PACKAGES
addappid(252071, 1, "c73ed0d201fe1cb1e46a3ff007cf99b88f907cdaa5dd5ba88227bb64ff9c4015")
