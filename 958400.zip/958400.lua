-- Lua provided by RyzenAPI
-- Game: Project CARS 3

-- MAIN APPLICATION
addappid(958400)
addappid(1354050)
addappid(1354051)
addappid(1354052)
addappid(1354053)
addappid(1354110)
addappid(1354111)

-- MAIN APP DEPOTS / PACKAGES
addappid(958400,0,"26f9b590b8928d4a73038b47409029bcf154b148062e779a3a310c61971222d7")
addappid(958401,0,"4b06ad0995378136df7bf9cc46cd2a5f755ed87834c3f704bca005d1527ff9a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
