-- Lua provided by RyzenAPI
-- Game: Project CARS 3

-- MAIN APPLICATION
addappid(958400)
addappid(1354050)
addappid(1354051)
addappid(1354052)
addappid(1354053)
addappid(1354110)
addappid(1354111)

-- MAIN APP DEPOTS / PACKAGES
addappid(958400,0,"26f9b590b8928d4a73038b47409029bcf154b148062e779a3a310c61971222d7")
addappid(958401,0,"4b06ad0995378136df7bf9cc46cd2a5f755ed87834c3f704bca005d1527ff9a3")

