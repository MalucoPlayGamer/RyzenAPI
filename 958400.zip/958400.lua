-- Lua provided by RyzenAPI 
-- Game: AppID 958400
addappid(958400)
addappid(958401, 1, "4b06ad0995378136df7bf9cc46cd2a5f755ed87834c3f704bca005d1527ff9a3")
