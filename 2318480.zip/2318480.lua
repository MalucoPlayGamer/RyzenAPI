-- Lua provided by RyzenAPI
-- Game: 2318480

-- MAIN APPLICATION
addappid(2318480)
-- Game: addappid(2318480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318481, 1, "7f4f46de883df069f69f74a2c4bb0bbdde62672bf784388ed429fa7ef8108718")
