-- Lua provided by RyzenAPI
-- Game: addappid(390890)

-- MAIN APPLICATION
addappid(390890)

-- MAIN APP DEPOTS / PACKAGES
addappid(390891, 1, "75c6b46bdfcb4a6ea60025ba61ed0bcf9c0fe8c3dbce0b86c120687f93859a2d")
