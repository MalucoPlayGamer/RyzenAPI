-- Lua provided by RyzenAPI
-- Game: 2294370

-- MAIN APPLICATION
addappid(2294370)
-- Game: addappid(2294370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294371, 1, "3dae3fc189e95311952cdbcadd3b10dd55c1c091530df4449fe5102dfc375a32")
