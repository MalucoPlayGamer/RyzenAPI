-- Lua provided by RyzenAPI
-- Game: The Sinking Structure, Clione, and Lost Child -Log4

-- MAIN APPLICATION
addappid(1923060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923061, 1, "2fba6688962a708d154097420787cef69ede852873e20bd0d2abddae175843a0")

