-- Lua provided by RyzenAPI
-- Game: Game: Horny Girls Hentai

-- MAIN APPLICATION
addappid(1546870)
-- Game: addappid(1546870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546871, 1, "0191a66531ec6e9be56b3a79c9255ca903f7bef7d19cce5753a9b0cc560993eb")
addappid(1546872, 1, "019cec82af33c02a0b765a028546bfcdf8fb1f1ac9a8f5090ad52210f6922afe")
addappid(1546873, 1, "a5721f389d520e118bbdb02b1a1e9a46bae1ca7d0acf560db3c03af083f4fc50")
addappid(1546874, 1, "1c4363cb37a29cf2fb724b39ea9d62b06b465b8f367f129d7fdb182eb2d538c7")
