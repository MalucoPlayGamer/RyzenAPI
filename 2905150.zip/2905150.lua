-- Lua provided by RyzenAPI
-- Game: Game: 遗忘魔塔

-- MAIN APPLICATION
addappid(2905150)
-- Game: addappid(2905150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905151, 1, "ba9d882c7516366afa37356af11089b5d4244921dd6e1503384153ef3c9b9454")
