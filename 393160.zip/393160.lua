-- Lua provided by RyzenAPI 
-- Game: AppID 393160
addappid(393160)
addappid(393161, 1, "1724113d2c719bf25e235daaba3e267efcbee59ca77b6cb41e930569a190f029")
