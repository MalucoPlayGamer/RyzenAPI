-- Lua provided by RyzenAPI
-- Game: The Voices Games 3d Collection

-- MAIN APPLICATION
addappid(2081640)
-- Game: addappid(2081640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081641, 1, "90e724268ba75e390d37b594fead2fcf359d7640f35aa91ec238301b3217ab41")
