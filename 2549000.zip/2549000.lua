-- Lua provided by RyzenAPI
-- Game: Game: SummerAfterTenYears: Steam Edition

-- MAIN APPLICATION
addappid(2549000)
-- Game: addappid(2549000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549001, 1, "012e5bf83159ec0461f21afb00d704ed8854760098cef4969787bec5678a5668")
