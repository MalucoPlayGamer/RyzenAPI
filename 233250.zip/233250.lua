-- Lua provided by RyzenAPI
-- Game: Planetary Annihilation

-- MAIN APPLICATION
addappid(233250)
addappid(321580)
addappid(337810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(233251, 1, "bb27ddfb25c31b36b4dc0bb768c60f17a4b2f45d7bee79053a656d1068f0494e")
addappid(233252, 1, "034186e1efed61feae749e834f994e99996ac84e0d3d949128701c18497b9caa")
addappid(233253, 1, "1f62a06bd4948bf4dbee3b373b403f5cd04479b633aa15d4853fd7f7adc9c2d4")
addappid(233254, 1, "e9d88560188f5adf9646ed663f82f925710c8fef1646a976cd13091efe12012b")
addappid(323420, 0, "8bf5c725df5aa1cb4fa250299b09ba1cfeb4c608b0da77473afee9be952b6343")
