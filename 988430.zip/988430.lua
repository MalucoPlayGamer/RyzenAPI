-- Lua provided by RyzenAPI
-- Game: Lightseekers

-- MAIN APPLICATION
addappid(988430)

-- MAIN APP DEPOTS / PACKAGES
addappid(988431, 1, "05088f1c4ed1f8f62eac170ff4c9c7dde48cc77858ba6490b0a02d8547ac1f96")
addappid(988432, 1, "4268ff757cdec7df66784c74d251b6c330e62df1e70e1d3382bee9d9352d05a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
