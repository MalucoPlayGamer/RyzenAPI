-- Lua provided by SkyAPI 
-- Game: AppID 2932640
addappid(2932640)
addappid(2932641, 1, "447eae7e1a88a207f0562a3ed5100528f30bcd1c24b4e7fe17cb1c2095194485")
