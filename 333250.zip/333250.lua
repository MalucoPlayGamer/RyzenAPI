-- Lua provided by RyzenAPI
-- Game: Game: AppID 333250

-- MAIN APPLICATION
addappid(333250)
-- Game: addappid(333250)

-- MAIN APP DEPOTS / PACKAGES
addappid(333251, 1, "75e161caaf67b9489ffd8c32f0bb0f2c2f0dbe98f20621bafeb49cb573b5568d")
addappid(333252, 1, "49b64b598ef98c10c14bb21b8ea8f48f10bcc148699eb355140f75134979696f")
addappid(333253, 1, "2ffe4788edbedcc27efa19ac11e07ebeeab97bfb6c6e3fdf562526a1b4497e65")
addappid(348690, 0, "49d8b879d051270bed4395b8eb3c2a43ac61b5702990527f65b349751b186895")
