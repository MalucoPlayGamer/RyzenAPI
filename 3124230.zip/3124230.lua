-- Lua provided by RyzenAPI
-- Game: Jackal

-- MAIN APPLICATION
addappid(3124230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124231, 1, "64e235d5dc909ec5d1ef63fce7db606cf9e0b86e435b7035947faf47dce756a0")
