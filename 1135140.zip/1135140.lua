-- Lua provided by RyzenAPI
-- Game: Game: AppID 1135140

-- MAIN APPLICATION
addappid(1135140)
-- Game: addappid(1135140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135141, 1, "fd9b19faba6434c6c5581d9aeb2dda2e161afe557711fc060e1ad9511f5810cb")
