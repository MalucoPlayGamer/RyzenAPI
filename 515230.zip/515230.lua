-- Lua provided by RyzenAPI
-- Game: Cleo's Lost Idols

-- MAIN APPLICATION
addappid(515230)
addappid(706120)
addappid(706121)
addappid(706122)

-- MAIN APP DEPOTS / PACKAGES
addappid(515231, 1, "561d9bb239dd90f9471e7c217d11dc40d643ab690c11a7cfd69d6849236bf987")
addappid(515232, 1, "2081a804734b09b43245950e7addbf085761560708981ecf9102f7acd89f7fa6")

