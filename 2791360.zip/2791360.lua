-- Lua provided by RyzenAPI
-- Game: PINEAPPLE: A Bittersweet Revenge

-- MAIN APPLICATION
addappid(2791360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791361, 1, "d601f819750369c59ebb0600bf60af433b6749e40180d70a9102d471d29ce169")

