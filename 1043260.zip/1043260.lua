-- Lua provided by SkyAPI 
-- Game: Gladiator Guild Manager
addappid(1043260)
addappid(1043261, 1, "8c865483c01f4bb7399ff967ccfc9a7e110d62a197a7fd9ecf4792f5d9c3fe66")
addappid(1043262, 1, "c8f22281632780ee9ecb3c7d19fdc66ff60f7810d61253bfeeb49fd38412aaf8")
addappid(1043263, 1, "0e8605c7059bd533b9d6fdfa7ca53fbe33c13fd3c09aa5caf609ddce82d74a41")
