-- Lua provided by SkyAPI 
-- Game: Monster Line of Defense
addappid(2373340)
addappid(2373341, 1, "6fe7a8c6b01b7e7a8f9c7121bb508170ab6d1ede14c5208843c64d7802bd580c")
addappid(2378000, 0, "d80e9c7965bb4ac49001dba834c643b9089f628394ee6dce37b54334d19793d4")
