-- Lua provided by RyzenAPI
-- Game: Game: Cat Adventure 2

-- MAIN APPLICATION
addappid(1913320)
-- Game: addappid(1913320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913321, 1, "d56feadc2eb8f3c3abfb79d5cf8b540f2143857affb3c93570df2fd2005525f8")
