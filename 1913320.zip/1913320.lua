-- Lua provided by RyzenAPI
-- Game: Cat Adventure 2

-- MAIN APPLICATION
addappid(1913320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1913321, 1, "d56feadc2eb8f3c3abfb79d5cf8b540f2143857affb3c93570df2fd2005525f8")

