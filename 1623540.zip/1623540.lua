-- Lua provided by RyzenAPI
-- Game: Hentai VR 2

-- MAIN APPLICATION
addappid(1623540)
-- Game: addappid(1623540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623541, 1, "ed6308c4c2be5330e3faebe886e98dc5bb4e18f19e1f5156059fdf27f8e9b529")
