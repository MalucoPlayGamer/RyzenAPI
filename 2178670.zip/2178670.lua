-- Lua provided by RyzenAPI
-- Game: addappid(2178670)

-- MAIN APPLICATION
addappid(2178670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178673,0,"eb49255c60607a3215a82c0eccefa065a10585b81007c48a22f23a1292bbff5d")
