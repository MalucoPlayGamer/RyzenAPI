-- Lua provided by RyzenAPI
-- Game: setManifestid(2050212,"626555373982605625")

-- MAIN APPLICATION
addappid(2050210)
-- Game: addappid(2050210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050212,0,"4d888fdacd6ecb07f354d0bb8d74aa91f57c5cf28912408d365083bde2c3cb27")
