-- Lua provided by SkyAPI 
-- Game: AppID 2950160
addappid(2950160)
addappid(2950161, 1, "dff49ceb947d933573ccf3a9828080da42459650b4986027e98d3895e2ded5b6")
