-- Lua provided by SkyAPI 
-- Game: Tormented Souls Demo
addappid(1652610)
addappid(1652611, 1, "0d95c4fa332b49d4fe6478d76488aca22f36b5fde77a8bf5180e912811eea9ea")
