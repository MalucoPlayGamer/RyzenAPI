-- Lua provided by RyzenAPI
-- Game: Tormented Souls Demo

-- MAIN APPLICATION
addappid(1652610)
-- Game: addappid(1652610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652611, 1, "0d95c4fa332b49d4fe6478d76488aca22f36b5fde77a8bf5180e912811eea9ea")
