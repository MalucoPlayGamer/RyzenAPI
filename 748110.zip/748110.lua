-- Lua provided by RyzenAPI
-- Game: Kitten Madness

-- MAIN APPLICATION
addappid(748110)

-- MAIN APP DEPOTS / PACKAGES
addappid(748111,0,"2cdeae4311a05f6c9592f0da4ca39f8bf09960f6991a5c01b224bd2f6f9cdd7d")

