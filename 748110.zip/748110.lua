-- Lua provided by RyzenAPI
-- Game: Kitten Madness

-- MAIN APPLICATION
addappid(748110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(748111,0,"2cdeae4311a05f6c9592f0da4ca39f8bf09960f6991a5c01b224bd2f6f9cdd7d")

