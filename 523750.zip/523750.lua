-- Lua provided by RyzenAPI
-- Game: AppID 523750

-- MAIN APPLICATION
addappid(523750)

-- MAIN APP DEPOTS / PACKAGES
addappid(523751, 1, "8c7479e4259707d8363ea976671db536f0331c7ab5fb299befeeec0267ff6f99")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
