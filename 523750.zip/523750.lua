-- Lua provided by RyzenAPI
-- Game: AppID 523750

-- MAIN APPLICATION
addappid(523750)
-- Game: addappid(523750)

-- MAIN APP DEPOTS / PACKAGES
addappid(523751, 1, "8c7479e4259707d8363ea976671db536f0331c7ab5fb299befeeec0267ff6f99")
