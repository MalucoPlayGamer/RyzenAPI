-- Lua provided by RyzenAPI
-- Game: Age of Empires Mobile: PC Edition

-- MAIN APPLICATION
addappid(2783360)
