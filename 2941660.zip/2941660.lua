-- Lua provided by RyzenAPI
-- Game: addappid(2941660)

-- MAIN APPLICATION
addappid(2941660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941661, 1, "9e9c4a4cb9451b1e189a13b090d38f79707b0a150a3bf50a17cdd38aedfb85c5")
