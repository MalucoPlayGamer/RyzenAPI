-- Lua provided by RyzenAPI
-- Game: Easy Red 2: Normandy

-- MAIN APPLICATION
addappid(2317930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317930,0,"abd13ac0def91994aa63d469d8606fe414d99506f540f683af7807eef45cf1dc")

