-- Lua provided by RyzenAPI
-- Game: AppID 1036200

-- MAIN APPLICATION
addappid(1036200)
addappid(1036220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1036201, 1, "e6e655f85c561b42499bd24daa9b6f2ae87b88bb1afece0c4ac0a66f72802626")

