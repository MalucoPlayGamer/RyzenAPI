-- Lua provided by RyzenAPI
-- Game: AppID 1036200

-- MAIN APPLICATION
addappid(1036200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036201, 1, "e6e655f85c561b42499bd24daa9b6f2ae87b88bb1afece0c4ac0a66f72802626")
