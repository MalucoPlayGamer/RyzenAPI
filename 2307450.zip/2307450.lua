-- Lua provided by SkyAPI 
-- Game: AppID 2307450
addappid(2307450)
addappid(2307451, 1, "b51d1722f97cb8582d0785f1768984c758719b7e3618a28fc707395def1c7f67")
