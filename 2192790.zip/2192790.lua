-- Lua provided by RyzenAPI
-- Game: The Walking Dead: Destinies

-- MAIN APPLICATION
addappid(2192790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192791, 1, "7745876eee038640635797aefd1c9ac282814264233cbe7063fc6697744324c7")

