-- Lua provided by RyzenAPI
-- Game: AppID 781600

-- MAIN APPLICATION
addappid(781600)
-- Game: addappid(781600)

-- MAIN APP DEPOTS / PACKAGES
addappid(781601, 1, "3d94c548529b7f10a8301a1ca6767b8ac85c4d675c31dffdbd51d6f26e2129b7")
addappid(781602, 1, "7756fb70f00b5e3ba7a0cfdc02016c3ab73d5081f7ac80d5e0682a4b31657541")
