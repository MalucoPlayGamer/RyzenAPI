-- Lua provided by RyzenAPI
-- Game: Jack Holmes : Master of Puppets PROLOGUE

-- MAIN APPLICATION
addappid(2489510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489511, 1, "197abaa1c834b2fe67d9aa564e8854def02662ce54b8fbfb6beb0e989e97f5c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
