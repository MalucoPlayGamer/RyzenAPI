-- Lua provided by RyzenAPI
-- Game: AppID 282640

-- MAIN APPLICATION
addappid(282640)

-- MAIN APP DEPOTS / PACKAGES
addappid(282641, 1, "46c6ee641c5bde057d49477314b4f7b5c5d1dce4c38a47c1fd5ab2ea2f43f0b2")
addappid(349810, 0, "72f751d4cede316bce2b52f0551bf81d92e4392fe044d66cf5fc2845320773be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
