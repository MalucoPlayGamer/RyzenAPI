-- Lua provided by RyzenAPI
-- Game: Metal Fatigue

-- MAIN APPLICATION
addappid(888040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(888041, 1, "e7c113c3591b403342314c08a967a28740da94e6c05987e2da7ebd2196e01688")
addappid(888042, 1, "0f1b8bbd841e05fb5ac862115fc779e299bd04f0ddbdfac3c26e53dfff87ec01")
