-- Lua provided by RyzenAPI
-- Game: Game: Knockout League - Arcade VR Boxing

-- MAIN APPLICATION
addappid(488920)
-- Game: addappid(488920)

-- MAIN APP DEPOTS / PACKAGES
addappid(488921, 1, "ca1006d5bfc1e6d6b15badab24309bb6b26c93e2e0a316f4dddec5f27e4f4631")
addappid(907080, 0, "e34db0638d042874918e35c6b39cc9f00441a1d9d3fa4f2e8552b4b624437fb4")
