-- Lua provided by RyzenAPI
-- Game: Game: Path of the Sramana

-- MAIN APPLICATION
addappid(1231530)
-- Game: addappid(1231530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231531, 1, "253dd7f9ea04c158be52926d77216f254e95905af1fc2a5750788b2816a0b15e")
