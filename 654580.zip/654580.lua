-- Lua provided by RyzenAPI
-- Game: 654580

-- MAIN APPLICATION
addappid(654580)
addappid(654581)
addappid(654583)
addappid(654584)
addappid(654585)

-- MAIN APP DEPOTS / PACKAGES
addappid(654582,0,"2d5c365de1e2d9f8ce15690afa3e233e8e3f4a5761769c207a1e420de66ac5ee")

