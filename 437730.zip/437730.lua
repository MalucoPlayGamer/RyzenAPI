-- Lua provided by RyzenAPI
-- Game: Roadclub: League Racing

-- MAIN APPLICATION
addappid(437730)

-- MAIN APP DEPOTS / PACKAGES
addappid(437731, 1, "7fe019b76afa51c9f87efac5c62b434a2709f197b20567a8795c1a1ae31e393f")
