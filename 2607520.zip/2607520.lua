-- Lua provided by RyzenAPI
-- Game: Game: AppID 2607520

-- MAIN APPLICATION
addappid(2607520)
-- Game: addappid(2607520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607521, 1, "65a97cb93c499a8b37d72b4f4e5e0f9842c799a52a9e4a7f4c213510f32224f1")
