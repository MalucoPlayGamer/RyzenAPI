-- Lua provided by RyzenAPI
-- Game: Bonhomme 7 Heures

-- MAIN APPLICATION
addappid(1590380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590381, 1, "2089ef58b815f3fb73465a2e14420350dc06ce1f449c32d42ec9b7b6bf7305ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
