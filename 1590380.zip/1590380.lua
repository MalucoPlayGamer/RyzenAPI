-- Lua provided by RyzenAPI 
-- Game: Bonhomme 7 Heures
addappid(1590380)
addappid(1590381, 1, "2089ef58b815f3fb73465a2e14420350dc06ce1f449c32d42ec9b7b6bf7305ae")
