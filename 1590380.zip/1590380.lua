-- Lua provided by RyzenAPI
-- Game: Bonhomme 7 Heures

-- MAIN APPLICATION
addappid(1590380)
-- Game: addappid(1590380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590381, 1, "2089ef58b815f3fb73465a2e14420350dc06ce1f449c32d42ec9b7b6bf7305ae")
