-- Lua provided by RyzenAPI
-- Game: Game: AppID 2351570

-- MAIN APPLICATION
addappid(2351570)
-- Game: addappid(2351570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351571, 1, "9313de3d614a5001aa1d67315797b7fd0860a620a4990e34f553e031a8fb4b97")
