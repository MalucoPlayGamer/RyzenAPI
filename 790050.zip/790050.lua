-- Lua provided by RyzenAPI
-- Game: addappid(790050)

-- MAIN APPLICATION
addappid(790050)

-- MAIN APP DEPOTS / PACKAGES
addappid(790051, 1, "8c0230f6eb3cef30ee0ea15e06df9c07cf3b7494f355175ee5bb2d7a40664f9e")
