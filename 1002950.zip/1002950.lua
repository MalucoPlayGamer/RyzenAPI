-- Lua provided by RyzenAPI
-- Game: addappid(1002950)

-- MAIN APPLICATION
addappid(1002950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002951, 1, "bd7b16ef1ee8d19532aa668264e4861dd42ea330923d4a82873c2388dc674ebb")
