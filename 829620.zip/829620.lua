-- Lua provided by RyzenAPI
-- Game: Robbie Swifthand and the Orb of Mysteries Demo

-- MAIN APPLICATION
addappid(829620)
addappid(829621)

-- MAIN APP DEPOTS / PACKAGES
addappid(718011,0,"dca072b2151a1f645010a9125d92a7714f6f59e6d7bfe02b9fa0daa0d33d241c")

