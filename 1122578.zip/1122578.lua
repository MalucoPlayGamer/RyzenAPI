-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1122578)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122578,0,"86f27d153ae6016b74afe9d31711e9e97ad302182d85b6f17159c662862707b8")
