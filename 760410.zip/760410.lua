-- Lua provided by RyzenAPI
-- Game: addappid(760410)

-- MAIN APPLICATION
addappid(760410)

-- MAIN APP DEPOTS / PACKAGES
addappid(760411, 1, "f3810f594c588f64d1740d067f0f4f2749ec5eb176b690f05d53dc67ac090a8a")
