-- Lua provided by RyzenAPI
-- Game: Mythic Love: Iberian Legends

-- MAIN APPLICATION
addappid(2654990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654991,0,"a8c2f9b41597eaa803570eb201c33c55764483ecb3ea3cedc4d835dd19182a16")
