-- Lua provided by RyzenAPI
-- Game: Game: BiblioMania

-- MAIN APPLICATION
addappid(1848120)
-- Game: addappid(1848120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848121, 1, "5ed055a88db2a42afe832c28ebf8fbe3576b1133f9add34c005469dfe7ef4bfe")
