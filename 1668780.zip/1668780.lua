-- Lua provided by RyzenAPI
-- Game: Firelight Fantasy: Vengeance

-- MAIN APPLICATION
addappid(1668780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1668781, 1, "3d1ca8b02f028604229f63beac922bab96863c21c6f8260db6d5c2219739ca86")

