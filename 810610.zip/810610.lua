-- Lua provided by RyzenAPI
-- Game: Mission Of Hero

-- MAIN APPLICATION
addappid(810610)
-- Game: addappid(810610)

-- MAIN APP DEPOTS / PACKAGES
addappid(810611, 1, "fd5ad6298c7e3630f99bb109c95193d00fb44f4000a9d84da03124eaa75eeb76")
