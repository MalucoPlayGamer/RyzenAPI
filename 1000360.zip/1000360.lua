-- Lua provided by SkyAPI 
-- Game: AppID 1000360
addappid(1000360)
addappid(1000361, 1, "b5b97451061159abe6184f5c46e24d7d3a1898c26611b7dce09483c6b5843f79")
