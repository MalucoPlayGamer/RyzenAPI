-- Lua provided by RyzenAPI
-- Game: addappid(2258010)

-- MAIN APPLICATION
addappid(2258010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258011, 1, "4414d60594be7ef86c0cdb170fcc937f035af4124ee3c83db11f6a01063aa520")
