-- Lua provided by RyzenAPI
-- Game: addappid(370710)

-- MAIN APPLICATION
addappid(370710)

-- MAIN APP DEPOTS / PACKAGES
addappid(370711, 1, "c4da71f665157eeab5160c8388ea39d8ab07be369e2192183f66409469b3d9ca")
