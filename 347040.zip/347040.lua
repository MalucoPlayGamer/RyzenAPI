-- Lua provided by RyzenAPI
-- Game: addappid(347040)

-- MAIN APPLICATION
addappid(347040)

-- MAIN APP DEPOTS / PACKAGES
addappid(347041, 1, "053f67edbd819b056ab6a9ce3d4b208bcef6f2e853f74551e2a58135aa8f37b3")
addappid(347042, 1, "b7b7d95815c69e43eb63d5b65b6dea6e9fb52a642d9cccf221aafd5b1edc7def")
