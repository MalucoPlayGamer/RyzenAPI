-- Lua provided by RyzenAPI
-- Game: 559150

-- MAIN APPLICATION
addappid(559150)
-- Game: addappid(559150)

-- MAIN APP DEPOTS / PACKAGES
addappid(559151, 1, "acc9d267f682c83a681985a9638bee6b13353c292426158654ea6b88ce9982aa")
