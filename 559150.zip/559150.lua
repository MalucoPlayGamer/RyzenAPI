-- Lua provided by RyzenAPI 
-- Game: Royal Detective: The Lord of Statues Collector's Edition
addappid(559150)
addappid(559151, 1, "acc9d267f682c83a681985a9638bee6b13353c292426158654ea6b88ce9982aa")
