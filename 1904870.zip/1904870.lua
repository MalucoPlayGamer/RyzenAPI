-- Lua provided by RyzenAPI
-- Game: City Bus Manager - Asia

-- MAIN APPLICATION
addappid(1904870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904871, 1, "3c265b55622dc8cf1671c7cef104df57a21a364dc7c66312c17a05b6fc3ba17b")
