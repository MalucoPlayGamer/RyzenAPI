-- Lua provided by RyzenAPI
-- Game: Game: Intelligence: Dinosaurs

-- MAIN APPLICATION
addappid(835680)
addappid(908680)
-- Game: addappid(835680)

-- MAIN APP DEPOTS / PACKAGES
addappid(835681, 1, "af34b138321830519033bddb29bca9281874d91b53fb7ee22167184da641a365")
