-- Lua provided by RyzenAPI
-- Game: addappid(3579960)

-- MAIN APPLICATION
addappid(3579960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3579961, 1, "39815d6d8e5d411d907c698bb62c31338bf1d51dae9faeda6240e41dd22d6a68")
