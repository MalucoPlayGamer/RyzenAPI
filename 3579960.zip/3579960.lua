-- Lua provided by RyzenAPI
-- Game: Laser Tag Massacre

-- MAIN APPLICATION
addappid(3579960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3579961, 1, "39815d6d8e5d411d907c698bb62c31338bf1d51dae9faeda6240e41dd22d6a68")

