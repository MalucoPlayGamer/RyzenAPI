-- Lua provided by RyzenAPI
-- Game: addappid(873030)

-- MAIN APPLICATION
addappid(873030)

-- MAIN APP DEPOTS / PACKAGES
addappid(873030,0,"71a772c0c608b221f92db02803de7868d1ba7e1aba0c6ca4e9933e7f194c22c1")
