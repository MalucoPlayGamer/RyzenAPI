-- Lua provided by RyzenAPI
-- Game: Pillars of Dust

-- MAIN APPLICATION
addappid(1144140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144141, 1, "1ba3f94746752c31ad476e18faead6159954eda130a5c71dc83f34985d605c2b")

