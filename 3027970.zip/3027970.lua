-- Lua provided by RyzenAPI
-- Game: Neon Phonk Robots

-- MAIN APPLICATION
addappid(3027970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027971, 1, "18b092f4503a1cf37a6814dd2d8a9127c2705908b65876c5dfbb114738880627")

