-- Lua provided by RyzenAPI
-- Game: Blacklight: Retribution

-- MAIN APPLICATION
addappid(209870)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228990)
addappid(229003)
addappid(229031)

-- MAIN APP DEPOTS / PACKAGES
addappid(209871, 1, "b8f0f4d375949c868e38effc0492760fc1c222d3eca77ef311f85105fa80f056")
