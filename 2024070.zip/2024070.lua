-- Lua provided by RyzenAPI
-- Game: Party Quiz

-- MAIN APPLICATION
addappid(2024070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024071, 1, "ca9aa81b0b92768ac495e7e7c41612806728a9c8e87ae18f6e2036d8ad65909e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
