-- Lua provided by RyzenAPI
-- Game: Party Quiz

-- MAIN APPLICATION
addappid(2024070)
-- Game: addappid(2024070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024071, 1, "ca9aa81b0b92768ac495e7e7c41612806728a9c8e87ae18f6e2036d8ad65909e")
