-- Lua provided by RyzenAPI
-- Game: 2713650

-- MAIN APPLICATION
addappid(2713650)
-- Game: addappid(2713650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2713651, 1, "d0bc6b08cad6a8b5a6df52d97864493ac761031d660a894f4c3f4e92b6210827")
