-- Lua provided by RyzenAPI
-- Game: Femdom Wife Game - Zoe Demo

-- MAIN APPLICATION
addappid(2393220)
-- Game: addappid(2393220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393222,0,"9248429fba086260fa317ab9f316485725e0e21bbc79a0a9d624915cd57ad87a")
