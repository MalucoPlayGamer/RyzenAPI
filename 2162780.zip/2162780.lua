-- Lua provided by RyzenAPI
-- Game: 2162780

-- MAIN APPLICATION
addappid(2162780)
-- Game: addappid(2162780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162781, 1, "38334d38e2b8fd14f4aa8218d79eb1494d35a6dd2978f9d543c66a30d1b8fcd9")
