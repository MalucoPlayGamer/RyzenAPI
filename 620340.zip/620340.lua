-- Lua provided by RyzenAPI 
-- Game: Cubrick
addappid(620340)
addappid(620341, 1, "d3d03c9187927703affaeff633325dc38fc87b6fa0e9be8edab5e54455cfe0b1")
