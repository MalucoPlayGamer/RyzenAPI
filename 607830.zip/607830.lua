-- Lua provided by RyzenAPI
-- Game: 607830

-- MAIN APPLICATION
addappid(607830)
-- Game: addappid(607830)

-- MAIN APP DEPOTS / PACKAGES
addappid(607830,0,"b6f04e102f22c7b200ab88e53bf169aa2f01f764c6d71423ba7c303ba00f38de")
