-- Lua provided by RyzenAPI
-- Game: photonflowers* - Wallpaper Pack

-- MAIN APPLICATION
addappid(1158540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158540,0,"3d0f0961d7f51a6bfc36d9000d1e7d3867528e1086b09bbe443179508c3a7b9c")

