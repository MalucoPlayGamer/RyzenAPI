-- Lua provided by RyzenAPI
-- Game: AppID 756440

-- MAIN APPLICATION
addappid(756440)
-- Game: addappid(756440)

-- MAIN APP DEPOTS / PACKAGES
addappid(756441, 1, "8d6d0a4601a5b12dfac4724fe1f2d78f636d6ac9a704628c40c39f0e51f32e55")
