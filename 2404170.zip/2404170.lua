-- Lua provided by RyzenAPI
-- Game: Museum No.9

-- MAIN APPLICATION
addappid(2404170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404171, 1, "3ade580bf3dd00c6ff74161f3f407215f16aeb209a8136c769e70560fd82896b")

