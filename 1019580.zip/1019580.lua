-- Lua provided by RyzenAPI
-- Game: AppID 1019580

-- MAIN APPLICATION
addappid(1019580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019581, 1, "05863b17f41cfe47a2d9a1671bdab3b781fdbd351b32a66cd78a7e1c3a6cc131")
