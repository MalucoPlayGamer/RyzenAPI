-- Lua provided by RyzenAPI
-- Game: Re:Touring

-- MAIN APPLICATION
addappid(2318920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318921, 1, "18da0c4e85514b33ec1e0374977ee90b4770118921cd34dc2b0a697593c0e142")

