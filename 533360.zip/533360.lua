-- Lua provided by RyzenAPI
-- Game: Zia and the goddesses of magic

-- MAIN APPLICATION
addappid(533360)

-- MAIN APP DEPOTS / PACKAGES
addappid(533361,0,"8e8ec271b6a9bf42f2227f8447ae31a83ed31362c3e5c9596f3e41436c3d8dd5")

