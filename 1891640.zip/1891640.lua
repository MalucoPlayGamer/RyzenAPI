-- Lua provided by RyzenAPI
-- Game: AZUR BEAM

-- MAIN APPLICATION
addappid(1891640)
-- Game: addappid(1891640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891641, 1, "a625479bf7db5ae0929550000b74577f33eca8c1d590b346377f6f50441afbef")
