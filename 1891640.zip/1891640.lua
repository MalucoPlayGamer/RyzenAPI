-- Lua provided by RyzenAPI 
-- Game: AZUR BEAM
addappid(1891640)
addappid(1891641, 1, "a625479bf7db5ae0929550000b74577f33eca8c1d590b346377f6f50441afbef")
