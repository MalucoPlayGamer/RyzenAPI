-- Lua provided by RyzenAPI
-- Game: CHR$(143) Demo

-- MAIN APPLICATION
addappid(1695700)
-- Game: addappid(1695700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695701, 1, "7dff49e9f917266153620ce844f73c1a717fd0068a12ec46a8acc5f246741de0")
