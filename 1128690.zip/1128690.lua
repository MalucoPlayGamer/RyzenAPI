-- Lua provided by RyzenAPI
-- Game: Plunge

-- MAIN APPLICATION
addappid(1128690)
addappid(1147410)
-- Game: addappid(1128690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128691, 1, "6ef38e7f09926320b599a69dd9ffa73635070d3b54de898dd8b14d7ab770e20b")
addappid(1128692, 1, "d91c59eb39d78d1b344dea244e9d62ce197de001ca687dcea501bdc772b34f6c")
