-- Lua provided by RyzenAPI
-- Game: Plunge

-- MAIN APPLICATION
addappid(1128690)
addappid(1147410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1128691, 1, "6ef38e7f09926320b599a69dd9ffa73635070d3b54de898dd8b14d7ab770e20b")
addappid(1128692, 1, "d91c59eb39d78d1b344dea244e9d62ce197de001ca687dcea501bdc772b34f6c")

