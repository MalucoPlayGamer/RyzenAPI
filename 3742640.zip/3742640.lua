-- Lua provided by RyzenAPI
-- Game: 3742640

-- MAIN APPLICATION
addappid(3742640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742640,0,"d38d3feda696cf727d0c475dc1b483babd0b2cb8f7a9c475318f1f6c0b410038")

