-- Lua provided by RyzenAPI
-- Game: Gods Will Be Watching

-- MAIN APPLICATION
addappid(274290)
-- Game: addappid(274290)

-- MAIN APP DEPOTS / PACKAGES
addappid(274291, 1, "83c607500843186e8213d5ce7dadbc14220a48e1e3e5733512d2224442dee279")
addappid(274292, 1, "375805dfe7b1805d771ead54e373b3ac0601690768e39b14324da24e108b0a0e")
addappid(274293, 1, "cd842fe49afe62fa4e20dceca4c80f16429fc6250a4777bf1dcfdd4887cd79a0")
addappid(274295, 1, "199e095b74bbc2341a821f3ce250c4e22bf9289ba2009db7c1f13470f9d4e09b")
