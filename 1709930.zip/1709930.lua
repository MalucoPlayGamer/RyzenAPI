-- Lua provided by RyzenAPI
-- Game: addappid(1709930)

-- MAIN APPLICATION
addappid(1709930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709931, 1, "ad690e2079b1c3cacfa6090825513b30eb3afeff9cbe8a6f78a405b60a5c750b")
addappid(1709932, 1, "6989567bdfa5bfd3d7821a4d153e2fc09df460d8c9c0ec77f8cba18efcd8b346")
