-- Lua provided by RyzenAPI
-- Game: The Homecoming Exhibition

-- MAIN APPLICATION
addappid(2294990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2294991, 1, "3407e81ad609cc48988c7c591feb91a63105f23e3377a9af38311ece860dc0df")

