-- Lua provided by RyzenAPI
-- Game: HimeYoku: A Sacrifice of Lust and Grace Soundtrack

-- MAIN APPLICATION
addappid(2245340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245341, 1, "eeb1a9db60368b9fc5b66a9f10ac26a65714a1669c82a3d4d5d3dac1cc86f9c9")
addappid(2245342, 1, "f10ebe5f9a45b15a10cba99e02a6da7db2a2872694ba8194fbb43fe9cdfa77cb")

