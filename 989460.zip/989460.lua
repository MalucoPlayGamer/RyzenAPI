-- Lua provided by RyzenAPI
-- Game: 脚本塔防 Massacre  Tower

-- MAIN APPLICATION
addappid(989460)
addappid(989461)

-- MAIN APP DEPOTS / PACKAGES
addappid(989462,0,"53f04172e08694c247045bd16f71fa049031a0cb6d24c80bb8ea3dbbe4aaddea")
