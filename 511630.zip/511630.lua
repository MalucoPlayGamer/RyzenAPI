-- Lua provided by RyzenAPI
-- Game: 511630

-- MAIN APPLICATION
addappid(511630)
addappid(618180)
-- Game: addappid(511630)

-- MAIN APP DEPOTS / PACKAGES
addappid(511631, 1, "b5f40a61bd8170df8106edfc47aea88087df0707d2f7e63917610b2f26f13cdb")
