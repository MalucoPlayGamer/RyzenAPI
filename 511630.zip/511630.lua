-- Lua provided by SkyAPI 
-- Game: Max, an Autistic Journey
addappid(511630)
addappid(511631, 1, "b5f40a61bd8170df8106edfc47aea88087df0707d2f7e63917610b2f26f13cdb")
addappid(618180)
