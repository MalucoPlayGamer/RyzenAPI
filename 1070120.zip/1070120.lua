-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1070120)
-- Game: addappid(1070120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070120,0,"7be8be3e1634d7872075a94ca92aacd447542c9c6ef10899caa1a90c80a087ca")
