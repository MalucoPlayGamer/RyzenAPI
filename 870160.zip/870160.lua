-- Lua provided by SkyAPI 
-- Game: AppID 870160
addappid(870160)
addappid(870161, 1, "7480173b2d2b06618295ac8a814e2d139d09c7b360f9b6633283daf1715f0c93")
