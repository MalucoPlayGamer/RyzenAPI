-- Lua provided by RyzenAPI
-- Game: R.O.V.E.R.

-- MAIN APPLICATION
addappid(870160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(870161, 1, "7480173b2d2b06618295ac8a814e2d139d09c7b360f9b6633283daf1715f0c93")
