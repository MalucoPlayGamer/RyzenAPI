-- Lua provided by RyzenAPI
-- Game: Hacknet

-- MAIN APPLICATION
addappid(365450)
addappid(521840)

-- MAIN APP DEPOTS / PACKAGES
addappid(365451, 1, "bbbb5f70e666008307c6c11f917cf6f03781c29e49fe5762536e5aca4c119b97")
addappid(365453, 1, "f1afe8097c6dbeead2d6613c83c4f1fd05e257a5fb947a488c6a2fd2921e3d9c")
addappid(365454, 1, "03f224c738b9bbf65120893dcdb5a3e8aa361fb9b15a48ba72b16272422becde")
addappid(365455, 1, "e78fa655688c8f09ce374b855e4dbf0307a1bea8082843118049700b0433c46c")
addappid(365456, 1, "0c7ed01961fbe859446edb5c1164fa186e956ea5907ec3dadd2fe3fd77a394da")
addappid(365458, 1, "a4ef3ad79afb43c168e0c3f756a4f7d4b5dec49ab6c30a4798ed65a445ae2470")
addappid(365459, 1, "354287bd02690e680e610dd55d1797ac6862e80015d3deeb49151696de98cb40")
addappid(408711, 0, "ac86110f9a605651695235db27a8a3554f3484a2de635e606af18125d41cb481")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
