-- Lua provided by RyzenAPI
-- Game: addappid(1904230)

-- MAIN APPLICATION
addappid(1904230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904231, 1, "dda0a7d434c06dde37bf6c5d686a16981d8cde962e0b38c53d7fa298dc5dd764")
