-- Lua provided by SkyAPI 
-- Game: AppID 2350
addappid(2350)
addappid(2351, 1, "7452700559c276dcec0c7e12b956bf1bde9fd78a26f15efdedc7047abdaacb26")
