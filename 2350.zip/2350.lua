-- Lua provided by RyzenAPI
-- Game: 2350

-- MAIN APPLICATION
addappid(2350)
-- Game: addappid(2350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351, 1, "7452700559c276dcec0c7e12b956bf1bde9fd78a26f15efdedc7047abdaacb26")
