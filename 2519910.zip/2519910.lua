-- Lua provided by RyzenAPI
-- Game: Creature Rumble

-- MAIN APPLICATION
addappid(2519910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519911, 1, "23ecd3ed19abfeadaca43d4368f93e2c8b49ce740e158d582460c82c12fcd65f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
