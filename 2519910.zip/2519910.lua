-- Lua provided by RyzenAPI
-- Game: 2519910

-- MAIN APPLICATION
addappid(2519910)
-- Game: addappid(2519910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519911, 1, "23ecd3ed19abfeadaca43d4368f93e2c8b49ce740e158d582460c82c12fcd65f")
