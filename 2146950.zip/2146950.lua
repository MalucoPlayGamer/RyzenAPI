-- Lua provided by RyzenAPI
-- Game: addappid(2146950)

-- MAIN APPLICATION
addappid(2146950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146951, 1, "a899cd6b11b2b673e948e58fd208213ba2a2332423598cd3f50ee095a2cc1250")
