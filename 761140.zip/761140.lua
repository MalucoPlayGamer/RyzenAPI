-- Lua provided by RyzenAPI
-- Game: Lost Summoner Kitty

-- MAIN APPLICATION
addappid(761140)

-- MAIN APP DEPOTS / PACKAGES
addappid(761141,0,"5725cbddf875e346017267f3841864ea7e019656ffad0b0af414a37549adbd9b")

