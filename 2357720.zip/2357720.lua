-- Lua provided by RyzenAPI
-- Game: Game: Street Legal 1: REVision Demo

-- MAIN APPLICATION
addappid(2357720)
-- Game: addappid(2357720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357721, 1, "5377844d06272475622adf0b295393570c980d02cdc44aed1de43faf383f07a4")
