-- Lua provided by RyzenAPI
-- Game: Constricting Cubes

-- MAIN APPLICATION
addappid(535270)

-- MAIN APP DEPOTS / PACKAGES
addappid(535271, 1, "d0045ec7db9d3a5b6c2296d50968986212adb57ddb70f199c0a0a37b204bc7fb")

