-- Lua provided by RyzenAPI
-- Game: Constricting Cubes

-- MAIN APPLICATION
addappid(535270)

-- MAIN APP DEPOTS / PACKAGES
addappid(535271, 1, "d0045ec7db9d3a5b6c2296d50968986212adb57ddb70f199c0a0a37b204bc7fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
