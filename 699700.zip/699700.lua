-- Lua provided by RyzenAPI
-- Game: 699700

-- MAIN APPLICATION
addappid(699700)
-- Game: addappid(699700)

-- MAIN APP DEPOTS / PACKAGES
addappid(699701, 1, "40d1780d9e628c4fe87146f29048eb7e0f7e7efdc982ce1cfe399b18fd5e87b0")
