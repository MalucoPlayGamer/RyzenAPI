-- Lua provided by SkyAPI 
-- Game: Fight Angel Special Edition
addappid(1041840)
addappid(1041841, 1, "dc5500497b281207f5fa2f61d1f802022878ea11d5c7b1a73d39ba9bcb2c6633")
