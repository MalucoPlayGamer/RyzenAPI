-- Lua provided by RyzenAPI
-- Game: Szybowcowa '87

-- MAIN APPLICATION
addappid(2246650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2246651, 1, "9e180ce7d7fb0a18906b9bc5301cb8e5bcb51079ebb3303e16ba23f802da58e7")

