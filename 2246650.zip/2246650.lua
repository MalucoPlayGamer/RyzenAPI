-- Lua provided by RyzenAPI 
-- Game: Szybowcowa '87
addappid(2246650)
addappid(2246651, 1, "9e180ce7d7fb0a18906b9bc5301cb8e5bcb51079ebb3303e16ba23f802da58e7")
