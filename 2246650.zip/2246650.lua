-- Lua provided by RyzenAPI
-- Game: 2246650

-- MAIN APPLICATION
addappid(2246650)
-- Game: addappid(2246650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246651, 1, "9e180ce7d7fb0a18906b9bc5301cb8e5bcb51079ebb3303e16ba23f802da58e7")
