-- Lua provided by RyzenAPI
-- Game: Undefeated

-- MAIN APPLICATION
addappid(332390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(332391, 1, "7aa6c1cf9d40347b19dae1555402e6eece4948a0995978201b2896224e727115")
addappid(362980, 0, "bffd248e3279962af86c869514f79c7f1cdf16cd77f6fdfd7d6efe06e91fadd6")
addappid(394080, 0, "1fb1033b747c1c1cfc304039a1c714b4163d4542eff40c1c9c548ab43c42af4e")

