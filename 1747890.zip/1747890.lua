-- Lua provided by RyzenAPI
-- Game: Demon Turf: Neon Splash

-- MAIN APPLICATION
addappid(1747890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747891, 1, "a4fc3ee6ae402cadfe40c62942a5cca01b81aaf33ca92da936ea098dd7b8a226")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
