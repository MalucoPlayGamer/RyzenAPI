-- Lua provided by RyzenAPI
-- Game: SWAT 3: Tactical Game of the Year Edition

-- MAIN APPLICATION
addappid(560370)

-- MAIN APP DEPOTS / PACKAGES
addappid(560371, 1, "c9aa79b0b3471a84b4884995978fcdcf0e01f7c2ef38e2b0e45acb1deb99a890")
