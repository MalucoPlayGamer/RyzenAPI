-- Lua provided by RyzenAPI
-- Game: Shining Song Starnova

-- MAIN APPLICATION
addappid(675240)

-- MAIN APP DEPOTS / PACKAGES
addappid(675241, 1, "d0ccdb0ddec1d7ce05791da978ae013f73ecf764774900c14788a26e8450b3b3")
addappid(943820, 0, "2f32944ac6314e6935f76133973bc548b13c0c2fd0288cea47bb71ff52cb7346")
addappid(978740, 0, "2ccc28946addcaa677347fce23204c676ee0f6e1433f7c2fe20735bdcef3acec")

