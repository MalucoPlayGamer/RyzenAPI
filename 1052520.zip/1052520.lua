-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Campaign Data / キャンペーンデータ

-- MAIN APPLICATION
addappid(1052520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052520,0,"1c9450c38a8756f937502b420db6703eb9aff9d219693692a057812a71f8af7d")

