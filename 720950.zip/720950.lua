-- Lua provided by RyzenAPI
-- Game: EGE DistantPlanet NonXXX

-- MAIN APPLICATION
addappid(720950)

-- MAIN APP DEPOTS / PACKAGES
addappid(720951,0,"111afee523a9cd2126147f89c3eed15fee15003116308fb8933038c7e52704f5")

