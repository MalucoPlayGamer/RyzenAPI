-- Lua provided by SkyAPI 
-- Game: AppID 601340
addappid(601340)
addappid(601341, 1, "e4bddd22c4acb5b0a0db2484ee6c56969cf1a16c410b19a9d3452d2fe80a28c2")
