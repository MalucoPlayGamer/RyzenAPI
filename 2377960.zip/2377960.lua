-- Lua provided by RyzenAPI
-- Game: Clash of Panzer

-- MAIN APPLICATION
addappid(2377960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377961, 1, "2b30d3f1d1f8d826788371c4fb2f7a813eacd1158f3d6c92298d03ccb8b1fff2")

