-- Lua provided by RyzenAPI
-- Game: Duck Side of the Moon

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2959770, 1, "b5c3f3ebc5e9bcf1e12912e3eda7d97571151156e3810f6b98101900eff8c59f") -- Duck Side of the Moon
addappid(2959772, 1, "7ce918b6b8384f41da7a9605fec0a979db28e3d55fb5bd36d3515923a7f30232") -- Depot 2959772
addappid(2959773, 1, "dc716d20a9074d90058a075eb92777986de7fe55cc1ef47034a6fb26605a8309") -- Depot 2959773

