-- Lua provided by RyzenAPI
-- Game: Game: Zombie sanctuary: Ash

-- MAIN APPLICATION
addappid(2519310)
addappid(3155530)
-- Game: addappid(2519310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519311, 1, "10490397288c96f79b2d053bbdc19d84342a55efae1b760292a439f2edaf3f27")
