-- Lua provided by RyzenAPI
-- Game: Innchanted

-- MAIN APPLICATION
addappid(1369720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369721, 1, "51d99c9a4cf45ffa568410310c3bb1d776899abc46c582a51ef476063d1a2c33")
