-- Lua provided by RyzenAPI
-- Game: Game: The Lost Souls

-- MAIN APPLICATION
addappid(453670)
-- Game: addappid(453670)

-- MAIN APP DEPOTS / PACKAGES
addappid(453671, 1, "ab09e734b17227ac13b91797450dc50c95e5d2c4838d331292d31c06c055c293")
