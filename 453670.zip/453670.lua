-- Lua provided by SkyAPI 
-- Game: The Lost Souls
addappid(453670)
addappid(453671, 1, "ab09e734b17227ac13b91797450dc50c95e5d2c4838d331292d31c06c055c293")
