-- Lua provided by RyzenAPI
-- Game: addappid(3183630)

-- MAIN APPLICATION
addappid(3183630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183632,0,"d8d06273c49f18972b93fcc17f1985a2578b1add0bff0134f40af8afc2f09c6e")
