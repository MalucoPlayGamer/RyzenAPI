-- Lua provided by RyzenAPI
-- Game: Game: NEON GALAXY

-- MAIN APPLICATION
addappid(651970)
-- Game: addappid(651970)

-- MAIN APP DEPOTS / PACKAGES
addappid(651971, 1, "ac0889ac720beb0248316548e4641c9966fb60251b0dca1ac344308107975bb0")
