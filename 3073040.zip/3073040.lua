-- Lua provided by RyzenAPI
-- Game: Seoul Station

-- MAIN APPLICATION
addappid(3073040)
-- Game: addappid(3073040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073041, 1, "d5355408014d53178ac224a6587a056472e7d3606d0ad44ee8c9862920a54b68")
