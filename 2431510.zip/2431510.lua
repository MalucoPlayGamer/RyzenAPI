-- Lua provided by RyzenAPI
-- Game: Game: BlueSuburbia

-- MAIN APPLICATION
addappid(2431510)
-- Game: addappid(2431510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431511, 1, "5c9bf5937a1c3f30c86f879d772d0705ba4b37e386e1ab80a1853670b88c8106")
