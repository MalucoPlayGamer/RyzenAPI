-- Lua provided by RyzenAPI
-- Game: Trials of Mana

-- MAIN APPLICATION
addappid(924980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(924981, 1, "244e36cc32635256e4eda55f4850ee8ac6dece4b04825dbbe4586e418f798cda")
addappid(1144960, 0, "6e104e07086cad2fa00b0088d9da6a5fdfb49ca1b8a0bf47660c190adaad0dae")
addappid(1190470, 0, "4197f91760ac16404b9fcef6851a187b50398e15d6f00b1bc222c9d273b34791")

