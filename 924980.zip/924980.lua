-- Lua provided by RyzenAPI
-- Game: Trials of Mana

-- MAIN APPLICATION
addappid(924980)

-- MAIN APP DEPOTS / PACKAGES
addappid(924981, 1, "244e36cc32635256e4eda55f4850ee8ac6dece4b04825dbbe4586e418f798cda")
addappid(1144960, 0, "6e104e07086cad2fa00b0088d9da6a5fdfb49ca1b8a0bf47660c190adaad0dae")
addappid(1190470, 0, "4197f91760ac16404b9fcef6851a187b50398e15d6f00b1bc222c9d273b34791")
