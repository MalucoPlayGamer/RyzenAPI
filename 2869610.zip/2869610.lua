-- Lua provided by RyzenAPI
-- Game: ArkCraft: The Rebirth of the World

-- MAIN APPLICATION
addappid(2869610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869611, 1, "3524764112f17ad8775391d0ece5900352fbf17b0adab066cec722b539118371")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
