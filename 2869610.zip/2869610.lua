-- Lua provided by RyzenAPI
-- Game: Game: ArkCraft: The Rebirth of the World

-- MAIN APPLICATION
addappid(2869610)
-- Game: addappid(2869610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869611, 1, "3524764112f17ad8775391d0ece5900352fbf17b0adab066cec722b539118371")
