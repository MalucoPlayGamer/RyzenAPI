-- Lua provided by RyzenAPI
-- Game: addappid(1387660)

-- MAIN APPLICATION
addappid(1387660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291011,0,"f61fc138f45f4d77105dc0fb4264842bd804e319f0fb57aece98ab3aba1e7027")
