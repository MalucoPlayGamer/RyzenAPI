-- Lua provided by SkyAPI 
-- Game: Othercide
addappid(798490)
addappid(798491, 1, "c56e56411dc96fec8738715385ff28065aac6e476400453a1764be3f4030a52c")
addappid(1347640, 0, "b49b2b47ad9dee2295cbbf1e325620ffe3de8960c78ff2999e7436d6092f7865")
