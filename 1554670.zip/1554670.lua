-- Lua provided by RyzenAPI
-- Game: Voidwalkers - Soul Hunters

-- MAIN APPLICATION
addappid(1554670)
addappid(1734380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554671, 1, "2a7582ec01109a5d36eb2d2f610a25b6798b05e301e94fd1df0840ec9dba8086")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
