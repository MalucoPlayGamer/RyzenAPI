-- Lua provided by RyzenAPI 
-- Game: Voidwalkers - Soul Hunters
addappid(1554670)
addappid(1554671, 1, "2a7582ec01109a5d36eb2d2f610a25b6798b05e301e94fd1df0840ec9dba8086")
addappid(1734380)
