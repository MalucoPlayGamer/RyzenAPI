-- Lua provided by RyzenAPI
-- Game: Game: lilGunBois: Super Team Transgender Fortress Platformer Battlegrounds

-- MAIN APPLICATION
addappid(860080)
-- Game: addappid(860080)

-- MAIN APP DEPOTS / PACKAGES
addappid(860081, 1, "59348c457d1693e60160075873f78025e4e7409a8854a927600cd4467b3f3b49")
