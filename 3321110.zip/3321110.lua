-- Lua provided by RyzenAPI
-- Game: Vasilisa And Baba Yaga Soundtrack

-- MAIN APPLICATION
addappid(3321110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321111, 1, "369414674ccdf220d3aadffc807e70ffb95dc49f8cba58bb07e4b92901e2db97")
addappid(3321112, 1, "fd7329c003524e31a67318debf2996cd921c004c7757af43f0bc9c1cb6a5c704")
