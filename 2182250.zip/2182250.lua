-- Lua provided by RyzenAPI
-- Game: Game: GOAL! The Club Manager - Original Soundtrack

-- MAIN APPLICATION
addappid(2182250)
-- Game: addappid(2182250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182251, 1, "57a90367d5466858a5d847e7eae41056ec3d7aae6465dae2736c7829f1704244")
