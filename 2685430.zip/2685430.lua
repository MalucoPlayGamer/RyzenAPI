-- Lua provided by RyzenAPI
-- Game: Game: AppID 2685430

-- MAIN APPLICATION
addappid(2685430)
-- Game: addappid(2685430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685431, 1, "709d8ffb3a2c9cc00f5deeb3c14f8ffaca26872590e53f7efe8c115fc0f82068")
