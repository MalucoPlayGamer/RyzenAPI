-- Lua provided by RyzenAPI
-- Game: Dyson Sphere Program - Digital Art Book

-- MAIN APPLICATION
addappid(1530310)
-- Game: addappid(1530310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530310,0,"d6853b48dc840f9b44fe7a225d1775e48305f3760aa3e8a826ec0d38eafe989f")
addtoken(1530310,"11371357649252062499")
