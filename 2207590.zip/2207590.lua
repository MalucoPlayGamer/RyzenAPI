-- Lua provided by RyzenAPI
-- Game: 2207590

-- MAIN APPLICATION
addappid(2207590)
-- Game: addappid(2207590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207591, 1, "ccd21baee13d48ef73fe9e0eaf6daf367073f7ff496513f7433b0ed8e5352e49")
