-- Lua provided by SkyAPI 
-- Game: Kemono Heroes
addappid(2787700)
addappid(2787701, 1, "a5c0c6ce33ba8b9c8865f8e915cae3fd143e9e99f0d76f80947c5ba8131c4f4f")
