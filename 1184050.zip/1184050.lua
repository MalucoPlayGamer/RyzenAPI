-- Lua provided by RyzenAPI
-- Game: Gears Tactics

-- MAIN APPLICATION
addappid(1184050)
addappid(1190291)
-- Game: addappid(1184050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184051, 1, "611b8c84a24ed0ca287ddd56e4cf8fa507b371b3d8aab420662550f6af6777e2")
