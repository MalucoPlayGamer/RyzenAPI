-- Lua provided by RyzenAPI
-- Game: Gears Tactics

-- MAIN APPLICATION
addappid(1184050)
addappid(1190291)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1184051, 1, "611b8c84a24ed0ca287ddd56e4cf8fa507b371b3d8aab420662550f6af6777e2")

