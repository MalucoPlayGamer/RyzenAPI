-- Lua provided by RyzenAPI
-- Game: Game: CHARMING HEART

-- MAIN APPLICATION
addappid(1985680)
addappid(2629571)
addappid(2629581)
addappid(2629591)
addappid(2629601)
-- Game: addappid(1985680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985681, 1, "eec4381ef2b77611f5cccdebf9bcfc96350e5746a97012537dea91977167a69e")
