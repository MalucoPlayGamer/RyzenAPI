-- Lua provided by RyzenAPI
-- Game: AppID 1916080

-- MAIN APPLICATION
addappid(1916080)
-- Game: addappid(1916080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916081, 1, "3ed09bce9e7680ab58145842caf3d99084e51087278ccccc1a12886fd5c0bf2e")
