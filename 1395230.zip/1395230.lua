-- Lua provided by RyzenAPI
-- Game: Almost My Floor: Prologue

-- MAIN APPLICATION
addappid(1395230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395231, 1, "b9daea462e0f7f65c6cde2a8d93fc380ca166033c030e817df483b0edf83cb42")
addappid(1395232, 1, "aa185aea17c80fa4f283127477e576f7572036df40370d7df73a726f442040bc")

