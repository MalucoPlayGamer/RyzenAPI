-- Lua provided by RyzenAPI
-- Game: 3370700

-- MAIN APPLICATION
addappid(3370700)
-- Game: addappid(3370700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3370701, 1, "ab3fcc68db9acf1f4f7a69b131fd2d6e78dbbead88d943cd1720fd3f9e92f717")
