-- Lua provided by RyzenAPI
-- Game: Layers of Fear (2016)

-- MAIN APPLICATION
addappid(391720)

-- MAIN APP DEPOTS / PACKAGES
addappid(391721, 1, "1162ab36159039f4781377536e3876faa9f479d44d97241be0270ce8da7a7698")
addappid(391722, 1, "6d9db8f3d6215b58516336c2ad0b05b9825abfbbf08e83ae59af125eede9a701")
addappid(391723, 1, "d3fdc865309b0966094284e3502d89bd0e136ddf666944cff9c6ed6defde0cad")
addappid(550210, 0, "fd1f73f5566a7b8eae9978c7891e5ee3857c685c32e1b5992f8a3d5a8c4debc5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(493530)
