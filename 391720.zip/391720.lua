-- Lua provided by RyzenAPI
-- Game: Layers of Fear (2016)

-- MAIN APPLICATION
addappid(391720)
-- Game: addappid(391720)

-- MAIN APP DEPOTS / PACKAGES
addappid(391721, 1, "1162ab36159039f4781377536e3876faa9f479d44d97241be0270ce8da7a7698")
addappid(391722, 1, "6d9db8f3d6215b58516336c2ad0b05b9825abfbbf08e83ae59af125eede9a701")
addappid(391723, 1, "d3fdc865309b0966094284e3502d89bd0e136ddf666944cff9c6ed6defde0cad")
addappid(550210, 0, "fd1f73f5566a7b8eae9978c7891e5ee3857c685c32e1b5992f8a3d5a8c4debc5")
