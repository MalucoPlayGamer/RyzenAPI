-- Lua provided by RyzenAPI
-- Game: Dojo Masters

-- MAIN APPLICATION
addappid(2538000)
addappid(3807730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538001, 1, "07f3a8f0b3bb2b457828e9e08677b3da48e29563b8b5292f84abef96e3b778c0")
