-- Lua provided by RyzenAPI
-- Game: Dojo Masters

-- MAIN APPLICATION
addappid(2538000)
addappid(3807730)
addappid(4785370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2538001, 1, "07f3a8f0b3bb2b457828e9e08677b3da48e29563b8b5292f84abef96e3b778c0")

