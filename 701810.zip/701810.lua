-- Lua provided by RyzenAPI
-- Game: addappid(701810)

-- MAIN APPLICATION
addappid(701810)

-- MAIN APP DEPOTS / PACKAGES
addappid(701811, 1, "13f2501b1cbfe272a448f90364baf43a8596d7da2c1d4f1acd70b74582082bc1")
