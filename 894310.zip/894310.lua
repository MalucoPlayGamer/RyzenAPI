-- Lua provided by RyzenAPI
-- Game: Game: Finding Light

-- MAIN APPLICATION
addappid(894310)
-- Game: addappid(894310)

-- MAIN APP DEPOTS / PACKAGES
addappid(894311, 1, "61d5fb11ff9f4984f786ef6f71e045dcbd7e073b4e471d3370145245d713d939")
