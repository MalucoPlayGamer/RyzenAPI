-- Lua provided by RyzenAPI
-- Game: Trigger Saint

-- MAIN APPLICATION
addappid(354770)

-- MAIN APP DEPOTS / PACKAGES
addappid(354771, 1, "6156ba099756a5131acf800f579a72fe512886a3e5ffac8152ba3b5916aa657f")
