-- Lua provided by RyzenAPI
-- Game: Who's Who?

-- MAIN APPLICATION
addappid(1796200)
-- Game: addappid(1796200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796201, 1, "d6679f3c4710b2610809d09d378cf3d2860f3a8d1a6f3684bd2b23dc5656b31c")
