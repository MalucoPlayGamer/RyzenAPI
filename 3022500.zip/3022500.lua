-- Lua provided by RyzenAPI
-- Game: Sakura Alien 3

-- MAIN APPLICATION
addappid(3022500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022501, 1, "aba8dcd345e6eb188bd36de1e1e1037e2f92589aeb975b48b7a7e065d6249546")

