-- Lua provided by RyzenAPI
-- Game: Krimson

-- MAIN APPLICATION
addappid(2107520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107521, 1, "38a51a48a0b2ebcf11efd05d6f07a19b9426703d0402c5cec9e4a0729c2326ec")

