-- Lua provided by RyzenAPI
-- Game: addappid(448960)

-- MAIN APPLICATION
addappid(448960)

-- MAIN APP DEPOTS / PACKAGES
addappid(448961, 1, "656a814290c151eb74e26a111120aaabcec97c7c476a949fd148facd16b42f58")
