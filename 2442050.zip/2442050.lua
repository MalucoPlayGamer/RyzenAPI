-- Lua provided by RyzenAPI
-- Game: Edmund and Eliza

-- MAIN APPLICATION
addappid(2442050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442051, 1, "cbc537f02eac960a51b5db0cbec00b722e737b26bc102926aec4e63359d69798")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
