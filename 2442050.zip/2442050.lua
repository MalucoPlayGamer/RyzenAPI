-- Lua provided by SkyAPI 
-- Game: Edmund and Eliza
addappid(2442050)
addappid(2442051, 1, "cbc537f02eac960a51b5db0cbec00b722e737b26bc102926aec4e63359d69798")
