-- Lua provided by RyzenAPI
-- Game: Edmund and Eliza

-- MAIN APPLICATION
addappid(2442050)
-- Game: addappid(2442050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442051, 1, "cbc537f02eac960a51b5db0cbec00b722e737b26bc102926aec4e63359d69798")
