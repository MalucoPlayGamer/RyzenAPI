-- Lua provided by RyzenAPI
-- Game: Professional Lumberjack 2015

-- MAIN APPLICATION
addappid(316240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(316241, 1, "19669574546c69280c695e07eb7c4e176e78dc992a2f3669d0d85cae3adf9b10")
addappid(316247, 1, "f2357d196635f89cbad17bf2374a835fcf526f78330039a16e10ca1557c4c568")
