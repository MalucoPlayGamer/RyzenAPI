-- Lua provided by RyzenAPI
-- Game: Game: RePete

-- MAIN APPLICATION
addappid(448010)
-- Game: addappid(448010)

-- MAIN APP DEPOTS / PACKAGES
addappid(448011, 1, "d7f708bfa6957e92649c72e3288817f2ff976c91bad122113a54f8bfcb8156b2")
addappid(448012, 1, "5969c4e30951d9c526aeb2ac0df93f098b5b7ceba59f026943df0a8270ec1e87")
addappid(448013, 1, "e2d6da0f455a2cd6fe4a61f9791a701135b6d310046e739b0e139d9e20ebbcb3")
addappid(448014, 1, "d7cb9d54e6b8fe6ba88203e4ed63528d3d8490d80b9c568d640fe6da48d81c19")
