-- Lua provided by RyzenAPI 
-- Game: L.S.S II
addappid(1056330)
addappid(1056331, 1, "cd9b109627b6fe2ec2b120221d25999a9b1334b93b178d9bfd029fa5517f6868")
addappid(1056332, 1, "f52f4013d15cf5ba93afd7ac49713e80c96fe62ab5098ac7f5b69ff57e24d065")
