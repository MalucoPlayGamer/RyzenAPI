-- Lua provided by RyzenAPI 
-- Game: Steel Armor: Blaze of War
addappid(286280)
addappid(286281, 1, "1f63b8129febd08f98723110a3e61a5bbc905a3877c7f77bb7ce62e23d048c44")
addappid(399860, 0, "b2f0b86f02cb3a17a0f7d42772603bfb3c64005cb06f896449ea405a7c747e25")
