-- Lua provided by RyzenAPI
-- Game: Steel Armor: Blaze of War

-- MAIN APPLICATION
addappid(286280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(286281, 1, "1f63b8129febd08f98723110a3e61a5bbc905a3877c7f77bb7ce62e23d048c44")
addappid(399860, 0, "b2f0b86f02cb3a17a0f7d42772603bfb3c64005cb06f896449ea405a7c747e25")

