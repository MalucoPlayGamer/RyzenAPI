-- Lua provided by SkyAPI 
-- Game: Supraland Demo
addappid(1000560)
addappid(1000561, 1, "0183d05584b8644bf7abaf0a25d0c9510ead1455e2374155c8efba2f2a7309c2")
