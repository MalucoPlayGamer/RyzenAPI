-- Lua provided by RyzenAPI
-- Game: 1632080

-- MAIN APPLICATION
addappid(1632080)
-- Game: addappid(1632080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632081, 1, "510fe07f5c9e444cbac036da45d9216abd0d50468284b7c1d2354a22311583d6")
