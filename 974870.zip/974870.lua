-- Lua provided by RyzenAPI
-- Game: 974870

-- MAIN APPLICATION
addappid(974870)
-- Game: addappid(974870)

-- MAIN APP DEPOTS / PACKAGES
addappid(974871, 1, "428aff8bba3e7aae194bdfc92c9a264fc2b83917d6ea0f460c30530b28ca06ed")
