-- Lua provided by RyzenAPI
-- Game: 1503090

-- MAIN APPLICATION
addappid(1503090)
-- Game: addappid(1503090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503096,0,"73ba5b5452cf8716cca331f3568b14df23b4250bde805c04b08c020043e72e0e")
