-- Lua provided by RyzenAPI
-- Game: Minion Masters

-- MAIN APPLICATION
addappid(489520)
addappid(551880)
addappid(560900)
addappid(883110)
addappid(988160)
addappid(1033840)
addappid(1066920)
addappid(1137440)
addappid(1189690)
addappid(1247120)
addappid(1324190)
addappid(1392620)
addappid(1467210)
addappid(1560570)
addappid(1645360)
addappid(1748780)
addappid(1846520)
addappid(1954710)
addappid(2071000)
addappid(2155210)
addappid(2251260)
addappid(2360050)
addappid(2495770)
addappid(2679280)
addappid(2885550)
addappid(3101570)

-- MAIN APP DEPOTS / PACKAGES
addappid(489521, 1, "45a166379b24baf7777bc77d32ad618dbb49857a55199085a38bd2a0c5beee72")
addappid(489522, 1, "7225f5252b1a5ad86620873e7d4b862fcbafc56bbe826dd52be1b3b34c279f6c")
addappid(489523, 1, "d5321a86e91d11c18618b16ed442a2d53d2baecb3780fc25e2f7aa02da8723a7")

