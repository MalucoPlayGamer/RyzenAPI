-- Lua provided by RyzenAPI
-- Game: 异化之恶〇Abnormal Treatment

-- MAIN APPLICATION
addappid(1122750)
