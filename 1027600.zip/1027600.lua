-- Lua provided by RyzenAPI
-- Game: 1027600

-- MAIN APPLICATION
addappid(1027600)
-- Game: addappid(1027600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027601, 1, "d0e2e91cc450eafb42eda41d8ee929dacf389ca000c789a9cfe642513961eeef")
