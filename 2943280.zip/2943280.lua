-- Lua provided by RyzenAPI
-- Game: Game: Dustland Delivery

-- MAIN APPLICATION
addappid(2943280)
-- Game: addappid(2943280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943281, 1, "21e8caf4a1bbff8f83e2f1d46bdf17045d0466e7c9a319a99094e0bcd945b6d6")
addappid(3404490, 0, "631ba94966307eed6f069d2207d3148395e38f7ae53b2bf8b5e55e4d422062c6")
addappid(3559340, 0, "f02790760e408469ab1876819a79a8c300be8458df2bf791add6694342e7f3b3")
