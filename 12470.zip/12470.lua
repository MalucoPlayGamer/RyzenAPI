-- Lua provided by RyzenAPI
-- Game: addappid(12470)

-- MAIN APPLICATION
addappid(12470)

-- MAIN APP DEPOTS / PACKAGES
addappid(12471, 1, "c4f3662c3e0d9392d6ac806fd7dce26d87571dccd61fa63c19292b8580cd9e2a")
