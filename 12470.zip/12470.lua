-- Lua provided by RyzenAPI 
-- Game: Port Royale 2
addappid(12470)
addappid(12471, 1, "c4f3662c3e0d9392d6ac806fd7dce26d87571dccd61fa63c19292b8580cd9e2a")
