-- Lua provided by RyzenAPI
-- Game: 1871830

-- MAIN APPLICATION
addappid(1871830)
-- Game: addappid(1871830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871831, 1, "b2bcc18f93789a197bfc5bc530bca7a29ae95c9d6616bca2cc820b7772fd6bbf")
