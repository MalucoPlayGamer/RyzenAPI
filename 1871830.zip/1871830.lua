-- Lua provided by RyzenAPI
-- Game: ERRANTE

-- MAIN APPLICATION
addappid(1871830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871831, 1, "b2bcc18f93789a197bfc5bc530bca7a29ae95c9d6616bca2cc820b7772fd6bbf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
