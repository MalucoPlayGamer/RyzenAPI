-- Lua provided by RyzenAPI
-- Game: addappid(1575670)

-- MAIN APPLICATION
addappid(1575670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575671, 1, "95a69135e55e003614a8dcd16c339391736aa681ceed7344e18209efcbc6a0b6")
