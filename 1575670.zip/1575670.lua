-- Lua provided by RyzenAPI
-- Game: SNK VS. CAPCOM: THE MATCH OF THE MILLENNIUM

-- MAIN APPLICATION
addappid(1575670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1575671, 1, "95a69135e55e003614a8dcd16c339391736aa681ceed7344e18209efcbc6a0b6")

