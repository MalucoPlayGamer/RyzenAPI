-- Lua provided by RyzenAPI
-- Game: addappid(1411490)

-- MAIN APPLICATION
addappid(1411490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411491, 1, "8c9bb48bec4848bb61b67dcf70d9ce508aea50c83ac231098579a97860ec88bd")
