-- Lua provided by RyzenAPI
-- Game: Lost In Time

-- MAIN APPLICATION
addappid(1411490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1411491, 1, "8c9bb48bec4848bb61b67dcf70d9ce508aea50c83ac231098579a97860ec88bd")

