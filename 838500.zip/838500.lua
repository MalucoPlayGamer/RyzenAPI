-- Lua provided by RyzenAPI
-- Game: AppID 838500

-- MAIN APPLICATION
addappid(838500)
-- Game: addappid(838500)

-- MAIN APP DEPOTS / PACKAGES
addappid(838501, 1, "9a93239c5119c60ee7cefe81f306561f842100ff61e3c60d1943bb5e184e3c55")
