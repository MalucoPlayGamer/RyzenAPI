-- Lua provided by RyzenAPI
-- Game: Game: Chronicles of Magic: Divided Kingdoms

-- MAIN APPLICATION
addappid(746840)
-- Game: addappid(746840)

-- MAIN APP DEPOTS / PACKAGES
addappid(746841, 1, "a96e5b1a9423c90a8477b44a59775773c1e1de2d7412c134d22cac6521127d66")
