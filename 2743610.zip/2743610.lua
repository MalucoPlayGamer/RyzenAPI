-- Lua provided by RyzenAPI 
-- Game: AppID 2743610
addappid(2743610)
addappid(2743611, 1, "e2cd3cdbeaa784eaaf989a06a99d0630aaed4c8d4453a6f38028c12135265721")
