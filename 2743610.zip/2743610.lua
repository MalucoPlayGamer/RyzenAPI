-- Lua provided by RyzenAPI
-- Game: Winning Post 10 2024 体験版

-- MAIN APPLICATION
addappid(2743610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743611, 1, "e2cd3cdbeaa784eaaf989a06a99d0630aaed4c8d4453a6f38028c12135265721")
