-- Lua provided by RyzenAPI
-- Game: Legends of Amberland

-- MAIN APPLICATION
addappid(873890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(873891,0,"e9edda460f29aceb9b7aea5c0fca47ebdbea680e60f55078757898ac40892135")

