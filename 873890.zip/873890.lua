-- Lua provided by RyzenAPI
-- Game: Legends of Amberland

-- MAIN APPLICATION
addappid(873890)

-- MAIN APP DEPOTS / PACKAGES
addappid(873891,0,"e9edda460f29aceb9b7aea5c0fca47ebdbea680e60f55078757898ac40892135")

