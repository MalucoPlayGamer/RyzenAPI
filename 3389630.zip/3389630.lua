-- Lua provided by RyzenAPI
-- Game: addappid(3389630)

-- MAIN APPLICATION
addappid(3389630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389631, 1, "ab402ced9533047090410bfbcd7abd8b69a79804bffa838c68ebb5bbae5fe417")
