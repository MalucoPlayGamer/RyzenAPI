-- Lua provided by RyzenAPI
-- Game: V-LOVER！Soundtrack

-- MAIN APPLICATION
addappid(3778050)
-- Game: addappid(3778050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3778051, 1, "4ffeba41f65fdce38af7f93d7db87bdf09e0de0d3b6dbfa30145412f3b32cfbe")
