-- Lua provided by RyzenAPI
-- Game: Farm in another world

-- MAIN APP DEPOTS / PACKAGES
addappid(2233950, 1, "b024a309edd5f626b7dd19b3eeaf48c456076ee70fc0ebec26ca993463ecf056") -- Farm in another world
addappid(2233951, 1, "d99aad0433a61798854f6193247d4badd5205541bff7e833a195778397005c2d") -- Depot 2233951

