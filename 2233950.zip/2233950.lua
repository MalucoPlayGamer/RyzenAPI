-- 2233950's Lua and Manifest Created by Hubcap Manifest
-- Farm in another world
-- Created: August 04, 2026 at 22:44:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2233950, 1, "b024a309edd5f626b7dd19b3eeaf48c456076ee70fc0ebec26ca993463ecf056") -- Farm in another world
-- MAIN APP DEPOTS
addappid(2233951, 1, "d99aad0433a61798854f6193247d4badd5205541bff7e833a195778397005c2d") -- Depot 2233951
setManifestid(2233951, "9161659885651409542", 643515904)