-- Lua provided by RyzenAPI
-- Game: addappid(3430220)

-- MAIN APPLICATION
addappid(3430220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430220,0,"280149ac8a063c5ef08cfb592a699a092ec6ddaa977512503e7a6187931fd0ab")
