-- Lua provided by RyzenAPI
-- Game: Liz and Rose's Alchemy Factory

-- MAIN APPLICATION
addappid(3143550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143551,0,"7a96dd1d967de43b52b6e214ac03b37e9b3accb86e4885d22b85b0f0d316643e")

