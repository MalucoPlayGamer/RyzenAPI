-- Lua provided by RyzenAPI
-- Game: GRIDbeat!

-- MAIN APPLICATION
addappid(3243370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243371,0,"374ec742099a09cf48144dedcf2d23f5cd4350f50b8e4e996af9c565f86c4e31")

