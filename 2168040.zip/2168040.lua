-- Lua provided by SkyAPI 
-- Game: AppID 2168040
addappid(2168040)
addappid(2168041, 1, "a2c54a97f934372e4312675bcb1efc38a1015b556a090fe276621adee6ef4615")
