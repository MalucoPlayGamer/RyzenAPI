-- Lua provided by RyzenAPI
-- Game: Ants Took My Eyeball Demo

-- MAIN APPLICATION
addappid(2168040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168041, 1, "a2c54a97f934372e4312675bcb1efc38a1015b556a090fe276621adee6ef4615")
