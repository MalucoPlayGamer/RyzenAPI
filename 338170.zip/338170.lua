-- Lua provided by RyzenAPI
-- Game: Ratz Instagib

-- MAIN APPLICATION
addappid(338170)
addappid(4142440)
addappid(4226810)
addappid(4655880)

-- MAIN APP DEPOTS / PACKAGES
addappid(338171, 1, "a0db2a939c93f1889ed7d74eca3c3b0f0f4175e2177880593435285c8bdbaff8")

