-- Lua provided by RyzenAPI
-- Game: AppID 338170

-- MAIN APPLICATION
addappid(338170)

-- MAIN APP DEPOTS / PACKAGES
addappid(338171, 1, "a0db2a939c93f1889ed7d74eca3c3b0f0f4175e2177880593435285c8bdbaff8")

