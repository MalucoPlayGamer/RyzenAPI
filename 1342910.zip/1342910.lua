-- Lua provided by RyzenAPI
-- Game: Winter's Trumpet

-- MAIN APPLICATION
addappid(1342910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342914,0,"761da9535c6b8f34158dc716bd2e075b748e64e6337dd496c1853b99e98f278a")

