-- Lua provided by RyzenAPI
-- Game: Game: AppID 1756040

-- MAIN APPLICATION
addappid(1756040)
-- Game: addappid(1756040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756041, 1, "2a7a5d907129ac1731ad86d2eabfccc48a80cfd761d0960a504d479f751728cc")
