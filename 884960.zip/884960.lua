-- Lua provided by RyzenAPI
-- Game: addappid(884960)

-- MAIN APPLICATION
addappid(884960)

-- MAIN APP DEPOTS / PACKAGES
addappid(884961, 1, "af7a6a8d671c773fa94bae7a597e0d79d866d13b60a47e015d2188c7c8a786bb")
