-- Lua provided by RyzenAPI
-- Game: AppID 1396380

-- MAIN APPLICATION
addappid(1396380)
-- Game: addappid(1396380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396381, 1, "a4a53cbc2ed0f7f09dc0a4ab33c6b476d4620880f64044766c1b98199f12c0c7")
