-- Lua provided by RyzenAPI
-- Game: Rags to Dishes

-- MAIN APPLICATION
addappid(1442300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442301, 1, "4d9bb2c90d6beb0aa3b4219d60d15be58fed0358a359670525deafe8d459cb8e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
