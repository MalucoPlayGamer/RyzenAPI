-- Lua provided by RyzenAPI
-- Game: Food Mahjong

-- MAIN APPLICATION
addappid(707610)
-- Game: addappid(707610)

-- MAIN APP DEPOTS / PACKAGES
addappid(707611, 1, "145b460654598293ac39a0c588453a6c8f36f7b6035b66bc9e865151fbbfa9d0")
