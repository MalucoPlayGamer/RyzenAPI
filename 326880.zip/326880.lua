-- Lua provided by RyzenAPI
-- Game: 326880

-- MAIN APPLICATION
addappid(326880)
-- Game: addappid(326880)

-- MAIN APP DEPOTS / PACKAGES
addappid(326881, 1, "fc8179872bc6ad23b8fa4d7bd96316b7d9acabca2f3b641af0f49d92a45aa91a")
