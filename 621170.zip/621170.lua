-- Lua provided by RyzenAPI
-- Game: Winter's Empty Mask - Visual novel

-- MAIN APPLICATION
addappid(621170)
addappid(1096350)

-- MAIN APP DEPOTS / PACKAGES
addappid(621171, 1, "7264c4c62c2bcaf3ad30b8062fcb97725c711837f4160e8372966df3fbefe004")

