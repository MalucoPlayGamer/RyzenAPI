-- Lua provided by RyzenAPI 
-- Game: Coal Mining Simulator
addappid(1118110)
addappid(1118111, 1, "13b9e8519a23c745a0308c75f2fbea76aafe67c740ea999a9175118e86fa243f")
