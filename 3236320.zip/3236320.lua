-- Lua provided by SkyAPI 
-- Game: AppID 3236320
addappid(3236320)
addappid(3236321, 1, "79eb7da209798c86e7c0b3aa0bd1c6cf8a39e00d34f7d1b9299632d603abd340")
