-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1317495)
addappid(1317495,0,"6f29a0d64338d0606e3554611cacebc71d7c95d25b2df76c750df094d0a17d86")
-- setManifestid(1317495,"693766959635380214")
addappid(1317550,0,"e63b1008a8f761d6d562fd8f4d982e98a4d9aa6c3ccbaf94279c2c658f5be6fc")
-- setManifestid(1317550,"3399404403239615147")
addappid(1317551,0,"306290b00dd7903a531ae9c6400e5737056329e00ec926bc9a85c70df4eaff2e")
-- setManifestid(1317551,"7293417469057635974")
addappid(1317552)
addappid(1317553)
addappid(1317554,0,"35a5e1a3f066a0ee300ffc31bbc4d59a0a72553911004e08aa09dd778961da48")
-- setManifestid(1317554,"3246404701163793736")
addappid(1317555)
addappid(1317556)