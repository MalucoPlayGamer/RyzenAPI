-- Lua provided by RyzenAPI
-- Game: Game: Zoonomaly

-- MAIN APPLICATION
addappid(2101890)
-- Game: addappid(2101890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101891, 1, "379c19a139745811b4180367a7fe5a614b62a35e66bc5f01b2197ccf4e7fb5ec")
