-- Lua provided by RyzenAPI
-- Game: Game: AppID 3415760

-- MAIN APPLICATION
addappid(3415760)
-- Game: addappid(3415760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415761, 1, "5289120faeec6c3c1995ca97a33e6faf436384ec03790498075988e2aab30274")
