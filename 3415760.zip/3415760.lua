-- Lua provided by RyzenAPI
-- Game: Reincarnation in another world going to rape All NPCs VR

-- MAIN APPLICATION
addappid(3415760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415761, 1, "5289120faeec6c3c1995ca97a33e6faf436384ec03790498075988e2aab30274")

