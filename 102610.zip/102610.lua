-- Lua provided by RyzenAPI
-- Game: Orcs Must Die! Demo

-- MAIN APPLICATION
addappid(102610)
addappid(102631)
addappid(102632)
addappid(102633)
addappid(102634)
addappid(102635)
addappid(102636)
addappid(102637)
addappid(102638)
addappid(102639)

-- MAIN APP DEPOTS / PACKAGES
addappid(102611, 1, "460b1292c72eacbbb405cdc2ddc7cb43263261cc68d98b2b5d9045d71aa114f8")

