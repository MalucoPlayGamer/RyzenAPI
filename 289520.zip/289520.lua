-- Lua provided by RyzenAPI
-- Game: addappid(289520)

-- MAIN APPLICATION
addappid(289520)
addappid(306340)

-- MAIN APP DEPOTS / PACKAGES
addappid(289521, 1, "f62cdb49de0592bce93ecd1070fb7d6adc612e9ab33f7f4b4a466ec72351c4c3")
addappid(289526, 1, "f19ac21f961f7861c3910bc183233fde8c3536dd7297922208b1ee5f0c3b9eea")
