-- Lua provided by RyzenAPI
-- Game: AppID 289520

-- MAIN APPLICATION
addappid(289520)
addappid(306340)

-- MAIN APP DEPOTS / PACKAGES
addappid(289521, 1, "f62cdb49de0592bce93ecd1070fb7d6adc612e9ab33f7f4b4a466ec72351c4c3")
addappid(289526, 1, "f19ac21f961f7861c3910bc183233fde8c3536dd7297922208b1ee5f0c3b9eea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
