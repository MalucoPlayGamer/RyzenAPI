-- Lua provided by SkyAPI 
-- Game: Russian Roulette: Online
addappid(2747720)
addappid(2747721, 1, "ccb7cf0f902eb22229f65c7ee32af758ecb6a921e6cc73a55714111dc908cb22")
