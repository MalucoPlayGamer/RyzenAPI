-- Lua provided by RyzenAPI
-- Game: 2747720

-- MAIN APPLICATION
addappid(2747720)
-- Game: addappid(2747720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747721, 1, "ccb7cf0f902eb22229f65c7ee32af758ecb6a921e6cc73a55714111dc908cb22")
