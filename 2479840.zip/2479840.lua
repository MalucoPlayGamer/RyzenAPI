-- Lua provided by RyzenAPI
-- Game: Pawn Planet

-- MAIN APPLICATION
addappid(2479840)
-- Game: addappid(2479840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479841, 1, "94260d4c80c6837b2460639aa34e30da4caa193bf3e4ac9f93406d760bc22bed")
