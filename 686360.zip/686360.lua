-- Lua provided by RyzenAPI
-- Game: Dungeons & Treasure VR

-- MAIN APPLICATION
addappid(686360)

-- MAIN APP DEPOTS / PACKAGES
addappid(686361, 1, "e53ac8ff3e799134dd1ebcc7d411fdb1440123b0c07ec60483cd265cf7ff4bbb")

