-- Lua provided by RyzenAPI
-- Game: Re into Another World

-- MAIN APPLICATION
addappid(2726720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726721, 1, "6b3d5bf3083446b8112f066914808a6e835b3fa7120e0314f04a52529c522efd")
