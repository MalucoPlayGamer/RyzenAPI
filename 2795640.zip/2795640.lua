-- Lua provided by RyzenAPI
-- Game: Game: BOXHEAD:Immortal

-- MAIN APPLICATION
addappid(2795640)
-- Game: addappid(2795640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795641, 1, "0c65954056f381c2291248a78405682db66ec270698b7a9d5c562e977d822d23")
