-- Lua provided by RyzenAPI 
-- Game: BOXHEAD:Immortal
addappid(2795640)
addappid(2795641, 1, "0c65954056f381c2291248a78405682db66ec270698b7a9d5c562e977d822d23")
