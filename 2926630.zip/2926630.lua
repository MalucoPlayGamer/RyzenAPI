-- Lua provided by RyzenAPI
-- Game: Elven Rivers: Sky Realm Collector's Edition

-- MAIN APPLICATION
addappid(2926630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926631, 1, "e435358508e0c629f1ab9f89bb82f994af05fb514976aa164b7216e7542ed989")

