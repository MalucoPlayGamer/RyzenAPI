-- Lua provided by RyzenAPI
-- Game: addappid(1374990)

-- MAIN APPLICATION
addappid(1374990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374991, 1, "e063499289c711bd928f62b294c3bf225bec365e3e5c45e6ac29681d3ebbd401")
