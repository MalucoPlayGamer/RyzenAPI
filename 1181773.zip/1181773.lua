-- Lua provided by RyzenAPI
-- Game: 1181773

-- MAIN APPLICATION
addappid(1181773)
-- Game: addappid(1181773)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181773,0,"d9e4415393d0299c24164f2c1ca7c7f98e8ce1a4c8b0ee592dd0caa4b0ffc82f")
