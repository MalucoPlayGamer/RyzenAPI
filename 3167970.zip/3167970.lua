-- Lua provided by RyzenAPI
-- Game: Starless Abyss

-- MAIN APPLICATION
addappid(3167970)
-- Game: addappid(3167970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167971, 1, "f8df432c3fa05eb9edf6d4347e12168ebda47b1630a44b66987a600ea0630d6a")
