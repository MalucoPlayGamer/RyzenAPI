-- Lua provided by RyzenAPI
-- Game: Game: Linkito

-- MAIN APPLICATION
addappid(2312770)
-- Game: addappid(2312770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312771, 1, "392afe142502e678e7eaf6695dbf98020885b67d216bf5cac8250726c64b8fc2")
