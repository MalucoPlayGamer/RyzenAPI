-- Lua provided by RyzenAPI
-- Game: addappid(2246640)

-- MAIN APPLICATION
addappid(2246640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246641, 1, "4a3d8a93e1e1ff3658bb00d26b607fe57f7e00a5b52c797346f9eda0b3a3cb3b")
addappid(2246642, 1, "ead1cd247f66b20925edc3aeca9e503853549acfcfb8e332fde3bcadbe27df1b")
addappid(2246643, 1, "0004f93550c0b2b6ad27f62524f3fc6d5a9938c756c92ccf16a885ab3e9d5704")
