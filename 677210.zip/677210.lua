-- Lua provided by RyzenAPI
-- Game: addappid(677210)

-- MAIN APPLICATION
addappid(677210)

-- MAIN APP DEPOTS / PACKAGES
addappid(677211, 1, "6957db353c2129f397c8ab65d88f143d03374d40433b477d4d5e1c8fbf02073a")
