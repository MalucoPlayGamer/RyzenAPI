-- Lua provided by RyzenAPI
-- Game: 2309400

-- MAIN APPLICATION
addappid(2309400)
-- Game: addappid(2309400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309401, 1, "8f9aca927d6e5f8c9580f88cb29060f69d4c013f4b56ccba58a14c8bc3aaa457")
