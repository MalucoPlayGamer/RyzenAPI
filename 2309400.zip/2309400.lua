-- Lua provided by RyzenAPI
-- Game: The Devourer: Hunted Souls

-- MAIN APPLICATION
addappid(2309400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309401, 1, "8f9aca927d6e5f8c9580f88cb29060f69d4c013f4b56ccba58a14c8bc3aaa457")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
