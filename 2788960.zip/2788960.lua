-- Lua provided by RyzenAPI
-- Game: Hidden Cats in Jigsaw Puzzle

-- MAIN APPLICATION
addappid(2788960)

