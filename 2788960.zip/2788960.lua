-- Lua provided by RyzenAPI
-- Game: Hidden Cats in Jigsaw Puzzle

-- MAIN APPLICATION
addappid(2788960)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2932700)
addappid(2933540)
addappid(2933550)
addappid(2933560)
addappid(3008710)
addappid(3008720)
addappid(4256990)
