-- Lua provided by RyzenAPI 
-- Game: READY AIM FIRE
addappid(1330290)
addappid(1330291, 1, "44173e587667bad322cd5e9f798791f6989914d11821806e33ee647210ec4534")
