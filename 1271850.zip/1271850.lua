-- Lua provided by RyzenAPI
-- Game: Grand Casino Tycoon

-- MAIN APPLICATION
addappid(1271850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271851, 1, "072e1990becac15d3a765468428b715cccb69ebdcc0e43121642efabd5937881")
