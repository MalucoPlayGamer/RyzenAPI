-- Lua provided by RyzenAPI
-- Game: 10 Second Ninja X

-- MAIN APPLICATION
addappid(435790)

-- MAIN APP DEPOTS / PACKAGES
addappid(435791, 1, "894959ae02ba688c6e0c6b2602c11eb873e60df967f546c948a521a2d4da0199")

