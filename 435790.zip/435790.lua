-- Lua provided by RyzenAPI 
-- Game: AppID 435790
addappid(435790)
addappid(435791, 1, "894959ae02ba688c6e0c6b2602c11eb873e60df967f546c948a521a2d4da0199")
