-- Lua provided by RyzenAPI
-- Game: addappid(215020)

-- MAIN APPLICATION
addappid(215020)

-- MAIN APP DEPOTS / PACKAGES
addappid(215021, 1, "f28d6cfc0b6b22d8c9781b8b322120cd4c35b69270d47045ea5a7d1ac0e7ecb2")
addappid(215030, 1, "8951c0773e78bd4ea5e5beea4ac25818cc0c7851dc949cc4af1788c25a66de29")
