-- Lua provided by RyzenAPI
-- Game: Sam & Max: The Devil's Playhouse

-- MAIN APPLICATION
addappid(2648050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648052,0,"19d40578faab545e248a07945688c4b8652911fa745ced31364303a471c93ff7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3162640)
