-- Lua provided by RyzenAPI
-- Game: Sam & Max: The Devil's Playhouse

-- MAIN APPLICATION
addappid(2648050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648052,0,"19d40578faab545e248a07945688c4b8652911fa745ced31364303a471c93ff7")

