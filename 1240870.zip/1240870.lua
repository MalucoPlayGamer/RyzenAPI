-- Lua provided by RyzenAPI
-- Game: 1240870

-- MAIN APPLICATION
addappid(1240870)
-- Game: addappid(1240870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240871, 1, "58bcaf82281401051928789aa1250883ebba7f1cf5c16d0c67fd73b8f191a206")
