-- Lua provided by RyzenAPI
-- Game: addappid(1328260)

-- MAIN APPLICATION
addappid(1328260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328261, 1, "2047d508aa17601cb9358c5f8ad22385b2c023fb887d2afec024aa93142057f3")
