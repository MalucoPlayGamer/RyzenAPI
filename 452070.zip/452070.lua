-- Lua provided by RyzenAPI
-- Game: AppID 452070

-- MAIN APPLICATION
addappid(452070)

-- MAIN APP DEPOTS / PACKAGES
addappid(452071, 1, "366f4fb630bc2e9fb533d8b066f9148238ad42dacf554a0f2cd96eb27b016e2b")
