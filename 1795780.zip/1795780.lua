-- Lua provided by RyzenAPI 
-- Game: Trance
addappid(1795780)
addappid(1795781, 1, "6a71df8b300767f6897c4518e765a68c9336d88732cfa8224ef3a301602f1590")
