-- Lua provided by RyzenAPI
-- Game: Trance

-- MAIN APPLICATION
addappid(1795780)
-- Game: addappid(1795780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795781, 1, "6a71df8b300767f6897c4518e765a68c9336d88732cfa8224ef3a301602f1590")
