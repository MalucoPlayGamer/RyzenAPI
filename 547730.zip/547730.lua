-- Lua provided by RyzenAPI
-- Game: Izanami's Dream Battle

-- MAIN APPLICATION
addappid(547730)

-- MAIN APP DEPOTS / PACKAGES
addappid(547731,0,"81d3d0f691e33b60d6b45f921500f358e3bcf58e975419384a5fb3ba50d49b8f")
addappid(547732,0,"001972d2e8ccba9fa96ca9f0e7386cc807d07f68a52e969f95b3fdf0d4646c3e")
addappid(549640,0,"8ecdf9c8464dcea07b76fd9222fc7d2238287512024be80ac8666f624608443a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
