-- Lua provided by RyzenAPI
-- Game: 3570

-- MAIN APPLICATION
addappid(3570)
-- Game: addappid(3570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3571, 1, "a5767c7daca496aadcbad5a155f462ad604a1ef0b8bf622a68c656fc02aa7f35")
