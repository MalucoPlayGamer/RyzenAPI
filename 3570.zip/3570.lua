-- Lua provided by RyzenAPI
-- Game: Mystery P.I.™ - The New York Fortune

-- MAIN APPLICATION
addappid(3570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3571, 1, "a5767c7daca496aadcbad5a155f462ad604a1ef0b8bf622a68c656fc02aa7f35")
