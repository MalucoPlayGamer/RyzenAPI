-- Lua provided by SkyAPI 
-- Game: Mystery P.I.™ - The New York Fortune
addappid(3570)
addappid(3571, 1, "a5767c7daca496aadcbad5a155f462ad604a1ef0b8bf622a68c656fc02aa7f35")
