-- Lua provided by RyzenAPI
-- Game: 冒险与魔法

-- MAIN APPLICATION
addappid(2173550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173551, 1, "e99e64aeae3ab55c5302a42e4ad9b27560bdea153b882c69b2874383d2a81890")
