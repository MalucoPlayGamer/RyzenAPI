-- Lua provided by RyzenAPI
-- Game: 1731240

-- MAIN APPLICATION
addappid(1731240)
addappid(1782220)
-- Game: addappid(1731240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731241, 1, "c0c25efe5dec25d50c5a59a0f0758f9c5e411ec0c37883491eb6025259900c31")
