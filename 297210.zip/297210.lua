-- Lua provided by RyzenAPI
-- Game: Famaze

-- MAIN APPLICATION
addappid(297210)

-- MAIN APP DEPOTS / PACKAGES
addappid(297211, 1, "0d6ebb3f7df96eb9b2cabae4864cc771c5e8d7294bbf30b6d01575ca126bfb30")

