-- Lua provided by RyzenAPI
-- Game: Colorless Life

-- MAIN APPLICATION
addappid(670430)

-- MAIN APP DEPOTS / PACKAGES
addappid(670431, 1, "ef40d621689805e42d73e78e16af1c24e04863df02af094f4812bd5dde980302")

