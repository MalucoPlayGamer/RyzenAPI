-- Lua provided by RyzenAPI
-- Game: Boneraiser Minions

-- MAIN APPLICATION
addappid(1944570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944571, 1, "8e83ec363bd416c4467b4d7565a27c94c044a55cd601b8f3b584078f7333a863")

