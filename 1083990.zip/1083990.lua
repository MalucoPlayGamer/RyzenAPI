-- Lua provided by SkyAPI 
-- Game: AppID 1083990
addappid(1083990)
addappid(1083991, 1, "ab6453b8a0806643425ba08de30f5315f9ccf937736e272262f1a4739fc4696d")
