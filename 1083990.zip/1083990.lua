-- Lua provided by RyzenAPI
-- Game: Yume Puzzle

-- MAIN APPLICATION
addappid(1083990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083991, 1, "ab6453b8a0806643425ba08de30f5315f9ccf937736e272262f1a4739fc4696d")

