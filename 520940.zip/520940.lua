-- Lua provided by RyzenAPI
-- Game: Game: MX vs ATV All Out

-- MAIN APPLICATION
addappid(520940)
-- Game: addappid(520940)

-- MAIN APP DEPOTS / PACKAGES
addappid(520941, 1, "774322cb104ada5a8876992300a39a67544ca4246b11f68dc12f09034d34f892")
