-- Lua provided by RyzenAPI
-- Game: MX vs ATV All Out

-- MAIN APPLICATION
addappid(520940)

-- MAIN APP DEPOTS / PACKAGES
addappid(520941, 1, "774322cb104ada5a8876992300a39a67544ca4246b11f68dc12f09034d34f892")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(829730)
addappid(829731)
addappid(829732)
addappid(829733)
addappid(829734)
addappid(829735)
addappid(829736)
addappid(829737)
addappid(842210)
addappid(842211)
addappid(842212)
addappid(842213)
addappid(842214)
addappid(842215)
addappid(856140)
addappid(856141)
addappid(856142)
addappid(856143)
addappid(856144)
addappid(856145)
addappid(856146)
addappid(856147)
addappid(856148)
addappid(856149)
addappid(856150)
addappid(876730)
addappid(876731)
addappid(876732)
addappid(876733)
addappid(876734)
addappid(876735)
addappid(881330)
addappid(907280)
addappid(939730)
addappid(984340)
addappid(1102660)
addappid(1260070)
