-- Lua provided by RyzenAPI
-- Game: Game: Dungeons & Degenerate Gamblers

-- MAIN APPLICATION
addappid(2400510)
-- Game: addappid(2400510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400511, 1, "f08be77434663a38ec425845293b8bda95d36ff7a388d6750b7a7169681e2500")
addappid(2400512, 1, "492f6a3d8ac2649a1c06a2e0c3f57d43056f49ce83f432ab0a56349256f1b86d")
addappid(2400513, 1, "fad855e6d88be1c801695aef8326b8b1e27914f761f41a4a89d110df9a7524e3")
