-- Lua provided by RyzenAPI
-- Game: Soul of Savarog

-- MAIN APPLICATION
addappid(2988090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988091, 1, "64b34156e6fb0685e1ce773a4c0137f446718ccd66660fb8db35a6e9fc134be6")

