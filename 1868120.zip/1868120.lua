-- Lua provided by RyzenAPI
-- Game: 1868120

-- MAIN APPLICATION
addappid(1868120)
-- Game: addappid(1868120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868121, 1, "1882d5323e20670de27e6f964020c0b1d1206225df4faaf649ddb44c0e1d6d65")
