-- Lua provided by RyzenAPI
-- Game: Game: AppID 3045280

-- MAIN APPLICATION
addappid(3045280)
-- Game: addappid(3045280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3045281, 1, "39030ee150dc295803ddff13653dc330ca513bd1e8b8666700c6a76eba441fcd")
