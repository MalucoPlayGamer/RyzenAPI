-- Lua provided by RyzenAPI
-- Game: 苍空的彼端

-- MAIN APPLICATION
addappid(3122530)
addappid(3391590)

