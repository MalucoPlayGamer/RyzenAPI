-- Lua provided by RyzenAPI
-- Game: 3061910

-- MAIN APPLICATION
addappid(3061910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3061912,0,"d6e1856ad4ae87fd7a2382af8b08e9d102ffa90f641f4f5ca2bf1f4c97aac553")

