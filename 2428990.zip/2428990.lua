-- Lua provided by RyzenAPI
-- Game: Brothers in Hell

-- MAIN APPLICATION
addappid(2428990)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(2428991, 1, "d52760968880f22a074018254f13a7ed7459f695e3dd623ef87368ff2dbb3f20")

