-- Lua provided by RyzenAPI
-- Game: 1743860

-- MAIN APPLICATION
addappid(1743860)
-- Game: addappid(1743860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743861, 1, "29f330cdba1b817386bdf00566e7fcc4e1dcb4cee55f8cf812b2ac57a9c0985b")
