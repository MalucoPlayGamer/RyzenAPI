-- Lua provided by RyzenAPI
-- Game: Game: Draw (OST)

-- MAIN APPLICATION
addappid(2645710)
-- Game: addappid(2645710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645711, 1, "cb2179997aa20fddb39a14984344cba98fc849c41085c5df238284ad52c20703")
