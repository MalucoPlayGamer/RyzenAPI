-- Lua provided by RyzenAPI 
-- Game: Idle Run Aya
addappid(3021060)
addappid(3021061, 1, "c9241c9ff831f1abe3224cbaed272ac5e789683a2857b67b1d5d42ac30293786")
