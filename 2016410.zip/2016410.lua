-- Lua provided by RyzenAPI
-- Game: Arali

-- MAIN APPLICATION
addappid(2016410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2016411, 1, "1dc12cebde0a633fd1649fe1244242ec690e8906adb72a35fdb2798d1382531c")

