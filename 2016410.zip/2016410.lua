-- Lua provided by SkyAPI 
-- Game: Arali
addappid(2016410)
addappid(2016411, 1, "1dc12cebde0a633fd1649fe1244242ec690e8906adb72a35fdb2798d1382531c")
