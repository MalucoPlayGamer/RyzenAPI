-- Lua provided by RyzenAPI
-- Game: 2016410

-- MAIN APPLICATION
addappid(2016410)
-- Game: addappid(2016410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016411, 1, "1dc12cebde0a633fd1649fe1244242ec690e8906adb72a35fdb2798d1382531c")
