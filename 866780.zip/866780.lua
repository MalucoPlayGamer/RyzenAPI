-- Lua provided by RyzenAPI
-- Game: addappid(866780)

-- MAIN APPLICATION
addappid(866780)

-- MAIN APP DEPOTS / PACKAGES
addappid(866781, 1, "902bd04bf1a631fd5b71afb08ff7fb1705d9617998327a0e8e191ce3116d102a")
