-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1930530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930530,0,"496b4a8d2f0ae9e0d0d271ea7258a22d30f42801e06ba5e93db272758567321d")

