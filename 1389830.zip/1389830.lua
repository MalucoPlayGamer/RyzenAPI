-- Lua provided by RyzenAPI
-- Game: addappid(1389830)

-- MAIN APPLICATION
addappid(1389830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389831, 1, "feac1a3bd1ce4ee243ec823f9ded24607fcdb9f01e238a7e1d06883715722505")
