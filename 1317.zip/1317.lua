-- Lua provided by RyzenAPI
-- Game: addappid(1317)

-- MAIN APPLICATION
addappid(1317)
addappid(1318)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
addappid(1304,0,"200fc0fe754cd7a9cda0e34c206d5fc758419d5a278b38041637291f137951a6")
