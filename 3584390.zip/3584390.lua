-- Lua provided by RyzenAPI
-- Game: your lover

-- MAIN APPLICATION
addappid(3584390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3584392,0,"5dedbfc2d9992b40befebea54cea54fcfefdffb757908085e2653979b20096db")

