-- Lua provided by RyzenAPI
-- Game: 三国英雄演义(Three Kingdoms Heroes Epic)

-- MAIN APPLICATION
addappid(2766760)
-- Game: addappid(2766760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766761, 1, "29f144958a433c280377e241afed2e5b0ac3ccb6f4978886df9f948eeb792bda")
