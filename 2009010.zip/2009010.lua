-- Lua provided by RyzenAPI
-- Game: My Furry Protogen 🐾

-- MAIN APPLICATION
addappid(2009010)
addappid(2022550)
-- Game: addappid(2009010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009011, 1, "3a4a955463b394b4ebb2ee9aee749d7e62584ccf93555f40cbd063e9a8f60c0d")
