-- Lua provided by RyzenAPI
-- Game: MILF's Plaza - Hot Animations Pack

-- MAIN APPLICATION
addappid(2814120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814120,0,"206914d88d77e711305d1e55c31fa84597e9f5976ed7403df58bafb73fa46311")

