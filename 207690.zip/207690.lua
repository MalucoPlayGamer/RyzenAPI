-- Lua provided by RyzenAPI
-- Game: Game: Botanicula

-- MAIN APPLICATION
addappid(207690)
-- Game: addappid(207690)

-- MAIN APP DEPOTS / PACKAGES
addappid(207691, 1, "44f283926d3665192b3467735dfc6e572ee77ad366f795120dede4dae85f6fee")
addappid(207692, 1, "718a536d470370549bd2b9fb9789521094be57b6c25576066be33c8bc7b5721b")
