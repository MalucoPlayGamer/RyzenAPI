-- Lua provided by RyzenAPI
-- Game: addappid(2255290)

-- MAIN APPLICATION
addappid(2255290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255291, 1, "cbf6e4a991642ca20122dfe37ceaf5df4f046e2a93c8a0a234532224c1592004")
