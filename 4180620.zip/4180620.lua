-- Lua provided by RyzenAPI
-- Game: Submerge

-- MAIN APPLICATION
addappid(4180620)

-- MAIN APP DEPOTS / PACKAGES
addappid(4180621, 1, "fbf6b19773f6b0583ef04b179055644dded9e76ee19bcef67a27fd558fa08865")

