-- Lua provided by RyzenAPI
-- Game: Azure Striker GUNVOLT 3

-- MAIN APPLICATION
addappid(1931690)
addappid(2208400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1931691, 1, "4a7902d9e19a7c744698fb4221c09fd1d94eb3fa7e824156e901ea004f34f31b")
addappid(2125550, 0, "d1fce450adeade59890ce08994323149eb75bac31c6312be3ff2186405e5ed45")
addappid(2144230, 0, "b64da330ef2c3ee3af88ee280096f2bde551db09e151b41b8c62323827ac7d5f")
addappid(2171460, 0, "20c3c1507f754a6810a1dd867b2b8b21541ed71f4a23e0019f5525aff3bd0f4c")
addappid(2189980, 0, "fdf43da886dda184e1df3b501e6afcc899d427243c4b8ff28780204e30fb9044")
addappid(2189990, 0, "07f332e0d6d0beefa85255bb36ee755b77e29b257222ca84e8143344427f1447")

