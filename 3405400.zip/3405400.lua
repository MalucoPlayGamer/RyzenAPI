-- Lua provided by RyzenAPI
-- Game: Cursed Feed

-- MAIN APPLICATION
addappid(3405400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3405401, 1, "6d1a9f5e2206b15156373eab150728b7fca3a48210638568b8a81da16265b532")

