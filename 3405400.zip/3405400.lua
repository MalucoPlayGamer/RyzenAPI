-- Lua provided by RyzenAPI
-- Game: Cursed Feed

-- MAIN APPLICATION
addappid(3405400)
-- Game: addappid(3405400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405401, 1, "6d1a9f5e2206b15156373eab150728b7fca3a48210638568b8a81da16265b532")
