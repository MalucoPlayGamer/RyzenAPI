-- Lua provided by RyzenAPI
-- Game: Game: AppID 3241280

-- MAIN APPLICATION
addappid(3241280)
-- Game: addappid(3241280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241281, 1, "b44a58a56caa96029faa7f587590fa10f2edc06749d19e05dab514333f6ed949")
