-- Lua provided by SkyAPI 
-- Game: Super Geisha Neon
addappid(2075390)
addappid(2075391, 1, "c361ca2a678171a73d6b0b9671bef4985a6ab0ab257aeb28408170a49fc3c8fa")
