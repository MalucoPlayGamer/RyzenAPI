-- Lua provided by RyzenAPI
-- Game: 2075390

-- MAIN APPLICATION
addappid(2075390)
-- Game: addappid(2075390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075391, 1, "c361ca2a678171a73d6b0b9671bef4985a6ab0ab257aeb28408170a49fc3c8fa")
