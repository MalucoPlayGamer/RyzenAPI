-- Lua provided by RyzenAPI
-- Game: addappid(342640)

-- MAIN APPLICATION
addappid(342640)
addappid(596110)

-- MAIN APP DEPOTS / PACKAGES
addappid(342641, 1, "63988ec4fd7cca0e3f903799219d0cde391a9b54f5f29d431a2c88a320fde776")
