-- Lua provided by RyzenAPI
-- Game: Deathsmiles

-- MAIN APPLICATION
addappid(314180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(314181, 1, "8ec591841d58f53439070ce9044b26ea0d4aaa6e524e5d0ff807f61ce9d2edc4")

