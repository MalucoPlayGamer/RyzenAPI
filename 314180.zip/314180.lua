-- Lua provided by RyzenAPI
-- Game: AppID 314180

-- MAIN APPLICATION
addappid(314180)
-- Game: addappid(314180)

-- MAIN APP DEPOTS / PACKAGES
addappid(314181, 1, "8ec591841d58f53439070ce9044b26ea0d4aaa6e524e5d0ff807f61ce9d2edc4")
