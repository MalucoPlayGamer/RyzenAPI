-- Lua provided by RyzenAPI 
-- Game: Warrecs 2
addappid(1360500)
addappid(1360501, 1, "160c69c2f5953575534f781573ac4806c6af51287a27b91ca6dc66c646c23264")
