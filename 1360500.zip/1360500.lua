-- Lua provided by RyzenAPI
-- Game: Warrecs 2

-- MAIN APPLICATION
addappid(1360500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1360501, 1, "160c69c2f5953575534f781573ac4806c6af51287a27b91ca6dc66c646c23264")

