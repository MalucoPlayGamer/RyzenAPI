-- Lua provided by RyzenAPI
-- Game: Fairy of the treasures - Wallpapers

-- MAIN APPLICATION
addappid(973490)

-- MAIN APP DEPOTS / PACKAGES
addappid(973490,0,"251014b3b8c20d5692b89b6833708de16c07043c7388fde7427565e1a4c4d95d")
