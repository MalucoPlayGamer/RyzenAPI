-- Lua provided by RyzenAPI
-- Game: Let Them Breathe: Hello Mother

-- MAIN APPLICATION
addappid(2787890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2787891, 1, "ce69ad10e5986fb3e010b1da142e11a2b1fe234ece004e01c2b2bf99760e4934")

