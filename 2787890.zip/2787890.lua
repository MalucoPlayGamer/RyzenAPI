-- Lua provided by SkyAPI 
-- Game: Let Them Breathe: Hello Mother
addappid(2787890)
addappid(2787891, 1, "ce69ad10e5986fb3e010b1da142e11a2b1fe234ece004e01c2b2bf99760e4934")
