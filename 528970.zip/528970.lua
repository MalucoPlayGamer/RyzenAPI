-- Lua provided by RyzenAPI
-- Game: AppID 528970

-- MAIN APPLICATION
addappid(528970)

-- MAIN APP DEPOTS / PACKAGES
addappid(528971, 1, "3a2bd79c2e78901ddb04ece17cb4f5100f708d740b2d14cd0660f9998fd50ff1")

