-- Lua provided by RyzenAPI
-- Game: Neko Doll

-- MAIN APPLICATION
addappid(1855500)
-- Game: addappid(1855500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855501, 1, "035a4243baa5b8547b19c3cdfa71d151abd06aebd89d79e37d0f617474891ffa")
addappid(1879350, 0, "206a0f58ecda78e43209856711392bee3187589acd31e7f79d42b6d07b475266")
