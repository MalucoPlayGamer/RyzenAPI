-- Lua provided by RyzenAPI
-- Game: Evergreen - Mountain Life Simulator

-- MAIN APPLICATION
addappid(1997250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997251, 1, "4c2fc3bc7d664372944f9d6f6c363b1198590a82bb3a825e11e2c8f2aef06462")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
