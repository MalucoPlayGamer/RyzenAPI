-- Lua provided by RyzenAPI
-- Game: Truck Crash

-- MAIN APPLICATION
addappid(1352070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352071, 1, "d6aff2dde5570a678259d56ce5c598af017ea111f14a07c2ac1a85a0750fac2c")
