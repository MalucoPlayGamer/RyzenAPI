-- Lua provided by RyzenAPI
-- Game: AppID 885620

-- MAIN APPLICATION
addappid(885620)
addappid(900890)
addappid(900891)

-- MAIN APP DEPOTS / PACKAGES
addappid(885621, 1, "a89f3b47cb5868a241253ef55ab09d13bccf237685acda1975114b4d7dcf2eec")
