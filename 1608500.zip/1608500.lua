-- Lua provided by RyzenAPI
-- Game: addappid(1608500)

-- MAIN APPLICATION
addappid(1608500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608502,0,"01794d0e6110e41790c83d8ffc3bfe8703d07e5ad226fb03d9c13b3df8b9d1c2")
