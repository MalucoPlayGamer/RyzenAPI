-- Lua provided by RyzenAPI
-- Game: A game that saves the muscles caught in the ceiling of the gymnasium

-- MAIN APPLICATION
addappid(2026370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026371, 1, "da4cf935d25ad886e2adadc22b02976e74c3ddda8f30f8006a1e5217ba8c63d3")

