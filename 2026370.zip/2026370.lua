-- Lua provided by RyzenAPI
-- Game: A game that saves the muscles caught in the ceiling of the gymnasium

-- MAIN APPLICATION
addappid(2026370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2026371, 1, "da4cf935d25ad886e2adadc22b02976e74c3ddda8f30f8006a1e5217ba8c63d3")

