-- Lua provided by RyzenAPI
-- Game: Astro Battlers TD

-- MAIN APPLICATION
addappid(1728980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728981, 1, "a926c641cf257ff4b53a7c959628a61ef8471d064a0ea8c190e58a67d2ea0d6b")
