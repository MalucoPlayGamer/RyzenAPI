-- Lua provided by RyzenAPI
-- Game: addappid(2940210)

-- MAIN APPLICATION
addappid(2940210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940211, 1, "9372b7766cdbcedfd737c38be07fb5e73c0cd964455198c2bdee9ab9ebc5f3df")
