-- Lua provided by RyzenAPI
-- Game: The House in Fata Morgana: A Requiem for Innocence

-- MAIN APPLICATION
addappid(804700)

-- MAIN APP DEPOTS / PACKAGES
addappid(804701, 1, "070be9f771207868ee375a92155f6cf916fb019cd3dce5073f79eb3a87369148")
