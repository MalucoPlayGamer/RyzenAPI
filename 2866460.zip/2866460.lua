-- Lua provided by RyzenAPI
-- Game: Dungeon Exiles Demo

-- MAIN APPLICATION
addappid(2866460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866461, 1, "5b9f9d280a6578728e7f925b55a91235c8674b848e5da34961628b7ae34ae781")
addappid(2866462, 1, "4915d7e62f54790add9417dea82596c6ccce0480fcfd8f904b78e0f91cbc8d06")
