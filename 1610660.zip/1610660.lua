-- Lua provided by RyzenAPI
-- Game: 1610660

-- MAIN APPLICATION
addappid(1610660)
-- Game: addappid(1610660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610661, 1, "5f4c755d6f963ba4eba38568b347494a8abe56eeabb40b82599514008f41fa99")
