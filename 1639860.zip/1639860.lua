-- Lua provided by RyzenAPI
-- Game: Game: AppID 1639860

-- MAIN APPLICATION
addappid(1639860)
-- Game: addappid(1639860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639861, 1, "d7e164792228df959b6cf8767ea105f554eb85135b075dc70e4af8669633c42b")
