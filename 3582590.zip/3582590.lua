-- Lua provided by RyzenAPI
-- Game: Deedlee Doo! Carkour!

-- MAIN APPLICATION
addappid(3582590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582591, 1, "d6e4acebf05f684219efbc25a28b15d0df6bc0ac1499c22a9bb2452810bd1a26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
