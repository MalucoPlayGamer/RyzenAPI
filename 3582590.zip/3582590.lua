-- Lua provided by RyzenAPI 
-- Game: Deedlee Doo! Carkour!
addappid(3582590)
addappid(3582591, 1, "d6e4acebf05f684219efbc25a28b15d0df6bc0ac1499c22a9bb2452810bd1a26")
