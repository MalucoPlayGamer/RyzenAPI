-- Lua provided by RyzenAPI
-- Game: AppID 423490

-- MAIN APPLICATION
addappid(423490)

-- MAIN APP DEPOTS / PACKAGES
addappid(423491, 1, "84ee169cd02cd52105d3777ec59eda5fb7bf448b9a7229d09405d4dd5d196cad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(549970)
addappid(549971)
addappid(562820)
