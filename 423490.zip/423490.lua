-- Lua provided by SkyAPI 
-- Game: AppID 423490
addappid(423490)
addappid(423491, 1, "84ee169cd02cd52105d3777ec59eda5fb7bf448b9a7229d09405d4dd5d196cad")
