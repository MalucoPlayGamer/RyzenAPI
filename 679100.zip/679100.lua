-- Lua provided by RyzenAPI
-- Game: Aequitas Orbis

-- MAIN APPLICATION
addappid(679100)

-- MAIN APP DEPOTS / PACKAGES
addappid(679102,0,"3428522a821e319631922202099815ffa2e68743527c9709bf10e8eccc537a92")
addappid(679104,0,"b7c43b1fd21d1e9464ca2c23f09dcc1e7604c86ab6292a0899d1b4316ce03e72")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(745770)
