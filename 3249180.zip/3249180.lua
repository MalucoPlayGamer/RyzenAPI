-- Lua provided by RyzenAPI
-- Game: 3249180

-- MAIN APPLICATION
addappid(3249180)
-- Game: addappid(3249180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249181, 1, "f6b198f8ebe1ac45c86422d5d5588c1a3018e5a36008d1134743ce4e56af0fe8")
