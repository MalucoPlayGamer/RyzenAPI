-- Lua provided by SkyAPI 
-- Game: Traveller's Hymn
addappid(3249180)
addappid(3249181, 1, "f6b198f8ebe1ac45c86422d5d5588c1a3018e5a36008d1134743ce4e56af0fe8")
