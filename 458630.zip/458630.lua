-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(458630)
addappid(458631)
addappid(458633)
addappid(458634)
addappid(458635)

-- MAIN APP DEPOTS / PACKAGES
addappid(458632,0,"b04b2cb9e6e1c6dc3681974160637dbbd2ea444dd069a6b166f1cf3373515e9e")

