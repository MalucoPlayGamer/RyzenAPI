-- Lua provided by RyzenAPI
-- Game: 859480

-- MAIN APPLICATION
addappid(859480)
-- Game: addappid(859480)

-- MAIN APP DEPOTS / PACKAGES
addappid(859481, 1, "65221b1db6c2bc48a41a59f7d4bd9e1384bfee0c15166dfe328788214ae9b47a")
