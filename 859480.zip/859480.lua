-- Lua provided by RyzenAPI
-- Game: Block Competition

-- MAIN APPLICATION
addappid(859480)

-- MAIN APP DEPOTS / PACKAGES
addappid(859481, 1, "65221b1db6c2bc48a41a59f7d4bd9e1384bfee0c15166dfe328788214ae9b47a")

