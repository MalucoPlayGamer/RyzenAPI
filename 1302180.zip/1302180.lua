-- Lua provided by RyzenAPI
-- Game: Racing Juke

-- MAIN APPLICATION
addappid(1302180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302181, 1, "2c155a8c9cae55afb3d7312dc61123471ae4b25d32fbbbedfeba1cd40f8f75e5")
