-- Lua provided by RyzenAPI
-- Game: Roll For Initiative

-- MAIN APPLICATION
addappid(1778060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778061, 1, "8c543697957e52d5838b3f2fd1bea1ae531203aa01a70a970a33503683e18840")

