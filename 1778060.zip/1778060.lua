-- Lua provided by RyzenAPI
-- Game: Roll For Initiative

-- MAIN APPLICATION
addappid(1778060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1778061, 1, "8c543697957e52d5838b3f2fd1bea1ae531203aa01a70a970a33503683e18840")

