-- Lua provided by RyzenAPI
-- Game: Black Mirror II

-- MAIN APPLICATION
addappid(286460)

-- MAIN APP DEPOTS / PACKAGES
addappid(286461, 1, "c53b742592fd7ef4c6703448c5b4b4e91db792b5e14a75941bc829c3619329a1")
addappid(286462, 1, "28df5daa772ec8fa23a3ecac81fe889d56b697ec6d4d063ea2da75488e430b65")
addappid(286463, 1, "8f28c5bd4c6d5da9f444947caf13b3b50dae967b68abfc6171336d4eaa2f4363")
addappid(286464, 1, "5b407eeaffeba361cbdbdf7da8707875874bc38cf00fe482aeaf0f1523585a29")
addappid(286465, 1, "20ba9d9dc323a5ff6de5632a1e345fa9175f8351f53cd3ef04e7cd5e9913cfb8")
addappid(286466, 1, "35c72cf17c4830bbc21fb45d1ab314d81e9c6933a066e9151932a797d8d1d1a9")
addappid(286467, 1, "017c81eb3ff273fc8d61f05c8ee28ca11217044b8803e799fb40154cd8b84f87")
addappid(286468, 1, "a19f1eb53f5f2723e2b5cb8fe5385a3fb9bd2cc563b418432512614708c46986")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
