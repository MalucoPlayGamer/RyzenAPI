-- Lua provided by RyzenAPI
-- Game: Hatland Adventures

-- MAIN APPLICATION
addappid(347930)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(347931, 1, "5c1e9b5b2015feb1eb987e3b42c62bc04a235e65806dad2b7030f9b74d9d1755")

