-- Lua provided by RyzenAPI
-- Game: 347930

-- MAIN APPLICATION
addappid(347930)
-- Game: addappid(347930)

-- MAIN APP DEPOTS / PACKAGES
addappid(347931, 1, "5c1e9b5b2015feb1eb987e3b42c62bc04a235e65806dad2b7030f9b74d9d1755")
