-- Lua provided by RyzenAPI
-- Game: AppID 432150

-- MAIN APPLICATION
addappid(432150)

-- MAIN APP DEPOTS / PACKAGES
addappid(432151, 1, "975dae250b901b3c41bf73fd0e6fcfc68dccab93e90f2907094551cd041971aa")
