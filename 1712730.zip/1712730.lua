-- Lua provided by RyzenAPI
-- Game: Aptly Rolling

-- MAIN APPLICATION
addappid(1712730)
-- Game: addappid(1712730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712731, 1, "bfe44216583df61a24778ec56b333c5d9985b72b277131bfa53edc6d181c71e1")
