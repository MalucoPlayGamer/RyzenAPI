-- Lua provided by RyzenAPI
-- Game: DARK SHORES

-- MAIN APPLICATION
addappid(574710)

-- MAIN APP DEPOTS / PACKAGES
addappid(574715,0,"d8066d739700a866ee1552e23673d208ecb981d14c40d523e4a2f927e1342c58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
