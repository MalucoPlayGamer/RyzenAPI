-- Lua provided by RyzenAPI
-- Game: 446620

-- MAIN APPLICATION
addappid(446620)
-- Game: addappid(446620)

-- MAIN APP DEPOTS / PACKAGES
addappid(446621, 1, "db2c2f105c2bd64c27902c32fca9ed2b8f9b55cfd7883ed09c1d202264baecd3")
