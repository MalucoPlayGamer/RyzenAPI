-- Lua provided by RyzenAPI
-- Game: Legacy of the Ark: The Long Awakening

-- MAIN APPLICATION
addappid(4871420)
