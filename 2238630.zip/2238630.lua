-- Lua provided by RyzenAPI
-- Game: Forgotten Mines

-- MAIN APPLICATION
addappid(2238630)
-- Game: addappid(2238630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238631, 1, "4c2050d579a527334f61fe29034c195273fdd9927c6f82df257578e26e955467")
