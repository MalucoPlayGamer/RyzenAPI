-- Lua provided by RyzenAPI
-- Game: Game: Skelly Selest

-- MAIN APPLICATION
addappid(685400)
-- Game: addappid(685400)

-- MAIN APP DEPOTS / PACKAGES
addappid(685401, 1, "ab534dac0ab86cf41bb87af31eb17c50b0762ddccd21b7327c2b91a34a89d85c")
