-- Lua provided by RyzenAPI
-- Game: Break The Targets

-- MAIN APPLICATION
addappid(802130)
-- Game: addappid(802130)

-- MAIN APP DEPOTS / PACKAGES
addappid(802131, 1, "345f5dd9db2be44f6642b528a444f36722af740d3fbe9c7b85d9110097c04ef2")
