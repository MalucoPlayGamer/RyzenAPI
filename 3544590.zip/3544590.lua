-- Lua provided by RyzenAPI
-- Game: Feast of the Beast

-- MAIN APPLICATION
addappid(3544590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3544591, 1, "73307d53d917d36383437634ca49a2444941dce0cf51d6952cce68405c685a38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
