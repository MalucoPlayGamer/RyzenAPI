-- Lua provided by RyzenAPI
-- Game: Feast of the Beast

-- MAIN APPLICATION
addappid(3544590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3544591, 1, "73307d53d917d36383437634ca49a2444941dce0cf51d6952cce68405c685a38")

