-- Lua provided by RyzenAPI
-- Game: Five Minutes Till Christmas

-- MAIN APPLICATION
addappid(3330390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3330391, 1, "c653aef57fb4cd2e5d57bdf56a6433e03c92bceafb73115b723987b432dab08e")

