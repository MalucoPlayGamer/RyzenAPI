-- Lua provided by RyzenAPI
-- Game: Five Minutes Till Christmas

-- MAIN APPLICATION
addappid(3330390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330391, 1, "c653aef57fb4cd2e5d57bdf56a6433e03c92bceafb73115b723987b432dab08e")

