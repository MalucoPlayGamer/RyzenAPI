-- Lua provided by RyzenAPI 
-- Game: AppID 1725760
addappid(1725760)
addappid(1725761, 1, "eb9233620604afb52eca74935c8a812fd2583ec4f923c5db790a797c89f0eb8b")
addappid(1725762, 1, "59d37872de4b2017085982272bbc410361bb7f8f42343abb2fabeb841c5413a2")
