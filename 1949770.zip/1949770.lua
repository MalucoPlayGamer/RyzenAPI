-- Lua provided by RyzenAPI
-- Game: 1949770

-- MAIN APPLICATION
addappid(1949770)
-- Game: addappid(1949770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949771, 1, "ac20b38673a43e87c88bb08fd348ff833cf803a857d41dd3ec5aa332d0ce7829")
