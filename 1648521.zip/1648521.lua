-- Lua provided by RyzenAPI
-- Game: 1648521

-- MAIN APPLICATION
addappid(1648521)
-- Game: addappid(1648521)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648521,0,"c113c66dd5f52b95de4fce24a0e6b39f8d7b55006c6693de367af190c5d099ea")
