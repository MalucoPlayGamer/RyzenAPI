-- Lua provided by RyzenAPI
-- Game: Game: Glider Sim Deluxe – Soaring Simulator

-- MAIN APPLICATION
addappid(1422940)
-- Game: addappid(1422940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422941, 1, "8556e2c91e663ffd6a371170bb0facf16363b843532941402e15ec39df70a930")
