-- Lua provided by RyzenAPI
-- Game: 350910

-- MAIN APPLICATION
addappid(350910)
-- Game: addappid(350910)

-- MAIN APP DEPOTS / PACKAGES
addappid(350911, 1, "44f2c6687c3b823d40fec65fb2b8df6088d089cd13df84154435fe170c673386")
addappid(350913, 1, "165610fc670190772c4f95ca9b081ab6faf96ad01af054b7bcceeede80a4c943")
