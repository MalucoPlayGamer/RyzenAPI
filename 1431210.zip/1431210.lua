-- Lua provided by RyzenAPI 
-- Game: MahJong - Medieval Fantasy
addappid(1431210)
addappid(1431211, 1, "5795294014a1afc863c5e265a72b22bcc0ed368f762982e32ba397702f73ae81")
