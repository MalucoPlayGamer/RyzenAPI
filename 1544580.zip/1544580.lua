-- Lua provided by RyzenAPI
-- Game: Would you like to run an idol café?

-- MAIN APPLICATION
addappid(1544580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544581, 1, "dc5f37f7b1309450e35df35f360313a2a98da9925c86dfccaaf92a54953ae665")
