-- Lua provided by RyzenAPI
-- Game: Atomic Girls Soundtrack

-- MAIN APPLICATION
addappid(1516830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516831, 1, "ba0375b4a3d5acdb554d93240cbff36cfab90d7fe4ef9f8d66c10a7d73a90e00")

