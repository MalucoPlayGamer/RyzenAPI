-- Lua provided by SkyAPI 
-- Game: Atomic Girls Soundtrack
addappid(1516830)
addappid(1516831, 1, "ba0375b4a3d5acdb554d93240cbff36cfab90d7fe4ef9f8d66c10a7d73a90e00")
