-- Lua provided by RyzenAPI
-- Game: Game: AppID 1892280

-- MAIN APPLICATION
addappid(1892280)
-- Game: addappid(1892280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892281, 1, "89b437c0c89aae9c8ef3ed4733a30f07999075d609af3d76f1f41ac0d7d50af4")
