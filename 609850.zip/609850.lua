-- Lua provided by RyzenAPI
-- Game: Slinger VR

-- MAIN APPLICATION
addappid(609850)

-- MAIN APP DEPOTS / PACKAGES
addappid(609851, 1, "2b295bbe6f188c1ab07b7eff0b5f88efff9e172caba5661b28ba254e9fb099ee")

