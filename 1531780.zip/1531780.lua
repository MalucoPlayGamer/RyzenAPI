-- Lua provided by RyzenAPI
-- Game: AppID 1531780

-- MAIN APPLICATION
addappid(1531780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1531781, 1, "c39157c3d50cb05980c7ec131d3f46001baaa0b3495c45791b6ba4acda8b1b1a")

