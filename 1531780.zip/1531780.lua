-- Lua provided by SkyAPI 
-- Game: AppID 1531780
addappid(1531780)
addappid(1531781, 1, "c39157c3d50cb05980c7ec131d3f46001baaa0b3495c45791b6ba4acda8b1b1a")
