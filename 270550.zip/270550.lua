-- Lua provided by RyzenAPI
-- Game: Yet Another Zombie Defense

-- MAIN APPLICATION
addappid(270550)

-- MAIN APP DEPOTS / PACKAGES
addappid(270551, 1, "699b0c00c5f312cc2f54f95ee0c09a7ee14d1a2a17c1057809c80b07bfaf1c35")

