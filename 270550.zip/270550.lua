-- Lua provided by RyzenAPI
-- Game: Yet Another Zombie Defense

-- MAIN APPLICATION
addappid(270550)

-- MAIN APP DEPOTS / PACKAGES
addappid(270551, 1, "699b0c00c5f312cc2f54f95ee0c09a7ee14d1a2a17c1057809c80b07bfaf1c35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
