-- Lua provided by RyzenAPI
-- Game: Recall

-- MAIN APPLICATION
addappid(1604440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1604442,0,"5a29af63c4e5482fc981a17d302c8d9d2ee3858371d655d75da50d8fae972bd6")

