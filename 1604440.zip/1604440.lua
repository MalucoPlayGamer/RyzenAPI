-- Lua provided by RyzenAPI
-- Game: setManifestid(1604442,"7241525880270040618")

-- MAIN APPLICATION
addappid(1604440)
-- Game: addappid(1604440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604442,0,"5a29af63c4e5482fc981a17d302c8d9d2ee3858371d655d75da50d8fae972bd6")
