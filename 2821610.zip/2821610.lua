-- Lua provided by RyzenAPI
-- Game: Echoes of the End: Enhanced Edition

-- MAIN APPLICATION
addappid(2821610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2821611, 1, "9d26f14b9a968c26e106af6e03b8738a5038d34a341d6dd6c68ea51cfbd25985")

