-- Lua provided by RyzenAPI
-- Game: addappid(2821610)

-- MAIN APPLICATION
addappid(2821610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821611, 1, "9d26f14b9a968c26e106af6e03b8738a5038d34a341d6dd6c68ea51cfbd25985")
