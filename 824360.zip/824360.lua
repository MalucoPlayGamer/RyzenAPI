-- Lua provided by RyzenAPI
-- Game: addappid(824360)

-- MAIN APPLICATION
addappid(824360)

-- MAIN APP DEPOTS / PACKAGES
addappid(824361, 1, "4a07063f5021a72df1b577dc36a46314222e3a8ff8b6c5df9d9eff3fda91423b")
