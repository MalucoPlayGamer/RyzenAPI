-- Lua provided by RyzenAPI
-- Game: addappid(1561380)

-- MAIN APPLICATION
addappid(1561380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561381, 1, "4f05bd7ea2074f4907ec73cedf91635f5224898c823b0d3b009fdc37dcda0f61")
