-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Alette's Swimsuit "Rainmaker"

-- MAIN APPLICATION
addappid(1754700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754700,0,"5850698dcb737db293d85d928794dceb3455934ba9b1b19e0069d95d37675a28")
