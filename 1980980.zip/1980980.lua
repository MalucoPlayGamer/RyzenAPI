-- Lua provided by RyzenAPI
-- Game: The Backrooms Project

-- MAIN APPLICATION
addappid(1980980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1980981, 1, "ee3b7873b6702b9eca4c9c17f8172351c588c1900c28324a951547040bab0df9")

