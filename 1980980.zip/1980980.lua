-- Lua provided by RyzenAPI
-- Game: Game: The Backrooms Project

-- MAIN APPLICATION
addappid(1980980)
-- Game: addappid(1980980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980981, 1, "ee3b7873b6702b9eca4c9c17f8172351c588c1900c28324a951547040bab0df9")
