-- Lua provided by RyzenAPI
-- Game: Game: CTHULOOT

-- MAIN APPLICATION
addappid(2283410)
-- Game: addappid(2283410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283411, 1, "133f28fc93dd9acec253e20551c7f75246a38f06d08953f37ad3a66403126484")
