-- Lua provided by RyzenAPI
-- Game: Game: Ravenous Devils

-- MAIN APPLICATION
addappid(1615290)
-- Game: addappid(1615290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1615291, 1, "3922ca231f055cfc951f20d2aa0497a90dd0ddf945d91135ece9ed433f37534a")
