-- Lua provided by RyzenAPI
-- Game: Ravenous Devils

-- MAIN APPLICATION
addappid(1615290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1615291, 1, "3922ca231f055cfc951f20d2aa0497a90dd0ddf945d91135ece9ed433f37534a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
