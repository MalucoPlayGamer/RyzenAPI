-- Lua provided by RyzenAPI
-- Game: addappid(906390)

-- MAIN APPLICATION
addappid(906390)

-- MAIN APP DEPOTS / PACKAGES
addappid(906391, 1, "21a86a0b84d344af8022ad04866eea93db5041d7867bba630dc3cb35dab6d3cb")
