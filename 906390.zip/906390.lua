-- Lua provided by RyzenAPI
-- Game: Return.

-- MAIN APPLICATION
addappid(906390)
addappid(907150)

-- MAIN APP DEPOTS / PACKAGES
addappid(906391,0,"21a86a0b84d344af8022ad04866eea93db5041d7867bba630dc3cb35dab6d3cb")

