-- Lua provided by RyzenAPI
-- Game: BallBastic!

-- MAIN APPLICATION
addappid(2428170)
addappid(2899560)
addappid(2996730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428171, 1, "b2a70bb48c551d4d5fe847583b8c5483d7d789595a607c691c5dd78569faa78e")

