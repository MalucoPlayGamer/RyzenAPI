-- Lua provided by RyzenAPI
-- Game: Junk Jack

-- MAIN APPLICATION
addappid(414190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(414191, 1, "d8325c05742410bf8997eacf94ff4a72f5a1de6d9da227cc1799f92bc6106db4")
addappid(414192, 1, "f95bddc68066248b8d55a18f4b1bf5a1b3e84676fb7dce8f6c7a14db8e61df41")
addappid(414193, 1, "32d436d41017d1fd4a6ed5c067e74b2ddce6e7087d2e16ff790e28c9c2d81302")
addappid(414194, 1, "b3a2f121c225f36dbbb4c46cf0383345b6926530926ec5c7a0434f3da1611d3e")
addappid(414196, 1, "ef47e74554e5fccea94f7875eb9bd65c86cfbd5f3496b334285da1d72f06ef98")
addappid(414198, 1, "666e11d55bb0fcd6085d40ea4daa1016d10b43c638671a2a3c18c21b87d3a8f1")

