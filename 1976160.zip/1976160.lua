-- Lua provided by RyzenAPI
-- Game: Pixel Palette Creator 🎨🖌️

-- MAIN APPLICATION
addappid(1976160)
addappid(1979600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976161, 1, "65320f2e021ec3ae4811685554f9ef216d57436551df24db92ec715ee86e0bfa")

