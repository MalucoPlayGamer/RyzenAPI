-- Lua provided by RyzenAPI
-- Game: Ovine Replica

-- MAIN APPLICATION
addappid(2490820)
-- Game: addappid(2490820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490821, 1, "385ca2b51ce74efa870fef2059095724ffc726c9e8ede728070a4e0585c59728")
addappid(2490822, 1, "815e245a02661f231dcabbce74e2b92b80991982a9facdc19015dc8c80fcf118")
addappid(2490823, 1, "ec4cf944b6b19aed6404895ff44341dc0ac0db7d42300b6d277376641cae0a03")
