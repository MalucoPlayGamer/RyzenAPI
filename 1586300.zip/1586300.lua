-- Lua provided by RyzenAPI
-- Game: Jacob The Farmer

-- MAIN APPLICATION
addappid(1586300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586301, 1, "e02c6915c72c06057393ebbc46c8a4fb86ae84b11997664ff67935e31c089e47")

