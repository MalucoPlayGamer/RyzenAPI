-- Lua provided by RyzenAPI
-- Game: addappid(1588010)

-- MAIN APPLICATION
addappid(1588010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588011, 1, "115b07cbe961849aa56b23cb6e55235fb940462a1138e4808b0f4e72d44e3cb7")
