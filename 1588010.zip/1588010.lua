-- Lua provided by RyzenAPI
-- Game: PGA TOUR 2K23

-- MAIN APPLICATION
addappid(1588010)
addappid(1952790)
addappid(1952791)
addappid(1952792)
addappid(1952793)
addappid(2105190)
addappid(2491900)
addappid(2491901)
addappid(2491902)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1588011,0,"115b07cbe961849aa56b23cb6e55235fb940462a1138e4808b0f4e72d44e3cb7")

