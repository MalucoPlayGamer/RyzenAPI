-- Lua provided by RyzenAPI
-- Game: PGA TOUR 2K23

-- MAIN APPLICATION
addappid(1588010)
addappid(1952790)
addappid(1952791)
addappid(1952792)
addappid(1952793)
addappid(2105190)
addappid(2491900)
addappid(2491901)
addappid(2491902)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588011,0,"115b07cbe961849aa56b23cb6e55235fb940462a1138e4808b0f4e72d44e3cb7")

