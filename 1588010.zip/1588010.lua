-- Lua provided by SkyAPI 
-- Game: PGA TOUR 2K23
addappid(1588010)
addappid(1588011, 1, "115b07cbe961849aa56b23cb6e55235fb940462a1138e4808b0f4e72d44e3cb7")
