-- Lua provided by RyzenAPI
-- Game: Uninvited Guest

-- MAIN APPLICATION
addappid(1659210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1659211, 1, "c5ef6f34f3abdc67a21f44b727eaf2372969381c058f595df177a5e1960d1561")
addappid(1814660, 0, "d1e5049e12a889d8f24d2a34ad3cdfb7b511c820e54ceef5a778bb19129c8ff6")

