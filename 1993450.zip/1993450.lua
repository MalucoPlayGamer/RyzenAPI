-- Lua provided by RyzenAPI
-- Game: 1993450

-- MAIN APPLICATION
addappid(1993450)
-- Game: addappid(1993450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993451, 1, "b9bbe7253fefd4feafe607c9b258199ebd768e6e519463fc1379569c57dff75e")
