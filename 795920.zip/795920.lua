-- Lua provided by RyzenAPI
-- Game: SALVATOR

-- MAIN APPLICATION
addappid(795920)
-- Game: addappid(795920)

-- MAIN APP DEPOTS / PACKAGES
addappid(795921, 1, "0fb7a33fa08617570be20407ecfff34b39ab95992381b4f7482b05ce0afd0721")
