-- Lua provided by RyzenAPI 
-- Game: Infested Inside Multiplayer Online
addappid(1055360)
addappid(1055361, 1, "279c956543c330317501a938e013f545e899d413e9ed0b20a4509f0ebe97ae86")
