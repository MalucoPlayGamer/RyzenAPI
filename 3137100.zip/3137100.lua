-- Lua provided by RyzenAPI
-- Game: Where Girls Are Made

-- MAIN APPLICATION
addappid(3137100)
-- Game: addappid(3137100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137101, 1, "bfd3c52314858cbf36141b98feb4c11851ec8fae9819ec977b4a28fd2b627bdb")
