-- Lua provided by RyzenAPI
-- Game: Miko Sniper

-- MAIN APPLICATION
addappid(2971440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2971441, 1, "a606d9b31ad0fc721ae98335f8e417b7bc2e6531cbfb99cf94020e9ddba2c9e3")

