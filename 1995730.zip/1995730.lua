-- Lua provided by RyzenAPI
-- Game: 1995730

-- MAIN APPLICATION
addappid(1995730)
-- Game: addappid(1995730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995731, 1, "a8a57384589523ad66877b6d0ae398f6a04d580f76b38e6c4f62910d356db6ba")
