-- Lua provided by RyzenAPI
-- Game: Game: VR Soccer Training

-- MAIN APPLICATION
addappid(796970)
-- Game: addappid(796970)

-- MAIN APP DEPOTS / PACKAGES
addappid(796971, 1, "2978149919d8a41969f973d556f7ec2feddfd523e459c92f3847dff3bfeec0bc")
