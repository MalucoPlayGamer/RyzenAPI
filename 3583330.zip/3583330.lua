-- Lua provided by RyzenAPI
-- Game: 3583330

-- MAIN APPLICATION
addappid(3583330)
-- Game: addappid(3583330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3583333,0,"63e93656bea8ba072b6d1584f6bdbbe1c37b781772fb7a5962add8cd372579c2")
