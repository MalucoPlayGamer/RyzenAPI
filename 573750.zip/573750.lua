-- Lua provided by RyzenAPI
-- Game: AppID 573750

-- MAIN APPLICATION
addappid(573750)

-- MAIN APP DEPOTS / PACKAGES
addappid(573751, 1, "48fa3f886aec16573bdfec877440dbbb8682dee569a6f905237dabebe46effda")
