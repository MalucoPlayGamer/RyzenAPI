-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(920700)
addappid(920701)
addappid(920703)

-- MAIN APP DEPOTS / PACKAGES
addappid(920702,0,"c90fc7b833378684efbda53fbc1378c0da219cf2fb74cc443bb630f6661bd99c")

