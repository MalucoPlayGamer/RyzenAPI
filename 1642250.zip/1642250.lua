-- Lua provided by RyzenAPI
-- Game: 1642250

-- MAIN APPLICATION
addappid(1642250)
addappid(1649600)
-- Game: addappid(1642250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642251, 1, "1bc455a9f055d1dc30f8c03f5ece0a4770228e8394c92e8c851a42c86645c427")
