-- Lua provided by RyzenAPI
-- Game: 1022493

-- MAIN APPLICATION
addappid(1022493)
-- Game: addappid(1022493)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022493,0,"f40402f7ff6e34060d33aaa0f36eed7a4ad27f0f39e9731e3f7b991fb521a684")
