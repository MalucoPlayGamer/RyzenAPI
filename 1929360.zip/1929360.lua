-- Lua provided by RyzenAPI
-- Game: Tumbleweed Destiny

-- MAIN APPLICATION
addappid(1929360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929361, 1, "90020666ff0800a6f72860499f3b9603fd91179a7fdedd8204ba6256becc73c6")

