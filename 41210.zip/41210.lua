-- Lua provided by RyzenAPI
-- Game: Game: Eufloria

-- MAIN APPLICATION
addappid(41210)
-- Game: addappid(41210)

-- MAIN APP DEPOTS / PACKAGES
addappid(41211, 1, "75d546287a157d4b33dbcaa2409880bb178988342ac208076452aeb5365b594c")
