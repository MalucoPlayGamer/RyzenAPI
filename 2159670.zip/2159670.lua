-- Lua provided by RyzenAPI
-- Game: 2159670

-- MAIN APPLICATION
addappid(2159670)
-- Game: addappid(2159670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159671, 1, "6cd8677d15ffdd684e1c806248307dd911464fb0eabaade8efc8b57996489d2c")
