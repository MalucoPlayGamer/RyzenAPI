-- Lua provided by RyzenAPI
-- Game: addappid(40810)

-- MAIN APPLICATION
addappid(40810)

-- MAIN APP DEPOTS / PACKAGES
addappid(40811, 1, "7fd6577f575efe7e1c578988d71e7eae2b2b51b05244806977e75276cf5c42b0")
