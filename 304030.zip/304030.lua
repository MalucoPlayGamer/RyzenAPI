-- Lua provided by RyzenAPI
-- Game: 304030

-- MAIN APPLICATION
addappid(304030)
-- Game: addappid(304030)

-- MAIN APP DEPOTS / PACKAGES
addappid(304031, 1, "ebf77a14607c58da7dba4738d045bd47ffdf0d088db759f52319795b5cf774d2")
