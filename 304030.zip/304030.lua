-- Lua provided by RyzenAPI
-- Game: ArcheAge

-- MAIN APPLICATION
addappid(304030)
addappid(304070)
addappid(304071)
addappid(304072)
addappid(357160)
addappid(357161)
addappid(357162)
addappid(357163)
addappid(380850)
addappid(445320)
addappid(445321)
addappid(445330)
addappid(485300)
addappid(485301)
addappid(485302)
addappid(528890)
addappid(528891)
addappid(528892)
addappid(553920)
addappid(647860)
addappid(832350)
addappid(1826850)

-- MAIN APP DEPOTS / PACKAGES
addappid(304031, 1, "ebf77a14607c58da7dba4738d045bd47ffdf0d088db759f52319795b5cf774d2")

