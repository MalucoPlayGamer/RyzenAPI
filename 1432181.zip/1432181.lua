-- Lua provided by RyzenAPI
-- Game: FUSER™ - Flo Rida ft. T-Pain - "Low"

-- MAIN APPLICATION
addappid(1432181)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432181,0,"775a70dbf08214a12c1f3f52e58e87da03a8baca5e5c3233835af22e99b8f224")

