-- Lua provided by RyzenAPI
-- Game: addappid(1297090)

-- MAIN APPLICATION
addappid(1297090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297091, 1, "af4f08a270ec669724f9acea9668fe1a85cb2a15ffb91ce63de748170fd80cdb")
