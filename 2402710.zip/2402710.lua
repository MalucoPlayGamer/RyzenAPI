-- Lua provided by RyzenAPI
-- Game: DPS IDLE 2

-- MAIN APPLICATION
addappid(2402710)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3189390)
addappid(3189400)
addappid(3189410)
addappid(3189420)
