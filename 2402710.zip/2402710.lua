-- Lua provided by RyzenAPI
-- Game: DPS IDLE 2

-- MAIN APPLICATION
addappid(2402710)
