-- Lua provided by RyzenAPI
-- Game: Game: AppID 1252390

-- MAIN APPLICATION
addappid(1252390)
-- Game: addappid(1252390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252391, 1, "22624de6877f7017656e03197398153c2e1cfa53e435a97ef3f1c8a004a5cbd4")
