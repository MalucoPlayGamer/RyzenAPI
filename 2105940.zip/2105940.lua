-- Lua provided by RyzenAPI
-- Game: Synthalaxy

-- MAIN APPLICATION
addappid(2105940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2105941, 1, "f5a31c0580d5b699b3e21994c3235dd20f5a17eb3c351560ae2a7688e6ea08be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
