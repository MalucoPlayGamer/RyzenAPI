-- Lua provided by RyzenAPI
-- Game: Synthalaxy

-- MAIN APPLICATION
addappid(2105940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2105941, 1, "f5a31c0580d5b699b3e21994c3235dd20f5a17eb3c351560ae2a7688e6ea08be")
