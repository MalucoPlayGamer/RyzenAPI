-- Lua provided by RyzenAPI
-- Game: Game: CompactO - Idle Game

-- MAIN APPLICATION
addappid(1516490)
-- Game: addappid(1516490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516491, 1, "6ee3b9df54d901fc0107f7a559ccf6b72511fc1a875a73aa9244d1d7122bcb01")
