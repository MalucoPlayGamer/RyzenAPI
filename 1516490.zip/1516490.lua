-- Lua provided by RyzenAPI 
-- Game: CompactO - Idle Game
addappid(1516490)
addappid(1516491, 1, "6ee3b9df54d901fc0107f7a559ccf6b72511fc1a875a73aa9244d1d7122bcb01")
