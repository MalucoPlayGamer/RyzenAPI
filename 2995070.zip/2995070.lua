-- Lua provided by RyzenAPI
-- Game: Liminal Void Demo

-- MAIN APPLICATION
addappid(2995070)
-- Game: addappid(2995070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2995071, 1, "1b8326bd2ac352ab47e94fb3297739976f54908dfb76cf504f1f66e5b12b940d")
