-- Lua provided by RyzenAPI
-- Game: Parabellum: Siege Of Legends

-- MAIN APPLICATION
addappid(3682400)
-- Game: addappid(3682400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3682401, 1, "bc421966ca385ab98c8ce4ca4026bec7e2a9a01ba0bcf5f9c11911a560f777a4")
