-- Lua provided by RyzenAPI
-- Game: addappid(1845760)

-- MAIN APPLICATION
addappid(1845760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845761, 1, "8be76e56926779c37f9f3eab740c7b38b9a8da6806d5f5f9d5beaaa13918605a")
