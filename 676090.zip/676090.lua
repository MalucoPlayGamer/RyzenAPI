-- Lua provided by RyzenAPI
-- Game: Legend Of Mercy 神医魔导

-- MAIN APPLICATION
addappid(676090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(676091, 1, "7139baaebde37e7ca1dd50b0b85c4ba64321c50d06d9129b5a4216d8da9eaa70")
addappid(888430, 0, "f6b08be13882515472202959a126314792fd6ffcf1f805273d72ccedb59f1c91")
addappid(1019110, 0, "e7f893d190dc57dede5785b2f1ad2da38e533f58b7349b0350ba469abcbdd3dc")
addappid(1048770, 0, "2003b790411f8a69ca88b6dc29b75e8c2f09c814247138e179148b23fedfd7f7")

