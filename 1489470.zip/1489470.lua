-- Lua provided by RyzenAPI
-- Game: Game: Do You See the Waving Cape

-- MAIN APPLICATION
addappid(1489470)
-- Game: addappid(1489470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489471, 1, "27fe55ea5b96a4034bcc4285abebc6b857c472dfea1dd979f3b76763ba9b8297")
