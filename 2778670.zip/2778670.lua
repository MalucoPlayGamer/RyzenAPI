-- Lua provided by RyzenAPI
-- Game: Game: AppID 2778670

-- MAIN APPLICATION
addappid(2778670)
-- Game: addappid(2778670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778671, 1, "a97fce75e2580370511aeb9f84b806f32e0ae93d70921c0a574371945d021eb4")
