-- Lua provided by RyzenAPI
-- Game: STAR WARS™: The Force Unleashed™ II

-- MAIN APPLICATION
addappid(32500)

-- MAIN APP DEPOTS / PACKAGES
addappid(32501, 1, "35b1b5fdcf3803d161fec434ad7aa9463f7cad667ad4086f9b6c2a5c865c14c9")
addappid(32502, 1, "2bf1ebfe91d219e0a96890ce46dd2d8af98e02badf5a5de304bbe3ed8fe21d59")
addappid(32503, 1, "c7e1b842997f64b8ebf68d26d3c88ae266b370fca8cc4e0973e0183511e3dc80")
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

