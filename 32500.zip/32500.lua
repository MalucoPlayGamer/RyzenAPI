-- Lua provided by RyzenAPI
-- Game: Game: STAR WARS™: The Force Unleashed™ II

-- MAIN APPLICATION
addappid(32500)
-- Game: addappid(32500)

-- MAIN APP DEPOTS / PACKAGES
addappid(32501, 1, "35b1b5fdcf3803d161fec434ad7aa9463f7cad667ad4086f9b6c2a5c865c14c9")
addappid(32502, 1, "2bf1ebfe91d219e0a96890ce46dd2d8af98e02badf5a5de304bbe3ed8fe21d59")
addappid(32503, 1, "c7e1b842997f64b8ebf68d26d3c88ae266b370fca8cc4e0973e0183511e3dc80")
