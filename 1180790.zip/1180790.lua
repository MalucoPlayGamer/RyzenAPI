-- Lua provided by RyzenAPI
-- Game: ImageStriker

-- MAIN APPLICATION
addappid(1180790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180791, 1, "704b5c99ca86c953ce290d5b38ac98dd273e7f15d54133e1127f5dbaa4e6ffda")

