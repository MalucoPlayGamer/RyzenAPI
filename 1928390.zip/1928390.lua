-- Lua provided by RyzenAPI
-- Game: Sheep's Territory

-- MAIN APPLICATION
addappid(1928390)
-- Game: addappid(1928390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928391, 1, "aa80feff00e74199cab7540dfcba5629565a4617fa67ff78237de67f1e4485b8")
