-- Lua provided by RyzenAPI
-- Game: Jaunt VR - Experience Cinematic Virtual Reality

-- MAIN APPLICATION
addappid(456450)

-- MAIN APP DEPOTS / PACKAGES
addappid(456451, 1, "dde42557c548471dbce80e85f46229aaea284a3c2e5d496dc0b57620076c635b")
