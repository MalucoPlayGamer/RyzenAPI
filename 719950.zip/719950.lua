-- Lua provided by RyzenAPI
-- Game: addappid(719950)

-- MAIN APPLICATION
addappid(719950)

-- MAIN APP DEPOTS / PACKAGES
addappid(719951, 1, "7ba1371d80e21193c368ff6657078409455d7ac9ce2eaeabddd1f9692ab5f5dc")
