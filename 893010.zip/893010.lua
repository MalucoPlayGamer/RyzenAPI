-- Lua provided by RyzenAPI
-- Game: Slave's Sword

-- MAIN APPLICATION
addappid(893010)

-- MAIN APP DEPOTS / PACKAGES
addappid(893011, 1, "3aa077eb03afd2f285faaf1e2ee336ea7a9b518f25b8596e6a960262a83788a8")
addappid(893012, 1, "75859e5e7a9064af60d5d1dccea115e6e89d0331632c6a1fe7eb68da1753d75e")
addappid(893013, 1, "d9b779554694a3729639276c43c6769eeccfaff39a0833cff0f9e328795a820a")
