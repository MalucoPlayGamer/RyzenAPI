-- Lua provided by RyzenAPI
-- Game: addappid(1311730)

-- MAIN APPLICATION
addappid(1311730)
addappid(1499580)
addappid(1509580)
addappid(1509600)
addappid(1509610)
addappid(1509620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311731, 1, "4735e6ddfad368d848c872a4e0e4209ad16920bcad9b915f600a4a0ba6904219")
