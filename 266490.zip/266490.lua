-- Lua provided by RyzenAPI
-- Game: addappid(266490)

-- MAIN APPLICATION
addappid(266490)

-- MAIN APP DEPOTS / PACKAGES
addappid(266491, 1, "0bab84b246e1c3225f313831bcd3791451b6f443123ff57eb193c6cdd915d402")
