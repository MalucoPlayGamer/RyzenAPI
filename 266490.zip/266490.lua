-- Lua provided by RyzenAPI
-- Game: Lili: Child of Geos

-- MAIN APPLICATION
addappid(266490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(266491, 1, "0bab84b246e1c3225f313831bcd3791451b6f443123ff57eb193c6cdd915d402")
