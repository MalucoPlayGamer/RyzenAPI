-- Lua provided by SkyAPI 
-- Game: AppID 1169430
addappid(1169430)
addappid(1169431, 1, "5e53ce726691c9b43b12ee7b65f81bdffad53e0abdb8c764f1963d6bf800f7be")
