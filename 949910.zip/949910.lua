-- Lua provided by RyzenAPI
-- Game: Refill your Roguelike

-- MAIN APPLICATION
addappid(229003)
addappid(949910)

-- MAIN APP DEPOTS / PACKAGES
addappid(949912,0,"97b153e7ee615029704a7f3ad366f3471372c7067f4a12864ccf0719aebc9c94")

