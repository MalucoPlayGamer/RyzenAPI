-- Lua provided by RyzenAPI
-- Game: AppID 1578540

-- MAIN APPLICATION
addappid(1578540)
-- Game: addappid(1578540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578541, 1, "93cac0e56fe48dd55326955d26c53020b6a51533d0d50924a01f5aba270e8cb8")
