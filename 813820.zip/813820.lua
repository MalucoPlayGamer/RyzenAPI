-- Lua provided by RyzenAPI
-- Game: AppID 813820

-- MAIN APPLICATION
addappid(813820)

-- MAIN APP DEPOTS / PACKAGES
addappid(813821, 1, "4ed35024be26a9aa32361aa0e170819b45e4159f6a270c98000a644745536662")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(885550)
addappid(961100)
addappid(1016340)
addappid(1025380)
addappid(1049430)
addappid(1065820)
addappid(1116450)
addappid(2071780)
