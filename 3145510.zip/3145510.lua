-- Lua provided by RyzenAPI
-- Game: Japanese Rail Sim: Hakone Town of Natural Beauty and Hot Springs

-- MAIN APPLICATION
addappid(3145510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3145511, 1, "b4642f17aec3a4a93c29d0db7997e92019363401bc30c5d0f7c9026688f36ecf")

