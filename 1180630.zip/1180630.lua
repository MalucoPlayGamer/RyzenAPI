-- Lua provided by RyzenAPI 
-- Game: AppID 1180630
addappid(1180630)
addappid(1180631, 1, "463575d420d7ea4d98453ba75418364a287335a395441201585a2ae20d36c762")
