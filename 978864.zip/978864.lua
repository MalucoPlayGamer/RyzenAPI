-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Guo Jia "Additional Hypothetical Scenarios Set" / 郭嘉「追加ＩＦシナリオセット」

-- MAIN APPLICATION
addappid(978864)

-- MAIN APP DEPOTS / PACKAGES
addappid(978864,0,"95f67c3c5fb24458b6f6c43a02e4eb390f52718e6a3a279fea6c1b331829116d")
