-- Lua provided by RyzenAPI 
-- Game: Undesired Catch
addappid(3072380)
addappid(3072381, 1, "28d3a0f839132ae486242d33906fa1b773a75b5c1ad0ab991a42b194d0e06e97")
