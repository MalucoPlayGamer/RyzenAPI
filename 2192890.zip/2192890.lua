-- Lua provided by RyzenAPI
-- Game: Game: Relaxing Lawnmower Simulator

-- MAIN APPLICATION
addappid(2192890)
-- Game: addappid(2192890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192891, 1, "56ec056418b365e10334de65b5e0322006144e4bb90d284d0d5c3a8d288446d8")
