-- Lua provided by RyzenAPI 
-- Game: Relaxing Lawnmower Simulator
addappid(2192890)
addappid(2192891, 1, "56ec056418b365e10334de65b5e0322006144e4bb90d284d0d5c3a8d288446d8")
