-- Lua provided by RyzenAPI
-- Game: Relaxing Lawnmower Simulator

-- MAIN APPLICATION
addappid(2192890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192891, 1, "56ec056418b365e10334de65b5e0322006144e4bb90d284d0d5c3a8d288446d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
