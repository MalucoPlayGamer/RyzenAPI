-- Lua provided by RyzenAPI
-- Game: 1675070

-- MAIN APPLICATION
addappid(1675070)
-- Game: addappid(1675070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675071, 1, "3dd9ac78bc9e298e20dad1bce3be84b5e123179903353c92ff2c53d7cb0475b4")
