-- Lua provided by RyzenAPI
-- Game: SMETANKA

-- MAIN APPLICATION
addappid(1675070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1675071, 1, "3dd9ac78bc9e298e20dad1bce3be84b5e123179903353c92ff2c53d7cb0475b4")

