-- Lua provided by RyzenAPI
-- Game: Game: AppID 2495940

-- MAIN APPLICATION
addappid(2495940)
-- Game: addappid(2495940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495941, 1, "fac85324712b03b253d2b97091aa01b97f632b6ed033c862d22717404b27a04e")
