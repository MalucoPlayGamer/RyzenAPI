-- Lua provided by SkyAPI 
-- Game: AppID 2495940
addappid(2495940)
addappid(2495941, 1, "fac85324712b03b253d2b97091aa01b97f632b6ed033c862d22717404b27a04e")
