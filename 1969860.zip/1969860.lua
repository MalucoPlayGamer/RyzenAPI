-- Lua provided by RyzenAPI
-- Game: AppID 1969860

-- MAIN APPLICATION
addappid(1969860)
-- Game: addappid(1969860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969861, 1, "4eb126d9b1643dbd37adc8dcf55b264a494514f93f73843c5deac65be522c7d4")
