-- Lua provided by RyzenAPI
-- Game: Dolls Nest ArtWorks

-- MAIN APPLICATION
addappid(3309800)
-- Game: addappid(3309800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3309801, 1, "eb33a62af8d26bd13463a39431cadbc4db3aa54244a0bc91d01bb94feee60f49")
