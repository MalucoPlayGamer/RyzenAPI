-- Lua provided by RyzenAPI
-- Game: Superfly

-- MAIN APPLICATION
addappid(1413020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413021, 1, "0d6bc35a3066242f011963d1c2de69716c460faa59fe5249f1a1dca90e3fb8ef")
