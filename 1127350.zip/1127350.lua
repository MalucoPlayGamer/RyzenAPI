-- Lua provided by RyzenAPI
-- Game: addappid(1127350)

-- MAIN APPLICATION
addappid(1127350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127351, 1, "fa75db0477d75e0810c1ff01d6a8483150838c545da2ebe63b3e01153e90162b")
