-- Lua provided by RyzenAPI
-- Game: Lucent Bounds

-- MAIN APPLICATION
addappid(1732260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732261, 1, "403881448745150ca67e9a9b73df320df65a9f02c3817ddeb8e1c86657f966e6")

