-- Lua provided by RyzenAPI
-- Game: Whispering Lane Demo

-- MAIN APPLICATION
addappid(2754500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754501, 1, "95698932d130e6e04b93b73f0da5db004fc8126d8bccb5707637d20b29911c25")
