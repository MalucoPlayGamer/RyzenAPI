-- Lua provided by RyzenAPI
-- Game: Heart-Lung Machine

-- MAIN APPLICATION
addappid(3103480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3103481, 1, "dd3f6cc9c5288a2b3edcc3628192258ad00f6deb2ea92f5431a294e128eafa96")

