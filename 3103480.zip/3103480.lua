-- Lua provided by RyzenAPI
-- Game: Game: Heart-Lung Machine

-- MAIN APPLICATION
addappid(3103480)
-- Game: addappid(3103480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103481, 1, "dd3f6cc9c5288a2b3edcc3628192258ad00f6deb2ea92f5431a294e128eafa96")
