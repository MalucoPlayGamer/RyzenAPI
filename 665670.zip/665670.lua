-- Lua provided by RyzenAPI
-- Game: Enlysia

-- MAIN APPLICATION
addappid(665670)

-- MAIN APP DEPOTS / PACKAGES
addappid(665671,0,"cdfced31feacdc41ab6de604907ae4dede8fb0e4533ee720b4f40aa4f3f0d45e")

