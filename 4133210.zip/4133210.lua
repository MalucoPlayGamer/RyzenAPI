-- Lua provided by RyzenAPI
-- Game: Dung Ho!

-- MAIN APPLICATION
addappid(4133210)

-- MAIN APP DEPOTS / PACKAGES
addappid(4133211,0,"33122620bc8ccbabf2393e6bf28208c5dc58f7a754e9f261d611834b4a0c7bc2")

