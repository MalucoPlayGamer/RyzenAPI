-- Lua provided by SkyAPI 
-- Game: Blackout Rugby - World Cup Edition
addappid(1157960)
addappid(1157961, 1, "8ba13dcd94a82c162124aeef57ef832989de3cb1e51f1ad497bc549054701285")
addappid(1157962, 1, "219de41f413cb7ec44bc885adf970c1a4111808945f356c2d7ff4202f2f595cd")
addappid(1157963, 1, "4b6f63f79bb4e7fd43e97144dc235d2bc338b0719ca2b054b98eae2bc1f88a05")
