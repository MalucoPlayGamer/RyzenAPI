-- Lua provided by RyzenAPI
-- Game: Tilt Brush

-- MAIN APPLICATION
addappid(327140)
-- Game: addappid(327140)

-- MAIN APP DEPOTS / PACKAGES
addappid(327141, 1, "a2eb909a03d38645c950eb1619f1802917c6ab5853513ee3e9ffa46b65246497")
