-- Lua provided by RyzenAPI
-- Game: Gears of War: Reloaded

-- MAIN APPLICATION
addappid(2523720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523721, 1, "3e44ca039e0a56e928a0f15185ec4dd1a6122548cafccbeeb625c4af6b7fdaaa")

