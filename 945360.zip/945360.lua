-- Generated with Luie @ https://lua.tools/
-- 945360 - Among Us
-- Generated 2026-08-20 00:44:17 UTC
-- # Depots (Total/DLC/Shared): 2/0/1

-- Main AppID
addappid(945360, 1, "7f0bd1cc5c537189d88186c93ddc7bb29608c8cff6c3e67bb2bb8bd5bab8f752")

-- Main Depots
addappid(945361, 1, "cc84ab09a34dfa19f0cf86c30c05345294e788988c95455a7c42d024dc4f33a8") -- (windows)
setManifestid(945361, "1397756378225229500", 1115879348)

-- DLC's (no depot keys required)
addappid(946430) -- Among Us - Hamster Pet Bundle
addappid(971924) -- Among Us - Bedcrab Pet Bundle
addappid(971925) -- Among Us - Polus Map
addappid(971995) -- Among Us - Brainslug Pet Bundle
addappid(971996) -- Among Us - Mini Crewmate Bundle
addappid(971998) -- Among Us - MIRA HQ Map
addappid(971999) -- Among Us - Stickmin Pet Bundle
addappid(1579150) -- Among Us - Airship Skins

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
