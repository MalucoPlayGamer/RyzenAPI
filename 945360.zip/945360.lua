-- Lua provided by RyzenAPI
-- Game: AppID 945360

-- MAIN APPLICATION
addappid(945360)
-- Game: addappid(945360)

-- MAIN APP DEPOTS / PACKAGES
addappid(945361, 1, "cc84ab09a34dfa19f0cf86c30c05345294e788988c95455a7c42d024dc4f33a8")
