-- Lua provided by SkyAPI 
-- Game: AppID 599800
addappid(599800)
addappid(599801, 1, "898d0aa12d60a36d9d1e9495e152a4e60f0e2a850ae5b5426523c8e376cbbdf0")
