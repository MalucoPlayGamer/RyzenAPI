-- Lua provided by RyzenAPI
-- Game: Easy Magic

-- MAIN APPLICATION
addappid(599800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(599801, 1, "898d0aa12d60a36d9d1e9495e152a4e60f0e2a850ae5b5426523c8e376cbbdf0")
