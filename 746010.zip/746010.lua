-- Lua provided by RyzenAPI
-- Game: AppID 746010

-- MAIN APPLICATION
addappid(746010)
-- Game: addappid(746010)

-- MAIN APP DEPOTS / PACKAGES
addappid(746011, 1, "eef46ecaef78618ea2dc2d067203f8eb43089a1f84ce867ee28f4f606742a64c")
addappid(746012, 1, "54ce56e440250fbe564dec2232024c285e2a00f3aceb18135da22c3fc202e635")
