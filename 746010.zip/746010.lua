-- Lua provided by RyzenAPI
-- Game: AppID 746010

-- MAIN APPLICATION
addappid(746010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(746011, 1, "eef46ecaef78618ea2dc2d067203f8eb43089a1f84ce867ee28f4f606742a64c")
addappid(746012, 1, "54ce56e440250fbe564dec2232024c285e2a00f3aceb18135da22c3fc202e635")

