-- Lua provided by RyzenAPI 
-- Game: AppID 510550
addappid(510550)
addappid(510551, 1, "9da159e3c22bc4045b8a0128aa932a0bc57202615c7ff90252b902d03f45c907")
addappid(510552, 1, "187f31bd3dce231c6554dc79d1d7ba90fd6d30858d517bc97c2ed265375fd838")
