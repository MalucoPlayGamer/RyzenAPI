-- Lua provided by RyzenAPI
-- Game: 沃瑞尔：荒境

-- MAIN APPLICATION
addappid(2281300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281304,0,"52048112ec640ff42cc5716ad8747b782f262fd2c451cf51eb8d125532154281")
addappid(2281305,0,"f9fbb507f4a7d3fc32c2dad30d8107996c90f571cc8719d00ce421904a59a26d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
