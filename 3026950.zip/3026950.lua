-- Lua provided by RyzenAPI
-- Game: Game: AppID 3026950

-- MAIN APPLICATION
addappid(3026950)
-- Game: addappid(3026950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026951, 1, "7abfe564ca391f13201d86377ba903adb487456e71a7b2aa194c86fabd5af153")
