-- Lua provided by RyzenAPI
-- Game: addappid(2834390)

-- MAIN APPLICATION
addappid(2834390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834391, 1, "42e479481f458de70834e6fcce9f08102d64b8078623578ba7759e6eb9a546ce")
addappid(2834392, 1, "8fdd9fd82669f8d894bd28bcf8de900bf9bb1bd88b4c5bd6cf216c9bb4ee2c21")
