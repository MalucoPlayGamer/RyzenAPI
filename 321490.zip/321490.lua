-- Lua provided by RyzenAPI
-- Game: MotoGP™14 Compact

-- MAIN APPLICATION
addappid(321490)

-- MAIN APP DEPOTS / PACKAGES
addappid(321491, 1, "dd571a84a56bbc842bd54d812034fee6285feae54665e3fbf822ccefdefceb34")

