-- Lua provided by RyzenAPI
-- Game: addappid(2735540)

-- MAIN APPLICATION
addappid(2735540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735541, 1, "61a1340c0313463d21c5c4eba9ced15bfb2ae53db29e3b8f38c43be3461740d8")
