-- Lua provided by RyzenAPI 
-- Game: Home_0
addappid(3066510)
addappid(3066511, 1, "0489474a2279eb8e46f59078bf07dc423ae8a26c3881ee857cf3431892d2df3d")
