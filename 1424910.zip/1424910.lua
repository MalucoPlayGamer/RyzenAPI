-- Lua provided by RyzenAPI
-- Game: Game: KEO

-- MAIN APPLICATION
addappid(1424910)
-- Game: addappid(1424910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424911, 1, "c19399a834ea9af62eb8495681d2dbe099a17b530cbc70a4bb86f01eac3306dd")
