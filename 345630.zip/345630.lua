-- Lua provided by RyzenAPI
-- Game: The Eden of Grisaia

-- MAIN APPLICATION
addappid(345630)

-- MAIN APP DEPOTS / PACKAGES
addappid(345631, 1, "b4c3616bf13684a07646738aeb599491992a146ebfe8189892515afbe02d82f9")
