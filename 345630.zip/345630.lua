-- Lua provided by RyzenAPI
-- Game: The Eden of Grisaia

-- MAIN APPLICATION
addappid(345630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(345631, 1, "b4c3616bf13684a07646738aeb599491992a146ebfe8189892515afbe02d82f9")

