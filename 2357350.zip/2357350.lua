-- Lua provided by RyzenAPI
-- Game: Primal Fray

-- MAIN APPLICATION
addappid(2357350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357351,0,"be39865af13a6ae913065015e3f8dccf5c01e1790a5244986db3236fd978df80")

