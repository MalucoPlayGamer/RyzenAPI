-- Lua provided by RyzenAPI
-- Game: The Sun and Moon

-- MAIN APPLICATION
addappid(321560)

-- MAIN APP DEPOTS / PACKAGES
addappid(321561, 1, "dc88be00784d300fe7a25a54dac9dd8fbaf1f4f8308804712ba53aff51b860cd")
addappid(321562, 1, "913430b3eea9baa6de044bbc57ceeeccfb3672081f431a2c0b0789c55931286b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
