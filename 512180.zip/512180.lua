-- Lua provided by RyzenAPI
-- Game: Nightshade/百花百狼

-- MAIN APPLICATION
addappid(512180)
-- Game: addappid(512180)

-- MAIN APP DEPOTS / PACKAGES
addappid(512181, 1, "b21f0b8e7694f006627f5dade8f7a42f4914474328ca1f69c927b37fea546c46")
addappid(619630, 0, "46aef0afc8e24ec63cf51061d0b18afb6526156916553a9a55ae117e9a40f242")
addappid(751720, 0, "aec863980c092a37cfc8c5c1c6d8650776a84b676d9546ec546367d5cd21d480")
