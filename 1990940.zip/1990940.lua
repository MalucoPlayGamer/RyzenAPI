-- Lua provided by RyzenAPI
-- Game: The Impossible Game 2

-- MAIN APPLICATION
addappid(1990940)
-- Game: addappid(1990940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990944,0,"a162de881d04767a0656d293d795c16a3b41d02860b17ceb86834d23098d3cb7")
