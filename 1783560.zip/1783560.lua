-- Lua provided by RyzenAPI
-- Game: The Last Caretaker

-- MAIN APPLICATION
addappid(1783560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1783561, 1, "41cafd1c9367ffc962fab9d00cf8e6f16d2111b649a8161810a924b1cbf91fc2")

