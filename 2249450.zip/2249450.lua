-- Lua provided by RyzenAPI
-- Game: Butterfly's Poison; Blood Chains

-- MAIN APPLICATION
addappid(2249450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249452,0,"903cfc66f5f74ea31b7046be49dbf69ff39eec91fabc1680a100e340629a2ce3")

