-- Lua provided by RyzenAPI
-- Game: Port Royale 4 - Orginial Soundtrack

-- MAIN APPLICATION
addappid(1287300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287302,0,"11a042bec5155c909deda8d41518418aba8be1fc5949369c01665a708c71c4a6")
addappid(1287303,0,"526709622be8c606f2c80c7772a58b9c632d4e3c05241fe4a2127132af5cd50e")

