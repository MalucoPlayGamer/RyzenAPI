-- Lua provided by RyzenAPI
-- Game: Protective Clothing

-- MAIN APPLICATION
addappid(1248100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248101, 1, "ef012a569fd7534995822eb52e5915c4a459e5af88b736ae9d78b382876d6a5c")

