-- Lua provided by RyzenAPI
-- Game: Game: Flag Clicker

-- MAIN APPLICATION
addappid(2996990)
-- Game: addappid(2996990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996991, 1, "1c8e6975946ddbde1455937580cde66b08917829cc3088c261a4477b114a25d8")
