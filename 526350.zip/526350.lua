-- Lua provided by RyzenAPI
-- Game: addappid(526350)

-- MAIN APPLICATION
addappid(526350)

-- MAIN APP DEPOTS / PACKAGES
addappid(526351, 1, "69f7f6e6f8b11f7bb3305ef202423f9c31f34b94e4f71abdd6b6eb638151067e")
