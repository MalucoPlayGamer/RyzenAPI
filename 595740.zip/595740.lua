-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS: Spirit of Sanada

-- MAIN APPLICATION
addappid(595740)

-- MAIN APP DEPOTS / PACKAGES
addappid(595741, 1, "cd209dd095bd5ba3ac1c3660b8e58aea8322e5bdf5aeface442f2e2f7437f441")
addappid(595742, 1, "2d040859d83d045060456a61659caa2f3fb325139e14ee1ec4d50e038bb03ec7")
addappid(595750, 1, "9bbb647d3d36cbf671e33e7666a72bf6c2f0952fcb7ed48e7920d196caba1ebd")
addappid(595751, 1, "bd99efe8d637dc50a2546d1ed476f7636ede482f1cfaefa84f6d0e3fcf42dc97")
addappid(595752, 1, "67f84099514552d823e74a1819673da0d92aa050833c9d15b587edded7f71b6d")
addappid(595753, 1, "64265bd656680837c88051f62936c2e36591737450b914c5aa975c8029851cd8")
addappid(595754, 1, "b826e46fa0e8e59e8cde6dfa6a493b466aa846a918a6d1372fa57b36aab6ed45")
addappid(595755, 1, "b065028ee51a6e24594372d5d3f15c1e51f7dfaad4272eb066435b054d16f211")
addappid(595756, 1, "1f4bb8618362196d4f0d0ceff93562083441518e721161944bd35f7f14577eee")
addappid(595757, 1, "37e5c170af309d390b2254f50339bbaa559c06bf63d15ef9eaba79e6f0af8af7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
