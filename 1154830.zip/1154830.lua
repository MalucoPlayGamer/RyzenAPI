-- Lua provided by RyzenAPI
-- Game: AppID 1154830

-- MAIN APPLICATION
addappid(1154830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1154831, 1, "550c60dc43f05ffbaa4bc67d5918f72a0e1edc1fbae2b762294f0aef2decd078")

