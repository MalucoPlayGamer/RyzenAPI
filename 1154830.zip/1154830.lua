-- Lua provided by SkyAPI 
-- Game: AppID 1154830
addappid(1154830)
addappid(1154831, 1, "550c60dc43f05ffbaa4bc67d5918f72a0e1edc1fbae2b762294f0aef2decd078")
