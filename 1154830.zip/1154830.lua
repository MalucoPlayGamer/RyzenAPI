-- Lua provided by RyzenAPI
-- Game: addappid(1154830)

-- MAIN APPLICATION
addappid(1154830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154831, 1, "550c60dc43f05ffbaa4bc67d5918f72a0e1edc1fbae2b762294f0aef2decd078")
