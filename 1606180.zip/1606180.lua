-- Lua provided by RyzenAPI
-- Game: 下一站江湖Ⅱ

-- MAIN APPLICATION
addappid(1606180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606181, 1, "78085baa1a1489cac9f2593fc792421a3c773edf3317721f5b02ccb7b9c07898")
addappid(2905470, 0, "5e0e8e4e9b25bd36951858ffd7fe45086c92ca50d89481201f01b39e18aff304")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2998780)
addappid(3007440)
addappid(3099590)
addappid(3137140)
addappid(3169410)
addappid(3255940)
addappid(3323010)
addappid(3349590)
addappid(3386320)
addappid(3402520)
addappid(3422810)
addappid(3552810)
addappid(3627630)
addappid(3636310)
addappid(3759070)
addappid(3978160)
addappid(4110930)
addappid(4276540)
addappid(4330480)
addappid(4330490)
addappid(4587320)
addappid(4763140)
