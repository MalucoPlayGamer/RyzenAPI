-- Lua provided by RyzenAPI
-- Game: addappid(1644490)

-- MAIN APPLICATION
addappid(1644490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644491, 1, "7704b326c81e4d0332d7d9bec66ecba248d1ca6a3dd26dadec44592d91b2f631")
