-- Lua provided by RyzenAPI
-- Game: VITAL

-- MAIN APPLICATION
addappid(1155620)
-- Game: addappid(1155620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155621, 1, "534d3c41b23990f7e7f74fc97a6b92ef60b4d9b4b0b76c4a4e71f9b3b244569f")
