-- Lua provided by RyzenAPI
-- Game: Game: Dangerous Golf

-- MAIN APPLICATION
addappid(405500)
-- Game: addappid(405500)

-- MAIN APP DEPOTS / PACKAGES
addappid(405501, 1, "0c9999b0d5b4f423fbaf57b1ceea97065fbb88fab60bdf79a424a07c4962b5ff")
