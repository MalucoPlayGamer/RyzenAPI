-- Lua provided by RyzenAPI
-- Game: Game: DRAPLINE

-- MAIN APPLICATION
addappid(3103780)
-- Game: addappid(3103780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103781, 1, "ee66db4070f707592b52d8ef86c947876578214b396c1b9d17e569b8835eccdc")
addappid(3103782, 1, "893707c13da5f2ab44ba8b2e1dc842e38de09c2c0304f94e5c9a9a83a3cdd421")
