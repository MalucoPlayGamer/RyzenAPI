-- Lua provided by RyzenAPI
-- Game: Angel Detective Agency

-- MAIN APPLICATION
addappid(3770040)
-- Game: addappid(3770040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3770041, 1, "19a5376aab04b197eb4dcb7b1b5c467660ca78e9b00646bcdefe029c34bda36a")
