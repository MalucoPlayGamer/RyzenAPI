-- Lua provided by RyzenAPI 
-- Game: AppID 554810
addappid(554810)
addappid(554811, 1, "4f53f1d582059a8004f5d0e06a321ed306ded7c76dd6f17e614bff636c169da0")
addappid(653200, 0, "aca6d6d88ac5f9ce2238a1d7258317ed079c468fe33909e471a5691dfc576098")
