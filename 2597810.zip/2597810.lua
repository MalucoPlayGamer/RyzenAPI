-- Lua provided by RyzenAPI
-- Game: Afallon

-- MAIN APPLICATION
addappid(2597810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597811,0,"084e7d51d514f3a5b9d28a0fb64f6e7e0957abd73ec2a03691f3b331a14687ff")

