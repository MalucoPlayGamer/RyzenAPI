-- Lua provided by RyzenAPI
-- Game: MILF HUNTER

-- MAIN APPLICATION
addappid(1854970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854971, 1, "5cbcd1b144dd584cd11bf424dbfb0f7c0dbcf3ba262c2cdb88e2278b69384321")
