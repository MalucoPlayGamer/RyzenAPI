-- Lua provided by RyzenAPI
-- Game: 977720

-- MAIN APPLICATION
addappid(977720)
addappid(1230190)
-- Game: addappid(977720)

-- MAIN APP DEPOTS / PACKAGES
addappid(977721, 1, "dd0736bb8b095b2a17ac137d03ee3855b06a7fbe60f2ebb4a9b0f6cc0e3c65b5")
addappid(1127600, 0, "179add4605b52e0cbca81fed1e5f2819a5f7bc69bdf719afc7debd061542df96")
