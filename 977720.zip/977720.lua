-- Lua provided by RyzenAPI
-- Game: AppID 977720

-- MAIN APPLICATION
addappid(977720)
addappid(1230190)

-- MAIN APP DEPOTS / PACKAGES
addappid(977721, 1, "dd0736bb8b095b2a17ac137d03ee3855b06a7fbe60f2ebb4a9b0f6cc0e3c65b5")
addappid(1127600, 0, "179add4605b52e0cbca81fed1e5f2819a5f7bc69bdf719afc7debd061542df96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
