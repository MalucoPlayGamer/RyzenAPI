-- Lua provided by RyzenAPI
-- Game: FUSER™ - Naughty By Nature - "Hip Hop Hooray"

-- MAIN APPLICATION
addappid(1771593)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771593,0,"5adbedc2eff8ec6f60c67a6f7503eb603e05a7e1072a6a0cd52183268682fd84")
