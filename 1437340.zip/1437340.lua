-- Lua provided by RyzenAPI
-- Game: My Name is Mayo 2

-- MAIN APPLICATION
addappid(1437340)
-- Game: addappid(1437340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437341, 1, "48818826c067c3811ffb2d450a097cbccc7212d40a85ef3f393540615890706b")
