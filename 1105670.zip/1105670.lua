-- Lua provided by RyzenAPI
-- Game: The Last Spell

-- MAIN APPLICATION
addappid(1105670)
addappid(2795980)
addappid(3023570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105671, 1, "035313fc0f8c90ae012495b81235df4f48e57b13f7bdb737cce730b562337c56")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4191390)
