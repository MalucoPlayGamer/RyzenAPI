-- Lua provided by RyzenAPI 
-- Game: AppID 1543380
addappid(1543380)
addappid(1543381, 1, "b62803e1927027120cbe47775b88c7f56aa22cac2e78f1987e92248f07709289")
