-- Lua provided by RyzenAPI
-- Game: addappid(955580)

-- MAIN APPLICATION
addappid(955580)

-- MAIN APP DEPOTS / PACKAGES
addappid(955581, 1, "40898d99607719c0dd16cef3cd023bb2a39f211c2e783aab06194730313cd5a1")
