-- Lua provided by RyzenAPI 
-- Game: Desert Kingdoms 2 Demo
addappid(3073850)
addappid(3073851, 1, "5e1f09061d89b12fc12197e0d00a9e65808dad4445223827e30c4efc21d250a5")
