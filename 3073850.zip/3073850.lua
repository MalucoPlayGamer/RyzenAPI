-- Lua provided by RyzenAPI
-- Game: Desert Kingdoms 2 Demo

-- MAIN APPLICATION
addappid(3073850)
-- Game: addappid(3073850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073851, 1, "5e1f09061d89b12fc12197e0d00a9e65808dad4445223827e30c4efc21d250a5")
