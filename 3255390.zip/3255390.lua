-- Lua provided by RyzenAPI 
-- Game: The Stalked 2 Demo
addappid(3255390)
addappid(3255391, 1, "34232d31b212faa9698afc0e743a7bd864f505cd4139e47acd62f440013f1d49")
