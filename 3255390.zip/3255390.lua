-- Lua provided by RyzenAPI
-- Game: 3255390

-- MAIN APPLICATION
addappid(3255390)
-- Game: addappid(3255390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255391, 1, "34232d31b212faa9698afc0e743a7bd864f505cd4139e47acd62f440013f1d49")
