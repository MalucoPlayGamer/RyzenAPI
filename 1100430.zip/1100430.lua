-- Lua provided by RyzenAPI
-- Game: Spirit Hunter: NG

-- MAIN APPLICATION
addappid(1100430)
-- Game: addappid(1100430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100431, 1, "ff701395cbcfcfac7d19ca543ca10a865803b1ce7acfc5fe47c9ac261b948c53")
