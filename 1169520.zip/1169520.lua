-- Lua provided by RyzenAPI
-- Game: Guild of Ascension

-- MAIN APPLICATION
addappid(1169520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169521, 1, "ba864b220e25b19108da819983e2c3abf239780ca9be5cdd41efd1d433e6221f")
