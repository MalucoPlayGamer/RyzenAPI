-- Lua provided by RyzenAPI 
-- Game: Cyclic Warriors
addappid(2746000)
addappid(2746001, 1, "0bbf02ffc881ce23cf4052dc5e5ae8de5743d59cc6f62dd7c97be500f9f14fb6")
