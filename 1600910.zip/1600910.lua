-- Lua provided by RyzenAPI
-- Game: Demon's Mirror

-- MAIN APPLICATION
addappid(1600910)
-- Game: addappid(1600910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600911, 1, "c8d34f2ef4139893b624775a07c5eeced69a1067a423cf17a3b0bbfa22ffd3c0")
