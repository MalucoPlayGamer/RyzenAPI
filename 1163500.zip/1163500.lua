-- Lua provided by RyzenAPI
-- Game: Game: Warp Drive

-- MAIN APPLICATION
addappid(1163500)
-- Game: addappid(1163500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163501, 1, "e248e1b1135347aad85eae25d275c9a319729891994f8807c0319a32d32fb23b")
addappid(1163502, 1, "9e556ff90a3e16710036d2bc878f870df225952c3d0de1d552ca70315a94d73e")
