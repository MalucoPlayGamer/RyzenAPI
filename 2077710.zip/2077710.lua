-- Lua provided by RyzenAPI
-- Game: Die in the Dungeon Demo

-- MAIN APPLICATION
addappid(2077710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077711, 1, "1d3604589b813614f3d42915b5432b5632509068e3dc6a8b9f29b84646ac58e4")

