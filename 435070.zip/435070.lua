-- Lua provided by RyzenAPI
-- Game: 435070

-- MAIN APPLICATION
addappid(435070)
-- Game: addappid(435070)

-- MAIN APP DEPOTS / PACKAGES
addappid(435071, 1, "c1312ef1e697ab986d846d1ed4d1b5a7587fe02e83b0ad316c4d1f982b9e9092")
