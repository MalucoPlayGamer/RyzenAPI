-- Lua provided by RyzenAPI 
-- Game: Poly Bridge 2
addappid(1062160)
addappid(1062161, 1, "dbdee5dc6bbc788137c7e79c69cb426c6a29e384afd8d7bddc510b9fbdd0e2e8")
addappid(1062162, 1, "c11113d3df439909cf97ddfdfbe93cda9ef1131270627970ff27aefce06a5f07")
addappid(1062163, 1, "c15494d2cf3ac61e4c3cb47288ef2e57f7f2581ff5e197d7dcd3e4ba90b70d77")
addappid(1062164, 1, "18a955c1d539cc2e3187d0b9cc9dda2488f3cbbb7c8dda72a62b3e2ca6fabe5d")
