-- Lua provided by RyzenAPI 
-- Game: 198X
addappid(1086010)
addappid(1086011, 1, "814c6c53499c5f471844e3ca39a14d159641d4e11851791f39bce092c9cbb41f")
