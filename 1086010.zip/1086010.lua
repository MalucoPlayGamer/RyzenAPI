-- Lua provided by RyzenAPI
-- Game: Game: 198X

-- MAIN APPLICATION
addappid(1086010)
-- Game: addappid(1086010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086011, 1, "814c6c53499c5f471844e3ca39a14d159641d4e11851791f39bce092c9cbb41f")
