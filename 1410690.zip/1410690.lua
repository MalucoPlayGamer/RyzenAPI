-- Lua provided by RyzenAPI
-- Game: No Place for Bravery Prologue

-- MAIN APPLICATION
addappid(1410690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410691, 1, "9271630ccdc333f151b07c54ab9972b70754f0931022bfa60716bcd76a132db0")
