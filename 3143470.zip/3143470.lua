-- Lua provided by RyzenAPI
-- Game: 懒人也江湖

-- MAIN APPLICATION
addappid(3143470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143471, 1, "1b883719b205f24435d4c21f6e8afe5fd679a3e477748198708478af688bad4c")

