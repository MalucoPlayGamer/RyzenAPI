-- Lua provided by RyzenAPI
-- Game: Kuroinu Redux

-- MAIN APPLICATION
addappid(2348170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2348171, 1, "181ba457aea310b0124ce51495c0645435f185a424fbf121e9d0952de490b2a9")

