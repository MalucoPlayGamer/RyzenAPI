-- Lua provided by RyzenAPI
-- Game: Game: Wolfenstein II: The New Colossus Demo

-- MAIN APPLICATION
addappid(754730)
-- Game: addappid(754730)

-- MAIN APP DEPOTS / PACKAGES
addappid(754731, 1, "937ff738e5b11a6f8a45958cdf78f1b5294419fdc0b1af7a16d772f42ca37486")
