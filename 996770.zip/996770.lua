-- Lua provided by RyzenAPI
-- Game: Moving Out

-- MAIN APPLICATION
addappid(996770)
addappid(1249280)
addappid(1464740)

-- MAIN APP DEPOTS / PACKAGES
addappid(996771,0,"249bfc47285eca22bef9935db1c8a613f07db0a16fe05e0ff608510221013721")

