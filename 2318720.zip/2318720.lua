-- Lua provided by RyzenAPI
-- Game: Gunshots in the barren hills

-- MAIN APPLICATION
addappid(2318720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2318721, 1, "24ffb215ecb5f819e9f9d95c771dc3cf373f002ed229bb72a35bbd81fff72b39")

