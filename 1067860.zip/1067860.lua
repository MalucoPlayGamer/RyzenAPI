-- Lua provided by RyzenAPI
-- Game: NewCity

-- MAIN APPLICATION
addappid(1067860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1067861, 1, "e68e069c53903a530420e616457c24b0744c9aa02a8b18cf6e533986c797fb78")

