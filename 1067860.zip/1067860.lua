-- Lua provided by RyzenAPI
-- Game: Game: NewCity

-- MAIN APPLICATION
addappid(1067860)
-- Game: addappid(1067860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067861, 1, "e68e069c53903a530420e616457c24b0744c9aa02a8b18cf6e533986c797fb78")
