-- Lua provided by RyzenAPI
-- Game: 1889520

-- MAIN APPLICATION
addappid(1889520)
-- Game: addappid(1889520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889521, 1, "56381695f48fe4a61cf0859350acd38eeb5bf2d04e03cb7a06b23db0b7671441")
