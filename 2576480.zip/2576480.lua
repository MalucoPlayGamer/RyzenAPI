-- Lua provided by RyzenAPI
-- Game: Game: To The Mars

-- MAIN APPLICATION
addappid(2576480)
-- Game: addappid(2576480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576481, 1, "bb5a2bf4882f10524d56d8a6a4d5b6545929bcf96a57b94e925984adf8aa0a22")
