-- Lua provided by RyzenAPI
-- Game: Swarm Bunker: Lust Defense

-- MAIN APP DEPOTS / PACKAGES
addappid(4403260, 1, "0b4be040c08e56a350407ac6a1dce55e05edeb12d20bc13e6f3206b8571ea6cd") -- Swarm Bunker: Lust Defense
addappid(4403261, 1, "ee00577eff184928522dc551698320ae55fd9ea8602fb92615c60161845f5903") -- Depot 4403261

