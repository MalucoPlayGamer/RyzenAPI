-- 4403260's Lua and Manifest Created by Hubcap Manifest
-- Swarm Bunker: Lust Defense
-- Created: August 06, 2026 at 11:24:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4403260, 1, "0b4be040c08e56a350407ac6a1dce55e05edeb12d20bc13e6f3206b8571ea6cd") -- Swarm Bunker: Lust Defense
-- MAIN APP DEPOTS
addappid(4403261, 1, "ee00577eff184928522dc551698320ae55fd9ea8602fb92615c60161845f5903") -- Depot 4403261
setManifestid(4403261, "8669339020928587908", 3610497053)