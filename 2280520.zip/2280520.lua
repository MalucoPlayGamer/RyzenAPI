-- Lua provided by RyzenAPI
-- Game: AppID 2280520

-- MAIN APPLICATION
addappid(2280520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2280521, 1, "d167876e22b70d6addc56d5c661b8fc9aafb32b6247f5d51703dda07123c3af1")

