-- Lua provided by RyzenAPI
-- Game: 2280520

-- MAIN APPLICATION
addappid(2280520)
-- Game: addappid(2280520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280521, 1, "d167876e22b70d6addc56d5c661b8fc9aafb32b6247f5d51703dda07123c3af1")
