-- Lua provided by SkyAPI 
-- Game: AppID 1144800
addappid(1144800)
addappid(1144801, 1, "f3e386eb697d47f96f091e2a26b7db4f9b6277954eb71c6de5414f21f2276f64")
