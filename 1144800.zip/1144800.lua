-- Lua provided by RyzenAPI
-- Game: 1144800

-- MAIN APPLICATION
addappid(1144800)
-- Game: addappid(1144800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144801, 1, "f3e386eb697d47f96f091e2a26b7db4f9b6277954eb71c6de5414f21f2276f64")
