-- Lua provided by RyzenAPI
-- Game: AppID 1144800

-- MAIN APPLICATION
addappid(1144800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144801, 1, "f3e386eb697d47f96f091e2a26b7db4f9b6277954eb71c6de5414f21f2276f64")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
