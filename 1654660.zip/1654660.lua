-- Lua provided by SkyAPI 
-- Game: En Garde!
addappid(1654660)
addappid(1654661, 1, "5b40c516f1699847186ea0cf3558f3a94137c7b55f85808a3ed2d88dbe4850a8")
