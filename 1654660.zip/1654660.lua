-- Lua provided by RyzenAPI
-- Game: En Garde!

-- MAIN APPLICATION
addappid(1654660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654661, 1, "5b40c516f1699847186ea0cf3558f3a94137c7b55f85808a3ed2d88dbe4850a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
