-- Lua provided by RyzenAPI
-- Game: AppID 2114260

-- MAIN APPLICATION
addappid(2114260)
-- Game: addappid(2114260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114261, 1, "74e5ae02424a8b234fd8c287930195941a37cbdb43fcf6f057751bfbfb39649c")
