-- Lua provided by RyzenAPI
-- Game: Bit Orchard

-- MAIN APPLICATION
addappid(1573620)
-- Game: addappid(1573620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573621, 1, "25044257286c337b700b76da61885eb7e056ef6458f2c570aae9d2c5a79461e5")
