-- Lua provided by RyzenAPI
-- Game: Niche - a genetics survival game

-- MAIN APPLICATION
addappid(440650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(440651, 1, "173b902c8affd1385f5e1087a2ec9c5ea9737f0d1540c21344efc2cdb62135cc")
addappid(440652, 1, "74134a27bf39dc022e5240c34ba5de0d07ec253925ee1c24953f422183a4663a")
addappid(440653, 1, "c3f5f7b4802f418d71f564b413c79cedd87cc9adce6203da8e432a8f15dac0fc")
addappid(712900, 0, "7c75d34250e255708b38d182519d0798068b4d8fe113735eb16341fcb9f53dbf")
