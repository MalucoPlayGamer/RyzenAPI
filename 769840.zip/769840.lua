-- Lua provided by RyzenAPI
-- Game: Muddledash

-- MAIN APPLICATION
addappid(769840)

-- MAIN APP DEPOTS / PACKAGES
addappid(769841, 1, "c53524a81adfd48a1be433603b517e8b94d50fef329d0c13db43dde4c3940c60")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(852030)
