-- Lua provided by RyzenAPI
-- Game: Zagan Must Be Rescued

-- MAIN APPLICATION
addappid(1295030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295031, 1, "67711c3b95375226655ef3e7e5de123d334d2a1018b64b9589224662dbeb955f")

