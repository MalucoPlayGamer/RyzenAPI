-- Lua provided by RyzenAPI
-- Game: Zagan Must Be Rescued

-- MAIN APPLICATION
addappid(1295030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295031, 1, "67711c3b95375226655ef3e7e5de123d334d2a1018b64b9589224662dbeb955f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
