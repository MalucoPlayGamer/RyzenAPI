-- Lua provided by RyzenAPI 
-- Game: AppID 2570840
addappid(2570840)
addappid(2570841, 1, "c58a8ddca3eb7ed699ea5da891b71c9826ead6d5f9ddf2ffe4adb5b01d403057")
