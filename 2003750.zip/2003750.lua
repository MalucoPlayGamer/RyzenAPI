-- Lua provided by RyzenAPI
-- Game: Blacken Slash: Prologue

-- MAIN APPLICATION
addappid(2003750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003752,0,"5b77467b5b99adeecabaf51c7e1b0dd1ba0fd91f49eb7b00c0f825e9ad960459")
addappid(2003753,0,"e18e84b80410a5c770160cdd37ab6c6c62e5a0a81ccb6c59569f893b3aa15d89")
addappid(2003754,0,"7c4048a24a037e91d7d3b1ac4690bda0f436b50976325d0093126eb8fc3abd74")

