-- Lua provided by RyzenAPI
-- Game: Game: Farm Keeper

-- MAIN APPLICATION
addappid(2458940)
-- Game: addappid(2458940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458941, 1, "c366292b6b9f76c2b70553e224d414f5c4ab8d672e03f86e45030a668924999b")
