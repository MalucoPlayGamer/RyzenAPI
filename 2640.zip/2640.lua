-- Lua provided by RyzenAPI 
-- Game: Call of Duty: United Offensive
addappid(2640)
addappid(2641, 1, "36f1541ab1d713a20a676d2a797a0827e02e423ab89565e65791608bc2222da4")
addappid(2642, 1, "04bf9fd8c34331f7f1e3270ce1f5e39aeae22532f11b1d606d316d8380f26472")
addappid(2643, 1, "b09d9e478376212e6d088091efeb0247b6333bec6ffa2704639607c1444773f4")
addappid(2644, 1, "61f34a50c83de39dba6b02810d0d3a8a562758d56c45fdee47e50db543dfbb3c")
