-- Lua provided by RyzenAPI
-- Game: Game: Iron Crypticle

-- MAIN APPLICATION
addappid(548680)
-- Game: addappid(548680)

-- MAIN APP DEPOTS / PACKAGES
addappid(548681, 1, "b55bbcfd61fb8d367a752b8e751d76c1471182cc81e7463a9faa9399986c77ce")
