-- Lua provided by RyzenAPI
-- Game: Iron Crypticle

-- MAIN APPLICATION
addappid(548680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(548681, 1, "b55bbcfd61fb8d367a752b8e751d76c1471182cc81e7463a9faa9399986c77ce")

