-- Lua provided by RyzenAPI
-- Game: 2916460

-- MAIN APPLICATION
addappid(2916460)
-- Game: addappid(2916460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916461, 1, "8faac456ca317a4a88f79c0a4d2f864bf02b63938677ec1be445bb3e3cc6a421")
addappid(2916462, 1, "aef4b7e5be6b63e9dfdadd6c770904ba199312c7b7ef0a0210e19c3711f2cb21")
