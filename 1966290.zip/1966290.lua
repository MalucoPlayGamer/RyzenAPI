-- Lua provided by RyzenAPI
-- Game: Sandwalkers: The Fourteenth Caravan

-- MAIN APPLICATION
addappid(1966290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966291, 1, "c36cbfc926f2032aeab9b9b267e2155faf7b66d85794ca01903e4e2b108f2a65")

