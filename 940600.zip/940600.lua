-- Lua provided by RyzenAPI
-- Game: AppID 940600

-- MAIN APPLICATION
addappid(940600)

-- MAIN APP DEPOTS / PACKAGES
addappid(940601, 1, "2d89608b8a3bb8d1d8d504844bad0de7bf7482f7e37a6772e957b8d3d740f9f5")

