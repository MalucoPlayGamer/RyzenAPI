-- Lua provided by RyzenAPI
-- Game: FLATHEAD

-- MAIN APPLICATION
addappid(2840480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2840481, 1, "6179b8bc5b13f8586375cfdd8d642b3d6ed4a7954435cd1192bee1e8716a0329")

