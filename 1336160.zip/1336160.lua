-- Lua provided by RyzenAPI
-- Game: Game: Chupa Chupa VR

-- MAIN APPLICATION
addappid(1336160)
-- Game: addappid(1336160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336161, 1, "911e0f4233d5a26938501434c3f536d9845b5207115af9559a89cbf691593538")
