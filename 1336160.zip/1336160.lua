-- Lua provided by RyzenAPI
-- Game: Chupa Chupa VR

-- MAIN APPLICATION
addappid(1336160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336161, 1, "911e0f4233d5a26938501434c3f536d9845b5207115af9559a89cbf691593538")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1373150)
addappid(1409380)
