-- Lua provided by RyzenAPI
-- Game: AppID 644610

-- MAIN APPLICATION
addappid(644610)
-- Game: addappid(644610)

-- MAIN APP DEPOTS / PACKAGES
addappid(644611, 1, "2c579e7bb9d99f5858130adff384bca975d29a24d284a8063a836b7a6bb62d21")
