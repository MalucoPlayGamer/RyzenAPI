-- Lua provided by RyzenAPI
-- Game: We Are Counting

-- MAIN APP DEPOTS / PACKAGES
addappid(4233450, 1, "c4a2124b799ce8a0524a8d50b7d3f696970d803c3cd640d4932fc444e7b1e6f6") -- We Are Counting
addappid(4233451, 1, "78a2ab4e7364cfa2510ac2aad3dc65ea16c9bb0be77942cb9507b8c2fbdd24d0") -- Depot 4233451

