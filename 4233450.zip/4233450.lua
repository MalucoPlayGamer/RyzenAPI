-- 4233450's Lua and Manifest Created by Hubcap Manifest
-- We Are Counting
-- Created: August 14, 2026 at 06:09:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4233450, 1, "c4a2124b799ce8a0524a8d50b7d3f696970d803c3cd640d4932fc444e7b1e6f6") -- We Are Counting
-- MAIN APP DEPOTS
addappid(4233451, 1, "78a2ab4e7364cfa2510ac2aad3dc65ea16c9bb0be77942cb9507b8c2fbdd24d0") -- Depot 4233451
setManifestid(4233451, "2755075439115353750", 364288489)