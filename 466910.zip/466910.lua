-- Lua provided by RyzenAPI 
-- Game: AppID 466910
addappid(466910)
addappid(466911, 1, "3856a917d12356aebfef587965a126a3e373352ebe70830cfcd064ed239c5d47")
addappid(466912, 1, "82188643bbcf1a81e974ca9e1ba315a0c686bf6c1bbc216b957a713e67fd312b")
