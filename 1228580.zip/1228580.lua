-- Lua provided by RyzenAPI
-- Game: Trine 2 Soundtrack

-- MAIN APPLICATION
addappid(1228580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228581, 1, "57dca842a628d06175c5d06e691d3cc58b6abd70c3cee3d94e1f9fa0053d30de")
addappid(1228582, 1, "16495dc8b563820bb25d5aa76a7fa63194c8c89c12982950850f52e75da8d04f")

