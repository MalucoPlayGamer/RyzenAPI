-- Lua provided by RyzenAPI
-- Game: 2229650

-- MAIN APPLICATION
addappid(2229650)
-- Game: addappid(2229650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229651, 1, "a1fac5c0a4c031c46c7d80a740af1de6eece31bda1a6ae7d2b3321e02a28f385")
