-- Lua provided by RyzenAPI
-- Game: Game: Firelight Fantasy: Force Energy

-- MAIN APPLICATION
addappid(1619330)
-- Game: addappid(1619330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619331, 1, "9c55a3cf68c47fef19bdc47d094ed9f202979141f90f0864bfd30b5455012c92")
