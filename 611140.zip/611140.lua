-- Lua provided by RyzenAPI
-- Game: addappid(611140)

-- MAIN APPLICATION
addappid(611140)

-- MAIN APP DEPOTS / PACKAGES
addappid(611141, 1, "62f744182169e4b1c946d78bc8ebd2c6cc04a3d4fb5a4cdbb9defbf6ccb23718")
addappid(611142, 1, "ca06360cdb9f70d45932d23fded23f41c1d1940f0977d0af495ed931f0a2e901")
addappid(611143, 1, "7b3d782567504d544ea5b981fcec23eb154cf25da4ee20951fd97460731aa67c")
addappid(642640, 0, "e8d292a380404fdc1a5b8ea5c84829cf4fc58e7a4fb4050eac29485fe22e32e5")
