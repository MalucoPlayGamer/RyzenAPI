-- Lua provided by RyzenAPI
-- Game: AppID 624950

-- MAIN APPLICATION
addappid(624950)

-- MAIN APP DEPOTS / PACKAGES
addappid(624951, 1, "90abacd1aabb53ef885fbad8c6be68f6a1b9cc366dd412f1516a296cb373e10e")
