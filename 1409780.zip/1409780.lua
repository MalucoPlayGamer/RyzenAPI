-- Lua provided by RyzenAPI
-- Game: AppID 1409780

-- MAIN APPLICATION
addappid(1409780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409781, 1, "93d3c1d68311bcdf8af57df31c4d7d3caa4c9ce41fdf8ee04edebd67fc03cfef")

