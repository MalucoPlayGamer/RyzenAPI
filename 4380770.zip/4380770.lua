-- Lua provided by RyzenAPI
-- Game: Balls & Gamble

-- MAIN APPLICATION
addappid(4380770) -- Balls & Gamble

-- MAIN APP DEPOTS / PACKAGES
addappid(4380771, 1, "3e87b31c0777399ee241dbfc349c770a1bcf91b2acac28298b5ee7e44f91e88a") -- Depot 4380771

