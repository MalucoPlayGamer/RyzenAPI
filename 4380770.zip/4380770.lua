-- 4380770's Lua and Manifest Created by Hubcap Manifest
-- Balls & Gamble
-- Created: August 17, 2026 at 14:11:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4380770) -- Balls & Gamble
-- MAIN APP DEPOTS
addappid(4380771, 1, "3e87b31c0777399ee241dbfc349c770a1bcf91b2acac28298b5ee7e44f91e88a") -- Depot 4380771
setManifestid(4380771, "7739097784280782731", 336935202)