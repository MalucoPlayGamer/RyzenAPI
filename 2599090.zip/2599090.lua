-- Lua provided by SkyAPI 
-- Game: AppID 2599090
addappid(2599090)
addappid(2599091, 1, "858a5da73a03c0a19a72d6194aeb8c4fe090673cfc1dde37c0cc86e04244fc84")
