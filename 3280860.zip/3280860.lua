-- Lua provided by RyzenAPI
-- Game: Game: Duel to The Holes

-- MAIN APPLICATION
addappid(3280860)
-- Game: addappid(3280860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3280861, 1, "a453e5baac92c11f4871e51fa0071b1317ecb2274a31e0b1cdcdbf965cbd5fbc")
addappid(3280862, 1, "c4047c4f357e192d441d5eaec324a8c8bb9f0e052034b20ae87c0cf160fe249b")
