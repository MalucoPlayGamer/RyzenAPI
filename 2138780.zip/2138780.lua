-- Lua provided by RyzenAPI
-- Game: CashGrab

-- MAIN APPLICATION
addappid(2138780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138781, 1, "54ce6481e3178c5d940deef81aa4ba626ada7f5ebb9fab0c42f63724efb24db3")

