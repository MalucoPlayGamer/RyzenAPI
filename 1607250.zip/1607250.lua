-- Lua provided by RyzenAPI
-- Game: 1607250

-- MAIN APPLICATION
addappid(1607250)
addappid(2510870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607251,0,"cad59bdcdf19f13ebd39d2b57182945eb2e3d1e8f2dc316ddc06604db6785581")

