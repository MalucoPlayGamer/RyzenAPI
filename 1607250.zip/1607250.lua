-- Lua provided by RyzenAPI
-- Game: MY HERO ULTRA RUMBLE

-- MAIN APPLICATION
addappid(1607250)
-- Game: addappid(1607250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607251, 1, "cad59bdcdf19f13ebd39d2b57182945eb2e3d1e8f2dc316ddc06604db6785581")
