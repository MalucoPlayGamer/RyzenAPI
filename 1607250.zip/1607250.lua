-- Lua provided by SkyAPI 
-- Game: MY HERO ULTRA RUMBLE
addappid(1607250)
addappid(1607251, 1, "cad59bdcdf19f13ebd39d2b57182945eb2e3d1e8f2dc316ddc06604db6785581")
