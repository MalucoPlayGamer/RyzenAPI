-- Lua provided by RyzenAPI
-- Game: Game: AppID 2598420

-- MAIN APPLICATION
addappid(2598420)
-- Game: addappid(2598420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598421, 1, "ebfbed60c389a158ad87233e5e45d861fc282127df4211ac37c83c04c72c90f7")
addappid(2598422, 1, "23f4e1ab332933bc588c84527522f6c1b1d0451d14dcde93dbf08de82b81142f")
