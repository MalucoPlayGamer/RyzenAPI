-- Lua provided by RyzenAPI 
-- Game: Dragon Awaken
addappid(824300)
addappid(824301, 1, "55253336d90c4803fc85b67bd4a065fb40c083744a490d3d159a8f5f50944b1e")
addappid(824302, 1, "c41b565cab12909e83072ba479df4b15a891c352ac11e55cebd8c30a3d5cf361")
addappid(824303, 1, "e9dfcce0584b2fbc496bd41990b846bb6a3fba1627087714f22b69edfe6413b8")
