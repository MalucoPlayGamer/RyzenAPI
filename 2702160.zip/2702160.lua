-- Lua provided by RyzenAPI
-- Game: Maitetsu:Last Run!! - Rail Romanesque origin

-- MAIN APPLICATION
addappid(2702160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702160,0,"4a44e2e6217705a86e1baedf92ee3755843a73c018c47bc05a00190d4b535f18")

