-- Lua provided by RyzenAPI
-- Game: Game: life is not auto

-- MAIN APPLICATION
addappid(3065720)
-- Game: addappid(3065720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3065721, 1, "06f2213285900ea984a0d737482f398144ed7c16a59a88fe1209a86f4b8d42fc")
