-- Lua provided by RyzenAPI
-- Game: Muscles And Bullets

-- MAIN APPLICATION
addappid(1005920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005921, 1, "0d5c0019f84c2b9dc402fcfeee70949a5edd80df5311a0e3979abbc246501af7")

