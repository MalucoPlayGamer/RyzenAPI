-- Lua provided by RyzenAPI
-- Game: Muscles And Bullets

-- MAIN APPLICATION
addappid(1005920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005921, 1, "0d5c0019f84c2b9dc402fcfeee70949a5edd80df5311a0e3979abbc246501af7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
