-- Lua provided by RyzenAPI
-- Game: 690040

-- MAIN APPLICATION
addappid(690040)
-- Game: addappid(690040)

-- MAIN APP DEPOTS / PACKAGES
addappid(690041, 1, "d7b6546532d440e08e3070be7a2f40cc462135f7a99604b2b8f4bac641ec5819")
addappid(690042, 1, "e1b7d8c628e8b58b309617e4b36023dd4c5ed0593bdec2db83a7077db8aca9e4")
addappid(690043, 1, "9fd622d1ccbd15efa14c398acb544facdae92d714fe48c707ebbffe217073c05")
