-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2815140)
-- Game: addappid(2815140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815142,0,"63bdb59e8260917b9d8a44024980d054162bfd42cd0f0e1f558f0eddff7a0fd6")
