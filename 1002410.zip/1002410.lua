-- Lua provided by RyzenAPI
-- Game: The Five Cores Remastered

-- MAIN APPLICATION
addappid(1002410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1002413,0,"700e258a6c22a1337b66897bb39b325649c38e900d069118d5cf9c4bd6bddfd2")
addappid(1002414,0,"55d8e995140a1fe3d5a328ac3b28c40e2755e7afbf694916c70aa36e46050f34")
addappid(1002415,0,"b0d38d6c56a16db1d18769576c775b47a6b0b3bab07e1b40631b5a8b623b0cc5")

