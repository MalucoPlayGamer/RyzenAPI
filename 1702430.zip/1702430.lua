-- Lua provided by SkyAPI 
-- Game: Vlad Circus: Descend Into Madness
addappid(1702430)
addappid(1702431, 1, "a1e3fff9173b9291a767e4d37d9b03f17f071d5378bb682a2c15e508091f5390")
