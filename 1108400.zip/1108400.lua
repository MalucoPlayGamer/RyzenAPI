-- Lua provided by RyzenAPI
-- Game: addappid(1108400)

-- MAIN APPLICATION
addappid(1108400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108401, 1, "1e2faa708a2c1a25c133c367b1da72517e256d020d03e695b3e0dba6f8d40db6")
