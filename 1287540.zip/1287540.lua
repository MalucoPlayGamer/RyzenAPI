-- Lua provided by RyzenAPI
-- Game: 1287540

-- MAIN APPLICATION
addappid(1287540)
-- Game: addappid(1287540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287541, 1, "349f215bcc42a21c113013d88ecf4d4dcd11e194bd5a802e157231a96c4356f3")
