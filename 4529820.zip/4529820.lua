-- Lua provided by RyzenAPI
-- Game: Wobble Wobble

-- MAIN APPLICATION
addappid(4529820) -- Wobble Wobble

-- MAIN APP DEPOTS / PACKAGES
addappid(4529821, 1, "7913d04642f28a0be2ade5f32543f27a619b6067a7e5c91556c0fcecac75b406") -- Depot 4529821

