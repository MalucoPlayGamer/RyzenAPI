-- Lua provided by RyzenAPI
-- Game: Sakura Alien 2

-- MAIN APPLICATION
addappid(2021690)
-- Game: addappid(2021690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021691, 1, "e329997a8d872fbe3894bd719b598446b24e8bdf78a27c0b4f3c108d2ad7a704")
