-- 4242040's Lua and Manifest Created by Hubcap Manifest
-- Koikata: How Our Love Grows
-- Created: August 25, 2026 at 07:20:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4242040) -- Koikata: How Our Love Grows
-- MAIN APP DEPOTS
addappid(4242041, 1, "579b7daa46088da50413d235c5af3880faa57d6bbf13c934fbe9a7aed9f028ef") -- Depot 4242041
setManifestid(4242041, "8381617947449002913", 2667197152)