-- Lua provided by RyzenAPI
-- Game: Koikata: How Our Love Grows

-- MAIN APPLICATION
addappid(4242040) -- Koikata: How Our Love Grows

-- MAIN APP DEPOTS / PACKAGES
addappid(4242041, 1, "579b7daa46088da50413d235c5af3880faa57d6bbf13c934fbe9a7aed9f028ef") -- Depot 4242041

