-- Lua provided by RyzenAPI
-- Game: Float Night

-- MAIN APPLICATION
addappid(958280)

-- MAIN APP DEPOTS / PACKAGES
addappid(958281, 1, "a490fd021cbc286b525c8c3815825f90447c9cc488a8f8e413518fe9590edcf2")
