-- Lua provided by RyzenAPI
-- Game: Game: AppID 905150

-- MAIN APPLICATION
addappid(905150)
-- Game: addappid(905150)

-- MAIN APP DEPOTS / PACKAGES
addappid(905151, 1, "88fdd225bd2c905ee750dd0e43268de5f356b7acf33c2a2c9a6b304595e49558")
