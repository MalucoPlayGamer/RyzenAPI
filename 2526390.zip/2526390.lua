-- Lua provided by RyzenAPI
-- Game: Police Car Escape Simulator

-- MAIN APPLICATION
addappid(2526390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526391, 1, "ef12d6e4412cb54b7576821941b69b025eaa78ca40326b7a1ccefe3fdf6e4858")

