-- Lua provided by SkyAPI 
-- Game: Police Car Escape Simulator
addappid(2526390)
addappid(2526391, 1, "ef12d6e4412cb54b7576821941b69b025eaa78ca40326b7a1ccefe3fdf6e4858")
