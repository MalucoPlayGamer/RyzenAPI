-- Lua provided by RyzenAPI
-- Game: Haunted

-- MAIN APPLICATION
addappid(260550)

-- MAIN APP DEPOTS / PACKAGES
addappid(260551, 1, "fab926ab0f62f732a5120904eccdeaddd5d443783981a26db495f5ca2de7b652")
