-- Lua provided by RyzenAPI
-- Game: 2173730

-- MAIN APPLICATION
addappid(2173730)
-- Game: addappid(2173730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173731, 1, "0bc382740b857f237c4d9cbbf2341905f1ffcf45167d724eca3aef411d72fd30")
