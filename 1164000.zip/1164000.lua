-- Lua provided by RyzenAPI
-- Game: 六阶谜题

-- MAIN APPLICATION
addappid(1164000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164001, 1, "f3ed3d24460fa8736a81daadc543b6a0caebaf607ecd459d4acd0a7875cf8627")

