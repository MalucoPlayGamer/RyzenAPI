-- Lua provided by RyzenAPI
-- Game: Game: AppID 18510

-- MAIN APPLICATION
addappid(18510)
-- Game: addappid(18510)

-- MAIN APP DEPOTS / PACKAGES
addappid(18511, 1, "848449c23d636d154b80821f7335a30a0c4dbb0fc855c31757f501996d95502f")
