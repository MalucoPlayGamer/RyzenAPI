-- Lua provided by RyzenAPI
-- Game: Echo Point Nova

-- MAIN APPLICATION
addappid(1836730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836731, 1, "3cb8d34f2b9a803179612fabdc6ea345bcbc6486081c8620e8263944ba2d7824")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
