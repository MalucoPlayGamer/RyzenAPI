-- Lua provided by RyzenAPI
-- Game: Game: Echo Point Nova

-- MAIN APPLICATION
addappid(1836730)
-- Game: addappid(1836730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836731, 1, "3cb8d34f2b9a803179612fabdc6ea345bcbc6486081c8620e8263944ba2d7824")
