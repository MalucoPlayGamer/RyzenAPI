-- Lua provided by SkyAPI 
-- Game: Full Service
addappid(1223810)
addappid(1223811, 1, "220b5304ef5b8925cdd76689b738ae22e7beea9ad05c0377e751df627befee90")
addappid(1402640, 0, "f211d24d98c2a8d967bff181c471dc6e7af11be723f816d0c2125ad41d91abaa")
