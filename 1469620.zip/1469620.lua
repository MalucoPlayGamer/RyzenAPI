-- Lua provided by RyzenAPI
-- Game: Game: Epic Battle Fantasy Collection

-- MAIN APPLICATION
addappid(1469620)
-- Game: addappid(1469620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469621, 1, "dcfe77533bfd79030422a00f95dc80e47b90b105cee8b9933c27a321a2d5d683")
