-- Lua provided by RyzenAPI
-- Game: Trump Cake Mania

-- MAIN APPLICATION
addappid(3397580)
-- Game: addappid(3397580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397581, 1, "a5dc6bb9c371b10e67b6aa6275f3c5813f31b1d7030a86ecaec96143386a917e")
