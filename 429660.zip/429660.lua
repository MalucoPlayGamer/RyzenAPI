-- Lua provided by RyzenAPI
-- Game: AppID 429660

-- MAIN APPLICATION
addappid(429660)
addappid(525430)
addappid(528050)
addappid(528051)
addappid(528052)
addappid(528053)
addappid(528055)
addappid(528056)
addappid(528057)
addappid(528058)
addappid(565210)
addappid(565220)
addappid(565230)
addappid(565240)
addappid(565250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(429661, 1, "3e52800c7b5a10bac4878feb162b72dd4e5ec4beef6e6ad8d4b655e2c4745cdd")
addappid(429662, 1, "1f6d73e22df7e5dac711b82814a468d8449de542ad120cb8d421665c01169da9")
addappid(525431, 0, "457a2c7c346be27f567dd706788c87b207707550820c344a40b784f4fe1f8964")
addappid(525432, 0, "ec8e6e42ad814dde77de73cd1f53a65f5f4509eeb0d6ad8677f0f1ee48c6f4a8")
addappid(525433, 0, "dcda584b7fe0b2afaff8c4d8cd84adfb4f337a547b4982f7bb15fab89b9537cf")
addappid(525434, 0, "e763a7ffce3df5a28c82c797295090441bc5b6c76bf12eeb8e8298f5f1469381")
addappid(525436, 0, "857ef4108c5073f43da39364b64d3b2077f4c678ca2c39d39ca7ea5f27f94a38")
addappid(525437, 0, "dacad30c0b0755d163fb6015561a25202d2a43eb6de5b00d47ce5120523c50c0")
addappid(525438, 0, "2c0e75ac265e0eb53d6029ddcce4ee149e74b87be8eafd629a7af6dd61508d1e")
addappid(525439, 0, "0efad71312b804ec645d81fe77e41a443fe95f1394651ec7aa3b8bb724a5ae1b")

