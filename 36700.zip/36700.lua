-- Lua provided by RyzenAPI
-- Game: The Scourge Project: Episode 1 and 2

-- MAIN APPLICATION
addappid(36700)

-- MAIN APP DEPOTS / PACKAGES
addappid(36701, 1, "3df4e3a47d6902af8efa65d9c0caff7514a5e1a611ad9a5120fec05dae77a1b8")
addappid(36702, 1, "68347875858b1e1b41775ac1d7f78f175f9153dae66c91e10f1a8346298ab5cf")
addappid(36703, 1, "00903bc5d5979b59962559ed7f13ac5194c0aa5c2e57d804792eaeeef6e98cd2")
addappid(36704, 1, "650e3fde4642fbd1f4323c66267d0f262bbcd5718b5c0f499c23f9d46b2039a7")
addappid(36705, 1, "ad12fbcf49f5fd3613c7d2bda314caad6f52f6dce626ee41ddee818d065fcab4")
addappid(36706, 1, "b762e5600f584b7572ca1f3667d65645ef6025472f3ad9514e382a4135a3800e")
