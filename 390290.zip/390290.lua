-- Lua provided by RyzenAPI
-- Game: Game: Bulb Boy

-- MAIN APPLICATION
addappid(390290)
-- Game: addappid(390290)

-- MAIN APP DEPOTS / PACKAGES
addappid(390291, 1, "269aa609b6e5be73834b2b03ef666f3fb1b9622cf0591e1bbde0066e27713a59")
addappid(390292, 1, "e4d51b308206bcb633e6264794ab0d4ef46730eb40a75eb34fc51ca4f6b74faa")
addappid(390293, 1, "12317e119a0f7589bfbf6f6bdd9356efa1e19b463f4ba86730af1239eaf33ded")
addappid(497010, 0, "e0d5fdb5d29de797b4019586172036a51f570eb9b3a3276e64c3a1f453b2f1f9")
