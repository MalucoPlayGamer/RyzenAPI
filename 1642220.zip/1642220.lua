-- Lua provided by RyzenAPI
-- Game: FIND ALL

-- MAIN APPLICATION
addappid(1642220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642221, 1, "1c7b5f3060488564b6a652693322311baa5c2a9bc11b64ec5eab7fa06c0db5db")
addappid(1642222, 1, "78a16809719b31b6ebb0693197554b4e5ab5135b430e4070b75628d2a71bf81e")
addappid(1642223, 1, "f874f36bdaaa184695b9e44b49f5ff0bb6938ed7ab460621fbcc7223b71c9543")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3772280)
addappid(3772290)
