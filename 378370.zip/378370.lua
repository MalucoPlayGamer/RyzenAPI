-- Lua provided by RyzenAPI
-- Game: Nomad

-- MAIN APPLICATION
addappid(378370)

-- MAIN APP DEPOTS / PACKAGES
addappid(378371, 1, "081e6f5fd10b3c598c5bd8b9ec1e21c9d8863d6749e0247d4953ab962e45e9af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(431430)
addappid(508800)
