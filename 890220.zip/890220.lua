-- Lua provided by RyzenAPI
-- Game: Math Fun

-- MAIN APPLICATION
addappid(890220)

-- MAIN APP DEPOTS / PACKAGES
addappid(890221, 1, "2d34abf5b8d06c2fb7563b66e5c4dabdf2c511f8b5d6402430d662f27353c1fc")

