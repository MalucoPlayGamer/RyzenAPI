-- Lua provided by RyzenAPI
-- Game: Arcanum: Of Steamworks and Magick Obscura

-- MAIN APPLICATION
addappid(500810)

-- MAIN APP DEPOTS / PACKAGES
addappid(500811, 1, "0a2b8ac55c4306db72b735a9c023da1e3be97d09d1d4d36bab8d1bb92b7daaa4")
