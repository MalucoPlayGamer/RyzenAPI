-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Modern + Midnight City

-- MAIN APPLICATION
addappid(1767100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767100,0,"93f1205ee6ce0bed0c02e2a8537c692eb6440934bc2e52af43197a030d30ab74")

