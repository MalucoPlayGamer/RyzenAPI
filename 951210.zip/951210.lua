-- Lua provided by RyzenAPI
-- Game: Game: AppID 951210

-- MAIN APPLICATION
addappid(951210)
-- Game: addappid(951210)

-- MAIN APP DEPOTS / PACKAGES
addappid(951211, 1, "d8c48e84f2473d435e33c00b557976674699a20aa59fbfa654b7492f1102fedd")
