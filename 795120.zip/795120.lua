-- Lua provided by RyzenAPI
-- Game: To The Capital 2

-- MAIN APPLICATION
addappid(795120)

-- MAIN APP DEPOTS / PACKAGES
addappid(795123,0,"c12ba775ed4121f46e76246e785e1720352f759d79cefa839c440485afb9771e")
addappid(795124,0,"e8656fb27a36952e3c1ec8629f992d6edeec0c2a59775dbecb1fa9f002d0917e")

