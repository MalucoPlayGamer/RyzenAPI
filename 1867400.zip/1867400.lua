-- Lua provided by RyzenAPI
-- Game: 1867400

-- MAIN APPLICATION
addappid(1867400)
-- Game: addappid(1867400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867401, 1, "9b4fa03d3bded81d3d4bc9a9d1ff97773603dd6b297d5cc79df66e2b2564ec73")
