-- Lua provided by RyzenAPI 
-- Game: Neko Puzzle
addappid(1685880)
addappid(1685881, 1, "00533f5e4df83eb9e82199bf36e47b38a55b74f60958b724d25aa9e8b8615764")
