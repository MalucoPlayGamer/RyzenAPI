-- Lua provided by RyzenAPI
-- Game: Game: AppID 1399180

-- MAIN APPLICATION
addappid(1399180)
-- Game: addappid(1399180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399181, 1, "6e137ed438ef200dc152410bd13b1cd7076fa23fd2416b1c3cd9be002e6afd24")
addappid(1399183, 1, "596db70508f098f578879b3a59d8cdd34e48165bed87635738e83c15adfeef6c")
