-- Lua provided by RyzenAPI
-- Game: MORDHAU

-- MAIN APPLICATION
addappid(629760)
addappid(1049020)
addappid(1836060)
addappid(1836061)
addappid(2051200)
addappid(2172840)
addappid(2340920)
addappid(2579610)
addappid(2817460)
addappid(3199060)

-- MAIN APP DEPOTS / PACKAGES
addappid(629761,0,"b82feeaa287d5a5fcbe7a872419a5876c55b9fd9952e9ffd61cca30199a3e475")
addappid(1049020,0,"4a2aff4b390dddb370d3a1e16bc2c0e09da55926e097c1b3983a6ca11953e2c7")

