-- Lua provided by RyzenAPI
-- Game: Ms. Splosion Man

-- MAIN APPLICATION
addappid(105420)

-- MAIN APP DEPOTS / PACKAGES
addappid(105421, 1, "a903dcf43846dfd90571dc5f5ae35c8ac627b4802496fd4aaa912f87c3883b21")

