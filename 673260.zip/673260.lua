-- Lua provided by SkyAPI 
-- Game: Starblast
addappid(673260)
addappid(673261, 1, "302aafa60150c4a9e25f1917c9fb032b6d60d9f2084c4992a27a24eb95b1d10a")
addappid(673262, 1, "f8ccdefc3b4e13d1be27a0fc7ff5457ea42abdf28e8dbdbe42f7e2b37cef4c2b")
addappid(673264, 1, "2d1ee955d6bd5b5809d01eaf9a36319e5aa2d53eaa7590467de9714bc95c41c9")
