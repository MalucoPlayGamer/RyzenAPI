-- Lua provided by SkyAPI 
-- Game: Astroflux
addappid(489560)
addappid(489561, 1, "74b8e96b07b2e40dde0d4f4b87c8c84c11e6d5ff9f03dccf1cc2e718ca1f5351")
addappid(489562, 1, "e9ebba6973c707e256109e72b20a9158c4ee1791714ccc8b734674ff2daa74bc")
