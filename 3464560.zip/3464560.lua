-- Lua provided by RyzenAPI
-- Game: Game: SPARED!

-- MAIN APPLICATION
addappid(3464560)
-- Game: addappid(3464560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464561, 1, "c333e1917655c56fe50d554f06a44f305f9018e276c86fe95a6fda5d427da9a3")
