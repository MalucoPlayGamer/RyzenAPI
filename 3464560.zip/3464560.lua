-- Lua provided by RyzenAPI 
-- Game: SPARED!
addappid(3464560)
addappid(3464561, 1, "c333e1917655c56fe50d554f06a44f305f9018e276c86fe95a6fda5d427da9a3")
