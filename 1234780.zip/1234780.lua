-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport Chania - Ioannis Daskalogiannis

-- MAIN APPLICATION
addappid(1234780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234780,0,"f92483f13f0bed110901b646b721929f4b1a0632b1edd883a99867af6b1dd085")

