-- Lua provided by RyzenAPI
-- Game: Chroma: Bloom And Blight

-- MAIN APPLICATION
addappid(1140740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140741, 1, "b68cd533ba1d93b046d5416138f2bc9e4bd74fa59e5b44af3cb24f6b5ccc9b89")

