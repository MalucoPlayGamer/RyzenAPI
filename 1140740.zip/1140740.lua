-- Lua provided by RyzenAPI
-- Game: Chroma: Bloom And Blight

-- MAIN APPLICATION
addappid(1140740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140741, 1, "b68cd533ba1d93b046d5416138f2bc9e4bd74fa59e5b44af3cb24f6b5ccc9b89")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
