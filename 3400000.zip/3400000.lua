-- Lua provided by RyzenAPI
-- Game: addappid(3400000)

-- MAIN APPLICATION
addappid(3400000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400001, 1, "e1ef4a14595192f4e31bd0a1fef3c533c6b297918ff247799117e214b6c9d7ff")
