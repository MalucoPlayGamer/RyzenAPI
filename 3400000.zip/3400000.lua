-- Lua provided by RyzenAPI
-- Game: Cubic Odyssey

-- MAIN APPLICATION
addappid(3400000)
addappid(4210450)
addappid(4210460)
addappid(4210470)
addappid(4210480)
addappid(4241490)
addappid(4241500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400001,0,"e1ef4a14595192f4e31bd0a1fef3c533c6b297918ff247799117e214b6c9d7ff")

