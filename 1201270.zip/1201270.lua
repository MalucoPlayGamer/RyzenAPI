-- Lua provided by RyzenAPI 
-- Game: AppID 1201270
addappid(1201270)
addappid(1201271, 1, "059aab9cc6be1eb88f8bc9f00435944cbb6da3d97bf77c1321194c77f7eb9345")
addappid(2050830, 0, "5406f763ce10cb0c5838e6901d1e20be36452695e30b0c987e870ac1feecaa04")
