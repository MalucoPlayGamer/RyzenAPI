-- Lua provided by RyzenAPI
-- Game: CargoRun

-- MAIN APPLICATION
addappid(2187690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187691, 1, "127d90d400c7fc7635f8cfbe7bf87078a27519571f57f4fdeea5fabdb0ad4600")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
