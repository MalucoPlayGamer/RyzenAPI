-- Lua provided by RyzenAPI
-- Game: CargoRun

-- MAIN APPLICATION
addappid(2187690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187691, 1, "127d90d400c7fc7635f8cfbe7bf87078a27519571f57f4fdeea5fabdb0ad4600")

