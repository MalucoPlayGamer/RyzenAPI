-- Lua provided by RyzenAPI
-- Game: 527460

-- MAIN APPLICATION
addappid(527460)
-- Game: addappid(527460)

-- MAIN APP DEPOTS / PACKAGES
addappid(527461, 1, "fbc4f9fa403107e30a2b16ba398375d963269002419cb4ba10465fe21b25d2cc")
addappid(527462, 1, "cd356ec3f7606cec05a272b5d5b765ef749c826a73c9cfa35b2b4615cba9c236")
