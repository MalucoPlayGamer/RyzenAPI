-- Lua provided by RyzenAPI
-- Game: Quixzel Rush: Halloween Party

-- MAIN APPLICATION
addappid(937590)

-- MAIN APP DEPOTS / PACKAGES
addappid(937591, 1, "f62270fa7c4bd7a1209d89de3714143eec13c66e1a2928f3e8caced97cdbf4a4")

