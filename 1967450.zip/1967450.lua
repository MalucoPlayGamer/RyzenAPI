-- Lua provided by RyzenAPI
-- Game: 1967450

-- MAIN APPLICATION
addappid(1967450)
addappid(2092050)
-- Game: addappid(1967450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967451, 1, "72ed793e54a81acc76b668cd0f8ebcc5e1463a8329eedb9393ea2ccdf95110c3")
