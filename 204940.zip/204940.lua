-- Lua provided by RyzenAPI
-- Game: Crusader Kings Complete

-- MAIN APPLICATION
addappid(204940)

-- MAIN APP DEPOTS / PACKAGES
addappid(204941, 1, "5b174cd7b5f2abe3b7b05e340c357d7fa227f5c6183f72557647c67feaf7bfa3")
