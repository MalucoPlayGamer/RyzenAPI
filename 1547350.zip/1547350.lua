-- Lua provided by RyzenAPI
-- Game: addappid(1547350)

-- MAIN APPLICATION
addappid(1547350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547351, 1, "deceed4083aa72eba142429b28c46e6b5f9129d43ec142f6d4d9134a116c0477")
