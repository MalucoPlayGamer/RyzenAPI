-- Lua provided by RyzenAPI
-- Game: AppID 1547350

-- MAIN APPLICATION
addappid(1547350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547351, 1, "deceed4083aa72eba142429b28c46e6b5f9129d43ec142f6d4d9134a116c0477")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
