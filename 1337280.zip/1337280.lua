-- Lua provided by RyzenAPI
-- Game: Game: AppID 1337280

-- MAIN APPLICATION
addappid(1337280)
-- Game: addappid(1337280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337281, 1, "4f1dc058feed51b4c5d19edf6c1230e7d5db952f412f7e3ca4154ce6ff84ef45")
