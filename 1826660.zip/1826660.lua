-- Lua provided by RyzenAPI
-- Game: Game: Crystal Goddess

-- MAIN APPLICATION
addappid(1826660)
-- Game: addappid(1826660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826661, 1, "ffa364c0559d3000bdeb64a70240f64209773407dc865b8f744f23e1c563834f")
