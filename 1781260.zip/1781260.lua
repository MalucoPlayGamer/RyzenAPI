-- Lua provided by RyzenAPI 
-- Game: AppID 1781260
addappid(1781260)
addappid(1781261, 1, "07d743e67c418c1e5cff25519be852fab12bf44b7fb4f2d39ca63b95cefa4d33")
