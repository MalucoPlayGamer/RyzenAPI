-- Lua provided by RyzenAPI
-- Game: Timberman VS

-- MAIN APPLICATION
addappid(943380)
-- Game: addappid(943380)

-- MAIN APP DEPOTS / PACKAGES
addappid(943381, 1, "11336c272b20d470333260e40b161ed0b483f11d5786280fd4f62ed91d2d2903")
