-- Lua provided by RyzenAPI
-- Game: Game: GeneWars

-- MAIN APPLICATION
addappid(2093980)
-- Game: addappid(2093980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093981, 1, "b1520573567df9016b95576a1af0da36b8f86189b8953927f19b8641498c406c")
