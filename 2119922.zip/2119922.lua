-- Lua provided by RyzenAPI
-- Game: 2119922

-- MAIN APPLICATION
addappid(2119922)
-- Game: addappid(2119922)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119922,0,"e71030dd071ad4e8f274d1437e58c436fbbb5e0197d2eada57eefab6987bfcc6")
