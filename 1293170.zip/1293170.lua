-- Lua provided by RyzenAPI 
-- Game: BZZZT
addappid(1293170)
addappid(1293171, 1, "09dfff14c37a2203bc2a8532e205ff375f8e6a1085570d88c435ea61d8a74ddb")
addappid(1293173, 1, "27feb31f6ab691ced077676c709a2fcaf1717a127803815accbe66f9539b6e41")
addappid(1293174, 1, "ef080812ab61508c0b57261c712f18eeea4acc05c0b6df73d3ad6144992f51c4")
