-- Lua provided by RyzenAPI
-- Game: Super Raft Boat Together

-- MAIN APPLICATION
addappid(1955340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955341, 1, "655e828ccb569d0aff31819213dadb5061c7b91c6cb72d0fc6751aedfa24db3d")

