-- Lua provided by SkyAPI 
-- Game: Cats & Dice Demo
addappid(3165140)
addappid(3165141, 1, "6a19781188e90292bd74d04e2817d157ac2964b922f041e92f4172fd22c79547")
