-- Lua provided by RyzenAPI
-- Game: Game: Cats & Dice Demo

-- MAIN APPLICATION
addappid(3165140)
-- Game: addappid(3165140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165141, 1, "6a19781188e90292bd74d04e2817d157ac2964b922f041e92f4172fd22c79547")
