-- Lua provided by RyzenAPI
-- Game: addappid(3326530)

-- MAIN APPLICATION
addappid(3326530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3326531, 1, "f8fdd8fedc22f72c23b235dd68d61f070ea0ed46671bb10bd0d86b2ddc854d2f")
