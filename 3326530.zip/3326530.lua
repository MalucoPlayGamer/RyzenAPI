-- Lua provided by RyzenAPI
-- Game: My Taskbar Farm

-- MAIN APPLICATION
addappid(3326530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3326531, 1, "f8fdd8fedc22f72c23b235dd68d61f070ea0ed46671bb10bd0d86b2ddc854d2f")

