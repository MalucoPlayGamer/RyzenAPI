-- Lua provided by RyzenAPI
-- Game: 2231190

-- MAIN APPLICATION
addappid(2231190)
-- Game: addappid(2231190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231191, 1, "48e7e0796ba1b96f1722c7e298aa7138ade390af6f1421c5fafd6d31b73ebafa")
