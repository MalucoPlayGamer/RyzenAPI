-- Lua provided by RyzenAPI
-- Game: Roxy Raccoon's Pinball Panic

-- MAIN APPLICATION
addappid(1807690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807691, 1, "77f83127ac5f182fbb8e240d19d86161e464f3e40b97f631864456e5e8031aac")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1983760)
addappid(1987920)
addappid(2020880)
addappid(2082430)
addappid(2082431)
addappid(2082450)
addappid(2102270)
addappid(2102271)
addappid(2152150)
addappid(2152200)
addappid(2152210)
addappid(2234840)
addappid(2234841)
addappid(2234860)
addappid(2283450)
addappid(2372230)
addappid(2385270)
addappid(2462920)
addappid(2462921)
addappid(2546880)
addappid(2546890)
addappid(2546900)
addappid(2547000)
addappid(2643570)
addappid(2643580)
addappid(2643590)
addappid(2643610)
addappid(2773150)
addappid(2827370)
addappid(2827380)
addappid(2854080)
addappid(2854090)
addappid(2884550)
addappid(2884560)
addappid(2884570)
addappid(2884580)
addappid(3055850)
