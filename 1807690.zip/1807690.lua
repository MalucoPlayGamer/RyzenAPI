-- Lua provided by RyzenAPI
-- Game: Game: Roxy Raccoon's Pinball Panic

-- MAIN APPLICATION
addappid(1807690)
-- Game: addappid(1807690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807691, 1, "77f83127ac5f182fbb8e240d19d86161e464f3e40b97f631864456e5e8031aac")
