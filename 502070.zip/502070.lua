-- Lua provided by RyzenAPI
-- Game: AppID 502070

-- MAIN APPLICATION
addappid(502070)

-- MAIN APP DEPOTS / PACKAGES
addappid(502071, 1, "6f95decf499ee69828c89aaedbe1e036245d4c1a8f0642f1c4f2e3d751af340d")
addappid(502072, 1, "7cc98a995e022adffc1c1826dc34fe7d1f1d4abab047904d240bbd6110d56c1b")
addappid(502073, 1, "9346b30b468da8fb987be7bcc53eaf69aec8da4f4aed81ef61984105e4ab62d5")
addappid(502074, 1, "a03242ad7d07327755c8d4ec836c4ac52ce29aa97e12b65f8d29ba63b7dab66a")
addappid(502075, 1, "5c04e2baabfae896038a1c70c3e4755a8648d87b05058f7e1edf80c1de889a04")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
