-- Lua provided by RyzenAPI
-- Game: Thunder Ray

-- MAIN APPLICATION
addappid(1944910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944911, 1, "897e3e3c8938c1c8ceb9d69c154e5beafc79a3152d09426d439c7978b3adf072")

