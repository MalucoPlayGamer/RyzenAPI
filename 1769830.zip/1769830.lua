-- Lua provided by RyzenAPI
-- Game: As We Descend

-- MAIN APPLICATION
addappid(1769830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1769831, 1, "8c3967335c3e1b93c4524d512a00c44d7f35ea4d64b2e0158b9f852c1d8da9ec")
