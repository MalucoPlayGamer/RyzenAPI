-- Lua provided by SkyAPI 
-- Game: Flipped
addappid(1835090)
addappid(1835091, 1, "e9a9334b6c902dfd0d3f55a2427fccf19c4177333fdfebbef47c81ae5d21a7a0")
