-- Lua provided by RyzenAPI
-- Game: addappid(2099440)

-- MAIN APPLICATION
addappid(2099440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099441, 1, "c4128792f1ab22221225a0d851b0cc3cc49a361707a0c3795c1cbad8fb70eea6")
