-- Lua provided by RyzenAPI
-- Game: addappid(2121370)

-- MAIN APPLICATION
addappid(2121370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121371, 1, "ce61f919a143123b51fadec186d435fa48d8728846fc8423edc945b73ca188fe")
