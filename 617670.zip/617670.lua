-- Lua provided by RyzenAPI
-- Game: Game: AppID 617670

-- MAIN APPLICATION
addappid(617670)
-- Game: addappid(617670)

-- MAIN APP DEPOTS / PACKAGES
addappid(617671, 1, "b81f128eb62958238dc7e85508de15fd275e3cc8783d2ec1da2329c869b76ae7")
