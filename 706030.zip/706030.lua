-- Lua provided by RyzenAPI
-- Game: Parking Cop Simulator

-- MAIN APPLICATION
addappid(706030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(706031, 1, "1d158c107688bc12261847642e8a8170c13f64c92938f86b5455142e6b6dbb78")
