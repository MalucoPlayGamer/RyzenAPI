-- Lua provided by RyzenAPI
-- Game: Game: Hot Shot Burn

-- MAIN APPLICATION
addappid(801750)
-- Game: addappid(801750)

-- MAIN APP DEPOTS / PACKAGES
addappid(801751, 1, "f6a537275c0d1cfa06641e729d64aa0c6a0e0b61ddd02c8f9e5571572ad54fe5")
