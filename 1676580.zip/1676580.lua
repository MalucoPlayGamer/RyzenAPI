-- Lua provided by RyzenAPI
-- Game: My Stepmom is a Futanari

-- MAIN APPLICATION
addappid(1676580)
-- Game: addappid(1676580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676581, 1, "c251801620366fabbbe84d986c34d0733bf2ece9ae73f85964c31f25bfd58d4e")
