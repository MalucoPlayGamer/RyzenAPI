-- Lua provided by RyzenAPI
-- Game: Banished Knight

-- MAIN APPLICATION
addappid(3567940)
-- Game: addappid(3567940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3567949,0,"afad79aacf834398f58e9046d419007057e5bd3a93fcea592423c77c094bb63a")
