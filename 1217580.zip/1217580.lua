-- Lua provided by RyzenAPI
-- Game: AppID 1217580

-- MAIN APPLICATION
addappid(1217580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1217581, 1, "89c094026c7e7efc9f9b171ce4d963db76bb3533ccebecaf76c81d26209e6819")
addappid(1217582, 1, "60af9f97c4c013561a670831d5eac6d892b6798382acce760e2035da7e35131d")
addappid(1217583, 1, "e27891df43da46cedaad04092b4a0e7c0495fc67396d58389fea36455b0f0696")

