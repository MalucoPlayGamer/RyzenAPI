-- Lua provided by RyzenAPI
-- Game: 1637900

-- MAIN APPLICATION
addappid(1525193)
addappid(1637900)
addappid(1637901)
addappid(1637902)
-- Game: addappid(1637900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525192,0,"2e79d3b069644175b6b5ce3a9e4c135d9b52fe4da3e3105cac55ac98163bd27b")
