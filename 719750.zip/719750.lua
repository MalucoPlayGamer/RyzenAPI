-- Lua provided by RyzenAPI
-- Game: AppID 719750

-- MAIN APPLICATION
addappid(719750)

-- MAIN APP DEPOTS / PACKAGES
addappid(719751, 1, "b6b196600f6ab32beea140248fe3b5ea19bab6802fd115b894352e2696b4347c")
addappid(719752, 1, "e7fb21a8f729cac2cfa6196185655639ef189342137e6ba2cf83275c2b4fac45")
addappid(719753, 1, "efa4268e8b3f643ebb5105185d3939ec7d2a1b37dc880baf9a5e2f217fd7990d")
addappid(719754, 1, "6d493c4d331063bfb45699122d53b4285c9becfc135111d0d278d460210fbfd3")
addappid(719755, 1, "62dbbf93ed064bb5b4a316e99b14c8261489c98ac54b74e4a27c64c213ffc581")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3374800)
