-- Lua provided by RyzenAPI
-- Game: addappid(1692490)

-- MAIN APPLICATION
addappid(1692490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692490,0,"6cada7b57fc4a593853d1b8ca2dfe61551955f18ffcdf8c3e6c2a6dba64b77de")
