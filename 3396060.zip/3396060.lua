-- Lua provided by RyzenAPI
-- Game: Tower Networking Inc. Demo

-- MAIN APPLICATION
addappid(3396060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396061, 1, "24c4cbdadf0bbae48a088826561b169b0b6a02d0c1408aa732a46d336d4cb584")

