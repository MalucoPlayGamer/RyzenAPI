-- Lua provided by RyzenAPI
-- Game: Escape: VR

-- MAIN APPLICATION
addappid(607440)

-- MAIN APP DEPOTS / PACKAGES
addappid(607441, 1, "7feb0b910a31d551a26e40b86e2a938e665b6a0e4baab709b22ec6b26ebd3511")

