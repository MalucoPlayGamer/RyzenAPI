-- Lua provided by RyzenAPI 
-- Game: Corsairs Legacy Demo
addappid(2289330)
addappid(2289331, 1, "b65533e5babb143ce33f6aff0fec8665e6ee4d2fb53b6017f4559acafb08b868")
