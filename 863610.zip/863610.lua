-- Lua provided by RyzenAPI
-- Game: Game: AppID 863610

-- MAIN APPLICATION
addappid(863610)
-- Game: addappid(863610)

-- MAIN APP DEPOTS / PACKAGES
addappid(863611, 1, "b22b44e70573a799e8ae8c0626d2a47c9aba492b79d8752a530d1ced2faf6faa")
