-- Lua provided by RyzenAPI
-- Game: EDMtv VR

-- MAIN APPLICATION
addappid(513200)

-- MAIN APP DEPOTS / PACKAGES
addappid(513201, 1, "9fab3b04d399c0b13f383725795ce5f53b9001e26df0747dedcc27867ffb60a8")

