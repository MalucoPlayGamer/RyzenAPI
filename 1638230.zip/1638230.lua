-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword: Mists Beyond the Mountains

-- MAIN APPLICATION
addappid(1638230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638231, 1, "bf79b1e44f81974756e323c4a38363444ad60c63c6acbcfb76474f26044662b4")

