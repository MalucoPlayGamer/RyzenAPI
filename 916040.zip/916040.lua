-- Lua provided by RyzenAPI
-- Game: SFD

-- MAIN APPLICATION
addappid(916040)

-- MAIN APP DEPOTS / PACKAGES
addappid(916041, 1, "6f34b690056eb05e52ef16e44afaad07f93bad7c2d304031d09d4771785789aa")
