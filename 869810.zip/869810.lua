-- Lua provided by SkyAPI 
-- Game: AppID 869810
addappid(869810)
addappid(869811, 1, "536e8e46862c525349fe556ff5eafa0aa758030d8c43680affc40566a47d98f6")
