-- Lua provided by RyzenAPI
-- Game: 2995780

-- MAIN APPLICATION
addappid(2995780)
-- Game: addappid(2995780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2995781, 1, "e318b3179f4a060e1405951fb2f7807fc9cf85f59b096bfe82dbf3718f22a77b")
