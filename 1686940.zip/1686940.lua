-- Lua provided by RyzenAPI
-- Game: Bopl Battle

-- MAIN APPLICATION
addappid(1686940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686941, 1, "de23a57d97b78aaf4bbf11afcce1b6d2e96ce42e7518fb58ddf5535a51b81c65")

