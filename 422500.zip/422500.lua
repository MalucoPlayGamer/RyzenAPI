-- Lua provided by RyzenAPI
-- Game: Emmerholt: Prologue

-- MAIN APPLICATION
addappid(422500)
-- Game: addappid(422500)

-- MAIN APP DEPOTS / PACKAGES
addappid(422501, 1, "6a6696ae20bc06ae4e703b1d2f993d7cfe5ba71eabb12a4a59c44ef16aa10eac")
