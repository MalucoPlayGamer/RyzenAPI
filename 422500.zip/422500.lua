-- Lua provided by RyzenAPI
-- Game: Emmerholt: Prologue

-- MAIN APPLICATION
addappid(422500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(422501, 1, "6a6696ae20bc06ae4e703b1d2f993d7cfe5ba71eabb12a4a59c44ef16aa10eac")

