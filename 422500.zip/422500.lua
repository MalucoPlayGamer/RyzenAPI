-- Lua provided by SkyAPI 
-- Game: Emmerholt: Prologue
addappid(422500)
addappid(422501, 1, "6a6696ae20bc06ae4e703b1d2f993d7cfe5ba71eabb12a4a59c44ef16aa10eac")
