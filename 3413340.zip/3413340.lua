-- Lua provided by RyzenAPI
-- Game: Wallpaper Play

-- MAIN APPLICATION
addappid(3413340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413341, 1, "66f5da21a8bac32645aaea80893ba7cc28b1e046f1729e50cf867daaf8ad45c8")

