-- Lua provided by RyzenAPI
-- Game: Package Piles: Tidy Up The Warehouse!

-- MAIN APPLICATION
addappid(5050640) -- Package Piles: Tidy Up The Warehouse!

-- MAIN APP DEPOTS / PACKAGES
addappid(5050641, 1, "0322ee3684c23cc8ccf03203bcefa1764b76080455de96b2e6d2d1db56bf0c31") -- Depot 5050641

