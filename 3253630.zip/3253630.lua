-- Lua provided by SkyAPI 
-- Game: Gal Guardians: Servants of the Dark
addappid(3253630)
addappid(3253631, 1, "35b657ff529e35bc5bc2480eda73c452361b0e5875c1a66000bd08f5da5789a8")
