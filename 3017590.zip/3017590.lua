-- Lua provided by RyzenAPI
-- Game: Brickadia Server

-- MAIN APPLICATION
addappid(3017590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017591, 1, "88e9bce59016ce7281a22228c6068b059783496850ac564a55cb76d34fc5ea18")
