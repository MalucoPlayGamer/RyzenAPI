-- 4424080's Lua and Manifest Created by Hubcap Manifest
-- BounceForever
-- Created: August 19, 2026 at 11:36:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4424080) -- BounceForever
-- MAIN APP DEPOTS
addappid(4424081, 1, "c220075ed6c11faf9e354810033c3a2ee3fd7df18950c796f9c3bcedaf30d5bb") -- Depot 4424081
setManifestid(4424081, "5479862975970946958", 1270895873)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)