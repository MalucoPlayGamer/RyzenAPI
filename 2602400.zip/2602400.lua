-- Lua provided by RyzenAPI
-- Game: Game: 御姐初长成试玩版

-- MAIN APPLICATION
addappid(2602400)
-- Game: addappid(2602400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602401, 1, "e15b6d80a7b5905b576ccbc4f11c6f5375521bf90cd1d1b2aa537406e18053a6")
