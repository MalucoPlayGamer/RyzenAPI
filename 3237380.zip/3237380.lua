-- Lua provided by RyzenAPI
-- Game: addappid(3237380)

-- MAIN APPLICATION
addappid(3237380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3237381, 1, "f64337db0a054f18da3372617539df5b28c3100290e2658f8fac19569a99afef")
