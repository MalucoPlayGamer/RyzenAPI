-- Lua provided by SkyAPI 
-- Game: AppID 3237380
addappid(3237380)
addappid(3237381, 1, "f64337db0a054f18da3372617539df5b28c3100290e2658f8fac19569a99afef")
