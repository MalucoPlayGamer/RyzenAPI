-- Lua provided by RyzenAPI
-- Game: Musgro Farm - Demo

-- MAIN APPLICATION
addappid(3318320)
-- Game: addappid(3318320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318321, 1, "0eed163015bd19c929e4012aa52fc0dd38006d5096447b70f6d5eba2d8478d91")
