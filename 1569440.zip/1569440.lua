-- Lua provided by RyzenAPI
-- Game: Game: OneShot: Fading Memory

-- MAIN APPLICATION
addappid(1569440)
-- Game: addappid(1569440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569441, 1, "795ae553653b0905c5eee2fb8a716262396ff15c4313640cabbb00f01d1e4512")
