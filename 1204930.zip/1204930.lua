-- Lua provided by RyzenAPI 
-- Game: Hop Step Sing! Astral Piece
addappid(1204930)
addappid(1204931, 1, "6977496e40ca329ab0ab89a00a496bb27cb2e4c89c1710cc90ec11dbd158b90c")
addappid(1204933, 1, "9d8247414723744e53d81760a12af25bc7f3d6a298a8516e650449570aa30f02")
