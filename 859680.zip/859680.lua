-- Lua provided by RyzenAPI
-- Game: addappid(859680)

-- MAIN APPLICATION
addappid(859680)

-- MAIN APP DEPOTS / PACKAGES
addappid(859681, 1, "0bfb260a5d76a9d2f7b3a6a8b48dafb19d9a7c616c8fbe7bb172c3acff2d02ee")
addappid(947550, 0, "1deee04857ecf7ae60b626690586614307c0331e863a8b780e7b0e2c94c90c77")
