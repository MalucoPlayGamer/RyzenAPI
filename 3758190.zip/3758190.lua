-- Lua provided by RyzenAPI
-- Game: WUCHANG: Fallen Feathers Soundtrack

-- MAIN APPLICATION
addappid(3758190)
-- Game: addappid(3758190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3758191, 1, "6a02a8415b11cc2d0d5578a0bb93e955abb933fbb378d43149a2105e5f32590a")
addappid(3758192, 1, "3c6aafecacfcd5f0ef971f364de81fcf4752115de544aa3a40c8f8a2ce0bcbe7")
