-- Lua provided by RyzenAPI
-- Game: ZDSimulator - Kyiv-Shevchenko Route

-- MAIN APPLICATION
addappid(3609190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609190,0,"d41c60128a717f37fd1e3edc7ba50fb00f13838f3df71841ae1d37f0534515c5")
