-- Lua provided by RyzenAPI
-- Game: 2222000

-- MAIN APPLICATION
addappid(2222000)
-- Game: addappid(2222000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222001, 1, "412f657dd415bd104b0de759ab207cf60f78c9536a6cff0fb76c268ad71a53db")
