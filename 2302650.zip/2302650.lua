-- Lua provided by SkyAPI 
-- Game: Cat Girl Creator
addappid(2302650)
addappid(2302651, 1, "88fe4ec1a89354a5ce8e7c3ea6ca5a1471906d8751d7bf8ea757837575ec9a9b")
addappid(2302652, 1, "3bef7fb2dd156064162992ad302a964a0e3ec31c75a85d5f5d217873e0d065da")
addappid(2302653, 1, "e0d6395262a8eeeb905af3bc6f8f30bb4d151d6581a01d4acecdcd766a8493eb")
