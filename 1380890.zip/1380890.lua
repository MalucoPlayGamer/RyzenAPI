-- Lua provided by RyzenAPI
-- Game: Block Sumo

-- MAIN APPLICATION
addappid(1380890)
-- Game: addappid(1380890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380891, 1, "5252edcac94bb9a04d287bb692667e1cc6310a10d5613a8e168fee7c08ef9b42")
