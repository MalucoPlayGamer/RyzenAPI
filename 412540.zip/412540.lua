-- Lua provided by RyzenAPI
-- Game: The Minotaur

-- MAIN APPLICATION
addappid(412540)
addappid(412550)

-- MAIN APP DEPOTS / PACKAGES
addappid(412541, 1, "86f4006cc7628f6c0b2b49de2511a2ba79362ce47b715467ecfcbd0be32a2e29")
addappid(412542, 1, "a5424cc2e4d9250c180e66e90ea80bc5283b62009bd598984fbb141f673bdfec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
