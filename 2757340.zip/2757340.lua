-- Lua provided by RyzenAPI
-- Game: Game: AppID 2757340

-- MAIN APPLICATION
addappid(2757340)
-- Game: addappid(2757340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757341, 1, "a1b7ff3b607b1a46ced4333d88a31500cef3c6ff65b6f292105318254b46ba0c")
