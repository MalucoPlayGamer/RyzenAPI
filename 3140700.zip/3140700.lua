-- Lua provided by RyzenAPI
-- Game: Game: FALSE SPIDER Demo

-- MAIN APPLICATION
addappid(3140700)
-- Game: addappid(3140700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140701, 1, "875ff57ee9e24165ad5ecc8f9647f18bf5cf9ad290355db4923b048185fb743f")
