-- Lua provided by RyzenAPI
-- Game: She Fell Off

-- MAIN APPLICATION
addappid(2531540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531541, 1, "1de2c7036c5d6818fec42293a491201c647e685744fdb8348b5cd0dfc381b3a4")

