-- Lua provided by RyzenAPI
-- Game: Game: AppID 676990

-- MAIN APPLICATION
addappid(676990)
-- Game: addappid(676990)

-- MAIN APP DEPOTS / PACKAGES
addappid(676991, 1, "6a86d204f6e1728841214b7994851eba9857231dba616eb8c60911906a33ce1c")
