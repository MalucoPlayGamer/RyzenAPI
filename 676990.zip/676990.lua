-- Lua provided by RyzenAPI
-- Game: The Stone

-- MAIN APPLICATION
addappid(676990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(676991, 1, "6a86d204f6e1728841214b7994851eba9857231dba616eb8c60911906a33ce1c")
