-- Lua provided by RyzenAPI
-- Game: Demon Truck

-- MAIN APPLICATION
addappid(489760)

-- MAIN APP DEPOTS / PACKAGES
addappid(489761, 1, "af4d6e80976f48e4d2fbe8df6e53f0d1046df91c9802d5cbbae60490c003d26e")
