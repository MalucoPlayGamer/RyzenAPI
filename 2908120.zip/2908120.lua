-- Lua provided by RyzenAPI
-- Game: addappid(2908120)

-- MAIN APPLICATION
addappid(2908120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908121, 1, "5e933532e080042fb16d4f4dcd121031dbd54bd708f522d0f33f3f63c67f2320")
