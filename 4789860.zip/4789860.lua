-- 4789860's Lua and Manifest Created by Hubcap Manifest
-- Furry Adventure 3 - Big Boobas!
-- Created: August 17, 2026 at 14:46:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4789860) -- Furry Adventure 3 - Big Boobas!
-- MAIN APP DEPOTS
addappid(4789861, 1, "bf6b085627e9e4166f7c2dd93a183954f5f94b95747ab8559575c89138b08f97") -- Depot 4789861
setManifestid(4789861, "7256832890046622332", 3240505793)