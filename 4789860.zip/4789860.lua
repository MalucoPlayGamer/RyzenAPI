-- Lua provided by RyzenAPI
-- Game: Furry Adventure 3 - Big Boobas!

-- MAIN APPLICATION
addappid(4789860) -- Furry Adventure 3 - Big Boobas!

-- MAIN APP DEPOTS / PACKAGES
addappid(4789861, 1, "bf6b085627e9e4166f7c2dd93a183954f5f94b95747ab8559575c89138b08f97") -- Depot 4789861

