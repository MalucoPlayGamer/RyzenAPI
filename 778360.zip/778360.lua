-- Lua provided by RyzenAPI
-- Game: Love or Loved

-- MAIN APPLICATION
addappid(778360)

-- MAIN APP DEPOTS / PACKAGES
addappid(778361, 1, "4df244a5564cd974038fb37f14cd38d34069b88a0485b16984186e57377dac12")

