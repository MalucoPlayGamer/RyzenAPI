-- Lua provided by RyzenAPI
-- Game: Pro Gamer Manager

-- MAIN APPLICATION
addappid(408740)
addappid(567740)
addappid(567741)
addappid(567742)
addappid(567743)
-- Game: addappid(408740)

-- MAIN APP DEPOTS / PACKAGES
addappid(408741, 1, "6d0bf9b8868370fdad1920e813c0e8d9886483b3b8e065074c0b493298d43875")
