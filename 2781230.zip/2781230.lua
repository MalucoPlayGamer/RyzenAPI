-- Lua provided by RyzenAPI
-- Game: addappid(2781230)

-- MAIN APPLICATION
addappid(2781230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781231, 1, "05c7e438a183ea0fe6604545390bcd242ad22ab3e814cc50f7b6b37b34d8d007")
