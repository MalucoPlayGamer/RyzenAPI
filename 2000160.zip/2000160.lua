-- Lua provided by RyzenAPI
-- Game: Music Store Simulator

-- MAIN APPLICATION
addappid(2000160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000161, 1, "2b6327d3aec126406cfefebd4dd4934fa75673ce5e48950d4bfc10bbd45d4946")
