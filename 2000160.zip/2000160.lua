-- Lua provided by SkyAPI 
-- Game: Music Store Simulator
addappid(2000160)
addappid(2000161, 1, "2b6327d3aec126406cfefebd4dd4934fa75673ce5e48950d4bfc10bbd45d4946")
