-- Lua provided by RyzenAPI
-- Game: Night Blade

-- MAIN APPLICATION
addappid(1591340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591341, 1, "758a127bd6d56fb58b8624b1e710740fabf8a898c8c5bce3713cd3c926ace560")

