-- Lua provided by RyzenAPI 
-- Game: Night Blade
addappid(1591340)
addappid(1591341, 1, "758a127bd6d56fb58b8624b1e710740fabf8a898c8c5bce3713cd3c926ace560")
