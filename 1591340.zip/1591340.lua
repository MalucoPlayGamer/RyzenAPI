-- Lua provided by RyzenAPI
-- Game: Night Blade

-- MAIN APPLICATION
addappid(1591340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591341, 1, "758a127bd6d56fb58b8624b1e710740fabf8a898c8c5bce3713cd3c926ace560")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
