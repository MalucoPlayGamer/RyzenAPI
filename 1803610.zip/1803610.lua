-- Lua provided by RyzenAPI
-- Game: 1803610

-- MAIN APPLICATION
addappid(1803610)
-- Game: addappid(1803610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803611, 1, "8481c75d08b17a7dff991af75b1e62dce6a4374b7079267537f39bbafbc06730")
