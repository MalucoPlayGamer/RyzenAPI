-- Lua provided by RyzenAPI
-- Game: AppID 1803610

-- MAIN APPLICATION
addappid(1803610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1803611, 1, "8481c75d08b17a7dff991af75b1e62dce6a4374b7079267537f39bbafbc06730")

