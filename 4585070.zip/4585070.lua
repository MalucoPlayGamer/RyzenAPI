-- Lua provided by RyzenAPI
-- Game: Boil Cabbage Make Soup

-- MAIN APPLICATION
addappid(4585070) -- Boil Cabbage Make Soup

-- MAIN APP DEPOTS / PACKAGES
addappid(4585071, 1, "3de7c1c4fd2dce7df66abcc7e6f164abeecc9949473b2a0df69a5a0fd34efa7b") -- Depot 4585071

