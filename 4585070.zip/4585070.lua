-- 4585070's Lua and Manifest Created by Hubcap Manifest
-- Boil Cabbage Make Soup
-- Created: August 12, 2026 at 22:54:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4585070) -- Boil Cabbage Make Soup
-- MAIN APP DEPOTS
addappid(4585071, 1, "3de7c1c4fd2dce7df66abcc7e6f164abeecc9949473b2a0df69a5a0fd34efa7b") -- Depot 4585071
setManifestid(4585071, "2664458221320222470", 549386470)