-- Lua provided by RyzenAPI
-- Game: Star Trek: Resurgence

-- MAIN APPLICATION
addappid(2653940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653941, 1, "ee1cbdec40a1fad0b1834e8c18dc966cbbb2adabda6f1583968128b37b4faf16")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2979360)
