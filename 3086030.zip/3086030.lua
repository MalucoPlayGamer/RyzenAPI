-- Lua provided by RyzenAPI
-- Game: Dream World Adventure

-- MAIN APPLICATION
addappid(3086030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086031, 1, "71bde297498876092d7425eba52288a31845a9b4646f02d411ecf9a3fb608b76")
