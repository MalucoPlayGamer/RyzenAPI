-- Lua provided by RyzenAPI
-- Game: 1607016

-- MAIN APPLICATION
addappid(1607016)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607016,0,"e9c6ded588d45885902dd7e0c8b7aedca4bc4770b7f66422fa92b8a5cda39a06")

