-- Lua provided by RyzenAPI
-- Game: The Con Simulator

-- MAIN APPLICATION
addappid(917020)
addappid(917021)
addappid(1008660)

-- MAIN APP DEPOTS / PACKAGES
addappid(917022,0,"1fe331ecdd7a6f4ccf4218fc8c173a7c0e6929aad57c47d27dd1bdff2275efa5")
addappid(917023,0,"17cdd35630497113a7b7b26e32bb6adb8a1642b7623ceab4201c74ef3f18b20d")

