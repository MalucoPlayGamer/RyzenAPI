-- Lua provided by SkyAPI 
-- Game: AppID 362400
addappid(362400)
addappid(362401, 1, "653ae45d630ec4ad1f89918e0c2ce7fd3a0e135dcd13bb419dbcc4006b77d532")
addappid(362402, 1, "2d5cb976909a13ce3ba3ea51a880ed0b9fa857e9b474dba179730d41d2d5dc52")
