-- Lua provided by RyzenAPI
-- Game: AppID 356570

-- MAIN APPLICATION
addappid(356570)

-- MAIN APP DEPOTS / PACKAGES
addappid(356571, 1, "e0c5af37eb915ce07aca7109ae015d3ab3c5fc4f5d12a23737d8f384de5863b2")
addappid(356572, 1, "29073d7749d6f3624d9f26ba1ca67ead84929bb11b642e4d37fc406b8dece937")
addappid(356573, 1, "6169c58c4b57ebfc6d172f174a91fd8537d2a9daff72fe744c712dc0cd352c76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(530180)
addappid(554791)
