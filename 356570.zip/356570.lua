-- Lua provided by RyzenAPI
-- Game: 356570

-- MAIN APPLICATION
addappid(356570)
-- Game: addappid(356570)

-- MAIN APP DEPOTS / PACKAGES
addappid(356571, 1, "e0c5af37eb915ce07aca7109ae015d3ab3c5fc4f5d12a23737d8f384de5863b2")
addappid(356572, 1, "29073d7749d6f3624d9f26ba1ca67ead84929bb11b642e4d37fc406b8dece937")
addappid(356573, 1, "6169c58c4b57ebfc6d172f174a91fd8537d2a9daff72fe744c712dc0cd352c76")
