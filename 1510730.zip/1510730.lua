-- Lua provided by RyzenAPI
-- Game: Auto World Tycoon

-- MAIN APPLICATION
addappid(1510730)
-- Game: addappid(1510730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510731, 1, "a4754879879711f689b3b242d56e633488c2f90ec6e81f0194b2d25e65554473")
