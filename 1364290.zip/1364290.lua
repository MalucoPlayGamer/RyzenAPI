-- Lua provided by RyzenAPI
-- Game: Animalia Survival

-- MAIN APPLICATION
addappid(1364290)
addappid(1836930)
addappid(1880050)
addappid(1933380)
addappid(2181270)
addappid(2181271)
addappid(2186930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364291, 1, "8b4b39182603bff5a321a38e2932993b82401b9a9e7fc0b15d795bef3c55d224")

