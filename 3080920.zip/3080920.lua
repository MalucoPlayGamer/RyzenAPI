-- Lua provided by RyzenAPI
-- Game: 孵道

-- MAIN APPLICATION
addappid(3080920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080921, 1, "5f081d6f3567280bee95c7e3eb793f96724566c7ed1c2610bdbbb4dd3e50c3fc")
