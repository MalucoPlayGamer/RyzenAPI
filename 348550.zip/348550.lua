-- Lua provided by RyzenAPI
-- Game: GUILTY GEAR XX ACCENT CORE PLUS R

-- MAIN APPLICATION
addappid(348550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(348551, 1, "bc81a7470b9eafaa17162700c9a15e00de6d5dc6c2c23da102e1df775d9ff4fd")

