-- Lua provided by RyzenAPI
-- Game: 348550

-- MAIN APPLICATION
addappid(348550)
-- Game: addappid(348550)

-- MAIN APP DEPOTS / PACKAGES
addappid(348551, 1, "bc81a7470b9eafaa17162700c9a15e00de6d5dc6c2c23da102e1df775d9ff4fd")
