-- Lua provided by RyzenAPI
-- Game: Long Ago: A Puzzle Tale

-- MAIN APPLICATION
addappid(1589920)
-- Game: addappid(1589920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589921, 1, "5edf31f0027dc09bcac4099c46bd6e2c46cc1336909c4b080993533c3eaee125")
addappid(1589922, 1, "6b1931062d59157f83369ea6e87c7da555cb99dfa22878e6b92260e6cd81b0e2")
