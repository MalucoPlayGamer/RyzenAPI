-- Lua provided by RyzenAPI
-- Game: Long Ago: A Puzzle Tale

-- MAIN APPLICATION
addappid(1589920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589921, 1, "5edf31f0027dc09bcac4099c46bd6e2c46cc1336909c4b080993533c3eaee125")
addappid(1589922, 1, "6b1931062d59157f83369ea6e87c7da555cb99dfa22878e6b92260e6cd81b0e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
