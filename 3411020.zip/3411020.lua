-- Lua provided by RyzenAPI
-- Game: addappid(3411020)

-- MAIN APPLICATION
addappid(3411020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411021, 1, "2a147d92b887763ad62d27ee4a67a4f720b65a95c1468a5ae33ba5ecc11be8b5")
