-- Lua provided by RyzenAPI
-- Game: Nazi Zombies

-- MAIN APPLICATION
addappid(3044350)

