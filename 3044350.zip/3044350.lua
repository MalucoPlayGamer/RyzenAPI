-- Lua provided by RyzenAPI
-- Game: Nazi Zombies

-- MAIN APPLICATION
addappid(3044350)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3044360)
