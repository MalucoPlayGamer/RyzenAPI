-- Lua provided by RyzenAPI
-- Game: AppID 409150

-- MAIN APPLICATION
addappid(409150)
-- Game: addappid(409150)

-- MAIN APP DEPOTS / PACKAGES
addappid(409151, 1, "082b00cede46b4c8583af8c9707ad199fbffc525f53a4dc82d2369a04f5dcf78")
