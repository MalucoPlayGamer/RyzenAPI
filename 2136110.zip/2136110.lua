-- Lua provided by RyzenAPI
-- Game: addappid(2136110)

-- MAIN APPLICATION
addappid(2136110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136111, 1, "a895de9b78a2e6e9ca318ef74c2e4dedfe4391fde5970e4e1cc1bc430d9d69ab")
