-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(224763)

-- MAIN APP DEPOTS / PACKAGES
addappid(224763,0,"19c6e089f2d743d986b9af1efcd18596af578cb85dd38da5d2b273003f830371")
addappid(1403120,0,"62e1924f8ad95119b633075fd6cc5ccdfce3781b4bc89baa1baa4ead5f28b99d")
addtoken(224763,18133981425943676207)

