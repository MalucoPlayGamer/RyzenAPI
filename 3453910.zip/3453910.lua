-- Lua provided by RyzenAPI
-- Game: Happy's Humble Burger Cult

-- MAIN APPLICATION
addappid(3453910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453911, 1, "565c80590e51c2a01c3f2c52c1f3b4c27bedd850997f8054545d448291384463") -- Depot 3453911

