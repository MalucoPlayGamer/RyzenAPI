-- Lua provided by RyzenAPI
-- Game: addappid(1235450)

-- MAIN APPLICATION
addappid(1235450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235451, 1, "eb715e16e1c4855b89eebe0da46262053ed69f95e072d19db1c189edbae36fd4")
