-- Lua provided by RyzenAPI
-- Game: 1466190

-- MAIN APPLICATION
addappid(1466190)
-- Game: addappid(1466190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466191, 1, "14ba7a9fd4c1a59d0d70600ae8deb0ffcdce07b8c33d771725b1ebaff51c6604")
