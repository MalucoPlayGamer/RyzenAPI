-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Scenario & BGM Set 5

-- MAIN APPLICATION
addappid(1634712)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634712,0,"39faf0211d10d1854164fe237a2dbf3ce06e3608bf78e63ff5cba2fd12a3ca7c")

