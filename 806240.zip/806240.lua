-- Lua provided by RyzenAPI
-- Game: 806240

-- MAIN APPLICATION
addappid(806240)
-- Game: addappid(806240)

-- MAIN APP DEPOTS / PACKAGES
addappid(806241, 1, "68e73aa2de22de37325f60e311147d83ff7a5ef1a44863ce5e3dda069626fd38")
