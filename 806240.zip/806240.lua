-- Lua provided by RyzenAPI
-- Game: AppID 806240

-- MAIN APPLICATION
addappid(806240)

-- MAIN APP DEPOTS / PACKAGES
addappid(806241, 1, "68e73aa2de22de37325f60e311147d83ff7a5ef1a44863ce5e3dda069626fd38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
