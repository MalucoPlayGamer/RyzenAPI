-- Lua provided by RyzenAPI
-- Game: Qorena

-- MAIN APPLICATION
addappid(1049640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1049641, 1, "8542a59fedf633f773d0ddde4b72e78c9f93fc59d3c7ce13aba3b802e65c1c37")
addappid(1049642, 1, "aa8ff60223ace5711ce4e8344eba2af15a4fd0fb080443b0c43c807945f2df9d")

