-- Lua provided by RyzenAPI
-- Game: Backrooms Loop

-- MAIN APPLICATION
addappid(3672540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3672541, 1, "22eba8d8626daa1ee82ba5a5d84d9355cf68c3cb8752411c2fb7eaafaa19c5e6")
