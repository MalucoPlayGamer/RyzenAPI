-- Lua provided by RyzenAPI 
-- Game: Peaceful Days
addappid(1156360)
addappid(1156361, 1, "34d1eb309c4508d98e9e8d2b3f86bae5a2c103ea50b35493f0df1e03d701eaf7")
addappid(4175640)
