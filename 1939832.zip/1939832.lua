-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1939832)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939832,0,"a76dd722ee2d389be66560d0e292b9f6bfddc2780551cbc6a7e05077043af08f")
