-- Lua provided by RyzenAPI
-- Game: I Am Sakuya FPS: Lunarian Invasion

-- MAIN APPLICATION
addappid(3864010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3864011,0,"83b56b110454f95ad2e95b6de04ae08d72b38be75e0f9ddc7e761c3632ba5564")

