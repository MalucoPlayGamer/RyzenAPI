-- Lua provided by RyzenAPI 
-- Game: AppID 509240
addappid(509240)
addappid(509241, 1, "2481e6b9559963801d454e7a943329dd8edf6b707ef16ae9159c95697d5aa7c8")
