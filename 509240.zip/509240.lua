-- Lua provided by RyzenAPI
-- Game: addappid(509240)

-- MAIN APPLICATION
addappid(509240)

-- MAIN APP DEPOTS / PACKAGES
addappid(509241, 1, "2481e6b9559963801d454e7a943329dd8edf6b707ef16ae9159c95697d5aa7c8")
