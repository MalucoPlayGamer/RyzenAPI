-- Lua provided by RyzenAPI
-- Game: 1804020

-- MAIN APPLICATION
addappid(1804020)
-- Game: addappid(1804020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804021, 1, "c3ea7942a1bb4aa8f905b4e730728668171cf4c9427dd835ce08a50073d89ac3")
addappid(1804022, 1, "6cfd9b1712e4e25de449e02138a87bf9b7cd338af9c8a5432e7b8a3c3b66ed9c")
addappid(1804023, 1, "cfbca2db709700e4ed71db39dbc1c6a5bf6b226b50aee491570f9944d2ba250e")
