-- Lua provided by RyzenAPI
-- Game: 钟馗斩鬼 试用版

-- MAIN APPLICATION
addappid(3176100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176101, 1, "882854fdec1e77c9c6adb2dd758891428934bea0f45376fe9d5bba778a9a0f7a")

