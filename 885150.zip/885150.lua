-- Lua provided by RyzenAPI
-- Game: Game: AppID 885150

-- MAIN APPLICATION
addappid(885150)
-- Game: addappid(885150)

-- MAIN APP DEPOTS / PACKAGES
addappid(885151, 1, "065842b529868579e6f4294e64bb4d9e50c36c19a7166d6f6b4cdc23cff6044d")
