-- Lua provided by RyzenAPI
-- Game: AppID 885150

-- MAIN APPLICATION
addappid(885150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(885151, 1, "065842b529868579e6f4294e64bb4d9e50c36c19a7166d6f6b4cdc23cff6044d")

