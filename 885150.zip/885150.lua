-- Lua provided by RyzenAPI 
-- Game: AppID 885150
addappid(885150)
addappid(885151, 1, "065842b529868579e6f4294e64bb4d9e50c36c19a7166d6f6b4cdc23cff6044d")
