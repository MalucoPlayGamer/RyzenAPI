-- Lua provided by RyzenAPI
-- Game: Touhou Genso Wanderer -FORESIGHT-

-- MAIN APPLICATION
addappid(1847150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847151, 1, "9f8b15faa6e7d997f2f98facab170b3ea49259938cf880e23dc362f61e309253")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2898290)
addappid(3068120)
addappid(3296810)
