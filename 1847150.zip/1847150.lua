-- Lua provided by RyzenAPI
-- Game: addappid(1847150)

-- MAIN APPLICATION
addappid(1847150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847151, 1, "9f8b15faa6e7d997f2f98facab170b3ea49259938cf880e23dc362f61e309253")
