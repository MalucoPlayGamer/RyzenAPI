-- Lua provided by RyzenAPI
-- Game: 1366850

-- MAIN APPLICATION
addappid(1366850)
addappid(2532380)
-- Game: addappid(1366850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366851, 1, "a3355a91fe5bfd67cdb9df887a898194bb748ff16a3dafb779b654120cc08648")
