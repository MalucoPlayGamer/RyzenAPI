-- Lua provided by RyzenAPI
-- Game: Jected - Rivals

-- MAIN APPLICATION
addappid(1366850)
addappid(2347970)
addappid(2347971)
addappid(2532380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1366851, 1, "a3355a91fe5bfd67cdb9df887a898194bb748ff16a3dafb779b654120cc08648")

