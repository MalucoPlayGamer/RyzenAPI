-- Lua provided by RyzenAPI 
-- Game: AppID 974970
addappid(974970)
addappid(974971, 1, "b64d13cae0830764341ead2c5bb8ad5502e107621886e7cedf96fa3ec30dba23")
