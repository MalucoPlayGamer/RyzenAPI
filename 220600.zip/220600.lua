-- Lua provided by RyzenAPI
-- Game: Game: AppID 220600

-- MAIN APPLICATION
addappid(220600)
-- Game: addappid(220600)

-- MAIN APP DEPOTS / PACKAGES
addappid(220601, 1, "10d326ef486c48609b68f2a44bea7f58611312f485a27052ca6047e8d5da46f0")
