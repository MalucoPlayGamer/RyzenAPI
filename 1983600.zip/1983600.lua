-- Lua provided by RyzenAPI
-- Game: Game: TYPER GIRL

-- MAIN APPLICATION
addappid(1983600)
addappid(1991800)
-- Game: addappid(1983600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983601, 1, "5755389dbee69004e261222fe1c995fcf13f5f3120549b5bda46228b1e40d60d")
