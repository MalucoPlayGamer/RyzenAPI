-- Lua provided by RyzenAPI
-- Game: Mystery Case Files: The Revenant's Hunt Collector's Edition

-- MAIN APPLICATION
addappid(749080)

-- MAIN APP DEPOTS / PACKAGES
addappid(749081, 1, "31e72d72068970e998c5bb332007838f084622d616c11998c74c47bcc6c188a0")

