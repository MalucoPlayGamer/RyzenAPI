-- Lua provided by RyzenAPI
-- Game: 1553390

-- MAIN APPLICATION
addappid(228988)
addappid(228989)
addappid(228990)
addappid(1553390)
addappid(1553395)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553394,0,"3ca2ba39e2b52cd34f54b74b6072c3c1482b2ecbc1fd337593f8fcf366ea4006")
