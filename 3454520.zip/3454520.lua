-- Lua provided by RyzenAPI
-- Game: Death Drive

-- MAIN APPLICATION
addappid(3454520)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4231040)
