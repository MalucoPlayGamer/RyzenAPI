-- Lua provided by RyzenAPI
-- Game: Death Drive

-- MAIN APPLICATION
addappid(3454520)
