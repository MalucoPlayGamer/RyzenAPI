-- Lua provided by RyzenAPI 
-- Game: DAEMON X MACHINA
addappid(1167450)
addappid(1167451, 1, "3dc4397d4f94a640043bea785c35492e0b1bfc7e8d08d9f1a1f708f9eab47991")
