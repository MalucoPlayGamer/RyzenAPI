-- Lua provided by RyzenAPI
-- Game: Game: DAEMON X MACHINA

-- MAIN APPLICATION
addappid(1167450)
-- Game: addappid(1167450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167451, 1, "3dc4397d4f94a640043bea785c35492e0b1bfc7e8d08d9f1a1f708f9eab47991")
