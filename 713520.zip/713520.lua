-- Lua provided by RyzenAPI
-- Game: Adventures of Heroes

-- MAIN APPLICATION
addappid(713520)

-- MAIN APP DEPOTS / PACKAGES
addappid(713521, 1, "849de8a269f7a1274befd25122661196f5a28a9c628940e9250880c30506e71f")

