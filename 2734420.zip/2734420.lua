-- Lua provided by RyzenAPI
-- Game: Summer Clover Demo

-- MAIN APPLICATION
addappid(2734420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2734421, 1, "74302a3345e497fb2874664582fd29a05f014631f1a037984d3cbcce996c1f00")

