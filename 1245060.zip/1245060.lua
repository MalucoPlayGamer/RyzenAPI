-- Lua provided by RyzenAPI
-- Game: addappid(1245060)

-- MAIN APPLICATION
addappid(1245060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245061, 1, "99dd7f664effdd7bbdd25aeda95742d8d5f4d0f657ee110c9cd0cf0d32964959")
