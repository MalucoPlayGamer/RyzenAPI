-- Lua provided by RyzenAPI
-- Game: Somny & Yawn: Dream Detectives

-- MAIN APPLICATION
addappid(1245060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1245061, 1, "99dd7f664effdd7bbdd25aeda95742d8d5f4d0f657ee110c9cd0cf0d32964959")

