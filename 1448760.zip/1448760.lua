-- Lua provided by RyzenAPI 
-- Game: The Plane Effect
addappid(1448760)
addappid(1448761, 1, "73e1a852f5c6d93f1af01352e9f45547663445eb558cb6b27cce56c3580aceac")
