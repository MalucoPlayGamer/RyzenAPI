-- Lua provided by RyzenAPI
-- Game: The Plane Effect

-- MAIN APPLICATION
addappid(1448760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1448761, 1, "73e1a852f5c6d93f1af01352e9f45547663445eb558cb6b27cce56c3580aceac")

