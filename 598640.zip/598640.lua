-- Lua provided by RyzenAPI
-- Game: AppID 598640

-- MAIN APPLICATION
addappid(598640)
addappid(782000)
addappid(782001)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(598641, 1, "9005709516bd635056a46ea46e70c28b3fd6ebdb77b5ee84d4ad599bd6dba0f9")
addappid(598643, 1, "e8a3d73270ed3ff3581bc46a08aa4b3d63818e6b3399f2012fd96d4a50cd31e9")

