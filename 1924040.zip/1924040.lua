-- Lua provided by RyzenAPI
-- Game: Succubus - Ukraine Support

-- MAIN APPLICATION
addappid(1924040)
-- Game: addappid(1924040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924040,0,"6e526caaf0232eb8d659c5b75643da7703ea62743dbc46398e49de5abb55a111")
