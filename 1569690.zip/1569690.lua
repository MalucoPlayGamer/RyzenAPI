-- Lua provided by RyzenAPI
-- Game: Game: Snapshot

-- MAIN APPLICATION
addappid(1569690)
-- Game: addappid(1569690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569691, 1, "23d9c75a6381426ce23f8b1ceae0283f1fe5c4ee794ebff73fc7bd2ecb17da3b")
