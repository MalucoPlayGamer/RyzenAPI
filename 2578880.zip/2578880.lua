-- Lua provided by RyzenAPI
-- Game: How to lose one's virginity

-- MAIN APPLICATION
addappid(2578880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578882,0,"b6a3a2e840a7b2137f48505a64614145e5491e30022dcb9e981bf075f7fd3b00")

