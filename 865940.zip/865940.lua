-- Lua provided by SkyAPI 
-- Game: AppID 865940
addappid(865940)
addappid(865941, 1, "124cdd7f3c79fe0b72f9304aee92959fedbb6f8a2d6b2d6507a77cc5d5b2dd49")
