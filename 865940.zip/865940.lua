-- Lua provided by RyzenAPI
-- Game: SNK 40th Anniversary Collection

-- MAIN APPLICATION
addappid(865940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(865941, 1, "124cdd7f3c79fe0b72f9304aee92959fedbb6f8a2d6b2d6507a77cc5d5b2dd49")

