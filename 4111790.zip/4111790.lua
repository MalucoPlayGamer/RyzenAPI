-- Lua provided by RyzenAPI
-- Game: Eroo Synth

-- MAIN APPLICATION
addappid(4111790)

-- MAIN APP DEPOTS / PACKAGES
addappid(4111791,0,"cd1c6a034549d645fe037372cfb64f5a4640d357b66f2938c1977fda6b414562")

