-- Lua provided by RyzenAPI
-- Game: AppID 2786530

-- MAIN APPLICATION
addappid(2786530)
-- Game: addappid(2786530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786531, 1, "67fb52a5421d23a62b2136ed8fb29a6fba189904948bea6effcbe003933a8866")
