-- Lua provided by RyzenAPI
-- Game: 1107620

-- MAIN APPLICATION
addappid(1107620)
-- Game: addappid(1107620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107621, 1, "4d973e816524d0e9fccef202e6d419fc3fd58109ee6d5859116b4795e8becda5")
