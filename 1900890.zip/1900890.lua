-- Lua provided by RyzenAPI
-- Game: Game: Redgar: The Space Viking

-- MAIN APPLICATION
addappid(1900890)
-- Game: addappid(1900890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900891, 1, "92b589dbab4e2b03d126555f8478c80bddae34a8b1c0e67d7520bbd0e07a83e5")
