-- Lua provided by RyzenAPI
-- Game: Game: FAP & CUM: Simulator 🔞💦

-- MAIN APPLICATION
addappid(2331970)
-- Game: addappid(2331970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331971, 1, "124ea04791ecc549e38d9075a242a54a5f4ae4171f10a48d9a9a11f0bf1a108b")
