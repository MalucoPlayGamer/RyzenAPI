-- Lua provided by RyzenAPI
-- Game: Moonlight Peaks

-- MAIN APPLICATION
addappid(2209900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209901,0,"01d7e2553cfbb6e74ba7875bc496c21df179b68c79905bef6f24dfbc33180749")
addappid(4892990,0,"f23cf3c15a3c6e18a5409540488640be30002f5056b9a6a65aa2e60df19950f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
