-- Lua provided by RyzenAPI
-- Game: Morbid: The Lords of Ire Official Art book

-- MAIN APPLICATION
addappid(2968360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968360,0,"397355ff73981aea4297593530ff93f52e4d6b37853dc80051ca9b0445d24c87")

