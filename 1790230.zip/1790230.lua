-- Lua provided by RyzenAPI
-- Game: Wallpaper Engine - Editor Extensions

-- MAIN APPLICATION
addappid(1790230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790230,0,"28aacfb757c396f07f861f189a2c2ec78653123de2177c05f94a792d1a3c8bfd")

