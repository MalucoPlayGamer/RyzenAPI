-- Lua provided by RyzenAPI
-- Game: 2893570

-- MAIN APPLICATION
addappid(2893570)
addappid(3707290)
addappid(3707300)
addappid(3707310)
addappid(3904130)
addappid(3904140)
addappid(3904280)
-- Game: addappid(2893570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893571, 1, "511f158856c1819c10a9d2916437455351f4fde9144e27c85cdbd64769037309")
