-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST I & II HD-2D Remake

-- MAIN APPLICATION
addappid(2893570)
addappid(3707290)
addappid(3707300)
addappid(3707310)
addappid(3904130)
addappid(3904140)
addappid(3904280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2893571, 1, "511f158856c1819c10a9d2916437455351f4fde9144e27c85cdbd64769037309")

