-- Lua provided by RyzenAPI
-- Game: addappid(2128940)

-- MAIN APPLICATION
addappid(2128940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128941, 1, "621c4bef8246ddd04d10b116798bb77487e959a63cbe208df4cf8ac39b34ca29")
