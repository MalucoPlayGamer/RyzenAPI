-- Lua provided by RyzenAPI
-- Game: THE 4 SINS

-- MAIN APPLICATION
addappid(2128940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2128941, 1, "621c4bef8246ddd04d10b116798bb77487e959a63cbe208df4cf8ac39b34ca29")

