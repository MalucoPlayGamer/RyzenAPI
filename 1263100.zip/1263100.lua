-- Lua provided by RyzenAPI
-- Game: 1263100

-- MAIN APPLICATION
addappid(1263100)
-- Game: addappid(1263100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263101, 1, "ccc24bdbaad68d36350e92f39f02c418584aa052be9b6541eb549481fff893ec")
