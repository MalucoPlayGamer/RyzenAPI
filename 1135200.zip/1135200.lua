-- Lua provided by RyzenAPI
-- Game: addappid(1135200)

-- MAIN APPLICATION
addappid(1135200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135201, 1, "5163ac6668ec971bb6843eab1baabf537d3f429b7db3890e3076906cac50744d")
