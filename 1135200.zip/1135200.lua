-- Lua provided by RyzenAPI
-- Game: Sokpop S03: soko loco

-- MAIN APPLICATION
addappid(1135200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135201, 1, "5163ac6668ec971bb6843eab1baabf537d3f429b7db3890e3076906cac50744d")
