-- Lua provided by RyzenAPI
-- Game: AppID 2936690

-- MAIN APPLICATION
addappid(2936690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936691, 1, "fc3a57f3a972cb720bde50121993c908ba6053f0b271dba98ce1c8a1f02e6bc7")

