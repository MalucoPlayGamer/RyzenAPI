-- Lua provided by RyzenAPI
-- Game: addappid(1267593)

-- MAIN APPLICATION
addappid(1267593)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267593,0,"01a00a43a8823de8c38fe8fcf6a09ce3398123d3a1fe9834e1cccaba00977062")
