-- Lua provided by RyzenAPI
-- Game: AppID 292570

-- MAIN APPLICATION
addappid(292570)

-- MAIN APP DEPOTS / PACKAGES
addappid(292571, 1, "6750a4a723965edd94d460d2ef4113a8b7cc016eaeea4ec19cbc0e6e9c2fd174")

