-- Lua provided by RyzenAPI
-- Game: Unstrong

-- MAIN APPLICATION
addappid(1841270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841271, 1, "7d5841e450cdbf3cef11804273e0ff70155a70898d71c43abd33141bcd60faa3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
