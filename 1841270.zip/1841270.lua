-- Lua provided by SkyAPI 
-- Game: Unstrong
addappid(1841270)
addappid(1841271, 1, "7d5841e450cdbf3cef11804273e0ff70155a70898d71c43abd33141bcd60faa3")
