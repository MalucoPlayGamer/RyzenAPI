-- Lua provided by RyzenAPI
-- Game: Unstrong

-- MAIN APPLICATION
addappid(1841270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841271, 1, "7d5841e450cdbf3cef11804273e0ff70155a70898d71c43abd33141bcd60faa3")
