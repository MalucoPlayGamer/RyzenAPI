-- Lua provided by RyzenAPI
-- Game: Crypt of the NecroDancer

-- MAIN APPLICATION
addappid(247080)

-- MAIN APP DEPOTS / PACKAGES
addappid(247081, 1, "5bce434354fea0c7503acbe00a19e3141a3d4a189f6dee25d259975dece40578")
addappid(247082, 1, "c6fe8c185bcb52ebee02fa7493e9c73fd547d108bb1a7ffd6ff82f2f3f3b80e9")
addappid(247083, 1, "0394a7c6c5a7dd0c0a45c9dc2db94c3aa8c299c833518cdf02f7dbe80c14f213")
addappid(247084, 1, "164f7f5000bdd485d1de898057c91571bc063162ea1e5eb272f95808b0a1e3f7")
addappid(247085, 1, "0bbb1af4bf7f57f4932a666fdafdd7d1843f3298da3aaf338f625f21726116cd")
addappid(247086, 1, "084a8e6f1cd43f57644dc8bcb45abcbeec55d0fc200d61ce9e8aa551128fbe96")
addappid(314681, 0, "86b107dfe99928f9ea794dcbcc527a198a9f4ed2fcb212d52a3ff02d5e966598")
addappid(379400, 0, "d9551f0dc69408c182ad45436ecba3c583e1dbccca7e19ff59d7716b867f2eaf")
addappid(554000, 0, "07ebfaa5ad8955c436c7094754b0258e6a211af2f13fc4397a244f1063c66feb")
addappid(554001, 0, "1a7ea174be8f2fa475bc29db73b46c4884536f3e98e1faea82e898abd27ca2a5")
addappid(554002, 0, "712a0f2fa5b5052b0c884e3209ce288bf3e217ec0447d3e377ca50cb58f03f7b")
addappid(1985571, 0, "bace7b3645458f6f6d8a58869742f3361c5237e46f18edae304b4bac8629392f")
addappid(2828720, 0, "4ddd83a880c452efd1f17d647698a2ce1068e125c97e54ce3e4da18526bb163e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2094810)
addappid(3884150)
addappid(4022920)
