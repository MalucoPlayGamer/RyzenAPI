-- Lua provided by RyzenAPI
-- Game: Game: AppID 628460

-- MAIN APPLICATION
addappid(628460)
-- Game: addappid(628460)

-- MAIN APP DEPOTS / PACKAGES
addappid(628461, 1, "fe0c8c9c62a671c1b493b5835ab5cc9c3ba5fb5b4bcbdce150b780d2553bf3ad")
