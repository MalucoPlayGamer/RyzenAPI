-- Lua provided by SkyAPI 
-- Game: AppID 1800830
addappid(1800830)
addappid(1800831, 1, "d00c110cf5d901004aa111b197f3c7691dc8e5ea71778d992f42edced0268f5c")
