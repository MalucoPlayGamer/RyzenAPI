-- Lua provided by RyzenAPI
-- Game: addappid(1800830)

-- MAIN APPLICATION
addappid(1800830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800831, 1, "d00c110cf5d901004aa111b197f3c7691dc8e5ea71778d992f42edced0268f5c")
