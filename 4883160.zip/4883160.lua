-- Lua provided by RyzenAPI
-- Game: Haunted Laia

-- MAIN APPLICATION
addappid(4883160) -- Haunted Laia

-- MAIN APP DEPOTS / PACKAGES
addappid(4883161, 1, "5b134e2b2f9343a40b1fa3aeacdca0db241f5560f1ccbc1c3abe36b2f2a55a38") -- Depot 4883161
