-- Lua provided by RyzenAPI 
-- Game: Drake Hollow
addappid(739650)
addappid(739651, 1, "552923721d39995578b2fbe8710de847045c8409ce877be51229c793fdf5f068")
