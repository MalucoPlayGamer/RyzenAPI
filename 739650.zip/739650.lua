-- Lua provided by RyzenAPI
-- Game: Game: Drake Hollow

-- MAIN APPLICATION
addappid(739650)
-- Game: addappid(739650)

-- MAIN APP DEPOTS / PACKAGES
addappid(739651, 1, "552923721d39995578b2fbe8710de847045c8409ce877be51229c793fdf5f068")
