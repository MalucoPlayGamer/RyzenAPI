-- Lua provided by RyzenAPI
-- Game: The Old Woman | 無言老婆

-- MAIN APPLICATION
addappid(3653910)
-- Game: addappid(3653910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3653911, 1, "98e8bd33910992f60abadf4af8054136615bb7aaacc3de8abeb51a3e0d95e2cc")
