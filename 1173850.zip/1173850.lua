-- Lua provided by RyzenAPI
-- Game: Zombie Panic In Wonderland DX

-- MAIN APPLICATION
addappid(1173850)
addappid(1184270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984,0,"df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229006,0,"9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416")

