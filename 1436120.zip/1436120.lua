-- Lua provided by RyzenAPI
-- Game: Game: AppID 1436120

-- MAIN APPLICATION
addappid(1436120)
-- Game: addappid(1436120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436121, 1, "9e683e7c614aede49c33ec583004dc7f0c580b2890ab26fa8820b99b7b337f8b")
addappid(1436122, 1, "60cb7ca21e88f4a5623e6934c771f25158734fbdc0af50ec6c58bddf89993a4d")
