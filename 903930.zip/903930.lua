-- 903930's Lua and Manifest Created by Hubcap Manifest
-- Brigador Killers
-- Created: August 20, 2026 at 14:22:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(903930, 1, "9ed0315f706bcd75696bc98f00317cc9fa6a1e81f381850723e0a0d91a6e8e9e") -- Brigador Killers
-- MAIN APP DEPOTS
addappid(903931, 1, "1ccbc7e4d21a7b3aac2f43e395c1a5dbccbde8c242672b0fe9a1846cb52da118") -- Depot 903931
setManifestid(903931, "5584554007627815482", 2879597196)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(903932) -- Depot 903932 (empty depot)
-- addappid(903934) -- Depot 903934 (empty depot)