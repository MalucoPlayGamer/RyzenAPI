-- Lua provided by RyzenAPI
-- Game: Brigador Killers

-- MAIN APPLICATION
-- addappid(903932) -- Depot 903932 (empty depot)
-- addappid(903934) -- Depot 903934 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(903930, 1, "9ed0315f706bcd75696bc98f00317cc9fa6a1e81f381850723e0a0d91a6e8e9e") -- Brigador Killers
addappid(903931, 1, "1ccbc7e4d21a7b3aac2f43e395c1a5dbccbde8c242672b0fe9a1846cb52da118") -- Depot 903931

