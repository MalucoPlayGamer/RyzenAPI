-- Lua provided by RyzenAPI
-- Game: Balance 97.261/100 Demo

-- MAIN APPLICATION
addappid(2301680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301681, 1, "cdeaafe150a83eb9d7fcf33f56473d28327194dd7011660577dc1f9606dac6eb")
