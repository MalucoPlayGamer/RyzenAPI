-- Lua provided by RyzenAPI
-- Game: Tales of Mahabharata

-- MAIN APPLICATION
addappid(867920)

-- MAIN APP DEPOTS / PACKAGES
addappid(867921,0,"95d7b1c5f033ec97663bccd38cb046a7fc2453445893716c0c9695f0f1bbfa47")

