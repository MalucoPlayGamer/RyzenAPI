-- Lua provided by RyzenAPI
-- Game: 2458330

-- MAIN APPLICATION
addappid(2458330)
-- Game: addappid(2458330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458331, 1, "977ec52c6d141768399b872ebdb2c47f503572898a0a2dbb9a9ae9aaa1c8ac13")
