-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - MGC Animations MZ MegaPack 1

-- MAIN APPLICATION
addappid(1853740)
-- Game: addappid(1853740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853740,0,"504af37a365cafc56d07937fb4e690939014378e7849361d8c73b4dfb17c2ae2")
