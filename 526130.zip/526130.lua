-- Lua provided by RyzenAPI
-- Game: 526130

-- MAIN APPLICATION
addappid(526130)
-- Game: addappid(526130)

-- MAIN APP DEPOTS / PACKAGES
addappid(526131, 1, "7219bd1c799efed843cb41b0551573432f7b37330b285e66fb85ffdd78250301")
