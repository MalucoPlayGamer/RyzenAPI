-- Lua provided by RyzenAPI
-- Game: Drug Lord Tycoon

-- MAIN APPLICATION
addappid(2450700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450701, 1, "4a3a2ae39476d7a795b84d47d587540dff59b607a35d2e34e6470823b37c7ff9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
