-- Lua provided by RyzenAPI 
-- Game: Drug Lord Tycoon
addappid(2450700)
addappid(2450701, 1, "4a3a2ae39476d7a795b84d47d587540dff59b607a35d2e34e6470823b37c7ff9")
