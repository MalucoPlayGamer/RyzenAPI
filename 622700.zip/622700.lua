-- Lua provided by RyzenAPI
-- Game: War Heroes: Invasion

-- MAIN APPLICATION
addappid(622700)

-- MAIN APP DEPOTS / PACKAGES
addappid(622701, 1, "cee04c1216deba2a8a5148a4f96b2824df964e4feca32b2c66f331181c8f136c")

