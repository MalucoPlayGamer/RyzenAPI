-- Lua provided by RyzenAPI
-- Game: Romance of the Three Kingdoms VIII with Power Up Kit

-- MAIN APPLICATION
addappid(628040)
-- Game: addappid(628040)

-- MAIN APP DEPOTS / PACKAGES
addappid(628041, 1, "ecfab0e9a76241539823be0e6caf053eae6fd66c02c4266321b2ce0ffeca25bc")
addappid(628042, 1, "8d04310e1659bd522550a1c59ab8f5f80b9eb1e92f98adf2527bc608a9bd5007")
