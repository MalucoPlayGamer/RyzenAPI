-- Lua provided by RyzenAPI
-- Game: Khan VS Kahn

-- MAIN APPLICATION
addappid(1020330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020331, 1, "37eed2e70f7e24eb0c3e683fdc88793297bc64d47ec08405a7c2c9ba0551a83f")
addappid(1020332, 1, "6d5201ab30e55cb27a2b814b7630d14bcfa0d5b1aaf7f96e63c7ed93f2acf1fb")
addappid(1020333, 1, "cadfe8e6f1ef02892b1fd3025cd5259ae20e134fdcad64bd8fad56adc4ff2273")
