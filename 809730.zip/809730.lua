-- Lua provided by RyzenAPI
-- Game: FISHERY

-- MAIN APPLICATION
addappid(809730)

-- MAIN APP DEPOTS / PACKAGES
addappid(809734,0,"dca6a87c8c06259b75191ae2dc97f8d8ff9fc520afe615cccc60357a5faf3818")
