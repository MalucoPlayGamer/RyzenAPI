-- Lua provided by RyzenAPI
-- Game: Notanote

-- MAIN APPLICATION
addappid(2687160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687161, 1, "36d3a361d1ca80e9898e5c0bb59cfabda66df74b9ea072415c83e51712b060be")
