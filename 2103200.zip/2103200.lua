-- Lua provided by RyzenAPI
-- Game: Toynip

-- MAIN APPLICATION
addappid(2103200)
-- Game: addappid(2103200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103201, 1, "54f1c0e4eb58cb80c6e36c82ee7a039cb3eb0df4139fefe642432615363802df")
