-- Lua provided by SkyAPI 
-- Game: Toynip
addappid(2103200)
addappid(2103201, 1, "54f1c0e4eb58cb80c6e36c82ee7a039cb3eb0df4139fefe642432615363802df")
