-- Lua provided by RyzenAPI
-- Game: Toynip

-- MAIN APPLICATION
addappid(2103200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103201, 1, "54f1c0e4eb58cb80c6e36c82ee7a039cb3eb0df4139fefe642432615363802df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
