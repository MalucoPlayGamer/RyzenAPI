-- Lua provided by RyzenAPI
-- Game: Game: AppID 561450

-- MAIN APPLICATION
addappid(561450)
-- Game: addappid(561450)

-- MAIN APP DEPOTS / PACKAGES
addappid(561451, 1, "1d816638bf9554794982e997654e5df4fa355989fdb215e725c5534be8336c58")
