-- Lua provided by RyzenAPI
-- Game: IZON.

-- MAIN APPLICATION
addappid(3009480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009481, 1, "a0ea24c20d5bc13af816fd5d9ef157ea2add504c3e489967570bd4e68fd95e8b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
