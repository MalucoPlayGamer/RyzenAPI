-- Lua provided by RyzenAPI
-- Game: addappid(3009480)

-- MAIN APPLICATION
addappid(3009480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009481, 1, "a0ea24c20d5bc13af816fd5d9ef157ea2add504c3e489967570bd4e68fd95e8b")
