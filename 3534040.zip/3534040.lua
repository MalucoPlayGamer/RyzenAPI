-- Lua provided by RyzenAPI
-- Game: Mirror Quest Dog and Cat

-- MAIN APPLICATION
addappid(3534040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3534041, 1, "281bea067d240e9ac479cb86d90f4f8bf7027264319eb382dd0e0ff86c2ac6b6")

