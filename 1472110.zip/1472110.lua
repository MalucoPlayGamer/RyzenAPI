-- Lua provided by SkyAPI 
-- Game: TIRELESS: Prepare for the Adrenaline Playtest
addappid(1472110)
addappid(1472111, 1, "4a258f5dc208b3dfa36e7d06b6a94034b38f35b64b5c95b21208168f8e403051")
