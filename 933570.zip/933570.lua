-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - ω-Force 20th Anniversary Concert BGM Pack

-- MAIN APPLICATION
addappid(933570)
-- Game: addappid(933570)

-- MAIN APP DEPOTS / PACKAGES
addappid(933570,0,"73501b386f9ea9eccd6ce966f58651c8df4fd49e846eff95e461d689706e6560")
