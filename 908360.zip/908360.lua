-- Lua provided by RyzenAPI
-- Game: 908360

-- MAIN APPLICATION
addappid(908360)
-- Game: addappid(908360)

-- MAIN APP DEPOTS / PACKAGES
addappid(908361, 1, "f004ab45afada2c657ed7a32dd0a281a9b0df9056fe522c9d4c74390d82b5b9d")
