-- Lua provided by RyzenAPI
-- Game: How Much Items - Plants

-- MAIN APPLICATION
addappid(3471100)
-- Game: addappid(3471100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471101, 1, "b0679bf53d72d63b4fad8977e0aae4b85072491b27d090a4091be7b05048f17b")
