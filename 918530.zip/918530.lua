-- Lua provided by RyzenAPI
-- Game: Game: The Dark Room

-- MAIN APPLICATION
addappid(918530)
-- Game: addappid(918530)

-- MAIN APP DEPOTS / PACKAGES
addappid(918531, 1, "5a48a804127f5f0d2afce2cfa849cd308ed10186ef7795a89baf852549eafce0")
