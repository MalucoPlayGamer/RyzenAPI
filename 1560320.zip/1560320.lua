-- Lua provided by RyzenAPI
-- Game: Endless Furry Pinball 2D

-- MAIN APPLICATION
addappid(1560320)
-- Game: addappid(1560320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560321, 1, "173d87eff0cc6b4983b7bc5cfa6b7926be8401fef842c8af2b4389af565ce6ca")
