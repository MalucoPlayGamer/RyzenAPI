-- Lua provided by RyzenAPI
-- Game: addappid(936790)

-- MAIN APPLICATION
addappid(936790)

-- MAIN APP DEPOTS / PACKAGES
addappid(936791, 1, "1fc3971cce72a8ff20a3b392694cfa1d06b4c13eda5b6ed0fa739578a6f5aa16")
addappid(936792, 1, "67b78f2a5ac997bb1bb5cc22af0451a592a1e08dd674e104b4025438d7e66fcb")
addappid(1450570, 0, "82f0127348d44cf84f149e40cf7b6ba7f6cd219e09f8a2d841f66298eb13bfea")
addappid(1450571, 0, "ec0d0cf5a7ba2f943e0be4865ab3c82db329b0613123c4294739c7f816ddf6fd")
addappid(1450572, 0, "beba6ea27606af345317455d0a149f4539bc9bbafa6c562ab7df443993512a2a")
