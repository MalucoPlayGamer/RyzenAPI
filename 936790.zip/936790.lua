-- Lua provided by RyzenAPI
-- Game: Life is Strange: True Colors

-- MAIN APPLICATION
addappid(936790)
addappid(1571390)

-- MAIN APP DEPOTS / PACKAGES
addappid(936791,0,"1fc3971cce72a8ff20a3b392694cfa1d06b4c13eda5b6ed0fa739578a6f5aa16")
addappid(936792,0,"67b78f2a5ac997bb1bb5cc22af0451a592a1e08dd674e104b4025438d7e66fcb")
addappid(1450570,0,"82f0127348d44cf84f149e40cf7b6ba7f6cd219e09f8a2d841f66298eb13bfea")
addappid(1450571,0,"ec0d0cf5a7ba2f943e0be4865ab3c82db329b0613123c4294739c7f816ddf6fd")
addappid(1450572,0,"beba6ea27606af345317455d0a149f4539bc9bbafa6c562ab7df443993512a2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
