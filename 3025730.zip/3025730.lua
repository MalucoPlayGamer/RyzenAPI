-- Lua provided by RyzenAPI
-- Game: addappid(3025730)

-- MAIN APPLICATION
addappid(3025730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025731, 1, "2bfc73618ced27a8ec26795cdc5d9010b359e84db5eba0cb5638bb69c553b4d0")
