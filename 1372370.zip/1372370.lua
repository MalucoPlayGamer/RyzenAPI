-- Lua provided by RyzenAPI
-- Game: addappid(1372370)

-- MAIN APPLICATION
addappid(1372370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372371, 1, "06bbd59b71587769709159fcde853f360dcb0a115f3d8013aac3ec9251cb5e70")
