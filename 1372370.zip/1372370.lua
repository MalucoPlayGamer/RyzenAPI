-- Lua provided by RyzenAPI
-- Game: Last of Ass

-- MAIN APPLICATION
addappid(1372370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372371, 1, "06bbd59b71587769709159fcde853f360dcb0a115f3d8013aac3ec9251cb5e70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
