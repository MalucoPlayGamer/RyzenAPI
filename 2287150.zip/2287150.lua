-- Lua provided by RyzenAPI
-- Game: Revenge of the Mage

-- MAIN APPLICATION
addappid(2287150)
-- Game: addappid(2287150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287151, 1, "de7dd5e4cacdce00287697122fff8e3db28e280079e8581365ffec726a7da42c")
