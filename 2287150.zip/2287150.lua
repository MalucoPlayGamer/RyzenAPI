-- Lua provided by RyzenAPI
-- Game: Revenge of the Mage

-- MAIN APPLICATION
addappid(2287150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287151, 1, "de7dd5e4cacdce00287697122fff8e3db28e280079e8581365ffec726a7da42c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
