-- Lua provided by RyzenAPI
-- Game: Many Buttons to Press

-- MAIN APPLICATION
addappid(1841700)
-- Game: addappid(1841700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841702,0,"ab2873982ad74dc9a5cf4846f74c1cd7c8ec56910b56d3ca3672d0e049c50852")
