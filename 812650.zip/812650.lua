-- Lua provided by SkyAPI 
-- Game: Data Defense
addappid(812650)
addappid(812651, 1, "fc9d090e17408f168bdf275877bdf51be339dadc9acb9e5ee354554f68ea7ccd")
