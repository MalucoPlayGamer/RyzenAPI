-- Lua provided by RyzenAPI
-- Game: Game: Data Defense

-- MAIN APPLICATION
addappid(812650)
-- Game: addappid(812650)

-- MAIN APP DEPOTS / PACKAGES
addappid(812651, 1, "fc9d090e17408f168bdf275877bdf51be339dadc9acb9e5ee354554f68ea7ccd")
