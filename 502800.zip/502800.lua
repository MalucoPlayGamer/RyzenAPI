-- Lua provided by RyzenAPI
-- Game: AppID 502800

-- MAIN APPLICATION
addappid(502800)

-- MAIN APP DEPOTS / PACKAGES
addappid(502801, 1, "fd7bae3f34fc7207ee55e8bd7c8148f5ca2115a52aa9792880292d45a698b48b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(576300)
addappid(582040)
addappid(588260)
addappid(588261)
addappid(588262)
addappid(588263)
addappid(588300)
addappid(588301)
addappid(588960)
addappid(588961)
addappid(588962)
addappid(588963)
addappid(588964)
