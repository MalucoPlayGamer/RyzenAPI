-- Lua provided by RyzenAPI
-- Game: AppID 502800

-- MAIN APPLICATION
addappid(502800)

-- MAIN APP DEPOTS / PACKAGES
addappid(502801, 1, "fd7bae3f34fc7207ee55e8bd7c8148f5ca2115a52aa9792880292d45a698b48b")

