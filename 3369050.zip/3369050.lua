-- Lua provided by RyzenAPI
-- Game: Art Detective: Hidden in Gusu

-- MAIN APPLICATION
addappid(3369050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369051, 1, "08201e7df2d87aa386a0a5cc281edb09ee4d511f375d0fd14e471f643efc4bed")

