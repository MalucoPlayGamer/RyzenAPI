-- Lua provided by RyzenAPI
-- Game: 1504250

-- MAIN APPLICATION
addappid(1504250)
-- Game: addappid(1504250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504251, 1, "f5d2af9c3726eeb9e48fe9859bb745685d8d22289eca2516d0c6eb6fec179e69")
