-- Lua provided by RyzenAPI 
-- Game: Paper Planet
addappid(1504250)
addappid(1504251, 1, "f5d2af9c3726eeb9e48fe9859bb745685d8d22289eca2516d0c6eb6fec179e69")
