-- Lua provided by RyzenAPI
-- Game: Crossing Souls

-- MAIN APPLICATION
addappid(331690)
-- Game: addappid(331690)

-- MAIN APP DEPOTS / PACKAGES
addappid(331691, 1, "3b28eedcca1659f596864d971ad7d047a5e57e238c8b34c62a980870001b9790")
addappid(331692, 1, "81fcc5ce4dfe5e90415abc0e88c5c43057b118a5976592f6cc61abdf73398f8a")
addappid(331693, 1, "c0b0e6f0b564d1ef41bf371cdd39f7741c339ce6550dae73ad7400d9d7b1cd49")
addappid(799820, 0, "893c58218df254c951a8a6872799fe3b27a97bf93df03b883fa87561be053a53")
