-- Lua provided by RyzenAPI
-- Game: Cao Pi - Officer Ticket / 曹丕使用券

-- MAIN APPLICATION
addappid(956732)

-- MAIN APP DEPOTS / PACKAGES
addappid(956732,0,"9b5026756fac28b38b5563b28421be97c9621706b766faa642c19cd780926841")
