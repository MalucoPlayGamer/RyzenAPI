-- Lua provided by RyzenAPI
-- Game: Jesus Christ RPG Trilogy

-- MAIN APPLICATION
addappid(449040)
-- Game: addappid(449040)

-- MAIN APP DEPOTS / PACKAGES
addappid(449041, 1, "5f36f0832bc16e9b3a0e725898b99344cf02be39f28a49a86a7dde52ad196283")
addappid(455451, 0, "2c407e9eef1a51c02d150d57869016f33be25afcecea355d6059dca23be34957")
