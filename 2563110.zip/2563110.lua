-- Lua provided by RyzenAPI
-- Game: 2563110

-- MAIN APPLICATION
addappid(2563110)
-- Game: addappid(2563110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563111, 1, "c2452c4a7833b185b2dfddb9dd721c5d22620f395f094b9470c72da21373166b")
