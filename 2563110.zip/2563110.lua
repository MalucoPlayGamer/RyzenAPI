-- Lua provided by RyzenAPI 
-- Game: Backrooms:Run For Your Life Demo
addappid(2563110)
addappid(2563111, 1, "c2452c4a7833b185b2dfddb9dd721c5d22620f395f094b9470c72da21373166b")
