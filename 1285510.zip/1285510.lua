-- Lua provided by RyzenAPI
-- Game: AppID 1285510

-- MAIN APPLICATION
addappid(1285510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285511, 1, "a6333dba8dbbd4fa2d6963c6a2d1b972d64b173ce63ac046ffbd1ce9a591acac")

