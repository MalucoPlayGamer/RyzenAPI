-- Lua provided by RyzenAPI
-- Game: Game: Unbreakable Vr Runner

-- MAIN APPLICATION
addappid(494310)
-- Game: addappid(494310)

-- MAIN APP DEPOTS / PACKAGES
addappid(494311, 1, "45aaf12b3934d8e55bd12adadd41fe02f2ff5c4bd6703cba3abf50e82557115d")
