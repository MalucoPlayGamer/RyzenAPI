-- Lua provided by RyzenAPI
-- Game: Game: Smells Like a Mushroom Demo

-- MAIN APPLICATION
addappid(2473460)
-- Game: addappid(2473460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473461, 1, "262d3ea9c97e98b899be704bd936d6731a89c5b22f78e57e18fac0e446855794")
