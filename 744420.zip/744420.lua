-- Lua provided by RyzenAPI
-- Game: Adventures Of Pipi

-- MAIN APPLICATION
addappid(744420)
-- Game: addappid(744420)

-- MAIN APP DEPOTS / PACKAGES
addappid(744421, 1, "ea6028f179ec981592a94ffbc1ba7791d60b4ea9747afcbec70f4b85a748bedd")
