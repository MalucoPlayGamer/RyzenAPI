-- Lua provided by RyzenAPI
-- Game: Game: Red Comrades 3: Return of Alaska. Reloaded

-- MAIN APPLICATION
addappid(546220)
-- Game: addappid(546220)

-- MAIN APP DEPOTS / PACKAGES
addappid(546221, 1, "b744d30c693041db167dd73f04fabc67e93fdef5dc8ab2bccc9c8ded271d9888")
