-- Lua provided by RyzenAPI
-- Game: Digimon Story Time Stranger

-- MAIN APPLICATION
addappid(1984270)
addappid(3524390)
addappid(3524400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984271, 1, "b0aa8ddfef2996e3122b0bda1d02f7ceb28f608ac8c1d853e6793790aaab8860")
addappid(3524240, 0, "f06dc8a525a2fb5e03453da570b80915bd7c02daae714ac854c86283a2bc4e18")
addappid(3524250, 0, "b6c098c1cdd8687907373e2a6e59446445aafca92e10fe4da2c59481f0448f24")
addappid(3524300, 0, "0ae80de6e7b2f3ec166de6a98b3f6a018af9fba6c54f144916d1f4ab07671b2c")
addappid(3524310, 0, "5f8a85a36740263fe78affe346fd7b0c18eb7ad2a51537a2c875f64fa080cbf1")
addappid(3524320, 0, "0da086161abea2f6ce0863a530fefc41ac12993fb4308ff16301926398803a27")
addappid(3524330, 0, "2358d5ff200cefb1eef6f77277f04089a01daaea4418cd48d530b4de3fe53f61")
addappid(3524340, 0, "5441f08ccf7ebad6314bac9d071ba47a41e709f4000e121004752959138bb2dc")
addappid(3524350, 0, "388eb5d2862631b327cd83e312bc69e3f14ecf6087a6a2ec0860f20df764139d")
addappid(3524360, 0, "9ac71aa654d8726aaf514236b138ac5c075854dd8f33abbfeb1b4316302c7f7b")
addappid(3524370, 0, "a20f41adefa6edd0b1a0644a6e359437cc9476624a4e80b6b31d90c893fb3577")
addappid(3524380, 0, "4ef7dc743aea30597adbffc2215a364e119c16ab160dc2f20ae358296d12f4bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3524260)
addappid(3524270)
addappid(3524290)
