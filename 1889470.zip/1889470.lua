-- Lua provided by RyzenAPI
-- Game: Half-Life Decay: Solo Mission Demo

-- MAIN APPLICATION
addappid(1889470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889471, 1, "636e1d1ca1fc4281690a0c051d03b3839b9350aca870ba97b33b279402b793fb")

