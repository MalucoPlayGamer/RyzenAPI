-- Lua provided by RyzenAPI
-- Game: 重装无限·Metal Infinite

-- MAIN APPLICATION
addappid(1304320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304321, 1, "cebb86b85f3f22b4aebefa3894d617fe0c75272d755bdd8c863cbf0583b11040")
