-- Lua provided by RyzenAPI
-- Game: GetsuFumaDen

-- MAIN APPLICATION
addappid(1530910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1530911, 1, "177fbc93d65bcf2db512f49fd0dd4560593efe48d0da37369157dd2b231f19c5")
