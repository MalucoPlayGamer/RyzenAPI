-- Lua provided by RyzenAPI
-- Game: 1530910

-- MAIN APPLICATION
addappid(1530910)
-- Game: addappid(1530910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530911, 1, "177fbc93d65bcf2db512f49fd0dd4560593efe48d0da37369157dd2b231f19c5")
