-- Lua provided by RyzenAPI
-- Game: Fetish Locator Week Two

-- MAIN APPLICATION
addappid(1684170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684171, 1, "9e8c76fd782e5ae2fdc981a6fb4713ac041aa58509de543ba6843fe56b6422c2")
addappid(1805600, 0, "de244818877047e116733eb4a3b7968055ffb5e17384448940eb6b80159e5d3f")

