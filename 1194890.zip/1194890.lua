-- Lua provided by RyzenAPI
-- Game: AppID 1194890

-- MAIN APPLICATION
addappid(1194890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194891, 1, "1dee4f3886fbae0d3e48f3db3d124164838700a648c99747c887792935981723")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
