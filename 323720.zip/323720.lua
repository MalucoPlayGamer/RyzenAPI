-- Lua provided by RyzenAPI 
-- Game: AppID 323720
addappid(323720)
addappid(323721, 1, "0bff0a3a392b9160402e8122d6be2b3049ccf6def9df7ea1a4e90475d67d44d4")
addappid(323722, 1, "6a8fdc09e7d22f204c376e68d69c57c805b01fcc25515d0d18e54a4c995a723e")
addappid(323723, 1, "5bb89f06d58dc4a51e8bedab8f2bc84bf169a610dcff3e86aa987f3e13867450")
