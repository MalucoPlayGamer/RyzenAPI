-- Lua provided by RyzenAPI
-- Game: Decay - The Mare

-- MAIN APPLICATION
addappid(323720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(323721, 1, "0bff0a3a392b9160402e8122d6be2b3049ccf6def9df7ea1a4e90475d67d44d4")
addappid(323722, 1, "6a8fdc09e7d22f204c376e68d69c57c805b01fcc25515d0d18e54a4c995a723e")
addappid(323723, 1, "5bb89f06d58dc4a51e8bedab8f2bc84bf169a610dcff3e86aa987f3e13867450")

