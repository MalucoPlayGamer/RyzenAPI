-- Lua provided by RyzenAPI
-- Game: addappid(857340)

-- MAIN APPLICATION
addappid(857340)

-- MAIN APP DEPOTS / PACKAGES
addappid(857341, 1, "36c41787d810282fd03f759c8678035051fa74d7cc95eed125b4dccb99931d21")
