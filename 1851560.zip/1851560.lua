-- Lua provided by RyzenAPI
-- Game: Stillborn Slayer

-- MAIN APPLICATION
addappid(1851560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851561, 1, "54b1a95190411d1b85d9aeca78faee78857b615257b89e12969a98fc615604b9")
