-- Lua provided by RyzenAPI
-- Game: 1760840

-- MAIN APPLICATION
addappid(1760840)
-- Game: addappid(1760840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760841, 1, "cf65a5f944f5c931c7345d123a8ad33acee1758ad127b37e18a267d21310b662")
