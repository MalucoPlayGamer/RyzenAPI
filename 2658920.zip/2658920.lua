-- Lua provided by RyzenAPI
-- Game: Staffer Reborn

-- MAIN APPLICATION
addappid(2658920)
addappid(2658923)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658922,0,"59d82b64a0029b28c0395694c717702474f2e13654095ac767b4c7eed3a92b84")

