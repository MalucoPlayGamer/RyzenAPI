-- Lua provided by RyzenAPI
-- Game: addappid(833880)

-- MAIN APPLICATION
addappid(833880)

-- MAIN APP DEPOTS / PACKAGES
addappid(833881, 1, "65db85451daa045f123576a7ee49d9ff1be5c9b789bca7832439dac31e8b7112")
