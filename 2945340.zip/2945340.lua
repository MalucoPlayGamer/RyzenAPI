-- Lua provided by RyzenAPI
-- Game: 虎馬 / Trauma

-- MAIN APPLICATION
addappid(2945340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945341, 1, "af1728f474c5a2464a968990cfb3e13375785052022b02850f011eb66dd16c3c")

