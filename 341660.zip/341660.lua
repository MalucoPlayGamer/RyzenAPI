-- Lua provided by RyzenAPI
-- Game: addappid(341660)

-- MAIN APPLICATION
addappid(341660)

-- MAIN APP DEPOTS / PACKAGES
addappid(341662,0,"aab0903f31c4eb881ab46cc4c3bc8f14ec51deadcf949da3dfb484ffc623ed83")
addappid(341663,0,"310b0658e9b414827cc420c3eeb2de4a0c8150d1b57ca02bd97dd19e0127e87c")
