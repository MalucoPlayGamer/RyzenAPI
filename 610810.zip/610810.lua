-- Lua provided by RyzenAPI
-- Game: Your Friend Hana

-- MAIN APPLICATION
addappid(610810)

-- MAIN APP DEPOTS / PACKAGES
addappid(610811, 1, "249bfcc8f2865e36968ec5dc0aeca330557908342ea15a166c5060104e2b885d")
