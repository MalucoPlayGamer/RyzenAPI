-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2020 Demo

-- MAIN APPLICATION
addappid(1317910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317911, 1, "9d017df43458e9e7aa1e7370e308cb39bc988f80d8d786baf7529e2fca67e253")

