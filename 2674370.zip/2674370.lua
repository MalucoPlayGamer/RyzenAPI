-- Lua provided by RyzenAPI
-- Game: Sugar Lust Harem

-- MAIN APPLICATION
addappid(2674370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674371, 1, "9f4bdb4cf3e34e4a051188fd133dd0ac46ce675caf8eeeafce782c3205d5589d")

