-- Lua provided by RyzenAPI
-- Game: Rescuer

-- MAIN APPLICATION
addappid(1606610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606611, 1, "4b0b01f61eb548d129c9d69ae1e37160b92703f05eb90446a8034d7fa3cc95c3")

