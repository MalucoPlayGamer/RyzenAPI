-- Lua provided by RyzenAPI
-- Game: Labyrinthine Dreams

-- MAIN APPLICATION
addappid(278570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(278571, 1, "efe1c3911d9c05ebed87f66a1774c18b8d003ee6d4df83e0a938f7b38c1ca639")
addappid(372140, 0, "45dbd8c13201b02b6fab4a1f7c2bec47b2dcf38ebbd1e8b65e3c203ec355e274")

