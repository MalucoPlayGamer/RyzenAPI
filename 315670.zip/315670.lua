-- Lua provided by RyzenAPI
-- Game: 315670

-- MAIN APPLICATION
addappid(315670)
-- Game: addappid(315670)

-- MAIN APP DEPOTS / PACKAGES
addappid(315671, 1, "8618f56348c4466803cd62ac10a446a199c09265330c6eebfe76fc5e9799504e")
