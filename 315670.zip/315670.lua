-- Lua provided by RyzenAPI
-- Game: Raiden III Digital Edition

-- MAIN APPLICATION
addappid(315670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(315671, 1, "8618f56348c4466803cd62ac10a446a199c09265330c6eebfe76fc5e9799504e")

