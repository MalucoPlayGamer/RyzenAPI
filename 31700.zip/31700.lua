-- Lua provided by RyzenAPI
-- Game: Game: AppID 31700

-- MAIN APPLICATION
addappid(31700)
-- Game: addappid(31700)

-- MAIN APP DEPOTS / PACKAGES
addappid(31701, 1, "c161f5d7bfa3ee2f2c1c8457bbd95ef37d80864124b7ab589120b92deaee4497")
addappid(31702, 1, "6d17627b0ec5aef001022dfd4f46bb2fa5fc4718b638ee66173ad3b5ba329da2")
addappid(31703, 1, "9d2a2d2ee3027a68d2917cdc9dd7955fc8aeaa961c7cb1ffddcbef1e2dc1f5c5")
