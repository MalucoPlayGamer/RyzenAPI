-- Lua provided by RyzenAPI
-- Game: Game: AppID 35030

-- MAIN APPLICATION
addappid(35030)
-- Game: addappid(35030)

-- MAIN APP DEPOTS / PACKAGES
addappid(35031, 1, "c852263afc7a3284f5f7c1335336866393e24afcd2fc7229c22c8f03f6fd4f02")
addappid(35032, 1, "961009ac96219a0689ecc94f15505537f5ac38b604cf4ea6344868f60a45b3b6")
addappid(35036, 1, "fee2c8a5cf2a02ec11cad6f1937593486fd60e8f852b0eb2cb410a716a1007db")
