-- Lua provided by RyzenAPI
-- Game: RHEM I SE: The Mysterious Land

-- MAIN APPLICATION
addappid(656900)

-- MAIN APP DEPOTS / PACKAGES
addappid(656901, 1, "715200815d0ce3913d406519c4868ffe4bb9d0254dc0104a217b575f99b3403d")

