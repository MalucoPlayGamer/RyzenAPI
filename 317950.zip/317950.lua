-- Lua provided by RyzenAPI
-- Game: KEL Reaper of Entropy

-- MAIN APPLICATION
addappid(317950)
-- Game: addappid(317950)

-- MAIN APP DEPOTS / PACKAGES
addappid(317951, 1, "65cd8032de53325999580cf725f82c0cb2edb83e76cd81e382818050c7f3d44b")
