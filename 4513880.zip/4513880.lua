-- Lua provided by RyzenAPI
-- Game: Could You Be a Gal Master?

-- MAIN APPLICATION
addappid(4513880)

-- MAIN APP DEPOTS / PACKAGES
addappid(4513881,0,"6461ee2c7a6679cce446b4ef8dd85820ef19afec5fc0bbb1c42b5e2404a6a5e7")

