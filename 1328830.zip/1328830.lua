-- Lua provided by RyzenAPI
-- Game: Jumper Starman

-- MAIN APPLICATION
addappid(1328830)
-- Game: addappid(1328830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328831, 1, "c4ac05cbdf629bacfda31fdee68fadafb6ea6e4b2e49c6db384eb15d8e1343ad")
