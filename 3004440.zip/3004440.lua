-- Lua provided by RyzenAPI
-- Game: #BLUD Soundtrack

-- MAIN APPLICATION
addappid(3004440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004441, 1, "0d2678b5bfb8b2a106728fbe33897c8e67d50449123f0b1c77d0e391ac73d2ba")
