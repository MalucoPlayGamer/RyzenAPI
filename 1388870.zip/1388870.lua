-- Lua provided by RyzenAPI
-- Game: Arcade Paradise

-- MAIN APPLICATION
addappid(1388870)
addappid(1986510)
addappid(1986511)
addappid(1986512)
addappid(2217400)
addappid(2217401)
addappid(2217402)
addappid(2217403)
addappid(2217404)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388871, 1, "83cd56b908dfe50adfc7684d1f0dff29d2c72f42f43728b7bc96acb1fb042bed")

