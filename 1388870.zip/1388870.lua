-- Lua provided by RyzenAPI
-- Game: 1388870

-- MAIN APPLICATION
addappid(1388870)
-- Game: addappid(1388870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388871, 1, "83cd56b908dfe50adfc7684d1f0dff29d2c72f42f43728b7bc96acb1fb042bed")
