-- Lua provided by RyzenAPI
-- Game: addappid(2076320)

-- MAIN APPLICATION
addappid(2076320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076321, 1, "0c0bd611847f77fc3487301ca9342bd6c988c58dce246a9f36ae794fa52d668d")
