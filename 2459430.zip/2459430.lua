-- Lua provided by SkyAPI 
-- Game: Plastomorphosis
addappid(2459430)
addappid(2459431, 1, "9c5b77bf4ac69e1646d49e98f6d3be3bde5627cf24be9f5dd5e4561ba6af4583")
