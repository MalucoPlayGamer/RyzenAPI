-- Lua provided by RyzenAPI 
-- Game: Klym
addappid(1207400)
addappid(1207401, 1, "787e596be6927485fc5f723eeabbf8fa692fc464c415f52eba5e15d5cccd7707")
addappid(1207402, 1, "608986db0b63a281422e412524882344801698ed5f4cd0381a593e0c27e73509")
