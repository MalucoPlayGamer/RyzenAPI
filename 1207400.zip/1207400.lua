-- Lua provided by RyzenAPI
-- Game: Klym

-- MAIN APPLICATION
addappid(1207400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207401, 1, "787e596be6927485fc5f723eeabbf8fa692fc464c415f52eba5e15d5cccd7707")
addappid(1207402, 1, "608986db0b63a281422e412524882344801698ed5f4cd0381a593e0c27e73509")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
