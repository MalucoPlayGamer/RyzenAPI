-- Lua provided by RyzenAPI
-- Game: MUZEGATE

-- MAIN APPLICATION
addappid(1445360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445361, 1, "b4a12f74d0ec5de0b71ca09a646626178e82b1af4c256cef1116efb8e5c734bd")

