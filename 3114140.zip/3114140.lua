-- Lua provided by RyzenAPI
-- Game: Game: 都市女友的私密约会 An intimate date with an urban girlfriend

-- MAIN APPLICATION
addappid(3114140)
-- Game: addappid(3114140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114141, 1, "54d08379e18ce0a71ed6be05864bf3f62b283401423e27479b6c54992d9c34b2")
