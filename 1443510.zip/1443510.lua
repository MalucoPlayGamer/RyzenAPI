-- Lua provided by RyzenAPI
-- Game: addappid(1443510)

-- MAIN APPLICATION
addappid(1443510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443511, 1, "dbfae85415a42269a4d778186861d29411cfcf3beaeaa59cc19a092f784fafb2")
