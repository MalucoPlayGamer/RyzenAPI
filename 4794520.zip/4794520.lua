-- 4794520's Lua and Manifest Created by Hubcap Manifest
-- SLOTMANIA
-- Created: June 24, 2026 at 06:15:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4794520) -- SLOTMANIA
-- MAIN APP DEPOTS
addappid(4794522, 1, "04826857c5ddab44caa46d5f32426693ffef069666f29694dfc8c97653ea1314") -- Depot 4794522
-- setManifestid(4794522, "9063466523966062500", 110208548)