-- Lua provided by RyzenAPI 
-- Game: The Purge Day
addappid(553450)
addappid(553451, 1, "cd4f8f111792c385b78adba439350e0a76285f8c21f6961d914db2c971325192")
