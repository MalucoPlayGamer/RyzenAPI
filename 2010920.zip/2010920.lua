-- Lua provided by RyzenAPI
-- Game: Game: Symphony Of Motion

-- MAIN APPLICATION
addappid(2010920)
-- Game: addappid(2010920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010921, 1, "24568a435c47da7f125eaa8096177e693e50faaa6e57ee1618d9483521df9c99")
