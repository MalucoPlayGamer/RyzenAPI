-- Lua provided by RyzenAPI
-- Game: addappid(2837300)

-- MAIN APPLICATION
addappid(2837300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837301, 1, "b75ad83ddf3d4b3f95773676aec68c45aa2de216cb558f3015c756faa70bdf2c")
