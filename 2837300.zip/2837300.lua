-- Lua provided by RyzenAPI
-- Game: WhichWayOut?

-- MAIN APPLICATION
addappid(2837300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837301, 1, "b75ad83ddf3d4b3f95773676aec68c45aa2de216cb558f3015c756faa70bdf2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
