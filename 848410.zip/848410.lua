-- Lua provided by RyzenAPI
-- Game: AppID 848410

-- MAIN APPLICATION
addappid(848410)
-- Game: addappid(848410)

-- MAIN APP DEPOTS / PACKAGES
addappid(848411, 1, "db488e03f1e6711c7a6d372d7618072bec39782408bd1d95d9d4f32006a2194d")
