-- Lua provided by SkyAPI 
-- Game: AppID 848410
addappid(848410)
addappid(848411, 1, "db488e03f1e6711c7a6d372d7618072bec39782408bd1d95d9d4f32006a2194d")
