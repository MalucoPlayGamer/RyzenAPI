-- Lua provided by SkyAPI 
-- Game: AppID 616110
addappid(616110)
addappid(616111, 1, "1395ca953b76517542d3cfa3d82e2b64f9ff9faedaa7ff2a5645f97ffc69941b")
addappid(630500, 0, "8de568ef4617c6d6cde5d34b826f9257a96e0995520df8574b5c18716f0da38e")
