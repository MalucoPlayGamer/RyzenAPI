-- Lua provided by RyzenAPI
-- Game: addappid(1553110)

-- MAIN APPLICATION
addappid(1553110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553111, 1, "72c3599ff801646e8b10d76ff8c0671db0dca00b16d07136801e43305f2c2be4")
