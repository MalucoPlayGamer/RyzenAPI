-- Lua provided by RyzenAPI
-- Game: Strata Design 3D SE

-- MAIN APPLICATION
addappid(631130)
addappid(671070)

-- MAIN APP DEPOTS / PACKAGES
addappid(631131, 1, "ff3816ad8a9830da492eba5d861af3d6dbae086f499b201839cdf42ed98038e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
