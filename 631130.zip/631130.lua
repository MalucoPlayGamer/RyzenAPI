-- Lua provided by RyzenAPI
-- Game: Strata Design 3D SE

-- MAIN APPLICATION
addappid(631130)
addappid(671070)

-- MAIN APP DEPOTS / PACKAGES
addappid(631131, 1, "ff3816ad8a9830da492eba5d861af3d6dbae086f499b201839cdf42ed98038e2")

