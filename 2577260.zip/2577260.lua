-- Lua provided by RyzenAPI
-- Game: 2577260

-- MAIN APPLICATION
addappid(2577260)
-- Game: addappid(2577260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577261, 1, "597afc93bd921d9a91fc75e8f55f1e6ed4cd2220b3b1f39d32a6d90f977392a6")
