-- Lua provided by RyzenAPI
-- Game: 711130

-- MAIN APPLICATION
addappid(711130)
-- Game: addappid(711130)

-- MAIN APP DEPOTS / PACKAGES
addappid(711131, 1, "e68f6b4b6dfde1e683ca9238b574cec4b29eacc02a4101585e5a49954dd85211")
addappid(748080, 0, "a635f8042c88379866b7e878efd197a1bdbe64d566943cf018fbdd614420237e")
