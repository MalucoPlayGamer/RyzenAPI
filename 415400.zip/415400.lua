-- Lua provided by RyzenAPI
-- Game: Cross Set

-- MAIN APPLICATION
addappid(415400)

-- MAIN APP DEPOTS / PACKAGES
addappid(415401, 1, "575e2f46e0f218986f98fb02d0f79b8900c31eb68d580e1ad6022926697a6627")
addappid(415402, 1, "ddf75a68489fb9b74dea84ee490f5182761378cb47f55531442a54e5dbce9cc7")
addappid(415403, 1, "a861741093f644ccca752bbf94a333978b08cb6ce29f5950055612c5a6f3e9ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
