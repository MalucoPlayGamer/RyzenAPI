-- Lua provided by RyzenAPI
-- Game: Kingdoms and Castles

-- MAIN APPLICATION
addappid(569480)
-- Game: addappid(569480)

-- MAIN APP DEPOTS / PACKAGES
addappid(569481, 1, "812b93c7ade8e5e40c5f29b44c81ebe626c7e4246e4e11a229f50f7f8ffb5f33")
addappid(569482, 1, "131f3c6fa1c393f5b884c0a662bf5c0c197f1fec53b7a56c7fa8940617e0e6be")
addappid(569483, 1, "b6d2e0a8b8c2f0ead721d72c3ad8f46088407bf1807a22dfb4ee57eceb210267")
addappid(569484, 1, "13bb193ffd7e8031b4e453f99a765883b782333ee150988412780b264ed4f248")
addappid(1764300, 0, "3a9fee69925542868ba41744376bf34656d83524f7eee7c6c4f3bff5310dbaf4")
