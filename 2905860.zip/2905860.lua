-- Lua provided by RyzenAPI
-- Game: CHAT WARS! Demo

-- MAIN APPLICATION
addappid(2905860)
-- Game: addappid(2905860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905861, 1, "66e7947bc076ec8e03bbd1c95129bed76bfafff27da5498c3edcf2fd9a1eafa5")
