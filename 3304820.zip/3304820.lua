-- Lua provided by RyzenAPI
-- Game: Vespia: Shield of Aberration

-- MAIN APPLICATION
addappid(3304820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304821, 1, "60cf4d86193563f85b5907163688ead4cd40b5ab5bb28e0f296bce92b896e85a")
