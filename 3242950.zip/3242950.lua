-- Lua provided by RyzenAPI
-- Game: Outworld Station

-- MAIN APPLICATION
addappid(3242950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242951, 1, "c6743d91162c56cb7c1c418ee6b0471d533dc8560938f3506b810ec1f8774038")
