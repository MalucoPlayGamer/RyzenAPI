-- Lua provided by RyzenAPI 
-- Game: Does It Stack?
addappid(2511270)
addappid(2511271, 1, "a5a3526cfe66d02c585e410b5981a13b1ce94999296d7854d14b83929add1c18")
