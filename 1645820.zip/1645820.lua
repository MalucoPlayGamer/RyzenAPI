-- Lua provided by RyzenAPI
-- Game: addappid(1645820)

-- MAIN APPLICATION
addappid(1645820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645821, 1, "4365eaac1ea48f79aeec8b027dbea51e9a22b5e2c841e8f60a6d18151fcb4573")
