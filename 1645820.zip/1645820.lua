-- Lua provided by RyzenAPI
-- Game: SurrounDead

-- MAIN APPLICATION
addappid(1645820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645821, 1, "4365eaac1ea48f79aeec8b027dbea51e9a22b5e2c841e8f60a6d18151fcb4573")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
