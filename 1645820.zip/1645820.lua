-- Lua provided by SkyAPI 
-- Game: SurrounDead
addappid(1645820)
addappid(1645821, 1, "4365eaac1ea48f79aeec8b027dbea51e9a22b5e2c841e8f60a6d18151fcb4573")
