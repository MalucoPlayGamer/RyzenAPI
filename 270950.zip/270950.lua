-- Lua provided by RyzenAPI
-- Game: Ski Region Simulator - Gold Edition

-- MAIN APPLICATION
addappid(270950)

-- MAIN APP DEPOTS / PACKAGES
addappid(270951, 1, "d3489c7b14056fc1213b811d854b1b46c37b9d9762525cf88c43e0a16499ae5c")
