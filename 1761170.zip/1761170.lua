-- Lua provided by SkyAPI 
-- Game: Alien Dawn Demo
addappid(1761170)
addappid(1761171, 1, "b44441983cb4bde2917495cdb4db7a061a4abf10401e9c052c1bf483490864a6")
