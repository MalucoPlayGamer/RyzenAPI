-- Lua provided by RyzenAPI
-- Game: Alien Dawn Demo

-- MAIN APPLICATION
addappid(1761170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761171, 1, "b44441983cb4bde2917495cdb4db7a061a4abf10401e9c052c1bf483490864a6")
