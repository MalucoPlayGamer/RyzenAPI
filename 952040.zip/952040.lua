-- Lua provided by RyzenAPI
-- Game: MUSYNX

-- MAIN APPLICATION
addappid(952040)
addappid(963060)
addappid(1023780)
addappid(1199500)
addappid(1228400)
addappid(1435620)
addappid(1721770)

-- MAIN APP DEPOTS / PACKAGES
addappid(952041, 1, "d7e8a1495068660d1566825adb153b1fb482aa57a925e54c35a8fbcfbd42603d")
addappid(1304150, 0, "a0707192c508e475805ffddf8f3352066361c60023214d54f7be950eec7565bc")
