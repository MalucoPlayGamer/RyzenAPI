-- Lua provided by RyzenAPI
-- Game: MUSYNX

-- MAIN APPLICATION
addappid(952040)
addappid(963060)
addappid(1023780)
addappid(1199500)
addappid(1228400)
addappid(1435620)
addappid(1721770)

-- MAIN APP DEPOTS / PACKAGES
addappid(952041, 1, "d7e8a1495068660d1566825adb153b1fb482aa57a925e54c35a8fbcfbd42603d")
addappid(1304150, 0, "a0707192c508e475805ffddf8f3352066361c60023214d54f7be950eec7565bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
