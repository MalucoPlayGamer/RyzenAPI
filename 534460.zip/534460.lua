-- Lua provided by SkyAPI 
-- Game: Let Hawaii Happen VR
addappid(534460)
addappid(534461, 1, "36748a83173b4489d581ff346b1a9fbd1b6900dc3d69251cd6f0f61a780d9d23")
