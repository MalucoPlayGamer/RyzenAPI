-- Lua provided by RyzenAPI
-- Game: ATC4: Airport OSAKA [RJOO]

-- MAIN APPLICATION
addappid(2314640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314640,0,"ecf227381f521d40d063adbc2f9abd77c93c3ada28357b70b4a3adf4d24465f2")
