-- Lua provided by RyzenAPI
-- Game: Deadly Station

-- MAIN APPLICATION
addappid(850310)
addappid(887350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(850311, 1, "3a66ebdf241ec1bb9c365bb0a2ed6a0d2bc366929af9da9795f28eb08ebdda41")

