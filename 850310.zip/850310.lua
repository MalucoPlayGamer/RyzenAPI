-- Lua provided by RyzenAPI
-- Game: Game: Deadly Station

-- MAIN APPLICATION
addappid(850310)
addappid(887350)
-- Game: addappid(850310)

-- MAIN APP DEPOTS / PACKAGES
addappid(850311, 1, "3a66ebdf241ec1bb9c365bb0a2ed6a0d2bc366929af9da9795f28eb08ebdda41")
