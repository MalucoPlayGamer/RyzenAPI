-- Lua provided by RyzenAPI
-- Game: AppID 533620

-- MAIN APPLICATION
addappid(533620)
-- Game: addappid(533620)

-- MAIN APP DEPOTS / PACKAGES
addappid(533621, 1, "d96d3c2f44e100d5b5bbe86b57299161ba90e96f11064e55410b3f6deb9db4b8")
