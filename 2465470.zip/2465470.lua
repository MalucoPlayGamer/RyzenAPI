-- Lua provided by RyzenAPI
-- Game: addappid(2465470)

-- MAIN APPLICATION
addappid(2465470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465471, 1, "c58d5a418d732cde33286e8450b6d003ec9ff997ea9b44b0a3da6a5e797caddb")
