-- Lua provided by RyzenAPI 
-- Game: 浮生九还 Demo
addappid(2465470)
addappid(2465471, 1, "c58d5a418d732cde33286e8450b6d003ec9ff997ea9b44b0a3da6a5e797caddb")
