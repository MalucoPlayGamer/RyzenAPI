-- Lua provided by RyzenAPI
-- Game: Soulstopia -PHI-

-- MAIN APPLICATION
addappid(1752760)
-- Game: addappid(1752760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752761, 1, "a3bd35bcc3258698754752f4d45cd06841efac4cdab181ab66cb9a7587eeeba5")
