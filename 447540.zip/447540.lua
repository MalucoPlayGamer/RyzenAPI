-- Lua provided by RyzenAPI
-- Game: Lost Cosmonaut

-- MAIN APPLICATION
addappid(447540)

-- MAIN APP DEPOTS / PACKAGES
addappid(447541, 1, "82df8c11f5095d3ab0cb63152d73ff97f0779a2330f6fe30bcc2f1baca204735")

