-- Lua provided by RyzenAPI 
-- Game: Phantasy Star Online 2 New Genesis
addappid(1056640)
addappid(1056641, 1, "0a33a2b208cb9fa5726f871d9aa7274af515a8a78bc7554d0e47abc639535514")
addappid(2251111, 0, "a1856d0e96a2a132cceb1e4566e9f140ae7768c415cd212d271b97783f1e133f")
