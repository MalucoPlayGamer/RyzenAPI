-- Lua provided by RyzenAPI
-- Game: 963580

-- MAIN APPLICATION
addappid(963580)
-- Game: addappid(963580)

-- MAIN APP DEPOTS / PACKAGES
addappid(963581, 1, "b4bcc83f3a3e5c60a903a3fab97baeeb32e5fa1996df1b46944bbe5fe10f5a6c")
