-- Lua provided by RyzenAPI
-- Game: addappid(1796720)

-- MAIN APPLICATION
addappid(1796720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796721, 1, "051a5366d88b1b6518bb689eaa149e076eef9d750a602e22d5821bb9a0c405b1")
