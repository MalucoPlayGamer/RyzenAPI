-- Lua provided by RyzenAPI
-- Game: 961660

-- MAIN APPLICATION
addappid(961660)
-- Game: addappid(961660)

-- MAIN APP DEPOTS / PACKAGES
addappid(961661, 1, "62fb37cfde005a74de08716dcf0094534301be372330c93d0a9d55d7f79a18a4")
