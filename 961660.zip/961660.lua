-- Lua provided by RyzenAPI
-- Game: Nowhere Patrol

-- MAIN APPLICATION
addappid(961660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(961661, 1, "62fb37cfde005a74de08716dcf0094534301be372330c93d0a9d55d7f79a18a4")

