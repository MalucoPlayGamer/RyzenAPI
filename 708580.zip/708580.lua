-- Lua provided by RyzenAPI
-- Game: 708580

-- MAIN APPLICATION
addappid(708580)
-- Game: addappid(708580)

-- MAIN APP DEPOTS / PACKAGES
addappid(708581, 1, "ba0584b8eebb0b747160f48e2e260a03bf7bd189740e590b52b2352f2ae6943b")
