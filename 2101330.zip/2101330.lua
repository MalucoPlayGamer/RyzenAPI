-- Lua provided by RyzenAPI
-- Game: 2101330

-- MAIN APPLICATION
addappid(2101330)
-- Game: addappid(2101330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101331, 1, "56dc2ad3fcb69b9cd13962b17e3a9bcf3a3d2cc958026ef866dbad14ca63b260")
addappid(2101332, 1, "56c3bb2e6473285c71c0ff63463bb711e7d3da8d7a185f77f3f63ceb6471f869")
