-- Lua provided by RyzenAPI
-- Game: 743880

-- MAIN APPLICATION
addappid(743880)
-- Game: addappid(743880)

-- MAIN APP DEPOTS / PACKAGES
addappid(743881, 1, "497ba48220e965c5a36ca904a3c37f5bf58ed086b58c274151240651fd3ca09d")
addappid(743882, 1, "9efffdc6e14dbab2a22d60590d4ab98e2aa06a220f7aace9b91ed7eaf12676d4")
