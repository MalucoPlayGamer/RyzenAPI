-- Lua provided by RyzenAPI
-- Game: When We Arrive

-- MAIN APPLICATION
addappid(4078360) -- When We Arrive
addappid(4688480) -- When We Arrive - Support DLC

-- MAIN APP DEPOTS / PACKAGES
addappid(4078362, 1, "ac1dfeed721be1c5b002f462a9ebdb2395d7de753704c1454265b6e8ea1842c3") -- Depot 4078362
