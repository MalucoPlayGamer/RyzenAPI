-- Lua provided by RyzenAPI 
-- Game: Twizzle Puzzle: Reptiles
addappid(2757530)
addappid(2757531, 1, "67d1fcebfc3d2fac440db63df1673cdd0b46e8140ca61e1f8519e006fc146ae9")
