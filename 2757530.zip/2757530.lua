-- Lua provided by RyzenAPI
-- Game: Twizzle Puzzle: Reptiles

-- MAIN APPLICATION
addappid(2757530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757531, 1, "67d1fcebfc3d2fac440db63df1673cdd0b46e8140ca61e1f8519e006fc146ae9")
