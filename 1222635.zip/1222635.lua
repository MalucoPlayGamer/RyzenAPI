-- Lua provided by RyzenAPI
-- Game: RetroArch - Nestopia

-- MAIN APPLICATION
addappid(1222635)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222635,0,"1552007dc8956f25c87eaafc1f2c01e230f8d08b50a46a24e104be2d3c65f3aa")
addappid(1790140,0,"2e7319a67b8ce1c4b9ec8975b191de20235ca7d26172afceae06b8d60344daf3")
addappid(1790141,0,"cb7d97ec9818918e98a2466fa91d1e13ab4da4609439e23e1e721ddd41b2d870")

