-- Lua provided by RyzenAPI
-- Game: addappid(2509370)

-- MAIN APPLICATION
addappid(2509370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509371, 1, "c4c116bf42f6369d524070e4051d4394e6426bd2d5e61bfdad1a0d8401d73540")
