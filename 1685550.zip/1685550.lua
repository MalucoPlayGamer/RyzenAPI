-- Lua provided by RyzenAPI
-- Game: Zombardment

-- MAIN APPLICATION
addappid(1685550)
-- Game: addappid(1685550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685551, 1, "633fe8baef04c104d49853709ece401aaf6bbd8fd189e37f060a7fc01b8314bb")
