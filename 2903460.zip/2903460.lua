-- Lua provided by RyzenAPI
-- Game: Project Of Cooling The Earth

-- MAIN APPLICATION
addappid(2903460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903461, 1, "4ab7009110c551435e07843c5b595d9381576f640ce0ed29ec4073a984930e03")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
