-- Lua provided by RyzenAPI
-- Game: Chess Remix

-- MAIN APPLICATION
addappid(2484670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484671,0,"e50cc4c10fd658ce56e1e80a56658bc96a4e37f8a488b3caa4d8476e91102ab7")

