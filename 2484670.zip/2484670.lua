-- Lua provided by RyzenAPI
-- Game: Chess Remix

-- MAIN APPLICATION
addappid(2484670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2484671,0,"e50cc4c10fd658ce56e1e80a56658bc96a4e37f8a488b3caa4d8476e91102ab7")

