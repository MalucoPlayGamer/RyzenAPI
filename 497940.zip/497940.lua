-- Lua provided by RyzenAPI
-- Game: Destiny of Ancient Kingdoms™

-- MAIN APPLICATION
addappid(497940)

-- MAIN APP DEPOTS / PACKAGES
addappid(497941, 1, "ef42cd9b728a5c3608b5609018a040da862e89a4165407c464025c19c4f7d24e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
