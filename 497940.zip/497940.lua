-- Lua provided by RyzenAPI
-- Game: Destiny of Ancient Kingdoms™

-- MAIN APPLICATION
addappid(497940)
-- Game: addappid(497940)

-- MAIN APP DEPOTS / PACKAGES
addappid(497941, 1, "ef42cd9b728a5c3608b5609018a040da862e89a4165407c464025c19c4f7d24e")
