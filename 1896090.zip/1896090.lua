-- Lua provided by RyzenAPI
-- Game: Game: The Claws of Blood

-- MAIN APPLICATION
addappid(1896090)
addappid(2270660)
-- Game: addappid(1896090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896091, 1, "970953a5f48152b468052aefd277cdf417ad4cf38cc495a8f376897a5b36d29d")
