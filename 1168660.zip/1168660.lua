-- Lua provided by RyzenAPI 
-- Game: Barro 2020
addappid(1168660)
addappid(1168661, 1, "db613845f52a172384cdbfe80e2cff1d3342c45c3838a9e7e4e73eceea7d5c2c")
addappid(1168662, 1, "dc13ff00770ff6992f565aa85531d760fccb2a61c54ec63ccf7a3dd6c0c1869b")
