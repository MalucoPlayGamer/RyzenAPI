-- Lua provided by RyzenAPI
-- Game: 1691640

-- MAIN APPLICATION
addappid(1691640)
-- Game: addappid(1691640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691641, 1, "429b66d02ff3bd8ac2043eff00fb1605bd0b5e744db51ff63eaaf23876011837")
