-- Lua provided by SkyAPI 
-- Game: FRIGID Playtest
addappid(1691640)
addappid(1691641, 1, "429b66d02ff3bd8ac2043eff00fb1605bd0b5e744db51ff63eaaf23876011837")
