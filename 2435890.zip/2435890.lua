-- Lua provided by RyzenAPI
-- Game: addappid(2435890)

-- MAIN APPLICATION
addappid(2435890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435891, 1, "d54f6dbc8c63be9a3aab0555490765cf43415a719024eb7994bfc2bdbb834b75")
