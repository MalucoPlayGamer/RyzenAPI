-- Lua provided by RyzenAPI 
-- Game: MOONSHIRE Demo
addappid(2745010)
addappid(2745011, 1, "ed7a1af925d72ef280197e637b33e073be4dfa914b989f290a48ec54afea1db8")
