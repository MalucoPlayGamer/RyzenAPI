-- Lua provided by RyzenAPI
-- Game: Neon Fantasy: Rodents

-- MAIN APPLICATION
addappid(2745560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2745561, 1, "8176c81b07199edeee0442f7aba09cbeba0c3d0f3957a0fa2d48308fcc8669d3")

