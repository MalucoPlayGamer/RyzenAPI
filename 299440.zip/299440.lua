-- Lua provided by RyzenAPI
-- Game: Rooks Keep

-- MAIN APPLICATION
addappid(299440)

-- MAIN APP DEPOTS / PACKAGES
addappid(299441, 1, "5eb4d811928088892031d07b7cfba277fba72f18b36ef5167bbfeb23d74ab552")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
