-- Lua provided by RyzenAPI
-- Game: Rooks Keep

-- MAIN APPLICATION
addappid(299440)
-- Game: addappid(299440)

-- MAIN APP DEPOTS / PACKAGES
addappid(299441, 1, "5eb4d811928088892031d07b7cfba277fba72f18b36ef5167bbfeb23d74ab552")
