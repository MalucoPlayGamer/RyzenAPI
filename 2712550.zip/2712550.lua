-- Lua provided by RyzenAPI
-- Game: The Shell Part II: Purgatorio

-- MAIN APPLICATION
addappid(2712550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2712551, 1, "62bf645b1fe806fa53c687c2496e5f15184506cc091583f0dc6b86f6d6dc1135")

