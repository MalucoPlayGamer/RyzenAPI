-- Lua provided by RyzenAPI
-- Game: 2712550

-- MAIN APPLICATION
addappid(2712550)
-- Game: addappid(2712550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712551, 1, "62bf645b1fe806fa53c687c2496e5f15184506cc091583f0dc6b86f6d6dc1135")
