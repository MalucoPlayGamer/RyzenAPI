-- Lua provided by RyzenAPI
-- Game: My Universe - Fashion Boutique

-- MAIN APPLICATION
addappid(1365410)
-- Game: addappid(1365410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365411, 1, "2a2f8f83b7a31ee378e56e2e5360c15250398e0efd584c171848b25b8228060d")
