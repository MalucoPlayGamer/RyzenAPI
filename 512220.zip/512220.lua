-- Lua provided by RyzenAPI
-- Game: addappid(512220)

-- MAIN APPLICATION
addappid(512220)

-- MAIN APP DEPOTS / PACKAGES
addappid(512221, 1, "46c6e635a8e1cdc03e7071ed11d2138c88e19a0925374df608c0c733581e0ee3")
