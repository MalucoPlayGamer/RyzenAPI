-- 3833760's Lua and Manifest Created by Hubcap Manifest
-- You Know The Drill
-- Created: June 12, 2026 at 17:13:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3833760, 1, "06ba5fda03d41f82655039844e27045c14633136014d97629c7f170ae1d7cb51") -- You Know The Drill
-- MAIN APP DEPOTS
addappid(3833761, 1, "1ffe0eb9873d8b7221e36fe2fa8af1bcf89af090afbccb793a854f9b878e3bb0") -- Depot 3833761
setManifestid(3833761, "6150316226912496542", 187692720)
addappid(3833762, 1, "d2fe577bc16bb82d6590a51af8edd963162f8967a2fa61bbc18c44d668685549") -- Depot 3833762
setManifestid(3833762, "2870046389607409809", 161009184)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4596600) -- You Know The Drill - Supporter Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4596600) -- Depot 4596600 (empty depot)