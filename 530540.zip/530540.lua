-- Lua provided by RyzenAPI
-- Game: mr.President Prologue Episode

-- MAIN APPLICATION
addappid(530540)

-- MAIN APP DEPOTS / PACKAGES
addappid(530541, 1, "08bb3f929c2ac016241e1e1ff7fb8c67f3a48d18b908663d089af25611d490ff")
addappid(530542, 1, "739ed87c46c47a952f7e9b82688a2051475151501e9ecaaab4c6473c2a4a9f5b")
