-- Lua provided by RyzenAPI
-- Game: AaAaAA!!! - A Reckless Disregard for Gravity

-- MAIN APPLICATION
addappid(15520)
addappid(15522)
addappid(98001)

-- MAIN APP DEPOTS / PACKAGES
addappid(15521, 1, "ab436d71cae2f1b03dd1323149a518141acc9db1a26c0ccb72677ddb85b2eaad")

