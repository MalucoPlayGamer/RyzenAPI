-- Lua provided by RyzenAPI 
-- Game: Void Raiders
addappid(445600)
addappid(445601, 1, "ef70d7453d94e1e696e63bafe100a6d5ebb031157ea4c1997d997323f0fb62f1")
