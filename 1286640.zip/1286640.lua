-- Lua provided by SkyAPI 
-- Game: AppID 1286640
addappid(1286640)
addappid(1286641, 1, "10d1d934a9b086ab124694167dbc161362a0ebfaf840023be88c95e0c65cf699")
