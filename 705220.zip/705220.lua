-- Lua provided by RyzenAPI
-- Game: Game: Tactical Monsters Rumble Arena

-- MAIN APPLICATION
addappid(705220)
-- Game: addappid(705220)

-- MAIN APP DEPOTS / PACKAGES
addappid(705221, 1, "95f9643dafd893ab9884d51b83652915ee378ab10f3f0f40e290b2482a4e890b")
