-- Lua provided by RyzenAPI
-- Game: Game: Programming Simulator

-- MAIN APPLICATION
addappid(3345050)
-- Game: addappid(3345050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345051, 1, "5d47c794da70446d03884953ae9f06e4e39aba9592701609a208b37882fda848")
