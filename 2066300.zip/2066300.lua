-- Lua provided by RyzenAPI 
-- Game: Escape: The Endless Dogwatch
addappid(2066300)
addappid(2066301, 1, "26af57040dccb2cc2b1307c1fed000836662532f8a8514ac3172a88b54dfaaff")
