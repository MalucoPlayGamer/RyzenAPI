-- Lua provided by RyzenAPI 
-- Game: LOVE ON
addappid(2873010)
addappid(2873011, 1, "68ddbeec1bab24a313e218498785524f53178dd5a2cc24dd41a440df0d6105e8")
