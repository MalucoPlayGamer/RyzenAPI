-- Lua provided by SkyAPI 
-- Game: The secret of the stone
addappid(1424700)
addappid(1424701, 1, "4b433a953ce8d8c6173922a969461dff2b5fe08a7bea73337992eaff25f14fd6")
