-- Lua provided by RyzenAPI
-- Game: The secret of the stone

-- MAIN APPLICATION
addappid(1424700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424701, 1, "4b433a953ce8d8c6173922a969461dff2b5fe08a7bea73337992eaff25f14fd6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
