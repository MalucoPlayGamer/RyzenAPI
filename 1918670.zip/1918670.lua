-- Lua provided by RyzenAPI
-- Game: Dulce et Decorum

-- MAIN APPLICATION
addappid(1918670)
-- Game: addappid(1918670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918671, 1, "da5d540b689c769707355d3e17fd9ecba100e56dcdc6c71e10315fa2311936c5")
