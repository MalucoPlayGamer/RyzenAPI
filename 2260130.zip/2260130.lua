-- Lua provided by RyzenAPI
-- Game: Offroad Mechanic Simulator: Prologue - First Job

-- MAIN APPLICATION
addappid(2260130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260131, 1, "bc77a3a54fe9c51689b6994acd20751b10b5e4ce708eb7e0795632c76cc50b96")
