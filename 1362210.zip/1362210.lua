-- Lua provided by RyzenAPI
-- Game: AppID 1362210

-- MAIN APPLICATION
addappid(1362210)
-- Game: addappid(1362210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362211, 1, "6a9bae651a43c2bef0f8cdb7cd2bbf03f916e81a01e664f7501ea223fbda8359")
