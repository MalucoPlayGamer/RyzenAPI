-- Lua provided by RyzenAPI
-- Game: Shopping Clutter 2: Christmas Square

-- MAIN APPLICATION
addappid(932970)

-- MAIN APP DEPOTS / PACKAGES
addappid(932971, 1, "2e204903beb36ed5183509c10068d4ca8a0c4eb8442dcbf101a252f103fb6b0a")

