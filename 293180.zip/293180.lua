-- Lua provided by RyzenAPI
-- Game: Overcast - Walden and the Werewolf

-- MAIN APPLICATION
addappid(293180)

-- MAIN APP DEPOTS / PACKAGES
addappid(293181, 1, "2822f42f845c42cd2f925805c6e8830571eb89a817aceb41cd5b54eb645c6066")
addappid(295530, 0, "56f1a00086d3b473feec5e192a4156c8473d6283dc65eea01183157c138948b9")
