-- Lua provided by RyzenAPI
-- Game: Travellin Cats in China

-- MAIN APPLICATION
addappid(2608040)
addappid(2915740)
-- Game: addappid(2608040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2608041, 1, "da86d90aa41712b5a21971a2df725471a6c3c9d16b576903c6919dedf96db730")
