-- Lua provided by RyzenAPI
-- Game: Travellin Cats in China

-- MAIN APPLICATION
addappid(2608040)
addappid(2915740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2608041, 1, "da86d90aa41712b5a21971a2df725471a6c3c9d16b576903c6919dedf96db730")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
