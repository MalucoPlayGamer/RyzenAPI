-- Lua provided by RyzenAPI
-- Game: The Idiot's Tale

-- MAIN APPLICATION
addappid(810450)

-- MAIN APP DEPOTS / PACKAGES
addappid(810451,0,"e0812fd9a1b2edef9846ba422a6d255c2803381c2fb1d6ecefc26c549bbc81d8")

