-- Lua provided by RyzenAPI
-- Game: Sons Of The Forest Dedicated Server

-- MAIN APPLICATION
addappid(2465200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465201, 1, "2164f0883ba619f4739b611442ed4350a6c9fde47a85b22e7b8145236f794c39")
