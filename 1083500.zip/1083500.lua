-- Lua provided by RyzenAPI 
-- Game: AppID 1083500
addappid(1083500)
addappid(1083501, 1, "b0116239572505b2a04db6fe7ab09e81f237509ee1330f56017687de31f72102")
