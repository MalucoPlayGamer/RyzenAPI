-- Lua provided by RyzenAPI
-- Game: Contraption Maker

-- MAIN APPLICATION
addappid(241240)

-- MAIN APP DEPOTS / PACKAGES
addappid(241241, 1, "344a16c53f84fe53d537d301305db500c71d07deabe6f624d51459fab5dca4eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(462540)
addappid(464480)
addappid(745580)
addappid(786010)
