-- Lua provided by RyzenAPI
-- Game: addappid(1926870)

-- MAIN APPLICATION
addappid(1926870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926871, 1, "52b516b1b15fe9513c3175ad0d8d16d1e9fff7ba4014da2720ee416be1b3b408")
