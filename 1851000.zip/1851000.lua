-- Lua provided by RyzenAPI
-- Game: 1851000

-- MAIN APPLICATION
addappid(1851000)
-- Game: addappid(1851000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851001, 1, "ffe5b1ece7e5b96c85c653b86d9911c4902cba6bab47dfef5cb42a5c85115ec4")
