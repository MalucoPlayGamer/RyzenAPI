-- Lua provided by RyzenAPI
-- Game: Land of the Vikings: Thralls

-- MAIN APPLICATION
addappid(2997380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997380,0,"381309f7d05c85b60c138b2907b6a053a904cbd09764c78bebe959e9ae617af6")
