-- Lua provided by RyzenAPI
-- Game: The Twisting Trail of Clues

-- MAIN APPLICATION
addappid(2411770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411771, 1, "1e974fac0d53ca3cfbfd3f9b7decd1304a7f5b2d7debffb65d5870d97b7f446a")

