-- Lua provided by RyzenAPI
-- Game: RIO - Raised In Oblivion

-- MAIN APPLICATION
addappid(1340160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1340161, 1, "eca0de75f406983af68b8d7ecfe04cc890d3c29a050533f27a0d63ae77218b2d")

