-- Lua provided by SkyAPI 
-- Game: RIO - Raised In Oblivion
addappid(1340160)
addappid(1340161, 1, "eca0de75f406983af68b8d7ecfe04cc890d3c29a050533f27a0d63ae77218b2d")
