-- Lua provided by RyzenAPI
-- Game: VTuber Maker

-- MAIN APPLICATION
addappid(1368950)
-- Game: addappid(1368950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368951, 1, "0676677d0c97e4daf341e9bf63d334597e819d1c956825feb7feb5a5699e620e")
