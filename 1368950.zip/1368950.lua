-- Lua provided by SkyAPI 
-- Game: VTuber Maker
addappid(1368950)
addappid(1368951, 1, "0676677d0c97e4daf341e9bf63d334597e819d1c956825feb7feb5a5699e620e")
