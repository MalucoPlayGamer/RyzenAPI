-- Lua provided by RyzenAPI
-- Game: 3752500

-- MAIN APPLICATION
addappid(3752500)
-- Game: addappid(3752500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3752501, 1, "554542f294c9f8221bdea5cb9dc6844454c4cc904c2a72c2625a6e029e1e2272")
