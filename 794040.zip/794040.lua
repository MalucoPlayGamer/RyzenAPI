-- Lua provided by RyzenAPI
-- Game: The Broken Seal: Arena

-- MAIN APPLICATION
addappid(794040)

-- MAIN APP DEPOTS / PACKAGES
addappid(794041,0,"8201ceaafde0a36070e651438c3bf36648e4c632c33fd81f321683c095900189")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
