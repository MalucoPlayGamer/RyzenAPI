-- Lua provided by RyzenAPI
-- Game: The Broken Seal: Arena

-- MAIN APPLICATION
addappid(794040)

-- MAIN APP DEPOTS / PACKAGES
addappid(794041,0,"8201ceaafde0a36070e651438c3bf36648e4c632c33fd81f321683c095900189")

