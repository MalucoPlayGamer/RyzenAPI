-- Lua provided by RyzenAPI
-- Game: Forest Home

-- MAIN APPLICATION
addappid(1145970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145971, 1, "0f291ab802444fd888d5e533d663ff047174fea0e3a3cc03a907cae6e36e9d11")

