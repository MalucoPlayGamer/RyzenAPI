-- Lua provided by RyzenAPI
-- Game: 2484370

-- MAIN APPLICATION
addappid(2484370)
-- Game: addappid(2484370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484371, 1, "85f4fdee04e082b7aafe73194c796cd927210426a7d34b51dd8cadf740da68f3")
