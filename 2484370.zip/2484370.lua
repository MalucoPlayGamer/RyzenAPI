-- Lua provided by SkyAPI 
-- Game: Package Runner
addappid(2484370)
addappid(2484371, 1, "85f4fdee04e082b7aafe73194c796cd927210426a7d34b51dd8cadf740da68f3")
