-- Lua provided by SkyAPI 
-- Game: AppID 243340
addappid(243340)
addappid(243341, 1, "200247dc723b7b9bbdd5d12782592def5bc328beffb0bf8982b0bf2e2f7f621c")
