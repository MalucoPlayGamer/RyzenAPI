-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Weeknd - "Take My Breath"

-- MAIN APPLICATION
addappid(2195478)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195478,0,"2bbb5c9eff1bbb1b2eb9844224b61018878fa32b72adc1e262e51c464c955745")

