-- Lua provided by RyzenAPI
-- Game: AppID 401200

-- MAIN APPLICATION
addappid(401200)

-- MAIN APP DEPOTS / PACKAGES
addappid(401201, 1, "aca145af095b285c07efb37beba3083d480989240eea2c5e0c5a22c622741bce")

