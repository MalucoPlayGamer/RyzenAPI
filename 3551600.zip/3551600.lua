-- Lua provided by RyzenAPI
-- Game: Jumpscare Simulator: System Breach

-- MAIN APPLICATION
addappid(3551600)
addappid(3614440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3551601, 1, "3b2adb6bf1fffac4173d10381a87233e53fffd40d97365b544316d37aadfacfa")
addappid(3614441, 1, "5c6ada1124085942a79bc86fc52c9100bf6aeea007de54620da4c3187c58c8ca")

