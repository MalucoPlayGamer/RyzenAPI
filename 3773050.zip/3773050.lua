-- Lua provided by RyzenAPI
-- Game: addappid(3773050)

-- MAIN APPLICATION
addappid(3773050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3773051, 1, "fad50a924be896f435e7c75bafc078335d6f53e43ef658de121a0b6f39597675")
addappid(3773052, 1, "c3403b51a325fbf02b77625edccf05423b16646dc692fd7b3fabaa117e58a32d")
