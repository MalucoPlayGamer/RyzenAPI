-- Lua provided by RyzenAPI
-- Game: AppID 1291170

-- MAIN APPLICATION
addappid(1291170)
-- Game: addappid(1291170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291171, 1, "1a3918aa22c50743d5a2748097a8952bd085d245b7a4815b8b6d4b7be5e7b6d2")
