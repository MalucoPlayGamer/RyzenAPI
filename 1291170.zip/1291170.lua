-- Lua provided by SkyAPI 
-- Game: AppID 1291170
addappid(1291170)
addappid(1291171, 1, "1a3918aa22c50743d5a2748097a8952bd085d245b7a4815b8b6d4b7be5e7b6d2")
