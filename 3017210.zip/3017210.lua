-- Lua provided by RyzenAPI
-- Game: 双门勇者棋试玩版

-- MAIN APPLICATION
addappid(3017210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017211, 1, "3221abab6fea184c3ad1246d938a2ffbe75c8e09849b841e9ddc77e77a9f7960")

