-- Lua provided by RyzenAPI
-- Game: 3188550

-- MAIN APPLICATION
addappid(3188550)
-- Game: addappid(3188550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3188551, 1, "6ed228c9ac1dbac1b89898ad102d41a0a0956e067cd3edf9725c57b9b570ad57")
