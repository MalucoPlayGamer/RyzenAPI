-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(987110)

-- MAIN APP DEPOTS / PACKAGES
addappid(987110,0,"e6218b5f3aa1289e5c7ee3a4335c8b3498d9aa10b0565c9809c5793cbb090d85")
