-- 244930's Lua and Manifest Created by Hubcap Manifest
-- SNOW
-- Created: September 30, 2025 at 18:03:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 25
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(244930, 1, "4bc5d19d8fd89848421ce60b8d8d7ae20d648ab8b57064cfcfa865114c10183b") -- SNOW
-- MAIN APP DEPOTS
addappid(244932, 1, "c2b7ba04b844b1b17e43e54b12e41fe26dbb58e5395efa4c00f331c19d6ee960") -- SNOW Content
setManifestid(244932, "8252072277213176985", 5687931359)
addappid(244931, 1, "68a04c41820256641aab2e2ece89e9fe85ed5f29e8b74bbc8f08184c129d98d8") -- Binaries Windows x64
setManifestid(244931, "6633547932201161198", 101981770)
addappid(244934, 1, "9119fb228785f766c6b25164f6be06426452e82b8f4ce42f8f3d9efa32728747") -- Localization English
setManifestid(244934, "3177227709443963649", 2130141)
addappid(244935, 1, "07c1aee91ec03ceb4db622bcd90243ae899b141a3075296a40a82f1bb497d3a7") -- Levels
setManifestid(244935, "4068944397068568551", 3955626609)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(257300) -- SNOW Starter Pack
addappid(257301) -- SNOW Tester Pack
addtoken(257301, "4132990426917150496")
addappid(257302) -- SNOW Founders Pack
addtoken(257302, "14427208988331126869")
addappid(438800) -- SNOW Amateur Pack
addappid(438801) -- SNOW Pro Pack
addappid(438802) -- SNOW Legend Pack
addappid(481120) -- SNOW Snowboard Amateur Pack
addappid(481121) -- SNOW Snowboard Pro Pack
addappid(481122) -- SNOW Snowboard Legend Pack
addappid(481170) -- SNOW Ski Amateur Pack
addappid(481171) -- SNOW Ski Pro Pack
addappid(481172) -- SNOW Legend Pack
addappid(571360) -- SNOW - Ski Starter Pack
addappid(571361) -- SNOW - Snowboard Starter Pack
addappid(571362) -- SNOW - Legend Pack
addappid(774271) -- SNOW - Starter Pack
addappid(774272) -- SNOW - Pro Pack
addappid(774273) -- SNOW - Legend Pack
addappid(774274) -- SNOW - Skier Pack
addappid(774275) -- SNOW - Snowboard Pack
addappid(774276) -- SNOW - All Access Basic Pass
addappid(774277) -- SNOW - All Access Pro Pass
addappid(774278) -- SNOW - All Access Legend Pass
addappid(774279) -- SNOW - Lifetime Pack
addappid(1015980) -- SNOW - Ultimate Edition