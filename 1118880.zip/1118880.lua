-- Lua provided by RyzenAPI
-- Game: Rituals in the Dark

-- MAIN APPLICATION
addappid(1118880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118881, 1, "c34a209bdefa07f5bc6d1315d8875fb2a2737dd81b5822ad5853f916e5f200f6")

