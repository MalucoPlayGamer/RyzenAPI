-- Lua provided by RyzenAPI
-- Game: 1261520

-- MAIN APPLICATION
addappid(1261520)
-- Game: addappid(1261520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261521, 1, "0bac1ce04e63019f735f64cbd5a412c1fd54cf25dd6b2504fe5b57600bba4aee")
