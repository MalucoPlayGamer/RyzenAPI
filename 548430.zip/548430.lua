-- Lua provided by RyzenAPI
-- Game: Deep Rock Galactic

-- MAIN APPLICATION
addappid(548430)

-- MAIN APP DEPOTS / PACKAGES
addappid(548431, 1, "73ef10dc344cb7fb34be23aea35b20fbb2b32b0db50650919c7e3d731e759aad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(801860)
addappid(1283090)
addappid(1283091)
addappid(1430610)
addappid(1530640)
addappid(1797340)
addappid(1946960)
addappid(2165590)
addappid(2291670)
addappid(2416900)
addappid(2934390)
addappid(3481460)
addappid(4207910)
