-- Lua provided by RyzenAPI
-- Game: 548430

-- MAIN APPLICATION
addappid(548430)
-- Game: addappid(548430)

-- MAIN APP DEPOTS / PACKAGES
addappid(548431, 1, "73ef10dc344cb7fb34be23aea35b20fbb2b32b0db50650919c7e3d731e759aad")
