-- Lua provided by RyzenAPI
-- Game: Game: Space Sprouts

-- MAIN APPLICATION
addappid(2790020)
-- Game: addappid(2790020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790021, 1, "897c2315879c6a2c24078f0d16095777c0b5504495a8d3167f4c755b3a6a0ba2")
