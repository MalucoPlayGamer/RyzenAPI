-- Lua provided by RyzenAPI 
-- Game: AppID 2797840
addappid(2797840)
addappid(2797841, 1, "6dbe1be716114195227e06bbb86ae87e3da602f60a7ae75b4b971512d88eccc8")
