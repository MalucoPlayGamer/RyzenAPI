-- Lua provided by RyzenAPI
-- Game: 350070

-- MAIN APPLICATION
addappid(350070)
-- Game: addappid(350070)

-- MAIN APP DEPOTS / PACKAGES
addappid(350071, 1, "1abcb9e62c9e134f4bf2c85bada045d31baa85c29ca3a86c022229e0a5d97179")
addappid(350072, 1, "b09b7238e7ea6a0eaef64c700977e618fd9e9852432bb25eb9eeb17633365e22")
addappid(350073, 1, "777d4af04e6abc5ab2d2c14f74b65a319e54825b847f0eb06936662e3dec2bb5")
