-- 4751340's Lua and Manifest Created by Hubcap Manifest
-- Organize my Shop
-- Created: July 25, 2026 at 06:08:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4751340, 1, "30651e3adacc02a23a72a05c4564e134cd3adb312430bfc3d848dc5ad8c30582") -- Organize my Shop
-- MAIN APP DEPOTS
addappid(4751341, 1, "b9242212e2372740d36e3b40befab3db376224fc6f2bf42326c83ddc7ec9ec3b") -- Depot 4751341
setManifestid(4751341, "1102813491512129229", 934817043)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Organize my Shop Nightshift (AppID: 4864930)
addappid(4864930)
addappid(4751342, 1, "44330ba983fcab1ed7e117dbf38611e2137695310174740df948e5ef76002e9d") -- Organize my Shop Nightshift - Depot 4751342
setManifestid(4751342, "2104788966961324071", 934820635)
-- Organize my Shop Chaos (AppID: 4958830)
addappid(4958830)
addappid(4958830, 1, "a78cf71129c8b88f40024c52ecd7082c48b897d32ed56186b61f80b208484e30") -- Organize my Shop Chaos - Depot 4958830
setManifestid(4958830, "4414400051640024097", 934820640)