-- Lua provided by RyzenAPI
-- Game: AppID 1308060

-- MAIN APPLICATION
addappid(1308060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308061, 1, "1fb5ac3ca867fac728dc958b95ecb7c5ffa237d68d9fabb8bfdbe13e0a4ed6f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
