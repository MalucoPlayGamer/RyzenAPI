-- Lua provided by SkyAPI 
-- Game: Arkasha
addappid(796110)
addappid(796111, 1, "f0eabcdabfb7d3ce1ce2ae7f150e769cb11559c3d28f75d6b02ad7939bb6d5c9")
