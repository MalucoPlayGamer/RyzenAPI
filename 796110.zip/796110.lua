-- Lua provided by RyzenAPI
-- Game: Arkasha

-- MAIN APPLICATION
addappid(796110)

-- MAIN APP DEPOTS / PACKAGES
addappid(796111, 1, "f0eabcdabfb7d3ce1ce2ae7f150e769cb11559c3d28f75d6b02ad7939bb6d5c9")

