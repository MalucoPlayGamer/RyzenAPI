-- Lua provided by SkyAPI 
-- Game: Shio
addappid(525360)
addappid(525361, 1, "b22a757a52c7e653b84b47dcccf3babea51b10f85de4d410f4110579eea3e109")
addappid(525362, 1, "d58f35aa8a5ebf30d689dbe5753de312e52bbfdde12eac44a1dea7d50ffc7a47")
addappid(630920, 0, "e7a1b34d214492e370aaea832362aeabc4199d17458505d0c7b2e13caca512c0")
