-- Lua provided by RyzenAPI
-- Game: AppID 955250

-- MAIN APPLICATION
addappid(955250)
-- Game: addappid(955250)

-- MAIN APP DEPOTS / PACKAGES
addappid(955251, 1, "c9e7b7713a5333c67c76db5dc6d0a54799e5bb34a2ace5cd0945c9bf554ef0d6")
