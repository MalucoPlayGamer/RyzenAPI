-- Lua provided by RyzenAPI
-- Game: Whispered Secrets: Into the Beyond Collector's Edition

-- MAIN APPLICATION
addappid(669040)

-- MAIN APP DEPOTS / PACKAGES
addappid(669041,0,"84833693a4e4e4b135cf1fa94d3bfb380b486f56a8e2f858d0220198da6982d2")

