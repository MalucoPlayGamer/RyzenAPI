-- Lua provided by RyzenAPI
-- Game: Game: Bound Survivor

-- MAIN APPLICATION
addappid(3605460)
-- Game: addappid(3605460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3605461, 1, "797e6163258884e0ec550186a9fea91c29f5c112d28c00ee0a20982bd25045d8")
