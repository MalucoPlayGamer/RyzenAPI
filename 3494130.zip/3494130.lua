-- Lua provided by RyzenAPI
-- Game: Clink

-- MAIN APPLICATION
addappid(3494130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3494131, 1, "08acc02e5b3e1d09b0dd54172e3fb42435a4cf22a5ee37a8fe431d27ad46da32")

