-- Lua provided by RyzenAPI
-- Game: Clink

-- MAIN APPLICATION
addappid(3494130)
-- Game: addappid(3494130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3494131, 1, "08acc02e5b3e1d09b0dd54172e3fb42435a4cf22a5ee37a8fe431d27ad46da32")
