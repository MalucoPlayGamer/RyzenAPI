-- Lua provided by RyzenAPI
-- Game: Defense Grid 2

-- MAIN APPLICATION
addappid(221540)
addappid(228983)
addappid(228990)
addappid(267190)
addappid(267191)
addappid(315220)
addappid(330540)
addappid(1080920)

-- MAIN APP DEPOTS / PACKAGES
addappid(221541, 1, "218b2b3b9d874e694e1af2fe5a774b43d43b63dc4589d3ce869e1d0bda927770")
addappid(221542, 1, "9c995ddec3697d4166bc4ebeefc3e4dc846e9744773e0d64e8b3fb77f25928c2")
addappid(221543, 1, "1f5fe60442095d2f8ff4f3af1c75ab5b22ea53e39d9859c7848d910cafbfaeb8")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(315410, 0, "b6c9b9cf4e7bfbfa125320910302e39f873a3d973b08e2b7b6e7a6cd61f07762")
addappid(315411, 0, "cbe9575a280fc0613f1f425ac2c0be361c9b347ffb0c9a8cc827cbc1d754d883")
addappid(315412, 0, "d9e4b2cdb711c3a089e6171de549588facedd1991c1efb1b75c7bc0ac86955bc")

