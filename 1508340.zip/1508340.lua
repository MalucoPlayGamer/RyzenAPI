-- Lua provided by RyzenAPI
-- Game: Forsaken Universe

-- MAIN APPLICATION
addappid(1508340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508341, 1, "b3c67834f59a5fec12bfd1e4c743d007035b8a2b1c60ff2db4a6bc2a84dfab1e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
