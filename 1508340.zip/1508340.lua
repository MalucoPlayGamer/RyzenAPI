-- Lua provided by RyzenAPI
-- Game: Forsaken Universe

-- MAIN APPLICATION
addappid(1508340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508341, 1, "b3c67834f59a5fec12bfd1e4c743d007035b8a2b1c60ff2db4a6bc2a84dfab1e")

