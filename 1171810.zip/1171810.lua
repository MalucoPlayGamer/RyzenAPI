-- Lua provided by RyzenAPI
-- Game: Immortal Girl

-- MAIN APPLICATION
addappid(1171810)
-- Game: addappid(1171810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171811, 1, "c9c9ec42700b31aa65f8111b55d8358110ba19b7cf8bf6842f970aececa55cc6")
