-- Lua provided by RyzenAPI
-- Game: Strategy & Tactics: Wargame Collection

-- MAIN APPLICATION
addappid(338130)
-- Game: addappid(338130)

-- MAIN APP DEPOTS / PACKAGES
addappid(338131, 1, "4be8ee292ccb6dd6f59c5032c7ecb782683c245e8ff60b083c33d4b386eb0bf7")
addappid(338132, 1, "87f65723789a1d4a7ab7447e4f3f7c314fa9b5a239a939d178cf8c8c9133e108")
addappid(338133, 1, "357a1faea93a2df44e05015ac89190ca2b1bd562f07f00cb5ab48338e48ac753")
addappid(338134, 1, "89f2524c514d448e7b8b09c3ef03e6b1035cb783e31c2250f93fd5e0892f4e1b")
addappid(338135, 1, "4aeafd6757960e951da4d3ce77bee2935b142e6d912879280884f63b6f11d65c")
addappid(338136, 1, "779c8c742d74772712393c173ec1c6d09cd03173c9ac5219b6c481f6de39af42")
