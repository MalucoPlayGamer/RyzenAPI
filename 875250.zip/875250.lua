-- Lua provided by RyzenAPI
-- Game: Recursive Dragon

-- MAIN APPLICATION
addappid(875250)
-- Game: addappid(875250)

-- MAIN APP DEPOTS / PACKAGES
addappid(875251, 1, "8f4556731ab850230c5565d83c3a24cdc4763b59dd47db20d7958f66d7654e72")
