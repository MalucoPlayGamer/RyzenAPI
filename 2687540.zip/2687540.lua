-- Lua provided by RyzenAPI
-- Game: Game: Gateway to the Kulikovo Field: The Battle of Yepifan

-- MAIN APPLICATION
addappid(2687540)
-- Game: addappid(2687540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687541, 1, "2a777afdd41ab3adb3aa2c8032c1e275d519e9d159754f2017c2a425b1eb6d9e")
