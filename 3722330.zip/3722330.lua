-- Lua provided by RyzenAPI
-- Game: Shift At Midnight

-- MAIN APPLICATION
addappid(3722330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722331, 1, "241b88aeb27a250cbfff336e4e5ec6f28a60d136f4431f8bdcbf84a0506e5ed4") -- Depot 3722331

