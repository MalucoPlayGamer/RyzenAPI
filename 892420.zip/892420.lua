-- Lua provided by RyzenAPI
-- Game: 892420

-- MAIN APPLICATION
addappid(892420)
-- Game: addappid(892420)

-- MAIN APP DEPOTS / PACKAGES
addappid(892421, 1, "dee2edae1f54bf3dfb094738ca9624ff9cd3bb6abe5e31715e6dc24c919c0a37")
