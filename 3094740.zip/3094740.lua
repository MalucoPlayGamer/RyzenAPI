-- Lua provided by RyzenAPI 
-- Game: Second Rate Superheroes
addappid(3094740)
addappid(3094741, 1, "918d9250a54e0467b743c5a820d3d6c47e448f8ed5012655fc32bc3f3bf89205")
