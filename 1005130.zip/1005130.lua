-- Lua provided by RyzenAPI
-- Game: Game: Delicious - Emily's Road Trip

-- MAIN APPLICATION
addappid(1005130)
-- Game: addappid(1005130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005131, 1, "14704006a2f219dadae417da07c736ed0608aeb13f54f91a8a1b6344c01cb18e")
