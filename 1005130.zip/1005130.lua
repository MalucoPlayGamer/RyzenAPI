-- Lua provided by RyzenAPI
-- Game: Delicious - Emily's Road Trip

-- MAIN APPLICATION
addappid(1005130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005131, 1, "14704006a2f219dadae417da07c736ed0608aeb13f54f91a8a1b6344c01cb18e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
