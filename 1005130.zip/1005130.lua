-- Lua provided by RyzenAPI 
-- Game: Delicious - Emily's Road Trip
addappid(1005130)
addappid(1005131, 1, "14704006a2f219dadae417da07c736ed0608aeb13f54f91a8a1b6344c01cb18e")
