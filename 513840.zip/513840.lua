-- Lua provided by RyzenAPI
-- Game: Friday Night Bullet Arena

-- MAIN APPLICATION
addappid(513840)

-- MAIN APP DEPOTS / PACKAGES
addappid(513841, 1, "f10a6cacbc615867312d04c02ba8a297a82b105ea84464463cc9b13a6dd57f6a")

