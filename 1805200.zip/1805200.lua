-- Lua provided by RyzenAPI
-- Game: Game: Shirone: the Dragon Girl

-- MAIN APPLICATION
addappid(1805200)
-- Game: addappid(1805200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805201, 1, "66a9b100d06aa393e05f10ab63e069af45e88b666f7c585ffae316368dbe7320")
