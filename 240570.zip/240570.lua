-- Lua provided by RyzenAPI
-- Game: Gunpoint Demo

-- MAIN APPLICATION
addappid(240570)
-- Game: addappid(240570)

-- MAIN APP DEPOTS / PACKAGES
addappid(240571, 1, "f23ecec60c5fa296eb6b9e63181a8fb86e07a439ccd41d9c9fad600d7f35eff1")
