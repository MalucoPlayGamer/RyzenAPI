-- Lua provided by RyzenAPI
-- Game: Game: AppID 431740

-- MAIN APPLICATION
addappid(431740)
-- Game: addappid(431740)

-- MAIN APP DEPOTS / PACKAGES
addappid(431741, 1, "e7b9fb2dba75df588225fea8042c8e15df91bf99e0072a80707e42766d42531a")
