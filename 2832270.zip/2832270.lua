-- Lua provided by RyzenAPI
-- Game: addappid(2832270)

-- MAIN APPLICATION
addappid(2832270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832271, 1, "13a3bf56104049c54859ea8a1d964a7d2ed5f1db9ba043a26b379784481fdc3b")
