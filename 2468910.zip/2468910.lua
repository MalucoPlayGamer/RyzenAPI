-- Lua provided by RyzenAPI
-- Game: 上古武神传

-- MAIN APPLICATION
addappid(2468910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468911, 1, "09755cfba84f42c9e0d347a7356b0e9586a9adc12d6126fd024030b7c1e66d86")
