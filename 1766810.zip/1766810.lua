-- Lua provided by RyzenAPI
-- Game: SnOut 2

-- MAIN APPLICATION
addappid(1766810)
-- Game: addappid(1766810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766811, 1, "fd7b3c4e747976b9104bd7d26c67fddd6a561034524f8027cba07d6112589c1e")
