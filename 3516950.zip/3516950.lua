-- Lua provided by RyzenAPI 
-- Game: 2nd Eve Playtest
addappid(3516950)
addappid(3516951, 1, "36d402d03c0cda38104824d72f6601d2fb21d82638ac83d549fbaf5b337c36d7")
