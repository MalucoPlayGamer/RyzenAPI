-- Lua provided by RyzenAPI
-- Game: addappid(956861)

-- MAIN APPLICATION
addappid(956861)

-- MAIN APP DEPOTS / PACKAGES
addappid(956861,0,"ca07ad4e20695315b498da58d45306a3f27a042e1d990fc7e94ddfdf07e19afa")
