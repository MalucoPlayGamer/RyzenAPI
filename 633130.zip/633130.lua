-- Lua provided by RyzenAPI
-- Game: AppID 633130

-- MAIN APPLICATION
addappid(633130)

-- MAIN APP DEPOTS / PACKAGES
addappid(633131, 1, "1278b99fee51cfb769521d0c5ba45d59d109aa5dc14a32887656b0208176e126")
addappid(633132, 1, "61f94e09896aba4c9e77305608e2b6603795bdb3f5e34890ac5af9789f7cd4fa")
addappid(633133, 1, "e6ef9d2f1655a9e428d5fa0f817caa8f8dc685a7d0a8e88c52134069d86c188b")
addappid(633134, 1, "56441cfc68b352605d3a5faa7b99f2d97856af9f5a8cf1e59431075f150ee247")
addappid(633135, 1, "44135138c08279fe4014debf884ca1d18c4ecdc1ecca07307fac904083743367")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(636290)
