-- Lua provided by RyzenAPI
-- Game: Bad Dream: Coma

-- MAIN APPLICATION
addappid(538070)

-- MAIN APP DEPOTS / PACKAGES
addappid(538071, 1, "1cc683e5e0294a6145902dbca953875b8f9b0a340dd21b63b926e03b87da634b")
addappid(538072, 1, "812b5acde01c823d8ddacfee4ef87a8a699741c9b8d6a2be3433de40e36f049b")
