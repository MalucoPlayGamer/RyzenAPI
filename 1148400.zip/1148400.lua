-- Lua provided by RyzenAPI
-- Game: AppID 1148400

-- MAIN APPLICATION
addappid(1148400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148401, 1, "a493cf71eae584e1f2708c8be6ccef76ba765b2dd05af0ab77503ec7eba8a836")
