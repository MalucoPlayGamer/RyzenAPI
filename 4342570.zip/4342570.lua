-- Lua provided by RyzenAPI
-- Game: Gospodar's Tales

-- MAIN APPLICATION
addappid(4342570)

-- MAIN APP DEPOTS / PACKAGES
addappid(4342571,0,"8afca19ac29e51f372ebf0467742a65a02dfb1113a9158c4b4275829843d1bf6")

