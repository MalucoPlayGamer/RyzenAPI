-- Lua provided by RyzenAPI
-- Game: Money Bath VR

-- MAIN APPLICATION
addappid(1041670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041671, 1, "f0bd9e827792c195c11b388347e0a5de467709db1adc1164a16addc145eca03a")
