-- Lua provided by SkyAPI 
-- Game: Game Of Fate2：Digital upgraded version
addappid(3357830)
addappid(3357831, 1, "6371e72e0042fa7e187a1940bb973643af5896b42fa755f8c07fd4dd1d041328")
