-- Lua provided by RyzenAPI
-- Game: The Fear of The Past

-- MAIN APPLICATION
addappid(2957420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957421, 1, "7177e3e3675ef03a6a69511d6c80e6c8a8b05bbff8298bae6711ec6705438d62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
