-- Lua provided by RyzenAPI
-- Game: The Fear of The Past

-- MAIN APPLICATION
addappid(2957420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957421, 1, "7177e3e3675ef03a6a69511d6c80e6c8a8b05bbff8298bae6711ec6705438d62")

