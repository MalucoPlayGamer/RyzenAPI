-- Lua provided by SkyAPI 
-- Game: Bunny Park
addappid(1208600)
addappid(1208601, 1, "e2bba740d0a5f5eebd4645b386df6c40ef37d08c209a3f312ade721e748b6d8b")
