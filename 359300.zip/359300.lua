-- Lua provided by RyzenAPI
-- Game: addappid(359300)

-- MAIN APPLICATION
addappid(359300)

-- MAIN APP DEPOTS / PACKAGES
addappid(359301, 1, "a84c2647b937464bb51fa46dac9d5996ddc2e1c43d5c841c5c2a6fddc80484ff")
