-- Lua provided by RyzenAPI
-- Game: Spooky Shooter 3D

-- MAIN APPLICATION
addappid(1863100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863101, 1, "80b87aa17abccfc5312d76bf1999a4098882e1606b5499b90ecb08910fc6d46c")
