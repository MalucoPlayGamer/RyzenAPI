-- Lua provided by RyzenAPI
-- Game: A Regular Store

-- MAIN APPLICATION
addappid(3365450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365451, 1, "74ef31cdc637d9fb2051b8419cde76cf8f1ed84990e4974c5ff29f11edf00697")

