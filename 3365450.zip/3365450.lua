-- Lua provided by RyzenAPI
-- Game: A Regular Store

-- MAIN APPLICATION
addappid(3365450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3365451, 1, "74ef31cdc637d9fb2051b8419cde76cf8f1ed84990e4974c5ff29f11edf00697")

