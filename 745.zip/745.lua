-- Lua provided by RyzenAPI
-- Game: Counter-Strike: Global Offensive - SDK

-- MAIN APPLICATION
addappid(745)

-- MAIN APP DEPOTS / PACKAGES
addappid(745,0,"d44860df39cac46afd48e89af6a4bef065021f62b7ce95855376fa8a19da15ac")

