-- Lua provided by RyzenAPI
-- Game: Game: C.A.R.D.S. RPG: The Misty Battlefield

-- MAIN APPLICATION
addappid(2539880)
-- Game: addappid(2539880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539881, 1, "0d5e6f6f300cd9d10877064931ee2e463c429b55a6a185ee84653872b87b13ee")
