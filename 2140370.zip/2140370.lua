-- Lua provided by RyzenAPI
-- Game: 2140370

-- MAIN APPLICATION
addappid(2140370)
-- Game: addappid(2140370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140371, 1, "48b875648824324fe272bfedb5d0888fee07f6162319c53acbd940c16a82beff")
