-- Lua provided by RyzenAPI 
-- Game: Mirage Feathers
addappid(2719060)
addappid(2719061, 1, "05fdf6e0a87a40f02883352bcf83fe2cf99e9df2e9eec653b8746844a2ac12c5")
