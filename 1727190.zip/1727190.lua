-- Lua provided by RyzenAPI
-- Game: AppID 1727190

-- MAIN APPLICATION
addappid(1727190)
-- Game: addappid(1727190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727191, 1, "34dc7b6543cfb3fe536e2026c21f7a762e7fb21e0ce364a5b2ef0c6ead38aa08")
