-- Lua provided by RyzenAPI
-- Game: GUILTY GEAR Xrd -SIGN-

-- MAIN APPLICATION
addappid(376300)

-- MAIN APP DEPOTS / PACKAGES
addappid(376301, 1, "db9be068899d06cfa9f91911e0dd144e67a2ea330fb1a8b01ffb962567f09fc8")
addappid(419967, 0, "aaca9de7af0f55894c2a5724f694e6cfb5324cb47b421178afa9db116569f484")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(419470)
addappid(419471)
addappid(419472)
addappid(419473)
addappid(419474)
addappid(419475)
addappid(419476)
addappid(419477)
addappid(419478)
addappid(419479)
addappid(419930)
addappid(419931)
addappid(419932)
addappid(419933)
addappid(419934)
addappid(419935)
addappid(419936)
addappid(419937)
addappid(419938)
addappid(419939)
addappid(419940)
addappid(419941)
addappid(419942)
addappid(419943)
addappid(419944)
addappid(419945)
addappid(419946)
addappid(419947)
addappid(419948)
addappid(419949)
addappid(419960)
addappid(419961)
addappid(419962)
addappid(419963)
addappid(419964)
addappid(419965)
addappid(419966)
