-- Lua provided by RyzenAPI
-- Game: Game: Puss in Combat Boots

-- MAIN APPLICATION
addappid(2167430)
-- Game: addappid(2167430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167431, 1, "8ece7667b0acfb3f840a8f3390614a30d63467e3f0effa468a69e7f4e414e758")
addappid(2179420, 0, "9bedbb2298e3f80e970d0caf010ce9c981d1824864c82548f0ad68901ac3638d")
