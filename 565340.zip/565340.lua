-- Lua provided by RyzenAPI
-- Game: Game: AppID 565340

-- MAIN APPLICATION
addappid(565340)
-- Game: addappid(565340)

-- MAIN APP DEPOTS / PACKAGES
addappid(565341, 1, "cfc1bf21219576d67351a3ae40352e4ae39f3dbe26ea448873bbe89beff3941f")
