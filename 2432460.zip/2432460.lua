-- Lua provided by SkyAPI 
-- Game: Born to Rise
addappid(2432460)
addappid(2432461, 1, "f4825e8b5a6ab0e4c9287627c2cb8d7cde0eb162506cd0e3fb8c636225063765")
