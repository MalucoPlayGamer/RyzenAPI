-- Lua provided by RyzenAPI
-- Game: Born to Rise

-- MAIN APPLICATION
addappid(2432460)
-- Game: addappid(2432460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432461, 1, "f4825e8b5a6ab0e4c9287627c2cb8d7cde0eb162506cd0e3fb8c636225063765")
