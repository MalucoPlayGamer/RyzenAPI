-- Lua provided by RyzenAPI
-- Game: The Confession

-- MAIN APPLICATION
addappid(1289640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1289641, 1, "3d3cbed498c22c0e3ed85d38e58e7fa84d9b1140036d4fc241d17e00555789fa")

