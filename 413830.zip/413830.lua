-- Lua provided by RyzenAPI
-- Game: addappid(413830)

-- MAIN APPLICATION
addappid(413830)

-- MAIN APP DEPOTS / PACKAGES
addappid(413831, 1, "b29fdf60b493072968ff0db19139626991ca770793dc131a0e0e40cfeb378685")
