-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2765930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765930,0,"4c4d1401196b2d9e096a5c387dfc0cd6d00ccbb405d564705277e37f78e45884")

