-- Lua provided by RyzenAPI
-- Game: addappid(245850)

-- MAIN APPLICATION
addappid(245850)

-- MAIN APP DEPOTS / PACKAGES
addappid(245851, 1, "abd535eed250ff915dc2c11c620b623c8a42a9491f4e81614e4585b2aa3fbc6c")
addappid(245852, 1, "7793e4b216ff0073ce223c7ba3721bfccefe7ca71d9b983931fa980bdda6a7ff")
addappid(245853, 1, "1b2a6d06518a837f228451749423bbfe974de4db6dfbca3bdf71e47d36c8607b")
