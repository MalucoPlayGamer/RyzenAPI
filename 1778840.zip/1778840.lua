-- Lua provided by RyzenAPI
-- Game: Game: Spirit of the North 2

-- MAIN APPLICATION
addappid(1778840)
-- Game: addappid(1778840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778841, 1, "b4829fc8fb08449fc0f307d6dd4130f1eccf40bc7aae5e3c7373efa304296086")
