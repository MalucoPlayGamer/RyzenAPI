-- Lua provided by RyzenAPI
-- Game: Game: AppID 1161900

-- MAIN APPLICATION
addappid(1161900)
-- Game: addappid(1161900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161901, 1, "dc6df0a3df7810c49e9c0ce2403a5f7c0d87e40d04550744443f7048654f3b4d")
