-- Lua provided by RyzenAPI
-- Game: Game: The Gurion Mountains

-- MAIN APPLICATION
addappid(1449580)
-- Game: addappid(1449580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449581, 1, "e13fc13efe75c9ca02cc787ba782f0d8eb82d7183eab15062e2c65be3d726586")
