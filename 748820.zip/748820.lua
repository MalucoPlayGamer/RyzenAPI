-- Lua provided by RyzenAPI
-- Game: Monstrous

-- MAIN APPLICATION
addappid(748820)

-- MAIN APP DEPOTS / PACKAGES
addappid(748821,0,"24c82aad436f6152c767ca82bab4abcdff9b2cb41a386d2b914dde409e0fd254")

