-- Lua provided by RyzenAPI
-- Game: Game: Red or Blue

-- MAIN APPLICATION
addappid(3439320)
-- Game: addappid(3439320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439321, 1, "ef8fda258f1278000099050c33aad5770c14631cfc4e0f6b6b964b44f5a71748")
