-- Lua provided by RyzenAPI
-- Game: Sniper Art of Victory

-- MAIN APPLICATION
addappid(271500)

-- MAIN APP DEPOTS / PACKAGES
addappid(271501, 1, "328ade4d6b9325ca6b95ba6588f4b1c202603c391f73d010ffc84c68661c16c2")
addappid(271502, 1, "1d0a9ffaaced72e35c709cddb30d5193a0e353d777a79bcf6fcce93878623288")
addappid(271503, 1, "febf108e53d0e7d578818c317657ac65e7d0a4dc0717afb562eec9d71f4614d3")
addappid(271504, 1, "efa64fe3574f6cba1ca51648613e7d9b9ca7998e17dc0868e0a7615dff35f3c9")
addappid(271505, 1, "1506a5b36c313d6e0cca53f8071a38605aa6a03b85a1d29348c9236860e28a72")
addappid(271506, 1, "c130d71187a900fc39b6e87147b2de6ec93f6ecb99f49a8df18667f82f992c2a")
addappid(271507, 1, "aadb8243368ac8dfe7845052df0f12fdf65607daf6c376c8eb4f48806e743536")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
