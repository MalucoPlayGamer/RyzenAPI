-- Lua provided by RyzenAPI
-- Game: AppID 1033700

-- MAIN APPLICATION
addappid(1033700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033701, 1, "23f23f3b33988c0ab1fb9fd5cee898b57bf8851490aca8d4cfb5cddb6b928867")
