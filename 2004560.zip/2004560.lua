-- Lua provided by RyzenAPI
-- Game: Aces and Adventures Demo

-- MAIN APPLICATION
addappid(2004560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004561, 1, "d66bbda5c7394929739b853df430bdcfc9205c7293c7a6a65a2a35fd18721503")

