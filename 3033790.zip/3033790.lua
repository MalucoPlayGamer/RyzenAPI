-- Lua provided by RyzenAPI
-- Game: Subterror Demo

-- MAIN APPLICATION
addappid(3033790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033791, 1, "d8bec6fe265015272e01a7d2f9ad15b578b1ce26b58fa1fb1e871a66f7fad68b")

