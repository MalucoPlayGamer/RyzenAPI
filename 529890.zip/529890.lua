-- Lua provided by RyzenAPI
-- Game: Maniac Mansion

-- MAIN APPLICATION
addappid(529890)

-- MAIN APP DEPOTS / PACKAGES
addappid(529891, 1, "c33cd8859355efbc8dfbb243a689d26c68190949a8d3b7539a0c2789b7aa9fa2")
addappid(529893, 1, "67df3e9fd1785a9f08a7e3d05712168e5507ca7d058f3533d4e80ce179b677b4")

