-- Lua provided by RyzenAPI
-- Game: Box Knight

-- MAIN APP DEPOTS / PACKAGES
addappid(1678650, 1, "13bdd8c3df2c3fd75d6a547b92e740b0dc7b43f4946fc11aabab25ba0697e4f9") -- Box Knight
addappid(1678651, 1, "76c45cf0e639f271e2d09c49cd7e9d2bea293c5f21ab605bba0b544539b4cf29") -- Depot 1678651

