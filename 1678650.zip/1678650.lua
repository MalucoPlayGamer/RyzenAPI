-- 1678650's Lua and Manifest Created by Hubcap Manifest
-- Box Knight
-- Created: August 26, 2026 at 06:36:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1678650, 1, "13bdd8c3df2c3fd75d6a547b92e740b0dc7b43f4946fc11aabab25ba0697e4f9") -- Box Knight
-- MAIN APP DEPOTS
addappid(1678651, 1, "76c45cf0e639f271e2d09c49cd7e9d2bea293c5f21ab605bba0b544539b4cf29") -- Depot 1678651
setManifestid(1678651, "5274737906919070657", 4225884299)