-- Lua provided by RyzenAPI
-- Game: Assetto Corsa Competizione

-- MAIN APPLICATION
addappid(805550)
addappid(1201360)
addappid(1337860)
addappid(1449260)
addappid(1493170)
addappid(1865950)
addappid(1865970)
addappid(2328720)
addappid(2700600)
addappid(2700610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(805551, 1, "6f5126fe4ab830a15b56dc7f0fca443085cf934b3a86b59bae02e77be7d1e8fe")

