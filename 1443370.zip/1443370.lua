-- Lua provided by RyzenAPI
-- Game: The Skylia Prophecy

-- MAIN APPLICATION
addappid(1443370)
-- Game: addappid(1443370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443371, 1, "5c792d16884bd350b1739c2e28784c54528ef94fba53cd0abc058dd2d80dcc64")
