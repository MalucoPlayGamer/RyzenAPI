-- Lua provided by RyzenAPI
-- Game: Game: Frozen Shelter

-- MAIN APPLICATION
addappid(2394450)
-- Game: addappid(2394450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394451, 1, "8adbede9a43c12326700dbd0903ff4316eb26b610d426dd901900dde94a7c528")
