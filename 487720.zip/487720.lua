-- Lua provided by RyzenAPI
-- Game: addappid(487720)

-- MAIN APPLICATION
addappid(487720)

-- MAIN APP DEPOTS / PACKAGES
addappid(487721, 1, "0967d8650f46351598c6be9dded65dedf0b957a5ec0644e5ebd4378d76fb1c17")
