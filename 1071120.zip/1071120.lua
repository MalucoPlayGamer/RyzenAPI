-- Lua provided by RyzenAPI
-- Game: Mushroom Cats

-- MAIN APPLICATION
addappid(1071120)

