-- Lua provided by RyzenAPI
-- Game: Lofi Ball

-- MAIN APPLICATION
addappid(2009850)
addappid(2321810)
addappid(2355030)
addappid(2356380)
addappid(2471410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009851, 1, "af7be8a84a8cbedf6b3bf96569a50a5bc4ac5250abab06b0aed29491d42141a6")

