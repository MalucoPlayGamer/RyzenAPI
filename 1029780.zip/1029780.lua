-- Lua provided by RyzenAPI
-- Game: Going Medieval

-- MAIN APPLICATION
addappid(1029780)
addappid(4400170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029781, 1, "80cc898af46b1219817e27d4d45647970682fd0e6fe8bd0308a630baf5344b15")

