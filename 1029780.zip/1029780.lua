-- Lua provided by SkyAPI 
-- Game: AppID 1029780
addappid(1029780)
addappid(1029781, 1, "80cc898af46b1219817e27d4d45647970682fd0e6fe8bd0308a630baf5344b15")
