-- Lua provided by RyzenAPI
-- Game: AppID 1029780

-- MAIN APPLICATION
addappid(1029780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029781, 1, "80cc898af46b1219817e27d4d45647970682fd0e6fe8bd0308a630baf5344b15")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4400170)
