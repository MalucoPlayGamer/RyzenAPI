-- Lua provided by RyzenAPI
-- Game: Game: FINAL FANTASY XIII-2 Original Soundtrack PLUS

-- MAIN APPLICATION
addappid(3372170)
-- Game: addappid(3372170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372171, 1, "6206092aa2de5573478cd46856ae2e0ee597be439073a1d7a67092de1b60a113")
