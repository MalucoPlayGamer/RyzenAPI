-- Lua provided by RyzenAPI
-- Game: Forgetter

-- MAIN APPLICATION
addappid(1499990)
-- Game: addappid(1499990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499991, 1, "07f57a9b4664a6867edd05f276036c2646ca9ae9e1e10bdb70b8007ec3836c57")
