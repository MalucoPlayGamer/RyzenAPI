-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - Cardgame Sample

-- MAIN APPLICATION
addappid(1896830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896831, 1, "3876540a20e90b1478893b700baf2b2a54e6af2950f8f0ca09cad480454bb828")
