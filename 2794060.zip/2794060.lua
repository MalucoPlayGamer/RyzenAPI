-- Lua provided by RyzenAPI
-- Game: ZhaoyunChuang

-- MAIN APPLICATION
addappid(2794060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794061, 1, "2e8452edda424ada51bc2c3dc9b2d70dc293fc34a480147585524d11a5163a5d")

