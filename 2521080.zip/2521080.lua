-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2521080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521080,0,"82726248b93c5e6ffc2aff9410dbcf64aca8c2feb708f2ea8f727f8a8ae7dd41")

