-- Lua provided by RyzenAPI
-- Game: Game: AppID 349100

-- MAIN APPLICATION
addappid(349100)
-- Game: addappid(349100)

-- MAIN APP DEPOTS / PACKAGES
addappid(349101, 1, "1f68f054502896ff916d418f19f97de336ae66600927db0229cac811e68d9489")
