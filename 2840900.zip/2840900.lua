-- Lua provided by SkyAPI 
-- Game: Lilja and Natsuka Painting Lies
addappid(2840900)
addappid(2840901, 1, "ea4f551800b5ed872ef6707c3823f137a21235440b1c7e422db4ab7486a14cda")
