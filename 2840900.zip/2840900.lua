-- Lua provided by RyzenAPI
-- Game: Lilja and Natsuka Painting Lies

-- MAIN APPLICATION
addappid(2840900)
-- Game: addappid(2840900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840901, 1, "ea4f551800b5ed872ef6707c3823f137a21235440b1c7e422db4ab7486a14cda")
