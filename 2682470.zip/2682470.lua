-- Lua provided by RyzenAPI
-- Game: 2682470

-- MAIN APPLICATION
addappid(2682470)
-- Game: addappid(2682470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682471, 1, "c0a12ba09e8bc4ae050dae997cd1c624959854065e121ad9f4c1fecf8397899f")
