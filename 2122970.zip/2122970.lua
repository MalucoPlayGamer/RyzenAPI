-- Lua provided by RyzenAPI
-- Game: AppID 2122970

-- MAIN APPLICATION
addappid(2122970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122971, 1, "dfff396bdfebc5ba26b7ba0c76d95774e5d6b48ca4d0ef1946fdc79a6be76609")

