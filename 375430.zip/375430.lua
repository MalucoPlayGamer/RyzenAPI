-- Lua provided by RyzenAPI
-- Game: AppID 375430

-- MAIN APPLICATION
addappid(375430)

-- MAIN APP DEPOTS / PACKAGES
addappid(375431, 1, "e00de0a29cded75b4e239a8c80c1f3a26e411320e1e33e0f9cfb4a2c5cbfdaef")

