-- Lua provided by RyzenAPI
-- Game: addappid(295510)

-- MAIN APPLICATION
addappid(295510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252440,0,"0c17a000f8f1095b56a2ff5ee2e736d4f239bee2bb6c4307b63724b6c99af533")
addappid(1252441,0,"2fcf0f7ba559662199755fb49fd17b99d3d73d3d5efb8ab0d54d03ef39a9b72e")
