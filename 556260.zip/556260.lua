-- Lua provided by RyzenAPI
-- Game: AppID 556260

-- MAIN APPLICATION
addappid(556260)
-- Game: addappid(556260)

-- MAIN APP DEPOTS / PACKAGES
addappid(556261, 1, "90c1fdef5b7d34498eedef3c03caa34c6ec0f5702fd94fd3041c95b390d04dee")
