-- Lua provided by RyzenAPI
-- Game: Kingdoms: Merge & Build Demo

-- MAIN APPLICATION
addappid(3229740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229741, 1, "aa5d7802f86b6f9a40db828a1391dda7313ce526c11aabb5e67c71d5a9c8b58b")

