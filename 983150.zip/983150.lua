-- Lua provided by RyzenAPI
-- Game: Sakura no Mori † Dreamers 2

-- MAIN APPLICATION
addappid(983150)
-- Game: addappid(983150)

-- MAIN APP DEPOTS / PACKAGES
addappid(983151, 1, "e2bde360273ad3f3af808caa270c483b0a0a90bcadcc1673ff5c6a64c3d8e15d")
addappid(983152, 1, "0f3a63c36045a8372c6ddf054655640ec45467d4cac8dfef5c45b2e6e9939d86")
