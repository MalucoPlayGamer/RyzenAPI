-- Lua provided by RyzenAPI
-- Game: Sakura no Mori † Dreamers 2

-- MAIN APPLICATION
addappid(983150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(983151, 1, "e2bde360273ad3f3af808caa270c483b0a0a90bcadcc1673ff5c6a64c3d8e15d")
addappid(983152, 1, "0f3a63c36045a8372c6ddf054655640ec45467d4cac8dfef5c45b2e6e9939d86")

