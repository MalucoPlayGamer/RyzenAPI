-- Lua provided by RyzenAPI
-- Game: THE BUTTON by Elendow

-- MAIN APPLICATION
addappid(1999740)
addappid(2026850)
addappid(2332000)
addappid(2332001)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999741, 1, "661e21038e123947d6ac4430a771e115d0faeeadcc47aa9be09758b3d8e549a3")
addappid(1999742, 1, "775e04b28d89999c0a75f773a977f57364bfa7aeb118c4a7da8bf82e0bbaa215")

