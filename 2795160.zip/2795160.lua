-- Lua provided by RyzenAPI 
-- Game: Exosky
addappid(2795160)
addappid(2795161, 1, "8a6bddbfc10c0c9b1f2fa516c5a7631d2fb97087abccc4878446bee91bb15c66")
