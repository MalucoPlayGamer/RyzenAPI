-- Lua provided by RyzenAPI
-- Game: 2481440

-- MAIN APPLICATION
addappid(2481440)
-- Game: addappid(2481440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481441, 1, "3ee769167fff4589be74d380d446c0bdaeb63b079bf781f992ce2ddc4865b31d")
