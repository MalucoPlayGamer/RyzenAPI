-- Lua provided by RyzenAPI
-- Game: Boobs VR 2

-- MAIN APPLICATION
addappid(1403950)
-- Game: addappid(1403950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403950,0,"259d493c916f9fef5561ec952976ae5b146b5e8fcc9b6e5c3f213311f2069233")
