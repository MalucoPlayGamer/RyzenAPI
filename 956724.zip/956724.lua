-- Lua provided by RyzenAPI
-- Game: Liu Bei - Officer Ticket / 劉備使用券

-- MAIN APPLICATION
addappid(956724)

-- MAIN APP DEPOTS / PACKAGES
addappid(956724,0,"7579fe01cb58b2b59d64b5ba466ae4be86fca8db30f9954750699f48bc08e4d2")

