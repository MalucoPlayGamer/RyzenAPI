-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Sunny is streaming

-- MAIN APPLICATION
addappid(4343840) -- Hentai Clicker: Sunny is streaming

-- MAIN APP DEPOTS / PACKAGES
addappid(4343841, 1, "6f901d9a0a157330ae2ef5bbd20f62985f8a5fcd2d39e02d45e6d555f48156d2") -- Depot 4343841

