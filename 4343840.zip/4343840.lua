-- 4343840's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Sunny is streaming
-- Created: June 23, 2026 at 18:53:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4343840) -- Hentai Clicker: Sunny is streaming
-- MAIN APP DEPOTS
addappid(4343841, 1, "6f901d9a0a157330ae2ef5bbd20f62985f8a5fcd2d39e02d45e6d555f48156d2") -- Depot 4343841
setManifestid(4343841, "790242010415469551", 165927088)