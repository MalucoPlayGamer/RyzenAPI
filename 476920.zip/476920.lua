-- Lua provided by SkyAPI 
-- Game: AppID 476920
addappid(476920)
addappid(476921, 1, "70cf08a7066d8f3505d9fd199d86fc33f24a40da7f22f3e6a2a016ea65984084")
