-- Lua provided by RyzenAPI
-- Game: Game: AppID 476920

-- MAIN APPLICATION
addappid(476920)
-- Game: addappid(476920)

-- MAIN APP DEPOTS / PACKAGES
addappid(476921, 1, "70cf08a7066d8f3505d9fd199d86fc33f24a40da7f22f3e6a2a016ea65984084")
