-- Lua provided by RyzenAPI
-- Game: 3406910

-- MAIN APPLICATION
addappid(3406910)
addappid(3725940)
addappid(3857670)
-- Game: addappid(3406910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3406911, 1, "3071d68e355b513c2f032ef70401c18b3dc82991b372b61f21a70b25f3bee52b")
