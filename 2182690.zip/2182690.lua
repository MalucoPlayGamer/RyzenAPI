-- Lua provided by RyzenAPI
-- Game: 2182690

-- MAIN APPLICATION
addappid(2182690)
-- Game: addappid(2182690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182691, 1, "2f3c150ce5d80dcbe30901a2a6bf668b68f7b488d6affe81a89be33b19d27123")
