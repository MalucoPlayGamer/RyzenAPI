-- Lua provided by RyzenAPI
-- Game: 1350900

-- MAIN APPLICATION
addappid(1350900)
-- Game: addappid(1350900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350900,0,"63b39682ef62593aec4099c236bf5d70dede6f91aba90d3c0f6c1f84bd473af9")
