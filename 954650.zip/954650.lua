-- Lua provided by RyzenAPI
-- Game: AppID 954650

-- MAIN APPLICATION
addappid(954650)

-- MAIN APP DEPOTS / PACKAGES
addappid(954651, 1, "0a4594866df407233bbaab2186edad9592e6847c30dbc9fc870fd5b23097cfc2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
