-- Lua provided by RyzenAPI
-- Game: Swarm Survivor: Endless Siege

-- MAIN APP DEPOTS / PACKAGES
addappid(3745020, 1, "d2b0926558e305006287c3a97c053ecc238350bd62215f1eb58e9d36ad160b8f") -- Swarm Survivor: Endless Siege
addappid(3745021, 1, "a9de25126d650792c80144811cae2c3572fef0994d3fb6516b5672c6e4ff8f1b") -- Depot 3745021

