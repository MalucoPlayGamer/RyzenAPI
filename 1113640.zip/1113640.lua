-- Lua provided by RyzenAPI
-- Game: Escape from Labyrinth

-- MAIN APPLICATION
addappid(1113640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113641, 1, "a64c51236bd932f8ee4cae952c5524d1c375bdf69dd7f3e7facf0575e731edb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
