-- Lua provided by RyzenAPI 
-- Game: Escape from Labyrinth
addappid(1113640)
addappid(1113641, 1, "a64c51236bd932f8ee4cae952c5524d1c375bdf69dd7f3e7facf0575e731edb2")
