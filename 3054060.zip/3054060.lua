-- Lua provided by RyzenAPI
-- Game: addappid(3054060)

-- MAIN APPLICATION
addappid(3054060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054061, 1, "000002031325b7d597430bdd763848a5975b2aabbd85cdebf1b9decd620b7ef0")
