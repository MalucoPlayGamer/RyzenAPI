-- Lua provided by SkyAPI 
-- Game: Kraktures
addappid(3054060)
addappid(3054061, 1, "000002031325b7d597430bdd763848a5975b2aabbd85cdebf1b9decd620b7ef0")
