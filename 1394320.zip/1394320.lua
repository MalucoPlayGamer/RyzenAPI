-- Lua provided by RyzenAPI
-- Game: Magic Trick

-- MAIN APPLICATION
addappid(1394320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394321, 1, "4246975f2c9c97e13af9ec6b48bd32849a97de0527a899ea0d4ad57ef6347c2e")

