-- Lua provided by RyzenAPI 
-- Game: AppID 2837850
addappid(2837850)
addappid(2837851, 1, "116663c23e00d6f06d32b369c095ddf6a242939dd8435b8bbcbedf98ac0739b0")
