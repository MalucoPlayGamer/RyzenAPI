-- Lua provided by RyzenAPI
-- Game: Game: AppID 2837850

-- MAIN APPLICATION
addappid(2837850)
-- Game: addappid(2837850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837851, 1, "116663c23e00d6f06d32b369c095ddf6a242939dd8435b8bbcbedf98ac0739b0")
