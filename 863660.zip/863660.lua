-- Lua provided by RyzenAPI
-- Game: Sea of memories

-- MAIN APPLICATION
addappid(863660)

-- MAIN APP DEPOTS / PACKAGES
addappid(863661, 1, "df198f3e0bcbe3767f2f3386b4f5535a8a988791e95aa1d87c212f5177288400")

