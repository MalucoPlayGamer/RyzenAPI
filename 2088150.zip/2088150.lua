-- Lua provided by RyzenAPI 
-- Game: AppID 2088150
addappid(2088150)
addappid(2088151, 1, "c56008e7858726aeaa52aaf82013ebea183ab9787712108aa3023009abbf4faa")
