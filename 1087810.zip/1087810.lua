-- Lua provided by SkyAPI 
-- Game: Forgetful Dictator
addappid(1087810)
addappid(1087811, 1, "400e7cbe267022d0bbca9022bc797ea494ea2b2f57cb79e33b380f48ce3b49b4")
