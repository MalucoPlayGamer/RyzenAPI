-- Lua provided by RyzenAPI
-- Game: Gothic Virtual Tabletop

-- MAIN APPLICATION
addappid(2757850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757853,0,"e5e8640a48c4d92355aa339ff896e1bc9f6ee0ef8713ee67abddff80f013ea84")
addappid(2757854,0,"85a4975e372b1b89a77edd579b3145cffb227975e52bb6352da191bbf7a973fb")

