-- Lua provided by RyzenAPI
-- Game: Time Wasters

-- MAIN APPLICATION
addappid(1290330)
-- Game: addappid(1290330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290331, 1, "7f29049cc019ba30f0214906e4233cfd836704b80970027985af3a3254234594")
