-- Lua provided by RyzenAPI
-- Game: The Keep Soundtrack

-- MAIN APPLICATION
addappid(640940)
-- Game: addappid(640940)

-- MAIN APP DEPOTS / PACKAGES
addappid(640940,0,"c222beb27c274d4a8ec808a1a086b9d8cf690655f5fe9015e8028f1af0f44451")
