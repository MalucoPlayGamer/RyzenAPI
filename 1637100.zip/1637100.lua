-- Lua provided by RyzenAPI
-- Game: addappid(1637100)

-- MAIN APPLICATION
addappid(1637100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637101, 1, "2c17e3dfcc34cdcb25ce8524401181bceaefd32eac1492f0baeb7bc5a24df396")
