-- Lua provided by RyzenAPI
-- Game: Game: DREDGE

-- MAIN APPLICATION
addappid(1562430)
addappid(2104240)
addappid(2198600)
addappid(2561440)
addappid(2561450)
-- Game: addappid(1562430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562431, 1, "acf9eaa218c2a21d4505c6c9554bcef5b09bb049af53bdcf759b27c5bb16b7f8")
addappid(1562432, 1, "df7109e5cbf70a0c68998601d6bbab069037180905b28c8002f37b77cf6fe191")
addappid(2198610, 0, "24e82ac895be0fe904414677a48514d8230f80f0e8f2c050a2d81d41490d2e96")
