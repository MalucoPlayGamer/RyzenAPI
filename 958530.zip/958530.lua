-- Lua provided by RyzenAPI
-- Game: Fury of Dracula: Digital Edition

-- MAIN APPLICATION
addappid(958530)

-- MAIN APP DEPOTS / PACKAGES
addappid(958531, 1, "7969cf4cd686b5cce9039037b34e3560378a37b8f1486a307d01f9187dbeee1d")
