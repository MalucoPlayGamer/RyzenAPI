-- Lua provided by SkyAPI 
-- Game: Fury of Dracula: Digital Edition
addappid(958530)
addappid(958531, 1, "7969cf4cd686b5cce9039037b34e3560378a37b8f1486a307d01f9187dbeee1d")
