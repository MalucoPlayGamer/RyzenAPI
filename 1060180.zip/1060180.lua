-- Lua provided by RyzenAPI
-- Game: Cyber Driver

-- MAIN APPLICATION
addappid(1060180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060181, 1, "357c4d5a2bf890b0022f1104c91a65a34e9718a263bd7862e1d2ae9b6bf4b87f")
