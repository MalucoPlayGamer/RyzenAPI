-- Lua provided by SkyAPI 
-- Game: Cyber Driver
addappid(1060180)
addappid(1060181, 1, "357c4d5a2bf890b0022f1104c91a65a34e9718a263bd7862e1d2ae9b6bf4b87f")
