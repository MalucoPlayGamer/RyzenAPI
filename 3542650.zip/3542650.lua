-- 3542650's Lua and Manifest Created by Hubcap Manifest
-- Magic Typo
-- Created: July 30, 2026 at 06:36:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3542650) -- Magic Typo
-- MAIN APP DEPOTS
addappid(3542651, 1, "07ef77f8f8f65aaa5f4e0362f9e4c79a09961a1ff0f3220fd185f64c71c944ab") -- Depot 3542651
setManifestid(3542651, "798335057671923159", 15643898)