-- Lua provided by RyzenAPI
-- Game: Gateways Editor

-- MAIN APPLICATION
addappid(245640)

-- MAIN APP DEPOTS / PACKAGES
addappid(245641, 1, "1a5947f362f1354fe971367d28f4a11c2ce6bf6f2255140bef5d589805050a00")
