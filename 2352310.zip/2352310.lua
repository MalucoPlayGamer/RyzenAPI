-- Lua provided by RyzenAPI
-- Game: Game: Truck preparation for driving VR training Free

-- MAIN APPLICATION
addappid(2352310)
-- Game: addappid(2352310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352311, 1, "76708356b3050431565f456d20e39361e2c045e3c61e636d3410b0d41bc248d9")
