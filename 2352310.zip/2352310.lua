-- Lua provided by SkyAPI 
-- Game: Truck preparation for driving VR training Free
addappid(2352310)
addappid(2352311, 1, "76708356b3050431565f456d20e39361e2c045e3c61e636d3410b0d41bc248d9")
