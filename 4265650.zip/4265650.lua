-- Lua provided by RyzenAPI
-- Game: Oil Empire

-- MAIN APPLICATION
addappid(4265650)

-- MAIN APP DEPOTS / PACKAGES
addappid(4265651,0,"7975b37381b5090d8b6a79cc043237a38e483dcb1106b314217c3cf5ef049e6d")

