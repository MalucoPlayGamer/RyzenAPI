-- Lua provided by RyzenAPI
-- Game: Levels

-- MAIN APPLICATION
addappid(2203130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203131, 1, "77edef74948917be777c256a1c75de32008fe2ae471ac0719d94d996e7700cb8")
