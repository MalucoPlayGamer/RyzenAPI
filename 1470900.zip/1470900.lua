-- Lua provided by RyzenAPI
-- Game: Game: AppID 1470900

-- MAIN APPLICATION
addappid(1470900)
-- Game: addappid(1470900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470901, 1, "7495ef798172aac3fe311e55e9ce1bee2d12a096090ec90fee5bb88b7d7edbe9")
