-- Lua provided by RyzenAPI
-- Game: Game: AppID 1013350

-- MAIN APPLICATION
addappid(1013350)
-- Game: addappid(1013350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013351, 1, "24c675a5a1d93d65e6c9a75015942468c0150eefcf1093ac512c364139f60d0e")
addappid(1013352, 1, "f62c5505463cb8be881cf17cfa0d7a5a53fd8757298c1edbbfb58e8c081f05d7")
addappid(1013353, 1, "d228a3b8c5649247edb03ff40f4395cefecacefc2597c5997cb40d86f4d9b4a8")
addappid(1013354, 1, "ea42e5ff1189a919addca15930ebe61df3cf123c59b25d042986cb31913fc12e")
