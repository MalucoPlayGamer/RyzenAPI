-- Lua provided by RyzenAPI
-- Game: the Ark of Horizon

-- MAIN APPLICATION
addappid(994200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(994201, 1, "f6395af4e3c60907ebfc4d4591791f0a375fee2db97f862359dc4bf884735a47")
