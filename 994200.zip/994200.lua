-- Lua provided by RyzenAPI 
-- Game: AppID 994200
addappid(994200)
addappid(994201, 1, "f6395af4e3c60907ebfc4d4591791f0a375fee2db97f862359dc4bf884735a47")
