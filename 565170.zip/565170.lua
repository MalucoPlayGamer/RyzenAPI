-- Lua provided by RyzenAPI 
-- Game: AppID 565170
addappid(565170)
addappid(565171, 1, "e7d1a65e337775f4a28273dc161f810b9add0bcce8da54c931971752bf2007b7")
