-- Lua provided by RyzenAPI
-- Game: Blade Strangers

-- MAIN APPLICATION
addappid(565170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(565171, 1, "e7d1a65e337775f4a28273dc161f810b9add0bcce8da54c931971752bf2007b7")

