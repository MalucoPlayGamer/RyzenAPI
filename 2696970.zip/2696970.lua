-- Lua provided by RyzenAPI
-- Game: Monologue: Winter melancholy

-- MAIN APPLICATION
addappid(2696970)
-- Game: addappid(2696970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696971, 1, "e003f4ee28a2b5e2ba0021da8d0824d3310b83d3584cbebb7a80e1a0b0fbde2e")
