-- Lua provided by RyzenAPI
-- Game: AppID 615020

-- MAIN APPLICATION
addappid(615020)
addappid(984530)
addappid(1056270)

-- MAIN APP DEPOTS / PACKAGES
addappid(615021, 1, "ded7e5eef9902dd1435f5e8d0e8061238471c681ec015823d4675d324c36e240")

