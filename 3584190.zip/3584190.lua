-- Lua provided by RyzenAPI
-- Game: Three Sisters

-- MAIN APPLICATION
addappid(3584190)
-- Game: addappid(3584190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3584191, 1, "6170b384d1c20210417b87519a3a287d734640a60e194e2f980a9909b25d7eb8")
