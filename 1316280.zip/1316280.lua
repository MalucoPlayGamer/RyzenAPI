-- Lua provided by RyzenAPI
-- Game: 1316280

-- MAIN APPLICATION
addappid(1316280)
-- Game: addappid(1316280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316281, 1, "c7e2bd487ed1bc2b72aee10cf5f96cfd1fbc56526152996047fada158f604fb0")
