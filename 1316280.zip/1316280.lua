-- Lua provided by SkyAPI 
-- Game: Tekling 2: Overdrive
addappid(1316280)
addappid(1316281, 1, "c7e2bd487ed1bc2b72aee10cf5f96cfd1fbc56526152996047fada158f604fb0")
