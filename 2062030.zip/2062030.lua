-- Lua provided by RyzenAPI
-- Game: Code Alkonost: Awakening of Evil

-- MAIN APPLICATION
addappid(2062030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062031, 1, "0c0806a489d78cefb17f41cb3490f59f62750efd6b37ab1113e691181459d638")

