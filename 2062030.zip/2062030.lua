-- Lua provided by RyzenAPI
-- Game: Code Alkonost: Awakening of Evil

-- MAIN APPLICATION
addappid(2062030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062031, 1, "0c0806a489d78cefb17f41cb3490f59f62750efd6b37ab1113e691181459d638")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
