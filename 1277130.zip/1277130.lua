-- Lua provided by RyzenAPI
-- Game: addappid(1277130)

-- MAIN APPLICATION
addappid(1277130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277131, 1, "f0e25285c69f852068c19218ffc7cf08b44abe1d4f922bb637a77fc5e068e9c9")
