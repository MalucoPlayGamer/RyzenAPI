-- Lua provided by RyzenAPI
-- Game: Deathbound

-- MAIN APPLICATION
addappid(1277130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277131, 1, "f0e25285c69f852068c19218ffc7cf08b44abe1d4f922bb637a77fc5e068e9c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2936870)
addappid(2990150)
addappid(3010570)
