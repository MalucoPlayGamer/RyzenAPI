-- Lua provided by RyzenAPI
-- Game: AppID 283390

-- MAIN APPLICATION
addappid(283390)
-- Game: addappid(283390)

-- MAIN APP DEPOTS / PACKAGES
addappid(283391, 1, "e608893110076b34f8724217e70bbb3944d01f208eaae604161376f9a5a9d8ce")
