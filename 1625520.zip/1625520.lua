-- Lua provided by RyzenAPI
-- Game: Seance

-- MAIN APPLICATION
addappid(1625520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625521, 1, "f9f04e33fef1210b2f8d98df2de085a234df9d115e5f1b75fcd07ab9915a3ba0")
