-- Lua provided by RyzenAPI
-- Game: addappid(1817630)

-- MAIN APPLICATION
addappid(1817630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817631, 1, "5321ccd49b55eebdead9838f3598307d6972a7d6d39f675fb2b90bc91bb4d71c")
addappid(1817632, 1, "85baaffd9a690bb46144403e72afd653d4d2669dbefd4c4fd92bcee9b77b3736")
