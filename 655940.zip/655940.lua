-- Lua provided by RyzenAPI
-- Game: 655940

-- MAIN APPLICATION
addappid(655940)
addappid(1117270)
addappid(1142340)
-- Game: addappid(655940)

-- MAIN APP DEPOTS / PACKAGES
addappid(655941, 1, "9a342feb398b551ed7d2e7cbfb5f279a6db55e093d2298ff2cf35c425d075af4")
