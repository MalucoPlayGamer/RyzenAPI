-- Lua provided by RyzenAPI
-- Game: Elo Hell

-- MAIN APPLICATION
addappid(655940)
addappid(1117270)
addappid(1142340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(655941, 1, "9a342feb398b551ed7d2e7cbfb5f279a6db55e093d2298ff2cf35c425d075af4")

