-- Lua provided by RyzenAPI
-- Game: Wizard of Wings: Escape Demo

-- MAIN APPLICATION
addappid(3171880)
-- Game: addappid(3171880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171881, 1, "1db1df2bf0ca381be8a4eca0661bd9d1c1ae0a2deb5e4bfca51875e5cc38bb06")
