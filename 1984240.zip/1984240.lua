-- Lua provided by SkyAPI 
-- Game: Victim
addappid(1984240)
addappid(1984241, 1, "b86b9cb0644d39605bc94fdd94e3f6b0bd7762cdb13917b1f5175fc2f5a05406")
