-- Lua provided by RyzenAPI
-- Game: 2858720

-- MAIN APPLICATION
addappid(2858720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858720,0,"24021d1ebefec90bfadfd8879ae6ad52d31a9076f2a7fbed2cd6c71807067080")

