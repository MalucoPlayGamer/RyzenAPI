-- Lua provided by RyzenAPI
-- Game: Beat Saber - OneRepublic - "Counting Stars"

-- MAIN APPLICATION
addappid(1636340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636340,0,"e077189e5227961b8b2fbe6873a94327a4662c186f1d3941d5dc16ebbc262390")
