-- Lua provided by RyzenAPI
-- Game: Game: Sneak Out

-- MAIN APPLICATION
addappid(2782820)
-- Game: addappid(2782820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782821, 1, "5244df890f6c6f51a66c117fa8c02716745acde8c95ad842a541e70d20aa5bf0")
