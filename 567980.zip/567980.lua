-- Lua provided by RyzenAPI
-- Game: addappid(567980)

-- MAIN APPLICATION
addappid(567980)

-- MAIN APP DEPOTS / PACKAGES
addappid(567981, 1, "06b621f75cb3be9f797ed1b2ef2343be62e4b599fbd2aaeab20f7e12513c46e2")
addappid(568710, 0, "c04277d1b191e860ca167f6cae2570164db182dcd46e9d1fd760a8b72b6690a2")
