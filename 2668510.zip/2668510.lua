-- Lua provided by RyzenAPI
-- Game: Red Dead Redemption

-- MAIN APPLICATION
addappid(2668510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668511, 1, "839eae6ac7edb75331c27732d207b339d78db2f2bd634989b08bd602a4c5983b")
addappid(2668512, 1, "ba1f0d8d7f0e02e8659bdd8d6a7738133974941d2da9845ae59a4f0fa456d801")
addappid(2668513, 1, "af2b732e108f2a10ed375b7042e3aa1cbdf57dc59dc07c303a7d9d31e81b9c59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
