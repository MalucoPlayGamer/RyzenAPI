-- Lua provided by RyzenAPI
-- Game: Onward

-- MAIN APPLICATION
addappid(496240)

-- MAIN APP DEPOTS / PACKAGES
addappid(496241, 1, "71a14b0a9721275ee6aed871405aadf80e75224bc4bd8a6100aa5de6de3e9912")

