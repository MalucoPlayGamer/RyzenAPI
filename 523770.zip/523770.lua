-- Lua provided by SkyAPI 
-- Game: Of Bird and Cage
addappid(523770)
addappid(523771, 1, "b5ab9ccd8f84f54b759d3f44f5af87af32b6e81d3e6804cebae18cf8b6a13b45")
