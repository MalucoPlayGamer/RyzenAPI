-- Lua provided by RyzenAPI
-- Game: Of Bird and Cage

-- MAIN APPLICATION
addappid(523770)

-- MAIN APP DEPOTS / PACKAGES
addappid(523771, 1, "b5ab9ccd8f84f54b759d3f44f5af87af32b6e81d3e6804cebae18cf8b6a13b45")

