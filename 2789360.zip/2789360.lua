-- Lua provided by RyzenAPI
-- Game: Beer and Plunder Demo

-- MAIN APPLICATION
addappid(2789360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789361, 1, "e9857c02a162130216e4319258a75f265f3ab8091ecc2796487b0bf5680ea69d")
