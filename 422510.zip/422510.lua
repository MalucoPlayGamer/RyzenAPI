-- Lua provided by RyzenAPI
-- Game: AppID 422510

-- MAIN APPLICATION
addappid(422510)

-- MAIN APP DEPOTS / PACKAGES
addappid(422511, 1, "0223f5270076336702935ef060ca837fb345c42f8e675871705864d67af49323")
addappid(422512, 1, "6998dd560b01e5b93644feedcab7fc3e45f411598601d4c19ed542bd7604bc7f")
addappid(422517, 1, "811eeb4336b2aa9cb28be27343fa20479557c206694a0678ddac8f3666efcaf7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1008730)
