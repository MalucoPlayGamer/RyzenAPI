-- 2231230's Lua and Manifest Created by Hubcap Manifest
-- Solar Survivors
-- Created: July 28, 2026 at 15:10:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2231230, 1, "749655312e6d9be51bd6cb1e5bf65c59bd8c1f4928f5f41f7dfc65efffcd8558") -- Solar Survivors
-- MAIN APP DEPOTS
addappid(2231231, 1, "22d59aef1c0d7a9cf1232954d1b3413fd3afc768f85829bcc4200997b6fbb541") -- Depot 2231231
setManifestid(2231231, "366372987326317884", 560701238)