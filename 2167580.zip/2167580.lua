-- Lua provided by RyzenAPI
-- Game: addappid(2167580)

-- MAIN APPLICATION
addappid(2167580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167581, 1, "07bd2df5442b7d2faf3290d37c5faa84da8fdcad286d5eec8339b3a61d1226c6")
addappid(2167582, 1, "9e28d1dfe8c8e44fc1523d7ca9b6d3525eef3b62b28e562cf5ce01eb8618bbf0")
