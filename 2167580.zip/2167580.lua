-- Lua provided by RyzenAPI
-- Game: Summoners War: Chronicles

-- MAIN APPLICATION
addappid(2167580)
addappid(2660190)
addappid(2660200)
addappid(2742120)
addappid(2886840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2167581, 1, "07bd2df5442b7d2faf3290d37c5faa84da8fdcad286d5eec8339b3a61d1226c6")
addappid(2167582, 1, "9e28d1dfe8c8e44fc1523d7ca9b6d3525eef3b62b28e562cf5ce01eb8618bbf0")

