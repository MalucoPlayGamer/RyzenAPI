-- Lua provided by RyzenAPI
-- Game: 2802530

-- MAIN APPLICATION
addappid(2802530)
-- Game: addappid(2802530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802531, 1, "6b7be51208ed15e7da2deaaebdb43c6ae0270f9c5bef80e25b202b36f014bda5")
