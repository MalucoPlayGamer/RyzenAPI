-- Lua provided by RyzenAPI
-- Game: 2383200

-- MAIN APPLICATION
addappid(2383200)
-- Game: addappid(2383200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383201, 1, "e6ab327b2ce7b1d4a38492ab781adbe69841ef9b0a99d0d939c6c9d65eed4950")
