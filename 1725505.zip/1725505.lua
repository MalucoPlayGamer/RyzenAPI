-- Lua provided by RyzenAPI
-- Game: addappid(1725505)

-- MAIN APPLICATION
addappid(1725505)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725505,0,"e4d00c9bf6d5ed352c3046f0f626c0284a6ee6aa31e6288d4866dc0a1a402641")
