-- Lua provided by RyzenAPI
-- Game: Beat Saber - Foo Fighters - "The Pretender"

-- MAIN APPLICATION
addappid(2233137)
-- Game: addappid(2233137)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233137,0,"14441118a21955e493f983737468a6f42e7d3f9df7b3c37594aedbe72bb831dd")
