-- Lua provided by RyzenAPI
-- Game: Jelly Is Sticky

-- MAIN APPLICATION
addappid(1492620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1492621, 1, "a19333d517b43c91d85da7bf721b3be61c026a90e08cef9a0b10f3a35140212e")

