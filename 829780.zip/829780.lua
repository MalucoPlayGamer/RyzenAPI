-- Lua provided by RyzenAPI
-- Game: Baby's on fire: 99 virgins

-- MAIN APPLICATION
addappid(829780)

-- MAIN APP DEPOTS / PACKAGES
addappid(829781, 1, "429ed8cd80356b1d32e1da65c16c5b64e48d77a587b7cfa9e1997947c6871330")
