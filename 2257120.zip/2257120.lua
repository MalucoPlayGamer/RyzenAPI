-- Lua provided by RyzenAPI
-- Game: Metal Glove: Exodus

-- MAIN APPLICATION
addappid(2257120)
-- Game: addappid(2257120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257121, 1, "e7212cdb2878a0000a4c985a54dee365956de37148988ff15e9433b980d47699")
