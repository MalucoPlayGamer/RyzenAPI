-- Lua provided by RyzenAPI
-- Game: Metal Glove: Exodus

-- MAIN APPLICATION
addappid(2257120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2257121, 1, "e7212cdb2878a0000a4c985a54dee365956de37148988ff15e9433b980d47699")

