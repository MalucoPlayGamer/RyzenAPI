-- Lua provided by RyzenAPI
-- Game: PaPaPub

-- MAIN APPLICATION
addappid(962470)
addappid(1022930)

-- MAIN APP DEPOTS / PACKAGES
addappid(962471, 1, "01ce494ff71cd7980678d2acabd461d184471e01c041c277018d100f754f5bd1")

