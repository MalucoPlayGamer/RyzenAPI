-- Lua provided by RyzenAPI
-- Game: She Remembered Caterpillars Demo

-- MAIN APPLICATION
addappid(470800)

-- MAIN APP DEPOTS / PACKAGES
addappid(470801, 1, "81d664dfead7b4994b8bf3b353bc54861a695305154cf70d2e76be9377959e91")

