-- Lua provided by RyzenAPI
-- Game: addappid(2168130)

-- MAIN APPLICATION
addappid(2168130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168131, 1, "40e9a7eb3e397a7298c96623a4eb1971af974cb45f6b163266abdeb61eb2f2af")
