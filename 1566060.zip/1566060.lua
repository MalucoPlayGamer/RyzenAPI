-- Lua provided by RyzenAPI 
-- Game: Miss Furry
addappid(1566060)
addappid(1566061, 1, "d747528abd69ea5c4928913d8678065f2ceb211e41ac872c1ae399b9e23fc4af")
addappid(1566062, 1, "9b98d941a1b8631a3cdf6976d9cc12a4f7f1d3323023411a7aaaf3810a9fbd83")
addappid(1566063, 1, "0b2f16b8a4820bfc5c02a2a2161add045d530c49bcfe339ac973fb603fd48b21")
