-- Lua provided by RyzenAPI
-- Game: addappid(3161980)

-- MAIN APPLICATION
addappid(3161980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161981, 1, "dda932a5a13374ec68f153ee14c1ba78963c1a164d3318caea2473b51051de06")
