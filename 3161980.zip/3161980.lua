-- Lua provided by SkyAPI 
-- Game: Blackjack Of Lust Demo
addappid(3161980)
addappid(3161981, 1, "dda932a5a13374ec68f153ee14c1ba78963c1a164d3318caea2473b51051de06")
