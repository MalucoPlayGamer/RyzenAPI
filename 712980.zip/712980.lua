-- Lua provided by RyzenAPI
-- Game: Game: Rainyday

-- MAIN APPLICATION
addappid(712980)
-- Game: addappid(712980)

-- MAIN APP DEPOTS / PACKAGES
addappid(712981, 1, "f37506475cfe8f3beee3b3cb89e9f19bd874342cc196484b6ae17be938afa6d6")
