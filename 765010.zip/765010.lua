-- Lua provided by SkyAPI 
-- Game: Strid
addappid(765010)
addappid(765011, 1, "2d3ac7ba408d1b3add138d5139345cc0c266828ef4cc8c6bf37e696c02406c49")
