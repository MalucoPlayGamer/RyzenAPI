-- Lua provided by RyzenAPI
-- Game: Strid

-- MAIN APPLICATION
addappid(765010)
-- Game: addappid(765010)

-- MAIN APP DEPOTS / PACKAGES
addappid(765011, 1, "2d3ac7ba408d1b3add138d5139345cc0c266828ef4cc8c6bf37e696c02406c49")
