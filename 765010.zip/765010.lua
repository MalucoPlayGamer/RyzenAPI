-- Lua provided by RyzenAPI
-- Game: Strid

-- MAIN APPLICATION
addappid(765010)
addappid(906720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(765011, 1, "2d3ac7ba408d1b3add138d5139345cc0c266828ef4cc8c6bf37e696c02406c49")

