-- Lua provided by RyzenAPI
-- Game: Boy VS Genius 贫穷少年与校园名人的生死对决

-- MAIN APPLICATION
addappid(1090560)
-- Game: addappid(1090560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090561, 1, "cf462fba18fb6ee89937c2c74f4ceea9e4936000dc751100cda671279367cdff")
