-- Lua provided by RyzenAPI
-- Game: 1090560

-- MAIN APPLICATION
addappid(1090560)
-- Game: addappid(1090560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090561, 1, "cf462fba18fb6ee89937c2c74f4ceea9e4936000dc751100cda671279367cdff")
