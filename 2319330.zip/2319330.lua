-- Lua provided by RyzenAPI
-- Game: Vemari Worlds

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(229000)
addappid(2319330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319332,0,"3dd74779dc19b4b074dd72667531cbc2f5cf3e4339c781dc6473cd77ff2c2921")

