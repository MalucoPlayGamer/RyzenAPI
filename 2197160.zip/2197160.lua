-- Lua provided by RyzenAPI
-- Game: Castle Of Secrets: Prologue

-- MAIN APPLICATION
addappid(2197160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197161, 1, "cee689362c208b82b20bc6edc57b7551f171125f76e16fd078672e701bf4e78b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
