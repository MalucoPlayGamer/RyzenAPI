-- Lua provided by RyzenAPI
-- Game: Castle Of Secrets: Prologue

-- MAIN APPLICATION
addappid(2197160)
-- Game: addappid(2197160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197161, 1, "cee689362c208b82b20bc6edc57b7551f171125f76e16fd078672e701bf4e78b")
