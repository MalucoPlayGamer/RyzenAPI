-- Lua provided by RyzenAPI
-- Game: addappid(295110)

-- MAIN APPLICATION
addappid(295110)

-- MAIN APP DEPOTS / PACKAGES
addappid(295111, 1, "86d79e6dddd9c89cfdd298afd6becfca9138e78266570ddfcc002afcbbf51251")
