-- Lua provided by RyzenAPI
-- Game: Just Survive

-- MAIN APPLICATION
addappid(295110)
addappid(342160)
addappid(565620)
addappid(565621)
addappid(565622)
addappid(568110)
addappid(636240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(295111, 1, "86d79e6dddd9c89cfdd298afd6becfca9138e78266570ddfcc002afcbbf51251")

