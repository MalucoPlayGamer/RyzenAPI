-- Lua provided by RyzenAPI
-- Game: AppID 200190

-- MAIN APPLICATION
addappid(200190)
-- Game: addappid(200190)

-- MAIN APP DEPOTS / PACKAGES
addappid(200191, 1, "b12e6d601bb858158f40afa55fd643c88d66ee1f1967af24e749f5dba6965e1d")
