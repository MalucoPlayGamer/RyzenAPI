-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2100540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100540,0,"ec5b1062544a500d9637042f0a4b92f74242f68584f7fba9412e3a5b8aecfad8")
