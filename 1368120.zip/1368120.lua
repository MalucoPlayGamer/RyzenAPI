-- Lua provided by RyzenAPI
-- Game: Messy Room Simulator

-- MAIN APPLICATION
addappid(1368120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368121, 1, "97590ea230272eb4a7de6970a54e59620f21d467ff9f72958d7a3e6c0a1d6277")
