-- Lua provided by RyzenAPI
-- Game: WARNO

-- MAIN APPLICATION
addappid(1611600)
addappid(2978610)
addappid(2978620)
addappid(2978630)
addappid(2978640)
addappid(2978650)
addappid(3017370)
addappid(3025400)
addappid(3261230)
addappid(3309840)
addappid(3333260)
addappid(3333270)
addappid(3363540)
addappid(3484700)
addappid(3594460)
addappid(3601220)
addappid(3628420)
addappid(3690960)
addappid(3746630)
addappid(3828990)
addappid(4030770)
addappid(4100510)
addappid(4341720)
addappid(4579490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611600,0,"d053a11e0ae8b1c11883882bf55f125055e5965c6c57c0a35774f33ee51114d8")
addappid(1611601,0,"4f4f2eafce1c568afab8d453340193eeec38f656303f6aca28a1ba4e806204ea")
addappid(2981540,0,"9ccfc15aa1a5e2cadfbf80f7cad47232df810b4ecd7b5e5f3ae709cc36aca605")

