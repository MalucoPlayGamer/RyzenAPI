-- Lua provided by RyzenAPI
-- Game: addappid(1611600)

-- MAIN APPLICATION
addappid(1611600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611601, 1, "4f4f2eafce1c568afab8d453340193eeec38f656303f6aca28a1ba4e806204ea")
