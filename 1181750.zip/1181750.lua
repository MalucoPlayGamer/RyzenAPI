-- Lua provided by RyzenAPI
-- Game: THE VR CANYON

-- MAIN APPLICATION
addappid(1181750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181751, 1, "35dd7479b01fa6975405f6d916e6711cd0f5af8764ce1eda9b74bd3ee6c92fc5")
addappid(1181752, 1, "a1645db1efcfabe8b7ee8decbd38d91fb630f305ef5b96e94897bbdbc8f7bcbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
