-- Lua provided by RyzenAPI 
-- Game: THE VR CANYON
addappid(1181750)
addappid(1181751, 1, "35dd7479b01fa6975405f6d916e6711cd0f5af8764ce1eda9b74bd3ee6c92fc5")
addappid(1181752, 1, "a1645db1efcfabe8b7ee8decbd38d91fb630f305ef5b96e94897bbdbc8f7bcbc")
