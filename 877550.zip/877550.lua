-- Lua provided by RyzenAPI
-- Game: Digital Jigsaw Puzzle

-- MAIN APPLICATION
addappid(877550)

-- MAIN APP DEPOTS / PACKAGES
addappid(877551,0,"ebe307028126fa070108e66125a72156c85df2bc940bdc962483be3a589319ff")

