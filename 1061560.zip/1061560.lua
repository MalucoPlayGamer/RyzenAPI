-- Lua provided by RyzenAPI 
-- Game: AppID 1061560
addappid(1061560)
addappid(1061561, 1, "e14db01f55654302402e7b495d254d57202d2d35dea5fd9b9bb2aefe27aca79c")
