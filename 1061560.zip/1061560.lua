-- Lua provided by RyzenAPI
-- Game: addappid(1061560)

-- MAIN APPLICATION
addappid(1061560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061561, 1, "e14db01f55654302402e7b495d254d57202d2d35dea5fd9b9bb2aefe27aca79c")
