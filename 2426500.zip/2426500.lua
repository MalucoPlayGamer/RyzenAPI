-- Lua provided by RyzenAPI
-- Game: 2 Minutes 16 Seconds

-- MAIN APPLICATION
addappid(2426500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426501, 1, "434fef16933b3959133f9091ad87e31ff145be636c682c36f04e7a70bc40769d")
