-- Lua provided by RyzenAPI
-- Game: The Star Named Eos Demo

-- MAIN APPLICATION
addappid(2259110)
-- Game: addappid(2259110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259112,0,"63fa93f60f838256741582ff3c9ff711029eec630d48d37ba753ace655660e0b")
