-- Lua provided by RyzenAPI
-- Game: Game: WILD WEST

-- MAIN APPLICATION
addappid(1874340)
-- Game: addappid(1874340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874341, 1, "4734d7a92f852da6ec0401638b05c0421d87958c1f014aaaa1e9b2b81944f353")
