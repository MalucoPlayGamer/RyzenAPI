-- Lua provided by RyzenAPI
-- Game: Annual

-- MAIN APPLICATION
addappid(710090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(710091, 1, "024d287e9b3562d6a09391541102a02b9ef0ab8b1b3d5ab0060c382337fd7487")

