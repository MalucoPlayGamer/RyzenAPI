-- Lua provided by RyzenAPI
-- Game: Game: Fast Food Simulator

-- MAIN APPLICATION
addappid(2916430)
-- Game: addappid(2916430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916431, 1, "564c9e0805c5dec31aa2dd90a84b9b054479da085b32843dec67a4ef39a45eee")
