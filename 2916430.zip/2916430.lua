-- Lua provided by SkyAPI 
-- Game: Fast Food Simulator
addappid(2916430)
addappid(2916431, 1, "564c9e0805c5dec31aa2dd90a84b9b054479da085b32843dec67a4ef39a45eee")
