-- Lua provided by RyzenAPI
-- Game: Fast Food Simulator

-- MAIN APPLICATION
addappid(2916430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916431, 1, "564c9e0805c5dec31aa2dd90a84b9b054479da085b32843dec67a4ef39a45eee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
