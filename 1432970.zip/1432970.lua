-- Lua provided by RyzenAPI
-- Game: Game: ASSAULT SHELL

-- MAIN APPLICATION
addappid(1432970)
-- Game: addappid(1432970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432971, 1, "e4fc7b4508d180d52739edfc784ddc13b45400b9a87a9969fc288066ac79d7f4")
