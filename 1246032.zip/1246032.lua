-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Edge of Storm

-- MAIN APPLICATION
addappid(1246032)
-- Game: addappid(1246032)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246032,0,"5d4c9c3755f81062522a97cf2d906a7399668cbdcfae75905cf7abe4d5ceb66d")
