-- Lua provided by RyzenAPI
-- Game: 100 China Cats

-- MAIN APPLICATION
addappid(3141120)
-- Game: addappid(3141120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141121, 1, "72c1449dbabd955de195aa7668ac1ca73490fec265d4d9937a384835dd347549")
addappid(3801900, 0, "82d63a1cf0892bfec26aa5343e57ae810da278eecbc127a161d42a360d4e073c")
