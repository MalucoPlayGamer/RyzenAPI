-- Lua provided by RyzenAPI
-- Game: 8 Ball

-- MAIN APPLICATION
addappid(818530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(818531, 1, "91e14aae86d7731de6fc7aa76c8abb4be53057e7ffce1d2728fc2fb4a17fc7c7")
