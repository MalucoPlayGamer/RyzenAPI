-- Lua provided by RyzenAPI
-- Game: addappid(818530)

-- MAIN APPLICATION
addappid(818530)

-- MAIN APP DEPOTS / PACKAGES
addappid(818531, 1, "91e14aae86d7731de6fc7aa76c8abb4be53057e7ffce1d2728fc2fb4a17fc7c7")
