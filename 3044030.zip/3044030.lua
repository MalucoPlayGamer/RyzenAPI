-- Lua provided by RyzenAPI 
-- Game: Ten Bells
addappid(3044030)
addappid(3044031, 1, "3983990c9248f607f99e2cd1b9390f9c29164e797a395d80bfd89549dd750d23")
addappid(3044032, 1, "d597ec0c3b1e6abe6c4aca48b4a3d976129327e37b476330873343488584cf1a")
