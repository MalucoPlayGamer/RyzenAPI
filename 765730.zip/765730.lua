-- Lua provided by RyzenAPI
-- Game: addappid(765730)

-- MAIN APPLICATION
addappid(765730)

-- MAIN APP DEPOTS / PACKAGES
addappid(765731, 1, "539027ff2ba0a711442dd35e801c7a17930025fea42daa8d7616a0fefbfd5026")
