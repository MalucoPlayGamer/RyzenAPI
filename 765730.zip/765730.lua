-- Lua provided by RyzenAPI
-- Game: Wand Wars VR

-- MAIN APPLICATION
addappid(765730)

-- MAIN APP DEPOTS / PACKAGES
addappid(765731, 1, "539027ff2ba0a711442dd35e801c7a17930025fea42daa8d7616a0fefbfd5026")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
