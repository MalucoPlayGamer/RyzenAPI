-- Lua provided by RyzenAPI
-- Game: addappid(1397790)

-- MAIN APPLICATION
addappid(1397790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397792,0,"5b441e5f7ab96d6c70e83d938eafcdc9a0d9cfd37735248c07bde3dbf170131e")
