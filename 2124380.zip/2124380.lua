-- Lua provided by RyzenAPI
-- Game: Super Lesbian Animal RPG

-- MAIN APPLICATION
addappid(2124380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(2124381, 1, "339de36f78e0ed8ae02dbc27697b6e25ff149219b20391873f7aca36b1741333")

