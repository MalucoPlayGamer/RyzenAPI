-- Lua provided by RyzenAPI
-- Game: 2124380

-- MAIN APPLICATION
addappid(2124380)
-- Game: addappid(2124380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124381, 1, "339de36f78e0ed8ae02dbc27697b6e25ff149219b20391873f7aca36b1741333")
