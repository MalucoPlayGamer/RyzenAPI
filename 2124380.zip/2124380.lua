-- Lua provided by SkyAPI 
-- Game: Super Lesbian Animal RPG
addappid(2124380)
addappid(2124381, 1, "339de36f78e0ed8ae02dbc27697b6e25ff149219b20391873f7aca36b1741333")
