-- Lua provided by RyzenAPI
-- Game: AppID 769560

-- MAIN APPLICATION
addappid(769560)
-- Game: addappid(769560)

-- MAIN APP DEPOTS / PACKAGES
addappid(769561, 1, "19401507de5feddd82e4f6c61ebd98705d324389101a905c8a4665382670ceff")
addappid(769563, 1, "34364a11c5bda46ab6fce346c8a3aefc6af4549e55e891b9a02b7e3dc508f0f2")
