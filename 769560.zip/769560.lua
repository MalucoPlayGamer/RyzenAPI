-- Lua provided by RyzenAPI
-- Game: Night of the Full Moon

-- MAIN APPLICATION
addappid(769560)
addappid(1420870)
addappid(1420880)
addappid(2125560)
addappid(2125561)
addappid(2302880)
addappid(2302881)
addappid(2302882)
addappid(2302883)
addappid(2595650)
addappid(2595660)
addappid(2595670)
addappid(2595680)
addappid(2595690)
addappid(3193870)
addappid(3901740)
addappid(4231680)
addappid(4231690)
addappid(4231700)
addappid(4778420)
addappid(4778430)
addappid(4778440)

-- MAIN APP DEPOTS / PACKAGES
addappid(769561, 1, "19401507de5feddd82e4f6c61ebd98705d324389101a905c8a4665382670ceff")
addappid(769563, 1, "34364a11c5bda46ab6fce346c8a3aefc6af4549e55e891b9a02b7e3dc508f0f2")

