-- Lua provided by RyzenAPI
-- Game: Kingdom Fall, Dawn of the Druid

-- MAIN APPLICATION
addappid(1746890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746891, 1, "8e0167742e06ea8268c819036d0306c10e9aa88e8ad83ed294b389f976d618a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
