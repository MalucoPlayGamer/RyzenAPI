-- Lua provided by SkyAPI 
-- Game: Kingdom Fall, Dawn of the Druid
addappid(1746890)
addappid(1746891, 1, "8e0167742e06ea8268c819036d0306c10e9aa88e8ad83ed294b389f976d618a1")
