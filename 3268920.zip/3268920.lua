-- Lua provided by RyzenAPI
-- Game: Terrorbytes Demo

-- MAIN APPLICATION
addappid(3268920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268921, 1, "d4f9140bd7de4edb9085f985a309a746d1338c3f4df2822742a5c5ada33fbb65")
