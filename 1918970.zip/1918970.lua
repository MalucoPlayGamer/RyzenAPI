-- Lua provided by RyzenAPI
-- Game: Eresys

-- MAIN APPLICATION
addappid(1918970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918971, 1, "373461b27fbb9526bb0b32ca3ede09f3eab24512572fc0acffd95babbb12ba12")
