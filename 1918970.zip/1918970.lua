-- Lua provided by RyzenAPI
-- Game: Eresys

-- MAIN APPLICATION
addappid(1918970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918971, 1, "373461b27fbb9526bb0b32ca3ede09f3eab24512572fc0acffd95babbb12ba12")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
