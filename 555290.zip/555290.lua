-- Lua provided by RyzenAPI
-- Game: AppID 555290

-- MAIN APPLICATION
addappid(555290)
addappid(1246580)
addappid(1246581)

-- MAIN APP DEPOTS / PACKAGES
addappid(555291, 1, "63754e4b96725e4572e8c5dd3d370268d96e643a482e1b57030bd7c93039ff5d")
addappid(555292, 1, "b7e5e05ab9df6dbd72927e1d653f660776d467ffed3994c48af11adf5c2fbb23")

