-- Lua provided by RyzenAPI
-- Game: Monster Phenomenon

-- MAIN APPLICATION
addappid(1863480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863481, 1, "313b34a4a2617724538912f835c5738c8a3851fa1075f536baa2bf0d94a483c8")

