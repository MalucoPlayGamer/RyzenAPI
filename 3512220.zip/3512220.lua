-- Lua provided by RyzenAPI
-- Game: AppID 3512220

-- MAIN APPLICATION
addappid(3512220)
-- Game: addappid(3512220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3512221, 1, "65717a0d71ab79e908b8e17eb7aaacb0ea7821bed564842f346a6065527513f6")
