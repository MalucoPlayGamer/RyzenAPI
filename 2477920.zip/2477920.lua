-- Lua provided by RyzenAPI
-- Game: Hatsune Miku - The Planet Of Wonder And Fragments Of Wishes

-- MAIN APPLICATION
addappid(2477920)
-- Game: addappid(2477920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477921, 1, "246452162a6aeb6e026201faaed576de679a2a75c61780ecad66c47de4e95024")
