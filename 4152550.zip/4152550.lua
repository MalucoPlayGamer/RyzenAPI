-- Lua provided by RyzenAPI
-- Game: Eggstreme Farming

-- MAIN APPLICATION
addappid(4152550) -- Eggstreme Farming

-- MAIN APP DEPOTS / PACKAGES
addappid(4152551, 1, "a55a87ce27d14960c39df9dbb1a6b5d86bc948329ed13401da78d154d238bf6f") -- Depot 4152551

