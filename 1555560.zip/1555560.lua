-- Lua provided by RyzenAPI
-- Game: AppID 1555560

-- MAIN APPLICATION
addappid(1555560)
addappid(1555600)
addappid(1555601)
addappid(1555602)
addappid(1555603)
-- Game: addappid(1555560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555561, 1, "214178caedde03560c439add6fb9466007f096de7557d08edb7cab545af945c0")
