-- Lua provided by RyzenAPI
-- Game: addappid(2261010)

-- MAIN APPLICATION
addappid(2261010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261010,0,"11b653c7577d5c65e11f4d4bfc481bd53bf146055f425366a7aa0fc870d5496a")
