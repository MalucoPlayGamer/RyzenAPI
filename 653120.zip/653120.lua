-- Lua provided by RyzenAPI 
-- Game: AppID 653120
addappid(653120)
addappid(653121, 1, "6a5816966b34887bf6ea53aad7ecd0599d6504e04920d14cce32f689084c2323")
addappid(653123, 1, "5fee795c96de2fb8fc5d1a41559d03b12170199b764a74c2eacd547f9b97bc3d")
addappid(653124, 1, "b47da34616a1f443feba6e1b961f7706cd11d2e5a91f3c72bc1ddee0d17fa429")
