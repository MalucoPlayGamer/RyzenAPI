-- Lua provided by RyzenAPI
-- Game: AppID 653120

-- MAIN APPLICATION
addappid(653120)

-- MAIN APP DEPOTS / PACKAGES
addappid(653121, 1, "6a5816966b34887bf6ea53aad7ecd0599d6504e04920d14cce32f689084c2323")
addappid(653123, 1, "5fee795c96de2fb8fc5d1a41559d03b12170199b764a74c2eacd547f9b97bc3d")
addappid(653124, 1, "b47da34616a1f443feba6e1b961f7706cd11d2e5a91f3c72bc1ddee0d17fa429")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
