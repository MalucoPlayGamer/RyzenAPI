-- Lua provided by SkyAPI 
-- Game: AppID 1334750
addappid(1334750)
addappid(1334751, 1, "3c4ee0d8e33b51983ab60aa21591cb7d2de1c6b98a9cfd4295b96ce9a0abf997")
