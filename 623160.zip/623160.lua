-- Lua provided by RyzenAPI
-- Game: addappid(623160)

-- MAIN APPLICATION
addappid(623160)

-- MAIN APP DEPOTS / PACKAGES
addappid(623161, 1, "bb89fb76884150ac987ec501a5e3d670295e1db2f9bd3f7343925df061459fac")
