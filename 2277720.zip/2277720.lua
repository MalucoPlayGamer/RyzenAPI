-- Lua provided by RyzenAPI
-- Game: Red Glare

-- MAIN APPLICATION
addappid(2277720)
-- Game: addappid(2277720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277721, 1, "5f1ecf73f193106bdf440b2eec6c105e59ace41dd4d53c35057af6add5b24251")
