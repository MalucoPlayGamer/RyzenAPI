-- Lua provided by RyzenAPI
-- Game: Gigantosaurus: Dino Kart

-- MAIN APPLICATION
addappid(1770500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770501, 1, "2b82a0a5c959781ba5af550d57230a731df0d78888e39aa2385585c0de92e042")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
