-- Lua provided by RyzenAPI
-- Game: Game: Gigantosaurus: Dino Kart

-- MAIN APPLICATION
addappid(1770500)
-- Game: addappid(1770500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770501, 1, "2b82a0a5c959781ba5af550d57230a731df0d78888e39aa2385585c0de92e042")
