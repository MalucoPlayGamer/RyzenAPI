-- Lua provided by RyzenAPI
-- Game: DownTheDead

-- MAIN APPLICATION
addappid(1936250)
-- Game: addappid(1936250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936251, 1, "988a471c560b09bb5fdb833e1313a892c678abe2115fad9b24f68367095424df")
