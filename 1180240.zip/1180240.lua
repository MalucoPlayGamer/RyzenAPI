-- Lua provided by RyzenAPI
-- Game: AppID 1180240

-- MAIN APPLICATION
addappid(1180240)
-- Game: addappid(1180240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180241, 1, "949f816b2d4cc6c95b1cdf0a50c0c589e9a3d7b4848a951af87f3b9d7f0365b4")
