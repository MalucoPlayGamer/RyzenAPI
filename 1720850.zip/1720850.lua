-- Lua provided by RyzenAPI
-- Game: Game: A=B

-- MAIN APPLICATION
addappid(1720850)
-- Game: addappid(1720850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720851, 1, "fb181f7a04da043c4768c0c1762ba08c8d01ba0e15cb512e48f8b597f32b4b78")
addappid(1720852, 1, "86c29624f0840d65c9d18e45e7a4e5a0f10c63ffaecbb07a8105c78fdd517328")
