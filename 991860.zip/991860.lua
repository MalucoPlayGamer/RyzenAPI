-- Lua provided by RyzenAPI 
-- Game: IMAZE.EXE 2
addappid(991860)
addappid(991861, 1, "f769271a292cc8fe3c8c985df3113b988d37a0a35484d8751c4844f1fce795dc")
