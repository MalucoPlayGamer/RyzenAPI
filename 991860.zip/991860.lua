-- Lua provided by RyzenAPI
-- Game: Game: IMAZE.EXE 2

-- MAIN APPLICATION
addappid(991860)
-- Game: addappid(991860)

-- MAIN APP DEPOTS / PACKAGES
addappid(991861, 1, "f769271a292cc8fe3c8c985df3113b988d37a0a35484d8751c4844f1fce795dc")
