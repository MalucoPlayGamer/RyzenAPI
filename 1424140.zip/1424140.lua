-- Lua provided by RyzenAPI
-- Game: 1424140

-- MAIN APPLICATION
addappid(1424140)
-- Game: addappid(1424140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424141, 1, "8b5ae1b9bedc5c5cfe6b0f3f6a026d2a5ddc03358d94c739d3eb18f7c3811277")
