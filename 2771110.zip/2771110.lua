-- Lua provided by RyzenAPI
-- Game: addappid(2771110)

-- MAIN APPLICATION
addappid(2771110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771111, 1, "802dd0505be5518464fe77ed7afa2c28611463bf00ec5ef400643b323d09c4c7")
addappid(2771112, 1, "c385e52ae8ad3b8756ab3caa03e50b105c0157fb797bb5acbff1bbb8bb27692f")
