-- Lua provided by RyzenAPI
-- Game: Guild Wars 2®

-- MAIN APPLICATION
addappid(1284210)
addappid(1996840)
addappid(2008610)
addappid(2013750)
addappid(2450010)
addappid(2486290)
addappid(2982320)
addappid(2982330)
addappid(3845860)
addappid(3845870)
addappid(4158070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284211, 1, "15957cae60ac6d6ef2c8d2972c2a77160c6620b01c02dff14ae85510c0b2c5b6")
addappid(1284212, 1, "3621a9dd9b026862d51a738bbf79f6e3d7e8ac07521d78934c20d8588e00bbbc")

