-- Lua provided by SkyAPI 
-- Game: Guild Wars 2®
addappid(1284210)
addappid(1284211, 1, "15957cae60ac6d6ef2c8d2972c2a77160c6620b01c02dff14ae85510c0b2c5b6")
addappid(1284212, 1, "3621a9dd9b026862d51a738bbf79f6e3d7e8ac07521d78934c20d8588e00bbbc")
