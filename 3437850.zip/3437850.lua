-- Lua provided by RyzenAPI
-- Game: Propaganda vs. Zombies

-- MAIN APPLICATION
addappid(3437850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437851, 1, "f071c7d76f9b22e6e2a85baab42ac1e2a464264791e95ec7ae1f7c3acf4257ec")

