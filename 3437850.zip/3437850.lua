-- Lua provided by SkyAPI 
-- Game: Propaganda vs. Zombies
addappid(3437850)
addappid(3437851, 1, "f071c7d76f9b22e6e2a85baab42ac1e2a464264791e95ec7ae1f7c3acf4257ec")
