-- Lua provided by RyzenAPI
-- Game: GOAT OF DUTY

-- MAIN APPLICATION
addappid(555000)
addappid(1277681)
addappid(1277690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(555001, 1, "921094082df34744b48b0a6bee4226028cb24548860ca1aedd4a49b57cc6db65")
addappid(1277700, 0, "e09b8443b0dbf0f6d90a2d0cef5a0cf8c92f31c56fefbc6097c084394d8bc34d")

