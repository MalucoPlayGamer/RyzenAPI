-- Lua provided by RyzenAPI
-- Game: Game: AppID 555000

-- MAIN APPLICATION
addappid(555000)
addappid(1277681)
addappid(1277690)
-- Game: addappid(555000)

-- MAIN APP DEPOTS / PACKAGES
addappid(555001, 1, "921094082df34744b48b0a6bee4226028cb24548860ca1aedd4a49b57cc6db65")
addappid(1277700, 0, "e09b8443b0dbf0f6d90a2d0cef5a0cf8c92f31c56fefbc6097c084394d8bc34d")
