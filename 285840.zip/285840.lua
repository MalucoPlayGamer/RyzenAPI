-- Lua provided by RyzenAPI
-- Game: Game: Enemy Mind

-- MAIN APPLICATION
addappid(285840)
-- Game: addappid(285840)

-- MAIN APP DEPOTS / PACKAGES
addappid(285841, 1, "dd1d0ec9e7aae75341b2c39610c15cb0641cff7833f706f8f959d4a6bee76067")
addappid(285842, 1, "be55bbf527fdf5b60f748d2b0c538c1140712065392316102d862d0c639a8814")
