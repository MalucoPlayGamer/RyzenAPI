-- Lua provided by RyzenAPI
-- Game: Unlife

-- MAIN APPLICATION
addappid(1464100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464101, 1, "29e79e5c90ea9b00a710fdd54786c3f87ae2402b0933d19acf0a91742426edc1")

