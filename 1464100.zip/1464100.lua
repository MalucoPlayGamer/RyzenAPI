-- Lua provided by SkyAPI 
-- Game: Unlife
addappid(1464100)
addappid(1464101, 1, "29e79e5c90ea9b00a710fdd54786c3f87ae2402b0933d19acf0a91742426edc1")
