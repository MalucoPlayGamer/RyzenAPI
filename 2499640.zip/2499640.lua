-- Lua provided by RyzenAPI
-- Game: Deities Flush

-- MAIN APPLICATION
addappid(2499640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499649,0,"77ead61175a1d256de71756b7d56b3f17ef0f42d48893d4b920b38acebc6790b")

