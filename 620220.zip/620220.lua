-- Lua provided by RyzenAPI
-- Game: Catmaze

-- MAIN APPLICATION
addappid(620220)

-- MAIN APP DEPOTS / PACKAGES
addappid(620221, 1, "4b5433d57af8fa043a9df271181eda3dd2a1d6fbb95b6ee115bf4911ff64bb74")
addappid(620222, 1, "7b48a5c6989e4f270ee4937e68003303c6e7aabaef3373b0148723caea9c3c91")
addappid(620223, 1, "4952f93e742fc7270a09248e6e11794d01a18797aebd04bab3f062dbdbd7a888")

