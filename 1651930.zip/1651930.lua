-- Lua provided by SkyAPI 
-- Game: The Chronos Principle
addappid(1651930)
addappid(1651931, 1, "1e8294fa0dd842bcbdd07cd931874d957f6f079a5761237d008c5d3c7e6d6a78")
addappid(1651932, 1, "c9c7b37758e91cd6095c98e1ce115c3b3ea286c6bdf1a8ac4ec324b4aaf60a6f")
