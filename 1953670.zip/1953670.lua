-- Lua provided by RyzenAPI
-- Game: Quetzal's Call

-- MAIN APPLICATION
addappid(1953670)
-- Game: addappid(1953670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953671, 1, "fb66e0877989e669a801faaa18c2278645cb551745471431e531c3ac6b1ce0c5")
