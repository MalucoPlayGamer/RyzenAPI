-- Lua provided by RyzenAPI
-- Game: Monster RPG 2

-- MAIN APPLICATION
addappid(409370)
addappid(420240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(409371, 1, "d39dbeaff6a90b7b67e001733cd7171ebd67602fc73adbc6824c724edf97de78")
addappid(409374, 1, "25aac86906f93e4fcb5218d40246c7f9e554401a10adb4edd62caa2bc091fd90")

