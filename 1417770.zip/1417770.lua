-- Lua provided by RyzenAPI 
-- Game: Primeval Planet: Angimanation
addappid(1417770)
addappid(1417771, 1, "18b5dfca103afad7be8b1271e70ac8f139e977d768a57d0ebf5d0eaee6a9eedd")
