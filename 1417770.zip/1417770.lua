-- Lua provided by RyzenAPI
-- Game: Game: Primeval Planet: Angimanation

-- MAIN APPLICATION
addappid(1417770)
-- Game: addappid(1417770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417771, 1, "18b5dfca103afad7be8b1271e70ac8f139e977d768a57d0ebf5d0eaee6a9eedd")
