-- Lua provided by RyzenAPI
-- Game: 504500

-- MAIN APPLICATION
addappid(504500)
-- Game: addappid(504500)

-- MAIN APP DEPOTS / PACKAGES
addappid(504501, 1, "504dd033e8ec9c5575287f6ffc9da34ee651a458ea0489ff218696429f0e19ba")
