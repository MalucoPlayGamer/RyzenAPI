-- Lua provided by RyzenAPI
-- Game: Hover Havoc

-- MAIN APPLICATION
addappid(504500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(504501, 1, "504dd033e8ec9c5575287f6ffc9da34ee651a458ea0489ff218696429f0e19ba")

