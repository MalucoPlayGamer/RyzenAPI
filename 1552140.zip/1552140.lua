-- Lua provided by RyzenAPI
-- Game: Suzukuri Dungeon: Karin in the Mountain

-- MAIN APPLICATION
addappid(1552140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552141, 1, "e014bcb78d8d655dd13423c9529ec812454b845c31c78df9a9352da9a20ae00b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
