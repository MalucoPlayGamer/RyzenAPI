-- Lua provided by RyzenAPI
-- Game: 1552140

-- MAIN APPLICATION
addappid(1552140)
-- Game: addappid(1552140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552141, 1, "e014bcb78d8d655dd13423c9529ec812454b845c31c78df9a9352da9a20ae00b")
