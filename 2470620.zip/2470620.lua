-- Lua provided by RyzenAPI
-- Game: 2470620

-- MAIN APPLICATION
addappid(2470620)
-- Game: addappid(2470620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470621, 1, "44fd7d8610db08e836c60d38b55a011c342b20cea699ed7f3fc2651039768f98")
