-- Lua provided by RyzenAPI
-- Game: Look Outside Soundtrack

-- MAIN APPLICATION
addappid(3580350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3580351, 1, "a138c1e086aaaa678fbd2486fa39d09e40db540fa3effe8aaf2c3b5eacd44287")
