-- Lua provided by RyzenAPI
-- Game: 2660940

-- MAIN APPLICATION
addappid(2660940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660940,0,"36b7286da195dcba1175b6629b3bcd197d8fa56c679fcdf14a3d3aefb59d9876")
