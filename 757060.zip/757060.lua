-- Lua provided by RyzenAPI
-- Game: DoubleTap

-- MAIN APPLICATION
addappid(757060)

-- MAIN APP DEPOTS / PACKAGES
addappid(757061,0,"01686b929aba18bdb82ab1c65c904b9b1403b4bdff495a1ce125a1d894817762")

