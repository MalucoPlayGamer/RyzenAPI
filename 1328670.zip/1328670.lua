-- Lua provided by RyzenAPI
-- Game: AppID 1328670

-- MAIN APPLICATION
addappid(1328670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328671, 1, "1b520c64f75ebe1a7f790333c5853f8b457add2b86420baf131e3745da969f7a")
addappid(1328672, 1, "69d012c8068dd2c4629138cbec801bbb0a734de4599de6fe2bb6474998f28b39")
addappid(1328673, 1, "a221c0fffb7d13defb492a08b2b374f4c7985e350949704da3c5b898281b9b8c")
addappid(1328674, 1, "2cb09b62df0a5695580ee9fee27f68f82ca5da05dc6f7f3bf8a7fdcf4c2d8ec8")
addappid(1328675, 1, "9a76443f9117cc6c61740bed586fdbacc37f1e75253263fbf9a1da1b1fa2c79e")
addappid(1328676, 1, "1ddb6edf2f05c57067bd35342fa6d29a565858b6980cdae592d9260b07c1249c")
addappid(1328677, 1, "96579200c174b23b82fef4c3a1c5edf870062c0d3b853fe93ea5b0280aa45f75")
addappid(1328678, 1, "e8c1cfa35825cc97c40ee7f2ff2f294a3187d21c9f276f736c1daa8b660335a5")
addappid(1328679, 1, "aa32bd82a4477fea9f805725a12c6514ef11cbc069f1029161abfde1451d9e22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1393160)
