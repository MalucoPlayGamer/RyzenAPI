-- Lua provided by RyzenAPI
-- Game: Game: Lunar's Chosen - Wallpaper Pack

-- MAIN APPLICATION
addappid(1820310)
-- Game: addappid(1820310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820311, 1, "97c5e40b834efcb751e322cdabc38028462e55e88ce016f8cc15bbc4811e3f00")
