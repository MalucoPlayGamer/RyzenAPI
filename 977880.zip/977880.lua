-- Lua provided by RyzenAPI
-- Game: Eastward

-- MAIN APPLICATION
addappid(977880)

-- MAIN APP DEPOTS / PACKAGES
addappid(977881, 1, "61b3f0fbc54a5b19045f56ad4f82a3987691796e1d31aafcc3101bb7164f4a0a")
addappid(977882, 1, "2130408c437c3dc2ca74ee39385a5cd7691ec088033499fdf8b4658907389f86")
addappid(977884, 1, "e70d6634a97c4cb7c77867a994a5aeefc53dccf51be6de837316e713455639d6")
addappid(977885, 1, "bfb8c4d49777a1408d1d2e123d3f3ef2b19b95e5ee54d95ba964dca6d93c2626")
addappid(2305370, 0, "f31461b40fd343a4164c9a1127f994a4b76190d4f5c888662eed3bc6d7f88c56")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
