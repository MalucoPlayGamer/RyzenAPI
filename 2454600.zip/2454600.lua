-- Lua provided by RyzenAPI
-- Game: Ironsand

-- MAIN APPLICATION
addappid(2454600) -- Ironsand
-- addappid(5095470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454601, 1, "fad8bc092d034bb867222dd5dee3bc1c5b93c587b680ab570f124089308adfbb") -- Depot 2454601

