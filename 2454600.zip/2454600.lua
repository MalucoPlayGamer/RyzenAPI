-- 2454600's Lua and Manifest Created by Hubcap Manifest
-- Ironsand
-- Created: August 20, 2026 at 11:50:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(2454600) -- Ironsand
-- MAIN APP DEPOTS
addappid(2454601, 1, "fad8bc092d034bb867222dd5dee3bc1c5b93c587b680ab570f124089308adfbb") -- Depot 2454601
setManifestid(2454601, "4384748943067284951", 14465861858)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Ironsand - Supporter Pack (AppID: 5095470) - missing depot keys
-- addappid(5095470)