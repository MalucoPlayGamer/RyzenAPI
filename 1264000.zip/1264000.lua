-- Lua provided by SkyAPI 
-- Game: AppID 1264000
addappid(1264000)
addappid(1264001, 1, "37eebd35edcc4099aca7c65cb085774ed30970a98a2a1b6168ca2f0160f18178")
