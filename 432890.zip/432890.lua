-- Lua provided by RyzenAPI
-- Game: Quote

-- MAIN APPLICATION
addappid(432890)

-- MAIN APP DEPOTS / PACKAGES
addappid(432892,0,"0ec9bc6e4b037eae16d7b100cb03f209f0396b95679ba6d2c2d93a9bb4800f5c")

