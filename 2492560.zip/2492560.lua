-- Lua provided by RyzenAPI
-- Game: Labyrinth of Rage

-- MAIN APPLICATION
addappid(2492560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492561, 1, "3cc80327b68992532509246c975c1d2d2917ac9c5c4bf48c435e971bdb5b869e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
