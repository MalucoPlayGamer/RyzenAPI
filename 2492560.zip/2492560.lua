-- Lua provided by RyzenAPI
-- Game: Labyrinth of Rage

-- MAIN APPLICATION
addappid(2492560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492561, 1, "3cc80327b68992532509246c975c1d2d2917ac9c5c4bf48c435e971bdb5b869e")

