-- 4771890's Lua and Manifest Created by Hubcap Manifest
-- 夜魇突袭:血牌风暴
-- Created: July 23, 2026 at 02:36:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4771890) -- 夜魇突袭:血牌风暴
-- MAIN APP DEPOTS
addappid(4771891, 1, "2e89bf1a495fc1ea4a5735647782a1e74aa0f9b54d9738f8797ea6a067cad492") -- Depot 4771891
setManifestid(4771891, "4850050769737818227", 338529067)