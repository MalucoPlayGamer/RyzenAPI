-- Lua provided by RyzenAPI
-- Game: Kamasutra Connect : Sexy Hentai Girls

-- MAIN APPLICATION
addappid(929310)

-- MAIN APP DEPOTS / PACKAGES
addappid(929311, 1, "4f9ef4ed195f0c564eee109cadb7742de04b6cc085c707cc8fabc8fb8481b375")
addappid(929312, 1, "cf040daf99b39e749c8cbd830f76faed4b93e29e9c401340159e82a1304937ed")

