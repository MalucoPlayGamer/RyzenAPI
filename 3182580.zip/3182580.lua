-- Lua provided by RyzenAPI
-- Game: Game: AppID 3182580

-- MAIN APPLICATION
addappid(3182580)
-- Game: addappid(3182580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182581, 1, "4a0c3e849a708e0b1864f896fbac81ec3a786cf516dec16063eac8cbfbe6682f")
