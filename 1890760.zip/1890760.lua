-- Lua provided by RyzenAPI
-- Game: Game: Hentai Girls: Contact [18+]

-- MAIN APPLICATION
addappid(1890760)
-- Game: addappid(1890760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890761, 1, "8896c12a4638fa8c8113280f7ecade11a8041fa59ad4aa7f138fa749769bd2d2")
