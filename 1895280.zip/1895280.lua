-- Lua provided by SkyAPI 
-- Game: MacShot
addappid(1895280)
addappid(1895281, 1, "fff91057816f8a199df3e430c5729fd025a9be1bae22a853b3d098dd6e69dba6")
addappid(1895282, 1, "e79c441c5b29bc38a1d114209574be933f094e59ed77cdfe75a390d4900c07bb")
addappid(1895283, 1, "0d888597a0373d81b6e00cc36291e3cb95ebea1440d6d6e1a4f65c5a4350db56")
