-- Lua provided by RyzenAPI
-- Game: SVFI - Creative Extension Pack Access A

-- MAIN APPLICATION
addappid(1991700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991701, 1, "f2b2381c5416086818bdcba3d874725663c8064f01ca8fd4318dbe1d4fe47b3c")
