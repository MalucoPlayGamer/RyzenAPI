-- Lua provided by RyzenAPI 
-- Game: AppID 1062070
addappid(1062070)
addappid(1062071, 1, "1ead711607e5dec889257e01cd913ea9358640a72a8904f2533c0a737f12e8e6")
