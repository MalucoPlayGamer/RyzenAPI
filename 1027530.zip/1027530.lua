-- Lua provided by RyzenAPI
-- Game: Robohazard 2077

-- MAIN APPLICATION
addappid(1027530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027531, 1, "c220ba3c2aa8b445a8fac39524b130f0424dc5204b9526f396beda47c418e34e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
