-- Lua provided by RyzenAPI
-- Game: Game: Robohazard 2077

-- MAIN APPLICATION
addappid(1027530)
-- Game: addappid(1027530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027531, 1, "c220ba3c2aa8b445a8fac39524b130f0424dc5204b9526f396beda47c418e34e")
