-- Lua provided by SkyAPI 
-- Game: Robohazard 2077
addappid(1027530)
addappid(1027531, 1, "c220ba3c2aa8b445a8fac39524b130f0424dc5204b9526f396beda47c418e34e")
