-- Lua provided by RyzenAPI 
-- Game: Somber Echoes
addappid(1299290)
addappid(1299291, 1, "fc5b32cacdd3a6013c462e43074cafc32edca676dc5cfec129389fce3934f001")
