-- Lua provided by RyzenAPI
-- Game: Game: Somber Echoes

-- MAIN APPLICATION
addappid(1299290)
-- Game: addappid(1299290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299291, 1, "fc5b32cacdd3a6013c462e43074cafc32edca676dc5cfec129389fce3934f001")
