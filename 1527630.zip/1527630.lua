-- Lua provided by RyzenAPI
-- Game: 1527630

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1527630)
-- Game: addappid(1527630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527633,0,"912dafe6d862688705f3fc895d7a36f3ca5e11cb550b8e254d584cec045d8bad")
