-- Lua provided by RyzenAPI
-- Game: addappid(1862100)

-- MAIN APPLICATION
addappid(1862100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862101, 1, "2b66d02012b77ec97043daaeb06d1318b36ba74a0c68968c3f4c82f289b7585a")
