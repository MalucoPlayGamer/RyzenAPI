-- Lua provided by RyzenAPI
-- Game: Alchemist Shop Simulator Demo

-- MAIN APPLICATION
addappid(3114000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114001, 1, "166626068f66378ab79b62dc54a246802ffc41b303924885d1bd64955623cf43")

