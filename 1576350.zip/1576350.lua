-- Lua provided by RyzenAPI
-- Game: Blair Witch VR

-- MAIN APPLICATION
addappid(1576350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576351, 1, "d7ec113a72837564472a635ed1671fa0989fc5b852f21efdf8e1d584ad3f173c")
addappid(1576352, 1, "f6ddf331351e4222eff5c549a655cca342ce622a03e2c8e4da1900655f94dc93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
