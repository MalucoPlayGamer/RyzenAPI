-- Lua provided by RyzenAPI
-- Game: Game: No Such Luck

-- MAIN APPLICATION
addappid(3019400)
addappid(3949590)
-- Game: addappid(3019400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019401, 1, "71e0907742343367da06e4f8cbc1a1ec853c2b3859ad3c797ef43cd6470a431d")
