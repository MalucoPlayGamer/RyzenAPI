-- Lua provided by RyzenAPI
-- Game: AppID 1963100

-- MAIN APPLICATION
addappid(1963100)
-- Game: addappid(1963100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963101, 1, "693e95da2179145d8ef2fc47d112e1b4b463970c50dc54e6c7f20e362e5fb57f")
