-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3046970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046970,0,"6a81bf583075244cea46ebbcc2a90815fc2f23724c08f6ddb6c9d18fec34272a")
