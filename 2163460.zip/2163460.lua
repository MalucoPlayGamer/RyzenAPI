-- Lua provided by RyzenAPI
-- Game: addappid(2163460)

-- MAIN APPLICATION
addappid(2163460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163461, 1, "5cae219c1fd501a798b058551196e5b647a3e78f2dee34a1f76aab7836cc2d88")
