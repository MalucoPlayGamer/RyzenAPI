-- Lua provided by RyzenAPI
-- Game: Δ Time

-- MAIN APPLICATION
addappid(1119590)
-- Game: addappid(1119590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119591, 1, "5b7fdaf5efece2bbc760b20bce90492c1a356891316dcc4cbfaa6f3c5fb03f4d")
