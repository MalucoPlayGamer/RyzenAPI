-- Lua provided by RyzenAPI
-- Game: The Search for MR Fimple

-- MAIN APPLICATION
addappid(1835640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835641, 1, "1bfd0c70ea762538a0102c0cd085f94dad048a9b0fd2ed22927b9553987b0bde")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
