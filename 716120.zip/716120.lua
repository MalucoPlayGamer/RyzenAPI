-- Lua provided by RyzenAPI
-- Game: Oppaidius Summer Trouble! Demo

-- MAIN APPLICATION
addappid(716120)

-- MAIN APP DEPOTS / PACKAGES
addappid(716121, 1, "7d63bb29e26bf2d5a950e7935857e5f6d9fb396085ddfe60637f5f5cb59ef2ac")
