-- Lua provided by RyzenAPI
-- Game: Long Live The Queen

-- MAIN APPLICATION
addappid(251990)

-- MAIN APP DEPOTS / PACKAGES
addappid(251991, 1, "e91a4745c98a16800f42eeac21601da40020a73514a9e312dfaaffaaa85e6c65")
addappid(251992, 1, "9ec4b5aa40efcb0e46df009daafd56c00e244a17d85768f739c57c82b724c37c")
addappid(251993, 1, "18fb5507e2d205608377c4e6e95c85d24c6cae8bf422850e4c0680ddfdd0f22a")
addappid(251994, 1, "ccea40e7019813499fafdf625dd442064c7527d6e99efa91acefa25fa0b33487")
addappid(251995, 1, "558eb443fb0e80c3e883c9b58fe34c845fb2b4a936f57eb1d17f6d37e699d627")
addappid(251996, 1, "ec9de3d49e1f30aa3f4fb3c967c6da816d7c3926a9a31e8d7558fbd0d6de8caa")
addappid(251997, 1, "5288e32a49fc6c970f541ac5a5a72f7407321edc96a21ac277db5f5e015a098c")
