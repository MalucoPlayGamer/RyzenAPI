-- Lua provided by RyzenAPI
-- Game: PETS

-- MAIN APPLICATION
addappid(3362790)
-- Game: addappid(3362790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362791, 1, "7a49a868c014e48c8ae2dbdfc88785b2c0400e3e8b9b95c52b7e93190ebefc1b")
