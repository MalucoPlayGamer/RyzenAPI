-- Lua provided by RyzenAPI 
-- Game: PETS
addappid(3362790)
addappid(3362791, 1, "7a49a868c014e48c8ae2dbdfc88785b2c0400e3e8b9b95c52b7e93190ebefc1b")
