-- 2127340's Lua and Manifest Created by Hubcap Manifest
-- DAWN ONE
-- Created: August 21, 2026 at 22:33:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2127340, 1, "4d6a21809ae58c12c4c8507ab908abf95ceaefde7d60eff765f741e63eb4c6f4") -- DAWN ONE
-- MAIN APP DEPOTS
addappid(2127341, 1, "d0cbe3b622541c7af8d427fcc308e106b3402a378ec4f85f4a4b0405cb458a01") -- Depot 2127341
setManifestid(2127341, "6295144050645963652", 821748041)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)