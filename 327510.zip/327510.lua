-- Lua provided by RyzenAPI
-- Game: WASTED

-- MAIN APPLICATION
addappid(327510)
-- Game: addappid(327510)

-- MAIN APP DEPOTS / PACKAGES
addappid(327511, 1, "756b6babd9f4bd1018a5e671b33271b6682e2e05e845d5d3ced0c10f45cb2ce4")
