-- Lua provided by RyzenAPI
-- Game: Dead Dungeon

-- MAIN APPLICATION
addappid(751640)
-- Game: addappid(751640)

-- MAIN APP DEPOTS / PACKAGES
addappid(751641, 1, "6b41a0b9de319d14552d519130d6f562250d4fa17bba3ba61eeb798d4e3f122e")
addappid(751642, 1, "4d2cc1b3e2814ca50a7355cfe1d698324f15df308fd76cafd6cb928d41163dc3")
addappid(751643, 1, "b7880658280fcda2df4cee7fb1cd419cb115801d1f5346b487347e25f081a530")
