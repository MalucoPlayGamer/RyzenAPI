-- Lua provided by RyzenAPI
-- Game: addappid(3239730)

-- MAIN APPLICATION
addappid(3239730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239731, 1, "48a93b66acf694bb6edae5d63156788a9fc7a78f4d42ddd9f61e392b432e9ed1")
