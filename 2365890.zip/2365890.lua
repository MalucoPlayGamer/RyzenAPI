-- Lua provided by RyzenAPI
-- Game: addappid(2365890)

-- MAIN APPLICATION
addappid(2365890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365891, 1, "7ee3f59d4e18f08d1af65680770137b1ca0cb1c1070b2f328fc68b6e2e852937")
