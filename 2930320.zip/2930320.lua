-- Lua provided by RyzenAPI
-- Game: Pharmacy Simulator

-- MAIN APPLICATION
addappid(2930320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930322,0,"a196a53fffb6a7c01138839b4e210b0521e5179d3f8971e17622be035dfe82af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
