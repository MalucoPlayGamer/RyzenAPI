-- Lua provided by RyzenAPI
-- Game: addappid(2930320)

-- MAIN APPLICATION
addappid(2930320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930322,0,"a196a53fffb6a7c01138839b4e210b0521e5179d3f8971e17622be035dfe82af")
