-- Lua provided by RyzenAPI
-- Game: Game: 汉尘：腐草为萤

-- MAIN APPLICATION
addappid(2078910)
-- Game: addappid(2078910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078911, 1, "ca47cfa859a0729e7198bde0c958be7956f9bb89d2af8a066acb02d20e70ba0a")
