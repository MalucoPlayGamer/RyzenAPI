-- Lua provided by SkyAPI 
-- Game: AppID 350550
addappid(350550)
addappid(350551, 1, "708cb025a80b22ec11531141e33ef89f9a85008932ad4d210f9aa767e77b0500")
addappid(383860, 0, "eead4ec2a4bbe89c81ea1220b757aa352c08b0e8519e8015fdf86707d9c5c115")
