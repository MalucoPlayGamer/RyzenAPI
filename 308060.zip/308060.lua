-- Lua provided by RyzenAPI
-- Game: Black The Fall

-- MAIN APPLICATION
addappid(308060)

-- MAIN APP DEPOTS / PACKAGES
addappid(308061, 1, "1175992b0b0d52ce4c0d4e841cd7c832a24647b10e8b49fbeae003372d695c60")
addappid(308062, 1, "1ff807217e8da80d2a4b3476cc138fab5af35e459ad51a0a2cdae2bd0d0d2da7")
addappid(308063, 1, "73f66912ba86e7c81a8927074ac52afca903f7a1a4f3957bdc361e59462dc96d")
addappid(308064, 1, "30cfe4a6220b78a911247bd0a784e0bb8d47b8380fa825571cde0b7f1cba588f")
addappid(654540, 0, "791ac1a1a86f37ffffa6ba24c3d0ce3862b4449936889836e08d3b97586fc6f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
