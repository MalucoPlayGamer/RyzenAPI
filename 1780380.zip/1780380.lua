-- Lua provided by SkyAPI 
-- Game: Golf Solitaire Simple
addappid(1780380)
addappid(1780381, 1, "84467e7d35fb9edbd5fc35d375dc1a715eca48bd26a0ad4d2a25b58be85350ed")
addappid(1780382, 1, "72df9c5ae591707ab025f2a3b87565099dc2f75d8cf8f7b19c2ca019d86e75d8")
addappid(1780383, 1, "395a12f269ff00312ba9c136e6281126b024c8de343a95e149e957e6b8a60e11")
