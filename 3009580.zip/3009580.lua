-- Lua provided by RyzenAPI
-- Game: 小石冒险 - 弹幕禁止·红 BarrageForbidden-Scarlet！

-- MAIN APPLICATION
addappid(3009580)
-- Game: addappid(3009580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009580,0,"008cae9c2b7dd6d26dce3efd50da40db7c63d9a76befda7491aa6a6abbb58ddb")
