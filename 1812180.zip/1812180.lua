-- Lua provided by SkyAPI 
-- Game: Zipp's Café
addappid(1812180)
addappid(1812181, 1, "9ce825b5cbd1b8ddf198675840d5a9175d5a2edea8e758aa1ecbfdebc3150262")
