-- Lua provided by RyzenAPI
-- Game: HellGunner

-- MAIN APPLICATION
addappid(618120)

-- MAIN APP DEPOTS / PACKAGES
addappid(618121, 1, "a4d22bfbfb3b046d1c0bb2f528c39d4e67746d543235b9fab07cb3a03be67d28")
