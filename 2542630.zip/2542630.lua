-- Lua provided by SkyAPI 
-- Game: AppID 2542630
addappid(2542630)
addappid(2542631, 1, "9366a86ec6febd3ffe599a6328d819beab9461cac28ae72cd671adfa978ce62f")
