-- Lua provided by RyzenAPI
-- Game: 幻想三国志

-- MAIN APPLICATION
addappid(1457620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457621, 1, "1f3726f3b5d00ac2a30c73d871223d331b430037ccd72b11c7116690982b46d0")
addappid(1457622, 1, "1ed633a5d678119d7cbf81af8174df21b9819bd3c3ab3d9b2ffe80a8771fd49a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
