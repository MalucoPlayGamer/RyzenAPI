-- Lua provided by RyzenAPI
-- Game: 440660

-- MAIN APPLICATION
addappid(440660)
-- Game: addappid(440660)

-- MAIN APP DEPOTS / PACKAGES
addappid(440661, 1, "0fada12174ceab26d76c96db916b13b9ae35537a26508e30f89ba59c260c029c")
addappid(440662, 1, "7b7bcb3590b3213a5653a7d89c52dc551ad3a9362185b84dbed1c19900e7a214")
