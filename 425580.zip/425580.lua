-- Lua provided by RyzenAPI
-- Game: The Room Two

-- MAIN APPLICATION
addappid(425580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(425581, 1, "e462c2936219ccbd043bcbe729b2111338be43ff0475f8377d214379adea1f87")

