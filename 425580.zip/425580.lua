-- Lua provided by RyzenAPI
-- Game: The Room Two

-- MAIN APPLICATION
addappid(425580)
-- Game: addappid(425580)

-- MAIN APP DEPOTS / PACKAGES
addappid(425581, 1, "e462c2936219ccbd043bcbe729b2111338be43ff0475f8377d214379adea1f87")
