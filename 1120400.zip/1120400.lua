-- Lua provided by RyzenAPI
-- Game: Terra Randoma

-- MAIN APPLICATION
addappid(1120400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120401, 1, "7c424ef54f489eb10c0b4ad0ee24a06b7c2be945bfcd0731c7dc35f86a7e1268")
