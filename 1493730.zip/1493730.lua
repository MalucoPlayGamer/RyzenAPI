-- Lua provided by RyzenAPI
-- Game: Secret Summer

-- MAIN APPLICATION
addappid(1493730)
-- Game: addappid(1493730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493731, 1, "5005cfb7d5a4b5d14f9ff896a67d8aa7ae3889bddc1053f7460f48e997ad6d9c")
