-- Lua provided by RyzenAPI
-- Game: Railroad Corporation

-- MAIN APPLICATION
addappid(797400)
addappid(1192650)
addappid(1208150)
addappid(1300770)
addappid(1466280)
addappid(1466720)
addappid(1568200)
addappid(1739120)
addappid(2066720)
addappid(2175320)
addappid(2556960)

-- MAIN APP DEPOTS / PACKAGES
addappid(797400,0,"8116d4cb0df766b71108d950be85ebda578a0919112ea6c4a06a4139fb50f9ef")
addappid(797401,0,"8ceaa95b6b38e4c1e7bbd01fdaacd757e44d43b25f66af6f828ff510b2d6532b")
addappid(1192650,0,"b13819d702599c3b1ae4c59c4c2e13e36502f20436e352e24713e17043ce3cec")

