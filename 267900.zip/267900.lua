-- Lua provided by RyzenAPI
-- Game: Guilty Gear Isuka

-- MAIN APPLICATION
addappid(267900)

-- MAIN APP DEPOTS / PACKAGES
addappid(267901, 1, "ac1eb80f2f385bc77e544788088eac24cc501d44e4da32f213230bf57a30084f")
