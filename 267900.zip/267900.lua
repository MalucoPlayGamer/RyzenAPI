-- Lua provided by RyzenAPI
-- Game: Guilty Gear Isuka

-- MAIN APPLICATION
addappid(267900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(267901, 1, "ac1eb80f2f385bc77e544788088eac24cc501d44e4da32f213230bf57a30084f")

