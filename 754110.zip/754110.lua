-- Lua provided by RyzenAPI
-- Game: Escort Commander

-- MAIN APPLICATION
addappid(754110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(754111, 1, "31d75edfa2bd1d1c4188e0ef25d0a057c17e559d3d6842441820690ee9234687")

