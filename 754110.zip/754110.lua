-- Lua provided by RyzenAPI
-- Game: Game: Escort Commander

-- MAIN APPLICATION
addappid(754110)
-- Game: addappid(754110)

-- MAIN APP DEPOTS / PACKAGES
addappid(754111, 1, "31d75edfa2bd1d1c4188e0ef25d0a057c17e559d3d6842441820690ee9234687")
