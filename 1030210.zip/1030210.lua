-- Lua provided by RyzenAPI
-- Game: Torchlight III

-- MAIN APPLICATION
addappid(1030210)
addappid(1337370)
addappid(1358460)
addappid(1358461)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1030211,0,"294931f8d84cd3c62a79c27031c1d407e28875f7fba01c99f8e3fc6d18385280")

