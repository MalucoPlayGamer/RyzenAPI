-- Lua provided by RyzenAPI
-- Game: Torchlight III

-- MAIN APPLICATION
addappid(1030210)
addappid(1337370)
addappid(1358460)
addappid(1358461)

-- MAIN APP DEPOTS / PACKAGES
addappid(1030211,0,"294931f8d84cd3c62a79c27031c1d407e28875f7fba01c99f8e3fc6d18385280")

