-- Lua provided by RyzenAPI 
-- Game: Slice of Sea
addappid(750290)
addappid(750291, 1, "af1f776788f725cbf02052efd611178191bcff10e558865c603ed7cb47acf1fa")
addappid(750292, 1, "e372572d117c3dfcb8bac0d9f70b0619cc2db06c37fd0c54fcdc5d2c6ec7857f")
