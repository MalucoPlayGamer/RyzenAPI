-- Lua provided by RyzenAPI
-- Game: Game: Summertime Madness

-- MAIN APPLICATION
addappid(1360550)
-- Game: addappid(1360550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360551, 1, "88e96a4750f64907997164c910e3f37164d77eb97bcd78e2aaad0d0b48626576")
