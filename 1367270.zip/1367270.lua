-- Lua provided by RyzenAPI
-- Game: BATTLESCAR: Punk Was Invented By Girls

-- MAIN APPLICATION
addappid(1367270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367271, 1, "913868bf8d9164b40f704127a7a5a590468d89900feb6fa75fabeebcc91d036a")
