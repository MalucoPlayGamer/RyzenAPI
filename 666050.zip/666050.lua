-- Lua provided by RyzenAPI
-- Game: Rescue Team 7

-- MAIN APPLICATION
addappid(666050)
-- Game: addappid(666050)

-- MAIN APP DEPOTS / PACKAGES
addappid(666051, 1, "0d9e85309b734fe3a6588a11011526119acb86b3275764c0ab341ea0ecbaa175")
addappid(666053, 1, "c52f475258edded3b64951d9bbc57c15bcc31d6a22c09767554779a90c9629ee")
