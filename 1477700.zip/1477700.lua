-- Lua provided by RyzenAPI
-- Game: addappid(1477700)

-- MAIN APPLICATION
addappid(1477700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477701, 1, "2a3dda0f6eb109c85c1c45a209417c1ae3a09aaceb80d056bcc378dd2023b702")
