-- Lua provided by RyzenAPI
-- Game: 577800

-- MAIN APPLICATION
addappid(577800)
-- Game: addappid(577800)

-- MAIN APP DEPOTS / PACKAGES
addappid(577801, 1, "578f3e9a8fc232064d10861726073c62f9cc150d5cbe5b2330a7f65a642244c2")
