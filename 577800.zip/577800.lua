-- Lua provided by RyzenAPI
-- Game: NBA 2K18

-- MAIN APPLICATION
addappid(577800)

-- MAIN APP DEPOTS / PACKAGES
addappid(577801, 1, "578f3e9a8fc232064d10861726073c62f9cc150d5cbe5b2330a7f65a642244c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(610060)
addappid(629190)
addappid(629191)
