-- Lua provided by RyzenAPI
-- Game: addappid(2928660)

-- MAIN APPLICATION
addappid(2928660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928661, 1, "b1796fe49de9abb9d7b5cf5b696a0e730bcfeb619aaf488cb46cc81f7cfcb5a8")
