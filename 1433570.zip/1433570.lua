-- Lua provided by RyzenAPI
-- Game: Car Detailing Simulator

-- MAIN APPLICATION
addappid(1433570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433572,0,"6fdbb0037c4aa12c03a2684a46ed80f7edb869e441ae37d43d3e5ec00d6a4b5e")
addappid(1802264,0,"5a4caf851a74cbbe8fe3c15cb6d030a49f3cad0266048fe3f8d2c4b97677284a")
addappid(2161872,0,"dfa5152a177d80677faaa80ce6a5cb632d7e8a140145ccac9035a7fa93fa5945")
