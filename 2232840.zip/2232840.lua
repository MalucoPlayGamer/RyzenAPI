-- Lua provided by RyzenAPI
-- Game: Garten of Banban

-- MAIN APPLICATION
addappid(2232840)
addappid(4163900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2232841, 1, "f463c6b7a54bd7052749957d74e0f15902023349913787914128c3d16e8bdc8c")

