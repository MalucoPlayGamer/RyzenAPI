-- Lua provided by RyzenAPI
-- Game: Garten of Banban

-- MAIN APPLICATION
addappid(2232840)
addappid(4163900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232841, 1, "f463c6b7a54bd7052749957d74e0f15902023349913787914128c3d16e8bdc8c")
