-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 9

-- MAIN APPLICATION
addappid(2448080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448080,0,"4c7ad852d004c44ac65ad7ed8949c5fb5682288b8f8ede27668544828b7431f5")

