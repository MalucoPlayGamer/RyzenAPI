-- Lua provided by RyzenAPI
-- Game: How To Survive: Third Person Standalone

-- MAIN APPLICATION
addappid(360150)
-- Game: addappid(360150)

-- MAIN APP DEPOTS / PACKAGES
addappid(360151, 1, "040ed0243998be372fe25b2ff7fb523b29bead98ef29646666a9aedf6bd1a752")
addappid(360152, 1, "b4fb76b062fe2c5d514e5d33345ea8e1b48a87f2267129a283559acf247ca1db")
addappid(360153, 1, "3cee40bff1140f02f03ae15e06a27fa53e903cbb187ca4617670147781878fe5")
addappid(360154, 1, "a5065dad52734fe8262be3d0bc7f5c7acd20ca5b3198cd2cf0e68dd4b47dfd86")
addappid(360155, 1, "f5463f40b0d10d985796e851bf070f102751844bc95ce7616c40b1d5130df47e")
addappid(360156, 1, "87bda5f5650b41e9d840b57ec4e0c11b8cee94d861b69ac039a0fe9cb6e7220c")
addappid(360157, 1, "bdc1e3a96fb95c1f5d07c417d17a7eedc061c852b2a4081aa47b0d1631f9cf51")
addappid(360158, 1, "e37540c4ee88027bf65d1c4e77736f2315a62901ae6e7215829224ee324ac560")
