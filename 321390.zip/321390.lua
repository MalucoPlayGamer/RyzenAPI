-- Lua provided by RyzenAPI
-- Game: Zone 22

-- MAIN APPLICATION
addappid(321390)

-- MAIN APP DEPOTS / PACKAGES
addappid(321391, 1, "252a14f5e873856804bdbc2692b0bffb6c3e6e4989cf0d1236bcd67efbea9f1a")
