-- Lua provided by RyzenAPI
-- Game: Boxman's Struggle

-- MAIN APPLICATION
addappid(1228560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228561, 1, "159fecd857c30777ce8bf4a4b3a69140ad9e7e697df2e06ba96b7600689687aa")
