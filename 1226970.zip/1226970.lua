-- Lua provided by RyzenAPI 
-- Game: Disco Simulator
addappid(1226970)
addappid(1226971, 1, "c0fbd201860c52f99170078e2ad565ab45aad674d818ac9d1d04552f06489046")
