-- Lua provided by RyzenAPI
-- Game: Game: Disco Simulator

-- MAIN APPLICATION
addappid(1226970)
-- Game: addappid(1226970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226971, 1, "c0fbd201860c52f99170078e2ad565ab45aad674d818ac9d1d04552f06489046")
