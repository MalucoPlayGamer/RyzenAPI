-- Lua provided by RyzenAPI
-- Game: Transistor

-- MAIN APPLICATION
addappid(237930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(237931, 1, "64d71a7396179714511a13c17f8608210be0b1e6454ed22bbcf1ca39974773a9")
addappid(237932, 1, "feea2c931de8b99499f33a16b4008b739231d19ef4b3bb9010545dd808e6cdd6")
addappid(237933, 1, "4da16e2d3b3b3b5d640f12ce049cb54e2a7e650a02e3fef9d96d9f392a75b218")
addappid(237934, 1, "ca69c0b218742d719af7cc241ab5c6bae6bbe737c541936cf1ca7533f9c6b221")
addappid(237935, 1, "442c4ba3dddca111764d9ed8d36c3c76b5a3966980261046021102fe2553d5a0")
