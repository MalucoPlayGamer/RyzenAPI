-- Lua provided by RyzenAPI
-- Game: Sweet Dream

-- MAIN APPLICATION
addappid(1639520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639521, 1, "9da7e42f5edef0b511cbc0de75ca84163fc1b6911f21fd5ff98d11998d7b6d0a")
