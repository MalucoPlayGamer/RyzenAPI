-- Lua provided by RyzenAPI
-- Game: Kanon

-- MAIN APPLICATION
addappid(2850310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850311, 1, "6bbee5ccd95b5f0ecd4468b82abb7710f269833055353288c20fcb02fb5e8b8b")
