-- Lua provided by RyzenAPI
-- Game: Windblown: Soundtrack

-- MAIN APPLICATION
addappid(3285350)
-- Game: addappid(3285350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3285351, 1, "a132e363e6d4cdf9075ce07b2873b83164f5f01320cb0157a4a93e68b209c8d6")
addappid(3285352, 1, "9f272aae070ba5fe5a1abdd128d2d5a907fe255096e2708efc106395fec68c1b")
