-- Lua provided by RyzenAPI 
-- Game: Hustle Game
addappid(1683590)
addappid(1683591, 1, "1d7e348a97e7128c6562a5bd10d9502f16c0aaee861605fb816c60b4d0137462")
