-- Lua provided by RyzenAPI
-- Game: Typing Farmer

-- MAIN APPLICATION
addappid(4216670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4216671,0,"a29fb95d81ca2716a5dd1119da1b52747844c57cade18b1a386673099cc7c665")

