-- Lua provided by RyzenAPI
-- Game: Card Streamer Simulator

-- MAIN APPLICATION
addappid(3592240)
-- Game: addappid(3592240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3592241, 1, "6ff5110d16d6ca6fe555fa75fc86ccf0ceb0a264f34f87585f9e225c69bf5bb5")
