-- Lua provided by RyzenAPI
-- Game: Don't Take It Personally, I Just Don't Like You

-- MAIN APPLICATION
addappid(1296490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296491, 1, "9ed7e3c59469406a6b2ba66f16520a020432480c9f0ffdf869920f09b3871d38")

