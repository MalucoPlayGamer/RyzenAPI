-- Lua provided by SkyAPI 
-- Game: LUMbA: HANGOVER
addappid(2198770)
addappid(2198771, 1, "3cb7229b7768c6c525e6f3845ffc4f3d9cf2ad3f2dc9139c4a544ef8a5bfc000")
