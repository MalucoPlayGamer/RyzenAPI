-- Lua provided by RyzenAPI
-- Game: addappid(2340160)

-- MAIN APPLICATION
addappid(2340160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340161, 1, "3b3f133387bd18da420edbea98829e8eb0f4a75a0b3f6250fcb16f9e0e312f9a")
