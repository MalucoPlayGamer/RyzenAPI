-- Lua provided by SkyAPI 
-- Game: Faculty
addappid(2286940)
addappid(2286941, 1, "7b60c9162d6907cdb108bca1e0c6ec0d5a5f2c9e19afb206b108376e774fd14b")
