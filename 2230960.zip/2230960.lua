-- Lua provided by RyzenAPI
-- Game: Game: AppID 2230960

-- MAIN APPLICATION
addappid(2230960)
-- Game: addappid(2230960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230961, 1, "031924117b8f51f8e10d1c4d7d69408f423496147aa4fe88dfa4601bfd5034b4")
