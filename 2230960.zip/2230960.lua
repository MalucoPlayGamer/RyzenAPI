-- Lua provided by RyzenAPI
-- Game: Sports: Renovations

-- MAIN APPLICATION
addappid(2230960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2230961, 1, "031924117b8f51f8e10d1c4d7d69408f423496147aa4fe88dfa4601bfd5034b4")

