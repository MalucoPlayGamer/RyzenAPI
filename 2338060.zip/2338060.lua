-- Lua provided by RyzenAPI
-- Game: Game: Ascendant Playtest

-- MAIN APPLICATION
addappid(2338060)
-- Game: addappid(2338060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338061, 1, "30456dc1aee9e7208e7bdb81e963412044270110e74bb6f7725031a718f64609")
