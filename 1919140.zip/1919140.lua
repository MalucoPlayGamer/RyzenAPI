-- Lua provided by RyzenAPI
-- Game: Antioch: Scarlet Bay

-- MAIN APPLICATION
addappid(1919140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919141, 1, "5646e5c25884e215ae1d0293716a0e039c9e4e1432ddc96686db6f96cc4900e8")
