-- Lua provided by RyzenAPI
-- Game: Game: Shitty Cactus

-- MAIN APPLICATION
addappid(1229650)
-- Game: addappid(1229650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229651, 1, "4ad48fd8b0c1953f77890ab1e22d015116ce68b44437b75859b09f21f3fa4000")
