-- Lua provided by RyzenAPI
-- Game: Merchant's Rush

-- MAIN APPLICATION
addappid(2110600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2110601, 1, "d49c2b252b82188d998f455de5135b35e6752cc9da29afcc051365dc376a5ff5")

