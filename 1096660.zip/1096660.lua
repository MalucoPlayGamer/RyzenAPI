-- Lua provided by RyzenAPI
-- Game: addappid(1096660)

-- MAIN APPLICATION
addappid(1096660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096661, 1, "9246042cf70f9eec941e8064b720eebabf7669503253d3f7816234bdccd51aef")
