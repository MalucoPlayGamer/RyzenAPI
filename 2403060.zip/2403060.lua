-- Lua provided by RyzenAPI
-- Game: Game: Dinosaur Land Aerial Photograph

-- MAIN APPLICATION
addappid(2403060)
-- Game: addappid(2403060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403061, 1, "7b365d9b63425a8e9e8c84eee2a5befc8c1548760aa6f44c8b62ddce3c43e1b8")
