-- Lua provided by RyzenAPI
-- Game: Dinosaur Land Aerial Photograph

-- MAIN APPLICATION
addappid(2403060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403061, 1, "7b365d9b63425a8e9e8c84eee2a5befc8c1548760aa6f44c8b62ddce3c43e1b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
