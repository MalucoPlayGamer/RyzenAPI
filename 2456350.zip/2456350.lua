-- Lua provided by RyzenAPI
-- Game: 2456350

-- MAIN APPLICATION
addappid(2456350)
-- Game: addappid(2456350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456351, 1, "5ccb2b5564af5a9512d72b2c4a917f78210a4b3ef66a81992a9cde71fa378a56")
