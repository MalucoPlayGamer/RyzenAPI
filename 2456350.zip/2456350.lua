-- Lua provided by SkyAPI 
-- Game: The Scourge | Tai Ương
addappid(2456350)
addappid(2456351, 1, "5ccb2b5564af5a9512d72b2c4a917f78210a4b3ef66a81992a9cde71fa378a56")
