-- Lua provided by RyzenAPI
-- Game: SMASH LEGENDS

-- MAIN APPLICATION
addappid(1352080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352081, 1, "20447818b9565461276861087cdd7b980534e7e2c2bb27a52c707743691450a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
