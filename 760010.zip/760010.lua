-- Lua provided by RyzenAPI
-- Game: Flying Turkey

-- MAIN APPLICATION
addappid(760010)

-- MAIN APP DEPOTS / PACKAGES
addappid(760011, 1, "c2418b672ea01a7dfc4a28cd8c9559c84bcd532c74dbd8de12772ed836c34a6b")

