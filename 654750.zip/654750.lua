-- Lua provided by RyzenAPI
-- Game: Game: AppID 654750

-- MAIN APPLICATION
addappid(654750)
-- Game: addappid(654750)

-- MAIN APP DEPOTS / PACKAGES
addappid(654751, 1, "c9aa0b48018e89c46559a4d1e0cc4cf86c7b3296917bf5b4ae5ce0e4158bb310")
