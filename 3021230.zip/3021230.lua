-- Lua provided by RyzenAPI
-- Game: Crisis in the Kremlin: The Cold War. DEMO VERSION.

-- MAIN APPLICATION
addappid(3021230)
-- Game: addappid(3021230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021231, 1, "a551341d2b0a864e2d3f2b95350028e4cfde15fc53670cb33af70e34b1d2dd7c")
