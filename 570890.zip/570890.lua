-- Lua provided by RyzenAPI
-- Game: addappid(570890)

-- MAIN APPLICATION
addappid(570890)

-- MAIN APP DEPOTS / PACKAGES
addappid(570891, 1, "050e9c59f8c87027eee762b97fd9278cc80e3daa508ef14beb99ace353a9e4e2")
