-- Lua provided by RyzenAPI
-- Game: Fahrenheit: Indigo Prophecy Remastered

-- MAIN APPLICATION
addappid(312840)

-- MAIN APP DEPOTS / PACKAGES
addappid(312841, 1, "d05346a49a29a9fbf0451e3c6cee99301a36876c966b905d163a3fb8282d1f94")
addappid(312842, 1, "7a6ae5406d5425bcce6fa06408a94536f53e4370d1f1884e73dda38b78fb081f")
addappid(312843, 1, "3bc0aa552c66b883e9a15156c9ae2804e894c6b52f8a89f8125f35e82e63e2e6")
addappid(312844, 1, "955c7982f628a7c4f66e39ffbf1b89a6003cd1e1e6aa5e4c1ee88244adfc2c56")
addappid(312845, 1, "f806ebcb395256899bedea7843ebcfdda5b73a3a72758ed352fb66cb0f61e3f5")
addappid(312846, 1, "f1e5a21fc6bf1eb354305922f041e63f00c86130a6c8ed4a196b8cf226d7fa06")

