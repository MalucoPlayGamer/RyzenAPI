-- Lua provided by RyzenAPI
-- Game: 432170

-- MAIN APPLICATION
addappid(432170)
-- Game: addappid(432170)

-- MAIN APP DEPOTS / PACKAGES
addappid(432171, 1, "10ec6ed434433b9c768fdc447061bd84f96906f482c19df8466e4733383e73c0")
