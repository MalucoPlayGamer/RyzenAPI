-- Lua provided by RyzenAPI
-- Game: The Sentinel

-- MAIN APPLICATION
addappid(2568600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568601, 1, "9186aeb7d7cbe81adb45e8d1a56564203eb05eacb16089476536f7831bcf0559")

