-- Lua provided by RyzenAPI
-- Game: AppID 3432500

-- MAIN APPLICATION
addappid(3432500)
-- Game: addappid(3432500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432501, 1, "13fe28ca56733e33289dd6b3090b73b069a365d1009fdd56cd5626424c56ffa1")
