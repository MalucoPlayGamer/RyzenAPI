-- Lua provided by RyzenAPI
-- Game: Superliminal Double-Album Soundtrack

-- MAIN APPLICATION
addappid(1440610)
-- Game: addappid(1440610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440611, 1, "9fb8ff38a7860a864e58c69f554b6713c4820ec069b16e6f1e654971432c1179")
