-- Lua provided by RyzenAPI
-- Game: Examination Chambers

-- MAIN APPLICATION
addappid(1820350)
-- Game: addappid(1820350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820351, 1, "f3be0ee615873373e765e57ddba2ab695c0e5bf9271e05a4b30e15930f9e28a4")
