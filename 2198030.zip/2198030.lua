-- Lua provided by SkyAPI 
-- Game: Iron Mandate
addappid(2198030)
addappid(2198031, 1, "a3662841ab4e54592a3150b535e8e50d7f5ba3a3e3aea7fc3c96aeed0ccb5871")
