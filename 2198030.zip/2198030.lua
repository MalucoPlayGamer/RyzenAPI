-- Lua provided by RyzenAPI
-- Game: Iron Mandate

-- MAIN APPLICATION
addappid(2198030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198031, 1, "a3662841ab4e54592a3150b535e8e50d7f5ba3a3e3aea7fc3c96aeed0ccb5871")

