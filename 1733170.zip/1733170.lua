-- Lua provided by RyzenAPI
-- Game: Killing Time: Resurrected

-- MAIN APPLICATION
addappid(1733170)
-- Game: addappid(1733170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733171, 1, "415d080ae40a9c6e5e7dac3fdfb509a4946a1af264902e3c19f87fcf8887b189")
addappid(1733172, 1, "a2e1de84931ba6577ffe76a902f099e1c85db7f3d30b1969c8b52b2ffb9798ea")
addappid(1733173, 1, "2f000270474f87f3a155fc3d4a52fa7fe3628cc2e021940a2bd457e55e3dd3d3")
