-- Lua provided by RyzenAPI
-- Game: 604190

-- MAIN APPLICATION
addappid(604190)
-- Game: addappid(604190)

-- MAIN APP DEPOTS / PACKAGES
addappid(604191, 1, "895497c59e82b10720fa6e9f3292bcb84a48e010f0ec81078c2a138aa2791cfa")
