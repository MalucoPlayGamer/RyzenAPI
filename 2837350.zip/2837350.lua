-- Lua provided by RyzenAPI
-- Game: Block Tower TD 2

-- MAIN APPLICATION
addappid(2837350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837351, 1, "3a6b5e9e13dec8321cd2ea00477db068d8aefb93dd2ad014d57ccdc3372c4bac")

