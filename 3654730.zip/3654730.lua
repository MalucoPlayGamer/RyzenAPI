-- Lua provided by SkyAPI 
-- Game: AppID 3654730
addappid(3654730)
addappid(3654731, 1, "c19643d5233de103d9d6e8df1f8d3d73ae4237847e1e8fcc6e670b4e50c73f80")
