-- Lua provided by RyzenAPI
-- Game: 3654730

-- MAIN APPLICATION
addappid(3654730)
-- Game: addappid(3654730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3654731, 1, "c19643d5233de103d9d6e8df1f8d3d73ae4237847e1e8fcc6e670b4e50c73f80")
