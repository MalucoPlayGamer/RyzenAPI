-- Lua provided by RyzenAPI
-- Game: Game: Fireflies & Figments: A Willow's Journey

-- MAIN APPLICATION
addappid(1853650)
-- Game: addappid(1853650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853651, 1, "b493bec25d04a517ff61b9a2a4ab980ef8a98685980526f2524cbee3dfce781f")
