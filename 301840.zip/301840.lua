-- Lua provided by RyzenAPI
-- Game: AppID 301840

-- MAIN APPLICATION
addappid(301840)
addappid(828650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(301841, 1, "3ecf26b81fe3b3a9f3f44bdeb1120aa084969a8560bd6431bd427717c684d647")
addappid(834020, 0, "2b065a9ad96209f05a7c0ab2ae7c0aab1912cfa9c743b1a7de583d05ca6bcb7a")

