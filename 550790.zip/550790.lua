-- Lua provided by RyzenAPI
-- Game: AppID 550790

-- MAIN APPLICATION
addappid(550790)

-- MAIN APP DEPOTS / PACKAGES
addappid(550791, 1, "87709b5dd064f9761d9a5752ba2588b182d5fa939da19eddc5eac6ee6ae5d03f")
