-- Lua provided by RyzenAPI
-- Game: Trials of the Blood Dragon

-- MAIN APPLICATION
addappid(435480)
addappid(488980)
addappid(488981)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(435481, 1, "ddd7b6747b7a31651a8cb793ab966a8017f56627b1b9dfafabe568c3687a089e")
addappid(435482, 1, "36a2c6ef9ad6cb45f1725d4d9e5b23cce0c2ffcf02db57b1f965baf250fc6c8c")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

