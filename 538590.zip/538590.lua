-- Lua provided by RyzenAPI
-- Game: Sleeping Valley

-- MAIN APPLICATION
addappid(538590)
addappid(548410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(538591, 1, "bc265a348eecf20ed8946e737c5936e5a043792f66b75fca9da9871eae703b40")

