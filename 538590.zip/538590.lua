-- Lua provided by RyzenAPI
-- Game: 538590

-- MAIN APPLICATION
addappid(538590)
addappid(548410)
-- Game: addappid(538590)

-- MAIN APP DEPOTS / PACKAGES
addappid(538591, 1, "bc265a348eecf20ed8946e737c5936e5a043792f66b75fca9da9871eae703b40")
