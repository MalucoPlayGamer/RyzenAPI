-- Lua provided by RyzenAPI
-- Game: Game: Rogue Glitch Ultra

-- MAIN APPLICATION
addappid(1092630)
-- Game: addappid(1092630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092631, 1, "d39265cb34556230eff34f053893a0f2971588c51da507c34f4ebacf5056fe25")
addappid(1092632, 1, "04ae1716dfe93902e0f98371a5c4efaad043dfa5b021344d1e69738b36095d2a")
addappid(2698210, 0, "caaf887bd3a7169f4b40b5325a56bde908ee5a36ef594aa91fbfc52076e94487")
