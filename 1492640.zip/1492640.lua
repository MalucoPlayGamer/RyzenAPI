-- Lua provided by RyzenAPI
-- Game: Game: Mixx Island: Remix

-- MAIN APPLICATION
addappid(1492640)
-- Game: addappid(1492640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492641, 1, "ee845e975487b33c375e0e67c21745f918f44eb37462ace1cb8ed43a73864ea7")
