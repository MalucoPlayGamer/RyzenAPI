-- Lua provided by RyzenAPI
-- Game: Hentai Room

-- MAIN APPLICATION
addappid(1800370)
-- Game: addappid(1800370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800372,0,"b4123455861501fc5149c9d073deec7ac8a40dfffc2f76182e2c56daeac4c8b4")
