-- Lua provided by RyzenAPI
-- Game: BITROOM

-- MAIN APPLICATION
addappid(1411660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1411661, 1, "cf7e946385bd561a908f286b2eb7ea6e57bd77af3091d305515cefd36589860b")

