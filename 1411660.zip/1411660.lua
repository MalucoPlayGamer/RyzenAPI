-- Lua provided by RyzenAPI
-- Game: BITROOM

-- MAIN APPLICATION
addappid(1411660)
-- Game: addappid(1411660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411661, 1, "cf7e946385bd561a908f286b2eb7ea6e57bd77af3091d305515cefd36589860b")
