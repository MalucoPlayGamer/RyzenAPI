-- Lua provided by RyzenAPI
-- Game: Game: Burnhouse Lane

-- MAIN APPLICATION
addappid(1846460)
-- Game: addappid(1846460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846461, 1, "3d37dd18520f23789c39d4ea9ce8340823caa69f52480dc8035cb257a15bb317")
addappid(1846463, 1, "6b10c5bec54dfd6b422f4f131425be074f8ccd058251de4ff03eb60b25ab1fbd")
