-- Lua provided by RyzenAPI
-- Game: Story Crafter Demo

-- MAIN APPLICATION
addappid(3202570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202571, 1, "91b664edb2fe36ace7c3faf8a12f013ff1fbd5ca283dab6c205c70a235b91c34")

