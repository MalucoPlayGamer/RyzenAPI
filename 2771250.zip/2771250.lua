-- Lua provided by RyzenAPI
-- Game: AppID 2771250

-- MAIN APPLICATION
addappid(2771250)
-- Game: addappid(2771250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771251, 1, "74bc2d32aa5519ba0d6401b26ea3ec7cbcaa969a8481837d871219635a1949da")
