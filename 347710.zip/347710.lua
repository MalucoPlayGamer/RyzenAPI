-- Lua provided by RyzenAPI
-- Game: Perils of Man

-- MAIN APPLICATION
addappid(347710)

-- MAIN APP DEPOTS / PACKAGES
addappid(347711, 1, "bc4f1f83c3913b4aea730896d8a1deaebf57f263a5b3cf33d068e447e7b2b1b4")
addappid(347712, 1, "a3b953e195d4c5149d9ed51d2dd53152c08bf179ee4150e15cac30947a4f2b53")
addappid(347713, 1, "f6e70c38a82301d50a780492ca223bd33230fb32de044e3f9544213d6da35aa0")
