-- Lua provided by RyzenAPI
-- Game: Robowars

-- MAIN APPLICATION
addappid(285090)

-- MAIN APP DEPOTS / PACKAGES
addappid(285091, 1, "b2f232729170a555208821baab833776c03c8ebf36b07ac0f21dd2a0197c465b")
