-- Lua provided by SkyAPI 
-- Game: Robowars
addappid(285090)
addappid(285091, 1, "b2f232729170a555208821baab833776c03c8ebf36b07ac0f21dd2a0197c465b")
