-- Lua provided by RyzenAPI
-- Game: 1769280

-- MAIN APPLICATION
addappid(1769280)
addappid(1779420)
-- Game: addappid(1769280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769281, 1, "e2b2849dbd67502ba7f8ae33b989684e30634b53ed3c9b79dc00f6cae06385f3")
