-- Lua provided by RyzenAPI 
-- Game: Retromancer
addappid(1007180)
addappid(1007181, 1, "5efdc489755eca85f046beb118e74f898a7d95e0b65a1bbfc21f2d7642e85ddf")
