-- Lua provided by RyzenAPI
-- Game: Retromancer

-- MAIN APPLICATION
addappid(1007180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007181, 1, "5efdc489755eca85f046beb118e74f898a7d95e0b65a1bbfc21f2d7642e85ddf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
