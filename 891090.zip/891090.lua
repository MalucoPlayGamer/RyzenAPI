-- Lua provided by RyzenAPI
-- Game: JUST a Game

-- MAIN APPLICATION
addappid(891090)

-- MAIN APP DEPOTS / PACKAGES
addappid(891091, 1, "03f150d9d6011deb9f55d7a25f8869fa0fc95b7fd53a89d1337b2c54c7591b9f")

