-- Lua provided by RyzenAPI
-- Game: AppID 893050

-- MAIN APPLICATION
addappid(893050)
-- Game: addappid(893050)

-- MAIN APP DEPOTS / PACKAGES
addappid(893051, 1, "10d8a4c3f961f0902884f06a206ef3a23b3e3078f6f8d115b25299fb1dbe6bd5")
