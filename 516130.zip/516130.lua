-- Lua provided by SkyAPI 
-- Game: Runner3
addappid(516130)
addappid(516131, 1, "954da9de1efe6c14d3269271b22934e3204a8fa9981b1cea57b00671d7dae061")
