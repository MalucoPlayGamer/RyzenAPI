-- Lua provided by RyzenAPI 
-- Game: AppID 453990
addappid(453990)
addappid(453991, 1, "a1eb736365421baf5162ffbac36be0c761bc17c5cd0218d9656c0cb908ac817d")
addappid(453992, 1, "21e1480d0ff97e5fb314767e5cb0d61a04f396b1f4170c5b1fd3f4247c22b879")
