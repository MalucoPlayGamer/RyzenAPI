-- Lua provided by RyzenAPI
-- Game: Spellweaver

-- MAIN APPLICATION
addappid(429680)
addappid(464330)
addappid(465230)
addappid(545140)
addappid(615130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(429681, 1, "83261eb0656848c3fa32bf2f9306ef1e66871c8a44381ab9ad6ca2147c4d0010")

