-- Lua provided by RyzenAPI
-- Game: addappid(429680)

-- MAIN APPLICATION
addappid(429680)

-- MAIN APP DEPOTS / PACKAGES
addappid(429681, 1, "83261eb0656848c3fa32bf2f9306ef1e66871c8a44381ab9ad6ca2147c4d0010")
