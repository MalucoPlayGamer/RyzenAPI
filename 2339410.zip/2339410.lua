-- Lua provided by RyzenAPI
-- Game: Game: AppID 2339410

-- MAIN APPLICATION
addappid(2339410)
-- Game: addappid(2339410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339411, 1, "2824942828819f49d401b7801dbfb65cdf8959017e6baa194c6c4506aa98b025")
