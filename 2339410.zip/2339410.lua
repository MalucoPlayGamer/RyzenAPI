-- Lua provided by RyzenAPI 
-- Game: AppID 2339410
addappid(2339410)
addappid(2339411, 1, "2824942828819f49d401b7801dbfb65cdf8959017e6baa194c6c4506aa98b025")
