-- Lua provided by SkyAPI 
-- Game: SWEET FEETS
addappid(2448140)
addappid(2448141, 1, "5f7235a1130032a4620d45a85e1f5d92b6f02bd03a653935900a6b0f9d313f05")
