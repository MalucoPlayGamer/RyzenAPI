-- Lua provided by RyzenAPI
-- Game: Sakura Isekai Adventure 2

-- MAIN APPLICATION
addappid(2832790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832791, 1, "1e65dcc01bbd00a3a99acc2c9521bd1bcd97d12979af1507017fe03348112e04")

