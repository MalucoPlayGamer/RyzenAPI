-- Lua provided by SkyAPI 
-- Game: Sakura Isekai Adventure 2
addappid(2832790)
addappid(2832791, 1, "1e65dcc01bbd00a3a99acc2c9521bd1bcd97d12979af1507017fe03348112e04")
