-- Lua provided by RyzenAPI
-- Game: The Jackbox Megapicker

-- MAIN APPLICATION
addappid(2828500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828503,0,"659f957cbb0b054cc966e81a1da055822db7e4927b08ad2442d454c5cefcb7a5")
addappid(2828504,0,"3a33b1261d2a2bcee158ca6f6281743de5300eb22b96e93a864ba25cc201068b")
addappid(2828507,0,"470e8527802526a4dfc4e4237b3e4da650dcea0e89b8482b62692c25828dbe05")
addappid(2828508,0,"86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
