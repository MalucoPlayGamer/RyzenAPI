-- Lua provided by RyzenAPI
-- Game: Starship: Nova Strike

-- MAIN APPLICATION
addappid(457930)
addappid(492060)

-- MAIN APP DEPOTS / PACKAGES
addappid(457931, 1, "5f2616da2996e20e3451af5f1120cb60211b2099f49a697c3fe3003fbf38b488")

