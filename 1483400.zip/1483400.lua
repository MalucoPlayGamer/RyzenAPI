-- Lua provided by RyzenAPI
-- Game: Heroic Adventures

-- MAIN APPLICATION
addappid(1483400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483401, 1, "064189841fa6e9e5317f5293c67355bf819477b829d0625bf4ca7e320c42cf14")
