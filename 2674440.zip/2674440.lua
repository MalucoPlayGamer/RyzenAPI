-- Lua provided by RyzenAPI
-- Game: 2674440

-- MAIN APPLICATION
addappid(2674440)
-- Game: addappid(2674440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674440,0,"a881e85e4678ccaef0d5ca9695e29dd34cf8660a418ebf92396882daf6679f16")
