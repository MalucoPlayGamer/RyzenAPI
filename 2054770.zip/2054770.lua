-- Lua provided by SkyAPI 
-- Game: Combo Card Clashers
addappid(2054770)
addappid(2054771, 1, "7a541bf28f25e3def1355fd47aa8f0ebd7c0202db77e627f689a999e7a711fa3")
