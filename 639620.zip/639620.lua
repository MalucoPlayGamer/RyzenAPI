-- Lua provided by RyzenAPI
-- Game: 639620

-- MAIN APPLICATION
addappid(639620)
-- Game: addappid(639620)

-- MAIN APP DEPOTS / PACKAGES
addappid(639620,0,"d08c3ba65bfdf90a27faec0b0e763be7d977f2451ec2caecb930b78fbc95d2ec")
