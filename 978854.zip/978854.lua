-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(978854)

-- MAIN APP DEPOTS / PACKAGES
addappid(978854,0,"80d2b72918a28373cda3f794480193981b3b39d7d6cbb2a23e28412522c7f6a8")

