-- Lua provided by RyzenAPI
-- Game: addappid(1547170)

-- MAIN APPLICATION
addappid(1547170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547171, 1, "b4fe4fda2afab1bda59d76d12a0e0fad5840d279c9eb0df04bec32d9b908c4d2")
