-- Lua provided by RyzenAPI
-- Game: 983800

-- MAIN APPLICATION
addappid(983800)
-- Game: addappid(983800)

-- MAIN APP DEPOTS / PACKAGES
addappid(983801, 1, "f7c151ce7827dae5356aa2397f53f074f1b5b55fba9737870313d7b8e872178f")
