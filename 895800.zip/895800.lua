-- Lua provided by RyzenAPI
-- Game: addappid(895800)

-- MAIN APPLICATION
addappid(895800)

-- MAIN APP DEPOTS / PACKAGES
addappid(895801, 1, "a45ef15456a88b88cdaf3aea4fac0d318ef94309aa62c6e6a9b398f325582a17")
