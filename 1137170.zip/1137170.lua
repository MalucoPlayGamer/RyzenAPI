-- Lua provided by RyzenAPI
-- Game: addappid(1137170)

-- MAIN APPLICATION
addappid(1137170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137171, 1, "ce6719ab478eb9e8f1f1af370ef3a10bfcc4ab9fc8c542216e8f6deb92eb9497")
