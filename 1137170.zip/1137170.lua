-- Lua provided by RyzenAPI
-- Game: NEKROTRONIC VR

-- MAIN APPLICATION
addappid(1137170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137171, 1, "ce6719ab478eb9e8f1f1af370ef3a10bfcc4ab9fc8c542216e8f6deb92eb9497")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
