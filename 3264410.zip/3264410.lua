-- Lua provided by RyzenAPI
-- Game: Heroes of Hammerwatch II Demo

-- MAIN APPLICATION
addappid(3264410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264411, 1, "c335aa3b914c512651dce99fa5223923725a303ea913e65a95d6d744f3e5feeb")
addappid(3264412, 1, "a2a740ecd764504065e0547f1e1e57b5fc942525247f1344b0f3917565027bf8")

