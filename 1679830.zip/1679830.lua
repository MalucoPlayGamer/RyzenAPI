-- Lua provided by SkyAPI 
-- Game: Chernobyl inferno
addappid(1679830)
addappid(1679831, 1, "301f6f507d27b10c8e630515143b0f8e9dc6ef34658f0b5cca9a2c84f0682adb")
