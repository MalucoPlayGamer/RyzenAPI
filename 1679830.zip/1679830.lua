-- Lua provided by RyzenAPI
-- Game: Chernobyl inferno

-- MAIN APPLICATION
addappid(1679830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1679831, 1, "301f6f507d27b10c8e630515143b0f8e9dc6ef34658f0b5cca9a2c84f0682adb")

