-- Lua provided by RyzenAPI
-- Game: Animal Gods

-- MAIN APPLICATION
addappid(370220)

-- MAIN APP DEPOTS / PACKAGES
addappid(370226,0,"9068d542c359eb40cbf713a7725317d9ebcae17573b31663c66cd36e58315d5e")
addappid(403540,0,"3aa9775b68e9c817c155f339539a40c07e14c3959ede68f9afa7c77face5cd4d")

