-- Lua provided by RyzenAPI
-- Game: AppID 2959030

-- MAIN APPLICATION
addappid(2959030)
-- Game: addappid(2959030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959031, 1, "b833ebdbcc197fb3e8a3c8e40d95eb6df653b4d9b6a0785960250fa8d46eb1fc")
