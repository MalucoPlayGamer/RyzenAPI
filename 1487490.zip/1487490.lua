-- Lua provided by RyzenAPI
-- Game: Lair Land Story: Deluxe Edition

-- MAIN APPLICATION
addappid(1487490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487491, 1, "1d3c0f90e9898900540dfb02aae6875fb746c7d15ab93296313018047d9c903c")

