-- Lua provided by RyzenAPI
-- Game: addappid(7710)

-- MAIN APPLICATION
addappid(7710)

-- MAIN APP DEPOTS / PACKAGES
addappid(7711, 1, "a9f4a163abd6a80285e66f16b8cea4024d7e3679ccbc23f71fa490593898d6c5")
