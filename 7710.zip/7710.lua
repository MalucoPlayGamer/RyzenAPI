-- Lua provided by SkyAPI 
-- Game: BioShock Demo
addappid(7710)
addappid(7711, 1, "a9f4a163abd6a80285e66f16b8cea4024d7e3679ccbc23f71fa490593898d6c5")
