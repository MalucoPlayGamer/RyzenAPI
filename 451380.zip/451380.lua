-- Lua provided by RyzenAPI
-- Game: The Darkside Detective Demo

-- MAIN APPLICATION
addappid(451380)
-- Game: addappid(451380)

-- MAIN APP DEPOTS / PACKAGES
addappid(451381, 1, "de469a2bea1ed636868903b2a3cf46f6d2f04d7e84232daa18f1624d2b41bd5d")
