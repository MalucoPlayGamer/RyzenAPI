-- Lua provided by RyzenAPI
-- Game: Game: Mey Rescuer

-- MAIN APPLICATION
addappid(1495510)
-- Game: addappid(1495510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495511, 1, "6a4b86fffa2b9bbdf1137a2cecf3876ada8805b6db39f075ddc29d669ff00bc0")
