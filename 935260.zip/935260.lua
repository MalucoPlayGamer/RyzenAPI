-- Lua provided by RyzenAPI
-- Game: 绯色幻想(Scarlet Fantasy)

-- MAIN APPLICATION
addappid(935260)

-- MAIN APP DEPOTS / PACKAGES
addappid(935261, 1, "5a9804e42950c8c0b40ae6a7b9feca59e7354f93ee9246676ca24a3164c2cf44")
