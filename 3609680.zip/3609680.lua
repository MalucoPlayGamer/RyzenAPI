-- Lua provided by RyzenAPI
-- Game: 3609680

-- MAIN APPLICATION
addappid(3609680)
-- Game: addappid(3609680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609682,0,"8abd1828a75a8dd6f9b5968d9119f0bba0cc6cb13c86132406b34a5bc93c1540")
