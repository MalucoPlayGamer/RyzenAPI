-- Lua provided by RyzenAPI
-- Game: TT Isle Of Man: Ride on the Edge 3

-- MAIN APPLICATION
addappid(1924170)
-- Game: addappid(1924170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924171, 1, "dc2a2fa0a93a7767111124bf716ca6299a76f547234b46a62f20b4cf411ed62e")
