-- Lua provided by RyzenAPI 
-- Game: FemDomination 2
addappid(1875750)
addappid(1875751, 1, "a6fd885471c4bb8c4461076ccdb3fa56965dac3c6e31d35c8bbb0d6ab518c793")
