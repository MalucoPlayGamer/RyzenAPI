-- Lua provided by RyzenAPI
-- Game: Not Without My Poop

-- MAIN APPLICATION
addappid(789730)

-- MAIN APP DEPOTS / PACKAGES
addappid(789731, 1, "3e4609f9dc66c5d50f7ceaed29171fedeaad8d4ab9b79ae55d9dc7f066f762e2")
