-- Lua provided by RyzenAPI
-- Game: WolfFang SkullFang Saturn Tribute Boosted

-- MAIN APPLICATION
addappid(2987170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987171, 1, "b5ab2bf632336e459931fdc32e1ee2cb56cfb66b40d65c954ad881eb5cb582b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
