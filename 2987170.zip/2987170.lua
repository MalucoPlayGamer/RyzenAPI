-- Lua provided by RyzenAPI
-- Game: addappid(2987170)

-- MAIN APPLICATION
addappid(2987170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987171, 1, "b5ab2bf632336e459931fdc32e1ee2cb56cfb66b40d65c954ad881eb5cb582b9")
