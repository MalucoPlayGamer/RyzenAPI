-- Lua provided by RyzenAPI 
-- Game: 神州豪侠
addappid(2549350)
addappid(2549351, 1, "9f0348f9098031c40532498f95b8deba0690299429257d85d80567cddb7eef30")
