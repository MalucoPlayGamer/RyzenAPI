-- Lua provided by RyzenAPI
-- Game: Game: 神州豪侠

-- MAIN APPLICATION
addappid(2549350)
-- Game: addappid(2549350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549351, 1, "9f0348f9098031c40532498f95b8deba0690299429257d85d80567cddb7eef30")
