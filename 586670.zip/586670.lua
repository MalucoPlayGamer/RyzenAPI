-- Lua provided by RyzenAPI
-- Game: Game: A Foretold Affair

-- MAIN APPLICATION
addappid(586670)
addappid(594420)
-- Game: addappid(586670)

-- MAIN APP DEPOTS / PACKAGES
addappid(586671, 1, "feed74a181a570c375244b41621c1ffc884beeb6d9949a708ccb3b993617cb78")
