-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956894)

-- MAIN APP DEPOTS / PACKAGES
addappid(956894,0,"56132c9ae9d2210391e6149ed5ebf787d7215d62d4b514476303c87b753a0e05")
