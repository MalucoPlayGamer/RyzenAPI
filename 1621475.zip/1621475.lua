-- Lua provided by RyzenAPI
-- Game: Los Sims™ 4 Colores de Carnaval - Kit

-- MAIN APPLICATION
addappid(1621475)
-- Game: addappid(1621475)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621475,0,"2ba7531f226f4a14d9c5da08e39e4b403aa8f37cd3b7de54b73a638a9d501e2d")
addappid(1849980,0,"8538bdf3b8d85de35fe32b4141bf864e4449be134d3ddeb70f9e9c7b48a549e8")
addappid(1849982,0,"09ec731f11fc43b03a467e0306ab754430bc10a155db3559344c2499b370d5a5")
addappid(1849985,0,"3deeddc1d83b0b8a0dbbe5a86b5d8d01c82d52804def085c188edaabe817940f")
addappid(1849986,0,"766e15c51f0ad6a8a7834c0ebee0d4a0ced729ed11885ee26633e29712da696c")
addappid(1849987,0,"da57d7b47883990e4e80a40c73c8d8fd5dbf45d240d28aab3ae76eee68788bbe")
addappid(1849990,0,"68ca81c5d159e7e119f72cd765be3794eb9489a29521c9ca257d6d76b326d344")
addappid(1849997,0,"ae8e3017dfb85947d659356ad9b0e026a5d31acf0a59cd96aade6ded8a876cf9")
