-- Lua provided by RyzenAPI
-- Game: AppID 456180

-- MAIN APPLICATION
addappid(456180)

-- MAIN APP DEPOTS / PACKAGES
addappid(456181, 1, "caa362291001ccb27bbea309faba08bcc9e0c84ed09b41b2c3d1f96cced4cabd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(822300)
