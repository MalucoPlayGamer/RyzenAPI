-- Lua provided by RyzenAPI
-- Game: The American Dream

-- MAIN APPLICATION
addappid(456180)
addappid(822300)

-- MAIN APP DEPOTS / PACKAGES
addappid(456181, 1, "caa362291001ccb27bbea309faba08bcc9e0c84ed09b41b2c3d1f96cced4cabd")
