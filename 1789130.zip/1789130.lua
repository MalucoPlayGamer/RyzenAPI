-- Lua provided by RyzenAPI
-- Game: The Monster PIMP

-- MAIN APPLICATION
addappid(1789130)
addappid(2447210)
-- Game: addappid(1789130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789131, 1, "7890bc1daa243726e403b9d82b022c49dd7c7b97f7e1b0732501860a1c9e6e10")
