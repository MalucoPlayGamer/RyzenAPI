-- Lua provided by RyzenAPI
-- Game: Game: AppID 1403280

-- MAIN APPLICATION
addappid(1403280)
-- Game: addappid(1403280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403281, 1, "b1392497cf7a3ea9c3c791bd7a25076535b1a8505176632cdf543d76f8054e5a")
