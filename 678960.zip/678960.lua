-- Lua provided by RyzenAPI
-- Game: CODE VEIN

-- MAIN APPLICATION
addappid(678960)
addappid(773991)
addappid(774011)
addappid(875950)
addappid(875960)
addappid(875980)
addappid(875990)
addappid(876000)
addappid(879380)
addappid(1196141)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(678961, 1, "155690b8769a0c5f9c3d2d80a310bb358ba0351763c737dc9fa20e18beca0c71")
addappid(678962, 1, "b8f72b3b8f5a5447d9c4a650bd72e8586c588e4a630de3275693245dd5f7fb58")
addappid(678963, 1, "966a81a4382a2605455cfe05fa758289608791fd9ac5b14c96e8ce4ac58a212f")
addappid(678964, 1, "dc860a20f5a42bffda51d66283422eaffb4b39fad8d8fd8ed26cda7790a3fb16")

