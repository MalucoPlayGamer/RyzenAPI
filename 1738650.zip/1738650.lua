-- Lua provided by RyzenAPI
-- Game: Game: AppID 1738650

-- MAIN APPLICATION
addappid(1738650)
-- Game: addappid(1738650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738651, 1, "f522724096933c07bae370a30a9bb4588cf14afdd69468ab35461d50333d2956")
