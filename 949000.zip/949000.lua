-- Lua provided by RyzenAPI
-- Game: Game: Marble Combat

-- MAIN APPLICATION
addappid(949000)
-- Game: addappid(949000)

-- MAIN APP DEPOTS / PACKAGES
addappid(949001, 1, "bac43ec64122998c9d8ed2b6026d9723b0b7f6bd5d9ed906c1771ebf80984781")
