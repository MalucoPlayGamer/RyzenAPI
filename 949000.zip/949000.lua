-- Lua provided by RyzenAPI
-- Game: Marble Combat

-- MAIN APPLICATION
addappid(949000)

-- MAIN APP DEPOTS / PACKAGES
addappid(949001, 1, "bac43ec64122998c9d8ed2b6026d9723b0b7f6bd5d9ed906c1771ebf80984781")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
