-- Lua provided by RyzenAPI
-- Game: Serve Or Die

-- MAIN APPLICATION
addappid(4643930) -- Serve Or Die

-- MAIN APP DEPOTS / PACKAGES
addappid(4643931, 1, "444d9c5cfc85026c12afc3a7750d79232c109e094af355ff8cc0274737c89361") -- Depot 4643931
