-- Lua provided by RyzenAPI
-- Game: AppID 1170940

-- MAIN APPLICATION
addappid(1170940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170941, 1, "62440cb9c7e3e97a3e1e5fb018175b4b8f4e88c21ea5ec37e42f27f7a97ffcd5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
