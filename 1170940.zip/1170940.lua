-- Lua provided by RyzenAPI
-- Game: AppID 1170940

-- MAIN APPLICATION
addappid(1170940)
-- Game: addappid(1170940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170941, 1, "62440cb9c7e3e97a3e1e5fb018175b4b8f4e88c21ea5ec37e42f27f7a97ffcd5")
