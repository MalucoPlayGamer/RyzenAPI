-- Lua provided by RyzenAPI
-- Game: addappid(1237890)

-- MAIN APPLICATION
addappid(1237890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237891, 1, "f776f763633b69869dbcb7aa1e9497fc2ee302db29f735d5da35f1be2256157a")
