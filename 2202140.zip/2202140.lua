-- Lua provided by RyzenAPI
-- Game: Waifu Fighter - Digital Artbook

-- MAIN APPLICATION
addappid(2202140)
-- Game: addappid(2202140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202141, 1, "1251e6d34914c7e7a106445f2b397ee32b418e4cc3e098cc5b60e9ba756360b6")
addappid(2202142, 1, "9835f51057a2dee7f67395198851cca45cf8271223cdd1ee6bf4ef5b2be7b122")
