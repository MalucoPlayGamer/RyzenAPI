-- Lua provided by RyzenAPI
-- Game: 2102530

-- MAIN APPLICATION
addappid(2102530)
-- Game: addappid(2102530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102531, 1, "955bd475e0bd4906fcb513fe5f0da273bd460faba0edf7bd66e317fe25cbb65d")
