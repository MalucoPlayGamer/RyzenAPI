-- Lua provided by SkyAPI 
-- Game: Blood Rush Demo
addappid(2828980)
addappid(2828981, 1, "4f53f59fc252d1135f8b25ca969fb803f7b06b6317b4d72192c5ca579ff021ea")
