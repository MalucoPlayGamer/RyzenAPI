-- Lua provided by RyzenAPI
-- Game: 2828980

-- MAIN APPLICATION
addappid(2828980)
-- Game: addappid(2828980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828981, 1, "4f53f59fc252d1135f8b25ca969fb803f7b06b6317b4d72192c5ca579ff021ea")
