-- Lua provided by RyzenAPI
-- Game: Airship Dragoon

-- MAIN APPLICATION
addappid(308380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(308381, 1, "a6e0c056230f022538572167c029fa88227be68f4df74c8e003127c78a36d1c8")
