-- Lua provided by RyzenAPI
-- Game: Game: AppID 308380

-- MAIN APPLICATION
addappid(308380)
-- Game: addappid(308380)

-- MAIN APP DEPOTS / PACKAGES
addappid(308381, 1, "a6e0c056230f022538572167c029fa88227be68f4df74c8e003127c78a36d1c8")
