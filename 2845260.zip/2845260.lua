-- Lua provided by RyzenAPI
-- Game: Game: 100 March Cats

-- MAIN APPLICATION
addappid(2845260)
-- Game: addappid(2845260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845261, 1, "039ef2c2b585e361aac0bcc3d7d81c15a1d9f8e7be02d47945a6905c98248af4")
