-- Lua provided by RyzenAPI
-- Game: addappid(1328410)

-- MAIN APPLICATION
addappid(1328410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328412,0,"82af4a6cac4703db2782325e611bc0c5fa491a5a3450de7a3edf5d6f5f90ae94")
addappid(1328413,0,"ed623427a9dc57d37690bb5fecc5c85fa143ec71e10e39d4b4f033f32ff7c874")
addappid(1328414,0,"ce18cb59e46417bc1b1e9648e0d0a15ae47c8be400559d1ebc99d3095a9a4f3b")
