-- Lua provided by RyzenAPI
-- Game: Lugh World

-- MAIN APPLICATION
addappid(3234720)
addappid(4519860)
addappid(4978850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3234721,0,"d6d64a4d94c4e43843b4fdb58c79b0985adf2bdc0460ef18084c1de4cef4834c")

