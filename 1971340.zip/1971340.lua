-- Lua provided by RyzenAPI
-- Game: Gothic wa Mahou Otome "Deathsmiles" Respect Arrange Soundtrack

-- MAIN APPLICATION
addappid(1971340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971341, 1, "19b279b27a4ad471bda8e34dcab0c3a14a7501a103be80eb6e1f2aa40d189b41")
addappid(1971342, 1, "1458a72af0fe1f5e6b14e3c8deb89a0c2a441a08d733e6cc88b115fd68e80fd0")
addappid(1971343, 1, "412c2443a45fb0a434d0cf8cb37a0b09b387c24daa29ba32287c50dfd05af8fb")
addappid(1971344, 1, "ae419712aff9e0da3673b9d7fa6c2824ce1ae091d5fad2911aa55f607fb3d74a")
