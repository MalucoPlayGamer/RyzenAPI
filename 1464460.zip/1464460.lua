-- Lua provided by RyzenAPI
-- Game: Qip

-- MAIN APPLICATION
addappid(1464460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464461, 1, "9d6c22ea76a0800ca27d6ee94152a8977091b28b2c79c2b38b4dcdca422e6933")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
