-- Lua provided by RyzenAPI
-- Game: addappid(1464460)

-- MAIN APPLICATION
addappid(1464460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464461, 1, "9d6c22ea76a0800ca27d6ee94152a8977091b28b2c79c2b38b4dcdca422e6933")
