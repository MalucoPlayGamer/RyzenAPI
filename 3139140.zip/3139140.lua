-- Lua provided by RyzenAPI
-- Game: This Is Not Your House

-- MAIN APPLICATION
addappid(3139140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3139141, 1, "4155d65cd2c0cc7e8d1e52704f652a030af5f3067a25c55bb0971d79bd194206")

