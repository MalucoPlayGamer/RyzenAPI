-- Lua provided by RyzenAPI
-- Game: addappid(1677020)

-- MAIN APPLICATION
addappid(1677020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677021, 1, "badea80094b0fd1120102f84e19c97f5542a935ff3d7bd757135243f7d2dbf2d")
