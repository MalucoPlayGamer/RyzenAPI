-- Lua provided by RyzenAPI
-- Game: The Devil's Womb

-- MAIN APPLICATION
addappid(913320)

-- MAIN APP DEPOTS / PACKAGES
addappid(913321, 1, "4d171f01f01853555646838b92b859f693dcde0daa33093b9c658a0930c3793e")

