-- Lua provided by RyzenAPI
-- Game: Commander Quest

-- MAIN APPLICATION
addappid(2697930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697931, 1, "688a415a05ac047923a7e910d555ae93abb5859ed06d74373fbf7925930da9d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
