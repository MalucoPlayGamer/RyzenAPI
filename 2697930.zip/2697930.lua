-- Lua provided by RyzenAPI
-- Game: Commander Quest

-- MAIN APPLICATION
addappid(2697930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697931, 1, "688a415a05ac047923a7e910d555ae93abb5859ed06d74373fbf7925930da9d6")

