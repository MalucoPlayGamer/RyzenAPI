-- Lua provided by RyzenAPI
-- Game: addappid(2857930)

-- MAIN APPLICATION
addappid(2857930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2857931, 1, "f0ea88bdb2f7ff3d962552cc0c15c29bd8b7c4cfb6cb8159698b4523d69a6543")
