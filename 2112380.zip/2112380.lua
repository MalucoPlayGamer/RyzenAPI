-- Lua provided by RyzenAPI
-- Game: Game: Negative Atmosphere: Emergency Room Prototype

-- MAIN APPLICATION
addappid(2112380)
-- Game: addappid(2112380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112381, 1, "7a9227ddbcecd4c78dcd1cbd0df8b71a4b83b8329ffd9e60a391790f7b5929fb")
