-- Lua provided by RyzenAPI
-- Game: Negative Atmosphere: Emergency Room Prototype

-- MAIN APPLICATION
addappid(2112380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112381, 1, "7a9227ddbcecd4c78dcd1cbd0df8b71a4b83b8329ffd9e60a391790f7b5929fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
