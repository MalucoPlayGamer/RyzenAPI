-- Lua provided by RyzenAPI
-- Game: 3217960

-- MAIN APPLICATION
addappid(3217960)
-- Game: addappid(3217960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3217961, 1, "960acdff71d21d58b22d812c8dfcad844061d4af86d990378c9393c9938d375f")
