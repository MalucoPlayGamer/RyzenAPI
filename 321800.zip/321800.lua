-- Lua provided by RyzenAPI
-- Game: 321800

-- MAIN APPLICATION
addappid(321800)
-- Game: addappid(321800)

-- MAIN APP DEPOTS / PACKAGES
addappid(321801, 1, "aa12c4f8ab98cd0f230f4375b31411021824636e988f778bf14d3dc9bc25904c")
addappid(321802, 1, "0a78898beac6eca60fbf49396d38c0ff69206fa7dcd45d0880090d45c1fd70d9")
addappid(321803, 1, "a1242b10ef45d7a28d786eaccc93d5952a51ee1a651cdb451536ba9e6d223494")
addappid(321804, 1, "3d7d1faef16bced2e60febeb7a6364549ff8383cef13f8dc82e78a00c97e9830")
