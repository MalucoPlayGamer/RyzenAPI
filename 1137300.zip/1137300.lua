-- Lua provided by RyzenAPI
-- Game: addappid(1137300)

-- MAIN APPLICATION
addappid(1137300)
addappid(1581901)
addappid(1581932)
addappid(1581933)
addappid(1581934)
addappid(1581935)
addappid(1581936)
addappid(1581937)
addappid(1581938)
addappid(1581939)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137301, 1, "24ca096079bebd50677ab228e60f5773d36d1f51b7785d03fb1df59262c9388b")
addappid(1137302, 1, "e821dbc8dc967006511960418bfaf7398358478114d21612000b8ac396dbeb1b")
addappid(1581930, 0, "21b2c3bb882203d1ccbe91878195906b97cd73888f11cef06a7cfb113d5de579")
