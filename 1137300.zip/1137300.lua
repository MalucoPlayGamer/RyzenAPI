-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes Chapter One

-- MAIN APPLICATION
addappid(1137300)
addappid(1581901)
addappid(1581932)
addappid(1581933)
addappid(1581934)
addappid(1581935)
addappid(1581936)
addappid(1581937)
addappid(1581938)
addappid(1581939)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137301, 1, "24ca096079bebd50677ab228e60f5773d36d1f51b7785d03fb1df59262c9388b")
addappid(1137302, 1, "e821dbc8dc967006511960418bfaf7398358478114d21612000b8ac396dbeb1b")
addappid(1581930, 0, "21b2c3bb882203d1ccbe91878195906b97cd73888f11cef06a7cfb113d5de579")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
