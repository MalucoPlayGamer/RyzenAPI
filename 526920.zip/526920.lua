-- Lua provided by RyzenAPI
-- Game: SQUAKE

-- MAIN APPLICATION
addappid(526920)

-- MAIN APP DEPOTS / PACKAGES
addappid(526921, 1, "8d71b08db0ffbd06183ed450c44b38c7ec1ea5f400b2f8a8b938e3e9cb290474")
addappid(526922, 1, "c7ceefb337f5acf7d801fce23bc40e8d79c394e52eed98780b19b78f3a2cf07d")
