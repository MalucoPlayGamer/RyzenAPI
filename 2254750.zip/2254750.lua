-- Lua provided by RyzenAPI
-- Game: 2254750

-- MAIN APPLICATION
addappid(2254750)
-- Game: addappid(2254750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254751, 1, "9e8faaf5a33720ee613a63662447f669ec90a1afc48af14bd71af09f2c203465")
