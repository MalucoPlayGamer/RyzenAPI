-- Lua provided by RyzenAPI
-- Game: Welcome Demon

-- MAIN APPLICATION
addappid(4266020) -- Welcome Demon

-- MAIN APP DEPOTS / PACKAGES
addappid(4266021, 1, "49a92b7ff4b77a6efc120e144c8ba738bfb196f710407a3ddea00f21f724cf3b") -- Depot 4266021

