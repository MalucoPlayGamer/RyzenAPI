-- Lua provided by SkyAPI 
-- Game: AppID 654490
addappid(654490)
addappid(654491, 1, "d321ab6ea01660121a43248c8ed0e3b047a9eb0d9f8765835cf86c692919571c")
addappid(686210, 0, "d2ef5ca9d521c3c9667f4c264911049ce1d850649b645cbabf1097796ead971c")
