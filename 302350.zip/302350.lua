-- Lua provided by RyzenAPI
-- Game: Tex Murphy: Under a Killing Moon

-- MAIN APPLICATION
addappid(302350)

-- MAIN APP DEPOTS / PACKAGES
addappid(302351, 1, "5e49562d6fbb75bef75a65726b78ff30c6b533ff66079eaa8056c2806416e87f")
addappid(302352, 1, "adf85dbfc1e14fc073ceea78e3d54c8fb92fab5108ffacbdfc7bcefd8a065a94")
addappid(302353, 1, "0a10464e1823bd878cd3a854e39edae27fbc54751fdd0a21315c82c4b9f52538")
addappid(302354, 1, "3bf8c91ba66d396271654bffb657ec76a41b9351b6f060ec05aac334c83478b7")

