-- Lua provided by SkyAPI 
-- Game: AppID 277390
addappid(277390)
addappid(277391, 1, "fd9e3798f5681427e4c145fa75d7f49991e6fe0cd31160511c8f4c42bca3502c")
addappid(277394, 1, "72b34538a220861e98ea9761dcda1fa4a4a40714b5f52ebe5a5174310ae01e71")
