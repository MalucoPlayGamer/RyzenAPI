-- Lua provided by RyzenAPI
-- Game: The Last 47 Hours Music Collection

-- MAIN APPLICATION
addappid(1031520)
-- Game: addappid(1031520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031520,0,"416f8ffc351521e160ab100be2df807e3cdee69ce2fadd3b2028520c22851298")
