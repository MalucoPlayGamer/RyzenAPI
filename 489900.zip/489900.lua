-- Lua provided by RyzenAPI
-- Game: Bayla Bunny

-- MAIN APPLICATION
addappid(489900)

-- MAIN APP DEPOTS / PACKAGES
addappid(489901, 1, "5434ad729016eab53ee38b52d84db4d760bd456df47e6c681a105c531a989d15")

