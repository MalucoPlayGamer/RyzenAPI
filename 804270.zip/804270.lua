-- Lua provided by RyzenAPI
-- Game: Chex Quest HD

-- MAIN APPLICATION
addappid(804270)

-- MAIN APP DEPOTS / PACKAGES
addappid(804271, 1, "795bc4057e2a1c0fa3346612d0a818d1a12855f7a5b95e46427b3d48f28650a2")
addappid(804272, 1, "ea378b0da9a3f178d6ea58dfd4045193838cc7fde969378008a4b4596044e7cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
