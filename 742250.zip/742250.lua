-- Lua provided by RyzenAPI
-- Game: AppID 742250

-- MAIN APPLICATION
addappid(742250)

-- MAIN APP DEPOTS / PACKAGES
addappid(742251, 1, "e161fef1c6443b133b257b8f7e49ab612e3d5402c747e8a743984a34565e25d3")
addappid(742252, 1, "61dc2e52de971d363f30e27cfd0effcd225ba782ffa44961b05f51cc605e3c45")
addappid(742253, 1, "b7982baf380c306cf589f35a7effa9e49c1b9eacde3e68310d776d089c582d2c")
addappid(743880, 0, "87144b9498804b3ea48dc1884b0f7ee07d21b69d889577082908abfa884e8b30")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1792990)
addappid(1804250)
