-- Lua provided by SkyAPI 
-- Game: Cult of the Lamb Soundtrack
addappid(2015890)
addappid(2015891, 1, "d6f6c983191a2f11a58a33670799f2bf707666d834710af4018a2bc57c24d13f")
addappid(2015892, 1, "ad979829eb577feabacff9f56f449de355bc43cdc60d88e3319e48fc234bade9")
