-- Lua provided by RyzenAPI
-- Game: Netoo

-- MAIN APPLICATION
addappid(4017520)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4248350)
