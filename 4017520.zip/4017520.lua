-- Lua provided by RyzenAPI
-- Game: Netoo

-- MAIN APPLICATION
addappid(4017520)
