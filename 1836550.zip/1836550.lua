-- Lua provided by RyzenAPI
-- Game: Tap Wizard 2

-- MAIN APPLICATION
addappid(1836550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836551, 1, "67bf380ac747703e763fd2fd2c3e7d158c53418b1b8fce0a481b81460e7948a4")
addappid(1836552, 1, "1e99a505e163056b8b4dacda2d96420e2ace09a668225548cfe2c90f1edfc557")
addappid(1836553, 1, "1d5cb6ebfe858d8bc74b28b4ab57bc35337ad4770e61db6cc2be1d9b6330af15")

