-- Lua provided by RyzenAPI
-- Game: addappid(3868930)

-- MAIN APPLICATION
addappid(3868930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3868930,0,"d16793170a6ce1f37dcc016fb1d3f65f49d432dede620e2cd014a85ced73535c")
