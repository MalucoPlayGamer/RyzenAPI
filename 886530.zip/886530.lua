-- Lua provided by RyzenAPI
-- Game: GolemRush

-- MAIN APPLICATION
addappid(886530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(886531, 1, "10069946797617049d6f487601a5c1a0db9908175c5f4ed4d05863c5c29fa57f")

