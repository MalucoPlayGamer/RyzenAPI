-- Lua provided by RyzenAPI
-- Game: Game: AppID 886530

-- MAIN APPLICATION
addappid(886530)
-- Game: addappid(886530)

-- MAIN APP DEPOTS / PACKAGES
addappid(886531, 1, "10069946797617049d6f487601a5c1a0db9908175c5f4ed4d05863c5c29fa57f")
