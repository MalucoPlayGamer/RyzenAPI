-- Lua provided by RyzenAPI
-- Game: Game: F-19 Stealth Fighter

-- MAIN APPLICATION
addappid(347250)
-- Game: addappid(347250)

-- MAIN APP DEPOTS / PACKAGES
addappid(347251, 1, "a770c96876108391bc1e98b5f87b578bb37f6db813a97113eb5b665499baceed")
addappid(347252, 1, "278b9441352bbf9ed11a235a9f38bd7fd7b0cdc29fd5ba4c62f1feafa8ec1c9a")
addappid(347253, 1, "5b04e3e356ac6c7830796b4be3a04bd694c393dd2391ae9978a866655f25dcc3")
addappid(347254, 1, "1ae1b2e2467a97c7133bb64249141616fa4300223e0ad9fb06af403dc872d1f2")
addappid(347255, 1, "b2954267ba82ed811c90340c15ffbc1d80a7c1dcc1cda171a46a0b9265e058e2")
