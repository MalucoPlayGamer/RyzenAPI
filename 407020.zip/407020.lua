-- Lua provided by RyzenAPI
-- Game: Star Sky

-- MAIN APPLICATION
addappid(407020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(407021, 1, "cd5ac38c122a035103ca74ca21f75b352d8909a85c0b522714e14c07895e5408")
addappid(407023, 1, "77fd2711ef62407a6e4d6594c3c63bf8e41d1c10c464b9b660d54063bf8bed9d")

