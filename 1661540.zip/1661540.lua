-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy: Japan

-- MAIN APPLICATION
addappid(1661540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661540,0,"efac0c9447efa282482404aee37e3756d0e65a34ccfa3e48e308b74922c0c0ec")

