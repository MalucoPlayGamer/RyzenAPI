-- Lua provided by RyzenAPI
-- Game: 2833810

-- MAIN APPLICATION
addappid(2833810)
-- Game: addappid(2833810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833811, 1, "af92047e19f01f59be907395bd1543cab4b9cdcf059f9c3bb8e75614ac182d83")
