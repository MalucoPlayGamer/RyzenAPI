-- Lua provided by SkyAPI 
-- Game: Life of Delta
addappid(1376760)
addappid(1376761, 1, "8a610ae827d27555dad5dc5f6933b60c6c776864411b1dbb7b09c5b13bbf8bd8")
addappid(2176630, 0, "9ee50cd654a68bfa53e1e67a56b55adb2eb78421badfefe5065ad18070f22630")
