-- Lua provided by RyzenAPI
-- Game: Kirakira stars idol project Reika

-- MAIN APPLICATION
addappid(1396050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396051, 1, "bb86b33e6b94bb1164a144487d618f3d9c95623d57e7da2b647ec6b223ec61b4")

