-- Lua provided by RyzenAPI
-- Game: addappid(528090)

-- MAIN APPLICATION
addappid(528090)

-- MAIN APP DEPOTS / PACKAGES
addappid(528091, 1, "d87fff2acfab414aff404d0656340f6bd45ce41efa33c69e1b96cf43494b749a")
