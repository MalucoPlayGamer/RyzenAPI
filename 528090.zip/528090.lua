-- Lua provided by SkyAPI 
-- Game: AppID 528090
addappid(528090)
addappid(528091, 1, "d87fff2acfab414aff404d0656340f6bd45ce41efa33c69e1b96cf43494b749a")
