-- Lua provided by RyzenAPI
-- Game: The Curse of Kubel

-- MAIN APPLICATION
addappid(1269810)
addappid(2215640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269811, 1, "7c2622c6ba1bb396e5c08f61f6b85561c0f519e9022b6be3d3070867a2c86f66")
addappid(1269812, 1, "0523f77df65a0f98478276b3d7afd608f34a13c2cd6ba11f8d20809bab822874")
addappid(1269813, 1, "8dfa852a4600bd96202ee76c93ea7acc85020a53c0560ed0e4dc0e7b3fea3e33")

