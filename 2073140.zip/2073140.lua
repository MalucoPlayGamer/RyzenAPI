-- Lua provided by SkyAPI 
-- Game: Another World - Thought Taboo
addappid(2073140)
addappid(2073141, 1, "b17855661520b9e5f8e7f17603f287c621ea1a5d9f2b771a8e1fb4134a07162a")
