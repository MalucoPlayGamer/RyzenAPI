-- Lua provided by RyzenAPI
-- Game: Another World - Thought Taboo

-- MAIN APPLICATION
addappid(2073140)
-- Game: addappid(2073140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073141, 1, "b17855661520b9e5f8e7f17603f287c621ea1a5d9f2b771a8e1fb4134a07162a")
