-- Lua provided by RyzenAPI
-- Game: The House of Da Vinci 2

-- MAIN APPLICATION
addappid(1259840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259841, 1, "d861f228c28813fb0f5540e64bee4620ce146056d81198900c06881d6e784eda")
addappid(1259842, 1, "f8324c2e3146d7c2652f73da840718aa33eb82d8306c7b0e38b674ead91dfe9f")

