-- Lua provided by RyzenAPI
-- Game: 512020

-- MAIN APPLICATION
addappid(512020)
addappid(532050)
-- Game: addappid(512020)

-- MAIN APP DEPOTS / PACKAGES
addappid(512021, 1, "8de278e8e9ba3e8964175e300561e9f83b42a997e6baebe1fbfbcdfe56472b75")
