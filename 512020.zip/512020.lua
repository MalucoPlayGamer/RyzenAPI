-- Lua provided by SkyAPI 
-- Game: AppID 512020
addappid(512020)
addappid(512021, 1, "8de278e8e9ba3e8964175e300561e9f83b42a997e6baebe1fbfbcdfe56472b75")
addappid(532050)
