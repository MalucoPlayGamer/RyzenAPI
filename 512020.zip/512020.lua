-- Lua provided by RyzenAPI
-- Game: AppID 512020

-- MAIN APPLICATION
addappid(512020)
addappid(532050)

-- MAIN APP DEPOTS / PACKAGES
addappid(512021, 1, "8de278e8e9ba3e8964175e300561e9f83b42a997e6baebe1fbfbcdfe56472b75")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(543310)
addappid(562790)
addappid(569740)
addappid(591730)
addappid(592790)
