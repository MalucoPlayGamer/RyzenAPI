-- Lua provided by RyzenAPI
-- Game: AppID 3107770

-- MAIN APPLICATION
addappid(3107770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107771, 1, "a9c6a704720ae607eff2c46f7a6e568b65b9a51151966cc1351743ae3c9e61e7")
addappid(3107772, 1, "d38198946309b146ab17ceb2264df9699df1b9bf0990ca656187445257dba5c7")
addappid(3107773, 1, "a57f8f3939d20663af6c87bd50c547e03fba0b0d4d1a4895f53ad75b3305a8bd")
addappid(3107774, 1, "3fa0dcd4e8f1ea9349e4c695a828a0d304059df158d34674a9c6ddb495ce2451")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3341470)
addappid(3341480)
