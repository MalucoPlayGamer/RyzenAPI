-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Sophie's Swimsuit "White Canvas"

-- MAIN APPLICATION
addappid(1754697)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754697,0,"9bd5f83ecc0f987dbc59790df0e37fb82c110f683e53dcc58806ee08e43c4dde")

