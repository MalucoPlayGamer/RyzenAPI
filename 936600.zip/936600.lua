-- Lua provided by RyzenAPI
-- Game: 936600

-- MAIN APPLICATION
addappid(936600)
-- Game: addappid(936600)

-- MAIN APP DEPOTS / PACKAGES
addappid(936601, 1, "a8029a0cc968f5380d432359767ddbca4299db234f8da3473d2dc6fe17034dfb")
