-- Lua provided by RyzenAPI
-- Game: Power & Revolution 2019 Edition

-- MAIN APPLICATION
addappid(1050040) -- Godn Spy Add-on -  Power  Revolution 2019 Edition
addappid(1050050) -- Modding Tool Add-on - Power  Revolution 2019 Edition DLC
addappid(1050060) -- 2017 Scenarios - Power  Revolution 2019 Edition
addappid(1050070) -- 2018 Scenarios - Power  Revolution 2019 Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(1029630, 1, "e39c84f73c826949f45419c5b5cebcbe2f96d25366277961e1c9f42b435ccadc") -- Power & Revolution 2019 Edition
addappid(1029631, 1, "7658f26810ba87b7702374ae870feff225701f68f0faac528abee92c92d6e542") -- Power & Revolution 2019 Edition Content
addappid(1029632, 1, "65293f259b1c1b3e1acfd8f2730fbd156fe49048a796b6118c51c479e77f6f35") -- P19_FR
addappid(1029633, 1, "3c8d735a2842e673ff0b7ff0f21b7ca7d5c91b7dc88940ba7fe42bcb335a7a00") -- P19_DE
addappid(1029634, 1, "089cae068f067a00efbdaa7de89d8710109d76a9af1945fc38d05692b19931ad") -- P19_ES
addappid(1029635, 1, "119a79e8d11022f276b810d927f3b2e47dbacb0d71603a1ec1901d9776b9f9d6") -- P19_IT
addappid(1029636, 1, "b987480a5aee7ff0122ba535cf231628db663dbde499c3c381c590f154e14923") -- P19_RU
addappid(1029637, 1, "ed82a37229d484b9e6939bafc72462d48532215b9461c54216e3e06be49d030b") -- P19_JP
addappid(1029638, 1, "6246f872d38ec6cd91dd1c4b0ffd301c5883a3577044449e55d383cfaf650f02") -- P19_PT
addappid(1029639, 1, "053ce4bb60872553475860b5baa8335184b70d23f22cb2c95c383f022352db52") -- P19_CN
addappid(1050041, 1, "a41b5047bceb1047726afbafdec144148f9106e50e0ba8b74325c04405878dc3") -- MAC_Power & Revolution 2019 Edition Content
addappid(1050042, 1, "6ed53d302685590eaac9243980904226d83bd340e30d15171ca9a1d70da8fad1") -- MAC_P19_FR
addappid(1050043, 1, "fbd4249648bffc0b62dec0a6aeb35a0d0507c004edadd52e9ba05bd8d5ed44e8") -- MAC_P19_DE
addappid(1050044, 1, "21872e14597238a55804e715f06c7e0f811defff346c3a62c23a12099de64ddf") -- MAC_P19_ES
addappid(1050045, 1, "6177401c5eef048c30f338fd6a52ff37d7014a1d02cf7092961a23741ba5c8a1") -- MAC_P19_IT
addappid(1050046, 1, "61249ab5bb83e331fb5bf584c846fb952792faf5f2006834c66ac2cf5f9d99c9") -- MAC_P19_JP

