-- Lua provided by RyzenAPI
-- Game: Oppai Girl

-- MAIN APPLICATION
addappid(981410)

-- MAIN APP DEPOTS / PACKAGES
addappid(981411, 1, "5cef7de2b7798537ec4918f2137b48abba035a8cdc57bbba15559a5c07f27105")

