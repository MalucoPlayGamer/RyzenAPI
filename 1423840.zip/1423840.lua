-- Lua provided by RyzenAPI
-- Game: 1423840

-- MAIN APPLICATION
addappid(1423840)
-- Game: addappid(1423840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423841, 1, "dad39c9eedc5650e4d67cd61648c49c68f7bf3f49749fb85a3ec541e5a602b37")
