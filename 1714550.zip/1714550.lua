-- Lua provided by RyzenAPI
-- Game: Ninja Issen (忍者一閃)

-- MAIN APPLICATION
addappid(1714550)
-- Game: addappid(1714550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714551, 1, "8145b2214a9fd4465c39eabb54f94923273a1090b7e4e1a1183bee65951c3be2")
