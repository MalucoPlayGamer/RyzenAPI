-- Lua provided by RyzenAPI
-- Game: 3472890

-- MAIN APPLICATION
addappid(3472890)
-- Game: addappid(3472890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3472891, 1, "4e0c91b4bfcb2e79472b04e7e9d10aa9524c6db2981cc2befbc7bed7b5ed5d2d")
