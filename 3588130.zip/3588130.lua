-- Lua provided by RyzenAPI
-- Game: In Stars and Time Artbook

-- MAIN APPLICATION
addappid(3588130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3588130,0,"83a033d78d81407460af0e7d6e5009e1265b384b9ae86cd3236cdb971cfedc4f")
