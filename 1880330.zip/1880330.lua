-- Lua provided by RyzenAPI
-- Game: 1880330

-- MAIN APPLICATION
addappid(1880330)
-- Game: addappid(1880330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880331, 1, "3e73a19dd09a22aaa2e38246e3ca82b2505ddfecfc199ce00a47210ce59d6485")
