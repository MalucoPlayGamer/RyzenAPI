-- Lua provided by RyzenAPI
-- Game: Mega Man Zero/ZX Legacy Collection

-- MAIN APPLICATION
addappid(999020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(999021, 1, "974feb98b181de2a334cede506d077ad1374981971c2b55c9902dec581afe55a")
addappid(1109480, 0, "9c67b6dd619329ca1498f6002d0ce7f5cfb04a2560a0f72debd3e1f940692683")

