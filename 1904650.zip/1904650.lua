-- Lua provided by RyzenAPI
-- Game: Dungeons & Dragons - Stronghold: Kingdom Simulator

-- MAIN APPLICATION
addappid(1904650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904651, 1, "c87af2d71f2fb30c1f0c682debe35cebd7da08c279a4d8b55459d50f45d7c05b")
addappid(1904652, 1, "2f3899f0c97e96f19dcc9d345d5ef829bf82979b035325d5aa72ba7f07321e0c")

