-- Lua provided by RyzenAPI
-- Game: addappid(3668070)

-- MAIN APPLICATION
addappid(3668070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668071, 1, "6144a75bedc3d6aef0c3aa696902c01dd99a81df80ead6110fd1bbffe8d05a30")
