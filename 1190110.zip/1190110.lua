-- Lua provided by RyzenAPI
-- Game: addappid(1190110)

-- MAIN APPLICATION
addappid(1190110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190111, 1, "e7c218fc991b2890601cabb913fca458c0f6d0af3dc8955d8cb73835c9e2230d")
