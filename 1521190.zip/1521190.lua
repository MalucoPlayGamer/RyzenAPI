-- Lua provided by RyzenAPI 
-- Game: Love in the distance
addappid(1521190)
addappid(1521191, 1, "b5f039834d45c08ea7e7350c624404c7a864750ae4a040c3ba84ba737112a65b")
addappid(1521192, 1, "c744b0f52ee4114d537e664b8d1d5349eb16977a999dd36c440568d70a72ad0c")
