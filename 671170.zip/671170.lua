-- Lua provided by RyzenAPI
-- Game: 671170

-- MAIN APPLICATION
addappid(671170)
addappid(671171)
addappid(671173)
addappid(671174)

-- MAIN APP DEPOTS / PACKAGES
addappid(671172,0,"a8abfac7d9a0b90dbb92b33c84cccd9c89b7b43e821d77e20800f729fbd68bf4")

