-- Lua provided by RyzenAPI
-- Game: 封神榜  伏魔三太子（重制版）

-- MAIN APPLICATION
addappid(1765160)
-- Game: addappid(1765160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765161, 1, "7f7db68c94f017ff62fdf18ebd80ba0b0af48da549e68cfd438049e7044ef9db")
