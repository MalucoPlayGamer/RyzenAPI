-- Lua provided by RyzenAPI
-- Game: Forest Keeper

-- MAIN APPLICATION
addappid(2807320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807321, 1, "4111852a2f0c70c11ab8dbcb9f1a26bcc7d37f7824ac71a6b139dfca76524814")
