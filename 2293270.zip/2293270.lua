-- Lua provided by RyzenAPI
-- Game: Touhou Lensed Night Sky, Kaseigai Demo

-- MAIN APPLICATION
addappid(2293270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293271, 1, "8e4571333411ddd782b2894172efac89323f852d0f96690c15ae0a550dffa5e1")
