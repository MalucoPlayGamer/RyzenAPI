-- Lua provided by RyzenAPI
-- Game: addappid(952030)

-- MAIN APPLICATION
addappid(952030)

-- MAIN APP DEPOTS / PACKAGES
addappid(952031, 1, "20af96dfbf2e6273367ef357021e2061f605f0b0eaa564218d4629e61adce6c8")
