-- Lua provided by RyzenAPI
-- Game: Shadow Tactics: Aiko's Choice

-- MAIN APPLICATION
addappid(1579380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579381, 1, "57aa2248cce96c61947b3114178e0cd3105ac53f4b3711be8ce5ea782d573fbd")
addappid(1579383, 1, "e0345c1a810cb18d9d4cc98d31ecc83191537cc78bea066b0b418304df1d9118")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
