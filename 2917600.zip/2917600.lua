-- Lua provided by RyzenAPI
-- Game: AppID 2917600

-- MAIN APPLICATION
addappid(2917600)
-- Game: addappid(2917600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917601, 1, "66f232294d99cf00b4662be88ea3f7a09d8491d0b7d1f59c1cc2b10889a0f6da")
