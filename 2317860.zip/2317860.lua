-- Lua provided by SkyAPI 
-- Game: AppID 2317860
addappid(2317860)
addappid(2317861, 1, "5c50a5aeb652d81a3d3fca5780114a9f092e051750e880e4351988328a5a2a55")
