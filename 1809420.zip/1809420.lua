-- Lua provided by RyzenAPI
-- Game: Shankaram: CODE REBORN

-- MAIN APPLICATION
addappid(1809420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809421, 1, "f597e9248ad44e8463bff1c05d94351e45a0cf1fe3c6f50a2b6ec0f4db7c2c49")

