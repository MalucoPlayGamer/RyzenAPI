-- Lua provided by RyzenAPI
-- Game: Rolando The Majestic

-- MAIN APPLICATION
addappid(1965410)
-- Game: addappid(1965410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965411, 1, "a46166c417f3faa28ab9261bb48739834666db8d405ace644696fdd52004ea1d")
