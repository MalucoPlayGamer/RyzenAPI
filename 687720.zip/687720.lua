-- Lua provided by RyzenAPI
-- Game: Baobabs Mausoleum Ep.2: 1313 Barnabas Dead End Drive

-- MAIN APPLICATION
addappid(687720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(687721,0,"082e90831ffa25d0285606b9670a798ad919f8313ee5be8f977f7939e868e3e5")

