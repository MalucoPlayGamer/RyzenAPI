-- Lua provided by RyzenAPI
-- Game: Baobabs Mausoleum Ep.2: 1313 Barnabas Dead End Drive

-- MAIN APPLICATION
addappid(687720)

-- MAIN APP DEPOTS / PACKAGES
addappid(687721,0,"082e90831ffa25d0285606b9670a798ad919f8313ee5be8f977f7939e868e3e5")

