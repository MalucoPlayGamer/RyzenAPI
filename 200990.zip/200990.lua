-- Lua provided by RyzenAPI 
-- Game: Geneforge 3
addappid(200990)
addappid(200991, 1, "f79b68df54e1f6c35bcbb2e9afb2db4bb076a0c7f2f3faf9f72d6f490fe8bd28")
