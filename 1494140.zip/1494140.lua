-- Lua provided by RyzenAPI
-- Game: 7Days Origins

-- MAIN APPLICATION
addappid(1494140)
-- Game: addappid(1494140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494141, 1, "1b7af338718f423799728abe6f54581980a2d9ccd960db960632cf56cc62a8e0")
