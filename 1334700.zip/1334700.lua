-- Lua provided by RyzenAPI
-- Game: tomorrow won't come for those without ██████

-- MAIN APPLICATION
addappid(1334700)
-- Game: addappid(1334700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334701, 1, "815e94f804cdad22cf34f19eaaf0303df87cb9510cd6fce9dd027e7ca52e4adc")
addappid(1334702, 1, "cdf850ab035feeab2a38c2021011c0d3ae72eebc7c010f8fd9259f529b1e0271")
addappid(1334704, 1, "072f256611d99aec3ac53d31141c9975145ba88e0a425e406955383713310351")
addappid(1334705, 1, "746c2d4549bf4deaba6c95ebbfc71868231165c04a4209ccdf004112fe887754")
