-- Lua provided by RyzenAPI
-- Game: Farm Empire

-- MAIN APPLICATION
addappid(2320130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320131, 1, "96e2f3db7246890adc74c5671517b5f1492a7c4bf4d56c75c61ec29bd09dfc55")
addappid(2320132, 1, "b8c81f5a2920327acbd44388b0d6e9c0846b67a10b5ec2a0b1a52c9ac9d642ac")

