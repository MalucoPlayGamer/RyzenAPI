-- Lua provided by RyzenAPI
-- Game: Estencel

-- MAIN APPLICATION
addappid(2025320)
-- Game: addappid(2025320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025321, 1, "d088dd80384e4775ed1fc573d1509e595e467c9a1ca0607a601cce757bd1ad9b")
