-- Lua provided by RyzenAPI
-- Game: Estencel

-- MAIN APPLICATION
addappid(2025320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025321, 1, "d088dd80384e4775ed1fc573d1509e595e467c9a1ca0607a601cce757bd1ad9b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
