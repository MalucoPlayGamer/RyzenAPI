-- Lua provided by RyzenAPI
-- Game: Bunny Girl Cumming for my Carrot

-- MAIN APPLICATION
addappid(2888290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888291, 1, "24417047ad2940ebc933386c2f571ae84032dd37849bfb5c2d97c47b1ee24ac6")

