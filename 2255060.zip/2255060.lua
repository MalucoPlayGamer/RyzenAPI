-- Lua provided by RyzenAPI
-- Game: 2255060

-- MAIN APPLICATION
addappid(2255060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255060,0,"e7ac77d0e9491bcd58e2e150d07226da949dee1eabe5f0cf4343e8d1f078650a")

