-- Lua provided by RyzenAPI
-- Game: Spooky Typing: The Ghost Plague

-- MAIN APPLICATION
addappid(1791870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791871, 1, "feaabdf9f3e3bc86c2168b60073b94e788b07cea1f337d0cf6f014169075e2f3")

