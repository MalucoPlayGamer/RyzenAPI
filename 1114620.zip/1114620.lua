-- Lua provided by RyzenAPI
-- Game: Cloak and Dasher

-- MAIN APPLICATION
addappid(1114620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114621, 1, "7b863d025ce381b5d2886eb907e742a39d76257ba1cde40013c3ba05eb44fd44")

