-- Lua provided by RyzenAPI
-- Game: Burger Patrol

-- MAIN APPLICATION
addappid(313700)
-- Game: addappid(313700)

-- MAIN APP DEPOTS / PACKAGES
addappid(313702,0,"587a129cf86869db9586fb25b854e67dcafd2fd1586a62731231a97c6aa8262f")
