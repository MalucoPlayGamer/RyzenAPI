-- Lua provided by RyzenAPI 
-- Game: Paraplasm: Beyond the Veil
addappid(2913670)
addappid(2913671, 1, "dbf10649a6fd4fbd610af541d04059bfe7687879051a97a1a6d2d9aabc41bb5e")
