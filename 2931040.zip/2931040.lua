-- Lua provided by SkyAPI 
-- Game: Poor Thief
addappid(2931040)
addappid(2931041, 1, "8c0e0363cd61c08da492a00e25e43c31015ba611d2dd56bb63faa12b1ee4fd8b")
