-- Lua provided by RyzenAPI
-- Game: Klepto

-- MAIN APPLICATION
addappid(403590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(403591, 1, "c1aa87b983f70a1da5f25f1f7f933aaf1d9b753dd30370d460bf136c9fcc3b5c")

