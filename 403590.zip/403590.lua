-- Lua provided by RyzenAPI
-- Game: addappid(403590)

-- MAIN APPLICATION
addappid(403590)

-- MAIN APP DEPOTS / PACKAGES
addappid(403591, 1, "c1aa87b983f70a1da5f25f1f7f933aaf1d9b753dd30370d460bf136c9fcc3b5c")
