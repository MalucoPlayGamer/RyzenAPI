-- Lua provided by RyzenAPI
-- Game: AppID 862810

-- MAIN APPLICATION
addappid(862810)

-- MAIN APP DEPOTS / PACKAGES
addappid(862811, 1, "b08bbe19b22d576f34ce8fe6f961d4684a04bac9026a61cea8922a53397eb1fe")
