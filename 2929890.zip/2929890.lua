-- Lua provided by RyzenAPI
-- Game: Game: Cyborg City

-- MAIN APPLICATION
addappid(2929890)
-- Game: addappid(2929890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929891, 1, "c896156881b05e5cb516a2f5fc5e8053836d1c396599f08a4ac6270085e6d076")
