-- Lua provided by RyzenAPI
-- Game: addappid(1119710)

-- MAIN APPLICATION
addappid(1119710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119711, 1, "9d3ce368aeea7e0fa7089f6c3766c1947e69fddf6dad12e3ce99033a1392f7a4")
addappid(1119712, 1, "605792ba17735d0e9b5539f7a21ea379c83e204c817f14ee22a0a0a3dd64d07c")
