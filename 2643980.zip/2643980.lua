-- Lua provided by RyzenAPI
-- Game: Emberward Demo

-- MAIN APPLICATION
addappid(2643980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643981, 1, "d63e46b47fef72d77d99a016fedf650dd92425f521df37dfd6cc93bf74ee58da")
