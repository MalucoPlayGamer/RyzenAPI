-- Lua provided by RyzenAPI
-- Game: Hentai Luna

-- MAIN APPLICATION
addappid(2939180)
-- Game: addappid(2939180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2939181, 1, "e0a72cd82b17f72ed0fd6d0e89516920a76f8b17a3a405690e5d6cb6d0be3966")
