-- Lua provided by RyzenAPI
-- Game: Acceleration of SUGURI 2

-- MAIN APPLICATION
addappid(390710)

-- MAIN APP DEPOTS / PACKAGES
addappid(390711, 1, "719119317690283c0722310941f213e99de10833bf0dedbe0ebb0880d36b474c")

