-- Lua provided by RyzenAPI
-- Game: Acceleration of SUGURI 2

-- MAIN APPLICATION
addappid(390710)
addappid(1502440)
addappid(1665560)
addappid(3731930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(390711, 1, "719119317690283c0722310941f213e99de10833bf0dedbe0ebb0880d36b474c")

