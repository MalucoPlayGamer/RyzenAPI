-- Lua provided by RyzenAPI
-- Game: Horny Housewives Booty Call Blackmail

-- MAIN APPLICATION
addappid(1641010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641011, 1, "22010dc597b83609342b6d77e41df95367408db53363e45327cef4fd77dac82d")

