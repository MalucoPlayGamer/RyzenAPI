-- Lua provided by RyzenAPI
-- Game: Battle Shapers Demo

-- MAIN APPLICATION
addappid(2450000)
-- Game: addappid(2450000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450001, 1, "81116f54598f31121762b9e0c7b8561686f39e9677d3b449b94315b075fb6e00")
