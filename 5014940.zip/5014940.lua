-- 5014940's Lua and Manifest Created by Hubcap Manifest
-- Clickendo
-- Created: August 15, 2026 at 00:09:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5014940) -- Clickendo
-- MAIN APP DEPOTS
addappid(5014941, 1, "22722c3e77245b17ed057806160622560988118a09ad31af0dfabe7d7cd5f98e") -- Depot 5014941
setManifestid(5014941, "8520999268485241321", 88639831)