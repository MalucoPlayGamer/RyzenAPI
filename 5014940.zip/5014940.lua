-- Lua provided by RyzenAPI
-- Game: Clickendo

-- MAIN APPLICATION
addappid(5014940) -- Clickendo

-- MAIN APP DEPOTS / PACKAGES
addappid(5014941, 1, "22722c3e77245b17ed057806160622560988118a09ad31af0dfabe7d7cd5f98e") -- Depot 5014941

