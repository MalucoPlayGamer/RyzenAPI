-- Lua provided by RyzenAPI
-- Game: addappid(1084630)

-- MAIN APPLICATION
addappid(1084630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084631, 1, "92ac47ee519bf1edce6fccb2e03d10c3ae2721c61425302c3f8f35c4c2a1eb10")
