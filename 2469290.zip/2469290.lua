-- Lua provided by RyzenAPI
-- Game: addappid(2469290)

-- MAIN APPLICATION
addappid(2469290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469292,0,"ff6e4a081a29ba17d344ce15b4d108fea1622a9b58614a6eacc33cb69c313ebb")
