-- Lua provided by RyzenAPI
-- Game: 1466640

-- MAIN APPLICATION
addappid(1466640)
-- Game: addappid(1466640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466641, 1, "4002fa24b467f86f7d65fb8a377d33358f83d3b42ebe25cc72332820bafcea85")
addappid(1681090, 0, "e849c920b7bd10b6cd085dd924dcc425c8526ca5adef4f3bcc6d5d76edbc523c")
addappid(1782160, 0, "76552fd3f798c97e0f65596b191fff61ae78efa157fff76de8fbb409d322755e")
