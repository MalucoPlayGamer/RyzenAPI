-- Lua provided by RyzenAPI
-- Game: 江梦潮音 J.M.Rhythm

-- MAIN APPLICATION
addappid(2836760)
-- Game: addappid(2836760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836763,0,"88d0567af2e37170daa4a7f353a226b7a858d201c317c39c09351f1b39a1606e")
addappid(2836764,0,"19e899d8017a6a7d5beef48134151e310fe0f80f8aaab9070cc9f237319f5ea9")
