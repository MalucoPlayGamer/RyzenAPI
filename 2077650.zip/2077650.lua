-- Lua provided by RyzenAPI
-- Game: Amok Runner

-- MAIN APPLICATION
addappid(2077650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077654,0,"ca4f42393889893fa5c3782144c26d4d8702e9bde72894c44b00a53f935c9838")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
