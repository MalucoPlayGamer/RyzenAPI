-- Lua provided by RyzenAPI
-- Game: Amok Runner

-- MAIN APPLICATION
addappid(2077650)
-- Game: addappid(2077650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077654,0,"ca4f42393889893fa5c3782144c26d4d8702e9bde72894c44b00a53f935c9838")
