-- 4492260's Lua and Manifest Created by Hubcap Manifest
-- Ducks in Disguise
-- Created: August 01, 2026 at 13:55:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4492260, 1, "1e7a5488ecdddb5713870f21e5845318c9c28763b2e71e32d61a7058301a6aef") -- Ducks in Disguise
-- MAIN APP DEPOTS
addappid(4492261, 1, "c95b42a32277ba5d5b06d69650564649821e0761eb0d6a3d192ca23296b45cec") -- Depot 4492261
setManifestid(4492261, "4189138732940794044", 372490029)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4492262) -- Depot 4492262 (empty depot)