-- Lua provided by RyzenAPI
-- Game: Ducks in Disguise

-- MAIN APPLICATION
-- addappid(4492262) -- Depot 4492262 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4492260, 1, "1e7a5488ecdddb5713870f21e5845318c9c28763b2e71e32d61a7058301a6aef") -- Ducks in Disguise
addappid(4492261, 1, "c95b42a32277ba5d5b06d69650564649821e0761eb0d6a3d192ca23296b45cec") -- Depot 4492261

