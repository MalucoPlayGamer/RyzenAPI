-- Lua provided by RyzenAPI
-- Game: The Three Musketeers - D'Artagnan & the 12 Jewels

-- MAIN APPLICATION
addappid(827110)
-- Game: addappid(827110)

-- MAIN APP DEPOTS / PACKAGES
addappid(827111, 1, "7174f97b4dc804ab8624ab715e4093e47f7c38edf77897995273315864b75f0a")
