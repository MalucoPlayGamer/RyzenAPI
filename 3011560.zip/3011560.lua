-- Lua provided by RyzenAPI
-- Game: addappid(3011560)

-- MAIN APPLICATION
addappid(3011560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011561, 1, "1d00e46b6cf91037e5bcc758b2e7730e71037025ab3c8af09a8a00789bac23a0")
