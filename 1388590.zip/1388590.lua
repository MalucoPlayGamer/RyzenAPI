-- Lua provided by RyzenAPI
-- Game: Yakuza 6: The Song of Life

-- MAIN APPLICATION
addappid(1388590)
addappid(1478720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1388591, 1, "02a2c7298742e3092a66f1d6b2a6c2703b1d8452a110657633953890a89309b4")

