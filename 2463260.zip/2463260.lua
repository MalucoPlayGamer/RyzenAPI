-- Lua provided by RyzenAPI
-- Game: 有所思 Yearning

-- MAIN APPLICATION
addappid(2463260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463261, 1, "1e7389e3cb2a6572fc954e2f59c29c0a240b30e7bfba07912add284d58b91883")
