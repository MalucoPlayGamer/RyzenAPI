-- Lua provided by RyzenAPI
-- Game: Hexia

-- MAIN APPLICATION
addappid(1173730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173732,0,"9f88a63701dd7fc4202f89954b2dd155e90ffc3f4c1ff0be25555f8255294c40")
