-- Lua provided by RyzenAPI
-- Game: Hexia

-- MAIN APPLICATION
addappid(1173730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173732,0,"9f88a63701dd7fc4202f89954b2dd155e90ffc3f4c1ff0be25555f8255294c40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
