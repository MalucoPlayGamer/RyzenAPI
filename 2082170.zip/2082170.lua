-- Lua provided by RyzenAPI
-- Game: Game: OnlyFap Simulator 2 💦

-- MAIN APPLICATION
addappid(2082170)
-- Game: addappid(2082170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082171, 1, "7482e003041f54b50f913f4822182db852ada4b7cd756af8ba65d5ef7305b16a")
