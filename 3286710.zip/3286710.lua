-- Lua provided by RyzenAPI
-- Game: Softie

-- MAIN APPLICATION
addappid(3286710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286711, 1, "d20b05e51524904a55a18c38bb78cce3dbe641557e835ad867caca8230f9d333")
