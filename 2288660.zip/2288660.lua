-- Lua provided by RyzenAPI
-- Game: Game: Furry Reich 🐺

-- MAIN APPLICATION
addappid(2288660)
-- Game: addappid(2288660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288661, 1, "18a257c69daf9692595dbbcc5680491f071382e92d3627fc7cfeefbaefb8e1a1")
addappid(2378020, 0, "6fd2af82066da85c0666ba53a468e2abaf5a7a6a7f0c9f3c7ce3e68cf3a1d017")
