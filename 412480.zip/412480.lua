-- Lua provided by RyzenAPI
-- Game: Turtle Odyssey

-- MAIN APPLICATION
addappid(412480)

-- MAIN APP DEPOTS / PACKAGES
addappid(412481, 1, "edb4fc97ecc0f4c06bf7bede4e5388fc7cbecfd6baa038a26d03d7b4cd1991f1")
addappid(412482, 1, "e007bd1143e6cabafc349c36499a3ab25dc3879df48bf1c905f0a44d3183feff")
addappid(412484, 1, "f6c7ee0bbb9dcb74b26c42d2e1f1527915ad5fc4ffc174065095c408ae5fb023")
addappid(412485, 1, "c876ff793051cc48d1a4360e955dde48d8c2ce33bbce79ded30a393d660de5e6")
addappid(412486, 1, "0a93a7e19f923cc82df01ccd57126cfe3b6a6232cf5dd05b2e4edc5654aaec5a")
