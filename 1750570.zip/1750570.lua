-- Lua provided by RyzenAPI
-- Game: Subway Midnight

-- MAIN APPLICATION
addappid(1750570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750571, 1, "7b50024de28816655a74e4f56844e911b42a8430694f14bf482c3d3f7e3687ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
