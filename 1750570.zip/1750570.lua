-- Lua provided by RyzenAPI
-- Game: Game: Subway Midnight

-- MAIN APPLICATION
addappid(1750570)
-- Game: addappid(1750570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750571, 1, "7b50024de28816655a74e4f56844e911b42a8430694f14bf482c3d3f7e3687ce")
