-- Lua provided by RyzenAPI
-- Game: ATRI -My Dear Moments- Demo

-- MAIN APPLICATION
addappid(1263470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263471, 1, "cbce0c0138d1c3043ea737aafb05c6f1d04e27ee436ac4f0dabbd8f4cdd28b7a")
