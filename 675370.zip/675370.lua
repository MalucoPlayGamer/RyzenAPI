-- Lua provided by RyzenAPI
-- Game: addappid(675370)

-- MAIN APPLICATION
addappid(675370)

-- MAIN APP DEPOTS / PACKAGES
addappid(675371, 1, "7a874dfa66f9dc8ce4b48575826da3fe3850c077320a84371e4bbaaf4555c2a4")
