-- Lua provided by RyzenAPI
-- Game: Blackout Hospital

-- MAIN APPLICATION
addappid(2301510)
