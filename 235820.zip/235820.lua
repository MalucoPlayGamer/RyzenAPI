-- Lua provided by RyzenAPI
-- Game: Element4l

-- MAIN APPLICATION
addappid(235820)

-- MAIN APP DEPOTS / PACKAGES
addappid(235821, 1, "ca41a549efde590258fd5c0dae8c564a69a22ef678eda57a8b8ddf06668d458a")
addappid(235822, 1, "c9820d7cfafdd4936008090a63691d11a7f9f72113c1dc157a90d4173f0f048a")
addappid(235823, 1, "8fe9bed28eeb49ce2d874b73a23f1030344330a4001efdd1dd29d60016b4fee9")
addappid(235824, 1, "6c69bf44af1ad3ea9fda51696ee27fad4a4aab45a5740c673a266009b5623934")
