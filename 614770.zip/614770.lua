-- Lua provided by SkyAPI 
-- Game: Beachhead: DESERT WAR
addappid(614770)
addappid(614771, 1, "c912c0a90c9c339e27f3290c97555f8be358bb1971f7bdaaa1e9c78e7059c2a5")
