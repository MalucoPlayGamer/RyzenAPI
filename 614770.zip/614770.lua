-- Lua provided by RyzenAPI
-- Game: Beachhead: DESERT WAR

-- MAIN APPLICATION
addappid(614770)

-- MAIN APP DEPOTS / PACKAGES
addappid(614771, 1, "c912c0a90c9c339e27f3290c97555f8be358bb1971f7bdaaa1e9c78e7059c2a5")

