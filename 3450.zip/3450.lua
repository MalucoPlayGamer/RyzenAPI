-- Lua provided by RyzenAPI
-- Game: Typer Shark! Deluxe

-- MAIN APPLICATION
addappid(3450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451, 1, "b77c58c0afc47722fe738beb8bab11cd44a5b2db92950470eb69da9878abfa9b")
