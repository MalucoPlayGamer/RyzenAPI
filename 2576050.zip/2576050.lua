-- Lua provided by RyzenAPI
-- Game: The Last King Demo

-- MAIN APPLICATION
addappid(2576050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576051, 1, "305816bbcafbeef1bc94a69cc0cc6db5caa596f1b93ff63adf408f6e2848f660")

