-- Lua provided by RyzenAPI
-- Game: addappid(3253860)

-- MAIN APPLICATION
addappid(3253860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253861, 1, "371ef77bd5ac4cba1502d9761314f39139ff19cf3a84940a9b74553717bf3ba5")
