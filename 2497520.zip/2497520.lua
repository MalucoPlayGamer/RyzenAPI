-- Lua provided by RyzenAPI
-- Game: RUSH: Only Up Multiplayer

-- MAIN APPLICATION
addappid(2497520)
-- Game: addappid(2497520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497521, 1, "34df4557ec2dd51d6f0e6e0b348f31fb895cc4f0cf2c3c9513209ecab452b4b3")
