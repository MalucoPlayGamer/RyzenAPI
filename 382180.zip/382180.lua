-- Lua provided by RyzenAPI
-- Game: Devilry

-- MAIN APPLICATION
addappid(382180)
-- Game: addappid(382180)

-- MAIN APP DEPOTS / PACKAGES
addappid(382181, 1, "b1523031f7921c4cd5eecc8d6410c9d3da335d451852d2206e2c4f9c3cb92bf4")
