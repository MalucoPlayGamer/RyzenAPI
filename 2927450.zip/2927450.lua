-- Lua provided by RyzenAPI
-- Game: Wings of Seduction Art Book

-- MAIN APPLICATION
addappid(2927450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927450,0,"576789dddab6f6630416f262c8c48c95e33a95e984fbe982f1e3fa29bd401c86")

