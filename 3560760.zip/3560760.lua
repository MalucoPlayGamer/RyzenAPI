-- Lua provided by RyzenAPI
-- Game: 3560760

-- MAIN APPLICATION
addappid(3560760)
-- Game: addappid(3560760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3560761, 1, "fd45688c1cb976437d9e8ac47938f076b017149b416f5d4998e0bdcc8ab9eb31")
addappid(3560762, 1, "5ecbc14a94c7cc2742b9fb59ae84e432f4d0bb293b118ec11bb982b3302643c9")
