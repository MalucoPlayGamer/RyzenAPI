-- Lua provided by RyzenAPI
-- Game: Mystery Box 2: Evolution

-- MAIN APPLICATION
addappid(2541380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541382,0,"916c03485624498191b2022a082b9db62b828e8bf93e0fc29de17023db38059c")

