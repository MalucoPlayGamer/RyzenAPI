-- Lua provided by RyzenAPI
-- Game: Cannon Brawl

-- MAIN APPLICATION
addappid(230860)
addappid(324920)

-- MAIN APP DEPOTS / PACKAGES
addappid(230861, 1, "6268a83a57ef6a0d5bd61daef9c0bd11c8e74a20601275a65f7465cbf5a96fd8")
addappid(367310, 0, "abd8f32b0b87284d391e0cca491a1fc5c82e361488a5744a666695326e186789")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
