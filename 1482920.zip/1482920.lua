-- Lua provided by RyzenAPI
-- Game: Dance Waifu

-- MAIN APPLICATION
addappid(1482920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482921, 1, "840ddfac03f3b438499dca7ec7944b1b62b15ef27e974703c7309b8e20d4c7e7")

