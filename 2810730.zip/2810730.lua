-- Lua provided by RyzenAPI
-- Game: A Building Full of Cats 2

-- MAIN APPLICATION
addappid(2810730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810731, 1, "452dbb8aff3ac3d649b92c7a2b591932c978e9d66a88f2a6bf5705245ab3b3b7")
