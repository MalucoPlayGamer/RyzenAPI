-- Lua provided by RyzenAPI
-- Game: Game: ScrewUp

-- MAIN APPLICATION
addappid(1695670)
-- Game: addappid(1695670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695671, 1, "42082982cbdd3229a17a0a0eae94966ee12e023e869b045358481452c3bd23b7")
