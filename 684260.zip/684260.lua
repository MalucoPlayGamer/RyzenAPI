-- Lua provided by RyzenAPI
-- Game: Phantom Warfare

-- MAIN APPLICATION
addappid(684260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(684261,0,"b47b2e4af4349e610be528aeb609939cad7a4a9d63311f0752564e077364602f")

