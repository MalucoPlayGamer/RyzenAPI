-- Lua provided by RyzenAPI
-- Game: Phantom Warfare

-- MAIN APPLICATION
addappid(684260)

-- MAIN APP DEPOTS / PACKAGES
addappid(684261,0,"b47b2e4af4349e610be528aeb609939cad7a4a9d63311f0752564e077364602f")

