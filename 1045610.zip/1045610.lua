-- Lua provided by RyzenAPI
-- Game: addappid(1045610)

-- MAIN APPLICATION
addappid(1045610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045611, 1, "79aceeca7900160b3af0b02387deaba1bf6a62dd5abc11e8cbdfe543aba82361")
