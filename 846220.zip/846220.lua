-- Lua provided by RyzenAPI
-- Game: 846220

-- MAIN APPLICATION
addappid(846220)
-- Game: addappid(846220)

-- MAIN APP DEPOTS / PACKAGES
addappid(846221, 1, "434f4f4f2a33da114d05122c4c54bb880c768734f223b366217ae403773a1e3f")
