-- Lua provided by RyzenAPI
-- Game: 69 Hitomi Love

-- MAIN APPLICATION
addappid(1750330)
-- Game: addappid(1750330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750331, 1, "b15977a167bd4b95887eb2142f32b65a52ea8b2c3a2508958cbb27b362f99b01")
