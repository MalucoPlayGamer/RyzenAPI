-- Lua provided by RyzenAPI
-- Game: Game: AppID 3231300

-- MAIN APPLICATION
addappid(3231300)
-- Game: addappid(3231300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231301, 1, "e43de3e90d0aa4dc5aeb848e1741aa1f351f3ae45561015a18cf3ed5ce84890e")
