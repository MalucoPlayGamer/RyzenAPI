-- Lua provided by RyzenAPI
-- Game: AppID 1469610

-- MAIN APPLICATION
addappid(1469610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469611, 1, "cb95d3ea5c9f552b88c37bc94987bef1625b3ae64e2b06522256c01342877ac8")
addappid(2617710, 0, "c3882e3af17a4230d127faccd8d869954c76c7521e0b980d650b6c477a8703b1")
addappid(2617720, 0, "b7098a3e63d8c9af791a2e7490e6a549a15f7703d2a5149905769c2e49bc16d3")
addappid(2946200, 0, "c4f3b00cb21b98545ffbf687c92a0cac6968687f71637da7746fd8eeed0e4256")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
