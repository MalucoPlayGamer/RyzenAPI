-- Lua provided by RyzenAPI 
-- Game: AppID 335450
addappid(335450)
addappid(335451, 1, "69957a63e2f4f4b677194dec51f644c853c77bcecbcd8c3b4533133d7982ca4e")
addappid(335452, 1, "0fde542af82105c21dee6007ebc7db574f6e1dc40a7aa4e59c1d0c5a0f63f958")
addappid(335453, 1, "3d28dce5231dabc9d76484a09c097c91f416fe7e8993d40b4de53700daddbc67")
