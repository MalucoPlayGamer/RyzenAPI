-- Lua provided by RyzenAPI
-- Game: Magic piano

-- MAIN APPLICATION
addappid(3042880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042881, 1, "0d5caf4bf8629576d0a962a2900579bd97f997ba3f5121e596a0352e2abeddb1")
