-- Lua provided by RyzenAPI
-- Game: Haimrik

-- MAIN APPLICATION
addappid(492180)

-- MAIN APP DEPOTS / PACKAGES
addappid(492181, 1, "95244b4ad174a0b44e2c2f398559431880beb362717f42fe97df6741b8fadbed")
