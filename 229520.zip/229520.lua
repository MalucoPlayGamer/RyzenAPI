-- Lua provided by RyzenAPI
-- Game: Dungeon Hearts

-- MAIN APPLICATION
addappid(229520)

-- MAIN APP DEPOTS / PACKAGES
addappid(229521, 1, "934e0c1785df339e5c559cadd5e6da260cf81a5c0470d26bcb002a0981eef9cd")
addappid(229522, 1, "afd5be36e0dc52b71fbd9c40ea76bf6ba5c69ef6e53c634ea4454702104f471f")
addappid(229523, 1, "6eed87041efd203a09187adcdb7512b1c0d694b08f46ead6dc15cd601aacac43")
addappid(229524, 1, "eae64419680c0b9cc1ddcd14b6098174d59cca102dab79d7f9900fd00ca16c61")
