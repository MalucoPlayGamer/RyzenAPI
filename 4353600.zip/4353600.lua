-- Lua provided by RyzenAPI
-- Game: Radiance of Annihilation -Disorder Eclipse-

-- MAIN APPLICATION
addappid(4353600)

-- MAIN APP DEPOTS / PACKAGES
addappid(4353601,0,"1bba49148f843983c899586d6286d850833f984cbf88eebb92534d1d0c3afc79")

