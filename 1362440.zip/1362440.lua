-- Lua provided by SkyAPI 
-- Game: AppID 1362440
addappid(1362440)
addappid(1362441, 1, "a25a192cf9ecd81361c9604666c7ca49a6fa16b3bc05e0a26729ac6383fa6ae0")
