-- Lua provided by RyzenAPI
-- Game: Norman's Great Illusion

-- MAIN APPLICATION
addappid(463510)

-- MAIN APP DEPOTS / PACKAGES
addappid(463511, 1, "f09e07b5616b15d4686b89811bfe2a733d1b215092827edd37b976df77c5829f")
