-- Lua provided by RyzenAPI
-- Game: Wing Breakers

-- MAIN APPLICATION
addappid(308080)
-- Game: addappid(308080)

-- MAIN APP DEPOTS / PACKAGES
addappid(308081, 1, "94ab58d65030b6ba3c615801863a04f904eea6f39ac395fea82dc1b31ab60e10")
