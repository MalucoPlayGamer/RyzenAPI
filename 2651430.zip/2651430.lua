-- Lua provided by RyzenAPI
-- Game: Futanari Master!

-- MAIN APPLICATION
addappid(2651430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651431,0,"c61f25fd7c23ad73677116b879802fbefe7649426bf2be12b43f9bc9abbb6700")
addappid(2651432,0,"8633f90774dbbd055a7c0d3b8018375c5b6918be9710f4eb1320f7d3845bec44")

