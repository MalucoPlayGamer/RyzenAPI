-- Lua provided by RyzenAPI
-- Game: addappid(2234890)

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2234890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234892,0,"01b4d0936ee407d0fec8c116b5abeadb15e985525af1989ba4e10d7b584d8fb4")
