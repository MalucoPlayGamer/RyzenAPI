-- Lua provided by RyzenAPI
-- Game: Game: AppID 519140

-- MAIN APPLICATION
addappid(519140)
-- Game: addappid(519140)

-- MAIN APP DEPOTS / PACKAGES
addappid(519141, 1, "1628d3be4d45ebdb8177970504fe7068f343c48b2bbc646d3585aa3091a77da7")
