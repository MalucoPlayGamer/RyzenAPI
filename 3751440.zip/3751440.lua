-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KPVD Airport

-- MAIN APPLICATION
addappid(3751440)
-- Game: addappid(3751440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751440,0,"def975c45bfffc1b64dad57b9c42c03203fe436576384cbd609e273db4384409")
