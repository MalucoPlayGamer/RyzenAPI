-- Lua provided by RyzenAPI
-- Game: addappid(1820050)

-- MAIN APPLICATION
addappid(1820050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820051, 1, "7be4418a77385f68a45c07b1bf1871f98a04122b12697f9ed9e69d8f6fccccbf")
