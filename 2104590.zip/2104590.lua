-- Lua provided by RyzenAPI
-- Game: addappid(2104590)

-- MAIN APPLICATION
addappid(2104590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104591, 1, "b0aeab9d441989c42800ee37a97ff4cbdd892810d4bae79932272be9c084f6bd")
