-- Lua provided by RyzenAPI
-- Game: Goblin Quest: Escape!

-- MAIN APPLICATION
addappid(375570)

-- MAIN APP DEPOTS / PACKAGES
addappid(375572,0,"9f9b69cad412ad650ed262b7aeef83418d88610b47800d6c3f2fca6b3e73b552")
addappid(375630,0,"3977d727a1df9f1d984393e322ee6c07123b48e7b6876f540b0619bd6dd2b463")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
