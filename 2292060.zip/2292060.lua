-- Lua provided by RyzenAPI
-- Game: Spell Disk

-- MAIN APPLICATION
addappid(2292060)
-- Game: addappid(2292060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292061, 1, "57722719c4d76726459b7c503ac87b5f0df90699a17f81409948f1009d50a0eb")
