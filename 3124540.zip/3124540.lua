-- Lua provided by RyzenAPI
-- Game: Game: Far Far West

-- MAIN APPLICATION
addappid(3124540)
-- Game: addappid(3124540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124541, 1, "c09a55a6a88c0a10b672b6f544431641dafaf34a4f082c4798b3de9a59061cac")
