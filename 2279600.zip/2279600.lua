-- Lua provided by RyzenAPI
-- Game: Raw Metal

-- MAIN APPLICATION
addappid(2279600)
-- Game: addappid(2279600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279601, 1, "65d42d74ac4d4892600feab5a59795e6108dc6c7fabd93c7b70971606d36e7e5")
