-- Lua provided by RyzenAPI
-- Game: One Last Crane

-- MAIN APPLICATION
addappid(446530)

-- MAIN APP DEPOTS / PACKAGES
addappid(446531, 1, "c34faa7fb987cfe710085b7eb6461ebb3721d6b62541f1ddee166584427b7595")

