-- Lua provided by RyzenAPI
-- Game: Hypersomnia

-- MAIN APPLICATION
addappid(2660970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660971, 1, "8b77b3879efa72f77d3555219c65b4a3434c73a597bb479de661d8db3844b401")
addappid(2660972, 1, "a40e660272a73b23d5041e58f0362bcaa5365ccb46ce8a65513dd6be9755b53f")
addappid(2660973, 1, "825d9d6c3dc29e0b75d0a10302d24c98ce322b45af9510c874ed8523981fe2ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
