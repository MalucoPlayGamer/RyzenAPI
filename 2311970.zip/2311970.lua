-- Lua provided by RyzenAPI
-- Game: AppID 2311970

-- MAIN APPLICATION
addappid(2311970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311971, 1, "cc2723234e3db33cf22e8fb64027bb7cf0fa4257bc96f1e67a0f3dfac166a307")
addappid(2311972, 1, "4ffac67a7d0162c24f28cd0b04bc27f9b539b657465c74c073508de0caa1bfb3")

