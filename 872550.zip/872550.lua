-- Lua provided by RyzenAPI
-- Game: addappid(872550)

-- MAIN APPLICATION
addappid(872550)

-- MAIN APP DEPOTS / PACKAGES
addappid(872551, 1, "f63fd4afec309d9653f95d00098be42a22e4959f72ad4642af5376529d97f465")
