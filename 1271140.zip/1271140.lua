-- Lua provided by RyzenAPI
-- Game: AppID 1271140

-- MAIN APPLICATION
addappid(1271140)
-- Game: addappid(1271140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271141, 1, "172acc191fd0ba21def842d2509c0b4f8734a85751767671f1fa43aacb35b971")
