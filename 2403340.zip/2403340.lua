-- Lua provided by RyzenAPI
-- Game: 大科学家

-- MAIN APPLICATION
addappid(2403340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403341, 1, "cc57e9273fb8db16680f8014f5db391b766e33a89bcb018098af8d678d535167")
