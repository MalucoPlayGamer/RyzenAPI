-- Lua provided by RyzenAPI
-- Game: AppID 854210

-- MAIN APPLICATION
addappid(854210)

-- MAIN APP DEPOTS / PACKAGES
addappid(854211, 1, "56be9e728d0be9c738badc405da86ad6dabc07458e900f43c73d6994aff127ce")

