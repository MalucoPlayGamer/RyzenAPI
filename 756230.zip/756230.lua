-- Lua provided by RyzenAPI 
-- Game: KARTOFELKA
addappid(756230)
addappid(756231, 1, "44cd41eb9eee35bd7ca8cdaad98704c2d426a3a29a69b4d4e45b291d74f71a4c")
