-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1463251)
addappid(3030890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463251,0,"88d8fcb08c3ac472634eaa68124a10f6754d63e01c3745b8ef33fd52ed15957c")
