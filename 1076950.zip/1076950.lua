-- Lua provided by RyzenAPI
-- Game: 1076950

-- MAIN APPLICATION
addappid(1076950)
-- Game: addappid(1076950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076951, 1, "6945dd323b2410eebd11cf82dfde21c20117175cece5979c2047b858204c2285")
