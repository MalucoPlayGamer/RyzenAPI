-- Lua provided by RyzenAPI
-- Game: Riviera: The Promised Land

-- MAIN APPLICATION
addappid(2891280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(2891281, 1, "1505f12920cd71d2371d4173e5f5746b9c71d824053651945ea03453d64abd0e")
addappid(2891282, 1, "350baf77bde688c99936a20dc7049d0bd9c018f8884f3199c5676b4decd4645b")

