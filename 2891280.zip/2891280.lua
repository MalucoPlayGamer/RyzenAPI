-- Lua provided by RyzenAPI
-- Game: Game: Riviera: The Promised Land

-- MAIN APPLICATION
addappid(2891280)
-- Game: addappid(2891280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891281, 1, "1505f12920cd71d2371d4173e5f5746b9c71d824053651945ea03453d64abd0e")
addappid(2891282, 1, "350baf77bde688c99936a20dc7049d0bd9c018f8884f3199c5676b4decd4645b")
