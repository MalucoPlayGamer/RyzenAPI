-- Lua provided by RyzenAPI
-- Game: AppID 1250650

-- MAIN APPLICATION
addappid(1250650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250651, 1, "afa5356481ba8c88343716391d1692b39ad47fc1976c224763ac75179601f367")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
