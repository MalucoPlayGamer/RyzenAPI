-- Lua provided by RyzenAPI
-- Game: addappid(1787550)

-- MAIN APPLICATION
addappid(1787550)
addappid(2832550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787551, 1, "081e1b1579e0a2cdc2af1d352a5013d23cc26932fe24b836179255c902a7c3ba")
