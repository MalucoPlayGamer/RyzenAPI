-- Lua provided by RyzenAPI
-- Game: Game: Eternal Strands

-- MAIN APPLICATION
addappid(1491410)
-- Game: addappid(1491410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491411, 1, "e4195a57e3f14ccbdf4be2fa5c576bb10366f40df6a80f47b31f6d71e918cdc4")
