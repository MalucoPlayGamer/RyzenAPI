-- Lua provided by RyzenAPI
-- Game: Game: AppID 360750

-- MAIN APPLICATION
addappid(360750)
-- Game: addappid(360750)

-- MAIN APP DEPOTS / PACKAGES
addappid(360751, 1, "8e41bcadf773fab45b48770ef6bde057cc9b80a92f31ac06e1ff00b20940c3e0")
