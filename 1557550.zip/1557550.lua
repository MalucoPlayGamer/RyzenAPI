-- Lua provided by RyzenAPI
-- Game: Rogues Adventure

-- MAIN APPLICATION
addappid(1557550)
-- Game: addappid(1557550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557551, 1, "1c4216febdb2f79d2567d0fc740ca4e16afb56087a590ff523048075dcaac8ec")
