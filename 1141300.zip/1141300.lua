-- Lua provided by RyzenAPI
-- Game: Game: Sloth Quest

-- MAIN APPLICATION
addappid(1141300)
-- Game: addappid(1141300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141301, 1, "bcc0577d54fe7cc84a0020f1c1cfb3dac5d22b619eac80490049e0418cb3021b")
