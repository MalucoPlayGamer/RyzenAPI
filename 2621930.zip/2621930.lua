-- 2621930's Lua and Manifest Created by Hubcap Manifest
-- Grim Trials
-- Created: August 25, 2026 at 08:45:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2621930, 1, "25805edfe12f256420055fe96614a870cf04c6455f7466585876ff65869b3afe") -- Grim Trials
addtoken(2621930, "17344050760354626763")
-- MAIN APP DEPOTS
addappid(2621931, 1, "da739e21c084a60740f635556f6c9d4dec8e3fbd2f107c4248699e92783319e9") -- Depot 2621931
setManifestid(2621931, "8297804381299344310", 7158466562)