-- Lua provided by RyzenAPI
-- Game: J-Town: A Visual Novel

-- MAIN APPLICATION
addappid(2413310)
-- Game: addappid(2413310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413316,0,"90f174586296d9afa6d8ec162477fc8dd4ef174ac29d8b6d393b0f71e3c1da56")
addappid(2413317,0,"783693827e2b4503b4e9b3ae769fd27376c9f3cd5b736b3f6573dd531a1d12f1")
