-- Lua provided by RyzenAPI
-- Game: 3746490

-- MAIN APPLICATION
addappid(3746490)
-- Game: addappid(3746490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3746491, 1, "f8e4cb4f18202874619cbe5e5abcd8f5856bbb28de6fdb9c493eb48e594e1714")
