-- Lua provided by RyzenAPI 
-- Game: 3D PUZZLE - Steampunk City
addappid(3746490)
addappid(3746491, 1, "f8e4cb4f18202874619cbe5e5abcd8f5856bbb28de6fdb9c493eb48e594e1714")
