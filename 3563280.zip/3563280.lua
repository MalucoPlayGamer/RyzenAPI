-- Lua provided by RyzenAPI
-- Game: Trainfort Playtest

-- MAIN APPLICATION
addappid(3563280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3563281, 1, "ca672ddb80128dde595c342e7fc5fdc33ce1471759b303e2dfd8f8d3695a9049")
