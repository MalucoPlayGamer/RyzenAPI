-- Lua provided by RyzenAPI
-- Game: Outpath Demo

-- MAIN APPLICATION
addappid(2624480)
-- Game: addappid(2624480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624481, 1, "63bca3c2395614778e69bbb85198f634f08e3bc32e0a18901f82580a89ba9766")
