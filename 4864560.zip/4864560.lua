-- 4864560's Lua and Manifest Created by Hubcap Manifest
-- SCRIBBLE HUNT
-- Created: July 22, 2026 at 21:16:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4864560) -- SCRIBBLE HUNT
-- MAIN APP DEPOTS
addappid(4864561, 1, "52936e781dc452b446084f9979c58367b30ebdd39659bb334a5249676f5df12a") -- Depot 4864561
setManifestid(4864561, "5103723862199454868", 1006984678)
addappid(4864562, 1, "2a0c11e36c791b76f33e77bbce5f473feee44446d71559a7d21f2b5a6836f64b") -- Depot 4864562
setManifestid(4864562, "8374889447146891701", 674550636)