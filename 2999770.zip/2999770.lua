-- Lua provided by RyzenAPI
-- Game: addappid(2999770)

-- MAIN APPLICATION
addappid(2999770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999771, 1, "1b7727cebadb4e6a32308ff34503a8e201a53efe0927d35cc563139bcf1aea52")
