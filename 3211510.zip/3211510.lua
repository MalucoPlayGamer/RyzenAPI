-- Lua provided by RyzenAPI
-- Game: Falling Cube

-- MAIN APPLICATION
addappid(3211510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211511, 1, "10b3e18ba6c44b7628c4b3f02afefa315a059a0d4d494abc132d440eb770ea01")
