-- Lua provided by RyzenAPI
-- Game: Game: KILL la KILL -IF

-- MAIN APPLICATION
addappid(922500)
-- Game: addappid(922500)

-- MAIN APP DEPOTS / PACKAGES
addappid(922501, 1, "851aa4d7733286b8af83cee83db59c1e054e5c637bcd0ac4eed625f1b9ffd29e")
