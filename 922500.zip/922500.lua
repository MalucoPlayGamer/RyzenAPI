-- Lua provided by RyzenAPI
-- Game: KILL la KILL -IF

-- MAIN APPLICATION
addappid(922500)

-- MAIN APP DEPOTS / PACKAGES
addappid(922501, 1, "851aa4d7733286b8af83cee83db59c1e054e5c637bcd0ac4eed625f1b9ffd29e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
