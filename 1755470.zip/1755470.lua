-- Lua provided by RyzenAPI
-- Game: addappid(1755470)

-- MAIN APPLICATION
addappid(1755470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755471, 1, "3c1d8a2e6bd62ce8b8581ba96c0f6657b97a62f5e24e322977687ccb75894cf6")
