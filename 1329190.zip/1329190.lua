-- Lua provided by RyzenAPI 
-- Game: Fear Of The Dark
addappid(1329190)
addappid(1329191, 1, "bb046387d54cbd4bbc020308b62888feb365a1dc70cfd79b9de0e442988f4b7a")
