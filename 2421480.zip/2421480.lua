-- Lua provided by RyzenAPI
-- Game: Poly

-- MAIN APPLICATION
addappid(2421480)
-- Game: addappid(2421480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421481, 1, "ca47391221726d95b0f9d18141773180487a4f719faca0583ce852a89786377b")
addappid(2421482, 1, "08d7374e4495895b6fa813a7dceeb7acd4f7c5e9df4eb89d660bae1ac63d3794")
