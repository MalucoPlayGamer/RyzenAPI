-- Lua provided by RyzenAPI
-- Game: Action: Source Dedicated Server

-- MAIN APPLICATION
addappid(985050)

-- MAIN APP DEPOTS / PACKAGES
addappid(985051, 1, "1b5c4a9ed06c4490242e6e01dc8dd35865a1f92d5b6cd107d8506ef0de45e3fd")
addappid(985052, 1, "6ccb069eab2a5ea9b0eaa732990a94548317725052567785f6e707da46537d92")

