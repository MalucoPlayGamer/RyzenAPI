-- Lua provided by SkyAPI 
-- Game: Apocrypha Playtest
addappid(1528600)
addappid(1528601, 1, "3b5238b3447819f1d4ab48ed8457e2d7485f25e00bb3c95e7a731126e921fb63")
