-- Lua provided by RyzenAPI
-- Game: Apocrypha Playtest

-- MAIN APPLICATION
addappid(1528600)
-- Game: addappid(1528600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528601, 1, "3b5238b3447819f1d4ab48ed8457e2d7485f25e00bb3c95e7a731126e921fb63")
