-- Lua provided by RyzenAPI
-- Game: addappid(2095890)

-- MAIN APPLICATION
addappid(2095890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095891, 1, "b99b9a37d88529afc03084f9110d9fc3b2366b5e55cc3d230d132e377c923e48")
