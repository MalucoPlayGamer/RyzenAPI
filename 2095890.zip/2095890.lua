-- Lua provided by RyzenAPI
-- Game: Black Gunner Wukong: Prologue

-- MAIN APPLICATION
addappid(2095890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095891, 1, "b99b9a37d88529afc03084f9110d9fc3b2366b5e55cc3d230d132e377c923e48")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
