-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Bali

-- MAIN APPLICATION
addappid(2356500)
addappid(2843440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2356501, 1, "3fe4f5b5e35928b2092616b950f076e0a4a489b39bb866803851468eee847b70")

