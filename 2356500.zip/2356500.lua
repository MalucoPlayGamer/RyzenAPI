-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Bali

-- MAIN APPLICATION
addappid(2356500)
addappid(2843440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356501, 1, "3fe4f5b5e35928b2092616b950f076e0a4a489b39bb866803851468eee847b70")

