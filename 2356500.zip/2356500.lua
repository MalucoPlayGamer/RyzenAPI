-- Lua provided by RyzenAPI 
-- Game: Travellin Cats in Bali
addappid(2356500)
addappid(2356501, 1, "3fe4f5b5e35928b2092616b950f076e0a4a489b39bb866803851468eee847b70")
addappid(2843440)
