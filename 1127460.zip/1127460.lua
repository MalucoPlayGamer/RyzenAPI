-- Lua provided by RyzenAPI
-- Game: Game: Mod and Play

-- MAIN APPLICATION
addappid(1127460)
-- Game: addappid(1127460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127461, 1, "e3e013ec12a165cf51f7acef8cc714a19db2c0159df7e182beaed6b2c42dcf51")
