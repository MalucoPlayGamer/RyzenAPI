-- Lua provided by RyzenAPI
-- Game: White Blade

-- MAIN APPLICATION
addappid(2453530)
-- Game: addappid(2453530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453531, 1, "854a3b10d2b61821347c1dd926b579b244030e6886a66717acd9a73638f2877f")
