-- 4138190's Lua and Manifest Created by Hubcap Manifest
-- One Tower Defense
-- Created: July 08, 2026 at 06:08:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4138190, 1, "e161f1b4607a8366e004e0eb567227fe6eac29fcf9e1ddf9117582c38ebfafed") -- One Tower Defense
-- MAIN APP DEPOTS
addappid(4138191, 1, "804f571d84102a8017660251f72a6c3f66ee47deb679d6530ec59289aeacf693") -- Depot 4138191
setManifestid(4138191, "3166443205772244552", 2250320111)
addappid(4138192, 1, "486285b812a85ff7921d986d415f7f7a39782d47157adbe896b2752001baa187") -- Depot 4138192
setManifestid(4138192, "8177675592281724779", 2842774392)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)