-- Lua provided by RyzenAPI
-- Game: addappid(3417180)

-- MAIN APPLICATION
addappid(3417180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417181, 1, "516fcea99a00a16a2254514ef76eed35cd141e552fb5ae3dca5c4d76ba05502d")
