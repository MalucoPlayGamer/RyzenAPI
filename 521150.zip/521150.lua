-- Lua provided by RyzenAPI
-- Game: Another Brick in The Mall

-- MAIN APPLICATION
addappid(521150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(521151, 1, "e8ca0dc6e6ea0ee4f21367724434d17cbe78b4a4d7a6ba1c12d93297c1fba5da")

