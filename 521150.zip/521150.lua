-- Lua provided by SkyAPI 
-- Game: Another Brick in The Mall
addappid(521150)
addappid(521151, 1, "e8ca0dc6e6ea0ee4f21367724434d17cbe78b4a4d7a6ba1c12d93297c1fba5da")
