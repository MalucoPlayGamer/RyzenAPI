-- Lua provided by RyzenAPI
-- Game: Game: Bythzkel Sombréa Playtest

-- MAIN APPLICATION
addappid(3122870)
-- Game: addappid(3122870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122871, 1, "9a1c82cdfaf45e0049ba9ecb581a32e700380003bd7966daadfa0dfd9b9aad3a")
