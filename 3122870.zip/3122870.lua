-- Lua provided by RyzenAPI 
-- Game: Bythzkel Sombréa Playtest
addappid(3122870)
addappid(3122871, 1, "9a1c82cdfaf45e0049ba9ecb581a32e700380003bd7966daadfa0dfd9b9aad3a")
