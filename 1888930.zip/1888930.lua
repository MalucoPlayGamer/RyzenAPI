-- Lua provided by RyzenAPI
-- Game: The Last of Us™ Part I

-- MAIN APPLICATION
addappid(1888930)
addappid(2245260)
addappid(2254450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1888931, 1, "19cd197b4bc7e62551196ec84d00da135a4dedeb5edca50804001bf9e90b6b70")
addappid(1888932, 1, "20a675f9d2a0efd0cf0f8985b2a1c67d5d64e1c2b5aee665d3692969b28b1be4")
addappid(1888933, 1, "035887e659bc052ab1d1801d1665304be7da49992076cd123e25b9bd06a64134")

