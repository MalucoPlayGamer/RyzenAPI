-- Lua provided by RyzenAPI
-- Game: Game: U.N.P.O.C. Vessel of Opportunity

-- MAIN APPLICATION
addappid(3528590)
-- Game: addappid(3528590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3528591, 1, "a4b67fcc84932284610f577e2066dec341f79420be6d473b6f045b4e06b1551d")
