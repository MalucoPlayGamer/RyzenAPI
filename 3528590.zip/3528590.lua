-- Lua provided by RyzenAPI
-- Game: U.N.P.O.C. Vessel of Opportunity

-- MAIN APPLICATION
addappid(3528590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3528591, 1, "a4b67fcc84932284610f577e2066dec341f79420be6d473b6f045b4e06b1551d")

