-- Lua provided by SkyAPI 
-- Game: Little Orpheus
addappid(1558930)
addappid(1558931, 1, "6333d7f5a890e5fb114c2230c12d271b82d68462f3ec693be710765ffaf34972")
addappid(1903260, 0, "920e53ffbbd0e2e20c460fc9313a0ba0b26f7974a309fd7db2d10640d044bcc9")
