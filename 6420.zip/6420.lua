-- Lua provided by RyzenAPI
-- Game: Nexus - The Jupiter Incident

-- MAIN APPLICATION
addappid(6420)

-- MAIN APP DEPOTS / PACKAGES
addappid(6421, 1, "c3103808f804e14637723eb143ea4cb6108d0c8f290038e98564c2cc80829d19")
addappid(6423, 1, "7d50ba84c5cd4e151dcfa8f93e6c365f0883d4814fb2dc983583a7ab65abcca8")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(444760, 0, "f1ecaa85df6d77d5284f7464940dcac2b930c67df0afa765511429360a75c9ff")

