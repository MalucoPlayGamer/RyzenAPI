-- Lua provided by RyzenAPI
-- Game: Havocado: Ragdoll Fighter

-- MAIN APPLICATION
addappid(995050)
-- Game: addappid(995050)

-- MAIN APP DEPOTS / PACKAGES
addappid(995051, 1, "e27093a614db5d9075ba8e80660566664642fc600f034d03df4f8a758e96dd1d")
