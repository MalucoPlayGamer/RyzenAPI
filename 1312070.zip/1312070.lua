-- Lua provided by SkyAPI 
-- Game: Pink Island
addappid(1312070)
addappid(1312071, 1, "2c592951d040a8f4ce989f86f7cca8175f32f2a98d391ed60b08413375b0a42d")
