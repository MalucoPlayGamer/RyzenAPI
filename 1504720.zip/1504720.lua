-- Lua provided by RyzenAPI
-- Game: AppID 1504720

-- MAIN APPLICATION
addappid(1504720)
-- Game: addappid(1504720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504721, 1, "31ca0f9d9b91f02448f30ff93a00470baec16a94ecb33cd66331062bd2290560")
