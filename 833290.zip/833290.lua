-- Lua provided by RyzenAPI
-- Game: 833290

-- MAIN APPLICATION
addappid(833290)
addappid(849150)
-- Game: addappid(833290)

-- MAIN APP DEPOTS / PACKAGES
addappid(833291, 1, "9146d4cbcc7319aad33411124cad7edad618d66fbe55106e1a4940fb8e16650d")
