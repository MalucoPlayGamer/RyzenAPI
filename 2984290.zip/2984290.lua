-- Lua provided by RyzenAPI
-- Game: 2984290

-- MAIN APPLICATION
addappid(2984290)
-- Game: addappid(2984290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984291, 1, "075081ea3fdc14a2e205feba39a00863a9fc4f8d4662337399e4d29747bbdd9f")
addappid(2984293, 1, "eddc0232c99cd7881ec7ef895b2f8b0fcf923639ae7f7a9c118e4520f8de6fce")
