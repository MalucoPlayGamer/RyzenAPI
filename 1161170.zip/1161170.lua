-- Lua provided by RyzenAPI
-- Game: The Rewinder

-- MAIN APPLICATION
addappid(1161170)
addappid(1889432)
addappid(1889433)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161171, 1, "81819a3524d966ab80e641ae9eee0d3cde944eace7a7d9ce2f7afe2b9982d68e")
addappid(1161173, 1, "6c682c271e0a0f4dadddc74ad006bbba9d7e56c9ee0f392610edf3578fce32cb")
addappid(1889430, 0, "9085dc239f31f7ed21668a5f596eeff196b269c3cc1757a70c404d3c08705f4a")
addappid(1889431, 0, "71f40a1e0afb6fcd3ba5023ce15eb5c924ae579f8f624e32219d8d8b471b2f0d")

