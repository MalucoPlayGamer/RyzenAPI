-- Lua provided by RyzenAPI
-- Game: 3161510

-- MAIN APPLICATION
addappid(3161510)
-- Game: addappid(3161510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161511, 1, "2a0b7d008795ae561f5ea820ff87cafb497ac67d18cc476c9dd78122cab8b96a")
