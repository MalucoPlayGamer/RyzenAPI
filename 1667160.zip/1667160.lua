-- Lua provided by RyzenAPI
-- Game: 入替人-ReplaceR-

-- MAIN APPLICATION
addappid(1667160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1667161, 1, "dd0559620840401542474c6a90840d382057a511044f039a37708f770ad9c8d0")

