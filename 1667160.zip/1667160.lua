-- Lua provided by RyzenAPI
-- Game: 入替人-ReplaceR-

-- MAIN APPLICATION
addappid(1667160)
-- Game: addappid(1667160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667161, 1, "dd0559620840401542474c6a90840d382057a511044f039a37708f770ad9c8d0")
