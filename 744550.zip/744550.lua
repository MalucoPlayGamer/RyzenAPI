-- Lua provided by RyzenAPI
-- Game: Tactical Operations

-- MAIN APPLICATION
addappid(744550)

-- MAIN APP DEPOTS / PACKAGES
addappid(744551,0,"8fe258c21236e9afbe4683ef45ee1c917fc2bb0ee0fb927332f94ca98ed91e87")

