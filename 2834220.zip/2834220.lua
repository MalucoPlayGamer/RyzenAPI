-- Lua provided by RyzenAPI
-- Game: Femdom Game World: Stepsister

-- MAIN APPLICATION
addappid(2834220)
-- Game: addappid(2834220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834221, 1, "a35a887789cb906a8a6e8ea9437a2ffc459ce7613c20a4d83818ecc8b3015eeb")
