-- Lua provided by RyzenAPI
-- Game: Tiny Shadows Interwoven Hearts

-- MAIN APPLICATION
addappid(3865150)

