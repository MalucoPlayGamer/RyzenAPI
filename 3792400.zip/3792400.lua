-- Lua provided by RyzenAPI
-- Game: 3792400

-- MAIN APPLICATION
addappid(3792400)
-- Game: addappid(3792400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3792401, 1, "db5fae22b371038d42619188f7c006536a49b9a8ca653d04710be467f59dda14")
