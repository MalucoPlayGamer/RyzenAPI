-- Lua provided by RyzenAPI 
-- Game: Secret of Mana Original Soundtrack
addappid(3792400)
addappid(3792401, 1, "db5fae22b371038d42619188f7c006536a49b9a8ca653d04710be467f59dda14")
