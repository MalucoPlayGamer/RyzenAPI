-- Lua provided by RyzenAPI
-- Game: Monster Run: Downfall of the Empire

-- MAIN APPLICATION
addappid(2394300)
-- Game: addappid(2394300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394301, 1, "13ea77897e7cd032e0b4317a7055d7cdaf1a056c78cf4d9a368ae2f53fd07c4b")
