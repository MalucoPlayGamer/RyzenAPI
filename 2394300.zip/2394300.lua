-- Lua provided by RyzenAPI 
-- Game: Monster Run: Downfall of the Empire
addappid(2394300)
addappid(2394301, 1, "13ea77897e7cd032e0b4317a7055d7cdaf1a056c78cf4d9a368ae2f53fd07c4b")
