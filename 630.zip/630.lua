-- Lua provided by RyzenAPI
-- Game: Game: Alien Swarm

-- MAIN APPLICATION
addappid(630)
-- Game: addappid(630)

-- MAIN APP DEPOTS / PACKAGES
addappid(631, 1, "3a2c1e15d9e982313db3de3a7408bdf3a7b50da0e753e8c440d71dd5c3074e95")
