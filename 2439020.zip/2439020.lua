-- Lua provided by SkyAPI 
-- Game: Hotel Simulator 2024
addappid(2439020)
addappid(2439021, 1, "7d2f4ef83f9608287ef3d9888956a286755c0b6c1d879d76fdf99bb8891ab7d9")
