-- Lua provided by RyzenAPI
-- Game: Game: Hotel Simulator 2024

-- MAIN APPLICATION
addappid(2439020)
-- Game: addappid(2439020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439021, 1, "7d2f4ef83f9608287ef3d9888956a286755c0b6c1d879d76fdf99bb8891ab7d9")
