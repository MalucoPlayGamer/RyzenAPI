-- Lua provided by RyzenAPI
-- Game: addappid(2059580)

-- MAIN APPLICATION
addappid(2059580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059580,0,"664a17c3fd135a37d8fdf92986016ca00dd04b06d49b9e6ea80f6aefd4a6d2b5")
