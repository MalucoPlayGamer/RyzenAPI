-- Lua provided by RyzenAPI
-- Game: addappid(1316460)

-- MAIN APPLICATION
addappid(1316460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316461, 1, "a983b3223f9c09cee5457041ad70dd7ab83b928d2fe6b855c7b1a2ecb9981b90")
