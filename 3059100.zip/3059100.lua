-- Lua provided by RyzenAPI
-- Game: Forgotten house Demo

-- MAIN APPLICATION
addappid(3059100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3059101, 1, "a42804c5c5c03f6d9961f5169132d547df84c300aded768122a14eccb725b416")

