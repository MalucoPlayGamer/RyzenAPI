-- Lua provided by RyzenAPI
-- Game: addappid(435360)

-- MAIN APPLICATION
addappid(435360)
addappid(691520)
addappid(711510)

-- MAIN APP DEPOTS / PACKAGES
addappid(435361, 1, "e7044f8edf7ccb5b5c7dd97b6a018385efc2a8537c045f062194ab2898d4d710")
