-- Lua provided by RyzenAPI
-- Game: FUSER™ - Ini Kamoze - "Here Comes The Hotstepper (Heartical Mix)"

-- MAIN APPLICATION
addappid(1432153)
-- Game: addappid(1432153)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432153,0,"eebb284ad43b373011ea8fe45e1799f385e4da02c307affb39185c38397e965f")
