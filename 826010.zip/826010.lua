-- Lua provided by RyzenAPI
-- Game: JQ: chemistry

-- MAIN APPLICATION
addappid(826010)
-- Game: addappid(826010)

-- MAIN APP DEPOTS / PACKAGES
addappid(826011, 1, "5a9dab3100a8f81bd920952f6586cec93086b714737e44d5ba5dc17c2799c46e")
