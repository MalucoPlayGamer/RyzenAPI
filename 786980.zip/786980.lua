-- Lua provided by RyzenAPI
-- Game: Behind The Beyond

-- MAIN APPLICATION
addappid(786980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(786984,0,"6fed8aa690a2fbeba97813685722bf0eadd9fda9ce08b5afca2192904b9f353c")

