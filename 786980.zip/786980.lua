-- Lua provided by RyzenAPI
-- Game: setManifestid(786984,"2500796790998520395")

-- MAIN APPLICATION
addappid(786980)
-- Game: addappid(786980)

-- MAIN APP DEPOTS / PACKAGES
addappid(786984,0,"6fed8aa690a2fbeba97813685722bf0eadd9fda9ce08b5afca2192904b9f353c")
