-- Lua provided by RyzenAPI
-- Game: Game: Syllogism

-- MAIN APPLICATION
addappid(2740350)
-- Game: addappid(2740350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2740351, 1, "eb629d56556a3f1a0e51354c5cdef1225641dcc730441362479546a812f512da")
