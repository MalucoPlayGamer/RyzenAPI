-- Lua provided by RyzenAPI
-- Game: Hentai Girl Puzzle SCI-FI

-- MAIN APPLICATION
addappid(1117680)
-- Game: addappid(1117680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117682,0,"077d6041be135257be1dc73a6a615d333e99739fb4b9dc601b6a1c7390245796")
