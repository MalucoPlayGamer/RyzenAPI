-- Lua provided by RyzenAPI
-- Game: Song in the Smoke

-- MAIN APPLICATION
addappid(1787810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1787811, 1, "9459c1f673129e69f4ab902e3c861cc2ade9d9c9d9b7affeaf018366cf3593c5")

