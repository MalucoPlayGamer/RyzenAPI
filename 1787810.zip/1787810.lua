-- Lua provided by RyzenAPI
-- Game: Song in the Smoke

-- MAIN APPLICATION
addappid(1787810)
-- Game: addappid(1787810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787811, 1, "9459c1f673129e69f4ab902e3c861cc2ade9d9c9d9b7affeaf018366cf3593c5")
