-- Lua provided by RyzenAPI
-- Game: Painted Legend 2

-- MAIN APPLICATION
addappid(1335340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335341, 1, "ec0ea1d0dcec55764ddce7c5a47b2d3d6626ab2555eed2e5b1b3eb0ed2cf3207")

