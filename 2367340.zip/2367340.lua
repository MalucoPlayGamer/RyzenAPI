-- Lua provided by RyzenAPI
-- Game: 灾变前夜 Playtest

-- MAIN APPLICATION
addappid(2367340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367341, 1, "d242648e001b171a6f9198364be8145532641f76543c40293caaf10a745aab6f")
