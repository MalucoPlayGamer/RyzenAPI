-- Lua provided by RyzenAPI
-- Game: Catch Me If You Can

-- MAIN APPLICATION
addappid(839330)

-- MAIN APP DEPOTS / PACKAGES
addappid(839331, 1, "63a6cd516f75805b5cb04bcf5519bc011df1fd23c7e71f4be3180020e4823e62")
