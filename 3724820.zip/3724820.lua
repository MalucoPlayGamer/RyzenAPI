-- 3724820's Lua and Manifest Created by Hubcap Manifest
-- Data Breach
-- Created: July 22, 2026 at 07:32:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3724820) -- Data Breach
-- MAIN APP DEPOTS
addappid(3724821, 1, "1348686ced6e2537c7ad6c4478959abdbd3bb73e39bd5e9abccc104baeaf2667") -- Depot 3724821
setManifestid(3724821, "6905276468490966682", 4241239750)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)