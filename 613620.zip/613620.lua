-- Lua provided by RyzenAPI
-- Game: AppID 613620

-- MAIN APPLICATION
addappid(613620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(613621, 1, "ccf0ed17a07203da5bf7434d6070837576ba9cb64a38763a517386a2098c005c")

