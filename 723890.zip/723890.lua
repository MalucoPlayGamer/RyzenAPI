-- Lua provided by RyzenAPI
-- Game: AppID 723890

-- MAIN APPLICATION
addappid(723890)
-- Game: addappid(723890)

-- MAIN APP DEPOTS / PACKAGES
addappid(723891, 1, "3cd5f15180ec156dc9de31e4ed50e075a33fef0fa2f953b3fa16621303c0c415")
addappid(723892, 1, "c6a29aabdb22a3f28a1f1028c4a4fa68d371c00f02d56a7f3b0c046517d29aaa")
