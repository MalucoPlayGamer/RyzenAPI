-- Lua provided by RyzenAPI
-- Game: AppID 723890

-- MAIN APPLICATION
addappid(723890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(723891, 1, "3cd5f15180ec156dc9de31e4ed50e075a33fef0fa2f953b3fa16621303c0c415")
addappid(723892, 1, "c6a29aabdb22a3f28a1f1028c4a4fa68d371c00f02d56a7f3b0c046517d29aaa")

