-- Lua provided by RyzenAPI
-- Game: Virtual Heritage Tour: VR Museum Adventure

-- MAIN APPLICATION
addappid(3065740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3065741, 1, "b07cf3f195ae8b468c9a80fc96ab8e62270818a0c8f6b6291e1d939a82c67570")

