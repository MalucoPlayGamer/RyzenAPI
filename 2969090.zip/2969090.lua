-- Lua provided by SkyAPI 
-- Game: Pyramid Game YSBC Premier
addappid(2969090)
addappid(2969091, 1, "e2478ea3a29c9eaf4e99845e2cf51bcd6e2a467bca3d3a99e9b80271805ba86b")
