-- Lua provided by RyzenAPI
-- Game: Sort Them Ducks

-- MAIN APP DEPOTS / PACKAGES
addappid(4992070, 1, "f200c28e18a248936e25af92bcb3a3ab5596923d217f469eb5cac447c04a5330") -- Sort Them Ducks
addappid(4992071, 1, "4607a37d6d00aa9fc2a284c981b1983b05dac8c5519402ebd5aa206f97e0a392") -- Depot 4992071

