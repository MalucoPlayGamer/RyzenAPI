-- 4992070's Lua and Manifest Created by Hubcap Manifest
-- Sort Them Ducks
-- Created: August 13, 2026 at 12:16:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4992070, 1, "f200c28e18a248936e25af92bcb3a3ab5596923d217f469eb5cac447c04a5330") -- Sort Them Ducks
-- MAIN APP DEPOTS
addappid(4992071, 1, "4607a37d6d00aa9fc2a284c981b1983b05dac8c5519402ebd5aa206f97e0a392") -- Depot 4992071
setManifestid(4992071, "460713304560995569", 1532500864)