-- Lua provided by RyzenAPI
-- Game: The Gears: Factory

-- MAIN APPLICATION
addappid(3374140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374141, 1, "a6de069ee74c91ece2f0b9b40624436574c284354432dd9adb79a427b6f3b98f")
