-- Lua provided by RyzenAPI
-- Game: Deep Beyond

-- MAIN APPLICATION
addappid(2841720)
-- Game: addappid(2841720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841721, 1, "7308a4018606c193a26a534017ba3880fc3128e21592876b1fcf53b563030ef0")
