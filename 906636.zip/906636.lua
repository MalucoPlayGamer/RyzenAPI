-- Lua provided by RyzenAPI
-- Game: Mega Man X6 Sound Collection

-- MAIN APPLICATION
addappid(906636)
-- Game: addappid(906636)

-- MAIN APP DEPOTS / PACKAGES
addappid(910120,0,"54d40409a9d1c3d76c6d39bede80a646e67d11277d8ae39e8ed4609c1869f629")
addappid(910121,0,"de5877a5d3780e646770bd2d1e4007435bca49773bb82a5dc42611d06c414dfd")
addappid(910122,0,"6d72bf606a104d0e8c434e20486c4999526cec7908b9bfcba06205bfa2ff2ba6")
