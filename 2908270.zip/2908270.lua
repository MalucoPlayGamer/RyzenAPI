-- Lua provided by RyzenAPI
-- Game: Snackroach

-- MAIN APPLICATION
addappid(2908270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908273,0,"be4fdc3098cf88f12f1db4c05c538014de29e691244cb56e5b6ee3d7893a1289")

