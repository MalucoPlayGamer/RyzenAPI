-- Lua provided by RyzenAPI
-- Game: Game: Sword and Fairy 7 Demo

-- MAIN APPLICATION
addappid(1560490)
-- Game: addappid(1560490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560491, 1, "5120534125919a368cd9195ee35775ed983e67b57bb395b58b664d107731d15e")
