-- Lua provided by RyzenAPI
-- Game: Falco Engine

-- MAIN APPLICATION
addappid(1112440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112441, 1, "4a678f5d99e2f79abc79c57cf4067f362a8ee09a99bf2229816356e05b2df9c7")
