-- Lua provided by RyzenAPI
-- Game: Stolen Realm Survivors

-- MAIN APPLICATION
addappid(3228580)
addappid(4685040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228581,0,"f9205aa6022e460da618e9088f9b94d66363a4cfea34f36d20537cde7f0798de")

