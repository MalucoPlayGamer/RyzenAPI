-- Lua provided by RyzenAPI
-- Game: off

-- MAIN APPLICATION
addappid(2061680)
-- Game: addappid(2061680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061681, 1, "8ecaefc7c632739d13b45354442a7a3cf30e80be380f42d5f7d2e12134fc0b8f")
