-- Lua provided by RyzenAPI 
-- Game: Mind Unleashed
addappid(450740)
addappid(450741, 1, "1244aed19db3941c85293aded8b20df7d6e37712847d2038529e61cf03bd6195")
