-- Lua provided by RyzenAPI
-- Game: Starcube MMO

-- MAIN APPLICATION
addappid(2099770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099771, 1, "99b8dfeb7f56425ca4558d72e37db630ba1aa1bc37053798807f14fa3003d627")
