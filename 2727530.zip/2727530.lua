-- Lua provided by SkyAPI 
-- Game: Your wife
addappid(2727530)
addappid(2727531, 1, "9aa6b83ccf28467ad1ffd756909d78c92aceafa1d8f2280b6907f7edc8f9f86b")
