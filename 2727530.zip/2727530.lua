-- Lua provided by RyzenAPI
-- Game: Your wife

-- MAIN APPLICATION
addappid(2727530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727531, 1, "9aa6b83ccf28467ad1ffd756909d78c92aceafa1d8f2280b6907f7edc8f9f86b")
