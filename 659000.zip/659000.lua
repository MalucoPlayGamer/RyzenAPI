-- Lua provided by SkyAPI 
-- Game: Meta Star
addappid(659000)
addappid(659001, 1, "6618328308b9842dce7cff12a4a824f7b0f431602a7f7ab9d0678378252c973e")
