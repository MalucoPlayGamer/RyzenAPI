-- Lua provided by RyzenAPI
-- Game: addappid(2165800)

-- MAIN APPLICATION
addappid(2165800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165800,0,"dbbece04c21ee06f57377d691827b859d237ee5755cc0199e8d046c9ff142412")
