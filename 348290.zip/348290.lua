-- Lua provided by RyzenAPI
-- Game: Hospital Manager

-- MAIN APPLICATION
addappid(348290)

-- MAIN APP DEPOTS / PACKAGES
addappid(348291, 1, "ba424d1177738aacf462e53a48f84057ff68ae6dce814c408018b7fa34e1250a")
addappid(348292, 1, "1d67c648f264e2550fd2c62bde19d3773c9ab5978ceef7d104058b6c9c34f4df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
