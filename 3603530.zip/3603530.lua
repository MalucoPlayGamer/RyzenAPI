-- Lua provided by RyzenAPI
-- Game: Dungeon with Girl

-- MAIN APPLICATION
addappid(3603530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3603531,0,"225c8309befd5e8daaed0039fd60ae53ee5d069d79b98b05914d519bc2d528a0")

