-- Lua provided by RyzenAPI
-- Game: B-17 Flying Fortress : The Mighty 8th Redux

-- MAIN APPLICATION
addappid(2000800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000801, 1, "64a01aaab41114fbeb9cd91e99b4358f4ce37b5b3d5547cb86dffb7037911ef5")
addappid(2000802, 1, "8b67a5e9af95d957494118dd6b9a5210e6f63467e64dde6c8685519c52d19c95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
