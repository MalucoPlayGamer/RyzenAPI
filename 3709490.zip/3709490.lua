-- Lua provided by RyzenAPI
-- Game: Star Clicker Odyssey

-- MAIN APPLICATION
addappid(3709490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3709491, 1, "468937f2f6b15ac0e77ae9e2a7e68ade4a46717985e822043c8da3477666e455")
