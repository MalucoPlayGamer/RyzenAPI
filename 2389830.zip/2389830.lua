-- Lua provided by RyzenAPI
-- Game: Game: 閃攻機人アスラ - ASURA THE STRIKER -

-- MAIN APPLICATION
addappid(2389830)
-- Game: addappid(2389830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389831, 1, "87d35476e1ed17a5daca4f08275c3201f5899a67f078687df4939c4179238acd")
