-- Lua provided by RyzenAPI
-- Game: Game: Killer Klownz

-- MAIN APPLICATION
addappid(564980)
-- Game: addappid(564980)

-- MAIN APP DEPOTS / PACKAGES
addappid(564981, 1, "9ba86e5a96c73ee80c9e2919a370aad37c674e28549cba1200f6f1fd4a9341ef")
