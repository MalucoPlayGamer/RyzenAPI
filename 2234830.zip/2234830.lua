-- Lua provided by RyzenAPI 
-- Game: AppID 2234830
addappid(2234830)
addappid(2234831, 1, "57db36df11c7f93aaaab1614ccd5630f4f716682d5501ce4ba955c28b318dd7c")
