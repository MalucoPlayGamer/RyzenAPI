-- Lua provided by RyzenAPI 
-- Game: Jumpers' mountain Demo
addappid(3017920)
addappid(3017921, 1, "50f874ef4bf6008f29ae28ef6d715badd6f3f867acece592e751794039bc7715")
