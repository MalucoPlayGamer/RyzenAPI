-- Lua provided by RyzenAPI
-- Game: 1971: Indian Naval Front

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(957950)
addappid(957954)
-- Game: addappid(957950)

-- MAIN APP DEPOTS / PACKAGES
addappid(957953,0,"f18188d40e30a15f6facfbcd88144219fdba57a376bd0206df6602c17b246d59")
