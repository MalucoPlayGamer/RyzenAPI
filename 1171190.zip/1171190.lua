-- Lua provided by RyzenAPI
-- Game: Support pack 1

-- MAIN APPLICATION
addappid(1171190)
addappid(1171191)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171190,0,"e7cff60611bac07923da3d5f9adb2277cd84042cb7fefda4c73906c24ded8179")

