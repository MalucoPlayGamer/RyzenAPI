-- Lua provided by RyzenAPI
-- Game: addappid(365310)

-- MAIN APPLICATION
addappid(365310)

-- MAIN APP DEPOTS / PACKAGES
addappid(365311, 1, "78cc02495fd679fec435354e26553ab3a637c4d75e3f4ca6bb4e9988d799d4a0")
