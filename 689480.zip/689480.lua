-- Lua provided by RyzenAPI
-- Game: Leon's crusade (La cruzada de León)

-- MAIN APPLICATION
addappid(689480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(689481, 1, "adb071b3169c1a5fa9ebdf6daa11dd3c9c36e43ff0ed73ffba24e6a75b100222")
addappid(689482, 1, "a441473a92e650d1094536b899fa1287b0f5adc71e85d4b5b031435f854ee42f")
addappid(689483, 1, "39807da420c013f49774c8f6beb531f93301ba1793788951be9e84ed60128810")
addappid(689484, 1, "ee4e82c369cfd4b442ed2dce53d8c5ad0dbeb98f3a9c69835394aa3e00348be9")
addappid(689485, 1, "9700e0923f2c3a34dd4027e169cfd221648e43c8ce1cb50dd8b7cd8bb33a7ba8")
addappid(689486, 1, "0e501cc4c39b1e57490f32f65df0ad8b04f272566b07a3986c7acc7cf72e74e3")
addappid(690030, 0, "fcd420c1e1cc02fca1f96626ace882bf88212ba52030bb397c213c320955467b")

