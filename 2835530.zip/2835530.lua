-- Lua provided by RyzenAPI
-- Game: addappid(2835530)

-- MAIN APPLICATION
addappid(2835530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835533, 1, "60ff950675278d2d9588f534359afce7b62e02cb4db091bba6083d617cb7f5af")
