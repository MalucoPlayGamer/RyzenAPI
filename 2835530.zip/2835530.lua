-- Lua provided by RyzenAPI
-- Game: This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.

-- MAIN APPLICATION
addappid(2835530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835533, 1, "60ff950675278d2d9588f534359afce7b62e02cb4db091bba6083d617cb7f5af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
