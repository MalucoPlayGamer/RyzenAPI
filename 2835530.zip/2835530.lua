-- Lua provided by RyzenAPI
-- Game: This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.

-- MAIN APPLICATION
addappid(2835530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835533, 1, "60ff950675278d2d9588f534359afce7b62e02cb4db091bba6083d617cb7f5af")

