-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956866)
-- Game: addappid(956866)

-- MAIN APP DEPOTS / PACKAGES
addappid(956866,0,"95bc5ca5bf1492413459aab8be16d5017f08a1b3bb21ce6e1fa9448bb883d541")
