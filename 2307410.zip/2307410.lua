-- Lua provided by RyzenAPI
-- Game: 2307410

-- MAIN APPLICATION
addappid(2307410)
-- Game: addappid(2307410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307411, 1, "9642cc750301f64b0db1e24f2e891f8b2c099879df8de8202cf540f9933d6c5f")
