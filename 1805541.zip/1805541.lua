-- Lua provided by RyzenAPI
-- Game: Expeditions: Rome - Soundtrack

-- MAIN APPLICATION
addappid(1805541)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823580,0,"f749fe8748796c9f897bace8f9526e3d2a33e4895cc98700a1b04ce537fe3dc1")
addappid(1823581,0,"97d91d51247f235719dfedc70aecc75bf00f5b3c2387713513123ef2c2ffd9a1")

