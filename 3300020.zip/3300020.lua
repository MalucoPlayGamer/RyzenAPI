-- Lua provided by RyzenAPI
-- Game: Legend of the Dark War God

-- MAIN APPLICATION
addappid(3300020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3300021, 1, "1fd6acafc12570ae082f94ed44ad7ae819c7736ac50e1498f036ac921c36f963")
