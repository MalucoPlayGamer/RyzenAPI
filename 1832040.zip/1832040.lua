-- Lua provided by RyzenAPI
-- Game: Flintlock: The Siege of Dawn

-- MAIN APPLICATION
addappid(1832040)
addappid(2783020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832041, 1, "c1c5cdc2dfdfd7c552d99cd75df6df269211866648a1602567d62350e7fd4145")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
