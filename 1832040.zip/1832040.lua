-- Lua provided by RyzenAPI
-- Game: Flintlock: The Siege of Dawn

-- MAIN APPLICATION
addappid(1832040)
addappid(2783020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832041, 1, "c1c5cdc2dfdfd7c552d99cd75df6df269211866648a1602567d62350e7fd4145")

