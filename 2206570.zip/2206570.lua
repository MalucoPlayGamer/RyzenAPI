-- Lua provided by RyzenAPI
-- Game: Geolosys

-- MAIN APPLICATION
addappid(2206570)
-- Game: addappid(2206570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206571, 1, "33ab659fec5155c4d624d037fcaecc18915ddc3d44ce27a1bdf12925fbb71adf")
