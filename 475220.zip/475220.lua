-- Lua provided by RyzenAPI
-- Game: Kabitis

-- MAIN APPLICATION
addappid(475220)
addappid(483280)
addappid(533220)
addappid(533221)
addappid(533222)

-- MAIN APP DEPOTS / PACKAGES
addappid(475221, 1, "566fd05318960b63b0a0bea2231bacf6e0b4663c002216ace999236c088e40c3")
addappid(475222, 1, "ea2404a27cc93a64ae3e1ceaa7ba1f3f5bb4e92c3eb2b40b050d3365e6bd1df8")
addappid(475223, 1, "757392d14e7039010c497e7ba88c32258e6f9295cead5a3740abab99b5d85c8d")

