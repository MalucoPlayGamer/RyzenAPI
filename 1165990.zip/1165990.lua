-- Lua provided by RyzenAPI
-- Game: Kiln

-- MAIN APPLICATION
addappid(1165990)
addappid(4415870)
addappid(4415890)
addappid(4543370)
addappid(4662210)
addappid(4662220)
addappid(4662230)
addappid(4713690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165991,0,"3bd95042702642156e86f38e3164ec83dbb5f23be9fbcc5a52c428c95b034739")

