-- Lua provided by RyzenAPI
-- Game: Kiln

-- MAIN APPLICATION
addappid(1165990)
addappid(4415870)
addappid(4415890)
addappid(4543370)
addappid(4662210)
addappid(4662220)
addappid(4662230)
addappid(4713670)
addappid(4713690)
addappid(4832840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1165991,0,"3bd95042702642156e86f38e3164ec83dbb5f23be9fbcc5a52c428c95b034739")

