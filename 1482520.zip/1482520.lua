-- Lua provided by RyzenAPI
-- Game: Space Station 14 Playtest

-- MAIN APPLICATION
addappid(1482520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255461,0,"db1af947ad4cf741af8aa7cc49ca10ab88b513f7c79a3d1ab8b21946ac27655d")
addappid(1482522,0,"201ac8020ff8fd054e3cb4a6be6378648971cd6d06cbfdb3eba1defe6808ff6a")
