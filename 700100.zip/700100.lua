-- Lua provided by RyzenAPI
-- Game: 700100

-- MAIN APPLICATION
addappid(700100)
-- Game: addappid(700100)

-- MAIN APP DEPOTS / PACKAGES
addappid(700101, 1, "c40e63a91d6db571a42b82d51b4e8e8156e380c40150f30b5d51870049e2117e")
