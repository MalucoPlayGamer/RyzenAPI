-- Lua provided by RyzenAPI 
-- Game: AppID 727740
addappid(727740)
addappid(727741, 1, "feda5bcb486e26776f57f7a44226b82343d86f58645fbec89d419810aaba8ddf")
