-- Lua provided by RyzenAPI
-- Game: addappid(727740)

-- MAIN APPLICATION
addappid(727740)

-- MAIN APP DEPOTS / PACKAGES
addappid(727741, 1, "feda5bcb486e26776f57f7a44226b82343d86f58645fbec89d419810aaba8ddf")
