-- Lua provided by RyzenAPI
-- Game: Farming Engine

-- MAIN APPLICATION
addappid(1601100)
-- Game: addappid(1601100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601101, 1, "455c71a83b719f774b7e3288b1dcf4c384a951dfe0f00b9d12af53f44395adbc")
