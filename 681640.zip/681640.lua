-- Lua provided by RyzenAPI
-- Game: World of Contraptions

-- MAIN APPLICATION
addappid(681640)

-- MAIN APP DEPOTS / PACKAGES
addappid(681641,0,"7c87ad52fa78f5a037215af8607993f31ceae86e7201aecee1c2f0396016c09e")

