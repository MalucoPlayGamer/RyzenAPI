-- Lua provided by RyzenAPI
-- Game: Wind Child

-- MAIN APPLICATION
addappid(397090)

-- MAIN APP DEPOTS / PACKAGES
addappid(397091, 1, "41cf51f257f632d96904df33aae7967a58ece8b7bb1b5a0be81cf7f31cb9f87c")
