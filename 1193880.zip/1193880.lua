-- Lua provided by RyzenAPI
-- Game: addappid(1193880)

-- MAIN APPLICATION
addappid(1193880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193881, 1, "09b8a92969ef5b101bd4322e06b5f1d2b565eb38a7ec5195411b63a6f60ad5cb")
