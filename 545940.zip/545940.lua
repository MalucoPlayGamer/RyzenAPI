-- Lua provided by RyzenAPI
-- Game: Hunting Unlimited 2009

-- MAIN APPLICATION
addappid(545940)

-- MAIN APP DEPOTS / PACKAGES
addappid(545941,0,"b4f10ec0aa8f4af5687cd6388e324f249eeedefdfe7de30dca5ee76be6213690")

