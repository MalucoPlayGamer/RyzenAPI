-- Lua provided by RyzenAPI
-- Game: Game: Alien: Rogue Incursion VR

-- MAIN APPLICATION
addappid(1850050)
-- Game: addappid(1850050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850051, 1, "fe58595e434c24887790366689f0296feecad748727c976457fa5720bbe4276d")
