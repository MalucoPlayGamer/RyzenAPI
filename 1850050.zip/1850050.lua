-- Lua provided by RyzenAPI
-- Game: Alien: Rogue Incursion VR

-- MAIN APPLICATION
addappid(1850050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850051, 1, "fe58595e434c24887790366689f0296feecad748727c976457fa5720bbe4276d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3138720)
