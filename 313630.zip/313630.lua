-- Lua provided by RyzenAPI
-- Game: The Solus Project

-- MAIN APPLICATION
addappid(229002)
addappid(313630)

-- MAIN APP DEPOTS / PACKAGES
addappid(313632,0,"0f2e970b6acf3023969d729056408a290b423498327d07e72562c3724e158cdc")

