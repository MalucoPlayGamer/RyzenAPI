-- Lua provided by RyzenAPI 
-- Game: Burst Into
addappid(829080)
addappid(829081, 1, "d9f3e58f3a9ee5b14c9e06222ef5e354ebf6c9fdfcab3e5d43048ae3811f7ac0")
addappid(844120, 0, "be16d18ee9574b351da52dc9fcc371c1b6103ba87094b5e885fa94f98b32adc3")
