-- Lua provided by RyzenAPI
-- Game: GRIP: Combat Racing - Official Soundtrack

-- MAIN APPLICATION
addappid(967400)

-- MAIN APP DEPOTS / PACKAGES
addappid(967400,0,"0677f5f18fa8a1ea616c3ec066643047e9280f66624f535266769d098c577178")
