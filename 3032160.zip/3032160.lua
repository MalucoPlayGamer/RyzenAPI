-- Lua provided by RyzenAPI
-- Game: Puzzle Scenery

-- MAIN APPLICATION
addappid(3032160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032161, 1, "2532edba15eb5df1b2c0a2c0e97cda5fc7cae5c9de3cddc59ed241da44dea4cf")
