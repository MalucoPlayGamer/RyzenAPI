-- Lua provided by RyzenAPI
-- Game: Ninja Run

-- MAIN APPLICATION
addappid(1201250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201251, 1, "85ea7131f0d112d778ab8b53f6f921f55224403d78f59ed59f288eeea0a167e5")
