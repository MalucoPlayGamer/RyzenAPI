-- Lua provided by RyzenAPI
-- Game: Reflection

-- MAIN APPLICATION
addappid(3668080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3668081, 1, "57e8358dc923a421319fe11031a8cbada4031105c13786c9ef4c08b4cd67d05c")

