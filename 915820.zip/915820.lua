-- Lua provided by RyzenAPI
-- Game: setManifestid(915822,"7047341795711905455")

-- MAIN APPLICATION
addappid(915820)
-- Game: addappid(915820)

-- MAIN APP DEPOTS / PACKAGES
addappid(915822,0,"314698c4342802bb1edf286a2ae5d25e6956c12ee61b859b3f0d0a1b09d2da60")
