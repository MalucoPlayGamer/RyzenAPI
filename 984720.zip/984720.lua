-- Lua provided by RyzenAPI
-- Game: Hentai Summer

-- MAIN APPLICATION
addappid(984720)
addappid(984721)

-- MAIN APP DEPOTS / PACKAGES
addappid(984722,0,"6b6ad0ff3c24c4d7655de90c6b3c0735325a7f69b8d3250cec614d03e57e5f06")
