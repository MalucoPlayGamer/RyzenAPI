-- Lua provided by RyzenAPI
-- Game: Sid Meier's Starships

-- MAIN APPLICATION
addappid(282210)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(282211, 1, "4bc768a4b99952d7c933acf0358b80376fcbe69dc8fe4e46c5c0d7ca78332f9b")
addappid(282212, 1, "0340b6e0d8ab3082d7b2ceb7ba926e6c981801016c7e124d050421917df0ff03")

