-- Lua provided by RyzenAPI
-- Game: 2990660

-- MAIN APPLICATION
addappid(2990660)
-- Game: addappid(2990660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990660,0,"bea9eb6b3a48f7882e52925a588ba0392f43c439a487eccaa7bf05acf6243643")
