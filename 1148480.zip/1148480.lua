-- Lua provided by SkyAPI 
-- Game: AppID 1148480
addappid(1148480)
addappid(1148481, 1, "ecd60ae8a5572a755dc7555c417cff8ddb4a856f541ef22a4b3d3131e1309cb3")
