-- Lua provided by RyzenAPI
-- Game: Venus Vacation PRISM - DEAD OR ALIVE Xtreme -

-- MAIN APPLICATION
addappid(3155730)
addappid(3199230)
addappid(3204050)
addappid(3204060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3155731, 1, "f5f3f46814cdec1b4afab690622f6dffb042619e839eb1b08310252f9099e0fc")

