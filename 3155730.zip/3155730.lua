-- Lua provided by RyzenAPI
-- Game: addappid(3155730)

-- MAIN APPLICATION
addappid(3155730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155731, 1, "f5f3f46814cdec1b4afab690622f6dffb042619e839eb1b08310252f9099e0fc")
