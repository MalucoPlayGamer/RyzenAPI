-- Lua provided by SkyAPI 
-- Game: The Astonishing Game
addappid(583190)
addappid(583191, 1, "0a143b4099a39f01b493bd4de6407f7d6f36ef8a26ab03f3618c0819545f27ac")
addappid(583192, 1, "59e9683c82050d1659909708180efbce9e558f7cbd6a2ea1a93fb53eb0ede718")
addappid(583193, 1, "31510c3db3f8738aa44a4f22e424b561d0297188bd453c08dbcd53c6a060e8c8")
