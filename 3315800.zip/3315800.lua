-- Lua provided by RyzenAPI
-- Game: Honey Trap Amnesia

-- MAIN APPLICATION
addappid(3315800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3315804,0,"359890583fcbe1693182e9a1cb8403d49cd73f5d4eeec37bd0ae6a754d2e5b53")
addappid(3315805,0,"44b5c74be4124b3fb03545c13e930f576f79555e0a49dcfea5eaf76e0c76a522")

