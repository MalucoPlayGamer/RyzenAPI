-- Lua provided by RyzenAPI
-- Game: addappid(1163560)

-- MAIN APPLICATION
addappid(1163560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163561, 1, "221a05c0fec23ffc40972c1850ace764d5bdd04a8d39e0e38525e786194e9c15")
