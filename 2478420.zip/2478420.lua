-- Lua provided by RyzenAPI
-- Game: Dualis

-- MAIN APPLICATION
addappid(2478420)
-- Game: addappid(2478420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478421, 1, "e913d302669c33a8a347838a76d88d6437a0ee73824495b7a4cd09319b741304")
