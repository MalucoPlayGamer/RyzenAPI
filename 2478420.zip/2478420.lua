-- Lua provided by RyzenAPI
-- Game: Dualis

-- MAIN APPLICATION
addappid(2478420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2478421, 1, "e913d302669c33a8a347838a76d88d6437a0ee73824495b7a4cd09319b741304")

