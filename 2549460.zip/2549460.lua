-- Lua provided by RyzenAPI
-- Game: 2549460

-- MAIN APPLICATION
addappid(2549460)
-- Game: addappid(2549460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549460,0,"beba38b194c85f4b888fc2d851fc8153f006ba4ef5b2aed95b456d479a6c4434")
