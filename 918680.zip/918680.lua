-- Lua provided by RyzenAPI
-- Game: Castle of Venia

-- MAIN APPLICATION
addappid(918680)

-- MAIN APP DEPOTS / PACKAGES
addappid(918681, 1, "091033db2b0fe299a0c93c0b46675874007ecffc0ed1bd5af77cabf5f1835109")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
