-- Lua provided by RyzenAPI
-- Game: 918680

-- MAIN APPLICATION
addappid(918680)
-- Game: addappid(918680)

-- MAIN APP DEPOTS / PACKAGES
addappid(918681, 1, "091033db2b0fe299a0c93c0b46675874007ecffc0ed1bd5af77cabf5f1835109")
