-- Lua provided by RyzenAPI
-- Game: Little Witch in the Woods

-- MAIN APPLICATION
addappid(1594940)
-- Game: addappid(1594940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594941, 1, "04285d12a3e6cdfeb5449292b53174aa1205b0c8330cc8e237d7b73e8bc2b63a")
addappid(1594942, 1, "8ff465046ee05c80a0b3d61e0eda56f8bee6e774cb297149fe0e6d1590159226")
