-- Lua provided by RyzenAPI
-- Game: WIL

-- MAIN APPLICATION
addappid(717940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(717941, 1, "bf29af6dfc07f5331572f0d375a704b91922371cd73ca51d0368e24a6c3c6936")

