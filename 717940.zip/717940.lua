-- Lua provided by RyzenAPI
-- Game: Game: WIL

-- MAIN APPLICATION
addappid(717940)
-- Game: addappid(717940)

-- MAIN APP DEPOTS / PACKAGES
addappid(717941, 1, "bf29af6dfc07f5331572f0d375a704b91922371cd73ca51d0368e24a6c3c6936")
