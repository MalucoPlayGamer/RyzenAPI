-- Lua provided by RyzenAPI
-- Game: Guardians of the Sanctree

-- MAIN APPLICATION
addappid(2512930)
addappid(3322970)
-- Game: addappid(2512930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512931, 1, "3274780d163f8e52f7da41e15170a17c6238db6dcc320396374a638ac86e039f")
