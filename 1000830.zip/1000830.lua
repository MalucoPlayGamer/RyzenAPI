-- Lua provided by RyzenAPI
-- Game: Gachi Finder 3000

-- MAIN APPLICATION
addappid(1000830)
-- Game: addappid(1000830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000831, 1, "a6904622833b87f678a7891a8999f32fb3a4e1c21b5f3c8697d278a4dc96e464")
