-- Lua provided by RyzenAPI
-- Game: Pool Blitz

-- MAIN APPLICATION
addappid(3942580)
