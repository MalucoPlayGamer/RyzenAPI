-- Lua provided by RyzenAPI
-- Game: 3077180

-- MAIN APPLICATION
addappid(3077180)
-- Game: addappid(3077180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077181, 1, "6f6d78eb93c37b77e12489a7eccdf337fc349374ab0d4b7168a8da16a4e57ef6")
