-- Lua provided by RyzenAPI
-- Game: The Protean Forest

-- MAIN APPLICATION
addappid(2592710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(2592711, 1, "2c925ca8fcc375dab88026f11c753db66c113b8b93bd954613adbf13ec9bdd2e")

