-- Lua provided by RyzenAPI
-- Game: The Protean Forest

-- MAIN APPLICATION
addappid(2592710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2592711, 1, "2c925ca8fcc375dab88026f11c753db66c113b8b93bd954613adbf13ec9bdd2e")

