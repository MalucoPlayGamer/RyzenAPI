-- Lua provided by RyzenAPI
-- Game: Dude, Where Is My Beer?

-- MAIN APPLICATION
addappid(1288760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288763,0,"c75d8775b38488b0767a1bdf5a15d882967f8e2ede4ca421c70f1b5e2b613365")

