-- Lua provided by RyzenAPI
-- Game: AppID 829760

-- MAIN APPLICATION
addappid(829760)

-- MAIN APP DEPOTS / PACKAGES
addappid(829761, 1, "63c3670332882cd73f6083fae853247e0094961d3d2aa2f96f133879f7a5e2bd")
addappid(829762, 1, "189357158d90056215e20c09ce9ade3b06abc4478e1fd34547d53d083d59593a")
addappid(829763, 1, "fbbcce4c4cc188c27b06dc483332973f6329dab0806972906e9c5f0205b46b96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
