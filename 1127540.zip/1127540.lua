-- Lua provided by RyzenAPI
-- Game: addappid(1127540)

-- MAIN APPLICATION
addappid(1127540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127541, 1, "a88dfc318f3884df5d94d623734666b8eb1be851f76c77df6a7237d17faef382")
addappid(1127542, 1, "7178a6f4cb21496eb726504afc332e74ac91318061050bafa0e4dfc87ead7f42")
addappid(1127543, 1, "5ca6309b6eae9fbd72bded69b467dd37df69b55ae319b43ebd99a0db5155cd5d")
