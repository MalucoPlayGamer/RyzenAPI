-- Lua provided by RyzenAPI
-- Game: Eden's Ritter - Paladins of Ecstasy

-- MAIN APPLICATION
addappid(1127540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1127541, 1, "a88dfc318f3884df5d94d623734666b8eb1be851f76c77df6a7237d17faef382")
addappid(1127542, 1, "7178a6f4cb21496eb726504afc332e74ac91318061050bafa0e4dfc87ead7f42")
addappid(1127543, 1, "5ca6309b6eae9fbd72bded69b467dd37df69b55ae319b43ebd99a0db5155cd5d")
