-- Lua provided by RyzenAPI
-- Game: Anime Girls: Highschool of Dead

-- MAIN APPLICATION
addappid(2698540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698541, 1, "9efbdb0bb650a70f692c4b884b89358fd996cd6d528a0fa75b7c4d4391ee34da")
