-- Lua provided by RyzenAPI
-- Game: 2757630

-- MAIN APPLICATION
addappid(2757630)
-- Game: addappid(2757630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757631, 1, "1514a7f1e48c09d3988add6efcc5a3d0965115375bb230b36986fa603518bda2")
