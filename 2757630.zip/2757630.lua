-- 2757630's Lua and Manifest Created by Hubcap Manifest
-- Lonely Knight - Idle Roguelike RPG
-- Created: September 29, 2025 at 22:31:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 16

-- MAIN APPLICATION
addappid(2757630) -- Lonely Knight - Idle Roguelike RPG
-- MAIN APP DEPOTS
addappid(2757631, 1, "1514a7f1e48c09d3988add6efcc5a3d0965115375bb230b36986fa603518bda2") -- Depot 2757631
setManifestid(2757631, "1520850124158536018", 116150937)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2790040) -- Lonely Knight - Starter Pack
addappid(2796300) -- Lonely Knight - Grow Pack
addappid(2796310) -- Lonely Knight - Daily Pass
addappid(2796320) -- Lonely Knight - Key Pass
addappid(2872050) -- Lonely Knight - Mega Pack
addappid(2872060) -- Lonely Knight - Double Mega Pack
addappid(2883810) -- Lonely Knight - Gem Pack
addappid(2883820) -- Lonely Knight - Huge Gem Pack
addappid(2883830) -- Lonely Knight - Rebirth Stone Pack
addappid(2883840) -- Lonely Knight - Huge Rebirth Stone Pack
addappid(2883850) -- Lonely Knight - Soul Stone Pack
addappid(2883860) -- Lonely Knight - Huge Soul Stone Pack
addappid(2883870) -- Lonely Knight - Gold Pack
addappid(2883880) -- Lonely Knight - Huge Gold Pack
addappid(2956240) -- Lonely Knight - Lonely Pass
addappid(2956270) -- Lonely Knight - Daily Rebirth Pass