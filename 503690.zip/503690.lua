-- Lua provided by RyzenAPI
-- Game: Game: Starship Disco

-- MAIN APPLICATION
addappid(503690)
-- Game: addappid(503690)

-- MAIN APP DEPOTS / PACKAGES
addappid(503691, 1, "debc64d4a82d82f3225611d7b3dcd1a3d929ba0f726ad799609b0c7bdddfecd8")
