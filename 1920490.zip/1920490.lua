-- Lua provided by RyzenAPI
-- Game: The Outer Worlds: Spacer's Choice Edition

-- MAIN APPLICATION
addappid(1920490)
-- Game: addappid(1920490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920491, 1, "27a2f143dfdef7f57d92c95cd6fc0682e767921c962694a6c4efa9fc5054fab4")
