-- 4026250's Lua and Manifest Created by Hubcap Manifest
-- Project P.I.T.T.
-- Created: August 19, 2026 at 11:36:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4026250, 1, "9fe3812c1a2c40e01a3e7ccfe8963cf0ed0b214d5a87973ef5f107cd185885c2") -- Project P.I.T.T.
-- MAIN APP DEPOTS
addappid(4026251, 1, "d46af75d3224b0d4a695498e9ecb0af504ed237f4e5c474f65ed8fe8e23bbab7") -- Depot 4026251
setManifestid(4026251, "8711552493721890120", 302667369)
addappid(4026252, 1, "569b1f87350ab87a33e380fe595cee9faffce036a6c48f54ce3d8449db2a8ada") -- Depot 4026252
setManifestid(4026252, "6560532043422166895", 272626204)
addappid(4026253, 1, "abcc8cfd91294cfda902d7fd9c9794ac2a7bbe269a83d6377392a9bcbf4c9cde") -- Depot 4026253
setManifestid(4026253, "3495424084116217877", 174790197)