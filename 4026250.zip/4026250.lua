-- Lua provided by RyzenAPI
-- Game: Project P.I.T.T.

-- MAIN APP DEPOTS / PACKAGES
addappid(4026250, 1, "9fe3812c1a2c40e01a3e7ccfe8963cf0ed0b214d5a87973ef5f107cd185885c2") -- Project P.I.T.T.
addappid(4026251, 1, "d46af75d3224b0d4a695498e9ecb0af504ed237f4e5c474f65ed8fe8e23bbab7") -- Depot 4026251
addappid(4026252, 1, "569b1f87350ab87a33e380fe595cee9faffce036a6c48f54ce3d8449db2a8ada") -- Depot 4026252
addappid(4026253, 1, "abcc8cfd91294cfda902d7fd9c9794ac2a7bbe269a83d6377392a9bcbf4c9cde") -- Depot 4026253

