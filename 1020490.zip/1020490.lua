-- Lua provided by RyzenAPI
-- Game: addappid(1020490)

-- MAIN APPLICATION
addappid(1020490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020491, 1, "97c422c304da4664d53964b17b551905a7c4a33bfc966f5ea8e370a624bd0e72")
