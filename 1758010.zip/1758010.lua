-- Lua provided by RyzenAPI
-- Game: Dungeon Raider

-- MAIN APPLICATION
addappid(1758010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758011, 1, "737af4ee980d981dc0f94940e8cd08c3b6dd4c4f7e0aed50b38aa1ee106f2577")

