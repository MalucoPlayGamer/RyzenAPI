-- Lua provided by RyzenAPI
-- Game: Bootombaa

-- MAIN APPLICATION
addappid(605910)

-- MAIN APP DEPOTS / PACKAGES
addappid(605912,0,"f2d94b5f1b5a5774b7a7eb621a911dfd5070c3112508526bc204a24f40e2dabf")
addtoken(605910,"838548904510832659")

