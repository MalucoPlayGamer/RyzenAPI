-- Lua provided by RyzenAPI
-- Game: 中国式网游 Demo

-- MAIN APPLICATION
addappid(2788770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788771, 1, "84687b12af5675f3123fd646377da0eeced2aebd744e83b46ffb10a001803ec6")

