-- Lua provided by RyzenAPI
-- Game: Game: AppID 2788770

-- MAIN APPLICATION
addappid(2788770)
-- Game: addappid(2788770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788771, 1, "84687b12af5675f3123fd646377da0eeced2aebd744e83b46ffb10a001803ec6")
