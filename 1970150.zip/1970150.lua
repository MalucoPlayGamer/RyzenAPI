-- Lua provided by RyzenAPI 
-- Game: Asterigos: Complete Soundtrack
addappid(1970150)
addappid(1970151, 1, "8d6d3898a0efab9cb74a22b8f989e0c5f3929a41a906bbc357c7b71f93ab260d")
