-- Lua provided by RyzenAPI
-- Game: SafeZoneVR

-- MAIN APPLICATION
addappid(1701090)
addappid(1733210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1701091, 1, "5ee300abcfa7a2447592155f84462b00b24eedd5c8da2ad9c2d11b41758c0a6c")

