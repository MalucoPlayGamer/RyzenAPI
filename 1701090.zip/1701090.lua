-- Lua provided by SkyAPI 
-- Game: SafeZoneVR
addappid(1701090)
addappid(1701091, 1, "5ee300abcfa7a2447592155f84462b00b24eedd5c8da2ad9c2d11b41758c0a6c")
addappid(1733210)
