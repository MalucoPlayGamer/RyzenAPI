-- Lua provided by RyzenAPI
-- Game: 2388850

-- MAIN APPLICATION
addappid(2388850)
-- Game: addappid(2388850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388851, 1, "876819a9df6d53ab95abcffbc1a6791274a565773da2f7e046a449bbc85f4e1d")
