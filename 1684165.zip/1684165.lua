-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9 Empires - Unisex Custom Steel Set

-- MAIN APPLICATION
addappid(1684165)
-- Game: addappid(1684165)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684165,0,"1b15bb541afd0cdf76517bc02dbcf146a954f1da30f1a788cc5ba9c54e93504e")
