-- Lua provided by RyzenAPI
-- Game: Nikopol: Secrets of the Immortals

-- MAIN APPLICATION
addappid(11370)
-- Game: addappid(11370)

-- MAIN APP DEPOTS / PACKAGES
addappid(11371, 1, "ff90e62e5dea683e75ed5ce717693373d58104c937031dbf474e9195b2a74ce2")
addappid(11372, 1, "5f28203b605a265cfad515a3a27e366883103736f4182f1c5976592fe9642a31")
addappid(11373, 1, "47897376c979c27806ed011975484cc9213a8a842f8b081ac8fdd91f8516a8c8")
addappid(11374, 1, "a6367b6d1b577ac743c537c5ea65bb6e00c443ca5ca1ee8cfc5f3e1ab48de4d8")
addappid(11375, 1, "9876fc81555143081be99e49661ec5967156f5af943af7cfa41d6e16bb2d2fcd")
