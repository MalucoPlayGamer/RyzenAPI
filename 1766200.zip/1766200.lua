-- Lua provided by RyzenAPI
-- Game: Apocalich

-- MAIN APPLICATION
addappid(1766200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766201, 1, "08ff4aa1ce62e458aedc15f0eebb97b35441f63bc2eaa6201d636b7a09e03089")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
