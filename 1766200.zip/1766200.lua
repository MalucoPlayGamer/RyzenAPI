-- Lua provided by RyzenAPI
-- Game: addappid(1766200)

-- MAIN APPLICATION
addappid(1766200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766201, 1, "08ff4aa1ce62e458aedc15f0eebb97b35441f63bc2eaa6201d636b7a09e03089")
