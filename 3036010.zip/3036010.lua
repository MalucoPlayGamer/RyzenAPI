-- Lua provided by RyzenAPI
-- Game: Coin Push RPG

-- MAIN APPLICATION
addappid(3036010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036011, 1, "ff480b5702269d75c1c9fa2222a2d2e343a6bed322d45e3836400771939a87a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3804200)
addappid(3872570)
