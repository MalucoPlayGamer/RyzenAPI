-- Lua provided by SkyAPI 
-- Game: Coin Push RPG
addappid(3036010)
addappid(3036011, 1, "ff480b5702269d75c1c9fa2222a2d2e343a6bed322d45e3836400771939a87a9")
