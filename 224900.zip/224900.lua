-- Lua provided by RyzenAPI
-- Game: Iron Sky: Invasion

-- MAIN APPLICATION
addappid(224900)
addappid(234860)
addappid(234863)
addappid(234880)
addappid(234883)
addappid(547430)

-- MAIN APP DEPOTS / PACKAGES
addappid(224901, 1, "0810a302b178f487285d09b918564d5435a7e713d010fc0419acb2892bbf401f")
addappid(224902, 1, "6abde3fc11c59f686107a8ec5f015a3f52d6784b441bd95c6b7a8fd2e0f42d89")
addappid(224904, 1, "e64792c2479df354d8a3b78434a0c9d3254fc79b2102539449b8b2aee23e4230")
addappid(234861, 0, "2dc9aa9763f1aa16c1cda72646a4080dbfeab299e55b85a610b7271d66b2d477")
addappid(234862, 0, "b33b1a79b4baf453175ceaba167290452f961ca7def083bb555d173b82ba72c7")
addappid(234881, 0, "49541e2b67ebdacc67572d595640998319fc69bb207e822086f06a5665b812ba")
addappid(234882, 0, "ac015940a9a2bd53522b3f4744f38f76b7cfbeee55ae1d2125045ee85721224f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4216720)
