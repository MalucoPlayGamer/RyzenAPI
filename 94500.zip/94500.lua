-- Lua provided by RyzenAPI
-- Game: Back to the Future: Ep 2 - Get Tannen!

-- MAIN APPLICATION
addappid(94500)

-- MAIN APP DEPOTS / PACKAGES
addappid(94501, 1, "de581d5b3044a167a2fc2e2f3a0b445782e5eb90e3edf54ab6e2b6259cf6e7ae")
addappid(94502, 1, "768ce4788dc6ef5d7f3ffa5df6e779a6ff2abcfed3c69e30b5ea1298afbbf0bd")
