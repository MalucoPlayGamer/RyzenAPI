-- Lua provided by RyzenAPI
-- Game: Sherman Commander

-- MAIN APPLICATION
addappid(1451050)
-- Game: addappid(1451050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451051, 1, "f091fac73b66814bd58a9b68c680cdd081f686c5d2fb89d0791a99b6cb6c7ba0")
addappid(4464830, 0, "d3151b629c1128a050e2f366535352605d59996300bd1806ab3a764386238782")
