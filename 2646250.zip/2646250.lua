-- Lua provided by RyzenAPI
-- Game: 2646250

-- MAIN APPLICATION
addappid(2646250)
-- Game: addappid(2646250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646251, 1, "a8de565640ef38310178d7ab12b0892bc41e5b99784a74c4da03e51e1d8cfed7")
