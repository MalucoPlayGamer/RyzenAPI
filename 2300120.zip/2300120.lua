-- Lua provided by RyzenAPI
-- Game: Painkiller

-- MAIN APPLICATION
addappid(2300120)
addappid(3751350)
addappid(3751360)
addappid(3751400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300122,0,"564f6b9b6546324d5955cca4017995913ecaa47e114dc895936fa767f514a829")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3751370)
addappid(3751380)
