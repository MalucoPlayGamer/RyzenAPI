-- Lua provided by RyzenAPI
-- Game: addappid(2300120)

-- MAIN APPLICATION
addappid(2300120)
addappid(3751350)
addappid(3751360)
addappid(3751400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300122,0,"564f6b9b6546324d5955cca4017995913ecaa47e114dc895936fa767f514a829")
