-- Lua provided by RyzenAPI
-- Game: AppID 714820

-- MAIN APPLICATION
addappid(714820)

-- MAIN APP DEPOTS / PACKAGES
addappid(714821, 1, "d0cbbca0d0651aa0ac3705d55d85c9466d4b697de7a90f43e4946313640c7e32")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
