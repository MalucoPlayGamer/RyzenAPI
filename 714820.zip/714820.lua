-- Lua provided by RyzenAPI
-- Game: 714820

-- MAIN APPLICATION
addappid(714820)
-- Game: addappid(714820)

-- MAIN APP DEPOTS / PACKAGES
addappid(714821, 1, "d0cbbca0d0651aa0ac3705d55d85c9466d4b697de7a90f43e4946313640c7e32")
