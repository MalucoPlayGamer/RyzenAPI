-- Lua provided by SkyAPI 
-- Game: AppID 714820
addappid(714820)
addappid(714821, 1, "d0cbbca0d0651aa0ac3705d55d85c9466d4b697de7a90f43e4946313640c7e32")
