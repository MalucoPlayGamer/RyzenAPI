-- Lua provided by SkyAPI 
-- Game: The Questing
addappid(1974040)
addappid(1974041, 1, "f92965c90414b377de81df3e3462bb0a6842636945eb2dd9894adca16baf20c1")
