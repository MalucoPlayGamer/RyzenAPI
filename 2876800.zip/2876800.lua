-- Lua provided by RyzenAPI
-- Game: Game: Tenfold Loop

-- MAIN APPLICATION
addappid(2876800)
-- Game: addappid(2876800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2876801, 1, "658bcccd6f0efb9eea7f6f9bd9da03f237a6dcff8048cbbed8713b988e9b3603")
