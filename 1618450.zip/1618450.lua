-- Lua provided by RyzenAPI
-- Game: Anatidae: To The Nest Level

-- MAIN APPLICATION
addappid(1618450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618451, 1, "d5421a82037af31768adb2dce817a017e202aee0913ddacfd811daed740b5124")
