-- Lua provided by RyzenAPI
-- Game: At Eve’s Wake Definitive Edition

-- MAIN APPLICATION
addappid(1395120)
-- Game: addappid(1395120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395121, 1, "66439fd719c54ba2a80b694641de54e5b07f2dada9bba3fb673d89f94ee51c3e")
