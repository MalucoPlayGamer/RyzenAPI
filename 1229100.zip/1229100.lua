-- Lua provided by RyzenAPI
-- Game: GIRLS DEFENCE

-- MAIN APPLICATION
addappid(1229100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229101, 1, "cf5f3b844ccf1d8b1d87ebaef828efaab40ffd49dddf803fe57160b22456911d")

