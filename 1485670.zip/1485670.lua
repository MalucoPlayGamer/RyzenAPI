-- Lua provided by RyzenAPI
-- Game: addappid(1485670)

-- MAIN APPLICATION
addappid(1485670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485671, 1, "5008c87c4be6f2a5b7738f801cdd6fac6e1f69ba5ffbdd78c17260801476a2bb")
