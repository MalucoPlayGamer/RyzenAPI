-- Lua provided by SkyAPI 
-- Game: AppID 1485670
addappid(1485670)
addappid(1485671, 1, "5008c87c4be6f2a5b7738f801cdd6fac6e1f69ba5ffbdd78c17260801476a2bb")
