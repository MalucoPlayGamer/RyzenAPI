-- Lua provided by RyzenAPI
-- Game: Wet Sand

-- MAIN APPLICATION
addappid(2198830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198831, 1, "2d107ad4e8d70111d0198e7991b3ff294c41d0297a6dd54235f126f6d3a576ca")
