-- Lua provided by SkyAPI 
-- Game: Insight
addappid(1602980)
addappid(1602981, 1, "282814662848c2c79c25705f29bad3ddaa5fc8ce859cd192623a8d3043fd218d")
