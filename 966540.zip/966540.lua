-- Lua provided by RyzenAPI 
-- Game: Bedtime Blues
addappid(966540)
addappid(966541, 1, "dcf04a21b705e9a4274596d8fa2081c2b2ea001a441415db47ea94a415245cd1")
