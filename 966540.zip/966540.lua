-- Lua provided by RyzenAPI
-- Game: Bedtime Blues

-- MAIN APPLICATION
addappid(966540)

-- MAIN APP DEPOTS / PACKAGES
addappid(966541, 1, "dcf04a21b705e9a4274596d8fa2081c2b2ea001a441415db47ea94a415245cd1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
