-- Lua provided by RyzenAPI
-- Game: Game: Bedtime Blues

-- MAIN APPLICATION
addappid(966540)
-- Game: addappid(966540)

-- MAIN APP DEPOTS / PACKAGES
addappid(966541, 1, "dcf04a21b705e9a4274596d8fa2081c2b2ea001a441415db47ea94a415245cd1")
