-- Lua provided by SkyAPI 
-- Game: August Walk
addappid(2418820)
addappid(2418821, 1, "94bd7956209467f3a7c1121d452829cb5b11f6ee2410770dbef9e68071a5f27a")
