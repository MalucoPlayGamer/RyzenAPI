-- Lua provided by RyzenAPI
-- Game: August Walk

-- MAIN APPLICATION
addappid(2418820)
-- Game: addappid(2418820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418821, 1, "94bd7956209467f3a7c1121d452829cb5b11f6ee2410770dbef9e68071a5f27a")
