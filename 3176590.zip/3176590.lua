-- Lua provided by RyzenAPI
-- Game: Game: Witch's Dungeon Demo

-- MAIN APPLICATION
addappid(3176590)
-- Game: addappid(3176590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176591, 1, "75791231f3d9c11123e21c18f98558baaa914bb32a62d3fbafec9749cc42b548")
