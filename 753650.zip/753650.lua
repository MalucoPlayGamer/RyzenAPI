-- Lua provided by RyzenAPI
-- Game: addappid(753650)

-- MAIN APPLICATION
addappid(753650)

-- MAIN APP DEPOTS / PACKAGES
addappid(753651, 1, "1c92c17e8d55c9e13845ae0587a9314cec99ae02d85a42fd865fa2138ca171d6")
