-- Lua provided by RyzenAPI
-- Game: Stellarcraft

-- MAIN APPLICATION
addappid(3189820)
