-- Lua provided by RyzenAPI
-- Game: 2359150

-- MAIN APPLICATION
addappid(2359150)
-- Game: addappid(2359150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359151, 1, "ade1bc7e0f37d71d4f9744ed613cd0a32f4a5be160417b2f26d2d56a99faefc0")
