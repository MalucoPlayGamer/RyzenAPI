-- Lua provided by RyzenAPI
-- Game: addappid(933940)

-- MAIN APPLICATION
addappid(933940)

-- MAIN APP DEPOTS / PACKAGES
addappid(933941, 1, "ff002fd47a148e7aad24c26c1b91ee8bf246a97b1b743f1cb2ca7404eb9a0b61")
addappid(933942, 1, "a8c32c47ab77c83ef059e60f05168390aaf5f2b4b5f283d58e091d2b4119a597")
