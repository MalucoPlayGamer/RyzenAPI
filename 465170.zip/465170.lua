-- Lua provided by RyzenAPI
-- Game: addappid(465170)

-- MAIN APPLICATION
addappid(465170)

-- MAIN APP DEPOTS / PACKAGES
addappid(465171, 1, "36ecf724bd15068ee8bfc7d7d43ec19d3e9cbce1123d1fd7ff0596ba0341e45a")
addappid(465172, 1, "59fb3025daeae40f02809771fc5b923e558a260a4f9e7838bcbbcbb66ac3938b")
addappid(465173, 1, "4e2e51f683e4afcd0ed71372800fe5c9780246945ed4db60b1cab9f1bb24e54d")
