-- Lua provided by RyzenAPI
-- Game: Tactics Ogre: Reborn

-- MAIN APPLICATION
addappid(1451090)
addappid(2087040)
addappid(2087050)
addappid(2087060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1451091, 1, "05d42e1703b05e7a865e15447318d8cb35bc0b30f9221f1150ee53f7cb434096")

