-- Lua provided by RyzenAPI
-- Game: Tactics Ogre: Reborn

-- MAIN APPLICATION
addappid(1451090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451091, 1, "05d42e1703b05e7a865e15447318d8cb35bc0b30f9221f1150ee53f7cb434096")
