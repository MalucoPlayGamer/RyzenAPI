-- Lua provided by RyzenAPI
-- Game: 380810

-- MAIN APPLICATION
addappid(380810)
-- Game: addappid(380810)

-- MAIN APP DEPOTS / PACKAGES
addappid(380811, 1, "5afb149b74c863b975841298becd697728f224ab1f3e89dd8cc2d516c32fb509")
