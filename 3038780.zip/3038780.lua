-- Lua provided by SkyAPI 
-- Game: AppID 3038780
addappid(3038780)
addappid(3038781, 1, "0afcb61abf800f75193c9922399863f2af28e72085ee3367596dab27c5d06d40")
