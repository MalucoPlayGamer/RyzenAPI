-- Lua provided by RyzenAPI
-- Game: 3038780

-- MAIN APPLICATION
addappid(3038780)
-- Game: addappid(3038780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038781, 1, "0afcb61abf800f75193c9922399863f2af28e72085ee3367596dab27c5d06d40")
