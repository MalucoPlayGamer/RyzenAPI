-- Lua provided by RyzenAPI
-- Game: Game: Sweet Transit

-- MAIN APPLICATION
addappid(1612770)
-- Game: addappid(1612770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612771, 1, "e52667e4be892f84d8f6daff2f0e49027e2c3b961a28c725d450d2ade426810d")
addappid(3104710, 0, "ff834bf9a291298907517e08837ffff5433a8e774035d4af9ad6b8f7da6d026e")
