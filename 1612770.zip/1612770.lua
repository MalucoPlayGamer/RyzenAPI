-- Lua provided by RyzenAPI
-- Game: Sweet Transit

-- MAIN APPLICATION
addappid(1612770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612771, 1, "e52667e4be892f84d8f6daff2f0e49027e2c3b961a28c725d450d2ade426810d")
addappid(3104710, 0, "ff834bf9a291298907517e08837ffff5433a8e774035d4af9ad6b8f7da6d026e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
