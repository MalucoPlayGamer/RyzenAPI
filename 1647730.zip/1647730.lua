-- Lua provided by RyzenAPI 
-- Game: Zool Redimensioned
addappid(1647730)
addappid(1647731, 1, "307d03c3f4d606f246daa9e3cb7f01d10db89c0abd325094f7436d9123ba49d6")
