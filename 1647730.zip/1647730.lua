-- Lua provided by RyzenAPI
-- Game: Zool Redimensioned

-- MAIN APPLICATION
addappid(1647730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1647731, 1, "307d03c3f4d606f246daa9e3cb7f01d10db89c0abd325094f7436d9123ba49d6")

