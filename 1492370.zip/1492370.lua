-- Lua provided by RyzenAPI
-- Game: 1492370

-- MAIN APPLICATION
addappid(1492370)
-- Game: addappid(1492370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492371, 1, "95502b10c85a07c3d9ff2c47ba03bc30cde3f87105007acaf748b20f0e8707fc")
