-- Lua provided by RyzenAPI
-- Game: 794640

-- MAIN APPLICATION
addappid(794640)
addappid(794641)
addappid(794643)
addappid(794644)
-- Game: addappid(794640)

-- MAIN APP DEPOTS / PACKAGES
addappid(794642,0,"bceb65027262ffebefbdaf27eea23264ebe4b9f4c6e503fa5b043cac6a4aa21c")
