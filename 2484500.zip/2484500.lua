-- Lua provided by RyzenAPI
-- Game: Ontotis

-- MAIN APPLICATION
addappid(2484500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484501, 1, "f350477b40ef7be9837b76eca5c5a4c26235a0bbb1f626b337c7d7f508c9f8dc")

