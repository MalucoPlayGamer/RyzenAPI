-- Lua provided by RyzenAPI
-- Game: Ontotis

-- MAIN APPLICATION
addappid(2484500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484501, 1, "f350477b40ef7be9837b76eca5c5a4c26235a0bbb1f626b337c7d7f508c9f8dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
