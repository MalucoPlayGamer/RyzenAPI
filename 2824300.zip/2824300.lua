-- Lua provided by RyzenAPI
-- Game: Miss Neko: Pirates - Free Bonus Content

-- MAIN APPLICATION
addappid(2824300)
-- Game: addappid(2824300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824300,0,"ac55798aaf5fb0397a7f0f5a16c3602b751cd7ecce5767dae51f55263d099d14")
