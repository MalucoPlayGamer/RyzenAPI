-- Lua provided by RyzenAPI
-- Game: 100 hidden aliens

-- MAIN APPLICATION
addappid(1493300)
-- Game: addappid(1493300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493301, 1, "1e06b269c15d0470edd678398a89f23161b7cabc170dcb3ae8aeae647954e1d8")
