-- Lua provided by RyzenAPI
-- Game: addappid(1880490)

-- MAIN APPLICATION
addappid(1880490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880491, 1, "7c37594b731d1788de16dd5aa2ca085cef95feeabe4ed3f7609f96d3da5838bc")
