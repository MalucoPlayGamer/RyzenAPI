-- Lua provided by RyzenAPI
-- Game: Summer Crush

-- MAIN APPLICATION
addappid(2163060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163061, 1, "dfac7232179517a6bf02a2c313439355722499a0dbe842cba6098673dfa884b9")

