-- Lua provided by RyzenAPI
-- Game: Paladin Duty - Knights and Blades

-- MAIN APPLICATION
addappid(800310)

-- MAIN APP DEPOTS / PACKAGES
addappid(800311, 1, "58fc3322e1cee22d87fd0f91f0a6e7d6d8ee8390ba486a08acf733b00917860c")

