-- Lua provided by RyzenAPI
-- Game: Dead Secret Circle

-- MAIN APPLICATION
addappid(671920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(671921,0,"f3ff89ca9edf4105356ffbe3944aece3658f0793bc5cfc8c0552f02207734c30")
addappid(671923,0,"a11f0c67e0dcfa924cccd654d0203612456e2035f9d2fffa62f332de93e7a8a3")
addappid(671924,0,"78a6470969a135fe23a3ca17e5fca464840292f57ca2a83c9919f89779bb40a0")

