-- Lua provided by RyzenAPI
-- Game: Out There: Ω Edition - Soundtrack

-- MAIN APPLICATION
addappid(357040)
-- Game: addappid(357040)

-- MAIN APP DEPOTS / PACKAGES
addappid(357040,0,"35818591df4dfb1a29e19efcd430b3ef82c57f36625f11fed50a8acf39ee7ef7")
