-- Lua provided by RyzenAPI 
-- Game: AppID 1360080
addappid(1360080)
addappid(1360081, 1, "eeefc30a37bcf1fc6668c8f230b1ce8c080fa90f387e44836f035c8ad5bd7247")
