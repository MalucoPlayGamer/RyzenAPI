-- Lua provided by RyzenAPI
-- Game: addappid(3244670)

-- MAIN APPLICATION
addappid(3244670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244671, 1, "3ba4ea6202de099e57e5ee5d2bca860dc640202e5139fda281bf26f74ffa0776")
