-- Lua provided by RyzenAPI
-- Game: Omega Quintet

-- MAIN APPLICATION
addappid(683280)
addappid(714331)
addappid(714332)
addappid(714333)
addappid(714334)
addappid(714335)
addappid(714336)
addappid(714337)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(683281, 1, "a8b93525937571bdd6f336114a4b38e481489a1163ee886d0de2c5418d8efeec")

