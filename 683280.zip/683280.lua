-- Lua provided by SkyAPI 
-- Game: Omega Quintet
addappid(683280)
addappid(683281, 1, "a8b93525937571bdd6f336114a4b38e481489a1163ee886d0de2c5418d8efeec")
