-- Lua provided by RyzenAPI
-- Game: Omega Quintet

-- MAIN APPLICATION
addappid(683280)
-- Game: addappid(683280)

-- MAIN APP DEPOTS / PACKAGES
addappid(683281, 1, "a8b93525937571bdd6f336114a4b38e481489a1163ee886d0de2c5418d8efeec")
