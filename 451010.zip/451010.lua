-- Lua provided by RyzenAPI
-- Game: addappid(451010)

-- MAIN APPLICATION
addappid(451010)

-- MAIN APP DEPOTS / PACKAGES
addappid(451011, 1, "e1992c190fc5933b61de6ecb19a58e4cdb261e935e5acfa5bd05a3919d5dc4ea")
