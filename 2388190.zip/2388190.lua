-- Lua provided by RyzenAPI
-- Game: Rite as Rain

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2388190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388192,0,"d456ab430517619c5536c865ccc31ee950cbb2d7b8a8186b5d598926ff8e0453")
