-- Lua provided by RyzenAPI
-- Game: Winter Ember - Digital Comic: Issues 0-4

-- MAIN APPLICATION
addappid(1954190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954190,0,"8cd257bc64718513829549a49c3c0474f4e0ca022ced2f731c1c3811b7a06081")

