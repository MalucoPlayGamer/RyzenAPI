-- Lua provided by RyzenAPI
-- Game: Mystery Of Dust

-- MAIN APPLICATION
addappid(1656840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656842,0,"1a05e7f9d644f35baa391a75363747ce029d5a6db2a8b59f0b7ab5c9d7aef6a5")
