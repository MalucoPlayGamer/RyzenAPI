-- Lua provided by RyzenAPI
-- Game: Tribal Hunter

-- MAIN APPLICATION
addappid(1379870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379871, 1, "39cf1f56fc2d5a8115950f27e89bdfbc1b0b69c23f10fba64ca8ff189c20d93b")
