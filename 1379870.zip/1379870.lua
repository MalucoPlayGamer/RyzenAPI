-- Lua provided by RyzenAPI 
-- Game: Tribal Hunter
addappid(1379870)
addappid(1379871, 1, "39cf1f56fc2d5a8115950f27e89bdfbc1b0b69c23f10fba64ca8ff189c20d93b")
