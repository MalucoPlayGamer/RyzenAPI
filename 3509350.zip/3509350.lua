-- Lua provided by RyzenAPI
-- Game: Game: AppID 3509350

-- MAIN APPLICATION
addappid(3509350)
-- Game: addappid(3509350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509351, 1, "62649c9470d5d41a23f1a572d35db43d94b721616e748ceb74aae715b0b67bbf")
