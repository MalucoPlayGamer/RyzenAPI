-- Lua provided by RyzenAPI
-- Game: SENRAN KAGURA SHINOVI VERSUS

-- MAIN APPLICATION
addappid(411830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(411831, 1, "c646b288f6ac69d87186d64ef36d17afcfc40175ec5bb2e931d75690e8cdafca")

