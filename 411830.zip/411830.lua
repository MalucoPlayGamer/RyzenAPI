-- Lua provided by RyzenAPI
-- Game: Game: AppID 411830

-- MAIN APPLICATION
addappid(411830)
-- Game: addappid(411830)

-- MAIN APP DEPOTS / PACKAGES
addappid(411831, 1, "c646b288f6ac69d87186d64ef36d17afcfc40175ec5bb2e931d75690e8cdafca")
