-- Lua provided by RyzenAPI
-- Game: NASCAR 21: Ignition

-- MAIN APPLICATION
addappid(1439300)
addappid(1722691)
addappid(1722692)
addappid(1722693)
addappid(1722694)
addappid(1722695)
addappid(1741700)
addappid(2088470)
addappid(2088471)
addappid(2088472)
addappid(2088473)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1439301, 1, "92f2f9566c8e5a335dcf88e661b917aa87c2e6fd06b179f12783cddf01a15c78")

