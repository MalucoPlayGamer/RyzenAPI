-- Lua provided by RyzenAPI
-- Game: Game: NASCAR 21: Ignition

-- MAIN APPLICATION
addappid(1439300)
-- Game: addappid(1439300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439301, 1, "92f2f9566c8e5a335dcf88e661b917aa87c2e6fd06b179f12783cddf01a15c78")
