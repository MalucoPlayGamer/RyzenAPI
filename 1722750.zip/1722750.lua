-- Lua provided by SkyAPI 
-- Game: Halt The Heist!
addappid(1722750)
addappid(1722751, 1, "2e20b3d05958b402d075e3ef0c67c16cd91342b8a10f0f5faef18f6a4b16e310")
addappid(2109560)
