-- Lua provided by RyzenAPI
-- Game: Halt The Heist!

-- MAIN APPLICATION
addappid(1722750)
addappid(2109560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722751, 1, "2e20b3d05958b402d075e3ef0c67c16cd91342b8a10f0f5faef18f6a4b16e310")

