-- Lua provided by RyzenAPI
-- Game: Choice of Rebels: Uprising

-- MAIN APPLICATION
addappid(748890)

-- MAIN APP DEPOTS / PACKAGES
addappid(748891, 1, "49ab6cbdaedad89c4cbd2de0c45c487df96904839a4a4c07f5a54b13d438861d")
