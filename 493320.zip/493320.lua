-- Lua provided by RyzenAPI
-- Game: Killing Time (Classic)

-- MAIN APPLICATION
addappid(493320)
-- Game: addappid(493320)

-- MAIN APP DEPOTS / PACKAGES
addappid(493321, 1, "660985f9e1666c98648b5f1da18eb7f40ff1085d63472e7dc05de7eda1f1be6c")
