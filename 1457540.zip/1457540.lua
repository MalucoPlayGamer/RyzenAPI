-- Lua provided by RyzenAPI
-- Game: addappid(1457540)

-- MAIN APPLICATION
addappid(1457540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457541, 1, "744a6a2ba201b385dfeb91898fc09af9d6c8cf7aad21230f244ceaf9c9ab315d")
