-- Lua provided by RyzenAPI
-- Game: TCG Multiplayer Card Shop Simulator

-- MAIN APPLICATION
addappid(3354260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354261, 1, "c3b75aa4d6c62adc59330e193b292122b951a414195e1ebc59111ba1834e6962")

