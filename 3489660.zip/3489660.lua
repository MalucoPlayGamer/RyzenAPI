-- Lua provided by RyzenAPI
-- Game: Game: AppID 3489660

-- MAIN APPLICATION
addappid(3489660)
-- Game: addappid(3489660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489661, 1, "913902381c03455b7bcfea2c4df46c30c378a0521958864956c5bdec710e86ea")
