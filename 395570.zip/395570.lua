-- Lua provided by RyzenAPI
-- Game: AppID 395570

-- MAIN APPLICATION
addappid(395570)

-- MAIN APP DEPOTS / PACKAGES
addappid(395571, 1, "9e9dd51aa36e492fb9ff09bbc29b2d03ed18f03ae0c79bd3f2ecf271b29ce696")
addappid(395572, 1, "edb5d379d46c72dd21ed3316821a833aec6e2c2c40e8ef1361994d83b43bc4f4")
addappid(395573, 1, "1f4ffca44a3641d17b24e6e9aeaa8ed675f4c729c97ef76e3175d55b99d82771")
addappid(395574, 1, "b38784582becbf6cd57ec044a4d67f24c2a55f5c816fdda4ddfc7c34bfb6dd97")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
