-- Lua provided by RyzenAPI 
-- Game: AppID 395570
addappid(395570)
addappid(395571, 1, "9e9dd51aa36e492fb9ff09bbc29b2d03ed18f03ae0c79bd3f2ecf271b29ce696")
addappid(395572, 1, "edb5d379d46c72dd21ed3316821a833aec6e2c2c40e8ef1361994d83b43bc4f4")
addappid(395573, 1, "1f4ffca44a3641d17b24e6e9aeaa8ed675f4c729c97ef76e3175d55b99d82771")
addappid(395574, 1, "b38784582becbf6cd57ec044a4d67f24c2a55f5c816fdda4ddfc7c34bfb6dd97")
