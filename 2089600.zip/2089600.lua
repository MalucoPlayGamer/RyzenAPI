-- Lua provided by SkyAPI 
-- Game: Urban Myth Dissolution Center
addappid(2089600)
addappid(2089601, 1, "54b3d5d488cbc9bad1702a168dff9c8474bff9a9b8007db6c27b35ece57be062")
