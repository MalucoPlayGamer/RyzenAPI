-- Lua provided by RyzenAPI
-- Game: AppID 2180520

-- MAIN APPLICATION
addappid(2180520)
-- Game: addappid(2180520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180521, 1, "6ea8d814caaa052ae245e5525ddcbe799f4d8f32c6d504754b1e4d2ce8787efa")
