-- Lua provided by RyzenAPI
-- Game: Outlaws + A Handful of Missions (Classic, 1997)

-- MAIN APPLICATION
addappid(559620)

-- MAIN APP DEPOTS / PACKAGES
addappid(559621, 1, "0b58ae3fd5dcb7a6c3ba08dbd176d3dc4c24b94b75cea587b1feb621e175db47")
