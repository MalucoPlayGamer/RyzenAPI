-- Lua provided by RyzenAPI
-- Game: addappid(559620)

-- MAIN APPLICATION
addappid(559620)

-- MAIN APP DEPOTS / PACKAGES
addappid(559621, 1, "0b58ae3fd5dcb7a6c3ba08dbd176d3dc4c24b94b75cea587b1feb621e175db47")
