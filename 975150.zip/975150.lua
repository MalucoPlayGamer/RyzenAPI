-- Lua provided by RyzenAPI
-- Game: Resolutiion

-- MAIN APPLICATION
addappid(975150)

-- MAIN APP DEPOTS / PACKAGES
addappid(975151, 1, "bc03dcda660b9cdee1500d59983da1dc9ff266d2aaf46a025d7f77aee724b862")
addappid(975152, 1, "f0bf8a414d8b272f4bf579295dc96927782e6dd77a6420838fb7657882bf223b")
addappid(975153, 1, "de26f7667c6c8ae9b7daa0ce1667209a2b287a2bf8527fd73e917d71e224eaae")

