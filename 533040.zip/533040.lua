-- Lua provided by RyzenAPI
-- Game: Dark Parables: The Thief and the Tinderbox Collector's Edition

-- MAIN APPLICATION
addappid(533040)

-- MAIN APP DEPOTS / PACKAGES
addappid(533041, 1, "d1656b951cd16374c605299df8f88e608f32da681c53674ea400635662f856d3")

