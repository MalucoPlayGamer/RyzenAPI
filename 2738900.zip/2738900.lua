-- Lua provided by RyzenAPI
-- Game: REAL ESTATE Simulator - FROM BUM TO MILLIONAIRE

-- MAIN APPLICATION
addappid(2738900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738901, 1, "5eaddb5380aace58757b17aa7f06de248c9cc52edf69eca7fa34edc35077108b")
