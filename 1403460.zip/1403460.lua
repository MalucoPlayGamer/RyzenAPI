-- Lua provided by RyzenAPI
-- Game: Flavortown

-- MAIN APPLICATION
addappid(1403460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403461, 1, "727eb1a138c2c3da73e897147b97f0b66e669c9eebefc52196fe61303aac20a7")
