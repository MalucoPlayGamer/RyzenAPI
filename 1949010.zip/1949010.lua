-- Lua provided by RyzenAPI
-- Game: Room 301 NO.6

-- MAIN APPLICATION
addappid(1949010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949011, 1, "34beb74af3b770950da2a5a92db4da41c3bbf180171ae46179ea435916393db7")

