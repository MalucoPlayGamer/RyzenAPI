-- Lua provided by RyzenAPI
-- Game: AppID 2509090

-- MAIN APPLICATION
addappid(2509090)
-- Game: addappid(2509090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509091, 1, "1020e0c923a09a052bbde82a7ca5e3024ef6f27842918fe5b271721e5ef3b036")
