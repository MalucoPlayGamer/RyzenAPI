-- Lua provided by RyzenAPI
-- Game: Hitler Waifu

-- MAIN APPLICATION
addappid(2435960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435961, 1, "3e1f7c4ad85b90921e5a180b6f3ba5c652d834e5d6fa2b472b39b21ce1c24856")
