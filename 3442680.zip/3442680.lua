-- 3442680's Lua and Manifest Created by Hubcap Manifest
-- Deep Water
-- Created: August 11, 2026 at 23:24:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3442680) -- Deep Water
-- MAIN APP DEPOTS
addappid(3442681, 1, "7f2f87424709945b180bacd6961a25852f02393b6f49abda14a41396427573a7") -- Depot 3442681
setManifestid(3442681, "348254505587447099", 521857200)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)