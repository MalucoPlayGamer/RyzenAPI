-- Lua provided by RyzenAPI
-- Game: Deep Water

-- MAIN APPLICATION
addappid(3442680) -- Deep Water

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3442681, 1, "7f2f87424709945b180bacd6961a25852f02393b6f49abda14a41396427573a7") -- Depot 3442681

