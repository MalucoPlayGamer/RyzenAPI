-- Lua provided by RyzenAPI
-- Game: No More Money

-- MAIN APPLICATION
addappid(2246300)
addappid(2247390)
addappid(2254960)
addappid(3126100)
addappid(4815030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246301, 1, "6e00c4062ad757ac2d9ed985d08a335494cd024c1cee3a53b71283ecf51134bb")
