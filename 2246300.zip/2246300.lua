-- Lua provided by RyzenAPI
-- Game: AppID 2246300

-- MAIN APPLICATION
addappid(2246300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246301, 1, "6e00c4062ad757ac2d9ed985d08a335494cd024c1cee3a53b71283ecf51134bb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2247390)
addappid(2254960)
addappid(3126100)
addappid(4815030)
