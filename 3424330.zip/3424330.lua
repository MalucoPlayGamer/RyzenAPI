-- Lua provided by SkyAPI 
-- Game: AppID 3424330
addappid(3424330)
addappid(3424331, 1, "bd8d48b280ae2bb941a5778f90eeafc74685b5d26a82d9953794e195e12224f0")
