-- Lua provided by RyzenAPI
-- Game: addappid(2642570)

-- MAIN APPLICATION
addappid(2642570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642571, 1, "ed55ccabb537c2a37b6b9d448652b2ee3a5c3adc955d1ab54da99690f5375b0d")
