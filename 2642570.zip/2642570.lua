-- Lua provided by SkyAPI 
-- Game: Pinball Storm: Lokanta
addappid(2642570)
addappid(2642571, 1, "ed55ccabb537c2a37b6b9d448652b2ee3a5c3adc955d1ab54da99690f5375b0d")
