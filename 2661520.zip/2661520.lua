-- Lua provided by RyzenAPI
-- Game: There's No Easter Eggs

-- MAIN APPLICATION
addappid(2661520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661521, 1, "ad9956d7093905b315f50dc472ec0edddbe1f45318dc07a6163dff3f77b9fc17")

