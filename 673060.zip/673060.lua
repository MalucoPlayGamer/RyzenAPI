-- Lua provided by RyzenAPI
-- Game: Floor Plan VR

-- MAIN APPLICATION
addappid(673060)

-- MAIN APP DEPOTS / PACKAGES
addappid(673061, 1, "bbc019cdd25a97255e9c4f4214e04a79455f461de448694fdb15ca494b8cd92d")

