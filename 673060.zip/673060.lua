-- Lua provided by RyzenAPI 
-- Game: AppID 673060
addappid(673060)
addappid(673061, 1, "bbc019cdd25a97255e9c4f4214e04a79455f461de448694fdb15ca494b8cd92d")
