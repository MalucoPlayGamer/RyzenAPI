-- Lua provided by RyzenAPI
-- Game: Game: The Legend of The Sacred Stone EX

-- MAIN APPLICATION
addappid(1886830)
-- Game: addappid(1886830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886831, 1, "fa710aae267ec0dba1d1c72224d2d1f30c1bc138990482cc30d3e8eb838d8f33")
