-- Lua provided by RyzenAPI
-- Game: WE ARE FOOTBALL 2024

-- MAIN APPLICATION
addappid(1951410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951411, 1, "226dafc2cf50035575ff3261fea505b971bdfccf67470001a8522a797816fe9e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
