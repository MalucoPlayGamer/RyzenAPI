-- Lua provided by RyzenAPI
-- Game: addappid(1951410)

-- MAIN APPLICATION
addappid(1951410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951411, 1, "226dafc2cf50035575ff3261fea505b971bdfccf67470001a8522a797816fe9e")
