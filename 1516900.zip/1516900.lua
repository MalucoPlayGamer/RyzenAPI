-- Lua provided by RyzenAPI
-- Game: addappid(1516900)

-- MAIN APPLICATION
addappid(1516900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516901, 1, "d877baac97cce491f9febbf69756d38aa84e3039efc653d07a55ed2681f6d120")
