-- Lua provided by RyzenAPI
-- Game: mickey mouse P.I. For Hire

-- MAIN APPLICATION
addappid(3879490)
addappid(3912890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2416450, 1, "56df9203dd3706f1816684fd80aec6fd14bacaf541f8274f7d84eb9ae924b04e")
addappid(2416451, 1, "c52f8369321c8357293962eacf7c7f416c2ea912c3d2640703880a12c964732a")
addappid(3879491, 1, "a609219532d6690630d1cccd2eb190817cca2d15d8380c0d3ba2bb1d91108f67")

