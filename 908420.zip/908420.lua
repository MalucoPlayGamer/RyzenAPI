-- Lua provided by RyzenAPI
-- Game: Game: AppID 908420

-- MAIN APPLICATION
addappid(908420)
-- Game: addappid(908420)

-- MAIN APP DEPOTS / PACKAGES
addappid(908421, 1, "e4c0fc25da71cb01e82710113ac3999a404b55293e1befed482a82f8382cff2e")
