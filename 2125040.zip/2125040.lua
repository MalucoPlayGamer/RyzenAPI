-- Lua provided by RyzenAPI
-- Game: Estencel Demo

-- MAIN APPLICATION
addappid(2125040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125041, 1, "ebb2581c755af555af185ca7f29eb97a6041acebe3835fc8efe914f3000cc7ab")
