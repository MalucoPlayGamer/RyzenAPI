-- Lua provided by RyzenAPI
-- Game: Game: The Alchemist's Cards

-- MAIN APPLICATION
addappid(3745270)
-- Game: addappid(3745270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3745271, 1, "1db8fd13e5ff9ee71c1678fbb625215864adfa9dc23e7a50332099453ea75911")
