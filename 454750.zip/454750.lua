-- Lua provided by RyzenAPI
-- Game: Aeternum

-- MAIN APPLICATION
addappid(454750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(454751, 1, "3052a9b4a99b8881954cd17ab7979ecb0eaa6c98b784b16ca3cd6b5c58722141")
