-- Lua provided by RyzenAPI 
-- Game: AppID 454750
addappid(454750)
addappid(454751, 1, "3052a9b4a99b8881954cd17ab7979ecb0eaa6c98b784b16ca3cd6b5c58722141")
