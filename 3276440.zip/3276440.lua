-- Lua provided by RyzenAPI
-- Game: Game: JumpKin

-- MAIN APPLICATION
addappid(3276440)
-- Game: addappid(3276440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276441, 1, "5c68907552973efd49a80a436d956b14f4a55564bd5f1c82b045b1169d7951c8")
