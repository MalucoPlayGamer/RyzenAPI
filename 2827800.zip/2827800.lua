-- Lua provided by RyzenAPI
-- Game: 反转21克-下部：迷雾中的真相+命运红线

-- MAIN APPLICATION
addappid(2827800)
-- Game: addappid(2827800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827800,0,"036d4fcab0d5e081ddee7ab6441f9c1bfe763d8d27934f36431eefadb0f351f1")
