-- Lua provided by RyzenAPI
-- Game: DFF NT: Emperor Starter Pack

-- MAIN APPLICATION
addappid(1022438)
-- Game: addappid(1022438)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022438,0,"de4fe21ae82f450b2b530b31d007ac17f4ad42e3d57724a1c3c5e964b1aa2d97")
