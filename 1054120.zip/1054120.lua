-- Lua provided by RyzenAPI
-- Game: Game: SEXXXNATOR: Adult Sandbox RPG

-- MAIN APPLICATION
addappid(1054120)
-- Game: addappid(1054120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054121, 1, "5bbc2783bfd5a08c4853d071e2a767dd5aa61e65666d2a65cb7b96dd0025fffe")
