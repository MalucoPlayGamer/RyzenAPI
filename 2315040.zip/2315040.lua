-- Lua provided by RyzenAPI
-- Game: 火炬之光：无限

-- MAIN APPLICATION
addappid(2315040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2315041, 1, "c9c7ccb23dda07c32919da95a21c9183042acfdf7496fd666304756d9dd78fcd")

