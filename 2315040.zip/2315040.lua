-- Lua provided by RyzenAPI
-- Game: addappid(2315040)

-- MAIN APPLICATION
addappid(2315040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315041, 1, "c9c7ccb23dda07c32919da95a21c9183042acfdf7496fd666304756d9dd78fcd")
