-- Lua provided by RyzenAPI
-- Game: Highline Volleyball VR Demo

-- MAIN APPLICATION
addappid(2704570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704571, 1, "c636f433387c5f030b98b55617f3d4a890a256d1e7b9582687e630587071e313")

