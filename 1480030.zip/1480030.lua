-- Lua provided by RyzenAPI
-- Game: A Way To Be Dead

-- MAIN APPLICATION
addappid(1480030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480031, 1, "e0b0e781b98aa7df9b1562415bf8ac001bc3ac09bf66887f0c656302021b26ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
