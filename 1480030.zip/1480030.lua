-- Lua provided by RyzenAPI
-- Game: A Way To Be Dead

-- MAIN APPLICATION
addappid(1480030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480031, 1, "e0b0e781b98aa7df9b1562415bf8ac001bc3ac09bf66887f0c656302021b26ce")
