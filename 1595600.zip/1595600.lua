-- Lua provided by RyzenAPI
-- Game: Last Generation: Survival

-- MAIN APPLICATION
addappid(1595600)
-- Game: addappid(1595600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595601, 1, "1090e7de8734e1771ac9d62ec833bfe4efd7dfc1a1e10167add75a6e278502f0")
