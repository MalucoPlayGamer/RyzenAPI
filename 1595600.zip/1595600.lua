-- Lua provided by SkyAPI 
-- Game: Last Generation: Survival
addappid(1595600)
addappid(1595601, 1, "1090e7de8734e1771ac9d62ec833bfe4efd7dfc1a1e10167add75a6e278502f0")
