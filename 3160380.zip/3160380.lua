-- Lua provided by RyzenAPI
-- Game: Game: AppID 3160380

-- MAIN APPLICATION
addappid(3160380)
-- Game: addappid(3160380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160381, 1, "c5679c714e1a0ae4c3381f3072a54a486d29c20baa93813288f16afb4fc93e8b")
addappid(3160382, 1, "8aee6f48d5030a3016f2f2b14efd2d5bb128d4a924ee148e2dcfca17d033076a")
