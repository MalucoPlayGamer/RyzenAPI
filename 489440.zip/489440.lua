-- Lua provided by RyzenAPI
-- Game: Tentacult!

-- MAIN APPLICATION
addappid(489440)

-- MAIN APP DEPOTS / PACKAGES
addappid(489441, 1, "a7d13324252b8a9216ec4eadb8f70172cfd2a2d7001521e5e8eb49ea02a72c6f")

