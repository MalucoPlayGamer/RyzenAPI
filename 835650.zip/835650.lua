-- Lua provided by RyzenAPI
-- Game: Game: AppID 835650

-- MAIN APPLICATION
addappid(835650)
-- Game: addappid(835650)

-- MAIN APP DEPOTS / PACKAGES
addappid(835651, 1, "303aa5cf9ac4c0d43a57dd173753a1d76e9bf428373d0d798298af8f86e3dc0a")
addappid(835652, 1, "ce35de34cbb732b7631b924e5c90854abc88cb1cb580d0c98fe6be00896c2700")
