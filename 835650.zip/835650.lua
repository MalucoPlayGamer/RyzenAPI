-- Lua provided by RyzenAPI
-- Game: Rising Lords

-- MAIN APPLICATION
addappid(835650)
addappid(3503840)

-- MAIN APP DEPOTS / PACKAGES
addappid(835650,0,"266af09906a0f2ec278555e7f549d55c90c72bdee8db2496682e4d42ff540a09")
addappid(835651,0,"303aa5cf9ac4c0d43a57dd173753a1d76e9bf428373d0d798298af8f86e3dc0a")
addappid(835652,0,"ce35de34cbb732b7631b924e5c90854abc88cb1cb580d0c98fe6be00896c2700")

