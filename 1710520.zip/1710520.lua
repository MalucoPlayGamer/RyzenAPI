-- Lua provided by RyzenAPI
-- Game: Mind-Blowing Girls 3

-- MAIN APPLICATION
addappid(1710520)
addappid(1710660)
-- Game: addappid(1710520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710521, 1, "544d53c67f89c6057ecda77cf64975a3679c793e263b6ed34aaf84156d347566")
