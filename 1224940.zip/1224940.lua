-- Lua provided by RyzenAPI
-- Game: 1224940

-- MAIN APPLICATION
addappid(1224940)
-- Game: addappid(1224940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224941, 1, "098faf903d473c1d990ae386b46126fa5b17f29619db28faa2df3a942f1decc6")
