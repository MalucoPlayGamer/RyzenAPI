-- Lua provided by RyzenAPI
-- Game: Game: YoloMouse - Cursor Changer

-- MAIN APPLICATION
addappid(1283970)
-- Game: addappid(1283970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283971, 1, "cc3e8638081fb7bb6f0a2b461db9232fa3521c984d47cb33aed0f59c8eadd303")
