-- Lua provided by RyzenAPI
-- Game: 2843190

-- MAIN APPLICATION
addappid(2843190)
-- Game: addappid(2843190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843191, 1, "fba4bbaff05d9c2d954a673410b3ed2468e54afa6403fe20bacfdddd06d0bb0d")
addappid(3765780, 0, "d1cb02413ec970a4b50bd09fb20b345ea7e28ee0ced5fd0e63c2ec2a701dc178")
