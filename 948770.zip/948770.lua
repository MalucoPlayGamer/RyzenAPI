-- Lua provided by RyzenAPI
-- Game: 魔塔2018

-- MAIN APPLICATION
addappid(948770)

-- MAIN APP DEPOTS / PACKAGES
addappid(948771, 1, "e6efb3f2ac644f64bc707a97ed317b8294852ef3f63afa18840d0171d5091a20")

