-- Lua provided by RyzenAPI
-- Game: Steel Storm: Burning Retribution

-- MAIN APPLICATION
addappid(96200)
addappid(202650)

-- MAIN APP DEPOTS / PACKAGES
addappid(96201,0,"c8a76944d76f39eb3d1edee3db7c964c5d23856745fc7f2080443f3e4a17ca9b")
addappid(96202,0,"0754f8a1995b42e5b91a971f2b0e1ae208bf62de95621fef3fc78a9d454bc44e")
addappid(96203,0,"abd371985ecea02847b40529c8feb0f883cb2c922c0c606137600269dd1530a4")
addappid(96204,0,"8560a9b45f0551b1129ccc19917ca63feeb24ba583bb37992a288bddf3526c0a")
addappid(202651,0,"367d339c91d17cb385f3f8e7641e04ebc6b5b42f99e84c7cb20761604f55e1f7")
addappid(202652,0,"55aa90e0869ccd1f4e8c40c2b089f2b0aa2ff2c7fac048dade0120f0417453b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
