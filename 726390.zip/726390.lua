-- Lua provided by RyzenAPI
-- Game: Scream Collector

-- MAIN APPLICATION
addappid(726390)

