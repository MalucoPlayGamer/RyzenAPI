-- Lua provided by RyzenAPI
-- Game: Last Hours Of Jack

-- MAIN APPLICATION
addappid(625120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(625121, 1, "ff5b958b30bdf3afbe3e8b8617f68d6bddbffd4d05342025ce714a74e86a4aca")

