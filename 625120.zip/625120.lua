-- Lua provided by RyzenAPI
-- Game: 625120

-- MAIN APPLICATION
addappid(625120)
-- Game: addappid(625120)

-- MAIN APP DEPOTS / PACKAGES
addappid(625121, 1, "ff5b958b30bdf3afbe3e8b8617f68d6bddbffd4d05342025ce714a74e86a4aca")
