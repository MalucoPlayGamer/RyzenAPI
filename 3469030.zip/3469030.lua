-- Lua provided by RyzenAPI
-- Game: Game: 超自然侦探社 Demo

-- MAIN APPLICATION
addappid(3469030)
-- Game: addappid(3469030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3469031, 1, "e1f9f4cc8e6bed72f300aedb0edcdbb786832b76afc8c0787dbdfe5c239a1b9e")
