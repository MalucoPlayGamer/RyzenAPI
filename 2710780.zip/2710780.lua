-- Lua provided by RyzenAPI
-- Game: addappid(2710780)

-- MAIN APPLICATION
addappid(2710780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710781, 1, "3eb33395327e7af673ba8672c0f1f452afec4d19df4f40e8dc25a71b5b01b3fb")
