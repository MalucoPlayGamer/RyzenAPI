-- Lua provided by RyzenAPI
-- Game: A House of Thieves

-- MAIN APPLICATION
addappid(1506760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1506761, 1, "9c1ea0111eca1c16666126676785c3915c79e8615b3a21856d9fb66cfdbc8ceb")

