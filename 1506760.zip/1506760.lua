-- Lua provided by RyzenAPI
-- Game: 1506760

-- MAIN APPLICATION
addappid(1506760)
-- Game: addappid(1506760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506761, 1, "9c1ea0111eca1c16666126676785c3915c79e8615b3a21856d9fb66cfdbc8ceb")
