-- Lua provided by RyzenAPI
-- Game: Game: AppID 890180

-- MAIN APPLICATION
addappid(890180)
-- Game: addappid(890180)

-- MAIN APP DEPOTS / PACKAGES
addappid(890181, 1, "d9f6fbf68820af9c27c2f95dab28b8770859e73085d8239eef8e72b5f938c3b7")
addappid(890182, 1, "5146f76d53fe012f943316b621bed8422f57588ce26a62036589f98d86aaf2db")
addappid(890183, 1, "e870b22c2a4aa796ee52be67437bcda0c0b02aeecb7ae61ba8afe45d8f35bf01")
addappid(890184, 1, "f3f6f7cef156bf18b8f651bdae8ee81a85471e02d8327c031c5557832a1d2c99")
