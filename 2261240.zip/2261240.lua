-- Lua provided by RyzenAPI
-- Game: Game: Nope Nope Nope Nurses

-- MAIN APPLICATION
addappid(2261240)
-- Game: addappid(2261240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261241, 1, "acbd825b66bd4546db9a4b1522fa3af4677b5ed276117779b0db7807ce79f9ab")
