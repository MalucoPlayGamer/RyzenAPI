-- Lua provided by RyzenAPI
-- Game: Nope Nope Nope Nurses

-- MAIN APPLICATION
addappid(2261240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2261241, 1, "acbd825b66bd4546db9a4b1522fa3af4677b5ed276117779b0db7807ce79f9ab")

