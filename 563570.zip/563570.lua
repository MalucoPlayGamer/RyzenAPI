-- Lua provided by RyzenAPI
-- Game: AppID 563570

-- MAIN APPLICATION
addappid(563570)
-- Game: addappid(563570)

-- MAIN APP DEPOTS / PACKAGES
addappid(563571, 1, "4ce8b890003114625dad3e5e69b4cdb6f0813a9176e2290ee83f1fb3e0662e9d")
