-- Lua provided by SkyAPI 
-- Game: AppID 563570
addappid(563570)
addappid(563571, 1, "4ce8b890003114625dad3e5e69b4cdb6f0813a9176e2290ee83f1fb3e0662e9d")
