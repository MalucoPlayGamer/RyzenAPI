-- Lua provided by RyzenAPI
-- Game: addappid(844950)

-- MAIN APPLICATION
addappid(844950)

-- MAIN APP DEPOTS / PACKAGES
addappid(844951, 1, "3cd49bc7d1e9eda527890cd8bde9df59a5f0ff82b4e303eb363c888ea15a9eab")
addappid(909340, 0, "fddeb166bb31dbf0be597b640e43896dadf6502a113d9d085af9e8859d266588")
