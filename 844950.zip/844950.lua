-- Lua provided by RyzenAPI
-- Game: Eternal Fantasy

-- MAIN APPLICATION
addappid(844950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(844951, 1, "3cd49bc7d1e9eda527890cd8bde9df59a5f0ff82b4e303eb363c888ea15a9eab")
addappid(909340, 0, "fddeb166bb31dbf0be597b640e43896dadf6502a113d9d085af9e8859d266588")

