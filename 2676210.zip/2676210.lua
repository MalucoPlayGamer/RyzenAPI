-- Lua provided by RyzenAPI
-- Game: GARMM Adventurer Vol.1

-- MAIN APPLICATION
addappid(2676210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676211, 1, "672337683ef717fecf4069110b211b834955b655059f6050e2b1fdeaf83dd8fe")

