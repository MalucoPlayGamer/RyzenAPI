-- Lua provided by RyzenAPI
-- Game: Demonic Blade

-- MAIN APPLICATION
addappid(1341100)
-- Game: addappid(1341100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341101, 1, "0b0b0f835edfc704a0bf6cfa21924b3ad4721927cb48366af96a80ffd440bd10")
