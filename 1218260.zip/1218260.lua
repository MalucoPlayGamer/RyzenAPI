-- Lua provided by RyzenAPI
-- Game: Sono

-- MAIN APPLICATION
addappid(1218260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218261, 1, "16d08379c1f262ed87f89bdbe29640b0ca89aea1b3699c2a44fd4d48e6a4d039")
addappid(1218262, 1, "64fd931dc2e81250b27e6183e0f6492de657140f8b0be12ce6c88da3f0651b22")
addappid(1218263, 1, "1530553d5702ec2498e73bbbbae90c173771f06c06ccfec2a04865fd31b2b10c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
