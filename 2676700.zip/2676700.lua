-- Lua provided by RyzenAPI
-- Game: Deadly Nightmare Unwanted Heritage

-- MAIN APPLICATION
addappid(2676700)
-- Game: addappid(2676700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676705,0,"e618736e30da6e544df046edf2412090c8ce2ab1edda66ab144954ff7ebf10f7")
