-- Lua provided by RyzenAPI
-- Game: CYBRID

-- MAIN APPLICATION
addappid(1636850)
-- Game: addappid(1636850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636851, 1, "c39bb3972ee3abdffe7fcd5264a30205d3a9e513ce9a352d444b6306137fc53e")
