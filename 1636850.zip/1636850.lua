-- Lua provided by RyzenAPI
-- Game: CYBRID

-- MAIN APPLICATION
addappid(1636850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636851, 1, "c39bb3972ee3abdffe7fcd5264a30205d3a9e513ce9a352d444b6306137fc53e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3703810)
