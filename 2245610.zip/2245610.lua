-- Lua provided by RyzenAPI
-- Game: Otherplane

-- MAIN APPLICATION
addappid(2245610)
-- Game: addappid(2245610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245611, 1, "01703f28394196f2dd6e8189d80b6516b6997d0c7a47eac51178f42e264849c6")
