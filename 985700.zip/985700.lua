-- Lua provided by RyzenAPI
-- Game: Game: 军团战棋 Legion War Demo

-- MAIN APPLICATION
addappid(985700)
-- Game: addappid(985700)

-- MAIN APP DEPOTS / PACKAGES
addappid(985701, 1, "84fe5636af820e633d8944f54688d040b2d3ea418f9c862f7da2f04225457bc8")
