-- Lua provided by RyzenAPI
-- Game: Zombie Estate 2

-- MAIN APPLICATION
addappid(512490)

-- MAIN APP DEPOTS / PACKAGES
addappid(512491, 1, "d3f361ad5da2cbc583223240e7f5b9c5ead7c67e6565ea3c1b6aaf2bf8005f4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
