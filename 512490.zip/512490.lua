-- Lua provided by SkyAPI 
-- Game: Zombie Estate 2
addappid(512490)
addappid(512491, 1, "d3f361ad5da2cbc583223240e7f5b9c5ead7c67e6565ea3c1b6aaf2bf8005f4c")
