-- Lua provided by RyzenAPI
-- Game: Touhou Kimono Blast

-- MAIN APPLICATION
addappid(1824540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824541, 1, "eac80fcdfcd74afeb8e1578a95c4b7e4ee9825430e70b59a04fa0a829929fd07")
