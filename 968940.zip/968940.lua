-- Lua provided by RyzenAPI
-- Game: addappid(968940)

-- MAIN APPLICATION
addappid(968940)

-- MAIN APP DEPOTS / PACKAGES
addappid(968941, 1, "25ee3ab0cc6fd33d032e2e24a2ab1608509f0a71dd50977bfde2a039ab186389")
