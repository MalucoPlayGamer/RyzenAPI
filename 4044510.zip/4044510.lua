-- Lua provided by RyzenAPI
-- Game: Breezy Bakes Simulator

-- MAIN APPLICATION
addappid(4044510)

-- MAIN APP DEPOTS / PACKAGES
addappid(4044511,0,"ae4d4d1809ff4effc5e9709263d563a73ad181c625aeb848f7bf48932b0224eb")

