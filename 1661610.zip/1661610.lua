-- Lua provided by RyzenAPI
-- Game: Apopia: Sugar Coated Tale

-- MAIN APPLICATION
addappid(1661610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661611,0,"e7e9d91bc0429d103f5e080500c8d851e8a1c0ed8c8404751b2f8d9e54e4cef5")

