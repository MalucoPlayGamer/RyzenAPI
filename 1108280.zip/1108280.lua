-- Lua provided by RyzenAPI
-- Game: Resident Evil Resistance - Traje de sobrevivente masculino: Leon S. Kennedy

-- MAIN APPLICATION
addappid(1108280)
-- Game: addappid(1108280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108280,0,"2c80f9e638cea673510ec5562456040bb00c6ef138fb7be77c691ecab6118199")
