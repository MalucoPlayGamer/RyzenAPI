-- Lua provided by RyzenAPI
-- Game: AppID 870610

-- MAIN APPLICATION
addappid(870610)
addappid(894560)
addappid(894561)

-- MAIN APP DEPOTS / PACKAGES
addappid(870611, 1, "7b4aec82f10a2d2cf9cd461af0a8021149dc7727ab8fafeb2efc2197c68ca89d")

