-- Lua provided by RyzenAPI
-- Game: Void And Meddler

-- MAIN APPLICATION
addappid(377970)
addappid(383680)
addappid(408260)
addappid(556420)

-- MAIN APP DEPOTS / PACKAGES
addappid(377971, 1, "8268cff2d1337620916e3755c94cc83d19ba685ade2861014822558c10d05db7")

