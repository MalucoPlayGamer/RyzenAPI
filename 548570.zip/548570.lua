-- Lua provided by RyzenAPI
-- Game: RAGE 2

-- MAIN APPLICATION
addappid(228986)
addappid(548570)
addappid(1054920)
addappid(1054921)
addappid(1067980)

-- MAIN APP DEPOTS / PACKAGES
addappid(548572,0,"1492bc687a1a552be15c6dcb0c7c677d21a0a5253a4f8845c808f0a9037ae5b2")

