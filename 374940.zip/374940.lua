-- Lua provided by RyzenAPI
-- Game: Tank Battle: Normandy

-- MAIN APPLICATION
addappid(374940)

-- MAIN APP DEPOTS / PACKAGES
addappid(374941, 1, "2cbc48268a5d12509de219d8855330b211c08e97324c7784fe8966a827278f69")
addappid(374942, 1, "6d1a2256c5ce60dfc4335f43c1255776198dd13f7690455cdf6f989f7fda917a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
