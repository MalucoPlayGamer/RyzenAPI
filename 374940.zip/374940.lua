-- Lua provided by SkyAPI 
-- Game: Tank Battle: Normandy
addappid(374940)
addappid(374941, 1, "2cbc48268a5d12509de219d8855330b211c08e97324c7784fe8966a827278f69")
addappid(374942, 1, "6d1a2256c5ce60dfc4335f43c1255776198dd13f7690455cdf6f989f7fda917a")
