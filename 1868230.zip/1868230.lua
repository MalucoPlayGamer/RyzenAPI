-- Lua provided by RyzenAPI
-- Game: 1868230

-- MAIN APPLICATION
addappid(1868230)
-- Game: addappid(1868230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868231, 1, "dbdecc5088dda20342b6337c1f60cedca13b667eebd58aaba36cf1c2e8d27bd5")
