-- Lua provided by RyzenAPI 
-- Game: AppID 691130
addappid(691130)
addappid(691131, 1, "b9141c5c9d6c5b463650f9f7ac63fe95d8bc278c5599e79066d280b2ab971655")
