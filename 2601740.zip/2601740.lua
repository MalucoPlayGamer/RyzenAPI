-- Lua provided by RyzenAPI
-- Game: 2601740

-- MAIN APPLICATION
addappid(2601740)
-- Game: addappid(2601740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601741, 1, "b7fe9710a406a208187d554c13cab0a3e3000b1e76ad074859927e245f6fe1c9")
