-- Lua provided by RyzenAPI
-- Game: AppID 1186040

-- MAIN APPLICATION
addappid(1186040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186041, 1, "d36b37fc2cc47afac8d850b9bef3bf65a60292c5d92dda259b815b1cc2c6658b")
