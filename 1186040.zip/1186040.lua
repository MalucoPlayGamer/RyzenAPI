-- Lua provided by RyzenAPI
-- Game: Worms Rumble

-- MAIN APPLICATION
addappid(1440190) -- Worms Rumble - Action All-Stars Pack
addappid(1440191) -- Worms Rumble - Legends Pack
addappid(1442620) -- Worms Rumble - New Challengers Pack
addappid(1490070) -- Worms Rumble - Armageddon Weapon Skin Pack
addappid(1490080) -- Worms Rumble - Emote Pack
addappid(1490090) -- Worms Rumble - Captain  Shark Double Pack
addappid(1490100) -- Worms Rumble - Cats  Dogs Double Pack
addappid(1503190) -- Worms Rumble - Honor  Death Pack
addappid(1528070) -- Worms Rumble - Bank Heist Double Pack
addappid(1572500) -- Worms Rumble - Spaceworm and Alien Double Pack
-- addappid(1186042) -- Depot 1186042 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1186040, 1, "f0fa3041c53f78443289986b6fd20f5b34dc85fafd2a74659bf22b5ae0e8d6db") -- Worms Rumble
addappid(1186041, 1, "d36b37fc2cc47afac8d850b9bef3bf65a60292c5d92dda259b815b1cc2c6658b") -- Project Nimble Content

