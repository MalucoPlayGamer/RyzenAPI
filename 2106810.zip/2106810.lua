-- Lua provided by RyzenAPI
-- Game: The Forest of Drizzling Rain

-- MAIN APPLICATION
addappid(2106810)
-- Game: addappid(2106810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106813,0,"d5965056fdb9534ddd55a07c08ee23ef963599a32db9e47f6fe2c27cb992c05e")
addappid(2106815,0,"3ad7579ffc80dc88e1477624ef3feacb0c9be10c769ccb8f4ddb801846916944")
addappid(2106817,0,"b933670ae8ebebb4132dc12f3fce7043b016c65555b073fe82ec22a27a3bca86")
addappid(2106818,0,"cc16d4977fdc8b5820aa317ba86a501a2a8b3e6615af0c509050697a72c819de")
