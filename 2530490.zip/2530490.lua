-- Lua provided by RyzenAPI
-- Game: addappid(2530490)

-- MAIN APPLICATION
addappid(2530490)
addappid(4021450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530491, 1, "7edbb8d7ab46a4c9dd432e79bd83ff5fa540cd15144a384e599065a20590d31d")
