-- Lua provided by RyzenAPI
-- Game: Aquapark Tycoon

-- MAIN APPLICATION
addappid(2819470)
addappid(4948710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819471,0,"a38c0eb936bc8daad59b9f70ca0203ed4b5c30ba0750466288574a541d8f67c5")
addappid(2819472,0,"d367f19ab03b2e0f7e3f06064165e3019cd0def122126f73b40e8d6e1349bdc8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
