-- Lua provided by RyzenAPI
-- Game: Grimm's Hollow

-- MAIN APPLICATION
addappid(1170880)

