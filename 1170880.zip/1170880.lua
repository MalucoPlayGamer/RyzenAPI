-- Lua provided by RyzenAPI
-- Game: Grimm's Hollow

-- MAIN APPLICATION
addappid(1170880)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1183640)
