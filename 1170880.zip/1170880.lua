-- Lua provided by RyzenAPI
-- Game: Grimm's Hollow

-- MAIN APPLICATION
addappid(1170880)
addappid(1183640)

