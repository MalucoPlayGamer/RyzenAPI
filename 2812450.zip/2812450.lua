-- Lua provided by RyzenAPI
-- Game: Tiny Garden

-- MAIN APPLICATION
addappid(2812450)
addappid(3493700)
addappid(3623570)
-- Game: addappid(2812450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812451, 1, "92971f4b75b3fdfcd20b47058bcc1355587bf47f8d0dde109c5d19a73d2fe192")
