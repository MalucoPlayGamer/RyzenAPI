-- Lua provided by RyzenAPI
-- Game: missed messages.

-- MAIN APPLICATION
addappid(812810)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1082920)
