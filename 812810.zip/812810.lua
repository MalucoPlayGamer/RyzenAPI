-- Lua provided by RyzenAPI
-- Game: missed messages.

-- MAIN APPLICATION
addappid(812810)
addappid(1082920)

