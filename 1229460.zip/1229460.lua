-- Lua provided by RyzenAPI 
-- Game: AppID 1229460
addappid(1229460)
addappid(1229461, 1, "b119b0db146be27ba32ed20404d96e96314aa24471a75b0e33fdf959ae98302c")
addappid(1879740, 0, "9a37029ba1586cdc0466b36288355b3dad8872bf3bee6074d76412eb8e08ee62")
