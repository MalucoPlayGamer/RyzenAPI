-- Lua provided by RyzenAPI
-- Game: Dice Legacy

-- MAIN APPLICATION
addappid(1229460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1229461, 1, "b119b0db146be27ba32ed20404d96e96314aa24471a75b0e33fdf959ae98302c")
addappid(1879740, 0, "9a37029ba1586cdc0466b36288355b3dad8872bf3bee6074d76412eb8e08ee62")

