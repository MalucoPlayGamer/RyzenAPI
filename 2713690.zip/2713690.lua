-- Lua provided by RyzenAPI
-- Game: addappid(2713690)

-- MAIN APPLICATION
addappid(2713690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2713692,0,"b78eff7b11ce3c5061e4fc8f455c25d1d7ea57fbfe0889f1d1268a6ff56b66df")
