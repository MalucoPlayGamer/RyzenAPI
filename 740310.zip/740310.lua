-- Lua provided by RyzenAPI
-- Game: Transmogrify

-- MAIN APPLICATION
addappid(740310)

-- MAIN APP DEPOTS / PACKAGES
addappid(740311,0,"98a0009b5b7c3f20c5cdadbe86c3a530a9263d708d45d965b2d7964f59b73b2d")
addappid(740314,0,"c59df9e646111aa760fd90bc70862e4a511d86243933babe905b3e3feea17ef6")

