-- Lua provided by RyzenAPI
-- Game: Tiamat X

-- MAIN APPLICATION
addappid(343340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(343341, 1, "b8c392218e84a1d0074affbf7ac5326917bcc94bae2579aa25bc43460eedfa3f")
addappid(343342, 1, "59c90aade7c2faa5c9e65e4130bdb98a026ccfcb217c5793b23618925f0cf231")

