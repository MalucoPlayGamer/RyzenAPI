-- Lua provided by RyzenAPI
-- Game: addappid(343340)

-- MAIN APPLICATION
addappid(343340)

-- MAIN APP DEPOTS / PACKAGES
addappid(343341, 1, "b8c392218e84a1d0074affbf7ac5326917bcc94bae2579aa25bc43460eedfa3f")
addappid(343342, 1, "59c90aade7c2faa5c9e65e4130bdb98a026ccfcb217c5793b23618925f0cf231")
