-- Lua provided by RyzenAPI
-- Game: Deathtrap Dungeon Trilogy

-- MAIN APPLICATION
addappid(824760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(824761, 1, "a0bf2b0724580718d478df3f650a45cce3e414152a6732c9beddce01f0fd86b3")
addappid(824762, 1, "6db5e08b4256dcf0b9f66afafca791c5f43f7e171b5588e8814900b58131ebd1")

