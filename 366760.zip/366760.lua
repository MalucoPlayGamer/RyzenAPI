-- Lua provided by RyzenAPI 
-- Game: AppID 366760
addappid(366760)
addappid(366761, 1, "1b1c63da7b5081f37070a6a71e38f4e1a810319edf55a7d5d4bc39254b97b6d6")
addappid(366764, 1, "2d450be1864d5a73efcce13a0d6c4188bf9938b2db8f155c48a7ed12bf48dc12")
