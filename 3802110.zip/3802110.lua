-- Lua provided by RyzenAPI
-- Game: Reminiscence

-- MAIN APPLICATION
addappid(3802110)
-- Game: addappid(3802110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3802111, 1, "93dfc87d4b5f82ca267dd26c0b73eedcb9bc1eeb8104a26288a31a0e01d4465c")
