-- Lua provided by RyzenAPI
-- Game: Lyra Convolution

-- MAIN APPLICATION
addappid(3328230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(3328231, 1, "ab1c1c9f5143b956d54547c6fa3177455f06292f91fc6c1d59e94f708f533008")

