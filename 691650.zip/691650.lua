-- Lua provided by RyzenAPI
-- Game: 691650

-- MAIN APPLICATION
addappid(691650)
-- Game: addappid(691650)

-- MAIN APP DEPOTS / PACKAGES
addappid(691651, 1, "ded95132f1f234c6bdfd435509fec2d6f462a3c59645f1af46446c2b12ac2764")
