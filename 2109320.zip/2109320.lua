-- Lua provided by RyzenAPI
-- Game: AppID 2109320

-- MAIN APPLICATION
addappid(2109320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109321, 1, "ce0fe7127da4ec097125391874e4b025ddaae3dd3e9b646508ac439c62f8df6f")

