-- Lua provided by SkyAPI 
-- Game: Infinite World: Randomize everything
addappid(865390)
addappid(865391, 1, "f9bc046edcc5c9be48ca79e20eece0d98730c22d5923331827716630e19590d6")
