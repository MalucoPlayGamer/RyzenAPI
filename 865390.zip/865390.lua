-- Lua provided by RyzenAPI
-- Game: Infinite World: Randomize everything

-- MAIN APPLICATION
addappid(865390)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(865391, 1, "f9bc046edcc5c9be48ca79e20eece0d98730c22d5923331827716630e19590d6")

