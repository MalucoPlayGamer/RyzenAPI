-- Lua provided by RyzenAPI
-- Game: Skaldsong

-- MAIN APPLICATION
addappid(3808550)
