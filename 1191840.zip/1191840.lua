-- Lua provided by RyzenAPI
-- Game: AppID 1191840

-- MAIN APPLICATION
addappid(1191840)
-- Game: addappid(1191840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191841, 1, "7e1edb534a44821e0ab6883fda8ebde143e3be38d4767eb0372ed2a22fd0c7a8")
