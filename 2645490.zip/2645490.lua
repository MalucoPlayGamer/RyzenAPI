-- Lua provided by RyzenAPI
-- Game: Ghostbane

-- MAIN APPLICATION
addappid(2645490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645491, 1, "6c02ebfd400609aca6a521f670c2a4ae3ef96ce643325e124ca9686f62bca3e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
