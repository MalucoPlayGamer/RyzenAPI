-- Lua provided by SkyAPI 
-- Game: Ghostbane
addappid(2645490)
addappid(2645491, 1, "6c02ebfd400609aca6a521f670c2a4ae3ef96ce643325e124ca9686f62bca3e9")
