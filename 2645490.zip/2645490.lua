-- Lua provided by RyzenAPI
-- Game: Ghostbane

-- MAIN APPLICATION
addappid(2645490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645491, 1, "6c02ebfd400609aca6a521f670c2a4ae3ef96ce643325e124ca9686f62bca3e9")

