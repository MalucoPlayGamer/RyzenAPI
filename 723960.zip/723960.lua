-- Lua provided by RyzenAPI
-- Game: Twilight Phenomena: Strange Menagerie Collector's Edition

-- MAIN APPLICATION
addappid(723960)

-- MAIN APP DEPOTS / PACKAGES
addappid(723961,0,"d879bdb70a76d35962c6e01fa6de7122d4d44f4090b583df8d4b52290901edf7")

