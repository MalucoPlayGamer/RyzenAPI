-- Lua provided by RyzenAPI
-- Game: addappid(3180150)

-- MAIN APPLICATION
addappid(3180150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180151, 1, "28de3e0bee2c6383e918f4f8ce53cb834444d8015c34213ea29b92874b5c884e")
