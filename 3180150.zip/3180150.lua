-- Lua provided by SkyAPI 
-- Game: Mall Simulator
addappid(3180150)
addappid(3180151, 1, "28de3e0bee2c6383e918f4f8ce53cb834444d8015c34213ea29b92874b5c884e")
