-- Lua provided by RyzenAPI
-- Game: Game: The Chronicles of King Arthur: Episode 2 - Knights of the Round Table

-- MAIN APPLICATION
addappid(1065680)
-- Game: addappid(1065680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065681, 1, "b54f75723ee92d36e714cafc4129c619db3faa5923c6f0a205ba3bf3429587ef")
addappid(1065682, 1, "2df4f08bf08aa9a0d0edc4069b96b01386597781a6ce11d1c1f80756f2d107b3")
addappid(1065683, 1, "983fded501cad100c1dc0268c970dc76f6a2ae8590161c445f036acfcb211c6c")
