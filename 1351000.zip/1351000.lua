-- Lua provided by RyzenAPI
-- Game: Gangs of Sherwood

-- MAIN APPLICATION
addappid(1351000)
-- Game: addappid(1351000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351001, 1, "b55b3a9859675e8cfccbb2c111ca9987ea4becee8654ea81f98cc17fa510172e")
