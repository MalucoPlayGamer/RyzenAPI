-- Lua provided by RyzenAPI
-- Game: Gangs of Sherwood

-- MAIN APPLICATION
addappid(1351000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351001, 1, "b55b3a9859675e8cfccbb2c111ca9987ea4becee8654ea81f98cc17fa510172e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2394550)
addappid(2432270)
addappid(2432271)
addappid(2432272)
