-- Lua provided by RyzenAPI
-- Game: Tear of Time: Lost memory

-- MAIN APPLICATION
addappid(1802920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1802921, 1, "a3e9357188007c97d6b50e79168f22d14a66a1c3ba73669bd8b6e1b6c9d51607")

