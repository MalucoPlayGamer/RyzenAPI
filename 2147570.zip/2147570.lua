-- Lua provided by RyzenAPI
-- Game: Game: AppID 2147570

-- MAIN APPLICATION
addappid(2147570)
-- Game: addappid(2147570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147571, 1, "b1b0db36c313067d29d1df72d0a97e7532b5e5174482253f50dc7e9f2b2e3460")
