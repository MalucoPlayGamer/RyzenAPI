-- Lua provided by RyzenAPI
-- Game: 680310

-- MAIN APPLICATION
addappid(680310)
-- Game: addappid(680310)

-- MAIN APP DEPOTS / PACKAGES
addappid(680311, 1, "8e3dbc1e185c1745a1b3d94677209d65a97b9888ebdcd7c811e656bcbc5bfcee")
