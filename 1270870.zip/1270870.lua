-- Lua provided by SkyAPI 
-- Game: Gray platformer
addappid(1270870)
addappid(1270871, 1, "880d178a8d7b80de630e7023e0d9e8f24b7248cd3aa6a84d20c0c0d0fa4899a2")
