-- Lua provided by RyzenAPI 
-- Game: Franky Lettuce
addappid(869650)
addappid(869651, 1, "12ee63c988ec7b2139844ac240fb481ea5d713a7c9a942b00f1dc4ccbd7c6c9c")
