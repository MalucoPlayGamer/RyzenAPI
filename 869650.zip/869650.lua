-- Lua provided by RyzenAPI
-- Game: Franky Lettuce

-- MAIN APPLICATION
addappid(869650)
-- Game: addappid(869650)

-- MAIN APP DEPOTS / PACKAGES
addappid(869651, 1, "12ee63c988ec7b2139844ac240fb481ea5d713a7c9a942b00f1dc4ccbd7c6c9c")
