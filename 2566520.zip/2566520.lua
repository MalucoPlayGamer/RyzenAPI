-- Lua provided by SkyAPI 
-- Game: Breaking Box: Walk!
addappid(2566520)
addappid(2566521, 1, "bc038349ac6f57392a98963ecce5961f4cad3369d92832fd48a0e41056d2dbb5")
