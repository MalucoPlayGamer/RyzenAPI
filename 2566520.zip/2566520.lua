-- Lua provided by RyzenAPI
-- Game: Game: Breaking Box: Walk!

-- MAIN APPLICATION
addappid(2566520)
-- Game: addappid(2566520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566521, 1, "bc038349ac6f57392a98963ecce5961f4cad3369d92832fd48a0e41056d2dbb5")
