-- Lua provided by SkyAPI 
-- Game: AppID 1287920
addappid(1287920)
addappid(1287921, 1, "e7ddc15199d9efe989f4e006c406bc526b1e5eca7e8a0a9872bde4f22316b417")
