-- Lua provided by RyzenAPI
-- Game: AppID 1287920

-- MAIN APPLICATION
addappid(1287920)
-- Game: addappid(1287920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287921, 1, "e7ddc15199d9efe989f4e006c406bc526b1e5eca7e8a0a9872bde4f22316b417")
