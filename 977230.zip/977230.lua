-- Lua provided by SkyAPI 
-- Game: Mars Power Industries Deluxe
addappid(977230)
addappid(977231, 1, "45a661fd26fe0fcea7f8264f1c9993522a337a305158128f3efb44af6d2906b7")
addappid(977232, 1, "4f7b1f8719075c889593e78a5e649a0e674c04cb794767cd62ed870649ee698e")
addappid(977233, 1, "d94a07cbd914d7395e224707846939442c52ac3b5c77b0dd81c8d53b48cc80b0")
