-- Lua provided by RyzenAPI
-- Game: FutaPunk 🌚

-- MAIN APPLICATION
addappid(4774990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4774991,0,"e885acfa61e08235255f751fd1a8b44e2c252d2a9cd2a0055f5f4a6d4c081913")

