-- Lua provided by RyzenAPI
-- Game: 659850

-- MAIN APPLICATION
addappid(659850)
-- Game: addappid(659850)

-- MAIN APP DEPOTS / PACKAGES
addappid(659851, 1, "86028db434b6ee7f21343978d0c162efe77ca529a07836edbf8f4d643733eb85")
