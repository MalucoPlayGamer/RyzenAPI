-- Lua provided by RyzenAPI
-- Game: SNK VS. CAPCOM SVC CHAOS

-- MAIN APPLICATION
addappid(2442380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2442381, 1, "f43852020cb567d0ddfb56e11bdd0ecd594ab4398f83336762639a5da7a4d255")

