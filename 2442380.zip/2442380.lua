-- Lua provided by RyzenAPI
-- Game: addappid(2442380)

-- MAIN APPLICATION
addappid(2442380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442381, 1, "f43852020cb567d0ddfb56e11bdd0ecd594ab4398f83336762639a5da7a4d255")
