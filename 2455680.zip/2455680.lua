-- Lua provided by RyzenAPI 
-- Game: Ayako's Mission
addappid(2455680)
addappid(2455681, 1, "1d4611a139f48373ad28d958dc8683ae6ce0109f8d368728d45d018107ce229d")
addappid(2455682, 1, "c9f22131a9e222f65e54924b4896827b834c0b50865ecb33aa7ec37d897d2e09")
