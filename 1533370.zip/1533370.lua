-- Lua provided by RyzenAPI
-- Game: Undiscovered House

-- MAIN APPLICATION
addappid(1533370)
-- Game: addappid(1533370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533371, 1, "4794e1a5fef2776bfe82f1e25b74e613e50f5f119110db755adeb986ff1e53e1")
