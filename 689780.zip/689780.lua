-- Lua provided by RyzenAPI
-- Game: Murderous Pursuits Dedicated Server

-- MAIN APPLICATION
addappid(689780)

-- MAIN APP DEPOTS / PACKAGES
addappid(689781, 1, "da1cf81ec0735cd8ebd69d646e1b50f8ab316877d454755587ae61e826bfc550")
