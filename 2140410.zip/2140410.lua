-- Lua provided by RyzenAPI
-- Game: setManifestid(2140412,"6933699738223122228")

-- MAIN APPLICATION
addappid(2140410)
-- Game: addappid(2140410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140412,0,"20479d663d7ecb5dc1dcc84accc830c2a2af5c0816a6612f5395731f3cc75df0")
