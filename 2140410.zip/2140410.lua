-- Lua provided by RyzenAPI
-- Game: Target React Force

-- MAIN APPLICATION
addappid(2140410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2140412,0,"20479d663d7ecb5dc1dcc84accc830c2a2af5c0816a6612f5395731f3cc75df0")

