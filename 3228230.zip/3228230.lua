-- Lua provided by RyzenAPI
-- Game: Earthquake: Margarita School - Definitive Edition

-- MAIN APPLICATION
addappid(3228230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228231, 1, "5a4795911b7d93f7e19d50b69cc2d7f8a22bd2f0da61df01fc59cd4aa4e6982c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
