-- Lua provided by RyzenAPI
-- Game: Game: Earthquake: Margarita School - Definitive Edition

-- MAIN APPLICATION
addappid(3228230)
-- Game: addappid(3228230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228231, 1, "5a4795911b7d93f7e19d50b69cc2d7f8a22bd2f0da61df01fc59cd4aa4e6982c")
