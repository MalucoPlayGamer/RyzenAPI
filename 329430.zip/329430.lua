-- Lua provided by RyzenAPI
-- Game: State of Decay: YOSE

-- MAIN APPLICATION
addappid(329430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(329431, 1, "b8142089d680a0dd39b0f2eacfff905ca0004a9c2325ce8c2c80d413e687f67e")
addappid(339300, 0, "e82138bd6b8f2ea0236b0330057d5c6b5a8c3cf052114ccc01e5eac7340f524e")
addappid(339301, 0, "5e8df18e12cf473ba1d495d4b6016705092b2691168d1da3a40c940a1379874a")
addappid(339302, 0, "63dd37d8abfb56e5575369d3552237ee7b55f9c520e3b0162ecb8f7f5a31189f")
addappid(339303, 0, "92f7d66647f23a028445c3185b7eff16f0404179b383888965c1d04efa7ba318")

