-- Lua provided by RyzenAPI
-- Game: Salvor DEEP

-- MAIN APPLICATION
addappid(3004470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004471, 1, "18aef2bfc8151c1da49bb66506129fc453bb0e72dcf4f6768a4880d5894d6fb3")

