-- Lua provided by SkyAPI 
-- Game: Salvor DEEP
addappid(3004470)
addappid(3004471, 1, "18aef2bfc8151c1da49bb66506129fc453bb0e72dcf4f6768a4880d5894d6fb3")
