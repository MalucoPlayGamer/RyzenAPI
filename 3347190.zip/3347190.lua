-- Lua provided by RyzenAPI 
-- Game: 「Clover Reset」 Original Soundtrack
addappid(3347190)
addappid(3347191, 1, "b305844f302b07b2abd2bf235a5cf3663b2de7d97b7ae6117b14aef055db2ce8")
addappid(3347192, 1, "d591257b2bad47178edc8a2ec8c46343d053da46216d18818ad006b08db20749")
