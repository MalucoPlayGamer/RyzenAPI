-- Lua provided by RyzenAPI
-- Game: 1000$

-- MAIN APPLICATION
addappid(1099840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099841, 1, "c88d7380690082b7ef70c14178fc72be31fb2c7ca992d41f643f793caadee631")

