-- Lua provided by RyzenAPI
-- Game: Game: AppID 1168460

-- MAIN APPLICATION
addappid(1168460)
-- Game: addappid(1168460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168461, 1, "e1a06e821923c865a60daba0443c374aae9d61820307b44a6f5062ebab279a2d")
