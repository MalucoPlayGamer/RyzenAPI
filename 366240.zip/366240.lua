-- Lua provided by RyzenAPI
-- Game: Game: AppID 366240

-- MAIN APPLICATION
addappid(366240)
-- Game: addappid(366240)

-- MAIN APP DEPOTS / PACKAGES
addappid(366241, 1, "a3e2eab3b04bec7bfe5f9c864ca7fc55c1aad6b594fb2475b791b5324c57ce9b")
