-- Lua provided by RyzenAPI
-- Game: 异变战区  E.E.R.I.E

-- MAIN APPLICATION
addappid(1631640)
-- Game: addappid(1631640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631642,0,"167b36297de9980a07e4b7612273cc5a17369150dd3e21897d1b2d66d293a4d8")
