-- Lua provided by RyzenAPI
-- Game: Bunch of Heroes

-- MAIN APPLICATION
addappid(111400)
-- Game: addappid(111400)

-- MAIN APP DEPOTS / PACKAGES
addappid(111401, 1, "ed30131f4b13d1e44bb42d4c9d2ab97ca3eaae75416d0bd4c00af0d55b4e4f4a")
