-- Lua provided by SkyAPI 
-- Game: Battle of the Four Towers
addappid(1923480)
addappid(1923481, 1, "06e8e6051f9e28df507854b55ebb87ccd051cf842a131a57f178b4d5bd50e509")
