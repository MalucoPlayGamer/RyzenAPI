-- Lua provided by RyzenAPI
-- Game: addappid(1923480)

-- MAIN APPLICATION
addappid(1923480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923481, 1, "06e8e6051f9e28df507854b55ebb87ccd051cf842a131a57f178b4d5bd50e509")
