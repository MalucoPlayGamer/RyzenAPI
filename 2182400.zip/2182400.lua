-- Lua provided by RyzenAPI
-- Game: Game: Laughing to Die

-- MAIN APPLICATION
addappid(2182400)
addappid(3204580)
-- Game: addappid(2182400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182401, 1, "fa9d769b176ffdbe827c7672087c6eb112faf16d32b25883e93c75d5b0f2dd47")
addappid(2182402, 1, "567e25c2984765d69559825245c80f337af0a9daf2ca11bd00ecef8ca34d89ff")
