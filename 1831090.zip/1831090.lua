-- Lua provided by RyzenAPI
-- Game: Slide Furry Boys

-- MAIN APPLICATION
addappid(1831090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831091, 1, "58f2254ac961b2420cdd556ee5e824391e5fe6279c9b56b1b543c4faa7be68af")
