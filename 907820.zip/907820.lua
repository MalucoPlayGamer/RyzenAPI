-- Lua provided by RyzenAPI
-- Game: Aeon of Sands - The Trail

-- MAIN APPLICATION
addappid(907820)
addappid(1025290)

-- MAIN APP DEPOTS / PACKAGES
addappid(907821, 1, "a4f5bb939a77fbd70c9eed83a2be905cdb9384e576a169ffc766148c1b67e0e3")

