-- Lua provided by RyzenAPI
-- Game: Rat Prison

-- MAIN APPLICATION
addappid(1688470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688471, 1, "d4f5c37c93126814c648f3f1dac65fd42788c021ee5253af9519582821807b2a")

