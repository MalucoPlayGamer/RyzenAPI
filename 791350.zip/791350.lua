-- Lua provided by RyzenAPI 
-- Game: AppID 791350
addappid(791350)
addappid(791351, 1, "6daf13c95975735ab51c8cf712f73f51b9b7a8f08fe532f13f75d12f7ee9be0f")
