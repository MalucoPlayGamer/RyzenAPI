-- Lua provided by RyzenAPI
-- Game: Game: AppID 2515010

-- MAIN APPLICATION
addappid(2515010)
-- Game: addappid(2515010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515011, 1, "1bc4f81016fa26669c132533011397c205b7610df321c62dae465ad6d19abf2a")
