-- Lua provided by RyzenAPI
-- Game: addappid(2574790)

-- MAIN APPLICATION
addappid(2574790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574791, 1, "9fc00b2c4c462f446d031c807066f6abcf6bf12db506b23a4ee5eee2c623f55b")
