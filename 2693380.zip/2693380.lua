-- Lua provided by RyzenAPI 
-- Game: AppID 2693380
addappid(2693380)
addappid(2693381, 1, "c46b5a9485964e490ce2c29df60c3b1cf0819068cef1558c1d999853e91b24fe")
addappid(2693383, 1, "4e3e5b5e40b74f7e37f0d02296b8d04b14c4e9a874ca98038ddbb0d1cedcfd43")
