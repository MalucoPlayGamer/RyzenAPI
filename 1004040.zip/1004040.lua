-- Lua provided by SkyAPI 
-- Game: AppID 1004040
addappid(1004040)
addappid(1004041, 1, "688437ed1cc75e551eea45e46b47431fe0592b358f102c48e32de01d8b07f241")
addappid(1248340, 0, "f0b1503ecc624e742b1208fece3f3b18dca39d6c9946464398ec9bbb91f8b4f1")
