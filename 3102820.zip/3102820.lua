-- Lua provided by RyzenAPI
-- Game: X Roulette 💋🔞

-- MAIN APPLICATION
addappid(3102820)
-- Game: addappid(3102820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3102821, 1, "09325a776c1c43aed1cc1630182196e9858f3031fb31a507848a82d248f3e43e")
