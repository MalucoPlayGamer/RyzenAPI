-- Lua provided by RyzenAPI
-- Game: addappid(2406870)

-- MAIN APPLICATION
addappid(2406870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406871, 1, "5db7dd78407cc8c22f304dbdb997f06e67e6773633dc31413862b2800254ebe1")
