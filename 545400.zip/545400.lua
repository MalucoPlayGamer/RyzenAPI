-- Lua provided by RyzenAPI
-- Game: Natural - Beyond Nature -

-- MAIN APPLICATION
addappid(545400)

-- MAIN APP DEPOTS / PACKAGES
addappid(545401,0,"2b07061a482eb194b13cab5241dc8db34ccdf8c08816b02cebbd555185d97ed1")
addappid(545402,0,"4317fe7d2cee519ea608f154994c21298ce37a1a912736ce91c3687dfd4abdfe")
addappid(585160,0,"7d4868a33882ced9db44e99e75425dae9eae8505efaf8c144c18b2aac49b6708")

