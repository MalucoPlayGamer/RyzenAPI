-- Lua provided by RyzenAPI
-- Game: Animal Falling Playtest

-- MAIN APPLICATION
addappid(3288030)
-- Game: addappid(3288030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288031, 1, "8529084bd96c70ae36b4f6990fc0dc3c3b913c5db9684d0fb2e8bdf9be41afd6")
