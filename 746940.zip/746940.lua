-- Lua provided by RyzenAPI
-- Game: addappid(746940)

-- MAIN APPLICATION
addappid(746940)

-- MAIN APP DEPOTS / PACKAGES
addappid(746941, 1, "c7d850fccf73bacbf5199248f294c139e21c066f058daedaa67b26d82609317d")
addappid(746942, 1, "cc6f5bd0896eaaca6201e4f4c289c8b2067ff2b3157812b8d76c2fe3b02aaaf4")
addappid(746943, 1, "8ff3b5de7fede7f1dfe2734cc35a4f1f5ff2db67c3370dc7d259d65dcad1595f")
