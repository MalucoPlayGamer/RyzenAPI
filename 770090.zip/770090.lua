-- Lua provided by RyzenAPI
-- Game: AppID 770090

-- MAIN APPLICATION
addappid(770090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(770091, 1, "1ba32408fa13e5bb5eaa7502201d45e1b784b537db3742921cefb722e589cb40")

