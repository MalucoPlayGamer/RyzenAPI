-- Lua provided by RyzenAPI
-- Game: Game: AppID 770090

-- MAIN APPLICATION
addappid(770090)
-- Game: addappid(770090)

-- MAIN APP DEPOTS / PACKAGES
addappid(770091, 1, "1ba32408fa13e5bb5eaa7502201d45e1b784b537db3742921cefb722e589cb40")
