-- Lua provided by SkyAPI 
-- Game: Pinball FX
addappid(2328760)
addappid(2328761, 1, "ebd3cd9ab224746406fbcb2a4d335eaf3c716feea7869b67121f22b2ed8401ef")
