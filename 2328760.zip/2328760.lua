-- Lua provided by RyzenAPI
-- Game: 2328760

-- MAIN APPLICATION
addappid(2328760)
-- Game: addappid(2328760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328761, 1, "ebd3cd9ab224746406fbcb2a4d335eaf3c716feea7869b67121f22b2ed8401ef")
