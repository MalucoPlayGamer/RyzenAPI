-- Lua provided by SkyAPI 
-- Game: 帷幕 Playtest
addappid(2810060)
addappid(2810061, 1, "dc66d5764b8a26565fef307bd5ee315c626894e320d993808978d1c0245db68c")
