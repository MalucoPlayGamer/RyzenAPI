-- Lua provided by RyzenAPI
-- Game: Game: 帷幕 Playtest

-- MAIN APPLICATION
addappid(2810060)
-- Game: addappid(2810060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810061, 1, "dc66d5764b8a26565fef307bd5ee315c626894e320d993808978d1c0245db68c")
