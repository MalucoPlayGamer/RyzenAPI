-- Lua provided by RyzenAPI
-- Game: 656210

-- MAIN APPLICATION
addappid(656210)
-- Game: addappid(656210)

-- MAIN APP DEPOTS / PACKAGES
addappid(656211, 1, "ecf9aac3ebc104f5b0b4edb754a1634b90a3214e1dbd955ef8c8687abc6acaac")
