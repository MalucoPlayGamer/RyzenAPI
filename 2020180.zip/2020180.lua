-- Lua provided by RyzenAPI
-- Game: 2020180

-- MAIN APPLICATION
addappid(2020180)
-- Game: addappid(2020180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020181, 1, "aea9f23b5f8598d9789eeb02e6ab314510f79496f6c623c91e5289ca54e5738c")
