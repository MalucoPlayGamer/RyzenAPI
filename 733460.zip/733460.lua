-- Lua provided by RyzenAPI
-- Game: First Feudal

-- MAIN APPLICATION
addappid(733460)

-- MAIN APP DEPOTS / PACKAGES
addappid(733461, 1, "e856fd9d2e84507c88c02a549fe575b3ff174ea91d83ed4c0aa9d549f606dd30")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
