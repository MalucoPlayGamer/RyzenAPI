-- Lua provided by RyzenAPI
-- Game: Save Your Nuts

-- MAIN APPLICATION
addappid(752170)
-- Game: addappid(752170)

-- MAIN APP DEPOTS / PACKAGES
addappid(752174,0,"4aa45f60569468928422c41077e56032e23768af574a248f15d0612e02158abb")
