-- Lua provided by RyzenAPI
-- Game: Lost Remnant: Roaches to Riches

-- MAIN APPLICATION
addappid(1386020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386021, 1, "bd7ca1fb49e7851c4b41948d5e717c8868f0106d80709dc5fb443c9d4716c30f")
