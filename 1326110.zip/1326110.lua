-- Lua provided by RyzenAPI
-- Game: 1326110

-- MAIN APPLICATION
addappid(1326110)
-- Game: addappid(1326110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326111, 1, "f072ac5639510def17bae668c0d1ec844e1fb7c70260e46ff3077d065be60c8f")
