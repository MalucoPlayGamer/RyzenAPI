-- Lua provided by RyzenAPI
-- Game: Kris and the City of Pleasure

-- MAIN APPLICATION
addappid(2130680)
-- Game: addappid(2130680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130681, 1, "515e96947dfe7d11952bf85c37c6aa1c9c21378db885a66413d8777746f18f27")
addappid(2130682, 1, "b8a935f92f1820c8458e792b55260f85ef0eddee500bf8b2c023fe6382023cca")
addappid(2130683, 1, "9f2a3aa9e943d044aac6e5f1a3a05c28d48c1f2dd0548902f8c1c1c45bcf4f6c")
addappid(2130684, 1, "8773595479a1a867b4db8ef6320fe7c84cc0f284c489e184f11fa4ea868282a5")
