-- 4259520's Lua and Manifest Created by Hubcap Manifest
-- 鼠吃跑 Hamster, Eat, Run
-- Created: July 28, 2026 at 11:12:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4259520) -- 鼠吃跑 Hamster, Eat, Run
-- MAIN APP DEPOTS
addappid(4259521, 1, "0818e56de5f03384e8718f50f56cb73d90204479069aafbfb5b1143bd27b99dd") -- Depot 4259521
setManifestid(4259521, "6547957404306213980", 235948304)