-- Lua provided by RyzenAPI
-- Game: Game: AppID 3298610

-- MAIN APPLICATION
addappid(3298610)
-- Game: addappid(3298610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298611, 1, "50a3f05bfb5a8cf34ba33054737b8dc034884818ce71ba76c589e55c5f720e59")
