-- Lua provided by RyzenAPI
-- Game: Polity - Online Role Playing

-- MAIN APPLICATION
addappid(1479480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479481, 1, "ac02323da1f0f8c3ae5798e339740a9db9dd2a68079178c939219ad736036932")
addappid(1479482, 1, "d30c507bccb676cfdcba7defc3f7d3424fcca97086be1a8ce62ed1252e03bd3b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1606160)
addappid(1606161)
addappid(1606162)
addappid(1606163)
