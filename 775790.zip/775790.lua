-- Lua provided by SkyAPI 
-- Game: AppID 775790
addappid(775790)
addappid(775791, 1, "d2bd4fbb95f5930a252611cbd320e707a3f5336fe23d738f52ccd7d0ce2e8a5b")
