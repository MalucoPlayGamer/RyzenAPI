-- Lua provided by RyzenAPI
-- Game: AppID 775790

-- MAIN APPLICATION
addappid(775790)
-- Game: addappid(775790)

-- MAIN APP DEPOTS / PACKAGES
addappid(775791, 1, "d2bd4fbb95f5930a252611cbd320e707a3f5336fe23d738f52ccd7d0ce2e8a5b")
