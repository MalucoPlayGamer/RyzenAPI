-- Lua provided by RyzenAPI
-- Game: 1815190

-- MAIN APPLICATION
addappid(1815190)
-- Game: addappid(1815190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815191, 1, "ef2fb83bfc9b1d3414548b24a3fc7af4d4beb2952e06fe6f8152415a3e05c2f8")
