-- Lua provided by RyzenAPI
-- Game: Crossout

-- MAIN APPLICATION
addappid(386180)

-- MAIN APP DEPOTS / PACKAGES
addappid(386182,0,"5e393372d81e7c956cd5a9b7ecd84f7d40fd29439941954b81901ff128e1899e")

