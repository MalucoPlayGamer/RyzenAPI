-- Lua provided by RyzenAPI
-- Game: 929200

-- MAIN APPLICATION
addappid(929200)
-- Game: addappid(929200)

-- MAIN APP DEPOTS / PACKAGES
addappid(929201, 1, "a5822d626c236205f9e9ebb89124d4977e801ddad11e758e5c127b3ae35939d8")
