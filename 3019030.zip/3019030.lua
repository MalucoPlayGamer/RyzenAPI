-- Lua provided by RyzenAPI 
-- Game: Survivor in the Forest 2
addappid(3019030)
addappid(3019031, 1, "25cf8d74f2cc95ad7ad421b8f4844f26a33d1e36b9e63929e54d1a51048c50c9")
