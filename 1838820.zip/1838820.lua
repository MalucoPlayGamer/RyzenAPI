-- Lua provided by RyzenAPI
-- Game: Life of a Space Force Captain

-- MAIN APPLICATION
addappid(1838820)
-- Game: addappid(1838820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838821, 1, "04ef79892983834d2fda8d95fe4b81ace0dcdb97ff973309ac4f337442305dd8")
