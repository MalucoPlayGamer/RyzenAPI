-- Lua provided by RyzenAPI
-- Game: addappid(3144640)

-- MAIN APPLICATION
addappid(3144640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144641, 1, "4df401c4ad2c3c5cf2d770112a2f8716ef5541f2d3acdb7e6878622ed1c997a0")
