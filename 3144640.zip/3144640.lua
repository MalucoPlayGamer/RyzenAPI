-- Lua provided by RyzenAPI
-- Game: Skoof Simulator

-- MAIN APPLICATION
addappid(3144640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144641, 1, "4df401c4ad2c3c5cf2d770112a2f8716ef5541f2d3acdb7e6878622ed1c997a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
