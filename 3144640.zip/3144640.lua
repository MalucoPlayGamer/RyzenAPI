-- Lua provided by RyzenAPI 
-- Game: Skoof Simulator
addappid(3144640)
addappid(3144641, 1, "4df401c4ad2c3c5cf2d770112a2f8716ef5541f2d3acdb7e6878622ed1c997a0")
