-- Lua provided by RyzenAPI
-- Game: 2602550

-- MAIN APPLICATION
addappid(2602550)
-- Game: addappid(2602550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602551, 1, "8d4ee254aef9b1ca38ef942e76f3681a6a8fff33f18a3376fa6606ee488e5bb1")
