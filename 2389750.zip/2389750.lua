-- Lua provided by RyzenAPI 
-- Game: Afterimage: Soundtrack
addappid(2389750)
addappid(2389751, 1, "2bd3bcfa7684ceccb237deffd1747c73fa4d7c8da81d2d40a365ad33af033fa8")
addappid(2389752, 1, "5335553b01cc340c1c685c35ff4522e0c6e3bbfb9492d457ce76b10b7718167a")
