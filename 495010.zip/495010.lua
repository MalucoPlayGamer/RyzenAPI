-- Lua provided by RyzenAPI
-- Game: Game: Ranger of the jungle

-- MAIN APPLICATION
addappid(495010)
-- Game: addappid(495010)

-- MAIN APP DEPOTS / PACKAGES
addappid(495011, 1, "df330557c32ab7bee540310ad83c4270eb9e7fa8273ee170394c8288e6abb190")
