-- Lua provided by RyzenAPI
-- Game: Ranger of the jungle

-- MAIN APPLICATION
addappid(495010)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(495011, 1, "df330557c32ab7bee540310ad83c4270eb9e7fa8273ee170394c8288e6abb190")

