-- Lua provided by RyzenAPI
-- Game: Reioku - Ghost house -

-- MAIN APPLICATION
addappid(3461950)
-- Game: addappid(3461950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461951, 1, "6c596e6d7c3452598d7ddaed1c6e5ac3f969e81668a5e3df10c336abd176cd9e")
