-- Lua provided by RyzenAPI
-- Game: AppID 1589740

-- MAIN APPLICATION
addappid(1589740)
-- Game: addappid(1589740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589741, 1, "04de72929af2105ff4c79fddd3bf44b81c6ed7e06ba479d29a6327a6c7ef0785")
