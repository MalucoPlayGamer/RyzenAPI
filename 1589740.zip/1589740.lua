-- Lua provided by SkyAPI 
-- Game: AppID 1589740
addappid(1589740)
addappid(1589741, 1, "04de72929af2105ff4c79fddd3bf44b81c6ed7e06ba479d29a6327a6c7ef0785")
