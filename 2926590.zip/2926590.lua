-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Mature, Level-Headed, and Dependable Secretary Maid GP-01fb

-- MAIN APPLICATION
addappid(2926590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926591, 1, "d3e8f3d6a2ae4f5bf41b7afc08fb332e6c24a08acb6639f60d43bf8f49850f9a")
addappid(2926592, 1, "5dcb566a4244b00194e61381a817fa228bf90e41d028d2c40cf840a6da8ffdf2")

