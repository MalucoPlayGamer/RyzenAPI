-- Lua provided by RyzenAPI 
-- Game: Minigame Madness Lite
addappid(1827800)
addappid(1827801, 1, "887399a7c54c68ebff7a46e1d21929130ab94e9940c762b0b6fe3ed78106e345")
