-- Lua provided by RyzenAPI
-- Game: Wanting Wings

-- MAIN APPLICATION
addappid(2685610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685611, 1, "482920a3232da8adb1122fea2fdf68d6c1b207ee7dfdb7849eba5ef3cdda1734")

