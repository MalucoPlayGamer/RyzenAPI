-- Lua provided by SkyAPI 
-- Game: Wanting Wings
addappid(2685610)
addappid(2685611, 1, "482920a3232da8adb1122fea2fdf68d6c1b207ee7dfdb7849eba5ef3cdda1734")
