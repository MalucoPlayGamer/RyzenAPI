-- Lua provided by RyzenAPI 
-- Game: AppID 842590
addappid(842590)
addappid(842591, 1, "90a7360c5357493420d05f3e086f92f527a32ab440996e4d0a955e530a913d7f")
