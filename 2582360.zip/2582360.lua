-- Lua provided by RyzenAPI
-- Game: An Arcade Full of Cats: TimeWarp Trouble

-- MAIN APPLICATION
addappid(2582360)
-- Game: addappid(2582360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582360,0,"438156b9a03fd5ead6d6a54eb32684df376111e0637c015bdf28a21efcc7b0b3")
