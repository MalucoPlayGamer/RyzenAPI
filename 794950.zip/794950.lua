-- Lua provided by RyzenAPI
-- Game: Game: The Frosty Leaves 寒叶下的薄冰

-- MAIN APPLICATION
addappid(794950)
-- Game: addappid(794950)

-- MAIN APP DEPOTS / PACKAGES
addappid(794951, 1, "671f507325a045792fb6bda21705427c5514b85125ca9a53f0730f4f8dfc4aee")
