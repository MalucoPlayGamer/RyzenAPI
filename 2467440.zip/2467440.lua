-- Lua provided by RyzenAPI
-- Game: Game: VTuber Beats Demo

-- MAIN APPLICATION
addappid(2467440)
-- Game: addappid(2467440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467441, 1, "2ebe44bfae24e9ca43982409265127713b1e2adffcf7b143d10042e4d87c7552")
