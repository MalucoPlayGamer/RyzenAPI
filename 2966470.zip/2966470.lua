-- Lua provided by RyzenAPI
-- Game: I dont Fall

-- MAIN APPLICATION
addappid(2966470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2966471, 1, "310dae15931c36c16dc93b44dc6ddf6fe52d9c8bfe07078f610e00052375f467")

