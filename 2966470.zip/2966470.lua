-- Lua provided by RyzenAPI
-- Game: 2966470

-- MAIN APPLICATION
addappid(2966470)
-- Game: addappid(2966470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966471, 1, "310dae15931c36c16dc93b44dc6ddf6fe52d9c8bfe07078f610e00052375f467")
