-- Lua provided by SkyAPI 
-- Game: Code of War Gun Shooting Games
addappid(2430360)
addappid(2430361, 1, "18f9581718c1058546146d93cad729c9cdd8d3da3401416757e5f5cb546f81b6")
addappid(2430362, 1, "b3ce4f1dd31c556b91e577367a66e7b9fbd69ac1e13f8edbb2ccf97992f1df59")
addappid(2430363, 1, "b83d67c2bdd5613d88c9be823477c67f71e2aa4585bd61c65203c1d1c22338fc")
