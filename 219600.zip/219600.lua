-- Lua provided by RyzenAPI 
-- Game: AppID 219600
addappid(219600)
addappid(219601, 1, "23b7d1205a37743c80fdab6b511280c2339332f2c908ea82b4ca4ac97cebb9ad")
