-- Lua provided by RyzenAPI
-- Game: Ruin

-- MAIN APPLICATION
addappid(663950)
