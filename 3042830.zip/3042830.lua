-- Lua provided by SkyAPI 
-- Game: AppID 3042830
addappid(3042830)
addappid(3042831, 1, "b301d0c0dccd9129b1e9a51096558f76f2ab207b7b5615ec280aa435b590c3ee")
