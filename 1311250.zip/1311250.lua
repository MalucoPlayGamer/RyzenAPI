-- Lua provided by RyzenAPI
-- Game: Don't Be Afraid - The First Toy

-- MAIN APPLICATION
addappid(1311250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311251, 1, "f0b1c937fcfe71f4563879963b73f9cc7966c7d1e2ab5fee2f43d63e6e3b6de4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
