-- Lua provided by RyzenAPI
-- Game: Don't Be Afraid - The First Toy

-- MAIN APPLICATION
addappid(1311250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311251, 1, "f0b1c937fcfe71f4563879963b73f9cc7966c7d1e2ab5fee2f43d63e6e3b6de4")

