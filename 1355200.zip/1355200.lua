-- Lua provided by RyzenAPI
-- Game: Uber Destruction

-- MAIN APPLICATION
addappid(1355200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355201, 1, "9f63832e7939b58fd22d544330da03a14cfaff2419492410844d174cd56208f4")
