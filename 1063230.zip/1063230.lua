-- Lua provided by RyzenAPI
-- Game: 6120

-- MAIN APPLICATION
addappid(1063230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1063231, 1, "8ea4f71f69240faac068b7872bb5b8b578ccb93561b925190729b03ca4095003")
