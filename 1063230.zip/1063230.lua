-- Lua provided by RyzenAPI
-- Game: Game: AppID 1063230

-- MAIN APPLICATION
addappid(1063230)
-- Game: addappid(1063230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063231, 1, "8ea4f71f69240faac068b7872bb5b8b578ccb93561b925190729b03ca4095003")
