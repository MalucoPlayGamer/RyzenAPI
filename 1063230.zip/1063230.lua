-- Lua provided by SkyAPI 
-- Game: AppID 1063230
addappid(1063230)
addappid(1063231, 1, "8ea4f71f69240faac068b7872bb5b8b578ccb93561b925190729b03ca4095003")
