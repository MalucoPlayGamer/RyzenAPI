-- Lua provided by SkyAPI 
-- Game: Pig Eat Ball
addappid(339090)
addappid(339091, 1, "5594bb3058af7e98191def2dceae5af4df4fd20741fd00c79e6a344c30abbcaa")
