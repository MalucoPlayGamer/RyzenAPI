-- Lua provided by RyzenAPI
-- Game: Pig Eat Ball

-- MAIN APPLICATION
addappid(339090)

-- MAIN APP DEPOTS / PACKAGES
addappid(339091, 1, "5594bb3058af7e98191def2dceae5af4df4fd20741fd00c79e6a344c30abbcaa")

