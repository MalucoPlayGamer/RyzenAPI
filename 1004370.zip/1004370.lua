-- Lua provided by RyzenAPI
-- Game: Game: Paper Cut Mansion

-- MAIN APPLICATION
addappid(1004370)
-- Game: addappid(1004370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004371, 1, "36a1bc5541f99d5ca44710553cd91971acf784f08e2a8623d4f129cc1b03b53a")
