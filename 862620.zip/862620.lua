-- Lua provided by RyzenAPI
-- Game: 862620

-- MAIN APPLICATION
addappid(862620)
-- Game: addappid(862620)

-- MAIN APP DEPOTS / PACKAGES
addappid(862621, 1, "4976124449ce2afe3fde02ebc5207f591902610af271dcd75b00463402c2f117")
