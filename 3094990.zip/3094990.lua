-- 3094990's Lua and Manifest Created by Hubcap Manifest
-- Wish Creatures
-- Created: August 15, 2026 at 14:20:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3094990) -- Wish Creatures
-- MAIN APP DEPOTS
addappid(3094992, 1, "550b70cfceff669724431303772b5a3e53e5667fc39fa5dc62253f9acffe59e0") -- Depot 3094992
setManifestid(3094992, "2594057823162509567", 403751853)