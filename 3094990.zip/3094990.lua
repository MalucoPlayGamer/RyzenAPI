-- Lua provided by RyzenAPI
-- Game: Wish Creatures

-- MAIN APPLICATION
addappid(3094990) -- Wish Creatures

-- MAIN APP DEPOTS / PACKAGES
addappid(3094992, 1, "550b70cfceff669724431303772b5a3e53e5667fc39fa5dc62253f9acffe59e0") -- Depot 3094992

