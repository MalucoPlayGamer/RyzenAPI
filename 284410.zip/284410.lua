-- Lua provided by RyzenAPI
-- Game: 284410

-- MAIN APPLICATION
addappid(284410)
-- Game: addappid(284410)

-- MAIN APP DEPOTS / PACKAGES
addappid(284411, 1, "4c4ea47c779563db226920e5e8bb47eff9073045db9f8e97f3556aed01e1faf1")
addappid(284412, 1, "b6217854e0407519b5c693af970cbb2eea1515f7b6cfaa87d2c478ece7ae145c")
addappid(284413, 1, "14b00af33d84ea169ed3ae98e0676ee1c25de065fa6c7a8cc7fd0ac9430a2d81")
