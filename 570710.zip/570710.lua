-- Lua provided by RyzenAPI
-- Game: Extinction

-- MAIN APPLICATION
addappid(570710)

-- MAIN APP DEPOTS / PACKAGES
addappid(570711, 1, "5a15e842d809e66b9d7c5eb1ebd8e6075afe72c750c610168442a91ec2810abe")
