-- Lua provided by RyzenAPI
-- Game: addappid(2222150)

-- MAIN APPLICATION
addappid(2222150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222151, 1, "ee4c94846305c1b1a116456f02332670f60ad7db1ec23674a6dc5d1b59acaef7")
