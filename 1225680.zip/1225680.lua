-- Lua provided by RyzenAPI
-- Game: Game: AppID 1225680

-- MAIN APPLICATION
addappid(1225680)
-- Game: addappid(1225680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225681, 1, "0fb5ce7a88817c0a43c1a353e5412d0355b096ca346f82152696d105b9167ef1")
