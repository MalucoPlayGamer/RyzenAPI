-- Lua provided by RyzenAPI
-- Game: Lewd Dungeon Manager 🔞

-- MAIN APPLICATION
addappid(4657580) -- Lewd Dungeon Manager 🔞

-- MAIN APP DEPOTS / PACKAGES
addappid(4657581, 1, "6dc18903910b33172e62e72917b7350ce5cf150415c3d65af43b6d3d020c8c53") -- Depot 4657581
addappid(4657582, 1, "6faa3ab62303dbed6046d0dee07d5c44584b08baf43d781675ebc027452540af") -- Depot 4657582
addappid(4657583, 1, "5deb2d1928550e8034340ff183fc15f139075fabf02efcedb14f897aca87762a") -- Depot 4657583

