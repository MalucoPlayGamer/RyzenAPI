-- Lua provided by SkyAPI 
-- Game: AppID 489700
addappid(489700)
addappid(489701, 1, "20dae978bd873809b36d0cf9cc8b79f85a5c231a3dd8651513abdd094a1f4b5e")
