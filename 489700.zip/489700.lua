-- Lua provided by RyzenAPI
-- Game: addappid(489700)

-- MAIN APPLICATION
addappid(489700)

-- MAIN APP DEPOTS / PACKAGES
addappid(489701, 1, "20dae978bd873809b36d0cf9cc8b79f85a5c231a3dd8651513abdd094a1f4b5e")
