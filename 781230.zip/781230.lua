-- Lua provided by RyzenAPI
-- Game: addappid(781230)

-- MAIN APPLICATION
addappid(781230)

-- MAIN APP DEPOTS / PACKAGES
addappid(781231, 1, "434425846905779b0044b0f1ddb09bfde6c1179c03cdcc965bca96e6d75dbf0e")
