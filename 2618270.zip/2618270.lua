-- Lua provided by RyzenAPI
-- Game: Project Werewulf Demo

-- MAIN APPLICATION
addappid(2618270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618271, 1, "78069c5d6e67f7967aec6a99fc41bd7ddb25723f7498399a267991589cf692c2")

