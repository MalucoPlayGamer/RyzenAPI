-- Lua provided by RyzenAPI
-- Game: addappid(1558250)

-- MAIN APPLICATION
addappid(1558250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558250,0,"f47eaf646b3d45dcd5500b275c456a2f345e3c2af1e09ed0c157d45ae8c049b2")
