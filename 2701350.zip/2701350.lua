-- Lua provided by SkyAPI 
-- Game: Dragon Chronicles: Black Tears
addappid(2701350)
addappid(2701351, 1, "c519152f7cb9a109cc7ad8b1929c306f0a18d43506ba52ea602c36bc81724ed2")
