-- Lua provided by RyzenAPI
-- Game: Dragon Chronicles: Black Tears

-- MAIN APPLICATION
addappid(2701350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701351, 1, "c519152f7cb9a109cc7ad8b1929c306f0a18d43506ba52ea602c36bc81724ed2")
