-- Lua provided by RyzenAPI
-- Game: Store Wars: Prologue - Multiplayer Shop Simulator

-- MAIN APPLICATION
addappid(3308210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308211, 1, "9d75449a536e814829e0f91b9b8b6aa381d50a46585589e81acafdd8eb32a0e9")
