-- Lua provided by RyzenAPI
-- Game: addappid(658600)

-- MAIN APPLICATION
addappid(658600)

-- MAIN APP DEPOTS / PACKAGES
addappid(658601, 1, "0594369257bb139e3594e36f5cba82130ee5306b2dc083111d801dd8aeecc945")
