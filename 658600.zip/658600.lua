-- Lua provided by RyzenAPI
-- Game: Lawnmower Game

-- MAIN APPLICATION
addappid(658600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(658601, 1, "0594369257bb139e3594e36f5cba82130ee5306b2dc083111d801dd8aeecc945")

