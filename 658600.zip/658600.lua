-- Lua provided by SkyAPI 
-- Game: Lawnmower Game
addappid(658600)
addappid(658601, 1, "0594369257bb139e3594e36f5cba82130ee5306b2dc083111d801dd8aeecc945")
