-- Lua provided by RyzenAPI
-- Game: Five Nights at Silver Pine

-- MAIN APPLICATION
addappid(2901210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2901211, 1, "82e385e09e31ad169a7f8bc2acaef97470d2271c8996a04d7ea52f8e98657c68")

