-- Lua provided by RyzenAPI
-- Game: Game: Five Nights at Silver Pine

-- MAIN APPLICATION
addappid(2901210)
-- Game: addappid(2901210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901211, 1, "82e385e09e31ad169a7f8bc2acaef97470d2271c8996a04d7ea52f8e98657c68")
