-- Lua provided by RyzenAPI
-- Game: Game: Metal Slug Tactics (Original Game Soundtrack)

-- MAIN APPLICATION
addappid(3283800)
-- Game: addappid(3283800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3283801, 1, "590eec6e642f2fc671e08522c19e91b0a319a8b4a2ddcbe398a332d22e2cc144")
