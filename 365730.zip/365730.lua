-- Lua provided by RyzenAPI
-- Game: Gilbert Goodmate and the Mushroom of Phungoria

-- MAIN APPLICATION
addappid(365730)
-- Game: addappid(365730)

-- MAIN APP DEPOTS / PACKAGES
addappid(365731, 1, "3ed130db41e50c3b1c28a1ea29d96449e6163cc554a49e459820b7192051fcbd")
