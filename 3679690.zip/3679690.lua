-- Lua provided by RyzenAPI
-- Game: 3679690

-- MAIN APPLICATION
addappid(3679690)
-- Game: addappid(3679690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3679692,0,"95de08fa9bf9730bd06aa98430f0916a5e85846867cbefc0b65ae0b00bdde107")
