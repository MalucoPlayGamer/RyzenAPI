-- Lua provided by RyzenAPI
-- Game: AppID 1925030

-- MAIN APPLICATION
addappid(1925030)
-- Game: addappid(1925030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925031, 1, "e5959523da98ccb7232e062687b46e80a6c020e45c68c9faaec4523177dd0278")
