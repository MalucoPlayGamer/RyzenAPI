-- Lua provided by SkyAPI 
-- Game: AppID 951430
addappid(951430)
addappid(951431, 1, "725a4c43d135b7a2a88f31b230fa673d5fd1b368ff63d872b3f68fb91fceed05")
addappid(951432, 1, "a881f9e28189dcb78f84a8d2d7e8dba3f7e5341ffc95e689f2a47edbaccb78e0")
addappid(951433, 1, "14054dfc84dedefd8dbd0d364590f4b26959222a0dd9d9f9cf821e4a0d0e518d")
