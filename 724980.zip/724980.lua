-- Lua provided by RyzenAPI
-- Game: Winter Warland

-- MAIN APPLICATION
addappid(724980)

-- MAIN APP DEPOTS / PACKAGES
addappid(724981,0,"e0a5c69f9a9ecde1bb5b15bba9a6a28fd477a0d7a000e3e1b5b9456615862b67")

