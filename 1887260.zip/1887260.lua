-- Lua provided by RyzenAPI
-- Game: Timberman VR 

-- MAIN APPLICATION
addappid(1887260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887263,0,"a7e04ab0d391e6917abd8a7254f20acdc3cdcd7330e474c598462cd51047fd89")

