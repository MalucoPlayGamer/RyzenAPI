-- Lua provided by SkyAPI 
-- Game: 18 Wheels of Steel: Extreme Trucker 2
addappid(362780)
addappid(362781, 1, "cb12b7ee0a1bbeea3fd6985fd2c04a3e201fb131f92abe5df166f9fa83e9f83f")
