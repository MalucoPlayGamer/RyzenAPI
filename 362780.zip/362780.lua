-- Lua provided by RyzenAPI
-- Game: Game: 18 Wheels of Steel: Extreme Trucker 2

-- MAIN APPLICATION
addappid(362780)
-- Game: addappid(362780)

-- MAIN APP DEPOTS / PACKAGES
addappid(362781, 1, "cb12b7ee0a1bbeea3fd6985fd2c04a3e201fb131f92abe5df166f9fa83e9f83f")
