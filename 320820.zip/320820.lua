-- Lua provided by RyzenAPI
-- Game: Toren

-- MAIN APPLICATION
addappid(320820)
-- Game: addappid(320820)

-- MAIN APP DEPOTS / PACKAGES
addappid(320821, 1, "25c55dd7620548e65d11668ee5f7ffc2e56a58d9a5d634ce1a409dadac4fc5fb")
addappid(320822, 1, "ff57cc4d66324cf5266a6f5359651459e3643b9e513c98f8e298b0ca899ab542")
addappid(320823, 1, "d417a0194d833595de42301b88c58c610c3f0c3149636d2fd1a78ca2c9fc34a6")
