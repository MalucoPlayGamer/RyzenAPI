-- Lua provided by RyzenAPI
-- Game: 2410500

-- MAIN APPLICATION
addappid(2410500)
-- Game: addappid(2410500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410501, 1, "114e6436298fcb299e27f5032551bef5f1266280b2b13aff4d2d713edcdc8f82")
