-- Lua provided by RyzenAPI
-- Game: Plantabi: Little Garden

-- MAIN APPLICATION
addappid(2764070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764071, 1, "a0fa53eced986ef628b80f56f8209f33b1015b7f9dbbf880967e01366dcbb09b")
addappid(2764072, 1, "15e4e7a7592e48a992af9e28fb2b8ffe52c1a1d8d083d7fccdf28becbf72a87c")
