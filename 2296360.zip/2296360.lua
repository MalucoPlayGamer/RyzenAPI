-- Lua provided by RyzenAPI
-- Game: Groupy 2

-- MAIN APPLICATION
addappid(2296360)
-- Game: addappid(2296360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296361, 1, "a226a7056e62c52a5724941b2bce97244eb11319125c6f1ba00c3ea6bec14cc1")
