-- Lua provided by RyzenAPI 
-- Game: Arken Age
addappid(2274200)
addappid(2274201, 1, "23fe823eb2d203e3fe4e1aabc4a7e6e449c1422b95bb39a3b6b117970cc45ba3")
