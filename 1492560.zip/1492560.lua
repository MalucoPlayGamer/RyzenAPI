-- Lua provided by RyzenAPI
-- Game: Paradise Killer: Art of Paradise

-- MAIN APPLICATION
addappid(1492560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492560,0,"b6f856b763c5b6820f3ed8d3ab6eaca84c48657e425afd9133c3ea316442013d")

