-- Lua provided by RyzenAPI
-- Game: The Edgar Mitchell Overview Effect VR Experience

-- MAIN APPLICATION
addappid(1445700)
-- Game: addappid(1445700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445701, 1, "9bfeabcc64bfaba3b3df8c96867649ba4fb822ef863dd578eb6bf94f27fdb2b8")
