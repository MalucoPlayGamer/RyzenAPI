-- Lua provided by RyzenAPI
-- Game: Game: KickNSlap

-- MAIN APPLICATION
addappid(1976130)
-- Game: addappid(1976130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976131, 1, "2f7e47dbe306ace297563d87064d66f64491814f6f34b46a0cdbff2674e25e96")
