-- Lua provided by RyzenAPI 
-- Game: Cargo Shop Simulator
addappid(3576250)
addappid(3576251, 1, "b1e5de8e0e7d8cbf73457d7fff630cc22f3d3e8d7646816f3b606a9b8a01ffa4")
