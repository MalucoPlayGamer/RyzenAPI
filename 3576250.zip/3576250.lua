-- Lua provided by RyzenAPI
-- Game: Game: Cargo Shop Simulator

-- MAIN APPLICATION
addappid(3576250)
-- Game: addappid(3576250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3576251, 1, "b1e5de8e0e7d8cbf73457d7fff630cc22f3d3e8d7646816f3b606a9b8a01ffa4")
