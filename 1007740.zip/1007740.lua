-- Lua provided by RyzenAPI
-- Game: Refight:The Last Warship

-- MAIN APPLICATION
addappid(1007740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007741, 1, "1b1ae92243f23fe59575e3ec3f4dc7fd79116a4c203eaa0729a20429485947a7")
