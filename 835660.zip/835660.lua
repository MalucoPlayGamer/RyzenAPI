-- Lua provided by RyzenAPI
-- Game: Circle UP

-- MAIN APPLICATION
addappid(835660)
-- Game: addappid(835660)

-- MAIN APP DEPOTS / PACKAGES
addappid(835669,0,"13c84a430f8b8e69c4d47d480d4a0902529d481627107ed14621aec141e04a11")
