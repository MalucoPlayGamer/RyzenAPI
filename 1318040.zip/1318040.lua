-- Lua provided by RyzenAPI
-- Game: Shady Knight Demo

-- MAIN APPLICATION
addappid(1318040)
-- Game: addappid(1318040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318041, 1, "b99992d1bdda851302b35c12df4db57838859aee6b9c5ed2f146bd6c8fa46193")
