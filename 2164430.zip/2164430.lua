-- Lua provided by RyzenAPI
-- Game: AppID 2164430

-- MAIN APPLICATION
addappid(2164430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164431, 1, "59e6193cfb81d063c76b5bb81a2de23df4cb8d76fd9493444dd2aef9820d3e40")

