-- Lua provided by RyzenAPI
-- Game: addappid(1014460)

-- MAIN APPLICATION
addappid(1014460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014461, 1, "e5140ce01965d0bb8f311ac84e889a6a3247f10a21ef6f730520c7c037a818d7")
addappid(1014463, 1, "b602e52c41ee6e1f06104fcc4c9d21bab7907793e43e3dfc75eb1b8597ac9cec")
