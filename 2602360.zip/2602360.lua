-- Lua provided by RyzenAPI
-- Game: AppID 2602360

-- MAIN APPLICATION
addappid(2602360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602361, 1, "707bd26a5263fbe70167efaef0680a346345a9be6b60482a5da9fc31e6febcd4")
