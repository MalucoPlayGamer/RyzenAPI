-- Lua provided by RyzenAPI
-- Game: Game: BATTLLOON - バトルーン

-- MAIN APPLICATION
addappid(985800)
-- Game: addappid(985800)

-- MAIN APP DEPOTS / PACKAGES
addappid(985801, 1, "65334f7c385ec066bb32f86ea56901e37ffc44747869302e99d5ac47369b5df1")
