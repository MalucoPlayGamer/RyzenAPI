-- Lua provided by RyzenAPI
-- Game: PUNIHI LOADER 2

-- MAIN APPLICATION
addappid(1956960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956961, 1, "8037abf3f6cdd31a268de23fdea45e56e6b9b08e400c4787cb8eb1c79bb59a6c")

