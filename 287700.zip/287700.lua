-- Lua provided by RyzenAPI
-- Game: METAL GEAR SOLID V: THE PHANTOM PAIN

-- MAIN APPLICATION
addappid(287700)
addappid(406540)
addappid(406560)
addappid(406580)
addappid(406590)
addappid(406600)
addappid(406610)
addappid(406620)
addappid(436030)
addappid(436040)
addappid(436050)
addappid(437230)
addappid(437231)
addappid(437232)
addappid(437233)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(287701, 1, "f1c3bbf22c23c0777bf23c71491e2398e216ade65fbd5597762b7fb64165dd4f")
addappid(287702, 1, "5fff13d6b2e316f81e7fbce5e82cc9e77fdcc6c1daa0f723a3f347c1f2017287")

