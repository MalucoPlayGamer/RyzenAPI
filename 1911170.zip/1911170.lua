-- Lua provided by RyzenAPI
-- Game: addappid(1911170)

-- MAIN APPLICATION
addappid(1911170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911171, 1, "b780cd4f516eb7dfb7aea32d92289de7fa8d6abf9883fad0eb73579f96354d93")
