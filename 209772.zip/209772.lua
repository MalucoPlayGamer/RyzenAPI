-- Lua provided by RyzenAPI
-- Game: DEFCON Soundtrack

-- MAIN APPLICATION
addappid(209772)
-- Game: addappid(209772)

-- MAIN APP DEPOTS / PACKAGES
addappid(209772,0,"5016d0a1a73e7ec987d0be4046e7f6ac49291b34e0a11341f29f6d88554ce439")
