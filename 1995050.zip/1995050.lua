-- Lua provided by RyzenAPI
-- Game: Game: AppID 1995050

-- MAIN APPLICATION
addappid(1995050)
-- Game: addappid(1995050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995051, 1, "7a51829e80d9470948e56f9dc1fa9031aae750591524fbced34e16200783c081")
