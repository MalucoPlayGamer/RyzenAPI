-- Lua provided by RyzenAPI
-- Game: 562740

-- MAIN APPLICATION
addappid(562740)
-- Game: addappid(562740)

-- MAIN APP DEPOTS / PACKAGES
addappid(562741, 1, "d027bde7a9715289d45dd12c73deaca769d7ca0a2f55f17eb331dfe4868bf31b")
