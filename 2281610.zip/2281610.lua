-- Lua provided by RyzenAPI
-- Game: Scrappage

-- MAIN APPLICATION
addappid(2281610)
-- Game: addappid(2281610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281611, 1, "0a4a92107c3dd76e58c1b7bf6794d4dcdee42c8a7a8228d7cae35128bf7247bc")
addappid(2281612, 1, "689a2e2b69ef429f78d43623072b9094a3054b88305ece97b0b601ffff47d27d")
addappid(2281613, 1, "40596508a6b8139b15b3125475cbcb1b842656d1fbabaa3f5eb0a3b9daf9abe0")
addappid(2281614, 1, "804a4fbd70cba59c5a48d07d76b6229929a420e4277e631ea76631c5d2d6e3ee")
