-- Lua provided by RyzenAPI
-- Game: Clockwork Survivors

-- MAIN APPLICATION
addappid(2062390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062391, 1, "ae509b6b54c3cc4ca49d46baa2f4ce12ecac905548c56a27fe77da6b25a3d633")
