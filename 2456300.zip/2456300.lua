-- Lua provided by RyzenAPI
-- Game: Game: 汉末霸业免费版

-- MAIN APPLICATION
addappid(2456300)
-- Game: addappid(2456300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456301, 1, "60b14be14da1f6a7c413a706b149498535960549507ceda7bc420036ce0f0f28")
