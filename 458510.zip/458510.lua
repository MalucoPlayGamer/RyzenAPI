-- Lua provided by RyzenAPI
-- Game: Zombie Pinball

-- MAIN APPLICATION
addappid(458510)

-- MAIN APP DEPOTS / PACKAGES
addappid(458511, 1, "dd8f9f89c62322608730aaace25f8b3ad966feeb53c5f794427c22333b68db66")

