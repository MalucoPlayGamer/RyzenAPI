-- Lua provided by RyzenAPI
-- Game: Lila's Tale and the Hidden Forest

-- MAIN APPLICATION
addappid(1622040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622041, 1, "ed871a35b4dcbd7679db049b4e318440380a1fc8211032055dbb82680280b971")

