-- Lua provided by RyzenAPI
-- Game: addappid(2831590)

-- MAIN APPLICATION
addappid(2831590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831591, 1, "2ae9ba5ae099066472cf4025cf0e9356cc3444209bdd457f849cb93e377a215e")
