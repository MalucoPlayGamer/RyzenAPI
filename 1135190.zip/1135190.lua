-- Lua provided by RyzenAPI
-- Game: Sokpop S03: Hoppa

-- MAIN APPLICATION
addappid(1135190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135191, 1, "0ac53098dc4d697096b8a1405cd909b0834b3c481663bae90c5a100986f52fd8")
addappid(1135192, 1, "3f04b1235d4d6cc438f83bf789ccc1fc8567647508dca8ac72fc209d8d5fd4b3")
