-- Lua provided by RyzenAPI
-- Game: AppID 351690

-- MAIN APPLICATION
addappid(351690)
addappid(629470)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(351691, 1, "f601d49a401c52b98d81a86ab1a9cce88f6d248b459a0c5956d6acf9d001aaa0")

