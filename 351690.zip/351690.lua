-- Lua provided by RyzenAPI
-- Game: AppID 351690

-- MAIN APPLICATION
addappid(351690)

-- MAIN APP DEPOTS / PACKAGES
addappid(351691, 1, "f601d49a401c52b98d81a86ab1a9cce88f6d248b459a0c5956d6acf9d001aaa0")

