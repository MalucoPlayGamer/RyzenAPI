-- Lua provided by RyzenAPI
-- Game: The Deep Diving of FloodDragon

-- MAIN APPLICATION
addappid(1005490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005491, 1, "781d1c9ce1e622644e11402d6dc64ef8222831aa5791e57f24962685ae4ca9c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
