-- Lua provided by RyzenAPI
-- Game: The Deep Diving of FloodDragon

-- MAIN APPLICATION
addappid(1005490)
-- Game: addappid(1005490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005491, 1, "781d1c9ce1e622644e11402d6dc64ef8222831aa5791e57f24962685ae4ca9c0")
