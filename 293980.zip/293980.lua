-- Lua provided by RyzenAPI
-- Game: Baron Wittard

-- MAIN APPLICATION
addappid(293980)

-- MAIN APP DEPOTS / PACKAGES
addappid(293981, 1, "796b82c49712bdb848a8ac4ae458f3fac7a129fdaa5d5d668dadc09d06871688")

