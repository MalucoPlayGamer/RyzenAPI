-- Lua provided by RyzenAPI
-- Game: Silent Hunter®: Wolves of the Pacific U-Boat Missions

-- MAIN APPLICATION
addappid(15240)

-- MAIN APP DEPOTS / PACKAGES
addappid(15241, 1, "d37886ae60eb905805ab60979ddd70d35a3d080def98dd8abacdcee525f544bc")

