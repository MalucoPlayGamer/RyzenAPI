-- Lua provided by RyzenAPI
-- Game: 人生牌

-- MAIN APPLICATION
addappid(2141230)
-- Game: addappid(2141230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141231, 1, "16a1098c30e92a16e8d4acc4947f36546a23ea989140881940ebae1899f041cc")
