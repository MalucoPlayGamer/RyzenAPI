-- Lua provided by RyzenAPI
-- Game: The Expedition Soundtrack

-- MAIN APPLICATION
addappid(3624230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3624231, 1, "e1a3fc55bf0b0dbed542fcc686200fb52b5cc64a1c25ae9f78fecdf4a3215961")
