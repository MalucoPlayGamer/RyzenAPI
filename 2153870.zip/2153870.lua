-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2153870)
addappid(2153871)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153872,0,"8d457689bea1359a61b8bc676238db49b96aec8e56ad39efd92741e9d2db04a6")
