-- Lua provided by RyzenAPI
-- Game: Mountain Trap 2: Under the Cloak of Fear

-- MAIN APPLICATION
addappid(563330)

-- MAIN APP DEPOTS / PACKAGES
addappid(563331, 1, "0ca2bc78276206133a60dd599efa995d767f07eed19eb0384c241616e75ed44c")

