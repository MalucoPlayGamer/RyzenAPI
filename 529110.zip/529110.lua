-- Lua provided by RyzenAPI
-- Game: AppID 529110

-- MAIN APPLICATION
addappid(529110)

-- MAIN APP DEPOTS / PACKAGES
addappid(529111, 1, "80cde27d4b139a87ae8e6f9a49345b2769637b6e8bf5df1257140e2b49d995c9")
addappid(529112, 1, "dd313da603b66a68a7d83c80c947405c6dbec1440203ea3019a7c898a2c416b7")
addappid(529113, 1, "e75721165fda75fc5d6e06d8412567dd28fe4679ecb5db517ea96b0c6302af8f")
addappid(529114, 1, "71355843d4216a87ea49962ddbcfb9c41902e58978bd97bd4c10b5f109d32d58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(542600)
