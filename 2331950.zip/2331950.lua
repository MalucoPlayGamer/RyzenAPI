-- Lua provided by RyzenAPI
-- Game: WebCum Empire Tycoon 📷 💦

-- MAIN APPLICATION
addappid(2331950)
-- Game: addappid(2331950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331951, 1, "dccbd3002993222eb340f8205661e10a01a8c171584e9ec4213011d94d2d1ed8")
