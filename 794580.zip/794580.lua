-- Lua provided by RyzenAPI
-- Game: SNK HEROINES Tag Team Frenzy

-- MAIN APPLICATION
addappid(794580)
addappid(1016150)

-- MAIN APP DEPOTS / PACKAGES
addappid(794581, 1, "f9dd60ab29de5453b64132c6334e9e19a905335da3f1a822e0131204e8983b29")
addappid(794582, 1, "d49a9cbf59f9372e960c6874086f0377202c2445ea60a5f6f0405614c5a12f4a")
addappid(794584, 1, "67049750303e67d3dff67001816c87f29e3a4ed7b7ff34679966e1a7b76164eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
