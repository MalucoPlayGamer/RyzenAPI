-- Lua provided by RyzenAPI
-- Game: dEskape

-- MAIN APPLICATION
addappid(2390060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390061, 1, "8f48471e2a2397ec02bf330515fa993e7274fd1fc2ab1eb832e710456619b115")
