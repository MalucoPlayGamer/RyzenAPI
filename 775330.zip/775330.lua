-- Lua provided by RyzenAPI
-- Game: AppID 775330

-- MAIN APPLICATION
addappid(775330)

-- MAIN APP DEPOTS / PACKAGES
addappid(775331, 1, "bbe08fceaaa6aac46dad49ebeac8628ad09b7aa16639b558ec3bc6745ce3aa88")

