-- Lua provided by RyzenAPI
-- Game: Game: Solar Settlers

-- MAIN APPLICATION
addappid(655480)
-- Game: addappid(655480)

-- MAIN APP DEPOTS / PACKAGES
addappid(655481, 1, "32d62e2dea1d7069bda63a86e865192c64d852cfe553f5e5b80e2f306727d122")
