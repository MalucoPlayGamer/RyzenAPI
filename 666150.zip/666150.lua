-- Lua provided by RyzenAPI
-- Game: addappid(666150)

-- MAIN APPLICATION
addappid(666150)
addappid(2562771)

-- MAIN APP DEPOTS / PACKAGES
addappid(666151, 1, "e4ed477c5cebc990e21bdc1f3f728043303a3c34a55b2a732e6652b28cbd689d")
