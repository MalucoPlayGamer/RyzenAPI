-- Lua provided by RyzenAPI 
-- Game: Return to abyss 重返深渊
addappid(2185780)
addappid(2185781, 1, "42b07f01a4faa2c66c58d95ce40238638fa3452a0f56e84292fc3509cfefc699")
