-- Lua provided by RyzenAPI
-- Game: Return to abyss 重返深渊

-- MAIN APPLICATION
addappid(2185780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185781, 1, "42b07f01a4faa2c66c58d95ce40238638fa3452a0f56e84292fc3509cfefc699")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2314410)
addappid(2314411)
addappid(2314412)
addappid(2412590)
addappid(2561740)
addappid(2561750)
