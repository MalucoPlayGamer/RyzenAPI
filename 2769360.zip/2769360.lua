-- Lua provided by RyzenAPI
-- Game: Rivals Duel: Card Battler

-- MAIN APPLICATION
addappid(2769360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769361, 1, "b576fb3ad38c2c7a3fba4c768f4132a7147ca3dd81f4c27d6a7df431efd7ddc8")
addappid(2769362, 1, "d5b953fc6f7440743e12c1a4efbaf40166e1b076b842051c47f59b844ec62102")
