-- Lua provided by RyzenAPI
-- Game: The Ditzy Demons Are in Love With Me

-- MAIN APPLICATION
addappid(802870)
addappid(948430)
addappid(1354640)

-- MAIN APP DEPOTS / PACKAGES
addappid(802871,0,"f7bd9e0bc84a1edbe4b04461c405fb6c6c43056e8377392c9f31865df5c5a40f")
addappid(802872,0,"865cbde2be0e694c0f5f4a7ca707cea378da72753409adce96c290ce8917b474")
addappid(802873,0,"68cf1dcd18c717a6a744c562cd69549bb284a775e08d19049c6f4a7beafed5e8")
addappid(802874,0,"30d6998e2adac54b2735a167e70b0aa8909f620d9393b68269497e1fc68a22c3")
addappid(1354640,0,"6356ec08f5b1beb204bb917c640f6b187a6e94122225afe87b74e7eca100be07")

