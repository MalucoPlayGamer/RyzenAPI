-- Lua provided by RyzenAPI
-- Game: 1930740

-- MAIN APPLICATION
addappid(1930740)
-- Game: addappid(1930740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930741, 1, "de4025ff3f73a3b1cd0ce08d51e3efa8f3f0a017b07c6a0f282cbb1e0b120c19")
