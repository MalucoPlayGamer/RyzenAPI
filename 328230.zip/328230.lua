-- Lua provided by RyzenAPI
-- Game: A Bird Story - Original Soundtrack

-- MAIN APPLICATION
addappid(328230)

-- MAIN APP DEPOTS / PACKAGES
addappid(328230,0,"0724e3ff26927d38665292645e8dbe4970a7156e84c86c0e3efe58bffd4980ae")
