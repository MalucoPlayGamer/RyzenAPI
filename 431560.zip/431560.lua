-- Lua provided by RyzenAPI
-- Game: Hard Room

-- MAIN APPLICATION
addappid(431560)

-- MAIN APP DEPOTS / PACKAGES
addappid(431561, 1, "7768fe4492138fc79e48e9350b3dd8756975b5ce6c11e9c8421e12a21a00a729")
