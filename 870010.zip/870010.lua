-- Lua provided by RyzenAPI
-- Game: Mazes and Mages

-- MAIN APPLICATION
addappid(870010)
-- Game: addappid(870010)

-- MAIN APP DEPOTS / PACKAGES
addappid(870011, 1, "4fbb66796a647c6efd67e427594837ef099e02f5421d3886d8ee4adfa4e19044")
