-- Lua provided by RyzenAPI 
-- Game: Idle Cultivation
addappid(3697240)
addappid(3697241, 1, "135c2a1b45bd4701c0e53613689483379f99bb4083926ef8c4266b4ad5730428")
addappid(4406460)
