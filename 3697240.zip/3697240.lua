-- Lua provided by RyzenAPI
-- Game: Idle Cultivation

-- MAIN APPLICATION
addappid(3697240)
addappid(4406460)
-- Game: addappid(3697240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3697241, 1, "135c2a1b45bd4701c0e53613689483379f99bb4083926ef8c4266b4ad5730428")
