-- Lua provided by RyzenAPI
-- Game: Writeway

-- MAIN APPLICATION
addappid(2736740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736741, 1, "ea77b4de0a4ad1a8df90f6553ce9a12044bb4182b36dc938db3416fcdbbde603")

