-- Lua provided by RyzenAPI
-- Game: Magic Spellslingers

-- MAIN APPLICATION
addappid(720090)
-- Game: addappid(720090)

-- MAIN APP DEPOTS / PACKAGES
addappid(720091, 1, "90e031f3324d113e5292eb62a0e25fcc758f0a3c55c514505a3121fe98417da9")
