-- Lua provided by RyzenAPI
-- Game: My Brother Rabbit

-- MAIN APPLICATION
addappid(855640)

-- MAIN APP DEPOTS / PACKAGES
addappid(855641, 1, "ed559eb443a29cdc89660d913c48a117726ab1b6f7395ba8ba1b18cfd512aa31")
addappid(855642, 1, "8e69404f2416b61877dfae2d3ca4b1c823e6f4cded2402fa50dadc806f0ff5d9")
addappid(855643, 1, "18ddb9cc36828f251c4347aa5a074efc4468baf6d6f2a2ae0bdef674657da6cc")
addappid(922580, 0, "91e38986a3dac96f8b6075c82f2fc6088f24f1d42e830f0eddeba2f4c5655e38")
addappid(922581, 0, "1f20777246011f0e969fe0c7b2a2080d570692177d9e7cedfb8e0cf973fa10e0")
