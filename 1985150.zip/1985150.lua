-- Lua provided by RyzenAPI
-- Game: We are definitely the baddies

-- MAIN APPLICATION
addappid(1985150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985151, 1, "5d9a4eaa198c84b23b7f9ea480980c745fae1bfb3c7d4f24297dd64a7260064e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
