-- Lua provided by RyzenAPI
-- Game: 我的坦克我的团

-- MAIN APPLICATION
addappid(1978240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978241, 1, "6a3326af47a63225ee5a9bcaf4f467562e85e1f4d386f7f4c41eb78e857564d0")

