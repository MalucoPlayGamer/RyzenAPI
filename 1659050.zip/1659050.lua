-- Lua provided by RyzenAPI
-- Game: Creatures Docking Station

-- MAIN APPLICATION
addappid(1659050)
addappid(1797350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1659051, 1, "5049103c53297b6392bcf0f8008606a27f1cfd57249226bc7233738980036f78")
addappid(1813080, 0, "0d64a34f0fc08646c9d3d3807ab6e10f899a9ca452ac3bc9356872a76d56b5b2")
addappid(1838430, 0, "0ae775e998599b9b0a0adc6e1e1fc366e3422f9d588d74df7d317a3ea93609f1")
addappid(2552730, 0, "d29061e4aac5c7285fed66997023900a33f11ab3b9db47b7a8750fdb512001f2")

