-- Lua provided by RyzenAPI
-- Game: Distant Space

-- MAIN APPLICATION
addappid(569610)

-- MAIN APP DEPOTS / PACKAGES
addappid(569611, 1, "a7527fd2068cac97c3a7772ca98930fed680114645e7439cbdc777e48f38d4f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
