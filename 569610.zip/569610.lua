-- Lua provided by RyzenAPI
-- Game: Distant Space

-- MAIN APPLICATION
addappid(569610)

-- MAIN APP DEPOTS / PACKAGES
addappid(569611, 1, "a7527fd2068cac97c3a7772ca98930fed680114645e7439cbdc777e48f38d4f2")

