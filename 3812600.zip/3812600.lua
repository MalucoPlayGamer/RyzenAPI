-- Lua provided by RyzenAPI
-- Game: ReStory: Chill Electronics Repairs

-- MAIN APPLICATION
addappid(5034500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3812600, 1, "28dcae12b1fc1cc8730d44073f4378f9ae73e32de2639581a693dd0bfcd42163") -- ReStory: Chill Electronics Repairs
addappid(3812601, 1, "5f6abd59a61b1a803b5a34eef196a26cd035da18f255212a544d5158dbfc626e") -- Depot 3812601
addappid(3812602, 1, "6fcf1eb039f557a73d5ed9b5fc840b753c184899a3e48ef44d98bf4bc423c31f") -- Depot 3812602
addappid(5034500, 1, "7b50eb279041c0949418aece25a74fc3c349e149ad3cfdfe093f5ea2c6954065") -- Restory Chill Electronics Repairs - Digital Artbook - Depot 5034500

