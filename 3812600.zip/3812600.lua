-- 3812600's Lua and Manifest Created by Hubcap Manifest
-- ReStory: Chill Electronics Repairs
-- Created: August 12, 2026 at 05:52:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3812600, 1, "28dcae12b1fc1cc8730d44073f4378f9ae73e32de2639581a693dd0bfcd42163") -- ReStory: Chill Electronics Repairs
-- MAIN APP DEPOTS
addappid(3812601, 1, "5f6abd59a61b1a803b5a34eef196a26cd035da18f255212a544d5158dbfc626e") -- Depot 3812601
setManifestid(3812601, "1323513118648202309", 1051512281)
addappid(3812602, 1, "6fcf1eb039f557a73d5ed9b5fc840b753c184899a3e48ef44d98bf4bc423c31f") -- Depot 3812602
setManifestid(3812602, "6989682484989569419", 1097899607)
-- DLCS WITH DEDICATED DEPOTS
-- Restory Chill Electronics Repairs - Digital Artbook (AppID: 5034500)
addappid(5034500)
addappid(5034500, 1, "7b50eb279041c0949418aece25a74fc3c349e149ad3cfdfe093f5ea2c6954065") -- Restory Chill Electronics Repairs - Digital Artbook - Depot 5034500
setManifestid(5034500, "4573138219617442396", 52964384)