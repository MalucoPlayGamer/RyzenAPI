-- Lua provided by RyzenAPI
-- Game: ReStory: Chill Electronics Repairs

-- MAIN APPLICATION
addappid(3812600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3812601,0,"5f6abd59a61b1a803b5a34eef196a26cd035da18f255212a544d5158dbfc626e")
addappid(5034500,0,"7b50eb279041c0949418aece25a74fc3c349e149ad3cfdfe093f5ea2c6954065")

