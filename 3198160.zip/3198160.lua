-- Lua provided by RyzenAPI
-- Game: addappid(3198160)

-- MAIN APPLICATION
addappid(3198160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198162,0,"0d65af0518b7f0a092c21a1f84a0fac845a4aac3ec53078b06da78f28b6f863c")
