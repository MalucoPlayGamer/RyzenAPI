-- Lua provided by RyzenAPI 
-- Game: Anx Defense Demo
addappid(2602850)
addappid(2602851, 1, "a59897768683f6caecb6df116b586e4a133332cc44f5a243f80586caf19ba67a")
