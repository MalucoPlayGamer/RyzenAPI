-- Lua provided by RyzenAPI
-- Game: Anx Defense Demo

-- MAIN APPLICATION
addappid(2602850)
-- Game: addappid(2602850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602851, 1, "a59897768683f6caecb6df116b586e4a133332cc44f5a243f80586caf19ba67a")
