-- Lua provided by RyzenAPI
-- Game: AppID 700050

-- MAIN APPLICATION
addappid(700050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(700051, 1, "5b7440271c3a9dfef5e8f01a46922a5bb04802c375b0463ca486fe8cba3f97b1")

