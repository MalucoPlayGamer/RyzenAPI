-- Lua provided by RyzenAPI
-- Game: 700050

-- MAIN APPLICATION
addappid(700050)
-- Game: addappid(700050)

-- MAIN APP DEPOTS / PACKAGES
addappid(700051, 1, "5b7440271c3a9dfef5e8f01a46922a5bb04802c375b0463ca486fe8cba3f97b1")
