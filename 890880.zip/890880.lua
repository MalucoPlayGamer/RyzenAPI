-- Lua provided by RyzenAPI
-- Game: FROSTBITE: Deadly Climate

-- MAIN APPLICATION
addappid(890880)
-- Game: addappid(890880)

-- MAIN APP DEPOTS / PACKAGES
addappid(890881, 1, "d5b0787443812d15e921db901d015496b0c72eb1095f205ed9713d38b45151a4")
