-- Lua provided by RyzenAPI
-- Game: 勇者之路

-- MAIN APPLICATION
addappid(2757390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2757391, 1, "bd2d8e74ad05be894d764485c8358851dea69631d15a1c573032cc2bef91176d")

