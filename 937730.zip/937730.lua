-- Lua provided by RyzenAPI
-- Game: Lady's Hentai Mosaic

-- MAIN APPLICATION
addappid(937730)

-- MAIN APP DEPOTS / PACKAGES
addappid(937731, 1, "4c1702ead2ab642b6bafe75f55e2679eb5fbbf575907beb20513976aa011bfcf")
addappid(937734, 1, "184c870c0c452a1658cea1d2040fe3e658ccc07eee1f0a56cc50b098ef52e2c2")
