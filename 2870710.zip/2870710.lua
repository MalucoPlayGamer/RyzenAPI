-- Lua provided by RyzenAPI
-- Game: addappid(2870710)

-- MAIN APPLICATION
addappid(2870710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870711, 1, "b2ddc85ffb0094b75d9222fd057d715f4f6d039e242ac38f31d18e49e9914304")
