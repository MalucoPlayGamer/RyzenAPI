-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Easy Linear Playing Exercise 2

-- MAIN APPLICATION
addappid(1089223)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089223,0,"67bb0ed7cf5cc843f48e8af6d651a8a7d233176fda87c1bbdb95e8aef3a266ba")

