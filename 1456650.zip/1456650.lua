-- Lua provided by RyzenAPI
-- Game: Pascal's Wager: Definitive Edition

-- MAIN APPLICATION
addappid(1456650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456651, 1, "559deaf06509bad0ea10096b34b255d9578beb01b9a64cb9f058aca1d5c955aa")

