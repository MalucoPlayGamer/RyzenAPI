-- Lua provided by RyzenAPI
-- Game: Pascal's Wager: Definitive Edition

-- MAIN APPLICATION
addappid(1456650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456651, 1, "559deaf06509bad0ea10096b34b255d9578beb01b9a64cb9f058aca1d5c955aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
