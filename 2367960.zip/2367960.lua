-- Lua provided by RyzenAPI
-- Game: Game: Sinking Simulator: Legacy

-- MAIN APPLICATION
addappid(2367960)
-- Game: addappid(2367960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367961, 1, "7bfed986f21f10b0e6b36e2c10238e576053737de431e65bcf0ff360a45228d5")
