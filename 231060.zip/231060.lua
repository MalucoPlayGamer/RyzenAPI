-- Lua provided by RyzenAPI
-- Game: Ragnarok Online 2

-- MAIN APPLICATION
addappid(231060)

-- MAIN APP DEPOTS / PACKAGES
addappid(231061, 1, "c82542ce427b6bbc6d150aed8e05247180355f7b6701f88272691e96a46e1580")

