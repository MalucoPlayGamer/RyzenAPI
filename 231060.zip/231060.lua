-- Lua provided by RyzenAPI
-- Game: Ragnarok Online 2

-- MAIN APPLICATION
addappid(231060)
addappid(239370)
addappid(239380)
addappid(247180)
addappid(247190)
addappid(265090)
addappid(267860)
addappid(267861)
addappid(267862)
addappid(267863)
addappid(267864)

-- MAIN APP DEPOTS / PACKAGES
addappid(231061, 1, "c82542ce427b6bbc6d150aed8e05247180355f7b6701f88272691e96a46e1580")

