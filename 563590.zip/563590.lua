-- Lua provided by RyzenAPI
-- Game: addappid(563590)

-- MAIN APPLICATION
addappid(563590)

-- MAIN APP DEPOTS / PACKAGES
addappid(563591, 1, "ee590aec9438559505e7e5dc5bcc470e97967393be08f3488c783fa86fbde87b")
