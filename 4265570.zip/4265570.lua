-- Lua provided by RyzenAPI
-- Game: Parking in Tight Spaces

-- MAIN APPLICATION
addappid(4265570) -- Parking in Tight Spaces

-- MAIN APP DEPOTS / PACKAGES
addappid(4265571, 1, "4e227147a32943e3ed42262b57bcad2deaf0bcbdfc4fe1d1b106eaad85a51b59") -- Depot 4265571

