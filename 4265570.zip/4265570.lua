-- 4265570's Lua and Manifest Created by Hubcap Manifest
-- Parking in Tight Spaces
-- Created: August 14, 2026 at 13:11:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4265570) -- Parking in Tight Spaces
-- MAIN APP DEPOTS
addappid(4265571, 1, "4e227147a32943e3ed42262b57bcad2deaf0bcbdfc4fe1d1b106eaad85a51b59") -- Depot 4265571
setManifestid(4265571, "3374876850066208662", 3901541633)