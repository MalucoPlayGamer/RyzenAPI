-- Lua provided by RyzenAPI
-- Game: True Game

-- MAIN APPLICATION
addappid(1610230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610231, 1, "33138580bffab10974f46e0e051b4718f138c91a08936b88da131c1d26077ccf")
