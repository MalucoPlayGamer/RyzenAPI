-- Lua provided by RyzenAPI
-- Game: Quest of Dungeons

-- MAIN APPLICATION
addappid(270050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(270051, 1, "3d4aac75823ddb05faf90ad474fa079030552cf02dd4611f08c77e2a90933af2")
addappid(270052, 1, "8647a25a59a92f7a6678f6599ad02e66f1e9f17625c4fde17b598a697aa854de")
addappid(270053, 1, "9c6b776544209e5a467c3e9328202535d148b06179f6a1602d544f789a9f2bc8")
