-- Lua provided by RyzenAPI
-- Game: Project 13: Nightwatch - Canteen

-- MAIN APPLICATION
addappid(2963820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963820,0,"f2a6071136f72c312001b0118da459c8f3e04197d7db04513065ad164379e5c1")
