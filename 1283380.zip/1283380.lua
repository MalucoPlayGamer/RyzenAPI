-- Lua provided by RyzenAPI
-- Game: AppID 1283380

-- MAIN APPLICATION
addappid(1283380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283381, 1, "c54bdc26812e5e70ead9b7a7663500ae3bfef6ea03218a01dca2c095f78581d4")

