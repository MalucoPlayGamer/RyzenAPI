-- Lua provided by RyzenAPI
-- Game: Cat Mail Co.

-- MAIN APPLICATION
addappid(4380490) -- Cat Mail Co.

-- MAIN APP DEPOTS / PACKAGES
addappid(4380491, 1, "1639ac5473e577209fec86c1386c93ce89b54703cc51f71956a7577b27ad278b")
