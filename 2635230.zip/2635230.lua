-- Lua provided by RyzenAPI
-- Game: addappid(2635230)

-- MAIN APPLICATION
addappid(2635230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635230,0,"01239c30f414ddb4bbbccb30d5c75c48e2c09933db4f4077aa4a75723187e07e")
