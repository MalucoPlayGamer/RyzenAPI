-- Lua provided by SkyAPI 
-- Game: Wedding Witch
addappid(2529820)
addappid(2529821, 1, "f6da43b73303ced9a9784ea87fdd5b4765cf4d6aec263bfc71b745fcbb123ca1")
addappid(2529822, 1, "5e01233dc312df0a9e3bd76fee01086af0375f8fdb9c14d6918da9d9d0aecf54")
addappid(2529823, 1, "af0af07d78d0727a37ffaccfbdd25782ea50da5e54ff186e288966121b595221")
addappid(2638000)
