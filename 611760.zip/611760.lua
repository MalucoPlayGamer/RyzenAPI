-- Lua provided by SkyAPI 
-- Game: AppID 611760
addappid(611760)
addappid(611761, 1, "eaf32c11c2ea3d5e796eb9d89b6c242944ae1efe0f8885387ecff48bae6d999d")
addappid(611762, 1, "d41c83cfff2d2468dca5f2ddb9dd576e7f9869027d155134d279ae1cd3cb641c")
