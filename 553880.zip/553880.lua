-- Lua provided by RyzenAPI
-- Game: Archangel™: Hellfire

-- MAIN APPLICATION
addappid(553880)
addappid(933130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(553881, 1, "1efc6b2fdf601afcbbe071e3101b7a198eb01aa9451b74a1839cea2dac0bf5df")
