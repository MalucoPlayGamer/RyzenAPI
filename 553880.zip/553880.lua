-- Lua provided by RyzenAPI
-- Game: AppID 553880

-- MAIN APPLICATION
addappid(553880)

-- MAIN APP DEPOTS / PACKAGES
addappid(553881, 1, "1efc6b2fdf601afcbbe071e3101b7a198eb01aa9451b74a1839cea2dac0bf5df")

