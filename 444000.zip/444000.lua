-- Lua provided by RyzenAPI
-- Game: addappid(444000)

-- MAIN APPLICATION
addappid(444000)

-- MAIN APP DEPOTS / PACKAGES
addappid(444001, 1, "5217afa1f4155a29abc553fba40614338f537c6c4ffa321bf90a9ecc0fa5b669")
