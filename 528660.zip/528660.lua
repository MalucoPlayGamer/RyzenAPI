-- Lua provided by RyzenAPI
-- Game: Game: Spin Rush

-- MAIN APPLICATION
addappid(528660)
-- Game: addappid(528660)

-- MAIN APP DEPOTS / PACKAGES
addappid(528661, 1, "afbc1cffa084cf9be0e33c1ae055c07799b8eff0d9fe8210c36697165d75891b")
addappid(528662, 1, "c86fa9f8039b3561c35cefc95c4c483d38afa69658b37074e64b3a191842e021")
addappid(528663, 1, "1ab7b2ab0d3d61da65cbb920fcabf4265751eae9053909609999e1913e9462a1")
addappid(528664, 1, "eede3744801ac8721a19a71bf285b833c93bb38b20169620341ec42eeffa2b41")
