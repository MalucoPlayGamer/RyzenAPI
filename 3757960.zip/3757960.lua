-- Lua provided by RyzenAPI
-- Game: 3757960

-- MAIN APPLICATION
addappid(3757960)
-- Game: addappid(3757960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3757961, 1, "eece6a13385261b8e43fa95eb5820e5a6edb135e5d582550cc99f26c93ab5e83")
