-- Lua provided by RyzenAPI
-- Game: addappid(442860)

-- MAIN APPLICATION
addappid(442860)

-- MAIN APP DEPOTS / PACKAGES
addappid(442861, 1, "3fa0dc24fa2f06bd8868a080de75ce634cd0506e81bf1c92b7200f213f0f385e")
