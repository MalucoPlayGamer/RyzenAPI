-- Lua provided by SkyAPI 
-- Game: Verde Station
addappid(324120)
addappid(324121, 1, "bcd152b62959c236216baac460f2407a85d4522a54be9a6fddd77a3a0a7176e2")
addappid(324122, 1, "0ac681be42cdb42ee758812fa5f1201fb23087758b1361ed27577a9ec539b589")
addappid(324123, 1, "d00b54ccad0d62ba9d20a16c9c29bc5e34b2e0cca6f68a7d08464380aba461da")
