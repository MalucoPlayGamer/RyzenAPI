-- Lua provided by RyzenAPI
-- Game: addappid(1636343)

-- MAIN APPLICATION
addappid(1636343)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636343,0,"522defb7d604943287835062c91a6fc2c37ad38b5aa5da31eaf987c285545bb0")
