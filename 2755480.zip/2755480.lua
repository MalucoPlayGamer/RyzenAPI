-- Lua provided by RyzenAPI
-- Game: The Censor DX Edition

-- MAIN APPLICATION
addappid(2755480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755481,0,"b5c225997ce7a240b0666f448a99189ebe6ac7fd0d3fc0be8bd148bc6aa3cf7f")
addappid(3985241,0,"6d0c26da70e7fdc64b17ef27250dc75d3aa964997eb9e5ba6f3c53830277fb60")
addappid(3985242,0,"4478929d8b9317350ec21beca470e04461f3091f6aae1388d4c02f1cf66c3a99")
addappid(3985243,0,"09d94d035d4e9c06b1b12c54c47c166eeb400d06bc9457ed640c575897b0d3c6")
addappid(3985244,0,"6031ff47bc1a45fc972d4076ede32b4aad3523d814d3afa903bdbe32645651d4")
addappid(3985245,0,"0f1089070f283a0c5d82b05dd7b050ca1e889504738b8a6c06a5762822271b3e")
addappid(3985246,0,"9c737cc04106c47f54ddfceb44eae15386c50ca056d55e035a24e61be93e7975")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3985240)
