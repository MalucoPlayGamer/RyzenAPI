-- Lua provided by RyzenAPI
-- Game: The Censor DX Edition

-- MAIN APPLICATION
addappid(2755480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755481, 1, "b5c225997ce7a240b0666f448a99189ebe6ac7fd0d3fc0be8bd148bc6aa3cf7f")
addappid(3985241, 0, "6d0c26da70e7fdc64b17ef27250dc75d3aa964997eb9e5ba6f3c53830277fb60")
