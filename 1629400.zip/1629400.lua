-- Lua provided by RyzenAPI
-- Game: Towerbots

-- MAIN APPLICATION
addappid(1629400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629401, 1, "0372cd4e433da23b4c0c97cf12ddaea7a40afce0809cadf3bd13708fd3def359")
