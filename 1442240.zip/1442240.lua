-- Lua provided by RyzenAPI
-- Game: Save the Pirate

-- MAIN APPLICATION
addappid(1442240)
addappid(1530830)
addappid(1537640)
addappid(1537650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442241, 1, "ab871c3e082e81fb50b3e7212af88d81c391746a2c00f73810d7b58cfa28ba2f")
addappid(1442242, 1, "93f78dbbcd47cde5c5062eb0b187abb929d47eef7136f5a584b40ee97cc5eb71")
addappid(1442243, 1, "4dd1433b3cb43d2129285c3ac12c8e49fcbd052698a129885788058db3e85c2c")
addappid(1442244, 1, "30409d27e9636a3d07093b0a3cfe4fc6c309f731f2f5399dde1bfb10713b9c7b")
