-- Lua provided by RyzenAPI
-- Game: Breeders of the Nephelym

-- MAIN APPLICATION
addappid(1161770)
-- Game: addappid(1161770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161771, 1, "f721df393d668bd9b99270f51c5a715d40556fe826c5213700ed3b7e95858976")
