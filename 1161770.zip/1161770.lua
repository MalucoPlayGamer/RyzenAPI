-- Lua provided by RyzenAPI
-- Game: Breeders of the Nephelym

-- MAIN APPLICATION
addappid(1161770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1161771, 1, "f721df393d668bd9b99270f51c5a715d40556fe826c5213700ed3b7e95858976")

