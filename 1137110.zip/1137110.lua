-- Lua provided by RyzenAPI 
-- Game: AppID 1137110
addappid(1137110)
addappid(1137111, 1, "23b05ab12aa7033ddd0a3769c813dc0f2e84c71779e97f0fa172981fa3aef74a")
