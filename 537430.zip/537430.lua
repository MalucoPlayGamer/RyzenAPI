-- Lua provided by RyzenAPI
-- Game: Game: Inner Chains

-- MAIN APPLICATION
addappid(537430)
-- Game: addappid(537430)

-- MAIN APP DEPOTS / PACKAGES
addappid(537431, 1, "8c101105c6fbdb0c7213b9419e48123c2213ccff852876a6a656108fb54c9d53")
