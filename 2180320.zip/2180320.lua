-- Lua provided by RyzenAPI
-- Game: 2180320

-- MAIN APPLICATION
addappid(2180320)
-- Game: addappid(2180320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180321, 1, "5fb0c3e8d2752c1da28fd7baf1dc33d84e2d24bd2548af8f7db0a3cdb7d38b2c")
