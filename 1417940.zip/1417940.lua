-- Lua provided by SkyAPI 
-- Game: 捕鱼炸翻天
addappid(1417940)
addappid(1417941, 1, "d23b3fccd787f5b33c005da443228a334d36b4fad1eae7a58e54c04cbae9a35d")
