-- Lua provided by RyzenAPI
-- Game: Way to the light

-- MAIN APPLICATION
addappid(2613070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613071, 1, "b2ecce87886668df96ea390bd1b7af0a7503d2f167fa72ba95d6127993acc701")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
