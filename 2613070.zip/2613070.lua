-- Lua provided by RyzenAPI
-- Game: addappid(2613070)

-- MAIN APPLICATION
addappid(2613070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613071, 1, "b2ecce87886668df96ea390bd1b7af0a7503d2f167fa72ba95d6127993acc701")
