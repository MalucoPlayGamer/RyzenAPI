-- Lua provided by SkyAPI 
-- Game: Cardfight!! Vanguard Dear Days
addappid(1881420)
addappid(1881421, 1, "d22cbc6744b081e9035797a8578eaf3486fd307ec250797cc37e9260b97306b2")
