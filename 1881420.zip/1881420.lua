-- Lua provided by RyzenAPI
-- Game: Cardfight!! Vanguard Dear Days

-- MAIN APPLICATION
addappid(1881420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881421, 1, "d22cbc6744b081e9035797a8578eaf3486fd307ec250797cc37e9260b97306b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2078840)
addappid(2078841)
addappid(2078860)
addappid(2112100)
addappid(2112101)
addappid(2112102)
addappid(2112103)
addappid(2112104)
addappid(2112105)
addappid(2112110)
addappid(2112111)
addappid(2112112)
addappid(2112113)
addappid(2112114)
addappid(2112115)
addappid(2112116)
addappid(2190710)
addappid(2190711)
addappid(2190712)
addappid(2190713)
addappid(2190714)
addappid(2190715)
addappid(2190716)
addappid(2190717)
addappid(2190718)
addappid(2190720)
addappid(2190721)
addappid(2190722)
addappid(2190723)
addappid(2190724)
addappid(2191800)
addappid(2399380)
addappid(2399390)
addappid(2399391)
addappid(2399400)
addappid(2399401)
addappid(2399402)
addappid(2399403)
addappid(2399404)
addappid(2399405)
addappid(2399406)
addappid(2399407)
addappid(2654550)
