-- Lua provided by RyzenAPI
-- Game: Game: Cardfight!! Vanguard Dear Days

-- MAIN APPLICATION
addappid(1881420)
-- Game: addappid(1881420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881421, 1, "d22cbc6744b081e9035797a8578eaf3486fd307ec250797cc37e9260b97306b2")
