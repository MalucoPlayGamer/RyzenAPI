-- Lua provided by RyzenAPI
-- Game: AppID 33770

-- MAIN APPLICATION
addappid(33770)

-- MAIN APP DEPOTS / PACKAGES
addappid(33771, 1, "60949bac5cd2b9728afba36291d6902fd3e8b244ac2e5d093a0e0a4d062e7cd0")
