-- Lua provided by RyzenAPI
-- Game: New York Rat Simulator

-- MAIN APPLICATION
addappid(1566540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1566541, 1, "9fd228887f63f5777b216d32c88cb74b1fadbf9cc4dc7908ed8b5c231f8ca293")

