-- Lua provided by RyzenAPI
-- Game: Game: New York Rat Simulator

-- MAIN APPLICATION
addappid(1566540)
-- Game: addappid(1566540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566541, 1, "9fd228887f63f5777b216d32c88cb74b1fadbf9cc4dc7908ed8b5c231f8ca293")
