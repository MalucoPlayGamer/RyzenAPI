-- Lua provided by RyzenAPI
-- Game: Game: 明星志願2000

-- MAIN APPLICATION
addappid(1642580)
-- Game: addappid(1642580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642581, 1, "437014a64826625303e3e25ce4cbea92816f8c18db872d86f0fee3994f10f4ab")
addappid(1856630, 0, "54f3e3999584b9ac15f083025ea162d8d4a04dd101a11ef74d3f97a2729092cb")
