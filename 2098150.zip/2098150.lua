-- Lua provided by SkyAPI 
-- Game: Orpheus
addappid(2098150)
addappid(2098151, 1, "fe1cce66505eb500c8df4d03b590f7f20fced983221af5abef8f5f482a0191bd")
