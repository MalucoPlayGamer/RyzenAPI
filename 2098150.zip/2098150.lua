-- Lua provided by RyzenAPI
-- Game: 2098150

-- MAIN APPLICATION
addappid(2098150)
-- Game: addappid(2098150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098151, 1, "fe1cce66505eb500c8df4d03b590f7f20fced983221af5abef8f5f482a0191bd")
