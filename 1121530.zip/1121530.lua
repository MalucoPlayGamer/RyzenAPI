-- Lua provided by SkyAPI 
-- Game: Globesweeper: Hex Puzzler
addappid(1121530)
addappid(1121531, 1, "77355f4de21d4df1f27606cd6162b2efd3abe1622dc08af3fb3f5d8384ec55fc")
