-- Lua provided by RyzenAPI
-- Game: Globesweeper: Hex Puzzler

-- MAIN APPLICATION
addappid(1121530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1121531, 1, "77355f4de21d4df1f27606cd6162b2efd3abe1622dc08af3fb3f5d8384ec55fc")

