-- Lua provided by RyzenAPI
-- Game: Globesweeper: Hex Puzzler

-- MAIN APPLICATION
addappid(1121530)
-- Game: addappid(1121530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121531, 1, "77355f4de21d4df1f27606cd6162b2efd3abe1622dc08af3fb3f5d8384ec55fc")
