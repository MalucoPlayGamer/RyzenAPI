-- Lua provided by RyzenAPI
-- Game: Poveglia: The Island of No Return

-- MAIN APPLICATION
addappid(2260450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2260451, 1, "df059deaeb778ff15fcbf0d67bc0a885305dd7e51f9917748b504f8d7516a895")

