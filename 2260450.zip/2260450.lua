-- Lua provided by RyzenAPI
-- Game: 2260450

-- MAIN APPLICATION
addappid(2260450)
-- Game: addappid(2260450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260451, 1, "df059deaeb778ff15fcbf0d67bc0a885305dd7e51f9917748b504f8d7516a895")
