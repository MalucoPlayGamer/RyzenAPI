-- Lua provided by RyzenAPI
-- Game: Game: Pixel Game Maker MV - Chiptune Style Battle Music Pack

-- MAIN APPLICATION
addappid(1755800)
-- Game: addappid(1755800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755801, 1, "b183861d5547ee5912855bf390832ca3140c65c470039318ca16ac0d9f47f821")
