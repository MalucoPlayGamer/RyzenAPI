-- Lua provided by RyzenAPI
-- Game: Outpath

-- MAIN APPLICATION
addappid(2237970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237971, 1, "5a1f07263fe77dc61d0d92da409ff8b0da7dad2883c02d3a0c0b9891ff0fd2dc")
