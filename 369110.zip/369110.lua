-- Lua provided by RyzenAPI
-- Game: AppID 369110

-- MAIN APPLICATION
addappid(369110)

-- MAIN APP DEPOTS / PACKAGES
addappid(369111, 1, "da3a3d88baa2c5eed6a0b1bc02ab4557564386a9e5d33a4f0304ee695f17c15f")
