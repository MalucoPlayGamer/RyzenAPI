-- Lua provided by RyzenAPI
-- Game: 444130

-- MAIN APPLICATION
addappid(444130)
-- Game: addappid(444130)

-- MAIN APP DEPOTS / PACKAGES
addappid(444131, 1, "863967c15d0ffd44883259ceab67610287de757397dedf2c1dfd5d403f7b0fcf")
