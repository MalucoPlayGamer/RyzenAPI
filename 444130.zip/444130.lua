-- Lua provided by RyzenAPI
-- Game: AppID 444130

-- MAIN APPLICATION
addappid(444130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(444131, 1, "863967c15d0ffd44883259ceab67610287de757397dedf2c1dfd5d403f7b0fcf")

