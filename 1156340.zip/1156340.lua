-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1156340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156340,0,"d23ccec412ccd63f9a0681455a16f64a87abf27005ba450d9b08674e5d737d5d")
