-- Lua provided by RyzenAPI
-- Game: Game: AppID 1051630

-- MAIN APPLICATION
addappid(1051630)
-- Game: addappid(1051630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051631, 1, "56a3c252a4120946f0b509c8fc84ef70f144a9a4ec7317bfb9094934f72f5fb1")
