-- Lua provided by RyzenAPI 
-- Game: RTS Creator Demo
addappid(335410)
addappid(335411, 1, "87fc8725dfb32ea039abb0bac2346b2bdb42561809b93bddff7a426c77147be9")
