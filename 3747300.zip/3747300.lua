-- Lua provided by RyzenAPI
-- Game: Mitos.is: OG

-- MAIN APPLICATION
addappid(3747300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3747301, 1, "edc32d7a8a7ed005eabfb4eda060899e48dfb1f2222ab44b36db5aafeb77b3da")
