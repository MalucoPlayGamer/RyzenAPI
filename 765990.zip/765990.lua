-- Lua provided by RyzenAPI 
-- Game: AppID 765990
addappid(765990)
addappid(765991, 1, "6051786a3627a6f7c9e99639ba1001418ab360103835cb38b3a7c9a66a07ef43")
