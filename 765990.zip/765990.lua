-- Lua provided by RyzenAPI
-- Game: Game: AppID 765990

-- MAIN APPLICATION
addappid(765990)
-- Game: addappid(765990)

-- MAIN APP DEPOTS / PACKAGES
addappid(765991, 1, "6051786a3627a6f7c9e99639ba1001418ab360103835cb38b3a7c9a66a07ef43")
