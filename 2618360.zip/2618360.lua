-- Lua provided by RyzenAPI
-- Game: addappid(2618360)

-- MAIN APPLICATION
addappid(2618360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618361, 1, "634f3eb844c8a4fd0a1c61c83182d35e4e86ede5c37376f6d4c8c40c99cca8f9")
