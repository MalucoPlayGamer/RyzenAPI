-- Lua provided by RyzenAPI
-- Game: Elements Divided

-- MAIN APPLICATION
addappid(2805770)
addappid(3830940)
addappid(4219210)
addappid(4219220)
addappid(4219230)
addappid(4219240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805771,0,"4730c358fb32598b2cdbea801335f5fdb58f96a90c75fb0b796316290592f4aa")

