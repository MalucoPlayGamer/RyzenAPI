-- Lua provided by RyzenAPI
-- Game: Elements Divided

-- MAIN APPLICATION
addappid(2805770)
-- Game: addappid(2805770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805771, 1, "4730c358fb32598b2cdbea801335f5fdb58f96a90c75fb0b796316290592f4aa")
