-- Lua provided by RyzenAPI
-- Game: AppID 1028840

-- MAIN APPLICATION
addappid(1028840)
-- Game: addappid(1028840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028841, 1, "c8e1656f5b5b1d38efb4abcec1caa37331cb00fc78bfac95e726444df7ab2813")
