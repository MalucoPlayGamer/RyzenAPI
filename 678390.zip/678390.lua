-- Lua provided by RyzenAPI
-- Game: addappid(678390)

-- MAIN APPLICATION
addappid(678390)

-- MAIN APP DEPOTS / PACKAGES
addappid(678391, 1, "1cbb02d7130382871fdb89c25f6d549c292a8cd98e5e9ed747b55d2c95ca40d1")
addappid(678393, 1, "c409ea51cece4cfa7445af4ccc4a915ac715982ba301a72e739054932e175607")
