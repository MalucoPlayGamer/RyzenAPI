-- Lua provided by RyzenAPI
-- Game: Cow Milking Simulator

-- MAIN APPLICATION
addappid(624710)

-- MAIN APP DEPOTS / PACKAGES
addappid(624711,0,"1914702c08047f3dc9a7995ac3d4dbd3e3ce212eca7d9f4999a29d34a0f17dca")

