-- Lua provided by RyzenAPI
-- Game: Fresh Body

-- MAIN APPLICATION
addappid(550840)
addappid(863320)

-- MAIN APP DEPOTS / PACKAGES
addappid(550841, 1, "142ffcca320d1e80c8f0470f2e99ce5b5d0c0d6cb201e64eca6ba9ee064042da")
addappid(550842, 1, "8874f6c68397e5dab3affc3c38424b9da8f7fa48ce05cc7cd08610ebe3af5842")
addappid(764340, 0, "97e5cb702d1424a81f808c041fda99214d2726529c02a8a2e178b1d0c0c9a296")
addappid(772400, 0, "118c03fedc7eafc26f0c9ad3fee6737c4fa214641b69953063181dc113f69892")
addappid(777290, 0, "967c7f34b1af4b5621c3d3c94af1b32e8ae03cf69e7a3d45efa1cd1b8b8813c0")

