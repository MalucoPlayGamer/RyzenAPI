-- Lua provided by RyzenAPI
-- Game: Love, Money, Rock'n'Roll

-- MAIN APPLICATION
addappid(615530)

-- MAIN APP DEPOTS / PACKAGES
addappid(615531, 1, "798a2870c2ddd7da29e898c6f9472b8b5dfcf9bb0799588e2ee149ba756da3f9")
addappid(615532, 1, "fecd3a957c73d5dcf977d6d5144b5b23574076649553b85fe163793ff1a8557f")
addappid(615533, 1, "09514769a9093810fe2e725d9cb6b97b71628394770f14448a79c651ca2b8b49")
addappid(615534, 1, "c71f8ed70d1f2c2cc7d2b4a7d5268fbb350d874f5f4916911a0394ea1283714b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2318010)
addappid(3313270)
