-- Lua provided by RyzenAPI
-- Game: 破碎的笔记 Bad Note

-- MAIN APPLICATION
addappid(976070)

-- MAIN APP DEPOTS / PACKAGES
addappid(976071, 1, "0b50ffa7e6a16f8a567b86548dcfd86835f9f17987f8774f9eeb11e70355bd02")
