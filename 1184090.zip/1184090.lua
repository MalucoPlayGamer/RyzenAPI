-- Lua provided by RyzenAPI
-- Game: Belly Dance Girl

-- MAIN APPLICATION
addappid(1184090)
-- Game: addappid(1184090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184091, 1, "5846fb1aea7df1b98f015cfd2c56aadbf859819c8b975de59e1f1ed9e89e15bf")
