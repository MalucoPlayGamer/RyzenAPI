-- Lua provided by RyzenAPI
-- Game: Crossroads Inn Anniversary Edition

-- MAIN APPLICATION
addappid(867290)
addappid(1150370)
addappid(1150380)
addappid(1154630)
addappid(1205180)
addappid(1281620)
addappid(1363450)
addappid(1395950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(867290,0,"7e5ee2feb6ed393bee1b51252fb15ab46be116bd002416f23275cdb78e23135b")
addappid(867291,0,"946d57dead5d938dbd782c3c56fe6fad23ea5dda3fbef17510fa46239a662c35")
addappid(867292,0,"e0b53ba818849d833cf7873dce585251711bab5130f9da0b8aa9be894d9e90e2")
addappid(867293,0,"21471f2f834b3a97ff57f937f2449ce063ade83a09035233252022212edb846c")
addappid(867294,0,"168b338e26024bbc37aa60196c4b816364a053b490b9f69a9e4909c9847d0fff")
addappid(867295,0,"79f6ebf78f9679ab2f38bdd57ec3f3aea885b1a0520759e5d435fc4a4470540a")
addappid(1150370,0,"9e8c87bdcf781f63105f1e59dc81043ed0e81dda8b9ced108350cc88622336e4")

