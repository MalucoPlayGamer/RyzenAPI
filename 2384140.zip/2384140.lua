-- Lua provided by RyzenAPI
-- Game: Luminous Skies: A Short Adventure

-- MAIN APPLICATION
addappid(2384140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384141, 1, "0d0afd32cc7496c084258c731bc467f20d82dad9006aed3aa3012e79b86de5b8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2384220)
addappid(2384221)
addappid(2384222)
addappid(2840850)
addappid(2892120)
