-- Lua provided by RyzenAPI
-- Game: Soul Dossier

-- MAIN APPLICATION
addappid(1520470)
-- Game: addappid(1520470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520471, 1, "4fda52c932a82ad19a19fc759e5aed0f9364d8aeac70bf21a2d218d5b14bae50")
