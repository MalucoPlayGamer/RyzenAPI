-- Lua provided by RyzenAPI
-- Game: Game: AppID 1400200

-- MAIN APPLICATION
addappid(1400200)
-- Game: addappid(1400200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400201, 1, "9b91d6899fb3768738f94b7d23456c24baf215518c78cfcc6a60bf362a83cf48")
