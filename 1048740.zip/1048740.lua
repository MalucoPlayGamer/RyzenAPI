-- Lua provided by RyzenAPI
-- Game: addappid(1048740)

-- MAIN APPLICATION
addappid(1048740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048741, 1, "967f9cee847f97f55f48e7ec0f5f72f5fa950a9cfc22d5f1769d84b49873582f")
