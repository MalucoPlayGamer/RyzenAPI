-- Lua provided by RyzenAPI
-- Game: addappid(1357540)

-- MAIN APPLICATION
addappid(1357540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357541, 1, "6f90b21e4a0281f28c8dac09e5b694abc1efa99413fd0cd23d5be23b9f1fbf9a")
