-- Lua provided by RyzenAPI
-- Game: 2669490

-- MAIN APPLICATION
addappid(2669490)
-- Game: addappid(2669490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669491, 1, "f316ad37a838bfa0da286dbb839a8ab600d68a8541d0ef9e1ef65221ed4e568a")
