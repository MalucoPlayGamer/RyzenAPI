-- Lua provided by RyzenAPI
-- Game: StarRupture

-- MAIN APPLICATION
addappid(1631270) -- StarRupture
addappid(4167250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1631272, 1, "cbb99a831607efa2d9529979e09ca1e3b1692bf978684330d6db62a558c30b52") -- Depot 1631272
addappid(4167250, 1, "5ea58a4526ce19f7edf2448015e940043fc2da5d61a837f34dfdf2e2966a2f8c") -- StarRupture - Supporter Pack - Depot 4167250
