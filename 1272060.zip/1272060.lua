-- Lua provided by SkyAPI 
-- Game: Premier Manager 02/03
addappid(1272060)
addappid(1272061, 1, "28a5feff0ba8a8dd2a13f6635661bdbabbe62f20f7aa09652e262b6ce5e7ed2a")
