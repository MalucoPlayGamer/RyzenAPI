-- Lua provided by RyzenAPI
-- Game: AppID 781590

-- MAIN APPLICATION
addappid(781590)
-- Game: addappid(781590)

-- MAIN APP DEPOTS / PACKAGES
addappid(781591, 1, "3a66f0247c8a1022cbba9171cb71b2b8ad5b4ba4f849076ef89a2d4044f02d37")
addappid(781870, 0, "66d793387e3b2243ea1aa33847dbe28a1b0a2b7ae05ffd0a06bc768a95f82864")
