-- Lua provided by RyzenAPI
-- Game: The Labyrinth

-- MAIN APPLICATION
addappid(652050)
-- Game: addappid(652050)

-- MAIN APP DEPOTS / PACKAGES
addappid(652051, 1, "8cea0a1b44295b384052a2ead3954c4ec7100f6f9ff99f0ba4a3084d5526bbfa")
