-- Lua provided by RyzenAPI
-- Game: 799860

-- MAIN APPLICATION
addappid(799860)
-- Game: addappid(799860)

-- MAIN APP DEPOTS / PACKAGES
addappid(799861, 1, "d8b26e3f563762a703593e9b391d1d32a689a472b236b83146f2cf1f67302370")
addappid(799862, 1, "0ecd3140ca9fbed715d61bbef757521f8912ba75aaba071ec39bc6406ca6bdae")
