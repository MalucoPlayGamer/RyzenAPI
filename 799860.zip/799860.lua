-- Lua provided by RyzenAPI
-- Game: AppID 799860

-- MAIN APPLICATION
addappid(799860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(799861, 1, "d8b26e3f563762a703593e9b391d1d32a689a472b236b83146f2cf1f67302370")
addappid(799862, 1, "0ecd3140ca9fbed715d61bbef757521f8912ba75aaba071ec39bc6406ca6bdae")

