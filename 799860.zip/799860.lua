-- Lua provided by SkyAPI 
-- Game: AppID 799860
addappid(799860)
addappid(799861, 1, "d8b26e3f563762a703593e9b391d1d32a689a472b236b83146f2cf1f67302370")
addappid(799862, 1, "0ecd3140ca9fbed715d61bbef757521f8912ba75aaba071ec39bc6406ca6bdae")
