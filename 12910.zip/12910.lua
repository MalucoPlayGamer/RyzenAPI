-- Lua provided by RyzenAPI
-- Game: AudioSurf Demo

-- MAIN APPLICATION
addappid(12910)

-- MAIN APP DEPOTS / PACKAGES
addappid(12911, 1, "7aa16b1a0eb161d33ae0bb784e59274ea65865b6d46ac7c38955cd6d7b745204")

