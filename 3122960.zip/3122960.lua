-- Lua provided by RyzenAPI
-- Game: Goeland: Seagull Adventure Demo

-- MAIN APPLICATION
addappid(3122960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122963,0,"647e27c9968b09109f1c3f4b9dc6c7f1b08b6ac8812581a1b820c2e56663b4e2")

