-- Lua provided by RyzenAPI
-- Game: I, Zombie

-- MAIN APPLICATION
addappid(307230)

-- MAIN APP DEPOTS / PACKAGES
addappid(307231, 1, "7e13cc1d91060dfd4368b5fd087c88ef9c27c6afe71954082b3d23525655c1df")
