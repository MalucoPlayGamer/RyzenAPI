-- Lua provided by RyzenAPI
-- Game: Blood Money: Lethal Eden

-- MAIN APPLICATION
addappid(3850560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3850561, 1, "61903c2633e62e94d33f313bfefafd29b2e47475366438e3d01d2b7832001567")

