-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3633810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3633810,0,"e5eeaa4d2870530dd19c02a48d2951e74c0f67c20725bed63d7f4e2f14a9e54c")

