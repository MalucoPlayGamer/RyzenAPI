-- Lua provided by RyzenAPI
-- Game: Sur

-- MAIN APPLICATION
addappid(1661580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661581, 1, "58eb5301ae763a1deec30d7f215ae825490b83edb678a592c887dde53a47ccaf")
addappid(1661583, 1, "8513ed384bf3fe71a209c98ac9dcf2b56a42392b0f07be7c61d0225d3e601af9")
