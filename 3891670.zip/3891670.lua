-- 3891670's Lua and Manifest Created by Hubcap Manifest
-- 消えた灯と夏の影
-- Created: July 23, 2026 at 02:18:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3891670) -- 消えた灯と夏の影
-- MAIN APP DEPOTS
addappid(3891671, 1, "66758fc5fb55affe4a3b624f012a37a49d29ecbc6da0a7cf7da045d16a7d41fe") -- Depot 3891671
setManifestid(3891671, "6403583751584382918", 346455094)