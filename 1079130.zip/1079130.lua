-- Lua provided by RyzenAPI
-- Game: addappid(1079130)

-- MAIN APPLICATION
addappid(1079130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079131, 1, "9c3fb0c9d932d749bd52b8d575a69b0bc42e4573865a14871a2a0503a4a35cc9")
