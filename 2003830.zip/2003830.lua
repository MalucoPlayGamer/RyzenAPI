-- Lua provided by RyzenAPI
-- Game: 2003830

-- MAIN APPLICATION
addappid(2003830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003830,0,"18eb1d65b2ea668554c8a94dfd95f764ff93dd891842d8fcdb38fbcb87e4c99c")

