-- Lua provided by RyzenAPI
-- Game: Game: Naughty Memories: Asian Beauty

-- MAIN APPLICATION
addappid(1486340)
-- Game: addappid(1486340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486341, 1, "51d10b66aa5b20111f7410b054a83993fbbf49ef79b9345c6507bc36aab640f6")
