-- Lua provided by SkyAPI 
-- Game: AppID 3019960
addappid(3019960)
addappid(3019961, 1, "2148e1b1032e28d50dd720474031990643aa8ca91b4eb7582e2a0325e111b27a")
