-- Lua provided by RyzenAPI
-- Game: There's something wrong with... Demo

-- MAIN APPLICATION
addappid(3019960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019961, 1, "2148e1b1032e28d50dd720474031990643aa8ca91b4eb7582e2a0325e111b27a")

