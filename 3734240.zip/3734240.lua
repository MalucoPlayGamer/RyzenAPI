-- Lua provided by RyzenAPI 
-- Game: Calyx Playtest
addappid(3734240)
addappid(3734241, 1, "c46025b89a2ee4f1ceab2f61d3517b093c6273af597b8f55c80e91f39d0794ad")
