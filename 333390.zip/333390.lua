-- Lua provided by RyzenAPI
-- Game: Game: AppID 333390

-- MAIN APPLICATION
addappid(333390)
-- Game: addappid(333390)

-- MAIN APP DEPOTS / PACKAGES
addappid(333391, 1, "7597b04995661056b86f77e091b56d2c5c02e9cc8cc187b1a64d511f6b953c7b")
addappid(354190, 0, "dede3d83e9d2609a780565e96973db75dc189244d00efe8a01d86a99bc8bc8e8")
