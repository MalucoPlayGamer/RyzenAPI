-- Lua provided by RyzenAPI
-- Game: Labyrinth Legend

-- MAIN APPLICATION
addappid(1321010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321011, 1, "e6e34bfb352da1c5d524312a0143f27c5aae8999fa06ab6b7b164134cdaa7a67")
