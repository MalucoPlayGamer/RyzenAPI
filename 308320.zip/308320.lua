-- Lua provided by RyzenAPI
-- Game: Total Pro Golf 3

-- MAIN APPLICATION
addappid(308320)

-- MAIN APP DEPOTS / PACKAGES
addappid(308321, 1, "7b650c46df5935d934cee7aca0c323e98786d84ed72e373c7742e5d1dbf8306e")
