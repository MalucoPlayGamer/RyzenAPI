-- Lua provided by RyzenAPI
-- Game: Among Ashes

-- MAIN APPLICATION
addappid(2430900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430901, 1, "90cfd24a24b805820e19c590e43a32922893e12eddebac0e319874a503e49b86")
