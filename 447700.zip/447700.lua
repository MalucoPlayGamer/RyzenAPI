-- Lua provided by RyzenAPI
-- Game: Game: Crystal Crisis

-- MAIN APPLICATION
addappid(447700)
-- Game: addappid(447700)

-- MAIN APP DEPOTS / PACKAGES
addappid(447701, 1, "cc1012c91c368f999cab6456cca0d497d289fb672e9dd07cdaef1506c2cccab0")
