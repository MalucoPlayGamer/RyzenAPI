-- Lua provided by RyzenAPI
-- Game: addappid(2783880)

-- MAIN APPLICATION
addappid(2783880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783881, 1, "be9d14089d1ca95432cd141b9aa0bcd4e9a31289253e7c8ca650a4a0654d213c")
