-- Lua provided by RyzenAPI 
-- Game: Dino Tower Arena Demo
addappid(2683730)
addappid(2683731, 1, "223e74895cd46d2ef9b83ca9a1f138775993ae5f36192013ea7527e1d365b505")
