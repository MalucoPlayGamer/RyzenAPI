-- Lua provided by RyzenAPI
-- Game: Dino Tower Arena Demo

-- MAIN APPLICATION
addappid(2683730)
-- Game: addappid(2683730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683731, 1, "223e74895cd46d2ef9b83ca9a1f138775993ae5f36192013ea7527e1d365b505")
