-- Lua provided by RyzenAPI
-- Game: Immortal Mantis: Revenge

-- MAIN APPLICATION
addappid(2577550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577552,0,"1a633f43245af34df83958a8c4a8f403871d576ebe60775d3277e753e00afb12")

