-- Lua provided by SkyAPI 
-- Game: AppID 1919720
addappid(1919720)
addappid(1919721, 1, "6d792834d37c0f4838ab6ecf0476c127e7aa44b1ac0fd4c5042f3181b0f02c14")
