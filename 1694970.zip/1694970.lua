-- Lua provided by RyzenAPI
-- Game: Jude

-- MAIN APPLICATION
addappid(1694970)
-- Game: addappid(1694970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694971, 1, "0b229703f4788bfffce160541c63f1b93952d400cde899b8d9c8e048f78d24ff")
