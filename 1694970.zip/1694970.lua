-- Lua provided by RyzenAPI 
-- Game: Jude
addappid(1694970)
addappid(1694971, 1, "0b229703f4788bfffce160541c63f1b93952d400cde899b8d9c8e048f78d24ff")
