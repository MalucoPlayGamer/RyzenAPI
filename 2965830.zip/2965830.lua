-- Lua provided by RyzenAPI
-- Game: Breaking Good (Demo)

-- MAIN APPLICATION
addappid(2965830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2965831, 1, "2eb0f838acd897292da1e582cc8c3ec287e89598b2319216368e850270481449")

