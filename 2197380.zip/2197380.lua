-- Lua provided by RyzenAPI
-- Game: addappid(2197380)

-- MAIN APPLICATION
addappid(2197380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197381, 1, "f5702c7cc84c7651d95849c6a93d4ac68eefce709b5672f72c15e44ae93f4b8c")
