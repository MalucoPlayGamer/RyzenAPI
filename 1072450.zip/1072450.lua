-- Lua provided by RyzenAPI
-- Game: addappid(1072450)

-- MAIN APPLICATION
addappid(1072450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072451, 1, "d9df9ad6f532f080b9f4c9a0f27cbef5ad70428008f556e4f6636079415f9c2d")
