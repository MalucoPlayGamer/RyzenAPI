-- Lua provided by RyzenAPI
-- Game: Changeling Tale Demo

-- MAIN APPLICATION
addappid(1232880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232882,0,"e06ab3299d842fd78d8584d8b0e1829c50fa27447c079b25a1b4eb7770249864")

