-- Lua provided by RyzenAPI
-- Game: 2340640

-- MAIN APPLICATION
addappid(2340640)
-- Game: addappid(2340640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340641, 1, "14e50324bb0e022a36bff91f7c952fa874f3fb0948d944e34923d84ab67d8e66")
