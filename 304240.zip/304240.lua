-- Lua provided by RyzenAPI
-- Game: AppID 304240

-- MAIN APPLICATION
addappid(304240)

-- MAIN APP DEPOTS / PACKAGES
addappid(304241, 1, "628406156243272990c118c3a8497b1bdc8b03a11cd1b21e986ff86c89a45f49")
addappid(304242, 1, "e86af320324228098bed69cf389ccd1b7af582a1f5725a1952a5815fd7cc1313")
addappid(345190, 0, "60ab048988d781e57c9bbc1881b3a4fbc67178b649d758ef782277efc5f073f5")
addappid(345191, 0, "eb7b2280a99010609c30169ce5ea98a4052c54a7139feab5e3ffacdac64035fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
