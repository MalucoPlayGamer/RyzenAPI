-- Lua provided by SkyAPI 
-- Game: Secret Crush -Unrequited love-
addappid(3386300)
addappid(3386301, 1, "1c91accae85e8d81cb97a72448248cd880897d64b79853bb9002d70f38068539")
