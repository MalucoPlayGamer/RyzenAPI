-- Lua provided by RyzenAPI
-- Game: Game: Secret Crush -Unrequited love-

-- MAIN APPLICATION
addappid(3386300)
-- Game: addappid(3386300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386301, 1, "1c91accae85e8d81cb97a72448248cd880897d64b79853bb9002d70f38068539")
