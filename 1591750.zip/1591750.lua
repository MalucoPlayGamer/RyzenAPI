-- Lua provided by RyzenAPI
-- Game: 1591750

-- MAIN APPLICATION
addappid(1591750)
-- Game: addappid(1591750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591751, 1, "0cd283c521a863d40aab4f801ddb0b299306764eb163dde2d18e6bc6708e7ed3")
