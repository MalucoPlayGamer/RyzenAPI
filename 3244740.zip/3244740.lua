-- Lua provided by RyzenAPI
-- Game: addappid(3244740)

-- MAIN APPLICATION
addappid(3244740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244741, 1, "a036b98c641aee4f8b530cf170fddb3e109c81aae2967db9208461ceabe42af2")
