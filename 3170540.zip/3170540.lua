-- Lua provided by RyzenAPI
-- Game: Backyard Baseball '97

-- MAIN APPLICATION
addappid(3170540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3170541, 1, "897fe0a30dee8551d3246d89d80cb49f992e3c799faa70b1f13f4a185c5fa5d6")

