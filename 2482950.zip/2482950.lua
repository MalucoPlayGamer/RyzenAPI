-- Lua provided by RyzenAPI
-- Game: 夕照原

-- MAIN APPLICATION
addappid(2482950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482951,0,"de5eabf567b73eafea8a7fc103059887b3170707ee745d76191f912c61bf531b")

