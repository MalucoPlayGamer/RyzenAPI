-- Lua provided by RyzenAPI
-- Game: AppID 476420

-- MAIN APPLICATION
addappid(476420)

-- MAIN APP DEPOTS / PACKAGES
addappid(476421, 1, "6e96e728a5a41c78fbfb8efc1320dcd26134fb3631f5c7a8be52bd9bf8fbc7ec")
addappid(476424, 1, "7f8a06c82fa28936c03453345f4841f7a57c82cb9d52b278bd13dea7e2e5dff2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(727670)
