-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956942)

-- MAIN APP DEPOTS / PACKAGES
addappid(956942,0,"36038e0380306dc1a3abe3bec39f31994808f3ab69eec730e0d9e9e42c719b68")
