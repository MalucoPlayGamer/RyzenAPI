-- Lua provided by RyzenAPI
-- Game: Hellstuck: Rage With Your Friends

-- MAIN APPLICATION
addappid(1559570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559571, 1, "89283a6e1a801944c2289903bd0f932350072d8d1aac4bf16c283e9de7e49b38")
addappid(1559572, 1, "515a633de6baa5d274ff71d97fd31494941d716968861a1850589aeadbb2a2ed")
addappid(1559573, 1, "86c5393de73119dbc703e603c1349e74e92b8c3320f071455e3eea4cb0b6c867")
addappid(1559574, 1, "c23482ae251a695d6c45c2614b58fbb006b76815e360eb6f6a2437534486aa90")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
