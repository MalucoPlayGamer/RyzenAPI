-- Lua provided by RyzenAPI
-- Game: Vindicator: Uprising

-- MAIN APPLICATION
addappid(367050)

-- MAIN APP DEPOTS / PACKAGES
addappid(367051, 1, "9657dd6d798883df6c8f4a3600250475a5cdfd027c5d723b7427eee517a2a943")
