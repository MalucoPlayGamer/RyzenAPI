-- Lua provided by RyzenAPI
-- Game: AppID 300300

-- MAIN APPLICATION
addappid(300300)
-- Game: addappid(300300)

-- MAIN APP DEPOTS / PACKAGES
addappid(300301, 1, "679cb3bf6616c5844f1ee880ca2bd22d11ae4e9170a81d7a834e37c7cb0db365")
addappid(300302, 1, "47abef6c46c9c577c515bd9676cdbf65ce8da5353b6e1a1707a359d08f56d80d")
addappid(300303, 1, "3a6784da65ebf7af6adffebea412718ff4b23106ca9b3897a790994b2dca7ef4")
