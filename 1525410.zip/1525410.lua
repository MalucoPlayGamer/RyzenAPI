-- Lua provided by SkyAPI 
-- Game: Wulin Chess
addappid(1525410)
addappid(1525411, 1, "2ec9b843b3646364d8d54c68e72c522c0a46f8442719ee27405c487f425ee8bd")
