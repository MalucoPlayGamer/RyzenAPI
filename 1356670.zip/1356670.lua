-- Lua provided by RyzenAPI
-- Game: Sakuna: Of Rice and Ruin

-- MAIN APPLICATION
addappid(1356670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1356671, 1, "2274d0580389444c8d3f76784004263592cf56f22615887102a85e9fdd67996c")

