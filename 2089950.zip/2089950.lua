-- Lua provided by RyzenAPI
-- Game: AppID 2089950

-- MAIN APPLICATION
addappid(2089950)
-- Game: addappid(2089950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089951, 1, "16485fd727dae34b0c09a36cfd6232974baccda1f142ae58020f57a2cd3ddbba")
