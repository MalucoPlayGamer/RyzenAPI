-- Lua provided by RyzenAPI
-- Game: Crow Story

-- MAIN APPLICATION
addappid(1792610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792611, 1, "d422d713960ddbdb1bfd87da7629b8e93df3061e4b613541aca2e1c86b186ca8")

