-- Lua provided by RyzenAPI
-- Game: Crow Story

-- MAIN APPLICATION
addappid(1792610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1792611, 1, "d422d713960ddbdb1bfd87da7629b8e93df3061e4b613541aca2e1c86b186ca8")

