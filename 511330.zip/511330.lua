-- Lua provided by RyzenAPI
-- Game: addappid(511330)

-- MAIN APPLICATION
addappid(511330)

-- MAIN APP DEPOTS / PACKAGES
addappid(511331, 1, "e7d0478029e19211899d50c7f986286448a79bd042b86408dbef9a78f3d4aefc")
addappid(511332, 1, "6da8b1c77fee1d993c2890d74c461609ef629bf4ab493f94d6c4dcc8de5307e4")
