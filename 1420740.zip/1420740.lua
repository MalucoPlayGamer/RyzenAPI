-- Lua provided by RyzenAPI
-- Game: 1420740

-- MAIN APPLICATION
addappid(1420740)
addappid(1580360)
-- Game: addappid(1420740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420741, 1, "61b8e36380f44fd963d80755dc9a469f4d65e21444e827bde69a3a0a7dbcbe36")
addappid(1420742, 1, "127df59bb70070a71bda1bfb3be6199927cb98e3f5d7b8e25d2858ae1a8adb8a")
addappid(1420743, 1, "4aec2ea79178f404123f72575c5462664dcabf7cc50917eecff01f9bb25d5813")
