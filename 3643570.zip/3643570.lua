-- Lua provided by RyzenAPI
-- Game: AppID 3643570

-- MAIN APPLICATION
addappid(3643570)
-- Game: addappid(3643570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3643571, 1, "3ed68c54c6af48da5aa5567bf875830e076239ad29c7e6211fbc17ba132e6fc6")
