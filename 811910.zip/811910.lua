-- Lua provided by RyzenAPI
-- Game: AppID 811910

-- MAIN APPLICATION
addappid(811910)
-- Game: addappid(811910)

-- MAIN APP DEPOTS / PACKAGES
addappid(811911, 1, "19f783d65f9d72c6955a01b29b05eed5f6b1b30cd5ec95007de926f5db571143")
