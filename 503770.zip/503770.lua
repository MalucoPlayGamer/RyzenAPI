-- Lua provided by RyzenAPI
-- Game: Game: Elven Assassin

-- MAIN APPLICATION
addappid(503770)
addappid(2524910)
-- Game: addappid(503770)

-- MAIN APP DEPOTS / PACKAGES
addappid(503771, 1, "4847dd1de9fcf351094865e0e0757667ecced7be8fda54c3784fcf397222feec")
