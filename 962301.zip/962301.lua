-- Lua provided by RyzenAPI
-- Game: Man Chong - Officer Ticket / 満寵使用券

-- MAIN APPLICATION
addappid(962301)

-- MAIN APP DEPOTS / PACKAGES
addappid(962301,0,"c8ef36e68d5068762a3701e8188c552ac0edf4ca1fe28bc50654f689b50c084b")
