-- Lua provided by RyzenAPI
-- Game: Pregnant Ogre

-- MAIN APPLICATION
addappid(2137190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137191, 1, "d699b3c796a17f2bde7d9b7bdf1f290d4d5ec681ac1f7610c2073cd98a1c072e")
addappid(2137192, 1, "18af96be5b888204a15794f7746ab388181a083b1e1b00c83ccb947a4cc3b81c")
