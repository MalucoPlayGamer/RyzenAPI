-- Lua provided by RyzenAPI
-- Game: addappid(2871180)

-- MAIN APPLICATION
addappid(2871180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871181, 1, "3f960d72023ae312f2fdf88f91d96a7049de5fef7a4c93dc4fd6a7cddfbe4b6e")
