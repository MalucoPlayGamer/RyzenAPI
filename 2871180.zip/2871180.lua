-- Lua provided by SkyAPI 
-- Game: Always Forward
addappid(2871180)
addappid(2871181, 1, "3f960d72023ae312f2fdf88f91d96a7049de5fef7a4c93dc4fd6a7cddfbe4b6e")
