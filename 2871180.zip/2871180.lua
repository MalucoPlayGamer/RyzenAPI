-- Lua provided by RyzenAPI
-- Game: Always Forward

-- MAIN APPLICATION
addappid(2871180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2871181, 1, "3f960d72023ae312f2fdf88f91d96a7049de5fef7a4c93dc4fd6a7cddfbe4b6e")

