-- Lua provided by RyzenAPI
-- Game: Game: DrakulA

-- MAIN APPLICATION
addappid(1534770)
-- Game: addappid(1534770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534771, 1, "809ef4577bfc1082c3bc3c8efa2abca33af4d9705f85ef8d126d0d137fa078cd")
