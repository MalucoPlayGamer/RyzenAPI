-- Lua provided by RyzenAPI
-- Game: UNICLR - Additional Character Londrekia & Additional Gallery Item

-- MAIN APPLICATION
addappid(1216950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216950,0,"3fd91689671e5e4bb79d727667413253dd9149e60fdb07f0b8e7d589802d7c4b")

