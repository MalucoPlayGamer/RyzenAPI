-- Lua provided by RyzenAPI 
-- Game: Soft cookie
addappid(1019070)
addappid(1019071, 1, "0abc674c4a2000fd0cd7477658eaa2d5f870e85847feb62bc8ec8a2d7eecd9f3")
