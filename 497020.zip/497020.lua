-- Lua provided by RyzenAPI
-- Game: Game: AppID 497020

-- MAIN APPLICATION
addappid(497020)
-- Game: addappid(497020)

-- MAIN APP DEPOTS / PACKAGES
addappid(497021, 1, "3c540b07cf7834d0cc42d6b38338de4d9f87c07d5551e477499c67c4d0f2a182")
