-- Lua provided by RyzenAPI
-- Game: Thank Goodness You're Here!

-- MAIN APPLICATION
addappid(2366980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366981, 1, "436c3a988f36c4fc3f8bebe8661ad1a4ce467bfad673d0a76c1cc174a44792f0")
addappid(2366982, 1, "c3653cc3f2c3580882e504a12cad17115a9b5574f3a569a6625eddc03a1a7a02")

