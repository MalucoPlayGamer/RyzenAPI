-- Lua provided by RyzenAPI
-- Game: Game: Negative: The Way of Shinobi

-- MAIN APPLICATION
addappid(1504010)
-- Game: addappid(1504010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504011, 1, "f10f649a84a61211251cea52515159efe7dd937c069bf84f6fc502ec57574b4a")
