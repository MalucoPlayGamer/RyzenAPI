-- Lua provided by RyzenAPI
-- Game: New Cycle

-- MAIN APPLICATION
addappid(2198510)
-- Game: addappid(2198510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198511, 1, "cc63e967354dee46c1617e73a460c60281c8c39681d133bac4e8dde913ae7f47")
addappid(2731240, 0, "e2843df7fe82e31f0567798a3812e5b8ab9428c9c7c1d4e0a17e16d26ad3da49")
