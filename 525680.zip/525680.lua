-- Lua provided by RyzenAPI
-- Game: Deisim

-- MAIN APPLICATION
addappid(525680)

-- MAIN APP DEPOTS / PACKAGES
addappid(525681, 1, "6fe1c0eab36fab7b608d24cc87b0bb54be81ab400d06f8b383a23bd27d541758")

