-- Lua provided by RyzenAPI
-- Game: AppID 514900

-- MAIN APPLICATION
addappid(514900)

-- MAIN APP DEPOTS / PACKAGES
addappid(514901, 1, "9d4dfcb2bbaf5e1c768e52ccbde211a2781fcfacd067163584bb94cae0f0f36d")
addappid(514902, 1, "925841fe97a736e76f041bf2ba2253d3490fbf4e8b3768d96ef03d850b6cb275")
addappid(514903, 1, "da779431dc57614486550c49639ebd27ee1b836bf68fa771f6367a78fc0a362a")
addappid(939320, 0, "02ae7393068735ffb3a6956b6517a3b0a70302442b1f877b032b002847311d0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
