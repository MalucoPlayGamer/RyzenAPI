-- Lua provided by RyzenAPI
-- Game: addappid(1101060)

-- MAIN APPLICATION
addappid(1101060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101061, 1, "69d35dceb8cfb91104d91203f0af7c9ab82334e82b3bfe2f313fe7c7018579ae")
