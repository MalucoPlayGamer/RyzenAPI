-- Lua provided by RyzenAPI
-- Game: AppID 1090590

-- MAIN APPLICATION
addappid(1090590)
-- Game: addappid(1090590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090591, 1, "155a77ca3e7b4483ef656e61339215e78db1b2197feff9c08e8fb006910af960")
