-- Lua provided by RyzenAPI
-- Game: Ultimate Panic Flight

-- MAIN APPLICATION
addappid(797550)

-- MAIN APP DEPOTS / PACKAGES
addappid(797551, 1, "8d4315ce200aa20288f7cc2f6b3ac7d92f2704b074c55a45fdf981b2e1182c27")
addappid(797552, 1, "270e35b59317b46e83d663fa6798837dd26dfca66f8a8963f47dcc40c50e14f7")
