-- Lua provided by RyzenAPI
-- Game: Game: NSFW Solitaire & Puzzles

-- MAIN APPLICATION
addappid(2274120)
-- Game: addappid(2274120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274121, 1, "8ab778e04e57fdbbab09a082231e133ae4f45bf4a89761efec9472468bec95c8")
addappid(2274122, 1, "56160889f27ab6a4a245e436cf97e3d725c21b9e1baba88b44322999e595b47f")
addappid(2274123, 1, "085b0114c448bb594e608313a78f106a6436965c0e39153fac4cdddee43d2bc0")
