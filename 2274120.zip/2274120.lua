-- Lua provided by RyzenAPI
-- Game: NSFW Solitaire & Puzzles

-- MAIN APPLICATION
addappid(2274120)
addappid(2344840)
addappid(3092690)
addappid(3115110)
addappid(3513450)
addappid(3788630)
addappid(3831360)
addappid(3880230)
addappid(4015910)
addappid(4160570)
addappid(4185840)
addappid(4193710)
addappid(4208020)
addappid(4231120)
addappid(4255020)
addappid(4265010)
addappid(4280200)
addappid(4297330)
addappid(4303230)
addappid(4317890)
addappid(4351630)
addappid(4402440)
addappid(4424960)
addappid(4456870)
addappid(4684870)
addappid(4779540)
addappid(4877450)
addappid(4927400)
addappid(4968670)
addappid(5039410)
addappid(5075430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274121, 1, "8ab778e04e57fdbbab09a082231e133ae4f45bf4a89761efec9472468bec95c8")
addappid(2274122, 1, "56160889f27ab6a4a245e436cf97e3d725c21b9e1baba88b44322999e595b47f")
addappid(2274123, 1, "085b0114c448bb594e608313a78f106a6436965c0e39153fac4cdddee43d2bc0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5154530)
