-- Lua provided by RyzenAPI
-- Game: Game: Vetrix Worlds

-- MAIN APPLICATION
addappid(1992860)
-- Game: addappid(1992860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992861, 1, "2a7b35a888175a80463211e91e7645068379304d6cf093624f1860b33831ef9e")
