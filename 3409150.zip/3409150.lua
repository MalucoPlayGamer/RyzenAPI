-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Stone Quarry Tileset

-- MAIN APPLICATION
addappid(3409150)
-- Game: addappid(3409150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3409150,0,"12d0114c89bcc86eef2b486a96481a665f61fdabbaa293d0a8772d889fd89046")
