-- Lua provided by RyzenAPI
-- Game: ΔV: Rings of Saturn Demo

-- MAIN APPLICATION
addappid(949730)
-- Game: addappid(949730)

-- MAIN APP DEPOTS / PACKAGES
addappid(949732,0,"c67582d836e33105afaf87aa0275108f7200ca8e6321b2c353b966ccb1ac8e23")
