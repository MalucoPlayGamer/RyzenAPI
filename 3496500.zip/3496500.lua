-- Lua provided by RyzenAPI
-- Game: Game: Orb Tower

-- MAIN APPLICATION
addappid(3496500)
-- Game: addappid(3496500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496501, 1, "56efda99cb388cb0bd0cc08f4cafd1a4c532540c0a04c1ae69634ae932e2f04f")
