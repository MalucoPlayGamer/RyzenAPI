-- Lua provided by RyzenAPI
-- Game: False Dichotomy

-- MAIN APPLICATION
addappid(1359990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359991, 1, "347e4e2f151ce1656916d17267ded0131e3d05703271921071b676e7e53db9ef")

