-- Lua provided by RyzenAPI
-- Game: AppID 436480

-- MAIN APPLICATION
addappid(436480)

-- MAIN APP DEPOTS / PACKAGES
addappid(436481, 1, "3385b00397e2ef53f0250c72fd6b57eb235322a0aa9289ca60b75c61f423b3f8")
addappid(436482, 1, "bbb9186cfb8f8022185814f5b77036951b66309db3481db5d3d27abc68260fca")
addappid(436483, 1, "b178ecfd5521f0de817bcbac31efd3f003facf8fa8282acfae77d4c9be7cfe49")

