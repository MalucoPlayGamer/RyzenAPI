-- Lua provided by RyzenAPI
-- Game: Ripple In Dirac Sea

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2421650)
-- Game: addappid(2421650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421652,0,"d93aff6b572ecb2a36bc34f41b1869706b56a98251ef8bb697f798d1d1303813")
