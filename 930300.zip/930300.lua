-- Lua provided by RyzenAPI
-- Game: Desolate Sands

-- MAIN APPLICATION
addappid(930300)

-- MAIN APP DEPOTS / PACKAGES
addappid(930301, 1, "d90073899e0db1c10d2af3776badab3904a5e9d208a9d00a776990d7e9db3abf")

