-- Lua provided by RyzenAPI
-- Game: Desolate Sands

-- MAIN APPLICATION
addappid(930300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(930301, 1, "d90073899e0db1c10d2af3776badab3904a5e9d208a9d00a776990d7e9db3abf")

