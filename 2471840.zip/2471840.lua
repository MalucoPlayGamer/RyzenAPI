-- Lua provided by RyzenAPI
-- Game: 2471840

-- MAIN APPLICATION
addappid(2471840)
-- Game: addappid(2471840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471841, 1, "192fd392deaea675c31bb69eb52f1335128b207b2f1165d50e2ebbd83af97dd9")
