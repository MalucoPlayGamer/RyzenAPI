-- Lua provided by RyzenAPI
-- Game: AppID 256350

-- MAIN APPLICATION
addappid(256350)
-- Game: addappid(256350)

-- MAIN APP DEPOTS / PACKAGES
addappid(256351, 1, "e240599cfb68da2017364011990de9729cfdd4475e746067d595b35cc208db8a")
