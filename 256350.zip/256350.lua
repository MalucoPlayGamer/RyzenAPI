-- Lua provided by RyzenAPI
-- Game: WRC Powerslide

-- MAIN APPLICATION
addappid(256350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(256351, 1, "e240599cfb68da2017364011990de9729cfdd4475e746067d595b35cc208db8a")
