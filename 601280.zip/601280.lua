-- Lua provided by RyzenAPI
-- Game: Village Story

-- MAIN APPLICATION
addappid(601280)

-- MAIN APP DEPOTS / PACKAGES
addappid(601281, 1, "f4c282f5ef569d1b7829edf4943aaa22a495ab904f7355953c4b9e2d414df495")
