-- Lua provided by RyzenAPI
-- Game: Game: Dashpong

-- MAIN APPLICATION
addappid(1729250)
-- Game: addappid(1729250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729251, 1, "6d351f77411d616136dfa82eee6b2aa3a24c6b7f4dbc8b0933a4bec4a680aa98")
