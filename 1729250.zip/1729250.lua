-- Lua provided by RyzenAPI 
-- Game: Dashpong
addappid(1729250)
addappid(1729251, 1, "6d351f77411d616136dfa82eee6b2aa3a24c6b7f4dbc8b0933a4bec4a680aa98")
