-- Lua provided by RyzenAPI
-- Game: addappid(3210580)

-- MAIN APPLICATION
addappid(3210580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210581, 1, "066b0243fc889619b1babc96ce3fd557bff755495e16c1991669d825a9bf68e1")
