-- Lua provided by SkyAPI 
-- Game: SPARROW DEMO
addappid(3210580)
addappid(3210581, 1, "066b0243fc889619b1babc96ce3fd557bff755495e16c1991669d825a9bf68e1")
