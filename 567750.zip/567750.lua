-- Lua provided by SkyAPI 
-- Game: AppID 567750
addappid(567750)
addappid(567751, 1, "bd5c25f75eadeab406d6da8f58f3c7775aca1a52a92d9d35c2533d28dfd83f16")
