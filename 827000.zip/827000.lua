-- Lua provided by SkyAPI 
-- Game: Celtic Kings: Rage of War
addappid(827000)
addappid(827001, 1, "4edad004939de7ebec8ee8afb56f075480f2bc03d62ae1c657e2b2e533666d74")
