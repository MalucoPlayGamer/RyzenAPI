-- 277950's Lua and Manifest Created by Hubcap Manifest
-- Deadbreed®
-- Created: September 29, 2025 at 06:57:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 12 (1 excluded)
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(277950) -- Deadbreed®
-- MAIN APP DEPOTS
addappid(277951, 1, "740cb4098eb16010bc602aa63a09dac96e2047105c2e8bef1ad1b7947ea27ef3") -- Deadbreed Content
setManifestid(277951, "3010222839920741905", 3223783455)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(305410) -- Deadbreed  Bare Bones Beta Pack
addappid(305420) -- Deadbreed  Death Deluxe Beta Pack
addappid(305430) -- Deadbreed  Nightbreed Beta Pack
addappid(305431) -- Deadbreed  Daybreed Beta Pack
addappid(314750) -- Deadbreed  Undertaker Beta Pack
addappid(336260) -- Deadbreed  Undead Beta Pack
addtoken(336260, "8843931963629208393")
addappid(452201) -- Deadbreed  Armory Value Pack
addappid(459740) -- Deadbreed  Daybreak Breed Pack
addappid(459741) -- Deadbreed  Nightfall Breed Pack
addappid(459742) -- Deadbreed  Twilight Breed Pack
addappid(459743) -- Deadbreed  Starter Value Pack
addappid(459744) -- Deadbreed  Nekro Deluxe Pack
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(452200) -- Deadbreed® – Super Silver Value Pack (unreleased)