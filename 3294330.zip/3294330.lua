-- Lua provided by RyzenAPI
-- Game: 201 - The Bad Number

-- MAIN APPLICATION
addappid(3294330)
-- Game: addappid(3294330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294331, 1, "1b983c5ce93d648ccd4c0c18e42f4d0439f27007ac16e9c5af4f5ae48d9d3e5a")
