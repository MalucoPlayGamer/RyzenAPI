-- Lua provided by RyzenAPI
-- Game: Ionia

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1121140)
addappid(1796400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121142,0,"c564fdf18a9bbe2fdc6bae4a36b89187416af7842e160f27b5912719ee34e2d7")
