-- Lua provided by RyzenAPI
-- Game: 1543520

-- MAIN APPLICATION
addappid(1543520)
-- Game: addappid(1543520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543522,0,"bb93b1ed4f9fbd2aac127916b1d725c78c1567f40ae589ee581fec990964c312")
