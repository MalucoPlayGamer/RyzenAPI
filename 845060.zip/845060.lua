-- Lua provided by RyzenAPI
-- Game: 845060

-- MAIN APPLICATION
addappid(845060)
-- Game: addappid(845060)

-- MAIN APP DEPOTS / PACKAGES
addappid(845061, 1, "539ae8a17fc78a2bbbd2d7f72dc0c2171e324f03bb1e7aabbdf0e81ad51e3abf")
