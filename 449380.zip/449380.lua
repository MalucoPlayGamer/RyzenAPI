-- Lua provided by RyzenAPI
-- Game: Substance Designer 6

-- MAIN APPLICATION
addappid(449380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(449381, 1, "bb4180affe1a12778ac9b93df2e53c1949880e3ec5a5bb4dd7f0ca615210f325")
