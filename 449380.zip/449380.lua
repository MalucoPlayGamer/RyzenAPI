-- Lua provided by SkyAPI 
-- Game: AppID 449380
addappid(449380)
addappid(449381, 1, "bb4180affe1a12778ac9b93df2e53c1949880e3ec5a5bb4dd7f0ca615210f325")
