-- Lua provided by SkyAPI 
-- Game: Dominated by: Yandere Goth Cop
addappid(3832790)
addappid(3832791, 1, "d4290667829fb83509fed39bbca65b10c7575a84270ec27bba5666c699ceedb7")
