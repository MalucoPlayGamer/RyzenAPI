-- Lua provided by RyzenAPI
-- Game: 3228680

-- MAIN APPLICATION
addappid(3228680)
addappid(3763140)
-- Game: addappid(3228680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228681, 1, "7057aaf89dcffdddacf30206affe2880c2e696f7ffaf69095ca3ddda4e4901c9")
