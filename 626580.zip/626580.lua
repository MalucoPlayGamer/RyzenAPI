-- Lua provided by RyzenAPI
-- Game: 626580

-- MAIN APPLICATION
addappid(626580)
-- Game: addappid(626580)

-- MAIN APP DEPOTS / PACKAGES
addappid(626581, 1, "e12e33069689ad111d8a6c03bf83221b0231389219a33dac63ef1738b3a2637f")
