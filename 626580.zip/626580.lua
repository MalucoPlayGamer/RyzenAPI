-- Lua provided by SkyAPI 
-- Game: AppID 626580
addappid(626580)
addappid(626581, 1, "e12e33069689ad111d8a6c03bf83221b0231389219a33dac63ef1738b3a2637f")
