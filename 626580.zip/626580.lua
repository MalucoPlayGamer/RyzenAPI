-- Lua provided by RyzenAPI
-- Game: AppID 626580

-- MAIN APPLICATION
addappid(626580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(626581, 1, "e12e33069689ad111d8a6c03bf83221b0231389219a33dac63ef1738b3a2637f")

