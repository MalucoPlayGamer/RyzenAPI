-- Lua provided by RyzenAPI 
-- Game: AppID 3457390
addappid(3457390)
addappid(3457391, 1, "8ae955b4c5d7c6560e8c5c0dbd08c5eb86609cd38f3cf74880b4b9f67879b4d4")
