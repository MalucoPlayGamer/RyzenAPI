-- Lua provided by RyzenAPI
-- Game: AppID 3457390

-- MAIN APPLICATION
addappid(3457390)
-- Game: addappid(3457390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3457391, 1, "8ae955b4c5d7c6560e8c5c0dbd08c5eb86609cd38f3cf74880b4b9f67879b4d4")
