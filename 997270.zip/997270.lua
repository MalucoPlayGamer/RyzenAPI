-- Lua provided by RyzenAPI
-- Game: Game: 傲皇忆剑诀

-- MAIN APPLICATION
addappid(997270)
-- Game: addappid(997270)

-- MAIN APP DEPOTS / PACKAGES
addappid(997271, 1, "75d710af4111cedb992b70d1da63410c3b4edd3d6581cf7a7199b5001cd5b2fa")
