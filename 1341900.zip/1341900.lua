-- Lua provided by RyzenAPI
-- Game: Castle on the Coast

-- MAIN APPLICATION
addappid(1341900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341902,0,"f2be84212322011f9e38b361a8925aa286197e2c54c2f0d2e43c54869f2f8382")
addappid(1341903,0,"1a3e64169d9cf193a9fb129fec2bd07df78bacb0a103b6f1394b6b2d2de6acd2")

