-- Lua provided by RyzenAPI
-- Game: Castle on the Coast

-- MAIN APPLICATION
addappid(1341900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341902,0,"f2be84212322011f9e38b361a8925aa286197e2c54c2f0d2e43c54869f2f8382")
addappid(1341903,0,"1a3e64169d9cf193a9fb129fec2bd07df78bacb0a103b6f1394b6b2d2de6acd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
