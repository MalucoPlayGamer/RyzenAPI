-- Lua provided by RyzenAPI
-- Game: 帷幕跑团 Demo

-- MAIN APPLICATION
addappid(3231730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231731, 1, "8fd80c7c243c1e47596ae8211ebf53ff5662d9e0eb12a3f2e1d1ffee8ec083e4")
