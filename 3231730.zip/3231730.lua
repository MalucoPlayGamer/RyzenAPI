-- Lua provided by SkyAPI 
-- Game: 帷幕跑团 Demo
addappid(3231730)
addappid(3231731, 1, "8fd80c7c243c1e47596ae8211ebf53ff5662d9e0eb12a3f2e1d1ffee8ec083e4")
