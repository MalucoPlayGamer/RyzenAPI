-- Lua provided by RyzenAPI
-- Game: Night in the Woods - Soundtrack Vol. II

-- MAIN APPLICATION
addappid(610221)

-- MAIN APP DEPOTS / PACKAGES
addappid(610221,0,"23f056deadaf38d8c6bb78d9a9d42d23d36a1842f880824533520bee4b28df35")
