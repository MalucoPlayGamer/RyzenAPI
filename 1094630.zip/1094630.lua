-- Lua provided by RyzenAPI
-- Game: Aircraft War

-- MAIN APPLICATION
addappid(1094630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094631, 1, "451b930ffb19e16482644f22df4b284885cc0a9286b3492315ccc99afcf0de5a")
addappid(1094632, 1, "c5262e78454184fd9eab6e3940a39ea4fafbc66ed32dbe4ba2f0a9f2bbc37a4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1126940)
addappid(1132330)
addappid(1156560)
addappid(1175990)
addappid(1234510)
addappid(1241000)
addappid(2167250)
