-- Lua provided by RyzenAPI
-- Game: 3156480

-- MAIN APPLICATION
addappid(3156480)
-- Game: addappid(3156480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156481, 1, "0ae381be8499a6c79448df1a7c8db84966afe342d4318b6325abef35e6602a87")
