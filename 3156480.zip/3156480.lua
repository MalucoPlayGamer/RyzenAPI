-- Lua provided by RyzenAPI
-- Game: 绝尘 Demo

-- MAIN APPLICATION
addappid(3156480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156481, 1, "0ae381be8499a6c79448df1a7c8db84966afe342d4318b6325abef35e6602a87")
