-- Lua provided by RyzenAPI
-- Game: Seeker Shrine

-- MAIN APPLICATION
addappid(4413860) -- Seeker Shrine

-- MAIN APP DEPOTS / PACKAGES
addappid(4413861, 1, "59eeeb6815f2594af9f1601e000a2a9a6604a3bc8cfbe0a1c0b472b1af6ae0be") -- Depot 4413861
addappid(4413862, 1, "d67a20b6443e11d72485600da7a00cef868290631cfa49b52a2ad0071494049e") -- Depot 4413862
addappid(4413863, 1, "6673669eaff530a533681b62da1917748b4c06503d58dd719101d19dd1edfb0a") -- Depot 4413863

