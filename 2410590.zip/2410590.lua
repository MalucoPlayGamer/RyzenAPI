-- Lua provided by RyzenAPI
-- Game: Dunk Dunk

-- MAIN APPLICATION
addappid(2410590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410591, 1, "c621703e8c123e60bced9ab3f3c1f57800ced3a2fb0cfce1cdba6a27ba2f5bcc")

