-- Lua provided by RyzenAPI
-- Game: AppID 905130

-- MAIN APPLICATION
addappid(905130)
-- Game: addappid(905130)

-- MAIN APP DEPOTS / PACKAGES
addappid(905131, 1, "427b6cc48e2caa63787982959685efc66a830c5dc2a250b2977ad5cb6e4ae427")
