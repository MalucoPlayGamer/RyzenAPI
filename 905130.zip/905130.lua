-- Lua provided by RyzenAPI
-- Game: AppID 905130

-- MAIN APPLICATION
addappid(905130)

-- MAIN APP DEPOTS / PACKAGES
addappid(905131, 1, "427b6cc48e2caa63787982959685efc66a830c5dc2a250b2977ad5cb6e4ae427")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
