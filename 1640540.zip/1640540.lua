-- Lua provided by RyzenAPI
-- Game: DESOLATIUM: Prologue

-- MAIN APPLICATION
addappid(1640540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1640541, 1, "bee01425c567fc9a4a449720bc8877e3d23475254ce9f5881763a258e13c7561")
addappid(1640543, 1, "4a5e175c9de1e1f3211cc242f9693961cf1fc787a1b1cf0fe3338672740d7faa")

