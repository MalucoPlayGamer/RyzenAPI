-- Lua provided by RyzenAPI
-- Game: Era of Majesty

-- MAIN APPLICATION
addappid(412130)

-- MAIN APP DEPOTS / PACKAGES
addappid(412131, 1, "9ecbfeb997a028be2aed71c9c143da4867bdbeab6527124e0d000bdd3ebde368")
