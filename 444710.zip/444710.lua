-- Lua provided by RyzenAPI
-- Game: Battle Crust

-- MAIN APPLICATION
addappid(444710)
-- Game: addappid(444710)

-- MAIN APP DEPOTS / PACKAGES
addappid(444711, 1, "73b02451de91170bb7f2e8eea20f7d03cabb73ff2d897da83410cedcc615e66b")
