-- Lua provided by RyzenAPI
-- Game: Battle Crust

-- MAIN APPLICATION
addappid(444710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(444711, 1, "73b02451de91170bb7f2e8eea20f7d03cabb73ff2d897da83410cedcc615e66b")

