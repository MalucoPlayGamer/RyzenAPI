-- Lua provided by RyzenAPI 
-- Game: AppID 2374000
addappid(2374000)
addappid(2374001, 1, "cdbe149547ceb64384de08a06d926c7f059565e7d85de3a181073bd7ece0b9b3")
