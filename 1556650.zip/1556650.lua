-- Lua provided by RyzenAPI
-- Game: Castle of Shikigami 2

-- MAIN APPLICATION
addappid(1556650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556651, 1, "91efaffff98bef3ed55848099f440d3ada8eea4ff0624b50d94322f3ed361a02")

