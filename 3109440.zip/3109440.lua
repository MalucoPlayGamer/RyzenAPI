-- Lua provided by RyzenAPI
-- Game: Breakout Epilepsia

-- MAIN APPLICATION
addappid(3109440)
