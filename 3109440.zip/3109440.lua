-- Lua provided by RyzenAPI
-- Game: Breakout Epilepsia

-- MAIN APPLICATION
addappid(3109440)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3192890)
