-- Generated with Luie @ https://lua.tools/
-- 845210 - Sim Racing Telemetry
-- Generated 2026-08-19 17:19:08 UTC
-- # Depots (Total/DLC/Shared): 3/0/1

-- Main AppID
addappid(845210)

-- Main Depots
addappid(845211, 1, "c9535219adeac4dde68e887abe173ee026ed0a45ed519b6d8fe263ed94d60015") -- (windows)
setManifestid(845211, "8396778508924249488", 370645785)
addappid(845212, 1, "fe82805b54ed4dc37012a491ba619bb81ba3ec4cc44087a414110ece131251e8") -- (macos)
setManifestid(845212, "6560501092125766129", 432932946)

-- DLC's (no depot keys required)
addappid(860230) -- Sim Racing Telemetry - F1 2016
addappid(860231) -- Sim Racing Telemetry - Project Cars
addappid(860232) -- Sim Racing Telemetry - F1 2017
addappid(860233) -- Sim Racing Telemetry - Project Cars 2
addappid(885660) -- Sim Racing Telemetry - MotoGP 18
addappid(927330) -- Sim Racing Telemetry - F1 2018
addappid(1127420) -- Sim Racing Telemetry - F1 2019
addappid(1386820) -- Sim Racing Telemetry - F1 2020
addappid(1660060) -- Sim Racing Telemetry - Assetto Corsa
addappid(1660061) -- Sim Racing Telemetry - F1 2021
addappid(2056900) -- Sim Racing Telemetry - F1 22
addappid(2133690) -- Sim Racing Telemetry - Assetto Corsa Competizione
addappid(2426210) -- Sim Racing Telemetry - F1 23
addappid(2644860) -- Sim Racing Telemetry - Automobilista 2
addappid(2962200) -- Sim Racing Telemetry - F1 24
addappid(3692310) -- Sim Racing Telemetry - F1 25
addappid(4777350) -- Sim Racing Telemetry - F1 26 (F1 25: 2026 Season Pack)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
