-- Lua provided by RyzenAPI
-- Game: Game: Sim Racing Telemetry

-- MAIN APPLICATION
addappid(845210)
-- Game: addappid(845210)

-- MAIN APP DEPOTS / PACKAGES
addappid(845211, 1, "c9535219adeac4dde68e887abe173ee026ed0a45ed519b6d8fe263ed94d60015")
addappid(845212, 1, "fe82805b54ed4dc37012a491ba619bb81ba3ec4cc44087a414110ece131251e8")
