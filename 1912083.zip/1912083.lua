-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1912083)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912083,0,"aba65a1e5ea04abc5f420c9f13ac9e8afc44c922e9f34f8059874ca092740666")
