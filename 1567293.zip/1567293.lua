-- Lua provided by RyzenAPI
-- Game: STORY OF SEASONS: Pioneers of Olive Town - Neil's Jacket

-- MAIN APPLICATION
addappid(1567293)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567293,0,"112b71b1b5c076a4c228c552afdc6989a44337cbbb060c172699e489b42f16d4")
