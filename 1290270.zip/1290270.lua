-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade — Night Road

-- MAIN APPLICATION
addappid(1290270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290271, 1, "148a239c347a4dda889f2f64a24ef3afe100c6b7d8d43acfff0443320d9037cd")
