-- Lua provided by SkyAPI 
-- Game: Five Nights: No Escape
addappid(2374030)
addappid(2374031, 1, "f1cf95d90027bd3678ec99592bc3acc66017e6d409d75c9f08824f2fd8d89357")
