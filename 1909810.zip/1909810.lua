-- Lua provided by RyzenAPI
-- Game: Game: Seventh Lair

-- MAIN APPLICATION
addappid(1909810)
-- Game: addappid(1909810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909811, 1, "4074938a97af1c13b32ac7ab444c9e4a3d459192202e2aee1fd672ada8fe2204")
