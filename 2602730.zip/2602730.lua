-- Lua provided by RyzenAPI 
-- Game: AppID 2602730
addappid(2602730)
addappid(2602731, 1, "d31ce66b412e106551e16fc2ec0e70d495569a4830a855175f3c9db1b1cb6676")
addappid(2646310, 0, "15a40d2c1d05823949f946c3cba278c73f5d613b71d87d4f41787c7acc7b6cab")
