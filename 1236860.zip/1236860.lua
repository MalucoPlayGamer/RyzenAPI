-- Lua provided by RyzenAPI
-- Game: Edge of Reality

-- MAIN APPLICATION
addappid(1236860)
-- Game: addappid(1236860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236861, 1, "87a93659702a9149871ab8991381932ec68abd033f3459835e70079f12a4c1d2")
