-- Lua provided by RyzenAPI
-- Game: addappid(3097380)

-- MAIN APPLICATION
addappid(3097380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097381, 1, "2fccab5af5563ca8df5da69d0f87d7a0b22af653c661f334899506e63d220582")
