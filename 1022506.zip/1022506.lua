-- Lua provided by RyzenAPI
-- Game: addappid(1022506)

-- MAIN APPLICATION
addappid(1022506)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022506,0,"9a048b25b68d9a4e5978ee9b6356320e4dcaffe4d7215ad359d35a0e67c9b730")
