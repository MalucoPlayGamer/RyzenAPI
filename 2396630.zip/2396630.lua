-- Lua provided by RyzenAPI
-- Game: Game: Unsupervised

-- MAIN APPLICATION
addappid(2396630)
-- Game: addappid(2396630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396631, 1, "ff3b8472dc57a80ba5ba96595402ec970475436cc3b2f353263626c123692f88")
