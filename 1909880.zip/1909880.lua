-- Lua provided by RyzenAPI 
-- Game: サイコロサイコ セブンスヘブン
addappid(1909880)
addappid(1909881, 1, "d0525159e36bd099e2bee516fd0d75cc2bb9db4343f3f96a7a0d10edfc310ccd")
