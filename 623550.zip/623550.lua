-- Lua provided by RyzenAPI 
-- Game: AppID 623550
addappid(623550)
addappid(623551, 1, "6c936d10058084d17b1145d6f61105264df3e936f52fbb5714fdb51445d89864")
