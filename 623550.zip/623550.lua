-- Lua provided by RyzenAPI
-- Game: Game: AppID 623550

-- MAIN APPLICATION
addappid(623550)
-- Game: addappid(623550)

-- MAIN APP DEPOTS / PACKAGES
addappid(623551, 1, "6c936d10058084d17b1145d6f61105264df3e936f52fbb5714fdb51445d89864")
