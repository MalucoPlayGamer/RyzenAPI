-- Lua provided by RyzenAPI
-- Game: addappid(3147550)

-- MAIN APPLICATION
addappid(3147550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147551, 1, "dadbd0f5a301439ee8f566f4a8bfbc3c0a72006e3133e57acb9af3d8ec28136f")
