-- Lua provided by RyzenAPI
-- Game: Sketch Crawler

-- MAIN APPLICATION
addappid(1731260)
addappid(3288410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731261, 1, "4c329282a0e1c86c11a6f1ffc1dd767681a89d1b6db6d4bf016de50477ade337")

