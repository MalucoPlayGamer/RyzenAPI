-- Lua provided by RyzenAPI
-- Game: 1435440

-- MAIN APPLICATION
addappid(1435440)
-- Game: addappid(1435440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435441, 1, "2f2892e6d62c2779809a1def6b724b94379f682a9f8b84cb0b9179eef4304a18")
