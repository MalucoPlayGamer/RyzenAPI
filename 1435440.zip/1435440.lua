-- Lua provided by RyzenAPI
-- Game: Dark Dragonkin

-- MAIN APPLICATION
addappid(1435440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1435441, 1, "2f2892e6d62c2779809a1def6b724b94379f682a9f8b84cb0b9179eef4304a18")

