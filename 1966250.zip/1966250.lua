-- Lua provided by RyzenAPI
-- Game: 1966250

-- MAIN APPLICATION
addappid(1966250)
-- Game: addappid(1966250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966251, 1, "ae7be24ae59e0e4aea41732b1696aa0fbdbab504f89af565b5746b5d958a0abb")
