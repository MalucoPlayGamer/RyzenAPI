-- Lua provided by RyzenAPI
-- Game: Black Hat Cooperative

-- MAIN APPLICATION
addappid(503100)

-- MAIN APP DEPOTS / PACKAGES
addappid(503101, 1, "5e2ad92467af2c983adf28ce29a83c1de2d0376c7b47f53c09af80367db9d4b7")
