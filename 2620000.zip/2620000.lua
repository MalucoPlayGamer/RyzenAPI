-- Lua provided by RyzenAPI
-- Game: BULLETHELL

-- MAIN APPLICATION
addappid(2620000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620001, 1, "74b784a107c0e4d5850c5cc881c607b7c36bc1639d607e00e5ed18265950af18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
