-- Lua provided by RyzenAPI 
-- Game: BULLETHELL
addappid(2620000)
addappid(2620001, 1, "74b784a107c0e4d5850c5cc881c607b7c36bc1639d607e00e5ed18265950af18")
