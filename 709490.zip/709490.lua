-- Lua provided by RyzenAPI 
-- Game: AppID 709490
addappid(709490)
addappid(709491, 1, "8b993762d886235198bfd7407ac8a7787f144e0cba7a04cadce0472b53005333")
addappid(709492, 1, "49f92c3f3f69fdb431992c477a54c0781bf50f438e5bc5ba55edd903a20d6dbd")
