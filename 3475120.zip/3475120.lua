-- Lua provided by RyzenAPI
-- Game: Image2pixel-PixelArtGenerator

-- MAIN APPLICATION
addappid(3475120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3475121, 1, "0358dbc41c51fbb9da961b3c6469acf91a09f6a8c21e48c7da4ed89c6004c6f9")
