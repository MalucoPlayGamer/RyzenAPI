-- Lua provided by RyzenAPI
-- Game: 3651480

-- MAIN APPLICATION
addappid(3651480)
-- Game: addappid(3651480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3651481, 1, "adef690fca07f7a0bc6924b21e18be559528a7075e071cf97b6f2e6946376ddb")
