-- Lua provided by RyzenAPI
-- Game: addappid(1080420)

-- MAIN APPLICATION
addappid(1080420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080420,0,"7932deafc36a6fe75ac8a5b498c563ff0ca6929f18cf6eb9a963a0821ef506ca")
