-- Lua provided by RyzenAPI
-- Game: 1795880

-- MAIN APPLICATION
addappid(1795880)
-- Game: addappid(1795880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795882,0,"3c9b30b23ca79af0687f91309e46e570ca5287e58bff0e0aba1655f1f9efaba4")
