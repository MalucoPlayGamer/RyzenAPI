-- Lua provided by RyzenAPI
-- Game: Game: AppID 485500

-- MAIN APPLICATION
addappid(485500)
-- Game: addappid(485500)

-- MAIN APP DEPOTS / PACKAGES
addappid(485501, 1, "d41556026d7ea01a16c749f87f1569a0901ad3e8d30fe1e50f39cb4194b5251f")
