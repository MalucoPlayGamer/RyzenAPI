-- Lua provided by RyzenAPI 
-- Game: AppID 485500
addappid(485500)
addappid(485501, 1, "d41556026d7ea01a16c749f87f1569a0901ad3e8d30fe1e50f39cb4194b5251f")
