-- Lua provided by RyzenAPI 
-- Game: KALPA: Cosmic Symphony
addappid(2717010)
addappid(2717011, 1, "df124aad57b2fbebd5e35b4b22bc2aab3f041ed6c6bff012dc43d1fd385d0363")
