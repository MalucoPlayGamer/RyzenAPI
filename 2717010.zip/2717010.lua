-- Lua provided by RyzenAPI
-- Game: KALPA: Cosmic Symphony

-- MAIN APPLICATION
addappid(2717010)
addappid(3290790)
addappid(3295260)
addappid(3600870)
addappid(3616790)
addappid(3864670)
addappid(3864680)
addappid(4050040)
addappid(4108350)
addappid(4124270)
addappid(4240410)
addappid(4290620)
addappid(4290630)
addappid(4337140)
addappid(4489600)
addappid(4580750)
addappid(4724940)
addappid(4872170)
addappid(4938050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717011,0,"df124aad57b2fbebd5e35b4b22bc2aab3f041ed6c6bff012dc43d1fd385d0363")

