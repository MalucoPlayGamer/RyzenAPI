-- Lua provided by RyzenAPI
-- Game: Zerko

-- MAIN APPLICATION
addappid(2862990)
addappid(2862991)
addappid(2862993)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862992,0,"1af2458c142e3d39120818078af08fe9ee0d94c5f7e94725b36c37b48da69e45")
