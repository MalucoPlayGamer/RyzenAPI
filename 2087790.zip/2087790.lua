-- Lua provided by RyzenAPI
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 13 - Night Warriors: Darkstalkers' Revenge - Demitri Stage (Romania)

-- MAIN APPLICATION
addappid(2087790)
-- Game: addappid(2087790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087791, 1, "4bcba6ba9adfc9b100d349b1e9543b28d268c6b41793477087f2469474ef70a5")
addappid(2087792, 1, "52c8e8e8b78aa650d94926cf95693a4246dec0209418737fb39797f1447a912b")
addappid(2087793, 1, "6c5635ceb3f7172ba5dc393229b6a838f3feb934bb10bfaf8830f25a30ce8b4a")
addappid(2087794, 1, "9f6a052d3f13375ae0f2a7df2a43e71f945d4803fd85519b6e001fbbdb891d29")
addappid(2087795, 1, "a9fa6676641db65e5965a77a4ff226c8dd9022d2b8b9a5567b5bcfc3a932b842")
addappid(2087796, 1, "c835e38cb4b045950c4881809fe2e2fea5337bd46d87af53f40916b926d9485c")
