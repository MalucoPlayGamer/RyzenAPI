-- Lua provided by RyzenAPI
-- Game: Command & Conquer Red Alert™, Counterstrike™ and The Aftermath™

-- MAIN APPLICATION
addappid(2229840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229841, 1, "26ec78cd68550fe930fb06bc779f42b58a6b52e5defa7a918f2e17aaf178f8b0")
addappid(2229842, 1, "f4839d4738635cfbdfb74408dc4360920171975654fa6976e504896aa95d5a24")
addappid(2229843, 1, "0486f7e323f2382c3e0ed96c89b343f3965bd5860133ede36dc9288ab8d130bb")
addappid(2229844, 1, "7dfd018e1fcaf58887568680a445cff76a439bfcfdbd301f8b7e1508fd94ba4a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
