-- Lua provided by RyzenAPI
-- Game: 335900

-- MAIN APPLICATION
addappid(335900)
-- Game: addappid(335900)

-- MAIN APP DEPOTS / PACKAGES
addappid(335901, 1, "b38b7e1ced2fa2bf62ad4a60eccf52b3cf82e1bcdde92c741ca393b204d63612")
