-- Lua provided by RyzenAPI
-- Game: Slappy Board

-- MAIN APPLICATION
addappid(1714910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1714911, 1, "125a4954bb095a1040b7b72c6cc81447bf40728116a5934dd020528c0e1cde3e")

