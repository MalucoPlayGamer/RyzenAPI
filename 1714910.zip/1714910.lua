-- Lua provided by RyzenAPI
-- Game: Slappy Board

-- MAIN APPLICATION
addappid(1714910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714911, 1, "125a4954bb095a1040b7b72c6cc81447bf40728116a5934dd020528c0e1cde3e")

