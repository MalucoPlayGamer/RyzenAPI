-- Lua provided by RyzenAPI
-- Game: Geneforge 2 - Infestation

-- MAIN APPLICATION
addappid(2480560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840550,0,"b58628193f1b4213fa9780f553c744d5064c69b9849c28863070b503bbf06490")

