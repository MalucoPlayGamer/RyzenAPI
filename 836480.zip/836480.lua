-- Lua provided by RyzenAPI 
-- Game: AppID 836480
addappid(836480)
addappid(836481, 1, "10322530a854cfb8ab41ef4c18e0b175d9f2cb46294c615978c44805da4b1c6e")
