-- Lua provided by RyzenAPI
-- Game: 恋爱模拟器 Love Simulation

-- MAIN APPLICATION
addappid(836480)

-- MAIN APP DEPOTS / PACKAGES
addappid(836481, 1, "10322530a854cfb8ab41ef4c18e0b175d9f2cb46294c615978c44805da4b1c6e")

