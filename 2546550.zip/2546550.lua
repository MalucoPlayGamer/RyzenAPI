-- Lua provided by RyzenAPI
-- Game: Uncharted Ocean - Adventures at the Poles

-- MAIN APPLICATION
addappid(2546550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546550,0,"f3d19965903002647a7a3bf04ba3fc1a9c8ab74bf93fdd057a554574fdb41eb0")
