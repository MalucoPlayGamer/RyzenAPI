-- Lua provided by RyzenAPI
-- Game: 2370570

-- MAIN APPLICATION
addappid(2370570)
-- Game: addappid(2370570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370571, 1, "dc5e3cf0c26fde1cad4dae1dededee6f611ccffe9d48ee5d29df447eb6b9ac60")
