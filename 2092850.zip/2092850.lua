-- Lua provided by RyzenAPI
-- Game: Krzyżacy - The Knights of the Cross

-- MAIN APPLICATION
addappid(2092850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092851, 1, "3ebf7530285db2ba77a8e47b6d69d7d345a3485d1b9f70cf2980011b43e8646e")

