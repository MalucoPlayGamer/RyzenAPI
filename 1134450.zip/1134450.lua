-- Lua provided by RyzenAPI
-- Game: AppID 1134450

-- MAIN APPLICATION
addappid(1134450)
-- Game: addappid(1134450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134451, 1, "b52e3a2489f8595d9a8def024a1309e79f52ae1f140ea649254c125c55d8216e")
