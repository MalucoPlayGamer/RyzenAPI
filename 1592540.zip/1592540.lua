-- Lua provided by RyzenAPI
-- Game: Loretta

-- MAIN APPLICATION
addappid(1592540)
-- Game: addappid(1592540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592541, 1, "47fdaa22e83a121b23d097a21cec64881e9214af133555ddd6a20f6ab63d1dd5")
addappid(2346520, 0, "79409b12f4660a84f24cd05b702f6bc78703590501c11ec0fbb7be4a2de5df2b")
