-- Lua provided by SkyAPI 
-- Game: Ratty Catty
addappid(610380)
addappid(610381, 1, "938cf4e355c15c15e3c4856671bd28b238a941292be9ff485749806fc67c7949")
