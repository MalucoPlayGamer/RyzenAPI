-- Lua provided by RyzenAPI
-- Game: Ratty Catty

-- MAIN APPLICATION
addappid(610380)
-- Game: addappid(610380)

-- MAIN APP DEPOTS / PACKAGES
addappid(610381, 1, "938cf4e355c15c15e3c4856671bd28b238a941292be9ff485749806fc67c7949")
