-- Lua provided by RyzenAPI
-- Game: addappid(1770860)

-- MAIN APPLICATION
addappid(1770860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770861, 1, "74e418e932e40ba24cdb09c446253f02217dffcf82fe16c7c59af2b2eb37fef7")
addappid(1770862, 1, "53d4d8204b4ee28e6c0bac74aae4999ebd14e987bd74281ed5a426763a85ec85")
