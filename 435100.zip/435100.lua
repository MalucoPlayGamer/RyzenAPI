-- Lua provided by RyzenAPI
-- Game: 2Dark

-- MAIN APPLICATION
addappid(435100)
addappid(579740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(435101, 1, "3f4b20b3c80b9322722f6d5edf4d8d6a871be2ced833bdcfe1c06cc486c52825")

