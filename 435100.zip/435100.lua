-- Lua provided by RyzenAPI
-- Game: 2Dark

-- MAIN APPLICATION
addappid(435100)
addappid(579740)

-- MAIN APP DEPOTS / PACKAGES
addappid(435101, 1, "3f4b20b3c80b9322722f6d5edf4d8d6a871be2ced833bdcfe1c06cc486c52825")
