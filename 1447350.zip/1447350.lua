-- Lua provided by RyzenAPI
-- Game: 1447350

-- MAIN APPLICATION
addappid(1447350)
-- Game: addappid(1447350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447351, 1, "bca84315d5dcc7dc363a34af5d3842165bb04d87d172be1a8744649f5d2b0d45")
