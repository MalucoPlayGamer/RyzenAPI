-- Lua provided by RyzenAPI
-- Game: Metro Mini Market Simulator

-- MAIN APPLICATION
addappid(3454910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454911, 1, "4d9ce08bd3fb183786a92c9b0f0038396c5af7faf88ef8277b0f55f5ec73949b")
