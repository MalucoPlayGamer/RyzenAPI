-- Lua provided by RyzenAPI 
-- Game: Power Ball 2022
addappid(2090140)
addappid(2090141, 1, "cef04f592200ed1714bcab25bdcb65746e37a14e5a0589871857f69333e0c6e9")
