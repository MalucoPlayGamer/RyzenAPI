-- Lua provided by RyzenAPI
-- Game: DC Dual Force

-- MAIN APPLICATION
addappid(2442810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442811, 1, "3003cf9de6e533e155b682146edf17dff8a4624bd637526641eb22f40fc88b7a")
