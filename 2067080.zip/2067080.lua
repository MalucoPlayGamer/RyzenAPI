-- Lua provided by RyzenAPI
-- Game: Sweet Agents - Artbook 18+

-- MAIN APPLICATION
addappid(2067080)
-- Game: addappid(2067080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067080,0,"5435851a617613224c6170470d4c483d0b5f4fe682df0b60a6b52dacc20f8c5f")
