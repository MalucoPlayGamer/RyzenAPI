-- Lua provided by RyzenAPI
-- Game: Pro Soccer Online

-- MAIN APPLICATION
addappid(1583320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1583321, 1, "a99816925abdd4d21d6792cf5c253613c895df9cedd29cb1a745e9dbb58d4ce1")

