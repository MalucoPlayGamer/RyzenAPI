-- Lua provided by RyzenAPI
-- Game: Pro Soccer Online

-- MAIN APPLICATION
addappid(1583320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583321, 1, "a99816925abdd4d21d6792cf5c253613c895df9cedd29cb1a745e9dbb58d4ce1")
