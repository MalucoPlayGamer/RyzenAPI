-- Lua provided by RyzenAPI
-- Game: addappid(2782350)

-- MAIN APPLICATION
addappid(2782350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782351, 1, "62684b063334b54beced9185e5163a3fa6748282bf0334534acdd7beaa947634")
