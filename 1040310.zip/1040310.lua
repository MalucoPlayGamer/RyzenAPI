-- Lua provided by RyzenAPI 
-- Game: I Know Everything
addappid(1040310)
addappid(1040311, 1, "e3814bfc866471f5000ced08f3e79c83789e90fa24d3f6883d5ef532a1c9ded2")
addappid(1040312, 1, "57f6005a1076af887c5f4aa84825c117912d0f472cac949e59a5736df156e299")
