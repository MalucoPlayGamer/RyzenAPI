-- Lua provided by RyzenAPI
-- Game: Game: Mistfall Hunter Playtest

-- MAIN APPLICATION
addappid(3321660)
-- Game: addappid(3321660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321661, 1, "1ce7ed40a4156b77229e823820917f43a620a90cb8e99f33bf1998fed38c9056")
