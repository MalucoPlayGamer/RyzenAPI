-- Lua provided by RyzenAPI
-- Game: Zombie Shooting Star: ARCADE

-- MAIN APPLICATION
addappid(2210710)
-- Game: addappid(2210710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210711, 1, "5619ce844e6cc21764daaf30338a91ac4151ff9335d64632f3531ece2c0b0f4c")
