-- Lua provided by RyzenAPI
-- Game: Zombie Shooting Star: ARCADE

-- MAIN APPLICATION
addappid(2210710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2210711, 1, "5619ce844e6cc21764daaf30338a91ac4151ff9335d64632f3531ece2c0b0f4c")

