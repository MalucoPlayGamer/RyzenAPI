-- Lua provided by SkyAPI 
-- Game: Zombie Shooting Star: ARCADE
addappid(2210710)
addappid(2210711, 1, "5619ce844e6cc21764daaf30338a91ac4151ff9335d64632f3531ece2c0b0f4c")
