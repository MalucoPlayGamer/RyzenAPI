-- Lua provided by RyzenAPI
-- Game: AppID 1371560

-- MAIN APPLICATION
addappid(1371560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1371561, 1, "329c8d3e90c94fd265d8be92108c5ef111ac542247190aa6b4a3b5a79586d8f6")

