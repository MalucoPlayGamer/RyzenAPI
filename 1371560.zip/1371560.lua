-- Lua provided by SkyAPI 
-- Game: AppID 1371560
addappid(1371560)
addappid(1371561, 1, "329c8d3e90c94fd265d8be92108c5ef111ac542247190aa6b4a3b5a79586d8f6")
