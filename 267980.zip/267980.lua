-- Lua provided by RyzenAPI
-- Game: Game: Hostile Waters: Antaeus Rising

-- MAIN APPLICATION
addappid(267980)
-- Game: addappid(267980)

-- MAIN APP DEPOTS / PACKAGES
addappid(267981, 1, "65c09a2905e2b7eaff0615651fdb08cf1a81c27f03dfbb6bbf934f12fad36953")
