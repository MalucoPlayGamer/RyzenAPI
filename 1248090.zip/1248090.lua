-- Lua provided by RyzenAPI
-- Game: addappid(1248090)

-- MAIN APPLICATION
addappid(1248090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248091, 1, "665e6cc98c75138d62a960607eed146abfa17f3177bc17d32d06200ab4690f40")
