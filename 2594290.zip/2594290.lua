-- Lua provided by RyzenAPI
-- Game: Game: Warlords Battle Simulator

-- MAIN APPLICATION
addappid(2594290)
-- Game: addappid(2594290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594291, 1, "a254e17a8178a092635dc5a4eec79c2107f1dfa12dcaed479f8b36a075c11d4d")
