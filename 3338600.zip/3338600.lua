-- Lua provided by RyzenAPI
-- Game: The Last Experiment: A Memetric Story

-- MAIN APPLICATION
addappid(3338600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3338601, 1, "6e6d485b13a5a14f93d95056614e2bf52ac307a83e25488cafc5b56ea400eecd")

