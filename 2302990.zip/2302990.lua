-- Lua provided by RyzenAPI
-- Game: Vacuum Warrior - Idle Game

-- MAIN APPLICATION
addappid(2302990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302991, 1, "b23764f5d47738744da564d2fb23c582d0eba60758f2848af4b0573d6462508b")
