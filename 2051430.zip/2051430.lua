-- Lua provided by RyzenAPI
-- Game: Game: Deadlink Demo

-- MAIN APPLICATION
addappid(2051430)
-- Game: addappid(2051430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051431, 1, "0cd952ff75b4b40f9d60506e06a14c686aebd9c115b3167a7cc7da8de6547f40")
