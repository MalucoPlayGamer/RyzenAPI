-- Lua provided by SkyAPI 
-- Game: Nympho Monster Domination
addappid(1186600)
addappid(1186601, 1, "950a898ec186484ca94b06d62f921424862f5c3e0133bbef682567ff91c74d23")
