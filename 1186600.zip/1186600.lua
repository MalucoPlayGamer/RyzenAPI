-- Lua provided by RyzenAPI
-- Game: Game: Nympho Monster Domination

-- MAIN APPLICATION
addappid(1186600)
-- Game: addappid(1186600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186601, 1, "950a898ec186484ca94b06d62f921424862f5c3e0133bbef682567ff91c74d23")
