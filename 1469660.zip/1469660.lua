-- Lua provided by RyzenAPI
-- Game: AppID 1469660

-- MAIN APPLICATION
addappid(1469660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1469661, 1, "b45484ff5ec6aeb65965602fae7cf6eee9643dd8cb6a5a0ce7b1aa7691c077f4")

