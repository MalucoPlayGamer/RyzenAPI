-- Lua provided by RyzenAPI
-- Game: Game: AppID 1469660

-- MAIN APPLICATION
addappid(1469660)
-- Game: addappid(1469660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469661, 1, "b45484ff5ec6aeb65965602fae7cf6eee9643dd8cb6a5a0ce7b1aa7691c077f4")
