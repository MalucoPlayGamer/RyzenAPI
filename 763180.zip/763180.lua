-- Lua provided by RyzenAPI
-- Game: 763180

-- MAIN APPLICATION
addappid(763180)
-- Game: addappid(763180)

-- MAIN APP DEPOTS / PACKAGES
addappid(763181, 1, "b2d433fe48104010021c86d9698aa4c069827de439f9f581edffe1f511076a4f")
