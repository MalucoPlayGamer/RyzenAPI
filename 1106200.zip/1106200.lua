-- Lua provided by RyzenAPI
-- Game: 1106200

-- MAIN APPLICATION
addappid(1106200)
-- Game: addappid(1106200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106201, 1, "d7232ba830d00f8ca263c327f6a449ec489a8e8450c349091a4f5b8b0371c1fd")
