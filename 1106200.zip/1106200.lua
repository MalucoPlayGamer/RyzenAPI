-- Lua provided by SkyAPI 
-- Game: Overseas
addappid(1106200)
addappid(1106201, 1, "d7232ba830d00f8ca263c327f6a449ec489a8e8450c349091a4f5b8b0371c1fd")
