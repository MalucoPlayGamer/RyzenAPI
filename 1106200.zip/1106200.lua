-- Lua provided by RyzenAPI
-- Game: Overseas

-- MAIN APPLICATION
addappid(1106200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1106201, 1, "d7232ba830d00f8ca263c327f6a449ec489a8e8450c349091a4f5b8b0371c1fd")

