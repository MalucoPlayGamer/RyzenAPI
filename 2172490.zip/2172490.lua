-- Lua provided by RyzenAPI 
-- Game: Detective Ridelle
addappid(2172490)
addappid(2172491, 1, "8277d18886acfd60b9c363061c34a46c7fda2e70ec5857db832c25c64c55bf79")
