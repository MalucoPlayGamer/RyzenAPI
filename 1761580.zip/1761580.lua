-- Lua provided by RyzenAPI 
-- Game: AppID 1761580
addappid(1761580)
addappid(1761581, 1, "e3ea75ced4451751eaebd4d20a9de190b44fc5986de79268862e1a6e9aff8487")
addappid(1761589, 1, "78ab9d1f159acbcaa0d619922d038250cd31d51fc42e0f0b49d6736cc8f8b6b4")
