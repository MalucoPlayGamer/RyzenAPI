-- Lua provided by RyzenAPI
-- Game: Mossy Pixels

-- MAIN APPLICATION
addappid(2618370)
addappid(2696990)
-- Game: addappid(2618370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618371, 1, "d405d467a16cec1fdeffb7db832b82e75d2540d4a25b369f47d26dc89cb5b9bf")
