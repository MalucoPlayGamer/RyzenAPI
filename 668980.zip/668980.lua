-- Lua provided by RyzenAPI
-- Game: 668980

-- MAIN APPLICATION
addappid(668980)
-- Game: addappid(668980)

-- MAIN APP DEPOTS / PACKAGES
addappid(668981, 1, "c91553daee0ae847d7822b89908ecf6f2485d79ffbd5ac8672da1ac074753ca1")
addappid(668982, 1, "53d9e3a3ec708436d0fcb17f2b70a2a3d9904ec7cc3e1901dcd2f5f077242de1")
