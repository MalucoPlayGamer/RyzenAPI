-- Lua provided by RyzenAPI
-- Game: Forsaken Remastered

-- MAIN APPLICATION
addappid(668980)

-- MAIN APP DEPOTS / PACKAGES
addappid(668981, 1, "c91553daee0ae847d7822b89908ecf6f2485d79ffbd5ac8672da1ac074753ca1")
addappid(668982, 1, "53d9e3a3ec708436d0fcb17f2b70a2a3d9904ec7cc3e1901dcd2f5f077242de1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
