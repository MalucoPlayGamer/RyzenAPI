-- Lua provided by RyzenAPI
-- Game: Restore Your Island

-- MAIN APPLICATION
addappid(2698420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698421,0,"508e88ce1a7d990f47ad0938e40db7036544f06a8fd753c1561e553edf0c6714")

