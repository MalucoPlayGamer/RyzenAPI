-- Lua provided by RyzenAPI
-- Game: AppID 251040

-- MAIN APPLICATION
addappid(251040)

-- MAIN APP DEPOTS / PACKAGES
addappid(251041, 1, "9cd2db859cb875aa6f6b15e6f87a82484ac03e7b9411bc61648dc3cf4e84881c")
