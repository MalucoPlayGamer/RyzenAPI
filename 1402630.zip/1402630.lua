-- Lua provided by RyzenAPI
-- Game: Game: Freedom Fighters Soundtrack

-- MAIN APPLICATION
addappid(1402630)
-- Game: addappid(1402630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402631, 1, "c7119d7058f71d5e3a919b0199fe901b8eb56b31e9b87ce4b17bde54147d01c8")
addappid(1402632, 1, "ec9d1761c86b61a029bd79c86b7cae16a4a59a888881497a3309f94c763c1f15")
