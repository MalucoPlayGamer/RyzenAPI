-- Lua provided by RyzenAPI 
-- Game: AppID 435250
addappid(435250)
addappid(435251, 1, "1b6dc126ca6a91a415da3545320dcf009993e83fd0aef6ef046bc2a53266dbfe")
