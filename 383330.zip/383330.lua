-- Lua provided by RyzenAPI
-- Game: 383330

-- MAIN APPLICATION
addappid(383330)
-- Game: addappid(383330)

-- MAIN APP DEPOTS / PACKAGES
addappid(383331, 1, "9e6e308ecf64e0cf64f8e908017019ca44ece07c712fbc4f0dedb5eb77848e39")
