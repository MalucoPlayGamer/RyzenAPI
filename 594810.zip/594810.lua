-- Lua provided by RyzenAPI
-- Game: addappid(594810)

-- MAIN APPLICATION
addappid(594810)

-- MAIN APP DEPOTS / PACKAGES
addappid(594811, 1, "8f855db0f5cf3b8564059b7cad55e83d8dbd05c0e400a6d4fa2ade7a3f9525e1")
addappid(594812, 1, "cbca1ad36540eec731299e78c5c2694f941a3a232bb3bf5da8690f2250ba5b31")
addappid(594813, 1, "40bb154dd8481d2f220f40dbd8d119bf054613193d3a5a02c308b1a301367ab8")
