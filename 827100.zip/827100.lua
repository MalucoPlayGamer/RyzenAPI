-- Lua provided by RyzenAPI
-- Game: AppID 827100

-- MAIN APPLICATION
addappid(827100)
-- Game: addappid(827100)

-- MAIN APP DEPOTS / PACKAGES
addappid(827101, 1, "713e800e58ca5052db4fc2754781d2b46d8c228dc94cbe3d760c256404feb76c")
