-- Lua provided by RyzenAPI
-- Game: 448710

-- MAIN APPLICATION
addappid(448710)
-- Game: addappid(448710)

-- MAIN APP DEPOTS / PACKAGES
addappid(448711, 1, "f429010276d32cb4524bd7a171c7205c074b00c817192e23fcd7f18a61fa9688")
