-- Lua provided by RyzenAPI
-- Game: Nine Heavens

-- MAIN APPLICATION
addappid(3252190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3252191, 1, "a07131d960f75800930bb903ec36c5175bfacc459a75d26026fd6543df72984d")
