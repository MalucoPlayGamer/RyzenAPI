-- Lua provided by RyzenAPI
-- Game: Game: Lup

-- MAIN APPLICATION
addappid(412600)
-- Game: addappid(412600)

-- MAIN APP DEPOTS / PACKAGES
addappid(412601, 1, "858521850f2d033495760124118b15d04a65dece23e812b000b75a53656020a5")
