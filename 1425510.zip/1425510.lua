-- Lua provided by RyzenAPI
-- Game: Clown In a House

-- MAIN APPLICATION
addappid(1425510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425511,0,"343aae73a465019bf651b8ec860abd55a1df6f1ec62c83252504ae93fb7881a9")

