-- Lua provided by RyzenAPI
-- Game: AppID 728540

-- MAIN APPLICATION
addappid(728540)
addappid(728550)
addappid(897060)
addappid(897061)
addappid(897062)
addappid(897063)
addappid(897064)
addappid(897065)
addappid(897066)
addappid(897067)
addappid(897068)
addappid(897069)
addappid(897070)
addappid(897071)
addappid(897072)
addappid(897073)
addappid(897074)
addappid(897075)
addappid(897090)
addappid(899060)
addappid(899061)
addappid(899920)
addappid(983770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(728541, 1, "e4a41d4d57557375369bfdac7855e67e509f711267bd9a21ffb5eedf45ab3c25")

