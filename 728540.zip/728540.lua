-- Lua provided by RyzenAPI
-- Game: 728540

-- MAIN APPLICATION
addappid(728540)
-- Game: addappid(728540)

-- MAIN APP DEPOTS / PACKAGES
addappid(728541, 1, "e4a41d4d57557375369bfdac7855e67e509f711267bd9a21ffb5eedf45ab3c25")
