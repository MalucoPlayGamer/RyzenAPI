-- Lua provided by RyzenAPI
-- Game: 2446270

-- MAIN APPLICATION
addappid(2446270)
addappid(2622680)
-- Game: addappid(2446270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446271, 1, "1ec7158f1c1dcb6bfba78443cd698604092d2313993f6b964bb33b5470ac7a8c")
