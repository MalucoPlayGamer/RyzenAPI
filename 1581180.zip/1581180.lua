-- Lua provided by RyzenAPI
-- Game: addappid(1581180)

-- MAIN APPLICATION
addappid(1581180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581181, 1, "7bc92ac93915348bf937d5c68cb8fcc15c3f8d351337401c1724e6e6ccc296d3")
