-- Lua provided by RyzenAPI
-- Game: addappid(1759920)

-- MAIN APPLICATION
addappid(1759920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759921, 1, "6d7160825c36bdfa1fef9d6cc697d60edeba9a0afa3dad868b589a2308cecf66")
