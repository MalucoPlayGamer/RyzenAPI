-- Lua provided by RyzenAPI
-- Game: Goblin Harvest - The Mighty Quest

-- MAIN APPLICATION
addappid(604060)
-- Game: addappid(604060)

-- MAIN APP DEPOTS / PACKAGES
addappid(604061, 1, "7398635c50ea8b5c37c5a09297336941a9a32ef1eba40f4b4113339f7033d24a")
