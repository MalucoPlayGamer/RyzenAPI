-- Lua provided by RyzenAPI
-- Game: Goblin Harvest - The Mighty Quest

-- MAIN APPLICATION
addappid(604060)

-- MAIN APP DEPOTS / PACKAGES
addappid(604061, 1, "7398635c50ea8b5c37c5a09297336941a9a32ef1eba40f4b4113339f7033d24a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
