-- Lua provided by RyzenAPI
-- Game: Last Dream Fishing Arcade

-- MAIN APPLICATION
addappid(2334080)
-- Game: addappid(2334080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334081, 1, "45745ebb337d3e1a9fd9494077d3488fb1baf5dba381e064be9cc8e167f7036d")
