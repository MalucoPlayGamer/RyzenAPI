-- Lua provided by RyzenAPI
-- Game: 3171730

-- MAIN APPLICATION
addappid(3171730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171730,0,"3c98c5ab6e2eca56fe71caadb97beb08ba2b315ee392bb7a973de1071ec54c7c")
