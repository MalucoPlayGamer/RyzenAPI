-- Lua provided by RyzenAPI
-- Game: DEPO : Death Epileptic Pixel Origins

-- MAIN APPLICATION
addappid(1091320)
addappid(2925350)
addappid(2925360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091320,0,"c375963fd1758011f7efc34b19449ab3a74af5e8ff3a8aeee74719025ca639c9")
addappid(1091322,0,"c5b879b4c34d834b932c8c84678e867f7b25ab397a96e0df557c733f5a7fcdd9")
addappid(1091323,0,"2b98f9ff1aadef55e48c6792fa47c2c54fed0e12fd18796ecfbb795a9c5d092a")
addappid(1091324,0,"97374440bfe3128e405de3adf39612caeb55c71a147826993f938a6b85ff6cfb")

