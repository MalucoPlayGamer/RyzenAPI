-- Lua provided by RyzenAPI
-- Game: Isolania

-- MAIN APPLICATION
addappid(1997920)
-- Game: addappid(1997920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997921, 1, "8a428b6c9ed184f324247070a77bea180007bf7002b58d0812a6e1df396d9879")
