-- Lua provided by RyzenAPI
-- Game: The Dreamland：Free

-- MAIN APPLICATION
addappid(2259270)
-- Game: addappid(2259270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259271, 1, "5dcc2d319659483184adfafa2581fe90997aff9a19aef3d0297c33d8e1c76037")
