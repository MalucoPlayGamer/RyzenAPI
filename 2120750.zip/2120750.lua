-- Lua provided by SkyAPI 
-- Game: The First Step
addappid(2120750)
addappid(2120751, 1, "649370a0a06cc874412e53e5d5bef528c79216e024c0b3d3e88203246a197c3c")
