-- Lua provided by RyzenAPI
-- Game: Game: Through the Mirror

-- MAIN APPLICATION
addappid(548720)
-- Game: addappid(548720)

-- MAIN APP DEPOTS / PACKAGES
addappid(548721, 1, "a72d5d11e0f01d2aa859a6fb7dea8fd221b8fa5e0d0ccb7a83c42882cef589ed")
