-- Lua provided by RyzenAPI
-- Game: AppID 1930430

-- MAIN APPLICATION
addappid(1930430)
-- Game: addappid(1930430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930431, 1, "a9759055a556d26de2c28c7f151b805c54ee5c9c2dbd7b9ff275cc703a85f2e7")
