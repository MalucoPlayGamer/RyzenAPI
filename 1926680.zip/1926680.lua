-- Lua provided by RyzenAPI
-- Game: FUCK PUTIN

-- MAIN APPLICATION
addappid(1926680)
-- Game: addappid(1926680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926681, 1, "9f4597faa8d99cf44dcb8ddb823b07fa84c7d973aac8e5b6f4ab675bb727ee16")
addappid(1926682, 1, "3c50d5c9daf24995a26213468b37cfb6ee78e3a400bc84327b2a0dc57ee0e787")
