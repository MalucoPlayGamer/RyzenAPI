-- Lua provided by RyzenAPI
-- Game: FUCK PUTIN

-- MAIN APPLICATION
addappid(1926680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926681, 1, "9f4597faa8d99cf44dcb8ddb823b07fa84c7d973aac8e5b6f4ab675bb727ee16")
addappid(1926682, 1, "3c50d5c9daf24995a26213468b37cfb6ee78e3a400bc84327b2a0dc57ee0e787")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
