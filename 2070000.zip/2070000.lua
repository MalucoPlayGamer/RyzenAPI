-- Lua provided by SkyAPI 
-- Game: Heavy Burden
addappid(2070000)
addappid(2070001, 1, "a7871e69ef6390e0f8e06620e9a510b0f37e1593d1c5f29969fb90f37a79b75a")
