-- Lua provided by RyzenAPI
-- Game: 2070000

-- MAIN APPLICATION
addappid(2070000)
-- Game: addappid(2070000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070001, 1, "a7871e69ef6390e0f8e06620e9a510b0f37e1593d1c5f29969fb90f37a79b75a")
