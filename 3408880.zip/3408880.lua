-- Lua provided by RyzenAPI
-- Game: Game: Call from the darkness Demo

-- MAIN APPLICATION
addappid(3408880)
-- Game: addappid(3408880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408881, 1, "fe6a3f21538ba5fccb13b5c42be59bcb837ae4d8ea537dc5829a3e18d2fe26fb")
