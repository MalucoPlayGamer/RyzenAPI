-- Lua provided by RyzenAPI
-- Game: Debug Girl

-- MAIN APPLICATION
addappid(2572670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572671, 1, "147cefc9d2ad99226ae822c3affa1576bb9c4fbc0ec1e8953ac076c10f807a56")
