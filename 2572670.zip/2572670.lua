-- Lua provided by SkyAPI 
-- Game: Debug Girl
addappid(2572670)
addappid(2572671, 1, "147cefc9d2ad99226ae822c3affa1576bb9c4fbc0ec1e8953ac076c10f807a56")
