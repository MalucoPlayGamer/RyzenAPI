-- Lua provided by RyzenAPI
-- Game: Football Manager 2017 Resource Archiver

-- MAIN APPLICATION
addappid(482870)

-- MAIN APP DEPOTS / PACKAGES
addappid(482871, 1, "0ea8d2642c7767bd78b258e7e06f39fc7516fa471b02b03c6826804d15dd7fcb")
addappid(482872, 1, "25a3ce4ac448640dfae2d47ea9343ecba3dd3db1db3d8c69bf779a52dbcce2a9")
addappid(482873, 1, "bf1bc9c083beb2cb98045244532d9db0c3c70332f76b414dd94e7f3ffaa0469a")
addappid(482874, 1, "a338f7b5e0e8634fca8bf0eba9d4a099b43e9aed2376b26af52dd8630e282a3e")

