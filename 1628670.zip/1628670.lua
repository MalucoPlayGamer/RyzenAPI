-- Lua provided by RyzenAPI
-- Game: Game: Move the Window

-- MAIN APPLICATION
addappid(1628670)
-- Game: addappid(1628670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628671, 1, "ac53b5c509206db238e09a4fd1da7bb778a5b98f79b68fe810b7b926fd6ddc28")
