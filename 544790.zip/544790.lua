-- Lua provided by RyzenAPI
-- Game: addappid(544790)

-- MAIN APPLICATION
addappid(544790)

-- MAIN APP DEPOTS / PACKAGES
addappid(544797,0,"841396d7072d023dfe01a1efb6fffc179f7a27ce63c0686e27dec1b63997af94")
