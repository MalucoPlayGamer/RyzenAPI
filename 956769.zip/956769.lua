-- Lua provided by RyzenAPI
-- Game: Daqiao - Officer Ticket / 大喬使用券

-- MAIN APPLICATION
addappid(956769)
-- Game: addappid(956769)

-- MAIN APP DEPOTS / PACKAGES
addappid(956769,0,"c8509e10f1301f53c33a3dce54c673c9ce92dcfcc730b162a479342aa21fa3ce")
