-- Lua provided by RyzenAPI
-- Game: Satellite Command

-- MAIN APPLICATION
addappid(514670)

-- MAIN APP DEPOTS / PACKAGES
addappid(514671,0,"20d7681b3752495367cf81e6adbebc663c8a39a464608874752e99d19dd867b1")

