-- Lua provided by RyzenAPI
-- Game: Satellite Command

-- MAIN APPLICATION
addappid(514670)

-- MAIN APP DEPOTS / PACKAGES
addappid(514671,0,"20d7681b3752495367cf81e6adbebc663c8a39a464608874752e99d19dd867b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
