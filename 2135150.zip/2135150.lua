-- Lua provided by RyzenAPI
-- Game: addappid(2135150)

-- MAIN APPLICATION
addappid(2135150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135153,0,"b800fa7ccfbea4d3c24ba4e8d50bdab1b39bf15b492ac44ad91b5af2af02cc14")
