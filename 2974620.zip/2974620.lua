-- Lua provided by RyzenAPI
-- Game: SignaNota

-- MAIN APPLICATION
addappid(2974620)
-- Game: addappid(2974620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2974621, 1, "00acdd9b8b0cb832fbd7bbbeac1a93416b2a633a79e90c8f8a22d026a0ee07ae")
