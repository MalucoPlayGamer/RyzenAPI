-- Lua provided by RyzenAPI
-- Game: addappid(3387230)

-- MAIN APPLICATION
addappid(3387230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387231, 1, "f5ce838deb061eda3627d796f26c5ed03e7a8dca0b821865eb51006c55e29321")
