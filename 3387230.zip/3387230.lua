-- Lua provided by RyzenAPI
-- Game: MyPawnShop

-- MAIN APPLICATION
addappid(3387230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387231, 1, "f5ce838deb061eda3627d796f26c5ed03e7a8dca0b821865eb51006c55e29321")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
