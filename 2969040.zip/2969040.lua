-- Lua provided by RyzenAPI
-- Game: Roulette Simulator 2025

-- MAIN APPLICATION
addappid(2969040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969041, 1, "7501909d69280100ad77d6da5c054faf5eff823bf3d020be9c77136e3ed43c57")
