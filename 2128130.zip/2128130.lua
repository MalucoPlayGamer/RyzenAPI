-- Lua provided by RyzenAPI
-- Game: The Legend of Gandar II

-- MAIN APPLICATION
addappid(2128130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128131, 1, "6dcf85128b11b81593318e45f301901780fc91a6bec411999cf665c6d3ab5d78")
