-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Zhou Yu "Additional Hypothetical Scenarios Set" / 周瑜「追加ＩＦシナリオセット」

-- MAIN APPLICATION
addappid(978865)

-- MAIN APP DEPOTS / PACKAGES
addappid(978865,0,"9bcecd8f1b1d064e59fd918451aa1710bb5fa14b9ead813cd3f4fb5b234e48a3")
