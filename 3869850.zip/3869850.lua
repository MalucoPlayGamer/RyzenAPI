-- Lua provided by RyzenAPI
-- Game: Welcome to the Game III

-- MAIN APPLICATION
addappid(3869850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3869851,0,"6a3013f6cdd84051c584e737937cec085fa9ab43214b03b82b553de28c9b24b4")
addappid(4941970,0,"a44e6e7025c3873f7405ab5d0c9878adc1cf32f3b559d84f2867d55198ee4661")
addappid(4942030,0,"3c878b07316585fe2d9d4d4f8f2772ea459ca1755b50c20956868620687d3fcf")
addappid(4942050,0,"e145c9a6688d802d4d8670a740d130821881ada9bcf216cb9472e828a67004b3")
addappid(4942060,0,"2e46dd38af9adeb0b6ecff02645404c10489a92ba4d4713e5d9da14b4c038211")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4942040)
