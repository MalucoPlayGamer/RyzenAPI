-- Lua provided by RyzenAPI
-- Game: Kitsune Kitchen

-- MAIN APPLICATION
addappid(862920)

-- MAIN APP DEPOTS / PACKAGES
addappid(862921, 1, "65103f6456b218ef11b87995e012d65fc81581fab7c492aa17b245c102f67c28")
addappid(869860, 0, "afe9a55742321626d46defcfe8a02d6a179e464eefd727f3218a0ba6ad816053")

