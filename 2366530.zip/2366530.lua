-- Lua provided by SkyAPI 
-- Game: Flashpoint Campaigns: Southern Storm
addappid(2366530)
addappid(2366531, 1, "ff0d731bb2c9de1bd151184f781cf402d07471e5c462bc7d4254ead5f640fd02")
addappid(2366532, 1, "50978092fa93dfd20ebd219392dc6f9e437eb8dc9070d4f1e42a5c4cd2f843b3")
