-- Lua provided by RyzenAPI
-- Game: addappid(989450)

-- MAIN APPLICATION
addappid(989450)

-- MAIN APP DEPOTS / PACKAGES
addappid(989451, 1, "05d48ee7483c5056e2a7545096ad1bf18d3a1cb5aa000c3d7c294107c0954669")
