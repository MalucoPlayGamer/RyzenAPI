-- Lua provided by RyzenAPI
-- Game: Tales Beyond The Tomb - Route 86

-- MAIN APPLICATION
addappid(3860920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3860921, 1, "831c12a8afb073a4b11d5fe223b0780e90589cb045dcf38c363b494e7eadf604")
