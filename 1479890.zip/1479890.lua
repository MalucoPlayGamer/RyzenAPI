-- Lua provided by RyzenAPI
-- Game: Inua - A Story in Ice and Time

-- MAIN APPLICATION
addappid(1479890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479891, 1, "4b49de1e5349c9123f6c66bbd60cc380a2791152ab83c07cd78d6350308e7e0f")
addappid(1479892, 1, "eff6031dd1d8ec53e7a24f11694803fa6ca54f6230aac6fda644c5e9263e3d88")

