-- Lua provided by RyzenAPI
-- Game: 1710830

-- MAIN APPLICATION
addappid(1710830)
-- Game: addappid(1710830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710831, 1, "82cf667ce95f2d7ea24f58bb3ce9dede7aa69847ce30949b14788b744b493e67")
