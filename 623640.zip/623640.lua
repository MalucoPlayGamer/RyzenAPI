-- Lua provided by RyzenAPI
-- Game: Game: Mulaka

-- MAIN APPLICATION
addappid(623640)
-- Game: addappid(623640)

-- MAIN APP DEPOTS / PACKAGES
addappid(623641, 1, "487c64818dbefd3704352f5f9a04ceab4d1191b0dda55af711687f4930bf2131")
addappid(623642, 1, "22c3661048cca8a6b700a512761f781c421005dea07e6a3c5ce237311ae8356f")
addappid(623644, 1, "38afd8257f47679fa2b35f4ee23ef295de751e7628e6800fcf13a765b80e52b2")
