-- Lua provided by RyzenAPI
-- Game: HelloWorld:ESCAPE

-- MAIN APPLICATION
addappid(1833850)
-- Game: addappid(1833850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833851, 1, "cef85dbe0d1b2b3dac77daa19bb87bcb9e05f8edc7d510ae84ee9fb0216b1e3d")
