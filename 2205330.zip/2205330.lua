-- Lua provided by RyzenAPI
-- Game: Scourge Of War - Remastered

-- MAIN APPLICATION
addappid(2205330)
-- Game: addappid(2205330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205332,0,"53b677bd1c09ce8b076074bd7cb31e530faf10940692714aa754df801443ca69")
