-- Lua provided by RyzenAPI
-- Game: Scourge Of War - Remastered

-- MAIN APPLICATION
addappid(2205330)
addappid(3136610)
addappid(3136660)
addappid(3136670)
addappid(3136680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2205332,0,"53b677bd1c09ce8b076074bd7cb31e530faf10940692714aa754df801443ca69")

