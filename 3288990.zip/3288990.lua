-- Lua provided by RyzenAPI
-- Game: Grove Fisher

-- MAIN APPLICATION
addappid(3288990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288991, 1, "4fc4639c695a0585ea902ffce2bc05a20fcb6cca4080aabcb0aa80b6f9f9c05c")
