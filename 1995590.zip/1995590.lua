-- Lua provided by RyzenAPI
-- Game: 1995590

-- MAIN APPLICATION
addappid(1995590)
-- Game: addappid(1995590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995591, 1, "472b3dfa196961304a3821d7c81836c5f93e610efe83afde540005be5c0135ba")
