-- Lua provided by RyzenAPI 
-- Game: AppID 1995590
addappid(1995590)
addappid(1995591, 1, "472b3dfa196961304a3821d7c81836c5f93e610efe83afde540005be5c0135ba")
