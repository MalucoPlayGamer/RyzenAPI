-- Lua provided by RyzenAPI
-- Game: Undisputed

-- MAIN APPLICATION
addappid(1451190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451191, 1, "543e5be37b6ba13500441680b3434302f89112d8f1fae261eec6e6cb245ffd22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2900100)
addappid(2946350)
addappid(3102510)
addappid(3525000)
addappid(3740110)
addappid(3870270)
addappid(4030960)
addappid(4031830)
