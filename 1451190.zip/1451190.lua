-- Lua provided by RyzenAPI 
-- Game: Undisputed
addappid(1451190)
addappid(1451191, 1, "543e5be37b6ba13500441680b3434302f89112d8f1fae261eec6e6cb245ffd22")
