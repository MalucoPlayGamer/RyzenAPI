-- Lua provided by RyzenAPI
-- Game: Game: Undisputed

-- MAIN APPLICATION
addappid(1451190)
-- Game: addappid(1451190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451191, 1, "543e5be37b6ba13500441680b3434302f89112d8f1fae261eec6e6cb245ffd22")
