-- Lua provided by RyzenAPI
-- Game: Game: Tactical Assault VR

-- MAIN APPLICATION
addappid(2314160)
-- Game: addappid(2314160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314161, 1, "5be7927a7b9161b7c4faa65d50810e4337a6ec964921f4cc0d37d8003e72bed0")
