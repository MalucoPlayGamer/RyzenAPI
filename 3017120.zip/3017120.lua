-- Lua provided by RyzenAPI
-- Game: Game: Egg Surprise

-- MAIN APPLICATION
addappid(3017120)
-- Game: addappid(3017120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017121, 1, "8c1ef147ed15da7fddee19f45cbe1e2ef42ae7017d7a2ef411094e0d92402707")
addappid(3017122, 1, "22b67b84728823485efddbec0ef9a03d207f70bd70fe55b375cc9c9a71b042f7")
