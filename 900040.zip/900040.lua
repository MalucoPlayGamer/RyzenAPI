-- Lua provided by RyzenAPI
-- Game: ELEX II

-- MAIN APPLICATION
addappid(900040)

-- MAIN APP DEPOTS / PACKAGES
addappid(900041, 1, "2897ed41e50c086df41db434bab08b6d548129f2d73ab571fdeff2fd23d1ace7")
addappid(900042, 1, "fde4e9f160f99f36c10fe3109af629a29a14215cba4cd72ea300049c4e412e8e")
addappid(900043, 1, "631e6e3e06544ea63b1f494f9bc23e21218866d2ec7e0ac06234e438a9af005e")
addappid(900044, 1, "6ed2d57093821be503b35d56b411e54cb076ad3848ac0f7feab60f862002d980")
addappid(900045, 1, "577e32e1b6fbab249971eb1a29a5a9d4f499cec8ac26d458b6508eda3f24016a")
addappid(900046, 1, "d99c8c9fd24babe49b133f5f261db4d1fa5ba5d25335674b3bac23916160964b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
