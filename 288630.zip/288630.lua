-- Lua provided by RyzenAPI
-- Game: Sharpe Investigations: Death on the Seine

-- MAIN APPLICATION
addappid(288630)

-- MAIN APP DEPOTS / PACKAGES
addappid(288631, 1, "8e59bae813e08d9659c121d0ebeb1f42de09c4bd48cc893e7deea6b23ce4e403")
addappid(288632, 1, "018c0aead090a024fca60e7d51cc65d2d480d5819de974916edc79b12ca91c2d")
addappid(288633, 1, "b4cb9ed4801d84657117d4a7c022758ace1a0f505d2a4f11307b42361c868df8")
addappid(288634, 1, "8372ab77c505279190c773d269a703bd564c9f04d97cab365ccbd008815c15b9")
addappid(288635, 1, "22d1b55bc4534661fadab1a621a6dcd07a47abbadbafb961961e4bd9cefa7788")
addappid(288636, 1, "9cd7d44e44ed794d4b70a06d0264a94a5dfbf5b8ef3554eb38c956615234642a")
addappid(288637, 1, "0504899bd3c6cfe3ada3b5a5c2107e7f07c5aedaf92df5b29acc12ac5b5aa66f")
addappid(288638, 1, "5d9642372f1bb7eb0fd488efef3e0a82485773fac933050c98775f04ad25cded")

