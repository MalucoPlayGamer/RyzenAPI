-- Lua provided by RyzenAPI
-- Game: Flintlock: The Siege of Dawn – Demo

-- MAIN APPLICATION
addappid(2934040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934041, 1, "4fad7793072118d62464f8a858fac19f04981a78a4b2f1a182ec5ea22cf49ce8")

