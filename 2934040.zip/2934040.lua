-- Lua provided by SkyAPI 
-- Game: AppID 2934040
addappid(2934040)
addappid(2934041, 1, "4fad7793072118d62464f8a858fac19f04981a78a4b2f1a182ec5ea22cf49ce8")
