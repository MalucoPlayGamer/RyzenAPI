-- Lua provided by RyzenAPI
-- Game: addappid(1979150)

-- MAIN APPLICATION
addappid(1979150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979151, 1, "80336b09d61a075598f1b17ec83b36ff19150d308a6e29e079decbcc60e0721b")
