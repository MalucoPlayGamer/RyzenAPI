-- Lua provided by RyzenAPI
-- Game: Moolii's Dreamland

-- MAIN APPLICATION
addappid(1280380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280381, 1, "9b8614e5e8aa2605ab5d521cea32d50b0c46aa7f2852e52b48d1af931c2cf8af")

