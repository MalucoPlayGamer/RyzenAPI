-- Lua provided by RyzenAPI
-- Game: 2310820

-- MAIN APPLICATION
addappid(2310820)
-- Game: addappid(2310820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310821, 1, "86e37738c60d4d15cceadbc7d03626b8cc149e8eaafcffb2b101cdc044952784")
