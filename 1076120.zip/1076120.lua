-- Lua provided by RyzenAPI
-- Game: addappid(1076120)

-- MAIN APPLICATION
addappid(1076120)
addappid(1076121)
addappid(1076123)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076122,0,"3f101ba9184f6e3c36baf292ae032360a3757f6c215570ab82853cf16398b8c3")
