-- Lua provided by RyzenAPI
-- Game: Project Third Eye

-- MAIN APPLICATION
addappid(2425290)
-- Game: addappid(2425290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425291, 1, "0138197066b87287bcfca71065ecdda6e7e6b7363ce918f5aded6560edae37ba")
