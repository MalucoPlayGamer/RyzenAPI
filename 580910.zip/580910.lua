-- Lua provided by RyzenAPI
-- Game: idleBeer

-- MAIN APPLICATION
addappid(580910)

-- MAIN APP DEPOTS / PACKAGES
addappid(580911, 1, "f0614c717985d47e84f6fa455d8f2b49039125c54cadee6d90e3cf07eb8b921f")
