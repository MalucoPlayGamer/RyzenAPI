-- Lua provided by RyzenAPI
-- Game: It Moves

-- MAIN APPLICATION
addappid(1028930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(1028931, 1, "a065abc64f9398af187eab0939c4cb116e6d9f0b5da9d3fc6fcaf2999a3c9186")

