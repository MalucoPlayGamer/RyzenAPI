-- Lua provided by RyzenAPI
-- Game: My Ex-Future Family Season 2

-- MAIN APPLICATION
addappid(2692280)
addappid(3697760)
addappid(3698020)
addappid(3698030)
addappid(3698040)
addappid(4007620)
addappid(4027770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2692281, 1, "69e14e7a62c75d4b177707c06dfa45c7c1cfc3012e2dffc2a77fea3b4202c6fc")

