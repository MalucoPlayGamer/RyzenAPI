-- Lua provided by RyzenAPI
-- Game: My Ex-Future Family Season 2

-- MAIN APPLICATION
addappid(2692280)
-- Game: addappid(2692280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692281, 1, "69e14e7a62c75d4b177707c06dfa45c7c1cfc3012e2dffc2a77fea3b4202c6fc")
