-- Lua provided by RyzenAPI
-- Game: Time Chess Demo

-- MAIN APPLICATION
addappid(3196000)
-- Game: addappid(3196000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196001, 1, "69259ffbc7ced005297757ab577da8136e2d07b600fd06f5a9624fe0405f4ff8")
