-- Lua provided by RyzenAPI
-- Game: Wizard time!

-- MAIN APPLICATION
addappid(1821950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821951, 1, "7894744195015a734f18b3caf2864ecdd670e1d2b7a50ac14623f61612e337ab")
