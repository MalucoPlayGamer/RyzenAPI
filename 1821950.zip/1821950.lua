-- Lua provided by SkyAPI 
-- Game: AppID 1821950
addappid(1821950)
addappid(1821951, 1, "7894744195015a734f18b3caf2864ecdd670e1d2b7a50ac14623f61612e337ab")
