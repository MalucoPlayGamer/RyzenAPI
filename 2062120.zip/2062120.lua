-- Lua provided by RyzenAPI
-- Game: 2062120

-- MAIN APPLICATION
addappid(2062120)
-- Game: addappid(2062120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062121, 1, "02469bd3fc5909666dcba52047c05778f714ea3f2e9bae40685576223472c104")
addappid(2062123, 1, "ec7a6a8621e893a336faeeef63d3bb5219f5126b8ab0c3bb2ce0c2afea0e9524")
