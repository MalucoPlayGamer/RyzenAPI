-- Lua provided by RyzenAPI
-- Game: Path of Idle: Old Gods Rising

-- MAIN APPLICATION
addappid(4243990)
addappid(4243990) -- Path of Idle: Old Gods Rising
addappid(4985510) -- Path of Idle Old Gods Rising - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4243991, 1, "623ed85953c63973a1304b6251c1f4ae8ec579582fafa15adf440db37d696852")
addappid(4243991, 1, "623ed85953c63973a1304b6251c1f4ae8ec579582fafa15adf440db37d696852") -- Depot 4243991
addappid(4243992, 1, "f98fc8450d889cf7c2b73a25f834a6f0f3c5839fe383771816440bf41d0fdcc6")
addappid(4243992, 1, "f98fc8450d889cf7c2b73a25f834a6f0f3c5839fe383771816440bf41d0fdcc6") -- Depot 4243992

