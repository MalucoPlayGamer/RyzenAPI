-- 4243990's Lua and Manifest Created by Hubcap Manifest
-- Path of Idle: Old Gods Rising
-- Created: August 13, 2026 at 04:05:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4243990) -- Path of Idle: Old Gods Rising
-- MAIN APP DEPOTS
addappid(4243991, 1, "623ed85953c63973a1304b6251c1f4ae8ec579582fafa15adf440db37d696852") -- Depot 4243991
setManifestid(4243991, "1262873655030763845", 1239765377)
addappid(4243992, 1, "f98fc8450d889cf7c2b73a25f834a6f0f3c5839fe383771816440bf41d0fdcc6") -- Depot 4243992
setManifestid(4243992, "2295036286542235476", 499871363)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4985510) -- Path of Idle Old Gods Rising - Supporter Pack