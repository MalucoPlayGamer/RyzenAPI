-- Lua provided by RyzenAPI
-- Game: AppID 1150150

-- MAIN APPLICATION
addappid(1150150)
-- Game: addappid(1150150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150151, 1, "4a232dde61c97708125fd67ddd97a0d596f11272dea8ee227d46009ef0322718")
