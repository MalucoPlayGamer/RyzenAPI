-- Lua provided by RyzenAPI
-- Game: GreedFall

-- MAIN APPLICATION
addappid(606880)
addappid(1034720)

-- MAIN APP DEPOTS / PACKAGES
addappid(606881, 1, "51893736990321529ecd03e59acee9a60ed5c2a53e107949debe45cef32a5a53")
addappid(1468480, 0, "677f8e886652aeac6daa7c047778d8a7354419630229b74ae7f656c68251b8ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
