-- Lua provided by RyzenAPI
-- Game: Game: GreedFall

-- MAIN APPLICATION
addappid(606880)
addappid(1034720)
-- Game: addappid(606880)

-- MAIN APP DEPOTS / PACKAGES
addappid(606881, 1, "51893736990321529ecd03e59acee9a60ed5c2a53e107949debe45cef32a5a53")
addappid(1468480, 0, "677f8e886652aeac6daa7c047778d8a7354419630229b74ae7f656c68251b8ab")
