-- Lua provided by RyzenAPI
-- Game: Wang Yuanji - Officer Ticket / 王元姫使用券

-- MAIN APPLICATION
addappid(956862)

-- MAIN APP DEPOTS / PACKAGES
addappid(956862,0,"89529c80e86eabd1dbafba6db12cf463f43f63e13066d24d7d6b59a116395a52")
