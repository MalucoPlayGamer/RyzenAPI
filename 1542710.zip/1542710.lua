-- Lua provided by RyzenAPI
-- Game: Dreams of an Exile

-- MAIN APPLICATION
addappid(1542710)
-- Game: addappid(1542710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542711, 1, "f561ccb9ffd4961e65d4a8d1a80526e1d74bc0bf6d25a19b509095cc2a49224a")
