-- Lua provided by RyzenAPI
-- Game: I got BLACKMAILED by a FUTANARI!

-- MAIN APPLICATION
addappid(2772660)
-- Game: addappid(2772660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772661, 1, "5b199c93c1561230fcd00c7df4ec0a0bb73e80ae82d493dd1d4816efe63756ea")
