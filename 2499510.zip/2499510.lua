-- Lua provided by RyzenAPI
-- Game: Absurd Story: Back Home

-- MAIN APPLICATION
addappid(2499510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499511, 1, "4b698bf487237662ba972183264c910f9d249ad0f6ed4b2c59bceb23f4953646")

