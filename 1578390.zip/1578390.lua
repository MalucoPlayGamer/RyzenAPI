-- Lua provided by RyzenAPI 
-- Game: My Garage
addappid(1578390)
addappid(1578391, 1, "2629060dc735b648e02216c3c27486fc1158eabb37d690a8d820d7565abe107f")
