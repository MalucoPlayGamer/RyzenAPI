-- Lua provided by RyzenAPI
-- Game: Game: My Garage

-- MAIN APPLICATION
addappid(1578390)
-- Game: addappid(1578390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578391, 1, "2629060dc735b648e02216c3c27486fc1158eabb37d690a8d820d7565abe107f")
