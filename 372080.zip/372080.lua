-- Lua provided by RyzenAPI
-- Game: Kramora's Shadow

-- MAIN APPLICATION
addappid(372080)

-- MAIN APP DEPOTS / PACKAGES
addappid(372081, 1, "1c11c8f30d062d2889494c8c1b4373126dc4fa43cd2d058c16489419f6564b46")
addappid(372082, 1, "7dda32345efa4d49aa71365ae04fc4c87ce772aed3cb9399ca4e16479a5c5dc7")
addappid(372083, 1, "4d22f0560d2bf2bd5ac4d5c62b9b1161e6f11a101e87acd3e542f8e202b70cac")

