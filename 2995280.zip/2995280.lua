-- Lua provided by RyzenAPI
-- Game: Game: Clothing Store Simulator Demo

-- MAIN APPLICATION
addappid(2995280)
-- Game: addappid(2995280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2995281, 1, "4a58f05a944e0f47fb7f3c595a8abc4c336677b2e5bbf0095a6046669588aeb2")
