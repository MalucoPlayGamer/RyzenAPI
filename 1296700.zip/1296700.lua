-- Lua provided by RyzenAPI 
-- Game: Headbangers in Holiday Hell
addappid(1296700)
addappid(1296701, 1, "2cc87506f5d5334f2e32ad20f8a76eebe8115ec180518f1b69a166e2d12f73dc")
