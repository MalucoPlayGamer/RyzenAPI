-- Lua provided by RyzenAPI
-- Game: 1296700

-- MAIN APPLICATION
addappid(1296700)
-- Game: addappid(1296700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296701, 1, "2cc87506f5d5334f2e32ad20f8a76eebe8115ec180518f1b69a166e2d12f73dc")
