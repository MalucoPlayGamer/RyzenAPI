-- Lua provided by RyzenAPI
-- Game: Idol Magical Girl Chiru Chiru Michiru Part 2

-- MAIN APPLICATION
addappid(377720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(377721, 1, "563f6fe3e58a873cc598d456d327e3c37b345d86469e10b87223c772a954c8ff")
addappid(377722, 1, "a1a7b314a0d7133e51cbe0ab5e30f489119aad6603abaa74c7bb0d1337dad4a6")

