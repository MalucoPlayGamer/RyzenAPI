-- Lua provided by RyzenAPI
-- Game: Game: Eventide 3: Legacy of Legends

-- MAIN APPLICATION
addappid(677020)
-- Game: addappid(677020)

-- MAIN APP DEPOTS / PACKAGES
addappid(677021, 1, "59fc06802b18ff971913972ab934c3a9c40673bb8165c823182bcfaa872472fd")
