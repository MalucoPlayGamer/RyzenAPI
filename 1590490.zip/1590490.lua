-- Lua provided by RyzenAPI
-- Game: Game: AppID 1590490

-- MAIN APPLICATION
addappid(1590490)
-- Game: addappid(1590490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590491, 1, "2767cd807fef754e515e85888b9ec24d6ac0994f507e02a98351ab0ae12a479c")
