-- Lua provided by RyzenAPI
-- Game: Chasing Styx

-- MAIN APPLICATION
addappid(594300)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(594301, 1, "9e5783182a2e99972f3fab020a2085f2d5d772df5bbf80988d756b81d9e0be47")
addappid(594302, 1, "ea2125c2bcd09438ca89e0551063fd1e864c00be64d5780977d3a45528e37c08")
addappid(594303, 1, "f9ba031c666c91ef4edc3dd72a3129c6a2ce93acfbb16584ac752de112422b49")

