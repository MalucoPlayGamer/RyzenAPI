-- Lua provided by RyzenAPI
-- Game: Chasing Styx

-- MAIN APPLICATION
addappid(594300)
-- Game: addappid(594300)

-- MAIN APP DEPOTS / PACKAGES
addappid(594301, 1, "9e5783182a2e99972f3fab020a2085f2d5d772df5bbf80988d756b81d9e0be47")
addappid(594302, 1, "ea2125c2bcd09438ca89e0551063fd1e864c00be64d5780977d3a45528e37c08")
addappid(594303, 1, "f9ba031c666c91ef4edc3dd72a3129c6a2ce93acfbb16584ac752de112422b49")
