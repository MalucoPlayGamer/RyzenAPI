-- Lua provided by RyzenAPI
-- Game: The Conquest of Go

-- MAIN APPLICATION
addappid(1264970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264971, 1, "895e7b54910685eab2f85579edfd824aa1f0e871684f9893123fba0ac740d11b")
