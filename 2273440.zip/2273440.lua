-- Lua provided by RyzenAPI
-- Game: 可识此阵

-- MAIN APPLICATION
addappid(2273440)
-- Game: addappid(2273440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273441, 1, "49c4fccf41b87b59ea93ed051e432e0bce6dd7d14825ca240741d2586ab4cdde")
