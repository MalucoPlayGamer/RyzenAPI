-- Lua provided by RyzenAPI
-- Game: shock wave

-- MAIN APPLICATION
addappid(2895140)
-- Game: addappid(2895140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895141, 1, "09e8a35e1b82255d6e7281e807882b9502fdb55c11329df0bf6ee452d07c8ddb")
