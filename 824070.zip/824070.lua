-- Lua provided by RyzenAPI
-- Game: Objects in Space

-- MAIN APPLICATION
addappid(824070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(824071, 1, "fdaf5f01721cf219ef0ec294470ea0b72f1e5d22ce510c6a6c34e91a13821a8b")
addappid(824072, 1, "07f1321706ec8e3032f81f390bef19a525b76037a8e1a60c01ddf68d96d85506")
addappid(824073, 1, "a5ce15c495571856940111c4011f7b22442ca21364121629a9f334842086d1b2")
