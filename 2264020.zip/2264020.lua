-- Lua provided by RyzenAPI 
-- Game: Saiko no sutoka no shiki
addappid(2264020)
addappid(2264021, 1, "7ac425d371333df5cd807387eb3049aa6b6760f34fcff241addbe96c8c05d653")
