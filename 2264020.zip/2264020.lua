-- Lua provided by RyzenAPI
-- Game: Saiko no sutoka no shiki

-- MAIN APPLICATION
addappid(2264020)
-- Game: addappid(2264020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264021, 1, "7ac425d371333df5cd807387eb3049aa6b6760f34fcff241addbe96c8c05d653")
