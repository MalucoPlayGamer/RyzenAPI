-- Lua provided by RyzenAPI
-- Game: Cow Girls 3 Stories

-- MAIN APPLICATION
addappid(2443550)
addappid(2452780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443551, 1, "07684db9df6b3f664ee179c1f193114e9a8a1daa00a0cc401478a4c88a9d4098")
