-- Lua provided by RyzenAPI
-- Game: Practisim VR

-- MAIN APPLICATION
addappid(611720)

-- MAIN APP DEPOTS / PACKAGES
addappid(611721, 1, "36fa4b7f630180fae65350bcf34e0d19747a97e7914cff51832839a30fb25410")

