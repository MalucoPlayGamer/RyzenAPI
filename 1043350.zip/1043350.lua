-- Lua provided by RyzenAPI
-- Game: Game: AppID 1043350

-- MAIN APPLICATION
addappid(1043350)
-- Game: addappid(1043350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043351, 1, "2070eba01221e2772d41e12b30d1319ee592713d5592ee511fa78a5ee57f36de")
