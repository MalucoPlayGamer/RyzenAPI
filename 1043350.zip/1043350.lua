-- Lua provided by RyzenAPI
-- Game: 1406

-- MAIN APPLICATION
addappid(1043350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1043351, 1, "2070eba01221e2772d41e12b30d1319ee592713d5592ee511fa78a5ee57f36de")