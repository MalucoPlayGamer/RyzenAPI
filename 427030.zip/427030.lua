-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword: The Gate of Firmament

-- MAIN APPLICATION
addappid(427030)

-- MAIN APP DEPOTS / PACKAGES
addappid(427031, 1, "aff7172a7fe2cf4150333ff521bc8939d78594c7d7c13cbe76768aec462f8c88")
addappid(441940, 0, "1efc6519dced7e97a4e0879800f9cb114cd39d247fa30a2ee45ef102999213e2")
