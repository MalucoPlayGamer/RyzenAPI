-- Lua provided by RyzenAPI
-- Game: Protect Me

-- MAIN APPLICATION
addappid(734820)

-- MAIN APP DEPOTS / PACKAGES
addappid(734821, 1, "5adef31733256447cfb6367f453940ebde05bb47aa69442f4fee3c17eeef52e1")

