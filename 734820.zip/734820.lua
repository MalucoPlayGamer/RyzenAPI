-- Lua provided by SkyAPI 
-- Game: Protect Me
addappid(734820)
addappid(734821, 1, "5adef31733256447cfb6367f453940ebde05bb47aa69442f4fee3c17eeef52e1")
