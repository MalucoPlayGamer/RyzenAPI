-- Lua provided by RyzenAPI
-- Game: 1241020

-- MAIN APPLICATION
addappid(1241020)
addappid(1243390)
-- Game: addappid(1241020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241021, 1, "74962fd56c6fcf560a98ad2098bb4a1fe4ae59ce2a0efaddc1ec39b516990254")
