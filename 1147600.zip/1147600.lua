-- Lua provided by RyzenAPI
-- Game: Star Police

-- MAIN APPLICATION
addappid(1147600)
-- Game: addappid(1147600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147601, 1, "88f0c5cfcbab000a027791f5c84952a996da60a509580857e96464f871f2d495")
