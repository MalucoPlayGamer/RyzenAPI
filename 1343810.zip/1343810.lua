-- Lua provided by SkyAPI 
-- Game: Fallen Hero: Retribution
addappid(1343810)
addappid(1343811, 1, "a148cc34a2bcdb8e2c3e18ae61f4724b9981253bdbf45e3bb478d544ff44fd0d")
