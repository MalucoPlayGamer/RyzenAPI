-- Lua provided by RyzenAPI
-- Game: 1343810

-- MAIN APPLICATION
addappid(1343810)
-- Game: addappid(1343810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343811, 1, "a148cc34a2bcdb8e2c3e18ae61f4724b9981253bdbf45e3bb478d544ff44fd0d")
