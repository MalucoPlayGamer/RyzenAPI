-- Lua provided by RyzenAPI
-- Game: 守护与智友 Playtest

-- MAIN APPLICATION
addappid(3049090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049091, 1, "6dfe4cd79b4a87b65de02e6446159ac9f5f637e58cdcd79b9997d71c98c946f6")

