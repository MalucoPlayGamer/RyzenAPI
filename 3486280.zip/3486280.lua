-- Lua provided by RyzenAPI
-- Game: Long Knives

-- MAIN APPLICATION
addappid(3486280)

