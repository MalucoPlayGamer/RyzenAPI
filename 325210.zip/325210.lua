-- Lua provided by RyzenAPI 
-- Game: Arctico
addappid(325210)
addappid(325211, 1, "a8ac0ee7156168376ff07b9319af38fd75268e9af29cab7c520c41bbf35797d6")
addappid(325212, 1, "0953c1747a6e94fc628fc42581c03d14d7870946418fd8ec5beb907e8e42820c")
