-- Lua provided by RyzenAPI
-- Game: Chicken Wars

-- MAIN APPLICATION
addappid(668790)

-- MAIN APP DEPOTS / PACKAGES
addappid(668791, 1, "78ff419f185c9755c693f44df27681b04949eb0cae9c2bf65a15cece286e86ee")
