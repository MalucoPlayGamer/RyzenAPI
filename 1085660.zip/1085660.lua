-- 1085660's Lua and Manifest Created by Hubcap Manifest
-- Destiny 2
-- Created: July 28, 2026 at 21:05:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 67 (1 excluded)

-- MAIN APPLICATION
addappid(1085660, 1, "c4207f985a7c9087d85059e8db2abe93ae173c09d47677391e006235e0a8fd56") -- Destiny 2
-- MAIN APP DEPOTS
addappid(1085661, 1, "c659b5e3411b08b00254acdd060490edf00b7803c96e6c45c875bf427882b23b") -- Game Depot
setManifestid(1085661, "4529650157997769787", 161290906657)
addappid(1085662, 1, "ff16e660aa96ae3ecc53e25fd85e91273d87d9c1b78eb6ff7ece94c49c71bb5b") -- Game Depot - English
setManifestid(1085662, "7375010213057600838", 1515366990)
addappid(1085663, 1, "42a1acec866dc7977209ce879cde1c8636fd095b623725296fec3bdacc1797ab") -- Game Depot - French
setManifestid(1085663, "1859000992539302057", 1673595470)
addappid(1085664, 1, "dcde0e8344ec4e244155e8528079e159567072957b2bae75171724a8d836acf3") -- Game Depot - German
setManifestid(1085664, "843010868981503229", 1698396750)
addappid(1085665, 1, "fa4269489ba4a1346cc9063fd65d4b22539746883528d176084b95ff0769b2c1") -- Game Depot - Italian
setManifestid(1085665, "5064548901532831036", 1693915726)
addappid(1085666, 1, "9bab62c5acd50b61eb290625804368f677ee7f96e8dd7f0cbbcc2c34e47168ec") -- Game Depot - Japanese
setManifestid(1085666, "2641119778591315688", 1690749518)
addappid(1085667, 1, "ac3cafaebc96e76d529cd097ea5c85ca3f621cca08297e13204cb4fa8f384ee5") -- Game Depot - Portuguese
setManifestid(1085667, "7177273242512299173", 1674179150)
addappid(1085668, 1, "a54be657f1cd95a08b8d2049fc546681135effdc9971899cc89c4b3f2c8ee56c") -- Game Depot - Spanish
setManifestid(1085668, "3339808893027695875", 1658569294)
addappid(1085669, 1, "0126ecc80f9aae320d66ecf39dcce8f73a1245acff9516c6109fcf99aeef781e") -- Game Depot - Russian
setManifestid(1085669, "2016052316336468334", 1629219406)
addappid(1085670, 1, "aeb7f802f6ca21071a812710ecc34bbace05de554f09e18d579dac18c63ef6ac") -- Game Depot - Polish
setManifestid(1085670, "575320013410355920", 1683696206)
addappid(1085671, 1, "977be35521ffd206e64dde54bca54a740c1cb879790e0717ab57f8bdc139d708") -- Game Depot - Chinese Simplified
setManifestid(1085671, "3110547029442914749", 1469127246)
addappid(1085672, 1, "c15ac58ea22a195cc9edcd283275257c8caa0a7b1a341647baa3a16c158b82d8") -- Game Depot - Chinese Traditional
setManifestid(1085672, "6543729476543402278", 123069006)
addappid(1085673, 1, "54f7fa19d2b67a383ca442dfbf1e7a4c575ffbf270376f3c91f8b67ec1abb921") -- Game Depot - Latin American Spanish
setManifestid(1085673, "5465516270575494674", 1605448270)
addappid(1085674, 1, "cb850bb898523fe75e34e44ef0047fe0269ab8b33267ab65886061200eb4815b") -- Game Depot - Korean
setManifestid(1085674, "6869183220623480953", 1554217550)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1090090) -- Destiny 2 Kill Tracker Ghost Pre-Order Pack
addappid(1090091) -- Destiny 2 Exotic Weapon Coldheart Pre-Order Pack
addappid(1090092) -- Destiny 2 Salute Emote Pre-Order Pack
addappid(1090093) -- Destiny 2 Premium Digital Content Pack
addappid(1090094) -- Destiny 2 Curse of Osiris
addappid(1090095) -- Destiny 2 Warmind
addappid(1090096) -- Destiny 2 Expansion Pass
addappid(1090150) -- Destiny 2 Forsaken Pack
addappid(1090151) -- Destiny 2 Forsaken Annual Pass
addappid(1090152) -- Destiny 2 Forsaken Pre-Order Pack
addappid(1090170) -- Destiny 2 Forsaken Deluxe Pack
addappid(1090171) -- Destiny 2 Forsaken Korea Pre-Order Pack
addappid(1090200) -- Destiny 2 Shadowkeep Pack
addappid(1090201) -- Destiny 2 Shadowkeep Pre-Order Pack
addappid(1090202) -- Destiny 2 Shadowkeep Deluxe Pack
addappid(1314550) -- Destiny 2 Beyond Light Pre-Order Pack
addappid(1314560) -- Destiny 2 Beyond Light Exotic Emote
addappid(1314561) -- Destiny 2 Beyond Light Strangers Upgrade Pack
addappid(1314562) -- Destiny 2 Beyond Light Strangers Weapon Pack
addappid(1314563) -- Destiny 2 Beyond Light Pack
addappid(1330040) -- Destiny 2 Season of Arrivals Silver Bundle
addappid(1370350) -- Destiny 2 Season of the Hunt Silver Bundle
addappid(1438630) -- Destiny 2 Beyond Light Deluxe Edition Upgrade
addappid(1504300) -- Destiny 2 Season of the Chosen Silver Bundle
addappid(1565570) -- Destiny 2 Season of the Splicer Silver Bundle
addappid(1569630) -- Destiny 2 Throne of Atheon Emote Bundle
addappid(1656330) -- Destiny 2 The Witch Queen
addappid(1656340) -- Destiny 2 The Witch Queen Pre-Order Pack
addappid(1656350) -- Destiny 2 The Witch Queen Deluxe Edition
addappid(1656360) -- Destiny 2 The Witch Queen Deluxe  Bungie 30th Anniversary Bundle
addappid(1656370) -- Destiny 2 Bungie 30th Anniversary Pack
addappid(1656380) -- Destiny 2 Season of the Lost Silver Bundle
addappid(1656390) -- Destiny 2 Season of the Risen Silver Bundle
addappid(1656400) -- Destiny 2 Season of the Haunted Silver Bundle
addappid(1656410) -- Destiny 2 Season of Plunder Silver Bundle
addappid(1656420) -- Destiny 2 Season of the Seraph Silver Bundle
addappid(1745440) -- Destiny 2 Triumphant Silver Bundle
addappid(1816020) -- Destiny 2 The Witch Queen Deluxe Edition Upgrade
addappid(1940230) -- Destiny 2 Season of Defiance Silver Bundle
addappid(1945340) -- Destiny 2 Lightfall
addappid(1945360) -- Destiny 2 Lightfall  Annual Pass
addappid(1945370) -- Destiny 2 Lightfall Pre-Order Pack
addappid(1945380) -- Destiny 2 Lightfall Exotic Weapon
addappid(1945390) -- Destiny 2 Lightfall Exotic Emote
addappid(1945420) -- Destiny 2 Lightfall  Annual Pass Upgrade
addappid(2218000) -- Destiny 2 Season of the Deep Silver Bundle
addappid(2218001) -- Destiny 2 Season of the Witch Silver Bundle
addappid(2218002) -- Destiny 2 Season of the Wish Silver Bundle
addappid(2218003) -- Destiny 2 Echoes Silver Bundle
addappid(2266420) -- Destiny 2 Legacy Collection (2023)
addappid(2336880) -- Destiny 2 The Final Shape
addappid(2336881) -- Destiny 2 The Final Shape  Annual Pass
addappid(2336882) -- Destiny 2 The Final Shape Pre-Order Pack
addappid(2336883) -- Destiny 2 The Final Shape Exotic Weapon
addappid(2336884) -- Destiny 2 The Final Shape Exotic Emote
addappid(2336885) -- Destiny 2 The Final Shape Annual Pass Upgrade
addappid(2336910) -- Destiny 2 Starter Pack
addappid(2343180) -- Destiny 2 Armory Collection (30th Anniv.  Forsaken Pack)
addappid(2648100) -- Destiny 2 Legacy Collection (2024)
addappid(2972400) -- Destiny 2 Revenant Silver Bundle
addappid(2972410) -- Destiny 2 Heresy Silver Bundle
addappid(2972420) -- Destiny 2 Reclamation Silver Bundle
addappid(2972430) -- Destiny 2 Ash  Iron Silver Bundle
addappid(3186490) -- Destiny 2 The Edge of Fate
addappid(3186540) -- Destiny 2 Renegades
addappid(3952720) -- Destiny 2 Triumphant Rewards Silver Bundle
addappid(4562000) -- Destiny 2 Dungeon Key Pack
addtoken(4562000, "16049967099097266182")
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(1945350) -- Destiny 2: Lightfall Annual Pass Upgrade (unreleased)