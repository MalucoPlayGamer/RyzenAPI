-- Lua provided by RyzenAPI
-- Game: Game: 50

-- MAIN APPLICATION
addappid(1830480)
-- Game: addappid(1830480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830481, 1, "89e34c56b9962e840e242e3b1b6aa5c6ce9bf102cb5aa1b5d935f4d827c7ec86")
