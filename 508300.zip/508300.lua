-- Lua provided by RyzenAPI
-- Game: AppID 508300

-- MAIN APPLICATION
addappid(508300)

-- MAIN APP DEPOTS / PACKAGES
addappid(508301, 1, "7ca42cfc2b5bc255e8e7ec1856ea4834cf32cafcc200843620bdbfe0a6ed823d")
