-- Lua provided by SkyAPI 
-- Game: AppID 1189740
addappid(1189740)
addappid(1189741, 1, "05f8eaf399a01328255ec2be5cdf1c59843755e2bd5bed2e8eef944d65bd5676")
