-- Lua provided by RyzenAPI
-- Game: addappid(1638520)

-- MAIN APPLICATION
addappid(1638520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638521, 1, "14f919985b9cfd360bf02c061e9a05541e85bf40bb3db9382e7c1149dc9f1579")
