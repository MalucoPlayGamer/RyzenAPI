-- Lua provided by RyzenAPI
-- Game: Hyperglide

-- MAIN APPLICATION
addappid(1638520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1638521, 1, "14f919985b9cfd360bf02c061e9a05541e85bf40bb3db9382e7c1149dc9f1579")

