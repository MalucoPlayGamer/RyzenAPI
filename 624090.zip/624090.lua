-- Lua provided by RyzenAPI
-- Game: AppID 624090

-- MAIN APPLICATION
addappid(624090)
addappid(711730)

-- MAIN APP DEPOTS / PACKAGES
addappid(624091, 1, "0eaedfdfe20625923a7924d9939c58e2ce4d969f2b38838fe0c1693d925357c7")
addappid(624092, 1, "85b09112ae949e6d725632dd45fca3f4077510a037ff2f45dc735abaec7f1b59")
addappid(624093, 1, "088ea190e0f89903e796f98af0f4ce9754fbc69f53a8b3f5d6e8bb3bd27ada9f")
addappid(624094, 1, "da44204814c11446fcbb134e14502c0f70d791499097a615e31e42a4d18e52d1")
addappid(624095, 1, "a8bcf3452521a9c3bd91bc6ab0c58f4ff901c1fd7bfb759a62cf2f0fe66720fb")
addappid(624096, 1, "5ae68d4e6aa1961b5d5aabe060bf12392e43a6c5f1d8a7753c91a2e38b4e35c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
