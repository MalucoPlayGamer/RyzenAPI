-- Lua provided by RyzenAPI
-- Game: Railroad Tycoon II Platinum

-- MAIN APPLICATION
addappid(7620)

-- MAIN APP DEPOTS / PACKAGES
addappid(7621, 1, "68093523d8ef51e0969b6b1bd3c244d0284223944e7f53700c3e36d03ca78e27")
