-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - POP: Slasher Forest

-- MAIN APPLICATION
addappid(1468850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468850,0,"c14805fb98156f3d3e5e58388e6726f36fe44d35645a341019242fe702e58e33")

