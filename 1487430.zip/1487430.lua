-- Lua provided by RyzenAPI 
-- Game: Muse:Night Out
addappid(1487430)
addappid(1487431, 1, "8efa33d965eb18fa24159061be896bff016cac49e68745a3eb0fc2840be7c3d3")
addappid(1521990, 0, "f9e61bf1809a9d571ea7261d5eafc7436bdaec6e6f5834a8a02cf854d7bfb7c5")
