-- Lua provided by RyzenAPI
-- Game: Game: Outside

-- MAIN APPLICATION
addappid(746760)
-- Game: addappid(746760)

-- MAIN APP DEPOTS / PACKAGES
addappid(746761, 1, "800ce80e515b094f2f247af84f914559900a99651523e0fe5c640aa1c862c770")
