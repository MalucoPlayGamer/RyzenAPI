-- Lua provided by SkyAPI 
-- Game: Outside
addappid(746760)
addappid(746761, 1, "800ce80e515b094f2f247af84f914559900a99651523e0fe5c640aa1c862c770")
