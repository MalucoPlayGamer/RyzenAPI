-- Lua provided by RyzenAPI
-- Game: Treasure Hunter Claire

-- MAIN APPLICATION
addappid(828070)

-- MAIN APP DEPOTS / PACKAGES
addappid(828071, 1, "b9d79b992c2961aab11c5ca92dc32061de90dc773aa11a4f602a235a6429b3d1")
addappid(828072, 1, "a8beacd32d824fcb73bc287fb854a22af0b5d7a1652c5a88d5e09f86a3eb1a0d")
addappid(828073, 1, "ef3ec75836c091ddb5ce36f2d22ef841138216cd96dea8bac330e927133e1a1b")
addappid(828074, 1, "4f5e0ce70e8247eb32a3b063c2f721701c6ca848bc96475350b15ade0b36cdb2")
