-- Lua provided by RyzenAPI
-- Game: Killer Instinct - The Complete Soundtrack

-- MAIN APPLICATION
addappid(720530)

-- MAIN APP DEPOTS / PACKAGES
addappid(720530,0,"a91f8ebe9f17a4336d7557ecb50955ed97e27bc65ab877a587ca70ed91915075")
