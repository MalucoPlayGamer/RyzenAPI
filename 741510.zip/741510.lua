-- Lua provided by RyzenAPI
-- Game: AppID 741510

-- MAIN APPLICATION
addappid(741510)

-- MAIN APP DEPOTS / PACKAGES
addappid(741511, 1, "306d2bd04ca970553b5c0abec7bb73a5eb8918ec7edc31a1b7a5985abb3d15fe")

