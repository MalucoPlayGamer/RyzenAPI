-- Lua provided by RyzenAPI
-- Game: The Hong Kong Massacre

-- MAIN APPLICATION
addappid(741510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(741511, 1, "306d2bd04ca970553b5c0abec7bb73a5eb8918ec7edc31a1b7a5985abb3d15fe")

