-- Lua provided by RyzenAPI
-- Game: Game: AppID 1383400

-- MAIN APPLICATION
addappid(1383400)
addappid(1435550)
addappid(1435551)
addappid(1435552)
-- Game: addappid(1383400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383401, 1, "2da0d635b71bf98fcb98df22eb57ea70dbe242cfb31eef01d4db335ac69c79e2")
