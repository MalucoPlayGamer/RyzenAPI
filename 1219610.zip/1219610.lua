-- Lua provided by RyzenAPI
-- Game: 1219610

-- MAIN APPLICATION
addappid(1219610)
-- Game: addappid(1219610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219611, 1, "1039a0e8433f2ed85e3eafbfadf153a9a7d7264576ff92a1676c0b5c5793e7db")
