-- Lua provided by RyzenAPI
-- Game: The Juicer

-- MAIN APPLICATION
addappid(400790)

-- MAIN APP DEPOTS / PACKAGES
addappid(400791, 1, "a0a158e8e2e9a59a6a000275e1215e06869abb47f82dff7c788276bf06a642e7")

