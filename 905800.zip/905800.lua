-- Lua provided by RyzenAPI
-- Game: addappid(905800)

-- MAIN APPLICATION
addappid(905800)

-- MAIN APP DEPOTS / PACKAGES
addappid(905801, 1, "5ae17bf3c435ed5e51b807a651d17e8e2a06adc5ff0da37ece15b25feb52ef47")
