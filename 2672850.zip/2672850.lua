-- Lua provided by RyzenAPI
-- Game: A Game About Flicking A Switch

-- MAIN APPLICATION
addappid(2672850)
-- Game: addappid(2672850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672851, 1, "9362fa084c3ae733bb1678b47d4b27431fe59d47b75c69ea2982b6681f3759e8")
