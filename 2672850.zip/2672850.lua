-- Lua provided by RyzenAPI
-- Game: A Game About Flicking A Switch

-- MAIN APPLICATION
addappid(2672850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2672851, 1, "9362fa084c3ae733bb1678b47d4b27431fe59d47b75c69ea2982b6681f3759e8")

