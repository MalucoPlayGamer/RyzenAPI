-- Lua provided by RyzenAPI
-- Game: addappid(3283090)

-- MAIN APPLICATION
addappid(3283090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3283090,0,"ff57df5770f283685d2d085d99d75a442a8b8ce5ddd8ca2830cfa6122c6e7e12")
