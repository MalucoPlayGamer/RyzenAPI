-- Lua provided by RyzenAPI
-- Game: Golden Lap Demo

-- MAIN APPLICATION
addappid(3023630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023631, 1, "15d18bd7b9c4237ff7980c2f1a01b03f35ecf95c1160d035f2e193cb480613a5")
