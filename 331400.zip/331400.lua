-- Lua provided by RyzenAPI
-- Game: Luna: Shattered Hearts: Episode 1

-- MAIN APPLICATION
addappid(228990)
addappid(331400)

-- MAIN APP DEPOTS / PACKAGES
addappid(331402,0,"3bbb5fb90a3ae20f82933c556abb5d96fec09fccef8d9b45bee3c31f7704f6d7")
