-- Lua provided by RyzenAPI
-- Game: 3376160

-- MAIN APPLICATION
addappid(3376160)
-- Game: addappid(3376160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376161, 1, "07ac97e50d3ae190084388a2486b62affcfb9ed38305e814beba46ceb0d75171")
