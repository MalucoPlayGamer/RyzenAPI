-- Lua provided by RyzenAPI
-- Game: Furry BDSM

-- MAIN APPLICATION
addappid(2502600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2502601, 1, "4a368966af1dbc4fdc8c5ab75339a16e883dbdf6e0e1d6e794c2e61b0483a48a")
