-- Lua provided by RyzenAPI
-- Game: Game: Conan Exiles Enhanced

-- MAIN APPLICATION
addappid(440900)
addappid(760730)
addappid(785120)
addappid(788220)
addappid(887120)
addappid(919390)
addappid(972370)
addappid(1040930)
addappid(1066190)
addappid(1066250)
addappid(1076150)
addappid(1134010)
addappid(1147100)
addappid(1173900)
addappid(1265640)
addappid(1410760)
addappid(1668110)
-- Game: addappid(440900)

-- MAIN APP DEPOTS / PACKAGES
addappid(440901, 1, "57ff2e2d0f7c2740c0c36426359060ef90b3367394dae24b861efff0752010fd")
addappid(440902, 1, "c4039510426aa98899efbe92e3777309401d95e2b341f6605db10afee7e2f7a9")
addappid(440903, 1, "55bc314377497f1dc799ba2accf9643afc380ad197155bca6dfb5326e8760270")
addappid(577840, 0, "5de478d01266d514b190336ec2af425bffc9016ca5c27869a17d38b216294fdc")
addappid(1206200, 0, "634db241a3f4000ce8cde76f15b56686f7dcd983aacae9869864dbdbc9afa4a0")
