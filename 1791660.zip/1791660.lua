-- Lua provided by RyzenAPI
-- Game: Game: Dollhouse: Behind the Broken Mirror

-- MAIN APPLICATION
addappid(1791660)
-- Game: addappid(1791660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791661, 1, "001d8e50132708bebf1a01d85ba7098b7877eb23e1722c52e62fbf4225440247")
