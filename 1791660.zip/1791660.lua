-- Lua provided by RyzenAPI
-- Game: Dollhouse: Behind the Broken Mirror

-- MAIN APPLICATION
addappid(1791660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1791661, 1, "001d8e50132708bebf1a01d85ba7098b7877eb23e1722c52e62fbf4225440247")

