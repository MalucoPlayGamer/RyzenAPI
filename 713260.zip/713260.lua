-- Lua provided by RyzenAPI
-- Game: Beyond the Sunset 斜阳下的彼岸

-- MAIN APPLICATION
addappid(713260)

-- MAIN APP DEPOTS / PACKAGES
addappid(713261, 1, "d8f946478be965c6ad097680c94476989b20854fac5dd5c43066d84541487051")

