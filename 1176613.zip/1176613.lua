-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Legendary Costumes OROCHI Pack 4

-- MAIN APPLICATION
addappid(1176613)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176613,0,"1ffe89b244821b95875a52e49cc2fa8b1587b3c925ed72b90c6285deb14b086e")

