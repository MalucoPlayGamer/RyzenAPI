-- Lua provided by RyzenAPI
-- Game: addappid(1197590)

-- MAIN APPLICATION
addappid(1197590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197591, 1, "ef67bde157f071641ed050d9f4ce29573f2907affa22f10c55ce565668f082ce")
