-- Lua provided by RyzenAPI
-- Game: Frontier Forge

-- MAIN APPLICATION
addappid(3313070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313071, 1, "700c4f43560b245be3e596a3324bf6949335b64ffa7f432f44952207a65eac8c")
