-- Lua provided by RyzenAPI
-- Game: Game: Hunter Hitman

-- MAIN APPLICATION
addappid(3397160)
-- Game: addappid(3397160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397161, 1, "d20b862278218fcd5ab7bd15e4bc08312c8183ea3644d74e35aeea840eb98c4d")
addappid(3397162, 1, "d045ec7b8f1ee81654e1116468ad2a83c349dbdbf073e58ef2c8c482aa89cc09")
