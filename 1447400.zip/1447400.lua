-- Lua provided by SkyAPI 
-- Game: Samurai Slaughter House
addappid(1447400)
addappid(1447401, 1, "d6a7c9443538c7b523fd4311b3799af6c9e35b9294fb2d09d16487acb3e8f260")
