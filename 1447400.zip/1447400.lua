-- Lua provided by RyzenAPI
-- Game: Samurai Slaughter House

-- MAIN APPLICATION
addappid(1447400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447401, 1, "d6a7c9443538c7b523fd4311b3799af6c9e35b9294fb2d09d16487acb3e8f260")
