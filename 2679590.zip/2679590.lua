-- Lua provided by RyzenAPI
-- Game: Chaperone

-- MAIN APPLICATION
addappid(2679590)
-- Game: addappid(2679590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679591, 1, "9c1c4b92b21cde6ce664998cff755831d366233625aad7e2cd64131d239e73b4")
