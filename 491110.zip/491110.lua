-- Lua provided by RyzenAPI
-- Game: addappid(491110)

-- MAIN APPLICATION
addappid(491110)

-- MAIN APP DEPOTS / PACKAGES
addappid(491111, 1, "26be464e70f3da892e92e6b72f21ad24c945cb667875f8af7a283f850dc574ba")
