-- Lua provided by RyzenAPI
-- Game: interLOGIC

-- MAIN APPLICATION
addappid(563150)
-- Game: addappid(563150)

-- MAIN APP DEPOTS / PACKAGES
addappid(563151, 1, "db89595f279d1ecf2f00df6101a665de8c8c05ef569ee55d3cc55428981938b9")
