-- Lua provided by RyzenAPI
-- Game: addappid(1214540)

-- MAIN APPLICATION
addappid(1214540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214541, 1, "2225ee832b7433e8b109d00c26b355fdcfd62110d009f434a380b93fbe6a4968")
