-- Lua provided by RyzenAPI
-- Game: SUPER CIRCUIT BREAKERS

-- MAIN APPLICATION
addappid(1214540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214541, 1, "2225ee832b7433e8b109d00c26b355fdcfd62110d009f434a380b93fbe6a4968")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1214550)
addappid(1214551)
addappid(1214552)
addappid(1214553)
addappid(1214554)
addappid(1214555)
addappid(1214556)
addappid(1214557)
