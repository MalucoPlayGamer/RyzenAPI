-- Lua provided by RyzenAPI
-- Game: addappid(1436240)

-- MAIN APPLICATION
addappid(1436240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436241, 1, "3281db0fdb3cf9efdd3becbaaf8bc39bca11cd571ed353df467aff7aa64b502b")
