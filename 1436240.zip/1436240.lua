-- Lua provided by SkyAPI 
-- Game: Krakatoa
addappid(1436240)
addappid(1436241, 1, "3281db0fdb3cf9efdd3becbaaf8bc39bca11cd571ed353df467aff7aa64b502b")
