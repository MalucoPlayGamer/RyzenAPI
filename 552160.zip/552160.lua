-- Lua provided by RyzenAPI
-- Game: Game: Hade

-- MAIN APPLICATION
addappid(552160)
-- Game: addappid(552160)

-- MAIN APP DEPOTS / PACKAGES
addappid(552161, 1, "ebcdd85854b988ca9aaf5315e403883271073a6468bebb83c73366cd8c6ae61e")
addappid(875410, 0, "1010ee320f36e8087c4f54e979902906875ffd5ec2084a4950652bb9e560d1e8")
