-- Lua provided by SkyAPI 
-- Game: Hade
addappid(552160)
addappid(552161, 1, "ebcdd85854b988ca9aaf5315e403883271073a6468bebb83c73366cd8c6ae61e")
addappid(875410, 0, "1010ee320f36e8087c4f54e979902906875ffd5ec2084a4950652bb9e560d1e8")
