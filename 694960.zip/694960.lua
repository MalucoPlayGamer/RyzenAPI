-- Lua provided by RyzenAPI
-- Game: Zenethics Lab : Outbreak

-- MAIN APPLICATION
addappid(694960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(694961, 1, "dca518420c5f4ea3426a5575d3d996687ae2e920767b90a9c793773ca9ea0e77")

