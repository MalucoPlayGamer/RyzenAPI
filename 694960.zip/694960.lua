-- Lua provided by RyzenAPI
-- Game: addappid(694960)

-- MAIN APPLICATION
addappid(694960)

-- MAIN APP DEPOTS / PACKAGES
addappid(694961, 1, "dca518420c5f4ea3426a5575d3d996687ae2e920767b90a9c793773ca9ea0e77")
