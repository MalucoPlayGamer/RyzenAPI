-- Lua provided by RyzenAPI
-- Game: Nine Realms Prologue

-- MAIN APPLICATION
addappid(2900530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2900531, 1, "a001132144fbe94c60013f31b086c65ec8486a308b13c9fb5a43a81dd2555a54")
