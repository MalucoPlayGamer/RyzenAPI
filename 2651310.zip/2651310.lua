-- Lua provided by RyzenAPI
-- Game: Escape from the Goblin Lair

-- MAIN APPLICATION
addappid(2651310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651311, 1, "bde9a862771b76a267d498de86955fabad96e78a8e6e113a1ab66e04a7aa3352")
