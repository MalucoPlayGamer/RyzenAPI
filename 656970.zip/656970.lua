-- Lua provided by RyzenAPI
-- Game: MagiCat

-- MAIN APPLICATION
addappid(656970)

-- MAIN APP DEPOTS / PACKAGES
addappid(656971, 1, "788bd4e988ccc9315a4560b0ed6a4b7ca3bccc06e4b30f68c4399b765f816287")
addappid(656972, 1, "0abb8e611cbd8628d89ecf1ce2d0bb84bfce94c9156faac808cc79ce3f9cc02a")
addappid(658900, 0, "829bc2df0b23286556a85fd164446dcf181afe3fba992279c633a5787f0931bb")

