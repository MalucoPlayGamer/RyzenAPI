-- Lua provided by RyzenAPI
-- Game: addappid(3074650)

-- MAIN APPLICATION
addappid(3074650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074652,0,"0627b9fe9b4746eac4ff879d212fe92f79c1a9932d31b82f41741093dc8fd8aa")
