-- Lua provided by RyzenAPI
-- Game: Scythe: Digital Edition

-- MAIN APPLICATION
addappid(718560)

-- MAIN APP DEPOTS / PACKAGES
addappid(718561, 1, "18a346c0d39e5590c4ccfc88eb7c0f7ce4189abdf2ee90de5e6f40a39c39fb11")
addappid(718562, 1, "7ba590a2581bc3fc979da728d6d6050935e18235d03b54e99fb55c6a6f89d3a9")
