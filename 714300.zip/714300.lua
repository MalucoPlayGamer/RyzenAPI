-- Lua provided by RyzenAPI 
-- Game: Dead By Murder
addappid(714300)
addappid(714301, 1, "9866b1b67073bcd2f05f2db8b22c5024dafd6d700744c056f6db186203d92730")
addappid(714302, 1, "03ef3aa9a984ed75dfaf85c0460f0b45dc6ffca54c9c1c1ccee9955a338ba8d1")
addappid(714303, 1, "79da2b4aeaa8be182130739325a04b354d429c28d769c9abe15593a4bed6d236")
addappid(714304, 1, "e2f8cb8d3311e5d0fe9c02dafd701e8219e3d7a4fddb27ee8b6899f4895b3b3f")
