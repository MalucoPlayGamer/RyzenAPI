-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Card Game Combat Deckbuilder Engine

-- MAIN APPLICATION
addappid(3243580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243580,0,"0d36b6bb670f78370f4ce72db851fd237ebb5f6c116de3c7644098812c3df365")
