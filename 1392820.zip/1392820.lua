-- Lua provided by RyzenAPI
-- Game: Game: Milk inside a bag of milk inside a bag of milk

-- MAIN APPLICATION
addappid(1392820)
-- Game: addappid(1392820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392821, 1, "ce93995786da4603f789552702103267bb07ab363a18ea1f10879037d814c374")
