-- Lua provided by RyzenAPI
-- Game: 2819180

-- MAIN APPLICATION
addappid(2819180)
-- Game: addappid(2819180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819181, 1, "3f0a9f9239895aede6a67e2874a094d9c5a3738ac389404aa550da9e0db08cb9")
