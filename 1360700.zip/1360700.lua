-- Lua provided by RyzenAPI
-- Game: DREAM TIME

-- MAIN APPLICATION
addappid(1360700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360701, 1, "0d7f5f70542490effff22a1fd0ebc9f0da1c80e3b58ecfe7cb0912dff8a7fd17")
