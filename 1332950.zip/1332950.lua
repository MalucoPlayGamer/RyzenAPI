-- Lua provided by SkyAPI 
-- Game: KinnikuNeko: SUPER MUSCLE CAT
addappid(1332950)
addappid(1332951, 1, "fcb8d26315b432d36dd242acb502100f01c1a4aa42929bbbb8b2a6e0c59c96f1")
