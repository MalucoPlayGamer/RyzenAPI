-- Lua provided by RyzenAPI
-- Game: Keyboard Warrior

-- MAIN APPLICATION
addappid(4344210) -- Keyboard Warrior

-- MAIN APP DEPOTS / PACKAGES
addappid(4344211, 1, "83e98380c6678a32341167d5e4e0419b1384799b56c8fc5ddf2ac512ce292b63") -- Depot 4344211

