-- 4344210's Lua and Manifest Created by Hubcap Manifest
-- Keyboard Warrior
-- Created: August 03, 2026 at 02:50:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4344210) -- Keyboard Warrior
-- MAIN APP DEPOTS
addappid(4344211, 1, "83e98380c6678a32341167d5e4e0419b1384799b56c8fc5ddf2ac512ce292b63") -- Depot 4344211
setManifestid(4344211, "59907267845771632", 316159476)