-- Lua provided by RyzenAPI
-- Game: Natsu-Mon: 20th Century Summer Kid

-- MAIN APPLICATION
addappid(2839280)
addappid(2913330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839281, 1, "0f3c4a4638a09ca39ece60e8b7daa705bf0a70d0d9836cf7f109b5c324720537")
