-- Lua provided by RyzenAPI
-- Game: Natsu-Mon: 20th Century Summer Kid

-- MAIN APPLICATION
addappid(2839280)
addappid(2913330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839281, 1, "0f3c4a4638a09ca39ece60e8b7daa705bf0a70d0d9836cf7f109b5c324720537")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
