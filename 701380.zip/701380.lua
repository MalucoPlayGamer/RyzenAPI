-- Lua provided by RyzenAPI
-- Game: El Tango de la Muerte

-- MAIN APPLICATION
addappid(701380)
addappid(859670)

-- MAIN APP DEPOTS / PACKAGES
addappid(701381, 1, "1e05c54e60f09d23de4c743405ac41e8e86ce27cabbb49ff2cf00484e1e67f51")
