-- Lua provided by RyzenAPI
-- Game: Game: AppID 701380

-- MAIN APPLICATION
addappid(701380)
-- Game: addappid(701380)

-- MAIN APP DEPOTS / PACKAGES
addappid(701381, 1, "1e05c54e60f09d23de4c743405ac41e8e86ce27cabbb49ff2cf00484e1e67f51")
