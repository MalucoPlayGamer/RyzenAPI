-- Lua provided by RyzenAPI
-- Game: 2536650

-- MAIN APPLICATION
addappid(2536650)
-- Game: addappid(2536650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536651, 1, "3e512226e99dbf990fa0e750d9764eaee6c1ecd9e80149fbfdfaffb2ced009b3")
