-- Lua provided by RyzenAPI
-- Game: Depth Siege Atlantis

-- MAIN APPLICATION
addappid(849550)

-- MAIN APP DEPOTS / PACKAGES
addappid(849551, 1, "01ba3e78716380ebc2a675db03b79b3598a690c3e95552310d6015a082c14694")
