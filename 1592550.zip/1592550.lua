-- Lua provided by RyzenAPI
-- Game: AppID 1592550

-- MAIN APPLICATION
addappid(1592550)
-- Game: addappid(1592550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592551, 1, "03149686968dbd8cb3215da0ec61b2312fd96383512b23f44cb3deabbb4be432")
