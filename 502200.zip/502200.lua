-- Lua provided by RyzenAPI
-- Game: Orczz

-- MAIN APPLICATION
addappid(502200)
-- Game: addappid(502200)

-- MAIN APP DEPOTS / PACKAGES
addappid(502201, 1, "6e15024b10b84569093528ebef7fd5cc4e3af38f6730f7e4a608da2ff0748033")
addappid(502202, 1, "f4b4d7d063fce31440796121efd77ddeb5724b9d918034b79164f853467a84ec")
