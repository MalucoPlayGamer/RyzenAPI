-- Lua provided by RyzenAPI
-- Game: addappid(757630)

-- MAIN APPLICATION
addappid(757630)
addappid(757631)

-- MAIN APP DEPOTS / PACKAGES
addappid(757632,0,"08d0a140b5032a31af727f9c7f333858cbbd58ffdaf703857bb58d6a7d83ad71")
addappid(757633,0,"5be2b71443a5b324f8f83934fbfa2075bd0b56464f98b3fa06fc2eda359dec39")
