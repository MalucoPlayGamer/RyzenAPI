-- Lua provided by RyzenAPI
-- Game: Game: Demon Speakeasy

-- MAIN APPLICATION
addappid(1854250)
-- Game: addappid(1854250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854251, 1, "2f47694e5fe8e10fee5b3f0979c7086bc2745d9b27ed96813ff5a28e39b9f388")
