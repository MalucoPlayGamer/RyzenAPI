-- Lua provided by RyzenAPI
-- Game: 965610

-- MAIN APPLICATION
addappid(965610)
-- Game: addappid(965610)

-- MAIN APP DEPOTS / PACKAGES
addappid(965611, 1, "8a32a223bd9b3ac39569b9c965b7cbbc30c243d8684d16dfd4f3dd2036576835")
