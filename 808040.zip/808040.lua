-- Lua provided by RyzenAPI
-- Game: 808040

-- MAIN APPLICATION
addappid(808040)
-- Game: addappid(808040)

-- MAIN APP DEPOTS / PACKAGES
addappid(808042,0,"ee769d14c77151699ae7eef36072970adb15c000e452190e38378a907654a7e7")
addappid(808044,0,"c9efd6c2e6cc05068e20caace585daf5ed3fe0fbb47c9a691b749d815c50aa51")
