-- Lua provided by RyzenAPI 
-- Game: AppID 1648820
addappid(1648820)
addappid(1648821, 1, "54b3ce77411f6351cdf03219021f2f861d5a2a9e3449c99e08b052787dac4bc4")
