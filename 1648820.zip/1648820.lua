-- Lua provided by RyzenAPI
-- Game: addappid(1648820)

-- MAIN APPLICATION
addappid(1648820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648821, 1, "54b3ce77411f6351cdf03219021f2f861d5a2a9e3449c99e08b052787dac4bc4")
