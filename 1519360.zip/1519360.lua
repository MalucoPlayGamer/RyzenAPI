-- Lua provided by SkyAPI 
-- Game: The Legends in Kylamar
addappid(1519360)
addappid(1519361, 1, "fe278c11043c4882888c2669f9955bde0c788b1604157beae7058373084d1ac1")
