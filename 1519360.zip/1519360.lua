-- Lua provided by RyzenAPI
-- Game: Game: The Legends in Kylamar

-- MAIN APPLICATION
addappid(1519360)
-- Game: addappid(1519360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519361, 1, "fe278c11043c4882888c2669f9955bde0c788b1604157beae7058373084d1ac1")
