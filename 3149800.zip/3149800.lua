-- Lua provided by RyzenAPI
-- Game: Game: 勾八公主狂想曲（J8 Princess Rhapsody）

-- MAIN APPLICATION
addappid(3149800)
-- Game: addappid(3149800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3149801, 1, "72f0d5e41945c0d6c83622ae1820e866ecd1ec95f3b88a00ab18cb86da0916f9")
