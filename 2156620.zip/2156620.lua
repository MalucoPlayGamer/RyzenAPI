-- Lua provided by RyzenAPI
-- Game: The Future Radio and the Artificial Pigeons

-- MAIN APPLICATION
addappid(2156620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156621, 1, "a08bee15ef9084adf1203812efcd66f5b48824b889b6093d38f9f38e77e3bbe6")
