-- Lua provided by RyzenAPI
-- Game: 2156620

-- MAIN APPLICATION
addappid(2156620)
-- Game: addappid(2156620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156621, 1, "a08bee15ef9084adf1203812efcd66f5b48824b889b6093d38f9f38e77e3bbe6")
