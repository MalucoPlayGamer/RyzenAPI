-- Lua provided by RyzenAPI
-- Game: Dead Frontier 2

-- MAIN APPLICATION
addappid(744900)
-- Game: addappid(744900)

-- MAIN APP DEPOTS / PACKAGES
addappid(744901, 1, "6c001af4bda0e78ffd4dafd2017db83c50571db2f086cfec5ad36efe7fbd736a")
