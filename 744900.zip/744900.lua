-- Lua provided by RyzenAPI 
-- Game: Dead Frontier 2
addappid(744900)
addappid(744901, 1, "6c001af4bda0e78ffd4dafd2017db83c50571db2f086cfec5ad36efe7fbd736a")
