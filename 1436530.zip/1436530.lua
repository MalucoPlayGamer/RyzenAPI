-- Lua provided by RyzenAPI
-- Game: addappid(1436530)

-- MAIN APPLICATION
addappid(1436530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436531, 1, "a0a76b27b83d7337395fce25b1be6fb6a00913bd92d56360d80da351914b2bc9")
