-- Lua provided by RyzenAPI
-- Game: Game: Lyonesse

-- MAIN APPLICATION
addappid(1685840)
-- Game: addappid(1685840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685841, 1, "0792856db36c0bce0b10da9f075d167a2aee4bfd83d3917edfdaab1586a56daf")
