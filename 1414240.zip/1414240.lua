-- Lua provided by RyzenAPI
-- Game: Evolution of a Mini World: Physics Wonderland

-- MAIN APPLICATION
addappid(1414240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414241, 1, "a40705549d7fcf0ffbdaa3283a62bff8bc59cc17db36d27fba80d8f4ba0ba954")
