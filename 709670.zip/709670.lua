-- Lua provided by SkyAPI 
-- Game: AppID 709670
addappid(709670)
addappid(709671, 1, "56e37efb9f145ddac3b061ce08021f04b88ae9876be30dbcc5f401c10f1a6291")
