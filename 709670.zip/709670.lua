-- Lua provided by RyzenAPI
-- Game: Clarent Saga: Tactics

-- MAIN APPLICATION
addappid(709670)
addappid(1602640)
addappid(1602641)
addappid(1602642)
addappid(1602643)
addappid(1602644)
addappid(1603010)

-- MAIN APP DEPOTS / PACKAGES
addappid(709671, 1, "56e37efb9f145ddac3b061ce08021f04b88ae9876be30dbcc5f401c10f1a6291")

