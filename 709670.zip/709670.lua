-- Lua provided by RyzenAPI
-- Game: Game: AppID 709670

-- MAIN APPLICATION
addappid(709670)
-- Game: addappid(709670)

-- MAIN APP DEPOTS / PACKAGES
addappid(709671, 1, "56e37efb9f145ddac3b061ce08021f04b88ae9876be30dbcc5f401c10f1a6291")
