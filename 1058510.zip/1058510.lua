-- Lua provided by RyzenAPI
-- Game: AppID 1058510

-- MAIN APPLICATION
addappid(1058510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058511, 1, "72921e265aa8a53df9e871a489ad954b1dcedbe3f0a0b3e0fc157a81a204aea9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
