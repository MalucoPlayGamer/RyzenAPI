-- Lua provided by RyzenAPI
-- Game: 1058510

-- MAIN APPLICATION
addappid(1058510)
-- Game: addappid(1058510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058511, 1, "72921e265aa8a53df9e871a489ad954b1dcedbe3f0a0b3e0fc157a81a204aea9")
