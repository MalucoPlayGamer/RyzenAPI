-- Lua provided by RyzenAPI 
-- Game: Quake III Arena
addappid(2200)
addappid(2201, 1, "2258e9896f9aa441c43568358fb59c20b85d6c06a87dec3e7e0ec6ce444d5bb5")
