-- Lua provided by RyzenAPI
-- Game: Game: Quake III Arena

-- MAIN APPLICATION
addappid(2200)
-- Game: addappid(2200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201, 1, "2258e9896f9aa441c43568358fb59c20b85d6c06a87dec3e7e0ec6ce444d5bb5")
