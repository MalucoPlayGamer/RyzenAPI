-- Lua provided by SkyAPI 
-- Game: AppID 2157360
addappid(2157360)
addappid(2157361, 1, "b4917d72c655c59629de499640e14ff017a1033c6abbd9ac0ffd5a334c9c59c6")
