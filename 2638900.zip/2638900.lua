-- Lua provided by RyzenAPI
-- Game: Renovation Plan

-- MAIN APPLICATION
addappid(2638900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638901, 1, "c48370cbf20ed587cbce30cb0a0accda15a733202f86e8c592e0b74f63904a93")
