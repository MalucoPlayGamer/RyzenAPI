-- Lua provided by RyzenAPI
-- Game: Renovation Plan

-- MAIN APPLICATION
addappid(2638900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638901, 1, "c48370cbf20ed587cbce30cb0a0accda15a733202f86e8c592e0b74f63904a93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
