-- Lua provided by RyzenAPI
-- Game: ...Knew the Beginning

-- MAIN APPLICATION
addappid(1882600)
-- Game: addappid(1882600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882601, 1, "09acf5cda544a02b4a1b531b089b5d84fc0fdfa6186a2b0704e9aa493f8c3891")
