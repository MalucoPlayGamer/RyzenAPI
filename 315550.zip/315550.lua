-- Lua provided by RyzenAPI
-- Game: Taxi

-- MAIN APPLICATION
addappid(315550)
-- Game: addappid(315550)

-- MAIN APP DEPOTS / PACKAGES
addappid(315551, 1, "5bae8678a80701fb711f9abb61b866323c38d9ba7f93f669b59532f3e47a45e5")
