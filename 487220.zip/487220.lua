-- Lua provided by RyzenAPI
-- Game: AppID 487220

-- MAIN APPLICATION
addappid(487220)
addappid(830420)

-- MAIN APP DEPOTS / PACKAGES
addappid(487221, 1, "d6954a8f552aecc1c5d73265cadbb5988397adf77e99eb985f7375c4fd5fe72d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(516400)
