-- Lua provided by RyzenAPI
-- Game: Game: I MAED A GAM3 W1TH Z0MB1ES 1NIT!!!1 Soundtrack

-- MAIN APPLICATION
addappid(1844980)
-- Game: addappid(1844980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844981, 1, "f09e7e96f36f46fe8426524133a06a0abe1becfa1939a8171412c130a29a9c72")
addappid(1844982, 1, "ab11b9f3952e4470c0aabbea37d05a6245528a83f3e04ee6fc648aa2b5e4cedd")
