-- Lua provided by RyzenAPI
-- Game: The Disney Afternoon Collection

-- MAIN APPLICATION
addappid(525040)

-- MAIN APP DEPOTS / PACKAGES
addappid(525041, 1, "c665a9c976e42491f17e547559de95ca0965372283e7a3c5eab4c234d9e27be1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
