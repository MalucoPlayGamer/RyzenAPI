-- Lua provided by RyzenAPI
-- Game: The Disney Afternoon Collection

-- MAIN APPLICATION
addappid(525040)

-- MAIN APP DEPOTS / PACKAGES
addappid(525041, 1, "c665a9c976e42491f17e547559de95ca0965372283e7a3c5eab4c234d9e27be1")
