-- Lua provided by RyzenAPI
-- Game: Game: Hexfactory

-- MAIN APPLICATION
addappid(1958750)
-- Game: addappid(1958750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958751, 1, "4ba8d86c0786a48a07408c54f6e641255cd7092b2a804e8a08e88e2b9e3587ee")
