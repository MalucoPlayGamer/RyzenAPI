-- Lua provided by RyzenAPI
-- Game: AppID 2854160

-- MAIN APPLICATION
addappid(2854160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854161, 1, "40cec7ed1af253f34ac7800a526f113a5340974becd2b42afafab0a61d34a52e")
