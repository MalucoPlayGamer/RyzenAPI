-- Lua provided by RyzenAPI
-- Game: Electro Ride Prologue

-- MAIN APPLICATION
addappid(1301990)
-- Game: addappid(1301990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301991, 1, "f8821c11fc3057e043243d5be871f758738ddb9bba0075c85cfc1475940b0662")
