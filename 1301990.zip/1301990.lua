-- Lua provided by SkyAPI 
-- Game: Electro Ride Prologue
addappid(1301990)
addappid(1301991, 1, "f8821c11fc3057e043243d5be871f758738ddb9bba0075c85cfc1475940b0662")
