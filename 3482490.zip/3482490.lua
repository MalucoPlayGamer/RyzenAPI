-- Lua provided by RyzenAPI 
-- Game: Project Gravity
addappid(3482490)
addappid(3482491, 1, "7aa033033d9d377c0517c2cf5fc8b347889d833d5eeaffbf11be37862ab15271")
