-- Lua provided by RyzenAPI 
-- Game: AppID 2316290
addappid(2316290)
addappid(2316291, 1, "a5ed8e55bd5838607f46f73e5f9866d6500bc032eeceb033009443ecc93d02ff")
