-- Lua provided by RyzenAPI
-- Game: 2316290

-- MAIN APPLICATION
addappid(2316290)
-- Game: addappid(2316290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316291, 1, "a5ed8e55bd5838607f46f73e5f9866d6500bc032eeceb033009443ecc93d02ff")
