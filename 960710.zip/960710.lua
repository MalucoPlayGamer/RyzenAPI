-- Lua provided by RyzenAPI
-- Game: DON'T GIVE UP: A Cynical Tale

-- MAIN APPLICATION
addappid(960710)

-- MAIN APP DEPOTS / PACKAGES
addappid(960712,0,"37268060dbdde8d82b38822b3cb1be73b0e41c38c4b23457806e286bcb3eb9f7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1422250)
