-- Lua provided by RyzenAPI
-- Game: Adventures of Dragon

-- MAIN APPLICATION
addappid(770370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(770371, 1, "c6a1251ade4b52ca8a8835a914b89de55b6777da2a9832b436c7594126c0f582")
addappid(770372, 1, "68c29fdec2f3ed45f7323468e3636fb5dccb5da229559f281aa61ced179779fb")
addappid(1003250, 0, "57bb93b053635f9ed97ab928488682448bc91abb0815b7727ea699c96d34e0cf")
addappid(1067680, 0, "43d39afcc817f73055c846c140a54aa7390684e3d85cf5e3dc8fb38afbf0d89d")
