-- Lua provided by RyzenAPI
-- Game: setManifestid(998835,"5952350274008335341")

-- MAIN APPLICATION
addappid(998830)
-- Game: addappid(998830)

-- MAIN APP DEPOTS / PACKAGES
addappid(998835,0,"76bc88eced5b92365ee86148dc720d28368def230e94e895fa3a95686f7aa17c")
