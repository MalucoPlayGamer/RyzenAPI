-- Lua provided by RyzenAPI
-- Game: Game: Part of You

-- MAIN APPLICATION
addappid(1919270)
-- Game: addappid(1919270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919271, 1, "886fe39051190c152d191d2c7727e2436ed8d73b83c943c9432101308f296dc9")
