-- Lua provided by RyzenAPI
-- Game: Part of You

-- MAIN APPLICATION
addappid(1919270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1919271, 1, "886fe39051190c152d191d2c7727e2436ed8d73b83c943c9432101308f296dc9")

