-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Dark Forest

-- MAIN APPLICATION
addappid(1309230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309230,0,"e67c6218c871a08ef27a2527f7433ddf297c296cf858720779636b63f2fd5bce")

