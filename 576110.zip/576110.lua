-- Lua provided by RyzenAPI
-- Game: Game: AppID 576110

-- MAIN APPLICATION
addappid(576110)
-- Game: addappid(576110)

-- MAIN APP DEPOTS / PACKAGES
addappid(576111, 1, "c59efe152698015e001986338d24d3d27e59411288c5b651c950849bd2d7b8e9")
