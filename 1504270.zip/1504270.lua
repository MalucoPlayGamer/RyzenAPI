-- Lua provided by RyzenAPI
-- Game: Napoleon Maiden ~A maiden without the word impossible~

-- MAIN APPLICATION
addappid(1504270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504271, 1, "05190adabd211898bb18774e4da2219f6852ab9a596831206f49ad7bfaa5c0c0")
addappid(2263402, 0, "7ad077994b2c56c6d8a75a771f60ad5d37938843927e0ec981c8ba77f3b26b94")

