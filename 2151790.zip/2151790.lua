-- Lua provided by RyzenAPI
-- Game: The Hermit Chronicles

-- MAIN APPLICATION
addappid(2151790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151791, 1, "a6dc46d11315be0d759afe61ddb289b69aff04b7c35bb7b110932d5170351192")
