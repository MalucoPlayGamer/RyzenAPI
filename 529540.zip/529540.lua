-- Lua provided by RyzenAPI
-- Game: Thread Studio

-- MAIN APPLICATION
addappid(529540)

-- MAIN APP DEPOTS / PACKAGES
addappid(529541, 1, "29912bca7849271a4fc7303923c5efd2d455c7875e21d174a73ed2d8eee8489d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
