-- Lua provided by RyzenAPI
-- Game: Thread Studio

-- MAIN APPLICATION
addappid(529540)

-- MAIN APP DEPOTS / PACKAGES
addappid(529541, 1, "29912bca7849271a4fc7303923c5efd2d455c7875e21d174a73ed2d8eee8489d")

