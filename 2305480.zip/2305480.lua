-- Lua provided by RyzenAPI
-- Game: 觅光：第一章 - Seeking Light : Chapter 1

-- MAIN APPLICATION
addappid(2305480)
addappid(2365930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305481, 1, "923c6ec21301f270123f092a0d9236aebfee12d4ae9209b68e8b325b61d1101d")

