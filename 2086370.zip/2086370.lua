-- Lua provided by RyzenAPI 
-- Game: Super Double Dragon
addappid(2086370)
addappid(2086371, 1, "f761f47f184dfbfee6af0d87ca41520915e1c9ddbfc1c2f225f31aad86798631")
