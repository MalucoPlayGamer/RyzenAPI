-- Lua provided by RyzenAPI
-- Game: Super Double Dragon

-- MAIN APPLICATION
addappid(2086370)
-- Game: addappid(2086370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086371, 1, "f761f47f184dfbfee6af0d87ca41520915e1c9ddbfc1c2f225f31aad86798631")
