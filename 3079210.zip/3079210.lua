-- Lua provided by RyzenAPI
-- Game: hell let loose vietnam

-- MAIN APPLICATION
addappid(3079210) -- pre venda jogo

