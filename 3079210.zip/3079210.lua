-- Lua provided by RyzenAPI
-- Game: Hell Let Loose: Vietnam

-- MAIN APPLICATION
addappid(3079210)
addappid(3079210) -- pre venda jogo
addappid(4447980) -- Field Supply NVA Boat Crew Uniform

-- MAIN APP DEPOTS / PACKAGES
addappid(3079211, 1, "f7eb2462eb25f9a05bb91c0a20e77a6f943af632b06af7d4f2e19dd912176e6c")

