-- Lua provided by RyzenAPI
-- Game: pre venda jogo

-- MAIN APPLICATION
addappid(3079210) -- pre venda jogo

