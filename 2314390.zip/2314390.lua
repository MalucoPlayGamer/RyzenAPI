-- Lua provided by RyzenAPI
-- Game: Game: AppID 2314390

-- MAIN APPLICATION
addappid(2314390)
-- Game: addappid(2314390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314391, 1, "dd501847c1a018fa37d318f0ac228c9b2dbab36e67aa2e996ee62d1df397ec71")
addappid(2314392, 1, "4029b5fa967341a51b60f45818527959c2ebe9585ccaa396709f23ce617a896b")
