-- Lua provided by RyzenAPI
-- Game: DFF NT: Arsenal IV, Bartz Klauser's 4th Weapon Set

-- MAIN APPLICATION
addappid(1022416)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022416,0,"1e584979ea0db0adeb2766b056f58473079a1e80824998f10e1db207d81faa1e")

