-- Lua provided by RyzenAPI
-- Game: 2142870

-- MAIN APPLICATION
addappid(2142870)
addappid(2142880)
-- Game: addappid(2142870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142871, 1, "9efecc77e982aafb89e6d63617f07bb3765df31cb7bec8fcb0d7487fbb21b200")
