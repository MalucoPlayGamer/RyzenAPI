-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - SAM GroundService

-- MAIN APPLICATION
addappid(1952480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952480,0,"5d8fdcd7e1ce4520a7aa1584b735329d13eb6e6ecfacf3f1750e857416d55658")
