-- Lua provided by RyzenAPI
-- Game: Anathyma

-- MAIN APPLICATION
addappid(2624060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624061, 1, "3b7f6e29033d298fefa3b6b0e2ac32ae5668eeadd08ffe63a0be2645d7180751")

