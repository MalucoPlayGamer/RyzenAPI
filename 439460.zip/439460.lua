-- Lua provided by RyzenAPI
-- Game: Ships 2017

-- MAIN APPLICATION
addappid(439460)
-- Game: addappid(439460)

-- MAIN APP DEPOTS / PACKAGES
addappid(439461, 1, "2bd62bf4dc3f2a94f5c7d8ca39e1ffb633a5561b4b594de17f708dfcd24ae8ce")
