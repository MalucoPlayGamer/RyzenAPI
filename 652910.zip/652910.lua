-- Lua provided by RyzenAPI 
-- Game: Delay
addappid(652910)
addappid(652911, 1, "5b820e96cb24ff1eb73299ac83d86996a0a9ab85974da6babaf758a8c87fa187")
