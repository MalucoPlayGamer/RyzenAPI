-- Lua provided by RyzenAPI
-- Game: Rootman Demo

-- MAIN APPLICATION
addappid(2317750)
-- Game: addappid(2317750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317751, 1, "c2b6256c9f3f86189be6d56a617b8be0c285c8bf397b11bbe788e8690a8e4b5c")
