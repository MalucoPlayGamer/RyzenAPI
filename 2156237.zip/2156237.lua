-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2156237)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156237,0,"5c84080aabe7b1efc605722c7aab0f72e20c6cca311556f1a7511987d3d57457")

