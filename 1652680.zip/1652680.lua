-- Lua provided by SkyAPI 
-- Game: GAME.exe
addappid(1652680)
addappid(1652681, 1, "27a9c05be9cc93b5227b1d77c226f5174022cb77f2437a03753cc15706a752bf")
