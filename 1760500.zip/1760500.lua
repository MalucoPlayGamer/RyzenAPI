-- Lua provided by RyzenAPI
-- Game: Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles: Character avatars x 10 (full roster)

-- MAIN APPLICATION
addappid(1760500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760500,0,"07cfb0664655d5544016861463b28175d000e7880ecaea791cc4739c26f8069f")

