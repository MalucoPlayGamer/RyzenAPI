-- Lua provided by RyzenAPI
-- Game: Gabenwood: 99 Hidden Bucks

-- MAIN APPLICATION
addappid(2103710)
-- Game: addappid(2103710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103711, 1, "3a6c67c3b9fbcbe07e9e2df4970db2c022b79fea3d654de39fc64dde4121854c")
