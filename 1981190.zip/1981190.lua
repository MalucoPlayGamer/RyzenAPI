-- Lua provided by RyzenAPI
-- Game: addappid(1981190)

-- MAIN APPLICATION
addappid(1981190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981191, 1, "5a8c5680cea4f62a449f668452f98a57b24f02c7de608f3a4fc86491ca3264fb")
