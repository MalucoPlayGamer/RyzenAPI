-- Lua provided by RyzenAPI
-- Game: Equinox

-- MAIN APPLICATION
addappid(1981190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1981191, 1, "5a8c5680cea4f62a449f668452f98a57b24f02c7de608f3a4fc86491ca3264fb")

