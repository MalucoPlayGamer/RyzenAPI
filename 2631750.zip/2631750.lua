-- Lua provided by RyzenAPI
-- Game: 2631750

-- MAIN APPLICATION
addappid(2631750)
-- Game: addappid(2631750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631751, 1, "fbef009a9a881231b5c7b9946300c04e68cf18f4b2fe86440cd6a27bbfa09105")
