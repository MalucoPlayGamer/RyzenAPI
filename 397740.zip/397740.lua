-- Lua provided by RyzenAPI
-- Game: Game: AppID 397740

-- MAIN APPLICATION
addappid(397740)
-- Game: addappid(397740)

-- MAIN APP DEPOTS / PACKAGES
addappid(397741, 1, "ebbcfcee8fe8358c430edbcf2f68f0feefeaaeefaf266acb9d28fa125049d851")
addappid(397742, 1, "2281ebe2d4eca8c1ba5721aa60349be3faa85e3db67114d2bb72deb927450b3b")
