-- Lua provided by RyzenAPI
-- Game: What Is The Ghost

-- MAIN APPLICATION
addappid(3929260) -- What Is The Ghost

-- MAIN APP DEPOTS / PACKAGES
addappid(3929261, 1, "6975e40046465163650b867a4c8d10e5dba1fb34bfb4f6119e91c7728a68a19a") -- Depot 3929261

