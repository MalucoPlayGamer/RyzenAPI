-- 3929260's Lua and Manifest Created by Hubcap Manifest
-- What Is The Ghost
-- Created: August 07, 2026 at 12:50:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3929260) -- What Is The Ghost
-- MAIN APP DEPOTS
addappid(3929261, 1, "6975e40046465163650b867a4c8d10e5dba1fb34bfb4f6119e91c7728a68a19a") -- Depot 3929261
setManifestid(3929261, "8515940635346882516", 293280496)