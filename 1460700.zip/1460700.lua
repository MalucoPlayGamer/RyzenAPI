-- Lua provided by RyzenAPI
-- Game: 1460700

-- MAIN APPLICATION
addappid(1460700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460702,0,"3de01e5d1c3e1bb1479aeb29362e75f85b2e85ccf1ca7e021b99cdfb363b8b54")

