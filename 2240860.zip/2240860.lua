-- Lua provided by RyzenAPI
-- Game: AppID 2240860

-- MAIN APPLICATION
addappid(2240860)
-- Game: addappid(2240860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240861, 1, "8959e6552e95dedef10cbc8a106a0e68ff64f94f327e5c2431fc037aee1106c1")
