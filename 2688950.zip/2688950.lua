-- Lua provided by RyzenAPI
-- Game: Game: Planet Coaster 2

-- MAIN APPLICATION
addappid(2688950)
addappid(3091180)
addappid(3091190)
addappid(3337040)
addappid(3902620)
-- Game: addappid(2688950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688951, 1, "d1fc4044f8dbec56ccd7ccac0a38810470c5fecf00dedc36a294c39453f9adb0")
