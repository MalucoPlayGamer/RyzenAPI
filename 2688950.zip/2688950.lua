-- Generated with Luie @ https://lua.tools/
-- 2688950 - Planet Coaster 2
-- Generated 2026-08-08 17:04:34 UTC
-- # Depots (Total/DLC/Shared): 6/3/2

-- Main AppID
addappid(2688950, 1, "db80e514e0e23f3ac57084d4e47af67ec4d0d5d3c223d5b918daf8fdc9e73eeb")

-- Main Depots
addappid(2688951, 1, "d1fc4044f8dbec56ccd7ccac0a38810470c5fecf00dedc36a294c39453f9adb0")
setManifestid(2688951, "702010445531950067", 30830122975)

-- DLC's (no depot keys required)
addappid(3091180) -- Planet Coaster 2: Bonus Ride Collection
addappid(3091190) -- Planet Coaster 2: Vintage Funfair Ride Pack
addappid(3337040) -- Planet Coaster 2: Thrill-Seekers Ride Pack
addappid(3902620) -- Planet Coaster 2: Sorcery Pack
addappid(4129920) -- Planet Coaster 2: Toybox Pack
addappid(4492160) -- Planet Coaster 2: Parades Pack

-- DLC's (with depot keys)
-- The Music of Planet Coaster 2: You, Me & Fluidity (AppID: 3299720)
addappid(3299720)
addappid(3299721, 1, "223e20c632bc0347c13db5bf878f388c34d94dbb0ca4f37f1f0f8e2f344535cf")
setManifestid(3299721, "544182693317952126", 1683586480)
addappid(3299722, 1, "8b9708acdf921f3e7152104befd3820d0aaa021112e28516c5a819f3560c460b")
setManifestid(3299722, "7769414947378223114", 1853086457)
addappid(3299723, 1, "88ca1484366b066d82034f67795683103f3e80c8230b9ca98c9bcdb5b98ff867")
setManifestid(3299723, "2377508422711440983", 1871063590)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
