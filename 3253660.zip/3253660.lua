-- Lua provided by RyzenAPI
-- Game: addappid(3253660)

-- MAIN APPLICATION
addappid(3253660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253661, 1, "2d5ac5aaf6e505269fd8588d5a2c301447dbdc33d2d676b131d4a4e3b1269f07")
