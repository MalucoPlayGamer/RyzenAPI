-- Lua provided by RyzenAPI
-- Game: Game: Super Robin

-- MAIN APPLICATION
addappid(1288110)
-- Game: addappid(1288110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288111, 1, "af0499ca178d1f27c91089d2d5f012df31c2818c6a63b2af62fbbf879ebc42a2")
