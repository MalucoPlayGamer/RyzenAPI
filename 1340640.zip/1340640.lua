-- Lua provided by RyzenAPI
-- Game: 1340640

-- MAIN APPLICATION
addappid(1340640)
-- Game: addappid(1340640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340641, 1, "83c5bd6cc2bfc156943de3a99386d601af5d1949d6a39d2ff1d00031a7cc4377")
