-- Lua provided by RyzenAPI
-- Game: International Space Banana

-- MAIN APPLICATION
addappid(1331670)
-- Game: addappid(1331670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331671, 1, "d4316b5950a62e3cfac06620af8c43f6ae0ac0f0e71d7ef619c334de68fdc20d")
