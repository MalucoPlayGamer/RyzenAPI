-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(798860)

-- MAIN APP DEPOTS / PACKAGES
addappid(798860,0,"038527fbfc4b71919808521fb7105da29f56ff8c8e4db34ae6e6101f3b767229")

