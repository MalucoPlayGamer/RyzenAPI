-- Lua provided by RyzenAPI
-- Game: Game: AppID 789610

-- MAIN APPLICATION
addappid(789610)
-- Game: addappid(789610)

-- MAIN APP DEPOTS / PACKAGES
addappid(789611, 1, "f267d61593c774814173e4e7c1f4f5e0143dfc154d6b634bee058885d6569962")
