-- Lua provided by RyzenAPI
-- Game: KILLING A SUPERSTAR

-- MAIN APPLICATION
addappid(1490850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490851, 1, "7d609cfa0b8c5959ba6c802e4ca911669a11407fef8342cc4cc3d976691a5daf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
