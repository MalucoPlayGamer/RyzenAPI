-- Lua provided by RyzenAPI
-- Game: 1490850

-- MAIN APPLICATION
addappid(1490850)
-- Game: addappid(1490850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490851, 1, "7d609cfa0b8c5959ba6c802e4ca911669a11407fef8342cc4cc3d976691a5daf")
