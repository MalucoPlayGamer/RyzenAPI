-- Lua provided by RyzenAPI 
-- Game: Feed the Cups
addappid(2336220)
addappid(2336221, 1, "f3f120d62113945152c4dbc839727429765e41336f99fc3a1e125c5bdf43ec2b")
