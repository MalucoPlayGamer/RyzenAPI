-- Lua provided by RyzenAPI
-- Game: Westworld Awakening

-- MAIN APPLICATION
addappid(1133320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1133321, 1, "21ab639dc4893f5946f43fc15785f6b570f9fd797822caa60a90b5ae67644049")
