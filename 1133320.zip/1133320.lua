-- Lua provided by RyzenAPI
-- Game: Game: AppID 1133320

-- MAIN APPLICATION
addappid(1133320)
-- Game: addappid(1133320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133321, 1, "21ab639dc4893f5946f43fc15785f6b570f9fd797822caa60a90b5ae67644049")
