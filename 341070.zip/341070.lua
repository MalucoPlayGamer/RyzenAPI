-- Lua provided by RyzenAPI
-- Game: Stay Dead Evolution

-- MAIN APPLICATION
addappid(341070)

-- MAIN APP DEPOTS / PACKAGES
addappid(341071, 1, "b27b9546a2e8135aa855241c08b435daf1323849366ae82ae2695407d21359d5")

