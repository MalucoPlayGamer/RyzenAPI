-- Lua provided by RyzenAPI
-- Game: addappid(1099140)

-- MAIN APPLICATION
addappid(1099140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099141, 1, "eb2bdd49e64c9d0bb7bcb960992a61f067c9c8176017f86473860a4afddcc842")
