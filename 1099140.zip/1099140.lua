-- Lua provided by RyzenAPI
-- Game: 她3 : 复乐园之曦 Her3 : The Light of Paradise Regained

-- MAIN APPLICATION
addappid(1099140)
-- Game: addappid(1099140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099141, 1, "eb2bdd49e64c9d0bb7bcb960992a61f067c9c8176017f86473860a4afddcc842")
