-- Lua provided by RyzenAPI
-- Game: Game: Malleus Cocconum: The Heiress

-- MAIN APPLICATION
addappid(2965680)
-- Game: addappid(2965680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2965681, 1, "2e7f4862122d6f42bf27da1535972a33bc69bd0af5ee52a95ac294a17e8b2d04")
