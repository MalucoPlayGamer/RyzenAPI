-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Advanced String Skipping Exercise 2

-- MAIN APPLICATION
addappid(1122579)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122579,0,"da71b95c1598cf19cca31ad556019451bf3d5ad4b563a954ff1b5bb81da17443")

