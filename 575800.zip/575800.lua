-- Lua provided by RyzenAPI
-- Game: Arizona Rose and the Pharaohs' Riddles

-- MAIN APPLICATION
addappid(575800)

-- MAIN APP DEPOTS / PACKAGES
addappid(575801,0,"51423db56371079799b30a102ff5a640695f0f0cb9f66f38333bb804e249be3c")

