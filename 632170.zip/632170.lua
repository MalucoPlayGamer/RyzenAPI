-- Lua provided by RyzenAPI
-- Game: AppID 632170

-- MAIN APPLICATION
addappid(632170)

-- MAIN APP DEPOTS / PACKAGES
addappid(632171, 1, "1b9482f8418efffaeea95321d3ba1a3da3209fac031e1b984aae4929b7329342")
addappid(632172, 1, "28270a5e0b5f022e3d3715322b6da6a40ad6da04b14127387b262f9d30ba664f")
addappid(632173, 1, "49c40b7928565308ca2f11f81a26af8544746f587c25f3faaaa85195f141cc9a")
addappid(726370, 0, "786f2af43cbf760173cd6bbc3a2b11444f48c5053dd66fc0081427e269ad77b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
