-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2310170)
addappid(2310171)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310170,0,"de1463a0a59753f584b197afe4c0009fe068739abf33d6ad83a09cfae4c3d131")

