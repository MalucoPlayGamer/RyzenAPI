-- Lua provided by SkyAPI 
-- Game: Sex Simulator - Girl on Girl
addappid(2352500)
addappid(2352501, 1, "e3a7bae21fe6500401a53e67d580f95c428b9ed0f1aefd44b2fc27223334fbd1")
