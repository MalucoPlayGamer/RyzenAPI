-- Lua provided by RyzenAPI
-- Game: Sex Simulator - Girl on Girl

-- MAIN APPLICATION
addappid(2352500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352501, 1, "e3a7bae21fe6500401a53e67d580f95c428b9ed0f1aefd44b2fc27223334fbd1")
