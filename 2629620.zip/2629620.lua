-- Lua provided by RyzenAPI
-- Game: The Last Man Survivor Demo

-- MAIN APPLICATION
addappid(2629620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629621, 1, "d700736f2d8266470482b910a7cc53f43350c8a26bf98a342fe33915f3efdda4")

