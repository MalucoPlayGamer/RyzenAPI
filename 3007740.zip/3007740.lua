-- Lua provided by RyzenAPI
-- Game: addappid(3007740)

-- MAIN APPLICATION
addappid(3007740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007741, 1, "58513cb992dab32bcd16e84e2a580f53ea76d472b81fa33957ecb742a4813a6d")
