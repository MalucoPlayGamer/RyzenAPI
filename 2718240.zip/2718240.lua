-- Lua provided by SkyAPI 
-- Game: PolyPine
addappid(2718240)
addappid(2718241, 1, "6cc06aeab0483c18060930db7b0b6722950a28806d50052dcddce79ba4f02a14")
