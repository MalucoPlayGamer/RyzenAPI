-- Lua provided by RyzenAPI
-- Game: PolyPine

-- MAIN APPLICATION
addappid(2718240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2718241, 1, "6cc06aeab0483c18060930db7b0b6722950a28806d50052dcddce79ba4f02a14")

