-- Lua provided by RyzenAPI
-- Game: PolyPine

-- MAIN APPLICATION
addappid(2718240)
-- Game: addappid(2718240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718241, 1, "6cc06aeab0483c18060930db7b0b6722950a28806d50052dcddce79ba4f02a14")
