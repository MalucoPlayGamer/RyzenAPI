-- Lua provided by RyzenAPI
-- Game: Femdom Lines

-- MAIN APPLICATION
addappid(1114730)
-- Game: addappid(1114730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114731, 1, "1eebc566394841253e1a2cb417c10075c4029953ba3959593c6121727dab5bc8")
