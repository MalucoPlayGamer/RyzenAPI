-- Lua provided by RyzenAPI
-- Game: Femdom Lines

-- MAIN APPLICATION
addappid(1114730)
addappid(1152930)
addappid(1177560)
addappid(1676230)
addappid(3087520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114730,0,"80b8a16eb37faf4d96c344df8b4f73dc6db7ee052c3260edefbfee4f44eec838")
addappid(1114731,0,"1eebc566394841253e1a2cb417c10075c4029953ba3959593c6121727dab5bc8")

