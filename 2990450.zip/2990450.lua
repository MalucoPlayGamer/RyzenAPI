-- Lua provided by RyzenAPI
-- Game: 2990450

-- MAIN APPLICATION
addappid(2990450)
-- Game: addappid(2990450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990451, 1, "74d43ba22a4ebfd4207f6ced9a77e681312bd52936692f9e07f3029752bf4a9e")
