-- Lua provided by RyzenAPI
-- Game: 泡沫冬景

-- MAIN APPLICATION
addappid(1049100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049101, 1, "c71eca367a831a038455f535c347297f4c321b91bb6db15918db9e557737eec0")
addappid(1049102, 1, "8a2b27144f91509b38a2e0fa2ba9af5d7f7bbdafd14ff348b000772b87994181")
addappid(1049103, 1, "579fb5ecbb28623db8380b22bcc78770d91c4000ae03aa00a184691c8759f712")
addappid(1049104, 1, "40bf682876ddf4178357f89f9875ed8194f379dd1092e0947a82350b52c82d5c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1424830)
addappid(1506340)
