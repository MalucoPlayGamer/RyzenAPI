-- Lua provided by RyzenAPI
-- Game: ANIMAL WELL

-- MAIN APPLICATION
addappid(813230)
-- Game: addappid(813230)

-- MAIN APP DEPOTS / PACKAGES
addappid(813231, 1, "bb42c41063ff494ceca8a0ce69218fcc97cc5f31c2066992f80ec8dab229486e")
