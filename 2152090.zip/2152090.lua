-- Lua provided by SkyAPI 
-- Game: My Futanari Stepmom Impregnated Me
addappid(2152090)
addappid(2152091, 1, "0e66f88c21ba8a5502a29b4273f7242683eeaf379d8f63b98dd33d9302d84922")
