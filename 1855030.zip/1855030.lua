-- Lua provided by SkyAPI 
-- Game: Stairway to Heaven's Gate
addappid(1855030)
addappid(1855031, 1, "2e4e7cf554fdb88e470bda2446e725757a27c34ee894e5e65c12300478294ada")
addappid(1855032, 1, "5c75bb370e05f3f034c2ae87508d6861e9a0c990531ed3b7afbab7c0c9cda064")
