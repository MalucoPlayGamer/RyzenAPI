-- Lua provided by RyzenAPI
-- Game: Stairway to Heaven's Gate

-- MAIN APPLICATION
addappid(1855030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1855031, 1, "2e4e7cf554fdb88e470bda2446e725757a27c34ee894e5e65c12300478294ada")
addappid(1855032, 1, "5c75bb370e05f3f034c2ae87508d6861e9a0c990531ed3b7afbab7c0c9cda064")

