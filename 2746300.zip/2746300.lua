-- Lua provided by RyzenAPI
-- Game: AppID 2746300

-- MAIN APPLICATION
addappid(2746300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746301, 1, "adb2e356a5c89abb3c64b9a7da97e25a506bc9a2486eec5a9681b597813ba770")
