-- Lua provided by RyzenAPI
-- Game: 2078960

-- MAIN APPLICATION
addappid(2078960)
-- Game: addappid(2078960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078962,0,"2d4d088376078e86c78efe40e3240a8cdf2ecceab4ce1c45fc89fcec34019963")
