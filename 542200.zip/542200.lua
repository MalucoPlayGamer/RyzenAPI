-- Lua provided by RyzenAPI 
-- Game: Animal Lover
addappid(542200)
addappid(542201, 1, "24428ffc643c4768f0ff166d40b58ff445408627b6fc5c613b72d9a1786ec63b")
addappid(542202, 1, "b0d9ed7ace2dff888634dd2ff72c07d8dea6eaee126d6834ab275f7a534a974c")
addappid(542203, 1, "9d3180274ca7b33b02671cb60f0cb3ad3501f4a43ffdfb73525e937bef797c8e")
