-- Lua provided by RyzenAPI
-- Game: 2085890

-- MAIN APPLICATION
addappid(2085890)
-- Game: addappid(2085890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085892,0,"8dd5852fd9fa1b73983339c4ed9c3d8798718ec9be460770d8788f381def9a92")
