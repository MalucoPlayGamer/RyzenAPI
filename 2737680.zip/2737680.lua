-- Lua provided by RyzenAPI
-- Game: Blast Hopper

-- MAIN APPLICATION
addappid(2737680)
-- Game: addappid(2737680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737681, 1, "00f132d089e1ade0315382109358f0119bf025a197872a054f98445428269cb8")
