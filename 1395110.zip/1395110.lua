-- Lua provided by SkyAPI 
-- Game: Cavity Busters Soundtrack
addappid(1395110)
addappid(1395111, 1, "b7568478cdc5368a8587f1c7b4819b1578e0fe68e83d9b18c17d7f1b7325911c")
addappid(1395112, 1, "c4e57beda4a4c49707e4ccc44f477c960473a5481a91548d4dd3a7f7539bff82")
