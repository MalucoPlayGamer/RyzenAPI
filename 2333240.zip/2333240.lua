-- Lua provided by SkyAPI 
-- Game: Logic Town
addappid(2333240)
addappid(2333241, 1, "5067770f6ae0f95c9b6c031d5ad2f54990ead17f61f6c919f622bcbe401fd9af")
