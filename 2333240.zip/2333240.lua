-- Lua provided by RyzenAPI
-- Game: Logic Town

-- MAIN APPLICATION
addappid(2333240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333241, 1, "5067770f6ae0f95c9b6c031d5ad2f54990ead17f61f6c919f622bcbe401fd9af")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2703380)
addappid(2763580)
addappid(2829390)
addappid(3244260)
addappid(4742980)
