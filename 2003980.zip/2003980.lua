-- Lua provided by RyzenAPI
-- Game: Game: Under Contract Demo

-- MAIN APPLICATION
addappid(2003980)
-- Game: addappid(2003980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003981, 1, "2a5ba0f751fa053d4950c8af158049236acef1f645960d25558ce1d030931594")
