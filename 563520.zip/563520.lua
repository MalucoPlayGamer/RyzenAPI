-- Lua provided by RyzenAPI
-- Game: addappid(563520)

-- MAIN APPLICATION
addappid(563520)
addappid(563521)
addappid(563523)
addappid(581830)
addappid(581831)

-- MAIN APP DEPOTS / PACKAGES
addappid(563522,0,"5f2569f18e9595838d8b5bac0e39b54f2ef68f192eb8cade2e21c3f3b9aee3cc")
