-- Lua provided by RyzenAPI
-- Game: Brink of Consciousness: The Lonely Hearts Murders

-- MAIN APPLICATION
addappid(327370)

-- MAIN APP DEPOTS / PACKAGES
addappid(327371, 1, "5dd6933e1d3cdc175d745756c2d4658e8dd236214b315fa6019dab65be6e6f54")
addappid(327372, 1, "36e330b79059f769c354ff7dd77d3afc5ce65544085aaf437c1fd803f2a1bc0d")
addappid(327373, 1, "31db18b35450b161ff9b56676000ff794df0d6e246b2c5d4564bfaab4f992649")
addappid(327374, 1, "cef7ec2e248eb14ad995fe517f2bcd62f7bfccc34af029924ba6f1394d79e495")
addappid(327375, 1, "13a9b23b6af49d8859b34ebc13a6a0e6b156c6b8ba7ae8eb475630c025228b72")
addappid(327376, 1, "133eda45370ef3aa3955df826020b0bcb39e4421d4de8fed2dee1e0e17c30153")
addappid(327377, 1, "2e27f7c6c1299fcf46f98aafa506c048f9236e0186888a59f9b36d8d1b70e243")
addappid(327378, 1, "dcb1adcf5a2eed96ab20392ff05f59508f5831fa773154e19db2f08ea7d2a8ce")
addappid(327379, 1, "101ddcba344a2c3607f1d12fcb571a99ba62fc76c2c5bce31b362c9981f9c5e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
