-- Lua provided by RyzenAPI
-- Game: 397730

-- MAIN APPLICATION
addappid(397730)
-- Game: addappid(397730)

-- MAIN APP DEPOTS / PACKAGES
addappid(397731, 1, "766fd7c19dc1ece7de0a4ed051dc0e00cb52a82bdb3cab271b4d60c6c0e37761")
addappid(397732, 1, "1ea251d35b8bbd547049df7f58087f7ed672c426407a12841e6df0ef4531566f")
addappid(397733, 1, "b3bbc6fa0315989b575631577500e4059998f1d58c5d9adbbcf623e4bfd06771")
