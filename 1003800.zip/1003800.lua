-- Lua provided by RyzenAPI
-- Game: Gang Beasts Soundtrack

-- MAIN APPLICATION
addappid(1003800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003800,0,"bb91c8306d8c387437df923dc41555bf8dd18b89313125e483ee022fa1a77c73")

