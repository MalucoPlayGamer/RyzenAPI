-- Lua provided by RyzenAPI
-- Game: Panmorphia

-- MAIN APPLICATION
addappid(1421690)
addappid(1421691)
addappid(1421693)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421692,0,"75848df18d0aa6d895d2b8beed3648db5b535b7a8d9964f5908d727b64dbb472")

