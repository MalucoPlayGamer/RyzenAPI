-- Lua provided by RyzenAPI
-- Game: addappid(2387400)

-- MAIN APPLICATION
addappid(2387400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387401, 1, "eca2560f8aaaebefbeca00dd18f274e82436fadda9a580ea44a8051fb805c7a2")
