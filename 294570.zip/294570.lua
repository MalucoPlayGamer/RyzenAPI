-- Lua provided by RyzenAPI
-- Game: addappid(294570)

-- MAIN APPLICATION
addappid(294570)
addappid(303050)
addappid(303051)
addappid(303052)
addappid(303053)
addappid(303054)
addappid(303055)
addappid(303056)
addappid(303057)
addappid(303058)
addappid(303059)
addappid(303060)
addappid(303061)
addappid(303062)
addappid(303063)

-- MAIN APP DEPOTS / PACKAGES
addappid(294571, 1, "a7fd7ca85c7caf055d33a91422b7346b7cf2fa5c4bec68010f497b9216e7964c")
addappid(294574, 1, "3c194a505d7a5d62ffa159573b3bcad9bba3563b0a5a29037b315494d100224e")
addappid(294575, 1, "ceb589222bf0da29496b093f4dfbbba49b729b7228c41fe69ed406b468c18f13")
