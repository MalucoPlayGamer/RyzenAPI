-- Lua provided by RyzenAPI
-- Game: addappid(484890)

-- MAIN APPLICATION
addappid(484890)

-- MAIN APP DEPOTS / PACKAGES
addappid(484891, 1, "edc390d5c005217570013909b7f32bfaaa55f73302b399418fa0e60a99ccd6a3")
