-- Lua provided by RyzenAPI
-- Game: 1566090

-- MAIN APPLICATION
addappid(1566090)
-- Game: addappid(1566090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566091, 1, "0fe3693ff1f5c6c91a4633b6e27de8b9daf1a08c17d5998ded16e6949e75b239")
