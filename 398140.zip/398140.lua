-- Lua provided by RyzenAPI
-- Game: Game: AppID 398140

-- MAIN APPLICATION
addappid(398140)
-- Game: addappid(398140)

-- MAIN APP DEPOTS / PACKAGES
addappid(398141, 1, "e2697cec90638b875b1f8bf1724b70b4f1295a463aa2e05c0f5e5d1f6dee1b83")
