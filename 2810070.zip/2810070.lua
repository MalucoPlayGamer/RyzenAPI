-- Lua provided by RyzenAPI
-- Game: 2810070

-- MAIN APPLICATION
addappid(2810070)
-- Game: addappid(2810070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810071, 1, "d2039db98e9110ca1556fba909d73487a36f913fe0c41b6573ca84ce03004d73")
