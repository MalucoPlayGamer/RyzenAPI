-- Lua provided by RyzenAPI
-- Game: Luckitown

-- MAIN APPLICATION
addappid(1872790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872791, 1, "be0b16b969e62ffb6f18dd43d03c60e30bd945952b4c74577b76d6679bf6b19e")
addappid(1872792, 1, "877d508e1bc6a777ce82182582e6e7135fe5a3bf376f44ad06e618fb9de85a36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
