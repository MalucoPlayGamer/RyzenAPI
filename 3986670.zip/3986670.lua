-- Lua provided by RyzenAPI
-- Game: YOU ARE THE MONSTER

-- MAIN APPLICATION
addappid(3986670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3986671, 1, "da79273f8c824218157edead4edc72d3bac399aa0cd69d55389f57eba17041c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
