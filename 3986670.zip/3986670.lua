-- Lua provided by RyzenAPI
-- Game: Game: YOU ARE THE MONSTER

-- MAIN APPLICATION
addappid(3986670)
-- Game: addappid(3986670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3986671, 1, "da79273f8c824218157edead4edc72d3bac399aa0cd69d55389f57eba17041c8")
