-- Lua provided by RyzenAPI
-- Game: Breakers Collection

-- MAIN APPLICATION
addappid(1786230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1786231, 1, "82fa61c2c0428be1d394a8b1f1c6537e39f90bb4c09b536ab43793ef2ed7e5f9")

