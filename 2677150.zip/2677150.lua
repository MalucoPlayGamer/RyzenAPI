-- Lua provided by SkyAPI 
-- Game: MAZE
addappid(2677150)
addappid(2677151, 1, "bcfe94b353145ab788270d91be587718a64df4770f3364152af2b4f7ada6a0ec")
