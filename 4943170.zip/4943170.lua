-- Lua provided by RyzenAPI
-- Game: Catetris

-- MAIN APPLICATION
addappid(4943170) -- Catetris

-- MAIN APP DEPOTS / PACKAGES
addappid(4943171, 1, "f2137b657702d66ea4d9d325822e8f754b68dad4ff80962265ba92ad0eacb5fa") -- Depot 4943171

