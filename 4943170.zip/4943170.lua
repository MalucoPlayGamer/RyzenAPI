-- 4943170's Lua and Manifest Created by Hubcap Manifest
-- Catetris
-- Created: August 08, 2026 at 22:55:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4943170) -- Catetris
-- MAIN APP DEPOTS
addappid(4943171, 1, "f2137b657702d66ea4d9d325822e8f754b68dad4ff80962265ba92ad0eacb5fa") -- Depot 4943171
setManifestid(4943171, "8885965286588497091", 187092837)