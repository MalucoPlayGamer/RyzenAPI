-- Lua provided by RyzenAPI
-- Game: Skool Daze Reskooled

-- MAIN APPLICATION
addappid(524430)

-- MAIN APP DEPOTS / PACKAGES
addappid(524431,0,"49cbbe2697382d0b9c25d7fd4e69c946e004e7c2e549a24734951d458098e4f3")

