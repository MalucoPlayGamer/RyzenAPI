-- Lua provided by RyzenAPI
-- Game: Game: AppID 1689030

-- MAIN APPLICATION
addappid(1689030)
-- Game: addappid(1689030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689031, 1, "834eba57315d825c6d54768b946221ce3dbcd8a1475521827d189683bc30f1cf")
