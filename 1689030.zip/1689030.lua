-- Lua provided by RyzenAPI
-- Game: VR Eagles of Victorian England

-- MAIN APPLICATION
addappid(1689030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1689031, 1, "834eba57315d825c6d54768b946221ce3dbcd8a1475521827d189683bc30f1cf")
