-- Lua provided by RyzenAPI 
-- Game: AppID 1689030
addappid(1689030)
addappid(1689031, 1, "834eba57315d825c6d54768b946221ce3dbcd8a1475521827d189683bc30f1cf")
