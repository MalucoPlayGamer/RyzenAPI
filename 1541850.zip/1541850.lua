-- Lua provided by RyzenAPI
-- Game: Endless Furry Clicker

-- MAIN APPLICATION
addappid(1541850)
-- Game: addappid(1541850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541851, 1, "d6ae5e60cbb4995cb00ca1ce56847f5bda80d668caf27b682668389c785a5713")
