-- Lua provided by RyzenAPI
-- Game: 405860

-- MAIN APPLICATION
addappid(405860)
-- Game: addappid(405860)

-- MAIN APP DEPOTS / PACKAGES
addappid(405861, 1, "0fad2e99ebd321b7a1f5833a324bce27a03692e353ce30a7132dadece8b0cb44")
