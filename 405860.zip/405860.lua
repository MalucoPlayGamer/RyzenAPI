-- Lua provided by SkyAPI 
-- Game: Super Ubie Island REMIX
addappid(405860)
addappid(405861, 1, "0fad2e99ebd321b7a1f5833a324bce27a03692e353ce30a7132dadece8b0cb44")
