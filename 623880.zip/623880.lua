-- Lua provided by RyzenAPI 
-- Game: AppID 623880
addappid(623880)
addappid(623881, 1, "a9962c1007a204ea625b9d54a04738d2c1b2651810de0a69dc561e30fd99c5d5")
