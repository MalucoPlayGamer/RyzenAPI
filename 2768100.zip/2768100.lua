-- Lua provided by RyzenAPI
-- Game: Slendrina Remake

-- MAIN APPLICATION
addappid(2768100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768102,0,"444466645bcb08e81e589e4fcf995b3839c6b2c5db0ad8320e2876a183e5da51")

