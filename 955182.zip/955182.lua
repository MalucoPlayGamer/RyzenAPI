-- Lua provided by RyzenAPI
-- Game: Shan Gui II OST

-- MAIN APPLICATION
addappid(955182)

-- MAIN APP DEPOTS / PACKAGES
addappid(955182,0,"ee5834cb7f0bfad52314134827631666add0aa01434815bbfed9f00c885f2277")
addappid(1227840,0,"0a181f8418f8f9c3b9d74d645a0aa18631bfbb5a1befa9598182ca79faaed16f")

