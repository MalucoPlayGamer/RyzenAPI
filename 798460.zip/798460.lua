-- Lua provided by RyzenAPI
-- Game: Ni no Kuni Wrath of the White Witch™ Remastered

-- MAIN APPLICATION
addappid(798460)

-- MAIN APP DEPOTS / PACKAGES
addappid(798461, 1, "939a224755dc4c5c3580d0d9f2a8849d836222a4ab25e078137d82cb619b4c70")
addappid(798462, 1, "d858c296b49663598e7424076ee6b7079a789856f1f3e944e9997a52c965b307")
addappid(1154000, 0, "8ce42d40489dd4eb6b3e1fc33a88f87687751d03d5f4a56e6d79ac2d852f919b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
