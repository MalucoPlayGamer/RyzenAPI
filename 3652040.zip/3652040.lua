-- Lua provided by RyzenAPI
-- Game: 3652040

-- MAIN APPLICATION
addappid(3652040)
-- Game: addappid(3652040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652041, 1, "912e1b7cac0b8521f909ecd23d51d11a2e9d7b27e597cfa2db2ffd889af53d7e")
