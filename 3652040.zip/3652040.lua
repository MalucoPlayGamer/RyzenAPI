-- Lua provided by SkyAPI 
-- Game: ALWAYS: ILL
addappid(3652040)
addappid(3652041, 1, "912e1b7cac0b8521f909ecd23d51d11a2e9d7b27e597cfa2db2ffd889af53d7e")
