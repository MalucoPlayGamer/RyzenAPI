-- Lua provided by RyzenAPI
-- Game: ALWAYS: ILL

-- MAIN APPLICATION
addappid(3652040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652041, 1, "912e1b7cac0b8521f909ecd23d51d11a2e9d7b27e597cfa2db2ffd889af53d7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
