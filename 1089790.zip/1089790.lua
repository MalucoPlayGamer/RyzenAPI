-- Lua provided by RyzenAPI 
-- Game: Winter Resort Simulator
addappid(1089790)
addappid(1089791, 1, "c7cfd0362a6faf917cf564bc5f978931ad96e584f8fe0b0a72878d3f3977dc69")
addappid(1294390)
