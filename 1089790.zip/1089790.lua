-- Lua provided by RyzenAPI
-- Game: Winter Resort Simulator

-- MAIN APPLICATION
addappid(1089790)
addappid(1294390)
-- Game: addappid(1089790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089791, 1, "c7cfd0362a6faf917cf564bc5f978931ad96e584f8fe0b0a72878d3f3977dc69")
