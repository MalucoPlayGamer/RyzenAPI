-- Lua provided by RyzenAPI
-- Game: addappid(437060)

-- MAIN APPLICATION
addappid(437060)
addappid(437061)
addappid(437062)
addappid(437063)

-- MAIN APP DEPOTS / PACKAGES
addappid(437064,0,"699d18d99a786a33f6071d08158d8bc3b0e0c1674978e1c379b052709680e674")
