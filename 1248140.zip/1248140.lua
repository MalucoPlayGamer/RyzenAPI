-- Lua provided by RyzenAPI
-- Game: Game: AppID 1248140

-- MAIN APPLICATION
addappid(1248140)
-- Game: addappid(1248140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248141, 1, "6f7555279c3c9d02676d7a25c0e26ab8f39a65403cbf571cdef694852e099bfe")
