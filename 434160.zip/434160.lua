-- Lua provided by RyzenAPI
-- Game: A Hole New World

-- MAIN APPLICATION
addappid(434160)
addappid(602260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(434161, 1, "fb47c1aae9ad39c681268de241a572bcc4df2fd068b73bdd7ac8e6eade66c9b6")
