-- Lua provided by RyzenAPI
-- Game: 434160

-- MAIN APPLICATION
addappid(434160)
-- Game: addappid(434160)

-- MAIN APP DEPOTS / PACKAGES
addappid(434161, 1, "fb47c1aae9ad39c681268de241a572bcc4df2fd068b73bdd7ac8e6eade66c9b6")
