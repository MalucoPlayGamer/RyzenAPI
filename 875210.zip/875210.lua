-- Lua provided by RyzenAPI
-- Game: Game: Kingdom Heroes 8

-- MAIN APPLICATION
addappid(875210)
-- Game: addappid(875210)

-- MAIN APP DEPOTS / PACKAGES
addappid(875211, 1, "4aa89c448d1281e001b634e03ae51f7a4596985c8cd37c23ad16c077713acaf0")
addappid(1453620, 0, "dafaacf59d76fbc1d4e0324c0126b43b84d7e8c6361be6cfe95e51fbe77be95a")
addappid(1711770, 0, "6f85df8ddfb8699c8e7544955e338b1e918c9e41088d521f6f2666349a0a2734")
addappid(1711771, 0, "58b988a451b2a098a289ac08b7cf9b71eb778ca472e79c58fdede2915cad54dd")
addappid(1711772, 0, "3c95f8ca1eeb141514f011e1da645b0fdb9f1ae429f62c9af3b9c61eb27cf7a6")
addappid(1711773, 0, "744dbf2497c1a0269f8f7bfad8b7c95e52980f42562702f603625be77032db68")
