-- Lua provided by RyzenAPI
-- Game: 1123190

-- MAIN APPLICATION
addappid(1123190)
-- Game: addappid(1123190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123191, 1, "c6b56896cdd5c17ac19dbcf81194462ec9b544d3c7230f9e454572bc2dbcbeb1")
