-- Lua provided by RyzenAPI
-- Game: Maggie's Apartment

-- MAIN APPLICATION
addappid(652950)

-- MAIN APP DEPOTS / PACKAGES
addappid(652951,0,"bdb19c6ed1d34b310716ab66e4243c8f7424f08ba1369754de0ea10a2eb8bab5")

