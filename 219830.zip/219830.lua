-- Lua provided by RyzenAPI
-- Game: King Arthur's Gold

-- MAIN APPLICATION
addappid(219830)
addappid(228988)
addappid(640900)
addappid(894670)
addappid(1140690)

-- MAIN APP DEPOTS / PACKAGES
addappid(219831, 1, "9d780caa23fc0766cb83471cb789817fc380ea3585e7789667537071ff2b7647")
addappid(219833, 1, "94ea56defd8bfe40ec5f1626f63ff477f4d9f1a1fe60166c317a068712a2bc7f")

