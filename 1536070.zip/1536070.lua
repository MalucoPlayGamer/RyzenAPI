-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 3

-- MAIN APPLICATION
addappid(1536070)
-- Game: addappid(1536070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536071, 1, "d6a2c59ffe5243d02fbc55ef55217326f18f564b24dd632e350e6f4a59807a09")
addappid(1536072, 1, "588c27050d63460ef9d7025133c2158a2eb7845d17a11af23dce0f3e8f0e076a")
addappid(1536073, 1, "166136fe87d653f76a3d9c01ba93850089347dfe0aeefc76389aaeceaa353254")
