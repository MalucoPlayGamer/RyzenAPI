-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 3

-- MAIN APPLICATION
addappid(1536070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536071, 1, "d6a2c59ffe5243d02fbc55ef55217326f18f564b24dd632e350e6f4a59807a09")
addappid(1536072, 1, "588c27050d63460ef9d7025133c2158a2eb7845d17a11af23dce0f3e8f0e076a")
addappid(1536073, 1, "166136fe87d653f76a3d9c01ba93850089347dfe0aeefc76389aaeceaa353254")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
