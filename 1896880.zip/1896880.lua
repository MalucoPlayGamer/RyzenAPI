-- Lua provided by RyzenAPI
-- Game: AppID 1896880

-- MAIN APPLICATION
addappid(1896880)
-- Game: addappid(1896880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896881, 1, "eee5fd4badf6f1eb939642254cce90c8c9cf3a8e60dc3458e4e941f4b0067952")
