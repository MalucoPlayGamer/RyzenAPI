-- Lua provided by SkyAPI 
-- Game: AppID 778420
addappid(778420)
addappid(778421, 1, "7c6ddfb05d9a76899e9379a949f363c0916827b1bd1612b433198f58ab28e0b7")
