-- Lua provided by RyzenAPI
-- Game: 778420

-- MAIN APPLICATION
addappid(778420)
-- Game: addappid(778420)

-- MAIN APP DEPOTS / PACKAGES
addappid(778421, 1, "7c6ddfb05d9a76899e9379a949f363c0916827b1bd1612b433198f58ab28e0b7")
