-- Lua provided by RyzenAPI
-- Game: Soulfire

-- MAIN APPLICATION
addappid(822800)
addappid(1155140)

-- MAIN APP DEPOTS / PACKAGES
addappid(822801, 1, "89f505034b86d2fac64609341be5608b5797ea954618ad267502510a9cfd1480")
