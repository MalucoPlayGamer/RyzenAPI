-- Lua provided by SkyAPI 
-- Game: Soulfire
addappid(822800)
addappid(822801, 1, "89f505034b86d2fac64609341be5608b5797ea954618ad267502510a9cfd1480")
addappid(1155140)
