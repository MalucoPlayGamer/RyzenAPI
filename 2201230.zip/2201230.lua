-- Lua provided by RyzenAPI
-- Game: Belial Red

-- MAIN APPLICATION
addappid(2201230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201231, 1, "7e6c67e1c7eeeb679773c30c3d90a3bb04074ddf6ab52971d1272286db0a7efb")
addappid(2201232, 1, "f14f6661f088e51ed5b13fc3c60808bc4f97a280dfe3f2a9ce589bc5e953dd00")
addappid(2201233, 1, "d075dcac859fddd6c617a00dd24b588b4aa9daf79adcd60353db1d5febd31dc7")
