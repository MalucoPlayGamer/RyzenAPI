-- Lua provided by RyzenAPI
-- Game: AppID 927250

-- MAIN APPLICATION
addappid(927250)
-- Game: addappid(927250)

-- MAIN APP DEPOTS / PACKAGES
addappid(927251, 1, "ba4a15f7ef47c5d874e4f760635057c9b63834e78d51c2c9cede15ca7331755a")
addappid(1020880, 0, "7c9a7c9e857e2ef331ae8473e69babd2152de1f19ab8c05e44a729d58501cea8")
