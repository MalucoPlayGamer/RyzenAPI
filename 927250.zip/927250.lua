-- Lua provided by RyzenAPI
-- Game: Bladed Fury

-- MAIN APPLICATION
addappid(927250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(927251, 1, "ba4a15f7ef47c5d874e4f760635057c9b63834e78d51c2c9cede15ca7331755a")
addappid(1020880, 0, "7c9a7c9e857e2ef331ae8473e69babd2152de1f19ab8c05e44a729d58501cea8")

