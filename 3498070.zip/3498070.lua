-- Lua provided by RyzenAPI
-- Game: Spring Adventure

-- MAIN APPLICATION
addappid(3498070)
-- Game: addappid(3498070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3498071, 1, "023c5210b89c185b311f8fa5801906339b6c56964b3089a4f5bf9c64319c5824")
