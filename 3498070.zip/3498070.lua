-- Lua provided by RyzenAPI
-- Game: Spring Adventure

-- MAIN APPLICATION
addappid(3498070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3498071, 1, "023c5210b89c185b311f8fa5801906339b6c56964b3089a4f5bf9c64319c5824")

