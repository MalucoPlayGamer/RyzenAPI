-- Lua provided by RyzenAPI
-- Game: Aim Climb

-- MAIN APPLICATION
addappid(1909770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909771, 1, "d37b0f6242b0ba5c60fc37ed28b6078957618ffcd9dcda07a0dff26608cc87cc")

