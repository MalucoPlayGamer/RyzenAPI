-- Lua provided by SkyAPI 
-- Game: Aim Climb
addappid(1909770)
addappid(1909771, 1, "d37b0f6242b0ba5c60fc37ed28b6078957618ffcd9dcda07a0dff26608cc87cc")
