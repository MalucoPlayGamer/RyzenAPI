-- Lua provided by RyzenAPI
-- Game: Pixelshire Demo

-- MAIN APPLICATION
addappid(2130840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130841, 1, "46ffa1af9984c6253ffee3315246441490602d760391c1396e028e94ff07b32e")

