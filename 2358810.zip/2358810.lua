-- Lua provided by SkyAPI 
-- Game: FurryFury Soundtrack
addappid(2358810)
addappid(2358811, 1, "159e1f7cecd43a493b6089f4ae0e77b008eac174ffcd6d779d0658760b5e478b")
