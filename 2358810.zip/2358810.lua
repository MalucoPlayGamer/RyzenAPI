-- Lua provided by RyzenAPI
-- Game: Game: FurryFury Soundtrack

-- MAIN APPLICATION
addappid(2358810)
-- Game: addappid(2358810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358811, 1, "159e1f7cecd43a493b6089f4ae0e77b008eac174ffcd6d779d0658760b5e478b")
