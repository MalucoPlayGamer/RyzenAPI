-- Lua provided by RyzenAPI
-- Game: addappid(383380)

-- MAIN APPLICATION
addappid(383380)

-- MAIN APP DEPOTS / PACKAGES
addappid(383380,0,"555e59e18e15a2e8223f544722ef50516c7a1cc40ae77e9c4a18c1fb0c9f1c29")
