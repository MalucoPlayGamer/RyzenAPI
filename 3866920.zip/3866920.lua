-- Lua provided by RyzenAPI
-- Game: NAMAKORIUM

-- MAIN APPLICATION
addappid(3866920)
addappid(4583220)
addappid(4588240)
addappid(4650760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3866921,0,"3ac23f9360831b550bbb1310fc095bb1d2255a9eb8618a280b410d697e274cbb")

