-- Lua provided by RyzenAPI
-- Game: Spacebourne

-- MAIN APPLICATION
addappid(732240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(732241, 1, "cc8fe4dfc2c21305ef69a1039581d322146765bcd0d210db37e54e8e9dce9383")

