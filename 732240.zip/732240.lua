-- Lua provided by RyzenAPI
-- Game: addappid(732240)

-- MAIN APPLICATION
addappid(732240)

-- MAIN APP DEPOTS / PACKAGES
addappid(732241, 1, "cc8fe4dfc2c21305ef69a1039581d322146765bcd0d210db37e54e8e9dce9383")
