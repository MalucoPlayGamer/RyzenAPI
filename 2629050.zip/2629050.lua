-- Lua provided by RyzenAPI
-- Game: Bistro Blitz

-- MAIN APPLICATION
addappid(2629050)
-- Game: addappid(2629050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629051, 1, "5374b9d34d486e8c627cccf5d65d473a9e85b9b1b293d0447b34de538c7bafb6")
