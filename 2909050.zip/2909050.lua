-- Lua provided by RyzenAPI
-- Game: Game: poker dungeon

-- MAIN APPLICATION
addappid(2909050)
-- Game: addappid(2909050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909051, 1, "47fb4e9715870b10becf3ee0f964a4c43cf4c62be073aa4fe7a5ea88292cf43e")
