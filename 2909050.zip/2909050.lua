-- Lua provided by RyzenAPI
-- Game: poker dungeon

-- MAIN APPLICATION
addappid(2909050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909051, 1, "47fb4e9715870b10becf3ee0f964a4c43cf4c62be073aa4fe7a5ea88292cf43e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
