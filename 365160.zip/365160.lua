-- Lua provided by RyzenAPI
-- Game: Kona

-- MAIN APPLICATION
addappid(365160)

-- MAIN APP DEPOTS / PACKAGES
addappid(365161, 1, "6e648d8138fee29cc7123f85315e157e4ebc91e9a4441cae3bf74455ab9d9619")
addappid(365162, 1, "6ba0f45e26a469a04ecee397faa014fd825870980dfce1a9e641b958a47e12c1")
addappid(365163, 1, "efb0753775218c0e8125413c981d847dc8e21f2e097bc5bf235178ea50b55306")
addappid(365164, 1, "b8a2c3cf47bde24a8945d30e04b3ee93bc626b2ceb3ee6a2f7973423522a9bdf")
addappid(365165, 1, "ddc135814bf538a37bdcade378112cfeb237fcef3e59d4f4ea10dd86a92a680d")
addappid(365166, 1, "1e62a78932b4cb7bafb34ad2cad2730bce48bec46ce41d68d4601d77dfbff2d3")
addappid(612650, 0, "a30261d85fc8e5d301bd89ce88db33e200eb86816ea1bde15f77314474bfab70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(886280)
