-- Lua provided by RyzenAPI 
-- Game: HardAF
addappid(2679880)
addappid(2679881, 1, "41fc9d080fe16bb923fbf2510ab7f97521b859b6e527af637faa6e7e840f2137")
