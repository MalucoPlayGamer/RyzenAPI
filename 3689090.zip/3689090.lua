-- Lua provided by SkyAPI 
-- Game: Labyrinth : Dracula's lair
addappid(3689090)
addappid(3689091, 1, "f77fb8d4fcc028d4ecbf0a2b36ce019ebff4a33bcd69aa7c22cc538d1fbd6ce7")
