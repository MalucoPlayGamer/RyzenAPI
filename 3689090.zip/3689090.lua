-- Lua provided by RyzenAPI
-- Game: Labyrinth : Dracula's lair

-- MAIN APPLICATION
addappid(3689090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689091, 1, "f77fb8d4fcc028d4ecbf0a2b36ce019ebff4a33bcd69aa7c22cc538d1fbd6ce7")

