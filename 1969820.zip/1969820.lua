-- Lua provided by RyzenAPI
-- Game: Game: Legacy of Sin: Blood Oath

-- MAIN APPLICATION
addappid(1969820)
addappid(2164770)
-- Game: addappid(1969820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969821, 1, "0e78675196e91bfed0ec362211432d3a9665804f9aa2c6b8873946fd112c5065")
addappid(1969822, 1, "fd5e0a0f561b6026f6145b9dda4950909e10844dfe4a003f38182063158d546e")
addappid(1969823, 1, "f504c4b59da26c3bc458aff98dea7b2a8748f7c7738919003c5059f47a5c6c8c")
