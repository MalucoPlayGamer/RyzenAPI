-- Lua provided by RyzenAPI
-- Game: AppID 466160

-- MAIN APPLICATION
addappid(466160)
addappid(733170)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(466161, 1, "ed45d7772c3838ffd9219e6a6ec75b2556312810128fe7dbe1b5091534a39e9b")

