-- Lua provided by RyzenAPI
-- Game: AppID 466160

-- MAIN APPLICATION
addappid(466160)
-- Game: addappid(466160)

-- MAIN APP DEPOTS / PACKAGES
addappid(466161, 1, "ed45d7772c3838ffd9219e6a6ec75b2556312810128fe7dbe1b5091534a39e9b")
