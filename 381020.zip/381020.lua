-- Lua provided by RyzenAPI 
-- Game: Sky Rogue
addappid(381020)
addappid(381021, 1, "aa5c0aab131d242b1aa0933abcd138215a69bf9a3c7609c8de2eb144033f288e")
addappid(381022, 1, "4758415d49da3b2716803753fc5534a0f02f5524ee7fa4a90bc8cf5f6138603e")
addappid(381023, 1, "3f56ced32e2032932c459e3018493989b276fbf328bac0378cc5dcb012b0b828")
addappid(586070)
