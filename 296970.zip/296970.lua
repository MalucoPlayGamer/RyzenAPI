-- Lua provided by RyzenAPI
-- Game: AppID 296970

-- MAIN APPLICATION
addappid(296970)

-- MAIN APP DEPOTS / PACKAGES
addappid(296971, 1, "6d2026dac5117cbe37ffb5ae20f0a1d3f8569a47369f7c6682acd9aa0a0a476c")
addappid(296972, 1, "74126c85d0fb77596c3df1f55c805d5082f2ad89e5cf5205e72782ab8cee2e16")
addappid(296973, 1, "8c8494f5ea894476f706bf40443ac5f3b9df111d43a31484545a3f0cba9a2c5b")
addappid(296974, 1, "e39540283c1ed0ccaa1055700c32e44d5f4bf08e5533253816e54d1ad5688d6d")
addappid(296975, 1, "e02cdbda4e3d170b7ca9e579bb48c0f565f83c3935255641ac42280083b52a25")
addappid(296976, 1, "187ecd47ef952b50eb86fc528adf7be912eb242285aa02dc316a5bf3d8605b4e")
addappid(296977, 1, "68e417137ea909f1fdce81a3c6aae1b56253bceb7f39ef86b2ad9ca84bc72e90")
addappid(296978, 1, "74437b166f551322abeca4edc4178980d6464b51b5348a2f66f9d7951c7c15a8")
addappid(296979, 1, "ca9c8260e8aad1055ca7d67c5b54303c08cb80167b85f2003b4c7e900dd5b26d")
addappid(997041, 0, "7c62b39bbdd9201ca93ce90b4aee75b814f24b0f47581ab2d933fad2bc2eec02")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(410170)
addappid(460390)
addappid(609970)
addappid(997042)
