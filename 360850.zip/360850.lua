-- Lua provided by RyzenAPI
-- Game: Game: AppID 360850

-- MAIN APPLICATION
addappid(360850)
-- Game: addappid(360850)

-- MAIN APP DEPOTS / PACKAGES
addappid(360851, 1, "93b8f7f5dd1ddc1e2cf8ab3b3e96268bfd716435931e6c47b74d72f65ebb36da")
