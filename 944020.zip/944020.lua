-- Lua provided by RyzenAPI
-- Game: 944020

-- MAIN APPLICATION
addappid(944020)
-- Game: addappid(944020)

-- MAIN APP DEPOTS / PACKAGES
addappid(944021, 1, "ed3d94eeaf625bf5bcb525641aa310b0b88becc1d2b419585d78ccf50b83c4d2")
addappid(1096940, 0, "52c7c1c400a30558e1dd529a8b522feff155da933e5333ec005d488328a1e11c")
