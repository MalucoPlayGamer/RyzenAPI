-- Lua provided by RyzenAPI 
-- Game: Aquarist VR Demo
addappid(2141020)
addappid(2141021, 1, "44a510a9ad5af39b795c950eb5429a87f4de309fd93949f433a0e70271514fc6")
