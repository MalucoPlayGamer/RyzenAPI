-- Lua provided by RyzenAPI
-- Game: Signy & Mino: Against All Gods

-- MAIN APP DEPOTS / PACKAGES
addappid(2379160, 1, "f7042278da1f7249c0acc794063913e2fe914e2a132a83e1fe45a013262915e5") -- Signy & Mino: Against All Gods
addappid(2379161, 1, "91b805bb48e49737bdfea1d6c8c7cf5f954edce1e1e79fd2e1bda52e81cd7141") -- Depot 2379161

