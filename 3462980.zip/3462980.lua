-- Lua provided by RyzenAPI
-- Game: Nirvana

-- MAIN APPLICATION
addappid(3462980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3462981, 1, "53a62c9c1e61879a958e93e137c15aabcceb757025648f13f6f31d401fa72a44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
