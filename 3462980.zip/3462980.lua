-- Lua provided by RyzenAPI
-- Game: Game: Nirvana

-- MAIN APPLICATION
addappid(3462980)
-- Game: addappid(3462980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3462981, 1, "53a62c9c1e61879a958e93e137c15aabcceb757025648f13f6f31d401fa72a44")
