-- Lua provided by RyzenAPI
-- Game: Finding Cats In Breeze Village

-- MAIN APPLICATION
addappid(2845400)
-- Game: addappid(2845400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845401, 1, "4dac0797fc80fe697b5f950a184c1e0ceb56ad800741eb4b4bcdd113eb67b7c0")
