-- Lua provided by RyzenAPI
-- Game: 3699970

-- MAIN APPLICATION
addappid(3699970)
-- Game: addappid(3699970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699971, 1, "bd479351e02e020c397dab0bcfeadd8517a06e4ff272b2a2fed335c47f1d5c75")
