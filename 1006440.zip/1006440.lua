-- Lua provided by RyzenAPI
-- Game: The Dame Was Loaded

-- MAIN APPLICATION
addappid(1006440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006441, 1, "dee5bf7f1392c23dba925f85ffb45279ddc475acfbea6b459583e289b1b83667")
