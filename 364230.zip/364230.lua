-- Lua provided by RyzenAPI
-- Game: Lucius Demake

-- MAIN APPLICATION
addappid(364230)

-- MAIN APP DEPOTS / PACKAGES
addappid(364231, 1, "9f33fe7881ffe399789448d49b8d85f2c180c5b8f6ad8caf32630e52470cbfe0")
addappid(364232, 1, "fc2d6bb862275c000ea5b342fb8a10361e2cc7c9510943fdfc09ac07d33f9412")

