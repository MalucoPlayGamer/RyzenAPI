-- Lua provided by RyzenAPI 
-- Game: AppID 2670730
addappid(2670730)
addappid(2670731, 1, "41fa76a302423a5215bf4982b11cda90026fa05d7ecd049f9c8f236d6146aaab")
