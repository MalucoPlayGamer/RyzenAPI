-- Lua provided by RyzenAPI
-- Game: 1766230

-- MAIN APPLICATION
addappid(1766230)
-- Game: addappid(1766230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766231, 1, "14bc688bedf2298eb2b04c56519157b77667adb2c184e694c92fed8a693aca29")
