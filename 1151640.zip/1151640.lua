-- Lua provided by RyzenAPI
-- Game: AppID 1151640

-- MAIN APPLICATION
addappid(1151640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151641, 1, "df518a946513a91a56704336384864918ec740df8537ca1812a8f54264355361")
addappid(1151642, 1, "59255c4691e86b0813ddced2314be6ac433c80eacb80b7d716c1cc76ca2032f2")
addappid(1151644, 1, "8a4848c62e8fcd4b79f78195190e4595e6c74b9a81ebe42b60e82bdd9b4b5c17")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2107510)
