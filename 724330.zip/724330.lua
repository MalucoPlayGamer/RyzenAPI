-- Lua provided by RyzenAPI
-- Game: Age of Grit

-- MAIN APPLICATION
addappid(724330)

-- MAIN APP DEPOTS / PACKAGES
addappid(724333,0,"8ae2d41b81e928cd9363b1f0c088b78730893932b3a66dcbec83340887382e2a")

