-- Lua provided by RyzenAPI
-- Game: AppID 1550190

-- MAIN APPLICATION
addappid(1550190)
-- Game: addappid(1550190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550191, 1, "77ad2eea4ff09649565ad2ce6318f21cd224ce7326c31db6498b515e1fc00708")
