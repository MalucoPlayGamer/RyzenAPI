-- Lua provided by RyzenAPI
-- Game: AppID 1550190

-- MAIN APPLICATION
addappid(1550190)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1550191, 1, "77ad2eea4ff09649565ad2ce6318f21cd224ce7326c31db6498b515e1fc00708")

