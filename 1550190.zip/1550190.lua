-- Lua provided by SkyAPI 
-- Game: AppID 1550190
addappid(1550190)
addappid(1550191, 1, "77ad2eea4ff09649565ad2ce6318f21cd224ce7326c31db6498b515e1fc00708")
