-- Lua provided by RyzenAPI
-- Game: Screw Drivers

-- MAIN APPLICATION
addappid(1279510)
addappid(2999730)
addappid(3288110)
addappid(3500960)
addappid(3816730)
addappid(3816740)
addappid(3816750)
addappid(3816770)
addappid(4129420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279511, 1, "ef004932c90fe787672412305ac6f8a390431f51947c405d255840ead5220052")

