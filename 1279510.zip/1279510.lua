-- Lua provided by RyzenAPI 
-- Game: Screw Drivers
addappid(1279510)
addappid(1279511, 1, "ef004932c90fe787672412305ac6f8a390431f51947c405d255840ead5220052")
