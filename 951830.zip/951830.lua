-- Lua provided by RyzenAPI
-- Game: The Last Sovereign

-- MAIN APPLICATION
addappid(951830)
addappid(1032050)
addappid(4020140)

-- MAIN APP DEPOTS / PACKAGES
addappid(951831, 1, "39310b427e2f6c34ee891788aa42b1bda4b20ad807261a33677a72f2dd348946")
