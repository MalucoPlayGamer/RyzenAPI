-- Lua provided by RyzenAPI
-- Game: Dead Island 2

-- MAIN APPLICATION
addappid(934700)
addappid(2667910)
addappid(2813000)
addappid(2813010)
addappid(2813020)
addappid(2813030)
addappid(2813040)
addappid(2813050)
addappid(2813060)
addappid(2813070)
addappid(2813080)
addappid(2813090)
addappid(2813100)
addappid(2813110)
addappid(2813310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(934701, 1, "9f01bb4de4308fcda3524d8e086fb30c2cee5a647bc41b8ca77afad561bde375")
addappid(934702, 1, "74f4653f5c8cd21938bd4a269765ee3310d860bbf57e7fcc44dd02751f277a49")
addappid(934703, 1, "58de2f171f82b74cb47ade0cbc87eb4a5046814bdf0bf1b6d359625a63543852")

