-- Lua provided by RyzenAPI
-- Game: Dead Island 2

-- MAIN APPLICATION
addappid(934700)

-- MAIN APP DEPOTS / PACKAGES
addappid(934701, 1, "9f01bb4de4308fcda3524d8e086fb30c2cee5a647bc41b8ca77afad561bde375")
addappid(934702, 1, "74f4653f5c8cd21938bd4a269765ee3310d860bbf57e7fcc44dd02751f277a49")
addappid(934703, 1, "58de2f171f82b74cb47ade0cbc87eb4a5046814bdf0bf1b6d359625a63543852")

