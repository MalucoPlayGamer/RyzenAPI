-- Lua provided by RyzenAPI
-- Game: Inventory Quest: Hero's Hoard Demo

-- MAIN APPLICATION
addappid(3039270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039271, 1, "328c82423603d3f833d9639d008c42e66652019f9f2926343160856a446445aa")
