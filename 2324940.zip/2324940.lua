-- Lua provided by RyzenAPI 
-- Game: AESIR Online
addappid(2324940)
addappid(2324941, 1, "192da237b18633b049a70d1db02ca22a8350c7629b3eceace54a136ad7fc17de")
