-- Lua provided by RyzenAPI
-- Game: Colour Bind

-- MAIN APPLICATION
addappid(208710)
addappid(229020)

-- MAIN APP DEPOTS / PACKAGES
addappid(208711, 1, "0f0cbb8176ee18aaa4ec3517282ada25ccad55539ee412490c8b59a29ad5a0ea")
