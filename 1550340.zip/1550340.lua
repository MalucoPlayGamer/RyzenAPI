-- Lua provided by RyzenAPI 
-- Game: The hardest game in the universe
addappid(1550340)
addappid(1550341, 1, "7e6f514ba42f3f03d89c697cfbd7e0c59fe4e0265ed2a282f738ce2cbafdc314")
