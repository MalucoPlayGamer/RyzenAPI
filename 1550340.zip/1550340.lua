-- Lua provided by RyzenAPI
-- Game: 1550340

-- MAIN APPLICATION
addappid(1550340)
-- Game: addappid(1550340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550341, 1, "7e6f514ba42f3f03d89c697cfbd7e0c59fe4e0265ed2a282f738ce2cbafdc314")
