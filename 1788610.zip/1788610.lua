-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1788610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788610,0,"650172f9d8cd4a212c836859c0efba5957165939e24e920e0ba01746a1a6d358")
