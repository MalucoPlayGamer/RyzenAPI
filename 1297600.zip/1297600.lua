-- Lua provided by RyzenAPI
-- Game: 1297600

-- MAIN APPLICATION
addappid(1297600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297602,0,"235ff718276cdd9a076e3d263e3e1c31b9f9a8cb3b2e3ecafdff9c1ec5946ec1")
addappid(1297603,0,"cc21d1c293ac9ee5b0837b823c5d10078dbca1701f651a2a43402a63c867daaa")

