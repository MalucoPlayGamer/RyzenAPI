-- Lua provided by RyzenAPI
-- Game: Game: Run Sausage Run!

-- MAIN APPLICATION
addappid(2324300)
-- Game: addappid(2324300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324301, 1, "71462dd0917e0aa39a99ff768fb7499b7db568c079fc185067010642ef24d3f9")
