-- Lua provided by RyzenAPI
-- Game: Run Sausage Run!

-- MAIN APPLICATION
addappid(2324300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324301, 1, "71462dd0917e0aa39a99ff768fb7499b7db568c079fc185067010642ef24d3f9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2839980)
addappid(3791180)
addappid(3791190)
addappid(3791200)
addappid(3791210)
addappid(3791220)
addappid(3791230)
