-- Lua provided by RyzenAPI
-- Game: addappid(2454930)

-- MAIN APPLICATION
addappid(2454930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454931, 1, "166d5df7c7dbb95b73b9664e64c1b4563e2b7fd697ae41665b3f2111666fa50e")
