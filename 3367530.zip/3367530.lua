-- Lua provided by RyzenAPI
-- Game: OpenCAGE

-- MAIN APPLICATION
addappid(3367530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367531, 1, "f13ea6caf713b791d74c3be13c9889ef65d81f9003799aa082ec31c23afec298")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
