-- Lua provided by RyzenAPI
-- Game: addappid(3367530)

-- MAIN APPLICATION
addappid(3367530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367531, 1, "f13ea6caf713b791d74c3be13c9889ef65d81f9003799aa082ec31c23afec298")
