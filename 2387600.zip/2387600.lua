-- Lua provided by RyzenAPI
-- Game: addappid(2387600)

-- MAIN APPLICATION
addappid(2387600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387601, 1, "9b961db97f5e697d1c147682751b701f80c970c13e19b7bdc8b29f749a6bc40e")
