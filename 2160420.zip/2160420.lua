-- Lua provided by RyzenAPI
-- Game: The Backrooms Multiplayer

-- MAIN APPLICATION
addappid(2160420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160421, 1, "f4d1d3ed5e70b71644e60ae7d4571e2d59bd9e799052cbc890fd7ab730002b33")
