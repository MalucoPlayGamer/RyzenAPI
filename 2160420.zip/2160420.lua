-- Lua provided by RyzenAPI
-- Game: The Backrooms Multiplayer

-- MAIN APPLICATION
addappid(2160420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2160421, 1, "f4d1d3ed5e70b71644e60ae7d4571e2d59bd9e799052cbc890fd7ab730002b33")

