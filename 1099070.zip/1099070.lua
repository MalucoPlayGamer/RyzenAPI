-- Lua provided by RyzenAPI
-- Game: Legendary gun

-- MAIN APPLICATION
addappid(1099070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099071, 1, "a1a2fba4dbd40a7fce8551bf9ffe1ecda49f5cecf212bf09e5343d257d65175f")
