-- Lua provided by SkyAPI 
-- Game: Legendary gun
addappid(1099070)
addappid(1099071, 1, "a1a2fba4dbd40a7fce8551bf9ffe1ecda49f5cecf212bf09e5343d257d65175f")
