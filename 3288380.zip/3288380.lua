-- Lua provided by RyzenAPI
-- Game: 3288380

-- MAIN APPLICATION
addappid(3288380)
-- Game: addappid(3288380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288381, 1, "68a3b14dbffc2718e6170795002b89646a27177d5e27cfcb3b9700c8c08fb88a")
