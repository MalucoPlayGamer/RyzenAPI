-- Lua provided by SkyAPI 
-- Game: SEX CLUB Simulator 🔞🍓
addappid(3288380)
addappid(3288381, 1, "68a3b14dbffc2718e6170795002b89646a27177d5e27cfcb3b9700c8c08fb88a")
