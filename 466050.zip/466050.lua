-- Lua provided by RyzenAPI
-- Game: 466050

-- MAIN APPLICATION
addappid(466050)
-- Game: addappid(466050)

-- MAIN APP DEPOTS / PACKAGES
addappid(466051, 1, "cf024f8734214ed12d0e320f112003c84c8defaae5cdf45dd1293cada1f9b053")
