-- Lua provided by RyzenAPI
-- Game: 2100090

-- MAIN APPLICATION
addappid(2100090)
-- Game: addappid(2100090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100091, 1, "89bcec077591216dd1fcb9f6ef2492c892ffd53a30addca862d0e5560f538728")
