-- Lua provided by RyzenAPI
-- Game: MGP Manager

-- MAIN APPLICATION
addappid(759860)

-- MAIN APP DEPOTS / PACKAGES
addappid(759862,0,"5345f0d35c3a164655a78c60f6ec6de1da7c36c972b85a8c5f988b7203f901c6")

