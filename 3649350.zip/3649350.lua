-- Lua provided by RyzenAPI
-- Game: 3649350

-- MAIN APPLICATION
addappid(3649350)
-- Game: addappid(3649350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3649351, 1, "e7db669e72c93d4a07ac4be9ca23b7ffc8107e1eaff390964e0e780c02dba93c")
