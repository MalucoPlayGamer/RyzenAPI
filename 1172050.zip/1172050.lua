-- Lua provided by RyzenAPI
-- Game: COCKHEAD

-- MAIN APPLICATION
addappid(1172050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172051, 1, "e0efd7852ddcb6cc1d4a5e03e88913d77de13f45ae55cc78f11852e7432adeef")
