-- Lua provided by RyzenAPI
-- Game: AppID 1631710

-- MAIN APPLICATION
addappid(1631710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631711, 1, "ee79bcb699ee735e3e3ba38dc643c4efad4790f336cd976bf538df30eeba0371")

