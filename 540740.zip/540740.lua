-- Lua provided by SkyAPI 
-- Game: Perfect
addappid(540740)
addappid(540741, 1, "4afafeb8d471530f7df742747424f000503228009b6e7b30bf4c510f2feca3ab")
