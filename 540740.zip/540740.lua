-- Lua provided by RyzenAPI
-- Game: Game: Perfect

-- MAIN APPLICATION
addappid(540740)
-- Game: addappid(540740)

-- MAIN APP DEPOTS / PACKAGES
addappid(540741, 1, "4afafeb8d471530f7df742747424f000503228009b6e7b30bf4c510f2feca3ab")
