-- Lua provided by RyzenAPI
-- Game: 1259790

-- MAIN APPLICATION
addappid(1259790)
-- Game: addappid(1259790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259791, 1, "5ea8dbe5aeae44f42d162a5cb2b674190a05b463043126bc912e1757bf60b49c")
