-- Lua provided by RyzenAPI
-- Game: Puyo Puyo™ Tetris® 2

-- MAIN APPLICATION
addappid(1259790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259791, 1, "5ea8dbe5aeae44f42d162a5cb2b674190a05b463043126bc912e1757bf60b49c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1538230)
