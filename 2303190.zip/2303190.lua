-- Lua provided by RyzenAPI
-- Game: 2303190

-- MAIN APPLICATION
addappid(2303190)
-- Game: addappid(2303190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303191, 1, "d206c24c95d9a61ec9af1efe5a474035bd579fea859e933585e3676a94d264ba")
