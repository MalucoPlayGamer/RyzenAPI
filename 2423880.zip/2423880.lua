-- Lua provided by RyzenAPI 
-- Game: AppID 2423880
addappid(2423880)
addappid(2423881, 1, "d160224bbd6383dd854f48f4ff53d8e0a20d62389ca07affd53772f75c782122")
