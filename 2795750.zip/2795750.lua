-- Lua provided by RyzenAPI
-- Game: Night Slashers: Remake

-- MAIN APPLICATION
addappid(2795750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795751, 1, "74154dbe91f089fa8d7b3aadd576220af75ca81b68759983f5a8b81009e08218")

