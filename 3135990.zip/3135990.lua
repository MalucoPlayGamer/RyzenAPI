-- Lua provided by RyzenAPI
-- Game: AppID 3135990

-- MAIN APPLICATION
addappid(3135990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3135991, 1, "891beb4ec69b9c17aeaf9880a90f2970f21da5fa905942e140bb63fbe78a19fa")

