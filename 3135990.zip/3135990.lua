-- Lua provided by RyzenAPI
-- Game: Finnish Cabin Mayhem - Mökkimähinä

-- MAIN APPLICATION
addappid(3135990)
-- Game: addappid(3135990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135991, 1, "891beb4ec69b9c17aeaf9880a90f2970f21da5fa905942e140bb63fbe78a19fa")
