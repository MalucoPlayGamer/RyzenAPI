-- Lua provided by RyzenAPI
-- Game: Game: Aveyond 3-3: The Lost Orb

-- MAIN APPLICATION
addappid(321880)
-- Game: addappid(321880)

-- MAIN APP DEPOTS / PACKAGES
addappid(321881, 1, "98eeabe3d98b47ac15ba95181f702865df5514336ec5db1fc13da09f108994f4")
