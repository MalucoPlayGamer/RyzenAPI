-- Lua provided by RyzenAPI
-- Game: Project Beril X Shining Shooting Star

-- MAIN APPLICATION
addappid(2457400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457401, 1, "09cc379118595ad94d601bd12da754d7e3b32869039a69eef9d5ca5aa7a3c6ee")
