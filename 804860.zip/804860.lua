-- Lua provided by RyzenAPI
-- Game: Klotzen! Panzer Battles

-- MAIN APPLICATION
addappid(804860)

-- MAIN APP DEPOTS / PACKAGES
addappid(804861,0,"92fa2e4bff4884635f08b3936190c0917bf3467e19277d585337b6482a4a3894")

