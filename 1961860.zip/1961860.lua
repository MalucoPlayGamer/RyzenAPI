-- Lua provided by RyzenAPI
-- Game: - Doki Doki Family - 特異体質者のドキドキ家族生活

-- MAIN APPLICATION
addappid(1961860)
-- Game: addappid(1961860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961861, 1, "fa4c8e5a383ca862baf738991cd5e909312a8580c23eec3b7c71fd974804b07c")
