-- Lua provided by RyzenAPI
-- Game: Phantom of the Twilight Demo

-- MAIN APPLICATION
addappid(3074780)
-- Game: addappid(3074780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074781, 1, "a69a1ee058d4e6bd09a5d6d23f41c89d13e06837ed78d1c433a876c7574d7493")
