-- Lua provided by SkyAPI 
-- Game: to a T
addappid(1875320)
addappid(1875321, 1, "a803448a773c04a1dd88813bcf71df7a11332bfa866bef9fc17c6107928f294a")
