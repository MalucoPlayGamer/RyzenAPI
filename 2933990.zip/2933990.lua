-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Christmas

-- MAIN APPLICATION
addappid(2933990)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3224930)
