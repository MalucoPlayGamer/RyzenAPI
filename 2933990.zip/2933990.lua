-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Christmas

-- MAIN APPLICATION
addappid(2933990)

