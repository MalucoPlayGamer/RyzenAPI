-- Lua provided by RyzenAPI
-- Game: addappid(2544620)

-- MAIN APPLICATION
addappid(2544620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544621, 1, "cb429a265c74002c4f6d1599b16b942d90a6a0ca38db8a2f7f218cd307ce441c")
