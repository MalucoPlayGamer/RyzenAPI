-- Lua provided by RyzenAPI 
-- Game: AppID 501900
addappid(501900)
addappid(501901, 1, "4c0553eb4e1eb02d67d3aa8786602b7c4f8c9ff2edbcb64f1a1bca44a362984f")
