-- Lua provided by RyzenAPI
-- Game: 429780

-- MAIN APPLICATION
addappid(429780)
-- Game: addappid(429780)

-- MAIN APP DEPOTS / PACKAGES
addappid(429781, 1, "90f79db2fa29bd102f7e36b317b429db2320413f567e9abf290a9323612fd1a8")
