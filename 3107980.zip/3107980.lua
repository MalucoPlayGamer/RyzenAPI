-- Lua provided by RyzenAPI
-- Game: 3107980

-- MAIN APPLICATION
addappid(3107980)
-- Game: addappid(3107980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107981, 1, "f0afff5ff0598914413c6bb2bca16daca6368ee249e58d301c6f0061d44c75f3")
