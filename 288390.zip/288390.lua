-- Lua provided by RyzenAPI
-- Game: NOBUNAGA'S AMBITION: Souzou with Power Up Kit

-- MAIN APPLICATION
addappid(288390)
addappid(321640)
addappid(321641)
addappid(321642)
addappid(321643)
addappid(321644)
addappid(321645)
addappid(321646)
addappid(321647)
addappid(321648)
addappid(321649)
addappid(335650)
addappid(344110)
addappid(363230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(288391, 1, "472012d4409c8a4b95e0b1a0fc9e712950dd4ced07a996c0acb20e211916b7fa")
addappid(288392, 1, "787ac924d3e71a622e4e6e76e78ae50b28365324420b74dcc6c6173246cc137a")

