-- Lua provided by RyzenAPI
-- Game: addappid(1425370)

-- MAIN APPLICATION
addappid(1425370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425371, 1, "63028b3cf5153ecee8d28959dec0af2f480b5c5f93ef1976ec44e9372d2207fc")
