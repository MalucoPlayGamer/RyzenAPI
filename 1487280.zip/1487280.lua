-- Lua provided by RyzenAPI
-- Game: 1487280

-- MAIN APPLICATION
addappid(1487280)
addappid(2668900)
-- Game: addappid(1487280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487281, 1, "4bf893443edb48896bce3601f372ebe6b4676ebda114ac3460d97c1c2ed2e248")
