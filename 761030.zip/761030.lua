-- Lua provided by RyzenAPI
-- Game: EARTHLOCK

-- MAIN APPLICATION
addappid(761030)

-- MAIN APP DEPOTS / PACKAGES
addappid(761031, 1, "94f81f875a581932dd42e23252c78adb39b5a08cebcfc0eb03db34fb4c383bf3")
addappid(761032, 1, "b28ea5f919a3534a74b32eb89c3dd0a59aa7327a29f55c8a557da3906c7fc0dd")
addappid(761035, 1, "3107a2ff81f4b3776de06a4ed87a59d2fc384e767a65da678953f11014153569")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(820980)
addappid(1075410)
addappid(1448420)
