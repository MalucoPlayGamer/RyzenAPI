-- Lua provided by RyzenAPI
-- Game: Star Vortex

-- MAIN APPLICATION
addappid(2098160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098161,0,"c26581d5679c41c52ff6ba083aba39a91ea29d9cc4f82cdecca963d4ccbe9b42")

