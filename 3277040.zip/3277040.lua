-- Lua provided by RyzenAPI
-- Game: The Queen of Phalli

-- MAIN APPLICATION
addappid(3277040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277041,0,"0d3d66fa263dfbd07ae9021c64d3f644bb78da903fca0779512fd79ba7b8c98e")

