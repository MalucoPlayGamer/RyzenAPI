-- Lua provided by RyzenAPI
-- Game: addappid(3447570)

-- MAIN APPLICATION
addappid(3447570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3447571, 1, "f9bb61e4615afefa730b28be97bbdde15dec611b9f63dc6c754adcf7dee9b70a")
