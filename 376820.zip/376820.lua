-- Lua provided by RyzenAPI
-- Game: addappid(376820)

-- MAIN APPLICATION
addappid(376820)

-- MAIN APP DEPOTS / PACKAGES
addappid(376820,0,"6a25664a66b97f4e0ed72547eb92809b49a45b60cb42748f023dba4d4e914d2b")
