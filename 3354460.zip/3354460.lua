-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3354460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354460,0,"5cadcf20439ca071dfd1159a77ef4d4233aebde7e0c7cc97437c0bdb1c214638")
