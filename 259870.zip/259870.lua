-- Lua provided by RyzenAPI
-- Game: addappid(259870)

-- MAIN APPLICATION
addappid(259870)

-- MAIN APP DEPOTS / PACKAGES
addappid(259871, 1, "4f2e5a5425ad67bc5baf910526ff1d2459030251141a70965aebad394995bbab")
