-- Lua provided by RyzenAPI
-- Game: AppID 259870

-- MAIN APPLICATION
addappid(259870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(259871, 1, "4f2e5a5425ad67bc5baf910526ff1d2459030251141a70965aebad394995bbab")

