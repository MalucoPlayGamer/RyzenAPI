-- Lua provided by RyzenAPI
-- Game: PacaPlus

-- MAIN APPLICATION
addappid(610610)

-- MAIN APP DEPOTS / PACKAGES
addappid(610611,0,"a021aefb1ae400f0607beeb2b17f83c91c4e01c7db47d1f230c93a9fc970af91")

