-- Lua provided by RyzenAPI
-- Game: RollScape

-- MAIN APPLICATION
addappid(2904290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904291, 1, "a36e3fd357a0b1a84f45f6b89a96fcf17f7ab5c2147f93ff9a462bcfe57608a7")
