-- Lua provided by RyzenAPI
-- Game: AppID 496760

-- MAIN APPLICATION
addappid(496760)

-- MAIN APP DEPOTS / PACKAGES
addappid(496761, 1, "c653da01e7f176ca6e13b941a033c336d24a7216db1b19e4ee2f46325cceb5d3")
