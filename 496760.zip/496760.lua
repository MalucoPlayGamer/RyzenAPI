-- Lua provided by SkyAPI 
-- Game: AppID 496760
addappid(496760)
addappid(496761, 1, "c653da01e7f176ca6e13b941a033c336d24a7216db1b19e4ee2f46325cceb5d3")
