-- Lua provided by RyzenAPI
-- Game: Hotline Miami

-- MAIN APPLICATION
addappid(219152)

-- MAIN APP DEPOTS / PACKAGES
addappid(219150, 1, "2913177754c5c8b37def713cdb2cbb3c6c7268f3ceff993c9a1ba1b6805d5116")
addappid(219151, 1, "456344fdb2b0b0fa153f9224614ea5f197a574c7fa01dca7d4e67396b90862f1") -- (windows)
addappid(219152, 1, "d1116e26a0aeb3d3a498382d419102e5a8386dcfa923e8844a6e1e2aa0d671f4")
addappid(219153, 1, "36914ef27763ac7dce257f1590b6e79691ca6a8344717af702f8561696084724") -- (macos)
addappid(219154, 1, "7b246edbccabec5571afe424f31a75091978a35a235dfd22f38202a1e560d6f0") -- (windows)
addappid(219155, 1, "5b5492d07dfd11304128730426b8c37825fb0e0704bcdd71c27b483e83245848") -- (linux)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

