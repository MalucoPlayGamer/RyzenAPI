-- Lua provided by RyzenAPI
-- Game: Game: Hotline Miami

-- MAIN APPLICATION
addappid(219150)
addappid(228983)
addappid(228990)
addappid(229000)
addappid(229020)
addappid(275090)
-- Game: addappid(219150)

-- MAIN APP DEPOTS / PACKAGES
addappid(219151, 1, "456344fdb2b0b0fa153f9224614ea5f197a574c7fa01dca7d4e67396b90862f1")
addappid(219153, 1, "36914ef27763ac7dce257f1590b6e79691ca6a8344717af702f8561696084724")
addappid(219154, 1, "7b246edbccabec5571afe424f31a75091978a35a235dfd22f38202a1e560d6f0")
addappid(219155, 1, "5b5492d07dfd11304128730426b8c37825fb0e0704bcdd71c27b483e83245848")
