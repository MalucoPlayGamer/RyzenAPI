-- Lua provided by RyzenAPI
-- Game: Noun Town: VR Language Learning

-- MAIN APPLICATION
addappid(1643100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643101, 1, "e91a99eaea1343f1bea7e632c5a4197adea9e47ad82f3a1c336d94e7ee6ac394")

