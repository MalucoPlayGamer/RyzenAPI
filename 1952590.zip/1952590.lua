-- Lua provided by RyzenAPI
-- Game: Future Racer 2000

-- MAIN APPLICATION
addappid(1952590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952591, 1, "3244c69db98a5a9ebae76459eb0376a7624b9f41eda189d2d796fa3599ef6d60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
