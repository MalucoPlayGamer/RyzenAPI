-- Lua provided by SkyAPI 
-- Game: Horribunnies Demo
addappid(1321820)
addappid(1321821, 1, "3ed8ecb94931042c46e247c910adef23b18feb8be9c704653dbf16392c3afc86")
