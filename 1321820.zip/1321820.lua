-- Lua provided by RyzenAPI
-- Game: Horribunnies Demo

-- MAIN APPLICATION
addappid(1321820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321821, 1, "3ed8ecb94931042c46e247c910adef23b18feb8be9c704653dbf16392c3afc86")

