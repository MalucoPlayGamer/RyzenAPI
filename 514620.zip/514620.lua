-- Lua provided by RyzenAPI
-- Game: Ellipsis

-- MAIN APPLICATION
addappid(514620)
-- Game: addappid(514620)

-- MAIN APP DEPOTS / PACKAGES
addappid(514621, 1, "4590c1cebcb1e14b723017efa97a245ed45ce9228c9881c15ea0021c5402082d")
addappid(514622, 1, "8ff16cab418616ae3da9988f9d268169ba7b41926764661fe67b65a7d9d2068f")
addappid(514623, 1, "0587ceff456a40c4256f57d097ee7f3b6595a3e4802faf02ab7d0050bbf78cd5")
