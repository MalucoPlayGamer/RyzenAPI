-- Lua provided by RyzenAPI
-- Game: Nyasha Beach - Artbook 18+

-- MAIN APPLICATION
addappid(1080570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080570,0,"9b8359a92fc377bbf94510bd600672413abbd772f742982e201092442549a689")

