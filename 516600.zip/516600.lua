-- Lua provided by RyzenAPI 
-- Game: AppID 516600
addappid(516600)
addappid(516601, 1, "46e5593a4a4a9f2bdd5ec452df6a20851907e505533f88fbe6dddab4e6d21849")
addappid(516602, 1, "af4cbeef967e785c1e61ead92b620dcb1b3c0d9dab123ea9cf862773b8a3777b")
addappid(696620, 0, "249b4d8de87d866e93f37565f80306c14696605f3f06a6ebb4d5fd6b15ac39cc")
