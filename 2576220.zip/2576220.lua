-- Lua provided by RyzenAPI
-- Game: Game: AppID 2576220

-- MAIN APPLICATION
addappid(2576220)
-- Game: addappid(2576220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576221, 1, "232c9344bcfc09fcb3ff5e1c7b81594c2cd082ea9e73782e3416cb7d7a2bbc37")
