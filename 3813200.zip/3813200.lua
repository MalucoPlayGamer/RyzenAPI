-- Lua provided by RyzenAPI
-- Game: 萌宠消消乐

-- MAIN APPLICATION
addappid(3813200)
-- Game: addappid(3813200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3813201, 1, "d10dd73e6455d8b3a27309e84d919d14772958ca319c5ae33c09d152b83b5001")
