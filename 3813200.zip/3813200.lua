-- Lua provided by SkyAPI 
-- Game: 萌宠消消乐
addappid(3813200)
addappid(3813201, 1, "d10dd73e6455d8b3a27309e84d919d14772958ca319c5ae33c09d152b83b5001")
