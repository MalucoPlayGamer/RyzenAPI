-- Lua provided by RyzenAPI
-- Game: Game: RUNGORE

-- MAIN APPLICATION
addappid(2113040)
-- Game: addappid(2113040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113041, 1, "9d8d75fac5fc285f4fb82a7c7b4e1e4ad2a42b8625d5d8c88e7d51bd59e8ed70")
