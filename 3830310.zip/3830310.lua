-- Lua provided by RyzenAPI
-- Game: 3830310

-- MAIN APPLICATION
addappid(3830310)
-- Game: addappid(3830310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3830311, 1, "35d34bc1b656234436e215733a2727e202972cc58e57ad8de6f30b38efe37ec1")
