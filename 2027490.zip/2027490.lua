-- Lua provided by RyzenAPI 
-- Game: Paramnesia
addappid(2027490)
addappid(2027491, 1, "85257cbeeeec1378157e1c1cfb7f43f6f154605eead28e18fd538eef26286490")
