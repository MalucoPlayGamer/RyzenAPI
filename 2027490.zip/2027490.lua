-- Lua provided by RyzenAPI
-- Game: Game: Paramnesia

-- MAIN APPLICATION
addappid(2027490)
-- Game: addappid(2027490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027491, 1, "85257cbeeeec1378157e1c1cfb7f43f6f154605eead28e18fd538eef26286490")
