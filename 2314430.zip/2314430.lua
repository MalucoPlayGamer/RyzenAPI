-- Lua provided by RyzenAPI
-- Game: addappid(2314430)

-- MAIN APPLICATION
addappid(2314430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314434,0,"a42167f0b0c7b17223e72ae8bb9e3097e4f68bb7670f6eb2fbe1bfa09a73f7f1")
