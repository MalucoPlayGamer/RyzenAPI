-- Lua provided by RyzenAPI
-- Game: yebushou：defeat pirates

-- MAIN APPLICATION
addappid(2314430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2314434,0,"a42167f0b0c7b17223e72ae8bb9e3097e4f68bb7670f6eb2fbe1bfa09a73f7f1")

