-- Lua provided by RyzenAPI
-- Game: Game: beat refle

-- MAIN APPLICATION
addappid(1947940)
-- Game: addappid(1947940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947941, 1, "807eaaf989173a205ed9f109d1f12b919f8e98a57b747d6a7722c8d7dc8f7462")
