-- Lua provided by RyzenAPI
-- Game: Game: Narita Boy

-- MAIN APPLICATION
addappid(1069530)
-- Game: addappid(1069530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069531, 1, "a4a4484c627f5b21ab3b103da51b53466291ebe0f757ca425141d07247a8261e")
addappid(1069532, 1, "7db9c9fa9e2d1ff70de5c192581456070bcc82ba80fc4d6ded9d0b3a4bd5d7df")
