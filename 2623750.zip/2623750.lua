-- Lua provided by RyzenAPI
-- Game: Game: Ghost Girl Ghussy: XXXL Edition

-- MAIN APPLICATION
addappid(2623750)
-- Game: addappid(2623750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623751, 1, "0e35dd43c77977fecf0a6b9201b764b03dbf06bdf9ac46f1d47cf210b11f4747")
addappid(2623752, 1, "e92c23faf4f68f67ac1f180f2b0d1eb912019bb3271a2a18087389f98271ab48")
