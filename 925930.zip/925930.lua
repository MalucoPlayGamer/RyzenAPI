-- Lua provided by RyzenAPI
-- Game: addappid(925930)

-- MAIN APPLICATION
addappid(925930)

-- MAIN APP DEPOTS / PACKAGES
addappid(925931, 1, "8beba539244bd34b5002be3a144721b14b48bd2e1e9ae3bcd9c0c1f1bda8acdf")
addappid(925932, 1, "705f6ce5abe7383279082bf96464357981930fc2aa6c56e0fe4662841273be8e")
