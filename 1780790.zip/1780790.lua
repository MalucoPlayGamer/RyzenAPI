-- Lua provided by RyzenAPI
-- Game: Chill Corner - Extras

-- MAIN APPLICATION
addappid(1780790)
-- Game: addappid(1780790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780790,0,"000982a21ba38d01030bd119f24834129cf68913918914b87225ffb60d26a011")
