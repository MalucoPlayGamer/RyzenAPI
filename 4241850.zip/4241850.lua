-- Lua provided by RyzenAPI
-- Game: Dreadmyst

-- MAIN APPLICATION
addappid(4241850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(4241851, 1, "c445ad8903041465c821a3fed0c1176a8112f318949deaa788d64fd1e82d912c")

