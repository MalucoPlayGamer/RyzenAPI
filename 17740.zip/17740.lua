-- Lua provided by RyzenAPI
-- Game: Empires Mod

-- MAIN APPLICATION
addappid(17740)

-- MAIN APP DEPOTS / PACKAGES
addappid(17741, 1, "7e8821461931362634689d0530c009d338d6c5c6b88eb81c981c638fdb0f61ac")
addappid(17742, 1, "9a3d669b14e10e2f322f4fc7fdf25e380b8dbc1a9f31e73b5f2e8e6a44a32962")
addappid(17743, 1, "e0baaabfe4a7d44302908a6a68558212d0af18324a7eba7c9f3fed832a958d1d")
addappid(17744, 1, "9e0f5b9cd9cb8b2bfc5ecb978bcff0551fe0637eadd3e3321ba617936295e382")
addappid(17745, 1, "89baf5c93dc011259514abe40f2f7128ee940bbbcd4a2eb3117c6f517dee9855")
addappid(17746, 1, "2e7bb66f98930659183de43b44445366dd09afb5feebe687de87c6c2bdadb874")

