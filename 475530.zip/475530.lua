-- Lua provided by RyzenAPI
-- Game: Game: Go Go Electric Samurai

-- MAIN APPLICATION
addappid(475530)
-- Game: addappid(475530)

-- MAIN APP DEPOTS / PACKAGES
addappid(475531, 1, "984c11c5d2389e1d15b9563aadf31f74a7ff111612f45f0dd8ceabd1029a34ce")
addappid(475532, 1, "338719d28b283c3743b97ca61fdc22e797df45e6b66c72a8b36f23f1f9817a47")
addappid(475533, 1, "30d753ed0fe02b9bbf7c353734acfe32c334ca3b60c6f964e17fb44829f756a5")
addappid(475534, 1, "4868d39f0db7ec946b79d6a566ae0b4e6a0bbde19429ada56fcb7f401b095580")
addappid(475535, 1, "74ecf73952a516126eec4c0fb30b8db79441334b20249e19df05e8a0a5b29a60")
