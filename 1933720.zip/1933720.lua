-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1933720)
-- Game: addappid(1933720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933720,0,"1a85821f39da1d9a7447323591c4dc682d3abd78862f0a6ce19f932fd1e5ac28")
