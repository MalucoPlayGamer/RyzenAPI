-- Lua provided by RyzenAPI
-- Game: addappid(1933720)

-- MAIN APPLICATION
addappid(1933720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933720,0,"1a85821f39da1d9a7447323591c4dc682d3abd78862f0a6ce19f932fd1e5ac28")
