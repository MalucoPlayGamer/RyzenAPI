-- Lua provided by RyzenAPI
-- Game: AppID 897930

-- MAIN APPLICATION
addappid(897930)
addappid(1144480)

-- MAIN APP DEPOTS / PACKAGES
addappid(897931, 1, "42f5055bb59c33a4d699e19f4f95367c949bc7e969d957a7ceae778cdcd666a6")

