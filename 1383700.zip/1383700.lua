-- Lua provided by RyzenAPI
-- Game: Jet Kave Adventure

-- MAIN APPLICATION
addappid(1383700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383701, 1, "b743b12d50cd63069776792afc0ff3d96597bbb7a376358d6b2350653e3120b6")

