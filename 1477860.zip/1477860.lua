-- Lua provided by RyzenAPI
-- Game: 7 Angels

-- MAIN APPLICATION
addappid(1477860)
-- Game: addappid(1477860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477861, 1, "5abaa9e8c60fcf631c9eeff46295a4021fdeb474f315caeb959b528c4f590dc9")
