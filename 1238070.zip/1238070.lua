-- Lua provided by RyzenAPI
-- Game: Game: Dead Space™ 3 Awakened

-- MAIN APPLICATION
addappid(1238070)
-- Game: addappid(1238070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238071, 1, "b0b0e711f319b72005a52798746abab7225f32646a2a4eb7a83d91e271bc4dbf")
addappid(1238072, 1, "97efb8a09ce148e9b91910bee36a0de829e4132fa2554c320199769bc4c5d197")
addappid(1238073, 1, "738d13f58c85f8aebd2113d4403aafec80091bd74a3b07dcfbc42fbb9b2a696f")
addappid(1238074, 1, "bb81e3c20aef2811edf6043cf93fcdf9c2d67d2ac3a28fbb7e59631447fd30f0")
addappid(1238075, 1, "79272a28e16cb1df1e70c289384622a84cdc10539cd6b37d1a65eac489b56914")
addappid(1238076, 1, "95b18b189d04f6aef0fd98587ff48a3343ac9cef77d24eedb3a584c6eccf4402")
