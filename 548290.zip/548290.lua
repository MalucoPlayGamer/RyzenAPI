-- Lua provided by RyzenAPI
-- Game: Dark Eden

-- MAIN APPLICATION
addappid(548290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(548291, 1, "bb89cf9848259d168f5f0a4114462c4b63f4ee9811a5e547d48e8fd217988e7c")
