-- Lua provided by RyzenAPI 
-- Game: AppID 548290
addappid(548290)
addappid(548291, 1, "bb89cf9848259d168f5f0a4114462c4b63f4ee9811a5e547d48e8fd217988e7c")
