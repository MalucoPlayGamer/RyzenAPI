-- Lua provided by RyzenAPI
-- Game: Pier Solar and the Great Architects

-- MAIN APPLICATION
addappid(286220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(286221, 1, "3ef4385eae74caa090b45a84c21bd786bf906ea1fc9c890e733223eb953ac63e")
addappid(328200, 0, "7b797b4d6c5cde00cba9cf881258e5a5fdd525b6c02015093352861fc82b51be")
