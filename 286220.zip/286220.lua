-- Lua provided by RyzenAPI
-- Game: addappid(286220)

-- MAIN APPLICATION
addappid(286220)

-- MAIN APP DEPOTS / PACKAGES
addappid(286221, 1, "3ef4385eae74caa090b45a84c21bd786bf906ea1fc9c890e733223eb953ac63e")
addappid(328200, 0, "7b797b4d6c5cde00cba9cf881258e5a5fdd525b6c02015093352861fc82b51be")
