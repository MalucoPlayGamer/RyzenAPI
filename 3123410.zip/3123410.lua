-- Lua provided by RyzenAPI
-- Game: Atelier Yumia: The Alchemist of Memories & the Envisioned Land

-- MAIN APPLICATION
addappid(3123410)
addappid(3284970)
addappid(3284980)
addappid(3284990)
addappid(3285000)
addappid(3285010)
addappid(3285020)
addappid(3285030)
addappid(3285040)
addappid(3285050)
addappid(3285060)
addappid(3285070)
addappid(3285080)
addappid(3285090)
addappid(3285100)
addappid(3285110)
addappid(3285120)
addappid(3285130)
addappid(3285140)
addappid(3285150)
addappid(3401940)
addappid(3401950)
-- Game: addappid(3123410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123411, 1, "427bebee696a57c77abdb7f7c291fe1f99efc82922c0ba9b154fd7cb9a2b4e78")
