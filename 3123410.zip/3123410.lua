-- Lua provided by RyzenAPI
-- Game: Atelier Yumia: The Alchemist of Memories & the Envisioned Land

-- MAIN APPLICATION
addappid(3123410)
addappid(3284970)
addappid(3284980)
addappid(3284990)
addappid(3285000)
addappid(3285010)
addappid(3285020)
addappid(3285030)
addappid(3285040)
addappid(3285050)
addappid(3285060)
addappid(3285070)
addappid(3285080)
addappid(3285090)
addappid(3285100)
addappid(3285110)
addappid(3285120)
addappid(3285130)
addappid(3285140)
addappid(3285150)
addappid(3401940)
addappid(3401950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123411, 1, "427bebee696a57c77abdb7f7c291fe1f99efc82922c0ba9b154fd7cb9a2b4e78")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3569670)
addappid(3569680)
addappid(3569690)
addappid(3668860)
addappid(3742540)
addappid(3742550)
addappid(3742560)
addappid(3742570)
addappid(3742580)
addappid(3742590)
addappid(3742600)
addappid(3742610)
addappid(3742620)
addappid(3742630)
addappid(3742640)
addappid(3855580)
addappid(3855590)
addappid(3931880)
