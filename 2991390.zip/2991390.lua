-- Lua provided by RyzenAPI
-- Game: Kozue's Strange Journey 2

-- MAIN APPLICATION
addappid(2991390)
-- Game: addappid(2991390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2991391, 1, "ffccfb5c3006be89497133849b7b2713602cd5917e9b940db5e5e1df51b1303f")
addappid(2991392, 1, "04f4508ca2024b08e07d0006c658fda864ba121c174ab811c1c7855d29e1165e")
addappid(2991393, 1, "9de9d07370121daa69383a3ffa6a0e9553a2ef239d18680f7d55dac5e8509854")
