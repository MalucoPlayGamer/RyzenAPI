-- Lua provided by RyzenAPI
-- Game: AppID 742420

-- MAIN APPLICATION
addappid(742420)

-- MAIN APP DEPOTS / PACKAGES
addappid(742421, 1, "88a9d9035d4e3901137c2dee72a0d793e82eef65ab3bb4a955807a1fc7ad656a")
addappid(742422, 1, "f1d350a42b978755d26493fa6da74f910b4865d9b637122b1d297a937c7a9f9b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2391920)
addappid(2419620)
addappid(2419621)
addappid(2419622)
addappid(2419623)
addappid(2419624)
addappid(2419625)
addappid(2419626)
addappid(2419627)
addappid(2419628)
addappid(2419629)
addappid(2508370)
addappid(2508380)
addappid(2508390)
addappid(2512130)
