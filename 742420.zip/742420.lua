-- Lua provided by RyzenAPI
-- Game: Game: AppID 742420

-- MAIN APPLICATION
addappid(742420)
-- Game: addappid(742420)

-- MAIN APP DEPOTS / PACKAGES
addappid(742421, 1, "88a9d9035d4e3901137c2dee72a0d793e82eef65ab3bb4a955807a1fc7ad656a")
addappid(742422, 1, "f1d350a42b978755d26493fa6da74f910b4865d9b637122b1d297a937c7a9f9b")
