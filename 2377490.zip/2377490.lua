-- Lua provided by RyzenAPI
-- Game: Psychiatric Hospital

-- MAIN APPLICATION
addappid(2377490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2377491, 1, "8167d7e0573197718c67111172cc22567304f021c85400d6981fe9971f9cf1b6")

