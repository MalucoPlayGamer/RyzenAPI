-- Lua provided by RyzenAPI 
-- Game: Psychiatric Hospital
addappid(2377490)
addappid(2377491, 1, "8167d7e0573197718c67111172cc22567304f021c85400d6981fe9971f9cf1b6")
