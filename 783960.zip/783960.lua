-- Lua provided by RyzenAPI
-- Game: Forgotten Sound 2: Destiny

-- MAIN APPLICATION
addappid(783960)

-- MAIN APP DEPOTS / PACKAGES
addappid(783961, 1, "87e3ab312072c432296fade4fc8cf8ee067ba614075749e603bcdc2773dc1546")

