-- Lua provided by RyzenAPI
-- Game: addappid(310530)

-- MAIN APPLICATION
addappid(310530)

-- MAIN APP DEPOTS / PACKAGES
addappid(310531, 1, "0bf0a046af153b88cb451a768c64e6ac4caea9a8b908a9954eb6271027562474")
