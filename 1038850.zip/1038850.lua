-- Lua provided by RyzenAPI
-- Game: Game: Boom! Boom!

-- MAIN APPLICATION
addappid(1038850)
-- Game: addappid(1038850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038851, 1, "3fdd83904911eb58aad19859a739885db6211bf5db9faafd0c62835fe7e28387")
