-- Lua provided by RyzenAPI 
-- Game: Cento Original Soundtrack
addappid(2999520)
addappid(2999521, 1, "bcf640fed5fbdf9afaf9978a83a5f3bdb849427e78eb537466ddb410789ea82b")
addappid(2999522, 1, "1489457c7e27b3cb4af1fd406ee2c58389e5db0ca91dc0b18ee180532594b3cb")
