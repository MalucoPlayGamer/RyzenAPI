-- Lua provided by SkyAPI 
-- Game: AppID 1433490
addappid(1433490)
addappid(1433491, 1, "eac2d74b739e01bb8ae11e250d8337f1e39e6cb7e6f41f4d4e292ebb44093740")
