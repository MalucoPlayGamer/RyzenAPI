-- Lua provided by RyzenAPI
-- Game: Rubber Royale: Holiday Prologue

-- MAIN APPLICATION
addappid(2589790)
-- Game: addappid(2589790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589791, 1, "0e49f1428c8a5a33ecac0455bad505efb565217be6f434e9bfa598ef54e7f8de")
