-- Lua provided by RyzenAPI
-- Game: Rubber Royale: Holiday Prologue

-- MAIN APPLICATION
addappid(2589790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2589791, 1, "0e49f1428c8a5a33ecac0455bad505efb565217be6f434e9bfa598ef54e7f8de")

