-- Lua provided by RyzenAPI
-- Game: Brilliant Bob

-- MAIN APPLICATION
addappid(368900)

-- MAIN APP DEPOTS / PACKAGES
addappid(368901, 1, "5bc76bedfdb27a8649596598e38af046fa40e529df6a85913e95e8caffec3c94")

