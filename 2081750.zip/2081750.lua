-- Lua provided by RyzenAPI
-- Game: The Tale of Bistun - Artbook

-- MAIN APPLICATION
addappid(2081750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081750,0,"ecf44a47b7872803e2dc9d020847716db5b6908aa5ddbbc008ece47a6e1840d2")

