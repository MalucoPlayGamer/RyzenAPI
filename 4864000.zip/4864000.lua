-- 4864000's Lua and Manifest Created by Hubcap Manifest
-- Terraforming Titans
-- Created: July 30, 2026 at 14:20:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4864000, 1, "23feb9b2245af919cf05ddde804e428b1bbac3451e85f64997083ba167cd0780") -- Terraforming Titans
-- MAIN APP DEPOTS
addappid(4864001, 1, "5ca441f4f592fd9a23721e8ee206bc996f3181b3cb2f56e0f509d315e9e64072") -- Depot 4864001
setManifestid(4864001, "1686881396630085683", 414868820)
addappid(4864002, 1, "8727b6efab3c152a10ef0a9a9f898c18f8989ea3abdcdcc13cee89e8c2ecd883") -- Depot 4864002
setManifestid(4864002, "5146511767930837619", 367134449)