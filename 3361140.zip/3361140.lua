-- Lua provided by RyzenAPI
-- Game: Game: AppID 3361140

-- MAIN APPLICATION
addappid(3361140)
-- Game: addappid(3361140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361141, 1, "38f23ccf4d58a8c2a06f8bbee0afb7357c31901d6aa688e70ebf487f69d11b96")
