-- Lua provided by RyzenAPI
-- Game: Game: Anvil Playtest

-- MAIN APPLICATION
addappid(2383950)
-- Game: addappid(2383950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383951, 1, "d0d2a76b71927a218ef36a3c895a008783f36427eabe5b6a46253ef25cfcdd25")
