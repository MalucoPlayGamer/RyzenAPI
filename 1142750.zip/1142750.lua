-- Lua provided by RyzenAPI
-- Game: BAFF 3

-- MAIN APPLICATION
addappid(1142750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142751, 1, "17dde06addc97972cc010acbea667c1213e4c65c3c5c236d62b261bdfe24fe36")

