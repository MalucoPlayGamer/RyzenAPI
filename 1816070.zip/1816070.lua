-- Lua provided by RyzenAPI
-- Game: ILLUMINATI

-- MAIN APPLICATION
addappid(1816070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1816071, 1, "c6e3d9426278328ceec475e40a706a1e0b988e37b7161e4c500bb6291e768011")

