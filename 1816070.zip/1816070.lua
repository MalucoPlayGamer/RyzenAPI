-- Lua provided by RyzenAPI 
-- Game: ILLUMINATI
addappid(1816070)
addappid(1816071, 1, "c6e3d9426278328ceec475e40a706a1e0b988e37b7161e4c500bb6291e768011")
