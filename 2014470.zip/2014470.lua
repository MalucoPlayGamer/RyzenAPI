-- Lua provided by RyzenAPI
-- Game: 2014470

-- MAIN APPLICATION
addappid(2014470)
-- Game: addappid(2014470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014471, 1, "96d8a73a7868cc684a816c75ae30a93a327f329f8654b1c4c3c7e7e76448e95c")
