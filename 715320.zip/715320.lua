-- Lua provided by RyzenAPI
-- Game: Legend of Egypt - Pharaohs Garden

-- MAIN APPLICATION
addappid(715320)

-- MAIN APP DEPOTS / PACKAGES
addappid(715321,0,"52cb2a8b29e7cb996178407a3a86c256f81545aadf26f5c771efc0777ca27d04")
addappid(715322,0,"c6ebf48fc782cd2709dcbea0215ab4d789a6d5ed0b1b8f0df93daf4e557389d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
