-- Lua provided by RyzenAPI
-- Game: Legend of Egypt - Pharaohs Garden

-- MAIN APPLICATION
addappid(715320)

-- MAIN APP DEPOTS / PACKAGES
addappid(715321,0,"52cb2a8b29e7cb996178407a3a86c256f81545aadf26f5c771efc0777ca27d04")
addappid(715322,0,"c6ebf48fc782cd2709dcbea0215ab4d789a6d5ed0b1b8f0df93daf4e557389d5")

