-- Lua provided by RyzenAPI
-- Game: Ball 2D: Soccer Online

-- MAIN APPLICATION
addappid(703940)
-- Game: addappid(703940)

-- MAIN APP DEPOTS / PACKAGES
addappid(703941, 1, "8cb205616e4989100c4d34b34215c7d4effa4ab84d8a91db30257779b923ab99")
addappid(703942, 1, "e9b2afe67995e2ee22575478334ed548cbaae34473f501229242b5ad6445219d")
