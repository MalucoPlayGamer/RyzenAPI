-- Lua provided by RyzenAPI
-- Game: addappid(461860)

-- MAIN APPLICATION
addappid(461860)

-- MAIN APP DEPOTS / PACKAGES
addappid(461861, 1, "644144123872c91dd25b28e813df9b1736095f2deb9171b9f4c971ea6a8dd41c")
