-- Lua provided by SkyAPI 
-- Game: Country Girl Keiko
addappid(1065940)
addappid(1065941, 1, "ea003dad8a718fad953de2a3640b76cff8cf54d084fc6cdbd8d23a1b2730a90c")
addappid(1065942, 1, "f9532fd2549dc8bb000d501a6e2b35a0b637ddd71d95ec8209d8cd5ae7356bd4")
addappid(1065943, 1, "daa8bb9e4632e27e37520a3f3bb36b34f2c167073f2827f5893172841ec5b19c")
