-- Lua provided by RyzenAPI
-- Game: Hentai Breaker

-- MAIN APPLICATION
addappid(1214490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214491, 1, "afe608ebfa4c9da88cc16eb86d66832cc5a41783f4be0cda7c02f274af016cda")
