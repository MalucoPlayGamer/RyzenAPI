-- Lua provided by RyzenAPI
-- Game: Game: 新叶旅者与少年的回忆

-- MAIN APPLICATION
addappid(2650800)
-- Game: addappid(2650800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650801, 1, "57c07bda1fafc6292272903fa1e2e638b4fad281950882343d4d5121e4fd6e26")
