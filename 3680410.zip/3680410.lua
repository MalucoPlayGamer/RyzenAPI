-- Lua provided by RyzenAPI
-- Game: Tears of Vanfell: New Beginning

-- MAIN APPLICATION
addappid(3680410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3680411, 1, "ec2f9558cecfdaa198c616df4bbd521969e751012a01589990d06de1d391d001")
