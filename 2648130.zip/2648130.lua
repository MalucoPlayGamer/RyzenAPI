-- Lua provided by RyzenAPI
-- Game: Game: Bugs N' Guns

-- MAIN APPLICATION
addappid(2648130)
-- Game: addappid(2648130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648131, 1, "62205f2861c25a97664f3eeb29a411b06527a92796c26af878571bba85ac6656")
