-- Lua provided by RyzenAPI
-- Game: Bugs N' Guns

-- MAIN APPLICATION
addappid(2648130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2648131, 1, "62205f2861c25a97664f3eeb29a411b06527a92796c26af878571bba85ac6656")

