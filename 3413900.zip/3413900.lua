-- Lua provided by RyzenAPI
-- Game: addappid(3413900)

-- MAIN APPLICATION
addappid(3413900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413901, 1, "e755fed28d82d8d9d84568a6f25c521714e738fcf9afd7c619c2d62190a8822d")
