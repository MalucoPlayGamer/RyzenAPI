-- Lua provided by RyzenAPI
-- Game: Robot Detour

-- MAIN APPLICATION
addappid(2666840)
-- Game: addappid(2666840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666841, 1, "696df327fa9f6badd845023f10636fd6539be91c527c9ba5a478590a143dea30")
