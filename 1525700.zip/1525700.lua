-- Lua provided by SkyAPI 
-- Game: Tavern Master
addappid(1525700)
addappid(1525701, 1, "148f2103f69eac632cc21e2946672efc48866c28e811cf4548c86d486585d13b")
addappid(1525702, 1, "7743d6c36c89910df1f23ba93a8f49d450afcdb31a0ce13da77477399a584a46")
addappid(1525703, 1, "8e39ceb3086a0d0f4c045ab2273ab1f838dbb58aaece0433256a307bdb8bc6b6")
addappid(3261130)
