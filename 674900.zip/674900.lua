-- Lua provided by RyzenAPI
-- Game: Toys Gun Fire Boom

-- MAIN APPLICATION
addappid(674900)

-- MAIN APP DEPOTS / PACKAGES
addappid(674901,0,"4cf69a64dd09dadc206f4ddd97879b54ad81fa7d4d8538b74b55db5f1039ef08")

