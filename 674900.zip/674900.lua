-- Lua provided by RyzenAPI
-- Game: Toys Gun Fire Boom

-- MAIN APPLICATION
addappid(674900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(674901,0,"4cf69a64dd09dadc206f4ddd97879b54ad81fa7d4d8538b74b55db5f1039ef08")

