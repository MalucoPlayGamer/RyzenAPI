-- Lua provided by RyzenAPI
-- Game: Zoey: Nightclub Secrets

-- MAIN APPLICATION
addappid(3271470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271471, 1, "8deb976c625731d0c7ba30d0eb127c2e88bebc4907e798a3f22974436c15668e")
