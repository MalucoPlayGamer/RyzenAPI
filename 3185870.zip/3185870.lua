-- Lua provided by RyzenAPI
-- Game: 3185870

-- MAIN APPLICATION
addappid(3185870)
-- Game: addappid(3185870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3185871, 1, "9cf2080decb38cbe704f66200b8b583a151c1e323e3baaaa01c6c947d81369d3")
