-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1658950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658950,0,"e4350e8f7b2da5093cf5fd27fa6eefbe72a9217f343147ff3b06cc4a6be025a6")

