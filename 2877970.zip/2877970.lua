-- Lua provided by RyzenAPI
-- Game: My Protogen Engineer - 18+ Adult Only Patch

-- MAIN APPLICATION
addappid(2877970)
-- Game: addappid(2877970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877970,0,"8aa121adb77af7a3b243747702002e66031133877c67255ec37700bc3c8e80e3")
