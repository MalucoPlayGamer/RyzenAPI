-- Lua provided by RyzenAPI
-- Game: Reassembly

-- MAIN APPLICATION
addappid(329130)

-- MAIN APP DEPOTS / PACKAGES
addappid(329131, 1, "267b3dfd646f701a44706c4e22f8421e859bb2b7ff264ea7106d9fdc833211a1")
addappid(329132, 1, "63e0e9e894fa57419db07435676963aac8963d11edf72ae09e240a4b2c19bf2b")
addappid(329133, 1, "616c4c2226f9daa40fa906a480d5f104b7a98ed5033d82d56903f9f7ce386721")
addappid(329134, 1, "c7121c008bde1b2a2a26448ca35f4a8b3d0f1a9652f6559c20025e83f11115fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1012980)
