-- Lua provided by SkyAPI 
-- Game: Seek and Seduce: Naomie
addappid(3764880)
addappid(3764881, 1, "2ced26981bd50f7860471640c4c01b0a58a03311986539010d5404bc44c543a3")
