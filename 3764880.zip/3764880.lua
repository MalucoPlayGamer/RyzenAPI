-- Lua provided by RyzenAPI
-- Game: Game: Seek and Seduce: Naomie

-- MAIN APPLICATION
addappid(3764880)
-- Game: addappid(3764880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3764881, 1, "2ced26981bd50f7860471640c4c01b0a58a03311986539010d5404bc44c543a3")
