-- Lua provided by SkyAPI 
-- Game: AppID 1678610
addappid(1678610)
addappid(1678611, 1, "f5104a81ddf74dd694e2e83ece6859637e1204feacf1fd1b027662a40c3e9b97")
