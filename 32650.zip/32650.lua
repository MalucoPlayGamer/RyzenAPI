-- Lua provided by RyzenAPI
-- Game: Game: AppID 32650

-- MAIN APPLICATION
addappid(32650)
-- Game: addappid(32650)

-- MAIN APP DEPOTS / PACKAGES
addappid(32651, 1, "50c9f1ec00bb05cd151f46b9ac2805031e36e78f001b09e20019ab3ad3c34d74")
