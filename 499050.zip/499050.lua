-- Lua provided by RyzenAPI
-- Game: AppID 499050

-- MAIN APPLICATION
addappid(499050)

-- MAIN APP DEPOTS / PACKAGES
addappid(499051, 1, "8a38fb02dc2b287402c88b902b3049068c0bd71b5b2d580f396050abe8be8fbf")

