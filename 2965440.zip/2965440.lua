-- Lua provided by RyzenAPI 
-- Game: AppID 2965440
addappid(2965440)
addappid(2965441, 1, "0d0e0118944573f73a440e2f5cc64896ce2871f74b1a3e366c08794ad237752d")
