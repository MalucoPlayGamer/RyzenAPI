-- Lua provided by RyzenAPI
-- Game: 501790

-- MAIN APPLICATION
addappid(501790)
-- Game: addappid(501790)

-- MAIN APP DEPOTS / PACKAGES
addappid(501791, 1, "164762d1f60f4d6d07afdf1501b9562617e32e0d46d6a0f73ab83ace95019a2d")
addappid(501792, 1, "125ba888b2602ffea37d3ee6123fcbf1da055d205339d6f4542d3f17caacddbd")
addappid(501793, 1, "37cb3eb9db4d50542ff406e5300a10a67a8e3783ca175da0d1cd86e0ecc622ad")
