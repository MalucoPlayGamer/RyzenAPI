-- Lua provided by RyzenAPI
-- Game: No Heroes Here

-- MAIN APPLICATION
addappid(696140)

-- MAIN APP DEPOTS / PACKAGES
addappid(696141, 1, "608b8b70d11aea741535f59bc3bced5edc7dab189a3309466dc17421589ac7d6")
