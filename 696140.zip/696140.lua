-- Lua provided by RyzenAPI
-- Game: No Heroes Here

-- MAIN APPLICATION
addappid(696140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(696141, 1, "608b8b70d11aea741535f59bc3bced5edc7dab189a3309466dc17421589ac7d6")

