-- Lua provided by RyzenAPI
-- Game: My Doctor is a Futanari

-- MAIN APPLICATION
addappid(1854140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854141, 1, "fb629c1ef9b44331aff87daae5dbb0e20a599b39f0f765ec9197d134fcd509b4")
