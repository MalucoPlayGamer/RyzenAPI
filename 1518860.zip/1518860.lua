-- Lua provided by RyzenAPI
-- Game: Gravel Gang

-- MAIN APPLICATION
addappid(1518860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518861, 1, "b4c356710c9c22638ae202b0aa840e9f702e03dfb6fdc3bb7a2673ed1d2054e7")
