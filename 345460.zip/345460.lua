-- Lua provided by RyzenAPI
-- Game: War of Omens

-- MAIN APPLICATION
addappid(345460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(345461, 1, "4738dbac6d95b07ea94c3aa5ddb92639f0b9409d0ff128ff153b01049b8b8d5e")
addappid(345462, 1, "6af42dcd9175da58875992ef59bcbf6af78b7e73531291bf4ce14749632c1986")
