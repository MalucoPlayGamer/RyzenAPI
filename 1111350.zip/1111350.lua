-- Lua provided by RyzenAPI
-- Game: Crystar - Sexy Bikini (Blue)

-- MAIN APPLICATION
addappid(1111350)
-- Game: addappid(1111350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111350,0,"be4efa437fe43ee248f65719377e5038ca14ff77a276e745df7dec7512a40376")
