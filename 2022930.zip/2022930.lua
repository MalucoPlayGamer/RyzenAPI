-- Lua provided by RyzenAPI
-- Game: WARCANA

-- MAIN APPLICATION
addappid(2022930)
addappid(3073620)
addappid(3073630)
addappid(3073640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2022931, 1, "d229c5081f104f5986426a1ca355121a5c09c23c0e90058b743c86b849a2cb6b")

