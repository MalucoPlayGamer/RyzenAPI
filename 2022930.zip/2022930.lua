-- Lua provided by RyzenAPI
-- Game: Game: WARCANA

-- MAIN APPLICATION
addappid(2022930)
-- Game: addappid(2022930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022931, 1, "d229c5081f104f5986426a1ca355121a5c09c23c0e90058b743c86b849a2cb6b")
