-- Lua provided by RyzenAPI 
-- Game: AppID 65400
addappid(65400)
addappid(65401, 1, "aab4c423f172e7d14a57ba905f1cf6447f632628764125b53840104c4f106769")
