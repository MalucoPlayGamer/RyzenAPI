-- Lua provided by RyzenAPI
-- Game: 65400

-- MAIN APPLICATION
addappid(65400)
-- Game: addappid(65400)

-- MAIN APP DEPOTS / PACKAGES
addappid(65401, 1, "aab4c423f172e7d14a57ba905f1cf6447f632628764125b53840104c4f106769")
