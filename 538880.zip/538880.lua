-- Lua provided by RyzenAPI
-- Game: addappid(538880)

-- MAIN APPLICATION
addappid(538880)

-- MAIN APP DEPOTS / PACKAGES
addappid(538881, 1, "08eb9f85471f6d51a7db2a4a04fbce3b906f5dfda6bc8fc4462fab99ff679ae7")
addappid(538882, 1, "cc334c0ee5740a52379267c346da24acd06a1621c9517437665d58e83cb64d9c")
addappid(538883, 1, "76e9d27efdc3d70cdadd0c28e3dabb72a24fc273a8a7e810ee0cd4129c5690e8")
