-- Lua provided by RyzenAPI
-- Game: 3219290

-- MAIN APPLICATION
addappid(3219290)
-- Game: addappid(3219290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219290,0,"5d65949003aae02b8f7d7489ed3b77f140ceb256747bfb3fd76f6f76ea7e3f57")
