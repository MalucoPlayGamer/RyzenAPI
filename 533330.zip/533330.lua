-- Lua provided by SkyAPI 
-- Game: Shut Eye
addappid(533330)
addappid(533331, 1, "73d44e486c5bac14fcb1521a116ffe9e026737d24ebdbc5c3fe8e69fd56f2603")
addappid(533332, 1, "c8180f51bb88e2e2f92bd10526672d88e9a2c9ace2b23e785c22ebd33f74866b")
addappid(533333, 1, "4f0bc867221d0e3165f1143bc4ec7c5423e32dca0554db98f3920521d352c807")
