-- Lua provided by RyzenAPI
-- Game: Game: AppID 2400400

-- MAIN APPLICATION
addappid(2400400)
-- Game: addappid(2400400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400401, 1, "75e0f75b3c3f0e1d57ad593ea564031fddef1018442ddd88e55e26656a87354e")
