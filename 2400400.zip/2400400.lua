-- Lua provided by SkyAPI 
-- Game: AppID 2400400
addappid(2400400)
addappid(2400401, 1, "75e0f75b3c3f0e1d57ad593ea564031fddef1018442ddd88e55e26656a87354e")
