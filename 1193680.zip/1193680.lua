-- Lua provided by RyzenAPI
-- Game: 1193680

-- MAIN APPLICATION
addappid(1193680)
-- Game: addappid(1193680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193681, 1, "9017dd236b8f6bcd5fbe39b448c496009013d76fa2ef011902d63635a4c91dd3")
