-- Lua provided by RyzenAPI
-- Game: Alien Invasion 3D part 2

-- MAIN APPLICATION
addappid(1193680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1193681, 1, "9017dd236b8f6bcd5fbe39b448c496009013d76fa2ef011902d63635a4c91dd3")

