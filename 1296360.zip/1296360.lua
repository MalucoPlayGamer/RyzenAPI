-- Lua provided by RyzenAPI 
-- Game: Archvale
addappid(1296360)
addappid(1296361, 1, "cd8bd502bab629ae4c436ea94afeb2370b50ec2cc8919f583bc3989b20b46edc")
