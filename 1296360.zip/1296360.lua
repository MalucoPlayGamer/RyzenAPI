-- Lua provided by RyzenAPI
-- Game: Game: Archvale

-- MAIN APPLICATION
addappid(1296360)
-- Game: addappid(1296360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296361, 1, "cd8bd502bab629ae4c436ea94afeb2370b50ec2cc8919f583bc3989b20b46edc")
