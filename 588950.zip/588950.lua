-- Lua provided by RyzenAPI
-- Game: Game: Kingsway

-- MAIN APPLICATION
addappid(588950)
-- Game: addappid(588950)

-- MAIN APP DEPOTS / PACKAGES
addappid(588951, 1, "b5cc60718097a56ab52462d040f511e5948933c74353e44173a6e64b056ee036")
