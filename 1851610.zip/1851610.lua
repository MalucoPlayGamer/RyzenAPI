-- Lua provided by RyzenAPI
-- Game: River Tails: Stronger Together

-- MAIN APPLICATION
addappid(1851610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851611, 1, "0433750bab63572df54610d462657fb0ac98292cccb61c9198384c77954148d8")

