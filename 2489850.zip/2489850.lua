-- Lua provided by RyzenAPI
-- Game: Slave Lords Of The Galaxy

-- MAIN APPLICATION
addappid(2489850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489851, 1, "8f3319a955753c85c637672a86085f44625de2d213462f1ea3e05621250435ec")

