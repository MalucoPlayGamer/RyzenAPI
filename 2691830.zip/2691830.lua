-- Lua provided by SkyAPI 
-- Game: ASTRA
addappid(2691830)
addappid(2691831, 1, "88fd50d4898f68bc5ad29b6a86a2c17f033ada8a898d5e703e4824db51e9e34a")
