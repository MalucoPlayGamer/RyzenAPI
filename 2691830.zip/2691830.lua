-- Lua provided by RyzenAPI
-- Game: ASTRA

-- MAIN APPLICATION
addappid(2691830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691831, 1, "88fd50d4898f68bc5ad29b6a86a2c17f033ada8a898d5e703e4824db51e9e34a")
