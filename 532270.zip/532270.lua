-- Lua provided by RyzenAPI 
-- Game: AppID 532270
addappid(532270)
addappid(532271, 1, "a2afd7404bb1fc3e2df7012d77d8c2d808b0661e2ac2a0192a32b95f425ca1c5")
