-- Lua provided by RyzenAPI
-- Game: Home and Dungeon

-- MAIN APPLICATION
addappid(1395850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395852,0,"f128558502d54b849f00e913a707846b6a07718a168693b9d17edf1a1366b811")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1508560)
