-- Lua provided by RyzenAPI
-- Game: The Succubi Trap

-- MAIN APPLICATION
addappid(729320)

-- MAIN APP DEPOTS / PACKAGES
addappid(729321,0,"41567b9d7f6b47f53ecd41f8b66f7b759d5355f0de06b68dbe5612bc75278c03")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
