-- Lua provided by RyzenAPI
-- Game: The Succubi Trap

-- MAIN APPLICATION
addappid(729320)

-- MAIN APP DEPOTS / PACKAGES
addappid(729321,0,"41567b9d7f6b47f53ecd41f8b66f7b759d5355f0de06b68dbe5612bc75278c03")

