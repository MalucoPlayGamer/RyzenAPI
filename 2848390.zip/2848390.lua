-- Lua provided by RyzenAPI
-- Game: Nine Lives Ninja: Explore!

-- MAIN APPLICATION
addappid(2848390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848391, 1, "c6885eb0c85fe0003e550845066627b675760aa0b679cd2b42f96529349e1d8e")
