-- Lua provided by RyzenAPI
-- Game: addappid(2098560)

-- MAIN APPLICATION
addappid(2098560)
addappid(2098564)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098563,0,"b8bd84cb078b1be3d019a4375a0584f3b126ba9532df581437bddf89b20d045b")
