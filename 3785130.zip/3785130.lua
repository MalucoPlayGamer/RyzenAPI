-- Lua provided by RyzenAPI
-- Game: Shop Mistress NTR

-- MAIN APPLICATION
addappid(3785130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3785131, 1, "2e85f5a855a4c29b2f27b04f3f0c5fdfb025fa607c5d5864682e2015b8e6bd6e")

