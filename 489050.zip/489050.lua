-- Lua provided by RyzenAPI
-- Game: Whitetail Challenge

-- MAIN APPLICATION
addappid(489050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(489052,0,"424849f4f499677b7aefa5b32d02e8c306157344c192f7cce2fb0fa03c9954de")

