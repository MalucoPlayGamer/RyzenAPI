-- Lua provided by RyzenAPI
-- Game: addappid(489050)

-- MAIN APPLICATION
addappid(489050)

-- MAIN APP DEPOTS / PACKAGES
addappid(489052,0,"424849f4f499677b7aefa5b32d02e8c306157344c192f7cce2fb0fa03c9954de")
