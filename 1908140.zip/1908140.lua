-- Lua provided by RyzenAPI
-- Game: Game: Escape : Lia

-- MAIN APPLICATION
addappid(1908140)
-- Game: addappid(1908140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908141, 1, "607210813104a4327909ff40d1bb9173c4fcab50e849a572fa6a07943752e2b5")
