-- Lua provided by RyzenAPI
-- Game: Ash of Legends

-- MAIN APPLICATION
addappid(1280290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280291, 1, "6366b86e95fd48d184718dafdf7e95edabfa33bbadd0a96f8ac70a6f5dc876be")

