-- Lua provided by RyzenAPI
-- Game: Escape from Monkey Island™

-- MAIN APPLICATION
addappid(730830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(730831, 1, "2f4ec82d87ce95880ed92c3f9dc3c17fe551294ea10e0bd1327ae028f69011e9")
addappid(730832, 1, "afbf7134e079dda0004014038bfffb0cf46a5d75ea44ccd01773a1c71dece37b")
addappid(730833, 1, "9848b2f5b5298f2e5ba203afbac07c2163d7fc533589e578fa146f5ff357a1b6")
addappid(730834, 1, "a68c0983095a7e3c0e2f395a1e57b08ce281e9a0de46b159d2bd8791106ea9ee")
addappid(730835, 1, "862a43a973628e483115e14fa0fe5cba32f4d2113aede07e39d310d46e8e079e")
addappid(730836, 1, "bd7e816c1e77a922dd1dc7cc82255f60d871f7f7b661a4c32e22d03629ddb3d2")
