-- Lua provided by RyzenAPI
-- Game: Good Boy!

-- MAIN APPLICATION
addappid(840440)
-- Game: addappid(840440)

-- MAIN APP DEPOTS / PACKAGES
addappid(840441, 1, "c3378b4f0132093351be09765f95e59f3822b006a50d9d849b17c85c949d4725")
