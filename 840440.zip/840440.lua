-- Lua provided by SkyAPI 
-- Game: Good Boy!
addappid(840440)
addappid(840441, 1, "c3378b4f0132093351be09765f95e59f3822b006a50d9d849b17c85c949d4725")
