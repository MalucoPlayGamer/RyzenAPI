-- Lua provided by RyzenAPI
-- Game: Fight Me Bro!

-- MAIN APPLICATION
addappid(533630)

-- MAIN APP DEPOTS / PACKAGES
addappid(533631,0,"ed30640a2f783c3ab05d819f78afa561f9c84492e35fc201195cb2aea54700b2")

