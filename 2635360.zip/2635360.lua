-- Lua provided by RyzenAPI
-- Game: addappid(2635360)

-- MAIN APPLICATION
addappid(2635360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635361, 1, "cdbb3439e1b6dc27141d0fbbad30a691ef7f8817bc8918af5765802d4c3f5204")
