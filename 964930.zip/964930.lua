-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(964930)

-- MAIN APP DEPOTS / PACKAGES
addappid(964930,0,"8d6e1a8b596db24106b4cd82eece26e010f10b926c0bb21bf5b1e381c3825cfb")

