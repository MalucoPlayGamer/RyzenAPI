-- 4024870's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Valentine is streaming
-- Created: June 13, 2026 at 02:31:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4024870) -- Hentai Clicker: Valentine is streaming
-- MAIN APP DEPOTS
addappid(4024871, 1, "42145de1731642e3aa14cd46265ba9a96b82e34830c398030c4e63a630f5f002") -- Depot 4024871
setManifestid(4024871, "8911814620420055953", 160537476)