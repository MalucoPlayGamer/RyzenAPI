-- Lua provided by RyzenAPI
-- Game: addappid(539460)

-- MAIN APPLICATION
addappid(539460)

-- MAIN APP DEPOTS / PACKAGES
addappid(539461, 1, "8a9816c65ffda433d70c9d0b79d5075b01fcf34561241d1ea66233287e49b562")
