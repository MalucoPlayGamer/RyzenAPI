-- Lua provided by RyzenAPI
-- Game: addappid(3640770)

-- MAIN APPLICATION
addappid(3640770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3640770,0,"e4584bcdb271e8a7d43b77bef0cd13e2cdc0fd67baaa2187168c55bcb4ba8a4f")
