-- Lua provided by RyzenAPI
-- Game: Game: Spilled! Soundtrack

-- MAIN APPLICATION
addappid(3503730)
-- Game: addappid(3503730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3503731, 1, "25aae1a39cded11d42c5068cfb769feb9c7a990672a8e39df6e6602db9ccf543")
