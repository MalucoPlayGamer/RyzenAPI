-- Lua provided by RyzenAPI
-- Game: AppID 323130

-- MAIN APPLICATION
addappid(323130)
-- Game: addappid(323130)

-- MAIN APP DEPOTS / PACKAGES
addappid(323131, 1, "bab7905675576ecf82c397a0e1bbf233f9e1236c3aae0e4c01fa9687e810fa14")
addappid(323132, 1, "568d19f7e73828f11531c951e5c8a730153d0fed30eb415066daab1cbf7a3bb9")
