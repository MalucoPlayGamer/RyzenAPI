-- Lua provided by RyzenAPI
-- Game: 824550

-- MAIN APPLICATION
addappid(824550)
addappid(1938440)
addappid(1938441)
addappid(1938442)
addappid(1938443)
addappid(1938444)
addappid(1938445)
addappid(1938446)
addappid(1938450)
addappid(1938451)
addappid(1938452)
addappid(1938453)
addappid(1938454)
addappid(1938455)
addappid(1938456)
addappid(2231720)
addappid(2291030)
-- Game: addappid(824550)

-- MAIN APP DEPOTS / PACKAGES
addappid(824551, 1, "d7322acca8725452a82e5121292fd903e830f8a91921e30a735b09ec79c9df51")
