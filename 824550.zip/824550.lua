-- Lua provided by RyzenAPI
-- Game: AppID 824550

-- MAIN APPLICATION
addappid(824550)
addappid(1938440)
addappid(1938441)
addappid(1938442)
addappid(1938443)
addappid(1938444)
addappid(1938445)
addappid(1938446)
addappid(1938450)
addappid(1938451)
addappid(1938452)
addappid(1938453)
addappid(1938454)
addappid(1938455)
addappid(1938456)
addappid(2231720)
addappid(2291030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(824551, 1, "d7322acca8725452a82e5121292fd903e830f8a91921e30a735b09ec79c9df51")

