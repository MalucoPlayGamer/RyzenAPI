-- Lua provided by RyzenAPI
-- Game: Recycling Center Simulator Demo

-- MAIN APPLICATION
addappid(2975280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975281, 1, "db61a650c25a06b50b1df6b68038d97bd4aa07bd904c5680edfcf2320e379c85")
