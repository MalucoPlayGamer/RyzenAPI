-- Lua provided by RyzenAPI
-- Game: Battle Teams 2

-- MAIN APPLICATION
addappid(1969870)
addappid(2705310)
addappid(2732030)
addappid(2732040)
addappid(2786230)
addappid(2800180)
addappid(2800190)
addappid(2800200)
addappid(2800270)
addappid(2947600)
addappid(3001700)
addappid(3001710)
addappid(3036990)
addappid(4467400)
addappid(4483820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969871, 1, "eb562f797b101b9491cff7e022f4123054a914f556f5c23ebb32a79d443f4cea")
addappid(1969872, 1, "9f1e43c5ae4423baad6bb759be69ecef6ee3e8214f48a85456b3b6aa55bd8a1a")

