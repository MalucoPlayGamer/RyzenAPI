-- Lua provided by RyzenAPI
-- Game: Hentai World: Animated Puzzle

-- MAIN APPLICATION
addappid(1691360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691361, 1, "a6f96dd89a9296c05bcb2016aba2c7a8e5d6ee12eeab875333ac506480ee1a7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
