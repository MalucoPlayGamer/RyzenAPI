-- Lua provided by RyzenAPI
-- Game: Battlezone 98 Redux

-- MAIN APPLICATION
addappid(301650)
addappid(470750)

-- MAIN APP DEPOTS / PACKAGES
addappid(301651, 1, "630b891df838326614dcc7ef4fdecd0ba39ee2f80415032aa2b92e71f4a9a407")
addappid(301652, 1, "c5989798e72e617a4104f8bde57b2a79da9bbb590b27b5021f4a1afb057d1fbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
