-- Lua provided by RyzenAPI
-- Game: DEEMO -Reborn- Prime Pack II

-- MAIN APPLICATION
addappid(1307540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307543,0,"424f412e729cf2b6569a22934d6b8ee6a40d77f62c07dcf35aa6525084052cce")
addappid(1307544,0,"17e383027d6ca624452a9f3d23d98ecac1d3bb6cbdfafc52ccae6b01f108d729")
