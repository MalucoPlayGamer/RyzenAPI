-- Lua provided by RyzenAPI
-- Game: 2517100

-- MAIN APPLICATION
addappid(2517100)
-- Game: addappid(2517100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517101, 1, "9aadef8c5e06f855ea0cb1f95ee0815c339c9b3addf1586f01e231e6637edd4c")
