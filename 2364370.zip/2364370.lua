-- Lua provided by RyzenAPI
-- Game: addappid(2364370)

-- MAIN APPLICATION
addappid(2364370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364372,0,"a0af6967e88adcd736dea528f63dd6b0a462f919a4d15152cbf290e614af44be")
