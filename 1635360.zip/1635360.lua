-- Lua provided by RyzenAPI
-- Game: 1635360

-- MAIN APPLICATION
addappid(1635360)
-- Game: addappid(1635360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635361, 1, "924d03db7174320d18c12b4a4958c08b6275ea5da08a219e7dc31acf83544d44")
addappid(1635362, 1, "d0860824aa0c13b7e66cfd8c3bbc5cb5038f23c1a50362abbbe4cb63f309f784")
