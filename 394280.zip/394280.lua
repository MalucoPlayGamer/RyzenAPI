-- Lua provided by RyzenAPI
-- Game: Dark Heritage: Guardians of Hope

-- MAIN APPLICATION
addappid(394280)

-- MAIN APP DEPOTS / PACKAGES
addappid(394281, 1, "2c611dc204a7ee81792180a006ef430f5578368ea33490f126999b61483dd2cf")

