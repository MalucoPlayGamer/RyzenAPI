-- Lua provided by RyzenAPI
-- Game: Phantom Brave PC

-- MAIN APPLICATION
addappid(409870)

-- MAIN APP DEPOTS / PACKAGES
addappid(409871, 1, "003e880a3907083a9557253e7deb6e6762fa8882ebfd6f68d200c2a54a100a42")
addappid(409872, 1, "0f87287a87687fe632e5b050da4420eab7588dcd6eca84a5b9742960debf91a6")
addappid(409873, 1, "62b8854051b02e08275b204486bb4f33c5e375989ac3d7895a7ef98b691483cb")
addappid(475010, 0, "82217b66b0e7270d8de03f771d1984ca2345702e3afd799adcbcfad90ac384b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
