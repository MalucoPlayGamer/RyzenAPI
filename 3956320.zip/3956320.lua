-- Lua provided by RyzenAPI
-- Game: Inotia 4

-- MAIN APPLICATION
addappid(3956320)

