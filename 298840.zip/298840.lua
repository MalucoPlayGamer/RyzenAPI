-- Lua provided by RyzenAPI 
-- Game: Millennium 4 - Beyond Sunset
addappid(298840)
addappid(298841, 1, "96f6376ea414c3a49f8de832216fa1da125524a11ed4a049d1b62d588b0fc9b4")
addappid(357090, 0, "72c7c04961e31f8a14f7d9e960926f2528ce1a125e19ad1300d14fb85264c149")
