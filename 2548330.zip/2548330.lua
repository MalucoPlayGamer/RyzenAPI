-- Lua provided by RyzenAPI
-- Game: AppID 2548330

-- MAIN APPLICATION
addappid(2548330)
addappid(2594990)
addappid(2753360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2548331, 1, "f1e601ac187013ee4d3773e098dc1ca9b151d6d3a123b7065c7547108617ae4d")

