-- Lua provided by RyzenAPI 
-- Game: AppID 2548330
addappid(2548330)
addappid(2548331, 1, "f1e601ac187013ee4d3773e098dc1ca9b151d6d3a123b7065c7547108617ae4d")
