-- Lua provided by RyzenAPI
-- Game: War of Dots

-- MAIN APPLICATION
addappid(3902430)
addappid(4626610)

