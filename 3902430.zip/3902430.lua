-- Lua provided by RyzenAPI
-- Game: War of Dots

-- MAIN APPLICATION
addappid(3902430)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4626610)
