-- Lua provided by SkyAPI 
-- Game: COLLECTION of SaGa FINAL FANTASY LEGEND
addappid(1642620)
addappid(1642621, 1, "37e5c69516ba3fe109dd57a96a172e4f586356fa6fcc47efe6ac465cb2370b1a")
