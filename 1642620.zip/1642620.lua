-- Lua provided by RyzenAPI
-- Game: COLLECTION of SaGa FINAL FANTASY LEGEND

-- MAIN APPLICATION
addappid(1642620)
addappid(1775030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1642621, 1, "37e5c69516ba3fe109dd57a96a172e4f586356fa6fcc47efe6ac465cb2370b1a")

