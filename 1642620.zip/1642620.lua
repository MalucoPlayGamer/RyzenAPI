-- Lua provided by RyzenAPI
-- Game: 1642620

-- MAIN APPLICATION
addappid(1642620)
-- Game: addappid(1642620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642621, 1, "37e5c69516ba3fe109dd57a96a172e4f586356fa6fcc47efe6ac465cb2370b1a")
