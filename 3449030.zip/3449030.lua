-- Lua provided by RyzenAPI
-- Game: addappid(3449030)

-- MAIN APPLICATION
addappid(3449030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449031, 1, "986e02f38adf7ce7ee4c63600ea35ffa8f2905de5d7752e7dfab3ad747e02c93")
