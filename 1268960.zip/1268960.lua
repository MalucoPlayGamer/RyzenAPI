-- Lua provided by RyzenAPI
-- Game: pureya

-- MAIN APPLICATION
addappid(1268960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1268961, 1, "31f68aaaf0151832fdd440059939ad7359eaef685d70e576bba8893410b625a7")
addappid(1268962, 1, "be40b4715facbcf32fdc400decd1a524e8f41dbb81ace54512b85d97ae135332")
addappid(1268963, 1, "48b7db3c029d985354f6d79619f33ce5c7ab15dd2c6277adf6cd6cd0eea9ce90")
addappid(1268964, 1, "8c44148fbc9c5d1d65be12bfd2c1814acc1d1d1f10c83753a1a978ae4d747178")

