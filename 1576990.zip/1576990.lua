-- Lua provided by RyzenAPI
-- Game: 1576990

-- MAIN APPLICATION
addappid(1576990)
-- Game: addappid(1576990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576991, 1, "649dbd865d5bc363bbc7935104eb5b4509a5e6da26fa07f1cc0a31001aa48e3e")
