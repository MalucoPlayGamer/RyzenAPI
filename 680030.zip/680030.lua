-- Lua provided by RyzenAPI
-- Game: Gone Viral

-- MAIN APPLICATION
addappid(680030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(680031, 1, "da05899e5ee44ae72a492ad6e780b830444b6083c4a5aa8a5c9ed30eb1c05e64")

