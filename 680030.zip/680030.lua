-- Lua provided by SkyAPI 
-- Game: AppID 680030
addappid(680030)
addappid(680031, 1, "da05899e5ee44ae72a492ad6e780b830444b6083c4a5aa8a5c9ed30eb1c05e64")
