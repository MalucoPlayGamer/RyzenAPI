-- Lua provided by RyzenAPI
-- Game: Deskworm

-- MAIN APPLICATION
addappid(4044170)
addappid(4697040)
addappid(4772500)
addappid(4772520)

