-- Lua provided by RyzenAPI
-- Game: Deskworm

-- MAIN APPLICATION
addappid(4044170)
