-- Lua provided by RyzenAPI
-- Game: Horizon Chase Turbo

-- MAIN APPLICATION
addappid(389140)

-- MAIN APP DEPOTS / PACKAGES
addappid(389141, 1, "b701d7dd3a6c31a23eaa83ded7b72728699ba4d822037d08c55f33ab6c04a498")
addappid(389142, 1, "d411057b24124869c0eb400d3298373e0cfa0a51934b950b9550c7a5d6772995")
addappid(389143, 1, "fc18f2da47813fa2532d41ac24491b7e359c77694ccd11b9f4e518a549752b56")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1137940)
addappid(1174880)
addappid(1608540)
