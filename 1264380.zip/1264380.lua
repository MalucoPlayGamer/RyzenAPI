-- Lua provided by RyzenAPI
-- Game: Lonely Mountains: Downhill Demo

-- MAIN APPLICATION
addappid(1264380)
-- Game: addappid(1264380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264381, 1, "39361790e456bddb595d5cd7f012d0752204385a674a63eed962ae7ac42b43ec")
