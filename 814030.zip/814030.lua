-- Lua provided by RyzenAPI
-- Game: Queen's Quest 4: Sacred Truce

-- MAIN APPLICATION
addappid(814030)
-- Game: addappid(814030)

-- MAIN APP DEPOTS / PACKAGES
addappid(814031, 1, "92f1332d8173e8f01fbf91ad293fe4d664b96fbb091104f78549786c51c7c45a")
