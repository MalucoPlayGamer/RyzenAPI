-- Lua provided by RyzenAPI
-- Game: Summer times Afternoon

-- MAIN APPLICATION
addappid(568800)

-- MAIN APP DEPOTS / PACKAGES
addappid(568801,0,"028b1bebe602a9ef6572c2065210b4476f03f618e5c0ccc36784e66a12981d38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
