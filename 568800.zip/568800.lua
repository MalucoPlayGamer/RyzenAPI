-- Lua provided by RyzenAPI
-- Game: Summer times Afternoon

-- MAIN APPLICATION
addappid(568800)

-- MAIN APP DEPOTS / PACKAGES
addappid(568801,0,"028b1bebe602a9ef6572c2065210b4476f03f618e5c0ccc36784e66a12981d38")

