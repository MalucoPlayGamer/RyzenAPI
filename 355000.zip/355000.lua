-- Lua provided by RyzenAPI
-- Game: addappid(355000)

-- MAIN APPLICATION
addappid(355000)

-- MAIN APP DEPOTS / PACKAGES
addappid(355001, 1, "ef57d2150b3770acd5d1342a6382f227c31348ddf48d7583c2bbbab0c604ca87")
