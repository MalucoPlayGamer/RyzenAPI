-- Lua provided by RyzenAPI
-- Game: GlassWire

-- MAIN APPLICATION
addappid(355000)

-- MAIN APP DEPOTS / PACKAGES
addappid(355001, 1, "ef57d2150b3770acd5d1342a6382f227c31348ddf48d7583c2bbbab0c604ca87")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(384530)
addappid(384531)
addappid(384532)
