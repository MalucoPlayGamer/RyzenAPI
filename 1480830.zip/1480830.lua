-- Lua provided by RyzenAPI
-- Game: Game: Evil Tonight

-- MAIN APPLICATION
addappid(1480830)
-- Game: addappid(1480830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480831, 1, "4cd75d180271a7c0a07fd0f90de60d71399ef979c60bec860f7c8ae3db058dac")
