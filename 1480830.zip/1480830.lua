-- Lua provided by RyzenAPI
-- Game: Evil Tonight

-- MAIN APPLICATION
addappid(1480830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1480831, 1, "4cd75d180271a7c0a07fd0f90de60d71399ef979c60bec860f7c8ae3db058dac")

