-- Lua provided by RyzenAPI
-- Game: Noctuary Original Soundtrack

-- MAIN APPLICATION
addappid(2696340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696342,0,"5d46a8e421e8eee6da3fd70e8eaa638aa496db6091e32fdd64ae854e8a1adaf2")
addappid(2696343,0,"9045d0690a5064bb75c4d89499f5b42825e43f57ddc92127228a980b7702ff44")
