-- Lua provided by RyzenAPI
-- Game: Nigate Tale

-- MAIN APPLICATION
addappid(1048350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1048351, 1, "bba11e728718bd5b261407b3dc4592eaf36ba60665af5f27411b638e3733daf5")
addappid(1048352, 1, "fd59b597b19381ab889c44cf1cc0fe66da99920098126f6a4cad2a16ecb21c3e")

