-- Lua provided by RyzenAPI
-- Game: 1901780

-- MAIN APPLICATION
addappid(1901780)
-- Game: addappid(1901780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901784,0,"e393219eaf96e55aaea467c555513b20e1e4434ea333a5d9ea4fb4833e9cf541")
