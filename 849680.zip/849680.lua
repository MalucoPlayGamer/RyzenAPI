-- Lua provided by RyzenAPI
-- Game: Game: AppID 849680

-- MAIN APPLICATION
addappid(849680)
-- Game: addappid(849680)

-- MAIN APP DEPOTS / PACKAGES
addappid(849681, 1, "5e7382f51fed0a24ee8f34c0b5ecd2c2d7a043f673b4c94b18b0a5261576b402")
addappid(849682, 1, "308652bfaa8ec707145cabfe0a6f6458f2aa4db7c13c7c2f924d28b98e16069d")
addappid(849683, 1, "8643952e7f5153b18dbf52033f4f804c805ca7bad393b68ce59f5700ea98c935")
