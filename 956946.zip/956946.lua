-- Lua provided by RyzenAPI
-- Game: 956946

-- MAIN APPLICATION
addappid(956946)
-- Game: addappid(956946)

-- MAIN APP DEPOTS / PACKAGES
addappid(956946,0,"47021608db29d399338fddbc5d6243eaeb499283580fbfc379078e619bbefe9f")
