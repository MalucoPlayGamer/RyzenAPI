-- Lua provided by RyzenAPI
-- Game: Fa Zheng - Officer Ticket / 法正使用券

-- MAIN APPLICATION
addappid(956946)

-- MAIN APP DEPOTS / PACKAGES
addappid(956946,0,"47021608db29d399338fddbc5d6243eaeb499283580fbfc379078e619bbefe9f")

