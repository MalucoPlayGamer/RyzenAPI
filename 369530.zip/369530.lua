-- Lua provided by RyzenAPI
-- Game: Game: Void Destroyer 2

-- MAIN APPLICATION
addappid(369530)
-- Game: addappid(369530)

-- MAIN APP DEPOTS / PACKAGES
addappid(369531, 1, "8e331659c4e3a7685d6d17007f10b96b52c93d044842586e498a8b590703a6e7")
addappid(1322250, 0, "91962446eeebf30ee66b2ca653d62c5caba9f286234d705cba0e96ad15d97f2f")
addappid(1383180, 0, "19cc441993fc8e2b6f5f509eca6aac4ac45792043a6f178188d01d433a7a8135")
