-- Lua provided by RyzenAPI
-- Game: Void Destroyer 2

-- MAIN APPLICATION
addappid(369530)

-- MAIN APP DEPOTS / PACKAGES
addappid(369531, 1, "8e331659c4e3a7685d6d17007f10b96b52c93d044842586e498a8b590703a6e7")
addappid(1322250, 0, "91962446eeebf30ee66b2ca653d62c5caba9f286234d705cba0e96ad15d97f2f")
addappid(1383180, 0, "19cc441993fc8e2b6f5f509eca6aac4ac45792043a6f178188d01d433a7a8135")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
