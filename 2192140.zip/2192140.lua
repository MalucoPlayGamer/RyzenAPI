-- Lua provided by RyzenAPI
-- Game: Life No.0 Demo

-- MAIN APPLICATION
addappid(2192140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192141, 1, "6cbc7fd71b25410391d53a8c346c1678158ef9ad8c9c664814e34f91037da566")

