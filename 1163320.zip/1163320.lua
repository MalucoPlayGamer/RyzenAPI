-- Lua provided by RyzenAPI
-- Game: Zombie horde

-- MAIN APPLICATION
addappid(1163320)
-- Game: addappid(1163320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163321, 1, "f2a074edd27354c16e8677c73c5fd4fc4c79614ef5e2a03064116ad37378baaf")
