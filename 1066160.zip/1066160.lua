-- Lua provided by RyzenAPI
-- Game: addappid(1066160)

-- MAIN APPLICATION
addappid(1066160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066161, 1, "100b3be775499e66631a341e7face26f2cc26d2b45888aea43bfc3dc125771a8")
