-- Lua provided by RyzenAPI
-- Game: Captain Fly and Sexy Girls at the Night Club

-- MAIN APPLICATION
addappid(1066160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066161, 1, "100b3be775499e66631a341e7face26f2cc26d2b45888aea43bfc3dc125771a8")

