-- Lua provided by RyzenAPI
-- Game: Brazilian Adventure

-- MAIN APPLICATION
addappid(764880)

-- MAIN APP DEPOTS / PACKAGES
addappid(764881,0,"e97f025e10ea62339aa6ee6721ee3247acd253bbc1a91cf727555ce25e4c6e5d")

