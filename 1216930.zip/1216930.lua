-- Lua provided by RyzenAPI
-- Game: Vikings Wars

-- MAIN APPLICATION
addappid(1216930)
-- Game: addappid(1216930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216931, 1, "1e5e53118b69952a784f7ab7b33d59013d70afae0973952b1086af0b6bb01e9d")
