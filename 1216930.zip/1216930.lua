-- Lua provided by SkyAPI 
-- Game: Vikings Wars
addappid(1216930)
addappid(1216931, 1, "1e5e53118b69952a784f7ab7b33d59013d70afae0973952b1086af0b6bb01e9d")
