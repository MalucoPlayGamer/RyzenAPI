-- Lua provided by RyzenAPI
-- Game: Blackout - Early Access

-- MAIN APPLICATION
addappid(2461070)
-- Game: addappid(2461070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461071, 1, "a1cdc815109201b712cfcf036f512d418ccb6ff2ca3583fe4c2363d9bb89c6d9")
