-- Lua provided by RyzenAPI
-- Game: The Last Sigil

-- MAIN APPLICATION
addappid(228990)
addappid(632100)
addappid(632101)

-- MAIN APP DEPOTS / PACKAGES
addappid(632102,0,"1ed84b3163c560eff668c12ad36341736b4df1f9c4556bfb313a27b7affeb421")
