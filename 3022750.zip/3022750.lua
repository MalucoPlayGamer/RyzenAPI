-- Lua provided by RyzenAPI
-- Game: Game: Rune Stones

-- MAIN APPLICATION
addappid(3022750)
-- Game: addappid(3022750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022751, 1, "f5ed03784eae4aa791b96779e852de6f949763f9e1ff78053e042663460294cf")
