-- Lua provided by RyzenAPI
-- Game: WWE 2K BATTLEGROUNDS

-- MAIN APPLICATION
addappid(1142100)
addappid(1363630)
addappid(1363631)
addappid(1363632)
addappid(1544760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142101,0,"2fb5547f8c8e9b82c818cef8c908c4d1904b56a997e1a41c40c83a3a4e03ca1a")

