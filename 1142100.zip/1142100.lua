-- Lua provided by RyzenAPI
-- Game: Game: WWE 2K BATTLEGROUNDS

-- MAIN APPLICATION
addappid(1142100)
-- Game: addappid(1142100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142101, 1, "2fb5547f8c8e9b82c818cef8c908c4d1904b56a997e1a41c40c83a3a4e03ca1a")
