-- Lua provided by RyzenAPI
-- Game: WWE 2K BATTLEGROUNDS

-- MAIN APPLICATION
addappid(1142100)
addappid(1363630)
addappid(1363631)
addappid(1363632)
addappid(1544760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142101,0,"2fb5547f8c8e9b82c818cef8c908c4d1904b56a997e1a41c40c83a3a4e03ca1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
