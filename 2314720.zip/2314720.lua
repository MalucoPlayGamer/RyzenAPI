-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] Parasocial | パラソーシャル

-- MAIN APPLICATION
addappid(2314720)
-- Game: addappid(2314720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314721, 1, "f627302cb6e9725d117be8923be7440410f1c69d179f96e422a607dfcf4f24f8")
