-- Lua provided by RyzenAPI 
-- Game: San Matias - Mafia City
addappid(728830)
addappid(728831, 1, "aee7ebd40ac5e447b11f33d63ac9b84d989e4d4c86269af0bd33ef6f307c1e88")
