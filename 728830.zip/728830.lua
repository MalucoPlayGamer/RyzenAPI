-- Lua provided by RyzenAPI
-- Game: San Matias - Mafia City

-- MAIN APPLICATION
addappid(728830)
-- Game: addappid(728830)

-- MAIN APP DEPOTS / PACKAGES
addappid(728831, 1, "aee7ebd40ac5e447b11f33d63ac9b84d989e4d4c86269af0bd33ef6f307c1e88")
