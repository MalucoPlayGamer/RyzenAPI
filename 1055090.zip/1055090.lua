-- Lua provided by RyzenAPI
-- Game: Embark

-- MAIN APPLICATION
addappid(1055090)
-- Game: addappid(1055090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055091, 1, "66d304c52dd7f4be0c45fde9dfeeccb0dc1449ce3e6dc21bb37ca0bd1b37aaeb")
