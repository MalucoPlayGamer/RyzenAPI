-- Lua provided by RyzenAPI
-- Game: Game: Quantum Flux

-- MAIN APPLICATION
addappid(396610)
-- Game: addappid(396610)

-- MAIN APP DEPOTS / PACKAGES
addappid(396611, 1, "a32e3c688e116eacd4bd54636d87f82d7d7770977c5cc61238c54cb8ae30334e")
addappid(396620, 0, "3a06afa96802dd485b2fe3db408350d41f9097662cab12d6f224bf94bab18615")
