-- Lua provided by RyzenAPI
-- Game: Game: AppID 1300620

-- MAIN APPLICATION
addappid(1300620)
-- Game: addappid(1300620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300621, 1, "3801e744b1df458ee3251a11a73c0bf14b249c734b936ac61cebc8017c99ad1a")
