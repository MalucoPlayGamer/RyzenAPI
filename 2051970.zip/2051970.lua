-- Lua provided by RyzenAPI
-- Game: Disgaea 6 Complete - Digital Art Book

-- MAIN APPLICATION
addappid(2051970)
-- Game: addappid(2051970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051970,0,"21e0f12d187860fe3b67d369bd2180cad8669d2726c4b1eee68d2e3d0eb3b74d")
