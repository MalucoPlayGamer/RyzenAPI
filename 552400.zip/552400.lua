-- Lua provided by RyzenAPI
-- Game: Sweep'n'Sweep

-- MAIN APPLICATION
addappid(552400)

-- MAIN APP DEPOTS / PACKAGES
addappid(552401,0,"a7ef2382fdd5613760b6103e0b38abd4b7dacbd3c413cf388a14534554bf2851")

