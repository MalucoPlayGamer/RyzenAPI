-- Lua provided by RyzenAPI
-- Game: X Fugitive

-- MAIN APPLICATION
addappid(1776290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776293,0,"533330de09050622cbc6d75e1f28ed86afdfa93a2723877468f9ba7bc2def175")

