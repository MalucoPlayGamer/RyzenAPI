-- Lua provided by RyzenAPI
-- Game: AppID 631530

-- MAIN APPLICATION
addappid(631530)
-- Game: addappid(631530)

-- MAIN APP DEPOTS / PACKAGES
addappid(631531, 1, "5631956e6ed7db027eff3cd0ba917479108a7c8e37422b46686e6c09ae262bd6")
