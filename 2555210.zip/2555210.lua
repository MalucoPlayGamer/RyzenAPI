-- Lua provided by RyzenAPI
-- Game: 2555210

-- MAIN APPLICATION
addappid(2555210)
addappid(2555211)
-- Game: addappid(2555210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555210,0,"885a38b435517d0318bb515b802ec96ec8d9bc3db4cc240854bd12c6c8d6b966")
