-- Lua provided by RyzenAPI
-- Game: Do Not Feed the Monkeys 2099 - Four Cage Gourmet Pack

-- MAIN APPLICATION
addappid(2555210)
addappid(2555211)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555210,0,"885a38b435517d0318bb515b802ec96ec8d9bc3db4cc240854bd12c6c8d6b966")
