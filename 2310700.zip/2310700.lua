-- Lua provided by RyzenAPI
-- Game: addappid(2310700)

-- MAIN APPLICATION
addappid(2310700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310701, 1, "755facd04814a99ed35cddbe95fdf47e317d63159ef24b7ffdbab96b2f7925df")
