-- Lua provided by RyzenAPI
-- Game: Shadow Corridor 2 雨ノ四葩

-- MAIN APPLICATION
addappid(2310700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310701, 1, "755facd04814a99ed35cddbe95fdf47e317d63159ef24b7ffdbab96b2f7925df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3929690)
