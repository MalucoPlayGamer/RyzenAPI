-- Lua provided by RyzenAPI
-- Game: Chopper Battle New Horizon

-- MAIN APPLICATION
addappid(751870)
-- Game: addappid(751870)

-- MAIN APP DEPOTS / PACKAGES
addappid(751871, 1, "1f8f74f329caf62c20c81cd35168cf0ffab8898c4d3117d5ff57af49801197a0")
