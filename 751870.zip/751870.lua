-- Lua provided by RyzenAPI
-- Game: Chopper Battle New Horizon

-- MAIN APPLICATION
addappid(751870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(751871, 1, "1f8f74f329caf62c20c81cd35168cf0ffab8898c4d3117d5ff57af49801197a0")

