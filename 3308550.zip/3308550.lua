-- Lua provided by RyzenAPI
-- Game: Sky End Market

-- MAIN APPLICATION
addappid(3308550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308551, 1, "5b5aa1204c361ba263216225aa96c111290227d271cd317fdabe6af3ea232251")
