-- Lua provided by RyzenAPI 
-- Game: AppID 3308550
addappid(3308550)
addappid(3308551, 1, "5b5aa1204c361ba263216225aa96c111290227d271cd317fdabe6af3ea232251")
