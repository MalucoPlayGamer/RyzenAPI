-- Lua provided by RyzenAPI
-- Game: Game: WASTED

-- MAIN APPLICATION
addappid(3478290)
-- Game: addappid(3478290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478291, 1, "b07dcbd43f49d8030808231d6b5930d84e63d5b680b065ade061b15268c06a39")
