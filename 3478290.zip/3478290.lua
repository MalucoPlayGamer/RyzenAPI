-- Lua provided by RyzenAPI
-- Game: WASTED

-- MAIN APPLICATION
addappid(3478290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478291, 1, "b07dcbd43f49d8030808231d6b5930d84e63d5b680b065ade061b15268c06a39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
