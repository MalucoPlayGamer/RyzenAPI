-- Lua provided by RyzenAPI
-- Game: Game: AppID 2134310

-- MAIN APPLICATION
addappid(2134310)
-- Game: addappid(2134310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134311, 1, "b00adf693705bc9ec0839f760e178f8d805ba92a2a1b281b5880ee947f084d36")
