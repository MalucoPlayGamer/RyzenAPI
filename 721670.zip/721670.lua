-- Lua provided by RyzenAPI
-- Game: addappid(721670)

-- MAIN APPLICATION
addappid(721670)
addappid(756690)
addappid(757410)
addappid(757800)
addappid(760130)
addappid(761210)
addappid(766770)

-- MAIN APP DEPOTS / PACKAGES
addappid(721671, 1, "164832b1c23c4282e2b09a8d8c094beb4ab74a6192b377099e926d446e7146ba")
