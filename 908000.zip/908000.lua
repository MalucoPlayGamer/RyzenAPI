-- Lua provided by RyzenAPI
-- Game: AppID 908000

-- MAIN APPLICATION
addappid(908000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(908001, 1, "68825d05beb451728b9a6a073faa89c77dc27b1e2c8a05d607479f0eabd12dc4")

