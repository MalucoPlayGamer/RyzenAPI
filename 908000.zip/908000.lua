-- Lua provided by RyzenAPI
-- Game: addappid(908000)

-- MAIN APPLICATION
addappid(908000)

-- MAIN APP DEPOTS / PACKAGES
addappid(908001, 1, "68825d05beb451728b9a6a073faa89c77dc27b1e2c8a05d607479f0eabd12dc4")
