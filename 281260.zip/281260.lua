-- Lua provided by RyzenAPI 
-- Game: AppID 281260
addappid(281260)
addappid(281261, 1, "0b6490f64611827cf98a47289cead03a4ae2c4abce020dd63375332316ca9687")
