-- Lua provided by RyzenAPI
-- Game: 334660

-- MAIN APPLICATION
addappid(334660)
-- Game: addappid(334660)

-- MAIN APP DEPOTS / PACKAGES
addappid(334661, 1, "27f064b8030a5c3a38d711af87b7462fa0d57671aefd93cc44e5112629728831")
