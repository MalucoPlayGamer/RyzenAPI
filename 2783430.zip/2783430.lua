-- Lua provided by RyzenAPI 
-- Game: AppID 2783430
addappid(2783430)
addappid(2783431, 1, "5ee1167616fd267d65629b0e75a88e4fa801949ef2737ecd631be1d219bd0152")
