-- Lua provided by RyzenAPI 
-- Game: AppID 1342890
addappid(1342890)
addappid(1342891, 1, "0cec067b2253bc7fbb9baef1b76448340d4767c1d35825d5b38e47d029b9ec35")
