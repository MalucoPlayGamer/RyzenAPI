-- Lua provided by RyzenAPI
-- Game: Who Needs a Hero?

-- MAIN APPLICATION
addappid(1342890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342891, 1, "0cec067b2253bc7fbb9baef1b76448340d4767c1d35825d5b38e47d029b9ec35")

