-- Lua provided by RyzenAPI
-- Game: Soy Supremacy

-- MAIN APPLICATION
addappid(3833120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3833121,0,"4f177764305ca5a09f17dd5f1c47ee7a68c5b5828dd8c642ab259e89ef736a2a")

