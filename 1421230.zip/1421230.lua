-- Lua provided by RyzenAPI
-- Game: 1421230

-- MAIN APPLICATION
addappid(1421230)
-- Game: addappid(1421230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421231, 1, "834c91134303b4bf39af028ea1d732338b6287729ab24a287d1ec7bd4a45ab4a")
