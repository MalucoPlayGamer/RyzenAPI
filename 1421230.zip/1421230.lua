-- Lua provided by RyzenAPI
-- Game: Syberia: The World Before - Prologue

-- MAIN APPLICATION
addappid(1421230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1421231, 1, "834c91134303b4bf39af028ea1d732338b6287729ab24a287d1ec7bd4a45ab4a")

