-- Lua provided by RyzenAPI
-- Game: Frog struggles

-- MAIN APPLICATION
addappid(1206140)
-- Game: addappid(1206140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206141, 1, "4ba0d36e6950f2380f404bab8ef10f02fb1b60211655d70531d1b694452a8e4f")
