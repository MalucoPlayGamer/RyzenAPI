-- Lua provided by RyzenAPI
-- Game: Frog struggles

-- MAIN APPLICATION
addappid(1206140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206141, 1, "4ba0d36e6950f2380f404bab8ef10f02fb1b60211655d70531d1b694452a8e4f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
