-- Lua provided by RyzenAPI
-- Game: MILF's Plaza Soundtrack

-- MAIN APPLICATION
addappid(2872360)
-- Game: addappid(2872360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872361, 1, "abf7d938bbcd1a920d2b0551b45a8e82e62e02a929df01082d8dbefd67ba8e02")
addappid(2872362, 1, "b6ad67b0617a0fd289736fba0a9af51d76097ba3095f534e9c8e1a6a642db735")
