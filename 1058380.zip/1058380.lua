-- Lua provided by RyzenAPI
-- Game: Streamer Daily

-- MAIN APPLICATION
addappid(1058380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058381, 1, "8cfcad41e728a947fa8d88a3269fcc6c10dbb8ce594612631a7d8300998e28ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
