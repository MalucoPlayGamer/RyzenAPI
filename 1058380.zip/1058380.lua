-- Lua provided by RyzenAPI
-- Game: Streamer Daily

-- MAIN APPLICATION
addappid(1058380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058381, 1, "8cfcad41e728a947fa8d88a3269fcc6c10dbb8ce594612631a7d8300998e28ae")
