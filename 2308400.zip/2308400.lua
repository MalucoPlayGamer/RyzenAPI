-- Lua provided by RyzenAPI
-- Game: Nandemoya of Flower Street

-- MAIN APPLICATION
addappid(2308400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308401, 1, "b45ab06805b23ae57e7e83114f23901337e749c4bb8b3e568119d36585c45e35")
