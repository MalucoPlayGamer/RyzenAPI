-- Lua provided by RyzenAPI
-- Game: 96810

-- MAIN APPLICATION
addappid(96810)
-- Game: addappid(96810)

-- MAIN APP DEPOTS / PACKAGES
addappid(96802,0,"94c382c1f76d3f991330a37e6b1a772a08dc950007a928c8de1b80b80a4b33cb")
