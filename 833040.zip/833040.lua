-- Lua provided by RyzenAPI
-- Game: Hiveswap Friendsim

-- MAIN APPLICATION
addappid(833040)
addappid(848020)
addappid(859130)
addappid(864980)
addappid(878920)
addappid(886930)
addappid(892400)
addappid(904580)
addappid(913810)
addappid(922430)
addappid(931920)
addappid(941220)
addappid(950820)
addappid(959160)
addappid(966360)
addappid(975560)
addappid(986510)
addappid(998810)

-- MAIN APP DEPOTS / PACKAGES
addappid(833041,0,"800510b33041c92c57ab3b7834a88b04fa85e39ac0d703f7bacc22b9cd1d914a")

