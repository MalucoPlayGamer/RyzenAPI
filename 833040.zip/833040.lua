-- Lua provided by RyzenAPI
-- Game: 833040

-- MAIN APPLICATION
addappid(833040)
-- Game: addappid(833040)

-- MAIN APP DEPOTS / PACKAGES
addappid(833041, 1, "800510b33041c92c57ab3b7834a88b04fa85e39ac0d703f7bacc22b9cd1d914a")
