-- Lua provided by RyzenAPI
-- Game: Ravenfield

-- MAIN APPLICATION
addappid(636480)

-- MAIN APP DEPOTS / PACKAGES
addappid(636481, 1, "85a0ec71b9f6fb33c36056ce85f0937f8465b590f8cacb1d7eef63d2d9a0061c")
addappid(636482, 1, "cabf23d189b4c72001daad4116232b4edacf160742f8dcbc63a39cd935d1e220")
addappid(636483, 1, "a03e024cec8d0e31aaacd382005c4329f781587c1ddb2eb83248d5eca4488e37")
addappid(636484, 1, "4af2541c989f166ad952fdfcabb3968e30b9c76c86c684c65768f2dd3f6afeb7")

