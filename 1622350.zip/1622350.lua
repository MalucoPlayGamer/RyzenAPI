-- Lua provided by RyzenAPI
-- Game: Copycat

-- MAIN APPLICATION
addappid(1622350)
-- Game: addappid(1622350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622351, 1, "83b37bc19503c3a2c210e8599e1fdf1bfad5725707f83548d46c1429e1d49efa")
addappid(1622352, 1, "9fbf2e0a7ee3747711e1553ec46a2b11269d278785d67664de52b514a869bba7")
