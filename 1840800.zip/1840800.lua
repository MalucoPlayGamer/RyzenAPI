-- Lua provided by RyzenAPI
-- Game: Headquarters: World War II

-- MAIN APPLICATION
addappid(1840800)
addappid(2885300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1840801, 1, "ff2d8c45c35e81391fda349955290d9ec6bb2125325841f63df17a59d559fcd1")
addappid(1840802, 1, "02d4624618c1b7a31579dc43a230a772f6573474738baadaec47e45debe14e0c")
addappid(3047640, 0, "ccef1868801a9d1b50abe1161a90efdac4950ad7f57b5b04aa4f1704da6a178e")
addappid(3295310, 0, "27d046f37b398876ab45a3f5e257a42e0b33f68061aef514b37fdb669e4b3559")

