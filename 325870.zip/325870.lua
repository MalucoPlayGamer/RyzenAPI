-- Lua provided by RyzenAPI
-- Game: Clash of Puppets

-- MAIN APPLICATION
addappid(325870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(325871, 1, "7ccc6e9a4efe29e04b4128e2024cc01652b63308e72c4439e733ffd7b4256bd2")
