-- Lua provided by RyzenAPI
-- Game: Game: AppID 325870

-- MAIN APPLICATION
addappid(325870)
-- Game: addappid(325870)

-- MAIN APP DEPOTS / PACKAGES
addappid(325871, 1, "7ccc6e9a4efe29e04b4128e2024cc01652b63308e72c4439e733ffd7b4256bd2")
