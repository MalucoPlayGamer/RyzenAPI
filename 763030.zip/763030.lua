-- Lua provided by RyzenAPI
-- Game: Game: AppID 763030

-- MAIN APPLICATION
addappid(763030)
-- Game: addappid(763030)

-- MAIN APP DEPOTS / PACKAGES
addappid(763031, 1, "b8831ca0f934defa24c412a335db7b9e417ca1047053aa2ac3b46c2ff16e0948")
addappid(763032, 1, "df17cdace0fa2ffd84dd4b9a6641647fc1e2bab554dc7475f1244ab699f6221c")
addappid(763033, 1, "a5d5ab0f3aa4813f19248c9e1fb9f34b06e9da715f9c696f84554cd6be6b96c7")
