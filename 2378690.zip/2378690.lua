-- Lua provided by RyzenAPI
-- Game: 倩女幽魂2023

-- MAIN APPLICATION
addappid(2378690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378691, 1, "048ca16a1aad95e624486d05f08e1df05ea1eb1fa0b189591b3543ed5d21caa0")

