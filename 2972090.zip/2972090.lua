-- Lua provided by RyzenAPI
-- Game: Spellagis

-- MAIN APPLICATION
addappid(2972090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2972091, 1, "953868bda68004f3ec09bec2dd66dbf758df69dc912fee54248c74f5fb3cb80d")

