-- Lua provided by SkyAPI 
-- Game: World of Tennis: Roaring ’20s
addappid(796290)
addappid(796291, 1, "88d8dfa9f46789214aa4200c295e9a7c9bd21580b74184c5bc04febbba66ef26")
addappid(796292, 1, "e074bb0507f1dc68ee9151a61a99d307854208d111ee5b3be10b6b0ad095b0d0")
