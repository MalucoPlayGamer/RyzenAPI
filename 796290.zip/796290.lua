-- Lua provided by RyzenAPI
-- Game: World of Tennis: Roaring ’20s

-- MAIN APPLICATION
addappid(796290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(796291, 1, "88d8dfa9f46789214aa4200c295e9a7c9bd21580b74184c5bc04febbba66ef26")
addappid(796292, 1, "e074bb0507f1dc68ee9151a61a99d307854208d111ee5b3be10b6b0ad095b0d0")

