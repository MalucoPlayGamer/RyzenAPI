-- Lua provided by RyzenAPI
-- Game: Into the Necrovale Demo

-- MAIN APPLICATION
addappid(2469580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469582,0,"8a7086c9de1e830e1f3940252e022715e42f8a66c071b51567140fb7ebb8d7ba")
