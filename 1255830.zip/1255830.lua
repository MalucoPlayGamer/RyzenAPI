-- Lua provided by RyzenAPI
-- Game: Puzzle Girls: Alexa

-- MAIN APPLICATION
addappid(1255830)
addappid(1255850)
addappid(1256050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255831, 1, "c878a875054d802ccb4f319e4724cd9deed396f3e85656536215767775c52796")

