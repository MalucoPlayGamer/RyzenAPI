-- Lua provided by RyzenAPI
-- Game: 2960790

-- MAIN APPLICATION
addappid(2960790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960792,0,"bd2a169c39286f9a14d9ef97c3f44291c62b8ff91bed9dccbfce0c3207dfaa7a")
