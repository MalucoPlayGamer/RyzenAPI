-- Lua provided by RyzenAPI
-- Game: AppID 1039960

-- MAIN APPLICATION
addappid(1039960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1039961, 1, "44ba2a62e359d4b3540df0f329122325fbf7c4082bfb9978e5ab097d30892c5a")
addappid(1039962, 1, "1cf24ecb468f2f2aae9d91a6de42b8681867ae4206a23f6eb874a5960de79c33")

