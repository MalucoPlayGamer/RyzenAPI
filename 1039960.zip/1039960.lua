-- Lua provided by RyzenAPI
-- Game: Game: AppID 1039960

-- MAIN APPLICATION
addappid(1039960)
-- Game: addappid(1039960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039961, 1, "44ba2a62e359d4b3540df0f329122325fbf7c4082bfb9978e5ab097d30892c5a")
addappid(1039962, 1, "1cf24ecb468f2f2aae9d91a6de42b8681867ae4206a23f6eb874a5960de79c33")
