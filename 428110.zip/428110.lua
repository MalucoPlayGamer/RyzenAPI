-- Lua provided by RyzenAPI
-- Game: Save Halloween: City of Witches

-- MAIN APPLICATION
addappid(428110)

-- MAIN APP DEPOTS / PACKAGES
addappid(428111, 1, "d027d69ab4c17c79472c83238a72187bc2dcdeb8034cf3a579e7b8150f3160c7")

