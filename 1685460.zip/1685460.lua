-- Lua provided by RyzenAPI
-- Game: 1685460

-- MAIN APPLICATION
addappid(1685460)
-- Game: addappid(1685460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685461, 1, "edf0cf99f612764bb616efc2d0c0cf7a8883f6caf6acbc647332b48b0cf6c2c5")
addappid(2168690, 0, "aa38399402d8ba93b3d2d5e17f2b51a9fb2d3dae5f8cc3c87eba1eea7a22e872")
