-- Lua provided by RyzenAPI
-- Game: A-Train: All Aboard! Tourism

-- MAIN APPLICATION
addappid(1685460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1685461, 1, "edf0cf99f612764bb616efc2d0c0cf7a8883f6caf6acbc647332b48b0cf6c2c5")
addappid(2168690, 0, "aa38399402d8ba93b3d2d5e17f2b51a9fb2d3dae5f8cc3c87eba1eea7a22e872")

