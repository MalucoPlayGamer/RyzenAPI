-- Lua provided by RyzenAPI
-- Game: Diesel Guns

-- MAIN APPLICATION
addappid(355400)

-- MAIN APP DEPOTS / PACKAGES
addappid(355401, 1, "2dc8329a06afdb2a9e9782c09224db864671840dfeed61d4ae69d12a168558fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
