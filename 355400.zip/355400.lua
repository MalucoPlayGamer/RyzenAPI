-- Lua provided by RyzenAPI
-- Game: addappid(355400)

-- MAIN APPLICATION
addappid(355400)

-- MAIN APP DEPOTS / PACKAGES
addappid(355401, 1, "2dc8329a06afdb2a9e9782c09224db864671840dfeed61d4ae69d12a168558fe")
