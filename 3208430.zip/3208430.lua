-- Lua provided by RyzenAPI
-- Game: Food Delivery Simulator 2026 - Demo

-- MAIN APPLICATION
addappid(3208430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208431, 1, "75e9a63b7193f87727444964150b3817bbc53dbb13b3908cb8c55d129680ec45")

