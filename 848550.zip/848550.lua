-- Lua provided by RyzenAPI
-- Game: Welcome Back To 2007 Part II

-- MAIN APPLICATION
addappid(848550)
addappid(935810)

-- MAIN APP DEPOTS / PACKAGES
addappid(848551,0,"1a60e109e72f137abc2c807229ae0cbad20d6da13f7d8b7cde2dd61e8ff03275")
addappid(935810,0,"bf51151c0ea4f73d490f7b04ea79f90c30b039a722dfe673c729f13c42455de7")

