-- Lua provided by RyzenAPI
-- Game: Welcome Back To 2007 Part II

-- MAIN APPLICATION
addappid(848550)
-- Game: addappid(848550)

-- MAIN APP DEPOTS / PACKAGES
addappid(848551, 1, "1a60e109e72f137abc2c807229ae0cbad20d6da13f7d8b7cde2dd61e8ff03275")
