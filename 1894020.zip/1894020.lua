-- Lua provided by RyzenAPI
-- Game: 白昼夢の青写真 Soundtrack CASE-1

-- MAIN APPLICATION
addappid(1894020)
-- Game: addappid(1894020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894021, 1, "173ac47617665c5a1ee32e8da5d22f83c624c5b0a95731acc2e3bbe30fddcd74")
addappid(1894022, 1, "5c722a7cf7bd5597ef4fbb80a0b6b76ffe2ccc49071c659dd75521d84a5a7427")
