-- Lua provided by RyzenAPI
-- Game: VoiceAttack v2

-- MAIN APPLICATION
addappid(3046550)
-- Game: addappid(3046550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046551, 1, "e126909adbd9a8d3d88411be28d17be2e7e689e89273a9624308f8edbcba8f78")
