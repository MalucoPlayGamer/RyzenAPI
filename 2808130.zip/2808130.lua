-- Lua provided by RyzenAPI
-- Game: 2808130

-- MAIN APPLICATION
addappid(2808130)
-- Game: addappid(2808130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808131, 1, "bf177ef805a2e5b3f13f3a4724dc09387d0bed9d2b580d63edd7cec4790e6be9")
