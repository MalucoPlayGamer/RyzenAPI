-- Lua provided by RyzenAPI
-- Game: 855580

-- MAIN APPLICATION
addappid(855580)
-- Game: addappid(855580)

-- MAIN APP DEPOTS / PACKAGES
addappid(855581, 1, "5c996731cf480423cc884c88263a857b5b075c94fb65cd0c3c3a65c0559009e2")
