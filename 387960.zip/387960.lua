-- Lua provided by RyzenAPI
-- Game: AppID 387960

-- MAIN APPLICATION
addappid(387960)

-- MAIN APP DEPOTS / PACKAGES
addappid(387961, 1, "b46adc443a5630c8458dea30f8a192f72a80f293999282bb7c2dfdfeb4b7506b")
addappid(387962, 1, "de101d053231a128a6bd4c385926361f93f0998723a55105e1ece3fcb11e7e24")
addappid(387963, 1, "e2513a9c665f32feadd9caa6ded2c383f8d0ff6e64fa04ea1c887f60e6df0668")
addappid(387964, 1, "cb3d8e2b4842b9b563060081837523086eff53b03924fdf09aaf31180895acf6")
addappid(387965, 1, "eb54b06129e7773fcdf0231c2159f3c0d2c02f9475abc03f2ffc5b561712b3e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
