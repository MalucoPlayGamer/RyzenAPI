-- Lua provided by RyzenAPI
-- Game: Game: After Solitary

-- MAIN APPLICATION
addappid(650460)
-- Game: addappid(650460)

-- MAIN APP DEPOTS / PACKAGES
addappid(650461, 1, "ba4390fe937c991ed1f8d88a1453d3538c1b3740cbc467b41d7ff48f8a75043e")
