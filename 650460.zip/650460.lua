-- Lua provided by RyzenAPI
-- Game: After Solitary

-- MAIN APPLICATION
addappid(650460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(650461, 1, "ba4390fe937c991ed1f8d88a1453d3538c1b3740cbc467b41d7ff48f8a75043e")

