-- Lua provided by RyzenAPI
-- Game: Sex Simulator - CamGirl Audition

-- MAIN APPLICATION
addappid(2548010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548011, 1, "ceceae66b4d28ac4304c8ba106a7da3cb84158f893a181a6d505fa268d19a5c6")
