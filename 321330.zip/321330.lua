-- Lua provided by RyzenAPI
-- Game: ENYO ARCADE

-- MAIN APPLICATION
addappid(321330)
addappid(980100)
addappid(982460)
addappid(982461)
addappid(982490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(321331, 1, "49aebf5d978b73219726d0c75cc17cff3fa21fbf8b73ecb81e55013f61465f41")
