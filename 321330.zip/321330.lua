-- Lua provided by RyzenAPI
-- Game: AppID 321330

-- MAIN APPLICATION
addappid(321330)
-- Game: addappid(321330)

-- MAIN APP DEPOTS / PACKAGES
addappid(321331, 1, "49aebf5d978b73219726d0c75cc17cff3fa21fbf8b73ecb81e55013f61465f41")
