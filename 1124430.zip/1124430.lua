-- Lua provided by RyzenAPI
-- Game: 1124430

-- MAIN APPLICATION
addappid(1124430)
-- Game: addappid(1124430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124431, 1, "1b9773601b1ad6b995750a2ec3d72f79415d1d35c6df49887ae9ac5bbf2cd0ca")
