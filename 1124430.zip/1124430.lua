-- Lua provided by RyzenAPI 
-- Game: The Adventures of Sullivan
addappid(1124430)
addappid(1124431, 1, "1b9773601b1ad6b995750a2ec3d72f79415d1d35c6df49887ae9ac5bbf2cd0ca")
