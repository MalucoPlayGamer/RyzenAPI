-- Lua provided by RyzenAPI
-- Game: The Sand Dunes

-- MAIN APPLICATION
addappid(1566610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1566611, 1, "ac874f16d0090b390c1cf2042c24cdf71368310650d070948b12ab2e7aea7aff")
