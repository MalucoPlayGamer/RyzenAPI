-- Lua provided by RyzenAPI
-- Game: AppID 1566610

-- MAIN APPLICATION
addappid(1566610)
-- Game: addappid(1566610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566611, 1, "ac874f16d0090b390c1cf2042c24cdf71368310650d070948b12ab2e7aea7aff")
