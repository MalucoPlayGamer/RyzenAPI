-- Lua provided by RyzenAPI
-- Game: AppID 1069210

-- MAIN APPLICATION
addappid(1069210)
addappid(1215360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069211, 1, "df65187fbcd4d429b1e181973de797d636e2c48fc2ae51d83a4455c5b3e8c23d")

