-- Lua provided by SkyAPI 
-- Game: Ballspell
addappid(2145080)
addappid(2145081, 1, "9ccfee693878098f5f7387909836a1cd0eac51f76b193449f4d7b257336753b1")
