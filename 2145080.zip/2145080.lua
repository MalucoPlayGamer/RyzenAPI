-- Lua provided by RyzenAPI
-- Game: Ballspell

-- MAIN APPLICATION
addappid(2145080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2145081, 1, "9ccfee693878098f5f7387909836a1cd0eac51f76b193449f4d7b257336753b1")

