-- Lua provided by RyzenAPI
-- Game: Bug Blast

-- MAIN APPLICATION
addappid(1348060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348061, 1, "5692d047daf595fc666d3d24324053b3031defbd50ca1b8fad65cbc75c541e5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
