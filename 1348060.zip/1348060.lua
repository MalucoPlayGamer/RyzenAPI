-- Lua provided by RyzenAPI
-- Game: Bug Blast

-- MAIN APPLICATION
addappid(1348060)
-- Game: addappid(1348060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348061, 1, "5692d047daf595fc666d3d24324053b3031defbd50ca1b8fad65cbc75c541e5f")
