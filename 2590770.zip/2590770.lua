-- Lua provided by RyzenAPI
-- Game: addappid(2590770)

-- MAIN APPLICATION
addappid(2590770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590771, 1, "71f7bff1b1fdbd65ad715c435255e8dc310fc51b0cadc0a50af7c60816870966")
