-- Lua provided by RyzenAPI
-- Game: Dark Deity 2

-- MAIN APPLICATION
addappid(2446600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446601, 1, "0650a9f501109efa45fda14c3e72dc2705e04483e64b8959d584831341cc965f")

