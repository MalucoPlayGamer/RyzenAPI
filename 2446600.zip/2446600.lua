-- Lua provided by SkyAPI 
-- Game: Dark Deity 2
addappid(2446600)
addappid(2446601, 1, "0650a9f501109efa45fda14c3e72dc2705e04483e64b8959d584831341cc965f")
