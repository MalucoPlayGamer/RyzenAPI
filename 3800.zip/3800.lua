-- Lua provided by RyzenAPI
-- Game: Advent Rising

-- MAIN APPLICATION
addappid(3800)
addappid(229005)

-- MAIN APP DEPOTS / PACKAGES
addappid(3801, 1, "71daad497b6e6376e600e568ba4bd9f44e0510a4089a2a2167f4d6dbb3a9d593")
addappid(3802, 1, "fbd63b496e1b7ac35c68d149f0ff2593ce1db623c6ceac1dc7f4ecfb27baad09")
addappid(3803, 1, "0eac0fec4ec999be81a7544ffdc756ea14bc04da7f7d0305cf429de35dd4cfac")
addappid(3804, 1, "7dff3ac366df626ef2b079a774b54e48883396cba7b4689d2aae07cfeff724dc")
addappid(3805, 1, "3bd36a1d2eff221c65ba8f9b09635616b0ea46701b79c87da20981a8df8e4077")
addappid(3806, 1, "3dc7ae6f4b0991f49d394de057f9801615081623469e7f1cacbd41ca9852b095")
addappid(825220, 0, "376b0f337fb8d02b025685462e2d940a38013e61299d89ffdd15cdf8eda57b46")
addappid(825221, 0, "06133ed85101533776f3538cf68f5552a7eccc0272e97c13efb69faeedcca100")

