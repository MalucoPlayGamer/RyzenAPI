-- Lua provided by RyzenAPI
-- Game: FORCED: Slightly Better Edition

-- MAIN APPLICATION
addappid(249990)
addappid(260880)
addappid(292220)

-- MAIN APP DEPOTS / PACKAGES
addappid(249991, 1, "3c2138ce0be4d998706a5e6d6cb6090947e3a473b79c53ef444286749fed70b3")
addappid(249992, 1, "2cc9a030d9e8e4f1668ca0b8a2c14ef3fcdb44e992fe3976c6bff3f11e20317e")
addappid(249993, 1, "ae87c483080acad49eae5daf132ed3ca4fd76203d36f19dd5ace9c7abf7c39ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(260881)
