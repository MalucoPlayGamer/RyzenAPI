-- Lua provided by RyzenAPI
-- Game: FORCED: Slightly Better Edition

-- MAIN APPLICATION
addappid(249990)
addappid(260880)
addappid(292220)
-- Game: addappid(249990)

-- MAIN APP DEPOTS / PACKAGES
addappid(249991, 1, "3c2138ce0be4d998706a5e6d6cb6090947e3a473b79c53ef444286749fed70b3")
addappid(249992, 1, "2cc9a030d9e8e4f1668ca0b8a2c14ef3fcdb44e992fe3976c6bff3f11e20317e")
addappid(249993, 1, "ae87c483080acad49eae5daf132ed3ca4fd76203d36f19dd5ace9c7abf7c39ba")
