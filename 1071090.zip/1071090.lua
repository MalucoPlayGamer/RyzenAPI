-- Lua provided by RyzenAPI
-- Game: Game: AppID 1071090

-- MAIN APPLICATION
addappid(1071090)
-- Game: addappid(1071090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071091, 1, "96241e519e95e54816cdfd363fd69599e8d375943c3ae89f50d04f284302de5c")
