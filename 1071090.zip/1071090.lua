-- Lua provided by SkyAPI 
-- Game: AppID 1071090
addappid(1071090)
addappid(1071091, 1, "96241e519e95e54816cdfd363fd69599e8d375943c3ae89f50d04f284302de5c")
