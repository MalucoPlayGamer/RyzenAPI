-- Lua provided by RyzenAPI
-- Game: Choo-Choose

-- MAIN APPLICATION
addappid(2946030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946031, 1, "7e81ac081f94f0a1de80d15ef3a74b86b006c6f149897ae0994f26056eec90db")
addappid(3384850, 0, "89570a88010cdc194ef3afeb97362afc011a9875938738cbd3993560bdf94ae1")
addappid(3777730, 0, "6c10325933645400240042b99e9b807947d518801b29d0533b2f64f0206854ed")
addappid(3777740, 0, "539163f050c99de0423ce28588c5c081ca26146474269211a7068ce274c9defb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3839870)
