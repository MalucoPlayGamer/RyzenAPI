-- Lua provided by RyzenAPI 
-- Game: AppID 3187490
addappid(3187490)
addappid(3187491, 1, "0afb72deaec8dd36e374569eff99ff92829e011d25d7f8890dbc209c93cd7102")
