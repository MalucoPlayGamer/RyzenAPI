-- Lua provided by RyzenAPI 
-- Game: Monster Coming
addappid(2491050)
addappid(2491051, 1, "4754442031936f888d0ccfd09f38bccd656157a63acbe5517c73458004bb1154")
