-- Lua provided by RyzenAPI
-- Game: 星礼研究所 | Sighchology Research Lab

-- MAIN APPLICATION
addappid(1187030)
addappid(1219350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187031, 1, "1e9ab5156f817669ae2c363cc8fc5720eee088d7398c489231e06f979f205c06")

