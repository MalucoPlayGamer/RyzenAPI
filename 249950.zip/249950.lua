-- Lua provided by RyzenAPI
-- Game: Game: Forge Quest

-- MAIN APPLICATION
addappid(249950)
-- Game: addappid(249950)

-- MAIN APP DEPOTS / PACKAGES
addappid(249951, 1, "c52aa28f967ad47a9e0c4ced1176ced3a8a1e439396d4b776807c1e75951c431")
addappid(249952, 1, "7f007a6fe148d77577029e77660e0001ca7bd5337283a85ef23fbd0834eb55cb")
addappid(249953, 1, "3b133ae86b463ba1d3aee72d1bab0ea4092b60be5ac98e9627bb381498942ae4")
addappid(249954, 1, "e0a31c994c88153f5261cc283aa38fe8f454e67a404b85a650cb4b949e8a826c")
