-- Lua provided by RyzenAPI
-- Game: Bear's Restaurant

-- MAIN APPLICATION
addappid(1687550)
-- Game: addappid(1687550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687552,0,"06cf17d61b5f629516539e46ba7e799af4855415ac82834e6b3a69cb4dd8014a")
