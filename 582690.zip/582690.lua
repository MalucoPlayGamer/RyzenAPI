-- Lua provided by RyzenAPI
-- Game: Toon Shooters 2: The Freelancers

-- MAIN APPLICATION
addappid(582690)

-- MAIN APP DEPOTS / PACKAGES
addappid(582692,0,"1e76c641b915fa3a889ef118643a42bfcb1d03007db94d9db5993d641e97f15b")
addappid(582693,0,"baf0a92e586f7b9d1a0e623c262c1910ad66f82aa29ff3366b14e5f67379a3ff")
