-- Lua provided by RyzenAPI
-- Game: Soccer Kid

-- MAIN APPLICATION
addappid(1104480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104481, 1, "0b69359e9b40db592d67d12ebf005a161aa4110d17d0657b79ca6ac0f141e604")
