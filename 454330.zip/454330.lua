-- Lua provided by RyzenAPI
-- Game: addappid(454330)

-- MAIN APPLICATION
addappid(454330)

-- MAIN APP DEPOTS / PACKAGES
addappid(454332,0,"4a6fce284c8093231a586c047152893c2ff06260b23d6f631001be2c5bdfe4a2")
