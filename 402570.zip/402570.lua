-- Lua provided by RyzenAPI
-- Game: Atlas Reactor

-- MAIN APPLICATION
addappid(402570)
addappid(402572)
addappid(470290)
addappid(470291)
addappid(470292)
addappid(535200)
addappid(535201)
addappid(535202)
addappid(630190)
addappid(682200)
addappid(842570)

-- MAIN APP DEPOTS / PACKAGES
addappid(402573,0,"b152ad79596e92c260bfab99fba1a17d56621ad2dde252183bdcf3b5f7349c4a")
addappid(402574,0,"eba5098845a1ceb140757af156b41208a4425b5927d9668774a0ae5549034edf")
addappid(845241,0,"9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")

