-- Lua provided by RyzenAPI
-- Game: 1078460

-- MAIN APPLICATION
addappid(1078460)
-- Game: addappid(1078460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078461, 1, "9feaf51130c7eb5ec3e2f89ae610a64ac5e0307d13db35fc7f08499884b69564")
