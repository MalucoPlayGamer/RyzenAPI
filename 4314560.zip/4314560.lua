-- Lua provided by RyzenAPI
-- Game: Cartapli : Fold Quest

-- MAIN APPLICATION
addappid(4314560)
