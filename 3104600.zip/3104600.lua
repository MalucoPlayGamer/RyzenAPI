-- Lua provided by RyzenAPI
-- Game: Observa

-- MAIN APPLICATION
addappid(3104600)

