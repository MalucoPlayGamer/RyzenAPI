-- Lua provided by SkyAPI 
-- Game: Night of the Witch's Invasion
addappid(3477730)
addappid(3477731, 1, "aab05c54bb9a6e8d35d2aac45f3173098987eb78de96d6c9d0b707d239a0ebd9")
