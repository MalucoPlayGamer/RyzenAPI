-- Lua provided by RyzenAPI
-- Game: Game: GoldFish Brain

-- MAIN APPLICATION
addappid(1264360)
-- Game: addappid(1264360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264361, 1, "3ce2dab20ddd3a5095f0b6144865135fecd3568d8876dd84ec91db88db0eb764")
