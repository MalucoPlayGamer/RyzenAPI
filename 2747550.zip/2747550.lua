-- Lua provided by RyzenAPI
-- Game: 2747550

-- MAIN APPLICATION
addappid(2747550)
-- Game: addappid(2747550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747551, 1, "998a98d376ce8a31aebac65ed4f83820283eaabac8258057bdd7052812b2cb30")
