-- Lua provided by SkyAPI 
-- Game: AppID 575640
addappid(575640)
addappid(575641, 1, "6d8c22a609a9164da9449a50759fbff2b81bdf5d12716fe20c15845d10507eb7")
addappid(584770, 0, "5b90f2b9b352fca728d5c2b60cfdc851dc3f31675ded6ee671def7b8e9c0d8c1")
