-- Lua provided by RyzenAPI
-- Game: Cyber Utopia

-- MAIN APPLICATION
addappid(654350)

-- MAIN APP DEPOTS / PACKAGES
addappid(654351, 1, "38f4c0c155ae2c7e45ed68a1bb549451b0e6f161feae20942d074e31c0874a59")
