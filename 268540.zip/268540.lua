-- Lua provided by RyzenAPI
-- Game: AppID 268540

-- MAIN APPLICATION
addappid(268540)

-- MAIN APP DEPOTS / PACKAGES
addappid(268541, 1, "23feeb76adcd09d11c5f05c332ec9bc8d2865aa2832d801a9b57c113f7ead12f")
addappid(268542, 1, "41d712cad85f1e32847c94352511b94562679cce68bf055f87e58bb1de18e20e")
addappid(268543, 1, "c24dddf5dbfd50eb2bfc2fc6ffc178d75c42551d426af58912b9b1f5d2ed1f9d")
addappid(268544, 1, "dcef23eb54b8539314d8a06e2e650fe5d125047a4d9f586c84fb135067749001")
addappid(268545, 1, "71ed1db02f442e92e132e35e929450a0a3bb1ecace3472ef19af712186d14294")
addappid(268546, 1, "421da99dd376a6d385fe66770aec8e6dcde641d9a9f42fcbe405b5c0b4f1dc33")
addappid(268547, 1, "83c719b03c76950ef0e7e53b7993887fde246584a2939a7f554821cb965d781c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
