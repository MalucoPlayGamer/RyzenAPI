-- Lua provided by RyzenAPI 
-- Game: AppID 1174400
addappid(1174400)
addappid(1174401, 1, "c3569053d5043c37602fa5eb1082f3df002a6de794f2dc31db489e4649df4731")
