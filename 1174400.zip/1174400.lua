-- Lua provided by RyzenAPI
-- Game: 1174400

-- MAIN APPLICATION
addappid(1174400)
-- Game: addappid(1174400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174401, 1, "c3569053d5043c37602fa5eb1082f3df002a6de794f2dc31db489e4649df4731")
