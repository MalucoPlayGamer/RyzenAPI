-- Lua provided by RyzenAPI
-- Game: AppID 1174400

-- MAIN APPLICATION
addappid(1174400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1174401, 1, "c3569053d5043c37602fa5eb1082f3df002a6de794f2dc31db489e4649df4731")

