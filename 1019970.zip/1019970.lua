-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Yue Jin "Knight Costume" / 楽進「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019970,0,"681b9ef0e97ccd7b6cdd439670675efa68bf2e59ccdface966077c382aae13bf")
