-- Lua provided by SkyAPI 
-- Game: Blacksmith Legends: Prologue
addappid(1523290)
addappid(1523291, 1, "c80997afc6a891f2ed59206038d1957fdc246c3e4ad03351af4a5780209d8804")
