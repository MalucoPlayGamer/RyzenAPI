-- Lua provided by RyzenAPI
-- Game: Blacksmith Legends: Prologue

-- MAIN APPLICATION
addappid(1523290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523291, 1, "c80997afc6a891f2ed59206038d1957fdc246c3e4ad03351af4a5780209d8804")

