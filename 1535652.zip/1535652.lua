-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1535652)
-- Game: addappid(1535652)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535652,0,"deef6b175093030df1ee70ff14a8399282196125588bcc2c818bc4738a8c1008")
