-- Lua provided by SkyAPI 
-- Game: AppID 817950
addappid(817950)
addappid(817951, 1, "3bbe5f867a953a86139113e633b6446c90f937985acc06e50ed58401a8c8751a")
