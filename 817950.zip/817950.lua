-- Lua provided by RyzenAPI
-- Game: AppID 817950

-- MAIN APPLICATION
addappid(817950)

-- MAIN APP DEPOTS / PACKAGES
addappid(817951, 1, "3bbe5f867a953a86139113e633b6446c90f937985acc06e50ed58401a8c8751a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
