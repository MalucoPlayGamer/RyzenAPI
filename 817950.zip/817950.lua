-- Lua provided by RyzenAPI
-- Game: Game: AppID 817950

-- MAIN APPLICATION
addappid(817950)
-- Game: addappid(817950)

-- MAIN APP DEPOTS / PACKAGES
addappid(817951, 1, "3bbe5f867a953a86139113e633b6446c90f937985acc06e50ed58401a8c8751a")
