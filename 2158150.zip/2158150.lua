-- Lua provided by RyzenAPI
-- Game: Stickman Trenches Demo

-- MAIN APPLICATION
addappid(2158150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158151, 1, "a2d63fad738d5af94e1f2760e429852bca7378e07a2967b50b2254960c1b568d")

