-- Lua provided by RyzenAPI
-- Game: Latex & Tentacles

-- MAIN APPLICATION
addappid(1938300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938301, 1, "1788feeb0f2ddff968a94fd76e7a3b8c64b57f191c423264c48b7fb22839eb4a")

