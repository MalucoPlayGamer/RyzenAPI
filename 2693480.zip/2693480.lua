-- Lua provided by RyzenAPI
-- Game: Game: Color Splash: Animals

-- MAIN APPLICATION
addappid(2693480)
-- Game: addappid(2693480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693481, 1, "076eb4e503c717e235174cfa1727dea18bd0ee6fa9e37ef7f52c7c170491f46b")
