-- Lua provided by RyzenAPI
-- Game: エスカレーター |  Escalator

-- MAIN APPLICATION
addappid(2738050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738051, 1, "47e8ffe6053f63eb67349d822b19bb03362d81c05052eba0f4f71d657f8fc8f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
