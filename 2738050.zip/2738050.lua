-- Lua provided by RyzenAPI 
-- Game: エスカレーター |  Escalator
addappid(2738050)
addappid(2738051, 1, "47e8ffe6053f63eb67349d822b19bb03362d81c05052eba0f4f71d657f8fc8f6")
