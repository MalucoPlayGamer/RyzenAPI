-- Lua provided by RyzenAPI
-- Game: Game of Thrones Winter is Coming

-- MAIN APPLICATION
addappid(1105420)
-- Game: addappid(1105420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105423,0,"a6a1d913607540bd50aeaad67fb903307b4c23add07c6eabc9c49a6541b00438")
