-- Lua provided by RyzenAPI
-- Game: Flexibility and Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1634760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634760,0,"7f5c9d4088b4e185ddea3c6fa0e18b13aae837533a52fd020edd7f5725cc1206")

