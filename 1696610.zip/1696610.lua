-- Lua provided by RyzenAPI
-- Game: Game: Escape from the Lockdown: The Demon Fortress (Steam Version) - Day 1

-- MAIN APPLICATION
addappid(1696610)
-- Game: addappid(1696610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696611, 1, "8b56af6465817dab1458163013c1c1c4d6ca8309312194297b2b0671f9aff9bf")
