-- Lua provided by RyzenAPI
-- Game: Fantastic Checkers 2

-- MAIN APPLICATION
addappid(514480)

-- MAIN APP DEPOTS / PACKAGES
addappid(514481, 1, "8310055d8b555621995ae3a7b0e673264f6430fed4f9ab93cb752fba85c19896")
