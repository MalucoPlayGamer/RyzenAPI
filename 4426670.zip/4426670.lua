-- Lua provided by RyzenAPI
-- Game: Hunt Zombies Together

-- MAIN APPLICATION
addappid(4426670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4426671,0,"8fe51a4c6e15a04ac8c4ae418f31ec4400da90ee670b6bde5884c6371840c5d1")

