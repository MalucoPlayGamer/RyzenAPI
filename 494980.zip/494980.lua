-- Lua provided by RyzenAPI
-- Game: Wondership Q

-- MAIN APPLICATION
addappid(494980)

-- MAIN APP DEPOTS / PACKAGES
addappid(494981, 1, "2a322ab74521c349322b17f0c4f2358bed717384871bcbf28f301807a40b1fe6")

