-- Lua provided by RyzenAPI
-- Game: Adventure Rage

-- MAIN APPLICATION
addappid(646450)

-- MAIN APP DEPOTS / PACKAGES
addappid(646451, 1, "170c646fe11e1e3104f6ff1e64b535348523fabfd939f1fe7dac7283677b66d2")
