-- Lua provided by RyzenAPI
-- Game: addappid(3187910)

-- MAIN APPLICATION
addappid(3187910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3187911, 1, "1889abb3b69d5fc6edc3dc962bf614fbcfca998981ce55152da30bb155f42f8d")
