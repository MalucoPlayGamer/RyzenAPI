-- Lua provided by RyzenAPI
-- Game: addappid(1637370)

-- MAIN APPLICATION
addappid(1637370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637371, 1, "d772ecc19e9711ca01387cc6198a59c289f81c1dbac0ca97f5c4f9a1d77f2cb2")
