-- Lua provided by RyzenAPI
-- Game: Paunch 2

-- MAIN APPLICATION
addappid(1829030)
addappid(1851110)
addappid(1851111)
addappid(1851112)
addappid(1851113)
addappid(1851114)
addappid(1851115)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829031, 1, "ab932dc4ca21c973ffa2a304055ad2ec595ff76ba3d5247c2613d54286035cda")

