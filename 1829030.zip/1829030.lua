-- Lua provided by RyzenAPI
-- Game: addappid(1829030)

-- MAIN APPLICATION
addappid(1829030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829031, 1, "ab932dc4ca21c973ffa2a304055ad2ec595ff76ba3d5247c2613d54286035cda")
