-- Lua provided by RyzenAPI
-- Game: My Museum Prologue: Treasure Hunter

-- MAIN APPLICATION
addappid(1945030)
-- Game: addappid(1945030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945031, 1, "92d63d11b6bc3f926fc2e7eb7e3673e5eccf2520cb2b718f45f3c65ee8c0e9e1")
