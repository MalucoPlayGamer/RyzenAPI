-- Lua provided by RyzenAPI
-- Game: My Museum Prologue: Treasure Hunter

-- MAIN APPLICATION
addappid(1945030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1945031, 1, "92d63d11b6bc3f926fc2e7eb7e3673e5eccf2520cb2b718f45f3c65ee8c0e9e1")

