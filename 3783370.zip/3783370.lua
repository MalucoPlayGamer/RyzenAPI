-- Lua provided by RyzenAPI
-- Game: ReDrop

-- MAIN APPLICATION
addappid(3783370)
-- Game: addappid(3783370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3783371, 1, "d577efc51ad4237cbf5618dadd5bc4c0024f8483cddb6dc8aee4eff09071912d")
