-- Lua provided by RyzenAPI
-- Game: Headsnatchers

-- MAIN APPLICATION
addappid(797410)
-- Game: addappid(797410)

-- MAIN APP DEPOTS / PACKAGES
addappid(797411, 1, "2d20789a0a0cb607234844f035429532572ffa7d6589b8180252447c4c3cf953")
