-- Lua provided by RyzenAPI
-- Game: Headsnatchers

-- MAIN APPLICATION
addappid(797410)

-- MAIN APP DEPOTS / PACKAGES
addappid(797411, 1, "2d20789a0a0cb607234844f035429532572ffa7d6589b8180252447c4c3cf953")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
