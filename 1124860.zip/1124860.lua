-- Lua provided by RyzenAPI
-- Game: Otter Space Rescue

-- MAIN APPLICATION
addappid(1124860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124861, 1, "dd00fa70ddf95afb6123d55d81f8028e67efd795d3f3490381d8e5afb19a6292")
