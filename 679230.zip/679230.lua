-- Lua provided by RyzenAPI
-- Game: Tell a Demon

-- MAIN APPLICATION
addappid(679230)

-- MAIN APP DEPOTS / PACKAGES
addappid(679232,0,"3d2422d04e76cf0a57e0cd5a149e7c482c4f52141caf0db01461c0595b9e8e83")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(679340)
