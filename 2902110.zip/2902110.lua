-- Lua provided by RyzenAPI 
-- Game: Mullet Mad Jack SOUNDTRACK
addappid(2902110)
addappid(2902111, 1, "a57178f867c8536dadc9daa003fc834a3acb05b0d196f6cf54f6f3bc94416a18")
addappid(2902112, 1, "77479cdeeb26cbf7bf2a487c2419c3a33df089fe8b0067960c5a770cb519ce7a")
