-- Lua provided by RyzenAPI
-- Game: Webbed

-- MAIN APPLICATION
addappid(1390350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390351, 1, "ba207fae98255a61553df347356f3c5a08cbce410ccaf7ce6a00c7b05a75d1d3")
