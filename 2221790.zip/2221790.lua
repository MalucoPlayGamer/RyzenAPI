-- Lua provided by RyzenAPI 
-- Game: 幻境咖啡馆-Dreamland coffee
addappid(2221790)
addappid(2221791, 1, "e10d3ef211f14669583ccfb6b9f15d9eced44dcb6df458f796ea1ef61cbdf5d3")
