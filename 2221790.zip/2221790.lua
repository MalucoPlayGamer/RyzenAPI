-- Lua provided by RyzenAPI
-- Game: Game: 幻境咖啡馆-Dreamland coffee

-- MAIN APPLICATION
addappid(2221790)
-- Game: addappid(2221790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221791, 1, "e10d3ef211f14669583ccfb6b9f15d9eced44dcb6df458f796ea1ef61cbdf5d3")
