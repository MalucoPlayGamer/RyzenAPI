-- Lua provided by RyzenAPI 
-- Game: Snow Bros. Wonderland
addappid(3214870)
addappid(3214871, 1, "41a9beb4057fe83f826a91a5d1eef5646760802d023ae46dd6411dd088b9fe03")
