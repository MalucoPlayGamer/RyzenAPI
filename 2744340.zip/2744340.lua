-- Lua provided by RyzenAPI
-- Game: addappid(2744340)

-- MAIN APPLICATION
addappid(2744340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744341, 1, "205492ad0e74c61eba0e9822cc57b3f9a6b0146560c8daa5a3f4b029050756ab")
