-- Lua provided by SkyAPI 
-- Game: Thunder Ronin
addappid(2744340)
addappid(2744341, 1, "205492ad0e74c61eba0e9822cc57b3f9a6b0146560c8daa5a3f4b029050756ab")
