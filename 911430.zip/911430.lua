-- Lua provided by RyzenAPI
-- Game: addappid(911430)

-- MAIN APPLICATION
addappid(911430)

-- MAIN APP DEPOTS / PACKAGES
addappid(911431, 1, "d557646ee358e44b53c1ce9c9cb76a3c09fa295165ab9eb0e6df79ae2268a099")
