-- Lua provided by RyzenAPI
-- Game: Good Company

-- MAIN APPLICATION
addappid(911430)
addappid(1230250)

-- MAIN APP DEPOTS / PACKAGES
addappid(911431,0,"d557646ee358e44b53c1ce9c9cb76a3c09fa295165ab9eb0e6df79ae2268a099")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
