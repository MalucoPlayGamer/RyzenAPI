-- Lua provided by RyzenAPI
-- Game: The Inquisitor - Demo

-- MAIN APPLICATION
addappid(2545270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545271, 1, "2cb6345cd54c65851182bd1ca54bdb523453f3fd0d0eed3eaf74c842e3804aa4")

