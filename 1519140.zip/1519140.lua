-- Lua provided by RyzenAPI
-- Game: [Neolithic]To the End

-- MAIN APPLICATION
addappid(1519140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519141, 1, "8e0e461f09dcadd643ed7d1efe9805ad828808273c330ca6fc5c8e4e96190518")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2611830)
addappid(2763550)
addappid(2877000)
