-- Lua provided by RyzenAPI
-- Game: [Neolithic]To the End

-- MAIN APPLICATION
addappid(1519140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519141, 1, "8e0e461f09dcadd643ed7d1efe9805ad828808273c330ca6fc5c8e4e96190518")
