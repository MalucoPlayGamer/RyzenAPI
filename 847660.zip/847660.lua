-- Lua provided by RyzenAPI
-- Game: Story: Heaven & Hell

-- MAIN APPLICATION
addappid(847660)
addappid(879460)

-- MAIN APP DEPOTS / PACKAGES
addappid(847661, 1, "ad02d660ef63f353fd04318c272110fcb467d81ee6ba91732ce4b1bed627535a")

