-- Lua provided by RyzenAPI
-- Game: For Sparta

-- MAIN APPLICATION
addappid(1867790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867792,0,"fef50542211e2ca6840d02335f881f1b1749a69b97dbda4d550e5b8c7688b28c")

