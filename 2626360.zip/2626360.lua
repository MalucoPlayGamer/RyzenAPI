-- Lua provided by RyzenAPI
-- Game: Game: Panda Go

-- MAIN APPLICATION
addappid(2626360)
-- Game: addappid(2626360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626361, 1, "c734fb0bf2ad487d805d61f857e7876a71b8100e455e6dc35d9b8cfec03f7247")
