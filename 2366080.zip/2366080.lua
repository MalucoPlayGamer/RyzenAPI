-- Lua provided by RyzenAPI
-- Game: addappid(2366080)

-- MAIN APPLICATION
addappid(2366080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366081, 1, "cd2d70c147ff1a554251837cdfbe9c5f91a4ef63d59d07e1d4a908971d4c2d74")
