-- Lua provided by RyzenAPI
-- Game: Game: AppID 620640

-- MAIN APPLICATION
addappid(620640)
-- Game: addappid(620640)

-- MAIN APP DEPOTS / PACKAGES
addappid(620641, 1, "ce0b1069b759ee42ed0bc491b751a55c68cb97f39b73fc01dacc46c02a976b9f")
