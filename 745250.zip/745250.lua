-- Lua provided by RyzenAPI
-- Game: YAPP: Yet Another Puzzle Platformer

-- MAIN APPLICATION
addappid(745250)

-- MAIN APP DEPOTS / PACKAGES
addappid(745251, 1, "9c02b1ef346dc01d923195868d39139820dec7e589549782ee6d373f1a16c462")

