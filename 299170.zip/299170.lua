-- Lua provided by RyzenAPI
-- Game: Vault Cracker

-- MAIN APPLICATION
addappid(299170)

-- MAIN APP DEPOTS / PACKAGES
addappid(299171, 1, "f3aab8917123fd594515172cbd386928f772a1f16db56317182e74bc4fc427b5")

