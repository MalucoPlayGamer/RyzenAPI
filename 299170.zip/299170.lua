-- Lua provided by SkyAPI 
-- Game: Vault Cracker
addappid(299170)
addappid(299171, 1, "f3aab8917123fd594515172cbd386928f772a1f16db56317182e74bc4fc427b5")
