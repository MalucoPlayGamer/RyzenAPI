-- Lua provided by RyzenAPI
-- Game: Game: AppID 892310

-- MAIN APPLICATION
addappid(892310)
-- Game: addappid(892310)

-- MAIN APP DEPOTS / PACKAGES
addappid(892311, 1, "824432a359549f1df446970c8b0808b98035a03037793dce6d52ec2b3365d8f6")
