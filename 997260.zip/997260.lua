-- Lua provided by RyzenAPI 
-- Game: Hyper Scuffle
addappid(997260)
addappid(997261, 1, "edcd5f06040c33e269db864edcc857244040c625fa6e264f708866be313bd75b")
