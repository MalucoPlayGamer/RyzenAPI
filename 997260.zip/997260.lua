-- Lua provided by RyzenAPI
-- Game: Hyper Scuffle

-- MAIN APPLICATION
addappid(997260)

-- MAIN APP DEPOTS / PACKAGES
addappid(997261, 1, "edcd5f06040c33e269db864edcc857244040c625fa6e264f708866be313bd75b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
