-- Lua provided by RyzenAPI
-- Game: Hyper Scuffle

-- MAIN APPLICATION
addappid(997260)

-- MAIN APP DEPOTS / PACKAGES
addappid(997261, 1, "edcd5f06040c33e269db864edcc857244040c625fa6e264f708866be313bd75b")

