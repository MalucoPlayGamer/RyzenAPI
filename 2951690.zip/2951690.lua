-- Lua provided by RyzenAPI
-- Game: Sonic Rumble Party

-- MAIN APPLICATION
addappid(2951690)
