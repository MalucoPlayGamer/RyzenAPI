-- Lua provided by RyzenAPI
-- Game: Game: AppID 1206700

-- MAIN APPLICATION
addappid(1206700)
-- Game: addappid(1206700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206701, 1, "40e955f94647d834bcfc6efa7ff8dbe667d5eb87944683a5d324dac897d435e5")
