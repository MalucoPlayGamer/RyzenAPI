-- Lua provided by SkyAPI 
-- Game: AppID 1206700
addappid(1206700)
addappid(1206701, 1, "40e955f94647d834bcfc6efa7ff8dbe667d5eb87944683a5d324dac897d435e5")
