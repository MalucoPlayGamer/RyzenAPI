-- Lua provided by RyzenAPI
-- Game: Game: AppID 449630

-- MAIN APPLICATION
addappid(449630)
-- Game: addappid(449630)

-- MAIN APP DEPOTS / PACKAGES
addappid(449631, 1, "d1d972083185bc0c12e7c5c4b9b218d61814255e88616c94835e898fd31a12ae")
