-- Lua provided by RyzenAPI
-- Game: ChargeShot

-- MAIN APPLICATION
addappid(401840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(401841, 1, "fa5f78b22441cfa5e7c76218cb43d3d3bc6e940b880a6910a425d7f1e582db32")

