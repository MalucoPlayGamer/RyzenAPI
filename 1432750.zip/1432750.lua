-- Lua provided by RyzenAPI
-- Game: Chionophile

-- MAIN APPLICATION
addappid(1432750)
-- Game: addappid(1432750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432751, 1, "03f6b354a85748a5be89fd25810ffde8ecdc26352a40049de1185b4b4f98b2be")
