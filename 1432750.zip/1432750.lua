-- Lua provided by RyzenAPI
-- Game: Chionophile

-- MAIN APPLICATION
addappid(1432750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1432751, 1, "03f6b354a85748a5be89fd25810ffde8ecdc26352a40049de1185b4b4f98b2be")

