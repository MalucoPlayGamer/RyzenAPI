-- Lua provided by RyzenAPI
-- Game: Labyronia Elements

-- MAIN APPLICATION
addappid(750770)
-- Game: addappid(750770)

-- MAIN APP DEPOTS / PACKAGES
addappid(750771, 1, "f66baa73cc1ec6db4cf5da5d392afb02fdf642e81544a1b8d0963bce5e65da8c")
