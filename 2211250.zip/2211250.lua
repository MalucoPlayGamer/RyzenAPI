-- Lua provided by SkyAPI 
-- Game: Of Frost and Flowers
addappid(2211250)
addappid(2211251, 1, "1a4237388e08418bc06591c2343fa02cfb71f906091839069df3893f6a5d6214")
