-- Lua provided by RyzenAPI
-- Game: Of Frost and Flowers

-- MAIN APPLICATION
addappid(2211250)
-- Game: addappid(2211250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211251, 1, "1a4237388e08418bc06591c2343fa02cfb71f906091839069df3893f6a5d6214")
