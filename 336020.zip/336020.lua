-- Lua provided by RyzenAPI
-- Game: addappid(336020)

-- MAIN APPLICATION
addappid(336020)

-- MAIN APP DEPOTS / PACKAGES
addappid(336021, 1, "581adb44792ca383f22aaed1eef5528623ca22eaab31860efd119b3fa1ac4c2e")
