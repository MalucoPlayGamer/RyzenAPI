-- Lua provided by RyzenAPI
-- Game: Beat Saber - Metallica - "Master of Puppets"

-- MAIN APPLICATION
addappid(3354630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354630,0,"bceb367a4621591786c1fd546ebd91fb148284e14f0f8110c32e18dbadf9e2d3")
