-- Lua provided by RyzenAPI
-- Game: addappid(2103400)

-- MAIN APPLICATION
addappid(2103400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103401, 1, "8a1b1aa5b96b5937a86534bce39046bf9af3ef624130eb7dd94245c4734a7e48")
