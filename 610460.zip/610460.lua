-- Lua provided by RyzenAPI
-- Game: addappid(610460)

-- MAIN APPLICATION
addappid(610460)

-- MAIN APP DEPOTS / PACKAGES
addappid(610461, 1, "d57c29410cb50ff08738901d0beba20853b1ea69a392cda178f7d5601f0875ab")
addappid(610462, 1, "b9a11f0a7572f02da8a88e815a04fdeb3a5c2023fb8f2f28eec70bc0729afef5")
addappid(610463, 1, "42ca08d32ff94803180958404d78141fcf5f2f0b5e10d1013b0eb42db8eda0e7")
