-- Lua provided by RyzenAPI
-- Game: addappid(842270)

-- MAIN APPLICATION
addappid(842270)

-- MAIN APP DEPOTS / PACKAGES
addappid(842271, 1, "1963fb7f98bf9a77b78a5afce107b809f50a302638a7a2c7189a7d0242ab9444")
