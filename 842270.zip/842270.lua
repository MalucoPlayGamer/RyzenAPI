-- Lua provided by RyzenAPI
-- Game: Formula X

-- MAIN APPLICATION
addappid(842270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(842271, 1, "1963fb7f98bf9a77b78a5afce107b809f50a302638a7a2c7189a7d0242ab9444")

