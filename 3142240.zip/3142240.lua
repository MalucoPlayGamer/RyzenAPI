-- Lua provided by RyzenAPI
-- Game: Симулятор Чушпана 2 Soundtrack

-- MAIN APPLICATION
addappid(3142240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142241, 1, "cf098480bfb6b8a39652c9b5b0dc964175a474b595889c1a603cf33defd4788f")
addappid(3142242, 1, "19437ac8327e70ca3a252dbe75de1d08045a3c5c6440e03a18b117de445c5e16")

