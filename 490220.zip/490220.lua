-- Lua provided by RyzenAPI
-- Game: Prismata

-- MAIN APPLICATION
addappid(490220)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(534640)
