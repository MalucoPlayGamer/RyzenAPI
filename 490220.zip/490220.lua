-- Lua provided by RyzenAPI
-- Game: Prismata

-- MAIN APPLICATION
addappid(490220)
addappid(534640)

