-- Lua provided by RyzenAPI
-- Game: Way to Go! Demo

-- MAIN APPLICATION
addappid(228990)
addappid(229002)
addappid(229012)
addappid(337830)
addappid(337831)

-- MAIN APP DEPOTS / PACKAGES
addappid(336232,0,"8f9ee48647a58c402d64f0600fca9745e6a10f4c1deb518b5fe7e8a8c8929d0f")
addappid(336233,0,"f0a5e6cb356adc84cbe99d7873d5577ab005ce2f4019395453428982933dd330")
addappid(336234,0,"9968863626c45077b414e87338dd48187c464bbfeb7a74ca31376f8a5413639d")
addappid(336235,0,"38fef7d5b5c8348be9a3a5e500b3a0957f6d5e3906992e6313d72663ce5fb890")

