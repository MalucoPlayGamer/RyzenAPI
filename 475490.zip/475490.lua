-- Lua provided by RyzenAPI
-- Game: AppID 475490

-- MAIN APPLICATION
addappid(475490)

-- MAIN APP DEPOTS / PACKAGES
addappid(475491, 1, "b016c915949771f655e5e71d930547d0973fdbe0d689f2ec7a93aae02a1d48cb")
addappid(475492, 1, "58113750e984795818161d1a2d06fbf11119fd466e4d6072b98fa5a56d900bd3")
addappid(475493, 1, "413ee1757a5951a846ec648c01119e570f0330872f74f805665430b1709f0d60")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1686040)
