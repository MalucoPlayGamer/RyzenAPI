-- Lua provided by RyzenAPI
-- Game: 2324720

-- MAIN APPLICATION
addappid(2324720)
-- Game: addappid(2324720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324720,0,"ab5ff41aa2959290c69697a536d07053713debb34bd03d22dd1e75dc2040fe25")
