-- Lua provided by RyzenAPI
-- Game: 1679910

-- MAIN APPLICATION
addappid(1679910)
-- Game: addappid(1679910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679911, 1, "7d603c51c5326812ed8bf50bc2e483d13c135cc94be6a411b1ddb80ea5bd3725")
