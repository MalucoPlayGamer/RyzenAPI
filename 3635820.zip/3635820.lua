-- Lua provided by RyzenAPI
-- Game: addappid(3635820)

-- MAIN APPLICATION
addappid(3635820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3635821, 1, "4e0e1683dfb77b9b7e3996a676cc9381122f6165490bd5f5a22c86f9d4c75c55")
