-- Lua provided by RyzenAPI 
-- Game: SANDSPEED: CAMEL RACING
addappid(3635820)
addappid(3635821, 1, "4e0e1683dfb77b9b7e3996a676cc9381122f6165490bd5f5a22c86f9d4c75c55")
