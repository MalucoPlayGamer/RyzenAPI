-- Lua provided by RyzenAPI
-- Game: Angel Wings

-- MAIN APPLICATION
addappid(862440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(862441, 1, "28b140d86af72d6f7962826ca3265ca69327e6d7093063b7dd4018e43d6dbf64")

