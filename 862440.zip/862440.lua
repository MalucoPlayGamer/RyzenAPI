-- Lua provided by RyzenAPI
-- Game: 862440

-- MAIN APPLICATION
addappid(862440)
-- Game: addappid(862440)

-- MAIN APP DEPOTS / PACKAGES
addappid(862441, 1, "28b140d86af72d6f7962826ca3265ca69327e6d7093063b7dd4018e43d6dbf64")
