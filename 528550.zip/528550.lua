-- Lua provided by RyzenAPI
-- Game: Drunkn Bar Fight

-- MAIN APPLICATION
addappid(528550)

-- MAIN APP DEPOTS / PACKAGES
addappid(528551, 1, "295061648184e6e3983e870f392be0b0e7a5cce067aba2c993acd36ec81ad577")
