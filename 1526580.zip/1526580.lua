-- Lua provided by RyzenAPI
-- Game: Game: Zombie Dungeon

-- MAIN APPLICATION
addappid(1526580)
-- Game: addappid(1526580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526581, 1, "a521ac8a4064c254768a54493d70bba846f99a0c1039af58c7316b81f4c00583")
