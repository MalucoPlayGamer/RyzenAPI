-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9 Empires - Season Pass

-- MAIN APPLICATION
addappid(1684147)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684147,0,"3d91ad83b987b5bd42171f7de021cfa804761da9bcf07e61e682137ac6076edf")

