-- Lua provided by RyzenAPI
-- Game: AppID 3008400

-- MAIN APPLICATION
addappid(3008400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008401, 1, "a1094ff5c3b7d87dde931aed4da18ffd1929029c65b2f8aa989aaa7d216e380f")
