-- Lua provided by SkyAPI 
-- Game: Sky Gamblers: Storm Raiders
addappid(304910)
addappid(304911, 1, "0a5983508e65f5e8170be21ed5379fb70c80651f3fe7ad816c697b17807377f0")
