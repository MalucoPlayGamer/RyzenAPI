-- Lua provided by RyzenAPI
-- Game: Game: Sky Gamblers: Storm Raiders

-- MAIN APPLICATION
addappid(304910)
-- Game: addappid(304910)

-- MAIN APP DEPOTS / PACKAGES
addappid(304911, 1, "0a5983508e65f5e8170be21ed5379fb70c80651f3fe7ad816c697b17807377f0")
