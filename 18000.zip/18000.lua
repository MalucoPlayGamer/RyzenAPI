-- Lua provided by RyzenAPI
-- Game: 18000

-- MAIN APPLICATION
addappid(18000)
-- Game: addappid(18000)

-- MAIN APP DEPOTS / PACKAGES
addappid(18001, 1, "ceab09e9f1ac772cd37ef3c3141086c2654f491336dae69e08e56f5b406d28b9")
addappid(18002, 1, "81fbdac4c7006a193d778e310e5a1cfda2ed80ec8ac16a04d6262844d83305d8")
