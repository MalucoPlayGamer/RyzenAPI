-- Lua provided by RyzenAPI
-- Game: Game: Lam Lam

-- MAIN APPLICATION
addappid(2169800)
-- Game: addappid(2169800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169801, 1, "150c00958510b931604544676299be6c040d62425bd5c1d3e40a255cd3a044e0")
