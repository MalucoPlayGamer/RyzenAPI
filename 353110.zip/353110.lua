-- Lua provided by RyzenAPI
-- Game: Game: Dreamscapes: Nightmare's Heir - Premium Edition

-- MAIN APPLICATION
addappid(353110)
-- Game: addappid(353110)

-- MAIN APP DEPOTS / PACKAGES
addappid(353111, 1, "e254da44406618038a8fcafd32fdc349f5c6617654ea9edf073b6f7ab85ae4e6")
