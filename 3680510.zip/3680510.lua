-- Lua provided by RyzenAPI 
-- Game: Sip Fisher
addappid(3680510)
addappid(3680511, 1, "21185b25e6446e4dbd744bb41de47f3add55a99df642cf8f9b87792b08e2548e")
