-- Lua provided by RyzenAPI
-- Game: 3680510

-- MAIN APPLICATION
addappid(3680510)
-- Game: addappid(3680510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3680511, 1, "21185b25e6446e4dbd744bb41de47f3add55a99df642cf8f9b87792b08e2548e")
