-- Lua provided by RyzenAPI 
-- Game: Stealth Kill VR Missions Demo
addappid(3008610)
addappid(3008611, 1, "19126f50338482492514be0b41f8b8c37413a1173a234c719bf746f63f14e699")
