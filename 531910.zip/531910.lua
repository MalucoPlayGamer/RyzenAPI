-- Lua provided by RyzenAPI
-- Game: Bad Sector HDD

-- MAIN APPLICATION
addappid(531910)

-- MAIN APP DEPOTS / PACKAGES
addappid(531911, 1, "994641595350cae0071e2be44bab1aaa26923f690bbcf30e45e1dbc4bdcf8498")
