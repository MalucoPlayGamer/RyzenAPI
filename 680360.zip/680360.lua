-- Lua provided by RyzenAPI
-- Game: Regions Of Ruin

-- MAIN APPLICATION
addappid(680360)

-- MAIN APP DEPOTS / PACKAGES
addappid(680361, 1, "a6285253d76d03ae4f3be14b21804b3e3a2dc9f570f6a5c5e77cc751ede844a1")
addappid(680362, 1, "f2171842662cd01819979ab3c64a58ee57a14870ccbc0f54371da926071cf873")
addappid(680363, 1, "c33468b6905d9a0cf3abab57d3ffd3a3ed3b590d6df19bd27f239501ee2b7368")
addappid(680365, 1, "8779592a99c5d16c8277bd735d792895a124fc018f77b59665c4f5b74e6ba412")
addappid(680366, 1, "b0bc3236848d7c33b92d6aaa50525a76b914d4190bf9a77e01449758e2097ac4")
addappid(680367, 1, "a4cc0e9f44003def3bdb291f8536dd7cd568c18a420b0d66c733bfd3bac6f1bf")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(723080)
addappid(843800)
