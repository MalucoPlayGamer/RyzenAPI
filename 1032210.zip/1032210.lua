-- Lua provided by RyzenAPI
-- Game: 2014.Aftermath

-- MAIN APPLICATION
addappid(1032210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032211, 1, "aff5378d0acb1afef206958a9acf2087652302776e171e882c7f3e0823c35af6")
