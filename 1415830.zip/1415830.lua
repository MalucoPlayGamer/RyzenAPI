-- Lua provided by RyzenAPI
-- Game: Game: Necrosis

-- MAIN APPLICATION
addappid(1415830)
-- Game: addappid(1415830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415831, 1, "aa982cc55c498891d9a237c17c395c57e009b5348070397a3f4d3d76debae522")
