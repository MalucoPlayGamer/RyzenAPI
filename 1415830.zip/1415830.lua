-- Lua provided by RyzenAPI
-- Game: Necrosis

-- MAIN APPLICATION
addappid(1415830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415831, 1, "aa982cc55c498891d9a237c17c395c57e009b5348070397a3f4d3d76debae522")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
