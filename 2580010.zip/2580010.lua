-- Lua provided by SkyAPI 
-- Game: Echoes Of Steel
addappid(2580010)
addappid(2580011, 1, "2d9dede12781e346130f3045d6bd6aa3d88578666f8575a44d17c00d1a4a1962")
