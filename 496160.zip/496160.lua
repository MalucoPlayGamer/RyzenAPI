-- Lua provided by RyzenAPI
-- Game: addappid(496160)

-- MAIN APPLICATION
addappid(496160)

-- MAIN APP DEPOTS / PACKAGES
addappid(496161, 1, "239bee202b9115b32330476ad16ad57494cec4f1cf6bd4e116d3c873804bedf3")
