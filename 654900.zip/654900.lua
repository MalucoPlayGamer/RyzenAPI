-- Lua provided by RyzenAPI
-- Game: Game: qop

-- MAIN APPLICATION
addappid(654900)
-- Game: addappid(654900)

-- MAIN APP DEPOTS / PACKAGES
addappid(654901, 1, "5c674b6dc0832f3b11fb805637c2c60078df6994671ee3801be46dfeff184f63")
addappid(687820, 0, "267ff0784e1c5acd03001f39f5c91a15d5d02703d62720ce355172e56f27fcf4")
