-- Lua provided by RyzenAPI
-- Game: Game: Last Year: The Nightmare

-- MAIN APPLICATION
addappid(511440)
-- Game: addappid(511440)

-- MAIN APP DEPOTS / PACKAGES
addappid(511441, 1, "3017fde25125483817a596d524ce85beca20745228fe5c192464754e8ef601ef")
addappid(511442, 1, "896088e1bf9a5837b20657e1d3b8305f334897207b315e836978ba71c5c15120")
