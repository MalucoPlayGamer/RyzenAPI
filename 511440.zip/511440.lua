-- Lua provided by RyzenAPI
-- Game: Last Year: The Nightmare

-- MAIN APPLICATION
addappid(511440)
addappid(688040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(511441, 1, "3017fde25125483817a596d524ce85beca20745228fe5c192464754e8ef601ef")
addappid(511442, 1, "896088e1bf9a5837b20657e1d3b8305f334897207b315e836978ba71c5c15120")

