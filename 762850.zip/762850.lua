-- Lua provided by RyzenAPI
-- Game: 762850

-- MAIN APPLICATION
addappid(762850)
-- Game: addappid(762850)

-- MAIN APP DEPOTS / PACKAGES
addappid(762851, 1, "cb999d9f22f986e2529497fae26cf51dce335351122c73a89a7313c239c274bf")
