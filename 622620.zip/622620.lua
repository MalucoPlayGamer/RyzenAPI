-- Lua provided by RyzenAPI
-- Game: Nightmare Adventures: The Turning Thorn

-- MAIN APPLICATION
addappid(622620)

-- MAIN APP DEPOTS / PACKAGES
addappid(622621,0,"b1ddc74021ce9baa5b5bd81fed60763335da140847a31ddd3a3e7008aa9d87fa")

