-- Lua provided by RyzenAPI 
-- Game: Unfortunate Spacemen
addappid(408900)
addappid(408901, 1, "8d004395f00d6dc127dafc3ec6814656c9fe61ff8242ba9117b53de6b046e1f7")
addappid(1349010)
