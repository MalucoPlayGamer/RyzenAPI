-- Lua provided by RyzenAPI
-- Game: 408900

-- MAIN APPLICATION
addappid(408900)
addappid(1349010)
-- Game: addappid(408900)

-- MAIN APP DEPOTS / PACKAGES
addappid(408901, 1, "8d004395f00d6dc127dafc3ec6814656c9fe61ff8242ba9117b53de6b046e1f7")
