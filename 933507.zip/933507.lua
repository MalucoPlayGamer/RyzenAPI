-- Lua provided by RyzenAPI
-- Game: addappid(933507)

-- MAIN APPLICATION
addappid(933507)

-- MAIN APP DEPOTS / PACKAGES
addappid(933507,0,"a03edf0943ea688517d598ddaeed7cabafa0b10c1bb381ee76037cbba27b66d6")
addtoken(933507,14501482262133531908)
