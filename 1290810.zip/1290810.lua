-- Lua provided by RyzenAPI
-- Game: Game: AppID 1290810

-- MAIN APPLICATION
addappid(1290810)
-- Game: addappid(1290810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290811, 1, "99688e94b53127f406f1fb978bbc50b805561e0eb893f844f9933b029e1a1d1e")
