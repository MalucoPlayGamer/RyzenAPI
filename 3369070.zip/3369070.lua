-- Lua provided by RyzenAPI
-- Game: addappid(3369070)

-- MAIN APPLICATION
addappid(3369070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369071, 1, "fb1cf4f7ef604c1c832043b3d97f863d9a62c048ccc044f94f0eb009d99b9f78")
addappid(3836080, 0, "8e06b897611bb074aa685d2d0bcfe7e9d8a3de0debb388895d8e7e626772f166")
addappid(3838750, 0, "465d4256a1afb50cd95b121bd8ea3631aa16d894331fdaab1420ecef77cae91e")
