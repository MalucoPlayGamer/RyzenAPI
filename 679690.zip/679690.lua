-- Lua provided by RyzenAPI
-- Game: SwapQuest

-- MAIN APPLICATION
addappid(679690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(679691, 1, "213d0809456b485c6bf36b4164f33bbfaf53d99df0ee8eb77fbf40592d3497f4")
addappid(685830, 0, "aef0110f7dd1864a4261028d70f4aaa1bde3f5ba96bc78fa450d8f667df7d10d")

