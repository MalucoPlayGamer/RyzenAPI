-- Lua provided by RyzenAPI
-- Game: I got PINNED by a FUTANARI

-- MAIN APPLICATION
addappid(3080210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080211, 1, "38ffe9dc78feef153c36bd0e0f63eef6ed575e5f21cad53b09a0db469fc658fa")
