-- Lua provided by RyzenAPI
-- Game: Requiem Memory

-- MAIN APPLICATION
addappid(2548250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548251, 1, "701e1d1d2b9f6ce437640f44a977978506e415e3b7f07480d95a49a10dd8a968")

