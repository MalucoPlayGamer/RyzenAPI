-- Lua provided by RyzenAPI
-- Game: ARK: Survival Evolved Original Soundtrack

-- MAIN APPLICATION
addappid(1646550)
-- Game: addappid(1646550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646551, 1, "db7bbfcc0ebe1f42b12be40c9e702ef82fcf783b73b86a2684ef58bd13820805")
