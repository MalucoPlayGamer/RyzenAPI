-- Lua provided by RyzenAPI
-- Game: 3395140

-- MAIN APPLICATION
addappid(3395140)
addappid(3947680)
-- Game: addappid(3395140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3395141, 1, "f790bdf4b2a593f8aa9ba91d22825cb001b52156935252c18e6b0445da8b0cd9")
