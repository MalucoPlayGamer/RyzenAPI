-- Lua provided by SkyAPI 
-- Game: AppID 1307180
addappid(1307180)
addappid(1307181, 1, "2d07d1448f2530f37066b1cf6d997ca80611916be0a26b393671eb8634563680")
