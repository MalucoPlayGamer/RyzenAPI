-- Lua provided by RyzenAPI
-- Game: Twisted Tower

-- MAIN APPLICATION
addappid(1575990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575991,0,"734ae639f98a4a293b9234c8cb375ab906ef93823d4d6cde34591bd2e107c258")

