-- Lua provided by RyzenAPI
-- Game: The Midnight Walk

-- MAIN APPLICATION
addappid(2863640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863641, 1, "6280ec508a2efdb3808c9bd11bd91b715519a1a4d2ed3c040192b39814aded91")

