-- Lua provided by RyzenAPI
-- Game: Omelet You Cook

-- MAIN APPLICATION
addappid(3205380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205381, 1, "9a32ab58b063f1ce04e0ba099d336a8ba9a61c15434859ef88ef8ba33a959bff")

