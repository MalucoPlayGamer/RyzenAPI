-- Lua provided by RyzenAPI
-- Game: AppID 859460

-- MAIN APPLICATION
addappid(859460)
-- Game: addappid(859460)

-- MAIN APP DEPOTS / PACKAGES
addappid(859461, 1, "15f74198ec35086187e045498be32dbfe59c60484149afd5ead2c45985bb75e4")
