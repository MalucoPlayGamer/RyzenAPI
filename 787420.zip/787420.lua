-- Lua provided by RyzenAPI
-- Game: Robot Fighting

-- MAIN APPLICATION
addappid(787420)

-- MAIN APP DEPOTS / PACKAGES
addappid(787421, 1, "136c6f74a14893e4ac446079bfe7c372c3e8da14210abc4a11341920606688db")
