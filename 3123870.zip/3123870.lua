-- Lua provided by RyzenAPI
-- Game: AppID 3123870

-- MAIN APPLICATION
addappid(3123870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123871, 1, "648c27f83f362b6ecb5466cee7469cee2c75aaa09364bff21af8df7b067189f2")
