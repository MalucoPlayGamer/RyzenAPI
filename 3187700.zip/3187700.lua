-- Lua provided by RyzenAPI
-- Game: Short Trip

-- MAIN APPLICATION
addappid(3187700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3187701, 1, "fabbac859c87bec545672cc0a4bf114800aad837cdd3cc01515fbd69f3b72cfa")

