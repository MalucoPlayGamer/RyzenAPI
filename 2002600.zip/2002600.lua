-- Lua provided by RyzenAPI
-- Game: 吞食一统中原Tunshi  unifying plains

-- MAIN APPLICATION
addappid(2002600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002601, 1, "ebdaec4c1b59d0ae633026bf32a980ba20f4c11a78bc310ef2cc97688a091bf4")
