-- Lua provided by RyzenAPI
-- Game: 1554480

-- MAIN APPLICATION
addappid(1554480)
-- Game: addappid(1554480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554480,0,"d00d8321392cc4e43fcadef2dd49fdb9275eb971ab76f7a0e8c8e6db083d51ae")
