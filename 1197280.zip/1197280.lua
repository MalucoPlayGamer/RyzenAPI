-- Lua provided by RyzenAPI
-- Game: Cyber Pussy 2020

-- MAIN APPLICATION
addappid(1197280)
addappid(1199590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197281, 1, "ca32a06fbcd9c37b1772f0539ce9b11996b53bdc0f159e376fd98025510301c6")
