-- Lua provided by RyzenAPI
-- Game: AppID 1197280

-- MAIN APPLICATION
addappid(1197280)
-- Game: addappid(1197280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197281, 1, "ca32a06fbcd9c37b1772f0539ce9b11996b53bdc0f159e376fd98025510301c6")
