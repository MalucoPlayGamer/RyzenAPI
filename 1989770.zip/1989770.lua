-- Lua provided by RyzenAPI
-- Game: Game: Chickenoidz Super Party

-- MAIN APPLICATION
addappid(1989770)
-- Game: addappid(1989770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989771, 1, "34aea469675611758ecfa2a73191e73c4d0b1e9a9c48013da6da7f9de8a4ddf0")
