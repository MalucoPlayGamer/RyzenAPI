-- Lua provided by RyzenAPI
-- Game: Game: Sonic the Hedgehog 4 - Episode II

-- MAIN APPLICATION
addappid(203650)
-- Game: addappid(203650)

-- MAIN APP DEPOTS / PACKAGES
addappid(203651, 1, "c090444c110ea4a60676099ef324bce5fec7e70c815ba6b79c0ca5e6b5b44eb4")
