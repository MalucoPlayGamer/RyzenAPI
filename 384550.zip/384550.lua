-- Lua provided by RyzenAPI
-- Game: addappid(384550)

-- MAIN APPLICATION
addappid(384550)
addappid(395700)

-- MAIN APP DEPOTS / PACKAGES
addappid(384551, 1, "15d6883c26e6ef1a01deff446a649eda83f5b4e8a8161565e9b156c0a0aef7cb")
