-- Lua provided by RyzenAPI
-- Game: AppID 542790

-- MAIN APPLICATION
addappid(542790)

-- MAIN APP DEPOTS / PACKAGES
addappid(542791, 1, "ae3eb5d0c7304f34289656118c4c80b635ee845705901070678a0fd70a6a68ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
