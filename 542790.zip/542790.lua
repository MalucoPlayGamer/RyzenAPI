-- Lua provided by RyzenAPI
-- Game: 542790

-- MAIN APPLICATION
addappid(542790)
-- Game: addappid(542790)

-- MAIN APP DEPOTS / PACKAGES
addappid(542791, 1, "ae3eb5d0c7304f34289656118c4c80b635ee845705901070678a0fd70a6a68ad")
