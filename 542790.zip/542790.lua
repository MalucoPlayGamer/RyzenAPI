-- Lua provided by RyzenAPI 
-- Game: AppID 542790
addappid(542790)
addappid(542791, 1, "ae3eb5d0c7304f34289656118c4c80b635ee845705901070678a0fd70a6a68ad")
