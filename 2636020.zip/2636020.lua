-- Lua provided by RyzenAPI
-- Game: EX-XDRiVER

-- MAIN APPLICATION
addappid(2636020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636021, 1, "50fb6f931ed9b8750573d2032568453d167a74b72934a4b4f22a1c2de540fe57")
addappid(2636022, 1, "918a6ee40e6f80e1804307e7c54ce3273cf0e374de278c0a91e7cdc1e676552d")
addappid(2636023, 1, "2d3f3b123c62c11fc1401d86ecb472431a67de768f19b0555fe25b6b06ffd5fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
