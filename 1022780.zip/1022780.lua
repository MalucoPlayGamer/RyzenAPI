-- Lua provided by RyzenAPI
-- Game: Animal Fight Club

-- MAIN APPLICATION
addappid(1022780)
addappid(1076190)
-- Game: addappid(1022780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022781, 1, "0032c1b3eefa6f5c609e948274aba4242a6296045c31d151457295aaea28e228")
addappid(1022782, 1, "265a8b2374d2ffabdc445f9b233cd97cf89c71a1b7b83906db4937eaeb24356d")
addappid(1022783, 1, "727a6408ad60a700b9b696d2b43a1b0bf220f0391570cf28a2766923b4d096b6")
