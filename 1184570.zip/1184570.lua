-- Lua provided by RyzenAPI
-- Game: Game: Last Neighbor

-- MAIN APPLICATION
addappid(1184570)
-- Game: addappid(1184570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184571, 1, "0c8d52bc5ac4ad7ec19bccef71bf0f5a3a5eccf878015416f6b5821b0e877f0b")
