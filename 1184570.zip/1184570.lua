-- Lua provided by SkyAPI 
-- Game: Last Neighbor
addappid(1184570)
addappid(1184571, 1, "0c8d52bc5ac4ad7ec19bccef71bf0f5a3a5eccf878015416f6b5821b0e877f0b")
