-- Lua provided by RyzenAPI
-- Game: Cute BAR - Artbook 18+

-- MAIN APPLICATION
addappid(1858520)
-- Game: addappid(1858520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858520,0,"907193e6c47ef43c4b72de3c75c84b0a8e833575d74bbb3985b6d6d34faaf330")
addtoken(1858520,6422960676052584216)
