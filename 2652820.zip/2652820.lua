-- Lua provided by RyzenAPI
-- Game: Game: Mechanical Trap

-- MAIN APPLICATION
addappid(2652820)
-- Game: addappid(2652820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2652821, 1, "545951eb7e95c3f85293d04d82c8278653db1719d04df3bae4069f7d7bcd4c47")
