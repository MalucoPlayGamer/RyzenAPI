-- Lua provided by RyzenAPI
-- Game: Poems & Codes

-- MAIN APPLICATION
addappid(2295070)
-- Game: addappid(2295070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295074,0,"c6c9b5b6c6a414edc759c17e46d7593701364576432679ea14e631d324c8329b")
