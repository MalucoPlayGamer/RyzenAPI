-- Lua provided by RyzenAPI
-- Game: Ultra Cop

-- MAIN APPLICATION
addappid(3274790)
-- Game: addappid(3274790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274791, 1, "829eac4a4583d8a7dc35830eb86498550cb13f09b6f5ad732339701984598b86")
