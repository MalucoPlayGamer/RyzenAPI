-- Lua provided by RyzenAPI
-- Game: Maseylia: Echoes of the past

-- MAIN APPLICATION
addappid(2938870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938871,0,"7f554a9782de19ca87fa333f2663b9a660858205b9fc0f614bb0e48fda6b8769")

