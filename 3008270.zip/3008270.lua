-- Lua provided by RyzenAPI
-- Game: Tree of Sacrifice

-- MAIN APPLICATION
addappid(3008270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008271, 1, "2e2602c5e78f2281130b31df7f8717fada00d83b2f62ecc8f8be0c367f3846a7")

