-- Lua provided by RyzenAPI
-- Game: Silent: Abandoned

-- MAIN APPLICATION
addappid(3108720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3108721, 1, "71e6c021f32a127e8ca56575ce725fe840dae530e4b5600fc6a574a4e408ca8c")

