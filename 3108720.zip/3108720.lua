-- Lua provided by RyzenAPI
-- Game: Silent: Abandoned

-- MAIN APPLICATION
addappid(3108720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108721, 1, "71e6c021f32a127e8ca56575ce725fe840dae530e4b5600fc6a574a4e408ca8c")
