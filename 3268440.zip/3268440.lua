-- Lua provided by RyzenAPI
-- Game: 3268440

-- MAIN APPLICATION
addappid(3268440)
-- Game: addappid(3268440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268441, 1, "f2c67ca795635221d7e11bf4b809d906399d835f0f3d584d2bf271d2146b1c1f")
