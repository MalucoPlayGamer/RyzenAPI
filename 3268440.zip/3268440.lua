-- Lua provided by SkyAPI 
-- Game: SIM SPORTS RAID
addappid(3268440)
addappid(3268441, 1, "f2c67ca795635221d7e11bf4b809d906399d835f0f3d584d2bf271d2146b1c1f")
