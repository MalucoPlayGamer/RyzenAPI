-- Lua provided by RyzenAPI
-- Game: Kingdom Warrior

-- MAIN APPLICATION
addappid(1208510)
addappid(1208511)
-- Game: addappid(1208510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208512,0,"3bd1a3cb9da4b4836272b92ac2b5a31d1ea6961cd81824d0827875ae5296def9")
