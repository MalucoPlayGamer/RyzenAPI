-- Lua provided by SkyAPI 
-- Game: The Forgotten Concluder
addappid(2159730)
addappid(2159731, 1, "fd54f478eca8c672671b2e70af432549809a19e5d47b5a06112bf58b5ca46985")
