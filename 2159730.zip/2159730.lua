-- Lua provided by RyzenAPI
-- Game: The Forgotten Concluder

-- MAIN APPLICATION
addappid(2159730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159731, 1, "fd54f478eca8c672671b2e70af432549809a19e5d47b5a06112bf58b5ca46985")
