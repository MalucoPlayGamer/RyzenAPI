-- Lua provided by RyzenAPI
-- Game: FaceRig Workshop Utility Kit

-- MAIN APPLICATION
addappid(329720)

-- MAIN APP DEPOTS / PACKAGES
addappid(329721, 1, "ecf44e8367ff2acb5f268ef2247596168ef57056806f86f0931454785c3dc449")
