-- Lua provided by RyzenAPI
-- Game: Idle Campaign

-- MAIN APPLICATION
addappid(1141320)
-- Game: addappid(1141320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141321, 1, "f7433c2d25280d841e64eb810744bae4896963ab2c85c81776c7620f4e4a8e50")
