-- Lua provided by RyzenAPI
-- Game: 2303720

-- MAIN APPLICATION
addappid(2303720)
-- Game: addappid(2303720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303721, 1, "a163935494e0b404272476b4592503dbc95bafe8718fb5ae44e424bcf403fdcc")
