-- Lua provided by RyzenAPI 
-- Game: Multiplayer Cowboys
addappid(2303720)
addappid(2303721, 1, "a163935494e0b404272476b4592503dbc95bafe8718fb5ae44e424bcf403fdcc")
