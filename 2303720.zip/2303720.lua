-- Lua provided by RyzenAPI
-- Game: Multiplayer Cowboys

-- MAIN APPLICATION
addappid(2303720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303721, 1, "a163935494e0b404272476b4592503dbc95bafe8718fb5ae44e424bcf403fdcc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
