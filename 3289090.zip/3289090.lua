-- Lua provided by RyzenAPI
-- Game: Ghost Master: Resurrection

-- MAIN APPLICATION
addappid(3289090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289091, 1, "da1a6bcad881eef9d2c2a1224fa9d28942b4f4ecd313cb24b7d91007c2666f23")
