-- Lua provided by RyzenAPI
-- Game: Ghost Master: Resurrection

-- MAIN APPLICATION
addappid(3289090)
addappid(4369970)
addappid(4369980)
addappid(4369990)
addappid(4370000)
addappid(4552800)
addappid(4636150)
addappid(4636170)
addappid(4636190)
addappid(4636200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3289091, 1, "da1a6bcad881eef9d2c2a1224fa9d28942b4f4ecd313cb24b7d91007c2666f23")

