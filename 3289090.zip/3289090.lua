-- Lua provided by SkyAPI 
-- Game: Ghost Master: Resurrection
addappid(3289090)
addappid(3289091, 1, "da1a6bcad881eef9d2c2a1224fa9d28942b4f4ecd313cb24b7d91007c2666f23")
