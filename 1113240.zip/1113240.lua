-- Lua provided by RyzenAPI
-- Game: Game: AppID 1113240

-- MAIN APPLICATION
addappid(1113240)
-- Game: addappid(1113240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113241, 1, "af2d6e2255aa8a6fd3efc634332e6debfc7a6d25144df2e488b6974c986a9597")
addappid(1113242, 1, "832fc31cc500d0406013d6203fcb6a3c18edd13d287693c898347a8fe3d72912")
