-- Lua provided by RyzenAPI
-- Game: Alice Through the Fey Realm

-- MAIN APPLICATION
addappid(2707340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707341, 1, "c28fa0c588b0761558e8f945bdcb690dd7c8db0f41831d6577696b04c9956aa5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
