-- Lua provided by RyzenAPI
-- Game: Game: Alice Through the Fey Realm

-- MAIN APPLICATION
addappid(2707340)
-- Game: addappid(2707340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707341, 1, "c28fa0c588b0761558e8f945bdcb690dd7c8db0f41831d6577696b04c9956aa5")
