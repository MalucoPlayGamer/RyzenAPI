-- Lua provided by RyzenAPI
-- Game: Soundodger 2

-- MAIN APPLICATION
addappid(1400910)
-- Game: addappid(1400910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400911, 1, "048a1514b9ab41b781dd3319f1b35b7cd013d8889ec602c40a911d80722fab58")
