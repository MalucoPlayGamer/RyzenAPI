-- Lua provided by RyzenAPI
-- Game: Living with temptation CLASSIC

-- MAIN APPLICATION
addappid(1550600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550601, 1, "ebbfe7755deb85ff5670972085c974da0ca5f014c7edfc48ea20916546bb56f9")
addappid(2243090, 0, "f7a86001680504aef261fa839787e27ae8814d7f0c5f034b6265d20dc8d13d59")

