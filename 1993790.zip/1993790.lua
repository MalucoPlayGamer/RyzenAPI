-- Lua provided by RyzenAPI
-- Game: Clarent Saga: Chronicles Demo

-- MAIN APPLICATION
addappid(1993790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993791, 1, "f12bc5ec0220365450d83ae30555cd69a7bebf472c4e9e8697e9914bbd836958")
