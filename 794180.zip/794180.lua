-- Lua provided by RyzenAPI
-- Game: Game: PRO FISHING SIMULATOR

-- MAIN APPLICATION
addappid(794180)
addappid(903690)
-- Game: addappid(794180)

-- MAIN APP DEPOTS / PACKAGES
addappid(794181, 1, "3f76e87d045e093f2ca450be98a9b788806679f28ceb4481dfb2edc6cb707a67")
