-- Lua provided by RyzenAPI
-- Game: 664420

-- MAIN APPLICATION
addappid(664420)
-- Game: addappid(664420)

-- MAIN APP DEPOTS / PACKAGES
addappid(664421, 1, "bedb233872efaaa21d034570e61f46ce8aac6a65868c694313d989c0e779be63")
addappid(667200, 0, "825149fb6ec72f4770ff5841ec6e389099afdcfec701ad59b74c939a00dd4990")
