-- Lua provided by RyzenAPI
-- Game: addappid(1846830)

-- MAIN APPLICATION
addappid(1846830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846831, 1, "ce4d2e1cade1913b6983841c9a17682268bf288ba3583fe8e025f20424e2e687")
