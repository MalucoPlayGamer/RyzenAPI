-- Lua provided by SkyAPI 
-- Game: Gummings
addappid(1846830)
addappid(1846831, 1, "ce4d2e1cade1913b6983841c9a17682268bf288ba3583fe8e025f20424e2e687")
