-- Lua provided by RyzenAPI
-- Game: Dark Sky - Art Supporter Pack

-- MAIN APPLICATION
addappid(3215900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215900,0,"77fe00913724a65c72adc8d2faa994e95205d27bdce523ae30aad3f912843558")
