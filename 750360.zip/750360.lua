-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: On Ice

-- MAIN APPLICATION
addappid(750360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(750361, 1, "7eac766eca0fe8cfc9d47a51befab0b6d4e248d8d0fbdced42b285cc70851121")
addappid(750362, 1, "3008e38aff830af061434f063115191e2faf7a98f8185467bda5cfae2c6b5203")

