-- Lua provided by RyzenAPI 
-- Game: AppID 3097950
addappid(3097950)
addappid(3097951, 1, "d4b836013762a7e7fb5c67eaf64ec9c12f0e99a0ecda75d1966707f3c1c74e88")
