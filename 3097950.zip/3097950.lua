-- Lua provided by RyzenAPI
-- Game: Game: AppID 3097950

-- MAIN APPLICATION
addappid(3097950)
-- Game: addappid(3097950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097951, 1, "d4b836013762a7e7fb5c67eaf64ec9c12f0e99a0ecda75d1966707f3c1c74e88")
