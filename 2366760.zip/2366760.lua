-- Lua provided by RyzenAPI
-- Game: Hentai Kaiya

-- MAIN APPLICATION
addappid(2366760)
-- Game: addappid(2366760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366761, 1, "b82db6e869b1a9e42527d73fcdb3355d0c03f4948dacd7716ab4bd685e65525b")
