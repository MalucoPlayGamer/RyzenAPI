-- Lua provided by RyzenAPI
-- Game: Tropico 3: Absolute Power

-- MAIN APPLICATION
addappid(57600)

-- MAIN APP DEPOTS / PACKAGES
addappid(57601, 1, "f0ec1203cab4abb24d99678e19af81ccb0485e2abdad74cc356713e6447606c5")
addappid(57602, 1, "0a3cb43699d24f223d8e559c7e9294d2068c73d6f76431b982a66190a00f1406")
addappid(57603, 1, "c065d3908e5d0e16a5cfe5729e3ae9c5afc549bef021ecf685cf941ebb771b8c")
addappid(57604, 1, "1c423bc9afa636dc2066a360d32d790d6e9903185de12f046a928dc6f043c19b")
addappid(57605, 1, "d09edfc01da03603139e5f0b85786e0dbb407776ed215ac42d94a6b848f66290")
addappid(57606, 1, "edf9ac44fc02f99f4f71f4feaf411e12a3d56c9ef621ef7e105a7e7561c7d9ac")

