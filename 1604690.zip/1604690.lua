-- Lua provided by RyzenAPI
-- Game: Last Blossom

-- MAIN APPLICATION
addappid(1604690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1604691, 1, "d4b0ab7c1e7436812cac9a4302e805d1971dbcb2e152ad6f8c2d32720d8837a8")
addappid(1604692, 1, "5ff8be443ab8f801e3638512fdf64e78e6cbff4b6e0a945113fba6fd3945a11d")

