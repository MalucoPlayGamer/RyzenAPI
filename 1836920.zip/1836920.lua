-- Lua provided by RyzenAPI
-- Game: Hunt-or-Haunt

-- MAIN APPLICATION
addappid(1836920)
-- Game: addappid(1836920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836921, 1, "cfd0a7287a0cf986efc51b24ab5b2f639ee667b7fc3d27acdacee4fd30381e55")
