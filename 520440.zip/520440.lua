-- Lua provided by RyzenAPI
-- Game: GUILTY GEAR Xrd REV 2

-- MAIN APPLICATION
addappid(520440)
addappid(550330)
addappid(550331)
addappid(550332)
addappid(550333)
addappid(550334)
addappid(550335)
addappid(631550)
addappid(631551)
addappid(631552)
addappid(631553)
addappid(631554)
addappid(631560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(520441, 1, "af503156fe99dae6d61184f2f1bd545031ccb28303d951e22c2286fd3f83a983")
addappid(550910, 0, "c20d6035a78aea708d31c29a8bbdabacfc921baf7004778c70f7d9c5ca177bfc")

