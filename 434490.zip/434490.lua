-- Lua provided by RyzenAPI
-- Game: Otem's Defiance

-- MAIN APPLICATION
addappid(434490)
addappid(488620)

-- MAIN APP DEPOTS / PACKAGES
addappid(434491, 1, "c793a63fadf1a8fac7ffaf6255e08ac62332e800ee611ae30a29e1de8579b618")
