-- Lua provided by RyzenAPI
-- Game: Blackguards 2

-- MAIN APPLICATION
addappid(314830)

-- MAIN APP DEPOTS / PACKAGES
addappid(314831, 1, "5fd25594ec7f284fcd4687b1fe1389d6fd6340a94feb503fd4d0ba48363fc3d2")
addappid(314832, 1, "b83629bde034e70aa274f8409043134c1b801d9fa13b301f29e69b6bea560d75")
addappid(314834, 1, "f8f53767d5fe895060f6bd80eb40a7d14e422bbd7c8c05230c5c36aaabf3ab8f")
addappid(314835, 1, "9225c3cb71411a4b276bb362a50ac9e8ac4911c687c86220f5ef8871adb5a19a")
addappid(314836, 1, "524103217e68d0d6c0aa9cd61b7c3f6114a0a9e67ba62612900c0fb071fc4462")
addappid(314837, 1, "50c5b4cab76656987d4818fa54163315c01f76c2c947ef9640d378157a98c36f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
