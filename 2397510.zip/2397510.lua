-- Lua provided by RyzenAPI
-- Game: Corsairs - Battle of the Caribbean

-- MAIN APPLICATION
addappid(2397510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397511,0,"610d54defc3db1f1f518432efdf3164cf00abd1cd1690ed55541e90f4814b3b3")
addappid(4639560,0,"c553433ba70faf933f2a4f11fe6c255c3532cfa30cf7e0d399cbc1db43389b58")

