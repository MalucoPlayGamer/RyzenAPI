-- Lua provided by RyzenAPI
-- Game: Hentai Teachers

-- MAIN APPLICATION
addappid(2053320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053321, 1, "126dd0e0939cceb7f135fc8f91d48f7a5c7f8764053fd905531695c1c7fdb7cc")
