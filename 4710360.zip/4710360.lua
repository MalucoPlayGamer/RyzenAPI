-- Lua provided by RyzenAPI
-- Game: Divine Girls:Kalia Saga

-- MAIN APPLICATION
addappid(4710360)
