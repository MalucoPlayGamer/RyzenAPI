-- Lua provided by SkyAPI 
-- Game: AppID 1118920
addappid(1118920)
addappid(1118921, 1, "3b73fa8e49d4a3f0e75f8ded4e9f65da2705b0a3e708bab7e90c5decffb86a75")
