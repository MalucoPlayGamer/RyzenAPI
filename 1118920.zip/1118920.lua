-- Lua provided by RyzenAPI
-- Game: TrenchesWIP

-- MAIN APPLICATION
addappid(1118920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1118921, 1, "3b73fa8e49d4a3f0e75f8ded4e9f65da2705b0a3e708bab7e90c5decffb86a75")
