-- Lua provided by SkyAPI 
-- Game: AppID 851810
addappid(851810)
addappid(851811, 1, "ce522c45e4ef1e4a61f855ca90bdbf3963baee46443a33ddf4d4edfae2840556")
addappid(851812, 1, "bdfd9edd9422ffa7b64386dc53f5b3912d311d42190adf9dd1e838dad450001d")
