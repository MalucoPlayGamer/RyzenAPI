-- Lua provided by RyzenAPI
-- Game: Ultimate Sudoku Collection

-- MAIN APPLICATION
addappid(851810)
addappid(853370)
addappid(853870)
addappid(853871)
addappid(853872)
addappid(853873)
addappid(853874)
addappid(853875)
addappid(853876)
addappid(853877)
addappid(853881)
addappid(853882)
addappid(853883)
addappid(853884)
addappid(853885)
addappid(853886)
addappid(853887)
addappid(873540)
addappid(873541)
addappid(944890)
addappid(944891)
addappid(944892)
addappid(944893)
addappid(1336900)
addappid(1336901)
addappid(1485290)
addappid(1485291)
addappid(1485292)

-- MAIN APP DEPOTS / PACKAGES
addappid(851811, 1, "ce522c45e4ef1e4a61f855ca90bdbf3963baee46443a33ddf4d4edfae2840556")
addappid(851812, 1, "bdfd9edd9422ffa7b64386dc53f5b3912d311d42190adf9dd1e838dad450001d")

