-- Lua provided by RyzenAPI
-- Game: Vivid Knight

-- MAIN APPLICATION
addappid(1569090)
-- Game: addappid(1569090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569091, 1, "62a43c7e0fcd7f227f467dc4cd0fd28a72c512ddb977e006e36924f5e2e33776")
addappid(1569092, 1, "ba09776f46e9cc65263987a17addd54761def54655d794f6016272c8ad9778a7")
