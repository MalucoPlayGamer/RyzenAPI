-- Lua provided by RyzenAPI
-- Game: Colonials Programme

-- MAIN APPLICATION
addappid(1485630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485631, 1, "0d090a47cae622d1107f9815c74fe6b8a74e3cb7beda3b8084baa74e516ea7d4")
