-- Lua provided by RyzenAPI
-- Game: 435050

-- MAIN APPLICATION
addappid(435050)
-- Game: addappid(435050)

-- MAIN APP DEPOTS / PACKAGES
addappid(435051, 1, "cca22eee4345b0d92b3eb6df5a9d96e81930dba9eabd4f4ffe63ce641135a97e")
