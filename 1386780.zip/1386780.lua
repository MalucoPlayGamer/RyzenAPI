-- Lua provided by RyzenAPI
-- Game: City of Gangsters

-- MAIN APPLICATION
addappid(1386780)
addappid(1643230)
addappid(1643231)
addappid(1811230)
addappid(1869410)
addappid(1968890)
addappid(1968891)
addappid(1968892)
addappid(1968893)
addappid(1968894)
addappid(1968895)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386782,0,"cc85a8184e55e8644852fd1dbd9111a4e73de9f65b0d84eed7613556e303f37c")

