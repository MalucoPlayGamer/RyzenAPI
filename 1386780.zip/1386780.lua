-- Lua provided by RyzenAPI
-- Game: City of Gangsters

-- MAIN APPLICATION
addappid(1386780)
-- Game: addappid(1386780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386782,0,"cc85a8184e55e8644852fd1dbd9111a4e73de9f65b0d84eed7613556e303f37c")
