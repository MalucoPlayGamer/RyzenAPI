-- Lua provided by RyzenAPI
-- Game: Game: Dorfs: Hammers for Hire

-- MAIN APPLICATION
addappid(1707790)
-- Game: addappid(1707790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707791, 1, "742c601603ad7cb42ba81c01fb2cccd66c7117c0ae21a936e69a896e61c6a42a")
