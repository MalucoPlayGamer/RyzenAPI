-- Lua provided by RyzenAPI 
-- Game: Evil Tag
addappid(611350)
addappid(611351, 1, "6fa4b93548ea131caa1851eec47ba8e4893f69307cadc1b1f45ea4784e60ad9a")
