-- Lua provided by RyzenAPI
-- Game: Fobia - St. Dinfna Hotel

-- MAIN APPLICATION
addappid(1298140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1298141, 1, "8ed0c54ae9089ee945e1b0f545f589b5f7ea797bb013f86e011ba09d90ccf0c5")

