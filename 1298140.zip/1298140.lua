-- Lua provided by RyzenAPI
-- Game: Game: Fobia - St. Dinfna Hotel

-- MAIN APPLICATION
addappid(1298140)
-- Game: addappid(1298140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298141, 1, "8ed0c54ae9089ee945e1b0f545f589b5f7ea797bb013f86e011ba09d90ccf0c5")
