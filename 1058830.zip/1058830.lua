-- Lua provided by RyzenAPI
-- Game: Spin Rhythm XD

-- MAIN APPLICATION
addappid(1058830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058831,0,"3f26db997b2f0251aeb078e6ea68fba45a9b67c18863ff4c467f6f03aa0eeae4")
addappid(1058832,0,"de813043e58eacf88f155d5ea29ae67c2db721b05892742680892b29872caddb")
addappid(1058833,0,"0cfbdacb00c012f9bd209b7cfd60b9f97f9ccf8de14d8dfeac47198d63e8624f")
addappid(1664540,0,"1f2524ed33a3c11d30d6f2fff2588dd755f3580da01c0c112cdbb63faa8f6f05")
addappid(1668790,0,"1f931f673b51c59f94252105c8c93fabe144d8240f5377da2f268333bb27be5b")
addappid(1668791,0,"64a1081e7e6d408a166bf3cf058fd384486eef13abdcbbc477f3dec90267f5a2")
addappid(1677790,0,"5e19cee912dcb39cb56c05d06e8c35684e6f5d5ef3c9417cf165d77dcf7c20db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
