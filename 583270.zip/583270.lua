-- Lua provided by RyzenAPI 
-- Game: Cosmic Express
addappid(583270)
addappid(583271, 1, "3a222f85f5b0e34fbe0be891b9c6ae39ec2e2cdfec24fc1d4c9d21509998ec84")
addappid(583272, 1, "f06f5b3880bd2c900272934dc095c08553dcc75dd31fc42784c972b8aa93fbd4")
addappid(583273, 1, "855b82819bca2eceedb763351c6d18d2c0fd8704556ccf26cb678136f4c731de")
