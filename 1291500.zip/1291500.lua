-- Lua provided by RyzenAPI
-- Game: Game: Kill It With Fire: Ignition

-- MAIN APPLICATION
addappid(1291500)
-- Game: addappid(1291500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291501, 1, "a3180f7777ff39be856ad266c1568cc08a63c85347bf17410dff5c9164b0f9ed")
