-- Lua provided by RyzenAPI
-- Game: Kill It With Fire: Ignition

-- MAIN APPLICATION
addappid(1291500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291501, 1, "a3180f7777ff39be856ad266c1568cc08a63c85347bf17410dff5c9164b0f9ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
