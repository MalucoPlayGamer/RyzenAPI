-- Lua provided by RyzenAPI
-- Game: Night Raider

-- MAIN APPLICATION
addappid(2719290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719291, 1, "3a2948db3b7201c3bdd69857dec4c6c844c1505dc1d3ff59cd05e2cdebb3f832")

