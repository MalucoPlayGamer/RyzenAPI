-- Lua provided by RyzenAPI
-- Game: Charlie Charlie Challenge

-- MAIN APPLICATION
addappid(2793250)
-- Game: addappid(2793250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793251, 1, "d952dd6983b5b0b4816d69f252ce5106d9e27d80a393f5016f6b67ff6442d880")
