-- Lua provided by RyzenAPI
-- Game: Make Your Kingdom: Prologue

-- MAIN APPLICATION
addappid(1257560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257561, 1, "ad0670366bc4753137a4eaa455df08688bff9257d843cb611d525c64f2936364")
