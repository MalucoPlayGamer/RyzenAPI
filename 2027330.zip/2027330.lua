-- Lua provided by RyzenAPI
-- Game: 2027330

-- MAIN APPLICATION
addappid(2027330)
-- Game: addappid(2027330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027331, 1, "fe55366b35c183a95c0ec8968cfc7df1e903ba74e41b8c298201fda9946a0b7d")
