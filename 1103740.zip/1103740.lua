-- Lua provided by RyzenAPI
-- Game: 1103740

-- MAIN APPLICATION
addappid(1103740)
-- Game: addappid(1103740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103740,0,"807fbb14e8abafc8d083d29b87e166958b4136a6f5b33b1f0c9d8cd2ef05b22d")
