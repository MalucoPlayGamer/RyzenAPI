-- Lua provided by RyzenAPI
-- Game: FALLSTRUKTUR

-- MAIN APPLICATION
addappid(3674270)
