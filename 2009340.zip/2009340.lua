-- Lua provided by RyzenAPI
-- Game: Defend The Bits TD

-- MAIN APPLICATION
addappid(2009340)
-- Game: addappid(2009340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009341, 1, "edbcc8a93270520be297e8d087eb0951c0e5cd79b02b96fc210eb36af7e6f158")
