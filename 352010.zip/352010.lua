-- Lua provided by RyzenAPI
-- Game: Beach Bounce

-- MAIN APPLICATION
addappid(352010)

-- MAIN APP DEPOTS / PACKAGES
addappid(352011, 1, "6aca3e55b1b76b01ff05f4d5249a1065156bf8d22b5f6db152ede9383732d1fe")
addappid(394050, 0, "36089cc72378c875ab0339b7fa7bb1d993f97bd3b2c0cfd0ba6e9c391d9eac03")
