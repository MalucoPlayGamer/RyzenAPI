-- Lua provided by RyzenAPI
-- Game: 三国英雄传豪华版

-- MAIN APPLICATION
addappid(1956710)
addappid(2252320)
addappid(2252321)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956711, 1, "b7bdb739927b534ba5c5aa567927c33c28b42135896323f9829900404d1d9589")
