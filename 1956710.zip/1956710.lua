-- Lua provided by RyzenAPI
-- Game: Game: AppID 1956710

-- MAIN APPLICATION
addappid(1956710)
addappid(2252320)
addappid(2252321)
-- Game: addappid(1956710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956711, 1, "b7bdb739927b534ba5c5aa567927c33c28b42135896323f9829900404d1d9589")
