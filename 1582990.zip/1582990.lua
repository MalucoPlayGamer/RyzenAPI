-- Lua provided by RyzenAPI
-- Game: Game: AppID 1582990

-- MAIN APPLICATION
addappid(1582990)
-- Game: addappid(1582990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582991, 1, "33ef75b5bb050a6535ad3fbc3b8330010cec2d77fb00f402401af073f7e0ff77")
