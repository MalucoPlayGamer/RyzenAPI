-- Lua provided by RyzenAPI
-- Game: Underwater Duo

-- MAIN APPLICATION
addappid(3736310) -- Underwater Duo

-- MAIN APP DEPOTS / PACKAGES
addappid(3736311, 1, "6934fd8808081fa361bcc86360a1d2b4cd7b9241efc51efb0f7381023a47a826") -- Depot 3736311

