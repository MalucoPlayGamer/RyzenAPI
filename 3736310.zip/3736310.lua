-- 3736310's Lua and Manifest Created by Hubcap Manifest
-- Underwater Duo
-- Created: August 12, 2026 at 09:13:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3736310) -- Underwater Duo
-- MAIN APP DEPOTS
addappid(3736311, 1, "6934fd8808081fa361bcc86360a1d2b4cd7b9241efc51efb0f7381023a47a826") -- Depot 3736311
setManifestid(3736311, "7355583939494379987", 393961572)