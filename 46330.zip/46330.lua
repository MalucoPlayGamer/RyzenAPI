-- Lua provided by RyzenAPI
-- Game: Game: AppID 46330

-- MAIN APPLICATION
addappid(46330)
-- Game: addappid(46330)

-- MAIN APP DEPOTS / PACKAGES
addappid(46331, 1, "cabd4cd4506577df8a2af5b8b7734c8daade980a0b6ab0dff4265fbdb9111a9d")
addappid(46332, 1, "1cc52d8a0d4d44b54318666990f0479b7df8a5a118e633955cf63259cde6c84f")
