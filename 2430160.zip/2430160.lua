-- Lua provided by RyzenAPI
-- Game: Taimanin Asagi

-- MAIN APPLICATION
addappid(2430160)
-- Game: addappid(2430160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430161, 1, "291f1b09c9e351257963e42a88f4f980528bee404fc171c81828d66e6d40bf83")
