-- Lua provided by RyzenAPI
-- Game: Deceit 2 Playtest

-- MAIN APPLICATION
addappid(2460380)
-- Game: addappid(2460380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460381, 1, "2936865e448282150ac95d857e04c2b74f22099160d880decf0f896011f1125c")
