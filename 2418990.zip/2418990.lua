-- Lua provided by RyzenAPI
-- Game: Game: Fight for Eden: HEAT

-- MAIN APPLICATION
addappid(2418990)
-- Game: addappid(2418990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418991, 1, "d005f299f5ef078f3e994af52286a263bc5f6ea93350937e77b88d033e8b0581")
