-- Lua provided by RyzenAPI
-- Game: English Country Tune

-- MAIN APPLICATION
addappid(207570)

-- MAIN APP DEPOTS / PACKAGES
addappid(207571, 1, "cc8f6871f6bba2a47a4b0987950189cdf0c17ce2a0f60b3b89d0498fbb505415")
addappid(207572, 1, "b26d599055ca94581fa51a60405fbff6304080e9e55c346a23f18294e1b8cc5d")
addappid(207573, 1, "b984a92771c19d58258e1e0a293314359df4895bca57dc7ef047dca32bdde447")

