-- Lua provided by RyzenAPI
-- Game: 2458350

-- MAIN APPLICATION
addappid(2458350)
-- Game: addappid(2458350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458351, 1, "59f95b73b2b621d7df07b1c07d1ffbab8590345d946936847a3568e34f1e62ca")
