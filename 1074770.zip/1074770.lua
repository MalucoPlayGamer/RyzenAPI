-- Lua provided by RyzenAPI
-- Game: The Rescue of Mermaids

-- MAIN APPLICATION
addappid(1074770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074771, 1, "f8d07052e6af4432215ae26cf1ee0379f65d611409d2664c06449f48382b81c3")

