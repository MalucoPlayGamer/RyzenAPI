-- Lua provided by RyzenAPI
-- Game: Dwarves: Glory, Death and Loot Soundtrack

-- MAIN APPLICATION
addappid(2542510)
-- Game: addappid(2542510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542511, 1, "a883875d6e274d7628d937fe9042d270ad38915d40140f36c9cbe2273bc5b718")
