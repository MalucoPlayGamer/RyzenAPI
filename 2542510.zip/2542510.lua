-- Lua provided by SkyAPI 
-- Game: Dwarves: Glory, Death and Loot Soundtrack
addappid(2542510)
addappid(2542511, 1, "a883875d6e274d7628d937fe9042d270ad38915d40140f36c9cbe2273bc5b718")
