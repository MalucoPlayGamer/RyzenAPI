-- Lua provided by RyzenAPI
-- Game: 1996600

-- MAIN APPLICATION
addappid(1996600)
-- Game: addappid(1996600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996601, 1, "13f1b08e53c7359e3cbf2ea32a3c38a087d7c5ef32c83d873869beff43113b9b")
