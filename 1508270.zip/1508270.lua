-- Lua provided by RyzenAPI
-- Game: Doctor Who: The Lonely Assassins

-- MAIN APPLICATION
addappid(1508270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508271, 1, "9f2607ea636490985470e4a41ec10aa9f3d0b4b7b075b4ab6ac8b4f550dcc65e")

