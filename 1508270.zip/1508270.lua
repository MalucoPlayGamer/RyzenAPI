-- Lua provided by SkyAPI 
-- Game: Doctor Who: The Lonely Assassins
addappid(1508270)
addappid(1508271, 1, "9f2607ea636490985470e4a41ec10aa9f3d0b4b7b075b4ab6ac8b4f550dcc65e")
