-- Lua provided by RyzenAPI
-- Game: Evil V Evil

-- MAIN APPLICATION
addappid(809090)
addappid(2329970)
addappid(2438640)
addappid(2438650)
addappid(2438690)
addappid(2438700)

-- MAIN APP DEPOTS / PACKAGES
addappid(809091,0,"6dc83285372dcf6d745fc04869e57178509236ffe967b5b78834857345fdc45b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
