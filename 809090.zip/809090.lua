-- Lua provided by RyzenAPI
-- Game: Game: EvilVEvil

-- MAIN APPLICATION
addappid(809090)
-- Game: addappid(809090)

-- MAIN APP DEPOTS / PACKAGES
addappid(809091, 1, "6dc83285372dcf6d745fc04869e57178509236ffe967b5b78834857345fdc45b")
