-- Lua provided by RyzenAPI
-- Game: Evil V Evil

-- MAIN APPLICATION
addappid(809090)
addappid(2329970)
addappid(2438640)
addappid(2438650)
addappid(2438690)
addappid(2438700)

-- MAIN APP DEPOTS / PACKAGES
addappid(809091,0,"6dc83285372dcf6d745fc04869e57178509236ffe967b5b78834857345fdc45b")

