-- Lua provided by RyzenAPI
-- Game: Portal war

-- MAIN APPLICATION
addappid(2169040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169041, 1, "b132e3e645b34b73d2f8a47cd689af36e07cdf3416f1996116829a8496296511")

