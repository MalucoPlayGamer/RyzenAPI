-- Lua provided by RyzenAPI
-- Game: Skolly's Adventure Demo

-- MAIN APPLICATION
addappid(2798110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2798111, 1, "3c865e9a10e3b9e25a540428eec62a6bf32b66afb4d71e687558a84caebc87b4")

