-- Lua provided by RyzenAPI
-- Game: Game: Counter Fight

-- MAIN APPLICATION
addappid(551690)
-- Game: addappid(551690)

-- MAIN APP DEPOTS / PACKAGES
addappid(551691, 1, "70e450c93e091d642bd7951a86d728bf521a0c9a948fbbad75b67efb5249faf7")
