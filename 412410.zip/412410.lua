-- Lua provided by RyzenAPI
-- Game: Castle Chaos

-- MAIN APPLICATION
addappid(412410)

-- MAIN APP DEPOTS / PACKAGES
addappid(412412,0,"43cc10db150439fff34496c01f9167d5463bc8ed1855fee3997182e5b9fce517")
addappid(412413,0,"670214efd1c84c99576ae2b15a1aaf67fae28ffa124ac959407bfd03851a8af6")
addappid(412414,0,"6a1eca787e27f1465db346886a10879d84efdbbfdc5ddc8ddf09d59a072d721b")

