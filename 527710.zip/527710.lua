-- Lua provided by SkyAPI 
-- Game: Crown Champion: Legends of the Arena
addappid(527710)
addappid(527711, 1, "e3b02a4343f9982777b10c7a4ea1d251152f82150afbf69e5e8fd71454c2ba4e")
