-- Lua provided by RyzenAPI
-- Game: Game: Omega Reaction

-- MAIN APPLICATION
addappid(516520)
-- Game: addappid(516520)

-- MAIN APP DEPOTS / PACKAGES
addappid(516521, 1, "4fc373470ae0d1696257b0e578fc0144fd65e6220c3eeda0bfa4ea194a84a29f")
addappid(516522, 1, "8ec490bb7c10ae63d1e927457fef2f9a763a93107a4880323649cd3cf572684c")
addappid(516523, 1, "dedf1c1efc1f1c3ca4136b8618391111afbf9e0091c6b6b29ae94e21d9e99d1f")
