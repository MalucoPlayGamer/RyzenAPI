-- Lua provided by RyzenAPI
-- Game: 278810

-- MAIN APPLICATION
addappid(278810)
addappid(318490)
-- Game: addappid(278810)

-- MAIN APP DEPOTS / PACKAGES
addappid(278811, 1, "7fd1693aa7a4feeec79c19fd1b992055d53c1761d0f73faf669c251db44c1708")
