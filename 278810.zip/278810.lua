-- Lua provided by RyzenAPI 
-- Game: LA Cops
addappid(278810)
addappid(278811, 1, "7fd1693aa7a4feeec79c19fd1b992055d53c1761d0f73faf669c251db44c1708")
addappid(318490)
