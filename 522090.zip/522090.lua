-- Lua provided by RyzenAPI
-- Game: Medieval Defenders

-- MAIN APPLICATION
addappid(522090)
addappid(552020)

-- MAIN APP DEPOTS / PACKAGES
addappid(522091, 1, "df32514367c8f5ae1784a6101e71d750cf273fdcaf50f69c3c4f3ca51c11f757")
