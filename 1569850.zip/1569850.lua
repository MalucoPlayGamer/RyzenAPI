-- Lua provided by SkyAPI 
-- Game: BLACK WITCHCRAFT : Original Soundtrack
addappid(1569850)
addappid(1569851, 1, "945d45c8a3a462e515fe7f83a8ce90165beb6c53261b25dd5448afa195a371e0")
