-- Lua provided by RyzenAPI
-- Game: addappid(2235620)

-- MAIN APPLICATION
addappid(2235620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235621, 1, "ad4e30427659cd42e6e8bc29a916c0e1326af77bdcbfcd1c3685fb10c6c90209")
