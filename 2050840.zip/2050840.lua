-- Lua provided by RyzenAPI
-- Game: - Am I kind-hearted? - ワタシのココロは綺麗ですか？

-- MAIN APPLICATION
addappid(2050840)
-- Game: addappid(2050840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050841, 1, "6d0c0454442651e7060c9b22e5fb39ca268ecd0065614e6dfc570fa0f54daf03")
