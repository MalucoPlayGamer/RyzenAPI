-- Lua provided by SkyAPI 
-- Game: Serious Sam's Bogus Detour
addappid(272620)
addappid(272621, 1, "128097d333fd531cc87f31800933d9763aaa02ebf8ea510af00c4c02e8ee4f92")
addappid(272622, 1, "71419954920964d4482a28044e8f4000db2aba271b76d46c0b2ddd199971cdf3")
addappid(272623, 1, "7ca37ed9ea6bceaa2ddc729f41a950742fecdc4e4c8a5be64adb9e4357681d8c")
addappid(272624, 1, "ffa0058a49c1c2d2b34ce4c6a6f83cc43983c99b6408304b9002a1468ca5962c")
