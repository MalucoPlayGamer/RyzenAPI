-- Lua provided by RyzenAPI
-- Game: AppID 24710

-- MAIN APPLICATION
addappid(24710)

-- MAIN APP DEPOTS / PACKAGES
addappid(24711, 1, "3a2ed483c2f6cbbf7ab46ef591b8e0d7eedcb495f4be628630874afc07e7fc27")

