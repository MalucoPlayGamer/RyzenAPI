-- Lua provided by RyzenAPI 
-- Game: Breach & Clear
addappid(266130)
addappid(266131, 1, "baf015c74e71246b5e9a818b5ee1244dbb455a7c45dc814de4ad89017a0a3f49")
addappid(266132, 1, "c9ae9a5875cfff7805fb95edaea39466221b197c973f3b6ff347ce07d65c096b")
addappid(266133, 1, "6122939498f6b9676a9bf7db87cf106547d0b137c70a2eab621990dd5d312429")
addappid(296990)
