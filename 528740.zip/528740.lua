-- Lua provided by RyzenAPI
-- Game: Operation: New Earth

-- MAIN APPLICATION
addappid(528740)

