-- Lua provided by RyzenAPI
-- Game: Operation: New Earth

-- MAIN APPLICATION
addappid(528740)
addappid(562630)
addappid(595350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

