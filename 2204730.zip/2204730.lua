-- Lua provided by RyzenAPI
-- Game: Once upon a Dungeon II

-- MAIN APPLICATION
addappid(2204730)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2204731, 1, "3b285592f402731907ee92b2f9c01f5b53ee2fc0dc247fda8cbe6c7f30601300")

