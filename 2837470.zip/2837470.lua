-- Lua provided by RyzenAPI
-- Game: Asterball

-- MAIN APPLICATION
addappid(2837470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2837471, 1, "759cfc21b93b24374dc9ef8bbf37e9bfe53ee7ba9afbcc79ed6e5523ae3f2332")

