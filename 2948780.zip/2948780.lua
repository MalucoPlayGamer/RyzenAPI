-- Lua provided by RyzenAPI 
-- Game: AppID 2948780
addappid(2948780)
addappid(2948781, 1, "2208b1a16c8739302eb532445a6c9812a19f995db628e275cbe18936c70f8586")
