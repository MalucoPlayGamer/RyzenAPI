-- Lua provided by RyzenAPI
-- Game: Rebellion: Rise of the Damned Demo

-- MAIN APPLICATION
addappid(2948780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948781, 1, "2208b1a16c8739302eb532445a6c9812a19f995db628e275cbe18936c70f8586")
