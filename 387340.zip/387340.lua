-- Lua provided by SkyAPI 
-- Game: Hyperdimension Neptunia U: Action Unleashed
addappid(387340)
addappid(387341, 1, "b9339c2eccae61dc980bf894f2aa6040b20f30acd640e2c488520a367a081ae8")
addappid(417850, 0, "f820889941e5e2a11990025b7e46f4b1db0696ec8e4153b55ad81391da9345c5")
addappid(417851, 0, "1b278e15411c4b39aaa7480e5b0b37c49c4bc865e0323fca229e5adafce03520")
