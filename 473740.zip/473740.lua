-- Lua provided by RyzenAPI
-- Game: 473740

-- MAIN APPLICATION
addappid(473740)
addappid(685470)
-- Game: addappid(473740)

-- MAIN APP DEPOTS / PACKAGES
addappid(473741, 1, "542631dee14d94d6a0cc4cbbc7d5b6df2be7c458ab11c40e7436d5f492eab6b5")
