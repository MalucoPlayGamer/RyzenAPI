-- Lua provided by RyzenAPI
-- Game: addappid(2597420)

-- MAIN APPLICATION
addappid(2597420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597421, 1, "e5c3218986aa868a1a8980e848467a9917a9c8e10deea9e0ebf66c1388a6309e")
