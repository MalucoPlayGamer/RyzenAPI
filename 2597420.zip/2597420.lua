-- Lua provided by RyzenAPI
-- Game: 悠闲打砖块(Leisurely Brick)

-- MAIN APPLICATION
addappid(2597420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597421, 1, "e5c3218986aa868a1a8980e848467a9917a9c8e10deea9e0ebf66c1388a6309e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
