-- Lua provided by RyzenAPI
-- Game: ™انتم السابقون

-- MAIN APPLICATION
addappid(3666640)
-- Game: addappid(3666640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3666641, 1, "69d1b349084afa00fdcbb6308a914d3fd15d58f72ebee39c47144e032e923a69")
