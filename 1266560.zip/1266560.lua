-- Lua provided by RyzenAPI
-- Game: 鋼鉄戦記C21

-- MAIN APPLICATION
addappid(1484360) -- C21 Starters Pack
addappid(1954350) -- C21 Weapon Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1266560, 1, "c4b206569cd165c816e6ba650b58087027553afde47184de39bb090ae29beb26") -- 鋼鉄戦記C21
addappid(1266561, 1, "684fb93901dce2a8958e6d0ee76b74a5b9144a03d080d11795ff1502cd869e70") -- 鋼鉄戦記C21 Content
addappid(1266562, 1, "e3ed6f0fb34e62d972b18abb7b05bc56887c05cfd696a1a71eb145b1e5cd4fa3") -- 鋼鉄戦記C21 windows
addappid(1266563, 1, "821a621bdd8779f00fc915b13945bbc9136a543ebc9065df2d55351de4e29faf") -- 鋼鉄戦記C21 mac

