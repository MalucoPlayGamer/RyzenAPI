-- Lua provided by RyzenAPI
-- Game: Game: AppID 1266560

-- MAIN APPLICATION
addappid(1266560)
-- Game: addappid(1266560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266561, 1, "684fb93901dce2a8958e6d0ee76b74a5b9144a03d080d11795ff1502cd869e70")
addappid(1266562, 1, "e3ed6f0fb34e62d972b18abb7b05bc56887c05cfd696a1a71eb145b1e5cd4fa3")
addappid(1266563, 1, "821a621bdd8779f00fc915b13945bbc9136a543ebc9065df2d55351de4e29faf")
