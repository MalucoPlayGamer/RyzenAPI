-- Lua provided by RyzenAPI
-- Game: 1644615

-- MAIN APPLICATION
addappid(1644615)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644615,0,"f8e5e4c71325c0de7d63240c9f4ba30e2bd30b640acf9f57c5d4efbd7e4e345c")

