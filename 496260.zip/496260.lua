-- Lua provided by RyzenAPI
-- Game: Corona Blossom Vol.1 Gift From the Galaxy

-- MAIN APPLICATION
addappid(496260)
-- Game: addappid(496260)

-- MAIN APP DEPOTS / PACKAGES
addappid(496261, 1, "d0881da669d64361a3d5497063974b5644a709d62bcb80853d5146b7fb0ff010")
addappid(496262, 1, "df875e9d5ee0402091750402b53c043f8edb7efbb3f02e941964bbe5130d2c60")
