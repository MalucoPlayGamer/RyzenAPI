-- Lua provided by RyzenAPI
-- Game: The Scourge | Tai Ương Demo

-- MAIN APPLICATION
addappid(2570730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570731, 1, "4aca3af438721f9601dd69f1a8a02aa96bc67977a7cf7576b24bc6576cca3acd")
