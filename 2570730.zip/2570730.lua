-- Lua provided by SkyAPI 
-- Game: The Scourge | Tai Ương Demo
addappid(2570730)
addappid(2570731, 1, "4aca3af438721f9601dd69f1a8a02aa96bc67977a7cf7576b24bc6576cca3acd")
