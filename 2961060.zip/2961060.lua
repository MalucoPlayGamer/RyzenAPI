-- Lua provided by RyzenAPI
-- Game: Brutal Bible Bloodbaths

-- MAIN APPLICATION
addappid(2961060)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3081010)
addappid(5016600)
