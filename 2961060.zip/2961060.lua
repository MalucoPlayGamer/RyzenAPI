-- Lua provided by RyzenAPI
-- Game: Brutal Bible Bloodbaths

-- MAIN APPLICATION
addappid(2961060)
