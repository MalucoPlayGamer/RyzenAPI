-- Lua provided by SkyAPI 
-- Game: 琉隐 Soundtrack
addappid(1784670)
addappid(1784671, 1, "3bb2725462a81b04d85850f46450116ca5dfc28688d961b07bf646e758abed3f")
