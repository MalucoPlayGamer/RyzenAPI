-- Lua provided by RyzenAPI
-- Game: 琉隐 Soundtrack

-- MAIN APPLICATION
addappid(1784670)
-- Game: addappid(1784670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784671, 1, "3bb2725462a81b04d85850f46450116ca5dfc28688d961b07bf646e758abed3f")
