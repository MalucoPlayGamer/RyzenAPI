-- Lua provided by RyzenAPI
-- Game: addappid(3333890)

-- MAIN APPLICATION
addappid(3333890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333891, 1, "b5e52dd81308451318ddf6c896cb1fed3ac016742cd36cd0d123855bf55206a6")
