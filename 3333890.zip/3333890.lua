-- Lua provided by RyzenAPI
-- Game: Panelak

-- MAIN APPLICATION
addappid(3333890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333891, 1, "b5e52dd81308451318ddf6c896cb1fed3ac016742cd36cd0d123855bf55206a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
