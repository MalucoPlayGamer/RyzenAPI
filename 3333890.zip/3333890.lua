-- Lua provided by SkyAPI 
-- Game: Panelak
addappid(3333890)
addappid(3333891, 1, "b5e52dd81308451318ddf6c896cb1fed3ac016742cd36cd0d123855bf55206a6")
