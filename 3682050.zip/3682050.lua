-- Lua provided by RyzenAPI
-- Game: Sickly Days and Summer Traces

-- MAIN APPLICATION
addappid(3682050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3682051, 1, "09652578b46fb04323a0df42c60d7d41225df719e923c430f528530ae6605d61")

