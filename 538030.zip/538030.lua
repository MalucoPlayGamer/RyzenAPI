-- Lua provided by RyzenAPI
-- Game: Xenonauts 2

-- MAIN APPLICATION
addappid(538030)

-- MAIN APP DEPOTS / PACKAGES
addappid(538031, 1, "abd9295b438de55315009b4ca303c5f54b32b21d98b8cb090ff2434392e583b9")

