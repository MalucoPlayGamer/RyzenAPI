-- Lua provided by RyzenAPI
-- Game: 300340

-- MAIN APPLICATION
addappid(300340)
addappid(386000)
-- Game: addappid(300340)

-- MAIN APP DEPOTS / PACKAGES
addappid(300341, 1, "edd3e04c29fbda95fc23f8857868f533bda7f475a5d3b4dafaca591ecd451720")
