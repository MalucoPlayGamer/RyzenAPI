-- Lua provided by RyzenAPI
-- Game: Hunting Unlimited 4

-- MAIN APPLICATION
addappid(545920)

-- MAIN APP DEPOTS / PACKAGES
addappid(545921, 1, "a99252e47be2f310c1792af672fa752ea9e7c3d659f1ee9652ddc3b5d2dd5054")

