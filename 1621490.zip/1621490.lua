-- Lua provided by SkyAPI 
-- Game: MagicShop3D
addappid(1621490)
addappid(1621491, 1, "d3396f7d61b2885891b1a976c2224424d8fb5771b5a5601e1a1a252e478231d9")
