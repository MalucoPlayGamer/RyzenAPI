-- Lua provided by RyzenAPI
-- Game: P1441vr

-- MAIN APPLICATION
addappid(1686790)
-- Game: addappid(1686790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686791, 1, "2e8f7105301ac1e94e655dae22bb2f8b1926ffeddb49699568f775b8ebadee0e")
