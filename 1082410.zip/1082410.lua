-- Lua provided by RyzenAPI
-- Game: Lost in Tropics

-- MAIN APPLICATION
addappid(1082410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082412,0,"7416f1cf0a0e6c3117bb93df7ff5ac0dcb56db0725b7730ae0e253248095e46e")

