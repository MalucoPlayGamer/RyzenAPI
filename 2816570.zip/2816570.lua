-- Lua provided by RyzenAPI
-- Game: The Land of the Magnates

-- MAIN APPLICATION
addappid(2816570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2816571, 1, "6700721a66f7cd5527b58b6f27b65cf3041c6e3d898474686f0e7b51dc093df4")

