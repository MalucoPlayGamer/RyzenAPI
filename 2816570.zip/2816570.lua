-- Lua provided by RyzenAPI 
-- Game: The Land of the Magnates
addappid(2816570)
addappid(2816571, 1, "6700721a66f7cd5527b58b6f27b65cf3041c6e3d898474686f0e7b51dc093df4")
