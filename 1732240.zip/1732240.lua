-- Lua provided by RyzenAPI
-- Game: Virtual Journey Into the Metaverse

-- MAIN APPLICATION
addappid(1732240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732241, 1, "ff454702f50f13a7fc48431e0234504c0525e62cd88f308f859b58ee56207c56")
