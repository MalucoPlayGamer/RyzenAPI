-- Lua provided by RyzenAPI
-- Game: addappid(2112580)

-- MAIN APPLICATION
addappid(2112580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112581, 1, "2614dd1ec62e9bb314ad289a2034f44aff01301af9182ebeacf86e8cd5228dcb")
