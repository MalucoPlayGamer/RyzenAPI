-- Lua provided by RyzenAPI
-- Game: Mercenary Squad Auto Chess

-- MAIN APPLICATION
addappid(2797080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797081, 1, "014c8226b8d68810f0d3ec6d98caeae7f9bad9f27b910626d4ccb4aa5432bcb6")

