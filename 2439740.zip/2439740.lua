-- Lua provided by RyzenAPI
-- Game: Game: Wolf West

-- MAIN APPLICATION
addappid(2439740)
-- Game: addappid(2439740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439741, 1, "3914f8cffa8130a43a7d3b688ee453add62595583c5c5b21e19ded3465fbbfae")
