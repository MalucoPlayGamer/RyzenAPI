-- Lua provided by RyzenAPI 
-- Game: Cyber Seraph Soundtrack
addappid(1318160)
addappid(1318161, 1, "c5c89465531b81dff3fe872e0509a31d155fb5dcd1004bce6dd4b960e6b521a6")
