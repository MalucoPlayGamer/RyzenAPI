-- Lua provided by RyzenAPI
-- Game: addappid(1082190)

-- MAIN APPLICATION
addappid(1082190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082191, 1, "f047c3fc7f03134e92c70ff66d5f5a746d18bebde3fdd81af70f43a072cc2dfb")
