-- Lua provided by RyzenAPI
-- Game: Cuckold Sex - Episode 1

-- MAIN APPLICATION
addappid(2948040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948041, 1, "072902b43a425cde8f1ec8aa224e47dfca9676213c16290dee1e4d3f925a0d2c")

