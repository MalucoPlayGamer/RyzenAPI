-- Lua provided by RyzenAPI
-- Game: Mekabolt

-- MAIN APPLICATION
addappid(1096210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1096211, 1, "ca8ebcfc55393b654b2cab03151924b504dcfe6170b1a99e8db5f345eb33fd68")

