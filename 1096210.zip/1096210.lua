-- Lua provided by RyzenAPI
-- Game: Game: Mekabolt

-- MAIN APPLICATION
addappid(1096210)
-- Game: addappid(1096210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096211, 1, "ca8ebcfc55393b654b2cab03151924b504dcfe6170b1a99e8db5f345eb33fd68")
