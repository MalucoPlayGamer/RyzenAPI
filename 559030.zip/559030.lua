-- Lua provided by RyzenAPI
-- Game: Siege Saga

-- MAIN APPLICATION
addappid(559030)

-- MAIN APP DEPOTS / PACKAGES
addappid(559031,0,"e9dfe40fc42269b9ccba66ca13a03cb1d606771dadc4f7c43696a5d87956c625")

