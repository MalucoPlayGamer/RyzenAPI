-- Lua provided by RyzenAPI
-- Game: Pool Cleaning Simulator

-- MAIN APPLICATION
addappid(2165620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165621, 1, "ad8dde03388a6fbaa173e97616fe19a9ca497d6552276fa6a6f2bf4083ce99bf")
