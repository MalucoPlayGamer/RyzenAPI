-- Lua provided by RyzenAPI 
-- Game: AppID 3266990
addappid(3266990)
addappid(3266991, 1, "7be2a3719e1a37e0817c690c43240850fb6dd07b199c64d977f5b983cd1313a7")
