-- Lua provided by RyzenAPI
-- Game: 1403650

-- MAIN APPLICATION
addappid(1403650)
-- Game: addappid(1403650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403651, 1, "05a2c84ec7278d6ab3d89d68bd1078d2def724ffd621fe4e9143d9cec8329bd3")
