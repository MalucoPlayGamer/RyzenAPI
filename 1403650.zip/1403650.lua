-- Lua provided by RyzenAPI
-- Game: Everdream Valley

-- MAIN APPLICATION
addappid(1403650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403651, 1, "05a2c84ec7278d6ab3d89d68bd1078d2def724ffd621fe4e9143d9cec8329bd3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2392630)
addappid(2431000)
addappid(2488400)
addappid(3281060)
