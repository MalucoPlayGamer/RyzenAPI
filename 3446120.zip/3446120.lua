-- Lua provided by RyzenAPI
-- Game: Game: Kira☆Kano

-- MAIN APPLICATION
addappid(3446120)
-- Game: addappid(3446120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446121, 1, "aadb32c08fa1e2753ecc0a2f349070af853935b7687a435b3cede167d84ee267")
