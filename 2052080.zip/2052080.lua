-- Lua provided by RyzenAPI
-- Game: Melia's Witch Test

-- MAIN APPLICATION
addappid(2052080)
addappid(2323480)
-- Game: addappid(2052080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052081, 1, "0db28835c9d7ef25ab81b0c0529ed814fa3d5b2ff491443a21489cdf3748716b")
