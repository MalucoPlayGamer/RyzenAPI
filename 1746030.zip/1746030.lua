-- Lua provided by RyzenAPI
-- Game: addappid(1746030)

-- MAIN APPLICATION
addappid(1746030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746031, 1, "d2e49cb79445331fa5ecbcd064628f63bb7564a3ee8ca7aaefbcf8034f5722ea")
addappid(1746032, 1, "14857b18effdcdcff1ba5225c733118fe29fcf35c5d6d931edd7da5b1f47f7bd")
