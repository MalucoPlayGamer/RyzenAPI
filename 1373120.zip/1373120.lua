-- Lua provided by RyzenAPI
-- Game: Air Wars

-- MAIN APPLICATION
addappid(1373120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373121, 1, "dbfb35357bb54dabc3c42502a86f5d17947bebb85fd3e659a59b020dd326fed4")

