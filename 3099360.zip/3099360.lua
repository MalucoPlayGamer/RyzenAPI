-- Lua provided by RyzenAPI
-- Game: Fishing Tale

-- MAIN APPLICATION
addappid(3099360) -- Fishing Tale

-- MAIN APP DEPOTS / PACKAGES
addappid(3099361, 1, "6072f8f04f4acbc245066bcb3bdbfcb58f9fbae5cf4c0ccac526adb33b4c9fce") -- Depot 3099361
