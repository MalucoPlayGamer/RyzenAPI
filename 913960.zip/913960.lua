-- Lua provided by RyzenAPI
-- Game: 913960

-- MAIN APPLICATION
addappid(913960)
-- Game: addappid(913960)

-- MAIN APP DEPOTS / PACKAGES
addappid(913961, 1, "4c1e397d9096c9fa045cea0f3c192f18ff4a32c5a33c64cadbe2914db3d06668")
