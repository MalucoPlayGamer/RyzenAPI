-- Lua provided by RyzenAPI
-- Game: Game: Everhood Soundtrack

-- MAIN APPLICATION
addappid(1546510)
-- Game: addappid(1546510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546511, 1, "d73a7b152459a1c32394e5b070866e5c7c94be06fd01f21844e00d72069f551a")
