-- Lua provided by RyzenAPI
-- Game: Game: ASKE Demo

-- MAIN APPLICATION
addappid(1672940)
-- Game: addappid(1672940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672941, 1, "775ca2e4118bbd6b6ee802d4d05155ba9fc3e50cd77128d5856e2ee12879fd5b")
