-- Lua provided by RyzenAPI
-- Game: Mists of Aiden

-- MAIN APPLICATION
addappid(1239050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1239051, 1, "29d8e198d02f9e089614fe953754258f9fefa5e5077ece2794ae89b19cd41f51")

