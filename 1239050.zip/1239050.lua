-- Lua provided by RyzenAPI
-- Game: Game: Mists of Aiden

-- MAIN APPLICATION
addappid(1239050)
-- Game: addappid(1239050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239051, 1, "29d8e198d02f9e089614fe953754258f9fefa5e5077ece2794ae89b19cd41f51")
