-- Lua provided by SkyAPI 
-- Game: Lunar Mirror
addappid(1910790)
addappid(1910791, 1, "091bda9dd12f1482617ab6bb0d82b3afe34f0547dad941cba55e0526dc30d7e2")
addappid(1924880, 0, "6e6f611562fa9102914e70dd105b854666fb15c53b5e72b9797acc8b594eaad4")
