-- 2830090's Lua and Manifest Created by Hubcap Manifest
-- SixthForce
-- Created: June 23, 2026 at 10:41:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2830090) -- SixthForce
-- MAIN APP DEPOTS
addappid(2830091, 1, "b1fcfc16272ce6dbd5d3c7aca4e427c86164a134a2bfb53faa0f85b371ca5953") -- Depot 2830091
setManifestid(2830091, "1275609782240709634", 3491068835)
addappid(2830092, 1, "bbc1389338a916e50d26063bb1b095af1b0dbd04031936835cce6dd391a56866") -- Depot 2830092
setManifestid(2830092, "4674937751758716070", 3650482520)