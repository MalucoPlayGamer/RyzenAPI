-- Generated with Luie @ https://lua.tools/
-- 2830090 - SixthForce
-- Generated 2026-08-08 18:11:40 UTC
-- # Depots (Total/DLC/Shared): 3/0/0

-- Main AppID
addappid(2830090)

-- Main Depots
addappid(2830091, 1, "b1fcfc16272ce6dbd5d3c7aca4e427c86164a134a2bfb53faa0f85b371ca5953") -- (windows)
setManifestid(2830091, "4770812714964586996", 3301217452)
addappid(2830092, 1, "bbc1389338a916e50d26063bb1b095af1b0dbd04031936835cce6dd391a56866") -- (macos)
setManifestid(2830092, "6572069320285952410", 3474394416)

-- DLC's (no depot keys required)
addappid(4999260) -- Sixth Force - Community Supporter Pack

-- Missing Depots (We don't have the keys yet lol): 2830093
