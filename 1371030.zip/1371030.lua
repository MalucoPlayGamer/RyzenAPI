-- Lua provided by SkyAPI 
-- Game: 他人世界末 原声音乐集 On-looker-OST
addappid(1371030)
addappid(1371031, 1, "be8404937e35c3f781e5e1b49c3eb21766846e80ad36e71d5f9084aaf983aad4")
addappid(1371033, 1, "d3c63a89f0833552c54bf9e0acc9d9007790adadaddfe05a7a741f2da1bbeaaa")
