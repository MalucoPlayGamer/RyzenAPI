-- Lua provided by RyzenAPI
-- Game: 3354440

-- MAIN APPLICATION
addappid(3354440)
-- Game: addappid(3354440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354440,0,"1281cf3bd13f83c93ff54722457c548cebedfb99e0af6b1bb90cac31655fe2c2")
