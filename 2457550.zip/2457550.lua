-- Lua provided by RyzenAPI
-- Game: King Arthur: Legends Rise Playtest

-- MAIN APPLICATION
addappid(2457550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457551, 1, "50d4f8cb17e763af1052478a8e11132cf0026fd0679c1469b1f4306d239107b1")

