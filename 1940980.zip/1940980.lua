-- Lua provided by RyzenAPI
-- Game: 1940980

-- MAIN APPLICATION
addappid(1940980)
-- Game: addappid(1940980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940981, 1, "21785ab8cb5d1722c44ef7478234910f2524cbb71473af4d5c8df4efb9eddc0a")
