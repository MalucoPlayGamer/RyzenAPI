-- Lua provided by RyzenAPI
-- Game: Small Kingdoms Prologue

-- MAIN APPLICATION
addappid(2533030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533031, 1, "dbdc5264182c2dc3970a16ecbbd307267f2071a208d2cea4347619e69330eca5")
