-- Lua provided by RyzenAPI
-- Game: Game: Maid Survivors : Little Angels Demo

-- MAIN APPLICATION
addappid(2827590)
-- Game: addappid(2827590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827591, 1, "cf9a7267366a80b4dea0f7c59229aded21baec9436cab72939c81d8dadc45ceb")
