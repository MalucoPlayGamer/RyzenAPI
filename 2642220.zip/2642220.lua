-- Lua provided by RyzenAPI
-- Game: God Chosen Place

-- MAIN APPLICATION
addappid(2642220)
-- Game: addappid(2642220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642221, 1, "2c5361611491e5387d2462fd90dcf7ffcc58e6d0ef86309058af9297ed3e8994")
addappid(2642222, 1, "436b28bfc43bb53011215f5b8b56eb6e420a10aad1a0990127f914f8f0a41d70")
