-- Lua provided by RyzenAPI 
-- Game: AppID 3038870
addappid(3038870)
addappid(3038871, 1, "0da92f8892b52e3d5364c42e979832a9fb13e938397b3d63f7bb25bc30a4b17d")
