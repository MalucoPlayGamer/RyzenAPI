-- Lua provided by RyzenAPI
-- Game: Air Rage

-- MAIN APPLICATION
addappid(583510)

-- MAIN APP DEPOTS / PACKAGES
addappid(583511, 1, "4d6553791d3eacf19496f6538bfe147f01b1c9eee370fa493b06191ae50296b4")
