-- Lua provided by RyzenAPI
-- Game: Chop Goblins

-- MAIN APPLICATION
addappid(1935660)
-- Game: addappid(1935660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935661, 1, "a1cbc497e9379f494fdff0228c60ac13e6128ba5dedb4e7cf2c75e7411869d86")
addappid(2409650, 0, "68bef0d8292a91e5b221adaa02cff211615f4108f35dd371eb8c42f90d75f822")
