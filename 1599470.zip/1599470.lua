-- Lua provided by RyzenAPI
-- Game: addappid(1599470)

-- MAIN APPLICATION
addappid(1599470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599471, 1, "43090e52f0e5ae8440721d51c7256a07b1a447a9e25685ffd9b1e1d76292be0f")
