-- Lua provided by RyzenAPI
-- Game: 無知ムチぬえっＸ Demo

-- MAIN APPLICATION
addappid(2869920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869921, 1, "394e59c3853fc84df8a5b1170de61979025886897defb20d0be70e02919b768e")
