-- Lua provided by RyzenAPI
-- Game: Chambered

-- MAIN APPLICATION
addappid(658230)
-- Game: addappid(658230)

-- MAIN APP DEPOTS / PACKAGES
addappid(658231, 1, "1faeca819822c3f3ec7b265e445363acf3ea95f7a0faa4e50897ab837495ff05")
