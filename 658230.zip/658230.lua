-- Lua provided by RyzenAPI 
-- Game: Chambered
addappid(658230)
addappid(658231, 1, "1faeca819822c3f3ec7b265e445363acf3ea95f7a0faa4e50897ab837495ff05")
