-- Lua provided by RyzenAPI
-- Game: Game: AppID 1225660

-- MAIN APPLICATION
addappid(1225660)
-- Game: addappid(1225660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225661, 1, "bbf7ff1cc084c7cd5f4fc99577efb4c02635ceb8dbb4da6cb8f0f9da0822fe61")
addappid(1225662, 1, "c8e7b5310d69f0651d6ff74330c08fc5d35ddd9450ebf5bea99ec959c9277e1f")
addappid(1225663, 1, "240ec58a9e2af4227a4a6048f01ebbb0f4c4c6968d1347bd5ffe30b724121c67")
addappid(1650940, 0, "e646045b1a139aeaf656c266efaec47a9a51880c9618cbb4c22a505e5b2e95f4")
