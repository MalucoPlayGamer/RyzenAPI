-- Lua provided by RyzenAPI
-- Game: AppID 631510

-- MAIN APPLICATION
addappid(631510)

-- MAIN APP DEPOTS / PACKAGES
addappid(631511, 1, "79183f987f646ce0abe58d2a413285f83e8bc0d045c01864d28e30bb6ee37ae2")
addappid(811840, 0, "16b5d8916c93e2e48652438e21a29ca27db96cdf30f095c95d0ee9eec24cf34b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
