-- Lua provided by RyzenAPI
-- Game: addappid(631510)

-- MAIN APPLICATION
addappid(631510)

-- MAIN APP DEPOTS / PACKAGES
addappid(631511, 1, "79183f987f646ce0abe58d2a413285f83e8bc0d045c01864d28e30bb6ee37ae2")
addappid(811840, 0, "16b5d8916c93e2e48652438e21a29ca27db96cdf30f095c95d0ee9eec24cf34b")
