-- Lua provided by RyzenAPI
-- Game: Gensokyo Night Festival

-- MAIN APPLICATION
addappid(1122050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122051, 1, "5974f8138ac0f50856b879f4e85bced29cb0ad8a28075d48a59a2010ac5faa9c")

