-- Lua provided by RyzenAPI
-- Game: addappid(1252600)

-- MAIN APPLICATION
addappid(1252600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252601, 1, "48646fb6dfc5f57027ab3696f0fc3a31568db38a78289dafd464c8ef4dbd7325")
