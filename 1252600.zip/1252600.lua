-- Lua provided by RyzenAPI
-- Game: ANOTHER EDEN

-- MAIN APPLICATION
addappid(1252600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252601, 1, "48646fb6dfc5f57027ab3696f0fc3a31568db38a78289dafd464c8ef4dbd7325")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
