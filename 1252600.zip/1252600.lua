-- Lua provided by SkyAPI 
-- Game: ANOTHER EDEN
addappid(1252600)
addappid(1252601, 1, "48646fb6dfc5f57027ab3696f0fc3a31568db38a78289dafd464c8ef4dbd7325")
