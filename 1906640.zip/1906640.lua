-- Lua provided by RyzenAPI
-- Game: Revenge of the Killer Octopus

-- MAIN APPLICATION
addappid(1906640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906641, 1, "9f6c6a7036d27842efd22182e323239597698f1fd08fa9f42f77c97b471c4598")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
