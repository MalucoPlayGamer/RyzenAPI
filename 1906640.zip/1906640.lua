-- Lua provided by RyzenAPI 
-- Game: Revenge of the Killer Octopus
addappid(1906640)
addappid(1906641, 1, "9f6c6a7036d27842efd22182e323239597698f1fd08fa9f42f77c97b471c4598")
