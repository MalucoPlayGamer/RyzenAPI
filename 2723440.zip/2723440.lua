-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2723440)
-- Game: addappid(2723440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723440,0,"2892f083c96c2a2eee09be44f430872b1ff01c9b1d8487667f20170b5ec68ea6")
