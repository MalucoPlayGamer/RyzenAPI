-- Lua provided by RyzenAPI
-- Game: 3038550

-- MAIN APPLICATION
addappid(3038550)
-- Game: addappid(3038550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038551, 1, "79ae4ad1dc431e34774e85a45161ea0f96ddf81db038a1a12efc714ec813e7c4")
