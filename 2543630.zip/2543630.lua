-- Lua provided by SkyAPI 
-- Game: WarWar Battle Kingdom
addappid(2543630)
addappid(2543631, 1, "8ae0da20a1e67ce069197e7b75a470014db428a2f88dbabf73ea807d9fbc339c")
