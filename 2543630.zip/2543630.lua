-- Lua provided by RyzenAPI
-- Game: WarWar Battle Kingdom

-- MAIN APPLICATION
addappid(2543630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543631, 1, "8ae0da20a1e67ce069197e7b75a470014db428a2f88dbabf73ea807d9fbc339c")
