-- Lua provided by RyzenAPI
-- Game: JDM: Japanese Drift Master

-- MAIN APPLICATION
addappid(1153410)
-- Game: addappid(1153410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153411, 1, "aae6e034473725f27603fc003f2520e4df8111c1433317b84a92e8bb8fb64913")
addappid(3749551, 0, "ebe86f26c512a72840dfc92fcfd523c57ede0185d0150f30ea1f0e04a11a219d")
