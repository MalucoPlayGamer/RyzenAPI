-- Lua provided by RyzenAPI
-- Game: JDM: Japanese Drift Master

-- MAIN APPLICATION
addappid(1153410)
addappid(3749550)
addappid(4054180)
addappid(4449300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1153411,0,"aae6e034473725f27603fc003f2520e4df8111c1433317b84a92e8bb8fb64913")
addappid(3749551,0,"ebe86f26c512a72840dfc92fcfd523c57ede0185d0150f30ea1f0e04a11a219d")

