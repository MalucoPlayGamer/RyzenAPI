-- Lua provided by SkyAPI 
-- Game: Hentai Aim Trainer 2
addappid(2219970)
addappid(2219971, 1, "0556b0fe5fbbd0f9dc60d539e778eb5758c160eed6e1e8f073d8575863eb004e")
