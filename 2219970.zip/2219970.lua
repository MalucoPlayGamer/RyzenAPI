-- Lua provided by RyzenAPI
-- Game: Game: Hentai Aim Trainer 2

-- MAIN APPLICATION
addappid(2219970)
-- Game: addappid(2219970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219971, 1, "0556b0fe5fbbd0f9dc60d539e778eb5758c160eed6e1e8f073d8575863eb004e")
