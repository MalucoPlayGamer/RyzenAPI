-- Lua provided by RyzenAPI
-- Game: LingerToAlive

-- MAIN APPLICATION
addappid(2182160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2182161, 1, "6f99b464b566cc90f6c4563a703e3cb3a3e8926f5c70b094b2a51cf89533fa9d")
addappid(2182162, 1, "ca295b5f1ceccd98ba61e9a950e22ff7dc7e1712d8a896d3894ea37ea59d0f66")

