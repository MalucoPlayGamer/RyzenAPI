-- Lua provided by RyzenAPI
-- Game: addappid(3073000)

-- MAIN APPLICATION
addappid(3073000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073001, 1, "6b3321e11a6d8283e8116414adccd9da0fe1e2603e4441fbd790a59af4149818")
