-- Lua provided by RyzenAPI
-- Game: Grind Survivors

-- MAIN APPLICATION
addappid(3816930)
addappid(4332160)
addappid(4332170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3816931,0,"4c48190b96fa1496187f24f2b468e425e8a6532f2b455e623c42f4d1575a48a9")
addappid(4332161,0,"59168ce0fd1bc22c7c2c683a5140cfcf4d0bc2f0700c8353fe4849e9f9404019")

