-- Lua provided by RyzenAPI
-- Game: AppID 648870

-- MAIN APPLICATION
addappid(648870)
-- Game: addappid(648870)

-- MAIN APP DEPOTS / PACKAGES
addappid(648871, 1, "eb4adbae4345da7696d7c3d71522611915d768d8cd360eef3ba1e04983740b84")
