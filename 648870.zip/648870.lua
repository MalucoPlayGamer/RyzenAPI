-- Lua provided by RyzenAPI
-- Game: Intel 5G VR Experience

-- MAIN APPLICATION
addappid(648870)

-- MAIN APP DEPOTS / PACKAGES
addappid(648871, 1, "eb4adbae4345da7696d7c3d71522611915d768d8cd360eef3ba1e04983740b84")
