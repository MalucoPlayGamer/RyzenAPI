-- Lua provided by RyzenAPI
-- Game: NO.8 High School

-- MAIN APPLICATION
addappid(3421860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421862,0,"ad5c2b97ba853b7d9322b2305b8ef2bab6dd1a0a19d4e3177c796aadf7b6b81f")
