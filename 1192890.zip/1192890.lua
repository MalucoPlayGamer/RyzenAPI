-- Lua provided by RyzenAPI
-- Game: Game: AppID 1192890

-- MAIN APPLICATION
addappid(1192890)
-- Game: addappid(1192890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192891, 1, "ceadfd80a399c35c7d4b17430b519fc7e8e994cbaba9fae2eaa4028fc8d76457")
addappid(1205890, 0, "dee4cf3d1e87480f8d1a898400b491c49b5ccb641cf5447310cf707b64bc1dd1")
addappid(1208940, 0, "59762503ae4b8e1ff71cae4c45d03e26136af037f8a07117df113540a0802238")
