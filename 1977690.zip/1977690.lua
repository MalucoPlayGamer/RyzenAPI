-- Lua provided by RyzenAPI
-- Game: 1977690

-- MAIN APPLICATION
addappid(1977690)
-- Game: addappid(1977690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977691, 1, "df8b4b8b251b30b6c80d80e39dc83f44f5115d6eea146819066dc666a44b8382")
