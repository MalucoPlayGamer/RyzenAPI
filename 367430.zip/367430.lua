-- Lua provided by RyzenAPI
-- Game: One Ship Two Ship Redshift Blueshift

-- MAIN APPLICATION
addappid(367430)

-- MAIN APP DEPOTS / PACKAGES
addappid(367431, 1, "18130aca0699b945e05165afaf9f4ca12f932dc55f2813f10fb8ab67d7e8abbf")
