-- Lua provided by RyzenAPI
-- Game: addappid(1751630)

-- MAIN APPLICATION
addappid(1751630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751631, 1, "6ceb8e5102f7a696dc17620e442de3abdcf24b528b424eb60f86c7e913d83ad8")
