-- Lua provided by RyzenAPI 
-- Game: AppID 2683210
addappid(2683210)
addappid(2683211, 1, "7b7d4b1811e83c42537c3c566d81c425a678876b57f2f2e1c9de104e0c12df0b")
