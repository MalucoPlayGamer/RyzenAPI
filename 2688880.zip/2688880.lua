-- Lua provided by SkyAPI 
-- Game: Cultivation Fantasy Demo
addappid(2688880)
addappid(2688881, 1, "7c954998c3b676f5b053157780e9c573dbbb59c2276321644ef245132be7465e")
