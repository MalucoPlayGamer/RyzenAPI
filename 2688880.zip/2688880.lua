-- Lua provided by RyzenAPI
-- Game: Game: Cultivation Fantasy Demo

-- MAIN APPLICATION
addappid(2688880)
-- Game: addappid(2688880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688881, 1, "7c954998c3b676f5b053157780e9c573dbbb59c2276321644ef245132be7465e")
