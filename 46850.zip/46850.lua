-- Lua provided by RyzenAPI
-- Game: Zombie Pirates

-- MAIN APPLICATION
addappid(46850)

-- MAIN APP DEPOTS / PACKAGES
addappid(46851, 1, "7e693d34ca926d6f8730631d445b17d9b26c57a62ab417f3e146b94782ffd9e5")

