-- Lua provided by RyzenAPI
-- Game: Zombie Pirates

-- MAIN APPLICATION
addappid(46850)

-- MAIN APP DEPOTS / PACKAGES
addappid(46851, 1, "7e693d34ca926d6f8730631d445b17d9b26c57a62ab417f3e146b94782ffd9e5")
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)

