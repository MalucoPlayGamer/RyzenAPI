-- Lua provided by RyzenAPI
-- Game: Seek Girl Ⅶ

-- MAIN APPLICATION
addappid(1464930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464931, 1, "4981b98323c2aee1b903c0b55730a16d1bd40cc6f5f734dac7233344e8992471")
addappid(1481250, 0, "9d1166c7e9bf8ce15365a4293016aaeadaddb6273cdf297ae70b1d1f144b7ef4")

