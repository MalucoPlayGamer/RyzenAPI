-- Lua provided by RyzenAPI
-- Game: AppID 2761890

-- MAIN APPLICATION
addappid(2761890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761891, 1, "60df43351f67caea4a0c7f6b7d4b2dafa9d9ac81a04e1202364aac69a93aa7f9")
