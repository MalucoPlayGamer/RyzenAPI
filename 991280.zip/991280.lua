-- Lua provided by SkyAPI 
-- Game: Air Combat XF
addappid(991280)
addappid(991281, 1, "62759fa41e225b100711ee4379a8f0e55ecf13fa5a667710431c322cb68fe08a")
addappid(991282, 1, "996f50de04c60ad846a7dba48d051a3ca8a35d968d756be9c264e16559feb62a")
