-- Lua provided by RyzenAPI
-- Game: Air Combat XF

-- MAIN APPLICATION
addappid(991280)

-- MAIN APP DEPOTS / PACKAGES
addappid(991281, 1, "62759fa41e225b100711ee4379a8f0e55ecf13fa5a667710431c322cb68fe08a")
addappid(991282, 1, "996f50de04c60ad846a7dba48d051a3ca8a35d968d756be9c264e16559feb62a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
