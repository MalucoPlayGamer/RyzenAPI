-- Lua provided by RyzenAPI
-- Game: 冬日树下的回忆

-- MAIN APPLICATION
addappid(2403320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403321, 1, "0347998936037fcc49aeae36dcc9852d1e4fda8a96c134ed7a8586370bc5c9c3")

