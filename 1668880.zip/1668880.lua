-- Lua provided by RyzenAPI
-- Game: Spring and Girls

-- MAIN APPLICATION
addappid(1668880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668881, 1, "5207697c6e9c8f23ce339d6f4403a182ce029916d693ad36fce1d97d05f83385")
