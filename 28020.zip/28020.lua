-- Lua provided by RyzenAPI 
-- Game: AppID 28020
addappid(28020)
addappid(28021, 1, "ebb0cb44d7ca620c285f3dabafcffe7e71a8cb586f8f8d82d7615f010cadead7")
addappid(28023, 1, "ea2491231a89b49d3dd37deaf8162755885cac733fad52e54811ff755002acc2")
