-- Lua provided by RyzenAPI
-- Game: Game: Arkhelom 3D

-- MAIN APPLICATION
addappid(373670)
-- Game: addappid(373670)

-- MAIN APP DEPOTS / PACKAGES
addappid(373671, 1, "8e697b01b603b3a7d40218bdd607fe7e6d6fd6a0c9ecfce09e7f20bf649fb0b8")
