-- Lua provided by RyzenAPI
-- Game: Yellowcreek Stories - The Cabin Watcher

-- MAIN APP DEPOTS / PACKAGES
addappid(4411840, 1, "ba5ab9e537fff302a37ba3cdba37cf7d46de0fd30ddc9ad3227c3761f50a64db") -- Yellowcreek Stories - The Cabin Watcher
addappid(4411841, 1, "9c987b78e66423f8ed8789fffce4402cd5347a399597078e96b41985f22d80d5") -- Depot 4411841

