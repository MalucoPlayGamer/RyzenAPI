-- 4411840's Lua and Manifest Created by Hubcap Manifest
-- Yellowcreek Stories - The Cabin Watcher
-- Created: August 06, 2026 at 11:24:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4411840, 1, "ba5ab9e537fff302a37ba3cdba37cf7d46de0fd30ddc9ad3227c3761f50a64db") -- Yellowcreek Stories - The Cabin Watcher
-- MAIN APP DEPOTS
addappid(4411841, 1, "9c987b78e66423f8ed8789fffce4402cd5347a399597078e96b41985f22d80d5") -- Depot 4411841
setManifestid(4411841, "7698842807604822459", 4305098467)