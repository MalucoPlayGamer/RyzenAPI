-- Lua provided by RyzenAPI
-- Game: 2598310

-- MAIN APPLICATION
addappid(2598310)
-- Game: addappid(2598310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598311, 1, "421d6cfe2aea41761e018d384aa3b7d18f3971f12fd6fe2f7af6db4f0d06fa04")
