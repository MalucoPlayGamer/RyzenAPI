-- Lua provided by RyzenAPI
-- Game: Femboy Simulator

-- MAIN APPLICATION
addappid(4570310)

-- MAIN APP DEPOTS / PACKAGES
addappid(4570311,0,"8b3f467ebecab025cd6a2424b5bac52ec94e9a42c1f3f59a262327bf81057e4c")
addappid(4570312,0,"0a4b7323cb5dede0796ad8dead81b030e2b2e4ab3dab5442f53add20ffde3bc9")

