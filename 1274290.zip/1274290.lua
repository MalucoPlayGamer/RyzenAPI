-- Lua provided by RyzenAPI
-- Game: Kidnapped Girl

-- MAIN APPLICATION
addappid(1274290)
addappid(1345960)
addappid(1345961)
addappid(1345962)
addappid(1358890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274291, 1, "95b07ab7d39b5890ec7f10b2efb07705027aa64891040d80382f8a8f2248504a")

