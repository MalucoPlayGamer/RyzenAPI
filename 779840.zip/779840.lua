-- Lua provided by RyzenAPI
-- Game: Forgotten Sound 1: Revelation

-- MAIN APPLICATION
addappid(779840)

-- MAIN APP DEPOTS / PACKAGES
addappid(779841,0,"a80d997f9ab18d4eb008815745b016e21a785bc524d9bdeeea83925f29482c61")

