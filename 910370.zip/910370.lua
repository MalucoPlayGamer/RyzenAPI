-- Lua provided by RyzenAPI
-- Game: CoreOptimizer

-- MAIN APPLICATION
addappid(910370)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(910371, 1, "d625f7667f4c808e557ac80fec48ccc738efef7b1cbefad4ca788c57cd785137")
