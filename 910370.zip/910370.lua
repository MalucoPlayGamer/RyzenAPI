-- Lua provided by RyzenAPI 
-- Game: AppID 910370
addappid(910370)
addappid(910371, 1, "d625f7667f4c808e557ac80fec48ccc738efef7b1cbefad4ca788c57cd785137")
