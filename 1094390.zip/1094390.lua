-- Lua provided by RyzenAPI
-- Game: Waltz of the Wizard

-- MAIN APPLICATION
addappid(1094390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094391, 1, "22e4dc8fded362712da10517a0d040b3b16209ebefa394898fe37df1b34de209")

