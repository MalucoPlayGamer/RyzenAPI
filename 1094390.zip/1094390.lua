-- Lua provided by RyzenAPI
-- Game: Waltz of the Wizard

-- MAIN APPLICATION
addappid(1094390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094391, 1, "22e4dc8fded362712da10517a0d040b3b16209ebefa394898fe37df1b34de209")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
