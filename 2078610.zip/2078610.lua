-- Lua provided by RyzenAPI
-- Game: Super Nova Party

-- MAIN APPLICATION
addappid(2078610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2078611, 1, "09953941edd7f3597faf026531d2b1c00b97fbe44ebdb85a92774af40ad49ed3")
addappid(2078612, 1, "9b9db02acf97d020f8d37d71f14b2ee2fecad6de5795967da35777d436d266c4")

