-- Lua provided by RyzenAPI
-- Game: Super Nova Party

-- MAIN APPLICATION
addappid(2078610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078611, 1, "09953941edd7f3597faf026531d2b1c00b97fbe44ebdb85a92774af40ad49ed3")
addappid(2078612, 1, "9b9db02acf97d020f8d37d71f14b2ee2fecad6de5795967da35777d436d266c4")
