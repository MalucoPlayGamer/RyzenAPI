-- Lua provided by RyzenAPI
-- Game: Rumble Runners

-- MAIN APPLICATION
addappid(1646880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1646881, 1, "52a94b2084cfe1abba3276eaabd0c72380958434a696aab256533d99f6cf1923")

