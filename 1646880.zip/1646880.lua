-- Lua provided by RyzenAPI
-- Game: Rumble Runners

-- MAIN APPLICATION
addappid(1646880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646881, 1, "52a94b2084cfe1abba3276eaabd0c72380958434a696aab256533d99f6cf1923")
