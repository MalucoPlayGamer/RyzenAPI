-- Lua provided by RyzenAPI
-- Game: CRSED: Cuisine Royale

-- MAIN APPLICATION
addappid(884660)
-- Game: addappid(884660)

-- MAIN APP DEPOTS / PACKAGES
addappid(884661, 1, "86548a2647c488277584080991fa8f51dc18d763a55638de34a8f9d9341337a4")
addappid(884663, 1, "f59d2e2b55d08bc4824b4e93427b3a906c89f4b8a25338bf96cda6531d5bbe2a")
