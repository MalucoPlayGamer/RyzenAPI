-- Lua provided by RyzenAPI
-- Game: CRSED: Cuisine Royale

-- MAIN APPLICATION
addappid(884660)
addappid(892580)
addappid(997120)
addappid(1142900)
addappid(1142910)
addappid(1142920)
addappid(1168130)
addappid(1168131)
addappid(1207240)
addappid(1249310)
addappid(1486830)
addappid(1486831)
addappid(1486832)
addappid(1486833)
addappid(1486834)
addappid(1486835)
addappid(1486836)
addappid(1611670)
addappid(1698180)
addappid(1830750)
addappid(1901820)
addappid(2139750)
addappid(2561800)
addappid(2861370)

-- MAIN APP DEPOTS / PACKAGES
addappid(884661,0,"86548a2647c488277584080991fa8f51dc18d763a55638de34a8f9d9341337a4")
addappid(884663,0,"f59d2e2b55d08bc4824b4e93427b3a906c89f4b8a25338bf96cda6531d5bbe2a")

