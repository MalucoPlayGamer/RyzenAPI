-- Lua provided by RyzenAPI
-- Game: Project XMAS

-- MAIN APPLICATION
addappid(1889660)
-- Game: addappid(1889660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889661, 1, "469c4533d9fd229e91d0ca51378aafd64f5efa2e0a43d8cc0cf269163d1cdad5")
