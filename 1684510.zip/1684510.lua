-- Lua provided by RyzenAPI
-- Game: Game: The Plane Effect Prologue

-- MAIN APPLICATION
addappid(1684510)
-- Game: addappid(1684510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684511, 1, "3d04924600eadae98576f8c3616ea60cbe8a5cfdf413915a9bb2f5988ff89dbf")
