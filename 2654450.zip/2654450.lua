-- Lua provided by RyzenAPI 
-- Game: ChronoBabes
addappid(2654450)
addappid(2654451, 1, "ef206befb2d91188b4389a3c671ae90ac2c5b2693a123356bb934d535b7588c9")
