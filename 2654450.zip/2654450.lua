-- Lua provided by RyzenAPI
-- Game: Game: ChronoBabes

-- MAIN APPLICATION
addappid(2654450)
-- Game: addappid(2654450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654451, 1, "ef206befb2d91188b4389a3c671ae90ac2c5b2693a123356bb934d535b7588c9")
