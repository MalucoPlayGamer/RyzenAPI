-- Lua provided by RyzenAPI
-- Game: AppID 976120

-- MAIN APPLICATION
addappid(976120)

-- MAIN APP DEPOTS / PACKAGES
addappid(976121, 1, "605d29b391a039e38c29aae37713f3bf644887c89d82be0504293c3693944dc3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
