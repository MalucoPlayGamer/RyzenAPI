-- Lua provided by RyzenAPI
-- Game: Game: AppID 976120

-- MAIN APPLICATION
addappid(976120)
-- Game: addappid(976120)

-- MAIN APP DEPOTS / PACKAGES
addappid(976121, 1, "605d29b391a039e38c29aae37713f3bf644887c89d82be0504293c3693944dc3")
