-- Lua provided by RyzenAPI
-- Game: DUNGEON ENCOUNTERS

-- MAIN APPLICATION
addappid(1451080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451081, 1, "1e9210b049d3d5ab438ca571f7708025b302639f1beee2d284025fffb51911ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
