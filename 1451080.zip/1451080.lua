-- Lua provided by RyzenAPI
-- Game: 1451080

-- MAIN APPLICATION
addappid(1451080)
-- Game: addappid(1451080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451081, 1, "1e9210b049d3d5ab438ca571f7708025b302639f1beee2d284025fffb51911ee")
