-- Lua provided by RyzenAPI
-- Game: Game: AppID 977690

-- MAIN APPLICATION
addappid(977690)
-- Game: addappid(977690)

-- MAIN APP DEPOTS / PACKAGES
addappid(977691, 1, "39bfd11f3475c7b57f7f58075ef78a8e2a596054604b24c2b5f369ba309a4f4c")
