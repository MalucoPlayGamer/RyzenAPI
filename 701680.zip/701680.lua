-- Lua provided by RyzenAPI
-- Game: The Legend of Slime

-- MAIN APPLICATION
addappid(701680)
-- Game: addappid(701680)

-- MAIN APP DEPOTS / PACKAGES
addappid(701681, 1, "8e1b0501f6496a11f2a774cdeb4353a4f000bb278e7b16ece97fa3ef65137afc")
