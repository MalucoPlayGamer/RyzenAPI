-- Lua provided by SkyAPI 
-- Game: Dice & Fold
addappid(2693930)
addappid(2693931, 1, "966ee2d74d5a6753c47790de4ac4e64ed032768859bd74f1f3327de749f7cda3")
addappid(2693932, 1, "13d31953e5e95db599dc773a2bd3e6cfe146c2069217d8d30c0dc5fea6fee08e")
addappid(2693933, 1, "65fad31760d852ba42d51bd41dd198087cee07d25465963a693a299b2ea253da")
