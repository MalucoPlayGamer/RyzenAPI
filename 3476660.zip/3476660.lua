-- Lua provided by RyzenAPI
-- Game: Star Crafter

-- MAIN APPLICATION
addappid(3476660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3476661, 1, "556d09c6efd437abe16e6b4a0b3e179a2a471aacb4d522a9c536a2db40257c72")

