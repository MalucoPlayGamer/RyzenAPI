-- Lua provided by SkyAPI 
-- Game: Grapple Whip
addappid(2211120)
addappid(2211121, 1, "5137ff97fe31684837d01b6363c49388f488f53fd9312b7aa6882316ad9cfec7")
