-- Lua provided by RyzenAPI
-- Game: Aliens: Dark Descent

-- MAIN APPLICATION
addappid(1150440)
addappid(2272330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150441, 1, "328cb288abceeee524857fca615b3536ef66edfed9f90abf1688db72e4306db4")
addappid(1150443, 1, "43054529bc8dfc949bd87ace2a922a6d49baaf1502d9ab61114c312f3d0778f1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
