-- Lua provided by SkyAPI 
-- Game: AppID 1387450
addappid(1387450)
addappid(1387451, 1, "de431b99f6e653d97f86c2212d3eada32117f016d73da7c737a06d026ac9d8f8")
