-- Lua provided by RyzenAPI
-- Game: addappid(1387450)

-- MAIN APPLICATION
addappid(1387450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387451, 1, "de431b99f6e653d97f86c2212d3eada32117f016d73da7c737a06d026ac9d8f8")
