-- Lua provided by RyzenAPI
-- Game: Game: Chariot

-- MAIN APPLICATION
addappid(319450)
-- Game: addappid(319450)

-- MAIN APP DEPOTS / PACKAGES
addappid(319451, 1, "7d63c0c73eb482fefaa06cd600fde01c1167671b2ec031d396bf0cc0756d6176")
