-- Lua provided by RyzenAPI
-- Game: Is it different or not?

-- MAIN APPLICATION
addappid(2784850)
-- Game: addappid(2784850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784851, 1, "5efaa1d2ace8309af2a54feed4483fef771854fe92083e56f7aa51bb1912b936")
