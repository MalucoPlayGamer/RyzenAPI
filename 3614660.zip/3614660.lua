-- Lua provided by RyzenAPI
-- Game: addappid(3614660)

-- MAIN APPLICATION
addappid(3614660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614661, 1, "fc77e48a4a11fc2e5b0cf0a1c78baa821f7caaccfe547bc3fc712e71409debba")
