-- Lua provided by RyzenAPI
-- Game: Game: Paradise

-- MAIN APPLICATION
addappid(1725330)
-- Game: addappid(1725330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725331, 1, "9dbf36078987800598fdcd0a896f05a672664ce2e98814b31302cb2e386621f2")
