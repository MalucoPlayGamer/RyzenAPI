-- Lua provided by RyzenAPI
-- Game: Reprogram

-- MAIN APPLICATION
addappid(710670)

-- MAIN APP DEPOTS / PACKAGES
addappid(710671,0,"dac1424a716c3fa49e147b4bbc62ef4cbf977621f7d2a0afe983a239d3c53eda")

