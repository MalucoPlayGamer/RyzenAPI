-- Lua provided by RyzenAPI
-- Game: Game: Circadian Dice

-- MAIN APPLICATION
addappid(1893620)
-- Game: addappid(1893620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893621, 1, "072b28c77e6a48b80fce4a8b0d34dc430a8013f35b6e261810b0eab284f60f7b")
