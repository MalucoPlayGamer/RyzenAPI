-- 3724710's Lua and Manifest Created by Hubcap Manifest
-- Gunstoppable
-- Created: August 05, 2026 at 13:38:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3724710) -- Gunstoppable
-- MAIN APP DEPOTS
addappid(3724711, 1, "1914384a9a831e82bc8dda856747dba36fd1298956e85ee4642afbe5de431a8c") -- Depot 3724711
setManifestid(3724711, "457092964107360428", 968237861)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)