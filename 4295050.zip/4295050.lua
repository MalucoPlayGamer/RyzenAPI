-- Lua provided by RyzenAPI
-- Game: SubPrime Delivery

-- MAIN APPLICATION
addappid(4295050) -- SubPrime Delivery

-- MAIN APP DEPOTS / PACKAGES
addappid(4295051, 1, "5dfc1e0a806d3aa7006b49ff06f760bc833156d88139016d7b19bc93a41d2602") -- Depot 4295051
addappid(4295052, 1, "91c38d52af8539ffa59f59a9cdd666bbcb3ac028cc9f92895bfea3bb547ab1f4") -- Depot 4295052

