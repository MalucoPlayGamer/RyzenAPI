-- 4295050's Lua and Manifest Created by Hubcap Manifest
-- SubPrime Delivery
-- Created: August 17, 2026 at 03:53:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4295050) -- SubPrime Delivery
-- MAIN APP DEPOTS
addappid(4295051, 1, "5dfc1e0a806d3aa7006b49ff06f760bc833156d88139016d7b19bc93a41d2602") -- Depot 4295051
setManifestid(4295051, "2839983984675857262", 141943913)
addappid(4295052, 1, "91c38d52af8539ffa59f59a9cdd666bbcb3ac028cc9f92895bfea3bb547ab1f4") -- Depot 4295052
setManifestid(4295052, "5699489139225078667", 424693072)