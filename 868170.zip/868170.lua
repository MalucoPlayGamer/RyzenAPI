-- Lua provided by RyzenAPI
-- Game: Together VR - PC Edition DLC

-- MAIN APPLICATION
addappid(868170)

-- MAIN APP DEPOTS / PACKAGES
addappid(868170,0,"61f141c3f5ba9409faf6b69a94823e1721ea7a9c4715203a4d934cab903ef217")

