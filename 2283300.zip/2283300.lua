-- Lua provided by RyzenAPI 
-- Game: Chants of Sennaar Demo
addappid(2283300)
addappid(2283301, 1, "94cc0cfc7e76ec5fb0f6f64d9d6b0ce4b54b5c75ce2442f96a11954e486ca9e0")
