-- Lua provided by RyzenAPI 
-- Game: AppID 3007680
addappid(3007680)
addappid(3007681, 1, "08bb9f84304b47df0db2effe27ad9c691ccf67f2d7fb096b516b0cf7a2f2af2c")
