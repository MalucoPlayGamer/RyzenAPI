-- Lua provided by RyzenAPI
-- Game: Game: AppID 3007680

-- MAIN APPLICATION
addappid(3007680)
-- Game: addappid(3007680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007681, 1, "08bb9f84304b47df0db2effe27ad9c691ccf67f2d7fb096b516b0cf7a2f2af2c")
