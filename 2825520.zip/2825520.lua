-- Lua provided by RyzenAPI
-- Game: Despot Zombie

-- MAIN APPLICATION
addappid(2825520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825521, 1, "f6259af31ea0fabaf34ff14b42a43e8e6c973181f7ff62daddf9d0d5d3384a53")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
