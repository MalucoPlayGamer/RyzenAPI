-- Lua provided by RyzenAPI
-- Game: Despot Zombie

-- MAIN APPLICATION
addappid(2825520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825521, 1, "f6259af31ea0fabaf34ff14b42a43e8e6c973181f7ff62daddf9d0d5d3384a53")
