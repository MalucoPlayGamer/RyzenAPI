-- Lua provided by RyzenAPI
-- Game: Just Another Memory

-- MAIN APPLICATION
addappid(1121290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121292,0,"3ec5d81589e80f6ca1df136d762695e0e2cc780775d0b65e761b3bdbd5d652e4")
addappid(1121293,0,"3da978ee99dd7eaea98d7b433f40f467b9884bb828a5f1323b46f9a9b53e4ef3")

