-- Lua provided by RyzenAPI
-- Game: 894890

-- MAIN APPLICATION
addappid(894890)

-- MAIN APP DEPOTS / PACKAGES
addappid(894894,0,"e1665697a4a80eab9996f3e6560fb9208f4adb9ff08b852dea4a0c6a8e73789a")

