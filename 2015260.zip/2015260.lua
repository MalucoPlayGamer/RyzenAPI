-- Lua provided by RyzenAPI
-- Game: 2015260

-- MAIN APPLICATION
addappid(2015260)
-- Game: addappid(2015260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015261, 1, "2fab1327a77144444087c36271e8fb604fe42dda44578ea1d5e706e1ff52500e")
