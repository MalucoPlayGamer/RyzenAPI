-- Lua provided by RyzenAPI
-- Game: addappid(2077430)

-- MAIN APPLICATION
addappid(2077430)
addappid(2077480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077431, 1, "6ab86104574ab0fe9bb10f9b4df4340ccb7f6563375d696dfee15ea99de1075d")
