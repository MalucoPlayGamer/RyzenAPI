-- Lua provided by RyzenAPI
-- Game: addappid(1739790)

-- MAIN APPLICATION
addappid(1739790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739792,0,"24c8012214152f3b4022f1f29d9546e9468b75ab4472f53ff4feefdb82f155fe")
