-- Lua provided by RyzenAPI
-- Game: Game: AppID 1526480

-- MAIN APPLICATION
addappid(1526480)
-- Game: addappid(1526480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526481, 1, "8e736d566f8d1e1e59dfa5e2b8c418edc4aff61495234a570806a6f83adb4380")
