-- Lua provided by RyzenAPI
-- Game: Lost Planet™: Extreme Condition

-- MAIN APPLICATION
addappid(6510)

-- MAIN APP DEPOTS / PACKAGES
addappid(6511, 1, "cdf263d649c38a56c5db71c3f56977cfc98c77569c38dbfca56eb285daec2f8a")
addappid(6512, 1, "c2d4670673d1e03729ee8c2371b154c07f1424806e0ac0a2cc370faec581ee3b")
addappid(6513, 1, "23fb40120934b68c5b9aba0f2045f4b88262072989d47e46973480605b9bf9dd")
addappid(6514, 1, "3e3bdc7c9d4c3c315ed58ff6b638c212bdb970d72fbac3a3112ec3c6bdf8ef20")
addappid(6515, 1, "2dc3259147895a03e62f6f84ab288928677817c0daa74afd005298ffed1aed59")
addappid(6516, 1, "653a7e0b6d65efc080cb29179412826567380a1f532303a06551476448dab0cf")
addappid(6517, 1, "f24d03d132992cc75b3ba86e00da87ae3757007a5743df95d27c6ada3797ee0c")
addappid(6518, 1, "a7c2594dbeff9bce314bd0e2769e7dda0946c6acaa3043c5f14a8d6477ad15c1")
addappid(6519, 1, "66499509d65d6ff51d6b20b70abd96fe24eb865ae6f9a7c872dc49deabb5ab57")

