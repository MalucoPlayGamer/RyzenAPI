-- Lua provided by RyzenAPI
-- Game: Idol Showdown

-- MAIN APPLICATION
addappid(1742020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742021, 1, "80d84aa0bc583a865ef07a6ec0fe52df9bf1e81f004f489e2d78e661dcc04d9c")

