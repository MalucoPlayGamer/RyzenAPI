-- Lua provided by RyzenAPI
-- Game: Idol Showdown

-- MAIN APPLICATION
addappid(1742020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742021, 1, "80d84aa0bc583a865ef07a6ec0fe52df9bf1e81f004f489e2d78e661dcc04d9c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
