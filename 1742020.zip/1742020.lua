-- Lua provided by SkyAPI 
-- Game: Idol Showdown
addappid(1742020)
addappid(1742021, 1, "80d84aa0bc583a865ef07a6ec0fe52df9bf1e81f004f489e2d78e661dcc04d9c")
