-- Lua provided by RyzenAPI
-- Game: AppID 1383630

-- MAIN APPLICATION
addappid(1383630)
-- Game: addappid(1383630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383631, 1, "77bb7191440a6d4af93a5c978967d21a51e33f78ba0ca0cfc45739289a8da17c")
