-- Lua provided by RyzenAPI
-- Game: AppID 801360

-- MAIN APPLICATION
addappid(801360)

-- MAIN APP DEPOTS / PACKAGES
addappid(801361, 1, "d5747e52634303a27a21bc46ab027a23fd1e7ee9cb034436e6fd3c2cfc096a9c")

