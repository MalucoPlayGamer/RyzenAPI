-- Lua provided by RyzenAPI
-- Game: Game: Curse of the Dead Gods - Original Soundtrack

-- MAIN APPLICATION
addappid(1556810)
-- Game: addappid(1556810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556811, 1, "85b443ae50aebd748160f34f2a578edb684182d5f300eacda11511b54def1c37")
addappid(1556812, 1, "3191d6aad30a75623d83abb4af4b0525883514b7bfcd3e7380e7119e4d2ed320")
