-- Lua provided by RyzenAPI
-- Game: addappid(3267530)

-- MAIN APPLICATION
addappid(3267530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267531, 1, "b85c7cad5c07979e58f7269b2b35143cd08b3cdd00638088396d5944a9490bad")
