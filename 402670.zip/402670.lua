-- Lua provided by RyzenAPI
-- Game: Space Thinger

-- MAIN APPLICATION
addappid(402670)
-- Game: addappid(402670)

-- MAIN APP DEPOTS / PACKAGES
addappid(402671, 1, "3d9defde0196cfea9df6cb99886ad171d54383369c869bed9af7a2ee8864d0ba")
addappid(402672, 1, "126f661dbc1546c0c436d833880d82f0c6ed2f91be18e95393fb759e1dd22b35")
