-- Lua provided by RyzenAPI
-- Game: Metro 2033 Redux

-- MAIN APPLICATION
addappid(286690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(286691, 1, "9f2bfaf0ab2396150e63cd8b6b38d236d0920a9f71c1a985229eaa30e1cd8236")
addappid(286692, 1, "fcc52f00eb59255ae34e6033cab93c08fd90afa73ca1e540aa945f7d80c5cda9")
addappid(286693, 1, "a717bf4f94b493ea0a156cf0499828cd3846cb1e2ad512ce0b14a9ff63367c5c")
addappid(286694, 1, "3ebbefa9c070b65308bb5b94c5817ed0d74faa04b1d147f778b12012699b749c")

