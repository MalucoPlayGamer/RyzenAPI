-- Lua provided by RyzenAPI
-- Game: Metro 2033 Redux

-- MAIN APPLICATION
addappid(286690)

-- MAIN APP DEPOTS / PACKAGES
addappid(286691, 1, "9f2bfaf0ab2396150e63cd8b6b38d236d0920a9f71c1a985229eaa30e1cd8236")
addappid(286692, 1, "fcc52f00eb59255ae34e6033cab93c08fd90afa73ca1e540aa945f7d80c5cda9")
addappid(286693, 1, "a717bf4f94b493ea0a156cf0499828cd3846cb1e2ad512ce0b14a9ff63367c5c")
addappid(286694, 1, "3ebbefa9c070b65308bb5b94c5817ed0d74faa04b1d147f778b12012699b749c")
