-- Lua provided by RyzenAPI
-- Game: Elon Simulator 2019

-- MAIN APPLICATION
addappid(1116550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116551, 1, "d5502dc043d4ff009cbc5979eb36c1d0ac2c1893f0fafcbfa91a2def4ac40540")
addappid(1116552, 1, "f232ea4aa9f1c9e3a135d317cceec995b65c0a87b42deff66de89e7475b442dd")
addappid(1116553, 1, "1bdf508c5aba9fd709dbe9a710366eca3bfb665e3e02379147a7562e366384d8")
