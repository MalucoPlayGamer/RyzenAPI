-- Lua provided by RyzenAPI
-- Game: Game: Soundtrack - Zombie Police: Christmas Dancing with Police Zombies

-- MAIN APPLICATION
addappid(3098190)
-- Game: addappid(3098190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098191, 1, "4b4ca525d7807166a5b41777a19549cb2432022ad06cee205b34bf70548b3032")
addappid(3098192, 1, "441b877045d4448fc4effca6e347dbe770b1a54c8c831fb481c269229f7a58bf")
