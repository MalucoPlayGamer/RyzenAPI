-- Lua provided by RyzenAPI
-- Game: 1994070

-- MAIN APPLICATION
addappid(1994070)
-- Game: addappid(1994070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994071, 1, "a6e0ac76c46d00deee652142e7760e17ab069de8d9b7d0f4b3992e6e0a03be57")
addappid(1994072, 1, "e362f83e9fe255ebfbad70c2bf454f52dc7db41330a560009fe13b004182432f")
addappid(1994073, 1, "bd2f06fafae1bc1fb3943b15f614c5a0700ab7e6abf081d344e3295e2e48342b")
