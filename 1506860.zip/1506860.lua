-- Lua provided by RyzenAPI
-- Game: FRIGID VR Demo

-- MAIN APPLICATION
addappid(1506860)
-- Game: addappid(1506860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506861, 1, "a8426fb15ed8603ce1dc93ed808974b7501cf94444902502f46f98bd36f4621f")
