-- Lua provided by RyzenAPI
-- Game: A Dance of Fire and Ice OST

-- MAIN APPLICATION
addappid(1027880)
-- Game: addappid(1027880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715611,0,"42f4bbb800d0eb8cd934988ca3178cbf4bc744081d6315553bcc663ead6afb93")
addappid(2715612,0,"98cf950ac365cf9c0ef0dc7ea2f17257157f65789f3bbd730e30446d3717772a")
