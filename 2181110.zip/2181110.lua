-- Lua provided by RyzenAPI
-- Game: AppID 2181110

-- MAIN APPLICATION
addappid(2181110)
-- Game: addappid(2181110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181111, 1, "cbeac6d0144910eb6f5aba756885a6c98da601d73807fd77eca95e0143623b77")
