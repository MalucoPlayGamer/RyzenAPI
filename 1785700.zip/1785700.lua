-- Lua provided by RyzenAPI
-- Game: 1785700

-- MAIN APPLICATION
addappid(1785700)
-- Game: addappid(1785700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785701, 1, "936c359ec9a2a7fd7ce9867e12eb57fe95b6e6a3ddd848add5c4accdcff76cb3")
