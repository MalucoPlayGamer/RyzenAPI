-- Lua provided by RyzenAPI
-- Game: Girls Gym

-- MAIN APPLICATION
addappid(1785700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1785701, 1, "936c359ec9a2a7fd7ce9867e12eb57fe95b6e6a3ddd848add5c4accdcff76cb3")
