-- Lua provided by RyzenAPI
-- Game: Miami Hotel Simulator Prologue

-- MAIN APPLICATION
addappid(1967700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1967701, 1, "e43626b3dfbf4c93e472adafa3e15407dab156e97d55ba65aeb7699bb1d2495c")

