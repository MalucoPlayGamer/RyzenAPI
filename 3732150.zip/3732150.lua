-- Lua provided by RyzenAPI
-- Game: Game: Koro-san's Home "WAN!" Derby

-- MAIN APPLICATION
addappid(3732150)
-- Game: addappid(3732150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3732151, 1, "9d006fcdd716053f50b368e10c13bd97ab15fee1d59c96818c4ea30ef3371474")
