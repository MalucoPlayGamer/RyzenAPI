-- Lua provided by SkyAPI 
-- Game: Palpus X Annihilation Demo
addappid(3328240)
addappid(3328241, 1, "14e43f5bea1409c00b36b6aef2d6719e7a525465d2fbf864edffa565f4e5ba3f")
