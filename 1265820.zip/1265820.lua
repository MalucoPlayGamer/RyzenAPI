-- Lua provided by RyzenAPI
-- Game: Fights in Tight Spaces

-- MAIN APPLICATION
addappid(1265820)
addappid(1867120)
addappid(3625850)
addappid(4091260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265821, 1, "38d39b5180e5d5c1270d55c4463569ffec11367b0639340f60f26a64da69097e")

