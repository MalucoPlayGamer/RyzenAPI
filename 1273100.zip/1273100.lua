-- Lua provided by RyzenAPI
-- Game: 1273100

-- MAIN APPLICATION
addappid(1273100)
-- Game: addappid(1273100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273101, 1, "19dd335f920366c7d50f6fb8c944c7733dea3c4c95d749a6405c36941465f7fa")
