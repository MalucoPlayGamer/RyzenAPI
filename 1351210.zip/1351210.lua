-- Lua provided by RyzenAPI
-- Game: Gord

-- MAIN APPLICATION
addappid(1351210)
addappid(2313790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1351211, 1, "fb427b05dabcb95be7cedb9356751a93e4d2d3508b3026688f95b9c841c08d0b")
addappid(2102280, 0, "887b0662ef5ce38ca0ee193e75b0fa2e968cdbfef883478c356a463371f0e483")
addappid(2465680, 0, "e8855a43afd082277199eb76cc09e6faeb9c0265f89902f4cea01ea38585c751")
addappid(2543600, 0, "386b17f1c5aa1edf92c72dc157bf7fda813717c60784f27105e2852b82c5a086")

