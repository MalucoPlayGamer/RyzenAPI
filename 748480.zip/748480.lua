-- Lua provided by RyzenAPI 
-- Game: Wild Romance: Mofu Mofu Edition
addappid(748480)
addappid(748481, 1, "f61ac6efc9268c9091fdaa000fd9e7cfa6e43f9a733521db24cdf7373633a67b")
addappid(1035150, 0, "24958dde768fbaf7a0b2c0e74d3d311915c8ad825979b3090c8d87b487bb5d99")
