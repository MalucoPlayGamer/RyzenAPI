-- Lua provided by RyzenAPI
-- Game: Voodoo Detective

-- MAIN APPLICATION
addappid(1740680)
-- Game: addappid(1740680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740682,0,"d5c83f68d1963c60bf588d18db06c11ed213f403b0ce9dd7bfb4aa621e72d038")
addappid(1740683,0,"bef6a666e0d693c06158e5ef9f708a457afa420f0214bc653857e1d84fdb8398")
addappid(1740684,0,"2b86ee9962a54ea2798e63694f536fa284adfd13e361114de723ec4f81b87b16")
