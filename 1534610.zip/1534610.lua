-- Lua provided by RyzenAPI
-- Game: 1534610

-- MAIN APPLICATION
addappid(1534610)
-- Game: addappid(1534610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534611, 1, "d6bc323ef927a23646b2b0bfbc598fbc524c9ca2d1789a66a70d44729ff502e5")
