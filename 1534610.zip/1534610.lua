-- Lua provided by RyzenAPI
-- Game: ZombiesWaves

-- MAIN APPLICATION
addappid(1534610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1534611, 1, "d6bc323ef927a23646b2b0bfbc598fbc524c9ca2d1789a66a70d44729ff502e5")
