-- Lua provided by RyzenAPI
-- Game: addappid(2080690)

-- MAIN APPLICATION
addappid(2080690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080691, 1, "4f31da14ac6d847cb27d02bc14da0ddf076b9499bdc36aa391ced18c08788547")
