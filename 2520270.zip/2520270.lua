-- Lua provided by RyzenAPI
-- Game: Space industrial empire：The giants of deep space

-- MAIN APPLICATION
addappid(2520270)
-- Game: addappid(2520270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520270,0,"9d3c073b1ac81669ede911bcfbd521e5f17036b4c37196a1425a79f21dec7037")
