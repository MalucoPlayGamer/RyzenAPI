-- Lua provided by RyzenAPI
-- Game: Move or Die

-- MAIN APPLICATION
addappid(323850)
addappid(1667930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(323851, 1, "8bbd44add7af77c91ae5be0f10a8b8241942806486c18c0e19452122fd62244e")
addappid(323852, 1, "31d8c9df5c0e275bbf52919e5c0048a88dac06f6e7d9f7547e9c1c50fd8a712b")

