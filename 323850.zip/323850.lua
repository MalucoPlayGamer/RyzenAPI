-- Lua provided by RyzenAPI
-- Game: AppID 323850

-- MAIN APPLICATION
addappid(323850)
-- Game: addappid(323850)

-- MAIN APP DEPOTS / PACKAGES
addappid(323851, 1, "8bbd44add7af77c91ae5be0f10a8b8241942806486c18c0e19452122fd62244e")
addappid(323852, 1, "31d8c9df5c0e275bbf52919e5c0048a88dac06f6e7d9f7547e9c1c50fd8a712b")
