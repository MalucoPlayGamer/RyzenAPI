-- Lua provided by RyzenAPI
-- Game: Game: AppID 1960420

-- MAIN APPLICATION
addappid(1960420)
-- Game: addappid(1960420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960421, 1, "71f810bee582e09bad4c0d6a8487e6c14134315823f936c0d1e6411170bd569b")
