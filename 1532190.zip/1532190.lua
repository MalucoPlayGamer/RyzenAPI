-- Lua provided by SkyAPI 
-- Game: Halo: CE Mod Tools - MCC
addappid(1532190)
addappid(1532191, 1, "d63c4c1e7138ba8948915be87f0cd1a6c20107589bec58b1dbf2f5fc3005799d")
