-- Lua provided by RyzenAPI
-- Game: addappid(1532190)

-- MAIN APPLICATION
addappid(1532190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532191, 1, "d63c4c1e7138ba8948915be87f0cd1a6c20107589bec58b1dbf2f5fc3005799d")
