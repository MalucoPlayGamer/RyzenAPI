-- Lua provided by RyzenAPI
-- Game: HopBound

-- MAIN APPLICATION
addappid(1332890)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1332891, 1, "cc876cc34254e5270440d4bf3f9c60408234a44804525296515663541077e26d")

