-- Lua provided by RyzenAPI
-- Game: Game: HopBound

-- MAIN APPLICATION
addappid(1332890)
-- Game: addappid(1332890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332891, 1, "cc876cc34254e5270440d4bf3f9c60408234a44804525296515663541077e26d")
