-- Lua provided by RyzenAPI
-- Game: Yet Another Killing Game - Original Soundtrack

-- MAIN APPLICATION
addappid(3735940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3735941, 1, "c329f48c2c0dbee48f981c1ddb610c8beb3df7e69d7f4f34dc50bc6917f09fe9")
addappid(3735942, 1, "2e6b80158e743e3098e5dfa60c1fe4e4f629f10f3cc587a89f939ab92fd7417c")
