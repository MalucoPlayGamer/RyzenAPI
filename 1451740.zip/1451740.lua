-- Lua provided by RyzenAPI
-- Game: Children of Silentown: Prologue

-- MAIN APPLICATION
addappid(1451740)

