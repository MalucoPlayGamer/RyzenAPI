-- Lua provided by RyzenAPI 
-- Game: MEATGRINDER
addappid(1968710)
addappid(1968711, 1, "e431d4e11ace7b06e2a9833c1111b6afc283a518f423435b91bafcd0e53f974e")
