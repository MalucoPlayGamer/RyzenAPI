-- Lua provided by RyzenAPI
-- Game: Game: Paper Bride 3 Unresolved Love

-- MAIN APPLICATION
addappid(1939790)
-- Game: addappid(1939790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939791, 1, "7de0aae77c62ef479e8b577947fc7456f4463c385e974d8a3f5ea9bb933580a4")
addappid(1939792, 1, "ab79e4ba8e7101a54a4b7c5460d4a492222e01514ea8d551e2ffec128734afce")
addappid(1939793, 1, "8ab10d18cc5e676144d619c03fece0121396d3e528db6e31e01d9c6068ced6ce")
addappid(2144700, 0, "212ee8551f9ba98b74155ccd2bb6648a1c8fcd454650eecede6a9862e4003b23")
addappid(2144710, 0, "e16400d3b44b76110b075670d0520d1895064a22a6f2e299dcef6136f46ad13a")
