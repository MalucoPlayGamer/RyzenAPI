-- Lua provided by RyzenAPI
-- Game: Deep Sea Pursuit

-- MAIN APPLICATION
addappid(3192540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192541, 1, "de4da02b2630fe766e4d120abe41696238231ee0e1cec19853a6b45d3cd659e0")

