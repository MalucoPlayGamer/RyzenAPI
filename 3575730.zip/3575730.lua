-- Lua provided by RyzenAPI
-- Game: AppID 3575730

-- MAIN APPLICATION
addappid(3575730)
-- Game: addappid(3575730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575731, 1, "d9ccb17579ba7b57f7e263a7edbd4771237b42aa93b25e92dc7b8f02bc202898")
