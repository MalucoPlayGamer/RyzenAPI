-- Lua provided by RyzenAPI
-- Game: -- R.A.T.: Human Error

-- MAIN APPLICATION
addappid(3814370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3814371, 1, "09292cb3e4a4eb071c4f26042e7c6f5e4a6c102bc7d72f09418e2b87a7cb94db")

