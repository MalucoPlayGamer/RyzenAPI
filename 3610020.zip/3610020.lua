-- Lua provided by RyzenAPI
-- Game: addappid(3610020)

-- MAIN APPLICATION
addappid(3610020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3610021, 1, "cce13dfe6413104534b5ed5fe171ec61e83c3d507b6d4820c932e5147a2d873c")
