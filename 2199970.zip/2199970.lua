-- Lua provided by RyzenAPI
-- Game: addappid(2199970)

-- MAIN APPLICATION
addappid(2199970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199972,0,"791468b7026d555abe4ade4f3325f2bab2ef12d8736c3cb46c03cf3ea11ec942")
