-- Lua provided by RyzenAPI
-- Game: V-Skin

-- MAIN APPLICATION
addappid(1759650)
addappid(1873460)
addappid(1873470)
addappid(1873590)
addappid(1873620)
addappid(1873630)
addappid(1873640)
addappid(1873650)
addappid(1873660)
addappid(1884280)
addappid(1976600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759651, 1, "9f647b2ae5ae8c333b5212f3ac0259f65eb9a7063efe10a6ed5ef693d5f52a83")
addappid(1759652, 1, "c66cede6034dc0e5bcc33ab1281af14b7d446cd3c4864c9463e394de6da9df49")

