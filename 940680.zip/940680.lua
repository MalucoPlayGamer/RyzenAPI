-- Lua provided by RyzenAPI
-- Game: The Textorcist: The Story of Ray Bibbia

-- MAIN APPLICATION
addappid(940680)
addappid(1906170)

-- MAIN APP DEPOTS / PACKAGES
addappid(940681,0,"78153a71c36cde83962b20dccc1f1d6ff6461a57211c414da56654f8ce7c4fe2")
addappid(940682,0,"3eb7bd1f87154b7a5d2b6c800bd43bad9b2be8597dd2bce4a97bec6bf6fc38ab")
addappid(940683,0,"a0d1ce2b094fcdc67c376fe694f7386fc4e7cac631ce5fa85961b2dc85010bea")

