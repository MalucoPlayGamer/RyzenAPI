-- Lua provided by RyzenAPI
-- Game: The Textorcist: The Story of Ray Bibbia

-- MAIN APPLICATION
addappid(940680)

-- MAIN APP DEPOTS / PACKAGES
addappid(940681, 1, "78153a71c36cde83962b20dccc1f1d6ff6461a57211c414da56654f8ce7c4fe2")
addappid(940682, 1, "3eb7bd1f87154b7a5d2b6c800bd43bad9b2be8597dd2bce4a97bec6bf6fc38ab")

