-- Lua provided by SkyAPI 
-- Game: Love is All Around: Echoes of Yesterday
addappid(3099660)
addappid(3099661, 1, "8307ffd73510ab48dec77577266458532f5d90033565f1234fedc768ceef12e4")
addappid(3099662, 1, "e0b56e1d2f42b2742e5c77cb4cfc5cc56cb1a774b4612aee8919d88582b10ff4")
addappid(3228000)
