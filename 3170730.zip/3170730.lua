-- Lua provided by RyzenAPI
-- Game: Slay or Fall

-- MAIN APPLICATION
addappid(3170730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170731, 1, "286f0ddb5e0ed5b62a2f18694688407dc146712632fbfa205e22cc72a01f98c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
