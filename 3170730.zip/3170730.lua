-- Lua provided by RyzenAPI
-- Game: 3170730

-- MAIN APPLICATION
addappid(3170730)
-- Game: addappid(3170730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170731, 1, "286f0ddb5e0ed5b62a2f18694688407dc146712632fbfa205e22cc72a01f98c9")
