-- Lua provided by RyzenAPI
-- Game: 816990

-- MAIN APPLICATION
addappid(816990)
-- Game: addappid(816990)

-- MAIN APP DEPOTS / PACKAGES
addappid(816991, 1, "497572fdd0f7b008c6d83cc46312a2ccdfd719470fbfaefc06f1f5341be9b340")
