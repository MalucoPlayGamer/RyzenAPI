-- Lua provided by RyzenAPI
-- Game: The Odyssey

-- MAIN APPLICATION
addappid(516560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(516561, 1, "09cdce310f958ad370891ea4f78d73b9d2e2e67e94c38c2844c21249df9f60cc")
addappid(516562, 1, "f0a1790c20b1f1a857255ddfb2d318c5c354242a70fb68ec9dcedece8844e38b")
addappid(516563, 1, "3e9d364ae369412a4ff8f937febb39ad18fe51d63b0c696af65aeeaccd79a98f")
