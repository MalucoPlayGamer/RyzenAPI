-- Lua provided by RyzenAPI
-- Game: AppID 516560

-- MAIN APPLICATION
addappid(516560)

-- MAIN APP DEPOTS / PACKAGES
addappid(516561, 1, "09cdce310f958ad370891ea4f78d73b9d2e2e67e94c38c2844c21249df9f60cc")
addappid(516562, 1, "f0a1790c20b1f1a857255ddfb2d318c5c354242a70fb68ec9dcedece8844e38b")
addappid(516563, 1, "3e9d364ae369412a4ff8f937febb39ad18fe51d63b0c696af65aeeaccd79a98f")

