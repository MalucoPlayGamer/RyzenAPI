-- Lua provided by RyzenAPI
-- Game: Cossacks 3

-- MAIN APPLICATION
addappid(333420)
addappid(523011)
addappid(523014)
addappid(565040)
addappid(615380)
addappid(630890)
addappid(694190)

-- MAIN APP DEPOTS / PACKAGES
addappid(333421, 1, "123897c8a4194681e90531b3210e69ae64b882ebcd01168565bf4bd8f7474d0e")
addappid(333422, 1, "5be0e65047ed02be128f1a3a9a3a869e92248de85a3b2b61a1a27abab6679dce")
addappid(333425, 1, "70d01ee9ffd7ff06dd42725deed893bacfb6196e50a49c88ddaee5234f0cb1ea")
addappid(333426, 1, "7c7c181ea62b7d0a80185bc48e9849610947e415acb37553717391c1b1a3284b")
addappid(333427, 1, "29a2788d4a6ee5196c8eec28989af551e6144fe4a4683b7b3ccef6b33abd7dff")
addappid(333428, 1, "cfca06248f0b4660be7ca33beb443ecd4409a6a5856c58f67d6b4c5e5c57eeb6")
addappid(523012, 0, "f9a77ced0f9d331e744a65701245912428479acb806ba7598d1f5f4a76cd6d1d")
addappid(523013, 0, "f5943d6e27ae0fe49ef5d375a764c0c4d5651eb2e3e566b0105729ea72ffb2e8")
addappid(523015, 0, "a8ddb515260b5bf7959d0f14373db13fc374c8d453bd7e46987fc5d4069ad43b")
addappid(523016, 0, "f6603f030c30b4dff8378f4d9d7653837660c04957adca8f71073f7b185a071a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(523010)
addappid(586910)
addappid(650290)
addappid(650291)
addappid(650360)
