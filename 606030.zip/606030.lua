-- Lua provided by RyzenAPI
-- Game: AppID 606030

-- MAIN APPLICATION
addappid(606030)

-- MAIN APP DEPOTS / PACKAGES
addappid(606031, 1, "bd8e52b6a5bca83df9a31ef3059de05761ad90b55563ebfa080129533a741c8a")
