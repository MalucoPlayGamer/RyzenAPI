-- Lua provided by RyzenAPI
-- Game: 838340

-- MAIN APPLICATION
addappid(838340)
-- Game: addappid(838340)

-- MAIN APP DEPOTS / PACKAGES
addappid(838341, 1, "7e9efb5ac7f7f78daf8f1e325f5a0ca80ebe9128cde3cab95bab8573e190ce4f")
