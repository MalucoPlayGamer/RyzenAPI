-- Lua provided by RyzenAPI
-- Game: Game: Duskers

-- MAIN APPLICATION
addappid(254320)
-- Game: addappid(254320)

-- MAIN APP DEPOTS / PACKAGES
addappid(254321, 1, "37f60f1c2bcfd343cff4d68b405e614439d4c842198a4372b7daf1de48be776a")
addappid(254322, 1, "418da610b7c832734112da9c924ec212e43796ca623636e4b0e0e11fa303925a")
addappid(254323, 1, "144341c30058e758d40d2f87fc34ba118d85cfa4fc44efce9722d9875d1402fd")
