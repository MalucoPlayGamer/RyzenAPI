-- Lua provided by RyzenAPI 
-- Game: AppID 1123610
addappid(1123610)
addappid(1123611, 1, "731abe43b0b73156a7b8f1f0230c338bb56e1a919512c82df9286c81a5673057")
