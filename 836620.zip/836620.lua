-- Lua provided by RyzenAPI
-- Game: Game: AppID 836620

-- MAIN APPLICATION
addappid(836620)
-- Game: addappid(836620)

-- MAIN APP DEPOTS / PACKAGES
addappid(836621, 1, "516084eba4e62dcb5ebbbf9930ce30c5df95d67ccbe464e2a1c265eb16f37b68")
addappid(836624, 1, "81ff8bb1ea59dedc6c3c6799239477bf603397fa39a0a8230902eaa62f9e3b9a")
addappid(836625, 1, "d756219c7f1071f777d7de835827516fe2051cf88e845587fa8e87151a44a465")
