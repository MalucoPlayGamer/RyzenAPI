-- Lua provided by RyzenAPI
-- Game: addappid(1267591)

-- MAIN APPLICATION
addappid(1267591)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267591,0,"de0d39aee1dde8aac67b6db5304d3f5517765a36aeff270e6de6e0f43e2fa735")
