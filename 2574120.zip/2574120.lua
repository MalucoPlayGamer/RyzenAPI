-- Lua provided by RyzenAPI 
-- Game: AppID 2574120
addappid(2574120)
addappid(2574121, 1, "3bfdf62cfd49ec5628068e198f620f952d4ab1bf304fcff4ad74eb443743736f")
