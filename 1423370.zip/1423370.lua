-- Lua provided by SkyAPI 
-- Game: NOeSIS02_羽化
addappid(1423370)
addappid(1423371, 1, "e8c2220166f46ff9683c15bf7a8fdcb7cfedc97f1c2e2fd77b06fe05acc589d5")
addappid(1423372, 1, "d8c42c99fbbd58cce875046ec270e64924949438d08902325ef9684c75b6e5d4")
addappid(1423373, 1, "7c70a5c549f8d3cdd56d9d64442f486560bad11419d5e42ab7685606a05b4d6a")
