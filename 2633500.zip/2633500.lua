-- Lua provided by RyzenAPI
-- Game: addappid(2633500)

-- MAIN APPLICATION
addappid(2633500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633501, 1, "81aee4b92306ea6a6bc33144f79851878a1c8ad50565beadbefebdce82ea0266")
addappid(2633502, 1, "a9d6a87cb64bfe9644e586abb5aed868ac69eef6f5d36250c8bf8d3826c16be3")
