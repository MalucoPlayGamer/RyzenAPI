-- Lua provided by RyzenAPI
-- Game: DeoVR - VR Video Streaming Platform

-- MAIN APPLICATION
addappid(837380)
-- Game: addappid(837380)

-- MAIN APP DEPOTS / PACKAGES
addappid(837381, 1, "eaf86086f6ea244be81f2dc201b12bfe9eb80fa33eac5f66802946942e72c488")
