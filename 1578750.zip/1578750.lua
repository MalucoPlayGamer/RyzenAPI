-- Lua provided by RyzenAPI
-- Game: Endless Furry Asteroids

-- MAIN APPLICATION
addappid(1578750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578751, 1, "6eb0dffe2bc696899446c7e40af27729476bdb4065de698eb3dbb3bb5d531675")

