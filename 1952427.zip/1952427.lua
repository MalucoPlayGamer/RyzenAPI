-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin ModemCity Pack

-- MAIN APPLICATION
addappid(1952427)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952427,0,"2bb9d7df4844ed25eafaeb55833485a8039f5c9dd1f407d8480bbceec646541f")

