-- Lua provided by RyzenAPI
-- Game: 1840100

-- MAIN APPLICATION
addappid(1840100)
-- Game: addappid(1840100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840101, 1, "ec9f41b39ba3adc4626303954ae8bb803d459188b580faf176551c8be3416f84")
