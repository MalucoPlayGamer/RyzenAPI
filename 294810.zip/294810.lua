-- Lua provided by RyzenAPI
-- Game: 294810

-- MAIN APPLICATION
addappid(294810)
addappid(333460)
-- Game: addappid(294810)

-- MAIN APP DEPOTS / PACKAGES
addappid(294811, 1, "767663dce289d4b9e78e5421b30ac5407e4fd3e5d1ccd448ef161cf96467f4b8")
