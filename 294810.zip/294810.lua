-- Lua provided by RyzenAPI
-- Game: BlazBlue: Continuum Shift Extend

-- MAIN APPLICATION
addappid(294810)
addappid(333460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(294811, 1, "767663dce289d4b9e78e5421b30ac5407e4fd3e5d1ccd448ef161cf96467f4b8")

