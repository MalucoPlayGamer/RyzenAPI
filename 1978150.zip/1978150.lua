-- Lua provided by RyzenAPI
-- Game: Kamaeru: A Frog Refuge

-- MAIN APPLICATION
addappid(1978150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978151, 1, "c9db1dc880a00cdaab75ec0353eb3eec407d5f587ca930656578fbb33ac1f2a0")
