-- Lua provided by RyzenAPI
-- Game: Game: 九劫曲：诅咒之地 NINE TRIALS

-- MAIN APPLICATION
addappid(976800)
-- Game: addappid(976800)

-- MAIN APP DEPOTS / PACKAGES
addappid(976801, 1, "e5473c1253917a867755672a7c3ba88181ba9fa5a2e8637e027083efc0330f4f")
