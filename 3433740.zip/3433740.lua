-- Lua provided by RyzenAPI
-- Game: Dominated By: Sadistic Roommate

-- MAIN APPLICATION
addappid(3433740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3433743,0,"6efecf52582fc340a839051e96e3d227b994de843334d948f612d4133e67249e")
