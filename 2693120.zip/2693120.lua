-- Lua provided by RyzenAPI
-- Game: addappid(2693120)

-- MAIN APPLICATION
addappid(2693120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693121, 1, "3e00d53fe5807fe0422bde437a73aa62eceefbe22ec94f04f1847df13c780ce2")
