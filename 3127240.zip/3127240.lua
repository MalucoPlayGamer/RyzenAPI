-- Lua provided by RyzenAPI
-- Game: Seeing Red

-- MAIN APPLICATION
addappid(3127240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127241, 1, "72104ecee2f3481c44963894a92ec7187db62e2a27116f59432e43c8652180cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
