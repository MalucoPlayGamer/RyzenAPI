-- Lua provided by RyzenAPI
-- Game: Seeing Red

-- MAIN APPLICATION
addappid(3127240)
-- Game: addappid(3127240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127241, 1, "72104ecee2f3481c44963894a92ec7187db62e2a27116f59432e43c8652180cd")
