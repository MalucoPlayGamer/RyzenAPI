-- Lua provided by RyzenAPI
-- Game: The Movie Trivia Challenge

-- MAIN APPLICATION
addappid(875790)

-- MAIN APP DEPOTS / PACKAGES
addappid(875791,0,"aef95f6c07a2228ff67497d191a1bae0745a221bb2354d4be138ba0dadea9bf3")

