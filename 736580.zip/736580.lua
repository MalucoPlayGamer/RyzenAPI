-- Lua provided by RyzenAPI
-- Game: addappid(736580)

-- MAIN APPLICATION
addappid(736580)

-- MAIN APP DEPOTS / PACKAGES
addappid(736580,0,"49c3304c2363184564ac42b0d51ab3dfe18bd0df8bc5f01b29e02c4834eb3866")
