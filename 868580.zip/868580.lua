-- Lua provided by RyzenAPI
-- Game: Arkhangel: The House of the Seven Stars

-- MAIN APPLICATION
addappid(868580)

-- MAIN APP DEPOTS / PACKAGES
addappid(868581, 1, "9d673998ed4bc1524a2f7e74064abdc9180e7fd93a04c6f3b0d6b59c59a19894")
addappid(868582, 1, "420f9f089aece0b472d23ef5f5cb9476c8071601c5ecef5f89c9551dab205fc8")
addappid(868584, 1, "2dda4c1773777bd32254fd0329d57aa220b4291a2de12f86c21e4a4cae7f8033")
addappid(868585, 1, "1aaa193d5b3621c28551bec6fc6ccdd902cbd54f725b3c00982cf2f20e366426")

