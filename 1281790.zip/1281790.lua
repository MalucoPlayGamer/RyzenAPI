-- Lua provided by RyzenAPI
-- Game: SHEEPO

-- MAIN APPLICATION
addappid(1281790)
-- Game: addappid(1281790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281791, 1, "abe7ba9141ebcf20c270101e78c0b2833bd41aa39a742232405057688c1d8148")
