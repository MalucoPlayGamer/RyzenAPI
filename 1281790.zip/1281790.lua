-- Lua provided by RyzenAPI 
-- Game: SHEEPO
addappid(1281790)
addappid(1281791, 1, "abe7ba9141ebcf20c270101e78c0b2833bd41aa39a742232405057688c1d8148")
