-- Lua provided by SkyAPI 
-- Game: Into The Core
addappid(1081160)
addappid(1081161, 1, "49b2369340ff1b38247eb8e90523d89ed919ac88c6b96938b6054d41d344dba4")
