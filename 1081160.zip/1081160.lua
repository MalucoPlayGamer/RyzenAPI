-- Lua provided by RyzenAPI
-- Game: Into The Core

-- MAIN APPLICATION
addappid(1081160)
-- Game: addappid(1081160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081161, 1, "49b2369340ff1b38247eb8e90523d89ed919ac88c6b96938b6054d41d344dba4")
