-- Lua provided by RyzenAPI
-- Game: Into The Core

-- MAIN APPLICATION
addappid(1081160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081161, 1, "49b2369340ff1b38247eb8e90523d89ed919ac88c6b96938b6054d41d344dba4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
