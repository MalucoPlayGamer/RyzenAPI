-- Lua provided by RyzenAPI
-- Game: About a Boy

-- MAIN APPLICATION
addappid(3768660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3768661, 1, "1498f13f9a7c443b6d74359a761c71f8519065e32f559a9f22cd518342da03b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
