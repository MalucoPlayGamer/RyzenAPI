-- Lua provided by RyzenAPI
-- Game: About a Boy

-- MAIN APPLICATION
addappid(3768660)
-- Game: addappid(3768660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3768661, 1, "1498f13f9a7c443b6d74359a761c71f8519065e32f559a9f22cd518342da03b0")
