-- Lua provided by SkyAPI 
-- Game: AppID 224280
addappid(224280)
addappid(224281, 1, "ab981b3e9ba0cd7b32da28287a7b97d7dbe4c1c932a74f151b8c6e00b7ee3b47")
