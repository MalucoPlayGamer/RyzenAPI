-- Lua provided by RyzenAPI
-- Game: Skill Legends Royale Demo

-- MAIN APPLICATION
addappid(3164420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164421, 1, "4add4cd81c15e55bbc2bd00ef8bc0088c4f96df1749911b8fe21f3b9ce2622e5")
