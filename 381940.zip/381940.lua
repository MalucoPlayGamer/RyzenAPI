-- Lua provided by RyzenAPI
-- Game: Game: AppID 381940

-- MAIN APPLICATION
addappid(381940)
-- Game: addappid(381940)

-- MAIN APP DEPOTS / PACKAGES
addappid(381941, 1, "a0d397dc73984dc34132cf81c17e974751a3642b19955db6b2de1ff5a6e615cc")
