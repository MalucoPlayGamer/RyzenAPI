-- Lua provided by RyzenAPI
-- Game: RetroArch - XRick

-- MAIN APPLICATION
addappid(1227465)
-- Game: addappid(1227465)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227465,0,"6e9cbde9e7ca4b1ed2e5ac73f937f461556ba4f15a36bf790cb8668faf066d8a")
addappid(1789900,0,"92c0f90ba07ce4415feadd14e0769fac07850f88167bb581191f6f20cfdb23e5")
addappid(1789901,0,"a1768458f021462fdc91e5dd95121e38be634ffc844e6b1afdcfad69077cbf23")
