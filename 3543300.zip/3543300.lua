-- 3543300's Lua and Manifest Created by Hubcap Manifest
-- Medic Mayhem
-- Created: August 21, 2026 at 22:33:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3543300) -- Medic Mayhem
-- MAIN APP DEPOTS
addappid(3543302, 1, "22b9b9442023e6e4135547a6066cb99170879decd46360903e4edf40c3a4be18") -- Depot 3543302
setManifestid(3543302, "8557796881687755492", 767801672)
addappid(3543303, 1, "896d5a043367f6c3fa19bd1ddd2b58e34a145ce7c01b3cfc3bca258f9733b46b") -- Depot 3543303
setManifestid(3543303, "6020513887885475359", 732725088)