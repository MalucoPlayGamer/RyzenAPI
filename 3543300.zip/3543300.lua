-- Lua provided by RyzenAPI
-- Game: Medic Mayhem

-- MAIN APPLICATION
addappid(3543300) -- Medic Mayhem

-- MAIN APP DEPOTS / PACKAGES
addappid(3543302, 1, "22b9b9442023e6e4135547a6066cb99170879decd46360903e4edf40c3a4be18") -- Depot 3543302
addappid(3543303, 1, "896d5a043367f6c3fa19bd1ddd2b58e34a145ce7c01b3cfc3bca258f9733b46b") -- Depot 3543303

