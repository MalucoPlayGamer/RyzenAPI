-- Lua provided by RyzenAPI
-- Game: Rubinite Demo

-- MAIN APPLICATION
addappid(2320010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320011, 1, "a6ce4d7c54cb5755b8dc7a19fcc229847c10a0aba650fa85027ab44dcefb1395")

