-- Lua provided by SkyAPI 
-- Game: AppID 1285040
addappid(1285040)
addappid(1285041, 1, "3f3239bf0c5887309001d9ee426345a03528cf1f84b3e6067b468eafecb45498")
addappid(1285042, 1, "4021ba3e3c0fdb9e8d3199890c1cd457e007e891bfbc83dd25c1f3331a411eb0")
