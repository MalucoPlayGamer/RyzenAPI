-- Lua provided by RyzenAPI
-- Game: AppID 1285040

-- MAIN APPLICATION
addappid(1285040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285041, 1, "3f3239bf0c5887309001d9ee426345a03528cf1f84b3e6067b468eafecb45498")
addappid(1285042, 1, "4021ba3e3c0fdb9e8d3199890c1cd457e007e891bfbc83dd25c1f3331a411eb0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1899330)
