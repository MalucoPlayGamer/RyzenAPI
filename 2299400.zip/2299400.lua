-- Lua provided by RyzenAPI 
-- Game: Aquascapers
addappid(2299400)
addappid(2299401, 1, "b6193b2740c186ea303a5c84f0c5cb89eb3b66adaaeae1b46cac8f805efe5d0a")
