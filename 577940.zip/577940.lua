-- Lua provided by RyzenAPI
-- Game: AppID 577940

-- MAIN APPLICATION
addappid(577940)
addappid(2625580)

-- MAIN APP DEPOTS / PACKAGES
addappid(577941, 1, "369c2eb2f233f274457b6a59f16d4caf8e4bd979815beecc1406415d0486fe5a")
