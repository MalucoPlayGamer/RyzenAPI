-- Lua provided by RyzenAPI
-- Game: Dumbz Snake

-- MAIN APPLICATION
addappid(3126890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126892,0,"790cccac089026555b640c3bcd0e2fad49884b200d7d47b18a0613e638ba5432")
