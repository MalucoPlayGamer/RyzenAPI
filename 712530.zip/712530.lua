-- Lua provided by RyzenAPI
-- Game: AppID 712530

-- MAIN APPLICATION
addappid(712530)

-- MAIN APP DEPOTS / PACKAGES
addappid(712531, 1, "7f86d4535f3c6fed0e11a6ca9ea2c9cfe9274bbb25b03c074bf4096b8f8e0202")

