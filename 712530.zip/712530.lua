-- Lua provided by RyzenAPI
-- Game: AppID 712530

-- MAIN APPLICATION
addappid(712530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(712531, 1, "7f86d4535f3c6fed0e11a6ca9ea2c9cfe9274bbb25b03c074bf4096b8f8e0202")

