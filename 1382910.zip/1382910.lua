-- Lua provided by RyzenAPI
-- Game: Hell Architect: Prologue

-- MAIN APPLICATION
addappid(1382910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382911, 1, "212512f068c0b37178ebad84e72fa52d39f27b9470d3a96185f033a7b8f3cfb7")
