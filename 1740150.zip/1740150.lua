-- Lua provided by RyzenAPI 
-- Game: A.W.O.L.
addappid(1740150)
addappid(1740151, 1, "ada7866e6786b8483961cbef230be15f2ab24464d1072671d76ff670d8f238dc")
addappid(1740152, 1, "8abedcada32e7edc00ca4e3154e10a9faff3d7e10540c0b7c33ca79556f36421")
