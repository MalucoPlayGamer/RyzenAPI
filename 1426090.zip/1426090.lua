-- Lua provided by RyzenAPI 
-- Game: My Yandere Sister loves me too much!
addappid(1426090)
addappid(1426091, 1, "1bda40da75f5af72d4e96c47fd3216d3f63ac3ea1bbd8c3c1b9f1b160f498b4c")
