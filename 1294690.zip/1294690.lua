-- Lua provided by RyzenAPI
-- Game: Game: AppID 1294690

-- MAIN APPLICATION
addappid(1294690)
-- Game: addappid(1294690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1294691, 1, "ca5b2eb6325244a66b1ef8fc2e973fe2d2b12e9c23c1cb31c1fb0fe202a2fbbb")
addappid(1294692, 1, "3266814f6f487da635a7f004e4ce61333f4b044a9028683d7e09b1bfdd53ab93")
