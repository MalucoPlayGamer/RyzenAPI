-- Lua provided by RyzenAPI
-- Game: Suspense: Madman's Dreams

-- MAIN APPLICATION
addappid(3395810)
-- Game: addappid(3395810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3395811, 1, "ad7cb6027f7abd27e0d6dd021d552a1122316ee1e1899127ae8b9d76bbbe79d8")
