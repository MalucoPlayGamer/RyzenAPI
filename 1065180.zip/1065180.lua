-- Lua provided by RyzenAPI
-- Game: Azure Striker Gunvolt 2

-- MAIN APPLICATION
addappid(1065180)
addappid(1224660)
addappid(1224661)
addappid(1224662)
addappid(1224663)
addappid(1224664)
addappid(1224665)
addappid(1224666)
addappid(1224667)
addappid(1224668)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065181, 1, "ac3c9d877d3b1fae2ffd2fb2564447d4cc88afd5da3249d2a3dbe9832cfff9e4")

