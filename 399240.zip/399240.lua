-- Lua provided by RyzenAPI
-- Game: AppID 399240

-- MAIN APPLICATION
addappid(399240)

-- MAIN APP DEPOTS / PACKAGES
addappid(399241, 1, "117a240bc5e278131a4e934cfd7fca4c86114017b76eade1761c6be5ceee2608")
