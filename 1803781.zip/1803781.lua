-- Lua provided by RyzenAPI
-- Game: Surviving the Aftermath: Forgotten Tracks

-- MAIN APPLICATION
addappid(1803781)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803781,0,"8aa528baef6e7d937b37b363bbf517520164111b94f8735594f6012361a6622e")
