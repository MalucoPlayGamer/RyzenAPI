-- Lua provided by RyzenAPI
-- Game: addappid(1105730)

-- MAIN APPLICATION
addappid(1105730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105731, 1, "3ab02641dba2cd489858b5056492ecb66a2511be46f4119b5555e588dae4d0a4")
