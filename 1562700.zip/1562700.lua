-- Lua provided by RyzenAPI
-- Game: addappid(1562700)

-- MAIN APPLICATION
addappid(1562700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562701, 1, "6a61d46843f44ec57cd9d72896f19e6ae976649dc0462ea6d9874ef8be703144")
