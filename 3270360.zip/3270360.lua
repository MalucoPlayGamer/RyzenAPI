-- Lua provided by RyzenAPI
-- Game: 3270360

-- MAIN APPLICATION
addappid(3270360)
-- Game: addappid(3270360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3270361, 1, "7011c9b7b48f7afdc5e5f8e019f31de1b619e52bfc6c7d44e0f5a42ac23adf83")
