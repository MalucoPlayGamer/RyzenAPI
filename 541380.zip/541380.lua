-- Lua provided by SkyAPI 
-- Game: AppID 541380
addappid(541380)
addappid(541381, 1, "858baf38418cc9423c52818be8aaab28fe2abcab022bd8cb9d899beb5729c3fb")
