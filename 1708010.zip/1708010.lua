-- Lua provided by RyzenAPI
-- Game: The Expanse: A Telltale Series

-- MAIN APPLICATION
addappid(1708010)
addappid(2632830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708011, 1, "6127007ca95c2bebc0f6debad6929012bd174633b0c1c755c7e0e2b2459a0ae6")

