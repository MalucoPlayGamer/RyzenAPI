-- Lua provided by RyzenAPI
-- Game: Yokai Art : Adult Content Patch

-- MAIN APPLICATION
addappid(2072470)
-- Game: addappid(2072470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072470,0,"23b865f9503a0a67865b872de0f2d1d86737a85c38cc551be031e076b70fad17")
