-- Lua provided by RyzenAPI
-- Game: Echoes of Vision

-- MAIN APPLICATION
addappid(4324040)
