-- Lua provided by SkyAPI 
-- Game: AppID 1230510
addappid(1230510)
addappid(1230511, 1, "08940c080a1d12bbe22899434095f2ee73643e330d34edc3b598f75118401e21")
