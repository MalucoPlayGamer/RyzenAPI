-- Lua provided by RyzenAPI
-- Game: AppID 1230510

-- MAIN APPLICATION
addappid(1230510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230511, 1, "08940c080a1d12bbe22899434095f2ee73643e330d34edc3b598f75118401e21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
