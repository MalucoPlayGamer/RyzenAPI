-- Lua provided by RyzenAPI 
-- Game: Format Converter Tsar
addappid(3686110)
addappid(3686111, 1, "c67f47eaa3be8dfd1d8a4fde63a429e68d196fbc10d1a7f3560bbc5fc0be91c2")
