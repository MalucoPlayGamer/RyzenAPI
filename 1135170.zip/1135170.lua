-- Lua provided by SkyAPI 
-- Game: AppID 1135170
addappid(1135170)
addappid(1135171, 1, "b2d60ad5f34e8f9131a4743960ddcc2e0bbf367fa2ac9c7bb8748836d79392e1")
addappid(1135172, 1, "86ec659889b85b80f73759c3d5a438cb5d23c374161fdf7c8ae3d6461336978f")
