-- Lua provided by RyzenAPI
-- Game: Sokpop S02: spider ponds

-- MAIN APPLICATION
addappid(1135170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135171, 1, "b2d60ad5f34e8f9131a4743960ddcc2e0bbf367fa2ac9c7bb8748836d79392e1")
addappid(1135172, 1, "86ec659889b85b80f73759c3d5a438cb5d23c374161fdf7c8ae3d6461336978f")
