-- Lua provided by RyzenAPI
-- Game: 流る星 -a wish star-

-- MAIN APPLICATION
addappid(3034450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034451, 1, "7edb092ca8a34fcf00626f1655dafbd68b0ef3c0d0874f102f839da70b88809b")
addappid(3034452, 1, "377ddde3a661209a218d8dabb34569df1599922a84ae7cb34651f539b1d2e66a")
