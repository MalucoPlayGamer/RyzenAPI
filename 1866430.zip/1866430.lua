-- Lua provided by RyzenAPI
-- Game: Rhapsody: A Musical Adventure

-- MAIN APPLICATION
addappid(1866430)
addappid(2071690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866431, 1, "dbcc9c2fe869b002fda394eae67a9508d0459cddb6dfaee79d720e48aa6e822b")

