-- Lua provided by RyzenAPI
-- Game: Rhapsody: A Musical Adventure

-- MAIN APPLICATION
addappid(1866430)
addappid(2071690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866431, 1, "dbcc9c2fe869b002fda394eae67a9508d0459cddb6dfaee79d720e48aa6e822b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
