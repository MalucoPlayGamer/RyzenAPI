-- Lua provided by RyzenAPI
-- Game: addappid(886160)

-- MAIN APPLICATION
addappid(886160)

-- MAIN APP DEPOTS / PACKAGES
addappid(886161, 1, "39bf2426b7d025406c340471b0d3f5c3ee663052dd79cbb47c47a07934d87f0b")
