-- Lua provided by RyzenAPI
-- Game: AppID 543770

-- MAIN APPLICATION
addappid(543770)
-- Game: addappid(543770)

-- MAIN APP DEPOTS / PACKAGES
addappid(543771, 1, "2ffe742b32a183e5b183d8cbb0dc58c497a3bf9c7fd368b7cc810115ba9396b4")
