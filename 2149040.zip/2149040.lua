-- Lua provided by RyzenAPI
-- Game: Game: Overboss Demo

-- MAIN APPLICATION
addappid(2149040)
-- Game: addappid(2149040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149041, 1, "69a198e9af3be834402c2afcb2ea06395e1354cca19d484242e2209ab99a01d2")
