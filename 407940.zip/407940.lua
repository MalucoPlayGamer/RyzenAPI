-- Lua provided by RyzenAPI
-- Game: Hyper Bounce Blast

-- MAIN APPLICATION
addappid(407940)

-- MAIN APP DEPOTS / PACKAGES
addappid(407941, 1, "e2e44cf637cf0b6dfe3c986779587c8c7e9bd907db63b07c16b48ab8030a4e7b")

