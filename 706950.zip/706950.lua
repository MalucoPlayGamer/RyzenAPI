-- Lua provided by RyzenAPI
-- Game: 706950

-- MAIN APPLICATION
addappid(706950)
-- Game: addappid(706950)

-- MAIN APP DEPOTS / PACKAGES
addappid(706951, 1, "c6568b2d1a53a8a0c157d0846e6cceca2854f0bff1f5a9668c02f6d8b688466b")
addappid(706952, 1, "30313b894dd1e11df891ad6e574772edbbf51c74072d8b3a7232a2dc4ba44822")
