-- Lua provided by RyzenAPI
-- Game: Operation Hardcore

-- MAIN APPLICATION
addappid(395550)
-- Game: addappid(395550)

-- MAIN APP DEPOTS / PACKAGES
addappid(395551, 1, "9e7ddfa785be2ba4a61fe6f31e9c8a8f6ba559388eb62db3d0be3564f42d6ba8")
