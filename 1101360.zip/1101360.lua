-- Lua provided by RyzenAPI
-- Game: Rock of Ages 3: Make & Break

-- MAIN APPLICATION
addappid(1101360)
addappid(1407701)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1101361, 1, "08c2115cb72dce24358deb8abe73e0aae1df9871b4a471fc8338619ed22be736")

