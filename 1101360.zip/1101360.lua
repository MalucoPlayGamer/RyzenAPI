-- Lua provided by RyzenAPI 
-- Game: AppID 1101360
addappid(1101360)
addappid(1101361, 1, "08c2115cb72dce24358deb8abe73e0aae1df9871b4a471fc8338619ed22be736")
