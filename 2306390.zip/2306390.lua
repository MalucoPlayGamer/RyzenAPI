-- Lua provided by RyzenAPI
-- Game: addappid(2306390)

-- MAIN APPLICATION
addappid(2306390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306391, 1, "039989a58fa43d9b94decb32954555254948ea7b2cfd80d7a03434f0f5f4585a")
