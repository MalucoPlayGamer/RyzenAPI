-- Lua provided by RyzenAPI
-- Game: addappid(1796870)

-- MAIN APPLICATION
addappid(1796870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796871, 1, "b058b77ca891a9c9dd5c556643e7441fa45c554c3c1ed682e623b211decf9641")
