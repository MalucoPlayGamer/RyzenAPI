-- Lua provided by RyzenAPI
-- Game: Slime-san: Sheeple’s Sequel

-- MAIN APPLICATION
addappid(228990)
addappid(766010)

-- MAIN APP DEPOTS / PACKAGES
addappid(766012,0,"accaa85194dec4b79c179892886c05c7e82ee588b198d825c3551f9777287f2b")
addappid(766013,0,"cca3c307e6c3ccf72c6edcdbfc65ef9aab11778efb6f8b4025199492e327f5f5")
addappid(766014,0,"b00d37c2a3f2bef0cf9528ae2f70fa76e1ddb038904f28fd7e21791cb2745dc9")
addappid(766015,0,"16984f330ad192398d6eb732805757cf664381b8f7168b2fe3c90df5719e68da")
