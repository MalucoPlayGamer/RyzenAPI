-- Lua provided by RyzenAPI
-- Game: Draw Slasher

-- MAIN APPLICATION
addappid(418270)

-- MAIN APP DEPOTS / PACKAGES
addappid(418271, 1, "fdb90a958409a150591f7687d4ed757abde6cfc1fec1ffb71478e50b32a7b52d")
addappid(418272, 1, "942f4db7a14fc72697d9c1366011021a20fe3d2f35db6ffa0a37e656dd16b6ca")
addappid(418273, 1, "87afccf2adf2f029918018fa814f3a52b483a4b8ea6a8135f3ee1a209f37f6ee")
addappid(418274, 1, "5c58f5e5822154fde08073f028c11edb49aa8a7b1fbfe8b60b0c301867be0702")

