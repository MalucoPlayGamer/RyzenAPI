-- Lua provided by RyzenAPI 
-- Game: AppID 200350
addappid(200350)
addappid(200351, 1, "94a7ffc4541d021e6f80348d392d78641306ad5b55950c714c0dfc50630d37a5")
