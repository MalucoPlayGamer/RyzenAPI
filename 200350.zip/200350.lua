-- Lua provided by RyzenAPI
-- Game: Starvoid

-- MAIN APPLICATION
addappid(200350)

-- MAIN APP DEPOTS / PACKAGES
addappid(200351, 1, "94a7ffc4541d021e6f80348d392d78641306ad5b55950c714c0dfc50630d37a5")

