-- 2393430's Lua and Manifest Created by Hubcap Manifest
-- Duelists of Eden Playtest
-- Created: June 25, 2026 at 12:08:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2393430) -- Duelists of Eden Playtest
addtoken(2393430, "9099517720892817065")
-- MAIN APP DEPOTS
addappid(2393431, 1, "0d6908b219a51a51d30a3ba64fdfbb3e1a014f192747ce11d58e29e5189e4375") -- Depot 2393431
setManifestid(2393431, "9092486021502596086", 427240532)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)