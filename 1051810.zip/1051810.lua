-- Lua provided by RyzenAPI
-- Game: VCB: Why City 4k

-- MAIN APPLICATION
addappid(1051810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051811, 1, "1749fcb3f77cee7fdc67602917abe6810f97256089703049de2249a2bfd38e3f")

