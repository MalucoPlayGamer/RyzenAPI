-- Lua provided by RyzenAPI
-- Game: SuperTaxCity

-- MAIN APPLICATION
addappid(2881800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881801, 1, "d1ecba256d079cbd3cf917e5de736ea6d13e1694cd1e09065f8ec78464dac855")
