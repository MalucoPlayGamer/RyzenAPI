-- Lua provided by RyzenAPI
-- Game: AppID 724490

-- MAIN APPLICATION
addappid(724490)
addappid(986000)
addappid(986001)

-- MAIN APP DEPOTS / PACKAGES
addappid(724491, 1, "54af84c1da1549ba1d0b84e63b51b9ef0949947001bcd9bb3cfd70afbd4fed9e")
