-- Lua provided by RyzenAPI
-- Game: project canvas 〜ヰ世界情緒育成計画〜

-- MAIN APPLICATION
addappid(2872930)
-- Game: addappid(2872930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872931, 1, "1a7db5ea3110d80008a4ce8c9f4289b0f39a556560e18cba2847e5c070a22495")
