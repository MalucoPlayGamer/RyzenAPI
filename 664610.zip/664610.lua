-- Lua provided by RyzenAPI
-- Game: AppID 664610

-- MAIN APPLICATION
addappid(664610)
-- Game: addappid(664610)

-- MAIN APP DEPOTS / PACKAGES
addappid(664611, 1, "47bf682da2a850f84bb41485435fe71ce7330e264cbeeaac27a2eca14f70167b")
