-- Lua provided by RyzenAPI
-- Game: 1810410

-- MAIN APPLICATION
addappid(1810410)
-- Game: addappid(1810410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810412,0,"6d8ad6654df10a88bb2a8a6fb0949f0bec587e8ce736a44cd39f6c61c203ffe2")
