-- Lua provided by RyzenAPI
-- Game: Unreal Mashup

-- MAIN APPLICATION
addappid(1800000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1800001, 1, "f61e8e4b89b480992508647f4ee7f2462882f557eafb1ec9a75e27f092f35ac5")

