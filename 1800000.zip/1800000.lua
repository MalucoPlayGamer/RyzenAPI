-- Lua provided by RyzenAPI
-- Game: Unreal Mashup

-- MAIN APPLICATION
addappid(1800000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800001, 1, "f61e8e4b89b480992508647f4ee7f2462882f557eafb1ec9a75e27f092f35ac5")

