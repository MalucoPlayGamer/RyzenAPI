-- Lua provided by RyzenAPI
-- Game: Primitive Society Simulator FreeDemo

-- MAIN APPLICATION
addappid(2190140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190142,0,"5baefe66d39545decf77276d90468c0627585d82c07b6216da1d4a6dafe277f8")

