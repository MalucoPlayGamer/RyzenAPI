-- Lua provided by RyzenAPI 
-- Game: Fallen Depths
addappid(3332000)
addappid(3332001, 1, "0fa0a4eb47c0edfa70874be1e95c6af56c0e37594b68c8433ef6b96b2f5090ac")
