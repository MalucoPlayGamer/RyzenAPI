-- Lua provided by RyzenAPI
-- Game: Choice of the Vampire

-- MAIN APPLICATION
addappid(776000)
addappid(1437330)
addappid(1437331)

-- MAIN APP DEPOTS / PACKAGES
addappid(776001, 1, "ef755f4428797f6fcf0ff30630322233c7cf5350b06b4ba67c927a67df2eab89")
