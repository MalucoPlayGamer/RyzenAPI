-- Lua provided by RyzenAPI
-- Game: After Inc: Revival

-- MAIN APPLICATION
addappid(3337140)
addappid(5031220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337140,0,"bc5bfc6ee0f88d0453dacfc35d228e97faf0938162d5a7b897cb5dc839eaecbf")
addappid(3337141,0,"6a52d39ffb6729a22be5ae05081f3b4a13e9a662d19e24a2a693a04ea7bbe38a")
addappid(3337142,0,"0c2bf209b9cfd8678e7d11bfea0e971ddef37b4c65c3b75d815a6d383ab3bae9")
addappid(3337143,0,"93279b68247b5e1c1f5f74972baf9058c3a7479c4b67cbe68a6e53aa60915819")

