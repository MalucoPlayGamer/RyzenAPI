-- Lua provided by RyzenAPI
-- Game: After Inc: Revival

-- MAIN APPLICATION
addappid(3337140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337142,0,"0c2bf209b9cfd8678e7d11bfea0e971ddef37b4c65c3b75d815a6d383ab3bae9")
addappid(3337143,0,"93279b68247b5e1c1f5f74972baf9058c3a7479c4b67cbe68a6e53aa60915819")
