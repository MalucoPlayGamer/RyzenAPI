-- Lua provided by RyzenAPI
-- Game: Siren's Well

-- MAIN APPLICATION
addappid(3272980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3272981, 1, "8d3fefb54899a54bf8a0e62777d944033d73ac874ecb47860b713f40489f0fc4")

