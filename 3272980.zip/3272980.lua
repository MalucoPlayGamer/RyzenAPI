-- Lua provided by RyzenAPI
-- Game: Siren's Well

-- MAIN APPLICATION
addappid(3272980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272981, 1, "8d3fefb54899a54bf8a0e62777d944033d73ac874ecb47860b713f40489f0fc4")
