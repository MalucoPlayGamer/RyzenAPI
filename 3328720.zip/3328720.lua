-- Lua provided by RyzenAPI
-- Game: 3328720

-- MAIN APPLICATION
addappid(3328720)
-- Game: addappid(3328720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328721, 1, "2b884aee62fb6f72dff10a76bfef85f1abe442945e02bb555872218a05f66f25")
