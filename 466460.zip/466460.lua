-- Lua provided by RyzenAPI
-- Game: 466460

-- MAIN APPLICATION
addappid(466460)
-- Game: addappid(466460)

-- MAIN APP DEPOTS / PACKAGES
addappid(464171,0,"a4b995e55ca0d7e39d72c5d10dcec1267af6282a3ac056d357ee190d4701ad8c")
