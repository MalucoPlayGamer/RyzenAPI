-- Lua provided by RyzenAPI
-- Game: Game: Stella of The End

-- MAIN APPLICATION
addappid(2510770)
-- Game: addappid(2510770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510771, 1, "01aab9abea5851d8f368d4b07c30802c4ff53db61479ebcfb6f7a5609bd48a31")
