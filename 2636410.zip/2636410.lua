-- Lua provided by RyzenAPI
-- Game: Stranded

-- MAIN APPLICATION
addappid(2636410)
-- Game: addappid(2636410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636411, 1, "464855a8a1921d1420945d8c8e994a00ae4ef648664a86bf4565d1750097d056")
