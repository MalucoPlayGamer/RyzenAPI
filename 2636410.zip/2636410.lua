-- Lua provided by SkyAPI 
-- Game: Stranded
addappid(2636410)
addappid(2636411, 1, "464855a8a1921d1420945d8c8e994a00ae4ef648664a86bf4565d1750097d056")
