-- Lua provided by RyzenAPI
-- Game: 801280

-- MAIN APPLICATION
addappid(801280)
-- Game: addappid(801280)

-- MAIN APP DEPOTS / PACKAGES
addappid(801281, 1, "2f70ffb28e7abdb5b389fcfb4af191afdb88b136df03d6bab40a0525fbdf4b24")
