-- Lua provided by RyzenAPI
-- Game: 849940

-- MAIN APPLICATION
addappid(849940)
addappid(849946)
addappid(849947)

-- MAIN APP DEPOTS / PACKAGES
addappid(849945,0,"df3b9ab188d3213ba5c518fc36d832a5de1fde8f3449ba3735ef0a8e5412522f")

