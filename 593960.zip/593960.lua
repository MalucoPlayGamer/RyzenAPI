-- Lua provided by RyzenAPI 
-- Game: Lorelai
addappid(593960)
addappid(593961, 1, "1572aa3be741d5137b62f4a111f0cd42d2ea399746ed4cfa3f45a65c671b6fa7")
