-- Lua provided by RyzenAPI
-- Game: addappid(1911210)

-- MAIN APPLICATION
addappid(1911210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911211, 1, "c0fc2fd8fa6f3942ed077637986ba4d9624b561f9c26766d37925c8f8d80c1a5")
