-- Lua provided by RyzenAPI
-- Game: The Front Dedicated Server

-- MAIN APPLICATION
addappid(2612550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612551, 1, "53b87fb2dca0ac49158c70dbd3232a747ba0ef7328ea23c2cb61503c4e3f2b8c")
