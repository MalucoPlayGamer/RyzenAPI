-- Lua provided by RyzenAPI
-- Game: addappid(646290)

-- MAIN APPLICATION
addappid(646290)

-- MAIN APP DEPOTS / PACKAGES
addappid(646291, 1, "2bbd895d00eff3539cab0501162ad3d276f66e025f436c5a5cc69d565e523676")
