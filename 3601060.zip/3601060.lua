-- Lua provided by RyzenAPI
-- Game: TaVRn's Takedown - Naheulbeuk

-- MAIN APPLICATION
addappid(3601060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3601061,0,"b354b5d635d85abe16a85247fd0efb20c19e2d5042eb0b314b3218f8a6c4f762")

