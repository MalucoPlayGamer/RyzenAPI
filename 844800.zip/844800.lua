-- Lua provided by RyzenAPI
-- Game: 844800

-- MAIN APPLICATION
addappid(844800)
-- Game: addappid(844800)

-- MAIN APP DEPOTS / PACKAGES
addappid(844801, 1, "37adab0c75c44a18a3c566db4c6a2a13c00080b7b2b891c377f68110b4975ba2")
