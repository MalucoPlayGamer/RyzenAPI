-- Lua provided by RyzenAPI
-- Game: addappid(2893740)

-- MAIN APPLICATION
addappid(2893740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893741, 1, "38fee45bb3b648c376677e2594cba51819ffe690af91ec43a9e6ab59fc71f79e")
