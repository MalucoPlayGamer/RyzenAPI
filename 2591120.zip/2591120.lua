-- Lua provided by RyzenAPI
-- Game: 2591120

-- MAIN APPLICATION
addappid(2591120)
-- Game: addappid(2591120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591121, 1, "ccd55c570778cd23c6299b6d05a236e100dd14f1b5f34d43c595cf7f0bc4b193")
