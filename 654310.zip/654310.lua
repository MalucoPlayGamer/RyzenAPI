-- Lua provided by RyzenAPI
-- Game: AppID 654310

-- MAIN APPLICATION
addappid(654310)
-- Game: addappid(654310)

-- MAIN APP DEPOTS / PACKAGES
addappid(654311, 1, "46f7b09e155543eb13f883da8b88be2b32d220dd67333049b1cbf55c57eb9ca1")
