-- Lua provided by RyzenAPI
-- Game: AppID 654310

-- MAIN APPLICATION
addappid(654310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(654311, 1, "46f7b09e155543eb13f883da8b88be2b32d220dd67333049b1cbf55c57eb9ca1")

