-- Lua provided by RyzenAPI
-- Game: Xion Leak

-- MAIN APPLICATION
addappid(1948490)
-- Game: addappid(1948490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948491, 1, "ae6c844e517b2642f79942a5c78a45d927a2fbee888bb2049575ff8a0d759400")
