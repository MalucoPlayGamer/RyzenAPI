-- Lua provided by SkyAPI 
-- Game: Xion Leak
addappid(1948490)
addappid(1948491, 1, "ae6c844e517b2642f79942a5c78a45d927a2fbee888bb2049575ff8a0d759400")
