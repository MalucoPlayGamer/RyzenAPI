-- Lua provided by RyzenAPI
-- Game: WARRIORS: Abyss - NOBUNAGA'S AMBITION Yukimura Sanada Costume Set

-- MAIN APPLICATION
addappid(3358160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358160,0,"92e45e04b2863544247f5e07ec54e39a35f2a27d0d234bfba0336d799a16f1f3")
