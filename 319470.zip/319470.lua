-- Lua provided by RyzenAPI
-- Game: addappid(319470)

-- MAIN APPLICATION
addappid(319470)
addappid(409430)

-- MAIN APP DEPOTS / PACKAGES
addappid(319471, 1, "cdfb1649c534096777fcd2e9a7c1014090979db4460ea95635254b5f437a7935")
addappid(319472, 1, "6e2b3fc1f6597f40206db5a23474f5dbfb56d2bf975996d85a79a9a21f5958ab")
addappid(319473, 1, "471de44a96cf5f1b0cef9fbcd68afc581292d3ca8b6bc8d40d3ba2d29e659464")
