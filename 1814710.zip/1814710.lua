-- Lua provided by RyzenAPI 
-- Game: Cute Dogs
addappid(1814710)
addappid(1814711, 1, "4d631f9eca2753844f525a5ef49a0097f1bc8a97716071eb0bdad2e3d052d365")
addappid(1830930, 0, "ba2207c8e4095062f1091d7fe20c622601320753cc1a000df860c7b892bb9324")
