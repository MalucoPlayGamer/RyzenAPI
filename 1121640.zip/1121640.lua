-- Lua provided by RyzenAPI
-- Game: The Wandering Village

-- MAIN APPLICATION
addappid(2108240)
addappid(2108250)
addappid(4162120) -- The Wandering Village: Onbu Skin Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1121640, 1, "c062c6f17c6ea36e00602abd95e4730f14fd13d9aba7ceba9942f8de2016d25e")
addappid(1121641, 1, "589062032126cb115e44bf22b1f1a7e84ac07202db9d7e297972cc12130c256b") -- (windows, 64-bit)
addappid(1121642, 1, "bbb6ebc0721460dbc0155d9b26c55231535405d93f38fb6e50872d0803db0fed") -- (macos)
addappid(1121643, 1, "89b00047847f1d8ba2672409d955a16b87f2fba17d5104e7d52f2eb93b0ef7d2") -- (windows, 32-bit)
addappid(1121644, 1, "bdd41c80e89da770cf45077f31fabce93992c2a99fde9378afdc725375bdee4e") -- (linux, 64-bit)
addappid(2108240, 1, "3bab56d802407d29977f89e57f59dbddd3fbdffb45f22df1832cf0e363bb7a13")
addappid(2108251, 1, "d6fb0ed010c06dfdca387061f1bb4892e0482bf705aee95f2c71ed9d70eb2eab")
addappid(2108252, 1, "ee894065f752a31854dd17794a896892c26017992ce7610165edeaf3adf6a338")

