-- Lua provided by RyzenAPI
-- Game: Game: The Wandering Village

-- MAIN APPLICATION
addappid(1121640)
-- Game: addappid(1121640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121641, 1, "589062032126cb115e44bf22b1f1a7e84ac07202db9d7e297972cc12130c256b")
addappid(1121642, 1, "bbb6ebc0721460dbc0155d9b26c55231535405d93f38fb6e50872d0803db0fed")
addappid(1121643, 1, "89b00047847f1d8ba2672409d955a16b87f2fba17d5104e7d52f2eb93b0ef7d2")
addappid(1121644, 1, "bdd41c80e89da770cf45077f31fabce93992c2a99fde9378afdc725375bdee4e")
addappid(2108240, 0, "3bab56d802407d29977f89e57f59dbddd3fbdffb45f22df1832cf0e363bb7a13")
