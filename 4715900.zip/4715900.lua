-- 4715900's Lua and Manifest Created by Hubcap Manifest
-- Pocket Dinos
-- Created: August 01, 2026 at 13:55:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4715900, 1, "b9b79e91a9504dd1f398b5680c3e61f6105f12ccf0f74024e0fa19b275e5e1d3") -- Pocket Dinos
-- MAIN APP DEPOTS
addappid(4715901, 1, "32e6a888d3cb98471b96148a1596eec4afae1928ece0771eeacc31fc9c69e2d2") -- Depot 4715901
setManifestid(4715901, "7777716378161925605", 278929768)