-- Lua provided by SkyAPI 
-- Game: Repurpose
addappid(1862430)
addappid(1862431, 1, "025b538afe7e9d84b9181fd3b7ca7068544160a2cc1b021145e77d408587d2d3")
