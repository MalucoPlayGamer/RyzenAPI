-- Lua provided by RyzenAPI
-- Game: addappid(3305890)

-- MAIN APPLICATION
addappid(3305890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3305891, 1, "bfadbe6436c396aa84d7a66c1eecc2cc037612651913367118ebfcc2319a1dae")
