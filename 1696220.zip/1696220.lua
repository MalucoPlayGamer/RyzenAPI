-- Lua provided by SkyAPI 
-- Game: FixFox
addappid(1696220)
addappid(1696221, 1, "aa40424245d44e10f5bd786ea1d71c9982cc71dd59df7282de2899c0a0630ae7")
