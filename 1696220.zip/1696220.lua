-- Lua provided by RyzenAPI
-- Game: FixFox

-- MAIN APPLICATION
addappid(1696220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696221, 1, "aa40424245d44e10f5bd786ea1d71c9982cc71dd59df7282de2899c0a0630ae7")

