-- Lua provided by RyzenAPI
-- Game: Max Mustard Digital Poster

-- MAIN APPLICATION
addappid(2875220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875220,0,"b6d9512e8cce26d88b2aae47652b542314a60e9ffda5a2ba023a3ac216b611f3")
