-- Lua provided by RyzenAPI
-- Game: AppID 1195560

-- MAIN APPLICATION
addappid(1195560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195561, 1, "568121e318794056b2f3d6e5dbb0eaca592c9837ddd1392c93d86db87babf6ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
