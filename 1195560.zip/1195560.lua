-- Lua provided by RyzenAPI
-- Game: AppID 1195560

-- MAIN APPLICATION
addappid(1195560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195561, 1, "568121e318794056b2f3d6e5dbb0eaca592c9837ddd1392c93d86db87babf6ec")
