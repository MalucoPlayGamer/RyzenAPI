-- Lua provided by RyzenAPI
-- Game: Necrosmith

-- MAIN APPLICATION
addappid(1949190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949191, 1, "2178fc0e37f409d3204faee4bc3c9aa8023f8147d013554ca4579c1e45d90225")

