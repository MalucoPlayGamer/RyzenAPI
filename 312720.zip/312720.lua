-- Lua provided by RyzenAPI
-- Game: 312720

-- MAIN APPLICATION
addappid(312720)
addappid(327610)
-- Game: addappid(312720)

-- MAIN APP DEPOTS / PACKAGES
addappid(312721, 1, "976bf97250d7d5afde92fc0c77b2672204e1af2e81f4319c2f780537cd687a9c")
addappid(312722, 1, "ed0b81b2d1ed3fb065b430a64c11404c441b9204cdb314beefb1b15bd7782575")
