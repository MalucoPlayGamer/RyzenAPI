-- Lua provided by SkyAPI 
-- Game: AppID 517710
addappid(517710)
addappid(517711, 1, "3c65968fa84da5dfbace9314360f35d4a1248dac7c04e5b29cb534136bd31025")
