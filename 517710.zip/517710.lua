-- Lua provided by RyzenAPI
-- Game: 517710

-- MAIN APPLICATION
addappid(517710)
-- Game: addappid(517710)

-- MAIN APP DEPOTS / PACKAGES
addappid(517711, 1, "3c65968fa84da5dfbace9314360f35d4a1248dac7c04e5b29cb534136bd31025")
