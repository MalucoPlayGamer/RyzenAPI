-- Lua provided by RyzenAPI
-- Game: Redout: Enhanced Edition

-- MAIN APPLICATION
addappid(517710)
addappid(573350)
addappid(580620)
addappid(627430)
addappid(627440)
addappid(728910)
addappid(762770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(517711, 1, "3c65968fa84da5dfbace9314360f35d4a1248dac7c04e5b29cb534136bd31025")

