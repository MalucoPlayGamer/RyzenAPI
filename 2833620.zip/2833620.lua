-- Lua provided by RyzenAPI
-- Game: addappid(2833620)

-- MAIN APPLICATION
addappid(2833620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833621, 1, "62ef6cfafe3df62ad97ede074be838e89a49c692fcf3715e122a5787c126fe41")
