-- Lua provided by RyzenAPI
-- Game: Fat Prisoner Simulator 3

-- MAIN APPLICATION
addappid(1498590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498591, 1, "4d0c9ffbc436ec91b8077b8ebd91e9447e6649957026df437faff81f54249c0f")

