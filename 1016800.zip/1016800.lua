-- 1016800's Lua and Manifest Created by Hubcap Manifest
-- Chernobylite Complete Edition
-- Created: September 29, 2025 at 03:53:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 10
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1016800) -- Chernobylite Complete Edition
-- MAIN APP DEPOTS
addappid(1016801, 1, "d5922db497812c1e9e7de0a1242522c0a4f38964b632aafe2f466105a69429bb") -- Chernobylite Content
setManifestid(1016801, "5026200692860711757", 40253308368)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Chernobylite - The Art of Chernobylite (AppID: 1701200)
addappid(1701200)
addappid(1701200, 1, "fa86adca169023889b58ef61c505090a61a8da3443ddf019b9f69ef260f8164a") -- Chernobylite - The Art of Chernobylite - Depot 1701200
setManifestid(1701200, "7242997835342746338", 29136344)
-- Chernobylite - Charity Pack (AppID: 1935250)
addappid(1935250)
addappid(1935250, 1, "941ebb09831816d7e374e710c049522e83cea8d0369312ba6b8884dcccbaedfa") -- Chernobylite - Charity Pack - Depot 1935250
setManifestid(1935250, "1033237140666714046", 174698967)
-- Chernobylite Short Story The Arrival (AppID: 2094140)
addappid(2094140)
addappid(2094140, 1, "9453fc82afc2a02778b083025064645f9a62e0eea1bab39667730a324eaf938c") -- Chernobylite Short Story The Arrival - Depot 2094140
setManifestid(2094140, "5838793652207091789", 9458651)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1640500) -- Chernobylite - White Rose Pack
addappid(1797280) -- Chernobylite - Autumn Dread Pack
addappid(1845330) -- Chernobylite - Deadly Frost Pack
addappid(1903090) -- Chernobylite - Blue Flames Pack
addappid(1958580) -- Chernobylite - Red Trees Pack
addappid(2184830) -- Chernobylite - Zone Bard Pack
addappid(3017050) -- Chernobylite - Black Smoke Pack