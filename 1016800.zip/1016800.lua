-- Lua provided by RyzenAPI
-- Game: Game: AppID 1016800

-- MAIN APPLICATION
addappid(1016800)
-- Game: addappid(1016800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016801, 1, "d5922db497812c1e9e7de0a1242522c0a4f38964b632aafe2f466105a69429bb")
