-- Lua provided by RyzenAPI
-- Game: Undying Flower Soundtrack

-- MAIN APPLICATION
addappid(3536940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3536941, 1, "47377a983e9985d9115dda823afec7dd9559476b8be8a6d4f5a92ab14dd45c0c")
addappid(3536942, 1, "28880f8c469d2c3ba797959d0638871425eb5af57d781f417666faafff666f49")
