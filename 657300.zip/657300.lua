-- Lua provided by RyzenAPI
-- Game: addappid(657300)

-- MAIN APPLICATION
addappid(657300)

-- MAIN APP DEPOTS / PACKAGES
addappid(657301, 1, "f55ac8ba7eadef82930f43632e75f188c99599ad02198e82236987cf2e790c50")
