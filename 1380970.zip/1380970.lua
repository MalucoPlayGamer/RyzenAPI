-- Lua provided by RyzenAPI
-- Game: addappid(1380970)

-- MAIN APPLICATION
addappid(1380970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380972,0,"e2838fcb0e86b775aebc7f00dff9969e8b90c47851fad19972d497e7a7e34a62")
