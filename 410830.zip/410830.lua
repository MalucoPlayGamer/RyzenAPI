-- Lua provided by RyzenAPI
-- Game: addappid(410830)

-- MAIN APPLICATION
addappid(410830)

-- MAIN APP DEPOTS / PACKAGES
addappid(410831, 1, "23779601da4d340a634b500198194cde949cfaa1912836bc3c9a59c6dcd4db32")
