-- Lua provided by RyzenAPI
-- Game: Edge Of Eternity - War Nekaroo Skin

-- MAIN APPLICATION
addappid(1000400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000400,0,"855ef54a7c25583a5447a17b1c1ed5589e09965d94ccb9cf68e2b228b721bcf9")
