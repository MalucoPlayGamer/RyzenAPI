-- Lua provided by RyzenAPI
-- Game: 2071720

-- MAIN APPLICATION
addappid(2071720)
-- Game: addappid(2071720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071721, 1, "e6de0092ab5e5cb160bbeb8b3157b4680b06db123b92cc94fe7e328b3a8858dd")
