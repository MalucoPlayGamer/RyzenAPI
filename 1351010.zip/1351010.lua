-- Lua provided by RyzenAPI
-- Game: addappid(1351010)

-- MAIN APPLICATION
addappid(1351010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351010,0,"4b7c81491f7a9df3d473f533d064e654f57c6f2f05dfc5bbf6903aab346f0536")
