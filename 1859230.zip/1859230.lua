-- Lua provided by RyzenAPI
-- Game: Nightmare: The Lunatic Soundtrack

-- MAIN APPLICATION
addappid(1859230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859231, 1, "14e16b389c3e7f5eef85d7307739ecc7474480ec6fcf000d90508879900f7108")

