-- Lua provided by RyzenAPI
-- Game: Infinite Rails Demo

-- MAIN APPLICATION
addappid(3507160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3507163,0,"8995076ba7cc3c1fe0ecb7f575201213fb8c3c038a4dab99f922c075d62b3c07")

