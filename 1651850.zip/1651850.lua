-- Lua provided by RyzenAPI
-- Game: AppID 1651850

-- MAIN APPLICATION
addappid(1651850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651851, 1, "1dd770964de28b5cdc9e098cc3c951a0589bb20664203923d9279589f09ee3a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
