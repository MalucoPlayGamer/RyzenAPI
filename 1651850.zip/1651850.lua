-- Lua provided by RyzenAPI
-- Game: Game: AppID 1651850

-- MAIN APPLICATION
addappid(1651850)
-- Game: addappid(1651850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651851, 1, "1dd770964de28b5cdc9e098cc3c951a0589bb20664203923d9279589f09ee3a1")
