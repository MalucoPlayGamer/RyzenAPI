-- Lua provided by RyzenAPI
-- Game: Campaign Clicker

-- MAIN APPLICATION
addappid(485650)

-- MAIN APP DEPOTS / PACKAGES
addappid(485651, 1, "86a32a5442c078e4e2794844305dbd3f2e78cd39603553a9095e8192173df926")
