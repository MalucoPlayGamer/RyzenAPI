-- Lua provided by RyzenAPI
-- Game: Campaign Clicker

-- MAIN APPLICATION
addappid(485650)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(485651, 1, "86a32a5442c078e4e2794844305dbd3f2e78cd39603553a9095e8192173df926")

