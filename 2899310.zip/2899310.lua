-- Lua provided by RyzenAPI
-- Game: Card Engine

-- MAIN APPLICATION
addappid(2899310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899311, 1, "d574da0ffbea7afb1ab5e2207869784ad04b2b3c39e6f10b0dc11c32204c3dfe")
