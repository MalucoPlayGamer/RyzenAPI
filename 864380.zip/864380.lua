-- Lua provided by RyzenAPI
-- Game: A Lot Like Love

-- MAIN APPLICATION
addappid(864380)

-- MAIN APP DEPOTS / PACKAGES
addappid(864381, 1, "30ad3a16c62ea221f584d124dc234bc2d1a73945c7de2562db562bd2a85ff402")
addappid(864382, 1, "16ee25781c24594a9344be6c7338e025df6c9979b01ff5c7391a98de84ef2ad0")

