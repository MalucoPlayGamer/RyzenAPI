-- Lua provided by RyzenAPI
-- Game: addappid(1133980)

-- MAIN APPLICATION
addappid(1133980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133981, 1, "f22185ff0f1afe3a7c8bfcfb1583a1f58ccaf509b90e9584217c698b65d19593")
