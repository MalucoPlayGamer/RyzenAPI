-- Lua provided by RyzenAPI
-- Game: Agni Fighter

-- MAIN APPLICATION
addappid(2267680)
-- Game: addappid(2267680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267681, 1, "e09c1b409a82af7f75acdd70f1ec8f1247cb3206cc96067a8938ff0bf5db5942")
