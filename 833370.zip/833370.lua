-- Lua provided by RyzenAPI
-- Game: HexLab

-- MAIN APPLICATION
addappid(833370)
-- Game: addappid(833370)

-- MAIN APP DEPOTS / PACKAGES
addappid(833371, 1, "28b40b7e0f32617bf20fd327ef14a9112c0828191e1f9039c9b80eed282b017b")
