-- Lua provided by SkyAPI 
-- Game: HexLab
addappid(833370)
addappid(833371, 1, "28b40b7e0f32617bf20fd327ef14a9112c0828191e1f9039c9b80eed282b017b")
