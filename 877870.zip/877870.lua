-- Lua provided by RyzenAPI
-- Game: World Soccer Strikers '91

-- MAIN APPLICATION
addappid(877870)
addappid(1433760)

-- MAIN APP DEPOTS / PACKAGES
addappid(877871, 1, "ca88b2e279b29d71c7d3016627a358666f2fddb71a9c7987bd72f73128664b6a")
