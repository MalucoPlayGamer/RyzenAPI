-- Lua provided by SkyAPI 
-- Game: AppID 877870
addappid(877870)
addappid(877871, 1, "ca88b2e279b29d71c7d3016627a358666f2fddb71a9c7987bd72f73128664b6a")
