-- Lua provided by RyzenAPI
-- Game: addappid(1700270)

-- MAIN APPLICATION
addappid(1700270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700271, 1, "e9d47fee5f2c047a0323c658234c240bdf35a6bfd16e4e80097004a5c2b14393")
