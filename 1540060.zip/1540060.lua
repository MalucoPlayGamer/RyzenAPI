-- Lua provided by RyzenAPI
-- Game: Game: Angry Putin

-- MAIN APPLICATION
addappid(1540060)
-- Game: addappid(1540060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540061, 1, "c0c7b8d8bdbfe6e6871e9469fe891cc9cbe97a2be9511ef222ff4fb5b46c145c")
