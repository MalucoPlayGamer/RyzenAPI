-- Lua provided by RyzenAPI
-- Game: CONSORTIUM Remastered

-- MAIN APPLICATION
addappid(2380550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2380551, 1, "fbc2ba879f105b19ad249df806f89164bb2153b7d36360a2b74976f32943a578")
