-- Lua provided by RyzenAPI
-- Game: Game: AppID 2380550

-- MAIN APPLICATION
addappid(2380550)
-- Game: addappid(2380550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380551, 1, "fbc2ba879f105b19ad249df806f89164bb2153b7d36360a2b74976f32943a578")
