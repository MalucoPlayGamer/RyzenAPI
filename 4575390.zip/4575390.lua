-- Lua provided by RyzenAPI
-- Game: Bow-wow Battle

-- MAIN APPLICATION
addappid(4575390)
-- Game: addappid(4575390)

-- MAIN APP DEPOTS / PACKAGES
addappid(4575391, 1, "5db43126ea3762c201898ae2e6b08c448e65d75e9fd759804c40a9b2b6752166")
