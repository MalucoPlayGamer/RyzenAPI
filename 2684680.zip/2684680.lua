-- Lua provided by RyzenAPI
-- Game: 2684680

-- MAIN APPLICATION
addappid(2684680)
-- Game: addappid(2684680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684681, 1, "4d2e2f2acfa0543792a1421f65e5ada8bed4172f6074fd0e30d206187a6f1a5d")
