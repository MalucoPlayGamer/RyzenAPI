-- Lua provided by RyzenAPI
-- Game: AppID 1305590

-- MAIN APPLICATION
addappid(1305590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305591, 1, "08b13a13b989d56fb7c273c389971a68d87c99fadf97fb25a1c5203defec98ac")
