-- Lua provided by RyzenAPI
-- Game: Game: Revenge of the shadow ninja

-- MAIN APPLICATION
addappid(2364970)
-- Game: addappid(2364970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364971, 1, "8a0ef60b915228b9388c489dbce898d11df6d3d5abf627aa4644cdd765c09cf9")
