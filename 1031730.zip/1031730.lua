-- Lua provided by RyzenAPI
-- Game: Battlefall: State of Conflict

-- MAIN APPLICATION
addappid(1031730)
-- Game: addappid(1031730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031731, 1, "4fc3e0feb3937104cda0189c3c22280e8f8627766857bba7390237ddf6dd3987")
