-- Lua provided by RyzenAPI
-- Game: Battlefall: State of Conflict

-- MAIN APPLICATION
addappid(1031730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031731, 1, "4fc3e0feb3937104cda0189c3c22280e8f8627766857bba7390237ddf6dd3987")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
