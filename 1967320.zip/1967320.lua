-- Lua provided by RyzenAPI
-- Game: Fairy Biography

-- MAIN APPLICATION
addappid(1967320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967321, 1, "6a98e41448a53785e0aef5372a588f79b49fca4cbb5ad905fb028699463d96b6")
addappid(2001260, 0, "7d3c5da564b3d5581fbda0f1c1af1b7c162c95f5a2e86dfc39154a88e47f9df4")

