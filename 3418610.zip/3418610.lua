-- Lua provided by RyzenAPI 
-- Game: 火起雪中寺
addappid(3418610)
addappid(3418611, 1, "28e3e511a7491cfad75d9f69646f81078c2dcba15d9634e28b27c1022ff1d1ec")
