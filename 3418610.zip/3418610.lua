-- Lua provided by RyzenAPI
-- Game: Game: 火起雪中寺

-- MAIN APPLICATION
addappid(3418610)
-- Game: addappid(3418610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418611, 1, "28e3e511a7491cfad75d9f69646f81078c2dcba15d9634e28b27c1022ff1d1ec")
