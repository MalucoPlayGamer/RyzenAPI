-- Lua provided by RyzenAPI
-- Game: 火起雪中寺

-- MAIN APPLICATION
addappid(3418610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3418611, 1, "28e3e511a7491cfad75d9f69646f81078c2dcba15d9634e28b27c1022ff1d1ec")

