-- Lua provided by RyzenAPI
-- Game: Game: 情人泪

-- MAIN APPLICATION
addappid(2244420)
-- Game: addappid(2244420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244421, 1, "bf5f37d7004da1f54cfb8ba3ca4e070246884252defa0fb77a5b2c6c0919db53")
