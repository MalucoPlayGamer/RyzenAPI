-- Lua provided by RyzenAPI
-- Game: Dice of Kalma

-- MAIN APPLICATION
addappid(3885520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3885521,0,"efa6b9befa3e7e5712ec8a700492a3667635d6ba242c4a895647c2d162d55373")

