-- Lua provided by RyzenAPI 
-- Game: Mountain Eye
addappid(3080890)
addappid(3080891, 1, "c3bd01cb6108547a9219802d6a2fed85fe7a390c0b82b79b1e7f29f2e12a1560")
