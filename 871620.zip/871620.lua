-- Lua provided by RyzenAPI
-- Game: Volcano Eruption

-- MAIN APPLICATION
addappid(871620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(871621, 1, "001aa88714d95b4b07307650ea9671bc9fe9af6b385d3bb0552fd044f741297e")

