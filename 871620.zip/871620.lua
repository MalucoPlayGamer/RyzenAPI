-- Lua provided by RyzenAPI
-- Game: 871620

-- MAIN APPLICATION
addappid(871620)
-- Game: addappid(871620)

-- MAIN APP DEPOTS / PACKAGES
addappid(871621, 1, "001aa88714d95b4b07307650ea9671bc9fe9af6b385d3bb0552fd044f741297e")
