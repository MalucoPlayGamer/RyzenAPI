-- Lua provided by RyzenAPI 
-- Game: Volcano Eruption
addappid(871620)
addappid(871621, 1, "001aa88714d95b4b07307650ea9671bc9fe9af6b385d3bb0552fd044f741297e")
