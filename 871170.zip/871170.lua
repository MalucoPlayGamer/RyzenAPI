-- Lua provided by RyzenAPI
-- Game: 3tene FREE

-- MAIN APPLICATION
addappid(871170)

-- MAIN APP DEPOTS / PACKAGES
addappid(871171, 1, "92891ab8a7ee8cc3b069a1104585b08b8234cc07246c0f41137afffc808ac8e1")
