-- Lua provided by SkyAPI 
-- Game: AppID 871170
addappid(871170)
addappid(871171, 1, "92891ab8a7ee8cc3b069a1104585b08b8234cc07246c0f41137afffc808ac8e1")
