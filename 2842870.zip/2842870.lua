-- Lua provided by RyzenAPI
-- Game: addappid(2842870)

-- MAIN APPLICATION
addappid(2842870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842871, 1, "47a10b0b5420bc881d2712f9d9c00a9cb639fdd91789565acebd9cdd8d091ad4")
