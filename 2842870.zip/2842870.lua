-- Lua provided by SkyAPI 
-- Game: My Futa Girlfriend 🔞
addappid(2842870)
addappid(2842871, 1, "47a10b0b5420bc881d2712f9d9c00a9cb639fdd91789565acebd9cdd8d091ad4")
