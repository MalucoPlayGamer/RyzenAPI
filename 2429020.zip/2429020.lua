-- Lua provided by RyzenAPI
-- Game: Kingdom Come: Deliverance II Modding tools

-- MAIN APPLICATION
addappid(2429020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429021, 1, "f7fcf33281ac0f6ffb0c1527b91828f1286a6ef092667f6462055c8b2fd8c177")

