-- Lua provided by RyzenAPI 
-- Game: AppID 738270
addappid(738270)
addappid(738271, 1, "6595c89c41bdab954b03a0482aa55ef150b05266420f02c8019f97b8d01c3a16")
addappid(738272, 1, "e568a6ecc5053d322791ec13c5a56620aefa764058edc233a854a5bda5754bd7")
