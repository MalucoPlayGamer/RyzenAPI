-- Lua provided by RyzenAPI
-- Game: RetroArch - Gearboy

-- MAIN APPLICATION
addappid(1227485)
-- Game: addappid(1227485)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227485,0,"749b71c78a72ec94408e2b311eeacf8b59d4b06e903cbdeb02b89ae348d822dd")
addappid(1789780,0,"92e26d2e4839f482f0a04b408166b6b0fcbb733626016b020c858c208eae4918")
addappid(1789781,0,"bb18fb3d6763975fff59621e4f5fb117984521cc85dcaccfe5db348ab9069bb0")
