-- Lua provided by RyzenAPI
-- Game: Pylow

-- MAIN APPLICATION
addappid(868920)
-- Game: addappid(868920)

-- MAIN APP DEPOTS / PACKAGES
addappid(868921, 1, "78da0650c04841c08df2175d5d2a58b2888f2fcfe92ad31aec4e3603d02fa545")
