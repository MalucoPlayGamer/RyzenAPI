-- Lua provided by RyzenAPI
-- Game: AppID 1061150

-- MAIN APPLICATION
addappid(1061150)
-- Game: addappid(1061150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061151, 1, "ea8041f760d9441df482a348cc83fbece252eb4abeba104e7eec2c26db199189")
