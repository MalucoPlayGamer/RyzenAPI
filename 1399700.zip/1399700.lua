-- Lua provided by RyzenAPI
-- Game: Kapital: Sparks of Revolution

-- MAIN APPLICATION
addappid(1399700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399701, 1, "23b4755c45fb37d72a93d30b3af5dd32c3e956054dafb0efc3193312aa03e90d")
addappid(1399702, 1, "45857885427ab2419000ac3ada753d4df7afdfc5d46f90820ba468bb1be7b1f3")
addappid(1399703, 1, "54ec35d8a02a4442a7399b502be48c01ae9ae4b7f2ca1fbe9b479b29240f6b28")

