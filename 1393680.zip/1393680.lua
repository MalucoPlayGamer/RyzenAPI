-- Lua provided by RyzenAPI
-- Game: Supreme Fighters

-- MAIN APPLICATION
addappid(1393680)
addappid(2816440)
-- Game: addappid(1393680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393681, 1, "2186313b26e1ffbe98c0ed8ee4fc39428dca96f04d6d4506c9bbcd4278cd6cf6")
