-- Lua provided by RyzenAPI
-- Game: Super Video Golf

-- MAIN APPLICATION
addappid(2173760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173761, 1, "ff3aca443ad8ca2974f52b48f8ab5362524db9f926f809726f7efd6c1e371517")
addappid(2173762, 1, "5e73aeb38b200798e045e0e273e539459a9b177dbf60a00d85b569c685022e92")
addappid(2173764, 1, "e739c8046499b59cde1711084f14b67def673ba4ff63399cfac991142081a609")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4050220)
addappid(4446570)
addappid(4928640)
