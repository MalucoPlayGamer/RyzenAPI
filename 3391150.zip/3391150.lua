-- Lua provided by RyzenAPI
-- Game: AppID 3391150

-- MAIN APPLICATION
addappid(3391150)
-- Game: addappid(3391150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391151, 1, "6864b45c3f00330013d3625ffcf5c4cea5e9894d1d276252b5651d6aa708d8c3")
