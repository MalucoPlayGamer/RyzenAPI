-- Lua provided by RyzenAPI
-- Game: 百禾梦境漫游 Wandering Dreams of Yuri

-- MAIN APPLICATION
addappid(3391150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391151, 1, "6864b45c3f00330013d3625ffcf5c4cea5e9894d1d276252b5651d6aa708d8c3")
