-- Lua provided by SkyAPI 
-- Game: AppID 2764340
addappid(2764340)
addappid(2764341, 1, "be20da46701f45cbed6f851af1363b0e554309965735c798d078cc9a08a855a4")
