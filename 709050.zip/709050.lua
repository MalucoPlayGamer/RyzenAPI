-- Lua provided by RyzenAPI
-- Game: 709050

-- MAIN APPLICATION
addappid(709050)
-- Game: addappid(709050)

-- MAIN APP DEPOTS / PACKAGES
addappid(709051, 1, "3f21e8305938bbcad80a49fd4b36d067e925862d43513ef0cfbd04ea89b9d47c")
addappid(866880, 0, "79b40b5cbf0e8f64aacc7bfc7cce20c2cb3274d003ce936b3acdde700880ad83")
