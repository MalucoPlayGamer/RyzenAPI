-- Lua provided by RyzenAPI
-- Game: GHOUL

-- MAIN APPLICATION
addappid(709050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(709051, 1, "3f21e8305938bbcad80a49fd4b36d067e925862d43513ef0cfbd04ea89b9d47c")
addappid(866880, 0, "79b40b5cbf0e8f64aacc7bfc7cce20c2cb3274d003ce936b3acdde700880ad83")

