-- Lua provided by SkyAPI 
-- Game: AppID 2591520
addappid(2591520)
addappid(2591521, 1, "27ef898b54861070c6c12cb895305df727edff2287cbf192f38e3e7a6b8c98e5")
