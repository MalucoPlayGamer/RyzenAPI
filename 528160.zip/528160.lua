-- Lua provided by RyzenAPI
-- Game: AppID 528160

-- MAIN APPLICATION
addappid(528160)
-- Game: addappid(528160)

-- MAIN APP DEPOTS / PACKAGES
addappid(528161, 1, "0dae17234537fba91da3c9ba144ebb731f3fb6fb1e4d7383f1de0d910ce15fd5")
