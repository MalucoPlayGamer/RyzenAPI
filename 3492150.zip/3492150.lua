-- 3492150's Lua and Manifest Created by Hubcap Manifest
-- Ministry of Truth: False Memory
-- Created: August 19, 2026 at 12:11:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3492150) -- Ministry of Truth: False Memory
-- MAIN APP DEPOTS
addappid(3492151, 1, "c7cc259da16531e2b0d2a4980d43393148a37ac904e4be2d73fdbd84427e0eb7") -- Depot 3492151
setManifestid(3492151, "3146934669731541091", 806337642)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITH DEDICATED DEPOTS
-- Ministry of Truth False Memory - Supporter Pack (AppID: 4969170)
addappid(4969170)
addappid(4969170, 1, "4a1c445cbe8d83a88c89b756839a59cde3bf5c68ae7cf6decde4ded008f16fa4") -- Ministry of Truth False Memory - Supporter Pack - Depot 4969170
setManifestid(4969170, "8457521906601416005", 132951827)