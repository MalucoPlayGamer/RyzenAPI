-- Lua provided by RyzenAPI
-- Game: addappid(1050510)

-- MAIN APPLICATION
addappid(1050510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050511, 1, "0c36cc5753ca062c140ec89028446ce4131670318e2cf1f3becd83403cf7649e")
