-- Lua provided by RyzenAPI
-- Game: 디펜서바이버 Demo

-- MAIN APPLICATION
addappid(3232500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232501, 1, "3266b5bc05edbad3512ae8013448262159561e81bcf241331c9cf7390d6d1924")
