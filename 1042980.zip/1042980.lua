-- Lua provided by RyzenAPI
-- Game: Zen Chess: Mate in Two

-- MAIN APPLICATION
addappid(1042980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042981, 1, "4974af648559172479a018835a655c26cb2d737870a41f9bd8a711ee157025ae")

