-- Lua provided by RyzenAPI
-- Game: Stalker

-- MAIN APPLICATION
addappid(1243580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243581, 1, "ce32e9b9824600aae50a02f155f6a577b5592d7946a8cf0599b2b2388add2c05")
