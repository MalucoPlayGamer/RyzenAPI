-- Lua provided by RyzenAPI
-- Game: Elderand

-- MAIN APPLICATION
addappid(1413660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413661, 1, "b1332b5755e3bab36587c10b18dd191021c63d01316179bf28429c9a347704cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
