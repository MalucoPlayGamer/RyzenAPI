-- Lua provided by RyzenAPI
-- Game: Game: Elderand

-- MAIN APPLICATION
addappid(1413660)
-- Game: addappid(1413660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413661, 1, "b1332b5755e3bab36587c10b18dd191021c63d01316179bf28429c9a347704cf")
