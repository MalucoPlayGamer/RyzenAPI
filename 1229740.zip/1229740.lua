-- Lua provided by RyzenAPI
-- Game: Game: LUX SINE

-- MAIN APPLICATION
addappid(1229740)
-- Game: addappid(1229740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229741, 1, "0d1561d4587c530cefbca92f9b07f8c55ca37ffa720825278847146100c2be70")
