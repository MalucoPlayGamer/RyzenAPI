-- Lua provided by RyzenAPI
-- Game: SONG OF HORROR COMPLETE EDITION

-- MAIN APPLICATION
addappid(1096570)
addappid(1147650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096571, 1, "dffa128a302f183d9ddbdc34dd4d31d88d8618fd873509b8e40cf4b9a133973e")
addappid(1151730, 0, "1fa432cb9b2476b7b825842c3509dcba1f9e5d17146d1542fa2cf9629f375ba3")
addappid(1157230, 0, "d11a1682bf5ef74c412d84bc31da9eace38258ca0f0036f87feaf28fde2a69d2")
addappid(1158110, 0, "10e306a0051ec5d25d4cad10a9d396949dacd2350b2f1a338cf82ba5ff55f8fa")
addappid(1158111, 0, "9aaf0983692baa458a164715f4463a8f4bb6aad4e5e477afb95b8c5cee89823a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
