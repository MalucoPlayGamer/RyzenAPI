-- Lua provided by RyzenAPI
-- Game: Obscure Chronicle of Dynasty

-- MAIN APPLICATION
addappid(2010900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010901, 1, "c3f53ddfca46d00c2c3f9d50d36167d936c18e55cab77e90133bfb10aaf9ee2f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2674440)
addappid(2694320)
