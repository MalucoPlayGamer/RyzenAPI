-- Lua provided by RyzenAPI
-- Game: Monkey Island 2: Special Edition

-- MAIN APPLICATION
addappid(32460)

-- MAIN APP DEPOTS / PACKAGES
addappid(32461, 1, "6db5e5a0fe1aedc6880b02e4000e8e69edd6ee75098c0155369f2572aa121c5b")

