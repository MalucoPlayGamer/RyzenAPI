-- Lua provided by RyzenAPI
-- Game: 699820

-- MAIN APPLICATION
addappid(699820)
-- Game: addappid(699820)

-- MAIN APP DEPOTS / PACKAGES
addappid(699821, 1, "83c735f91622344c3b402b47a32ec5a3891b52e4cb2e34a2c782060758e106bc")
