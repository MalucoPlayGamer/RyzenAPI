-- Lua provided by SkyAPI 
-- Game: Faunamorph
addappid(2461980)
addappid(2461981, 1, "c39c1c62062f16e4546f0aebc7c389a1574f0fbf2d5b1f98998c886110d1c032")
