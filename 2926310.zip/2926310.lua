-- Lua provided by RyzenAPI
-- Game: Rota's Nautical Chronicles of Trade

-- MAIN APPLICATION
addappid(2926310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926311, 1, "7953010a0a671e426dc8b3a0d55127e0a7c68887ff64e779e33bb6bc4f886a9e")

