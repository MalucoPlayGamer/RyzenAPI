-- Lua provided by RyzenAPI
-- Game: Game: AppID 871280

-- MAIN APPLICATION
addappid(871280)
-- Game: addappid(871280)

-- MAIN APP DEPOTS / PACKAGES
addappid(871281, 1, "6d57833bc9201ae2cb86c56352b863279840f7de6baad99de2dd0655435a778e")
addappid(871282, 1, "ef128c78bfe765a3367d327bc3ecef8639d0798411bbc487a03d306f4e706fbe")
