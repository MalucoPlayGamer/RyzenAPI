-- Lua provided by RyzenAPI
-- Game: addappid(1279420)

-- MAIN APPLICATION
addappid(1279420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279421, 1, "af3c89a95ca1614a0e1f5012d3a747fdba9c7e942fecb609d5f11ff97a67b1ff")
