-- Lua provided by SkyAPI 
-- Game: Inside Jennifer
addappid(1754860)
addappid(1754861, 1, "a3af54ca0ddcae3460f0b6e9001b734519f2bb467862e29551b0061ee5f1afed")
addappid(2177600, 0, "824f8f6a59ac2118d60466080fc8c5cc6736fe256d348fd9ab6fadf3c33852c5")
