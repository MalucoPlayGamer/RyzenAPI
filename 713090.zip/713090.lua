-- Lua provided by RyzenAPI
-- Game: Zombie Bloxx

-- MAIN APPLICATION
addappid(713090)

-- MAIN APP DEPOTS / PACKAGES
addappid(713091, 1, "8d24959f5119832b31ea42f8d75d44f562d453bc70974e9d5262f07561be1df2")
