-- Lua provided by RyzenAPI
-- Game: Game: NALOGI 2

-- MAIN APPLICATION
addappid(841350)
-- Game: addappid(841350)

-- MAIN APP DEPOTS / PACKAGES
addappid(841351, 1, "0918ed90de40244db0583519bc1826a975ead1609133b3434b7931017bc989d7")
