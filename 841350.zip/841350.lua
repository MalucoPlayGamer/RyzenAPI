-- Lua provided by RyzenAPI 
-- Game: NALOGI 2
addappid(841350)
addappid(841351, 1, "0918ed90de40244db0583519bc1826a975ead1609133b3434b7931017bc989d7")
