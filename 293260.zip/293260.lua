-- Lua provided by RyzenAPI
-- Game: Card Hunter

-- MAIN APPLICATION
addappid(293260)

