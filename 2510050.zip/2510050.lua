-- Lua provided by RyzenAPI
-- Game: AppID 2510050

-- MAIN APPLICATION
addappid(2510050)
-- Game: addappid(2510050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510051, 1, "d669a42c116747f4277f37ffa6e48618e5c7dc3b686f9da933737e0c1879f4af")
