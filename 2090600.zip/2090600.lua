-- Lua provided by SkyAPI 
-- Game: Thistlemine
addappid(2090600)
addappid(2090601, 1, "10756945247fa335da5dd1b81559e73344bd1db1531f120d6f3c3716ae2cb698")
addappid(2090602, 1, "19f94471eb9b689f56a4d469d3662b0363d00dd3b72e4a0e389fbd482de9ec09")
