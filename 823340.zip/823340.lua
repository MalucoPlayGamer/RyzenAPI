-- Lua provided by RyzenAPI
-- Game: Round Mars

-- MAIN APPLICATION
addappid(823340)
addappid(830010)
-- Game: addappid(823340)

-- MAIN APP DEPOTS / PACKAGES
addappid(823341, 1, "c1702d3a53a77f3a47bd27f046198a614f2091bd5e179d262f44fe530a975448")
