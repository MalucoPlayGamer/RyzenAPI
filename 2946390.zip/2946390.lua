-- Lua provided by RyzenAPI
-- Game: Jump the Track

-- MAIN APPLICATION
addappid(2946390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946391, 1, "7fee4fc876abfdd0956ce2d74968ab2dfa1e2690f13a9f793f0ff25f4114d6e7")
