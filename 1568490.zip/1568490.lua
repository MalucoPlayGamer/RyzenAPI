-- Lua provided by RyzenAPI
-- Game: The Survivor After

-- MAIN APPLICATION
addappid(1568490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568491, 1, "75fb2fee35996176b282987281170317a390a856eeeb9d7d8017d393c489338b")

