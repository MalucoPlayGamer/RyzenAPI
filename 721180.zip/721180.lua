-- Lua provided by RyzenAPI
-- Game: Dustborn

-- MAIN APPLICATION
addappid(721180)
addappid(3153680)

-- MAIN APP DEPOTS / PACKAGES
addappid(721181, 1, "23ceb1d86e5aca23fa961043b1f7c8453a6a0fbaea2d7e6731503dd5714ae14d")

