-- Lua provided by RyzenAPI
-- Game: Beat Saber - Nirvana - "Smells Like Teen Spirit"

-- MAIN APPLICATION
addappid(2233135)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233135,0,"42262b51e2919a46205651409ec8b115db0994312f62e8555ea21b4728a71c32")

