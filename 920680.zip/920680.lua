-- Lua provided by RyzenAPI
-- Game: addappid(920680)

-- MAIN APPLICATION
addappid(920680)

-- MAIN APP DEPOTS / PACKAGES
addappid(920681, 1, "c163ad7768dd12840f1ec6ec28f295db8c3da81e77ea14729ab1d5ffd3552be5")
addappid(920682, 1, "abca3dcd364ae85063a10067dd0b2c1a09ac93229631df346d8a902ec9d30677")
addappid(920683, 1, "4ae66f438a8924600a5a31f477eef728798830d6429092a5f18d7ecba0afd2fd")
