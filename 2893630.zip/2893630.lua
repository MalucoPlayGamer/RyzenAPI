-- Lua provided by RyzenAPI
-- Game: Surmount Soundtrack

-- MAIN APPLICATION
addappid(2893630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893631, 1, "438430c0a85a91ac99223aade01d450433dc5ee1944beb4a88f17c146c334f64")
