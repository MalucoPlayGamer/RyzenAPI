-- Lua provided by RyzenAPI
-- Game: AppID 598340

-- MAIN APPLICATION
addappid(598340)

-- MAIN APP DEPOTS / PACKAGES
addappid(598341, 1, "f9910b4417f19d79a23aff369ef57b16291fd3f7d6f28f7a71a724dec1e9618b")

