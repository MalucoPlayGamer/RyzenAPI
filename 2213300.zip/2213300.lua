-- Lua provided by RyzenAPI
-- Game: Game: Might & Magic: Clash of Heroes - Definitive Edition

-- MAIN APPLICATION
addappid(2213300)
-- Game: addappid(2213300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213301, 1, "8c4e3ece3a273a60d9f657e2426ab58c6fb8ad0fa69949a61608a36cef4f563c")
