-- Lua provided by RyzenAPI
-- Game: Might & Magic: Clash of Heroes - Definitive Edition

-- MAIN APPLICATION
addappid(2213300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213301, 1, "8c4e3ece3a273a60d9f657e2426ab58c6fb8ad0fa69949a61608a36cef4f563c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
