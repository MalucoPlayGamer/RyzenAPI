-- Lua provided by RyzenAPI
-- Game: AppID 1198850

-- MAIN APPLICATION
addappid(1198850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198851, 1, "9fe940eb285d2d57383c4a5ed0fce947ecd10f6bc43af44abede4ecb78637930")
addappid(1198852, 1, "0a220e518335047c74c9be74833fd3d6221e0923d7d4e2aeebec5322269367fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
