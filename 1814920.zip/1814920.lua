-- Lua provided by RyzenAPI
-- Game: Bombyx

-- MAIN APPLICATION
addappid(1814920)
addappid(2219550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1814923,0,"b6b06ef910b0536d8035be3ccf6aa690207ef5f137efadffae110a41c45fefbb")

