-- Lua provided by RyzenAPI
-- Game: Bombyx

-- MAIN APPLICATION
addappid(1814920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814923,0,"b6b06ef910b0536d8035be3ccf6aa690207ef5f137efadffae110a41c45fefbb")
