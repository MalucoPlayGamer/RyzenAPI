-- Lua provided by RyzenAPI
-- Game: A Forgetful Loop Soundtrack

-- MAIN APPLICATION
addappid(1447680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447681, 1, "0aa2e130bff804585699758cb9b1667ca0a46e9c432683ade0d022adf5d6dff9")

