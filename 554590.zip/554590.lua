-- Lua provided by RyzenAPI
-- Game: Little Kingdom 2

-- MAIN APPLICATION
addappid(554590)

-- MAIN APP DEPOTS / PACKAGES
addappid(554591,0,"a7681d74b576e487f45075be2e9ae2c0e7cbfd4fc314d16d771d9fcb3b1ff1ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
