-- Lua provided by RyzenAPI
-- Game: Little Kingdom 2

-- MAIN APPLICATION
addappid(554590)

-- MAIN APP DEPOTS / PACKAGES
addappid(554591,0,"a7681d74b576e487f45075be2e9ae2c0e7cbfd4fc314d16d771d9fcb3b1ff1ab")

