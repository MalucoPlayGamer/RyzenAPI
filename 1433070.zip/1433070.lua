-- Lua provided by RyzenAPI 
-- Game: Into the Pyramid
addappid(1433070)
addappid(1433071, 1, "05ca4e94b1f4d060eb13cae161f037237d57c149d07bc58aaa66821c56ef2b48")
