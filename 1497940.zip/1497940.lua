-- Lua provided by RyzenAPI
-- Game: 1497940

-- MAIN APPLICATION
addappid(1497940)
-- Game: addappid(1497940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497941, 1, "aeb63400cf7c4b57c3b2540fea5e7162ac5d672d9d818a716baddc19bac02d19")
