-- Lua provided by RyzenAPI
-- Game: 2235920

-- MAIN APPLICATION
addappid(2235920)
-- Game: addappid(2235920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235921, 1, "96c28778cbcb14eb26e4b46d7724c56c3486ec2818050a13c876cfe06dc04d0b")
