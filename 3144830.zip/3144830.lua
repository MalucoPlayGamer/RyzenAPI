-- Lua provided by RyzenAPI
-- Game: addappid(3144830)

-- MAIN APPLICATION
addappid(3144830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144830,0,"46ec9fab404dcd3a5e0b2862b1f9c1a0410157b5071f35a086bd4f57f6b79beb")
