-- Lua provided by RyzenAPI
-- Game: 1868170

-- MAIN APPLICATION
addappid(1868170)
-- Game: addappid(1868170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868171, 1, "f154df4a3db1d8bdc4a4d12e40437ffaae407bda2ade06184b6519e425beec5f")
addappid(2054910, 0, "a01ce5abe52ea15038012fb9fdeadf79bd94abc813fae754fb6de08c2492ba12")
