-- Lua provided by RyzenAPI
-- Game: AppID 869780

-- MAIN APPLICATION
addappid(869780)

-- MAIN APP DEPOTS / PACKAGES
addappid(869781, 1, "b9df17efe3a43223ceec6e3d8b44a02beff3b3b213e36802285e2b68fa931be9")

