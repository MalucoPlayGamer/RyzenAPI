-- Lua provided by RyzenAPI
-- Game: All Alone: VR

-- MAIN APPLICATION
addappid(604830)

-- MAIN APP DEPOTS / PACKAGES
addappid(604831, 1, "1476b6f6f9f422544ecaab1a8c1e4932c939c085eee4d9f62eb322694fdf4acb")

