-- Lua provided by RyzenAPI
-- Game: Game: AppID 2315140

-- MAIN APPLICATION
addappid(2315140)
-- Game: addappid(2315140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315141, 1, "f0dffb20cf1497ee523073f6ed830ee81973673674b65690330650bff1a3dd16")
