-- Lua provided by RyzenAPI
-- Game: Femboys of the Phalanx

-- MAIN APPLICATION
addappid(1565080)
-- Game: addappid(1565080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565081, 1, "740673796593e16c341af7be03d19c60190c0e82f64afdc3fbe44292c93615c5")
