-- Lua provided by RyzenAPI
-- Game: Super ComboMan: Smash Edition

-- MAIN APPLICATION
addappid(468650)

-- MAIN APP DEPOTS / PACKAGES
addappid(468651, 1, "c73a80a13655969f34eefd4681aee0cd8fea0b328942680abf7e1310eb677275")
