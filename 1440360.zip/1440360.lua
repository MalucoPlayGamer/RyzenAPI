-- Lua provided by RyzenAPI
-- Game: addappid(1440360)

-- MAIN APPLICATION
addappid(1440360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440361, 1, "95f99e1cc67a65a09fe8b5bf12dea273474c7eaee1704835eb655a4bb431cdd9")
