-- Lua provided by RyzenAPI
-- Game: Silent Sector

-- MAIN APPLICATION
addappid(1159680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159681, 1, "a138eba1e14b7cd928eed8e8b9826924200b86b0e6a63643b5fc18955660c34d")

