-- Lua provided by RyzenAPI
-- Game: addappid(1993750)

-- MAIN APPLICATION
addappid(1993750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993751, 1, "b4c9bdd5f0b3b51bc389bf0bdd6649006ab1c0c43c8d4cef1e6aae54c6a726ec")
