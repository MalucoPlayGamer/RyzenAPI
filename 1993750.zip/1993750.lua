-- Lua provided by SkyAPI 
-- Game: Demise Sanctuary Demo
addappid(1993750)
addappid(1993751, 1, "b4c9bdd5f0b3b51bc389bf0bdd6649006ab1c0c43c8d4cef1e6aae54c6a726ec")
