-- Lua provided by RyzenAPI
-- Game: 1277280

-- MAIN APPLICATION
addappid(1277280)
-- Game: addappid(1277280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277280,0,"97b1a6e486453593de4c0849fef262ef5101f65a23e7580c9edef9a14ce2bfac")
