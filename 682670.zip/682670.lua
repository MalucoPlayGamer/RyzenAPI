-- Lua provided by RyzenAPI
-- Game: Game: 初颜 - The Prototype

-- MAIN APPLICATION
addappid(682670)
-- Game: addappid(682670)

-- MAIN APP DEPOTS / PACKAGES
addappid(682671, 1, "d4d4dbf84e7ca0d6f85d234283f68687290a037dc8c28ae6f4a7fcd6bd6ae42c")
