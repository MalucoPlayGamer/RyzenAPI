-- Lua provided by RyzenAPI
-- Game: Chaos Road

-- MAIN APPLICATION
addappid(1514740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514741, 1, "7168478190732b1d9c2b6100da8186b6be1a34f66ad66d25b154a77bd57ef655")

