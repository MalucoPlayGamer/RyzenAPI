-- Lua provided by RyzenAPI
-- Game: Thymesia

-- MAIN APPLICATION
addappid(1343240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1343241, 1, "ad9a8b0ab098a95291acac64ad83e29e116602c5adb0c53f7fb690b853463eca")
addappid(2118360, 0, "837e400e70207d8424743048821b734c6bf2764bef515a95ad6a4e2ee4e236ea")

