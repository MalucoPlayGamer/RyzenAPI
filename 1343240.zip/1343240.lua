-- Lua provided by RyzenAPI
-- Game: Thymesia

-- MAIN APPLICATION
addappid(1343240)
-- Game: addappid(1343240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343241, 1, "ad9a8b0ab098a95291acac64ad83e29e116602c5adb0c53f7fb690b853463eca")
addappid(2118360, 0, "837e400e70207d8424743048821b734c6bf2764bef515a95ad6a4e2ee4e236ea")
