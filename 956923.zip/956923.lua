-- Lua provided by RyzenAPI
-- Game: 956923

-- MAIN APPLICATION
addappid(956923)

-- MAIN APP DEPOTS / PACKAGES
addappid(956923,0,"d77f6b2bb40aeec092cb8e56452bd5a2b4466d29cca31032bdf2035548192b7b")

