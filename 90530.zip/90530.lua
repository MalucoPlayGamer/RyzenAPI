-- Lua provided by RyzenAPI
-- Game: AppID 90530

-- MAIN APPLICATION
addappid(90530)

-- MAIN APP DEPOTS / PACKAGES
addappid(90531, 1, "038ecab5ba9a96dadbf35372f036fd84af7b607a3e286b7ad056ccfcd990a96a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(236641)
addappid(236642)
addappid(236645)
