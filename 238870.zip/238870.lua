-- Lua provided by RyzenAPI
-- Game: Citadels

-- MAIN APPLICATION
addappid(238870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(238871, 1, "fd41e2943f4e77eac4e02d403d7cc8b67bae4f37cb64298c9396277811115f2c")

