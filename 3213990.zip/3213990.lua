-- Lua provided by RyzenAPI
-- Game: 3213990

-- MAIN APPLICATION
addappid(3213990)
-- Game: addappid(3213990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213991, 1, "6ddb18eb0ce6e98761b559fbe95a369b10e1aa429d905dc044e8a75ff3603359")
