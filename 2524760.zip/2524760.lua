-- Lua provided by SkyAPI 
-- Game: AppID 2524760
addappid(2524760)
addappid(2524761, 1, "c066928ca10fc0bb5e0e32fd2d0f66bf0c111ea1c23d7d3ec91d2e0f0329fabe")
