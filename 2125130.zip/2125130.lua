-- Lua provided by RyzenAPI
-- Game: addappid(2125130)

-- MAIN APPLICATION
addappid(2125130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125131, 1, "44f68057c06ad71307624b25e17e91faccbba2bc6f3c0624fde794d20542c115")
