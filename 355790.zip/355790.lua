-- Lua provided by RyzenAPI
-- Game: Styx: Shards of Darkness

-- MAIN APPLICATION
addappid(355790)
addappid(465250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(355791, 1, "f6f2eddd25996d1bcab2d0e2d2f58a8d2c7b68151c78d0471ab64ebf83597338")
addappid(355798, 1, "b8b78e28377ae79a37aebc418943f5251b3f40a1876ce97e491e625cdfb2de5e")
addappid(465251, 1, "6153def17eb931ae46694c4c97df2b398ca6298270d699cec191eaf303b142a6")

