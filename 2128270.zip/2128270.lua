-- Lua provided by RyzenAPI
-- Game: Path of Achra

-- MAIN APPLICATION
addappid(2128270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128272,0,"8c97f3924201b2f84b59712d5dcbb2db8014a46f3f6bf99706526c75652b07a8")

