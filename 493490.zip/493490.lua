-- Lua provided by RyzenAPI 
-- Game: City Car Driving
addappid(493490)
addappid(493491, 1, "c4f4405ba8654ac03d7a74431206dc52bb2a92366d4573cbd39f79ca902cb68b")
addappid(967230, 0, "2c117136658608f75a3b2f1e578a87ee165e28456a29dd5afadf7b49ab35d3c2")
