-- Lua provided by RyzenAPI
-- Game: City Car Driving

-- MAIN APPLICATION
addappid(493490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(493491, 1, "c4f4405ba8654ac03d7a74431206dc52bb2a92366d4573cbd39f79ca902cb68b")
addappid(967230, 0, "2c117136658608f75a3b2f1e578a87ee165e28456a29dd5afadf7b49ab35d3c2")

