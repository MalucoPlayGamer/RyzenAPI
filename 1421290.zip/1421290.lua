-- Lua provided by RyzenAPI 
-- Game: Battle Shapers
addappid(1421290)
addappid(1421291, 1, "d6fd93b33b555a19ed595dd17d6870d3d9766384a03610931c27b6c85609a6e4")
