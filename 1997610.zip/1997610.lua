-- Lua provided by SkyAPI 
-- Game: Offenders
addappid(1997610)
addappid(1997611, 1, "b4b5177ec2ab90069b0c7aca08181bf0305b4690ea8ffe447ce6cf7f2f583f8c")
