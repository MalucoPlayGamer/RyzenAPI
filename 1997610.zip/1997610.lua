-- Lua provided by RyzenAPI
-- Game: Offenders

-- MAIN APPLICATION
addappid(1997610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997611, 1, "b4b5177ec2ab90069b0c7aca08181bf0305b4690ea8ffe447ce6cf7f2f583f8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
