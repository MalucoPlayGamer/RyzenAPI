-- Lua provided by RyzenAPI
-- Game: Offenders

-- MAIN APPLICATION
addappid(1997610)
-- Game: addappid(1997610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997611, 1, "b4b5177ec2ab90069b0c7aca08181bf0305b4690ea8ffe447ce6cf7f2f583f8c")
