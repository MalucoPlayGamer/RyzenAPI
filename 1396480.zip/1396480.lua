-- Lua provided by RyzenAPI
-- Game: Game: MonsterSoft

-- MAIN APPLICATION
addappid(1396480)
addappid(1453210)
-- Game: addappid(1396480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396481, 1, "2722c41ef2f9dc3d245d44dd1bbfc4080778576d13d4d2dd57cc4dd8348a2332")
