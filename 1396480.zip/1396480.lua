-- Lua provided by RyzenAPI
-- Game: MonsterSoft

-- MAIN APPLICATION
addappid(1396480)
addappid(1453210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396481, 1, "2722c41ef2f9dc3d245d44dd1bbfc4080778576d13d4d2dd57cc4dd8348a2332")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1399810)
