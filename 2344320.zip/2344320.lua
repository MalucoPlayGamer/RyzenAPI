-- Lua provided by RyzenAPI
-- Game: Eldegarde

-- MAIN APPLICATION
addappid(2344320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344321, 1, "a080d0b573b949016080909f58b6c1efbd2c40dfd4d331560cfbbe6a6ff1c8b8")
