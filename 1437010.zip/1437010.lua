-- Lua provided by RyzenAPI
-- Game: Game: The Last Spell: Prologue

-- MAIN APPLICATION
addappid(1437010)
-- Game: addappid(1437010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437011, 1, "8a70de3b60d64070d742a2f8ac79b6855c7ff6974bad7851fa83d4bc70a998f4")
