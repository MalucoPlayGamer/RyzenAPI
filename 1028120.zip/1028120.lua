-- Lua provided by RyzenAPI
-- Game: 1028120

-- MAIN APPLICATION
addappid(1028120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028120,0,"a4ab9c65fd912ebb1e91197ff73bd2818e89fafb02c40ac858f19f432d7e4cae")

