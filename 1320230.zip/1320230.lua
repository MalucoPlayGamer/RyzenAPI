-- Lua provided by RyzenAPI
-- Game: AppID 1320230

-- MAIN APPLICATION
addappid(1320230)
-- Game: addappid(1320230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320231, 1, "f542fcdd5a4ba6c63dc1a9cf4576e7dec795899af8d92de849cc767f03088538")
