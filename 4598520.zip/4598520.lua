-- Lua provided by RyzenAPI
-- Game: 修仙长生界

-- MAIN APPLICATION
addappid(4598520)
