-- Lua provided by SkyAPI 
-- Game: Starr Mazer: DSP
addappid(462100)
addappid(462101, 1, "750a2686c89c41eee1ce032c379cd68ecf7de67fe53f7ad4aa71a813981bc716")
