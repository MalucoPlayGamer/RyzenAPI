-- Lua provided by RyzenAPI
-- Game: AppID 2005570

-- MAIN APPLICATION
addappid(2005570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005571, 1, "793cbe694c3957f3fc6cd4ae71ff8cd5a1f57c5f459d50f71c40c081f4fc1c87")
