-- Lua provided by RyzenAPI
-- Game: Game: AppID 871360

-- MAIN APPLICATION
addappid(871360)
-- Game: addappid(871360)

-- MAIN APP DEPOTS / PACKAGES
addappid(871361, 1, "4bb47cd36bae0164d8a929e8859dde81fe18b81f8d30b7234fbf0cc2ce2a50a0")
