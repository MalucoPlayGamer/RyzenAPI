-- Lua provided by RyzenAPI
-- Game: Fix My Cat Doc

-- MAIN APPLICATION
addappid(2124660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124661, 1, "cf6057d3b05d8b7de20b6a33d38f9369191d6944ce1f08b473f2e34687779953")

