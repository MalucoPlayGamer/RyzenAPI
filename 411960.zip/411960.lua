-- Lua provided by RyzenAPI 
-- Game: AppID 411960
addappid(411960)
addappid(411961, 1, "34db156a8c9a6e1514dd307cbff3093dd6fbb20b3b43da55cc96193ad2767f5c")
addappid(411962, 1, "c7127930bdac5bbdc32b399e21c5aa8835e0672e4137c142f620340b8c2beb10")
addappid(577131, 0, "c779dbda34eb520f838bb4849dbe74bdb6748815a326fe05a75c9c3d390762f8")
