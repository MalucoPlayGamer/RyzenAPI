-- Lua provided by RyzenAPI
-- Game: ふぇにきのミニゲームゆにばぁ～す

-- MAIN APPLICATION
addappid(3453150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453151, 1, "9331003556b3df4e70c4aaa9bdb4becfe4fa4222bf7011b7af5e1e9acf27b5c8")
