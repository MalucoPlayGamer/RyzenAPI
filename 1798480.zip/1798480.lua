-- Lua provided by RyzenAPI
-- Game: 1798480

-- MAIN APPLICATION
addappid(1798480)
-- Game: addappid(1798480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798481, 1, "a31710ecd994ed4b265161c9c6a627bd84ea06e0ac0435cc8e05206efebe74f5")
