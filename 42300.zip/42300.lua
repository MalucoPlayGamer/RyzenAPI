-- Lua provided by RyzenAPI
-- Game: AppID 42300

-- MAIN APPLICATION
addappid(42300)
-- Game: addappid(42300)

-- MAIN APP DEPOTS / PACKAGES
addappid(42301, 1, "21388217a65c0c947e137635f1ac47007cb9a09b640271053f60032cbb8e574c")
addappid(42302, 1, "3f9891c4d916c6e18ee8b09ae4c4ca58ac1a01a45ebb27f59aaaeda8d98d492f")
