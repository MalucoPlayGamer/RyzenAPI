-- Lua provided by RyzenAPI
-- Game: FACE LOVE: Face Designer

-- MAIN APPLICATION
addappid(3401050)
addappid(3408910)

