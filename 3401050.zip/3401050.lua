-- Lua provided by RyzenAPI
-- Game: FACE LOVE: Face Designer

-- MAIN APPLICATION
addappid(3401050)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3408910)
