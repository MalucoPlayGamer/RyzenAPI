-- Lua provided by SkyAPI 
-- Game: Nefarious
addappid(448290)
addappid(448291, 1, "efc613e61a0785bbc7b21077d31cede2de56dc611775bac00199fdf04a82ccbb")
