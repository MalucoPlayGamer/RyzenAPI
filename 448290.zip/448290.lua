-- Lua provided by RyzenAPI
-- Game: Nefarious

-- MAIN APPLICATION
addappid(448290)

-- MAIN APP DEPOTS / PACKAGES
addappid(448291, 1, "efc613e61a0785bbc7b21077d31cede2de56dc611775bac00199fdf04a82ccbb")
