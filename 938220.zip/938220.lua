-- Lua provided by RyzenAPI
-- Game: addappid(938220)

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(229006)
addappid(229020)
addappid(938220)

-- MAIN APP DEPOTS / PACKAGES
addappid(938222,0,"da77eedb3ea678e91dd821806cad983ca70a7d23bc2e0aa55109d6567f88d3b2")
addappid(1087590,0,"784c161dbb32a099a4ab5750a136e8f89fb2b356ed00473b9a9657dc7a58befd")
addappid(1106130,0,"535bc12b1a9c96bc9d94b9a40afb75e18c850688433c29401fd5fb46fba2c882")
addappid(1123390,0,"8520204103c6bbf612aab08b6e896cbab58a59850091edee7224e9c62e97cb34")
