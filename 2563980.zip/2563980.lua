-- Lua provided by SkyAPI 
-- Game: Little Loki & The Yggdrasil Maze
addappid(2563980)
addappid(2563981, 1, "29361881f8d8fb46808d1add75884094309b90565ddab8cef2378ac73794d6f6")
addappid(2563982, 1, "62c34d33a3f743a8c3fdd864f12fa777bfb48389c3c2c24ad35f580d94d3ce32")
