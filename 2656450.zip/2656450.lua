-- Lua provided by RyzenAPI
-- Game: survial

-- MAIN APPLICATION
addappid(2656450)
-- Game: addappid(2656450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656451, 1, "9f2c016ef9e809c03a093d92ac84d81db171ca3d326066548549ab618fb2febd")
