-- Lua provided by RyzenAPI
-- Game: addappid(450650)

-- MAIN APPLICATION
addappid(450650)

-- MAIN APP DEPOTS / PACKAGES
addappid(450651, 1, "2d0bb83e770fa4577f7e65ce6d15a0421e5442407c165a1b22b6004983ddceed")
