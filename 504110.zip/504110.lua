-- Lua provided by RyzenAPI
-- Game: Game: AppID 504110

-- MAIN APPLICATION
addappid(504110)
addappid(756181)
-- Game: addappid(504110)

-- MAIN APP DEPOTS / PACKAGES
addappid(504111, 1, "0230e1608d347d1f57c2ef132d9c525fdac0dd02864dc0228c6decca0741933c")
