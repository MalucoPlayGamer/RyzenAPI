-- Lua provided by RyzenAPI
-- Game: The Longest Five Minutes

-- MAIN APPLICATION
addappid(504110)
addappid(756181)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(504111, 1, "0230e1608d347d1f57c2ef132d9c525fdac0dd02864dc0228c6decca0741933c")
