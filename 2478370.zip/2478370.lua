-- Lua provided by RyzenAPI
-- Game: Ghostrunner 2 Demo

-- MAIN APPLICATION
addappid(2478370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478371, 1, "f17a70e7ba4cc4cbb51bc4f88512c68b5f0db92aeff6523cc3d78e68ca79f75e")
