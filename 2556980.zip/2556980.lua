-- Lua provided by RyzenAPI
-- Game: 2556980

-- MAIN APPLICATION
addappid(2556980)
-- Game: addappid(2556980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556981, 1, "896d1715a77a5ea1934f2ed4bcaae6d02d46b6fb18a6ea5b51c2a5d8eb31baf0")
