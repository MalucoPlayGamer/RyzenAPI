-- Lua provided by RyzenAPI
-- Game: Game: Arrogation: Unlight of Day Demo

-- MAIN APPLICATION
addappid(2155160)
-- Game: addappid(2155160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155161, 1, "be357df9f31c58f1cd0b738fcea1c769e36c9b4911407de89cb5f7eeddde9eba")
