-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2024

-- MAIN APPLICATION
addappid(2328780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2328781, 1, "73f36384be5a4f42c637781cb27525c43d3239cb24c3784c14ae698668f7930b")

