-- Lua provided by RyzenAPI
-- Game: Game: Pro Basketball Manager 2024

-- MAIN APPLICATION
addappid(2328780)
-- Game: addappid(2328780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328781, 1, "73f36384be5a4f42c637781cb27525c43d3239cb24c3784c14ae698668f7930b")
