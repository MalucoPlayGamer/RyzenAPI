-- Lua provided by RyzenAPI
-- Game: Game: /R - A Neurodivergent Thriller

-- MAIN APPLICATION
addappid(3396850)
-- Game: addappid(3396850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396851, 1, "2847c079890b81fac6d942b29f6f5e107dd656b6d671b68aeff1211ae41e73ed")
