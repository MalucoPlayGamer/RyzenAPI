-- Lua provided by RyzenAPI
-- Game: /R - A Neurodivergent Thriller

-- MAIN APPLICATION
addappid(3396850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396851, 1, "2847c079890b81fac6d942b29f6f5e107dd656b6d671b68aeff1211ae41e73ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
