-- Lua provided by RyzenAPI
-- Game: Pyramid Game

-- MAIN APPLICATION
addappid(2936160)
addappid(2969080)
addappid(2969090)
addappid(2969100)
addappid(2969110)
addappid(2969120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936161, 1, "8b889a7c03a33061e0c644f3f73bd39eca4f02fe20b1986fd50f366423d7e820")
addappid(2936162, 1, "0b0262317cae58f99454ae13c503a9486bf88fe145700396716109e78e356409")

