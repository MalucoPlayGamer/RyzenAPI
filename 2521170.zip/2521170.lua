-- Lua provided by RyzenAPI
-- Game: Looking For Fael

-- MAIN APPLICATION
addappid(2521170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521171,0,"14fe7d52a5f941706c9c7386f22d0d1f8f44f02f59671cec9efd52ab81704395")
addappid(2521172,0,"1efeab27161fc9e875c7b4e8c44f4da09a5c2ee1376ff955e76304cdc9f31acf")

