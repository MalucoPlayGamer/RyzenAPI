-- Lua provided by RyzenAPI
-- Game: Looking For Fael

-- MAIN APPLICATION
addappid(2521170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(2521171,0,"14fe7d52a5f941706c9c7386f22d0d1f8f44f02f59671cec9efd52ab81704395")
addappid(2521172,0,"1efeab27161fc9e875c7b4e8c44f4da09a5c2ee1376ff955e76304cdc9f31acf")

