-- Lua provided by RyzenAPI
-- Game: Game: AppID 912170

-- MAIN APPLICATION
addappid(912170)
-- Game: addappid(912170)

-- MAIN APP DEPOTS / PACKAGES
addappid(912171, 1, "c0ab53207618897cd5183b18eaf68351f11c0f746d80322050258f8ed50a4322")
