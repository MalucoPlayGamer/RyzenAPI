-- Lua provided by RyzenAPI
-- Game: Game: AppID 1204440

-- MAIN APPLICATION
addappid(1204440)
-- Game: addappid(1204440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204441, 1, "6255bcdefa3bee14c9bc8ffa05389b08c79bb812e5a32b92977e23bca5562972")
