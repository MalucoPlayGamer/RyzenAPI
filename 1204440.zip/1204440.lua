-- Lua provided by SkyAPI 
-- Game: AppID 1204440
addappid(1204440)
addappid(1204441, 1, "6255bcdefa3bee14c9bc8ffa05389b08c79bb812e5a32b92977e23bca5562972")
