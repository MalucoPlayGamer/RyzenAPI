-- Lua provided by RyzenAPI
-- Game: Nosy Little Fly

-- MAIN APPLICATION
addappid(1961500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961501, 1, "31c62bd6501b4c883cdffcd1c8a1951cd8a9c52eaf18735a731f70bd63301142")
