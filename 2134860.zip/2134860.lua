-- Lua provided by RyzenAPI
-- Game: My Ex-future Family

-- MAIN APPLICATION
addappid(2134860)
addappid(2599110)
addappid(2778450)
addappid(3097580)
addappid(3097890)
addappid(3158710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2134861, 1, "9290a0114ee7ce8b8094f5859bd0c3cf8b28b316835f8bd60ac7830ab7a1d3cc")

