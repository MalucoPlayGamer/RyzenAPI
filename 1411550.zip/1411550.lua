-- Lua provided by RyzenAPI
-- Game: 1411550

-- MAIN APPLICATION
addappid(1411550)
-- Game: addappid(1411550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411551, 1, "550108744aaf5fbbba1a199f6c5f25f9896312066c7221073dfd7784c7ac6a23")
