-- Lua provided by SkyAPI 
-- Game: Super Smash Gals: Ultimate Orgy
addappid(2496270)
addappid(2496271, 1, "49c8c2515509d5d42fb0018d6ecc75e8c89c3b3404e1e6b781c1edeceb1b796b")
addappid(2496272, 1, "7947356047d3e2a94bbd5261bb382e736d0f28e0905b3b0187b0e1d5eb4d2d05")
