-- Lua provided by SkyAPI 
-- Game: Angel Legion
addappid(1333350)
addappid(1333351, 1, "d261f1c5fd56aa71f668d873476793628c85f826b79dde306c3375a96d51f610")
addappid(1333352, 1, "2b212d2a86cc889645c7da7359add44dfc65cf493fb9f30ade3fc3a7cb95240f")
