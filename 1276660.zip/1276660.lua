-- Lua provided by RyzenAPI
-- Game: addappid(1276660)

-- MAIN APPLICATION
addappid(1276660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276661, 1, "833a53bf4aaaa0e5ee02d5e5155f82b91e55dde85a069b2cac4115110d57a609")
