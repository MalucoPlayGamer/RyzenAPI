-- Lua provided by RyzenAPI
-- Game: AppID 2816430

-- MAIN APPLICATION
addappid(2816430)
-- Game: addappid(2816430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2816431, 1, "e1049bbd51b1fb8334f7ccb5180d4fa4e0c0941e731a5cfdd821ad212af57f6c")
