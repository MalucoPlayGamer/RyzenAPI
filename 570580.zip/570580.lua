-- Lua provided by RyzenAPI
-- Game: Game: Zork Anthology

-- MAIN APPLICATION
addappid(570580)
-- Game: addappid(570580)

-- MAIN APP DEPOTS / PACKAGES
addappid(570581, 1, "906be1b8edafbc47ba23f71d47ee595617536108e84c36e23986ef5382c48e59")
