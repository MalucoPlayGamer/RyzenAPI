-- Lua provided by SkyAPI 
-- Game: Terra Atlantis
addappid(1638130)
addappid(1638131, 1, "5b264a443b021b1e21aaa7d57ba07860bd8524c75d5e22b88138be819a4ab9fe")
