-- Lua provided by RyzenAPI
-- Game: Terra Atlantis

-- MAIN APPLICATION
addappid(1638130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638131, 1, "5b264a443b021b1e21aaa7d57ba07860bd8524c75d5e22b88138be819a4ab9fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
