-- Lua provided by RyzenAPI
-- Game: Game: Unique Identy

-- MAIN APPLICATION
addappid(3205480)
-- Game: addappid(3205480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205481, 1, "bb97e0474da8bae14f9be6f2ce722b9f3585b7c6cad25d5a9e5de5de0f813b0e")
