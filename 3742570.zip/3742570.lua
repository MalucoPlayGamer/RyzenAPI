-- Lua provided by RyzenAPI
-- Game: Atelier Yumia - "Perfect Butler" Costume for Viktor

-- MAIN APPLICATION
addappid(3742570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742570,0,"3329194ea955b33111621ca9a795583ff0f42a7b4e752285ea7b51a65e5e7a74")
