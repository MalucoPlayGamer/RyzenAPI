-- Lua provided by RyzenAPI
-- Game: 2845620

-- MAIN APPLICATION
addappid(2845620)
-- Game: addappid(2845620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845622,0,"34b8abd44de6e56a61854566fa3a0650d6536f3f95ba4868fbda0b7f95609a75")
