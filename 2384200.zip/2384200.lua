-- Lua provided by RyzenAPI
-- Game: Game: Thriving City: Song Soundtrack

-- MAIN APPLICATION
addappid(2384200)
-- Game: addappid(2384200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384201, 1, "386801e223dd1ce86b22e3e87c39066ca981b697ffec6ceedaac2f94879f36be")
addappid(2384202, 1, "174da132646f7f7f275f52519f38fc61463cea4ad49601ffecd76be24f13489c")
