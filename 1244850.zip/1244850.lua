-- Lua provided by RyzenAPI
-- Game: Game: Witch College 2

-- MAIN APPLICATION
addappid(1244850)
addappid(1247700)
-- Game: addappid(1244850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244851, 1, "0dc18696dc464793aa643a63ef9ca067fdcf703eedc4ca9b4a50ccd80431805e")
