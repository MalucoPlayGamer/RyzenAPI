-- Lua provided by RyzenAPI
-- Game: 460870

-- MAIN APPLICATION
addappid(460870)
-- Game: addappid(460870)

-- MAIN APP DEPOTS / PACKAGES
addappid(460871, 1, "8535c2aa7928bc41dcffa922fa29eef30cec9125039dac50b60d7cc4f3abfa4e")
