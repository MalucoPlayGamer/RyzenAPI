-- Lua provided by RyzenAPI
-- Game: 夜永 Eternal Love Soundtrack

-- MAIN APPLICATION
addappid(1503840)
-- Game: addappid(1503840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503841, 1, "debc53e7126d51221f199ff9a7cec6e4aeedae4097f1661f830169b19b9101e4")
addappid(1503842, 1, "ab37471dabe377c91611e4ee03479d97e26086f0fb5ed6b9d92ecac4f2542c10")
