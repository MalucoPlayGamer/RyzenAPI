-- Lua provided by RyzenAPI
-- Game: 421610

-- MAIN APPLICATION
addappid(421610)
-- Game: addappid(421610)

-- MAIN APP DEPOTS / PACKAGES
addappid(421611, 1, "9debbbe9b4e64637f756d4fae68f6bc08bad44ffbdbafd4dbc07c7c7daba13b3")
