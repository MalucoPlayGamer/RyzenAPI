-- Lua provided by RyzenAPI
-- Game: Game: Waifu Fighter

-- MAIN APPLICATION
addappid(1757490)
-- Game: addappid(1757490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757491, 1, "9e809d3b1bd4b269cb3b1449e33d438a4fe796b25d031e409c2866d27cac4fe2")
addappid(1757492, 1, "a965d3c062a4ea27dd4aae06ac154151f38cd49a03d6c24fa1a434578f2f9ce6")
addappid(2202141, 0, "1251e6d34914c7e7a106445f2b397ee32b418e4cc3e098cc5b60e9ba756360b6")
addappid(2202142, 0, "9835f51057a2dee7f67395198851cca45cf8271223cdd1ee6bf4ef5b2be7b122")
