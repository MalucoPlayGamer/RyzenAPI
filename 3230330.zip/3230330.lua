-- Lua provided by RyzenAPI
-- Game: Hex Bots

-- MAIN APPLICATION
addappid(3230330)
addappid(3669410)

