-- Lua provided by RyzenAPI
-- Game: Hex Bots

-- MAIN APPLICATION
addappid(3230330)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3669410)
