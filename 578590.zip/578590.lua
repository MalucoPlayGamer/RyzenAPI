-- Lua provided by RyzenAPI
-- Game: City Siege: Faction Island

-- MAIN APPLICATION
addappid(578590)

-- MAIN APP DEPOTS / PACKAGES
addappid(578591, 1, "6dba307cc6efc93b079d9d210dc678059243e1e4afca4d92ce3cd5a3975c5f3d")
