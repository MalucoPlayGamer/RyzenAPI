-- Lua provided by RyzenAPI
-- Game: Puzzle - LINES AND KNOTS

-- MAIN APPLICATION
addappid(228990)
addappid(1227750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231348,0,"445781e789f42ef1ee95891ebb6b4d68c37ac0379e0be0fab0efc30df79619de")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1231340)
addappid(1404900)
addappid(1404901)
addappid(1404910)
addappid(2700830)
