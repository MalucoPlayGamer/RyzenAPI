-- Lua provided by RyzenAPI
-- Game: 1754690

-- MAIN APPLICATION
addappid(1754690)
-- Game: addappid(1754690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754690,0,"2234668fadcf8604d2a6d54d11cb91bc1ac801765a437a97e9d6cbcbe4c4ecde")
