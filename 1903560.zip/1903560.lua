-- Lua provided by RyzenAPI
-- Game: Game: Atomic Picnic

-- MAIN APPLICATION
addappid(1903560)
-- Game: addappid(1903560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903561, 1, "101090ea8a8c59cbcf29efee18361bfa5058a83a4a1a237659147e10c0d19108")
