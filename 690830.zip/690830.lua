-- Lua provided by RyzenAPI
-- Game: Foundation

-- MAIN APPLICATION
addappid(690830)
addappid(4713280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(690831, 1, "a0df1cd93c1681e0839c3d7a86e7de7b7af07d07b00cc495896697b1fda49961")
addappid(3482250, 0, "c10e61648bc4b16350ebfac52a6d56f7282c1442a4f3c49e04bb9a7dd4693717")

