-- Lua provided by RyzenAPI
-- Game: 690830

-- MAIN APPLICATION
addappid(690830)
-- Game: addappid(690830)

-- MAIN APP DEPOTS / PACKAGES
addappid(690831, 1, "a0df1cd93c1681e0839c3d7a86e7de7b7af07d07b00cc495896697b1fda49961")
addappid(3482250, 0, "c10e61648bc4b16350ebfac52a6d56f7282c1442a4f3c49e04bb9a7dd4693717")
