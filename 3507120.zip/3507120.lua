-- Lua provided by RyzenAPI
-- Game: addappid(3507120)

-- MAIN APPLICATION
addappid(3507120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3507121, 1, "44dc815d32e5906fbef21f4f0a3f78f1fbbda81ea88a9e66a18610dd62ae230f")
