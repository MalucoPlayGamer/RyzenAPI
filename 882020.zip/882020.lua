-- Lua provided by RyzenAPI
-- Game: AppID 882020

-- MAIN APPLICATION
addappid(882020)
addappid(974350)
addappid(974351)
addappid(974352)
addappid(974353)
addappid(974354)
addappid(974360)
addappid(974361)
addappid(974362)
addappid(974363)
addappid(974364)

-- MAIN APP DEPOTS / PACKAGES
addappid(882021, 1, "98e4bc3ec881ff2c64e27355a79009610767d35116475913dd052519969971d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
