-- Lua provided by RyzenAPI
-- Game: AppID 882020

-- MAIN APPLICATION
addappid(882020)
addappid(974350)
addappid(974351)
addappid(974352)
addappid(974353)
addappid(974354)
addappid(974360)
addappid(974361)
addappid(974362)
addappid(974363)
addappid(974364)
-- Game: addappid(882020)

-- MAIN APP DEPOTS / PACKAGES
addappid(882021, 1, "98e4bc3ec881ff2c64e27355a79009610767d35116475913dd052519969971d4")
