-- Lua provided by RyzenAPI
-- Game: AppID 1225570

-- MAIN APPLICATION
addappid(1225570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225571, 1, "bfce858492701c48e90b69a9bb8b6e75727d244141d4e65c24d70623208ee965")
addappid(1225572, 1, "49a81f49ead1348c551713f50e75af7bce4af74de5a19f9246cacf465b5a5bb8")
addappid(1225573, 1, "d280c918fae8a156564bc0d93d9d68629413986db630e7d51aed031278438394")
addappid(1225574, 1, "bb268ac48611b1139830d5c70a051594c339996762442ddaa2bd08534c612187")
addappid(1225575, 1, "8e66a428751567b5e0d99c1bc39aca60946a767e0eca29d28b0581c114aa66e1")
addappid(1225576, 1, "76ecc115adc73c029729a373f5a7ddf4f364536eb05629e6d22df2afac2cc603")
addappid(1225577, 1, "ca68bd4ee628af72fd03f078b10e0303f30365fb52984cf216deba9008900c39")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1282800)
