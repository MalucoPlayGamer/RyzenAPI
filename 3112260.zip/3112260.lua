-- Lua provided by RyzenAPI
-- Game: Virtua Fighter 5 R.E.V.O. World Stage

-- MAIN APPLICATION
addappid(3112260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112261, 1, "e6f1715a5b59614a89b1dd93f5b2f9c4078e5365b885651d49acfbfc4df8ad89")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3282760)
addappid(3282770)
addappid(3282780)
addappid(3353780)
addappid(3419340)
addappid(3761410)
