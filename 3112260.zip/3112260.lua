-- Lua provided by RyzenAPI
-- Game: Game: Virtua Fighter 5 R.E.V.O. World Stage

-- MAIN APPLICATION
addappid(3112260)
-- Game: addappid(3112260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112261, 1, "e6f1715a5b59614a89b1dd93f5b2f9c4078e5365b885651d49acfbfc4df8ad89")
