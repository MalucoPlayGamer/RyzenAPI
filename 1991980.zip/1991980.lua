-- Lua provided by RyzenAPI
-- Game: AppID 1991980

-- MAIN APPLICATION
addappid(1991980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991981, 1, "ab842d3e679523d64cf3b64195cdaf7c2ac81ab5d18a1dae1022f2633a8d24f4")

