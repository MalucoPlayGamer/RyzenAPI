-- Lua provided by RyzenAPI
-- Game: Game: Beyond The Heavens

-- MAIN APPLICATION
addappid(806180)
-- Game: addappid(806180)

-- MAIN APP DEPOTS / PACKAGES
addappid(806181, 1, "359a497d13a820411bf65fee3eb5273db590f2b3317f956db7d8ae45bdb08d30")
