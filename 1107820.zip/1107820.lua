-- Lua provided by RyzenAPI
-- Game: Pushy and Pully in Blockland

-- MAIN APPLICATION
addappid(1107820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107821, 1, "abd9ecd05c70a06ceb94a240107e4d37db18a5b2f922bc50154317a401af9a0e")
addappid(1107822, 1, "797c9e2eda83dc50d49fd682ef987eabea19890c28e4966b5e81bc73011e1b19")
addappid(1107823, 1, "60ca3619bc72d79d6cb7b809c3c4d7fdb732568e5818976aae3f56b6d83468e4")
