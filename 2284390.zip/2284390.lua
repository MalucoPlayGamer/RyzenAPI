-- Lua provided by RyzenAPI 
-- Game: Castle Kingdom Wars
addappid(2284390)
addappid(2284391, 1, "b4cefa943af6a4578d4061e1160e094129d27ac3160d262bb3cb17aec01f0d5f")
