-- Lua provided by RyzenAPI
-- Game: Mupple

-- MAIN APPLICATION
addappid(1882930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882931, 1, "a0f08e0746ffc98dbe8ad9b8a2d48d4ed1faaf3326ff213c85d5378ae357b0b6")

