-- Lua provided by RyzenAPI
-- Game: Legends of Eisenwald

-- MAIN APPLICATION
addappid(246760)

-- MAIN APP DEPOTS / PACKAGES
addappid(246761, 1, "3392e98e17e0751bf62bb0693783dec0437ad4c9dd06de7124fa8ead0ab99716")
addappid(336450, 0, "d7fefa5be35eb291c16e434083764c620f74f08bfa43c1270a53787bf38c93ed")
addappid(337090, 0, "ac66578704d7b8eb15e1db75d6d0803d72a44b966109a39cde081add9869423a")
addappid(416750, 0, "19cd0f3782535f53283285f7c693b9e861e9025709ac3a6e59d4f6046a191f1d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(417160)
