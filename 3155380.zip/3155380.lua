-- Lua provided by RyzenAPI
-- Game: addappid(3155380)

-- MAIN APPLICATION
addappid(3155380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155381, 1, "79dd47c4dd3aa3f6ba885f5fa7bc85b64f5ed9a1bfe88ac92b119d8f87c1e8ec")
