-- Lua provided by RyzenAPI
-- Game: SONIC SUPERSTARS - LEGO® Fun Pack

-- MAIN APPLICATION
addappid(2376681)
-- Game: addappid(2376681)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376681,0,"0c92a1adfef01e648935444d21387d4210e9f8f9e44ce9540dd74fc366520cce")
