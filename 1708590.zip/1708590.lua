-- Lua provided by RyzenAPI
-- Game: The Rescue Squad

-- MAIN APPLICATION
addappid(1708590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708591, 1, "e1ff7289b244d883dc00122018e4d5b521ddbe87860f81c784c39d7100f9fc45")
