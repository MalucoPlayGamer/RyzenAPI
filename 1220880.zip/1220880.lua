-- Lua provided by SkyAPI 
-- Game: AppID 1220880
addappid(1220880)
addappid(1220881, 1, "f4c6d54b8ac285674cf3123e8523f31d077cf32baa145e8662a2fece8ec106ea")
