-- Lua provided by RyzenAPI
-- Game: 陆大迹神Ⅱ

-- MAIN APPLICATION
addappid(1220880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220881, 1, "f4c6d54b8ac285674cf3123e8523f31d077cf32baa145e8662a2fece8ec106ea")

