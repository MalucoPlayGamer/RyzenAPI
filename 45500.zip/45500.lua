-- Lua provided by RyzenAPI
-- Game: 45500

-- MAIN APPLICATION
addappid(45500)
-- Game: addappid(45500)

-- MAIN APP DEPOTS / PACKAGES
addappid(45502,0,"2d2e4973ac879ae4b0faa2f52666f01c90950835df3b3c2fee37d00c2d377b46")
