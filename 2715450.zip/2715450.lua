-- Lua provided by RyzenAPI
-- Game: Tails of Iron - Artbook

-- MAIN APPLICATION
addappid(2715450)
-- Game: addappid(2715450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715451, 1, "1d3d4de844ff36ced4d0cbfbdd602fd85261bb7bce68ad8b74fbaf685fd390f8")
