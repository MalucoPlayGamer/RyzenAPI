-- Lua provided by SkyAPI 
-- Game: AppID 1939970
addappid(1939970)
addappid(1939971, 1, "0d0243090a47fc277116845e3718d318974cae787bb631ed034d1a1e1599918a")
