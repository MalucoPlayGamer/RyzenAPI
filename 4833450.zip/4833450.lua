-- Lua provided by RyzenAPI
-- Game: Money for Girls: Amortized

-- MAIN APP DEPOTS / PACKAGES
addappid(4833450, 1, "c2c94885f7d55132395dd2f2ba1d99594e84cb47eb4ee56828d800d0eb620ad1") -- Money for Girls: Amortized
addappid(4833451, 1, "5c8ae923eeba07817402317597eab788ecb1e81dae66bd936003325a587a17d2") -- Depot 4833451

