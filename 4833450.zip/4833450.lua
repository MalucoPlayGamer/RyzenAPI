-- 4833450's Lua and Manifest Created by Hubcap Manifest
-- Money for Girls: Amortized
-- Created: August 25, 2026 at 07:20:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4833450, 1, "c2c94885f7d55132395dd2f2ba1d99594e84cb47eb4ee56828d800d0eb620ad1") -- Money for Girls: Amortized
-- MAIN APP DEPOTS
addappid(4833451, 1, "5c8ae923eeba07817402317597eab788ecb1e81dae66bd936003325a587a17d2") -- Depot 4833451
setManifestid(4833451, "5822773306242875601", 1256341005)