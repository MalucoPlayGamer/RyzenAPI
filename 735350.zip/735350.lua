-- Lua provided by RyzenAPI
-- Game: Game: AppID 735350

-- MAIN APPLICATION
addappid(735350)
-- Game: addappid(735350)

-- MAIN APP DEPOTS / PACKAGES
addappid(735351, 1, "317ae1aa3ed0c9825ce7610df03e799083fca840640a11a40fd91b20b70477c7")
