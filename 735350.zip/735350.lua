-- Lua provided by SkyAPI 
-- Game: AppID 735350
addappid(735350)
addappid(735351, 1, "317ae1aa3ed0c9825ce7610df03e799083fca840640a11a40fd91b20b70477c7")
