-- Lua provided by RyzenAPI 
-- Game: Neodori Forever
addappid(1963660)
addappid(1963661, 1, "0090e23ad69e296830e631cf8ee8b747fbcf6e82ec4c4345443ff113eb3262d9")
