-- Lua provided by RyzenAPI
-- Game: 594640

-- MAIN APPLICATION
addappid(594640)
-- Game: addappid(594640)

-- MAIN APP DEPOTS / PACKAGES
addappid(594641, 1, "94e525b44b8e09cc367b375ed3db1cea7a94bb99f6f44fb5eff5b23e1877f671")
