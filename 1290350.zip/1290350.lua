-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade — Out for Blood

-- MAIN APPLICATION
addappid(1290350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290351, 1, "134611c7730fc89bd8a3ba25c2aafbfe87ae630b7b007637ec6833a522b6ec03")
