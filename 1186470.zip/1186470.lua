-- Lua provided by RyzenAPI
-- Game: AppID 1186470

-- MAIN APPLICATION
addappid(1186470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1186471, 1, "50b17b0c71f9cdc8302bff4c9411264430bc26b33b6084f18e546031f0f86d74")

