-- Lua provided by SkyAPI 
-- Game: AppID 1186470
addappid(1186470)
addappid(1186471, 1, "50b17b0c71f9cdc8302bff4c9411264430bc26b33b6084f18e546031f0f86d74")
