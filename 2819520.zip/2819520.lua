-- Lua provided by RyzenAPI
-- Game: Viking Rise

-- MAIN APPLICATION
addappid(2819520)
