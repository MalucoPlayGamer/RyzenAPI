-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3358070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358070,0,"7f29a98df78d333fa66611c3d323c6312f0c42aacd986b5459db60dee34ac7fa")

