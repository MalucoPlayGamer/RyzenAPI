-- Lua provided by RyzenAPI
-- Game: Fear the Night - 恐惧之夜

-- MAIN APPLICATION
addappid(764920)
-- Game: addappid(764920)

-- MAIN APP DEPOTS / PACKAGES
addappid(764921, 1, "dc067df4c0ccec7c188e6cd7d75704804705e7bf7dd7778076f9e662a113224a")
