-- Lua provided by RyzenAPI
-- Game: Mini Airways Playtest

-- MAIN APPLICATION
addappid(2852780)
-- Game: addappid(2852780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852781, 1, "6a8a196da80c9458e847dd8188ed442a8c26c9e7a09457da949d1fa4db5e0baf")
