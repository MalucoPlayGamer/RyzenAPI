-- Lua provided by RyzenAPI
-- Game: Super House of Dead Ninjas

-- MAIN APPLICATION
addappid(224820)
addappid(238570)

-- MAIN APP DEPOTS / PACKAGES
addappid(224821, 1, "7a68cbff60cf5df3a309a0e7023a97729158cf8e90f07835685c2a29a97115dc")
