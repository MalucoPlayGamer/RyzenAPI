-- Lua provided by RyzenAPI
-- Game: AppID 224820

-- MAIN APPLICATION
addappid(224820)
-- Game: addappid(224820)

-- MAIN APP DEPOTS / PACKAGES
addappid(224821, 1, "7a68cbff60cf5df3a309a0e7023a97729158cf8e90f07835685c2a29a97115dc")
