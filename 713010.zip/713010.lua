-- Lua provided by RyzenAPI
-- Game: AppID 713010

-- MAIN APPLICATION
addappid(713010)

-- MAIN APP DEPOTS / PACKAGES
addappid(713011, 1, "f3c562443ab17e1da48837841b4124b04c41589f6eb0efb89cf7422aadaf5cc7")
