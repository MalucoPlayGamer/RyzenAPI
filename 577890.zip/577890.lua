-- Lua provided by RyzenAPI 
-- Game: AppID 577890
addappid(577890)
addappid(577891, 1, "e8c9104148dc7a8ca795bf06e23856761c92da76c8098806f876d1e4eb01d4aa")
