-- Lua provided by SkyAPI 
-- Game: AppID 2114680
addappid(2114680)
addappid(2114681, 1, "1f6b56cbba8f115dbdee069483f4ec8d1aebc143cd6d5f3b1b453fa52bc1d345")
