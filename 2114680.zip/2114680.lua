-- Lua provided by RyzenAPI
-- Game: Game: AppID 2114680

-- MAIN APPLICATION
addappid(2114680)
-- Game: addappid(2114680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114681, 1, "1f6b56cbba8f115dbdee069483f4ec8d1aebc143cd6d5f3b1b453fa52bc1d345")
