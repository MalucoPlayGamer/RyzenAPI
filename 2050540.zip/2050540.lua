-- Lua provided by RyzenAPI
-- Game: Pocket Clothier

-- MAIN APPLICATION
addappid(2050540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050541, 1, "6aedd4b9ebe0ba5b0084bc5100590cc326fa7b4435bd2f5d4038e448eaa21eff")

