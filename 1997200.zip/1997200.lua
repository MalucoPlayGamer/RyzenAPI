-- Lua provided by RyzenAPI
-- Game: 1997200

-- MAIN APPLICATION
addappid(1997200)
-- Game: addappid(1997200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997201, 1, "09c28a5394383ff96bb4bc6d6232061c76f5bc0ef6d49cc9987e98199f156fa9")
