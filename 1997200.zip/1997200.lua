-- Lua provided by SkyAPI 
-- Game: AppID 1997200
addappid(1997200)
addappid(1997201, 1, "09c28a5394383ff96bb4bc6d6232061c76f5bc0ef6d49cc9987e98199f156fa9")
