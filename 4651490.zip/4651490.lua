-- Lua provided by RyzenAPI
-- Game: Loot Gobblin' Together

-- MAIN APPLICATION
addappid(4651490) -- Loot Gobblin' Together
addappid(5139680) -- Loot Gobblin Together - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4651491, 1, "ca351ddb23e759e0ce6f2ea1a8e04395a06ca7ac9ad3223e9ee0eb2b7663e070") -- Depot 4651491
addappid(4651492, 1, "818c905bc24ca09352ed5499ed5db5fa80b6e748290dbcff78be744ad42be1af") -- Depot 4651492
addappid(4651493, 1, "b751884d01a21498b7721a8269c5e7b8a7b8fb0baf3f989790485ca577d0cad6") -- Depot 4651493
