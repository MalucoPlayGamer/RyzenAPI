-- Lua provided by RyzenAPI
-- Game: 506战纪

-- MAIN APPLICATION
addappid(3294580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3294581, 1, "1a107bd9ff0a5b244358b8e40564846862f58c36a25122a66d0d9d425c063dea")