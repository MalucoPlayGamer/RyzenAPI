-- Lua provided by RyzenAPI
-- Game: Sam & Dan: Floaty Flatmates

-- MAIN APPLICATION
addappid(978270)
addappid(979850)
addappid(979851)
addappid(979852)
addappid(979860)
addappid(979861)

-- MAIN APP DEPOTS / PACKAGES
addappid(978271, 1, "e56c5d69d106a635bb9ada7108d1db43c9bbb1e86ed4ecd4cd88fcf74322d048")
