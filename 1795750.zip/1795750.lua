-- Lua provided by RyzenAPI
-- Game: 1795750

-- MAIN APPLICATION
addappid(1795750)
-- Game: addappid(1795750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795751, 1, "906dd549bf6ff9a78c2f9eed554ad49fe23c3a4838a8427d2c33b4940889b452")
