-- Lua provided by RyzenAPI
-- Game: Q2 HUMANITY

-- MAIN APPLICATION
addappid(2357950)
-- Game: addappid(2357950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357951, 1, "b21fb59ff5169506f2771ddf697eba0e81c51727fc5c09ca9f9c23e258d25fc8")
