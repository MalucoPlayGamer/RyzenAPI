-- Lua provided by RyzenAPI
-- Game: The Cold Forest

-- MAIN APPLICATION
addappid(2094170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094171, 1, "9d5fca810ff2c946003aedab14c9286fb2cda248bd8e56a20796a36a8d9c9353")

