-- Lua provided by RyzenAPI
-- Game: AppID 311680

-- MAIN APPLICATION
addappid(311680)

-- MAIN APP DEPOTS / PACKAGES
addappid(311681, 1, "89fe23fd2f7bbaabb4d8b88e738a4185233a49716e3fe1d63b7032956d70fff4")
