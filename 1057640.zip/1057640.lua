-- Lua provided by RyzenAPI
-- Game: addappid(1057640)

-- MAIN APPLICATION
addappid(1057640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057641, 1, "b048103078711d5ab830b310f6addad5cb9b0e1f06df81a94e67fb00b6b1bd00")
