-- Lua provided by RyzenAPI
-- Game: 1857350

-- MAIN APPLICATION
addappid(1857350)
-- Game: addappid(1857350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857351, 1, "0f22fd40ee3a19c6a8fdbd19433c379194aa619b33d7f57022be6981db95341d")
