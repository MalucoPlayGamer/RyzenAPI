-- Lua provided by RyzenAPI
-- Game: Backfire

-- MAIN APPLICATION
addappid(548260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(548261, 1, "ca1768fdb68b19eba9a520e771797dd6fa177b98a21c07af6aefeb820e2cd7d7")

