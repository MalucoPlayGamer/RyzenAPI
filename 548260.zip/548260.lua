-- Lua provided by RyzenAPI
-- Game: Game: Backfire

-- MAIN APPLICATION
addappid(548260)
-- Game: addappid(548260)

-- MAIN APP DEPOTS / PACKAGES
addappid(548261, 1, "ca1768fdb68b19eba9a520e771797dd6fa177b98a21c07af6aefeb820e2cd7d7")
