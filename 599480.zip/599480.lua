-- Lua provided by RyzenAPI 
-- Game: Flamel's miracle（弗拉梅尔的奇迹）
addappid(599480)
addappid(599481, 1, "da1d67bff0320bd09bebc7c105d380ed72894af3680693c13ff42e049958fffb")
addappid(599482, 1, "7805b39c3b36acb26277a03e6d49787cf18137dd76d5b66d8818d6625f4f7bb1")
addappid(599483, 1, "614b24963df5ed23fa9f7b15900790a13294feb126b08c533c3f93682f45c293")
addappid(621040)
