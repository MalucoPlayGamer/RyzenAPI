-- Lua provided by RyzenAPI
-- Game: Sutekina kanojo no tsukurikata

-- MAIN APPLICATION
addappid(1396150)
-- Game: addappid(1396150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396151, 1, "3e63fe149565d4315eac405910ee6cf844e4dac17b43d3939f4c4161af3ba16e")
