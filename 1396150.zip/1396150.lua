-- Lua provided by RyzenAPI
-- Game: Sutekina kanojo no tsukurikata

-- MAIN APPLICATION
addappid(1396150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1396151, 1, "3e63fe149565d4315eac405910ee6cf844e4dac17b43d3939f4c4161af3ba16e")

