-- Lua provided by RyzenAPI
-- Game: The Sushi Bar | 寿司バー

-- MAIN APPLICATION
addappid(3369850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369851, 1, "c509b5a60fa04cca99765a13a27f9ca8b74e175d4e97c39bf62cef78307c00fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
