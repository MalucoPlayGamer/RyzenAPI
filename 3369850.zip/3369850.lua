-- Lua provided by RyzenAPI
-- Game: 3369850

-- MAIN APPLICATION
addappid(3369850)
-- Game: addappid(3369850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369851, 1, "c509b5a60fa04cca99765a13a27f9ca8b74e175d4e97c39bf62cef78307c00fd")
