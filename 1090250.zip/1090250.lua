-- Lua provided by RyzenAPI
-- Game: Crunch Element

-- MAIN APPLICATION
addappid(1090250)
-- Game: addappid(1090250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090251, 1, "fb2d64153fd2c15477f5180013ccdb688ec4728a362ed33fc7c6bda9b1302f65")
