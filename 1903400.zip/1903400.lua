-- Lua provided by RyzenAPI
-- Game: Bicycle Rider Simulator

-- MAIN APPLICATION
addappid(1903400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903401, 1, "a99c2e8caf4acabbf6fb14c7d819904a5072bdf22a3ee6ebe611864767692763")

