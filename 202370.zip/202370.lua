-- Lua provided by RyzenAPI
-- Game: 202370

-- MAIN APPLICATION
addappid(202370)
-- Game: addappid(202370)

-- MAIN APP DEPOTS / PACKAGES
addappid(202371, 1, "1c09626123967f6a1b093752dbeb337322bdc9b7c550d4d9dd037e87753621df")
