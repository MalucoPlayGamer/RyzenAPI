-- Lua provided by RyzenAPI
-- Game: Terraformers

-- MAIN APPLICATION
addappid(1244800)
addappid(2646850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244801, 1, "8497f1f2c3d208f4150b210cfc9f1b5281d74a3b2e5e209a235baa4ad9553ad4")
addappid(1244802, 1, "2475cf37403469e779b4c142fe6eef9326bc49943b4473fb5a75eb28f62482f8")
addappid(1244803, 1, "7a6607ebb13a2195abfa890e5bef010af2b88c419c5e7fee8cb5c6597c2630e7")
addappid(1783650, 0, "0474504e1c09e61912b386782d3e567401170d2a93feb96f49fadd18746ec18f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2779050)
addappid(2779060)
