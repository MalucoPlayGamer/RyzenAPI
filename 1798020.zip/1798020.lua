-- Lua provided by RyzenAPI
-- Game: Mega Man Battle Network Legacy Collection Vol. 2

-- MAIN APPLICATION
addappid(1798020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798021, 1, "f49976dd7ad37fed5c3d06d4e728237fcff43f31868c0ba63e8c92d630191d01")
