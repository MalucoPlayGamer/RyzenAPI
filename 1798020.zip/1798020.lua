-- Lua provided by RyzenAPI
-- Game: Mega Man Battle Network Legacy Collection Vol. 2

-- MAIN APPLICATION
addappid(1798020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798021, 1, "f49976dd7ad37fed5c3d06d4e728237fcff43f31868c0ba63e8c92d630191d01")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1981420)
