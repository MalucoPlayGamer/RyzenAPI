-- Lua provided by RyzenAPI
-- Game: Game: Waves of Rotting Flesh

-- MAIN APPLICATION
addappid(1336430)
-- Game: addappid(1336430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336431, 1, "968fa3bbc29c11bc8a896996a40b53f27be7141c5f2fe0baaeb420a93905c934")
