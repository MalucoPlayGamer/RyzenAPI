-- Lua provided by RyzenAPI
-- Game: 100 Hidden Capybaras

-- MAIN APPLICATION
addappid(3288020)
-- Game: addappid(3288020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288022,0,"925b7d17b3f0c6e46826bf1191683be2d9e70449807966fc6476c96192c9477b")
