-- Lua provided by RyzenAPI
-- Game: 3699450

-- MAIN APPLICATION
addappid(3699450)
-- Game: addappid(3699450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699451, 1, "095ba51c25935a7ff31fbc871132d9dfb0905672fb07c6e6a5c2e7c41711cc77")
