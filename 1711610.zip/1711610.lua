-- Lua provided by RyzenAPI
-- Game: addappid(1711610)

-- MAIN APPLICATION
addappid(1711610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711611, 1, "87b345dd014fd329e3de12531b11884443942dccaacb4876a44317bea54beec9")
