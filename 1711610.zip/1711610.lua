-- Lua provided by SkyAPI 
-- Game: Dungeon 100
addappid(1711610)
addappid(1711611, 1, "87b345dd014fd329e3de12531b11884443942dccaacb4876a44317bea54beec9")
