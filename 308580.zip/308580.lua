-- Lua provided by RyzenAPI
-- Game: Orborun

-- MAIN APPLICATION
addappid(308580)

-- MAIN APP DEPOTS / PACKAGES
addappid(308581, 1, "891e0c0c0acfcacdf62c700e8fa551b357c1b02a17e2dd17927b2b731ca2ed3a")
addappid(308582, 1, "6ff543b90ee37540fb1bf586f9e9c7e90c930f398617aed79eb65dfec419f19d")
addappid(308583, 1, "d0066fd4f6ce19567bde1d711754436f3fbeca993a17f086547f46cbcedadc94")
addappid(308584, 1, "906093a03d9f1c0a7859bdfe7a85279f1fffed2a6d6f3144f7f321fbe1a68f92")

