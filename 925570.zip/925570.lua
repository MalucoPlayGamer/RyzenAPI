-- Lua provided by RyzenAPI
-- Game: addappid(925570)

-- MAIN APPLICATION
addappid(925570)

-- MAIN APP DEPOTS / PACKAGES
addappid(925571, 1, "4d118f2a9064b3e3a4be789aa2a59e10d7b30cb1b25346632fa3d69c6c3dc5a4")
