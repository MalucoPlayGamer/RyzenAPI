-- Lua provided by RyzenAPI
-- Game: The Lightbringer

-- MAIN APPLICATION
addappid(1561660)
-- Game: addappid(1561660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561661, 1, "824dd6a9f3b1621ed9bf1ec13fecdc78b67477a1980d1c9d90ae2eca06fcc9b3")
