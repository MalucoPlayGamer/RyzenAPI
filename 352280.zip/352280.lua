-- Lua provided by RyzenAPI
-- Game: Cakewalk Sound Center

-- MAIN APPLICATION
addappid(352280)

-- MAIN APP DEPOTS / PACKAGES
addappid(352281, 1, "d8f6bab597f6477db90f9f0fd5f39ae415e0e8b06e235f97ea80c33d0d0dfd38")
addappid(352282, 1, "3f9790a4f07a6cbbfdeea7d80ced8302331bd9e84f66933f425bfb00600d23fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(352320)
addappid(352321)
addappid(352322)
addappid(352323)
addappid(352324)
addappid(352325)
addappid(352326)
addappid(352327)
addappid(352328)
addappid(352329)
addappid(352330)
addappid(352331)
addappid(352332)
addappid(352333)
addappid(352334)
addappid(352335)
addappid(352336)
addappid(352337)
addappid(352338)
addappid(352339)
addappid(352340)
addappid(352341)
addappid(352342)
