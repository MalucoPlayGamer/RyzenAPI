-- Lua provided by RyzenAPI
-- Game: Game: AppID 3044860

-- MAIN APPLICATION
addappid(3044860)
-- Game: addappid(3044860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044861, 1, "572801db13de709a16902149085f7fdb2fe88108a44d468fcad22d71a582d135")
