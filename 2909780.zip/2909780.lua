-- Lua provided by RyzenAPI
-- Game: Облик из Sonic Adventure в SONIC X SHADOW GENERATIONS

-- MAIN APPLICATION
addappid(2909780)
-- Game: addappid(2909780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909780,0,"d4bca264bdbcdde86f3167d63185b55ea30748dc1670b75bd2c48fe00b16ec08")
