-- Lua provided by RyzenAPI
-- Game: SONIC X SHADOW GENERATIONS: Sonic Adventure Legacy Skin

-- MAIN APPLICATION
addappid(2909780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909780,0,"d4bca264bdbcdde86f3167d63185b55ea30748dc1670b75bd2c48fe00b16ec08")

