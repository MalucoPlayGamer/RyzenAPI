-- Lua provided by RyzenAPI
-- Game: Blood Rose ~ Origin of the Plague

-- MAIN APPLICATION
addappid(2530690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530692,0,"605c6ef43f872e2cd98a4629177e641de52c90e4f6264705df8b0b39dcb55381")
addappid(2530694,0,"82dd7d4f691f52e7386a4ae1d9437a7f3f27e1a87cb501c45fb3761bb9aade5a")
