-- Lua provided by RyzenAPI
-- Game: Settle and Battle: New Empires

-- MAIN APPLICATION
addappid(3306790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3306791, 1, "85cae820dd237a1964e8c1ad8b60b7e74fa202992cbdff6aa6e562ca85172d14")
