-- Lua provided by RyzenAPI
-- Game: Fantasy Tavern Sextet -Vol.2 Adventurer's Days-

-- MAIN APPLICATION
addappid(1461770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461771, 1, "5123a99066149ecf15462285c26a5947e738725fc7b0e1f7056f006bf5e2edbc")
