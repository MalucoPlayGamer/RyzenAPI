-- Lua provided by RyzenAPI
-- Game: 1385350

-- MAIN APPLICATION
addappid(1385350)
-- Game: addappid(1385350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385351, 1, "0010238c72bdebd25aa314c52496204da884523e0effa517dc8f7b76c1b27d97")
