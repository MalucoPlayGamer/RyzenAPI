-- Lua provided by SkyAPI 
-- Game: AppID 2358380
addappid(2358380)
addappid(2358381, 1, "05c7c670afaf0539e245ee85eb425b24ee4a3fec485b36db030f95d69943d538")
