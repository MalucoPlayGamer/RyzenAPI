-- Lua provided by RyzenAPI
-- Game: Game: AppID 2358380

-- MAIN APPLICATION
addappid(2358380)
-- Game: addappid(2358380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358381, 1, "05c7c670afaf0539e245ee85eb425b24ee4a3fec485b36db030f95d69943d538")
