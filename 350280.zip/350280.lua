-- Lua provided by RyzenAPI
-- Game: LawBreakers

-- MAIN APPLICATION
addappid(350280)
addappid(620150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(350281, 1, "1a27abec28f7e7c1c8dded70ba0e131c604bdcb8af3701c788a545ebfbda4acd")
