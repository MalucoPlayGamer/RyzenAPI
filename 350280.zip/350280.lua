-- Lua provided by RyzenAPI
-- Game: Game: AppID 350280

-- MAIN APPLICATION
addappid(350280)
addappid(620150)
-- Game: addappid(350280)

-- MAIN APP DEPOTS / PACKAGES
addappid(350281, 1, "1a27abec28f7e7c1c8dded70ba0e131c604bdcb8af3701c788a545ebfbda4acd")
