-- Lua provided by RyzenAPI
-- Game: Seven Kingdoms 2 HD

-- MAIN APPLICATION
addappid(338800)

-- MAIN APP DEPOTS / PACKAGES
addappid(338801, 1, "6b48fd8f02cbc4c281632b101c8be1c428cfc529a42474da1af812bf47cca7db")
