-- Lua provided by RyzenAPI
-- Game: 338800

-- MAIN APPLICATION
addappid(338800)
-- Game: addappid(338800)

-- MAIN APP DEPOTS / PACKAGES
addappid(338801, 1, "6b48fd8f02cbc4c281632b101c8be1c428cfc529a42474da1af812bf47cca7db")
