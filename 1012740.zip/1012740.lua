-- Lua provided by RyzenAPI
-- Game: Game: 九劫曲:诅咒之地 NINE TRIALS Demo

-- MAIN APPLICATION
addappid(1012740)
-- Game: addappid(1012740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012741, 1, "9edd9ffd394b14dfc7bdd09bccf1e098b1ca709122ecf976d3df911dd3219525")
