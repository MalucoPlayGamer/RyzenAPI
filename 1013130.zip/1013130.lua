-- Lua provided by RyzenAPI
-- Game: Happy Anime Puzzle

-- MAIN APPLICATION
addappid(1013130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013131, 1, "c299f227ea570b52f88005a91f8fee2fda4a7adad1ee30f1b76b5abb619c1258")

