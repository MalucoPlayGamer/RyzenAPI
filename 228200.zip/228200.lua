-- Lua provided by RyzenAPI
-- Game: Company of Heroes

-- MAIN APPLICATION
addappid(228200)
addappid(228221)
addappid(228222)
addappid(228223)

-- MAIN APP DEPOTS / PACKAGES
addappid(228201, 1, "5d6bed0e4d50494cfda9f876c9c851d5f0d5b90456f45cb1083b1316338e3fd0")
addappid(228202, 1, "e1d4ee51033ff00a5fab176efaa92d1c7c8d47519880b3444edd9988b5efa51c")
addappid(228203, 1, "7b564d87178856b4bb20aa971be9300644d9bc3a6bc9da3dccb447922f83116a")
addappid(228204, 1, "0d601b5f2cca71acb2d9920c5df9f936ee3b8e8701fb4aa96763af3ded0cfb10")
addappid(228205, 1, "dfbbce5d3f4b092bfd697b15d16ddc0f0cd5eb3a3730d430e3eebe2f3cd077a1")
addappid(228206, 1, "601486a3e1d777ba88fe3ab8fc1eff071b5a894a4b32b40a5ae351ad99e7c14d")
addappid(228207, 1, "8f0d66cf66279c53e2c6eea205de4d16ea3cbdf4283ba41a16215644a362d2f7")
addappid(228209, 1, "84e2e9698afb312d2efac8be482c8e413be2afabff5885a3a1b279e95f802d47")
addappid(228210, 1, "a0e3bc5632baa62801f5e21e85a69ab51eaab22d1e1ebf196de9df12a6b2e043")
addappid(228211, 1, "77d671190e479e4eb6be4fea948506dc1941363fceed6e6af56e844f0a0681e7")
addappid(228212, 1, "ffe99980ed112a495130a18ce8348ad0763046f7f65d610c747cf22deeeab2f0")
addappid(228213, 1, "dd5682bc26f22c7f92343926cb219482d72811fbe7bbd66e60979dc183dbfcc1")
addappid(228214, 1, "2ced19d575cbfc8cc70cadf3180fddf9254d87f440f614ca3d233a69cc035596")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
