-- Lua provided by RyzenAPI
-- Game: Project 37 Demo

-- MAIN APPLICATION
addappid(2919570)
-- Game: addappid(2919570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919571, 1, "1667a4e5b4f31c77e5559893fe71bdfba31ee9917a250bd3aa5a414e1bb2e1e8")
