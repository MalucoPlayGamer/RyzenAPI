-- Lua provided by RyzenAPI 
-- Game: RIPOUT
addappid(1558830)
addappid(1558831, 1, "f90ef0dbdc6e568321950badd9e5ef4414b653e6e870df748bb0aff5cbd1509c")
