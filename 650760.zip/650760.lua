-- Lua provided by RyzenAPI
-- Game: 侠客风云传前传(Tale of Wuxia:The Pre-Sequel)

-- MAIN APPLICATION
addappid(650760)

-- MAIN APP DEPOTS / PACKAGES
addappid(650761, 1, "c47a9730127e0409b0ec1ee9876faa317f7372187b33e4220310ae846e1bc86d")
addappid(709060, 0, "dc4d08c6bb013d1447d892d9c069ab01dec943a25b0463d0aecbfb535687f111")

