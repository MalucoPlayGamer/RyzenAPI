-- Lua provided by RyzenAPI
-- Game: Game: Cinderella Escape! R12

-- MAIN APPLICATION
addappid(408000)
-- Game: addappid(408000)

-- MAIN APP DEPOTS / PACKAGES
addappid(408001, 1, "cfa93944a8017d08f01a9363b240b8022209d53bfb9fc83a635a47234d6c2163")
addappid(408002, 1, "ec494e35e3f70a1cc33aa36ac27c4275982cc6d59a6218714a25f6cb3cf63ce7")
addappid(425500, 0, "580815185038edaddeb5243170e26a95ae3ed83b60e4138e55866c8dc32b66be")
