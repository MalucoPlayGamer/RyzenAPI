-- Lua provided by RyzenAPI
-- Game: 方块地牢2 重置版

-- MAIN APP DEPOTS / PACKAGES
addappid(4807960, 1, "3d5da017648dcd621d7f4427d870b4375beeec641974a30c078f5e294e7cb686") -- 方块地牢2 重置版
addappid(4807961, 1, "81880dc9045cb3b3cfb075ee3a42a309cc2d7cef4b6f6135f8069f118bf0181e") -- Depot 4807961
