-- Lua provided by RyzenAPI
-- Game: Gravity Shot

-- MAIN APPLICATION
addappid(511960)
-- Game: addappid(511960)

-- MAIN APP DEPOTS / PACKAGES
addappid(511961, 1, "30f7c7e70a1dea3aa866e368ec26e19cbd30bbde10a404784e243378c4b708e4")
