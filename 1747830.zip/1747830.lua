-- Lua provided by RyzenAPI 
-- Game: Blossom Tales II: The Minotaur Prince
addappid(1747830)
addappid(1747831, 1, "185e2969cdebd12d14fdc377241d8176698a0c8e1a64e7f36e61f6187a555b50")
