-- Lua provided by RyzenAPI
-- Game: Blossom Tales II: The Minotaur Prince

-- MAIN APPLICATION
addappid(1747830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747831, 1, "185e2969cdebd12d14fdc377241d8176698a0c8e1a64e7f36e61f6187a555b50")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
