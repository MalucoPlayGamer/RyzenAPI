-- Lua provided by RyzenAPI
-- Game: BattleTubers

-- MAIN APPLICATION
addappid(2684080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684081, 1, "e61fb713daa133fc08d5e114125a1f439049e871a727bb68161730398db874d8")

