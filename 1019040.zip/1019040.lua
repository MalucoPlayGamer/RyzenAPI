-- Lua provided by SkyAPI 
-- Game: Smash team
addappid(1019040)
addappid(1019041, 1, "9e3f60b88755ed2fbca7bf87648b21928a2950400e95644a1da626ec579c7ce5")
