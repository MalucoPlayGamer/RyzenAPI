-- Lua provided by RyzenAPI
-- Game: Smash team

-- MAIN APPLICATION
addappid(1019040)
-- Game: addappid(1019040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019041, 1, "9e3f60b88755ed2fbca7bf87648b21928a2950400e95644a1da626ec579c7ce5")
