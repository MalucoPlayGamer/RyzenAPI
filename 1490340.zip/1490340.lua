-- Lua provided by RyzenAPI
-- Game: 1490340

-- MAIN APPLICATION
addappid(1490340)
-- Game: addappid(1490340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490343,0,"d72b3113b5e909f8a410e385f25df9b0d5a1e702e60b250ff8f59efaff267dfd")
addappid(1490345,0,"b0237aae3dad057759ec3180ff4b4281b8a808e6189d2aff1310340e412acda8")
addappid(1490346,0,"2c9fd2b749a4e7438ffaac2b09d369bd2de97e158df994abb424eb259a38fc7e")
