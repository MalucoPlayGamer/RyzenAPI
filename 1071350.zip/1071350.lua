-- Lua provided by RyzenAPI
-- Game: Little One - A Visual Novel

-- MAIN APPLICATION
addappid(1071350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071351, 1, "7f5126b4a712689ac01366bd826e82ddff25a4136191be123b8739b41e17d093")

