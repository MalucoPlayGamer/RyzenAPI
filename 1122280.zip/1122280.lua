-- Lua provided by RyzenAPI 
-- Game: AppID 1122280
addappid(1122280)
addappid(1122281, 1, "80ff93d8ff9aed030866c0f023017c338664f87f39566e1bcc848115ca840f47")
