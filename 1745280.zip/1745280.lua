-- Lua provided by RyzenAPI
-- Game: Magitek VR

-- MAIN APPLICATION
addappid(1745280)
-- Game: addappid(1745280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745281, 1, "eb70aee4af2e7411deca17711013ae4200fa67b7dc6da0c6deef44193f6577d2")
