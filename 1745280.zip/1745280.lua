-- Lua provided by SkyAPI 
-- Game: Magitek VR
addappid(1745280)
addappid(1745281, 1, "eb70aee4af2e7411deca17711013ae4200fa67b7dc6da0c6deef44193f6577d2")
