-- Lua provided by RyzenAPI
-- Game: addappid(1341190)

-- MAIN APPLICATION
addappid(1341190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341191, 1, "ce1390a6ba0ba86d26eecf465b2fbfcf52d220352dfc4876e294001245e3347c")
