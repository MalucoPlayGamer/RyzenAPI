-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic Midsummer Maid's Dream ALL in ONE Pack

-- MAIN APPLICATION
addappid(3137210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137211, 1, "4db74276a24eac5ff62509490dd97e7478c48a531cb41b22a7728e4b06090232")

