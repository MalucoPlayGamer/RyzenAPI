-- Lua provided by RyzenAPI
-- Game: Tempest Rising Soundtrack

-- MAIN APPLICATION
addappid(2488520)
-- Game: addappid(2488520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488521, 1, "a2b6d87f86ca0a85031b592070b8a77f88e741eaff207b555ce3dad8eb7d8faa")
addappid(2488522, 1, "a83d7ae843a8ce85ebbb3cde04b685a0be56036671999c3a43b74a4f25874dca")
