-- Lua provided by RyzenAPI
-- Game: Livestream: Escape from Hotel Izanami

-- MAIN APPLICATION
addappid(1523400)
-- Game: addappid(1523400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523401, 1, "265f6150389c0e2aa58e2072a3fe0a5ecb77f51f4f624a9164aeb498ab240f8f")
