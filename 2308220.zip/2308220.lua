-- Lua provided by RyzenAPI
-- Game: Abyss Of Fire

-- MAIN APPLICATION
addappid(2308220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308221, 1, "5226601960fbd2d52583a708d65b3fbd8c5e77d4208284f99a4db2949bc14cb9")
