-- Lua provided by RyzenAPI
-- Game: Royal Casino: Video Poker

-- MAIN APPLICATION
addappid(771840)

-- MAIN APP DEPOTS / PACKAGES
addappid(771841, 1, "90f9925e0aacb9499ac799174ad642fbdab5a2970038b0b4276909e7b257130e")
addappid(771842, 1, "8b4045e53a1126dd55a2cbd7e16e0d1293440f763ca14ec87a6f2108abc53df1")
addappid(771843, 1, "bc03d61e33a690ae30e681a124fe3664bb6019dd7cf3f2d7143d6f4245635ab4")

