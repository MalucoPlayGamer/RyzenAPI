-- Lua provided by RyzenAPI
-- Game: The Pane Puzzle Demo

-- MAIN APPLICATION
addappid(3213660)
-- Game: addappid(3213660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213661, 1, "523d6f0ef882b977946c510c1d30d4a98d8de6349b6bc9fb71908985fdcbf972")
