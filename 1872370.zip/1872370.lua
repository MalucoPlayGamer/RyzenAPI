-- Lua provided by RyzenAPI
-- Game: BLIND dreams Demo

-- MAIN APPLICATION
addappid(1872370)
-- Game: addappid(1872370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872371, 1, "ebfd276d327131b47b0bab606031681996fdaae2087cd1997808962551221acb")
