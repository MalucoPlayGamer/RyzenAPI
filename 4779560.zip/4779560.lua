-- 4779560's Lua and Manifest Created by Hubcap Manifest
-- Idle Startup
-- Created: June 21, 2026 at 11:57:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4779560) -- Idle Startup
-- MAIN APP DEPOTS
addappid(4779561, 1, "f6a36e74b830e527fb667d0a2639e3bd37bf8a67cfacba9ce550bb68b2bf884e") -- Depot 4779561
-- setManifestid(4779561, "5271291100806092336", 301316143)