-- Lua provided by RyzenAPI 
-- Game: Galactic Arms Race
addappid(249610)
addappid(249611, 1, "05eff02235e3ba01ddbff251cc5189157afa19b5c1657f76da88be0e06b3d7c1")
