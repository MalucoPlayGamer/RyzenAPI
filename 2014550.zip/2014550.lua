-- Lua provided by RyzenAPI 
-- Game: Voidwrought
addappid(2014550)
addappid(2014551, 1, "6d2ed618640bb062b370e4f15dc33c4cfddb5536b55bc4bf6b3d633885110588")
