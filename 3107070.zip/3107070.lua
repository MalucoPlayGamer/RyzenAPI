-- Lua provided by RyzenAPI
-- Game: THE JOY OF CREATION Demo

-- MAIN APPLICATION
addappid(3107070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107071, 1, "eb02b25f927a8a386c3874e302cdf06f04c9da40cb2fced61c5aa5f355ddeff3")

