-- Lua provided by RyzenAPI
-- Game: Office Run

-- MAIN APPLICATION
addappid(2000180)
addappid(2158090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000181, 1, "2cdc4fa3acfab6990881c79aa4b3e9075c7a10646eb6b6ec47127027419b322a")

