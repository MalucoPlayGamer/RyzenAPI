-- Lua provided by RyzenAPI
-- Game: AppID 330020

-- MAIN APPLICATION
addappid(330020)
addappid(1648880)

-- MAIN APP DEPOTS / PACKAGES
addappid(330021, 1, "08ae65e452cbf086b1185be193446421485214e63e705cbc139de687c906dc15")
addappid(330022, 1, "d67d4cef4af612190a78a42d3af9df70988474b78c9f1de68d65cf711cc09be4")
addappid(330023, 1, "47799065e21c92aab38943ad2b7312f5719f9b3e92bc8029e19216741a650cde")
addappid(330024, 1, "57ee867e033c4216af875908ec959e0d91ae5c1ef5493dc3a5a7c06b4a6c7317")
addappid(330026, 1, "3d470a3c0b7fc703b8e780dc3f087babecd65d940c96bc92ee202f61acea9113")
addappid(330027, 1, "7e53bfaacab4472e6918491409733d7490edc7f25e0797f374e498118da1e0c5")
addappid(1317160, 0, "9977ce8fa90309f0f0c337720d0ab3ec775f1a6f02d6034e6ad8a18157e514ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
