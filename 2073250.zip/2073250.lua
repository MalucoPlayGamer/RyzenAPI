-- Lua provided by RyzenAPI
-- Game: Rift of the NecroDancer

-- MAIN APPLICATION
addappid(3467170)
addappid(3550070)
addappid(3550080)
addappid(3550090)
addappid(3559850)
addappid(3626830)
addappid(3627050)
addappid(3627060)
addappid(3627070)
addappid(3627080)
addappid(3627090)
addappid(3627100)
addappid(3627110)
addappid(3627120)
addappid(3627130)
addappid(3627140)
addappid(3627150)
addappid(3627160)
addappid(3627170)
addappid(3627180)
addappid(3627190)
addappid(3725250)
addappid(3725270)
addappid(3725280)
addappid(3725290)
addappid(3725300)
addappid(3725310)
addappid(3830060)
addappid(3898480)
addappid(3898490)
addappid(3898500)
addappid(3898510)
addappid(3898520)
addappid(3898530)
addappid(3898540)
addappid(3898550)
addappid(3898560)
addappid(3898570)
addappid(3898580)
addappid(4174170)
addappid(4174190)
addappid(4174200)
addappid(4174210)
addappid(4174220)
addappid(4174230)
addappid(4349820)
addappid(4350140)
addappid(4350150)
addappid(4350180)
addappid(4350230)
addappid(4352430)
addappid(4352440)
addappid(4632820) -- Rift of the NecroDancer Celeste Music Pack
addappid(4632830) -- Rift of the NecroDancer Pizza Tower Music Pack
addappid(4632840) -- Rift of the NecroDancer hololive Music Pack
addappid(4632850) -- Rift of the NecroDancer Hatsune Miku Music Pack
addappid(4632860) -- Rift of the NecroDancer Everhood Music Pack
addappid(4632870) -- Rift of the NecroDancer Monstercat Music Pack
addappid(4632880) -- Rift of the NecroDancer Shovel Knight Music Pack
addappid(4632890) -- Rift of the NecroDancer Friday Night Funkin Music Pack
addappid(4654210)
addappid(4706330)
-- addappid(3725230) -- Depot 3725230 (empty depot)
-- addappid(3725240) -- Depot 3725240 (empty depot)
-- addappid(3725260) -- Depot 3725260 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073250, 1, "0b6ca1d9c88455d6ac1096de88585db96ff084f284219f56fc05d100441bedda") -- Rift of the NecroDancer
addappid(2073251, 1, "f3424a6f32150d03e898c114191451b63081675764e3e0ddf0ce6bd0734d666b") -- Depot 2073251
addappid(2073259, 1, "03c395318054183a5c4c60cd4df462cacec4c9f7415e76c07cf98ce31c4554e9") -- Depot 2073259
addappid(3467170, 1, "4e3a42f92f481f77ae7843e6844ee9049f90cfdd302f49d4b122b7ff66f32c53") -- Rift of the NecroDancer Supporter Upgrade - Depot 3467170
addappid(3550070, 1, "c5e0fad38f92ce6a0e378522bd6bf74fe53e6a04ef0a7e145bffa46dbe17db46") -- Rift of the NecroDancer Celeste - Scattered and Lost - Lena Raine - Depot 3550070
addappid(3550080, 1, "984ddac2c098b4f37550c8ed9d2980ea03a899ee21e3f6b28078cc83aeb200fe") -- Rift of the NecroDancer Celeste - Reach for the Summit - Lena Raine - Depot 3550080
addappid(3550090, 1, "f7f47e5a2539f979b3d3ff86bf0625cdfe0c5ca4050ab97342c9da12de938bfc") -- Rift of the NecroDancer Celeste - Confronting Myself - Lena Raine - Depot 3550090
addappid(3559850, 1, "0622d26edbb4448ab0e17c945e450b99bd9213d70988e87d5d26b43973faf231") -- Rift of the NecroDancer Celeste - Resurrections - Lena Raine - Depot 3559850
addappid(3626830, 1, "ce820de788301aa0b1eb935d055f0ec41c9cb6d996d573e15344c486d24edc75") -- Rift of the NecroDancer Pizza Tower - Its Pizza Time - Depot 3626830
addappid(3627050, 1, "e721c0138f3c18ebe8486e04478840bb193baddaba024c059cc5595575d75695") -- Rift of the NecroDancer Pizza Tower - The Death That I Deservioli - Depot 3627050
addappid(3627060, 1, "c21e1f8ba06713584702f71fede628be67ce8d3276c0c3c77933faf7c525e55f") -- Rift of the NecroDancer Pizza Tower - Unexpectancy, Pt. 3 - Depot 3627060
addappid(3627070, 1, "e13987034b4aa231644f9ef8e85a81732af89ba4d9b773f5e65907288a2ce4f5") -- Rift of the NecroDancer Pizza Tower - World Wide Noise - Depot 3627070
addappid(3627080, 1, "545531d1fa71eed4f901e19b1f1e82279df4709588cbcb8e31f534463ebd489a") -- Rift of the NecroDancer VA-11 Hall-A Music Pack - Depot 3627080
addappid(3627090, 1, "2c04474815d27fe352df2faa8cab0fe2fe8f41cb94d76b5f29f3dff0d8e076db") -- Rift of the NecroDancer hololive - BIBBIDIBA - Depot 3627090
addappid(3627100, 1, "482f81a4237453c85b7a3fd841a5ebd8caf7d564f30eb255d82cd30b9469554b") -- Rift of the NecroDancer hololive - REFLECT - Depot 3627100
addappid(3627110, 1, "504d57a53d4383dacad5c233a0214c6ab022a4c9e5ca9a3ea2c6ae3f28723deb") -- Rift of the NecroDancer hololive - Play Dice - Depot 3627110
addappid(3627120, 1, "4f5c0daa0b6e5e4afc9b6b6c355f11992e5cc26b18629dcbf0474bec3ebbe813") -- Rift of the NecroDancer hololive - Ahoy  - Depot 3627120
addappid(3627130, 1, "78b5874d7bb27e3f96608fe7b1b6e203254cf0dc4ae9b14d2fe7ed6842eb15b8") -- Rift of the NecroDancer hololive - Carbonated Love - Depot 3627130
addappid(3627140, 1, "611cd4aaa0b67cb3d7e710a4bb85927bfc43d99ce0f68cfd7a962709dc7ffb47") -- Rift of the NecroDancer Hatsune Miku - Too Real - Depot 3627140
addappid(3627150, 1, "4ccca58cda3863cb5a612c23e15fef74527d2c3cbdc980c6ce2ab4bf045b9248") -- Rift of the NecroDancer Hatsune Miku - MGICALCURE LOVE  SHOT - Depot 3627150
addappid(3627160, 1, "e5cf25d96b92ab96eeb8bd421d853d30271441d3248b3ed591b91f57b43e24df") -- Rift of the NecroDancer Hatsune Miku - Intergalactic Bound - Depot 3627160
addappid(3627170, 1, "4922d7366962aa0b7d4a8b4eb7fe5c75b3855583f452c3d883b3d96efd48d90b") -- Rift of the NecroDancer Hatsune Miku - Just 1dB Louder - Depot 3627170
addappid(3627180, 1, "bdc3de612dad1cb3878e9af83bf5f6d666ae6168bde8a7dd2084339367ed26de") -- Rift of the NecroDancer Hatsune Miku - MikuFiesta - Depot 3627180
addappid(3627190, 1, "0160345dcaeaa4de213b5516d2341867c85b5c721522cecb9e753a24d7a48632") -- Rift of the NecroDancer Hatsune Miku - Radiant Revival - Depot 3627190
addappid(3725250, 1, "ed2f0c1960f04ee46a314d44b707f4a035693e2163875cd7c5e4033e5e57d8f2") -- Rift of the NecroDancer VA-11 Hall-A - YLIAD - Garoad - Depot 3725250
addappid(3725270, 1, "de5c4691bfc53c008a14bcbbe7c77f269d8f1df64472740b28f6b1e38c58bf04") -- Rift of the NecroDancer Everhood - The Final Battle - Depot 3725270
addappid(3725280, 1, "6be8037532fc4c5ffd3bfed10f8b3aac18cf5b42642c80d63190f0e1b400bc87") -- Rift of the NecroDancer Everhood - Feisty Flowers - Depot 3725280
addappid(3725290, 1, "e39aadc6814c324e49e7e06c5db3edefe95f10561f5d163e9c7277705d677817") -- Rift of the NecroDancer Everhood - Revenge - Depot 3725290
addappid(3725300, 1, "c4df9663dcf8df47e29437f428f21355993479a5e70a421a993eaaf6d6e699f0") -- Rift of the NecroDancer Everhood - Why Oh You Are LOVE - Depot 3725300
addappid(3725310, 1, "e423cd31efde2d6466661829f7dd5a93c97ab8a1d6b5b857b2d1f4da109fb34a") -- Rift of the NecroDancer Everhood - Powers of Destruction - Depot 3725310
addappid(3830060, 1, "f516bbdf46b0b3db3d2029c43f76a51aa7abcbd707dcc3df1e5272f3d33530ce") -- Rift of the NecroDancer UNBEATABLE - WORN OUT TAPES [tally-ho version] - peak divide ft. Rachel Lake - Depot 3830060
addappid(3898480, 1, "ea9f729e815f258bbd7dd12c429f7631981d878d684c847f77dbadd08560ea0e") -- Rift of the NecroDancer Monstercat - Final Boss - Depot 3898480
addappid(3898490, 1, "bca0044516b44385eed86f0a769601cb8a7e81258b3d4d7edaa50f3576650539") -- Rift of the NecroDancer Monstercat - New Game - Depot 3898490
addappid(3898500, 1, "fcd34f8b9073d1f9b0de162ebed90dbb15f7696bfdcbf9203ba0137c1d418868") -- Rift of the NecroDancer Monstercat - Crab Rave - Depot 3898500
addappid(3898510, 1, "3dc6654e6ea2a7e73bf06e41d910aaf0dbbebb7a3fbaad6da5c50b81862aed24") -- Rift of the NecroDancer Monstercat - PLAY - Depot 3898510
addappid(3898520, 1, "074bab334fc9622d1a91e0684af4c1dc39e68e70e7552db8f5e535ed43211851") -- Rift of the NecroDancer Monstercat - Waiting For You - Depot 3898520
addappid(3898530, 1, "49512b4a7b4868189099dfaa4a315cfba1ed6e040d37cbd63e1944f3fc34b07a") -- Rift of the NecroDancer Shovel Knight - Main Theme - Jake Kaufman - Depot 3898530
addappid(3898540, 1, "551ad7ada442a90bb8f2c0f93c9c46af966a78b5dd04c192302bd1cce6703538") -- Rift of the NecroDancer Shovel Knight - La Danse Macabre (Lich Yard) - Jake Kaufman - Depot 3898540
addappid(3898550, 1, "6aeb0d0c403384ec3a878991b69d7c5fcdd744511667484cc73927e589aff74b") -- Rift of the NecroDancer Shovel Knight - Strike the Earth (Plains of Passage) - Jake Kaufman - Depot 3898550
addappid(3898560, 1, "91ecb413b9b3a432de3bdd86cd453e6634a26172f3935db3ce5a1560e65390ee") -- Rift of the NecroDancer Shovel Knight - In the Halls of the Usurper (Pridemoor Keep) - Jake Kaufman - Depot 3898560
addappid(3898570, 1, "a760ab40a016d49731a64d2d79eef1571cb801dcbb39af0e65e5c6cff30e7751") -- Rift of the NecroDancer Shovel Knight - High Above the Land (The Flying Machine) - Jake Kaufman - Depot 3898570
addappid(3898580, 1, "daeae93277bded6d5864a9c90f1123875d188a4081f92c7df7f9a3da75c95809") -- Rift of the NecroDancer Shovel Knight - An Underlying Problem (The Lost City) - Jake Kaufman - Depot 3898580
addappid(4174170, 1, "bc34c0ff791d9138241b2d7f831523de1d9c0b7e0bd1f41d177ff11922c8c93f") -- Rift of the NecroDancer Friday Night Funkin - Dad Battle - Kawai Sprite - Depot 4174170
addappid(4174190, 1, "f6737b0ca4777ed22d27ac5d4ec7267294ada182cfa01792fc6ce47e11206e8a") -- Rift of the NecroDancer Friday Night Funkin - Blammed - Kawai Sprite - Depot 4174190
addappid(4174200, 1, "a0929f898c8df9977283a0422ce4290dd7f387e6945c8d64d131371c2e8c60a1") -- Rift of the NecroDancer Friday Night Funkin - Stress - Kawai Sprite - Depot 4174200
addappid(4174210, 1, "9c1ffdccc6d30bacd62840a97a37e8743f56fa5abff697020c7a709b3415f53b") -- Rift of the NecroDancer Friday Night Funkin - Darnell - Kawai Sprite - Depot 4174210
addappid(4174220, 1, "e2f5e86b966bf209a11de8944fe65885eb08c0c6f5f0090d3b6b843e1bef1d5a") -- Rift of the NecroDancer Friday Night Funkin - Ugh - Kawai Sprite - Depot 4174220
addappid(4174230, 1, "1c34d441e639e6aaa07952b0f658992d33468ef2f204d2d5577f0d9f77396293") -- Rift of the NecroDancer Friday Night Funkin - Senpai - Kawai Sprite - Depot 4174230
addappid(4349820, 1, "ab3a55e1bf9e7d787d0f205509e6330f9b2881096feeafa86019cbaf68ba4d44") -- Rift of the NecroDancer Spin Rhythm XD - The Magician - Seejay - Depot 4349820
addappid(4350140, 1, "52da0cb97e1c9aca57899b4abe004f52a10f8b21136418c601fc6f5e871cd58c") -- Rift of the NecroDancer OST Vol. 2 - Ultra Creepy - Danny Baranowsky - Depot 4350140
addappid(4350150, 1, "21f537dc3a6f20243bfd14910d6d730de2fa3f478e56952eeceb981daad089fc") -- Rift of the NecroDancer KDA (Riot Games) Music Pack - Depot 4350150
addappid(4350180, 1, "96bb6ee18c5d972c778afbdbff68cba14957c9f97180a731682cd404c26ab0e0") -- Rift of the NecroDancer UNDERTALE Music Pack - Depot 4350180
addappid(4350230, 1, "127941f6dc70fea414d936f8d5aebbac27d732e8bab14c3816df47cd9e115129") -- Rift of the NecroDancer UNDERTALE - Spider Dance - Toby Fox - Depot 4350230
addappid(4352430, 1, "a3ce1b0c5d6427b96bbeac6b7ce3dc3c088de021d81bb9dfb86703b1a345929b") -- Rift of the NecroDancer Omega Strikers - The Girl Who Glitched (Ai.Mis Theme) - Garrett Williamson - Depot 4352430
addappid(4352440, 1, "70db506f113d788bb48aa27187fbc4114f4cbc70d2b5ed531cc98ea5a017d0bd") -- Rift of the NecroDancer Omega Strikers Music Pack - Depot 4352440
addappid(4654210, 1, "5e2bac251f6090d3c3ecb9d29262574a0e5cea4f5c2b2c6fc957db253b940096") -- Rift of the NecroDancer Among Us - Sought (Seek Remix) - Danny Baranowsky - Depot 4654210
addappid(4706330, 1, "f6dd28b893fa185e3c8b5c57b5de1b53c65582edeb8842e90e864ead09a5ac2c") -- Rift of the NecroDancer OST Volume 2 Music Pack - Depot 4706330

