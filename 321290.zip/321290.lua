-- Lua provided by RyzenAPI
-- Game: 321290

-- MAIN APPLICATION
addappid(321290)
-- Game: addappid(321290)

-- MAIN APP DEPOTS / PACKAGES
addappid(321291, 1, "8cd7f5df091829c11e9113553b5b581be6c867d491356e1c0e3a7e6f1d0360f1")
addappid(321293, 1, "1026902335bef3180d363008c41efa5cc59a36e05ab7ec0a8f4a7de7555bf1a4")
addappid(404450, 0, "8b28b4d300afd1976b78f151f8cdc3c018d088084fb1c22adfcdafda3edf1bd7")
