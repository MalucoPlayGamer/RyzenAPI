-- Lua provided by RyzenAPI 
-- Game: Women's Prison
addappid(1706650)
addappid(1706651, 1, "f4de0f85dfd1888e923439e30e9a455007fb94d36925611fae60f373094a68bd")
