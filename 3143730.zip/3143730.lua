-- Lua provided by RyzenAPI
-- Game: Game: Lazarus -Side Story of COMRADE FORCE-

-- MAIN APPLICATION
addappid(3143730)
-- Game: addappid(3143730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143731, 1, "b619c52825275a07cbf3720ac888975207a0f96156726d8abee5e4de85fb9b89")
