-- Lua provided by RyzenAPI 
-- Game: AppID 798180
addappid(798180)
addappid(798181, 1, "f8da8fb7940bbbe7ccc002f12cb7e73099636775b9a41d68f4feb0feca80d7de")
