-- Lua provided by RyzenAPI
-- Game: Pierrot à la Mode

-- MAIN APPLICATION
addappid(3074380)
-- Game: addappid(3074380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074382,0,"6df310584c25aa26c5d466c43eabf5e3bb5e834e851988cd202031ffaf14d899")
addappid(3074383,0,"2bbb81c603ebf0bb124bd790b278c78913d369057d07746af2e8aa0820482aa5")
