-- Lua provided by RyzenAPI
-- Game: 732370

-- MAIN APPLICATION
addappid(732370)
-- Game: addappid(732370)

-- MAIN APP DEPOTS / PACKAGES
addappid(732371, 1, "51b51a81caa136eddf4825a0666102dc91529eaa0534361c239f230f8b85b8bd")
addappid(732372, 1, "e110f6cf242a1f24cc941fc3995956cf78d2e563403bce78bf84d7855dbbc994")
