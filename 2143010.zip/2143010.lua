-- Lua provided by RyzenAPI
-- Game: Convenient

-- MAIN APPLICATION
addappid(2143010)
-- Game: addappid(2143010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143011, 1, "4c50f1684785873f5e9c60b50fab328008cd142111fb007067305abe6311b66f")
