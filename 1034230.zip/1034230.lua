-- Lua provided by RyzenAPI
-- Game: ***

-- MAIN APPLICATION
addappid(1034230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1034231, 1, "5b2ffe963ac014b7522cdc27e7a7c10623e8c8f76fa5517d84290990323533d3")

