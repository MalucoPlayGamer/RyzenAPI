-- Lua provided by RyzenAPI
-- Game: ***

-- MAIN APPLICATION
addappid(1034230)
-- Game: addappid(1034230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034231, 1, "5b2ffe963ac014b7522cdc27e7a7c10623e8c8f76fa5517d84290990323533d3")
