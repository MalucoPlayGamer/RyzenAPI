-- Lua provided by RyzenAPI 
-- Game: ***
addappid(1034230)
addappid(1034231, 1, "5b2ffe963ac014b7522cdc27e7a7c10623e8c8f76fa5517d84290990323533d3")
