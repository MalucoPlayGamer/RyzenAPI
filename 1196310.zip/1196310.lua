-- Lua provided by RyzenAPI
-- Game: addappid(1196310)

-- MAIN APPLICATION
addappid(1196310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196311, 1, "775e122ebc7a4df99d613dcfbd24e3adb43976c2e396b7c59f92e665b731d275")
