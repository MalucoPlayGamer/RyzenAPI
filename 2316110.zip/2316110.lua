-- Lua provided by RyzenAPI
-- Game: Saving Mei

-- MAIN APPLICATION
addappid(2316110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316111, 1, "a84755f96eee1946b7f55c16c96ac212a8d3f628cfe401a252e2ea229679d69b")
