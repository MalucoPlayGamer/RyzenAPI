-- Lua provided by RyzenAPI
-- Game: ❂ Hexaluga ❂ Dungeons and Hunting ☠

-- MAIN APPLICATION
addappid(860670)

-- MAIN APP DEPOTS / PACKAGES
addappid(860671,0,"710193f968667325bdacc3b8881c9f9d07128197e46f4ddfc750272476fac527")

