-- Lua provided by RyzenAPI
-- Game: 2175210

-- MAIN APPLICATION
addappid(2175210)
-- Game: addappid(2175210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175211, 1, "bc440a4b90e317373b6e839a4d3e9b1e70288038cbd19f6f8a79863b6d9e4b8d")
