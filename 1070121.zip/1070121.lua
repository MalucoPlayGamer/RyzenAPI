-- Lua provided by RyzenAPI
-- Game: Crystar - Nanana's Comic Outfit

-- MAIN APPLICATION
addappid(1070121)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070121,0,"7f8e0738c11af83b8e2bd2b9d6151fadb303bde030190fe3f019475ae5934855")

