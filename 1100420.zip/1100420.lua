-- Lua provided by RyzenAPI
-- Game: AppID 1100420

-- MAIN APPLICATION
addappid(1100420)
addappid(1191750)
addappid(1191751)
addappid(1191752)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1100421, 1, "0bf5d9e5b3b90b66565e79587703416c4ef7e6963e026eca850d12b86434d28c")
addappid(1100422, 1, "70560ee7acf14561f7c7b228c3bca2e21c027d6e2dc641d343360e77c4be8aa4")

