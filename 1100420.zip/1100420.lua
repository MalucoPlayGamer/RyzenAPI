-- Lua provided by RyzenAPI
-- Game: Game: AppID 1100420

-- MAIN APPLICATION
addappid(1100420)
addappid(1191750)
addappid(1191751)
addappid(1191752)
-- Game: addappid(1100420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100421, 1, "0bf5d9e5b3b90b66565e79587703416c4ef7e6963e026eca850d12b86434d28c")
addappid(1100422, 1, "70560ee7acf14561f7c7b228c3bca2e21c027d6e2dc641d343360e77c4be8aa4")
