-- Lua provided by RyzenAPI
-- Game: Gluua

-- MAIN APPLICATION
addappid(1664810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664811, 1, "3349b516bf375e50212ad5ecaebdc86b322962e0604a86ab84dd4a10043543f9")
