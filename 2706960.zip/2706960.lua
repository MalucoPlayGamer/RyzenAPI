-- Lua provided by RyzenAPI
-- Game: 027

-- MAIN APPLICATION
addappid(2706960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706961, 1, "db85b96f25785b829a2bda6fb53a999cdd5f6cc51fdc743024b6815d963c0b39")