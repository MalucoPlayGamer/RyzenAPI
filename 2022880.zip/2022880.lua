-- Lua provided by SkyAPI 
-- Game: Truxton
addappid(2022880)
addappid(2022881, 1, "8236117c3c2b046c6813ffd8aef0fee4f29a4cfb05c607431b2526f17c78f5e9")
