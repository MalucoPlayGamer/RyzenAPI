-- Lua provided by RyzenAPI
-- Game: Truxton

-- MAIN APPLICATION
addappid(2022880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2022881, 1, "8236117c3c2b046c6813ffd8aef0fee4f29a4cfb05c607431b2526f17c78f5e9")

