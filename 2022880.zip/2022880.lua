-- Lua provided by RyzenAPI
-- Game: addappid(2022880)

-- MAIN APPLICATION
addappid(2022880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022881, 1, "8236117c3c2b046c6813ffd8aef0fee4f29a4cfb05c607431b2526f17c78f5e9")
