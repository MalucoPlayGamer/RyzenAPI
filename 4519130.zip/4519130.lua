-- Lua provided by RyzenAPI
-- Game: MOLDRISE

-- MAIN APPLICATION
addappid(4519130)

-- MAIN APP DEPOTS / PACKAGES
addappid(4519132,0,"657a9bd87fa5635826abb5e3f63567020dbdc97c66f6eecf2fa78521c2a9adc7")

