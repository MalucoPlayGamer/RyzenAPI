-- Lua provided by RyzenAPI
-- Game: Travel Riddles: Mahjong

-- MAIN APPLICATION
addappid(909430)

-- MAIN APP DEPOTS / PACKAGES
addappid(909431, 1, "fc7c5ff7ebe11952075845a52d7bf8e72c648619676fc43fb9a85fcb17227408")
addappid(909432, 1, "7a3c1f086c5fbd7f859b4cc73463528357d20398a97af701cf8a052e0c559520")

