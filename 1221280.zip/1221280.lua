-- Lua provided by RyzenAPI
-- Game: Run Dude

-- MAIN APPLICATION
addappid(1221280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221281, 1, "bf35ea136f64bab3f496ea67f429b9b66819612ff19628f24fee83faf7bc1da0")

