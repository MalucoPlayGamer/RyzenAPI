-- Lua provided by RyzenAPI
-- Game: NINJA GAIDEN Σ [NINJA GAIDEN: Master Collection]

-- MAIN APPLICATION
addappid(1580780)
-- Game: addappid(1580780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580781, 1, "bb543a47bf3b5af1cec50b251f74e45c3971d238157cd602fc0ab13fc2e1db10")
addappid(1580782, 1, "e010750ce2862afdcd43ff22d609f9b5ee98f7ebca60cc891cd3ad4a884d4a52")
