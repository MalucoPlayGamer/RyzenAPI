-- Lua provided by RyzenAPI
-- Game: NINJA GAIDEN Σ [NINJA GAIDEN: Master Collection]

-- MAIN APPLICATION
addappid(1580780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580781, 1, "bb543a47bf3b5af1cec50b251f74e45c3971d238157cd602fc0ab13fc2e1db10")
addappid(1580782, 1, "e010750ce2862afdcd43ff22d609f9b5ee98f7ebca60cc891cd3ad4a884d4a52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
