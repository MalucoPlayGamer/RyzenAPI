-- Lua provided by RyzenAPI
-- Game: Castle of Shikigami

-- MAIN APPLICATION
addappid(582980)
addappid(675390)
-- Game: addappid(582980)

-- MAIN APP DEPOTS / PACKAGES
addappid(582981, 1, "1977cd7dc04d833f2a8c6e19defae805f7cec74101626c67f91edd3ad356d14c")
