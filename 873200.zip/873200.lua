-- Lua provided by RyzenAPI
-- Game: Teleportals. I swear it's a nice game

-- MAIN APPLICATION
addappid(873200)

-- MAIN APP DEPOTS / PACKAGES
addappid(873201, 1, "6b20c0dc405b031a0c2b6ea41a06f94f8293b7578d4cb509fab88b35f67a7273")

