-- Lua provided by RyzenAPI
-- Game: 873200

-- MAIN APPLICATION
addappid(873200)
-- Game: addappid(873200)

-- MAIN APP DEPOTS / PACKAGES
addappid(873201, 1, "6b20c0dc405b031a0c2b6ea41a06f94f8293b7578d4cb509fab88b35f67a7273")
