-- Lua provided by RyzenAPI
-- Game: Game: Atomorf

-- MAIN APPLICATION
addappid(1122830)
-- Game: addappid(1122830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122831, 1, "5c745aa12f97b67c6de69ece600aa9d58fa22b25797486f11cbc541a010d8413")
