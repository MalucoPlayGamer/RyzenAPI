-- Lua provided by RyzenAPI
-- Game: CABAL Online

-- MAIN APPLICATION
addappid(253490)
-- Game: addappid(253490)

-- MAIN APP DEPOTS / PACKAGES
addappid(253493,0,"a06a40def2669e06e3dbfdfab18e8f8dda5bee46d822599e2dbadaccaa9ea0fb")
