-- Lua provided by RyzenAPI
-- Game: Pineapple on pizza

-- MAIN APPLICATION
addappid(2263010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263011, 1, "1bfc8dd5ea148bb3813e9c81948fae645ba5ea0bf5d76c8d1d7f28118b775ba8")
addappid(2263012, 1, "46af9d38cea64ef11ac4cb8c968a11de88c33115706ae8c73ff6e473fef15c3d")
addappid(2263013, 1, "5f0cd8655b28c91f4b1f08f1b508c77522d52a1dd9a3562a949924865fa99f51")
addappid(2263014, 1, "e2ec0f79bdd391dd46d9d63142ca5b9e89a6aaaa7840fb2053f267f33fa4827f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
