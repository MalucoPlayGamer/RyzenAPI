-- Lua provided by RyzenAPI 
-- Game: Pineapple on pizza
addappid(2263010)
addappid(2263011, 1, "1bfc8dd5ea148bb3813e9c81948fae645ba5ea0bf5d76c8d1d7f28118b775ba8")
addappid(2263012, 1, "46af9d38cea64ef11ac4cb8c968a11de88c33115706ae8c73ff6e473fef15c3d")
addappid(2263013, 1, "5f0cd8655b28c91f4b1f08f1b508c77522d52a1dd9a3562a949924865fa99f51")
addappid(2263014, 1, "e2ec0f79bdd391dd46d9d63142ca5b9e89a6aaaa7840fb2053f267f33fa4827f")
