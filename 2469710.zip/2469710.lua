-- Lua provided by RyzenAPI
-- Game: Forest of Strays

-- MAIN APPLICATION
addappid(2469710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469711, 1, "28809503c06ebd86f5076cc0e333aa085527d6a8fa82641e075d82d74245349a")

