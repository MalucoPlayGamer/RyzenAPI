-- Lua provided by RyzenAPI
-- Game: Happy toys

-- MAIN APPLICATION
addappid(977640)

-- MAIN APP DEPOTS / PACKAGES
addappid(977641, 1, "f83286647e6d311ab948e91320b040ef2e2dbb06cac219e1dab116debc9daa49")
