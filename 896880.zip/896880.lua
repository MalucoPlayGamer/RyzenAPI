-- Lua provided by SkyAPI 
-- Game: AppID 896880
addappid(896880)
addappid(896881, 1, "7a87da9888494648378c8997ef1d4c35c6c3c47eb92f437b59361e93154c4899")
