-- Lua provided by RyzenAPI
-- Game: Game: AppID 896880

-- MAIN APPLICATION
addappid(896880)
-- Game: addappid(896880)

-- MAIN APP DEPOTS / PACKAGES
addappid(896881, 1, "7a87da9888494648378c8997ef1d4c35c6c3c47eb92f437b59361e93154c4899")
