-- Lua provided by RyzenAPI
-- Game: The Showdown Effect: Reloaded

-- MAIN APPLICATION
addappid(2242420)
addappid(2817220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242421, 1, "e8c12c754e50d61f8762000c31790ac56235199819ce733ae7fbebaba8584e3b")
