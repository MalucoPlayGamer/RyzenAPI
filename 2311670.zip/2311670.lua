-- Lua provided by RyzenAPI 
-- Game: Girls of the Lust City and the Avenger
addappid(2311670)
addappid(2311671, 1, "86d6e567bd6fecf550ef802a15de7e8f3397e723b2e064622122681c7dddfd36")
addappid(2767090, 0, "1bf97f6da32572d2d7fef858855bfb1106b0a2ca3ecc77a23d818dbc322b7602")
