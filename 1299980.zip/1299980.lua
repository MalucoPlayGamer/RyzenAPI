-- Lua provided by RyzenAPI
-- Game: Game: CursorFX

-- MAIN APPLICATION
addappid(1299980)
-- Game: addappid(1299980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299981, 1, "b5190112cb04ba26ea76317b90361e910003ffff8c605a498c43501654557f2a")
