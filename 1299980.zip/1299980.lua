-- Lua provided by SkyAPI 
-- Game: CursorFX
addappid(1299980)
addappid(1299981, 1, "b5190112cb04ba26ea76317b90361e910003ffff8c605a498c43501654557f2a")
