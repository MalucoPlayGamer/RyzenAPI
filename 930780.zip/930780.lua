-- Lua provided by RyzenAPI
-- Game: addappid(930780)

-- MAIN APPLICATION
addappid(930780)

-- MAIN APP DEPOTS / PACKAGES
addappid(930781, 1, "dd306a709eb1c857156b0a0b6eba09b277aa59d8314fd13b7dce66e27288368a")
addappid(930782, 1, "2f5433aefce640ee02a3f673ffef4831b743641763b3b1a0a25b91e49423fb29")
