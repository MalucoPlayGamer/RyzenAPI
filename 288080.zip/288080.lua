-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(288080)

-- MAIN APP DEPOTS / PACKAGES
addappid(288082,0,"5f22d0bf8b0e5f6406e83e97193e036d10f13596cce7c1efc60b2648ac4016e7")

