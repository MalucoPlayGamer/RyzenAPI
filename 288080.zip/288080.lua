-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(288080)
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(288082,0,"5f22d0bf8b0e5f6406e83e97193e036d10f13596cce7c1efc60b2648ac4016e7")
-- setManifestid(288082,"6149342849432448451")