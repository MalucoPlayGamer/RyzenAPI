-- Lua provided by RyzenAPI
-- Game: 逢魔之時

-- MAIN APPLICATION
addappid(1483600)
-- Game: addappid(1483600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483601, 1, "20b4e5067c04183565939c8edc46298221a951944d2a279dde37bce074593c50")
