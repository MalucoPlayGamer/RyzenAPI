-- Lua provided by SkyAPI 
-- Game: Mess Adventures
addappid(1381530)
addappid(1381531, 1, "e28cc39b295a181c425f010d78f06cd117f605e2d98fa5852315447d83963a62")
addappid(1381532, 1, "0de00814145844c2f6aaf9232e34deda8d0f4bb27d55ab7c489e42700a480b4f")
