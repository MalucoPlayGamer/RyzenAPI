-- Lua provided by RyzenAPI
-- Game: 1658310

-- MAIN APPLICATION
addappid(1658310)
-- Game: addappid(1658310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658311, 1, "72f3fe0fe313e79a07afb879d48f8a264b67f2879cc5197c471131d9fe0a27c6")
