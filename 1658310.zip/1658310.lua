-- Lua provided by SkyAPI 
-- Game: Wolf of Stock Street
addappid(1658310)
addappid(1658311, 1, "72f3fe0fe313e79a07afb879d48f8a264b67f2879cc5197c471131d9fe0a27c6")
