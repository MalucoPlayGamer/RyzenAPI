-- Lua provided by SkyAPI 
-- Game: Unholy Angel
addappid(2224860)
addappid(2224861, 1, "6ca21586c0d3418d03921c486933b956d02095d9e815e791915914a6fbb72831")
