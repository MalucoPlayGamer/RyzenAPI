-- Lua provided by RyzenAPI
-- Game: Game: Equalizer

-- MAIN APPLICATION
addappid(666250)
-- Game: addappid(666250)

-- MAIN APP DEPOTS / PACKAGES
addappid(666251, 1, "a3da296afaea81065232583c8e4be58c210047d2b25e40c954b4223ac4f10900")
