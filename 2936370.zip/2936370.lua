-- Lua provided by RyzenAPI
-- Game: Escape from the Cannibal Family

-- MAIN APPLICATION
addappid(2936370)
-- Game: addappid(2936370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936371, 1, "5cb49c2a53e12d6f28d84cbc051f6be8d42622e7140520e2b28c654e03e602e6")
