-- Lua provided by RyzenAPI
-- Game: OVIS LOOP Demo

-- MAIN APPLICATION
addappid(2277700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277701, 1, "aa8eedfeeb8224e2b2e18d72007756f60a778bf86caab950231ba26f26d6225b")

