-- Lua provided by RyzenAPI 
-- Game: Corner Kitchen Fast Food Simulator Demo
addappid(3361010)
addappid(3361011, 1, "dc6a34c4a0f685efb770c3619d21e0063fbd06f21275f02ef43e78305e080e9b")
