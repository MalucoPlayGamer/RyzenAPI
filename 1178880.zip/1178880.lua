-- Lua provided by RyzenAPI
-- Game: Panzer Dragoon: Remake

-- MAIN APPLICATION
addappid(1178880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178881, 1, "78d8686f087e46faad79c0156a02d2a7d6897ebdf33c0f0f4068c6509ed6aa07")
