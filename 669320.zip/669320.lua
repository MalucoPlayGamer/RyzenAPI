-- Lua provided by RyzenAPI
-- Game: Nation War:Chronicles

-- MAIN APPLICATION
addappid(669320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(669321, 1, "fe0c65ee64f065479e6ac4020905e66a33e8b2a9514a009d873e8dda708af249")
addappid(669322, 1, "2046fccc30d6b24d5801c9c91c74ade30e9e43b69fe67fa263d10ce519ccb096")
