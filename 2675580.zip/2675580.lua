-- Lua provided by RyzenAPI
-- Game: addappid(2675580)

-- MAIN APPLICATION
addappid(2675580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675581, 1, "eaaba3eb569df6cfdb0c219754e3250fc537a2f345b0cc6009d3760c65c34b00")
