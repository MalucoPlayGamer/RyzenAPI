-- Lua provided by RyzenAPI
-- Game: Mothers and Daughters

-- MAIN APPLICATION
addappid(2508400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508401, 1, "cb6d6d5bdc461f4fff896e49d3c2667cb49d4342c79c6e25b46e01db2926a269")

