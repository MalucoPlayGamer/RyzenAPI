-- Lua provided by RyzenAPI
-- Game: 825080

-- MAIN APPLICATION
addappid(825080)
-- Game: addappid(825080)

-- MAIN APP DEPOTS / PACKAGES
addappid(825081, 1, "3ce606afc0bd0f5a66fb93777a11d14434f8c4c1f7db716c9474f077f1b631a1")
