-- Lua provided by RyzenAPI
-- Game: Breaking Beaver

-- MAIN APPLICATION
addappid(3631070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631071, 1, "0a897da2cb70157bc47ae148124321d6c492c9d6e3d9ec1530029ee4dd624df2")
addtoken(3631070, "17169522939695063610")

