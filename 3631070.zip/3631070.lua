-- Generated with Luie @ https://lua.tools/
-- 3631070 - Breaking Beaver
-- Generated 2026-08-27 22:21:30 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(3631070)
addtoken(3631070, "17169522939695063610")

-- Main Depots
addappid(3631071, 1, "0a897da2cb70157bc47ae148124321d6c492c9d6e3d9ec1530029ee4dd624df2")
setManifestid(3631071, "5740718201191261796", 195934157)
