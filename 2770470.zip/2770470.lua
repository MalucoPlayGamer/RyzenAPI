-- Lua provided by SkyAPI 
-- Game: 悟道（体验版）
addappid(2770470)
addappid(2770471, 1, "511733333fa38a20fddca24d88439c33bc02ef3996d9f6c63eb71d3205596445")
