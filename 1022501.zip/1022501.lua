-- Lua provided by RyzenAPI
-- Game: 1022501

-- MAIN APPLICATION
addappid(1022501)
-- Game: addappid(1022501)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022501,0,"2d8bcaf05c9fe695b0df21d7fa6cbdf7e4a70dd19bf66e26a2709c630f98732d")
