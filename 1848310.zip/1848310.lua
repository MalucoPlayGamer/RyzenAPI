-- Lua provided by RyzenAPI 
-- Game: Just in Slime
addappid(1848310)
addappid(1848311, 1, "061f6f9e048b5275e382df3db48e41ac0ebd67678cda8f4a5807def733ac038a")
