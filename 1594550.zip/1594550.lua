-- Lua provided by RyzenAPI
-- Game: Erophone - 18+ Adult Only Content

-- MAIN APPLICATION
addappid(1594550)
-- Game: addappid(1594550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594550,0,"8fa3a6fcbca0601d848bdb5e859fd10b8795d6bdb87dff46bd8e18fa7b78e071")
