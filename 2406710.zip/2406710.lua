-- Lua provided by RyzenAPI
-- Game: Backrooms Society Demo

-- MAIN APPLICATION
addappid(2406710)
-- Game: addappid(2406710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406711, 1, "b42fb15a4f3fd5ce18faff8118b17cd266aa0f5c99b1dc013f80bae549a74f9f")
