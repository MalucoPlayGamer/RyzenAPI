-- Lua provided by RyzenAPI
-- Game: 2707410

-- MAIN APPLICATION
addappid(2707410)
-- Game: addappid(2707410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707411, 1, "00dafe7a2529b5258f7fd356d828044d3ee469c107d085aa05f68989cc7b07f6")
