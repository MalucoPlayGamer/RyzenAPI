-- Lua provided by RyzenAPI
-- Game: Iron Line

-- MAIN APPLICATION
addappid(2707410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707411, 1, "00dafe7a2529b5258f7fd356d828044d3ee469c107d085aa05f68989cc7b07f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
