-- Lua provided by RyzenAPI
-- Game: Game: Digital LimitedPack [OST + Art Book]

-- MAIN APPLICATION
addappid(1633540)
-- Game: addappid(1633540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633541, 1, "281be0fab0299210490ef4b775f448a7d146f196d7f349e5682c6642d7959b2e")
addappid(1633542, 1, "6696ff5dd07527d9e414bcce3e9bde6d639c34f6aad27b4986ae119ba7b1f93b")
addappid(1633543, 1, "8f07cc510df4b7dbcdc181cb0892d8ab010624b11d9032d5e428996e413486d4")
addappid(1633544, 1, "6d2aa7a3b2d4fca1f101b3767d01015d24368b043e271df046321b82f21bb7ce")
