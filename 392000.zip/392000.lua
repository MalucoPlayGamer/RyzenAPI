-- Lua provided by RyzenAPI
-- Game: TRON RUN/r

-- MAIN APPLICATION
addappid(392000)

-- MAIN APP DEPOTS / PACKAGES
addappid(392001, 1, "f4aeb854cddc93e65cdeb570e566f99ed2a5395bd93dd0bd5f159dad168869d5")
addappid(413661, 0, "32305fc73f53d15ffca7196714eb1ae9a26e4d3854dc7ff7c69aac9db4856493")
addappid(413662, 0, "c879a1b5603f3d8b746c274330b6233fef9d8a931c908159f3f19759659ef699")
addappid(413663, 0, "9db005c3342bec451a00646d30c09dd067d4656a2c9bb85a2e3ef78c631a7f97")
addappid(445150, 0, "7ff732ea38383c02ff90b17643d3d384d64dc1fe8d7b85721506980058e4944e")
addappid(486770, 0, "b78d2d62dc4997f59e2b593130a095d7b0dae33f82d96a5ecc668db580ee4f2c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(429460)
addappid(429461)
addappid(429462)
addappid(445280)
