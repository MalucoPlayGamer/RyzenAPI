-- Lua provided by RyzenAPI
-- Game: Backyard Brawl

-- MAIN APPLICATION
addappid(954170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(954171, 1, "a10872a23f87489b9b043e74442550e181bf19b2977bffe55339ad17082524f3")
