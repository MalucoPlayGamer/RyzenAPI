-- Lua provided by RyzenAPI 
-- Game: AppID 954170
addappid(954170)
addappid(954171, 1, "a10872a23f87489b9b043e74442550e181bf19b2977bffe55339ad17082524f3")
