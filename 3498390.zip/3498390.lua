-- Lua provided by RyzenAPI
-- Game: Astroloot

-- MAIN APPLICATION
addappid(3498390)
-- Game: addappid(3498390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3498391, 1, "2d60bf1cd65f860165590f233447aa54e1bb63ccb89b664ece9afb87bf4ba5b4")
