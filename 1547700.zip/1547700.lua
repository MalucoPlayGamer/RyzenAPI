-- Lua provided by RyzenAPI
-- Game: addappid(1547700)

-- MAIN APPLICATION
addappid(1547700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547700,0,"c31cd57608abc41ccf22c4dc13e6aa6cf2fa8805c7ec751aa06dbaf860ae9558")
