-- Lua provided by RyzenAPI
-- Game: Game: Branches

-- MAIN APPLICATION
addappid(1717420)
-- Game: addappid(1717420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717421, 1, "969cb6d6a6dcb8889046850f19e2c5d33fce203c932fe186cb46de91f6da950a")
