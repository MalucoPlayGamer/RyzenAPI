-- Lua provided by RyzenAPI 
-- Game: AppID 1249500
addappid(1249500)
addappid(1249501, 1, "c97586476820067e9d85b9daef659305f45b7d89b45dac441ef8e7f264088574")
