-- Lua provided by RyzenAPI
-- Game: addappid(1226300)

-- MAIN APPLICATION
addappid(1226300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226301, 1, "e8d2ac4c148906ee78d6b6e018700fd3c2a25cca2cdff1d8f23d21267eba929e")
