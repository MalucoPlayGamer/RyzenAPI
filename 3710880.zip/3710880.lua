-- Lua provided by RyzenAPI
-- Game: Tinkerlands - Supporter Pack

-- MAIN APPLICATION
addappid(3710880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3710880,0,"918207750296c856f4f8f1095b0b38390c9ff01c336ade848cd103af6f4fe9b6")

