-- Lua provided by RyzenAPI
-- Game: AppID 842100

-- MAIN APPLICATION
addappid(842100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(842101, 1, "f8914dc18d4332a8ef96e4238cb7c74fc4501861408680f3cc2c3e2ca622fac8")

