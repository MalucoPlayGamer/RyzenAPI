-- Lua provided by RyzenAPI
-- Game: Game: AppID 842100

-- MAIN APPLICATION
addappid(842100)
-- Game: addappid(842100)

-- MAIN APP DEPOTS / PACKAGES
addappid(842101, 1, "f8914dc18d4332a8ef96e4238cb7c74fc4501861408680f3cc2c3e2ca622fac8")
