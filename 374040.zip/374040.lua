-- Lua provided by RyzenAPI 
-- Game: Portal Knights
addappid(374040)
addappid(374041, 1, "a50a492cd588398e0b8d7827635a4331eaa6c7a626722137840b655e532dd725")
