-- Lua provided by RyzenAPI
-- Game: Portal Knights

-- MAIN APPLICATION
addappid(374040)

-- MAIN APP DEPOTS / PACKAGES
addappid(374041, 1, "a50a492cd588398e0b8d7827635a4331eaa6c7a626722137840b655e532dd725")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(837990)
addappid(851860)
addappid(851870)
addappid(918540)
addappid(1046050)
addappid(1085410)
addappid(1176870)
