-- Lua provided by RyzenAPI
-- Game: Dear Mirror Flower

-- MAIN APPLICATION
addappid(3543570)
-- Game: addappid(3543570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3543571, 1, "92842387e6841cbde71d8516c64c7d471caef135435d2add2de8bc84ac160e3d")
