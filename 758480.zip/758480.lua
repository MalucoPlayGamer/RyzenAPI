-- Lua provided by RyzenAPI
-- Game: Ukrainian ball in search of gas

-- MAIN APPLICATION
addappid(758480)
-- Game: addappid(758480)

-- MAIN APP DEPOTS / PACKAGES
addappid(758481, 1, "7750ddcf2f4a803faeb685b5fe1dcaa5c446f4bb40928018f96fc05b897071f4")
