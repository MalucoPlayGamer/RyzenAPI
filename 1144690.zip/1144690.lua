-- Lua provided by RyzenAPI
-- Game: 1144690

-- MAIN APPLICATION
addappid(1144690)
-- Game: addappid(1144690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144691, 1, "c19c9bf59cbaef25dcae70deeea4719d32c9d6876271b4c2c7960e47c6170c10")
