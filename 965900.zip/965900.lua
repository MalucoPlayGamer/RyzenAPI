-- Lua provided by RyzenAPI
-- Game: addappid(965900)

-- MAIN APPLICATION
addappid(965900)

-- MAIN APP DEPOTS / PACKAGES
addappid(965901, 1, "2795f5054f6e3c5561dbc950115b39654246c4c61055cdff6c3ac1ac2da616c2")
