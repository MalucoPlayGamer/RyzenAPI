-- Lua provided by RyzenAPI
-- Game: The Incredible Adventures of Van Helsing

-- MAIN APPLICATION
addappid(215530)
addappid(228984)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(215531, 1, "dd9d30db7dbe8932cc1459e72357e927b19c7c7b49fd51555ab56361c3e0498c")
addappid(215538, 1, "d0685c093ad459e2a05517559c95208eb073cf8d4ab0d59617397619e58088f5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(215532)
addappid(215533)
addappid(215534)
addappid(215535)
addappid(215536)
addappid(215537)
