-- Lua provided by RyzenAPI
-- Game: addappid(38220)

-- MAIN APPLICATION
addappid(38220)

-- MAIN APP DEPOTS / PACKAGES
addappid(38221, 1, "946fa308bb3ff58dcfa53ce06b69b89c6b8117fe8118ece663b9acdbca83256f")
addappid(38222, 1, "0ff4194ad77a2a59510a4f1934694b02e191bf7a1284f596353ca8ca26fcd856")
addappid(38223, 1, "8c43073d65261fea9dec37ff61185329860054697cfa8a044546e17bbea0fdee")
