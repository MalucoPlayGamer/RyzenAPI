-- Lua provided by RyzenAPI 
-- Game: Hardspace: Shipbreaker - Original Soundtrack
addappid(1474600)
addappid(1474601, 1, "e92d4ace4642f0f983ef0f6de4e57c08d7a7248dbb6f6733e2db8bd73ca7b56b")
addappid(1474602, 1, "c04c9652ac9cdc4bfc8c5ab8d86734f221316516379f7619fe07849a420155c6")
