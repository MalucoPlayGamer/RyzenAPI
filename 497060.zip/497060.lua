-- Lua provided by RyzenAPI
-- Game: 497060

-- MAIN APPLICATION
addappid(497060)
-- Game: addappid(497060)

-- MAIN APP DEPOTS / PACKAGES
addappid(497061, 1, "6e273ad3e01acbf05e75950e7e13c48cf9bf2c19154dc90a5d9e0d232c8e404a")
