-- Lua provided by RyzenAPI
-- Game: Rise

-- MAIN APPLICATION
addappid(497060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(497061, 1, "6e273ad3e01acbf05e75950e7e13c48cf9bf2c19154dc90a5d9e0d232c8e404a")
