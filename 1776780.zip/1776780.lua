-- Lua provided by RyzenAPI
-- Game: The Sims™ 4 Wilkołaki Pakiet rozgrywki

-- MAIN APPLICATION
addappid(1776780)
addappid(2009980)
addappid(2009982)
addappid(2009983)
addappid(2009984)
addappid(2009985)
addappid(2009986)
addappid(2009987)
-- Game: addappid(1776780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776781, 1, "af14d1368191f66458cee36dd613f5bacce0f83e138cfeda0833dd219eb5621d")
addappid(1776782, 1, "ab76fb18e704719a7a016d6d56af2f66f25280ca8d2d628bdcb72f6fbfa3ce8e")
addappid(1776783, 1, "285c10016631a147917528b0fd27f0b6b49101615a5fd93167eb0623d953117e")
addappid(1776786, 1, "2e4b478c603c7241afe0473572582253464a6c06ec2cd71807919b06197b3a2f")
addappid(1776787, 1, "e32cc1612e4a44aadd7cee3a0c69507079158fea474fb6cefedac44d3f1d60d9")
addappid(1776788, 1, "289d849006fa543cfc2c325af9a7e4fdd21f8b730945e431d90069e332cd7880")
addappid(2009981, 0, "5ded80576ddab62f4b9517f7330ef5719575dd2a12320d9ebe39e3aee1fa1626")
addappid(2009988, 0, "aa14c1267fab491768e0aeee17ea86a3ad52d1e6cc04051f80c90adc40cb3b31")
