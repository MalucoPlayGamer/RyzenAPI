-- Lua provided by RyzenAPI
-- Game: addappid(1931750)

-- MAIN APPLICATION
addappid(1931750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931751, 1, "84537cbb90d6ba2cf9591160914769a5fa7a59f3c6f68c35676830bc30ef9fdc")
