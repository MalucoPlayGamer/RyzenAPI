-- Lua provided by RyzenAPI
-- Game: Game: Descent 2

-- MAIN APPLICATION
addappid(273580)
-- Game: addappid(273580)

-- MAIN APP DEPOTS / PACKAGES
addappid(273581, 1, "11c6817e68ec54e3d915afe77e594ca2beef681b187dd81be266edb7219d8c66")
