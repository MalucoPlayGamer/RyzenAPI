-- Lua provided by RyzenAPI
-- Game: Nav Demo

-- MAIN APPLICATION
addappid(2951930)
-- Game: addappid(2951930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951931, 1, "c4a44f2304e33c452b416c7f5850bef967627b2ae224a79b99f4aadcaef0000e")
