-- Lua provided by SkyAPI 
-- Game: Nav Demo
addappid(2951930)
addappid(2951931, 1, "c4a44f2304e33c452b416c7f5850bef967627b2ae224a79b99f4aadcaef0000e")
