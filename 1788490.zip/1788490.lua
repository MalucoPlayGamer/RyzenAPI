-- Lua provided by RyzenAPI
-- Game: Adult Puzzles - Hentai NightClub

-- MAIN APPLICATION
addappid(1788490)
-- Game: addappid(1788490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788491, 1, "18e992ff5d052514f475bb0c3947023eb777a8b471f4c786fb9c046868466b04")
addappid(1788580, 0, "2083db8a5ac15f8326b6d915effb1aeeeb1fefd2fe98884c93fcf7a194631f07")
