-- Lua provided by RyzenAPI
-- Game: Unwanted Dungeon

-- MAIN APPLICATION
addappid(3733160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3733161,0,"899422d105b5ba039e09c0d56b6e4495fafc6f69a63dbea89490807c5b96afb9")

