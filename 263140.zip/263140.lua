-- Lua provided by RyzenAPI
-- Game: 263140

-- MAIN APPLICATION
addappid(263140)
-- Game: addappid(263140)

-- MAIN APP DEPOTS / PACKAGES
addappid(263141, 1, "12e9fdc996791f0a33b9684e2716da97c36659b5c34c1b5e68cfef6f5ca861ba")
addappid(263142, 1, "a336c897c9d44ae2c407711167ed500610de4e3fb694c0fd959a9ffb7c3c343a")
