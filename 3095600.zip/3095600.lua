-- Lua provided by RyzenAPI
-- Game: Miracle Heroes: Temporal Bounty Hunter

-- MAIN APPLICATION
addappid(3095600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095601, 1, "7937a0a9ef34fe696d733d7b9f42e83c75418939f78efb50cddb4f5fe5ef51d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
