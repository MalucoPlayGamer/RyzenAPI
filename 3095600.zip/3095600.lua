-- Lua provided by SkyAPI 
-- Game: Miracle Heroes: Temporal Bounty Hunter
addappid(3095600)
addappid(3095601, 1, "7937a0a9ef34fe696d733d7b9f42e83c75418939f78efb50cddb4f5fe5ef51d5")
