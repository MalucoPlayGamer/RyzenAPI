-- Lua provided by RyzenAPI
-- Game: Miracle Heroes: Temporal Bounty Hunter

-- MAIN APPLICATION
addappid(3095600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095601, 1, "7937a0a9ef34fe696d733d7b9f42e83c75418939f78efb50cddb4f5fe5ef51d5")

