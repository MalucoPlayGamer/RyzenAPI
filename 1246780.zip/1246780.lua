-- Lua provided by RyzenAPI
-- Game: Game: AppID 1246780

-- MAIN APPLICATION
addappid(1246780)
-- Game: addappid(1246780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246781, 1, "1267921282f21b9b8683acf212ace4457e230e12a04600ba88ab492fa76608b0")
