-- Lua provided by RyzenAPI 
-- Game: Straima
addappid(399140)
addappid(399141, 1, "73b8e60a55e7d728dd4836ed2d5ba4874f647dd657b79da4eb77a33bad459111")
