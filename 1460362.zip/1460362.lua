-- Lua provided by RyzenAPI
-- Game: FUSER™ - Chumbawamba - "Tubthumping"

-- MAIN APPLICATION
addappid(1460362)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460362,0,"ed2a29aa10c985e5040fa04a0b2bd381ef615c1762b636b343163c7387d04c0f")
