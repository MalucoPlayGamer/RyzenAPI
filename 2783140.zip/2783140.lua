-- Lua provided by RyzenAPI
-- Game: Game: Parcel Corps Demo

-- MAIN APPLICATION
addappid(2783140)
-- Game: addappid(2783140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783141, 1, "2cde5761c093f2a666b890a491a36d2e0d86bc3cffe60bc7a1c6eb2d8c4dff25")
