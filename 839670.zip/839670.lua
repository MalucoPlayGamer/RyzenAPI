-- Lua provided by RyzenAPI
-- Game: Alice's Adventures - Hidden Object Puzzle Game

-- MAIN APPLICATION
addappid(839670)
-- Game: addappid(839670)

-- MAIN APP DEPOTS / PACKAGES
addappid(839671, 1, "df624f54abeb5826734312c75725b1248bfbccfb81e5696355815e333095d921")
