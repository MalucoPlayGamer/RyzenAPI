-- Lua provided by RyzenAPI
-- Game: Slime Rule

-- MAIN APPLICATION
addappid(2069550)
-- Game: addappid(2069550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069551, 1, "3eddbc921f47afb606a2c7f5aed2d7fe887d7d4962ccf0ebcabdbb306de59403")
