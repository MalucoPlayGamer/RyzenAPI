-- Lua provided by SkyAPI 
-- Game: AppID 3695140
addappid(3695140)
addappid(3695141, 1, "f1d39289a2a22a7b838ee827843c5cb3948e1eee384575b07b7e84358e13ffe3")
