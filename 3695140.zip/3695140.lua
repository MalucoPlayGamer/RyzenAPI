-- Lua provided by RyzenAPI
-- Game: addappid(3695140)

-- MAIN APPLICATION
addappid(3695140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3695141, 1, "f1d39289a2a22a7b838ee827843c5cb3948e1eee384575b07b7e84358e13ffe3")
