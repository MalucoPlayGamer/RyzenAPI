-- Lua provided by RyzenAPI
-- Game: Dead Unending Demo

-- MAIN APPLICATION
addappid(2258820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258821, 1, "a38cc10c2975f25455ed6c3b5b2605e6c94377480d05027bfb5463614abf7143")
