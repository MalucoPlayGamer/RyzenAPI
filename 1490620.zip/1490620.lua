-- Lua provided by RyzenAPI
-- Game: Game: Pray And Spray

-- MAIN APPLICATION
addappid(1490620)
-- Game: addappid(1490620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490621, 1, "c08ee748d4a30bf784180962975d560727369fc078f863823efb63a435001316")
