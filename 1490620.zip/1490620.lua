-- Lua provided by SkyAPI 
-- Game: Pray And Spray
addappid(1490620)
addappid(1490621, 1, "c08ee748d4a30bf784180962975d560727369fc078f863823efb63a435001316")
