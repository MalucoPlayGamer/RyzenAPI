-- Lua provided by RyzenAPI
-- Game: Game: Rise of the samurai in VR

-- MAIN APPLICATION
addappid(1473500)
-- Game: addappid(1473500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473501, 1, "5267babbb030a8c1dd9f62256ebd1a501e835b1e60bee94afaee93912e628ab7")
