-- Lua provided by RyzenAPI
-- Game: addappid(2839090)

-- MAIN APPLICATION
addappid(2839090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839091, 1, "aacf417b8a78074a1f5465d1e8ef4f1a27afde842ce1b83ff9ee58cad21dbe00")
