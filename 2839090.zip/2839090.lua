-- Lua provided by RyzenAPI
-- Game: Unlock the Three

-- MAIN APPLICATION
addappid(2839090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839091, 1, "aacf417b8a78074a1f5465d1e8ef4f1a27afde842ce1b83ff9ee58cad21dbe00")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
