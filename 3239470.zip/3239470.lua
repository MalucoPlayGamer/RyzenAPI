-- Lua provided by RyzenAPI
-- Game: 异梦残响 | Endless Dream Demo

-- MAIN APPLICATION
addappid(3239470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239471, 1, "d0889d648191508f47a4c4c1f144991d594ccbc109de3e7d5bf763af149eb4fe")

