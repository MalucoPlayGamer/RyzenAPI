-- Lua provided by RyzenAPI
-- Game: Ashen Arrows

-- MAIN APPLICATION
addappid(1947240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947241, 1, "cfce64a767a89c4934e79cd8aae97ecb566b06d5ab3f4482277d3ae24ac8c55a")

