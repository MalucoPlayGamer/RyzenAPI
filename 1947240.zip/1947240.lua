-- Lua provided by RyzenAPI
-- Game: Ashen Arrows

-- MAIN APPLICATION
addappid(1947240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1947241, 1, "cfce64a767a89c4934e79cd8aae97ecb566b06d5ab3f4482277d3ae24ac8c55a")

