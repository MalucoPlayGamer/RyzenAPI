-- Lua provided by RyzenAPI
-- Game: Bomber Dudes

-- MAIN APPLICATION
addappid(1362830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362831, 1, "76dfc4a2b4abfdaa5300f299a3e54f8dc596d5cfbfa446d779b1ee028583c5ea")

