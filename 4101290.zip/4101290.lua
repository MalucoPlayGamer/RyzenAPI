-- Lua provided by RyzenAPI
-- Game: Overtrick

-- MAIN APP DEPOTS / PACKAGES
addappid(4101290, 1, "3c932967e48248a144f84711407b5f6669859a8cc3ac22a8ea9e5d5c37ec9623") -- Overtrick
addappid(4101291, 1, "02339f2446c447b91bfa86c3125f3f4965dc07c438c42bb91119edf11675ee64") -- Depot 4101291

