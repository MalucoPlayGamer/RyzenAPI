-- 4101290's Lua and Manifest Created by Hubcap Manifest
-- Overtrick
-- Created: August 25, 2026 at 11:39:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4101290, 1, "3c932967e48248a144f84711407b5f6669859a8cc3ac22a8ea9e5d5c37ec9623") -- Overtrick
-- MAIN APP DEPOTS
addappid(4101291, 1, "02339f2446c447b91bfa86c3125f3f4965dc07c438c42bb91119edf11675ee64") -- Depot 4101291
setManifestid(4101291, "5674636624767563070", 485095671)