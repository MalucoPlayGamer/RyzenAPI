-- Lua provided by RyzenAPI
-- Game: Parking World: Build & Manage

-- MAIN APPLICATION
addappid(2551570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551571, 1, "7f8cc23534f4143d80aea505f42bb83dcb942de1b8d0e07b629ce3b9dfa2e6a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
