-- Lua provided by RyzenAPI
-- Game: Game: Parking World: Build & Manage

-- MAIN APPLICATION
addappid(2551570)
-- Game: addappid(2551570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551571, 1, "7f8cc23534f4143d80aea505f42bb83dcb942de1b8d0e07b629ce3b9dfa2e6a2")
