-- Lua provided by RyzenAPI
-- Game: BM Estate Intermediary

-- MAIN APPLICATION
addappid(2981440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981441, 1, "f6828d0aeab20c41ad79971177c3b69ad8dcd401124b0694eb23189d366d101d")

