-- Lua provided by RyzenAPI
-- Game: 669980

-- MAIN APPLICATION
addappid(669980)
-- Game: addappid(669980)

-- MAIN APP DEPOTS / PACKAGES
addappid(669981, 1, "5ef21290e3021aacc859ce521709bc57af37154441c8d82055a4b8568fa839d0")
