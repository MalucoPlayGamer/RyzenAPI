-- Lua provided by RyzenAPI
-- Game: Blasted Fortress

-- MAIN APPLICATION
addappid(339500)
addappid(375800)
-- Game: addappid(339500)

-- MAIN APP DEPOTS / PACKAGES
addappid(339501, 1, "acb455b55527ea31218b85b608bc31a13f735a4d8618bf35ae95e7058b045dc6")
