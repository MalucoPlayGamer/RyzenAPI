-- Lua provided by RyzenAPI
-- Game: Game: Young Souls

-- MAIN APPLICATION
addappid(985900)
-- Game: addappid(985900)

-- MAIN APP DEPOTS / PACKAGES
addappid(985901, 1, "9466ea40807d12680b58646af842743785df166b07b8b971285a3abf02254200")
