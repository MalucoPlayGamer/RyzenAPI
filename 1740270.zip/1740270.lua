-- Lua provided by RyzenAPI
-- Game: 1740270

-- MAIN APPLICATION
addappid(1740270)
-- Game: addappid(1740270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740271, 1, "08eab558ac70d216c6af82a228ae7d996fd420fdcf0e8068cc4f1b6d1e3c4457")
