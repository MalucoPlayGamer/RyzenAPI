-- Lua provided by RyzenAPI
-- Game: Game: Ittle Dew

-- MAIN APPLICATION
addappid(241320)
-- Game: addappid(241320)

-- MAIN APP DEPOTS / PACKAGES
addappid(241321, 1, "da642b6d5dfd89e55f668a09298f3cd8a6cc987dd083390a0a1a26fd0f95e664")
addappid(241322, 1, "a823ebdfb2a35b1f0da00e7091443a5e68f9e508d92a2b25e3573ac336ad4d1f")
addappid(241323, 1, "55050db6992d8518846ad1c0162023c237b76453b4be36f7df1c935d32ba0b65")
