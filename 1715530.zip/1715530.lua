-- Lua provided by RyzenAPI
-- Game: Medieval Wars

-- MAIN APPLICATION
addappid(1715530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715531, 1, "090ac0933aa52866dfcfbcc47c0b0ed6d70a055db97825f8a96c47df21f23ae5")
