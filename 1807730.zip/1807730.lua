-- Lua provided by RyzenAPI
-- Game: Game: Lab Bio-Terror

-- MAIN APPLICATION
addappid(1807730)
-- Game: addappid(1807730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807731, 1, "e905f069aa9a7e950aab72815971d77e07eb393804a4dce4ec142cd941d8deb2")
