-- Lua provided by RyzenAPI
-- Game: 702030

-- MAIN APPLICATION
addappid(702030)
-- Game: addappid(702030)

-- MAIN APP DEPOTS / PACKAGES
addappid(702031, 1, "5475ff122ea6dc05102e35d0510afb26facf5dbc647fe6dea5fc926f84738c3f")
