-- Lua provided by RyzenAPI
-- Game: Game: OnlyFap Simulator 3 💦

-- MAIN APPLICATION
addappid(2179630)
-- Game: addappid(2179630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179631, 1, "aba04c3c88a1794e1fe00731fceb91b8200da2b7636f84238f0064fe55c09ce3")
