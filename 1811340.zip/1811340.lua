-- Lua provided by RyzenAPI
-- Game: Spray Paint Simulator

-- MAIN APPLICATION
addappid(1811340)
addappid(3053730)
-- Game: addappid(1811340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811341, 1, "7b55c2b537b574df16fc24077a09521709c1f8bc8763eeb8eb8583485ef4a2ac")
