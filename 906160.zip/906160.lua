-- Lua provided by RyzenAPI
-- Game: addappid(906160)

-- MAIN APPLICATION
addappid(906160)
addappid(908760)

-- MAIN APP DEPOTS / PACKAGES
addappid(906161, 1, "e5ce7de5a7f7fac63363185c2cd408b4fc3761f704df563dbf2cbf3eeef3ab02")
