-- Lua provided by RyzenAPI
-- Game: Game: The Chef's Shift Demo

-- MAIN APPLICATION
addappid(2432200)
-- Game: addappid(2432200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432201, 1, "8acaa069ceaab0fa137d3086e5a627d1db0e65683e91911ce23d1c0cdab0625d")
