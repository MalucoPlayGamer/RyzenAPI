-- Lua provided by RyzenAPI
-- Game: Otaku's Fantasy 2

-- MAIN APPLICATION
addappid(788130)

-- MAIN APP DEPOTS / PACKAGES
addappid(788131, 1, "b646afd9f4b781478410fa80bac57640b5962389f41bfde145263e297ce5b0fc")
