-- Lua provided by RyzenAPI
-- Game: Pandemic: The Board Game

-- MAIN APPLICATION
addappid(622440)
addappid(622850)
addappid(622851)
addappid(1224970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(622441, 1, "af6b423bd86ef1d54aa5887ef11ad8dad09c46bf15b0a20cbd39ef6bea7ec95a")

