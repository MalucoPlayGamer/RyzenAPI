-- Lua provided by RyzenAPI
-- Game: AppID 622440

-- MAIN APPLICATION
addappid(622440)
-- Game: addappid(622440)

-- MAIN APP DEPOTS / PACKAGES
addappid(622441, 1, "af6b423bd86ef1d54aa5887ef11ad8dad09c46bf15b0a20cbd39ef6bea7ec95a")
