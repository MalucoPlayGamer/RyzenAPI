-- Lua provided by RyzenAPI
-- Game: Sifu

-- MAIN APPLICATION
addappid(2138710)
addappid(2231950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138711, 1, "640993870daafc721632280e9e612a93f957d22bd8a16dcc526c3b8f73be0e33")
addappid(2253841, 0, "27dc031b34fbcd34f1a8d7fd5658680f030c63aa34e8cfeb1a6c982888552d7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
