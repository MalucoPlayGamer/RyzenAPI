-- Lua provided by RyzenAPI
-- Game: 2383860

-- MAIN APPLICATION
addappid(2383860)
-- Game: addappid(2383860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383861, 1, "301d77547524e561d525f814becce947e3cd0978cff7641c3ff32a0e16eb66fe")
