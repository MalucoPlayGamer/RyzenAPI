-- Lua provided by RyzenAPI 
-- Game: AppID 790930
addappid(790930)
addappid(790931, 1, "751884fdf38a739db7770184f48b9356bfc5d661b631056061dc3e5eb048a655")
