-- Lua provided by RyzenAPI
-- Game: Primitive Shooter

-- MAIN APPLICATION
addappid(790930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(790931, 1, "751884fdf38a739db7770184f48b9356bfc5d661b631056061dc3e5eb048a655")
