-- Lua provided by RyzenAPI
-- Game: 790930

-- MAIN APPLICATION
addappid(790930)
-- Game: addappid(790930)

-- MAIN APP DEPOTS / PACKAGES
addappid(790931, 1, "751884fdf38a739db7770184f48b9356bfc5d661b631056061dc3e5eb048a655")
