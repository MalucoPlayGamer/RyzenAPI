-- Lua provided by RyzenAPI
-- Game: 1222140

-- MAIN APPLICATION
addappid(1222140)
-- Game: addappid(1222140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222141, 1, "d87af32872df297ec519d0e79b6e0afc327b09048c3414622606b54efc46f519")
