-- Lua provided by RyzenAPI
-- Game: Cyberpunk SFX

-- MAIN APPLICATION
addappid(1465260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465261, 1, "84237b89e2269c4dcc9a038e9dd84fa5d44c90a957e0539c162eb7096174ae1d")

