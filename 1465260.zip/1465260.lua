-- Lua provided by RyzenAPI
-- Game: Cyberpunk SFX

-- MAIN APPLICATION
addappid(1465260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465261, 1, "84237b89e2269c4dcc9a038e9dd84fa5d44c90a957e0539c162eb7096174ae1d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
