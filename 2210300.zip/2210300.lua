-- Lua provided by RyzenAPI
-- Game: 2210300

-- MAIN APPLICATION
addappid(2210300)
-- Game: addappid(2210300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210301, 1, "b998abceae2d0c1d6a887fd89e17acb41a2135ec80a48147ce548c7a39b41e2a")
