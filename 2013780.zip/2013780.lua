-- Lua provided by RyzenAPI 
-- Game: Drain Runner
addappid(2013780)
addappid(2013781, 1, "845454cdc6348e46ccdffd11bdb77d71b3fd066ae8ce261e52a1955121e9ce1c")
