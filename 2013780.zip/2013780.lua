-- Lua provided by RyzenAPI
-- Game: Game: Drain Runner

-- MAIN APPLICATION
addappid(2013780)
-- Game: addappid(2013780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013781, 1, "845454cdc6348e46ccdffd11bdb77d71b3fd066ae8ce261e52a1955121e9ce1c")
