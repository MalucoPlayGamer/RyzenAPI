-- Lua provided by RyzenAPI
-- Game: AppID 562600

-- MAIN APPLICATION
addappid(562600)

-- MAIN APP DEPOTS / PACKAGES
addappid(562601, 1, "6d1d03e9c9e28b5ff1279c1944f16d318a92fec222c58d536e0230f7e5085d08")
addappid(562602, 1, "5e568c4efa1cfb124deb8ab1f64b615ebb5b20cb0388b6afc63dd71c1c64e736")

