-- Lua provided by RyzenAPI
-- Game: addappid(3163450)

-- MAIN APPLICATION
addappid(3163450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163451, 1, "35aa2f50126bb053300dca97a62c30cdf9fb73a15581006531c57dc429a0af36")
