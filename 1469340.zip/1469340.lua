-- Lua provided by RyzenAPI
-- Game: GyroBlade

-- MAIN APPLICATION
addappid(1469340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469341, 1, "09e2695279f3a832b6adc340dea008ec586a8c3c7b5a901eaeee8f5543671649")

