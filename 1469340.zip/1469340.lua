-- Lua provided by SkyAPI 
-- Game: AppID 1469340
addappid(1469340)
addappid(1469341, 1, "09e2695279f3a832b6adc340dea008ec586a8c3c7b5a901eaeee8f5543671649")
