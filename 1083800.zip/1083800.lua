-- Lua provided by RyzenAPI
-- Game: Glitch Arena

-- MAIN APPLICATION
addappid(1083800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1083801, 1, "b6b9eae2a06157e3c6ee01dab677da87e723108af8c5b9128f045e28d3f5b64b")
