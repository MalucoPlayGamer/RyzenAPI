-- Lua provided by RyzenAPI
-- Game: 1338330

-- MAIN APPLICATION
addappid(1338330)
-- Game: addappid(1338330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338331, 1, "34c087cbf49f58d43d5d7417c942cffab38e7a0862ad59fb717f48d2f9110e90")
