-- Lua provided by RyzenAPI 
-- Game: Lemon Cake
addappid(1338330)
addappid(1338331, 1, "34c087cbf49f58d43d5d7417c942cffab38e7a0862ad59fb717f48d2f9110e90")
