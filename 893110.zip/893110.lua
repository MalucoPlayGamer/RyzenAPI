-- Lua provided by RyzenAPI
-- Game: 893110

-- MAIN APPLICATION
addappid(893110)
-- Game: addappid(893110)

-- MAIN APP DEPOTS / PACKAGES
addappid(893111, 1, "7c05421b10b0a31dc80b6ccb5e1a40b864607360156a2d2bdf9c34a720b509ce")
