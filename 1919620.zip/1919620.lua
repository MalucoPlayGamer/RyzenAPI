-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Omnia (LOFI Remix) Soundtrack

-- MAIN APPLICATION
addappid(1919620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919621, 1, "b02c889595b104ad0f2a8b675c8689b6356f7b2a0dc3f869cfaaa8b5b762caea")
addappid(1919622, 1, "c3cf4cdb1c5bc2a82fa0ab16d8a713a541a52330e848505647392a4cd029a96a")

