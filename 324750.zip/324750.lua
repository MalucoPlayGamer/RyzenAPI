-- Lua provided by RyzenAPI
-- Game: addappid(324750)

-- MAIN APPLICATION
addappid(324750)

-- MAIN APP DEPOTS / PACKAGES
addappid(324752,0,"dbcd171f7920405d7efb1f393eb06ffe2a48182dcb4435c0a3fc5259712026b0")
addappid(324753,0,"5993fc4e34e79eca42bc4f57e223d2adee4a747636f9fdc9996e04adc4cd3c54")
