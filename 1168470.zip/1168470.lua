-- Lua provided by RyzenAPI
-- Game: 1168470

-- MAIN APPLICATION
addappid(1168470)
-- Game: addappid(1168470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168471, 1, "0d2f35526701fc1eb6b613fca8d995d8ab5fa63a30d638bfaac7c3082a182b24")
addappid(1168472, 1, "1dd812b2036d2d16eb6f9c4c134c3b76c245dfc2c5271a86e04665cdbe37d1bd")
