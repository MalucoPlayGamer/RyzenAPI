-- Lua provided by RyzenAPI
-- Game: addappid(881520)

-- MAIN APPLICATION
addappid(228985)
addappid(881520)
addappid(881521)
addappid(881523)
addappid(881524)

-- MAIN APP DEPOTS / PACKAGES
addappid(881522,0,"a8eb82668292615dfe21c947905eb817a338d777d229852e772e05d7c3342a2d")
