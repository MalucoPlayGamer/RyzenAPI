-- Lua provided by RyzenAPI
-- Game: Game: AppID 330660

-- MAIN APPLICATION
addappid(330660)
-- Game: addappid(330660)

-- MAIN APP DEPOTS / PACKAGES
addappid(330661, 1, "129cae372f3315dacba5c8f1957bd535d592bfbff271e34b625836ba6d7d7dc0")
addappid(330662, 1, "8e9a6c54141963096253ea3687ded00ff7f53261d52b6f1cd511b7635a12d229")
addappid(337570, 0, "f49a04f5ba007eadda03a068515f67c95e1587ea365ae15cf4ccf8c9a70773d6")
