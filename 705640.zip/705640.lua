-- Lua provided by RyzenAPI
-- Game: BACK TO THE EGG! Tower Defense

-- MAIN APPLICATION
addappid(705640)

-- MAIN APP DEPOTS / PACKAGES
addappid(705641, 1, "e1238fed99d3c73bcbf0f4e06b8351b45b400ad8a60464a16091a1813283d1d9")

