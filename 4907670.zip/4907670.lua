-- Lua provided by RyzenAPI
-- Game: 霸业封神传奇

-- MAIN APPLICATION
addappid(4907670)

