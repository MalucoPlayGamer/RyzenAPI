-- Lua provided by RyzenAPI
-- Game: Dexodonex

-- MAIN APPLICATION
addappid(552780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(552781, 1, "2240e608b1651f6c2389d13ba8a41e1e8e5cdfa8071b72c5ae8ee3e174d02623")

