-- Lua provided by RyzenAPI
-- Game: Game: AppID 552780

-- MAIN APPLICATION
addappid(552780)
-- Game: addappid(552780)

-- MAIN APP DEPOTS / PACKAGES
addappid(552781, 1, "2240e608b1651f6c2389d13ba8a41e1e8e5cdfa8071b72c5ae8ee3e174d02623")
