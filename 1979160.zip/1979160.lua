-- Lua provided by RyzenAPI
-- Game: GoRogue

-- MAIN APPLICATION
addappid(1979160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979162,0,"b961dd3465a714e73aac82ac638a43eb7669c0235e56b15df98e18acff204e90")
addappid(1979163,0,"913ab31bf7611dd85227582c308c85b0c0dcaea0a854e307e0fb056da410b3c4")
addappid(1979164,0,"fa44cad98b1afcefc6cf5d4b455697668f2e221079de7549ae3b1cc30b8b7b11")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
