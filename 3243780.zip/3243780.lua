-- Lua provided by RyzenAPI
-- Game: Game: Abode: Definitive Edition

-- MAIN APPLICATION
addappid(3243780)
-- Game: addappid(3243780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243781, 1, "3bb8e2211f2c722a6ba245c106feddec1097f3d6308ef1b545f9fcb1a47ddce2")
