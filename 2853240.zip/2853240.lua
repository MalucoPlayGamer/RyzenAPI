-- Lua provided by RyzenAPI
-- Game: Song of Yosef

-- MAIN APPLICATION
addappid(2853240)
-- Game: addappid(2853240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853241, 1, "690875d2ec8ba5f1852a5f06da0a3d5222eeade1bb6fead30f25019e29b6b423")
