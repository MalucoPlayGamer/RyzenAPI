-- Lua provided by RyzenAPI
-- Game: Scribblenauts Unmasked: A DC Comics Adventure

-- MAIN APPLICATION
addappid(249870)

-- MAIN APP DEPOTS / PACKAGES
addappid(249871, 1, "3d88d7ccdf77d55b7d14b32499acea66a91edbadac96101e48c61327b98fef64")
addappid(256490, 0, "adfbfee5b5b61894ac75840ddbf4c06b03433093e56568ffd65c2b5ed3771197")

