-- Lua provided by RyzenAPI
-- Game: Game: Fishy 3D

-- MAIN APPLICATION
addappid(1446000)
-- Game: addappid(1446000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446001, 1, "44869a85b0e3ec13467a97b0d0ce9eb700b59a3cfae93aea8ec3e39ae85f3fe7")
