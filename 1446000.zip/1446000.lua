-- Lua provided by RyzenAPI
-- Game: Fishy 3D

-- MAIN APPLICATION
addappid(1446000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446001, 1, "44869a85b0e3ec13467a97b0d0ce9eb700b59a3cfae93aea8ec3e39ae85f3fe7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
