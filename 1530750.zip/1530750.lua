-- Lua provided by RyzenAPI
-- Game: 1530750

-- MAIN APPLICATION
addappid(1530750)
-- Game: addappid(1530750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530751, 1, "ac2be9130379ebe103f94c96ef11bd267df681fdee0e73f2079bcbd53ee331a5")
