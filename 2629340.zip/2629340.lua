-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Bar: Gachi Puzzles

-- MAIN APPLICATION
addappid(2629340)
-- Game: addappid(2629340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629341, 1, "5683d2847cb46daa57a8b788f354efd048c58ffed3317142cb9bbcfc4f505cb5")
