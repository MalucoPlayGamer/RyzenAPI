-- Lua provided by RyzenAPI
-- Game: GabeN: The Final Decision

-- MAIN APPLICATION
addappid(403740)
-- Game: addappid(403740)

-- MAIN APP DEPOTS / PACKAGES
addappid(403741, 1, "6a91687fb7ca234358cb8f1950f5d341c19810068162866a1223bf43b0f43005")
