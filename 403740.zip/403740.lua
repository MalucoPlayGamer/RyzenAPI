-- Lua provided by RyzenAPI
-- Game: GabeN: The Final Decision

-- MAIN APPLICATION
addappid(403740)

-- MAIN APP DEPOTS / PACKAGES
addappid(403741, 1, "6a91687fb7ca234358cb8f1950f5d341c19810068162866a1223bf43b0f43005")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
