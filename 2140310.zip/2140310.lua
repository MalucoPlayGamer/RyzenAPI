-- Lua provided by RyzenAPI
-- Game: Wish Me Well

-- MAIN APPLICATION
addappid(2140310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140311,0,"de6ce5f8d949f559ad164f1be3e9cb9f6fea4269c5c0c5305e406edfef7f2798")

