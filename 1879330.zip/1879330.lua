-- Lua provided by RyzenAPI
-- Game: Game: WARRIORS OROCHI 3 Ultimate Definitive Edition

-- MAIN APPLICATION
addappid(1879330)
-- Game: addappid(1879330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879331, 1, "22b5adb092b925360661b865cfb859a11116c8a3f041d4a8aa0b5db7b79fc36b")
addappid(1879332, 1, "0f4da0326fa3e0ef870af18b5bae9fc19f6f5ef7442e05f7137b6f1d0bdf2f7d")
addappid(1879333, 1, "a02ae77c03851be8c4441c52b0ab8503b418f832d0035ab6a13ec4ca83ce27b7")
addappid(1879334, 1, "04a5aab7be5b8c0cd6be58dc98053000a93293e80d52ffb5d41841173af05f7d")
