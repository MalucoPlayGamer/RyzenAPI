-- Lua provided by RyzenAPI
-- Game: 491410

-- MAIN APPLICATION
addappid(491410)
-- Game: addappid(491410)

-- MAIN APP DEPOTS / PACKAGES
addappid(491410,0,"8d8580bff83f1d01ace52920f27a9a2a62dc29f0f4db0a31d530c3aaf3ec755c")
