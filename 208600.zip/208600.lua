-- Lua provided by RyzenAPI 
-- Game: Lunar Flight
addappid(208600)
addappid(208601, 1, "19c0c0365ef10b18e4e9715f6a7372b8263516cb58265ef46620dbf9d18a95b3")
addappid(208602, 1, "fd04dfb88141f5b196a443a7a0f0eba6af997469a48f889b530c8b86f6a90005")
