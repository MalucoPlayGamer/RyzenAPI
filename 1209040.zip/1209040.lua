-- Lua provided by RyzenAPI
-- Game: Game: Cyber Hunter

-- MAIN APPLICATION
addappid(1209040)
-- Game: addappid(1209040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209041, 1, "0f87fe60c9bd5b83eae11fc4af43cd5f2824b28bc80952d3b2cac260540e42b1")
