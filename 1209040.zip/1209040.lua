-- Lua provided by RyzenAPI
-- Game: Cyber Hunter

-- MAIN APPLICATION
addappid(1209040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209041, 1, "0f87fe60c9bd5b83eae11fc4af43cd5f2824b28bc80952d3b2cac260540e42b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
