-- Lua provided by RyzenAPI 
-- Game: Muv-Luv photonflowers*
addappid(889700)
addappid(889701, 1, "6c94ba047fa3a74fe7184584b2e6a51146eff59a6e59f9705a097a27c1f96886")
addappid(1158540, 0, "3d0f0961d7f51a6bfc36d9000d1e7d3867528e1086b09bbe443179508c3a7b9c")
