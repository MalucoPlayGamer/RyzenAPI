-- Lua provided by RyzenAPI
-- Game: Muv-Luv photonflowers*

-- MAIN APPLICATION
addappid(889700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(889701, 1, "6c94ba047fa3a74fe7184584b2e6a51146eff59a6e59f9705a097a27c1f96886")
addappid(1158540, 0, "3d0f0961d7f51a6bfc36d9000d1e7d3867528e1086b09bbe443179508c3a7b9c")

