-- Lua provided by RyzenAPI
-- Game: addappid(2323190)

-- MAIN APPLICATION
addappid(2323190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323191, 1, "9d52a223a067f1b7922023992ed8eb3a210210d806a80cbdc38cbfd1371da704")
