-- Lua provided by SkyAPI 
-- Game: THE SEGMENT TWINS Demo
addappid(2323190)
addappid(2323191, 1, "9d52a223a067f1b7922023992ed8eb3a210210d806a80cbdc38cbfd1371da704")
