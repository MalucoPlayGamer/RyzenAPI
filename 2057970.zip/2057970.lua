-- Lua provided by RyzenAPI 
-- Game: Rainy Butcher
addappid(2057970)
addappid(2057971, 1, "34499c402c2c85408bb001f0e4d98ffc222216a04f099eba5be84839bc9a2604")
