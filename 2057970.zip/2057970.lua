-- Lua provided by RyzenAPI
-- Game: addappid(2057970)

-- MAIN APPLICATION
addappid(2057970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057971, 1, "34499c402c2c85408bb001f0e4d98ffc222216a04f099eba5be84839bc9a2604")
