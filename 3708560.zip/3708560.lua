-- Lua provided by RyzenAPI
-- Game: Brainfuck Challenge

-- MAIN APPLICATION
addappid(3708560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3708561, 1, "bd5c0a4a9beea4e1bad8b303cab3dd354dfb2a31cf5e616ebe6cb3a7708e91e2")
