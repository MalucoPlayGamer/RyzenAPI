-- Lua provided by RyzenAPI
-- Game: Game: DETECTIVE - Rainy night

-- MAIN APPLICATION
addappid(3389720)
-- Game: addappid(3389720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389721, 1, "12cfc517afe7a76d3629fcf6438e97ef20f676b5f565678d6fc20dd847d5bb53")
