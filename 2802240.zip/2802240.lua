-- Lua provided by RyzenAPI
-- Game: Red end

-- MAIN APPLICATION
addappid(2802240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802241, 1, "744de515c95a3c15d69b02b3ae4133e64ae8e6496cd444f435679e9648db099d")

