-- Lua provided by RyzenAPI
-- Game: addappid(940310)

-- MAIN APPLICATION
addappid(940310)

-- MAIN APP DEPOTS / PACKAGES
addappid(940311, 1, "1891e441209e1dc968dd7c1e63b6c1b3fcab21562a475b7e58ba1bf20fe4f5a7")
