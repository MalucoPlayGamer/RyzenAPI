-- Lua provided by RyzenAPI
-- Game: Generic Space Shooter

-- MAIN APPLICATION
addappid(366010)

-- MAIN APP DEPOTS / PACKAGES
addappid(366011, 1, "e0a8e21c0bff00f1688ea12d38e402188695c6bbffc2bade05eddb10da2f6aca")
addappid(366012, 1, "7e47fc4587ea3d912eea95def0f6bf975be9cba4da74d1d3e4f5ae520470c92f")

