-- Lua provided by RyzenAPI
-- Game: Friendship Club

-- MAIN APPLICATION
addappid(332760)

-- MAIN APP DEPOTS / PACKAGES
addappid(332761, 1, "3de3a372937c0748884f8e386fa09c97a266b1fba7409d922381798b2d31adc3")

