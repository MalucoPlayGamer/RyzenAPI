-- Lua provided by RyzenAPI
-- Game: Game: I'm on Observation Duty 3

-- MAIN APPLICATION
addappid(1458560)
-- Game: addappid(1458560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458561, 1, "66ed816de6e8e4e6a935743efc8d034882889e3a3f57503b18a45503817d9a01")
addappid(1458562, 1, "c659209d7e5195034bc1e43e3ba1523feb0cf252fd1f7022149e5b2245c1f670")
addappid(1458563, 1, "36c3e5ec096fa476ccbbc06c015ab74a1610486ff54ff8d26a9f04e059333c37")
