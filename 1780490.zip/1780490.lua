-- Lua provided by RyzenAPI
-- Game: Skull Bullets

-- MAIN APPLICATION
addappid(1780490)
-- Game: addappid(1780490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780491, 1, "d97dcfa59243c3730c8479cf56d63abc667f45bec63191c877866643dfec2bc5")
