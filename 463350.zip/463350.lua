-- Lua provided by RyzenAPI
-- Game: Storm Of Spears RPG

-- MAIN APPLICATION
addappid(463350)

-- MAIN APP DEPOTS / PACKAGES
addappid(463351, 1, "15f1b84c4c6d6836b1a4b0d858dcfaec53ca049048ed5ea54f8ade8f3e376097")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
