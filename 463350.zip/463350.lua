-- Lua provided by RyzenAPI
-- Game: 463350

-- MAIN APPLICATION
addappid(463350)
-- Game: addappid(463350)

-- MAIN APP DEPOTS / PACKAGES
addappid(463351, 1, "15f1b84c4c6d6836b1a4b0d858dcfaec53ca049048ed5ea54f8ade8f3e376097")
