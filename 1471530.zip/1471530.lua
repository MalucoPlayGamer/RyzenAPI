-- Lua provided by RyzenAPI
-- Game: AppID 1471530

-- MAIN APPLICATION
addappid(1471530)
-- Game: addappid(1471530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471531, 1, "fba2391a1ff96b6cf468e0d66c1dbc70a77ac4cc5d56f32baca5706a1e44a6cf")
