-- Lua provided by RyzenAPI
-- Game: addappid(711050)

-- MAIN APPLICATION
addappid(711050)

-- MAIN APP DEPOTS / PACKAGES
addappid(711051, 1, "44ea2d054072eca7d93d9cededb12f63984966324d66d322120cee876ec64f36")
