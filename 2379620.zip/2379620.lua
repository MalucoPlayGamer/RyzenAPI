-- Lua provided by RyzenAPI
-- Game: The Unfallens: Awakening

-- MAIN APPLICATION
addappid(2379620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379621, 1, "5e51450db3e55388fb89e37aa96542490dcdc30e3df66dee1e44620c5b644f3f")

