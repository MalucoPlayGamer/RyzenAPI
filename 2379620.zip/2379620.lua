-- Lua provided by RyzenAPI
-- Game: The Unfallens: Awakening

-- MAIN APPLICATION
addappid(2379620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379621, 1, "5e51450db3e55388fb89e37aa96542490dcdc30e3df66dee1e44620c5b644f3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
