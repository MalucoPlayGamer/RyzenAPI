-- Lua provided by RyzenAPI
-- Game: 1171240

-- MAIN APPLICATION
addappid(1171240)
-- Game: addappid(1171240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171241, 1, "4a76116c9356bdf2abac0a87494488428d6c871510eddc301b69fa098a71ca92")
