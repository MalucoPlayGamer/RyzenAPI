-- Lua provided by RyzenAPI
-- Game: Reiko's Fragments

-- MAIN APPLICATION
addappid(1171240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1171241, 1, "4a76116c9356bdf2abac0a87494488428d6c871510eddc301b69fa098a71ca92")

