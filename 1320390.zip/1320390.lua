-- Lua provided by RyzenAPI
-- Game: School of Magic Demo

-- MAIN APPLICATION
addappid(1320390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320391, 1, "45bcd2d1f47f2805e990a94a4c90e5c62f4b1de46137bfeac23623ec2b8ae1e2")
