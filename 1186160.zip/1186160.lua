-- Lua provided by RyzenAPI
-- Game: All Day Dying: Redux Edition

-- MAIN APPLICATION
addappid(1186160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186161, 1, "8fd595ffcd6ff1ab2f265d16902577abd9ea17eb0fd686d4c9034bff7391f4eb")
addappid(1186162, 1, "1fd738729298938db11e1a21be12c28421f80c7ecb6cea4d9199c96a76166406")

