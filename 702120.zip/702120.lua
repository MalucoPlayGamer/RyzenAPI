-- Lua provided by RyzenAPI
-- Game: AppID 702120

-- MAIN APPLICATION
addappid(702120)

-- MAIN APP DEPOTS / PACKAGES
addappid(702121, 1, "0ff1cc840ddfb659e456e0a25ec2c41922b5e7765cd10529ad7c95210e8207de")

