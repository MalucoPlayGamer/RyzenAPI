-- Lua provided by RyzenAPI
-- Game: AppID 702120

-- MAIN APPLICATION
addappid(702120)

-- MAIN APP DEPOTS / PACKAGES
addappid(702121, 1, "0ff1cc840ddfb659e456e0a25ec2c41922b5e7765cd10529ad7c95210e8207de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
