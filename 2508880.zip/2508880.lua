-- Lua provided by RyzenAPI
-- Game: 2508880

-- MAIN APPLICATION
addappid(2508880)
-- Game: addappid(2508880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508881, 1, "723e139583a5e03b5feaa2b603fdfe5214a13c0522f933f661cd0381ea3a88dd")
