-- Lua provided by SkyAPI 
-- Game: AppID 2508880
addappid(2508880)
addappid(2508881, 1, "723e139583a5e03b5feaa2b603fdfe5214a13c0522f933f661cd0381ea3a88dd")
