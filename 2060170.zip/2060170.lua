-- Lua provided by RyzenAPI
-- Game: Solas City Heroes

-- MAIN APPLICATION
addappid(2060170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060171, 1, "a32b38b12711ecfd395b208daee4691be435b95a6aecc537688b85f4bbbc8b15")
addappid(2594150, 0, "e85ee6c6c747a77fd5f1f9992f2b0d4d0d3c88592ec4a7627998019312dbb509")

