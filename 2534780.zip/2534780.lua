-- Lua provided by RyzenAPI
-- Game: Game: AppID 2534780

-- MAIN APPLICATION
addappid(2534780)
-- Game: addappid(2534780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2534781, 1, "fc770c6a1146ffdf3972493d2d9ce4ce9789534c232e92cb0587e9d3926499e5")
