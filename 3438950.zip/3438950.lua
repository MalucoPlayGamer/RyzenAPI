-- Lua provided by RyzenAPI
-- Game: addappid(3438950)

-- MAIN APPLICATION
addappid(3438950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438951, 1, "d11f3598ccb674e7b2ec396ec0e52d76a7d57446e635cee539db0cec25e7eff3")
