-- Lua provided by RyzenAPI
-- Game: 952400

-- MAIN APPLICATION
addappid(952400)
addappid(952401)
addappid(952403)
-- Game: addappid(952400)

-- MAIN APP DEPOTS / PACKAGES
addappid(952402,0,"0d22de41eeabde962950dcbd8943850bad2d8ade32d16ca3645c9c50868d38f8")
