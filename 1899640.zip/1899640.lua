-- Lua provided by RyzenAPI
-- Game: Hipster Cafe Demo

-- MAIN APPLICATION
addappid(1899640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899641, 1, "1a57a93224d243c0681e8e3edf588e3ecdbb6b9104bc9f16fd04fcd1a3fc3a4b")
