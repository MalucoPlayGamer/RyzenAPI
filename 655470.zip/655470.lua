-- Lua provided by RyzenAPI
-- Game: AppID 655470

-- MAIN APPLICATION
addappid(655470)

-- MAIN APP DEPOTS / PACKAGES
addappid(655471, 1, "a153c335a7fce772778acefe299c1bf8069c6ab71f764d17ca219ee57af64c54")

