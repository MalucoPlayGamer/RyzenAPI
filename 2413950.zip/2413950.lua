-- Generated with Luie @ https://lua.tools/
-- 2413950 - Final Sentence
-- Generated 2026-08-28 18:41:17 UTC
-- # Depots (Total/DLC/Shared): 5/2/2

-- Main AppID
addappid(2413950)

-- Main Depots
addappid(2413951, 1, "3ad7272d45fc2e119edbee37c6ba3717db9e05e3f86ef888f322187368c078e3")
setManifestid(2413951, "4359476531449613829", 847825203)

-- DLC's (no depot keys required)
addappid(4556350) -- Final Sentence Supporter Pack

-- DLC's (with depot keys)
-- Final Sentence Soundtrack (AppID: 4675680)
addappid(4675680)
addappid(4675681, 1, "fd3c3577b952ac15d2533a8ee3ff306828ce6a8dd6f63bbde27cded1a01677aa")
setManifestid(4675681, "2432564301354626005", 38677440)
addappid(4675682, 1, "687a0efa693460b19537b7c1f79e026e46bfb2454b974962d8abfcdf1aa21033")
setManifestid(4675682, "5293436803169795402", 185864572)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
