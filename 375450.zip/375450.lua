-- Lua provided by RyzenAPI
-- Game: NOBUNAGA'S AMBITION: Sphere of Influence - Ascension

-- MAIN APPLICATION
addappid(375450)
addappid(440913)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(375451, 1, "6a1ff2e590a2e88a0877fdd1d9ba214dafcc788b272bd3350ed275fd5a15c1ee")
addappid(440912, 0, "73d3f687df7a9e60c9ead2f1cac5f3dc83a5d8a7e988dcb711e86b09a1166112")
addappid(440914, 0, "f3e40493d6526950be66a137e203bfb057c0ef76c82dd670eba5b519adb10909")
addappid(440915, 0, "3231ae50b271522640019e230aab65be5e429aa72b826fc72bab5bd23e6e49fe")
addappid(440920, 0, "b247247b899628c02b098452e06d197f839e06c514a875811d22fc5c6ab16263")
addappid(440921, 0, "5ad003cb59cec7a144f8ae6d8e4865ac1743adbe643559dbe7236c10c8da97cb")
addappid(457360, 0, "d447dfa68aae4e4ff10780a7b0cb781faa162cf53c4c61355f01652b2f362372")

