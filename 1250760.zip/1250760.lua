-- Lua provided by RyzenAPI
-- Game: AppID 1250760

-- MAIN APPLICATION
addappid(1250760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250761, 1, "f216603c5d84982048016924a19b799179191613717423730f10418c0a175ecc")
addappid(1250762, 1, "5f7f9d373f70518956ccda6dac00784448885f57542faf2ddd79d9be0fa067f6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1925870)
