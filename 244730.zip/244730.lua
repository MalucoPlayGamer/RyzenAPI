-- Lua provided by RyzenAPI
-- Game: Divekick

-- MAIN APPLICATION
addappid(244730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(244731, 1, "b3a9b258894fe64f60a6075ff812af64daf0182c1dbb490adff8dc19e3245d7c")

