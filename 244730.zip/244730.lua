-- Lua provided by RyzenAPI
-- Game: AppID 244730

-- MAIN APPLICATION
addappid(244730)
-- Game: addappid(244730)

-- MAIN APP DEPOTS / PACKAGES
addappid(244731, 1, "b3a9b258894fe64f60a6075ff812af64daf0182c1dbb490adff8dc19e3245d7c")
