-- Lua provided by RyzenAPI
-- Game: Survive in Space

-- MAIN APPLICATION
addappid(467950)
-- Game: addappid(467950)

-- MAIN APP DEPOTS / PACKAGES
addappid(467951, 1, "c451015f36bb730586462d7177451cc40531b70c618407399c395b13cd14fe2e")
addappid(467952, 1, "0509987c77b499799d3f4b67085ef0642a97d52fdd18195e037e4ba2f5ff6ac7")
