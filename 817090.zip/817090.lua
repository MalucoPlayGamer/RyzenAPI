-- Lua provided by RyzenAPI
-- Game: Pizza Connection 3 - Soundtrack

-- MAIN APPLICATION
addappid(817090)
-- Game: addappid(817090)

-- MAIN APP DEPOTS / PACKAGES
addappid(817090,0,"51996e3b2c3d6340469d8a8c929264204ca6e2b08ed15e214592e5cae099995b")
