-- Lua provided by RyzenAPI
-- Game: 775310

-- MAIN APPLICATION
addappid(775310)
-- Game: addappid(775310)

-- MAIN APP DEPOTS / PACKAGES
addappid(775311, 1, "f799e6edd9feb2d5167c5c6dc9293b744e09aa8d96d5143a3a27c3eb180ece4f")
addappid(775314, 1, "f7f06f35fa4aae1a666137ff17a40421c3d8edc76fc0bdb2bad887736041814f")
