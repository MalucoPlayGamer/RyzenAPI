-- Lua provided by SkyAPI 
-- Game: Blood of Patriots
addappid(775310)
addappid(775311, 1, "f799e6edd9feb2d5167c5c6dc9293b744e09aa8d96d5143a3a27c3eb180ece4f")
addappid(775314, 1, "f7f06f35fa4aae1a666137ff17a40421c3d8edc76fc0bdb2bad887736041814f")
