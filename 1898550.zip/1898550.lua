-- Lua provided by RyzenAPI
-- Game: Brutal Rifters

-- MAIN APPLICATION
addappid(1898550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1898551, 1, "59c3c8eb94ac192b13c3545750e517bce1a47f41fddc603daa25fd9defd4be0b")

