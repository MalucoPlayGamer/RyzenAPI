-- Lua provided by RyzenAPI
-- Game: addappid(1898550)

-- MAIN APPLICATION
addappid(1898550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898551, 1, "59c3c8eb94ac192b13c3545750e517bce1a47f41fddc603daa25fd9defd4be0b")
