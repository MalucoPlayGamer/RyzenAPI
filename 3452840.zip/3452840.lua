-- Lua provided by RyzenAPI
-- Game: 3452840

-- MAIN APPLICATION
addappid(3452840)
-- Game: addappid(3452840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452841, 1, "08e953b01f303f99c0f0e266002617fa8c5447370f11e34ba8f2ef87eb86ef74")
