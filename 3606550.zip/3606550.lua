-- Lua provided by RyzenAPI
-- Game: 3606550

-- MAIN APPLICATION
addappid(3606550)
-- Game: addappid(3606550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3606551, 1, "d609907547db1b704d3c01ac67a069273edc95dd8e7c7043ea1cd659d092cb16")
addappid(3606552, 1, "c6576993f72fd4a9f9dcdbdfa61ca8bc6a34a3f91852317902cd3c83e1b2e744")
