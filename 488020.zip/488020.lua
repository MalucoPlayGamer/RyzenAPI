-- Lua provided by RyzenAPI
-- Game: addappid(488020)

-- MAIN APPLICATION
addappid(488020)

-- MAIN APP DEPOTS / PACKAGES
addappid(488021, 1, "665b2a9899eaa3f31107bae600b1b66c104e21a315e95d981e17abb92be11607")
