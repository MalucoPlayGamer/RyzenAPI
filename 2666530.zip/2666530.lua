-- Lua provided by RyzenAPI
-- Game: addappid(2666530)

-- MAIN APPLICATION
addappid(2666530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666531, 1, "f112afa617578476fdc3f382bedbd3b142e526647e15ed0cd65e991a21d5a841")
