-- Lua provided by RyzenAPI
-- Game: Idol Hands

-- MAIN APPLICATION
addappid(1745310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745311, 1, "5cc84c8ab2e0e10deb49332289a8f535f0b5acb2f9ea24fcfb8d585329f02200")
