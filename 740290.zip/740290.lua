-- Lua provided by RyzenAPI
-- Game: Game: AppID 740290

-- MAIN APPLICATION
addappid(740290)
-- Game: addappid(740290)

-- MAIN APP DEPOTS / PACKAGES
addappid(740291, 1, "86c4d2673ce4899fa444d260f0c91666b07b50278931b50ed44606cc5273b4ab")
