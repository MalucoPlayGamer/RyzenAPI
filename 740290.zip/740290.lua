-- Lua provided by RyzenAPI
-- Game: Irony Of Nightmare

-- MAIN APPLICATION
addappid(740290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(740291, 1, "86c4d2673ce4899fa444d260f0c91666b07b50278931b50ed44606cc5273b4ab")
