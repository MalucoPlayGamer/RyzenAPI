-- Lua provided by RyzenAPI
-- Game: Untitled Space Game

-- MAIN APPLICATION
addappid(1459560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459562,0,"4344397bc578d3726fbb1151c167117d5394bce70ced5bdcb857ba33243ac653")

