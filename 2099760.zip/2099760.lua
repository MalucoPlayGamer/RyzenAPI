-- Lua provided by RyzenAPI
-- Game: Game: Theseus Protocol Playtest

-- MAIN APPLICATION
addappid(2099760)
-- Game: addappid(2099760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099761, 1, "63477261bae941e498b7f8a2dd903b65087d2cdcf5495cf6911268c8ddb8541a")
