-- Lua provided by RyzenAPI
-- Game: addappid(3618440)

-- MAIN APPLICATION
addappid(3618440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3618441, 1, "b79a006ca042d6f76e901079d3fdcc21b60919fe34a10e3f3d854d471e710500")
addappid(3618442, 1, "234b9af981e606fef4c0eba41c7849d42b0d6c68c6bf24aad0e9635fbc236b9c")
