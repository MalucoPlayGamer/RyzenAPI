-- Lua provided by RyzenAPI
-- Game: AppID 360870

-- MAIN APPLICATION
addappid(360870)

-- MAIN APP DEPOTS / PACKAGES
addappid(360871, 1, "9588fa0ec8e9e2238864fbdecc3f25403c7dda2bf71e8a70011dfdd11f530667")
