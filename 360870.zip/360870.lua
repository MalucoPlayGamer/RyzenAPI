-- Lua provided by RyzenAPI
-- Game: Ultimate Tic-Tac-Toe

-- MAIN APPLICATION
addappid(360870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(360871, 1, "9588fa0ec8e9e2238864fbdecc3f25403c7dda2bf71e8a70011dfdd11f530667")
