-- Lua provided by RyzenAPI
-- Game: Lust Girls

-- MAIN APPLICATION
addappid(2345820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345821, 1, "88a922f07d4a9c776aecb1f4fe9198ec23fa7360b5e59a7e7ccd794759c1b466")

