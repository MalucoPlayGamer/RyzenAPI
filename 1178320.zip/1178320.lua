-- Lua provided by RyzenAPI
-- Game: CryoFall - Soundtrack

-- MAIN APPLICATION
addappid(1178320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178320,0,"d2f094dd461c2c2e95650c109bd8d49493e306ff2e9ed663616fedda6c81c56e")
addappid(1178322,0,"df16cb9bdf0ecd494f1a6a1ac013642e4aba11a181f5e2520afa1d780869ec3b")

