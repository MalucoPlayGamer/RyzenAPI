-- Lua provided by RyzenAPI
-- Game: MareQuest: An Interactive Tail Artpack

-- MAIN APPLICATION
addappid(2569880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569880,0,"3a1a13373988270127c033091830eae39ab3ab30ddcfaa93c8391334021a60fa")

