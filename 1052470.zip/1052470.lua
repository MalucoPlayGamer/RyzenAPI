-- Lua provided by RyzenAPI
-- Game: addappid(1052470)

-- MAIN APPLICATION
addappid(1052470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052472,0,"205be3337ef7066f1ac0727c3fe761a4725b512f0d13eb5088be6da698d4306c")
