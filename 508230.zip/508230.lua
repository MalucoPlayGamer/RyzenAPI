-- Lua provided by RyzenAPI
-- Game: Anime Studio Simulator

-- MAIN APPLICATION
addappid(508230)
addappid(548440)

-- MAIN APP DEPOTS / PACKAGES
addappid(508231, 1, "cf2ff8f42ea34bebb555f17f114ff4ce4fdc9595948dc9f941c8fb8aa07e4b53")
