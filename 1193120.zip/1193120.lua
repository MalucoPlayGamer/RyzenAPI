-- Lua provided by RyzenAPI
-- Game: 1193120

-- MAIN APPLICATION
addappid(1193120)
-- Game: addappid(1193120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193121, 1, "9db27e20129efe94254c5d99999b6c5ea68146d79100e2ddc751d8aa98a29574")
