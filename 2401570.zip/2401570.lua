-- Lua provided by SkyAPI 
-- Game: AppID 2401570
addappid(2401570)
addappid(2401571, 1, "ed95407bf5ca1f67f8bec1bd3ac8b6767360c1b531cfda580bf1b3587d311581")
