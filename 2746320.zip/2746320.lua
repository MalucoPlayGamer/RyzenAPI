-- Lua provided by RyzenAPI 
-- Game: AppID 2746320
addappid(2746320)
addappid(2746321, 1, "26f90b2e81ee47fd4641e066c97f560486e50c953dd88da41730f9c5e4bf58a4")
