-- Lua provided by RyzenAPI
-- Game: 1936200

-- MAIN APPLICATION
addappid(1936200)
-- Game: addappid(1936200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936201, 1, "3b01a3467467e732fa36c2d5bb8e3ec5c951857dd707a40619f5ed4b1074a258")
