-- Lua provided by RyzenAPI
-- Game: 3D Escape Room: Detective Story

-- MAIN APPLICATION
addappid(3411050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411051, 1, "c4600ef021e6ad60a4c455e997994f39bebc3eae442cc334d3475c7aff8371ed")
