-- Lua provided by SkyAPI 
-- Game: AppID 1265090
addappid(1265090)
addappid(1265091, 1, "5612e22686a8e033a120d56e03296b891a15204ca9d60d0e76fb863ced13ecbe")
