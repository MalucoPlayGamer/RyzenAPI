-- Lua provided by RyzenAPI
-- Game: 魔女秘药（witch elixir）

-- MAIN APPLICATION
addappid(1265090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265091, 1, "5612e22686a8e033a120d56e03296b891a15204ca9d60d0e76fb863ced13ecbe")

