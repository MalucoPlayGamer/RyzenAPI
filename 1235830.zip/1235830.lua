-- Lua provided by RyzenAPI 
-- Game: AppID 1235830
addappid(1235830)
addappid(1235831, 1, "11305462aeeea702fe8f17070160924e617636debd11cc3cd57766ea672e16e3")
