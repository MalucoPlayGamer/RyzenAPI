-- Lua provided by RyzenAPI
-- Game: Wolfenstein™

-- MAIN APPLICATION
addappid(10170)

-- MAIN APP DEPOTS / PACKAGES
addappid(10171, 1, "a2439326badfef6d764a514b33bb90eea391409d88f15992f1529e624c0cb8a2")
addappid(10172, 1, "2f0f40dcfebd4a8a05aeecb6fea49c433fc44a71eb8aafdb0abbc0169b5c4d16")
addappid(10173, 1, "c70e338e4470a1029611a86d1e9809d981c692ed83bb2915d9878ca07721013a")
addappid(10174, 1, "d747914aa2ded94213318d876a4cab085cc547378e7ee6da6a0969ad18fb9755")
addappid(10175, 1, "16f900a978eee5a3b1ab16b5d4021515281e17f643ace858a386f4d70c4a92a9")
addappid(10176, 1, "b0ffdf805eedf5d8adfe93a78346b788abf5c6af3a1addef2a04b891faddd873")

