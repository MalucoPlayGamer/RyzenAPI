-- Lua provided by RyzenAPI
-- Game: The Orb Chambers

-- MAIN APPLICATION
addappid(485220)

-- MAIN APP DEPOTS / PACKAGES
addappid(485221, 1, "6222405986634473eaa5d67ddeda4426d09302db71a66017c83cad5ad141248f")
