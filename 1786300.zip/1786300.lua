-- Lua provided by RyzenAPI
-- Game: Puzzle Art: Rodents

-- MAIN APPLICATION
addappid(1786300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786301, 1, "78f6cba82b83f3e8f4da32ebd6f662f9341d853ff556a2cb2739a4a1d7457eeb")

