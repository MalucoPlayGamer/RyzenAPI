-- Lua provided by SkyAPI 
-- Game: Puzzle Art: Rodents
addappid(1786300)
addappid(1786301, 1, "78f6cba82b83f3e8f4da32ebd6f662f9341d853ff556a2cb2739a4a1d7457eeb")
