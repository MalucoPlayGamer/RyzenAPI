-- Lua provided by RyzenAPI
-- Game: ToneStone Playtest

-- MAIN APPLICATION
addappid(228988)
addappid(1665400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665402,0,"128a56fcdf568ed9b9a1cc749ca56ca216dfcf911e597c3da397f827d5a95db4")
addappid(1665403,0,"5204b925ba5a14630208554395135c6e0a21304581bba7ca00a80751752e44fa")

