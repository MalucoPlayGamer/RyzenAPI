-- Lua provided by RyzenAPI
-- Game: Achievement Hunter: Princess

-- MAIN APPLICATION
addappid(804240)

-- MAIN APP DEPOTS / PACKAGES
addappid(804241, 1, "1e1679fc04d3fe7d4e396e7dd16e5f2f97019c92843fc4abb97d8578b9ecea36")

