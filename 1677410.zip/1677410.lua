-- Lua provided by SkyAPI 
-- Game: Romeow: to the cracked Mars
addappid(1677410)
addappid(1677411, 1, "803a5a738e4135f62e6e71c2c68160f4c140c9de12ca54a5eb534a0a760483c9")
