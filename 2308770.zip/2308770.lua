-- Lua provided by RyzenAPI
-- Game: Escape From The Depth

-- MAIN APPLICATION
addappid(2308770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308771, 1, "41b73f9059c586b1a657616808d47ce2a5b3e74b2c22a3543167b4fd1c3c95a4")
