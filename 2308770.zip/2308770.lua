-- Lua provided by SkyAPI 
-- Game: Escape From The Depth
addappid(2308770)
addappid(2308771, 1, "41b73f9059c586b1a657616808d47ce2a5b3e74b2c22a3543167b4fd1c3c95a4")
