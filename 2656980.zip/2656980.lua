-- Lua provided by RyzenAPI
-- Game: House of Lust

-- MAIN APPLICATION
addappid(2656980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656981, 1, "5c44a8ddeb3992c4b2971b406b36b6c55b83340d3d7e266420ce64c3f0a129bc")
