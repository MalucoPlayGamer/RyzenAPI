-- Lua provided by SkyAPI 
-- Game: AppID 921740
addappid(921740)
addappid(921741, 1, "4392d9b555cbfc5332f3c098be32b0f3ac7c966e387c5ac08d6fc7bce9ba881d")
