-- Lua provided by RyzenAPI
-- Game: AppID 921740

-- MAIN APPLICATION
addappid(921740)

-- MAIN APP DEPOTS / PACKAGES
addappid(921741, 1, "4392d9b555cbfc5332f3c098be32b0f3ac7c966e387c5ac08d6fc7bce9ba881d")

