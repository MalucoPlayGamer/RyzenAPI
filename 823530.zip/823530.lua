-- Lua provided by RyzenAPI
-- Game: Aesthetic Arena

-- MAIN APPLICATION
addappid(823530)

-- MAIN APP DEPOTS / PACKAGES
addappid(823531, 1, "acf8fccbb4f45349b0ff8e655c3e9fc0b4fb7a611dc8988f39c446d1958318cd")
