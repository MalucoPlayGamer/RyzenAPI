-- Lua provided by RyzenAPI
-- Game: Cyber Revolution

-- MAIN APPLICATION
addappid(3515280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515281, 1, "6df8a325b3146051d30853402a6a1ef6d9525fb0c05ac0297d4e96f17311cbb2")

