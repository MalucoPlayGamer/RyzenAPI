-- Lua provided by RyzenAPI
-- Game: Tung Sahur Zombie

-- MAIN APPLICATION
addappid(3817910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3817911, 1, "64ceb7d788656dcd2b1be9cdc18b4ea222c018b77778f4587a769cc1de4aa3b7")

