-- Lua provided by RyzenAPI
-- Game: Game: Invention 5

-- MAIN APPLICATION
addappid(3060730)
-- Game: addappid(3060730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3060731, 1, "2407124d09bf6502b921cd5566270d8081fb6394381ebd2eabe42f80e570c294")
