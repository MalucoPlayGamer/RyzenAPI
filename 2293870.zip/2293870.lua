-- Lua provided by RyzenAPI
-- Game: Game: AppID 2293870

-- MAIN APPLICATION
addappid(2293870)
-- Game: addappid(2293870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293871, 1, "174e8358b289e2a6e5d5152f1e16216de6597f1b165df2bf39b1361253d60aa1")
