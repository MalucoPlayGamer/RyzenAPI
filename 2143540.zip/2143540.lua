-- Lua provided by RyzenAPI
-- Game: Isekai Janken Hero

-- MAIN APPLICATION
addappid(2143540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143541, 1, "29691ae1e012fe2e8a4bff9e0a1d60cc7054f57d72c732cd02c5587cfda26caf")

