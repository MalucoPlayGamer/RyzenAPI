-- Lua provided by RyzenAPI
-- Game: AppID 1816650

-- MAIN APPLICATION
addappid(1816650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816651, 1, "5853e53bbaa141e59cc7d581f5cf9ebe189daedd9af432949481f50737bd01db")

