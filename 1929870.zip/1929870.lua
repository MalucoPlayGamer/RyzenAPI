-- Lua provided by RyzenAPI
-- Game: Nomad Survival

-- MAIN APPLICATION
addappid(1929870)
-- Game: addappid(1929870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929871, 1, "3ee504c44adec68c919e3017edfb69d28bc66a3223f42c91d6189e614d9eb828")
