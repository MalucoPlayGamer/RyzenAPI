-- Lua provided by RyzenAPI
-- Game: AppID 1072400

-- MAIN APPLICATION
addappid(1072400)
-- Game: addappid(1072400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072401, 1, "8244f520893a6ceee6f645c601e6a93e8d2c5035ed3d60d50d45feefdfa2fca5")
