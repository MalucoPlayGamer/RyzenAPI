-- Lua provided by RyzenAPI
-- Game: Game: Saku the Covert Agent

-- MAIN APPLICATION
addappid(2921690)
-- Game: addappid(2921690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921691, 1, "c9ca8698943c52459a0ed090afb21728f9fe4d5a5b0042a6e9f49ec04ebaffa5")
