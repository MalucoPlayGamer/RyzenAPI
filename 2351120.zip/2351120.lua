-- Lua provided by RyzenAPI 
-- Game: AppID 2351120
addappid(2351120)
addappid(2351121, 1, "a4a95595461e55ea6765cd72b371632ee2c547c993e9073c476600b5211bcd9f")
