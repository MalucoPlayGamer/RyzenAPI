-- Lua provided by RyzenAPI
-- Game: AppID 2351120

-- MAIN APPLICATION
addappid(2351120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351121, 1, "a4a95595461e55ea6765cd72b371632ee2c547c993e9073c476600b5211bcd9f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2662220)
