-- Lua provided by RyzenAPI
-- Game: AppID 1069380

-- MAIN APPLICATION
addappid(1069380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069381, 1, "9ee2ecaf0cdb7c07a6c6add64e80a645907e50e756ae63131af948ff725905c4")

