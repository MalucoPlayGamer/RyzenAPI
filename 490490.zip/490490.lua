-- Lua provided by RyzenAPI
-- Game: addappid(490490)

-- MAIN APPLICATION
addappid(490490)

-- MAIN APP DEPOTS / PACKAGES
addappid(490491, 1, "ae985edc8da95423b0a21d3370b71bffbab0164e5920cbc716cea1ce4ee13109")
