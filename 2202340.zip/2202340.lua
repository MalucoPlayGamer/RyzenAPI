-- Lua provided by RyzenAPI
-- Game: addappid(2202340)

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2202340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202342,0,"f09e5d39bdfb2dbc39e560731e0bd0063a1a7c00c69c633271aabcf8c54e7389")
