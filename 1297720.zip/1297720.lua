-- Lua provided by RyzenAPI
-- Game: Starstruck: Prologue

-- MAIN APPLICATION
addappid(1297720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297721, 1, "fadcceb075670aeb4b52904e67a1e867daa370e6d2b6bf4d5fb5ab7b191ddbfb")
