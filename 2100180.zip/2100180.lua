-- Lua provided by RyzenAPI
-- Game: Ever Seen a Cat? 2 - Paper Edition + Wallpapers

-- MAIN APPLICATION
addappid(2100180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100181, 1, "b00a9b80010dc3caa8aec5c67a4366235a4d2f0cb8829837fc92f61895aee7dc")
