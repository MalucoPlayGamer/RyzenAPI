-- Lua provided by RyzenAPI
-- Game: AppID 3078290

-- MAIN APPLICATION
addappid(3078290)
-- Game: addappid(3078290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078291, 1, "d570590c651defc7ae5f7d13b1b9cc9f866113cc431b314ebeb41269679ac3d7")
