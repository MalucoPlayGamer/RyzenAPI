-- Lua provided by RyzenAPI
-- Game: Game: AppID 1098420

-- MAIN APPLICATION
addappid(1098420)
-- Game: addappid(1098420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098421, 1, "f55b861235071194719a43b1dadae181718bf669b368d07662b13ccf55b9076f")
