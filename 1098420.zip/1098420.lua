-- Lua provided by RyzenAPI
-- Game: SpritePile

-- MAIN APPLICATION
addappid(1098420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1098421, 1, "f55b861235071194719a43b1dadae181718bf669b368d07662b13ccf55b9076f")
