-- Lua provided by RyzenAPI
-- Game: 462220

-- MAIN APPLICATION
addappid(462220)
-- Game: addappid(462220)

-- MAIN APP DEPOTS / PACKAGES
addappid(462221, 1, "bff76c64586752ac2c3936175e3ababf51d8b97602ad9acd9a1e76118673f6a5")
