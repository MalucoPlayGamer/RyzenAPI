-- Lua provided by RyzenAPI
-- Game: Game: Gladio Mori

-- MAIN APPLICATION
addappid(2689120)
-- Game: addappid(2689120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689121, 1, "87cb2be56e4de79d17f5cb52efc521ae4a02a57f2195116339023ad0aa27c4be")
