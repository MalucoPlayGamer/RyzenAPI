-- Lua provided by RyzenAPI
-- Game: Gladio Mori

-- MAIN APPLICATION
addappid(2689120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2689121, 1, "87cb2be56e4de79d17f5cb52efc521ae4a02a57f2195116339023ad0aa27c4be")

