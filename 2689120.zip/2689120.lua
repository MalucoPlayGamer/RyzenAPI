-- Lua provided by RyzenAPI 
-- Game: Gladio Mori
addappid(2689120)
addappid(2689121, 1, "87cb2be56e4de79d17f5cb52efc521ae4a02a57f2195116339023ad0aa27c4be")
