-- Lua provided by RyzenAPI
-- Game: Game: My Liege Demo

-- MAIN APPLICATION
addappid(2818470)
-- Game: addappid(2818470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818471, 1, "8975efc5221e065b232673e45ce9603990b9055c8b7155e8da6f48334db9587c")
