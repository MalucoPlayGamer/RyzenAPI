-- Lua provided by RyzenAPI
-- Game: Game: Barro 2024

-- MAIN APPLICATION
addappid(3119720)
-- Game: addappid(3119720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119721, 1, "cc275f98756c1c37b18cd77da7096ded0c7f534430753a41df0682bf434a4fbe")
addappid(3119722, 1, "aa75b0e483ba8a870d07b8670d008ee7928786371ca7211c1b353253d59e3f3d")
