-- Lua provided by SkyAPI 
-- Game: Zatorski, Ph.D.
addappid(1257520)
addappid(1257521, 1, "cfad78d002023ac042c02635e0ef5950b210343bd6a414f7b9324f9e45788760")
