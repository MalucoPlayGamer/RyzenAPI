-- Lua provided by RyzenAPI
-- Game: Zatorski, Ph.D.

-- MAIN APPLICATION
addappid(1257520)
-- Game: addappid(1257520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257521, 1, "cfad78d002023ac042c02635e0ef5950b210343bd6a414f7b9324f9e45788760")
