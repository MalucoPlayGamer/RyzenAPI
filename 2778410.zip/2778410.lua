-- Lua provided by RyzenAPI
-- Game: Cats and Seek : at Dino Park Demo

-- MAIN APPLICATION
addappid(2778410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778411, 1, "65328a4f300265862688f01ca9a4d188950b4ccd5eeb60571e381b591d76c1e5")
