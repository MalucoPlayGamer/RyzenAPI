-- Lua provided by RyzenAPI
-- Game: addappid(3175540)

-- MAIN APPLICATION
addappid(3175540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175541, 1, "d38e1e1219a49337e519716bddd4169130a7e1566c0852bf5f37a466cf7fa2e0")
