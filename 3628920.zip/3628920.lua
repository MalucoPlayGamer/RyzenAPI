-- Lua provided by RyzenAPI
-- Game: 3628920

-- MAIN APPLICATION
addappid(3628920)
-- Game: addappid(3628920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3628921, 1, "a2b6788cab4e62bf745f98ae833fb88d736aeae413cd837637b23c2e9e160dc3")
