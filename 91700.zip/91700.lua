-- Lua provided by RyzenAPI
-- Game: E.Y.E: Divine Cybermancy

-- MAIN APPLICATION
addappid(91700)

-- MAIN APP DEPOTS / PACKAGES
addappid(91701, 1, "36ae6dfb76a46698211c82895f28f8304f46794fd921589afde87c6bf7614c18")

