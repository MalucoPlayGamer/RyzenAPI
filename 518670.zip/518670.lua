-- Lua provided by RyzenAPI
-- Game: Intensive Exposure

-- MAIN APPLICATION
addappid(518670)
-- Game: addappid(518670)

-- MAIN APP DEPOTS / PACKAGES
addappid(518671, 1, "c1b40ca6ad77cca6c1b2a6af8deb411fbf795a31cc182f7cb68298d6eeac417e")
