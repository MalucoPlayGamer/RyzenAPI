-- Lua provided by SkyAPI 
-- Game: Intensive Exposure
addappid(518670)
addappid(518671, 1, "c1b40ca6ad77cca6c1b2a6af8deb411fbf795a31cc182f7cb68298d6eeac417e")
