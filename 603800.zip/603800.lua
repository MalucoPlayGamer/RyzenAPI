-- Lua provided by RyzenAPI
-- Game: ReThink

-- MAIN APPLICATION
addappid(603800)

-- MAIN APP DEPOTS / PACKAGES
addappid(603801, 1, "31053c494d102a04835d170d94b042e1e5136283d441c5cf7a5f25af7ccbaa54")
