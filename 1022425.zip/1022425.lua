-- Lua provided by RyzenAPI
-- Game: addappid(1022425)

-- MAIN APPLICATION
addappid(1022425)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022425,0,"f7f167e9636545f24f54c15b8fa4eb0a40d668c961f591981e556dafacd18d17")
