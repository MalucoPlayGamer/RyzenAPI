-- Lua provided by RyzenAPI
-- Game: I Hate My Waifu Streamer Demo

-- MAIN APPLICATION
addappid(3395680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3395681, 1, "3c674d07deb391d92f87b8e6409f8686156b724870d1acbd95d17dc6125a8f6f")
