-- Lua provided by RyzenAPI
-- Game: Game: Drill Deal Demo

-- MAIN APPLICATION
addappid(1668980)
-- Game: addappid(1668980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668981, 1, "44c882c4effa062d2b893d7be3b52392eea019a08d9c966aeb53679912789c73")
