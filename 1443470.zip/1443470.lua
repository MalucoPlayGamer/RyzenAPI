-- Lua provided by RyzenAPI
-- Game: Hauma - A Detective Noir Story

-- MAIN APPLICATION
addappid(1443470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443471, 1, "d4cc6d06f78a6bb6b590b2f9e6f1fcb56a39c3d737f61a2a1124c247477c2c92")
