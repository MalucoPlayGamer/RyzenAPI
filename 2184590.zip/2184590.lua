-- Lua provided by RyzenAPI
-- Game: Memories Off Yubikiri No Kioku

-- MAIN APPLICATION
addappid(2184590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184591, 1, "d13c3849a6d93237c9459e542fc1c3bbcf99a21e4d51d7642e794d8ea7935cc2")
