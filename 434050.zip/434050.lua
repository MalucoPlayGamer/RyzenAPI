-- Lua provided by RyzenAPI
-- Game: Duke Nukem 3D: 20th Anniversary World Tour

-- MAIN APPLICATION
addappid(434050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(434051, 1, "d49f8ba8799760e1828b631172a23b4249d2b62d08990a15b9889c5503959c8f")
addappid(434052, 1, "ea3018c6a0e0542aa4a358d3a5764dd5d991923c058fe460a3c57b991690cbd6")
addappid(434053, 1, "1d3041f7e94cc3e28939a46b4d23d9bd8a1342f106f7aa2949043614de034379")
