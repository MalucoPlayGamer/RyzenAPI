-- Lua provided by RyzenAPI
-- Game: AppID 230170

-- MAIN APPLICATION
addappid(230170)

-- MAIN APP DEPOTS / PACKAGES
addappid(230171, 1, "707c4a837fd32a1fbb400327e90a16760bb5d2f233420e3953bc46f6a03866aa")
addappid(230172, 1, "1a233e63171de023243ff005ce75420cb4f99270bc88fb92b90c31e7256dc9ea")
addappid(230173, 1, "ff4f42fe86769782f8aabc11624195ac9bedb3cd254b2c33ce064006729baf18")
addappid(230174, 1, "e0587c590e2e1c14f62a4ad87fcf93cf01790d59bc77677dc0454bdd9dd09ab4")
addappid(230175, 1, "6df03ebd6dbb9497e7ddfa593838f11a8723c5c89d7726812694bca06fc02375")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
