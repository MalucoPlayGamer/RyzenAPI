-- Lua provided by RyzenAPI
-- Game: 2182750

-- MAIN APPLICATION
addappid(2182750)
-- Game: addappid(2182750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182751, 1, "0a07ab399c6bea9ae5ac92196ab8fefc87b546c167cef4e11084452265cfd780")
