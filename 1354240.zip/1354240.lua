-- Lua provided by RyzenAPI
-- Game: Hunting Moon vol.2

-- MAIN APPLICATION
addappid(1354240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354241, 1, "440c43033c32461328d34790f926c132513801e3c5f5feef1874bfc8ae9ff777")
addappid(1354242, 1, "efb84e457b894f76831d4e9960266c5e8f5f9f58eec539aa579b9c47ce28b7e0")
addappid(1354243, 1, "be5c7ae33e36b8128ace7440dbdabc52245cbdcc64d22c739a7fb0f9189cbf6f")
