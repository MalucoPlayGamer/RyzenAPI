-- Lua provided by RyzenAPI
-- Game: Kaboom!

-- MAIN APPLICATION
addappid(1574670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574671, 1, "860bc4a158bd835a26e9c6541f9ac71762cb1558baa858869b1811844c9d5fe8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
