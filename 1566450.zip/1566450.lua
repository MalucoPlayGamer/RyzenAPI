-- Lua provided by RyzenAPI
-- Game: Setteeh

-- MAIN APPLICATION
addappid(1566450)
-- Game: addappid(1566450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566451, 1, "c4546af894afa897c5fa6093f8bcdf69436211257932aad8d251521253566ae1")
