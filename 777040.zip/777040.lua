-- Lua provided by RyzenAPI
-- Game: Game: AppID 777040

-- MAIN APPLICATION
addappid(777040)
-- Game: addappid(777040)

-- MAIN APP DEPOTS / PACKAGES
addappid(777041, 1, "ebbf5f0be3381cad906c6e5d11febed2c8b1f080b6b171f4d9304703872591c9")
