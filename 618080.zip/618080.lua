-- Lua provided by RyzenAPI
-- Game: Martial Arts Brutality

-- MAIN APPLICATION
addappid(618080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(618081, 1, "b67227c88e089563f4833e83fc796a0e2a20482345e0a8fdec71302bf0e90c75")

