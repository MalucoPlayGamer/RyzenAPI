-- Lua provided by RyzenAPI
-- Game: addappid(618080)

-- MAIN APPLICATION
addappid(618080)

-- MAIN APP DEPOTS / PACKAGES
addappid(618081, 1, "b67227c88e089563f4833e83fc796a0e2a20482345e0a8fdec71302bf0e90c75")
