-- Lua provided by RyzenAPI
-- Game: Eggy

-- MAIN APPLICATION
addappid(1523670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523671, 1, "55947e9a363c451baeb3cdfe8e5b3caef9f8908ca6ca87f6e40a040fd2d538e4")

