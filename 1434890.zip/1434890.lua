-- Lua provided by RyzenAPI 
-- Game: AppID 1434890
addappid(1434890)
addappid(1434891, 1, "e7767f4751d7430e87357868be339fde6b447208bbf1de0a419c730a0d93c8c8")
