-- Lua provided by RyzenAPI
-- Game: addappid(1434890)

-- MAIN APPLICATION
addappid(1434890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434891, 1, "e7767f4751d7430e87357868be339fde6b447208bbf1de0a419c730a0d93c8c8")
