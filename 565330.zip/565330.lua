-- Lua provided by RyzenAPI
-- Game: Twisted

-- MAIN APPLICATION
addappid(565330)

-- MAIN APP DEPOTS / PACKAGES
addappid(565331, 1, "62b35782ba2d5ac9217d3f56982c26a4db3da134b8f7f54d3897eebe5cb32dfa")
