-- Lua provided by RyzenAPI
-- Game: Vertical Slice: A Game Dev Story

-- MAIN APPLICATION
addappid(1491170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491171, 1, "a48df282623cea7fa3d718a014f1b2751dfbfdc4caed3e0fdc01931dfb8d5161")
