-- Lua provided by RyzenAPI
-- Game: 2726490

-- MAIN APPLICATION
addappid(2726490)
-- Game: addappid(2726490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726492,0,"5f1b96ec16722a2c83de432b6ebd24455f78864eaae9d5309e823a1de191ebbd")
