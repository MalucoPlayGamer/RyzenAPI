-- Lua provided by RyzenAPI
-- Game: CSI VR: Crime Scene Investigation

-- MAIN APPLICATION
addappid(893650)

-- MAIN APP DEPOTS / PACKAGES
addappid(893651, 1, "afa9822ac6936405550ddeefaa027812654aa58555aad6e9512b035d99ddda41")
