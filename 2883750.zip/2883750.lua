-- Lua provided by RyzenAPI
-- Game: 2883750

-- MAIN APPLICATION
addappid(2883750)
-- Game: addappid(2883750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883751, 1, "20e126f199fabbbea0b38ae6d1e29b4d34a398201440e356cea6c91f5d38eb51")
