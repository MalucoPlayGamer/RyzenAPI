-- Lua provided by RyzenAPI
-- Game: LOST EMBER - VR Edition

-- MAIN APPLICATION
addappid(1880890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880891, 1, "a38a1b4d145f6c3d1245785807c320cc386cc72f7b633d852da1b5bf4c2ed1a2")
