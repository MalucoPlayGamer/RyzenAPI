-- Lua provided by RyzenAPI
-- Game: Dark Succubus

-- MAIN APP DEPOTS / PACKAGES
addappid(3732310, 1, "b9927c741842e6a7ad541a8b873ca8e16c8fbf5186c46e98624d76d79d1cff46") -- Dark Succubus
addappid(3732311, 1, "810ac05957947c9ed2104adae094b5eb949c2a13a6cdf26241899e9e8b7e9ee0") -- Depot 3732311

