-- Lua provided by RyzenAPI
-- Game: 31 Room

-- MAIN APPLICATION
addappid(3617320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3617321, 1, "b2fa95a52a2936f1f2aa6aca7b0483ab1e9ef23b608b45ede100472724339f57")
