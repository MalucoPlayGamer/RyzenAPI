-- Lua provided by RyzenAPI
-- Game: 719640

-- MAIN APPLICATION
addappid(719640)
-- Game: addappid(719640)

-- MAIN APP DEPOTS / PACKAGES
addappid(719641, 1, "4a48e249b8aeaf0f9c698c0ef0e5d099d0270ba1086aff9f7662d2c5c75e1167")
