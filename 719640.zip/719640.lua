-- Lua provided by RyzenAPI
-- Game: War Planet Online: Global Conquest

-- MAIN APPLICATION
addappid(719640)

-- MAIN APP DEPOTS / PACKAGES
addappid(719641, 1, "4a48e249b8aeaf0f9c698c0ef0e5d099d0270ba1086aff9f7662d2c5c75e1167")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
