-- Lua provided by RyzenAPI
-- Game: 1792600

-- MAIN APPLICATION
addappid(1792600)
-- Game: addappid(1792600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792601, 1, "8434d696dd21d12dca0589e96bffb42bee74bb26838a8dd9d7860c641ed76794")
