-- Lua provided by SkyAPI 
-- Game: Dusk Diver 2
addappid(1792600)
addappid(1792601, 1, "8434d696dd21d12dca0589e96bffb42bee74bb26838a8dd9d7860c641ed76794")
