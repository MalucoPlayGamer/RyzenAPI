-- Lua provided by RyzenAPI
-- Game: Dusk Diver 2

-- MAIN APPLICATION
addappid(1792600)
addappid(1919820)
addappid(1930530)
addappid(1930660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1792601, 1, "8434d696dd21d12dca0589e96bffb42bee74bb26838a8dd9d7860c641ed76794")

