-- Lua provided by RyzenAPI
-- Game: Stellar Monarch 2

-- MAIN APPLICATION
addappid(1437750)
addappid(2775010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1437751, 1, "3d00824ef271b7220e3734a677c4439796dfea7f6ab6957c154a09fd071e1c39")

