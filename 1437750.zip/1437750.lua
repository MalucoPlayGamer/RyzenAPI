-- Lua provided by RyzenAPI
-- Game: Stellar Monarch 2

-- MAIN APPLICATION
addappid(1437750)
addappid(2775010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437751, 1, "3d00824ef271b7220e3734a677c4439796dfea7f6ab6957c154a09fd071e1c39")
