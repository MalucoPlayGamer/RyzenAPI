-- Lua provided by RyzenAPI
-- Game: Another Try

-- MAIN APPLICATION
addappid(1197220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197222,0,"bf668a492ed8944e666744c97edbe70d6f30970eed141844bf6a4688b76676c5")

