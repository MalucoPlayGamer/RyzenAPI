-- Lua provided by RyzenAPI
-- Game: Game: Knock Harder

-- MAIN APPLICATION
addappid(1216490)
-- Game: addappid(1216490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216491, 1, "b01afb0eadbf6ce1f1d4465afc361f705351cb6bbd6f232bb331cecf7f4e5744")
