-- Lua provided by RyzenAPI
-- Game: 1492080

-- MAIN APPLICATION
addappid(1492080)
-- Game: addappid(1492080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492081, 1, "df646fda511f4aa54489c1d601bbb455b4d6ccccb974fcddcbe7a2e01a2ef61c")
