-- Lua provided by RyzenAPI
-- Game: ArcaniA

-- MAIN APPLICATION
addappid(39690)

-- MAIN APP DEPOTS / PACKAGES
addappid(39691, 1, "0017f440e275cbff33c5b3b72e4d23c715231b31297b2aa4e3ab9f8c6fce357b")
addappid(39692, 1, "d0fc34b0f7765b377b2af76c334d747b7d253ab3b875892b5d4c66c3c816b8bc")
addappid(39693, 1, "d9a8c6e0e5277794e749a316707075f4e0b2a219a911f0ee8259da787a5030be")
addappid(39694, 1, "0c8ce431ad6b600d1fbe5273b86dfb699b816240e8d79f31b71c95bae4ce32c9")
addappid(39695, 1, "c49350144ca0b661c88c50f7df7e56961d4cca4490707889395b199a021a1aa3")
addappid(39696, 1, "90a1cb6faf6305e4ed8a99f52972eaa4db2e6b6caddcf8f529e5cc1b15623281")
addappid(39697, 1, "8b522d6b9318bb1222f290608e83df4d1d1c03d24ec2ef0509655d8b490d2ff7")
addappid(39698, 1, "79ce43881df8438d51c6adb3cba4c72b6ef9bf65895e43db3b36be57f036bf42")
addappid(39699, 1, "eb442d0bc679ff2fb2566d3508bcf9a2c6041c782d9c44bc73e76268a3e3eeae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
