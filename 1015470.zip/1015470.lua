-- Lua provided by RyzenAPI 
-- Game: AppID 1015470
addappid(1015470)
addappid(1015471, 1, "a23754552108470cf4b9f262a922df1b718b0a88ca87bcb576936299a125aa14")
