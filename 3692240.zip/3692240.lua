-- Lua provided by RyzenAPI
-- Game: 3692240

-- MAIN APPLICATION
addappid(3692240)
-- Game: addappid(3692240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3692241, 1, "9a28bd1e52de54e042fd28729de5ce7ccf7f5c3ab09eacc1d5cafc97bbc4291d")
