-- Lua provided by RyzenAPI
-- Game: Minigolf Blast Demo

-- MAIN APPLICATION
addappid(2389370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389371, 1, "1be08c8b27359801669114b36c09dcc75c8ae51ad3b95710b5597410ce6a52a1")
