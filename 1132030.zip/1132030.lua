-- Lua provided by RyzenAPI
-- Game: Trash Sailors

-- MAIN APPLICATION
addappid(1132030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1132031, 1, "30acb98fa8d522782586dbc4b6d68647abcc92b05659ee1a0edfe144cccd6d86")
