-- Lua provided by RyzenAPI
-- Game: 1132030

-- MAIN APPLICATION
addappid(1132030)
-- Game: addappid(1132030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132031, 1, "30acb98fa8d522782586dbc4b6d68647abcc92b05659ee1a0edfe144cccd6d86")
