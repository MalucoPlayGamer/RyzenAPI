-- Lua provided by RyzenAPI
-- Game: AppID 619020

-- MAIN APPLICATION
addappid(619020)
-- Game: addappid(619020)

-- MAIN APP DEPOTS / PACKAGES
addappid(619021, 1, "b3ed5c66465215117655a0524c35c85c8408d8a844882eaa7037a778bfaef4a0")
