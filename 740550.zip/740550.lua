-- Lua provided by RyzenAPI
-- Game: Record of Agarest War Mariage

-- MAIN APPLICATION
addappid(740550)

-- MAIN APP DEPOTS / PACKAGES
addappid(740551, 1, "bc6fcddc29500fe0f3dffb7552973d7f84c293a0564b1b7d4c1fcdac9db4d1e3")
addappid(740552, 1, "cc784046db3ebb1c97521ebd5647f01faceda9e8ddc1242e03eabb27c865385c")
addappid(740553, 1, "b035fda492026eca543354db7deb9518e2064b99b560abbc35593de797b780a4")
addappid(740554, 1, "245bbbf6d244911e6182095d353a72c4d0ce1819b31a9c6248270fbc5fcc0dd0")
addappid(740555, 1, "72dd24ab3b8fb770a27c095ed7e9bf25103ca1f0951b310c1998f243160a5c14")
addappid(740556, 1, "afd4e63d8255fbdc6779b285e184c7d86d0a67ecf6f423b2512cb306e99cec79")
addappid(740557, 1, "ca93b6b4330f97fd8ffb25244e8266f1e0b86fd8b80c52552c1afcfcc50766b9")
addappid(740558, 1, "37bda2403ae4d7c6b3f372288dee900c9a0c93318a569bcfc23a2b496bc361eb")
addappid(1015490, 0, "68db7fb0c6322c9ec1e30b5d3e7dc7a56ff2bd4bd0983cfafe7a9bd2512c4e44")

