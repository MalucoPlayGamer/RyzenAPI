-- Lua provided by RyzenAPI
-- Game: Record of Agarest War Mariage

-- MAIN APPLICATION
addappid(740550)

-- MAIN APP DEPOTS / PACKAGES
addappid(740551, 1, "bc6fcddc29500fe0f3dffb7552973d7f84c293a0564b1b7d4c1fcdac9db4d1e3")
addappid(740552, 1, "cc784046db3ebb1c97521ebd5647f01faceda9e8ddc1242e03eabb27c865385c")
addappid(740553, 1, "b035fda492026eca543354db7deb9518e2064b99b560abbc35593de797b780a4")
addappid(740554, 1, "245bbbf6d244911e6182095d353a72c4d0ce1819b31a9c6248270fbc5fcc0dd0")
addappid(740555, 1, "72dd24ab3b8fb770a27c095ed7e9bf25103ca1f0951b310c1998f243160a5c14")
addappid(740556, 1, "afd4e63d8255fbdc6779b285e184c7d86d0a67ecf6f423b2512cb306e99cec79")
addappid(740557, 1, "ca93b6b4330f97fd8ffb25244e8266f1e0b86fd8b80c52552c1afcfcc50766b9")
addappid(740558, 1, "37bda2403ae4d7c6b3f372288dee900c9a0c93318a569bcfc23a2b496bc361eb")
addappid(1015490, 0, "68db7fb0c6322c9ec1e30b5d3e7dc7a56ff2bd4bd0983cfafe7a9bd2512c4e44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
