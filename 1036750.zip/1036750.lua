-- Lua provided by RyzenAPI
-- Game: addappid(1036750)

-- MAIN APPLICATION
addappid(1036750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036751, 1, "6d28e80e5a67830f7a73f26e4d1dcd0b9d181526b67d15a3b6a120457e0a5b06")
