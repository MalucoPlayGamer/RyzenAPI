-- Lua provided by RyzenAPI
-- Game: AppID 1208420

-- MAIN APPLICATION
addappid(1208420)
-- Game: addappid(1208420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208421, 1, "7ef86eaa58f8f7f32566173047488d528cd9dc5e24870b5c8627da335b8ee959")
