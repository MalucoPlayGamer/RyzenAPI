-- Lua provided by RyzenAPI
-- Game: AppID 1208420

-- MAIN APPLICATION
addappid(1208420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208421, 1, "7ef86eaa58f8f7f32566173047488d528cd9dc5e24870b5c8627da335b8ee959")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
