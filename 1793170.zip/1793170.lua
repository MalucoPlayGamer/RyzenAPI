-- Lua provided by RyzenAPI
-- Game: 1793170

-- MAIN APPLICATION
addappid(1793170)
-- Game: addappid(1793170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793171, 1, "6e5dfb7681b4cab69f66fee2663e195d60ff7c8c51a32b25e80ba39d7a80e11b")
