-- Lua provided by RyzenAPI
-- Game: addappid(1172620)

-- MAIN APPLICATION
addappid(1172620)
addappid(1453980)
addappid(1467220)
addappid(1594030)
addappid(1781320)
addappid(1928780)
addappid(2307680)
addappid(2838650)
addappid(2838670)
addappid(3444920)
addappid(3444930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172621, 1, "d0a7c81c3c4ec69d5646531c500f6f8e46c7a42a74c6baf68a210c8db2f82117")
addappid(2309050, 0, "e496bd343a45a22ca0148b587298f7701885f32f944ce4217de1c0ba4fb0f786")
addappid(2838640, 0, "68937ad2c3fcbdd9f020ab2a0bf862931c990fafd559f2fd67a362a76f4569ec")
