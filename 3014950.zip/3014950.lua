-- Lua provided by RyzenAPI
-- Game: X4: Timelines Soundtrack

-- MAIN APPLICATION
addappid(3014950)
-- Game: addappid(3014950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014951, 1, "e8c1768c0019beef805c2a654750409b6813e5f4e9cf70e70cb264aacc466390")
addappid(3014952, 1, "86da418d92358803e074991c09e3c20b10b7cb69c768f013b29d9c38e7f745c9")
