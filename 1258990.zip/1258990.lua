-- Lua provided by RyzenAPI
-- Game: Rushberry Mercs

-- MAIN APPLICATION
addappid(1258990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258991, 1, "9969e0b5a058e8bfd603216379b49e9767edd11481ee3fcfdeb47c8d2e242840")
