-- Lua provided by RyzenAPI
-- Game: Geometry Wars™ 3: Dimensions Evolved

-- MAIN APPLICATION
addappid(310790)
addappid(333630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(310791, 1, "22339baa4088b74620ca32ad42a8b2aee19f19c6a74f69783e15ed93800ae052")
addappid(310792, 1, "19f76e591aed58ccd9c7f88f4c756340913cdbf4e909df93d8ba0e9d9ce784bb")
addappid(310793, 1, "3d23995b2bccaf040619db2433fa44107ab4980d087a591164ceb180251855ac")
addappid(310794, 1, "1179b9ffeac609b68cb25838413eabb1dcffaa3a04ede02a225bb8178de7bdbc")
addappid(310795, 1, "45fad7b8475b90b8ca16d27b9b967c4268167aa7099e25d18517047db73e728f")
addappid(310796, 1, "d63663572b6915c367e67d403014ef1c704e564c88f93c0ba4613c4cf03beecb")

