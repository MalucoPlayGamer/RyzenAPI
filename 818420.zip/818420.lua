-- Lua provided by RyzenAPI
-- Game: jump kingdom

-- MAIN APPLICATION
addappid(818420)

-- MAIN APP DEPOTS / PACKAGES
addappid(818421, 1, "079b8f62e88d47bbfdcc96562d9332bbaddf315f3a4b5010b8b4305f60235bf1")
