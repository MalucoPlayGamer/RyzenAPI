-- Lua provided by RyzenAPI
-- Game: 2778160

-- MAIN APPLICATION
addappid(2778160)
-- Game: addappid(2778160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778161, 1, "f79b068d732a7085ffb0d6c14576b98d5acb3f3cb6e5d35a70835fe85c8c2742")
