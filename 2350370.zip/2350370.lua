-- Lua provided by RyzenAPI
-- Game: Profi Girls

-- MAIN APPLICATION
addappid(2350370)
addappid(2369270)
-- Game: addappid(2350370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350371, 1, "95413fffe91984efe09f6aebdfe3f669128d1a66a1bd797d769e3d3ffe3ca38b")
