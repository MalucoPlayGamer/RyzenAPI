-- Lua provided by RyzenAPI
-- Game: 1376240

-- MAIN APPLICATION
addappid(1376240)
-- Game: addappid(1376240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376241, 1, "c47afc61d9967acaf61e977a1103ccbdf9dad469279132fc534dde09ab4f34a2")
