-- Lua provided by RyzenAPI
-- Game: addappid(16110)

-- MAIN APPLICATION
addappid(16110)

-- MAIN APP DEPOTS / PACKAGES
addappid(16111, 1, "fcc1a41758d939ab3b06f87eb711af6b64ed0166a3a05a297a9bfcc304dfc3ce")
