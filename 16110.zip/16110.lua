-- Lua provided by SkyAPI 
-- Game: Virtual Villagers: The Lost Children
addappid(16110)
addappid(16111, 1, "fcc1a41758d939ab3b06f87eb711af6b64ed0166a3a05a297a9bfcc304dfc3ce")
