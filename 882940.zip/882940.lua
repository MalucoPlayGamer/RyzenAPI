-- Lua provided by RyzenAPI
-- Game: Game: The Moment We Met

-- MAIN APPLICATION
addappid(882940)
-- Game: addappid(882940)

-- MAIN APP DEPOTS / PACKAGES
addappid(882941, 1, "1022958706aa21f194a4e8eee12adb5ea0e507d8ca12acd4a008548e5b517558")
