-- Lua provided by RyzenAPI
-- Game: 我是大官人

-- MAIN APPLICATION
addappid(2103160)
-- Game: addappid(2103160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103161, 1, "90e158a65305f550a50d634397acb33006eac608ae3a44b4778635def6714cb4")
