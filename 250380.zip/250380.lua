-- Lua provided by RyzenAPI
-- Game: Knock-knock

-- MAIN APPLICATION
addappid(250380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(250381, 1, "afc8172ef018ec7d71cffebbeeb87147164c994b34c3b2c9e17ec6fbfc885a74")
addappid(250382, 1, "37ccfec7384f9102bf5c8fc518f9e69d92423d33351fd64cff96f5b42c5e7e1a")
addappid(250383, 1, "b0ee4151376f8878c7bd01097505a809de168d3ff24f6ab9d4a433290068fd65")

