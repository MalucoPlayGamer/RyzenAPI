-- Lua provided by RyzenAPI
-- Game: Talk to Strangers

-- MAIN APPLICATION
addappid(963280)

-- MAIN APP DEPOTS / PACKAGES
addappid(963281, 1, "bf33002d36ade724e25938a24a6aca364edebf9c2be1337b1da5f38781f981d2")
addappid(963282, 1, "2c4d0a481a4d10e81ea29ecfffc5f30be28786c9d6c78235d94174b777035a92")
addappid(963283, 1, "fbb0b838dbfccd15721ba11a32d78bb1715440ee5eef5622570dcf0c162f4bae")

