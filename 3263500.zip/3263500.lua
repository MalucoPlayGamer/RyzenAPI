-- Lua provided by SkyAPI 
-- Game: AppID 3263500
addappid(3263500)
addappid(3263501, 1, "4f5d42e6a32275bab4d73cb97799caea094b1a13f0faa8c38cada152a86ebbac")
