-- Lua provided by RyzenAPI
-- Game: addappid(1710290)

-- MAIN APPLICATION
addappid(1710290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710291, 1, "94fa4f76f2c1f4413d97c4d43de019ee7e72c151131df21ba424bee714a614cd")
