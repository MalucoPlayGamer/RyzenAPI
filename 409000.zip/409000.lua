-- Lua provided by RyzenAPI
-- Game: Mystery Chronicle: One Way Heroics

-- MAIN APPLICATION
addappid(409000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(409001, 1, "68a7707f1a14d19fd50cf48e448e02a45e666fd140bac53768f741617dfe90e3")
addappid(409002, 1, "8ac1696203e6d3c33397bdb7ab817e1bc1e7ab2208cf2a34b711cf5742611d57")
addappid(409003, 1, "b6d49eb9bd4a20817582d595c7d5f9481f3a32ba21e59de858e3e8af3b521d1f")

