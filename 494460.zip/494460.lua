-- Lua provided by RyzenAPI
-- Game: 494460

-- MAIN APPLICATION
addappid(494460)
-- Game: addappid(494460)

-- MAIN APP DEPOTS / PACKAGES
addappid(494461, 1, "fac375e09e5fc527478329c369529d3706eac0033231288aa36a7c03046adc50")
