-- Lua provided by RyzenAPI
-- Game: The Horace Trilogy

-- MAIN APPLICATION
addappid(2006840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006841, 1, "c57a000cc8d8e1e46e1b9f2c096ec8d2ac4e96d0cff9d537eebe0349b3b8ce0e")
addappid(2006842, 1, "d77ea36cdb9b2697c7674b293e5e75fc2b12d37c20634369ed185356fb1fb54e")
addappid(2006843, 1, "bb59249d88d58244befa9b02f3667fd1e669bef8bccf4976f29de5f384cb6d02")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
