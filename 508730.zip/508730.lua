-- Lua provided by RyzenAPI
-- Game: Painted Legend

-- MAIN APPLICATION
addappid(508730)

-- MAIN APP DEPOTS / PACKAGES
addappid(508731, 1, "d10644f1e499053a6c13f7954d620c68efe6ede8e19f80dfdac15a387bd89ab0")

