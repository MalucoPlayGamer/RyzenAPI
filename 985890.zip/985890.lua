-- Lua provided by RyzenAPI
-- Game: Streets of Rage 4

-- MAIN APPLICATION
addappid(985890)

-- MAIN APP DEPOTS / PACKAGES
addappid(985891, 1, "334d196369a500638de8a9a02c66424ef3b3a519c858d3699911fdeb53deba76")
addappid(985892, 1, "c1c833c8664eecb7d7d21a056367ce7349b84f6fa25e160498bb581c6728e938")
addappid(985893, 1, "6c963ed6d4f98f40848a2b775a16737dc05ac6554c3122b0870140512531f4dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1585820)
