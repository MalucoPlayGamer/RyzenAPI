-- Lua provided by RyzenAPI
-- Game: SpellForce: Conquest of Eo

-- MAIN APPLICATION
addappid(1581770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581771, 1, "ffe2a296f48776e37af1454d167edda61275a0f08fed2ab4664ebbe27be48bb8")
addappid(1581773, 1, "13b6351fe5b434273ad9b36f114044a308db4dc77120669ba37d47626a0bcd95")
addappid(2681600, 0, "010d5842cb048d1e414ee229a6d3e84fae9e0f1388348c12259eba9716616077")
addappid(3132660, 0, "b77d01b9249631e8560b47025ec291ac854c156849a85d1246e4948f430c88e4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3540990)
