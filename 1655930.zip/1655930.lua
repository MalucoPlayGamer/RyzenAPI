-- Lua provided by RyzenAPI
-- Game: Hentai Jigsaw

-- MAIN APPLICATION
addappid(1655930)
-- Game: addappid(1655930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655931, 1, "e71069c3a7378233632b344f8e318fb11e73007018910e79797a80ea7e0a70e6")
