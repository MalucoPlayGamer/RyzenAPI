-- Lua provided by RyzenAPI 
-- Game: Hentai Jigsaw
addappid(1655930)
addappid(1655931, 1, "e71069c3a7378233632b344f8e318fb11e73007018910e79797a80ea7e0a70e6")
