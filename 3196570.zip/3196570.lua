-- Lua provided by RyzenAPI
-- Game: The Realm of Reincarnation

-- MAIN APPLICATION
addappid(3196570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3196571, 1, "f0026f891fee6e584946b58b028781cc11aeb064e87eca1831974e970c3e4d2c")

