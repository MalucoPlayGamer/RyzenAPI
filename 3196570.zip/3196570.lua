-- Lua provided by RyzenAPI
-- Game: addappid(3196570)

-- MAIN APPLICATION
addappid(3196570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196571, 1, "f0026f891fee6e584946b58b028781cc11aeb064e87eca1831974e970c3e4d2c")
