-- Lua provided by RyzenAPI
-- Game: 3739820

-- MAIN APPLICATION
addappid(3739820)
-- Game: addappid(3739820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3739820,0,"07cd214abeaada3bde404c07269ec9d2c2455b678f1d5bc8c594066d2a152454")
