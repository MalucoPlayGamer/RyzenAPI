-- Lua provided by RyzenAPI
-- Game: 377980

-- MAIN APPLICATION
addappid(377980)
-- Game: addappid(377980)

-- MAIN APP DEPOTS / PACKAGES
addappid(377981, 1, "2d1f0e770b38ae7afd208c1580fa95cdbc20a7f4b8c28fb4b8cf74c6455c1d80")
