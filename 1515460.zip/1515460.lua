-- Lua provided by RyzenAPI
-- Game: Prison Tycoon®: Under New Management

-- MAIN APPLICATION
addappid(1515460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515461, 1, "1a529d93dd63e3f08fae8d3528c552d2349ac1653a9dcae57f8cc2d31fd5ad00")

