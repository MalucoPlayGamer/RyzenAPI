-- Lua provided by RyzenAPI
-- Game: C-War 2

-- MAIN APPLICATION
addappid(1086690)
addappid(1115460)
addappid(1182180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086691, 1, "78e45c327e2e3ec47d8d2da2268af6d8711c77805391e263d304238e4b530f5a")
