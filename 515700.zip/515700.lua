-- Lua provided by RyzenAPI
-- Game: Snowday

-- MAIN APPLICATION
addappid(515700)

-- MAIN APP DEPOTS / PACKAGES
addappid(515701, 1, "1e16c85e81ce0da866ddacdf40b4cef5afc6955b33f2723575ab5430544985d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
