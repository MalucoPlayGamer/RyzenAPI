-- Lua provided by RyzenAPI
-- Game: addappid(515700)

-- MAIN APPLICATION
addappid(515700)

-- MAIN APP DEPOTS / PACKAGES
addappid(515701, 1, "1e16c85e81ce0da866ddacdf40b4cef5afc6955b33f2723575ab5430544985d3")
