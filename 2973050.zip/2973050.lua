-- Lua provided by RyzenAPI
-- Game: addappid(2973050)

-- MAIN APPLICATION
addappid(2973050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973051, 1, "865a9c3bef2191e442326dcb81c82a0fe3c081d6507e13db34b3acfc872fb409")
