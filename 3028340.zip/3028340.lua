-- Lua provided by RyzenAPI
-- Game: Game: AppID 3028340

-- MAIN APPLICATION
addappid(3028340)
-- Game: addappid(3028340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028341, 1, "ed77c20e89fd78d0f1db316859d34b919f19a55d969a0253256a51ada2f1341c")
