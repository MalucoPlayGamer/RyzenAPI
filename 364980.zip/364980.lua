-- Lua provided by RyzenAPI
-- Game: Bunker Constructor

-- MAIN APPLICATION
addappid(364980)

-- MAIN APP DEPOTS / PACKAGES
addappid(364981, 1, "52429d7e443b89ca92b4f4fac2ee2ba4a5e7e5cbdb4ef4449baf945cde3eac01")

