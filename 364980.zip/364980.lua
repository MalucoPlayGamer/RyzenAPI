-- Lua provided by RyzenAPI
-- Game: Bunker Constructor

-- MAIN APPLICATION
addappid(364980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(364981, 1, "52429d7e443b89ca92b4f4fac2ee2ba4a5e7e5cbdb4ef4449baf945cde3eac01")

