-- Lua provided by RyzenAPI
-- Game: Game: Kulebra and the Souls of Limbo - Prologue

-- MAIN APPLICATION
addappid(1678600)
-- Game: addappid(1678600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678601, 1, "e663b48ace1b39742a310a956e36da6e6296117083e3a4454c6855a36b17845e")
addappid(1678602, 1, "546f817cbe339cfa0eafe71da1c1ca666fac5dd762aed9cd2ed0c7cdc3d5950e")
addappid(1678603, 1, "d4d7e379e9c47871679a6c1bbadf9f12e4a130062a99e416529922b5bcd75705")
addappid(1678604, 1, "98ac6335ce104251916bafdcd3b0297a74cc3f7d09f8b82810998b58bc19288a")
