-- Lua provided by RyzenAPI
-- Game: Space Battle Royale

-- MAIN APPLICATION
addappid(2366400)
addappid(2844840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366401, 1, "df3949b0098a7fcb481bc995dbb490c39e959e10fd6648c6d591949d039eccf9")
