-- Lua provided by RyzenAPI
-- Game: addappid(1205513)

-- MAIN APPLICATION
addappid(1205513)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205513,0,"ff8697fd3fe26d292fddf3b2b0a6962a6ae700b9664c7abebbdb7dbee55aca6e")
