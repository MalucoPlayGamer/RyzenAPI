-- Lua provided by RyzenAPI
-- Game: The Gametrekking Omnibus

-- MAIN APPLICATION
addappid(838070)

-- MAIN APP DEPOTS / PACKAGES
addappid(838071, 1, "3751500348ff0013e84fbb87b26ec67ea4429e544abcb73dac11f78521fb0f72")

