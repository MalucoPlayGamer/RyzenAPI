-- Lua provided by RyzenAPI
-- Game: addappid(1848070)

-- MAIN APPLICATION
addappid(1848070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848071, 1, "c2f2dd75363dd2abb3d82907c88c92562aa721987d74c63ef61711e854a8ac53")
