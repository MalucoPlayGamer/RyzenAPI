-- Lua provided by RyzenAPI
-- Game: It's Chopping Time!

-- MAIN APPLICATION
addappid(4272270)
addappid(4649980)

-- MAIN APP DEPOTS / PACKAGES
addappid(4272271,0,"d7eed45d80891350ca29f21ff31418542643011c10af8b1dccb7166a1cd2cb4f")

