-- Lua provided by RyzenAPI
-- Game: Dungeon Core

-- MAIN APPLICATION
addappid(1351900)
-- Game: addappid(1351900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351901, 1, "df8fda8e7311636bb68868ee5451103397bb777a9a05561a66bc43e818972f43")
