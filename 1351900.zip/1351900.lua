-- Lua provided by RyzenAPI
-- Game: Dungeon Core

-- MAIN APPLICATION
addappid(1351900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351901, 1, "df8fda8e7311636bb68868ee5451103397bb777a9a05561a66bc43e818972f43")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
