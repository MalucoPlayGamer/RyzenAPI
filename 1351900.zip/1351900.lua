-- Lua provided by RyzenAPI 
-- Game: Dungeon Core
addappid(1351900)
addappid(1351901, 1, "df8fda8e7311636bb68868ee5451103397bb777a9a05561a66bc43e818972f43")
