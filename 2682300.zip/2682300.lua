-- Lua provided by RyzenAPI
-- Game: True Reporter. Mystery of Mistwood

-- MAIN APPLICATION
addappid(2682300)
-- Game: addappid(2682300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682301, 1, "cdd03d9bc9da09077c56e164587e268fbdc3041a490c229299d889b440aceccc")
