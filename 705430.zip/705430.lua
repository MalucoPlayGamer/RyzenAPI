-- Lua provided by RyzenAPI
-- Game: Game: AppID 705430

-- MAIN APPLICATION
addappid(705430)
-- Game: addappid(705430)

-- MAIN APP DEPOTS / PACKAGES
addappid(705431, 1, "b74e9295490a3774f48ca45d0f16a0ce79a909bab42878a09893b93c8c054708")
