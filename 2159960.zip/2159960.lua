-- Lua provided by RyzenAPI
-- Game: CorpoNation: The Sorting Process

-- MAIN APPLICATION
addappid(2159960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159961, 1, "bc9b0555e50d5d1397d3675bc4c9024b415dbfd462501dbac31ad1764f8ffaf6")
