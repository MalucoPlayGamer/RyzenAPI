-- Lua provided by RyzenAPI
-- Game: Lukewarm Massacre: The Spirit of Light Soundtrack

-- MAIN APPLICATION
addappid(2958980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958981, 1, "a3368ee1149cf4acfc6a123952f42a77f16312c709929e3c4427751b8e97efe8")
