-- Lua provided by RyzenAPI
-- Game: War Hunter

-- MAIN APPLICATION
addappid(842560)

-- MAIN APP DEPOTS / PACKAGES
addappid(842561,0,"4523d4fe2781a2339c9cf9e45f55ebc73e7c7f81502afaa6848d59b3112ab54c")

