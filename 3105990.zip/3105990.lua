-- Lua provided by RyzenAPI
-- Game: addappid(3105990)

-- MAIN APPLICATION
addappid(3105990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3105991, 1, "bacdad7bfa227bf39a14011665e13f2cf2526f6ee4ded04e7e9445c8d25e1af2")
