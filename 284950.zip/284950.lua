-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles: Japan

-- MAIN APPLICATION
addappid(284950)
-- Game: addappid(284950)

-- MAIN APP DEPOTS / PACKAGES
addappid(284951, 1, "3934d773225ed2dad9c5ac9bb09957b852b38d3889352968a9f778b64f0fbba9")
