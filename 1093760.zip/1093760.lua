-- Lua provided by RyzenAPI
-- Game: Shogun's Empire: Hex Commander

-- MAIN APPLICATION
addappid(1093760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1093761, 1, "5c7f382c4eb655a30ca386c4f3d9e627d7a939b7d49d3403d5b46eb3f3f3a3d7")

