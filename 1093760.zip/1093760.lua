-- Lua provided by RyzenAPI 
-- Game: Shogun's Empire: Hex Commander
addappid(1093760)
addappid(1093761, 1, "5c7f382c4eb655a30ca386c4f3d9e627d7a939b7d49d3403d5b46eb3f3f3a3d7")
