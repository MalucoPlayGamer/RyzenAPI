-- Lua provided by RyzenAPI
-- Game: addappid(657230)

-- MAIN APPLICATION
addappid(657230)

-- MAIN APP DEPOTS / PACKAGES
addappid(657231, 1, "ba642932ad6cc34eba947f7238cc2d5edc22c5a00e34d26b44b864dcaf2a1e55")
