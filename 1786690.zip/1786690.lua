-- Lua provided by RyzenAPI
-- Game: Pinballer (3D Pinball)

-- MAIN APPLICATION
addappid(1786690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786691, 1, "3e75a4de5cf4a6377f1be31847741566270c20fa88b274bfcbf003d1f46e6846")

