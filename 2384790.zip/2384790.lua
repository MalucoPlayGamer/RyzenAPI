-- Lua provided by RyzenAPI
-- Game: Paranormal Mission

-- MAIN APPLICATION
addappid(2384790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384791, 1, "340bf8a3a027021fa610567884cc3923dbf02eb2dd6b08b44d57f7d79345a7b7")
