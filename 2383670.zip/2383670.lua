-- Lua provided by RyzenAPI
-- Game: Tom Clancy’s Rainbow Six Extraction Demo

-- MAIN APPLICATION
addappid(2383670)
-- Game: addappid(2383670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383671, 1, "e8a5d6803e29c016b04d21b72b62cbdb74ee2be9408de85497b084b82e1b644e")
addappid(2383672, 1, "46a063147704fde139210f7e3d70d0b13fb71ef3cae9df64cd9bb7372dcdbbc5")
