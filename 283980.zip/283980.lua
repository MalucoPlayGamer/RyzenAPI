-- Lua provided by RyzenAPI
-- Game: Game: Spy Fox in "Dry Cereal"

-- MAIN APPLICATION
addappid(283980)
-- Game: addappid(283980)

-- MAIN APP DEPOTS / PACKAGES
addappid(283981, 1, "ab8515c871b9ad7e75f9237fdaf993e811fca7e77e17879d8ab36dcd236ece0e")
addappid(283984, 1, "13c02ffdcd49464c7fc2a347f1cbca3c1c7ba0644c7c0ae9178b61ee8f2daedd")
addappid(283985, 1, "f12895275535a988508da29ed7659913ec820cbd676145f7cd4e2f619c461893")
addappid(283992, 1, "c5e8fad6120cf328b9a8255959ed04d0c2c1c4882d169949815e4fbf48616633")
addappid(283993, 1, "72553c6abe2af7c82aed22bd0d143399dfe11d7499660ea48cc7401387741588")
