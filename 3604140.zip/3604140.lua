-- Lua provided by RyzenAPI
-- Game: 3604140

-- MAIN APPLICATION
addappid(3604140)
-- Game: addappid(3604140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3604141, 1, "29701fc3c3e198cc016e5619564804b9dd90af4342ac0ff7933e916f0d3ec0a9")
