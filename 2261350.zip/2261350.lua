-- Lua provided by RyzenAPI
-- Game: Cozy Keep: Farm, Craft, Manage

-- MAIN APPLICATION
addappid(2261350)
-- Game: addappid(2261350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261351, 1, "d69076bb6ef8e9fe72fc48d7e81f79a512ba83496052e773a1097d65712291f3")
