-- Lua provided by RyzenAPI
-- Game: 1650550

-- MAIN APPLICATION
addappid(1650550)
-- Game: addappid(1650550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650551, 1, "5128c74e4ab7b6dc236c1841d351ad6e231bbed20a7de6a3f0969101ed9736eb")
