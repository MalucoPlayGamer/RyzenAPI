-- Lua provided by RyzenAPI
-- Game: 1029760

-- MAIN APPLICATION
addappid(1029760)
-- Game: addappid(1029760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029761, 1, "8ce792020d827cdfecdf7428f8e059b33956efd53513467597aee48caf739520")
