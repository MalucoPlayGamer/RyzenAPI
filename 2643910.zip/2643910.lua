-- Lua provided by RyzenAPI
-- Game: The Final Countdown

-- MAIN APPLICATION
addappid(2643910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643911, 1, "241ca61315c28923ba92332c98baee3fb7d0806b5979862c0ab7a6ba6345b6b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
