-- Lua provided by RyzenAPI
-- Game: The Final Countdown

-- MAIN APPLICATION
addappid(2643910)
-- Game: addappid(2643910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643911, 1, "241ca61315c28923ba92332c98baee3fb7d0806b5979862c0ab7a6ba6345b6b4")
