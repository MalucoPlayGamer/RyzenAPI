-- Lua provided by RyzenAPI
-- Game: 疾风猎人-上线送V10，超变独家版本

-- MAIN APPLICATION
addappid(2447580)
-- Game: addappid(2447580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447581, 1, "fefe554760590123402397dfcc236129ec85d6cba15e69b084187e7ecb304781")
