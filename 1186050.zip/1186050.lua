-- Lua provided by RyzenAPI
-- Game: Game: AppID 1186050

-- MAIN APPLICATION
addappid(1186050)
-- Game: addappid(1186050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186051, 1, "9d671d25c325174ba5082c7a0df21f2d05a7aebde47b8f9edda79d7217ea1fbf")
