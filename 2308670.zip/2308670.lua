-- Lua provided by RyzenAPI
-- Game: Game: AppID 2308670

-- MAIN APPLICATION
addappid(2308670)
-- Game: addappid(2308670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308671, 1, "8f99dd386d719cfb161b6ded836f27ca5b758c7eebcdc25bb90cd3f04b99ee7f")
