-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - VTBS Airport

-- MAIN APPLICATION
addappid(2729880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729880,0,"d27766fd9cfdae58c3b9e8a14ffd199a897077231915f946a038f6d80b9064bc")
