-- Lua provided by RyzenAPI
-- Game: 2676170

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(2676170)
-- Game: addappid(2676170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676172,0,"ad04ed84076d6edb93e76c8513acea1728c2ef18eebeaf2c84e8ead5e9ac9602")
