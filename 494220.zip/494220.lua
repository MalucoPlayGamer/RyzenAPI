-- Lua provided by RyzenAPI
-- Game: Game: Blight of the Immortals

-- MAIN APPLICATION
addappid(494220)
-- Game: addappid(494220)

-- MAIN APP DEPOTS / PACKAGES
addappid(494221, 1, "393b427307f3be9d98b9d76842b625861e1ad359c62fadc85aa7ac43136064ee")
addappid(494222, 1, "8e8b7e449afd7af79e60d07ea4f1daa9a919a277ff78c3634e049623bf0ff285")
