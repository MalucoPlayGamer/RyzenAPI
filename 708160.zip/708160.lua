-- Lua provided by RyzenAPI
-- Game: Yokai Mask

-- MAIN APPLICATION
addappid(708160)

-- MAIN APP DEPOTS / PACKAGES
addappid(708161, 1, "ae58476805e99dc6fd2264d99cccb314ee5d79ca57c8fc227fec73dfb6b46744")
