-- Lua provided by RyzenAPI
-- Game: ShadowCalls 暗影召唤

-- MAIN APPLICATION
addappid(680500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(680501, 1, "69fd15c127c85e29b1ce572d2216e1dd1c677c18a69c354e76778637d7fbafd9")
