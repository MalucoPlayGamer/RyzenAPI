-- Lua provided by RyzenAPI
-- Game: Game: AppID 680500

-- MAIN APPLICATION
addappid(680500)
-- Game: addappid(680500)

-- MAIN APP DEPOTS / PACKAGES
addappid(680501, 1, "69fd15c127c85e29b1ce572d2216e1dd1c677c18a69c354e76778637d7fbafd9")
