-- Lua provided by RyzenAPI
-- Game: Game: AppID 851080

-- MAIN APPLICATION
addappid(851080)
-- Game: addappid(851080)

-- MAIN APP DEPOTS / PACKAGES
addappid(851081, 1, "5b2cc5e418f16dc656beeffc8f24e5c3f64c587c5c38a16d579617b0dcfa6665")
