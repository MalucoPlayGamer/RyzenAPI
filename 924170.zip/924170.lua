-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(924170)
-- Game: addappid(924170)

-- MAIN APP DEPOTS / PACKAGES
addappid(924170,0,"301a30a15dc3f2c0c4483c4379eb7fe45a95e2989367f5a43b9530e5988c1274")
