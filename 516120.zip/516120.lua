-- Lua provided by RyzenAPI
-- Game: addappid(516120)

-- MAIN APPLICATION
addappid(516120)

-- MAIN APP DEPOTS / PACKAGES
addappid(516121, 1, "e504edeb902d0618fb77500306ecfea03e83296d4d29c07781e1ef4132bfc380")
