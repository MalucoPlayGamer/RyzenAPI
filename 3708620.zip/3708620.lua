-- Lua provided by RyzenAPI
-- Game: Numeral Strike

-- MAIN APPLICATION
addappid(3708620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3708621,0,"41d3e7086a542b753d74518f799a2147ad3bb896d94e21bb52d03f1909264adc")

