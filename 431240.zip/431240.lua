-- Lua provided by RyzenAPI
-- Game: Golf With Your Friends

-- MAIN APPLICATION
addappid(431240)
addappid(1277570)
addappid(1901920)
addappid(1901921)
addappid(1901922)
addappid(2073740)
addappid(2130860)
addappid(2246730)
addappid(2366470)
addappid(2456990)
addappid(2456991)
addappid(2591390)
addappid(2710860)
addappid(2710870)
addappid(2863570)
addappid(3041140)
addappid(3041150)
addappid(3265830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(431241, 1, "16cd47114e4065cbc0a73cdeb4ea975256bf4ab9ac9e6306e112f94c5522f12d")
addappid(431242, 1, "6b14b5df622bf22a48c1842adf665a0e018cf6728a6f65ccc64dbe4a9258a3c3")
addappid(431243, 1, "8cc130bb9bbf82e74db58ec24740489b008779b70337a4bc6adce57825740d2f")
addappid(564170, 0, "fc920161bc70827e127a30a447ae4d0d47e9ace5c4190050fc3ba76950d107a8")

