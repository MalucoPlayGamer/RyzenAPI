-- Lua provided by RyzenAPI
-- Game: Gun Devil

-- MAIN APPLICATION
addappid(1287040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287041, 1, "804aecf0730bf5396781ad4e335a2e9eb954d2574ce3f992949513806016f2df")

