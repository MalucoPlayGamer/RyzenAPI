-- Lua provided by RyzenAPI
-- Game: Wish - Art Book

-- MAIN APPLICATION
addappid(1269010)
addappid(1269011)
addappid(1269012)
-- Game: addappid(1269010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269010,0,"3b2e905412c598dfee18a1ed43fc53bdd2556ef14b7cbc5849a3e33b1060a97e")
