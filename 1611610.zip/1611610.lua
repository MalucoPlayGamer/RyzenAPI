-- Lua provided by RyzenAPI
-- Game: Game: Girls for Clip maker

-- MAIN APPLICATION
addappid(1611610)
-- Game: addappid(1611610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611611, 1, "9e2ebee267b22d49740d6715d2d5b85849038f1f5adcd6b4ea7a88266755be48")
