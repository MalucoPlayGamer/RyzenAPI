-- Lua provided by RyzenAPI 
-- Game: Girls for Clip maker
addappid(1611610)
addappid(1611611, 1, "9e2ebee267b22d49740d6715d2d5b85849038f1f5adcd6b4ea7a88266755be48")
