-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV Demo

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228986)
addappid(1162550)
addappid(1162551)
-- Game: addappid(1162550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162552,0,"30e029a73d2cd455580db980bdef5211cd2e38cc9ba199b92ee2eed9dd21194f")
