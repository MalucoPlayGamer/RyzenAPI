-- Lua provided by RyzenAPI
-- Game: addappid(3358480)

-- MAIN APPLICATION
addappid(3358480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358481, 1, "3d4ea256fe50dee45f4f366091ae4631daf43c93c90b2cd917250812346997b4")
