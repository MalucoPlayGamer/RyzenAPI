-- Lua provided by RyzenAPI
-- Game: 1948700

-- MAIN APPLICATION
addappid(1948700)
addappid(2102830)
-- Game: addappid(1948700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948701, 1, "431609d09f4d239805b1e8db7e06aaa8f50e084a9330b6eeec7c4b2346ce22c0")
