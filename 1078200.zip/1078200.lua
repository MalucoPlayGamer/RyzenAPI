-- Lua provided by RyzenAPI
-- Game: Spirits Abyss

-- MAIN APPLICATION
addappid(1078200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078201, 1, "82820bed9decff94818120c96f15a246f22b71cd30034aeded44443410644aa7")

