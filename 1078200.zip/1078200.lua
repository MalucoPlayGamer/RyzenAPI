-- Lua provided by SkyAPI 
-- Game: AppID 1078200
addappid(1078200)
addappid(1078201, 1, "82820bed9decff94818120c96f15a246f22b71cd30034aeded44443410644aa7")
