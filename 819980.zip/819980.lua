-- Lua provided by RyzenAPI
-- Game: Brief Battles

-- MAIN APPLICATION
addappid(819980)

-- MAIN APP DEPOTS / PACKAGES
addappid(819981,0,"2f961db680388085c8b86c3fb3156b45664d17017c74b958fa5c465186ac3aa4")

