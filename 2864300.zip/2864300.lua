-- Lua provided by RyzenAPI
-- Game: Zombodesert

-- MAIN APPLICATION
addappid(2864300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864301, 1, "40b345c8830e75a08c2fba20a75a32a52cca4125b7e386eb3d20d7d99ef73601")

