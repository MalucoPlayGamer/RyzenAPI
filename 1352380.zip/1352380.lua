-- Lua provided by RyzenAPI
-- Game: addappid(1352380)

-- MAIN APPLICATION
addappid(1352380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352381, 1, "9a8cd0ff7135c5220190e30d12b91207ad93e1dde15eaf979cbd0152880ecd04")
