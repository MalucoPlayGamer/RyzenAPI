-- Lua provided by SkyAPI 
-- Game: Guts 'N Goals: Preseason
addappid(1352380)
addappid(1352381, 1, "9a8cd0ff7135c5220190e30d12b91207ad93e1dde15eaf979cbd0152880ecd04")
