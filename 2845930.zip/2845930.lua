-- Lua provided by RyzenAPI
-- Game: Final Dash

-- MAIN APPLICATION
addappid(2845930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845931, 1, "f6b8b34d8aa1b5ca9e9267a11ca2059ee0e152643172929f805fee812f751e34")
