-- Lua provided by RyzenAPI
-- Game: Final Dash

-- MAIN APPLICATION
addappid(2845930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2845931, 1, "f6b8b34d8aa1b5ca9e9267a11ca2059ee0e152643172929f805fee812f751e34")

