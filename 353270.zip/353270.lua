-- Lua provided by RyzenAPI
-- Game: Hyperdimension Neptunia Re;Birth3 V Generation

-- MAIN APPLICATION
addappid(353270)
addappid(987270)
addappid(1042050)
addappid(1050120)
addappid(1050121)
addappid(1050122)
addappid(1051790)
addappid(1051791)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(353271, 1, "3486fb9867eb4d44f8f77de8f1731ef563abacf49c2f69a153bdf0a6fdec6566")
addappid(353272, 1, "392ca2035868c6ead2aa636cbe4fc880cdb68b28471bb8bc373c911854721fb7")
addappid(353273, 1, "a8f2a6e462cb8707c58fb8a341e483ffce516ef0d468679c042fefbafa1aedaa")
addappid(389150, 0, "c2f1ee98c26d66923f8c51abe26815e939779e4eb68199d8b2f8984b77c77f10")
addappid(545020, 0, "7fe2cc2470fa5d8887246bca4e57effff68a5d7bfcb66f1fa2695e6137242d88")

