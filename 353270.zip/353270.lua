-- Lua provided by RyzenAPI
-- Game: Hyperdimension Neptunia Re;Birth3 V Generation

-- MAIN APPLICATION
addappid(353270)
addappid(987270)
addappid(1042050)
addappid(1050120)
addappid(1050121)
addappid(1050122)
addappid(1051790)
addappid(1051791)
-- Game: addappid(353270)

-- MAIN APP DEPOTS / PACKAGES
addappid(353271, 1, "3486fb9867eb4d44f8f77de8f1731ef563abacf49c2f69a153bdf0a6fdec6566")
addappid(353272, 1, "392ca2035868c6ead2aa636cbe4fc880cdb68b28471bb8bc373c911854721fb7")
addappid(353273, 1, "a8f2a6e462cb8707c58fb8a341e483ffce516ef0d468679c042fefbafa1aedaa")
addappid(389150, 0, "c2f1ee98c26d66923f8c51abe26815e939779e4eb68199d8b2f8984b77c77f10")
addappid(545020, 0, "7fe2cc2470fa5d8887246bca4e57effff68a5d7bfcb66f1fa2695e6137242d88")
