-- Lua provided by RyzenAPI
-- Game: Game: In The Gym (Memes Horror Game)

-- MAIN APPLICATION
addappid(2275180)
-- Game: addappid(2275180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275181, 1, "a26d633b3784b5152b7afa3769ca6acc42b6e112fed651be0765cd0c9aadedff")
