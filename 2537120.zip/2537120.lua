-- Lua provided by RyzenAPI
-- Game: Game: 911: Prey

-- MAIN APPLICATION
addappid(2537120)
-- Game: addappid(2537120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537121, 1, "05e84c525e433bcb79114a7b3108c6af4f9dfe15039891a0a81b93b90d5e6cc3")
