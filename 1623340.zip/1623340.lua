-- Lua provided by RyzenAPI
-- Game: 3D Hentai Puzzle 2

-- MAIN APPLICATION
addappid(1623340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623341, 1, "e05f74cef3390e258ab0bb21b587b9d4c4897c8b80ad27bb43036f63f6a5bde2")

