-- Lua provided by RyzenAPI 
-- Game: Banzai Escape
addappid(440340)
addappid(440341, 1, "4254e74e20a385daacbfbeee6dfc530fee98265aaf9fdfe38ca2224a0f2ee65d")
addappid(488530, 0, "cb8632d9b92c4d73d337e581fe5701798ce9989274cbd9ac24aebc3a3b8ebe2c")
