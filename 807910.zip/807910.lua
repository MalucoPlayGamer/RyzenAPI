-- Lua provided by RyzenAPI
-- Game: Road Legends

-- MAIN APPLICATION
addappid(807910)
addappid(807911)
addappid(807913)
-- Game: addappid(807910)

-- MAIN APP DEPOTS / PACKAGES
addappid(807912,0,"102892f2e4d739c5cab2c28ee3e7c6898ec63a076086f97a5403d0ddd6c44d8a")
