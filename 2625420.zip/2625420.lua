-- Lua provided by RyzenAPI
-- Game: Drive Beyond Horizons

-- MAIN APPLICATION
addappid(2625420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625421, 1, "e6632a8ac0813239fe1784858878c1dc48c48075d55d2b4045f529ba7ba3a01c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
