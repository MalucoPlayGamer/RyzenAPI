-- Lua provided by RyzenAPI
-- Game: addappid(1827520)

-- MAIN APPLICATION
addappid(1827520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827520,0,"0e2407c40baab23dca30610fc65e4429804463af27776d42e92c770b7dbef1ea")
