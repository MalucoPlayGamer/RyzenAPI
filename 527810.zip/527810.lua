-- Lua provided by RyzenAPI
-- Game: addappid(527810)

-- MAIN APPLICATION
addappid(527810)

-- MAIN APP DEPOTS / PACKAGES
addappid(527811, 1, "9ba7b945224177e5d4a9449697fa3d5c83eace962cf0d9399a1845e74fcb68b4")
