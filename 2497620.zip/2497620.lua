-- Lua provided by RyzenAPI
-- Game: Shadows of Doubt Soundtrack

-- MAIN APPLICATION
addappid(2497620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497621, 1, "70db2604e171234bf48403a98c2bb175dfc16e10fb357e208f6d359e7e33e2f3")
addappid(2497622, 1, "21618d9ebcf1831acd23a615f279102005f56d1e0f8daa930679910df47b144e")

