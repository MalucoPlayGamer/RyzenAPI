-- Lua provided by RyzenAPI
-- Game: 1035920

-- MAIN APPLICATION
addappid(1035920)
-- Game: addappid(1035920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035921, 1, "50a711d244c73dd0a1c1230da75c1e91640454ba51f6c5011f6f68e2adf2b2d1")
