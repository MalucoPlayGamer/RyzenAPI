-- Lua provided by RyzenAPI 
-- Game: Chocolate makes you happy: Lunar New Year
addappid(1035920)
addappid(1035921, 1, "50a711d244c73dd0a1c1230da75c1e91640454ba51f6c5011f6f68e2adf2b2d1")
