-- Lua provided by RyzenAPI
-- Game: Game: Girl Jigsaw

-- MAIN APPLICATION
addappid(1593860)
-- Game: addappid(1593860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593861, 1, "384adaeae53ce2029da7357c031d4f65464de382d96bb8d4da5dff56ea4ba9f0")
addappid(1608150, 0, "ddd6f10b9ac1e0f3fbdae87e074206a92a590570480a88cb3fc2d684cda82888")
