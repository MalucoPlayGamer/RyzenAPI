-- Lua provided by RyzenAPI
-- Game: Timemelters Demo

-- MAIN APPLICATION
addappid(1737580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737581, 1, "1f449359e233ab9af512718dae6a652bbc8f9dd4431b8b5956466ab9b7c2be79")

