-- Lua provided by RyzenAPI
-- Game: AppID 950890

-- MAIN APPLICATION
addappid(950890)
-- Game: addappid(950890)

-- MAIN APP DEPOTS / PACKAGES
addappid(950891, 1, "b1794fb1c9b7d90a30ab8663529c51a26b8e8a525d6452c9d933e1bf84650485")
