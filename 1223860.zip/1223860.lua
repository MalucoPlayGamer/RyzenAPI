-- Lua provided by RyzenAPI
-- Game: Game: AppID 1223860

-- MAIN APPLICATION
addappid(1223860)
-- Game: addappid(1223860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223861, 1, "8a6fdb170c7e6f1deef5bd3d0d5a2d08d17eea5806a9f3e533398cc8f6ea9fa2")
addappid(1223862, 1, "fa6db69067788043e8918292b9da7bdd6f28fc0d1cf33f826ff09858017fe200")
