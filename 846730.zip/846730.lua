-- Lua provided by RyzenAPI
-- Game: AppID 846730

-- MAIN APPLICATION
addappid(846730)
-- Game: addappid(846730)

-- MAIN APP DEPOTS / PACKAGES
addappid(846731, 1, "710c5dd476c24b9e7f29d92ce9425bc4b5c4290754ee91e3bbe145156968cad8")
