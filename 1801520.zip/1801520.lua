-- Lua provided by RyzenAPI 
-- Game: Zombieville USA 3D
addappid(1801520)
addappid(1801521, 1, "08b70f9e9b1b0671385a0f0b82e648b65d38566858a4dfad56d957ac4710e441")
