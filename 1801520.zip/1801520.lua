-- Lua provided by RyzenAPI
-- Game: Zombieville USA 3D

-- MAIN APPLICATION
addappid(1801520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1801521, 1, "08b70f9e9b1b0671385a0f0b82e648b65d38566858a4dfad56d957ac4710e441")

