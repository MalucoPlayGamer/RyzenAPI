-- Lua provided by RyzenAPI
-- Game: SchoolBoy Runaway

-- MAIN APPLICATION
addappid(3359320)
-- Game: addappid(3359320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359321, 1, "6501fca770ca2ec4e4804a7c5674717d9e5fd6e864f3860cd9624379fafe214c")
