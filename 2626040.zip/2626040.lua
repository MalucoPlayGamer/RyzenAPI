-- Lua provided by RyzenAPI
-- Game: addappid(2626040)

-- MAIN APPLICATION
addappid(2626040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626041, 1, "12037318a8d14f27e88b60fe13a327fdc78ac5beaac32720ef817874d1d7c337")
addappid(2646090, 0, "d30b1ea788761e576aa6aad5ff1cfc9b831cbd92bbb390592d509a57f7d57c9f")
