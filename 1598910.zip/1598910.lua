-- Lua provided by RyzenAPI 
-- Game: The Excrawlers
addappid(1598910)
addappid(1598911, 1, "b675d67ecd3b081cd6d8c4db84a905b04f2f0f281256cd173173c014e70dedbe")
