-- Lua provided by RyzenAPI
-- Game: Game: AppID 1973220

-- MAIN APPLICATION
addappid(1973220)
-- Game: addappid(1973220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973221, 1, "afbf7d7c53e97abdf22e1a0c3300f1ae4135770cd219f0ec2703cc0e97a224f0")
