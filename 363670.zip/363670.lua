-- Lua provided by RyzenAPI
-- Game: 363670

-- MAIN APPLICATION
addappid(363670)
-- Game: addappid(363670)

-- MAIN APP DEPOTS / PACKAGES
addappid(363671, 1, "23b3ea817043e13d77dac15cbff3106d87e00d1402af18084853c63b6feea5e0")
