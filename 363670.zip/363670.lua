-- Lua provided by RyzenAPI 
-- Game: AppID 363670
addappid(363670)
addappid(363671, 1, "23b3ea817043e13d77dac15cbff3106d87e00d1402af18084853c63b6feea5e0")
