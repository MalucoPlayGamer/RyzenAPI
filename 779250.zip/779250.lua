-- Lua provided by RyzenAPI
-- Game: 779250

-- MAIN APPLICATION
addappid(779250)
-- Game: addappid(779250)

-- MAIN APP DEPOTS / PACKAGES
addappid(779251, 1, "532831d27fb7fd0f0a72c9dbaa300d0cd9017ffee6ebe173975a3f30d44e6588")
