-- Lua provided by RyzenAPI
-- Game: Puff Town

-- MAIN APPLICATION
addappid(1742840)
-- Game: addappid(1742840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742841, 1, "4ced2e4c98b409cbf1ae9de01bdd0f133da23761013a2563514422e922ec4e9d")
addappid(1758610, 0, "d7cf06c2ff55b20cb32004e455a27ffcfe7d9d55cb7a07780cbe6ef049bd113c")
