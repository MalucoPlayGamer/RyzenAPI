-- Lua provided by RyzenAPI
-- Game: Game: AevumCore

-- MAIN APPLICATION
addappid(2163710)
-- Game: addappid(2163710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163711, 1, "fc732056737c03b8cc2f21640398778ea86304fead485e190a3213da1b678aa0")
