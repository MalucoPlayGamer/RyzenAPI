-- Lua provided by RyzenAPI 
-- Game: AevumCore
addappid(2163710)
addappid(2163711, 1, "fc732056737c03b8cc2f21640398778ea86304fead485e190a3213da1b678aa0")
