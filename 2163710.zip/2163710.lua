-- Lua provided by RyzenAPI
-- Game: AevumCore

-- MAIN APPLICATION
addappid(2163710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163711, 1, "fc732056737c03b8cc2f21640398778ea86304fead485e190a3213da1b678aa0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
