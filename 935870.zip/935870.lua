-- Lua provided by RyzenAPI
-- Game: addappid(935870)

-- MAIN APPLICATION
addappid(935870)

-- MAIN APP DEPOTS / PACKAGES
addappid(935871, 1, "e0308eafb0d39f3d5a2387d80ae4592380d352abaddfdd6187d6ba2db7b38244")
