-- Lua provided by SkyAPI 
-- Game: AppID 1120970
addappid(1120970)
addappid(1120971, 1, "d549519eccd4a3895d69c942013c4a54493fcb38b27e9ae29b4b7a54b7a45007")
