-- Lua provided by RyzenAPI
-- Game: Game: AppID 2101080

-- MAIN APPLICATION
addappid(2101080)
-- Game: addappid(2101080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101081, 1, "f1235156e862faa9d5c622be18302a045aaeb38ad146af17c083d2369b0f54ed")
addappid(2101082, 1, "2b8f44ad06a9b7f0219f8642b8627d30df9731cc419989d25d74e3cc7bee1739")
