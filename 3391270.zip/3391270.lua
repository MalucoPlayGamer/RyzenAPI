-- Lua provided by RyzenAPI
-- Game: Nayla's Fable: Lust & Rust

-- MAIN APPLICATION
addappid(3391270)
-- Game: addappid(3391270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391271, 1, "193292299e0c0823b5baf12a68108ed69fc597b49f4f6c91549f195210b466ba")
