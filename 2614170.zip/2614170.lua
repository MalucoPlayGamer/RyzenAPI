-- Lua provided by RyzenAPI
-- Game: addappid(2614170)

-- MAIN APPLICATION
addappid(2614170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614170,0,"8d8ca53755acc0ba6080c87a7da745cb112a3d3e95fba51834793fde9191ab47")
