-- Lua provided by RyzenAPI
-- Game: AppID 2348100

-- MAIN APPLICATION
addappid(2348100)
-- Game: addappid(2348100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348101, 1, "5a5cf73bad806bc262c4fc563ce5c0afe3b03e2ded2c4f6b6393ee9a67e44c66")
