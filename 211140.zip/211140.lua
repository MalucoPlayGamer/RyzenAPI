-- Lua provided by RyzenAPI
-- Game: 真・三國無雙６ with 猛將傳

-- MAIN APPLICATION
addappid(211140)

-- MAIN APP DEPOTS / PACKAGES
addappid(211141, 1, "3305adcbcedcba730b30bc24d26418579c36bc6d3c260a4d78a67bef6acab715")
