-- Lua provided by RyzenAPI
-- Game: Nation War:Chronicles Demo

-- MAIN APPLICATION
addappid(1599140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599141, 1, "722fd0498962b94ce0e00cc755437d29128d8f2b8e6965c2981f1fdbddf2ec9d")

