-- Lua provided by RyzenAPI
-- Game: Game: Astral Traveler

-- MAIN APPLICATION
addappid(618630)
-- Game: addappid(618630)

-- MAIN APP DEPOTS / PACKAGES
addappid(618631, 1, "6ed0f6052d4db7daab5015586eaf151633caf2e1a1aea83312531965e131b0e9")
addappid(618632, 1, "8a10b79acc8260eb21519e0c63bf751042bb77a2f9a694c162c2d6165ef2619b")
addappid(618633, 1, "3d6bc0dd4b53800a22acbd9f8b3427f84b3a904fb4da42a860c1fc103d81f162")
