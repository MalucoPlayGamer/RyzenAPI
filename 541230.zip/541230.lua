-- Lua provided by RyzenAPI
-- Game: Game: Alien Shooter TD

-- MAIN APPLICATION
addappid(541230)
-- Game: addappid(541230)

-- MAIN APP DEPOTS / PACKAGES
addappid(541231, 1, "e43c1d3b525340705f07a0fc949231bc9053437e3088805ccdeb992bc260ed63")
addappid(541232, 1, "4433e98adfe23f7323de63ab59d89d659d7a70974b2d3473c53baf6d3764b522")
addappid(541233, 1, "fb51caa177b06864c251c7f818ad41ef31020215236e6abedeece80f3ac45f0f")
