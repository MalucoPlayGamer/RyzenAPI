-- Lua provided by RyzenAPI 
-- Game: Dreadhunter Soundtrack
addappid(2616330)
addappid(2616331, 1, "4c957fd3d680ee94f7df3d044513c346034b843fa4126c87669fa8dc7ddd1a02")
addappid(2616332, 1, "0a00f68bd9c35664b24b87d87181e9b662028d0ea77a56d7a671158b8f44728e")
