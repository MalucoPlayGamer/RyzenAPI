-- Lua provided by RyzenAPI
-- Game: Game: Lawnmower Game Jigsaw

-- MAIN APPLICATION
addappid(3374450)
-- Game: addappid(3374450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374451, 1, "2a9e1ee15a0d34e27b60d4d04cfaf612595397121cbbebaebf6819429f3b11cc")
