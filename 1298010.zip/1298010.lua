-- Lua provided by RyzenAPI
-- Game: 1298010

-- MAIN APPLICATION
addappid(1298010)
-- Game: addappid(1298010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298011, 1, "fa041d563739737cec3564d92a9cf3ec8f1e396998f86e06419ae468f2f8a045")
