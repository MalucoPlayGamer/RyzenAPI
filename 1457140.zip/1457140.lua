-- Lua provided by RyzenAPI
-- Game: We're All Going To Die

-- MAIN APPLICATION
addappid(1457140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1457141, 1, "e9363c835450012b7b4e8efcea0098f835331e80c1d29ed6e46b9d61966a78a1")

