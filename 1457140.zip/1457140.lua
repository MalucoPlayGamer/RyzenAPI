-- Lua provided by RyzenAPI
-- Game: addappid(1457140)

-- MAIN APPLICATION
addappid(1457140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457141, 1, "e9363c835450012b7b4e8efcea0098f835331e80c1d29ed6e46b9d61966a78a1")
