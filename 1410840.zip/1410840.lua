-- Lua provided by SkyAPI 
-- Game: Crystal Call
addappid(1410840)
addappid(1410841, 1, "b7c4c6c0fb9ea90624434a7ccbb138967a173e4ce2df46ab7a3fc7493e26bd58")
