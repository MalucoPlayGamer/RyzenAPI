-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3246790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246790,0,"8b8603831abb43f64f73502caff6792bfce2476614890797f1c09eee65408c64")

