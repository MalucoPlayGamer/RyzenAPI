-- Lua provided by RyzenAPI
-- Game: 救済！粛清サークル ～The Purge Club～

-- MAIN APPLICATION
addappid(2911140)
-- Game: addappid(2911140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911141, 1, "88f2ec1a246792f4c6afde05c193e8139e2fe81b5f2f7681ee698ae1771afb51")
