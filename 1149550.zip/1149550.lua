-- Lua provided by RyzenAPI
-- Game: addappid(1149550)

-- MAIN APPLICATION
addappid(1149550)
addappid(1162490)
addappid(1168330)
addappid(1168440)
addappid(1168450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149551, 1, "0c7c1f95670d442af900ffa1d32e2de27867dfcaae0cdc54c10ab7a9649307d5")
addappid(1149552, 1, "9e37cd89abefcb3bc0883e3b864d438d799868677c3eb5b9b0fd8cc33c9fa4d4")
addappid(1149553, 1, "799a48b156b2e7dcedd8fecff2a6d4d16ce829b4ad69ecb188dd41444635aa23")
addappid(1149554, 1, "62b8cfbc138848db279a522eb86a712589f0dd21933c0541ca8f4f6668f12e4a")
