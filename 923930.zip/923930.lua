-- Lua provided by RyzenAPI
-- Game: Truth: Disorder II - Soundtrack

-- MAIN APPLICATION
addappid(923930)
-- Game: addappid(923930)

-- MAIN APP DEPOTS / PACKAGES
addappid(923930,0,"733f596a9b1856a07b67b04fd4e01c138175747d88c37dc79972e671386acc09")
