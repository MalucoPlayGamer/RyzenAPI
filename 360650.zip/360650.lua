-- Lua provided by RyzenAPI
-- Game: Game: 12 Labours of Hercules III: Girl Power

-- MAIN APPLICATION
addappid(360650)
-- Game: addappid(360650)

-- MAIN APP DEPOTS / PACKAGES
addappid(360651, 1, "45d49850421ded1f62adc6421726b3920f120192c8728498ad0980efbc8959eb")
addappid(360652, 1, "796a169c9689c0e91149c40e791a2d819210b3aed7d6ef38e880bd91cde3d36f")
addappid(360653, 1, "f3f24c7a64a24f4706110b745b682460e22c3dc648fd844b2517f8f6bd7d6fed")
