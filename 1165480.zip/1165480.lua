-- Lua provided by RyzenAPI
-- Game: 1165480

-- MAIN APPLICATION
addappid(1165480)
-- Game: addappid(1165480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165481, 1, "ea1699bc436a973034bfb8912319e3a3650eb1d418310c43e9cbb1bb0b18f207")
