-- Lua provided by SkyAPI 
-- Game: AppID 1165480
addappid(1165480)
addappid(1165481, 1, "ea1699bc436a973034bfb8912319e3a3650eb1d418310c43e9cbb1bb0b18f207")
