-- Lua provided by RyzenAPI
-- Game: Skyline Urban Story

-- MAIN APPLICATION
addappid(3185000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3185001, 1, "0a6e24d2f7a05f4d0d66cd6793c17a5e5584b643d459127675390823b830a673")
