-- Lua provided by RyzenAPI
-- Game: RebreatheR

-- MAIN APPLICATION
addappid(3821960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3821962,0,"5dcbe188d8a25e77732861ea6d33d0b3a87164e03e710878fe7dee218a46a7ff")

