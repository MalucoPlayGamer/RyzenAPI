-- Lua provided by RyzenAPI
-- Game: Doorways: Old Prototype

-- MAIN APPLICATION
addappid(525780)
addappid(538400)

-- MAIN APP DEPOTS / PACKAGES
addappid(525781, 1, "2450dcd841d0887e9f9bb972e7253e0efef5d45715de12ac9408a7dc60b4073b")
addappid(525782, 1, "8d70456ad87ed644e0883f3d113fc76999850e318e2e063fc2ea6f41ff81415a")
addappid(525783, 1, "d4ab7127c2c38635855059981fd18380d925f4e17d5b81939d4f22efe3baadac")
