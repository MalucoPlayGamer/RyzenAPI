-- Lua provided by RyzenAPI
-- Game: WWII Online

-- MAIN APPLICATION
addappid(251950)
-- Game: addappid(251950)

-- MAIN APP DEPOTS / PACKAGES
addappid(251959,0,"8d284ad2995be097cf7c6ba8987151435af2ea6ee7f2f39a81c947de8a107d23")
addappid(251960,0,"68baf9486c71dd3d0d7d0cac484f065fe8edace1bdcad3181d51d530b0f9e922")
