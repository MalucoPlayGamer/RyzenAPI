-- Lua provided by RyzenAPI
-- Game: WWII Online

-- MAIN APPLICATION
addappid(667290) -- World War II Online - STARTER
addappid(667291) -- World War II Online - PREMIUM
addappid(908460) -- Leadership Pack
addappid(908461) -- Paratrooper Pack
addappid(908470) -- Light AA Gun Pack
addappid(908471) -- Light AT Gun Pack
addappid(908472) -- Light Armor Pack
addappid(908473) -- Medium Armor Pack
addappid(908474) -- Combat Fighter Pack
addappid(936710) -- Support Infantry Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(251950, 1, "3dfa6cd4203438e89424330004053d7fe32e9fcaa9dc4274a35cc0670d0bb676") -- WWII Online
addappid(251959, 1, "8d284ad2995be097cf7c6ba8987151435af2ea6ee7f2f39a81c947de8a107d23") -- WWIIOL-BE-x64: Windows
addappid(251960, 1, "68baf9486c71dd3d0d7d0cac484f065fe8edace1bdcad3181d51d530b0f9e922") -- WWIIOL-BE-x64:OSX

