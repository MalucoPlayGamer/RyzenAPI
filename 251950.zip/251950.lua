-- Lua provided by RyzenAPI
-- Game: WWII Online

-- MAIN APPLICATION
addappid(251950)

-- MAIN APP DEPOTS / PACKAGES
addappid(251959,0,"8d284ad2995be097cf7c6ba8987151435af2ea6ee7f2f39a81c947de8a107d23")
addappid(251960,0,"68baf9486c71dd3d0d7d0cac484f065fe8edace1bdcad3181d51d530b0f9e922")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(908460)
addappid(908461)
addappid(908470)
addappid(908471)
addappid(908472)
addappid(908473)
addappid(908474)
addappid(936710)
