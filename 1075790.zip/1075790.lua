-- Lua provided by SkyAPI 
-- Game: AppID 1075790
addappid(1075790)
addappid(1075791, 1, "3580b09837798ddf703f3763ff4797821840b4c77cc4b9cd36d8a31303e6ef28")
addappid(1075792, 1, "f6a36cc57b32e63ba3775d1b7ff489f18a4b0e5aaa7a7927ec8e0f161f1f63cf")
