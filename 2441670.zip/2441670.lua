-- Lua provided by SkyAPI 
-- Game: Carnival in the hut
addappid(2441670)
addappid(2441671, 1, "a5f4014e09a97d0d90fd08da420add21c422315c2b3107a7d01e4b2aeaebdb41")
