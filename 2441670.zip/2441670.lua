-- Lua provided by RyzenAPI
-- Game: Game: Carnival in the hut

-- MAIN APPLICATION
addappid(2441670)
-- Game: addappid(2441670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441671, 1, "a5f4014e09a97d0d90fd08da420add21c422315c2b3107a7d01e4b2aeaebdb41")
