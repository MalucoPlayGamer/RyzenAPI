-- Lua provided by RyzenAPI
-- Game: Echoes of Creation: Origin

-- MAIN APPLICATION
addappid(4685890)
