-- Lua provided by RyzenAPI
-- Game: Hexen Hegemony

-- MAIN APPLICATION
addappid(940630)

-- MAIN APP DEPOTS / PACKAGES
addappid(940631, 1, "b14de51b356e57e04d43140d2caad67a01e4cf06fdfd9773c2786116fe59bc5a")

