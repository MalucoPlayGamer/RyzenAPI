-- Lua provided by RyzenAPI
-- Game: Hexen Hegemony

-- MAIN APPLICATION
addappid(940630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(940631, 1, "b14de51b356e57e04d43140d2caad67a01e4cf06fdfd9773c2786116fe59bc5a")

