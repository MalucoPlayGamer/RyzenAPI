-- Lua provided by RyzenAPI
-- Game: addappid(1957170)

-- MAIN APPLICATION
addappid(1957170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957171, 1, "cafa789f9aa64180941f34470c6512b08b71ef4b6546cc064ec8dc6ef647e1d5")
