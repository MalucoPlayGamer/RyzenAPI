-- Lua provided by RyzenAPI
-- Game: The Unsettled

-- MAIN APPLICATION
addappid(1957170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1957171, 1, "cafa789f9aa64180941f34470c6512b08b71ef4b6546cc064ec8dc6ef647e1d5")

