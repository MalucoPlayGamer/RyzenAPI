-- Lua provided by RyzenAPI
-- Game: In Stars And Time

-- MAIN APPLICATION
addappid(1677310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677311, 1, "5c168975657d2ce4b6970aabbee571b7c0a4d43d48184092896c8fbbb4bd8d4f")

