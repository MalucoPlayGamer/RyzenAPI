-- Lua provided by RyzenAPI
-- Game: Fishing Grind

-- MAIN APPLICATION
addappid(3019850)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3337590)
