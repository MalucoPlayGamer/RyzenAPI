-- Lua provided by RyzenAPI
-- Game: Fishing Grind

-- MAIN APPLICATION
addappid(3019850)
addappid(3337590)

