-- Lua provided by RyzenAPI
-- Game: Fishing Grind

-- MAIN APPLICATION
addappid(3019850)
