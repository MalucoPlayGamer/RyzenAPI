-- Lua provided by RyzenAPI
-- Game: MUZY

-- MAIN APPLICATION
addappid(2742150)
-- Game: addappid(2742150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742151, 1, "8f47f1f59975ce9aa78c839a85df3b7a6a144dbaa2a45f6cdb7a28c7e1a156f4")
