-- Lua provided by RyzenAPI
-- Game: A.D.M(Angels,Demons And Men)

-- MAIN APPLICATION
addappid(909170)
-- Game: addappid(909170)

-- MAIN APP DEPOTS / PACKAGES
addappid(909171, 1, "2a3edd0e2c5ae9487eefb1c61b632cdefcf7a7218ab812aabed6a2139529ae02")
