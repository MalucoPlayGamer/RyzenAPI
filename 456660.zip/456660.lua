-- Lua provided by RyzenAPI
-- Game: 456660

-- MAIN APPLICATION
addappid(456660)
-- Game: addappid(456660)

-- MAIN APP DEPOTS / PACKAGES
addappid(456661, 1, "2be369ea8abe218adfd0baa9ab9a91c608def82f364025447b479cc2e583efaa")
