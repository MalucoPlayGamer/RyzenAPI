-- Lua provided by RyzenAPI
-- Game: Game: SCP: Descent

-- MAIN APPLICATION
addappid(2757220)
-- Game: addappid(2757220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757221, 1, "105fc32f9a7adc217b0bfc26aafc55b8e8748ead192dbe480ff5d5e42b645fb5")
