-- Lua provided by RyzenAPI
-- Game: SCP: Descent

-- MAIN APPLICATION
addappid(2757220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757221, 1, "105fc32f9a7adc217b0bfc26aafc55b8e8748ead192dbe480ff5d5e42b645fb5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
