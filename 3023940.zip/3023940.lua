-- Lua provided by RyzenAPI
-- Game: Drill Core Demo

-- MAIN APPLICATION
addappid(3023940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023941, 1, "ced5f4563b2417eed94dcd8f33beb8a4571aa048b52502e30671723913576eff")
