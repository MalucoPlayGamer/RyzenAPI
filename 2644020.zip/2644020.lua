-- Lua provided by RyzenAPI
-- Game: The End Grows

-- MAIN APPLICATION
addappid(2644020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644021,0,"ceeb740e54d71843505b6e9629a04987b379addedbe44956befb5968d7cc90ca")

