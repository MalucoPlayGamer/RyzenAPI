-- Lua provided by SkyAPI 
-- Game: Squally
addappid(770200)
addappid(770201, 1, "1de349259456666c2f49c174976d08a7afe3a0ff94cb59c83ccfaa9c2e31c0a3")
addappid(770202, 1, "51a0fc3e8ee9023b4a78460e47db7ba0e85ac0e31265d17da3c1da79f813895e")
addappid(770203, 1, "b23fbd8e9f097baa96c17a4ea76f44674ef45be367ef72564f8e201b81e147b4")
