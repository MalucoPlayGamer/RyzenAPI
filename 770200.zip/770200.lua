-- Lua provided by RyzenAPI
-- Game: Squally

-- MAIN APPLICATION
addappid(770200)

-- MAIN APP DEPOTS / PACKAGES
addappid(770201, 1, "1de349259456666c2f49c174976d08a7afe3a0ff94cb59c83ccfaa9c2e31c0a3")
addappid(770202, 1, "51a0fc3e8ee9023b4a78460e47db7ba0e85ac0e31265d17da3c1da79f813895e")
addappid(770203, 1, "b23fbd8e9f097baa96c17a4ea76f44674ef45be367ef72564f8e201b81e147b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
