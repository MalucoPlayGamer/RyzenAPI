-- Lua provided by RyzenAPI
-- Game: 636470

-- MAIN APPLICATION
addappid(636470)
-- Game: addappid(636470)

-- MAIN APP DEPOTS / PACKAGES
addappid(636471, 1, "6bac78d157ddee2ef81c24221046c240ef33026d815ec9d6890d7c01795e65fc")
