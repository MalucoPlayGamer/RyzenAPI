-- Lua provided by RyzenAPI
-- Game: Tungulus

-- MAIN APPLICATION
addappid(636470)

-- MAIN APP DEPOTS / PACKAGES
addappid(636471, 1, "6bac78d157ddee2ef81c24221046c240ef33026d815ec9d6890d7c01795e65fc")
