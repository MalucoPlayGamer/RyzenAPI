-- Lua provided by RyzenAPI
-- Game: Dragon's Valkyrie: Wings of Fire

-- MAIN APPLICATION
addappid(3040870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3040871, 1, "4390c5dfd61fc66c95203c48e17e3c3b573d6d48ec43d0635d3c0943ce99b269")

