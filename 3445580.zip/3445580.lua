-- Lua provided by RyzenAPI
-- Game: Ambidextro

-- MAIN APPLICATION
addappid(3445580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445582,0,"86dc6cbfea22e6552e75979de093cfb92aeb610555d73ec461c55569975187e4")

