-- Lua provided by RyzenAPI
-- Game: Disciples II ROTE Scenario Editor

-- MAIN APPLICATION
addappid(1631)
addappid(1632)
addappid(1633)
addappid(1634)
addappid(1635)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")

