-- Lua provided by RyzenAPI
-- Game: Rent a Girl

-- MAIN APPLICATION
addappid(3781460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3781461, 1, "dcc7f7c7644a47c4f494aa946f9aa1c2f6a5543a35b027199f1a96cda0b4d206")
