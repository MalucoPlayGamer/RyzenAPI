-- 5009220's Lua and Manifest Created by Hubcap Manifest
-- Eclipsia
-- Created: August 21, 2026 at 22:09:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5009220) -- Eclipsia
-- MAIN APP DEPOTS
addappid(5009221, 1, "405491b42aacc6690214955413f94fdf55f4ffaa117523afb1e243cc3ba6be33") -- Depot 5009221
setManifestid(5009221, "107323815940195596", 451702552)