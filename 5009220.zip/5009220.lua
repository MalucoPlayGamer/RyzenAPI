-- Lua provided by RyzenAPI
-- Game: Eclipsia

-- MAIN APPLICATION
addappid(5009220) -- Eclipsia

-- MAIN APP DEPOTS / PACKAGES
addappid(5009221, 1, "405491b42aacc6690214955413f94fdf55f4ffaa117523afb1e243cc3ba6be33") -- Depot 5009221

