-- Lua provided by RyzenAPI
-- Game: Lots of Balls

-- MAIN APPLICATION
addappid(780760)

-- MAIN APP DEPOTS / PACKAGES
addappid(780761, 1, "05ce236b13dc8347e0396d62cfd988c246d9ecaddf2ce40f02af0467fdfcc125")
