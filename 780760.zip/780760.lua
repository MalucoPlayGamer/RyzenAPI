-- Lua provided by RyzenAPI
-- Game: 780760

-- MAIN APPLICATION
addappid(780760)
-- Game: addappid(780760)

-- MAIN APP DEPOTS / PACKAGES
addappid(780761, 1, "05ce236b13dc8347e0396d62cfd988c246d9ecaddf2ce40f02af0467fdfcc125")
