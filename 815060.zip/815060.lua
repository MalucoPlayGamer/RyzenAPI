-- Lua provided by RyzenAPI
-- Game: addappid(815060)

-- MAIN APPLICATION
addappid(622772)
addappid(622773)
addappid(622774)
addappid(815060)
addappid(815061)
addappid(815062)
addappid(815063)
addappid(815064)

-- MAIN APP DEPOTS / PACKAGES
addappid(622771,0,"8ec62138bae6eb834b227803d98fd192391100d5455f32bd360a90594215dfce")
