-- Lua provided by RyzenAPI
-- Game: Japanese Rail Sim: Operating the MEITETSU Line

-- MAIN APPLICATION
addappid(2281540)
addappid(3130250)
addappid(3130290)
-- Game: addappid(2281540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281541, 1, "9da978420320c4e0aabdbbda4dc04786ede196b4beca90f8c0d390e20a5d0d9b")
