-- Lua provided by RyzenAPI
-- Game: addappid(3014700)

-- MAIN APPLICATION
addappid(3014700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014701, 1, "dc5b6d8b94f9778f7f2d4107c9dcdb2a6d180bf249b8b6c8e9b4e70ed441a98c")
