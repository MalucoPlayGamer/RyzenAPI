-- Lua provided by RyzenAPI 
-- Game: iota
addappid(1273430)
addappid(1273431, 1, "f9d112ea8fcf52da7327d4d7b89ab34d71c7cf21cd2f635cc6484418aff39614")
addappid(1273434, 1, "09dd0799dbecd16daa0c0707ccdbcb983965aa1b23f647e7cf77bd4890d71bd0")
