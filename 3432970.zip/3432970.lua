-- Lua provided by RyzenAPI
-- Game: addappid(3432970)

-- MAIN APPLICATION
addappid(3432970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432971, 1, "acba842da42b42977676788e66c7e7f535f986c7799cdf3fad10e787ea413351")
