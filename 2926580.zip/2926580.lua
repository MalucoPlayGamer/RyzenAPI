-- Lua provided by RyzenAPI
-- Game: addappid(2926580)

-- MAIN APPLICATION
addappid(2926580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926581, 1, "179826323b4a95a7f52e9cadd6aa12b1e4a1e4a194882e17e895a9576a5e21ab")
