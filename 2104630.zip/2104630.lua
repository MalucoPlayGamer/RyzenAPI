-- Lua provided by RyzenAPI
-- Game: Game: AppID 2104630

-- MAIN APPLICATION
addappid(2104630)
-- Game: addappid(2104630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104631, 1, "9965507a70099e523a5ad952ba732e3dc593fb279b8fb39bf08ab479e9b505a8")
