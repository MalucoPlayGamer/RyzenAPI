-- Lua provided by RyzenAPI
-- Game: AppID 450500

-- MAIN APPLICATION
addappid(450500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(450501, 1, "e85a8fc87371c3e2ee1ecfc78626109264decfe2d260675fa02aa86d1747466d")
addappid(532730, 0, "0daec95f073e125baec0ef69c08877c1d30705cc422d6d7a565e43a5a29b7601")

