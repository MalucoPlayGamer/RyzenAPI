-- Lua provided by RyzenAPI
-- Game: Beat Saber: Billie Eilish - 'bellyache'

-- MAIN APPLICATION
addappid(1753522)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753522,0,"84e217107cdbe276e54b30ec68704116b7c42ea904e312c4f66cba2b64309d79")

