-- Lua provided by SkyAPI 
-- Game: AppID 2116890
addappid(2116890)
addappid(2116891, 1, "794909f81b9a83f1bdbe285d30c799cec070b26e9425dd9a926baf99cc8eedda")
addappid(2119790, 0, "147c38ec5231aab914292e839c79a4de2e73445852890ba465ae5f029b867fdf")
