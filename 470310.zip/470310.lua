-- Lua provided by RyzenAPI
-- Game: TROUBLESHOOTER: Abandoned Children

-- MAIN APPLICATION
addappid(470310)
addappid(2168550)
addappid(2168560)
addappid(2168561)
addappid(2168562)
addappid(2168563)
addappid(2168564)
addappid(2168565)
addappid(2168566)
addappid(2168567)
addappid(2168568)
addappid(2168580)
addappid(2168581)
addappid(2168582)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(470311, 1, "71496290fe8b1b26d4f05f685a814ae2aca733398ad54ff24c2624593b50371a")
addappid(470312, 1, "62bb49afb9a7bbb8eb0d96cba39693240c0028eb8fc2ffa6ebcc2368c0438318")
addappid(470313, 1, "9e8bebc9f7a95adfcc0192c0c430c945e96fe36b89e347ba13d086eac24052bc")
addappid(470315, 1, "97ab2405ed1a1ea81c0e96b64d4b9e45c419f81fecb54a2ba64a0149557ced1a")
addappid(470316, 1, "0e87b370ab085166221de1920178db672ad95e9b96d2b67270221aea0eae8237")
addappid(470317, 1, "6dd0aaa76393b3fa09d1cf22d6a270cdff2ab19bd125ef1e59747a0707788d15")
addappid(1345800, 0, "3d5d8e75bc2968cc1217348d8c698365f91ac84460c277c808f16ce7bb6796bb")
addappid(1856370, 0, "8340bd31c2a4a3a61faae44d8a85086ada41fe3b0fa51a4cb898f66989d6f768")
addappid(2670390, 0, "3962c1f476e9c883cdad4d5d98dd86f9cda93a2fee6cd818a6e0abec923ada9a")

