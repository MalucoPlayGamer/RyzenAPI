-- Lua provided by RyzenAPI
-- Game: Department of Gravity Management Playtest

-- MAIN APPLICATION
addappid(3542990)
-- Game: addappid(3542990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3542991, 1, "2653890d1f9c9de2f58b135727d9577e48a75079b14be7d255c981be70b414ad")
