-- Lua provided by RyzenAPI
-- Game: Just Another Night Shift

-- MAIN APPLICATION
addappid(2331130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331131, 1, "0c9747763a3a096f6bb8efe4f2bb686027090839ddcd8f1e41fa0a02b38a2661")
