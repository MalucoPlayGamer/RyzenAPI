-- Lua provided by RyzenAPI
-- Game: Tower Ball - Incremental Tower Defense

-- MAIN APPLICATION
addappid(1597220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597221, 1, "c13223c9b3d75ab6c11c36abbdc4495031f05be447402c96ad10cf1c337ecee8")
