-- Lua provided by RyzenAPI
-- Game: Rogue Blight

-- MAIN APPLICATION
addappid(4970460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890310, 1, "fec6329a4551ba8977b9a883a14bc4a8563c8e56b29cad33c64f097efa043ad9") -- Rogue Blight
addappid(1890311, 1, "ff911c64670bcf0f0bf73b1e6743d0a2303c715246dd66c77668f23b0a22f38a") -- Depot 1890311
addappid(1890312, 1, "56d028270ee98cbbcb473f555c5b1b8de4550c673ec1729296b79e26e711cd62") -- Depot 1890312
addappid(1890313, 1, "5a035b260ae2db5bb409672b0ee24b260bdcd2742f23b024dec7721d12e43095") -- Depot 1890313
addappid(4970460, 1, "768ca99a50b867c8857ddc88973b2d7b36cf504808f9229d8f54f639f01f9d73") -- Rogue Blight - Digital Artbook - Depot 4970460

