-- Lua provided by RyzenAPI
-- Game: 1958860

-- MAIN APPLICATION
addappid(1958860)
-- Game: addappid(1958860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958861, 1, "064ba895cb0c5bcc7ac8dff367b537c4912a1f426dfec2aa8f401ff915068c58")
