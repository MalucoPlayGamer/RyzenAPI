-- Lua provided by RyzenAPI 
-- Game: AppID 1907570
addappid(1907570)
addappid(1907571, 1, "239e5e867f7e51f2d76e3db12ea154ff607bfee55ffe5089b9374b69874112d0")
