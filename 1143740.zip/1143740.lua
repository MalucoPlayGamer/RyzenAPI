-- Lua provided by RyzenAPI 
-- Game: AppID 1143740
addappid(1143740)
addappid(1143741, 1, "d18f1deea4e335dc0ec66b6343d5680c4295dd26ea5596bdca3f9846f50d6271")
addappid(1143742, 1, "e049497ee969eda420d7f4efae3477e3920e521d71b8b56210375a92341a20d9")
