-- Lua provided by RyzenAPI
-- Game: 2642820

-- MAIN APPLICATION
addappid(2642820)
-- Game: addappid(2642820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642821, 1, "c4a8b7f6b8019817b6ce6fcb86624bf6ea1d976cfeac490b1f17c6f544af011d")
