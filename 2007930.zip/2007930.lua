-- Lua provided by RyzenAPI
-- Game: Fallen Bride Mege

-- MAIN APPLICATION
addappid(2007930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2007932,0,"381629f0048ef4e5324691dc8b4ea1dff788ec0341310fa055edbbf7491702c2")
addappid(2007933,0,"5c18d94a3c5b8bdfbd9c3858617bf2a947ce131d2a1376e24839fe6a8ecf87dc")
