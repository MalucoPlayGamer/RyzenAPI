-- Lua provided by RyzenAPI
-- Game: 易经·占卜

-- MAIN APPLICATION
addappid(2798400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2798401, 1, "2c6389831dbde6d94684ca061d3b32e65abc7c4efa415630dd9e75dc1e25b0fb")
