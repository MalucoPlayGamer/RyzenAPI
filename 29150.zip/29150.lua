-- Lua provided by SkyAPI 
-- Game: Mightier
addappid(29150)
addappid(29151, 1, "940ba2faedd4b136344d8081fd8d3895a9b16eb0bbd90b7da5f2f0c47c302e50")
