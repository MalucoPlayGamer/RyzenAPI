-- Lua provided by RyzenAPI
-- Game: 29150

-- MAIN APPLICATION
addappid(29150)
-- Game: addappid(29150)

-- MAIN APP DEPOTS / PACKAGES
addappid(29151, 1, "940ba2faedd4b136344d8081fd8d3895a9b16eb0bbd90b7da5f2f0c47c302e50")
