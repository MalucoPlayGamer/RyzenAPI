-- Lua provided by RyzenAPI
-- Game: Game: Native Isekai Defense: Prologue

-- MAIN APPLICATION
addappid(3114150)
-- Game: addappid(3114150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114151, 1, "751683d09ad419439e3fcf4cd7cb19c0de63c9025cd2b2b2b4a1c1b3148b2d2c")
