-- 4619420's Lua and Manifest Created by Hubcap Manifest
-- Slot Grind
-- Created: August 04, 2026 at 18:57:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4619420) -- Slot Grind
-- MAIN APP DEPOTS
addappid(4619422, 1, "71c7092180cdba66e32c059fe3d27eeb33933d4ebcbb50381a0702eed5719b07") -- Depot 4619422
setManifestid(4619422, "8104189849599277255", 135450212)
addappid(4619423, 1, "f7188c34bb961b1aa4eeaff8da2d7cf2f0db1b45ab191c1e548c5a52fd59c193") -- Depot 4619423
setManifestid(4619423, "5694500076570603857", 217479865)