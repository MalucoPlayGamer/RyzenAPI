-- Lua provided by RyzenAPI
-- Game: Slot Grind

-- MAIN APPLICATION
addappid(4619420) -- Slot Grind

-- MAIN APP DEPOTS / PACKAGES
addappid(4619422, 1, "71c7092180cdba66e32c059fe3d27eeb33933d4ebcbb50381a0702eed5719b07") -- Depot 4619422
addappid(4619423, 1, "f7188c34bb961b1aa4eeaff8da2d7cf2f0db1b45ab191c1e548c5a52fd59c193") -- Depot 4619423

