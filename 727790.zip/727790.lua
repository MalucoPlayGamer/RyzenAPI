-- Lua provided by RyzenAPI
-- Game: 727790

-- MAIN APPLICATION
addappid(727790)
-- Game: addappid(727790)

-- MAIN APP DEPOTS / PACKAGES
addappid(727791, 1, "23451052a2fd913e6c9818d84d9fc24f7ad335e08eaf1dad94efea7e5b9e1f13")
