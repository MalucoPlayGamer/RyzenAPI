-- Lua provided by SkyAPI 
-- Game: AppID 672230
addappid(672230)
addappid(672231, 1, "a85d8fb09295102ea9f8b4b05cf120f63d2a9a4be6c66a70c5aba8096ecdbefe")
