-- Lua provided by RyzenAPI
-- Game: Game: AppID 672230

-- MAIN APPLICATION
addappid(672230)
-- Game: addappid(672230)

-- MAIN APP DEPOTS / PACKAGES
addappid(672231, 1, "a85d8fb09295102ea9f8b4b05cf120f63d2a9a4be6c66a70c5aba8096ecdbefe")
