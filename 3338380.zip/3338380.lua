-- Lua provided by SkyAPI 
-- Game: The Cursed Moon ~The Girl Trapped in the Haunted House~
addappid(3338380)
addappid(3338381, 1, "4a2d86e772675dce237f66ebe8c00ff5cb1e8a7123c0a4bc627fac5e81e5564b")
addappid(3338382, 1, "e4cd045683080fb847465de12c9a3ac71e6b9052eb7c88d670f42485cccbbbec")
addappid(3338383, 1, "59621e91ff205124dcac9f106063b302a3e1438789cba491c75bd71b1099c407")
addappid(3338384, 1, "80251c68cf212735e33ac12be28578577b1de2c9234ac67c49a34adc0929fa78")
