-- Lua provided by RyzenAPI
-- Game: Game: Axe Ghost

-- MAIN APPLICATION
addappid(2712670)
-- Game: addappid(2712670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712671, 1, "20daa55583725d0ff619ab527eb9edb1aadd3a093cf52a51c8926db8b52e2146")
