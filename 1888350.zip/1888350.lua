-- Lua provided by RyzenAPI
-- Game: addappid(1888350)

-- MAIN APPLICATION
addappid(1888350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888350,0,"7a538b9f79ceb1d7b31d5bdba4d29076dcb7de6dd202a0b9eedb57706ad5f4ab")
