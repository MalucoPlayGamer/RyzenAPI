-- Lua provided by RyzenAPI
-- Game: The Lar

-- MAIN APPLICATION
addappid(1084570)
addappid(1107260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084571, 1, "b8bfe572cd31ff80b4ba74d90894d1e849e1809d12c578f3389c09ce40f7a6b6")
