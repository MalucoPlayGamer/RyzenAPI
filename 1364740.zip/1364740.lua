-- Lua provided by RyzenAPI
-- Game: 1364740

-- MAIN APPLICATION
addappid(1364740)
-- Game: addappid(1364740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364741, 1, "c4c12b68c7e2d595d5bb4be3c6011d50b87d45a982104be60dd508cdbcf89b2a")
