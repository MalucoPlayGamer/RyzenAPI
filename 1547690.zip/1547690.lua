-- Lua provided by RyzenAPI
-- Game: addappid(1547690)

-- MAIN APPLICATION
addappid(1547690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547690,0,"bb5713ee05bb3c9e3072f2a7440fde663a3af38e1598dd119007ddd6f876177d")
