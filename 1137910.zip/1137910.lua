-- Lua provided by RyzenAPI 
-- Game: AppID 1137910
addappid(1137910)
addappid(1137911, 1, "5900f8b4ed9f3447cc39f7ad144f381adb9e97e56c7ec55caabd3792f1d7c850")
