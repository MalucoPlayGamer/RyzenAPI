-- Lua provided by RyzenAPI
-- Game: Runes: The Forgotten Path

-- MAIN APPLICATION
addappid(457130)
addappid(970120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(457131, 1, "61e7f65e2d86fe0530ad43069346ce35673427481f61adadb3c227b8e291354d")

