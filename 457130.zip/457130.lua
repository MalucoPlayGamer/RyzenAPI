-- Lua provided by SkyAPI 
-- Game: Runes: The Forgotten Path
addappid(457130)
addappid(457131, 1, "61e7f65e2d86fe0530ad43069346ce35673427481f61adadb3c227b8e291354d")
addappid(970120)
