-- Lua provided by RyzenAPI
-- Game: Game: Runes: The Forgotten Path

-- MAIN APPLICATION
addappid(457130)
addappid(970120)
-- Game: addappid(457130)

-- MAIN APP DEPOTS / PACKAGES
addappid(457131, 1, "61e7f65e2d86fe0530ad43069346ce35673427481f61adadb3c227b8e291354d")
