-- Lua provided by SkyAPI 
-- Game: The Way of Life: DEFINITIVE EDITION
addappid(404960)
addappid(404961, 1, "148b2ae6f20ea4d67378e301846786254cdb85b269f5ffc83b27a1e923785708")
addappid(803240, 0, "b756c4ea063be7d9c6ae6dbf4aec1a4be25b5ff40017ddc650799f5d2e3087ff")
