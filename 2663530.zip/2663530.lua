-- Lua provided by RyzenAPI
-- Game: Game: POOLS

-- MAIN APPLICATION
addappid(2663530)
-- Game: addappid(2663530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663531, 1, "c4286bf964a6ae3ee6a54f2619f4222b3ec80a55a458d8281062b27d35afa8d0")
addappid(2663532, 1, "8ef4df38b64b5a5ffdb2b07e72c53ed51d3c21efc2ee13b523235da63974179d")
addappid(2663533, 1, "bc9994e3ea2a87aa8fac3693a4e3066a9e96a601b8e58f0586ea35a5b135819f")
