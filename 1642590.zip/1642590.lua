-- Lua provided by RyzenAPI
-- Game: 1642590

-- MAIN APPLICATION
addappid(1642590)
-- Game: addappid(1642590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642591, 1, "fa02f87c2b3218f64059dbde96ebcb42155f79ca1f37f47a762dd2f396ba15dc")
