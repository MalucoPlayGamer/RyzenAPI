-- Lua provided by RyzenAPI
-- Game: addappid(672650)

-- MAIN APPLICATION
addappid(672650)

-- MAIN APP DEPOTS / PACKAGES
addappid(672651, 1, "59dd8059bf26bcc788dcc58623b573cfcae399fe0b84d8ace4ae9933d67ade5b")
addappid(716690, 0, "a5a1b1e55f1c8a6fbaf3a7c2d2606d419c9661e85d49e282acb4ef653c75bc78")
addappid(716691, 0, "dccff691bc0a038956d2f4a287a71998efd6aca2f2efb3e179719f0c2177cac1")
addappid(1011640, 0, "10215199007b94e14cdad7bcc8632997b4dcbec164f112842cccdc7fc192e858")
