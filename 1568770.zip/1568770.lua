-- Lua provided by SkyAPI 
-- Game: Before We Leave Official Soundtrack
addappid(1568770)
addappid(1568771, 1, "ea95990c039be4c9c8d1bb9582a8cf19c3415389737a26550a66af74fc756c05")
addappid(1568772, 1, "689846a38db418cde1043c76406127432d6705e29cdafe0ee575418e001100ff")
