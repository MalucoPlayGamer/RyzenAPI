-- Lua provided by RyzenAPI
-- Game: Before We Leave Official Soundtrack

-- MAIN APPLICATION
addappid(1568770)
-- Game: addappid(1568770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568771, 1, "ea95990c039be4c9c8d1bb9582a8cf19c3415389737a26550a66af74fc756c05")
addappid(1568772, 1, "689846a38db418cde1043c76406127432d6705e29cdafe0ee575418e001100ff")
