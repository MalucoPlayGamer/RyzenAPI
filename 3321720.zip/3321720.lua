-- Lua provided by RyzenAPI
-- Game: Bestiary of the Mountains and Seas

-- MAIN APPLICATION
addappid(3321720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321721, 1, "dbb73e9e20c0162a5c94039c856a8f3f39d525e35c0895a1ee49d049aac10d51")

