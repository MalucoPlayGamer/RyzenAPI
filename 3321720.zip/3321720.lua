-- Lua provided by SkyAPI 
-- Game: Bestiary of the Mountains and Seas
addappid(3321720)
addappid(3321721, 1, "dbb73e9e20c0162a5c94039c856a8f3f39d525e35c0895a1ee49d049aac10d51")
