-- Lua provided by RyzenAPI
-- Game: addappid(2581950)

-- MAIN APPLICATION
addappid(2581950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581952,0,"8ed572ef0cd138022a5bec468f7e8b882ec28a56a821f5a26c0766ce76482926")
