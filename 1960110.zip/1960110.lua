-- Lua provided by RyzenAPI
-- Game: Silent Hope

-- MAIN APPLICATION
addappid(1960110)
addappid(2279950)
addappid(2285170)
addappid(2285171)
addappid(2285172)
addappid(2285173)
addappid(2285174)
addappid(2285175)
addappid(2285176)
addappid(2603660)
addappid(4682420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1960111, 1, "b947f010773890393ffbdc50519d6b487a787b0f78d078ad27864f71f1df3105")

