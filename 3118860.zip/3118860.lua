-- Lua provided by RyzenAPI
-- Game: Meat Lovers

-- MAIN APPLICATION
addappid(3118860) -- Meat Lovers

-- MAIN APP DEPOTS / PACKAGES
addappid(3118861, 1, "d775d19d02e253ea167832907c5cac589ff1cdb793c8f0c9a31c382efcf0c715") -- Depot 3118861
addappid(3118862, 1, "e8917dd98db55d486d9ad7fb1091207281a98727c64aa9649babd2f3cd1d72b5") -- Depot 3118862

