-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Mini Mixed Trivia 2

-- MAIN APPLICATION
addappid(706330)
-- Game: addappid(706330)

-- MAIN APP DEPOTS / PACKAGES
addappid(706331, 1, "d16e71436dc3093703050e92ac2382216dff6dd8ed2b9f6719a7c49c9bd82faf")
