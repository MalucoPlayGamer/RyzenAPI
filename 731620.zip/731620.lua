-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228986)
addappid(228987)
addappid(228990)
addappid(731620)
-- Game: addappid(731620)

-- MAIN APP DEPOTS / PACKAGES
addappid(731622,0,"fba3d27eb6314a1c4cbb357eb595f4174bbf31593a4e7b2345766f98e84d1447")
