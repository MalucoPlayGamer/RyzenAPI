-- Lua provided by RyzenAPI
-- Game: addappid(948740)

-- MAIN APPLICATION
addappid(948740)

-- MAIN APP DEPOTS / PACKAGES
addappid(948741, 1, "0209b9ec8a19f2f8db542209ad860ba1c936873eece3d2d62c23ff71213eee90")
addappid(1109030, 0, "b7aef045c7984a51f6a45ee0a570115afb1a2d186ef639b567412cf26297f716")
