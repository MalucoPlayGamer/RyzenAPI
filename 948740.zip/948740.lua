-- Lua provided by RyzenAPI
-- Game: AI: The Somnium Files

-- MAIN APPLICATION
addappid(948740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(948741, 1, "0209b9ec8a19f2f8db542209ad860ba1c936873eece3d2d62c23ff71213eee90")
addappid(1109030, 0, "b7aef045c7984a51f6a45ee0a570115afb1a2d186ef639b567412cf26297f716")

