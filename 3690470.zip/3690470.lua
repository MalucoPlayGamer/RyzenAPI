-- Lua provided by RyzenAPI
-- Game: 3690470

-- MAIN APPLICATION
addappid(3690470)
-- Game: addappid(3690470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690471, 1, "9eb7d1a3218bc9a9de989b1e42e971f8950e3af6c7aa40b61719fbe6569e222b")
