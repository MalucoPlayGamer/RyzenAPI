-- Lua provided by RyzenAPI
-- Game: Destiny of the World

-- MAIN APPLICATION
addappid(1264790)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1264791, 1, "a9c2b0e948936c11050401ed5408be66f18cd8158ed46f7543423656e4385d91")

