-- Lua provided by RyzenAPI
-- Game: Game: Destiny of the World

-- MAIN APPLICATION
addappid(1264790)
-- Game: addappid(1264790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264791, 1, "a9c2b0e948936c11050401ed5408be66f18cd8158ed46f7543423656e4385d91")
