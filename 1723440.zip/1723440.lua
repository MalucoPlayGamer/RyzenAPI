-- Lua provided by RyzenAPI
-- Game: Space X Collector

-- MAIN APPLICATION
addappid(1723440)
-- Game: addappid(1723440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723441, 1, "eeef9cdfda947d6c95f27e1abf28f3d11913b1e8958f8f061fe2c3fb03b300af")
