-- Lua provided by RyzenAPI
-- Game: Space X Collector

-- MAIN APPLICATION
addappid(1723440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1723441, 1, "eeef9cdfda947d6c95f27e1abf28f3d11913b1e8958f8f061fe2c3fb03b300af")

