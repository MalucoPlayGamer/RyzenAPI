-- Lua provided by SkyAPI 
-- Game: Space X Collector
addappid(1723440)
addappid(1723441, 1, "eeef9cdfda947d6c95f27e1abf28f3d11913b1e8958f8f061fe2c3fb03b300af")
