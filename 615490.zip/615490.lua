-- Lua provided by RyzenAPI
-- Game: I'm Awesome

-- MAIN APPLICATION
addappid(615490)

-- MAIN APP DEPOTS / PACKAGES
addappid(615491, 1, "8fef9f5b1ee421f3fedf5ea81f87b886ef79bac87ffc8615c35cb093d05b0651")

