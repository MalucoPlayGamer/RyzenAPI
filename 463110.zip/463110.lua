-- Lua provided by RyzenAPI
-- Game: Farnham Fables

-- MAIN APPLICATION
addappid(463110)
addappid(524360)
addappid(771780)
-- Game: addappid(463110)

-- MAIN APP DEPOTS / PACKAGES
addappid(463111, 1, "c2b3ee6354afc797bc791748aba58c24b49532b4f067b58632fa52ddd10581b9")
