-- Lua provided by RyzenAPI
-- Game: 1818800

-- MAIN APPLICATION
addappid(1818800)
-- Game: addappid(1818800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818801, 1, "ab2ec8f6fe1497fc32c43d21a8d1bfcb495ca0e3f7393b07cfa94095a771891a")
