-- Lua provided by RyzenAPI
-- Game: The Incredible Hulk: The Official Videogame

-- MAIN APPLICATION
addappid(10510)

-- MAIN APP DEPOTS / PACKAGES
addappid(10511, 1, "1ee8523ea6cccbb77331f1c4f4119d46c6cec6f04f55d8c06ae619f2aa60b1b6") -- the hulk content

