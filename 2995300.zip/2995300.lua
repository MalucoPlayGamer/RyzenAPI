-- Lua provided by RyzenAPI
-- Game: AppID 2995300

-- MAIN APPLICATION
addappid(2995300)
-- Game: addappid(2995300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2995301, 1, "232a8c4d324d28936258c5c0adff523d8035f82430e8bb2d9b0ab15b5715e521")
