-- Lua provided by RyzenAPI
-- Game: Virtual Race Car Engineer 2018

-- MAIN APPLICATION
addappid(728150)

-- MAIN APP DEPOTS / PACKAGES
addappid(728151,0,"2c1b4ee873462e431ebaba69d7715236ec50c262f7c6d23c3366d7ff9474170b")

