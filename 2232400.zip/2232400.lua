-- Lua provided by RyzenAPI
-- Game: Guncar Arena Demo

-- MAIN APPLICATION
addappid(2232400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232401, 1, "43a9d35ecac40620e90e08cd275d18ef95173857311746d46e1c352582e4960d")

