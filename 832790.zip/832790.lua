-- Lua provided by RyzenAPI
-- Game: Game: AppID 832790

-- MAIN APPLICATION
addappid(832790)
-- Game: addappid(832790)

-- MAIN APP DEPOTS / PACKAGES
addappid(832791, 1, "5c1917c0137ed5adfe2bcec1ecc21a4bdc5b4350ea61b57e62857bffd1de4161")
