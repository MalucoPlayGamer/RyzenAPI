-- Lua provided by RyzenAPI
-- Game: Touhou Hero of Ice Fairy Prologue - Supporter pack

-- MAIN APPLICATION
addappid(1852710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852710,0,"94097a91f29ea180a79e0cdadfb6a0f14955212ce7a8d96cd9729d838b55fe39")

