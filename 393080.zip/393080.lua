-- Lua provided by RyzenAPI
-- Game: 393080

-- MAIN APPLICATION
addappid(393080)
addappid(393103)
addappid(393104)
addappid(393105)
addappid(393106)
addappid(393107)
addappid(393108)
addappid(393109)
addappid(393110)
addappid(393111)
addappid(393112)
addappid(393113)
addappid(393114)
addappid(393115)
addappid(393116)
addappid(393117)
addappid(594970)
-- Game: addappid(393080)

-- MAIN APP DEPOTS / PACKAGES
addappid(393081, 1, "f53e66dd3c1efcb6f0c8f80eb82ed7b4c0038fe2627cf47433afe7bcb902abc7")
addappid(393082, 1, "d6d8b672150cf319317dfe2d925f8fb0dcb3c8c598089bd71aa13728011087bb")
