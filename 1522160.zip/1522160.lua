-- Lua provided by RyzenAPI
-- Game: Disney Epic Mickey: Rebrushed

-- MAIN APPLICATION
addappid(1522160)
addappid(2791920)
-- Game: addappid(1522160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522161, 1, "30d26b038623eaef752b3ad6c9d1bc8e9bdf859f7f802d5ca54923011edc369c")
