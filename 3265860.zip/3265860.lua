-- Lua provided by RyzenAPI
-- Game: 3265860

-- MAIN APPLICATION
addappid(3265860)
-- Game: addappid(3265860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265861, 1, "6fdcca79ff0715ad77882118085aee3d95416344ce11728212114befffe939b8")
