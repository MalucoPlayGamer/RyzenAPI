-- Lua provided by RyzenAPI
-- Game: addappid(435730)

-- MAIN APPLICATION
addappid(435730)

-- MAIN APP DEPOTS / PACKAGES
addappid(435731, 1, "a5d69ce3fb10b618d5bd6bc94e61b033defb29dbc629449c1779672372eccca4")
