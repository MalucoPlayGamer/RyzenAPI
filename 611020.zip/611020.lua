-- Lua provided by SkyAPI 
-- Game: AppID 611020
addappid(611020)
addappid(611021, 1, "11e16b8cf9129c6c2afe784eb9faac1e1503b66bac62e6624f6a6bdb5ebdeed2")
