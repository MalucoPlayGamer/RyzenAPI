-- Lua provided by RyzenAPI
-- Game: AppID 611020

-- MAIN APPLICATION
addappid(611020)

-- MAIN APP DEPOTS / PACKAGES
addappid(611021, 1, "11e16b8cf9129c6c2afe784eb9faac1e1503b66bac62e6624f6a6bdb5ebdeed2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
