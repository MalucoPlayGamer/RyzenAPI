-- Lua provided by RyzenAPI
-- Game: 537180

-- MAIN APPLICATION
addappid(537180)
-- Game: addappid(537180)

-- MAIN APP DEPOTS / PACKAGES
addappid(537181, 1, "edb79e05e2faf74003ab70eba4054912bdbffabf6d4394c16dfc1fab067ae9ef")
