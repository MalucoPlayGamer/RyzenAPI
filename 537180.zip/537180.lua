-- Lua provided by RyzenAPI
-- Game: Digimon Masters Online

-- MAIN APPLICATION
addappid(537180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(537181, 1, "edb79e05e2faf74003ab70eba4054912bdbffabf6d4394c16dfc1fab067ae9ef")

