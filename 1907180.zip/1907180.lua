-- Lua provided by RyzenAPI
-- Game: addappid(1907180)

-- MAIN APPLICATION
addappid(1907180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907181, 1, "1fe38db79dc592a0cb9ac47a3ce6b947973c5f3993133306914cc9a767727e55")
