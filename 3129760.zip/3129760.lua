-- Lua provided by RyzenAPI
-- Game: 101 Cats in Brazil

-- MAIN APPLICATION
addappid(3129760)
-- Game: addappid(3129760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129761, 1, "8dc2476a9b86b6fa6211181c9d0dc1d1a1f8613b9a92ea0dd59ae53e28e869d2")
