-- Lua provided by RyzenAPI
-- Game: Unlock the Feelings

-- MAIN APPLICATION
addappid(1961790)

