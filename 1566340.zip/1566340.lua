-- Lua provided by RyzenAPI
-- Game: Game: DARK AROUND YOU

-- MAIN APPLICATION
addappid(1566340)
-- Game: addappid(1566340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566341, 1, "c1520fb91a92f94d096563e1d936b1c13511c6edaf180a8cd913176c9f197d27")
