-- Lua provided by RyzenAPI
-- Game: S.U.M. - Slay Uncool Monsters

-- MAIN APPLICATION
addappid(1476430)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1537580)
addappid(1537581)
addappid(1537582)
addappid(1537583)
addappid(1537584)
addappid(1537585)
