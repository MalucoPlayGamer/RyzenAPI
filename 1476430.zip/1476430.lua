-- Lua provided by RyzenAPI
-- Game: S.U.M. - Slay Uncool Monsters

-- MAIN APPLICATION
addappid(1476430)

