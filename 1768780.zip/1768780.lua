-- Lua provided by RyzenAPI
-- Game: Game: Of Blades & Tails

-- MAIN APPLICATION
addappid(1768780)
-- Game: addappid(1768780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768781, 1, "758fa92fb93144ae7d6a9fec2854640b0b61b54587f51e3ba603fea5c2057252")
