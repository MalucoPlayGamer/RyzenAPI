-- Lua provided by SkyAPI 
-- Game: Goodbye Seoul (Demo)
addappid(2711590)
addappid(2711591, 1, "ced279ccca4625d5d82d4e5cc776cd93c06952b75b307ae079b8f4cd3b56884e")
