-- Lua provided by RyzenAPI
-- Game: addappid(2711590)

-- MAIN APPLICATION
addappid(2711590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711591, 1, "ced279ccca4625d5d82d4e5cc776cd93c06952b75b307ae079b8f4cd3b56884e")
