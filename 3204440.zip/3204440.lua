-- Lua provided by RyzenAPI
-- Game: The Cube of Love

-- MAIN APPLICATION
addappid(3204440)
-- Game: addappid(3204440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204441, 1, "c5fc5b163e97bfe88e7373c580c380407e4b6809e43ab7caac5ad8f13a57c8d6")
