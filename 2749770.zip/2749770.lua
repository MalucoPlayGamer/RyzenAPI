-- Lua provided by RyzenAPI
-- Game: Galaxy Burger

-- MAIN APPLICATION
addappid(2749770)
-- Game: addappid(2749770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2749771, 1, "00ad47a7b1372cb701d53a074e95ec1450ce676f7bc5f32ad4b155e900b06923")
