-- Lua provided by RyzenAPI
-- Game: addappid(1986780)

-- MAIN APPLICATION
addappid(1986780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986781, 1, "9e71806c4d29fcdf993ec93630e46327f0e9ee2623e8164b185ad14cf7ed1f1f")
