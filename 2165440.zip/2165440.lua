-- Lua provided by SkyAPI 
-- Game: MeiQi 2020
addappid(2165440)
addappid(2165441, 1, "e147006b4af3669c4c77cfeee90c386a99f8dbc362c31432ec8394991ef71b8e")
