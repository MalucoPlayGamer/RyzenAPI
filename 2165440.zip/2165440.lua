-- Lua provided by RyzenAPI
-- Game: addappid(2165440)

-- MAIN APPLICATION
addappid(2165440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165441, 1, "e147006b4af3669c4c77cfeee90c386a99f8dbc362c31432ec8394991ef71b8e")
