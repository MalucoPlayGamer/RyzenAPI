-- Lua provided by RyzenAPI
-- Game: 337940

-- MAIN APPLICATION
addappid(337940)
-- Game: addappid(337940)

-- MAIN APP DEPOTS / PACKAGES
addappid(337941, 1, "193f0be4688fbb6d560ccb7f383e9efdfb99fa543de94b52d5038c366f5fc4d6")
