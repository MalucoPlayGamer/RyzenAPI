-- Lua provided by SkyAPI 
-- Game: X-note
addappid(337940)
addappid(337941, 1, "193f0be4688fbb6d560ccb7f383e9efdfb99fa543de94b52d5038c366f5fc4d6")
