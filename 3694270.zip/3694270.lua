-- Lua provided by RyzenAPI
-- Game: Chasing Her Light

-- MAIN APPLICATION
addappid(3694270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3694271,0,"be8d305428162f39b6c34e339ee000424ab1984bd317afea53fa29595d833fc7")

