-- Lua provided by RyzenAPI
-- Game: Game: The Episodic

-- MAIN APPLICATION
addappid(1427150)
-- Game: addappid(1427150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427151, 1, "6fe89212236b9dc46f5c95667e0fc175e60e8d40316ab922f03570e80f8e181f")
