-- Lua provided by RyzenAPI
-- Game: The Episodic

-- MAIN APPLICATION
addappid(1427150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427151, 1, "6fe89212236b9dc46f5c95667e0fc175e60e8d40316ab922f03570e80f8e181f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
