-- Lua provided by RyzenAPI
-- Game: Shelter 69

-- MAIN APPLICATION
addappid(1905950)
addappid(3140440)
addappid(3140450)
addappid(3140460)
addappid(3140470)
addappid(3140490)
addappid(3140500)
addappid(3140510)
addappid(3140520)
addappid(3140530)
addappid(3335110)
addappid(3402590)
addappid(3804220)
addappid(3804240)
addappid(4521990)
addappid(4522000)
addappid(4522010)
addappid(4522020)
addappid(4522030)
addappid(4522050)
addappid(4522060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905951,0,"120a75b8b2d2194d118156abfbb95b0ff600e423817a6d015297c86acfc666c5")

