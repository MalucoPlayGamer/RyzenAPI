-- Lua provided by RyzenAPI
-- Game: 1905950

-- MAIN APPLICATION
addappid(1905950)
-- Game: addappid(1905950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905951, 1, "120a75b8b2d2194d118156abfbb95b0ff600e423817a6d015297c86acfc666c5")
