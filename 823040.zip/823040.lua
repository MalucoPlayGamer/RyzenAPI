-- Lua provided by SkyAPI 
-- Game: Griefer
addappid(823040)
addappid(823041, 1, "ee50590fe237ae26191cd5bc73cd601ce586c0b0481e7221387e21d34fc3c102")
