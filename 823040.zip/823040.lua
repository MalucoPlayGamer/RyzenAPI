-- Lua provided by RyzenAPI
-- Game: Griefer

-- MAIN APPLICATION
addappid(823040)

-- MAIN APP DEPOTS / PACKAGES
addappid(823041, 1, "ee50590fe237ae26191cd5bc73cd601ce586c0b0481e7221387e21d34fc3c102")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
