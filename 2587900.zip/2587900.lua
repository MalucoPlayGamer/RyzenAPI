-- Lua provided by RyzenAPI
-- Game: addappid(2587900)

-- MAIN APPLICATION
addappid(2587900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587901, 1, "97418d07add76c2f103889dd0b26c1371af4b7e61ad118051ceb0f81463b9438")
