-- Lua provided by RyzenAPI
-- Game: 38120

-- MAIN APPLICATION
addappid(38120)
-- Game: addappid(38120)

-- MAIN APP DEPOTS / PACKAGES
addappid(38121, 1, "2878027eef568201f9a55e287043fcf3552a83dd3abad66d0ab83091ecb420f9")
