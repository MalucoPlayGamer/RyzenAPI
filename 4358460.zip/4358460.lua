-- Lua provided by RyzenAPI
-- Game: Card Homestead

-- MAIN APPLICATION
addappid(4358460) -- Card Homestead

-- MAIN APP DEPOTS / PACKAGES
addappid(4358461, 1, "a418ce1cddb623fe5ab91a5efd008777e67127b3059ea063f65b335d15e52b23") -- Depot 4358461

