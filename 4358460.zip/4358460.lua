-- 4358460's Lua and Manifest Created by Hubcap Manifest
-- Card Homestead
-- Created: August 01, 2026 at 00:02:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4358460) -- Card Homestead
-- MAIN APP DEPOTS
addappid(4358461, 1, "a418ce1cddb623fe5ab91a5efd008777e67127b3059ea063f65b335d15e52b23") -- Depot 4358461
setManifestid(4358461, "8402250336492031604", 1297906474)