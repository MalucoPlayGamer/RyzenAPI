-- Lua provided by RyzenAPI
-- Game: Puzzle Together Multiplayer Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1478220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478221, 1, "4e995cbb1f30bdec3c75b23d5c27dc641428726c7cba55cadf3a4d824dc95de9")
addappid(1478222, 1, "9ea158c0b72700274346aa3008fcfae5756d12ed59d82efdb121025a6d9c341e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2338660)
addappid(2338680)
addappid(2349050)
