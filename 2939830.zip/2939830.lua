-- Lua provided by RyzenAPI
-- Game: addappid(2939830)

-- MAIN APPLICATION
addappid(2939830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2939831, 1, "fdfcfb38872d9839c8c4882dcf88a462eb49cce135d6253cb7838ae78c221664")
