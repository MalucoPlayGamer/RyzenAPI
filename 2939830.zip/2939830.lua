-- Lua provided by RyzenAPI
-- Game: Dungeon Done

-- MAIN APPLICATION
addappid(2939830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2939831, 1, "fdfcfb38872d9839c8c4882dcf88a462eb49cce135d6253cb7838ae78c221664")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
