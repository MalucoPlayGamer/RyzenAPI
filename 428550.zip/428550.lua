-- Lua provided by RyzenAPI
-- Game: Momodora: Reverie Under the Moonlight

-- MAIN APPLICATION
addappid(428550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(428551, 1, "695d68a2c6cff8a9154b23784167cf071fddd46964394d51bb029ef7b2ff9cf3")
addappid(428552, 1, "c8ddd9fbaf4f0259998ed0e8dd5445a7b4b81b180372f87bdcec0cd33bc1455d")
addappid(428553, 1, "020e5b0d42ab24a41508a2aaa7ecc6d50377dd1bad22861c502a6b0af5bceb5f")
