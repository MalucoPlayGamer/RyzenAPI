-- Lua provided by RyzenAPI
-- Game: Commandos 3 - HD Remaster

-- MAIN APPLICATION
addappid(1469170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469171, 1, "4f189691feae25994ce8ff8fcaf681430a175fd1952b413cee1e49fcdbecf958")
