-- Lua provided by RyzenAPI
-- Game: AppID 1230800

-- MAIN APPLICATION
addappid(1230800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230801, 1, "c3c2ae1dbb6ee0cebcf8803e2469170b38e2f9f8a704344a3883b4a956d19a53")
addappid(1552480, 0, "bc76446b4379e003e98f0fdd5f1c5e990fe1122ac1f29afea0cccc0573544481")
addappid(1721630, 0, "a61762ac5c553c5ff08b948d5657dabc0d061288f989dec7092f7f2cc613f705")
addappid(2486090, 0, "ac72f76af0e360c8018e3fd23b36ea03d3dbe19847ce43c618c14b589199da12")
addappid(2486300, 0, "f1afb74c2ee199f7b1717b2cbd4bf449a3247231d5133f0f50f7b00137c33950")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
