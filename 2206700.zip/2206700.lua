-- Lua provided by RyzenAPI
-- Game: addappid(2206700)

-- MAIN APPLICATION
addappid(2206700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206701, 1, "defaf03bfcb9ba10e0dcaf8177354b28c6c2f6b754316eea22478f7b9df5e5a6")
