-- Lua provided by RyzenAPI 
-- Game: AppID 2390820
addappid(2390820)
addappid(2390821, 1, "85eeda94b2d6f0ab5d24dcf10376688c14494f9be1d024e1c4a38f2678fc3025")
