-- Lua provided by RyzenAPI 
-- Game: Evil Cult Soundtrack
addappid(1311820)
addappid(1311821, 1, "4472633d49a5bc4ba55e495740fe9e06e08d2ae6950a5085bb8cef63c8030914")
