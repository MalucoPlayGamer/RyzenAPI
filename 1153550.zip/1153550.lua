-- Lua provided by RyzenAPI 
-- Game: AppID 1153550
addappid(1153550)
addappid(1153551, 1, "31879492e2a0b0219bd60e1e879c61a368bce72dbe35997f6bea5444b92cca86")
addappid(1153552, 1, "ae578889f2277a99cfb1def364f1b165a54252a35341f8832a506cd8c15fbd13")
