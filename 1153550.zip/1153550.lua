-- Lua provided by RyzenAPI
-- Game: Dark Fairy Fantasy

-- MAIN APPLICATION
addappid(1153550)
addappid(1169010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153551,0,"31879492e2a0b0219bd60e1e879c61a368bce72dbe35997f6bea5444b92cca86")
addappid(1153552,0,"ae578889f2277a99cfb1def364f1b165a54252a35341f8832a506cd8c15fbd13")
addappid(1169330,0,"fb46109a66ac5a81bd38b2720482755c6b3807bc2c034eb66e7aa3b05ef23321")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3305880)
