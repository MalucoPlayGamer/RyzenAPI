-- Lua provided by RyzenAPI 
-- Game: From The Sky: New Horizon
addappid(895430)
addappid(895431, 1, "5fac0b4f71c566f049ec2b596df8e67a2a18b47af1ee79ec1fc776ef8c1ebbfe")
