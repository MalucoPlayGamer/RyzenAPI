-- Lua provided by RyzenAPI
-- Game: AppID 611780

-- MAIN APPLICATION
addappid(611780)
addappid(675570)
-- Game: addappid(611780)

-- MAIN APP DEPOTS / PACKAGES
addappid(611781, 1, "4d283581d201d1105d18a87001bbcbbfe7dd3e2ad03fa3e87f07750719592e80")
