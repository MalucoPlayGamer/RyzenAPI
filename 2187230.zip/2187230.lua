-- Lua provided by RyzenAPI
-- Game: Game: ALTF42

-- MAIN APPLICATION
addappid(2187230)
-- Game: addappid(2187230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187231, 1, "9c8afd17289089392c3f545d6e6820afe3b75487f89b17a910b9e6eac67602a3")
