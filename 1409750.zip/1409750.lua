-- Lua provided by RyzenAPI
-- Game: AppID 1409750

-- MAIN APPLICATION
addappid(1409750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409751, 1, "e81fb4ede8cbd2debd7288d8a04e2716a63502da2e48fbd2ff0b08ad31ca6edd")

