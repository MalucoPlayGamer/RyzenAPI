-- Lua provided by SkyAPI 
-- Game: Sanae Toumaden X
addappid(1337710)
addappid(1337711, 1, "4a7f92a18b9fc4c40295e2fd95b24849d3cce2a87c1e4b71c3143794911f25ae")
