-- Lua provided by SkyAPI 
-- Game: AppID 25740
addappid(25740)
addappid(25741, 1, "653c0210dcbf7f3b136366bdf3724e8bb4e8fc219c406e39e0e827603e8e0c6f")
