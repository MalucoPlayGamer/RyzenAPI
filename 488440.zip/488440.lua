-- Lua provided by RyzenAPI
-- Game: Game: Angeldust

-- MAIN APPLICATION
addappid(488440)
-- Game: addappid(488440)

-- MAIN APP DEPOTS / PACKAGES
addappid(488441, 1, "6269e0acb2e48c045a156438170d8e871132fbd46c2e03d4a4418e7a6cbdb855")
addappid(488442, 1, "a2f9b64dc7ff12ea80a3497b7aa5fd1d5be9da069cbc35360f54105748b03c88")
addappid(488443, 1, "f56dec3f525c19d647b62119b8c2441a79a4476f54a712728fb2df993f334984")
addappid(488444, 1, "39d69ee32362cee15b6e96c33032736e0f4f66de090636e3c4cdfcc32df26b00")
