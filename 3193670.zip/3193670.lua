-- Lua provided by RyzenAPI
-- Game: Sorry! I surrounded beauty!

-- MAIN APPLICATION
addappid(3193670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193672,0,"0d354431a4891282531b10b75b6c531760e19c90190d2ed0f1eed282fa8b8de8")
