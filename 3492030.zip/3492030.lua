-- Lua provided by RyzenAPI
-- Game: 3492030

-- MAIN APPLICATION
addappid(3492030)
-- Game: addappid(3492030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3492031, 1, "d36c08327f5424f7695604cafbebcd8f0f07b0b59c430c947ae3a8f4f0e461d7")
