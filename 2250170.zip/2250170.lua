-- Lua provided by RyzenAPI
-- Game: Game: Probo Rush

-- MAIN APPLICATION
addappid(2250170)
-- Game: addappid(2250170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250171, 1, "1f79afaaa4a22be7b5f89caf2549a4a27f35a707e877d16056f05c45b51c3a3f")
