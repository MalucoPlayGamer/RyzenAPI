-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - City Exterior Tileset

-- MAIN APPLICATION
addappid(1874590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874590,0,"e81d26bae22f9a9e3e9b8601d8ac74ef0a33afff129f63792ac8fcab38750561")

