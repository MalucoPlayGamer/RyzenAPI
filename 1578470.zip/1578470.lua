-- Lua provided by RyzenAPI
-- Game: Hide Seek Survive

-- MAIN APPLICATION
addappid(1578470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578471, 1, "18c2a3a260d0f97e3fac4ea691cc12c778c30c50914dbe2f849bca449d25246d")
