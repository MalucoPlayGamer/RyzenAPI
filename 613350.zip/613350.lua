-- Lua provided by RyzenAPI
-- Game: Punished Talents: Seven Muses Collector's Edition

-- MAIN APPLICATION
addappid(613350)

-- MAIN APP DEPOTS / PACKAGES
addappid(613351,0,"26a23829951a398d27b45d5f4565f32704d8d2984e0b27c3b0429ac7fa95bcd5")

