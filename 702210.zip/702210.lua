-- Lua provided by RyzenAPI
-- Game: Princess Serena ~Raid of Demon Legion~

-- MAIN APPLICATION
addappid(702210)

-- MAIN APP DEPOTS / PACKAGES
addappid(702211, 1, "2384297d5ed401493796816dac90f296997995cb68be016575029fd3288ae5c4")
