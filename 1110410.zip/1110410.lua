-- Lua provided by RyzenAPI
-- Game: 1110410

-- MAIN APPLICATION
addappid(1110410)
-- Game: addappid(1110410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110411, 1, "76e2ccc7ba46c775aa8f8fe1596e269d0023c47da578bf32160a77373ff4a06a")
