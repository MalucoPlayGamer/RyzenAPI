-- Lua provided by RyzenAPI
-- Game: Game: DORONKO WANKO

-- MAIN APPLICATION
addappid(2512840)
-- Game: addappid(2512840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512841, 1, "748218e1e887baf2e738e6d94bbdfef3bc0ee9e24ea8986dd69e673c46218e77")
