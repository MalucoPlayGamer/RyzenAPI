-- Lua provided by RyzenAPI
-- Game: Windjammers 2

-- MAIN APPLICATION
addappid(1114290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114291, 1, "a55dfa12b90546b6cf95904006f8842f1e7a86682d220f72f513369d403b9955")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
