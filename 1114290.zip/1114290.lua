-- Lua provided by RyzenAPI
-- Game: Windjammers 2

-- MAIN APPLICATION
addappid(1114290)
-- Game: addappid(1114290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114291, 1, "a55dfa12b90546b6cf95904006f8842f1e7a86682d220f72f513369d403b9955")
