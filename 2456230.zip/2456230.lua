-- Lua provided by RyzenAPI
-- Game: Game: Night Terrors

-- MAIN APPLICATION
addappid(2456230)
-- Game: addappid(2456230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456231, 1, "f8801383d043061f4fde3278f238ffc0896621e655d765116733a3215e4936a8")
