-- Lua provided by SkyAPI 
-- Game: Night Terrors
addappid(2456230)
addappid(2456231, 1, "f8801383d043061f4fde3278f238ffc0896621e655d765116733a3215e4936a8")
