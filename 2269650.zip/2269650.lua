-- Lua provided by RyzenAPI
-- Game: addappid(2269650)

-- MAIN APPLICATION
addappid(2269650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269651, 1, "4ca17f0dc60162090a15f4c42c1846af8eaa01eccde2406c72a2eb2ac2d015be")
