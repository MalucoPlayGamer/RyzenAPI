-- Lua provided by RyzenAPI
-- Game: Hello Engineer: Scrap Machines Constructor Demo

-- MAIN APPLICATION
addappid(2288160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288161, 1, "f631e386422414e8152ea5a1a030c8376285bb2fc73898ac84120b11deadaf81")
