-- Lua provided by RyzenAPI
-- Game: AppID 473730

-- MAIN APPLICATION
addappid(473730)

-- MAIN APP DEPOTS / PACKAGES
addappid(473731, 1, "1a4fff59f8c07b4b299864390448bed5039eca8b2fade4346e0a897cf2a23fe8")

