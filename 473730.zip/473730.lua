-- Lua provided by SkyAPI 
-- Game: AppID 473730
addappid(473730)
addappid(473731, 1, "1a4fff59f8c07b4b299864390448bed5039eca8b2fade4346e0a897cf2a23fe8")
