-- Lua provided by SkyAPI 
-- Game: AppID 1255730
addappid(1255730)
addappid(1255731, 1, "03dce171c5550d92f869f8c7216cf1ebc3b7b552cdb4633eb6f802b5109486aa")
