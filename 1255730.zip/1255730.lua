-- Lua provided by RyzenAPI
-- Game: addappid(1255730)

-- MAIN APPLICATION
addappid(1255730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255731, 1, "03dce171c5550d92f869f8c7216cf1ebc3b7b552cdb4633eb6f802b5109486aa")
