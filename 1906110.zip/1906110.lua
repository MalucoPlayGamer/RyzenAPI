-- Lua provided by RyzenAPI
-- Game: 1906110

-- MAIN APPLICATION
addappid(1906110)
addappid(1906960)
addappid(1906961)
addappid(1906962)
addappid(1906963)
-- Game: addappid(1906110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906111, 1, "0e888798fceacbf992581d786fafea2b6e41e7eb3a940d0299a49beaf6347c04")
