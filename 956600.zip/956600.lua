-- Lua provided by RyzenAPI
-- Game: Magebuster: Amorous Augury

-- MAIN APPLICATION
addappid(956600)

-- MAIN APP DEPOTS / PACKAGES
addappid(956601, 1, "2dd11cd6bb4f3c339ff3b133c872f38e6c3d70b5b2e3770151af2c63ae407a16")
addappid(956604, 1, "5b09485e7ddaccc51efd85eddd892fec090527afcc34c2d542b3817d3ea2df6d")

