-- Lua provided by RyzenAPI
-- Game: 1759400

-- MAIN APPLICATION
addappid(1759400)
-- Game: addappid(1759400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759401, 1, "6589ba0d0a1a596fd7261e738fc65f5bc05889d76d364fb5c5255b30fd06914d")
