-- Lua provided by RyzenAPI
-- Game: Game: AppID 437020

-- MAIN APPLICATION
addappid(437020)
-- Game: addappid(437020)

-- MAIN APP DEPOTS / PACKAGES
addappid(437021, 1, "fd6ab1a6e6fb780c4d07d9abd60f1933e5113e051497392f81f0c5eea25e160f")
addappid(437022, 1, "aa6cf0d3504875c5f809e10873634c1e8d67f323b07e37294c1e5aa4a8623756")
