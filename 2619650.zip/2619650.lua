-- Lua provided by RyzenAPI
-- Game: Cauldron

-- MAIN APPLICATION
addappid(2619650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619651, 1, "918343dada47c356828b1df3d51c6692efc744449fe8c03d3cadc84846436aee")

