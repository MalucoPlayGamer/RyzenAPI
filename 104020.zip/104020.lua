-- Lua provided by RyzenAPI
-- Game: Storm in a Teacup

-- MAIN APPLICATION
addappid(104020)
addappid(228983)
addappid(228985)
addappid(229020)
-- Game: addappid(104020)

-- MAIN APP DEPOTS / PACKAGES
addappid(104021, 1, "d5590b6865e6837a18cc977975853c5dbee6299c96e36aff2ffe22758ad6ca47")
addappid(104022, 1, "b3b3bd9368ee0e018e68f29043ce78179a5f9b5f0c675a916e068147fd74ec22")
