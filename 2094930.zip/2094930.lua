-- Lua provided by RyzenAPI
-- Game: Game: Farm Wars

-- MAIN APPLICATION
addappid(2094930)
-- Game: addappid(2094930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094931, 1, "977582b532f55c52c2f93b7e614211d8c6749f1723163d87fe5adf2013044370")
