-- Lua provided by RyzenAPI
-- Game: Farm Wars

-- MAIN APPLICATION
addappid(2094930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094931, 1, "977582b532f55c52c2f93b7e614211d8c6749f1723163d87fe5adf2013044370")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
