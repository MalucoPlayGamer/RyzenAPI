-- Lua provided by RyzenAPI 
-- Game: Farm Wars
addappid(2094930)
addappid(2094931, 1, "977582b532f55c52c2f93b7e614211d8c6749f1723163d87fe5adf2013044370")
