-- Lua provided by RyzenAPI
-- Game: Game: Sky Noon

-- MAIN APPLICATION
addappid(569530)
-- Game: addappid(569530)

-- MAIN APP DEPOTS / PACKAGES
addappid(569531, 1, "a292a018bce858b8af1d9d2214555864764349207b7eb85d338e2e2e211b4a39")
