-- Lua provided by RyzenAPI
-- Game: AppID 1919910

-- MAIN APPLICATION
addappid(1919910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919911, 1, "5d2fb8ff8ae564ba864d90bdad8f1bff567801a2cb84ba7558d0d2c6c07d079f")

