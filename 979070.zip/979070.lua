-- Lua provided by SkyAPI 
-- Game: Just Die Already
addappid(979070)
addappid(979071, 1, "de1f8c5b3e33aab6c91b27557facd8d7448a2e810df150df70ea2da288c94528")
