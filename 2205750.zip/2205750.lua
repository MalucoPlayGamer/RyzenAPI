-- Lua provided by RyzenAPI
-- Game: addappid(2205750)

-- MAIN APPLICATION
addappid(2205750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205751, 1, "a67785ee7b87b686c910bea65d17e0fd28bfb807ad2a6619fb41f53933547c9b")
