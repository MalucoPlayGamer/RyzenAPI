-- Lua provided by RyzenAPI
-- Game: EXZEAL

-- MAIN APPLICATION
addappid(465060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(465061, 1, "d5a2a3575cfc416323a606e70937c9b0f9a3de670841b0646b8e706a2f286672")
