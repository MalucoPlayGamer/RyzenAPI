-- Lua provided by SkyAPI 
-- Game: AppID 465060
addappid(465060)
addappid(465061, 1, "d5a2a3575cfc416323a606e70937c9b0f9a3de670841b0646b8e706a2f286672")
