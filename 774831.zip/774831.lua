-- Lua provided by RyzenAPI
-- Game: AppID 774831

-- MAIN APPLICATION
addappid(774831)

-- MAIN APP DEPOTS / PACKAGES
addappid(774832, 1, "57a506cdcf03abdf0456fc1e9e63f12313a08a4ebed4852097c5fdd85add8269")
