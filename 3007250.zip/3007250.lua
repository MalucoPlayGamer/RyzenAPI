-- Lua provided by RyzenAPI
-- Game: Stonemachia Demo

-- MAIN APPLICATION
addappid(3007250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007251, 1, "b48e3fcc549af3b3bfe96331f64ee617660e5f76ae92d8784eb0e8ce5fdc8e81")
