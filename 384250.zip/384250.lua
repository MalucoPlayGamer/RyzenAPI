-- Lua provided by RyzenAPI
-- Game: Game: Super Rude Bear Resurrection

-- MAIN APPLICATION
addappid(384250)
addappid(615500)
-- Game: addappid(384250)

-- MAIN APP DEPOTS / PACKAGES
addappid(384251, 1, "17dc46e7426b0e388fbca3a5cc181e074763ea0d8a1c8f20d7083d0b7aae7104")
