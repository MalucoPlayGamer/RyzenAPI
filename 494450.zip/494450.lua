-- Lua provided by RyzenAPI
-- Game: Office lovers

-- MAIN APPLICATION
addappid(494450)

-- MAIN APP DEPOTS / PACKAGES
addappid(494451, 1, "1d10133db502b25bcf273449e600816be3d18ee5ecc4266aacafa4fef28e725c")
