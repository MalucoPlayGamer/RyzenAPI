-- Lua provided by RyzenAPI
-- Game: Office lovers

-- MAIN APPLICATION
addappid(494450)

-- MAIN APP DEPOTS / PACKAGES
addappid(494451, 1, "1d10133db502b25bcf273449e600816be3d18ee5ecc4266aacafa4fef28e725c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
