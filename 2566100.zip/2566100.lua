-- Lua provided by RyzenAPI
-- Game: Game: AppID 2566100

-- MAIN APPLICATION
addappid(2566100)
-- Game: addappid(2566100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566101, 1, "e5b975c371adc082eebb530cc7e7ca3675342ce77630c3fbf910a2e44796f8e6")
