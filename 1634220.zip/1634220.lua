-- Lua provided by RyzenAPI
-- Game: Rytmos

-- MAIN APPLICATION
addappid(1634220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634221, 1, "3983e345ee413b7a6f03cb3326d44a71e627f6543dcc42be8a9059ec973a0e0d")
