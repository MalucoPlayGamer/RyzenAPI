-- Lua provided by RyzenAPI
-- Game: Game: Retroids

-- MAIN APPLICATION
addappid(897530)
-- Game: addappid(897530)

-- MAIN APP DEPOTS / PACKAGES
addappid(897531, 1, "d0b45527e1d0a555ac07a7d89ba1480a515b3056768ada2e18f6fa69ba9e1fa2")
