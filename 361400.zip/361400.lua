-- Lua provided by RyzenAPI
-- Game: addappid(361400)

-- MAIN APPLICATION
addappid(361400)

-- MAIN APP DEPOTS / PACKAGES
addappid(361401, 1, "43830763b70144c41b1d4bcc7cb83be40ad34b17a98320dac64ee7f74d1cc7d2")
