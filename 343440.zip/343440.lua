-- Lua provided by RyzenAPI 
-- Game: Crash Drive 2
addappid(343440)
addappid(343441, 1, "d01ffa683e1518cb25963ae63a12662c33ed66eab6caed56345d453de088ed42")
addappid(343442, 1, "ca170a5f2b693ce1877ce7defb292579a52652c266bcbd7accd27bf8ed1aa9d8")
addappid(343443, 1, "ed989af2fb0c4ab2650416b706dd20479988a93fee572c99a86f01e1e6016691")
