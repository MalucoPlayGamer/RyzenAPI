-- Lua provided by RyzenAPI
-- Game: Game: Sniper Strike: Special Ops

-- MAIN APPLICATION
addappid(848500)
-- Game: addappid(848500)

-- MAIN APP DEPOTS / PACKAGES
addappid(848501, 1, "965bf90c9b2f65f03df4b65831579e53caa3f4ef74edc5b8545a44b8e41495ec")
