-- Lua provided by RyzenAPI
-- Game: Sniper Strike: Special Ops

-- MAIN APPLICATION
addappid(848500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(848501, 1, "965bf90c9b2f65f03df4b65831579e53caa3f4ef74edc5b8545a44b8e41495ec")

