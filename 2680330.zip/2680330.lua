-- Lua provided by SkyAPI 
-- Game: HunterX: code name T
addappid(2680330)
addappid(2680331, 1, "a9966c66282dbcad2717cd44a3209f8b0344739ad63f1ee7970df1548aae566d")
