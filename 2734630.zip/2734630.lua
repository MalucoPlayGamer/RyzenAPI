-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2734630)
addappid(2734631)
-- Game: addappid(2734630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2734632,0,"f032556318992942f2b7208b535ae824326d0b58f1ec378a3550286b1d01e99b")
