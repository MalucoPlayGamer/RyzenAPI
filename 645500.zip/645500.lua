-- Lua provided by RyzenAPI
-- Game: Game: AppID 645500

-- MAIN APPLICATION
addappid(645500)
-- Game: addappid(645500)

-- MAIN APP DEPOTS / PACKAGES
addappid(645501, 1, "eae3609018d8f30cb872e30ad67921ada48486d5e0fc1762dc874be3ef460a05")
