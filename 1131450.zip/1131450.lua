-- Lua provided by RyzenAPI
-- Game: Above Earth

-- MAIN APPLICATION
addappid(1131450)
-- Game: addappid(1131450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131451, 1, "2a7181029e260f8f638f8492e3fff3a111e8f82641b1c798ceb10bc344cfce03")
