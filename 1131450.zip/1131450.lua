-- Lua provided by RyzenAPI
-- Game: Above Earth

-- MAIN APPLICATION
addappid(1131450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131451, 1, "2a7181029e260f8f638f8492e3fff3a111e8f82641b1c798ceb10bc344cfce03")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
