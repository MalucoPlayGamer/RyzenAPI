-- Lua provided by RyzenAPI
-- Game: Intravenous Soundtrack

-- MAIN APPLICATION
addappid(1661230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661231, 1, "a20de036837c13ff07e8b4ccc338742d3224e2113cd8f25a858cbfd1ca06298f")
addappid(1661232, 1, "369d1c4b5a24783cf2f9c0811c99d08c6b6508331a86e6728d85f535e9e9b2e8")
