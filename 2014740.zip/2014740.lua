-- Lua provided by RyzenAPI
-- Game: addappid(2014740)

-- MAIN APPLICATION
addappid(2014740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014741, 1, "06ea93e09fe7496246e674e8662e14df7be2542bfde1b6e2d1a5614fab7e73f7")
