-- Lua provided by SkyAPI 
-- Game: 阴缘
addappid(1728460)
addappid(1728461, 1, "212035dc263bee7bd459fd6398c375a5d2a6d61fa0738a4d07ba3791e457c685")
