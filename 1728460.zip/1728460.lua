-- Lua provided by RyzenAPI
-- Game: 阴缘

-- MAIN APPLICATION
addappid(1728460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728461, 1, "212035dc263bee7bd459fd6398c375a5d2a6d61fa0738a4d07ba3791e457c685")

