-- Lua provided by RyzenAPI
-- Game: Rage of the Dragons NEO

-- MAIN APPLICATION
addappid(2892130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892131, 1, "0e45dd03a01edf84554d55231a702b8fab38e3fbd9e039063de445ce3d2c916c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
