-- Lua provided by RyzenAPI
-- Game: Game: Love ritual

-- MAIN APPLICATION
addappid(890500)
-- Game: addappid(890500)

-- MAIN APP DEPOTS / PACKAGES
addappid(890501, 1, "a82866234428af1f5d6435d27cdaafb40c8876db6ffd67a89e6442753e124ba4")
