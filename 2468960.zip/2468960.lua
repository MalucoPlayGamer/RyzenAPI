-- Lua provided by RyzenAPI
-- Game: Game: The Old House

-- MAIN APPLICATION
addappid(2468960)
-- Game: addappid(2468960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468961, 1, "eed316184f43685ac391cb227de41b6ffe02b2be9bb7245a1472cef6be7a3634")
