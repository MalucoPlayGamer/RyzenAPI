-- Lua provided by RyzenAPI
-- Game: Your Personal Chill Apartment

-- MAIN APPLICATION
addappid(1870430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870432,0,"74257cef337c16573446e5f9799201f35c37a1354dfc71ea4cc60582e3836861")

