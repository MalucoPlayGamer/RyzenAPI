-- Lua provided by RyzenAPI
-- Game: 2635250

-- MAIN APPLICATION
addappid(2635250)
-- Game: addappid(2635250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635250,0,"d0452c3804c2030f4b93eaaf639369c05b4857f6aacbe1afd4763f82658ac515")
