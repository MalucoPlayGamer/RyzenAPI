-- Lua provided by RyzenAPI
-- Game: 巅峰骑士团

-- MAIN APPLICATION
addappid(1132730)
-- Game: addappid(1132730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132731, 1, "8cd65d768fae340184d66327a3d5476f631b9ea226298728c73481dd35a163e5")
