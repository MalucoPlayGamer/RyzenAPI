-- Lua provided by RyzenAPI
-- Game: Game: AppID 3098890

-- MAIN APPLICATION
addappid(3098890)
-- Game: addappid(3098890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098891, 1, "7ac2c36340b5ec35259d94c143f63d84cf75384688651eae35e4850aa20c9898")
