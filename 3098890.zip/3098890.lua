-- Lua provided by SkyAPI 
-- Game: AppID 3098890
addappid(3098890)
addappid(3098891, 1, "7ac2c36340b5ec35259d94c143f63d84cf75384688651eae35e4850aa20c9898")
