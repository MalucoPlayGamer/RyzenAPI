-- Lua provided by RyzenAPI
-- Game: Endlanders : First Encounter

-- MAIN APPLICATION
addappid(2010450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010451, 1, "f8e4fb669272b97bece7edf64d29b67f71d6e60bfcc11172c9a7cb5f26626c7f")
addappid(2010452, 1, "2c4f4094c32038a872aa697e9e00703bed8651e4bdf7e8f933d6fade6b7fb283")
