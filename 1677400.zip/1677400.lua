-- Lua provided by RyzenAPI
-- Game: Black Lotus Motel

-- MAIN APPLICATION
addappid(1677400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677401, 1, "7997e132a7aa46358a839b615b480b9b1d679de168a0bad24e5d0048287e45c0")

