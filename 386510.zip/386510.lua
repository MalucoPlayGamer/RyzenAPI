-- Lua provided by RyzenAPI
-- Game: 386510

-- MAIN APPLICATION
addappid(386510)
-- Game: addappid(386510)

-- MAIN APP DEPOTS / PACKAGES
addappid(386511, 1, "62f6519ea613a1ca3e0bc9d589deecca6b40a961e28b73e1f6db0088837e006a")
addappid(386512, 1, "e0ae9703c3a81e9a4026c245f038d41da5bf8a6641bf008686e0b9cc2043cc26")
