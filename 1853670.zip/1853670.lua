-- Lua provided by RyzenAPI
-- Game: 九天剑侠传Idle RPG

-- MAIN APPLICATION
addappid(1853670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853672,0,"509ffb464a5bf679a111ff0842eaad3eb7b16c967486ca1e75e6a7e9319a26a5")
addtoken(1853670,"9998509695199424132")

