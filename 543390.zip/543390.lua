-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(543390)

-- MAIN APP DEPOTS / PACKAGES
addappid(543392,0,"7b624a5f0717b4f3bb1b1e806c633c9baefc5a62c0d4634c7ba7422ea1670233")

