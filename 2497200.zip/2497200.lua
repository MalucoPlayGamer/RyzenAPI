-- Lua provided by RyzenAPI
-- Game: Game: AppID 2497200

-- MAIN APPLICATION
addappid(2497200)
-- Game: addappid(2497200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497201, 1, "6a5986ecfcf8e22fefdf99598e35afdb128045a18edb0af02da379b20554c370")
