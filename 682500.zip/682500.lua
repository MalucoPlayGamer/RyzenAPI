-- Lua provided by RyzenAPI
-- Game: 682500

-- MAIN APPLICATION
addappid(682500)
-- Game: addappid(682500)

-- MAIN APP DEPOTS / PACKAGES
addappid(682501, 1, "1ed4b3bedb848c4f9326fb5362d5603339543b9951b6f1faeafa2357c4069620")
