-- Lua provided by RyzenAPI
-- Game: AppID 992070

-- MAIN APPLICATION
addappid(992070)

-- MAIN APP DEPOTS / PACKAGES
addappid(992071, 1, "d2a0c83f97902fed266dba3c1deb8e2e4b0d0ae0d5a7e3ee62e40268e974197a")
addappid(992072, 1, "5c0dc385e238e30311cfb96b7fe92a7f3d8854e3bb84c6ebf13fbaacf10feecb")
addappid(992073, 1, "6523a1fca9a7955345c89e3ec8c5d16cb9a9719172b74f732f718e37d0e3b368")

