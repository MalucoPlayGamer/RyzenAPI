-- Lua provided by RyzenAPI
-- Game: AppID 587710

-- MAIN APPLICATION
addappid(587710)
-- Game: addappid(587710)

-- MAIN APP DEPOTS / PACKAGES
addappid(587711, 1, "25bda6a39bcd5dc10135154ded8d41dd9dd23463a9900c9eeae29fefcc915b16")
