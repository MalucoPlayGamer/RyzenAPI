-- Lua provided by RyzenAPI
-- Game: Desert Island in Summer?

-- MAIN APPLICATION
addappid(2346500)
-- Game: addappid(2346500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346502,0,"fa42a80f521bff2357c3a3fa84b072de03f073348f436972502060967a02c166")
addappid(2346503,0,"3daa74b5cfe7fa455d92eeb2459b7e3f28d37702556a68b80fc7de44b4d7ddc8")
