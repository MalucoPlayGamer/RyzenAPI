-- Lua provided by RyzenAPI
-- Game: 1206180

-- MAIN APPLICATION
addappid(1206180)
-- Game: addappid(1206180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206181, 1, "ac7bd2c5002c5bf042b9e44ac95651a93c606029516bd3fbcd96e339c5a80072")
