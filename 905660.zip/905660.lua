-- Lua provided by RyzenAPI
-- Game: 纸境英雄 Papercraft

-- MAIN APPLICATION
addappid(905660)
addappid(1099130)

-- MAIN APP DEPOTS / PACKAGES
addappid(905661, 1, "d1a743ebbb7faa4af00c27eb449ece997b4c4f6bdaac4a3bd5ed69f7f8ff1681")

