-- Lua provided by RyzenAPI
-- Game: Transpose

-- MAIN APPLICATION
addappid(835950)

-- MAIN APP DEPOTS / PACKAGES
addappid(835951, 1, "754b1f8aa3ce86511ca2610d7690cad5cc85cb87e9ebb13f730c7c3112dbf420")
addappid(962040, 0, "f53d33b9f5227039e58b135a7bab7518cb3bde9398ce2a869fef7592191617ad")
