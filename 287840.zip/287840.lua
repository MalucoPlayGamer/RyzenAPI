-- Lua provided by RyzenAPI
-- Game: TY the Tasmanian Tiger 4

-- MAIN APPLICATION
addappid(287840)

-- MAIN APP DEPOTS / PACKAGES
addappid(287841, 1, "0c7a90dc2ecfcc55461a6f488e189a8164d6ac3edf0dafa9de3533aeb4c9d431")
addappid(400720, 0, "a56432b6309dd6d56708e152aa4379ada8860d4b8f452d802b5b6631de64b423")
addappid(400721, 0, "534e21f938c99a8289994f7548b3f829439d5ca26d4de6afc4872a33c2b884ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
