-- Lua provided by RyzenAPI 
-- Game: TY the Tasmanian Tiger 4
addappid(287840)
addappid(287841, 1, "0c7a90dc2ecfcc55461a6f488e189a8164d6ac3edf0dafa9de3533aeb4c9d431")
addappid(400720, 0, "a56432b6309dd6d56708e152aa4379ada8860d4b8f452d802b5b6631de64b423")
addappid(400721, 0, "534e21f938c99a8289994f7548b3f829439d5ca26d4de6afc4872a33c2b884ae")
