-- Lua provided by RyzenAPI
-- Game: Game: Nearly Dead

-- MAIN APPLICATION
addappid(1268900)
-- Game: addappid(1268900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268901, 1, "2c39cf9dead0b3395f0fbbb44df1ed03d0b1d9999a240b4b153db243dee21255")
