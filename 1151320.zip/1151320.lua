-- Lua provided by RyzenAPI
-- Game: Game: AppID 1151320

-- MAIN APPLICATION
addappid(1151320)
-- Game: addappid(1151320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151321, 1, "598d27b1238cfeca059c00968966a408acbe972018d14c4586d51acd8572860e")
