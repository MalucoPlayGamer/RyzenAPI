-- Lua provided by RyzenAPI
-- Game: Netsoccer2

-- MAIN APPLICATION
addappid(1151320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1151321, 1, "598d27b1238cfeca059c00968966a408acbe972018d14c4586d51acd8572860e")

