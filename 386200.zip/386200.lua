-- Lua provided by SkyAPI 
-- Game: STLD Redux: Episode 02
addappid(386200)
addappid(386201, 1, "b0b3096994a21dffa020c2d7dc43b431dc40a22d8a313aae06d4e7a7283595fb")
