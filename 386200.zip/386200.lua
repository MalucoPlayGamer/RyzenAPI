-- Lua provided by RyzenAPI
-- Game: addappid(386200)

-- MAIN APPLICATION
addappid(386200)

-- MAIN APP DEPOTS / PACKAGES
addappid(386201, 1, "b0b3096994a21dffa020c2d7dc43b431dc40a22d8a313aae06d4e7a7283595fb")
