-- 4890150's Lua and Manifest Created by Hubcap Manifest
-- EMIT:Embrace Beyond Time
-- Created: August 07, 2026 at 07:22:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4890150) -- EMIT:Embrace Beyond Time
-- MAIN APP DEPOTS
addappid(4890151, 1, "0a46dc29509485756fca8c9f720204e321143b1edc8596b7726d29fbbdf6738a") -- Depot 4890151
setManifestid(4890151, "7588633783324780213", 2457108579)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)