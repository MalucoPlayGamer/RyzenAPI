-- Lua provided by RyzenAPI
-- Game: EMIT:Embrace Beyond Time

-- MAIN APPLICATION
addappid(4890150) -- EMIT:Embrace Beyond Time

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4890151, 1, "0a46dc29509485756fca8c9f720204e321143b1edc8596b7726d29fbbdf6738a") -- Depot 4890151

