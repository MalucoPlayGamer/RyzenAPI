-- Lua provided by RyzenAPI
-- Game: AppID 833360

-- MAIN APPLICATION
addappid(833360)

-- MAIN APP DEPOTS / PACKAGES
addappid(833361, 1, "18d5edd65605f06d3db636fe9ed1e93dd77c5f9e31cf42549b3621c6ed648e8e")
