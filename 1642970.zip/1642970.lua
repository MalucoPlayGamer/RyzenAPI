-- Lua provided by SkyAPI 
-- Game: James Peris 2: La fuente de la eterna embriaguez Uncut and Uncensored
addappid(1642970)
addappid(1642971, 1, "c1ecf8ef9d48afc04df8c19085f860cc023aa43252dc2421632f9b2950a3d2ef")
