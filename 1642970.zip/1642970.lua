-- Lua provided by RyzenAPI
-- Game: Game: James Peris 2: La fuente de la eterna embriaguez Uncut and Uncensored

-- MAIN APPLICATION
addappid(1642970)
-- Game: addappid(1642970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642971, 1, "c1ecf8ef9d48afc04df8c19085f860cc023aa43252dc2421632f9b2950a3d2ef")
