-- Lua provided by RyzenAPI
-- Game: Game: The Jelly Adventure

-- MAIN APPLICATION
addappid(1941170)
-- Game: addappid(1941170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941171, 1, "bccc79c8e79ca43debc28bed15aea30b57bed6f6509cee5fe79667d4dc1674cc")
