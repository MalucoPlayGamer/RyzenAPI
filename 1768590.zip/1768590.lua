-- Lua provided by RyzenAPI
-- Game: Dune Strider

-- MAIN APPLICATION
addappid(1768590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768591, 1, "90771a45bd2c2eda3b5f53b01af3cb6c088599f377f16ce8727f5b2792c3f5ff")

