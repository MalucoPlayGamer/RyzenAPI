-- Lua provided by RyzenAPI
-- Game: Dune Strider

-- MAIN APPLICATION
addappid(1768590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768591, 1, "90771a45bd2c2eda3b5f53b01af3cb6c088599f377f16ce8727f5b2792c3f5ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
