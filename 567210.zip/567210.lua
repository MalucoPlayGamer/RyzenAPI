-- Lua provided by SkyAPI 
-- Game: Bunnyrama
addappid(567210)
addappid(567211, 1, "23389a8e81d8395f50a8ecd24197e3fd6aab337b54bc2586db05f425178f986f")
addappid(567212, 1, "69816e62ec021d687e859f7761aaac99b5997bd0a112c51c0e7beee6f99d7176")
addappid(567213, 1, "a1b51f316676bea113bed74b3d1a63960733880d390bbf86fcfbab35951fc688")
