-- Lua provided by RyzenAPI
-- Game: Xingcai - Officer Ticket / 星彩使用券

-- MAIN APPLICATION
addappid(956869)

-- MAIN APP DEPOTS / PACKAGES
addappid(956869,0,"8b910d757ec6004ae628f589d8ca29cb99699256994e834b20e47e60a0307f33")

