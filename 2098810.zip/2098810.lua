-- Lua provided by RyzenAPI
-- Game: addappid(2098810)

-- MAIN APPLICATION
addappid(2098810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098811, 1, "b2f62f89679d78d67090a04db0b62f5cb68b66b3625d2f23e8e4ed937aebf784")
