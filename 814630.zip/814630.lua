-- Lua provided by RyzenAPI
-- Game: AppID 814630

-- MAIN APPLICATION
addappid(814630)
-- Game: addappid(814630)

-- MAIN APP DEPOTS / PACKAGES
addappid(814631, 1, "c650fe2d1ae4fb1d588b9dd52e93df79d5751da3570fbf5dc1c6929080be9a3a")
