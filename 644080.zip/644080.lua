-- Lua provided by RyzenAPI
-- Game: Alphabear: Hardcover Edition

-- MAIN APPLICATION
addappid(644080)

-- MAIN APP DEPOTS / PACKAGES
addappid(644081,0,"6f200b1a75f83bdf76130b86ad6b3f6a612c636f6a28044494fffad5fa2a5469")

