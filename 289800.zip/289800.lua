-- Lua provided by RyzenAPI
-- Game: Dracula: The Resurrection

-- MAIN APPLICATION
addappid(289800)
-- Game: addappid(289800)

-- MAIN APP DEPOTS / PACKAGES
addappid(289801, 1, "1ed911ecd3671a76a797bed4202e604b8950b1639da80aba600b9b9a019c4b30")
addappid(289802, 1, "03c010d8962e91fdeba5e6a8c452f1214d6c5f315d17d563a953cb939230f71e")
