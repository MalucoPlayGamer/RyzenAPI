-- Lua provided by RyzenAPI
-- Game: Crossing Souls Soundtrack

-- MAIN APPLICATION
addappid(799820)

-- MAIN APP DEPOTS / PACKAGES
addappid(799820,0,"893c58218df254c951a8a6872799fe3b27a97bf93df03b883fa87561be053a53")

