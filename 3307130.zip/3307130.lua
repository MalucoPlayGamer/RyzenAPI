-- Lua provided by RyzenAPI
-- Game: Shadows At Bay

-- MAIN APPLICATION
addappid(3307130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3307131, 1, "0761ebbb4ee3aa04d13dcbd5aba7daf3371b7c13e0dac56c2a3055d1b98cc983")
