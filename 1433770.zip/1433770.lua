-- Lua provided by RyzenAPI
-- Game: Chesnakisnak

-- MAIN APPLICATION
addappid(1433770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433771, 1, "1468d45ee9adafae6651a8ecb8b72f801149a22dec644e708e1237d42615e5e4")

