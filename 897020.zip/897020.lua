-- Lua provided by SkyAPI 
-- Game: Awakening: Moonfell Wood
addappid(897020)
addappid(897021, 1, "53faf20cc80a783d047ce765126acd10ce1314a6047c9cd7ddd0abd170eb9441")
