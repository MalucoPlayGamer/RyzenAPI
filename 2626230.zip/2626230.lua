-- Lua provided by RyzenAPI
-- Game: Liu Chan Rise of the Empress Demo

-- MAIN APPLICATION
addappid(2626230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626231, 1, "3bf3efd3d220db3f203e5e31f3050f18cf4025fd51fe00df249166de8c68e309")

