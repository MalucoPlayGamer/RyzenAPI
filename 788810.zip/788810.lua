-- Lua provided by RyzenAPI
-- Game: Game: Exposure

-- MAIN APPLICATION
addappid(788810)
-- Game: addappid(788810)

-- MAIN APP DEPOTS / PACKAGES
addappid(788811, 1, "64a9e7a819743eee072a32af4d5c27c101924c064641c782e8b3a7947681b67d")
