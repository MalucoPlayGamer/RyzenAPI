-- Lua provided by RyzenAPI
-- Game: Crop Rotation

-- MAIN APPLICATION
addappid(2348090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348092,0,"c0e25b81db2853448631a071c5171340fd5ac1dd04516c84176c53853b64342c")
addappid(2348093,0,"0c06dc58ded147ad783a93e3f2462fcc8b3b7a7bfa57428d7b83539f2cf6d00b")
addappid(2348094,0,"de7d4db18942028077edb965c4535115ddfb51f3654bb07ea42baf1c58c0f2f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
