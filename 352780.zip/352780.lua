-- Lua provided by RyzenAPI
-- Game: addappid(352780)

-- MAIN APPLICATION
addappid(352780)
addappid(352783)
addappid(352784)
addappid(352785)
addappid(415431)

-- MAIN APP DEPOTS / PACKAGES
addappid(352782,0,"5412e7b114c6113a553dcb429b524c85efcc8a538fe1fd2d83b594923cc71989")
addappid(415430,0,"b3039eb56ea9f37506f991ee06e4ac78c626fe98b19ab9c1316004ba422dbb9f")
