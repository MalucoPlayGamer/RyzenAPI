-- Lua provided by RyzenAPI
-- Game: Infection Free Zone Playtest

-- MAIN APPLICATION
addappid(2303070)
-- Game: addappid(2303070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303071, 1, "0c3388a810dab0c654335a04bea2770454a7a74420238c74fe2fab8b67a8a657")
