-- Lua provided by RyzenAPI
-- Game: Throwing Stone

-- MAIN APPLICATION
addappid(1344780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344781, 1, "b81bcb488c36082d6821ec4ca03467fea807d4e048db7c0a16504395ffb13c82")
