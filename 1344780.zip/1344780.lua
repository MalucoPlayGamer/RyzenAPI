-- Lua provided by RyzenAPI
-- Game: Throwing Stone

-- MAIN APPLICATION
addappid(1344780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1344781, 1, "b81bcb488c36082d6821ec4ca03467fea807d4e048db7c0a16504395ffb13c82")

