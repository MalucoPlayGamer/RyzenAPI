-- Lua provided by RyzenAPI
-- Game: Game: Gal-X-E

-- MAIN APPLICATION
addappid(473510)
-- Game: addappid(473510)

-- MAIN APP DEPOTS / PACKAGES
addappid(473511, 1, "98cc8ae88245b5cd8be7ee1e208f5d46172f4723ad416226ea407acb5437b8f3")
