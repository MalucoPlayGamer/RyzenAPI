-- Lua provided by SkyAPI 
-- Game: Gal-X-E
addappid(473510)
addappid(473511, 1, "98cc8ae88245b5cd8be7ee1e208f5d46172f4723ad416226ea407acb5437b8f3")
