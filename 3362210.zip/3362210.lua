-- Lua provided by RyzenAPI
-- Game: sea fight

-- MAIN APPLICATION
addappid(3362210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362211, 1, "48b7c41d0ee1bc6287c96f9d258ce159ebc6eed4260ff1b8d623b9758fd0b59f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
