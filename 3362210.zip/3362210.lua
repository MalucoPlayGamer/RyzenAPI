-- Lua provided by RyzenAPI
-- Game: addappid(3362210)

-- MAIN APPLICATION
addappid(3362210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362211, 1, "48b7c41d0ee1bc6287c96f9d258ce159ebc6eed4260ff1b8d623b9758fd0b59f")
