-- Lua provided by RyzenAPI 
-- Game: Mimpi
addappid(332580)
addappid(332581, 1, "2fafb399f587cbfd63f4911c698144a5d7b08d9c527d2d253a27baaf7080714f")
addappid(332582, 1, "b119a3387f7cd4fd348c0bfc84167a884a04774353085ca051a69b4b2a1712b2")
