-- Lua provided by RyzenAPI
-- Game: 1983020

-- MAIN APPLICATION
addappid(1983020)
-- Game: addappid(1983020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983021, 1, "edebd2224f6464aed24a7db90bf7e410dfe698aea3dd4ef7fb45e521bde8e73b")
