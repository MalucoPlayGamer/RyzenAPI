-- Lua provided by RyzenAPI
-- Game: Etrian Odyssey HD

-- MAIN APPLICATION
addappid(1868180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868182,0,"970d28732ebb844489f167ca395fa07ef3878ccf53e28628975fa17a2f1ab40d")
addappid(2015490,0,"ddd128abdf745fa1a17a9a7110f345a22a7705f79a0f3082bebd4bb618f3788c")

