-- Lua provided by RyzenAPI
-- Game: Company of Heroes 3

-- MAIN APPLICATION
addappid(1677280)
addappid(2068340)
addappid(2068341)
addappid(2068342)
addappid(3300460)
addappid(3469800)
addappid(4095900)
addappid(4523180)
addappid(4523380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677280,0,"3bc2162aacc5a2b9978b30069dffbbd4e0dcedfde3b7db80768525428e963600")
addappid(1677281,0,"946c1091854e4b36a1468dea11adb8fe4fe6db6485976132a50781a70d5a206e")
addappid(1677282,0,"2dbe642c09395dcb0cfab68ff34eca066c3f47e38d8511d59509fb60cf7c665a")
addappid(1677283,0,"532412e59c494bd36e8efc9d4e257208e7412c8a70b16f206103f3913d4add50")
addappid(1677289,0,"6c1e1a6d270910f7b11c528abd36479749f01a68ac03f86cf3c7c56f036eb450")

