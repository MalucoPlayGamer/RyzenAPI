-- Lua provided by RyzenAPI
-- Game: Company of Heroes 3

-- MAIN APPLICATION
addappid(1677280)
addappid(2068340)
addappid(2068341)
addappid(2068342)
addappid(3300460)
addappid(3469800)
addappid(4095900)
addappid(4523180)
addappid(4523380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677280,0,"3bc2162aacc5a2b9978b30069dffbbd4e0dcedfde3b7db80768525428e963600")
addappid(1677281,0,"946c1091854e4b36a1468dea11adb8fe4fe6db6485976132a50781a70d5a206e")
addappid(1677282,0,"2dbe642c09395dcb0cfab68ff34eca066c3f47e38d8511d59509fb60cf7c665a")
addappid(1677283,0,"532412e59c494bd36e8efc9d4e257208e7412c8a70b16f206103f3913d4add50")
addappid(1677289,0,"6c1e1a6d270910f7b11c528abd36479749f01a68ac03f86cf3c7c56f036eb450")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
