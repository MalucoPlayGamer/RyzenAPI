-- Lua provided by RyzenAPI
-- Game: 935600

-- MAIN APPLICATION
addappid(935600)
-- Game: addappid(935600)

-- MAIN APP DEPOTS / PACKAGES
addappid(935601, 1, "472c55f83f21969ed666243ecd033254daa34532e3f5dd50d00f133f538422cc")
