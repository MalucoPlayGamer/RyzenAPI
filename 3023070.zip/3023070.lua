-- Lua provided by RyzenAPI 
-- Game: BEYBLADE X XONE
addappid(3023070)
addappid(3023071, 1, "c2398467d4fb3dd94f8253f01ba913f4fc14c3a4c59d63d7dec87ccec838cb62")
