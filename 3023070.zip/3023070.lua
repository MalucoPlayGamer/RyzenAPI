-- Lua provided by RyzenAPI
-- Game: addappid(3023070)

-- MAIN APPLICATION
addappid(3023070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023071, 1, "c2398467d4fb3dd94f8253f01ba913f4fc14c3a4c59d63d7dec87ccec838cb62")
