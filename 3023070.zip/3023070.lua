-- Lua provided by RyzenAPI
-- Game: BEYBLADE X XONE

-- MAIN APPLICATION
addappid(3023070)
addappid(3287540)
addappid(3287550)
addappid(3287560)
addappid(3287570)
addappid(3455100)
addappid(3534860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023071, 1, "c2398467d4fb3dd94f8253f01ba913f4fc14c3a4c59d63d7dec87ccec838cb62")

