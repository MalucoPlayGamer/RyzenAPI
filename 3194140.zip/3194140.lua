-- Lua provided by RyzenAPI
-- Game: Cozy Sudoku

-- MAIN APPLICATION
addappid(3194140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3194141, 1, "d9cb1d9252cb59c4d11609d4135650b1b5145d165f29e16d55d1f2e671a218c0")

