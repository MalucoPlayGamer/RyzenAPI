-- Lua provided by RyzenAPI
-- Game: Orblitz

-- MAIN APPLICATION
addappid(746360)

-- MAIN APP DEPOTS / PACKAGES
addappid(746361, 1, "6ebcbb17307a1d4decf2b885b8f47feb061cb6c49b335dad3b08f18f82aa72d7")
