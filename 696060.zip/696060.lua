-- Lua provided by RyzenAPI
-- Game: Live

-- MAIN APPLICATION
addappid(696060)

-- MAIN APP DEPOTS / PACKAGES
addappid(696061, 1, "a17985b8874b128505a7ce6078524bdbecc7eb57db22fcddfdb7c4ad1e1ef7bd")

