-- Lua provided by RyzenAPI
-- Game: 2752250

-- MAIN APPLICATION
addappid(2752250)
-- Game: addappid(2752250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752251, 1, "9b60575963653d5f926cea7a5e5e3bbdbe28bc06fb185d461d6b5d676539b47c")
