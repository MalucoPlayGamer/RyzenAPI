-- Lua provided by RyzenAPI
-- Game: CASE RECORDS: Lost Night

-- MAIN APPLICATION
addappid(3520330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3520331,0,"5a1488019a3ae08c4c5f14e99e64bf91105eabcdf22610d8f7fc18355e400b6f")

