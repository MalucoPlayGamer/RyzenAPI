-- Lua provided by RyzenAPI
-- Game: CASE RECORDS: Lost Night

-- MAIN APPLICATION
addappid(3520330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3520331,0,"5a1488019a3ae08c4c5f14e99e64bf91105eabcdf22610d8f7fc18355e400b6f")

