-- Lua provided by RyzenAPI 
-- Game: Black Forest
addappid(523070)
addappid(523071, 1, "9c0bd66d7bee8d6142b7a677eb42f195767fc3c56831eee5d0a62a482f0c99e7")
addappid(523072, 1, "fa042b023b2b5ace22d662149ae1650fcfedc37dd5c6a0b662e93ef1a246c1e1")
addappid(523073, 1, "5cd7e6b0b378c8c90c2b9d2151190bbadb4b8633f335fb04afd5b1dc8284d165")
