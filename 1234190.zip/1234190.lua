-- Lua provided by RyzenAPI
-- Game: ANIME WAR — Modern Campaign

-- MAIN APPLICATION
addappid(1234190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234191, 1, "efc6c543748c6848b95f6a1214d54ec3d72e73172a75de0d026e987a65f1e0ba")

