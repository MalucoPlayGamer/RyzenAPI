-- Lua provided by RyzenAPI
-- Game: 1871480

-- MAIN APPLICATION
addappid(1871480)
-- Game: addappid(1871480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871481, 1, "436ce67e77b44ebf002d8ee2d2ce5f09b8747854eb344593df85e447a405efd0")
