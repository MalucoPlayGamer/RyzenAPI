-- 4865210's Lua and Manifest Created by Hubcap Manifest
-- Egg-cremental
-- Created: July 15, 2026 at 13:47:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4865210) -- Egg-cremental
-- MAIN APP DEPOTS
addappid(4865211, 1, "6d75766a7706f1804ef738f9a99756744e3e7eb817f5d661fec82aee3f8dc91e") -- Depot 4865211
setManifestid(4865211, "56642823165333503", 186645264)