-- Lua provided by RyzenAPI
-- Game: HYDROPLANT Tycoon

-- MAIN APPLICATION
addappid(3621000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3621001, 1, "42463223af3e3f2a8c04713e718d72656d2380edf53bd5c7f36e0f953a0fb472")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
