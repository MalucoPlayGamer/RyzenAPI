-- Lua provided by RyzenAPI
-- Game: Game: HYDROPLANT Tycoon

-- MAIN APPLICATION
addappid(3621000)
-- Game: addappid(3621000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3621001, 1, "42463223af3e3f2a8c04713e718d72656d2380edf53bd5c7f36e0f953a0fb472")
