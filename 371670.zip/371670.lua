-- Lua provided by RyzenAPI
-- Game: Rolling Sun

-- MAIN APPLICATION
addappid(371670)
-- Game: addappid(371670)

-- MAIN APP DEPOTS / PACKAGES
addappid(371671, 1, "abc3b0fa792d8e8066a9f155b220508489321b4ddf38da60102fd5e5f687a992")
