-- Lua provided by SkyAPI 
-- Game: Rolling Sun
addappid(371670)
addappid(371671, 1, "abc3b0fa792d8e8066a9f155b220508489321b4ddf38da60102fd5e5f687a992")
