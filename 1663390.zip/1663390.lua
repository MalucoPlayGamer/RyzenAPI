-- Lua provided by RyzenAPI
-- Game: Game: Snake Deluxe

-- MAIN APPLICATION
addappid(1663390)
-- Game: addappid(1663390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663391, 1, "859b95469231b9830b783ec6191577d6b6e79f013a4727e06da8626715ad8ae3")
