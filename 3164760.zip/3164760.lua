-- Lua provided by RyzenAPI
-- Game: Uboat Attack

-- MAIN APPLICATION
addappid(3164760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164761, 1, "1D6BEDEC7F83AEBC6B67E94DC2CD03DBE8C5EC2D2ADA0B0B5BAF12D9D306F5AD")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3179220)
addappid(3179230)
addappid(3179240)
