-- Lua provided by RyzenAPI
-- Game: AppID 222140

-- MAIN APPLICATION
addappid(222140)
addappid(228982)
addappid(229000)
addappid(273670)

-- MAIN APP DEPOTS / PACKAGES
addappid(222141, 1, "94016a924467a6cfa3b855243f1dce9c4db3d85d0ff42c69237eda0a178c975d")
addappid(222142, 1, "43c5e53ed3ef188660717c34b70f72343e2ffc8bb79bfe09babf78cbacbf6f8f")
addappid(222143, 1, "d172a34799d8267fea29a02830f928569d8eb30e5f5806f68d0416453ad10674")

