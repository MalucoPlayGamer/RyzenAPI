-- Lua provided by RyzenAPI
-- Game: Moon Watch Demo

-- MAIN APPLICATION
addappid(3126870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126872,0,"b23be9b394872ef9637535ce7160b693dab6b292a693c7f72f6f19f7c185af74")

