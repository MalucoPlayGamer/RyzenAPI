-- Lua provided by RyzenAPI
-- Game: AppID 3349480

-- MAIN APPLICATION
addappid(3349480)
-- Game: addappid(3349480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349481, 1, "c9f48151f112ec84c9a1f7819e716c500453e667064fd7dc994546f5c5ef63be")
