-- Lua provided by RyzenAPI
-- Game: Poco

-- MAIN APPLICATION
addappid(3454610)

