-- Lua provided by RyzenAPI 
-- Game: Word Factori
addappid(2072840)
addappid(2072841, 1, "2057bba4fd1075a6129ad51109d8bbc022857986715b69810f21446f57d6a5b5")
