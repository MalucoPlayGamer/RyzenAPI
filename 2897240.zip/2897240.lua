-- Lua provided by RyzenAPI 
-- Game: Puffin Planes
addappid(2897240)
addappid(2897241, 1, "ba11bbfd0530c6d8c0d71902a329f6345f9bfe90a82e944b111a474559b81a9c")
