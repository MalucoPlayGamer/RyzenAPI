-- Lua provided by RyzenAPI
-- Game: addappid(2615380)

-- MAIN APPLICATION
addappid(2615380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615381, 1, "743a2c714fd15c93f9ac9dc7971f1d8d7121b36f003c5543555e7f674c1fcb68")
