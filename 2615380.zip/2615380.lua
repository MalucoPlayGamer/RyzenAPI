-- Lua provided by RyzenAPI
-- Game: The Legend of Yan Loong 1+2

-- MAIN APPLICATION
addappid(2615380)
-- Game: addappid(2615380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615381, 1, "743a2c714fd15c93f9ac9dc7971f1d8d7121b36f003c5543555e7f674c1fcb68")
