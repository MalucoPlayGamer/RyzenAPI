-- Lua provided by RyzenAPI
-- Game: Panic Diet!!

-- MAIN APPLICATION
addappid(1154730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154731, 1, "8e59253cce920ed4faf83c7dd4dc0280ba6e859fe8bd7d2937408c32a9feb892")
