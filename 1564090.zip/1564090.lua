-- Lua provided by RyzenAPI
-- Game: Landlord of the Woods

-- MAIN APPLICATION
addappid(1564090)
-- Game: addappid(1564090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564092,0,"f04e81b6e6ee04f414080c78b64a1afaf33f665e16204602ef444d515d030b03")
addappid(1564093,0,"9a6837fb19a9350a2be6ae76f03637ee692fb0f4110d6bf0023059b7432f4f82")
