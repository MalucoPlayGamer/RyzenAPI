-- Lua provided by RyzenAPI
-- Game: addappid(2288440)

-- MAIN APPLICATION
addappid(2288440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288441, 1, "5dc91a67752ca137a2cacee757befccf6347bc800882a32847303297d267e2e2")
