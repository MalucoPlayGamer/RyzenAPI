-- Lua provided by RyzenAPI
-- Game: Age Of Warbots

-- MAIN APPLICATION
addappid(3371630)
