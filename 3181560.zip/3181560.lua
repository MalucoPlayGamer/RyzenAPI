-- Lua provided by RyzenAPI
-- Game: addappid(3181560)

-- MAIN APPLICATION
addappid(3181560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181560,0,"8bae1b7e9e8b21a20c8559a29acd29dc6dda9afb6154587d5862ea0584eb3d7f")
