-- Lua provided by RyzenAPI
-- Game: Black Dragon Mage

-- MAIN APPLICATION
addappid(2207230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207231, 1, "9e1ce500aaacc3f6517ff73b84d8fce223071a058bc7ee28a586d4a71a3723bf")
