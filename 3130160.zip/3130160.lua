-- Lua provided by RyzenAPI
-- Game: Game: Ultra Sudoku

-- MAIN APPLICATION
addappid(3130160)
-- Game: addappid(3130160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130161, 1, "13fe8267b7528b42597b70f246364c7fb753bbcadec8efa7851b327342614e68")
