-- Lua provided by RyzenAPI
-- Game: 1652350

-- MAIN APPLICATION
addappid(1652350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652350,0,"a2bf42a7e1f1c872a3a9189e897f9a3cb76e1aab92586d3d4d97a865a5ccaec7")

