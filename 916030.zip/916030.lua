-- Lua provided by RyzenAPI
-- Game: 916030

-- MAIN APPLICATION
addappid(916030)
-- Game: addappid(916030)

-- MAIN APP DEPOTS / PACKAGES
addappid(916031, 1, "6390a27cba58c7950f6a57a5fa5548e128c9f944f657e9b5d5074b5f50e67f6a")
