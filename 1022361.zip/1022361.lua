-- Lua provided by RyzenAPI
-- Game: DFF NT: Rinoa Heartilly Starter Pack

-- MAIN APPLICATION
addappid(1022361)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022361,0,"502ad81a5fe4107c6629f8d961d46acccd49268b1997a42bea96b2ed36f0f644")

