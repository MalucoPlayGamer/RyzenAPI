-- Lua provided by RyzenAPI
-- Game: Kissing Simulator

-- MAIN APPLICATION
addappid(1091210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091211, 1, "1fa3c6dc4c98a3ffcdaa9a84cc2e42faca9ef5bfa4d6ac27231649ce299d6abe")
