-- Lua provided by RyzenAPI
-- Game: setManifestid(568672,"3681309375831337546")

-- MAIN APPLICATION
addappid(568670)
-- Game: addappid(568670)

-- MAIN APP DEPOTS / PACKAGES
addappid(568672,0,"d6d1a2f9c0935d4a0dc0110f9b44ed813f74500b717ee770d0125d4591bd54d4")
