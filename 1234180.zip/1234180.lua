-- Lua provided by RyzenAPI
-- Game: 1234180

-- MAIN APPLICATION
addappid(1234180)
-- Game: addappid(1234180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234181, 1, "20eb543693fccdb188bf01fbab67c04a34f003bcf2b9c3d6f27599220fe8335e")
