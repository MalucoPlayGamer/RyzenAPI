-- Lua provided by RyzenAPI 
-- Game: AppID 1234180
addappid(1234180)
addappid(1234181, 1, "20eb543693fccdb188bf01fbab67c04a34f003bcf2b9c3d6f27599220fe8335e")
