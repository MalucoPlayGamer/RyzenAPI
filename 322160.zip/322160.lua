-- Lua provided by RyzenAPI
-- Game: addappid(322160)

-- MAIN APPLICATION
addappid(322160)

-- MAIN APP DEPOTS / PACKAGES
addappid(322161, 1, "2e287fbf69d786c284739301b139ff7ac095c6f03061cd9a47809500fb1cec41")
addappid(322162, 1, "e6d27b5e6276b8296a84c8fe504c6b822427dbd155e0deff0b85f97b6bd295af")
