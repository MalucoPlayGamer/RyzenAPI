-- Lua provided by RyzenAPI
-- Game: WarSphere

-- MAIN APPLICATION
addappid(2451530)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2777020)
