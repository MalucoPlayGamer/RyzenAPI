-- Lua provided by RyzenAPI
-- Game: WarSphere

-- MAIN APPLICATION
addappid(2451530)

