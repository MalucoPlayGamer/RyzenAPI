-- Lua provided by RyzenAPI
-- Game: Sunshine Shuffle

-- MAIN APPLICATION
addappid(1912420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912421, 1, "54c4ee065f071c0f2aae221213a5e7457f12752e8978304e133da65ed5178dc9")

