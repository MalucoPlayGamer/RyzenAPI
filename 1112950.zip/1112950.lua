-- Lua provided by RyzenAPI
-- Game: Japocaliptyca/ Япокалиптика

-- MAIN APPLICATION
addappid(1112950)
-- Game: addappid(1112950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112951, 1, "91001eb57d52c5ab5b2c2d69919ccdf806ae6d5aeba667556ddc6e06b16684c0")
