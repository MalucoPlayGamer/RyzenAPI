-- Lua provided by RyzenAPI
-- Game: CosmoLands | Space-Adventure

-- MAIN APPLICATION
addappid(445880)

-- MAIN APP DEPOTS / PACKAGES
addappid(445881, 1, "29c9b6f586c006efd3c8dea85bf2f22c0ef194e35e6797bd6c813705a153c63d")
