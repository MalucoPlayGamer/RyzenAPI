-- Lua provided by RyzenAPI
-- Game: UuultraC

-- MAIN APPLICATION
addappid(1909800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909801, 1, "b7fd1ffed737ac12941ef64e0c05fc987971d1b7c6319092de359f5d0ae0906c")
