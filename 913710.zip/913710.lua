-- Lua provided by RyzenAPI
-- Game: Game: Dangerous Lands - Magic and RPG

-- MAIN APPLICATION
addappid(913710)
addappid(932200)
-- Game: addappid(913710)

-- MAIN APP DEPOTS / PACKAGES
addappid(913711, 1, "4954107b84176b53c93e0e95b9d2e7b7cfcf52b5e33411ca139772835a329471")
