-- Lua provided by RyzenAPI
-- Game: Game: FIVE: Guardians of David

-- MAIN APPLICATION
addappid(387010)
-- Game: addappid(387010)

-- MAIN APP DEPOTS / PACKAGES
addappid(387011, 1, "09641abc9fc93e3ea61d1bedfe1c645d516214cd4b54fd7fbf5b8c6594e39fc9")
addappid(387012, 1, "5c89fad44fed503c7f98b22d459072d836e556a09ebead23f5b096a0d4fc19f4")
addappid(422690, 0, "66d814d3da446ccc433211d21b0b77bf4d9ee8748f2877de2bc97c534c13ef98")
addappid(422691, 0, "9a8224fc3ac5733011380bf725cb4f81030acab54c1e2f424a649541d64243a7")
addappid(466380, 0, "5c63c2e71cd1e557605325d72d599ca62cb4363ede55ce621918821c45480350")
