-- Lua provided by RyzenAPI 
-- Game: Polda 3
addappid(2175650)
addappid(2175651, 1, "734cfe4b6a600d521e1d92cf8edd7a44e45394a2338f69cb93da07bedff78239")
