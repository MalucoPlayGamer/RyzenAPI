-- Lua provided by RyzenAPI
-- Game: 1386620

-- MAIN APPLICATION
addappid(1386620)
-- Game: addappid(1386620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386621, 1, "b76462078ea15801baebc7c836ab0d72ef122af048c2fc1e7143b008907bbf77")
addappid(1962400, 0, "563b49328602bd988e6161fa8a7c328ec9e1b1ba95f2cfbc6f3dafead1e9ccd9")
