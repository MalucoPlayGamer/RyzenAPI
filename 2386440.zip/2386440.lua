-- Lua provided by RyzenAPI 
-- Game: AppID 2386440
addappid(2386440)
addappid(2386441, 1, "288393a054827127276e3330fef548cbd4d86e1ce03c8a12fce3f1742a31eca1")
