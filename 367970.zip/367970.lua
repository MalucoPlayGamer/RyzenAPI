-- Lua provided by RyzenAPI
-- Game: 367970

-- MAIN APPLICATION
addappid(367970)
-- Game: addappid(367970)

-- MAIN APP DEPOTS / PACKAGES
addappid(367971, 1, "b9eaaa48e63bb8a652dccee1fc0a7b33b78b51151a25390afd29b6a6b507047c")
