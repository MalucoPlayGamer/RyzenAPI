-- Lua provided by SkyAPI 
-- Game: Lone Fungus
addappid(1674780)
addappid(1674781, 1, "bd7f83ebcedce1e0c989d4b0c5f5336fb5f7e7d0fa76810799427d8e0c07d7f6")
addappid(1674782, 1, "d019afa21fa89277ecd670d3ab25556f5ae90cb2ff03ab65a081aa8ed149d1c6")
addappid(1674784, 1, "e77dc07575a80e76cb0bbf00af551de79c28263c64acd5e73d134f33d866d078")
