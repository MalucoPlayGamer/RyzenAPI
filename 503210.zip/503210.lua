-- Lua provided by RyzenAPI
-- Game: Sentry Knight Tactics

-- MAIN APPLICATION
addappid(503210)

-- MAIN APP DEPOTS / PACKAGES
addappid(503211, 1, "f7e88ca9eba7c23bc96aee2eb54daa49b2f637e8c4858ef3638c10c7f1d38c41")
