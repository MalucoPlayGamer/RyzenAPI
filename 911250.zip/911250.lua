-- Lua provided by RyzenAPI
-- Game: AppID 911250

-- MAIN APPLICATION
addappid(911250)

-- MAIN APP DEPOTS / PACKAGES
addappid(911251, 1, "67e90c9dea93e190ff8072a7421e1ed15a29bae1b1c753df3378d6be3553b5c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
