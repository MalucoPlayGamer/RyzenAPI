-- Lua provided by RyzenAPI
-- Game: addappid(911250)

-- MAIN APPLICATION
addappid(911250)

-- MAIN APP DEPOTS / PACKAGES
addappid(911251, 1, "67e90c9dea93e190ff8072a7421e1ed15a29bae1b1c753df3378d6be3553b5c7")
