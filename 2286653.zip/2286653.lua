-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - SERIALGAMES Living Good City Tileset

-- MAIN APPLICATION
addappid(2286653)
-- Game: addappid(2286653)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286653,0,"b779f806cca94e260906e9566de7e122409025285de9c3a35fa315e5200ee92f")
