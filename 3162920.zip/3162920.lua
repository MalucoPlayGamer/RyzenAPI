-- Lua provided by RyzenAPI
-- Game: Forest 6174

-- MAIN APPLICATION
addappid(3162920)
addappid(3772630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162921, 1, "e13569dc04cf2da0fb6e7df7392779ffa57cac35213ac20e9d79cd429ff46d6f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
