-- Lua provided by RyzenAPI
-- Game: Out of the Park Baseball 26

-- MAIN APPLICATION
addappid(3116890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116891, 1, "959bcb6ea420ef72dc6f06becae7c7fb9b7240facb2b08c492b00bf124d6ae12")
addappid(3116894, 1, "313f36e0178314b9c3a0063d40768105b88d90b089edf304993e7d7af58cdc67")
addappid(3116895, 1, "5f30ee764d3a5cd57945bbef62716582941bd9ebfea21becbad501aaef7c3f45")
addappid(3116896, 1, "941823d772f3efc669051f4ed37677e61ec7b4aa650520c06fa1ecc8ce23870e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
