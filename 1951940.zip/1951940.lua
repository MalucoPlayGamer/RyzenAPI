-- Lua provided by RyzenAPI
-- Game: Eschaton

-- MAIN APPLICATION
addappid(1951940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951941, 1, "68891033e3c412899e4630a33d342ac383cf13a92fb109e2adc92a78ae23606e")
