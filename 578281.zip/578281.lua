-- Lua provided by RyzenAPI
-- Game: A Rose in the Twilight - Digital Soundtrack

-- MAIN APPLICATION
addappid(578281)

-- MAIN APP DEPOTS / PACKAGES
addappid(578281,0,"c90c4f7b4957d0035d8b27e2d21249bc5a2fbc3a5c583e503eb90b6630818918")
addtoken(578281,10722392314257754485)

