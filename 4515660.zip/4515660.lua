-- Lua provided by RyzenAPI
-- Game: Control, I'm Not Coming Back

-- MAIN APPLICATION
addappid(4515660)

