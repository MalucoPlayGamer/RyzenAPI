-- Lua provided by RyzenAPI
-- Game: Game: A Long Way Down

-- MAIN APPLICATION
addappid(856990)
-- Game: addappid(856990)

-- MAIN APP DEPOTS / PACKAGES
addappid(856991, 1, "d3a322e602b4681f6058ecc308d668846422208dc7827ea96672ac4545b1aecd")
addappid(856992, 1, "12c9fcb7c761fff050fb6a6d4e57acb4f1adf6f54ac35218aab39a1e8d7447a7")
addappid(856993, 1, "d8f983ca27359a1f06315cb577412b31e96df30c6fc2456e51160c30dd575d81")
