-- Lua provided by RyzenAPI
-- Game: Hyperdevotion Noire: Goddess Black Heart (Neptunia)

-- MAIN APPLICATION
addappid(415480)
addappid(426920)
addappid(426921)
addappid(426922)
addappid(426923)
addappid(426924)
addappid(426925)
addappid(426926)
addappid(426927)
addappid(426928)
addappid(426929)
addappid(426990)
addappid(426991)
addappid(426992)
addappid(426993)
addappid(426994)
addappid(426995)
addappid(426996)
addappid(426997)
addappid(426998)
addappid(426999)
addappid(427000)
addappid(427001)
addappid(427002)
addappid(427003)
addappid(427004)
addappid(427005)
addappid(427006)
addappid(427007)
addappid(427008)

-- MAIN APP DEPOTS / PACKAGES
addappid(415481, 1, "05e52def802398881df8b95fd2a285bc5e01ded37e94e3642f5e8d6a9eae20d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
