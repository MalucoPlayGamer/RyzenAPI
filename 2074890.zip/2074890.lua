-- Lua provided by SkyAPI 
-- Game: 少女妖精弹珠台 Elf Girl Pinball
addappid(2074890)
addappid(2074891, 1, "ba67098a50e16f823989f70996ca3dcde0b6f6ec881b9f83a1c224ff7188438d")
addappid(3614210, 0, "02799b560ea67de320f9b94f7eaea032ff1baed021d23b9fef058d423a0e2285")
