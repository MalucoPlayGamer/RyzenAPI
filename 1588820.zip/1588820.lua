-- Lua provided by RyzenAPI
-- Game: addappid(1588820)

-- MAIN APPLICATION
addappid(1588820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588820,0,"482bf02916c32f5cb363998edf33aedf92b5e5ea72bab2d001337e374f42f52e")
