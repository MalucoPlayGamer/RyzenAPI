-- Lua provided by RyzenAPI
-- Game: AppID 542710

-- MAIN APPLICATION
addappid(542710)

-- MAIN APP DEPOTS / PACKAGES
addappid(542711, 1, "efc28ec2574e0cd4969ef922f79acd90b4c94a1af6e527b78a9e3dbafe66c654")
