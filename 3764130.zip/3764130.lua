-- Lua provided by RyzenAPI
-- Game: addappid(3764130)

-- MAIN APPLICATION
addappid(3764130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3764131, 1, "e722f1a28fd2323fd908a5127d9f31d3004a6dfa902daa7dd6da27399dcf280d")
