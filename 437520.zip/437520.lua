-- Lua provided by RyzenAPI
-- Game: addappid(437520)

-- MAIN APPLICATION
addappid(437520)
addappid(437521)
addappid(437522)
addappid(437523)
addappid(437524)
addappid(437525)
addappid(437527)

-- MAIN APP DEPOTS / PACKAGES
addappid(437526,0,"1b2429359524fd540258b8ffe52d42e56c28e45bc525706704cd35f12dbbf621")
