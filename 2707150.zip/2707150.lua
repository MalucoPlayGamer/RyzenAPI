-- Lua provided by RyzenAPI
-- Game: Aviators VR

-- MAIN APPLICATION
addappid(2707150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707151, 1, "858789cbca9d5aee4ea5e99ce837eab1fbea6e7104efa13463c26d2ccd878365")
