-- Lua provided by RyzenAPI
-- Game: Rytmik Ultimate

-- MAIN APPLICATION
addappid(375840)
addappid(525970)
addappid(525971)
addappid(626650)
addappid(648200)
addappid(697380)
addappid(697410)
addappid(699070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(375841, 1, "85660895d9ce64c25f62bc748377445bcfc4e75c82739f127468cd8163c7e70f")

