-- Lua provided by RyzenAPI
-- Game: Rytmik Ultimate

-- MAIN APPLICATION
addappid(375840)

-- MAIN APP DEPOTS / PACKAGES
addappid(375841, 1, "85660895d9ce64c25f62bc748377445bcfc4e75c82739f127468cd8163c7e70f")
