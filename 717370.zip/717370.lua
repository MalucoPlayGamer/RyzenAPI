-- Lua provided by RyzenAPI
-- Game: Game: AppID 717370

-- MAIN APPLICATION
addappid(717370)
-- Game: addappid(717370)

-- MAIN APP DEPOTS / PACKAGES
addappid(717371, 1, "0d4d3c34db8260fae37d479a9f5180b92c97d3bee0cce84918a0f155f94ccf63")
