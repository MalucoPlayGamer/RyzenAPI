-- Lua provided by RyzenAPI
-- Game: Game: Battle Knights

-- MAIN APPLICATION
addappid(493000)
-- Game: addappid(493000)

-- MAIN APP DEPOTS / PACKAGES
addappid(493001, 1, "7d6b86be7b26619480e5d60056ad506b23e8560fd8e206608591646ddbf25718")
