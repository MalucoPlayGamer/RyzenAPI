-- Lua provided by RyzenAPI
-- Game: Game: Heileen 1: Sail Away

-- MAIN APPLICATION
addappid(302950)
-- Game: addappid(302950)

-- MAIN APP DEPOTS / PACKAGES
addappid(302951, 1, "e3dc1c233760b77e07c87b8957ff0acdfa768d6bc1a41ae8259b687a82e5c028")
