-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade - Justice

-- MAIN APPLICATION
addappid(2431700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431702,0,"5ff3d944b102683645e9ae873cc183c0f06ec98592ec7493f3c71acfa696d69a")

