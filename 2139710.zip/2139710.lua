-- Lua provided by RyzenAPI
-- Game: Stunts Contest Extreme Cars

-- MAIN APPLICATION
addappid(2139710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139711, 1, "b786f8c0be59cdce706aa889786006f0f3fd6fa0662cdeb588795378b165ff47")

