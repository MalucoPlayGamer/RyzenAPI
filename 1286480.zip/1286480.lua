-- Lua provided by RyzenAPI 
-- Game: Fantasy General II: Prologue
addappid(1286480)
addappid(1286481, 1, "c8c33ed5004071d4fa517b4821a44d0c4e24a98065c6030d2170e3a668976d80")
addappid(1286482, 1, "bb89d1c82f5cd81832690e33053d67d8a95b6f63e102d90631b246fea756bf27")
addappid(1286483, 1, "60cbc3caa1e65ddf19fea55cf2d579a6a0027f041358c9e06534cc17256e519b")
