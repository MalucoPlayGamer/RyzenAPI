-- Lua provided by RyzenAPI
-- Game: Nyran Survivors

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2540810)
addappid(2540817)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540813,0,"f54464f0864048bf67b60c2dfeb3ed26b20022700777dcfda4afd385431a1180")

