-- Lua provided by RyzenAPI
-- Game: addappid(3409750)

-- MAIN APPLICATION
addappid(3409750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3409751, 1, "7aa5b8dc7dfffe4b3a933a4c12b8ca4d65575f2d15f94e28dd67150272c7f26f")
