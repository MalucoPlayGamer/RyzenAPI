-- Lua provided by RyzenAPI
-- Game: MEGADEKA

-- MAIN APPLICATION
addappid(3679390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3679391, 1, "bc8c198ffaae7e96b71838dee838b0feb340c431b8a04c15e03fbd8ab801516b")
