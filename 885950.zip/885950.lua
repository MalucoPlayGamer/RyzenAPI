-- Lua provided by SkyAPI 
-- Game: Airranger
addappid(885950)
addappid(885951, 1, "30aeaa3522b0e83016df884e873d4b1e9c541e30abdf26ef5d9129c6cfcecba2")
