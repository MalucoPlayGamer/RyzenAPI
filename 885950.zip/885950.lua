-- Lua provided by RyzenAPI
-- Game: 885950

-- MAIN APPLICATION
addappid(885950)
-- Game: addappid(885950)

-- MAIN APP DEPOTS / PACKAGES
addappid(885951, 1, "30aeaa3522b0e83016df884e873d4b1e9c541e30abdf26ef5d9129c6cfcecba2")
