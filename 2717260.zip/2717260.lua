-- Lua provided by RyzenAPI
-- Game: 2717260

-- MAIN APPLICATION
addappid(2717260)
-- Game: addappid(2717260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717261, 1, "16c2f447a7d5cfb0bbf1344da6ef08babc80277bb02277d3c0296a90999419ec")
