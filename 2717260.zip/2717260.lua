-- Lua provided by RyzenAPI
-- Game: I'm counting to 6...

-- MAIN APPLICATION
addappid(2717260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717261, 1, "16c2f447a7d5cfb0bbf1344da6ef08babc80277bb02277d3c0296a90999419ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
