-- Lua provided by RyzenAPI
-- Game: 880490

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(880490)
addappid(880491)
-- Game: addappid(880490)

-- MAIN APP DEPOTS / PACKAGES
addappid(880492,0,"1ad35bd7b219c23efcdceffa47b1592e2f637aae5a1e64e7832c69f1ae62b431")
