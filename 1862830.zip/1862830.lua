-- Lua provided by RyzenAPI 
-- Game: Lost Artifacts Mysterious Book Collector's Edition
addappid(1862830)
addappid(1862831, 1, "fca8adbbe62c44e5e33df82f6e4c14187b47e290b62c1786edc60d62b0f06e6e")
addappid(1862834, 1, "4d7fa719af08cacab6fd8ab573299693cc16f1720e600f214998aa6e0bee7253")
