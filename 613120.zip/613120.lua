-- Lua provided by RyzenAPI
-- Game: Tank Battle: East Front

-- MAIN APPLICATION
addappid(613120)

-- MAIN APP DEPOTS / PACKAGES
addappid(613121, 1, "4a3dd89d7c1cf1101394b50d5efc96d23793d7859a5168e957c4d96127bbcf78")
addappid(613122, 1, "fd5934455a5c10c1266264b807782b5e63721c004d0df7e232dde63786460a2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
