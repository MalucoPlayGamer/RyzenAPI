-- Lua provided by RyzenAPI
-- Game: Upwards, Lonely Robot

-- MAIN APPLICATION
addappid(417900)

-- MAIN APP DEPOTS / PACKAGES
addappid(417901, 1, "51e608e5b09f6b7a8066883374f3e4b8b7bbe30bce0bae64fbf5b97c9a0fd34a")
