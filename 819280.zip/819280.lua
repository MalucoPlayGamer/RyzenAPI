-- Lua provided by RyzenAPI
-- Game: ZAMB! Endless Extermination

-- MAIN APPLICATION
addappid(819280)

-- MAIN APP DEPOTS / PACKAGES
addappid(819281,0,"ac3d34a25502b74c91b57a941a92e166a3867b0ea8d27e3fc1fa974c26dc7c81")

