-- Lua provided by RyzenAPI
-- Game: 小明明的世界

-- MAIN APPLICATION
addappid(3382580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3382581, 1, "f9d630d3b784a6152e00cab801e33076e7c3dd626183559fbf8acad609f6bfe5")
