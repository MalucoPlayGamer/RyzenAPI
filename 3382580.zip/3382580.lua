-- Lua provided by RyzenAPI
-- Game: 小明明的世界

-- MAIN APPLICATION
addappid(3382580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3382581, 1, "f9d630d3b784a6152e00cab801e33076e7c3dd626183559fbf8acad609f6bfe5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
