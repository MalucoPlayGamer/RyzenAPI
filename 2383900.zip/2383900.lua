-- Lua provided by RyzenAPI 
-- Game: Forbidden Sparks of Passion
addappid(2383900)
addappid(2383901, 1, "1d48075cbe4c0e073213b726eb880372ddeb5114c11435a88b2ef862ee971010")
