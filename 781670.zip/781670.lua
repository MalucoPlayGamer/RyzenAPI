-- Lua provided by RyzenAPI
-- Game: The Directed

-- MAIN APPLICATION
addappid(781670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(781671, 1, "a316f04e1e5e0e76ffcb082fbd33ca52f99bd8b45a7454cfc2e6994d761970f1")

