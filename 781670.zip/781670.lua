-- Lua provided by RyzenAPI
-- Game: addappid(781670)

-- MAIN APPLICATION
addappid(781670)

-- MAIN APP DEPOTS / PACKAGES
addappid(781671, 1, "a316f04e1e5e0e76ffcb082fbd33ca52f99bd8b45a7454cfc2e6994d761970f1")
