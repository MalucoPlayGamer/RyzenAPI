-- Lua provided by RyzenAPI 
-- Game: The Directed
addappid(781670)
addappid(781671, 1, "a316f04e1e5e0e76ffcb082fbd33ca52f99bd8b45a7454cfc2e6994d761970f1")
