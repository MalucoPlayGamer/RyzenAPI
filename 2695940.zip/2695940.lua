-- Lua provided by RyzenAPI
-- Game: PANICORE

-- MAIN APPLICATION
addappid(2695940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695941, 1, "362cab8fdee84b3302e120698fd3affff7563547d750f12594d1e5c5843f2758")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
