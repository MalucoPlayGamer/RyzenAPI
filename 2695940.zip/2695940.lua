-- Lua provided by RyzenAPI
-- Game: 2695940

-- MAIN APPLICATION
addappid(2695940)
-- Game: addappid(2695940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695941, 1, "362cab8fdee84b3302e120698fd3affff7563547d750f12594d1e5c5843f2758")
