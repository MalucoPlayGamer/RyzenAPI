-- Lua provided by RyzenAPI
-- Game: 2269450

-- MAIN APPLICATION
addappid(2269450)
-- Game: addappid(2269450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269452,0,"01f8b3c0e11d8cbfca0f541297c249a041fe71502665967de4ab8ace3b9cf86c")
