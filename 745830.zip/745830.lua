-- Lua provided by RyzenAPI
-- Game: Dragon Sinker

-- MAIN APPLICATION
addappid(745830)

-- MAIN APP DEPOTS / PACKAGES
addappid(745831, 1, "662cef779020d28a568598f1a4db2138b34d7d726403e8a8fe4f5b309981c063")
