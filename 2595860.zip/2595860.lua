-- Lua provided by RyzenAPI
-- Game: 2595860

-- MAIN APPLICATION
addappid(2595860)
-- Game: addappid(2595860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595861, 1, "b195524f4c4facf9a070a85a64a5ed1c2c2eb85b90bfc8a86760da23a038ac90")
