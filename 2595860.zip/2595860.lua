-- Lua provided by RyzenAPI
-- Game: Hitler is my crush

-- MAIN APPLICATION
addappid(2595860)
addappid(4353010)
addappid(4871850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595861, 1, "b195524f4c4facf9a070a85a64a5ed1c2c2eb85b90bfc8a86760da23a038ac90")

