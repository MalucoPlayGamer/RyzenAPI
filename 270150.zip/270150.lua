-- Lua provided by RyzenAPI
-- Game: RUNNING WITH RIFLES

-- MAIN APPLICATION
addappid(270150)

-- MAIN APP DEPOTS / PACKAGES
addappid(270151, 1, "890656b6d838f582c17fb9b320de87e4883dde389e50259d18d7873e91282ea6")
addappid(270152, 1, "e4185b86c5fb333933d68a04e22351de9209cc9681d876ab92ee84588ab30693")
addappid(270153, 1, "081b622c2721167ff54d4bbfa1d115795074855ef60231d22412499495c733a7")
addappid(616850, 0, "a3731982c02f0287168afae9fce0533107fa3a8fe5fd172c2ad7b907b42402f9")
addappid(616851, 0, "c8b28448759a72713ca23367acd929e742a3f756d7fa2407a8d98b18f0b1de34")
addappid(1210750, 0, "b3de81fbc1559878bba58b6af0f1247db203740fc618b9e1beb34b01d7be2a7b")
addappid(1210751, 0, "3cc262b28f0713250840c221816ea30564b228ab7bb8deb4f7bc44ff4173a877")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1962360)
addappid(1962410)
