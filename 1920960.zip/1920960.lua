-- Lua provided by RyzenAPI
-- Game: VPet-Simulator

-- MAIN APPLICATION
addappid(1920960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920961, 1, "f3c1dca72c3176fb5d7a9796466ca62b5c92ca622523560d9a453b18eb257d12")
addappid(1920962, 1, "b794b9f1512eea471fcc6e78eff98d2fff7bcdb475166ad200365ab56cb12cb4")
addappid(1920963, 1, "b32f451d9a2b48559bb18319906ee0a08556499d2e82dde42187a38a325adf12")
addappid(2607351, 0, "f0bc56fa0483749ee2b75d5fb7b0b17e3cce79382e7543ba3fecb2fb6883ec17")
addappid(2639250, 0, "ea76ffc614979026368548287258e7c179eba210d6b7b9b1136fc47888eae322")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2607350)
