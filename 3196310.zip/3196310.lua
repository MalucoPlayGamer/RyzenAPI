-- Lua provided by RyzenAPI
-- Game: MeiQi 2024

-- MAIN APPLICATION
addappid(3196310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3196311, 1, "91826bf287e1c662681cd717751ad39a17628aa0a412d6a7c6464519dd8d1bb4")

