-- Lua provided by RyzenAPI
-- Game: addappid(1536763)

-- MAIN APPLICATION
addappid(1536763)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536763,0,"f6a2ffdd4e9fe63e399fe210313c2bf4fa140ea871a35e10d51aeff3c41c1f6e")
