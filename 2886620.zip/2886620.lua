-- Lua provided by RyzenAPI
-- Game: Hive Blight

-- MAIN APPLICATION
addappid(2886620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886621,0,"6b6f22e887b5b5335dd2a87f4065b13db6a7836051c2ed16fc44cdd46ff1d01f")

