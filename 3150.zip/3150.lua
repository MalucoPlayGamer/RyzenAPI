-- Lua provided by RyzenAPI
-- Game: addappid(3150)

-- MAIN APPLICATION
addappid(3150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151, 1, "9aab03042f75bdb935bc27eac4c37d9f8aa255fd4ac1ed82494dbde3fbfd47ff")
addappid(3152, 1, "07195821f0a066c1ec74e572ba5f9fe8d12ce482fbeba4e174c191753ed1c6da")
