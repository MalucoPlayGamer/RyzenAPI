-- Lua provided by RyzenAPI
-- Game: Secret Hot Springs Girl

-- MAIN APPLICATION
addappid(3031150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3031151, 1, "a7ffe0371f100ed4777fbd4fd39e0f4d25c826d7a75461db5e5c0648c0d8d476")

