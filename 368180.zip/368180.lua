-- Lua provided by RyzenAPI
-- Game: 368180

-- MAIN APPLICATION
addappid(368180)
-- Game: addappid(368180)

-- MAIN APP DEPOTS / PACKAGES
addappid(368181, 1, "db6a8d8d3fa87368befda03258893905a76d02929f3bbe3a8f2e8b0754883793")
addappid(368182, 1, "4daf6779f26a459a6e9bfb8953b916668ab94b8e8edbb766ed0feca94ffbcde7")
addappid(368183, 1, "b85d9d270db2126bb4ae1a8a80863c4a929b055604ec43a5dabcb4efd8998e46")
