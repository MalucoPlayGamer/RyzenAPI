-- Lua provided by RyzenAPI
-- Game: Polyball

-- MAIN APPLICATION
addappid(368180)

-- MAIN APP DEPOTS / PACKAGES
addappid(368181, 1, "db6a8d8d3fa87368befda03258893905a76d02929f3bbe3a8f2e8b0754883793")
addappid(368182, 1, "4daf6779f26a459a6e9bfb8953b916668ab94b8e8edbb766ed0feca94ffbcde7")
addappid(368183, 1, "b85d9d270db2126bb4ae1a8a80863c4a929b055604ec43a5dabcb4efd8998e46")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
