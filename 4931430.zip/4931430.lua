-- Lua provided by RyzenAPI
-- Game: Logic Foundry

-- MAIN APPLICATION
addappid(4931430) -- Logic Foundry
-- addappid(4931432) -- Depot 4931432 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4931431, 1, "ae5668929ab5230919bf800bf8c85a060b080692f5506edbda88b28b431572b5") -- Depot 4931431

