-- 4931430's Lua and Manifest Created by Hubcap Manifest
-- Logic Foundry
-- Created: August 03, 2026 at 14:57:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4931430) -- Logic Foundry
-- MAIN APP DEPOTS
addappid(4931431, 1, "ae5668929ab5230919bf800bf8c85a060b080692f5506edbda88b28b431572b5") -- Depot 4931431
setManifestid(4931431, "3821263777150260283", 524457565)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4931432) -- Depot 4931432 (empty depot)