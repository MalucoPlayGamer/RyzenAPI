-- Lua provided by RyzenAPI
-- Game: Game: Idle Game x100

-- MAIN APPLICATION
addappid(2245700)
-- Game: addappid(2245700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245701, 1, "0fabfd4e3df4b406d80e04f738e2a438b5b44c91f0dae98bcc0887382ebf0504")
