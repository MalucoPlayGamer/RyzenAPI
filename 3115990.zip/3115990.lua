-- Lua provided by RyzenAPI
-- Game: addappid(3115990)

-- MAIN APPLICATION
addappid(3115990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115990,0,"50c6c0ee7c95c21356261a5a2cd3bbf04386b572b993276ef7af16bc93edaa07")
