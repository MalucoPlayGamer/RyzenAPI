-- Lua provided by RyzenAPI
-- Game: Whispers Of Yashan Demo

-- MAIN APPLICATION
addappid(2272260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272261, 1, "30b13d7e442cbe4126baa42cc20d797fea300a876509b9eb5874514e5b5b807e")
