-- Lua provided by SkyAPI 
-- Game: Whispers Of Yashan Demo
addappid(2272260)
addappid(2272261, 1, "30b13d7e442cbe4126baa42cc20d797fea300a876509b9eb5874514e5b5b807e")
