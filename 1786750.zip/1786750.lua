-- Lua provided by RyzenAPI
-- Game: Game: Runaway Princess

-- MAIN APPLICATION
addappid(1786750)
addappid(2568660)
-- Game: addappid(1786750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786751, 1, "31f822751a7f083992d769738ff61f57dd4d3a0edfd527bc405bc72b0d462067")
