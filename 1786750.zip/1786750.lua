-- Lua provided by SkyAPI 
-- Game: Runaway Princess
addappid(1786750)
addappid(1786751, 1, "31f822751a7f083992d769738ff61f57dd4d3a0edfd527bc405bc72b0d462067")
addappid(2568660)
