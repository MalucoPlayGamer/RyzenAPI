-- Lua provided by RyzenAPI
-- Game: 1566230

-- MAIN APPLICATION
addappid(1566230)
-- Game: addappid(1566230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566231, 1, "6def6d813c0e3018fba31fa3f273b041e164eda3a069fef3ac854061c3044857")
