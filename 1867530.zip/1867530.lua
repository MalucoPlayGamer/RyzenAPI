-- Lua provided by RyzenAPI
-- Game: Solar Ash

-- MAIN APPLICATION
addappid(1867530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867531, 1, "a999404da0beba5bf8330452fcefc8ddc18780dc81259a4209c63d8cef2dc987")

