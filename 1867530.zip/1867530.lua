-- Lua provided by SkyAPI 
-- Game: Solar Ash
addappid(1867530)
addappid(1867531, 1, "a999404da0beba5bf8330452fcefc8ddc18780dc81259a4209c63d8cef2dc987")
