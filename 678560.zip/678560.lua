-- Lua provided by RyzenAPI
-- Game: addappid(678560)

-- MAIN APPLICATION
addappid(678560)

-- MAIN APP DEPOTS / PACKAGES
addappid(678561, 1, "aa7f920c7a102e766504095d2f44e21e763fd98b0f1897c74c44dcf9e2886c06")
