-- Lua provided by RyzenAPI
-- Game: CS Diamantes Pipas PC : Jogo de pipa

-- MAIN APPLICATION
addappid(1851200)
addappid(3399340) -- CS Diamantes Pipas: DLC VIP Member
addappid(3399350) -- CS Diamantes Pipas: DLC PASE Member
addappid(4590430) -- CS Diamantes Pipas - Mobile Sync

-- MAIN APP DEPOTS / PACKAGES
addappid(1851201, 1, "655c8218c06d50701c644dde3bd8efa1da411be899b2f2360424a0d781f0c7ac")

