-- Lua provided by RyzenAPI 
-- Game: CS Diamantes Pipas PC : Jogo de pipa
addappid(1851200)
addappid(1851201, 1, "655c8218c06d50701c644dde3bd8efa1da411be899b2f2360424a0d781f0c7ac")
