-- Lua provided by RyzenAPI
-- Game: 1851200

-- MAIN APPLICATION
addappid(1851200)
-- Game: addappid(1851200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851201, 1, "655c8218c06d50701c644dde3bd8efa1da411be899b2f2360424a0d781f0c7ac")
