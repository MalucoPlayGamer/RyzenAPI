-- Lua provided by RyzenAPI
-- Game: 2699780

-- MAIN APPLICATION
addappid(2699780)
-- Game: addappid(2699780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699781, 1, "76066f6f50049e5de0b133195f4464ef4fcfc4a3eee44bb523ebe4dc13e5269f")
