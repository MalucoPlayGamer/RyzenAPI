-- Lua provided by RyzenAPI 
-- Game: AppID 1949340
addappid(1949340)
addappid(1949341, 1, "9e1057e6db570c728cc785529bb011c32f9984f7e1595f657e1b2186b3a49077")
addappid(1968580, 0, "26d7d726cda94bfec59fe16bf6eec13c5925ae0a01806b515b6e49b4106ac830")
