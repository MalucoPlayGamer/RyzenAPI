-- Lua provided by RyzenAPI
-- Game: 673190

-- MAIN APPLICATION
addappid(673190)
addappid(752540)
-- Game: addappid(673190)

-- MAIN APP DEPOTS / PACKAGES
addappid(673191, 1, "93520c9fcd93f706c13cbf60290ca6392cbb25fa14ea2ff5e6b6be312874e061")
