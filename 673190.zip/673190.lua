-- Lua provided by RyzenAPI
-- Game: All-Star Fruit Racing

-- MAIN APPLICATION
addappid(673190)
addappid(752540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(673191, 1, "93520c9fcd93f706c13cbf60290ca6392cbb25fa14ea2ff5e6b6be312874e061")

