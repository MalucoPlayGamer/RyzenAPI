-- Lua provided by RyzenAPI
-- Game: Les Manley in: Lost in L.A.

-- MAIN APPLICATION
addappid(1299730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299731, 1, "b3ee6fb40ffe1167d87092cd530a99725943faa80d97f09197b56483665927f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
