-- Lua provided by RyzenAPI
-- Game: AppID 348460

-- MAIN APPLICATION
addappid(348460)
addappid(404120)

-- MAIN APP DEPOTS / PACKAGES
addappid(348461, 1, "ebb535a3ec7a2de1002d3564af36087d86c363784d9e7ce7ee8d9d0a207a1ea7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(422290)
addappid(437300)
addappid(437301)
addappid(437302)
addappid(437303)
