-- Lua provided by RyzenAPI
-- Game: AppID 348460

-- MAIN APPLICATION
addappid(348460)
addappid(404120)

-- MAIN APP DEPOTS / PACKAGES
addappid(348461, 1, "ebb535a3ec7a2de1002d3564af36087d86c363784d9e7ce7ee8d9d0a207a1ea7")

