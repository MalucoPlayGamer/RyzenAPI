-- Lua provided by RyzenAPI
-- Game: Game: Boo Men

-- MAIN APPLICATION
addappid(1715730)
-- Game: addappid(1715730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715731, 1, "a24613787471dca234047252a127bb7c21954ad9298ac21a3af25804d8ea7226")
