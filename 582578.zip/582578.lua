-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport Zurich V2

-- MAIN APPLICATION
addappid(582578)

-- MAIN APP DEPOTS / PACKAGES
addappid(615810,0,"8ff533327d6270c750ddb9f1789c8359262b4301238008d79e3fcf487fa8ed57")
