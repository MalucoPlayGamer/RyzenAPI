-- Lua provided by SkyAPI 
-- Game: Zombie Camp: Last Survivor
addappid(357840)
addappid(357841, 1, "1e6d3e2646684b0b034bfa2f1894c1b59a09de5a974bf12d63a9bb75173063b0")
