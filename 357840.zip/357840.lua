-- Lua provided by RyzenAPI
-- Game: 357840

-- MAIN APPLICATION
addappid(357840)
-- Game: addappid(357840)

-- MAIN APP DEPOTS / PACKAGES
addappid(357841, 1, "1e6d3e2646684b0b034bfa2f1894c1b59a09de5a974bf12d63a9bb75173063b0")
