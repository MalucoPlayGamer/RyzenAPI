-- Lua provided by RyzenAPI
-- Game: Terafall: Survival

-- MAIN APPLICATION
addappid(1566220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566226,0,"468e304579bd03586d77e06348ffa12d7b945daca6e2b76bd8502d4e05078e46")

