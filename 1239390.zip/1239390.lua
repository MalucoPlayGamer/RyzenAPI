-- Lua provided by RyzenAPI 
-- Game: AppID 1239390
addappid(1239390)
addappid(1239391, 1, "4dbdf1a0cda773f0c4d8c15d8c8cba5d9adb127da723c4e93cffe710a60e00f1")
addappid(1239392, 1, "64c2eb04d1ea44ca8eb3dc65d336596dcc67ad12ec81b4d9fb52429ca866acc0")
