-- Lua provided by RyzenAPI
-- Game: AppID 1230210

-- MAIN APPLICATION
addappid(1230210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230211, 1, "039cf04e0dd586a7e25f8ba95a6b78eee37076a73fbcb7543c09b049fd9de9bc")

