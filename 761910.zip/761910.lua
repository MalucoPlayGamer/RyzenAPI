-- Lua provided by RyzenAPI
-- Game: Worbital

-- MAIN APPLICATION
addappid(761910)
-- Game: addappid(761910)

-- MAIN APP DEPOTS / PACKAGES
addappid(761912,0,"87dba011284e3b674a9aea122bc29512db7f791d1039b1d7364ec9b24a67a00f")
