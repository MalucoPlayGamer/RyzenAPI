-- Lua provided by RyzenAPI
-- Game: Game: OMG Words

-- MAIN APPLICATION
addappid(2884080)
-- Game: addappid(2884080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884081, 1, "e2070f919c7cb7fcd99ffbf7bbcf0ee0400a05b7dea120d7bec5e564a3d36d19")
