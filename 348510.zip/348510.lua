-- Lua provided by RyzenAPI 
-- Game: AppID 348510
addappid(348510)
addappid(348511, 1, "e2b9976e3aba33552201996cb14893386dbb6c0e491747f8db3ac8bb8cb93b40")
addappid(348512, 1, "1654e91703bbc6ec5ec914c4d9789f3d798536fc7559696f2d8954fac0a4e4e3")
