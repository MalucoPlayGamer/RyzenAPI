-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1621476)
addappid(1922461)
addappid(1922462)
addappid(1922463)
addappid(1922464)
addappid(1922465)
addappid(1922468)
addappid(1922469)
addappid(1922471)
addappid(1922472)
addappid(1922473)
addappid(1922474)
addappid(1922475)
addappid(1922476)
addappid(1922477)
-- Game: addappid(1621476)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621476,0,"09b646f0f1a1fcce97d324325ae2f5a8a357c7c317344feebd991fa23790d42a")
addappid(1922460,0,"4f947614f1fe8583c5aaa10705163c5feb90887336991eaf441f07e96826f6c3")
addappid(1922466,0,"b6e7949e9f8279b311bd04ba88b932875de4f8baf6cc12690f498b12c8e937e2")
addappid(1922467,0,"6b3b14b3576e2dce900df80ede315898fa34433ccdaf755798507d12f60b629d")
addappid(1922470,0,"0d18c524584d3d03f41551a8f93f72b0fa08919a742299a038b68ee6e1981b1e")
