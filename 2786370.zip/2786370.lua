-- Lua provided by RyzenAPI
-- Game: 乱世群雄

-- MAIN APPLICATION
addappid(2786370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786371, 1, "f5264c42070db0034f7ef60db5e69556e0c7e86959286bec0131070ea13ffca3")

