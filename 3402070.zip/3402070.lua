-- Lua provided by RyzenAPI
-- Game: Sexy Furry - Sheep Furry DLC

-- MAIN APPLICATION
addappid(3402070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402070,0,"9a5d6e9b3786192aa5270a80fac0f30c9f72819f7db14071d48483dcb9917f20")

