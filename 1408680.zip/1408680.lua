-- Lua provided by RyzenAPI
-- Game: Game: Nine to Five

-- MAIN APPLICATION
addappid(1408680)
-- Game: addappid(1408680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408681, 1, "0601d11225662a824c8549e4ea187d5ce20888ae28ce15e5234d7205f4a8583a")
