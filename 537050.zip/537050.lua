-- Lua provided by RyzenAPI
-- Game: AppID 537050

-- MAIN APPLICATION
addappid(537050)

-- MAIN APP DEPOTS / PACKAGES
addappid(537051, 1, "7d8faf9330ac03d1e8f894fdc953dc6161c75563155dfdd80a9db31bdc605f48")
