-- Lua provided by RyzenAPI
-- Game: The Mildew Children

-- MAIN APPLICATION
addappid(2420350)
-- Game: addappid(2420350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420351, 1, "1ab8448fc5723c83955a6870103455ee4c3789dce29102377a858147da5ebd59")
