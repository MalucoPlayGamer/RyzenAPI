-- Lua provided by RyzenAPI
-- Game: The Mildew Children

-- MAIN APPLICATION
addappid(2420350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420351, 1, "1ab8448fc5723c83955a6870103455ee4c3789dce29102377a858147da5ebd59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3501930)
