-- Lua provided by RyzenAPI
-- Game: 3607190

-- MAIN APPLICATION
addappid(3607190)
-- Game: addappid(3607190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3607191, 1, "d9321ff4764fc9f36c1afa93a4f31bd878dc35eec94c10d37e7e3c9fcb488eaf")
