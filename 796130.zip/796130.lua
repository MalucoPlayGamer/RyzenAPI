-- Lua provided by RyzenAPI
-- Game: Game: Virus Petya

-- MAIN APPLICATION
addappid(796130)
addappid(799280)
-- Game: addappid(796130)

-- MAIN APP DEPOTS / PACKAGES
addappid(796131, 1, "70852b87952d9a777ddc8a49878f81b10e350a3fae529808985a4d279515e473")
