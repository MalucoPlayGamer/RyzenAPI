-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 Personality Pack Friendly and Slightly Naughty Woman DLX edition

-- MAIN APPLICATION
addappid(2510840)
-- Game: addappid(2510840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510841, 1, "0f061eb516521865925040782c20ee277bade66d5cb0341b80df952c385e4053")
