-- Lua provided by RyzenAPI
-- Game: Blackbeard the Cursed Jungle

-- MAIN APPLICATION
addappid(1151310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151311, 1, "cb17f5e72f2c754d014eac61c8815935525ffc51955b50caa7345b010a6cc083")
