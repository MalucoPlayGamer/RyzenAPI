-- Lua provided by RyzenAPI
-- Game: 3303790

-- MAIN APPLICATION
addappid(3303790)
-- Game: addappid(3303790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3303791, 1, "0bb27ccec2a4c69e09bb9475996623e17ee0910d20a44802bcb63df8785d2ff4")
