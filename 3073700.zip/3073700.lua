-- Lua provided by RyzenAPI
-- Game: 3073700

-- MAIN APPLICATION
addappid(3073700)
-- Game: addappid(3073700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073701, 1, "4110d04a3b84929256dbb03d4d616d638c9a32cfdd0ba3e6a12d742a9189887f")
