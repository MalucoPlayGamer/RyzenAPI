-- Lua provided by RyzenAPI 
-- Game: Raccoon on a boat
addappid(3073700)
addappid(3073701, 1, "4110d04a3b84929256dbb03d4d616d638c9a32cfdd0ba3e6a12d742a9189887f")
