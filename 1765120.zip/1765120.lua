-- Lua provided by RyzenAPI
-- Game: AppID 1765120

-- MAIN APPLICATION
addappid(1765120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765121, 1, "3ff38af14d322e73620c80e550f8d13bb236cdbe3fe7d7ab16c3fda69847b7f6")

