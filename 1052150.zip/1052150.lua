-- Lua provided by RyzenAPI
-- Game: WoozyHero 乌贼英雄-欢乐联机版

-- MAIN APPLICATION
addappid(1052150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052151, 1, "314f9ffdee96d043a5199d1b186ad2ef8073cb691527487b44c1f1c0e90dad9f")
