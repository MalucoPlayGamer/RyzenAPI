-- Lua provided by RyzenAPI
-- Game: Cyberpunk Madness

-- MAIN APPLICATION
addappid(1554380)
-- Game: addappid(1554380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554381, 1, "91210b99956cdd7a49d070a4b1ccd5a453a970ca706bc71f44668415a1dcc160")
