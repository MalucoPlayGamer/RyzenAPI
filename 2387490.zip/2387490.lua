-- Lua provided by SkyAPI 
-- Game: AppID 2387490
addappid(2387490)
addappid(2387491, 1, "22afe6e4a8a790c82b1270afc9bcb0e7a93c8dc7a7a891f95310b766ccfd24f5")
