-- Lua provided by RyzenAPI
-- Game: Game: AppID 2387490

-- MAIN APPLICATION
addappid(2387490)
-- Game: addappid(2387490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387491, 1, "22afe6e4a8a790c82b1270afc9bcb0e7a93c8dc7a7a891f95310b766ccfd24f5")
