-- Lua provided by RyzenAPI
-- Game: Skald: Against the Black Priory - the Prologue

-- MAIN APPLICATION
addappid(1609100)
-- Game: addappid(1609100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609101, 1, "44efb52a81fc4f842a726d89954247a65bf537aecbc1364cfc4f5f06f9bcb63a")
