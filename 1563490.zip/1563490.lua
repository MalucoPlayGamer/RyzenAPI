-- Lua provided by RyzenAPI
-- Game: Doggone Hungry

-- MAIN APPLICATION
addappid(1563490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563491, 1, "d4b5d94eba662b8129b8df3299f0c4bdf6e2697df7226024a9cceae6ce12a67b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
