-- Lua provided by RyzenAPI
-- Game: Game: Doggone Hungry

-- MAIN APPLICATION
addappid(1563490)
-- Game: addappid(1563490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563491, 1, "d4b5d94eba662b8129b8df3299f0c4bdf6e2697df7226024a9cceae6ce12a67b")
