-- Lua provided by RyzenAPI
-- Game: Star Stuff

-- MAIN APPLICATION
addappid(1955110)
-- Game: addappid(1955110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955111, 1, "4deb7909fe04531db2c03abd6bebfa3d5d42eebdc63675908161bf1bda9bca88")
