-- Lua provided by RyzenAPI
-- Game: 2412240

-- MAIN APPLICATION
addappid(2412240)
-- Game: addappid(2412240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412241, 1, "1509e9f216704350465db1899294cfd0da5dd3cc3c0abe54ff4b01469f2ad76e")
addappid(3699090, 0, "78b3704014041b2a4425aab3be126dcef3b3764459cc9c8910eac534cad3a5f3")
