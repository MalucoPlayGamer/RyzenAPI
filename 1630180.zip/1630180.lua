-- Lua provided by RyzenAPI
-- Game: Game: The hidden game society

-- MAIN APPLICATION
addappid(1630180)
-- Game: addappid(1630180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630181, 1, "2e6d31b27e14c013e9f2e5ee27e431e3ca409ba37accfe34087598942e93475f")
