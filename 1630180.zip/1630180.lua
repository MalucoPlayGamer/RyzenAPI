-- Lua provided by RyzenAPI 
-- Game: The hidden game society
addappid(1630180)
addappid(1630181, 1, "2e6d31b27e14c013e9f2e5ee27e431e3ca409ba37accfe34087598942e93475f")
