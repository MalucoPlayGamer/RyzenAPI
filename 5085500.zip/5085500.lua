-- Lua provided by RyzenAPI
-- Game: Fireboy & Watergirl 3: The Ice Temple

-- MAIN APPLICATION
addappid(5085500) -- Fireboy & Watergirl 3: The Ice Temple

-- MAIN APP DEPOTS / PACKAGES
addappid(5085501, 1, "040a071dd51ba9fba51237b2f8b13683fb8c788eb6adafeb3dafc8f35876573b") -- Depot 5085501
