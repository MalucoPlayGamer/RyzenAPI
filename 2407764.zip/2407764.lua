-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2407764)
-- Game: addappid(2407764)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407764,0,"7259b9a968598010766a15ef2421f8884554da0d529fd41e3e12a459f8dcb44d")
