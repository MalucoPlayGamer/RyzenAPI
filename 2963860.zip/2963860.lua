-- Lua provided by RyzenAPI
-- Game: 2963860

-- MAIN APPLICATION
addappid(2963860)
-- Game: addappid(2963860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963861, 1, "4b7eec669d2c7ce29bcd5272253356ab2af4850adfe9bb329e04f5aeb1721ef0")
