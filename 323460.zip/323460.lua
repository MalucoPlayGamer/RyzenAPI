-- Lua provided by RyzenAPI
-- Game: Raiden IV: OverKill

-- MAIN APPLICATION
addappid(323460)
-- Game: addappid(323460)

-- MAIN APP DEPOTS / PACKAGES
addappid(323461, 1, "0ef3e25cdaa932f8e9c2291cf19ab90e95276b33670b1a8b706e84187ffd2dc6")
