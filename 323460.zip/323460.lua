-- Lua provided by RyzenAPI
-- Game: Raiden IV: OverKill

-- MAIN APPLICATION
addappid(323460)

-- MAIN APP DEPOTS / PACKAGES
addappid(323461, 1, "0ef3e25cdaa932f8e9c2291cf19ab90e95276b33670b1a8b706e84187ffd2dc6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
