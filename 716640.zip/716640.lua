-- Lua provided by RyzenAPI
-- Game: AppID 716640

-- MAIN APPLICATION
addappid(716640)

-- MAIN APP DEPOTS / PACKAGES
addappid(716641, 1, "20a7832f827e63157fde9e377d779fa34496288a2d37added2ab82b8c53d77e1")
addappid(716642, 1, "358d408cd8426bc0fc19e9b4a06318089be3257548b47fff946d7dfbc77934c9")
addappid(716643, 1, "49b831600f7b08e2ef6b95db7d96dfce8836852fb88477ccc60d9603f407267a")
addappid(966710, 0, "ca0f09e956e55c5faba68e76fe0bdbb06f76d1484985399d31b18b7c59c81261")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1243710)
addappid(1313010)
