-- Lua provided by RyzenAPI
-- Game: Disaster Blaster

-- MAIN APPLICATION
addappid(3194600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194601, 1, "c8995a94b1cb373fe94551baae8e4d53c77dc78e1ad7535c6c63ff62d1583c4e")
