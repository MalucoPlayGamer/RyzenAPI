-- Lua provided by RyzenAPI
-- Game: 960030

-- MAIN APPLICATION
addappid(960030)
-- Game: addappid(960030)

-- MAIN APP DEPOTS / PACKAGES
addappid(960031, 1, "e43c9af36c2cdf088ff9fa6115f17ce812ca08364cb52498287a231843fd464c")
