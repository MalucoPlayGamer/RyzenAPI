-- Lua provided by RyzenAPI
-- Game: Game: Dungeons of Blood and Dream

-- MAIN APPLICATION
addappid(2488590)
-- Game: addappid(2488590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488591, 1, "39e6d78db452b3c861d20b30e072883f6d8a53aefc7efc590023d4cbd390a980")
