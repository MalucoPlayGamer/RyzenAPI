-- Lua provided by RyzenAPI
-- Game: AIRHEART - Tales of broken Wings

-- MAIN APPLICATION
addappid(531180)
addappid(531181)
addappid(531182)
-- Game: addappid(531180)

-- MAIN APP DEPOTS / PACKAGES
addappid(531183,0,"6be22d2c3649798057ec2f9bcd732121ed05181f8f4510a7121c078ae8ae827f")
addappid(540220,0,"1e5a7ce4ccda033733b372540a2ab77530f7cd41d33793c243028a4e765f5023")
addappid(542190,0,"d9f9eac8776cdfc88708bb310af7a9bcf10fdef9048a86b04d5fb8529aaff6c6")
