-- Lua provided by RyzenAPI
-- Game: addappid(839420)

-- MAIN APPLICATION
addappid(839420)

-- MAIN APP DEPOTS / PACKAGES
addappid(839421, 1, "f5ccc4d8f7d32fc95204e49952f93b4c28f082e2f514e50ed4ed68cb53b88ded")
