-- Lua provided by RyzenAPI
-- Game: Jupiteration

-- MAIN APPLICATION
addappid(592240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(592241, 1, "dc02299517e55eabb8ac7b7b683849dfdb50daa9a993f51d92c493a57d9a41e2")

