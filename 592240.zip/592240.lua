-- Lua provided by RyzenAPI
-- Game: AppID 592240

-- MAIN APPLICATION
addappid(592240)

-- MAIN APP DEPOTS / PACKAGES
addappid(592241, 1, "dc02299517e55eabb8ac7b7b683849dfdb50daa9a993f51d92c493a57d9a41e2")
