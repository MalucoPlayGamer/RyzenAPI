-- Lua provided by RyzenAPI
-- Game: Survivors of the Dawn

-- MAIN APPLICATION
addappid(2285630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285631, 1, "ad830b59d924cc37b092256c4ce1af5a5042852e38e21702f4e6a0965a9a53ac")
addappid(2285639, 1, "38f61ea91833723297fde22d2a91da8b924279980e6e0ccb251c8dea75acb4fd")

