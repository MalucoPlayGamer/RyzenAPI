-- Lua provided by RyzenAPI
-- Game: The Backrooms 1998 - Found Footage Survival Horror Game

-- MAIN APPLICATION
addappid(1985930)
-- Game: addappid(1985930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985931, 1, "b42361c597e99fcf5224503d020088dfa9d685a4582938140223800ef79158a4")
