-- Lua provided by RyzenAPI
-- Game: Tales of Rein Ravine

-- MAIN APPLICATION
addappid(2299740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299741, 1, "876fc77e1050ebbfa8b575cbc4a7ce857d71162614a3c355d62b48797517caa8")
