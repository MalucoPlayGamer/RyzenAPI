-- Lua provided by RyzenAPI
-- Game: AppID 668970

-- MAIN APPLICATION
addappid(668970)
-- Game: addappid(668970)

-- MAIN APP DEPOTS / PACKAGES
addappid(668971, 1, "2dae829601a8e267d9b97af5b00f895c9fd22eb6bd75b207a43122d6d9a4a00a")
