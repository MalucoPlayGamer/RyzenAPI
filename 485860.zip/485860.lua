-- Lua provided by RyzenAPI
-- Game: Impossible Quest

-- MAIN APPLICATION
addappid(485860)

-- MAIN APP DEPOTS / PACKAGES
addappid(485861, 1, "9a1d0602fd6d20d2048dabe505939024e988c8d0c624946eb9539f1e14c4fd54")
