-- Lua provided by RyzenAPI
-- Game: 末日装甲 Playtest

-- MAIN APPLICATION
addappid(2922040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922041, 1, "9293e3bc4bf2d11306667d6ffbe8bafa53d3b84569e013f5d090635973bdcde1")
