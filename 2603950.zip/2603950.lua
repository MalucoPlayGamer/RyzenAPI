-- Lua provided by RyzenAPI 
-- Game: Timeline 拯救存档 -Manage your game save
addappid(2603950)
addappid(2603951, 1, "765846738d01f077fbdf07fb70bb651f6887dd178ac8bb19c7b6aaa7b9a14baa")
