-- Lua provided by RyzenAPI 
-- Game: AppID 953880
addappid(953880)
addappid(953881, 1, "ce1fdb3e32096060b07aa5974520c9f9dd7fb35346b6a38725bde5e8fa684f30")
