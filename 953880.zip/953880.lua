-- Lua provided by RyzenAPI
-- Game: First Class Trouble

-- MAIN APPLICATION
addappid(953880)
addappid(1611050)
addappid(1749280)
addappid(1749281)
addappid(1749282)
addappid(1749283)
addappid(1749284)
addappid(1783790)
addappid(1840110)
addappid(1881330)
addappid(1910530)
addappid(1951600)
addappid(2025040)
addappid(2108660)
addappid(4755130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(953881,0,"ce1fdb3e32096060b07aa5974520c9f9dd7fb35346b6a38725bde5e8fa684f30")

