-- Lua provided by RyzenAPI
-- Game: These nights in Cairo

-- MAIN APPLICATION
addappid(612100)

-- MAIN APP DEPOTS / PACKAGES
addappid(612101, 1, "cd2ab21d277a9bb7088469b0869cc5aa2fd6022ce4a54e6be82c01a9ed9be659")

