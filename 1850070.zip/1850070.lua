-- Lua provided by RyzenAPI
-- Game: Fireteam

-- MAIN APPLICATION
addappid(1850070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1850071, 1, "dbcd95c34ed21e2e1c6d112797fc634dd0d123c7eca91dfe433ca10b093577d8")

