-- Lua provided by RyzenAPI
-- Game: Game: Fireteam

-- MAIN APPLICATION
addappid(1850070)
-- Game: addappid(1850070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850071, 1, "dbcd95c34ed21e2e1c6d112797fc634dd0d123c7eca91dfe433ca10b093577d8")
