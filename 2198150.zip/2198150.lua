-- Lua provided by RyzenAPI
-- Game: Tiny Glade

-- MAIN APPLICATION
addappid(2198150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198151, 1, "a64cc2160b07e8fd86f1a2f001987b46e6760e59b3e0ac07915743a4eb695bac")
addappid(2198152, 1, "ef668181df894c351bdd06264513360aebd32539049befc1f36deae429957b8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
