-- Lua provided by RyzenAPI
-- Game: Game: Tiny Glade

-- MAIN APPLICATION
addappid(2198150)
-- Game: addappid(2198150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198151, 1, "a64cc2160b07e8fd86f1a2f001987b46e6760e59b3e0ac07915743a4eb695bac")
addappid(2198152, 1, "ef668181df894c351bdd06264513360aebd32539049befc1f36deae429957b8c")
