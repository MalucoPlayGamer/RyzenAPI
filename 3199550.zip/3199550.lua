-- Lua provided by RyzenAPI
-- Game: Game: Let's Beer Together! Demo

-- MAIN APPLICATION
addappid(3199550)
-- Game: addappid(3199550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199551, 1, "d58e004509c625a686f9166572d60551f02b36ecdb2f34995349389c4face253")
