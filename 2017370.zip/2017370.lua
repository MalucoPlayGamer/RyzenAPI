-- Lua provided by RyzenAPI
-- Game: Game: Trash Horror Collection

-- MAIN APPLICATION
addappid(2017370)
-- Game: addappid(2017370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017371, 1, "5afa29ed36e389c61a63d3321cc176d7b8bf26325ecee0c7428ee116d25af612")
