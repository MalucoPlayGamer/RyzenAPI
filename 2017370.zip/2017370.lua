-- Lua provided by SkyAPI 
-- Game: Trash Horror Collection
addappid(2017370)
addappid(2017371, 1, "5afa29ed36e389c61a63d3321cc176d7b8bf26325ecee0c7428ee116d25af612")
