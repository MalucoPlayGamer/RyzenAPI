-- Lua provided by RyzenAPI
-- Game: addappid(354750)

-- MAIN APPLICATION
addappid(354750)

-- MAIN APP DEPOTS / PACKAGES
addappid(354751, 1, "cfd084e942585673a2e2f3af9ab12dcb16a24f4c7063c9e22074018ee38342f6")
addappid(354752, 1, "0df6c741f49594f961b40e97ddfd5f2c1cd89a3de3e5b66a02d605c765ddcd90")
addappid(354753, 1, "648dedfef6d993fad55a7cc66cdc7eff4c18ac9d1212e34600beeec40d0508c7")
