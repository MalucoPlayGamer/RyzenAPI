-- Lua provided by RyzenAPI
-- Game: addappid(1311980)

-- MAIN APPLICATION
addappid(1311980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311981, 1, "088cc36c64af623dfba79214c5ba2b409fd85671ab20b0d26caf143aa122e015")
