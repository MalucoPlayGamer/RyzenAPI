-- Lua provided by RyzenAPI
-- Game: Simulation world

-- MAIN APPLICATION
addappid(1519640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519641, 1, "cd1912ffc4dd40def9bb2665c54e3508107fb436f44990f23ca94d209bee8176")
