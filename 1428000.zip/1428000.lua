-- Lua provided by RyzenAPI
-- Game: addappid(1428000)

-- MAIN APPLICATION
addappid(1428000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428000,0,"b9b10f720bd167435ec7721c7acf2263b6cb9a77b7f72d38a66f35e0ab1e69d4")
