-- Lua provided by RyzenAPI
-- Game: addappid(2493250)

-- MAIN APPLICATION
addappid(2493250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493251, 1, "44cac1d773156067c8147da46817fc2b3e5ad3e26a9a5e1b13c8b4f972c214eb")
