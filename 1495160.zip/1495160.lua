-- Lua provided by RyzenAPI
-- Game: 1495160

-- MAIN APPLICATION
addappid(1495160)
-- Game: addappid(1495160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495160,0,"cdb6d27732d97031d7e0e67aaeaa88dc88078765c30c1f82bcac0d1dddad804f")
