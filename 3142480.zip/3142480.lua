-- Lua provided by RyzenAPI
-- Game: Endzone 2: Wallpaper Pack

-- MAIN APPLICATION
addappid(3142480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142480,0,"4ea89a642735f6b393f43e6955abb72aa78b652ee20420c3d874ddd29d1f9b96")

