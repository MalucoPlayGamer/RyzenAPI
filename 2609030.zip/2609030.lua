-- Lua provided by RyzenAPI
-- Game: Robot

-- MAIN APPLICATION
addappid(2609030)
-- Game: addappid(2609030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609031, 1, "994bf8c547925db7fc3b506a746dc180b078454933fe512a0e58ab9350940924")
