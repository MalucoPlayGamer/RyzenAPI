-- Lua provided by RyzenAPI
-- Game: Game: AppID 1151180

-- MAIN APPLICATION
addappid(1151180)
-- Game: addappid(1151180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151181, 1, "481d3aab4748f8619d0682bf31169dd61ad8aaf17a588837019b579a477f2945")
