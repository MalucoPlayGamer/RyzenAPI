-- Lua provided by RyzenAPI
-- Game: Super Cucho

-- MAIN APPLICATION
addappid(1151180)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1151181, 1, "481d3aab4748f8619d0682bf31169dd61ad8aaf17a588837019b579a477f2945")
