-- Lua provided by RyzenAPI
-- Game: Castle Story OST

-- MAIN APPLICATION
addappid(758720)
-- Game: addappid(758720)

-- MAIN APP DEPOTS / PACKAGES
addappid(758720,0,"cad7511f33ffd35754931f1046589edb34976dddaf0079104f81226cba9b22cb")
