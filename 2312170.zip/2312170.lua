-- Lua provided by RyzenAPI
-- Game: pWordle

-- MAIN APPLICATION
addappid(2312170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312171, 1, "08194df7c786953d0c03642138a8e61762421c1ca66a77758f68b70a9be791ad")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2385070)
addappid(2385071)
