-- Lua provided by RyzenAPI 
-- Game: pWordle
addappid(2312170)
addappid(2312171, 1, "08194df7c786953d0c03642138a8e61762421c1ca66a77758f68b70a9be791ad")
