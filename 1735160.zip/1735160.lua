-- Lua provided by RyzenAPI
-- Game: 1735160

-- MAIN APPLICATION
addappid(1735160)
-- Game: addappid(1735160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735161, 1, "29d8cbb5659b32b8e67184a6d764a03508485ea757a1faaabcfe6db19638fcda")
