-- Lua provided by RyzenAPI
-- Game: 1842380

-- MAIN APPLICATION
addappid(1842380)
-- Game: addappid(1842380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842381, 1, "0f6b5859eaa8e8ec9148e7e10b6c184e53e9d20287ddb695db3aa09244753a98")
