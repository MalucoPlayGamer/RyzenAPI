-- Lua provided by SkyAPI 
-- Game: AppID 1482820
addappid(1482820)
addappid(1482821, 1, "08d1633591cbd61233ef2f8f48e1785e920b60fcd26fb3bedcc5d84bfe0c2255")
