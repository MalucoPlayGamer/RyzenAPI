-- Lua provided by RyzenAPI
-- Game: Void Marauders

-- MAIN APPLICATION
addappid(1482820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482821, 1, "08d1633591cbd61233ef2f8f48e1785e920b60fcd26fb3bedcc5d84bfe0c2255")
