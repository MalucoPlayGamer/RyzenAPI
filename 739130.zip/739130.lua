-- Lua provided by RyzenAPI
-- Game: The Executioner

-- MAIN APPLICATION
addappid(739130)

-- MAIN APP DEPOTS / PACKAGES
addappid(739131, 1, "600c75a102b39c53effb5da2e82a002fc7138f4977dd96d015f1af7b5eec4b87")
addappid(1170410, 0, "09afec6d8319286867b52a297228e491a0fec7df9795fe35ad8fbced508e66c3")
