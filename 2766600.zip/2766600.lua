-- Lua provided by RyzenAPI
-- Game: 2766600

-- MAIN APPLICATION
addappid(2766600)
-- Game: addappid(2766600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766601, 1, "f4fa84957305362af4eee6780222a5a799e565fa75571b1c77acce4d386d8f4c")
