-- Lua provided by SkyAPI 
-- Game: Geometry raid
addappid(2766600)
addappid(2766601, 1, "f4fa84957305362af4eee6780222a5a799e565fa75571b1c77acce4d386d8f4c")
