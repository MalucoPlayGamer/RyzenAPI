-- Lua provided by RyzenAPI
-- Game: Genopanic

-- MAIN APPLICATION
addappid(1984190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984191, 1, "6b77b69487ce6d4785fefce64c74ca085bd3d24646ab2249c9e9a4319f20e4da")
