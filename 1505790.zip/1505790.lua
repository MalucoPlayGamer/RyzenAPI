-- Lua provided by RyzenAPI
-- Game: 1505790

-- MAIN APPLICATION
addappid(1505790)
-- Game: addappid(1505790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505791, 1, "b34f9647c0b3d043037be3b950185997bcb821c09d7fbd1f491298b2c69d07b5")
