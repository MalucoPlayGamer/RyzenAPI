-- Lua provided by RyzenAPI 
-- Game: AppID 1772810
addappid(1772810)
addappid(1772811, 1, "8e9c7d7b1598eb776ec7be8927214a564636511a85296c45e0c080f2aa9adb9c")
