-- Lua provided by RyzenAPI
-- Game: VEGAS Pro 14 Edit Steam Edition

-- MAIN APPLICATION
addappid(528200)
-- Game: addappid(528200)

-- MAIN APP DEPOTS / PACKAGES
addappid(528201, 1, "7428fbdd96248703aa381fcf98b621194e8e2948d9454164f300346c9f3df67d")
