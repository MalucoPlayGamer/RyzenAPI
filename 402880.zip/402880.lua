-- Lua provided by RyzenAPI
-- Game: Age of Barbarian Extended Cut

-- MAIN APPLICATION
addappid(402880)
-- Game: addappid(402880)

-- MAIN APP DEPOTS / PACKAGES
addappid(402881, 1, "cff5d2a178129dd431bca4f03d405cb0c1370b162d470b000ae248cf1b9b22e7")
addappid(822080, 0, "ab231bf9abf335c6491253475a4838ba00e7dac1de5a2c64dd753f4e2711b847")
addappid(925110, 0, "6f144f32a55fa68d232044a43dc6d863b39795723fc6b384572de85d1995b756")
