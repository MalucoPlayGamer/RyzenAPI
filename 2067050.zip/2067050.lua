-- Lua provided by RyzenAPI
-- Game: 2067050

-- MAIN APPLICATION
addappid(2067050)
addappid(3715570)
-- Game: addappid(2067050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067051, 1, "201dd3404b99fc27f9420fd2c2adc7036e6bbe75162e4db5ecf27106e46c7d9b")
