-- Lua provided by RyzenAPI
-- Game: Squirrel with a Gun

-- MAIN APPLICATION
addappid(2067050)
addappid(3715570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067051, 1, "201dd3404b99fc27f9420fd2c2adc7036e6bbe75162e4db5ecf27106e46c7d9b")
