-- Lua provided by RyzenAPI 
-- Game: AppID 1036840
addappid(1036840)
addappid(1036841, 1, "919e260060ab2eaeca1783165b6985d3e1cfcd8a014e645659c12c5c62a26136")
