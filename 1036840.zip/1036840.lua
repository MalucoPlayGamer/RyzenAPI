-- Lua provided by RyzenAPI
-- Game: Game: AppID 1036840

-- MAIN APPLICATION
addappid(1036840)
-- Game: addappid(1036840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036841, 1, "919e260060ab2eaeca1783165b6985d3e1cfcd8a014e645659c12c5c62a26136")
