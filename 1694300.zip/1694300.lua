-- Lua provided by RyzenAPI 
-- Game: Light Pursuer
addappid(1694300)
addappid(1694301, 1, "33d1fd3c24f8189ef81f60cbd223df967395395941c78fb7fe40d7b1a3890b78")
