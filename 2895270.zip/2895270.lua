-- Lua provided by RyzenAPI
-- Game: Game: Hurricane

-- MAIN APPLICATION
addappid(2895270)
-- Game: addappid(2895270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895271, 1, "71e73d1c02649485f37b0fe861c966be83778223b3d936205d59c32cf3057d7b")
