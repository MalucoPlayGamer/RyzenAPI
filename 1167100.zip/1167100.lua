-- Lua provided by RyzenAPI
-- Game: Mind

-- MAIN APPLICATION
addappid(1167100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167102,0,"9da723e89bb9443e13ef11021806be838d3fa79b0339b6db95a9378db545c81f")

