-- Lua provided by RyzenAPI
-- Game: Unrailed 2: Back on Track

-- MAIN APPLICATION
addappid(2211170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2211171, 1, "924f04bf42410b224830a5cbe6e5fe8ed52b2cac3a5fc909505918bbbc2670c7")
addappid(2211172, 1, "879213df7df2f8d81ca40e1598d934533921f4f74471a53394c8f611bdeec23b")
addappid(3393870, 0, "677987212f50458d0f106db2ca80b57787838ed4128669ed85322d2923aa79b0")

