-- Lua provided by RyzenAPI
-- Game: 12260

-- MAIN APPLICATION
addappid(12260)
-- Game: addappid(12260)

-- MAIN APP DEPOTS / PACKAGES
addappid(12261, 1, "f36c6849c68923e69983c3b54c72a613c35054484675a6c567d812732afcbaf5")
