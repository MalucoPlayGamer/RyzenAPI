-- Lua provided by RyzenAPI 
-- Game: AppID 12260
addappid(12260)
addappid(12261, 1, "f36c6849c68923e69983c3b54c72a613c35054484675a6c567d812732afcbaf5")
