-- Lua provided by RyzenAPI
-- Game: addappid(1829750)

-- MAIN APPLICATION
addappid(1829750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829751, 1, "ce97671732f8ed3fb0eaaadcd01c4de2a6054f69992a377867a9e8ed83ba8dc2")
