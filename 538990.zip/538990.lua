-- Lua provided by RyzenAPI
-- Game: SugarMill

-- MAIN APPLICATION
addappid(538990)
addappid(538991)

-- MAIN APP DEPOTS / PACKAGES
addappid(538992,0,"99724701ecde18952777390c70cb6611d05b4c6df72c4189c0ebce268b0191fd")

