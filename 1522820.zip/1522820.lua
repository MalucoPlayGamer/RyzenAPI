-- Lua provided by RyzenAPI
-- Game: Orcs Must Die! 3

-- MAIN APPLICATION
addappid(1522820)
addappid(1669920)
addappid(1781510)
addappid(1936590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1522821, 1, "5c5a37b435d9eef062eaf42d50bc6406d1b5b39b7b0a78023b11b26e02517422")

