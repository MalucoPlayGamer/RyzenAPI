-- Lua provided by RyzenAPI
-- Game: addappid(1522820)

-- MAIN APPLICATION
addappid(1522820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522821, 1, "5c5a37b435d9eef062eaf42d50bc6406d1b5b39b7b0a78023b11b26e02517422")
