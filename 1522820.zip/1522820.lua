-- Lua provided by SkyAPI 
-- Game: Orcs Must Die! 3
addappid(1522820)
addappid(1522821, 1, "5c5a37b435d9eef062eaf42d50bc6406d1b5b39b7b0a78023b11b26e02517422")
