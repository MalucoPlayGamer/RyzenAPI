-- Lua provided by RyzenAPI
-- Game: SkyGameChanger-AirCombat II-

-- MAIN APPLICATION
addappid(1012160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1012161, 1, "c66ac76b162d18878d3a2393b9f675de3acd6d0ff59263ff03f29ba5d362bcd0")
addappid(1012162, 1, "8e4abbfc5a1296681f527e7ca23f8f7e44ae4f1eae2e348a224a7e3638be85c7")

