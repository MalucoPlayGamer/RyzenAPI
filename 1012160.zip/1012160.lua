-- Lua provided by RyzenAPI
-- Game: 1012160

-- MAIN APPLICATION
addappid(1012160)
-- Game: addappid(1012160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012161, 1, "c66ac76b162d18878d3a2393b9f675de3acd6d0ff59263ff03f29ba5d362bcd0")
addappid(1012162, 1, "8e4abbfc5a1296681f527e7ca23f8f7e44ae4f1eae2e348a224a7e3638be85c7")
