-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(228989)
addappid(228990)
addappid(229007)
addappid(2966070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966072,0,"47c86d6972a3749afabd232031ff06318d0527b2386192c84620da2f439b5342")

