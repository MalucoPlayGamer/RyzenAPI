-- Lua provided by RyzenAPI
-- Game: Bunker - The Underground Game

-- MAIN APPLICATION
addappid(354180)

-- MAIN APP DEPOTS / PACKAGES
addappid(354181, 1, "ab7a9295d7c0579442feecdc7609a1e6882bf0e69e328fe1a5a56ce148d54fcb")
