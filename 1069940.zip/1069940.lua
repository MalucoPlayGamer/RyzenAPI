-- Lua provided by RyzenAPI
-- Game: addappid(1069940)

-- MAIN APPLICATION
addappid(1069940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069941, 1, "381f5d7ec1df4f92ea83aa9874a734e3b9d5f8331a062f612962afbd57df3770")
