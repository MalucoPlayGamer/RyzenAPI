-- Lua provided by RyzenAPI
-- Game: Blood Brothers

-- MAIN APPLICATION
addappid(1069940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1069941, 1, "381f5d7ec1df4f92ea83aa9874a734e3b9d5f8331a062f612962afbd57df3770")
