-- 4329800's Lua and Manifest Created by Hubcap Manifest
-- DICEASTER
-- Created: July 26, 2026 at 13:16:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4329800, 1, "91acf363786b71c7b40c42f698d65ff26abda255e021f7773b3f4e3705a36c52") -- DICEASTER
-- MAIN APP DEPOTS
addappid(4329801, 1, "806abb71876feaef170341ec9772747b1f45c888037e2f7c680eb2c9bb3a7f36") -- Depot 4329801
setManifestid(4329801, "39716465440355188", 416913115)