-- Lua provided by RyzenAPI
-- Game: AppID 456670

-- MAIN APPLICATION
addappid(456670)

-- MAIN APP DEPOTS / PACKAGES
addappid(456671, 1, "bb27c3e9325bdfccdc1a9ef3e69b3c8db5089585fdc5d9de6d9015ee35f194da")
addappid(456672, 1, "53b29a41370902161c587ed9a515eab2743e966669fee913fa9a7d8b3962fa5d")
addappid(456673, 1, "6ebcbc1fd1e26d56c45a808b1679152f45bc0d75097118730f5837b117b059c4")
addappid(748680, 0, "3892f039b194c55244529fdbb9c706866c73730d863a05c0f8f33123ba586266")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(862450)
addappid(945450)
addappid(969730)
