-- Lua provided by RyzenAPI
-- Game: Game: AppID 809150

-- MAIN APPLICATION
addappid(809150)
-- Game: addappid(809150)

-- MAIN APP DEPOTS / PACKAGES
addappid(809151, 1, "d7ba6e3a162f7738ae621ca57cf508ee61a49efda0fdbe85fbd47ed3e30347d0")
