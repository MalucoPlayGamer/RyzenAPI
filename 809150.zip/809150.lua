-- Lua provided by RyzenAPI
-- Game: AppID 809150

-- MAIN APPLICATION
addappid(809150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809151, 1, "d7ba6e3a162f7738ae621ca57cf508ee61a49efda0fdbe85fbd47ed3e30347d0")

