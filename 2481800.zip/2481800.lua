-- Lua provided by RyzenAPI
-- Game: 2481800

-- MAIN APPLICATION
addappid(2481800)
-- Game: addappid(2481800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481801, 1, "030b9dbf829bb61a4cec194c96ba44cf73e25c5e8ab3f0d540bde261e04b3c86")
