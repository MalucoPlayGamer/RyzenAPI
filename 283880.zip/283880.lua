-- Lua provided by RyzenAPI
-- Game: Heroine's Quest: The Herald of Ragnarok

-- MAIN APPLICATION
addappid(283880)
addappid(769130)

-- MAIN APP DEPOTS / PACKAGES
addappid(283881, 1, "ce60886f36fd2210a54a2425ba26ad5f47e9c4a060538dbc37e2f9e1b3cf2594")
addappid(283882, 1, "8eb3872cc25afd9fbbd03f0c5c73fae5cfe5ffce1dd51982e3d6a440058ba234")
addappid(283883, 1, "4a6fa2ffa3b0509ba96f0d46a4648bf096a593c45c928ccb6047f3203073091a")
addappid(283884, 1, "663f82f3c8b6192ad4346991ab2c028567735441870caf39919bc36bcf15206d")
