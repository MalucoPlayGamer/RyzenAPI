-- Lua provided by RyzenAPI
-- Game: Non-Linear Text Quests

-- MAIN APPLICATION
addappid(531630)

-- MAIN APP DEPOTS / PACKAGES
addappid(531631, 1, "e30592786f314f0c01f17a8a3c6877a532ed9ebace966d283880d701704cd3ce")
addappid(531632, 1, "5fb9fbd6c9079bfb8d97125f6d1bdc2961cedb9391c57c87b6a97d42cab744af")
addappid(531633, 1, "439669f85a3015ee8beca050775cbc6d73a7b5af532d329c93683931228bacf9")
addappid(531634, 1, "4e0295e48cf85658ba2fd0fa16a4ad9bc2241408b22cf1b60d0f773fca362809")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1162210)
addappid(1170100)
