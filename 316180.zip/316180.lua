-- Lua provided by SkyAPI 
-- Game: A City Sleeps™
addappid(316180)
addappid(316181, 1, "fa5bc43b5a5fc8076c069a95e184a4684da1ca284b36a1438c85e4f6d3da0f73")
addappid(320440, 0, "0e1abab9387629f5c982b982ceb22614b0cc184edfe40cd4a0d9fb3210fe51f2")
