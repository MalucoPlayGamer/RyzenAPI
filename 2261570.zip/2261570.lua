-- Lua provided by RyzenAPI 
-- Game: ST World
addappid(2261570)
addappid(2261571, 1, "1ca56c1db9bbed19b300b03bcfbf0dfb6ad8d0e319fd958b14073f994799aa9d")
addappid(2261572, 1, "ad410c848a04a7421a5fa62255bec5422832f3d6e935108f6e8674946547689b")
