-- Lua provided by RyzenAPI
-- Game: Moon Hunters

-- MAIN APPLICATION
addappid(320040)
addappid(3765650)

-- MAIN APP DEPOTS / PACKAGES
addappid(320041, 1, "bc1fc18970a26dc138f56b3a736e6609d15ffd1aab05cda37c23549274d279a1")
addappid(320042, 1, "4cefece14ea5839e2df0173e3f17f41c784bd5880386c8f8098d4c20e06d2a22")
addappid(320043, 1, "b17ed95bc81ad2c5406da1b32e962a4dc6239e69bcb4d152623cab725748a866")
