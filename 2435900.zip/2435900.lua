-- Lua provided by RyzenAPI 
-- Game: SharpShooter3D
addappid(2435900)
addappid(2435901, 1, "42fe403635835d7502a6832b0174f7c7c572bb46f1402dc8d43f9bc1275cd6f3")
