-- Lua provided by RyzenAPI
-- Game: Empire of the Fallen Steel

-- MAIN APPLICATION
addappid(543380)

-- MAIN APP DEPOTS / PACKAGES
addappid(543381,0,"2357a9e3f8d94bd0383d55af470623c12126b3cb005a99bc2e07af95f866531e")

