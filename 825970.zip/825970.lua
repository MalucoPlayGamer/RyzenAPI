-- Lua provided by RyzenAPI 
-- Game: The Mystery of Devils House
addappid(825970)
addappid(825971, 1, "21edfc7c678ccd8c647bcae50def6f6170781e7b61b316ee3f51b3ba83a1c9a4")
