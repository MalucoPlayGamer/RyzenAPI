-- Lua provided by SkyAPI 
-- Game: Knight Eternal
addappid(1165180)
addappid(1165181, 1, "56518e78cc6be2e8e3c3345406489c90843d32d968aa79ca6eb754c4118aeb96")
