-- Lua provided by RyzenAPI
-- Game: Wukong UP Demo

-- MAIN APPLICATION
addappid(2945430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945431, 1, "d81c6060cfaaa95f83657d67cd1540b1a0f44dd80062e5b9c1679ce40bc1ca03")
