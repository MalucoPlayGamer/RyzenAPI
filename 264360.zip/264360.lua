-- Lua provided by RyzenAPI 
-- Game: AppID 264360
addappid(264360)
addappid(264361, 1, "641bd49c457fcbf965ee56d6bfdbb0abdeb43c6517916849488dc5d0f7785f0f")
