-- Lua provided by RyzenAPI
-- Game: Sunrider: Liberation Day - Captain's Edition

-- MAIN APPLICATION
addappid(358750)

-- MAIN APP DEPOTS / PACKAGES
addappid(358751, 1, "34952c62ec826e1ed1214ce0ca52932c5ef7357aaacf9903eab31cd344453c75")

