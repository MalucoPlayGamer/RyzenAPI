-- Lua provided by RyzenAPI
-- Game: 2879720

-- MAIN APPLICATION
addappid(2879720)
-- Game: addappid(2879720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879721, 1, "13c5c9a82ccfd3e33c92a9b58dbd7a1f50393128a74ded34995b825cd4519250")
