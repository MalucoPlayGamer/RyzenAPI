-- Lua provided by RyzenAPI
-- Game: B.I.O.T.A. Demo

-- MAIN APPLICATION
addappid(1696730)
-- Game: addappid(1696730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696731, 1, "13b489f768fe4b33d18b4e2cb9b7113a276d1565cdef4026d6d16f6000eabb38")
