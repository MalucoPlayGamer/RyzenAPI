-- Lua provided by RyzenAPI
-- Game: SurfsUp

-- MAIN APPLICATION
addappid(3454830)
addappid(3469980)

