-- Lua provided by RyzenAPI
-- Game: SurfsUp

-- MAIN APPLICATION
addappid(3454830)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3469980)
