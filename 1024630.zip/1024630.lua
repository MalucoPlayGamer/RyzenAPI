-- Lua provided by RyzenAPI
-- Game: Fighters Legacy

-- MAIN APPLICATION
addappid(1024630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1024631, 1, "27ea6e58fa4c6eabe691308ea3676bf8dd0b2dd0da76af54ef96bb905e90a015")

