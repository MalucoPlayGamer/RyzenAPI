-- Lua provided by RyzenAPI
-- Game: Game: AppID 1024630

-- MAIN APPLICATION
addappid(1024630)
-- Game: addappid(1024630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024631, 1, "27ea6e58fa4c6eabe691308ea3676bf8dd0b2dd0da76af54ef96bb905e90a015")
