-- Lua provided by SkyAPI 
-- Game: AppID 1985420
addappid(1985420)
addappid(1985421, 1, "05e05d6cee69333b9f22bdaead958c4f6cf1bcd850c7f96d2198326569848039")
