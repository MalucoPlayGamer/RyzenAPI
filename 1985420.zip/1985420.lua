-- Lua provided by RyzenAPI
-- Game: 1985420

-- MAIN APPLICATION
addappid(1985420)
-- Game: addappid(1985420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985421, 1, "05e05d6cee69333b9f22bdaead958c4f6cf1bcd850c7f96d2198326569848039")
