-- Lua provided by RyzenAPI
-- Game: AppID 805630

-- MAIN APPLICATION
addappid(805630)

-- MAIN APP DEPOTS / PACKAGES
addappid(805631, 1, "f6b03cb949d02ddde5591930f68ccabdce797c0d7591a6250329f555dafa233c")

