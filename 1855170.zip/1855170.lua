-- Lua provided by RyzenAPI
-- Game: Game: SEARCH ALL - CHRISTMAS

-- MAIN APPLICATION
addappid(1855170)
-- Game: addappid(1855170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855171, 1, "9978726617af5f77f9b26d6ed7be474bf9ee0099f61bf3313cb3ed2062a75ae5")
