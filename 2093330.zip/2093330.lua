-- Lua provided by RyzenAPI
-- Game: Game: Party Bunch

-- MAIN APPLICATION
addappid(2093330)
addappid(2129590)
-- Game: addappid(2093330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093331, 1, "3b732c9162cd1d2c9b330f282b07794652fd726e2bfd8f1cb9cfd93bc5601c5d")
