-- Lua provided by RyzenAPI
-- Game: Army Men II

-- MAIN APPLICATION
addappid(549170)

-- MAIN APP DEPOTS / PACKAGES
addappid(549171, 1, "a9ccd8be0f5bfdbea8c60f2754800a4bbade10e4759872ab1f2b72408f6fd1b3")
addappid(549172, 1, "f131b98570ff55e100a4ff7452068513873871635b4ec362ffea74a969844253")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
