-- Lua provided by SkyAPI 
-- Game: Army Men II
addappid(549170)
addappid(549171, 1, "a9ccd8be0f5bfdbea8c60f2754800a4bbade10e4759872ab1f2b72408f6fd1b3")
addappid(549172, 1, "f131b98570ff55e100a4ff7452068513873871635b4ec362ffea74a969844253")
