-- Lua provided by RyzenAPI
-- Game: Tropical Resort Simulator

-- MAIN APPLICATION
addappid(2936190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936191, 1, "28b0d6fc54d66f6bd31361f16c09cd1a5bf7a960d4ab216290c2d9349db6c673")
