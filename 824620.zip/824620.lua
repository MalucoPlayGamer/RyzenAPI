-- Lua provided by RyzenAPI
-- Game: AppID 824620

-- MAIN APPLICATION
addappid(824620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(824621, 1, "7fa9c1ecb9e2a5b9c3816ffb7648a964fc84f1179b3c88f3a48f6cbc7da5bf8f")

