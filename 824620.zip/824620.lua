-- Lua provided by RyzenAPI
-- Game: AppID 824620

-- MAIN APPLICATION
addappid(824620)
-- Game: addappid(824620)

-- MAIN APP DEPOTS / PACKAGES
addappid(824621, 1, "7fa9c1ecb9e2a5b9c3816ffb7648a964fc84f1179b3c88f3a48f6cbc7da5bf8f")
