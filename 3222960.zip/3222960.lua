-- Lua provided by RyzenAPI
-- Game: 悠久之树

-- MAIN APPLICATION
addappid(3222960)

