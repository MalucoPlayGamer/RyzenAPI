-- Lua provided by RyzenAPI
-- Game: Kitchen Wars

-- MAIN APPLICATION
addappid(2955840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955841, 1, "f3c6a7fcc9e3aefecc0226e9a0f026f6590f6dd6d66c02f07e1a787e4c62fd60")

