-- Lua provided by RyzenAPI
-- Game: 2476190

-- MAIN APPLICATION
addappid(2476190)
-- Game: addappid(2476190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476191, 1, "fe8740ec1536bb4da887f84faac452a1c7ee94548a160173c039cc2f7e8a6e89")
