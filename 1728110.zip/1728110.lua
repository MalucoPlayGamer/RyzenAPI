-- Lua provided by RyzenAPI
-- Game: Auto Mechanic

-- MAIN APPLICATION
addappid(1728110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728111, 1, "347a243a8a9a85f8374754b84c56c293b220cf2c95adec7a5187925609aea511")
