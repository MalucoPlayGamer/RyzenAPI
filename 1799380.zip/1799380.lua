-- Lua provided by RyzenAPI
-- Game: MAGLAM LORD

-- MAIN APPLICATION
addappid(1799380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1799381, 1, "e31bd32f4912cf67a7ef99ac8dcdf7530731782ae6d26709930109688571b414")
addappid(1840720, 0, "c0f177a2a2094b8d6e7ccdead86770a6ca6c97bc204655df1081376fd8145431")

