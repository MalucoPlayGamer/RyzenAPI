-- Lua provided by SkyAPI 
-- Game: Hello Teacher
addappid(1387970)
addappid(1387971, 1, "ed4ebcb5006b799dd2f4ecd44fa90dd1db306c8851178279e854419831c1b527")
