-- Lua provided by RyzenAPI
-- Game: Game: Hello Teacher

-- MAIN APPLICATION
addappid(1387970)
-- Game: addappid(1387970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387971, 1, "ed4ebcb5006b799dd2f4ecd44fa90dd1db306c8851178279e854419831c1b527")
