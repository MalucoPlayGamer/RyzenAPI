-- Lua provided by RyzenAPI
-- Game: Drill Deal: Borehole (Alpha)

-- MAIN APPLICATION
addappid(1376890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376891, 1, "b5150a121a7a606642d20d7f93c7ddcedb5f15022fff2576f9ae368751616b6b")
