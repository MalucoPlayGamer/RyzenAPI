-- Lua provided by RyzenAPI
-- Game: Donuts for Deer Teeth

-- MAIN APPLICATION
addappid(3638180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3638181, 1, "cafce5e0c3903df486f860217b13d16dae1a88a49a16fb8ab82998a48d808671")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
