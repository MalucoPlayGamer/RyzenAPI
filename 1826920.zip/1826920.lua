-- Lua provided by RyzenAPI
-- Game: 1826920

-- MAIN APPLICATION
addappid(1826920)
-- Game: addappid(1826920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826921, 1, "2f9e49efb0e306dc0f88eaa062fe51281755185fa2827a6638ab312f81bbb2ce")
