-- Lua provided by RyzenAPI
-- Game: Deliver At All Costs

-- MAIN APPLICATION
addappid(1880610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880611, 1, "11898035f93d790f53caa2004bd63de9137e651a0b4e28f147de268741f533e5")

