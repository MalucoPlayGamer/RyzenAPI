-- Lua provided by RyzenAPI
-- Game: Game: Two the Top

-- MAIN APPLICATION
addappid(3525360)
-- Game: addappid(3525360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3525361, 1, "7b7669fc3bbdf27a085e71a3660083e50765b589f837c24183875edeb6fbba1a")
