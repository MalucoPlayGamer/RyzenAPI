-- Lua provided by RyzenAPI
-- Game: Game: Duckball

-- MAIN APPLICATION
addappid(2299230)
-- Game: addappid(2299230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299231, 1, "0c311dd00f71b0fb746ea937a8011e4e1a930dce16ec8641369bb71316539549")
