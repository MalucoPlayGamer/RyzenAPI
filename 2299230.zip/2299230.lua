-- Lua provided by RyzenAPI
-- Game: Duckball

-- MAIN APPLICATION
addappid(2299230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299231, 1, "0c311dd00f71b0fb746ea937a8011e4e1a930dce16ec8641369bb71316539549")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
