-- Lua provided by RyzenAPI
-- Game: Vandozer

-- MAIN APPLICATION
addappid(802260)

-- MAIN APP DEPOTS / PACKAGES
addappid(802261,0,"1b0161fce608199435c5f5ae5ece3957783ff3e21ba3310995dbbe0cd393d421")

