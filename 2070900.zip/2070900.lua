-- Lua provided by SkyAPI 
-- Game: Hush Hush - Official Artbook
addappid(2070900)
addappid(2070901, 1, "a98f8f13cf5cbb0464a0edb7cd4a676357ce9086a15aef4e31d22549b2393acd")
