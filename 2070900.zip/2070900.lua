-- Lua provided by RyzenAPI
-- Game: addappid(2070900)

-- MAIN APPLICATION
addappid(2070900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070901, 1, "a98f8f13cf5cbb0464a0edb7cd4a676357ce9086a15aef4e31d22549b2393acd")
