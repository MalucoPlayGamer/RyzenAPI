-- Lua provided by RyzenAPI
-- Game: 938640

-- MAIN APPLICATION
addappid(938640)
-- Game: addappid(938640)

-- MAIN APP DEPOTS / PACKAGES
addappid(938641, 1, "8aa2d2be4b4580476ffd6618faa119f0cf3a5c9acb4ceddb3f313db222e1c47c")
