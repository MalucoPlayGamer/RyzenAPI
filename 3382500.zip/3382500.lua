-- Lua provided by RyzenAPI
-- Game: A Coloring Break

-- MAIN APPLICATION
addappid(3382500)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3442480)
addappid(3442490)
addappid(3442500)
addappid(3442510)
addappid(3442520)
addappid(3442530)
addappid(3442540)
addappid(3442550)
addappid(3442560)
addappid(3442570)
addappid(3501270)
