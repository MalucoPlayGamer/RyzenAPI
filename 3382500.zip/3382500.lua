-- Lua provided by RyzenAPI
-- Game: A Coloring Break

-- MAIN APPLICATION
addappid(3382500)

