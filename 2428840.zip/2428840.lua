-- Lua provided by RyzenAPI
-- Game: Miniatures

-- MAIN APPLICATION
addappid(2428840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428841, 1, "1e5c80c40b7d18e8cd317cf14b5091b57b4a3e0a4f7ba9adf1d6a590ff59bf42")
