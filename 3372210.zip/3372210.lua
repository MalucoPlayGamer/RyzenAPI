-- Lua provided by SkyAPI 
-- Game: AppID 3372210
addappid(3372210)
addappid(3372211, 1, "2c7adea10b6cc96205c1ca1aa0051784bdfa016727929d68dae38bf73ff62978")
