-- Lua provided by RyzenAPI
-- Game: AppID 3372210

-- MAIN APPLICATION
addappid(3372210)
-- Game: addappid(3372210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372211, 1, "2c7adea10b6cc96205c1ca1aa0051784bdfa016727929d68dae38bf73ff62978")
