-- Lua provided by RyzenAPI
-- Game: The Sanctum Demo

-- MAIN APPLICATION
addappid(1742710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742711, 1, "f87f4518ca7fff78961b8e32920495039c776cce38521aad63dc7a2f2edfe2e4")
