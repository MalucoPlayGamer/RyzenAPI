-- Lua provided by RyzenAPI
-- Game: Game: Avaris 2: The Return of the Empress

-- MAIN APPLICATION
addappid(421890)
-- Game: addappid(421890)

-- MAIN APP DEPOTS / PACKAGES
addappid(421891, 1, "2acbb2fea1bdb72d50aa8b4561827dc86a8c7dcc88c03949d0d55e8699e1785a")
