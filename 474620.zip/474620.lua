-- Lua provided by SkyAPI 
-- Game: AppID 474620
addappid(474620)
addappid(474621, 1, "e59bbccdb8a5c8551fd0899ea7c74dc8dc14de3edd7c9972dc115f9e6cc83c7b")
