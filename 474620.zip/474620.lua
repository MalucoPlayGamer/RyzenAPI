-- Lua provided by RyzenAPI
-- Game: AppID 474620

-- MAIN APPLICATION
addappid(474620)

-- MAIN APP DEPOTS / PACKAGES
addappid(474621, 1, "e59bbccdb8a5c8551fd0899ea7c74dc8dc14de3edd7c9972dc115f9e6cc83c7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
