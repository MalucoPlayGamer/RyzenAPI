-- Lua provided by SkyAPI 
-- Game: The Photographer (Nymphs)
addappid(3029340)
addappid(3029341, 1, "df025614ea1feba68d97f2e6530cc592b9c120dfd0c4fe6a5086a99013a72205")
