-- Lua provided by RyzenAPI
-- Game: 3029340

-- MAIN APPLICATION
addappid(3029340)
-- Game: addappid(3029340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029341, 1, "df025614ea1feba68d97f2e6530cc592b9c120dfd0c4fe6a5086a99013a72205")
