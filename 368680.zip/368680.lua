-- Lua provided by RyzenAPI
-- Game: Super Mutant Alien Assault

-- MAIN APPLICATION
addappid(368680)

-- MAIN APP DEPOTS / PACKAGES
addappid(368681, 1, "0216356d18fa92d844b49457ad4a96b390322b1e18d2b1200b2dbbeabe98c92b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
