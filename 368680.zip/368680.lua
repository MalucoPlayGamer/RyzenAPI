-- Lua provided by RyzenAPI
-- Game: Super Mutant Alien Assault

-- MAIN APPLICATION
addappid(368680)
-- Game: addappid(368680)

-- MAIN APP DEPOTS / PACKAGES
addappid(368681, 1, "0216356d18fa92d844b49457ad4a96b390322b1e18d2b1200b2dbbeabe98c92b")
