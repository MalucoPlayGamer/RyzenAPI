-- Lua provided by RyzenAPI
-- Game: Game: Amelie

-- MAIN APPLICATION
addappid(1835810)
-- Game: addappid(1835810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835811, 1, "378b7a5115e8afd7fc6bfeb01890bb421865b0593da9697e7fa709f45e4f049b")
