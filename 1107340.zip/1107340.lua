-- Lua provided by RyzenAPI
-- Game: LONN

-- MAIN APPLICATION
addappid(1107340)
-- Game: addappid(1107340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107341, 1, "2001fb2d078b16e6d722164757da74426e1cfa1bc52b1807c69753aa11eed928")
