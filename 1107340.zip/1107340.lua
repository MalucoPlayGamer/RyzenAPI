-- Lua provided by RyzenAPI
-- Game: LONN

-- MAIN APPLICATION
addappid(1107340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1107341, 1, "2001fb2d078b16e6d722164757da74426e1cfa1bc52b1807c69753aa11eed928")

