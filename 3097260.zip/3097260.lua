-- Lua provided by RyzenAPI 
-- Game: AppID 3097260
addappid(3097260)
addappid(3097261, 1, "cb1ca0f3da5ec7a8899e60482341001d64f75490c1af4733ea5315e88fbd05c8")
