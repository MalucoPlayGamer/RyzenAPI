-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Particle System Plugin - TRP Particle MZ

-- MAIN APPLICATION
addappid(2003832)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003832,0,"91e0063841d0d0ad371071730086b7c57569b4b1de07c1a1c732c5e6f81eb4cf")
