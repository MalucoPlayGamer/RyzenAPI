-- Lua provided by RyzenAPI
-- Game: Hot Roads

-- MAIN APPLICATION
addappid(1819280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819281, 1, "25672802156dd806c45c0e84a8ceff5e0cba66ce4ac319cb9e0642fc56d95647")

