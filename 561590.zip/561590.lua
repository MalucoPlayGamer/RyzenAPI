-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2017

-- MAIN APPLICATION
addappid(561590)

-- MAIN APP DEPOTS / PACKAGES
addappid(561591,0,"bb513b641e3f0be7ad6c00a2e4ca715658f2ab253061a50ccd3f43df8d99beca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
