-- Lua provided by RyzenAPI
-- Game: SENRAN KAGURA Bon Appetit!

-- MAIN APPLICATION
addappid(514310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(514311, 1, "b22e7b9824925fbabb1ad314a49af94a9127d5ba9c3050def2ec3844c79cd8b6")

