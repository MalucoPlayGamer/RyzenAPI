-- Lua provided by RyzenAPI
-- Game: 514310

-- MAIN APPLICATION
addappid(514310)
-- Game: addappid(514310)

-- MAIN APP DEPOTS / PACKAGES
addappid(514311, 1, "b22e7b9824925fbabb1ad314a49af94a9127d5ba9c3050def2ec3844c79cd8b6")
