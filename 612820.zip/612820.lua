-- Lua provided by RyzenAPI 
-- Game: Fallen Legion: Rise to Glory
addappid(612820)
addappid(612821, 1, "c484c39c7d0bb62734884ee4bcd8edb19e8b860efea8ee8f6d775f408c89b683")
