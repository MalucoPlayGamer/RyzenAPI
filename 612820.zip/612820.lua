-- Lua provided by RyzenAPI
-- Game: Game: Fallen Legion: Rise to Glory

-- MAIN APPLICATION
addappid(612820)
-- Game: addappid(612820)

-- MAIN APP DEPOTS / PACKAGES
addappid(612821, 1, "c484c39c7d0bb62734884ee4bcd8edb19e8b860efea8ee8f6d775f408c89b683")
