-- Lua provided by SkyAPI 
-- Game: AppID 1206430
addappid(1206430)
addappid(1206431, 1, "c2afa5f9c45c4bd8624a63fec7d9775ab4eabd4e5c8699efa9b958f07dc15865")
