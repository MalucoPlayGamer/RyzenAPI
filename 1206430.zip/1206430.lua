-- Lua provided by RyzenAPI
-- Game: AppID 1206430

-- MAIN APPLICATION
addappid(1206430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1206431, 1, "c2afa5f9c45c4bd8624a63fec7d9775ab4eabd4e5c8699efa9b958f07dc15865")

