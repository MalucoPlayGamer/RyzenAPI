-- Lua provided by RyzenAPI
-- Game: 2932560

-- MAIN APPLICATION
addappid(2932560)
-- Game: addappid(2932560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932561, 1, "506c45018c337be8ce5ad1cbc0937a6baaa4bb59304dc34939de6d178c4ac171")
