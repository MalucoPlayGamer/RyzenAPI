-- Lua provided by RyzenAPI
-- Game: AppID 1217160

-- MAIN APPLICATION
addappid(1217160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217161, 1, "875a48c5a13969d4817d453932860b7f758c3938d95c0b168c24394c9a81ae2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
