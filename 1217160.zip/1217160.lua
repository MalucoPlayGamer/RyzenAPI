-- Lua provided by SkyAPI 
-- Game: AppID 1217160
addappid(1217160)
addappid(1217161, 1, "875a48c5a13969d4817d453932860b7f758c3938d95c0b168c24394c9a81ae2c")
