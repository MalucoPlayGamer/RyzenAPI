-- Lua provided by RyzenAPI
-- Game: Escape from Nowhere

-- MAIN APPLICATION
addappid(1680900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680901, 1, "55447af4bfe99cb1a3a3d9737266528b04a5323a3fae0020d6d2966eb12d1360")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
