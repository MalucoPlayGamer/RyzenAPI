-- Lua provided by RyzenAPI
-- Game: Game: Escape from Nowhere

-- MAIN APPLICATION
addappid(1680900)
-- Game: addappid(1680900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680901, 1, "55447af4bfe99cb1a3a3d9737266528b04a5323a3fae0020d6d2966eb12d1360")
