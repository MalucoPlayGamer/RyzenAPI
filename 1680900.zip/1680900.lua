-- Lua provided by RyzenAPI 
-- Game: Escape from Nowhere
addappid(1680900)
addappid(1680901, 1, "55447af4bfe99cb1a3a3d9737266528b04a5323a3fae0020d6d2966eb12d1360")
