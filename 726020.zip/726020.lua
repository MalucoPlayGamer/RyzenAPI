-- Lua provided by RyzenAPI
-- Game: addappid(726020)

-- MAIN APPLICATION
addappid(726020)

-- MAIN APP DEPOTS / PACKAGES
addappid(726021, 1, "02eb1f52af47d4c1b8d69b40caaf67e6225878ba5ad8f1e7e993e4f5e3c500e8")
