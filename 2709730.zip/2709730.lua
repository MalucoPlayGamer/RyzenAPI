-- Lua provided by RyzenAPI
-- Game: addappid(2709730)

-- MAIN APPLICATION
addappid(2709730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709731, 1, "e40ade94dad57dd9ea57771ddd03eafc5bee4e359f715fcd189663a0940ff3b6")
