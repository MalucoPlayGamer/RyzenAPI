-- Lua provided by RyzenAPI
-- Game: Game: Phantom Abyss

-- MAIN APPLICATION
addappid(989440)
addappid(1630610)
-- Game: addappid(989440)

-- MAIN APP DEPOTS / PACKAGES
addappid(989441, 1, "6ce3719b6556abfcca19e3a7d853feadb3ab580fcf21c0dac505c9afb9978604")
