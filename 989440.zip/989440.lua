-- Lua provided by RyzenAPI
-- Game: Phantom Abyss

-- MAIN APPLICATION
addappid(989440)
addappid(1630610)

-- MAIN APP DEPOTS / PACKAGES
addappid(989441, 1, "6ce3719b6556abfcca19e3a7d853feadb3ab580fcf21c0dac505c9afb9978604")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
