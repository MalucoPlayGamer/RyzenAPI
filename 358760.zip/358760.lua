-- Lua provided by RyzenAPI
-- Game: Selenon Rising

-- MAIN APPLICATION
addappid(358760)

-- MAIN APP DEPOTS / PACKAGES
addappid(358761, 1, "846f0a2f9b46d1705840984f29eef52711a01cda3ebc78a6ec9af8be60eb71cc")
addappid(463950, 0, "20c9816de309377f17ba65a50d6f99d4588141ec246266e3e0a06167aea075f8")

