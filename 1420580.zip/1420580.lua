-- Lua provided by RyzenAPI
-- Game: Game: Daikaiju Daikessen: Versus

-- MAIN APPLICATION
addappid(1420580)
-- Game: addappid(1420580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420581, 1, "ab24868af9069041710d7c6d35ae452ba7ad844134b70f3a2efab9c464742ca4")
