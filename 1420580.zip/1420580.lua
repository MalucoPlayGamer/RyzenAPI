-- Lua provided by RyzenAPI
-- Game: Daikaiju Daikessen: Versus

-- MAIN APPLICATION
addappid(1420580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420581, 1, "ab24868af9069041710d7c6d35ae452ba7ad844134b70f3a2efab9c464742ca4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
