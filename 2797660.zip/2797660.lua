-- Lua provided by RyzenAPI
-- Game: Game: AppID 2797660

-- MAIN APPLICATION
addappid(2797660)
-- Game: addappid(2797660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797661, 1, "4dedc043f34768334bec414cc5ada8d77afb33ad526f846cbbbb38e1dad0d23c")
