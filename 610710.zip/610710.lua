-- Lua provided by RyzenAPI
-- Game: addappid(610710)

-- MAIN APPLICATION
addappid(610710)

-- MAIN APP DEPOTS / PACKAGES
addappid(610711, 1, "f4b89a9d30273bf9aed16815e9cd2f5e1edd17900321a45295cfbf4a38f03980")
