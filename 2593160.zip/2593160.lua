-- Lua provided by RyzenAPI
-- Game: Hollow Cocoon Demo

-- MAIN APPLICATION
addappid(2593160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593161, 1, "4a10d0b7c81e459e2e545604cf274be17869facc99a501aaa4372ee39af633ea")

