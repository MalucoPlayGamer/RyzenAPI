-- Lua provided by RyzenAPI
-- Game: Game: AppID 3129010

-- MAIN APPLICATION
addappid(3129010)
-- Game: addappid(3129010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129011, 1, "c40b5e9a628be0e3ab2eb809499a0bc34061e5c2414854588a632ef4880b7661")
