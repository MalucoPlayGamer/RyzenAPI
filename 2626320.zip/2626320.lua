-- Lua provided by RyzenAPI
-- Game: addappid(2626320)

-- MAIN APPLICATION
addappid(2626320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626321, 1, "0d64dd7b017b0d775de0081886cc6b6d063ba5d732c675e26510cae539a15a1f")
