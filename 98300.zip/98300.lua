-- Lua provided by RyzenAPI
-- Game: Game: Toy Soldiers

-- MAIN APPLICATION
addappid(98300)
-- Game: addappid(98300)

-- MAIN APP DEPOTS / PACKAGES
addappid(98301, 1, "0716bd127a498a8a18cca0f6fe1d429c7cc385a39dd4322a21415d3359cb2c72")
addappid(98302, 1, "fb945b5928d744aab73267370da0cda2495aa110795cac09620c783bc4592435")
addappid(98303, 1, "2375366e26cda8ec99ac31a73be6f083a49d1f807084d755481b31806472dbbc")
