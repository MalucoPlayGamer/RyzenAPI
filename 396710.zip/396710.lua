-- Lua provided by RyzenAPI
-- Game: 396710

-- MAIN APPLICATION
addappid(396710)
-- Game: addappid(396710)

-- MAIN APP DEPOTS / PACKAGES
addappid(396711, 1, "71ff8f8d1f8f3ca1b1e715e2d6eab788cdc309dee8a42994d04d143dc514313d")
addappid(396712, 1, "35742b028314b6babc3b91cc5b371476e220d9e80070b6776435d079dc9ae719")
