-- Lua provided by RyzenAPI
-- Game: 1072500

-- MAIN APPLICATION
addappid(1072500)
-- Game: addappid(1072500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072501, 1, "c1863dc4796bd607579ff60541fa593f1e5dffd8fc97da6c2f74ac3240cc966f")
