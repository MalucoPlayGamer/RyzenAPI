-- Lua provided by RyzenAPI
-- Game: Port Town: Survival

-- MAIN APPLICATION
addappid(3113340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113341, 1, "16feeaa8ef091a4d85647f951cfab51d19bfbf8fa6bc5bfe0450198c2ec12607")
