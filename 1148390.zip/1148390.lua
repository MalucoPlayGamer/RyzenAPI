-- Lua provided by RyzenAPI
-- Game: Game: Alien Earth

-- MAIN APPLICATION
addappid(1148390)
-- Game: addappid(1148390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148391, 1, "d9996a15943d92b90e7d780600731b6705f6066164869e2df5afba103e6972fa")
