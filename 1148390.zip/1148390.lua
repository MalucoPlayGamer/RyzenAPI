-- Lua provided by RyzenAPI
-- Game: Alien Earth

-- MAIN APPLICATION
addappid(1148390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1148391, 1, "d9996a15943d92b90e7d780600731b6705f6066164869e2df5afba103e6972fa")

