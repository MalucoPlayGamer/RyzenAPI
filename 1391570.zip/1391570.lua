-- Lua provided by RyzenAPI
-- Game: Game: Two by One

-- MAIN APPLICATION
addappid(1391570)
-- Game: addappid(1391570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391571, 1, "57d19e3b6a8dcdd6adf9a982d813a33c1135531828db669fd1a1b0c0869fdaa5")
addappid(1391572, 1, "296c7c4a38c913d737fec70938b068fbb604f6a5fb4f4f834d7ae89b7887629f")
