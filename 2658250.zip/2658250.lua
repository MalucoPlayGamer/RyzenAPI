-- Lua provided by SkyAPI 
-- Game: Eschatology
addappid(2658250)
addappid(2658251, 1, "f0e476d88e0270a595aec366a5755ec2950cec0d6aec0da86ee86fb968de1487")
