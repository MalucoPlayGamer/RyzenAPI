-- Lua provided by RyzenAPI
-- Game: 1125870

-- MAIN APPLICATION
addappid(1125870)
-- Game: addappid(1125870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125871, 1, "6eec00ad6d314553fc0c254b507da923f1d7dc83c1a9cc42d5c169d90ad52089")
