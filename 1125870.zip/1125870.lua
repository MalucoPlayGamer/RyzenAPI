-- Lua provided by RyzenAPI
-- Game: Public Enemy: Revolution Simulator

-- MAIN APPLICATION
addappid(1125870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1125871, 1, "6eec00ad6d314553fc0c254b507da923f1d7dc83c1a9cc42d5c169d90ad52089")
