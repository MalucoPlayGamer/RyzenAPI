-- Lua provided by RyzenAPI
-- Game: Garage: Bad Dream Adventure

-- MAIN APPLICATION
addappid(1946430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946431, 1, "5eb2e167f1e52f04244bec5e716e583fa135b311b3cc312bd31e0f27637f1144")

