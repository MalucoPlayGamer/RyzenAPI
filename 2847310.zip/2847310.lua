-- Lua provided by RyzenAPI
-- Game: Bedtime:turn off the life

-- MAIN APPLICATION
addappid(2847310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2847311, 1, "47568abd687ca85dcdb8e4baf7ab8d32a56f78cccd973e6b3e4bc1d6429644b3")

