-- Lua provided by RyzenAPI
-- Game: Castles

-- MAIN APPLICATION
addappid(666660)

-- MAIN APP DEPOTS / PACKAGES
addappid(666662,0,"b58db7b14051d27438a20ba3177e1ffcadab10d5ba7f929e54bd96d77889db53")
