-- Lua provided by RyzenAPI
-- Game: Murder on the Marine Express

-- MAIN APPLICATION
addappid(1673560)
-- Game: addappid(1673560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673561, 1, "36dab61e51a951c4b2ad26fa866dd79a0a05c14f5605943c4843626298e2cb13")
