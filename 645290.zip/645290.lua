-- Lua provided by RyzenAPI
-- Game: Game: AppID 645290

-- MAIN APPLICATION
addappid(645290)
-- Game: addappid(645290)

-- MAIN APP DEPOTS / PACKAGES
addappid(645291, 1, "784309ec045773a9ee7a880dc35e699d97506fe900d8823eb8797d1c011e3d65")
