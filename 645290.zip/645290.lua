-- Lua provided by RyzenAPI
-- Game: Mechanism

-- MAIN APPLICATION
addappid(645290)
addappid(907170)

-- MAIN APP DEPOTS / PACKAGES
addappid(645291, 1, "784309ec045773a9ee7a880dc35e699d97506fe900d8823eb8797d1c011e3d65")

