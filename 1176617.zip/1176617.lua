-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Sacred Treasure `World Tree Bident`

-- MAIN APPLICATION
addappid(1176617)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176617,0,"e12c740ed9c636ee5c754f5bb909d528c2ab77f355a06ba725894c66d7e4673b")

