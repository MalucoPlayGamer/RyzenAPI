-- Lua provided by RyzenAPI
-- Game: 1561020

-- MAIN APPLICATION
addappid(1561020)
-- Game: addappid(1561020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561021, 1, "a6684d93ddb2221bfa7760af67a27f9cb527c1c46779689479aceca42fc9c075")
