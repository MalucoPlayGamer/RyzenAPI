-- Lua provided by RyzenAPI
-- Game: Flinger Tactics

-- MAIN APPLICATION
addappid(1157050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157051, 1, "5488dfb7989923acfcb209d8d05dae19a72e118d1be7bd48160e27526fbb5783")
addappid(1157052, 1, "4b64391f0f6fcd8505235a0b56213c9be7de2fe8833a6dc3e526649edddd4332")

