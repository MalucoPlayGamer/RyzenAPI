-- Lua provided by RyzenAPI
-- Game: Game: Serafina and the Key to the Egg

-- MAIN APPLICATION
addappid(1410980)
-- Game: addappid(1410980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410981, 1, "c37b01e1a6a628f87b2c4af760770f9588cd43ddac6b2369f7fd35856941ba38")
addappid(1410982, 1, "1fccafa5535b2935ac934b41fa41a5aca06e1c689ecc392fd457195f871a3f1e")
addappid(1410983, 1, "a64cf2551c4233e396399bb1f47b6e3aa42cabcf459467882338d75ab9fca1a5")
