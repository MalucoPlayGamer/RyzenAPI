-- Lua provided by RyzenAPI
-- Game: Game: Dwarf Fortress Soundtrack (Fortress)

-- MAIN APPLICATION
addappid(2232370)
-- Game: addappid(2232370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232371, 1, "48ed24a4ce2a8019f8c444f2a12e6cb949e08a9ceb4bd43d58914931e303f57a")
addappid(2232372, 1, "2faf686a277a6de07657d851f1aeccbc719a3bec2903797c51518373cd64151f")
