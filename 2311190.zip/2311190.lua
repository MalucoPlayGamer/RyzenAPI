-- Lua provided by RyzenAPI
-- Game: Garten of Banban 3

-- MAIN APPLICATION
addappid(2311190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311191, 1, "4a1815ca32ea4425df578a4681c98da5378c5d5d2df87e6b5f755637e7eca984")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
