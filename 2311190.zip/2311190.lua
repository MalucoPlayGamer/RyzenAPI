-- Lua provided by RyzenAPI
-- Game: 2311190

-- MAIN APPLICATION
addappid(2311190)
-- Game: addappid(2311190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311191, 1, "4a1815ca32ea4425df578a4681c98da5378c5d5d2df87e6b5f755637e7eca984")
