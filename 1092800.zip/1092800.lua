-- Lua provided by RyzenAPI
-- Game: Game: Summit of the Wolf

-- MAIN APPLICATION
addappid(1092800)
-- Game: addappid(1092800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092801, 1, "ad6b32b7c72af65401fbc8fd8386754c880b805e04d30f42565b95ee14d3a15c")
