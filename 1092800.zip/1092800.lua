-- Lua provided by RyzenAPI
-- Game: Summit of the Wolf

-- MAIN APPLICATION
addappid(1092800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1092801, 1, "ad6b32b7c72af65401fbc8fd8386754c880b805e04d30f42565b95ee14d3a15c")

