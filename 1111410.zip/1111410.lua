-- Lua provided by RyzenAPI
-- Game: addappid(1111410)

-- MAIN APPLICATION
addappid(1111410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111411, 1, "71774dafd535cc1fdab9fbb811a8317a8a8806ea99d951787c503b01260d6a59")
