-- Lua provided by RyzenAPI 
-- Game: Think_
addappid(1111410)
addappid(1111411, 1, "71774dafd535cc1fdab9fbb811a8317a8a8806ea99d951787c503b01260d6a59")
