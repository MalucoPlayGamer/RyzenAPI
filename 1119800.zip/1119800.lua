-- Lua provided by SkyAPI 
-- Game: Brume
addappid(1119800)
addappid(1119801, 1, "de93f7fc628b43a28a4c4033c7a484a1fa8ddeb0525ab90cf8a1caa269eb0457")
addappid(1119802, 1, "7a2b757a05ddf11b841fc9c29e4c5e657a7456c8f52195a8fbf4147321cef693")
