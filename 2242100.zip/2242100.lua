-- Lua provided by RyzenAPI
-- Game: addappid(2242100)

-- MAIN APPLICATION
addappid(2242100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242101, 1, "595e4ee90fca8e3ce84a14962cd1e2c3dd5000d065bd047a6ad34edf45cd9fcb")
