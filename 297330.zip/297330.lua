-- Lua provided by RyzenAPI
-- Game: Game: Arcadecraft

-- MAIN APPLICATION
addappid(297330)
-- Game: addappid(297330)

-- MAIN APP DEPOTS / PACKAGES
addappid(297331, 1, "2c157c0c67cd3225658cb1f3a80855a219e9392f2364c5ec6246a05ce0cc1587")
