-- Lua provided by RyzenAPI
-- Game: Kong Hero

-- MAIN APPLICATION
addappid(2267010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267011, 1, "2466b8d9f63bec932fd4021ee788b4aa166166339428147921ad9d84ecaf8fac")

