-- Lua provided by RyzenAPI
-- Game: addappid(2595370)

-- MAIN APPLICATION
addappid(2595370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595371, 1, "22da140f0dade93e5bf88afe4c004babc89ef59c95da74c3d1195158ca9a631d")
