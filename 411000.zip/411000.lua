-- Lua provided by RyzenAPI
-- Game: Sorcery! Parts 1 and 2

-- MAIN APPLICATION
addappid(411000)

-- MAIN APP DEPOTS / PACKAGES
addappid(411001, 1, "94b9fbeb214e5d4db93d3d78f8f6677e6e33b31de669e6d0396eb01fdf7527f0")
addappid(411002, 1, "aa6ce007b9e80e264275ef5b94ec2a8afd4edab9e80b820dcd308ab807d2e565")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
