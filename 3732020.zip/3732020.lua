-- Lua provided by RyzenAPI
-- Game: Berserk or Die Soundtrack

-- MAIN APPLICATION
addappid(3732020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3732022,0,"445152b7ef0f94e643b0692eb03319e81752ab698f346ca582aa5d54a80beb25")
addappid(3732023,0,"8b7d3acac8f4bd6e83af09677cab742494b3ab937cb73dba5a1237316447063f")

