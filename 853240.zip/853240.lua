-- Lua provided by RyzenAPI
-- Game: The Light Keeps Us Safe

-- MAIN APPLICATION
addappid(853240)

-- MAIN APP DEPOTS / PACKAGES
addappid(853242,0,"998b7475b098edb2d0a135428fe5ac89d1720b69fbfa8d5502feb8f677822fc4")
