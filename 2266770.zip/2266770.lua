-- Lua provided by RyzenAPI
-- Game: Game: Pathfinder: Wrath of the Righteous - The Last Sarkorians

-- MAIN APPLICATION
addappid(2266770)
-- Game: addappid(2266770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266771, 1, "72cb786e11a7bd4d67bf56b4f3654a50e026389720f6e781f73eebd2d3fd3364")
addappid(2266772, 1, "aa4f746f14a4be0857252f9698faa7be4c6bfa864594801d9897a4e848b0a33a")
