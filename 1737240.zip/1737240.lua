-- Lua provided by RyzenAPI
-- Game: Game: 天气

-- MAIN APPLICATION
addappid(1737240)
-- Game: addappid(1737240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737241, 1, "e913242c1360f7c1c5c854664c0cfd91a03267f3f567b9af16116cb4d838a8c6")
