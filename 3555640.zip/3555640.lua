-- Lua provided by SkyAPI 
-- Game: Wings of Endless Soundtrack
addappid(3555640)
addappid(3555641, 1, "22da90e4ced1606ca41f5a1fa3d16953f0841e3ce7fb91204ae7f74fe12020e2")
