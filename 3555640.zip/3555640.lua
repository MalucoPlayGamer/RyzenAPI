-- Lua provided by RyzenAPI
-- Game: Wings of Endless Soundtrack

-- MAIN APPLICATION
addappid(3555640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3555641, 1, "22da90e4ced1606ca41f5a1fa3d16953f0841e3ce7fb91204ae7f74fe12020e2")
