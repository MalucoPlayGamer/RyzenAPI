-- Lua provided by RyzenAPI
-- Game: Game: AppID 2654630

-- MAIN APPLICATION
addappid(2654630)
-- Game: addappid(2654630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654631, 1, "d0e4ff1489dd5c040ffa445ffcb5c8e3730988ba840aee766df59c743f59fd6a")
