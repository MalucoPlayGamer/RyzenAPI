-- Lua provided by RyzenAPI
-- Game: 2897440

-- MAIN APPLICATION
addappid(2897440)
-- Game: addappid(2897440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897441, 1, "c42b9770b5756f9b913bef71c522ec891eb10d170b4d0fc3cf67520ceca463e8")
