-- Lua provided by RyzenAPI 
-- Game: Rails Across America
addappid(2680190)
addappid(2680191, 1, "dc834751cf19a28e7da79694a4302831f9c53b97433fa4d417092c6c6f0936a0")
addappid(2680192, 1, "0e985e48f115d9bb4d8cf11c87032fdaaefb5e3c27db4e1a62030aafd3624c57")
