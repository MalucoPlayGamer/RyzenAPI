-- Lua provided by RyzenAPI
-- Game: addappid(510290)

-- MAIN APPLICATION
addappid(510290)

-- MAIN APP DEPOTS / PACKAGES
addappid(510291, 1, "774e499902391bcb0517579e81165fdef225efa6c61d286909cd958aad29643a")
