-- Lua provided by RyzenAPI 
-- Game: AppID 598030
addappid(598030)
addappid(598031, 1, "8c0985393051220488bf9f63284a20a4f0052295786480d0c0142bd3597c2878")
