-- Lua provided by RyzenAPI
-- Game: AppID 881920

-- MAIN APPLICATION
addappid(881920)
addappid(1089410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(881921, 1, "f2e75ff5600dd371de1f62672dc24c8bbe6f43ac941e7a3174ff4285bf78bbe2")

