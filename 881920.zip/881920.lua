-- Lua provided by RyzenAPI
-- Game: addappid(881920)

-- MAIN APPLICATION
addappid(881920)

-- MAIN APP DEPOTS / PACKAGES
addappid(881921, 1, "f2e75ff5600dd371de1f62672dc24c8bbe6f43ac941e7a3174ff4285bf78bbe2")
