-- Lua provided by SkyAPI 
-- Game: AppID 881920
addappid(881920)
addappid(881921, 1, "f2e75ff5600dd371de1f62672dc24c8bbe6f43ac941e7a3174ff4285bf78bbe2")
