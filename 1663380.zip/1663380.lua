-- Lua provided by RyzenAPI
-- Game: addappid(1663380)

-- MAIN APPLICATION
addappid(1663380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663381, 1, "a48f7bc6df3734ddfa8163b35b8099bbabb925941de799773471ee8a0b2f9f28")
