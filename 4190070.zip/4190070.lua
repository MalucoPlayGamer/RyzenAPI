-- Lua provided by RyzenAPI
-- Game: Ladies, Don’t Tempt My Immortality

-- MAIN APPLICATION
addappid(4190070)
addappid(4206960)

-- MAIN APP DEPOTS / PACKAGES
addappid(4190071,0,"aaa04d6b73a9bc61869264f823f5776c2b82e12c8a293f2c83167bf6a2a9b329")
addappid(4206961,0,"a7cd41b3a8c3912357d6e7f2015db174ab64129beacfe98a65b489940bc9b308")

