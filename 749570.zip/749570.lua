-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(749570)
addappid(749571)
addappid(749573)

-- MAIN APP DEPOTS / PACKAGES
addappid(749572,0,"61b31746054a1dd0148d8f73263826f484fc3079035a1705578f7d6fea4eea10")
addtoken(749570,12171588904325010343)

