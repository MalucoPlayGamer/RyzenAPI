-- Lua provided by RyzenAPI
-- Game: Guilds Of Delenar

-- MAIN APPLICATION
addappid(812960)

-- MAIN APP DEPOTS / PACKAGES
addappid(812961,0,"63dda563a80ecb3767f6c74028fcce8a2ba2a4bc4cd10e69af945a2a50375336")

