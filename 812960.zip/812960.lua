-- Lua provided by RyzenAPI
-- Game: Guilds Of Delenar

-- MAIN APPLICATION
addappid(812960)

-- MAIN APP DEPOTS / PACKAGES
addappid(812961,0,"63dda563a80ecb3767f6c74028fcce8a2ba2a4bc4cd10e69af945a2a50375336")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
