-- Lua provided by RyzenAPI
-- Game: DeathTolls Experience

-- MAIN APPLICATION
addappid(847900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(847901, 1, "1904ba3f4c9529b2af2bd08eb303ed911cc40d8c2bddbfcabf1410c0a9544b3c")

