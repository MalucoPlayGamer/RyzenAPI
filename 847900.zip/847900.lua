-- Lua provided by RyzenAPI
-- Game: addappid(847900)

-- MAIN APPLICATION
addappid(847900)

-- MAIN APP DEPOTS / PACKAGES
addappid(847901, 1, "1904ba3f4c9529b2af2bd08eb303ed911cc40d8c2bddbfcabf1410c0a9544b3c")
