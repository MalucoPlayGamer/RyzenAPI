-- Lua provided by RyzenAPI
-- Game: Necromunda: Hired Gun - Digital Artbook

-- MAIN APPLICATION
addappid(1613060)
-- Game: addappid(1613060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1613060,0,"09db18f007d5850d07ce02da4c2f266d0cb0e6cfc667347700ef68166be797d3")
