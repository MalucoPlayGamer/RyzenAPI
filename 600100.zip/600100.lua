-- Lua provided by RyzenAPI
-- Game: Executive Hockey

-- MAIN APPLICATION
addappid(600100)

-- MAIN APP DEPOTS / PACKAGES
addappid(600101,0,"e4874538a15279ff8b80bd0fcc5b6b219f68db623ec536c65402145f6e2db16a")

