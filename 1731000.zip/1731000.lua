-- Lua provided by SkyAPI 
-- Game: Skulker
addappid(1731000)
addappid(1731001, 1, "5f892401994d5430b73a4ceb812c43a58ab1fdee80296b9665ca3a92c4779696")
