-- Lua provided by RyzenAPI
-- Game: The Nameless: Slay Dragon Playtest

-- MAIN APPLICATION
addappid(2780350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780351, 1, "6a2317dd6a2c78ba06847c272e7e61b0c2526773c6a4f016da2adf2294f9dc38")
