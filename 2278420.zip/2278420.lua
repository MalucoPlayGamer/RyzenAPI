-- Lua provided by RyzenAPI
-- Game: The Ramsey Demo

-- MAIN APPLICATION
addappid(2278420)
-- Game: addappid(2278420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278421, 1, "f72443f91731732157acaa7a14edf74e7e57518771722e211f4ed549cd3a486b")
