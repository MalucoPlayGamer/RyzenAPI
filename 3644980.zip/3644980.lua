-- Lua provided by RyzenAPI
-- Game: Upgrade My Heart

-- MAIN APPLICATION
addappid(3644980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3644981, 1, "6643ef01690871e476b1300a467c04c32f6a69b2c12d75f1b99215fb254d4e5a")

