-- Lua provided by RyzenAPI
-- Game: 制服少女

-- MAIN APPLICATION
addappid(1495400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495401, 1, "f2342573cbdf0e3b9c62ca818f4fa54974fc173a75fe47dd60ca9106f17b3657")
