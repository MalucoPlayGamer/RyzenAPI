-- Lua provided by RyzenAPI
-- Game: Dream Stone

-- MAIN APPLICATION
addappid(603090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(603091, 1, "82df675615e88e536b2bcd126348a6bb96dbe5c1308edc27355f66b9c9f4afcd")

