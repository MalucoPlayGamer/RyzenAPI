-- Lua provided by RyzenAPI
-- Game: AppID 603090

-- MAIN APPLICATION
addappid(603090)

-- MAIN APP DEPOTS / PACKAGES
addappid(603091, 1, "82df675615e88e536b2bcd126348a6bb96dbe5c1308edc27355f66b9c9f4afcd")

