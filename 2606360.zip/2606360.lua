-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2606360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606362,0,"cbf773015d45574b210417685f5b1357b33e7ad0382492a15a11f192ddcb9f20")

