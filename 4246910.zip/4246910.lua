-- Lua provided by RyzenAPI
-- Game: Femboy Futa Cozy Cafe

-- MAIN APPLICATION
addappid(4246910)

-- MAIN APP DEPOTS / PACKAGES
addappid(4246911, 1, "349265065c0b7e2e008590125731d8a00e8d64bb0b34ea3ef18fdc73678b2d6b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5059820)
addappid(5123600)
