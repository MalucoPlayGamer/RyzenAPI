-- Lua provided by RyzenAPI
-- Game: FUSER™ - Harry Styles - "Adore You"

-- MAIN APPLICATION
addappid(1432164)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432164,0,"78f8d54f0bfcc5cad837859286afe17878b6aede6e02ef65bc13c21c8a6b7fd7")
