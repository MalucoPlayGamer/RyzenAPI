-- Lua provided by RyzenAPI
-- Game: 2592160

-- MAIN APPLICATION
addappid(2592160)
addappid(3920280)
-- Game: addappid(2592160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2592161, 1, "5b4a3a4477e47584b99200004c6f4ef8cf41be05df586de9e1771e160fc7527d")
