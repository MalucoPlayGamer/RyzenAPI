-- Lua provided by RyzenAPI
-- Game: Game: Demining

-- MAIN APPLICATION
addappid(2716620)
-- Game: addappid(2716620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716621, 1, "36b4ed6e725e0a3fe8ff155de5abe451c5c741f552937501b606fe4b81907ea1")
