-- Lua provided by RyzenAPI
-- Game: Game: Gods vs Horrors

-- MAIN APPLICATION
addappid(2994240)
-- Game: addappid(2994240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994241, 1, "92f5f649f24970c0ccda65596884c173ef289cc05131497508acda608c709060")
