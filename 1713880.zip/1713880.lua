-- Lua provided by RyzenAPI
-- Game: addappid(1713880)

-- MAIN APPLICATION
addappid(1713880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713881, 1, "b064d35447b4db109f855e1f99f08ce9a962b678bf02f6946879b36f229a32cc")
