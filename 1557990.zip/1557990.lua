-- Lua provided by RyzenAPI
-- Game: Retail Royale

-- MAIN APPLICATION
addappid(1557990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557991, 1, "3a8e152b13dfa4a6ddb10317d85059798a650bd17ddf4e1309a4cf2c82676105")

