-- Lua provided by RyzenAPI
-- Game: Moon River

-- MAIN APPLICATION
addappid(3392490)
