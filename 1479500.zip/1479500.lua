-- Lua provided by RyzenAPI
-- Game: Rail of Möbius

-- MAIN APPLICATION
addappid(1479500)
-- Game: addappid(1479500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479501, 1, "543c4c39a7b4ef48da04182d604376099a9a5944fe460115be6245a4cc627905")
addappid(1479508, 1, "ffa6595a2ae127dced1ef095a8f339cc85674ee3245eee93ae383bff5334b019")
addappid(1479509, 1, "46cecb0811fcca580111e5613e98d4496ec6195bd0ab56779bae6df4b710b75f")
addappid(1633960, 0, "f92a7a008369b116abe0acdfdabe1c03c4b538af01366090d3adf40b5d64c615")
