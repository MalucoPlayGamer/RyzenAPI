-- Lua provided by RyzenAPI
-- Game: Puzzle Monarch: Nile River

-- MAIN APPLICATION
addappid(938840)
addappid(960120)

-- MAIN APP DEPOTS / PACKAGES
addappid(938841, 1, "9efdb3d0482e877a710aee36c9c985d5d526d7dc36aa236bb75ef25f4093f302")
