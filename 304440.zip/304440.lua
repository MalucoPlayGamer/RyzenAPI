-- Lua provided by RyzenAPI
-- Game: 100% Orange Juice - Demo

-- MAIN APPLICATION
addappid(304440)

-- MAIN APP DEPOTS / PACKAGES
addappid(304441, 1, "22683d5f91141a274f587c0d077ab1e5bfb2adec850d09fda4514fb6ee37caf2")

