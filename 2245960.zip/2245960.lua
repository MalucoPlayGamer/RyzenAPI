-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Swingers Resort

-- MAIN APPLICATION
addappid(2245960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245961, 1, "32c87b575e04fb48ac1fa59298053f9625ee541c7181640458a72e2255da042c")
