-- Lua provided by SkyAPI 
-- Game: Crypto Mining Simulator
addappid(1596310)
addappid(1596311, 1, "d4c0e0e5eceffe285ac91a761cf93da472b6ce5ad2fc9eaf04d61b8a9f751604")
