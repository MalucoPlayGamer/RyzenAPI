-- Lua provided by RyzenAPI
-- Game: Game: Crypto Mining Simulator

-- MAIN APPLICATION
addappid(1596310)
-- Game: addappid(1596310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596311, 1, "d4c0e0e5eceffe285ac91a761cf93da472b6ce5ad2fc9eaf04d61b8a9f751604")
