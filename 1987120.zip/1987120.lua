-- Lua provided by RyzenAPI
-- Game: Arclight Beat

-- MAIN APPLICATION
addappid(1987120)
-- Game: addappid(1987120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987121, 1, "2827cc71cb93ed1a666834bd929c5b279d440c609b949ce42d88b5a62a96d089")
