-- Lua provided by RyzenAPI
-- Game: Arclight Beat

-- MAIN APPLICATION
addappid(1987120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987121, 1, "2827cc71cb93ed1a666834bd929c5b279d440c609b949ce42d88b5a62a96d089")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
