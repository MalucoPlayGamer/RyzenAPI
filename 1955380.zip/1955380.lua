-- Lua provided by RyzenAPI
-- Game: 1955380

-- MAIN APPLICATION
addappid(1955380)
-- Game: addappid(1955380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955381, 1, "30eea395e53deba14b0d0582ece9fae093e85790a87a3d18f4d33091b02d9356")
