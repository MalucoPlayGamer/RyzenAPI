-- Lua provided by RyzenAPI
-- Game: Game: DAWNTRAIL: FINAL FANTASY XIV Original Soundtrack

-- MAIN APPLICATION
addappid(3372330)
-- Game: addappid(3372330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372331, 1, "cdb17111854df71a0876717ddccaf0a9ae3155e49d71e745fae1036fb159df8d")
