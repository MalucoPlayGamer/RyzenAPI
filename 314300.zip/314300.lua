-- Lua provided by RyzenAPI
-- Game: CubeZ

-- MAIN APPLICATION
addappid(314300)

-- MAIN APP DEPOTS / PACKAGES
addappid(314301, 1, "7522e21a5236b66fb452f33c774fbd2ac58c33901bf665a6506e708fffce1831")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
