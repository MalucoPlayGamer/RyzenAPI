-- Lua provided by RyzenAPI
-- Game: Game: CubeZ

-- MAIN APPLICATION
addappid(314300)
-- Game: addappid(314300)

-- MAIN APP DEPOTS / PACKAGES
addappid(314301, 1, "7522e21a5236b66fb452f33c774fbd2ac58c33901bf665a6506e708fffce1831")
