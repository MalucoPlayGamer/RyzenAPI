-- Lua provided by RyzenAPI
-- Game: 1428510

-- MAIN APPLICATION
addappid(1428510)
-- Game: addappid(1428510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428510,0,"dc3eb14fe5ad8f3b78b0dd238a51707d3cfad55ef305bdca7bee3723748399f7")
