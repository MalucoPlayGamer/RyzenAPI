-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xingcai (High school girls Costume) / 星彩 「女子高生風コスチューム」

-- MAIN APPLICATION
addappid(964935)

-- MAIN APP DEPOTS / PACKAGES
addappid(964935,0,"24a7c337dd027d8c88e17500727c6433e415ee91e7b74d8c43589743348ab29d")
