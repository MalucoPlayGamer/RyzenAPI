-- Lua provided by RyzenAPI
-- Game: Interloper

-- MAIN APPLICATION
addappid(356420)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(356421, 1, "0ae05cfcdcda25f3eefd4903e429e11930d651c16faa6b6022d41d11d1d62dcd")
addappid(356422, 1, "2976d5c95a1b576127f721cf7c9781952b11d5a8048715fb504c25a6b2a679ed")
addappid(356423, 1, "7399e2a4d8798886bcdf26095d0c1af0a364ca265caf87634c51eb3e9e6187f0")
addappid(356424, 1, "c6c9fe4fa25428d99f4fccadc030435d30b6605803dfba720c5f718015016956")

