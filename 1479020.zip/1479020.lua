-- Lua provided by RyzenAPI
-- Game: 1479020

-- MAIN APPLICATION
addappid(1479020)
-- Game: addappid(1479020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479021, 1, "f596e98d3cb96e38c1e66a8ebeeae3bde658410050d169652594f86549ca6ddb")
