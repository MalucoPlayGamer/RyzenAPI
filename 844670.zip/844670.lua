-- Lua provided by RyzenAPI
-- Game: Please Be Happy

-- MAIN APPLICATION
addappid(844670)
addappid(2226570)

-- MAIN APP DEPOTS / PACKAGES
addappid(844671, 1, "8fe5fb1afa7510c5fd3d7a870db2ecca2b7dc210671aec7fe570551527ac59da")
