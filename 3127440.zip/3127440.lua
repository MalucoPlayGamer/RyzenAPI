-- Lua provided by RyzenAPI
-- Game: Game: 101 Cats in Ireland

-- MAIN APPLICATION
addappid(3127440)
-- Game: addappid(3127440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127441, 1, "38ad685438039703d1604f24ddc465f300e4a84d413965fe3d36b3032c34855f")
