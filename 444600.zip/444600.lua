-- Lua provided by RyzenAPI
-- Game: Unhack 2 Demo

-- MAIN APPLICATION
addappid(444600)

-- MAIN APP DEPOTS / PACKAGES
addappid(444601, 1, "80c305f04173c090ebd051eaf5a53f4fa22360416fc15f9d1f90de0db6544a87")
