-- Lua provided by RyzenAPI
-- Game: Runehaven Demo

-- MAIN APPLICATION
addappid(2918260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918261, 1, "56d7d25b2f89ab7eb709dcb88286be1527b37e2b1c516f2f1b3a1e112dceddb4")

