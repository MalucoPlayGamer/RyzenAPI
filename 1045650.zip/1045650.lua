-- Lua provided by RyzenAPI
-- Game: My Stunt Life

-- MAIN APPLICATION
addappid(1045650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045651, 1, "f7023d0335273a9e45cfa341a6fc29d2af0c2efe77d9dcca07ba21bc8bf152b2")
