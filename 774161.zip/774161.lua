-- Lua provided by RyzenAPI
-- Game: addappid(774161)

-- MAIN APPLICATION
addappid(774161)

-- MAIN APP DEPOTS / PACKAGES
addappid(774162, 1, "4681f21a85bae359edd32556f8a7f8c250b4a4bd510b9a44df77d4bc1288d4bb")
