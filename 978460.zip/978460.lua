-- Lua provided by RyzenAPI
-- Game: Emily is Away <3

-- MAIN APPLICATION
addappid(978460)
-- Game: addappid(978460)

-- MAIN APP DEPOTS / PACKAGES
addappid(978461, 1, "bc36d7ce883895783be3f44bd66e30c03d0ddfba3fc125460a053eadd7480582")
addappid(978462, 1, "1f36bcf7c0499719619a03389d9925c863a51400d376e93a9293adf5742e16fa")
