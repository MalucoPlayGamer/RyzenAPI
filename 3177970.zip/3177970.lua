-- Lua provided by RyzenAPI
-- Game: Game: Bioweaver

-- MAIN APPLICATION
addappid(3177970)
addappid(3513460)
-- Game: addappid(3177970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177971, 1, "559e6e3450ca7058329648e9292f360d400970bf869e4a68440e07912d3ac476")
addappid(3177972, 1, "cac467301f8871e1599a50e2c350b2b16b9ef3adf04cbbd932dd4a6d22fc479c")
addappid(3177973, 1, "c0227822f255bb0836dc6ea94d39abc7a62fb9ba541ea8d3162b11962a12fb92")
