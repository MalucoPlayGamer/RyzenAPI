-- Lua provided by RyzenAPI
-- Game: 2302840

-- MAIN APPLICATION
addappid(2302840)
-- Game: addappid(2302840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302841, 1, "0c2e3f9421c32e3a63899f3b898f6f5a7dc9361cfeacf30ae766451cd8199016")
