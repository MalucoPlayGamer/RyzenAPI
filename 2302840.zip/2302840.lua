-- Lua provided by RyzenAPI 
-- Game: Compass of Destiny: Istanbul
addappid(2302840)
addappid(2302841, 1, "0c2e3f9421c32e3a63899f3b898f6f5a7dc9361cfeacf30ae766451cd8199016")
