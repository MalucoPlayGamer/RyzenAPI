-- Lua provided by RyzenAPI
-- Game: Compass of Destiny: Istanbul

-- MAIN APPLICATION
addappid(2302840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2302841, 1, "0c2e3f9421c32e3a63899f3b898f6f5a7dc9361cfeacf30ae766451cd8199016")

