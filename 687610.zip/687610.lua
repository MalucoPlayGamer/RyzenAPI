-- Lua provided by RyzenAPI 
-- Game: Cat vs. Corgis
addappid(687610)
addappid(687611, 1, "08f4571e6d7897579eb68491fef082e33cebe8fc32c10c4617b5b206409ac37a")
