-- Lua provided by RyzenAPI
-- Game: Caves of Lore

-- MAIN APPLICATION
addappid(2227130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227131, 1, "b8c7eb2d699f75058a20c4d840529515b9ee56b5da57fc4b2761f28138698874")

