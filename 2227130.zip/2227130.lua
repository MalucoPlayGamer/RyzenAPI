-- Lua provided by SkyAPI 
-- Game: Caves of Lore
addappid(2227130)
addappid(2227131, 1, "b8c7eb2d699f75058a20c4d840529515b9ee56b5da57fc4b2761f28138698874")
