-- Lua provided by RyzenAPI 
-- Game: AMAZE!
addappid(2348810)
addappid(2348811, 1, "7b9b8cfaa7fae764a185658ff7aa6a6b23866557138374c36d63f8ac2a039b1b")
addappid(2837990)
addappid(2838000)
