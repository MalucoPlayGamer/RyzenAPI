-- Lua provided by RyzenAPI
-- Game: addappid(1754704)

-- MAIN APPLICATION
addappid(1754704)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754704,0,"669094ba47d811aeb2e10100040bbdb32afa56f42f401920d9b989b5f55bf9ad")
