-- Lua provided by RyzenAPI
-- Game: Game: Sunny Cafe

-- MAIN APPLICATION
addappid(1611350)
-- Game: addappid(1611350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611351, 1, "931a0cc40c1115eef8ab138d945f58b1a03332665bbfc9428aadeabb398f2774")
addappid(1611355, 1, "54642bb792b2b39d83e110a42d3ba9a9813dcb6af67fc1ba65b23eb2064a9814")
addappid(1723431, 0, "e23d929e8693121d4dc1d657e090c65560d26c3de8bc2d768df455263317954f")
