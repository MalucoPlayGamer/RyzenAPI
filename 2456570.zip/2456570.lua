-- Lua provided by RyzenAPI
-- Game: Surveillance Simulator

-- MAIN APPLICATION
addappid(2456570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2456571, 1, "2eb8edeb526427d187b7b9ffa150038a56921da472827e1ee953d6271f723c4b")

