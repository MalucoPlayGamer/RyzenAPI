-- Lua provided by RyzenAPI 
-- Game: Brooks in Wild West
addappid(2628800)
addappid(2628801, 1, "c124c880df6b299eab8eb75fa52f4f1bde20c4bca0d522ad2279a2e7f1c4ae6c")
