-- Lua provided by SkyAPI 
-- Game: Mercenaries Blaze
addappid(1582510)
addappid(1582511, 1, "a7c9077c87c058d27658900f0da9af03802b13e705cda0a03b7ec0875afdc338")
