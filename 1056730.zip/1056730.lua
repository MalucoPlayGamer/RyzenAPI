-- Lua provided by RyzenAPI
-- Game: Game: Train Valley 2 - Original Soundtrack

-- MAIN APPLICATION
addappid(1056730)
-- Game: addappid(1056730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056731, 1, "3d22f9ba35fd8dee90870b19fc67bd6abfd414231f98fa1917da22d2c55413b6")
