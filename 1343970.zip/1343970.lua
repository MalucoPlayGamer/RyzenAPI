-- Lua provided by RyzenAPI
-- Game: The Running Man

-- MAIN APPLICATION
addappid(1343970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343971, 1, "c5d77ef931a642f5c4d04839cddc15854e8ace8f0c3751e99c082072cc4d03dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1348710)
