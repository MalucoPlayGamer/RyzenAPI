-- Lua provided by RyzenAPI
-- Game: The Running Man

-- MAIN APPLICATION
addappid(1343970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343971, 1, "c5d77ef931a642f5c4d04839cddc15854e8ace8f0c3751e99c082072cc4d03dd")
