-- Lua provided by RyzenAPI
-- Game: Game: Caroline's Fantasies

-- MAIN APPLICATION
addappid(2291690)
-- Game: addappid(2291690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291691, 1, "f7b109338c6e8fd5ae59099b972737b112b2566ed44ff73b3511cc7a12272357")
