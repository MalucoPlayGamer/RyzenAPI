-- Lua provided by RyzenAPI
-- Game: 979170

-- MAIN APPLICATION
addappid(979170)
-- Game: addappid(979170)

-- MAIN APP DEPOTS / PACKAGES
addappid(979172,0,"ea96a434b8859786f2ce13cb2e2f13b025b5e39c42125154c574ac23732e152e")
