-- Lua provided by RyzenAPI
-- Game: Game: Straimium Immortaly

-- MAIN APPLICATION
addappid(515650)
-- Game: addappid(515650)

-- MAIN APP DEPOTS / PACKAGES
addappid(515651, 1, "3e994f81ed290f30b9731c9a038af3958c847749fd328c90691b6e1a87a644b3")
