-- Lua provided by RyzenAPI
-- Game: Idle Grid

-- MAIN APPLICATION
addappid(2940220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940224,0,"85f11c114531ce946d8597d098897a50c6f64bad7272432668ec144f8d64d687")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
