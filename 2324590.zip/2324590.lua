-- Lua provided by RyzenAPI
-- Game: 2324590

-- MAIN APPLICATION
addappid(2324590)
-- Game: addappid(2324590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324591, 1, "7ff30fee65711e0850603185b3ac4026d6f7bcb4eb3402e82927ace16befe9c8")
