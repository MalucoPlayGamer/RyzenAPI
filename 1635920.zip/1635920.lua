-- Lua provided by RyzenAPI
-- Game: A Dog Named Mato

-- MAIN APPLICATION
addappid(1635920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635921, 1, "3e3bbd5d695024f7f3b3d1f8bc8f7a4ddbcb70f864f69e845aa264a1c9319300")
