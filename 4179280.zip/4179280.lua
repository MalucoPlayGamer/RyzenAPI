-- Lua provided by RyzenAPI
-- Game: Moonshiner Simulator

-- MAIN APPLICATION
addappid(4179280)

-- MAIN APP DEPOTS / PACKAGES
addappid(4179281,0,"0127d3d8ace2962fd669945db02094f4b790fb3c26b5c0e37345163de2e9e986")

