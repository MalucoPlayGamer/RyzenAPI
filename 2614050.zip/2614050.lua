-- Lua provided by RyzenAPI
-- Game: Game: Magnet Block Demo

-- MAIN APPLICATION
addappid(2614050)
-- Game: addappid(2614050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614051, 1, "19abffc2a1232ebbe9ee9219bdb668b47e635aeddb907b343153f17bf741adb5")
