-- Lua provided by RyzenAPI
-- Game: addappid(2614050)

-- MAIN APPLICATION
addappid(2614050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614051, 1, "19abffc2a1232ebbe9ee9219bdb668b47e635aeddb907b343153f17bf741adb5")
