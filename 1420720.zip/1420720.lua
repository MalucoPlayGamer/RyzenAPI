-- Lua provided by RyzenAPI
-- Game: 无名录

-- MAIN APPLICATION
addappid(1420720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420721, 1, "55da1322ed6ebfb04ca9d19ecc1e0ba4e285c303a40f623a4c2996ab0bcac57e")
