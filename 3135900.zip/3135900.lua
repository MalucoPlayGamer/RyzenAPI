-- Lua provided by RyzenAPI
-- Game: Game: Dawn of Survivor

-- MAIN APPLICATION
addappid(3135900)
-- Game: addappid(3135900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135901, 1, "313f70203f1dd8f45d21c130f90cb577a53dbeaba71bc4d0433af004cce30093")
