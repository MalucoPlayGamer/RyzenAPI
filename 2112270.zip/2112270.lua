-- Lua provided by RyzenAPI
-- Game: addappid(2112270)

-- MAIN APPLICATION
addappid(2112270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112271, 1, "0e9302a6f8115e2af9daeb87cfc86435e5ba2aff658d1e8c6570871097104382")
