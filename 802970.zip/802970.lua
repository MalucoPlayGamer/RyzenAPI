-- Lua provided by RyzenAPI
-- Game: Game: AppID 802970

-- MAIN APPLICATION
addappid(802970)
-- Game: addappid(802970)

-- MAIN APP DEPOTS / PACKAGES
addappid(802971, 1, "af4297f399fdaf8173868b08c06b627cb74512a6737102ff8dfdc8421f008074")
