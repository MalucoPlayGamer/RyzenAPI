-- Lua provided by RyzenAPI
-- Game: Prison Architect

-- MAIN APPLICATION
addappid(233450)
addappid(234430)
addappid(234431)
addappid(1143650)
addappid(1195240)
addappid(1244780)
addappid(1244781)
addappid(1493470)
addappid(1601350)
addappid(1760030)
addappid(1948120)
addappid(2085570)
addappid(2154010)
addappid(2184800)
addappid(2237250)

-- MAIN APP DEPOTS / PACKAGES
addappid(233451, 1, "27eb5fe0ce5772f90c109ac60918afc58a5870bbd1cdaef4b6c3919b0b63ef83")
addappid(233452, 1, "0313b1a3064addbc9f94a29d64e52a2db1f9da529598fe6402af74482b81876d")
addappid(233453, 1, "ba72480b04c6b8e3a27a7dab0ad8aae496aa36f4420a20e9b8aa8cb6c38b8b30")
addappid(234432, 0, "79c2572c2aea51e5da076c4656f66287663658804187cd5d78dba3a7eb801814")
addappid(234433, 0, "60f2761aca08c5325e4b42c01f8b4196a3046e895062c3e60c7f916ea9541acb")

