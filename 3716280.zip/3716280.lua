-- Lua provided by RyzenAPI
-- Game: 3716280

-- MAIN APPLICATION
addappid(3716280)
-- Game: addappid(3716280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716281, 1, "013ddb5e9e75e0e3cb379d140b568e92e35ce32474cbb914a2564ea1ee02bef6")
