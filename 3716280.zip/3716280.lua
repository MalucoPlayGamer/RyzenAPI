-- Lua provided by SkyAPI 
-- Game: Rumours of a Roman Empire
addappid(3716280)
addappid(3716281, 1, "013ddb5e9e75e0e3cb379d140b568e92e35ce32474cbb914a2564ea1ee02bef6")
