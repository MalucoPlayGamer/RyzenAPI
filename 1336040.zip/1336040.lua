-- Lua provided by RyzenAPI
-- Game: Easter Pairs

-- MAIN APPLICATION
addappid(1336040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336041, 1, "f6b26a520733cb583ed43e7ae816e2e812c13f18f63f21746f1f663f3a46e87c")
