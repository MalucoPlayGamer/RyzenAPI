-- Lua provided by RyzenAPI 
-- Game: BRUTALISTICK VR Demo
addappid(2720290)
addappid(2720291, 1, "91bc982c0f2799c31416424232f85278bd850a0108d804e5c606f06c66f8b7d5")
