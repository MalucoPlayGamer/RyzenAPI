-- Lua provided by RyzenAPI
-- Game: Bahamut2-Come on,Fight Demo

-- MAIN APPLICATION
addappid(2661650)
-- Game: addappid(2661650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661652,0,"e8553e1e27c25d4d32f573739cb441515dd1710ab3280a6123b68a864c666d7d")
