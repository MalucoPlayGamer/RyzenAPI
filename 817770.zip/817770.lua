-- Lua provided by RyzenAPI
-- Game: 817770

-- MAIN APPLICATION
addappid(817770)
-- Game: addappid(817770)

-- MAIN APP DEPOTS / PACKAGES
addappid(817771, 1, "3741f296b8a071314aaac7f00eb1b2b1ea26bc649a7e10c93e6aec34271216ee")
