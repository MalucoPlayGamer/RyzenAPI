-- Lua provided by RyzenAPI
-- Game: SANYA Demo

-- MAIN APPLICATION
addappid(2018890)
-- Game: addappid(2018890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018893,0,"9639f7ba3ff108ded31a0f07583ea356334a123c2638e92fd297b692a305f775")
