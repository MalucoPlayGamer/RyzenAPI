-- Lua provided by RyzenAPI
-- Game: Rocket Fist

-- MAIN APPLICATION
addappid(413500)
addappid(473410)

-- MAIN APP DEPOTS / PACKAGES
addappid(413501, 1, "b095d91742ec808787f0648a45b4b0100ab0b09a2eeb09bb5b6ca7c572f44fb8")
addappid(413502, 1, "05c018036a30aaf46dcc1d711c94e668c07e5a542b736c1d043aa6293201988a")
addappid(413503, 1, "fb8f261c04df5ce4b51034a5e2e66942fdb0ebfa54170c797f4f88e0e4ad8b78")
