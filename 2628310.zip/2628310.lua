-- Lua provided by RyzenAPI
-- Game: Adrenaline Rampage Demo

-- MAIN APPLICATION
addappid(2628310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628311, 1, "c8baf43542d0dc2c7532aaabbfdf7ebdee5a2d013073024b0c675ef25de35401")
