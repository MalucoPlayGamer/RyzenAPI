-- Lua provided by RyzenAPI
-- Game: The Spell Brigade Demo

-- MAIN APPLICATION
addappid(3002370)
-- Game: addappid(3002370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002371, 1, "435b725a2e47e8438abdfa5da120e62e6150612ddba9fc96047badfc37e4421a")
