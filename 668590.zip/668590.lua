-- Lua provided by RyzenAPI
-- Game: Omen Exitio: Plague

-- MAIN APPLICATION
addappid(668590)

-- MAIN APP DEPOTS / PACKAGES
addappid(668591, 1, "7c817af8084c89badf5ce4f7bbf4377dc426640b532b8fdde7bc7303f02b4abc")
addappid(668592, 1, "9f6d331fce6bee97ebe069406be1a064b60048e5cf3c0b5fc43061c937aee39e")
addappid(668593, 1, "f6b7421990060eff287ab3969d7919766308324ba6fcf65ca3644488c6a59618")
addappid(668594, 1, "acc6222a92e94fa430f2d1f04253f7175994b3e7ab08f1085cf3fe3c2ec6a0e7")

