-- Lua provided by RyzenAPI
-- Game: RailGods of Hysterra

-- MAIN APPLICATION
addappid(3201910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201911, 1, "46a048eabbe26d9436a14036da2caa89bb0aedc6120abe014d8a647ca5abb411")
addappid(3601390, 0, "64ba32802db186b2061a124acd28e1c105394eaee551f5249aa0bdba82704e39")

