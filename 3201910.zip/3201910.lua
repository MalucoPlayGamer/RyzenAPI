-- Lua provided by RyzenAPI
-- Game: RailGods of Hysterra

-- MAIN APPLICATION
addappid(3201910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201911, 1, "46a048eabbe26d9436a14036da2caa89bb0aedc6120abe014d8a647ca5abb411")
addappid(3601390, 0, "64ba32802db186b2061a124acd28e1c105394eaee551f5249aa0bdba82704e39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
