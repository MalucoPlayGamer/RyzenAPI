-- Lua provided by RyzenAPI
-- Game: Tavern Talk - Digital Tarot Cards - Major Arcana

-- MAIN APPLICATION
addappid(3054620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054620,0,"b059d133733f91db18eec276a0bd307e56d64efcb4341a12b8fb9a8e4d911da3")

