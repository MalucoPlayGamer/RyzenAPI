-- Lua provided by RyzenAPI
-- Game: PlanetFate

-- MAIN APPLICATION
addappid(485110)

-- MAIN APP DEPOTS / PACKAGES
addappid(485111, 1, "61bf5129ce49b2f9b9f0d243f76e690987b62d3dea99eee1789c5451078ee26c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
