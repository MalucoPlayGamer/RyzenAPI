-- Lua provided by RyzenAPI
-- Game: PlanetFate

-- MAIN APPLICATION
addappid(485110)
-- Game: addappid(485110)

-- MAIN APP DEPOTS / PACKAGES
addappid(485111, 1, "61bf5129ce49b2f9b9f0d243f76e690987b62d3dea99eee1789c5451078ee26c")
