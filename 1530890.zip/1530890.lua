-- Lua provided by RyzenAPI
-- Game: Car Constructor

-- MAIN APPLICATION
addappid(1530890)
-- Game: addappid(1530890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530891, 1, "d49d2df0e68f633f22ca55d5dde26703d0145d908c2f4a921216e7eb0daebbcf")
