-- Lua provided by RyzenAPI
-- Game: Game: Soul Devourer Demo

-- MAIN APPLICATION
addappid(2531850)
-- Game: addappid(2531850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531851, 1, "489661b410416fcd35419d023630377e6616b04099cba9b7d77ec4326e6e23ed")
