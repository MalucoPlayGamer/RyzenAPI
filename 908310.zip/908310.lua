-- Lua provided by RyzenAPI
-- Game: 908310

-- MAIN APPLICATION
addappid(908310)
-- Game: addappid(908310)

-- MAIN APP DEPOTS / PACKAGES
addappid(908311, 1, "de40027a0c8e5a8bf41ffee7e19b0ccf136991d5d183827c634f69200e8d9663")
