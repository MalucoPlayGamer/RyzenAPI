-- Lua provided by RyzenAPI
-- Game: AppID 772660

-- MAIN APPLICATION
addappid(772660)
-- Game: addappid(772660)

-- MAIN APP DEPOTS / PACKAGES
addappid(772661, 1, "3ebf2da769c0dd6596f493af5e43431bc8a962ed2937394bdaca09225e2bf61c")
