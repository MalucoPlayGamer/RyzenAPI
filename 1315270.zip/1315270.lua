-- Lua provided by RyzenAPI
-- Game: Game: AppID 1315270

-- MAIN APPLICATION
addappid(1315270)
-- Game: addappid(1315270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315271, 1, "d1c78b9adc1f39d7c5906336b3a10c3155c625d3e0a71624eb9936f19830248d")
