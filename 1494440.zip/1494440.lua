-- Lua provided by RyzenAPI
-- Game: Garbage: Hobo Prophecy

-- MAIN APPLICATION
addappid(1494440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494441, 1, "54b7151ff28452ff9aef8044e8a8c7effcfe094f8a93f3d2f0b1c801b1837698")
addappid(1494442, 1, "8f4cd12b0f46425309cd5f7e3f477f9e692341d2507cc1e57bbf7c2227389eb0")
