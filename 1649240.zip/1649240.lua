-- Lua provided by RyzenAPI
-- Game: Game: Returnal™

-- MAIN APPLICATION
addappid(1649240)
-- Game: addappid(1649240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649241, 1, "56c7a929e028152a464e8015e2e697cbcbf5313232cc82ccc1c312e6d5d76929")
