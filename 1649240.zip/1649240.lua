-- Lua provided by RyzenAPI
-- Game: Returnal™

-- MAIN APPLICATION
addappid(1649240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649241, 1, "56c7a929e028152a464e8015e2e697cbcbf5313232cc82ccc1c312e6d5d76929")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2127200)
