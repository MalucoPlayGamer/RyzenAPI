-- Lua provided by RyzenAPI
-- Game: Game: Savior of Light

-- MAIN APPLICATION
addappid(1746780)
-- Game: addappid(1746780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746781, 1, "9b05539937de79d8b5bfebec8464ce1325fd638b141e32c27885ceb0bb6f41a7")
