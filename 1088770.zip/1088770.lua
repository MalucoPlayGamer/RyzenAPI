-- Lua provided by RyzenAPI
-- Game: Car Mechanic Simulator VR

-- MAIN APPLICATION
addappid(1088770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088776,0,"daeb9c90a4aa9e931526349369f34a2b9abf460d72991b9fb02c79db9574dd45")

