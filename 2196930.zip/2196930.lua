-- Lua provided by RyzenAPI
-- Game: addappid(2196930)

-- MAIN APPLICATION
addappid(2196930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196931, 1, "a504ae0ba73f1e69f56de395afa0ee963a68a3a7e4a7bae2829d77fc6a504712")
