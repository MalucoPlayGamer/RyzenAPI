-- Lua provided by RyzenAPI
-- Game: Trans-Siberian Railway Simulator: Prologue

-- MAIN APPLICATION
addappid(2248950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248951, 1, "c61e8fac795f5cb589da9ebd004f86efd410b2c7fda301ecfbe680ef85b383d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
