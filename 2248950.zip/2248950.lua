-- Lua provided by RyzenAPI
-- Game: 2248950

-- MAIN APPLICATION
addappid(2248950)
-- Game: addappid(2248950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248951, 1, "c61e8fac795f5cb589da9ebd004f86efd410b2c7fda301ecfbe680ef85b383d0")
