-- Lua provided by RyzenAPI
-- Game: addappid(813710)

-- MAIN APPLICATION
addappid(813710)

-- MAIN APP DEPOTS / PACKAGES
addappid(813711, 1, "78438f8c861796ddf082354d00e0c9c321420daab6cfef76045004a27af1b5ae")
