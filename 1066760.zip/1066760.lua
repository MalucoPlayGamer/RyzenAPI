-- Lua provided by RyzenAPI
-- Game: Moonshine Inc.

-- MAIN APPLICATION
addappid(1066760)
addappid(2216400)
-- Game: addappid(1066760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066761, 1, "89b93a9fe44a42e58fc5e951069669f98ea11c796c023bf74a1f158182dd5dc6")
