-- Lua provided by RyzenAPI
-- Game: Shots fired in the Dark Forest

-- MAIN APPLICATION
addappid(1564920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564921, 1, "a070053a798d0fbc78041f39d2886a297e932df38990bb6f9601202a33ec9561")
