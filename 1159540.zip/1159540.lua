-- Lua provided by RyzenAPI
-- Game: 1159540

-- MAIN APPLICATION
addappid(1159540)
-- Game: addappid(1159540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159541, 1, "44f34b941ade94bebb70dfd380dbbc3b17c9d88b56f2591a27e33fad6f9fded3")
