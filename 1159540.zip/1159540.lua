-- Lua provided by RyzenAPI
-- Game: Fear the Dark Unknown

-- MAIN APPLICATION
addappid(1159540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1159541, 1, "44f34b941ade94bebb70dfd380dbbc3b17c9d88b56f2591a27e33fad6f9fded3")

