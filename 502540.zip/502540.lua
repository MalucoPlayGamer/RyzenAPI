-- Lua provided by RyzenAPI
-- Game: Cold Vengeance

-- MAIN APPLICATION
addappid(502540)
-- Game: addappid(502540)

-- MAIN APP DEPOTS / PACKAGES
addappid(502541, 1, "d26b01672ed0887457d7256439d517bc22313e8bd732a5116e7710669153bf49")
