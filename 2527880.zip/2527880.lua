-- Lua provided by RyzenAPI 
-- Game: Undead West
addappid(2527880)
addappid(2527881, 1, "39b214952581e628b060d33e56a70f3b7b00cd830e6441e7153bb7261863de37")
