-- Lua provided by RyzenAPI
-- Game: addappid(1457550)

-- MAIN APPLICATION
addappid(1457550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457551, 1, "70921b3629edb44eab3c9ca76f9bc879de3e6060d98e7b6a3e9135e35607e45e")
