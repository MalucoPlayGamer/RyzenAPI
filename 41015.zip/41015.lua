-- Lua provided by RyzenAPI
-- Game: Serious Sam HD: The Second Encounter Dedicated Server

-- MAIN APPLICATION
addappid(41015)

-- MAIN APP DEPOTS / PACKAGES
addappid(41016, 1, "b2c7c3fdf64acaad25118d9d4185819ca5ae1b687a718a0b15934cc859afa14e")
