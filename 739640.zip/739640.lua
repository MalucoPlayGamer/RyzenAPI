-- Lua provided by RyzenAPI
-- Game: AppID 739640

-- MAIN APPLICATION
addappid(739640)
-- Game: addappid(739640)

-- MAIN APP DEPOTS / PACKAGES
addappid(739641, 1, "c84aaa35cc35e3e17a56dbef9bda2055cc2024a5fedcd578565dff88b127044a")
