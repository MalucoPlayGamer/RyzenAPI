-- Lua provided by RyzenAPI
-- Game: Automaton Lung

-- MAIN APPLICATION
addappid(2158900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158902,0,"dfd7b4e79b571a2e961bfbe4a1b7ca36c73fd23363c5db9a22141e4ff2d6aa78")
addappid(2158904,0,"f7edfb93fe8282a1ce5b4509b68334a5d302de357bee33ac9634b85495f2dea9")

