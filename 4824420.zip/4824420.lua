-- Lua provided by RyzenAPI
-- Game: Vespera

-- MAIN APPLICATION
addappid(4824420)

-- MAIN APP DEPOTS / PACKAGES
addappid(4824421,0,"11ca6a364e8f368db4ebdcb717a2d92eb201cc7263b40e604aad28eaaa4440fc")

