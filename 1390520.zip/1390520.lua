-- Lua provided by RyzenAPI
-- Game: 1390520

-- MAIN APPLICATION
addappid(1390520)
-- Game: addappid(1390520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390521, 1, "557bfde2811841a3df2eab3d679fd8752cd84947389c70547e4ebdc33605da9f")
