-- Lua provided by RyzenAPI
-- Game: AppID 1390520

-- MAIN APPLICATION
addappid(1390520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1390521, 1, "557bfde2811841a3df2eab3d679fd8752cd84947389c70547e4ebdc33605da9f")

