-- Lua provided by RyzenAPI 
-- Game: AppID 1390520
addappid(1390520)
addappid(1390521, 1, "557bfde2811841a3df2eab3d679fd8752cd84947389c70547e4ebdc33605da9f")
