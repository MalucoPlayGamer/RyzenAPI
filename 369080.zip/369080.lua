-- Lua provided by RyzenAPI
-- Game: addappid(369080)

-- MAIN APPLICATION
addappid(369080)

-- MAIN APP DEPOTS / PACKAGES
addappid(369081, 1, "44227356ea1473bb6746ebef3a8772d6638da395fbc0e4e59c6dae032304b62c")
