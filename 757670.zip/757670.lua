-- Lua provided by RyzenAPI
-- Game: Blitz Freak

-- MAIN APPLICATION
addappid(757670)

-- MAIN APP DEPOTS / PACKAGES
addappid(757671,0,"c385d73b4f04b6c3f0d0e149b469dc1f68be2dcfb02897cc6d2c99f0f6f17495")

