-- Lua provided by RyzenAPI
-- Game: BloodRush: Undying Wish

-- MAIN APPLICATION
addappid(2471390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471391, 1, "f4b06b8b8b08920d8ad52ceb779f4c3aee4a3c2c6cbd209affe03f12cc24dbb3")

