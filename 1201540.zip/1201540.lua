-- Lua provided by RyzenAPI
-- Game: HELLCARD

-- MAIN APPLICATION
addappid(1201540)
addappid(2308840)
addappid(2308841)
addappid(3039290)
addappid(3066170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201541, 1, "05f46e5015acc33d5ddb5ed1e26f714626c81381f1b1a99ac114a6c9ca56af37")
addappid(1201542, 1, "77c151416b5ecca6177f179e0cbff1877cc0fed194017a4e29d9de807fbfa0fc")
addappid(2289820, 0, "60d6725d2ba3a078ec0d750fe14de4f6fd763d6259e6ae16a5fd60a535d0c979")
