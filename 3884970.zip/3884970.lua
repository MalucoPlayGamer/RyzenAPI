-- 3884970's Lua and Manifest Created by Hubcap Manifest
-- Layer Land
-- Created: June 24, 2026 at 06:14:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3884970) -- Layer Land
-- MAIN APP DEPOTS
addappid(3884971, 1, "625d3499c19e44760688deb63794d11ccf06f607ab59b98ad05fd11ba2226e6a") -- Depot 3884971
setManifestid(3884971, "1374198851083510098", 14919695210)