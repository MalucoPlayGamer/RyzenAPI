-- Lua provided by RyzenAPI
-- Game: Layer Land

-- MAIN APPLICATION
addappid(3884970) -- Layer Land

-- MAIN APP DEPOTS / PACKAGES
addappid(3884971, 1, "625d3499c19e44760688deb63794d11ccf06f607ab59b98ad05fd11ba2226e6a") -- Depot 3884971

