-- Lua provided by RyzenAPI
-- Game: ランブルバースト

-- MAIN APPLICATION
addappid(3698720)
addappid(3717440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3698721, 1, "b1df52c913f406bedcf3b455c4fb03ac99b7c65a29c3247a6b603e35faf6c81b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
