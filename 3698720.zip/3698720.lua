-- Lua provided by RyzenAPI
-- Game: ランブルバースト

-- MAIN APPLICATION
addappid(3698720)
addappid(3717440)
-- Game: addappid(3698720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3698721, 1, "b1df52c913f406bedcf3b455c4fb03ac99b7c65a29c3247a6b603e35faf6c81b")
