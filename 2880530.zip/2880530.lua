-- Lua provided by RyzenAPI
-- Game: addappid(2880530)

-- MAIN APPLICATION
addappid(2880530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880531, 1, "05114dc0ad0b77b6e4ff825624d76922b86f7e7d1d88319c732f383d00e0d97d")
