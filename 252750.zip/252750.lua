-- Lua provided by RyzenAPI
-- Game: addappid(252750)

-- MAIN APPLICATION
addappid(252750)

-- MAIN APP DEPOTS / PACKAGES
addappid(252751, 1, "da5dd68a39262016bf3d530b98f0e8925a8007948b0f818c0c956871cd5e8e23")
