-- Lua provided by RyzenAPI
-- Game: Game: AppID 24420

-- MAIN APPLICATION
addappid(24420)
-- Game: addappid(24420)

-- MAIN APP DEPOTS / PACKAGES
addappid(24421, 1, "364fb5ca23b092ca537fab4323d0ce7d06f39066b43633c3c946697fccd14e27")
addappid(24423, 1, "7056e2d1b1acb628ce7142a915639170b7d5e9c0806233e7987e10a2b72dbf2e")
