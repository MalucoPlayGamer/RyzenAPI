-- Lua provided by RyzenAPI
-- Game: Neon Shift Demo

-- MAIN APPLICATION
addappid(2796490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2671602,0,"4e4172945890d8d3dbc43e30903712ed452edaf4b4b96317f561457be5252244")

