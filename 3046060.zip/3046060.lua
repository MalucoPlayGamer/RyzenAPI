-- Lua provided by RyzenAPI
-- Game: 3046060

-- MAIN APPLICATION
addappid(3046060)
-- Game: addappid(3046060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046061, 1, "b10edcf7cfe46d77474fcfa4971dc7a638b78df6f61d93f27cb957283f83924c")
