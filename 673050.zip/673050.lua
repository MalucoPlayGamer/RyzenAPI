-- Lua provided by RyzenAPI
-- Game: StarBallMadNess

-- MAIN APPLICATION
addappid(673050)
addappid(740800)

-- MAIN APP DEPOTS / PACKAGES
addappid(673051,0,"539826ee33aab13eea171352428b0b006cfa7724d2563a83c675c3486d1bf750")

