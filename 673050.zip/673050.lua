-- Lua provided by RyzenAPI
-- Game: StarBallMadNess

-- MAIN APPLICATION
addappid(673050)
addappid(740800)

-- MAIN APP DEPOTS / PACKAGES
addappid(673051,0,"539826ee33aab13eea171352428b0b006cfa7724d2563a83c675c3486d1bf750")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
