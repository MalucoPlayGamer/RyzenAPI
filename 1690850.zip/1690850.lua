-- Lua provided by RyzenAPI
-- Game: Game: AppID 1690850

-- MAIN APPLICATION
addappid(1690850)
-- Game: addappid(1690850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690851, 1, "3d98fffe7f4e80f2e0847d3dfdc68a117eee9f897a534ac359c0c1e0132ca1d6")
addappid(1690852, 1, "58c65bdb0a8b4dfea06f47cd2023cc0ef90ee1a8d8fc852d18fc72c813806695")
addappid(1690853, 1, "973ceaabb0fea89b73ff345961670c776faafe3ce18d3870b9ce7879d74a0997")
addappid(1690854, 1, "f0ea1c02db2152fda1837f336086730fb7c1471b09455adf163f427f77eedfb3")
addappid(1690855, 1, "82a2691facd5f146e6e408c03cedda2128d11c3741c0cd800a676654b4fc031b")
