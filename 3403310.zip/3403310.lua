-- Lua provided by RyzenAPI
-- Game: addappid(3403310)

-- MAIN APPLICATION
addappid(3403310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3403311, 1, "5ce5bfb40aa36a2bb58ab23a41befbca9652b55b40a4b121fc8d60e211816812")
