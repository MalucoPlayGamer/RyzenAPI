-- Lua provided by RyzenAPI
-- Game: Game: AppID 295690

-- MAIN APPLICATION
addappid(295690)
addappid(343290)
addappid(459070)
-- Game: addappid(295690)

-- MAIN APP DEPOTS / PACKAGES
addappid(295691, 1, "ba24ff7409b9eef47fadde799c70b332a0a57a0e7cb1c4417c2479ff2b0da214")
addappid(295692, 1, "9fae6363e26fd3af8745680682293b2bf54c5af89c4d728f8b62f0079f530310")
addappid(295693, 1, "7690f933d94a93084958bf93471d4e27fb0a1b6c309b834edd8d5a77677d7524")
