-- Lua provided by SkyAPI 
-- Game: Becoming Saint
addappid(2643010)
addappid(2643011, 1, "130525f28d0e4c01084557db637d3c2f2ad9f712fdb9655fc4e4fcc8b3a2456f")
addappid(3708260, 0, "3883f826797f04a0e6b8aaa01fb7bd42859fd7f680bc63120c792182563f707c")
