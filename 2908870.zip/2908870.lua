-- Lua provided by RyzenAPI 
-- Game: HardAF Demo
addappid(2908870)
addappid(2908871, 1, "47000e5976c9cc61ea5dd45554bffaf83abbb0e7a632cf3c1fa699b17008ccdb")
