-- Lua provided by RyzenAPI
-- Game: 2908870

-- MAIN APPLICATION
addappid(2908870)
-- Game: addappid(2908870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908871, 1, "47000e5976c9cc61ea5dd45554bffaf83abbb0e7a632cf3c1fa699b17008ccdb")
