-- Lua provided by RyzenAPI
-- Game: 1482340

-- MAIN APPLICATION
addappid(1482340)
-- Game: addappid(1482340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482341, 1, "a8aa2823f5be3ceaa9a523ecee5fcbcfe7560ff5158d270f3d544295d90ef1c5")
