-- Lua provided by RyzenAPI
-- Game: Game: Exo-Calibre

-- MAIN APPLICATION
addappid(3353860)
-- Game: addappid(3353860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3353861, 1, "68fc58dcb2a8b47f6254485ef821189e7583a153f4f2d4b79130021099a01f12")
