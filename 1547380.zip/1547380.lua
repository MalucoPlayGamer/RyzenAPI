-- Lua provided by RyzenAPI
-- Game: Game: KINGDOM of the DEAD

-- MAIN APPLICATION
addappid(1547380)
-- Game: addappid(1547380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547381, 1, "f07ad97e9c7b674797750d063c03e3e5ccc49b7d4687749d744d07db069bff04")
