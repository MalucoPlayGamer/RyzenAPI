-- Lua provided by RyzenAPI 
-- Game: The Demon Lord's Daughter and the Tower of Seals
addappid(3226870)
addappid(3226871, 1, "1e0b81513a63b8a694f1087a3c80d14e2b34de83b2f8538037dc1b74a1e21852")
addappid(3226872, 1, "16c9a3fe2ebc13e40973e25703e2f7fda40487d29e7e95f892be0a5690df049f")
