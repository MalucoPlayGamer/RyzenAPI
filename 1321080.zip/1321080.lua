-- Lua provided by RyzenAPI
-- Game: Slams City. Hitler's Escape.

-- MAIN APPLICATION
addappid(1321080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321081, 1, "46bb20207e80cb3742de3d8938dc4cec8f25d5fac80ba5f99b8675d5ef61cca4")

