-- Lua provided by RyzenAPI
-- Game: addappid(2921830)

-- MAIN APPLICATION
addappid(2921830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921831, 1, "64ee3747f9bbafea597ef8a6c45dbab3f501f4835f1883e5c6ee4066f9e58652")
