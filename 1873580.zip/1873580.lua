-- Lua provided by RyzenAPI
-- Game: I am an Air Traffic Controller 4 Soundtrack

-- MAIN APPLICATION
addappid(1873580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873581, 1, "0626fc52b39061e245fd28f048c2a57b94ec3796019b7fb4a27cf98e910b2c7b")
