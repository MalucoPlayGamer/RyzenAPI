-- Lua provided by RyzenAPI 
-- Game: AppID 3149930
addappid(3149930)
addappid(3149931, 1, "fb04f5d7e6974a50dcfe70c205c0d9330d469463d9f32e88908c7e43a7609bf7")
