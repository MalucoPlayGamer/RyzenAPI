-- Lua provided by RyzenAPI 
-- Game: SunnySide
addappid(1746930)
addappid(1746931, 1, "e4630c4d5e63fc97082aebdb46ceac4809b8938c896430afdc0322fdeb06d4b5")
