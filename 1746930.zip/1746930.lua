-- Lua provided by RyzenAPI
-- Game: SunnySide

-- MAIN APPLICATION
addappid(1746930)
-- Game: addappid(1746930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746931, 1, "e4630c4d5e63fc97082aebdb46ceac4809b8938c896430afdc0322fdeb06d4b5")
