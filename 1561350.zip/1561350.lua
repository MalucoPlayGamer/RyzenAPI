-- Lua provided by SkyAPI 
-- Game: Gladia
addappid(1561350)
addappid(1561351, 1, "b79c5de05213081f9c52f4399221e5b265a0f8d4fd5105333f2789781cd90e24")
