-- Lua provided by RyzenAPI
-- Game: addappid(2115380)

-- MAIN APPLICATION
addappid(2115380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115381, 1, "016842e0ab5a1422818defaa98aff5eb6ebdb751580fcdb64cacd6a123382b9d")
