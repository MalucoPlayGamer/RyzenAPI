-- Lua provided by RyzenAPI
-- Game: Game: AppID 1653050

-- MAIN APPLICATION
addappid(1653050)
-- Game: addappid(1653050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653051, 1, "063ad9bf6e3454c16bb1ff1880941375636fc4a93535109b2e96df76265ea84b")
