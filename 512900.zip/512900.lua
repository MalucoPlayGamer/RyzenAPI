-- Lua provided by RyzenAPI
-- Game: Streets of Rogue

-- MAIN APPLICATION
addappid(512900)
-- Game: addappid(512900)

-- MAIN APP DEPOTS / PACKAGES
addappid(512901, 1, "85fac640a9cab09f4bd49765733b59cbbea29e009c915c239326f652bf177d14")
addappid(512902, 1, "db093359282567ce3be9d37b0c25fee42806ebed62778bd9e094dc8dd854a880")
addappid(512903, 1, "178fa8e13252bbd4ea52528c7a152bbb6cf6f0a692fd6fc70998f8e2b0baa279")
addappid(512904, 1, "e44ab84fdda90ca8deb7a4d9466e07ab750421fef17f5312dd501ff320213cad")
addappid(594700, 0, "b0d449164347e2080b4d5fb8b2b3e74b48679a8156b24bccfa221ec7327079a9")
addappid(1064720, 0, "3fc57ad6ce17971fcaf856fb9aad64cbd298a0f2e22ef28f4f680e9165e9f9b1")
addappid(1285810, 0, "9cbc7d8466c5dfb83cd7180c28d967fad70f9e833af36cde9e2c006ace9a2340")
