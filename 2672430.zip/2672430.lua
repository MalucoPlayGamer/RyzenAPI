-- Lua provided by RyzenAPI
-- Game: Guardians of Eden-Embrace of the Forest

-- MAIN APPLICATION
addappid(2672430)
-- Game: addappid(2672430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672431, 1, "53f8addf6dbe106b60b6a48ed701f3466dadf54f9368b2993ead9ae5f0652588")
