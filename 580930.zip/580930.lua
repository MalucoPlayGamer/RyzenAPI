-- Lua provided by RyzenAPI
-- Game: 580930

-- MAIN APPLICATION
addappid(580930)
-- Game: addappid(580930)

-- MAIN APP DEPOTS / PACKAGES
addappid(580931, 1, "84d55dd4c6919ec4a1f051c309892116377bd6a5c3911606c0737c5cc3ae148a")
