-- Lua provided by RyzenAPI
-- Game: Game: Kly-Kly

-- MAIN APPLICATION
addappid(1919060)
-- Game: addappid(1919060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919061, 1, "4961c200895b39bd301f8aae007923d914799c00d51ff825261e7ef2811c8b95")
