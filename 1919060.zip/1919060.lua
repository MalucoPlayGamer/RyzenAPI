-- Lua provided by SkyAPI 
-- Game: Kly-Kly
addappid(1919060)
addappid(1919061, 1, "4961c200895b39bd301f8aae007923d914799c00d51ff825261e7ef2811c8b95")
