-- Lua provided by RyzenAPI
-- Game: Ninja Village

-- MAIN APPLICATION
addappid(1918520)
-- Game: addappid(1918520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918521, 1, "a8abfdbfbe04543d1490e342885881aca0eeba1ea3c39eadf73f605565ee297d")
