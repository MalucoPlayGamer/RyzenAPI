-- Lua provided by SkyAPI 
-- Game: Ninja Village
addappid(1918520)
addappid(1918521, 1, "a8abfdbfbe04543d1490e342885881aca0eeba1ea3c39eadf73f605565ee297d")
