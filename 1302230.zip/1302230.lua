-- Lua provided by RyzenAPI
-- Game: Dead Containment

-- MAIN APPLICATION
addappid(1302230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1302231, 1, "979fcf13b8f59517ff7f93afe676946e15289cdff19395be72a46b402c7d4621")

