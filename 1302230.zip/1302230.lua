-- Lua provided by RyzenAPI
-- Game: addappid(1302230)

-- MAIN APPLICATION
addappid(1302230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302231, 1, "979fcf13b8f59517ff7f93afe676946e15289cdff19395be72a46b402c7d4621")
