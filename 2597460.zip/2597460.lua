-- Lua provided by RyzenAPI
-- Game: 2597460

-- MAIN APPLICATION
addappid(2597460)
-- Game: addappid(2597460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597461, 1, "1c7778bedec8de5c6b386bd52acf28b32724331e849e93c63b66bae2d5849eba")
