-- 4117730's Lua and Manifest Created by Hubcap Manifest
-- Slayblade
-- Created: August 20, 2026 at 13:23:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4117730, 1, "4f5e925a930456715e347385a56ce0db9688809ed33a695328d43bd5d8bd9cd3") -- Slayblade
-- MAIN APP DEPOTS
addappid(4117731, 1, "90553287bd1895fc33e11586b00c6e12f031833835b1260e2c93420558db7c2a") -- Depot 4117731
setManifestid(4117731, "6349754325501428977", 93976713)