-- Lua provided by RyzenAPI
-- Game: Axe Cop

-- MAIN APPLICATION
addappid(1193300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193301, 1, "bc7bf0a49b099c8b8d4612cb0e3b805b3fa6d9204906a46e6bdee6e626051824")

