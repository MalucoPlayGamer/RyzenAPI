-- Lua provided by SkyAPI 
-- Game: GUN™
addappid(2610)
addappid(2611, 1, "cd52840677ca6fc0ca0ff0dbb725803dd29bc5e0b8f9ecaed259ec7396f2d30e")
addappid(2612, 1, "7ac3d19acb0ddb59b5656a76c304abf4acc876db74d1f08fb72a1f87e72da3c1")
addappid(2613, 1, "0dad7435ea7de4a3083bf3a8d7f45e4da8f9665e97b6318a00a62b77e301db4e")
