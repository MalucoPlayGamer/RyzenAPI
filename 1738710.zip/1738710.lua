-- Lua provided by RyzenAPI
-- Game: SCP: Observer

-- MAIN APPLICATION
addappid(1738710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738711, 1, "a8432bf12cd20aadbf1b86773dcc557de787edecc13d15265250002d339d49ef")
