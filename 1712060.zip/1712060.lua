-- Lua provided by RyzenAPI
-- Game: 欢迎加入奇趣社 Demo

-- MAIN APPLICATION
addappid(1712060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712061, 1, "0c550591030381e263ee255a7272adfdf6991504ea3959ded50bfbd6eaeefff5")
