-- Lua provided by RyzenAPI
-- Game: Game: MANIC MINERS

-- MAIN APPLICATION
addappid(511070)
-- Game: addappid(511070)

-- MAIN APP DEPOTS / PACKAGES
addappid(511071, 1, "2d1b13c42a04a38296e2de482fcb3167c3fb21b2b64e0325b086265ec3c76154")
