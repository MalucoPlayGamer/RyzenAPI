-- Lua provided by RyzenAPI 
-- Game: MANIC MINERS
addappid(511070)
addappid(511071, 1, "2d1b13c42a04a38296e2de482fcb3167c3fb21b2b64e0325b086265ec3c76154")
