-- Lua provided by RyzenAPI 
-- Game: AppID 2458210
addappid(2458210)
addappid(2458211, 1, "77863914f64007c612fb83940e76b5ae47391e63988946d95d5b687ba21886ae")
addappid(2458212, 1, "7a12ae5ace3f5df1c5d3e7f64c4aba7cd4bf962aa96e8d833c324d8052ffd05c")
