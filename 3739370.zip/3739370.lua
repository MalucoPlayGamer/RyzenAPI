-- Lua provided by SkyAPI 
-- Game: They Came for More Pasta
addappid(3739370)
addappid(3739371, 1, "90aae11b29510a43cc048c522bb28cb388a44be42fa1422d633de5c32a5b5831")
addappid(3739372, 1, "4881e4a22c2ca71bda0e636c6b1a25e2ab3bf2c65a4e502df47ac7b6d6676408")
addappid(3739373, 1, "155dbf2bde998567f88a227752dcc248717eb918e631113c3f86da9728ac12cc")
