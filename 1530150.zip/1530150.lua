-- Lua provided by RyzenAPI
-- Game: Worn Thin

-- MAIN APPLICATION
addappid(1530150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530151, 1, "27863e466d4ddb78ec99327ba25446c38cb794f70bb0c081acaf81fcb89b56cb")
