-- Lua provided by RyzenAPI
-- Game: 姬恋~缚羽的欠片 纯净中文版

-- MAIN APPLICATION
addappid(2172470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172471, 1, "5c3072797a2fca27dff37e915e134142ea11a5c3b6538d31db8e644e8a91c96a")
