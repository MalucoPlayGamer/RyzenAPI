-- Lua provided by RyzenAPI
-- Game: AppID 443330

-- MAIN APPLICATION
addappid(443330)
addappid(514320)
-- Game: addappid(443330)

-- MAIN APP DEPOTS / PACKAGES
addappid(443331, 1, "7d15ba2ebc10bfbf18b6431e9bc5d6d6d6ec65650600909d2d037574f2cc6f56")
