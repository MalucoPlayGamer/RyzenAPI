-- Lua provided by RyzenAPI
-- Game: AppID 443330

-- MAIN APPLICATION
addappid(443330)
addappid(514320)

-- MAIN APP DEPOTS / PACKAGES
addappid(443331, 1, "7d15ba2ebc10bfbf18b6431e9bc5d6d6d6ec65650600909d2d037574f2cc6f56")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
