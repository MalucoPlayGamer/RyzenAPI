-- Lua provided by RyzenAPI
-- Game: Game: 富甲天下5

-- MAIN APPLICATION
addappid(2490910)
-- Game: addappid(2490910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490911, 1, "ae3b87201baf4b646e13aa7d443171267bc3db46f18cc13e8421d1cd94bb0dda")
addappid(2490912, 1, "6b67636fd09967362bbeb23cf4c2ff01820b8fbdef08e84cea82f271430ae4b2")
addappid(2490913, 1, "bd8d815e137da63a5650816d8a6f96d5da0913c3a92c370391744f862e1c3955")
