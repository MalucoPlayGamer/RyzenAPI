-- Lua provided by RyzenAPI
-- Game: Game: Escape Escape

-- MAIN APPLICATION
addappid(2562350)
-- Game: addappid(2562350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562351, 1, "62e4a85eb7850af6cefc971401218f96817cd66393f14a49d0d40681e72f7e1e")
addappid(2562353, 1, "d6975b8e300c958059b07ad7174e51716ddf0b42730ae44ae1cbf0e1b902e230")
