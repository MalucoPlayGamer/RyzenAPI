-- Lua provided by RyzenAPI
-- Game: Game: AppID 1352050

-- MAIN APPLICATION
addappid(1352050)
-- Game: addappid(1352050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352051, 1, "e316dc7d89778c31b29a76458830766f729f0a695175e5a3984bc23b58c5baa3")
