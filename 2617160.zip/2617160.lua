-- Lua provided by RyzenAPI
-- Game: 2617160

-- MAIN APPLICATION
addappid(2617160)
-- Game: addappid(2617160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617161, 1, "4a03a786c20c5ee4490553fdb32b9d0e590f8a774ce7a4fa44115260555ead5d")
