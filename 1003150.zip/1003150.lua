-- Lua provided by RyzenAPI
-- Game: Game: AppID 1003150

-- MAIN APPLICATION
addappid(1003150)
-- Game: addappid(1003150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003151, 1, "e38ee4478a19697dd819713b1110b2b617a814b7857a6c25df51948ad0b08d94")
