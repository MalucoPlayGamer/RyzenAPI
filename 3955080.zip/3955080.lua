-- Lua provided by RyzenAPI
-- Game: Villa Nocturne

-- MAIN APPLICATION
addappid(3955080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3955081,0,"1fb8f3cdd2406eb1be29e5fdab288586f9e1b688d8531618f15865d79a37591e")

