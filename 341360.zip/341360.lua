-- Lua provided by RyzenAPI
-- Game: 341360

-- MAIN APPLICATION
addappid(341360)
-- Game: addappid(341360)

-- MAIN APP DEPOTS / PACKAGES
addappid(341361, 1, "f8029d26fb58f8d988085b5ae0c147c98001c56f9adbbc083c5149df65bef475")
