-- Lua provided by RyzenAPI
-- Game: Artificial Fashionista

-- MAIN APPLICATION
addappid(2924880)
addappid(3045920)
addappid(3045930)
addappid(3045940)
addappid(3045950)
addappid(3582580)

