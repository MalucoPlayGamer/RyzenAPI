-- Lua provided by RyzenAPI
-- Game: Artificial Fashionista

-- MAIN APPLICATION
addappid(2924880)
