-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1375369)
-- Game: addappid(1375369)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375369,0,"21167464e984b91d747afe5ec8084ae53e0dd6613cdd94f6347bd788916a716d")
