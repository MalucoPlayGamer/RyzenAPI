-- Lua provided by RyzenAPI
-- Game: Escape Room - The Sick Colleague Demo

-- MAIN APPLICATION
addappid(1311000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301721,0,"e15c5fcffaf9da8ed7eba10b8fb52092c50d5282fdde85e6d18c87f8b6878324")

