-- Lua provided by RyzenAPI
-- Game: Orc Attack: Flatulent Rebellion

-- MAIN APPLICATION
addappid(268520)

-- MAIN APP DEPOTS / PACKAGES
addappid(268521, 1, "e38f64a90d07bffb8f500170455f3abdf20afbd3455fa6f665a5ac1a556f74c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
