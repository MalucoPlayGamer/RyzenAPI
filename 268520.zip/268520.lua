-- Lua provided by RyzenAPI
-- Game: Orc Attack: Flatulent Rebellion

-- MAIN APPLICATION
addappid(268520)

-- MAIN APP DEPOTS / PACKAGES
addappid(268521, 1, "e38f64a90d07bffb8f500170455f3abdf20afbd3455fa6f665a5ac1a556f74c3")
