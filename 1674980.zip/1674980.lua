-- Lua provided by RyzenAPI
-- Game: Viking Heroes 2

-- MAIN APPLICATION
addappid(1674980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674981, 1, "f5bc441f3556f4f2a8b500a303c3b0429d0e90309862b346cb8fc3d1849f9800")

