-- Lua provided by RyzenAPI
-- Game: Noble Fates

-- MAIN APPLICATION
addappid(1769420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769421, 1, "40032980f886ca48cbe7393f3c1214d5bd9c49322e47ae8c9d124ed0b38dd7be")
