-- Lua provided by RyzenAPI
-- Game: Star Trek: Infinite - Neutral Zone Tunes

-- MAIN APPLICATION
addappid(2620800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620800,0,"e5e7164e40f331f64fd0156fb13622518cf87cc3bbee29a50653706e14d48a3a")

