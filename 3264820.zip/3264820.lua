-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3264820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264822,0,"c4089c5e9b41971e0020947c5dc5808d079f7ff45dfc3744a0a19cfdd55f355c")
