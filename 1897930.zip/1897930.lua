-- Lua provided by RyzenAPI
-- Game: 怠惰的怪獸公主不想工作 Demo

-- MAIN APPLICATION
addappid(1897930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897931, 1, "79d7d77c802c55797a033ddb1f403680c6f2f59a54908cf429f0a8fea22e46f1")
