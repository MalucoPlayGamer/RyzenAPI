-- Lua provided by RyzenAPI
-- Game: AppID 1614550

-- MAIN APPLICATION
addappid(1614550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1614551, 1, "3371255cd228c41ba67c24f9d6c608715ab70e7f9b5c50d2eabe99e3b503d5e9")

