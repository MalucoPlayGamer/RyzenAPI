-- Lua provided by RyzenAPI
-- Game: Game: AppID 1614550

-- MAIN APPLICATION
addappid(1614550)
-- Game: addappid(1614550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614551, 1, "3371255cd228c41ba67c24f9d6c608715ab70e7f9b5c50d2eabe99e3b503d5e9")
