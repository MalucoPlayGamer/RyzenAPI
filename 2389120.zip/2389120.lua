-- Lua provided by RyzenAPI
-- Game: AppID 2389120

-- MAIN APPLICATION
addappid(2389120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389121, 1, "e66b46c3ce6fbe07784d2b0ecf1b475b03fb0b58fe6b75ebc77602cbbf0894db")
