-- Lua provided by RyzenAPI
-- Game: Tails of Iron

-- MAIN APPLICATION
addappid(1283410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283411, 1, "9088237d7b955a99fcfb88a0fe335ea74903e34559c6e2fdcc8140a7612c9f85")
addappid(1283412, 1, "fbed7072cbd0df3d340fc2762582822cdcc9fb17d3b677dcd3729066b30306cf")
addappid(1283413, 1, "8c7d457e9140157ca27c50e2801244020606739f29c0a083d3f878603d784d5d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1677120)
addappid(2715450)
