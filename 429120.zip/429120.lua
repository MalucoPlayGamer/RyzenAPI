-- Lua provided by RyzenAPI 
-- Game: Zamarian
addappid(429120)
addappid(429121, 1, "c6faed68444eabf557f161b9dd6b80f5ced4cf23b6b309d404e46bd9dd52dae7")
addappid(429122, 1, "1998b3d0cca97bbf8a33a766f6bad1e34d11309bfc574439b423632b9174189d")
addappid(429123, 1, "e1b95698e2dbf625404527bfb91597416a9819e1b16a0ab742237683942ffcfe")
