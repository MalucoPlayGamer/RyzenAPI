-- Lua provided by RyzenAPI
-- Game: Iron Harvest

-- MAIN APPLICATION
addappid(826630)
addappid(1341700)
addappid(1341701)
addappid(1341702)
addappid(1341703)
addappid(1628070)

-- MAIN APP DEPOTS / PACKAGES
addappid(826631,0,"d8be3df0a3621fbdc240ad82627e30a49fb44377c9e3853dcedbbc13f688c950")
addappid(826632,0,"2de56d135ce616ca3d7c317cab731d0e7cae6993e3da80bfebc062b3549930c3")
addappid(1341700,0,"e57395b0a6ef343f1cc7270bb3de56cb0c8c5b327c9ee0d8a06de8233bda5050")
addappid(1341701,0,"3a1b0e7f86ab77de1157f8fd35b197e866b8162d216e225c6e0e0a409d145b38")
addappid(1341702,0,"cc8401539e1c438a04e72b9349c091e5327c74c15f9e58981e4e0a7cdd77294d")
addappid(1628070,0,"21f7c10c96c7b8e840a421e65dff7aaa4d6eaacf1efabb3ddb27cadb0337e178")

