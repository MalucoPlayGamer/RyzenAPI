-- Lua provided by RyzenAPI
-- Game: The Artifact

-- MAIN APPLICATION
addappid(532920)

-- MAIN APP DEPOTS / PACKAGES
addappid(532921, 1, "301baa1a59e191a86142cc1de6ff3e1e57c9a08ce9b53f3ebff0a563238280af")

