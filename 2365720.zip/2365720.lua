-- Lua provided by SkyAPI 
-- Game: 龙栖 Soundtrack
addappid(2365720)
addappid(2365721, 1, "af1761cb9270ef5a32d35d41d393cf52bc07ce85e619f5f22f298adf23fe4217")
