-- Lua provided by RyzenAPI
-- Game: 2138600

-- MAIN APPLICATION
addappid(2138600)
-- Game: addappid(2138600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138601, 1, "cd4245028a19eecf3f6a2d301bd34acd89d5d5bbd0e33ef6c0906fe98d949d62")
