-- Lua provided by RyzenAPI 
-- Game: Tapering Tower
addappid(2138600)
addappid(2138601, 1, "cd4245028a19eecf3f6a2d301bd34acd89d5d5bbd0e33ef6c0906fe98d949d62")
