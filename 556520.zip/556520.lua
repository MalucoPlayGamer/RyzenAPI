-- Lua provided by RyzenAPI
-- Game: Housekeeping VR

-- MAIN APPLICATION
addappid(556520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(556521,0,"12f91ff1398106892c73d6ff9918e1a8f64657ae6c76b4316027744cf6338a75")

