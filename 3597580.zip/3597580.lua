-- Lua provided by RyzenAPI
-- Game: Earthion

-- MAIN APPLICATION
addappid(3597580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3597581, 1, "86019d14a0a621f503dcbc105e3ed6e3e8f0abc3f05c54e50a0385247b95ef12")

