-- Lua provided by RyzenAPI
-- Game: 1912043

-- MAIN APPLICATION
addappid(1912043)
-- Game: addappid(1912043)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912043,0,"23a27dd51ecac0668c8fb2985a3f7cec99acca77e63aa2c2e9fce40983e6a329")
