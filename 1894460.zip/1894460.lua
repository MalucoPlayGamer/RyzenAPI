-- Lua provided by RyzenAPI
-- Game: Zombie Within

-- MAIN APPLICATION
addappid(1894460)
addappid(3078050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894461, 1, "6b4c8a0f22f02e97af974cb3ef95e2a33af06801c660628a48abbfa74be4b86e")

