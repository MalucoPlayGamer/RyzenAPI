-- Lua provided by RyzenAPI
-- Game: Sender

-- MAIN APPLICATION
addappid(2371220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371221, 1, "d7cbbf2a32878fa051a29186f39f343ee9949bf90f9104084094c065ac3ef201")
