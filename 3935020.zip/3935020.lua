-- Lua provided by RyzenAPI
-- Game: Backyard Baseball

-- MAIN APPLICATION
addappid(3935020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3935021,0,"0408029333b8fb91116eedd0fcdfc3aaca556fd8695ded07acfd5d99c2dace89")
addappid(3935022,0,"e2d083324d8b66c7ee9b4bed9bcd9d546c24f0fcf0c5be75e1e11af6328e9524")

