-- Lua provided by RyzenAPI
-- Game: Towards The Pantheon: Escaping Eternity

-- MAIN APPLICATION
addappid(709450)

-- MAIN APP DEPOTS / PACKAGES
addappid(709451, 1, "673cffe5642ed4c14609e66dbba50c01e2882a4be23d05356217e83896a28fac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(767990)
