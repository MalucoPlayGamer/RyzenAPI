-- Lua provided by RyzenAPI
-- Game: Game: Towards The Pantheon: Escaping Eternity

-- MAIN APPLICATION
addappid(709450)
-- Game: addappid(709450)

-- MAIN APP DEPOTS / PACKAGES
addappid(709451, 1, "673cffe5642ed4c14609e66dbba50c01e2882a4be23d05356217e83896a28fac")
