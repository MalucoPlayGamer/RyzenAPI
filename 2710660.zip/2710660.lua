-- Lua provided by RyzenAPI
-- Game: addappid(2710660)

-- MAIN APPLICATION
addappid(2710660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710661, 1, "a762a85ca74405dff0371f09eeb715edb3ced0ff0b8ca03a55903a211a943453")
