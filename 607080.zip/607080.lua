-- Lua provided by RyzenAPI
-- Game: Psychonauts 2

-- MAIN APPLICATION
addappid(607080)
addappid(3245600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(607081, 1, "dfdca4a6e8f903ffd1a93290a893899e0726edc7a8c7b39fdff62b40c0994915")
addappid(607082, 1, "22a93ea0c402ea4df646974f91bbecdb6652294221f11654e861ccb74c6e71e2")
addappid(607083, 1, "e4a2441ee7da2b2cc4c57b8b9df23febbd76b6f695db493faa01fe2988244b5b")

