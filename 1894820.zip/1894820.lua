-- Lua provided by RyzenAPI
-- Game: Outshine Demo

-- MAIN APPLICATION
addappid(1894820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894821, 1, "9ae766686553b712a3b38633ff73cbbabc646ccc3de21046b6e30d45f60ee5ad")
