-- Lua provided by RyzenAPI
-- Game: Whisper of the House

-- MAIN APPLICATION
addappid(2589500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589501, 1, "6f51226f61dd888511279cdc32b68f2eafddb79f8d92998ffcac30e6dae73021")
