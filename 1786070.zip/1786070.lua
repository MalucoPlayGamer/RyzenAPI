-- Lua provided by RyzenAPI
-- Game: addappid(1786070)

-- MAIN APPLICATION
addappid(1786070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786072,0,"329ac0cba875b7c7ae4a1ccad3b16414c43da86a9f84fc91f5a4ce4bbc60bb98")
