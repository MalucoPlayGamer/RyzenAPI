-- Lua provided by RyzenAPI
-- Game: AppID 886060

-- MAIN APPLICATION
addappid(886060)
-- Game: addappid(886060)

-- MAIN APP DEPOTS / PACKAGES
addappid(886061, 1, "513a0e66f219ecf09304bac036b96439b96511487bf02f01551e0da106942bbd")
