-- Lua provided by RyzenAPI
-- Game: Sleeping Dogs: Definitive Edition

-- MAIN APPLICATION
addappid(307690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(307691, 1, "16e218fadcf1fd663c320861c008944503ae0e2725445797fd5043efb3806809")
addappid(307692, 1, "ccb1da56b95d82ffb9c3d29e4c19b6a782988c14c610a8ca674ead32d0f6cc8d")
addappid(307693, 1, "9deece342bce4e677c7c91c18a4e137aaa45e689533db5aa669ba83ea6cbc8cb")
addappid(307694, 1, "dd8ea35584589906ffef100d5d805f816c71b9dc99efe76a4e4eab647baceda4")
addappid(307695, 1, "1c80d5c2e7555bfabf795cfbbe8cb7449132c279f20bfbaa43351e72fe09b2d4")
addappid(307696, 1, "a265aef4fa6f4034eff3b39b421a9405aa44454654e8c7778847df6bb3684c59")

