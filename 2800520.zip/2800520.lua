-- Lua provided by RyzenAPI
-- Game: Game: Sex Magic 🔮

-- MAIN APPLICATION
addappid(2800520)
-- Game: addappid(2800520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800521, 1, "9bf090c07ca4f0ddf60ea1d061067b07e15c87cb3496efa70294b32941d94bd1")
