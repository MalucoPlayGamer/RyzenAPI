-- Lua provided by RyzenAPI 
-- Game: Sex Magic 🔮
addappid(2800520)
addappid(2800521, 1, "9bf090c07ca4f0ddf60ea1d061067b07e15c87cb3496efa70294b32941d94bd1")
