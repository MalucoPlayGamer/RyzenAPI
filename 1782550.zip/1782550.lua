-- Lua provided by RyzenAPI
-- Game: Royal Order Demo

-- MAIN APPLICATION
addappid(1782550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782552,0,"1ebdcc8915e9e89ec37cf8cc23cc024e4b27b34f9919a54d42dcd174f1ad75e3")

