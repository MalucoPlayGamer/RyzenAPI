-- Lua provided by RyzenAPI
-- Game: Mafia: The Old Country - Padrino Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(3269260, 1)

