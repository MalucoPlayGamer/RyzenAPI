-- Lua provided by RyzenAPI
-- Game: 3269260

-- MAIN APP DEPOTS / PACKAGES
addappid(3269260, 1)
-- Game: addappid(3269260, 1)
