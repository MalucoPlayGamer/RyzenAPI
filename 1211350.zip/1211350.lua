-- Lua provided by RyzenAPI
-- Game: Game: The Note of Red Evil

-- MAIN APPLICATION
addappid(1211350)
-- Game: addappid(1211350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211351, 1, "f3700175ba9757802a43e482d8b024182e06fcd6b8df6d505a52c150d2aaf623")
