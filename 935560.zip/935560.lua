-- Lua provided by RyzenAPI
-- Game: AppID 935560

-- MAIN APPLICATION
addappid(935560)

-- MAIN APP DEPOTS / PACKAGES
addappid(935561, 1, "f9dcecad1205b0914aa5b256e9bdc3448be336f9c520bed4b249216bb5e141b1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(939860)
