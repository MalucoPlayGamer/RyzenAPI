-- Lua provided by RyzenAPI
-- Game: Project Green Beat

-- MAIN APPLICATION
addappid(340480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(340481, 1, "0286e4b147710330cf54221cc9801ba0e166ae096ff217472067d5cc3f620fe5")

