-- Lua provided by RyzenAPI
-- Game: Project Green Beat

-- MAIN APPLICATION
addappid(340480)
-- Game: addappid(340480)

-- MAIN APP DEPOTS / PACKAGES
addappid(340481, 1, "0286e4b147710330cf54221cc9801ba0e166ae096ff217472067d5cc3f620fe5")
