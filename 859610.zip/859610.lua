-- Lua provided by RyzenAPI
-- Game: S.T.R.E.T.C.H.

-- MAIN APPLICATION
addappid(859610)
-- Game: addappid(859610)

-- MAIN APP DEPOTS / PACKAGES
addappid(859611, 1, "0e0c665a2249bea3e39f1c2dccab7fb8e33393c7c4a36010aed82f205a70f970")
addappid(894230, 0, "a24c55fe099d69f723b202e2532e91340309f1646782634d2964f8cdfd16d8d4")
