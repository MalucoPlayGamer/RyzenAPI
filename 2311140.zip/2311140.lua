-- Lua provided by RyzenAPI
-- Game: addappid(2311140)

-- MAIN APPLICATION
addappid(2311140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311141, 1, "b22861ffa340dbfcd791dc10b2f313a62d7b8c06b9ce7ffa9fd1a6e416c97460")
