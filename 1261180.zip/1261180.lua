-- Lua provided by SkyAPI 
-- Game: Rebirth Online
addappid(1261180)
addappid(1261181, 1, "a29fb86e0b78c44e2dc7caf32ad21e8c800b75da30bf045e05abc9f40b368ad9")
