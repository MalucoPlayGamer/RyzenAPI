-- Lua provided by RyzenAPI
-- Game: Age of Gods

-- MAIN APPLICATION
addappid(4545850)
addappid(4557590)
addappid(4557600)
addappid(4557630)
addappid(4557650)
addappid(4557660)
addappid(4557680)
addappid(4557690)
addappid(4557700)
addappid(4557710)
addappid(4557720)
addappid(4557730)
addappid(4557790)
addappid(4617820)
addappid(4617830)
addappid(4675540)
addappid(4675550)
addappid(4675570)
addappid(4675580)

