-- Lua provided by RyzenAPI
-- Game: Age of Gods

-- MAIN APPLICATION
addappid(4545850)

