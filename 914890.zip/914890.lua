-- Lua provided by RyzenAPI
-- Game: AppID 914890

-- MAIN APPLICATION
addappid(914890)

-- MAIN APP DEPOTS / PACKAGES
addappid(914891, 1, "f4bc0440fed9d2f3e4f7e479e3082fb552e4b0c0e853820dac545d87dfd97a93")
