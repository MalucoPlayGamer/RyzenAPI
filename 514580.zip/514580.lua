-- Lua provided by RyzenAPI 
-- Game: AppID 514580
addappid(514580)
addappid(514581, 1, "de68514e4de8687464b022567b9d8b8bb7c8369f9e6179b5b1151e9f5b3628bc")
