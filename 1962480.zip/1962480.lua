-- Lua provided by RyzenAPI
-- Game: Night of Love - 18+ Adult Only Patch

-- MAIN APPLICATION
addappid(1962480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962480,0,"73fbd5467c67eaa8eaa66e6c2c14f5fc914b2a645be9020d1ca8d04c6395b8f8")

