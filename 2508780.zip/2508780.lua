-- Lua provided by RyzenAPI
-- Game: STORY OF SEASONS: Grand Bazaar

-- MAIN APPLICATION
addappid(2508780)
addappid(3847810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508781, 1, "d3d2cecbf425b32af43928d0b54fb991edc1a74dfac4d72d31a47b22d078ec14")
addappid(3051830, 0, "11061a1ed5036b24ad17351d518ca68411d4fe283cf6156176f5d161b9044ebc")
addappid(3248040, 0, "d671f9d0718c441e13b212891d9003f5260e69433455f44bcf2c768e61173336")
addappid(3482230, 0, "0789e54527d096025f42b5c9e7196eed567c1e7b5a83a8466121fe86a3b6a8bb")
addappid(3847830, 0, "418b5c8fd01c80869d13b37d6ddff62844ed8fa89b0c9c3803a9846c36a96c3f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3051770)
addappid(3051780)
addappid(3051790)
addappid(3051800)
addappid(3051810)
addappid(3051820)
addappid(3406540)
addappid(3847820)
addappid(4426530)
addappid(4426540)
addappid(4695490)
