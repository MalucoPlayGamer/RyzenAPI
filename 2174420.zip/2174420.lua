-- Lua provided by RyzenAPI
-- Game: 2174420

-- MAIN APPLICATION
addappid(2174420)
-- Game: addappid(2174420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174421, 1, "babd8557d5602e0a12dde6953bb1124320adf526a00bbc39a771177cc475953a")
