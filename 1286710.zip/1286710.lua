-- Lua provided by RyzenAPI
-- Game: Hylics 2

-- MAIN APPLICATION
addappid(1286710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286711, 1, "c689c9ba15c582c3835f1e59018bf87ad2f17556a431923f7f4ffdd85ca7a1b2")
addappid(1286712, 1, "c138da20be0d8f6be152655696a8bd1e4dadf87e06e62fa4aa4f9a008d1f7725")
