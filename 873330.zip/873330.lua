-- Lua provided by RyzenAPI
-- Game: Color by Numbers - Flowers

-- MAIN APPLICATION
addappid(873330)

-- MAIN APP DEPOTS / PACKAGES
addappid(873331,0,"3eb7fdb9e7e9ef116e8b9573cfd14466fb5434ee4eb1c35c9a93efba217fbd48")

