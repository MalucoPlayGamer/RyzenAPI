-- Lua provided by RyzenAPI
-- Game: Night at the Office

-- MAIN APPLICATION
addappid(3305350)
-- Game: addappid(3305350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3305351, 1, "842c51278f52d510828f7775e7729a67c2bd44b4832bb0c89cf165eb5fcc6038")
