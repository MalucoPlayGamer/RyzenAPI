-- Lua provided by RyzenAPI
-- Game: Hack Time

-- MAIN APPLICATION
addappid(526450)
-- Game: addappid(526450)

-- MAIN APP DEPOTS / PACKAGES
addappid(526451, 1, "93cc23c78d415bb1875f419fc332ba65dad1efca481711479b239ce32f2c4d26")
