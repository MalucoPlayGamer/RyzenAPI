-- Lua provided by RyzenAPI
-- Game: Battle Nations

-- MAIN APPLICATION
addappid(251670)
