-- Lua provided by RyzenAPI
-- Game: 3452320

-- MAIN APPLICATION
addappid(3452320)
-- Game: addappid(3452320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452322,0,"de5a8b60428fc142f408df97cd79a756fa8cc90be948747cc948a0eb06e40c40")
