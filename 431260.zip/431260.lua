-- Lua provided by RyzenAPI
-- Game: AppID 431260

-- MAIN APPLICATION
addappid(431260)
-- Game: addappid(431260)

-- MAIN APP DEPOTS / PACKAGES
addappid(431261, 1, "94177ad948451c537fa61016b69695ab9deb1238048f5acd80519a94899bceba")
