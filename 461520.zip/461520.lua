-- Lua provided by RyzenAPI
-- Game: AppID 461520

-- MAIN APPLICATION
addappid(461520)

-- MAIN APP DEPOTS / PACKAGES
addappid(461521, 1, "ef84f3c861d13fe16bd681c8eeb0ddf1e07dae08d9192b958694b5c9126be5ce")
