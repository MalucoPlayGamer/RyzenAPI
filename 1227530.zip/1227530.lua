-- Lua provided by RyzenAPI
-- Game: Partisans 1941

-- MAIN APPLICATION
addappid(1227530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227531, 1, "e45240b32195cd1d4d03b178adb9468267ac2d874a9c0755c3b4980a3eeb9593")
addappid(1439000, 0, "44119551dd77619de388a37d0f6c8c95f21d1f0bc7e537eb123e5f64464a4cd3")
addappid(1439001, 0, "9efe86810f2eda333cc64abbb68742ff689326ea6e1e4a5d78adf4afd5ee3f2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
