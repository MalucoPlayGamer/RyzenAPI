-- Lua provided by RyzenAPI
-- Game: Celeste Soundtrack

-- MAIN APPLICATION
addappid(1092840)
-- Game: addappid(1092840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092841, 1, "c4c08701ff5bd1f0cdd2c602fd115ccca0d404d763de7c4148c43e1fe19e878c")
