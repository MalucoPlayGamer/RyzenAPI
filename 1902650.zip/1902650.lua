-- Lua provided by RyzenAPI
-- Game: Come See My Hole

-- MAIN APPLICATION
addappid(1902650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902651, 1, "69216284c7d776685c7303f39732b1d3c4eaa299ad4a66603c88e1fe0d8c9462")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
