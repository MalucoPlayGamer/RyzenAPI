-- Lua provided by RyzenAPI
-- Game: Besiege Original Soundtrack

-- MAIN APPLICATION
addappid(2959930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959931, 1, "d8b341ae519ba6ae755bd0df6df9925fc0901bfcaf5d2f3488aa25d0a0d841d2")
addappid(2959932, 1, "d888bcb0dea39efec45ab73172467144f52298904f0409d540fc0cb57f8f4af7")

