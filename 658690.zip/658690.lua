-- Lua provided by RyzenAPI
-- Game: Rage in Peace

-- MAIN APPLICATION
addappid(658690)

-- MAIN APP DEPOTS / PACKAGES
addappid(658691, 1, "4eed7ba8f97d8155809d8fdc793460b046f4125d495381e3df05dd784c2214aa")
addappid(658692, 1, "f349a67a8bda8fe20eac69e0dc0cd7944067f409f9b2fc5b5b562a079eeee8e9")
