-- Lua provided by RyzenAPI
-- Game: addappid(661500)

-- MAIN APPLICATION
addappid(661500)

-- MAIN APP DEPOTS / PACKAGES
addappid(661501, 1, "4d0e2be2df02c61d0e890ce18a1cabddf2bbb60464ceffcaa0df0a871d59b468")
