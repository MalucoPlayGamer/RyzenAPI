-- Lua provided by RyzenAPI
-- Game: Ancient: Legacy of Azul

-- MAIN APPLICATION
addappid(1661920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661921, 1, "992dc8b42b16e14f2863f5b52184afbaaf3486aef11bb80863ccd9790a5946d8")

