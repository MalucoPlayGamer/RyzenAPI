-- Lua provided by RyzenAPI 
-- Game: AppID 3290670
addappid(3290670)
addappid(3290671, 1, "d0b05d96d2c0ff25f928e58764e51625b535348993d3f6eaa3e7439bb2db5a11")
