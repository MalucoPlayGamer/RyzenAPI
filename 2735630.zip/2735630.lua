-- Lua provided by RyzenAPI
-- Game: Game: Frostrain

-- MAIN APPLICATION
addappid(2735630)
-- Game: addappid(2735630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735631, 1, "d406b66fe7e7939cb659f2f307f49a3df75c905b617f3991b21df3be11efc44a")
