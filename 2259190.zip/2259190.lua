-- Lua provided by RyzenAPI
-- Game: Protos Magos

-- MAIN APPLICATION
addappid(2259190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2259191, 1, "42cf7c5415784bf2ae961ca08cfe1008bfacfabe71b16428626ae571a863be83")

