-- Lua provided by RyzenAPI 
-- Game: Protos Magos
addappid(2259190)
addappid(2259191, 1, "42cf7c5415784bf2ae961ca08cfe1008bfacfabe71b16428626ae571a863be83")
