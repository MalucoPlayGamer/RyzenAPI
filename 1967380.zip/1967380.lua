-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 2022 - Good Game Pack

-- MAIN APPLICATION
addappid(1967380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967380,0,"f8dc9f726266ce2f77616176c56140f4800370aabb817865e6cb78897ad93da6")

