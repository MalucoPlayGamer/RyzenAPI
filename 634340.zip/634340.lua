-- Lua provided by RyzenAPI 
-- Game: AppID 634340
addappid(634340)
addappid(634341, 1, "2df235a2678d2e6670b2a75c4d4923e0741e070002db35b1d4a0a71cf119bbf8")
addappid(634342, 1, "a561359d69570213d79f74c7df914cc7b7cd4436c6dedbda3e3050153090a7fb")
