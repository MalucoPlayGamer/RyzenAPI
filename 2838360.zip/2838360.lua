-- Lua provided by RyzenAPI
-- Game: SINce Memories: Off The Starry Sky

-- MAIN APPLICATION
addappid(2838360)
-- Game: addappid(2838360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838361, 1, "d8abfe0bffa0aa31eed1c96624f7db1f5eb3b43544cbcbcbde2ad951426fbf9a")
