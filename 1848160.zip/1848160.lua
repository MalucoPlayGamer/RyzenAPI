-- Lua provided by RyzenAPI
-- Game: AMaze DOS

-- MAIN APPLICATION
addappid(1848160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848161, 1, "c1bb50828a7f472e67a6cb008433885bbadc353bb9d65b0c6489781dd01ca639")

