-- Lua provided by RyzenAPI
-- Game: Game: AppID 1148740

-- MAIN APPLICATION
addappid(1148740)
-- Game: addappid(1148740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148741, 1, "9b0d087902b58069ac3e890583f74447ca692fc5b8fb4e6a64cdd595ad4283be")
