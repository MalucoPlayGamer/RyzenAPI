-- Lua provided by RyzenAPI
-- Game: Catto Pew Pew! CLASSIC

-- MAIN APPLICATION
addappid(2065330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065332,0,"c827eff6fbb6a002530c6d61b8ed13535937fa448e905d927431763ad3a01433")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2070910)
addappid(2136650)
addappid(2236210)
