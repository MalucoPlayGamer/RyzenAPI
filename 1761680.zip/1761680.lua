-- Lua provided by RyzenAPI
-- Game: Game: Red Triangle Super Collection

-- MAIN APPLICATION
addappid(1761680)
-- Game: addappid(1761680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761681, 1, "990ac657d96887ae5dc6e45825491d6661dde46c494cf16add2cd9a3488b845b")
