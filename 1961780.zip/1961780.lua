-- Lua provided by RyzenAPI
-- Game: Gordianaut

-- MAIN APPLICATION
addappid(1961780)
-- Game: addappid(1961780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961781, 1, "871a5f80a5ec78a3041bfa1a652e0db9b0fc78e6261d5c8f963833127a71a0bf")
