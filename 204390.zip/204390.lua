-- Lua provided by RyzenAPI
-- Game: Pineapple Smash Crew

-- MAIN APPLICATION
addappid(204390)

-- MAIN APP DEPOTS / PACKAGES
addappid(204391, 1, "f37994ed4507f5332699a8971cf62a5f02d013ce4f1b66a5a88d75e4deee09a4")

