-- Lua provided by RyzenAPI
-- Game: Strayed

-- MAIN APPLICATION
addappid(2359470)
addappid(3344210)
addappid(3344220)
addappid(3344230)
addappid(3422360)
addappid(3422370)
addappid(3422380)
addappid(3652050)
addappid(3652060)
addappid(3671390)
addappid(3712840)
addappid(3747170)
addappid(3761150)
addappid(3852720)
addappid(3891280)
addappid(3891320)
addappid(3917360)
addappid(4036060)
addappid(4092820)
addappid(4092830)
addappid(4095280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359471, 1, "fae5ab274cd384def39251b423becea322c959a06e5ec256ba8460c38b2b79c3")
