-- Lua provided by RyzenAPI
-- Game: The Brothers Hotel

-- MAIN APPLICATION
addappid(3443410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3443411, 1, "d988ad6faa06a48a6e0bda2191a324b04f213255c17b3d8d870475fb7b25321d")

