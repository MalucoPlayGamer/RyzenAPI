-- Lua provided by SkyAPI 
-- Game: The Brothers Hotel
addappid(3443410)
addappid(3443411, 1, "d988ad6faa06a48a6e0bda2191a324b04f213255c17b3d8d870475fb7b25321d")
