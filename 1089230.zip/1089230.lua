-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Easy Hammer-on Exercise 2

-- MAIN APPLICATION
addappid(1089230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089230,0,"f15ee2b73d2e3f7a55e719f7f968256a5f82c855707132db1b8e3ca07aad9968")

