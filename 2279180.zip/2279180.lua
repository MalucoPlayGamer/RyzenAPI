-- Lua provided by RyzenAPI
-- Game: Game: AppID 2279180

-- MAIN APPLICATION
addappid(2279180)
-- Game: addappid(2279180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279181, 1, "e98b6734851c0390780417dd3ccb26e414c484c25a1f1b02ee852f05bc34deef")
