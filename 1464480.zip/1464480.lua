-- Lua provided by RyzenAPI
-- Game: 1464480

-- MAIN APPLICATION
addappid(1464480)
addappid(1468700)
-- Game: addappid(1464480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464481, 1, "7cce4db0505f2731939ebd6182fcaf1f7b6f45438898f9eb4b8b005cf402b9c0")
addappid(1464482, 1, "cef0564b4ef726fa94b211ff1d16d8bcf3c23489123e179e3768d569ff596b7f")
