-- Lua provided by RyzenAPI
-- Game: Game: Cubic Color

-- MAIN APPLICATION
addappid(800320)
-- Game: addappid(800320)

-- MAIN APP DEPOTS / PACKAGES
addappid(800321, 1, "3e794ce1e6893aa62205b305d6779557eceaa5ea229ccdff82c03887c84f9ff8")
addappid(800322, 1, "6aec64ac7500368cfd20ed0c0e7415b8983c9474b64051b680f7be2e3578223d")
addappid(800323, 1, "90399fbf806ce702832804e0fa8697a89d618c2cc89b197a37c416281c357d5e")
