-- Lua provided by RyzenAPI
-- Game: In The Night You Had Bad Dreams

-- MAIN APPLICATION
addappid(3320600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320602,0,"0cd6ac5e62b0f24488ea7522cd01501c2387a9988862c91d3a10900d2209ab0e")
