-- Lua provided by RyzenAPI
-- Game: Game: AppID 1371140

-- MAIN APPLICATION
addappid(1371140)
-- Game: addappid(1371140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371141, 1, "a8b8a9769e8e329b0a500efc876dfde9743c5397244928b4223e1266a11d87ce")
