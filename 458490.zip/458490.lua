-- Lua provided by SkyAPI 
-- Game: Who Must Die
addappid(458490)
addappid(458491, 1, "fdc8690ee9a1528ed1b30cdf056de4301285a3376ec8d5b8d4d00507eb0fdf78")
addappid(650390)
