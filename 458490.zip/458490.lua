-- Lua provided by RyzenAPI
-- Game: Who Must Die

-- MAIN APPLICATION
addappid(458490)
addappid(650390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(458491, 1, "fdc8690ee9a1528ed1b30cdf056de4301285a3376ec8d5b8d4d00507eb0fdf78")

