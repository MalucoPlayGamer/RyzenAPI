-- Lua provided by RyzenAPI
-- Game: Super Bernie World

-- MAIN APPLICATION
addappid(1258040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258041, 1, "8709a240ba8d5f583c3a92df25ac6dc829bb630aaf7b402b3c742971b93e5042")
addappid(1258042, 1, "683de3edffa29678adba65c50f7c0e3b78fdaa7228a8460c2e46077bbe1d9d75")
addappid(1258043, 1, "82b47401774cd0dceb2bd336e1ebbe5db93dc9f05278a7ba851731515b590672")

