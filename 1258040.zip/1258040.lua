-- Lua provided by RyzenAPI
-- Game: Super Bernie World

-- MAIN APPLICATION
addappid(1258040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258041, 1, "8709a240ba8d5f583c3a92df25ac6dc829bb630aaf7b402b3c742971b93e5042")
addappid(1258042, 1, "683de3edffa29678adba65c50f7c0e3b78fdaa7228a8460c2e46077bbe1d9d75")
addappid(1258043, 1, "82b47401774cd0dceb2bd336e1ebbe5db93dc9f05278a7ba851731515b590672")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1278240)
addappid(1947550)
