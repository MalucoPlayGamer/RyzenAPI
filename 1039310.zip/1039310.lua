-- Lua provided by RyzenAPI
-- Game: REGOLA

-- MAIN APPLICATION
addappid(1039310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039311, 1, "a9f3246a92d0f98b2d9480cc087728c2a578c1069faa92f1a86aef1ae1f5faab")
