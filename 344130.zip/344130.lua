-- Lua provided by RyzenAPI
-- Game: Cataegis : The White Wind

-- MAIN APPLICATION
addappid(344130)

-- MAIN APP DEPOTS / PACKAGES
addappid(344131, 1, "0397a916c1807f983287b4a89eb9b71681d1570dda8b6fcf6dc77910e6eb6018")

