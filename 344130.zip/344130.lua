-- Lua provided by SkyAPI 
-- Game: Cataegis : The White Wind
addappid(344130)
addappid(344131, 1, "0397a916c1807f983287b4a89eb9b71681d1570dda8b6fcf6dc77910e6eb6018")
