-- Lua provided by RyzenAPI
-- Game: Game: Arrow a Row

-- MAIN APPLICATION
addappid(2495980)
-- Game: addappid(2495980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495981, 1, "4418f70751021eaabd247177ae3b3aa8b3d99594f5126bf68972c2dca395501e")
