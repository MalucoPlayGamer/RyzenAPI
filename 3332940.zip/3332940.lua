-- Lua provided by RyzenAPI
-- Game: Game: AppID 3332940

-- MAIN APPLICATION
addappid(3332940)
-- Game: addappid(3332940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332941, 1, "9cec85afbdaa38ee37ba753d9bf88aea37349e551f7982f30c85bea40ffc6fb0")
