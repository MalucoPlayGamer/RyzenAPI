-- Lua provided by RyzenAPI
-- Game: Lumberjacked

-- MAIN APPLICATION
addappid(3593780)
-- Game: addappid(3593780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593781, 1, "05c5a610e203b9738ba23706949f63b99f6686dcf289dc94fe265ccb2c630f69")
