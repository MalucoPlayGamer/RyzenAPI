-- Lua provided by RyzenAPI
-- Game: Game: Death Ski

-- MAIN APPLICATION
addappid(1483580)
-- Game: addappid(1483580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483581, 1, "8bf29917d2aa980234a023cf7471c66134bacf687359387f9fe9b1830ac06a0b")
