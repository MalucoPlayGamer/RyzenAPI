-- Lua provided by RyzenAPI
-- Game: Mary Skelter Finale

-- MAIN APPLICATION
addappid(2357400)
-- Game: addappid(2357400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357401, 1, "69add776d95d91e0cba5459327b642259840ca08bae4c1360d4b0f68b5b15f54")
addappid(2357402, 1, "60aafb8d9b18aa1464f9defffd35d97dd6e3310b0c0feaa8caa54b2939709f50")
addappid(2357403, 1, "33b58bde4eaa3c6ed90d704fc2f76998ac789968b18fd47b43b12795f0dd9ab3")
addappid(2357404, 1, "0d5946468c5368edbf8103ac5af6c32da2e6bc6a2ebd0de7666b334d5d2c9ba7")
addappid(2357406, 1, "5d62c6342e84912218f0107484af0bf38ba33dcfa40c56150d6167418c557349")
