-- Lua provided by SkyAPI 
-- Game: SEX with HITLER
addappid(1849000)
addappid(1849001, 1, "60f69dc6c86553a46cee8272fd7794764e8f6008077cc94056f5c4ea0498dd85")
