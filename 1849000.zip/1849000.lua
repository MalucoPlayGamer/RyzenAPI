-- Lua provided by RyzenAPI
-- Game: Game: SEX with HITLER

-- MAIN APPLICATION
addappid(1849000)
-- Game: addappid(1849000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849001, 1, "60f69dc6c86553a46cee8272fd7794764e8f6008077cc94056f5c4ea0498dd85")
