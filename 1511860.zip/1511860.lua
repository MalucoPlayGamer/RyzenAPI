-- Lua provided by RyzenAPI
-- Game: Swallow the Sea

-- MAIN APPLICATION
addappid(1511860)
-- Game: addappid(1511860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511861, 1, "70ed883373122b4a625a2fd350b40f2db082866642a6ad77a83abfad78446565")
addappid(1511863, 1, "b0a3868f0b9a065b07e82a0a14706f429427d58d01b3bc4b842ecce33e2c599a")
