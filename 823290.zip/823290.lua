-- Lua provided by RyzenAPI
-- Game: Game: Pokka Man

-- MAIN APPLICATION
addappid(823290)
-- Game: addappid(823290)

-- MAIN APP DEPOTS / PACKAGES
addappid(823291, 1, "05dbcb9e910367df56feae4a97c10a57dc14ef38a23423814939b5739e3f427e")
