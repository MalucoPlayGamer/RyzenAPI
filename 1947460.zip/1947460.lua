-- Lua provided by RyzenAPI
-- Game: Angel Perversion

-- MAIN APPLICATION
addappid(1947460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947461, 1, "7bd8048f94663f80f5653d887d6a3ef3e347ef86a457ecf5857696cbd0f276b4")
