-- Lua provided by RyzenAPI
-- Game: Game: Reilla ~Sweets Adventure~

-- MAIN APPLICATION
addappid(2103190)
-- Game: addappid(2103190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103191, 1, "d424ea93323f701b415f34c8da682f535efd21e22d7186643610409982b11054")
