-- Lua provided by RyzenAPI
-- Game: Reilla ~Sweets Adventure~

-- MAIN APPLICATION
addappid(2103190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103191, 1, "d424ea93323f701b415f34c8da682f535efd21e22d7186643610409982b11054")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
