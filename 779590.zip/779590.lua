-- Lua provided by RyzenAPI
-- Game: Scavenger SV-4

-- MAIN APPLICATION
addappid(779590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(779591, 1, "66485e029ecb68b9e3d1f453fa4bda53bbc446433a43442af9a062429191184f")

