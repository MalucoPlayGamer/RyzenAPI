-- Lua provided by RyzenAPI
-- Game: Scavenger SV-4

-- MAIN APPLICATION
addappid(779590)

-- MAIN APP DEPOTS / PACKAGES
addappid(779591, 1, "66485e029ecb68b9e3d1f453fa4bda53bbc446433a43442af9a062429191184f")
