-- Lua provided by RyzenAPI
-- Game: addappid(463250)

-- MAIN APPLICATION
addappid(463250)

-- MAIN APP DEPOTS / PACKAGES
addappid(463251, 1, "e369edf1bbb979ebe0b7ab3e91fe99bfbf3a8eb4d00184c6fc84921124206e97")
