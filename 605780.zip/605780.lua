-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport Antalya

-- MAIN APPLICATION
addappid(605780)

-- MAIN APP DEPOTS / PACKAGES
addappid(605780,0,"aaf950947e1d83eef3f9e1b65ff48fd796e459b2d5844164b023f101bc42f7e2")
