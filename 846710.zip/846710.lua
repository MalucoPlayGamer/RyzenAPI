-- Lua provided by RyzenAPI
-- Game: De'Vine: World of Shadows

-- MAIN APPLICATION
addappid(846710)

-- MAIN APP DEPOTS / PACKAGES
addappid(846711, 1, "2c1b43454092a764ad63db7c66aa4d005ffee3e880fed95d2c8252c7d20c2bcf")

