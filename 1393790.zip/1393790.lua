-- Lua provided by RyzenAPI
-- Game: 1393790

-- MAIN APPLICATION
addappid(1393790)
-- Game: addappid(1393790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393791, 1, "5a8a09600f41a03eb45fb86d7d29b10c3c603bc3a0653823c5dde9fd5b3da3d2")
addappid(1393792, 1, "a711bd988fcaf7ca9f156edee67d7a5a1acd69ac77099eda1d4f472eb56082d4")
