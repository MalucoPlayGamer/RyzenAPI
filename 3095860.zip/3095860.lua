-- Lua provided by RyzenAPI
-- Game: The Dragonhood (Original Soundtrack)

-- MAIN APPLICATION
addappid(3095860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095862,0,"3093ec875f699eec900c55b3bdcba098779dc045b9e1dd050a8449ccb1ecaa48")
addappid(3095863,0,"ba398646223fbeb0cf6805d6af9cf410705ce48585fa9e35eb25caa8712b5084")
