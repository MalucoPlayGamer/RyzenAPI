-- Lua provided by RyzenAPI
-- Game: WarriOrb: Prologue

-- MAIN APPLICATION
addappid(1193760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193761, 1, "5e1ce05957e003d6f1731bc8640e7d150e2665e43b49c42e04eb59c56783ae06")
addappid(1193762, 1, "daa201011f15a4233e5321e3bd9f4d9b8367cf7b4b9059f03033efc1ea67541a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
