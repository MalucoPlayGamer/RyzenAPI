-- Lua provided by RyzenAPI
-- Game: 3273270

-- MAIN APPLICATION
addappid(3273270)
-- Game: addappid(3273270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273271, 1, "48a01c3016a587cce05acd2c2fb0e37e4486b93383ed42ac47c60ced2394385b")
