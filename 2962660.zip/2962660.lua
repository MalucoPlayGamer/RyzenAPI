-- Lua provided by RyzenAPI
-- Game: 2962660

-- MAIN APPLICATION
addappid(2962660)
-- Game: addappid(2962660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962661, 1, "db195cbf62decf4acf109d56d2dc580a61811d8f67a3e6f5d0bd288ab6b6dc95")
