-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Country Cottage Tileset

-- MAIN APPLICATION
addappid(3011760)
-- Game: addappid(3011760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011760,0,"251483f07a42bfdab4cfa2c1292b2b67d8116ff100317eee29ab36b19b8fbf89")
