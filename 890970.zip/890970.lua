-- Lua provided by RyzenAPI
-- Game: Oakwood

-- MAIN APPLICATION
addappid(890970)

-- MAIN APP DEPOTS / PACKAGES
addappid(890971, 1, "0b49f4bdf9da2365e964e731f064f025b85264131c711f493f818cd4519953cc")

