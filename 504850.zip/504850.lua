-- Lua provided by RyzenAPI
-- Game: Castle Invasion: Throne Out

-- MAIN APPLICATION
addappid(504850)

-- MAIN APP DEPOTS / PACKAGES
addappid(504852,0,"2d1c9c005694e833eecd9322cb85ea812cf25f496ba0fa0389ccd650dad63f11")
addappid(504853,0,"2611182e058e9d480e0ae5ae6c15e61e88583a2fb776e8c2b9e86e2956cf7be2")

