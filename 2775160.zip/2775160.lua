-- Lua provided by RyzenAPI
-- Game: addappid(2775160)

-- MAIN APPLICATION
addappid(2775160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775161, 1, "af85e329f1ddc0af6d743166c3276ace0d4cbc20bfe83415e6d097984de6247c")
