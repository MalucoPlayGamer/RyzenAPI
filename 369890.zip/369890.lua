-- Lua provided by RyzenAPI
-- Game: Riddled Corpses

-- MAIN APPLICATION
addappid(369890)

-- MAIN APP DEPOTS / PACKAGES
addappid(369891, 1, "ffb72774eef2c811b1804290f35e844f6ca4d776a029f310a22bf6d822825494")
addappid(369892, 1, "e41ff52c050a7a7b70bf303f3652ea05f158d5107ddac461adace4fdc424f7b3")
addappid(369893, 1, "973f071aadc1455bdb7f61965f033de14284216aef6368fa1b18a7a52f4e25f9")
addappid(369894, 1, "86e5b0bbdc14950d4deaefec9ad8a9dece6abe1ac6135bef0de356fe57cce839")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
