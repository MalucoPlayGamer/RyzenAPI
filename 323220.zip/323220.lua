-- Lua provided by RyzenAPI
-- Game: Vagante

-- MAIN APPLICATION
addappid(323220)
addappid(812970)
-- Game: addappid(323220)

-- MAIN APP DEPOTS / PACKAGES
addappid(323221, 1, "c303363ce4304b4fd265e8328cdacbebed351f897d5c3bbb151047fc645e7429")
addappid(323222, 1, "43c4e5d40878ef43326b23a4f59c0fa49fe0107aa82726da4a38ea9e6d04a8e1")
addappid(323223, 1, "97983e621eedf74b7d410384106d6d77f82b2df16282d59e422831628b9063b1")
