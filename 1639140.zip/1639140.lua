-- Lua provided by RyzenAPI
-- Game: Mouse adventure

-- MAIN APPLICATION
addappid(1639140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639141, 1, "d71069e944cf6640a0e90d2232a687797ff4f7a998f8ac1c017dea06be6aaa85")
