-- Lua provided by RyzenAPI
-- Game: Idle Magic Legend

-- MAIN APPLICATION
addappid(2450480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450481, 1, "e0deacefc5f207153cb0071e72430a2ab79a115276932d1001a62f937d42a658")
