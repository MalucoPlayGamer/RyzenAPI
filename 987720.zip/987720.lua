-- Lua provided by RyzenAPI
-- Game: addappid(987720)

-- MAIN APPLICATION
addappid(987720)

-- MAIN APP DEPOTS / PACKAGES
addappid(987721, 1, "4a2a551822487d8787fe3ebc3b22c088b0fb9060b4ed9951464da454471d4e56")
