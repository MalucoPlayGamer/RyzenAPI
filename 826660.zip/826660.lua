-- Lua provided by RyzenAPI
-- Game: Rosette and Words

-- MAIN APPLICATION
addappid(826660)

-- MAIN APP DEPOTS / PACKAGES
addappid(826661,0,"70ba6639dc63f19153d47d6b2e2f0bd4cd1728b0e7156500d03e750515fe6145")

