-- Lua provided by RyzenAPI
-- Game: Piece of..Horror

-- MAIN APPLICATION
addappid(2456690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456691, 1, "d87b2dd6e97ffcdb24c2fcfbf344f0838d6d32d778a1e0387ba8d096cf28e7a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
