-- Lua provided by RyzenAPI
-- Game: Piece of..Horror

-- MAIN APPLICATION
addappid(2456690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456691, 1, "d87b2dd6e97ffcdb24c2fcfbf344f0838d6d32d778a1e0387ba8d096cf28e7a4")

