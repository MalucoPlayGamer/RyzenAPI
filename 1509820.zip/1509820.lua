-- Lua provided by RyzenAPI
-- Game: 1509820

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1509820)
addappid(1509821)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509822,0,"99f19391916c32fccc0b61468c312b1c84939ffbf3fa2c9638de99fe9a243533")

