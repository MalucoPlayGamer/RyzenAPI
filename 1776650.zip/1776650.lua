-- Lua provided by RyzenAPI
-- Game: FRAGROOM: Defenders

-- MAIN APPLICATION
addappid(1776650)
-- Game: addappid(1776650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776651, 1, "c6a31185afabd55baef68cba129a75af5a8d0932243102130d67bf5343f826d2")
