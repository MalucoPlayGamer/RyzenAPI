-- Lua provided by RyzenAPI
-- Game: For Her

-- MAIN APPLICATION
addappid(3356320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356321, 1, "b83babdf6cbbc7bf4cc263f6b591b3e358db204bfae7bc47a735ef85ca04dba2")

