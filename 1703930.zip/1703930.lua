-- Lua provided by RyzenAPI
-- Game: AppID 1703930

-- MAIN APPLICATION
addappid(1703930)
-- Game: addappid(1703930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703931, 1, "1492dac5558b9fcd3ed3ad720abf15c9d78b3a70dee5cdb0d7049b47b80a726c")
