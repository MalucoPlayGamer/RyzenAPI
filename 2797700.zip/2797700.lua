-- Lua provided by RyzenAPI
-- Game: Maraka Demo

-- MAIN APPLICATION
addappid(2797700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797701, 1, "409ace84e470cb52cf32bee24533c1bb0576e0ba4965e71ff0fa441ffa0bd3d5")
