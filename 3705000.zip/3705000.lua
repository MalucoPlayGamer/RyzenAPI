-- Lua provided by RyzenAPI 
-- Game: Strategic Bastion
addappid(3705000)
addappid(3705001, 1, "fbe5587f249e8fe7bcaa414cfa242e9855d97f14a6f850340ce42ee2fec81ba4")
