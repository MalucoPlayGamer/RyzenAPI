-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: House of Ashes

-- MAIN APPLICATION
addappid(1281590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281591, 1, "30227bc236f755706519e5ac1540f31eac52e838767d82935eb85cde675e6409")
addappid(1281594, 1, "28b51e4e5d74c2dba5007400963dfadea9ec1c90c0da35c6ebbe5399c769dff1")

