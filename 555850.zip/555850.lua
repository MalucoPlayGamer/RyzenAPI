-- Lua provided by RyzenAPI
-- Game: AppID 555850

-- MAIN APPLICATION
addappid(555850)

-- MAIN APP DEPOTS / PACKAGES
addappid(555851, 1, "8de15a66558b3afdf4712ab9be64d17d5b9e9599ced109be9489a45f7a66c44f")
addappid(555852, 1, "4c766f69ee6d3ac0804157210e4ca491856a68c2198c2896e28a923e42e7065c")
addappid(555853, 1, "62be66471b27aeabe5c2d4253b3674be71c89934ed090f070a5c2a4772863ce9")
addappid(555854, 1, "0197a2d3f07d31ac6ef0a39d01e0a04fddb1d8edc9aab2a56f97ddcc3e837a5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
