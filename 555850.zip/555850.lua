-- Lua provided by RyzenAPI
-- Game: Game: AppID 555850

-- MAIN APPLICATION
addappid(555850)
-- Game: addappid(555850)

-- MAIN APP DEPOTS / PACKAGES
addappid(555851, 1, "8de15a66558b3afdf4712ab9be64d17d5b9e9599ced109be9489a45f7a66c44f")
addappid(555852, 1, "4c766f69ee6d3ac0804157210e4ca491856a68c2198c2896e28a923e42e7065c")
addappid(555853, 1, "62be66471b27aeabe5c2d4253b3674be71c89934ed090f070a5c2a4772863ce9")
addappid(555854, 1, "0197a2d3f07d31ac6ef0a39d01e0a04fddb1d8edc9aab2a56f97ddcc3e837a5f")
