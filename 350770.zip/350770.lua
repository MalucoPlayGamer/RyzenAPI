-- Lua provided by RyzenAPI
-- Game: Giana Sisters 2D

-- MAIN APPLICATION
addappid(350770)

-- MAIN APP DEPOTS / PACKAGES
addappid(350771, 1, "0526e4d0783432a908066d057b98cb0ef7a4dc98429b6ae5e969fea399456097")

