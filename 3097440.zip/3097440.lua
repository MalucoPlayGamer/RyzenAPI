-- Lua provided by RyzenAPI
-- Game: Game: Town Rhapsody

-- MAIN APPLICATION
addappid(3097440)
-- Game: addappid(3097440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097441, 1, "09f353c82dd798ee12ebee35f928a6af04aac53a3c26e7698e0e97d9bf11f857")
