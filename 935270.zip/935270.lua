-- Lua provided by SkyAPI 
-- Game: Great Hero's Beard
addappid(935270)
addappid(935271, 1, "2678be650f845b832f9eacc93150c0ff313b6e8a369dead8a7a78a6f63c4671a")
addappid(988360, 0, "cb614936563e0ad983f4bc93466f6b94649086120983e39b7bb9c70d2fb564a5")
