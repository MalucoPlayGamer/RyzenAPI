-- Lua provided by SkyAPI 
-- Game: LEGENO SLAYER
addappid(2100210)
addappid(2100211, 1, "45d8d6a63a211c7fba00385e4acb8b47300c747cd525cf7bec8c89178f696d10")
