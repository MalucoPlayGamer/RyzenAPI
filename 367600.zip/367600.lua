-- Lua provided by RyzenAPI
-- Game: Game: Skyshine's BEDLAM

-- MAIN APPLICATION
addappid(367600)
-- Game: addappid(367600)

-- MAIN APP DEPOTS / PACKAGES
addappid(367601, 1, "52093e670f735383f84e974f5fceb9bd1f32483780f9044d3115b0764c0954c2")
addappid(367602, 1, "ed929e2834cbf6f30c601bc1a3651f5bb34e973842c7f36288e88d027d637dd0")
addappid(367603, 1, "b69b8fe33bc28806596743efaa211e94cd26a8ac863ae7ad5a7540afee49dc54")
