-- 3833230's Lua and Manifest Created by Hubcap Manifest
-- The Comeback King
-- Created: August 12, 2026 at 00:04:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3833230, 1, "7f256cb418aef0b1f3cc586d6ccccd83b1730daa6e5e44fc53e6ba149fbcc43c") -- The Comeback King
-- MAIN APP DEPOTS
addappid(3833232, 1, "3bd65d43a6be1c4be33dde7c6f8846c67b07796c1f755564498a83b25c2d0449") -- Depot 3833232
setManifestid(3833232, "2098306385344375300", 368894346)
addappid(3833231, 1, "dffe951fde217893e535d42d822c4464ae36a0a54bb453bb03d2f0c721ca1ebe") -- Depot 3833231
setManifestid(3833231, "4550236855395496563", 76535803)