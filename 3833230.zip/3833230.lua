-- Lua provided by RyzenAPI
-- Game: The Comeback King

-- MAIN APP DEPOTS / PACKAGES
addappid(3833230, 1, "7f256cb418aef0b1f3cc586d6ccccd83b1730daa6e5e44fc53e6ba149fbcc43c") -- The Comeback King
addappid(3833231, 1, "dffe951fde217893e535d42d822c4464ae36a0a54bb453bb03d2f0c721ca1ebe") -- Depot 3833231
addappid(3833232, 1, "3bd65d43a6be1c4be33dde7c6f8846c67b07796c1f755564498a83b25c2d0449") -- Depot 3833232

