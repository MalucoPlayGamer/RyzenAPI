-- Lua provided by RyzenAPI 
-- Game: AppID 412170
addappid(412170)
addappid(412171, 1, "c1c4abb28627286a3837e9e88d65fb88b13b1ef1b5195e91aa4c0bcb9d531052")
