-- Lua provided by RyzenAPI
-- Game: Game: Ne Touchez Pas 5

-- MAIN APPLICATION
addappid(1029840)
-- Game: addappid(1029840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029841, 1, "46f3e8015b6091e35e111c02f81625267636d86c671a5b26a1ee6f6626bde6b3")
