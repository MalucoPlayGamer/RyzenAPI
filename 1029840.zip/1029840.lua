-- Lua provided by RyzenAPI 
-- Game: Ne Touchez Pas 5
addappid(1029840)
addappid(1029841, 1, "46f3e8015b6091e35e111c02f81625267636d86c671a5b26a1ee6f6626bde6b3")
