-- Lua provided by RyzenAPI
-- Game: Paper Shakespeare: Very Naked Hamlet

-- MAIN APPLICATION
addappid(1312380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1312381, 1, "580dd0da35a4a61dcea99de78a6002ce6129df758d903b1ea27aa5c2b38d1813")

