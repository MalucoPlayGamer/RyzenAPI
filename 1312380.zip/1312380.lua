-- Lua provided by RyzenAPI
-- Game: Paper Shakespeare: Very Naked Hamlet

-- MAIN APPLICATION
addappid(1312380)
-- Game: addappid(1312380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312381, 1, "580dd0da35a4a61dcea99de78a6002ce6129df758d903b1ea27aa5c2b38d1813")
