-- Lua provided by RyzenAPI
-- Game: Smoots World Cup Tennis

-- MAIN APPLICATION
addappid(393860)

-- MAIN APP DEPOTS / PACKAGES
addappid(393862,0,"fe35ee14249e5a1b9e59abc953eb80b7be86e65b5e3da31aae1f32b7ea9cbb71")

