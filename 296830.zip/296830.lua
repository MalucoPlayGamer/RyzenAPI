-- Lua provided by RyzenAPI
-- Game: Lucius II

-- MAIN APPLICATION
addappid(296830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(296831, 1, "8d6e19a7ddee087cc9ecc030b4e54be0c65f87d9d0f833a472f5579be9b962f6")
addappid(296832, 1, "a604868a76f3de549fe84b620e024969acbef9d6b815b2734c7e64b6c01e1bb5")

