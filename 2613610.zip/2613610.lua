-- Lua provided by RyzenAPI
-- Game: Drift.Wav

-- MAIN APPLICATION
addappid(2613610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613611, 1, "682b3f0e2ebef98f636e57f38ad6c663fd24348524c1efdb9588cd5ca5c66aa7")
