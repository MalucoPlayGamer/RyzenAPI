-- Lua provided by RyzenAPI
-- Game: Fantasy Fairways

-- MAIN APPLICATION
addappid(552690)

-- MAIN APP DEPOTS / PACKAGES
addappid(552691,0,"e7b4ce02115037b64dac7f40a8bba3998d3a23f125a3f275a1dc0d896aa8923b")
addappid(552693,0,"02e4700fa82815b13178d256a23348a1af86d0ebc62963c956b8d293521d7d6a")

