-- Lua provided by RyzenAPI
-- Game: IRFaceRig

-- MAIN APPLICATION
addappid(377590)
addappid(435170)
addappid(435171)
addappid(435172)
addappid(435173)
addappid(435174)
addappid(435175)
addappid(435176)
addappid(435177)
-- Game: addappid(377590)

-- MAIN APP DEPOTS / PACKAGES
addappid(377591, 1, "5f57926d23d4b3f18d3e695b3a49be3b32513652a629f7fe6b7af20fcd93c36d")
