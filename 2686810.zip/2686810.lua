-- Lua provided by RyzenAPI 
-- Game: Dimlight Dungeon
addappid(2686810)
addappid(2686811, 1, "aebd178b893e741f675dc30ba757a825e5aa6e03df3d21a8b5524cfab3648df5")
