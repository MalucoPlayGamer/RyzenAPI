-- Lua provided by RyzenAPI
-- Game: Dimlight Dungeon

-- MAIN APPLICATION
addappid(2686810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2686811, 1, "aebd178b893e741f675dc30ba757a825e5aa6e03df3d21a8b5524cfab3648df5")

