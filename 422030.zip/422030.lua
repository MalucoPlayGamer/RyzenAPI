-- Lua provided by RyzenAPI
-- Game: ReVeN: XBridge

-- MAIN APPLICATION
addappid(422030)
-- Game: addappid(422030)

-- MAIN APP DEPOTS / PACKAGES
addappid(422031, 1, "057c46afc76fe45f13650f8b49b042b7b0805800b134a32b60fee50bc9e32431")
addappid(425100, 0, "0d2d9004f3e46bc0797873ead5085e2f0c5616d10b33073548403cbee56b47a2")
