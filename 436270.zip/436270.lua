-- Lua provided by RyzenAPI
-- Game: Civil War: 1863

-- MAIN APPLICATION
addappid(436270)

-- MAIN APP DEPOTS / PACKAGES
addappid(436272,0,"2bc8ffcc2ed5979444d7380a364a1eeca6cb1b83627db92184bcfa8015103e6f")
addappid(436273,0,"c9a466b7368a12f0a1f012cb8b1da6c96f5d9d39e0d86e247a2347bc198f0f9f")
