-- Lua provided by RyzenAPI
-- Game: Spectrolite Soundtrack

-- MAIN APPLICATION
addappid(1824300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824301, 1, "c25561b19f2834087b860160eec61c50caf94912e2d4b970f55c5dec09d21277")
addappid(1824302, 1, "893465eaed162593c2c6f69e7cad58ce16f553b4147cecd117f88a1b5775c556")

