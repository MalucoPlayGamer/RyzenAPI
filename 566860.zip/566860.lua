-- Lua provided by RyzenAPI
-- Game: VR Dungeon Knight

-- MAIN APPLICATION
addappid(566860)

-- MAIN APP DEPOTS / PACKAGES
addappid(566861, 1, "58e116011e5da40c281ad7d295be7315f36d451474955b6b554a8513d2db5bf5")
