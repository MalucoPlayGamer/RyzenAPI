-- Lua provided by RyzenAPI
-- Game: Scratches - Director's Cut

-- MAIN APPLICATION
addappid(46460)
-- Game: addappid(46460)

-- MAIN APP DEPOTS / PACKAGES
addappid(46461, 1, "7c3a48396e874a35f70930136e13c38404ab1f10f1b07ea06904fd66b4209dcd")
