-- Lua provided by RyzenAPI
-- Game: Melody's Escape 2

-- MAIN APPLICATION
addappid(1829470)
-- Game: addappid(1829470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829471, 1, "cbe0304b1e6ca94bb5f7cf307ff07dd8c6caf76a7853b6e92ef78a5d0f1d9f3d")
