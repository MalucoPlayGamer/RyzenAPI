-- Lua provided by RyzenAPI
-- Game: Game: Love is All Around: Echoes of Yesterday Demo

-- MAIN APPLICATION
addappid(3100360)
-- Game: addappid(3100360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100361, 1, "fa4a1aac59c94142d76824ab0a8d5f943e6d8efb4adda1fb461d4fb1cd4186c4")
