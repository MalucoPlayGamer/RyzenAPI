-- Lua provided by SkyAPI 
-- Game: AFL 23
addappid(2337630)
addappid(2337631, 1, "ce68691fe0e376dbe23ebd7e30816aae061d9063b3101a45c7654d4f877a7bc4")
