-- Lua provided by RyzenAPI
-- Game: AppID 1503410

-- MAIN APPLICATION
addappid(1503410)
addappid(1507300)
addappid(1510640)
addappid(1515690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503411, 1, "46e97d44cab29d583bcd5a9cbf4876beaac69c49b641cb986e78fc36d8eef6f3")

