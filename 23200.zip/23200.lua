-- Lua provided by RyzenAPI
-- Game: AppID 23200

-- MAIN APPLICATION
addappid(23200)

-- MAIN APP DEPOTS / PACKAGES
addappid(23201, 1, "ec11e37f23555cf337bb1dd083e6c17e4df9a2f6078f66dc811099a80ff6641c")

