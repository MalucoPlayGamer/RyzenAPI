-- Lua provided by RyzenAPI
-- Game: addappid(2835590)

-- MAIN APPLICATION
addappid(2835590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835591, 1, "2ffb82f62cc851accc98fcf3fc0e60c0304099e14d3ff50ae18575ac22c50372")
