-- Lua provided by RyzenAPI
-- Game: 8AM

-- MAIN APPLICATION
addappid(2835590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2835591, 1, "2ffb82f62cc851accc98fcf3fc0e60c0304099e14d3ff50ae18575ac22c50372")

