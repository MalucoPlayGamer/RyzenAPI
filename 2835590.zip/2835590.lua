-- Lua provided by RyzenAPI 
-- Game: 8AM
addappid(2835590)
addappid(2835591, 1, "2ffb82f62cc851accc98fcf3fc0e60c0304099e14d3ff50ae18575ac22c50372")
