-- Lua provided by RyzenAPI
-- Game: addappid(748040)

-- MAIN APPLICATION
addappid(748040)

-- MAIN APP DEPOTS / PACKAGES
addappid(748041, 1, "4c79312f27b6b20cd3d3dadf731343cf7c52bd4ea432cc1a5ada20bcdb026f29")
