-- Lua provided by RyzenAPI
-- Game: State of War : Warmonger / 蓝色警戒 (Classic 2000)

-- MAIN APPLICATION
addappid(748040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(748041, 1, "4c79312f27b6b20cd3d3dadf731343cf7c52bd4ea432cc1a5ada20bcdb026f29")

