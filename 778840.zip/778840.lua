-- Lua provided by RyzenAPI
-- Game: Armored Evolution

-- MAIN APPLICATION
addappid(778840)

-- MAIN APP DEPOTS / PACKAGES
addappid(778841, 1, "4e5b954e2b691a6c8ae20be4730b3d2c20ba0457fbe6df75378b2e4394030579")
addappid(778842, 1, "dcbfb5c10797fb53241b024b343e028948770258af31d7467e9c571da13a9f38")

