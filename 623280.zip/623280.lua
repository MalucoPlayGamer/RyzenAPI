-- Lua provided by RyzenAPI
-- Game: Dungeons & Dragons: Dark Alliance

-- MAIN APPLICATION
addappid(623280)
addappid(1670840)
addappid(1670841)
addappid(1670842)
addappid(1670843)

-- MAIN APP DEPOTS / PACKAGES
addappid(623281,0,"a870c5700b3c111ce12dfe597bb1553f49555ae1c5f36ece0239178b01a80341")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
