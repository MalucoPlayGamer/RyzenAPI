-- Lua provided by RyzenAPI
-- Game: Dungeons & Dragons: Dark Alliance

-- MAIN APPLICATION
addappid(623280)
addappid(1670840)
addappid(1670841)
addappid(1670842)
addappid(1670843)

-- MAIN APP DEPOTS / PACKAGES
addappid(623281,0,"a870c5700b3c111ce12dfe597bb1553f49555ae1c5f36ece0239178b01a80341")

