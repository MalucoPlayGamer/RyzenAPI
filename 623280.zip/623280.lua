-- Lua provided by RyzenAPI
-- Game: AppID 623280

-- MAIN APPLICATION
addappid(623280)
-- Game: addappid(623280)

-- MAIN APP DEPOTS / PACKAGES
addappid(623281, 1, "a870c5700b3c111ce12dfe597bb1553f49555ae1c5f36ece0239178b01a80341")
