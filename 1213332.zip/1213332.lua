-- Lua provided by RyzenAPI
-- Game: DFF NT: Blade of Ruin, Ardyn Izunia's 4th Weapon

-- MAIN APPLICATION
addappid(1213332)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213332,0,"fa85b195570d49f6f1dd8707ba7ffcce3ecadcfc90cfcde7681f7ed90ac73a33")

