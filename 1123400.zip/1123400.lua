-- Lua provided by RyzenAPI
-- Game: The Land of Exile

-- MAIN APPLICATION
addappid(228985)
addappid(228986)
addappid(228990)
addappid(1123400)
-- Game: addappid(1123400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123402,0,"adfe7d0193986fa7b8c92e152f62e5413596a7f69766462d9e302b97b021ebf9")
