-- Lua provided by RyzenAPI
-- Game: 1179210

-- MAIN APPLICATION
addappid(1179210)
-- Game: addappid(1179210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179211, 1, "c6ef30beeea1da53720b5c4920b9c7d3c83112860d53632079e274fcbc0c7745")
