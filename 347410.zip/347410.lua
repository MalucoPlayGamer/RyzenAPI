-- Lua provided by RyzenAPI
-- Game: Jerry McPartlin - Rebel with a Cause

-- MAIN APPLICATION
addappid(347410)

-- MAIN APP DEPOTS / PACKAGES
addappid(347411, 1, "f16d9bcb0657e6a3e47815b107bed5a8460a1d9d62e2a1cbee3e2917f6a8f205")
addappid(347412, 1, "b4140a441350e377621d1107d553a0d01b49aabbf47a75982f063ada90512be0")
addappid(347414, 1, "24ed007f45cddf34150ea234c0b37f69e3947d3e0b161769fc945a493998af7a")
