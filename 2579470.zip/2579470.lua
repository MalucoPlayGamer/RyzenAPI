-- Lua provided by RyzenAPI
-- Game: Futanari girlfriends ⚧👧🍆

-- MAIN APPLICATION
addappid(2579470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579471, 1, "c1ebde62c8426536108bc09fcd954d334070caedddd0389d771df07e926c0864")
