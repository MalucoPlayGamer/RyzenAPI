-- Lua provided by RyzenAPI
-- Game: 2102490

-- MAIN APPLICATION
addappid(2102490)
-- Game: addappid(2102490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102491, 1, "72b7ed89ef6afa5ba8ff73661f89b1a861c4593b680adc5afde635003ef11068")
