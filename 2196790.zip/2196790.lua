-- Lua provided by RyzenAPI
-- Game: Jianghu Survivor

-- MAIN APPLICATION
addappid(2196790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196791, 1, "2ac7d6f5dbc1ea3ecece8a393854ed8e437732065dedf54a503cf87794531dd4")

