-- Lua provided by RyzenAPI
-- Game: 1917720

-- MAIN APPLICATION
addappid(1917720)
-- Game: addappid(1917720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917721, 1, "1210ca7aefc2ae85451d2252b3a7ec0883e031e5288df487ca147cca56433887")
