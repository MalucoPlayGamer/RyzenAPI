-- Lua provided by RyzenAPI
-- Game: Hell Miner

-- MAIN APPLICATION
addappid(2219990)
-- Game: addappid(2219990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219991, 1, "31274233e40d19814dc6744e2dd8340a8128bc04c6b813f1ec1ed855824f942b")
