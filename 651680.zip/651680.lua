-- Lua provided by RyzenAPI
-- Game: Game: Shalnor Legends: Sacred Lands

-- MAIN APPLICATION
addappid(651680)
-- Game: addappid(651680)

-- MAIN APP DEPOTS / PACKAGES
addappid(651681, 1, "e7f0566b8ff36666a1a99a9aa89cebc756543e6c9991ebe0175ef966c60dfac7")
addappid(651930, 0, "dc4bb3fae2bb0ad09d69a5a33ba7aea6a863c6f5121c9a7a12e2fb4480f2491c")
