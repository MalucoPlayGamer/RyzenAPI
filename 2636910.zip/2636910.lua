-- Lua provided by RyzenAPI
-- Game: Game: Moonbase Lambda

-- MAIN APPLICATION
addappid(2636910)
-- Game: addappid(2636910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636911, 1, "bcb44d2523527b414b40ae901fa78bcca389fcf925c4d6de0ca9bda9cb58bba1")
