-- Lua provided by RyzenAPI
-- Game: CHANGE: A Homeless Survival Experience

-- MAIN APPLICATION
addappid(926140)
addappid(1845520)

-- MAIN APP DEPOTS / PACKAGES
addappid(926141,0,"77470138e52af8fb87708e9084498ce59dea9ead06e835f0fde64faf88b7a059")
addappid(926142,0,"42cac4fff425db7bc94a96ddf9bad9158792975a2c51113ad5d10ac042ce8b63")
addappid(926143,0,"71766b560fab8c4af6bd8dc1855aa386a8ba62a30a94bbbbc5482e56cfcd9069")

