-- Lua provided by RyzenAPI
-- Game: DFF NT: Ramza Beoulve Starter Pack

-- MAIN APPLICATION
addappid(1022471)
-- Game: addappid(1022471)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022471,0,"fdf956417f8356ad2e2021a329c251f73264c37bfbe8ad5f25b24dfd3c0b0cfb")
