-- Lua provided by RyzenAPI
-- Game: addappid(2463490)

-- MAIN APPLICATION
addappid(2463490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463491, 1, "1b5d8d95cd360853c4839e2849e435ce94981f8cc0c89f7a7b4af6a9ec6d0741")
