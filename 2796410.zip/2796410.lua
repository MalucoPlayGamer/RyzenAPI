-- Lua provided by RyzenAPI 
-- Game: Sugar Tanks 2
addappid(2796410)
addappid(2796411, 1, "76f027d4839e19836f51ec882a37207cfeb6c4f803227af23d5b3c8362d29890")
