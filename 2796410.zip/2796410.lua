-- Lua provided by RyzenAPI
-- Game: Game: Sugar Tanks 2

-- MAIN APPLICATION
addappid(2796410)
-- Game: addappid(2796410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796411, 1, "76f027d4839e19836f51ec882a37207cfeb6c4f803227af23d5b3c8362d29890")
