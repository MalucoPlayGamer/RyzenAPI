-- Lua provided by RyzenAPI
-- Game: Game: Eron

-- MAIN APPLICATION
addappid(356880)
-- Game: addappid(356880)

-- MAIN APP DEPOTS / PACKAGES
addappid(356881, 1, "b270e41dd00990c3dac5e27630bbe46d26a1f09971c94554c1064443141500e8")
