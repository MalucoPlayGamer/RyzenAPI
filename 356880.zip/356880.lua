-- Lua provided by RyzenAPI 
-- Game: Eron
addappid(356880)
addappid(356881, 1, "b270e41dd00990c3dac5e27630bbe46d26a1f09971c94554c1064443141500e8")
