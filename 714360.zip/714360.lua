-- Lua provided by RyzenAPI
-- Game: 714360

-- MAIN APPLICATION
addappid(714360)
-- Game: addappid(714360)

-- MAIN APP DEPOTS / PACKAGES
addappid(714361, 1, "9aa83daad296122eb567c1737eec38e84556348aeb7abaa7e83ad2d13649fcd6")
