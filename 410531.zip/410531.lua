-- Lua provided by RyzenAPI
-- Game: AppGameKit Classic - Giant Asset Pack 2

-- MAIN APPLICATION
addappid(410531)

-- MAIN APP DEPOTS / PACKAGES
addappid(804250,0,"31a18eb5e1ecb6e51fab157d0d7313c759b89209a5a0820969cba774337e30a8")
