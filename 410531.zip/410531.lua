-- Lua provided by RyzenAPI
-- Game: 410531

-- MAIN APPLICATION
addappid(410531)
-- Game: addappid(410531)

-- MAIN APP DEPOTS / PACKAGES
addappid(804250,0,"31a18eb5e1ecb6e51fab157d0d7313c759b89209a5a0820969cba774337e30a8")
