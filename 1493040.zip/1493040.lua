-- Lua provided by RyzenAPI
-- Game: Seed Hunter 猎源 Soundtrack

-- MAIN APPLICATION
addappid(1493040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493041, 1, "81c3cd94329b35772db8ef8d00fcac63451057c70b69ebf3aecb160c93283921")
addappid(1493042, 1, "4f49f2cfef7c97939e474defc55d0d4e213cd52dee8ec5bf113b891af19c1820")
