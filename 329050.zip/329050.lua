-- Lua provided by RyzenAPI
-- Game: Devil May Cry 4 Special Edition

-- MAIN APPLICATION
addappid(329050)
addappid(359490)
addappid(359491)
addappid(359492)
addappid(359493)
addappid(359494)
addappid(359495)
addappid(359497)

-- MAIN APP DEPOTS / PACKAGES
addappid(329051, 1, "4da524a16eb2bb8577d094a37394176b10de35a42d6bcdecdd5c5115a324f2f3")
addappid(329052, 1, "8c64bb7a4690a8c03abdbdd37d6b8f2facd53e84b65bee01f5fc4ba7cbf820c4")
addappid(329059, 1, "b337f8a7dab3433f577c958de8297930a64e9d4e26afcb89decc17d68842720a")
addappid(329063, 1, "0fa835c37520b9ba38589e7501bcc412d60c892c4e4545dab524cdd986092179")
addappid(329064, 1, "fc5e4126a6feb60b108669709281b0f8c7421f717cfbe6c38e2fe20a2c33bee6")
addappid(359496, 0, "5eeebd35182e7d89c2849a263992ec597c582ae9ca3b387426064c8981aa8d0f")
addappid(359496, 1, "5eeebd35182e7d89c2849a263992ec597c582ae9ca3b387426064c8981aa8d0f")

