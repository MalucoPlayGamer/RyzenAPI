-- Lua provided by RyzenAPI
-- Game: Magic Weapon

-- MAIN APPLICATION
addappid(3770710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3770711, 1, "3ec861661a2b50f86a504ab59d85f760e069a1380ce461df9472bad8b50e62c3")

