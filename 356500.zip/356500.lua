-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Galactic Battlegrounds Saga

-- MAIN APPLICATION
addappid(356500)

-- MAIN APP DEPOTS / PACKAGES
addappid(356501, 1, "d5bad194e3d0f9950fbb362233a2f6cc5ce1ee79e06357a82a14c630f2b9c2b3")
addappid(356502, 1, "8cc059f0bc4b53f0a622f25fa2a4b11c52792d56bc1324078c9748102ed8ae3e")
addappid(356503, 1, "c982d09cf34b18400a2a1bb8222ff1c670505f3a0983a780c40de384840d5c9e")
addappid(356504, 1, "ab861a2cb9460b7d49085558b92b5dfeb56f719dcd7744be6a4db73bd97327bc")
addappid(356505, 1, "6ff63f53359ca6f36607ff4b1171c1391937fb7bde087d3616827566d9535caf")
addappid(356506, 1, "2e3fbe935e41e83c81618afb5a962b1d70a108276dbcecaa3a6c6ecefa2e55cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
