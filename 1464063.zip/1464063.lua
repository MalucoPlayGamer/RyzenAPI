-- Lua provided by RyzenAPI
-- Game: ​Our Life: Beginnings & Always - Voiced Name Expansion

-- MAIN APPLICATION
addappid(1464063)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464063,0,"972b91307bfab3540c0a5aeee8350283babe1564ba0976a08b9991607c2872bf")

