-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport Maastricht-Aachen

-- MAIN APPLICATION
addappid(614001)

-- MAIN APP DEPOTS / PACKAGES
addappid(615840,0,"452cb69cafe20009288b808b6d78275c61421d41342a1657595ecd210f38858e")
