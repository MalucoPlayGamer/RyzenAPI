-- Lua provided by RyzenAPI
-- Game: Game: AppID 1438110

-- MAIN APPLICATION
addappid(1438110)
-- Game: addappid(1438110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438111, 1, "1d27327282e1984641229bd1df1a7ef0b983bd1d664ba32df87910b97ee69bae")
