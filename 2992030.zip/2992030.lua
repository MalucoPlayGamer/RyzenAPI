-- Lua provided by RyzenAPI
-- Game: Extermination Shock Demo

-- MAIN APPLICATION
addappid(2992030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2992031, 1, "aebad2e21a3b301131ea8b327a41dced260ffc721b2dcbd83f776c916316f2e5")

