-- Lua provided by RyzenAPI
-- Game: addappid(1143852)

-- MAIN APPLICATION
addappid(1143852)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143852,0,"17a1ea3d734965e52de14e0340b18cdf6aef3b9c3edffea6e116a504be3faffc")
