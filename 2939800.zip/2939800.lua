-- Lua provided by RyzenAPI
-- Game: addappid(2939800)

-- MAIN APPLICATION
addappid(2939800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2939801, 1, "1b632b94a46a5aa9d4a6c76497b8c5f7db72e8b1086cfde86f217828aa0d59d9")
