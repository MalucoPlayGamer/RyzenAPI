-- Lua provided by RyzenAPI
-- Game: addappid(340820)

-- MAIN APPLICATION
addappid(340820)

-- MAIN APP DEPOTS / PACKAGES
addappid(340825,0,"638e07aaf1e0087cfc3db1e44564a24d02f63b74cd50014492bb6cd8b3635165")
