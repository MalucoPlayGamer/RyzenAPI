-- Lua provided by RyzenAPI
-- Game: addappid(1523990)

-- MAIN APPLICATION
addappid(1523990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523991, 1, "7f2b220509a030b753ac2eaa2afd6e7f0c49b33f68a727a1d69a31878322f093")
