-- Lua provided by RyzenAPI
-- Game: Zombikini PinballZ

-- MAIN APPLICATION
addappid(2469240)
-- Game: addappid(2469240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469241, 1, "5eb7e13a1f2d131702804a84eea8949efa3e3ce04781a591731eb67f48d6d6e2")
