-- Lua provided by RyzenAPI
-- Game: Requiem Of Science

-- MAIN APPLICATION
addappid(1828210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828211, 1, "94d96db9d748ad77bd17643ba001373c99475583d936204c3c0d83d99bc0ffa4")
addappid(1828212, 1, "373e8e5b3de04fbf92a7c40ec1f8b9c393f2c2a92ed0e9c8f9a9b4ef7cd831c3")
addappid(1828213, 1, "13d7a73ab1ed4c3eec0582dbebfed2a162ebe63d472fe75f1ecff890c183fdfc")

