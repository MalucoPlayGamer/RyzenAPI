-- Lua provided by RyzenAPI
-- Game: Game: Truberbrook / Trüberbrook

-- MAIN APPLICATION
addappid(757300)
-- Game: addappid(757300)

-- MAIN APP DEPOTS / PACKAGES
addappid(757301, 1, "5491c0cd98003bdf7138d63eaf1a72c1d31e27dbdc6658a019fa5a3cfe5b45b4")
addappid(757302, 1, "b41b02334a0e8f2358e99cba291247600ed85538c1685ec36ee0547f3c2bb6a5")
addappid(757303, 1, "7a527c53dca7cd5cdd73e8197fc55d1fa94208e583e3b3bf5f4fcb696f11da8e")
addappid(1049050, 0, "72209a33375b7120672b2de8a304f695689110b2be2a6dc94acba5cbc493e8ba")
