-- Lua provided by RyzenAPI
-- Game: 2306020

-- MAIN APPLICATION
addappid(2306020)
-- Game: addappid(2306020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2306021, 1, "290eecf97f0249189ba839146013f6a1ec12de97cab439cad6f70a0b755e1455")
