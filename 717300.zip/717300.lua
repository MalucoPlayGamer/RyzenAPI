-- Lua provided by RyzenAPI
-- Game: 717300

-- MAIN APPLICATION
addappid(717300)
-- Game: addappid(717300)

-- MAIN APP DEPOTS / PACKAGES
addappid(717302,0,"9832c9d4cddd40d9ff8bfacf75624704dc87f6003b372e97039f6f2fe99b28c6")
