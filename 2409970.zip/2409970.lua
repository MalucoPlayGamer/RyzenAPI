-- Lua provided by RyzenAPI
-- Game: addappid(2409970)

-- MAIN APPLICATION
addappid(2409970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409971, 1, "e9c4417bae20070b4cbacd8f9c203fd9a30f5d149a561a65672b891358cf30c0")
