-- Lua provided by RyzenAPI
-- Game: addappid(3007750)

-- MAIN APPLICATION
addappid(3007750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007750,0,"745389b76e6844e0b4ffc4f4fcaa6854ee067a5c644e970b6a2c0123ea8bc21f")
