-- Lua provided by RyzenAPI
-- Game: 茶言茶语

-- MAIN APPLICATION
addappid(2932140)
-- Game: addappid(2932140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932141, 1, "32ac7e955df889ad13d1d1b3a15a1c15cdff51e121a6d18f794f3c9eaf26283d")
