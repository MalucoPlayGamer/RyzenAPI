-- Lua provided by RyzenAPI
-- Game: QUICKERFLAK_RUTHLESSMOD

-- MAIN APPLICATION
addappid(2010110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010111, 1, "3ae92b2487e190eea2272504b345b5bf27dd3407cfb26747f4d8a8b1cd3fcd48")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
