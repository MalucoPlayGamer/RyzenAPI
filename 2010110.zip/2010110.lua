-- Lua provided by RyzenAPI
-- Game: 2010110

-- MAIN APPLICATION
addappid(2010110)
-- Game: addappid(2010110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010111, 1, "3ae92b2487e190eea2272504b345b5bf27dd3407cfb26747f4d8a8b1cd3fcd48")
