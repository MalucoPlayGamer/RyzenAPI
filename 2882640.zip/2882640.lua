-- Lua provided by RyzenAPI
-- Game: Game: The Dilemma

-- MAIN APPLICATION
addappid(2882640)
-- Game: addappid(2882640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882641, 1, "be5f0c805ac83ddc95a70ecb88a7ceb715d30cff7ab2fae9c2836316b51ff0e6")
