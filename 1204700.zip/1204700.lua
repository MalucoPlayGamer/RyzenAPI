-- Lua provided by SkyAPI 
-- Game: Pangea Survival
addappid(1204700)
addappid(1204701, 1, "39d7f9da57f40f3577ef249b56eed3002cca9796e65b4098f978deaa59566527")
