-- Lua provided by RyzenAPI
-- Game: Pangea Survival

-- MAIN APPLICATION
addappid(1204700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204701, 1, "39d7f9da57f40f3577ef249b56eed3002cca9796e65b4098f978deaa59566527")

