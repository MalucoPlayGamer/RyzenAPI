-- Lua provided by RyzenAPI
-- Game: Clock Tower: Rewind

-- MAIN APPLICATION
addappid(2794770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794771, 1, "f48d6d7cab6eb22681b4eaa06dd1b162119afaef0f637b2e58b12862dc33fa70")
