-- Lua provided by SkyAPI 
-- Game: AppID 3246740
addappid(3246740)
addappid(3246741, 1, "473d6c16c9c0f4042f6b73aeb6c4db199ea319257cecf7853ded2831b429b8d1")
