-- Lua provided by RyzenAPI
-- Game: Game: Escape from Naraka

-- MAIN APPLICATION
addappid(1390670)
-- Game: addappid(1390670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390671, 1, "c69ac4513bd4d43da9a5c01670cd58ce5bd8974a577253e3431d29abc12adc6d")
