-- Lua provided by RyzenAPI
-- Game: Escape from Naraka

-- MAIN APPLICATION
addappid(1390670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390671, 1, "c69ac4513bd4d43da9a5c01670cd58ce5bd8974a577253e3431d29abc12adc6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
