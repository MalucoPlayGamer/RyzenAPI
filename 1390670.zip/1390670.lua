-- Lua provided by RyzenAPI 
-- Game: Escape from Naraka
addappid(1390670)
addappid(1390671, 1, "c69ac4513bd4d43da9a5c01670cd58ce5bd8974a577253e3431d29abc12adc6d")
