-- Lua provided by RyzenAPI 
-- Game: 僕と彼の危険な同居生活
addappid(664130)
addappid(664131, 1, "eb1556a4093ea0ec4a94cf7a23d99622d47d2f8d11d7840d70a1d0b0a92e581b")
