-- Lua provided by RyzenAPI
-- Game: addappid(664130)

-- MAIN APPLICATION
addappid(664130)

-- MAIN APP DEPOTS / PACKAGES
addappid(664131, 1, "eb1556a4093ea0ec4a94cf7a23d99622d47d2f8d11d7840d70a1d0b0a92e581b")
