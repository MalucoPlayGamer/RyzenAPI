-- Lua provided by RyzenAPI
-- Game: Game: LurkBait Twitch Fishing

-- MAIN APPLICATION
addappid(2767520)
-- Game: addappid(2767520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767521, 1, "25b89f570154680e82f3497125d1a02335b21e604601c505f0c20b86ce7af980")
