-- Lua provided by RyzenAPI
-- Game: 1495170

-- MAIN APPLICATION
addappid(1495170)
-- Game: addappid(1495170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495171, 1, "0fed99ace16a44b0a07a4d46bdc60b636fea07f6a489590c98017263ed322e6e")
