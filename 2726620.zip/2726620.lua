-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Ultra Building Pack

-- MAIN APPLICATION
addappid(2726620)
-- Game: addappid(2726620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726620,0,"9de8096e700bef31c447380f70ab03492b4de08d9a6c9d0e9fdb39b9ff035bdb")
