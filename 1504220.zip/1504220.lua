-- Lua provided by RyzenAPI
-- Game: Game: AppID 1504220

-- MAIN APPLICATION
addappid(1504220)
-- Game: addappid(1504220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504221, 1, "ba8d4b8b1c8821b60875d3bc7b72722f5e3f2bd95388f109453c207a46518fd7")
