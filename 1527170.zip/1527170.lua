-- Lua provided by RyzenAPI
-- Game: Flying Girls

-- MAIN APPLICATION
addappid(1527170)
addappid(1528790)
addappid(1528791)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527171, 1, "e80af75d1ed9903b80171db01d711f3f690d359d66fc53c3c61ed95493124663")
