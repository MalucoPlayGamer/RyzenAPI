-- Lua provided by RyzenAPI
-- Game: Game: True Abstraction: Rewind Soundtrack

-- MAIN APPLICATION
addappid(3024360)
-- Game: addappid(3024360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024361, 1, "bd94fbf93257d491791bed5cfc5bbc9a1eb1c2f5db59ceef612def85c4f40645")
