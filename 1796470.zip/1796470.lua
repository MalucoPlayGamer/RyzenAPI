-- Lua provided by RyzenAPI
-- Game: Haste

-- MAIN APPLICATION
addappid(1796470)
-- Game: addappid(1796470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796471, 1, "1be44ffc3d55a3bfef475a9ca61508d531a7ff622c0d1ae83629e6b393fa0932")
addappid(1796472, 1, "2a2c45947a29324bdaf94d3259343dcdfd27c743d86cee2c7f6be5b5335057f4")
addappid(1796473, 1, "982d510676c5368c9c89c0e4a3c0a4fa849832fcb212a61e4f33ef3f43fe6605")
