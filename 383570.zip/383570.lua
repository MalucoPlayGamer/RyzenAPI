-- Lua provided by RyzenAPI
-- Game: Streets of Fury EX Demo

-- MAIN APPLICATION
addappid(383570)

-- MAIN APP DEPOTS / PACKAGES
addappid(383571, 1, "b544da15e2b5421a458cda5dea37bdc717801cda227366fa458f69e5afe2499e")
