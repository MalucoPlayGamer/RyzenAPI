-- Lua provided by RyzenAPI
-- Game: Game: Shui's Odyssey

-- MAIN APPLICATION
addappid(2808960)
-- Game: addappid(2808960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808961, 1, "10eb66acf9ccc4466d2532d6949d85f0fbe6e170ec8c461e022f2192d981b97a")
