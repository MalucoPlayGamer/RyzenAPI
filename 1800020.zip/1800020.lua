-- Lua provided by RyzenAPI
-- Game: Unreal Mashup Playtest

-- MAIN APPLICATION
addappid(1800020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800021, 1, "dd32ec027cb51c7f69fe300bc378d7f982b523eeb5699e86e03155a322563476")
