-- Lua provided by RyzenAPI
-- Game: TOK 2

-- MAIN APPLICATION
addappid(1047960)
-- Game: addappid(1047960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047961, 1, "5ffae2af1479c2fc7b2eb5dba0923ccdeb1df95e4c788fd419fd2377dc17ea5a")
