-- Lua provided by RyzenAPI
-- Game: Sling Ming

-- MAIN APPLICATION
addappid(489120)
-- Game: addappid(489120)

-- MAIN APP DEPOTS / PACKAGES
addappid(489121, 1, "f48a2be9f447fd930a1eccf594d811e4730fb5fda24ca4626322e4639f96290a")
addappid(489122, 1, "4da1aa9af755fa5c9d4c3b911e3543d0b8822a30f77f106c9d879c3ad9d19644")
