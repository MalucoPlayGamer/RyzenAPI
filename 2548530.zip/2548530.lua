-- Lua provided by RyzenAPI
-- Game: RegicideX

-- MAIN APPLICATION
addappid(2548530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548531, 1, "4a99fa7766ff5e00ec405b5cbd856d13e17d9e4ec9539343f57870aeb1f1996d")

