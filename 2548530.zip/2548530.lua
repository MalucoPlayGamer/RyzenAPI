-- Lua provided by RyzenAPI
-- Game: RegicideX

-- MAIN APPLICATION
addappid(2548530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548531, 1, "4a99fa7766ff5e00ec405b5cbd856d13e17d9e4ec9539343f57870aeb1f1996d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
