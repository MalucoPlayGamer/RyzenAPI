-- Lua provided by RyzenAPI
-- Game: Day D: Tower Rush

-- MAIN APPLICATION
addappid(423550)
addappid(464680)
addappid(464681)

-- MAIN APP DEPOTS / PACKAGES
addappid(423551, 1, "2dba4f89823415846c77e16efe48665e1890597892f4eeeb78fcdf03c895b521")
