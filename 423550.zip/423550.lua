-- Lua provided by RyzenAPI
-- Game: 423550

-- MAIN APPLICATION
addappid(423550)
addappid(464680)
addappid(464681)
-- Game: addappid(423550)

-- MAIN APP DEPOTS / PACKAGES
addappid(423551, 1, "2dba4f89823415846c77e16efe48665e1890597892f4eeeb78fcdf03c895b521")
