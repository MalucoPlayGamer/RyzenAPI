-- Lua provided by RyzenAPI
-- Game: Sam & Max 204: Chariots of the Dogs

-- MAIN APPLICATION
addappid(8290)

-- MAIN APP DEPOTS / PACKAGES
addappid(8291, 1, "898321186618783bb4b0ba5a34c05531e95bb1ee861b189bbdb4c5ef4fdadcd5")
addappid(8292, 1, "bf8ea49a6bdc7fbd5142498c51b2fe324f3e714d435d652299200614a46cf1c8")

