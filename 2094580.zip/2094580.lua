-- Lua provided by RyzenAPI
-- Game: We. The Refugees: Ticket to Europe

-- MAIN APPLICATION
addappid(2094580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094581, 1, "e06a3f014bf12ddd9e733af9befa6d15dbbf89cfb7aa6188124e35d04568dd0e")
