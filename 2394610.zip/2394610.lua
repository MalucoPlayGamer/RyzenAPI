-- Lua provided by RyzenAPI
-- Game: Destroy All Zombies

-- MAIN APPLICATION
addappid(2394610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394611, 1, "84215eb3a77c299dc18bd0373d778d7e01cada37c72fd75ee0588edaf61830f4")

