-- Lua provided by RyzenAPI
-- Game: Escape the Backrooms

-- MAIN APPLICATION
addappid(1943950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943951, 1, "7930e28c405ca5c1ab83cb57ad8f6a96adc288960b0e60acbc764ff1154d8bb3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
