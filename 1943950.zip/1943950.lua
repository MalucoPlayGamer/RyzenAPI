-- Lua provided by RyzenAPI
-- Game: Escape the Backrooms

-- MAIN APPLICATION
addappid(1943950)
-- Game: addappid(1943950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943951, 1, "7930e28c405ca5c1ab83cb57ad8f6a96adc288960b0e60acbc764ff1154d8bb3")
