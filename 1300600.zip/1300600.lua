-- Lua provided by RyzenAPI
-- Game: 1300600

-- MAIN APPLICATION
addappid(1300600)
-- Game: addappid(1300600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300601, 1, "58990efd4959235802c213b59308f2a5da29a4db82f0417cabf2ab1ddcf18420")
