-- Lua provided by RyzenAPI
-- Game: AppID 1203620

-- MAIN APPLICATION
addappid(1203620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203621, 1, "7f96699c353588876112960fa1128ff856383861b188907320369a798ecb07bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
