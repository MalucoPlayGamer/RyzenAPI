-- Lua provided by RyzenAPI
-- Game: addappid(1291310)

-- MAIN APPLICATION
addappid(1291310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291311, 1, "54b0475f9d2fe57d3d7f7a3fbf5227dc628edf8ffcf7103853415e207e9890bd")
