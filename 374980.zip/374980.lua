-- Lua provided by RyzenAPI
-- Game: Zombie Grinder Dedicated Server

-- MAIN APPLICATION
addappid(374980)

-- MAIN APP DEPOTS / PACKAGES
addappid(374981, 1, "384398fb2d39e6bed6d455069d71076b2f34549662ae3213c287c136d4d11bda")
addappid(374982, 1, "f89a59b04562d34733565adf5aa50706e4d9558c9acc7f44f3272c831ad0f9b8")
addappid(374983, 1, "cddbf37139d080ee9f3cd140b80c9f19f19ab79f8a34787de6ade55941c46562")
addappid(374984, 1, "0ae186a3c4363e527fbb6aa7abbac1a5f3e1ec61fde97951f52c2996fc26a1f2")

