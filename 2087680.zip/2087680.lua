-- Lua provided by RyzenAPI
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 2 - Savage Bees - Main Theme

-- MAIN APPLICATION
addappid(2087680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087681, 1, "4c5a4c46a06a73af99dd2f0150eda4d87b50f3421ed7b393fced2e27949bafeb")
addappid(2087682, 1, "c6349f232e450f0f19b011de1d4288ea725dc2523189d69ee17fb205af76a859")
addappid(2087683, 1, "1908d6bc6a9c2d91355add04b3d99ed4296c7c9c077d09fa12050edfd0a96f82")
addappid(2087684, 1, "4680b3bed8f5a4af3c910450e069ab98683efcdfcf812235f3cb5a51de70bf7b")
addappid(2087685, 1, "b7270c8474b3bd566150b822106e787d4a11bcc1addda160cc31088825fc8a89")
addappid(2087686, 1, "8fd80d9203fc4017b3f210fbad9f2d066dd0837d84692d08b7ff150ee521003c")

