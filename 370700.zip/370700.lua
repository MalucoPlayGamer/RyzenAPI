-- Lua provided by RyzenAPI
-- Game: AppID 370700

-- MAIN APPLICATION
addappid(370700)

-- MAIN APP DEPOTS / PACKAGES
addappid(370701, 1, "0a81f5d6528fe3dac9c0f9579ef9e44c6c8ddd22cdc55b0b8a37e06ebc4970cd")

