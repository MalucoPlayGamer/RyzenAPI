-- Lua provided by RyzenAPI
-- Game: AppID 104310

-- MAIN APPLICATION
addappid(104310)
-- Game: addappid(104310)

-- MAIN APP DEPOTS / PACKAGES
addappid(104311, 1, "af4ae49981191d5df1b7e2c99fdcf29b9e114f87f33635878a05abd9225ffa80")
