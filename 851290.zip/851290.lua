-- Lua provided by RyzenAPI
-- Game: AppID 851290

-- MAIN APPLICATION
addappid(851290)
addappid(899450)

-- MAIN APP DEPOTS / PACKAGES
addappid(851291, 1, "9f18639f4a1a3b3dc7838a99d408bd973faf7d6d5a924d8a64eda5a4c16f5c66")

