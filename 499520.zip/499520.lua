-- Lua provided by RyzenAPI
-- Game: The Turing Test

-- MAIN APPLICATION
addappid(499520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(499521, 1, "cc27c1105b28869f1278b2c6fb340d06c510c2914e0e31550d5bde626a84ff70")
addappid(508340, 0, "7a6bce78bb56b7bb61496273da749598fbe51d4b93c8832bd94cd99794927197")
