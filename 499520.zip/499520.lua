-- Lua provided by RyzenAPI 
-- Game: AppID 499520
addappid(499520)
addappid(499521, 1, "cc27c1105b28869f1278b2c6fb340d06c510c2914e0e31550d5bde626a84ff70")
addappid(508340, 0, "7a6bce78bb56b7bb61496273da749598fbe51d4b93c8832bd94cd99794927197")
