-- Lua provided by RyzenAPI
-- Game: What Lies in the Multiverse

-- MAIN APPLICATION
addappid(1721170)
addappid(1890070)
addappid(1946130)
addappid(1946131)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1721171, 1, "2384f8deb443147284cb2d0093e12e3e6c89571ccc48e47057346e9c10588d8d")

