-- Lua provided by RyzenAPI
-- Game: Super Bomberman R

-- MAIN APPLICATION
addappid(702700)
addappid(812290)
addappid(812291)

-- MAIN APP DEPOTS / PACKAGES
addappid(702701, 1, "c7bff373e03c51f4adbf1650a0855ba0656048194ba748cac31944971841d89f")

