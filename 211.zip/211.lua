-- Lua provided by RyzenAPI
-- Game: Source SDK

-- MAIN APPLICATION
addappid(211)

-- MAIN APP DEPOTS / PACKAGES
addappid(211,0,"45b0f10ae3a5f73b71eb456eae343bd2318b0966e300401cd0feabc23185d212")
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")

