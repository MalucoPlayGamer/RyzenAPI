-- Lua provided by RyzenAPI
-- Game: Undead Run

-- MAIN APPLICATION
addappid(1294360)
-- Game: addappid(1294360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1294361, 1, "c2650e28bea4ed3691f9c972378498c8e6f947d77efb7f8a4d9e252751bea9e3")
