-- Lua provided by RyzenAPI
-- Game: Undead Run

-- MAIN APPLICATION
addappid(1294360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1294361, 1, "c2650e28bea4ed3691f9c972378498c8e6f947d77efb7f8a4d9e252751bea9e3")

