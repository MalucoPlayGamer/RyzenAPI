-- Lua provided by RyzenAPI
-- Game: Agent 64: Spies Never Die

-- MAIN APPLICATION
addappid(1743100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1574480, 1, "de777abb2420f0d703649b2e101c54768290b26cf03e2039271eb7e2d96ecf05") -- Agent 64: Spies Never Die
addappid(1574481, 1, "5ff20f578dfd86513b490d420855fbf6bb17f84326cbd759e3252f234a898e84") -- Depot 1574481
addappid(1743100, 1, "243f2afea07dacdf2074bc6c23e391519d934b6dfb50e71c914c6758d5ccd14a") -- Agent 64 - Supporter Edition Pack - Depot 1743100

