-- Lua provided by RyzenAPI
-- Game: 糟糕！他们太爱我了怎么办？

-- MAIN APPLICATION
addappid(2877720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2877721, 1, "a7533f47fd2d9260c34c894f13b0685d57879c56bce9478bfb21ea0500eda95b")

