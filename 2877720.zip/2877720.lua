-- Lua provided by RyzenAPI
-- Game: Game: 糟糕！他们太爱我了怎么办？

-- MAIN APPLICATION
addappid(2877720)
-- Game: addappid(2877720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877721, 1, "a7533f47fd2d9260c34c894f13b0685d57879c56bce9478bfb21ea0500eda95b")
