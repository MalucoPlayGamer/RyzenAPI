-- Lua provided by RyzenAPI
-- Game: 2538110

-- MAIN APPLICATION
addappid(2538110)
-- Game: addappid(2538110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538111, 1, "2fabc508d56c16ed018e1bfefa83b2626b2acb66a00698b5a2961b9b76aaf66d")
