-- Lua provided by SkyAPI 
-- Game: AppID 1728570
addappid(1728570)
addappid(1728571, 1, "4800a76c9f397117804860aea66a810a7d5344ea26697267e1e649bf44219c58")
