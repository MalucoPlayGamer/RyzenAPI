-- Lua provided by RyzenAPI
-- Game: addappid(691580)

-- MAIN APPLICATION
addappid(691580)

-- MAIN APP DEPOTS / PACKAGES
addappid(691581, 1, "6e3ca99e589d6eeb1a1137ca17db957662d5e23b54d827c6bd7838d8f21b3284")
