-- Lua provided by RyzenAPI
-- Game: 1326840

-- MAIN APPLICATION
addappid(1326840)
-- Game: addappid(1326840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326841, 1, "1b6261c7f10f05c033ba46aced8b0359f33750cf419bdfe9b6ea845c9976b24f")
