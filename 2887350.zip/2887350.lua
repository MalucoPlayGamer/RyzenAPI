-- Lua provided by RyzenAPI
-- Game: Game: Fluffy Sailors

-- MAIN APPLICATION
addappid(2887350)
-- Game: addappid(2887350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887351, 1, "77b07113df5e3e5aedd87e7fc25570e14dc96c1528a62e85d170ad54314f8490")
