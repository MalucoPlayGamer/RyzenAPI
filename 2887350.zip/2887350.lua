-- Lua provided by SkyAPI 
-- Game: Fluffy Sailors
addappid(2887350)
addappid(2887351, 1, "77b07113df5e3e5aedd87e7fc25570e14dc96c1528a62e85d170ad54314f8490")
