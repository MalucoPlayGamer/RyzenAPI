-- Lua provided by RyzenAPI
-- Game: Growmancer

-- MAIN APPLICATION
addappid(3690720)
-- Game: addappid(3690720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690721, 1, "0d8d9058e4a8548f312de26543ee034cd89d4779f3cc9130a9c5503057d71796")
