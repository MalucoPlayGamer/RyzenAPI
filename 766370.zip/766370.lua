-- Lua provided by RyzenAPI
-- Game: Game: AppID 766370

-- MAIN APPLICATION
addappid(766370)
-- Game: addappid(766370)

-- MAIN APP DEPOTS / PACKAGES
addappid(766371, 1, "fa01c87764bb04a9345b076ed1379153be827db70ab7431eb23c05990c9c16d2")
