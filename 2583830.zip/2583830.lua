-- Lua provided by RyzenAPI
-- Game: Game: 手積み麻雀

-- MAIN APPLICATION
addappid(2583830)
-- Game: addappid(2583830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583831, 1, "a0d9ee0391dfa0564bd13018f0ca59172dcd0ee4951eccbf7874353f8e38e282")
