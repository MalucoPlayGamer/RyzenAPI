-- Lua provided by RyzenAPI
-- Game: addappid(2814110)

-- MAIN APPLICATION
addappid(2814110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814110,0,"1023441950b95d0576b096514e05ff00fbd3ffcd3ba3efa121fb67a253b3166c")
