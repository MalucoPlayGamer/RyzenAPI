-- Lua provided by RyzenAPI
-- Game: Polyroll

-- MAIN APPLICATION
addappid(743850)

-- MAIN APP DEPOTS / PACKAGES
addappid(743851,0,"c57b2d5fb0cfe4911d418ad064971162e994a7d410665891b4c64eac8f0ec955")

