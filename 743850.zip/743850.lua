-- Lua provided by RyzenAPI
-- Game: Polyroll

-- MAIN APPLICATION
addappid(743850)

-- MAIN APP DEPOTS / PACKAGES
addappid(743851,0,"c57b2d5fb0cfe4911d418ad064971162e994a7d410665891b4c64eac8f0ec955")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1180750)
