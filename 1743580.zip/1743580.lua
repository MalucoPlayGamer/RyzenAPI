-- Lua provided by RyzenAPI
-- Game: Horny Elves and a Moral Orc

-- MAIN APPLICATION
addappid(1743580)
-- Game: addappid(1743580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743581, 1, "339e6187a9811eb9ab1228decc2b1dd5551cfb7ffc356a0a10f31dc380a9621a")
