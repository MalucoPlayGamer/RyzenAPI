-- Lua provided by RyzenAPI
-- Game: Horny Elves and a Moral Orc

-- MAIN APPLICATION
addappid(1743580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743581, 1, "339e6187a9811eb9ab1228decc2b1dd5551cfb7ffc356a0a10f31dc380a9621a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
