-- Lua provided by RyzenAPI 
-- Game: CODE: PANDORA
addappid(1850520)
addappid(1850521, 1, "abd0868a11d90a26b0911ee489f6ff053d74b61b88c76c4093db4ab3ae05bc30")
addappid(2374520, 0, "a650eb9e3ba534676010a52c5d621c0c25f9c89607421dd3740fa5b2587223ac")
