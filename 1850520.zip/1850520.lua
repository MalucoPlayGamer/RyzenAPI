-- Lua provided by RyzenAPI
-- Game: CODE: PANDORA

-- MAIN APPLICATION
addappid(1850520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850521, 1, "abd0868a11d90a26b0911ee489f6ff053d74b61b88c76c4093db4ab3ae05bc30")
addappid(2374520, 0, "a650eb9e3ba534676010a52c5d621c0c25f9c89607421dd3740fa5b2587223ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
