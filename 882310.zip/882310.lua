-- Lua provided by RyzenAPI
-- Game: Game: AppID 882310

-- MAIN APPLICATION
addappid(882310)
-- Game: addappid(882310)

-- MAIN APP DEPOTS / PACKAGES
addappid(882311, 1, "7ba24c9ee32fb43adc8e7d0ba98e5d829bfb1ebc942d10be2b79ed7854e17233")
