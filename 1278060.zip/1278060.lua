-- Lua provided by RyzenAPI
-- Game: FPV SkyDive : FPV Drone Simulator

-- MAIN APPLICATION
addappid(1278060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278061, 1, "24007944eeceda09e4a71a068a2eefb61e0796774810ea33b1e769d2eb523cd3")
addappid(1278062, 1, "ca259f175f5612bc2b7a66d89be7562dc028faf9938621a163a9c6dc00b51410")
addappid(1278063, 1, "482a3891f2d6a949b943539d6985809e523598fa1c238e890bdb0dd0728ecd53")
addappid(1278064, 1, "85f5cc3514685e06ae8036612ff2e9586dc1a3aba9ddb6d7e36dc0f69022aa74")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1838190)
addappid(1966060)
addappid(2376830)
addappid(2384660)
addappid(2511190)
addappid(3007600)
addappid(3896940)
