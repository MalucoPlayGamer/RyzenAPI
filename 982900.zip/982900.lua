-- Lua provided by RyzenAPI
-- Game: Cat puzzle

-- MAIN APPLICATION
addappid(982900)

-- MAIN APP DEPOTS / PACKAGES
addappid(982901, 1, "97a005d6dcae614c074aca2093984f5c88e823081d394c66c92835dc73d19e15")

