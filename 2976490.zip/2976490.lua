-- Lua provided by RyzenAPI 
-- Game: The Stalked 2
addappid(2976490)
addappid(2976491, 1, "6984e8dddcd7172c7cd0eda21e514fb2e8be4f057bba81de922a2f276f95e014")
