-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1792980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792980,0,"03e65c48b6e74e0d27380a3c9263bb3d07b7113fb936b223e648d01f25cae629")

