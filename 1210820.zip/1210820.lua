-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: JustAsia - Real World Malaysia

-- MAIN APPLICATION
addappid(1210820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210820,0,"bf147663b03d298b9c2f9e58aab6df429268a97aeedf78d501207481e3e425b6")

