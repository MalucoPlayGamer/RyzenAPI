-- Lua provided by RyzenAPI 
-- Game: Party Pirates
addappid(2574760)
addappid(2574761, 1, "c5411ba6a7b91a083a73894c5ce5077de0ebe0a9d1a3592f1bf95d3461ce8c6d")
