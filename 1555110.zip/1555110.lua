-- Lua provided by RyzenAPI 
-- Game: Chasing Tails ~A Promise in the Snow~
addappid(1555110)
addappid(1555111, 1, "221315f2c174e695607ae5f8418db75ae8cbaf0972820adfd71d0a9f659ec0e5")
addappid(1659940, 0, "126503a910566524643e9509240a6da0fb79d672cf8d0fc785ed66a5bb4b10f9")
addappid(1717970, 0, "b79da1aab50259385dff4e117ae76c8e42ae2130e60259db6e079fa3fbcb8653")
addappid(1731980)
