-- Lua provided by RyzenAPI
-- Game: Game: AppID 586530

-- MAIN APPLICATION
addappid(586530)
-- Game: addappid(586530)

-- MAIN APP DEPOTS / PACKAGES
addappid(586531, 1, "e5d1ea650c7ff5be3aa56acabf9de1392b70473fdae5412dbe1c435ffc8a357a")
