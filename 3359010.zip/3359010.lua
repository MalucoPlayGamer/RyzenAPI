-- Lua provided by RyzenAPI
-- Game: Game: Arisen Force: Life Devotee Soundtrack II

-- MAIN APPLICATION
addappid(3359010)
-- Game: addappid(3359010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359011, 1, "7fc27367f95aab5c611886705d7b01b27814291f8f53685e97ce970091b2af24")
