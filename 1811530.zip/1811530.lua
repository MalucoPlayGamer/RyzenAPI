-- Lua provided by RyzenAPI
-- Game: AppID 1811530

-- MAIN APPLICATION
addappid(1811530)
-- Game: addappid(1811530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811531, 1, "615eab21aa074a1a18e2cd224fe96177d40484c01a14b6a5d118bad314378d84")
