-- Lua provided by RyzenAPI
-- Game: addappid(1281150)

-- MAIN APPLICATION
addappid(1281150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281151, 1, "125488174a4217ed25fcce633584e897bd17aa4b57eae3423cf47f06f06fc410")
