-- Lua provided by RyzenAPI
-- Game: Nubla 2

-- MAIN APPLICATION
addappid(1610450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610451, 1, "d4875dc18e5b2da071744d1e9c1ca2f54dcdd07b292302036d2762c2a77aaf38")

