-- Lua provided by RyzenAPI
-- Game: 918700

-- MAIN APPLICATION
addappid(918700)
-- Game: addappid(918700)

-- MAIN APP DEPOTS / PACKAGES
addappid(918701, 1, "1f4c1c0d19d8e4372ad69b1108ab4520208f437e795260bec1992fd743d5bde1")
