-- Lua provided by RyzenAPI
-- Game: addappid(1160010)

-- MAIN APPLICATION
addappid(1160010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160010,0,"a68402b7529fc1e0e5c4c3471fbdcdf4c6c3ed8735b94b9d6fd13afc7643581a")
