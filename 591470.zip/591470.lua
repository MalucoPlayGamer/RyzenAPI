-- Lua provided by RyzenAPI
-- Game: addappid(591470)

-- MAIN APPLICATION
addappid(591470)

-- MAIN APP DEPOTS / PACKAGES
addappid(591471, 1, "de04a29fdd0b127de0129b7fb0ae26f2e8f5f2717529da1c4433abcdbd60ac3e")
