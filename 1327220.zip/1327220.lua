-- Lua provided by SkyAPI 
-- Game: Derpy Conga Demo
addappid(1327220)
addappid(1327221, 1, "7630c176bcda175424f534fdac7fd9369c410f3397e4fb86fb42981adeab9b6b")
