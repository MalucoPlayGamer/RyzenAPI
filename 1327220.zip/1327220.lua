-- Lua provided by RyzenAPI
-- Game: Derpy Conga Demo

-- MAIN APPLICATION
addappid(1327220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327221, 1, "7630c176bcda175424f534fdac7fd9369c410f3397e4fb86fb42981adeab9b6b")
