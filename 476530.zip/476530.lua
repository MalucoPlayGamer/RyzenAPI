-- Lua provided by RyzenAPI
-- Game: AppID 476530

-- MAIN APPLICATION
addappid(476530)

-- MAIN APP DEPOTS / PACKAGES
addappid(476531, 1, "5e775e1aceeee4027b801262f7978e02f6ac3f9552161b6bcf7c5df6794c59b8")

