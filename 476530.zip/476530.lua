-- Lua provided by RyzenAPI
-- Game: Children of a Dead Earth

-- MAIN APPLICATION
addappid(476530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(476531, 1, "5e775e1aceeee4027b801262f7978e02f6ac3f9552161b6bcf7c5df6794c59b8")
