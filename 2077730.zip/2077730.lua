-- Lua provided by RyzenAPI
-- Game: Project: AHNO's Ark Soundtrack

-- MAIN APPLICATION
addappid(2077730)
-- Game: addappid(2077730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077731, 1, "88b69011c45eaf81e396def9a2f88594d4f725ad31f47535bc03f5bc11657a37")
addappid(2077732, 1, "d4b7fbb428e7f9bd182758cb3e79f752709ff71067a43271fcf9a5d02d262bf5")
