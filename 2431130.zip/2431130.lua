-- Lua provided by SkyAPI 
-- Game: Procrastinaut
addappid(2431130)
addappid(2431131, 1, "4293a689811ff3ea2ed68ab20c3a52be43d51dfe846780358f8934f2aefc957b")
