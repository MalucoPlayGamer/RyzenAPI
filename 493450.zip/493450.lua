-- Lua provided by RyzenAPI
-- Game: Wild Romance

-- MAIN APPLICATION
addappid(493450)

-- MAIN APP DEPOTS / PACKAGES
addappid(493451, 1, "49f2912788a43146115edcc52eeda45feb3dae00622b58440c5671b6757dcae8")
addappid(493452, 1, "0c25bd75f360c45d0c2083b1d5feeeed103f2633f84185a3920784ff09ab34df")
addappid(493453, 1, "b1f4152d2eea97c06dfed637ea2e00691af4b99f13bee3810cc2d8b6d7ad77bc")
