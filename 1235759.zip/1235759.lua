-- Lua provided by RyzenAPI
-- Game: The Sims™ 4 Spooky Stuff

-- MAIN APPLICATION
addappid(1235759)
-- Game: addappid(1235759)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235759,0,"2aafcdce1a4406bc20732069711a0b852be5f19a1fc8a2ac81f9f448d642a1f3")
addappid(1242120,0,"f9600393300ff31bb49f49a2f9b64b8601612c9fa94b2a57c8f3edbe4a3ed4a5")
addappid(1242126,0,"a67c862281e7b42d155b73cab7e2d40828edae539f49572914b4356b24ffd525")
addappid(1242132,0,"9c741a64bd6c91052b6d8a2eb4e157ab6367eb25ad6a973f7e2854d25e6e72a2")
addappid(1242134,0,"d0df8bee4c3357cc7a16f5634c1522326d18f5937f847cece53499be17e750d7")
addappid(1242136,0,"9c15c3d0feb09fbe25a6deaca570f26ebace4876968a53afc6d2dae4097ac3a3")
addappid(1242137,0,"3f0a507b60a89fa699df0f7ef6be76ff3bf00cfcca2e36b7ae0f1ecaa65580a8")
