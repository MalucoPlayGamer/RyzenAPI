-- Lua provided by RyzenAPI
-- Game: Ad Exitum

-- MAIN APPLICATION
addappid(444990)

-- MAIN APP DEPOTS / PACKAGES
addappid(444991, 1, "20f24fbbf60bca73c5e56084dc8072853da923d75a5ee8f796343a3f10b8b569")
