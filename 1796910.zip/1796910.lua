-- Lua provided by RyzenAPI
-- Game: Stealing a Monster Girl Harem

-- MAIN APPLICATION
addappid(1796910)
-- Game: addappid(1796910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796911, 1, "87d886ccd202e31a297302119d5e6f7c3cd07d6c63adea908f601647327d9f7d")
