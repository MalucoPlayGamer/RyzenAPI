-- Lua provided by RyzenAPI
-- Game: Curse: The Eye of Isis

-- MAIN APPLICATION
addappid(302210)
-- Game: addappid(302210)

-- MAIN APP DEPOTS / PACKAGES
addappid(302211, 1, "2ea0e030943adef9eb801a5d18d2bdc10a77cfef7b0e09a70b2438ac2118b310")
addappid(302212, 1, "cbb06f6fe44d2d72130fef389c0bfa6d55c7261836f87c3d348a290afa14f42e")
addappid(302213, 1, "5eea131ef3c7cc3273e74b186353acb919912bd5001a790ce171c0f38ab6b243")
addappid(302214, 1, "6702d00771b5110c67772676446a753b0b79b737b7371cfd7e12e5d57e6964fd")
addappid(302215, 1, "e909cdb09ad2b92a6c4e5db3f11039be98ac71598897a083a17cb743f5240d27")
addappid(302216, 1, "5158ee87b067e9d9fe4bd7a574cfa98651958d417edc38165ebeb6ed46f20650")
addappid(302217, 1, "4f90ad346d7d285b44ec2aa8dfecbc0e70b2a2f1c0bf5c3d5d10e10e8798dae7")
