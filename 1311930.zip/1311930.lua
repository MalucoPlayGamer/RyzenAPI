-- Lua provided by RyzenAPI
-- Game: Game: Robot Invasion

-- MAIN APPLICATION
addappid(1311930)
-- Game: addappid(1311930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311931, 1, "5f5fb693761cbc4d2061fb12401e08c656aab10888516b6ad62b27133ff49035")
