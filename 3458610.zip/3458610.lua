-- Lua provided by RyzenAPI 
-- Game: I'LL FUCK YOUR GRANDPA!
addappid(3458610)
addappid(3458611, 1, "9c970d45d8a25214a0dff5151473762695148ec85a922381302b4dcb554e4d16")
