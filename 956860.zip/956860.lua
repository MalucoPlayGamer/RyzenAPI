-- Lua provided by RyzenAPI
-- Game: 956860

-- MAIN APPLICATION
addappid(956860)
-- Game: addappid(956860)

-- MAIN APP DEPOTS / PACKAGES
addappid(956860,0,"9a193de86cf06fdc298d0bbef8e28309b2990ab80adc0f6010f024c29dacf1a6")
