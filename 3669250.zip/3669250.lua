-- Lua provided by RyzenAPI
-- Game: Vambrace: Dungeon Monarch Soundtrack

-- MAIN APPLICATION
addappid(3669250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3669251, 1, "1c55620c832d75e13ae7b2cc99ee7843cdda2c11ed06561f5a570515caad0dfb")
