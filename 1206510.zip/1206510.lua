-- Lua provided by RyzenAPI
-- Game: 1206510

-- MAIN APPLICATION
addappid(1206510)
-- Game: addappid(1206510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206511, 1, "ec6bd900bbc41ed62f78c28875fe6f7fef04c098f371c4026b64dcd10b6f57a6")
