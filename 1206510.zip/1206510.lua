-- Lua provided by RyzenAPI
-- Game: The inside of a drawer

-- MAIN APPLICATION
addappid(1206510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1206511, 1, "ec6bd900bbc41ed62f78c28875fe6f7fef04c098f371c4026b64dcd10b6f57a6")

