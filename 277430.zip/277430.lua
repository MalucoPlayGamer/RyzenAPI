-- Lua provided by RyzenAPI
-- Game: Halo: Spartan Assault

-- MAIN APPLICATION
addappid(277430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(277431, 1, "fd9a9ecb04ca6ba10edca1d45e65a83e082284ec233a32148f175616283f4545")

