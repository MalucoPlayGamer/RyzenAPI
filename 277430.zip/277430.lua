-- Lua provided by RyzenAPI
-- Game: Halo: Spartan Assault

-- MAIN APPLICATION
addappid(277430)

-- MAIN APP DEPOTS / PACKAGES
addappid(277431, 1, "fd9a9ecb04ca6ba10edca1d45e65a83e082284ec233a32148f175616283f4545")
