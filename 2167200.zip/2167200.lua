-- Lua provided by RyzenAPI
-- Game: AppID 2167200

-- MAIN APPLICATION
addappid(2167200)
-- Game: addappid(2167200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167201, 1, "83cdef46dcee06df13dad8315d4de940c96a1528e3175ea3bafa98c1da79d7f7")
addappid(2167206, 1, "bf786e7e3bfad1988e39efa9b008ce875927b8e651351d4963f5c44643f0152b")
