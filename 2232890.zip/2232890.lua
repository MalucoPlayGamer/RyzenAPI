-- Lua provided by RyzenAPI
-- Game: Wo Long: Fallen Dynasty Digital Art Book & Digital Mini Soundtrack

-- MAIN APPLICATION
addappid(2232890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232890,0,"c9d303abb2711b7678880b74da95738ae983c74990967e0607993544a12c5087")

