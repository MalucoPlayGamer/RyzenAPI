-- Lua provided by RyzenAPI
-- Game: addappid(1340850)

-- MAIN APPLICATION
addappid(1340850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340851, 1, "2131de0ef67837f5b092b156a4a2369ce48be0ad4458f163f180b0d61cdef001")
