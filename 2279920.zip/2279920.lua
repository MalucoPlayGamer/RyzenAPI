-- Lua provided by RyzenAPI
-- Game: Game: AppID 2279920

-- MAIN APPLICATION
addappid(2279920)
-- Game: addappid(2279920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279921, 1, "1d45ce253103c8dc0dfba586b4c3a83201f1f3567de57289eae3b795e4105474")
