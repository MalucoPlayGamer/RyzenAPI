-- Lua provided by RyzenAPI
-- Game: Rubber Royale Demo

-- MAIN APPLICATION
addappid(2564890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564891, 1, "ad406a883ffcfcaf369e88336e1144e95c28425c60e45cf9d69d5d037c5d9f60")
