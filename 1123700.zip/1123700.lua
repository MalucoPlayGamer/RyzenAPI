-- Lua provided by RyzenAPI
-- Game: addappid(1123700)

-- MAIN APPLICATION
addappid(1123700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123700,0,"de3de793203b3b2b9248bfc81a3120dd77ea4c71a139ea515e0a03d6ceeadb9c")
