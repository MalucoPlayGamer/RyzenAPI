-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1123700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123700,0,"de3de793203b3b2b9248bfc81a3120dd77ea4c71a139ea515e0a03d6ceeadb9c")
