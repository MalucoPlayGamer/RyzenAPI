-- Lua provided by RyzenAPI
-- Game: Strawberry Park

-- MAIN APPLICATION
addappid(2966530)
-- Game: addappid(2966530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966531, 1, "a373b65702d9fd142a98e8e6d02ee74a21f83dbfeea730ef616bcd0b72b68c0e")
