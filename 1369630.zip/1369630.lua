-- Lua provided by RyzenAPI
-- Game: ENDER LILIES: Quietus of the Knights

-- MAIN APPLICATION
addappid(1369630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1369631, 1, "37ffbdc102510093006d481ea5f5ee9d29a9b5f27824e96618acad7c222bce6c")
addappid(1369632, 1, "70f3ae8930871c24f176aa4286689264f984fb94b18bbb30f2b5a46d1ec053b8")

