-- Lua provided by RyzenAPI
-- Game: 2138540

-- MAIN APPLICATION
addappid(2138540)
-- Game: addappid(2138540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138541, 1, "9bf9a50e62513210645afaecf927a022a1ad71b6a916fdb239eeae48bf3fa4ec")
