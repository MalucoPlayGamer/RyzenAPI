-- Lua provided by RyzenAPI
-- Game: ABYSS CRAWLERS plus

-- MAIN APPLICATION
addappid(794760)

-- MAIN APP DEPOTS / PACKAGES
addappid(794761,0,"aa3544c6b8e552f6f6a6b74f80e8d54da40dafa1947bce5f698268c617aacd38")

