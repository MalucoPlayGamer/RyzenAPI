-- Lua provided by RyzenAPI
-- Game: Steampunk Action Battle Simulator

-- MAIN APPLICATION
addappid(662400)

-- MAIN APP DEPOTS / PACKAGES
addappid(662401, 1, "ecb0553ab9e69791ac9861de5449ab7631526cce4b5829684a2261ea97f5a2bb")
