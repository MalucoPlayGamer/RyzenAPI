-- Lua provided by RyzenAPI
-- Game: 660320

-- MAIN APPLICATION
addappid(660320)
-- Game: addappid(660320)

-- MAIN APP DEPOTS / PACKAGES
addappid(660321, 1, "bc12e92c5949b160e6211c5076f9c3ee06e892ea3ee7cee321230f6ca161ae0b")
