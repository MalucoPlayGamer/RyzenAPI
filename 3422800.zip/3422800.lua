-- Lua provided by RyzenAPI 
-- Game: AppID 3422800
addappid(3422800)
addappid(3422801, 1, "80efebb13c03b13e0ad30fa713b7f19f2b8553e8c2a3a5fd3c81d6f7cb862f4c")
