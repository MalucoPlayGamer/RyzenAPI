-- Lua provided by RyzenAPI
-- Game: 1684141

-- MAIN APPLICATION
addappid(1684141)
-- Game: addappid(1684141)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684141,0,"0551990412beab556f0ff42eb386f35fd4c8a8c9e19f026569982c75151ef5ed")
