-- Lua provided by RyzenAPI
-- Game: 2545740

-- MAIN APPLICATION
addappid(2545740)
-- Game: addappid(2545740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545741, 1, "4ff27606b11d1b6e0091674eec5dba91ff5c297177e17abc952012652cd5bb65")
