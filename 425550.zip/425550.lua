-- Lua provided by RyzenAPI
-- Game: AppID 425550

-- MAIN APPLICATION
addappid(425550)
-- Game: addappid(425550)

-- MAIN APP DEPOTS / PACKAGES
addappid(425551, 1, "fba59cf3e8d6065fecf265e56fbfe1ad6f51bfb5a97716744f807457bf4f2c90")
