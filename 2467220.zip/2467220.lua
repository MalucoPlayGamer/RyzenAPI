-- Lua provided by RyzenAPI
-- Game: TapTap Princess

-- MAIN APPLICATION
addappid(2467220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467221, 1, "ea9d00dc3659b4358e528211f2f1335461d99a64a1db6007c545306a1a49d512") -- (windows)

