-- Lua provided by RyzenAPI
-- Game: 656290

-- MAIN APPLICATION
addappid(656290)
-- Game: addappid(656290)

-- MAIN APP DEPOTS / PACKAGES
addappid(656291, 1, "aef3b0afcc71594ed2d2a39d15d23977dbf8563804cbf851e0ec7573dc60bc61")
