-- Lua provided by RyzenAPI
-- Game: Game: Puppeteer : Control

-- MAIN APPLICATION
addappid(2495160)
-- Game: addappid(2495160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495161, 1, "273cff5a47d6e673d5a5f910ee10f1924f221d9a14decd7036ba1a33cf4be640")
addappid(2613080, 0, "ca03185da83d04a9d8053d73b111f762796949f6177c2d40ad49c18cd71edc61")
addappid(2744980, 0, "3a216c4265b556ad48552bdf85eb544dd02c5c5967acdd366591e0a2ca443dae")
