-- Lua provided by RyzenAPI
-- Game: Puppeteer : Control

-- MAIN APPLICATION
addappid(2495160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495161, 1, "273cff5a47d6e673d5a5f910ee10f1924f221d9a14decd7036ba1a33cf4be640")
addappid(2613080, 0, "ca03185da83d04a9d8053d73b111f762796949f6177c2d40ad49c18cd71edc61")
addappid(2744980, 0, "3a216c4265b556ad48552bdf85eb544dd02c5c5967acdd366591e0a2ca443dae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
