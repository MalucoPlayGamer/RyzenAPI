-- Lua provided by RyzenAPI
-- Game: Contractors Showdown

-- MAIN APPLICATION
addappid(2719160)
addappid(3682230)
addappid(3682240)
addappid(3988260)
addappid(3988290)
addappid(3988320)
addappid(3988330)
addappid(3988340)
addappid(4118490)
addappid(4622600)
addappid(4881990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719161,0,"09414e3bc70d3b13b3e1145978229a49a56414f7aec9ed4eedc8598d31d720b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
