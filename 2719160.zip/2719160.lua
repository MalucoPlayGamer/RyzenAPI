-- Lua provided by RyzenAPI
-- Game: Contractors Showdown

-- MAIN APPLICATION
addappid(2719160)
addappid(3682230)
addappid(3682240)
addappid(3988260)
addappid(3988290)
addappid(3988320)
addappid(3988330)
addappid(3988340)
addappid(4118490)
addappid(4622600)
addappid(4881990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719161,0,"09414e3bc70d3b13b3e1145978229a49a56414f7aec9ed4eedc8598d31d720b6")

