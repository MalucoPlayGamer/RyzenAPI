-- Lua provided by RyzenAPI
-- Game: RetroArch - GW

-- MAIN APPLICATION
addappid(1227450)
-- Game: addappid(1227450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227450,0,"af41208b1cf13df1f053ccbde4aff7c3d079b6ffa366cc7c691eb7f3d4ce5b60")
addappid(1790040,0,"4937f486c7c5d5d2aa33633d4a5a34ff0a4e05298f0b68f7ce6ddd93d2ba7a60")
addappid(1790041,0,"3a59ce386472dd95047f5c50ce363e28332c58d05bf3654b18a013823d2ff68c")
