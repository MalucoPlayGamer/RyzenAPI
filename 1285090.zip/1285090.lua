-- Lua provided by RyzenAPI
-- Game: INFINITY

-- MAIN APPLICATION
addappid(1285090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285091, 1, "495ce0e5a1b71db8c851757da3712938c7785368370d4285209b21220da9b3cd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1289910)
addappid(1305360)
