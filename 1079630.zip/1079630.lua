-- Lua provided by RyzenAPI
-- Game: Death Jump

-- MAIN APPLICATION
addappid(1079630)
-- Game: addappid(1079630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079631, 1, "0a558e8b27c120dab6c2c0f4bcc3b807fdebeef00b2e89880a83dcfeffb7d500")
