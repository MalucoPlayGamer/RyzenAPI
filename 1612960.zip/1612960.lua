-- Lua provided by RyzenAPI
-- Game: Balloon Flight

-- MAIN APPLICATION
addappid(1612960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612961, 1, "ffa073c73e1f77130281712cbee9c1a50c7210de9f9137d415b9d81f151380a4")
