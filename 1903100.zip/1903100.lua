-- Lua provided by RyzenAPI
-- Game: Game: Super Slinger

-- MAIN APPLICATION
addappid(1903100)
-- Game: addappid(1903100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903101, 1, "016e6be054d35bd9b1c2e8312d38acc42d776d50588f13accd24c9b761da9dbf")
