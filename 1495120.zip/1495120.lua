-- Lua provided by RyzenAPI
-- Game: Fairytale Mosaics Cinderella 2

-- MAIN APPLICATION
addappid(1495120)
-- Game: addappid(1495120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495121, 1, "924c11592f96a846fd35aabb8a36ce45866cbdf1065b15abd9f3d1176b239074")
addappid(1495122, 1, "03b887d9ab985bf5016661ffb66d2c79ab325b144968b12cc3570f123f478960")
addappid(1495123, 1, "1c8922af7b4c8f242f2b3432bb747483d84906b5cf78c159998f24f8dda3729e")
addappid(1495124, 1, "b232bd3d493456c84738e3bb55cb74838b88bcb88bc287c0d00bce9d7d7cc9b2")
