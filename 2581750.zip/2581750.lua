-- Lua provided by RyzenAPI
-- Game: W.A.N.D. Project

-- MAIN APPLICATION
addappid(2581750)
-- Game: addappid(2581750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581751, 1, "ec32c1ab232c61df7243eec2b0b7515b81df3955cb8d0a68eaf8c5fc5cf74d75")
