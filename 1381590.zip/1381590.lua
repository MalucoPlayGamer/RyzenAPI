-- Lua provided by RyzenAPI
-- Game: Tokyo Re:Connect Prologue

-- MAIN APPLICATION
addappid(1381590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381591, 1, "1edb60081d8de25a3cbc58286cbf8c2f15d92674435058f842f61660ba84c950")
