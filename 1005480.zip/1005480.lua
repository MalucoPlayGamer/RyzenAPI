-- Lua provided by RyzenAPI
-- Game: Game: ELISEISK 2074

-- MAIN APPLICATION
addappid(1005480)
-- Game: addappid(1005480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005481, 1, "b16e0ad392785fbf7fe0232b7632bce41236bf511446eebdeb5cad4cb63d6077")
