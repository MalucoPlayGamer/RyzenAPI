-- Lua provided by RyzenAPI
-- Game: Reflect

-- MAIN APPLICATION
addappid(2914090)
-- Game: addappid(2914090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914091, 1, "75a78da412328ec1d6eb49fbe4fdb9854b5fb3c51d61d7874e01f335b9d1898d")
