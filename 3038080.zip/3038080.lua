-- Lua provided by RyzenAPI
-- Game: Game: HOT TOYS

-- MAIN APPLICATION
addappid(3038080)
-- Game: addappid(3038080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038081, 1, "e50778d08613b57fe27803f78e081062da352a743f0110935eeb4ae48c6b16d2")
