-- Lua provided by RyzenAPI
-- Game: addappid(2550930)

-- MAIN APPLICATION
addappid(2550930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550931, 1, "5a1b590c8c52c70086e7e1caba8c3f285bbf604d1fe90e232fd42959b30a9dfa")
