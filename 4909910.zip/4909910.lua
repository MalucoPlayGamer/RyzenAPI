-- 4909910's Lua and Manifest Created by Hubcap Manifest
-- Monotony Idle
-- Created: August 13, 2026 at 11:36:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4909910) -- Monotony Idle
-- MAIN APP DEPOTS
addappid(4909911, 1, "b977b14542f1a69991598aae5df5c95b57a47e8148cb9b8eb71700517a1dec11") -- Depot 4909911
setManifestid(4909911, "5987008272867593428", 389723873)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)