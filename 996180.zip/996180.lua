-- Lua provided by RyzenAPI
-- Game: Cryptofall: Investor simulator

-- MAIN APPLICATION
addappid(996180)
addappid(996181)
addappid(996183)

-- MAIN APP DEPOTS / PACKAGES
addappid(996182,0,"1c7375663b2100fb41e3778c74d0ba7057e4d9a1991ea4637b574083a4fde3a2")

