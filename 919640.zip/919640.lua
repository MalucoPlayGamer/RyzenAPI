-- Lua provided by RyzenAPI
-- Game: Steel Division 2

-- MAIN APPLICATION
addappid(919640)

-- MAIN APP DEPOTS / PACKAGES
addappid(919641, 1, "e4accb53bb694864b0f3b1524387a0a4035d482624f09d6d6872b321642d10d3")
addappid(988170, 0, "ef1a14771041deccaf7b6e1d0b2a5892cc9729e1cb8f17f89e6a96c0b21fa4a0")
addappid(988172, 0, "c0e3624a2143c3fc6e9db28bd40caca3c7187fd628e0e86469ed44f242b6224e")

