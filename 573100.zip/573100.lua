-- Lua provided by RyzenAPI 
-- Game: AppID 573100
addappid(573100)
addappid(573101, 1, "83d578fd37698440ef7ee73948c2e7a871f775010d346bd695b85e24e407c490")
