-- Lua provided by RyzenAPI
-- Game: Game: AppID 573100

-- MAIN APPLICATION
addappid(573100)
-- Game: addappid(573100)

-- MAIN APP DEPOTS / PACKAGES
addappid(573101, 1, "83d578fd37698440ef7ee73948c2e7a871f775010d346bd695b85e24e407c490")
