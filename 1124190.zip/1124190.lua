-- Lua provided by RyzenAPI
-- Game: Police Stunt Cars

-- MAIN APPLICATION
addappid(1124190)
-- Game: addappid(1124190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124191, 1, "91cdf06d8e2dda9282208019f1ae0750ba88f556fc41a580f7e34892f86e74f0")
