-- Lua provided by RyzenAPI
-- Game: FUSER™ - Dirty Vegas - "Days Go By"

-- MAIN APPLICATION
addappid(1598242)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598242,0,"25e0c67efef7a7e2cbbbd9d59491896cac6d28ab16b27b5422227bece22da313")
