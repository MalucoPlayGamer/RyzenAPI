-- Lua provided by RyzenAPI
-- Game: AppID 291130

-- MAIN APPLICATION
addappid(291130)

-- MAIN APP DEPOTS / PACKAGES
addappid(291131, 1, "9027e03749fcdbbcafbaf3dfe3f1ddce794f7afa96897ac1fe113c362845d494")

