-- Lua provided by RyzenAPI
-- Game: Sex with Succubus ❤️‍🔥

-- MAIN APPLICATION
addappid(2265180)
-- Game: addappid(2265180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265181, 1, "4832d6cc6ef75aeccd32e52f21aa360ae94f2418558a03f9051af7c01fd0f464")
