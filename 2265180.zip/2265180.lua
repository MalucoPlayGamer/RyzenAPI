-- Lua provided by SkyAPI 
-- Game: Sex with Succubus ❤️‍🔥
addappid(2265180)
addappid(2265181, 1, "4832d6cc6ef75aeccd32e52f21aa360ae94f2418558a03f9051af7c01fd0f464")
