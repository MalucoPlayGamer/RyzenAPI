-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KSEA Airport

-- MAIN APPLICATION
addappid(3632970)
-- Game: addappid(3632970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3632970,0,"b5b275b59954e33dfe62a725ba9f15ea53f121d28bb83e7a4e2e14d87bb882f0")
