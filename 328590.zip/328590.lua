-- Lua provided by RyzenAPI
-- Game: AppID 328590

-- MAIN APPLICATION
addappid(328590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(328591, 1, "acaf34d52e1f81e1e3b5fba6753407167cc4e200a6f249010ed55f0870a7b9b1")

