-- Lua provided by RyzenAPI
-- Game: Catherine Classic

-- MAIN APPLICATION
addappid(893180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(893181, 1, "fb859cb2119e43c326bcbd6cebcc8295d19dc46bda4c89b1689ebb9a5533470e")
addappid(893182, 1, "2bd7675876f35e778037e9749f8696e41f2a2d469b231ac7adae2fecb815fcc6")
