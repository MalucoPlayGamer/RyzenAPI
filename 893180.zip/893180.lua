-- Lua provided by RyzenAPI
-- Game: Game: AppID 893180

-- MAIN APPLICATION
addappid(893180)
-- Game: addappid(893180)

-- MAIN APP DEPOTS / PACKAGES
addappid(893181, 1, "fb859cb2119e43c326bcbd6cebcc8295d19dc46bda4c89b1689ebb9a5533470e")
addappid(893182, 1, "2bd7675876f35e778037e9749f8696e41f2a2d469b231ac7adae2fecb815fcc6")
