-- Lua provided by RyzenAPI
-- Game: Pawperty Damage

-- MAIN APPLICATION
addappid(2154650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154651, 1, "55009fd965ba13552be86989003aa5537cb28f1dd7a30d76b1a9305b3ed1a562")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2498060)
addappid(3217790)
addappid(3311750)
