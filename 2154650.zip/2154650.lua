-- Lua provided by RyzenAPI
-- Game: addappid(2154650)

-- MAIN APPLICATION
addappid(2154650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154651, 1, "55009fd965ba13552be86989003aa5537cb28f1dd7a30d76b1a9305b3ed1a562")
