-- Lua provided by RyzenAPI
-- Game: Dreamcore

-- MAIN APPLICATION
addappid(2453060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453061, 1, "0b8213c75958716335ce8364fb117b9ec29713c1fead925ef42641662bcfeec2")

