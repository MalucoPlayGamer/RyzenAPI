-- Lua provided by RyzenAPI
-- Game: Game: Hentai SpaceSuit

-- MAIN APPLICATION
addappid(2356180)
-- Game: addappid(2356180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356181, 1, "834fc822919ecc686aef2e3e43cc70c685ccf1a2159d343547950881b2de3566")
