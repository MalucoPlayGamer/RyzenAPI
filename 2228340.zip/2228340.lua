-- Lua provided by RyzenAPI
-- Game: Game: Burning Secrets - A Bara Visual Novel

-- MAIN APPLICATION
addappid(2228340)
addappid(2401360)
-- Game: addappid(2228340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2228341, 1, "682fc694dc967c338626d151746baaa6a35d809a28f37145b4c1b95ba86e8923")
