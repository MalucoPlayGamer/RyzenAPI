-- Lua provided by RyzenAPI
-- Game: Project Hive

-- MAIN APPLICATION
addappid(1454100)
-- Game: addappid(1454100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454101, 1, "123e62e7e45f16f7fe0efe9e85c97c5b2ffdec9a897f6cd2cb2a35e39bc71b4f")
