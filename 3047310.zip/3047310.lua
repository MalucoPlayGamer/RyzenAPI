-- Lua provided by RyzenAPI
-- Game: Game: Aim Assault

-- MAIN APPLICATION
addappid(3047310)
-- Game: addappid(3047310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3047311, 1, "d76c4e8367725007a1b444cb87dc9016d90619b9140ee2213ed9d70c1f672df0")
