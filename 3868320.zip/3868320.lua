-- 3868320's Lua and Manifest Created by Hubcap Manifest
-- Forage Wizard
-- Created: June 14, 2026 at 10:35:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3868320, 1, "c614aa405eb6a7426e460f0e07607e77d7a12be3ad2b22b26038ef466d224596") -- Forage Wizard
-- MAIN APP DEPOTS
addappid(3868323, 1, "9e28b51aa4740d06ca3b37fe73b23b365a51c318798a53a4bd622d73b76e476d") -- Depot 3868323
setManifestid(3868323, "1316921033395588190", 726550087)
addappid(3868324, 1, "f4af623014d8ab542b4ee710fbf0367d18a3b80b44b3b74b692a35c9f43bb2c7") -- Depot 3868324
setManifestid(3868324, "2100538762746424745", 866981514)