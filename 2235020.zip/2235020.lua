-- Lua provided by RyzenAPI
-- Game: addappid(2235020)

-- MAIN APPLICATION
addappid(2235020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235021, 1, "18c08150aebeedf87433615a466009912f918212efb6ac8b1e91cb8fbcd2d7a8")
