-- Lua provided by RyzenAPI
-- Game: 2685250

-- MAIN APPLICATION
addappid(2685250)
-- Game: addappid(2685250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685251, 1, "f66b7739e6ab4a9c773c3642ec90f36eaf9510d33416536a58fcfdc26eda20b3")
