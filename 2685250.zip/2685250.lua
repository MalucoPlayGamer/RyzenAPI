-- Lua provided by RyzenAPI
-- Game: Where Rabbits 兔子在哪里

-- MAIN APPLICATION
addappid(2685250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685251, 1, "f66b7739e6ab4a9c773c3642ec90f36eaf9510d33416536a58fcfdc26eda20b3")
