-- Lua provided by RyzenAPI
-- Game: AppID 1003520

-- MAIN APPLICATION
addappid(1003520)
addappid(1015900)
addappid(1073160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003521, 1, "75cb19fa8b0c7314b3a2528a05df4aa62da74ad0093f79355e1eb9dd4a435002")

