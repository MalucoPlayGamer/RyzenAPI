-- Lua provided by RyzenAPI
-- Game: Game: ENTANGLED SOULS

-- MAIN APPLICATION
addappid(2160840)
-- Game: addappid(2160840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160841, 1, "60c068812a5fa33680c87bcf223f3b0908cdf02aef806eac555d16da70068297")
