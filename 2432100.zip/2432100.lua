-- Lua provided by RyzenAPI
-- Game: ONE.

-- MAIN APPLICATION
addappid(2432100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432101, 1, "48b4db9efb8eaa04c883d07cc781906b64de1d0dd45bcb214e644df4ba92bbf5")
