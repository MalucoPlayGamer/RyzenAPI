-- Lua provided by SkyAPI 
-- Game: Let's Play with Nanai!
addappid(851350)
addappid(851351, 1, "5889230dc445c62007f6c32fd49b09a4415798a1411e087f5ebe73422896a548")
