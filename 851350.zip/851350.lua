-- Lua provided by RyzenAPI
-- Game: Let's Play with Nanai!

-- MAIN APPLICATION
addappid(851350)

-- MAIN APP DEPOTS / PACKAGES
addappid(851351, 1, "5889230dc445c62007f6c32fd49b09a4415798a1411e087f5ebe73422896a548")

