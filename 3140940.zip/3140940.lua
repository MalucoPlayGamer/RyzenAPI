-- Lua provided by RyzenAPI
-- Game: The Liminal Dimension Soundtrack

-- MAIN APPLICATION
addappid(3140940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140941, 1, "2885c36166b6ede6781adce68c7c6d6ad62f6415a519a3c5e4a876bf22bef027")
addappid(3140942, 1, "7619a6cdc8e6160fd29c6822035d470a9605fdb17ffe537ec04318a5a7a33110")

