-- Lua provided by RyzenAPI
-- Game: Quantum Odyssey

-- MAIN APPLICATION
addappid(2802710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802711, 1, "124613d203dfcabc9d4a9c3f2e11d64f7939f069bc637f280488d90d668b4479")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
