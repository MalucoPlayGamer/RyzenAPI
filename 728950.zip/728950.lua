-- Lua provided by RyzenAPI 
-- Game: Barrels Up
addappid(728950)
addappid(728951, 1, "1b8ada3949c281b54788f2070e054e37fe437523403ca8169ad72b1050749971")
