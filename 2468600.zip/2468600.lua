-- Lua provided by SkyAPI 
-- Game: My Legend of Immortal Cultivation
addappid(2468600)
addappid(2468601, 1, "529be780c8ed2dfb188c0f99e37a5204179adda3ba248decb8f638f5fc126b2b")
