-- Lua provided by RyzenAPI
-- Game: 2468600

-- MAIN APPLICATION
addappid(2468600)
-- Game: addappid(2468600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468601, 1, "529be780c8ed2dfb188c0f99e37a5204179adda3ba248decb8f638f5fc126b2b")
