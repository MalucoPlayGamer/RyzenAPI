-- Lua provided by RyzenAPI
-- Game: 我就是建-I just build

-- MAIN APPLICATION
addappid(3426410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3426411, 1, "a587150b45ccbe72d0eaa46d7258e0dfe56144fc07324efd464d4e4fbce987ec")
