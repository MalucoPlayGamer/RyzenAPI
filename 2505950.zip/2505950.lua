-- Lua provided by RyzenAPI
-- Game: Grand Prix Rock 'N Racing

-- MAIN APPLICATION
addappid(2505950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505951,0,"68c0a0217cb73c75bba6e925174460c1e90c5f770cef6c0b59b680fb32ef7d6f")

