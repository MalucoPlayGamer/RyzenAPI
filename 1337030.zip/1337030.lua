-- Lua provided by RyzenAPI
-- Game: En-Train

-- MAIN APPLICATION
addappid(1337030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337031, 1, "1a5a08cf68b34887cbc0aed39e7cf482622930951af967d72c887b206ff22ca5")
