-- Lua provided by RyzenAPI
-- Game: addappid(2130590)

-- MAIN APPLICATION
addappid(2130590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130591, 1, "fb2b02607c7ae0664e3951ec28dfeb9a41aa88b0ba8247ccc11400b08cdec063")
