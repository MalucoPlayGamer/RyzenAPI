-- Lua provided by SkyAPI 
-- Game: PUNCH FIT
addappid(2130590)
addappid(2130591, 1, "fb2b02607c7ae0664e3951ec28dfeb9a41aa88b0ba8247ccc11400b08cdec063")
