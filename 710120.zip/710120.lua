-- Lua provided by SkyAPI 
-- Game: Trivia Vault: Mini Mixed Trivia 4
addappid(710120)
addappid(710121, 1, "a01f9905cae6e9be4c105105dca2ce3c9b5be8f0757e1bc4d9ca4d7e8578d50d")
