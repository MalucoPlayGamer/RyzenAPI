-- Lua provided by RyzenAPI
-- Game: Showdown Bandit

-- MAIN APPLICATION
addappid(1076280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076281, 1, "71ec53a7520c66a77aa0c3ff9a632aa61095aba1304d13f36c01f84ba6225b71")
addappid(1076282, 1, "44c3a52e7878d63800b57cd4c28322e8bed568ce02b0f3b8b67f5c99cc432903")
