-- Lua provided by RyzenAPI
-- Game: Aurelia

-- MAIN APPLICATION
addappid(1231560)
-- Game: addappid(1231560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231561, 1, "fd1c18a5c89c59cf23926c576d78b90028d7bde9a857b8ce9579d893305ebbd5")
