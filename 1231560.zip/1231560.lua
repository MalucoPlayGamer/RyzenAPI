-- Lua provided by SkyAPI 
-- Game: Aurelia
addappid(1231560)
addappid(1231561, 1, "fd1c18a5c89c59cf23926c576d78b90028d7bde9a857b8ce9579d893305ebbd5")
