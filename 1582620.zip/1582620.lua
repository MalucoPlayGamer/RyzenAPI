-- Lua provided by RyzenAPI
-- Game: Game: AppID 1582620

-- MAIN APPLICATION
addappid(1582620)
-- Game: addappid(1582620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582621, 1, "28314f38494b6623ff6e8fa37e1492817628d3312fdcafd60f1168316ca17c84")
