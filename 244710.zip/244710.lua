-- Lua provided by SkyAPI 
-- Game: AppID 244710
addappid(244710)
addappid(244711, 1, "4d34e59d22fcc85fdd64c9a7d9a4d6c7716f273c004619018120623871f42973")
addappid(244712, 1, "6501b7d8119c3565139d9d5bf2c6946cc7d9d08ced520fe4da4695cdb03fe9c4")
