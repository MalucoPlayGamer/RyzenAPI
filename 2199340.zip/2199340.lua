-- Lua provided by SkyAPI 
-- Game: Smells Like a Mushroom
addappid(2199340)
addappid(2199341, 1, "b5051bca196dda3f892546f38c47acea78f1c76f53361a2e09906f9bcdc5d24a")
