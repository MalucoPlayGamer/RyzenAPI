-- Lua provided by RyzenAPI
-- Game: addappid(2199340)

-- MAIN APPLICATION
addappid(2199340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199341, 1, "b5051bca196dda3f892546f38c47acea78f1c76f53361a2e09906f9bcdc5d24a")
