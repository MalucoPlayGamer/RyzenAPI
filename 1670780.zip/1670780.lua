-- Lua provided by RyzenAPI
-- Game: Out of Action

-- MAIN APPLICATION
addappid(1670780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1670781, 1, "c4045591f12607e50469a37ca40c8fded6fbea8e5a667fb4b02a6cd587b19322")

