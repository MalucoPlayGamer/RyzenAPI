-- Lua provided by RyzenAPI
-- Game: addappid(1670780)

-- MAIN APPLICATION
addappid(1670780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670781, 1, "c4045591f12607e50469a37ca40c8fded6fbea8e5a667fb4b02a6cd587b19322")
