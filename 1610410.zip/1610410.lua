-- Lua provided by RyzenAPI
-- Game: MR 333

-- MAIN APPLICATION
addappid(1610410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610411, 1, "0c7df09015dd193c072fb936ced012db5f78fd8150502f36683fb5e8def46782")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
