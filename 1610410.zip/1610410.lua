-- Lua provided by RyzenAPI
-- Game: addappid(1610410)

-- MAIN APPLICATION
addappid(1610410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610411, 1, "0c7df09015dd193c072fb936ced012db5f78fd8150502f36683fb5e8def46782")
