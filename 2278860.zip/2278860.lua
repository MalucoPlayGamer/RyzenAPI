-- Lua provided by RyzenAPI
-- Game: Last Train Home Demo

-- MAIN APPLICATION
addappid(2278860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278861, 1, "3c3a15ed4ddf9da11045cad594c4fa2fde5408d6fde759cb88f3f27d724fd89d")
