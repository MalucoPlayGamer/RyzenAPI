-- Lua provided by RyzenAPI
-- Game: Game: Sword Reverie Soundtrack

-- MAIN APPLICATION
addappid(1833390)
-- Game: addappid(1833390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833391, 1, "de4e90a43c43f6583c436d31b912fb991353d5b9ec72a520c15803ea72d7ce13")
addappid(1833392, 1, "050de8ac3707d720511077c62e00e5968a9fc1387ec0d29cae531caca3ca707d")
