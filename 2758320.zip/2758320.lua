-- Lua provided by RyzenAPI
-- Game: Mine? Sweeper

-- MAIN APPLICATION
addappid(2758320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758321, 1, "6ee38e08134afff023e1ed3623bf0dec499c804ca2ea72221c5f4f26913df658")

