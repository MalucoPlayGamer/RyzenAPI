-- Lua provided by RyzenAPI
-- Game: 1556062

-- MAIN APPLICATION
addappid(1556062)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556062,0,"1b1ca1080e5133c64cfea4a49cf3b460a74a8d1021be041eea584da0a9664bdd")
