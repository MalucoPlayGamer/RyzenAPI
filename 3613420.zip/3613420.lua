-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KJFK Airport

-- MAIN APPLICATION
addappid(3613420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3613420,0,"fbcd4dd3a445a22ee5440900d50971a8c166fcc8f3630d228292889a6cd5547f")
