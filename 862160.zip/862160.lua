-- Lua provided by RyzenAPI
-- Game: Comet Crasher

-- MAIN APPLICATION
addappid(862160)
addappid(863600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(862161, 1, "7d40f6faa689d83600326d25cab13a9e83ed0a855f7c1818d1291a270a6983ae")
addappid(862162, 1, "f9be1892023a0e09627eb6ccbad8129405c0f9c90688d4b5f8a1606e8b81d554")

