-- Lua provided by RyzenAPI
-- Game: Dead In Bermuda

-- MAIN APPLICATION
addappid(384310)

-- MAIN APP DEPOTS / PACKAGES
addappid(384311, 1, "7d9d0c179709fb7dce9944eaba44785ffca223ef24bc53f5f219ceb6326ee120")
addappid(384313, 1, "6e001cd993bffbd942bcc4421273546e1bb3e297d677d51dd0d12f7cf7031cde")
