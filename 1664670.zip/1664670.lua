-- Lua provided by RyzenAPI
-- Game: Game: Refactor

-- MAIN APPLICATION
addappid(1664670)
-- Game: addappid(1664670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664671, 1, "bda932bfa3ad56fda9b4019cd48deb386be290e9f5b08e38d66e9371f2c8b37a")
addappid(1664672, 1, "e77599bb5bf0e4920f010041145dbf69dcd21f854729cca8ee4f8e554a16713b")
