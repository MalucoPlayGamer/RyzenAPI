-- Lua provided by RyzenAPI
-- Game: 逆乱西游之西天取经

-- MAIN APPLICATION
addappid(3678920)
-- Game: addappid(3678920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3678921, 1, "810f87d7e0a77820b4c85b9c09e06e11adfd8990e3e32d83231a2ff730cf64cf")
