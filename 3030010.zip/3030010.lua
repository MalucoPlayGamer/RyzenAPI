-- Lua provided by RyzenAPI
-- Game: 召唤师崛起  summoner rises

-- MAIN APPLICATION
addappid(3030010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030011, 1, "c40f73ffd35bd8e808339b330adf207943f9e83fed7c0e2b74f8d281d4202f3a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
