-- Lua provided by RyzenAPI
-- Game: Hentai Sakyubus

-- MAIN APPLICATION
addappid(1216660)
addappid(1216661)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216662,0,"13c8e4a62116132cd1250204ac586a61cca6b8da1c4d891d50f94c094405dc33")

