-- Lua provided by RyzenAPI
-- Game: 风起长安：驭骨人

-- MAIN APPLICATION
addappid(1737070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737071, 1, "68a9adb7dbdbe9e34d95d3f9eb3e05bdec8812a8c7661a62df3fe4f80e5005a5")

