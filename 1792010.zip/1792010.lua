-- Lua provided by RyzenAPI
-- Game: 1792010

-- MAIN APPLICATION
addappid(1792010)
addappid(1876940)
-- Game: addappid(1792010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792011, 1, "4d13a59de843fd65ec1ec601d4f2d51d29b37b5ef1444fb7f1f8e4fceb03f7c4")
