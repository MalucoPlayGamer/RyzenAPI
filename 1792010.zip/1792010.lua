-- Lua provided by RyzenAPI
-- Game: The Timeless Child - Prologue

-- MAIN APPLICATION
addappid(1792010)
addappid(1876940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1792011, 1, "4d13a59de843fd65ec1ec601d4f2d51d29b37b5ef1444fb7f1f8e4fceb03f7c4")

