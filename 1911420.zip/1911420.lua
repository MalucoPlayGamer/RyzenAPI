-- Lua provided by RyzenAPI
-- Game: Game: SEARCH AND RESCUE

-- MAIN APPLICATION
addappid(1911420)
addappid(2480320)
addappid(2891890)
addappid(2904630)
addappid(2931140)
-- Game: addappid(1911420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911421, 1, "1961e13b26d951de62ddbcd5c3ebe1b96685b8801b34b569e8585c257dd13599")
