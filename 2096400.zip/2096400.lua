-- Lua provided by RyzenAPI
-- Game: TAMAKAGURA: Tales of Turmoil

-- MAIN APPLICATION
addappid(2096400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096403,0,"8dc19b1b6fd71825a22fd7493f1db32fef885ed1501515f79979688f7a2fdedb")

