-- Lua provided by RyzenAPI 
-- Game: Demolition Master 3D
addappid(288710)
addappid(288711, 1, "e91578677c5b7f6e15d2eddec05df97034f2aa8aa1a6bfa34ea45a810b72c2fa")
