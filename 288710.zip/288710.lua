-- Lua provided by RyzenAPI
-- Game: Demolition Master 3D

-- MAIN APPLICATION
addappid(288710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(288711, 1, "e91578677c5b7f6e15d2eddec05df97034f2aa8aa1a6bfa34ea45a810b72c2fa")

