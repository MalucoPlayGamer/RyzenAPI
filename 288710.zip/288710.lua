-- Lua provided by RyzenAPI
-- Game: 288710

-- MAIN APPLICATION
addappid(288710)
-- Game: addappid(288710)

-- MAIN APP DEPOTS / PACKAGES
addappid(288711, 1, "e91578677c5b7f6e15d2eddec05df97034f2aa8aa1a6bfa34ea45a810b72c2fa")
