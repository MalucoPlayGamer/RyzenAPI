-- Lua provided by RyzenAPI
-- Game: 1992370

-- MAIN APPLICATION
addappid(1992370)
-- Game: addappid(1992370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992371, 1, "4a82a56942d1ab13903fe7ed1c3510259bd2bb181a8b87f30022cab43e79eff3")
