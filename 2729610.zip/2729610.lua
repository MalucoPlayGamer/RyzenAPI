-- Lua provided by RyzenAPI
-- Game: addappid(2729610)

-- MAIN APPLICATION
addappid(2729610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729610,0,"b207e379337839ed2bca0dae1ec13a71c1b2e3d1a0feaa91e3a6f36178f06eb0")
addappid(3017660,0,"d72ba0f3ff09d49f3f551e263c678bb7a3755e05493e9e4034cf162cead93231")
