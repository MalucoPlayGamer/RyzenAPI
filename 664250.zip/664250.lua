-- Lua provided by RyzenAPI
-- Game: EquiMagic - Galashow of Horses

-- MAIN APPLICATION
addappid(664250)

-- MAIN APP DEPOTS / PACKAGES
addappid(664251,0,"52b04a865fe0357007de57c03eb64565b21ca1dfae0b75bb51f4327d56134e7d")
addappid(664252,0,"a36449591a72c24b7c24156c8b2a4e9a0fb69ae8b613b65f2538651e397943ca")
addappid(664257,0,"94519f4cea6c8ba3ee7a970cc22d4f814e2d998453d97212d4d3e03e24c9fc65")

