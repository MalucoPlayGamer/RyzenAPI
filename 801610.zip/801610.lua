-- Lua provided by RyzenAPI 
-- Game: Amigo Fishing
addappid(801610)
addappid(801611, 1, "59e23797452ffd6fd5d31972dc844656ee412cb35fcadbe93563b30fe0f1a92a")
