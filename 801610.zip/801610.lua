-- Lua provided by RyzenAPI
-- Game: Amigo Fishing

-- MAIN APPLICATION
addappid(801610)

-- MAIN APP DEPOTS / PACKAGES
addappid(801611, 1, "59e23797452ffd6fd5d31972dc844656ee412cb35fcadbe93563b30fe0f1a92a")

