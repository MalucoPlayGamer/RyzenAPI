-- Lua provided by RyzenAPI
-- Game: Amigo Fishing

-- MAIN APPLICATION
addappid(801610)

-- MAIN APP DEPOTS / PACKAGES
addappid(801611, 1, "59e23797452ffd6fd5d31972dc844656ee412cb35fcadbe93563b30fe0f1a92a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
