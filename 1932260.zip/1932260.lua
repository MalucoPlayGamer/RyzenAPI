-- Lua provided by RyzenAPI
-- Game: No Creeps Were Harmed TD

-- MAIN APPLICATION
addappid(1932260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932261, 1, "1daf07e85729a2ee5b1426a9d40d412693012c8037426347cb979feb3dbecc91")

