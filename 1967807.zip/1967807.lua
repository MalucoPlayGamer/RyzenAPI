-- Lua provided by RyzenAPI
-- Game: 1967807

-- MAIN APPLICATION
addappid(1967807)
-- Game: addappid(1967807)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967807,0,"3750332770cb19cc0e71cd87e1f0eec41ffe13571a3ed9b1dd2c4a8ddb3e901b")
