-- Lua provided by RyzenAPI
-- Game: 584380

-- MAIN APPLICATION
addappid(584380)
-- Game: addappid(584380)

-- MAIN APP DEPOTS / PACKAGES
addappid(584385,0,"6a2d04ebe314a42c01f635e110bfc0e6f498b7d80ee5a7255c3b9df9fcb6830d")
addappid(584386,0,"8b5b48c73d326678d216b1ccdf7c4074d05a19356b22836cfc5421a307d43dc5")
