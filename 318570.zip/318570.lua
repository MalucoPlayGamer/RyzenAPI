-- Lua provided by RyzenAPI
-- Game: Hunters Of The Dead

-- MAIN APPLICATION
addappid(318570)
-- Game: addappid(318570)

-- MAIN APP DEPOTS / PACKAGES
addappid(318571, 1, "a9f6175240d188a80a0adf2c6c9cfc78078d477eb9106d176d2823a722708799")
