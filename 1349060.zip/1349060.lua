-- Lua provided by RyzenAPI
-- Game: It Steals

-- MAIN APPLICATION
addappid(1349060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349061, 1, "28d5ce68b499ff47b95c34dfd044e368578d709f719e69e1eb7dcfa25623dfcc")

