-- Lua provided by RyzenAPI
-- Game: Enlightenment

-- MAIN APPLICATION
addappid(663300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(663301, 1, "081843c9d1def5662232a4146d0ed7e2cd7724f2c9192c6866348be123f3dc16")

