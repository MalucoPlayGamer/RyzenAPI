-- Lua provided by RyzenAPI
-- Game: Enlightenment

-- MAIN APPLICATION
addappid(663300)

-- MAIN APP DEPOTS / PACKAGES
addappid(663301, 1, "081843c9d1def5662232a4146d0ed7e2cd7724f2c9192c6866348be123f3dc16")

