-- Lua provided by RyzenAPI 
-- Game: AppID 431810
addappid(431810)
addappid(431811, 1, "3b7db90f51d2d34364e293e92a6b6d24de783329de2148b76a289c0d1d7ad092")
addappid(431812, 1, "6584fa9efac647ed338f5214edb0861af226d0860e71ddafb4a969a6a968471e")
addappid(431813, 1, "c9bf853cb9027fada75de6b1fae63cfdde541a21cfcba32dfccf2a7474837f69")
