-- Lua provided by RyzenAPI
-- Game: Kaichu - The Kaiju Dating Sim

-- MAIN APPLICATION
addappid(1848590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848591, 1, "cd3ded602947be647d8462e3b576e3266702e934847a2adcf19994ac644485d9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2115230)
