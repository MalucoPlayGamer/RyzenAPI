-- Lua provided by RyzenAPI 
-- Game: Demon Speakeasy Soundtrack
addappid(1987370)
addappid(1987371, 1, "5c0cb7ba48fedee866b8b3c90e22dae641dba988107039fd1d6ca93d47adcedb")
addappid(1987372, 1, "e8c2304fe975d3751d88b48750d7bebd9b4d4e3b27a87c0c45d40beb7a6f96d5")
