-- Lua provided by RyzenAPI
-- Game: Spelling Quest Online

-- MAIN APPLICATION
addappid(1086630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086631, 1, "d91882517946c33c85c418b6760434449c82573fac745758e355c0ef02cb7d52")

