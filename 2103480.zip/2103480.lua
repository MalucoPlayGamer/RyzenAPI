-- Lua provided by RyzenAPI
-- Game: Summer Trip Cruise

-- MAIN APPLICATION
addappid(2103480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103481, 1, "23b4bbdc08584d5585831e6b868dffb9ef208b1e5801d32c4aabf6244a3b84e4")

