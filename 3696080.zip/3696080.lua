-- Lua provided by RyzenAPI
-- Game: Game: Zombie Outbreak 1942

-- MAIN APPLICATION
addappid(3696080)
-- Game: addappid(3696080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3696081, 1, "196193e24b1aeb1f6ae97781431a8faee257a7e7168e37d978ee92cc81bf2a74")
