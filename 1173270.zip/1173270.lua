-- Lua provided by RyzenAPI
-- Game: Big Red Hood: Halloween

-- MAIN APPLICATION
addappid(1173270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173271, 1, "a7b4c8701d5149870a8430c5c7a31fcfb99a77b75699ca8c7328fb58df255f9f")
