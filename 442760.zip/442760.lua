-- Lua provided by RyzenAPI
-- Game: Endless Burst

-- MAIN APPLICATION
addappid(442760)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(442761, 1, "5c10a0b433bbbc6344666dd10a916723737a1e200b5b01032e3360edb447d4ad")
