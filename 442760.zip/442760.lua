-- Lua provided by RyzenAPI
-- Game: Game: AppID 442760

-- MAIN APPLICATION
addappid(442760)
-- Game: addappid(442760)

-- MAIN APP DEPOTS / PACKAGES
addappid(442761, 1, "5c10a0b433bbbc6344666dd10a916723737a1e200b5b01032e3360edb447d4ad")
