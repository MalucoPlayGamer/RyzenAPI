-- Lua provided by RyzenAPI 
-- Game: AppID 386880
addappid(386880)
addappid(386881, 1, "ef2960fc8b8be694ca008acbbfd801cb922cf4d0769b42a77c21b94735d7e048")
