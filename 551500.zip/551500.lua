-- Lua provided by RyzenAPI
-- Game: addappid(551500)

-- MAIN APPLICATION
addappid(551500)

-- MAIN APP DEPOTS / PACKAGES
addappid(551501, 1, "3ed97249f9b3b3ae8c22ccdb761ef175e1adf887dcab519af8449375d7705ddc")
