-- Lua provided by RyzenAPI
-- Game: Hello Love: 18 Again

-- MAIN APPLICATION
addappid(3167180)
-- Game: addappid(3167180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167181, 1, "f61ad6c1640cf36271016dc035341874c16ab54aabaca29279cfc49f05b68741")
