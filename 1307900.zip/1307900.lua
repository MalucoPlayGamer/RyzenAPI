-- Lua provided by RyzenAPI
-- Game: Dark Sales

-- MAIN APPLICATION
addappid(1307900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307901, 1, "ae3d85061c7c788bc663672246e3b5fa840529b1605f0c551a277e98e01bd743")

