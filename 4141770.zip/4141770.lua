-- Lua provided by RyzenAPI
-- Game: Molili AI Friends: Your AI Desk Pal

-- MAIN APPLICATION
addappid(4141770)

