-- Lua provided by RyzenAPI
-- Game: 3069540

-- MAIN APPLICATION
addappid(3069540)
-- Game: addappid(3069540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069541, 1, "00e6e0e22052b16b1bb48f648bd54eee28f9c86a80e048bc6784953310e7be42")
