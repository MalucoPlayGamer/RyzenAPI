-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY

-- MAIN APPLICATION
addappid(1173770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173771, 1, "fab6556c5fd8ece93cfb03ab4998ea82fe6290d7991bf77e7073693eed4584cf")
addappid(1638280, 0, "85404e4cba508d1bed970ecdfe04c431a7889e1e20ce7e36d0f57cd98387c1b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
