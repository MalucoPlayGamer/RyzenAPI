-- Lua provided by RyzenAPI
-- Game: Game: FINAL FANTASY

-- MAIN APPLICATION
addappid(1173770)
-- Game: addappid(1173770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173771, 1, "fab6556c5fd8ece93cfb03ab4998ea82fe6290d7991bf77e7073693eed4584cf")
addappid(1638280, 0, "85404e4cba508d1bed970ecdfe04c431a7889e1e20ce7e36d0f57cd98387c1b5")
