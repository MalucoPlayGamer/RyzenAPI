-- Lua provided by RyzenAPI
-- Game: Horizon Walker

-- MAIN APPLICATION
addappid(3279780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279781,0,"5d0ff26265bc8400969a8f5dea7059b368663ce774f578849be1fcfc092836ec")

