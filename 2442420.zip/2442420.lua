-- Lua provided by SkyAPI 
-- Game: AppID 2442420
addappid(2442420)
addappid(2442421, 1, "9ac8c2434c2697d7315a3d3f83d8d578d28b21c8b69d7d2f67376f8170a22bb6")
