-- Lua provided by RyzenAPI
-- Game: Game: Screeps: Arena Demo

-- MAIN APPLICATION
addappid(1658320)
-- Game: addappid(1658320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658321, 1, "bdeddf543fd07f05f65901b088c50d6681f686c104f08dac2865d5d4d1c94a4e")
addappid(1658324, 1, "95b7e990b8e557a8a3cf6d5f02bcad2eb9bcf9fcffcdf659fed3ff6a778e8249")
addappid(1658326, 1, "52b614a0391476efa27feda08eff19c773aa2f71425d61ab28197c4890352cd0")
addappid(1658327, 1, "3f640d3f2107d936919a0f917460530568355f3f2154ef3062087dbeba2c5884")
