-- Lua provided by RyzenAPI
-- Game: Game: AppID 3489720

-- MAIN APPLICATION
addappid(3489720)
-- Game: addappid(3489720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489721, 1, "ddfff11d1b7b66a2b49cf70b5a5f78b74c9ab08415ac999ab01c3de6ee7d90d8")
