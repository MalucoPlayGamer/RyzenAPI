-- Lua provided by RyzenAPI
-- Game: Eris Dysnomia

-- MAIN APPLICATION
addappid(2377420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377421, 1, "155a79c4760e89f9034391a71b4ac853dc74e5b22511d92c530bff3670b40b7b")
addappid(2377422, 1, "abc045a6c8bd34aa13a191eb17f8d0a49bef1ced5e1195403045fbd8a43a0a5f")
addappid(2377423, 1, "7d01faf87eb42e696f5af2e205e2fca5b90b77d8eb6852330544de063cf03549")

