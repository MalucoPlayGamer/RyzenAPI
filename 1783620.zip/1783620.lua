-- Lua provided by RyzenAPI
-- Game: Tales of Morrow

-- MAIN APPLICATION
addappid(1783620)
-- Game: addappid(1783620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783621, 1, "4e9cd6be83a65b4a15a1c5e80db75e87d8a34ce10bff37d24f52ee804625db97")
