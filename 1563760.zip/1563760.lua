-- Lua provided by RyzenAPI
-- Game: Monster Girl Dungeon

-- MAIN APPLICATION
addappid(1563760)
-- Game: addappid(1563760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563761, 1, "8ea0f1929f6158d13f8d6f2417dfb2d12cee54fd5ee1205e15fcd8d5aa0acc12")
