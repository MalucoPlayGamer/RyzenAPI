-- Lua provided by RyzenAPI
-- Game: Madorica Real Estate 2 - The mystery of the new property -

-- MAIN APPLICATION
addappid(2253730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253731, 1, "05b1b26b10ef6980862f01c22b5b2de0b3b00e2a9f61e853164486108f99a553")

