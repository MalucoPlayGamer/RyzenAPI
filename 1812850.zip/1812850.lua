-- Lua provided by RyzenAPI
-- Game: Game: Race for Your Life

-- MAIN APPLICATION
addappid(1812850)
-- Game: addappid(1812850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812851, 1, "e1b7b69a21ce9ae72dca89d847dbf26dd5d35f4b38bdf8f55d986775fb6f5f2f")
