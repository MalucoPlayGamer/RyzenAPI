-- Lua provided by RyzenAPI
-- Game: Uberich: Advent Sinners Soundtrack

-- MAIN APPLICATION
addappid(2805540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805541, 1, "34e6fe293667cf871b7ac2ab2caf3bf0446865427f3287d5c59c9f6e2f383e9c")
addappid(2805542, 1, "aef0d5e35bb098d99f397d490e9f61d52cf6709a6c8a263da3a42bd4183cd6f6")

