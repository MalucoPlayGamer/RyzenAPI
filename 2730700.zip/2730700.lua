-- Lua provided by RyzenAPI
-- Game: addappid(2730700)

-- MAIN APPLICATION
addappid(2730700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730701, 1, "dba98ceae0220e43e02479a21fe2843be7d4adda5694f3bd8466c96a44b5851c")
