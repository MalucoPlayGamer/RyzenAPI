-- Lua provided by RyzenAPI
-- Game: Hauntii - Digital Art Collection

-- MAIN APPLICATION
addappid(2994470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994470,0,"29d05d91834e237b1dbdac873964a37b98f5f54a9547119d69d3f01b78175970")
