-- Lua provided by RyzenAPI
-- Game: Drew and the Floating Labyrinth

-- MAIN APPLICATION
addappid(346200)

-- MAIN APP DEPOTS / PACKAGES
addappid(346201, 1, "f1a35c27c43620d62e8ff90f9a794ba51e49f73b9ede5d0064674dde474ba421")
addappid(346202, 1, "1e6bc413bd9019c053a4868118bd206221edfa4c792dd4b7848569df5519c65b")
addappid(346203, 1, "b1b47ba1b66bb176178e3c5d6a8413dc4f2a6eb4ebe833a3ef23ebd42ed96b76")
addappid(346204, 1, "3f8b6da567f4b962125de397d14731441db303c06318bc7543f18ea88d1cc0a7")

