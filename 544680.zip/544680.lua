-- Lua provided by RyzenAPI 
-- Game: AppID 544680
addappid(544680)
addappid(544681, 1, "4a19defb6780539a9607b5e0586bba279c5a4a6aef86cfb76529e0866013d896")
