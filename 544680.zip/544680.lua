-- Lua provided by RyzenAPI
-- Game: addappid(544680)

-- MAIN APPLICATION
addappid(544680)

-- MAIN APP DEPOTS / PACKAGES
addappid(544681, 1, "4a19defb6780539a9607b5e0586bba279c5a4a6aef86cfb76529e0866013d896")
