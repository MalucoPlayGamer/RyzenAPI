-- Lua provided by RyzenAPI
-- Game: Holy Avenger

-- MAIN APPLICATION
addappid(544680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(544681, 1, "4a19defb6780539a9607b5e0586bba279c5a4a6aef86cfb76529e0866013d896")

