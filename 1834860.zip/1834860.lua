-- Lua provided by RyzenAPI
-- Game: LSPLibrary

-- MAIN APPLICATION
addappid(1834860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1834861, 1, "e10ba5b603ffc081391bc95cdbd86613bcda127b0b754732c8a61a66a40f36d6")
