-- Lua provided by RyzenAPI
-- Game: AppID 1928420

-- MAIN APPLICATION
addappid(1928420)
-- Game: addappid(1928420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928421, 1, "1b831225fde5b44f7f354180183f732b4feb59c016faa3362e792bf9d455b294")
