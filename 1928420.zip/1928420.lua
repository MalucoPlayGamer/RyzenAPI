-- Lua provided by SkyAPI 
-- Game: AppID 1928420
addappid(1928420)
addappid(1928421, 1, "1b831225fde5b44f7f354180183f732b4feb59c016faa3362e792bf9d455b294")
