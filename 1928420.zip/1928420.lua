-- Lua provided by RyzenAPI
-- Game: Farlight 84

-- MAIN APPLICATION
addappid(1928420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1928421, 1, "1b831225fde5b44f7f354180183f732b4feb59c016faa3362e792bf9d455b294")

