-- Lua provided by RyzenAPI
-- Game: Saurian

-- MAIN APPLICATION
addappid(587450)

-- MAIN APP DEPOTS / PACKAGES
addappid(587451, 1, "4204f5a4b409e244dabdafc59f2a1a2671f7192543d3a9935ad138a08e54a313")
addappid(723530, 0, "8414f85d1492cbf2858ed6f2795cde290c50aa8857cbd46ef12f13a4a0e1bcec")
addappid(869530, 0, "b81a254a9c4361894604f0b2879f88f5fc93443d1f89786aa7e0969270f3ffda")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
