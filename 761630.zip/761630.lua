-- Lua provided by RyzenAPI
-- Game: akda

-- MAIN APPLICATION
addappid(761630)

-- MAIN APP DEPOTS / PACKAGES
addappid(761631, 1, "d7d50b9f964363f35205698bb1bb2e19d6fc0beb3f49f79b4808f598dba79c3d")

