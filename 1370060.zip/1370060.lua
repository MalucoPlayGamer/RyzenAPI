-- Lua provided by RyzenAPI
-- Game: 1370060

-- MAIN APPLICATION
addappid(228988)
addappid(229007)
addappid(229033)
addappid(1370060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370062,0,"539b4f854b4dd94258fdd108f5aaf94510ea799bc20fff94017a127d5d8f3651")

