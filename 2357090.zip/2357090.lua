-- Lua provided by RyzenAPI 
-- Game: Vampire Girls
addappid(2357090)
addappid(2357091, 1, "76fb12b620510bffb633a25801eb379cc3049972ecf5d2e5cc6ca198e41acbce")
