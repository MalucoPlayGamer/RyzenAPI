-- Lua provided by RyzenAPI
-- Game: Hiro's Forest Rumble

-- MAIN APPLICATION
addappid(780430)

-- MAIN APP DEPOTS / PACKAGES
addappid(780431,0,"bedda5a27c9316294fcaa19e2b0177ac3799c94e9858f44fc53497bcbce52e99")

