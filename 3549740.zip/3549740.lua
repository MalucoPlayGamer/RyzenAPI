-- Lua provided by RyzenAPI
-- Game: The Last Camp

-- MAIN APPLICATION
addappid(3549740)
-- Game: addappid(3549740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549741, 1, "75eac657eeaa2b5c4008b2c3e6f0d29c86be54a6407ff597ca40f068eac5a751")
