-- Lua provided by SkyAPI 
-- Game: The Last Camp
addappid(3549740)
addappid(3549741, 1, "75eac657eeaa2b5c4008b2c3e6f0d29c86be54a6407ff597ca40f068eac5a751")
