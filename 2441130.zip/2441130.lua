-- Lua provided by RyzenAPI
-- Game: Game: AppID 2441130

-- MAIN APPLICATION
addappid(2441130)
-- Game: addappid(2441130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441131, 1, "685db7cfb1380313a2c419b7c777f2494aacf172c9a14e27f28215bb55de68a4")
