-- Lua provided by RyzenAPI 
-- Game: AppID 1755990
addappid(1755990)
addappid(1755991, 1, "292e29602a83823d9fed7eae38d8272840d7432b1506dc3146c33853881bcda1")
