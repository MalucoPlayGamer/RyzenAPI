-- Lua provided by RyzenAPI
-- Game: Try to Catch Up

-- MAIN APPLICATION
addappid(1755990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755991, 1, "292e29602a83823d9fed7eae38d8272840d7432b1506dc3146c33853881bcda1")

