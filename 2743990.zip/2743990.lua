-- Lua provided by RyzenAPI
-- Game: Human Farm - Practice Section Demo

-- MAIN APPLICATION
addappid(2743990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743992,0,"71686f3b71321cb63d5f82a396de065a89e4b571ecf93deb5f3692432825f8d2")
addappid(2743993,0,"aaf623d483e38e64b3c66e25a0e1dae90b270a8c280139f1973c8912f35fe2e8")
