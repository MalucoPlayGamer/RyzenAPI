-- Lua provided by RyzenAPI 
-- Game: AppID 1082710
addappid(1082710)
addappid(1082711, 1, "590f22813370768897e18746d4e0c8f7bbe2e99c6cc5f984af4e725eb0d648de")
addappid(1082712, 1, "39168722c7307cc0d90bbeb7d4e22fe91515b7ce44e412bfa5f143f75346ae63")
