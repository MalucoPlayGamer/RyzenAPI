-- Lua provided by RyzenAPI
-- Game: AppID 37230

-- MAIN APPLICATION
addappid(37230)
-- Game: addappid(37230)

-- MAIN APP DEPOTS / PACKAGES
addappid(37231, 1, "6fdd51e76af04e5b495ac233d5b40fcca512a5f0618b47e9f5617a5c76b729b4")
