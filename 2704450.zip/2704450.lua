-- Lua provided by RyzenAPI
-- Game: Stoneguard

-- MAIN APPLICATION
addappid(2704450) -- Stoneguard

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2704452, 1, "aa279f8ca39217c86b48764c973394e1dc7823c3b87df8232bddb6a58fca1496") -- Depot 2704452

