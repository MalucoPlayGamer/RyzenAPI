-- 2704450's Lua and Manifest Created by Hubcap Manifest
-- Stoneguard
-- Created: August 01, 2026 at 00:00:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2704450) -- Stoneguard
-- MAIN APP DEPOTS
addappid(2704452, 1, "aa279f8ca39217c86b48764c973394e1dc7823c3b87df8232bddb6a58fca1496") -- Depot 2704452
setManifestid(2704452, "3623227154327250586", 7062132153)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)