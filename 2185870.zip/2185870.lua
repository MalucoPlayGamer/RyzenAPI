-- Lua provided by RyzenAPI
-- Game: Richman 8

-- MAIN APPLICATION
addappid(2185870)
-- Game: addappid(2185870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185871, 1, "1386251fd29e41eebc8e8849fc570f2f3bfb9698b15a9f96727ebf92b5d334e8")
addappid(2185872, 1, "d49ea0f474e1ff461799960c76a2f53da652c5e8e75aaa2b13d9fdae2b81aab6")
