-- Lua provided by RyzenAPI
-- Game: RebellionGODSOUL-FreeWallpapers

-- MAIN APPLICATION
addappid(3573850)
-- Game: addappid(3573850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573850,0,"e02ec17f12b7b2ee078f9a9d3ae34992510b1920887480f46be5d3d2e6873212")
