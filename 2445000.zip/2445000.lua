-- Lua provided by RyzenAPI
-- Game: Gunforged Demo

-- MAIN APPLICATION
addappid(2445000)
-- Game: addappid(2445000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445002,0,"e353a39718b8333281de1cd25f2a94178710628c9795b7ea41774f3da17e80bd")
