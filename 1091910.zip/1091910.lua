-- Lua provided by RyzenAPI
-- Game: 1091910

-- MAIN APPLICATION
addappid(1091910)
-- Game: addappid(1091910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091911, 1, "0b08f377fcd75d75aa9dcda74a243a6548be16b92228cbe6a2fc4963d1dbd0d0")
