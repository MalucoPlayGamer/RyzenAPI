-- Lua provided by RyzenAPI
-- Game: Five Day Great Escape 五日大逃亡

-- MAIN APPLICATION
addappid(994290)

-- MAIN APP DEPOTS / PACKAGES
addappid(994291, 1, "893d9077e920464bf38eb97946d1e43c15df2d5bd692c77b158745827fcb4cc1")
