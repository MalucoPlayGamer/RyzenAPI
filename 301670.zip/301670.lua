-- Lua provided by RyzenAPI
-- Game: Salammbô: Battle for Carthage

-- MAIN APPLICATION
addappid(301670)
-- Game: addappid(301670)

-- MAIN APP DEPOTS / PACKAGES
addappid(301671, 1, "581e0d2c462362f5fa40f80b9d186435ad3ed6ecb0ecfc936a0105fb73fce973")
addappid(301672, 1, "9775228d7f037b35b1f5b12a1b7787d16b7d46d2d66eb8f882c62d3faa2dd9e5")
addappid(301673, 1, "ba6382a3d97381883634395ceb33bd02e9592d7c7f3f1c66b0f608bb2d4f71f3")
addappid(301674, 1, "2e614418ea73b69d44c6b44dbfd2bd9a7dd098747e104c5ca9c57164c658688a")
addappid(301675, 1, "afe9660940f2885592c70db0a6e74d94a6b810f0b8543bcf27b99aaf7cda70ec")
addappid(301676, 1, "d523942002c5c17063858aadf0d8e8ee72621afb182e5604713d4df9b53afcf9")
