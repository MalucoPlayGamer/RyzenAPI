-- Lua provided by RyzenAPI
-- Game: Glitch Hearts

-- MAIN APPLICATION
addappid(3932620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3932621,0,"86f8bafe854e2a042a8222ef4baa016fa7afa9addbf98135562f22bb32da5c1c")

