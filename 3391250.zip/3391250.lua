-- Lua provided by SkyAPI 
-- Game: Echoes of the Architects Demo
addappid(3391250)
addappid(3391251, 1, "e76707347612e0d4509e06948b633f37f6c5b2b2e0f4d80c8542fc55d9cc33e1")
