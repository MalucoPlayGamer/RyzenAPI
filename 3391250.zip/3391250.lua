-- Lua provided by RyzenAPI
-- Game: Echoes of the Architects Demo

-- MAIN APPLICATION
addappid(3391250)
-- Game: addappid(3391250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391251, 1, "e76707347612e0d4509e06948b633f37f6c5b2b2e0f4d80c8542fc55d9cc33e1")
