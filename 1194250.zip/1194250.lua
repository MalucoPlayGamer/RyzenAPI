-- Lua provided by RyzenAPI
-- Game: Screaming Chicken: Ultimate Showdown

-- MAIN APPLICATION
addappid(1194250)
-- Game: addappid(1194250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194251, 1, "32a8263cdb6376ab7f4bd3958455503a35e0b40d5598867bad12e29f9ec602a9")
