-- Lua provided by RyzenAPI
-- Game: Divine Orders

-- MAIN APPLICATION
addappid(3263480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263481, 1, "4e70667795fe15b56387ac9b4ce4984f75ba893db9d07b9a199fafcf9e6b8ed7")
