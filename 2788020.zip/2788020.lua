-- Lua provided by RyzenAPI
-- Game: Mendacium Demo

-- MAIN APPLICATION
addappid(2788020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788021, 1, "a6a86f75d1cd4f58ed9f143641710b624176e8cf4377637f1c3a481940f270ab")

