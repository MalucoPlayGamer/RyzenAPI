-- Lua provided by RyzenAPI
-- Game: Game: Barnyard Mahjong 3

-- MAIN APPLICATION
addappid(498030)
-- Game: addappid(498030)

-- MAIN APP DEPOTS / PACKAGES
addappid(498031, 1, "e60352760050ce57b23fcb783ebede056f4727bb3b5a885c3870496eec1d7c2b")
