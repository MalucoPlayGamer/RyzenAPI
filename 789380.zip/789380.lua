-- Lua provided by RyzenAPI
-- Game: Sometimes to Deal with the Difficulty of Being Alive, I Need to Believe There Is a Possibility That Life Is Not Real.

-- MAIN APPLICATION
addappid(789380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(789381, 1, "a4e302f93dcfbe6e477fa4f0db7edd9ab846d0e5df4585bbad234396986b33af")
