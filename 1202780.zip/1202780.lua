-- Lua provided by RyzenAPI
-- Game: Game: Theme Park Simulator: Rollercoaster Paradise

-- MAIN APPLICATION
addappid(1202780)
-- Game: addappid(1202780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202781, 1, "1df2a406a5348dc811e991067b17207dd19b0ac760623d7bd62e28b8a5e99407")
