-- Lua provided by RyzenAPI
-- Game: The Abyss Within

-- MAIN APPLICATION
addappid(2428020)
-- Game: addappid(2428020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428021, 1, "159d0d8fe50edc43cb4f8076ced6ede0f1ac43f494b3c76ccc94acac834d50d7")
