-- Lua provided by RyzenAPI
-- Game: Live Adventure

-- MAIN APPLICATION
addappid(1798210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798211, 1, "5d2977774c11ffa08d9586425629123559776b7908c1306a3edd23f18460614d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
