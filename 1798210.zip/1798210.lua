-- Lua provided by RyzenAPI
-- Game: Game: Live Adventure

-- MAIN APPLICATION
addappid(1798210)
-- Game: addappid(1798210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798211, 1, "5d2977774c11ffa08d9586425629123559776b7908c1306a3edd23f18460614d")
