-- Lua provided by RyzenAPI
-- Game: いるかにうろこがないわけ

-- MAIN APPLICATION
addappid(2632800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2632801, 1, "ac03c7728f60e6e702ea9727659cd39402d76872cc9d201421d1b385102bae50")

