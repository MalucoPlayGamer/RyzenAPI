-- Lua provided by RyzenAPI
-- Game: Cattails | Become a Cat!

-- MAIN APPLICATION
addappid(228990)
addappid(634160)
addappid(634161)
addappid(634163)
addappid(634164)
addappid(661141)
addappid(661142)

-- MAIN APP DEPOTS / PACKAGES
addappid(634162,0,"6d290fef38aafc6ff2d16c5846e45bbae99bf4792a3bf3c8dfc537d66030d962")

