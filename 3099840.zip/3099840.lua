-- Lua provided by RyzenAPI
-- Game: Kimi to Kanojo no LILYVAGANZA

-- MAIN APPLICATION
addappid(3099840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099842,0,"f1691229ddb3f95e7d36076e1023f33bdb765fd78188584c9c4acb7858d3c121")
addappid(3099843,0,"2bb47c8070a51626ae4edd41676825554b64e0232623ac512d5b11417ee7670b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4308010)
