-- Lua provided by RyzenAPI
-- Game: Game: Moving Houses

-- MAIN APPLICATION
addappid(2831060)
-- Game: addappid(2831060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831061, 1, "382e35fff8fa2b38503adc017848e7414e77dcf49d1a7ebf68ecf6b05ec86021")
