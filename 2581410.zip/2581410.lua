-- Lua provided by RyzenAPI
-- Game: Stygian: Outer Gods

-- MAIN APPLICATION
addappid(2581410)
addappid(4060460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2581411, 1, "c292424b75aecd8237120c73ae7e1bb635c2bb72c29ebcd4d7c1ad126f6a1f2c")

