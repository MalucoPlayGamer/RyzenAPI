-- Lua provided by RyzenAPI
-- Game: addappid(2581410)

-- MAIN APPLICATION
addappid(2581410)
addappid(4060460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581411, 1, "c292424b75aecd8237120c73ae7e1bb635c2bb72c29ebcd4d7c1ad126f6a1f2c")
