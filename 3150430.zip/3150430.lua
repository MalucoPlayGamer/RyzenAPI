-- Lua provided by RyzenAPI
-- Game: Haddie's Pizzeria Playtest

-- MAIN APPLICATION
addappid(3150430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150431, 1, "aa2a146964300bfe225f368a15035e2deb69a2033589dcff053c5ec02a5288e6")

