-- Lua provided by RyzenAPI
-- Game: 594370

-- MAIN APPLICATION
addappid(594370)
-- Game: addappid(594370)

-- MAIN APP DEPOTS / PACKAGES
addappid(594371, 1, "aaddaab486effbcc7af177f14440b5dd24eda08496512247f8ceaa2b44db8ef0")
