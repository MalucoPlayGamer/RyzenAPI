-- Lua provided by RyzenAPI
-- Game: Little fight

-- MAIN APPLICATION
addappid(777620)

-- MAIN APP DEPOTS / PACKAGES
addappid(777621,0,"10a2b205c9645c8c81620d66645fffc2eadc90ee3699490d1001c3c04913f0a3")

