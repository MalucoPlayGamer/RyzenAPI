-- Lua provided by RyzenAPI
-- Game: 1229500

-- MAIN APPLICATION
addappid(1229500)
-- Game: addappid(1229500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229501, 1, "dee85272e99e0414e6e060d816918367f22734b0a6fcc753d5f20d4fe63b06d9")
