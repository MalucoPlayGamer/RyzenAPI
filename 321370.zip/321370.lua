-- Lua provided by RyzenAPI
-- Game: Sign Motion

-- MAIN APPLICATION
addappid(321370)

-- MAIN APP DEPOTS / PACKAGES
addappid(321371, 1, "6a27b4129e535cdd5a7db05eaf7fcc4f17ef5fad0c95e4d53a1878a0adb18e3f")

