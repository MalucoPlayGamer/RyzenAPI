-- Lua provided by RyzenAPI
-- Game: Warriors & Castles

-- MAIN APPLICATION
addappid(372380)
-- Game: addappid(372380)

-- MAIN APP DEPOTS / PACKAGES
addappid(372381, 1, "ba6ab4f45188fd4f6209912d1bfab3fe82123257f2c6deef06ba10286a8ba1ea")
addappid(372382, 1, "d77eb509535e91ca8ed3a23a3a7de0aaed3b09c580257d773d120072e6c451e0")
addappid(372383, 1, "a949e47c36d343b35b77f4779516260d8f9b4132e6f594b96257ec18ee0db3cb")
