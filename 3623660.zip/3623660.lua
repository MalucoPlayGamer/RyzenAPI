-- Lua provided by RyzenAPI
-- Game: addappid(3623660)

-- MAIN APPLICATION
addappid(3623660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3623661, 1, "719686efd02e3fc92cdfb5771e7da7922ef0ae21d26275a48e97f239a1a58956")
