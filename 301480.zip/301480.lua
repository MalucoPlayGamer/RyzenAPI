-- Lua provided by RyzenAPI
-- Game: addappid(301480)

-- MAIN APPLICATION
addappid(301480)

-- MAIN APP DEPOTS / PACKAGES
addappid(301481, 1, "d061416744aa7356cde4abd1ecb81a2b50b34dbcd4e92a1cbdf54a015c7c1ba7")
