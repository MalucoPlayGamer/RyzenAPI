-- Lua provided by RyzenAPI
-- Game: GEARCRACK Arena

-- MAIN APPLICATION
addappid(301480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(301481, 1, "d061416744aa7356cde4abd1ecb81a2b50b34dbcd4e92a1cbdf54a015c7c1ba7")
