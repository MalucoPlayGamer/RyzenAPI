-- Lua provided by RyzenAPI
-- Game: Dark Deception

-- MAIN APPLICATION
addappid(332950)
addappid(1017030)
addappid(1019930)
addappid(1019931)
addappid(1019932)
addappid(1022850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(332951, 1, "6a39198ed2507581c09af1361425691fc64d1fd13d251b5b951e011d2dbaf3cd")

