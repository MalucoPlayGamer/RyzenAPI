-- Lua provided by RyzenAPI
-- Game: Dark Deception

-- MAIN APPLICATION
addappid(332950)

-- MAIN APP DEPOTS / PACKAGES
addappid(332951, 1, "6a39198ed2507581c09af1361425691fc64d1fd13d251b5b951e011d2dbaf3cd")
