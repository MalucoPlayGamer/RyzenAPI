-- Lua provided by RyzenAPI
-- Game: addappid(2293820)

-- MAIN APPLICATION
addappid(2293820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293821, 1, "b6fcaf2066c7d3191de1fcb679ca2de6a6a8dc126109787f44e6968a83789411")
