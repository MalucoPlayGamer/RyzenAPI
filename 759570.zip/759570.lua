-- Lua provided by RyzenAPI
-- Game: Decay of Logos

-- MAIN APPLICATION
addappid(759570)
-- Game: addappid(759570)

-- MAIN APP DEPOTS / PACKAGES
addappid(759571, 1, "922a90beaab8eab1a1f74dda5be37b7d95acdca3f2f0b5c6baf516927492d4ad")
