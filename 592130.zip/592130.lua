-- Lua provided by RyzenAPI
-- Game: NakedMan VS The Clothes

-- MAIN APPLICATION
addappid(592130)

-- MAIN APP DEPOTS / PACKAGES
addappid(592131, 1, "d992cfecdd3e2c94f5fe40f536460ac09cfc3ac28844b42e4bf03af720bca00a")
