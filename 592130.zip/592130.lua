-- Lua provided by RyzenAPI
-- Game: NakedMan VS The Clothes

-- MAIN APPLICATION
addappid(592130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(592131, 1, "d992cfecdd3e2c94f5fe40f536460ac09cfc3ac28844b42e4bf03af720bca00a")

