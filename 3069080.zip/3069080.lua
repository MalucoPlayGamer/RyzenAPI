-- Lua provided by RyzenAPI
-- Game: Plungeez

-- MAIN APP DEPOTS / PACKAGES
addappid(3069080, 1, "7b993e141af8c85a2d6b2175ea2f6cb37654934217282df09dd3bc034f358a62") -- Plungeez
addappid(3069081, 1, "1507601b86806218bbfec30809e4b99460fa20a0aef9422e8635776069fa7ea1") -- Depot 3069081

