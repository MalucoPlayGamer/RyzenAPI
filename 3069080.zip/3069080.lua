-- 3069080's Lua and Manifest Created by Hubcap Manifest
-- Plungeez
-- Created: August 27, 2026 at 13:29:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3069080, 1, "7b993e141af8c85a2d6b2175ea2f6cb37654934217282df09dd3bc034f358a62") -- Plungeez
-- MAIN APP DEPOTS
addappid(3069081, 1, "1507601b86806218bbfec30809e4b99460fa20a0aef9422e8635776069fa7ea1") -- Depot 3069081
setManifestid(3069081, "3904698675424047210", 463136517)