-- Lua provided by RyzenAPI
-- Game: Model Railway Easily Christmas

-- MAIN APPLICATION
addappid(926420)

-- MAIN APP DEPOTS / PACKAGES
addappid(926421, 1, "54412a0f326185ec4f99bb07e5022213047dc0d6cdbe4901570ea74037c20e62")

