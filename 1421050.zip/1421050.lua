-- Lua provided by RyzenAPI
-- Game: Kingdom Rush Vengeance Demo

-- MAIN APPLICATION
addappid(228984)
addappid(228985)
addappid(228988)
addappid(1421050)
addappid(1421051)
addappid(1421053)
-- Game: addappid(1421050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421052,0,"77c9a9adc7f49398bf6c51a5dde01007af41b44b313d9efc1dad3a9e7d41f264")
