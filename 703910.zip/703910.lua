-- Lua provided by RyzenAPI
-- Game: VRpatients

-- MAIN APPLICATION
addappid(703910)

-- MAIN APP DEPOTS / PACKAGES
addappid(703911, 1, "fb5d0fffff19a1d0c304f1d82ca67a5d9a4cdd53bf5c5a45fc0b4feae65beb85")
