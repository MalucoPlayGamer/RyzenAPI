-- Lua provided by SkyAPI 
-- Game: Sexy Mystic Survivors
addappid(1964360)
addappid(1964361, 1, "a7c59e735e6850c357c118ec4571233d0880dacc4f6c9a07896ca67f9547e3a9")
