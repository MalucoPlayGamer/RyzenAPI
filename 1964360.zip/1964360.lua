-- Lua provided by RyzenAPI
-- Game: addappid(1964360)

-- MAIN APPLICATION
addappid(1964360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964361, 1, "a7c59e735e6850c357c118ec4571233d0880dacc4f6c9a07896ca67f9547e3a9")
