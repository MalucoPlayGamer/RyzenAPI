-- Lua provided by RyzenAPI
-- Game: Mars Survivors

-- MAIN APPLICATION
addappid(2448270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448271, 1, "954fe1699718b3ab7e75c0779872ef5591e452e8f6a3e2af0c2f3e1517160a30")

