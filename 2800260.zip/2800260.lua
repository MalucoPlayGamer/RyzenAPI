-- Lua provided by RyzenAPI
-- Game: 2800260

-- MAIN APPLICATION
addappid(2800260)
-- Game: addappid(2800260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800261, 1, "e08aee8f951a1fe650c3b6c2ae73ef0925e3adc5ccdc716c759ff374dd952c45")
