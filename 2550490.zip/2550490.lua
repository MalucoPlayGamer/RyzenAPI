-- Lua provided by RyzenAPI 
-- Game: AppID 2550490
addappid(2550490)
addappid(2550491, 1, "b96ee96f4b146ef6120558a559a50ef92c6de3978693c7c4fa0bb6d5688b669a")
addappid(2550492, 1, "b8eaa2f630f17edcb07b85d2c9bf83d8b8e300effeb699bcf1fd3906b26f3583")
