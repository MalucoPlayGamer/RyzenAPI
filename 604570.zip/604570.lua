-- Lua provided by RyzenAPI
-- Game: Universe in Fire

-- MAIN APPLICATION
addappid(604570)

-- MAIN APP DEPOTS / PACKAGES
addappid(604571, 1, "d944f8d11522f84bd054f3dad21b728ea3616f796f241a1e840c8c9bb65ba5da")

