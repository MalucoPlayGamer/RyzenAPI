-- Lua provided by RyzenAPI
-- Game: Game: MyDockFinder

-- MAIN APPLICATION
addappid(1787090)
-- Game: addappid(1787090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787091, 1, "89e81a11a8a9323dc60060cb60eb73aea9b74b25d1c2a40f1bc86e5c67339b06")
