-- Lua provided by RyzenAPI
-- Game: MyDockFinder

-- MAIN APPLICATION
addappid(1787090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787091, 1, "89e81a11a8a9323dc60060cb60eb73aea9b74b25d1c2a40f1bc86e5c67339b06")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
