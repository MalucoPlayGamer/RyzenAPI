-- Lua provided by SkyAPI 
-- Game: MyDockFinder
addappid(1787090)
addappid(1787091, 1, "89e81a11a8a9323dc60060cb60eb73aea9b74b25d1c2a40f1bc86e5c67339b06")
