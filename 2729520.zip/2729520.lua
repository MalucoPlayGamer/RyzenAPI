-- Lua provided by RyzenAPI
-- Game: addappid(2729520)

-- MAIN APPLICATION
addappid(2729520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729521, 1, "2a0b8d80a84d10516798fe5188ada236bf960aec33ef7145d85c29affd570717")
