-- Lua provided by RyzenAPI
-- Game: Burly Men at Sea

-- MAIN APPLICATION
addappid(403290)

-- MAIN APP DEPOTS / PACKAGES
addappid(403293,0,"940b464b2b79526b3e2c3116c48979456c7c5b3687ed2e983677e82226778cda")

