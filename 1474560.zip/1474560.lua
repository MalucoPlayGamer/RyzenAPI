-- Lua provided by RyzenAPI
-- Game: 圣三国英杰传 Demo

-- MAIN APPLICATION
addappid(1474560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474561, 1, "0db0419996cac9f7dc75f53e5d6b1742775d82705de3ea9297087dbf28850801")
