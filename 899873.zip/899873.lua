-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(899873)
-- Game: addappid(899873)

-- MAIN APP DEPOTS / PACKAGES
addappid(899873,0,"0d1677f6a404ea55af64a4d508ed983c0302d76e0442db0d58a7f436b7346627")
