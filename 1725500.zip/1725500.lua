-- Lua provided by RyzenAPI
-- Game: Beat Saber: Skrillex – 'Bangarang (feat. Sirah)'

-- MAIN APPLICATION
addappid(1725500)
-- Game: addappid(1725500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725500,0,"fd521668f7ccc759dd6955305fdf44c5cd3b759bae3823a4e6e09951390ea356")
