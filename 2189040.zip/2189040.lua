-- Lua provided by RyzenAPI
-- Game: Mean Beans

-- MAIN APPLICATION
addappid(2189040)
addappid(2189130)
addappid(2189131)
addappid(2189132)
addappid(2481150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189041, 1, "93795dfd18e44aabbb92b73dd4860188b23d4520d623c5ce975b84d028da65db")

