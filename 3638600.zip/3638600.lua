-- Lua provided by RyzenAPI
-- Game: Dear Mirror Flower Soundtrack

-- MAIN APPLICATION
addappid(3638600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3638601, 1, "44563df113f158dff4789cfb883a1cfd04bfbeaab95e135035b086de05d0ef65")
