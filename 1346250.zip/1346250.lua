-- Lua provided by RyzenAPI
-- Game: Slide Stories: Neko's Journey

-- MAIN APPLICATION
addappid(1346250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346251, 1, "d687da9f93e10f68bbcdcc59a2a1be81a109aac3f7599dd8177b56c14fe736e7")
addappid(1346252, 1, "61872259ffce3138491293454e8f3be9b17c58f027d0e84f9a3af38f0bb6b792")

