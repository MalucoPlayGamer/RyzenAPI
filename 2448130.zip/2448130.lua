-- Lua provided by RyzenAPI
-- Game: Sex on Beach

-- MAIN APPLICATION
addappid(2448130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448131, 1, "a6c5a9828bff6a81dc6ecb02985d9b37af9cac5685861d8a06484fbbfe1095f0")
