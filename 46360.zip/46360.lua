-- Lua provided by RyzenAPI
-- Game: Game: Theatre of War 2: Kursk 1943

-- MAIN APPLICATION
addappid(46360)
-- Game: addappid(46360)

-- MAIN APP DEPOTS / PACKAGES
addappid(46361, 1, "f2d9148dd15422493606515abb619c202f8003b6a16558074414de240b07daf9")
addappid(46362, 0, "12a939067ae917ca301ad4e6b315f57293841e48d1da53ac70e06b60a139002d")
addappid(46363, 1, "77294e7291bc1a99ee7a3ecfb3759bc3ad23817c82cd01f24ada5d5ddb442baa")
addappid(46364, 1, "6cb2eeaf4172540daba53ec6a128d0224c0e34ca2aa521e4405d7cc942ba5144")
addappid(46365, 1, "145f0c23dd4e2b29ba2c97d4331e99e94528d78f3a37514bb45b1afd5f550d52")
addappid(46366, 1, "5e72c3073f13fd8a1d3403671b809ee40e03ab9d9fb7d51ee9aa91c9108838fd")
