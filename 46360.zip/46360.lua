-- Lua provided by RyzenAPI
-- Game: Theatre of War 2: Kursk 1943

-- MAIN APPLICATION
addappid(46360)

-- MAIN APP DEPOTS / PACKAGES
addappid(46361, 1, "f2d9148dd15422493606515abb619c202f8003b6a16558074414de240b07daf9")
addappid(46362, 0, "12a939067ae917ca301ad4e6b315f57293841e48d1da53ac70e06b60a139002d")
addappid(46363, 1, "77294e7291bc1a99ee7a3ecfb3759bc3ad23817c82cd01f24ada5d5ddb442baa")
addappid(46364, 1, "6cb2eeaf4172540daba53ec6a128d0224c0e34ca2aa521e4405d7cc942ba5144")
addappid(46365, 1, "145f0c23dd4e2b29ba2c97d4331e99e94528d78f3a37514bb45b1afd5f550d52")
addappid(46366, 1, "5e72c3073f13fd8a1d3403671b809ee40e03ab9d9fb7d51ee9aa91c9108838fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
