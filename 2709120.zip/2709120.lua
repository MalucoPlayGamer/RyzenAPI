-- Lua provided by RyzenAPI
-- Game: 2709120

-- MAIN APPLICATION
addappid(2709120)
-- Game: addappid(2709120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709121, 1, "a48423d534ce7da3fc796369f7aa1f6230df1a6bf0906e3e989fc8fe5b00b98f")
