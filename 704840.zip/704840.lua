-- Lua provided by RyzenAPI
-- Game: The Walking Vegetables

-- MAIN APPLICATION
addappid(704840)

-- MAIN APP DEPOTS / PACKAGES
addappid(704841, 1, "b9a35bbbd7028ba160c243e380b8f0a63ee9d5f1a3e8ec1af98d6dcdb209e7d9")
addappid(704842, 1, "27aa74e6e12c56a83ec4a8defbdf1dbe594b8f67afdf601db44bc45a80f3056d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
