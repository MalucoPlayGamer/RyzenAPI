-- Lua provided by SkyAPI 
-- Game: AppID 567600
addappid(567600)
addappid(567601, 1, "ee613754e658844710e67c44d5acaae4dd4d570cd4d281554952d01ed5526b98")
addappid(567602, 1, "ffa9e614a27a4df01da26ba57dcddcd44486eab36878086255659585614b89a4")
