-- Lua provided by RyzenAPI
-- Game: Game: HOPSHOT

-- MAIN APPLICATION
addappid(3495790)
-- Game: addappid(3495790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495791, 1, "461481d72859870b42ffc336f9cb75264399cb5aa5158ec805cd1538ca3f0a36")
