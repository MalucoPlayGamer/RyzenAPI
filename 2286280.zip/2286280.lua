-- Lua provided by RyzenAPI
-- Game: Game: AppID 2286280

-- MAIN APPLICATION
addappid(2286280)
-- Game: addappid(2286280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286281, 1, "be7c22e5c2976f70d1b46b0b1844919715354e24d17570834fb5034bbfc573b4")
