-- Lua provided by RyzenAPI
-- Game: Shop Simulator: Waifu Pillows

-- MAIN APPLICATION
addappid(3361340)
addappid(3774980)
-- Game: addappid(3361340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361341, 1, "ac30488150bd964f39cf92f944398a24b8076f784de66b44df299390b87645a8")
