-- Lua provided by RyzenAPI 
-- Game: World Empire 2027
addappid(1873540)
addappid(1873541, 1, "40a1a05eab917d811b0fc998ed0a832ab7749c684f9313ba412e430d5536d8b3")
