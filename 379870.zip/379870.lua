-- Lua provided by RyzenAPI
-- Game: Alteil: Horizons

-- MAIN APPLICATION
addappid(379870)
addappid(543690)
addappid(543691)
addappid(543692)
addappid(543693)
addappid(543700)
addappid(559390)
addappid(559391)
addappid(572370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(379871, 1, "614e594271e7171201a816c9506c72fb94c0e98726fbcb27405abe6bfbaff017")
addappid(379872, 1, "76a45f736d81f7270361e76a4142773082bb1a5edda7c02ad8756500874fd549")

