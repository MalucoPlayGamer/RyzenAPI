-- Lua provided by RyzenAPI
-- Game: YTGV Demo (progress transfers to full game)

-- MAIN APPLICATION
addappid(2072850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072851, 1, "b745410f8d2f97e7756a93d0e48fa867a2f0373f6ce6312e6d3ee3578a5e0e09")

