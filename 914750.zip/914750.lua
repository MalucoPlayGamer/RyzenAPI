-- Lua provided by RyzenAPI
-- Game: Bee Simulator

-- MAIN APPLICATION
addappid(914750)
addappid(3582180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(914751,0,"ed18dc86b4a15f06739cd86dce04634aaf0d6b18372a804b51fbdb0115b7d64a")
addappid(3582181,0,"e094c60fa58aacaf2bf2f09847b686c7960c0072b36b3662a740a42750ea476b")

