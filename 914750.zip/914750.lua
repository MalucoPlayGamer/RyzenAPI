-- Lua provided by RyzenAPI
-- Game: Bee Simulator

-- MAIN APPLICATION
addappid(914750)

-- MAIN APP DEPOTS / PACKAGES
addappid(914751,0,"ed18dc86b4a15f06739cd86dce04634aaf0d6b18372a804b51fbdb0115b7d64a")
addappid(3582181,0,"e094c60fa58aacaf2bf2f09847b686c7960c0072b36b3662a740a42750ea476b")

