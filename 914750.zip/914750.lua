-- Lua provided by RyzenAPI
-- Game: AppID 914750

-- MAIN APPLICATION
addappid(914750)

-- MAIN APP DEPOTS / PACKAGES
addappid(914751, 1, "ed18dc86b4a15f06739cd86dce04634aaf0d6b18372a804b51fbdb0115b7d64a")

