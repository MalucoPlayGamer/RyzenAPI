-- Lua provided by RyzenAPI
-- Game: Tavern Talk - Digital Pen & Paper Mini-Adventure

-- MAIN APPLICATION
addappid(3054560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054560,0,"5423a0984f61bc61d1ac1437b3770dcb11c87d0345e1381eeb611f98824926a4")

