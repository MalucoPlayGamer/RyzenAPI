-- Lua provided by RyzenAPI
-- Game: addappid(610050)

-- MAIN APPLICATION
addappid(610050)

-- MAIN APP DEPOTS / PACKAGES
addappid(610050,0,"8956256cdcec8d57efe54e712fbddf0b7c938da4053d26a93553cabbe3db2098")
