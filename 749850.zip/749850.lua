-- Lua provided by RyzenAPI
-- Game: DragonFangZ - The Rose & Dungeon of Time

-- MAIN APPLICATION
addappid(749850)
-- Game: addappid(749850)

-- MAIN APP DEPOTS / PACKAGES
addappid(749852,0,"5e37e9610b195ea0f462da1fd55740cc70e8cabb2dea3aa603c73c82e588ee63")
