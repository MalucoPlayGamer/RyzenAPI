-- Lua provided by RyzenAPI
-- Game: Superstar Racing

-- MAIN APPLICATION
addappid(1488380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488381, 1, "bd92591657369bbedfd67ee94c933838f24da76408dcc4eab350a1ac0d88d87a")
