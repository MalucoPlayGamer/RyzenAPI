-- Lua provided by RyzenAPI
-- Game: Hordes of Hunger

-- MAIN APPLICATION
addappid(2157710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2157711, 1, "aae1b54d52d987432e2554037a1c3b2176de82193e23ac6613b422c4bbc15775")

