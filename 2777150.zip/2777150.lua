-- Lua provided by RyzenAPI
-- Game: Penny’s Big Breakaway Demo

-- MAIN APPLICATION
addappid(2777150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777151, 1, "4ac7325df3bb5ea40c77058d97190a10658b513563554ea61455cfb7707530b2")
