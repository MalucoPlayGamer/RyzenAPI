-- Lua provided by RyzenAPI
-- Game: Theatre of Doom

-- MAIN APPLICATION
addappid(553020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(553021, 1, "5181cae9ba832b22b40ed7848cb503b4958147136f689d298924571743572a3e")

