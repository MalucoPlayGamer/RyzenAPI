-- Lua provided by RyzenAPI
-- Game: Game: AppID 3094110

-- MAIN APPLICATION
addappid(3094110)
-- Game: addappid(3094110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094111, 1, "32f1deb2d7f3e1b351ccf3eb906a40a2aff1cbfc94f296dea15f0d522a449a60")
