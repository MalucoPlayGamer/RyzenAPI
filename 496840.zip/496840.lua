-- Lua provided by SkyAPI 
-- Game: AppID 496840
addappid(496840)
addappid(496841, 1, "b4d866692d4c27a7dd27b8a91ebd1eb69a8e07b9375d201f38ccea5b35ea74b3")
