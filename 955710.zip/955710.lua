-- Lua provided by RyzenAPI
-- Game: 955710

-- MAIN APPLICATION
addappid(955710)
addappid(955711)
addappid(955712)

-- MAIN APP DEPOTS / PACKAGES
addappid(955710,0,"e5148b47e44ca3fcaa02b2649434fa62bed2c97b258abce270c13a211436ac72")
