-- Lua provided by RyzenAPI
-- Game: Femdom University 0

-- MAIN APPLICATION
addappid(2520590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520591, 1, "ee989ae0cf673b59d68a153a29683f53f06ddacdf914f655574a66450d85494e")

