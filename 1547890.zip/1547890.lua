-- Lua provided by RyzenAPI
-- Game: Let's Build a Zoo

-- MAIN APPLICATION
addappid(1547890)
addappid(1903410)
addappid(2380280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1547891, 1, "91f8d0ce53ab91c09189bbc774846c38a70c69bae5e5114c5d330767152bc5c2")

