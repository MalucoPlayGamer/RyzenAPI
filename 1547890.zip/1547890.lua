-- Lua provided by RyzenAPI
-- Game: Let's Build a Zoo

-- MAIN APPLICATION
addappid(1547890)
-- Game: addappid(1547890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547891, 1, "91f8d0ce53ab91c09189bbc774846c38a70c69bae5e5114c5d330767152bc5c2")
