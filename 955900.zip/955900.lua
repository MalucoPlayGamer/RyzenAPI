-- Lua provided by RyzenAPI
-- Game: AppID 955900

-- MAIN APPLICATION
addappid(955900)
-- Game: addappid(955900)

-- MAIN APP DEPOTS / PACKAGES
addappid(955901, 1, "7a3f5a92b6422af44c29c94bc4d54cb778ee157e58873e3e7b4e3fd4f25d3956")
addappid(955902, 1, "41dddf3f2fdc9cf3c5f99e7b96ca775a8ecb996de611c526fb3e6223a9aa6944")
addappid(1446730, 0, "df4bff2f0d54a794ba24b7faa60d334cc2abaf20d7ea625138d15a1bc6ac439d")
addappid(1701600, 0, "d358bbd50b412fd6ccd9a211041aaf9f0b8927f65d503c2026576162a2140dcc")
