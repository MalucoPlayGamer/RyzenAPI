-- Lua provided by RyzenAPI
-- Game: 517000

-- MAIN APPLICATION
addappid(517000)
-- Game: addappid(517000)

-- MAIN APP DEPOTS / PACKAGES
addappid(517001, 1, "34477bbb3c480e45bac79850e1a112d90bdd6339c40a4706c57d41aefad7d090")
