-- Lua provided by RyzenAPI
-- Game: SteamForge

-- MAIN APPLICATION
addappid(3439250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439251, 1, "85340a7e4b0dc78ee20c378d624e9e695d8d8c295bbac08a589e29ff285e6c39")

