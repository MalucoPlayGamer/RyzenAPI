-- Lua provided by RyzenAPI
-- Game: 833500

-- MAIN APPLICATION
addappid(833500)
-- Game: addappid(833500)

-- MAIN APP DEPOTS / PACKAGES
addappid(833501, 1, "5237eeced1c6613d5345fc50bc0022b8868730178c540e6e5fbb8e53a9b98baa")
