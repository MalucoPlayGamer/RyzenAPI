-- Lua provided by RyzenAPI 
-- Game: Thunder Rally
addappid(833500)
addappid(833501, 1, "5237eeced1c6613d5345fc50bc0022b8868730178c540e6e5fbb8e53a9b98baa")
