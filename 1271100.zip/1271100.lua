-- Lua provided by RyzenAPI
-- Game: 1271100

-- MAIN APPLICATION
addappid(1271100)
-- Game: addappid(1271100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271101, 1, "3afe755d42d2ca2e94246b22220813f691fed7102195e29f982d1e7e8f2da708")
