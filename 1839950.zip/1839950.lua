-- Lua provided by RyzenAPI
-- Game: Terminator: Dark Fate - Defiance

-- MAIN APPLICATION
addappid(1839950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839951, 1, "f8a253a01b8b47e291118b994126a4f5f12fa7146e083b8c0f48b4ad041bae2f")
addappid(1839952, 1, "b83da0b0e6b2221774a9c75f43afc8858d66b3cd6de96001dcf565886e8b38d4")
addappid(3227830, 0, "46a7b11f496997b5b8e36c135cc8371ae061f82f86fec4472b31841743be8a9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3650450)
addappid(4157110)
