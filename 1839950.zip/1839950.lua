-- Lua provided by RyzenAPI
-- Game: Game: Terminator: Dark Fate - Defiance

-- MAIN APPLICATION
addappid(1839950)
-- Game: addappid(1839950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839951, 1, "f8a253a01b8b47e291118b994126a4f5f12fa7146e083b8c0f48b4ad041bae2f")
addappid(1839952, 1, "b83da0b0e6b2221774a9c75f43afc8858d66b3cd6de96001dcf565886e8b38d4")
addappid(3227830, 0, "46a7b11f496997b5b8e36c135cc8371ae061f82f86fec4472b31841743be8a9f")
