-- Lua provided by SkyAPI 
-- Game: Life is Feudal: MMO
addappid(700030)
addappid(700031, 1, "96e50ffa14581d0832b756578cdafe8223caba6aa734e6e4e77cdb321edbd2ee")
