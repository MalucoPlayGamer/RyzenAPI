-- Lua provided by RyzenAPI
-- Game: Evergate

-- MAIN APPLICATION
addappid(845030)
-- Game: addappid(845030)

-- MAIN APP DEPOTS / PACKAGES
addappid(845031, 1, "1db87aed8ea795304f1bf210d57992c80bac7f380bd911dc502a1bb914702a10")
