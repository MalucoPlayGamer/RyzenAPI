-- Lua provided by RyzenAPI
-- Game: Game: Flipon

-- MAIN APPLICATION
addappid(1285020)
-- Game: addappid(1285020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285021, 1, "cd7538b4e0ac91f8eadfa59ec384fc55dc42decf4498b8a3fbd8fc03507af36e")
