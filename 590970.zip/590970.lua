-- Lua provided by RyzenAPI
-- Game: Hollow

-- MAIN APPLICATION
addappid(590970)

-- MAIN APP DEPOTS / PACKAGES
addappid(590971, 1, "e0fe08592a0e02eeada61bf6f16727afaec4250d3f71ef6905cee69ca4075cd5")

