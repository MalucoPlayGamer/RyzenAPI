-- Lua provided by RyzenAPI
-- Game: 1099563

-- MAIN APPLICATION
addappid(1099563)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099563,0,"08cb6064c91c1a0aa3c0333fceec4e6d2ac54e9d468cb0635b17d99463ad9f4c")

