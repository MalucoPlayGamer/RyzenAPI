-- Lua provided by RyzenAPI 
-- Game: ATTA -Spot the Oddities in the Strange Hotel-
addappid(2827450)
addappid(2827451, 1, "fc63e0dff156f93317dce72da325ef18435d9ed375e78860fd72065497e8d12f")
