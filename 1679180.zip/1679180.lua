-- Lua provided by RyzenAPI
-- Game: 1679180

-- MAIN APPLICATION
addappid(1679180)
-- Game: addappid(1679180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679181, 1, "cdf3a128efa23876bef8cb48fb1df3ae1b3951e99037aa1df2aa650af4464f85")
