-- Lua provided by RyzenAPI
-- Game: Heavensward: FINAL FANTASY XIV Original Soundtrack

-- MAIN APPLICATION
addappid(3372260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372261, 1, "c955bb15682d3473e4fb5e1f183e666f41524a0c75ee4d7fffa153c3a3dcc5f1")
