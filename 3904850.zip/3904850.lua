-- Lua provided by RyzenAPI
-- Game: Approximately Up

-- MAIN APPLICATION
addappid(3904850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3904850,0,"d2afef93da6af002e2a361a12e09ecaafcfc43969c9b2346f3accff626ea04e3")
addappid(3904851,0,"5e2a7ba121257fb488440e68f5e7403ef71830e2b3339e994b18ee95f2d41f2d")

