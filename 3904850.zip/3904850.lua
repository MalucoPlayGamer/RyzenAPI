-- Lua provided by RyzenAPI
-- Game: Approximately Up

-- MAIN APPLICATION
addappid(3904850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3904850,0,"d2afef93da6af002e2a361a12e09ecaafcfc43969c9b2346f3accff626ea04e3")
addappid(3904851,0,"5e2a7ba121257fb488440e68f5e7403ef71830e2b3339e994b18ee95f2d41f2d")

