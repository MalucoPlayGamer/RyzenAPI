-- Lua provided by RyzenAPI
-- Game: Game: STCC - The Game 1 - Expansion Pack for RACE 07

-- MAIN APPLICATION
addappid(8690)
-- Game: addappid(8690)

-- MAIN APP DEPOTS / PACKAGES
addappid(8691, 1, "65d35009bde70077748b71c0f59b6fc3d4791bb171b14c41e52b4c6cb2de084c")
