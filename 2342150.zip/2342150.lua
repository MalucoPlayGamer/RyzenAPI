-- Lua provided by RyzenAPI 
-- Game: Folk Hero
addappid(2342150)
addappid(2342151, 1, "fa8cad4b53a289b7c99b8752f0123a57b4d047ad0a14b1d8694eef7df6898de2")
