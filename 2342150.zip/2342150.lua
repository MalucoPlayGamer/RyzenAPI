-- Lua provided by RyzenAPI
-- Game: 2342150

-- MAIN APPLICATION
addappid(2342150)
-- Game: addappid(2342150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342151, 1, "fa8cad4b53a289b7c99b8752f0123a57b4d047ad0a14b1d8694eef7df6898de2")
