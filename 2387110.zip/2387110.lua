-- Lua provided by RyzenAPI
-- Game: Green Reaper

-- MAIN APPLICATION
addappid(2387110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2387111, 1, "3f780c43f20c6c50331ecf19303296ed3caf7e0bbee4ef50e8a618f64e653a5f")

