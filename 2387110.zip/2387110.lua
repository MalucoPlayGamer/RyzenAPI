-- Lua provided by RyzenAPI 
-- Game: Green Reaper
addappid(2387110)
addappid(2387111, 1, "3f780c43f20c6c50331ecf19303296ed3caf7e0bbee4ef50e8a618f64e653a5f")
