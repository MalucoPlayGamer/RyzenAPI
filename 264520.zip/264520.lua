-- Lua provided by RyzenAPI
-- Game: Moebius: Empire Rising

-- MAIN APPLICATION
addappid(264520)
-- Game: addappid(264520)

-- MAIN APP DEPOTS / PACKAGES
addappid(264521, 1, "d1d77e4feb51cabbc3ba042c39bbd63f4cd2854234084d7b4eeb37f721be7432")
addappid(264522, 1, "d039c4e8201d0915a370e3f50b067960bafc2a27db8fce435394d3220ec10d87")
addappid(264523, 1, "49914ccdc9c94b6af53ef787061395a7f9c8428dd37861249a17059dc119156a")
addappid(287550, 0, "f9e6eacdd749c6451bd4be41baa4e30453e8f5dd404f6822abe365e3719116ef")
