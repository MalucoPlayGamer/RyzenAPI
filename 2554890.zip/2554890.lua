-- Lua provided by RyzenAPI
-- Game: Game: AppID 2554890

-- MAIN APPLICATION
addappid(2554890)
-- Game: addappid(2554890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554891, 1, "c2bdd8f580d45bf596f3d6125408ec9098384b9474a04624740b6d93d179ad8a")
