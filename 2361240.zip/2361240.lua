-- Lua provided by RyzenAPI
-- Game: 天神印（THE BLOCKADE）

-- MAIN APPLICATION
addappid(2361240)
-- Game: addappid(2361240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361241, 1, "3608c4ad57a43d0effdaa7829fbc1252f31f9107884cac38275349861680abdd")
