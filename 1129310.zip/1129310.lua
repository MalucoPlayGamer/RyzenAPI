-- Lua provided by RyzenAPI
-- Game: Game: Receiver 2

-- MAIN APPLICATION
addappid(1129310)
-- Game: addappid(1129310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129311, 1, "01085dd84ed744c40bfa4353e67ca01e12a6ec49ba2d1669f246ea7c18b068cf")
addappid(1129312, 1, "4d2a335f014e364cc79b92c62fd259ba36a250b8a065a1c72637921ceb2884df")
addappid(1129313, 1, "2af62d9df93cd95de48148fae8ba034dd222a781dafd9a57bcae26e1b770d417")
