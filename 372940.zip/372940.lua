-- Lua provided by RyzenAPI
-- Game: 372940

-- MAIN APPLICATION
addappid(372940)
-- Game: addappid(372940)

-- MAIN APP DEPOTS / PACKAGES
addappid(372941, 1, "25a36761e5ec6da94bb2b2b70ee788c47aa048e93a07a198cb2cbf1d514af673")
