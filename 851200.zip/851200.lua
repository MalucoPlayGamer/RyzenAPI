-- Lua provided by RyzenAPI
-- Game: addappid(851200)

-- MAIN APPLICATION
addappid(851200)
addappid(852130)

-- MAIN APP DEPOTS / PACKAGES
addappid(851201, 1, "a223e217f6235ff6eaeb812a1d6c75e057a86a4c91ea76af0da856c6b0d14d72")
