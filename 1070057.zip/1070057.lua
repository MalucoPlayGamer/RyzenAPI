-- Lua provided by RyzenAPI
-- Game: addappid(1070057)

-- MAIN APPLICATION
addappid(1070057)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070057,0,"fc3d02520151ef0c9306b43e4c48aedf04e61be386f5505eb5a2e0784c544d0d")
