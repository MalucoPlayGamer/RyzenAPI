-- Lua provided by RyzenAPI
-- Game: Konkwest

-- MAIN APPLICATION
addappid(2702570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702571, 1, "fc87b46f4f4088d358d1c6ea06271867762ec1268ad70947e22810bced061419")

