-- Lua provided by SkyAPI 
-- Game: AppID 1120370
addappid(1120370)
addappid(1120371, 1, "bf290bc7bce4a2c9e343b5100f9381235d6ac1b75c1630ed9b70e45117d6ce86")
