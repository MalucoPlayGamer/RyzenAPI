-- Lua provided by RyzenAPI
-- Game: Atelier Meruru ~The Apprentice of Arland~ DX

-- MAIN APPLICATION
addappid(936190)

-- MAIN APP DEPOTS / PACKAGES
addappid(936191, 1, "dda6dcb9be0382c86014b8e234d3a9fc7dd16eb217912c0cf6dce99c40b52bca")

