-- Lua provided by RyzenAPI
-- Game: Atelier Meruru ~The Apprentice of Arland~ DX

-- MAIN APPLICATION
addappid(936190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(936191, 1, "dda6dcb9be0382c86014b8e234d3a9fc7dd16eb217912c0cf6dce99c40b52bca")

