-- Lua provided by RyzenAPI
-- Game: Cyber Surf

-- MAIN APPLICATION
addappid(735810)

-- MAIN APP DEPOTS / PACKAGES
addappid(735811, 1, "4f4d58aec8b108fe6cbc2a6f7daa7c398ed0c7666f07c9eb8f1f943cb70910f1")

