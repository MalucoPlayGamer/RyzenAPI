-- Lua provided by RyzenAPI
-- Game: AppID 1075200

-- MAIN APPLICATION
addappid(1075200)
addappid(1523410)
-- Game: addappid(1075200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075201, 1, "c8ba9a575e947a511e12702811ec1ba081f9f6f4037daa4a76541f5d667b0ddb")
