-- Lua provided by RyzenAPI
-- Game: Game: The Moon Relax

-- MAIN APPLICATION
addappid(1360360)
-- Game: addappid(1360360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360361, 1, "828710b857f484c1b431e7a2279a428afd8e4583c36fe047ae116b2ee1932723")
