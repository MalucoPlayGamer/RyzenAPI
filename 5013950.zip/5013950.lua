-- Lua provided by RyzenAPI
-- Game: Created: August 20, 2026 at 06:18:11 EDT

-- MAIN APPLICATION
addappid(5013950) -- 神临

-- MAIN APP DEPOTS / PACKAGES
addappid(5013951, 1, "c6b97c91a95589ed087f5911b672c8bd627a5bbfca66aa28349af02d6376a17f") -- Depot 5013951

