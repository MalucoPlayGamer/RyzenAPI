-- 5013950's Lua and Manifest Created by Hubcap Manifest
-- 神临
-- Created: August 20, 2026 at 06:18:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5013950) -- 神临
-- MAIN APP DEPOTS
addappid(5013951, 1, "c6b97c91a95589ed087f5911b672c8bd627a5bbfca66aa28349af02d6376a17f") -- Depot 5013951
setManifestid(5013951, "5556338794586122564", 134374584)