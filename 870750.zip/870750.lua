-- Lua provided by RyzenAPI
-- Game: 870750

-- MAIN APPLICATION
addappid(870750)
-- Game: addappid(870750)

-- MAIN APP DEPOTS / PACKAGES
addappid(870751, 1, "082e685affb89e7be3658fe395cca7313f23173884fa1e55877d8e769d9691af")
