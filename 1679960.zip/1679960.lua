-- Lua provided by RyzenAPI
-- Game: 1679960

-- MAIN APPLICATION
addappid(1679960)
-- Game: addappid(1679960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679961, 1, "e1adc5d5ef3426763426b6274dfd4ccdb1901c71686807001c9efb08eaafb9e5")
