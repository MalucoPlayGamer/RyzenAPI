-- Lua provided by RyzenAPI
-- Game: Sapling

-- MAIN APPLICATION
addappid(1679960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1679961, 1, "e1adc5d5ef3426763426b6274dfd4ccdb1901c71686807001c9efb08eaafb9e5")

