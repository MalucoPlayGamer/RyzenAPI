-- Lua provided by RyzenAPI
-- Game: Game: XIII - Classic

-- MAIN APPLICATION
addappid(1170760)
-- Game: addappid(1170760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170761, 1, "108131f745bf7b02473d31e4fbc5e99dda0d22e989c5ad7fa12f6abfa1250613")
addappid(1170763, 1, "ffdf90d9d55ad36291776ab92ec27f9d1e07e5bdf656bd72f615ed78f61d6788")
addappid(1170764, 1, "ea50db4c508b91100ec9f14a753dc7d2e75a8d07d5e5068002a964fed73a3b56")
addappid(1170765, 1, "2fa88aee41281e5e819c62038e6d67a7cee5dca04dddace863c3cbc3d7ef93cd")
addappid(1170766, 1, "d14fe8c5c876585dcf21af244acf27f92ebff5fbe3f0dfdc9271ce821046b487")
