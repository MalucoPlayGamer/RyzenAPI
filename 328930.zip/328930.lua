-- Lua provided by RyzenAPI
-- Game: Fleet Defender: The F-14 Tomcat Simulation

-- MAIN APPLICATION
addappid(328930)
-- Game: addappid(328930)

-- MAIN APP DEPOTS / PACKAGES
addappid(328931, 1, "22fccedbdd4c541ff2a57d518eab1c575057f861696766d458d385d4920b682a")
addappid(328932, 1, "d78870041feb8835722b4147f541719eabaca95839eec16828dc4b0b74f90c73")
addappid(328934, 1, "d6808f54c27d1edd8382ef01409d9f3a9891468cdacd6b934db088ea552b4433")
