-- Lua provided by RyzenAPI
-- Game: Game: Mini Madness

-- MAIN APPLICATION
addappid(1603960)
-- Game: addappid(1603960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603961, 1, "a79ea2ccb109ab83d2be377f7e04caa78a2ebf59849748b8b90790b4c04ebc07")
