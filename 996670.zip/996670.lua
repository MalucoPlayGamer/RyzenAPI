-- Lua provided by RyzenAPI
-- Game: addappid(996670)

-- MAIN APPLICATION
addappid(996670)

-- MAIN APP DEPOTS / PACKAGES
addappid(945491,0,"1569a6b8a28fc06c2c4dad7a8c340a95f56044a484fb038e8a9410b54b5b0fc3")
