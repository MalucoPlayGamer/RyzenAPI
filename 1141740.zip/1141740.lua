-- Lua provided by RyzenAPI
-- Game: 1141740

-- MAIN APPLICATION
addappid(1141740)
-- Game: addappid(1141740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141741, 1, "17469dc2a90c8f806b2b09253f14e9ddff33d0fb965a6dd8fccb609a3d912ece")
