-- Lua provided by RyzenAPI
-- Game: Game: AppID 779130

-- MAIN APPLICATION
addappid(779130)
-- Game: addappid(779130)

-- MAIN APP DEPOTS / PACKAGES
addappid(779131, 1, "30b743fa77fdf099113c0a9af504fe6d3850b3cf66d489963f5204949ca520a6")
