-- Lua provided by RyzenAPI
-- Game: Iron Ranger

-- MAIN APPLICATION
addappid(3804040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3804041, 1, "ec8c446395e78e9e428a4f3b4e7efe84b7914f743709f3efd2f2a11beb2fe460")

