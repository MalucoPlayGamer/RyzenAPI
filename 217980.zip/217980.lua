-- Lua provided by RyzenAPI
-- Game: Dishonored RHCP

-- MAIN APPLICATION
addappid(217980)
addappid(218780)
addappid(218781)
addappid(218782)
addappid(218783)

-- MAIN APP DEPOTS / PACKAGES
addappid(217981, 1, "491b8b17833d8f6ac03fe4ca360e5e41820b547e771f921ac0e45952f78309ed")
addappid(217982, 1, "4e5a19ff55c7d5c1525785af9650effdbe83be0d10f44fb82e2267c27e858706")
addappid(218784, 0, "b04bde8c974cdf127097a8e68368f052c9597d927ffac91f2acccf005d9d8195")
addappid(218785, 0, "5aec1758797fa6e7bcfbeea1e89f6721bec2d4d72d482c3807dc22db4abf7376")
addappid(218786, 0, "aebc7fb4476752e26e21da9e3808cb7234dd1d9522855e234273c32d628d285a")

