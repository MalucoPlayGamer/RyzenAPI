-- Lua provided by RyzenAPI
-- Game: Succubus - Artbook

-- MAIN APPLICATION
addappid(1670520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670520,0,"c59389154493a22caab252ea5a940f45743c015f3f9a158d1a00457a735fcf74")

