-- Lua provided by RyzenAPI
-- Game: addappid(1134260)

-- MAIN APPLICATION
addappid(1134260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134261, 1, "af3d21982d84baec435367f56b8949aa3fc24b0245040a30ccc4885884ce00ea")
