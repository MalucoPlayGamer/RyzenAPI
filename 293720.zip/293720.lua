-- Lua provided by RyzenAPI
-- Game: AppID 293720

-- MAIN APPLICATION
addappid(293720)

-- MAIN APP DEPOTS / PACKAGES
addappid(293721, 1, "574d4a0a9ce664410e2f1304d3c01abe434fdf332f802f44c02ecb4909d9ade3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
