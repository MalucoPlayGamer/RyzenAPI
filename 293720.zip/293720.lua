-- Lua provided by SkyAPI 
-- Game: AppID 293720
addappid(293720)
addappid(293721, 1, "574d4a0a9ce664410e2f1304d3c01abe434fdf332f802f44c02ecb4909d9ade3")
