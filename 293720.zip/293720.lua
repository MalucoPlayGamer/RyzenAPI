-- Lua provided by RyzenAPI
-- Game: addappid(293720)

-- MAIN APPLICATION
addappid(293720)

-- MAIN APP DEPOTS / PACKAGES
addappid(293721, 1, "574d4a0a9ce664410e2f1304d3c01abe434fdf332f802f44c02ecb4909d9ade3")
