-- Lua provided by RyzenAPI
-- Game: 失乐园歌留多

-- MAIN APPLICATION
addappid(3231830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231831, 1, "3bd0037818f86fd3557112832c05884e2bf7f746ab132aa7c23ed8f0df892131")
