-- Lua provided by RyzenAPI
-- Game: Chrono Sword

-- MAIN APPLICATION
addappid(1520160)
-- Game: addappid(1520160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520161, 1, "007f111f32c215ea27bd0e095ecac7170aa3915c35eec234c3cb3f5dd2162cb0")
