-- Lua provided by SkyAPI 
-- Game: Chrono Sword
addappid(1520160)
addappid(1520161, 1, "007f111f32c215ea27bd0e095ecac7170aa3915c35eec234c3cb3f5dd2162cb0")
