-- Lua provided by RyzenAPI
-- Game: 1896390

-- MAIN APPLICATION
addappid(1896390)
-- Game: addappid(1896390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896391, 1, "4159ee5b005936af5f224e6fa77e5d8d829176139bd52c1c45462912ffe99afa")
