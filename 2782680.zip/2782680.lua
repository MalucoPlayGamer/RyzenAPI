-- Lua provided by RyzenAPI
-- Game: Snufkin: Melody of Moominvalley - Cherished Keepsakes

-- MAIN APPLICATION
addappid(2782680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782680,0,"355197995e65fac3313010ff32965c909ab970f99b5bf5dcc59d20a255d423fc")

