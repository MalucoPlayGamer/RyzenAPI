-- Lua provided by RyzenAPI
-- Game: Dominated by: Yandere Goth Gangster

-- MAIN APPLICATION
addappid(3820090)
-- Game: addappid(3820090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3820097,0,"e6ae7825e0ca20908fa596341528862c802c70a8fa48dba4bf7f9549e1068d66")
