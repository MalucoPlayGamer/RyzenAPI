-- Lua provided by SkyAPI 
-- Game: Skibidi Toilets: Invasion
addappid(2550480)
addappid(2550481, 1, "b259b187ed65dd4872ec123fffa06f0e21749283f848cdeb8ec330c6456ecf7e")
