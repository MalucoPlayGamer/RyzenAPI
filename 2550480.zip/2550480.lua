-- Lua provided by RyzenAPI
-- Game: Game: Skibidi Toilets: Invasion

-- MAIN APPLICATION
addappid(2550480)
-- Game: addappid(2550480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550481, 1, "b259b187ed65dd4872ec123fffa06f0e21749283f848cdeb8ec330c6456ecf7e")
