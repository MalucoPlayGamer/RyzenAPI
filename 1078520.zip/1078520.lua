-- Lua provided by RyzenAPI
-- Game: Ghost Stories

-- MAIN APPLICATION
addappid(1078520)
addappid(1107120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078521, 1, "44bcd5d40098dffc7d718d6ddbcc6c0c6f3932d68af342e77441219ee63cc4ad")

