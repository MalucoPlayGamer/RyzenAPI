-- Lua provided by RyzenAPI
-- Game: Horizon's Gate

-- MAIN APPLICATION
addappid(1224290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224291, 1, "5fe3536a465ac0f161ec229e8dfa8987e2e7834b0af635904239d24a2a752038")
