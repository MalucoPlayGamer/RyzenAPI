-- Lua provided by SkyAPI 
-- Game: Horizon's Gate
addappid(1224290)
addappid(1224291, 1, "5fe3536a465ac0f161ec229e8dfa8987e2e7834b0af635904239d24a2a752038")
