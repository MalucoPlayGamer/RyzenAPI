-- Lua provided by RyzenAPI
-- Game: Game: Jotun: Original Soundtrack

-- MAIN APPLICATION
addappid(406470)
-- Game: addappid(406470)

-- MAIN APP DEPOTS / PACKAGES
addappid(406471, 1, "14a97d8854c2ad69ad602f08daa63a52b034cf52b8183faa50c6c88259b6f7d7")
