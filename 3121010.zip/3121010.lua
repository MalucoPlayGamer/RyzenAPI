-- Lua provided by RyzenAPI
-- Game: Code My Robot Vacuum

-- MAIN APP DEPOTS / PACKAGES
addappid(3121010, 1, "7279b30e5a86b84478759b03060281a2f9b4c844c29239ba2481ef6439503b2b") -- Code My Robot Vacuum
addappid(3121012, 1, "3cd808bf7748ef0bc2621b365fe42573730d75c3b5ef01ab728aac867ff6bac7") -- Depot 3121012
addappid(3121013, 1, "59c72a1411949938a6707e2f1900e21e86b50035f552bdbff2c85a8a508810b4") -- Depot 3121013
