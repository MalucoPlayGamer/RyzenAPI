-- Lua provided by RyzenAPI
-- Game: Re-Legion - Digital_Soundtrack_

-- MAIN APPLICATION
addappid(1021900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021900,0,"dbbbf5c86e16fab8033badf6081b71d5416da2bf8e44833b281b139e2b3b25b9")
