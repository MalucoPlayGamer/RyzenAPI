-- Lua provided by RyzenAPI
-- Game: Office Fight - Beta

-- MAIN APPLICATION
addappid(2549670)
addappid(2667620)
addappid(2668920)
addappid(2668930)
addappid(2668940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2549671, 1, "87f5312c2a1d00820253a54c3a276e5d53698d6b37ff9701bc68f011f9d1d2dc")
addappid(2549672, 1, "7ca5dcd64c8677f4bd5abb6456cbe18153f1ecd46fc1750a934058336baf07bd")

