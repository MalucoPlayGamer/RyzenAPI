-- Lua provided by RyzenAPI
-- Game: addappid(340800)

-- MAIN APPLICATION
addappid(340800)
addappid(343580)
addappid(343581)
addappid(343582)
addappid(343583)
addappid(374100)

-- MAIN APP DEPOTS / PACKAGES
addappid(340801, 1, "4be396ccedf0aab68564d0feb1412d6d383328fb169f33373a0d06ff9c221669")
addappid(340802, 1, "73ac81d63f153baca88a4aa0268dc7af86c03c66119af35b62d0fdf55f711934")
addappid(340803, 1, "2f3434a3c0864471404afbded2cd0695e7e22913a0b77410b49deb357f1fb654")
addappid(340804, 1, "922deafda375956874781c42f2cc35684da68e4bb98ca95db10863f86a601290")
addappid(340805, 1, "621390a9b78e14ba29b69a0d7488d5b81b1b6a1a4bae3b0bbfe9415829a490fe")
addappid(340806, 1, "8acbeb1d0ca39aaeb71e19c0dc375c96cefa8a9a416b1655ee5e194de71ee6f7")
