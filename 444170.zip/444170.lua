-- Lua provided by RyzenAPI
-- Game: AppID 444170

-- MAIN APPLICATION
addappid(444170)

-- MAIN APP DEPOTS / PACKAGES
addappid(444171, 1, "c3c195d04ff80d54f5da9311d87c23bd1075d3a17fae45afa55f6afcce8f0f4e")
addappid(444611, 0, "3fae997cfc1d42363c3aa5167ca29e1fb196f38c1962e33fd3f71645695b572c")

