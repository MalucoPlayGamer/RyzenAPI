-- Lua provided by RyzenAPI
-- Game: Don't Panic Together

-- MAIN APPLICATION
addappid(4359800)

-- MAIN APP DEPOTS / PACKAGES
addappid(4359801,0,"43f398659ce16ec63f7ab0348520aa9e56a22d94c71e7871b8a06878eb4f1d12")

