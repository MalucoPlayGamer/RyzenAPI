-- Lua provided by RyzenAPI
-- Game: Don't Panic Together

-- MAIN APPLICATION
addappid(4359800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4359801,0,"43f398659ce16ec63f7ab0348520aa9e56a22d94c71e7871b8a06878eb4f1d12")

