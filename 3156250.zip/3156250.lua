-- Lua provided by RyzenAPI
-- Game: 3156250

-- MAIN APPLICATION
addappid(3156250)
-- Game: addappid(3156250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156250,0,"23a95d9080d8ecd546d7aa5de801c98f20586c074c87d9e2da4abc79ee958cc2")
