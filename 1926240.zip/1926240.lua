-- Lua provided by RyzenAPI
-- Game: 1926240

-- MAIN APPLICATION
addappid(1926240)
-- Game: addappid(1926240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926241, 1, "3b16a7bee168c8d4901f26588bb77bc01abcff6461307dd581a32d54dd38c62c")
