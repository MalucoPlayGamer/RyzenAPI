-- Lua provided by RyzenAPI
-- Game: Biotope

-- MAIN APPLICATION
addappid(549040)

-- MAIN APP DEPOTS / PACKAGES
addappid(549041, 1, "27e95c75352bcc589ee2d541377df9297a3dfa9515698a3af29de80e523e7cd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
