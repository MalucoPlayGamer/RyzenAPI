-- Lua provided by RyzenAPI
-- Game: Biotope

-- MAIN APPLICATION
addappid(549040)

-- MAIN APP DEPOTS / PACKAGES
addappid(549041, 1, "27e95c75352bcc589ee2d541377df9297a3dfa9515698a3af29de80e523e7cd7")
