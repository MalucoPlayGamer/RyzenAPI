-- Lua provided by SkyAPI 
-- Game: AppID 1033330
addappid(1033330)
addappid(1033331, 1, "0c79621b41295dd709e02200551806cca2d4425579a3fb0e201413fec83299ab")
