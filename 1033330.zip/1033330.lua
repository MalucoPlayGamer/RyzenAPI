-- Lua provided by RyzenAPI
-- Game: Primordium - Day Zero

-- MAIN APPLICATION
addappid(1033330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1033331, 1, "0c79621b41295dd709e02200551806cca2d4425579a3fb0e201413fec83299ab")
