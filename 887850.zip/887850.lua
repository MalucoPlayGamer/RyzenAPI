-- Lua provided by RyzenAPI
-- Game: addappid(887850)

-- MAIN APPLICATION
addappid(887850)

-- MAIN APP DEPOTS / PACKAGES
addappid(887851, 1, "e680566573c0038ff3047862f88acf1dee4b1c1d90bfff107fd47bbf1f052f14")
