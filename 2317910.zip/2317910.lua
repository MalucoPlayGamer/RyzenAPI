-- Lua provided by RyzenAPI 
-- Game: Chinese Frontiers: Prologue
addappid(2317910)
addappid(2317911, 1, "6d90126b53eab03b03fd4ba3cfca72cd865b8f3303288b2bf91bc20ebb46501f")
