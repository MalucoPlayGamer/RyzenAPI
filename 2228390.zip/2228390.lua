-- Lua provided by RyzenAPI
-- Game: Game: Fairy Fencer F: Refrain Chord

-- MAIN APPLICATION
addappid(2228390)
-- Game: addappid(2228390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2228391, 1, "488ecc02c39c44b5128e5f9a646eef24476eb0fbd9fcbac1b6ffdd3e32b5f455")
