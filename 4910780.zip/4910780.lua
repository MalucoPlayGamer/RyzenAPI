-- Lua provided by RyzenAPI
-- Game: Europe Heatwave Simulator

-- MAIN APPLICATION
addappid(4910780)

-- MAIN APP DEPOTS / PACKAGES
addappid(4910781,0,"142b3ac7027de33d62a31f11096a143ffce54f4c332cf1e4afcbf36e74d20ce0")

