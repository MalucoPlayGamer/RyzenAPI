-- Lua provided by RyzenAPI
-- Game: addappid(2539780)

-- MAIN APPLICATION
addappid(2539780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539781, 1, "bbe49cfa8bfd8865efacd5214f5e433297289a1201e26046469aa4f53fab094f")
addappid(2539782, 1, "29db1a242bf7d4ae5eae0f0e4db45d8ad5c2c17de48ddaac64c9a665e2d9a27c")
