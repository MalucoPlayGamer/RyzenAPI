-- Lua provided by RyzenAPI
-- Game: The Groom of Gallagher Mansion Demo

-- MAIN APPLICATION
addappid(2529240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529243,0,"fdf4f25ffdd366743e8c95525275f3467e005d5c6d783c922ebf0e5b458290f2")
