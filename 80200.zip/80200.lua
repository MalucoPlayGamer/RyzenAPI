-- Lua provided by RyzenAPI
-- Game: Fate of the World

-- MAIN APPLICATION
addappid(80200)
-- Game: addappid(80200)

-- MAIN APP DEPOTS / PACKAGES
addappid(80201, 1, "be253bc91ee1a1bc58e603063dd085baa542bcd6914674c86cff493f52e9d146")
addappid(80202, 1, "148527ad7021b0759991e9b22809ede04d67a6f0cfa8a42c7aafc59150314238")
addappid(80203, 1, "456e5832e440906fd76b4b02aba5b2f101539a1ac18f80f3373ba59b3fa84cc6")
addappid(80204, 1, "a4521140411e46e8c8fd9c6cc3e8fbc5ae8e2598e8ee4008de71555ac626364d")
addappid(80205, 1, "ac87c6b6ecf6078028366586ba907acfc86f036c470005d2fb284bd87d4c02e6")
addappid(80206, 1, "a43c6171599027d4bf30a0d8b8a2b163b3abdcc6cf57a7b8a38fcf545366cf9a")
addappid(80207, 1, "2dc0e09df54fbee3d77dde755988601ba9fa60b9bf38ed3e261582c404d23ca8")
