-- Lua provided by RyzenAPI
-- Game: AppID 2299660

-- MAIN APPLICATION
addappid(2299660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299661, 1, "2e23811dd0dc3cbfb8d1c8129ebf2a91a0f9ef90474b2b9f127cb841c99ecda7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
