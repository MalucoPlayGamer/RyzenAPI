-- Lua provided by RyzenAPI 
-- Game: AppID 2299660
addappid(2299660)
addappid(2299661, 1, "2e23811dd0dc3cbfb8d1c8129ebf2a91a0f9ef90474b2b9f127cb841c99ecda7")
