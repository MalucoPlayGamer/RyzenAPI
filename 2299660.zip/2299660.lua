-- Lua provided by RyzenAPI
-- Game: Game: AppID 2299660

-- MAIN APPLICATION
addappid(2299660)
-- Game: addappid(2299660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299661, 1, "2e23811dd0dc3cbfb8d1c8129ebf2a91a0f9ef90474b2b9f127cb841c99ecda7")
