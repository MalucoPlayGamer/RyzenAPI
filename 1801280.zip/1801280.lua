-- Lua provided by RyzenAPI
-- Game: Game: SCP: CB Multiplayer Dedicated Server

-- MAIN APPLICATION
addappid(1801280)
-- Game: addappid(1801280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801281, 1, "e2eaa7f27f508a67f30942f68afd7408096bff1e105194c1bb93ad2cc5d671da")
