-- Lua provided by RyzenAPI
-- Game: addappid(2138130)

-- MAIN APPLICATION
addappid(2138130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138131, 1, "bcea51b374aed72ebe319aa5a0af7840a2b22b38a65fa2b01c8218dbb95a0baf")
