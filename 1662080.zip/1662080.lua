-- Lua provided by RyzenAPI
-- Game: Goonya Monster

-- MAIN APPLICATION
addappid(1973870) -- Goonya Monster - DX
addappid(2011740) -- Goonya Monster - 1
addappid(2086600) -- Goonya Monster - 2
addappid(2086610) -- Goonya Monster - 3
addappid(2086620) -- Goonya Monster - 4
addappid(2086621) -- Goonya Monster - 5
addappid(2086622) -- Goonya Monster - 6
addappid(2086630) -- Goonya Monster - BGMGO ON YA WAYFAKE TYPE. feat.
addappid(2086631) -- Goonya Monster - CV.
addappid(2086632) -- Goonya Monster - CV.
addappid(2086633) -- Goonya Monster - CV.
addappid(2086634) -- Goonya Monster - CV.
addappid(2086635) -- Goonya Monster - DX
addappid(2194140) -- Goonya Monster - BGMGO ON YA WAY(Instrumental Ver.)FAKE TYPE. feat.
addappid(2194360) -- Goonya Monster - DYES IWASAKIFAKE TYPE.
addappid(2194390) -- Goonya Monster - FAKE TYPE.
addappid(2194391) -- Goonya Monster - SAKANAMON
addappid(2194392) -- Goonya Monster - SAKANAMON
addappid(2194393) -- Goonya Monster - SAKANAMON
addappid(2194420) -- Goonya Monster - SAKANAMON
addappid(2194421) -- Goonya Monster -
addappid(2194422) -- Goonya Monster -
addappid(2194423) -- Goonya Monster -
addappid(2361290) -- Goonya Monster - CV.
addappid(2361300) -- Goonya Monster - CV.
addappid(2361301) -- Goonya Monster - CV.
addappid(2361310) -- Goonya Monster - CV.
addappid(2361311) -- Goonya Monster - CV.
addappid(2361312) -- Goonya Monster - CV.
addappid(2361313) -- Goonya Monster - CV.
addappid(2361314) -- Goonya Monster - CV.
addappid(2361315) -- Goonya Monster -
addappid(2361316) -- Goonya Monster -
addappid(2361317) -- Goonya Monster -
addappid(2395780) -- Goonya Monster -
addappid(2395781) -- Goonya Monster -
addappid(2445670) -- Goonya Monster - All Guys
addappid(2445671) -- Goonya Monster - VAll Guys
addappid(2445672) -- Goonya Monster - All Guys
addappid(2445673) -- Goonya Monster - All Guys
addappid(2631690) -- Goonya Monster - FAKE TYPE.
addappid(2631700) -- Goonya Monster - FAKE TYPE.
addappid(2732530) -- Goonya Monster -

-- MAIN APP DEPOTS / PACKAGES
addappid(1662080, 1, "8478256ceac70a8412c9092bed48b5805049661430c9a13e2f2a8be8d1dee2c4") -- Goonya Monster
addappid(1662081, 1, "27fe0f7c0846d79cfc60aa188b8e4b089bcbfe20c5fe56e23fe29c7b95192149") -- Depot 1662081
