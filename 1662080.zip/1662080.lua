-- Lua provided by RyzenAPI
-- Game: Goonya Monster

-- MAIN APPLICATION
addappid(1662080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662081, 1, "27fe0f7c0846d79cfc60aa188b8e4b089bcbfe20c5fe56e23fe29c7b95192149")
