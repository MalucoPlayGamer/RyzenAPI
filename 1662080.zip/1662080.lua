-- Lua provided by RyzenAPI
-- Game: Goonya Monster

-- MAIN APPLICATION
addappid(1662080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662081, 1, "27fe0f7c0846d79cfc60aa188b8e4b089bcbfe20c5fe56e23fe29c7b95192149")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2361290)
addappid(2361300)
addappid(2361301)
addappid(2361310)
addappid(2361311)
addappid(2361312)
addappid(2361313)
addappid(2361314)
addappid(2361315)
addappid(2361316)
addappid(2361317)
addappid(2395780)
addappid(2395781)
addappid(2445670)
addappid(2445671)
addappid(2445672)
addappid(2445673)
addappid(2631690)
addappid(2631700)
addappid(2732530)
