-- Lua provided by RyzenAPI
-- Game: Game: Jotunnslayer: Hordes of Hel Demo

-- MAIN APPLICATION
addappid(3047240)
-- Game: addappid(3047240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3047241, 1, "cb3bad4efd305f7a381a3d70d9d6a75e8205a83df7d09887f3f96dab7c1826cf")
