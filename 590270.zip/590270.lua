-- Lua provided by RyzenAPI
-- Game: Game: Catsby

-- MAIN APPLICATION
addappid(590270)
-- Game: addappid(590270)

-- MAIN APP DEPOTS / PACKAGES
addappid(590271, 1, "27c1da0396f63f9f1cf92a8dc8e2c2d8fe189841fb614f2fc2ada2214ecfc75a")
