-- Lua provided by RyzenAPI
-- Game: Frosty Nights

-- MAIN APPLICATION
addappid(733800)
-- Game: addappid(733800)

-- MAIN APP DEPOTS / PACKAGES
addappid(733801, 1, "de024fb3832b8fcf655fac9456f6815a0f27d879c91033251f6a316d8b924293")
