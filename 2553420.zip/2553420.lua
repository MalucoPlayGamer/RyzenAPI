-- Lua provided by RyzenAPI
-- Game: Game: Outta Hand

-- MAIN APPLICATION
addappid(2553420)
-- Game: addappid(2553420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553421, 1, "e241a1431f9f8b5c94220e022964b2e0e8615029dca688eb29ca154ed3e7f262")
