-- Lua provided by RyzenAPI
-- Game: Outta Hand

-- MAIN APPLICATION
addappid(2553420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553421, 1, "e241a1431f9f8b5c94220e022964b2e0e8615029dca688eb29ca154ed3e7f262")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
