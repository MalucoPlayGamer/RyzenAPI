-- Lua provided by RyzenAPI
-- Game: addappid(1861090)

-- MAIN APPLICATION
addappid(1861090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861091, 1, "69b9dff9165f9c63aa4accd51c4e934b01ee0098a3035167260159523e245dbf")
