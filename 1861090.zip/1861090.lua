-- Lua provided by RyzenAPI
-- Game: Dire Destiny ：Time Travel

-- MAIN APPLICATION
addappid(1861090) -- Dire Destiny ：Time Travel
addappid(2387640) -- -
addappid(2401650) -- -
addappid(2401660) -- -

-- MAIN APP DEPOTS / PACKAGES
addappid(1861091, 1, "69b9dff9165f9c63aa4accd51c4e934b01ee0098a3035167260159523e245dbf") -- Depot 1861091

