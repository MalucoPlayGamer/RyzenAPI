-- Lua provided by RyzenAPI
-- Game: No Man's Sky

-- MAIN APPLICATION
addappid(275850)
addappid(3380990)

-- MAIN APP DEPOTS / PACKAGES
addappid(275851, 1, "a5ce5217e5d5d20115ea81209764d4e89f37bed55b84690951d5df23e73852a6")
addappid(275852, 1, "1f8fb10eb2401484d32af8e6c0d3b7e4148e78e4cf8f632afe1ab6600fb7e57d")
