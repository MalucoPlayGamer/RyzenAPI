-- Lua provided by RyzenAPI
-- Game: No Man's Sky

-- MAIN APPLICATION
addappid(275850)
addappid(3380990)

-- MAIN APP DEPOTS / PACKAGES
addappid(275851, 1, "a5ce5217e5d5d20115ea81209764d4e89f37bed55b84690951d5df23e73852a6")
addappid(275852, 1, "1f8fb10eb2401484d32af8e6c0d3b7e4148e78e4cf8f632afe1ab6600fb7e57d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(513130)
