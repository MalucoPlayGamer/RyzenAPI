-- Lua provided by RyzenAPI
-- Game: Game: DEMoCap (Drag[en]gine Motion Capture)

-- MAIN APPLICATION
addappid(1939210)
-- Game: addappid(1939210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939211, 1, "097f14a4e011e13df27ac44b94e42c7db28115df85a728780327e75af5753deb")
