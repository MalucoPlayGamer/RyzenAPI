-- Lua provided by RyzenAPI 
-- Game: DEMoCap (Drag[en]gine Motion Capture)
addappid(1939210)
addappid(1939211, 1, "097f14a4e011e13df27ac44b94e42c7db28115df85a728780327e75af5753deb")
