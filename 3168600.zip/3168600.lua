-- Lua provided by RyzenAPI
-- Game: Among Us 3D

-- MAIN APPLICATION
addappid(3168600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168601, 1, "aa00ac0fba8596773fd2ef1ba340b52d867e19bf447258e770f68a2257d39dd4")

