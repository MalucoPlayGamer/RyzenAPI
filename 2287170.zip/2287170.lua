-- Lua provided by RyzenAPI
-- Game: Surviving Skeleton Island

-- MAIN APPLICATION
addappid(2287170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287172,0,"a4e34e76557086346f15fea907c6c53a6fb742dad368cf4363e6e77320103663")
