-- Lua provided by RyzenAPI
-- Game: addappid(1014350)

-- MAIN APPLICATION
addappid(1014350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014351, 1, "c876f360afb957d54da3a1e580131203ff311d394a9f822b7ee5c694ba4447fb")
