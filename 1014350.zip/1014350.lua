-- Lua provided by RyzenAPI
-- Game: Once A Stray

-- MAIN APPLICATION
addappid(1014350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014351, 1, "c876f360afb957d54da3a1e580131203ff311d394a9f822b7ee5c694ba4447fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
