-- Lua provided by RyzenAPI 
-- Game: Nightmare of Decay
addappid(1848450)
addappid(1848451, 1, "f3fb9b0a6cf6e0caff896c78c1b2fb492b4d5e078b8c748475991d073f2c40c1")
