-- Lua provided by RyzenAPI
-- Game: Nurse Love Syndrome

-- MAIN APPLICATION
addappid(1023690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023691, 1, "bcc9d0587252b949dc2f1a91c4ed5b5be87ecdb1271886c1dc7858eae49af3a3")
addappid(1023692, 1, "a0e9f0b3f3b830be62f77a7f584ff53ce88cef5f33fa5c9379d023d726bffc35")
addappid(1023693, 1, "a24abe85df307d1dfdb1b28d594100e02e54a29ffaa5f24cd10f7e77df7963d5")
addappid(1023694, 1, "5255e4fef603c49c1ca7ea06f54c176285568eeb6e9f9fed349f4c653cc51cf3")
addappid(1023695, 1, "23a50c97d9cadd4c56e7d0dd632b519e2136a539003cf5d7b5855abc5c125889")
addappid(1023696, 1, "9d9bdb7dd03776f2dbebf0b28276540db3ddfe2584ffb690932c7fa47ce9f929")
