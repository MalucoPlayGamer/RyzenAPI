-- Lua provided by RyzenAPI
-- Game: addappid(362370)

-- MAIN APPLICATION
addappid(362370)

-- MAIN APP DEPOTS / PACKAGES
addappid(362372,0,"a5a04594618c061c4ab4451b30f643e651f9892c7ca45eb50beeb562589052ee")
