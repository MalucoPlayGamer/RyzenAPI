-- Lua provided by RyzenAPI
-- Game: Dog Fight

-- MAIN APPLICATION
addappid(362370)

-- MAIN APP DEPOTS / PACKAGES
addappid(362372,0,"a5a04594618c061c4ab4451b30f643e651f9892c7ca45eb50beeb562589052ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
