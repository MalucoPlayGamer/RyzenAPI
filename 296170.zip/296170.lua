-- Lua provided by SkyAPI 
-- Game: Octodad: Dadliest Catch - Soundtrack
addappid(296170)
addappid(296171, 1, "deebf74d0bd9cb13adcf4e14f54d2bb87d41bd19f9c0b6289473b1fa103335a6")
addappid(296172, 1, "455b5f685d31f70389c930e695c8a3d5a0f5379ebcec77e6283f6597398fd2d4")
