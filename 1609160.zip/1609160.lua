-- Lua provided by RyzenAPI
-- Game: Game: Waifu Secret 2

-- MAIN APPLICATION
addappid(1609160)
-- Game: addappid(1609160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609161, 1, "75e69782342bbb05f2a3d8299e964a053538927dda66e87304e046a5b182a986")
