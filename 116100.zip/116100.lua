-- Lua provided by RyzenAPI
-- Game: addappid(116100)

-- MAIN APPLICATION
addappid(116100)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(116101, 1, "ce237214d91a5d96b1c9e576cf20f7c65de12f071b57958b3b425af0b52dda79")
addappid(116102, 1, "9a80caaccc88c1af46280b6f3ad95acca7cf42e519dfa1fa6d187592e5d9be7e")
