-- Lua provided by SkyAPI 
-- Game: ReplayBellSuikaSlotLikeGame
addappid(2804960)
addappid(2804961, 1, "bd12e22e65347ac3b0c2209c694ff522339c11a98ab1a43ec41cb8b6e08c7af1")
