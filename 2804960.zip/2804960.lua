-- Lua provided by RyzenAPI
-- Game: 2804960

-- MAIN APPLICATION
addappid(2804960)
-- Game: addappid(2804960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804961, 1, "bd12e22e65347ac3b0c2209c694ff522339c11a98ab1a43ec41cb8b6e08c7af1")
