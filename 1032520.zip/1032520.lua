-- Lua provided by RyzenAPI
-- Game: 1032520

-- MAIN APPLICATION
addappid(1032520)
-- Game: addappid(1032520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032521, 1, "a27c2fe86ee168a939f990899d8fc97546d22f363410e5f352fe667a0ade0223")
