-- Lua provided by RyzenAPI 
-- Game: JermaSlots
addappid(1032520)
addappid(1032521, 1, "a27c2fe86ee168a939f990899d8fc97546d22f363410e5f352fe667a0ade0223")
