-- Lua provided by RyzenAPI
-- Game: AppID 3427510

-- MAIN APPLICATION
addappid(3427510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427511, 1, "d43334fea62be448b7afe4501727a0845cc03649c1d190dec1f2beacd72ae461")

