-- Lua provided by RyzenAPI
-- Game: Origin Story - Season 1

-- MAIN APPLICATION
addappid(3942470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3942471,0,"e3875df03e87c1f2948388564e2c33bf1df757be212d25704fa5989687045095")

