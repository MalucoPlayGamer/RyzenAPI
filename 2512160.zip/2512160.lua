-- Lua provided by RyzenAPI
-- Game: Monday Meltdown

-- MAIN APPLICATION
addappid(2512160)
addappid(2543640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512161, 1, "a990c12b173ba5dac951aea1217e0ccf212dfe6c89800e035aedcb3c943ca0cd")
addappid(2512162, 1, "52619bfe4013acfb6b94b3682be386bef81168e40a89d9a8bcf66942249858a0")
addappid(2512163, 1, "4617e3f3c1613c72db63afcfc097d1842febadb3782ab31006dce847b1eeb634")

