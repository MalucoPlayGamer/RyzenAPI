-- Lua provided by RyzenAPI
-- Game: Game: Genokids Demo

-- MAIN APPLICATION
addappid(1457880)
-- Game: addappid(1457880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457881, 1, "206d3f637181e11ae8a969176627f8c0ab3281ab776e250ebb28b9e040ae9b61")
addappid(1457882, 1, "7166382ce4d15edbb79bcafcd102026a2f7bec1a8f14a1d30dcb4fe9499cb102")
addappid(1457883, 1, "6cbfcd91f34c97bc66247d9a0727c08ddd0949f46f12d50ef045a41120778375")
addappid(1457884, 1, "e0afa6117c22523c53f62fd26df89967696b10b06cc2986caee0b7445ea83442")
