-- Lua provided by RyzenAPI
-- Game: Skylar & Plux: Adventure On Clover Island

-- MAIN APPLICATION
addappid(452540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(452541, 1, "7887bd7700fad1b76a44e5a6a2470e1061dc7878842e31bd9f19a025f52d1021")

