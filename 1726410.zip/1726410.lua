-- Lua provided by RyzenAPI
-- Game: Seal of Evil

-- MAIN APPLICATION
addappid(1726410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1726411, 1, "5504ec6c55edb102cb03f94cf63c494fb66844245909874dac94b91cd1dce89b")

