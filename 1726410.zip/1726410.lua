-- Lua provided by RyzenAPI
-- Game: Seal of Evil

-- MAIN APPLICATION
addappid(1726410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726411, 1, "5504ec6c55edb102cb03f94cf63c494fb66844245909874dac94b91cd1dce89b")
