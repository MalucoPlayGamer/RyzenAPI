-- Lua provided by RyzenAPI
-- Game: Eville Soundtrack

-- MAIN APPLICATION
addappid(2148100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148101, 1, "cff9df4ee6e63ad841ec7f223f23417ee1da838e575b128a1d9765037b0547c2")
