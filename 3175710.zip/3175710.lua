-- Lua provided by RyzenAPI
-- Game: addappid(3175710)

-- MAIN APPLICATION
addappid(3175710)
addappid(3175712)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109001,0,"c2107271672d8a49237c8ff469b1f4f64ef691dbb32e371caaa1b141017c8198")
