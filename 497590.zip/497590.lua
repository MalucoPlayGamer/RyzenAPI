-- Lua provided by RyzenAPI
-- Game: Sapper's bad dream

-- MAIN APPLICATION
addappid(497590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(497591, 1, "c6bbf2a3a45aba4c44c0eb7dcc46f09ac878405ca6e029e20a3605d1cf45cc2a")
addappid(497592, 1, "1539a8fb3bdad4f94766c5cd8e30b205f2952708dcd1003522326c576803a37f")
addappid(497593, 1, "8088d6a1295cc57872a728631664d9e51f8740c5e6c915821a4c78071774c655")

