-- Lua provided by RyzenAPI
-- Game: Minesweeper Inc.

-- MAIN APPLICATION
addappid(4999570) -- Minesweeper Inc.

-- MAIN APP DEPOTS / PACKAGES
addappid(4999571, 1, "ed231424fb8b9ee5423d357c471c864c58ab1c31c642ed93e466304d9e212597") -- Depot 4999571
