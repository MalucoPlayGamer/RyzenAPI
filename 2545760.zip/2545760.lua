-- Lua provided by RyzenAPI
-- Game: Flag Defender!

-- MAIN APPLICATION
addappid(2545760)
-- Game: addappid(2545760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545761, 1, "5b79cb9922341e3803b4e2af006fdbf16799dde4a8922b10d83f6a94a128e21c")
addappid(2545762, 1, "9798afb585baea17bb93f6e6a258041887878848bcbb6e36307b1dc753409c1c")
addappid(2545763, 1, "55629ac487fc51ddb4cd2f68d55ead627edc0fccad6df38168310754609c38bf")
