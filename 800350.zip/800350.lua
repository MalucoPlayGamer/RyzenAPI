-- Lua provided by RyzenAPI
-- Game: Game: AppID 800350

-- MAIN APPLICATION
addappid(800350)
-- Game: addappid(800350)

-- MAIN APP DEPOTS / PACKAGES
addappid(800351, 1, "bc50888353cee3dc212a73a399a4d26cc895850b15a9a38eb50bc0c042ad541a")
