-- Lua provided by RyzenAPI 
-- Game: TEMPLE of RUBBO
addappid(1927380)
addappid(1927381, 1, "98a4251833f25a8f7d72942b3858f61e40a2b275a1b4fb546f8eabb7363711d1")
