-- Lua provided by RyzenAPI
-- Game: TEMPLE of RUBBO

-- MAIN APPLICATION
addappid(1927380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1927381, 1, "98a4251833f25a8f7d72942b3858f61e40a2b275a1b4fb546f8eabb7363711d1")

