-- Lua provided by RyzenAPI
-- Game: Game: TEMPLE of RUBBO

-- MAIN APPLICATION
addappid(1927380)
-- Game: addappid(1927380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927381, 1, "98a4251833f25a8f7d72942b3858f61e40a2b275a1b4fb546f8eabb7363711d1")
