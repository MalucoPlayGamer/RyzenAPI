-- Lua provided by RyzenAPI
-- Game: Climb Challenge - Castle

-- MAIN APPLICATION
addappid(2108420)
-- Game: addappid(2108420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108421, 1, "88e31a6a7aca90baf69adffbff587fa25fc1ff3e30a32712e55bfee5d463b0f8")
