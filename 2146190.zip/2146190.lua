-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2146190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146190,0,"97016528ed92d55d222866cb6c35c602ef32ec6d23289cdf261cb89d44e4fd47")
