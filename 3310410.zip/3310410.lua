-- Lua provided by RyzenAPI
-- Game: Dominated by: Sadistic Sensei

-- MAIN APPLICATION
addappid(3310410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310412,0,"9c234d1156b0406430297dec9f71fdfa973d2a4bd53fa506a1748bbdfd86bc94")
