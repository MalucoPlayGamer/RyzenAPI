-- Lua provided by RyzenAPI
-- Game: Game: Moon's Creed

-- MAIN APPLICATION
addappid(2340510)
-- Game: addappid(2340510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340511, 1, "6f68925b081efcf091d8028396312ae6a81cbff3b3b1450b8cdf8f3645fa895a")
