-- Lua provided by RyzenAPI
-- Game: addappid(1641780)

-- MAIN APPLICATION
addappid(1641780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641781, 1, "60e4ad6ad047ffbdf7f42bf91154299fa85445e86bb2ca101e295f8bbb78f93d")
