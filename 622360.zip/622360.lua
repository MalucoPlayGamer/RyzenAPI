-- Lua provided by RyzenAPI
-- Game: addappid(622360)

-- MAIN APPLICATION
addappid(622360)
addappid(622361)
addappid(622362)

-- MAIN APP DEPOTS / PACKAGES
addappid(622360,0,"b9f54eb626613b6e3bd9b2c3b037231dbbf65f7e001c70008a8be570cb3fd936")
