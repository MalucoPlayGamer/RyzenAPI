-- Lua provided by RyzenAPI
-- Game: Game: AppID 1439160

-- MAIN APPLICATION
addappid(1439160)
-- Game: addappid(1439160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439161, 1, "747c1ecc71f5ed3453ed8a6158d61b07ea57aeb3ec70fafa90f906fba5d7b6b3")
