-- Lua provided by SkyAPI 
-- Game: AppID 1439160
addappid(1439160)
addappid(1439161, 1, "747c1ecc71f5ed3453ed8a6158d61b07ea57aeb3ec70fafa90f906fba5d7b6b3")
