-- Lua provided by RyzenAPI
-- Game: Monsters 'til Midnight

-- MAIN APPLICATION
addappid(2157250)
-- Game: addappid(2157250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157251, 1, "927c4cd93ac27c8032481232a76dc93460dc7b0edd73d97631f8a5cd9ff9f7e6")
