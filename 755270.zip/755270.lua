-- Lua provided by RyzenAPI
-- Game: Fantasia of the Wind Theme Soundtrack

-- MAIN APPLICATION
addappid(755270)
-- Game: addappid(755270)

-- MAIN APP DEPOTS / PACKAGES
addappid(755270,0,"e0f6be56632f59127054b919e26d5c9af8467f415a7243ec87ad82cfa48aa816")
