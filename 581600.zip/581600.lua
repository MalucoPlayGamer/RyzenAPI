-- Lua provided by RyzenAPI
-- Game: AppID 581600

-- MAIN APPLICATION
addappid(581600)

-- MAIN APP DEPOTS / PACKAGES
addappid(581601, 1, "e02f5cad2d78358dcca74134e7db148e32bf49118facc06fa1db53a9b34dad2b")
