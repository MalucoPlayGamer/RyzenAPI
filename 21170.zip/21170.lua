-- Lua provided by RyzenAPI
-- Game: AppID 21170

-- MAIN APPLICATION
addappid(21170)

-- MAIN APP DEPOTS / PACKAGES
addappid(21171, 1, "a763304078675b207420b54781731743d83df33ec16ecd23c39c658e35cebfdb")
addappid(21172, 1, "295183fc63f92d95877def7e2c9481ffe50dbd79d43d00123431cf9c5cbb3c96")
addappid(21173, 1, "9217dd0a246116fac206d1ca8d62d149b3e848c9b5dc94bd967f7c9fa3dd75f7")
addappid(21174, 1, "a309af4e6aa6b7b8e287eec18bae36bcda0eef9f00e4cfeb887f1abcd2f4f988")
addappid(21175, 1, "1fa5af6c1885504dafa2cc5397e70c8e8ecc1d8f095c8394d92c82d62e978c3a")
addappid(21176, 1, "d1bc303370520d6ba26171b68d2614ecd9bcbe103df3a34681e9b4669a4e00bb")
addappid(21177, 1, "4f7fd13520d75986848822f39269d17a20bdeb92c899a42e7b3dd909c610ba07")
addappid(21178, 1, "6132ffaac53827f0c59b5e655f59fb96059871c4d9f3843805353b91c3a2ae6d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(21200)
addappid(21201)
addappid(21202)
addappid(21203)
addappid(21204)
addappid(21205)
addappid(21206)
addappid(21207)
addappid(21208)
addappid(21209)
addappid(21210)
addappid(21211)
addappid(21212)
addappid(21213)
addappid(21214)
addappid(21215)
addappid(21216)
addappid(21217)
addappid(21218)
addappid(21219)
addappid(21220)
addappid(21221)
addappid(21222)
addappid(21223)
addappid(21224)
