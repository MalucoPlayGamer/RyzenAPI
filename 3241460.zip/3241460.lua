-- Lua provided by RyzenAPI
-- Game: Songs of Life Demo

-- MAIN APPLICATION
addappid(3241460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241461, 1, "0cb03b37e723865ca57c81f2fab2e8788124734559b223621892ada7d8401e57")

