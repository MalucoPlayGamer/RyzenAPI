-- Lua provided by RyzenAPI
-- Game: 3354510

-- MAIN APPLICATION
addappid(3354510)
-- Game: addappid(3354510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354510,0,"cdf9a89ede09ac5329e3ebf4a382e202362e63bcdaac2e6242724116ad9f2674")
