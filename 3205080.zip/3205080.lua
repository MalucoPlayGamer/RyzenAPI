-- Lua provided by RyzenAPI
-- Game: Bad Parenting 1: Mr. Red Face

-- MAIN APPLICATION
addappid(3205080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205081, 1, "0aafcaf23db45ca0d186061b0f4a323f8241469b9e166526250eec6d2bbeef93")

