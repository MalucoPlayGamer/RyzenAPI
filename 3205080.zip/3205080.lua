-- Lua provided by RyzenAPI
-- Game: 3205080

-- MAIN APPLICATION
addappid(3205080)
-- Game: addappid(3205080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205081, 1, "0aafcaf23db45ca0d186061b0f4a323f8241469b9e166526250eec6d2bbeef93")
