-- 985830's Lua and Manifest Created by Hubcap Manifest
-- SUCCUBUS
-- Created: September 30, 2025 at 20:38:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 20
-- Total DLCs: 15
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(985830) -- SUCCUBUS
-- MAIN APP DEPOTS
addappid(985831, 1, "e5a9251be34f44dc070b26c1e6421eabeee3675299df8975935e61325d054480") -- SUCCUBUS Content
setManifestid(985831, "7477173148538146531", 77163778600)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)
-- DLCS WITH DEDICATED DEPOTS
-- Succubus - Unrated (AppID: 1592730)
addappid(1592730)
addappid(1592730, 1, "9e0bc10b60d9063a2303b7ff234185559ae398cef5bd9e0e3eefa6792406dd63") -- Succubus - Unrated - Succubus - Unrated (1592730) - magazyn zawartości
setManifestid(1592730, "6117286811064581667", 109502399)
-- Succubus - Artbook (AppID: 1670520)
addappid(1670520)
addappid(1670520, 1, "c59389154493a22caab252ea5a940f45743c015f3f9a158d1a00457a735fcf74") -- Succubus - Artbook - Succubus - Artbook - magazyn zawartości
setManifestid(1670520, "5201675979010200179", 178698214)
-- Succubus - Comic book (AppID: 1670521)
addappid(1670521)
addappid(1670521, 1, "88ed751e69fd0e0002f68ec2c2f3de7b7b8b09a87529344f2b589f80cb06ca19") -- Succubus - Comic book - Succubus - Comic book - magazyn zawartości
setManifestid(1670521, "3706352064729976960", 145811251)
-- Succubus - Madmind Heroine (AppID: 1760290)
addappid(1760290)
addappid(1760290, 1, "b2977edf6248bcf249048aacb2e443751039544b9b0322b80c27246f208d0b9f") -- Succubus - Madmind Heroine - Succubus - Madmind Heroine (1760290) - magazyn zawartości
setManifestid(1760290, "2264033998823238095", 1850)
-- Succubus - Tight Armors (AppID: 1809150)
addappid(1809150)
addappid(1809150, 1, "139c4d457bd0ab240bc24404f0c783fbb8aa125e55f61cee4251967bbad33ad8") -- Succubus - Tight Armors - Depot 1809150
setManifestid(1809150, "7354997281633810745", 125601411)
-- Succubus - Demons of the past (AppID: 1838510)
addappid(1838510)
addappid(1838510, 1, "4762c1c7d19fad1c6a6035381036c2866cdc86391ed4f2a9158c24eaf7c6069a") -- Succubus - Demons of the past - Succubus - Demons of the past - magazyn zawartości
setManifestid(1838510, "1593880437488727157", 9883956581)
-- Succubus - Ukraine Support (AppID: 1924040)
addappid(1924040)
addappid(1924040, 1, "6e526caaf0232eb8d659c5b75643da7703ea62743dbc46398e49de5abb55a111") -- Succubus - Ukraine Support - Depot 1924040
setManifestid(1924040, "8175249717902689423", 12602618)
-- Succubus - SuperHero Armors (AppID: 1924330)
addappid(1924330)
addappid(1924330, 1, "3223533790dfc3368576c4b4f4c53998d35e5b61fc0c3cff51f4eb68415beef0") -- Succubus - SuperHero Armors - Depot 1924330
setManifestid(1924330, "9065092693274755926", 4462560340)
-- Succubus - Issabel Cosplay (AppID: 1996310)
addappid(1996310)
addappid(1996310, 1, "cea3c22cd4c03d7394bfa41b99d64e0fbf0fbbc7155437edca456a939b3e7a77") -- Succubus - Issabel Cosplay - Depot 1996310
setManifestid(1996310, "7004131799078900888", 258617617)
-- Succubus - Summer Armors (AppID: 2051000)
addappid(2051000)
addappid(2051000, 1, "fefe74d2b068d6604d6cec3f5de2586f0de14ec511b2933773f718c704d3a4da") -- Succubus - Summer Armors - Depot 2051000
setManifestid(2051000, "765912472852606939", 4414046681)
-- Succubus - Onoskelis (AppID: 2114560)
addappid(2114560)
addappid(2114560, 1, "6d302a6bd95da65a309d7742dfb8309df06a28a6472b36a7c0e45b167a26c75e") -- Succubus - Onoskelis - Depot 2114560
setManifestid(2114560, "7573780897679084523", 4343957205)
-- Succubus - Halloween Nasty Outfits (AppID: 2119920)
addappid(2119920)
addappid(2119920, 1, "ff2421ef63bf3fa8d3585c9b6fc1014efc743649e3b734527c08c4b57fb7b34b") -- Succubus - Halloween Nasty Outfits - Depot 2119920
setManifestid(2119920, "2013571230642874720", 4481609071)
-- Succubus - Red Goddess (AppID: 2119922)
addappid(2119922)
addappid(2119922, 1, "e71030dd071ad4e8f274d1437e58c436fbbb5e0197d2eada57eefab6987bfcc6") -- Succubus - Red Goddess - Depot 2119922
setManifestid(2119922, "8479478883923473837", 15097451224)
-- Succubus - Tormentress (AppID: 2959800)
addappid(2959800)
addappid(2959800, 1, "9017ffefba75da1ca060d2b4e49a299801a2663467be1974d600ad01934e1a19") -- Succubus - Tormentress - Depot 2959800
setManifestid(2959800, "6461140497283898776", 12614855985)
-- Succubus - Elysian Fields (AppID: 3057500)
addappid(3057500)
addappid(3057500, 1, "4343c0d630c8eded1acaa32860e412905537e3c0ce314ecc22b2bbc6f578e32d") -- Succubus - Elysian Fields - Depot 3057500
setManifestid(3057500, "1930164408404408896", 4000)