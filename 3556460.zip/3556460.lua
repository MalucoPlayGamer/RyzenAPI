-- Lua provided by RyzenAPI
-- Game: 3556460

-- MAIN APPLICATION
addappid(3556460)
-- Game: addappid(3556460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3556461, 1, "651e5c6239cb3c767b8d7a243b1aadd43b122651fdf60b2c75c2864f9c289ed0")
