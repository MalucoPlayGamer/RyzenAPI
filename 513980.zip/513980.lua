-- Lua provided by SkyAPI 
-- Game: AppID 513980
addappid(513980)
addappid(513981, 1, "a79255e5f79f547dbdd8c016d1d7f3756436a84f44728a18b4a52ff16a870188")
