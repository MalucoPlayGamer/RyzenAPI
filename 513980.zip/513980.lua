-- Lua provided by RyzenAPI
-- Game: 513980

-- MAIN APPLICATION
addappid(513980)
-- Game: addappid(513980)

-- MAIN APP DEPOTS / PACKAGES
addappid(513981, 1, "a79255e5f79f547dbdd8c016d1d7f3756436a84f44728a18b4a52ff16a870188")
