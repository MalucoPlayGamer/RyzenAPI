-- Lua provided by RyzenAPI
-- Game: Daisy Flies to the Moon

-- MAIN APPLICATION
addappid(1395710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395711, 1, "bd3b4bf7dbf1d0897b11e8f3229a0c3b9a73f1a96b2824d611b66c875022f057")

