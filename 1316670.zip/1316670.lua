-- Lua provided by RyzenAPI
-- Game: Game: DEEMO -Reborn- OST VOL.1

-- MAIN APPLICATION
addappid(1316670)
-- Game: addappid(1316670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316671, 1, "8324432f88261451e26757a54a2c61c3c827d3ce55b32fb5ad6217fe3f7e43ed")
