-- Lua provided by RyzenAPI
-- Game: Lovecraft Quest - A Comix Game

-- MAIN APPLICATION
addappid(952460)

-- MAIN APP DEPOTS / PACKAGES
addappid(952461, 1, "21d7e407414611bd72b399f8ec80f89d9046804248419057d3d03139bb87d499")
