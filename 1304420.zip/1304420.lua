-- Lua provided by RyzenAPI
-- Game: Game: Super Cable Boy

-- MAIN APPLICATION
addappid(1304420)
-- Game: addappid(1304420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304421, 1, "e205c5d1ccb77b76236c986af6b1a9b1af9e7d24f8058bcc61dd7c1f38a7ae32")
addappid(1304422, 1, "cede9ebc8366156631343b3e5b9d3e1a3b40cca3e2d76b3944dfc77a6807927e")
addappid(1304423, 1, "6f18ee04adb191661ab43a2960f2f339c59ef43308dd73a8756b030b648f1164")
