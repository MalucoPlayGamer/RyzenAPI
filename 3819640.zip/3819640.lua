-- Lua provided by RyzenAPI
-- Game: Megastore Simulator

-- MAIN APPLICATION
addappid(3819640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3819641, 1, "cd3a3b0b3ca76fc3fd11c8c5426cc433df4d406d30e4d4fce18621a4742cdd64")

