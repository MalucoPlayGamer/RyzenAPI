-- Lua provided by SkyAPI 
-- Game: Nayati River
addappid(1278150)
addappid(1278151, 1, "3e237eacaa2b74949c5a3471808a8b20cb133e0f21ad662a6b9385a72d79da97")
