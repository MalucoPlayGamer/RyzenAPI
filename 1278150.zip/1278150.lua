-- Lua provided by RyzenAPI
-- Game: Nayati River

-- MAIN APPLICATION
addappid(1278150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278151, 1, "3e237eacaa2b74949c5a3471808a8b20cb133e0f21ad662a6b9385a72d79da97")
