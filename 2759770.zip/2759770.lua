-- Lua provided by RyzenAPI
-- Game: Anji -Implication-

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2759770)
addappid(2759772)
addappid(2759773)
addappid(2759774)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759775,0,"abde68be05f30da208312cd9f66865123c006d92c63112940b003a2be1d3814d")
