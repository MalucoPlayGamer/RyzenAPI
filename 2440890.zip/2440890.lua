-- Lua provided by RyzenAPI
-- Game: Game: Nobody Nowhere

-- MAIN APPLICATION
addappid(2440890)
-- Game: addappid(2440890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440891, 1, "57014a8c9e570e3251a1614e3bbd9dc7433a932543998b829f80ea7e64fc46dd")
