-- Lua provided by RyzenAPI
-- Game: addappid(776490)

-- MAIN APPLICATION
addappid(776490)

-- MAIN APP DEPOTS / PACKAGES
addappid(776491, 1, "69fca9154f831bbcd5c53ce8e95a2a7b986a2a9a2858071b3ba4061ae7dd7a7d")
