-- Lua provided by RyzenAPI
-- Game: 永远消失的幻想乡 ～ The Disappearing of Gensokyo

-- MAIN APPLICATION
addappid(776490)
addappid(778530)
addappid(779280)
addappid(780980)
addappid(780990)
addappid(781010)
addappid(781020)

-- MAIN APP DEPOTS / PACKAGES
addappid(776491, 1, "69fca9154f831bbcd5c53ce8e95a2a7b986a2a9a2858071b3ba4061ae7dd7a7d")

