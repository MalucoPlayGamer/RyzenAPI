-- Lua provided by RyzenAPI
-- Game: addappid(1443440)

-- MAIN APPLICATION
addappid(1443440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443441, 1, "88e2aba0576af8a77ba8fb6f9a4f96aa03f43a1a790544a33dee9020b66717ce")
