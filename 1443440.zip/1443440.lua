-- Lua provided by RyzenAPI 
-- Game: Little Nightmares II Demo
addappid(1443440)
addappid(1443441, 1, "88e2aba0576af8a77ba8fb6f9a4f96aa03f43a1a790544a33dee9020b66717ce")
