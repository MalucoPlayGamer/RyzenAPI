-- Lua provided by RyzenAPI
-- Game: AppID 393520

-- MAIN APPLICATION
addappid(393520)

-- MAIN APP DEPOTS / PACKAGES
addappid(393521, 1, "00b2381823e829ba89bfe29a991fea979cc1ae4787740940723f0a81ed0b7e38")
addappid(393523, 1, "7aae2f5d20f83ffda57e95369f0ceed65d827ce720f92b68c97e88fc25b9fbd8")
addappid(393524, 1, "c350775c1f99ea1a4a8ebe5baf6d43d92f7ed50cddb367baaf049c1775d9a983")
