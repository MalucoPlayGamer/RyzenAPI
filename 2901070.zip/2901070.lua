-- Lua provided by RyzenAPI
-- Game: The Simulation

-- MAIN APPLICATION
addappid(2901070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2901071, 1, "3bcdacc25ac903dad651105a3e5aea7cbbaf04086da0d268d9d75c62d5a753e1")

