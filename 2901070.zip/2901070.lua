-- Lua provided by RyzenAPI
-- Game: The Simulation

-- MAIN APPLICATION
addappid(2901070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901071, 1, "3bcdacc25ac903dad651105a3e5aea7cbbaf04086da0d268d9d75c62d5a753e1")

