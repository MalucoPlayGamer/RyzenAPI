-- Lua provided by RyzenAPI
-- Game: FARLAND SAGA I Saturn Tribute Sound Tracks

-- MAIN APPLICATION
addappid(3773550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3773551, 1, "4a69cea748ee60b228774cc5664562e61989c868f2530313da8ce75041de9136")

