-- Lua provided by SkyAPI 
-- Game: Ghostwire: Tokyo
addappid(1475810)
addappid(1475811, 1, "6044597d5ce5e2a639d6651712701e816115dca897c115e8cd756c0b2cae4454")
addappid(1475812, 1, "3943ef5d4b3a97877847fe80d0e0662bf583777800d70f80a04946dd3ff39143")
