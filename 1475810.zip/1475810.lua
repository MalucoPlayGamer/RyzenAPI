-- Lua provided by RyzenAPI
-- Game: Ghostwire: Tokyo

-- MAIN APPLICATION
addappid(1475810)
addappid(1702820)
addappid(1702821)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1475811, 1, "6044597d5ce5e2a639d6651712701e816115dca897c115e8cd756c0b2cae4454")
addappid(1475812, 1, "3943ef5d4b3a97877847fe80d0e0662bf583777800d70f80a04946dd3ff39143")

