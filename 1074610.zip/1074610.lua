-- Lua provided by RyzenAPI
-- Game: addappid(1074610)

-- MAIN APPLICATION
addappid(1074610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074611, 1, "cd4fd6686128119834ec29241c50a43a056ed7dea6f2e4ec20cdb457e009fea1")
