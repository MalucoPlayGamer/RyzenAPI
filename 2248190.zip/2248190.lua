-- Lua provided by RyzenAPI
-- Game: addappid(2248190)

-- MAIN APPLICATION
addappid(2248190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248191, 1, "4e38a18de70d41c67d0a49c6e05a0a9bd6cea56b7d97f1670102de574233916e")
