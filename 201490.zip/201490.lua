-- Lua provided by RyzenAPI
-- Game: Airline Tycoon 2

-- MAIN APPLICATION
addappid(201490)
addappid(206881)
addappid(206882)

-- MAIN APP DEPOTS / PACKAGES
addappid(201491, 1, "42dc780cee21bf5275c2117501023dc272fc73046c5c69994ebdedb73e7a9980")
addappid(201492, 1, "b269b3cf1feaf05c3991546aefe2b07331ec4082a366d174efbc84c7f071f145")
addappid(201493, 1, "12208e7500747e740a3789bb20000800c61a6ed7a322e1d2a0dd9d1a65ee18db")
addappid(201494, 1, "1feeeeda544e1e1d488d921b7a1a17af57e4223a816ba1efb25d251340bd1731")
addappid(201495, 1, "45d2d4055d80a8a641a1a8c0f32b8f97f14418005cfc16c49a07a5ea8e6f0844")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(206880)
