-- Lua provided by RyzenAPI
-- Game: Abys Orbit

-- MAIN APPLICATION
addappid(5007590)
