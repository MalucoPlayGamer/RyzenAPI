-- Lua provided by RyzenAPI 
-- Game: AppID 201830
addappid(201830)
addappid(201831, 1, "5569310179b8ae5de5982bcd17bf7b09cafe15ba67b6e1f399af857dc7c7f2a5")
addappid(201832, 1, "07b49dc7e3d521e833b49047546940206b568640c8576a3059f971ad8bf855ef")
