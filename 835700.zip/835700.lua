-- Lua provided by RyzenAPI
-- Game: 835700

-- MAIN APPLICATION
addappid(835700)
-- Game: addappid(835700)

-- MAIN APP DEPOTS / PACKAGES
addappid(835701, 1, "545822290ec8d0df39d2974ee8ed07285a2c35f258413ad6823c58211f21c9d8")
