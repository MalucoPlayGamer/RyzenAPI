-- Lua provided by RyzenAPI
-- Game: 991060

-- MAIN APPLICATION
addappid(991060)
-- Game: addappid(991060)

-- MAIN APP DEPOTS / PACKAGES
addappid(991060,0,"0e090c15c02e5972a12eeb53a658f544aadb60f2addcb79b6846fe715c70c20a")
