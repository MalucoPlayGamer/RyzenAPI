-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Faroe Islands XP

-- MAIN APPLICATION
addappid(991060)

-- MAIN APP DEPOTS / PACKAGES
addappid(991060,0,"0e090c15c02e5972a12eeb53a658f544aadb60f2addcb79b6846fe715c70c20a")

