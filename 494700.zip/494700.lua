-- Lua provided by SkyAPI 
-- Game: AppID 494700
addappid(494700)
addappid(494701, 1, "37663d992f68a134d216cd03428468b0e05f79644797f67c991ff921538a19e5")
