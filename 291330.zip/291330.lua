-- Lua provided by RyzenAPI
-- Game: addappid(291330)

-- MAIN APPLICATION
addappid(291330)

-- MAIN APP DEPOTS / PACKAGES
addappid(291331, 1, "c984bb59d804b5bdbad622fe2e5cf1f4e4ed4f7c919f3d1b5c98a7fb5e993aee")
