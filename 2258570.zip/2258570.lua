-- Lua provided by RyzenAPI
-- Game: addappid(2258570)

-- MAIN APPLICATION
addappid(2258570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258571, 1, "4a7c0b4c4a02b33f6a19a15616ad3e6a37c24dc6bd63a0ea9033bbcdb01590d8")
