-- Lua provided by RyzenAPI
-- Game: Game: Kaboom Monsters

-- MAIN APPLICATION
addappid(461490)
-- Game: addappid(461490)

-- MAIN APP DEPOTS / PACKAGES
addappid(461491, 1, "e00edb48b627e05ff8e52fb0edc8b5b7e423905997f9d1fa62cda881e37bb80c")
