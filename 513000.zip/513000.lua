-- Lua provided by RyzenAPI 
-- Game: KUBOOM
addappid(513000)
addappid(513001, 1, "9bb41e239868d7d49d07d59d1d82de9b04066ae3767682de2fccee672f88d2d8")
addappid(550050)
