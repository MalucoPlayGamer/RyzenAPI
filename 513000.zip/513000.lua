-- Lua provided by RyzenAPI
-- Game: KUBOOM

-- MAIN APPLICATION
addappid(513000)
addappid(550050)

-- MAIN APP DEPOTS / PACKAGES
addappid(513001, 1, "9bb41e239868d7d49d07d59d1d82de9b04066ae3767682de2fccee672f88d2d8")

