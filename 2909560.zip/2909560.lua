-- Lua provided by RyzenAPI 
-- Game: SoulShake
addappid(2909560)
addappid(2909561, 1, "d8d66ebaa43e07abe64e4fd9d8e7f68d4efb1aac075500b8ced8dd180e2b48ad")
