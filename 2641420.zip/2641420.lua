-- Lua provided by RyzenAPI
-- Game: 2641420

-- MAIN APPLICATION
addappid(2641420)
-- Game: addappid(2641420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641421, 1, "84b38c5d572f93478ab1c950d2fe23d9205d4b5e6823d70c9c9ee10b26a4d1ee")
