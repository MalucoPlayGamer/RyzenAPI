-- Lua provided by RyzenAPI
-- Game: VoidBound

-- MAIN APPLICATION
addappid(2500710)
-- Game: addappid(2500710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500711, 1, "7652e1f524e128a675ae5781df8731e8cba8bfb20e81868fdcac46e4ca45b94c")
