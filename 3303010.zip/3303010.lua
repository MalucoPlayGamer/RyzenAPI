-- Lua provided by SkyAPI 
-- Game: Katana Dragon
addappid(3303010)
addappid(3303011, 1, "6162f374449a9ca0a06f8caae7a1558311d59d83671d0c3d04064308e171a850")
