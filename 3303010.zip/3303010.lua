-- Lua provided by RyzenAPI
-- Game: Katana Dragon

-- MAIN APPLICATION
addappid(3303010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3303011, 1, "6162f374449a9ca0a06f8caae7a1558311d59d83671d0c3d04064308e171a850")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3594600)
addappid(3594870)
