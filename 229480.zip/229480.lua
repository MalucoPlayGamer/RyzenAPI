-- Lua provided by RyzenAPI
-- Game: Dungeons & Dragons: Chronicles of Mystara

-- MAIN APPLICATION
addappid(229480)

-- MAIN APP DEPOTS / PACKAGES
addappid(229481, 1, "70fdd0e29f3065e4da04ee358197903c1dde835c271fb99355d91460122a54e0")

