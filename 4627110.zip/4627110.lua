-- Lua provided by RyzenAPI
-- Game: Fell & Sell

-- MAIN APPLICATION
addappid(4627110) -- Fell & Sell

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4627111, 1, "28d630c42b8cba00c7b125084e4b7882fd121590cc2e1696e72ad68d6193d0e4") -- Depot 4627111

