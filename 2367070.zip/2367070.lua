-- Lua provided by RyzenAPI
-- Game: AppID 2367070

-- MAIN APPLICATION
addappid(2367070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367071, 1, "44d1d55beafd2b9d5b62fdb286df42c10a4fbf312b81c9130beef306dd876e17")

