-- Lua provided by RyzenAPI
-- Game: AMD Driver Updater, Vista and 7, 32 bit

-- MAIN APPLICATION
addappid(61800)

-- MAIN APP DEPOTS / PACKAGES
addappid(61801, 1, "5a042e37f478b7acab72d300b07af9bb22af6027a6569c8b8b6b085e56dd9b6f")
