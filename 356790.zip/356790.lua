-- Lua provided by RyzenAPI
-- Game: Galacide

-- MAIN APPLICATION
addappid(356790)
addappid(500910)

-- MAIN APP DEPOTS / PACKAGES
addappid(356791, 1, "2f7c20494545cfa8c62110cde16ae2efe5fd74c56ca09b9e5e915a859016f341")
addappid(356792, 1, "e1d092b508c016f919c188d88f7288380427f0033040cad09c7f0b5b5db9ddfd")
addappid(356794, 1, "2f7899ea46db4662442af3c3dea46a3fa3f029d1f4cf72ae18fdac0d9d003398")
addappid(395290, 0, "b59fd1a346665ba6266e64488823aab35c319166687d5dc4ddb6da912ad6d16a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
