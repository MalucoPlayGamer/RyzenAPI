-- Lua provided by RyzenAPI
-- Game: Click and Slay

-- MAIN APPLICATION
addappid(1716690)
-- Game: addappid(1716690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716691, 1, "82dfb37e44ad4995693886144e76e578cb24f30e2bcda4cfb159d2b17a9f5b16")
