-- Lua provided by RyzenAPI
-- Game: Game: Crystal matrix

-- MAIN APPLICATION
addappid(3693580)
-- Game: addappid(3693580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3693581, 1, "e62f059267516bd9800202c35baa97ddb557276d85a981be026fdc6e337187c3")
