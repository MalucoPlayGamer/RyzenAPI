-- Lua provided by RyzenAPI
-- Game: Death and Taxes Demo

-- MAIN APPLICATION
addappid(1166300)
-- Game: addappid(1166300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166301, 1, "c6ff8042828be0235a082dce69be7aa19eeb9dc131b1880e6bf7e6f02aca0f48")
