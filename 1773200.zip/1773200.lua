-- Lua provided by RyzenAPI
-- Game: Game: NMNE

-- MAIN APPLICATION
addappid(1773200)
-- Game: addappid(1773200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773201, 1, "108d17c52a65240549576658a83b0a0dda7ee62f67a9d8d366468cefd7976d05")
