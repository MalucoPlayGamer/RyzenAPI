-- Lua provided by RyzenAPI
-- Game: Zombeer

-- MAIN APPLICATION
addappid(262190)

-- MAIN APP DEPOTS / PACKAGES
addappid(262191, 1, "4c222793ff6ea3ccc35f02530e664d0022f0640361b02ad8f96d13762b69b403")

