-- Lua provided by RyzenAPI
-- Game: Zombeer

-- MAIN APPLICATION
addappid(262190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(262191, 1, "4c222793ff6ea3ccc35f02530e664d0022f0640361b02ad8f96d13762b69b403")

