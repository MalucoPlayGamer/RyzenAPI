-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Ghost Recon Advanced Warfighter®

-- MAIN APPLICATION
addappid(13640)
-- Game: addappid(13640)

-- MAIN APP DEPOTS / PACKAGES
addappid(13641, 1, "32ff916070ff0eddd05d5f5283c7ad801552b1cf0d751667a2596cb59039cc23")
addappid(13642, 1, "832d2c48343fb6f0b26f9e7cf1fcea2d99b75f2a04adfc9ae1baa737e4db0606")
addappid(13643, 1, "923125bd7f53c87f3b7c9ca17aff92c9b7094ec420830967d160347487a33d04")
addappid(13644, 1, "5f51b5ec22828b02afe2bb65ea3a1411a3abb5db7d0492cb5c9bd8e6e0c1afac")
addappid(13645, 1, "084855f220f95f5afc219e8712e901888b013eb93abc30279545f360cb78d5d4")
addappid(13646, 1, "8f4b9636dedbdc9cd3835cba62788d14d0c52aec5002e5595b22d1e5e6b78a20")
