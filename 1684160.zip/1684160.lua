-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9 Empires - Unisex Custom Angelic Armor Set

-- MAIN APPLICATION
addappid(1684160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684160,0,"cc8112668950e6262302475708bd2316bf864176da0f790e4db07614743299aa")

