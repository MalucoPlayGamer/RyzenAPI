-- Lua provided by RyzenAPI
-- Game: AppID 926210

-- MAIN APPLICATION
addappid(926210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(926211, 1, "5490eeeca2a5d29ba24da886aaa0d7e16818f751e526ca2bdf2bae4152253463")

