-- Lua provided by RyzenAPI
-- Game: addappid(926210)

-- MAIN APPLICATION
addappid(926210)

-- MAIN APP DEPOTS / PACKAGES
addappid(926211, 1, "5490eeeca2a5d29ba24da886aaa0d7e16818f751e526ca2bdf2bae4152253463")
