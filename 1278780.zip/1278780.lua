-- Lua provided by RyzenAPI
-- Game: AppID 1278780

-- MAIN APPLICATION
addappid(1278780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278781, 1, "1bf060ab38ff28b6e37725dabc0536cd2e9a5920e8327fe84f627bf75e91fbea")
addappid(1278782, 1, "b4443d9adb29f804e053c80d41163ab9bf738ed7845b44bc528275261bd47890")
addappid(1278783, 1, "e0203ee2c0c9fe7372ed8e30472d990d76c4f11cf51e1496760697e47ff18e59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
