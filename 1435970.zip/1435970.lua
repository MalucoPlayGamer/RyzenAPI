-- Lua provided by RyzenAPI
-- Game: 1435970

-- MAIN APPLICATION
addappid(1435970)
-- Game: addappid(1435970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435971, 1, "4ad20283ec8ad9127ec0472e4078ef6aa667195d8c138718f2bb28b3e5339af5")
