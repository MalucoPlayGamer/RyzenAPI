-- Lua provided by RyzenAPI
-- Game: Anomalous

-- MAIN APPLICATION
addappid(1435970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1435971, 1, "4ad20283ec8ad9127ec0472e4078ef6aa667195d8c138718f2bb28b3e5339af5")

