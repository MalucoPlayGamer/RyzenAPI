-- Lua provided by RyzenAPI 
-- Game: Papercut Art Gallery-Growth
addappid(2930890)
addappid(2930891, 1, "d7d1fbb62b65090422e5236a6f43a01573f46f0fe3985ef404aa2d0a99a6dc8b")
