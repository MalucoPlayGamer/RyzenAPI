-- Lua provided by RyzenAPI
-- Game: Game: Into The Haze

-- MAIN APPLICATION
addappid(1430640)
-- Game: addappid(1430640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430641, 1, "710b45280a5e3968693adce2914b7e6624eed7a761784a420272a95b6caae23b")
