-- Lua provided by RyzenAPI
-- Game: Heroes of Might and Magic: Olden Era

-- MAIN APPLICATION
addappid(3105440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3105441,0,"ed44e10054a9907358f5bd7827b31171c8ba2e2a11b5b8a738ecd73dd62b0424")

