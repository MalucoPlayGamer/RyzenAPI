-- Lua provided by RyzenAPI
-- Game: Game: Njorun's Will Demo

-- MAIN APPLICATION
addappid(2222290)
-- Game: addappid(2222290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222291, 1, "64f77c7598e5f498744985f5b86086b34b82af51002c1962764852ede1d5e1d9")
