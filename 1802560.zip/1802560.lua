-- Lua provided by RyzenAPI
-- Game: 1802560

-- MAIN APPLICATION
addappid(1802560)
-- Game: addappid(1802560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802561, 1, "eb330d8c4c262fdc0c4067217daa9904810b44907efc2ac625f912e183766d14")
