-- Lua provided by RyzenAPI 
-- Game: SEARCH ALL - ADULT
addappid(1802560)
addappid(1802561, 1, "eb330d8c4c262fdc0c4067217daa9904810b44907efc2ac625f912e183766d14")
