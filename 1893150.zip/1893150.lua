-- Lua provided by RyzenAPI
-- Game: COG Back To The 80s

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(229007)
addappid(1893150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893159,0,"47389fcf715b973e365ce1c1775b801c80a055c02a1fe009b799d3febfc81234")

