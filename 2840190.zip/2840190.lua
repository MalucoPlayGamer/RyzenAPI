-- Lua provided by RyzenAPI
-- Game: Great God Grove

-- MAIN APPLICATION
addappid(2840190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840191, 1, "25c476bf814907c839b026531dcd0a67dfa30547b7f3e9039448477d6c832c8b")
