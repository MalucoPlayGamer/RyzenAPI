-- Lua provided by RyzenAPI
-- Game: Cosmoblaster Exodia

-- MAIN APPLICATION
addappid(1914200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914201, 1, "b2131fac6f67738ca82992c2557f550a5f62d273d962b77af5b7f95c6168e375")
