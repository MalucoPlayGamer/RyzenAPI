-- Lua provided by SkyAPI 
-- Game: Goblins and Grottos
addappid(389190)
addappid(389191, 1, "1d6d01b4801e7c211069ee738be4051962308d42cea16bf2826f2f5b3d6432f2")
addappid(512290, 0, "bec425373622fd15c9bde47403e20981c69e3fdf43c3a771a05bcbd248007bd5")
