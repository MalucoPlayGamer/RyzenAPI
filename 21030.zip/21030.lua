-- Lua provided by RyzenAPI 
-- Game: AppID 21030
addappid(21030)
addappid(21031, 1, "498a8ce88548e7cb97e9ccc3e31f90f9bf076ca736a6e410d8943ef7214c803d")
