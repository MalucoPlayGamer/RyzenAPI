-- Lua provided by RyzenAPI
-- Game: Game: Medieval Kingdom Wars Story

-- MAIN APPLICATION
addappid(2596640)
-- Game: addappid(2596640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596641, 1, "9f1d597a82a031d1ea710b01ec40b2b911e7e5b495c51dc840f96e3b6cfff253")
