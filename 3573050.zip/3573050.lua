-- Lua provided by RyzenAPI
-- Game: addappid(3573050)

-- MAIN APPLICATION
addappid(3573050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573051, 1, "0084bd31cb752f24bdf4fe3ba2e9df9b0136f7eaf87ec70ec949790dc3f7012c")
