-- Lua provided by RyzenAPI
-- Game: Virtual Villagers: The Lost Children Demo

-- MAIN APPLICATION
addappid(16150)

-- MAIN APP DEPOTS / PACKAGES
addappid(16151, 1, "96f27b5204bf03dfc189b4dac8f14c12a6347941da4c330e69ade3634a6e5afa")
