-- Lua provided by SkyAPI 
-- Game: AppID 2840250
addappid(2840250)
addappid(2840251, 1, "57be2e7b3a1f0fbe374c32f7d795bf8c70b072676cf646ed093670ed13ba3c8f")
