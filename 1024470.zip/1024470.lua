-- Lua provided by RyzenAPI
-- Game: La Fuga

-- MAIN APPLICATION
addappid(1024470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024471, 1, "935b664f2952364a503e4e79cb6066cc8e85028b88cd0d4ce6d810ac16f8d7f1")
