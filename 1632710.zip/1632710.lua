-- Lua provided by RyzenAPI
-- Game: VR Nudity Camping

-- MAIN APPLICATION
addappid(1632710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632711, 1, "40e8510c8d5b286d343090ecb45bc5c32e70e132e0ba7f001d7903c4986fcb52")

