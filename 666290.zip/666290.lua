-- Lua provided by RyzenAPI
-- Game: AppID 666290

-- MAIN APPLICATION
addappid(666290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(666291, 1, "243b4677ce55e9b0ec1bfdca8e8d3ab89383e723c92a61dfde406a94f8217e6c")

