-- Lua provided by RyzenAPI
-- Game: Game: Hotel on the Grate

-- MAIN APPLICATION
addappid(1785460)
-- Game: addappid(1785460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785461, 1, "c6d010bbc74103fd92658bd7cef8b79632828f17d54432adea9af1344e0e73fe")
addappid(1785462, 1, "551ffbf9f436d1e13fbf2ef898f7173e24f1e0bd3afd347280da50daef399cdc")
