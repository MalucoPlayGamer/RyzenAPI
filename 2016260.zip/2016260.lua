-- Lua provided by RyzenAPI
-- Game: Deliver Us Mars Original Soundtrack

-- MAIN APPLICATION
addappid(2016260)
-- Game: addappid(2016260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016261, 1, "707e366a2fdb141f2f96ccf017061d3fd523daef2f8a47a06d578a43a21d3958")
addappid(2016262, 1, "a1222dd0b17ed600f85be81b8046629956183aa3a3e5a19d875e47f0f197352b")
