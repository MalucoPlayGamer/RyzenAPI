-- Lua provided by RyzenAPI
-- Game: 2555430

-- MAIN APPLICATION
addappid(2555430)
addappid(3751590)
-- Game: addappid(2555430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555431, 1, "18aecd28f1a2e9ac4ba577111bd5c963487b23b817f4b2210363f1bd00b08064")
