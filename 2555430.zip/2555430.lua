-- Generated with Luie @ https://lua.tools/
-- 2555430 - TRADESMAN: Deal to Dealer
-- Generated 2026-08-28 04:30:24 UTC
-- # Depots (Total/DLC/Shared): 2/0/1

-- Main AppID
addappid(2555430)

-- Main Depots
addappid(2555431, 1, "18aecd28f1a2e9ac4ba577111bd5c963487b23b817f4b2210363f1bd00b08064") -- (windows)
setManifestid(2555431, "6886609785377758784", 162706209)

-- DLC's (no depot keys required)
addappid(3751590) -- TRADESMAN: Deal to Dealer - HATS Supporter Pack
addappid(5097380) -- TRADESMAN: Deal to Dealer - Donkey Support Pack

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
