-- Lua provided by RyzenAPI
-- Game: TRADESMAN: Deal to Dealer

-- MAIN APPLICATION
addappid(2555430)
addappid(3751590) -- TRADESMAN: Deal to Dealer - HATS Supporter Pack
addappid(5097380) -- TRADESMAN: Deal to Dealer - Donkey Support Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2555431, 1, "18aecd28f1a2e9ac4ba577111bd5c963487b23b817f4b2210363f1bd00b08064") -- (windows)

