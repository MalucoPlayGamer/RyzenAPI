-- Lua provided by RyzenAPI
-- Game: Game: Tribe: Primitive Builder

-- MAIN APPLICATION
addappid(1059900)
-- Game: addappid(1059900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059901, 1, "1e29a8ec0be8503eb1df392dbedd81117d6763820605a731f15cdf91b45629ef")
