-- Lua provided by RyzenAPI
-- Game: Cat God Ranch

-- MAIN APPLICATION
addappid(2797340)
addappid(3795220)
addappid(4575460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797341, 1, "4adf02cfdd9a75f570ed860197c2c5d7565aa95826e5a3da4afecccc758f7438")

