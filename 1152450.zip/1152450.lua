-- Lua provided by RyzenAPI
-- Game: Creeps Creeps? Creeps!

-- MAIN APPLICATION
addappid(1152450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152451, 1, "2d7951595b6a90c66f6746441dd61eab34b00d3e01e9ffcbbf7ac24f44b3894b")
