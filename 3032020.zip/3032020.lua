-- Lua provided by RyzenAPI
-- Game: 3032020

-- MAIN APPLICATION
addappid(3032020)
-- Game: addappid(3032020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032021, 1, "895cdbd736b06ba1b5847b5f004439ec4e5c858a703376492b9a6eceddc905fb")
