-- Lua provided by RyzenAPI
-- Game: Cast & Spell

-- MAIN APPLICATION
addappid(3032020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3032021, 1, "895cdbd736b06ba1b5847b5f004439ec4e5c858a703376492b9a6eceddc905fb")

