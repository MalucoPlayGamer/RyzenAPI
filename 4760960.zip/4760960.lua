-- Lua provided by RyzenAPI
-- Game: Touch Me II

-- MAIN APPLICATION
addappid(4760960) -- Touch Me II

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4760961, 1, "549615696253a3374e4a4d3e41ae434eb2060eef1bdf13e36eb0ac67b4ad3f54") -- Depot 4760961

