-- Lua provided by RyzenAPI
-- Game: Man I Just Wanna Go Home

-- MAIN APPLICATION
addappid(3010070)
-- Game: addappid(3010070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3010071, 1, "202d6832e83f15d9adfec7af17c2555e873bdeda6f5923d649f57a2fa290a7d5")
