-- Lua provided by RyzenAPI
-- Game: AppID 225120

-- MAIN APPLICATION
addappid(225120)

-- MAIN APP DEPOTS / PACKAGES
addappid(225121, 1, "07cdabb45e17f7d27670d7c516cc53c7700e4e00968fbdd6ecd9e6244d6e7047")
