-- Lua provided by RyzenAPI 
-- Game: Shop Simulator: Supermarket
addappid(2886550)
addappid(2886551, 1, "c45ad22173947bbf5832b1f116c6a6e2d11b8daf01faab90de2d8b98cedfa69a")
