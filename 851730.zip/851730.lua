-- Lua provided by RyzenAPI
-- Game: Sandmade

-- MAIN APPLICATION
addappid(851730)

-- MAIN APP DEPOTS / PACKAGES
addappid(851731, 1, "507381a6413e44d6566f952171ded14e80c967b6d6883299f1bc61d782e7be10")

