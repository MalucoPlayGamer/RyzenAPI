-- Lua provided by RyzenAPI
-- Game: 1295890

-- MAIN APPLICATION
addappid(1295890)
-- Game: addappid(1295890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295891, 1, "54ba74fa1ad00bca9c9e68be448e5fb36c97136afb82fa6790c17f14b2d7c197")
