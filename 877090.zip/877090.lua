-- Lua provided by RyzenAPI
-- Game: Yoku's Island Express Demo

-- MAIN APPLICATION
addappid(877090)

-- MAIN APP DEPOTS / PACKAGES
addappid(877091, 1, "8296f29bed87506a8d5e9f4b3575cd8136014c06b6ce879d235f1da9f17beaca")
