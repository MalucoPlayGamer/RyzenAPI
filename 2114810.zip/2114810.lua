-- Lua provided by RyzenAPI 
-- Game: Tetris Girls
addappid(2114810)
addappid(2114811, 1, "38f7857b8eb625d1c32b07c978753617061f2189a5fd364f3dde44431801bf90")
