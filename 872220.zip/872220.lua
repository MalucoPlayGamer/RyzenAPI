-- Lua provided by RyzenAPI 
-- Game: AppID 872220
addappid(872220)
addappid(872221, 1, "b2566207b77125b615a4f4bd05186735e36a1c821645818ea47ad0d4e4104ad6")
