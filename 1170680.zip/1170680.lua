-- Lua provided by RyzenAPI
-- Game: 1170680

-- MAIN APPLICATION
addappid(1170680)
-- Game: addappid(1170680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170681, 1, "40ae1a062993f3874980e5d8b306ecfa6067e0bd13c2d6adb46d3705dfd6bba7")
