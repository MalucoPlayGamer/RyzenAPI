-- Lua provided by RyzenAPI
-- Game: 2623570

-- MAIN APPLICATION
addappid(2623570)
-- Game: addappid(2623570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623571, 1, "9afd160a45bcfa1c34509039e72b9ca75ccf7fa96e5c06186d975ce562d9e1ba")
