-- Lua provided by RyzenAPI
-- Game: Sweet Transit Official Soundtrack

-- MAIN APPLICATION
addappid(2094110)
-- Game: addappid(2094110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094111, 1, "a094e058139115ade442078fd1d0679f269dc5359abe4e25a7be4a3f91900812")
