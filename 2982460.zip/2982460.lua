-- Lua provided by RyzenAPI
-- Game: Game: Taiwan Love Story⁵ - Free Adult Content

-- MAIN APPLICATION
addappid(2982460)
-- Game: addappid(2982460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982461, 1, "a1d18026a7276941fdc62c6e6c0abc9181a3a5e8d1fb6ce57c2b974a6704ecb1")
