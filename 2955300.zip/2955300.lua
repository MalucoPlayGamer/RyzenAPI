-- Lua provided by RyzenAPI 
-- Game: AppID 2955300
addappid(2955300)
addappid(2955301, 1, "eb89ce2f5ceeb7fd74d1a8a8f8963ee5c74f79790ef99358a0cd1421392b0b40")
