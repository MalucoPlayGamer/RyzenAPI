-- Lua provided by RyzenAPI
-- Game: Game: The Demon's Exorcism

-- MAIN APPLICATION
addappid(2764510)
-- Game: addappid(2764510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764511, 1, "6397433c29a98ca69954fddbef9fe01fd1aed01cf870752de1cfd20fd23faa9f")
