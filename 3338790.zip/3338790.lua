-- Lua provided by RyzenAPI
-- Game: Marisa of Liartop Mountain Demo

-- MAIN APPLICATION
addappid(3338790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3338791, 1, "3302db3cdb1d47692566abdb70600b4da12a0bf4b393deb359bb9222b0621ea8")
