-- Lua provided by RyzenAPI
-- Game: Empire City Simulator

-- MAIN APPLICATION
addappid(3076620)
