-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Omega Modern Graphics Pack

-- MAIN APPLICATION
addappid(1671000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671000,0,"055403fe36e2ca327ad31761ea9f76819fe322cc8cde4658413e33c16e5b4e5a")

