-- Lua provided by RyzenAPI
-- Game: Flix The Flea

-- MAIN APPLICATION
addappid(371390)

-- MAIN APP DEPOTS / PACKAGES
addappid(371391, 1, "13d64774ea7adf933249f8a3a5ca3eaf021951c8d39f5adbfe3a5afa519b58a5")
