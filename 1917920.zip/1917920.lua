-- Lua provided by RyzenAPI
-- Game: Polda 7

-- MAIN APPLICATION
addappid(1917920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917921, 1, "aa8451ff765dcb28f294a4c81a91e8f8bab1b7dbc38809fa9048c542919527b9")

