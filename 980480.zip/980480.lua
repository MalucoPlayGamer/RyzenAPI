-- Lua provided by RyzenAPI
-- Game: addappid(980480)

-- MAIN APPLICATION
addappid(980480)

-- MAIN APP DEPOTS / PACKAGES
addappid(980481, 1, "bc843312f69960af3cebe7dd824718fac4e12a853037d5ba205fe39c0adad279")
