-- Lua provided by RyzenAPI
-- Game: Towertale

-- MAIN APPLICATION
addappid(980480)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(980481, 1, "bc843312f69960af3cebe7dd824718fac4e12a853037d5ba205fe39c0adad279")

