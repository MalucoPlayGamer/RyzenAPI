-- Lua provided by RyzenAPI 
-- Game: Towertale
addappid(980480)
addappid(980481, 1, "bc843312f69960af3cebe7dd824718fac4e12a853037d5ba205fe39c0adad279")
