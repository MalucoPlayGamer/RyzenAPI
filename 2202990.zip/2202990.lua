-- Lua provided by RyzenAPI
-- Game: addappid(2202990)

-- MAIN APPLICATION
addappid(2202990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202991, 1, "c27f24f769a433a1efd0eaa11865aa03a6c47b4529ca2e2faaf22d0d79fad6ce")
