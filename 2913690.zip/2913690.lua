-- Lua provided by RyzenAPI
-- Game: 计算机地牢 Demo

-- MAIN APPLICATION
addappid(2913690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913691, 1, "7020f2fef1bad3743493152052b3169c42f8ed3fb78f6d1c5a6c38d13957e1d5")

