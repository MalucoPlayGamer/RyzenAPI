-- Lua provided by RyzenAPI
-- Game: Gori: Cuddly Carnage - Day One Skin Pack

-- MAIN APPLICATION
addappid(2658940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658940,0,"efa59322699ac2d52478aae83bc70716e8f0f21387e12fe168899c1d7c256793")

