-- Lua provided by RyzenAPI
-- Game: Seven Days

-- MAIN APPLICATION
addappid(931560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(931561, 1, "5d737ee09ee36839bea7329bc2f32e4c937ed67c684136e4b991afb800cbd17f")

