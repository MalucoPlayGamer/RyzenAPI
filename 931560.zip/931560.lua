-- Lua provided by RyzenAPI
-- Game: Seven Days

-- MAIN APPLICATION
addappid(931560)

-- MAIN APP DEPOTS / PACKAGES
addappid(931561, 1, "5d737ee09ee36839bea7329bc2f32e4c937ed67c684136e4b991afb800cbd17f")

