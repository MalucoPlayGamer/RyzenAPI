-- Lua provided by RyzenAPI
-- Game: 1542920

-- MAIN APPLICATION
addappid(1542920)
-- Game: addappid(1542920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542921, 1, "96c7a5a1a4ab55159aafe95b4b6fd0952088f6b9340fdd822ee23feae5f91319")
