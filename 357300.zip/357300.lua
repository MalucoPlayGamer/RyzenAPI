-- Lua provided by RyzenAPI
-- Game: Snakebird

-- MAIN APPLICATION
addappid(357300)

-- MAIN APP DEPOTS / PACKAGES
addappid(357301, 1, "15abadd380dd4ecbb4fda2aea3cdfc9217979f6fc472b548428226a84da34011")
addappid(357302, 1, "c9c907cdca3bd3e6762e0dde2d482858d8f33f47535d4c0625df930bac12d2a1")
addappid(357303, 1, "8a814ec79b183eaf8faa6ef41e5035005374d7294ae946ce12c3f05af553609c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
