-- Lua provided by RyzenAPI
-- Game: Game: Mount Your Friends

-- MAIN APPLICATION
addappid(296470)
-- Game: addappid(296470)

-- MAIN APP DEPOTS / PACKAGES
addappid(296471, 1, "6560d7666496f67862d816e136897610d70392a917e73637b594a565a216e537")
