-- Lua provided by RyzenAPI 
-- Game: Mount Your Friends
addappid(296470)
addappid(296471, 1, "6560d7666496f67862d816e136897610d70392a917e73637b594a565a216e537")
