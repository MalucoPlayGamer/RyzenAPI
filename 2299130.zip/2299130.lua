-- Lua provided by RyzenAPI
-- Game: addappid(2299130)

-- MAIN APPLICATION
addappid(2299130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299131, 1, "5e2455051adbdcb30918a6dbc64be8e098868d7dd7bc34100f36ac186efb4781")
