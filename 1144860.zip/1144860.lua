-- Lua provided by SkyAPI 
-- Game: Flying Sword
addappid(1144860)
addappid(1144861, 1, "3495d11a41d43f9753510cd35be662a04cf2bc98f229d5b7f2958b1ca747de41")
