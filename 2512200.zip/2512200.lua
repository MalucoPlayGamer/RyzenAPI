-- Lua provided by RyzenAPI
-- Game: addappid(2512200)

-- MAIN APPLICATION
addappid(2512200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512201, 1, "03ec4aba92f6f0500b8a00e69766e9031cd0c937ce727bdc57f984667f0a2bf1")
