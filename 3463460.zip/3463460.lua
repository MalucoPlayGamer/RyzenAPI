-- Lua provided by RyzenAPI
-- Game: Game: Hidden Tomatoes 3

-- MAIN APPLICATION
addappid(3463460)
-- Game: addappid(3463460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3463461, 1, "92a43cb86fd2e3637f4576d843aaaab3ef1b0eb491b9305316986afb3c0832d7")
