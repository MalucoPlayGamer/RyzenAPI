-- Lua provided by RyzenAPI
-- Game: DIY MY LADY - DIY Queen of the Ocean (PC)

-- MAIN APPLICATION
addappid(1698790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698790,0,"0dc8f118565e5e38d5603d7aec7be029016b76bf65a4a44e35079aa8c06dfb4f")

