-- Lua provided by RyzenAPI
-- Game: SEX Dreams at the Motel

-- MAIN APPLICATION
addappid(4939160) -- SEX Dreams at the Motel
-- addappid(4939162) -- Depot 4939162 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4939161, 1, "4a10b77b2a006dd7d4efa9b3af1e4ce6b41ebfdf7b01512faac077486ec5100b") -- Depot 4939161

