-- Lua provided by RyzenAPI
-- Game: addappid(3653710)

-- MAIN APPLICATION
addappid(3653710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3653711, 1, "181d145b7d37d84d0a3f9c62b6c8c54ebdc7b268ffac5addfb0999078cd9d9be")
