-- Lua provided by RyzenAPI
-- Game: AppID 726710

-- MAIN APPLICATION
addappid(726710)

-- MAIN APP DEPOTS / PACKAGES
addappid(726711, 1, "8ea7f49904db34b9f914cb35e05293751c8bfc68146bef6bacba6c2df64e7808")

