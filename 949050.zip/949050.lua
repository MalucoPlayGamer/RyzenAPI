-- Lua provided by RyzenAPI
-- Game: Virtual Villagers Origins 2

-- MAIN APPLICATION
addappid(949050)

-- MAIN APP DEPOTS / PACKAGES
addappid(949051, 1, "66a68b6abda403ab9b1d9b295db576bf2bb2e6640095a646166d9cb14a18bcf9")
addappid(949052, 1, "0befc07da55193abf86f450dec78192d9a49ffccec28bc3e93e7ee65e64d48a4")
