-- Lua provided by RyzenAPI
-- Game: addappid(468820)

-- MAIN APPLICATION
addappid(468820)

-- MAIN APP DEPOTS / PACKAGES
addappid(468821, 1, "76671324f1ce2a32fa8ddf4380594de9798aebfe2b19e0f190f5f941938c9e65")
