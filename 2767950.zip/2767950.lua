-- Lua provided by RyzenAPI
-- Game: Capuchin

-- MAIN APPLICATION
addappid(2767950)

