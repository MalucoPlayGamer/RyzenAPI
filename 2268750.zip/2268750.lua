-- Lua provided by RyzenAPI
-- Game: Jianghu Survivor Demo

-- MAIN APPLICATION
addappid(2268750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2268751, 1, "11e4370c0e4b7cba46228b4fdfbe659089d9c4ca60b660287dd0fc98d4d2f702")
