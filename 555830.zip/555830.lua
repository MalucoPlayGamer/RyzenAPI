-- Lua provided by RyzenAPI
-- Game: Game: AppID 555830

-- MAIN APPLICATION
addappid(555830)
-- Game: addappid(555830)

-- MAIN APP DEPOTS / PACKAGES
addappid(555831, 1, "65c18de2a68b1aee4d406a524d74f8b6163d32d95cb5010ca9deebd8ded1e180")
