-- Lua provided by RyzenAPI
-- Game: 3363290

-- MAIN APPLICATION
addappid(3363290)
-- Game: addappid(3363290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3363291, 1, "0a4795dde80017699d7d32e540249e42a79929d51b8b4977a6cd4e4a151e1aff")
