-- Lua provided by RyzenAPI
-- Game: Moving Out 2: Training Day

-- MAIN APPLICATION
addappid(2403360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403361, 1, "23d450bbfc5fb05b1c9e76c71c3fa4ef9f8266d5789bee5758bb718889a05a5e")

