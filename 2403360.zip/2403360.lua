-- Lua provided by RyzenAPI
-- Game: Game: AppID 2403360

-- MAIN APPLICATION
addappid(2403360)
-- Game: addappid(2403360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403361, 1, "23d450bbfc5fb05b1c9e76c71c3fa4ef9f8266d5789bee5758bb718889a05a5e")
