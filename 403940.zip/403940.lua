-- Lua provided by RyzenAPI
-- Game: Game: Dungelot: Shattered Lands

-- MAIN APPLICATION
addappid(403940)
addappid(445850)
-- Game: addappid(403940)

-- MAIN APP DEPOTS / PACKAGES
addappid(403941, 1, "1f7d078e08372f74854e159cf40f65dbac4c36ca6bd5655732817cb2fc39edc9")
