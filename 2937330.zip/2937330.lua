-- Lua provided by RyzenAPI
-- Game: DOSMan: Space Aliens in Space!

-- MAIN APPLICATION
addappid(2937330)
-- Game: addappid(2937330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937331, 1, "6dc5e2a41503289124cc4590dec3a23592f9f7f11fe647686d445f24891a3837")
