-- Lua provided by RyzenAPI
-- Game: THE 8IGHT

-- MAIN APPLICATION
addappid(1316720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316721, 1, "5a39ad011ac0bc8efa45d3a0557f101b6ff997f3e2f4f359b6ab9fc59e514198")

