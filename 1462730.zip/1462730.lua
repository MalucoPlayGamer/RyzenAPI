-- Lua provided by RyzenAPI
-- Game: Game: Atomic Girls

-- MAIN APPLICATION
addappid(1462730)
-- Game: addappid(1462730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462731, 1, "356c24bff4e176ae5aafc612e753fb95e9f64513fe3adb1440001f909f5774ef")
