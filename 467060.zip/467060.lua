-- Lua provided by RyzenAPI
-- Game: Dead Army - Radio Frequency

-- MAIN APPLICATION
addappid(467060)

-- MAIN APP DEPOTS / PACKAGES
addappid(467061, 1, "a013f2408904521656e34dcfba7b998dc43621b90402f4c9de1d0f63f0d46461")
