-- Lua provided by RyzenAPI 
-- Game: Xonix Casual Edition
addappid(2534060)
addappid(2534061, 1, "a84834ae15166fc865c08f7010d3f4f2c05ad571b47d50dd241b6c0fd0a5ed3b")
