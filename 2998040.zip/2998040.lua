-- Lua provided by RyzenAPI
-- Game: BLOODSAINT

-- MAIN APPLICATION
addappid(2998040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2998041, 1, "7fb9fb05f05091bbbd762bfabba42518113747242dfa4ed88771a584a2a4256f")

