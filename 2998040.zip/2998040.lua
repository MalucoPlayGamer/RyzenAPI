-- Lua provided by SkyAPI 
-- Game: BLOODSAINT
addappid(2998040)
addappid(2998041, 1, "7fb9fb05f05091bbbd762bfabba42518113747242dfa4ed88771a584a2a4256f")
