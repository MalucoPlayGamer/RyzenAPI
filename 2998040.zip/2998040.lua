-- Lua provided by RyzenAPI
-- Game: 2998040

-- MAIN APPLICATION
addappid(2998040)
-- Game: addappid(2998040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998041, 1, "7fb9fb05f05091bbbd762bfabba42518113747242dfa4ed88771a584a2a4256f")
