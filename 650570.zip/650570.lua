-- Lua provided by RyzenAPI
-- Game: Code 7: A Story-Driven Hacking Adventure

-- MAIN APPLICATION
addappid(650570)
addappid(1058170)

-- MAIN APP DEPOTS / PACKAGES
addappid(650572,0,"595ccb16f4b5ad5aa11b48cbac4485b03acb79b675f69ac8e9fb48d6972af26d")
addappid(650574,0,"7e60bdcd3f318c5fb5504c03f65dea8fbac490bc699dd46c7773c307bf16887d")
addappid(650578,0,"bd2bbfbd551b1909b1f55e88b723bd24e66594e9594376e0052e395deb94ca0c")

