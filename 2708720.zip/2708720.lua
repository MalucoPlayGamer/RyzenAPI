-- Lua provided by SkyAPI 
-- Game: MistsBook
addappid(2708720)
addappid(2708721, 1, "a3093e67dd0aa48ca11c0b14f87c8ad2d706c9b6d2f5b80552bd33c77130641d")
