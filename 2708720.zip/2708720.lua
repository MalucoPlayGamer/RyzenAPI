-- Lua provided by RyzenAPI
-- Game: addappid(2708720)

-- MAIN APPLICATION
addappid(2708720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708721, 1, "a3093e67dd0aa48ca11c0b14f87c8ad2d706c9b6d2f5b80552bd33c77130641d")
