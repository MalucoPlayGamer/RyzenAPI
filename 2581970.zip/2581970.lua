-- Lua provided by RyzenAPI
-- Game: Shell Runner - Prelude

-- MAIN APPLICATION
addappid(2581970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581971, 1, "8d73798d8bb9fd695a715a58eeb0f97662474f5d3822021229c35c73780cd969")

