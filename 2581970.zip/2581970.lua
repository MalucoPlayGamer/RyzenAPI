-- Lua provided by RyzenAPI
-- Game: Shell Runner - Prelude

-- MAIN APPLICATION
addappid(2581970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581971, 1, "8d73798d8bb9fd695a715a58eeb0f97662474f5d3822021229c35c73780cd969")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
