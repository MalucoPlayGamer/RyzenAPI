-- Lua provided by RyzenAPI
-- Game: 1396890

-- MAIN APPLICATION
addappid(1396890)
-- Game: addappid(1396890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396891, 1, "4ded1cea3d475d47038b97f2ca0cb1c28ca6f55b798f1de9a837219dbdb3c2a1")
