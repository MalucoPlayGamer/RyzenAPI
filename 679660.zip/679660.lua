-- Lua provided by RyzenAPI
-- Game: aMAZE ZER0

-- MAIN APPLICATION
addappid(679660)

-- MAIN APP DEPOTS / PACKAGES
addappid(679661, 1, "dd4082044af7715259ac82b0e5464a574b3e10c86ff0c1c828eaffe6aa21a012")
addappid(852020, 0, "36f58fdc296d98dffce3d0fdb115df7723486320964574d1bde0c488acbff78e")

