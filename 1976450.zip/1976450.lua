-- Lua provided by SkyAPI 
-- Game: MeiQi:Story
addappid(1976450)
addappid(1976451, 1, "61524b8e947344f8eb902c43e04e9bd845761ec0b25fdccc061d47856c7f904d")
