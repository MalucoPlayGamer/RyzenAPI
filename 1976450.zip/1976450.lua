-- Lua provided by RyzenAPI
-- Game: MeiQi:Story

-- MAIN APPLICATION
addappid(1976450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976451, 1, "61524b8e947344f8eb902c43e04e9bd845761ec0b25fdccc061d47856c7f904d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
