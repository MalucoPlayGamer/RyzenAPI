-- Lua provided by RyzenAPI
-- Game: 3154800

-- MAIN APPLICATION
addappid(3154800)
-- Game: addappid(3154800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3154801, 1, "7f03d2f837b27b236e6df6bce387eba1ae4b46d90c9fe62622775ad7c6b30e6c")
