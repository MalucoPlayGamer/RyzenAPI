-- Lua provided by RyzenAPI
-- Game: Game: Siege Showdown

-- MAIN APPLICATION
addappid(2623700)
-- Game: addappid(2623700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623701, 1, "211b27b11451f7407bc2546b159c1b7f482da53f46562faee0a7eca045fd66e7")
