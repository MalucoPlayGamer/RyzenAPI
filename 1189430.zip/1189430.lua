-- Lua provided by RyzenAPI
-- Game: 1189430

-- MAIN APPLICATION
addappid(1189430)
-- Game: addappid(1189430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189431, 1, "d0a1fbd48abcfa82cb2d7fc25abaf48053058ab6ef6b933ebd5bad01864f2b9d")
