-- Lua provided by RyzenAPI
-- Game: Hentai Crazy Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1149130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149130,0,"5f568dfaca8e3d462d559d4d274d0533319b4268e0ca2b68b6b820f06ea51eb7")
