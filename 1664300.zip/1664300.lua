-- Lua provided by RyzenAPI
-- Game: addappid(1664300)

-- MAIN APPLICATION
addappid(228981)
addappid(228982)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228988)
addappid(228990)
addappid(229004)
addappid(229005)
addappid(229006)
addappid(229007)
addappid(229010)
addappid(229011)
addappid(229012)
addappid(229020)
addappid(229033)
addappid(1664300)
addappid(1664301)
addappid(1664302)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
