-- Lua provided by RyzenAPI
-- Game: Fairy Massage

-- MAIN APPLICATION
addappid(1992590)
addappid(3114520)
addappid(3196580)
addappid(3197070)
addappid(3199680)
addappid(4456150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992591, 1, "8d4b833fe2f6ef95a383475ff3032dd3a615539fe6e63b7ff186d2fed772724c")

