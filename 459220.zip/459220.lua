-- Lua provided by RyzenAPI
-- Game: addappid(459220)

-- MAIN APPLICATION
addappid(459220)

-- MAIN APP DEPOTS / PACKAGES
addappid(459221, 1, "d5ac4085e8993db07e41ff025f1a60abf083d790e0452af5900fcb82fce8acf0")
