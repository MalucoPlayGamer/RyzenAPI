-- Lua provided by RyzenAPI
-- Game: Halo Wars: Definitive Edition

-- MAIN APPLICATION
addappid(459220)

-- MAIN APP DEPOTS / PACKAGES
addappid(459221, 1, "d5ac4085e8993db07e41ff025f1a60abf083d790e0452af5900fcb82fce8acf0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
