-- Lua provided by RyzenAPI
-- Game: addappid(876540)

-- MAIN APPLICATION
addappid(876540)

-- MAIN APP DEPOTS / PACKAGES
addappid(876541, 1, "690a2d9620814d28ffbf34b8780bf7e5d0484ccefdeed44f8ebbce1f4cbc0fc9")
