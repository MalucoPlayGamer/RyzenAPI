-- Lua provided by RyzenAPI
-- Game: Game: AppID 1060450

-- MAIN APPLICATION
addappid(1060450)
-- Game: addappid(1060450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060451, 1, "7d7ef12867dc5ca4f1631e133b292ec93ca8cbb45b7a1ba8d043620269d5dcf8")
