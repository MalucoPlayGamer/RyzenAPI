-- Lua provided by RyzenAPI
-- Game: Sky Shepherd

-- MAIN APPLICATION
addappid(1060450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1060451, 1, "7d7ef12867dc5ca4f1631e133b292ec93ca8cbb45b7a1ba8d043620269d5dcf8")

