-- Lua provided by RyzenAPI
-- Game: Game: 东方百问~TouHouAsked

-- MAIN APPLICATION
addappid(930840)
-- Game: addappid(930840)

-- MAIN APP DEPOTS / PACKAGES
addappid(930841, 1, "1cffda154f38939a6c40c778c1a2b67104aa72407b65ffa6e176fe5762bc6e21")
