-- Lua provided by RyzenAPI
-- Game: Decision: Red Daze Supporter Bundle

-- MAIN APPLICATION
addappid(2079040)
-- Game: addappid(2079040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079040,0,"4db3216ac1548acc15e72f19243824525091198aa2fde37c4b0c688050f11669")
