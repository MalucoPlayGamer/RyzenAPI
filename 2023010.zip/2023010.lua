-- Lua provided by RyzenAPI
-- Game: 2023010

-- MAIN APPLICATION
addappid(2023010)
-- Game: addappid(2023010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023011, 1, "4cc8487cc68372aaf1225e96e683ca22ed8fcc3f210e03220e70ba98a691553a")
