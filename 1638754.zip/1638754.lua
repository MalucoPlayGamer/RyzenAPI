-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1638754)
-- Game: addappid(1638754)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638754,0,"3ea0ddc7b189e8d62a98adfc717f2b3e10dc418b8e2a49e0c6dc65936e562db7")
