-- Lua provided by RyzenAPI
-- Game: Game: AppID 1039110

-- MAIN APPLICATION
addappid(1039110)
-- Game: addappid(1039110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039111, 1, "410228e1ff619bdd034483a949c80cb7709aed580fdbe6b0b1bd5f82f88fa21b")
addappid(1039112, 1, "05557eae53e34a45d1dfeac57ff83c6014afc28b671bb5476ec5787207f32a7e")
addappid(1039113, 1, "3b8a575374c2e73978eb1eadd7f7793c8166e2eeb5cd74a3dadd03166d99f4ef")
addappid(1039114, 1, "5e2a3a7c31ed57ef64a8155a7eed43d1ecdb5e130f4eb2382464261182f70318")
