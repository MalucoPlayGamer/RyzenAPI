-- Lua provided by RyzenAPI
-- Game: Ikarus

-- MAIN APPLICATION
addappid(1039110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1039111, 1, "410228e1ff619bdd034483a949c80cb7709aed580fdbe6b0b1bd5f82f88fa21b")
addappid(1039112, 1, "05557eae53e34a45d1dfeac57ff83c6014afc28b671bb5476ec5787207f32a7e")
addappid(1039113, 1, "3b8a575374c2e73978eb1eadd7f7793c8166e2eeb5cd74a3dadd03166d99f4ef")
addappid(1039114, 1, "5e2a3a7c31ed57ef64a8155a7eed43d1ecdb5e130f4eb2382464261182f70318")

