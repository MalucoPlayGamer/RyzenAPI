-- Lua provided by RyzenAPI
-- Game: 2821810

-- MAIN APPLICATION
addappid(2821810)
-- Game: addappid(2821810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821811, 1, "f7fd5cc9aa13c9be65850293cdcbfe808360e6aaa4fbf32586bd07cc596037b2")
