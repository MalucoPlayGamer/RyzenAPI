-- Lua provided by RyzenAPI
-- Game: Game: The Last Clockwinder

-- MAIN APPLICATION
addappid(1755100)
-- Game: addappid(1755100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755101, 1, "b8ebc55f1ce9cf1c48d2e22f7e2abad7189824dcd3de7192fb472eefe38c2558")
