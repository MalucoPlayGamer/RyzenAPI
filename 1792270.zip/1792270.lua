-- Lua provided by RyzenAPI
-- Game: Game: AppID 1792270

-- MAIN APPLICATION
addappid(1792270)
-- Game: addappid(1792270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792271, 1, "4d14f333ba4abc79f7fe472b453c50f9fcc4b82e9ca88cb6087bbe4f1939e84e")
