-- Lua provided by RyzenAPI
-- Game: Stick Fight: The Game OST

-- MAIN APPLICATION
addappid(726050)

-- MAIN APP DEPOTS / PACKAGES
addappid(726050,0,"3866668b1a85adef60c3470be739a60c4764d0fcbd9fd7f7813b703233f9548e")

