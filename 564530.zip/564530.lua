-- Lua provided by RyzenAPI 
-- Game: AppID 564530
addappid(564530)
addappid(564531, 1, "28192ee60d83506858b4c3862c3576cb6655c48237429b3ba86c15a9e2fa329c")
