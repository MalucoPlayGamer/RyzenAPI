-- Lua provided by RyzenAPI
-- Game: Battlefleet Gothic: Armada (Classic)

-- MAIN APPLICATION
addappid(363680)
addappid(482200)

-- MAIN APP DEPOTS / PACKAGES
addappid(363681, 1, "0ce6e5ddaa2f3623a8d438ed0c94353186508a6192ea882ef48c30b0f7142648")
addappid(363682, 1, "af549810679bdfc0efde4a57d55f845d4c870a1c2d625da762904d4c05921f64")
addappid(363683, 1, "68030526d674ee50af5209d0e362a49d1892f0f4aebe79d780fd89daede1acd8")
addappid(363684, 1, "075a3989a3f48e828e51f5c17ab1d442a375693c4e711bec2ca97eec79417262")
addappid(363685, 1, "fe47bd068c223e1473ae47aa65531a125485071e827201fc50f06815c14e2c0d")
addappid(363686, 1, "eb0754477f0cf790a370780e1d4eadbb57b1b6a1b600783d22147d2204baa8d4")
addappid(363687, 1, "3044764ce76697db38e7359126e6b673c0a254df7519b840ee251f277d3dba28")
addappid(363688, 1, "7550722039822b62ae111d87b5475f1027c718ee1c87d1ef7d6522a4da577151")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(462260)
addappid(462261)
