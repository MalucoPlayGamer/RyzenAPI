-- Lua provided by RyzenAPI
-- Game: Game: MY HERO ONE'S JUSTICE 2 Demo

-- MAIN APPLICATION
addappid(1582270)
-- Game: addappid(1582270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582271, 1, "7937705fefdf5f7ce2604e2bba0d4d419ffab6c5d1c0450e312548fc6052a5a6")
