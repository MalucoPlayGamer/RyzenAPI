-- Lua provided by RyzenAPI
-- Game: 1582270

-- MAIN APPLICATION
addappid(1582270)
-- Game: addappid(1582270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582271, 1, "7937705fefdf5f7ce2604e2bba0d4d419ffab6c5d1c0450e312548fc6052a5a6")
