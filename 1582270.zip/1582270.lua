-- Lua provided by RyzenAPI 
-- Game: MY HERO ONE'S JUSTICE 2 Demo
addappid(1582270)
addappid(1582271, 1, "7937705fefdf5f7ce2604e2bba0d4d419ffab6c5d1c0450e312548fc6052a5a6")
