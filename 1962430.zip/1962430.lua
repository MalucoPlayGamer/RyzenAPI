-- Lua provided by RyzenAPI
-- Game: Monochrome Mobius: Rights and Wrongs Forgotten

-- MAIN APPLICATION
addappid(1962430)
addappid(2207200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962431, 1, "5dab5c9af2bd63310cd67ed682e10a357452baef5cfbaa1d0f0beaf7c160ade4")
addappid(1962432, 1, "91117a7c1daadf29f8e2f2e143e0ccd94efe2106e310526a7ef5a442426c29dc")
addappid(1962433, 1, "79d46168f3186be7cda3c26eb3a0b2a472b7c75dd0b16d5106b31ca3cbddee3b")
addappid(1962434, 1, "5a83524062f1700e4c06cfc38084444cd784c74b8c73f8886af3c4cd4327d684")

