-- Lua provided by RyzenAPI
-- Game: Europe Bus Driver

-- MAIN APPLICATION
addappid(2147370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147371, 1, "fbee01c144c3d5f8518d5cc3fe9c90496f20562579d0059bc451293896a9692c")
