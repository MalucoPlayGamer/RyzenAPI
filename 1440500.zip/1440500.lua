-- Lua provided by RyzenAPI
-- Game: 東方剛欲異聞　～ 水没した沈愁地獄

-- MAIN APPLICATION
addappid(1440500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1440501, 1, "2214ef17b1b6d4099dde474d2342d1350d12775030091effccdac4adb43c168d")

