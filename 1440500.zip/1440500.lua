-- Lua provided by RyzenAPI
-- Game: addappid(1440500)

-- MAIN APPLICATION
addappid(1440500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440501, 1, "2214ef17b1b6d4099dde474d2342d1350d12775030091effccdac4adb43c168d")
