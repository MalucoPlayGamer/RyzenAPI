-- Lua provided by RyzenAPI
-- Game: Game: AppID 893850

-- MAIN APPLICATION
addappid(893850)
-- Game: addappid(893850)

-- MAIN APP DEPOTS / PACKAGES
addappid(893851, 1, "f3b8ba0d8f664fc4a9581293e22046cab2ad4d517157e4aa46064ce68a7c5304")
addappid(893852, 1, "5085e7bb548c7cde8d490e27e7dc508637dd3023619f833e258c48efd3c993a8")
addappid(893853, 1, "7c19b3d3b406ce07eb21d136fd436d18b23f3436ea5de4f5b0e145de5c072cdb")
