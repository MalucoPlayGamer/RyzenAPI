-- Lua provided by RyzenAPI
-- Game: addappid(1729560)

-- MAIN APPLICATION
addappid(1729560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729561, 1, "993bb9c59fb2db3292abaa2a4c9916aabdcfb382c19e9a4b20e7a283cdbd728f")
