-- Lua provided by RyzenAPI
-- Game: 974010

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(974010)
addappid(1095490)
-- Game: addappid(974010)

-- MAIN APP DEPOTS / PACKAGES
addappid(974012,0,"933aed3f286799ba4a5bd22875cb18bc41a8b9c0b52a519bb407f9b4406e1a17")
