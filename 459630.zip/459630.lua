-- Lua provided by RyzenAPI
-- Game: setManifestid(459633,"1692245566576249103")

-- MAIN APPLICATION
addappid(459630)

-- MAIN APP DEPOTS / PACKAGES
addappid(459633,0,"83d3bff777b1db3a9f68b6fcacd695d78d15dc9b446d3b8a7d391bfc13a9289a")
