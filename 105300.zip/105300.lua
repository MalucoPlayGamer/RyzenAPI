-- Lua provided by RyzenAPI
-- Game: Critical Mass

-- MAIN APPLICATION
addappid(105300)
-- Game: addappid(105300)

-- MAIN APP DEPOTS / PACKAGES
addappid(105301, 1, "b46fd3778b7414e994a39bb1722efe22134f49b4d57a2ab5c1c235774221a5f0")
addappid(105302, 1, "b3f811ba85406d70903a09fea31f7c4643d10416d75fa37ed7843d6512f2386c")
