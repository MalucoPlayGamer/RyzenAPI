-- Lua provided by RyzenAPI
-- Game: addappid(375770)

-- MAIN APPLICATION
addappid(375770)
addappid(454660)

-- MAIN APP DEPOTS / PACKAGES
addappid(375771, 1, "3565214ac2b3882bc05351ac74562f2e914b17dad118f43a4dbdc5d9c92720ab")
addappid(375773, 1, "e3bdc2ca0d84ae9b01d54bb56173b8cc2bcaa9a350f0bd14ced9e1d61161cf22")
