-- Lua provided by RyzenAPI
-- Game: addappid(2178180)

-- MAIN APPLICATION
addappid(2178180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178181, 1, "ed0f3a14bcbabc925ca60a4443ba31777b8bbca0e1997b9ce9f375b014f7aa61")
