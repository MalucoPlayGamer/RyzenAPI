-- Lua provided by RyzenAPI
-- Game: Game: The Path - Prologue

-- MAIN APPLICATION
addappid(27040)
-- Game: addappid(27040)

-- MAIN APP DEPOTS / PACKAGES
addappid(27041, 1, "c0a468e88432e57538e4a26d950ee18acdf20e0bd6bb4be165f74dca149f2742")
