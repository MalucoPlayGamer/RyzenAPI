-- Lua provided by RyzenAPI
-- Game: Kings and Pigs

-- MAIN APPLICATION
addappid(1655880)
-- Game: addappid(1655880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655881, 1, "35960342efdfbe891fb8b732f1ca04d1a929b8a31db27b1163fdf52ce036b2bb")
