-- Lua provided by RyzenAPI
-- Game: First Day: Home Defender

-- MAIN APPLICATION
addappid(1225640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225641, 1, "1c02a011ec367d433153ba1e5eefdf9b767486e1b5d675b5fa505326212aee23")
