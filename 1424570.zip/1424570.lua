-- Lua provided by RyzenAPI 
-- Game: Delta0
addappid(1424570)
addappid(1424571, 1, "adcdc572a7b030a80c7cbfb36817b05c8fdf08e0a0c29017577e8d7112d60cc7")
addappid(1424573, 1, "240e5d14db0048fe40521c8e241c2034cc2d493002fcbcda84bd4622b4ef0684")
addappid(1424574, 1, "e15284b9b363d70cd85d6810b2dacfd308d58f977608b3e55fa3d9256edd7f86")
