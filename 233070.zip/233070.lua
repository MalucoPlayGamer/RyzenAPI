-- Lua provided by RyzenAPI
-- Game: addappid(233070)

-- MAIN APPLICATION
addappid(233070)

-- MAIN APP DEPOTS / PACKAGES
addappid(233071, 1, "7ea3b3bff99da299bd62312e32c73ddc6a169504a2c95acc2b6f00089c541726")
