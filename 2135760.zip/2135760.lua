-- Lua provided by RyzenAPI
-- Game: 2135760

-- MAIN APPLICATION
addappid(2135760)
-- Game: addappid(2135760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135761, 1, "32ddd3b676026fb1edf3bfd421549496afdcee622ff534b01f0a171165baf167")
