-- 1939390's Lua and Manifest Created by Hubcap Manifest
-- Dino Party
-- Created: August 15, 2026 at 03:14:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1939390, 1, "77caf62792f6205168ac79536662f5eda0ecdd2a7774c3a757bf77c4f2d60e93") -- Dino Party
-- MAIN APP DEPOTS
addappid(1939391, 1, "996bcb1d517cc5235fa07180d919281b07bf2b7e7ab8652563b756436231fc22") -- Depot 1939391
setManifestid(1939391, "3232340213815162671", 1909664553)