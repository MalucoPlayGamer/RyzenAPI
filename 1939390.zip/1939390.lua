-- Lua provided by RyzenAPI
-- Game: Dino Party

-- MAIN APP DEPOTS / PACKAGES
addappid(1939390, 1, "77caf62792f6205168ac79536662f5eda0ecdd2a7774c3a757bf77c4f2d60e93") -- Dino Party
addappid(1939391, 1, "996bcb1d517cc5235fa07180d919281b07bf2b7e7ab8652563b756436231fc22") -- Depot 1939391

