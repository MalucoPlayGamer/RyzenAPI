-- Lua provided by RyzenAPI
-- Game: Virtual Aquarium - Overlay Desktop Game

-- MAIN APPLICATION
addappid(1791120)
addappid(1828820)
addappid(1833450)
addappid(1900910)
addappid(1967000)
addappid(2256500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791121, 1, "2899462fa5f440baeb9f2acfc7329612a3bcf575005cc481c6c635ec2e302ee7")

