-- Lua provided by RyzenAPI
-- Game: SteamWorld Build

-- MAIN APPLICATION
addappid(2134770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134771, 1, "bbda61a192b954b2b25cfe27ca50a6a5e1cd9b6ecf41b9cd42b62d78bd2eace5")
