-- Lua provided by RyzenAPI
-- Game: Black Wolfberry:WuJing

-- MAIN APPLICATION
addappid(229000)
addappid(2809640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2809644,0,"588650ca8e0e6730599f4c8b69a9d5b9edec154f92a11ad6a0012bf9b584ffbc")

