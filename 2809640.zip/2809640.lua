-- Lua provided by RyzenAPI
-- Game: setManifestid(229000,"4622705914179893434")

-- MAIN APPLICATION
addappid(229000)
addappid(2809640)
-- Game: addappid(2809640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809644,0,"588650ca8e0e6730599f4c8b69a9d5b9edec154f92a11ad6a0012bf9b584ffbc")
