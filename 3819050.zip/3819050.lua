-- Lua provided by RyzenAPI
-- Game: Jrago II Eden Window

-- MAIN APPLICATION
addappid(3819050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3819052,0,"5b8c1f3c428601768471bec80b95a70198f8143bb3261050a6bb92b34c3981e0")

