-- Lua provided by RyzenAPI 
-- Game: AppID 3271110
addappid(3271110)
addappid(3271111, 1, "0e00758e54b7e462a231d9f38046096e34183fbf7f6d6497476a5bc9236376e5")
