-- Lua provided by RyzenAPI
-- Game: Cryptid Farm Demo

-- MAIN APPLICATION
addappid(3271110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271111, 1, "0e00758e54b7e462a231d9f38046096e34183fbf7f6d6497476a5bc9236376e5")

