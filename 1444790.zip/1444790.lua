-- Lua provided by RyzenAPI
-- Game: Re:Turn - One Way Trip: Digital Comic Book

-- MAIN APPLICATION
addappid(1444790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444790,0,"6dced90f235c5d939680566616c566463c666aad43bcda39a22ae45ff6af8ba4")

