-- Lua provided by RyzenAPI
-- Game: Sebil Engineering

-- MAIN APPLICATION
addappid(1750350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750352,0,"753d4ac10e45dc78f91de36db43289ef9e4127e277c9653d84278239cc6f27d2")

