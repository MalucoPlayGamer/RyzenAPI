-- Lua provided by RyzenAPI
-- Game: Kotel Ne Gori: A Friend of Lena Boots

-- MAIN APPLICATION
addappid(1325870)
-- Game: addappid(1325870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325871, 1, "0be9c6f9da1a72395bb500b642c5ca375a8adeabd8ca63c38949a7fdd1e9c263")
addappid(1325872, 1, "ea232959cf7ab10c8139a64b5fb869838d4396b762f8598bb5b9a31674649536")
