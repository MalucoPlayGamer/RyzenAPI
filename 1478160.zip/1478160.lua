-- Lua provided by RyzenAPI
-- Game: Game: Nyaruru Fishy Fight

-- MAIN APPLICATION
addappid(1478160)
-- Game: addappid(1478160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478161, 1, "0b31a1bb4d834f46c37bd1b54b48127e24153c121da8b990eed3d22bfe55c812")
addappid(1478163, 1, "a9540f1c2d4cdcbe060c10053578556ee98482b8828c354a711a5b3d60fb0bb7")
addappid(2495690, 0, "d37c959d4f78ef15c8647f82355c8f8cd155500049e39df6a36963933d1d558b")
