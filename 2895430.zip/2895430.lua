-- Lua provided by RyzenAPI
-- Game: Incremental Town RPG

-- MAIN APPLICATION
addappid(2895430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895432,0,"10f2ae8436a946f5d1ef3ce8d363bcc0f0426604da09f8ba0be71c94947a958e")

