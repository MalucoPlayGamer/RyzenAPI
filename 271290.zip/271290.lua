-- Lua provided by RyzenAPI
-- Game: addappid(271290)

-- MAIN APPLICATION
addappid(271290)

-- MAIN APP DEPOTS / PACKAGES
addappid(271291, 1, "02bb1ed80a549719159cfe1a052269a914c5dec37c593416e865ae1e467570b2")
