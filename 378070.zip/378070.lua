-- Lua provided by RyzenAPI
-- Game: Game: Energy Hook

-- MAIN APPLICATION
addappid(378070)
-- Game: addappid(378070)

-- MAIN APP DEPOTS / PACKAGES
addappid(378071, 1, "db1ca7f09deeb83d60a0f2fe1223619d878f33a0412fd4fc7d7329a8b5110e14")
