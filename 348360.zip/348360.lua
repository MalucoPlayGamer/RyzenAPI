-- Lua provided by RyzenAPI
-- Game: Doodle God

-- MAIN APPLICATION
addappid(348360)
addappid(680760)
-- Game: addappid(348360)

-- MAIN APP DEPOTS / PACKAGES
addappid(348361, 1, "a85c09599d4799d4c18f29a38de9b4bf74f3fdb1d14943da1b8ea03838b31c47")
addappid(348362, 1, "d97a7e05ca53324e9de20c6fb7806b557e64df18c052d06e23b56a89d5f8c914")
addappid(348363, 1, "b95dcf5f1c99cffee8abca1f93decec4c6a6bd75c30c2e69a425b1b19a1f62cd")
addappid(348364, 1, "0f59ac4bf89e6053685adc7bdc7872d682027b4584f0a25aecd85db70172fc46")
addappid(348365, 1, "cc9a64b1518ff31cde016f9e2516be812c41039b74c3103c2215de402b89a626")
addappid(348366, 1, "5d1349b296e3e1c0c39a6f3c4d6781cc372d448327dfb75a1a6c6318e61284aa")
