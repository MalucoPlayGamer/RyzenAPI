-- Lua provided by RyzenAPI
-- Game: 3238050

-- MAIN APPLICATION
addappid(3238050)
-- Game: addappid(3238050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238051, 1, "5a0c128732fcd909a3adb4a035b048bc9f2d206ba61b6ba6827e20b321d7bf91")
