-- Lua provided by RyzenAPI
-- Game: Fabulous - Angela's High School Reunion

-- MAIN APPLICATION
addappid(619810)

-- MAIN APP DEPOTS / PACKAGES
addappid(619811, 1, "4a7bcddb0d8f27f211b58001c41da38bfd61df5a8aeb18fcc3ea34d0666f03e7")
addappid(619812, 1, "5266d69995f90769bba70cca256931f267ec7283ac680167b05e2b810c37a2f7")
