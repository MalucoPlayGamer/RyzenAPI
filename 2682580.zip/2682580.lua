-- Lua provided by RyzenAPI
-- Game: Game: DUCKSIDE

-- MAIN APPLICATION
addappid(2682580)
-- Game: addappid(2682580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682581, 1, "83bf933e89fe0beed0565f603bcd6ce3d6b6491081677ef77c8d694fe0186f33")
