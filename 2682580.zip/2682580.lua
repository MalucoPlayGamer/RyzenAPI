-- Lua provided by RyzenAPI 
-- Game: DUCKSIDE
addappid(2682580)
addappid(2682581, 1, "83bf933e89fe0beed0565f603bcd6ce3d6b6491081677ef77c8d694fe0186f33")
