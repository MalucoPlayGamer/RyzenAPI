-- Lua provided by RyzenAPI
-- Game: DUCKSIDE

-- MAIN APPLICATION
addappid(2682580)
addappid(3102060)
addappid(3802310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2682581, 1, "83bf933e89fe0beed0565f603bcd6ce3d6b6491081677ef77c8d694fe0186f33")

