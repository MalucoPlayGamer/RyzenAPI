-- Lua provided by SkyAPI 
-- Game: Maid for Loving You
addappid(2176760)
addappid(2176761, 1, "f9a44e628f6dbff47e11e23c2de6fbcfa585db04d49bef4a9e556b296a764297")
