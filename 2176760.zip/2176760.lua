-- Lua provided by RyzenAPI
-- Game: Game: Maid for Loving You

-- MAIN APPLICATION
addappid(2176760)
-- Game: addappid(2176760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176761, 1, "f9a44e628f6dbff47e11e23c2de6fbcfa585db04d49bef4a9e556b296a764297")
