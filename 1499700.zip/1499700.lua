-- Lua provided by RyzenAPI
-- Game: Game: Golazo! 2

-- MAIN APPLICATION
addappid(1499700)
addappid(2192360)
-- Game: addappid(1499700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499701, 1, "c1139d20f9281551f4b89093fb13db789be92cf21260483fbc0184f258330479")
