-- Lua provided by SkyAPI 
-- Game: The Bad Kids
addappid(2071200)
addappid(2071201, 1, "1a87b391b41bebc4448fdf102ac6cbf86eb39a518c275bc3f74f5a9050f577a8")
addappid(2071203, 1, "2571c78fc89920168b394f893e0e8bef6874f533ce40126611f847e734cbad5c")
