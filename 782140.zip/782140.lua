-- Lua provided by RyzenAPI
-- Game: Re-Legion

-- MAIN APPLICATION
addappid(782140)

-- MAIN APP DEPOTS / PACKAGES
addappid(782141, 1, "05424372d60104cdaf57e7873bebef93db96502839c756bb46b3eb171c82f24c")
addappid(1021901, 0, "0fc6f0fcde9cb74036143f52c0fe5d731c4cd1d3e001889b2f1509dbecc1a1b2")

