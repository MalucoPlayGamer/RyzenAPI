-- Lua provided by RyzenAPI 
-- Game: AppID 2915890
addappid(2915890)
addappid(2915891, 1, "cbc1dbea26490b76d044482f99229a7cb64475ce6970c53f6885732fef6bd63d")
