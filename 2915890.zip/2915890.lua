-- Lua provided by RyzenAPI
-- Game: 30 Days on Ship Playtest

-- MAIN APPLICATION
addappid(2915890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915891, 1, "cbc1dbea26490b76d044482f99229a7cb64475ce6970c53f6885732fef6bd63d")

