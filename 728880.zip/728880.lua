-- Lua provided by RyzenAPI
-- Game: Game: Overcooked! 2

-- MAIN APPLICATION
addappid(728880)
-- Game: addappid(728880)

-- MAIN APP DEPOTS / PACKAGES
addappid(728881, 1, "6ab9f32746295a38fc0a75db089afc2394e0ced25ca436201027ed360890e5bc")
addappid(728882, 1, "3693ed13535f104258a7425e20b9e1fae3f30ec4d78a09f0b89cd55350991d51")
addappid(728883, 1, "67ac3a681ded025499180d68f3753ce53f4934976c75af86ab9a6287056dcdae")
