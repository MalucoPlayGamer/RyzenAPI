-- Lua provided by RyzenAPI
-- Game: The Alters

-- MAIN APPLICATION
addappid(1601570)
addappid(3773900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601571,0,"0439da537fb9ca417bd1efa7f41890efff942c7cae69a68d72ff61d8b3e2ca8b")
addappid(3237510,0,"ad826df32ba414ac8a933237753a188ce592b00e6fea22bccc50eafcacb13db5")
addappid(3237520,0,"cf66a594ba8f6ad6086533b80de69c5b1bb364e5718e1dad75de27c0f5f756b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
