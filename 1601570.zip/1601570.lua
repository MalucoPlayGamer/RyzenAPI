-- Lua provided by RyzenAPI
-- Game: The Alters

-- MAIN APPLICATION
addappid(1601570)
addappid(3773900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601571,0,"0439da537fb9ca417bd1efa7f41890efff942c7cae69a68d72ff61d8b3e2ca8b")
addappid(3237510,0,"ad826df32ba414ac8a933237753a188ce592b00e6fea22bccc50eafcacb13db5")
addappid(3237520,0,"cf66a594ba8f6ad6086533b80de69c5b1bb364e5718e1dad75de27c0f5f756b0")

