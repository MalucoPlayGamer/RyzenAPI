-- Lua provided by RyzenAPI
-- Game: addappid(1601570)

-- MAIN APPLICATION
addappid(1601570)
addappid(3237510)
addappid(3773900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601571, 1, "0439da537fb9ca417bd1efa7f41890efff942c7cae69a68d72ff61d8b3e2ca8b")
