-- Lua provided by RyzenAPI
-- Game: Heartbound - OST

-- MAIN APPLICATION
addappid(776560)

-- MAIN APP DEPOTS / PACKAGES
addappid(776560,0,"ab20b0ecbbf1ad0e2dd6e702aaeaa04c848f89cc1e3017c9b89f22fd8bc408e6")

