-- Lua provided by RyzenAPI
-- Game: EggOS: Incremental Game Dev

-- MAIN APPLICATION
addappid(4984770) -- EggOS: Incremental Game Dev

-- MAIN APP DEPOTS / PACKAGES
addappid(4984771, 1, "12d27ffad06f1fd2b294cf7f8f32df70cd96ddba318a8547347b8103bb3b8dbe") -- Depot 4984771
addappid(4984772, 1, "346e43879c57d4092ee63ed17410e78e26ac4f0da7dc1dc71193e13c7f6750f9") -- Depot 4984772
addappid(4984773, 1, "2149f4cce0cd895b6d8cb94f0dc2b51ef05829b118357f3fa1dcd10269b431f6") -- Depot 4984773

