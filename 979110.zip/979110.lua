-- Lua provided by RyzenAPI
-- Game: addappid(979110)

-- MAIN APPLICATION
addappid(979110)

-- MAIN APP DEPOTS / PACKAGES
addappid(979111, 1, "753e99e967ee48a9e571f9b8d087bf5c16b888de6b5d0382dfe0d6377da80033")
addappid(979112, 1, "de481d6749d72fd59dfc99a7ea1e9a9fc186a69268d327b5734abdad5d70ec27")
addappid(979113, 1, "ea5660cf4ce78ce15573642c1437a35f7f6644c479fa8b9ad9d8fca51d75b85b")
