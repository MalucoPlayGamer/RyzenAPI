-- Lua provided by RyzenAPI
-- Game: Beyond Magic

-- MAIN APPLICATION
addappid(463880)

-- MAIN APP DEPOTS / PACKAGES
addappid(463881, 1, "879b262125c96a83824bc510e9f1f1645741ee60f81cc91143c007d313dcc93c")

