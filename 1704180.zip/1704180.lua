-- Lua provided by RyzenAPI
-- Game: Broken Alliance

-- MAIN APPLICATION
addappid(1704180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704181, 1, "decb6c84ac40eb8b495d27d48bb6aa2da1f3a3db657c91ee4291a0329984b543")
addappid(1704182, 1, "6a7c4e937f79f46d622783be1d9b70b81c98751dbeea1d72a2c03533883ff9c1")
addappid(1704183, 1, "8947baefe31cae45a05e01f3fa6edd8f2141b099799577665624db6f6f7ed8bd")
