-- Lua provided by RyzenAPI 
-- Game: VOIDCRISIS
addappid(1817560)
addappid(1817561, 1, "db3c40c5e255e5c729f2421a9dbc99ab71547a512e852ddf64549f3aaddc470a")
