-- Lua provided by RyzenAPI
-- Game: 751950

-- MAIN APPLICATION
addappid(228984)
addappid(228990)
addappid(751950)

-- MAIN APP DEPOTS / PACKAGES
addappid(751952,0,"1dbb7d178f49c456e90ff8fb0cc7a05222bd66167aa6f75c76a1837f05cd0f34")
