-- Lua provided by RyzenAPI
-- Game: Game: SShield Reborn

-- MAIN APPLICATION
addappid(819880)
-- Game: addappid(819880)

-- MAIN APP DEPOTS / PACKAGES
addappid(819881, 1, "71f5ebf2060c5a05dd0b46efd5759957129ee25458883d2998ae7304dcd8d5c0")
