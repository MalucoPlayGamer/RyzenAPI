-- Lua provided by RyzenAPI 
-- Game: SShield Reborn
addappid(819880)
addappid(819881, 1, "71f5ebf2060c5a05dd0b46efd5759957129ee25458883d2998ae7304dcd8d5c0")
