-- Lua provided by RyzenAPI
-- Game: addappid(307130)

-- MAIN APPLICATION
addappid(307130)

-- MAIN APP DEPOTS / PACKAGES
addappid(307131, 1, "8ba910e412632536660c1480884b835c54e52dfe44888201aecf85ad5bbb2b39")
