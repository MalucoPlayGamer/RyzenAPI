-- Lua provided by RyzenAPI
-- Game: Game: AppID 362900

-- MAIN APPLICATION
addappid(362900)
-- Game: addappid(362900)

-- MAIN APP DEPOTS / PACKAGES
addappid(362901, 1, "6ef9b63df44fff0dcaca8ae7666cc07b4764276a45bf680fff203c8320227262")
