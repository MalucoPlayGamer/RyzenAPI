-- Lua provided by RyzenAPI
-- Game: LEVEL UP!

-- MAIN APPLICATION
addappid(332150)

-- MAIN APP DEPOTS / PACKAGES
addappid(332151, 1, "7a4895a66866385fb9310eef39538387575bee69ac27ce968c5590c6b3440162")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
