-- Lua provided by RyzenAPI
-- Game: 死亡编码-Death Code

-- MAIN APPLICATION
addappid(1819120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819121, 1, "544d77c9cba65bf316c17f4ddbdb2b30effeb2324b680acbd64857d7189e367c")

