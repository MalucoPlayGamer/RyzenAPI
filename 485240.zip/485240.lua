-- Lua provided by RyzenAPI
-- Game: AppID 485240

-- MAIN APPLICATION
addappid(485240)

-- MAIN APP DEPOTS / PACKAGES
addappid(485241, 1, "20bdcda3d520685f5fe1f4f1bbda203ceba11c42f10ffd9f7716547249a2e390")

