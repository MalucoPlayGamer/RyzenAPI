-- Lua provided by RyzenAPI
-- Game: AppID 1172830

-- MAIN APPLICATION
addappid(1172830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1172831, 1, "f4df2db0734ee580ad8832d3578784c329b7df93496fa5a0f7f8c37bad982c4d")

