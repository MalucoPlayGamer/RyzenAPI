-- Lua provided by RyzenAPI
-- Game: 1172830

-- MAIN APPLICATION
addappid(1172830)
-- Game: addappid(1172830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172831, 1, "f4df2db0734ee580ad8832d3578784c329b7df93496fa5a0f7f8c37bad982c4d")
