-- Lua provided by SkyAPI 
-- Game: AppID 1172830
addappid(1172830)
addappid(1172831, 1, "f4df2db0734ee580ad8832d3578784c329b7df93496fa5a0f7f8c37bad982c4d")
