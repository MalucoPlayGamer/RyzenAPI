-- Lua provided by RyzenAPI
-- Game: addappid(3101770)

-- MAIN APPLICATION
addappid(3101770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101771, 1, "a90af500793740aeb1d016807a9ed89bc371ee5a8e2a31cdcd2d438252c2d488")
