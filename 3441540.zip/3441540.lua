-- Lua provided by RyzenAPI
-- Game: 3441540

-- MAIN APPLICATION
addappid(3441540)
-- Game: addappid(3441540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441541, 1, "ebde51bd11a7ff9f489f9e1f60c8451bac18bd642bba3e7532a4eb9c3c9076aa")
addappid(3441542, 1, "ef9ca7e924c4feccc019676780633bbf52928ff9da62b154ff02f26e829b2941")
addappid(3441543, 1, "40316cfd86eb270866abc6546a87b2bb966beee39495909e7a6ac476d1aa215f")
