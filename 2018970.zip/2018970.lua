-- Lua provided by RyzenAPI
-- Game: Astro Colony Demo

-- MAIN APPLICATION
addappid(2018970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018971, 1, "1926e6c660e0ab535ae827cfeb469b0d1d02c78dfd60a6b100ff561dfbe76760")
