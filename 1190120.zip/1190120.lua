-- Lua provided by RyzenAPI
-- Game: Game: Good doktor

-- MAIN APPLICATION
addappid(1190120)
-- Game: addappid(1190120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190121, 1, "fa3736da4a111631d3080c2faaf3f5584df660890d90032d1e84d432fade4e61")
