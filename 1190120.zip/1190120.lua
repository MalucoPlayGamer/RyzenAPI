-- Lua provided by SkyAPI 
-- Game: Good doktor
addappid(1190120)
addappid(1190121, 1, "fa3736da4a111631d3080c2faaf3f5584df660890d90032d1e84d432fade4e61")
