-- Lua provided by RyzenAPI
-- Game: Hades' Star

-- MAIN APPLICATION
addappid(755800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(755801, 1, "55e6f6e188fd033ea0e95bbf4d8b87e978cab64dd28d4b7b06a0fef94db2c5f1")
addappid(755802, 1, "14a431464811bb8851523e443479c54830f0f60a46fe81101eced8177a972e1c")
addappid(755803, 1, "a0e50473748d0bb52bdc2f8f4015e46e5737f6e2ec28024ef96ad3bfec5676e6")

