-- Lua provided by RyzenAPI 
-- Game: Leave Me Alone: A Trip To Hell
addappid(444520)
addappid(444521, 1, "d148907cb9b0082614516a10e50342b2eaf7d4bb3a4abab950ac577f78594aae")
addappid(444522, 1, "ef86d69a00ceb75cfadbeda29d249cf31c3fb89983cc3f6cbd14ba08fbf82c49")
addappid(444523, 1, "7f241fd7807115d4f99c13ba4bab121886f6bb45102999ed02a691f2e89a2e05")
