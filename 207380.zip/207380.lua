-- Lua provided by RyzenAPI
-- Game: 207380

-- MAIN APPLICATION
addappid(207380)
addappid(334520)
-- Game: addappid(207380)

-- MAIN APP DEPOTS / PACKAGES
addappid(207381, 1, "c745f495cdd7dcfdc05d7d455c202399b48f044b3a733537ee46aa0d0211f38b")
