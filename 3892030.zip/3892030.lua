-- Lua provided by RyzenAPI
-- Game: 5 nights at Timokha 5: Island

-- MAIN APPLICATION
addappid(3892030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3892031,0,"efe0f2828fdfe8ee795d7dc75bb90b8c6d108cd5af0dff811d317772a0ae2c72")