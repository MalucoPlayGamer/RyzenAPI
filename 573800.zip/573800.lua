-- Lua provided by RyzenAPI
-- Game: Natari at the Bubble Planet

-- MAIN APPLICATION
addappid(573800)
-- Game: addappid(573800)

-- MAIN APP DEPOTS / PACKAGES
addappid(573801, 1, "12058fc45845cb3a67d2de7f5199c3bc4502f53bfaa0264b7dd6daea69ee41fa")
addappid(573802, 1, "e31193191242ae5b7f1958a9f996f58be8f9483bca7137712325b3e5f56d3a74")
