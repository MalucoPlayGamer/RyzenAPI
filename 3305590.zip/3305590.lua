-- Lua provided by RyzenAPI
-- Game: Game: HELLCAM Demo

-- MAIN APPLICATION
addappid(3305590)
-- Game: addappid(3305590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3305591, 1, "5f26870b3e69b15026cfa86a3db447a5714fc94b0581c0ef26113c6fb14e9761")
