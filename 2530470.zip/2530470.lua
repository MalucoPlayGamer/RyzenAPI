-- Lua provided by SkyAPI 
-- Game: Garden of Witches
addappid(2530470)
addappid(2530471, 1, "a978c4dc2cbf61036edb2e812dc4d23ab3ef9162446c75c0dd2bd87f384c49af")
