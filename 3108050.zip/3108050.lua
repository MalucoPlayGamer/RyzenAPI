-- Lua provided by RyzenAPI 
-- Game: 回生九命 The Nine Rebirths
addappid(3108050)
addappid(3108051, 1, "436c26c6ba34b688c92639cdbfb8eb939aa5ce09ea9b978c9d4fadc638ca1e85")
