-- Lua provided by RyzenAPI
-- Game: addappid(3108050)

-- MAIN APPLICATION
addappid(3108050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108051, 1, "436c26c6ba34b688c92639cdbfb8eb939aa5ce09ea9b978c9d4fadc638ca1e85")
