-- Lua provided by RyzenAPI 
-- Game: AppID 1105960
addappid(1105960)
addappid(1105961, 1, "bc778c65f2fee9ba05fe6262f489b58c8dc0290d08d4308792d7de0e8b5d3c0f")
