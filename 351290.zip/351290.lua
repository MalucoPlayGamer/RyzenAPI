-- Lua provided by RyzenAPI
-- Game: SURVIVAL: Postapocalypse Now

-- MAIN APPLICATION
addappid(351290)

-- MAIN APP DEPOTS / PACKAGES
addappid(351291, 1, "ecd63e9d2170accc4ecd20e5754bd1971f5325485fa436059d88844c3dd31b2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(446090)
addappid(1082370)
