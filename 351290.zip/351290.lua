-- Lua provided by RyzenAPI
-- Game: SURVIVAL: Postapocalypse Now

-- MAIN APPLICATION
addappid(351290)

-- MAIN APP DEPOTS / PACKAGES
addappid(351291, 1, "ecd63e9d2170accc4ecd20e5754bd1971f5325485fa436059d88844c3dd31b2d")
