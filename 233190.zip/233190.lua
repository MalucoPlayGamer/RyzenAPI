-- Lua provided by RyzenAPI
-- Game: Final Exam

-- MAIN APPLICATION
addappid(233190)

-- MAIN APP DEPOTS / PACKAGES
addappid(233191, 1, "37d4d62230532359fcfc10eb76b30f45a21f817dc6e949b22c16d26697768ff8")
addappid(233192, 1, "0806c06cadfac7f3d4aa64d627214f76f7a683be270eaeecc111fa6e44763b8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
