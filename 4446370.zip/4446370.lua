-- Lua provided by RyzenAPI
-- Game: Grit Shot

-- MAIN APPLICATION
addappid(4446370)

