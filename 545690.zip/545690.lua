-- Lua provided by RyzenAPI
-- Game: 545690

-- MAIN APPLICATION
addappid(545690)
-- Game: addappid(545690)

-- MAIN APP DEPOTS / PACKAGES
addappid(545691, 1, "bcef27faecc835c9e9817c79fd6e132ff336cf34e0aa68c210dc1cc40c5db17e")
