-- Lua provided by RyzenAPI
-- Game: Ertugrul of Ulukayin

-- MAIN APPLICATION
addappid(2133520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133521, 1, "01a536a66993f6a86afe23e020ffb386621f7b1c33113b83fbebca5943dc0397")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
