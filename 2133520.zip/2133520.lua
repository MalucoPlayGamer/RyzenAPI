-- Lua provided by RyzenAPI
-- Game: Ertugrul of Ulukayin

-- MAIN APPLICATION
addappid(2133520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133521, 1, "01a536a66993f6a86afe23e020ffb386621f7b1c33113b83fbebca5943dc0397")

