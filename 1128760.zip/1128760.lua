-- Lua provided by RyzenAPI
-- Game: 失落的琴弦 Demo

-- MAIN APPLICATION
addappid(1128760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128761, 1, "b43f99b242104072185a3dc428a6bc06340aaf57ffd42fbe23dd3687103a41a5")
addappid(1128762, 1, "a943a0cb1b8c3b8850b655ae67bebc0cf07590099f971e38e687eb5dbff91d8a")
