-- 3814540's Lua and Manifest Created by Hubcap Manifest
-- Catio Simulator
-- Created: July 24, 2026 at 12:05:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3814540) -- Catio Simulator
-- MAIN APP DEPOTS
addappid(3814541, 1, "becf99ff9ec5569399bb936ca202a4472aaa669a841f768807ae66889e6680dc") -- Depot 3814541
setManifestid(3814541, "3448997472703114462", 205729848)