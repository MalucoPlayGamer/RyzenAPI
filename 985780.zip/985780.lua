-- Lua provided by RyzenAPI
-- Game: Jack Axe

-- MAIN APPLICATION
addappid(985780)

-- MAIN APP DEPOTS / PACKAGES
addappid(985781, 1, "c413fa5efc5d6cd81ed25de5770da7b9101e330622f1a53c654235ebcf3fe615")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
