-- Lua provided by SkyAPI 
-- Game: Jack Axe
addappid(985780)
addappid(985781, 1, "c413fa5efc5d6cd81ed25de5770da7b9101e330622f1a53c654235ebcf3fe615")
