-- Lua provided by RyzenAPI
-- Game: addappid(283840)

-- MAIN APPLICATION
addappid(283840)

-- MAIN APP DEPOTS / PACKAGES
addappid(283841, 1, "58bc92effd3e703643951263ddfbaa44664819aef5a656edb843cd39468d7857")
