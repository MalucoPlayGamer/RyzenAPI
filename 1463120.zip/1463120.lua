-- Lua provided by RyzenAPI
-- Game: College Kings - The Complete Season

-- MAIN APPLICATION
addappid(1463120)
addappid(1624520)
addappid(1732640)
addappid(1847490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463121, 1, "028021ea8aaaaea17bfede62ddd261a646c576dea9c46cacbcd786f967eb3cd5")

