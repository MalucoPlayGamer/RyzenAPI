-- Lua provided by RyzenAPI
-- Game: Cyberflight

-- MAIN APPLICATION
addappid(1657350)
-- Game: addappid(1657350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657351, 1, "4a298a01d89cb7b931c21d2707170f04334b0f9b724301f37fd36ada55d2f986")
