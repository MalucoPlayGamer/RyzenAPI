-- Lua provided by SkyAPI 
-- Game: Cyberflight
addappid(1657350)
addappid(1657351, 1, "4a298a01d89cb7b931c21d2707170f04334b0f9b724301f37fd36ada55d2f986")
