-- Lua provided by RyzenAPI
-- Game: Love, Elections, and Chocolate

-- MAIN APPLICATION
addappid(3027600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027601, 1, "155d25dda145435e58e83618d31eb540d097627233eddaf86913f8465643ab36")

