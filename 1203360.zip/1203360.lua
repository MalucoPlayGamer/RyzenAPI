-- Lua provided by RyzenAPI
-- Game: Core Defense

-- MAIN APPLICATION
addappid(1203360)
addappid(1563040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203361, 1, "ad8db6fa83f9e1f0de4560ad81918287edd2ff1da750b57df34730a1b546568f")

