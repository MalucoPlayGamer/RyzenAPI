-- Lua provided by RyzenAPI
-- Game: 77p egg: Eggwife

-- MAIN APPLICATION
addappid(1317020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317022,0,"030dd973a7f90336a17442a91a6c5587ea6edeb974b76c9170871e6b533679ea")

