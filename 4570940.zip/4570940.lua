-- 4570940's Lua and Manifest Created by Hubcap Manifest
-- Monster Flipper
-- Created: July 15, 2026 at 16:02:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4570940) -- Monster Flipper
-- MAIN APP DEPOTS
addappid(4570941, 1, "6bed76a8291a189402a42a0b73fc656d3e0c98b50468b4033189c040c853b41b") -- Depot 4570941
setManifestid(4570941, "4062430179484694328", 140495792)