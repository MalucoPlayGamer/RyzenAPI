-- Lua provided by RyzenAPI
-- Game: AppID 1066610

-- MAIN APPLICATION
addappid(1066610)
-- Game: addappid(1066610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066611, 1, "c070edb6fe4d5c1e1dc8f1f606a0f8fd8047dff8028162302b2627019fcb651d")
