-- Lua provided by RyzenAPI
-- Game: Werner Waffenwerke: Arms Tycoon

-- MAIN APPLICATION
addappid(3048030) -- Werner Waffenwerke: Arms Tycoon

-- MAIN APP DEPOTS / PACKAGES
addappid(3048031, 1, "d2b6d4aa4a0122237799a39c06a7a0a936de9edc7fff5b4fcd5562042a6053d3") -- Depot 3048031
