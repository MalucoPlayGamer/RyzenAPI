-- Lua provided by RyzenAPI
-- Game: The Spirit of the Samurai Demo

-- MAIN APPLICATION
addappid(2208650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208651, 1, "5032cd6147fd80f1b1190bce922b825fd6ed402b43257affbd4ce88a6dcdca28")
