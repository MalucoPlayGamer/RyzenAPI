-- Lua provided by RyzenAPI
-- Game: Game: Arcane Board

-- MAIN APPLICATION
addappid(3126090)
-- Game: addappid(3126090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126091, 1, "bf35fe557860211d8533ece4a3c65e6a08ccf987f051309cc590d29ebd21d19b")
