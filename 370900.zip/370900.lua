-- Lua provided by RyzenAPI
-- Game: 370900

-- MAIN APPLICATION
addappid(370900)
-- Game: addappid(370900)

-- MAIN APP DEPOTS / PACKAGES
addappid(370901, 1, "bba5cd0ff99d4d40e6556861b335712dc4ad960286ec187226d9cde8b06e5b3a")
