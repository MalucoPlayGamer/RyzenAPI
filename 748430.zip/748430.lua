-- Lua provided by SkyAPI 
-- Game: AppID 748430
addappid(748430)
addappid(748431, 1, "c708d4f26efb51e308fe60a6b2220915d2becce5824489550652ab937ef2896f")
