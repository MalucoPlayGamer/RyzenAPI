-- Lua provided by RyzenAPI
-- Game: QLORB

-- MAIN APPLICATION
addappid(791970)

-- MAIN APP DEPOTS / PACKAGES
addappid(791971, 1, "ca6afd471f519b0b909a738e0c8cfef8d017bb0b44b044480cea5926873561c1")
