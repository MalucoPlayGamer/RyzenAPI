-- Lua provided by RyzenAPI
-- Game: addappid(1371170)

-- MAIN APPLICATION
addappid(1371170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371171, 1, "041b18f5798fcf3d2b5d6af1ef53a3905d8313d02d44947254f0d705ab7b4a88")
