-- Lua provided by SkyAPI 
-- Game: 3 min per day! Improve your aged eyes(Presbyopia)
addappid(1371170)
addappid(1371171, 1, "041b18f5798fcf3d2b5d6af1ef53a3905d8313d02d44947254f0d705ab7b4a88")
