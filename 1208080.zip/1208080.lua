-- Lua provided by RyzenAPI
-- Game: Cable Guardian

-- MAIN APPLICATION
addappid(1208080)
addappid(1261250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208081, 1, "a6deef6ad49edeb82825a6b3f259b4c092adcec81ff2c30b6d2d68c62da8461f")
