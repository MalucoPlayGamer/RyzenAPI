-- Lua provided by RyzenAPI
-- Game: At Night

-- MAIN APPLICATION
addappid(2646030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2646031, 1, "281aa15e875f57a8af5353fe53a75199067c4e2ad8c5441eb4c723278de58cbd")

