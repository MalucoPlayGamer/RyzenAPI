-- Lua provided by RyzenAPI
-- Game: At Night

-- MAIN APPLICATION
addappid(2646030)
-- Game: addappid(2646030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646031, 1, "281aa15e875f57a8af5353fe53a75199067c4e2ad8c5441eb4c723278de58cbd")
