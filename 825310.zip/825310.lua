-- Lua provided by RyzenAPI
-- Game: Dude Simulator 2

-- MAIN APPLICATION
addappid(825310)

-- MAIN APP DEPOTS / PACKAGES
addappid(825311, 1, "53fbaa458dcc3e6c16a4833eb63c4a499b996e40d167d3d55a371590b82c8ed5")
