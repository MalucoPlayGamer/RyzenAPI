-- Lua provided by RyzenAPI
-- Game: addappid(710160)

-- MAIN APPLICATION
addappid(710160)

-- MAIN APP DEPOTS / PACKAGES
addappid(710161, 1, "f204787ec193c242d7d936b67c7c1338da1e32894b3a4947483de770f11f0cfb")
