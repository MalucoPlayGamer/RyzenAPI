-- Lua provided by RyzenAPI
-- Game: Mula: The Cycle of Shadow

-- MAIN APPLICATION
addappid(710160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(710161, 1, "f204787ec193c242d7d936b67c7c1338da1e32894b3a4947483de770f11f0cfb")

