-- Lua provided by RyzenAPI
-- Game: 3038290

-- MAIN APPLICATION
addappid(3038290)
-- Game: addappid(3038290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038291, 1, "ab8fb25480e2996593278db9d099b9f31edf92d699f621db0c4f3cbf839735ed")
