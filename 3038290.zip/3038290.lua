-- Lua provided by RyzenAPI 
-- Game: EXPEDITION TO THE BACKROOMS
addappid(3038290)
addappid(3038291, 1, "ab8fb25480e2996593278db9d099b9f31edf92d699f621db0c4f3cbf839735ed")
