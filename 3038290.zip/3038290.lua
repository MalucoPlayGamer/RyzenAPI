-- Lua provided by RyzenAPI
-- Game: EXPEDITION TO THE BACKROOMS

-- MAIN APPLICATION
addappid(3038290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3038291, 1, "ab8fb25480e2996593278db9d099b9f31edf92d699f621db0c4f3cbf839735ed")

