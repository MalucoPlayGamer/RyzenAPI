-- Lua provided by RyzenAPI
-- Game: All the Darkest Places

-- MAIN APPLICATION
addappid(2879670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879671, 1, "5d33205a3624356634b8109fa5720f310ee8aa8e158ddf96778ff07b178708aa")
