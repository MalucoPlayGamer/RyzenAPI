-- Lua provided by RyzenAPI
-- Game: White Knuckle Demo

-- MAIN APPLICATION
addappid(3218540)
-- Game: addappid(3218540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3218541, 1, "22511413ca5f6c2ac888e2eb2051c99b303f94c6f0c9a63a626ced9062294831")
