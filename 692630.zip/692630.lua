-- Lua provided by RyzenAPI
-- Game: 692630

-- MAIN APPLICATION
addappid(692630)
-- Game: addappid(692630)

-- MAIN APP DEPOTS / PACKAGES
addappid(692631, 1, "66fd79a6495556f28351766edef3485e5bbc360ebd3ed2597c2de17d8bfd5331")
