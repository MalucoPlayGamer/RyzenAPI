-- Lua provided by RyzenAPI
-- Game: setManifestid(339914,"4013598307863288397")

-- MAIN APPLICATION
addappid(339910)

-- MAIN APP DEPOTS / PACKAGES
addappid(339914,0,"e5d8e8470eb7b7b99cb1050659d27324faa12f3bedf387a4fbaefa0cdf584ea4")

