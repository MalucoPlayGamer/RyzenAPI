-- Lua provided by RyzenAPI
-- Game: Uncraft World

-- MAIN APPLICATION
addappid(339910)

-- MAIN APP DEPOTS / PACKAGES
addappid(339914,0,"e5d8e8470eb7b7b99cb1050659d27324faa12f3bedf387a4fbaefa0cdf584ea4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
