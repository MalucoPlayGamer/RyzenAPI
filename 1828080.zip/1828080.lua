-- Lua provided by SkyAPI 
-- Game: Legend of Tai gong
addappid(1828080)
addappid(1828081, 1, "789b9ac930239d6f6e371455c2bb5a29ec5ee1fdf58056475a28e84c17c1ee47")
