-- Lua provided by RyzenAPI
-- Game: addappid(1828080)

-- MAIN APPLICATION
addappid(1828080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828081, 1, "789b9ac930239d6f6e371455c2bb5a29ec5ee1fdf58056475a28e84c17c1ee47")
