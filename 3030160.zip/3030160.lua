-- Lua provided by RyzenAPI
-- Game: Neon Fantasy: Mushrooms

-- MAIN APPLICATION
addappid(3030160)
-- Game: addappid(3030160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030161, 1, "602de6fd2afa54a671011426fbc325ee78294138ca2137fbb0e25c3c8a808cb2")
