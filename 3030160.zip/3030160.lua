-- Lua provided by SkyAPI 
-- Game: Neon Fantasy: Mushrooms
addappid(3030160)
addappid(3030161, 1, "602de6fd2afa54a671011426fbc325ee78294138ca2137fbb0e25c3c8a808cb2")
