-- Lua provided by RyzenAPI
-- Game: AppID 2997980

-- MAIN APPLICATION
addappid(2997980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997981, 1, "f09676618ac735e45ca9356c904e87cad18ff2bb61e65545637b745594c233e3")
addappid(2997982, 1, "1fea75c094a5a0e396510004703b4ef3f4f790bbc28638b137082f9bd622afa3")
addappid(2997983, 1, "829a7d74a7d3f152341c00dc09523ef7b2c7183d084fedffce9eb75d2593b91b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4546000)
