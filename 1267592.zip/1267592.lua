-- Lua provided by RyzenAPI
-- Game: addappid(1267592)

-- MAIN APPLICATION
addappid(1267592)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267592,0,"3adff218a7b385dcbc90f797a2686fbbf89a788bfc0ec795296b475f6d451c3d")
