-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1267592)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267592,0,"3adff218a7b385dcbc90f797a2686fbbf89a788bfc0ec795296b475f6d451c3d")

