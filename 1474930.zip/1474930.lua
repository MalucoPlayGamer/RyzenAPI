-- Lua provided by RyzenAPI
-- Game: Heavy Cargo - The Truck Simulator

-- MAIN APPLICATION
addappid(1474930)
addappid(3581920)
addappid(4244090)
addappid(4442670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474931,0,"9ebe45ec36b6017e74fbffec6a0f5877792ef03b356231266a2e8503a72f999b")

