-- Lua provided by RyzenAPI
-- Game: Heavy Cargo - The Truck Simulator

-- MAIN APPLICATION
addappid(1474930)
addappid(3581920)
addappid(4244090)
addappid(4442670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1474931,0,"9ebe45ec36b6017e74fbffec6a0f5877792ef03b356231266a2e8503a72f999b")

