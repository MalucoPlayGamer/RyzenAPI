-- Lua provided by SkyAPI 
-- Game: Etrian Odyssey III HD
addappid(1810820)
addappid(1810821, 1, "5c6aecc71489adfb4126754a88937595c7b8a093d72c7376ab979048558ba4fe")
addappid(1851230, 0, "6b140f7d850cb23d53d19e373c34c220b5b1753e675b54444484f011f88b0758")
