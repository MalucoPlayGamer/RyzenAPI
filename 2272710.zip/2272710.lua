-- Lua provided by RyzenAPI
-- Game: addappid(2272710)

-- MAIN APPLICATION
addappid(2272710)
addappid(2276320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272711, 1, "816d0fe71aa6f65ea2232b91e0ab1700610bd6710dcf8a6d709fa36dbc118397")
addappid(2272712, 1, "f6f183ba9933f063fd07dafbb25a96d3c9b950f4bd321f3b92ef058d62e51b1e")
