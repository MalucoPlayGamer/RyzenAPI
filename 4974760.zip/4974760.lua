-- 4974760's Lua and Manifest Created by Hubcap Manifest
-- Aqua Scrap: Deep Clean
-- Created: August 27, 2026 at 13:30:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4974760) -- Aqua Scrap: Deep Clean
-- MAIN APP DEPOTS
addappid(4974761, 1, "03976a746a78abdfdce5e9ba6033b6d0f3410e5b606ea4065ae3ef87091a4f74") -- Depot 4974761
setManifestid(4974761, "4841225163122501560", 1003558078)
addappid(4974762, 1, "d9cfbb79ebf555821b9e0a1ef5d5e47a49702d2b69327bfe92686a15eb9a568d") -- Depot 4974762
setManifestid(4974762, "3052026118375589809", 1124141877)