-- Lua provided by RyzenAPI
-- Game: Aqua Scrap: Deep Clean

-- MAIN APPLICATION
addappid(4974760) -- Aqua Scrap: Deep Clean

-- MAIN APP DEPOTS / PACKAGES
addappid(4974761, 1, "03976a746a78abdfdce5e9ba6033b6d0f3410e5b606ea4065ae3ef87091a4f74") -- Depot 4974761
addappid(4974762, 1, "d9cfbb79ebf555821b9e0a1ef5d5e47a49702d2b69327bfe92686a15eb9a568d") -- Depot 4974762

