-- Lua provided by RyzenAPI
-- Game: addappid(2149280)

-- MAIN APPLICATION
addappid(2149280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149280,0,"381f8b708871daa38594dffa4e9871100b6c0aa068857d0e7abbc7eadfb6b719")
