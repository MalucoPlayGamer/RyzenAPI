-- Lua provided by RyzenAPI
-- Game: Game: DEEPER CREEPER LUST🐙😱

-- MAIN APPLICATION
addappid(2791140)
-- Game: addappid(2791140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791141, 1, "2f7774931da87e011479d075bcf8aef7c9aed27d14a0a25955470a544a46eb60")
