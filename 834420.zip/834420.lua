-- Lua provided by RyzenAPI
-- Game: RollingBall: Unlimited World

-- MAIN APPLICATION
addappid(834420)

-- MAIN APP DEPOTS / PACKAGES
addappid(834421, 1, "efbbeb3c4fc14143e5afcf84dca5a37f329c8a9686d06a4cee0593e5a86bbfa9")
