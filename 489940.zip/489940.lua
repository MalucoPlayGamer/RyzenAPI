-- Lua provided by RyzenAPI
-- Game: BATTALION: Legacy

-- MAIN APPLICATION
addappid(489940)
-- Game: addappid(489940)

-- MAIN APP DEPOTS / PACKAGES
addappid(489941, 1, "74435adc1164efd21521555018ef3e81cc7892933c8c9898b4bc4957e7d0997f")
