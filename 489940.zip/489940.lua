-- Lua provided by RyzenAPI
-- Game: BATTALION: Legacy

-- MAIN APPLICATION
addappid(489940)

-- MAIN APP DEPOTS / PACKAGES
addappid(489941, 1, "74435adc1164efd21521555018ef3e81cc7892933c8c9898b4bc4957e7d0997f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(794150)
addappid(1133020)
addappid(1167740)
