-- Lua provided by RyzenAPI
-- Game: addappid(1417440)

-- MAIN APPLICATION
addappid(1417440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417441, 1, "02068ee8d7bbec44e1dc247bbe4a9cd38b9f933a3d219fb0d6d2d7d0461206b5")
