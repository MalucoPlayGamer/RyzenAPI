-- Lua provided by RyzenAPI
-- Game: 1483880

-- MAIN APPLICATION
addappid(1483880)
-- Game: addappid(1483880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483881, 1, "ed405e5b586b6583c831b0f5fe3cbd0583484103c6320668c4be6b188379c9ce")
