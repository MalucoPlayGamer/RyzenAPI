-- 4123450's Lua and Manifest Created by Hubcap Manifest
-- KABOOM Farm
-- Created: July 22, 2026 at 21:15:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4123450) -- KABOOM Farm
-- MAIN APP DEPOTS
addappid(4123451, 1, "c7e86eb0c9033346dfcb6f4cb08392c6ad16131fbb3d3272f1a5263b8e3a7b06") -- Depot 4123451
setManifestid(4123451, "555127044060303032", 698353591)
addappid(4123452, 1, "f8e8b81e8fdb9638b3029dd7e2188fe0f43f05b3f17322781e281660a9174398") -- Depot 4123452
setManifestid(4123452, "8362044137129935366", 696575137)
addappid(4123453, 1, "46ace4f6a73e8e6edac6ebb22da4069641912502bd0910350e870891b68b7d0a") -- Depot 4123453
setManifestid(4123453, "4225517356337750835", 696661150)