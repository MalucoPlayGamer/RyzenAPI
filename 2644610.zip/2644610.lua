-- Lua provided by RyzenAPI 
-- Game: Menace from the Deep
addappid(2644610)
addappid(2644611, 1, "1904090690a12c756694f903980a0e97fb0057b2dad6885e1cda140e8041d758")
addappid(3280710, 0, "a0e09b941c844c8f0f0c8f28afb56e21a207c0e08438f7d20424ccf4965eaf66")
