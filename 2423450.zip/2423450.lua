-- Lua provided by RyzenAPI
-- Game: Backrooms: Realm of Shadows Soundtracks

-- MAIN APPLICATION
addappid(2423450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423451, 1, "87c86aa504026637f9ab3522724d8f59e4a2faee408f94f4218ba7f347533b41")

