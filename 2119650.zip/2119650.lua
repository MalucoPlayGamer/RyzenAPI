-- Lua provided by RyzenAPI
-- Game: addappid(2119650)

-- MAIN APPLICATION
addappid(2119650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119651, 1, "b39bb0c3aeebfa987ee4c197a2da4d739d10ca111102dfb96be8f25c9015082b")
