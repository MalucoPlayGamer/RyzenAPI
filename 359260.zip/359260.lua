-- Lua provided by RyzenAPI
-- Game: Game: Green Moon

-- MAIN APPLICATION
addappid(359260)
-- Game: addappid(359260)

-- MAIN APP DEPOTS / PACKAGES
addappid(359261, 1, "b96b7ef686252301f7b04ca375fa6769f8cfd37b4c7f20bf97d5704d3ae7ef96")
