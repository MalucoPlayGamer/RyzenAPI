-- Lua provided by RyzenAPI
-- Game: Sorceress Demo

-- MAIN APPLICATION
addappid(2435820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435821, 1, "480b5e2972b9a6fb6b04ecaec5ce5272d9ba7219f1918addc98368ca826676f4")
