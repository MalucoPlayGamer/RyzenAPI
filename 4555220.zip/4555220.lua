-- Lua provided by RyzenAPI
-- Game: サチコの七不思議

-- MAIN APPLICATION
addappid(4555220)

-- MAIN APP DEPOTS / PACKAGES
addappid(4555221,0,"2a6d8362c3a5f7bbaedff1208ed3fcd64cbc24151facd3b2803c9e708bb42ce8")

