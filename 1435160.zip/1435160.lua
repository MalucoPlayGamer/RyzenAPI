-- Lua provided by SkyAPI 
-- Game: NYANCO MINE
addappid(1435160)
addappid(1435161, 1, "1b46250d62a20d4d95afce92941473f7f5faa31268bd399bfc2669ce332a0eab")
addappid(1435260, 0, "7a51b9377223c40ee7b68a80664b92f066f17e12f5bae1d783642af6f190e04d")
