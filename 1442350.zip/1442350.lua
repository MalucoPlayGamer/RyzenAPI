-- Lua provided by RyzenAPI
-- Game: addappid(1442350)

-- MAIN APPLICATION
addappid(1442350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442351, 1, "f8c7fc32746eabd9301a25e3d7dc005b914e1071e7fb07cf69c086dff8797b06")
