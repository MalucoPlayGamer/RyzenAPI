-- Lua provided by RyzenAPI
-- Game: AppID 656890

-- MAIN APPLICATION
addappid(656890)

-- MAIN APP DEPOTS / PACKAGES
addappid(656891, 1, "97db31e30c3105afa4572c5056a74daa2b3ba4c5878280de4ff095cc9eaf81c1")
addappid(656892, 1, "063a483bc723a6f54160ede4ae30ab89f83403f9dc71c27b0532ad341c8910a8")
addappid(656893, 1, "97e0b2acdfce79b25ac8edc14438bc51e685f30eb2cb45313d87fabcbaf9828f")
addappid(656894, 1, "2bf74282af8321c6659d569dc2b336a9ae02572a65ff99507981db3c2c083335")
addappid(656895, 1, "c68122427e840fd2c7741cfd0488cda8ae9df8e4aa9edb6bf74a6c4fcbdebc21")
addappid(656896, 1, "a902a749fb7b0c47131238950060d557d44755a9f3b102a5deba8cc7fab39706")
addappid(656897, 1, "3bfa90cb73706aa86c61bc556019063529da3bc3f02dbc28d02b19e088921a07")
addappid(656898, 1, "ea62da6aa88368f3c1123ad3a8a47e1a485e9a498d7e1ba7f836621ec9bde59f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229010, 1, "9ea8b334311d1b69b962aac11d4cce01f3dfb21722d4198c12314f2d67a0196f") -- (windows)
