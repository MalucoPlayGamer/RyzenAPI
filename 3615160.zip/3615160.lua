-- Lua provided by RyzenAPI 
-- Game: Teddy's Haven
addappid(3615160)
addappid(3615161, 1, "f41e04a71bb0bfcaecd7722b2d1a181e80bb1b08012861f85a3f74b88dc48da2")
addappid(4866880)
