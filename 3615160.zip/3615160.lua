-- Lua provided by RyzenAPI
-- Game: 3615160

-- MAIN APPLICATION
addappid(3615160)
addappid(4866880)
-- Game: addappid(3615160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3615161, 1, "f41e04a71bb0bfcaecd7722b2d1a181e80bb1b08012861f85a3f74b88dc48da2")
