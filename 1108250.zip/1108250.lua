-- Lua provided by RyzenAPI
-- Game: addappid(1108250)

-- MAIN APPLICATION
addappid(1108250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108251, 1, "5283d43da9d7addd0f34e822c27832c3f8b380fd003ba2f8753959449af74d05")
