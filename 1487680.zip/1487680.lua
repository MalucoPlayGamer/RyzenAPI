-- Lua provided by RyzenAPI
-- Game: Broken Universe - Tower Defense

-- MAIN APPLICATION
addappid(1487680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487681, 1, "f3bd53c91c7fc4c4e5534a89f4d726976f9ff811e27a5109e88315a8f1f142d9")

