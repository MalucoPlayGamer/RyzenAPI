-- Lua provided by RyzenAPI 
-- Game: Little Adventurer Treasure Hunt
addappid(3429910)
addappid(3429911, 1, "f0caa4b89c221133e942151fd5dd452762bf48424bb7d38020b75ae5719db4e0")
