-- Lua provided by RyzenAPI
-- Game: addappid(1385740)

-- MAIN APPLICATION
addappid(1385740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385741, 1, "d7184e98cbabfceed40fc0faea8e8d62f13cc334a63457ef3887666a57c42c52")
