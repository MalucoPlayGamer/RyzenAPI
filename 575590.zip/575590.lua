-- Lua provided by RyzenAPI
-- Game: AppID 575590

-- MAIN APPLICATION
addappid(575590)
-- Game: addappid(575590)

-- MAIN APP DEPOTS / PACKAGES
addappid(575591, 1, "22f082cf8f82de0a66c1ddaaccfa770b67e8857803d4731a3399363a92cbb23d")
