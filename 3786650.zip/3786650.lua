-- Lua provided by RyzenAPI
-- Game: Yuika My Bestie

-- MAIN APPLICATION
addappid(3786650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3786651, 1, "5406908b88b28b97d0e62b326397b895faf8b410c371b39a7c9d8c6532ecb1e3")

