-- Lua provided by SkyAPI 
-- Game: ClickBit
addappid(674220)
addappid(674221, 1, "c23db60d27b3134ef176c8664e4f85d6deb8e5e8661419b2a85d007e5815fa6b")
