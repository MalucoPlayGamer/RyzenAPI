-- Lua provided by RyzenAPI
-- Game: Game: Scrapnaut

-- MAIN APPLICATION
addappid(1323900)
-- Game: addappid(1323900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323901, 1, "386a977d71bf4c709d071c740ec4cf11d026dab3db5dc311316ee20d5ad57d90")
