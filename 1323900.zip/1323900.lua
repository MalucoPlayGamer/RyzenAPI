-- Lua provided by SkyAPI 
-- Game: Scrapnaut
addappid(1323900)
addappid(1323901, 1, "386a977d71bf4c709d071c740ec4cf11d026dab3db5dc311316ee20d5ad57d90")
