-- Lua provided by RyzenAPI
-- Game: GOLDRUSHERS

-- MAIN APPLICATION
addappid(710630)

-- MAIN APP DEPOTS / PACKAGES
addappid(710631,0,"aefab6f838d7a3c695e65da1a414b060abe30b4e3ee2c64ddab4a0c208c5ae68")

