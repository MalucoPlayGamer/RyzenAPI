-- Lua provided by RyzenAPI
-- Game: 1258310

-- MAIN APPLICATION
addappid(1258310)
-- Game: addappid(1258310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258311, 1, "0738a8f96f3926d9ae1254ac79b857539a15be21e7c291f8a4073e8eb89db450")
