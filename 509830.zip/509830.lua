-- Lua provided by RyzenAPI
-- Game: Evil Robots From N1M

-- MAIN APPLICATION
addappid(509830)

-- MAIN APP DEPOTS / PACKAGES
addappid(509831,0,"28967a634b50bafe18f1d03b9b6166008099932ef6dc588b42805db5fc40b4b2")

