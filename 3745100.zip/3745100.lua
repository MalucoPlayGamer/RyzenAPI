-- Lua provided by RyzenAPI
-- Game: addappid(3745100)

-- MAIN APPLICATION
addappid(3745100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3745101, 1, "01bb3b56f157d8262f6ce99cf1eea5e3ff866cf9e3ab0f81f7b1ad965ee69572")
