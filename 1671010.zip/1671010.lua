-- Lua provided by RyzenAPI
-- Game: 1671010

-- MAIN APPLICATION
addappid(1671010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671010,0,"e6765e0ade4b442fed4157dfc2e00d246651c3acb4e6bcf6a525456086dcda96")

