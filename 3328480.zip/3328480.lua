-- Lua provided by RyzenAPI
-- Game: addappid(3328480)

-- MAIN APPLICATION
addappid(3328480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328481, 1, "a7acd339c1d95daeaf0c898cdb6e2b80f71b6a9b1d322f84d80ba1a393bfe586")
