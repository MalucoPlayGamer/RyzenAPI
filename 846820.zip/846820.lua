-- Lua provided by RyzenAPI
-- Game: AppID 846820

-- MAIN APPLICATION
addappid(846820)

-- MAIN APP DEPOTS / PACKAGES
addappid(846821, 1, "ff302a411aef012568180a75ce5b40a4f70011a12cdb447af44c7bfc184ea1c3")
addappid(846823, 1, "8f3bbc2ee2708f43337903d592aaa3a89d556bcb7b129ae596ae444c8fb918aa")
addappid(846824, 1, "f37b8d36c16928fb2feadfd181fd454afc0dbfce3b8828d346e71c58ed813178")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(889300)
