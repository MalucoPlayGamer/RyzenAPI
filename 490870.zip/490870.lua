-- Lua provided by RyzenAPI 
-- Game: Weird Hero
addappid(490870)
addappid(490871, 1, "528a50d66572e62ed8b62c66e231e4af49505dca4673aa6c598fc079f23e5793")
addappid(490872, 1, "d2035773ddd706ab2c677299cd45a553cbddf59b4ce3a47085225c3426afa996")
