-- Lua provided by RyzenAPI
-- Game: Witches' Legacy: Slumbering Darkness Collector's Edition

-- MAIN APPLICATION
addappid(586710)

-- MAIN APP DEPOTS / PACKAGES
addappid(586711,0,"74f0ad09578b92ad196d2ce7445955f57c7f44bdbf66c861236c33088243cd68")

