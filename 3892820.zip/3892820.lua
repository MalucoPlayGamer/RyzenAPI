-- Lua provided by RyzenAPI
-- Game: Messy Hearts

-- MAIN APPLICATION
addappid(3892820)

