-- Lua provided by RyzenAPI
-- Game: Messy Hearts

-- MAIN APPLICATION
addappid(3892820)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4854450)
