-- Lua provided by RyzenAPI
-- Game: Nekoview-DESCENDANT OF NIGHTMARE artworks

-- MAIN APPLICATION
addappid(1448582)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448582,0,"d1245b411ce9cc50c4387ada2103a276b95041451ff4bec7cdf6d8fcdb90663e")

