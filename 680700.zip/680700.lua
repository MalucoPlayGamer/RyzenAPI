-- Lua provided by RyzenAPI
-- Game: Game: OK K.O.! Let’s Play Heroes

-- MAIN APPLICATION
addappid(680700)
addappid(732700)
-- Game: addappid(680700)

-- MAIN APP DEPOTS / PACKAGES
addappid(680701, 1, "21fa13cd367fc4d49fbfe26eea9029dd359407bd2577ecc683ff7fc8480c2e8b")
