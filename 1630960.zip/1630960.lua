-- Lua provided by RyzenAPI
-- Game: 1630960

-- MAIN APPLICATION
addappid(1630960)
-- Game: addappid(1630960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630961, 1, "a83745bbd4f1c3c90e05b3f5c601fe796ed6c8ea860037da51f84bd11dacd425")
addappid(1630962, 1, "9376071f44d9b23d0d504fd6746384da448826cb31ee19c2c917fef96a779bbc")
addappid(1630963, 1, "0ed6b34de467b14e89c77b2b578d759bf05baf26718ad37f32745dd2cdebcf5b")
