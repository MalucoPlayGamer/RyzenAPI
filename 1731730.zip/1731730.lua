-- Lua provided by RyzenAPI 
-- Game: Snowyland
addappid(1731730)
addappid(1731731, 1, "b860c1f53b127b1994a0285435da3ff767872cb64bc314b47f1cce418770f262")
addappid(1731732, 1, "b49f49007227bb8c27870293cc90bef0f8d79a0e3305d78715458f25cea347ee")
