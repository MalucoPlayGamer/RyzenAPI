-- Lua provided by RyzenAPI 
-- Game: Cattle Country
addappid(2818150)
addappid(2818151, 1, "d1dbe30d60e27a7c60076a2552a5b64927fc6070a0c5b12b123dffcdeff05ad1")
