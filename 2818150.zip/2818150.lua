-- Lua provided by RyzenAPI
-- Game: Cattle Country

-- MAIN APPLICATION
addappid(2818150)
-- Game: addappid(2818150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2818151, 1, "d1dbe30d60e27a7c60076a2552a5b64927fc6070a0c5b12b123dffcdeff05ad1")
