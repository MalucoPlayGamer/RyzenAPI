-- Lua provided by RyzenAPI
-- Game: Venture to the Vile

-- MAIN APPLICATION
addappid(2153750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153751, 1, "f7c29b9cbc0092f2de515748f453b446e1d61a6a1c4f97271bd643e6c555b0ed")

