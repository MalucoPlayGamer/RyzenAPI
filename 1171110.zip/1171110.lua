-- Lua provided by RyzenAPI
-- Game: AppID 1171110

-- MAIN APPLICATION
addappid(1171110)
-- Game: addappid(1171110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171111, 1, "240e26c999212912c764bc8b4485d48ca04e5f55c26acffb21e7b8eecf82743e")
