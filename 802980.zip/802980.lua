-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(802980)

-- MAIN APP DEPOTS / PACKAGES
addappid(802980,0,"8e8ffbaeb9c95260f24109834345a61a9c159f3b11be50fafa442c03ab4d25ce")
