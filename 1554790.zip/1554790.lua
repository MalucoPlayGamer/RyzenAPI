-- Lua provided by RyzenAPI
-- Game: Coloring Game 4

-- MAIN APPLICATION
addappid(1554790)
