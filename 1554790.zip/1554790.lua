-- Lua provided by RyzenAPI
-- Game: Coloring Game 4

-- MAIN APPLICATION
addappid(1554790)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1582820)
addappid(1582821)
addappid(1601290)
addappid(1601291)
addappid(1622020)
addappid(1622021)
addappid(1635170)
addappid(1635171)
addappid(1698250)
addappid(1698251)
addappid(1698252)
addappid(1739890)
addappid(1739891)
addappid(1761890)
addappid(1791670)
addappid(1813810)
addappid(1843120)
addappid(1843121)
addappid(1900310)
addappid(1900311)
addappid(1981730)
addappid(2108280)
addappid(2108281)
addappid(2175280)
