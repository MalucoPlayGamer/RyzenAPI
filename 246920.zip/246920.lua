-- Lua provided by SkyAPI 
-- Game: Bombernauts
addappid(246920)
addappid(246921, 1, "8c02d77e1f2afc66559e3fe799a355bd3fd714ef90100234cb999a50d3a972ee")
addappid(246922, 1, "e38109decec29b6820097c67df98e461802f9cb2e9e291a9156e9309fd7e7478")
addappid(246923, 1, "3cb5833709198a46543ed3bbc743196e15e1a11ba7aa2d7df2c8c0713efeada9")
