-- Lua provided by SkyAPI 
-- Game: ACIIIIIIIIIIIIIIID
addappid(1623380)
addappid(1623381, 1, "d06f7eb2e60c1eb8ddfe4573f25e9847bd8508fcc543a73da59b93e76f2a7ef9")
