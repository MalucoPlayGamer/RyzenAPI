-- Lua provided by SkyAPI 
-- Game: AppID 595550
addappid(595550)
addappid(595551, 1, "8d1472fa0212c0f02f4978b54779ab63c7aa5d2f36b6d92a94691269b307b3c5")
