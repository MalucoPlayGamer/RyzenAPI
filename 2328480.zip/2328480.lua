-- Lua provided by RyzenAPI
-- Game: Ascension

-- MAIN APPLICATION
addappid(2328480)
-- Game: addappid(2328480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328481, 1, "09c5b59ae7b6e031e179e66a22db7336d6be2108dbd016fa23b5052619ba8f15")
addappid(2328482, 1, "013f7da7c5fa0909c02485f8e2be56d004dff4ef0cb153e8304de20f7c0109d8")
