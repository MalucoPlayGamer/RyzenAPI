-- Lua provided by RyzenAPI
-- Game: AppID 359280

-- MAIN APPLICATION
addappid(359280)

-- MAIN APP DEPOTS / PACKAGES
addappid(359281, 1, "155e44e30ea691deda03ce6d412b896ac94b08a231e7fb4c4030751a713f2daf")
addappid(359282, 1, "b6464298d8ae30a0e3edb477e08fd3dec87ec579f46ddb6891cb8e9ae43833b1")
addappid(359283, 1, "ef8d5dc39ad9aa6a9a505c5525df1eae48bf18069183d21ff6281836ceec2213")

