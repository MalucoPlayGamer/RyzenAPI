-- Lua provided by RyzenAPI
-- Game: Kon's Lesson!

-- MAIN APPLICATION
addappid(2453310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453311, 1, "06b65fea2b6adaa84d546d6f47519a773ee90185ea1536c316ba2bc6438021e7")
