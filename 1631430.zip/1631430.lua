-- Lua provided by RyzenAPI
-- Game: Game: Smirkers

-- MAIN APPLICATION
addappid(1631430)
-- Game: addappid(1631430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631431, 1, "6670954b13fcd74150de95b1bb6c1c07cb2e617a0ec9486bf7666a4f01105bbd")
