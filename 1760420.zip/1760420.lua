-- Lua provided by RyzenAPI 
-- Game: ENOH
addappid(1760420)
addappid(1760421, 1, "43778084fa0193f90c2fd0f4e32b4f8aa1e0532279768d42117a98983bf6d6fb")
