-- Lua provided by RyzenAPI
-- Game: Hentai Furry - Artbook 18+

-- MAIN APPLICATION
addappid(1268850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268850,0,"a7f7a709654c084d68055306eb73dd9781a7e9789294802f9f701151de1972b4")
