-- Lua provided by RyzenAPI
-- Game: setManifestid(546962,"5425655364774651621")

-- MAIN APPLICATION
addappid(546960)
-- Game: addappid(546960)

-- MAIN APP DEPOTS / PACKAGES
addappid(546962,0,"b519001d2d1ab2192c8b1e0c7caac3e79cbb24d84249ba90451b1778d9714768")
