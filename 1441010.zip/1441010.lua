-- Lua provided by RyzenAPI
-- Game: The Pacifist's Great and Final Nightmare

-- MAIN APPLICATION
addappid(1441010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1441011, 1, "c350405f407520dc6a5fab8a031fb8e472d4c01dd5665df5ca6e0307b0e6c88f")

