-- Lua provided by RyzenAPI
-- Game: Game: The Pacifist's Great and Final Nightmare

-- MAIN APPLICATION
addappid(1441010)
-- Game: addappid(1441010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441011, 1, "c350405f407520dc6a5fab8a031fb8e472d4c01dd5665df5ca6e0307b0e6c88f")
