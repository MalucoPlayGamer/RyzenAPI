-- Lua provided by RyzenAPI
-- Game: Super Dark Deception

-- MAIN APPLICATION
addappid(2193720)
addappid(2860900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193721, 1, "46a1bf897c441b326253d098fa84f0364038a9e78ce4b1588732f7a959b7cb46")

