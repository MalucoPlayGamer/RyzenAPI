-- Lua provided by SkyAPI 
-- Game: Super Dark Deception
addappid(2193720)
addappid(2193721, 1, "46a1bf897c441b326253d098fa84f0364038a9e78ce4b1588732f7a959b7cb46")
addappid(2860900)
