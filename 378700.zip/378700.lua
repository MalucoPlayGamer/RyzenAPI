-- Lua provided by RyzenAPI
-- Game: addappid(378700)

-- MAIN APPLICATION
addappid(378700)

-- MAIN APP DEPOTS / PACKAGES
addappid(378701, 1, "5849340e2fb4cd63bc46a9986d524f621c9f2da1681e9c37c277547e21ade62b")
