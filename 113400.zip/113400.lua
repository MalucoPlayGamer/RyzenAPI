-- Lua provided by RyzenAPI
-- Game: APB Reloaded

-- MAIN APPLICATION
addappid(113400)
addappid(113402)
addappid(113403)
addappid(113405)
addappid(226490)
addappid(265060)
addappid(265061)

-- MAIN APP DEPOTS / PACKAGES
addappid(113401,0,"d6858c2ba4940054cdf81e2ac1d381f1468321c4fe7bc22dc8aac8d58148e9cc")
addappid(113409,0,"052afc6cbc7cb9ac7c56d13f5ce5f8531109ce2123fbcd4b0e8c5ede0a19692d")

