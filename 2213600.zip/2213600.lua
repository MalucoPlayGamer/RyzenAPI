-- Lua provided by SkyAPI 
-- Game: Medusa
addappid(2213600)
addappid(2213601, 1, "d8f91144c0c752d2b402a408d335f2e289e7028e4f224839c804643eebff6f31")
