-- Lua provided by RyzenAPI
-- Game: Reborn: Dragona PH

-- MAIN APPLICATION
addappid(2909370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909371, 1, "1c9d70e25d30afac5a7e6e368e16be5ab9da44c718112161755a6cf170e9301e")

