-- Lua provided by RyzenAPI 
-- Game: AppID 1491470
addappid(1491470)
addappid(1491471, 1, "f588a2260599803d8719385dcf8a45480148727c08c1a582f027f72851dc9874")
