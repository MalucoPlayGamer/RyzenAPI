-- Lua provided by RyzenAPI
-- Game: AppID 1712570

-- MAIN APPLICATION
addappid(1712570)
-- Game: addappid(1712570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712571, 1, "60e2512c270c15ebbc7a978a1b37d7057567106e60d566bdcafa768285eae2fb")
