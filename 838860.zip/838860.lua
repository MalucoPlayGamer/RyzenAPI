-- Lua provided by RyzenAPI
-- Game: Changed-OST

-- MAIN APPLICATION
addappid(838860)
-- Game: addappid(838860)

-- MAIN APP DEPOTS / PACKAGES
addappid(838862,0,"3b6c40e1728146f7f28945e8efe2a3bec33fd49b5e04250616cd8729db5752e2")
addappid(838863,0,"c704641a84040a22a04a0c9b9b4d2c86762a6b10de10b4f43382ffc53cf2f97e")
