-- Lua provided by RyzenAPI
-- Game: 1562890

-- MAIN APPLICATION
addappid(1562890)
-- Game: addappid(1562890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562891, 1, "9a9dbf56c3b8bb3cb68e4d4c4298e19b20e9b0068819608758ed75d976f85dd1")
