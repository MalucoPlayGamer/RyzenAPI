-- Lua provided by RyzenAPI
-- Game: Cave Heroes

-- MAIN APPLICATION
addappid(2631210)
addappid(2650740)
addappid(2651620)
addappid(2652470)
addappid(2652510)
addappid(2652520)
addappid(2652530)
addappid(2652540)
addappid(2652760)
addappid(2652770)
addappid(2652780)
addappid(2652790)
addappid(2652800)
addappid(3214630)
addappid(3214640)
addappid(3214650)
addappid(3214660)
addappid(3214670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631211,0,"b4a89305327cf7b2912e8bd7738215d9b619894b672acfef008dcfd3582c4e28")

