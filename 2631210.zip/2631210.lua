-- Lua provided by SkyAPI 
-- Game: Cave Heroes
addappid(2631210)
addappid(2631211, 1, "b4a89305327cf7b2912e8bd7738215d9b619894b672acfef008dcfd3582c4e28")
