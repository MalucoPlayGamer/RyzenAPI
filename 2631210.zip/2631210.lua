-- Lua provided by RyzenAPI
-- Game: addappid(2631210)

-- MAIN APPLICATION
addappid(2631210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631211, 1, "b4a89305327cf7b2912e8bd7738215d9b619894b672acfef008dcfd3582c4e28")
