-- Lua provided by RyzenAPI
-- Game: addappid(2166200)

-- MAIN APPLICATION
addappid(2166200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166201, 1, "6da97105fda512f771f2ec5813b3f0c5207df1796b20fc8283cdab0d23e3653e")
