-- Lua provided by RyzenAPI
-- Game: Trombone Champ: Unflattened

-- MAIN APPLICATION
addappid(3151670)
-- Game: addappid(3151670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151671, 1, "85557c97fe3028cb817410bf7e1aac01f0578ec78cf622a65e53061f04d0cfe4")
