-- Lua provided by RyzenAPI
-- Game: addappid(410130)

-- MAIN APPLICATION
addappid(410130)

-- MAIN APP DEPOTS / PACKAGES
addappid(410131, 1, "fcc42b9eecdc2c57f4aed4659ba714749c8f7a96fbd83f60b2fccd8a5c6d6128")
addappid(410133, 1, "91bb111a67fb70d39eec7c2f5576465a510bb8376bec98539b2fa24ae826f368")
addappid(410134, 1, "87ab923a26fac3b9008b5b042ddbbf2efe023be5b4eb8dcbd92c8efb9b1dd296")
addappid(410135, 1, "e39e11a366f5f05c26037af7d80dfbdeb9046d55e98fffbde2de8017aec8ab61")
addappid(410136, 1, "bfe60427166ec193e4b98a8473f522e4172d32d3e0a7344f290c8987b97f234b")
