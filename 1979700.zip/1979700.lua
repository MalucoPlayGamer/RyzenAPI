-- Lua provided by RyzenAPI
-- Game: Logica Emotica

-- MAIN APPLICATION
addappid(1979700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979701, 1, "086d638bbbf0d8c01eea61d3a3dbf3930b79f13becc1a87383f4f603060f3a49")

