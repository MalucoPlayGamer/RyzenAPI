-- Lua provided by RyzenAPI
-- Game: Unreal Lust Theory

-- MAIN APPLICATION
addappid(2573100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573101, 1, "55faf9612bc73e5ca55e53e175eb0ecf4a6fdbc64ccabe334445f8c10c1dfdb2")
