-- Lua provided by RyzenAPI
-- Game: Mutropolis - Artbook

-- MAIN APPLICATION
addappid(1551130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551130,0,"fd8a420d9524c5c7ef59bba9405b3f30f80224f80e9e0331427ee51fc109bf43")

