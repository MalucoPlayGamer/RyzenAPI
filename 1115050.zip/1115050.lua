-- Lua provided by RyzenAPI
-- Game: AppID 1115050

-- MAIN APPLICATION
addappid(1115050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1115051, 1, "346aaa98fc5e8195ca6603a8308ae9e5b5738cae6eb8cb6e468d945108f08899")

