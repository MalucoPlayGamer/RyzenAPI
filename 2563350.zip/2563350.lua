-- Lua provided by RyzenAPI
-- Game: addappid(2563350)

-- MAIN APPLICATION
addappid(2563350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563351, 1, "146bdd6802b87dceb9afed033b904867baf7009b123863433fd72b8a6712a5ad")
