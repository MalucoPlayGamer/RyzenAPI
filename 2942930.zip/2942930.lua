-- Lua provided by RyzenAPI
-- Game: Game: Hentai Tales: Another Fairy Tales

-- MAIN APPLICATION
addappid(2942930)
-- Game: addappid(2942930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942931, 1, "796b7a712f58b63ff75f19026d8c3dca66ac213967bcf244e5e2aae6085a6f41")
