-- Lua provided by RyzenAPI
-- Game: Hidden Office Top-Down 3D

-- MAIN APPLICATION
addappid(2137250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137251, 1, "5cbdb6e518e34554da0ab2e7faf6f76fcb2b0271af5f2101ac3a8639df684036")

