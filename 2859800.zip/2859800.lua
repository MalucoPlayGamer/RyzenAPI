-- Lua provided by RyzenAPI
-- Game: Harbinger

-- MAIN APPLICATION
addappid(2859800)
