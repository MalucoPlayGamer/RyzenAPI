-- Lua provided by SkyAPI 
-- Game: First Racer
addappid(1364690)
addappid(1364691, 1, "d6d005f41a24916cdc11d243189902616c54a7adf65ff52138b2d0c35617215f")
