-- Lua provided by RyzenAPI
-- Game: Doom & Destiny

-- MAIN APPLICATION
addappid(318130)

-- MAIN APP DEPOTS / PACKAGES
addappid(318131, 1, "0ff6fbe8dd768d0ec0a555b41f6d0016bddb9b954c18143ef0a65cfa5831d736")
addappid(318132, 1, "7239efe62b39906339340680264b4906a09f962fae431752e74c719bfbe5d22f")
addappid(318133, 1, "8fe734517bef11c2fbfa8871193bef8cba872f05e15cc8582f9f8d2cb609943b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
