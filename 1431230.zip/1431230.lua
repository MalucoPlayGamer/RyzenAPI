-- Lua provided by RyzenAPI
-- Game: Gods of Sand

-- MAIN APPLICATION
addappid(1431230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431231, 1, "ebc3c1eb4a9809f205894131c59117cf5580b988358a55617d85b865d2b4486a")

