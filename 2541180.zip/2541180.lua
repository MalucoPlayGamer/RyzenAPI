-- Lua provided by RyzenAPI 
-- Game: G-MODEアーカイブス+ 魔神転生 blind thinker
addappid(2541180)
addappid(2541181, 1, "cbd734c03bdc620e9d939d6d2c167443a8084f3468c8a8201f3250153c8f35bf")
