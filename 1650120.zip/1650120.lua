-- Lua provided by RyzenAPI
-- Game: addappid(1650120)

-- MAIN APPLICATION
addappid(1650120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650120,0,"a7502794ebc79426b13f99ad32cfc1eecedf56a9a3b25082a9e245eb52130f6c")
