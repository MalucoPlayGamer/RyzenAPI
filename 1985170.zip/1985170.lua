-- Lua provided by RyzenAPI
-- Game: Game: Warhammer 40,000: Warpforge

-- MAIN APPLICATION
addappid(1985170)
-- Game: addappid(1985170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985171, 1, "bf9c88dd8eaed9fee6529f71c7b823f921af2bbb78a3294b32b684dff3be59fd")
addappid(1985172, 1, "69b09e52d4beb8b1a3b9473bd63cda34d661a692f2d7a6cee2f481ce14e99fd2")
