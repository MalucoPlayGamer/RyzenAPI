-- Lua provided by RyzenAPI
-- Game: 2973500

-- MAIN APPLICATION
addappid(2973500)
-- Game: addappid(2973500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973501, 1, "bd4257b868b65b6a4f8920cfb1df1c6af0ac26a8647e8928b631ab992d371819")
