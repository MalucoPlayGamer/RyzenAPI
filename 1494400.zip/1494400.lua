-- Lua provided by RyzenAPI
-- Game: VR JAPAN

-- MAIN APPLICATION
addappid(1494400)
-- Game: addappid(1494400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494401, 1, "d234fe70e9e0948adc0de9d801d26ad83a3c95ea2feb3c2597d2121a38a2093a")
