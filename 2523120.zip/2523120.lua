-- Lua provided by RyzenAPI
-- Game: addappid(2523120)

-- MAIN APPLICATION
addappid(2523120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523121, 1, "b7d53dbfdeee18c7494c9844894decb6213e76a5017848a53316d3dacb63dd19")
