-- Lua provided by RyzenAPI
-- Game: AppID 338340

-- MAIN APPLICATION
addappid(338340)

-- MAIN APP DEPOTS / PACKAGES
addappid(338341, 1, "09fcc236c816891186cda2bf81feab4ab4d524ffc31446a2fe9b23a98446cb10")

