-- Lua provided by RyzenAPI
-- Game: addappid(3011020)

-- MAIN APPLICATION
addappid(3011020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011021, 1, "3328538be6b9ce98c1ea16559db904e9665226dce38b2ff010f382be6517fa91")
