-- Lua provided by RyzenAPI
-- Game: snatch&swallow

-- MAIN APPLICATION
addappid(2981210)
-- Game: addappid(2981210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981211, 1, "35c3175da1b472b6300499bd60698e98436103e99f69b63d9f380d9e819c0ac0")
