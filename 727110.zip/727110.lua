-- Lua provided by RyzenAPI
-- Game: AppID 727110

-- MAIN APPLICATION
addappid(727110)

-- MAIN APP DEPOTS / PACKAGES
addappid(727111, 1, "0051d4ab128d44c97df2edd9a079c225948e3b2d6482850d39beff3aac628fb1")
