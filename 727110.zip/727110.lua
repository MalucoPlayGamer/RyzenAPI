-- Lua provided by RyzenAPI
-- Game: AppID 727110

-- MAIN APPLICATION
addappid(727110)

-- MAIN APP DEPOTS / PACKAGES
addappid(727111, 1, "0051d4ab128d44c97df2edd9a079c225948e3b2d6482850d39beff3aac628fb1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
