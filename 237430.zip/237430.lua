-- Lua provided by RyzenAPI
-- Game: Expeditions: Conquistador

-- MAIN APPLICATION
addappid(237430)

-- MAIN APP DEPOTS / PACKAGES
addappid(237431, 1, "2dd4f1b9e4098e2399887e8878e56a4f1619783169229c3ca2873a370b0448e1")
addappid(237432, 1, "dce8d0bbe040a11a3b6d8b3efe24c4c5f6ebdaa7fcb96147c55af9ae24deca8c")
addappid(237433, 1, "e320e9aa7cfb6ae062266b2759ef5ce9aeef4c95e581a34c0dbb751f2c5c3da8")
