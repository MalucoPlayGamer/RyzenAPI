-- Lua provided by RyzenAPI
-- Game: Brigand: Panama

-- MAIN APPLICATION
addappid(709830)
-- Game: addappid(709830)

-- MAIN APP DEPOTS / PACKAGES
addappid(709830,0,"48b4880a274d6051665c6c21581f9b3d32cad4b2dc4d0b23fe2c9991df452e51")
