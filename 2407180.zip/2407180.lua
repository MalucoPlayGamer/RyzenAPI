-- Lua provided by RyzenAPI
-- Game: KAMiBAKO - Mythology of Cube - Demo

-- MAIN APPLICATION
addappid(2407180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407181, 1, "4da761642b070320a207a78b90db741eaae2b820391e9e7f1c61d7541f555097")
