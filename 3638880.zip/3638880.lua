-- Lua provided by RyzenAPI
-- Game: OddRoom Soundtrack

-- MAIN APPLICATION
addappid(3638880)
-- Game: addappid(3638880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3638881, 1, "e89e84970823bd4a2ccce7c3ca16a31648a5342312564b4e3c4f7eb854fc9900")
