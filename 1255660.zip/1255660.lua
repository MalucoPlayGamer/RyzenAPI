-- Lua provided by RyzenAPI
-- Game: Mya of the Desert

-- MAIN APPLICATION
addappid(1255660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1255661, 1, "8539a2e569dbc77a2799798ef023527423c809e7fcebe1c681c650281558baf2")

