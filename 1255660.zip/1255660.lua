-- Lua provided by RyzenAPI
-- Game: Game: AppID 1255660

-- MAIN APPLICATION
addappid(1255660)
-- Game: addappid(1255660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255661, 1, "8539a2e569dbc77a2799798ef023527423c809e7fcebe1c681c650281558baf2")
