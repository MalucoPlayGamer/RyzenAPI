-- Lua provided by RyzenAPI
-- Game: Catacombs of the Undercity

-- MAIN APPLICATION
addappid(352440)

-- MAIN APP DEPOTS / PACKAGES
addappid(352443,0,"0998a43cc8ad46b3087d6480ca8b2c8ea97cf7e03d4e48d9060e102e2ba934c4")

