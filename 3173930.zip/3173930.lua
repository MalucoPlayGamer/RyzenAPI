-- Lua provided by RyzenAPI
-- Game: Game: The Hilarious Three Kingdoms

-- MAIN APPLICATION
addappid(3173930)
-- Game: addappid(3173930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173931, 1, "002583053b80c6fcf7265aeff60686a3c5b552061ce553878ad655500889e888")
