-- Lua provided by RyzenAPI
-- Game: 1833840

-- MAIN APPLICATION
addappid(1833840)
addappid(1833940)
-- Game: addappid(1833840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833841, 1, "31b2916e902876cb823bf404cf6d165cd2044448cbc4c5a36273a6a328b7e9e2")
