-- Lua provided by RyzenAPI
-- Game: Button Tales

-- MAIN APPLICATION
addappid(545590)

-- MAIN APP DEPOTS / PACKAGES
addappid(545591, 1, "111c2d287b88adddcb903c6e058efe781b085689ad19f7329f2b5c6acbe41fee")
addappid(545592, 1, "f0e28fecc3535cad0715f3b3b22f32d126ebd4426ad6780771b9af29a093b0bf")
addappid(545593, 1, "e8e8b3fbc61a3616d2a0ba4c35223bdffb6fc7e3b3a714491ca308d99b125f92")

