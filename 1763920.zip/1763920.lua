-- Lua provided by RyzenAPI
-- Game: Impostor Factory Soundtrack

-- MAIN APPLICATION
addappid(1763920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763921, 1, "4b78b2052dc8f2948579cb0d1f62bea54bbfa04a29d7050faaa5a939a23cc71d")
