-- Lua provided by RyzenAPI
-- Game: 捕鱼竞赛

-- MAIN APPLICATION
addappid(1832540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832542,0,"5230922dd11a9f688c38fcf1ab9d34c4432affd35b90ffd22d8035ae58a66237")
addtoken(1832540,3422138460116157433)

