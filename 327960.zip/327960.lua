-- Lua provided by RyzenAPI 
-- Game: Journey of the King
addappid(327960)
addappid(327961, 1, "b1e797c33a0d4488aae7bb5e930f214dc31cc7bae987f1597853ea631e5b28f4")
