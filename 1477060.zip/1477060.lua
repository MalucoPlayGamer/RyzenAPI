-- Lua provided by RyzenAPI 
-- Game: Among Ass
addappid(1477060)
addappid(1477061, 1, "b0b7ce194617b7723c96ed969a0aacd2fa53ae60572c9ce2da017eb042d8f75a")
