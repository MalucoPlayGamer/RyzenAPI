-- Lua provided by RyzenAPI
-- Game: addappid(2626240)

-- MAIN APPLICATION
addappid(2626240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626241, 1, "03930c3a18df5b3b2f2656cc5a90e551534ecddd3a6338173c433c3114d49e26")
