-- Lua provided by RyzenAPI
-- Game: Game: Waifu App: 90 Days to Escape a Lonely Fate

-- MAIN APPLICATION
addappid(3329420)
-- Game: addappid(3329420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3329421, 1, "7e41e1035e2d893eb63df018d379377d17f8c02ece06629246e5f2a3e427ebc0")
addappid(3329422, 1, "5627ea67945fd966292aeaf6d71dd97c48651654cc0fddda16875f49e7d0637d")
addappid(3329423, 1, "beea5a12c2a11d500d1863dd9bced57f89e457421c2f9c0bd0ce5bfc96d8e855")
