-- Lua provided by RyzenAPI
-- Game: Game: AppID 977810

-- MAIN APPLICATION
addappid(977810)
-- Game: addappid(977810)

-- MAIN APP DEPOTS / PACKAGES
addappid(977811, 1, "4fecb537b7301b3088f8f4c521c86bee4b454fc29e4db02d10c3281563e2bfe5")
addappid(977813, 1, "cea1c6ff7b41365980ba6a2b554a5572d4028fa162edc0dbd3ca99ffd5a0794c")
addappid(977814, 1, "81e00d83d4111890076217fb26c86d094221dbc694bd568d8ee51f25ea2014a2")
