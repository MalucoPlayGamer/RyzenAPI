-- Lua provided by RyzenAPI
-- Game: The Sych story: Human Being

-- MAIN APPLICATION
addappid(1899010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899011, 1, "4a1e2618a076156ae6ebd29d5345c0429c968faf3f5905efd69fa850c49968ea")

