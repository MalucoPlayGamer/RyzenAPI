-- Lua provided by RyzenAPI
-- Game: 3432140

-- MAIN APPLICATION
addappid(3432140)
-- Game: addappid(3432140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432141, 1, "a6861b8e4a8bc6471b08a5e8a41d48710725f3e7dca3c75edb0feacc4c76e516")
