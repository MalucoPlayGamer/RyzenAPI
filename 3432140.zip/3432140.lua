-- Lua provided by RyzenAPI
-- Game: CRAZLIPSE

-- MAIN APPLICATION
addappid(3432140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3432141, 1, "a6861b8e4a8bc6471b08a5e8a41d48710725f3e7dca3c75edb0feacc4c76e516")

