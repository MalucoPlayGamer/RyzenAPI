-- Lua provided by RyzenAPI
-- Game: Game: Portal 2 - The Final Hours

-- MAIN APPLICATION
addappid(104600)
-- Game: addappid(104600)

-- MAIN APP DEPOTS / PACKAGES
addappid(104601, 1, "27e0356a12664db82529708e8c064219f04a81d36a2293d44c6e9694684c1aaa")
addappid(104602, 1, "1b0d355c0d41921980b4694b93ecd8a8c20cffc7c3a2a137b96b84b545c052ca")
