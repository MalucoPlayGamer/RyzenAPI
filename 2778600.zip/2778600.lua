-- Lua provided by RyzenAPI
-- Game: 2778600

-- MAIN APPLICATION
addappid(2778600)
-- Game: addappid(2778600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778601, 1, "25da56a5384b3d0e9895ab0f437ed0a3fefddde8b4f313c28be76d61bdadbc6b")
