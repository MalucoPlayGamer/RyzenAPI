-- Lua provided by RyzenAPI
-- Game: Kalaban - Original Soundtrack

-- MAIN APPLICATION
addappid(629710)

-- MAIN APP DEPOTS / PACKAGES
addappid(629711, 1, "c784df7dd9d1b2eed0f49bc269784d9a48032986f20a880bf81d7d5488b0420b")
