-- Lua provided by RyzenAPI
-- Game: 531860

-- MAIN APPLICATION
addappid(531860)
-- Game: addappid(531860)

-- MAIN APP DEPOTS / PACKAGES
addappid(531861, 1, "0f5770603fb7097a667c67388238ef708808df6cf6877e5fac1812e2ba066c8b")
