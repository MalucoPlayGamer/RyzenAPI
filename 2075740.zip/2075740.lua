-- Lua provided by RyzenAPI
-- Game: Rhythm Quest Demo

-- MAIN APPLICATION
addappid(2075740)
-- Game: addappid(2075740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075741, 1, "4cebc6a03a808185ddbe7931466997d29b45bdd7540549a8923a55a57987d046")
