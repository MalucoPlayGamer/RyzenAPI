-- Lua provided by RyzenAPI
-- Game: Dawn City

-- MAIN APPLICATION
addappid(768110)

-- MAIN APP DEPOTS / PACKAGES
addappid(768111,0,"929722f91ef5407c0e0abd416ed04763de8e1840d88e430fca99d2b30c2ec4e8")

