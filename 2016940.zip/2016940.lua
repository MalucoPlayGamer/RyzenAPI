-- Lua provided by RyzenAPI
-- Game: O2Jam Online

-- MAIN APPLICATION
addappid(2016940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016941, 1, "4a32a69badea9573cbc4c004c438eb88abf0efcbc1b19fca4777fd563fe330c2")
