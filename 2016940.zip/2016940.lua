-- Lua provided by RyzenAPI
-- Game: O2Jam Online

-- MAIN APPLICATION
addappid(2016940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016941, 1, "4a32a69badea9573cbc4c004c438eb88abf0efcbc1b19fca4777fd563fe330c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
