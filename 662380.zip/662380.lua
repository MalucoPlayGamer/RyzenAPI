-- Lua provided by RyzenAPI 
-- Game: Project X
addappid(662380)
addappid(662381, 1, "9e380437a0cd50d31e225311eb52ba017a84cb4a47e4ef1535d390d6a6cd3447")
