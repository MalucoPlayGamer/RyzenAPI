-- Lua provided by RyzenAPI
-- Game: Sable

-- MAIN APPLICATION
addappid(757310)

-- MAIN APP DEPOTS / PACKAGES
addappid(757311, 1, "a6c014ff9375e39f5bff97ef45bce9d11ec4a288c85ccd82c8200b77ecdd9d5c")
