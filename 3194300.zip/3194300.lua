-- Lua provided by RyzenAPI
-- Game: StrangePool

-- MAIN APPLICATION
addappid(3194300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3194301, 1, "1a428fa17d44bffe2317150145f3e2d9889489e350b4064276e1d88c1229ae8c")
