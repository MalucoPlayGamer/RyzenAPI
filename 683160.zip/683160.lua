-- Lua provided by SkyAPI 
-- Game: AppID 683160
addappid(683160)
addappid(683161, 1, "100c37ca79d05b35478055017e4e29839b34c87d28f93191c87f5bc9f1a7621a")
