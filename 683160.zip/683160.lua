-- Lua provided by RyzenAPI
-- Game: The Exorcist

-- MAIN APPLICATION
addappid(683160)

-- MAIN APP DEPOTS / PACKAGES
addappid(683161, 1, "100c37ca79d05b35478055017e4e29839b34c87d28f93191c87f5bc9f1a7621a")

