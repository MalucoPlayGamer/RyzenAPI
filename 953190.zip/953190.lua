-- Lua provided by RyzenAPI
-- Game: Game: Dream Walker

-- MAIN APPLICATION
addappid(953190)
-- Game: addappid(953190)

-- MAIN APP DEPOTS / PACKAGES
addappid(953191, 1, "31d5a1f5a330aebcc1133eb6f594398e793c5597b89ecf29f065f883c851bf0a")
