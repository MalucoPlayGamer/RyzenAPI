-- Lua provided by RyzenAPI
-- Game: European Air War

-- MAIN APPLICATION
addappid(514130)

-- MAIN APP DEPOTS / PACKAGES
addappid(514131, 1, "03256fc04f3ff539c514a3b23b7973b355a7b20504f362f49a4525276bf7a221")
