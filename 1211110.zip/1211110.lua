-- Lua provided by RyzenAPI
-- Game: Petal Crash

-- MAIN APPLICATION
addappid(1211110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211113,0,"5241e1fe2422adb8fc8b5b9584bbee5de6fe7f85e8b585e699a39a844239cec8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
