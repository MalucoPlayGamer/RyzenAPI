-- Lua provided by RyzenAPI
-- Game: addappid(1211110)

-- MAIN APPLICATION
addappid(1211110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211113,0,"5241e1fe2422adb8fc8b5b9584bbee5de6fe7f85e8b585e699a39a844239cec8")
