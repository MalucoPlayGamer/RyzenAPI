-- Lua provided by RyzenAPI
-- Game: setManifestid(1211113,"9160645676574685644")

-- MAIN APPLICATION
addappid(1211110)
-- Game: addappid(1211110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211113,0,"5241e1fe2422adb8fc8b5b9584bbee5de6fe7f85e8b585e699a39a844239cec8")
