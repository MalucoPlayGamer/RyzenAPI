-- Lua provided by RyzenAPI
-- Game: Game: Virus Hunter - Adult Only

-- MAIN APPLICATION
addappid(3002000)
-- Game: addappid(3002000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002001, 1, "fc3f158863e8ea3ec6f94386873c6c2e433e28e9f455223e2d1ec9fb14fbac3d")
