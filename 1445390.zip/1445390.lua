-- Lua provided by RyzenAPI
-- Game: Evergate Soundtrack

-- MAIN APPLICATION
addappid(1445390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445391, 1, "c8087c46597228c2eefa2bf831becfcd17c0c4fba0e9881d9233a139b16176e9")
addappid(1445392, 1, "f53eed71a18a00b9d77f5dbbd698b69f65c66918321a9d9645482f7c8c60606c")
