-- Lua provided by RyzenAPI
-- Game: 2793390

-- MAIN APPLICATION
addappid(2793390)
-- Game: addappid(2793390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793391, 1, "3b3a92c1187fb9c2703e7d027605d24bcadedede783ac3cdd7b24d6b2f060228")
