-- Lua provided by RyzenAPI
-- Game: Game: Run or Die

-- MAIN APPLICATION
addappid(2548650)
-- Game: addappid(2548650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548651, 1, "3f030b52ae91f1974ed6d22e7f29ba5cd075928c52451e2951815a08125364f7")
