-- Lua provided by RyzenAPI
-- Game: Run or Die

-- MAIN APPLICATION
addappid(2548650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548651, 1, "3f030b52ae91f1974ed6d22e7f29ba5cd075928c52451e2951815a08125364f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4762900)
addappid(4762910)
