-- Lua provided by RyzenAPI
-- Game: Morbid: The Lords of Ire

-- MAIN APPLICATION
addappid(2171560)
addappid(2968360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2171561, 1, "d86ddaea5c3e366d493504d0114ee6a6868dca98fefb0e2566b27b435bd643e1")

