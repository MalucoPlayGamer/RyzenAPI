-- Lua provided by RyzenAPI
-- Game: addappid(2171560)

-- MAIN APPLICATION
addappid(2171560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171561, 1, "d86ddaea5c3e366d493504d0114ee6a6868dca98fefb0e2566b27b435bd643e1")
