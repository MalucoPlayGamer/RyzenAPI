-- Lua provided by RyzenAPI
-- Game: 870080

-- MAIN APPLICATION
addappid(870080)
-- Game: addappid(870080)

-- MAIN APP DEPOTS / PACKAGES
addappid(870081, 1, "7ef0be26d42c46d4218a86f411931ec2ab4e5267925c41eeedd137dc7b2101a4")
