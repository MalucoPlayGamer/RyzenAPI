-- Lua provided by RyzenAPI
-- Game: PowerWash Simulator 2

-- MAIN APPLICATION
addappid(2968420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968422,0,"2c13dcc1b498282fe021b2cd49229d7309ace370d9e990cd3ad843397cf247c9")
addappid(4173830,0,"09117944c3966ed77061eb5f134fb9985cc1b2de5c9d48ac629139c66c1659b9")
addappid(4229450,0,"16aa57f7dc9215729cb0f06b7ff0a79b2af2fa0f0ec0bdfc0dad2ca3f14ea84c")

