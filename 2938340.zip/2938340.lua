-- Lua provided by RyzenAPI
-- Game: Really Simple Golf Demo

-- MAIN APPLICATION
addappid(2938340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938342,0,"32ab7cce7109c109d42dca3420de0736e957b9ec5e87bbc3d2610a2abe4557b8")

