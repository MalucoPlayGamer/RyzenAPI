-- Lua provided by RyzenAPI
-- Game: Mount and Blade Demo

-- MAIN APPLICATION
addappid(22110)

-- MAIN APP DEPOTS / PACKAGES
addappid(22111, 1, "0e405b422140bbdd4ffbc8cd2d24b506fa44676e74e3bae3fe20e4ee253f1dc2")
