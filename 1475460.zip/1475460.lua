-- Lua provided by RyzenAPI
-- Game: 3 Minute Heroes

-- MAIN APPLICATION
addappid(1475460)
addappid(1806140)
addappid(1806141)
addappid(1806143)
addappid(1806144)
addappid(1806145)
addappid(1806146)
addappid(1806147)
addappid(1806148)
addappid(1806149)
addappid(1806150)
addappid(1806151)
addappid(1806152)
addappid(1806153)
addappid(1806154)
addappid(1806155)
addappid(1806156)
addappid(1806157)
addappid(1806158)
addappid(1806159)
addappid(1806170)
addappid(1851290)
addappid(1886800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475461,0,"8d949a3e118e5799cd5c04565b01517af6b28d891e121a61caf3ceb56289b191")

