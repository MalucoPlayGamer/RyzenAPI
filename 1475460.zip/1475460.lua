-- Lua provided by RyzenAPI
-- Game: 3 Minute Heroes

-- MAIN APPLICATION
addappid(1475460)
-- Game: addappid(1475460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475461, 1, "8d949a3e118e5799cd5c04565b01517af6b28d891e121a61caf3ceb56289b191")
