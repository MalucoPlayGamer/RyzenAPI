-- Lua provided by RyzenAPI
-- Game: AppID 717990

-- MAIN APPLICATION
addappid(717990)

-- MAIN APP DEPOTS / PACKAGES
addappid(717991, 1, "b68a58ab639aeffaa4da09617b8611523091e24571678a57c754729e126f629d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
