-- Lua provided by RyzenAPI
-- Game: Game: AppID 717990

-- MAIN APPLICATION
addappid(717990)
-- Game: addappid(717990)

-- MAIN APP DEPOTS / PACKAGES
addappid(717991, 1, "b68a58ab639aeffaa4da09617b8611523091e24571678a57c754729e126f629d")
