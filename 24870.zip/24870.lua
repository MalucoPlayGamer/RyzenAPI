-- Lua provided by RyzenAPI
-- Game: Need for Speed: Shift

-- MAIN APPLICATION
addappid(24870)
-- Game: addappid(24870)

-- MAIN APP DEPOTS / PACKAGES
addappid(24871, 1, "d21bf6a450007944762201c63d2596658316d3daad66ca4b39269462dda788ff")
