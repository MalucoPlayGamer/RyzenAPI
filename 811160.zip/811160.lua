-- Lua provided by RyzenAPI
-- Game: Game of Stones

-- MAIN APPLICATION
addappid(811160)

-- MAIN APP DEPOTS / PACKAGES
addappid(811161,0,"72d844fbed905dd05373096cab67e5160e184dba9f5924639d64d665d0079a78")

