-- Lua provided by RyzenAPI
-- Game: Game: Warhammer Age of Sigmar: Soul Arena

-- MAIN APPLICATION
addappid(1606130)
-- Game: addappid(1606130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606131, 1, "58beb7bfd934f149e4a657fa47c0f271e0f52a2f82de5df88217f9184a435f94")
