-- Lua provided by RyzenAPI
-- Game: Follow the Leader

-- MAIN APPLICATION
addappid(2573960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573961, 1, "ea3a4c84590ae4291e5ab22022385f19ef54a5a057c1ffb30d85eaa8e2009ba4")

