-- Lua provided by RyzenAPI
-- Game: addappid(545370)

-- MAIN APPLICATION
addappid(545370)

-- MAIN APP DEPOTS / PACKAGES
addappid(545371, 1, "bc9c41118f242c2aada8574e25689e22646a4c78cabedb685d90c33753551236")
