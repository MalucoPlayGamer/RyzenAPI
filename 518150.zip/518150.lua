-- Lua provided by RyzenAPI
-- Game: Intruder

-- MAIN APPLICATION
addappid(518150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(518151, 1, "952413bc4e9cd3732dc1d76afa9cb5036685cf34af3ff9d55e281b2566ce999a")
addappid(518153, 1, "2ed850e7cc8b07415d7a61ec0298fbe0b5efaf01883c715b0097edfe16d860e3")

