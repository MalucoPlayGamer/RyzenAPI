-- Lua provided by RyzenAPI
-- Game: Retail Mage

-- MAIN APPLICATION
addappid(3224380)
addappid(3287370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3224381, 1, "3731355f19dab93bb80a2c5c901133737c9e701903af96693fbc3ccccf22a9f3")

