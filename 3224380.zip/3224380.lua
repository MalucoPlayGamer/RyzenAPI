-- Lua provided by RyzenAPI
-- Game: 3224380

-- MAIN APPLICATION
addappid(3224380)
-- Game: addappid(3224380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224381, 1, "3731355f19dab93bb80a2c5c901133737c9e701903af96693fbc3ccccf22a9f3")
