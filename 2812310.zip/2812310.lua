-- Lua provided by RyzenAPI
-- Game: Game: AppID 2812310

-- MAIN APPLICATION
addappid(2812310)
-- Game: addappid(2812310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812311, 1, "36342c39cc10d2696c74ba0de93893aa3bf697ba60f667b4a54650b84e1a4106")
