-- Lua provided by RyzenAPI
-- Game: AppID 283290

-- MAIN APPLICATION
addappid(283290)

-- MAIN APP DEPOTS / PACKAGES
addappid(283291, 1, "10bbee3dcd8ed6ee9638fe8c4c62ff58563852224b0e6f586df4038b4b88b52e")

