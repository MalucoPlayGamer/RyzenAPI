-- Lua provided by RyzenAPI
-- Game: AppID 510640

-- MAIN APPLICATION
addappid(510640)

-- MAIN APP DEPOTS / PACKAGES
addappid(510641, 1, "0354cc26d472ae268a913c57d9f16dd8cbde9f99ee22bb9f7c66f0fbb69f5c00")

