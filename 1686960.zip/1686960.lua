-- Lua provided by RyzenAPI
-- Game: Furry Puzzle

-- MAIN APPLICATION
addappid(1686960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686961, 1, "00ed6fddf44fad742db57fefbfe9abad5c1abfa3b4ee1fdfbd0a7d439314acba")

