-- Lua provided by RyzenAPI
-- Game: Desk Paws

-- MAIN APPLICATION
addappid(3586060)
-- Game: addappid(3586060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586064,0,"f91671e24cec92bdacf318179d93d9019d4647a7162166df12181208a1ae7e2e")
