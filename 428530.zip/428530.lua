-- Lua provided by RyzenAPI
-- Game: 428530

-- MAIN APPLICATION
addappid(428530)
-- Game: addappid(428530)

-- MAIN APP DEPOTS / PACKAGES
addappid(428531, 1, "e6a268c8dfbfa388e291920505d7613723644e41ae6245344da166e974620def")
