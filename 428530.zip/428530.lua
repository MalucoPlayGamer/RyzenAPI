-- Lua provided by SkyAPI 
-- Game: Machine Gun Train Run
addappid(428530)
addappid(428531, 1, "e6a268c8dfbfa388e291920505d7613723644e41ae6245344da166e974620def")
