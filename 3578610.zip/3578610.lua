-- Lua provided by RyzenAPI
-- Game: 3578610

-- MAIN APPLICATION
addappid(3578610)
-- Game: addappid(3578610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578611, 1, "15ca1fb143be0655f4b3e1aaf6de4af579742bf22269412daf633e805b1278e7")
