-- Lua provided by SkyAPI 
-- Game: AppID 3078910
addappid(3078910)
addappid(3078911, 1, "edad14e6683b772cdd970e2da702cafe50c4df9d85e379b2d692b97c02a61b79")
addappid(3109680, 0, "95017fb8de598f979f28d56585c2d2869ec225c757bbc3d996c780b78e8112c4")
