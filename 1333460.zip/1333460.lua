-- Lua provided by RyzenAPI
-- Game: Nino Maze LOFI

-- MAIN APPLICATION
addappid(1333460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333461, 1, "50a72c636c1f6d33f50078097152fc0345414bdf16b24bde56ccb74037de113a")

