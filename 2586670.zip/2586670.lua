-- Lua provided by RyzenAPI
-- Game: Evil Snowmen 2

-- MAIN APPLICATION
addappid(2586670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586671, 1, "7e093ac10df73312de7ca82c1280779a7b6550c6754adf2e9403d1648b17dfc3")
