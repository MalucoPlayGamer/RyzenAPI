-- Lua provided by RyzenAPI 
-- Game: PataNoir
addappid(449150)
addappid(449151, 1, "ae9a80354b3826927f2d1172c9f1a82e5c2b6ca7028f3e7b0db218f303ca647b")
