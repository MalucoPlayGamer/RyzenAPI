-- Lua provided by RyzenAPI
-- Game: PataNoir

-- MAIN APPLICATION
addappid(449150)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(449151, 1, "ae9a80354b3826927f2d1172c9f1a82e5c2b6ca7028f3e7b0db218f303ca647b")

