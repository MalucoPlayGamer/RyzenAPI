-- Lua provided by RyzenAPI
-- Game: Hot Heat Reset: Chapter 1

-- MAIN APPLICATION
addappid(2307370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307371, 1, "6dac81c328408fd8af5f759e5c0d79b2c9f54cfff72480329656d8a4c4ad1beb")

