-- Lua provided by RyzenAPI
-- Game: Spy Alliance

-- MAIN APPLICATION
addappid(2757350)
addappid(2757353)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757352,0,"38e244dc1688dc67ceadea8615918fc6c4600455a45c1b9954eabff2e43395c5")

