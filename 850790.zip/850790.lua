-- Lua provided by RyzenAPI
-- Game: Game: AppID 850790

-- MAIN APPLICATION
addappid(850790)
-- Game: addappid(850790)

-- MAIN APP DEPOTS / PACKAGES
addappid(850791, 1, "013862d499a7cbcdbf2ecfb201898f5429c5bb1772ba8f03aab11b6fd9606812")
addappid(850792, 1, "d14699436438021c5ce1f3c24ceca4eacc33b076c99b759a82ab9e25cd2725f9")
addappid(850793, 1, "7ed74d627eb395917b61daddda6685371ad95656fceeceeddad90afb6cca7513")
addappid(850794, 1, "008846d33a89dd99f4b6f89991fc9dba62534b28042bd116e0cab09d413f5487")
addappid(850795, 1, "3ba716628e3dfc6533ce00ba6af7239eac9fbc29123478f7c1b072897849ad7c")
