-- Lua provided by RyzenAPI
-- Game: addappid(965820)

-- MAIN APPLICATION
addappid(965820)
addappid(1121740)

-- MAIN APP DEPOTS / PACKAGES
addappid(965821, 1, "2b4ee1a93aaacb175738e8c12d97bac8b3067f97136ef17026e45150cc5220db")
