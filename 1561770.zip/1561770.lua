-- Lua provided by RyzenAPI
-- Game: 1561770

-- MAIN APPLICATION
addappid(1561770)
addappid(1612440)
addappid(1612442)
addappid(1612443)
addappid(1612444)
addappid(1612445)
addappid(1612446)
addappid(1612447)
addappid(1612448)
-- Game: addappid(1561770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561771, 1, "783a95d3c6c5fd182b64f6071920c1eec34858474225821ae3ed827ae1aaf404")
addappid(1561773, 1, "5e07d1336fcd2ad41e18eb076ba5ff0005096d012e6255d0a810d730036144b0")
addappid(1561777, 1, "8a68d455c2d9db5e90d45e84e0cfab03aaf79433c836421a905b44813ab21542")
addappid(1561778, 1, "905f6cf945da8b3ff2fd9fdbf044f8c5a7989a01dad81f4f6d5fbf012aa402d9")
addappid(1612441, 0, "f428ef3ef217c198a242c6987ec7101a3852b586f75e13c1e412dac9d2d41bee")
