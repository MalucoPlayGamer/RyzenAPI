-- Lua provided by RyzenAPI
-- Game: 1331620

-- MAIN APPLICATION
addappid(1331620)
-- Game: addappid(1331620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331624,0,"0ec2c4cfaa61834e565162917955c82b926e66be950d44707755fe1affe09e4f")
