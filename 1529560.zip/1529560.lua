-- Lua provided by RyzenAPI
-- Game: Knight Squad 2 Trials

-- MAIN APPLICATION
addappid(1529560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529561, 1, "13618ff07af9e11b66e02c4cb5e5dd089e213b765bb16a32d5b149372f1d1a0c")

