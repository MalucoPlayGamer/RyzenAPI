-- Lua provided by RyzenAPI
-- Game: addappid(2307950)

-- MAIN APPLICATION
addappid(2307950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307951, 1, "d81c92320d18daa3759b243f0840767caffe8e22563e7b549c4d1d0af86c1696")
