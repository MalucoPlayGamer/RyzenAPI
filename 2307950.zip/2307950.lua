-- Lua provided by SkyAPI 
-- Game: Zombie Survivals [18+]🧟‍♀️🔞
addappid(2307950)
addappid(2307951, 1, "d81c92320d18daa3759b243f0840767caffe8e22563e7b549c4d1d0af86c1696")
