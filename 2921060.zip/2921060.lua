-- Lua provided by RyzenAPI 
-- Game: Circus Challenge
addappid(2921060)
addappid(2921061, 1, "73b77e9da4b24ad9f839a90c5ab1e0e7fc055de667080355381d3de1b217ad21")
