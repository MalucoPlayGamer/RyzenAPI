-- Lua provided by RyzenAPI
-- Game: Game: Rurizakura

-- MAIN APPLICATION
addappid(1562470)
-- Game: addappid(1562470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562471, 1, "407c27ef28d3e4aa594fce438363bd46724ec1a7bf3242111aa47998ebe5927b")
