-- Lua provided by SkyAPI 
-- Game: Rurizakura
addappid(1562470)
addappid(1562471, 1, "407c27ef28d3e4aa594fce438363bd46724ec1a7bf3242111aa47998ebe5927b")
