-- Lua provided by RyzenAPI
-- Game: Merger 3D

-- MAIN APPLICATION
addappid(527750)
-- Game: addappid(527750)

-- MAIN APP DEPOTS / PACKAGES
addappid(527751, 1, "7c1b88343df8a09243e1a5f417e09f27e3143eaedd01067b96537133d175736d")
