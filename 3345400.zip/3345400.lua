-- Lua provided by RyzenAPI
-- Game: EDENS ZERO - Starter Item pack

-- MAIN APPLICATION
addappid(3345400)
-- Game: addappid(3345400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345400,0,"f5e90e13a7c91cfe19599118d404e9387ddfcfa8973453879a081cfb893887bb")
