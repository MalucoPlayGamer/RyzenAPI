-- Lua provided by RyzenAPI
-- Game: AppID 2581080

-- MAIN APPLICATION
addappid(2581080)
-- Game: addappid(2581080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581081, 1, "05ed43f8dcaa1942352615a46e529860fb5527bdddc6639d33188c7d7cf6075f")
