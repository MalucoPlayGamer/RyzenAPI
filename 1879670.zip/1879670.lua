-- Lua provided by RyzenAPI
-- Game: Futa Spell

-- MAIN APPLICATION
addappid(1879670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879671, 1, "be7b019a73558db5336ba23fae7825ffc980c10f7a7a9733f932f7733095d7bb")
