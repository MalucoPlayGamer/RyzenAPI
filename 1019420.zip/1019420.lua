-- Lua provided by RyzenAPI
-- Game: addappid(1019420)

-- MAIN APPLICATION
addappid(1019420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019421, 1, "7732892357924565c6b09283b0b4cb3eaa128a8a42bcf043fc70c6cf4d7cda3e")
