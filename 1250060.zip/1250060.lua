-- Lua provided by RyzenAPI
-- Game: 法利恩戰記（Furion Chronicles）

-- MAIN APPLICATION
addappid(1250060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250061, 1, "6ce2a612110584f42d723e2299b2b21cddae649ae1d75966851d894dace548cd")
