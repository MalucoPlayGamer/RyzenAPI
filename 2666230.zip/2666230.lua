-- Lua provided by RyzenAPI
-- Game: Dog And Goblin

-- MAIN APPLICATION
addappid(2666230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666231, 1, "f03c744fb52d86e8608d69a82ee4a1d00e7df88582fccd30752be00423ca5f95")
