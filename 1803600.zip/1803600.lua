-- Lua provided by RyzenAPI
-- Game: Game: Gone Rogue

-- MAIN APPLICATION
addappid(1803600)
-- Game: addappid(1803600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803601, 1, "fd56d425cad20c0a3a0a0a11590a52b9cf9898c942d6d94a5718c76e8ea5bfeb")
