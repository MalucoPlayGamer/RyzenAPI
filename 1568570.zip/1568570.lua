-- Lua provided by RyzenAPI
-- Game: Retro Tank Party

-- MAIN APPLICATION
addappid(1568570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568571, 1, "d0e61a51756fd2242f4a27f221f0c863deca79797989593fbbb33679dff881b0")
