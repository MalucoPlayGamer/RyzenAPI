-- Lua provided by RyzenAPI
-- Game: 1256440

-- MAIN APPLICATION
addappid(1256440)
-- Game: addappid(1256440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256441, 1, "639a44372e7fddcda5c2730980cb00a03f3d0c876bbb5103bc5031abe300c0ca")
