-- Lua provided by RyzenAPI
-- Game: Andromeda Wing

-- MAIN APPLICATION
addappid(691750)
-- Game: addappid(691750)

-- MAIN APP DEPOTS / PACKAGES
addappid(691751, 1, "3c5bcd637cbaf78816673fde97ffd615441343c80f525d530b0eee3866aa6262")
