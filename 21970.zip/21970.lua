-- Lua provided by RyzenAPI
-- Game: AppID 21970

-- MAIN APPLICATION
addappid(21970)

-- MAIN APP DEPOTS / PACKAGES
addappid(21971, 1, "e704dbef4f4282016b56efda28a5b9defecd3c92b4693419452e48342779da66")
addappid(21972, 1, "ee735b0ecf542d1fc838ad6d5bd4c961b78e0e5012a86fb7e8091ceef0146585")
addappid(21973, 1, "3aef726bd54bf84de604150f3fe3514b3bddd547e1c452b958b91f2b80eede98")
addappid(21974, 1, "870ff31e93239282a1f2ca1976c6d73b27b4624682e3f744a6a186df90439826")
addappid(21975, 1, "518629e5962326ec80f07329a7676cd08f6183ae0a188890c8f374c31e2026c6")
addappid(21976, 1, "59055e7fa9346e9cd1f33df0377fdddd34ae8ef26cd0071bcca67b556d0e8689")
addappid(21977, 1, "0cc975fcfc857ba6b9c6aafefbc7508d35b26a93ff5036f8923ab69f4cff48cb")
addappid(21978, 1, "f57edcbcb968e9eb1f0c1dd62b547eb5d9a2d7444fea92087840fc8d86830d71")
addappid(21979, 1, "dd9cc83fdae46f0073ea9325a330bd8802d1f4f17ac00856cd9cfb09fad93f90")
addappid(21995, 0, "53aa6bccae73a0277e964309643e1fd3a33f05c9b6a39df0ed35d43effa80cd2")
addappid(21996, 0, "6e52e24afa5dfcfe1a5139433c950e457139f5fe2bf954e7c538329976e15768")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(21963)
addappid(21964)
addappid(21999)
