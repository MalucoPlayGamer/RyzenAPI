-- Lua provided by RyzenAPI
-- Game: addappid(3282510)

-- MAIN APPLICATION
addappid(3282510)
addappid(3351580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3282511, 1, "432b0bcbbb1e83634d3d077b25540bcf99a3c9f4ec122aafc0f753378d29e37e")
