-- Lua provided by RyzenAPI
-- Game: BOMB: Who let the dogfight?

-- MAIN APPLICATION
addappid(301500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(301501, 1, "8ab24d16826ff2e9055f634e94cc64417ec5a927fae8da0268eae57da6704e8e")
addappid(301502, 1, "3e49ac085b16227d9b8745335252662f4d74b99eaab3d6c536fc81a4506b1219")

