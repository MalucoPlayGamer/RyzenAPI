-- Lua provided by RyzenAPI
-- Game: Andro Dunos II

-- MAIN APPLICATION
addappid(1856900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856901, 1, "98dad6228e688bcaa4d9fbc1c89a814548cf6fbd0abf0e05fe1c886d2739f1fc")

