-- Lua provided by RyzenAPI 
-- Game: The fall of gods
addappid(424170)
addappid(424171, 1, "55ca4b30f7b1c3d342e202fefb1568fdb75ed78cbd5386f67e9d09e5c3ec2de5")
