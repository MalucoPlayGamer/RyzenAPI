-- Lua provided by RyzenAPI
-- Game: The fall of gods

-- MAIN APPLICATION
addappid(424170)

-- MAIN APP DEPOTS / PACKAGES
addappid(424171, 1, "55ca4b30f7b1c3d342e202fefb1568fdb75ed78cbd5386f67e9d09e5c3ec2de5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
