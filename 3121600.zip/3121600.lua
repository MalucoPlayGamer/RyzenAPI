-- Lua provided by RyzenAPI
-- Game: Habilis

-- MAIN APPLICATION
addappid(3121600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3121601, 1, "cd1720fffa4a08d8764acc2b9eba27be3d16155be54379c48e50738dc3aa0870")
