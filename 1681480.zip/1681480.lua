-- Lua provided by RyzenAPI
-- Game: The Repairing Mantis

-- MAIN APPLICATION
addappid(1681480)
-- Game: addappid(1681480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681481, 1, "9d36077ca95f083a0e62ff71d9312a0d608b682c14709171749632a7016adeb8")
