-- Lua provided by RyzenAPI 
-- Game: AppID 767800
addappid(767800)
addappid(767801, 1, "98cf2427a3d18b7d6c2a042e08bb4bb357adf1c44402657a73270425b442985c")
