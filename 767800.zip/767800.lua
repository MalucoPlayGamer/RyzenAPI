-- Lua provided by RyzenAPI
-- Game: Struggle For Talyria

-- MAIN APPLICATION
addappid(767800)

-- MAIN APP DEPOTS / PACKAGES
addappid(767801, 1, "98cf2427a3d18b7d6c2a042e08bb4bb357adf1c44402657a73270425b442985c")

