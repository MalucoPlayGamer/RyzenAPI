-- Lua provided by RyzenAPI
-- Game: Star Conflict

-- MAIN APPLICATION
addappid(212070)
-- Game: addappid(212070)

-- MAIN APP DEPOTS / PACKAGES
addappid(212071, 1, "a12339bf444ae5b9d8c8729916e0e46dadea74ea247d3e4704fb805ecd1d8566")
addappid(212072, 1, "eead884c957e739aba8e12d6cb4ad62a5006ae9ee047a949c52d092663f5159d")
addappid(212073, 1, "8f4731c25f5f69a5ebf89300bed5a578cbf52131e05ea16e4d137cc68823378a")
addappid(212074, 1, "6bbe63a059e567ded4c6488b59f70d15a45812884dfa6a76357c76aeee669673")
