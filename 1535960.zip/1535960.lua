-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker Series Osyaberi! Horijyo! Holin Slash

-- MAIN APPLICATION
addappid(1535960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1535961, 1, "bc797e4797a40f98a00fb03eb229864ac80d0b8091aae56d0ad249bdaa7579eb")

