-- Lua provided by RyzenAPI
-- Game: AppID 1535960

-- MAIN APPLICATION
addappid(1535960)
-- Game: addappid(1535960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535961, 1, "bc797e4797a40f98a00fb03eb229864ac80d0b8091aae56d0ad249bdaa7579eb")
