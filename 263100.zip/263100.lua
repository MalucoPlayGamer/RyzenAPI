-- Lua provided by RyzenAPI
-- Game: 263100

-- MAIN APPLICATION
addappid(228983)
addappid(228990)
addappid(229000)
addappid(229002)
addappid(229003)
addappid(263100)

-- MAIN APP DEPOTS / PACKAGES
addappid(263102,0,"5b1b630476de424b7dca793d05e1c25709c52024325f378b3a08d12cc0f56303")
addappid(263103,0,"8ef5231f882bc84af050dc7e3a5d79b83b667c6f7d42c0bc6ffe3e53899a95af")
