-- Lua provided by RyzenAPI 
-- Game: AppID 1151720
addappid(1151720)
addappid(1151721, 1, "8272d61eafefb112e617756d33f81ee51b8f9c3624101859f9f17a04a3dd3093")
