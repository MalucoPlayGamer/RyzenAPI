-- Lua provided by RyzenAPI
-- Game: addappid(1151720)

-- MAIN APPLICATION
addappid(1151720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151721, 1, "8272d61eafefb112e617756d33f81ee51b8f9c3624101859f9f17a04a3dd3093")
