-- Lua provided by RyzenAPI
-- Game: addappid(1643000)

-- MAIN APPLICATION
addappid(1643000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643001, 1, "989b1e18b17d26a61dc2568bf333a7992d7fa31009a5c9a032da4a3d73e38e7d")
