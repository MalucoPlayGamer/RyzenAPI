-- Lua provided by RyzenAPI
-- Game: Envoy

-- MAIN APPLICATION
addappid(2561200)
-- Game: addappid(2561200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561202,0,"05969b6e90644489d3d0e38e3e6ee9bee5df5f5d0ba45393b2c42308a5fb6a6a")
addappid(2561203,0,"20630df01acacba726359e63072d73f5f74267dd61a6ad95159eb65a3e57c04f")
