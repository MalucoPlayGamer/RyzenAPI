-- Lua provided by RyzenAPI 
-- Game: Things That Bounce and Explode
addappid(1165960)
addappid(1165961, 1, "c09d77d0697125a55e286c2402a3b905d68117f42851f67fe99ed19be2ecdab9")
