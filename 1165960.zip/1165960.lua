-- Lua provided by RyzenAPI
-- Game: Things That Bounce and Explode

-- MAIN APPLICATION
addappid(1165960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1165961, 1, "c09d77d0697125a55e286c2402a3b905d68117f42851f67fe99ed19be2ecdab9")

