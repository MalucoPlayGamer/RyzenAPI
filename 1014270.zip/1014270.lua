-- Lua provided by RyzenAPI
-- Game: Game: AppID 1014270

-- MAIN APPLICATION
addappid(1014270)
-- Game: addappid(1014270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014271, 1, "c2f41f2d7134664d998963a56cb2fecd1315dd7a4ca3dfc93c8e4e0ff093faa3")
