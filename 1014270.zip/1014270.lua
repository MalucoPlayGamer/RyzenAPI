-- Lua provided by RyzenAPI
-- Game: Plaguepunk Justice

-- MAIN APPLICATION
addappid(1014270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1014271, 1, "c2f41f2d7134664d998963a56cb2fecd1315dd7a4ca3dfc93c8e4e0ff093faa3")
