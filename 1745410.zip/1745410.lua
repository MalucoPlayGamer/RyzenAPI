-- Lua provided by RyzenAPI
-- Game: Game: Skattered Dream

-- MAIN APPLICATION
addappid(1745410)
-- Game: addappid(1745410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745411, 1, "001bb93f5b62a156c87f17342cf90f7ac1b6c4ac4277cb25578f2b26534693de")
