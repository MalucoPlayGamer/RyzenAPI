-- Lua provided by RyzenAPI 
-- Game: Skattered Dream
addappid(1745410)
addappid(1745411, 1, "001bb93f5b62a156c87f17342cf90f7ac1b6c4ac4277cb25578f2b26534693de")
