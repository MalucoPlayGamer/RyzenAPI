-- Lua provided by RyzenAPI
-- Game: Stones Keeper

-- MAIN APPLICATION
addappid(1723530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723531, 1, "5c5ebfa787cdef37343f9ce8b5709bbb54f8539b711cb3a226a1a09dc6b103d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2202680)
