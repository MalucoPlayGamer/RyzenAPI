-- Lua provided by RyzenAPI
-- Game: addappid(1723530)

-- MAIN APPLICATION
addappid(1723530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723531, 1, "5c5ebfa787cdef37343f9ce8b5709bbb54f8539b711cb3a226a1a09dc6b103d5")
