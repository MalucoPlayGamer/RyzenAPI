-- Lua provided by RyzenAPI
-- Game: Game: Boxes: Lost Fragments

-- MAIN APPLICATION
addappid(2019810)
-- Game: addappid(2019810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019811, 1, "8cea3995d4cf96c6df7956209329e9da1a7a817fc1d2cd3b6a9d66833b16087a")
