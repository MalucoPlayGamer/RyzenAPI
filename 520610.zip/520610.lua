-- Lua provided by RyzenAPI
-- Game: 520610

-- MAIN APPLICATION
addappid(520610)
-- Game: addappid(520610)

-- MAIN APP DEPOTS / PACKAGES
addappid(520611, 1, "721b871d2a786b63ccaf4bd8bb0f6990b8723598c5ba46dde2f749d8502c693a")
