-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Gan Ning "Samurai Costume" / 甘寧「武者風コスチューム」

-- MAIN APPLICATION
addappid(1019990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019990,0,"ac399c92f4f52c31ca8765f9fb9151a31a9951b2549e9c9bbb04463654d95e1d")
