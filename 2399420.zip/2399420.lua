-- Lua provided by RyzenAPI 
-- Game: Le Mans Ultimate
addappid(2399420)
addappid(2399421, 1, "5ebe75565e2b00384fc9a712d85cb05cff556cce0e0a2566bbb63be290aaa378")
addappid(2973280)
addappid(2973290)
addappid(2997280)
addappid(3151390)
addappid(3260810)
addappid(3260820)
addappid(3307210)
addappid(3468240)
addappid(3511300)
