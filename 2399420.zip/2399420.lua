-- Lua provided by RyzenAPI
-- Game: Le Mans Ultimate

-- MAIN APPLICATION
addappid(2399420)
addappid(2973280)
addappid(2973290)
addappid(2997280)
addappid(3151390)
addappid(3260810)
addappid(3260820)
addappid(3307210)
addappid(3468240)
addappid(3511300)
addappid(3948300)
addappid(3954000)
addappid(3954010)
addappid(3954020)
addappid(4694190)
addappid(4906890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399421,0,"5ebe75565e2b00384fc9a712d85cb05cff556cce0e0a2566bbb63be290aaa378")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
