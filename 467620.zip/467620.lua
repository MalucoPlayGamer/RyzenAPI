-- Lua provided by RyzenAPI
-- Game: AppID 467620

-- MAIN APPLICATION
addappid(467620)

-- MAIN APP DEPOTS / PACKAGES
addappid(467621, 1, "64dcadb1f593d846afd696f06ea9450770c5c945d1b02cffc7d6f8226919439d")

