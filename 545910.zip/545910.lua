-- Lua provided by RyzenAPI
-- Game: Redemption Cemetery: Bitter Frost Collector's Edition

-- MAIN APPLICATION
addappid(545910)

-- MAIN APP DEPOTS / PACKAGES
addappid(545911,0,"205fec3a0865e529a268974dfc98645e0219b21e2acb6479ac1421977a80c871")

