-- Lua provided by RyzenAPI
-- Game: Obedient Women

-- MAIN APPLICATION
addappid(2139630)
-- Game: addappid(2139630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139631, 1, "fb6a92030b5821aba1c6fc42ef515474f25ce7a477bfcda0355ff6d679788cab")
addappid(2139653, 0, "ba30934db68c022d1397dafc07d924b46329727946f23b2f4c27b123a96fe799")
