-- Lua provided by RyzenAPI
-- Game: Obedient Women

-- MAIN APPLICATION
addappid(2139630)
addappid(2139650)
addappid(2139651)
addappid(2139652)
addappid(2224230)
addappid(2224231)
addappid(2224232)
addappid(2224233)
addappid(2306970)
addappid(2306971)
addappid(2306972)
addappid(2306973)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2139631, 1, "fb6a92030b5821aba1c6fc42ef515474f25ce7a477bfcda0355ff6d679788cab")
addappid(2139653, 0, "ba30934db68c022d1397dafc07d924b46329727946f23b2f4c27b123a96fe799")

