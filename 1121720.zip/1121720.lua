-- Lua provided by SkyAPI 
-- Game: AppID 1121720
addappid(1121720)
addappid(1121721, 1, "40ef16c1a115b003612b8a9c488a763fef510588409aa5f9e625c1e7bf16ef48")
addappid(1121722, 1, "8aa03b50950f34c2eb51bc07ad61c9bd66bb20c6276b75a1bcf8f519d59666bc")
