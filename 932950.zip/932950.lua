-- Lua provided by RyzenAPI
-- Game: 932950

-- MAIN APPLICATION
addappid(932950)
-- Game: addappid(932950)

-- MAIN APP DEPOTS / PACKAGES
addappid(932951, 1, "6dd65285d1ad959405b89285cd3b06b0a4467487af74d63b63d5a207f9185e9c")
