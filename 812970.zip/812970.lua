-- Lua provided by RyzenAPI
-- Game: Vagante: Original Soundtrack

-- MAIN APPLICATION
addappid(812970)

-- MAIN APP DEPOTS / PACKAGES
addappid(812971, 1, "4de6fa14fe733a8487d0daf28c610b385d0a4812a6403d510b0827b9c32f3e8b")

