-- Lua provided by RyzenAPI
-- Game: The Cummunist Manifesto

-- MAIN APPLICATION
addappid(3149270) -- The Cummunist Manifesto

-- MAIN APP DEPOTS / PACKAGES
addappid(3149271, 1, "514a160245d1b51274ce51a1b388829fc8f2a5ce58eb587733e31e3e415190aa") -- Depot 3149271

