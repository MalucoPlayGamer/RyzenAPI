-- 3149270's Lua and Manifest Created by Hubcap Manifest
-- The Cummunist Manifesto
-- Created: August 17, 2026 at 01:06:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3149270) -- The Cummunist Manifesto
-- MAIN APP DEPOTS
addappid(3149271, 1, "514a160245d1b51274ce51a1b388829fc8f2a5ce58eb587733e31e3e415190aa") -- Depot 3149271
setManifestid(3149271, "1639632405759969653", 242195480)