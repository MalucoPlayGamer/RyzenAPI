-- Lua provided by RyzenAPI
-- Game: Game: AppID 953610

-- MAIN APPLICATION
addappid(953610)
-- Game: addappid(953610)

-- MAIN APP DEPOTS / PACKAGES
addappid(953611, 1, "910833f4dc027783a212d9344ffc25680cfde5380aec171680ab207506feab62")
