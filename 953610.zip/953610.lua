-- Lua provided by RyzenAPI 
-- Game: AppID 953610
addappid(953610)
addappid(953611, 1, "910833f4dc027783a212d9344ffc25680cfde5380aec171680ab207506feab62")
