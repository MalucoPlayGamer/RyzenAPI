-- Lua provided by RyzenAPI
-- Game: addappid(2682600)

-- MAIN APPLICATION
addappid(2682600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682601, 1, "fe6075074fbdc0baf26f1fd79c3eb2ee8acf60810b6516c6f90f5a5c3c9ceeed")
