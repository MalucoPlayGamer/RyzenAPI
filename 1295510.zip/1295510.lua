-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST XI S: Echoes of an Elusive Age – Definitive Edition

-- MAIN APPLICATION
addappid(1295510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1295513,0,"940f6f87ded1c6f17229cc6e898c946f8ae111e0f74214543e0d73384711c0f2")

