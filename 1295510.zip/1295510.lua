-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST® XI S: Echoes of an Elusive Age™ - Definitive Edition

-- MAIN APPLICATION
addappid(1295510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295513,0,"940f6f87ded1c6f17229cc6e898c946f8ae111e0f74214543e0d73384711c0f2")
