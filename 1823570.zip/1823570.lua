-- Lua provided by RyzenAPI
-- Game: addappid(1823570)

-- MAIN APPLICATION
addappid(1823570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823571, 1, "a84020e13dd8cadae78c5ffb6689a93c75bfba76c7aef7828110c4a7dc7264df")
