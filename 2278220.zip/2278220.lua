-- Lua provided by RyzenAPI
-- Game: addappid(2278220)

-- MAIN APPLICATION
addappid(2278220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278221, 1, "2dd80cf66c8fde5cc0856129828db596744be46b24cbebfc2455176b35be0f72")
