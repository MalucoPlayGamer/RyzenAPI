-- Lua provided by RyzenAPI
-- Game: CMYW

-- MAIN APPLICATION
addappid(396590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(396591, 1, "1d0de7cae6d02c6b49476ec2d4570a947f689671ccb05f39521bd9b1677a349b")

