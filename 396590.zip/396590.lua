-- Lua provided by RyzenAPI 
-- Game: CMYW
addappid(396590)
addappid(396591, 1, "1d0de7cae6d02c6b49476ec2d4570a947f689671ccb05f39521bd9b1677a349b")
