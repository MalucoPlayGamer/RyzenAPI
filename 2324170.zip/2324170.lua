-- Lua provided by RyzenAPI
-- Game: Mythwrecked: Ambrosia Island Demo

-- MAIN APPLICATION
addappid(2324170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324171, 1, "2ce743fbd838c25763e03b816ae3dde8bb95e1db4dc31603d5cae23959219131")

