-- Lua provided by RyzenAPI
-- Game: Lucky Shot

-- MAIN APPLICATION
addappid(869180)

-- MAIN APP DEPOTS / PACKAGES
addappid(869181, 1, "5960be89a6ed533b407c3d22978523198e7578887bc3aee208dda215341bf173")

