-- Lua provided by RyzenAPI
-- Game: addappid(3440750)

-- MAIN APPLICATION
addappid(3440750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440751, 1, "cb7120f796b61e1f1bea030b9bf31e52db9e01309d8d9d2210fa4a6c1d553427")
