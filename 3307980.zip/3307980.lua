-- Lua provided by RyzenAPI
-- Game: Game: UNPUNISHED

-- MAIN APPLICATION
addappid(3307980)
-- Game: addappid(3307980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3307981, 1, "7c311701e21f52001baeffb0f39121fa7711547eedad69c9b3a78231547f90d2")
