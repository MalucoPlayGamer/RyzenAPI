-- Lua provided by RyzenAPI
-- Game: UNPUNISHED

-- MAIN APPLICATION
addappid(3307980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3307981, 1, "7c311701e21f52001baeffb0f39121fa7711547eedad69c9b3a78231547f90d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
