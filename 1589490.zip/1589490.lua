-- Lua provided by RyzenAPI
-- Game: Game: MeiQi 2022

-- MAIN APPLICATION
addappid(1589490)
-- Game: addappid(1589490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589491, 1, "e166035e1857a089d88564bf1c985f588a440b12739944401ecb1bc14cbec70f")
