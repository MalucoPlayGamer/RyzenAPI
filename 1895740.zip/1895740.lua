-- Lua provided by RyzenAPI
-- Game: 1895740

-- MAIN APPLICATION
addappid(1895740)
-- Game: addappid(1895740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895741, 1, "8c74331acf74d1042270fd7dac5c89073c87fb8b2edc9e23286fe5875a7bc1a6")
