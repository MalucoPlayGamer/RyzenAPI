-- Lua provided by RyzenAPI
-- Game: Inori's House

-- MAIN APPLICATION
addappid(1073370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073371, 1, "8503d15f7b62683129ee57e853dbbee4a1814435a268e71c137e74583295a9bb")
