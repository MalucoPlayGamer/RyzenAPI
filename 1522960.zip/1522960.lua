-- Lua provided by RyzenAPI
-- Game: Anemoiapolis: Chapter 1

-- MAIN APPLICATION
addappid(1522960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522961, 1, "4ae1b706c46cc1e3aca6e2040b858a5e0c2eab28033eabed5ac691e9f78ac1d3")
