-- Lua provided by RyzenAPI
-- Game: The Bridge

-- MAIN APPLICATION
addappid(821160)

-- MAIN APP DEPOTS / PACKAGES
addappid(821161, 1, "84736db66161692d75e04d8a40539fc235abe296da0af1ed3180c0d622da21ca")

