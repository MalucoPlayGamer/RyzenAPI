-- Lua provided by RyzenAPI
-- Game: AppID 838410

-- MAIN APPLICATION
addappid(838410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(838411, 1, "dbdc004cf38063713442eb653ef701651ec5491c2d31db24a137e65ae9a8b2d3")
addappid(838412, 1, "fc8dafdea1b43185a73c8acab80dcff2175d2be8843dc193a0a598e41dd7e2c2")
addappid(838413, 1, "86e361e25d277ffe13c96213e344a611ecf9353e3d6e8b4fc9716fad4fc4b0fc")

