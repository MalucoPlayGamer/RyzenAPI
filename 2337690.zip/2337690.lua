-- Lua provided by RyzenAPI
-- Game: 2337690

-- MAIN APPLICATION
addappid(2337690)
-- Game: addappid(2337690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337691, 1, "9094cfae44f0dc41101742943dd2a6fa87a56796cfc0dc3eb4c6a54eee651b33")
