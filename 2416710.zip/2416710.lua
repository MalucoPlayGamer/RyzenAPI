-- Lua provided by RyzenAPI
-- Game: Mother Ghoul - The Curse of Unborns

-- MAIN APPLICATION
addappid(2416710)
addappid(2416713)
-- Game: addappid(2416710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416712,0,"0e9f9c9ca314dd503b7dccb9439681de53c53df169149b645a63c4a8c7a4faaa")
