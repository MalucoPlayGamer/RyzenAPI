-- Lua provided by SkyAPI 
-- Game: Redrum: Dead Diary
addappid(541720)
addappid(541721, 1, "730fbc9d8c057aa159f7c6ae373c85215c512a0f12a478e586f2d06e6ac580f7")
addappid(541722, 1, "a48186035826e6815a04723743283a2b68abfd24bf1b4fcb79d359a92c205007")
