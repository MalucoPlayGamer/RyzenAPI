-- Lua provided by RyzenAPI
-- Game: B.I.O.T.A.

-- MAIN APPLICATION
addappid(1640320)
-- Game: addappid(1640320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640321, 1, "ef9ddba9618ef5639c2787d27b709582734f2ac9a3059d69a5a9083ffc162067")
