-- Lua provided by RyzenAPI
-- Game: Pretty Dinosaur Adventures of Ancient Earth VR

-- MAIN APPLICATION
addappid(2250850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250851, 1, "31f7b5715a21377a213be4c63ec4e4f9a20ea2d72181a985766ce6d62f026885")

