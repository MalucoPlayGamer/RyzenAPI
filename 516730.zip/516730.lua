-- Lua provided by RyzenAPI
-- Game: 516730

-- MAIN APPLICATION
addappid(516730)
-- Game: addappid(516730)

-- MAIN APP DEPOTS / PACKAGES
addappid(516731, 1, "59d84717f09aa4a4dd8081f49036dbe73d34a34f8a5abe4893ba3a71e112bba1")
