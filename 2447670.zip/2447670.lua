-- Lua provided by RyzenAPI
-- Game: ASMR Food Experience Playtest

-- MAIN APPLICATION
addappid(2447670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447671, 1, "05b704e25c9c7210168d59e77bb63c786c2c4a8de83b1e0f8f55c6b294f12c20")
