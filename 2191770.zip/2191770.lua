-- Lua provided by RyzenAPI
-- Game: addappid(2191770)

-- MAIN APPLICATION
addappid(2191770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191771, 1, "8063e5ae14e29af42a10fc846738f6b01bf09bae09649e90c3a1c9d006d3fefe")
