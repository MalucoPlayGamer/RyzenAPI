-- Lua provided by RyzenAPI 
-- Game: Dead Dreams
addappid(1195910)
addappid(1195911, 1, "3b2c134661a2cef51204229bc064a8bc582fb46bea377b6cd0e8d9e821761e86")
