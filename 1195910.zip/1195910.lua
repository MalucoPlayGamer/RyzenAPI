-- Lua provided by RyzenAPI
-- Game: Dead Dreams

-- MAIN APPLICATION
addappid(1195910)
-- Game: addappid(1195910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195911, 1, "3b2c134661a2cef51204229bc064a8bc582fb46bea377b6cd0e8d9e821761e86")
