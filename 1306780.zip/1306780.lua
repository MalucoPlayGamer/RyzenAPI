-- Lua provided by RyzenAPI
-- Game: Pledge: Extra credit

-- MAIN APPLICATION
addappid(1306780)
-- Game: addappid(1306780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306781, 1, "b6d8f1a7283ecba9be0ed6c5b594e15d0ecf56e2c520a22562839bf872f9511e")
