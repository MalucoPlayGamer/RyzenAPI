-- Lua provided by RyzenAPI
-- Game: Coffin Dodgers

-- MAIN APPLICATION
addappid(320540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(320541, 1, "9fe6fe0a9fbfc4c12438324713fb6c47cace26d9c6e3fa65a758d38773cabcc6")
addappid(320542, 1, "f898679e74429dc376be2c783e87b57c6f73603a4ec67b87a63185caf44e09da")
addappid(320543, 1, "bccbaed1a5f6bccf04ebf9b7f74e32075a07f63ce4949e64caeb9e3172e3bfce")
addappid(503470, 0, "75f82b5be59268c2c34ed4a7137738130576d9cfd5439cf3ebda92fba54ea1da")

