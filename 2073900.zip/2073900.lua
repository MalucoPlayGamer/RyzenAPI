-- Lua provided by RyzenAPI
-- Game: 2073900

-- MAIN APPLICATION
addappid(2073900)
-- Game: addappid(2073900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073901, 1, "79fee2983375d2d4115702be1d4d6d9d49b7c3ae258e7fde25f947e11895a92c")
