-- Lua provided by RyzenAPI
-- Game: 1201330

-- MAIN APPLICATION
addappid(1201330)
-- Game: addappid(1201330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201331, 1, "390a0bc585dfc6dea0ad89f9868fe8e9406b16d407d6003307483ccffdce81ee")
