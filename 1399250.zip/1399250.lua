-- Lua provided by RyzenAPI
-- Game: Red Cap Zombie Hunter

-- MAIN APPLICATION
addappid(1399250)
-- Game: addappid(1399250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399251, 1, "e6a0ed7cf0ef7a9405450a4b69ac3cf20b99e25c31abffabdc4f4ac02e43253d")
