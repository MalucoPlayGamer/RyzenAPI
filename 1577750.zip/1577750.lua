-- Lua provided by RyzenAPI
-- Game: Hamster All-Stars

-- MAIN APPLICATION
addappid(1577750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1577751, 1, "15e4179ed19c6cbc529683f722212a518f9ca32ad9467dcd6721ad9cc46c8539")
addappid(1577752, 1, "dc26192965df0c43d00eb6730247afb446a0d87d1f483dea372ea143dfe27126")

