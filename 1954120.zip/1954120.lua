-- Lua provided by RyzenAPI
-- Game: 4D Miner Demo

-- MAIN APPLICATION
addappid(1954120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954121, 1, "3ad50d2304fee8baa199a3c469197edcb784de588e60fffa9c3428a674015169")