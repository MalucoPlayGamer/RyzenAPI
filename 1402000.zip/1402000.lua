-- Lua provided by RyzenAPI
-- Game: Trapped Guys

-- MAIN APPLICATION
addappid(1402000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402001, 1, "a4bc68badc15065250e2559f1a2b1e50759f1c14da955828a8e6b3f66690ef76")
