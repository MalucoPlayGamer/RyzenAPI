-- Lua provided by SkyAPI 
-- Game: Trapped Guys
addappid(1402000)
addappid(1402001, 1, "a4bc68badc15065250e2559f1a2b1e50759f1c14da955828a8e6b3f66690ef76")
