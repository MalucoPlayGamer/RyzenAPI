-- Lua provided by RyzenAPI 
-- Game: Manzaka
addappid(2759050)
addappid(2759051, 1, "410930808375195ed7a12389981f06a283133423f6dd7fb5671b590e3363e542")
