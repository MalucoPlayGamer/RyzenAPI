-- Lua provided by RyzenAPI
-- Game: Game: Manzaka

-- MAIN APPLICATION
addappid(2759050)
-- Game: addappid(2759050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759051, 1, "410930808375195ed7a12389981f06a283133423f6dd7fb5671b590e3363e542")
