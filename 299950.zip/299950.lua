-- Lua provided by RyzenAPI
-- Game: GET EVEN

-- MAIN APPLICATION
addappid(299950)
addappid(623110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(299951, 1, "28a91a11aa6672341070c14fc9a533bd4d70a56eab97532b2c6731383906768a")
addappid(299952, 1, "29097e6170fc521c6035aac6ffefdf0a825ab232778cadd4893c4945e2930db2")

