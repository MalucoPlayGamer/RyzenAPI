-- Lua provided by RyzenAPI
-- Game: Game: Game Time Glizzys

-- MAIN APPLICATION
addappid(2520630)
-- Game: addappid(2520630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520631, 1, "14933b1b9208af7ee3b42007b38b437d798645818e9403d8ad3324c3c3c9e828")
