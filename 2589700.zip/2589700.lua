-- Lua provided by RyzenAPI
-- Game: Two Strikes Demo

-- MAIN APPLICATION
addappid(2589700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589701, 1, "ee353f61f153ea2efbe2d3de52d82e22d4fe58408151fe83770e7e25ae528dcf")
