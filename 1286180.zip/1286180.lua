-- Lua provided by SkyAPI 
-- Game: AppID 1286180
addappid(1286180)
addappid(1286181, 1, "5e3a40d1c0d063836db6c425be59bc8d4a07e6ca1d22dd1a77a030af60e45af8")
