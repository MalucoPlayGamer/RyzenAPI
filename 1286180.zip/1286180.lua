-- Lua provided by RyzenAPI
-- Game: Porn Star Island

-- MAIN APPLICATION
addappid(1286180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286181, 1, "5e3a40d1c0d063836db6c425be59bc8d4a07e6ca1d22dd1a77a030af60e45af8")
