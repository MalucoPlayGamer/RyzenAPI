-- Lua provided by RyzenAPI
-- Game: 534980

-- MAIN APPLICATION
addappid(534980)
addappid(538750)
-- Game: addappid(534980)

-- MAIN APP DEPOTS / PACKAGES
addappid(534981, 1, "14aeb0f2dcbabc87b3227a5bc750480813c1f8b61b62388b2b6b385e4ff58af3")
