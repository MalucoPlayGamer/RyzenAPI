-- Lua provided by RyzenAPI
-- Game: Echo Nine

-- MAIN APPLICATION
addappid(652140)

-- MAIN APP DEPOTS / PACKAGES
addappid(652141,0,"1d05cf90db430a0802f41fcb7e59407f29228ccf8a85738e2dfbb40d381a8f2d")

