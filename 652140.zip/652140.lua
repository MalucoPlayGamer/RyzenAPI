-- Lua provided by RyzenAPI
-- Game: Echo Nine

-- MAIN APPLICATION
addappid(652140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(652141,0,"1d05cf90db430a0802f41fcb7e59407f29228ccf8a85738e2dfbb40d381a8f2d")

