-- Lua provided by RyzenAPI
-- Game: AppID 880570

-- MAIN APPLICATION
addappid(880570)
addappid(884010)

-- MAIN APP DEPOTS / PACKAGES
addappid(880571, 1, "f136b98ea1f5e6dfdeadc244405c2b0054315f8646c2548def9462d281e90bb2")

