-- Lua provided by RyzenAPI
-- Game: AppID 941040

-- MAIN APPLICATION
addappid(941040)
-- Game: addappid(941040)

-- MAIN APP DEPOTS / PACKAGES
addappid(941041, 1, "12b4d01f8f6e0c74c4f40353722ee1c7b69fb34a47b1489451e36117ba90fe00")
