-- Lua provided by RyzenAPI
-- Game: Game: AppID 1215870

-- MAIN APPLICATION
addappid(1215870)
-- Game: addappid(1215870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215871, 1, "ea6aad80fe9b43be395113551e8fb91436a47a96bf68e78211eb6a59eae8908a")
