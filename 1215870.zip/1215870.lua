-- Lua provided by RyzenAPI
-- Game: The Walking Evil

-- MAIN APPLICATION
addappid(1215870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1215871, 1, "ea6aad80fe9b43be395113551e8fb91436a47a96bf68e78211eb6a59eae8908a")

