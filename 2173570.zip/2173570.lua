-- Lua provided by RyzenAPI
-- Game: addappid(2173570)

-- MAIN APPLICATION
addappid(2173570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173571, 1, "8cf205bf501f1475ba9c12b4ac144c3b4e698186e531cd72d9b7ca1519ac91a7")
