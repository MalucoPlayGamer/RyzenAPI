-- Lua provided by RyzenAPI
-- Game: ZEROCAR: Future Motorsport

-- MAIN APPLICATION
addappid(790080)

-- MAIN APP DEPOTS / PACKAGES
addappid(790081,0,"57bbf86b53f8abc0a838290cb5214576e14b08218198b8e2f744520d73bc41e4")

