-- Lua provided by RyzenAPI
-- Game: addappid(1372770)

-- MAIN APPLICATION
addappid(1372770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372771, 1, "d967ccd92018a5921ea336c1c99740ef04a79bfcf96190c0d5ac9d4821eee0f9")
