-- Lua provided by RyzenAPI
-- Game: Game: Neon Village Demo

-- MAIN APPLICATION
addappid(2952120)
-- Game: addappid(2952120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2952121, 1, "b20a2b697edf8c3591463dd1e92793735b9e438a2354c54bafa628e86ee16e70")
