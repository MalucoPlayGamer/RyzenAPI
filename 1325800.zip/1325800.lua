-- Lua provided by RyzenAPI 
-- Game: AppID 1325800
addappid(1325800)
addappid(1325801, 1, "6495c87870d879154bc0e87d722243ebb06ef366d7ada3ff896a53a30b0d4a13")
