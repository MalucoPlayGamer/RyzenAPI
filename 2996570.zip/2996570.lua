-- Lua provided by RyzenAPI
-- Game: addappid(2996570)

-- MAIN APPLICATION
addappid(2996570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996571, 1, "22d28241bbf5981e0adf5312e88b3d5d29eae805069166112feb915c7c7dd90f")
