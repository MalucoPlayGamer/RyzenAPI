-- Lua provided by SkyAPI 
-- Game: Countryside Dating
addappid(2367680)
addappid(2367681, 1, "2efce41f306d00b3683330fef12d379ae50710dc78ddfcf6d2ebffb581b4b9a1")
