-- Lua provided by RyzenAPI
-- Game: 2367680

-- MAIN APPLICATION
addappid(2367680)
-- Game: addappid(2367680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367681, 1, "2efce41f306d00b3683330fef12d379ae50710dc78ddfcf6d2ebffb581b4b9a1")
