-- Lua provided by RyzenAPI
-- Game: 3229170

-- MAIN APPLICATION
addappid(3229170)
-- Game: addappid(3229170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229171, 1, "16f7553d802bf5685eaa14b6b49782454f2afff590bfd50fd3bdd54538dc8d63")
