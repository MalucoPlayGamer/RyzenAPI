-- Lua provided by RyzenAPI
-- Game: addappid(2272570)

-- MAIN APPLICATION
addappid(2272570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272571, 1, "a7438b05aab41009b1ee79cc1084f6e93cb8f87896490295ddcf9060a175d771")
