-- Lua provided by RyzenAPI 
-- Game: The Bread Must Rise Demo
addappid(2272570)
addappid(2272571, 1, "a7438b05aab41009b1ee79cc1084f6e93cb8f87896490295ddcf9060a175d771")
