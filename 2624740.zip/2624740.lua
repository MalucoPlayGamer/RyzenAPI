-- Lua provided by RyzenAPI
-- Game: addappid(2624740)

-- MAIN APPLICATION
addappid(2624740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624741, 1, "1b73eff41eba5922089424f4622480b698cb4cbafd9aa87eae5308e4820d0744")
