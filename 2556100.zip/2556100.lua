-- Lua provided by SkyAPI 
-- Game: 骰子模拟器
addappid(2556100)
addappid(2556101, 1, "7312758917c59beff8ce9e96575ba2f88ee86f643170426688f4e0259348c232")
