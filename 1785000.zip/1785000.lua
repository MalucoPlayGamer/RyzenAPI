-- Lua provided by SkyAPI 
-- Game: Mokoko X
addappid(1785000)
addappid(1785001, 1, "d5ff4b99b6816c7d1cbfbf6082f9107417aa758246a12889f21c6a98aac30b00")
addappid(1785002, 1, "36b4244fd12b057e95fbb23f1665e55cefa08d327bb9bbaa7203882bbb24632b")
