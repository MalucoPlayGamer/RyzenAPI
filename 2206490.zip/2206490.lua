-- Lua provided by RyzenAPI
-- Game: Ruined Kingdom

-- MAIN APPLICATION
addappid(2206490)
-- Game: addappid(2206490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206491, 1, "102ae56c4a1a2bf73ec52929881a91eff80003225360f79a343398bd60cbef57")
addappid(2206492, 1, "8c9a5f904c464275d30de05a5bcbf1a40cb8263aad3f55af6e4a79fae8562c9e")
addappid(2206493, 1, "e863950caa6dde60744d8ce25907e1b48e96150ae82fcba3994198fb0b03873d")
