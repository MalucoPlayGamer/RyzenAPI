-- Lua provided by RyzenAPI
-- Game: Duskfade

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2542020, 1, "8baa61ba648b203f72825f27792a8f0aea234e6cb66182ee37a6884a51b41c8c") -- Duskfade
addappid(2542022, 1, "516e0ca255dc9e621518dcf785ec6c5a3e902a6f714b5e9ad99acbb539f42729") -- Depot 2542022

