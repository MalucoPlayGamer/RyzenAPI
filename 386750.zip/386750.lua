-- Lua provided by RyzenAPI
-- Game: 386750

-- MAIN APPLICATION
addappid(386750)
-- Game: addappid(386750)

-- MAIN APP DEPOTS / PACKAGES
addappid(386751, 1, "30e9bb05eec521562497dc22dfd73fa25bd999a406e0b587fae15845a23092c3")
