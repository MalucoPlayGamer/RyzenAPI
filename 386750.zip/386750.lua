-- Lua provided by RyzenAPI 
-- Game: Cashtronauts
addappid(386750)
addappid(386751, 1, "30e9bb05eec521562497dc22dfd73fa25bd999a406e0b587fae15845a23092c3")
