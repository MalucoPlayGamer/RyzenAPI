-- Lua provided by RyzenAPI
-- Game: Ghost Gunners

-- MAIN APPLICATION
addappid(2883690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883691,0,"7390658d6f8334242c49ffc1d4ec38d5223f4a5699c98bbd97f1d439ffcc889a")

