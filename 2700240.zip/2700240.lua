-- Lua provided by RyzenAPI
-- Game: Bloody Ink

-- MAIN APPLICATION
addappid(2700240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700241, 1, "68c15a97c18e262f302efa472ba3c36e42e77716e2a0c3d6d132f55edee6acfb")
