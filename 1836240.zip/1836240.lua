-- Lua provided by RyzenAPI
-- Game: Paintball

-- MAIN APPLICATION
addappid(1836240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1836241, 1, "d61ed39099fb6b4473061986e4095fd814e8b193c84e6a492424d7a1faec86d1")

