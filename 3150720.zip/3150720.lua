-- Lua provided by RyzenAPI
-- Game: Mint's Hints

-- MAIN APPLICATION
addappid(3150720)
