-- Lua provided by RyzenAPI
-- Game: Mini Taoism

-- MAIN APPLICATION
addappid(2339220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339221, 1, "dc1b2c807e96619583366e44922de7dafb66e3a1e3bf86075fb215c394602162")
