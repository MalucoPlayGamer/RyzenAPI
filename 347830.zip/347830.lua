-- Lua provided by RyzenAPI
-- Game: Fairy Fencer F

-- MAIN APPLICATION
addappid(347830)

-- MAIN APP DEPOTS / PACKAGES
addappid(347831, 1, "c9a3b19af233a90e8244fa1b2feaaa60bff1784977df16bd6af77d5b83fa3c36")
addappid(367410, 0, "d30847cad7baf46319e9198c47a2d761a5311a80817fcc2e6e27c03bad8e3197")
addappid(367411, 0, "b809003121eb995e9874ad9cc1abcecd9d72405337023d03c5b1e696f5860e8a")
addappid(367412, 0, "5be1b16844311c1385d5846cc06e08597c177fcb2cf16a1049838db68fa0b4b6")
addappid(367413, 0, "4820818c326b4425d13c5eddc8f9d5268568dace766667852d6e2777c08a300a")
addappid(367414, 0, "959a4686ba4e583a7a38d95b9bbdbdb513aa27a7cc98d3a81582ffa4d84060d2")
addappid(367415, 0, "ff21a63a6eaeaf674144231ccccf4bfd50bd6282639ca9ba42a2787c9757ee82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
