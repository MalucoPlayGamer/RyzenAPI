-- Lua provided by RyzenAPI
-- Game: Tehnodrom

-- MAIN APPLICATION
addappid(2999750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999751, 1, "f8a50b1701f51b7d51e2167ddacb1bcf32e1c4d1f4d34148c8d6a6e8fd9d15c7")

