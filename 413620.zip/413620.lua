-- Lua provided by RyzenAPI
-- Game: Space Needle VR

-- MAIN APPLICATION
addappid(413620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(413621, 1, "270a834886a1fa98ca9a7fa13f0d9c2568a15d0b7da094cea49ba6db73ce819c")

