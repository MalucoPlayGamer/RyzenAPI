-- Lua provided by RyzenAPI
-- Game: addappid(413620)

-- MAIN APPLICATION
addappid(413620)

-- MAIN APP DEPOTS / PACKAGES
addappid(413621, 1, "270a834886a1fa98ca9a7fa13f0d9c2568a15d0b7da094cea49ba6db73ce819c")
