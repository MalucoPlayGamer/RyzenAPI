-- Lua provided by RyzenAPI
-- Game: Anime Jigsaw Girls - Office

-- MAIN APPLICATION
addappid(1810600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810601, 1, "012470897f0cb7548685dfa8772fae6cfae41bc09d1b1caa92389e86da67eb50")
addappid(1810910, 0, "5cd906a592fd22209c01dfd433d175a309b215bb9190c8daa51e239fb504321b")
