-- Lua provided by RyzenAPI
-- Game: Game: Book of Legends

-- MAIN APPLICATION
addappid(47130)
-- Game: addappid(47130)

-- MAIN APP DEPOTS / PACKAGES
addappid(47131, 1, "e702f807e0325770e09f3d1d6d15c88915352ac5192a3e3a429e6b77049a587a")
