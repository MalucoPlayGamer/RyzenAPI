-- Lua provided by RyzenAPI
-- Game: 844220

-- MAIN APPLICATION
addappid(844220)
-- Game: addappid(844220)

-- MAIN APP DEPOTS / PACKAGES
addappid(844220,0,"64662398036b4da4f90a34baf38baa0d1bd6a0921a6cb5b1e86952373483b132")
