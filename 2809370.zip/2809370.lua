-- Lua provided by RyzenAPI
-- Game: The Crack (壳中之物）

-- MAIN APPLICATION
addappid(2809370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809371, 1, "b7d8da844e502c7b57dee647546637ee1d054055a25ed8069990bcca30f90d2f")

