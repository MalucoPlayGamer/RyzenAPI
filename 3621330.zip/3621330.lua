-- Lua provided by RyzenAPI
-- Game: Pro Jank Footy

-- MAIN APPLICATION
addappid(3621330) -- Pro Jank Footy

-- MAIN APP DEPOTS / PACKAGES
addappid(3621331, 1, "3cc8292a6a6ac39d7ba61e6483f45e3e2bfd679f4c393461332984d63e81128b") -- Depot 3621331

