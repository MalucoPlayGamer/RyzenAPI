-- 3621330's Lua and Manifest Created by Hubcap Manifest
-- Pro Jank Footy
-- Created: August 13, 2026 at 04:05:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3621330) -- Pro Jank Footy
-- MAIN APP DEPOTS
addappid(3621331, 1, "3cc8292a6a6ac39d7ba61e6483f45e3e2bfd679f4c393461332984d63e81128b") -- Depot 3621331
setManifestid(3621331, "2659864715090977701", 1279162729)