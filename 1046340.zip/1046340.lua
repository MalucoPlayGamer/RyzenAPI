-- Lua provided by RyzenAPI
-- Game: DFF NT: Fallen One Appearance Set for Kefka Palazzo

-- MAIN APPLICATION
addappid(1046340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046340,0,"79584f4690bcb1a5e22da5765014a4530ac9ef61f26c3c37dd6f03793a164cbe")

