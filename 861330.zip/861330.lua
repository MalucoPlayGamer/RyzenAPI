-- Lua provided by RyzenAPI
-- Game: Dungeon Deathball

-- MAIN APPLICATION
addappid(861330)

-- MAIN APP DEPOTS / PACKAGES
addappid(861331,0,"6de3604855e75420733325511fa629cccb7877370481c387ba11a0bd39f0c940")

