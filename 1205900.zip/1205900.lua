-- Lua provided by RyzenAPI
-- Game: Game: AppID 1205900

-- MAIN APPLICATION
addappid(1205900)
-- Game: addappid(1205900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205901, 1, "415275b1104da5443a655db02fdfa49fa9b18888daf6c50e5a0b22809d788c70")
