-- Lua provided by RyzenAPI 
-- Game: GP Bikes
addappid(848050)
addappid(848051, 1, "1e5bc91073683ea38e7026c68149c14c4acc9335e382172f50d3b286cf5e9957")
