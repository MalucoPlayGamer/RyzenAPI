-- Lua provided by RyzenAPI
-- Game: 848050

-- MAIN APPLICATION
addappid(848050)
-- Game: addappid(848050)

-- MAIN APP DEPOTS / PACKAGES
addappid(848051, 1, "1e5bc91073683ea38e7026c68149c14c4acc9335e382172f50d3b286cf5e9957")
