-- Lua provided by RyzenAPI 
-- Game: TRON: Catalyst
addappid(3025590)
addappid(3025591, 1, "2de63e32b9fbfaae7b21d306b1a1d21976a3da3aeada30e131952f50adb491ba")
