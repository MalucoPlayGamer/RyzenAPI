-- Lua provided by RyzenAPI
-- Game: Game: TRON: Catalyst

-- MAIN APPLICATION
addappid(3025590)
-- Game: addappid(3025590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025591, 1, "2de63e32b9fbfaae7b21d306b1a1d21976a3da3aeada30e131952f50adb491ba")
