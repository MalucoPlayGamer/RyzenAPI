-- Lua provided by SkyAPI 
-- Game: AppID 1063440
addappid(1063440)
addappid(1063441, 1, "301f8c9f0dc544d3887c120016bbcbf33b3f3f4765bb31d04679d890f5c002c0")
