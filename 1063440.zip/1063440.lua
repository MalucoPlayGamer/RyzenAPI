-- Lua provided by RyzenAPI
-- Game: Homeless Simulator 2

-- MAIN APPLICATION
addappid(1063440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063441, 1, "301f8c9f0dc544d3887c120016bbcbf33b3f3f4765bb31d04679d890f5c002c0")

