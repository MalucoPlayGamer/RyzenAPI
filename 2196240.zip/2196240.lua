-- Lua provided by RyzenAPI
-- Game: Game: Furry Survivals 18+

-- MAIN APPLICATION
addappid(2196240)
-- Game: addappid(2196240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196241, 1, "419112f46b44cb89c5a84bddebb4726b1991dc34f99486f1d1329f0b79e6c281")
