-- Lua provided by SkyAPI 
-- Game: Prove You Can Win Demo
addappid(3379160)
addappid(3379161, 1, "e6ac1263e8a96d4516e3b3740e1ad5f5860d95db1d9d7d39ae501a3c61a5a281")
