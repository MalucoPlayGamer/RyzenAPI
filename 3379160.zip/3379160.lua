-- Lua provided by RyzenAPI
-- Game: Prove You Can Win Demo

-- MAIN APPLICATION
addappid(3379160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3379161, 1, "e6ac1263e8a96d4516e3b3740e1ad5f5860d95db1d9d7d39ae501a3c61a5a281")

