-- Lua provided by RyzenAPI
-- Game: 1869430

-- MAIN APPLICATION
addappid(1869430)
-- Game: addappid(1869430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869431, 1, "3dec4ffce2dab14b991a895b5a52936aed82d7f9ec9512e0945090fa1ba12953")
