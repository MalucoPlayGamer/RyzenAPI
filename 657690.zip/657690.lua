-- Lua provided by RyzenAPI
-- Game: The Caribbean Sail

-- MAIN APPLICATION
addappid(657690)

-- MAIN APP DEPOTS / PACKAGES
addappid(657691, 1, "7cffed3b28ce4b7015594aab4f0053a58146f32cfd01196375e315041fdad9c4")

