-- Lua provided by RyzenAPI
-- Game: 794150

-- MAIN APPLICATION
addappid(794150)
-- Game: addappid(794150)

-- MAIN APP DEPOTS / PACKAGES
addappid(794150,0,"ec571665d1640682715e29d92da64cd3ee08d2c316b561d4b4506a5403c5e5ae")
