-- Lua provided by RyzenAPI
-- Game: Kebabstar Demo

-- MAIN APPLICATION
addappid(3083280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3083281, 1, "01fa213516d5514f220a5267d452beacded8604fd316337845da7f5868979664")

