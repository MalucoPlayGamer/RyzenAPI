-- Lua provided by RyzenAPI
-- Game: 秘封旅行 ~Secret Sealing Travel

-- MAIN APPLICATION
addappid(1176050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176051, 1, "67557fb0a7a78fe41c82a54572d53bf91f434d87893f6634fe982e5004824eb2")

