-- Lua provided by RyzenAPI
-- Game: Marauder

-- MAIN APPLICATION
addappid(289600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(289601, 1, "886fa9168dd7e4db59e7674992252732e7d55b58094aa7fd95873138d53a2117")
addappid(289602, 1, "cc99b42910645332fe7ffec69811af3bbbeb7484136e0ef4673e76fac158a716")

