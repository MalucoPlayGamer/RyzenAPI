-- Lua provided by RyzenAPI 
-- Game: Marauder
addappid(289600)
addappid(289601, 1, "886fa9168dd7e4db59e7674992252732e7d55b58094aa7fd95873138d53a2117")
addappid(289602, 1, "cc99b42910645332fe7ffec69811af3bbbeb7484136e0ef4673e76fac158a716")
