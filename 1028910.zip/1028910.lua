-- Lua provided by RyzenAPI
-- Game: Game: AppID 1028910

-- MAIN APPLICATION
addappid(1028910)
-- Game: addappid(1028910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028911, 1, "5a816be8dce811c4a90f985803ac7489d173c096d9a611199112cab38165550c")
