-- Lua provided by RyzenAPI
-- Game: Sparkle 4 Tales

-- MAIN APPLICATION
addappid(1028910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1028911, 1, "5a816be8dce811c4a90f985803ac7489d173c096d9a611199112cab38165550c")

