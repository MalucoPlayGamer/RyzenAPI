-- Lua provided by RyzenAPI
-- Game: Game: AppID 601130

-- MAIN APPLICATION
addappid(601130)
-- Game: addappid(601130)

-- MAIN APP DEPOTS / PACKAGES
addappid(601131, 1, "f166b1267f997e22363a1377e406ec85523dda9e7597267af0f6e18e421afa89")
addappid(601132, 1, "bacfdd3d36217924d1c350eadb53a17ef4a68a6ae63b50ea3c42b02197622713")
