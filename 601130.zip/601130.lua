-- Lua provided by RyzenAPI 
-- Game: AppID 601130
addappid(601130)
addappid(601131, 1, "f166b1267f997e22363a1377e406ec85523dda9e7597267af0f6e18e421afa89")
addappid(601132, 1, "bacfdd3d36217924d1c350eadb53a17ef4a68a6ae63b50ea3c42b02197622713")
