-- Lua provided by RyzenAPI
-- Game: addappid(1655350)

-- MAIN APPLICATION
addappid(1655350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655351, 1, "0d8ebe1451eb8b375c32d9f085caa7efd942e6a493447ad2c5ef64ca0a828fa1")
