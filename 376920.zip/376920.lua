-- Lua provided by RyzenAPI
-- Game: addappid(376920)

-- MAIN APPLICATION
addappid(376920)

-- MAIN APP DEPOTS / PACKAGES
addappid(376921, 1, "5b75dcb3b51671edf2e85824d2dbcafb3ce8be405f8cc725a589e85b29c62615")
addappid(376922, 1, "8a0865fae6111fccc82617c8a7aa04caf3bec861367138419684ada0e32ad325")
addappid(376923, 1, "4ddb16b3f941d3821bd9723615e4c1b93dd607f41f0e13efd30a74cdb38c8c54")
