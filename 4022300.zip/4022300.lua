-- Lua provided by RyzenAPI
-- Game: DateBoy

-- MAIN APPLICATION
addappid(4022300)
