-- 4808280's Lua and Manifest Created by Hubcap Manifest
-- Toll Plaza Simulator
-- Created: July 21, 2026 at 06:17:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4808280) -- Toll Plaza Simulator
-- MAIN APP DEPOTS
addappid(4808281, 1, "865dc142073be3d0c0078625921cdb9c232ff67baba24947c81533d43ff17414") -- Depot 4808281
setManifestid(4808281, "6832053861026224939", 661006012)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)