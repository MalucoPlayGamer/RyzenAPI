-- Lua provided by RyzenAPI
-- Game: Xi

-- MAIN APPLICATION
addappid(3432160)
-- Game: addappid(3432160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432161, 1, "26325d312f43f98b24c81286dcdb81267c0655cae533592259b791c2d5809d42")
