-- Lua provided by SkyAPI 
-- Game: Xi
addappid(3432160)
addappid(3432161, 1, "26325d312f43f98b24c81286dcdb81267c0655cae533592259b791c2d5809d42")
