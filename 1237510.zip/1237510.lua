-- Lua provided by RyzenAPI
-- Game: Dr Livingstone, I Presume? Reversed Escape Room

-- MAIN APPLICATION
addappid(1237510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237511, 1, "5900b2653011c2c301f470be292934c21eb74e5bf04871b5af57c10818b1f022")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1640620)
