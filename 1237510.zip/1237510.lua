-- Lua provided by RyzenAPI
-- Game: Dr Livingstone, I Presume? Reversed Escape Room

-- MAIN APPLICATION
addappid(1237510)
-- Game: addappid(1237510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237511, 1, "5900b2653011c2c301f470be292934c21eb74e5bf04871b5af57c10818b1f022")
