-- Lua provided by RyzenAPI
-- Game: 1428: Shadows over Silesia

-- MAIN APPLICATION
addappid(1228500)
addappid(2161820)
addappid(2843010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228501, 1, "9bc230b26e0d5abce0139b63c115640aabde8dc6c2f123bdddc815d8e19acecd")