-- Lua provided by RyzenAPI
-- Game: Game: AppID 382570

-- MAIN APPLICATION
addappid(382570)
-- Game: addappid(382570)

-- MAIN APP DEPOTS / PACKAGES
addappid(382571, 1, "149f3f63064e1a7fe3b68d53dcb8ad561a8c3636af84991f331924c26edba8f7")
