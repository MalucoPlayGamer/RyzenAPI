-- Lua provided by RyzenAPI
-- Game: AppID 70620

-- MAIN APPLICATION
addappid(70620)

-- MAIN APP DEPOTS / PACKAGES
addappid(70621, 1, "913dc81565808c228c4f0c9e3a6f2951b30334e3b24a0ea4ad324ee91c5f0aa6")
addappid(70622, 1, "bcdd5ba9529161cb3fa1e178962ced028033e50df872f9f6f70db646d33bfd9f")
