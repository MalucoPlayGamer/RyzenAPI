-- Lua provided by RyzenAPI
-- Game: 3481910

-- MAIN APPLICATION
addappid(3481910)
-- Game: addappid(3481910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3481912,0,"ffc10743e8f916897d6ec3e7460cc2dea35912d7d23040ac724cc5fbc67bd825")
