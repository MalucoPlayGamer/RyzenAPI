-- Lua provided by RyzenAPI 
-- Game: Neptunia Riders VS Dogoos
addappid(3273290)
addappid(3273291, 1, "a43c60737f3eab0157a4dd82e7edae2224d1b0a494bb59ec311b28ea58838f66")
addappid(3341530, 0, "4d90ae31ed1084894b2d915668a6b691cbbf236881522a46f40d09b0caf5be0c")
addappid(3341540, 0, "d58483f06d2098073771bdbd615e8178da01df911e37530a2c3f4766c484e7e3")
