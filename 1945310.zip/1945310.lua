-- Lua provided by RyzenAPI 
-- Game: Oceans
addappid(1945310)
addappid(1945311, 1, "6b799f55d20fa046bfbc9b3b7f1acf45b5862f308b8fc82423496a40a548161d")
addappid(1945312, 1, "abb07fdd1e46a3e9a63d3a76676e3424577761f2ddff347655956629541ca1b9")
