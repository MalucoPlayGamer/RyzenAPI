-- Lua provided by RyzenAPI
-- Game: addappid(2324760)

-- MAIN APPLICATION
addappid(2324760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324761, 1, "dbccba0d0c7cd214085c287f293e4a18cfe179633d52fd858357018a19369a45")
