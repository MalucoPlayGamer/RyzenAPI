-- Lua provided by RyzenAPI
-- Game: Short Life

-- MAIN APPLICATION
addappid(893570)

-- MAIN APP DEPOTS / PACKAGES
addappid(893571, 1, "df7b8115f25c59b7d9f7c67481a42cb78ba745a67a04c0a6df6edee036c34a89")
