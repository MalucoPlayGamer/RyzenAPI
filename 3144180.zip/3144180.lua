-- Lua provided by RyzenAPI
-- Game: addappid(3144180)

-- MAIN APPLICATION
addappid(3144180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144181, 1, "816d7b201ca16adabd8469b0ba9436dd44d0f62cb3f059869fde67c268c01611")
