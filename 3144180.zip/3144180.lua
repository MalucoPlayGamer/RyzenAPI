-- Lua provided by RyzenAPI 
-- Game: Scarlet's Haunted Hotel
addappid(3144180)
addappid(3144181, 1, "816d7b201ca16adabd8469b0ba9436dd44d0f62cb3f059869fde67c268c01611")
