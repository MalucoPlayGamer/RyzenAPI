-- Lua provided by RyzenAPI 
-- Game: AppID 2428710
addappid(2428710)
addappid(2428711, 1, "4e65f9e42f847d65b5d0c22f96939a2aeed7a551f53e0425f87aad859156d97d")
