-- Lua provided by RyzenAPI
-- Game: Flight League Series

-- MAIN APPLICATION
addappid(1207020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207021, 1, "ddef2bc37e229a6232ac9f35a4c55a489a3341c142d3a4c81883ab793f680fa9")
