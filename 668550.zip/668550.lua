-- Lua provided by RyzenAPI
-- Game: AppID 668550

-- MAIN APPLICATION
addappid(668550)

-- MAIN APP DEPOTS / PACKAGES
addappid(668551, 1, "7ebdd4d951856d8b86c630d21d781b75c846bd487c6c1daa432e347b39a621f2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1704110)
