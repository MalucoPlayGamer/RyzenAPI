-- Lua provided by RyzenAPI
-- Game: Dungeon Survivors

-- MAIN APPLICATION
addappid(2336730)
-- Game: addappid(2336730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336731, 1, "e4eb0522706792316dfd5f6c76938d0171b4b71d41f1f0a59ac5ab9e3d4e3381")
