-- Lua provided by SkyAPI 
-- Game: Dungeon Survivors
addappid(2336730)
addappid(2336731, 1, "e4eb0522706792316dfd5f6c76938d0171b4b71d41f1f0a59ac5ab9e3d4e3381")
