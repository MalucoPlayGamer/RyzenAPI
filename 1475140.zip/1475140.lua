-- Lua provided by RyzenAPI
-- Game: Green Marquis

-- MAIN APPLICATION
addappid(1475140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475141, 1, "e196e0e24bab5cfc1a2e4e43a9357f3ff4d69327f055e4c57697dd5e13492a43")

