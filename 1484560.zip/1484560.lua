-- Lua provided by RyzenAPI
-- Game: Ecchi Spirit

-- MAIN APPLICATION
addappid(1484560)
-- Game: addappid(1484560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484561, 1, "a8713ce14dfa3cdb8ae83f964f0a9950110805f70e416974746dc54ade586ab7")
