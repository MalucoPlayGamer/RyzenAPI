-- Lua provided by RyzenAPI
-- Game: Tonight, I Die in My Sleep

-- MAIN APPLICATION
addappid(2479170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479171, 1, "f9eb869d58d890e80244a744216997b2745b0b0adcc673aeb969df6d5197fef6")

