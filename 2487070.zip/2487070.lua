-- Lua provided by RyzenAPI
-- Game: Game: Anonymous Hacker Simulator: Prologue

-- MAIN APPLICATION
addappid(2487070)
-- Game: addappid(2487070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487071, 1, "0fca9cb28044858a3c05f4856f394909133ef7dc83937816673823f9e3f23769")
