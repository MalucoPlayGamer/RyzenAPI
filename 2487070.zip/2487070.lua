-- Lua provided by RyzenAPI
-- Game: Anonymous Hacker Simulator: Prologue

-- MAIN APPLICATION
addappid(2487070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487071, 1, "0fca9cb28044858a3c05f4856f394909133ef7dc83937816673823f9e3f23769")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
