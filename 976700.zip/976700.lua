-- Lua provided by RyzenAPI
-- Game: 976700

-- MAIN APPLICATION
addappid(976700)
-- Game: addappid(976700)

-- MAIN APP DEPOTS / PACKAGES
addappid(976701, 1, "9992574e6306543c9e2038ff9ed81758adef078d7743f1419a38e18a93067fce")
