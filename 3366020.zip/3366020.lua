-- Lua provided by RyzenAPI
-- Game: Game: LIMINAL SHIFT Demo

-- MAIN APPLICATION
addappid(3366020)
-- Game: addappid(3366020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3366021, 1, "f3d22b70d56b30b2e78318855f6c1bb24b205762fe18409d696bf51b12b6d9e1")
