-- Lua provided by RyzenAPI
-- Game: Kevurah Demo

-- MAIN APPLICATION
addappid(3004320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004321, 1, "6fe7a69a4cd46656df6fb1340f2354d812ae20a9fd61fe6340cd2dc4de6d30b8")
