-- Lua provided by SkyAPI 
-- Game: Hot Mom
addappid(2135640)
addappid(2135641, 1, "741b8a5930d0ab5e5fff0efac71c4d663cb256228319256423c757c8e2dadbbd")
