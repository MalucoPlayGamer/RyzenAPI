-- Lua provided by RyzenAPI
-- Game: 2135640

-- MAIN APPLICATION
addappid(2135640)
-- Game: addappid(2135640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135641, 1, "741b8a5930d0ab5e5fff0efac71c4d663cb256228319256423c757c8e2dadbbd")
