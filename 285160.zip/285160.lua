-- Lua provided by RyzenAPI
-- Game: LEGO® The Hobbit™

-- MAIN APPLICATION
addappid(285160)

-- MAIN APP DEPOTS / PACKAGES
addappid(285161, 1, "4135d51d7feab5c9486308c898045892514450bfceffc9cf366b1c37dfceb5ca")
addappid(285162, 1, "36d69764a808709db72a72a597867ba3cea57d05b21991a4b97e44fb5636807f")
addappid(292710, 0, "97849e45cf4fc1b5f410f52b05fb9184db288e1a4868847b4d87c537a6568e55")
addappid(292711, 0, "c2e5b9a384de141a6d83e35ea0f412275c1248582010345ce3efec5340a7c9aa")
addappid(292712, 0, "4adda7e7d7fec70194b674e56dcfba0ac942bcc63feb57541ff2193e2588df7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
