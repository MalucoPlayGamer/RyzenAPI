-- Lua provided by RyzenAPI
-- Game: 603390

-- MAIN APPLICATION
addappid(603390)
-- Game: addappid(603390)

-- MAIN APP DEPOTS / PACKAGES
addappid(603391, 1, "b6d8b7d51b36e87e46b9d9be8def3215c8bee8ec7671ea51ad0118adb22b9cce")
addappid(603392, 1, "ff379050d5c8b734daf2792433e292569359c1dfae97471db8403ee5735433e2")
addappid(603393, 1, "9b28681be2a7af236c8c52763cb81baa98ca5a83bff6b4c176998e692c1eb3d6")
addappid(1122790, 0, "f01819c5e6dfe2de05e04e4836c47dabef53643aecca9c1790d06a1dd87abf23")
