-- Lua provided by RyzenAPI
-- Game: AppID 620080

-- MAIN APPLICATION
addappid(620080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(620081, 1, "2185db318e37c3d71fd2d67b2463454bd11994981eb62ad468fa41683d7b2b78")

