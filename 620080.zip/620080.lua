-- Lua provided by RyzenAPI
-- Game: 620080

-- MAIN APPLICATION
addappid(620080)
-- Game: addappid(620080)

-- MAIN APP DEPOTS / PACKAGES
addappid(620081, 1, "2185db318e37c3d71fd2d67b2463454bd11994981eb62ad468fa41683d7b2b78")
