-- Lua provided by RyzenAPI
-- Game: 3320360

-- MAIN APPLICATION
addappid(3320360)
-- Game: addappid(3320360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320361, 1, "307b97d5c33bf6fb8ffad7d967d13b1a7b59971c7fcd15ef03a577ad7d487546")
