-- Lua provided by SkyAPI 
-- Game: AppID 1640930
addappid(1640930)
addappid(1640931, 1, "7925c691c601635f0a6c69c63580c25cf66bdcc939f75a6262d472e79b723312")
