-- Lua provided by RyzenAPI
-- Game: Triton Survival

-- MAIN APPLICATION
addappid(1013450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013451, 1, "42fbb208cf03ae470aecdd1a3f3924898088867510d17791731927de051674e5")
