-- Lua provided by RyzenAPI
-- Game: Little People

-- MAIN APPLICATION
addappid(708480)

-- MAIN APP DEPOTS / PACKAGES
addappid(708481, 1, "495c732c8a6a303efb36eb58d3d29e51864930c9d4df971e21bdbc7cecfa871a")

