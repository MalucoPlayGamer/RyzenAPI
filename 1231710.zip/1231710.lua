-- Lua provided by RyzenAPI
-- Game: Super Foosball

-- MAIN APPLICATION
addappid(1231710)
-- Game: addappid(1231710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231711, 1, "8a32dfbfb223e583299778ae9a81c822f2f63f1943ab480bd2ab71afadd522b6")
