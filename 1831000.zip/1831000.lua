-- Lua provided by RyzenAPI
-- Game: addappid(1831000)

-- MAIN APPLICATION
addappid(1831000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831001, 1, "b13a4f871efa7e5b4676ddd3b206ab0e2cb47f08f4d2ffd36e4866178c7a0489")
