-- Lua provided by RyzenAPI
-- Game: Neverwinter Nights: Enhanced Edition

-- MAIN APPLICATION
addappid(704450)

-- MAIN APP DEPOTS / PACKAGES
addappid(704451, 1, "6388979da7318474e9077d55932633daf30b2a4cae9391452ad9ce830b87648f")
addappid(704452, 1, "4f650135f432e3174abe1d3cca1d0345ea071d0ae2151f696b7901e2b662220c")
addappid(704453, 1, "f1fa224c2429aec8cae99633b59f56de42bacfd48488e45490de966ee55c7d2c")
addappid(704454, 1, "968b1c54f7c0376d75ce4fac3cb41dfdb602566a2265c671f0f179fbb15a2ec0")
addappid(737000, 0, "fbc6c3255789539f96e30309af296fd4c6e95f8f15a4929dfbb05dbc6d16e519")
addappid(737001, 0, "9ab987e4728d7bf2ba8425d05b7349e9c3e00fbcfda583b566e42c7e7ce2debc")
addappid(737002, 0, "62ff68c5cdb3c42604fb31ff7c2a00018ab467a2fc11a4ba0d88f0a987c4d77b")
addappid(744680, 0, "c26b3a6243c14d114c2de3fbc4e65598f4283027d3dfe2ca141b69d0c0d40857")
addappid(854960, 0, "8d7b71a9f5098a2d076c659e409abab23a8680da29672514213d819e15930fd9")
addappid(1143400, 0, "1471ce64984fbdca241ae192be42de5aacc240c1330d71304ad9ea871260f64e")
addappid(1247750, 0, "ec95193131d2b073b33d8cc9628e38984e6d8773c82fc6f9f20f3fa86e9af7a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3093340)
