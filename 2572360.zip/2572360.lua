-- Lua provided by RyzenAPI
-- Game: Game: InOutPath

-- MAIN APPLICATION
addappid(2572360)
-- Game: addappid(2572360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572361, 1, "89618c1b64c423fa9740ed797258e1d617912317688636862e7fec280432a86a")
