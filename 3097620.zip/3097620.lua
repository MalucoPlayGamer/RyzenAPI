-- Lua provided by RyzenAPI
-- Game: Game: Valis III

-- MAIN APPLICATION
addappid(3097620)
-- Game: addappid(3097620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097621, 1, "72bb808d4ed5d240955fc5a56e3bc0fa6b564b0a07219444cc4d9649e445f028")
