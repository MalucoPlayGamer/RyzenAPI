-- Lua provided by RyzenAPI
-- Game: Orbital Bullet

-- MAIN APPLICATION
addappid(1167680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167681, 1, "dc0b3e9ed4721c6021fde75fed36862324e101a7d0c33900818a4af8b58c6753")

