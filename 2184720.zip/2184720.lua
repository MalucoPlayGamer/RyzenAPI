-- Lua provided by RyzenAPI
-- Game: AppID 2184720

-- MAIN APPLICATION
addappid(2184720)
-- Game: addappid(2184720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184721, 1, "0b90abfcfd9fcb02d9197ca7fc5321955c2c9ea95345ababb81972d3d1f86f4d")
