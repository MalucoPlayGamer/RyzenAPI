-- Lua provided by RyzenAPI
-- Game: Onde Demo

-- MAIN APPLICATION
addappid(1721370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721371, 1, "9f972bab0966894214d220e983e5fac0ae129606cdbb87da478d6abd5ae58186")
