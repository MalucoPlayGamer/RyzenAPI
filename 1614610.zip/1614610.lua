-- Lua provided by RyzenAPI
-- Game: addappid(1614610)

-- MAIN APPLICATION
addappid(1614610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614611, 1, "b9066e040fb19f1c66e8452f590176d21dac493fc0894e9a9ee7bf54913734f6")
