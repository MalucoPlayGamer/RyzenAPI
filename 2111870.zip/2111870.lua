-- Lua provided by RyzenAPI
-- Game: Section 13

-- MAIN APPLICATION
addappid(2111870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111871, 1, "d34401529ac856c033c5910de719c8b7cf01c5aa2d54f5c5ea943d6c744f31d5")

