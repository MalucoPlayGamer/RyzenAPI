-- Lua provided by RyzenAPI
-- Game: Project Entropy

-- MAIN APPLICATION
addappid(2806410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806411, 1, "f49fb1305b2e3faada3755afa4726e2dfbb293cc3cbf4a7b1ba4b7df00a24478")
