-- 4331130's Lua and Manifest Created by Hubcap Manifest
-- Abyss Horde
-- Created: August 01, 2026 at 02:22:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4331130) -- Abyss Horde
-- MAIN APP DEPOTS
addappid(4331131, 1, "edb5169805abcd9a21ff15aec919c8853824d2ba988601f4c07da2f959c1ef85") -- Depot 4331131
setManifestid(4331131, "1700501490669623695", 264173680)