-- Lua provided by RyzenAPI
-- Game: Abyss Horde

-- MAIN APPLICATION
addappid(4331130) -- Abyss Horde

-- MAIN APP DEPOTS / PACKAGES
addappid(4331131, 1, "edb5169805abcd9a21ff15aec919c8853824d2ba988601f4c07da2f959c1ef85") -- Depot 4331131

