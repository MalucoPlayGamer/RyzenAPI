-- Lua provided by RyzenAPI
-- Game: Game: Soldiers Lost Forever (1914-1918)

-- MAIN APPLICATION
addappid(508630)
-- Game: addappid(508630)

-- MAIN APP DEPOTS / PACKAGES
addappid(508631, 1, "2fa162a739cd9b7df164d9201009a66d7f978eeb749649b19c8956a204050e82")
