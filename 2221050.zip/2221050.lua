-- Lua provided by SkyAPI 
-- Game: Neanderthallica
addappid(2221050)
addappid(2221051, 1, "9d30ce907b9e8d4ff8c34ab6d8757adc8d1a205d70051e9e591e0cd75cc46a75")
