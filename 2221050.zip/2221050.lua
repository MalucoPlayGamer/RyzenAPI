-- Lua provided by RyzenAPI
-- Game: Neanderthallica

-- MAIN APPLICATION
addappid(2221050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221051, 1, "9d30ce907b9e8d4ff8c34ab6d8757adc8d1a205d70051e9e591e0cd75cc46a75")

