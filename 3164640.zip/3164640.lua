-- Lua provided by RyzenAPI
-- Game: Days In Palis

-- MAIN APPLICATION
addappid(3164640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164641, 1, "e8110420e1f1bf532420da54f98179d0cf76a2ae67e120ec6f303e16b772c4e7")
