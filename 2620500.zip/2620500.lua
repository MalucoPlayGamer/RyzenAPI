-- Lua provided by RyzenAPI
-- Game: 2620500

-- MAIN APPLICATION
addappid(2620500)
-- Game: addappid(2620500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620501, 1, "e1e8cbe08a010f6ee1e15f7fa99d2cbe056ff2bbe88bb5b13e41f0fa3c727279")
