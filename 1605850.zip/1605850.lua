-- Lua provided by RyzenAPI
-- Game: ZeroSpace

-- MAIN APPLICATION
addappid(1605850) -- ZeroSpace
-- addappid(1605858) -- Depot 1605858 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1605851, 1, "01d517fcedbc210e4bb21f726c5434f768b84bb41840ec0a48d293677a4f6810") -- Depot 1605851

