-- 1605850's Lua and Manifest Created by Hubcap Manifest
-- ZeroSpace
-- Created: July 21, 2026 at 14:55:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1605850) -- ZeroSpace
-- MAIN APP DEPOTS
addappid(1605851, 1, "01d517fcedbc210e4bb21f726c5434f768b84bb41840ec0a48d293677a4f6810") -- Depot 1605851
setManifestid(1605851, "1525737124291251728", 52682959984)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1605858) -- Depot 1605858 (empty depot)