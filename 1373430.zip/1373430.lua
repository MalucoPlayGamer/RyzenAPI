-- Lua provided by SkyAPI 
-- Game: Leisure Suit Larry - Wet Dreams Dry Twice
addappid(1373430)
addappid(1373431, 1, "d048ee696d2631f06f49a38ca25ce1a58c70c012e9fd8b60998e3b0dbecd7303")
addappid(1373432, 1, "93b6e63fda49ca7b4ec581137bd5cb19082f83a5ce23a75bae6b954327fed0ba")
