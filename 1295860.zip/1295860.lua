-- Lua provided by RyzenAPI
-- Game: Rip Them Off

-- MAIN APPLICATION
addappid(1295860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295861, 1, "7903f0bc107e139011590deaf3b4e2b30cade95c99f4088883f35f537c2b0479")
