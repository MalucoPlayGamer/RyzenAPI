-- Lua provided by RyzenAPI
-- Game: Parallel

-- MAIN APPLICATION
addappid(1388350)
-- Game: addappid(1388350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388351, 1, "0d6774b258512d82d3097115d3e570a37ea72f7f194518e96c740aadef7748c9")
