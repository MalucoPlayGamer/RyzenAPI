-- Lua provided by RyzenAPI
-- Game: Parallel

-- MAIN APPLICATION
addappid(1388350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388351, 1, "0d6774b258512d82d3097115d3e570a37ea72f7f194518e96c740aadef7748c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
