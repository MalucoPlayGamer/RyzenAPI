-- Lua provided by RyzenAPI
-- Game: Fayburrow

-- MAIN APPLICATION
addappid(1873860)
-- Game: addappid(1873860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873861, 1, "e1a143bb76e8ce8593cf9a32f9d984dbf33a952048e27450855d1dd640899f63")
