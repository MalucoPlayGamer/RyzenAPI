-- Lua provided by RyzenAPI
-- Game: Abalon: Roguelike Tactics CCG

-- MAIN APPLICATION
addappid(1681840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681841, 1, "f734204772051d5543bbb8fc223d71d772a47e527a879e79fbd9649d86133557")
addappid(1681842, 1, "cf78b5e1fb7164a7544a3d4e6cd31a0fd99474dfbba8a8af1c2fcc59bdd5162f")
addappid(1681843, 1, "cee0a1e17be8f26819d76ca4da8633ff49efc5c0455a9694dc9997ecf4b5f292")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3998420)
