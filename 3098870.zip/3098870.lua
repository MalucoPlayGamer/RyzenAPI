-- Lua provided by RyzenAPI
-- Game: addappid(3098870)

-- MAIN APPLICATION
addappid(3098870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098871, 1, "3a2863935901c21199e175fc6c6c20030ab9623f9aaf3d698953a3ed0a66d5ef")
