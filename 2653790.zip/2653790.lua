-- Lua provided by RyzenAPI
-- Game: Game: The Exit 8

-- MAIN APPLICATION
addappid(2653790)
-- Game: addappid(2653790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653791, 1, "057987e441949d496886cc38feefea453a2863c2ee7f4afbf010230d6bd89372")
