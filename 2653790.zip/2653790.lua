-- Lua provided by RyzenAPI
-- Game: The Exit 8

-- MAIN APPLICATION
addappid(2653790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653791, 1, "057987e441949d496886cc38feefea453a2863c2ee7f4afbf010230d6bd89372")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
