-- Lua provided by RyzenAPI
-- Game: The Mystery Of Woolley Mountain  - Art Book

-- MAIN APPLICATION
addappid(1264780)
addappid(1264781)
-- Game: addappid(1264780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264780,0,"e5224bc077dc336f27ca99e87c659d704ec5eef9bce5b9366602d962a0d25c38")
