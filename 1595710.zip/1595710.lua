-- Lua provided by RyzenAPI
-- Game: 1595710

-- MAIN APPLICATION
addappid(1595710)
-- Game: addappid(1595710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595711, 1, "e623d4b49a1d8863b35ff0084ac5a201b5cb7f99649c23660e5ff15130951fd8")
