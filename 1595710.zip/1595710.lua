-- Lua provided by RyzenAPI
-- Game: Chased by Darkness

-- MAIN APPLICATION
addappid(1595710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595711, 1, "e623d4b49a1d8863b35ff0084ac5a201b5cb7f99649c23660e5ff15130951fd8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
