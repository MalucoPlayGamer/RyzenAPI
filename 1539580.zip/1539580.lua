-- Lua provided by RyzenAPI
-- Game: AppID 1539580

-- MAIN APPLICATION
addappid(1539580)
-- Game: addappid(1539580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539581, 1, "7cb52f50526c0dab1f0c15a09f08e7b35b99b0ff40307b567d9fd0448c32f373")
