-- Lua provided by RyzenAPI
-- Game: Game: DARTHY

-- MAIN APPLICATION
addappid(404850)
-- Game: addappid(404850)

-- MAIN APP DEPOTS / PACKAGES
addappid(404851, 1, "2fa2bbc8df778f977c47d43fee797bec6ce108c0cc87ccea3390d5a6701634b7")
