-- Lua provided by RyzenAPI
-- Game: DARTHY

-- MAIN APPLICATION
addappid(404850)

-- MAIN APP DEPOTS / PACKAGES
addappid(404851, 1, "2fa2bbc8df778f977c47d43fee797bec6ce108c0cc87ccea3390d5a6701634b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
