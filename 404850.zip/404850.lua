-- Lua provided by RyzenAPI 
-- Game: DARTHY
addappid(404850)
addappid(404851, 1, "2fa2bbc8df778f977c47d43fee797bec6ce108c0cc87ccea3390d5a6701634b7")
