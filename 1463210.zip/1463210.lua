-- Lua provided by RyzenAPI
-- Game: AppID 1463210

-- MAIN APPLICATION
addappid(1463210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463211, 1, "fca2c0441d07596e93eae17fceb5851b611c7ad30b7bf054c7ba2b37cea1b853")

