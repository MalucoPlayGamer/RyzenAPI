-- Lua provided by RyzenAPI
-- Game: Key Fairy

-- MAIN APPLICATION
addappid(2878580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878581,0,"0681e5f9a292f2bde56296d7a3c061e5b739cf87cfb0a01bf852a602cd505810")

