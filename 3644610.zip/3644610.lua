-- Lua provided by RyzenAPI
-- Game: My Summer Vacation

-- MAIN APPLICATION
addappid(3644610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3644611,0,"cb1ef4d1bef4f924c4d27d0839afb4e289aaceab483efb7c812bbda8737cea0a")
addappid(3644612,0,"5d6cebc60a84b45a1f34ac9ca6c3f2e9be3917cb4d8181b4ef80c8e34829db84")
addappid(3644613,0,"c8aad02525fd07d5a7cd89efbdd53ca0fc86c31b6ece9a66ffa03339ef5cc4e6")
addappid(3644614,0,"230aa922026e7703fd5f5cb7bba3eae4b42cda4dec51b7e285e679bc23a4d529")

