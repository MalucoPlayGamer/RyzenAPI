-- Lua provided by RyzenAPI
-- Game: addappid(1282090)

-- MAIN APPLICATION
addappid(1282090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282091, 1, "7cfd67e2aa8539de2bcb68792522ca5f7a7667c23534f0b909c20e9b1f6f7bb8")
