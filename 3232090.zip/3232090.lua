-- Lua provided by SkyAPI 
-- Game: Forge of the Fae Demo
addappid(3232090)
addappid(3232091, 1, "8e7683c128a74adcae74d14d282f9acd9da9794dd1f51d592609462d91e286d4")
