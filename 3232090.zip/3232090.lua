-- Lua provided by RyzenAPI
-- Game: 3232090

-- MAIN APPLICATION
addappid(3232090)
-- Game: addappid(3232090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232091, 1, "8e7683c128a74adcae74d14d282f9acd9da9794dd1f51d592609462d91e286d4")
