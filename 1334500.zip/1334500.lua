-- Lua provided by RyzenAPI
-- Game: RP7: Spin Your Own Encounter

-- MAIN APPLICATION
addappid(1334500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334501, 1, "70a46b4d52c61e8bc9730fc5c7021ae98d65ceb3e30adb437e678e0fee063075")
