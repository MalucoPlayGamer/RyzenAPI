-- Lua provided by RyzenAPI
-- Game: RP7: Spin Your Own Encounter

-- MAIN APPLICATION
addappid(1334500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334501, 1, "70a46b4d52c61e8bc9730fc5c7021ae98d65ceb3e30adb437e678e0fee063075")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
