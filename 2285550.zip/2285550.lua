-- Lua provided by RyzenAPI
-- Game: addappid(2285550)

-- MAIN APPLICATION
addappid(2285550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285551, 1, "afe8a5179c5f8472cac3ca41c6b35eab7bb08d22b24bb4c034c74a1a02bd8d12")
