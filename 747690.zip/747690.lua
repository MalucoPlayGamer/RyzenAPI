-- Lua provided by RyzenAPI
-- Game: Sinister Halloween

-- MAIN APPLICATION
addappid(747690)

-- MAIN APP DEPOTS / PACKAGES
addappid(747691, 1, "a5180048c7df025b22103c2ea38cc8da5ae10827a2cb3d06c9994edfe6880bd8")
addappid(1453070, 0, "fe79b0ff6fae08bfb10f667351c1cca65654cee49c5396af0013bdb1cd82ac84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
