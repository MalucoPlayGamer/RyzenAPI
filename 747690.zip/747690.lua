-- Lua provided by SkyAPI 
-- Game: Sinister Halloween
addappid(747690)
addappid(747691, 1, "a5180048c7df025b22103c2ea38cc8da5ae10827a2cb3d06c9994edfe6880bd8")
addappid(1453070, 0, "fe79b0ff6fae08bfb10f667351c1cca65654cee49c5396af0013bdb1cd82ac84")
