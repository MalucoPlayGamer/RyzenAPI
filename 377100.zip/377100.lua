-- Lua provided by RyzenAPI
-- Game: Game: AppID 377100

-- MAIN APPLICATION
addappid(377100)
-- Game: addappid(377100)

-- MAIN APP DEPOTS / PACKAGES
addappid(377101, 1, "1c76b73835bb6b1a6a042688cbe469614568ffefc0ccb192ad6ee655867b9eff")
addappid(377102, 1, "1c89aa8b1c80c336d137e435a03f9dba9c74da2ba902f130aac2d09a9552ea56")
