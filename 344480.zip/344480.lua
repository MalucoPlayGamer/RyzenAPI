-- Lua provided by RyzenAPI
-- Game: Quell

-- MAIN APPLICATION
addappid(344480)

-- MAIN APP DEPOTS / PACKAGES
addappid(344481, 1, "ebd49ae40f7419da3d4555fae9de1b349dc50eec9d2b4b4106db67ad55d2fe39")

