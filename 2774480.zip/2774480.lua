-- Lua provided by RyzenAPI
-- Game: Game: Tenno

-- MAIN APPLICATION
addappid(2774480)
-- Game: addappid(2774480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774481, 1, "013330d2d725b6cb38aa5c6d1041158821bc27a598990dc4b046e64ad4394f20")
