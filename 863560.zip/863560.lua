-- Lua provided by RyzenAPI
-- Game: 863560

-- MAIN APPLICATION
addappid(863560)
addappid(865620)
-- Game: addappid(863560)

-- MAIN APP DEPOTS / PACKAGES
addappid(863561, 1, "b14a931d47e7243adf6c83b505f0b6ba2739971c92e1d3348dc71c54f841c485")
