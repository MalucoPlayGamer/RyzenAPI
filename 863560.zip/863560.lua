-- Lua provided by RyzenAPI
-- Game: Slime CCG

-- MAIN APPLICATION
addappid(863560)
addappid(865620)

-- MAIN APP DEPOTS / PACKAGES
addappid(863561, 1, "b14a931d47e7243adf6c83b505f0b6ba2739971c92e1d3348dc71c54f841c485")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
