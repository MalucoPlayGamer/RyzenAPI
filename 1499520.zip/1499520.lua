-- Lua provided by RyzenAPI
-- Game: addappid(1499520)

-- MAIN APPLICATION
addappid(1499520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499521, 1, "e0cbe596f73219ff9d8f0ed322bb9fe7d1ca415cef6ed414018c904e5bbdeae3")
