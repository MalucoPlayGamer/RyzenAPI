-- Lua provided by RyzenAPI
-- Game: Liu Shan - Officer Ticket / 劉禅使用券

-- MAIN APPLICATION
addappid(956868)

-- MAIN APP DEPOTS / PACKAGES
addappid(956868,0,"c28f00b0b1ae615445563d1c8867a36a33acdd9df5428e3bc930f59dc012187c")

