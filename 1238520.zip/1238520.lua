-- Lua provided by RyzenAPI
-- Game: Game: AppID 1238520

-- MAIN APPLICATION
addappid(1238520)
-- Game: addappid(1238520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238521, 1, "535f2d599263c80fd172117d01f38219d12eac9d0efa2a51ba8c025da448009a")
