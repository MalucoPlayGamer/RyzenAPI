-- Lua provided by RyzenAPI
-- Game: RACE: Caterham Expansion

-- MAIN APPLICATION
addappid(4290)

-- MAIN APP DEPOTS / PACKAGES
addappid(4291, 1, "91bc8b4876b8ea340ff4727527c8b1dc3ea36f785036488303b08de1c552098a")

