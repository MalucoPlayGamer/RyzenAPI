-- Lua provided by RyzenAPI
-- Game: Myth of Empires

-- MAIN APPLICATION
addappid(1371580)
addappid(2817400)
addappid(2893560)
addappid(3042590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1371581, 1, "3dae7b26b55fcd654d6502a0c22fbea47703ffe9e46511d71053bfb5cc434800")
addappid(2817410, 0, "03ec0ad89e68879fa58390403c7482866c5342872b0b6655224e2f3e0068c498")
addappid(3502710, 0, "751565f18dbac7d972413bed39a518c3b47886422491f6058a2695f0f650ec64")

