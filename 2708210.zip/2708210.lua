-- Lua provided by RyzenAPI
-- Game: Game: Paradise

-- MAIN APPLICATION
addappid(2708210)
-- Game: addappid(2708210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708211, 1, "60f25259204055bed49fc21c2dbdca9909e9c52643c207c8473f03ec150041cd")
addappid(2708212, 1, "aaff04bdba74b401d413dfcc0e3b89237501d922cb7911ae822d4521d031875e")
