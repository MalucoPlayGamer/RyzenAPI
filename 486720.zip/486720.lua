-- Lua provided by RyzenAPI
-- Game: Bastard Bonds

-- MAIN APPLICATION
addappid(486720)

-- MAIN APP DEPOTS / PACKAGES
addappid(486721, 1, "19773ba55d4eead8b0e26fb68f371e4621a306470b282eb7fff2c08fb0dc9a3a")
