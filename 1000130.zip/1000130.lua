-- Lua provided by RyzenAPI
-- Game: Game: Cube Defender

-- MAIN APPLICATION
addappid(1000130)
-- Game: addappid(1000130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000131, 1, "9c5d499405571dace645a89d864e0dba8369efd98c4ba546ee11d66d44bd5a58")
