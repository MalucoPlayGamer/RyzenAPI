-- Lua provided by SkyAPI 
-- Game: Cube Defender
addappid(1000130)
addappid(1000131, 1, "9c5d499405571dace645a89d864e0dba8369efd98c4ba546ee11d66d44bd5a58")
