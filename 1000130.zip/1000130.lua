-- Lua provided by RyzenAPI
-- Game: Cube Defender

-- MAIN APPLICATION
addappid(1000130)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1000131, 1, "9c5d499405571dace645a89d864e0dba8369efd98c4ba546ee11d66d44bd5a58")

