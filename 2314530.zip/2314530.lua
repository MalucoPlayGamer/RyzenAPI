-- Lua provided by RyzenAPI
-- Game: Astraea

-- MAIN APPLICATION
addappid(2314530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314531, 1, "cf6003c5edca725e586ae6454c25ef844b735266733d76f75dbec53aeef2a7dc")

