-- Lua provided by RyzenAPI
-- Game: Rise of Adou

-- MAIN APPLICATION
addappid(3706510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3706511, 1, "e62146e97196ad62af599dafe348c1c02260e7338a645927c0b60fc16fa50a03")
