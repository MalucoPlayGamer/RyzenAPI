-- Lua provided by RyzenAPI
-- Game: 1432141

-- MAIN APPLICATION
addappid(1432141)
-- Game: addappid(1432141)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432141,0,"2886fad7ad7d47e909589a7c9b8dbb6807b2bf9868ca717ded21c9d3955c52c1")
