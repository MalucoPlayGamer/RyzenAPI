-- Lua provided by RyzenAPI
-- Game: 在一切晴朗的日子里｜On all clear days

-- MAIN APPLICATION
addappid(3127760)
-- Game: addappid(3127760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127761, 1, "ec0319899c9cfcda3bd540454fb2b06a54f9ace7139e21db19d3dbf4d0281cbc")
