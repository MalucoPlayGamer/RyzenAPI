-- Lua provided by RyzenAPI
-- Game: Last Day of Rome

-- MAIN APPLICATION
addappid(1015090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1015091, 1, "9ed34d4b75c62ce0b15c93629d3f38a85be7b3550cdad413c9e3da6acc4d5cec")
