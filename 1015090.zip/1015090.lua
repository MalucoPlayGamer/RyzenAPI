-- Lua provided by RyzenAPI
-- Game: AppID 1015090

-- MAIN APPLICATION
addappid(1015090)
-- Game: addappid(1015090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015091, 1, "9ed34d4b75c62ce0b15c93629d3f38a85be7b3550cdad413c9e3da6acc4d5cec")
