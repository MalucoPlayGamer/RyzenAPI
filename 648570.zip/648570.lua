-- Lua provided by RyzenAPI
-- Game: Hell Dimension VR

-- MAIN APPLICATION
addappid(648570)
-- Game: addappid(648570)

-- MAIN APP DEPOTS / PACKAGES
addappid(648571, 1, "86d6129ed42dcb92ec6b569f686005666be72a3e06eb1ada154fa95c351c811d")
