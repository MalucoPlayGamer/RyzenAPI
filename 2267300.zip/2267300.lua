-- Lua provided by RyzenAPI
-- Game: Game: AppID 2267300

-- MAIN APPLICATION
addappid(2267300)
-- Game: addappid(2267300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267301, 1, "7e69e5fef1e3ef4d667dee9b633a543f917397be2b3e5b9c0896d34c11a360fb")
