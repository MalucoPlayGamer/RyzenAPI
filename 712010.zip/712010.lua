-- Lua provided by SkyAPI 
-- Game: Chevo Lurker: Exodus
addappid(712010)
addappid(712011, 1, "ab27174582f8e112b416b49b4d1ce3f1b7dbfda501c7338cdc731dd50797f8e1")
