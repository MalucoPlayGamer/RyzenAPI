-- Lua provided by RyzenAPI
-- Game: addappid(803620)

-- MAIN APPLICATION
addappid(803620)

-- MAIN APP DEPOTS / PACKAGES
addappid(803621, 1, "c74f476cb54dd7d032a67cbfc25c71818e4cb3fb8f1afc18c7710f6ded862f62")
