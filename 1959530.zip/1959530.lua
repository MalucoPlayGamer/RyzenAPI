-- Lua provided by RyzenAPI
-- Game: Game: Extra Case: My Girlfriend's Secrets

-- MAIN APPLICATION
addappid(1959530)
-- Game: addappid(1959530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959531, 1, "7fbdff3a178bc6ba4abea5651145e36f82293ea3d7f5eaf20304934ae0014e25")
