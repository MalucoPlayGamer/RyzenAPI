-- Lua provided by RyzenAPI
-- Game: Game: Secret Agent

-- MAIN APPLICATION
addappid(2467540)
-- Game: addappid(2467540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467541, 1, "1194939e0bfe31710b0a1d24c06a6c9d5f53ee140227a2f87fffcff52bab23eb")
