-- Lua provided by RyzenAPI
-- Game: Depth

-- MAIN APPLICATION
addappid(274940)
-- Game: addappid(274940)

-- MAIN APP DEPOTS / PACKAGES
addappid(274941, 1, "b88a85a04f753010e90665ddd787a4ffc397df00d2b42ca9a4fb91ba188f65ce")
addappid(335640, 0, "cbf9e042ceccbb642129df3485d60db69b307428e2284e331d129b2efb2f9297")
addappid(423851, 0, "baf8759282b7213caea5d7edaa5334a8e3301f30dff6e19c4ff5b2d41446ef7e")
addappid(605240, 0, "fbbf0d1d478aef1e78c12bf38f3cfbf667a9685f0969d20622601d106ec51825")
