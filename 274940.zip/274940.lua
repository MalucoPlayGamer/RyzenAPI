-- Lua provided by RyzenAPI
-- Game: Depth

-- MAIN APPLICATION
addappid(274940)
addappid(322740)
addappid(361310)
addappid(361312)
addappid(361313)
addappid(361314)
addappid(370340)
addappid(370341)
addappid(384240)
addappid(392860)
addappid(413990)
addappid(413991)
addappid(414100)
addappid(414180)
addappid(418820)
addappid(423850)
addappid(423853)
addappid(456050)
addappid(728600)
addappid(815760)
addappid(850850)
addappid(1031940)
addappid(1386540)
addappid(1849220)

-- MAIN APP DEPOTS / PACKAGES
addappid(274940,0,"4760b943e129f92f4c34f68c3b28ae1c050d89d73806d2389e31619bd6b8501c")
addappid(274941,0,"b88a85a04f753010e90665ddd787a4ffc397df00d2b42ca9a4fb91ba188f65ce")
addappid(335640,0,"cbf9e042ceccbb642129df3485d60db69b307428e2284e331d129b2efb2f9297")
addappid(423851,0,"baf8759282b7213caea5d7edaa5334a8e3301f30dff6e19c4ff5b2d41446ef7e")
addappid(605240,0,"fbbf0d1d478aef1e78c12bf38f3cfbf667a9685f0969d20622601d106ec51825")

