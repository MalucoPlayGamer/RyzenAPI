-- Lua provided by RyzenAPI
-- Game: AppID 1075400

-- MAIN APPLICATION
addappid(1075400)
addappid(1179260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075401, 1, "207722fb189659c401fb525ed41cd08de07e39b7bd2c12bac69831ed342ebdc5")

