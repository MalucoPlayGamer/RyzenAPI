-- Lua provided by RyzenAPI
-- Game: Escape Room - Der kranke Kollege

-- MAIN APPLICATION
addappid(1301720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301721, 1, "e15c5fcffaf9da8ed7eba10b8fb52092c50d5282fdde85e6d18c87f8b6878324")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1943050)
addappid(1950660)
