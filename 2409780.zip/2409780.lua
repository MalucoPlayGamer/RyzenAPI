-- Lua provided by RyzenAPI
-- Game: 2409780

-- MAIN APPLICATION
addappid(2409780)
-- Game: addappid(2409780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409781, 1, "65720792d0c5ccc087188c5b45c2b6b8aa2ec5bdc4861d6cbe54c9fee4e82afa")
