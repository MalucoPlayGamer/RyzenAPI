-- Lua provided by RyzenAPI
-- Game: AppID 907840

-- MAIN APPLICATION
addappid(907840)

-- MAIN APP DEPOTS / PACKAGES
addappid(907841, 1, "881c03dc4e1aa311eaad225543c64f70b2c044d7f048a94709e6eed7cb503afb")
