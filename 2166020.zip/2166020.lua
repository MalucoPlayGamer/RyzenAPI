-- Lua provided by RyzenAPI 
-- Game: Hexworld
addappid(2166020)
addappid(2166021, 1, "73a632645a492105467430a8b915aab74c59f299345ebe73d224aeb60a764891")
