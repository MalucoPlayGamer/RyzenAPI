-- Lua provided by RyzenAPI
-- Game: Hexworld

-- MAIN APPLICATION
addappid(2166020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2166021, 1, "73a632645a492105467430a8b915aab74c59f299345ebe73d224aeb60a764891")

