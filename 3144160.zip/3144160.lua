-- Lua provided by RyzenAPI
-- Game: Game: Return To The Village

-- MAIN APPLICATION
addappid(3144160)
-- Game: addappid(3144160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144161, 1, "e1781e8f8616bb78b0efe22ef2d4105d7893c2903783addcd3835b31110f46f2")
