-- Lua provided by RyzenAPI
-- Game: Return To The Village

-- MAIN APPLICATION
addappid(3144160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144161, 1, "e1781e8f8616bb78b0efe22ef2d4105d7893c2903783addcd3835b31110f46f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
