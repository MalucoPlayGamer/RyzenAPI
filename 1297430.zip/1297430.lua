-- Lua provided by RyzenAPI
-- Game: Deadly Dozen Reloaded

-- MAIN APPLICATION
addappid(1297430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1297431, 1, "86450312bf8e1c9d8799c252d1b85c7b76056633d2676375a2a68e6e5050e32e")

