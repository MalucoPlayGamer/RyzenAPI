-- Lua provided by RyzenAPI
-- Game: Deadly Dozen Reloaded

-- MAIN APPLICATION
addappid(1297430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297431, 1, "86450312bf8e1c9d8799c252d1b85c7b76056633d2676375a2a68e6e5050e32e")
