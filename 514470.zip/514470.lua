-- Lua provided by RyzenAPI
-- Game: Game: Fantastic 4 In A Row 2

-- MAIN APPLICATION
addappid(514470)
-- Game: addappid(514470)

-- MAIN APP DEPOTS / PACKAGES
addappid(514471, 1, "ddbbf3423e98f0c7b66953982ddc38d1c891cc09a45b31125fc7978abf9b215b")
