-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Deluxe Costume - Nobunaga Oda

-- MAIN APPLICATION
addappid(1649710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649710,0,"5c5e816411764ba9bd99895f2246599586c941ab4fd8fd489590f9e6183b4a8e")

