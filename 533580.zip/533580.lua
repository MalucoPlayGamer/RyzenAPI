-- Lua provided by RyzenAPI
-- Game: Entangle

-- MAIN APPLICATION
addappid(533580)

-- MAIN APP DEPOTS / PACKAGES
addappid(533581, 1, "90e2bcdc3bc52c39288370f2f77acbe6be24ee03f5a0e782b4ec6135f6015904")

