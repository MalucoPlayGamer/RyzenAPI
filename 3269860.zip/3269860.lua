-- Lua provided by RyzenAPI
-- Game: 3269860

-- MAIN APPLICATION
addappid(3269860)
-- Game: addappid(3269860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269861, 1, "cba80528f16c3476fb3728d8af8ad5c29e0b839b07da119644799f4e5ce73eaf")
