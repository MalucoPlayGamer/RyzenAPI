-- Lua provided by RyzenAPI
-- Game: Game: AppID 2344920

-- MAIN APPLICATION
addappid(2344920)
-- Game: addappid(2344920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344921, 1, "0c0f71133eabf7ecfa8e13545a6c9397b723610746b173190a701f204e06c920")
