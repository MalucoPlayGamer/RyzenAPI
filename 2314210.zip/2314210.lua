-- Lua provided by RyzenAPI
-- Game: METAL GEAR SOLID - Master Collection Version Japanese Language Pack

-- MAIN APPLICATION
addappid(2314210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314210,0,"e068c94228149aa99007649f734b768c4ab7a51d4513556df1cf33ee1c2a0126")

