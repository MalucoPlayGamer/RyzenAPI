-- Lua provided by RyzenAPI
-- Game: AppID 551080

-- MAIN APPLICATION
addappid(551080)

-- MAIN APP DEPOTS / PACKAGES
addappid(551081, 1, "9bcacb3eebf03ea0b7df2a1dac02081f6f249e7ea0eeb044d71700fe6c2ef054")
addappid(551082, 1, "38e1e14d731b3e3095160da0fdecdbcd9e7e4d82c202cd0ea6adc0e39fd29122")
addappid(551083, 1, "05fa4994898b53ac89e0a6baad27498a78d569851646c33247aaa10c2fb5f632")
