-- Lua provided by RyzenAPI
-- Game: Kidgilantes

-- MAIN APPLICATION
addappid(1383290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383291, 1, "08139c60274138024d2b698e4786be9a3d1da407d19a75cddac1782423d5a83f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
