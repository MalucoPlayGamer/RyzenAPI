-- Lua provided by RyzenAPI
-- Game: Kidgilantes

-- MAIN APPLICATION
addappid(1383290)
-- Game: addappid(1383290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383291, 1, "08139c60274138024d2b698e4786be9a3d1da407d19a75cddac1782423d5a83f")
