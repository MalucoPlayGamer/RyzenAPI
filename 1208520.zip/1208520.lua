-- Lua provided by RyzenAPI
-- Game: The Alchemist's House

-- MAIN APPLICATION
addappid(1208520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1208521, 1, "5849a3fae202e0bf2e32c06afb458347fb84481acae9defa2156c68e191bf057")

