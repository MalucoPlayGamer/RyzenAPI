-- Lua provided by RyzenAPI
-- Game: 妖魔缠身 Demo

-- MAIN APPLICATION
addappid(3129940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129941, 1, "ec60ee606e54ea6e02764ecbda93de9188cb42125375f0faa7fafd51e34b30a7")
