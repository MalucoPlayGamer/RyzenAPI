-- Lua provided by RyzenAPI
-- Game: 350300

-- MAIN APPLICATION
addappid(350300)
-- Game: addappid(350300)

-- MAIN APP DEPOTS / PACKAGES
addappid(350301, 1, "234f0a9388ba255267ac11b4f8d0f7fd6c2dc47a80223bd8a3edd7284c8231d2")
addappid(350302, 1, "9195b84628a00f006f8ccded8b9a047c4f5fdf39eb01c8dfd88b813ca48c4a5c")
