-- Lua provided by RyzenAPI
-- Game: AppID 590950

-- MAIN APPLICATION
addappid(590950)

-- MAIN APP DEPOTS / PACKAGES
addappid(590951, 1, "3ed968d75cbe5fc8f8e57b12013444739eb40f7cecd93b0ecd1497b9380a0120")

