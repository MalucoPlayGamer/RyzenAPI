-- Lua provided by SkyAPI 
-- Game: Inscryption Demo
addappid(1753260)
addappid(1753261, 1, "14f0723099181bc08f737c9ef4ec5dee2f904376c6550fd26a0b78901068f4fa")
