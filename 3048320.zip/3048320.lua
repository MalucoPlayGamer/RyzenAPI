-- Lua provided by RyzenAPI
-- Game: Tamer: King of Dinosaurs Demo

-- MAIN APPLICATION
addappid(3048320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048321, 1, "e931f21ed8e8085608ff9d400ef1715dd1e489c6b6fbea34111a8e60913fd9ba")
