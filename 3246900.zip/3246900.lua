-- Lua provided by SkyAPI 
-- Game: Coloring Game: Girls 2
addappid(3246900)
addappid(3246901, 1, "0024358ea9c652d1e621ee742c2c24f0918742527e275deab03be0b25221cf1a")
addappid(3246903, 1, "426e9d211749e5c673bdcf7620f273672350214e7ae414d79670c15d5fd00703")
