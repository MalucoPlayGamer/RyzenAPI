-- Lua provided by RyzenAPI
-- Game: Drakensang - Phileasson's Secret

-- MAIN APPLICATION
addappid(33780)
-- Game: addappid(33780)

-- MAIN APP DEPOTS / PACKAGES
addappid(33781, 1, "c05aaa1d5d8fc37c938a376fec68950b3343bf6d19251e68568ec6b0571cbbc2")
