-- Lua provided by RyzenAPI
-- Game: Untamed Demo

-- MAIN APPLICATION
addappid(2737830)
-- Game: addappid(2737830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737831, 1, "fe9c3a0dc8aa4e93a0e79e73c2f8cd4f5f13f29eca984b20d300854f80374f1c")
