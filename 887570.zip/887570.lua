-- Lua provided by RyzenAPI
-- Game: Game: NEBULOUS: Fleet Command

-- MAIN APPLICATION
addappid(887570)
-- Game: addappid(887570)

-- MAIN APP DEPOTS / PACKAGES
addappid(887571, 1, "75252a8e668a49c99a8f56a9b77550209a9965e9a93b26c882c9706b973f5054")
