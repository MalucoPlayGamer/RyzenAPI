-- Lua provided by RyzenAPI
-- Game: NEBULOUS: Fleet Command

-- MAIN APPLICATION
addappid(887570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(887571, 1, "75252a8e668a49c99a8f56a9b77550209a9965e9a93b26c882c9706b973f5054")

