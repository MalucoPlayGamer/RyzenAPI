-- Lua provided by RyzenAPI
-- Game: 1508300

-- MAIN APPLICATION
addappid(1508300)
-- Game: addappid(1508300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508301, 1, "81b70e44a08d789f079b60eeeabad4f2d100a95e3de7cf8ac62bef2512e76da0")
