-- Lua provided by RyzenAPI
-- Game: Cowpocalypse

-- MAIN APPLICATION
addappid(1075430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(1075431, 1, "267ac0889e6811aa8ab0b1d4623e11d32d27e28aa7174fed5cde318cb1b66cef")
