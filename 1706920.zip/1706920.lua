-- Lua provided by RyzenAPI
-- Game: 1706920

-- MAIN APPLICATION
addappid(1706920)
-- Game: addappid(1706920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706921, 1, "75f9a1dc5afd9dda4fb58f20faf1670c6f7b92eee55bc058b85abe45547b1cd3")
