-- Lua provided by RyzenAPI
-- Game: 2476020

-- MAIN APPLICATION
addappid(2476020)
-- Game: addappid(2476020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476021, 1, "5c80c5ad9abd99fb26e9e7f03ae5d5aa80bf6fba999b69e4b480a0414b05c112")
