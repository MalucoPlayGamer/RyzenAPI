-- Lua provided by RyzenAPI
-- Game: Game: AppID 1316520

-- MAIN APPLICATION
addappid(1316520)
-- Game: addappid(1316520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316521, 1, "e126d3d4cc2d75232d5603e766718bc56f3ef59a2e06f5d04a9e4bad1e1b8b19")
