-- Lua provided by RyzenAPI
-- Game: Flain - Tao force & Cubes

-- MAIN APPLICATION
addappid(1316520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1316521, 1, "e126d3d4cc2d75232d5603e766718bc56f3ef59a2e06f5d04a9e4bad1e1b8b19")

