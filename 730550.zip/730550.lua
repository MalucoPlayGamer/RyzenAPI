-- Lua provided by SkyAPI 
-- Game: Kanova
addappid(730550)
addappid(730551, 1, "4874dbc34bd402286da4f5238690d3a950c308c06752951f57a4e37cf082f5e9")
