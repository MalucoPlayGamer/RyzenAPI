-- Lua provided by RyzenAPI
-- Game: Dream Daddy: A Dad Dating Simulator

-- MAIN APPLICATION
addappid(654880)
addappid(930020)

-- MAIN APP DEPOTS / PACKAGES
addappid(654881, 1, "8e82dbb1f4c7bb450e1448f093fc24c2efd707e2890b72d4207830ffbc270a13")
addappid(654884, 1, "120a10ce54e14f457a369ee18c1ff5e0f98170b9c4c8553125708576480984ad")

