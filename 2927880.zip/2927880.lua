-- Lua provided by RyzenAPI 
-- Game: H.E.N.T.A.L.K.E.R.
addappid(2927880)
addappid(2927881, 1, "0124746bb01704baf6b942a61d35b1985a6fe9dfbaf89dae555d616924f6d61d")
