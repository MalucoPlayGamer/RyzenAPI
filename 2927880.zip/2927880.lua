-- Lua provided by RyzenAPI
-- Game: 2927880

-- MAIN APPLICATION
addappid(2927880)
-- Game: addappid(2927880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927881, 1, "0124746bb01704baf6b942a61d35b1985a6fe9dfbaf89dae555d616924f6d61d")
