-- Lua provided by RyzenAPI
-- Game: Game: Pony World 2

-- MAIN APPLICATION
addappid(546820)
-- Game: addappid(546820)

-- MAIN APP DEPOTS / PACKAGES
addappid(546821, 1, "5823dbba23deaa784e652a122bbbd3676337f0cea507691534e74105eb92fca7")
