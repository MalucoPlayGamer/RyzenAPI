-- Lua provided by RyzenAPI
-- Game: AppID 2597760

-- MAIN APPLICATION
addappid(2597760)
-- Game: addappid(2597760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597761, 1, "f9c53784a3e8202200dc7c89bb488dc448f15055ae85de60fe2f02533e159f90")
