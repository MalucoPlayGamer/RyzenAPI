-- Lua provided by RyzenAPI
-- Game: addappid(857160)

-- MAIN APPLICATION
addappid(857160)

-- MAIN APP DEPOTS / PACKAGES
addappid(857161, 1, "ec9dbfda0da53e9cad57fadd3c89088fd43b2428ec6c2207552abcde34a80f9e")
