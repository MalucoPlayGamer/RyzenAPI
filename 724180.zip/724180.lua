-- Lua provided by RyzenAPI
-- Game: addappid(724180)

-- MAIN APPLICATION
addappid(724180)
addappid(736550)

-- MAIN APP DEPOTS / PACKAGES
addappid(724181, 1, "db38c470767ee70e0482d5d1e01e704e7cf38ad58322b568c2177cf23339ebdb")
