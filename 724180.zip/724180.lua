-- Lua provided by RyzenAPI
-- Game: Morgan lives in a Rocket House in VR

-- MAIN APPLICATION
addappid(724180)
addappid(736550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(724181, 1, "db38c470767ee70e0482d5d1e01e704e7cf38ad58322b568c2177cf23339ebdb")

