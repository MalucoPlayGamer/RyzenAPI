-- Lua provided by RyzenAPI
-- Game: Game: Sunwave Hotel

-- MAIN APPLICATION
addappid(2010210)
-- Game: addappid(2010210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010211, 1, "553c412a2d196d1525dd821199d29aea16c8378296f76b0d4ba58c2443e10e10")
