-- Lua provided by RyzenAPI
-- Game: 夢獸之島Isles of Monsters

-- MAIN APPLICATION
addappid(1758360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758361, 1, "d537518b3d1fc0ada86c9ee26bc4e65928234cdc4d0cb09afda0f61ee7a54117")
