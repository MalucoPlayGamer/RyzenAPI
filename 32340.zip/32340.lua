-- Lua provided by RyzenAPI
-- Game: addappid(32340)

-- MAIN APPLICATION
addappid(32340)

-- MAIN APP DEPOTS / PACKAGES
addappid(32341, 1, "e14be6564c29ae44e25e711c1e8e3eb197653f94762fa75bfe7f7e847cd2505a")
addappid(32342, 1, "48c97021d61f6fa6ed748e46f019ddc9f88866861cb5c3d11b755b4c03f73b68")
