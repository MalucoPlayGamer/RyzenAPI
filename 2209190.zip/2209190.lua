-- Lua provided by RyzenAPI
-- Game: The Princess of the Tower Wants a Hero

-- MAIN APPLICATION
addappid(2209190)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2215370)
