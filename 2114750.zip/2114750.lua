-- Lua provided by SkyAPI 
-- Game: Tsundere Girls
addappid(2114750)
addappid(2114751, 1, "94aef5b1cbbfda2c71fb3fd639e4c197c18b30d8e49eb2b8556a0f4af1440ace")
