-- Lua provided by RyzenAPI
-- Game: Tsundere Girls

-- MAIN APPLICATION
addappid(2114750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114751, 1, "94aef5b1cbbfda2c71fb3fd639e4c197c18b30d8e49eb2b8556a0f4af1440ace")
