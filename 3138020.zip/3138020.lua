-- Lua provided by RyzenAPI
-- Game: Game: Quantum of Hope

-- MAIN APPLICATION
addappid(3138020)
-- Game: addappid(3138020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138021, 1, "7622d329e8a578b5bcc3a74bf58fde8b9cd52ee0386517188ccf8da552bf3fe3")
