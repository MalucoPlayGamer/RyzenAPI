-- Lua provided by RyzenAPI
-- Game: 花火与幽灵少女 - Hanabi and Ghost girl

-- MAIN APPLICATION
addappid(2302540)
