-- Lua provided by RyzenAPI
-- Game: Game: AppID 1380120

-- MAIN APPLICATION
addappid(1380120)
-- Game: addappid(1380120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380121, 1, "8c9fdc7156d4ac36e3266d4b0266a9c166d18959837af567d523468e925b007a")
