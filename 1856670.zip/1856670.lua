-- Lua provided by RyzenAPI
-- Game: AppID 1856670

-- MAIN APPLICATION
addappid(1856670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856671, 1, "81c3e2d8b4be0737e09f9d6a0d264b2ca65c3c0c7ffdde7af5fe89122ce85592")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
