-- Lua provided by RyzenAPI 
-- Game: Silenced: The House
addappid(807230)
addappid(807231, 1, "1e482a5786904fd3eeebe1f75091b8216c3a895324bf8618e1f830f1835b0ef5")
