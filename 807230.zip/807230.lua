-- Lua provided by RyzenAPI
-- Game: Silenced: The House

-- MAIN APPLICATION
addappid(807230)
-- Game: addappid(807230)

-- MAIN APP DEPOTS / PACKAGES
addappid(807231, 1, "1e482a5786904fd3eeebe1f75091b8216c3a895324bf8618e1f830f1835b0ef5")
