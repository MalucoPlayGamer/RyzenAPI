-- Lua provided by RyzenAPI 
-- Game: AppID 496730
addappid(496730)
addappid(496731, 1, "50f1ca291545e63abef181a337ce2013d9cc1bb8e7ec5dadc503a3f20f4887be")
