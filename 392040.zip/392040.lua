-- Lua provided by RyzenAPI
-- Game: War Blade

-- MAIN APPLICATION
addappid(392040)
addappid(1015590)
-- Game: addappid(392040)

-- MAIN APP DEPOTS / PACKAGES
addappid(392041, 1, "606caa3c4dd52f52d6315d13e6ece6bb656c26ef1b38b30fa06e57987db7773c")
