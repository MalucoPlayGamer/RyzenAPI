-- Lua provided by RyzenAPI
-- Game: AppID 442780

-- MAIN APPLICATION
addappid(442780)

-- MAIN APP DEPOTS / PACKAGES
addappid(442781, 1, "aec4daf5e919b010344b83e30ab39a60a46b41a356609174cc074ac9c3330ba3")
addappid(442782, 1, "1c4b14812176b2e2e4b564f0a5ac7150a8c15798cec5b9c9f423c1e77f700548")
addappid(442783, 1, "eec50822a581b6f7a71b8791b02ff55897076857fc4e31d58b3def79fc98b51d")
addappid(442784, 1, "fc20fcac7c26c61fbb4cec154a6d1165a9424cfd379d051684223f2981ba221c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(629940)
