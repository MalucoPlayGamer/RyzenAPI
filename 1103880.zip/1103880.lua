-- Lua provided by RyzenAPI
-- Game: Bullet Roulette VR

-- MAIN APPLICATION
addappid(1103880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103881, 1, "4cd49726d235d1ca8c90069050d970521590be2b057c0101f07a529fbdfddd6a")
