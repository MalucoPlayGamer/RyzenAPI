-- Lua provided by RyzenAPI 
-- Game: THRILLKINGS
addappid(2916570)
addappid(2916571, 1, "91d077be56f20af190058d364c733f2e847fa4ecb87d291f2ee93b3d0bfd7215")
addappid(3362230)
