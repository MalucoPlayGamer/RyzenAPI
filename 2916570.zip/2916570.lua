-- Lua provided by RyzenAPI
-- Game: Game: THRILLKINGS

-- MAIN APPLICATION
addappid(2916570)
addappid(3362230)
-- Game: addappid(2916570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916571, 1, "91d077be56f20af190058d364c733f2e847fa4ecb87d291f2ee93b3d0bfd7215")
