-- Lua provided by RyzenAPI
-- Game: THRILLKINGS

-- MAIN APPLICATION
addappid(2916570)
addappid(3362230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2916571, 1, "91d077be56f20af190058d364c733f2e847fa4ecb87d291f2ee93b3d0bfd7215")

