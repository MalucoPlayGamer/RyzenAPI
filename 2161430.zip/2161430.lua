-- Lua provided by RyzenAPI
-- Game: addappid(2161430)

-- MAIN APPLICATION
addappid(2161430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161431, 1, "edb8749a36bedc4db3666ff1ade06918b28d26b75cb80c63a809149b6cc7f780")
