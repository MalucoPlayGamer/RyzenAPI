-- Lua provided by RyzenAPI
-- Game: Tiny Force Deluxe

-- MAIN APPLICATION
addappid(688620)

-- MAIN APP DEPOTS / PACKAGES
addappid(688622,0,"64a2b0ca9237f6cb2a6ffd7c6688f799999a8fe935cfa2a27ed85bc54e07152b")

