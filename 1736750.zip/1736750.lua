-- Lua provided by RyzenAPI
-- Game: Kingdom of Atham: Server

-- MAIN APPLICATION
addappid(1736750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736751, 1, "6ac59666ff9bb274b7019321b108c2947c4746536612e9f74bb838961d784eb9")
