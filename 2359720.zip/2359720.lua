-- Lua provided by RyzenAPI
-- Game: Figure Workshop

-- MAIN APPLICATION
addappid(2359720)
-- Game: addappid(2359720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359721, 1, "0477b8c4819db8ce41bff39353e93e654328ff68a436069d46ff4f9125f4d6f5")
