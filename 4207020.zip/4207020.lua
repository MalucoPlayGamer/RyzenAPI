-- Lua provided by RyzenAPI
-- Game: First Sin

-- MAIN APPLICATION
addappid(4207020) -- First Sin

-- MAIN APP DEPOTS / PACKAGES
addappid(4207021, 1, "318000b17a078e9a2683a7b5085480e971725aeda9965b639c241747ab988989") -- Depot 4207021
