-- Lua provided by SkyAPI 
-- Game: Hell Pages
addappid(1493590)
addappid(1493591, 1, "36d76d8abf3750ee1ffdf12674306c31be2a8314cefc590e7f12cd803eb7a4e0")
