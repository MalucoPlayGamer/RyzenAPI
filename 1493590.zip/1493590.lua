-- Lua provided by RyzenAPI
-- Game: Hell Pages

-- MAIN APPLICATION
addappid(1493590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493591, 1, "36d76d8abf3750ee1ffdf12674306c31be2a8314cefc590e7f12cd803eb7a4e0")
