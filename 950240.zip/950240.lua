-- Lua provided by RyzenAPI
-- Game: Game: AppID 950240

-- MAIN APPLICATION
addappid(950240)
-- Game: addappid(950240)

-- MAIN APP DEPOTS / PACKAGES
addappid(950241, 1, "a7cdf1b9241c338aa1bf3a702403c763dd023ae52b8ed2b0331b19a1033221ec")
