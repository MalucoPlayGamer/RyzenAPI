-- Lua provided by RyzenAPI
-- Game: Warm Village 暖暖村物语

-- MAIN APPLICATION
addappid(747850)
-- Game: addappid(747850)

-- MAIN APP DEPOTS / PACKAGES
addappid(747851, 1, "c5a80505f5872d873a7608b9743ebe9c9b78dfcdbe42df8438be8888d4559f33")
