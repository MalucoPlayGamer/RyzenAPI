-- 4617230's Lua and Manifest Created by Hubcap Manifest
-- Retail Rivals
-- Created: July 29, 2026 at 08:55:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4617230) -- Retail Rivals
-- MAIN APP DEPOTS
addappid(4617231, 1, "8f0d7a01cbda561f925385c7c16ecefdf0476b3ec025d8a77e5e89d085e3189e") -- Depot 4617231
setManifestid(4617231, "185346503580504193", 645185454)