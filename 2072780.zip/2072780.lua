-- Lua provided by RyzenAPI
-- Game: Game: Sex Adventures - The Office Slut

-- MAIN APPLICATION
addappid(2072780)
-- Game: addappid(2072780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072781, 1, "0239e4055c121e361f95e06ec942425dcc9c9943a2bc11f483ac8c0c0fa7d132")
