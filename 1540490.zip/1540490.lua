-- Lua provided by RyzenAPI
-- Game: addappid(1540490)

-- MAIN APPLICATION
addappid(1540490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540491, 1, "b6fe3cf1ec3c8321d50bd870cf28d4531da2e121afa76f19a3aa4ec4187912c2")
