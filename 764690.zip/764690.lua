-- Lua provided by RyzenAPI
-- Game: Caveblazers Together

-- MAIN APPLICATION
addappid(764690)

-- MAIN APP DEPOTS / PACKAGES
addappid(764691, 1, "6ba632e32bdf6114590d59f744c192e2452a30652bbe1a7afe73da4e9fc48d60")
