-- Lua provided by SkyAPI 
-- Game: Caveblazers Together
addappid(764690)
addappid(764691, 1, "6ba632e32bdf6114590d59f744c192e2452a30652bbe1a7afe73da4e9fc48d60")
