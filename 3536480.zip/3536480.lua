-- Lua provided by RyzenAPI
-- Game: 3536480

-- MAIN APPLICATION
addappid(3536480)
-- Game: addappid(3536480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3536481, 1, "ba4f41b90ecfb239f53286abb138ea4dbe25f515f2cae98542e9d7a7b4bb1e93")
