-- Lua provided by RyzenAPI
-- Game: The AC130 slays the zombies.

-- MAIN APPLICATION
addappid(3536480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3536481, 1, "ba4f41b90ecfb239f53286abb138ea4dbe25f515f2cae98542e9d7a7b4bb1e93")

