-- Lua provided by RyzenAPI
-- Game: Game: Super Miaoyin

-- MAIN APPLICATION
addappid(3481480)
-- Game: addappid(3481480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3481481, 1, "df8855f225de470379360a8546a9bbb395351c51a4d6f0ddb98115e71e32c6b7")
