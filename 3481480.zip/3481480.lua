-- Lua provided by RyzenAPI 
-- Game: Super Miaoyin
addappid(3481480)
addappid(3481481, 1, "df8855f225de470379360a8546a9bbb395351c51a4d6f0ddb98115e71e32c6b7")
