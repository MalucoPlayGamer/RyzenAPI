-- Lua provided by RyzenAPI
-- Game: 2300

-- MAIN APPLICATION
addappid(2300)
addappid(228988)
-- Game: addappid(2300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301, 1, "e20a67a0ee08097842bc07ab3b8624bfed9ac0085565dbd65ea564478c1f72b2")
