-- Lua provided by RyzenAPI
-- Game: Game: Drunken Fist 2: Zombie Hangover

-- MAIN APPLICATION
addappid(1770190)
-- Game: addappid(1770190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770191, 1, "d1aa83b47adf87f814a80ddd5672af3341c2a6ccd664bb09a4d9e87807f0ea35")
