-- Lua provided by RyzenAPI
-- Game: Drunken Fist 2: Zombie Hangover

-- MAIN APPLICATION
addappid(1770190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1770191, 1, "d1aa83b47adf87f814a80ddd5672af3341c2a6ccd664bb09a4d9e87807f0ea35")

