-- Lua provided by RyzenAPI
-- Game: Eternal Silence

-- MAIN APPLICATION
addappid(17550)

-- MAIN APP DEPOTS / PACKAGES
addappid(17551, 1, "7ee4d5e756b000d39e666fac2f0331ecb099e2e0e6bf9bc79104d29bbb6ed898")

