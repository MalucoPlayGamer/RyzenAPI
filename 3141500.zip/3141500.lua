-- Lua provided by RyzenAPI
-- Game: 塔防神马都是浮云

-- MAIN APPLICATION
addappid(3141500)
-- Game: addappid(3141500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141501, 1, "1622f8645362b046e5a7cea319b312ddf33be3b7d412b57aaab67216ec3b2218")
