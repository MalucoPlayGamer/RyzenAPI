-- Lua provided by RyzenAPI
-- Game: NieR Replicant ver.1.22474487139...

-- MAIN APPLICATION
addappid(1113560)
addappid(1565100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113561, 1, "a8237e96d9b70952bee1f0bc216c2148ba663ef656ca44d6e2057878f4494eb3")
addappid(1408390, 0, "30f495faf8482a92d1ec6e2338de1579fa4ee5d2b49f793de32254466c169aa6")

