-- Lua provided by RyzenAPI
-- Game: 219850

-- MAIN APPLICATION
addappid(200711)
addappid(200714)
addappid(200715)
addappid(219850)
addappid(219851)
addappid(219852)
-- Game: addappid(219850)

-- MAIN APP DEPOTS / PACKAGES
addappid(200712,0,"51776e76bc3cc28f142f4b168b689710e5a3cc96ada5a8bcf7aff2127bb75b55")
