-- Lua provided by RyzenAPI
-- Game: The World of Gangs

-- MAIN APPLICATION
addappid(1925040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925041, 1, "1eff8aa6622a2071a2ce92df82e7922b79ddcafc06dc323f6c26a7415efd4b34")
