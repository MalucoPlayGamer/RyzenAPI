-- Lua provided by RyzenAPI
-- Game: Rumours of a Roman Empire Artbook

-- MAIN APPLICATION
addappid(3750200)
-- Game: addappid(3750200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3750200,0,"b048cc1aab4dcc69614443cf8d39e5d8d092a0d75fdfdd864b87e196f0da452e")
