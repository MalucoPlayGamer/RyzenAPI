-- Lua provided by RyzenAPI
-- Game: 1903340

-- MAIN APPLICATION
addappid(1903340)
addappid(3228520)
-- Game: addappid(1903340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903341, 1, "8593f9c4cd595f833d5344e55cd6c6fdb73d9a4fa05dab033ba71622265e8c82")
