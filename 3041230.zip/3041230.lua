-- Lua provided by RyzenAPI
-- Game: Windrose

-- MAIN APPLICATION
addappid(3041230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041231, 1, "2be97dc7c9e688c9293eae10d8eac83e45ef0e1d40b83fe62cd19af3f211d774")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
