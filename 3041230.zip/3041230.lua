-- Lua provided by RyzenAPI 
-- Game: Windrose
addappid(3041230)
addappid(3041231, 1, "2be97dc7c9e688c9293eae10d8eac83e45ef0e1d40b83fe62cd19af3f211d774")
