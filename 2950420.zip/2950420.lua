-- Lua provided by SkyAPI 
-- Game: AppID 2950420
addappid(2950420)
addappid(2950421, 1, "0483b506b17390280a474ac80baa4163c2925c44f9f9e2540ef60563b5c9a204")
