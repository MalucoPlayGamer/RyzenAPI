-- Lua provided by SkyAPI 
-- Game: Mythos, Book One
addappid(3213410)
addappid(3213411, 1, "d6ec7afa7b2271ab61758f424c54099b6566c4c78f46d8289bcb94fce39ce355")
