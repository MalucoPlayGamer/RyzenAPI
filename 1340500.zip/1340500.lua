-- Lua provided by RyzenAPI
-- Game: Little Fire Girl

-- MAIN APPLICATION
addappid(1340500)
addappid(1441000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340501, 1, "6b98075bc3d57239a80083a65b632fa272e9eea514e7e9e28019c3fe78503912")
