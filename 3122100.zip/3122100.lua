-- Lua provided by RyzenAPI
-- Game: Game: The Ritual

-- MAIN APPLICATION
addappid(3122100)
-- Game: addappid(3122100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122101, 1, "48aa0b3cbc4fa513afb87bd9e9fe51f2e4208ebffe17826e659510d3c86a5586")
