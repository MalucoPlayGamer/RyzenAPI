-- Lua provided by RyzenAPI 
-- Game: AppID 1973610
addappid(1973610)
addappid(1973611, 1, "2ef6377a8f99b3a885967bf81f8465589f2921c79020a39447aabfbff43f042a")
addappid(1973613, 1, "79722c2970515e31dbeba5d0d8a86e8af40c6c4320fe6f0f503880fad97835d9")
