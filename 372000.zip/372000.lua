-- Lua provided by RyzenAPI 
-- Game: AppID 372000
addappid(372000)
addappid(372001, 1, "17eb52471e8792d079bc09344bc916dba9418e7133ed4e152a0714e1a6084b96")
