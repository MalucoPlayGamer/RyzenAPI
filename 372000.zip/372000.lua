-- Lua provided by RyzenAPI
-- Game: Tree of Savior (English Ver.)

-- MAIN APPLICATION
addappid(372000)
addappid(452430)
addappid(463640)
addappid(472840)
addappid(472841)
addappid(472860)
addappid(472861)
addappid(474800)
addappid(474801)
addappid(474802)
addappid(474803)
addappid(474804)
addappid(512910)
addappid(512911)
addappid(512912)
addappid(512913)
addappid(554270)
addappid(554271)
addappid(554272)
addappid(554273)
addappid(631450)
addappid(682380)
addappid(682390)
addappid(682400)
addappid(682410)
addappid(716440)
addappid(768700)
addappid(768701)
addappid(768702)
addappid(768703)
addappid(1279460)
addappid(1920920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(372001, 1, "17eb52471e8792d079bc09344bc916dba9418e7133ed4e152a0714e1a6084b96")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3513210)
addappid(3513240)
