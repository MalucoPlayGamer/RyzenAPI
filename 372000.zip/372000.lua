-- Lua provided by RyzenAPI
-- Game: Game: AppID 372000

-- MAIN APPLICATION
addappid(372000)
-- Game: addappid(372000)

-- MAIN APP DEPOTS / PACKAGES
addappid(372001, 1, "17eb52471e8792d079bc09344bc916dba9418e7133ed4e152a0714e1a6084b96")
