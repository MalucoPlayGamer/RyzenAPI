-- Lua provided by RyzenAPI
-- Game: Canasta 3D Premium

-- MAIN APPLICATION
addappid(966090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(966091, 1, "a4960ee122e1038b71b0f888ab7837ff50a062bc8a089a88fa5603290fbcd481")
