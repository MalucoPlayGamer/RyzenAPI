-- Lua provided by RyzenAPI
-- Game: addappid(966090)

-- MAIN APPLICATION
addappid(966090)

-- MAIN APP DEPOTS / PACKAGES
addappid(966091, 1, "a4960ee122e1038b71b0f888ab7837ff50a062bc8a089a88fa5603290fbcd481")
