-- Lua provided by RyzenAPI
-- Game: addappid(2545)

-- MAIN APPLICATION
addappid(2545)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546, 1, "6340b267559f27f15daf1323e1ecf9fdb44d1b2a5351ffefa7c5e10691c24ef1")
