-- Lua provided by RyzenAPI
-- Game: SAVE BILLY

-- MAIN APPLICATION
addappid(1860530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860531,0,"b5d44381cefded8eb5ce989c57b8cb3744f337797e9bdfee7090eff10790edaf")

