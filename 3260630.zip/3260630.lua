-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VII REBIRTH Digital Mini Soundtrack & Digital Art Book

-- MAIN APPLICATION
addappid(3260630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3260630,0,"39c8633805b12cb219e18d1665139d9ff5dd2a8ad30517ce3b29f1f935641f61")

