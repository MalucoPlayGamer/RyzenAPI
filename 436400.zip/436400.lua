-- Lua provided by RyzenAPI
-- Game: Game: AppID 436400

-- MAIN APPLICATION
addappid(436400)
-- Game: addappid(436400)

-- MAIN APP DEPOTS / PACKAGES
addappid(436401, 1, "b16acdc392fdf9755f379f1fe20bbee5b8cf06ce56c33667a40980497ec2b15c")
