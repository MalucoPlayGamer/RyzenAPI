-- Lua provided by RyzenAPI
-- Game: Puropu Defense Squad Demo

-- MAIN APPLICATION
addappid(2794980)
-- Game: addappid(2794980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794981, 1, "c4b0fe600f8bd22e78fc17f4c849e68e7b50233df12b680b81498020f4d09a9c")
