-- Lua provided by RyzenAPI
-- Game: Parkour Labs

-- MAIN APPLICATION
addappid(2469260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469261, 1, "b5453f89fd87ff2e87796abc0bf73c938f40f80a7145249537abb1ffd5b12a7a")
