-- Lua provided by RyzenAPI
-- Game: Parkour Labs

-- MAIN APPLICATION
addappid(2469260)
addappid(4508640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2469261, 1, "b5453f89fd87ff2e87796abc0bf73c938f40f80a7145249537abb1ffd5b12a7a")

