-- Lua provided by RyzenAPI
-- Game: Conquering Married Women through Sex

-- MAIN APPLICATION
addappid(2191660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191662,0,"851eb591437e3d91efb07c0ffeede351bdb6d7d4b91dc07a3ba8103502c66463")
