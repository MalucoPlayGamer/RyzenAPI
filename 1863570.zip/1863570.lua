-- Lua provided by RyzenAPI
-- Game: YUZA

-- MAIN APPLICATION
addappid(1863570)
-- Game: addappid(1863570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863571, 1, "dc4afcc949187deaf936ce9ff862ea53dc22c8c0fdea406919e4ccfd29ec37a4")
