-- Lua provided by RyzenAPI 
-- Game: Artificiality-人造物-
addappid(1023140)
addappid(1023141, 1, "e26736b6659f79feebcc674a846595ae9499316a1a7641856344c43a7fbd9656")
