-- Lua provided by SkyAPI 
-- Game: Just Get Through
addappid(338190)
addappid(338191, 1, "0dc920d08dcbec7b57d9bbb63532909a3d21efc3fe2ea0a87df00d77913c3add")
