-- Lua provided by SkyAPI 
-- Game: AppID 2491470
addappid(2491470)
addappid(2491471, 1, "1e7f82f98b1a62a8e1bd20e011d5fdd3852f3655107db790ce06efd6df04f2df")
