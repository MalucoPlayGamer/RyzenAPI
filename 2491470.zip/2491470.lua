-- Lua provided by RyzenAPI
-- Game: Astrometica Demo

-- MAIN APPLICATION
addappid(2491470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491471, 1, "1e7f82f98b1a62a8e1bd20e011d5fdd3852f3655107db790ce06efd6df04f2df")
