-- Lua provided by RyzenAPI
-- Game: addappid(974220)

-- MAIN APPLICATION
addappid(974220)

-- MAIN APP DEPOTS / PACKAGES
addappid(974221, 1, "a87ca11d31063ff8bf808db53cb1bad2db382a85b4e3047b2c6b4db360765600")
