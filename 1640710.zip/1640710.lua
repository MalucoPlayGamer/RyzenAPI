-- Lua provided by RyzenAPI
-- Game: Interregnum Chronicles: Signal

-- MAIN APPLICATION
addappid(1640710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1640711, 1, "62924b34f6943a18597fa676f0c9403074b719a9e13d8732d8e0fb6a32cc19b6")

