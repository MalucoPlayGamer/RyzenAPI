-- Lua provided by RyzenAPI
-- Game: The Box of Fear

-- MAIN APPLICATION
addappid(3881960) -- The Box of Fear

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3881961, 1, "fef1018e2c941a02b8471d6a8e5a8ca7796e8aebea72eaca2d3e1fb58432f206") -- Depot 3881961

