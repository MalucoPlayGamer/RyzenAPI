-- 3881960's Lua and Manifest Created by Hubcap Manifest
-- The Box of Fear
-- Created: August 14, 2026 at 00:45:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3881960) -- The Box of Fear
-- MAIN APP DEPOTS
addappid(3881961, 1, "fef1018e2c941a02b8471d6a8e5a8ca7796e8aebea72eaca2d3e1fb58432f206") -- Depot 3881961
setManifestid(3881961, "5103813303509491176", 1553815322)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)