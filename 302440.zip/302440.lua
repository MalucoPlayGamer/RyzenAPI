-- Lua provided by RyzenAPI
-- Game: 302440

-- MAIN APPLICATION
addappid(302440)
-- Game: addappid(302440)

-- MAIN APP DEPOTS / PACKAGES
addappid(302441, 1, "cbc6c7013756ac672bdcd25a0c0f88f682565dc5ebfac6317b8fb46fc54d6b56")
