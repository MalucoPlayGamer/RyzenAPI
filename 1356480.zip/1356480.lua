-- Lua provided by RyzenAPI
-- Game: helionaut

-- MAIN APPLICATION
addappid(1356480)
-- Game: addappid(1356480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356481, 1, "ebf7f081f03b2c7ad7b7c29a338fd3f6a704f682f19bc3ff196acea02f8bfb56")
addappid(1356482, 1, "b5c4481db023e8c357931d15fa841af6767a679f1e9b2ebfb1533a0e26a50a93")
