-- Lua provided by RyzenAPI
-- Game: Gunner-chan! Original Soundtrack

-- MAIN APPLICATION
addappid(2934130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934131, 1, "ff623902c73627b8ba5dfc1293e02583fd326e3631c19d45c9008a767d6d4639")
