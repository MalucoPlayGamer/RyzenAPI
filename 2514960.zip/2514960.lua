-- Lua provided by SkyAPI 
-- Game: AppID 2514960
addappid(2514960)
addappid(2514961, 1, "cb0c853fe1fe32bb017a5a1bb05158edc251190653ad84e31745b7fefdbc7866")
