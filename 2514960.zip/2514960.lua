-- Lua provided by RyzenAPI
-- Game: Refind Self: The Personality Test Game

-- MAIN APPLICATION
addappid(2514960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514961, 1, "cb0c853fe1fe32bb017a5a1bb05158edc251190653ad84e31745b7fefdbc7866")
