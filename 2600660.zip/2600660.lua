-- Lua provided by RyzenAPI
-- Game: Roulette Simulator 2024

-- MAIN APPLICATION
addappid(2600660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600661, 1, "e1a7779a2d0b77968524f7f721f13fa9e3dc97af39e9bbc6a805ea946522c5a1")
