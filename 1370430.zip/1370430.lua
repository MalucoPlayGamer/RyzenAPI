-- Lua provided by RyzenAPI
-- Game: Police Chase

-- MAIN APPLICATION
addappid(1370430)
-- Game: addappid(1370430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370433,0,"744756702ce30ecf3e20f7165cc546d1d1bbdc14b10e13ec228e67da3d302197")
