-- Lua provided by RyzenAPI
-- Game: 2308870

-- MAIN APPLICATION
addappid(2308870)
addappid(3244480)
-- Game: addappid(2308870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308871, 1, "eb948b0302827846185e48b0ddcdb7077db5ba361ba014c42ef6f41885d35866")
