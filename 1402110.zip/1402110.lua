-- Lua provided by RyzenAPI
-- Game: 1402110

-- MAIN APPLICATION
addappid(1402110)
-- Game: addappid(1402110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402111, 1, "0f0438b83b0b247b16083bc7fb38cba2dcd053ca1c4346ea5b6efdbc23b545bf")
addappid(2412330, 0, "2371be4ba1fc4e239280ad491539272d080ea6c9ef8718cc1c74e114b45e9124")
