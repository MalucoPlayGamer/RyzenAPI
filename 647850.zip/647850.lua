-- Lua provided by RyzenAPI
-- Game: Royal Detective: Queen of Shadows Collector's Edition

-- MAIN APPLICATION
addappid(647850)

-- MAIN APP DEPOTS / PACKAGES
addappid(647851,0,"a466c769b8ac01bbf977061293ca07ed6bfd55e9774ba473c2a989ead8421d7f")

