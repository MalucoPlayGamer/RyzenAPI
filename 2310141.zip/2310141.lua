-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2310141)
addappid(2359400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310141,0,"e12b614b66afc732295c29100b58b6631c48fdbdffd88e5a60d886eae44a1e4e")

