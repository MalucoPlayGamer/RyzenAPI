-- Lua provided by RyzenAPI
-- Game: Doorways: The Underworld

-- MAIN APPLICATION
addappid(311250)
addappid(526560)
addappid(526561)
addappid(526562)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(311251, 1, "c86c93ddbdda5d86c1a5148280b7a99533462bac7ebc5823230c9d89f7a456d1")
addappid(311252, 1, "644d232a98241ba01e8f36353c902846078535498e9b066ba7d214a042f18f8f")
addappid(311253, 1, "04b90c9de580e33afb7ad177afac81bb4bdf403305296999aa5cb43295cde0f2")

