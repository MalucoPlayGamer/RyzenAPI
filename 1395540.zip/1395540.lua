-- Lua provided by RyzenAPI
-- Game: BOT.vinnik Chess: Winning Patterns

-- MAIN APPLICATION
addappid(1395540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395541, 1, "fcc62ee97f4194d937802d9d43e86221880c400bf3f82dce37480112101e960a")

