-- Lua provided by RyzenAPI
-- Game: Sea of Stars: Sunset Edition

-- MAIN APPLICATION
addappid(1244090)
addappid(2550500)
addappid(3457510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1244091,0,"1549d20da14b7d148867bd5c7ae9353bf17b61ca4b5babd432a332beb9ca8b92")
addappid(2550501,0,"8b97c6e0dfb7c12208ed1fd619275b1c92564b93971477f777880be9887198ef")

