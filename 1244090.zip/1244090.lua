-- Lua provided by RyzenAPI
-- Game: Game: Sea of Stars: Sunset Edition

-- MAIN APPLICATION
addappid(1244090)
addappid(2550500)
-- Game: addappid(1244090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244091, 1, "1549d20da14b7d148867bd5c7ae9353bf17b61ca4b5babd432a332beb9ca8b92")
addappid(2550501, 0, "8b97c6e0dfb7c12208ed1fd619275b1c92564b93971477f777880be9887198ef")
