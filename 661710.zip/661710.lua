-- Lua provided by RyzenAPI
-- Game: Game: AppID 661710

-- MAIN APPLICATION
addappid(661710)
-- Game: addappid(661710)

-- MAIN APP DEPOTS / PACKAGES
addappid(661711, 1, "16a02431c3516141a4a68749d17a28bfc3b08e27ae522a0fcc86991697cdfecf")
