-- Lua provided by RyzenAPI
-- Game: Game: AppID 1105970

-- MAIN APPLICATION
addappid(1105970)
-- Game: addappid(1105970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105971, 1, "f9d1c16dc9aea767072e9e299435a1cf52e31ccab80cbf1d5400989350edb605")
