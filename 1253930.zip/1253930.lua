-- Lua provided by RyzenAPI 
-- Game: AppID 1253930
addappid(1253930)
addappid(1253931, 1, "282339aaf2bd186e2702fe537295243a219f2fb8b63b2fd0bfb0ec4795e3e5a7")
