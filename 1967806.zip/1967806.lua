-- Lua provided by RyzenAPI
-- Game: 1967806

-- MAIN APPLICATION
addappid(1967806)
-- Game: addappid(1967806)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967806,0,"00b22c3fce3d834170c98aa78e6dcddb93c738ad6b02ccf368d3be40b42f0ba1")
