-- Lua provided by RyzenAPI
-- Game: Gravity Circuit Soundtrack

-- MAIN APPLICATION
addappid(2392620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392621, 1, "62978bd325fe5b85e958fb7eacf1eee7df6fe0b1e4739767cc762efa76890aa9")
