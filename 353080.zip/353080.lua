-- Lua provided by SkyAPI 
-- Game: AppID 353080
addappid(353080)
addappid(353081, 1, "346f7f8a44d0219c930e50b7e9b035fbb6f9cc0113ae13881ed830e9df70959a")
