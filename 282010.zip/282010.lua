-- Lua provided by RyzenAPI
-- Game: Game: AppID 282010

-- MAIN APPLICATION
addappid(282010)
-- Game: addappid(282010)

-- MAIN APP DEPOTS / PACKAGES
addappid(282011, 1, "b9b2484dd91a4010b9c46608403103be34d0c43f700b0eb5ca52ec905e7bbd04")
