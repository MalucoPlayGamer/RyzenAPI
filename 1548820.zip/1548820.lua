-- Lua provided by RyzenAPI
-- Game: addappid(1548820)

-- MAIN APPLICATION
addappid(1548820)
addappid(1609210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548821, 1, "ee1d399505a549390e31fa30874ac00d070ce19dee1088791623f982f02c1eee")
