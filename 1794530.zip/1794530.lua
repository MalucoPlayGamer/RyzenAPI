-- Lua provided by RyzenAPI 
-- Game: OLI
addappid(1794530)
addappid(1794531, 1, "0e38168390584420700e9c2942967bac9039295be68526421146a396d2e73d46")
