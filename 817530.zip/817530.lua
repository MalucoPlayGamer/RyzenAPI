-- Lua provided by RyzenAPI
-- Game: AppID 817530

-- MAIN APPLICATION
addappid(817530)
-- Game: addappid(817530)

-- MAIN APP DEPOTS / PACKAGES
addappid(817531, 1, "c8cbcf1467636879ca22a89049cbc6994c24d9f1523f5d0571c3deab6df56e38")
