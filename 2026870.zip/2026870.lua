-- Lua provided by RyzenAPI
-- Game: addappid(2026870)

-- MAIN APPLICATION
addappid(2026870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026871, 1, "e6587fbf8def40bddc07fff93ebb119d7dee91564f3b6b1b963a157c869579b2")
