-- Lua provided by RyzenAPI
-- Game: Guild of Dungeoneering Ultimate Edition

-- MAIN APPLICATION
addappid(317820)

-- MAIN APP DEPOTS / PACKAGES
addappid(317821, 1, "70178e6061654a05d4a09486971f19b0318b82c9449ed80c6ee6611dcdb725fb")
addappid(317822, 1, "f1d0c9726973f4f0cd7069a6f224440503b548270d80687b3a30e8c8ae8917e8")
addappid(317823, 1, "51b0ad4454c12f4c412418b0a2f1ed9362a8b14943bed5227243b0b56bdb5df4")
addappid(402700, 0, "40268cae6e444e5ec31b3587af5b005fd6a34574dc8ab5f77af694c01e0359a5")
addappid(402701, 0, "c2f2d7f4f35875cfbe681004236c7898fc10ecae888e98c7495c2c94033ccace")
addappid(539040, 0, "676845f75d3cf2a120bfb88cb5613f9b96e7f6e0ddee450106434967a14c1d0e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(376810)
