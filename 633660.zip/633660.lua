-- Lua provided by RyzenAPI
-- Game: Onimod Land

-- MAIN APPLICATION
addappid(633660)

-- MAIN APP DEPOTS / PACKAGES
addappid(633661,0,"a9b1242d6f13cb10f47b08ca7ca34f191686678903abbca159a2a88fd4cee4bb")

