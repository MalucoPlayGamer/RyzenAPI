-- Lua provided by RyzenAPI 
-- Game: RACING BROS: ONLINE Playtest
addappid(1938060)
addappid(1938061, 1, "d2fe2e4d36096758399870414e357b9956a1d13a0ce4fe601ee9e099a1d7e942")
