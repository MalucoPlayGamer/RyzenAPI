-- Lua provided by RyzenAPI
-- Game: Firefighter Connor - Original Soundtrack

-- MAIN APPLICATION
addappid(2476800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476801, 1, "da5a52b9592a4904304b29780691754f3743be72649d44f41f6f7325f7d9c0a0")

