-- Lua provided by RyzenAPI
-- Game: Molemen Must Die!

-- MAIN APPLICATION
addappid(602120)
addappid(602121)
addappid(602123)
addappid(602124)

-- MAIN APP DEPOTS / PACKAGES
addappid(602122,0,"d60d82fcb408d09530b6e4d3ab6af54eceb4041f05625c4b56b88d813f94c913")

