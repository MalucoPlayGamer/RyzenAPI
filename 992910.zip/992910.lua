-- Lua provided by RyzenAPI
-- Game: The Black Masses

-- MAIN APPLICATION
addappid(992910)
-- Game: addappid(992910)

-- MAIN APP DEPOTS / PACKAGES
addappid(992911, 1, "d0028c96526a2472c22481e283de4ef6e3309ef56164526505b9ae23def284ed")
