-- Lua provided by RyzenAPI
-- Game: Haunted Hotel: Eclipse Collector's Edition

-- MAIN APPLICATION
addappid(995900)

-- MAIN APP DEPOTS / PACKAGES
addappid(995901, 1, "e3b568a6eedda27555b5dcafbfddfa85cfafcfcad540f6d715592159cee48a9c")

