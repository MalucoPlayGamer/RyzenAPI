-- Lua provided by RyzenAPI
-- Game: Fresh Story

-- MAIN APPLICATION
addappid(2638100)
-- Game: addappid(2638100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638102,0,"5f845debc32a98056b3a1049080d7ac005a2cfe64b7db676850e3566dc370225")
