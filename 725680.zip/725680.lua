-- Lua provided by RyzenAPI
-- Game: Golf 2D

-- MAIN APPLICATION
addappid(725680)

-- MAIN APP DEPOTS / PACKAGES
addappid(725681,0,"3f6a44d549beaac805516b9430609cd0979c98e65f1f6195d7ea06c0675ac91e")

