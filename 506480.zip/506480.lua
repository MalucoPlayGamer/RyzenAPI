-- Lua provided by RyzenAPI
-- Game: 506480

-- MAIN APPLICATION
addappid(506480)
-- Game: addappid(506480)

-- MAIN APP DEPOTS / PACKAGES
addappid(506481, 1, "7fb3cf0aa87aa59e1b5fe2a162fd4740fe5e0e4012be7ee8180007ce2d948013")
