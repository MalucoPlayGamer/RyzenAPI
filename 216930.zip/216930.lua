-- Lua provided by SkyAPI 
-- Game: Luxor: Amun Rising HD
addappid(216930)
addappid(216931, 1, "f7bf652e87d2d001ba86d43f8e169c686092531914a341a7123a58948ed9ba19")
