-- Lua provided by RyzenAPI
-- Game: Luxor: Amun Rising HD

-- MAIN APPLICATION
addappid(216930)

-- MAIN APP DEPOTS / PACKAGES
addappid(216931, 1, "f7bf652e87d2d001ba86d43f8e169c686092531914a341a7123a58948ed9ba19")
