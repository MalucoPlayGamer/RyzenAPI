-- Lua provided by RyzenAPI
-- Game: Road Fist

-- MAIN APPLICATION
addappid(577330)

-- MAIN APP DEPOTS / PACKAGES
addappid(577331,0,"dfc6ebd8fbb8a699ce5a6c588552264d32654f88efd2e8c92d4641f7e95253b4")

