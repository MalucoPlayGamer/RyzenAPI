-- Lua provided by RyzenAPI
-- Game: Game: Sang-Froid - Tales of Werewolves

-- MAIN APPLICATION
addappid(227220)
addappid(228982)
addappid(228990)
-- Game: addappid(227220)

-- MAIN APP DEPOTS / PACKAGES
addappid(227221, 1, "a056ebcf53a17f945ca770bbc6a8751ca9dfeff3dd0d1d017e141acff2b48988")
