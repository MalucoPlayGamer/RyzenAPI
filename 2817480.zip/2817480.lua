-- Lua provided by RyzenAPI
-- Game: Game: Eternal end

-- MAIN APPLICATION
addappid(2817480)
-- Game: addappid(2817480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817481, 1, "c34451d893febd505eeac975935af1af14a35273050ef5a7ade3d5fc091a4672")
