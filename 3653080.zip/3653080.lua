-- Lua provided by RyzenAPI
-- Game: Game: Fuga: Melodies of Steel (Manga) Vol. 6

-- MAIN APPLICATION
addappid(3653080)
-- Game: addappid(3653080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3653081, 1, "2b36f953bc46f98d8f81a504aac79f7fdbda2227c0d2eca1ccf2308abba9d544")
