-- Lua provided by RyzenAPI
-- Game: Grisaia Phantom Trigger Vol.8

-- MAIN APPLICATION
addappid(1869980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869981, 1, "86c6f472df56b054e496c79611fa90d312c1de0da9b8256d80a3779c863dbe53")
addappid(1869982, 1, "f9131bb827546ac9d9192ac9bb98f3c6f8aec619bdfd6f8fcd53b6999832315a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
