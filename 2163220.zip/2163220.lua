-- Lua provided by RyzenAPI
-- Game: S.P.L.I.C.E.D.

-- MAIN APPLICATION
addappid(2163220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2163221, 1, "cbcfe38b0d01c77b87568e3202fc958aaa183677d9039b4197b69417c8f1e804")

