-- Lua provided by RyzenAPI
-- Game: Game: S.P.L.I.C.E.D.

-- MAIN APPLICATION
addappid(2163220)
-- Game: addappid(2163220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163221, 1, "cbcfe38b0d01c77b87568e3202fc958aaa183677d9039b4197b69417c8f1e804")
