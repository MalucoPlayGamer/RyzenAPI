-- Lua provided by RyzenAPI
-- Game: Game: Zoe the Exhibitionist

-- MAIN APPLICATION
addappid(2220110)
-- Game: addappid(2220110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220111, 1, "0f0eb24bd2cf48bc2cb05660679deb2bc37e3a1e9ebc7c2ed577a60eecee06bd")
