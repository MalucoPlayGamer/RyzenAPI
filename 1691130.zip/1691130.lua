-- Lua provided by RyzenAPI
-- Game: Game: Bigger Bikes

-- MAIN APPLICATION
addappid(1691130)
-- Game: addappid(1691130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691131, 1, "f6205572633ce8b46be9702501835ac8275943424c30395214a677b00734bbc3")
