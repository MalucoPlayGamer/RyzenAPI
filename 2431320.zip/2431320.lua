-- Lua provided by RyzenAPI
-- Game: Cat-aclysm

-- MAIN APPLICATION
addappid(2431320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2431321, 1, "e80c837d4995ef91152a7ae1d52c2d04e2d02091bae641fdc337622b7b48eeb2")

