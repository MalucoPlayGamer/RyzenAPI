-- Lua provided by RyzenAPI
-- Game: 2431320

-- MAIN APPLICATION
addappid(2431320)
-- Game: addappid(2431320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431321, 1, "e80c837d4995ef91152a7ae1d52c2d04e2d02091bae641fdc337622b7b48eeb2")
