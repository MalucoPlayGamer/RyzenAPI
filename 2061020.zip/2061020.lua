-- Lua provided by RyzenAPI
-- Game: 筒楼异事

-- MAIN APPLICATION
addappid(2061020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061021, 1, "696947dd39dbf8f27a17aed564b0fc9214c80b2d7724d256b0571c76848c1045")

