-- Lua provided by RyzenAPI
-- Game: Beat Saber - deadmau5 - Ghosts 'n' Stuff (feat. Rob Swire)

-- MAIN APPLICATION
addappid(1967803)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967803,0,"9e36a9cc9249f87f3a33569a8fb307f490913c5b27ae7198b9260e5e45a2072d")
