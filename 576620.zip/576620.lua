-- Lua provided by RyzenAPI
-- Game: AppID 576620

-- MAIN APPLICATION
addappid(576620)

-- MAIN APP DEPOTS / PACKAGES
addappid(576621, 1, "9036d1e957d6ebde3697f629deb489e5acd67cf539850fced42a145719b72c7d")

