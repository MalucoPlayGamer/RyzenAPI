-- Lua provided by RyzenAPI
-- Game: Game: AppID 367570

-- MAIN APPLICATION
addappid(367570)
-- Game: addappid(367570)

-- MAIN APP DEPOTS / PACKAGES
addappid(367571, 1, "9f8b8cabacdeeeddf481313f51901c3bca42b48c770241e2c9c7236a9d135806")
addappid(367573, 1, "7d3adc6f39f904cbc35b51bcb66ce62cfe8d1fd2b9ce7320c674127262086bea")
addappid(367574, 1, "75656b42bb343d55571fed1c06876b60fab0d1c51d17b5aaa9a9dd5c489844d4")
