-- Lua provided by RyzenAPI
-- Game: Shardpunk

-- MAIN APPLICATION
addappid(1183800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183801, 1, "009d39e6ae30013a1c9545c1c8587bce94878b5c884d4ac732f44cccc9b2cce0")
addappid(2357190, 0, "14e1fbbe10a1239bcd89532b87bfbb17bd173b779d8c8c535ae13a3854936268")
addappid(2357191, 0, "bf3ae03f9b099ae5d036ccb2785b6972fa551c734cc82c94ff40c231709bbe64")
addappid(2380110, 0, "2df8ff8a5d627c23f57f9d9afa117b38fb14bb429edbcdab36a1d792253ed427")

