-- Lua provided by RyzenAPI
-- Game: История бомжа 2: полицейский беспредел

-- MAIN APPLICATION
addappid(1764730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764731, 1, "99e7b2117b82f0722334508dd558de9e811cb81f1f31d409957a8e7fa013a8af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
