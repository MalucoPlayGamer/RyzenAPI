-- Lua provided by RyzenAPI
-- Game: 1764730

-- MAIN APPLICATION
addappid(1764730)
-- Game: addappid(1764730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764731, 1, "99e7b2117b82f0722334508dd558de9e811cb81f1f31d409957a8e7fa013a8af")
