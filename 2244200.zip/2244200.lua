-- Lua provided by SkyAPI 
-- Game: Random Chat
addappid(2244200)
addappid(2244201, 1, "8d2aebc08700f68ba69f819b1c63b998f867f5c32209a3c343a646bff0bc6f23")
