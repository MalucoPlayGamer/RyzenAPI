-- Lua provided by RyzenAPI
-- Game: Game: Armada 2526 Gold Edition

-- MAIN APPLICATION
addappid(229970)
-- Game: addappid(229970)

-- MAIN APP DEPOTS / PACKAGES
addappid(229971, 1, "7bfbfb009c92cc25b972c5e824ea88707c9560951b154a509bb9fb47ce22c5e0")
addappid(229972, 1, "cd724fe3811d72f0b14480b98528b130a09a25064843520ecca7e21e4fd4e7b2")
