-- Lua provided by RyzenAPI
-- Game: addappid(3212400)

-- MAIN APPLICATION
addappid(3212400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3212401, 1, "b7d6bd3beaf70b97fe18c16e4a77e6fa2a767f4baa6533322749abd32fc52930")
