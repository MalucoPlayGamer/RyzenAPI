-- Lua provided by RyzenAPI
-- Game: 210740

-- MAIN APPLICATION
addappid(210740)
addappid(210741)
addappid(210742)

-- MAIN APP DEPOTS / PACKAGES
addappid(209376,0,"3b747ff965e962192acf47eb4b2fd903030922fa67cd7aa7fb1dc2f37d9f855b")
addappid(209377,0,"bec5e0163c270147341bc228c0fe691fb9fd59be5effb3967b94c0130aede801")

