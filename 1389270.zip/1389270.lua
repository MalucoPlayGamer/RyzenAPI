-- Lua provided by RyzenAPI
-- Game: Game: AppID 1389270

-- MAIN APPLICATION
addappid(1389270)
-- Game: addappid(1389270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389271, 1, "5d361db4ad4a4ac8892b9aba5ab2fd138935674e176de4938f29190f260a54f3")
addappid(1389272, 1, "24b538e235c5deb1f45ebd56d75d0460ccabbc322b885dedf2c720918b8c5caf")
addappid(1389274, 1, "606d12a40d23cacc308e43247ef061b167e9fce213978d99c2cd9d0e0a4b6781")
