-- Lua provided by RyzenAPI
-- Game: Don't Crash - The Political Game

-- MAIN APPLICATION
addappid(1389270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1389271, 1, "5d361db4ad4a4ac8892b9aba5ab2fd138935674e176de4938f29190f260a54f3")
addappid(1389272, 1, "24b538e235c5deb1f45ebd56d75d0460ccabbc322b885dedf2c720918b8c5caf")
addappid(1389274, 1, "606d12a40d23cacc308e43247ef061b167e9fce213978d99c2cd9d0e0a4b6781")

