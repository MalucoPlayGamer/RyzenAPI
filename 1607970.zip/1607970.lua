-- Lua provided by RyzenAPI
-- Game: 梦落凡尘 Dreams of falling into mortal dust

-- MAIN APPLICATION
addappid(1607970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607971, 1, "28183d916cd45f1b71bf92aa2ca34f31671dfc38598a92bd231cbba3b24daf31")
