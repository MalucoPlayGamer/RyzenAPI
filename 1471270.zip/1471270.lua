-- Lua provided by RyzenAPI
-- Game: Seablip

-- MAIN APPLICATION
addappid(1471270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471271, 1, "606ff8f57195c5bebd0a972ea660b468d9b6f3a63f9936894308266a4c9714d1")
addappid(1471273, 1, "d676bbac2f433cbacdab79b7ed7bf102fb9af9a86ac53795e21915219a32b8e5")
