-- Lua provided by RyzenAPI
-- Game: 841140

-- MAIN APPLICATION
addappid(841140)
addappid(928920)
-- Game: addappid(841140)

-- MAIN APP DEPOTS / PACKAGES
addappid(841141, 1, "423a5607a284474e9f5085a7c1e12de4daf532a0d5a55dbea9c6cd187ec3e4d0")
