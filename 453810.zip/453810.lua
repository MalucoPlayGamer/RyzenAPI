-- Lua provided by RyzenAPI
-- Game: Game: Blasting Agent: Ultimate Edition

-- MAIN APPLICATION
addappid(453810)
addappid(509200)
-- Game: addappid(453810)

-- MAIN APP DEPOTS / PACKAGES
addappid(453811, 1, "84f85dd420883a56c0a273be96d8f71d6190efddd94d67dacb12cb8bf0a48b37")
