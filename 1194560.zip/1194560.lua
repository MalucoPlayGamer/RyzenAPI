-- Lua provided by RyzenAPI
-- Game: addappid(1194560)

-- MAIN APPLICATION
addappid(1194560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194561, 1, "1ffbe730210252ff88f43375f060a7e912e970121ec900caaa797d12bcecd89b")
