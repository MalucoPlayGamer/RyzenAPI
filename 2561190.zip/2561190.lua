-- Lua provided by RyzenAPI
-- Game: Claire's Cruisin' Cafe: Fest Frenzy

-- MAIN APPLICATION
addappid(2561190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561191,0,"d82df86732c67eedcd19b8a28bc4277fa23587e8be4adeb2a0c3b00d7a757324")

