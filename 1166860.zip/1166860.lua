-- Lua provided by RyzenAPI
-- Game: Rival Stars Horse Racing

-- MAIN APPLICATION
addappid(1166860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1166861, 1, "be661b31efc83ddcbf1879df7a3465fef4cdb42a9dec1cd505fa895f552ad898")
addappid(1166862, 1, "461741bf6dbb540ea3aa64908a044ce59a495b3043e37baa6fbe66c008befe6c")
