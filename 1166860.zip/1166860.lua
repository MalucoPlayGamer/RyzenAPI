-- Lua provided by RyzenAPI
-- Game: 1166860

-- MAIN APPLICATION
addappid(1166860)
-- Game: addappid(1166860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166861, 1, "be661b31efc83ddcbf1879df7a3465fef4cdb42a9dec1cd505fa895f552ad898")
addappid(1166862, 1, "461741bf6dbb540ea3aa64908a044ce59a495b3043e37baa6fbe66c008befe6c")
