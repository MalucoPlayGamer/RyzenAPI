-- Lua provided by RyzenAPI
-- Game: Game: AppID 2934900

-- MAIN APPLICATION
addappid(2934900)
-- Game: addappid(2934900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934901, 1, "279a5ac1d1d61af5cf5e8008a27c37455844b8210ad0f06d9c7bbd5cc2dc29bd")
