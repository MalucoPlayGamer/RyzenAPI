-- Lua provided by RyzenAPI
-- Game: Way of Rhea

-- MAIN APPLICATION
addappid(1110620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110622,0,"9b7a0d67e849fe4790fff6ced321546ed94e951e0b100f62cc28a6522edeae2e")
