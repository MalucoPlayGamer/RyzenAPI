-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2106630)
-- Game: addappid(2106630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106630,0,"59cde40dc1b3cec7ad277527810f315d350be2a647b9d7d350bd4dcc1fe52282")
