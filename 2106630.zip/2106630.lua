-- Lua provided by RyzenAPI
-- Game: addappid(2106630)

-- MAIN APPLICATION
addappid(2106630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106630,0,"59cde40dc1b3cec7ad277527810f315d350be2a647b9d7d350bd4dcc1fe52282")
