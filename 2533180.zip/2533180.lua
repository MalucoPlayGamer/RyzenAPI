-- Lua provided by RyzenAPI 
-- Game: MELLOWOLLEM
addappid(2533180)
addappid(2533181, 1, "c6bb81ec03aebb9b4aeae1b454dfc8cecd4bb411331186b42f95df89cc782727")
addappid(2533182, 1, "e9f7047fcef712268ac49dfa4850293e5aa375272019a4546cf3d35249b7c3bf")
addappid(2533183, 1, "afdb73c3d3822917a78560784b749a24973f3aebb9041afe77b9fe1f818390f3")
