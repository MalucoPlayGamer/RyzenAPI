-- Lua provided by RyzenAPI
-- Game: addappid(681340)

-- MAIN APPLICATION
addappid(681340)

-- MAIN APP DEPOTS / PACKAGES
addappid(681341, 1, "4e4e2af723e7f9f5827f4b7cd887ac3a8683b11ee9664470723de88db5c383d6")
