-- Lua provided by RyzenAPI
-- Game: addappid(2606290)

-- MAIN APPLICATION
addappid(2606290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606291, 1, "7582162fbb30e94ff0edbe5dd19fb67c7709621ebda10d7def45f0769bba607c")
