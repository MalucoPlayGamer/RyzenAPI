-- Lua provided by RyzenAPI
-- Game: Touhou Luna Nights

-- MAIN APPLICATION
addappid(851100)

-- MAIN APP DEPOTS / PACKAGES
addappid(851102,0,"f135911c676abf3d681ef747c752c9e04cac69572ab804e8a13d7845b65d960a")
