-- Lua provided by RyzenAPI
-- Game: 592270

-- MAIN APPLICATION
addappid(592270)
-- Game: addappid(592270)

-- MAIN APP DEPOTS / PACKAGES
addappid(592271, 1, "bccf2ae4e114bb336c44a30ed02d00af669403934ed1d78d98f4f6456623ace2")
addappid(649920, 0, "fade480b8a95c60df2be67290f767b7fab78737dcb2c02f793920603f6de39ee")
