-- Lua provided by RyzenAPI
-- Game: Freestyle 2: Street Basketball

-- MAIN APPLICATION
addappid(339610)
-- Game: addappid(339610)

-- MAIN APP DEPOTS / PACKAGES
addappid(339611, 1, "a301a9654e4cb404d6a556fc8d1a0f2ed606362efd88edc390f7210b92918746")
