-- Lua provided by SkyAPI 
-- Game: AppID 1581880
addappid(1581880)
addappid(1581881, 1, "b079f539e99a12a54d0e738583bddea62b5390e881940b00038382dc0601d65e")
