-- Lua provided by RyzenAPI
-- Game: Order Automatica

-- MAIN APP DEPOTS / PACKAGES
addappid(2105840, 1, "6e7f5ed7e1f1684dffd7b4dcf4f9b6fce6386c6259a064d8f01ae26fb0bdcf31") -- Order Automatica
addappid(2105841, 1, "d11efb493c97290dd4824039a15b591b29d0d4c5fcf7319d2b3d554eb50a9c96") -- Depot 2105841
