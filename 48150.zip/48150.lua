-- Lua provided by RyzenAPI
-- Game: Voodoo Dice

-- MAIN APPLICATION
addappid(48150)

-- MAIN APP DEPOTS / PACKAGES
addappid(48151, 1, "b17dfbf15737f9e9e8b8fad0fab5dcb6cecf31b8047b3c69aeaffe1039f215cc")

