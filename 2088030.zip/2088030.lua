-- Lua provided by RyzenAPI
-- Game: Game: Long Dream

-- MAIN APPLICATION
addappid(2088030)
-- Game: addappid(2088030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088031, 1, "17f0273d8084bee1796962c8330bf632a1f8e7ac18e646d2ddeea3c0be63fe1b")
