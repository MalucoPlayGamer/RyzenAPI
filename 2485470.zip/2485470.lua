-- Lua provided by RyzenAPI
-- Game: Poly Jigsaw: Furries

-- MAIN APPLICATION
addappid(2485470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485471, 1, "15439b7b26f465640b9ca22371c5de7716d3d93d0a55eae13350d62e4f2e2bd4")

