-- Lua provided by SkyAPI 
-- Game: AppID 2485470
addappid(2485470)
addappid(2485471, 1, "15439b7b26f465640b9ca22371c5de7716d3d93d0a55eae13350d62e4f2e2bd4")
