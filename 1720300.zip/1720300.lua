-- Lua provided by RyzenAPI
-- Game: Game: 百年王国 Demo

-- MAIN APPLICATION
addappid(1720300)
-- Game: addappid(1720300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720301, 1, "0a0b7c367f47c2b23109b406048c38754c089afc1629df6a41a5cdb4888915f3")
