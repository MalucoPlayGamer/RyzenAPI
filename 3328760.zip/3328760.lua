-- Lua provided by RyzenAPI
-- Game: Sex-Loving Family - MOTION DLC -

-- MAIN APPLICATION
addappid(3328760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328760,0,"2ade7d0ff5b6286ba41eafe4f3c5696e7b60b582ba914ed44ee71fdb697a80b1")

