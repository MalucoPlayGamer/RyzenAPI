-- Lua provided by RyzenAPI
-- Game: Drunk or Dead 2

-- MAIN APPLICATION
addappid(1966660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966662,0,"2b014f97978fb6164a3285a6706b1f8c4d50b055ca893a1eae47aea5d191b615")
