-- Lua provided by RyzenAPI
-- Game: LUNAR LICH/月球巫妖

-- MAIN APPLICATION
addappid(1577880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1577881, 1, "27235708baf55dde056e949ba8df849ee57f09b3cc6333b7ddac022cbfd1fed9")
addappid(1577882, 1, "0cc95ef69a252135452ef903f949f8ab05f587ee75299ba92cac7ba0d391b39d")
