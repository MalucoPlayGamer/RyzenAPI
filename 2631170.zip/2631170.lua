-- Lua provided by RyzenAPI 
-- Game: 夢幻四驅車
addappid(2631170)
addappid(2631171, 1, "1e7c022cf1a92cdc4dd3a1cb490b98e9ae9af84f2e58ab35dc70746929a007d9")
addappid(2631172, 1, "0aeac8a2d5b0e822fdbca5f5c2894f508774416298b54106a8d460b254b5ef78")
addappid(2631173, 1, "328f86ce2745a7e96df2d3ac10f7d0fac60620f68c6930252c4c55db078a1df6")
