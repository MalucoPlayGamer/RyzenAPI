-- Lua provided by RyzenAPI
-- Game: Skeleton Warrior

-- MAIN APPLICATION
addappid(1245280)
-- Game: addappid(1245280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245281, 1, "ea7cbf3cef24db43b60e38804abd55f600196343517099b26c414be99b769d3a")
