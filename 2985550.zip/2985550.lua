-- Lua provided by RyzenAPI
-- Game: Game: Songs of Steel: Hispania Demo

-- MAIN APPLICATION
addappid(2985550)
-- Game: addappid(2985550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985551, 1, "5757c5a82e7c613066e91993b144b563a39f99a76b416d1f39546699c4d78363")
