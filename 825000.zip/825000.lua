-- Lua provided by RyzenAPI 
-- Game: AppID 825000
addappid(825000)
addappid(825001, 1, "83566e6bd3127732cc7feb50784e5a2a79ca18b83d55fa7c381b554e67086cc3")
