-- Lua provided by RyzenAPI
-- Game: addappid(825000)

-- MAIN APPLICATION
addappid(825000)

-- MAIN APP DEPOTS / PACKAGES
addappid(825001, 1, "83566e6bd3127732cc7feb50784e5a2a79ca18b83d55fa7c381b554e67086cc3")
