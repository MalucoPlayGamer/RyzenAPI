-- Lua provided by RyzenAPI
-- Game: Minefield Fractalis

-- MAIN APP DEPOTS / PACKAGES
addappid(3886360, 1, "077e1affd1f3bcc557f58103ceddc9c9e14bb29f7a741b9795739655e39ad6f3") -- Minefield Fractalis
addappid(3886361, 1, "436c52a2dcc2b1908c37d3635350af60ddc5eb7bd4f4e90c8d08b563740e99ef") -- Depot 3886361

