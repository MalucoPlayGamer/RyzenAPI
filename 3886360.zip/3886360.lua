-- 3886360's Lua and Manifest Created by Hubcap Manifest
-- Minefield Fractalis
-- Created: August 24, 2026 at 07:09:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3886360, 1, "077e1affd1f3bcc557f58103ceddc9c9e14bb29f7a741b9795739655e39ad6f3") -- Minefield Fractalis
-- MAIN APP DEPOTS
addappid(3886361, 1, "436c52a2dcc2b1908c37d3635350af60ddc5eb7bd4f4e90c8d08b563740e99ef") -- Depot 3886361
setManifestid(3886361, "5164031494849478305", 383706876)