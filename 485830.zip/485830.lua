-- Lua provided by RyzenAPI
-- Game: addappid(485830)

-- MAIN APPLICATION
addappid(485830)

-- MAIN APP DEPOTS / PACKAGES
addappid(485831, 1, "b4cb484b27a80808ec2b7d9ce046a36815c50b7678ff624d96e4b1edcd8c7e52")
