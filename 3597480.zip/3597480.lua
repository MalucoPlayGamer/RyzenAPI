-- Lua provided by RyzenAPI
-- Game: HOMESICKNESS

-- MAIN APPLICATION
addappid(3597480)
-- Game: addappid(3597480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3597481, 1, "61c4d9574482a406e6bbdd055d41f0be9ae3ee93da942e93dd53509fac27f17f")
