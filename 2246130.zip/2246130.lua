-- Lua provided by RyzenAPI 
-- Game: HIYOKU NO TORI
addappid(2246130)
addappid(2246131, 1, "032c4472c09f654018faf96682df574450bab47da17b3eca82183ea12e6ccf9f")
