-- Lua provided by RyzenAPI
-- Game: Game: HIYOKU NO TORI

-- MAIN APPLICATION
addappid(2246130)
-- Game: addappid(2246130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246131, 1, "032c4472c09f654018faf96682df574450bab47da17b3eca82183ea12e6ccf9f")
