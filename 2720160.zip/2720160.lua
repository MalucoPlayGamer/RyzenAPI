-- Lua provided by RyzenAPI
-- Game: Skate Rift Demo

-- MAIN APPLICATION
addappid(2720160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720161, 1, "e876fdbf9c8395c228e2b2c1374e6e0aca5ca7ef5b48fe118643fed9f5c7d182")

