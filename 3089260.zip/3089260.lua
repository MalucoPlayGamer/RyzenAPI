-- Lua provided by RyzenAPI
-- Game: The Curse of Elmwood

-- MAIN APPLICATION
addappid(3089260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089261, 1, "be402fab4bf6f808d8643340b9148a2471697a2569eba0d6bb3b48ce75dcfac2")

