-- Lua provided by RyzenAPI
-- Game: The Curse of Elmwood

-- MAIN APPLICATION
addappid(3089260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3089261, 1, "be402fab4bf6f808d8643340b9148a2471697a2569eba0d6bb3b48ce75dcfac2")

