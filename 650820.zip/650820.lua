-- Lua provided by RyzenAPI
-- Game: Psychic Isolation Episode 1

-- MAIN APPLICATION
addappid(650820)

-- MAIN APP DEPOTS / PACKAGES
addappid(650821, 1, "b4edf9d0344bf4e7c5b4683cce48082c573a716a868dc20e3e96f62b67325888")

