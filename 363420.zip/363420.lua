-- Lua provided by RyzenAPI 
-- Game: AppID 363420
addappid(363420)
addappid(363421, 1, "b0b040771b6555019595753677e15e6dcf8714d0ed598da6d21864b5a2f1d806")
