-- Lua provided by RyzenAPI
-- Game: Leap of Fate

-- MAIN APPLICATION
addappid(363420)
addappid(459480)

-- MAIN APP DEPOTS / PACKAGES
addappid(363421, 1, "b0b040771b6555019595753677e15e6dcf8714d0ed598da6d21864b5a2f1d806")
