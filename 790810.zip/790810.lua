-- Lua provided by RyzenAPI
-- Game: setManifestid(790812,"7250801529711479297")

-- MAIN APPLICATION
addappid(790810)
-- Game: addappid(790810)

-- MAIN APP DEPOTS / PACKAGES
addappid(790812,0,"7c16e4a97f4528858aa715d5f9c8525b0fc7cdcbbc7bcf3b02fb917176bdb32e")
addappid(790813,0,"734fc7b82af16298339e2f5fe39e48ec4e98db1a4534aa079ef59918dee7d380")
