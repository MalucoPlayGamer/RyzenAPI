-- Lua provided by RyzenAPI
-- Game: Pool Nation FX Lite

-- MAIN APPLICATION
addappid(314000)

-- MAIN APP DEPOTS / PACKAGES
addappid(314001, 1, "42a971c97df0b1f29941b79f7a42ceaf279372037ac5ff5cc2ad2067c0e8f7f6")

