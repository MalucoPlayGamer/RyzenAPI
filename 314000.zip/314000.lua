-- Lua provided by RyzenAPI
-- Game: Pool Nation FX Lite

-- MAIN APPLICATION
addappid(314000)
addappid(404610)
addappid(407820)
addappid(407821)
addappid(407822)
addappid(407823)
addappid(421770)
addappid(421771)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(314001, 1, "42a971c97df0b1f29941b79f7a42ceaf279372037ac5ff5cc2ad2067c0e8f7f6")

