-- Lua provided by RyzenAPI
-- Game: 1274130

-- MAIN APPLICATION
addappid(1274130)
-- Game: addappid(1274130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274131, 1, "3c3243586493e0a5e809b861668f4a1acf8331f7dfdc91f1d363ce5218411bb5")
