-- Lua provided by RyzenAPI
-- Game: Game: AppID 1268310

-- MAIN APPLICATION
addappid(1268310)
-- Game: addappid(1268310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268311, 1, "0320de5e067f13ab2c51087c737329af8974fcc189849cd1b14d3b776492e9d9")
