-- Lua provided by RyzenAPI
-- Game: Souldiers

-- MAIN APPLICATION
addappid(1419160)
-- Game: addappid(1419160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419161, 1, "8d619e2d44ca981d30956e28c8cface8844472b0de374d2f8c2ea19d251a9f68")
addappid(1988770, 0, "7c2a4efaa8d0f4aa2d4ce62394d5324630ef4b8612da87afeaaab5ae0d0d1918")
