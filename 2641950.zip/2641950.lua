-- Lua provided by RyzenAPI
-- Game: addappid(2641950)

-- MAIN APPLICATION
addappid(2641950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641950,0,"7dd8cfaa8fe8b94eb01d0167b5b9c8883a429f0d4bf05f1e98466772b630dd9c")
