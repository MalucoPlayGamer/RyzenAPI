-- Lua provided by RyzenAPI
-- Game: Deep Horizon

-- MAIN APPLICATION
addappid(651170)

-- MAIN APP DEPOTS / PACKAGES
addappid(651171,0,"a13668b7e702fb46439fa9283d58e69601aac048ca2d427205d95fb90f32d646")

