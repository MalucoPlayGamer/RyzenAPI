-- Lua provided by RyzenAPI
-- Game: Game: Flamebreak

-- MAIN APPLICATION
addappid(399640)
-- Game: addappid(399640)

-- MAIN APP DEPOTS / PACKAGES
addappid(399641, 1, "dac7a26e82731e22ae75a6c3163f0a3f8779a21b66e7c08d6eb7c3b7a12fc756")
addappid(399642, 1, "b7cd155b7d7e526bc3657a6514700cc72df7261e93724358e2759628967ba143")
