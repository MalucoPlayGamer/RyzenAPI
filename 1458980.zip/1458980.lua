-- Lua provided by RyzenAPI
-- Game: addappid(1458980)

-- MAIN APPLICATION
addappid(1458980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458981, 1, "142a2dbddd214f977a1a59c60f1bb7c2018116b548ee5e54a20e1a72344d8842")
