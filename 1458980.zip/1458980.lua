-- Lua provided by RyzenAPI
-- Game: Misery Mansion

-- MAIN APPLICATION
addappid(1458980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458981, 1, "142a2dbddd214f977a1a59c60f1bb7c2018116b548ee5e54a20e1a72344d8842")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
