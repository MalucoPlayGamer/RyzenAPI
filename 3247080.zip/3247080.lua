-- Lua provided by RyzenAPI
-- Game: UNLIGHT:Revive

-- MAIN APPLICATION
addappid(3247080)
