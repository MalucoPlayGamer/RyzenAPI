-- Lua provided by RyzenAPI
-- Game: Ashley Clark: The Secrets of the Ancient Temple

-- MAIN APPLICATION
addappid(912110)

-- MAIN APP DEPOTS / PACKAGES
addappid(912111, 1, "04d3469d692b84f0d79dc56aaf90e2b0ef5cebd5d239cbd3b3c7e9d465c349a6")
