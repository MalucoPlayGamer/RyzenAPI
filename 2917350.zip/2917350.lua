-- Lua provided by RyzenAPI
-- Game: Spin Hero

-- MAIN APPLICATION
addappid(2917350)
-- Game: addappid(2917350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917351, 1, "f38228a6b3b5e65bef0a46dd7472769d06558a70491eb070d2f8e895506a58f0")
