-- Lua provided by RyzenAPI
-- Game: Xu Sheng - Officer Ticket / 徐盛使用券

-- MAIN APPLICATION
addappid(962304)

-- MAIN APP DEPOTS / PACKAGES
addappid(962304,0,"6924d8d552441aae4c57ac5bca2372d2dcd71c63182bb1b2a7a3ec72030bd6d5")

