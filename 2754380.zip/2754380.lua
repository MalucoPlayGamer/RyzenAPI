-- Lua provided by RyzenAPI
-- Game: Game: AppID 2754380

-- MAIN APPLICATION
addappid(2754380)
-- Game: addappid(2754380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754381, 1, "a144e003752b9be3b56e1699fd3513b52775d8de366af34cd9464bf289edc3b0")
