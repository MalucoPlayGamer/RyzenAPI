-- Lua provided by RyzenAPI
-- Game: Tide Of Tactics

-- MAIN APPLICATION
addappid(4005630) -- Tide Of Tactics

-- MAIN APP DEPOTS / PACKAGES
addappid(4005631, 1, "55e40e1803e8b5c9dc3af159189037bcb9837454113d0f3bffc0c18d6e7a8693") -- Depot 4005631
addappid(4005632, 1, "2cd4def253f7f70ed818e99f83fc50bb031bf83861bcc38a32cfed1aeafacd5e") -- Depot 4005632

