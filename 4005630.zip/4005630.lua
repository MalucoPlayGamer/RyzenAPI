-- 4005630's Lua and Manifest Created by Hubcap Manifest
-- Tide Of Tactics
-- Created: August 08, 2026 at 22:55:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4005630) -- Tide Of Tactics
-- MAIN APP DEPOTS
addappid(4005631, 1, "55e40e1803e8b5c9dc3af159189037bcb9837454113d0f3bffc0c18d6e7a8693") -- Depot 4005631
setManifestid(4005631, "2604098618864242422", 224558723)
addappid(4005632, 1, "2cd4def253f7f70ed818e99f83fc50bb031bf83861bcc38a32cfed1aeafacd5e") -- Depot 4005632
setManifestid(4005632, "1873691259572849837", 166071635)