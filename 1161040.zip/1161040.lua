-- Lua provided by RyzenAPI
-- Game: Game: AppID 1161040

-- MAIN APPLICATION
addappid(1161040)
-- Game: addappid(1161040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161041, 1, "c63b6f16e4023a96270564804494152854e7f56552d83b03fe4b8fedbd55b6c6")
