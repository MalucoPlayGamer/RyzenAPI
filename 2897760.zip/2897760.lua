-- Lua provided by RyzenAPI
-- Game: Game: Romantic Escapades

-- MAIN APPLICATION
addappid(2897760)
-- Game: addappid(2897760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897761, 1, "d309294d9f28f61bc9fd632ec2133bc496ef6fb2c353ef57e9af630ea77ac693")
