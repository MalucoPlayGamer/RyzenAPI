-- Lua provided by RyzenAPI
-- Game: Romantic Escapades

-- MAIN APPLICATION
addappid(2897760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897761, 1, "d309294d9f28f61bc9fd632ec2133bc496ef6fb2c353ef57e9af630ea77ac693")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
