-- Lua provided by RyzenAPI
-- Game: addappid(1175950)

-- MAIN APPLICATION
addappid(1175950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175951, 1, "7186efa7c689ea0a9bd420392843a7eccfc74a9c47643293cd535faadac02e9f")
