-- Lua provided by RyzenAPI
-- Game: Game: CapitalismCraft

-- MAIN APPLICATION
addappid(2742930)
-- Game: addappid(2742930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742931, 1, "55357807c1a8d7728c1676412747ecb571fee558b00112309a3e3ee7e35ae187")
