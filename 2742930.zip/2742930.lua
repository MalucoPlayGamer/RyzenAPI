-- Lua provided by RyzenAPI 
-- Game: CapitalismCraft
addappid(2742930)
addappid(2742931, 1, "55357807c1a8d7728c1676412747ecb571fee558b00112309a3e3ee7e35ae187")
