-- Lua provided by RyzenAPI
-- Game: Incredible Dracula: Witches' Curse

-- MAIN APPLICATION
addappid(1187830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187831, 1, "70cac33e82f28d12bca18ad58780fc8c7e7822b06629e3f48ea63e57400a72ca")
addappid(1187832, 1, "85e61fc750df5dbe81f29f7867b2a5edfffb9c86180d6322fc879e2011cfadf9")
addappid(1187833, 1, "1e10711b8b9428ca19775de054900274b45acc563c7e415448bd901398c50c65")
addappid(1187834, 1, "8ce1ccc2ba2fb76ef0ae13ca652d6ef3aa06fa7d884cd463d9d0aadaa2864a13")
