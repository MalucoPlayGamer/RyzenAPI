-- Lua provided by RyzenAPI 
-- Game: AppID 496960
addappid(496960)
addappid(496961, 1, "2c0385ea88c89de81bef2b64f3466e451320a22723e499820992120cc40e7b8c")
