-- Lua provided by RyzenAPI 
-- Game: Sex, Camera, Action! 🔞
addappid(2955820)
addappid(2955821, 1, "1b028cac40e62c2d7815521286a9e69daedc6e35a5d064d767c52966ffe1fe18")
