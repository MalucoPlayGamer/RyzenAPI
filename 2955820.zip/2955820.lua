-- Lua provided by RyzenAPI
-- Game: Sex, Camera, Action! 🔞

-- MAIN APPLICATION
addappid(2955820)
-- Game: addappid(2955820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955821, 1, "1b028cac40e62c2d7815521286a9e69daedc6e35a5d064d767c52966ffe1fe18")
