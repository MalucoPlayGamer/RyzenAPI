-- Lua provided by RyzenAPI
-- Game: Arcane Worlds

-- MAIN APPLICATION
addappid(269610)

-- MAIN APP DEPOTS / PACKAGES
addappid(269611, 1, "551ce95155831e0dc5ee5cad9bbfef51076cee45c4fa0a7fb801ab61c81eb818")
addappid(269612, 1, "692346d4fb2d4b262c270870e8f14c9fe59a7424d5b91137c74831de57e33b80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
