-- Lua provided by SkyAPI 
-- Game: Arcane Worlds
addappid(269610)
addappid(269611, 1, "551ce95155831e0dc5ee5cad9bbfef51076cee45c4fa0a7fb801ab61c81eb818")
addappid(269612, 1, "692346d4fb2d4b262c270870e8f14c9fe59a7424d5b91137c74831de57e33b80")
