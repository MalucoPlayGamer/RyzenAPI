-- Lua provided by RyzenAPI
-- Game: Game: AppID 242980

-- MAIN APPLICATION
addappid(242980)
-- Game: addappid(242980)

-- MAIN APP DEPOTS / PACKAGES
addappid(242981, 1, "68e590aab33e335eefa3b6c506ade2cfa8587e03877963dd0969b144cb35dae8")
