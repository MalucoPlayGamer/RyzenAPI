-- Lua provided by RyzenAPI
-- Game: Daikatana

-- MAIN APPLICATION
addappid(242980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(242981, 1, "68e590aab33e335eefa3b6c506ade2cfa8587e03877963dd0969b144cb35dae8")

