-- Lua provided by RyzenAPI 
-- Game: AppID 242980
addappid(242980)
addappid(242981, 1, "68e590aab33e335eefa3b6c506ade2cfa8587e03877963dd0969b144cb35dae8")
