-- Lua provided by RyzenAPI
-- Game: Mineirinho Classic (Miner Ultra Adventures)

-- MAIN APPLICATION
addappid(1424240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424240,0,"76bfef2432f424b16a45730abeeba7dc30181fe36af52865de942f6880d08951")
