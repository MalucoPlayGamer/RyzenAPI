-- Lua provided by RyzenAPI
-- Game: 3716160

-- MAIN APPLICATION
addappid(3716160)
-- Game: addappid(3716160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716161, 1, "d529df1f83e1e9fa1f62833f146da8ef66c9c8815c87e07d56f284f4985ed1bd")
