-- Lua provided by RyzenAPI
-- Game: Aquarist - My First Job

-- MAIN APPLICATION
addappid(1584660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584661, 1, "23fc346b5c66acc40727444cfdcf5993e0c0fba81cb21d0dc384d24fb30609fd")
