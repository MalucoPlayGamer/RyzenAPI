-- Lua provided by RyzenAPI
-- Game: Home - A VR Spacewalk

-- MAIN APPLICATION
addappid(512270)

-- MAIN APP DEPOTS / PACKAGES
addappid(512271, 1, "c677d136e04e68b50ac0256c71d91b5b5e7b6af24e585efefad7d99f24ce66fb")
