-- Lua provided by RyzenAPI
-- Game: Home - A VR Spacewalk

-- MAIN APPLICATION
addappid(512270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(512271, 1, "c677d136e04e68b50ac0256c71d91b5b5e7b6af24e585efefad7d99f24ce66fb")

