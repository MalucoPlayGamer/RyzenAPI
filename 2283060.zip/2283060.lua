-- Lua provided by RyzenAPI 
-- Game: Christmas SQUIRT!
addappid(2283060)
addappid(2283061, 1, "b94d068d7c0d510328c6d2ede3ee2686b4fd35c198b063f1d432ca76773b605c")
