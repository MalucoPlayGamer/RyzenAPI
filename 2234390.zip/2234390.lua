-- Lua provided by RyzenAPI
-- Game: Game: AppID 2234390

-- MAIN APPLICATION
addappid(2234390)
-- Game: addappid(2234390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234391, 1, "738b538a28dcbe94412ed1d1b273406a09ef167dd3e708104d208f023631a629")
