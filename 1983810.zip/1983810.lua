-- Lua provided by RyzenAPI
-- Game: addappid(1983810)

-- MAIN APPLICATION
addappid(1983810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983811, 1, "0de93b95d491aeea52a44c59ed35682ab51a92d0425e56b07a006a19153764ce")
