-- Lua provided by RyzenAPI
-- Game: It's Locked

-- MAIN APPLICATION
addappid(2163680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163681, 1, "311c57fe97d747d179610b2a15782b179665c19a53d56f9d10c6d42233c558be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
