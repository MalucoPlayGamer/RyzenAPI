-- Lua provided by RyzenAPI
-- Game: It's Locked

-- MAIN APPLICATION
addappid(2163680)
-- Game: addappid(2163680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163681, 1, "311c57fe97d747d179610b2a15782b179665c19a53d56f9d10c6d42233c558be")
