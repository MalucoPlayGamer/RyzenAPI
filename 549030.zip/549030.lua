-- Lua provided by RyzenAPI
-- Game: 549030

-- MAIN APPLICATION
addappid(549030)
-- Game: addappid(549030)

-- MAIN APP DEPOTS / PACKAGES
addappid(549031, 1, "30c063100d265c68bdf2ed97f537c557300572d716cf943326b5bf2ef764bc35")
