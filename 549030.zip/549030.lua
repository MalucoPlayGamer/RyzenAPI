-- Lua provided by SkyAPI 
-- Game: SnipZ
addappid(549030)
addappid(549031, 1, "30c063100d265c68bdf2ed97f537c557300572d716cf943326b5bf2ef764bc35")
