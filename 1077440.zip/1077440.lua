-- Lua provided by RyzenAPI
-- Game: 卡片地下城Card Monsters: Dungeon

-- MAIN APPLICATION
addappid(1077440)
addappid(1077441)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077442,0,"3d51cd807a0c80fdc40ec457fc09915992587ab6fc7a0bf77d74960b8ab0bf1f")
addtoken(1077440,2517089450253364498)

