-- 304770's Lua and Manifest Created by Hubcap Manifest
-- IAH: INTERNET WAR
-- Created: August 21, 2026 at 01:46:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(304770) -- IAH: INTERNET WAR
-- MAIN APP DEPOTS
addappid(304771, 1, "3e159d5e31b4e5b614c9441cd7835442da4a04961fa5904e96c199682ff35c01") -- Depot 304771
setManifestid(304771, "9050904096065934351", 1085222370)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)