-- Lua provided by RyzenAPI
-- Game: IAH: INTERNET WAR

-- MAIN APPLICATION
addappid(304770) -- IAH: INTERNET WAR

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(304771, 1, "3e159d5e31b4e5b614c9441cd7835442da4a04961fa5904e96c199682ff35c01") -- Depot 304771

