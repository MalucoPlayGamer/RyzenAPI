-- Lua provided by RyzenAPI
-- Game: addappid(3311570)

-- MAIN APPLICATION
addappid(3311570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311571, 1, "7c27c950fc9e739f43e85bf5ff98719e003428aa6b18929fdc1ce3e22a02a986")
