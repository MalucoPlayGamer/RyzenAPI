-- Lua provided by RyzenAPI
-- Game: Half-Life: Alyx

-- MAIN APPLICATION
addappid(546560)

-- MAIN APP DEPOTS / PACKAGES
addappid(546561, 1, "08cfa79618da286194c744565ffd27d916e9a4fdea33fc16f3894fc03ec29957")
addappid(546563, 1, "2adb19a4389e7b997da8b54c9cdbdac86a6c9aa1582e436ab36e87f91c61bcb8")
addappid(546564, 1, "42e56a9d859f83e8a4598907e8593c9bc31e73bcdd640fe80f0bf76b6439dedd")
addappid(1295040, 0, "6c054d059310877e4a4f8d5b3eddb04a03e1e01e83812ccabc50a7f493442935")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1270090)
