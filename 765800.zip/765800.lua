-- Lua provided by SkyAPI 
-- Game: Agents: Biohunters
addappid(765800)
addappid(765801, 1, "d0880305a0991dca4272b32c58f4f5b42dba5e66c9bf88aac71f53c41625e8eb")
