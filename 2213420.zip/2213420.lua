-- Lua provided by RyzenAPI
-- Game: addappid(2213420)

-- MAIN APPLICATION
addappid(2213420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213421, 1, "a7c0b231ebee596b5d243bb04f0e8bdc647e31ed623cd81a62cd2a8d8937105d")
