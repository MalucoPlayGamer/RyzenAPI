-- Lua provided by RyzenAPI
-- Game: Skelethrone: The Chronicles of Ericona

-- MAIN APPLICATION
addappid(2139840)
addappid(2917800)
addappid(3499570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2139841, 1, "8e5a3c405ffabd82d236d99d5583d2b3836f045da51e2328b307e3001f8c5977")

