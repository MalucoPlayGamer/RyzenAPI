-- Lua provided by RyzenAPI
-- Game: Epics Of Distant Realm: Director's Cut Edition

-- MAIN APPLICATION
addappid(999350)

-- MAIN APP DEPOTS / PACKAGES
addappid(999351, 1, "fafb72be60608f14ff53d5225de7880713e1ece4801647a48e75180368fab13c")
