-- Lua provided by SkyAPI 
-- Game: How to shoot a criminal
addappid(518130)
addappid(518131, 1, "e1266b3ae767a975358301b0e40288868ce75470f210ca88188fed154c16e0bf")
