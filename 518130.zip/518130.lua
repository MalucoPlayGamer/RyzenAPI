-- Lua provided by RyzenAPI
-- Game: How to shoot a criminal

-- MAIN APPLICATION
addappid(518130)

-- MAIN APP DEPOTS / PACKAGES
addappid(518131, 1, "e1266b3ae767a975358301b0e40288868ce75470f210ca88188fed154c16e0bf")

