-- Lua provided by RyzenAPI
-- Game: AppID 905970

-- MAIN APPLICATION
addappid(905970)

-- MAIN APP DEPOTS / PACKAGES
addappid(905971, 1, "084a7cd54c1fe51a88dd2240c0045acc8af131e2765a8af8319a5a88503b15c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
