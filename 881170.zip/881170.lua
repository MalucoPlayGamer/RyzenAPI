-- Lua provided by RyzenAPI
-- Game: Bloody sand

-- MAIN APPLICATION
addappid(881170)

-- MAIN APP DEPOTS / PACKAGES
addappid(881171, 1, "a7094c1d6de545b2368552128564dc7f41097ff735b7da1e1e348b05c3d8d3f3")

