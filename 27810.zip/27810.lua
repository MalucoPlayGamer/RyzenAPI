-- Lua provided by SkyAPI 
-- Game: AppID 27810
addappid(27810)
addappid(27811, 1, "46db742c39f8ac183ef93d16c4a9cab62b35d0f0bd093db22c910d0071246244")
