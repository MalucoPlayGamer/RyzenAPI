-- Lua provided by RyzenAPI
-- Game: Cat Goes Fishing

-- MAIN APPLICATION
addappid(343780)

-- MAIN APP DEPOTS / PACKAGES
addappid(343781, 1, "58a7298110be7e23962443ba93991143f08c06eb17ab6ed807048ee46e812804")
addappid(343782, 1, "68e4c817ed512f81ebbe6cd84e5156d8fa8ccbaac4c8b7ef7c057d30a2bbe328")
