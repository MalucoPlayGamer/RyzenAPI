-- Lua provided by RyzenAPI
-- Game: AppID 374060

-- MAIN APPLICATION
addappid(374060)

-- MAIN APP DEPOTS / PACKAGES
addappid(374061, 1, "65b7e9f53e3c9fc40f2085c7b586ee7002bf45ae01391a35c2c72dab29d6b139")

