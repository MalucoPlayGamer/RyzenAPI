-- Lua provided by RyzenAPI
-- Game: 1940730

-- MAIN APPLICATION
addappid(1940730)
-- Game: addappid(1940730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940731, 1, "0bee3a5a99cf088c4c09c25c9dd4229aaa88f8e6574c75aabcbd7514db98567f")
addappid(1940732, 1, "44aaf92b4a752f24a8b3bca11f8a4a369efcd5397613489e26ec600effa35c81")
