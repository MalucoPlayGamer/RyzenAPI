-- Lua provided by RyzenAPI
-- Game: Spaceflight Factory : Prologue

-- MAIN APPLICATION
addappid(2219580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2219581, 1, "842714315bfc19980d8d2ef400ed77aaae6ea8e4376762e4632676899b279612")

