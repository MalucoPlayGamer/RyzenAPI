-- Lua provided by SkyAPI 
-- Game: Spaceflight Factory : Prologue
addappid(2219580)
addappid(2219581, 1, "842714315bfc19980d8d2ef400ed77aaae6ea8e4376762e4632676899b279612")
