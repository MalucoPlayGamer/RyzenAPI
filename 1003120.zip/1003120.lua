-- Lua provided by RyzenAPI
-- Game: Hitchhiker - A Mystery Game

-- MAIN APPLICATION
addappid(1003120)
-- Game: addappid(1003120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003121, 1, "8ac29d4388d8b5522c85fb0920e9cf83535459fc643407b6b3c587cda9de69cc")
