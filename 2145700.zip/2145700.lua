-- Lua provided by RyzenAPI
-- Game: Tead

-- MAIN APPLICATION
addappid(2145700)
