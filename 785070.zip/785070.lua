-- Lua provided by RyzenAPI
-- Game: Game: Dig and Shoot

-- MAIN APPLICATION
addappid(785070)
-- Game: addappid(785070)

-- MAIN APP DEPOTS / PACKAGES
addappid(785071, 1, "b79d217e13e3c8ab7c827c395d28dde4b83ae32477294f227da1bc535dce7be3")
