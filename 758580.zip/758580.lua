-- Lua provided by RyzenAPI 
-- Game: Grim Tales: The Wishes Collector's Edition
addappid(758580)
addappid(758581, 1, "1a91552b6fc857eaeab99b50c656534114dd4fe6fd6ee2e5e3c4ef869856f6d9")
