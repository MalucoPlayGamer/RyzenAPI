-- Lua provided by RyzenAPI
-- Game: The Paradixion: Son's Room

-- MAIN APPLICATION
addappid(2415540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415541, 1, "9d9a0d12444e812bba4761437bf8debcb5ff09969419ed13c518d5b09e2375d3")
