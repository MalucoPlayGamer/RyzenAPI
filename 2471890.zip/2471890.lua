-- Lua provided by RyzenAPI
-- Game: 2471890

-- MAIN APPLICATION
addappid(228989)
addappid(229002)
addappid(2471890)
-- Game: addappid(2471890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471892,0,"1be13d7568798a75b0abe67da13bcd29477deb1115413c5cb20a3bf5f9581d90")
