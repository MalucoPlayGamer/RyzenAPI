-- Lua provided by RyzenAPI
-- Game: Nameless ~The one thing you must recall~

-- MAIN APPLICATION
addappid(337930)

-- MAIN APP DEPOTS / PACKAGES
addappid(337932,0,"ea8d3bccfffe832e104bbfd68e3ceb9da58dc8fbbc4418a989886f78ecc7a574")
addappid(414670,0,"3f6d2a1a6dcc015000bc05e2dc45b3bddb99c5a458f9dd699a78c2368cecfa56")
addappid(414671,0,"b7f3044f610511ab6ade06bf46a4825a81514dc70e5d6bb8a046a21d2fcfbaad")
addappid(414672,0,"08ed219f7909136bca388e59fec6a13ffeb19123d3c7c71a880a43c56971ee2e")
addappid(414673,0,"fd9c0bf6e428d10e3b555aadd592f1125eeb15a62d41b0eb54ec9c9f90d50c50")
addappid(414674,0,"43283d833d2fe352ef86451d1f8536bf30557476c71e98cecbe1c36233450455")
addappid(414675,0,"74ec0379a42370d07682cdd5b42d813c0c8a3ddf46d74efc691cc34250ee24d3")
addappid(430200,0,"72ede9dd5fd23a01fa631bab47208eb33239484b22128553b0ff4b18fb8b4145")
