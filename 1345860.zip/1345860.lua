-- Lua provided by RyzenAPI
-- Game: Game: Grapple Dog

-- MAIN APPLICATION
addappid(1345860)
-- Game: addappid(1345860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345861, 1, "a5892c4144e63c4d4ec05ee2449350982223216a54204b90d6258028bb658529")
