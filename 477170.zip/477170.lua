-- Lua provided by RyzenAPI
-- Game: addappid(477170)

-- MAIN APPLICATION
addappid(477170)

-- MAIN APP DEPOTS / PACKAGES
addappid(477171, 1, "147859b3bf5e85b0ab39b7f5d9b85039949bc148f545b58899e8231642e7e8af")
