-- Lua provided by RyzenAPI
-- Game: Trulon: The Shadow Engine

-- MAIN APPLICATION
addappid(433840)

-- MAIN APP DEPOTS / PACKAGES
addappid(433841, 1, "02a4f8785d34cd7c032b7b996fa83edcf3879b26aa6e3b791008db27c6bd5542")
addappid(433842, 1, "9f7b93c52a7178fd932ff3ba2323d875e7f4ff4c02087e9c248c80f7324c65d5")
addappid(433843, 1, "130d4327ad14b1db9867d57f2befe2b964f597d446d09799f620a769af04ddf6")

