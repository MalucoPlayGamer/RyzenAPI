-- Lua provided by RyzenAPI
-- Game: AppID 658920

-- MAIN APPLICATION
addappid(658920)

-- MAIN APP DEPOTS / PACKAGES
addappid(658921, 1, "bf05172a5920c5e1a6ba9874c83a1818cdba9fa1c2a454acbd9f96437d985c2b")
addappid(658922, 1, "d1042677b012a687c3092aa3a9482943d4a7514e0a072371a9bc9f8410f43e89")
addappid(658923, 1, "0583cad37d3743eb5c9c91a9cd24b48462b45729ced4e4ea210bc0401bc3ecb7")
addappid(658924, 1, "140ba2760fef31b67c0559f3a6d6fa4b33a94d6a140bbccd6dc3cf5dece12419")
addappid(658925, 1, "8def9e7d0cc6bbb5284870ff26601645cfe9cf28e585aa729954f8d56776b72a")
addappid(658926, 1, "5e66881dad038b28b36b3f02ebbfa34f7a180e41230daf057bbd4a13136b54e2")
addappid(658927, 1, "e7d83e4b158d82e262516627ec9ecba4574ddd80701291ee80badc62b7d219d4")
addappid(658928, 1, "d1e2312f7b12e07ded09a1427fb188612d5d0f0850bbe5870b140a2a1b9dbf5d")
addappid(658929, 1, "3bd410f89d59c57645e5ed8dc231df53429c5dcee376d0fc289f385f502bce6f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
