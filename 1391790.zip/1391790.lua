-- Lua provided by RyzenAPI
-- Game: Game: Hentai Milf Quiz 2

-- MAIN APPLICATION
addappid(1391790)
-- Game: addappid(1391790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391791, 1, "ae824889557a862879dc48000735e789193cfd2505c6e1404fee9628fdcfe633")
