-- Lua provided by RyzenAPI
-- Game: addappid(1606510)

-- MAIN APPLICATION
addappid(1606510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606511, 1, "f2373192295b19ca15d83ef051c5a088850bfbf348d4817e413bcfc03af2efa3")
