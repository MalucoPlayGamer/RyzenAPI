-- Lua provided by RyzenAPI
-- Game: Cumming Hotel - A Gay Furry Slice of Life

-- MAIN APPLICATION
addappid(1222640)
-- Game: addappid(1222640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222641, 1, "f7d8b396a86d7c8d47142bca1cfef558b9da4ae15751e2cf5c513147fb1ab1ff")
