-- Lua provided by RyzenAPI
-- Game: Game: AppID 3302670

-- MAIN APPLICATION
addappid(3302670)
-- Game: addappid(3302670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3302671, 1, "4b40d27bbee312e382f7bb94e756366e174dc8b24bf9686c5553e0c8eadc67bc")
