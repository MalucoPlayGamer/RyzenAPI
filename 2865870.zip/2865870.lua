-- Lua provided by RyzenAPI
-- Game: 2865870

-- MAIN APPLICATION
addappid(2865870)
-- Game: addappid(2865870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865871, 1, "ffc3d8a605f4d36ecebf4ca84dd42feffc0b4fe1309b12e76ae32104c515719f")
