-- Lua provided by RyzenAPI
-- Game: Tear and the Library of Labyrinths

-- MAIN APPLICATION
addappid(1378040)
-- Game: addappid(1378040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378041, 1, "59109559ea80b4c4ebc3a18ce85496f995fe21a5b5aae371ce9cf5dcdb0b5991")
addappid(1378042, 1, "dc946f90e99e206d8817bead45b19287026a2e4b6e5a26921e09bf4f94fe51dc")
