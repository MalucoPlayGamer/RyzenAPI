-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy 4

-- MAIN APPLICATION
addappid(815950)

-- MAIN APP DEPOTS / PACKAGES
addappid(815951, 1, "4e27df1726f341979a2f08bbfd6a6fb82f699de87ab826a8bef71436bf1cb015")
