-- Lua provided by RyzenAPI
-- Game: Pepper Grinder

-- MAIN APPLICATION
addappid(2076580)
-- Game: addappid(2076580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076581, 1, "51c51af30929f5d1f28fe7b2d6f1b288ea135c7651baa7d28654438d7677429a")
addappid(2076582, 1, "01b04944a748aae3db099e4e691a4def9d16fd057602f7578ea622adf82b8388")
addappid(2076583, 1, "2a97519b9c06d2b2f0b0b75231e4fed81ce0946f48b379c3b6df72f32228c0f2")
