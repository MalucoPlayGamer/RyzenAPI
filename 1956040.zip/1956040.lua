-- Lua provided by RyzenAPI
-- Game: Kingdom Eighties

-- MAIN APPLICATION
addappid(1956040)
-- Game: addappid(1956040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956041, 1, "cb829ec52a7573a20eaa335a7b01e424f4226a180337439b421d9aea9a737d78")
addappid(1956042, 1, "ae1c20735ef4cf00472031c2c4b1253b496b0590095497d53b33c7dc7a3045dd")
addappid(1956043, 1, "8a783d086d9aaccdb6197b7eb9d0fdd31edacccd02a697b12600c9b8d86b0844")
