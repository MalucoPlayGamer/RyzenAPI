-- Lua provided by SkyAPI 
-- Game: Word Rescue
addappid(358340)
addappid(358341, 1, "605965d9cea81a2d80671e7146d853d43787f8ff34564706644b18bac0139a37")
addappid(358342, 1, "0ad5efeffcb32ddfd7dc5f5f04844feb231e6f8d21e1b13bbeab601d39ba46cd")
