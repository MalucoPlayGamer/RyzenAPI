-- Lua provided by RyzenAPI
-- Game: Word Rescue

-- MAIN APPLICATION
addappid(358340)

-- MAIN APP DEPOTS / PACKAGES
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)
addappid(358341, 1, "605965d9cea81a2d80671e7146d853d43787f8ff34564706644b18bac0139a37")
addappid(358342, 1, "0ad5efeffcb32ddfd7dc5f5f04844feb231e6f8d21e1b13bbeab601d39ba46cd")

