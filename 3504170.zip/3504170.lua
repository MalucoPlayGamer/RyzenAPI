-- Lua provided by RyzenAPI 
-- Game: AppID 3504170
addappid(3504170)
addappid(3504171, 1, "af2645a7d5bb99965882a14f409b5c4421d57eef769b14fcbc0d313131001523")
