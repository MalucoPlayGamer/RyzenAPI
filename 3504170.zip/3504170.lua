-- Lua provided by RyzenAPI
-- Game: Emberfly

-- MAIN APPLICATION
addappid(3504170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3504171, 1, "af2645a7d5bb99965882a14f409b5c4421d57eef769b14fcbc0d313131001523")

