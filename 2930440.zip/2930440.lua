-- Lua provided by RyzenAPI
-- Game: AppID 2930440

-- MAIN APPLICATION
addappid(2930440)
-- Game: addappid(2930440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930441, 1, "7dc5c9c4c463840dc09182ca78f7ff84d3e2b0730d369ee5fb5a3c858e651fa6")
