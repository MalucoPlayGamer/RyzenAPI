-- Lua provided by RyzenAPI
-- Game: PopSlinger

-- MAIN APPLICATION
addappid(1928320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928321, 1, "5b38dba5380c7cd4ae788d44d078b387473183136516557ffb60e847c55f750c")
addappid(1928322, 1, "fc9d2ba55bf0a5e1a88cb7816f83ec534efd59ec9bfef0e07091cc1fa2cbcffd")
