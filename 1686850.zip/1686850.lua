-- Lua provided by RyzenAPI
-- Game: Game: Untangle

-- MAIN APPLICATION
addappid(1686850)
-- Game: addappid(1686850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686851, 1, "1644d1422a24a42d83bb004b5f424f7364bd4b8662aff18f7638a0a1bf9d97b6")
