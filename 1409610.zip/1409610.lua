-- Lua provided by RyzenAPI
-- Game: 1409610

-- MAIN APPLICATION
addappid(1409610)
-- Game: addappid(1409610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409611, 1, "e31d2b3ea4926413c9b184e230a19984c4ec2ba5f5d1345d27fd2a63402d991f")
