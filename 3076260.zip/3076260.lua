-- Lua provided by RyzenAPI
-- Game: Game: Candy Factory TD Demo

-- MAIN APPLICATION
addappid(3076260)
-- Game: addappid(3076260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3076261, 1, "382571e5d00678b2007b5512c646359b36d76f2ca53669814cb7a10481e049f3")
