-- Lua provided by RyzenAPI
-- Game: SteamWorld Dig 2

-- MAIN APPLICATION
addappid(571310)
addappid(718690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(571311, 1, "1b60f070267da90c85307a89a4beeade93e99969d36c606e12ece0fc48581fbb")
addappid(571312, 1, "7f0d41d1e1de9763eddf2bbe525add273cd35a7a40d051a48476c1c35a8969e7")
addappid(571313, 1, "15d01ed825fb0a76bb49ae492f421bd685467d99472785da7a8a361aa39b7c09")

