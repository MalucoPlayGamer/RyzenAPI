-- Lua provided by RyzenAPI
-- Game: SteamWorld Dig 2

-- MAIN APPLICATION
addappid(571310)
addappid(718690)

-- MAIN APP DEPOTS / PACKAGES
addappid(571311, 1, "1b60f070267da90c85307a89a4beeade93e99969d36c606e12ece0fc48581fbb")
addappid(571312, 1, "7f0d41d1e1de9763eddf2bbe525add273cd35a7a40d051a48476c1c35a8969e7")
addappid(571313, 1, "15d01ed825fb0a76bb49ae492f421bd685467d99472785da7a8a361aa39b7c09")
