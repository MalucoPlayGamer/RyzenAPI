-- Lua provided by RyzenAPI
-- Game: Saloon VR

-- MAIN APPLICATION
addappid(1014970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1014971, 1, "f3f7e86d13fc3bf0d7976e633c86f18528813515ebef9e3343e06fb50932b2c9")
addappid(1038090, 0, "45966973ae106de1b51330de65304e44ed08933ba0a969163fcfcd269c0a432a")

