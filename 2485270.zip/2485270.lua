-- Lua provided by RyzenAPI
-- Game: 2485270

-- MAIN APPLICATION
addappid(2485270)
-- Game: addappid(2485270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485271, 1, "c432b61d21b858076d2ec376d6d711e9c3afe58aff81bba157e9f3743ee9fca7")
