-- Lua provided by RyzenAPI
-- Game: ENIGMA : An Illusion Named Family

-- MAIN APPLICATION
addappid(355570)
addappid(355571)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985,0,"21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229004,0,"56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0")
addappid(229033,0,"9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3")

