-- Lua provided by RyzenAPI
-- Game: addappid(2952240)

-- MAIN APPLICATION
addappid(2952240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2952240,0,"45b57c147df1c9b9b81ceedadb09804cfbb92f5974064802089737658d4c2e2b")
