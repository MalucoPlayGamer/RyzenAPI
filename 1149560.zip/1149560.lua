-- Lua provided by RyzenAPI
-- Game: addappid(1149560)

-- MAIN APPLICATION
addappid(1149560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149561, 1, "45bde1fd225fc7fb7f89fbbc1206e5259a724cabfdf2655d4c1a7cd38b90a6d9")
