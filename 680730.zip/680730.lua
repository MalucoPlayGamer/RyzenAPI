-- Lua provided by RyzenAPI
-- Game: 680730

-- MAIN APPLICATION
addappid(680730)
-- Game: addappid(680730)

-- MAIN APP DEPOTS / PACKAGES
addappid(680731, 1, "319352c0d88cf9ce587a1bb64e01f56a4e8ab54ec80480d98cf7b7fc73cd28d0")
