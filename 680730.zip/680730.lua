-- Lua provided by RyzenAPI 
-- Game: Plight
addappid(680730)
addappid(680731, 1, "319352c0d88cf9ce587a1bb64e01f56a4e8ab54ec80480d98cf7b7fc73cd28d0")
