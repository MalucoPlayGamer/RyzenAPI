-- Lua provided by RyzenAPI
-- Game: Mystery Stone from Heaven

-- MAIN APPLICATION
addappid(744630)
-- Game: addappid(744630)

-- MAIN APP DEPOTS / PACKAGES
addappid(744631, 1, "835f0dc36ae752dad75129edec5180d502708be431f43d3472cac1213798d319")
