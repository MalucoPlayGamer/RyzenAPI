-- Lua provided by RyzenAPI
-- Game: 2475750

-- MAIN APPLICATION
addappid(2475750)
-- Game: addappid(2475750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475751, 1, "0795ae7564c5e15b38207e37dadc16fc127d4bb1cd7737c77a8a818b52e14ad6")
