-- Lua provided by RyzenAPI
-- Game: 1219650

-- MAIN APPLICATION
addappid(1219650)
-- Game: addappid(1219650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219651, 1, "2a43aa1f543bae158955db45ccdce117c02fec6709536080e771c8aea09ce3fb")
