-- Lua provided by RyzenAPI
-- Game: 2813710

-- MAIN APPLICATION
addappid(2813710)
-- Game: addappid(2813710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2813711, 1, "4f0dd886bf35e4cd7a1f84358d06296a3853f7dd9a081677916c9915178d8eea")
addappid(2813712, 1, "faa6d4e61ed5b537f8ae6677bd2f57e0c47b03218f92dc023f7db50abbccf764")
