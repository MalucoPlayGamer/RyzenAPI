-- Lua provided by RyzenAPI
-- Game: Game: BattleBit Remastered Playtest

-- MAIN APPLICATION
addappid(1611740)
-- Game: addappid(1611740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611741, 1, "d4d75966e5595be6200af52fc99d2a14f7f139824b6057ebc3af6c3ee1fd0839")
