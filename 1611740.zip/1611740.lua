-- Lua provided by SkyAPI 
-- Game: BattleBit Remastered Playtest
addappid(1611740)
addappid(1611741, 1, "d4d75966e5595be6200af52fc99d2a14f7f139824b6057ebc3af6c3ee1fd0839")
