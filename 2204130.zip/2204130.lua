-- Lua provided by RyzenAPI
-- Game: Sid Meier's Alpha Centauri™ Planetary Pack

-- MAIN APPLICATION
addappid(2204130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2204131, 1, "71d6d70599b452f6f5642b031a2f455a1bfed3f540f04e5334c90e6f3d6619a5")
addappid(2204132, 1, "0839f412821152ee480d9e2b0b26fc6ec21d7d231de82248ddc0b3f776329c63")

