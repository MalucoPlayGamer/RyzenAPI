-- Lua provided by SkyAPI 
-- Game: Sid Meier's Alpha Centauri™ Planetary Pack
addappid(2204130)
addappid(2204131, 1, "71d6d70599b452f6f5642b031a2f455a1bfed3f540f04e5334c90e6f3d6619a5")
addappid(2204132, 1, "0839f412821152ee480d9e2b0b26fc6ec21d7d231de82248ddc0b3f776329c63")
