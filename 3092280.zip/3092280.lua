-- Lua provided by RyzenAPI
-- Game: Guardians Of Restoration

-- MAIN APPLICATION
addappid(3092280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092281, 1, "f88fae1546d822a1e8419c6f668fcca24f5f199d32a433a8499b02809cba8fe9")
