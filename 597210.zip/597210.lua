-- Lua provided by RyzenAPI
-- Game: Bayou Island - Point and Click Adventure

-- MAIN APPLICATION
addappid(597210)

-- MAIN APP DEPOTS / PACKAGES
addappid(597211,0,"a2d0d3ec27b2611762dc36d17c6dae45b36485e3b491c82483d6c4aa9395a84d")

