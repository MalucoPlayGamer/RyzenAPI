-- Lua provided by RyzenAPI
-- Game: Box Office Mayhem: Theatre Tycoon

-- MAIN APPLICATION
addappid(4572730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4572731,0,"0df331b1f9ed41408d48a167ee3447d23c4a2dff50c532de1ac52ac57475b05e")

