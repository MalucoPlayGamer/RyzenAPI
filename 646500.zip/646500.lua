-- Lua provided by RyzenAPI
-- Game: Egypt: Old Kingdom

-- MAIN APPLICATION
addappid(646500)

-- MAIN APP DEPOTS / PACKAGES
addappid(646501, 1, "038f7283e1e87ce42dbb136be2b87c950108a34c238864cebb0e3bf833efc78a")
addappid(646502, 1, "f6c44b727d54dd16604ecaa2af616e6b3d416603bd3c100c39bee775d89167c5")
addappid(646503, 1, "5f94340feeedba7b3313bdc39132351184b5133bf26c37fe35fd2ec35a8a87ee")
addappid(646504, 1, "913afd55523adf7d103de21cf8ba9912677ddce912a084a8b838e12e3f8d5e32")
addappid(844470, 0, "12822d3b4f6edf10c23ac308b8983ba4858d2f7d8d500a12463312a3c90b6266")
addappid(844480, 0, "62535c9e442b1225fd52264e2f8da3eaa66c08a5a15e964758f9b0f6f974f72e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(932780)
