-- Lua provided by RyzenAPI
-- Game: Midnight Ghost Hunt Soundtrack

-- MAIN APPLICATION
addappid(1951320)
-- Game: addappid(1951320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951321, 1, "aba343df1c9b9b9b2474aaf6ea2b3487732782e3e683889133b8c5e94555ce3f")
