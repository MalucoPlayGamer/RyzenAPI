-- Lua provided by RyzenAPI
-- Game: Game: TYRONE SOULZ

-- MAIN APPLICATION
addappid(2585050)
-- Game: addappid(2585050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585051, 1, "d413abe421dba2fcd608125ebb0ac06ebf8b8ce0586c8bb74259859b9c14738e")
addappid(2796840, 0, "6db4c3116ee16a022dcd06458319d2e5eddb44c1dd2b221490e025b374195905")
