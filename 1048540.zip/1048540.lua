-- Lua provided by RyzenAPI
-- Game: Game: Kao the Kangaroo: Round 2 (2003 re-release)

-- MAIN APPLICATION
addappid(1048540)
-- Game: addappid(1048540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048541, 1, "2a805f50e38282567abf3c50a4e61e11886633220e2b88399ec25c87db6038c7")
