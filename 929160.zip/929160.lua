-- Lua provided by RyzenAPI
-- Game: The King's Bird - Original Soundtrack

-- MAIN APPLICATION
addappid(929160)

-- MAIN APP DEPOTS / PACKAGES
addappid(929161, 1, "eb3b4e969bc8931c9301db979303f234b44f991404e80406714ec51379c0cef1")
