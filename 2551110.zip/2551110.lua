-- Lua provided by RyzenAPI
-- Game: Combat Mission Fortress Italy

-- MAIN APPLICATION
addappid(2551110)
addappid(2551120)
addappid(2551140)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2551111, 1, "fa43efda5fd9b2d0e460e6a782d21f9f56fa03b5ba7b382de44342987c66f423")
addappid(2551112, 1, "4c3a98847206aeb8240228fa05041c277d693e96e7516ed375dc521fa2c3ae7c")

