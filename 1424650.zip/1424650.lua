-- Lua provided by RyzenAPI
-- Game: Flicker

-- MAIN APPLICATION
addappid(1424650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424651,0,"cc735534a906f85ed29d907c10f277641cee39d32206bd4d799ec3d3065d5c97")

