-- Lua provided by RyzenAPI
-- Game: Flicker

-- MAIN APPLICATION
addappid(1424650)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(1424651,0,"cc735534a906f85ed29d907c10f277641cee39d32206bd4d799ec3d3065d5c97")

