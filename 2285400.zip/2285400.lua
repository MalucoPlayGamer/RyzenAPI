-- Lua provided by RyzenAPI
-- Game: Towers Together: Beginnings

-- MAIN APPLICATION
addappid(2285400)
addappid(2415940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285402,0,"bb9d929b72f806c2f72adebb169d1c54de457713576f641955eff85ed09b8fc8")
addappid(2285403,0,"9df33c92843a58bb95a90e0beac36c67042dd28b47ccac4ed8a487a31ee46515")

