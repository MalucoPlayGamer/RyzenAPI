-- Lua provided by RyzenAPI
-- Game: addappid(3127660)

-- MAIN APPLICATION
addappid(3127660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127661, 1, "debd68ffcb2956aa00be3e17d1a157e8dce5109e6e3fe523eaa62f3a9af41c88")
