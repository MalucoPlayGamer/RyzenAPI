-- Lua provided by RyzenAPI
-- Game: AppID 2736950

-- MAIN APPLICATION
addappid(2736950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736951, 1, "c745194475bcb4ccda0d0f7e815f2ad1d9029edda7d95e7c62c6e1d279750772")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
