-- Lua provided by RyzenAPI 
-- Game: AppID 2736950
addappid(2736950)
addappid(2736951, 1, "c745194475bcb4ccda0d0f7e815f2ad1d9029edda7d95e7c62c6e1d279750772")
