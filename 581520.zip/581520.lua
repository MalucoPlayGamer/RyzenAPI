-- Lua provided by RyzenAPI
-- Game: Sakura Magical Girls

-- MAIN APPLICATION
addappid(581520)

-- MAIN APP DEPOTS / PACKAGES
addappid(581521, 1, "670935fda637bf2365c87abe6d5d1379e80e9606edd02ae92d8cd479152293ff")

