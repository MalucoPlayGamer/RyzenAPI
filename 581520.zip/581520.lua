-- Lua provided by SkyAPI 
-- Game: Sakura Magical Girls
addappid(581520)
addappid(581521, 1, "670935fda637bf2365c87abe6d5d1379e80e9606edd02ae92d8cd479152293ff")
