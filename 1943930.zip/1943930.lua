-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Futanari BDSM

-- MAIN APPLICATION
addappid(1943930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943931, 1, "08ae70ab8997bfb180152011ce9cf3b5d29353962c3554a3ce0d183712dfbeb9")

