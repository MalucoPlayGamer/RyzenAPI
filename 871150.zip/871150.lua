-- Lua provided by RyzenAPI
-- Game: Noble Crusade

-- MAIN APPLICATION
addappid(871150)

-- MAIN APP DEPOTS / PACKAGES
addappid(871151,0,"4481eb2c221b1ca26bc98c37656c40fd60d8942fb2d3753d5a87728d9d92e653")

