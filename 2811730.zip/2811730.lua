-- Lua provided by RyzenAPI 
-- Game: V-Girl Kayla
addappid(2811730)
addappid(2811731, 1, "56dc2e10e0c62be2235c74c581e8903d5c170e085793a5c30a70c094874df3a8")
