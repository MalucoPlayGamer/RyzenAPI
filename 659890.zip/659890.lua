-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 17: New Palette

-- MAIN APPLICATION
addappid(659890)

-- MAIN APP DEPOTS / PACKAGES
addappid(659891,0,"142e4a8e8e8f25911ae35302ba90b573e858d9a0d4a836f3738999c00855f70e")

