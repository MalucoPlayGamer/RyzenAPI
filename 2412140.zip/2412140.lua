-- Lua provided by RyzenAPI
-- Game: Sex with Maids

-- MAIN APPLICATION
addappid(2412140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412141, 1, "c8e4bf0f6ad7c9dd1aa56c83ef376ced76098dc63c4792aa6ae492bc4c1b423a")

