-- Lua provided by RyzenAPI
-- Game: addappid(1964940)

-- MAIN APPLICATION
addappid(1964940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964941, 1, "4c6c7967f8cc4a9b7d61e352d013bb280cf527d9a7299fb5ae4daf06842d6f74")
