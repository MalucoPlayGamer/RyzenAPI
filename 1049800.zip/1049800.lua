-- Lua provided by RyzenAPI 
-- Game: BLOCKADE
addappid(1049800)
addappid(1049801, 1, "2419875fd070b18e891c1624ea9cde7c3042895fbbd67d993776fe782e94f621")
