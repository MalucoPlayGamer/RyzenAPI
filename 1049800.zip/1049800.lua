-- Lua provided by RyzenAPI
-- Game: BLOCKADE

-- MAIN APPLICATION
addappid(1049800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1049801, 1, "2419875fd070b18e891c1624ea9cde7c3042895fbbd67d993776fe782e94f621")

