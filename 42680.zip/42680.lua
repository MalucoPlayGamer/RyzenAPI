-- Lua provided by RyzenAPI
-- Game: Call of Duty®: Modern Warfare® 3 (2011)

-- MAIN APPLICATION
addappid(42729) -- Call of Duty Modern Warfare Collection 1 (Preorder) DLC

-- MAIN APP DEPOTS / PACKAGES
addappid(42680, 1, "4bf2d9294f477df1327e22e5efe65d98eca4d4592f0dc59fa451ab8ca8608fde") -- Call of Duty®: Modern Warfare® 3 (2011)
addappid(42681, 1, "b7003c5ea7e370881499daaf5ba52ea4f3a1e76843fb37ab4d97753d94df8f95") -- Call of Duty Modern Warfare 3 SP Binaries
addappid(42682, 1, "a7f0704e4a61083d1ef176c1efe2666a1e694ca4a2e40c17dda9f6c7a9ecceb1") -- Call of Duty Modern Warfare 3 Content (Shared from App 42690)
addappid(42683, 1, "252c3bce60c362e7fdb65dabb24a8f0f6d3098ef341315df1a9f2208c8550c9f") -- Call of Duty Modern Warfare 3 english (Shared from App 42690)
addappid(42684, 1, "7f904784b8e0755738fd4e3a4ade829396e449060bfd09275dd380dcff422703") -- Call of Duty Modern Warfare 3 spanish (Shared from App 42690)
addappid(42685, 1, "55cf38352373d9669395acabad606ab665e82d0421b28dc2c39003055f91ac5f") -- Call of Duty Modern Warfare 3 german (Shared from App 42690)
addappid(42686, 1, "1a676d3458091a765385fd997ed2171aeb13045296927c26c6a7bdebba7a3504") -- Call of Duty Modern Warfare 3 french (Shared from App 42690)
addappid(42687, 1, "308eb88b20769f215eb317cc8cae34f4e7a4cc74d74e8a04262275dbe41f5eca") -- Call of Duty Modern Warfare 3 italian (Shared from App 42690)
addappid(42688, 1, "a86e1ec84e71aad3a8c1b3fc2f3a237906eb6de447510da925db20173fb6b724") -- Call of Duty Modern Warfare 3 Russian (Shared from App 42690)
addappid(42689, 1, "5562719fd8e66322c45af3e1b327211c2dd815edd340bd6969a0dac1ebad018f") -- Call of Duty Modern Warfare 3 Japanese (Shared from App 42690)
addappid(42692, 1, "9c172487a1111e79908452b7cbbb680a070c482754b41be716278f44d681586d") -- Call of Duty Modern Warfare 3 Polish (Shared from App 42690)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(278310, 1, "c79da57207ccf933258ced455e9793b8ca10fdcd38300181226173ee705fe71b") -- Call of Duty: Modern Warfare 3 suitcase Content (Shared from App 42690)
addappid(278312, 1, "ab950813ce8448c02aad504c486513a86c03aa55bde084c7c6be8f6ca2b71966") -- Call of Duty: Modern Warfare 3 suitcase English (Shared from App 42690)
addappid(278313, 1, "fac16c89e3e4731296e3017b59a98ba16fa82ac1eca6b432fb0134639fbcc721") -- Call of Duty: Modern Warfare 3 suitcase Spanish (Shared from App 42690)
addappid(278314, 1, "bba43dbf20aca5543940151e8cf815cc535967d8091a6e2a777a4486bb5410a4") -- Call of Duty: Modern Warfare 3 suitcase German (Shared from App 42690)
addappid(278315, 1, "ab5bc1898a3c4805ce627fada0b379a4854a291ac920846e1505fcd7ace6b422") -- Call of Duty: Modern Warfare 3 suitcase French (Shared from App 42690)
addappid(278316, 1, "654ea6858de9296fc3d260a92db3c6c51acfdda38afd672784f6b5907a2b9ab6") -- Call of Duty: Modern Warfare 3 suitcase Italian (Shared from App 42690)
addappid(278331, 1, "0e8c2e3857ffb4d0cca47f5cf07ccbe8ee9e2ccc66be7ac744d1fa5167745310") -- Call of Duty: Modern Warfare 3 suitcase SP Binary

