-- Lua provided by RyzenAPI
-- Game: Call of Duty®: Modern Warfare® 3 (2011)

-- MAIN APPLICATION
addappid(42680)
addappid(278310)
addappid(278312)
addappid(278313)
addappid(278314)
addappid(278315)
addappid(278316)

-- MAIN APP DEPOTS / PACKAGES
addappid(42681, 1, "b7003c5ea7e370881499daaf5ba52ea4f3a1e76843fb37ab4d97753d94df8f95")
addappid(278331, 0, "0e8c2e3857ffb4d0cca47f5cf07ccbe8ee9e2ccc66be7ac744d1fa5167745310")
