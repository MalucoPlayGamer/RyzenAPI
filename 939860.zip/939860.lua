-- Lua provided by RyzenAPI
-- Game: addappid(939860)

-- MAIN APPLICATION
addappid(939860)

-- MAIN APP DEPOTS / PACKAGES
addappid(939860,0,"8aff9378e2c3f8ccb84707e97950223c53b0953a2fb327aef395219c1dab21a6")
