-- Lua provided by RyzenAPI
-- Game: This Game is Trash

-- MAIN APPLICATION
addappid(1385050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385051, 1, "8f934fd61615c58607c83cb7e19e4e10a730bc2604e4788bbda5be181e591600")

