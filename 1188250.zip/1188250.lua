-- Lua provided by RyzenAPI
-- Game: Game: AppID 1188250

-- MAIN APPLICATION
addappid(1188250)
-- Game: addappid(1188250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188251, 1, "2c1faaa685b6ae21d2b46760e0a6533980470f7918c6d4e8c6c712f0676312ac")
