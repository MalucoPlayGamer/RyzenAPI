-- Lua provided by SkyAPI 
-- Game: AppID 1188250
addappid(1188250)
addappid(1188251, 1, "2c1faaa685b6ae21d2b46760e0a6533980470f7918c6d4e8c6c712f0676312ac")
