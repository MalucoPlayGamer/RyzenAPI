-- Lua provided by RyzenAPI
-- Game: Hogtie

-- MAIN APPLICATION
addappid(3054330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054332,0,"8b42592e2548cd623391401848e6589619e4b52e1baf25628552a8fb3cb4bf58")

