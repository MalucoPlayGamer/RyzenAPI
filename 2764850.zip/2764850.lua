-- Lua provided by RyzenAPI
-- Game: 2764850

-- MAIN APPLICATION
addappid(2764850)
-- Game: addappid(2764850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764851, 1, "7437415b95b4511a2e58e3fcbb48d169c52e8bfb47646a84aa9ac36e85db67ca")
