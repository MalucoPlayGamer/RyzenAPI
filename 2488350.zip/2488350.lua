-- Lua provided by RyzenAPI
-- Game: Digital Mate

-- MAIN APPLICATION
addappid(2488350)
-- Game: addappid(2488350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488351, 1, "a48a1e461280d0554315b244a78235d8d09a853404075a88e0536d9ce9135a98")
