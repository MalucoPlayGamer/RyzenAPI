-- Lua provided by RyzenAPI
-- Game: Digital Mate

-- MAIN APPLICATION
addappid(2488350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488351, 1, "a48a1e461280d0554315b244a78235d8d09a853404075a88e0536d9ce9135a98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
