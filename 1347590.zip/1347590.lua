-- Lua provided by RyzenAPI
-- Game: Game: AppID 1347590

-- MAIN APPLICATION
addappid(1347590)
-- Game: addappid(1347590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347591, 1, "f02017560df639b7c390d32acd50c621e3bd3e398441d5a91f820431a6c4986b")
