-- Lua provided by RyzenAPI
-- Game: AppID 926540

-- MAIN APPLICATION
addappid(926540)

-- MAIN APP DEPOTS / PACKAGES
addappid(926541, 1, "534f3e51476067700c56126c13fa5c121944bf0d819e8ba94a948d4916d003f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
