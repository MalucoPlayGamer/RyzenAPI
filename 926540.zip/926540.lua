-- Lua provided by RyzenAPI 
-- Game: AppID 926540
addappid(926540)
addappid(926541, 1, "534f3e51476067700c56126c13fa5c121944bf0d819e8ba94a948d4916d003f6")
