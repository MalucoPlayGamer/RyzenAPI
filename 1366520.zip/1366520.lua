-- Lua provided by RyzenAPI 
-- Game: Dungeon Limbus
addappid(1366520)
addappid(1366521, 1, "52fae12e9f36cb729c8965b7759e0fcfdb95bce0c9b25620f4594f8a8c2ac93d")
