-- Lua provided by RyzenAPI
-- Game: Piero's Pilgrimage

-- MAIN APPLICATION
addappid(1948390)
-- Game: addappid(1948390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948391, 1, "bbc5d29b77eed25da5a8ab61eb335fc91de6239bbf2cc15ead295c810820f04e")
