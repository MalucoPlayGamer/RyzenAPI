-- Lua provided by RyzenAPI
-- Game: Transformers: War for Cybertron

-- MAIN APPLICATION
addappid(42650)

-- MAIN APP DEPOTS / PACKAGES
addappid(42651, 1, "295314c86ab608248f633c533681f8a81ba3b92d83fc63b73310682ce86e8cf0")
addappid(42652, 1, "1246ef4fb25dc8a0b7ae851bfe97a01c1b0a7a0bccacb5ee1d0d308d8355a245")
addappid(42653, 1, "fb9f8a7dc611c09afde4ac3d51c998e37276c8441ab609eabba12ef23e4ca022")
addappid(42654, 1, "c1649d5381f0ef1412c74628609ea5b5f24ff07e4dc8ba37cdfb914f862c96fe")
addappid(42655, 1, "9ef03a89cf687750f1bf442acc81a243f0860634275fa24b876bb77d16495660")

