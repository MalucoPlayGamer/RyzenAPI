-- Lua provided by SkyAPI 
-- Game: Desynced
addappid(1450900)
addappid(1450901, 1, "d9a1fcf1a5247619a996fda01bbd2cf2143fa24e234d4cbf0973f8eebf062d03")
