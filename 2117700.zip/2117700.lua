-- Lua provided by RyzenAPI
-- Game: 2117700

-- MAIN APPLICATION
addappid(2117700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117700,0,"3311f14e7d3090cb9b87e58bf8bfdc5d2b2e29c88b375c2242fcbaeb65f1eaf2")
