-- Lua provided by RyzenAPI
-- Game: Game: Zooma Demo

-- MAIN APPLICATION
addappid(1554800)
-- Game: addappid(1554800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554801, 1, "8624a119217b8cb13398b494d8ea77a2d2933aa8e6b8946e9f575aac690b09e4")
