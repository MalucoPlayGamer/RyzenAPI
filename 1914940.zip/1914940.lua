-- Lua provided by RyzenAPI
-- Game: Zhijiang Town

-- MAIN APPLICATION
addappid(1914940)
-- Game: addappid(1914940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914941, 1, "32f6fe4e7334f70abf81a81192cc05b777d33eb960c491a1422fcba81209b060")
