-- Lua provided by RyzenAPI 
-- Game: Zhijiang Town
addappid(1914940)
addappid(1914941, 1, "32f6fe4e7334f70abf81a81192cc05b777d33eb960c491a1422fcba81209b060")
