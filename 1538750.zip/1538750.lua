-- Lua provided by RyzenAPI
-- Game: Master of Pieces © Jigsaw Puzzle

-- MAIN APPLICATION
addappid(1538750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538751, 1, "df53e0bfd8a107051574ea1060308db39a9062036297f83301b498618b6067f6")

