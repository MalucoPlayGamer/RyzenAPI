-- Lua provided by RyzenAPI
-- Game: Blood Rage: Digital Edition

-- MAIN APPLICATION
addappid(1015930)
addappid(1282300)
addappid(1354120)
addappid(1366580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015931,0,"72a196821c2913524553307029de3543c0262b7b49cd842801f736bbeb499c2f")
addappid(1015932,0,"42d7d99a7e401fdd701668144338e062e620ebff686cacf8b01e8eb9047e0a30")

