-- Lua provided by RyzenAPI
-- Game: 1217050

-- MAIN APPLICATION
addappid(1217050)
-- Game: addappid(1217050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217051, 1, "256b0e3d0c58c82bc7bd03d267216246af37aea3e5fb889d8ccf599f942d59ee")
