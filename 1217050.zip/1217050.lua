-- Lua provided by RyzenAPI
-- Game: Shaolin vs Wutang 2

-- MAIN APPLICATION
addappid(1217050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217051, 1, "256b0e3d0c58c82bc7bd03d267216246af37aea3e5fb889d8ccf599f942d59ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
