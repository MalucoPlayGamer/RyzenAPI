-- Lua provided by RyzenAPI
-- Game: Game: BORE BLASTERS

-- MAIN APPLICATION
addappid(2398170)
-- Game: addappid(2398170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398171, 1, "17a13058c9b92ec2d622ec63e9e8535e28fcfa051ab2df613ca72f72d422fa8e")
