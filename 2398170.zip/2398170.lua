-- Lua provided by SkyAPI 
-- Game: BORE BLASTERS
addappid(2398170)
addappid(2398171, 1, "17a13058c9b92ec2d622ec63e9e8535e28fcfa051ab2df613ca72f72d422fa8e")
