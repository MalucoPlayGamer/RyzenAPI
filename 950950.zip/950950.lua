-- Lua provided by RyzenAPI
-- Game: In The Dark

-- MAIN APPLICATION
addappid(950950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(950951, 1, "fad0fd29842aea98dbc2930d4a811a0aa4c548614a90c2f558a2cecff3cd455e")

