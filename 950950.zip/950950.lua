-- Lua provided by RyzenAPI
-- Game: addappid(950950)

-- MAIN APPLICATION
addappid(950950)

-- MAIN APP DEPOTS / PACKAGES
addappid(950951, 1, "fad0fd29842aea98dbc2930d4a811a0aa4c548614a90c2f558a2cecff3cd455e")
