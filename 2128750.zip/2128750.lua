-- Lua provided by RyzenAPI
-- Game: Your Waifu JUICE

-- MAIN APPLICATION
addappid(2128750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128751, 1, "f0b83f48f9bf2d08e47b71249aa9811f4332af57139a9613ffea95b3387dba8b")
