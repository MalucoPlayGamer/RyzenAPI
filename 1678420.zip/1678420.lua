-- Lua provided by RyzenAPI
-- Game: Blade Runner: Enhanced Edition

-- MAIN APPLICATION
addappid(1678420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678421, 1, "7d4a4829b8106b692a3bcab2491052b136c5e7ee7477bb80526fc5242f42f1df")
addappid(1678422, 1, "c1548261a662b36db241fa5d50339dfd82dcf169632b263608c6e779864cc40d")
addappid(1678425, 1, "82fe057fc5cb02ebf85caefc495bf23b41eeee63eea1bb69f8d98e40bc777d70")
addappid(1678426, 1, "883242b885084ff467582bca350314b3a11b0fa08b8403d1e1bceeee25d820cd")
addappid(1678429, 1, "569cc56ab0ef1b683086b982618673c22d42b29039a1f26dcfb7551570c07cc6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
