-- Lua provided by RyzenAPI
-- Game: addappid(2027540)

-- MAIN APPLICATION
addappid(2027540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027541, 1, "a4f1f8451b982d4e34b40f8db4f6b89d9ca08dd62b384728d53ac4095684e669")
