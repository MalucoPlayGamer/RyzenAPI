-- Lua provided by RyzenAPI
-- Game: Escape From Tethys

-- MAIN APPLICATION
addappid(822540)

-- MAIN APP DEPOTS / PACKAGES
addappid(822541, 1, "f16e388ce9b212dd3fbc337fcb4db9550aa9512141ddc9f293b6a3aa2dcee7b7")
addappid(822542, 1, "6d74cb5a806c10a768304499bc642f038adaff7b329e19e79b86c254608043e0")

