-- Lua provided by RyzenAPI
-- Game: Beast Quest

-- MAIN APPLICATION
addappid(707060)

-- MAIN APP DEPOTS / PACKAGES
addappid(707061, 1, "6c25a39c5b1da35b625c9b993b931ea872d9cdafeaedd74ce4a9532ab24ce428")
