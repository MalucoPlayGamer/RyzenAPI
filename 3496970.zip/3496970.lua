-- Lua provided by RyzenAPI
-- Game: Gloopalaxy

-- MAIN APPLICATION
addappid(3496970) -- Gloopalaxy

-- MAIN APP DEPOTS / PACKAGES
addappid(3496971, 1, "ac514bcb8e9599f79ac2abdf6c13a3588dd42391658c819ecbed3dc99d6b08f9") -- Depot 3496971
addappid(3496972, 1, "3ceef0626939f9485cc432277e2a123e95a20628a169feb058fcca9207a29dfe") -- Depot 3496972

