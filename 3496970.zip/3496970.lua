-- 3496970's Lua and Manifest Created by Hubcap Manifest
-- Gloopalaxy
-- Created: August 05, 2026 at 22:37:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3496970) -- Gloopalaxy
-- MAIN APP DEPOTS
addappid(3496971, 1, "ac514bcb8e9599f79ac2abdf6c13a3588dd42391658c819ecbed3dc99d6b08f9") -- Depot 3496971
setManifestid(3496971, "781775886335286610", 408031872)
addappid(3496972, 1, "3ceef0626939f9485cc432277e2a123e95a20628a169feb058fcca9207a29dfe") -- Depot 3496972
setManifestid(3496972, "4278585268469744511", 449348991)