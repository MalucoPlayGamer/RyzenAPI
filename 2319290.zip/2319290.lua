-- Lua provided by RyzenAPI
-- Game: addappid(2319290)

-- MAIN APPLICATION
addappid(2319290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319292,0,"2112c1e66d68008a61f01ecfe3d029ac72aa71d725278ddca5dff4d43b688f41")
