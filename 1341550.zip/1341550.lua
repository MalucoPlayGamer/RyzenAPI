-- Lua provided by SkyAPI 
-- Game: PORN Handyman VR
addappid(1341550)
addappid(1341551, 1, "09c9599f8e726f6db99b50a92c0b0fa327ecf426c2b9c25f8794401509880213")
