-- Lua provided by RyzenAPI
-- Game: PORN Handyman VR

-- MAIN APPLICATION
addappid(1341550)
-- Game: addappid(1341550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341551, 1, "09c9599f8e726f6db99b50a92c0b0fa327ecf426c2b9c25f8794401509880213")
