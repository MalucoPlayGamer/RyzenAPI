-- Lua provided by RyzenAPI
-- Game: Choice of Life: Middle Ages 2 Demo

-- MAIN APPLICATION
addappid(1893270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893271, 1, "350e75b7b7eb161bdbe137c645a690e2704ebe9d2a388721fbcf226451860a0b")

