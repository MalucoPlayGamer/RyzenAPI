-- Lua provided by RyzenAPI
-- Game: Pioneers of Pagonia - Original Soundtrack

-- MAIN APPLICATION
addappid(2717840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717841, 1, "37319f57ffc9a1b365542ae1c02e0c70f9eff1a15fc18c6080e0ec9645485be1")
addappid(2717842, 1, "0dd4dc4650cf05fafd60f307e5c062e69513347a6c2f5308c856aca7db2a76a6")

