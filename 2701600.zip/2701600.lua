-- Lua provided by RyzenAPI
-- Game: Together We Live Soundtrack

-- MAIN APPLICATION
addappid(2701600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701601, 1, "f53e7d279fec9da6ef033173a897b3fd30bef1dd7003049a5cc7775aa13600a0")
