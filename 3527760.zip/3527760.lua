-- Lua provided by RyzenAPI
-- Game: RoboCop: Rogue City - Unfinished Business

-- MAIN APPLICATION
addappid(3527760)
addappid(3743240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3527761, 1, "851a0c3de06eeeaeed120d257ac3f74e137b4f5ff28ae34aca458410807cd52b")

