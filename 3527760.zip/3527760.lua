-- Lua provided by RyzenAPI
-- Game: RoboCop: Rogue City - Unfinished Business

-- MAIN APPLICATION
addappid(3527760)
addappid(3743240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3527761, 1, "851a0c3de06eeeaeed120d257ac3f74e137b4f5ff28ae34aca458410807cd52b")

