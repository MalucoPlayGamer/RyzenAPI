-- Lua provided by RyzenAPI 
-- Game: BounceShot
addappid(1736980)
addappid(1736981, 1, "49618d06b4f236a92d2417a0717985c7b59cebb0824a5d872fb8a2544efd2f77")
