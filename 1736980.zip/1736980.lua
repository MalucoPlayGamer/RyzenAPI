-- Lua provided by RyzenAPI
-- Game: BounceShot

-- MAIN APPLICATION
addappid(1736980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736981, 1, "49618d06b4f236a92d2417a0717985c7b59cebb0824a5d872fb8a2544efd2f77")
