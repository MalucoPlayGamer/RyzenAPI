-- Lua provided by RyzenAPI
-- Game: AppID 1544680

-- MAIN APPLICATION
addappid(1544680)
-- Game: addappid(1544680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544681, 1, "6ba706a1c7e7669f131f3dea8d00a5cc7ec5b1954a1e085cb2b8766877635fda")
