-- Lua provided by SkyAPI 
-- Game: AppID 1023700
addappid(1023700)
addappid(1023701, 1, "bef59db81976c72a2a486c99185ac7d8b439c85d598203a5910e738369ad2218")
addappid(1023704, 1, "e159aacdff1f3dfde1bcfcfe865fab87294a42292780a57ce81d3141fd215511")
