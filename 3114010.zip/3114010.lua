-- Lua provided by RyzenAPI
-- Game: CAPTURED

-- MAIN APPLICATION
addappid(3114010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114011, 1, "7ecaaf496a01b9f4ba0ee21372107bcc10f909e9d3575253f900fc644a265835")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
