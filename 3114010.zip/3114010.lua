-- Lua provided by RyzenAPI
-- Game: CAPTURED

-- MAIN APPLICATION
addappid(3114010)
-- Game: addappid(3114010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114011, 1, "7ecaaf496a01b9f4ba0ee21372107bcc10f909e9d3575253f900fc644a265835")
