-- Lua provided by RyzenAPI
-- Game: Divine Dynamo Flamefrit

-- MAIN APPLICATION
addappid(3068580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068581, 1, "5383f9f5644c3a1dcbbd1e9eed815e508f129d994e9659fda9240f231b41c1cb")

