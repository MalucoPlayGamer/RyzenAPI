-- Lua provided by SkyAPI 
-- Game: Divine Dynamo Flamefrit
addappid(3068580)
addappid(3068581, 1, "5383f9f5644c3a1dcbbd1e9eed815e508f129d994e9659fda9240f231b41c1cb")
