-- Lua provided by RyzenAPI
-- Game: Divine Dynamo Flamefrit

-- MAIN APPLICATION
addappid(3068580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068581, 1, "5383f9f5644c3a1dcbbd1e9eed815e508f129d994e9659fda9240f231b41c1cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
