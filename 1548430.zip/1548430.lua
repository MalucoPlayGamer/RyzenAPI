-- Lua provided by RyzenAPI
-- Game: Sacrifice of The Spirit

-- MAIN APPLICATION
addappid(1548430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548431, 1, "5715c4d2421b1abab5d7629747d46aaf37399d8da03cb982eb7905cf82cad501")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
