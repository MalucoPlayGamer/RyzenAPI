-- Lua provided by RyzenAPI
-- Game: Sacrifice of The Spirit

-- MAIN APPLICATION
addappid(1548430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548431, 1, "5715c4d2421b1abab5d7629747d46aaf37399d8da03cb982eb7905cf82cad501")
