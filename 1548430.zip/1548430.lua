-- Lua provided by SkyAPI 
-- Game: Sacrifice of The Spirit
addappid(1548430)
addappid(1548431, 1, "5715c4d2421b1abab5d7629747d46aaf37399d8da03cb982eb7905cf82cad501")
