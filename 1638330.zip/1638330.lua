-- Lua provided by RyzenAPI
-- Game: Game: Darius Cozmic Collection Arcade

-- MAIN APPLICATION
addappid(1638330)
-- Game: addappid(1638330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638331, 1, "7efd6b6cebf738807ea59b80cde184306b726b68662de40bdb46a82c8d21cffd")
