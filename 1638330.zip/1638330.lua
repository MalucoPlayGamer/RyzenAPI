-- Lua provided by RyzenAPI 
-- Game: Darius Cozmic Collection Arcade
addappid(1638330)
addappid(1638331, 1, "7efd6b6cebf738807ea59b80cde184306b726b68662de40bdb46a82c8d21cffd")
