-- Lua provided by RyzenAPI
-- Game: Damage: Sadistic Butchering of Humanity

-- MAIN APPLICATION
addappid(544220)

-- MAIN APP DEPOTS / PACKAGES
addappid(544221, 1, "9f69e5081f20cd5029ccb71c14229cf9b9b2f1b51b811aff735820cb89158aef")
