-- Lua provided by RyzenAPI
-- Game: Damage: Sadistic Butchering of Humanity

-- MAIN APPLICATION
addappid(544220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(544221, 1, "9f69e5081f20cd5029ccb71c14229cf9b9b2f1b51b811aff735820cb89158aef")

