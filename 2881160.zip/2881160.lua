-- Lua provided by RyzenAPI
-- Game: Game: SuperEat Man

-- MAIN APPLICATION
addappid(2881160)
-- Game: addappid(2881160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881161, 1, "f618b678bfaac1c4545ea616781095c37a8cc2113fcecfe2f8105d8889396f73")
