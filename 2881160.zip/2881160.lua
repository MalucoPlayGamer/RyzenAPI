-- Lua provided by RyzenAPI
-- Game: SuperEat Man

-- MAIN APPLICATION
addappid(2881160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2881161, 1, "f618b678bfaac1c4545ea616781095c37a8cc2113fcecfe2f8105d8889396f73")

