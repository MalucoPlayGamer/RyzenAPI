-- Lua provided by RyzenAPI
-- Game: Game: Bloody Glimpse

-- MAIN APPLICATION
addappid(709840)
-- Game: addappid(709840)

-- MAIN APP DEPOTS / PACKAGES
addappid(709841, 1, "8ffa4b0a7ce10e53f19239bf6d6e87399551e85ac3943c28e9b20fac5c59c783")
addappid(709842, 1, "371818e09ffaa454e7b78f2677526637edb1ab1d4a84e436b9fd9884d387fe71")
addappid(709843, 1, "080f50b36eaea177ebb47be10c20668854bf3595ffd6e3d8f7207286d3b28c79")
addappid(709844, 1, "3e0807b6399b5bfc3896e276e59c6544f0d89cf62ef3f7c4d6e1207654d881bc")
