-- Lua provided by SkyAPI 
-- Game: AppID 1829340
addappid(1829340)
addappid(1829341, 1, "5c3868dae060e7a6eaa374d308c72146cdd2aee91e9e4e3615577b547f60c9e5")
