-- 4754740's Lua and Manifest Created by Hubcap Manifest
-- Market Chain 98
-- Created: July 30, 2026 at 00:14:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4754740) -- Market Chain 98
-- MAIN APP DEPOTS
addappid(4754741, 1, "004820d9fe9e2795dea8c7b58e92a1e503d0f282b691606083f857908bff50ca") -- Depot 4754741
setManifestid(4754741, "5750009293799406343", 151416651)