-- Lua provided by RyzenAPI
-- Game: The Architect: Paris

-- MAIN APPLICATION
addappid(1525620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525621, 1, "8dfb5123a2cee700963305797ab949c67df79e8cbbbca271f3c4f3c02dc2bdd5")
