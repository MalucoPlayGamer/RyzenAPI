-- Lua provided by RyzenAPI
-- Game: The Anointed: David Saves Keilah

-- MAIN APPLICATION
addappid(1942530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1942531, 1, "94809b9b5e290f9231ac80248a8ab814342f6a9b4f7f1a6d672b08fc9c65e68e")

