-- Lua provided by RyzenAPI
-- Game: Bonfire

-- MAIN APPLICATION
addappid(1232310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232311, 1, "077e12398a07d5ff1ea405c420b74bd55400dce45730bf414dc4d168cad6357b")
