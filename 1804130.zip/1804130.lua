-- Lua provided by RyzenAPI
-- Game: Ghoul Castle 3D: Gold Edition

-- MAIN APPLICATION
addappid(1804130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804132,0,"180f713d64b824d263fdb4cd2fd333a4b4d402db10dec9e80d16294b379f33e7")
