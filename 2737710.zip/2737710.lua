-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 It’s a Night Magic Lucky Bag Ver. Empire Costume Collection

-- MAIN APPLICATION
addappid(2737710)
-- Game: addappid(2737710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737711, 1, "16baaa94001746640fc29545e82b1149c463e8769fb5193c5611c3f716abe662")
