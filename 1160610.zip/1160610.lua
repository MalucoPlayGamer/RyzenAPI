-- Lua provided by RyzenAPI
-- Game: Future Girls

-- MAIN APPLICATION
addappid(1160610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160611, 1, "5155b394a9fc7f97131bcc2b84bc327cf5b1699e5e5aff66dacf0df18d145cd5")
