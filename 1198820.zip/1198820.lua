-- Lua provided by RyzenAPI
-- Game: Monster Girl Garden

-- MAIN APPLICATION
addappid(1198820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198821, 1, "6fb52dcb97ebe6ea23de39cf61aa9a968a79508cd8f072354d1eda8715c8d695")
