-- Lua provided by SkyAPI 
-- Game: Roald Amundsen's House
addappid(1435700)
addappid(1435701, 1, "53b1e93007e505e654eb6424cc0c8cf6be9ab274b7dcfd511e596a6f3acc3b4a")
