-- Lua provided by RyzenAPI
-- Game: Game: Roald Amundsen's House

-- MAIN APPLICATION
addappid(1435700)
-- Game: addappid(1435700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435701, 1, "53b1e93007e505e654eb6424cc0c8cf6be9ab274b7dcfd511e596a6f3acc3b4a")
